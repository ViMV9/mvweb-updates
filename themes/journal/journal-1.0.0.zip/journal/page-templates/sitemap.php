<?php
/**
 * Template Name: Sitemap
 *
 * The map for people: every section of the site with its entries, in the look, the kinds and the order set in the Customizer.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_sitemap_link' ) ) {
	/**
	 * A name of the map as a link, or as plain text when it has no address.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $item Name and url.
	 * @param string              $css  Class of the link.
	 *
	 * @return string
	 */
	function mvweb_theme_sitemap_link( array $item, $css = '' ) {
		$attr = '' === $css ? '' : ' class="' . esc_attr( $css ) . '"';

		if ( empty( $item['url'] ) ) {
			return '<span' . $attr . '>' . esc_html( $item['name'] ) . '</span>';
		}

		return '<a' . $attr . ' href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['name'] ) . '</a>';
	}
}

if ( ! function_exists( 'mvweb_theme_sitemap_count' ) ) {
	/**
	 * The number of entries beside a name, when the map shows the numbers.
	 *
	 * @since 0.1.0
	 *
	 * @param int $number Number.
	 *
	 * @return string
	 */
	function mvweb_theme_sitemap_count( $number ) {
		if ( (int) $number < 1 || ! mvweb_core_sitemap()['counts'] ) {
			return '';
		}

		return '<span class="mvweb-t-sitemap__n">' . esc_html( number_format_i18n( (int) $number ) ) . '</span>';
	}
}

if ( ! function_exists( 'mvweb_theme_sitemap_more' ) ) {
	/**
	 * The link to the rest of a section: «More: 12 items».
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $group Section with more and url_more.
	 *
	 * @return string Empty when nothing is left.
	 */
	function mvweb_theme_sitemap_more( array $group ) {
		if ( '' === $group['more'] || '' === $group['url_more'] ) {
			return '';
		}

		return '<a class="mvweb-t-sitemap__more" href="' . esc_url( $group['url_more'] ) . '">' . esc_html( $group['more'] ) . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>';
	}
}

if ( ! function_exists( 'mvweb_theme_sitemap_icon' ) ) {
	/**
	 * The icon of a kind of the map in its coloured box; the names the sprite of the theme lacks take its nearest icon.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $type Kind of the map.
	 *
	 * @return string
	 */
	function mvweb_theme_sitemap_icon( array $type ) {
		$near = array(
			'list'          => 'category-2',
			'shopping-cart' => 'cart',
		);
		$icon = (string) $type['icon'];

		return '<span class="mvweb-t-sitemap__ico">' . mvweb_theme_icon( isset( $near[ $icon ] ) ? $near[ $icon ] : $icon ) . '</span>';
	}
}

if ( ! function_exists( 'mvweb_theme_sitemap_title' ) ) {
	/**
	 * The name of a kind of the map: a link to its whole listing when it has one.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $type Kind of the map.
	 * @param string              $css  Class of the name.
	 *
	 * @return string
	 */
	function mvweb_theme_sitemap_title( array $type, $css ) {
		return mvweb_theme_sitemap_link(
			array(
				'name' => $type['label'],
				'url'  => $type['archive'] ? $type['archive']['url'] : '',
			),
			$css
		);
	}
}

get_header();

while ( have_posts() ) :
	the_post();

	$mvweb_map   = mvweb_core_sitemap();
	$mvweb_title = mvweb_core_alt_h1();

	get_template_part(
		'template-parts/page-hero',
		null,
		array(
			'title' => '' !== $mvweb_title ? $mvweb_title : get_the_title(),
			'lead'  => has_excerpt() ? get_the_excerpt() : '',
		)
	);

	mvweb_theme_layout_open( mvweb_core_sidebar_area() );

	if ( $mvweb_map['types'] ) {
		get_template_part( 'template-parts/sitemap/' . $mvweb_map['view'], null, $mvweb_map );
	} else {
		get_template_part(
			'template-parts/empty',
			null,
			array(
				'icon'  => 'map-pin',
				'title' => __( 'The map is empty for now', 'journal' ),
				'text'  => __( 'The sections of the site will appear here as soon as they have pages.', 'journal' ),
			)
		);
	}

	mvweb_theme_layout_close( mvweb_core_sidebar_area() );

endwhile;

get_footer();
