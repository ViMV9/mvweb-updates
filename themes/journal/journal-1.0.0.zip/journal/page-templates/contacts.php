<?php
/**
 * Template Name: Contacts
 *
 * The contacts page in five looks.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	$mvweb_view     = mvweb_core_area_view( 'contacts' );
	$mvweb_title    = mvweb_core_alt_h1();
	$mvweb_title    = '' !== $mvweb_title ? $mvweb_title : get_the_title();
	$mvweb_lead     = has_excerpt() ? get_the_excerpt() : '';
	$mvweb_contacts = mvweb_core_contacts();
	$mvweb_map      = mvweb_core_profile_map();
	$mvweb_has_map  = '' !== $mvweb_map['image'] || '' !== $mvweb_map['src'];
	$mvweb_places   = mvweb_core_branches();

	ob_start();
	the_content();
	$mvweb_text = trim( (string) ob_get_clean() );

	if ( ! $mvweb_places && $mvweb_contacts['addresses'] ) {
		$mvweb_places = array(
			array_merge(
				$mvweb_contacts['addresses'][0],
				array(
					'phones' => $mvweb_contacts['phones'],
					'hours'  => $mvweb_contacts['hours'],
					'email'  => $mvweb_contacts['email'],
				)
			),
		);
	}

	$mvweb_map_part = static function ( array $map, $look, $name = '' ) {
		get_template_part(
			'template-parts/map-frame',
			null,
			array(
				'map'   => $map,
				'name'  => $name,
				'class' => 'mvweb-t-map-frame--' . $look,
				'sizes' => '(min-width: 1024px) 60vw, 100vw',
			)
		);
	};

	if ( '5' !== $mvweb_view ) {
		get_template_part(
			'template-parts/page-hero',
			null,
			array(
				'title' => $mvweb_title,
				'lead'  => $mvweb_lead,
			)
		);
	} else {
		ob_start();
		get_template_part( 'template-parts/crumbs' );
		$mvweb_crumbs = trim( (string) ob_get_clean() );

		if ( '' !== $mvweb_crumbs ) {
			echo '<div class="mvweb-t-container mvweb-t-contacts__crumbs">' . $mvweb_crumbs . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the breadcrumbs part, escaped there.
		}
	}

	mvweb_theme_layout_open( mvweb_core_sidebar_area(), 'mvweb-t-contacts mvweb-t-contacts--' . $mvweb_view );

	if ( '1' === $mvweb_view ) :
		?>
		<div class="mvweb-t-contacts__pair<?php echo $mvweb_has_map ? '' : ' mvweb-t-contacts__pair--solo'; ?>">
			<?php
			get_template_part( 'template-parts/contacts/list', null, array( 'contacts' => $mvweb_contacts ) );

			if ( $mvweb_has_map ) {
				$mvweb_map_part( $mvweb_map, 'tall' );
			}
			?>
		</div>
		<?php
	elseif ( '2' === $mvweb_view ) :
		if ( $mvweb_has_map ) {
			$mvweb_map_part( $mvweb_map, 'wide' );
		}

		get_template_part(
			'template-parts/contacts/branches',
			null,
			array(
				'places' => $mvweb_places,
				'look'   => 'cards',
			)
		);
	elseif ( '3' === $mvweb_view ) :
		get_template_part(
			'template-parts/contacts/cities',
			null,
			array(
				'places' => $mvweb_places,
				'map'    => $mvweb_map,
			)
		);
	elseif ( '4' === $mvweb_view ) :
		if ( '' !== $mvweb_text ) :
			?>
			<div class="mvweb-t-contacts__form mvweb-t-prose" data-prose>
				<?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The content of the page, filtered by WordPress. ?>
			</div>
			<?php
		endif;

		get_template_part(
			'template-parts/contacts/branches',
			null,
			array(
				'places' => $mvweb_places,
				'look'   => 'full',
			)
		);
	else :
		?>
		<div class="mvweb-t-contacts__overmap<?php echo $mvweb_has_map ? '' : ' mvweb-t-contacts__overmap--solo'; ?>">
			<?php
			if ( $mvweb_has_map ) {
				$mvweb_map_part( $mvweb_map, 'tall' );
			}
			?>
			<div class="mvweb-t-contacts__card">
				<?php
				mvweb_core_render_layout(
					'page-hero',
					array(
						'title' => $mvweb_title,
						'lead'  => $mvweb_lead,
						'above' => true,
					)
				);

				if ( ! mvweb_core_layout_has( 'page-hero', 'title' ) ) :
					?>
					<h1 class="screen-reader-text"><?php echo esc_html( $mvweb_title ); ?></h1>
					<?php
				endif;

				get_template_part( 'template-parts/contacts/list', null, array( 'contacts' => $mvweb_contacts ) );
				?>
			</div>
		</div>
		<?php
	endif;

	if ( '4' !== $mvweb_view && '' !== $mvweb_text ) :
		?>
		<div class="mvweb-t-prose mvweb-t-prose--measure" data-prose>
			<?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The content of the page, filtered by WordPress. ?>
		</div>
		<?php
	endif;

	mvweb_theme_layout_close( mvweb_core_sidebar_area() );

endwhile;

get_footer();
