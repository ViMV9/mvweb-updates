<?php
/**
 * Search results in five looks.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_view   = mvweb_core_area_view( 'search' );
$mvweb_needle = get_search_query( false );
$mvweb_found  = '' === $mvweb_needle ? 0 : (int) $GLOBALS['wp_query']->found_posts;
$mvweb_words  = array_values(
	array_filter(
		array_map( 'strval', (array) get_query_var( 'search_terms' ) ),
		static fn( $word ) => mb_strlen( $word ) >= 2
	)
);
$mvweb_lists  = array(
	'1' => array( 'row', '(min-width: 600px) 220px, 100vw' ),
	'2' => array( '', '(min-width: 1024px) 40vw, (min-width: 600px) 50vw, 100vw' ),
	'3' => array( 'text', '' ),
	'5' => array( 'text', '' ),
);
$mvweb_list   = isset( $mvweb_lists[ $mvweb_view ] ) ? $mvweb_lists[ $mvweb_view ] : $mvweb_lists['1'];
$mvweb_after  = get_search_form( array( 'echo' => false ) );

if ( $mvweb_found > 0 ) {
	$mvweb_after .= '<p class="mvweb-t-page-hero__meta">' . esc_html(
		sprintf(
			/* translators: 1: number of results, 2: search query. */
			_n( '%1$s result for “%2$s”', '%1$s results for “%2$s”', $mvweb_found, 'journal' ),
			number_format_i18n( $mvweb_found ),
			$mvweb_needle
		)
	) . '</p>';
}

get_header();

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'title' => __( 'Search the site', 'journal' ),
		'after' => $mvweb_after,
		'looks' => '5' === $mvweb_view ? array( 'center' ) : array(),
	)
);

mvweb_theme_layout_open( mvweb_core_sidebar_area(), 'mvweb-t-search-page mvweb-t-search-page--' . $mvweb_view );

if ( $mvweb_found > 0 ) :
	update_post_thumbnail_cache();
	?>
	<div class="mvweb-t-search-results">
		<?php
		if ( '3' === $mvweb_view ) {
			get_template_part( 'template-parts/search/tabs' );
		}

		if ( '4' === $mvweb_view ) :
			get_template_part( 'template-parts/search/by-topic', null, array( 'words' => $mvweb_words ) );
		else :
			?>
			<div class="<?php echo esc_attr( 'mvweb-t-results mvweb-t-results--' . $mvweb_view ); ?>">
				<?php
				while ( have_posts() ) :
					the_post();

					get_template_part(
						'template-parts/search/result',
						null,
						array(
							'modifier' => $mvweb_list[0],
							'sizes'    => $mvweb_list[1],
							'words'    => $mvweb_words,
						)
					);
				endwhile;
				?>
			</div>
			<?php
		endif;

		mvweb_theme_pagination();
		?>
	</div>
	<?php
else :
	?>
	<?php
	$mvweb_none = mvweb_core_layout_html( 'search.empty' );

	if ( '' !== trim( $mvweb_none ) ) :
		?>
		<div class="mvweb-t-empty mvweb-t-search-none"><?php echo $mvweb_none; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?></div>
		<?php
	endif;

	get_template_part( 'template-parts/search/hits' );
endif;

mvweb_theme_layout_close( mvweb_core_sidebar_area() );

get_footer();
