<?php
/**
 * Fields every block carries besides its own: the view, the look and the animation.
 *
 * The registry adds them, so a block declares only what is its own. The names
 * of the views belong to the theme: the data keeps a key.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_section_views' ) ) {
	/**
	 * The views a theme draws for a block type.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type Block type.
	 *
	 * @return array<string,string> View key => name; empty when there is no choice to make.
	 */
	function mvweb_core_section_views( $type ) {
		/**
		 * Filter the views of a block type.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $views View key => name.
		 * @param string               $type  Block type.
		 */
		$raw   = (array) apply_filters( 'mvweb_core_section_views', array(), $type );
		$views = array();

		foreach ( $raw as $key => $name ) {
			$key = sanitize_key( $key );

			if ( '' !== $key && is_string( $name ) && '' !== $name ) {
				$views[ $key ] = $name;
			}
		}

		return count( $views ) > 1 ? $views : array();
	}
}

if ( ! function_exists( 'mvweb_core_colour_tones' ) ) {
	/**
	 * The ready colours a colour field offers before the editor's own: colours of the palette that follow its preset and the dark scheme.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Key => name.
	 */
	function mvweb_core_colour_tones() {
		/**
		 * Filter the ready colours of the colour fields.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $tones Key => name.
		 */
		$tones = (array) apply_filters(
			'mvweb_core_colour_tones',
			array(
				'page'    => __( 'Page background', 'mvweb-core' ),
				'surface' => __( 'Tinted', 'mvweb-core' ),
				'soft'    => __( 'Soft accent', 'mvweb-core' ),
				'accent'  => __( 'Accent colour', 'mvweb-core' ),
				'inverse' => __( 'Dark colour', 'mvweb-core' ),
			)
		);
		$clean = array();

		foreach ( $tones as $key => $name ) {
			$key = sanitize_key( (string) $key );

			if ( '' !== $key && is_string( $name ) ) {
				$clean[ $key ] = $name;
			}
		}

		return $clean;
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_colour' ) ) {
	/**
	 * A colour field value: the key of a ready colour or a hex colour.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string Empty when it is neither.
	 */
	function mvweb_core_sanitize_colour( $value ) {
		$value = is_scalar( $value ) ? trim( (string) $value ) : '';

		return isset( mvweb_core_colour_tones()[ $value ] ) ? $value : (string) sanitize_hex_color( $value );
	}
}

if ( ! function_exists( 'mvweb_core_colour_css' ) ) {
	/**
	 * A colour field value as CSS: the background and the text that reads on it.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Value of a colour field.
	 *
	 * @return array{bg:string,ink:string}|array{} Empty when no colour is set.
	 */
	function mvweb_core_colour_css( $value ) {
		$value = mvweb_core_sanitize_colour( $value );

		if ( '' === $value ) {
			return array();
		}

		if ( '#' === $value[0] ) {
			return array(
				'bg'  => $value,
				'ink' => mvweb_core_strict_ink( $value ),
			);
		}

		return array(
			'bg'  => 'var(--mvweb-t-tone-' . $value . ')',
			'ink' => 'var(--mvweb-t-tone-' . $value . '-ink)',
		);
	}
}

if ( ! function_exists( 'mvweb_core_tones_styles' ) ) {
	/**
	 * Give the builder the tokens of the theme, so that its ready colours show the real colours of the palette.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_tones_styles() {
		if ( ! wp_script_is( 'mvweb-core-builder', 'enqueued' ) ) {
			return;
		}

		$path = get_theme_file_path( 'assets/css/tokens.css' );

		if ( ! file_exists( $path ) ) {
			return;
		}

		$colors       = function_exists( 'mvweb_core_element_color_css' ) ? mvweb_core_element_color_css() : array();
		$declarations = '';

		foreach ( array_merge( isset( $colors['both'] ) ? (array) $colors['both'] : array(), isset( $colors['light'] ) ? (array) $colors['light'] : array() ) as $property => $value ) {
			$value = mvweb_cz_sanitize_css_value( $value );

			if ( '' !== $value ) {
				$declarations .= $property . ':' . $value . ';';
			}
		}

		wp_enqueue_style( 'mvweb-core-builder-tokens', get_theme_file_uri( 'assets/css/tokens.css' ), array(), (string) filemtime( $path ) );
		wp_add_inline_style( 'mvweb-core-builder-tokens', mvweb_core_palette_css() . ( '' !== $declarations ? ':root{' . $declarations . '}' : '' ) );
	}
}
add_action( 'admin_enqueue_scripts', 'mvweb_core_tones_styles', 20 );
add_action( 'customize_controls_enqueue_scripts', 'mvweb_core_tones_styles', 20 );

if ( ! function_exists( 'mvweb_core_look_colour_field' ) ) {
	/**
	 * A colour field of the look group, shown while the background is the editor's own.
	 *
	 * @since 0.1.0
	 *
	 * @param string $label Field label.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_look_colour_field( $label ) {
		return array(
			'type'      => 'color',
			'group'     => __( 'Block design', 'mvweb-core' ),
			'label'     => $label,
			'show_when' => array(
				'field' => 'background',
				'in'    => array( 'custom' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_cards_colour_fields' ) ) {
	/**
	 * The colours of the cards and the icons of a block, shown while the block has a background.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_cards_colour_fields() {
		$when = array(
			'field' => 'background',
			'in'    => array( 'surface', 'accent', 'inverse', 'custom' ),
		);

		return array(
			'cards_bg'   => array(
				'type'      => 'color',
				'look'      => true,
				'label'     => __( 'Background of the cards', 'mvweb-core' ),
				'show_when' => $when,
			),
			'cards_ink'  => array(
				'type'        => 'color',
				'look'        => true,
				'label'       => __( 'Text colour of the cards', 'mvweb-core' ),
				'description' => __( 'Works with the background of the cards. Empty colour is picked by itself, black or white.', 'mvweb-core' ),
				'show_when'   => $when,
			),
			'cards_icon' => array(
				'type'        => 'color',
				'look'        => true,
				'label'       => __( 'Colour of the icons', 'mvweb-core' ),
				'description' => __( 'The plate under the icon or number; the sign on it is black or white by itself. The colours of the cards stay the same in the dark scheme.', 'mvweb-core' ),
				'show_when'   => $when,
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_section_common_fields' ) ) {
	/**
	 * Split a block's fields and add the common ones around them.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type Block type.
	 * @param array  $own  Raw fields the block declared.
	 *
	 * @return array{first:array,own:array,last:array} Fields before the block's own, the block's own, and after.
	 */
	function mvweb_core_section_common_fields( $type, array $own ) {
		$first = array();
		$views = mvweb_core_section_views( $type );

		if ( ! empty( $views ) ) {
			$first['view'] = array(
				'type'    => 'select',
				'label'   => __( 'View', 'mvweb-core' ),
				'choices' => $views,
				'default' => (string) array_key_first( $views ),
			);
		}

		unset( $own['background'] );

		$look = __( 'Block design', 'mvweb-core' );
		$last = array(
			'background'     => array(
				'type'     => 'select',
				'group'    => $look,
				'label'    => __( 'Background', 'mvweb-core' ),
				'choices'  => array(
					'plain'   => __( 'Page background', 'mvweb-core' ),
					'surface' => __( 'Tinted', 'mvweb-core' ),
					'accent'  => __( 'Accent colour', 'mvweb-core' ),
					'inverse' => __( 'Inverse, dark', 'mvweb-core' ),
					'custom'  => __( 'Own colours', 'mvweb-core' ),
				),
				'swatches' => array(
					'plain'   => 'page',
					'surface' => 'surface',
					'accent'  => 'accent',
					'inverse' => 'inverse',
					'custom'  => '',
				),
				'default'  => 'plain',
			),
			'bg_color'       => mvweb_core_look_colour_field( __( 'Background colour', 'mvweb-core' ) ),
			'ink_color'      => mvweb_core_look_colour_field( __( 'Text colour', 'mvweb-core' ) ),
			'bg_color_dark'  => mvweb_core_look_colour_field( __( 'Background colour, dark scheme', 'mvweb-core' ) ),
			'ink_color_dark' => mvweb_core_look_colour_field( __( 'Text colour, dark scheme', 'mvweb-core' ) ),
			'head_color'     => array(
				'type'        => 'color',
				'group'       => $look,
				'label'       => __( 'Colour of the block heading', 'mvweb-core' ),
				'description' => __( 'The heading above the content of the block; the cards keep their colours. “As the theme has it” keeps the colour of the view.', 'mvweb-core' ),
			),
			'kicker_color'   => array(
				'type'        => 'color',
				'group'       => $look,
				'label'       => __( 'Colour of the line above the heading', 'mvweb-core' ),
				'description' => __( '“As the theme has it” keeps the colour of the view.', 'mvweb-core' ),
			),
		);

		$last['ink_color']['description'] = __( 'Empty text colour is picked by itself, black or white. The dark scheme keeps the light colours until its own are set.', 'mvweb-core' );

		foreach ( $own as $key => $field ) {
			if ( ! empty( $field['look'] ) ) {
				unset( $field['look'], $own[ $key ] );
				$field['group'] = $look;
				$last[ $key ]   = $field;
			}
		}

		if ( isset( $own['image'] ) && 'image' === $own['image']['type'] ) {
			$side = isset( $own['image']['side'] ) && 'end' === $own['image']['side'] ? 'end' : 'start';

			unset( $own['image']['side'] );

			$last['image_side'] = array(
				'type'    => 'select',
				'group'   => $look,
				'label'   => __( 'Picture side', 'mvweb-core' ),
				'choices' => array(
					'start' => __( 'Left', 'mvweb-core' ),
					'end'   => __( 'Right', 'mvweb-core' ),
				),
				'default' => $side,
			);
			$last['image_size'] = array(
				'type'    => 'select',
				'group'   => $look,
				'label'   => __( 'Picture size', 'mvweb-core' ),
				'choices' => array(
					's' => __( 'Small', 'mvweb-core' ),
					'm' => __( 'Medium', 'mvweb-core' ),
					'l' => __( 'Large', 'mvweb-core' ),
				),
				'default' => 'm',
			);
		}

		if ( isset( $own['button_text'] ) ) {
			$last['button_kind'] = array(
				'type'    => 'select',
				'group'   => $look,
				'label'   => __( 'Button look', 'mvweb-core' ),
				'choices' => array(
					'primary'   => __( 'Filled', 'mvweb-core' ),
					'secondary' => __( 'Outlined', 'mvweb-core' ),
					'link'      => __( 'Link', 'mvweb-core' ),
				),
				'default' => 'primary',
			);
		}

		$last['motion'] = array(
			'type'    => 'select',
			'group'   => __( 'Animation', 'mvweb-core' ),
			'label'   => __( 'Animation on appearance', 'mvweb-core' ),
			'choices' => array(
				'auto' => __( 'As in the view', 'mvweb-core' ),
				'none' => __( 'No animation', 'mvweb-core' ),
			),
			'default' => 'auto',
		);

		return array(
			'first' => $first,
			'own'   => $own,
			'last'  => $last,
		);
	}
}

if ( ! function_exists( 'mvweb_core_view' ) ) {
	/**
	 * The chosen view of a block.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props Values of the block.
	 *
	 * @return string Empty when the block has one look only.
	 */
	function mvweb_core_view( array $props ) {
		return isset( $props['view'] ) ? sanitize_key( $props['view'] ) : '';
	}
}

if ( ! function_exists( 'mvweb_core_contrast_ratio' ) ) {
	/**
	 * The WCAG contrast ratio of two colours.
	 *
	 * @since 0.1.0
	 *
	 * @param string $a Hex colour.
	 * @param string $b Hex colour.
	 *
	 * @return float 1 to 21.
	 */
	function mvweb_core_contrast_ratio( $a, $b ) {
		$luminance = static function ( $hex ) {
			$hex = ltrim( (string) $hex, '#' );
			$hex = 3 === strlen( $hex ) ? $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2] : $hex;
			$sum = 0.0;

			foreach ( array( 0.2126, 0.7152, 0.0722 ) as $i => $weight ) {
				$value = hexdec( substr( $hex, $i * 2, 2 ) ) / 255;
				$sum  += $weight * ( $value <= 0.03928 ? $value / 12.92 : pow( ( $value + 0.055 ) / 1.055, 2.4 ) );
			}

			return $sum;
		};

		$one = $luminance( $a );
		$two = $luminance( $b );

		return ( max( $one, $two ) + 0.05 ) / ( min( $one, $two ) + 0.05 );
	}
}

if ( ! function_exists( 'mvweb_core_strict_ink' ) ) {
	/**
	 * Black or white, whichever has the higher contrast ratio: one of them reaches 4.5 on every background.
	 *
	 * @since 0.1.0
	 *
	 * @param string $background Hex colour.
	 *
	 * @return string
	 */
	function mvweb_core_strict_ink( $background ) {
		return mvweb_core_contrast_ratio( $background, '#ffffff' ) >= mvweb_core_contrast_ratio( $background, '#000000' ) ? '#ffffff' : '#000000';
	}
}

if ( ! function_exists( 'mvweb_core_readable_ink' ) ) {
	/**
	 * The text colour a background can always be read with.
	 *
	 * @since 0.1.0
	 *
	 * @param string $background Hex colour.
	 *
	 * @return string
	 */
	function mvweb_core_readable_ink( $background ) {
		$white = mvweb_core_contrast_ratio( $background, '#ffffff' );

		if ( $white >= mvweb_core_contrast_ratio( $background, '#000000' ) ) {
			return '#ffffff';
		}

		$hex = ltrim( (string) $background, '#' );
		$hex = 3 === strlen( $hex ) ? $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2] : $hex;
		$y   = 0.0;

		foreach ( array( 0.2126729, 0.7151522, 0.0721750 ) as $i => $weight ) {
			$y += $weight * pow( hexdec( substr( $hex, $i * 2, 2 ) ) / 255, 2.4 );
		}

		$black = pow( 0.022, 1.414 );
		$y     = $y < 0.022 ? $y + pow( 0.022 - $y, 1.414 ) : $y;
		$on    = ( pow( $y, 0.56 ) - pow( $black, 0.57 ) ) * 1.14;
		$under = ( 1 - pow( $y, 0.65 ) ) * 1.14;

		return $white >= 3 && $under > $on ? '#ffffff' : '#000000';
	}
}

if ( ! function_exists( 'mvweb_core_section_look' ) ) {
	/**
	 * The look of a block, ready for the template.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props Values of the block.
	 *
	 * @return array{background:string,style:string,image_side:string,image_size:string,button_kind:string}
	 */
	function mvweb_core_section_look( array $props ) {
		$background = isset( $props['background'] ) ? (string) $props['background'] : 'plain';
		$style      = '';

		if ( 'custom' === $background ) {
			$bg   = mvweb_core_sanitize_colour( isset( $props['bg_color'] ) ? $props['bg_color'] : '' );
			$tone = mvweb_core_colour_css( $bg );

			if ( '' === $bg ) {
				$background = 'plain';
			} elseif ( '#' !== $bg[0] ) {
				$ink    = mvweb_core_colour_css( isset( $props['ink_color'] ) ? $props['ink_color'] : '' );
				$ink    = empty( $ink ) ? $tone['ink'] : $ink['bg'];
				$style .= '--mvweb-t-sec-bg-light:' . $tone['bg'] . ';--mvweb-t-sec-ink-light:' . $ink . ';--mvweb-t-sec-bg-dark:' . $tone['bg'] . ';--mvweb-t-sec-ink-dark:' . $ink . ';';
			} else {
				$pairs   = array(
					array(
						'bg'  => $bg,
						'ink' => isset( $props['ink_color'] ) ? (string) $props['ink_color'] : '',
					),
				);
				$dark    = isset( $props['bg_color_dark'] ) ? (string) $props['bg_color_dark'] : '';
				$pairs[] = array(
					'bg'  => '' !== $dark ? $dark : $bg,
					'ink' => '' !== $dark ? ( isset( $props['ink_color_dark'] ) ? (string) $props['ink_color_dark'] : '' ) : $pairs[0]['ink'],
				);

				$names = array( 'light', 'dark' );

				foreach ( $pairs as $i => $pair ) {
					$back = mvweb_core_colour_css( $pair['bg'] );
					$back = empty( $back ) ? $tone : $back;
					$own  = mvweb_core_sanitize_colour( $pair['ink'] );

					if ( '' !== $own && '#' !== $own[0] ) {
						$ink = 'var(--mvweb-t-tone-' . $own . ')';
					} elseif ( '' !== $own && '#' === $back['bg'][0] && mvweb_core_contrast_ratio( $back['bg'], $own ) >= 4.5 ) {
						$ink = $own;
					} else {
						$ink = $back['ink'];
					}

					$style .= '--mvweb-t-sec-bg-' . $names[ $i ] . ':' . $back['bg'] . ';--mvweb-t-sec-ink-' . $names[ $i ] . ':' . $ink . ';';
				}
			}
		}

		return array(
			'background'  => $background,
			'style'       => $style,
			'image_side'  => isset( $props['image_side'] ) ? (string) $props['image_side'] : 'start',
			'image_size'  => isset( $props['image_size'] ) ? (string) $props['image_size'] : 'm',
			'button_kind' => isset( $props['button_kind'] ) ? (string) $props['button_kind'] : 'primary',
		);
	}
}

if ( ! function_exists( 'mvweb_core_h1_tag' ) ) {
	/**
	 * The tag of a heading that may be the h1: h1 for the one that owns it on the front page, div for the rest.
	 *
	 * @since 0.1.0
	 *
	 * @param string $owner   Block type that asks for the tag; empty for the first-screen blocks.
	 * @param bool   $reserve Whether to reserve the h1 for the owner instead of asking for it.
	 *
	 * @return string One of h1, div.
	 */
	function mvweb_core_h1_tag( $owner = '', $reserve = false ) {
		static $reserved = '';

		if ( $reserve ) {
			$reserved = (string) $owner;

			return 'div';
		}

		if ( ! is_front_page() || mvweb_core_h1_given() || $reserved !== (string) $owner ) {
			return 'div';
		}

		do_action( 'mvweb_core_front_h1' );

		return 'h1';
	}
}

if ( ! function_exists( 'mvweb_core_h1_given' ) ) {
	/**
	 * Whether a heading of the front page has taken the h1.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_h1_given() {
		return (bool) did_action( 'mvweb_core_front_h1' );
	}
}

if ( ! function_exists( 'mvweb_core_h1_reserve' ) ) {
	/**
	 * Decide who prints the h1 of the front page before the header: a long-text block that asks for it, else a first-screen block with a heading, else the logo.
	 *
	 * @since 0.1.0
	 *
	 * @param array $rows Rows of the page, as mvweb_core_request_sections() returns them; empty when the page prints no blocks.
	 *
	 * @return bool Whether a block took the h1.
	 */
	function mvweb_core_h1_reserve( array $rows ) {
		if ( ! is_front_page() ) {
			return false;
		}

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) || ! isset( $row['type'] ) || 'seo-text' !== $row['type'] ) {
				continue;
			}

			$props = mvweb_core_section_props( 'seo-text', isset( $row['props'] ) && is_array( $row['props'] ) ? $row['props'] : array() );
			$parts = mvweb_core_parts( $props );

			if ( ! empty( $props['title_h1'] ) && '' !== trim( (string) $props['title'] ) && '' !== trim( (string) $props['text'] ) && in_array( 'title', $parts, true ) ) {
				mvweb_core_h1_tag( 'seo-text', true );

				return true;
			}
		}

		foreach ( $rows as $row ) {
			if ( is_array( $row ) && isset( $row['type'] ) && mvweb_core_h1_first_screen( (string) $row['type'], isset( $row['props'] ) && is_array( $row['props'] ) ? $row['props'] : array() ) ) {
				return true;
			}
		}

		mvweb_core_h1_tag( 'logo', true );

		return false;
	}
}

if ( ! function_exists( 'mvweb_core_h1_first_screen' ) ) {
	/**
	 * Whether a first-screen block prints a heading, and with it the h1 of the front page.
	 *
	 * @since 0.1.0
	 *
	 * @param string              $type  Block type.
	 * @param array<string,mixed> $props Saved values of the block.
	 *
	 * @return bool
	 */
	function mvweb_core_h1_first_screen( $type, array $props ) {
		$asks = false;

		if ( 'hero' === $type ) {
			$props = mvweb_core_section_props( 'hero', $props );
			$asks  = '' !== trim( (string) ( isset( $props['title'] ) ? $props['title'] : '' ) );
		} elseif ( 'hero-slider' === $type ) {
			$props  = mvweb_core_section_props( 'hero-slider', $props );
			$slides = isset( $props['slides'] ) && is_array( $props['slides'] ) ? mvweb_core_visible_rows( $props['slides'] ) : array();
			$source = isset( $props['source'] ) ? (string) $props['source'] : 'manual';
			$posts  = function_exists( 'mvweb_core_hero_slider_posts_on' ) && mvweb_core_hero_slider_posts_on() && in_array( $source, array( 'posts', 'mixed' ), true );
			$first  = 'posts' === $source && $posts ? null : reset( $slides );

			$asks = is_array( $first ) ? '' !== trim( (string) ( isset( $first['title'] ) ? $first['title'] : '' ) ) : $posts;
		}

		/**
		 * Filter whether a block on the front page prints a heading that takes the h1 before the logo.
		 *
		 * @since 0.1.0
		 *
		 * @param bool                $asks  Whether the block prints the heading.
		 * @param string              $type  Block type.
		 * @param array<string,mixed> $props Values of the block.
		 */
		return (bool) apply_filters( 'mvweb_core_h1_first_screen', $asks, $type, $props );
	}
}

if ( ! function_exists( 'mvweb_core_cards_colours' ) ) {
	/**
	 * Own colours of the cards and the icons of a block: background and text of each, the text of the cards checked for contrast.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props Props of the row.
	 *
	 * @return array{cards?:array{bg:string,ink:string},icon?:array{bg:string,ink:string}} Only the colours the editor set.
	 */
	function mvweb_core_cards_colours( array $props ) {
		$colours = array();
		$cards   = mvweb_core_colour_css( isset( $props['cards_bg'] ) ? $props['cards_bg'] : '' );
		$ink     = mvweb_core_colour_css( isset( $props['cards_ink'] ) ? $props['cards_ink'] : '' );
		$icon    = mvweb_core_colour_css( isset( $props['cards_icon'] ) ? $props['cards_icon'] : '' );

		if ( $cards ) {
			$own = empty( $ink ) ? '' : $ink['bg'];

			if ( '' !== $own && '#' === $own[0] && '#' === $cards['bg'][0] ) {
				$own = mvweb_core_contrast_ratio( $cards['bg'], $own ) >= 4.5 ? $own : '';
			}

			$colours['cards'] = array(
				'bg'  => $cards['bg'],
				'ink' => '' !== $own ? $own : $cards['ink'],
			);
		}

		if ( $icon ) {
			$colours['icon'] = array(
				'bg'  => $icon['bg'],
				'ink' => $icon['ink'],
			);
		}

		return $colours;
	}
}

if ( ! function_exists( 'mvweb_core_part_colours' ) ) {
	/**
	 * Own colours of the head parts of a block: the heading, the kicker, the number, the label, the price.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props Props of the row.
	 *
	 * @return array<string,array{bg:string,ink:string}> Part => colour and the text that reads on it; only the parts the editor coloured.
	 */
	function mvweb_core_part_colours( array $props ) {
		$colours = array();

		foreach ( array( 'head', 'kicker', 'number', 'label', 'price' ) as $part ) {
			$colour = mvweb_core_colour_css( isset( $props[ $part . '_color' ] ) ? $props[ $part . '_color' ] : '' );

			if ( $colour ) {
				$colours[ $part ] = array(
					'bg'  => $colour['bg'],
					'ink' => $colour['ink'],
				);
			}
		}

		return $colours;
	}
}
