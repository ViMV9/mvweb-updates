<?php
/**
 * The question mark beside the wholesale price: a window with the terms of the wholesale price, written in the Customizer.
 *
 * @package MVweb_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_wholesale_info' ) ) {
	/**
	 * The terms of the wholesale price, cleaned of unsafe markup; empty when the mark is off, the wholesale prices are off or the text is empty.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_wholesale_info() {
		static $html = null;

		if ( null === $html ) {
			$text = trim( (string) get_theme_mod( 'mvweb_wholesale_info', '' ) );
			$on   = get_theme_mod( 'mvweb_wholesale', false ) && get_theme_mod( 'mvweb_wholesale_info_show', false );
			$html = $on && '' !== $text ? wpautop( wp_kses_post( $text ) ) : '';
		}

		return $html;
	}
}

if ( ! function_exists( 'mvweb_core_wholesale_info_fields' ) ) {
	/**
	 * The switch of the mark and the text of the window, after the caption of the wholesale price.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Customizer Kit.
	 *
	 * @return void
	 */
	function mvweb_core_wholesale_info_fields( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'toggle',
					'settings'    => 'mvweb_wholesale_info_show',
					'section'     => 'mvweb_cz_catalog_product',
					'label'       => __( 'Question mark beside the wholesale price', 'mvweb-core' ),
					'description' => __( 'A button that opens a window with the terms of the wholesale price. It shows beside the caption of the wholesale price in the cards and on the item page.', 'mvweb-core' ),
					'default'     => false,
					'required'    => array(
						array(
							'setting'  => 'mvweb_wholesale',
							'operator' => '==',
							'value'    => true,
						),
					),
				),
				array(
					'type'              => 'textarea',
					'settings'          => 'mvweb_wholesale_info',
					'section'           => 'mvweb_cz_catalog_product',
					'label'             => __( 'Terms of the wholesale price', 'mvweb-core' ),
					'description'       => __( 'The text of the window. Paragraphs, lists, links and bold text in HTML are kept. Empty text hides the button.', 'mvweb-core' ),
					'default'           => '',
					'sanitize_callback' => 'wp_kses_post',
					'required'          => array(
						array(
							'setting'  => 'mvweb_wholesale',
							'operator' => '==',
							'value'    => true,
						),
						array(
							'setting'  => 'mvweb_wholesale_info_show',
							'operator' => '==',
							'value'    => true,
						),
					),
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_wholesale_info_fields' );

if ( ! function_exists( 'mvweb_core_wholesale_info_window' ) ) {
	/**
	 * Print the window once at the end of the page; the theme draws it.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_wholesale_info_window() {
		if ( is_admin() || '' === mvweb_core_wholesale_info() ) {
			return;
		}

		get_template_part( 'template-parts/wholesale-info', null, array( 'html' => mvweb_core_wholesale_info() ) );
	}
}
add_action( 'wp_footer', 'mvweb_core_wholesale_info_window', 6 );
