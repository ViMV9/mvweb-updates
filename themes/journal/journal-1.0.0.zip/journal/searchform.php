<?php
/**
 * Search form: the field of the header in the look of a page, with an id of its own on every copy.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

echo mvweb_theme_search_field( 'page' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts, or by the renderer of the plugin.
