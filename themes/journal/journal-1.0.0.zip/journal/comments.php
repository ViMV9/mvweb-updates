<?php
/**
 * Comments under a blog entry: the list with the replies and the form.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( post_password_required() ) {
	return;
}

$mvweb_required  = (bool) get_option( 'require_name_email' );
$mvweb_commenter = wp_get_current_commenter();
$mvweb_field     = static function ( $name, $label, $type, $autocomplete ) use ( $mvweb_required, $mvweb_commenter ) {
	return sprintf(
		'<p class="mvweb-t-comments__field"><label class="mvweb-t-comments__label" for="%1$s">%2$s</label><input class="mvweb-t-input" id="%1$s" name="%1$s" type="%3$s" value="%4$s" autocomplete="%5$s"%6$s></p>',
		esc_attr( $name ),
		esc_html( $label ),
		esc_attr( $type ),
		esc_attr( isset( $mvweb_commenter[ 'author' === $name ? 'comment_author' : 'comment_author_' . $name ] ) ? $mvweb_commenter[ 'author' === $name ? 'comment_author' : 'comment_author_' . $name ] : '' ),
		esc_attr( $autocomplete ),
		$mvweb_required ? ' required' : ''
	);
};
$mvweb_consent   = mvweb_core_blog_comment_consent();
$mvweb_walker    = new class() extends Walker_Comment {
	/**
	 * Open the list of replies under a comment.
	 *
	 * @param string $output Markup so far.
	 * @param int    $depth  Depth of the comment.
	 * @param array  $args   Arguments of the list.
	 *
	 * @return void
	 */
	public function start_lvl( &$output, $depth = 0, $args = array() ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- Signature of the parent method.
		$output .= '<ol class="mvweb-t-comments__list mvweb-t-comments__list--children">';
	}

	/**
	 * Close the list of replies under a comment.
	 *
	 * @param string $output Markup so far.
	 * @param int    $depth  Depth of the comment.
	 * @param array  $args   Arguments of the list.
	 *
	 * @return void
	 */
	public function end_lvl( &$output, $depth = 0, $args = array() ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- Signature of the parent method.
		$output .= '</ol>';
	}
};
$mvweb_item      = static function ( $comment, $args, $depth ) {
	$mvweb_by_author = $comment->user_id && (int) get_post_field( 'post_author', $comment->comment_post_ID ) === (int) $comment->user_id;
	$mvweb_name      = (string) get_comment_author( $comment );
	$mvweb_avatar    = get_avatar(
		$comment,
		64,
		'',
		'',
		array(
			'class'         => 'mvweb-t-avatar',
			'force_display' => false,
			'loading'       => 'lazy',
		)
	);
	$mvweb_reply     = get_comment_reply_link(
		array_merge(
			$args,
			array(
				'add_below'  => 'div-comment',
				'depth'      => $depth,
				'max_depth'  => $args['max_depth'],
				'reply_text' => __( 'Reply', 'journal' ),
				'before'     => '',
				'after'      => '',
			)
		),
		$comment
	);
	?>
	<li class="mvweb-t-comment" id="comment-<?php echo (int) $comment->comment_ID; ?>">
		<article class="mvweb-t-comment__box" id="div-comment-<?php echo (int) $comment->comment_ID; ?>">
			<?php if ( $mvweb_avatar ) : ?>
				<?php echo $mvweb_avatar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag. ?>
			<?php else : ?>
				<span class="mvweb-t-avatar" aria-hidden="true"><?php echo esc_html( function_exists( 'mb_substr' ) ? mb_substr( $mvweb_name, 0, 1 ) : substr( $mvweb_name, 0, 1 ) ); ?></span>
			<?php endif; ?>
			<p class="mvweb-t-comment__head">
				<b><?php echo esc_html( $mvweb_name ); ?></b>
				<small>
					<?php if ( $mvweb_by_author ) : ?>
						<?php esc_html_e( 'Author', 'journal' ); ?> ·
					<?php endif; ?>
					<time datetime="<?php echo esc_attr( get_comment_date( 'c', $comment ) ); ?>"><?php echo esc_html( get_comment_date( '', $comment ) ); ?></time>
				</small>
			</p>
			<?php if ( '0' === (string) $comment->comment_approved ) : ?>
				<p class="mvweb-t-comment__note"><?php esc_html_e( 'Your comment is awaiting moderation.', 'journal' ); ?></p>
			<?php endif; ?>
			<div class="mvweb-t-comment__text"><?php comment_text( $comment ); ?></div>
			<?php if ( $mvweb_reply ) : ?>
				<?php echo str_replace( 'comment-reply-link', 'comment-reply-link mvweb-t-comment__reply', $mvweb_reply ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the link. ?>
			<?php endif; ?>
		</article>
	<?php
};
$mvweb_reorder = static function ( $fields ) {
	$text = isset( $fields['comment'] ) ? array( 'comment' => $fields['comment'] ) : array();

	return $text + $fields;
};
$mvweb_cookies = static function ( $field ) {
	return (string) preg_replace( '#<p class="comment-form-cookies-consent">(<input[^>]*>)\s*<label[^>]*>(.*?)</label></p>#s', '<label class="mvweb-t-comments__check">$1<span>$2</span></label>', $field );
};
$mvweb_count   = (int) get_comments_number();
?>
<section class="mvweb-t-section mvweb-t-section--surface mvweb-t-comments" id="comments">
	<div class="mvweb-t-container">
		<div class="mvweb-t-comments__inner">
			<?php if ( have_comments() ) : ?>
				<div class="mvweb-t-section__head">
					<div>
						<div class="mvweb-t-h2" role="heading" aria-level="2">
							<?php
							/* translators: %s: number of comments. */
							echo esc_html( sprintf( __( 'Comments · %s', 'journal' ), number_format_i18n( $mvweb_count ) ) );
							?>
						</div>
					</div>
				</div>

				<ol class="mvweb-t-comments__list">
					<?php
					wp_list_comments(
						array(
							'walker'   => $mvweb_walker,
							'callback' => $mvweb_item,
							'style'    => 'ol',
						)
					);
					?>
				</ol>

				<?php
				the_comments_navigation(
					array(
						'class' => 'mvweb-t-comments__nav',
					)
				);
				?>
			<?php endif; ?>

			<?php
			if ( comments_open() ) {
				add_filter( 'comment_form_fields', $mvweb_reorder );
				add_filter( 'comment_form_field_cookies', $mvweb_cookies );

				comment_form(
					array(
						'class_form'           => 'mvweb-t-comments__form',
						'class_submit'         => 'mvweb-t-btn',
						'title_reply'          => __( 'Leave a comment', 'journal' ),
						'title_reply_before'   => '<div id="reply-title" class="mvweb-t-comments__reply-title mvweb-t-h4" role="heading" aria-level="2">',
						'title_reply_after'    => '</div>',
						'cancel_reply_before'  => ' <small>',
						'cancel_reply_after'   => '</small>',
						'comment_notes_before' => '',
						'comment_notes_after'  => '',
						'logged_in_as'         => '',
						'label_submit'         => __( 'Send', 'journal' ),
						'submit_button'        => '<button name="%1$s" type="submit" id="%2$s" class="%3$s">%4$s</button>',
						'submit_field'         => ( '' !== $mvweb_consent ? '<label class="mvweb-t-comments__check"><input type="checkbox" name="mvweb_comment_agree" value="1" required><span>' . str_replace( '%', '%%', $mvweb_consent ) . '</span></label>' : '' ) . '%1$s %2$s',
						'comment_field'        => sprintf(
							'<p class="mvweb-t-comments__field"><label class="mvweb-t-comments__label" for="comment">%s</label><textarea class="mvweb-t-input" id="comment" name="comment" rows="4" required></textarea></p>',
							esc_html__( 'Comment', 'journal' )
						),
						'fields'               => array(
							'author' => '<div class="mvweb-t-comments__row">' . $mvweb_field( 'author', __( 'Name', 'journal' ), 'text', 'name' ) . $mvweb_field( 'email', __( 'E-mail, not published', 'journal' ), 'email', 'email' ) . '</div>',
						),
					)
				);

				remove_filter( 'comment_form_fields', $mvweb_reorder );
				remove_filter( 'comment_form_field_cookies', $mvweb_cookies );
			}
			?>
		</div>
	</div>
</section>
