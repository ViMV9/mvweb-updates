<?php
/**
 * Design helpers the templates of the theme call.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_header_class' ) ) {
	/**
	 * Class list for the header element.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_theme_header_class() {
		$classes = array( 'mvweb-t-header' );

		if ( is_singular( 'page' ) && has_post_thumbnail() ) {
			$classes[] = 'mvweb-t-header--overlay';
		}

		/**
		 * Filter the header class list.
		 *
		 * @since 0.1.0
		 *
		 * @param string[] $classes Class names.
		 */
		$classes = (array) apply_filters( 'mvweb_theme_header_class', $classes );

		return implode( ' ', array_filter( array_map( 'sanitize_html_class', $classes ) ) );
	}
}

if ( ! function_exists( 'mvweb_theme_pagination' ) ) {
	/**
	 * Print pagination in the theme's own markup.
	 *
	 * @since 0.1.0
	 *
	 * @param array $args Optional. Arguments passed to paginate_links(). The
	 *                    'type' key is ignored — this function needs an array.
	 *
	 * @return void
	 */
	function mvweb_theme_pagination( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'mid_size'  => 1,
				'end_size'  => 1,
				'prev_text' => mvweb_theme_icon( 'chevron-left', array( 'class' => 'mvweb-t-icon--sm' ) ) . '<span class="screen-reader-text">' . esc_html__( 'Previous page', 'journal' ) . '</span>',
				'next_text' => mvweb_theme_icon( 'chevron-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '<span class="screen-reader-text">' . esc_html__( 'Next page', 'journal' ) . '</span>',
			)
		);

		$args['type'] = 'array';

		$links = paginate_links( $args );

		if ( empty( $links ) ) {
			return;
		}

		$map = array(
			'class="prev page-numbers"' => 'class="mvweb-t-pagination__item" title="' . esc_attr__( 'Previous page', 'journal' ) . '"',
			'class="next page-numbers"' => 'class="mvweb-t-pagination__item" data-next title="' . esc_attr__( 'Next page', 'journal' ) . '"',
			'page-numbers dots'         => 'mvweb-t-pagination__item mvweb-t-pagination__item--dots',
			'page-numbers current'      => 'mvweb-t-pagination__item',
			'page-numbers'              => 'mvweb-t-pagination__item',
		);

		printf(
			'<nav class="mvweb-t-pagination" aria-label="%s">',
			esc_attr__( 'Pagination', 'journal' )
		);

		foreach ( $links as $link ) {
			echo str_replace( array_keys( $map ), array_values( $map ), $link ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup comes from paginate_links(), which escapes it.
		}

		echo '</nav>';
	}
}

if ( ! function_exists( 'mvweb_theme_logo' ) ) {
	/**
	 * Print the site logo: the uploaded image, or the sign with the name and the tagline of the site.
	 *
	 * @since 0.1.0
	 *
	 * @param array $args Optional. 'class' — extra classes on the link,
	 *                    'tag' — 'a' (default) or 'span' for the copies outside the header,
	 *                    'lazy' — true for copies below the first screen,
	 *                    'heading' — true when the logo is the h1 of the page:
	 *                    the name is the h1, a logo of a picture alone is wrapped in it.
	 *
	 * @return void
	 */
	function mvweb_theme_logo( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'class'   => '',
				'tag'     => 'a',
				'lazy'    => false,
				'heading' => false,
			)
		);

		$light = (int) get_theme_mod( 'custom_logo' );
		$dark  = (int) get_theme_mod( 'mvweb_logo_dark' );
		$light = wp_attachment_is_image( $light ) ? $light : 0;
		$dark  = wp_attachment_is_image( $dark ) ? $dark : 0;
		$sign  = ( $light || $dark ) && 'mark' === mvweb_cz_get( 'mvweb_logo_layout', 'image' );
		$text  = ! $light && ! $dark;
		$alt   = $sign ? '' : get_bloginfo( 'name' );

		$tag        = 'span' === $args['tag'] ? 'span' : 'a';
		$heading    = ! empty( $args['heading'] ) && 'a' === $tag;
		$wrap       = $heading && ! $sign && ! $text;
		$class      = trim( 'mvweb-t-logo ' . ( $sign ? 'mvweb-t-logo--sign ' : '' ) . $args['class'] );
		$attributes = 'a' === $tag ? sprintf( ' href="%s" rel="home"', esc_url( home_url( '/' ) ) ) : '';
		$box        = 'span' === $tag ? 'span' : 'div';

		if ( $wrap ) {
			echo '<h1 class="mvweb-t-logo-h1">';
		}

		printf( '<%1$s class="%2$s"%3$s>', esc_html( $tag ), esc_attr( $class ), $attributes ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Attributes escaped above.

		if ( $light && $dark && $light !== $dark ) {
			echo mvweb_theme_logo_image( $light, 'mvweb-t-logo__img mvweb-t-logo__img--light', $args['lazy'], $alt ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
			echo mvweb_theme_logo_image( $dark, 'mvweb-t-logo__img mvweb-t-logo__img--dark', $args['lazy'], $alt ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
		} elseif ( ! $text ) {
			echo mvweb_theme_logo_image( $light ? $light : $dark, 'mvweb-t-logo__img', $args['lazy'], $alt ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
		}

		if ( $sign || $text ) {
			$name    = $sign ? trim( (string) mvweb_cz_get( 'mvweb_logo_name', '' ) ) : '';
			$name    = '' !== $name ? $name : get_bloginfo( 'name' );
			$tagline = trim( (string) mvweb_cz_get( 'mvweb_logo_tagline', '' ) );
			$tagline = '' !== $tagline || $sign ? $tagline : get_bloginfo( 'description' );

			if ( $text ) {
				$words = preg_split( '/\s+/u', trim( $name ), 2, PREG_SPLIT_NO_EMPTY );
				$mark  = '';

				foreach ( is_array( $words ) ? $words : array( $name ) as $word ) {
					$mark .= mb_substr( $word, 0, 1 );
				}

				printf( '<span class="mvweb-t-logo__mark" aria-hidden="true">%s</span>', esc_html( $mark ) );
			}

			printf( '<%1$s class="mvweb-t-logo__text"><%2$s class="mvweb-t-logo__name">%3$s</%2$s>', esc_html( $heading ? 'div' : $box ), esc_html( $heading ? 'h1' : 'span' ), esc_html( $name ) );

			if ( '' !== $tagline ) {
				printf( '<span class="mvweb-t-logo__tag">%s</span>', esc_html( $tagline ) );
			}

			printf( '</%s>', esc_html( $heading ? 'div' : $box ) );
		}

		printf( '</%s>', esc_html( $tag ) );

		if ( $wrap ) {
			echo '</h1>';
		}
	}
}

if ( ! function_exists( 'mvweb_theme_logo_image' ) ) {
	/**
	 * One logo image, with a sizes value that matches how big it is shown.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $id      Attachment id.
	 * @param string $classes Class list.
	 * @param bool   $lazy    Whether the copy sits below the first screen.
	 * @param string $alt     Alternative text; empty when the name is printed
	 *                        next to the image.
	 *
	 * @return string
	 */
	function mvweb_theme_logo_image( $id, $classes, $lazy, $alt ) {
		$attr = array(
			'class'         => $classes,
			'alt'           => $alt,
			'loading'       => $lazy ? 'lazy' : false,
			'fetchpriority' => $lazy ? false : 'auto',
		);

		$image = wp_get_attachment_image_src( $id, 'full' );

		if ( $image && $image[2] > 0 ) {
			$ratio         = $image[1] / $image[2];
			$attr['sizes'] = sprintf(
				'(max-width: 1000px) %dpx, %dpx',
				ceil( (int) mvweb_cz_get( 'mvweb_logo_height_mobile', 40 ) * $ratio ),
				ceil( (int) mvweb_cz_get( 'mvweb_logo_height', 40 ) * $ratio )
			);
		}

		return wp_get_attachment_image( $id, 'full', false, $attr );
	}
}

if ( ! function_exists( 'mvweb_theme_drop_breadcrumbs_block_style' ) ) {
	/**
	 * Drop the stylesheet the breadcrumbs block enqueues when it renders.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_drop_breadcrumbs_block_style() {
		wp_deregister_style( 'wp-block-breadcrumbs' );
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_theme_drop_breadcrumbs_block_style', 20 );

if ( ! function_exists( 'mvweb_theme_follow' ) ) {
	/**
	 * Links to the social networks in one of the looks of the design: icons, brand squares, buttons with names, a list.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,string>> $socials Network id => url and label.
	 * @param string                             $style   icons, brand, buttons or list.
	 * @param int                                $max     How many to show; the rest open the window of the subscription with «+N».
	 * @param string                             $extra   Extra class of the list.
	 *
	 * @return void
	 */
	function mvweb_theme_follow( array $socials, $style, $max = 0, $extra = '' ) {
		if ( empty( $socials ) ) {
			return;
		}

		$rest    = $max > 0 ? count( $socials ) - $max : 0;
		$socials = $max > 0 ? array_slice( $socials, 0, $max, true ) : $socials;
		$named   = in_array( $style, array( 'buttons', 'list' ), true );
		?>
		<div class="<?php echo esc_attr( trim( 'mvweb-t-follow mvweb-t-follow--' . $style . ' ' . $extra ) ); ?>">
			<?php foreach ( $socials as $mvweb_id => $mvweb_link ) : ?>
				<a href="<?php echo esc_url( $mvweb_link['url'] ); ?>" data-brand="<?php echo esc_attr( mvweb_core_social_icon( $mvweb_id ) ); ?>" rel="noopener" target="_blank"<?php echo $named ? '' : ' title="' . esc_attr( $mvweb_link['label'] ) . '"'; ?>>
					<?php if ( 'list' === $style ) : ?>
						<span class="mvweb-t-follow__ico"><?php echo mvweb_theme_icon( mvweb_core_social_icon( $mvweb_id ), array( 'class' => 'mvweb-t-icon--brand' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
						<span class="mvweb-t-follow__name"><?php echo esc_html( $mvweb_link['label'] ); ?></span>
						<?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm mvweb-t-follow__go' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<?php else : ?>
						<?php echo mvweb_theme_icon( mvweb_core_social_icon( $mvweb_id ), array( 'class' => 'mvweb-t-icon--brand' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
						<span<?php echo $named ? '' : ' class="screen-reader-text"'; ?>><?php echo esc_html( $mvweb_link['label'] ); ?></span>
					<?php endif; ?>
				</a>
			<?php endforeach; ?>
			<?php if ( $rest > 0 && ! empty( mvweb_core_subscribe() ) ) : ?>
				<button class="mvweb-t-follow__more" type="button" popovertarget="mvweb-t-subpop" data-popover-trigger="mvweb-t-subpop" title="<?php esc_attr_e( 'All social networks', 'journal' ); ?>">
					+<?php echo esc_html( number_format_i18n( $rest ) ); ?>
					<span class="screen-reader-text"><?php esc_html_e( 'All social networks', 'journal' ); ?></span>
				</button>
			<?php endif; ?>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_meta_note' ) ) {
	/**
	 * The note about Meta under the social networks, when Instagram or Facebook is among them.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,string>> $socials Networks being shown.
	 *
	 * @return void
	 */
	function mvweb_theme_meta_note( array $socials ) {
		$note = mvweb_core_social_meta_note( $socials );

		if ( '' !== $note ) {
			printf( '<p class="mvweb-t-meta-note">%s</p>', esc_html( $note ) );
		}
	}
}

if ( ! function_exists( 'mvweb_theme_layout_open' ) ) {
	/**
	 * Open the text of a page and the room for the column of widgets beside it.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area  Area of widgets of the page.
	 * @param string $extra Classes of the layout added by the template.
	 *
	 * @return void
	 */
	function mvweb_theme_layout_open( $area, $extra = '' ) {
		$classes = array( 'mvweb-t-layout' );

		if ( mvweb_core_sidebar_on( $area ) ) {
			$classes[] = 'mvweb-t-layout--aside';
			$classes[] = 'mvweb-t-layout--' . mvweb_core_sidebar_side( $area );
		}

		if ( '' !== $extra ) {
			$classes[] = $extra;
		}

		printf( '<div class="mvweb-t-container"><div class="%s"><div class="mvweb-t-layout__main">', esc_attr( implode( ' ', $classes ) ) );
	}
}

if ( ! function_exists( 'mvweb_theme_layout_close' ) ) {
	/**
	 * Close the text of a page and print the column of widgets beside it.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area of widgets of the page.
	 *
	 * @return void
	 */
	function mvweb_theme_layout_close( $area ) {
		echo '</div>';

		if ( mvweb_core_sidebar_on( $area ) ) {
			get_template_part( 'template-parts/sidebar', null, array( 'area' => $area ) );
		}

		echo '</div></div>';
	}
}
