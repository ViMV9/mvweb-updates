<?php
/**
 * The menus as the theme draws them: the menu row with its dropdowns and mega menu, the menu of the drawer.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_menu_icon' ) ) {
	/**
	 * The icon of a menu item in its box, when the owner asked for icons.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $item_id   Menu item id.
	 * @param string $box_class Class of the box.
	 *
	 * @return string Escaped markup, empty when the item has no icon.
	 */
	function mvweb_theme_menu_icon( $item_id, $box_class ) {
		static $names = array();

		if ( ! get_theme_mod( 'mvweb_menu_icons', true ) ) {
			return '';
		}

		if ( ! isset( $names[ $item_id ] ) ) {
			$names[ $item_id ] = mvweb_core_menu_item_icon( $item_id );
		}

		if ( '' === $names[ $item_id ] ) {
			return '';
		}

		return '<span class="' . esc_attr( $box_class ) . '">' . mvweb_theme_icon( $names[ $item_id ] ) . '</span>';
	}
}

if ( ! function_exists( 'mvweb_theme_bar_nav' ) ) {
	/**
	 * The menu row: a link per item; an item with children gets a button beside it that opens a list or, when the item asks for it, the mega menu.
	 *
	 * @since 0.1.0
	 *
	 * @param string $location    Registered menu location.
	 * @param string $extra_class Class of the element that prints the menu.
	 *
	 * @return void
	 */
	function mvweb_theme_bar_nav( $location, $extra_class = '' ) {
		$tree = mvweb_core_menu_tree( $location );

		if ( empty( $tree[0] ) ) {
			return;
		}
		?>
		<nav class="<?php echo esc_attr( trim( 'mvweb-t-nav ' . $extra_class ) ); ?>" aria-label="<?php esc_attr_e( 'Primary menu', 'journal' ); ?>">
			<ul class="mvweb-t-nav__list">
				<?php foreach ( $tree[0] as $mvweb_top ) : ?>
					<?php
					$mvweb_has  = ! empty( $tree[ $mvweb_top->ID ] );
					$mvweb_mega = $mvweb_has && mvweb_core_menu_item_is_mega( $mvweb_top->ID );
					$mvweb_sub  = 'mvweb-t-sub-' . $mvweb_top->ID;
					?>
					<li class="mvweb-t-nav__item<?php echo $mvweb_mega ? ' mvweb-t-nav__item--mega' : ''; ?><?php echo esc_attr( mvweb_core_menu_classes( $mvweb_top ) ); ?>"<?php echo $mvweb_has ? ' data-nav-item' : ''; ?>>
						<a class="mvweb-t-nav__link" <?php echo mvweb_core_menu_href( $mvweb_top->url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped attributes. ?><?php echo mvweb_core_menu_current( $mvweb_top ) ? ' aria-current="page"' : ''; ?>>
							<?php echo mvweb_theme_menu_icon( $mvweb_top->ID, 'mvweb-t-nav__icon' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
							<?php echo esc_html( $mvweb_top->title ); ?>
						</a>
						<?php if ( $mvweb_has ) : ?>
							<?php
							/* translators: %s: name of the menu item. */
							$mvweb_open = sprintf( __( 'Open the section “%s”', 'journal' ), $mvweb_top->title );
							?>
							<button class="mvweb-t-nav__toggle" type="button" data-nav-link aria-expanded="false" aria-controls="<?php echo esc_attr( $mvweb_sub ); ?>" title="<?php echo esc_attr( $mvweb_open ); ?>">
								<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
								<span class="screen-reader-text"><?php echo esc_html( $mvweb_open ); ?></span>
							</button>
							<?php
							if ( $mvweb_mega ) {
								echo mvweb_core_mega_html( $location, $mvweb_top, $tree, 'mvweb_theme_mega_panel' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from the escaped markup of mvweb_theme_mega_panel().
							} else {
								mvweb_theme_dropdown( $tree, $mvweb_top, $mvweb_sub );
							}
							?>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		</nav>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_dropdown' ) ) {
	/**
	 * The list under an item of the menu row: its children and, when the item leads somewhere, the link to all of it.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,WP_Post[]> $tree Items grouped by parent.
	 * @param WP_Post              $item The item of the row.
	 * @param string               $id   Id of the list.
	 *
	 * @return void
	 */
	function mvweb_theme_dropdown( array $tree, $item, $id ) {
		?>
		<ul class="mvweb-t-ddown" id="<?php echo esc_attr( $id ); ?>" data-nav-sub>
			<?php foreach ( $tree[ $item->ID ] as $mvweb_child ) : ?>
				<li><a <?php echo mvweb_core_menu_href( $mvweb_child->url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped attributes. ?><?php echo mvweb_core_menu_current( $mvweb_child ) ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $mvweb_child->title ); ?></a></li>
			<?php endforeach; ?>
			<?php if ( mvweb_core_menu_url_is_real( $item->url ) ) : ?>
				<li class="mvweb-t-ddown__all">
					<a href="<?php echo esc_url( $item->url ); ?>">
						<?php esc_html_e( 'All articles of the section', 'journal' ); ?>
						<?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					</a>
				</li>
			<?php endif; ?>
		</ul>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_mega_entries' ) ) {
	/**
	 * What a tab of the mega menu shows: the items under it in the menu, else the most read articles of the category it leads to.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,WP_Post[]> $tree  Items grouped by parent.
	 * @param WP_Post              $tab   Menu item of the tab.
	 * @param int                  $count How many.
	 *
	 * @return array<int,array{url:string,title:string,image:int}>
	 */
	function mvweb_theme_mega_entries( array $tree, $tab, $count ) {
		$entries = array();

		if ( ! empty( $tree[ $tab->ID ] ) ) {
			foreach ( array_slice( mvweb_core_mega_cards( $tree, $tab->ID ), 0, $count ) as $card ) {
				$entries[] = array(
					'url'   => (string) $card['item']->url,
					'title' => (string) $card['item']->title,
					'image' => (int) $card['image'],
				);
			}

			return $entries;
		}

		if ( 'taxonomy' !== $tab->type || 'category' !== $tab->object ) {
			return $entries;
		}

		$ids = mvweb_core_views_period_ids(
			'month',
			array(
				'category' => (int) $tab->object_id,
				'count'    => $count,
			)
		);

		if ( $ids ) {
			_prime_post_caches( $ids, false, true );
		}

		foreach ( $ids as $id ) {
			$entries[] = array(
				'url'   => (string) get_permalink( $id ),
				'title' => get_the_title( $id ),
				'image' => (int) get_post_thumbnail_id( $id ),
			);
		}

		return $entries;
	}
}

if ( ! function_exists( 'mvweb_theme_mega_card' ) ) {
	/**
	 * One card of the mega menu: the picture and the title.
	 *
	 * @since 0.1.0
	 *
	 * @param array{url:string,title:string,image:int} $entry Entry.
	 * @param bool                                     $lead  Whether it is the large card of the look «Lead article».
	 *
	 * @return void
	 */
	function mvweb_theme_mega_card( array $entry, $lead = false ) {
		?>
		<a class="mvweb-t-mcard<?php echo $lead ? ' mvweb-t-mcard--lead' : ''; ?>" href="<?php echo esc_url( $entry['url'] ); ?>">
			<?php mvweb_theme_mega_cover( $entry['image'], $lead ? '' : 'mvweb-t-cover--wide' ); ?>
			<span class="mvweb-t-mcard__title"><?php echo esc_html( $entry['title'] ); ?></span>
		</a>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_mega_cover' ) ) {
	/**
	 * The picture of a card of the menus, or an empty plate of the same size.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $image    Attachment id.
	 * @param string $modifier Class of the shape.
	 *
	 * @return void
	 */
	function mvweb_theme_mega_cover( $image, $modifier ) {
		$has = $image && wp_attachment_is_image( $image );
		?>
		<span class="<?php echo esc_attr( trim( 'mvweb-t-cover ' . $modifier . ( $has ? '' : ' mvweb-t-cover--none' ) ) ); ?>">
			<?php
			if ( $has ) {
				echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
					$image,
					'mvweb_card',
					false,
					array(
						'alt'      => '',
						'loading'  => 'lazy',
						'decoding' => 'async',
						'sizes'    => '(min-width: 1024px) 280px, 60vw',
					)
				);
			}
			?>
		</span>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_mega_panel' ) ) {
	/**
	 * The mega menu of an item in the chosen look: the children as tabs with their cards, or as columns in the fifth look.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post              $item Top-level menu item.
	 * @param array<int,WP_Post[]> $tree Items grouped by parent.
	 *
	 * @return void
	 */
	function mvweb_theme_mega_panel( $item, array $tree ) {
		$looks = array(
			'1' => 'tabs',
			'2' => 'top',
			'3' => 'lead',
			'4' => 'dark',
			'5' => 'cols',
		);
		$view  = mvweb_core_area_view( 'mega' );
		$look  = isset( $looks[ $view ] ) ? $looks[ $view ] : 'tabs';
		$tabs  = $tree[ $item->ID ];
		?>
		<div class="mvweb-t-mega-wrap" id="<?php echo esc_attr( 'mvweb-t-sub-' . $item->ID ); ?>" data-nav-sub>
			<div class="mvweb-t-container">
				<?php if ( 'cols' === $look ) : ?>
					<div class="mvweb-t-mega mvweb-t-mega--cols">
						<div class="mvweb-t-mega__cols">
							<?php foreach ( $tabs as $mvweb_tab ) : ?>
								<?php $mvweb_entries = mvweb_theme_mega_entries( $tree, $mvweb_tab, 3 ); ?>
								<div class="mvweb-t-mega__col">
									<a class="mvweb-t-mega__colname" <?php echo mvweb_core_menu_href( $mvweb_tab->url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped attributes. ?>>
										<?php echo esc_html( $mvweb_tab->title ); ?>
										<?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
									</a>
									<?php if ( ! empty( $mvweb_entries ) ) : ?>
										<?php mvweb_theme_mega_cover( $mvweb_entries[0]['image'], 'mvweb-t-cover--wide' ); ?>
										<ul class="mvweb-t-mega__links">
											<?php foreach ( $mvweb_entries as $mvweb_entry ) : ?>
												<li><a href="<?php echo esc_url( $mvweb_entry['url'] ); ?>"><?php echo esc_html( $mvweb_entry['title'] ); ?></a></li>
											<?php endforeach; ?>
										</ul>
									<?php endif; ?>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				<?php else : ?>
					<div class="mvweb-t-mega mvweb-t-mega--<?php echo esc_attr( $look ); ?>" data-tabs>
						<div class="mvweb-t-mega__tabs" role="tablist" aria-label="<?php echo esc_attr( $item->title ); ?>"<?php echo 'top' === $look ? '' : ' aria-orientation="vertical"'; ?>>
							<?php foreach ( $tabs as $mvweb_index => $mvweb_tab ) : ?>
								<button type="button" data-tab="<?php echo esc_attr( (string) $mvweb_tab->ID ); ?>" aria-selected="<?php echo 0 === $mvweb_index ? 'true' : 'false'; ?>">
									<span><?php echo esc_html( $mvweb_tab->title ); ?></span>
									<?php echo mvweb_theme_icon( 'chevron-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
								</button>
							<?php endforeach; ?>
						</div>
						<div class="mvweb-t-mega__panels">
							<?php foreach ( $tabs as $mvweb_index => $mvweb_tab ) : ?>
								<?php $mvweb_entries = mvweb_theme_mega_entries( $tree, $mvweb_tab, 'lead' === $look ? 6 : 4 ); ?>
								<div class="mvweb-t-mega__panel" data-tabpanel="<?php echo esc_attr( (string) $mvweb_tab->ID ); ?>"<?php echo 0 === $mvweb_index ? '' : ' hidden'; ?>>
									<div class="mvweb-t-mega__phead">
										<span><?php echo esc_html( $mvweb_tab->title ); ?></span>
										<?php if ( mvweb_core_menu_url_is_real( $mvweb_tab->url ) ) : ?>
											<a class="mvweb-t-section__more" href="<?php echo esc_url( $mvweb_tab->url ); ?>">
												<?php esc_html_e( 'All articles of the section', 'journal' ); ?>
												<?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
											</a>
										<?php endif; ?>
									</div>
									<?php if ( 'lead' === $look && ! empty( $mvweb_entries ) ) : ?>
										<div class="mvweb-t-mega__lead">
											<?php mvweb_theme_mega_card( $mvweb_entries[0], true ); ?>
											<?php if ( count( $mvweb_entries ) > 1 ) : ?>
												<ul class="mvweb-t-mega__links">
													<?php foreach ( array_slice( $mvweb_entries, 1 ) as $mvweb_entry ) : ?>
														<li><a href="<?php echo esc_url( $mvweb_entry['url'] ); ?>"><?php echo esc_html( $mvweb_entry['title'] ); ?></a></li>
													<?php endforeach; ?>
												</ul>
											<?php endif; ?>
										</div>
									<?php elseif ( ! empty( $mvweb_entries ) ) : ?>
										<div class="mvweb-t-mega__cards">
											<?php foreach ( $mvweb_entries as $mvweb_entry ) : ?>
												<?php mvweb_theme_mega_card( $mvweb_entry ); ?>
											<?php endforeach; ?>
										</div>
									<?php endif; ?>
								</div>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_drawer_list' ) ) {
	/**
	 * A list of the drawer: an item with children folds into a disclosure the browser opens, closes and announces itself; a category shows its number of articles.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,WP_Post[]> $tree      Items grouped by parent.
	 * @param int                  $parent_id Id of the parent item.
	 *
	 * @return void
	 */
	function mvweb_theme_drawer_list( array $tree, $parent_id ) {
		$top = 0 === $parent_id;
		?>
		<ul class="<?php echo $top ? 'mvweb-t-drawer__list' : 'mvweb-t-drawer__subs'; ?>">
			<?php foreach ( $tree[ $parent_id ] as $mvweb_item ) : ?>
				<?php
				$mvweb_kids  = $top && ! empty( $tree[ $mvweb_item->ID ] );
				$mvweb_count = $top ? mvweb_core_menu_term_count( $mvweb_item ) : null;
				?>
				<li class="mvweb-t-drawer__item<?php echo esc_attr( mvweb_core_menu_classes( $mvweb_item ) ); ?>">
					<?php if ( ! $mvweb_kids ) : ?>
						<a class="<?php echo $top ? 'mvweb-t-drawer__link' : 'mvweb-t-drawer__sub'; ?>" <?php echo mvweb_core_menu_href( $mvweb_item->url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped attributes. ?><?php echo mvweb_core_menu_current( $mvweb_item ) ? ' aria-current="page"' : ''; ?>>
							<span class="mvweb-t-drawer__text"><?php echo esc_html( $mvweb_item->title ); ?></span>
							<?php if ( null !== $mvweb_count ) : ?>
								<small class="mvweb-t-drawer__count"><?php echo esc_html( number_format_i18n( $mvweb_count ) ); ?></small>
							<?php endif; ?>
						</a>
					<?php else : ?>
						<details class="mvweb-t-drawer__group">
							<summary class="mvweb-t-drawer__link">
								<span class="mvweb-t-drawer__text"><?php echo esc_html( $mvweb_item->title ); ?></span>
								<?php if ( null !== $mvweb_count ) : ?>
									<small class="mvweb-t-drawer__count"><?php echo esc_html( number_format_i18n( $mvweb_count ) ); ?></small>
								<?php endif; ?>
								<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm mvweb-t-drawer__arrow' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
							</summary>
							<div class="mvweb-t-drawer__open">
								<?php if ( mvweb_core_menu_url_is_real( $mvweb_item->url ) ) : ?>
									<a class="mvweb-t-drawer__all" href="<?php echo esc_url( $mvweb_item->url ); ?>">
										<?php esc_html_e( 'All articles of the section', 'journal' ); ?>
										<?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
									</a>
								<?php endif; ?>
								<?php mvweb_theme_drawer_list( $tree, $mvweb_item->ID ); ?>
							</div>
						</details>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_drawer_nav' ) ) {
	/**
	 * A menu location in the drawer.
	 *
	 * @since 0.1.0
	 *
	 * @param string $location Registered menu location.
	 *
	 * @return void
	 */
	function mvweb_theme_drawer_nav( $location ) {
		$tree = mvweb_core_menu_tree( $location );

		if ( ! empty( $tree[0] ) ) {
			mvweb_theme_drawer_list( $tree, 0 );
		}
	}
}

if ( ! function_exists( 'mvweb_theme_mega_cards' ) ) {
	/**
	 * The look "Lead article and list" shows six cards, the others four.
	 *
	 * @since 0.1.0
	 *
	 * @param int $limit Cards.
	 *
	 * @return int
	 */
	function mvweb_theme_mega_cards( $limit ) {
		return '3' === mvweb_core_area_view( 'mega' ) ? 6 : $limit;
	}
}
add_filter( 'mvweb_core_mega_cards', 'mvweb_theme_mega_cards' );

if ( ! function_exists( 'mvweb_theme_zone_html' ) ) {
	/**
	 * A zone as a string, so the wrapper of an empty one can be left out.
	 *
	 * @since 0.1.0
	 *
	 * @param string $zone Zone slug.
	 *
	 * @return string
	 */
	function mvweb_theme_zone_html( $zone ) {
		ob_start();
		mvweb_core_render_zone( $zone );

		return trim( (string) ob_get_clean() );
	}
}
