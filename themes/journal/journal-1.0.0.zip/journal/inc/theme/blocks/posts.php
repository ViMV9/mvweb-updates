<?php
/**
 * Block description: posts of the blog.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1'  => array(
			'label'  => __( 'First screen: lead and column', 'journal' ),
			'class'  => 'lead-a',
			'motion' => 'rise',
		),
		'2'  => array(
			'label'  => __( 'First screen: cover with text', 'journal' ),
			'class'  => 'lead-b',
			'motion' => 'rise',
		),
		'3'  => array(
			'label'  => __( 'First screen: no photo', 'journal' ),
			'class'  => 'lead-c',
			'motion' => 'rise',
		),
		'4'  => array(
			'label'  => __( 'First screen: lead and four', 'journal' ),
			'class'  => 'lead-d',
			'motion' => 'rise',
		),
		'5'  => array(
			'label'  => __( 'First screen: hello and search', 'journal' ),
			'class'  => 'lead-e',
			'motion' => 'rise',
		),
		'6'  => array(
			'label'  => __( 'Latest: grid', 'journal' ),
			'class'  => 'grid',
			'motion' => 'rise',
		),
		'7'  => array(
			'label'  => __( 'Latest: list with excerpts', 'journal' ),
			'class'  => 'rows',
			'motion' => 'rise',
		),
		'8'  => array(
			'label'  => __( 'Latest: cards on a band', 'journal' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
		'9'  => array(
			'label'  => __( 'Latest: feed by dates', 'journal' ),
			'class'  => 'feed',
			'motion' => 'rise',
		),
		'10' => array(
			'label'  => __( 'Latest: scrolling ribbon', 'journal' ),
			'class'  => 'rail',
			'motion' => 'rise',
		),
		'11' => array(
			'label'  => __( 'Most read: two columns', 'journal' ),
			'class'  => 'top-a',
			'motion' => 'rise',
		),
		'12' => array(
			'label'  => __( 'Most read: number and cover', 'journal' ),
			'class'  => 'top-b',
			'motion' => 'rise',
		),
		'13' => array(
			'label'  => __( 'Most read: dark band', 'journal' ),
			'class'  => 'top-c',
			'motion' => 'rise',
		),
		'14' => array(
			'label'  => __( 'Most read: tabs', 'journal' ),
			'class'  => 'top-d',
			'motion' => 'rise',
		),
		'15' => array(
			'label'  => __( 'Most read: first place large', 'journal' ),
			'class'  => 'top-e',
			'motion' => 'rise',
		),
		'16' => array(
			'label'  => __( 'Category band: head on the left', 'journal' ),
			'class'  => 'band-a',
			'motion' => 'rise',
		),
		'17' => array(
			'label'  => __( 'Category band: large and list', 'journal' ),
			'class'  => 'band-b',
			'motion' => 'rise',
		),
		'18' => array(
			'label'  => __( 'Category band: four columns', 'journal' ),
			'class'  => 'band-c',
			'motion' => 'rise',
		),
		'19' => array(
			'label'  => __( 'Category band: cover and titles', 'journal' ),
			'class'  => 'band-d',
			'motion' => 'rise',
		),
		'20' => array(
			'label'  => __( 'Category band: two categories', 'journal' ),
			'class'  => 'band-e',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'kicker'       => array( '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20' ),
		'title'        => array( '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20' ),
		'text'         => array( '5', '7', '11', '16' ),
		'source'       => array( '1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '15', '16', '17', '18', '19', '20' ),
		'period'       => array( '3', '11', '12', '13', '14', '15' ),
		'category_2'   => array( '20' ),
		'count'        => array( '6', '7', '8', '10', '11' ),
		'link_text'    => array( '6', '7', '8', '9', '10', '16', '17', '18', '19', '20' ),
		'link_url'     => array( '6', '7', '8', '9', '10', '16', '17', '18', '19', '20' ),
		'parts.kicker' => array( '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20' ),
		'parts.title'  => array( '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20' ),
		'parts.lead'   => array( '5', '7', '11', '16' ),
		'parts.chips'  => array( '16', '18' ),
		'parts.hint'   => array( '5' ),
		'parts.more'   => array( '6', '7', '8', '9', '10', '16', '17', '18', '19', '20' ),
	),
);
