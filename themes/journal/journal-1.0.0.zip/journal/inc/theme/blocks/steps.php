<?php
/**
 * Block description: stages, step by step.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Line with numbers', 'journal' ),
			'class'  => 'line',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Cards with a step plate', 'journal' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Timeline with side heading', 'journal' ),
			'class'  => 'timeline',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Pictures in cards', 'journal' ),
			'class'  => 'img',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Large numbers', 'journal' ),
			'class'  => 'big',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'items.image'      => array( '4' ),
		'item_parts.image' => array( '4' ),
	),
);
