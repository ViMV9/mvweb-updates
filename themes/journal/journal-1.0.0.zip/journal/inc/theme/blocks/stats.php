<?php
/**
 * Block description: figures of the journal.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Row with dividers', 'journal' ),
			'class'  => 'row',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Cards', 'journal' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Dark strip', 'journal' ),
			'class'  => 'dark',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Heading on the left', 'journal' ),
			'class'  => 'side',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'In a line between rules', 'journal' ),
			'class'  => 'line',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'items.icon'      => array(),
		'item_parts.icon' => array(),
	),
);
