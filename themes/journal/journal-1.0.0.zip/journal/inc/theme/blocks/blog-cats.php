<?php
/**
 * Block description: the categories of the blog.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Chips with counts', 'journal' ),
			'class'  => 'chips',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Tiles with icons', 'journal' ),
			'class'  => 'tiles',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Category and its articles', 'journal' ),
			'class'  => 'hubs',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Cards with subcategories', 'journal' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Index of subcategories', 'journal' ),
			'class'  => 'index',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'top_label' => array(),
		'posts'     => array( '3' ),
	),
);
