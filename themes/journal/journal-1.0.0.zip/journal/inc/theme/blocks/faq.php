<?php
/**
 * Block description: questions and answers.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Centred list', 'journal' ),
			'class'  => 'center',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Heading on the left', 'journal' ),
			'class'  => 'side',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Tiles with icons', 'journal' ),
			'class'  => 'tiles',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Numbered between rules', 'journal' ),
			'class'  => 'num',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Cards in two columns', 'journal' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'items.icon'       => array( '3' ),
		'item_parts.badge' => array( '3' ),
		'item_parts.num'   => array( '4' ),
		'open_first'       => array( '1', '2', '4', '5' ),
		'button_text'      => array( '2', '3' ),
		'button_url'       => array( '2', '3' ),
		'button_kind'      => array( '2' ),
		'parts.button'     => array( '2', '3' ),
	),
);
