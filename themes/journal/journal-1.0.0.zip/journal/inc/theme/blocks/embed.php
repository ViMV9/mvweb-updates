<?php
/**
 * Block description: a widget of another plugin, a player or a form.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Video in a frame 16:9', 'journal' ),
			'class'  => 'video',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Narrow form with numbers', 'journal' ),
			'class'  => 'numbered',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Strip with a form in a line', 'journal' ),
			'class'  => 'bar',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Dark: text and form', 'journal' ),
			'class'  => 'dark',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Backdrop with a ribbon', 'journal' ),
			'class'  => 'poll',
			'motion' => 'rise',
		),
	),
	'parts' => array(
		'ticker' => __( 'Running line', 'journal' ),
		'kicker' => __( 'Line above the heading', 'journal' ),
		'title'  => __( 'Heading', 'journal' ),
		'lead'   => __( 'Text under the heading', 'journal' ),
	),
	'only'  => array(
		'width'        => array( '1', '3', '4', '5' ),
		'ticker'       => array( '5' ),
		'parts.ticker' => array( '5' ),
	),
);
