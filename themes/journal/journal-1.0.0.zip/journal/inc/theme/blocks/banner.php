<?php
/**
 * Block description: wide banner.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Photo with text over it', 'journal' ),
			'class'  => 'photo',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Card on a colour', 'journal' ),
			'class'  => 'card',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Accent strip with a price', 'journal' ),
			'class'  => 'accent',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Dark with a running line', 'journal' ),
			'class'  => 'dark',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Partner material', 'journal' ),
			'class'  => 'partner',
			'motion' => 'rise',
		),
	),
	'parts' => array(
		'tag'     => __( 'Label', 'journal' ),
		'title'   => __( 'Heading', 'journal' ),
		'lead'    => __( 'Lead', 'journal' ),
		'prices'  => __( 'Prices', 'journal' ),
		'sale'    => __( 'Saving', 'journal' ),
		'until'   => __( 'Last day of the offer', 'journal' ),
		'button'  => __( 'Button', 'journal' ),
		'sticker' => __( 'Sticker', 'journal' ),
		'reel'    => __( 'Running line', 'journal' ),
	),
	'only'  => array(
		'image'         => array( '1', '2', '5' ),
		'image_side'    => array( '2' ),
		'image_size'    => array( '2' ),
		'button_kind'   => array(),
		'kicker_color'  => array(),
		'button2_text'  => array( '2' ),
		'button2_url'   => array( '2' ),
		'price_new'     => array( '3' ),
		'price_old'     => array( '3' ),
		'sale_label'    => array( '3' ),
		'sticker_num'   => array( '3' ),
		'sticker_text'  => array( '3' ),
		'ticker'        => array( '4' ),
		'advertiser'    => array( '5' ),
		'erid'          => array( '5' ),
		'parts.prices'  => array( '3' ),
		'parts.until'   => array( '3' ),
		'parts.sale'    => array( '3' ),
		'parts.sticker' => array( '3' ),
		'parts.reel'    => array( '4' ),
	),
);
