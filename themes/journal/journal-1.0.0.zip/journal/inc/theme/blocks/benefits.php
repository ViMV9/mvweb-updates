<?php
/**
 * Block description: why readers trust the journal.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Photo and card', 'journal' ),
			'class'  => 'card',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Points around the photo', 'journal' ),
			'class'  => 'around',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Groups in rows', 'journal' ),
			'class'  => 'groups',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Tiles', 'journal' ),
			'class'  => 'tiles',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Figures on the right', 'journal' ),
			'class'  => 'rows',
			'motion' => 'rise',
		),
	),
	'parts' => array(
		'title'      => __( 'Heading', 'journal' ),
		'media'      => __( 'Photo', 'journal' ),
		'card_icon'  => __( 'Card icon', 'journal' ),
		'card_title' => __( 'Card heading', 'journal' ),
		'lead'       => __( 'Lead', 'journal' ),
		'list'       => __( 'Points', 'journal' ),
	),
	'only'  => array(
		'image'             => array( '1', '2' ),
		'icon'              => array( '1' ),
		'card_title'        => array( '1' ),
		'items.icon'        => array( '2', '3', '4', '5' ),
		'items.group'       => array( '3' ),
		'items.image'       => array( '3' ),
		'items.figure'      => array( '5' ),
		'parts.media'       => array( '1', '2', '3' ),
		'parts.card_icon'   => array( '1' ),
		'parts.card_title'  => array( '1', '3' ),
		'item_parts.name'   => array( '2', '3', '4', '5' ),
		'item_parts.figure' => array( '5' ),
		'image_side'        => array(),
		'image_size'        => array(),
		'cards_bg'          => array( '1', '4' ),
		'cards_ink'         => array( '1', '4' ),
	),
);
