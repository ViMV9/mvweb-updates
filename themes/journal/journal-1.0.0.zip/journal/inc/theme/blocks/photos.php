<?php
/**
 * Block description: photographs with captions.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Mosaic of photos', 'journal' ),
			'class'  => 'mosaic',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Even grid', 'journal' ),
			'class'  => 'grid',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Scrolling rail', 'journal' ),
			'class'  => 'rail',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Columns of mixed height', 'journal' ),
			'class'  => 'cols',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Stage with thumbnails', 'journal' ),
			'class'  => 'stage',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'items.size'   => array( '1', '4' ),
		'items.url'    => array( '1', '2', '3', '4' ),
		'parts.thumbs' => array( '5' ),
	),
);
