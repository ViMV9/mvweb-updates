<?php
/**
 * Block description: two banners side by side.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Cards with a picture', 'journal' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Text over a cover', 'journal' ),
			'class'  => 'overlay',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Wide and narrow', 'journal' ),
			'class'  => 'wide',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Coloured plates', 'journal' ),
			'class'  => 'plates',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Sticker as a large figure', 'journal' ),
			'class'  => 'figure',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'title'                => array(),
		'head_color'           => array(),
		'kicker_color'         => array(),
		'parts.title'          => array(),
		'banners.kicker'       => array(),
		'banners.ticker'       => array(),
		'banners.image_2'      => array(),
		'banners.image_1'      => array( '1', '2', '3' ),
		'banners.icon'         => array( '1', '3' ),
		'banners.sticker'      => array( '5' ),
		'banners.sticker_note' => array( '5' ),
		'item_parts.kicker'    => array(),
		'item_parts.ticker'    => array(),
		'item_parts.pics'      => array( '1', '2', '3' ),
		'item_parts.sticker'   => array( '5' ),
	),
);
