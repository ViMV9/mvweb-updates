<?php
/**
 * Block description: two lists side by side.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Columns with marks', 'journal' ),
			'class'  => 'cols',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Tabs', 'journal' ),
			'class'  => 'tabs',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Comparison table', 'journal' ),
			'class'  => 'table',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Tinted cards', 'journal' ),
			'class'  => 'tinted',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Dark strip', 'journal' ),
			'class'  => 'dark',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'left_tab'         => array( '2' ),
		'right_tab'        => array( '2' ),
		'parts.divider'    => array(),
		'item_parts.count' => array( '2' ),
	),
);
