<?php
/**
 * Block description: the call to follow the site.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Strip with a form', 'journal' ),
			'class'  => 'strip',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Dark, in the centre', 'journal' ),
			'class'  => 'dark',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Card with a list', 'journal' ),
			'class'  => 'card',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Networks as tiles', 'journal' ),
			'class'  => 'tiles',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Line between rules', 'journal' ),
			'class'  => 'line',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'points'       => array( '3' ),
		'parts.points' => array( '3' ),
		'parts.form'   => array( '1', '2', '3', '5' ),
	),
);
