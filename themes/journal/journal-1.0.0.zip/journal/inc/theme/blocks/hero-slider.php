<?php
/**
 * Block description: first screen as a slider of posts and offers.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Photo across the page', 'journal' ),
			'class'  => 'photo',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Centred on a blurred photo', 'journal' ),
			'class'  => 'center',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Fan of cards and text', 'journal' ),
			'class'  => 'fan',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Coloured half and photo', 'journal' ),
			'class'  => 'split',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Photo and thumbnails', 'journal' ),
			'class'  => 'photos',
			'motion' => 'rise',
		),
	),
	'parts'      => array(
		'arrows' => __( 'Arrows', 'journal' ),
		'dots'   => __( 'Dots', 'journal' ),
		'pause'  => __( 'Pause button', 'journal' ),
		'thumbs' => __( 'Thumbnails', 'journal' ),
	),
	'item_parts' => array(
		'pics'    => __( 'Pictures', 'journal' ),
		'kicker'  => __( 'Line above the heading', 'journal' ),
		'title'   => __( 'Heading', 'journal' ),
		'lead'    => __( 'Lead', 'journal' ),
		'facts'   => __( 'Facts', 'journal' ),
		'actions' => __( 'Button', 'journal' ),
	),
	'only'       => array(
		'slide_effect'        => array(),
		'head_color'          => array(),
		'kicker_color'        => array(),
		'slides.accent_word'  => array( '1', '2', '3', '4' ),
		'slides.text'         => array( '1', '2', '3', '4' ),
		'slides.facts'        => array( '3', '4' ),
		'slides.button_text'  => array( '1', '2', '3', '4' ),
		'slides.button_url'   => array( '1', '2', '3', '4' ),
		'slides.button_color' => array(),
		'slides.price_label'  => array(),
		'slides.price'        => array(),
		'slides.image_1'      => array( '3' ),
		'slides.image_2'      => array( '3' ),
		'slides.image_3'      => array( '3' ),
		'slides.photo'        => array( '1', '2', '4', '5' ),
		'slides.photo_focus'  => array( '1', '2', '4', '5' ),
		'slides.link'         => array( '5' ),
		'slides.text_align'   => array( '1' ),
		'slides.overlay'      => array( '1', '2' ),
		'slides.blur'         => array(),
		'slides.products'     => array(),
		'parts.arrows'        => array( '1', '2', '3', '4' ),
		'parts.dots'          => array( '1', '2', '3', '4' ),
		'parts.pause'         => array( '1', '2', '3', '4' ),
		'parts.thumbs'        => array( '5' ),
		'item_parts.lead'     => array( '1', '2', '3', '4' ),
		'item_parts.facts'    => array( '3', '4' ),
		'item_parts.actions'  => array( '1', '2', '3', '4' ),
	),
);
