<?php
/**
 * Block description: how the journal works, short rules with icons.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Picture and icon grid', 'journal' ),
			'class'  => 'icons',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Numbered grid', 'journal' ),
			'class'  => 'num',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Thin strip', 'journal' ),
			'class'  => 'strip',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Circled icons in the centre', 'journal' ),
			'class'  => 'circles',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Photo and list', 'journal' ),
			'class'  => 'photo',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'image'           => array( '1', '5' ),
		'parts.image'     => array( '1', '5' ),
		'blocks.icon'     => array( '1', '3', '4', '5' ),
		'blocks.text'     => array( '1', '2', '4', '5' ),
		'item_parts.icon' => array( '1', '3', '4', '5' ),
		'item_parts.num'  => array( '2' ),
		'item_parts.text' => array( '1', '2', '4', '5' ),
		'image_side'      => array(),
		'image_size'      => array(),
		'cards_bg'        => array(),
		'cards_ink'       => array(),
		'cards_icon'      => array( '1', '3', '4', '5' ),
	),
);
