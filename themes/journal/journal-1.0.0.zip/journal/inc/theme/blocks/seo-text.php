<?php
/**
 * Block description: long text for search.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Column of text', 'journal' ),
			'class'  => 'column',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Folded, read in full', 'journal' ),
			'class'  => 'fold',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Two newspaper columns', 'journal' ),
			'class'  => 'cols',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Heading on the left', 'journal' ),
			'class'  => 'side',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Small between rules', 'journal' ),
			'class'  => 'small',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'spoiler'       => array( '1', '3', '4', '5' ),
		'spoiler_lines' => array( '1', '3', '4', '5' ),
	),
);
