<?php
/**
 * Block description: the authors of the blog.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Cards', 'journal' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'About the team and a list', 'journal' ),
			'class'  => 'about',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Trust in figures', 'journal' ),
			'class'  => 'trust',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Word of the editor', 'journal' ),
			'class'  => 'editor',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Strip of faces', 'journal' ),
			'class'  => 'faces',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'groups'      => array(),
		'ids'         => array( '1', '2', '4', '5' ),
		'count'       => array( '1', '2', '5' ),
		'chief_label' => array( '4' ),
		'letter'      => array( '4' ),
		'button_text' => array( '2' ),
		'button_url'  => array( '2' ),
		'facts'       => array( '3' ),
		'link_text'   => array( '1', '5' ),
		'link_url'    => array( '1', '5' ),
		'parts.more'  => array( '1', '5' ),
	),
);
