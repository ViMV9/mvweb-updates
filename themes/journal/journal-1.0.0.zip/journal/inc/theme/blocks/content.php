<?php
/**
 * Block description: text block.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Text in a column', 'journal' ),
			'class'  => 'column',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Picture with a badge', 'journal' ),
			'class'  => 'badge',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Two pictures and text', 'journal' ),
			'class'  => 'pair',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Quote beside the text', 'journal' ),
			'class'  => 'quote',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Large heading on the left', 'journal' ),
			'class'  => 'lead',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'image'         => array( '2', '3' ),
		'image_2'       => array( '3' ),
		'badge_icon'    => array( '2' ),
		'badge_title'   => array( '2' ),
		'badge_text'    => array( '2' ),
		'quote'         => array( '4' ),
		'quote_cite'    => array( '4' ),
		'parts.image'   => array( '2', '3' ),
		'parts.image_2' => array( '3' ),
		'parts.badge'   => array( '2' ),
		'parts.quote'   => array( '4' ),
		'image_side'    => array(),
		'image_size'    => array(),
	),
);
