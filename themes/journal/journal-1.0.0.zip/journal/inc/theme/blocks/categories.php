<?php
/**
 * Block description: groups with links, the categories of the blog or cards by hand.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Mosaic with a wide card', 'journal' ),
			'class'  => 'mosaic',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Grid of cards', 'journal' ),
			'class'  => 'grid',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Round pictures in a row', 'journal' ),
			'class'  => 'circles',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Colour tiles with a pattern', 'journal' ),
			'class'  => 'pattern',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'List of rows', 'journal' ),
			'class'  => 'rows',
			'motion' => 'rise',
		),
	),
	'item_parts' => array(
		'image' => __( 'Picture', 'journal' ),
		'title' => __( 'Name', 'journal' ),
		'count' => __( 'Line under the name', 'journal' ),
		'desc'  => __( 'Description', 'journal' ),
	),
	'only'       => array(
		'cards.image'           => array( '1', '2', '3', '5' ),
		'cards.image_2'         => array( '1' ),
		'cards.text'            => array( '1', '4', '5' ),
		'cards.size'            => array( '1' ),
		'cards.bg'              => array( '4' ),
		'cards.pattern'         => array( '4' ),
		'cards.pattern_image'   => array( '4' ),
		'cards.pattern_repeat'  => array( '4' ),
		'cards.pattern_opacity' => array( '4' ),
		'item_parts.image'      => array( '1', '2', '3', '5' ),
		'item_parts.desc'       => array( '1', '4', '5' ),
	),
);
