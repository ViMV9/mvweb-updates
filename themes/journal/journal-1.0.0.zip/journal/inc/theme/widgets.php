<?php
/**
 * The column of widgets: the classes of the widgets, the widgets the theme does not draw.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'use_widgets_block_editor', '__return_false' );
add_filter( 'gutenberg_use_widgets_block_editor', '__return_false' );

if ( ! function_exists( 'mvweb_theme_widget_classes' ) ) {
	/**
	 * Give the roles of the widgets the classes of the theme.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $classes Role => classes.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_widget_classes( $classes ) {
		return array_merge(
			(array) $classes,
			array(
				'widget'       => 'mvweb-t-wg',
				'title'        => 'mvweb-t-wg__title',
				'count'        => 'mvweb-t-wg__count',
				'chip'         => 'mvweb-t-chip',
				'list'         => 'mvweb-t-wg__list',
				'name'         => 'mvweb-t-wg__name',
				'help'         => 'mvweb-t-wg--help',
				'view'         => 'mvweb-t-wg-',
				'inserts'      => 'mvweb-t-in-content',
				'insert'       => 'mvweb-t-in-content__item',
				'insert_title' => 'mvweb-t-in-content__title',
			)
		);
	}
}
add_filter( 'mvweb_core_widget_classes', 'mvweb_theme_widget_classes' );

if ( ! function_exists( 'mvweb_theme_widget_kinds' ) ) {
	/**
	 * Leave out the request form: the journal has no request window.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $kinds Kinds of widgets by key.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_widget_kinds( $kinds ) {
		unset( $kinds['request'] );

		return $kinds;
	}
}
add_filter( 'mvweb_core_widget_kinds', 'mvweb_theme_widget_kinds', 20 );

if ( ! function_exists( 'mvweb_theme_widget_view' ) ) {
	/**
	 * The look a widget draws: its own, or the one the column gives a widget of this kind.
	 *
	 * @since 0.1.0
	 *
	 * @param string               $view   Own look of the widget, empty to follow the column.
	 * @param array<string,string> $column Look of the widget by the look of the column, '1'…'5'.
	 *
	 * @return string
	 */
	function mvweb_theme_widget_view( $view, array $column ) {
		if ( '' !== (string) $view ) {
			return (string) $view;
		}

		$frame = mvweb_core_area_view( 'sidebar' );

		return isset( $column[ $frame ] ) ? $column[ $frame ] : (string) reset( $column );
	}
}

if ( ! function_exists( 'mvweb_theme_widget_sets' ) ) {
	/**
	 * The widgets every column starts with, as the mockups draw them: area => list of [ widget, settings ].
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<int,array{0:string,1:array<string,mixed>}>>
	 */
	function mvweb_theme_widget_sets() {
		$socials = array(
			'mvweb_subscribe',
			array(
				'title' => __( 'Follow us', 'journal' ),
				'show'  => array( 'socials' ),
			),
		);
		$read    = array(
			'mvweb_posts',
			array(
				'title'  => __( 'Most read', 'journal' ),
				'source' => 'read',
				'number' => 5,
			),
		);
		$cats    = array( 'mvweb_blog_cats', array( 'title' => __( 'Categories', 'journal' ) ) );
		$search  = array( 'search', array( 'title' => __( 'Search', 'journal' ) ) );

		return array(
			'blog'    => array( $search, $cats, $read, $socials ),
			'single'  => array( $read, $socials ),
			'author'  => array( $read, $socials ),
			'search'  => array( $cats, $read ),
			'utility' => array(
				$search,
				$cats,
				array(
					'mvweb_posts',
					array(
						'title'  => __( 'Recent articles', 'journal' ),
						'source' => 'recent',
						'number' => 5,
					),
				),
			),
			'page'    => array(
				array( 'mvweb_contacts', array( 'title' => __( 'Editorial office', 'journal' ) ) ),
				$socials,
				array(
					'mvweb_subscribe',
					array(
						'title' => __( 'Newsletter', 'journal' ),
						'show'  => array( 'mail' ),
					),
				),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_seed_widgets' ) ) {
	/**
	 * Fill the columns that have no widget yet with the sets of the theme; a column with widgets and the inactive ones stay as they are.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_seed_widgets() {
		global $wp_registered_sidebars, $wp_widget_factory;

		$sidebars = wp_get_sidebars_widgets();
		$known    = array();
		$changed  = false;

		foreach ( $wp_widget_factory->widgets as $widget ) {
			$known[ $widget->id_base ] = true;
		}

		foreach ( mvweb_theme_widget_sets() as $area => $set ) {
			$id = mvweb_core_sidebar_id( $area );

			if ( ! isset( $wp_registered_sidebars[ $id ] ) || ! empty( $sidebars[ $id ] ) ) {
				continue;
			}

			$sidebars[ $id ] = array();

			foreach ( $set as $item ) {
				if ( empty( $known[ $item[0] ] ) ) {
					continue;
				}

				$saved  = (array) get_option( 'widget_' . $item[0], array() );
				$number = max( array_merge( array( 1 ), array_filter( array_keys( $saved ), 'is_int' ) ) ) + 1;

				$saved[ $number ]      = $item[1];
				$saved['_multiwidget'] = 1;
				$sidebars[ $id ][]     = $item[0] . '-' . $number;

				update_option( 'widget_' . $item[0], $saved );
			}

			$changed = true;
		}

		if ( $changed ) {
			wp_set_sidebars_widgets( $sidebars );
		}
	}
}
add_action( 'after_switch_theme', 'mvweb_theme_seed_widgets', 20 );
