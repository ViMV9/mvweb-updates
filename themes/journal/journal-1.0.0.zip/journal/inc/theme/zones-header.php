<?php
/**
 * The header zones: their names, hints and elements, and the default order of each of the three looks.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_header_default_order' ) ) {
	/**
	 * The elements of the header zones in the order of the chosen look.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $order Element slugs.
	 * @param string   $zone  Zone slug.
	 *
	 * @return string[]
	 */
	function mvweb_theme_header_default_order( $order, $zone ) {
		$common = array(
			'header-topbar'          => array( 'notice' ),
			'header-drawer-contacts' => array(),
			'header-drawer-nav'      => array( 'menu-primary' ),
			'header-drawer-foot'     => array( 'socials', 'messengers', 'subscribe', 'scheme' ),
		);

		$views = array(
			'simple'   => array(
				'header-main'    => array( 'logo', 'search-form', 'actions' ),
				'header-actions' => array( 'search', 'socials', 'scheme', 'subscribe' ),
				'header-nav'     => array( 'menu-primary' ),
			),
			'extended' => array(
				'header-main'    => array( 'logo', 'actions' ),
				'header-actions' => array( 'search', 'city', 'socials', 'scheme', 'subscribe' ),
				'header-nav'     => array( 'menu-primary', 'search-form' ),
			),
			'compact'  => array(
				'header-main'    => array( 'logo', 'menu-primary', 'actions' ),
				'header-actions' => array( 'search', 'scheme', 'subscribe' ),
				'header-nav'     => array(),
			),
		);

		if ( isset( $common[ $zone ] ) ) {
			return $common[ $zone ];
		}

		$view = mvweb_core_header_view();

		return isset( $views[ $view ][ $zone ] ) ? $views[ $view ][ $zone ] : $order;
	}
}
add_filter( 'mvweb_core_zone_default_order', 'mvweb_theme_header_default_order', 10, 2 );

if ( ! function_exists( 'mvweb_theme_header_zone_texts' ) ) {
	/**
	 * The name and the hint of every header zone, in words of the owner.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,string>> Zone slug => name and hint.
	 */
	function mvweb_theme_header_zone_texts() {
		return array(
			'header-topbar'          => array(
				'label' => __( 'Strip above the header', 'journal' ),
				'hint'  => __( 'The strip at the very top of the page: the announcement and, if needed, the city, the extra menu, the colour scheme switch. Its look is chosen in “Announcement”.', 'journal' ),
			),
			'header-main'            => array(
				'label' => __( 'Header row', 'journal' ),
				'hint'  => __( 'The row with the logo: the logo always stands first, then the menu, search and “Other items” (the icons and buttons on the right). How the logo looks is set in the section “Logo”.', 'journal' ),
			),
			'header-actions'         => array(
				'label' => __( 'Header row: other items', 'journal' ),
				'hint'  => __( 'What stands on the right of the header row: search, city, social networks, colour scheme switch, the button “Subscribe”. On a phone the search icon and the bell stay, the rest moves to the mobile menu.', 'journal' ),
			),
			'header-nav'             => array(
				'label' => __( 'Menu row', 'journal' ),
				'hint'  => __( 'The row under the header: the main menu and the search line. Empty in the third look, where the menu stands in the header row.', 'journal' ),
			),
			'header-drawer-contacts' => array(
				'label' => __( 'Mobile menu: contacts', 'journal' ),
				'hint'  => __( 'Address, opening hours, e-mail, messengers in the menu that opens on a phone. Above or below the menu items: see “Where the contacts stand”.', 'journal' ),
			),
			'header-drawer-nav'      => array(
				'label' => __( 'Mobile menu: sections', 'journal' ),
				'hint'  => __( 'The menus of the site in the mobile menu. A category shows the number of its articles.', 'journal' ),
			),
			'header-drawer-foot'     => array(
				'label' => __( 'Mobile menu: bottom', 'journal' ),
				'hint'  => __( 'The bottom of the mobile menu: social networks, messengers of the editorial office, the mailing and the colour scheme switch.', 'journal' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_header_zone_labels' ) ) {
	/**
	 * The names of the header zones.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $zones Zone slug => label.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_header_zone_labels( $zones ) {
		foreach ( mvweb_theme_header_zone_texts() as $zone => $texts ) {
			if ( isset( $zones[ $zone ] ) ) {
				$zones[ $zone ] = $texts['label'];
			}
		}

		return $zones;
	}
}
add_filter( 'mvweb_core_zones', 'mvweb_theme_header_zone_labels', 20 );

if ( ! function_exists( 'mvweb_theme_header_zone_hints' ) ) {
	/**
	 * The hints under the header zones in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $hints Zone slug => hint.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_header_zone_hints( $hints ) {
		foreach ( mvweb_theme_header_zone_texts() as $zone => $texts ) {
			$hints[ $zone ] = $texts['hint'];
		}

		return $hints;
	}
}
add_filter( 'mvweb_core_zone_hints', 'mvweb_theme_header_zone_hints' );

if ( ! function_exists( 'mvweb_theme_header_zone_elements' ) ) {
	/**
	 * The elements of the header zones the journal draws, with plain names; the shop and the phone are left out.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $elements Element slug => label.
	 * @param string               $zone     Zone slug.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_header_zone_elements( $elements, $zone ) {
		if ( 'header-main' === $zone ) {
			return array(
				'logo'         => __( 'Logo', 'journal' ),
				'menu-primary' => __( 'Main menu', 'journal' ),
				'search-form'  => __( 'Search (line)', 'journal' ),
				'actions'      => __( 'Other items', 'journal' ),
			);
		}

		$more = array(
			'header-actions'     => array(
				'scheme' => '',
				'city'   => '',
			),
			'header-drawer-foot' => array(
				'messengers' => '',
				'subscribe'  => '',
			),
		);

		if ( isset( $more[ $zone ] ) ) {
			$elements += $more[ $zone ];
		}

		if ( 'header-drawer-foot' === $zone && ! mvweb_core_subscribe_supported() ) {
			unset( $elements['subscribe'] );
		}

		foreach ( array( 'burger', 'menu-button', 'catalog-button', 'favorites', 'compare', 'account', 'cart', 'phone' ) as $gone ) {
			unset( $elements[ $gone ] );
		}

		$labels = array(
			'address'    => __( 'Address', 'journal' ),
			'schedule'   => __( 'Opening hours', 'journal' ),
			'scheme'     => __( 'Light and dark scheme switch', 'journal' ),
			'menu-top'   => __( 'Top menu', 'journal' ),
			'cta'        => __( 'Button with an own link', 'journal' ),
			'search'     => __( 'Search (icon)', 'journal' ),
			'city'       => __( 'City', 'journal' ),
			'socials'    => __( 'Social networks', 'journal' ),
			'messengers' => __( 'Messengers', 'journal' ),
			'subscribe'  => __( 'Subscribe', 'journal' ),
			'notice'     => __( 'Announcement', 'journal' ),
		);

		return array_merge( $elements, array_intersect_key( $labels, $elements ) );
	}
}
add_filter( 'mvweb_core_zone_elements', 'mvweb_theme_header_zone_elements', 30, 2 );
