<?php
/**
 * Stylesheets of the theme for the keys the core asks for.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_enqueue_styles' ) ) {
	/**
	 * Enqueue assets/css/{key}.css of the theme for every key of the request, in order.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_enqueue_styles() {
		$previous = '';

		foreach ( mvweb_core_style_map() as $key ) {
			$file = '';

			foreach ( array( '.min.css', '.css' ) as $extension ) {
				if ( '' === $file && file_exists( get_template_directory() . '/assets/css/' . $key . $extension ) ) {
					$file = '/assets/css/' . $key . $extension;
				}
			}

			if ( '' === $file ) {
				continue;
			}

			$handle = 'mvweb-t-' . str_replace( '/', '-', $key );

			wp_enqueue_style(
				$handle,
				get_template_directory_uri() . $file,
				'' === $previous ? array() : array( $previous ),
				(string) filemtime( get_template_directory() . $file )
			);

			$previous = $handle;
		}
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_theme_enqueue_styles' );

if ( ! function_exists( 'mvweb_theme_style_map' ) ) {
	/**
	 * Add the stylesheets of the pages that have their own: the author, the search, the 404, the sitemap and the contacts, and the states of the blocks that appear on scroll; the forms right after the base, for the text of the contacts and the mailing form of the window of the subscription.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Keys of the stylesheets so far.
	 *
	 * @return string[]
	 */
	function mvweb_theme_style_map( $styles ) {
		$own = array(
			'author'   => is_author(),
			'search'   => is_search(),
			'notfound' => is_404(),
			'sitemap'  => function_exists( 'mvweb_core_is_sitemap' ) && mvweb_core_is_sitemap(),
			'contacts' => is_page_template( 'page-templates/contacts.php' ),
			'widgets'  => mvweb_core_sidebar_active(),
			'motion'   => mvweb_core_motion_active(),
		);

		$own['widgets-cards'] = $own['widgets'];

		$form = mvweb_core_subscribe_has_form()
			|| ( $own['contacts'] && '' !== trim( (string) get_post_field( 'post_content', get_queried_object_id() ) ) );

		$styles = array_merge( $styles, array_keys( array_filter( $own ) ) );

		if ( $form && ! in_array( 'form', $styles, true ) ) {
			array_splice( $styles, (int) array_search( 'base', $styles, true ) + 1, 0, 'form' );
		}

		return $styles;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_theme_style_map' );

if ( ! function_exists( 'mvweb_theme_module_map' ) ) {
	/**
	 * Add the modules of the core the page leans on: the tabs of the mega menu and of the blocks, the focus of the windows, the running line.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules File names without extension.
	 *
	 * @return string[]
	 */
	function mvweb_theme_module_map( $modules ) {
		$tree = mvweb_core_menu_tree( 'primary' );

		foreach ( isset( $tree[0] ) ? $tree[0] : array() as $item ) {
			if ( ! empty( $tree[ $item->ID ] ) && mvweb_core_menu_item_is_mega( $item->ID ) && '5' !== mvweb_core_area_view( 'mega' ) ) {
				$modules[] = 'tabs';
				break;
			}
		}

		if ( ! empty( mvweb_core_subscribe() ) || ( mvweb_core_topics_on() && '3' === mvweb_core_area_view( 'topics' ) ) ) {
			$modules[] = 'popover-focus';
		}

		$needs = array(
			'ticker' => array(
				'banner' => array( '4' ),
				'embed'  => array( '5' ),
			),
			'tabs'   => array(
				'two-lists' => array( '2' ),
				'posts'     => array( '14' ),
			),
		);

		foreach ( mvweb_core_request_sections() as $row ) {
			$type = isset( $row['type'] ) ? (string) $row['type'] : '';
			$view = mvweb_core_view( isset( $row['props'] ) && is_array( $row['props'] ) ? $row['props'] : array() );
			$view = '' === $view ? '1' : $view;

			foreach ( $needs as $module => $types ) {
				if ( isset( $types[ $type ] ) && in_array( $view, $types[ $type ], true ) ) {
					$modules[] = $module;
				}
			}
		}

		if ( is_page_template( 'page-templates/contacts.php' ) && '3' === mvweb_core_area_view( 'contacts' ) && mvweb_core_has_city_choice() ) {
			$modules[] = 'tabs';
		}

		return array_values( array_unique( $modules ) );
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_theme_module_map' );

if ( ! function_exists( 'mvweb_theme_enqueue_scripts' ) ) {
	/**
	 * Enqueue the script of the frame: the switch of the topics of the day, the mobile menu and the mailing button.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_enqueue_scripts() {
		$file = file_exists( get_template_directory() . '/assets/js/frame.min.js' ) ? '/assets/js/frame.min.js' : '/assets/js/frame.js';

		wp_enqueue_script(
			'mvweb-t-frame',
			get_template_directory_uri() . $file,
			array(),
			(string) filemtime( get_template_directory() . $file ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_theme_enqueue_scripts' );
