<?php
/**
 * Fallback template.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_title = mvweb_core_alt_h1();

if ( '' === $mvweb_title ) {
	$mvweb_title = is_archive()
		? wp_strip_all_tags( get_the_archive_title() )
		: get_bloginfo( 'name' );
}

get_header();

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'title' => $mvweb_title,
		'lead'  => is_archive() ? wp_strip_all_tags( get_the_archive_description() ) : '',
	)
);

get_template_part(
	'template-parts/post-list',
	null,
	array(
		'empty_title'       => __( 'Nothing here yet', 'journal' ),
		'empty_text'        => __( 'There are no entries for this request.', 'journal' ),
		'empty_button_url'  => home_url( '/' ),
		'empty_button_text' => __( 'To the homepage', 'journal' ),
	)
);

get_footer();
