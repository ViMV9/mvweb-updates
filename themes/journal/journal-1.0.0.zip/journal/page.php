<?php
/**
 * Single page in five looks.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	$mvweb_view  = mvweb_core_area_view( 'page' );
	$mvweb_title = mvweb_core_alt_h1();
	$mvweb_looks = array(
		'3' => array( 'rule' ),
		'4' => array( 'band' ),
		'5' => array( 'large' ),
	);
	$mvweb_cover = '2' === $mvweb_view ? (int) get_post_thumbnail_id() : 0;

	get_template_part(
		'template-parts/page-hero',
		null,
		array(
			'title' => '' !== $mvweb_title ? $mvweb_title : get_the_title(),
			'lead'  => has_excerpt() ? get_the_excerpt() : '',
			'looks' => isset( $mvweb_looks[ $mvweb_view ] ) ? $mvweb_looks[ $mvweb_view ] : array(),
		)
	);

	mvweb_theme_layout_open( 'page' );

	if ( $mvweb_cover && wp_attachment_is_image( $mvweb_cover ) ) :
		?>
		<span class="mvweb-t-cover mvweb-t-cover--wide">
			<?php
			echo wp_get_attachment_image(
				$mvweb_cover,
				'large',
				false,
				array(
					'sizes'         => '(min-width: 1024px) 70vw, 100vw',
					'loading'       => false,
					'fetchpriority' => 'high',
				)
			);
			?>
		</span>
		<?php
	endif;
	?>

	<div class="mvweb-t-prose mvweb-t-prose--measure<?php echo '3' === $mvweb_view ? ' mvweb-t-dropcap' : ''; ?>" data-prose>
		<?php
		the_content();

		wp_link_pages(
			array(
				'before' => '<nav class="page-links" aria-label="' . esc_attr__( 'Page parts', 'journal' ) . '">',
				'after'  => '</nav>',
			)
		);
		?>
	</div>

	<?php
	mvweb_theme_layout_close( 'page' );

endwhile;

get_footer();
