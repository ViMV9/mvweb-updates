<?php
/**
 * Zone element: Logo, the words about the site and the social networks in the footer.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tagline = trim( (string) mvweb_cz_get( 'mvweb_footer_tagline', '' ) );
$mvweb_tagline = '' !== $mvweb_tagline ? $mvweb_tagline : get_bloginfo( 'description' );
$mvweb_socials = mvweb_cz_profile_socials();
$mvweb_title   = trim( (string) mvweb_cz_get( 'mvweb_footer_socials_title' ) );
?>
<div class="mvweb-t-el-brand mvweb-t-footer__brand">
	<?php mvweb_theme_logo( array( 'lazy' => true ) ); ?>

	<?php if ( '' !== $mvweb_tagline ) : ?>
		<p class="mvweb-t-footer__about"><?php echo esc_html( $mvweb_tagline ); ?></p>
	<?php endif; ?>

	<?php if ( ! empty( $mvweb_socials ) ) : ?>
		<div class="mvweb-t-footer__follow">
			<?php if ( '' !== $mvweb_title ) : ?>
				<div class="mvweb-t-footer__title"><?php echo esc_html( $mvweb_title ); ?></div>
			<?php endif; ?>
			<?php mvweb_theme_follow( $mvweb_socials, 'icons' ); ?>
			<?php mvweb_theme_meta_note( $mvweb_socials ); ?>
		</div>
	<?php endif; ?>
</div>
