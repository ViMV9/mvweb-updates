<?php
/**
 * Zone element: Opening hours.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_zone     = isset( $args['zone'] ) ? $args['zone'] : '';
$mvweb_context  = isset( $args['context'] ) ? $args['context'] : 'bar';
$mvweb_contacts = mvweb_core_contacts();

if ( empty( $mvweb_contacts['hours'] ) ) {
	return;
}

if ( 'drawer' === $mvweb_context ) :
	?>
	<p class="mvweb-t-el-schedule mvweb-t-drawer__hours">
		<?php foreach ( $mvweb_contacts['hours'] as $mvweb_row ) : ?>
			<span>
				<?php echo esc_html( $mvweb_row['days'] ); ?>
				<b><?php echo esc_html( $mvweb_row['time'] ); ?></b>
			</span>
		<?php endforeach; ?>
	</p>
	<?php
	return;
endif;

if ( 'phone' === mvweb_core_zone_neighbour( $mvweb_zone, 'schedule', -1 ) && ! empty( $mvweb_contacts['phones'] ) ) {
	return;
}
?>
<p class="mvweb-t-el-schedule"><?php echo esc_html( mvweb_core_hours_line( $mvweb_contacts['hours'] ) ); ?></p>
