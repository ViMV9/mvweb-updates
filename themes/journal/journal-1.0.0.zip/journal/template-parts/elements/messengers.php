<?php
/**
 * Zone element: Messengers of the profile — icons in the header, buttons with names in the mobile menu.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_links = mvweb_core_header_messengers();

if ( empty( $mvweb_links ) ) {
	return;
}

$mvweb_drawer = 'drawer' === ( isset( $args['context'] ) ? $args['context'] : 'bar' );
$mvweb_list   = '<div class="mvweb-t-msgs mvweb-t-msgs--' . ( $mvweb_drawer ? 'buttons' : 'icons' ) . '">';

foreach ( $mvweb_links as $mvweb_id => $mvweb_link ) {
	$mvweb_list .= '<a href="' . esc_url( $mvweb_link['url'] ) . '" data-brand="' . esc_attr( mvweb_core_social_icon( $mvweb_id ) ) . '" rel="noopener" target="_blank"' . ( $mvweb_drawer ? '' : ' title="' . esc_attr( $mvweb_link['label'] ) . '"' ) . '>'
		. mvweb_theme_icon( mvweb_core_social_icon( $mvweb_id ), array( 'class' => 'mvweb-t-icon--brand' ) )
		. '<span' . ( $mvweb_drawer ? '' : ' class="screen-reader-text"' ) . '>' . esc_html( $mvweb_link['label'] ) . '</span></a>';
}

$mvweb_list .= '</div>';

if ( ! $mvweb_drawer ) {
	echo '<div class="mvweb-t-el-messengers">' . $mvweb_list . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts above.

	return;
}
?>
<div class="mvweb-t-el-messengers mvweb-t-drawer__block">
	<span class="mvweb-t-drawer__cap"><?php esc_html_e( 'Write to the editorial office', 'journal' ); ?></span>
	<?php echo $mvweb_list; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts above. ?>
</div>
