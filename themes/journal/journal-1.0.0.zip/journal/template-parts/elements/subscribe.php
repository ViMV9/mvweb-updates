<?php
/**
 * Zone element: Subscribe — the bell on a phone and the button on a wide screen open the window of the subscription; in the mobile menu, the button of the mailing.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_subscribe = mvweb_core_subscribe();

if ( empty( $mvweb_subscribe ) ) {
	return;
}

if ( 'drawer' === ( isset( $args['context'] ) ? $args['context'] : 'bar' ) ) {
	if ( ! $mvweb_subscribe['form'] ) {
		return;
	}
	?>
	<button class="mvweb-t-el-subscribe mvweb-t-btn mvweb-t-btn--outline mvweb-t-btn--block" type="button" data-subscribe-open data-popover-trigger="mvweb-t-subpop">
		<?php echo mvweb_theme_icon( 'mail', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<?php esc_html_e( 'Mailing by e-mail', 'journal' ); ?>
	</button>
	<?php
	return;
}
?>
<div class="mvweb-t-el-subscribe">
	<button class="mvweb-t-icon-btn mvweb-t-header__bell" type="button" popovertarget="mvweb-t-subpop" data-popover-trigger="mvweb-t-subpop" title="<?php echo esc_attr( $mvweb_subscribe['label'] ); ?>">
		<?php echo mvweb_theme_icon( 'bell' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<span class="screen-reader-text"><?php echo esc_html( $mvweb_subscribe['label'] ); ?></span>
	</button>
	<button class="mvweb-t-btn mvweb-t-btn--sm mvweb-t-header__wide" type="button" popovertarget="mvweb-t-subpop" data-popover-trigger="mvweb-t-subpop">
		<?php echo mvweb_theme_icon( 'bell', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<?php echo esc_html( $mvweb_subscribe['label'] ); ?>
	</button>
</div>
