<?php
/**
 * Zone element: Search button.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<button class="mvweb-t-el-search mvweb-t-icon-btn" type="button" data-search-toggle aria-controls="mvweb-t-search-panel" aria-expanded="false" title="<?php esc_attr_e( 'Search', 'journal' ); ?>">
	<?php echo mvweb_theme_icon( 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<span class="screen-reader-text"><?php esc_html_e( 'Search', 'journal' ); ?></span>
</button>
