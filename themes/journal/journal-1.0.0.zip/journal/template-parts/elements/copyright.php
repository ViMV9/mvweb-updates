<?php
/**
 * Zone element: Copyright.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_copy = trim( (string) mvweb_cz_get( 'mvweb_footer_copyright', '' ) );
$mvweb_copy = '' !== $mvweb_copy
	? str_replace( '{year}', wp_date( 'Y' ), $mvweb_copy )
	: sprintf(
		/* translators: 1: current year, 2: site name. */
		__( '© %1$s %2$s. All rights reserved.', 'journal' ),
		wp_date( 'Y' ),
		get_bloginfo( 'name' )
	);
?>
<p class="mvweb-t-el-copyright mvweb-t-footer__copy"><?php echo esc_html( $mvweb_copy ); ?></p>
