<?php
/**
 * Zone element: Other items of the header row.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="mvweb-t-header__actions">
	<?php echo mvweb_theme_zone_html( 'header-actions' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped element templates. ?>
	<?php get_template_part( 'template-parts/elements/burger' ); ?>
</div>
