<?php
/**
 * Zone element: Badges of the footer, the studio and partners.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_footer_badges' ) ) {
	return;
}

foreach ( mvweb_core_footer_badges() as $mvweb_badge ) {
	get_template_part(
		'template-parts/footer/badge',
		null,
		array(
			'class'    => 'mvweb-t-el-dev-badge',
			'caption'  => $mvweb_badge['caption'],
			'url'      => $mvweb_badge['url'],
			'title'    => $mvweb_badge['title'],
			'image_id' => $mvweb_badge['image'],
			'view'     => $mvweb_badge['view'],
		)
	);
}
