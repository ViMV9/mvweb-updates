<?php
/**
 * Zone element: Social networks — brand squares in the header with «+N» for the rest, buttons with names in the mobile menu.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_socials = mvweb_cz_profile_socials();

if ( empty( $mvweb_socials ) ) {
	return;
}

if ( 'drawer' !== ( isset( $args['context'] ) ? $args['context'] : 'bar' ) ) {
	mvweb_theme_follow( $mvweb_socials, 'brand', 5, 'mvweb-t-el-socials' );

	return;
}

$mvweb_title = trim( (string) get_theme_mod( 'mvweb_drawer_socials_title', '' ) );
?>
<div class="mvweb-t-el-socials mvweb-t-drawer__block">
	<span class="mvweb-t-drawer__cap"><?php echo '' !== $mvweb_title ? esc_html( $mvweb_title ) : esc_html__( 'Follow us', 'journal' ); ?></span>
	<?php mvweb_theme_follow( $mvweb_socials, 'buttons', 0, 'mvweb-t-follow--compact' ); ?>
	<?php mvweb_theme_meta_note( $mvweb_socials ); ?>
</div>
