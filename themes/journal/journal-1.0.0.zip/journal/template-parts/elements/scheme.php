<?php
/**
 * Zone element: Light and dark scheme switch — an icon in the header, a button with words in the mobile menu.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_dark  = 'dark' === mvweb_core_default_scheme();
$mvweb_title = $mvweb_dark ? __( 'Switch to the light scheme', 'journal' ) : __( 'Switch to the dark scheme', 'journal' );

if ( 'drawer' === ( isset( $args['context'] ) ? $args['context'] : 'bar' ) ) :
	?>
	<button class="mvweb-t-el-scheme mvweb-t-drawer__scheme" type="button" data-scheme-toggle aria-pressed="<?php echo $mvweb_dark ? 'true' : 'false'; ?>" title="<?php echo esc_attr( $mvweb_title ); ?>">
		<svg class="mvweb-t-icon" aria-hidden="true" focusable="false" data-scheme-icon="light"<?php echo $mvweb_dark ? ' hidden' : ''; ?>><use href="#mvweb-t-icon-moon"></use></svg>
		<svg class="mvweb-t-icon" aria-hidden="true" focusable="false" data-scheme-icon="dark"<?php echo $mvweb_dark ? '' : ' hidden'; ?>><use href="#mvweb-t-icon-sun"></use></svg>
		<span data-scheme-label><?php echo $mvweb_dark ? esc_html__( 'Light scheme', 'journal' ) : esc_html__( 'Dark scheme', 'journal' ); ?></span>
	</button>
	<?php
	return;
endif;
?>
<button class="mvweb-t-el-scheme mvweb-t-icon-btn" type="button" data-scheme-toggle aria-pressed="<?php echo $mvweb_dark ? 'true' : 'false'; ?>" title="<?php echo esc_attr( $mvweb_title ); ?>">
	<svg class="mvweb-t-icon" aria-hidden="true" focusable="false" data-scheme-icon="light"<?php echo $mvweb_dark ? ' hidden' : ''; ?>><use href="#mvweb-t-icon-moon"></use></svg>
	<svg class="mvweb-t-icon" aria-hidden="true" focusable="false" data-scheme-icon="dark"<?php echo $mvweb_dark ? '' : ' hidden'; ?>><use href="#mvweb-t-icon-sun"></use></svg>
	<span class="screen-reader-text" data-scheme-sr><?php echo esc_html( $mvweb_title ); ?></span>
</button>
