<?php
/**
 * Zone element: Legal links.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_nav(
	'legal',
	array(
		'menu_class'           => 'mvweb-t-footer__legal-list',
		'items_wrap'           => '<ul id="%1$s" class="%2$s">%3$s</ul>',
		'container'            => 'nav',
		'container_class'      => 'mvweb-t-el-legal mvweb-t-footer__legal',
		'container_aria_label' => __( 'Legal information', 'journal' ),
	)
);
