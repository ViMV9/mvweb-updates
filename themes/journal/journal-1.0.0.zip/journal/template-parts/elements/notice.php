<?php
/**
 * Zone element: Announcement of the strip above the header.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_notice = mvweb_core_notice();

if ( empty( $mvweb_notice ) ) {
	return;
}

$mvweb_whole = '' === $mvweb_notice['link'] && '' !== $mvweb_notice['url'];
?>
<div class="mvweb-t-el-notice">
	<span class="mvweb-t-notice__ico" data-notice-text><?php echo mvweb_theme_icon( 'bell', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
	<p class="mvweb-t-notice__text" data-notice-text>
		<?php if ( '' !== $mvweb_notice['label'] ) : ?>
			<span class="mvweb-t-notice__badge"><?php echo esc_html( $mvweb_notice['label'] ); ?></span>
		<?php endif; ?>
		<?php if ( $mvweb_whole ) : ?>
			<a class="mvweb-t-notice__whole" href="<?php echo esc_url( $mvweb_notice['url'] ); ?>"><?php echo esc_html( $mvweb_notice['text'] ); ?></a>
		<?php else : ?>
			<span><?php echo esc_html( $mvweb_notice['text'] ); ?></span>
			<?php if ( '' !== $mvweb_notice['link'] && '' !== $mvweb_notice['url'] ) : ?>
				<a class="mvweb-t-notice__link" href="<?php echo esc_url( $mvweb_notice['url'] ); ?>"><?php echo esc_html( $mvweb_notice['link'] ); ?><?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></a>
			<?php endif; ?>
		<?php endif; ?>
	</p>

	<?php if ( $mvweb_notice['closable'] ) : ?>
		<button class="mvweb-t-notice__close" type="button" data-notice-close title="<?php esc_attr_e( 'Close the announcement', 'journal' ); ?>">
			<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span class="screen-reader-text"><?php esc_html_e( 'Close the announcement', 'journal' ); ?></span>
		</button>
	<?php endif; ?>
</div>
<?php
if ( $mvweb_notice['closable'] ) {
	wp_print_inline_script_tag(
		'(function(s){var n=s.closest("[data-notice]");if(!n){return;}try{if(!localStorage.getItem(n.getAttribute("data-notice"))){return;}}catch(e){return;}'
		. 'if(n.hasAttribute("data-notice-keep")){n.querySelectorAll("[data-notice-text],[data-notice-close]").forEach(function(e){e.hidden=true;});}else{n.hidden=true;}})(document.currentScript);'
	);
}
