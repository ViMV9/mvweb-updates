<?php
/**
 * The column of widgets beside the text of a page, in the look of the column.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_html = mvweb_core_sidebar_html( isset( $args['area'] ) ? (string) $args['area'] : '' );

if ( '' === $mvweb_html ) {
	return;
}
?>
<aside class="<?php echo esc_attr( 'mvweb-t-sidebar mvweb-t-sidebar--' . mvweb_core_area_view( 'sidebar' ) ); ?>" aria-label="<?php esc_attr_e( 'Sidebar', 'journal' ); ?>">
	<?php echo $mvweb_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the widgets, every value escaped there. ?>
</aside>
