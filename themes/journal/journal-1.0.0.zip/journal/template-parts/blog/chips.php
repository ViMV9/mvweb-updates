<?php
/**
 * The strip of links under the heading of a list of posts: the categories of the blog, the latest months or the subcategories with the number of articles.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_kind  = isset( $args['kind'] ) ? (string) $args['kind'] : 'topics';
$mvweb_items = array();

if ( 'subcats' === $mvweb_kind ) {
	foreach ( isset( $args['tiles'] ) ? (array) $args['tiles'] : array() as $mvweb_tile ) {
		$mvweb_items[] = array(
			'label'   => (string) $mvweb_tile['title'],
			'url'     => (string) $mvweb_tile['url'],
			'current' => false,
			'count'   => (int) $mvweb_tile['count'],
		);
	}
} else {
	$mvweb_items = 'months' === $mvweb_kind ? mvweb_core_blog_months() : mvweb_core_blog_topics();
}

if ( empty( $mvweb_items ) ) {
	return;
}

$mvweb_labels = array(
	'topics'  => __( 'Blog categories', 'journal' ),
	'months'  => __( 'Months', 'journal' ),
	'subcats' => __( 'Subcategories', 'journal' ),
);
?>
<nav class="mvweb-t-chips mvweb-t-blog__chips" aria-label="<?php echo esc_attr( isset( $mvweb_labels[ $mvweb_kind ] ) ? $mvweb_labels[ $mvweb_kind ] : $mvweb_labels['topics'] ); ?>">
	<?php foreach ( $mvweb_items as $mvweb_item ) : ?>
		<a class="mvweb-t-chip" href="<?php echo esc_url( $mvweb_item['url'] ); ?>"<?php echo ! empty( $mvweb_item['current'] ) ? ' aria-current="page"' : ''; ?>>
			<?php echo esc_html( $mvweb_item['label'] ); ?>
			<?php if ( ! empty( $mvweb_item['count'] ) ) : ?>
				<span class="mvweb-t-chip__n"><?php echo esc_html( number_format_i18n( (int) $mvweb_item['count'] ) ); ?></span>
			<?php endif; ?>
		</a>
	<?php endforeach; ?>
</nav>
