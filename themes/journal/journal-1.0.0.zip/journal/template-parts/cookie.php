<?php
/**
 * Notice about cookies: a bar or a card that stays on the screen until accepted.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_text     = isset( $args['text'] ) ? (string) $args['text'] : '';
$mvweb_button   = isset( $args['button'] ) ? (string) $args['button'] : '';
$mvweb_policy   = isset( $args['policy'] ) && is_array( $args['policy'] ) ? $args['policy'] : array();
$mvweb_position = isset( $args['position'] ) ? (string) $args['position'] : 'bar';
$mvweb_bg       = isset( $args['background'] ) ? (string) $args['background'] : 'surface';
$mvweb_style    = isset( $args['style'] ) ? (string) $args['style'] : '';
$mvweb_name     = isset( $args['name'] ) ? (string) $args['name'] : '';
$mvweb_days     = isset( $args['days'] ) ? absint( $args['days'] ) : 30;
$mvweb_preview  = ! empty( $args['preview'] );
?>
<div class="mvweb-t-section mvweb-t-cookie" data-cookie-pos="<?php echo esc_attr( $mvweb_position ); ?>" data-cookie-name="<?php echo esc_attr( $mvweb_name ); ?>" data-cookie-days="<?php echo esc_attr( (string) $mvweb_days ); ?>"<?php echo $mvweb_preview ? ' data-cookie-preview' : ''; ?> data-bg="<?php echo esc_attr( $mvweb_bg ); ?>"<?php echo '' === $mvweb_style ? '' : ' style="' . esc_attr( $mvweb_style ) . '"'; ?> role="region" aria-label="<?php esc_attr_e( 'Cookie notice', 'journal' ); ?>" hidden>
	<?php if ( '' !== $mvweb_text || ! empty( $mvweb_policy ) ) : ?>
		<p class="mvweb-t-cookie__text">
			<?php echo esc_html( $mvweb_text ); ?>
			<?php if ( ! empty( $mvweb_policy ) ) : ?>
				<a class="mvweb-t-cookie__link" href="<?php echo esc_url( $mvweb_policy['url'] ); ?>"><?php echo esc_html( $mvweb_policy['label'] ); ?></a>
			<?php endif; ?>
		</p>
	<?php endif; ?>

	<?php if ( '' !== $mvweb_button ) : ?>
		<button class="mvweb-t-btn mvweb-t-btn--sm mvweb-t-cookie__button" type="button" data-cookie-accept><?php echo esc_html( $mvweb_button ); ?></button>
	<?php endif; ?>
</div>
