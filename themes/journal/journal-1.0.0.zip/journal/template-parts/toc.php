<?php
/**
 * Table of contents of an entry: the core has given the headings anchors.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_items = isset( $args['items'] ) ? (array) $args['items'] : array();
$mvweb_title = trim( (string) mvweb_core_blog_option( 'mvweb_toc_title' ) );
$mvweb_open  = false;
$mvweb_sub   = false;
?>
<details class="mvweb-t-toc" data-toc>
	<summary class="mvweb-t-toc__title">
		<?php if ( '' !== $mvweb_title ) : ?>
			<span><?php echo esc_html( $mvweb_title ); ?></span>
		<?php else : ?>
			<span class="screen-reader-text"><?php esc_html_e( 'Contents', 'journal' ); ?></span>
		<?php endif; ?>
		<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm mvweb-t-toc__chev' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	</summary>
	<nav class="mvweb-t-toc__nav" aria-label="<?php echo esc_attr( '' !== $mvweb_title ? $mvweb_title : __( 'Contents', 'journal' ) ); ?>">
		<ol class="mvweb-t-toc__list">
			<?php
			foreach ( $mvweb_items as $mvweb_item ) :
				if ( 3 === (int) $mvweb_item['level'] && $mvweb_open ) :
					echo $mvweb_sub ? '' : '<ol class="mvweb-t-toc__sub">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
					$mvweb_sub = true;
					?>
					<li><a href="#<?php echo esc_attr( $mvweb_item['anchor'] ); ?>"><?php echo esc_html( $mvweb_item['text'] ); ?></a></li>
					<?php
					continue;
				endif;

				echo $mvweb_sub ? '</ol>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
				echo $mvweb_open ? '</li>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
				$mvweb_sub  = false;
				$mvweb_open = true;
				?>
				<li><a href="#<?php echo esc_attr( $mvweb_item['anchor'] ); ?>"><?php echo esc_html( $mvweb_item['text'] ); ?></a>
			<?php endforeach; ?>
			<?php
			echo $mvweb_sub ? '</ol>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
			echo $mvweb_open ? '</li>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
			?>
		</ol>
	</nav>
</details>
