<?php
/**
 * Kinds of the found entries as links: all of them, then the articles and the pages when they found something.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_needle = get_search_query( false );
$mvweb_kinds  = array(
	'posts' => array( 'post', __( 'Articles', 'journal' ) ),
	'pages' => array( 'page', __( 'Pages', 'journal' ) ),
);
$mvweb_asked  = get_query_var( 'post_type' );
$mvweb_asked  = is_string( $mvweb_asked ) ? sanitize_key( $mvweb_asked ) : '';
$mvweb_tabs   = array();
$mvweb_total  = 0;

foreach ( array_keys( $mvweb_kinds ) as $mvweb_slug ) {
	$mvweb_hit = $mvweb_asked === $mvweb_kinds[ $mvweb_slug ][0] ? $GLOBALS['wp_query'] : new WP_Query(
		array(
			's'                   => $mvweb_needle,
			'post_type'           => $mvweb_kinds[ $mvweb_slug ][0],
			'post_status'         => 'publish',
			'posts_per_page'      => 1,
			'fields'              => 'ids',
			'ignore_sticky_posts' => true,
		)
	);

	if ( 0 === (int) $mvweb_hit->found_posts ) {
		continue;
	}

	$mvweb_tabs[] = array(
		'type'  => $mvweb_kinds[ $mvweb_slug ][0],
		'label' => $mvweb_kinds[ $mvweb_slug ][1],
		'count' => (int) $mvweb_hit->found_posts,
	);
}

if ( '' === $mvweb_asked ) {
	$mvweb_total = (int) $GLOBALS['wp_query']->found_posts;
} else {
	$mvweb_all   = new WP_Query(
		array(
			's'                   => $mvweb_needle,
			'post_status'         => 'publish',
			'posts_per_page'      => 1,
			'fields'              => 'ids',
			'ignore_sticky_posts' => true,
		)
	);
	$mvweb_total = (int) $mvweb_all->found_posts;
}

if ( empty( $mvweb_tabs ) || ( 1 === count( $mvweb_tabs ) && $mvweb_tabs[0]['count'] === $mvweb_total && '' === $mvweb_asked ) ) {
	return;
}

array_unshift(
	$mvweb_tabs,
	array(
		'type'  => '',
		'label' => __( 'All', 'journal' ),
		'count' => $mvweb_total,
	)
);
?>
<nav class="mvweb-t-search-tabs" aria-label="<?php esc_attr_e( 'Kinds of results', 'journal' ); ?>">
	<?php foreach ( $mvweb_tabs as $mvweb_tab ) : ?>
		<?php
		$mvweb_url = add_query_arg(
			array_filter(
				array(
					's'         => rawurlencode( $mvweb_needle ),
					'post_type' => $mvweb_tab['type'],
				)
			),
			home_url( '/' )
		);
		?>
		<a class="mvweb-t-search-tabs__link" href="<?php echo esc_url( $mvweb_url ); ?>"<?php echo $mvweb_asked === $mvweb_tab['type'] ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $mvweb_tab['label'] ); ?> <span class="mvweb-t-search-tabs__n"><?php echo esc_html( number_format_i18n( $mvweb_tab['count'] ) ); ?></span></a>
	<?php endforeach; ?>
</nav>
