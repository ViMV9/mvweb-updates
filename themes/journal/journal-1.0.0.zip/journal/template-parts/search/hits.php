<?php
/**
 * Under a search that found nothing: the most read articles, when the Customizer gives them a heading.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_title = trim( (string) get_theme_mod( 'mvweb_search_hits_title', '' ) );

if ( '' === $mvweb_title ) {
	return;
}

$mvweb_posts = mvweb_core_top_posts( max( 1, absint( get_theme_mod( 'mvweb_search_hits_count', 5 ) ) ) );

if ( empty( $mvweb_posts ) ) {
	return;
}
?>
<div class="mvweb-t-search-hits">
	<div class="mvweb-t-search-hits__title mvweb-t-h3"><?php echo esc_html( $mvweb_title ); ?></div>
	<div class="mvweb-t-search-hits__list">
		<?php
		foreach ( $mvweb_posts as $mvweb_post ) :
			$GLOBALS['post'] = $mvweb_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- The card reads the current post; restored below.
			setup_postdata( $mvweb_post );

			get_template_part(
				'template-parts/post-card',
				null,
				array(
					'modifier' => 'row sm',
					'hide'     => array( 'lead', 'more', 'author', 'comments', 'views' ),
					'sizes'    => '96px',
				)
			);
		endforeach;

		wp_reset_postdata();
		?>
	</div>
</div>
