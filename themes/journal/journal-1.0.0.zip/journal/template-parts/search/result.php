<?php
/**
 * One found entry: the card of a post with the words of the query marked in the title and the text.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_modifier = isset( $args['modifier'] ) ? sanitize_html_class( (string) $args['modifier'] ) : '';
$mvweb_words    = isset( $args['words'] ) && is_array( $args['words'] ) ? $args['words'] : array();
$mvweb_mark     = static function ( $text ) use ( $mvweb_words ) {
	$text = esc_html( $text );

	if ( empty( $mvweb_words ) ) {
		return $text;
	}

	$pattern = implode( '|', array_map( static fn( $word ) => preg_quote( esc_html( $word ), '/' ), $mvweb_words ) );

	return (string) preg_replace( '/(?<![\p{L}\p{N}&#])((?:' . $pattern . ')[\p{L}\p{N}]*)/iu', '<mark>$1</mark>', $text );
};
$mvweb_part     = static function ( $slug, $part_args = array() ) {
	if ( ! mvweb_core_layout_has( 'card-post', $slug ) ) {
		return '';
	}

	ob_start();
	get_template_part( 'template-parts/card-post/' . $slug, null, $part_args );

	return trim( (string) ob_get_clean() );
};
$mvweb_media    = 'text' === $mvweb_modifier ? '' : $mvweb_part(
	'media',
	array(
		'sizes' => isset( $args['sizes'] ) ? (string) $args['sizes'] : '',
	)
);
$mvweb_meta     = $mvweb_part( 'date' ) . $mvweb_part( 'read' );
$mvweb_excerpt  = mvweb_core_layout_has( 'card-post', 'lead' ) ? trim( wp_strip_all_tags( get_the_excerpt() ) ) : '';
$mvweb_class    = 'mvweb-t-post mvweb-t-result' . ( '' === $mvweb_modifier ? '' : ' mvweb-t-post--' . $mvweb_modifier );
?>
<article class="<?php echo esc_attr( $mvweb_class ); ?>">
	<?php echo $mvweb_media; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template. ?>
	<div class="mvweb-t-post__body">
		<?php echo $mvweb_part( 'topic' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template. ?>
		<a class="mvweb-t-post__title" href="<?php the_permalink(); ?>"><?php echo $mvweb_mark( wp_strip_all_tags( get_the_title() ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the closure, only mark tags added. ?></a>
		<?php if ( '' !== $mvweb_excerpt ) : ?>
			<p class="mvweb-t-post__x"><?php echo $mvweb_mark( $mvweb_excerpt ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the closure, only mark tags added. ?></p>
		<?php endif; ?>
		<?php if ( '' !== $mvweb_meta ) : ?>
			<div class="mvweb-t-meta"><?php echo $mvweb_meta; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?></div>
		<?php endif; ?>
	</div>
</article>
