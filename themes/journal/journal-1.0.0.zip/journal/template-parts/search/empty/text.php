<?php
/**
 * Nothing found part: the icon, the line with the query and the advice.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_needle = get_search_query( false );
?>
<span class="mvweb-t-empty__icon"><?php echo mvweb_theme_icon( 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
<div class="mvweb-t-empty__title mvweb-t-h4">
	<?php
	if ( '' === $mvweb_needle ) {
		esc_html_e( 'Type a word to search for', 'journal' );
	} else {
		/* translators: %s: search query. */
		echo esc_html( sprintf( __( 'Nothing found for “%s”', 'journal' ), $mvweb_needle ) );
	}
	?>
</div>
<p class="mvweb-t-empty__text"><?php esc_html_e( 'Check the keyboard layout and typos, or try a simpler word.', 'journal' ); ?></p>
