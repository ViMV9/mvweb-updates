<?php
/**
 * The found entries of the page gathered by their first category; pages go to a group of their own.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_words  = isset( $args['words'] ) && is_array( $args['words'] ) ? $args['words'] : array();
$mvweb_groups = array();

foreach ( $GLOBALS['wp_query']->posts as $mvweb_post ) {
	$mvweb_terms = 'post' === $mvweb_post->post_type ? get_the_category( $mvweb_post->ID ) : array();
	$mvweb_key   = empty( $mvweb_terms ) ? 'type-' . $mvweb_post->post_type : 'term-' . $mvweb_terms[0]->term_id;

	if ( ! isset( $mvweb_groups[ $mvweb_key ] ) ) {
		$mvweb_type                 = get_post_type_object( $mvweb_post->post_type );
		$mvweb_link                 = empty( $mvweb_terms ) ? '' : get_category_link( $mvweb_terms[0] );
		$mvweb_groups[ $mvweb_key ] = array(
			'name'  => empty( $mvweb_terms ) ? ( $mvweb_type ? $mvweb_type->labels->name : '' ) : $mvweb_terms[0]->name,
			'url'   => is_string( $mvweb_link ) ? $mvweb_link : '',
			'posts' => array(),
		);
	}

	$mvweb_groups[ $mvweb_key ]['posts'][] = $mvweb_post;
}

if ( empty( $mvweb_groups ) ) {
	return;
}

$mvweb_pattern = implode( '|', array_map( static fn( $word ) => preg_quote( esc_html( $word ), '/' ), $mvweb_words ) );
?>
<div class="mvweb-t-rgroups">
	<?php foreach ( $mvweb_groups as $mvweb_group ) : ?>
		<div class="mvweb-t-rgroup">
			<div class="mvweb-t-rgroup__name">
				<?php if ( '' !== $mvweb_group['url'] ) : ?>
					<a href="<?php echo esc_url( $mvweb_group['url'] ); ?>"><?php echo esc_html( $mvweb_group['name'] ); ?></a>
				<?php else : ?>
					<?php echo esc_html( $mvweb_group['name'] ); ?>
				<?php endif; ?>
				<small><?php echo esc_html( number_format_i18n( count( $mvweb_group['posts'] ) ) ); ?></small>
			</div>
			<ul>
				<?php foreach ( $mvweb_group['posts'] as $mvweb_post ) : ?>
					<?php
					$mvweb_title = esc_html( wp_strip_all_tags( get_the_title( $mvweb_post ) ) );
					$mvweb_title = '' === $mvweb_pattern ? $mvweb_title : (string) preg_replace( '/(?<![\p{L}\p{N}&#])((?:' . $mvweb_pattern . ')[\p{L}\p{N}]*)/iu', '<mark>$1</mark>', $mvweb_title );
					?>
					<li><a href="<?php echo esc_url( get_permalink( $mvweb_post ) ); ?>"><?php echo $mvweb_title; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above, only mark tags added. ?></a></li>
				<?php endforeach; ?>
			</ul>
		</div>
	<?php endforeach; ?>
</div>
