<?php
/**
 * Head of a post, part: the cover with the caption of the picture.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = (int) get_post_thumbnail_id();

if ( 0 === $mvweb_id || ! wp_attachment_is_image( $mvweb_id ) ) {
	return;
}

$mvweb_image = wp_get_attachment_image(
	$mvweb_id,
	'mvweb_wide',
	false,
	array(
		'sizes'         => ! empty( $args['sizes'] ) ? (string) $args['sizes'] : '(min-width: 1024px) 50vw, 100vw',
		'loading'       => false,
		'fetchpriority' => 'high',
		'decoding'      => 'async',
	)
);

if ( '' === $mvweb_image ) {
	return;
}

$mvweb_caption = trim( (string) wp_get_attachment_caption( $mvweb_id ) );
$mvweb_frame   = 'mvweb-t-cover' . ( ! empty( $args['cover'] ) ? ' ' . sanitize_html_class( 'mvweb-t-cover--' . $args['cover'] ) : '' );
?>
<figure class="mvweb-t-ahead__cover">
	<span class="<?php echo esc_attr( $mvweb_frame ); ?>"><?php echo $mvweb_image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds and escapes the tag. ?></span>
	<?php if ( '' !== $mvweb_caption ) : ?>
		<figcaption><?php echo esc_html( $mvweb_caption ); ?></figcaption>
	<?php endif; ?>
</figure>
