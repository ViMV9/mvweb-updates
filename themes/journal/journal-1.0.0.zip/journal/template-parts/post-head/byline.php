<?php
/**
 * Head of a post, part: the author with the position.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_author = (int) get_post_field( 'post_author', get_the_ID() );
$mvweb_name   = trim( (string) get_the_author_meta( 'display_name', $mvweb_author ) );

if ( 0 === $mvweb_author || '' === $mvweb_name ) {
	return;
}

$mvweb_role   = mvweb_core_author_role( $mvweb_author );
$mvweb_avatar = get_avatar(
	$mvweb_author,
	64,
	'',
	'',
	array(
		'class'         => 'mvweb-t-avatar',
		'force_display' => false,
	)
);
?>
<a class="mvweb-t-ahead__author" href="<?php echo esc_url( get_author_posts_url( $mvweb_author ) ); ?>">
	<?php if ( $mvweb_avatar ) : ?>
		<?php echo $mvweb_avatar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag. ?>
	<?php else : ?>
		<span class="mvweb-t-avatar" aria-hidden="true"><?php echo esc_html( function_exists( 'mb_substr' ) ? mb_substr( $mvweb_name, 0, 1 ) : substr( $mvweb_name, 0, 1 ) ); ?></span>
	<?php endif; ?>
	<span>
		<b><?php echo esc_html( $mvweb_name ); ?></b>
		<?php if ( '' !== $mvweb_role ) : ?>
			<small><?php echo esc_html( $mvweb_role ); ?></small>
		<?php endif; ?>
	</span>
</a>
