<?php
/**
 * Page head: the breadcrumbs, the single h1 and the text under it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_args  = wp_parse_args(
	isset( $args ) && is_array( $args ) ? $args : array(),
	array(
		'title'    => '',
		'lead'     => '',
		'intro'    => '',
		'eyebrow'  => '',
		'meta'     => array(),
		'after'    => '',
		'image_id' => 0,
		'looks'    => array(),
	)
);
$mvweb_image = wp_attachment_is_image( absint( $mvweb_args['image_id'] ) ) ? absint( $mvweb_args['image_id'] ) : 0;
$mvweb_meta  = array_filter( array_map( 'trim', array_map( 'strval', (array) $mvweb_args['meta'] ) ) );
$mvweb_boxed = 0 !== $mvweb_image;
$mvweb_class = 'mvweb-t-page-hero' . ( $mvweb_boxed ? ' mvweb-t-page-hero--media' : '' );

foreach ( array_intersect( (array) $mvweb_args['looks'], array( 'rule', 'band', 'center', 'large' ) ) as $mvweb_look ) {
	$mvweb_class .= ' mvweb-t-page-hero--' . $mvweb_look;
}
?>
<section class="<?php echo esc_attr( $mvweb_class ); ?>">
	<div class="mvweb-t-container">
		<div class="mvweb-t-page-hero__inner">
		<?php if ( $mvweb_boxed && mvweb_core_layout_has( 'page-hero', 'crumbs' ) ) : ?>
			<?php get_template_part( 'template-parts/crumbs' ); ?>
		<?php endif; ?>

		<?php if ( $mvweb_boxed ) : ?>
			<div class="mvweb-t-page-hero__box">
				<div class="mvweb-t-page-hero__text">
		<?php endif; ?>

		<?php mvweb_core_render_layout( 'page-hero', array_merge( $mvweb_args, array( 'above' => $mvweb_boxed ) ) ); ?>

		<?php if ( ! mvweb_core_layout_has( 'page-hero', 'title' ) ) : ?>
			<h1 class="screen-reader-text"><?php echo esc_html( $mvweb_args['title'] ); ?></h1>
		<?php endif; ?>

		<?php if ( ! empty( $mvweb_meta ) ) : ?>
			<p class="mvweb-t-page-hero__meta" data-hero-meta>
				<?php foreach ( $mvweb_meta as $mvweb_fact ) : ?>
					<span><?php echo esc_html( $mvweb_fact ); ?></span>
				<?php endforeach; ?>
			</p>
		<?php endif; ?>

		<?php echo (string) $mvweb_args['after']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup the calling template has escaped itself. ?>

		<?php if ( $mvweb_boxed ) : ?>
				</div>
				<div class="mvweb-t-page-hero__pic">
				<?php
				echo wp_get_attachment_image(
					$mvweb_image,
					'large',
					false,
					array(
						'sizes'         => '(max-width: 960px) 100vw, 50vw',
						'decoding'      => 'async',
						'loading'       => false,
						'fetchpriority' => 'high',
					)
				);
				?>
				</div>
			</div>
		<?php endif; ?>
		</div>
	</div>
</section>
