<?php
/**
 * Footer contacts: the messengers of the profile as icons.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_chats = mvweb_cz_profile_chats();

if ( empty( $mvweb_chats ) ) {
	return;
}
?>
<li class="mvweb-t-footer__item">
	<span class="mvweb-t-footer__note"><?php esc_html_e( 'Write to a messenger', 'journal' ); ?></span>
	<div class="mvweb-t-msgs mvweb-t-msgs--icons">
		<?php foreach ( $mvweb_chats as $mvweb_id => $mvweb_link ) : ?>
			<a href="<?php echo esc_url( $mvweb_link['url'] ); ?>" data-brand="<?php echo esc_attr( mvweb_core_social_icon( $mvweb_id ) ); ?>" title="<?php echo esc_attr( $mvweb_link['label'] ); ?>" rel="noopener" target="_blank">
				<?php echo mvweb_theme_icon( mvweb_core_social_icon( $mvweb_id ), array( 'class' => 'mvweb-t-icon--brand' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php echo esc_html( $mvweb_link['label'] ); ?></span>
			</a>
		<?php endforeach; ?>
	</div>
</li>
