<?php
/**
 * Under the text of a post, part: the previous and the next post.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_prev = get_previous_post();
$mvweb_next = get_next_post();

if ( ! $mvweb_prev instanceof WP_Post && ! $mvweb_next instanceof WP_Post ) {
	return;
}
?>
<nav class="mvweb-t-pn" aria-label="<?php esc_attr_e( 'Other posts', 'journal' ); ?>">
	<?php if ( $mvweb_prev instanceof WP_Post ) : ?>
		<a class="mvweb-t-pn__link" href="<?php echo esc_url( get_permalink( $mvweb_prev ) ); ?>" rel="prev">
			<small><?php echo mvweb_theme_icon( 'chevron-left', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?><?php esc_html_e( 'Previous', 'journal' ); ?></small>
			<b><?php echo esc_html( get_the_title( $mvweb_prev ) ); ?></b>
		</a>
	<?php endif; ?>
	<?php if ( $mvweb_next instanceof WP_Post ) : ?>
		<a class="mvweb-t-pn__link mvweb-t-pn__link--next" href="<?php echo esc_url( get_permalink( $mvweb_next ) ); ?>" rel="next">
			<small><?php esc_html_e( 'Next', 'journal' ); ?><?php echo mvweb_theme_icon( 'chevron-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></small>
			<b><?php echo esc_html( get_the_title( $mvweb_next ) ); ?></b>
		</a>
	<?php endif; ?>
</nav>
