<?php
/**
 * Under the text of a post, part: «Was the article helpful?».
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_attrs = mvweb_core_helpful_attrs();

if ( '' === $mvweb_attrs ) {
	return;
}

$mvweb_votes = array(
	'yes' => __( 'Yes', 'journal' ),
	'no'  => __( 'No', 'journal' ),
);
?>
<div class="mvweb-t-helpful" role="group" aria-labelledby="mvweb-t-helpful-title"<?php echo $mvweb_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The core escapes the attributes. ?>>
	<div class="mvweb-t-helpful__q" id="mvweb-t-helpful-title"><?php esc_html_e( 'Was the article helpful?', 'journal' ); ?></div>
	<div class="mvweb-t-helpful__btns">
		<?php foreach ( $mvweb_votes as $mvweb_vote => $mvweb_label ) : ?>
			<button class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-btn--sm mvweb-t-helpful__vote--<?php echo esc_attr( $mvweb_vote ); ?>" type="button" data-helpful-vote="<?php echo esc_attr( $mvweb_vote ); ?>" aria-pressed="false">
				<?php echo mvweb_theme_icon( 'thumb-up', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<?php echo esc_html( $mvweb_label ); ?>
			</button>
		<?php endforeach; ?>
	</div>
	<p class="mvweb-t-helpful__status" data-helpful-status role="status"></p>
</div>
