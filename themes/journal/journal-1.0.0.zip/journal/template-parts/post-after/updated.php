<?php
/**
 * Under the text of a post, part: «Article updated» with the date of the last change, a day or more after the publication.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( (int) get_post_modified_time( 'U', true ) - (int) get_post_time( 'U', true ) < DAY_IN_SECONDS ) {
	return;
}
?>
<p class="mvweb-t-updated">
	<?php
	echo mvweb_theme_icon( 'refresh', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
	printf(
		/* translators: %s: date of the last change. */
		esc_html__( 'Article updated %s', 'journal' ),
		'<time datetime="' . esc_attr( get_the_modified_date( 'c' ) ) . '">' . esc_html( get_the_modified_date() ) . '</time>'
	);
	?>
</p>
