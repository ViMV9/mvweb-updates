<?php
/**
 * Under the text of a post, part: the subscription — the networks of the site and the window with all of them and the mailing.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_subscribe = mvweb_core_subscribe();

if ( empty( $mvweb_subscribe ) ) {
	return;
}
?>
<div class="mvweb-t-follow-box">
	<div class="mvweb-t-follow-box__text">
		<div class="mvweb-t-h4" role="heading" aria-level="2"><?php esc_html_e( 'Do not miss new articles', 'journal' ); ?></div>
		<p><?php esc_html_e( 'Subscribe where it suits you to read.', 'journal' ); ?></p>
	</div>
	<?php
	mvweb_theme_follow( $mvweb_subscribe['socials'], 'buttons', 6 );
	mvweb_theme_meta_note( array_slice( $mvweb_subscribe['socials'], 0, 6, true ) );
	?>
	<?php if ( $mvweb_subscribe['form'] || count( $mvweb_subscribe['socials'] ) > 6 ) : ?>
		<button class="mvweb-t-btn mvweb-t-btn--ghost mvweb-t-btn--sm" type="button" popovertarget="mvweb-t-subpop" data-popover-trigger="mvweb-t-subpop"><?php echo esc_html( $mvweb_subscribe['form'] ? __( 'All social networks and mailing', 'journal' ) : __( 'All social networks', 'journal' ) ); ?></button>
	<?php endif; ?>
</div>
