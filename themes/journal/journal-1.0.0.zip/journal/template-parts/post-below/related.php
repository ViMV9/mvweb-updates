<?php
/**
 * Bands under a post, part: more posts — of the category, then of the tags, then the newest.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_ids = mvweb_core_related_posts( get_the_ID(), absint( mvweb_core_blog_option( 'mvweb_post_related_count' ) ) );

if ( empty( $mvweb_ids ) ) {
	return;
}

$mvweb_view  = isset( $args['view'] ) ? (string) $args['view'] : '1';
$mvweb_title = trim( (string) mvweb_core_blog_option( 'mvweb_post_related_title' ) );
$mvweb_link  = trim( (string) mvweb_core_blog_option( 'mvweb_post_related_link' ) );
$mvweb_url   = mvweb_core_blog_url( get_the_ID() );
$mvweb_hide  = array( 'lead', 'author', 'date', 'comments', 'views', 'more' );
$mvweb_forms = array(
	'1' => array( 'four', '', array(), '(min-width: 1024px) 25vw, (min-width: 600px) 50vw, 100vw' ),
	'2' => array( 'three', '', array( 'lead' ), '(min-width: 1024px) 33vw, (min-width: 600px) 50vw, 100vw' ),
	'3' => array( 'two', 'row', array(), '160px' ),
	'4' => array( 'four', 'card', array(), '(min-width: 1024px) 25vw, (min-width: 600px) 50vw, 100vw' ),
	'5' => array( 'text', 'text', array(), '' ),
);
$mvweb_form  = isset( $mvweb_forms[ $mvweb_view ] ) ? $mvweb_forms[ $mvweb_view ] : $mvweb_forms['1'];
$mvweb_hide  = array_values( array_diff( $mvweb_hide, $mvweb_form[2] ) );

if ( '5' === $mvweb_view ) {
	$mvweb_hide[] = 'media';
}

if ( '' === $mvweb_url ) {
	$mvweb_link = '';
}

$mvweb_query = new WP_Query(
	array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'post__in'            => $mvweb_ids,
		'orderby'             => 'post__in',
		'posts_per_page'      => count( $mvweb_ids ),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	)
);

update_post_thumbnail_cache( $mvweb_query );
?>
<section class="mvweb-t-section mvweb-t-related">
	<div class="mvweb-t-container">
		<?php if ( '' !== $mvweb_title || '' !== $mvweb_link ) : ?>
			<div class="mvweb-t-section__head">
				<?php if ( '' !== $mvweb_title ) : ?>
					<div><div class="mvweb-t-h2" role="heading" aria-level="2"><?php echo esc_html( $mvweb_title ); ?></div></div>
				<?php endif; ?>
				<?php if ( '' !== $mvweb_link ) : ?>
					<a class="mvweb-t-section__more" href="<?php echo esc_url( $mvweb_url ); ?>"><?php echo esc_html( $mvweb_link ); ?><?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></a>
				<?php endif; ?>
			</div>
		<?php endif; ?>
		<div class="mvweb-t-related__list mvweb-t-related__list--<?php echo esc_attr( $mvweb_form[0] ); ?>">
			<?php
			while ( $mvweb_query->have_posts() ) :
				$mvweb_query->the_post();

				get_template_part(
					'template-parts/post-card',
					null,
					array(
						'modifier' => $mvweb_form[1],
						'hide'     => $mvweb_hide,
						'sizes'    => $mvweb_form[3],
					)
				);
			endwhile;
			wp_reset_postdata();
			?>
		</div>
	</div>
</section>
