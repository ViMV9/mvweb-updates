<?php
/**
 * The window of the subscription: all the social networks, the note about Meta and the mailing form.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_subscribe = mvweb_core_subscribe();

if ( empty( $mvweb_subscribe ) ) {
	return;
}

$mvweb_form = $mvweb_subscribe['form'] ? mvweb_core_subscribe_form() : '';
?>
<div class="mvweb-t-subpop" id="mvweb-t-subpop" popover data-popover role="dialog" aria-labelledby="mvweb-t-subpop-title">
	<div class="mvweb-t-subpop__head">
		<div class="mvweb-t-h4" id="mvweb-t-subpop-title"><?php echo esc_html( $mvweb_subscribe['label'] ); ?></div>
		<button class="mvweb-t-icon-btn" type="button" popovertarget="mvweb-t-subpop" popovertargetaction="hide" data-popover-close title="<?php esc_attr_e( 'Close', 'journal' ); ?>">
			<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span class="screen-reader-text"><?php esc_html_e( 'Close', 'journal' ); ?></span>
		</button>
	</div>

	<?php mvweb_theme_follow( $mvweb_subscribe['socials'], 'list' ); ?>

	<?php if ( '' !== $mvweb_subscribe['note'] ) : ?>
		<p class="mvweb-t-meta-note"><?php echo esc_html( $mvweb_subscribe['note'] ); ?></p>
	<?php endif; ?>

	<?php if ( '' !== $mvweb_form ) : ?>
		<div class="mvweb-t-subpop__mail">
			<div class="mvweb-t-subpop__cap"><?php echo empty( $mvweb_subscribe['socials'] ) ? esc_html__( 'By e-mail', 'journal' ) : esc_html__( 'Or by e-mail', 'journal' ); ?></div>
			<?php echo $mvweb_form; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the mailing plugin. ?>
		</div>
	<?php endif; ?>
</div>
