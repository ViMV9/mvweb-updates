<?php
/**
 * Block about the author, part: the links of the author.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_links = mvweb_core_author_links( isset( $args['author'] ) ? absint( $args['author'] ) : 0 );

if ( empty( $mvweb_links ) ) {
	return;
}
?>
<ul class="mvweb-t-author-box__links">
	<?php foreach ( $mvweb_links as $mvweb_link ) : ?>
		<?php
		/* translators: %s: name of a network or a mail. */
		$mvweb_label = sprintf( __( '%s of the author', 'journal' ), $mvweb_link['label'] );
		?>
		<li>
			<a class="mvweb-t-author-box__link" href="<?php echo esc_url( $mvweb_link['url'] ); ?>"<?php echo 0 === strpos( $mvweb_link['url'], 'http' ) ? ' target="_blank" rel="noopener"' : ''; ?> title="<?php echo esc_attr( $mvweb_label ); ?>">
				<?php echo mvweb_theme_icon( $mvweb_link['icon'], array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php echo esc_html( $mvweb_label ); ?></span>
			</a>
		</li>
	<?php endforeach; ?>
</ul>
