<?php
/**
 * Block about the author, part: the link to all posts of the author.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_author = isset( $args['author'] ) ? absint( $args['author'] ) : 0;

if ( 0 === $mvweb_author ) {
	return;
}
?>
<a class="mvweb-t-section__more" href="<?php echo esc_url( get_author_posts_url( $mvweb_author ) ); ?>"><?php esc_html_e( 'All posts of the author', 'journal' ); ?><?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></a>
