<?php
/**
 * Page not found part: the most read articles.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_ids = wp_list_pluck( mvweb_core_top_posts( 3 ), 'ID' );

if ( empty( $mvweb_ids ) ) {
	return;
}

get_template_part(
	'template-parts/notfound/list',
	null,
	array(
		'ids'      => $mvweb_ids,
		'title'    => __( 'Most read', 'journal' ),
		'class'    => 'mvweb-t-404__rows',
		'modifier' => 'row sm',
		'hide'     => array( 'lead', 'topic', 'more', 'author', 'date', 'read', 'comments' ),
		'sizes'    => '96px',
	)
);
