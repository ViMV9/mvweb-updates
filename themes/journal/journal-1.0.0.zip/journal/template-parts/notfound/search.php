<?php
/**
 * Page not found part: the search field.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! get_theme_mod( 'mvweb_404_search', true ) ) {
	return;
}

get_search_form();
