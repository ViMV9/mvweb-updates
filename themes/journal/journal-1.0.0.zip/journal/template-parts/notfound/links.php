<?php
/**
 * Page not found part: links to the main sections of the site that exist on it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_links   = array( home_url( '/' ) => __( 'Home', 'journal' ) );
$mvweb_blog    = mvweb_core_blog_url();
$mvweb_sitemap = mvweb_core_sitemap_page_ids();
$mvweb_contact = get_posts(
	array(
		'post_type'        => 'page',
		'post_status'      => 'publish',
		'fields'           => 'ids',
		'numberposts'      => 1,
		'meta_key'         => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- One page, looked up only on the page not found.
		'meta_value'       => 'page-templates/contacts.php', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- One page, looked up only on the page not found.
		'no_found_rows'    => true,
		'suppress_filters' => true,
	)
);

if ( '' !== $mvweb_blog ) {
	$mvweb_links[ $mvweb_blog ] = __( 'All articles', 'journal' );
}

if ( ! empty( $mvweb_sitemap ) && 'publish' === get_post_status( $mvweb_sitemap[0] ) ) {
	$mvweb_links[ (string) get_permalink( $mvweb_sitemap[0] ) ] = __( 'Sitemap', 'journal' );
}

if ( ! empty( $mvweb_contact ) ) {
	$mvweb_links[ (string) get_permalink( $mvweb_contact[0] ) ] = __( 'Contacts', 'journal' );
}
?>
<nav class="mvweb-t-404__links" aria-label="<?php esc_attr_e( 'Sections of the site', 'journal' ); ?>">
	<?php foreach ( $mvweb_links as $mvweb_url => $mvweb_label ) : ?>
		<a href="<?php echo esc_url( $mvweb_url ); ?>"><?php echo esc_html( $mvweb_label ); ?></a>
	<?php endforeach; ?>
</nav>
