<?php
/**
 * Page not found part: the categories of the blog with the number of articles.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_terms = get_categories(
	array(
		'hide_empty' => true,
		'orderby'    => 'count',
		'order'      => 'DESC',
		'number'     => 12,
	)
);

if ( empty( $mvweb_terms ) || ! is_array( $mvweb_terms ) ) {
	return;
}
?>
<div class="mvweb-t-404__list">
	<div class="mvweb-t-404__caption mvweb-t-h5"><?php esc_html_e( 'Or choose a category', 'journal' ); ?></div>
	<nav class="mvweb-t-chips" aria-label="<?php esc_attr_e( 'Categories', 'journal' ); ?>">
		<?php foreach ( $mvweb_terms as $mvweb_term ) : ?>
			<a class="mvweb-t-chip" href="<?php echo esc_url( (string) get_category_link( $mvweb_term ) ); ?>"><?php echo esc_html( $mvweb_term->name ); ?> <span class="mvweb-t-chip__n"><?php echo esc_html( number_format_i18n( (int) $mvweb_term->count ) ); ?></span></a>
		<?php endforeach; ?>
	</nav>
</div>
