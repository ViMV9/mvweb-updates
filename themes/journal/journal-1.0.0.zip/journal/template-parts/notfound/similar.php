<?php
/**
 * Page not found part: the articles whose words match the words of the missing address.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_ids = mvweb_core_notfound_similar( 3 );

if ( empty( $mvweb_ids ) ) {
	return;
}

get_template_part(
	'template-parts/notfound/list',
	null,
	array(
		'ids'      => $mvweb_ids,
		'title'    => __( 'Perhaps you were looking for', 'journal' ),
		'class'    => 'mvweb-t-404__grid',
		'modifier' => '',
		'hide'     => array( 'lead', 'more', 'author', 'date', 'comments', 'views' ),
		'sizes'    => '(min-width: 1024px) 22vw, (min-width: 600px) 50vw, 100vw',
	)
);
