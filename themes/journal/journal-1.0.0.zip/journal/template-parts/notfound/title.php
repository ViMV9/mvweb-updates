<?php
/**
 * Page not found part: the code over the heading and the h1; with the argument hidden only the h1 for screen readers.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_title = trim( (string) get_theme_mod( 'mvweb_404_title', '' ) );
$mvweb_title = '' !== $mvweb_title ? $mvweb_title : __( 'Page not found', 'journal' );
$mvweb_view  = isset( $args['view'] ) ? (string) $args['view'] : '';

if ( ! empty( $args['hidden'] ) ) {
	printf( '<h1 class="screen-reader-text">%s</h1>', esc_html( $mvweb_title ) );
	return;
}
?>
<?php if ( in_array( $mvweb_view, array( '1', '4' ), true ) ) : ?>
	<span class="mvweb-t-404__num" aria-hidden="true"><?php echo esc_html( number_format_i18n( 404 ) ); ?></span>
<?php elseif ( '5' === $mvweb_view ) : ?>
	<p class="mvweb-t-404__code">
		<?php
		/* translators: %s: error code. */
		echo esc_html( sprintf( __( 'Error %s', 'journal' ), number_format_i18n( 404 ) ) );
		?>
	</p>
<?php endif; ?>
<h1 class="mvweb-t-404__title"><?php echo esc_html( $mvweb_title ); ?></h1>
