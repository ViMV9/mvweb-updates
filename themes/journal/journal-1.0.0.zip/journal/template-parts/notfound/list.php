<?php
/**
 * A list of articles on the page not found. Arguments: ids, title, class, modifier, hide, sizes.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_ids = isset( $args['ids'] ) ? array_filter( array_map( 'absint', (array) $args['ids'] ) ) : array();

if ( empty( $mvweb_ids ) ) {
	return;
}

$mvweb_box = new WP_Query(
	array(
		'post__in'            => $mvweb_ids,
		'post_type'           => 'any',
		'orderby'             => 'post__in',
		'posts_per_page'      => count( $mvweb_ids ),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	)
);

if ( ! $mvweb_box->have_posts() ) {
	return;
}
?>
<div class="mvweb-t-404__list">
	<?php if ( ! empty( $args['title'] ) ) : ?>
		<div class="mvweb-t-404__caption mvweb-t-h5"><?php echo esc_html( (string) $args['title'] ); ?></div>
	<?php endif; ?>
	<div class="<?php echo esc_attr( isset( $args['class'] ) ? (string) $args['class'] : '' ); ?>">
		<?php
		while ( $mvweb_box->have_posts() ) :
			$mvweb_box->the_post();

			get_template_part(
				'template-parts/post-card',
				null,
				array(
					'modifier' => isset( $args['modifier'] ) ? (string) $args['modifier'] : '',
					'hide'     => isset( $args['hide'] ) ? (array) $args['hide'] : array(),
					'sizes'    => isset( $args['sizes'] ) ? (string) $args['sizes'] : '',
				)
			);
		endwhile;

		wp_reset_postdata();
		?>
	</div>
</div>
