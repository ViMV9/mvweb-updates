<?php
/**
 * Sitemap, look «Columns of sections»: under the name of every kind its sections stand in columns, the subsections marked by a line on the left.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_group = static function ( array $group, $sub ) use ( &$mvweb_group ) {
	?>
	<div class="<?php echo $sub ? 'mvweb-t-sm-cols__sub' : 'mvweb-t-sm-cols__group'; ?>">
		<div class="<?php echo $sub ? 'mvweb-t-sm-cols__subname' : 'mvweb-t-sm-cols__name'; ?>">
			<?php echo mvweb_theme_sitemap_link( $group ) . mvweb_theme_sitemap_count( $group['total'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers. ?>
		</div>
		<?php if ( $group['items'] ) : ?>
			<ul class="mvweb-t-sm-cols__list">
				<?php foreach ( $group['items'] as $mvweb_item ) : ?>
					<li><?php echo mvweb_theme_sitemap_link( $mvweb_item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?></li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
		<?php
		echo mvweb_theme_sitemap_more( $group ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper.

		foreach ( $group['subs'] as $mvweb_sub ) {
			$mvweb_group( $mvweb_sub, true );
		}
		?>
	</div>
	<?php
};
?>
<div class="mvweb-t-sitemap mvweb-t-sm-cols">
	<?php foreach ( $args['types'] as $mvweb_type ) : ?>
		<div class="mvweb-t-sm-cols__type">
			<div class="mvweb-t-sm-cols__head">
				<?php echo mvweb_theme_sitemap_title( $mvweb_type, 'mvweb-t-sm-cols__title' ) . mvweb_theme_sitemap_count( $mvweb_type['total'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers. ?>
			</div>

			<?php if ( $mvweb_type['groups'] ) : ?>
				<div class="mvweb-t-sm-cols__cols">
					<?php
					foreach ( $mvweb_type['groups'] as $mvweb_item ) {
						$mvweb_group( $mvweb_item, false );
					}
					?>
				</div>
			<?php else : ?>
				<ul class="mvweb-t-sm-cols__flat">
					<?php foreach ( $mvweb_type['items'] as $mvweb_item ) : ?>
						<li><?php echo mvweb_theme_sitemap_link( $mvweb_item ) . mvweb_theme_sitemap_count( isset( $mvweb_item['n'] ) ? $mvweb_item['n'] : 0 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers. ?></li>
					<?php endforeach; ?>
				</ul>
				<?php echo mvweb_theme_sitemap_more( $mvweb_type ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>
</div>
