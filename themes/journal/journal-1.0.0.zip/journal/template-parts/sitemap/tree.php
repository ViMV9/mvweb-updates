<?php
/**
 * Sitemap, look «Tree»: the kinds open, their sections folded; inside a section the link to the whole section, its subsections and entries.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_chev = mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm mvweb-t-sm-tree__chev' ) );

$mvweb_leaf = static function ( array $item, $css = 'mvweb-t-sm-tree__link' ) {
	echo '<li class="mvweb-t-sm-tree__leaf">' . mvweb_theme_sitemap_link( $item, $css ) . mvweb_theme_sitemap_count( isset( $item['n'] ) ? $item['n'] : 0 ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers.
};

$mvweb_node = static function ( array $group ) use ( &$mvweb_node, $mvweb_leaf, $mvweb_chev ) {
	$more = mvweb_theme_sitemap_more( $group );

	if ( ! $group['subs'] && ! $group['items'] && '' === $more ) {
		$mvweb_leaf(
			array(
				'name' => $group['name'],
				'url'  => $group['url'],
				'n'    => $group['total'],
			),
			'mvweb-t-sm-tree__link mvweb-t-sm-tree__link--group'
		);

		return;
	}
	?>
	<li>
		<details class="mvweb-t-sm-tree__node">
			<summary class="mvweb-t-sm-tree__sum">
				<?php echo '<span>' . esc_html( $group['name'] ) . '</span>' . mvweb_theme_sitemap_count( $group['total'] ) . $mvweb_chev; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers. ?>
			</summary>
			<ul class="mvweb-t-sm-tree__tree">
				<?php if ( '' !== $group['url'] ) : ?>
					<li class="mvweb-t-sm-tree__leaf">
						<a class="mvweb-t-sm-tree__open" href="<?php echo esc_url( $group['url'] ); ?>">
							<?php
							/* translators: %s: name of a section of the site. */
							echo esc_html( sprintf( __( 'Whole section «%s»', 'journal' ), $group['name'] ) );
							?>
						</a>
					</li>
				<?php endif; ?>
				<?php
				foreach ( $group['subs'] as $mvweb_sub ) {
					$mvweb_node( $mvweb_sub );
				}

				foreach ( $group['items'] as $mvweb_item ) {
					$mvweb_leaf( $mvweb_item );
				}
				?>
				<?php if ( '' !== $more ) : ?>
					<li class="mvweb-t-sm-tree__leaf"><?php echo $more; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?></li>
				<?php endif; ?>
			</ul>
		</details>
	</li>
	<?php
};
?>
<div class="mvweb-t-sitemap mvweb-t-sm-tree">
	<?php foreach ( $args['types'] as $mvweb_type ) : ?>
		<details class="mvweb-t-sm-tree__type" open>
			<summary class="mvweb-t-sm-tree__tsum">
				<?php echo '<span>' . esc_html( $mvweb_type['label'] ) . '</span>' . mvweb_theme_sitemap_count( $mvweb_type['total'] ) . $mvweb_chev; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers. ?>
			</summary>
			<div class="mvweb-t-sm-tree__body">
				<?php if ( $mvweb_type['archive'] ) : ?>
					<a class="mvweb-t-sm-tree__all" href="<?php echo esc_url( $mvweb_type['archive']['url'] ); ?>"><?php echo esc_html( $mvweb_type['archive']['name'] ) . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Icon markup of the theme. ?></a>
				<?php endif; ?>
				<ul class="mvweb-t-sm-tree__tree">
					<?php
					foreach ( $mvweb_type['groups'] as $mvweb_group ) {
						$mvweb_node( $mvweb_group );
					}

					foreach ( $mvweb_type['items'] as $mvweb_item ) {
						$mvweb_leaf( $mvweb_item );
					}
					?>
					<?php if ( '' !== mvweb_theme_sitemap_more( $mvweb_type ) ) : ?>
						<li class="mvweb-t-sm-tree__leaf"><?php echo mvweb_theme_sitemap_more( $mvweb_type ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?></li>
					<?php endif; ?>
				</ul>
			</div>
		</details>
	<?php endforeach; ?>
</div>
