<?php
/**
 * Sitemap, look «Contents»: numbered contents as in a book, the number of entries after a dotted leader.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_row = static function ( $number, array $item, $count, $css ) {
	$dots = '' !== $count ? '<span class="mvweb-t-sm-toc__dots" aria-hidden="true"></span>' . $count : '';
	$num  = '' !== $number ? '<span class="mvweb-t-sm-toc__num">' . esc_html( $number ) . '</span>' : '';

	printf(
		'<li class="%1$s"><div class="mvweb-t-sm-toc__row">%2$s%3$s%4$s</div>',
		esc_attr( $css ),
		$num, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above.
		mvweb_theme_sitemap_link( $item, 'mvweb-t-sm-toc__name' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper.
		$dots // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper.
	);
};

$mvweb_walk = static function ( array $groups, $prefix ) use ( &$mvweb_walk, $mvweb_row ) {
	foreach ( $groups as $at => $group ) {
		$number = $prefix . '.' . ( $at + 1 );
		$more   = mvweb_theme_sitemap_more( $group );

		$mvweb_row( $number, $group, mvweb_theme_sitemap_count( $group['total'] ), 'mvweb-t-sm-toc__group' );

		if ( $group['subs'] || $group['items'] || '' !== $more ) {
			echo '<ol class="mvweb-t-sm-toc__list">';

			$mvweb_walk( $group['subs'], $number );

			foreach ( $group['items'] as $item ) {
				$mvweb_row( '', $item, '', 'mvweb-t-sm-toc__item' );
				echo '</li>';
			}

			if ( '' !== $more ) {
				echo '<li class="mvweb-t-sm-toc__more">' . $more . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper.
			}

			echo '</ol>';
		}

		echo '</li>';
	}
};
?>
<div class="mvweb-t-sitemap mvweb-t-sm-toc">
	<ol class="mvweb-t-sm-toc__toc">
		<?php foreach ( $args['types'] as $mvweb_at => $mvweb_type ) : ?>
			<li class="mvweb-t-sm-toc__type" id="mvweb-sm-<?php echo esc_attr( $mvweb_type['key'] ); ?>">
				<div class="mvweb-t-sm-toc__thead">
					<span class="mvweb-t-sm-toc__num"><?php echo esc_html( (string) ( $mvweb_at + 1 ) ); ?></span>
					<?php echo mvweb_theme_sitemap_title( $mvweb_type, 'mvweb-t-sm-toc__name' ) . mvweb_theme_sitemap_count( $mvweb_type['total'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers. ?>
				</div>
				<ol class="mvweb-t-sm-toc__list">
					<?php
					$mvweb_walk( $mvweb_type['groups'], (string) ( $mvweb_at + 1 ) );

					foreach ( $mvweb_type['items'] as $mvweb_item ) {
						$mvweb_row( '', $mvweb_item, mvweb_theme_sitemap_count( isset( $mvweb_item['n'] ) ? $mvweb_item['n'] : 0 ), 'mvweb-t-sm-toc__item' );
						echo '</li>';
					}

					if ( '' !== mvweb_theme_sitemap_more( $mvweb_type ) ) {
						echo '<li class="mvweb-t-sm-toc__more">' . mvweb_theme_sitemap_more( $mvweb_type ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper.
					}
					?>
				</ol>
			</li>
		<?php endforeach; ?>
	</ol>
</div>
