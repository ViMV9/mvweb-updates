<?php
/**
 * The frame of the profile map: a still picture or an embedded map.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_map  = isset( $args['map'] ) && is_array( $args['map'] ) ? $args['map'] : mvweb_core_profile_map();
$mvweb_name = isset( $args['name'] ) && '' !== $args['name'] ? (string) $args['name'] : __( 'Map', 'journal' );
$mvweb_look = isset( $args['class'] ) ? ' ' . trim( (string) $args['class'] ) : '';
?>
<?php if ( '' !== $mvweb_map['image'] ) : ?>
	<div class="<?php echo esc_attr( 'mvweb-t-map-frame mvweb-t-map-frame--image' . $mvweb_look ); ?>">
		<?php
		$mvweb_map_id = isset( $mvweb_map['image_id'] ) ? (int) $mvweb_map['image_id'] : 0;

		if ( $mvweb_map_id ) {
			echo wp_get_attachment_image(
				$mvweb_map_id,
				'full',
				false,
				array(
					'alt'      => $mvweb_name,
					'loading'  => 'lazy',
					'decoding' => 'async',
					'sizes'    => isset( $args['sizes'] ) ? (string) $args['sizes'] : '100vw',
				)
			);
		} else {
			printf( '<img src="%1$s" alt="%2$s" loading="lazy" decoding="async">', esc_url( $mvweb_map['image'] ), esc_attr( $mvweb_name ) );
		}
		?>
	</div>
<?php elseif ( '' !== $mvweb_map['src'] ) : ?>
	<div class="<?php echo esc_attr( 'mvweb-t-map-frame' . $mvweb_look ); ?>">
		<iframe src="<?php echo esc_url( $mvweb_map['src'] ); ?>" title="<?php echo esc_attr( $mvweb_name ); ?>" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>
	</div>
<?php endif; ?>
