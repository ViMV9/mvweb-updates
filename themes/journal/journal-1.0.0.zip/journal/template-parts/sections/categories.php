<?php
/**
 * Section template: groups with links.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block  = mvweb_theme_block( 'categories', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props  = $mvweb_block['props'];
$mvweb_view   = $mvweb_block['mod'];
$mvweb_source = isset( $mvweb_props['source'] ) ? (string) $mvweb_props['source'] : 'manual';
$mvweb_cards  = array();
$mvweb_sizes  = array(
	'mosaic'  => '(min-width: 1024px) 25vw, 50vw',
	'grid'    => '(min-width: 600px) 33vw, 50vw',
	'circles' => '136px',
	'rows'    => '72px',
);
$mvweb_size   = isset( $mvweb_sizes[ $mvweb_view ] ) ? $mvweb_sizes[ $mvweb_view ] : '50vw';

$mvweb_small = 'circles' === $mvweb_view || 'rows' === $mvweb_view;

$mvweb_img = static function ( $id, $sizes ) use ( $mvweb_small ) {
	return wp_attachment_is_image( $id ) ? (string) wp_get_attachment_image(
		$id,
		$mvweb_small ? 'medium' : 'large',
		false,
		array(
			'alt'     => '',
			'loading' => 'lazy',
			'sizes'   => $sizes,
		)
	) : '';
};

if ( 'blog_cat' === $mvweb_source && function_exists( 'mvweb_core_blog_children' ) ) {
	$mvweb_count = isset( $mvweb_props['count'] ) ? max( 1, min( 24, absint( $mvweb_props['count'] ) ) ) : 6;

	foreach ( array_slice( mvweb_core_blog_children( 0, 'count' ), 0, $mvweb_count ) as $mvweb_index => $mvweb_term ) {
		$mvweb_url = get_term_link( $mvweb_term );

		if ( is_wp_error( $mvweb_url ) ) {
			continue;
		}

		$mvweb_cards[] = array(
			'title'   => $mvweb_term->name,
			'url'     => $mvweb_url,
			'text'    => implode( ', ', wp_list_pluck( mvweb_core_blog_children( $mvweb_term->term_id ), 'name' ) ),
			'note'    => mvweb_core_articles( (int) $mvweb_term->count ),
			'pic'     => mvweb_core_term_picture( $mvweb_term, $mvweb_small ? 'medium' : 'large' ),
			'pic_2'   => '',
			'wide'    => 0 === $mvweb_index,
			'bg'      => array(),
			'pattern' => array(),
		);
	}
} else {
	foreach ( mvweb_core_categories_cards( $mvweb_props ) as $mvweb_card ) {
		$mvweb_card['pic']   = $mvweb_img( $mvweb_card['image'], $mvweb_size );
		$mvweb_card['pic_2'] = $mvweb_img( $mvweb_card['image_2'], $mvweb_size );
		$mvweb_cards[]       = $mvweb_card;
	}
}

if ( empty( $mvweb_cards ) ) {
	return;
}

if ( '' === trim( (string) ( isset( $mvweb_props['link_url'] ) ? $mvweb_props['link_url'] : '' ) ) ) {
	$mvweb_link = function_exists( 'mvweb_core_blog_url' ) ? mvweb_core_blog_url() : '';

	if ( '' === $mvweb_link && function_exists( 'mvweb_core_sitemap_page_ids' ) ) {
		foreach ( mvweb_core_sitemap_page_ids() as $mvweb_page ) {
			if ( 'publish' === get_post_status( $mvweb_page ) ) {
				$mvweb_link = (string) get_permalink( $mvweb_page );
				break;
			}
		}
	}

	$mvweb_block['props']['link_url'] = $mvweb_link;
}

$mvweb_tones    = array( 'accent', 'soft', 'inverse', 'surface', 'soft', 'accent' );
$mvweb_patterns = array( 'dots', 'grid', 'lines', 'waves', 'zigzag', 'plus' );
$mvweb_order    = $mvweb_block['item_parts'];
$mvweb_base     = 'mvweb-t-categories__';

$mvweb_list = static function () use ( $mvweb_cards, $mvweb_view, $mvweb_source, $mvweb_order, $mvweb_base, $mvweb_tones, $mvweb_patterns ) {
	$html = '<div class="' . $mvweb_base . 'list">';

	foreach ( $mvweb_cards as $index => $card ) {
		$wide  = 'mosaic' === $mvweb_view && $card['wide'];
		$class = $mvweb_base . 'card' . ( $wide ? ' ' . $mvweb_base . 'card--wide' : '' );
		$attr  = '';

		if ( 'pattern' === $mvweb_view ) {
			$style   = '';
			$pattern = $card['pattern'];

			if ( empty( $pattern ) && 'blog_cat' === $mvweb_source ) {
				$pattern = array(
					'name'    => $mvweb_patterns[ $index % count( $mvweb_patterns ) ],
					'tile'    => '',
					'repeat'  => 'repeat',
					'opacity' => 12,
				);
			}

			if ( ! empty( $card['bg'] ) ) {
				$class .= ' ' . $mvweb_base . 'card--own';
				$style .= '--mvweb-t-card-bg:' . $card['bg']['bg'] . ';--mvweb-t-card-ink:' . $card['bg']['ink'] . ';';
			} else {
				$attr .= ' data-tone="' . esc_attr( $mvweb_tones[ $index % count( $mvweb_tones ) ] ) . '"';
			}

			if ( ! empty( $pattern ) ) {
				$attr  .= ' data-pattern="' . esc_attr( $pattern['name'] ) . '" data-pattern-repeat="' . esc_attr( $pattern['repeat'] ) . '"';
				$style .= '--mvweb-t-card-pattern-opacity:' . ( $pattern['opacity'] / 100 ) . ';' . ( '' !== $pattern['tile'] ? '--mvweb-t-card-pattern-tile:url("' . esc_url_raw( $pattern['tile'] ) . '");' : '' );
			}

			$attr .= '' !== $style ? ' style="' . esc_attr( $style ) . '"' : '';
		}

		$texts = array(
			'before' => '',
			'after'  => '',
		);
		$pics  = '';
		$place = 'before';

		foreach ( $mvweb_order as $slug ) {
			if ( 'title' === $slug ) {
				$texts[ $place ] .= '<span class="' . $mvweb_base . 'name">' . esc_html( $card['title'] ) . '</span>';
			} elseif ( 'count' === $slug && '' !== $card['note'] ) {
				$texts[ $place ] .= '<span class="' . $mvweb_base . 'note">' . esc_html( $card['note'] ) . '</span>';
			} elseif ( 'desc' === $slug && '' !== $card['text'] && ( $wide || in_array( $mvweb_view, array( 'pattern', 'rows' ), true ) ) ) {
				$texts[ $place ] .= '<span class="' . $mvweb_base . 'desc">' . esc_html( $card['text'] ) . '</span>';
			} elseif ( 'image' === $slug && '' !== $card['pic'] && 'pattern' !== $mvweb_view ) {
				$pics  = '<span class="mvweb-t-cover ' . $mvweb_base . 'pic">' . $card['pic'] . '</span>';
				$pics .= $wide && '' !== $card['pic_2'] ? '<span class="mvweb-t-cover ' . $mvweb_base . 'pic">' . $card['pic_2'] . '</span>' : '';
				$pics  = $wide ? '<span class="' . $mvweb_base . 'pics">' . $pics . '</span>' : $pics;
				$place = 'after';
			}
		}

		if ( ! in_array( 'title', $mvweb_order, true ) ) {
			$texts[ $place ] .= '<span class="screen-reader-text">' . esc_html( $card['title'] ) . '</span>';
		}

		$inner  = '' !== $texts['before'] ? '<span class="' . $mvweb_base . 'body">' . $texts['before'] . '</span>' : '';
		$inner .= $pics;
		$inner .= '' !== $texts['after'] ? '<span class="' . $mvweb_base . 'body">' . $texts['after'] . '</span>' : '';

		if ( 'rows' === $mvweb_view && '' !== $card['url'] ) {
			$inner .= mvweb_theme_icon( 'arrow-right', array( 'class' => $mvweb_base . 'arrow' ) );
		}

		$html .= '' !== $card['url']
			? '<a class="' . $class . '" href="' . esc_url( $card['url'] ) . '"' . $attr . '>' . $inner . '</a>'
			: '<div class="' . $class . '"' . $attr . '>' . $inner . '</div>';
	}

	return $html . '</div>';
};

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts(
	$mvweb_block,
	array(
		'list' => static function () use ( $mvweb_list ) {
			echo $mvweb_list(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and ready markup of the core.
		},
	)
);
mvweb_theme_section_close();
