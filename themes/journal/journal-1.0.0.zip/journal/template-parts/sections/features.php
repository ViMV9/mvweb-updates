<?php
/**
 * Section template: how the journal works, short rules with icons.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'features', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_items = isset( $mvweb_props['blocks'] ) && is_array( $mvweb_props['blocks'] ) ? mvweb_core_visible_rows( $mvweb_props['blocks'] ) : array();

if ( empty( $mvweb_items ) ) {
	return;
}

$mvweb_view  = $mvweb_block['mod'];
$mvweb_image = '';

if ( ! empty( $mvweb_props['image'] ) && in_array( $mvweb_view, array( 'icons', 'photo' ), true ) && in_array( 'image', $mvweb_block['parts'], true ) ) {
	$mvweb_image = wp_get_attachment_image(
		(int) $mvweb_props['image'],
		'icons' === $mvweb_view ? 'mvweb_wide' : 'mvweb_card',
		false,
		array(
			'loading' => 'lazy',
			'sizes'   => 'icons' === $mvweb_view ? '(min-width: 1280px) 1240px, 100vw' : '(min-width: 1024px) 40vw, 100vw',
		)
	);
}

$mvweb_render_item = static function ( $item, $number, $block ) {
	$view   = $block['mod'];
	$title  = isset( $item['title'] ) ? trim( (string) $item['title'] ) : '';
	$lines  = isset( $item['text'] ) ? array_filter( array_map( 'trim', (array) preg_split( '/\R/u', (string) $item['text'] ) ), 'strlen' ) : array();
	$pieces = array(
		'icon'  => '',
		'num'   => '',
		'title' => '' !== $title ? '<div class="mvweb-t-features__title mvweb-t-h4">' . esc_html( $title ) . '</div>' : '',
		'text'  => '',
	);

	if ( 'num' === $view ) {
		$pieces['num'] = '<span class="mvweb-t-features__num" aria-hidden="true">' . esc_html( sprintf( '%02d', $number ) ) . '</span>';
	} elseif ( ! empty( $item['icon'] ) ) {
		$pieces['icon'] = '<span class="mvweb-t-features__icon">' . mvweb_theme_icon( $item['icon'] ) . '</span>';
	}

	if ( ! empty( $lines ) && 'strip' !== $view ) {
		$pieces['text'] = '<ul class="mvweb-t-features__lines"><li>' . implode( '</li><li>', array_map( 'esc_html', $lines ) ) . '</li></ul>';
	}

	$html  = '';
	$inner = '';

	foreach ( $block['item_parts'] as $slug ) {
		if ( ! isset( $pieces[ $slug ] ) || '' === $pieces[ $slug ] ) {
			continue;
		}

		if ( in_array( $slug, array( 'title', 'text' ), true ) ) {
			$inner .= $pieces[ $slug ];
			continue;
		}

		if ( '' !== $inner ) {
			$html .= '<div class="mvweb-t-features__body">' . $inner . '</div>';
			$inner = '';
		}

		$html .= $pieces[ $slug ];
	}

	if ( '' !== $inner ) {
		$html .= '<div class="mvweb-t-features__body">' . $inner . '</div>';
	}

	return '' !== $html ? '<li class="mvweb-t-features__item">' . $html . '</li>' : '';
};

$mvweb_print_list = static function ( $block ) use ( $mvweb_items, $mvweb_render_item ) {
	$tag  = 'num' === $block['mod'] ? 'ol' : 'ul';
	$html = '';

	foreach ( $mvweb_items as $mvweb_index => $mvweb_item ) {
		$html .= $mvweb_render_item( $mvweb_item, $mvweb_index + 1, $block );
	}

	if ( '' !== $html ) {
		echo '<' . $tag . ' class="mvweb-t-features__list">' . $html . '</' . $tag . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed tag and markup built from escaped values.
	}
};

$mvweb_extra = 'strip' === $mvweb_view && 'plain' === $mvweb_block['look']['background'] ? 'mvweb-t-section--surface' : '';

$mvweb_extra .= mvweb_theme_cards_colours( $mvweb_block );

mvweb_theme_section_open( $mvweb_block, true, trim( $mvweb_extra ) );

if ( 'photo' === $mvweb_view ) {
	ob_start();
	mvweb_theme_render_parts(
		$mvweb_block,
		array(
			'image' => static function () use ( $mvweb_image ) {
				if ( '' !== $mvweb_image ) {
					echo '<span class="mvweb-t-cover mvweb-t-cover--tall mvweb-t-features__photo">' . $mvweb_image . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Attachment markup.
				}
			},
		)
	);
	$mvweb_media = trim( (string) ob_get_clean() );

	if ( '' !== $mvweb_media ) {
		echo '<div class="mvweb-t-features__media">' . $mvweb_media . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and attachment markup.
	}

	if ( in_array( 'list', $mvweb_block['parts'], true ) ) {
		$mvweb_print_list( $mvweb_block );
	}
} else {
	mvweb_theme_render_parts(
		$mvweb_block,
		array(
			'image' => static function () use ( $mvweb_image ) {
				if ( '' !== $mvweb_image ) {
					echo '<span class="mvweb-t-cover mvweb-t-cover--wide mvweb-t-features__banner">' . $mvweb_image . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Attachment markup.
				}
			},
			'list'  => $mvweb_print_list,
		)
	);
}

mvweb_theme_section_close();
