<?php
/**
 * Section template: questions and answers.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'faq', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_view  = $mvweb_block['mod'];
$mvweb_items = array();

if ( isset( $mvweb_props['items'] ) && is_array( $mvweb_props['items'] ) ) {
	foreach ( mvweb_core_visible_rows( $mvweb_props['items'] ) as $mvweb_row ) {
		$mvweb_question = isset( $mvweb_row['title'] ) ? trim( (string) $mvweb_row['title'] ) : '';
		$mvweb_answer   = isset( $mvweb_row['answer'] ) ? trim( (string) $mvweb_row['answer'] ) : '';

		if ( '' !== $mvweb_question && '' !== $mvweb_answer ) {
			$mvweb_items[] = array(
				'question' => $mvweb_question,
				'answer'   => $mvweb_answer,
				'icon'     => isset( $mvweb_row['icon'] ) ? trim( (string) $mvweb_row['icon'] ) : '',
			);
		}
	}
}

if ( empty( $mvweb_items ) ) {
	return;
}

$mvweb_value = static function ( $key ) use ( $mvweb_props ) {
	return isset( $mvweb_props[ $key ] ) ? trim( (string) $mvweb_props[ $key ] ) : '';
};

$mvweb_tiles  = 'tiles' === $mvweb_view;
$mvweb_first  = ! isset( $mvweb_props['open_first'] ) || ! empty( $mvweb_props['open_first'] );
$mvweb_badge  = $mvweb_tiles && in_array( 'badge', $mvweb_block['item_parts'], true );
$mvweb_number = 'num' === $mvweb_view && in_array( 'num', $mvweb_block['item_parts'], true );
$mvweb_button = '';

if ( in_array( $mvweb_view, array( 'side', 'tiles' ), true ) && in_array( 'button', $mvweb_block['parts'], true ) && '' !== $mvweb_value( 'button_text' ) && '' !== $mvweb_value( 'button_url' ) ) {
	if ( $mvweb_tiles || 'link' === $mvweb_block['look']['button_kind'] ) {
		$mvweb_button = '<a class="mvweb-t-section__more" href="' . esc_url( $mvweb_value( 'button_url' ) ) . '">' . esc_html( $mvweb_value( 'button_text' ) ) . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>';
	} else {
		$mvweb_button = '<a class="' . ( 'secondary' === $mvweb_block['look']['button_kind'] ? 'mvweb-t-btn mvweb-t-btn--outline' : 'mvweb-t-btn' ) . '" href="' . esc_url( $mvweb_value( 'button_url' ) ) . '">' . esc_html( $mvweb_value( 'button_text' ) ) . '</a>';
	}
}

$mvweb_answer = static function ( $text ) {
	return wpautop( esc_html( $text ) );
};

$mvweb_list = static function () use ( $mvweb_items, $mvweb_tiles, $mvweb_badge, $mvweb_number, $mvweb_first, $mvweb_answer ) {
	if ( $mvweb_tiles ) {
		?>
		<div class="mvweb-t-faq__tiles">
			<?php foreach ( $mvweb_items as $mvweb_item ) : ?>
				<div class="mvweb-t-faq__tile">
					<?php if ( $mvweb_badge && '' !== $mvweb_item['icon'] ) : ?>
						<span class="mvweb-t-faq__badge"><?php echo mvweb_theme_icon( $mvweb_item['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
					<?php endif; ?>
					<div class="mvweb-t-h4 mvweb-t-faq__q"><?php echo esc_html( $mvweb_item['question'] ); ?></div>
					<div class="mvweb-t-faq__a"><?php echo $mvweb_answer( $mvweb_item['answer'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Paragraphs of an escaped text. ?></div>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
		return;
	}
	?>
	<div class="mvweb-t-faq__list">
		<?php foreach ( $mvweb_items as $mvweb_index => $mvweb_item ) : ?>
			<details class="mvweb-t-faq__item"<?php echo $mvweb_first && 0 === $mvweb_index ? ' open' : ''; ?>>
				<summary class="mvweb-t-faq__summary">
					<?php if ( $mvweb_number ) : ?>
						<span class="mvweb-t-faq__num"><?php echo esc_html( sprintf( '%02d', $mvweb_index + 1 ) ); ?></span>
					<?php endif; ?>
					<span class="mvweb-t-faq__q"><?php echo esc_html( $mvweb_item['question'] ); ?></span>
					<span class="mvweb-t-faq__mark"><?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
				</summary>
				<div class="mvweb-t-faq__a"><?php echo $mvweb_answer( $mvweb_item['answer'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Paragraphs of an escaped text. ?></div>
			</details>
		<?php endforeach; ?>
	</div>
	<?php
};

$mvweb_renderers = array(
	'button' => static function () use ( $mvweb_button, $mvweb_tiles ) {
		if ( ! $mvweb_tiles ) {
			echo $mvweb_button; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
		}
	},
);

ob_start();
mvweb_theme_render_parts( $mvweb_block, $mvweb_renderers, $mvweb_tiles ? array( 'side' => $mvweb_button ) : array() );
$mvweb_intro = trim( (string) ob_get_clean() );

mvweb_theme_section_open( $mvweb_block, true, $mvweb_tiles && 'plain' === $mvweb_block['look']['background'] ? 'mvweb-t-section--surface' : '' );
?>
<div class="mvweb-t-faq__layout<?php echo '' !== $mvweb_intro ? ' mvweb-t-faq__layout--split' : ''; ?>">
	<?php if ( '' !== $mvweb_intro ) : ?>
		<div class="mvweb-t-faq__intro"><?php echo $mvweb_intro; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part renderers above. ?></div>
	<?php endif; ?>
	<?php $mvweb_list(); ?>
</div>
<?php
mvweb_theme_section_close();
