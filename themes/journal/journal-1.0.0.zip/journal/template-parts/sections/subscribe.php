<?php
/**
 * Section template: the call to follow the site.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block     = mvweb_theme_block( 'subscribe', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_subscribe = mvweb_core_subscribe();

if ( empty( $mvweb_subscribe ) ) {
	return;
}

$mvweb_view    = '' !== $mvweb_block['mod'] ? $mvweb_block['mod'] : 'strip';
$mvweb_socials = in_array( 'socials', $mvweb_block['parts'], true ) ? $mvweb_subscribe['socials'] : array();
$mvweb_max     = array(
	'dark' => 6,
	'card' => 6,
	'line' => 8,
);
$mvweb_max     = isset( $mvweb_max[ $mvweb_view ] ) ? $mvweb_max[ $mvweb_view ] : 0;
$mvweb_form    = 'tiles' !== $mvweb_view && in_array( 'form', $mvweb_block['parts'], true ) && $mvweb_subscribe['form'] ? mvweb_core_subscribe_form() : '';

if ( empty( $mvweb_socials ) && '' === $mvweb_form ) {
	return;
}

$mvweb_parts = array(
	'points'  => static function ( $block ) {
		$points = array_filter( array_map( 'trim', preg_split( '/\R/u', isset( $block['props']['points'] ) ? (string) $block['props']['points'] : '' ) ) );

		if ( 'card' !== $block['mod'] || empty( $points ) ) {
			return;
		}

		echo '<ul class="mvweb-t-subscribe__points">';

		foreach ( $points as $point ) {
			echo '<li>' . mvweb_theme_icon( 'check', array( 'class' => 'mvweb-t-icon--sm' ) ) . esc_html( $point ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
		}

		echo '</ul>';
	},
	'socials' => static function ( $block ) use ( $mvweb_socials, $mvweb_max, $mvweb_form ) {
		if ( empty( $mvweb_socials ) ) {
			return;
		}

		$shown = $mvweb_max > 0 ? array_slice( $mvweb_socials, 0, $mvweb_max, true ) : $mvweb_socials;

		echo '<div class="mvweb-t-subscribe__socials">';

		if ( 'strip' === $block['mod'] ) {
			echo '<span class="mvweb-t-subscribe__cap">' . esc_html( '' !== $mvweb_form ? __( 'Or read us on social networks', 'journal' ) : __( 'Read us on social networks', 'journal' ) ) . '</span>';
		}

		if ( 'tiles' === $block['mod'] ) {
			$verbs = array(
				'vk'            => __( 'Join', 'journal' ),
				'odnoklassniki' => __( 'Join', 'journal' ),
				'x'             => __( 'Read', 'journal' ),
				'whatsapp'      => __( 'Follow the channel', 'journal' ),
			);

			echo '<ul class="mvweb-t-subscribe__tiles">';

			foreach ( $shown as $id => $link ) {
				printf(
					'<li><a href="%1$s" data-brand="%2$s" rel="noopener" target="_blank"><span class="mvweb-t-follow__ico">%3$s</span><span class="mvweb-t-follow__name">%4$s</span><span class="mvweb-t-subscribe__cta">%5$s</span></a></li>',
					esc_url( $link['url'] ),
					esc_attr( mvweb_core_social_icon( $id ) ),
					mvweb_theme_icon( mvweb_core_social_icon( $id ), array( 'class' => 'mvweb-t-icon--brand' ) ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
					esc_html( $link['label'] ),
					esc_html( isset( $verbs[ $id ] ) ? $verbs[ $id ] : __( 'Subscribe', 'journal' ) )
				);
			}

			echo '</ul>';
		} else {
			$styles = array(
				'strip' => 'brand',
				'dark'  => 'buttons',
			);

			mvweb_theme_follow( $mvweb_socials, isset( $styles[ $block['mod'] ] ) ? $styles[ $block['mod'] ] : 'icons', $mvweb_max );
		}

		mvweb_theme_meta_note( $shown );

		echo '</div>';
	},
);

$mvweb_form_first = '' !== $mvweb_form && 'form' === (string) reset( $mvweb_block['parts'] );
$mvweb_form_html  = '' !== $mvweb_form ? '<div class="mvweb-t-subscribe__form" id="mvweb-t-subscribe-form" data-subscribe-form>' . $mvweb_form . '</div>' : '';

$mvweb_strip = array(
	'strip' => 'mvweb-t-section--surface',
	'dark'  => 'mvweb-t-section--inverse',
);

mvweb_theme_section_open( $mvweb_block, true, 'plain' === $mvweb_block['look']['background'] && isset( $mvweb_strip[ $mvweb_view ] ) ? $mvweb_strip[ $mvweb_view ] : '' );
?>
<div class="mvweb-t-subscribe__box<?php echo '' !== $mvweb_form ? ' mvweb-t-subscribe__box--form' : ''; ?>">
	<?php if ( 'card' === $mvweb_view ) : ?>
		<span class="mvweb-t-subscribe__ico"><?php echo mvweb_theme_icon( 'mail' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
	<?php endif; ?>
	<?php echo $mvweb_form_first ? $mvweb_form_html : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the mailing plugin. ?>
	<div class="mvweb-t-subscribe__main">
		<?php
		$mvweb_main          = $mvweb_block;
		$mvweb_main['parts'] = array_values( array_diff( $mvweb_block['parts'], array( 'form' ) ) );
		mvweb_theme_render_parts( $mvweb_main, $mvweb_parts );
		?>
	</div>
	<?php echo $mvweb_form_first ? '' : $mvweb_form_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the mailing plugin. ?>
</div>
<?php
mvweb_theme_section_close();
