<?php
/**
 * Section template: first screen as a slider of posts and offers.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block  = mvweb_theme_block( 'hero-slider', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props  = $mvweb_block['props'];
$mvweb_slides = mvweb_core_hero_slider_slides( $mvweb_props );

if ( empty( $mvweb_slides ) ) {
	return;
}

$mvweb_view     = $mvweb_block['mod'];
$mvweb_total    = count( $mvweb_slides );
$mvweb_order    = $mvweb_block['item_parts'];
$mvweb_parts    = $mvweb_block['parts'];
$mvweb_interval = isset( $mvweb_props['slide_interval'] ) && absint( $mvweb_props['slide_interval'] ) > 0 ? absint( $mvweb_props['slide_interval'] ) : 6;
$mvweb_manual   = mvweb_core_hero_slider_manual( $mvweb_props, $mvweb_parts );
$mvweb_wide     = in_array( $mvweb_view, array( 'photo', 'center' ), true );
$mvweb_rv       = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_texts    = 'photos' === $mvweb_view ? array( 'kicker', 'title' ) : array( 'kicker', 'title', 'lead', 'facts', 'actions' );
$mvweb_sizes    = array(
	'photo'  => '100vw',
	'center' => '100vw',
	'split'  => '(min-width: 600px) 50vw, 100vw',
	'photos' => '(min-width: 1024px) 75vw, 100vw',
	'fan'    => '(min-width: 600px) 18vw, 30vw',
);

$mvweb_val = static function ( $row, $key ) {
	return isset( $row[ $key ] ) && is_scalar( $row[ $key ] ) ? trim( (string) $row[ $key ] ) : '';
};

$mvweb_marked = static function ( $text ) {
	return (string) preg_replace( '/\*([^*\n]+)\*/u', '<span class="mvweb-t-hero-slider__accent">$1</span>', esc_html( $text ) );
};

$mvweb_image = static function ( $id, $size, $first ) use ( $mvweb_view, $mvweb_sizes ) {
	$id = absint( $id );

	if ( ! $id || ! wp_attachment_is_image( $id ) ) {
		return '';
	}

	$attr = array(
		'loading'  => $first ? 'eager' : 'lazy',
		'decoding' => 'async',
		'sizes'    => $mvweb_sizes[ $mvweb_view ],
	);

	if ( $first ) {
		$attr['fetchpriority'] = 'high';
	}

	return (string) wp_get_attachment_image( $id, $size, false, $attr );
};

$mvweb_text = array(
	'kicker'  => static function ( $slide ) use ( $mvweb_val ) {
		$kicker = $mvweb_val( $slide, 'kicker' );

		return '' !== $kicker ? '<span class="mvweb-t-kicker mvweb-t-hero-slider__kicker">' . esc_html( $kicker ) . '</span>' : '';
	},
	'title'   => static function ( $slide, $index ) use ( $mvweb_val, $mvweb_marked, $mvweb_view ) {
		$title = $mvweb_val( $slide, 'title' );
		$word  = 'photos' === $mvweb_view ? '' : $mvweb_val( $slide, 'accent_word' );
		$pos   = '' !== $word ? strpos( $title, $word ) : false;

		if ( '' === $title ) {
			return '';
		}

		$tag  = 0 === $index ? mvweb_core_h1_tag() : 'div';
		$html = 'photos' === $mvweb_view ? esc_html( str_replace( '*', '', $title ) ) : ( false === $pos
			? $mvweb_marked( $title )
			: $mvweb_marked( substr( $title, 0, $pos ) ) . '<span class="mvweb-t-hero-slider__accent">' . esc_html( $word ) . '</span>' . $mvweb_marked( substr( $title, $pos + strlen( $word ) ) ) );

		return '<' . $tag . ' class="mvweb-t-hero-slider__title">' . $html . '</' . $tag . '>';
	},
	'lead'    => static function ( $slide ) use ( $mvweb_val, $mvweb_marked ) {
		$lead = $mvweb_val( $slide, 'text' );

		return '' !== $lead ? '<p class="mvweb-t-hero-slider__lead">' . $mvweb_marked( $lead ) . '</p>' : '';
	},
	'facts'   => static function ( $slide ) use ( $mvweb_val, $mvweb_view ) {
		$lines = in_array( $mvweb_view, array( 'fan', 'split' ), true ) ? array_slice( mvweb_core_text_lines( $mvweb_val( $slide, 'facts' ) ), 0, 4 ) : array();
		$html  = '';

		foreach ( $lines as $line ) {
			$html .= '<li>' . esc_html( $line ) . '</li>';
		}

		return '' !== $html ? '<ul class="mvweb-t-hero-slider__facts">' . $html . '</ul>' : '';
	},
	'actions' => static function ( $slide ) use ( $mvweb_val ) {
		$label = $mvweb_val( $slide, 'button_text' );
		$url   = $mvweb_val( $slide, 'button_url' );

		return '' !== $label && '' !== $url ? '<div class="mvweb-t-hero-slider__actions"><a class="mvweb-t-btn mvweb-t-hero-slider__btn" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a></div>' : '';
	},
);

$mvweb_pics = static function ( $slide, $index ) use ( $mvweb_view, $mvweb_val, $mvweb_image ) {
	$first = 0 === $index;

	if ( 'fan' === $mvweb_view ) {
		$html = '';

		foreach ( array( 'image_1', 'image_2', 'image_3' ) as $number => $key ) {
			$picture = $mvweb_image( $mvweb_val( $slide, $key ), 'mvweb_card', $first );
			$html   .= '' !== $picture ? '<div class="mvweb-t-hero-slider__card mvweb-t-hero-slider__card--' . ( $number + 1 ) . '">' . $picture . '</div>' : '';
		}

		return '' !== $html ? '<div class="mvweb-t-hero-slider__fan">' . $html . '</div>' : '';
	}

	$photo = $mvweb_image( $mvweb_val( $slide, 'photo' ), 'mvweb_wide', $first );

	return '' !== $photo ? '<div class="mvweb-t-hero-slider__media">' . $photo . '</div>' : '';
};

$mvweb_slide = static function ( $slide, $index ) use ( $mvweb_val, $mvweb_view, $mvweb_order, $mvweb_total, $mvweb_text, $mvweb_texts, $mvweb_pics ) {
	$texts = array();
	$html  = '';
	$done  = false;

	foreach ( $mvweb_order as $slug ) {
		if ( isset( $mvweb_text[ $slug ] ) && in_array( $slug, $mvweb_texts, true ) ) {
			$part = call_user_func( $mvweb_text[ $slug ], $slide, $index );

			if ( '' !== $part ) {
				$texts[ $slug ] = $part;
			}
		}
	}

	foreach ( $mvweb_order as $slug ) {
		if ( 'pics' === $slug ) {
			$html .= $mvweb_pics( $slide, $index );
		} elseif ( isset( $texts[ $slug ] ) && ! $done ) {
			$done  = true;
			$html .= '<div class="mvweb-t-hero-slider__' . ( 'photos' === $mvweb_view ? 'cap' : 'body' ) . '">' . implode( '', $texts ) . '</div>';
		}
	}

	if ( '' === $html ) {
		return '';
	}

	$link = 'photos' === $mvweb_view ? $mvweb_val( $slide, 'link' ) : '';
	$html = '' !== $link ? '<a class="mvweb-t-hero-slider__link" href="' . esc_url( $link ) . '">' . $html . '</a>' : $html;
	$attr = '';

	if ( 'fan' !== $mvweb_view ) {
		$focus = $mvweb_val( $slide, 'photo_focus' );
		$attr .= in_array( $focus, array( 'top', 'bottom' ), true ) ? ' data-focus="' . esc_attr( $focus ) . '"' : '';
	}

	if ( 'photo' === $mvweb_view && 'center' === $mvweb_val( $slide, 'text_align' ) ) {
		$attr .= ' data-align="center"';
	}

	if ( in_array( $mvweb_view, array( 'photo', 'center' ), true ) ) {
		$shade = isset( $slide['overlay'] ) && is_numeric( $slide['overlay'] ) ? min( 80, max( 0, (int) $slide['overlay'] ) ) : 40;
		$attr .= ' style="--mvweb-t-slide-shade:' . esc_attr( $shade / 100 ) . '"';
	}

	$label = sprintf(
		/* translators: 1: number of the slide, 2: number of slides. */
		__( '%1$d of %2$d', 'journal' ),
		$index + 1,
		$mvweb_total
	);

	return '<article class="mvweb-t-hero-slider__slide" data-hero-slider-slide' . ( 0 === $index ? ' data-active' : '' ) . $attr . ' role="group" aria-roledescription="' . esc_attr__( 'slide', 'journal' ) . '" aria-label="' . esc_attr( $label ) . '">' . $html . '</article>';
};

$mvweb_html = '';

foreach ( $mvweb_slides as $mvweb_index => $mvweb_row ) {
	$mvweb_html .= $mvweb_slide( $mvweb_row, $mvweb_index );
}

if ( '' === $mvweb_html ) {
	return;
}

$mvweb_shown = static function ( $slug ) use ( $mvweb_parts ) {
	return in_array( $slug, $mvweb_parts, true );
};

$mvweb_round = static function ( $attr, $icon, $label, $more = '' ) {
	return '<button class="mvweb-t-hero-slider__arrow' . $more . '" type="button" ' . $attr . ' title="' . esc_attr( $label ) . '">' . $icon . '<span class="screen-reader-text">' . esc_html( $label ) . '</span></button>';
};

$mvweb_nav = '';

if ( $mvweb_total > 1 && 'photos' !== $mvweb_view ) {
	$mvweb_dots = '';

	if ( $mvweb_shown( 'dots' ) ) {
		for ( $mvweb_n = 1; $mvweb_n <= $mvweb_total; $mvweb_n++ ) {
			$mvweb_dot = sprintf(
				/* translators: %d: number of the slide. */
				__( 'Slide %d', 'journal' ),
				$mvweb_n
			);
			$mvweb_dots .= '<button class="mvweb-t-hero-slider__dot" type="button" data-hero-slider-dot title="' . esc_attr( $mvweb_dot ) . '"' . ( 1 === $mvweb_n ? ' data-active aria-current="true"' : ' aria-current="false"' ) . '><span class="screen-reader-text">' . esc_html( $mvweb_dot ) . '</span></button>';
		}

		$mvweb_dots = '<div class="mvweb-t-hero-slider__dots">' . $mvweb_dots . '</div>';
	}

	if ( $mvweb_shown( 'arrows' ) ) {
		$mvweb_nav .= $mvweb_round( 'data-hero-slider-prev', mvweb_theme_icon( 'chevron-left', array( 'class' => 'mvweb-t-icon--sm' ) ), __( 'Previous slide', 'journal' ) );
	}

	$mvweb_nav .= $mvweb_dots;

	if ( $mvweb_shown( 'arrows' ) ) {
		$mvweb_nav .= $mvweb_round( 'data-hero-slider-next', mvweb_theme_icon( 'chevron-right', array( 'class' => 'mvweb-t-icon--sm' ) ), __( 'Next slide', 'journal' ) );
	}

	if ( $mvweb_shown( 'pause' ) && ! $mvweb_manual ) {
		$mvweb_nav .= $mvweb_round( 'data-hero-slider-pause aria-pressed="false"', '<span class="mvweb-t-hero-slider__bars"></span>' . mvweb_theme_icon( 'play', array( 'class' => 'mvweb-t-icon--sm' ) ), __( 'Pause the slides', 'journal' ), ' mvweb-t-hero-slider__pause' );
	}

	$mvweb_nav = '' !== $mvweb_nav ? '<div class="mvweb-t-hero-slider__nav">' . $mvweb_nav . '</div>' : '';
}

if ( $mvweb_total > 1 && 'photos' === $mvweb_view && $mvweb_shown( 'thumbs' ) ) {
	foreach ( $mvweb_slides as $mvweb_index => $mvweb_row ) {
		$mvweb_name = trim( str_replace( '*', '', $mvweb_val( $mvweb_row, 'title' ) ) );
		$mvweb_cut  = strpos( $mvweb_name, ':' );
		$mvweb_name = false !== $mvweb_cut && $mvweb_cut > 0 ? trim( substr( $mvweb_name, 0, $mvweb_cut ) ) : $mvweb_name;
		$mvweb_name = '' !== $mvweb_name ? $mvweb_name : sprintf(
			/* translators: %d: number of the slide. */
			__( 'Slide %d', 'journal' ),
			$mvweb_index + 1
		);
		$mvweb_photo = absint( $mvweb_val( $mvweb_row, 'photo' ) );
		$mvweb_pic   = $mvweb_photo && wp_attachment_is_image( $mvweb_photo ) ? wp_get_attachment_image(
			$mvweb_photo,
			'mvweb_card',
			false,
			array(
				'alt'      => '',
				'loading'  => 'lazy',
				'decoding' => 'async',
				'sizes'    => '(min-width: 1024px) 96px, 30vw',
			)
		) : '';
		$mvweb_nav  .= '<button class="mvweb-t-hero-slider__thumb" type="button" data-hero-slider-dot' . ( 0 === $mvweb_index ? ' data-active aria-current="true"' : ' aria-current="false"' ) . '><span class="mvweb-t-hero-slider__thumb-pic">' . $mvweb_pic . '</span><span class="mvweb-t-hero-slider__thumb-name">' . esc_html( $mvweb_name ) . '</span></button>';
	}

	$mvweb_nav = '<div class="mvweb-t-hero-slider__thumbs">' . $mvweb_nav . '</div>';
}

mvweb_theme_section_open( $mvweb_block, ! $mvweb_wide );
?>
<div class="mvweb-t-hero-slider__box" data-hero-slider<?php echo $mvweb_wide ? $mvweb_rv : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?><?php echo $mvweb_manual ? ' data-manual' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?> data-interval="<?php echo esc_attr( $mvweb_interval ); ?>" role="region" aria-roledescription="<?php esc_attr_e( 'carousel', 'journal' ); ?>" aria-label="<?php esc_attr_e( 'Featured posts', 'journal' ); ?>">
	<div class="mvweb-t-hero-slider__slides"><?php echo $mvweb_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?></div>
	<?php echo $mvweb_nav; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
</div>
<?php
mvweb_theme_section_close( ! $mvweb_wide );
