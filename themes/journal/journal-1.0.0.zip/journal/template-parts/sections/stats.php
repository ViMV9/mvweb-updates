<?php
/**
 * Section template: figures of the journal.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'stats', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_items = isset( $mvweb_block['props']['items'] ) && is_array( $mvweb_block['props']['items'] ) ? mvweb_core_visible_rows( $mvweb_block['props']['items'] ) : array();

if ( empty( $mvweb_items ) ) {
	return;
}

$mvweb_item_parts = array(
	'number' => static function ( $item ) {
		if ( '' !== (string) $item['number'] ) {
			echo '<span class="mvweb-t-stats__num">' . esc_html( $item['number'] ) . '</span>';
		}
	},
	'label'  => static function ( $item ) {
		if ( '' !== (string) $item['label'] ) {
			echo '<span class="mvweb-t-stats__label">' . esc_html( $item['label'] ) . '</span>';
		}
	},
);

$mvweb_parts = array(
	'list' => static function ( $block ) use ( $mvweb_items, $mvweb_item_parts ) {
		?>
		<ul class="mvweb-t-stats__list">
			<?php foreach ( $mvweb_items as $mvweb_item ) : ?>
				<li class="mvweb-t-stats__item"><?php mvweb_theme_render_item_parts( $block, $mvweb_item, $mvweb_item_parts ); ?></li>
			<?php endforeach; ?>
		</ul>
		<?php
	},
);

mvweb_theme_section_open( $mvweb_block, true, 'dark' === $mvweb_block['mod'] && 'plain' === $mvweb_block['look']['background'] ? 'mvweb-t-section--inverse' : '' );
mvweb_theme_render_parts( $mvweb_block, $mvweb_parts );
mvweb_theme_section_close();
