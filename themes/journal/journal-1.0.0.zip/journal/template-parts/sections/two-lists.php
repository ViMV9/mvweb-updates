<?php
/**
 * Section template: two lists side by side.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'two-lists', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_view  = $mvweb_block['mod'];

$mvweb_value = static function ( $key ) use ( $mvweb_props ) {
	return isset( $mvweb_props[ $key ] ) ? trim( (string) $mvweb_props[ $key ] ) : '';
};

$mvweb_both  = 'yes-yes' === $mvweb_value( 'marks' );
$mvweb_lists = array();

foreach ( $mvweb_block['parts'] as $mvweb_slug ) {
	if ( ! in_array( $mvweb_slug, array( 'col_1', 'col_2' ), true ) ) {
		continue;
	}

	$mvweb_side  = 'col_1' === $mvweb_slug ? 'left' : 'right';
	$mvweb_items = array_values( array_filter( array_map( 'trim', preg_split( '/\R/', $mvweb_value( $mvweb_side . '_items' ) ) ), 'strlen' ) );

	if ( empty( $mvweb_items ) ) {
		continue;
	}

	$mvweb_yes     = 'left' === $mvweb_side || $mvweb_both;
	$mvweb_title   = $mvweb_value( $mvweb_side . '_title' );
	$mvweb_lists[] = array(
		'key'   => $mvweb_side,
		'title' => $mvweb_title,
		'tab'   => '' !== $mvweb_value( $mvweb_side . '_tab' ) ? $mvweb_value( $mvweb_side . '_tab' ) : $mvweb_title,
		'items' => $mvweb_items,
		'mark'  => $mvweb_yes ? 'yes' : 'no',
		'icon'  => $mvweb_yes ? 'check' : 'close',
	);
}

if ( empty( $mvweb_lists ) ) {
	return;
}

$mvweb_marks = in_array( 'mark', $mvweb_block['item_parts'], true );
$mvweb_count = in_array( 'count', $mvweb_block['item_parts'], true );

$mvweb_mark = static function ( array $group ) use ( $mvweb_marks ) {
	return $mvweb_marks ? mvweb_theme_icon( $group['icon'], array( 'class' => 'mvweb-t-icon--sm' ) ) : '';
};

$mvweb_items = static function ( array $group ) use ( $mvweb_mark ) {
	?>
	<ul class="mvweb-t-two-lists__items">
		<?php foreach ( $group['items'] as $mvweb_item ) : ?>
			<li class="mvweb-t-two-lists__item mvweb-t-two-lists__item--<?php echo esc_attr( $group['mark'] ); ?>"><?php echo $mvweb_mark( $group ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?><span><?php echo esc_html( $mvweb_item ); ?></span></li>
		<?php endforeach; ?>
	</ul>
	<?php
};

$mvweb_printed = false;

$mvweb_print = static function () use ( &$mvweb_printed, $mvweb_lists, $mvweb_view, $mvweb_items, $mvweb_mark, $mvweb_count ) {
	if ( $mvweb_printed ) {
		return;
	}

	$mvweb_printed = true;

	if ( 'tabs' === $mvweb_view && count( $mvweb_lists ) > 1 ) {
		?>
		<div class="mvweb-t-two-lists__tabs" data-tabs>
			<div class="mvweb-t-tabs" role="tablist">
				<?php foreach ( $mvweb_lists as $mvweb_index => $mvweb_list ) : ?>
					<button type="button" data-tab="<?php echo esc_attr( $mvweb_list['key'] ); ?>" aria-selected="<?php echo 0 === $mvweb_index ? 'true' : 'false'; ?>">
						<?php echo esc_html( $mvweb_list['tab'] ); ?>
						<?php if ( $mvweb_count ) : ?>
							<span class="mvweb-t-two-lists__count"><?php echo esc_html( number_format_i18n( count( $mvweb_list['items'] ) ) ); ?></span>
						<?php endif; ?>
					</button>
				<?php endforeach; ?>
			</div>
			<?php foreach ( $mvweb_lists as $mvweb_index => $mvweb_list ) : ?>
				<div class="mvweb-t-two-lists__panel" data-tabpanel="<?php echo esc_attr( $mvweb_list['key'] ); ?>"<?php echo 0 === $mvweb_index ? '' : ' hidden'; ?>>
					<?php $mvweb_items( $mvweb_list ); ?>
				</div>
			<?php endforeach; ?>
		</div>
		<?php
		return;
	}

	if ( 'table' === $mvweb_view ) {
		$mvweb_rows = max( array_map( 'count', array_column( $mvweb_lists, 'items' ) ) );
		?>
		<div class="mvweb-t-two-lists__table">
			<table>
				<thead>
					<tr>
						<?php foreach ( $mvweb_lists as $mvweb_list ) : ?>
							<th scope="col"><?php echo esc_html( $mvweb_list['title'] ); ?></th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody>
					<?php for ( $mvweb_row = 0; $mvweb_row < $mvweb_rows; $mvweb_row++ ) : ?>
						<tr>
							<?php foreach ( $mvweb_lists as $mvweb_list ) : ?>
								<td>
									<?php if ( isset( $mvweb_list['items'][ $mvweb_row ] ) ) : ?>
										<div class="mvweb-t-two-lists__item mvweb-t-two-lists__item--<?php echo esc_attr( $mvweb_list['mark'] ); ?>"><?php echo $mvweb_mark( $mvweb_list ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?><span><?php echo esc_html( $mvweb_list['items'][ $mvweb_row ] ); ?></span></div>
									<?php endif; ?>
								</td>
							<?php endforeach; ?>
						</tr>
					<?php endfor; ?>
				</tbody>
			</table>
		</div>
		<?php
		return;
	}
	?>
	<div class="mvweb-t-two-lists__cols">
		<?php foreach ( $mvweb_lists as $mvweb_list ) : ?>
			<div class="mvweb-t-two-lists__col mvweb-t-two-lists__col--<?php echo esc_attr( $mvweb_list['mark'] ); ?>">
				<?php if ( '' !== $mvweb_list['title'] ) : ?>
					<div class="mvweb-t-h3 mvweb-t-two-lists__title"><?php echo esc_html( $mvweb_list['title'] ); ?></div>
				<?php endif; ?>
				<?php $mvweb_items( $mvweb_list ); ?>
			</div>
		<?php endforeach; ?>
	</div>
	<?php
};

mvweb_theme_section_open( $mvweb_block, true, 'dark' === $mvweb_view && 'plain' === $mvweb_block['look']['background'] ? 'mvweb-t-section--inverse' : '' );
?>
<div class="mvweb-t-two-lists__layout">
	<?php
	mvweb_theme_render_parts(
		$mvweb_block,
		array(
			'col_1' => $mvweb_print,
			'col_2' => $mvweb_print,
		)
	);
	?>
</div>
<?php
mvweb_theme_section_close();
