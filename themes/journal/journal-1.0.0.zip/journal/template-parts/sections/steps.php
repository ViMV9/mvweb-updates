<?php
/**
 * Section template: stages, step by step.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'steps', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_items = isset( $mvweb_block['props']['items'] ) && is_array( $mvweb_block['props']['items'] ) ? mvweb_core_visible_rows( $mvweb_block['props']['items'] ) : array();

if ( empty( $mvweb_items ) ) {
	return;
}

$mvweb_render_item = static function ( $item, $number, $block ) {
	$view   = $block['mod'];
	$title  = isset( $item['title'] ) ? trim( (string) $item['title'] ) : '';
	$text   = isset( $item['text'] ) ? trim( (string) $item['text'] ) : '';
	$pieces = array(
		'image' => '',
		'num'   => '',
		'title' => '' !== $title ? '<div class="mvweb-t-steps__title mvweb-t-h4">' . esc_html( $title ) . '</div>' : '',
		'text'  => '' !== $text ? '<p class="mvweb-t-steps__text">' . esc_html( $text ) . '</p>' : '',
	);

	if ( 'img' === $view && ! empty( $item['image'] ) ) {
		$image = wp_get_attachment_image(
			(int) $item['image'],
			'mvweb_card',
			false,
			array(
				'loading' => 'lazy',
				'sizes'   => '(min-width: 1024px) 25vw, (min-width: 600px) 50vw, 100vw',
			)
		);

		$pieces['image'] = '' !== $image ? '<span class="mvweb-t-cover mvweb-t-steps__img">' . $image . '</span>' : '';
	}

	if ( 'big' === $view ) {
		$pieces['num'] = sprintf( '%02d', $number );
	} elseif ( 'cards' === $view ) {
		$pieces['num'] = '<span class="mvweb-t-steps__word">' . esc_html__( 'Step', 'journal' ) . '</span> ' . $number;
	} else {
		$pieces['num'] = (string) $number;
	}

	$pieces['num'] = '<span class="mvweb-t-steps__num" aria-hidden="true">' . $pieces['num'] . '</span>';

	$html  = '';
	$inner = '';

	foreach ( $block['item_parts'] as $slug ) {
		if ( ! isset( $pieces[ $slug ] ) || '' === $pieces[ $slug ] ) {
			continue;
		}

		if ( in_array( $slug, array( 'title', 'text' ), true ) ) {
			$inner .= $pieces[ $slug ];
			continue;
		}

		if ( '' !== $inner ) {
			$html .= '<div class="mvweb-t-steps__body">' . $inner . '</div>';
			$inner = '';
		}

		$html .= $pieces[ $slug ];
	}

	if ( '' !== $inner ) {
		$html .= '<div class="mvweb-t-steps__body">' . $inner . '</div>';
	}

	echo '<li class="mvweb-t-steps__item">' . $html . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and attachment markup.
};

$mvweb_parts = array(
	'list' => static function ( $block ) use ( $mvweb_items, $mvweb_render_item ) {
		echo '<ol class="mvweb-t-steps__list">';

		foreach ( $mvweb_items as $mvweb_index => $mvweb_item ) {
			$mvweb_render_item( $mvweb_item, $mvweb_index + 1, $block );
		}

		echo '</ol>';
	},
);

mvweb_theme_section_open( $mvweb_block, true, 'cards' === $mvweb_block['mod'] && 'plain' === $mvweb_block['look']['background'] ? 'mvweb-t-section--surface' : '' );
mvweb_theme_render_parts( $mvweb_block, $mvweb_parts );
mvweb_theme_section_close();
