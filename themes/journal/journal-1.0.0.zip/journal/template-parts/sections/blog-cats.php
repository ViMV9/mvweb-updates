<?php
/**
 * Section template: the categories of the blog.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'blog-cats', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_terms = mvweb_core_blog_cats_terms( $mvweb_block['props'] );

if ( empty( $mvweb_terms ) ) {
	return;
}

if ( empty( $mvweb_block['props']['link_url'] ) ) {
	$mvweb_block['props']['link_url'] = mvweb_core_blog_url();
}

$mvweb_icon = static function ( $term, $css ) {
	return '<span class="' . esc_attr( $css ) . '">' . mvweb_theme_icon( mvweb_core_term_icon( $term ) ) . '</span>';
};

$mvweb_list = array(
	'chips' => static function () use ( $mvweb_terms ) {
		echo '<div class="mvweb-t-chips mvweb-t-blog-cats__chips">';

		foreach ( $mvweb_terms as $term ) {
			printf(
				'<a class="mvweb-t-chip" href="%1$s">%2$s <span class="mvweb-t-blog-cats__n">%3$s</span></a>',
				esc_url( (string) get_term_link( $term ) ),
				esc_html( $term->name ),
				esc_html( number_format_i18n( $term->count ) )
			);
		}

		echo '</div>';
	},
	'tiles' => static function () use ( $mvweb_terms, $mvweb_icon ) {
		echo '<ul class="mvweb-t-blog-cats__list">';

		foreach ( $mvweb_terms as $term ) {
			printf(
				'<li><a class="mvweb-t-blog-cats__tile" href="%1$s">%2$s<span class="mvweb-t-blog-cats__name">%3$s</span><span class="mvweb-t-blog-cats__count">%4$s</span></a></li>',
				esc_url( (string) get_term_link( $term ) ),
				$mvweb_icon( $term, 'mvweb-t-blog-cats__ico' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
				esc_html( $term->name ),
				esc_html( mvweb_core_articles( $term->count ) )
			);
		}

		echo '</ul>';
	},
	'hubs'  => static function ( $block ) use ( $mvweb_terms, $mvweb_icon ) {
		$count = isset( $block['props']['posts'] ) ? max( 3, min( 5, absint( $block['props']['posts'] ) ) ) : 3;

		echo '<ul class="mvweb-t-blog-cats__list">';

		foreach ( $mvweb_terms as $term ) {
			$link  = (string) get_term_link( $term );
			$posts = mvweb_core_blog_cat_posts( $term->term_id, $count );
			?>
			<li class="mvweb-t-blog-cats__hub">
				<a class="mvweb-t-blog-cats__head" href="<?php echo esc_url( $link ); ?>">
					<?php echo $mvweb_icon( $term, 'mvweb-t-blog-cats__ico' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<span>
						<span class="mvweb-t-blog-cats__name"><?php echo esc_html( $term->name ); ?></span>
						<span class="mvweb-t-blog-cats__count"><?php echo esc_html( mvweb_core_articles( $term->count ) ); ?></span>
					</span>
				</a>
				<?php if ( ! empty( $posts ) ) : ?>
					<ul class="mvweb-t-blog-cats__posts">
						<?php foreach ( $posts as $post ) : ?>
							<li><a href="<?php echo esc_url( get_permalink( $post ) ); ?>"><?php echo esc_html( get_the_title( $post ) ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
				<a class="mvweb-t-section__more" href="<?php echo esc_url( $link ); ?>">
					<?php esc_html_e( 'All articles', 'journal' ); ?>
					<span class="screen-reader-text"><?php echo esc_html( $term->name ); ?></span>
					<?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				</a>
			</li>
			<?php
		}

		echo '</ul>';
	},
	'cards' => static function () use ( $mvweb_terms, $mvweb_icon ) {
		echo '<ul class="mvweb-t-blog-cats__list">';

		foreach ( $mvweb_terms as $term ) {
			$picture = mvweb_core_term_picture( $term, 'medium_large' );
			$kids    = wp_list_pluck( mvweb_core_blog_children( $term->term_id, 'count' ), 'name' );
			?>
			<li>
				<a class="mvweb-t-blog-cats__card" href="<?php echo esc_url( (string) get_term_link( $term ) ); ?>">
					<?php if ( '' !== $picture ) : ?>
						<span class="mvweb-t-cover mvweb-t-cover--square mvweb-t-blog-cats__pic"><?php echo $picture; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds the image tag. ?></span>
					<?php else : ?>
						<?php echo $mvweb_icon( $term, 'mvweb-t-cover mvweb-t-cover--square mvweb-t-blog-cats__pic mvweb-t-blog-cats__pic--icon' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<?php endif; ?>
					<span class="mvweb-t-blog-cats__body">
						<span class="mvweb-t-blog-cats__name"><?php echo esc_html( $term->name ); ?></span>
						<?php if ( ! empty( $kids ) ) : ?>
							<span class="mvweb-t-blog-cats__subs"><?php echo esc_html( implode( ' · ', $kids ) ); ?></span>
						<?php endif; ?>
					</span>
				</a>
			</li>
			<?php
		}

		echo '</ul>';
	},
	'index' => static function () use ( $mvweb_terms ) {
		echo '<ul class="mvweb-t-blog-cats__list">';

		foreach ( $mvweb_terms as $term ) {
			$kids = mvweb_core_blog_children( $term->term_id, 'count' );
			?>
			<li class="mvweb-t-blog-cats__group">
				<a class="mvweb-t-blog-cats__name" href="<?php echo esc_url( (string) get_term_link( $term ) ); ?>"><?php echo esc_html( $term->name ); ?> <small class="mvweb-t-blog-cats__n"><?php echo esc_html( number_format_i18n( $term->count ) ); ?></small></a>
				<?php if ( ! empty( $kids ) ) : ?>
					<ul class="mvweb-t-blog-cats__subs">
						<?php foreach ( $kids as $kid ) : ?>
							<li><a href="<?php echo esc_url( (string) get_term_link( $kid ) ); ?>"><?php echo esc_html( $kid->name ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</li>
			<?php
		}

		echo '</ul>';
	},
);

$mvweb_parts = array(
	'list' => static function ( $block ) use ( $mvweb_list ) {
		$mvweb_list[ isset( $mvweb_list[ $block['mod'] ] ) ? $block['mod'] : 'chips' ]( $block );
	},
);

mvweb_theme_section_open( $mvweb_block, true, 'cards' === $mvweb_block['mod'] && 'plain' === $mvweb_block['look']['background'] ? 'mvweb-t-section--surface' : '' );
mvweb_theme_render_parts( $mvweb_block, $mvweb_parts );
mvweb_theme_section_close();
