<?php
/**
 * Section template: why readers trust the journal.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'benefits', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_items = isset( $mvweb_props['items'] ) && is_array( $mvweb_props['items'] ) ? mvweb_core_visible_rows( $mvweb_props['items'] ) : array();

if ( empty( $mvweb_items ) ) {
	return;
}

$mvweb_view  = $mvweb_block['mod'];
$mvweb_parts = $mvweb_block['parts'];
$mvweb_list  = in_array( 'list', $mvweb_parts, true );
$mvweb_photo = '';

if ( in_array( 'media', $mvweb_parts, true ) && ! empty( $mvweb_props['image'] ) && in_array( $mvweb_view, array( 'card', 'around' ), true ) ) {
	$mvweb_photo = wp_get_attachment_image(
		(int) $mvweb_props['image'],
		'mvweb_card',
		false,
		array(
			'loading' => 'lazy',
			'sizes'   => 'card' === $mvweb_view ? '(min-width: 1024px) 55vw, 100vw' : '(min-width: 1024px) 360px, 100vw',
		)
	);
}

$mvweb_render_item = static function ( $item ) use ( $mvweb_block ) {
	$view   = $mvweb_block['mod'];
	$title  = isset( $item['title'] ) ? trim( (string) $item['title'] ) : '';
	$text   = isset( $item['text'] ) ? trim( (string) $item['text'] ) : '';
	$figure = isset( $item['figure'] ) ? trim( (string) $item['figure'] ) : '';
	$pieces = array(
		'mark'   => '',
		'name'   => '',
		'text'   => '',
		'figure' => '',
	);

	if ( 'card' === $view ) {
		$text = '' !== $text ? $text : $title;

		if ( '' === $text ) {
			return '';
		}

		$pieces['mark'] = mvweb_theme_icon( 'check', array( 'class' => 'mvweb-t-icon--sm mvweb-t-benefits__check' ) );
		$pieces['text'] = '<span>' . esc_html( $text ) . '</span>';
	} else {
		$pieces['mark']   = ! empty( $item['icon'] ) ? '<span class="mvweb-t-benefits__icon">' . mvweb_theme_icon( $item['icon'] ) . '</span>' : '';
		$pieces['name']   = '' !== $title ? '<div class="mvweb-t-benefits__name mvweb-t-h4">' . esc_html( $title ) . '</div>' : '';
		$pieces['text']   = '' !== $text ? '<p class="mvweb-t-benefits__text">' . esc_html( $text ) . '</p>' : '';
		$pieces['figure'] = 'rows' === $view && '' !== $figure ? '<span class="mvweb-t-benefits__figure">' . esc_html( $figure ) . '</span>' : '';
	}

	$html  = '';
	$inner = '';

	foreach ( $mvweb_block['item_parts'] as $slug ) {
		if ( ! isset( $pieces[ $slug ] ) || '' === $pieces[ $slug ] ) {
			continue;
		}

		if ( 'card' !== $view && in_array( $slug, array( 'name', 'text' ), true ) ) {
			$inner .= $pieces[ $slug ];
			continue;
		}

		if ( '' !== $inner ) {
			$html .= '<div class="mvweb-t-benefits__body">' . $inner . '</div>';
			$inner = '';
		}

		$html .= $pieces[ $slug ];
	}

	if ( '' !== $inner ) {
		$html .= '<div class="mvweb-t-benefits__body">' . $inner . '</div>';
	}

	return '' !== $html ? '<li class="mvweb-t-benefits__item">' . $html . '</li>' : '';
};

$mvweb_render_list = static function ( array $items, $classes = 'mvweb-t-benefits__list' ) use ( $mvweb_render_item ) {
	$html = implode( '', array_map( $mvweb_render_item, $items ) );

	return '' !== $html ? '<ul class="' . esc_attr( $classes ) . '">' . $html . '</ul>' : '';
};

$mvweb_extra = 'tiles' === $mvweb_view && 'plain' === $mvweb_block['look']['background'] ? 'mvweb-t-section--surface' : '';

$mvweb_extra .= mvweb_theme_cards_colours( $mvweb_block );

mvweb_theme_section_open( $mvweb_block, true, trim( $mvweb_extra ) );

if ( 'card' === $mvweb_view ) {
	mvweb_theme_head( $mvweb_block, array_values( array_intersect( $mvweb_parts, array( 'title' ) ) ) );

	$mvweb_box = '';

	foreach ( $mvweb_parts as $mvweb_slug ) {
		if ( 'card_icon' === $mvweb_slug && ! empty( $mvweb_props['icon'] ) ) {
			$mvweb_box .= '<span class="mvweb-t-benefits__card-icon">' . mvweb_theme_icon( $mvweb_props['icon'] ) . '</span>';
		} elseif ( 'card_title' === $mvweb_slug && ! empty( $mvweb_props['card_title'] ) ) {
			$mvweb_box .= '<div class="mvweb-t-benefits__card-title mvweb-t-h3">' . esc_html( (string) $mvweb_props['card_title'] ) . '</div>';
		} elseif ( 'lead' === $mvweb_slug && ! empty( $mvweb_props['text'] ) ) {
			$mvweb_box .= '<p class="mvweb-t-section__desc">' . esc_html( (string) $mvweb_props['text'] ) . '</p>';
		} elseif ( 'list' === $mvweb_slug ) {
			$mvweb_box .= $mvweb_render_list( $mvweb_items, 'mvweb-t-benefits__checks' );
		}
	}

	if ( '' !== $mvweb_photo || '' !== $mvweb_box ) {
		echo '<div class="mvweb-t-benefits__layout">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
		echo '' !== $mvweb_photo ? '<span class="mvweb-t-cover mvweb-t-benefits__photo">' . $mvweb_photo . '</span>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Attachment markup.
		echo '' !== $mvweb_box ? '<div class="mvweb-t-benefits__card">' . $mvweb_box . '</div>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
		echo '</div>';
	}
} else {
	mvweb_theme_head( $mvweb_block, array_values( array_intersect( $mvweb_parts, array( 'title', 'lead' ) ) ) );

	if ( 'around' === $mvweb_view ) {
		$mvweb_half  = (int) ceil( count( $mvweb_items ) / 2 );
		$mvweb_start = $mvweb_list ? $mvweb_render_list( array_slice( $mvweb_items, 0, $mvweb_half ), 'mvweb-t-benefits__list mvweb-t-benefits__side' ) : '';
		$mvweb_end   = $mvweb_list ? $mvweb_render_list( array_slice( $mvweb_items, $mvweb_half ), 'mvweb-t-benefits__list mvweb-t-benefits__side' ) : '';

		if ( '' !== $mvweb_photo || '' !== $mvweb_start . $mvweb_end ) {
			echo '<div class="mvweb-t-benefits__around">' . $mvweb_start . ( '' !== $mvweb_photo ? '<span class="mvweb-t-cover mvweb-t-cover--tall mvweb-t-benefits__arch">' . $mvweb_photo . '</span>' : '' ) . $mvweb_end . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and attachment markup.
		}
	} elseif ( 'groups' === $mvweb_view ) {
		$mvweb_groups = array();

		foreach ( $mvweb_items as $mvweb_item ) {
			$mvweb_name = isset( $mvweb_item['group'] ) ? trim( (string) $mvweb_item['group'] ) : '';
			$mvweb_last = count( $mvweb_groups ) - 1;

			if ( $mvweb_last < 0 || $mvweb_groups[ $mvweb_last ]['name'] !== $mvweb_name ) {
				$mvweb_groups[] = array(
					'name'  => $mvweb_name,
					'image' => 0,
					'items' => array(),
				);
				++$mvweb_last;
			}

			if ( ! $mvweb_groups[ $mvweb_last ]['image'] && ! empty( $mvweb_item['image'] ) ) {
				$mvweb_groups[ $mvweb_last ]['image'] = (int) $mvweb_item['image'];
			}

			$mvweb_groups[ $mvweb_last ]['items'][] = $mvweb_item;
		}

		$mvweb_html = '';

		foreach ( $mvweb_groups as $mvweb_group ) {
			$mvweb_pic  = in_array( 'media', $mvweb_parts, true ) && $mvweb_group['image'] ? wp_get_attachment_image(
				$mvweb_group['image'],
				'mvweb_card',
				false,
				array(
					'loading' => 'lazy',
					'sizes'   => '(min-width: 1024px) 50vw, (min-width: 600px) 40vw, 100vw',
				)
			) : '';
			$mvweb_body = ( in_array( 'card_title', $mvweb_parts, true ) && '' !== $mvweb_group['name'] ? '<div class="mvweb-t-benefits__group-name mvweb-t-h3">' . esc_html( $mvweb_group['name'] ) . '</div>' : '' ) . ( $mvweb_list ? $mvweb_render_list( $mvweb_group['items'] ) : '' );

			if ( '' !== $mvweb_pic || '' !== $mvweb_body ) {
				$mvweb_html .= '<div class="mvweb-t-benefits__group">' . ( '' !== $mvweb_pic ? '<span class="mvweb-t-cover mvweb-t-benefits__group-img">' . $mvweb_pic . '</span>' : '' ) . ( '' !== $mvweb_body ? '<div class="mvweb-t-benefits__group-body">' . $mvweb_body . '</div>' : '' ) . '</div>';
			}
		}

		echo '' !== $mvweb_html ? '<div class="mvweb-t-benefits__groups">' . $mvweb_html . '</div>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and attachment markup.
	} elseif ( $mvweb_list ) {
		echo $mvweb_render_list( $mvweb_items ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	}
}

mvweb_theme_section_close();
