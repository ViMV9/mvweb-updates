<?php
/**
 * Section template: the authors of the blog.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'authors', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];

$mvweb_facts = array();

if ( 'trust' === $mvweb_block['mod'] ) {
	foreach ( isset( $mvweb_props['facts'] ) && is_array( $mvweb_props['facts'] ) ? mvweb_core_visible_rows( $mvweb_props['facts'] ) : array() as $mvweb_fact ) {
		$mvweb_fact = array(
			'number' => isset( $mvweb_fact['number'] ) ? trim( (string) $mvweb_fact['number'] ) : '',
			'label'  => isset( $mvweb_fact['label'] ) ? trim( (string) $mvweb_fact['label'] ) : '',
		);

		if ( '' !== $mvweb_fact['number'] || '' !== $mvweb_fact['label'] ) {
			$mvweb_facts[] = $mvweb_fact;
		}
	}

	if ( empty( $mvweb_facts ) ) {
		return;
	}
}

$mvweb_count   = isset( $mvweb_props['count'] ) ? max( 1, min( 48, absint( $mvweb_props['count'] ) ) ) : 12;
$mvweb_authors = 'trust' === $mvweb_block['mod'] ? array() : mvweb_core_authors( wp_parse_id_list( isset( $mvweb_props['ids'] ) ? (string) $mvweb_props['ids'] : '' ), 'editor' === $mvweb_block['mod'] ? 1 : $mvweb_count );

if ( empty( $mvweb_authors ) && empty( $mvweb_facts ) ) {
	return;
}

$mvweb_ava = static function ( $author, $size ) {
	$photo = mvweb_core_user_photo( $author['id'] );
	$css   = 'mvweb-t-authors__ava mvweb-t-authors__ava--' . $size;

	if ( $photo ) {
		return '<span class="' . esc_attr( $css ) . '">' . wp_get_attachment_image(
			$photo,
			array( 192, 192 ),
			false,
			array(
				'alt'      => '',
				'loading'  => 'lazy',
				'decoding' => 'async',
			)
		) . '</span>';
	}

	$letters = '';

	foreach ( array_slice( preg_split( '/\s+/u', trim( $author['name'] ), -1, PREG_SPLIT_NO_EMPTY ), 0, 2 ) as $word ) {
		$letters .= mb_strtoupper( mb_substr( $word, 0, 1 ) );
	}

	return '<span class="' . esc_attr( $css ) . '" aria-hidden="true">' . esc_html( $letters ) . '</span>';
};

$mvweb_card = static function ( $author ) use ( $mvweb_ava ) {
	?>
	<li>
		<a class="mvweb-t-authors__card" href="<?php echo esc_url( $author['url'] ); ?>">
			<?php echo $mvweb_ava( $author, 'xl' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
			<span class="mvweb-t-authors__name"><?php echo esc_html( $author['name'] ); ?></span>
			<?php if ( '' !== $author['role'] ) : ?>
				<span class="mvweb-t-authors__role"><?php echo esc_html( $author['role'] ); ?></span>
			<?php endif; ?>
			<?php if ( $author['posts'] > 0 ) : ?>
				<span class="mvweb-t-authors__posts"><?php echo esc_html( mvweb_core_articles( $author['posts'] ) ); ?></span>
			<?php endif; ?>
		</a>
	</li>
	<?php
};

$mvweb_row = static function ( $author ) use ( $mvweb_ava ) {
	?>
	<li>
		<a class="mvweb-t-authors__row" href="<?php echo esc_url( $author['url'] ); ?>">
			<?php echo $mvweb_ava( $author, 'lg' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
			<span>
				<span class="mvweb-t-authors__name"><?php echo esc_html( $author['name'] ); ?></span>
				<?php if ( '' !== $author['role'] ) : ?>
					<span class="mvweb-t-authors__role"><?php echo esc_html( $author['role'] ); ?></span>
				<?php endif; ?>
			</span>
		</a>
	</li>
	<?php
};

$mvweb_editor = static function ( $author ) use ( $mvweb_ava, $mvweb_props ) {
	$letter = isset( $mvweb_props['letter'] ) ? trim( (string) $mvweb_props['letter'] ) : '';
	$lines  = '' !== $letter ? preg_split( '/\n\s*\n/u', $letter ) : ( '' !== $author['bio'] ? array( $author['bio'] ) : array() );
	$label  = isset( $mvweb_props['chief_label'] ) ? trim( (string) $mvweb_props['chief_label'] ) : '';
	$about  = implode( ', ', array_filter( array( $label, $author['role'] ) ) );
	?>
	<figure class="mvweb-t-authors__editor">
		<?php if ( ! empty( $lines ) ) : ?>
			<blockquote class="mvweb-t-authors__quote">
				<?php foreach ( $lines as $line ) : ?>
					<p><?php echo esc_html( trim( $line ) ); ?></p>
				<?php endforeach; ?>
			</blockquote>
		<?php endif; ?>
		<figcaption class="mvweb-t-authors__who">
			<?php echo $mvweb_ava( $author, 'lg' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
			<span>
				<a class="mvweb-t-authors__name" href="<?php echo esc_url( $author['url'] ); ?>"><?php echo esc_html( $author['name'] ); ?></a>
				<?php if ( '' !== $about ) : ?>
					<span class="mvweb-t-authors__role"><?php echo esc_html( $about ); ?></span>
				<?php endif; ?>
			</span>
		</figcaption>
	</figure>
	<?php
};

$mvweb_parts = array(
	'list' => static function ( $block ) use ( $mvweb_authors, $mvweb_facts, $mvweb_card, $mvweb_row, $mvweb_editor ) {
		if ( ! empty( $mvweb_facts ) ) {
			echo '<ul class="mvweb-t-authors__facts">';

			foreach ( $mvweb_facts as $fact ) {
				echo '<li class="mvweb-t-authors__fact">';

				if ( '' !== $fact['number'] ) {
					echo '<span class="mvweb-t-authors__num">' . esc_html( $fact['number'] ) . '</span>';
				}

				if ( '' !== $fact['label'] ) {
					echo '<span class="mvweb-t-authors__text">' . esc_html( $fact['label'] ) . '</span>';
				}

				echo '</li>';
			}

			echo '</ul>';

			return;
		}

		if ( 'editor' === $block['mod'] ) {
			$mvweb_editor( $mvweb_authors[0] );

			return;
		}

		echo '<ul class="mvweb-t-authors__list">';
		array_map( 'about' === $block['mod'] ? $mvweb_row : $mvweb_card, $mvweb_authors );
		echo '</ul>';
	},
);

$mvweb_head = array();

if ( 'about' === $mvweb_block['mod'] && ! empty( $mvweb_props['button_text'] ) && ! empty( $mvweb_props['button_url'] ) ) {
	$mvweb_head['side'] = '<a class="mvweb-t-btn mvweb-t-btn--outline" href="' . esc_url( (string) $mvweb_props['button_url'] ) . '">' . esc_html( (string) $mvweb_props['button_text'] ) . '</a>';
}

mvweb_theme_section_open( $mvweb_block, true, 'editor' === $mvweb_block['mod'] && 'plain' === $mvweb_block['look']['background'] ? 'mvweb-t-section--inverse' : '' );
mvweb_theme_render_parts( $mvweb_block, $mvweb_parts, $mvweb_head );
mvweb_theme_section_close();
