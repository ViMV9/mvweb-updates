<?php
/**
 * Section template: two banners side by side.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'banner-pair', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_mod   = $mvweb_block['mod'];
$mvweb_rows  = isset( $mvweb_block['props']['banners'] ) && is_array( $mvweb_block['props']['banners'] ) ? array_values(
	array_filter(
		mvweb_core_visible_rows( $mvweb_block['props']['banners'] ),
		static function ( $row ) {
			return ! mvweb_core_offer_ended( isset( $row['until'] ) ? $row['until'] : '' );
		}
	)
) : array();

if ( empty( $mvweb_rows ) ) {
	return;
}

$mvweb_val = static function ( array $row, $key ) {
	return isset( $row[ $key ] ) && is_scalar( $row[ $key ] ) ? trim( (string) $row[ $key ] ) : '';
};

$mvweb_arrow = mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) );

$mvweb_texts = array(
	'title'  => static function ( array $row ) use ( $mvweb_val ) {
		return '' !== $mvweb_val( $row, 'title' ) ? '<span class="mvweb-t-banner-pair__title">' . esc_html( $mvweb_val( $row, 'title' ) ) . '</span>' : '';
	},
	'text'   => static function ( array $row ) use ( $mvweb_val ) {
		return '' !== $mvweb_val( $row, 'text' ) ? '<span class="mvweb-t-banner-pair__text">' . esc_html( $mvweb_val( $row, 'text' ) ) . '</span>' : '';
	},
	'button' => static function ( array $row ) use ( $mvweb_val, $mvweb_mod, $mvweb_arrow ) {
		$label = $mvweb_val( $row, 'button_text' );

		if ( '' === $label || '' === $mvweb_val( $row, 'button_url' ) || 'plates' === $mvweb_mod ) {
			return '';
		}

		if ( 'figure' === $mvweb_mod ) {
			return '<span class="mvweb-t-section__more">' . esc_html( $label ) . $mvweb_arrow . '</span>';
		}

		return '<span class="mvweb-t-btn mvweb-t-btn--sm mvweb-t-banner-pair__btn">' . esc_html( $label ) . '</span>';
	},
);

$mvweb_item = static function ( array $row, $index ) use ( $mvweb_block, $mvweb_mod, $mvweb_val, $mvweb_texts, $mvweb_arrow ) {
	$parts = $mvweb_block['item_parts'];
	$body  = '';
	$url   = $mvweb_val( $row, 'button_url' );
	$image = absint( $mvweb_val( $row, 'image_1' ) );
	$image = $image && in_array( $mvweb_mod, array( 'cards', 'overlay', 'wide' ), true ) && wp_attachment_is_image( $image ) ? $image : 0;
	$icon  = in_array( $mvweb_mod, array( 'cards', 'wide' ), true ) ? $mvweb_val( $row, 'icon' ) : '';
	$pics  = in_array( 'pics', $parts, true );
	$class = 'mvweb-t-banner-pair__item';
	$media = '';
	$after = '';

	foreach ( $parts as $slug ) {
		if ( isset( $mvweb_texts[ $slug ] ) ) {
			$body .= call_user_func( $mvweb_texts[ $slug ], $row );
		}
	}

	if ( 'wide' === $mvweb_mod && 1 === $index ) {
		$image = 0;
		$media = $pics && '' !== $icon ? '<span class="mvweb-t-banner-pair__ico">' . mvweb_theme_icon( $icon ) . '</span>' : '';
	} elseif ( $pics && $image ) {
		$sizes = 'cards' === $mvweb_mod ? '(min-width: 600px) 200px, 32vw' : ( 'wide' === $mvweb_mod ? '(min-width: 1024px) 66vw, 100vw' : '(min-width: 600px) 50vw, 100vw' );
		$media = '<span class="mvweb-t-banner-pair__cover">' . wp_get_attachment_image(
			$image,
			'cards' === $mvweb_mod ? 'mvweb_card' : 'mvweb_wide',
			false,
			array(
				'alt'      => '',
				'loading'  => 'lazy',
				'decoding' => 'async',
				'sizes'    => $sizes,
			)
		) . '</span>';
	} elseif ( $pics && 'cards' === $mvweb_mod && '' !== $icon ) {
		$media = '<span class="mvweb-t-banner-pair__cover mvweb-t-banner-pair__cover--icon">' . mvweb_theme_icon( $icon ) . '</span>';
	}

	if ( 'overlay' === $mvweb_mod || ( 'wide' === $mvweb_mod && 0 === $index ) ) {
		$class .= '' !== $media ? ' mvweb-t-banner-pair__item--photo' : ' mvweb-t-banner-pair__item--plain';
	}

	if ( 'plates' === $mvweb_mod && '' !== $url && '' !== $mvweb_val( $row, 'button_text' ) && in_array( 'button', $parts, true ) ) {
		$after = '<span class="mvweb-t-banner-pair__go">' . esc_html( $mvweb_val( $row, 'button_text' ) ) . $mvweb_arrow . '</span>';
	}

	if ( 'figure' === $mvweb_mod && in_array( 'sticker', $parts, true ) && '' !== $mvweb_val( $row, 'sticker' ) . $mvweb_val( $row, 'sticker_note' ) ) {
		$media = '<span class="mvweb-t-banner-pair__fig">' . esc_html( $mvweb_val( $row, 'sticker' ) ) . ( '' !== $mvweb_val( $row, 'sticker_note' ) ? '<small>' . esc_html( $mvweb_val( $row, 'sticker_note' ) ) . '</small>' : '' ) . '</span>';
	}

	if ( '' === $body . $media . $after ) {
		return '';
	}

	$html = ( 'cards' === $mvweb_mod ? '' : $media ) . ( '' !== $body ? '<span class="mvweb-t-banner-pair__body">' . $body . '</span>' : '' ) . ( 'cards' === $mvweb_mod ? $media : '' ) . $after;

	return '' !== $url ? '<a class="' . $class . '" href="' . esc_url( $url ) . '">' . $html . '</a>' : '<div class="' . $class . '">' . $html . '</div>';
};

$mvweb_list = '';

foreach ( $mvweb_rows as $mvweb_index => $mvweb_row ) {
	$mvweb_list .= $mvweb_item( $mvweb_row, $mvweb_index );
}

if ( '' === $mvweb_list ) {
	return;
}

$mvweb_parts = array(
	'list' => static function () use ( $mvweb_list ) {
		echo '<div class="mvweb-t-banner-pair__list">' . $mvweb_list . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	},
);

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts( $mvweb_block, $mvweb_parts );
mvweb_theme_section_close();
