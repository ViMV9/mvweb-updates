<?php
/**
 * Section template: long text for search.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'seo-text', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_parts = $mvweb_block['parts'];
$mvweb_view  = $mvweb_block['mod'];

$mvweb_value = static function ( $key ) use ( $mvweb_props ) {
	return isset( $mvweb_props[ $key ] ) ? trim( (string) $mvweb_props[ $key ] ) : '';
};

$mvweb_text = '' !== $mvweb_value( 'text' ) ? preg_replace( '#<(/?)h1(?=[\s>])#i', '<$1h2', wp_kses_post( wpautop( $mvweb_value( 'text' ) ) ) ) : '';

if ( '' === $mvweb_text ) {
	return;
}

$mvweb_text = preg_replace( '#<table[\s>].*?</table>#is', '<div class="mvweb-t-seo-text__table">$0</div>', $mvweb_text );

$mvweb_mode  = 'fold' === $mvweb_view ? 'height' : $mvweb_value( 'spoiler' );
$mvweb_lines = absint( $mvweb_value( 'spoiler_lines' ) );
$mvweb_lines = $mvweb_lines > 0 ? min( 40, max( 3, $mvweb_lines ) ) : 8;

if ( ! in_array( $mvweb_mode, array( 'height', 'all' ), true ) || ! in_array( 'spoiler', $mvweb_parts, true ) ) {
	$mvweb_mode = 'none';
}

if ( 'height' === $mvweb_mode && mb_strlen( wp_strip_all_tags( $mvweb_text ) ) < $mvweb_lines * 70 && ! preg_match( '#<(table|ul|ol|dl|blockquote|pre|h[1-6])[\s>]#i', $mvweb_text ) ) {
	$mvweb_mode = 'none';
}

$mvweb_more = '' !== $mvweb_value( 'more_label' ) ? $mvweb_value( 'more_label' ) : _x( 'Read more', 'Text spoiler button', 'journal' );
$mvweb_less = '' !== $mvweb_value( 'less_label' ) ? $mvweb_value( 'less_label' ) : __( 'Collapse', 'journal' );

$mvweb_tag = 'div';

if ( ! empty( $mvweb_props['title_h1'] ) && '' !== $mvweb_value( 'title' ) && in_array( 'title', $mvweb_parts, true ) && is_front_page() ) {
	$mvweb_tag = mvweb_core_h1_tag( 'seo-text' );
}

$mvweb_renderers = array(
	'text' => static function () use ( $mvweb_text, $mvweb_mode, $mvweb_lines, $mvweb_more, $mvweb_less ) {
		if ( 'none' === $mvweb_mode ) {
			echo '<div class="mvweb-t-prose mvweb-t-seo-text__text">' . $mvweb_text . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Filtered text of the editor.

			return;
		}

		$class = 'height' === $mvweb_mode ? 'mvweb-t-seo-text__fold mvweb-t-seo-text__fold--cut' : 'mvweb-t-seo-text__fold';
		$style = 'height' === $mvweb_mode ? ' style="--mvweb-t-seo-lines:' . absint( $mvweb_lines ) . '"' : '';
		?>
		<details class="<?php echo esc_attr( $class ); ?>"<?php echo $style; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute with a number. ?>>
			<summary class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-seo-text__toggle">
				<span class="mvweb-t-seo-text__more"><?php echo esc_html( $mvweb_more ); ?></span>
				<span class="mvweb-t-seo-text__less"><?php echo esc_html( $mvweb_less ); ?></span>
				<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			</summary>
			<div class="mvweb-t-prose mvweb-t-seo-text__text"><?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Filtered text of the editor. ?></div>
		</details>
		<?php
	},
);

$mvweb_capture = static function ( array $slugs ) use ( $mvweb_block, $mvweb_renderers, $mvweb_tag ) {
	$part = $mvweb_block;

	$part['parts'] = $slugs;

	ob_start();
	mvweb_theme_render_parts( $part, $mvweb_renderers, array( 'title_tag' => $mvweb_tag ) );

	return trim( (string) ob_get_clean() );
};

$mvweb_intro = '';

if ( 'side' === $mvweb_view ) {
	$mvweb_intro = $mvweb_capture( array_values( array_intersect( $mvweb_parts, array( 'kicker', 'title' ) ) ) );
	$mvweb_body  = $mvweb_capture( array_values( array_diff( $mvweb_parts, array( 'kicker', 'title' ) ) ) );
} else {
	$mvweb_body = $mvweb_capture( $mvweb_parts );
}

if ( '' === $mvweb_intro && '' === $mvweb_body ) {
	return;
}

mvweb_theme_section_open( $mvweb_block, true, 'side' === $mvweb_view && 'plain' === $mvweb_block['look']['background'] ? 'mvweb-t-section--surface' : '' );
?>
<div class="mvweb-t-seo-text__layout<?php echo '' !== $mvweb_intro && '' !== $mvweb_body ? ' mvweb-t-seo-text__layout--split' : ''; ?>">
	<?php if ( '' !== $mvweb_intro ) : ?>
		<div class="mvweb-t-seo-text__intro"><?php echo $mvweb_intro; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part renderers above. ?></div>
	<?php endif; ?>
	<?php if ( '' !== $mvweb_body ) : ?>
		<div class="mvweb-t-seo-text__body"><?php echo $mvweb_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part renderers above. ?></div>
	<?php endif; ?>
</div>
<?php
mvweb_theme_section_close();
