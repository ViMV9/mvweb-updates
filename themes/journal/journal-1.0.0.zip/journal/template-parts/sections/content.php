<?php
/**
 * Section template: text block.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'content', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_parts = $mvweb_block['parts'];
$mvweb_view  = $mvweb_block['mod'];

$mvweb_value = static function ( $key ) use ( $mvweb_props ) {
	return isset( $mvweb_props[ $key ] ) ? trim( (string) $mvweb_props[ $key ] ) : '';
};

$mvweb_text = '';

if ( in_array( 'text', $mvweb_parts, true ) ) {
	$mvweb_text = '' !== $mvweb_value( 'text' ) ? wp_kses_post( wpautop( $mvweb_value( 'text' ) ) ) : trim( (string) apply_filters( 'the_content', get_post_field( 'post_content', get_the_ID() ) ) );
}

$mvweb_image = static function ( $key, $classes ) use ( $mvweb_props, $mvweb_parts ) {
	$id = isset( $mvweb_props[ $key ] ) ? absint( $mvweb_props[ $key ] ) : 0;

	if ( $id <= 0 || ! in_array( $key, $mvweb_parts, true ) ) {
		return '';
	}

	$picture = wp_get_attachment_image(
		$id,
		'large',
		false,
		array(
			'loading' => 'lazy',
			'sizes'   => '(min-width: 1024px) 36rem, 100vw',
		)
	);

	return '' !== $picture ? '<span class="mvweb-t-cover ' . esc_attr( $classes ) . '">' . $picture . '</span>' : '';
};

$mvweb_button = '';

if ( in_array( 'button', $mvweb_parts, true ) && '' !== $mvweb_value( 'button_text' ) && '' !== $mvweb_value( 'button_url' ) ) {
	$mvweb_kind = $mvweb_block['look']['button_kind'];

	if ( 'link' === $mvweb_kind ) {
		$mvweb_button = '<a class="mvweb-t-section__more" href="' . esc_url( $mvweb_value( 'button_url' ) ) . '">' . esc_html( $mvweb_value( 'button_text' ) ) . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>';
	} else {
		$mvweb_class  = 'secondary' === $mvweb_kind ? 'mvweb-t-btn mvweb-t-btn--outline' : ( 'pair' === $mvweb_view ? 'mvweb-t-btn mvweb-t-btn--soft' : 'mvweb-t-btn' );
		$mvweb_button = '<a class="' . esc_attr( $mvweb_class ) . '" href="' . esc_url( $mvweb_value( 'button_url' ) ) . '">' . esc_html( $mvweb_value( 'button_text' ) ) . '</a>';
	}
}

$mvweb_renderers = array(
	'text'   => static function () use ( $mvweb_text ) {
		if ( '' !== $mvweb_text ) {
			echo '<div class="mvweb-t-prose mvweb-t-content__prose">' . $mvweb_text . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Filtered text of the editor or of the entry.
		}
	},
	'button' => static function () use ( $mvweb_button ) {
		echo $mvweb_button; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	},
);

$mvweb_capture = static function ( array $slugs ) use ( $mvweb_block, $mvweb_renderers ) {
	$part = $mvweb_block;

	$part['parts'] = $slugs;

	ob_start();
	mvweb_theme_render_parts( $part, $mvweb_renderers );

	return trim( (string) ob_get_clean() );
};

$mvweb_intro = '';

if ( 'lead' === $mvweb_view ) {
	$mvweb_intro = $mvweb_capture( array_values( array_intersect( $mvweb_parts, array( 'kicker', 'title' ) ) ) );
	$mvweb_body  = $mvweb_capture( array_values( array_diff( $mvweb_parts, array( 'kicker', 'title' ) ) ) );
} else {
	$mvweb_body = $mvweb_capture( $mvweb_parts );
}

$mvweb_media = '';

if ( 'badge' === $mvweb_view ) {
	$mvweb_media = $mvweb_image( 'image', 'mvweb-t-cover--tall mvweb-t-content__pic' );

	if ( '' !== $mvweb_media && in_array( 'badge', $mvweb_parts, true ) && ( '' !== $mvweb_value( 'badge_title' ) || '' !== $mvweb_value( 'badge_text' ) ) ) {
		$mvweb_media .= '<span class="mvweb-t-content__badge">'
			. ( '' !== $mvweb_value( 'badge_icon' ) ? '<span class="mvweb-t-content__badge-icon">' . mvweb_theme_icon( $mvweb_value( 'badge_icon' ) ) . '</span>' : '' )
			. '<span class="mvweb-t-content__badge-text">'
			. ( '' !== $mvweb_value( 'badge_title' ) ? '<b>' . esc_html( $mvweb_value( 'badge_title' ) ) . '</b>' : '' )
			. ( '' !== $mvweb_value( 'badge_text' ) ? '<small>' . esc_html( $mvweb_value( 'badge_text' ) ) . '</small>' : '' )
			. '</span></span>';
	}
} elseif ( 'pair' === $mvweb_view ) {
	$mvweb_media = $mvweb_image( 'image', 'mvweb-t-cover--tall mvweb-t-content__pic' ) . $mvweb_image( 'image_2', 'mvweb-t-cover--square mvweb-t-content__pic mvweb-t-content__pic--second' );
}

$mvweb_quote = '';

if ( 'quote' === $mvweb_view && in_array( 'quote', $mvweb_parts, true ) && '' !== $mvweb_value( 'quote' ) ) {
	$mvweb_quote = '<figure class="mvweb-t-content__quote"><blockquote><p>' . esc_html( $mvweb_value( 'quote' ) ) . '</p></blockquote>'
		. ( '' !== $mvweb_value( 'quote_cite' ) ? '<figcaption>' . esc_html( $mvweb_value( 'quote_cite' ) ) . '</figcaption>' : '' )
		. '</figure>';
}

if ( '' === $mvweb_intro && '' === $mvweb_body && '' === $mvweb_media && '' === $mvweb_quote ) {
	return;
}

$mvweb_split = count( array_filter( array( $mvweb_intro, $mvweb_body, $mvweb_media, $mvweb_quote ) ) ) > 1;

mvweb_theme_section_open( $mvweb_block, true, 'lead' === $mvweb_view && 'plain' === $mvweb_block['look']['background'] ? 'mvweb-t-section--surface' : '' );
?>
<div class="mvweb-t-content__layout<?php echo $mvweb_split ? ' mvweb-t-content__layout--split' : ''; ?>">
	<?php if ( '' !== $mvweb_media && 'pair' === $mvweb_view ) : ?>
		<div class="mvweb-t-content__media"><?php echo $mvweb_media; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the attachment images and escaped values. ?></div>
	<?php endif; ?>
	<?php if ( '' !== $mvweb_intro ) : ?>
		<div class="mvweb-t-content__intro"><?php echo $mvweb_intro; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part renderers above. ?></div>
	<?php endif; ?>
	<?php if ( '' !== $mvweb_body ) : ?>
		<div class="mvweb-t-content__body"><?php echo $mvweb_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part renderers above. ?></div>
	<?php endif; ?>
	<?php if ( '' !== $mvweb_media && 'pair' !== $mvweb_view ) : ?>
		<div class="mvweb-t-content__media"><?php echo $mvweb_media; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the attachment images and escaped values. ?></div>
	<?php endif; ?>
	<?php echo $mvweb_quote; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
</div>
<?php
mvweb_theme_section_close();
