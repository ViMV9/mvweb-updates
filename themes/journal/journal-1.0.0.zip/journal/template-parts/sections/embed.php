<?php
/**
 * Section template: a widget of another plugin, a player or a form.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block     = mvweb_theme_block( 'embed', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props     = $mvweb_block['props'];
$mvweb_shortcode = mvweb_core_form_shortcode( isset( $mvweb_props['shortcode'] ) ? (string) $mvweb_props['shortcode'] : '' );
$mvweb_code      = isset( $mvweb_props['code'] ) ? trim( (string) $mvweb_props['code'] ) : '';
$mvweb_widget    = trim( $mvweb_shortcode . $mvweb_code );
$mvweb_rv        = '' !== $mvweb_block['motion'] ? ' data-rv' : '';

if ( '' === $mvweb_widget ) {
	return;
}

$mvweb_widget = (string) preg_replace( '/<iframe\b(?![^>]*\sloading=)/i', '<iframe loading="lazy"', $mvweb_widget );
$mvweb_view   = $mvweb_block['mod'];
$mvweb_plain  = 'plain' === $mvweb_block['look']['background'];
$mvweb_extra  = array();

if ( 'numbered' !== $mvweb_view && isset( $mvweb_props['width'] ) && 'narrow' === $mvweb_props['width'] ) {
	$mvweb_extra[] = 'mvweb-t-embed--narrow';
}

if ( $mvweb_plain && in_array( $mvweb_view, array( 'bar', 'poll' ), true ) ) {
	$mvweb_extra[] = 'mvweb-t-section--surface';
} elseif ( $mvweb_plain && 'dark' === $mvweb_view ) {
	$mvweb_extra[] = 'mvweb-t-section--inverse';
}

$mvweb_box = static function ( $css ) use ( $mvweb_widget ) {
	echo '<div class="mvweb-t-embed__' . esc_attr( $css ) . '">' . $mvweb_widget . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Shortcode output is escaped by the plugin that owns it; the code is filtered on save by mvweb_core_sanitize_code().
};

if ( 'poll' === $mvweb_view ) {
	$mvweb_pending = array();
	$mvweb_words   = isset( $mvweb_props['ticker'] ) ? mvweb_core_text_lines( (string) $mvweb_props['ticker'] ) : array();

	mvweb_theme_section_open( $mvweb_block, false, implode( ' ', $mvweb_extra ) );

	foreach ( array_merge( $mvweb_block['parts'], array( '' ) ) as $mvweb_slug ) {
		if ( in_array( $mvweb_slug, array( 'kicker', 'title', 'lead' ), true ) ) {
			$mvweb_pending[] = $mvweb_slug;
			continue;
		}

		if ( ! empty( $mvweb_pending ) ) {
			echo '<div class="mvweb-t-container mvweb-t-embed__narrow"' . $mvweb_rv . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.
			mvweb_theme_head( $mvweb_block, $mvweb_pending );
			echo '</div>';
			$mvweb_pending = array();
		}

		if ( 'ticker' === $mvweb_slug && ! empty( $mvweb_words ) ) {
			$mvweb_pause = __( 'Pause the running line', 'journal' );
			?>
			<div class="mvweb-t-embed__ticker" data-ticker<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
				<div class="mvweb-t-embed__window">
					<div class="mvweb-t-embed__track" data-ticker-track>
						<ul class="mvweb-t-embed__run" role="list">
							<?php foreach ( $mvweb_words as $mvweb_word ) : ?>
								<li><?php echo esc_html( $mvweb_word ); ?></li>
							<?php endforeach; ?>
						</ul>
					</div>
				</div>
				<button class="mvweb-t-embed__pause" type="button" data-ticker-toggle aria-pressed="false" title="<?php echo esc_attr( $mvweb_pause ); ?>">
					<span class="mvweb-t-embed__bars" aria-hidden="true"></span>
					<?php echo mvweb_theme_icon( 'play', array( 'class' => 'mvweb-t-icon--sm mvweb-t-embed__play' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Ready markup of the icon helper. ?>
					<span class="screen-reader-text"><?php echo esc_html( $mvweb_pause ); ?></span>
				</button>
			</div>
			<?php
		}
	}

	echo '<div class="mvweb-t-container mvweb-t-embed__narrow"' . $mvweb_rv . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.
	$mvweb_box( 'card' );
	echo '</div>';
	mvweb_theme_section_close( false );

	return;
}

mvweb_theme_section_open( $mvweb_block, true, implode( ' ', $mvweb_extra ) );

if ( in_array( $mvweb_view, array( 'bar', 'dark' ), true ) ) {
	ob_start();
	mvweb_theme_render_parts( $mvweb_block, array() );
	$mvweb_head = trim( (string) ob_get_clean() );
	?>
	<div class="mvweb-t-embed__layout">
		<?php if ( '' !== $mvweb_head ) : ?>
			<div class="mvweb-t-embed__intro"><?php echo $mvweb_head; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the head helper. ?></div>
		<?php endif; ?>
		<?php $mvweb_box( 'form' ); ?>
	</div>
	<?php
} else {
	mvweb_theme_render_parts( $mvweb_block, array() );
	$mvweb_box( 'video' === $mvweb_view ? 'frame' : 'form' );
}

mvweb_theme_section_close();
