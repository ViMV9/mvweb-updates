<?php
/**
 * Section template: wide banner.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'banner', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_mod   = $mvweb_block['mod'];
$mvweb_look  = $mvweb_block['look'];
$mvweb_parts = $mvweb_block['parts'];
$mvweb_rv    = '' !== $mvweb_block['motion'] ? ' data-rv' : '';

$mvweb_text = static function ( $key ) use ( $mvweb_props ) {
	return isset( $mvweb_props[ $key ] ) && is_scalar( $mvweb_props[ $key ] ) ? trim( (string) $mvweb_props[ $key ] ) : '';
};

$mvweb_image = absint( $mvweb_text( 'image' ) );
$mvweb_image = $mvweb_image && in_array( $mvweb_mod, array( 'photo', 'card', 'partner' ), true ) && wp_attachment_is_image( $mvweb_image ) ? $mvweb_image : 0;
$mvweb_title = $mvweb_text( 'title' );
$mvweb_lead  = $mvweb_text( 'text' );
$mvweb_label = $mvweb_text( 'button_text' );
$mvweb_url   = $mvweb_text( 'button_url' );
$mvweb_new   = $mvweb_text( 'price_new' );
$mvweb_old   = $mvweb_text( 'price_old' );
$mvweb_last  = '' !== $mvweb_text( 'until' ) ? date_create_immutable( $mvweb_text( 'until' ), wp_timezone() ) : false;
$mvweb_until = $mvweb_last ? sprintf(
	/* translators: %s: last day of the offer, such as 31 October. */
	__( 'until %s', 'journal' ),
	wp_date( 'j F', $mvweb_last->getTimestamp() )
) : '';
$mvweb_ad = 'partner' === $mvweb_mod && function_exists( 'mvweb_core_ad_label' ) ? mvweb_core_ad_label( $mvweb_props ) : '';

if ( ! $mvweb_image && '' === $mvweb_title && '' === $mvweb_lead && ( '' === $mvweb_label || '' === $mvweb_url ) ) {
	return;
}

$mvweb_amount = static function ( $price ) {
	$digits = str_replace( ',', '.', (string) preg_replace( '/[^\d.,]/u', '', $price ) );

	if ( substr_count( $digits, '.' ) > 1 ) {
		$digits = str_replace( '.', '', substr( $digits, 0, (int) strrpos( $digits, '.' ) ) ) . substr( $digits, (int) strrpos( $digits, '.' ) );
	}

	return is_numeric( $digits ) ? (float) $digits : null;
};

$mvweb_saving = '';
$mvweb_from   = $mvweb_amount( $mvweb_old );
$mvweb_to     = $mvweb_amount( $mvweb_new );

if ( null !== $mvweb_from && null !== $mvweb_to && $mvweb_from > $mvweb_to ) {
	$mvweb_diff   = $mvweb_from - $mvweb_to;
	$mvweb_sign   = trim( (string) preg_replace( '/[\d\s\x{00a0}.,]+/u', '', $mvweb_new ) );
	$mvweb_figure = number_format_i18n( $mvweb_diff, floor( $mvweb_diff ) === $mvweb_diff ? 0 : 2 );

	if ( '' === $mvweb_sign ) {
		$mvweb_saving = $mvweb_figure;
	} elseif ( 1 === preg_match( '/^\D/u', $mvweb_new ) ) {
		$mvweb_saving = $mvweb_sign . $mvweb_figure;
	} else {
		$mvweb_saving = $mvweb_figure . "\u{00a0}" . $mvweb_sign;
	}
}

$mvweb_arrow = mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) );

$mvweb_renderers = array(
	'tag'    => static function () use ( $mvweb_text, $mvweb_mod, $mvweb_ad ) {
		$tag = $mvweb_text( 'tag' );

		if ( 'partner' === $mvweb_mod ) {
			$pill = '' !== $mvweb_ad ? '<span class="mvweb-t-badge mvweb-t-banner__pill">' . esc_html__( 'Advertisement', 'journal' ) . '</span>' : '';

			return '' !== $pill . $tag ? '<span class="mvweb-t-banner__adv">' . $pill . ( '' !== $tag ? '<span>' . esc_html( $tag ) . '</span>' : '' ) . '</span>' : '';
		}

		if ( '' === $tag ) {
			return '';
		}

		$classes = array(
			'photo'  => 'mvweb-t-badge mvweb-t-banner__pill',
			'accent' => 'mvweb-t-banner__tag',
		);

		return '<span class="' . ( isset( $classes[ $mvweb_mod ] ) ? $classes[ $mvweb_mod ] : 'mvweb-t-kicker mvweb-t-banner__kicker' ) . '">' . esc_html( $tag ) . '</span>';
	},
	'title'  => static function () use ( $mvweb_title ) {
		return '' !== $mvweb_title ? '<div class="mvweb-t-banner__title" role="heading" aria-level="2">' . esc_html( $mvweb_title ) . '</div>' : '';
	},
	'lead'   => static function () use ( $mvweb_lead ) {
		return '' !== $mvweb_lead ? '<p class="mvweb-t-banner__text">' . esc_html( $mvweb_lead ) . '</p>' : '';
	},
	'prices' => static function () use ( $mvweb_new, $mvweb_old ) {
		return '' !== $mvweb_new ? '<p class="mvweb-t-banner__price"><b>' . esc_html( $mvweb_new ) . '</b>' . ( '' !== $mvweb_old ? '<s>' . esc_html( $mvweb_old ) . '</s>' : '' ) . '</p>' : '';
	},
	'sale'   => static function () use ( $mvweb_saving, $mvweb_text ) {
		return '' !== $mvweb_saving ? '<span>' . esc_html( trim( $mvweb_text( 'sale_label' ) . ' ' . $mvweb_saving ) ) . '</span>' : '';
	},
	'until'  => static function () use ( $mvweb_until ) {
		return '' !== $mvweb_until ? '<span>' . esc_html( $mvweb_until ) . '</span>' : '';
	},
	'button' => static function () use ( $mvweb_label, $mvweb_url, $mvweb_mod, $mvweb_text, $mvweb_arrow ) {
		if ( 'partner' === $mvweb_mod ) {
			return '' !== $mvweb_label && '' !== $mvweb_url ? '<span class="mvweb-t-section__more mvweb-t-banner__more">' . esc_html( $mvweb_label ) . $mvweb_arrow . '</span>' : '';
		}

		$html = '' !== $mvweb_label && '' !== $mvweb_url ? '<a class="mvweb-t-btn mvweb-t-banner__btn" href="' . esc_url( $mvweb_url ) . '">' . esc_html( $mvweb_label ) . '</a>' : '';

		if ( 'card' === $mvweb_mod && '' !== $mvweb_text( 'button2_text' ) && '' !== $mvweb_text( 'button2_url' ) ) {
			$html .= '<a class="mvweb-t-btn mvweb-t-btn--ghost mvweb-t-banner__alt" href="' . esc_url( $mvweb_text( 'button2_url' ) ) . '">' . $mvweb_arrow . esc_html( $mvweb_text( 'button2_text' ) ) . '</a>';
		}

		return '' !== $html ? '<div class="mvweb-t-banner__btns">' . $html . '</div>' : '';
	},
);

$mvweb_group = static function ( array $slugs, $wrap, $tail = '' ) use ( $mvweb_parts, $mvweb_renderers ) {
	$pieces = array();
	$save   = '';

	foreach ( array_values( array_intersect( $mvweb_parts, $slugs ) ) as $slug ) {
		$part = call_user_func( $mvweb_renderers[ $slug ] );

		if ( in_array( $slug, array( 'sale', 'until' ), true ) ) {
			$save          .= ( '' !== $save && '' !== $part ? '<span aria-hidden="true"> · </span>' : '' ) . $part;
			$pieces['save'] = '';
			continue;
		}

		$pieces[] = $part;
	}

	if ( isset( $pieces['save'] ) && '' !== $save ) {
		$pieces['save'] = '<p class="mvweb-t-banner__save">' . $save . '</p>';
	}

	$html = implode( '', $pieces ) . $tail;

	return '' !== $html ? '<div class="' . $wrap . '">' . $html . '</div>' : '';
};

$mvweb_picture = static function ( $size, $sizes ) use ( $mvweb_image ) {
	return $mvweb_image ? '<div class="mvweb-t-banner__media">' . wp_get_attachment_image(
		$mvweb_image,
		$size,
		false,
		array(
			'loading'  => 'lazy',
			'decoding' => 'async',
			'sizes'    => $sizes,
		)
	) . '</div>' : '';
};

$mvweb_class = 'mvweb-t-banner__box';
$mvweb_html  = '';
$mvweb_reel  = '';

if ( 'photo' === $mvweb_mod ) {
	$mvweb_html = $mvweb_picture( 'mvweb_wide', '(min-width: 1240px) 1240px, 100vw' ) . $mvweb_group( array( 'tag', 'title', 'lead', 'button' ), 'mvweb-t-banner__body' );
} elseif ( 'card' === $mvweb_mod ) {
	$mvweb_html   = $mvweb_group( array( 'tag', 'title', 'lead', 'button' ), 'mvweb-t-banner__body' ) . $mvweb_picture( 'mvweb_card', '(min-width: 600px) 360px, 100vw' );
	$mvweb_class .= 'start' === $mvweb_look['image_side'] ? ' mvweb-t-banner__box--start' : '';
	$mvweb_class .= in_array( $mvweb_look['image_size'], array( 's', 'l' ), true ) ? ' mvweb-t-banner__box--' . $mvweb_look['image_size'] : '';
} elseif ( 'accent' === $mvweb_mod ) {
	$mvweb_num     = $mvweb_text( 'sticker_num' );
	$mvweb_small   = $mvweb_text( 'sticker_text' );
	$mvweb_sticker = in_array( 'sticker', $mvweb_parts, true ) && '' !== $mvweb_num . $mvweb_small ? '<span class="mvweb-t-banner__sticker">' . ( '' !== $mvweb_num ? '<b>' . esc_html( $mvweb_num ) . '</b>' : '' ) . ( '' !== $mvweb_small ? '<small>' . esc_html( $mvweb_small ) . '</small>' : '' ) . '</span>' : '';
	$mvweb_html    = $mvweb_group( array( 'tag', 'title', 'lead' ), 'mvweb-t-banner__body' ) . $mvweb_group( array( 'prices', 'sale', 'until', 'button' ), 'mvweb-t-banner__buy' );
	$mvweb_html    = '' !== $mvweb_html ? $mvweb_sticker . $mvweb_html : '';
	$mvweb_class  .= '' !== $mvweb_sticker ? ' mvweb-t-banner__box--sticker' : '';
} elseif ( 'dark' === $mvweb_mod ) {
	$mvweb_html  = $mvweb_group( array( 'tag', 'title' ), 'mvweb-t-banner__body' ) . $mvweb_group( array( 'lead', 'button' ), 'mvweb-t-banner__side' );
	$mvweb_lines = mvweb_core_text_lines( $mvweb_text( 'ticker' ) );
	$mvweb_lines = ! empty( $mvweb_lines ) ? $mvweb_lines : array_values( array_filter( array( $mvweb_title, $mvweb_until ), 'strlen' ) );

	if ( in_array( 'reel', $mvweb_parts, true ) && ! empty( $mvweb_lines ) ) {
		$mvweb_count = count( $mvweb_lines );

		$mvweb_times = $mvweb_count * (int) ceil( 8 / $mvweb_count );

		for ( $mvweb_n = 0; $mvweb_n < $mvweb_times; $mvweb_n++ ) {
			$mvweb_reel .= '<li' . ( $mvweb_n >= $mvweb_count ? ' aria-hidden="true"' : '' ) . '>' . esc_html( $mvweb_lines[ $mvweb_n % $mvweb_count ] ) . '</li>';
		}

		$mvweb_stop = __( 'Pause the running line', 'journal' );
		$mvweb_reel = '<div class="mvweb-t-banner__ticker" data-ticker' . $mvweb_rv . '><div class="mvweb-t-banner__track" data-ticker-track><ul class="mvweb-t-banner__run" data-ticker-run>' . $mvweb_reel . '</ul></div><button class="mvweb-t-banner__stop" type="button" data-ticker-toggle aria-pressed="false" title="' . esc_attr( $mvweb_stop ) . '"><span class="mvweb-t-banner__bars"></span>' . mvweb_theme_icon( 'play', array( 'class' => 'mvweb-t-icon--sm' ) ) . '<span class="screen-reader-text">' . esc_html( $mvweb_stop ) . '</span></button></div>';
	}
} else {
	$mvweb_legal = '' !== $mvweb_ad ? '<span class="mvweb-t-banner__legal">' . esc_html( $mvweb_ad ) . '</span>' : '';
	$mvweb_html  = $mvweb_picture( 'mvweb_wide', '(min-width: 600px) 42vw, 100vw' ) . $mvweb_group( array( 'tag', 'title', 'lead', 'button' ), 'mvweb-t-banner__body', $mvweb_legal );
}

if ( '' === $mvweb_html && '' === $mvweb_reel ) {
	return;
}

if ( 'partner' === $mvweb_mod && '' !== $mvweb_url ) {
	$mvweb_html = '<a class="' . $mvweb_class . '" href="' . esc_url( $mvweb_url ) . '">' . $mvweb_html . '</a>';
} elseif ( '' !== $mvweb_html ) {
	$mvweb_html = '<div class="' . $mvweb_class . '">' . $mvweb_html . '</div>';
}

mvweb_theme_section_open( $mvweb_block, false, 'dark' === $mvweb_mod && 'plain' === $mvweb_look['background'] ? 'mvweb-t-section--inverse' : '' );
echo $mvweb_reel; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.

if ( '' !== $mvweb_html ) {
	echo '<div class="mvweb-t-container"' . $mvweb_rv . '>' . $mvweb_html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
}

mvweb_theme_section_close( false );
