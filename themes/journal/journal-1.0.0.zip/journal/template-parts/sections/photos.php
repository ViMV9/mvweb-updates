<?php
/**
 * Section template: photographs with captions.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'photos', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_rows  = isset( $mvweb_props['items'] ) && is_array( $mvweb_props['items'] ) ? mvweb_core_visible_rows( $mvweb_props['items'] ) : array();
$mvweb_shots = array();

_prime_post_caches( array_filter( array_map( 'absint', wp_list_pluck( $mvweb_rows, 'image' ) ) ), false, true );

foreach ( $mvweb_rows as $mvweb_row ) {
	$mvweb_image = isset( $mvweb_row['image'] ) ? absint( $mvweb_row['image'] ) : 0;

	if ( ! wp_attachment_is_image( $mvweb_image ) ) {
		continue;
	}

	$mvweb_size = isset( $mvweb_row['size'] ) ? (string) $mvweb_row['size'] : 'normal';

	$mvweb_shots[] = array(
		'image'   => $mvweb_image,
		'caption' => isset( $mvweb_row['caption'] ) ? trim( (string) $mvweb_row['caption'] ) : '',
		'url'     => isset( $mvweb_row['url'] ) ? trim( (string) $mvweb_row['url'] ) : '',
		'size'    => in_array( $mvweb_size, array( 'tall', 'square' ), true ) ? $mvweb_size : 'normal',
	);
}

if ( empty( $mvweb_shots ) ) {
	return;
}

$mvweb_view    = $mvweb_block['mod'];
$mvweb_caption = in_array( 'caption', $mvweb_block['item_parts'], true );
$mvweb_base    = 'mvweb-t-photos__';
$mvweb_uid     = isset( $args['uid'] ) ? sanitize_html_class( (string) $args['uid'] ) : '';
$mvweb_uid     = '' !== $mvweb_uid ? 'photos-' . $mvweb_uid : (string) wp_unique_id( 'photos-' );
$mvweb_sizes   = array(
	'mosaic' => '(min-width: 1024px) 25vw, 50vw',
	'grid'   => '(min-width: 1024px) 25vw, (min-width: 600px) 33vw, 50vw',
	'rail'   => '(min-width: 1024px) 20vw, (min-width: 600px) 42vw, 72vw',
	'cols'   => '(min-width: 1024px) 25vw, (min-width: 600px) 33vw, 50vw',
);

$mvweb_img = static function ( $id, $size, $sizes, $alt = null ) {
	$attr = array(
		'loading' => 'lazy',
		'sizes'   => $sizes,
	);

	if ( null !== $alt ) {
		$attr['alt'] = $alt;
	}

	return (string) wp_get_attachment_image( $id, $size, false, $attr );
};

$mvweb_name = static function ( $shot, $number ) use ( $mvweb_caption ) {
	if ( $mvweb_caption && '' !== $shot['caption'] ) {
		return '';
	}

	if ( '' !== $shot['caption'] ) {
		return $shot['caption'];
	}

	return '' === trim( (string) get_post_meta( $shot['image'], '_wp_attachment_image_alt', true ) )
		/* translators: %d: number of the photograph. */
		? sprintf( __( 'Photo %d', 'journal' ), $number )
		: '';
};

$mvweb_list = static function ( $block ) use ( $mvweb_shots, $mvweb_view, $mvweb_caption, $mvweb_base, $mvweb_uid, $mvweb_sizes, $mvweb_img, $mvweb_name ) {
	if ( 'stage' === $mvweb_view ) {
		$shots  = array_slice( $mvweb_shots, 0, 8 );
		$frames = '';
		$thumbs = '';

		foreach ( $shots as $i => $shot ) {
			$frames .= '<figure class="' . $mvweb_base . 'frame"><span class="mvweb-t-cover mvweb-t-cover--wide">' . $mvweb_img( $shot['image'], 'large', '(min-width: 1024px) 75vw, 100vw' ) . '</span>';
			$frames .= $mvweb_caption && '' !== $shot['caption'] ? '<figcaption class="' . $mvweb_base . 'cap">' . esc_html( $shot['caption'] ) . '</figcaption>' : '';
			$frames .= '</figure>';

			/* translators: %d: number of the photograph. */
			$label   = '' !== $shot['caption'] ? $shot['caption'] : sprintf( __( 'Photo %d', 'journal' ), $i + 1 );
			$thumbs .= '<label class="' . $mvweb_base . 'thumb"><input class="' . $mvweb_base . 'radio" type="radio" name="' . esc_attr( $mvweb_uid ) . '" value="' . ( $i + 1 ) . '"' . ( 0 === $i ? ' checked' : '' ) . '><span class="mvweb-t-cover mvweb-t-cover--square">' . $mvweb_img( $shot['image'], 'medium', '(min-width: 1024px) 10vw, (min-width: 600px) 12vw, 25vw', $label ) . '</span></label>';
		}

		$html = '<div class="' . $mvweb_base . 'stage"><div class="' . $mvweb_base . 'view">' . $frames . '</div>';

		if ( in_array( 'thumbs', $block['parts'], true ) && count( $shots ) > 1 ) {
			$html .= '<div class="' . $mvweb_base . 'thumbs" role="radiogroup" aria-label="' . esc_attr__( 'Choose a photo', 'journal' ) . '">' . $thumbs . '</div>';
		}

		return $html . '</div>';
	}

	$title = isset( $block['props']['title'] ) ? trim( (string) $block['props']['title'] ) : '';
	$attr  = 'rail' === $mvweb_view ? ' data-scroller="' . esc_attr( '' !== $title ? $title : __( 'Photographs', 'journal' ) ) . '"' : '';
	$html  = '<div class="' . $mvweb_base . 'list"' . $attr . '>';

	foreach ( $mvweb_shots as $i => $shot ) {
		$label = $mvweb_name( $shot, $i + 1 );
		$css   = $mvweb_base . 'item ' . $mvweb_base . 'item--' . $shot['size'];
		$html .= '' === $shot['url']
			? '<div class="' . $css . '">'
			: '<a class="' . $css . '" href="' . esc_url( $shot['url'] ) . '">' . ( '' !== $label ? '<span class="screen-reader-text">' . esc_html( $label ) . '</span>' : '' );
		$html .= '<span class="mvweb-t-cover">' . $mvweb_img( $shot['image'], 'large', $mvweb_sizes[ $mvweb_view ] ) . '</span>';
		$html .= $mvweb_caption && '' !== $shot['caption'] ? '<span class="' . $mvweb_base . 'cap">' . esc_html( $shot['caption'] ) . '</span>' : '';
		$html .= '' === $shot['url'] ? '</div>' : '</a>';
	}

	return $html . '</div>';
};

mvweb_theme_section_open( $mvweb_block, true, 'stage' === $mvweb_view && 'plain' === $mvweb_block['look']['background'] ? 'mvweb-t-section--inverse' : '' );
mvweb_theme_render_parts(
	$mvweb_block,
	array(
		'list' => static function ( $block ) use ( $mvweb_list ) {
			echo $mvweb_list( $block ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
		},
	)
);
mvweb_theme_section_close();
