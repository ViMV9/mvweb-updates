<?php
/**
 * Card of a post, part: the title, the link of the whole card.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<a class="mvweb-t-post__title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
