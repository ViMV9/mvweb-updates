<?php
/**
 * Card of a post, part: the first category.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_terms = get_the_category();

if ( empty( $mvweb_terms ) ) {
	return;
}

$mvweb_link = get_category_link( $mvweb_terms[0] );
?>
<a class="mvweb-t-kicker" href="<?php echo esc_url( is_string( $mvweb_link ) ? $mvweb_link : '' ); ?>"><?php echo esc_html( $mvweb_terms[0]->name ); ?></a>
