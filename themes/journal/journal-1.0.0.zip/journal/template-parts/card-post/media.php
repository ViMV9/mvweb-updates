<?php
/**
 * Card of a post, part: the cover.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! has_post_thumbnail() ) {
	return;
}

$mvweb_attr = array(
	'alt'      => '',
	'decoding' => 'async',
);

if ( ! empty( $args['sizes'] ) ) {
	$mvweb_attr['sizes'] = (string) $args['sizes'];
}

if ( ! empty( $args['eager'] ) ) {
	$mvweb_attr['loading']       = false;
	$mvweb_attr['fetchpriority'] = 'high';
} else {
	$mvweb_attr['loading'] = 'lazy';
}

$mvweb_image = wp_get_attachment_image( (int) get_post_thumbnail_id(), ! empty( $args['size'] ) ? (string) $args['size'] : 'mvweb_card', false, $mvweb_attr );

if ( '' === $mvweb_image ) {
	return;
}

$mvweb_class = trim( 'mvweb-t-cover ' . ( ! empty( $args['cover'] ) ? sanitize_html_class( 'mvweb-t-cover--' . $args['cover'] ) : '' ) );
?>
<a class="mvweb-t-post__media" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true"><span class="<?php echo esc_attr( $mvweb_class ); ?>"><?php echo $mvweb_image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds and escapes the tag. ?></span></a>
