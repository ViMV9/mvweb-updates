<?php
/**
 * Card of a post, part: the author with the picture.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_author = (int) get_the_author_meta( 'ID' );
$mvweb_name   = (string) get_the_author_meta( 'display_name', $mvweb_author );

if ( '' === $mvweb_name ) {
	return;
}

$mvweb_avatar = get_avatar(
	$mvweb_author,
	32,
	'',
	'',
	array(
		'class'         => 'mvweb-t-avatar',
		'force_display' => false,
		'loading'       => 'lazy',
	)
);
?>
<div class="mvweb-t-post__author">
	<?php if ( $mvweb_avatar ) : ?>
		<?php echo $mvweb_avatar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag. ?>
	<?php else : ?>
		<span class="mvweb-t-avatar" aria-hidden="true"><?php echo esc_html( function_exists( 'mb_substr' ) ? mb_substr( $mvweb_name, 0, 1 ) : substr( $mvweb_name, 0, 1 ) ); ?></span>
	<?php endif; ?>
	<a href="<?php echo esc_url( get_author_posts_url( $mvweb_author ) ); ?>"><?php echo esc_html( $mvweb_name ); ?></a>
</div>
