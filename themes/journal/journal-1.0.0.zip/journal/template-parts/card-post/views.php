<?php
/**
 * Card of a post, part: the number of views.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! mvweb_core_views_on() ) {
	return;
}

$mvweb_count = absint( get_post_meta( get_the_ID(), '_mvweb_views', true ) );

$mvweb_short = number_format_i18n( $mvweb_count );

if ( $mvweb_count >= 1000 ) {
	/* translators: %s: number of views in thousands, e.g. 7.9. */
	$mvweb_short = sprintf( _x( '%s K', 'thousands of views', 'journal' ), number_format_i18n( $mvweb_count / 1000, $mvweb_count < 10000 ? 1 : 0 ) );
}

/* translators: %s: number of views. */
$mvweb_label = sprintf( _n( '%s view', '%s views', $mvweb_count, 'journal' ), number_format_i18n( $mvweb_count ) );
?>
<span title="<?php echo esc_attr( $mvweb_label ); ?>">
	<?php echo mvweb_theme_icon( 'eye', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<span aria-hidden="true"><?php echo esc_html( $mvweb_short ); ?></span>
	<span class="screen-reader-text"><?php echo esc_html( $mvweb_label ); ?></span>
</span>
