<?php
/**
 * Card of a blog post.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_args  = isset( $args ) && is_array( $args ) ? $args : array();
$mvweb_hide  = isset( $mvweb_args['hide'] ) && is_array( $mvweb_args['hide'] ) ? $mvweb_args['hide'] : array();
$mvweb_class = 'mvweb-t-post';
$mvweb_out   = array(
	'media' => '',
	'body'  => '',
	'meta'  => '',
);
$mvweb_done  = array();
$mvweb_meta  = array( 'date', 'read', 'comments', 'views' );

foreach ( preg_split( '/\s+/', isset( $mvweb_args['modifier'] ) ? (string) $mvweb_args['modifier'] : '', -1, PREG_SPLIT_NO_EMPTY ) as $mvweb_mod ) {
	$mvweb_class .= ' mvweb-t-post--' . sanitize_html_class( $mvweb_mod );
}

$mvweb_print = static function ( $slug, $part_args ) {
	ob_start();
	get_template_part( 'template-parts/card-post/' . sanitize_key( $slug ), null, $part_args );

	return trim( (string) ob_get_clean() );
};

$mvweb_walk = static function ( $handled, $area, $slug, $part_args ) use ( $mvweb_hide, $mvweb_print, $mvweb_meta, &$mvweb_out, &$mvweb_done ) {
	if ( true === $handled || 'card-post' !== $area ) {
		return $handled;
	}

	$mvweb_done[] = $slug;
	$html         = in_array( $slug, $mvweb_hide, true ) ? '' : $mvweb_print( $slug, $part_args );

	if ( '' === $html ) {
		return true;
	}

	if ( 'media' === $slug ) {
		$mvweb_out['media'] .= $html;
	} elseif ( in_array( $slug, $mvweb_meta, true ) ) {
		$mvweb_out['meta'] .= $html;
	} else {
		$mvweb_out['body'] .= $html;
	}

	return true;
};

add_filter( 'mvweb_core_render_part', $mvweb_walk, 10, 4 );
mvweb_core_render_layout( 'card-post', $mvweb_args );
remove_filter( 'mvweb_core_render_part', $mvweb_walk, 10 );

if ( ! in_array( 'title', $mvweb_done, true ) || in_array( 'title', $mvweb_hide, true ) ) {
	$mvweb_out['body'] = $mvweb_print( 'title', $mvweb_args ) . $mvweb_out['body'];
}
?>
<article class="<?php echo esc_attr( $mvweb_class ); ?>" data-id="<?php the_ID(); ?>">
	<?php if ( ! empty( $mvweb_args['num'] ) ) : ?>
		<span class="mvweb-t-post__num"><?php echo esc_html( number_format_i18n( absint( $mvweb_args['num'] ) ) ); ?></span>
	<?php endif; ?>
	<?php echo $mvweb_out['media']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?>
	<div class="mvweb-t-post__body">
		<?php echo $mvweb_out['body']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?>
		<?php if ( '' !== $mvweb_out['meta'] ) : ?>
			<div class="mvweb-t-meta"><?php echo $mvweb_out['meta']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?></div>
		<?php endif; ?>
	</div>
</article>
