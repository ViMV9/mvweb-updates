<?php
/**
 * Topics of the day: the menu of its place under the header, in the look chosen in the Customizer.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! mvweb_core_topics_on() ) {
	return;
}

$mvweb_tree = mvweb_core_menu_tree( 'topics' );
$mvweb_list = isset( $mvweb_tree[0] ) ? array_values( $mvweb_tree[0] ) : array();

if ( empty( $mvweb_list ) ) {
	return;
}

$mvweb_view  = mvweb_core_area_view( 'topics' );
$mvweb_count = count( $mvweb_list );
$mvweb_label = __( 'Topics of the day', 'journal' );
$mvweb_link  = static function ( $item, $classes, $inner = '' ) {
	printf(
		'<a class="%1$s" %2$s%3$s>%4$s<span>%5$s</span></a>',
		esc_attr( $classes ),
		mvweb_core_menu_href( $item->url ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped attributes.
		mvweb_core_menu_current( $item ) ? ' aria-current="page"' : '',
		$inner, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by the caller.
		esc_html( $item->title )
	);
};
?>
<nav class="mvweb-t-topics" aria-labelledby="mvweb-t-topics-label"<?php echo is_customize_preview() ? ' data-mvweb-cz-section="mvweb_cz_header_topics"' : ''; ?>>
	<div class="mvweb-t-container">
		<span class="mvweb-t-topics__label" id="mvweb-t-topics-label"><?php echo mvweb_theme_icon( 'flame', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?><?php echo esc_html( $mvweb_label ); ?></span>
		<div class="mvweb-t-topics__list">
			<?php if ( '2' === $mvweb_view ) : ?>
				<div class="mvweb-t-trot" data-trot>
					<?php foreach ( $mvweb_list as $mvweb_index => $mvweb_item ) : ?>
						<a class="mvweb-t-trot__a" <?php echo mvweb_core_menu_href( $mvweb_item->url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped attributes. ?><?php echo $mvweb_index ? ' hidden' : ''; ?>><?php echo esc_html( $mvweb_item->title ); ?></a>
					<?php endforeach; ?>
					<?php if ( $mvweb_count > 1 ) : ?>
						<span class="mvweb-t-trot__count" aria-live="polite"><span data-trot-count>1</span> / <?php echo esc_html( number_format_i18n( $mvweb_count ) ); ?></span>
						<button class="mvweb-t-trot__btn" type="button" data-trot-go="-1" title="<?php esc_attr_e( 'Previous topic', 'journal' ); ?>">
							<?php echo mvweb_theme_icon( 'chevron-left', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
							<span class="screen-reader-text"><?php esc_html_e( 'Previous topic', 'journal' ); ?></span>
						</button>
						<button class="mvweb-t-trot__btn" type="button" data-trot-go="1" title="<?php esc_attr_e( 'Next topic', 'journal' ); ?>">
							<?php echo mvweb_theme_icon( 'chevron-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
							<span class="screen-reader-text"><?php esc_html_e( 'Next topic', 'journal' ); ?></span>
						</button>
					<?php endif; ?>
				</div>
			<?php elseif ( '3' === $mvweb_view ) : ?>
				<div class="mvweb-t-tdrop">
					<?php $mvweb_link( $mvweb_list[0], 'mvweb-t-tdrop__first' ); ?>
					<?php if ( $mvweb_count > 1 ) : ?>
						<button class="mvweb-t-tdrop__btn" type="button" popovertarget="mvweb-t-tpop" data-popover-trigger="mvweb-t-tpop">
							<?php
							/* translators: %d: number of the topics. */
							echo esc_html( sprintf( __( 'All topics · %d', 'journal' ), $mvweb_count ) );
							?>
							<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
						</button>
						<div class="mvweb-t-tpop" id="mvweb-t-tpop" popover data-popover role="dialog" aria-labelledby="mvweb-t-tpop-title">
							<div class="mvweb-t-tpop__head">
								<span id="mvweb-t-tpop-title"><?php echo esc_html( $mvweb_label ); ?></span>
								<button class="mvweb-t-icon-btn" type="button" popovertarget="mvweb-t-tpop" popovertargetaction="hide" data-popover-close title="<?php esc_attr_e( 'Close', 'journal' ); ?>">
									<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
									<span class="screen-reader-text"><?php esc_html_e( 'Close', 'journal' ); ?></span>
								</button>
							</div>
							<ol class="mvweb-t-tpop__list">
								<?php foreach ( $mvweb_list as $mvweb_index => $mvweb_item ) : ?>
									<li><?php $mvweb_link( $mvweb_item, 'mvweb-t-tpop__a', '<b>' . esc_html( number_format_i18n( $mvweb_index + 1 ) ) . '</b>' ); ?></li>
								<?php endforeach; ?>
							</ol>
							<a class="mvweb-t-section__more mvweb-t-tpop__all" href="<?php echo esc_url( mvweb_core_topics_all_url() ); ?>">
								<?php esc_html_e( 'Articles of today', 'journal' ); ?>
								<?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
							</a>
						</div>
					<?php endif; ?>
				</div>
			<?php elseif ( '4' === $mvweb_view ) : ?>
				<div class="mvweb-t-tnum">
					<ol class="mvweb-t-tnum__list">
						<?php foreach ( $mvweb_list as $mvweb_index => $mvweb_item ) : ?>
							<li><?php $mvweb_link( $mvweb_item, 'mvweb-t-tnum__a', '<b>' . esc_html( number_format_i18n( $mvweb_index + 1 ) ) . '</b>' ); ?></li>
						<?php endforeach; ?>
					</ol>
					<a class="mvweb-t-tnum__all" href="<?php echo esc_url( mvweb_core_topics_all_url() ); ?>">
						<?php esc_html_e( 'All', 'journal' ); ?>
						<?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
						<span class="screen-reader-text"><?php esc_html_e( 'articles of today', 'journal' ); ?></span>
					</a>
				</div>
			<?php elseif ( '5' === $mvweb_view ) : ?>
				<div class="mvweb-t-tcards">
					<?php foreach ( $mvweb_list as $mvweb_index => $mvweb_item ) : ?>
						<?php $mvweb_link( $mvweb_item, 'mvweb-t-tcards__a', '<b>' . esc_html( sprintf( '%02d', $mvweb_index + 1 ) ) . '</b>' ); ?>
					<?php endforeach; ?>
				</div>
			<?php else : ?>
				<div class="mvweb-t-tlinks">
					<?php foreach ( $mvweb_list as $mvweb_item ) : ?>
						<?php $mvweb_link( $mvweb_item, 'mvweb-t-tlinks__a' ); ?>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</nav>
