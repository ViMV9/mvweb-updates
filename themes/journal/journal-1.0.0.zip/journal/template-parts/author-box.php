<?php
/**
 * The block about the author of a blog entry.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! get_theme_mod( 'mvweb_author_box', false ) ) {
	return;
}

$mvweb_author = (int) get_post_field( 'post_author', get_the_ID() );
$mvweb_name   = trim( (string) get_the_author_meta( 'display_name', $mvweb_author ) );

if ( 0 === $mvweb_author || '' === $mvweb_name ) {
	return;
}

$mvweb_parts  = mvweb_core_blog_layout_html( 'author-box', array( 'author' => $mvweb_author ) );
$mvweb_avatar = isset( $mvweb_parts['avatar'] ) ? $mvweb_parts['avatar'] : '';
$mvweb_role   = mvweb_core_author_role( $mvweb_author );

unset( $mvweb_parts['avatar'] );
?>
<aside class="mvweb-t-author-box<?php echo '' === $mvweb_avatar ? ' mvweb-t-author-box--plain' : ''; ?>" aria-label="<?php esc_attr_e( 'About the author', 'journal' ); ?>">
	<?php echo $mvweb_avatar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template. ?>
	<div class="mvweb-t-author-box__head">
		<div class="mvweb-t-author-box__name"><?php echo esc_html( $mvweb_name ); ?></div>
		<?php if ( '' !== $mvweb_role ) : ?>
			<div class="mvweb-t-author-box__role"><?php echo esc_html( $mvweb_role ); ?></div>
		<?php endif; ?>
	</div>
	<?php if ( ! empty( $mvweb_parts ) ) : ?>
		<div class="mvweb-t-author-box__rest"><?php echo implode( '', $mvweb_parts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?></div>
	<?php endif; ?>
</aside>
