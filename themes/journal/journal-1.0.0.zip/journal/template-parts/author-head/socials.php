<?php
/**
 * Author heading part: the links of the author from the profile.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_links = mvweb_core_author_links( isset( $args['author'] ) ? absint( $args['author'] ) : 0 );

if ( empty( $mvweb_links ) ) {
	return;
}
?>
<div class="mvweb-t-follow mvweb-t-follow--icons mvweb-t-ahero__links">
	<?php foreach ( $mvweb_links as $mvweb_link ) : ?>
		<a href="<?php echo esc_url( $mvweb_link['url'] ); ?>" data-brand="<?php echo esc_attr( $mvweb_link['icon'] ); ?>" rel="noopener me" target="_blank" title="<?php echo esc_attr( $mvweb_link['label'] ); ?>">
			<?php echo mvweb_theme_icon( 'world' === $mvweb_link['icon'] ? 'link' : $mvweb_link['icon'], array( 'class' => 'mvweb-t-icon--brand' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span class="screen-reader-text"><?php echo esc_html( $mvweb_link['label'] ); ?></span>
		</a>
	<?php endforeach; ?>
</div>
