<?php
/**
 * Author heading part: how many articles the author has published.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_count = (int) count_user_posts( isset( $args['author'] ) ? absint( $args['author'] ) : 0, 'post', true );

if ( $mvweb_count < 1 ) {
	return;
}
?>
<span class="mvweb-t-ahero__stat"><b><?php echo esc_html( number_format_i18n( $mvweb_count ) ); ?></b><span><?php echo esc_html( _n( 'article', 'articles', $mvweb_count, 'journal' ) ); ?></span></span>
