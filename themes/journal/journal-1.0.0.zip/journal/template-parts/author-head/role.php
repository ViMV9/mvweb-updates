<?php
/**
 * Author heading part: the position of the author from the profile.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_role = mvweb_core_author_role( isset( $args['author'] ) ? absint( $args['author'] ) : 0 );

if ( '' === $mvweb_role ) {
	return;
}
?>
<p class="mvweb-t-ahero__role"><?php echo esc_html( $mvweb_role ); ?></p>
