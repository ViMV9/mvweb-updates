<?php
/**
 * Author heading part: the picture of the author, or the first letters of the name without one.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_author = isset( $args['author'] ) ? absint( $args['author'] ) : 0;
$mvweb_size   = isset( $args['view'] ) && '2' === (string) $args['view'] ? 'lg' : 'xl';
$mvweb_avatar = get_avatar(
	$mvweb_author,
	'lg' === $mvweb_size ? 128 : 192,
	'',
	'',
	array(
		'class'   => 'mvweb-t-avatar mvweb-t-avatar--' . $mvweb_size,
		'loading' => 'eager',
	)
);

if ( $mvweb_avatar ) {
	echo $mvweb_avatar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
	return;
}

$mvweb_name  = trim( (string) get_the_author_meta( 'display_name', $mvweb_author ) );
$mvweb_words = preg_split( '/\s+/u', $mvweb_name, 2, PREG_SPLIT_NO_EMPTY );
$mvweb_mark  = '';

foreach ( is_array( $mvweb_words ) ? $mvweb_words : array() as $mvweb_word ) {
	$mvweb_mark .= mb_substr( $mvweb_word, 0, 1 );
}

if ( '' === $mvweb_mark ) {
	return;
}
?>
<span class="mvweb-t-avatar mvweb-t-avatar--<?php echo esc_attr( $mvweb_size ); ?>" aria-hidden="true"><?php echo esc_html( mb_strtoupper( $mvweb_mark ) ); ?></span>
