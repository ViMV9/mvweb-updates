<?php
/**
 * Author heading part: the year the author joined the site.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_user = get_userdata( isset( $args['author'] ) ? absint( $args['author'] ) : 0 );
$mvweb_year = $mvweb_user instanceof WP_User ? (int) mysql2date( 'Y', $mvweb_user->user_registered ) : 0;

if ( $mvweb_year < 1 ) {
	return;
}
?>
<span class="mvweb-t-ahero__stat"><b><?php echo esc_html( (string) $mvweb_year ); ?></b><span><?php esc_html_e( 'on the site since', 'journal' ); ?></span></span>
