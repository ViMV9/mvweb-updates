<?php
/**
 * The card «Read also» in the text of a post, in place of the frame WordPress embeds for a link to an own post.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['post'] ) ? (int) $args['post'] : 0;

if ( $mvweb_id < 1 ) {
	return;
}

$mvweb_cats    = get_the_category( $mvweb_id );
$mvweb_minutes = mvweb_core_reading_minutes( $mvweb_id );
$mvweb_name    = wp_unique_id( 'mvweb-t-readalso-' );
$mvweb_image   = has_post_thumbnail( $mvweb_id ) ? get_the_post_thumbnail(
	$mvweb_id,
	'mvweb_card',
	array(
		'alt'     => '',
		'loading' => 'lazy',
		'sizes'   => '120px',
	)
) : '';
?>
<aside class="mvweb-t-readalso" aria-labelledby="<?php echo esc_attr( $mvweb_name ); ?>">
	<span class="mvweb-t-readalso__cap"><?php esc_html_e( 'Read also', 'journal' ); ?></span>
	<a class="mvweb-t-readalso__card<?php echo '' === $mvweb_image ? ' mvweb-t-readalso__card--text' : ''; ?>" href="<?php echo esc_url( get_permalink( $mvweb_id ) ); ?>">
		<?php if ( '' !== $mvweb_image ) : ?>
			<span class="mvweb-t-cover mvweb-t-cover--square"><?php echo $mvweb_image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds the image tag. ?></span>
		<?php endif; ?>
		<span class="mvweb-t-readalso__body">
			<span class="mvweb-t-readalso__title" id="<?php echo esc_attr( $mvweb_name ); ?>"><?php echo esc_html( get_the_title( $mvweb_id ) ); ?></span>
			<?php if ( $mvweb_minutes > 0 || ! empty( $mvweb_cats ) ) : ?>
				<span class="mvweb-t-meta">
					<?php if ( $mvweb_minutes > 0 ) : ?>
						<span>
							<?php
							echo mvweb_theme_icon( 'clock', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
							/* translators: %s: number of minutes. */
							echo esc_html( sprintf( _x( '%s min', 'reading time', 'journal' ), number_format_i18n( $mvweb_minutes ) ) );
							?>
						</span>
					<?php endif; ?>
					<?php if ( ! empty( $mvweb_cats ) ) : ?>
						<span><?php echo esc_html( $mvweb_cats[0]->name ); ?></span>
					<?php endif; ?>
				</span>
			<?php endif; ?>
		</span>
	</a>
</aside>
