<?php
/**
 * Contacts page: the phones, the number over its caption.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_phones = isset( $args['phones'] ) ? (array) $args['phones'] : array();

if ( ! $mvweb_phones ) {
	return;
}
?>
<div class="mvweb-t-el-phones">
	<?php foreach ( $mvweb_phones as $mvweb_phone ) : ?>
		<?php $mvweb_tag = '' !== (string) $mvweb_phone['href'] ? 'a' : 'span'; ?>
		<<?php echo esc_attr( $mvweb_tag ); ?> class="mvweb-t-el-phone"<?php echo 'a' === $mvweb_tag ? ' href="' . esc_url( $mvweb_phone['href'], array( 'tel' ) ) . '"' : ''; ?>>
			<span class="mvweb-t-el-phone__num"><?php echo esc_html( $mvweb_phone['number'] ); ?></span>
			<?php if ( '' !== trim( (string) $mvweb_phone['label'] ) ) : ?>
				<span class="mvweb-t-el-phone__cap"><?php echo esc_html( $mvweb_phone['label'] ); ?></span>
			<?php endif; ?>
		</<?php echo esc_attr( $mvweb_tag ); ?>>
	<?php endforeach; ?>
</div>
