<?php
/**
 * Contacts page: the opening hours, a line for every group of days.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_lines = array();

foreach ( isset( $args['hours'] ) ? (array) $args['hours'] : array() as $mvweb_row ) {
	$mvweb_lines[] = trim( $mvweb_row['days'] . ' ' . $mvweb_row['time'] );
}

$mvweb_lines = array_filter( $mvweb_lines );

if ( ! $mvweb_lines ) {
	return;
}
?>
<span class="mvweb-t-el-hours__rows">
	<?php foreach ( $mvweb_lines as $mvweb_line ) : ?>
		<span><?php echo esc_html( $mvweb_line ); ?></span>
	<?php endforeach; ?>
</span>
