<?php
/**
 * Contacts page: the branches by the tabs of the cities, the map of the city aside.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_places = isset( $args['places'] ) ? (array) $args['places'] : array();
$mvweb_map    = isset( $args['map'] ) && is_array( $args['map'] ) ? $args['map'] : mvweb_core_profile_map();
$mvweb_cities = mvweb_core_cities();
$mvweb_now    = mvweb_core_current_city();
$mvweb_groups = array();

foreach ( $mvweb_places as $mvweb_place ) {
	$mvweb_key                    = isset( $mvweb_place['key'] ) && isset( $mvweb_cities[ $mvweb_place['key'] ] ) ? $mvweb_place['key'] : '';
	$mvweb_groups[ $mvweb_key ][] = $mvweb_place;
}

if ( ! $mvweb_groups ) {
	return;
}

$mvweb_tabs = count( $mvweb_groups ) > 1;

$mvweb_panel = static function ( array $places, $key ) use ( $mvweb_map, $mvweb_tabs ) {
	$map = $mvweb_map;

	foreach ( $places as $place ) {
		if ( ! empty( $place['map'] ) ) {
			$map = array(
				'image'    => '',
				'image_id' => 0,
				'src'      => (string) $place['map'],
			);
			break;
		}
	}

	$has_map = '' !== $map['image'] || '' !== $map['src'];
	?>
	<div class="mvweb-t-contacts__city<?php echo $has_map ? '' : ' mvweb-t-contacts__city--solo'; ?>"<?php echo $mvweb_tabs ? ' data-tabpanel="' . esc_attr( $key ) . '"' : ''; ?>>
		<?php
		get_template_part(
			'template-parts/contacts/branches',
			null,
			array(
				'places' => $places,
				'look'   => 'list',
			)
		);

		if ( $has_map ) {
			get_template_part(
				'template-parts/map-frame',
				null,
				array(
					'map'   => $map,
					'name'  => (string) $places[0]['city'],
					'class' => 'mvweb-t-map-frame--side',
					'sizes' => '(min-width: 1024px) 40vw, 100vw',
				)
			);
		}
		?>
	</div>
	<?php
};
?>
<div class="mvweb-t-contacts__cities"<?php echo $mvweb_tabs ? ' data-tabs' : ''; ?>>
	<?php if ( $mvweb_tabs ) : ?>
		<div class="mvweb-t-tabs" role="tablist" aria-label="<?php esc_attr_e( 'Cities', 'journal' ); ?>">
			<?php foreach ( $mvweb_groups as $mvweb_key => $mvweb_list ) : ?>
				<button type="button" data-tab="<?php echo esc_attr( $mvweb_key ); ?>" aria-selected="<?php echo $mvweb_key === $mvweb_now ? 'true' : 'false'; ?>">
					<?php echo esc_html( $mvweb_list[0]['city'] ); ?>
					<span class="mvweb-t-tabs__n"><?php echo esc_html( number_format_i18n( count( $mvweb_list ) ) ); ?></span>
				</button>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<?php
	foreach ( $mvweb_groups as $mvweb_key => $mvweb_list ) {
		$mvweb_panel( $mvweb_list, $mvweb_key );
	}
	?>
</div>
