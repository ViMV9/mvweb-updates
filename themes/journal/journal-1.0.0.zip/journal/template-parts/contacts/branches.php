<?php
/**
 * Contacts page: the branches as cards, or the place of the profile when there are no branches.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_places = isset( $args['places'] ) ? (array) $args['places'] : array();
$mvweb_look   = isset( $args['look'] ) ? sanitize_html_class( (string) $args['look'] ) : 'cards';

if ( ! $mvweb_places ) {
	return;
}
?>
<div class="mvweb-t-branches mvweb-t-branches--<?php echo esc_attr( $mvweb_look ); ?>">
	<?php
	foreach ( $mvweb_places as $mvweb_place ) {
		get_template_part(
			'template-parts/contacts/branch',
			null,
			array(
				'branch' => $mvweb_place,
				'full'   => 'full' === $mvweb_look,
			)
		);
	}
	?>
</div>
