<?php
/**
 * Contacts page: the list of the contacts, a caption over every value.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_contacts = isset( $args['contacts'] ) && is_array( $args['contacts'] ) ? $args['contacts'] : mvweb_core_contacts();
$mvweb_email    = is_email( (string) $mvweb_contacts['email'] ) ? (string) $mvweb_contacts['email'] : '';
$mvweb_socials  = mvweb_cz_profile_socials();
$mvweb_chats    = mvweb_cz_profile_chats();
$mvweb_legal    = array_filter( array( trim( (string) mvweb_cz_profile( 'legal_name' ) ) ) );

foreach ( mvweb_cz_profile_requisites() as $mvweb_row ) {
	$mvweb_legal[] = trim( $mvweb_row['label'] . ' ' . $mvweb_row['value'] );
}

$mvweb_places = array_filter(
	(array) $mvweb_contacts['addresses'],
	static function ( $place ) {
		return '' !== trim( (string) $place['address'] );
	}
);

if ( '' === $mvweb_email && ! $mvweb_contacts['phones'] && ! $mvweb_places && ! $mvweb_contacts['hours'] && ! $mvweb_socials && ! $mvweb_chats && ! $mvweb_legal ) {
	return;
}
?>
<div class="mvweb-t-clist">
	<?php if ( '' !== $mvweb_email ) : ?>
		<div class="mvweb-t-clist__item">
			<span class="mvweb-t-clist__cap"><?php esc_html_e( 'Editorial e-mail', 'journal' ); ?></span>
			<a class="mvweb-t-clist__val" href="<?php echo esc_url( 'mailto:' . $mvweb_email ); ?>"><?php echo esc_html( $mvweb_email ); ?></a>
		</div>
	<?php endif; ?>

	<?php if ( $mvweb_contacts['phones'] ) : ?>
		<div class="mvweb-t-clist__item">
			<span class="mvweb-t-clist__cap"><?php echo esc_html( _n( 'Phone', 'Phones', count( $mvweb_contacts['phones'] ), 'journal' ) ); ?></span>
			<?php get_template_part( 'template-parts/contacts/phones', null, array( 'phones' => $mvweb_contacts['phones'] ) ); ?>
		</div>
	<?php endif; ?>

	<?php if ( $mvweb_places ) : ?>
		<div class="mvweb-t-clist__item">
			<span class="mvweb-t-clist__cap"><?php echo esc_html( _n( 'Address', 'Addresses', count( $mvweb_places ), 'journal' ) ); ?></span>
			<?php foreach ( $mvweb_places as $mvweb_place ) : ?>
				<address class="mvweb-t-clist__val">
					<?php echo esc_html( mvweb_core_address_text( $mvweb_place ) ); ?>
					<?php if ( '' !== trim( (string) $mvweb_place['note'] ) ) : ?>
						<small><?php echo esc_html( $mvweb_place['note'] ); ?></small>
					<?php endif; ?>
				</address>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<?php if ( $mvweb_contacts['hours'] ) : ?>
		<div class="mvweb-t-clist__item">
			<span class="mvweb-t-clist__cap"><?php esc_html_e( 'Opening hours', 'journal' ); ?></span>
			<?php get_template_part( 'template-parts/contacts/hours', null, array( 'hours' => $mvweb_contacts['hours'] ) ); ?>
		</div>
	<?php endif; ?>

	<?php if ( $mvweb_socials ) : ?>
		<div class="mvweb-t-clist__item">
			<span class="mvweb-t-clist__cap"><?php esc_html_e( 'Social networks', 'journal' ); ?></span>
			<?php
			mvweb_theme_follow( $mvweb_socials, 'brand' );
			mvweb_theme_meta_note( $mvweb_socials );
			?>
		</div>
	<?php endif; ?>

	<?php if ( $mvweb_chats ) : ?>
		<div class="mvweb-t-clist__item">
			<span class="mvweb-t-clist__cap"><?php esc_html_e( 'Messengers', 'journal' ); ?></span>
			<div class="mvweb-t-msgs mvweb-t-msgs--list">
				<?php foreach ( $mvweb_chats as $mvweb_id => $mvweb_link ) : ?>
					<a href="<?php echo esc_url( $mvweb_link['url'] ); ?>" data-brand="<?php echo esc_attr( mvweb_core_social_icon( $mvweb_id ) ); ?>" rel="noopener" target="_blank">
						<?php echo mvweb_theme_icon( mvweb_core_social_icon( $mvweb_id ), array( 'class' => 'mvweb-t-icon--brand' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
						<span class="mvweb-t-msgs__name"><?php echo esc_html( $mvweb_link['label'] ); ?></span>
						<?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm mvweb-t-msgs__go' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					</a>
				<?php endforeach; ?>
			</div>
		</div>
	<?php endif; ?>

	<?php if ( $mvweb_legal ) : ?>
		<div class="mvweb-t-requisites">
			<b><?php esc_html_e( 'Company details', 'journal' ); ?></b>
			<?php foreach ( $mvweb_legal as $mvweb_line ) : ?>
				<span><?php echo esc_html( $mvweb_line ); ?></span>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</div>
