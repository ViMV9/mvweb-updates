<?php
/**
 * Contacts page: one branch as a card, its name and city, the address with the way in, the phones, the hours, the e-mail and the links to the route and the map.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_branch = isset( $args['branch'] ) && is_array( $args['branch'] ) ? $args['branch'] : array();

if ( ! $mvweb_branch ) {
	return;
}

$mvweb_name  = trim( (string) $mvweb_branch['title'] );
$mvweb_city  = trim( (string) $mvweb_branch['city'] );
$mvweb_where = trim( (string) $mvweb_branch['address'] );
$mvweb_mail  = is_email( (string) $mvweb_branch['email'] ) ? (string) $mvweb_branch['email'] : '';
$mvweb_links = array_filter(
	array(
		'route' => array( (string) $mvweb_branch['route_url'], __( 'Route', 'journal' ), 'mvweb-t-btn--outline' ),
		'map'   => array( (string) $mvweb_branch['map_link'], __( 'On the map', 'journal' ), 'mvweb-t-btn--ghost' ),
	),
	static function ( $link ) {
		return '' !== $link[0];
	}
);
?>
<article class="mvweb-t-branch<?php echo empty( $args['full'] ) ? '' : ' mvweb-t-branch--full'; ?>">
	<?php if ( '' !== $mvweb_name || '' !== $mvweb_city ) : ?>
		<div class="mvweb-t-branch__head">
			<?php if ( '' !== $mvweb_name ) : ?>
				<div class="mvweb-t-branch__name mvweb-t-h4"><?php echo esc_html( $mvweb_name ); ?></div>
			<?php endif; ?>
			<?php if ( '' !== $mvweb_city ) : ?>
				<span class="mvweb-t-badge"><?php echo esc_html( $mvweb_city ); ?></span>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php if ( '' !== $mvweb_where ) : ?>
		<div class="mvweb-t-branch__line">
			<?php echo mvweb_theme_icon( 'map-pin', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<address class="mvweb-t-branch__addr">
				<?php echo esc_html( $mvweb_where ); ?>
				<?php if ( '' !== trim( (string) $mvweb_branch['note'] ) ) : ?>
					<small><?php echo esc_html( $mvweb_branch['note'] ); ?></small>
				<?php endif; ?>
			</address>
		</div>
	<?php endif; ?>

	<?php get_template_part( 'template-parts/contacts/phones', null, array( 'phones' => $mvweb_branch['phones'] ) ); ?>

	<?php if ( $mvweb_branch['hours'] ) : ?>
		<div class="mvweb-t-branch__line">
			<?php
			echo mvweb_theme_icon( 'clock', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
			get_template_part( 'template-parts/contacts/hours', null, array( 'hours' => $mvweb_branch['hours'] ) );
			?>
		</div>
	<?php endif; ?>

	<?php if ( '' !== $mvweb_mail ) : ?>
		<a class="mvweb-t-branch__line mvweb-t-branch__mail" href="<?php echo esc_url( 'mailto:' . $mvweb_mail ); ?>">
			<?php echo mvweb_theme_icon( 'mail', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span><?php echo esc_html( $mvweb_mail ); ?></span>
		</a>
	<?php endif; ?>

	<?php if ( $mvweb_links ) : ?>
		<div class="mvweb-t-branch__btns">
			<?php foreach ( $mvweb_links as $mvweb_link ) : ?>
				<a class="mvweb-t-btn mvweb-t-btn--sm <?php echo esc_attr( $mvweb_link[2] ); ?>" href="<?php echo esc_url( $mvweb_link[0] ); ?>" rel="noopener" target="_blank"><?php echo esc_html( $mvweb_link[1] ); ?></a>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</article>
