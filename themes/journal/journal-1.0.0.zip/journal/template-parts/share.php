<?php
/**
 * Share buttons of an entry.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! mvweb_core_share_here() ) {
	return;
}

$mvweb_id    = isset( $args['id'] ) ? absint( $args['id'] ) : get_the_ID();
$mvweb_links = mvweb_core_share_links( $mvweb_id );

if ( empty( $mvweb_links ) ) {
	return;
}
?>
<div class="mvweb-t-share">
	<span class="mvweb-t-share__label"><?php esc_html_e( 'Share', 'journal' ); ?></span>
	<ul class="mvweb-t-share__list">
		<?php foreach ( $mvweb_links as $mvweb_link ) : ?>
			<li>
				<a class="mvweb-t-share__link" href="<?php echo esc_url( $mvweb_link['url'] ); ?>" target="_blank" rel="noopener nofollow" title="<?php echo esc_attr( $mvweb_link['label'] ); ?>">
					<?php echo mvweb_theme_icon( $mvweb_link['icon'], array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<span class="screen-reader-text"><?php echo esc_html( $mvweb_link['label'] ); ?></span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</div>
