<?php
/**
 * The front of the site.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rows = mvweb_core_request_sections();

if ( empty( $mvweb_rows ) ) {
	if ( 'page' === get_option( 'show_on_front' ) ) {
		get_template_part( 'page' );
	} else {
		get_template_part( 'home' );
	}

	return;
}

mvweb_core_h1_reserve( $mvweb_rows );

get_header();

if ( is_page() ) {
	while ( have_posts() ) {
		the_post();
	}
}

mvweb_core_render_sections( $mvweb_rows );

get_footer();
