<?php
/**
 * All the articles: the page of the posts in the look of the list of posts.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_posts_page = (int) get_option( 'page_for_posts' );
$mvweb_title      = mvweb_core_alt_h1();
$mvweb_view       = mvweb_core_blog_view();
$mvweb_area       = mvweb_core_sidebar_area();
$mvweb_looks      = array(
	'feed' => array( 'rule' ),
	'wall' => array( 'center' ),
);
$mvweb_meta       = array();
$mvweb_after      = '';

if ( '' === $mvweb_title ) {
	$mvweb_title = $mvweb_posts_page > 0
		? get_the_title( $mvweb_posts_page )
		: __( 'Blog', 'journal' );
}

if ( in_array( $mvweb_view, array( 'feed', 'text' ), true ) ) {
	$mvweb_meta[] = mvweb_core_articles( (int) wp_count_posts( 'post' )->publish );
}

if ( in_array( $mvweb_view, array( 'journal', 'wall' ), true ) ) {
	ob_start();
	get_template_part( 'template-parts/blog/chips', null, array( 'kind' => 'topics' ) );
	$mvweb_after = (string) ob_get_clean();
}

get_header();

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'title' => $mvweb_title,
		'lead'  => is_paged() ? '' : mvweb_core_blog_lead(),
		'meta'  => $mvweb_meta,
		'after' => $mvweb_after,
		'looks' => isset( $mvweb_looks[ $mvweb_view ] ) ? $mvweb_looks[ $mvweb_view ] : array(),
	)
);

mvweb_theme_layout_open( $mvweb_area );

get_template_part(
	'template-parts/post-list',
	null,
	array(
		'view'              => $mvweb_view,
		'empty_icon'        => 'checklist',
		'empty_title'       => __( 'Nothing here yet', 'journal' ),
		'empty_text'        => __( 'The first entry will appear as soon as it is published.', 'journal' ),
		'empty_button_url'  => home_url( '/' ),
		'empty_button_text' => __( 'To the homepage', 'journal' ),
	)
);

mvweb_theme_layout_close( $mvweb_area );

mvweb_core_render_context_sections();

get_footer();
