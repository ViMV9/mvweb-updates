<?php
/**
 * Footer.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

ob_start();
mvweb_core_render_zone( 'footer-main' );
$mvweb_columns = trim( (string) ob_get_clean() );

ob_start();
mvweb_core_render_zone( 'footer-bottom' );
$mvweb_bottom = trim( (string) ob_get_clean() );
?>
</main>

<footer data-footer class="mvweb-t-footer"<?php echo is_customize_preview() ? ' data-mvweb-cz-section="mvweb_cz_footer_blocks"' : ''; ?>>
	<?php get_template_part( 'template-parts/footer-map' ); ?>

	<?php if ( '' !== $mvweb_columns ) : ?>
		<div class="mvweb-t-container mvweb-t-footer__main">
			<?php echo $mvweb_columns; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped element templates. ?>
		</div>
	<?php endif; ?>

	<?php if ( '' !== $mvweb_bottom ) : ?>
		<div class="mvweb-t-footer__bottom">
			<div class="mvweb-t-container mvweb-t-footer__bottom-row">
				<?php echo $mvweb_bottom; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped element templates. ?>
			</div>
		</div>
	<?php endif; ?>
</footer>

<button class="mvweb-t-totop" data-totop type="button" title="<?php esc_attr_e( 'Back to top', 'journal' ); ?>">
	<?php echo mvweb_theme_icon( 'arrow-up' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<span class="screen-reader-text"><?php esc_html_e( 'Back to top', 'journal' ); ?></span>
</button>

<?php get_template_part( 'template-parts/subscribe-popover' ); ?>

<?php wp_footer(); ?>
</body>
</html>
