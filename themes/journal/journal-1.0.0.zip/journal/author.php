<?php
/**
 * Archive of an author in five looks.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_author = get_queried_object_id();
$mvweb_view   = mvweb_core_area_view( 'author' );
$mvweb_title  = mvweb_core_alt_h1();
$mvweb_title  = '' !== $mvweb_title ? $mvweb_title : (string) get_the_author_meta( 'display_name', $mvweb_author );
$mvweb_parts  = mvweb_core_blog_layout_html(
	'author-head',
	array(
		'author' => $mvweb_author,
		'view'   => $mvweb_view,
	)
);
$mvweb_avatar = '5' === $mvweb_view || ! isset( $mvweb_parts['avatar'] ) ? '' : $mvweb_parts['avatar'];
$mvweb_role   = isset( $mvweb_parts['role'] ) ? $mvweb_parts['role'] : '';
$mvweb_text   = '';
$mvweb_facts  = '';

unset( $mvweb_parts['avatar'], $mvweb_parts['role'] );

foreach ( $mvweb_parts as $mvweb_slug => $mvweb_html ) {
	if ( in_array( $mvweb_slug, array( 'count', 'since' ), true ) ) {
		$mvweb_facts .= $mvweb_html;
		continue;
	}

	if ( '' !== $mvweb_facts ) {
		$mvweb_text .= '<div class="mvweb-t-ahero__stats">' . $mvweb_facts . '</div>';
		$mvweb_facts = '';
	}

	$mvweb_text .= $mvweb_html;
}

if ( '' !== $mvweb_facts ) {
	$mvweb_text .= '<div class="mvweb-t-ahero__stats">' . $mvweb_facts . '</div>';
}

$mvweb_lists = array(
	'1' => array(
		'modifier' => '',
		'hide'     => array( 'lead', 'more', 'author', 'comments', 'views' ),
		'sizes'    => '(min-width: 1024px) 40vw, (min-width: 600px) 50vw, 100vw',
	),
	'2' => array(
		'modifier' => 'row',
		'hide'     => array( 'more', 'author', 'comments', 'views' ),
		'sizes'    => '(min-width: 600px) 220px, 100vw',
	),
	'3' => array(
		'modifier' => 'card',
		'hide'     => array( 'lead', 'more', 'author', 'read', 'comments', 'views' ),
		'sizes'    => '(min-width: 1024px) 25vw, (min-width: 600px) 50vw, 100vw',
	),
	'4' => array(
		'modifier' => 'row',
		'hide'     => array( 'lead', 'more', 'author', 'comments', 'views' ),
		'sizes'    => '(min-width: 600px) 220px, 100vw',
	),
	'5' => array(
		'modifier' => 'text',
		'hide'     => array( 'media', 'more', 'author', 'comments', 'views' ),
		'sizes'    => '',
	),
);
$mvweb_list  = isset( $mvweb_lists[ $mvweb_view ] ) ? $mvweb_lists[ $mvweb_view ] : $mvweb_lists['1'];
$mvweb_class = 'mvweb-t-ahero mvweb-t-ahero--' . $mvweb_view . ( '3' === $mvweb_view ? ' mvweb-t-section--inverse' : '' );

get_header();
?>

<div class="mvweb-t-container">
	<div class="<?php echo esc_attr( $mvweb_class ); ?>">
		<?php if ( '4' === $mvweb_view ) : ?>
			<?php echo $mvweb_avatar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template. ?>
		<?php endif; ?>
		<div class="mvweb-t-ahero__text">
			<?php get_template_part( 'template-parts/crumbs' ); ?>
			<div class="mvweb-t-ahero__who">
				<?php if ( '4' !== $mvweb_view ) : ?>
					<?php echo $mvweb_avatar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template. ?>
				<?php endif; ?>
				<div class="mvweb-t-ahero__name">
					<h1 class="mvweb-t-ahero__title"><?php echo esc_html( $mvweb_title ); ?></h1>
					<?php echo $mvweb_role; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template. ?>
				</div>
			</div>
			<?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?>
		</div>
	</div>
</div>

<?php
mvweb_theme_layout_open( mvweb_core_sidebar_area() );

if ( have_posts() ) :
	update_post_thumbnail_cache();
	?>
	<div class="mvweb-t-author-list">
		<?php if ( in_array( $mvweb_view, array( '1', '4' ), true ) ) : ?>
			<div class="mvweb-t-author-list__title mvweb-t-h2"><?php esc_html_e( 'Articles by the author', 'journal' ); ?></div>
		<?php endif; ?>

		<div class="<?php echo esc_attr( 'mvweb-t-author-list__items mvweb-t-author-list__items--' . $mvweb_view ); ?>">
			<?php
			while ( have_posts() ) :
				the_post();

				get_template_part(
					'template-parts/post-card',
					null,
					array(
						'modifier' => $mvweb_list['modifier'],
						'hide'     => $mvweb_list['hide'],
						'sizes'    => $mvweb_list['sizes'],
					)
				);
			endwhile;
			?>
		</div>

		<?php mvweb_theme_pagination(); ?>
	</div>
	<?php
else :
	$mvweb_more = mvweb_core_sitemap_page_ids();
	$mvweb_more = empty( $mvweb_more ) ? '' : (string) get_permalink( $mvweb_more[0] );

	get_template_part(
		'template-parts/empty',
		null,
		array(
			'icon'        => 'checklist',
			'title'       => __( 'The author has no articles yet', 'journal' ),
			'text'        => __( 'The first article of the author is coming soon.', 'journal' ),
			'button_url'  => '' !== $mvweb_more ? $mvweb_more : home_url( '/' ),
			'button_text' => '' !== $mvweb_more ? __( 'All categories', 'journal' ) : __( 'To the homepage', 'journal' ),
		)
	);
endif;

mvweb_theme_layout_close( mvweb_core_sidebar_area() );

get_footer();
