( function () {
	var drawer = document.querySelector( '[data-drawer]' );

	document.addEventListener( 'click', function ( event ) {
		var go = event.target.closest( '[data-trot-go]' );

		if ( go ) {
			var box = go.closest( '[data-trot]' );
			var items = box.querySelectorAll( '.mvweb-t-trot__a' );
			var at = Array.prototype.findIndex.call( items, function ( item ) {
				return ! item.hidden;
			} );
			var next = ( at + parseInt( go.getAttribute( 'data-trot-go' ), 10 ) + items.length ) % items.length;

			items.forEach( function ( item, index ) {
				item.hidden = index !== next;
			} );
			box.querySelector( '[data-trot-count]' ).textContent = String( next + 1 );

			return;
		}

		var open = event.target.closest( '[data-subscribe-open]' );
		var pop = document.getElementById( 'mvweb-t-subpop' );

		if ( open && pop ) {
			var form = pop.querySelector( '.mvweb-t-subpop__mail' ) ? null : document.querySelector( '[data-subscribe-form]' );

			if ( drawer && drawer.open ) {
				drawer.close();
			}

			if ( form ) {
				var field = form.querySelector( 'input:not([type="hidden"]), textarea, select, button' );

				form.scrollIntoView( { block: 'center' } );

				if ( field ) {
					field.focus( { preventScroll: true } );
				}
			} else {
				pop.showPopover();
			}

			return;
		}

		var link = drawer && drawer.open ? event.target.closest( 'a[href*="#"]' ) : null;

		if ( link && drawer.contains( link ) && link.pathname === window.location.pathname ) {
			drawer.close();
		}

		if ( event.target.closest( '[data-notice-close]' ) ) {
			var logo = document.querySelector( '[data-header] .mvweb-t-logo' );

			if ( logo ) {
				logo.focus();
			}
		}
	} );

	if ( drawer ) {
		window.matchMedia( '(min-width: 1024px)' ).addEventListener( 'change', function ( event ) {
			if ( event.matches && drawer.open ) {
				drawer.close();
			}
		} );
	}
}() );
