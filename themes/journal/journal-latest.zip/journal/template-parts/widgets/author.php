<?php
/**
 * Widget body: the card of the author of the article or of the author page — photo, name, position, description, links.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_parts  = isset( $args['parts'] ) ? (array) $args['parts'] : array();
$mvweb_author = isset( $args['author'] ) ? absint( $args['author'] ) : 0;
$mvweb_name   = isset( $args['name'] ) ? (string) $args['name'] : '';
$mvweb_url    = isset( $args['url'] ) ? (string) $args['url'] : '';
$mvweb_role   = isset( $args['role'] ) ? (string) $args['role'] : '';
$mvweb_bio    = isset( $args['bio'] ) ? (string) $args['bio'] : '';
$mvweb_links  = isset( $args['links'] ) ? (array) $args['links'] : array();
$mvweb_photo  = '';

if ( '' === $mvweb_name ) {
	return;
}

if ( in_array( 'photo', $mvweb_parts, true ) ) {
	$mvweb_photo = (string) get_avatar(
		$mvweb_author,
		112,
		'',
		'',
		array(
			'class'         => 'mvweb-t-wauthor__photo',
			'force_display' => false,
			'loading'       => 'lazy',
		)
	);

	if ( '' === $mvweb_photo ) {
		$mvweb_photo = '<span class="mvweb-t-wauthor__photo mvweb-t-wauthor__photo--letter" aria-hidden="true">' . esc_html( function_exists( 'mb_substr' ) ? mb_substr( $mvweb_name, 0, 1 ) : substr( $mvweb_name, 0, 1 ) ) . '</span>';
	}
}
?>
<div class="<?php echo esc_attr( 'mvweb-t-wauthor' . ( '' === $mvweb_photo ? ' mvweb-t-wauthor--plain' : '' ) ); ?>">
	<div class="mvweb-t-wauthor__head">
		<?php echo $mvweb_photo; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag; the letter is escaped above. ?>
		<div class="mvweb-t-wauthor__who">
			<?php if ( '' !== $mvweb_url ) : ?>
				<a class="mvweb-t-wauthor__name" href="<?php echo esc_url( $mvweb_url ); ?>"><?php echo esc_html( $mvweb_name ); ?></a>
			<?php else : ?>
				<span class="mvweb-t-wauthor__name"><?php echo esc_html( $mvweb_name ); ?></span>
			<?php endif; ?>
			<?php if ( '' !== $mvweb_role ) : ?>
				<span class="mvweb-t-wauthor__role"><?php echo esc_html( $mvweb_role ); ?></span>
			<?php endif; ?>
		</div>
	</div>
	<?php foreach ( $mvweb_parts as $mvweb_part ) : ?>
		<?php if ( 'bio' === $mvweb_part && '' !== $mvweb_bio ) : ?>
			<p class="mvweb-t-wauthor__bio"><?php echo esc_html( $mvweb_bio ); ?></p>
		<?php elseif ( 'links' === $mvweb_part && ! empty( $mvweb_links ) ) : ?>
			<ul class="mvweb-t-wauthor__links">
				<?php foreach ( $mvweb_links as $mvweb_link ) : ?>
					<?php
					/* translators: %s: name of a network or a mail. */
					$mvweb_label = sprintf( __( '%s of the author', 'journal' ), $mvweb_link['label'] );
					$mvweb_icon  = 'world' === $mvweb_link['icon'] ? 'link' : (string) $mvweb_link['icon'];
					?>
					<li>
						<a class="mvweb-t-wauthor__link" href="<?php echo esc_url( $mvweb_link['url'] ); ?>"<?php echo 0 === strpos( $mvweb_link['url'], 'http' ) ? ' target="_blank" rel="noopener"' : ''; ?> title="<?php echo esc_attr( $mvweb_label ); ?>">
							<?php echo mvweb_theme_icon( $mvweb_icon, array( 'class' => in_array( $mvweb_icon, array( 'mail', 'link' ), true ) ? 'mvweb-t-icon--sm' : 'mvweb-t-icon--sm mvweb-t-icon--brand' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
							<span class="screen-reader-text"><?php echo esc_html( $mvweb_label ); ?></span>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	<?php endforeach; ?>
</div>
