<?php
/**
 * Widget body: the contacts of the site in the order the owner set.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_parts  = isset( $args['parts'] ) ? (array) $args['parts'] : array();
$mvweb_phones = isset( $args['phones'] ) ? (array) $args['phones'] : array();
$mvweb_email  = isset( $args['email'] ) ? (string) $args['email'] : '';
$mvweb_where  = isset( $args['address'] ) ? (string) $args['address'] : '';
$mvweb_chats  = isset( $args['messengers'] ) ? (array) $args['messengers'] : array();
$mvweb_hours  = array();

if ( isset( $args['hours'] ) && '' !== (string) $args['hours'] ) {
	$mvweb_contacts = mvweb_core_contacts();

	foreach ( (array) $mvweb_contacts['hours'] as $mvweb_line ) {
		$mvweb_line = trim( $mvweb_line['days'] . ' ' . $mvweb_line['time'] );

		if ( '' !== $mvweb_line ) {
			$mvweb_hours[] = $mvweb_line;
		}
	}
}

$mvweb_layout = mvweb_theme_widget_view(
	'',
	array(
		'1' => 'list',
		'2' => 'card',
		'3' => 'accent',
		'4' => 'phone',
		'5' => 'min',
	)
);
$mvweb_tone   = mvweb_theme_widget_view(
	isset( $args['view'] ) ? (string) $args['view'] : '',
	array(
		'1' => 'dark',
		'2' => 'light',
		'3' => 'accent',
		'4' => 'dark',
		'5' => 'light',
	)
);

$mvweb_row = static function ( $icon, $html, $extra = '' ) {
	return '<div class="mvweb-t-wcont__row' . $extra . '">' . mvweb_theme_icon( $icon, array( 'class' => 'mvweb-t-icon--sm' ) ) . '<div>' . $html . '</div></div>';
};

ob_start();

foreach ( $mvweb_parts as $mvweb_part ) {
	if ( 'phone' === $mvweb_part && ! empty( $mvweb_phones ) ) {
		$mvweb_html = '';

		foreach ( $mvweb_phones as $mvweb_phone ) {
			$mvweb_label = isset( $mvweb_phone['label'] ) ? trim( (string) $mvweb_phone['label'] ) : '';
			$mvweb_html .= '<a class="mvweb-t-wcont__phone" href="' . esc_url( $mvweb_phone['href'] ) . '"><b>' . esc_html( $mvweb_phone['number'] ) . '</b>' . ( '' !== $mvweb_label ? '<small>' . esc_html( $mvweb_label ) . '</small>' : '' ) . '</a>';
		}

		echo $mvweb_row( 'phone', $mvweb_html, ' mvweb-t-wcont__row--phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from escaped values.
	} elseif ( 'hours' === $mvweb_part && ! empty( $mvweb_hours ) ) {
		echo $mvweb_row( 'clock', '<div class="mvweb-t-wcont__hours"><span>' . implode( '</span><span>', array_map( 'esc_html', $mvweb_hours ) ) . '</span></div>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from escaped values.
	} elseif ( 'email' === $mvweb_part && '' !== $mvweb_email ) {
		echo $mvweb_row( 'mail', '<a href="mailto:' . esc_attr( antispambot( $mvweb_email ) ) . '">' . esc_html( antispambot( $mvweb_email ) ) . '</a>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from escaped values.
	} elseif ( 'address' === $mvweb_part && '' !== $mvweb_where ) {
		echo $mvweb_row( 'map-pin', '<span>' . esc_html( $mvweb_where ) . '</span>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from escaped values.
	} elseif ( 'messengers' === $mvweb_part && ! empty( $mvweb_chats ) ) {
		?>
		<div class="mvweb-t-wcont__msgs">
			<?php foreach ( $mvweb_chats as $mvweb_id => $mvweb_chat ) : ?>
				<a class="mvweb-t-wcont__msg" href="<?php echo esc_url( $mvweb_chat['url'] ); ?>" target="_blank" rel="noopener" title="<?php echo esc_attr( $mvweb_chat['label'] ); ?>">
					<?php echo mvweb_theme_icon( mvweb_core_social_icon( $mvweb_id ), array( 'class' => 'mvweb-t-icon--brand' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<span class="screen-reader-text"><?php echo esc_html( $mvweb_chat['label'] ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
		<?php
	}
}

$mvweb_list = trim( (string) ob_get_clean() );

if ( '' === $mvweb_list ) {
	return;
}
?>
<div class="<?php echo esc_attr( 'mvweb-t-wcont mvweb-t-wcont--' . $mvweb_layout . ' mvweb-t-wcont--on-' . $mvweb_tone ); ?>">
	<?php echo $mvweb_list; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled above from escaped values. ?>
</div>
