<?php
/**
 * Widget body: an icon, a line of text and a button; the title of the widget stands inside the card.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_parts = isset( $args['parts'] ) ? (array) $args['parts'] : array();
$mvweb_text  = isset( $args['text'] ) ? (string) $args['text'] : '';
$mvweb_label = isset( $args['button_text'] ) ? (string) $args['button_text'] : '';
$mvweb_url   = isset( $args['button_url'] ) ? (string) $args['button_url'] : '';
$mvweb_look  = mvweb_theme_widget_view(
	isset( $args['view'] ) ? (string) $args['view'] : '',
	array(
		'1' => 'card',
		'2' => 'accent',
		'3' => 'line',
		'4' => 'dark',
		'5' => 'dashed',
	)
);
$mvweb_btn   = array(
	'accent' => ' mvweb-t-btn--on-accent',
	'line'   => ' mvweb-t-btn--ghost',
);

ob_start();

foreach ( $mvweb_parts as $mvweb_part ) {
	if ( 'text' === $mvweb_part && '' !== $mvweb_text ) {
		?>
		<p class="mvweb-t-whelp__text"><?php echo esc_html( $mvweb_text ); ?></p>
		<?php
	} elseif ( 'button' === $mvweb_part && '' !== $mvweb_label && '' !== $mvweb_url ) {
		?>
		<a class="<?php echo esc_attr( 'mvweb-t-btn mvweb-t-btn--sm mvweb-t-whelp__btn' . ( isset( $mvweb_btn[ $mvweb_look ] ) ? $mvweb_btn[ $mvweb_look ] : '' ) ); ?>" href="<?php echo esc_url( $mvweb_url ); ?>">
			<?php echo esc_html( $mvweb_label ); ?>
			<?php if ( 'line' === $mvweb_look ) : ?>
				<?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<?php endif; ?>
		</a>
		<?php
	}
}

$mvweb_body = trim( (string) ob_get_clean() );

if ( '' === $mvweb_body ) {
	return;
}
?>
<div class="<?php echo esc_attr( 'mvweb-t-whelp mvweb-t-whelp--' . $mvweb_look ); ?>">
	<span class="mvweb-t-whelp__ico" aria-hidden="true"><?php echo mvweb_theme_icon( 'message-circle' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
	<?php echo $mvweb_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled above from escaped values. ?>
</div>
