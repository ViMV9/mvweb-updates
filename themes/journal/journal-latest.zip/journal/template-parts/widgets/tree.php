<?php
/**
 * Widget body: the categories of the blog in one of five looks.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rows = isset( $args['rows'] ) ? (array) $args['rows'] : array();

if ( empty( $mvweb_rows ) ) {
	return;
}

$mvweb_look = mvweb_theme_widget_view(
	isset( $args['view'] ) ? (string) $args['view'] : '',
	array(
		'1' => 'list',
		'2' => 'chips',
		'3' => 'icons',
		'4' => 'accordion',
		'5' => 'dots',
	)
);

$mvweb_inside = static function ( $row ) use ( &$mvweb_inside ) {
	foreach ( (array) $row['children'] as $child ) {
		if ( ! empty( $child['current'] ) || $mvweb_inside( $child ) ) {
			return true;
		}
	}

	return false;
};

$mvweb_current = static function ( $row ) {
	return ! empty( $row['current'] ) ? ' aria-current="page"' : '';
};

$mvweb_count = static function ( $row, $tag = 'small', $css = '' ) {
	if ( null === $row['count'] ) {
		return '';
	}

	return '<' . $tag . ( '' !== $css ? ' class="' . esc_attr( $css ) . '"' : '' ) . '>' . esc_html( number_format_i18n( (int) $row['count'] ) ) . '</' . $tag . '>';
};

$mvweb_subs = static function ( $rows, $css ) use ( &$mvweb_subs, $mvweb_current, $mvweb_count ) {
	if ( empty( $rows ) ) {
		return '';
	}

	$html = '<ul class="' . esc_attr( $css ) . '">';

	foreach ( $rows as $row ) {
		$html .= '<li><a href="' . esc_url( $row['url'] ) . '"' . $mvweb_current( $row ) . '><span>' . esc_html( $row['name'] ) . '</span>' . $mvweb_count( $row ) . '</a>';
		$html .= ! empty( $row['open'] ) ? $mvweb_subs( $row['children'], $css ) : '';
		$html .= '</li>';
	}

	return $html . '</ul>';
};

if ( 'chips' === $mvweb_look ) :
	$mvweb_branch = null;
	?>
	<div class="mvweb-t-wcats-set">
		<div class="mvweb-t-wcats-chips">
			<?php foreach ( $mvweb_rows as $mvweb_row ) : ?>
				<?php
				$mvweb_in = $mvweb_inside( $mvweb_row );

				if ( null === $mvweb_branch && ! empty( $mvweb_row['children'] ) && ( ! empty( $mvweb_row['current'] ) || $mvweb_in ) ) {
					$mvweb_branch = $mvweb_row;
				}
				?>
				<a class="<?php echo esc_attr( $mvweb_in ? 'mvweb-t-chip mvweb-t-chip--active' : 'mvweb-t-chip' ); ?>" href="<?php echo esc_url( $mvweb_row['url'] ); ?>"<?php echo $mvweb_current( $mvweb_row ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>><?php echo esc_html( $mvweb_row['name'] ); ?><?php echo $mvweb_count( $mvweb_row, 'span', 'mvweb-t-chip__n' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?></a>
			<?php endforeach; ?>
		</div>
		<?php if ( null !== $mvweb_branch ) : ?>
			<div class="mvweb-t-wcats-chips mvweb-t-wcats-chips--sub">
				<span>
					<?php
					/* translators: %s: name of the category. */
					echo esc_html( sprintf( __( 'In «%s»:', 'journal' ), $mvweb_branch['name'] ) );
					?>
				</span>
				<?php foreach ( $mvweb_branch['children'] as $mvweb_child ) : ?>
					<a href="<?php echo esc_url( $mvweb_child['url'] ); ?>"<?php echo $mvweb_current( $mvweb_child ) . ( $mvweb_inside( $mvweb_child ) ? ' class="mvweb-t-wcats-chips__on"' : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attributes. ?>><?php echo esc_html( $mvweb_child['name'] ); ?></a>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
	<?php
elseif ( 'accordion' === $mvweb_look ) :
	?>
	<div class="mvweb-t-wcats-acc">
		<?php foreach ( $mvweb_rows as $mvweb_row ) : ?>
			<div class="mvweb-t-wcats-acc__item">
				<a class="mvweb-t-wcats-acc__link" href="<?php echo esc_url( $mvweb_row['url'] ); ?>"<?php echo $mvweb_current( $mvweb_row ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>><span><?php echo esc_html( $mvweb_row['name'] ); ?></span><?php echo $mvweb_count( $mvweb_row ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?></a>
				<?php if ( ! empty( $mvweb_row['children'] ) ) : ?>
					<?php
					/* translators: %s: name of the category. */
					$mvweb_toggle = sprintf( __( 'Subcategories of %s', 'journal' ), $mvweb_row['name'] );
					?>
					<details<?php echo ! empty( $mvweb_row['open'] ) ? ' open' : ''; ?>>
						<summary title="<?php echo esc_attr( $mvweb_toggle ); ?>">
							<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
							<span class="screen-reader-text"><?php echo esc_html( $mvweb_toggle ); ?></span>
						</summary>
						<?php echo $mvweb_subs( $mvweb_row['children'], 'mvweb-t-wcats-acc__subs' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>
					</details>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>
	</div>
	<?php
else :
	?>
	<ul class="<?php echo esc_attr( 'mvweb-t-wcats mvweb-t-wcats--' . $mvweb_look ); ?>">
		<?php foreach ( $mvweb_rows as $mvweb_row ) : ?>
			<?php $mvweb_open = ! empty( $mvweb_row['open'] ) && ! empty( $mvweb_row['children'] ); ?>
			<li>
				<a class="<?php echo esc_attr( $mvweb_open ? 'mvweb-t-wcats__a mvweb-t-wcats__a--open' : 'mvweb-t-wcats__a' ); ?>" href="<?php echo esc_url( $mvweb_row['url'] ); ?>"<?php echo $mvweb_current( $mvweb_row ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
					<?php if ( 'icons' === $mvweb_look ) : ?>
						<span class="mvweb-t-wcats__ico"><?php echo mvweb_theme_icon( ! empty( $mvweb_row['id'] ) && get_term( (int) $mvweb_row['id'] ) instanceof WP_Term ? mvweb_core_term_icon( get_term( (int) $mvweb_row['id'] ) ) : 'file-text' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
					<?php endif; ?>
					<span><?php echo esc_html( $mvweb_row['name'] ); ?></span>
					<?php echo $mvweb_count( $mvweb_row ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>
				</a>
				<?php echo $mvweb_open ? $mvweb_subs( $mvweb_row['children'], 'mvweb-t-wcats__subs' ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php
endif;
