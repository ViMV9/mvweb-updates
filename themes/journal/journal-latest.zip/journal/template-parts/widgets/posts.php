<?php
/**
 * Widget body: the latest or the most read posts in one of five looks.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rows = isset( $args['rows'] ) ? (array) $args['rows'] : array();

if ( empty( $mvweb_rows ) ) {
	return;
}

$mvweb_parts    = isset( $args['parts'] ) ? (array) $args['parts'] : array();
$mvweb_source   = isset( $args['instance']['source'] ) ? (string) $args['instance']['source'] : 'recent';
$mvweb_views    = ! empty( $args['views'] );
$mvweb_more     = array(
	'6'  => 'soft',
	'7'  => 'thin',
	'8'  => 'top',
	'9'  => 'ring',
	'10' => 'tiles',
);
$mvweb_look     = mvweb_theme_widget_view(
	isset( $args['view'] ) ? (string) $args['view'] : '',
	'read' === $mvweb_source
		? array(
			'1' => 'num',
			'2' => 'row',
			'3' => 'right',
			'4' => 'num',
			'5' => 'date',
		) + $mvweb_more
		: array(
			'1' => 'row',
			'2' => 'lead',
			'3' => 'num',
			'4' => 'right',
			'5' => 'date',
		) + $mvweb_more
);
$mvweb_fresh    = in_array( $mvweb_look, $mvweb_more, true );
$mvweb_image    = in_array( 'image', $mvweb_parts, true ) && in_array( $mvweb_look, array( 'row', 'right', 'lead', 'soft', 'top', 'tiles' ), true );
$mvweb_date     = in_array( 'date', $mvweb_parts, true ) && ! $mvweb_fresh;
$mvweb_numbered = in_array( $mvweb_look, array( 'num', 'thin', 'top', 'ring', 'tiles' ), true );
?>
<ol class="<?php echo esc_attr( 'mvweb-t-wposts mvweb-t-wposts--' . $mvweb_look ); ?>">
	<?php foreach ( $mvweb_rows as $mvweb_i => $mvweb_row ) : ?>
		<?php
		$mvweb_lead = in_array( $mvweb_look, array( 'lead', 'top', 'tiles' ), true ) && 0 === $mvweb_i;
		$mvweb_pic  = '';
		$mvweb_cat  = '';

		if ( in_array( $mvweb_look, array( 'soft', 'thin', 'ring' ), true ) || ( 'top' === $mvweb_look && $mvweb_lead ) ) {
			$mvweb_terms = ! empty( $mvweb_row['id'] ) ? get_the_category( (int) $mvweb_row['id'] ) : array();
			$mvweb_cat   = ! empty( $mvweb_terms ) ? $mvweb_terms[0]->name : '';
		}

		if ( $mvweb_image && ( ! in_array( $mvweb_look, array( 'lead', 'top' ), true ) || $mvweb_lead ) ) {
			$mvweb_pic = $mvweb_lead && ! empty( $mvweb_row['id'] ) && has_post_thumbnail( $mvweb_row['id'] )
				? wp_get_attachment_image(
					get_post_thumbnail_id( $mvweb_row['id'] ),
					'medium_large',
					false,
					array(
						'loading'  => 'lazy',
						'decoding' => 'async',
						'sizes'    => '(min-width: 1024px) 340px, 100vw',
					)
				)
				: (string) $mvweb_row['image'];
		}
		?>
		<li class="mvweb-t-wposts__item">
			<?php if ( '' !== $mvweb_pic ) : ?>
				<a class="mvweb-t-wposts__img" href="<?php echo esc_url( $mvweb_row['url'] ); ?>" tabindex="-1" aria-hidden="true">
					<span class="<?php echo esc_attr( $mvweb_lead ? 'mvweb-t-cover' : 'mvweb-t-cover mvweb-t-cover--square' ); ?>"><?php echo $mvweb_pic; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of an attachment image. ?></span>
					<?php if ( 'top' === $mvweb_look ) : ?>
						<span class="mvweb-t-wposts__no"><?php esc_html_e( 'No. 1', 'journal' ); ?></span>
					<?php endif; ?>
				</a>
			<?php endif; ?>
			<?php if ( $mvweb_numbered && ! ( 'top' === $mvweb_look && $mvweb_lead && '' !== $mvweb_pic ) ) : ?>
				<span class="mvweb-t-wposts__n" aria-hidden="true"><?php echo esc_html( 'thin' === $mvweb_look ? sprintf( '%02d', $mvweb_i + 1 ) : number_format_i18n( $mvweb_i + 1 ) ); ?></span>
			<?php endif; ?>
			<div class="mvweb-t-wposts__body">
				<?php if ( '' !== $mvweb_cat ) : ?>
					<span class="mvweb-t-wposts__cat"><?php echo esc_html( $mvweb_cat ); ?></span>
				<?php endif; ?>
				<a class="mvweb-t-wposts__title" href="<?php echo esc_url( $mvweb_row['url'] ); ?>"><?php echo esc_html( $mvweb_row['title'] ); ?></a>
				<?php if ( $mvweb_date && $mvweb_views && ! empty( $mvweb_row['id'] ) ) : ?>
					<?php
					$mvweb_count = absint( get_post_meta( (int) $mvweb_row['id'], '_mvweb_views', true ) );
					$mvweb_short = number_format_i18n( $mvweb_count );

					if ( $mvweb_count >= 1000 ) {
						/* translators: %s: number of views in thousands, e.g. 7.9. */
						$mvweb_short = sprintf( _x( '%s K', 'thousands of views', 'journal' ), number_format_i18n( $mvweb_count / 1000, $mvweb_count < 10000 ? 1 : 0 ) );
					}

					/* translators: %s: number of views. */
					$mvweb_label = sprintf( _n( '%s view', '%s views', $mvweb_count, 'journal' ), number_format_i18n( $mvweb_count ) );
					?>
					<span class="mvweb-t-wposts__date" title="<?php echo esc_attr( $mvweb_label ); ?>">
						<?php echo mvweb_theme_icon( 'eye', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
						<span aria-hidden="true"><?php echo esc_html( $mvweb_short ); ?></span>
						<span class="screen-reader-text"><?php echo esc_html( $mvweb_label ); ?></span>
					</span>
				<?php elseif ( $mvweb_date && '' !== (string) $mvweb_row['date'] ) : ?>
					<time class="mvweb-t-wposts__date" datetime="<?php echo esc_attr( $mvweb_row['time'] ); ?>"><?php echo esc_html( $mvweb_row['date'] ); ?></time>
				<?php endif; ?>
			</div>
		</li>
	<?php endforeach; ?>
</ol>
