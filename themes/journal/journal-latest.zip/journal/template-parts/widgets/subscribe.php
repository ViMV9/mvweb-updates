<?php
/**
 * Widget body: the social networks with «+N» and the button of the window of all of them, the mailing text and form.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_parts   = isset( $args['parts'] ) ? (array) $args['parts'] : array();
$mvweb_socials = isset( $args['socials'] ) ? (array) $args['socials'] : array();
$mvweb_max     = isset( $args['max'] ) ? absint( $args['max'] ) : 0;
$mvweb_form    = isset( $args['form'] ) ? (string) $args['form'] : '';
$mvweb_text    = isset( $args['text'] ) ? (string) $args['text'] : '';
$mvweb_done    = array();
$mvweb_styles  = array(
	'6'  => 'pills',
	'7'  => 'rows',
	'8'  => 'cta',
	'9'  => 'pair',
	'10' => 'stripes',
);
$mvweb_frame   = mvweb_core_area_view( 'sidebar' );
$mvweb_style   = isset( $mvweb_styles[ $mvweb_frame ] ) ? $mvweb_styles[ $mvweb_frame ] : 'list';

foreach ( $mvweb_parts as $mvweb_part ) {
	if ( 'socials' === $mvweb_part && ! empty( $mvweb_socials ) ) {
		$mvweb_done[] = $mvweb_part;
		?>
		<div class="mvweb-t-wsub__socials">
			<?php
			if ( 'cta' === $mvweb_style ) {
				$mvweb_first = (string) array_key_first( $mvweb_socials );
				$mvweb_lead  = $mvweb_socials[ $mvweb_first ];
				$mvweb_rest  = array_slice( $mvweb_socials, 1, $mvweb_max > 0 ? max( 0, $mvweb_max - 1 ) : null, true );
				?>
				<div class="mvweb-t-wsub__cta" data-brand="<?php echo esc_attr( mvweb_core_social_icon( $mvweb_first ) ); ?>">
					<span class="mvweb-t-wsub__cta-ico"><?php echo mvweb_theme_icon( mvweb_core_social_icon( $mvweb_first ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
					<span class="mvweb-t-wsub__cta-title"><?php /* translators: %s: name of a social network. */ echo esc_html( sprintf( __( 'New articles on %s', 'journal' ), $mvweb_lead['label'] ) ); ?></span>
					<span class="mvweb-t-wsub__cta-text"><?php esc_html_e( 'We will let you know about new articles', 'journal' ); ?></span>
					<a class="mvweb-t-wsub__cta-btn" href="<?php echo esc_url( $mvweb_lead['url'] ); ?>" rel="noopener" target="_blank"><?php esc_html_e( 'Subscribe', 'journal' ); ?></a>
					<?php
					if ( ! empty( $mvweb_rest ) ) {
						mvweb_theme_follow( $mvweb_rest, 'links' );
					}
					?>
				</div>
				<?php
			} else {
				mvweb_theme_follow( $mvweb_socials, $mvweb_style, $mvweb_max );
			}

			mvweb_theme_meta_note( $mvweb_max > 0 ? array_slice( $mvweb_socials, 0, $mvweb_max, true ) : $mvweb_socials );
			?>
			<?php if ( $mvweb_max > 0 && count( $mvweb_socials ) > $mvweb_max ) : ?>
				<button class="mvweb-t-btn mvweb-t-btn--ghost mvweb-t-btn--sm mvweb-t-wsub__all" type="button" popovertarget="mvweb-t-subpop" data-popover-trigger="mvweb-t-subpop"><?php esc_html_e( 'All social networks', 'journal' ); ?></button>
			<?php endif; ?>
		</div>
		<?php
	} elseif ( 'mail' === $mvweb_part && '' !== $mvweb_form ) {
		?>
		<div class="mvweb-t-wsub__mail">
			<?php if ( ! empty( $mvweb_done ) ) : ?>
				<div class="mvweb-t-wsub__cap"><?php esc_html_e( 'Or by e-mail', 'journal' ); ?></div>
			<?php endif; ?>
			<?php if ( '' !== $mvweb_text ) : ?>
				<p class="mvweb-t-wsub__text"><?php echo esc_html( $mvweb_text ); ?></p>
			<?php endif; ?>
			<div class="mvweb-t-wsub__form"><?php echo $mvweb_form; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the mailing plugin. ?></div>
		</div>
		<?php
		$mvweb_done[] = $mvweb_part;
	}
}
