<?php
/**
 * Section template: the first screen with posts of the blog, drawn by the template of the blog posts.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part( 'template-parts/sections/posts', null, isset( $args ) && is_array( $args ) ? $args : array() );
