<?php
/**
 * Section template: the most read and discussed posts, drawn by the template of the blog posts.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part( 'template-parts/sections/posts', null, isset( $args ) && is_array( $args ) ? $args : array() );
