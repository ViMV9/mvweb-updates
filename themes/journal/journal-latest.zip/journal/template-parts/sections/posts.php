<?php
/**
 * Section template: posts of the blog.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'posts', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_view  = (int) $mvweb_block['view'];
$mvweb_desc  = mvweb_theme_blocks();
$mvweb_only  = isset( $mvweb_desc['posts']['only'] ) ? (array) $mvweb_desc['posts']['only'] : array();

foreach ( $mvweb_only as $mvweb_key => $mvweb_views ) {
	if ( in_array( (string) $mvweb_view, array_map( 'strval', (array) $mvweb_views ), true ) ) {
		continue;
	}

	if ( 0 === strpos( (string) $mvweb_key, 'parts.' ) ) {
		$mvweb_block['parts'] = array_values( array_diff( $mvweb_block['parts'], array( substr( (string) $mvweb_key, 6 ) ) ) );
	} elseif ( in_array( $mvweb_key, array( 'kicker', 'title', 'text', 'link_text', 'category_2' ), true ) ) {
		$mvweb_block['props'][ $mvweb_key ] = '';
	}
}

if ( 20 === $mvweb_view ) {
	if ( ! in_array( 'more', $mvweb_block['parts'], true ) ) {
		$mvweb_block['props']['link_text'] = '';
	}

	$mvweb_block['parts'] = array_values( array_diff( $mvweb_block['parts'], array( 'more' ) ) );
}

$mvweb_props  = $mvweb_block['props'];
$mvweb_counts = array( 0, 5, 4, 1, 5, 3, 6, 6, 8, 10, 8, 6, 4, 5, 6, 5, 6, 5, 4, 6, 4 );
$mvweb_count  = isset( $mvweb_counts[ $mvweb_view ] ) ? $mvweb_counts[ $mvweb_view ] : 3;

if ( isset( $mvweb_only['count'] ) && in_array( (string) $mvweb_view, (array) $mvweb_only['count'], true ) && ! empty( $mvweb_props['count'] ) ) {
	$mvweb_count = max( 1, min( 20, absint( $mvweb_props['count'] ) ) );
}

$mvweb_category = isset( $mvweb_props['category'] ) ? absint( $mvweb_props['category'] ) : 0;
$mvweb_term     = $mvweb_category > 0 ? get_term( $mvweb_category, 'category' ) : null;
$mvweb_term     = $mvweb_term instanceof WP_Term ? $mvweb_term : null;

if ( $mvweb_view >= 16 && $mvweb_view <= 19 && '' === trim( (string) $mvweb_props['title'] ) && null !== $mvweb_term ) {
	$mvweb_block['props']['title'] = $mvweb_term->name;
}

if ( empty( $mvweb_block['props']['link_url'] ) ) {
	$mvweb_block['props']['link_url'] = mvweb_core_posts_link( $mvweb_props );
}

$mvweb_tabs  = array();
$mvweb_side  = null;
$mvweb_query = null;

if ( 14 === $mvweb_view ) {
	$mvweb_labels = array(
		'read'    => __( 'Popular', 'journal' ),
		'popular' => __( 'Discussed', 'journal' ),
		'latest'  => __( 'New', 'journal' ),
	);

	if ( ! mvweb_core_views_on() ) {
		unset( $mvweb_labels['read'] );
	}

	foreach ( $mvweb_labels as $mvweb_source => $mvweb_label ) {
		$mvweb_found = mvweb_core_posts_query( array_merge( $mvweb_props, array( 'source' => $mvweb_source ) ), $mvweb_count );

		if ( null !== $mvweb_found ) {
			$mvweb_tabs[ $mvweb_source ] = array(
				'label' => $mvweb_label,
				'query' => $mvweb_found,
			);
		}
	}

	if ( empty( $mvweb_tabs ) ) {
		return;
	}
} else {
	$mvweb_query = mvweb_core_posts_query( $mvweb_props, $mvweb_count );
}

if ( null === $mvweb_query && empty( $mvweb_tabs ) && 5 !== $mvweb_view ) {
	return;
}

$mvweb_shown = null !== $mvweb_query ? wp_list_pluck( $mvweb_query->posts, 'ID' ) : array();

if ( 3 === $mvweb_view ) {
	$mvweb_side = mvweb_core_posts_query( array_merge( $mvweb_props, array( 'source' => 'read' ) ), 5, $mvweb_shown );
} elseif ( 20 === $mvweb_view && ! empty( $mvweb_props['category_2'] ) ) {
	$mvweb_side = mvweb_core_posts_query( array_merge( $mvweb_props, array( 'category' => absint( $mvweb_props['category_2'] ) ) ), $mvweb_count, $mvweb_shown );
}

$mvweb_layout = function_exists( 'mvweb_core_layouts' ) ? mvweb_core_layouts() : array();
$mvweb_all    = isset( $mvweb_layout['card-post']['parts'] ) ? array_map( 'strval', array_keys( $mvweb_layout['card-post']['parts'] ) ) : array();

$mvweb_meta = $mvweb_block['item_parts'];

$mvweb_card = static function ( $modifier, array $show, array $extra = array() ) use ( $mvweb_all, $mvweb_meta ) {
	get_template_part(
		'template-parts/post-card',
		null,
		array_merge(
			array(
				'modifier' => $modifier,
				'hide'     => array_values( array_diff( $mvweb_all, $show, array( 'title' ) ) ),
				'meta'     => $mvweb_meta,
			),
			$extra
		)
	);
};

$mvweb_cards = static function ( $query, $modifier, array $show, array $extra = array(), $from = 0, $to = 0, $numbered = false ) use ( $mvweb_card ) {
	$index = 0;

	$query->rewind_posts();

	while ( $query->have_posts() ) {
		$query->the_post();

		if ( $index >= $from && ( 0 === $to || $index < $to ) ) {
			$mvweb_card( $modifier, $show, $numbered ? array_merge( $extra, array( 'num' => $index + 1 ) ) : $extra );
		}

		++$index;
	}

	wp_reset_postdata();
};

$mvweb_caption = static function ( $source ) {
	$captions = array(
		'latest'  => __( 'Latest', 'journal' ),
		'popular' => __( 'Most discussed', 'journal' ),
		'read'    => __( 'Most read', 'journal' ),
	);

	if ( isset( $captions[ $source ] ) ) {
		echo '<div class="mvweb-t-posts__cap">' . esc_html( $captions[ $source ] ) . '</div>';
	}
};

$mvweb_chips = static function () use ( $mvweb_term, $mvweb_view ) {
	if ( null === $mvweb_term || ! function_exists( 'mvweb_core_blog_children' ) ) {
		return;
	}

	$children = array_slice( mvweb_core_blog_children( $mvweb_term->term_id, 'count' ), 0, 16 === $mvweb_view ? 3 : 4 );

	if ( empty( $children ) ) {
		return;
	}
	?>
	<div class="mvweb-t-chips mvweb-t-posts__chips">
		<?php foreach ( $children as $child ) : ?>
			<?php $link = get_category_link( $child ); ?>
			<a class="mvweb-t-chip" href="<?php echo esc_url( is_string( $link ) ? $link : '' ); ?>"><?php echo esc_html( $child->name ); ?> <span class="mvweb-t-chip__n"><?php echo esc_html( number_format_i18n( (int) $child->count ) ); ?></span></a>
		<?php endforeach; ?>
	</div>
	<?php
};

$mvweb_hint = static function () {
	echo function_exists( 'mvweb_theme_search_field' ) ? mvweb_theme_search_field( 'hello' ) : get_search_form( array( 'echo' => false ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts, or by the renderer of the plugin.

	$tree  = function_exists( 'mvweb_core_menu_tree' ) ? mvweb_core_menu_tree( 'topics' ) : array();
	$items = isset( $tree[0] ) ? $tree[0] : array();

	if ( empty( $items ) ) {
		return;
	}
	?>
	<div class="mvweb-t-posts__hint">
		<span><?php esc_html_e( 'Often searched:', 'journal' ); ?></span>
		<?php foreach ( $items as $item ) : ?>
			<a class="mvweb-t-chip" href="<?php echo esc_url( (string) $item->url ); ?>"><?php echo esc_html( (string) $item->title ); ?></a>
		<?php endforeach; ?>
	</div>
	<?php
};

$mvweb_box = static function ( array $block, array $slugs, $box_class, $title_tag = 'div' ) use ( $mvweb_chips, $mvweb_hint ) {
	$props = $block['props'];
	$text  = '';
	$more  = '';

	ob_start();

	foreach ( $slugs as $slug ) {
		if ( 'kicker' === $slug && '' !== trim( (string) $props['kicker'] ) ) {
			echo '<span class="mvweb-t-kicker">' . esc_html( $props['kicker'] ) . '</span>';
		} elseif ( 'title' === $slug && '' !== trim( (string) $props['title'] ) && 'h1' === $title_tag ) {
			echo '<h1 class="mvweb-t-posts__title">' . esc_html( $props['title'] ) . '</h1>';
		} elseif ( 'title' === $slug && '' !== trim( (string) $props['title'] ) ) {
			echo '<div class="' . ( 'mvweb-t-posts__hello' === $box_class ? 'mvweb-t-posts__title' : 'mvweb-t-h2' ) . '" role="heading" aria-level="2">' . esc_html( $props['title'] ) . '</div>';
		} elseif ( 'lead' === $slug && '' !== trim( (string) $props['text'] ) ) {
			echo '<p class="mvweb-t-section__desc">' . esc_html( $props['text'] ) . '</p>';
		} elseif ( 'chips' === $slug ) {
			$mvweb_chips();
		} elseif ( 'hint' === $slug ) {
			$mvweb_hint();
		} elseif ( 'more' === $slug && ! empty( $props['link_text'] ) && ! empty( $props['link_url'] ) ) {
			$more = '<a class="mvweb-t-section__more" href="' . esc_url( (string) $props['link_url'] ) . '">' . esc_html( (string) $props['link_text'] ) . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>';

			if ( 'mvweb-t-posts__band' === $box_class ) {
				echo $more; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
				$more = '';
			}
		}
	}

	$text = trim( (string) ob_get_clean() );

	if ( '' === $text && '' === $more ) {
		return;
	}

	if ( 'mvweb-t-section__head' !== $box_class ) {
		echo '<div class="' . esc_attr( $box_class ) . '">' . $text . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.

		return;
	}
	?>
	<div class="mvweb-t-section__head">
		<?php if ( '' !== $text ) : ?>
			<div><?php echo $text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?></div>
		<?php endif; ?>
		<?php echo $more; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
	</div>
	<?php
};

$mvweb_wide  = '(min-width: 1024px) 60vw, 100vw';
$mvweb_third = '(min-width: 1024px) 30vw, (min-width: 600px) 50vw, 100vw';
$mvweb_small = '(min-width: 1024px) 12vw, 34vw';
$mvweb_list  = static function () use ( $mvweb_view, $mvweb_query, $mvweb_side, $mvweb_tabs, $mvweb_cards, $mvweb_caption, $mvweb_props, $mvweb_term, $mvweb_wide, $mvweb_third, $mvweb_small ) {
	$first = array(
		'size'  => 'large',
		'sizes' => $mvweb_wide,
		'eager' => true,
	);
	$small = array( 'sizes' => $mvweb_small );
	$third = array( 'sizes' => $mvweb_third );
	$meta  = array( 'date', 'read' );

	if ( null === $mvweb_query && empty( $mvweb_tabs ) ) {
		return;
	}

	switch ( $mvweb_view ) {
		case 1:
			echo '<div class="mvweb-t-posts__layout">';
			$mvweb_cards( $mvweb_query, 'lg', array( 'media', 'topic', 'lead', 'author', 'date', 'read', 'comments' ), $first, 0, 1 );

			if ( count( $mvweb_query->posts ) > 1 ) {
				echo '<div class="mvweb-t-posts__side">';
				$mvweb_caption( isset( $mvweb_props['source'] ) ? (string) $mvweb_props['source'] : 'latest' );
				echo '<div class="mvweb-t-posts__list">';
				$mvweb_cards( $mvweb_query, 'row sm', array( 'media', 'topic', 'date', 'read' ), $small, 1 );
				echo '</div></div>';
			}

			echo '</div>';
			break;
		case 2:
			echo '<div class="mvweb-t-posts__layout">';
			$mvweb_cards( $mvweb_query, 'overlay lg', array( 'media', 'topic', 'lead', 'date', 'read', 'comments' ), array_merge( $first, array( 'sizes' => '100vw' ) ), 0, 1 );

			if ( count( $mvweb_query->posts ) > 1 ) {
				echo '<div class="mvweb-t-posts__row">';
				$mvweb_cards( $mvweb_query, 'text', array( 'topic', 'date', 'read' ), array(), 1 );
				echo '</div>';
			}

			echo '</div>';
			break;
		case 3:
			echo '<div class="mvweb-t-posts__layout"><div class="mvweb-t-posts__main">';
			$mvweb_cards( $mvweb_query, 'hero', array( 'topic', 'lead', 'author', 'read' ), array(), 0, 1 );
			echo '</div>';

			if ( null !== $mvweb_side ) {
				echo '<div class="mvweb-t-posts__side mvweb-t-posts__side--rule">';
				$mvweb_caption( 'read' );
				echo '<div class="mvweb-t-posts__list">';
				$mvweb_cards( $mvweb_side, 'num sm', array( 'views' ), array(), 0, 0, true );
				echo '</div></div>';
			}

			echo '</div>';
			break;
		case 4:
			echo '<div class="mvweb-t-posts__layout">';
			$mvweb_cards( $mvweb_query, 'lg', array( 'media', 'topic', 'lead', 'date', 'read', 'comments' ), $first, 0, 1 );

			if ( count( $mvweb_query->posts ) > 1 ) {
				echo '<div class="mvweb-t-posts__grid">';
				$mvweb_cards( $mvweb_query, 'sm', array( 'media', 'topic', 'read' ), array( 'sizes' => '(min-width: 1024px) 20vw, (min-width: 600px) 50vw, 100vw' ), 1 );
				echo '</div>';
			}

			echo '</div>';
			break;
		case 5:
			echo '<div class="mvweb-t-posts__row">';
			$mvweb_cards( $mvweb_query, '', array( 'media', 'topic', 'date', 'read' ), array_merge( $third, array( 'eager' => true ) ), 0, 1 );
			$mvweb_cards( $mvweb_query, '', array( 'media', 'topic', 'date', 'read' ), $third, 1 );
			echo '</div>';
			break;
		case 6:
			echo '<div class="mvweb-t-posts__grid">';
			$mvweb_cards( $mvweb_query, '', array( 'media', 'topic', 'lead', 'date', 'read', 'comments' ), $third );
			echo '</div>';
			break;
		case 7:
			echo '<div class="mvweb-t-posts__grid">';
			$mvweb_cards( $mvweb_query, 'row', array( 'media', 'topic', 'lead', 'date', 'read' ), array( 'sizes' => '(min-width: 1024px) 15vw, 34vw' ) );
			echo '</div>';
			break;
		case 8:
			echo '<div class="mvweb-t-posts__grid">';
			$mvweb_cards( $mvweb_query, 'card', array( 'media', 'topic', 'date', 'comments' ), array( 'sizes' => '(min-width: 1024px) 22vw, (min-width: 600px) 50vw, 100vw' ) );
			echo '</div>';
			break;
		case 9:
			echo '<div class="mvweb-t-posts__feed">';
			$mvweb_cards( $mvweb_query, '', array( 'topic', 'date' ) );
			echo '</div>';
			break;
		case 10:
			echo '<div class="mvweb-t-posts__rail" data-scroller="' . esc_attr__( 'Blog posts, scroll sideways', 'journal' ) . '">';
			$mvweb_cards( $mvweb_query, 'overlay md', array( 'media', 'topic', 'read' ), array( 'sizes' => '(min-width: 1024px) 22vw, (min-width: 600px) 42vw, 72vw' ) );
			echo '</div>';
			break;
		case 11:
			echo '<div class="mvweb-t-posts__top" style="--mvweb-t-top-rows:' . (int) ceil( count( $mvweb_query->posts ) / 2 ) . '">';
			$mvweb_cards( $mvweb_query, 'num', array( 'topic', 'comments', 'views' ), array( 'pad' => true ), 0, 0, true );
			echo '</div>';
			break;
		case 12:
			echo '<div class="mvweb-t-posts__top" data-scroller="' . esc_attr__( 'Blog posts, scroll sideways', 'journal' ) . '">';
			$mvweb_cards( $mvweb_query, 'num', array( 'media', 'topic', 'comments', 'views' ), array( 'sizes' => '(min-width: 1024px) 22vw, 74vw' ), 0, 0, true );
			echo '</div>';
			break;
		case 13:
			echo '<div class="mvweb-t-posts__top">';
			$mvweb_cards( $mvweb_query, 'num', array( 'topic', 'comments', 'views' ), array(), 0, 0, true );
			echo '</div>';
			break;
		case 14:
			$parts = array(
				'read'    => array( 'media', 'topic', 'views' ),
				'popular' => array( 'media', 'topic', 'comments' ),
				'latest'  => array( 'media', 'topic', 'date' ),
			);
			$thumb = array( 'sizes' => '(min-width: 1024px) 80px, 72px' );
			$on    = count( $mvweb_tabs ) > 1;
			$open  = isset( $mvweb_props['tab'], $mvweb_tabs[ $mvweb_props['tab'] ] ) ? (string) $mvweb_props['tab'] : (string) key( $mvweb_tabs );

			echo '<div class="mvweb-t-posts__tabs"' . ( $on ? ' data-tabs' : '' ) . '>';

			if ( $on ) {
				echo '<div class="mvweb-t-tabs" role="tablist">';

				foreach ( $mvweb_tabs as $source => $tab ) {
					echo '<button type="button" role="tab" data-tab="' . esc_attr( $source ) . '" aria-selected="' . ( $open === $source ? 'true' : 'false' ) . '"' . ( $open === $source ? '' : ' tabindex="-1"' ) . '>' . esc_html( $tab['label'] ) . '</button>';
				}

				echo '</div>';
			}

			foreach ( $mvweb_tabs as $source => $tab ) {
				echo '<div class="mvweb-t-posts__panel"' . ( $on ? ' role="tabpanel" data-tabpanel="' . esc_attr( $source ) . '"' : '' ) . ( $open === $source ? '' : ' hidden' ) . '><div class="mvweb-t-posts__grid">';
				$mvweb_cards( $tab['query'], 'row sm num', $parts[ $source ], $thumb, 0, 0, true );
				echo '</div></div>';

				if ( ! $on ) {
					break;
				}
			}

			echo '</div>';
			break;
		case 15:
			$badges = array(
				'read'    => __( 'No. 1 by views', 'journal' ),
				'popular' => __( 'No. 1 in discussions', 'journal' ),
				'latest'  => __( 'Latest', 'journal' ),
			);
			$source = isset( $mvweb_props['source'] ) ? (string) $mvweb_props['source'] : 'read';

			if ( ! mvweb_core_views_on() ) {
				unset( $badges['read'] );
			}

			echo '<div class="mvweb-t-posts__layout"><div class="mvweb-t-posts__first">';
			$mvweb_cards(
				$mvweb_query,
				'overlay md',
				array( 'media', 'topic', 'comments', 'views' ),
				array(
					'size'  => 'large',
					'sizes' => '(min-width: 1024px) 50vw, 100vw',
					'badge' => isset( $badges[ $source ] ) ? $badges[ $source ] : '',
				),
				0,
				1
			);
			echo '</div>';

			if ( count( $mvweb_query->posts ) > 1 ) {
				echo '<div class="mvweb-t-posts__list">';
				$mvweb_cards(
					$mvweb_query,
					'row sm num',
					array( 'media', 'topic', 'comments', 'views' ),
					array(
						'sizes' => '(min-width: 1024px) 80px, 72px',
						'pad'   => true,
					),
					1,
					0,
					true
				);
				echo '</div>';
			}

			echo '</div>';
			break;
		case 16:
			echo '<div class="mvweb-t-posts__grid">';
			$mvweb_cards( $mvweb_query, '', array_merge( array( 'media' ), $meta ), array( 'sizes' => '(min-width: 1024px) 22vw, (min-width: 600px) 50vw, 100vw' ) );
			echo '</div>';
			break;
		case 17:
			echo '<div class="mvweb-t-posts__layout">';
			$mvweb_cards(
				$mvweb_query,
				'md',
				array( 'media', 'lead', 'date', 'read', 'comments' ),
				array(
					'size'  => 'large',
					'sizes' => '(min-width: 1024px) 55vw, 100vw',
				),
				0,
				1
			);

			if ( count( $mvweb_query->posts ) > 1 ) {
				echo '<div class="mvweb-t-posts__list">';
				$mvweb_cards( $mvweb_query, 'row sm', array_merge( array( 'media' ), $meta ), $small, 1 );
				echo '</div>';
			}

			echo '</div>';
			break;
		case 18:
			echo '<div class="mvweb-t-posts__grid">';
			$mvweb_cards( $mvweb_query, '', array( 'media', 'lead', 'read' ), array( 'sizes' => '(min-width: 1024px) 22vw, (min-width: 600px) 50vw, 100vw' ) );
			echo '</div>';
			break;
		case 19:
			echo '<div class="mvweb-t-posts__layout">';
			$mvweb_cards(
				$mvweb_query,
				'overlay md',
				array_merge( array( 'media' ), $meta ),
				array(
					'size'  => 'large',
					'sizes' => '(min-width: 1024px) 45vw, 100vw',
				),
				0,
				1
			);

			if ( count( $mvweb_query->posts ) > 1 ) {
				echo '<div class="mvweb-t-posts__list">';
				$mvweb_cards( $mvweb_query, 'text', array( 'lead', 'read' ), array(), 1 );
				echo '</div>';
			}

			echo '</div>';
			break;
		case 20:
			$columns = array(
				array( $mvweb_query, $mvweb_term ),
			);

			if ( null !== $mvweb_side ) {
				$second    = get_term( absint( $mvweb_props['category_2'] ), 'category' );
				$columns[] = array( $mvweb_side, $second instanceof WP_Term ? $second : null );
			}

			echo '<div class="mvweb-t-posts__layout">';

			foreach ( $columns as $column ) {
				list( $query, $term ) = $column;
				$link                 = null !== $term ? get_category_link( $term ) : mvweb_core_posts_link( $mvweb_props );

				echo '<div class="mvweb-t-posts__col">';

				if ( null !== $term ) {
					echo '<div class="mvweb-t-posts__name"><div class="mvweb-t-h3" role="heading" aria-level="3">' . esc_html( $term->name ) . '</div>';

					if ( ! empty( $mvweb_props['link_text'] ) && is_string( $link ) && '' !== $link ) {
						echo '<a class="mvweb-t-section__more" href="' . esc_url( $link ) . '">' . esc_html( (string) $mvweb_props['link_text'] ) . '<span class="screen-reader-text">: ' . esc_html( $term->name ) . '</span>' . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
					}

					echo '</div>';
				}

				echo '<div class="mvweb-t-posts__list">';
				$mvweb_cards( $query, 'row sm', array_merge( array( 'media' ), $meta ), $small );
				echo '</div></div>';
			}

			echo '</div>';
			break;
	}
};

$mvweb_box_slugs = array(
	5  => array( 'kicker', 'title', 'lead', 'hint' ),
	16 => array( 'kicker', 'title', 'lead', 'chips', 'more' ),
	18 => array( 'kicker', 'title', 'lead', 'chips', 'more' ),
);
$mvweb_band      = 'plain' === $mvweb_block['look']['background'] ? array(
	8  => 'mvweb-t-section--surface',
	13 => 'mvweb-t-section--inverse',
	19 => 'mvweb-t-section--surface',
) : array();

mvweb_theme_section_open( $mvweb_block, true, isset( $mvweb_band[ $mvweb_view ] ) ? $mvweb_band[ $mvweb_view ] : '' );

if ( isset( $mvweb_box_slugs[ $mvweb_view ] ) ) {
	$mvweb_own   = $mvweb_box_slugs[ $mvweb_view ];
	$mvweb_class = 5 === $mvweb_view ? 'mvweb-t-posts__hello' : ( 16 === $mvweb_view ? 'mvweb-t-posts__band' : 'mvweb-t-section__head' );
	$mvweb_tag   = 5 === $mvweb_view && in_array( 'title', $mvweb_block['parts'], true ) && '' !== trim( (string) $mvweb_block['props']['title'] ) && function_exists( 'mvweb_core_h1_tag' ) ? mvweb_core_h1_tag() : 'div';
	$mvweb_head  = array_values( array_intersect( $mvweb_block['parts'], $mvweb_own ) );
	$mvweb_after = false;

	echo 16 === $mvweb_view ? '<div class="mvweb-t-posts__split">' : '';

	foreach ( $mvweb_block['parts'] as $mvweb_slug ) {
		if ( in_array( $mvweb_slug, $mvweb_own, true ) ) {
			if ( ! $mvweb_after ) {
				$mvweb_box( $mvweb_block, $mvweb_head, $mvweb_class, $mvweb_tag );
				$mvweb_after = true;
			}
		} elseif ( 'list' === $mvweb_slug ) {
			$mvweb_list();
		}
	}

	echo 16 === $mvweb_view ? '</div>' : '';
} else {
	mvweb_theme_render_parts( $mvweb_block, array( 'list' => $mvweb_list ) );
}

mvweb_theme_section_close();
