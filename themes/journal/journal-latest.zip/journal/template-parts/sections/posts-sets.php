<?php
/**
 * Section template: the collections of posts.
 *
 * A collection is a card: a picture, a name, a description, the covers of the
 * posts inside, the number of posts and the minutes of reading, and a button.
 * A collection without published posts is not printed; one collection is drawn
 * large, the picture beside the text.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'posts-sets', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_sets  = array();
$mvweb_speed = max( 1, (int) apply_filters( 'mvweb_core_reading_speed', 180 ) ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- The filter of the core.

foreach ( mvweb_core_visible_rows( isset( $mvweb_props['items'] ) && is_array( $mvweb_props['items'] ) ? $mvweb_props['items'] : array() ) as $mvweb_row ) {
	$mvweb_ids = wp_parse_id_list( isset( $mvweb_row['ids'] ) ? (string) $mvweb_row['ids'] : '' );

	if ( empty( $mvweb_ids ) ) {
		continue;
	}

	$mvweb_posts = get_posts(
		array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'post__in'            => $mvweb_ids,
			'orderby'             => 'post__in',
			'posts_per_page'      => count( $mvweb_ids ),
			'ignore_sticky_posts' => true,
		)
	);

	if ( empty( $mvweb_posts ) ) {
		continue;
	}

	$mvweb_words = 0;

	foreach ( $mvweb_posts as $mvweb_post ) {
		$mvweb_words += (int) preg_match_all( '/[\p{L}\p{N}]+/u', wp_strip_all_tags( $mvweb_post->post_content ) );
	}

	$mvweb_sets[] = array(
		'row'     => $mvweb_row,
		'posts'   => $mvweb_posts,
		'url'     => '' !== trim( (string) ( isset( $mvweb_row['url'] ) ? $mvweb_row['url'] : '' ) ) ? (string) $mvweb_row['url'] : (string) get_permalink( $mvweb_posts[0] ),
		'minutes' => max( 1, (int) ceil( $mvweb_words / $mvweb_speed ) ),
	);
}

if ( empty( $mvweb_sets ) ) {
	return;
}

$mvweb_rv     = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_button = '' !== trim( (string) $mvweb_props['button'] ) ? (string) $mvweb_props['button'] : __( 'Read the collection', 'journal' );

$mvweb_parts = array(
	'title'    => static function ( $set ) {
		echo '<div class="mvweb-t-posts-sets__title mvweb-t-h3"><a href="' . esc_url( $set['url'] ) . '">' . esc_html( (string) $set['row']['title'] ) . '</a></div>';
	},
	'text'     => static function ( $set ) {
		$text = trim( (string) ( isset( $set['row']['text'] ) ? $set['row']['text'] : '' ) );

		if ( '' !== $text ) {
			echo '<p class="mvweb-t-posts-sets__text">' . esc_html( $text ) . '</p>';
		}
	},
	'contents' => static function ( $set ) {
		echo '<ul class="mvweb-t-posts-sets__contents" aria-label="' . esc_attr__( 'Posts of the collection', 'journal' ) . '">';

		foreach ( $set['posts'] as $post ) {
			$title = get_the_title( $post );

			echo '<li class="mvweb-t-posts-sets__thing" title="' . esc_attr( $title ) . '"><a href="' . esc_url( (string) get_permalink( $post ) ) . '">' . get_the_post_thumbnail( $post, 'thumbnail', array( 'alt' => '' ) ) . '<span class="screen-reader-text">' . esc_html( $title ) . '</span></a></li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Image markup of the core, escaped inside.
		}

		echo '</ul>';
	},
	'facts'    => static function ( $set ) {
		$count = count( $set['posts'] );

		echo '<p class="mvweb-t-posts-sets__facts">' . esc_html(
			sprintf(
				/* translators: 1: number of posts, 2: minutes of reading. */
				_n( '%1$s post · %2$s min of reading', '%1$s posts · %2$s min of reading', $count, 'journal' ),
				number_format_i18n( $count ),
				number_format_i18n( $set['minutes'] )
			)
		) . '</p>';
	},
	'button'   => static function ( $set ) use ( $mvweb_button ) {
		echo '<div class="mvweb-t-posts-sets__actions"><a class="mvweb-t-btn" href="' . esc_url( $set['url'] ) . '">' . esc_html( $mvweb_button ) . '<span class="screen-reader-text">: ' . esc_html( (string) $set['row']['title'] ) . '</span></a></div>';
	},
);

$mvweb_print_list = static function ( $block ) use ( $mvweb_sets, $mvweb_parts, $mvweb_rv ) {
	echo '<ul class="mvweb-t-posts-sets__list' . ( 1 === count( $mvweb_sets ) ? ' mvweb-t-posts-sets__list--single' : '' ) . '">';

	foreach ( $mvweb_sets as $set ) {
		$badge = trim( (string) ( isset( $set['row']['badge'] ) ? $set['row']['badge'] : '' ) );
		$image = ! empty( $set['row']['image'] ) ? (string) wp_get_attachment_image( absint( $set['row']['image'] ), 'large', false, array( 'alt' => '' ) ) : get_the_post_thumbnail( $set['posts'][0], 'large', array( 'alt' => '' ) );

		echo '<li class="mvweb-t-posts-sets__item' . ( '' !== $badge ? ' mvweb-t-posts-sets__item--badge' : '' ) . '"' . $mvweb_rv . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute.

		if ( '' !== $badge ) {
			echo '<span class="mvweb-t-badge mvweb-t-posts-sets__badge">' . esc_html( $badge ) . '</span>';
		}

		if ( in_array( 'image', $block['item_parts'], true ) && '' !== $image ) {
			echo '<a class="mvweb-t-posts-sets__media" href="' . esc_url( $set['url'] ) . '" tabindex="-1" aria-hidden="true">' . $image . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Image markup of the core, escaped inside.
		}

		echo '<div class="mvweb-t-posts-sets__body">';
		mvweb_theme_render_item_parts( $block, $set, $mvweb_parts );
		echo '</div></li>';
	}

	echo '</ul>';
};

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts( $mvweb_block, array( 'list' => $mvweb_print_list ), array( 'rv' => true ) );
mvweb_theme_section_close();
