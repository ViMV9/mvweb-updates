<?php
/**
 * The block about the author of a blog entry.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! get_theme_mod( 'mvweb_author_box', false ) ) {
	return;
}

$mvweb_author = (int) get_post_field( 'post_author', get_the_ID() );
$mvweb_name   = trim( (string) get_the_author_meta( 'display_name', $mvweb_author ) );

if ( 0 === $mvweb_author || '' === $mvweb_name ) {
	return;
}

$mvweb_parts  = mvweb_core_blog_layout_html( 'author-box', array( 'author' => $mvweb_author ) );
$mvweb_avatar = isset( $mvweb_parts['avatar'] ) ? $mvweb_parts['avatar'] : '';
$mvweb_bio    = isset( $mvweb_parts['bio'] ) ? $mvweb_parts['bio'] : '';
$mvweb_role   = mvweb_core_author_role( $mvweb_author );
$mvweb_count  = (int) count_user_posts( $mvweb_author, 'post', true );

unset( $mvweb_parts['avatar'], $mvweb_parts['bio'] );

if ( isset( $mvweb_parts['more'] ) ) {
	$mvweb_more = $mvweb_parts['more'];

	unset( $mvweb_parts['more'] );

	$mvweb_parts['more'] = $mvweb_more;
}
?>
<aside class="mvweb-t-author-box<?php echo '' === $mvweb_avatar ? ' mvweb-t-author-box--plain' : ''; ?>" aria-labelledby="mvweb-t-author-box-name">
	<?php echo $mvweb_avatar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template. ?>
	<div class="mvweb-t-author-box__main">
		<div class="mvweb-t-author-box__head">
			<span class="mvweb-t-author-box__kicker"><?php esc_html_e( 'About the author', 'journal' ); ?></span>
			<div class="mvweb-t-author-box__name" id="mvweb-t-author-box-name"><?php echo esc_html( $mvweb_name ); ?></div>
			<?php if ( '' !== $mvweb_role ) : ?>
				<div class="mvweb-t-author-box__role"><?php echo esc_html( $mvweb_role ); ?></div>
			<?php endif; ?>
		</div>
		<?php echo $mvweb_bio; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template. ?>
		<?php if ( $mvweb_count > 0 || ! empty( $mvweb_parts ) ) : ?>
			<div class="mvweb-t-author-box__foot">
				<?php if ( $mvweb_count > 0 ) : ?>
					<span class="mvweb-t-author-box__count"><?php /* translators: %s: number of posts of the author. */ echo wp_kses( sprintf( _n( '%s article', '%s articles', $mvweb_count, 'journal' ), '<b>' . esc_html( number_format_i18n( $mvweb_count ) ) . '</b>' ), array( 'b' => array() ) ); ?></span>
				<?php endif; ?>
				<?php echo implode( '', $mvweb_parts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?>
			</div>
		<?php endif; ?>
	</div>
</aside>
