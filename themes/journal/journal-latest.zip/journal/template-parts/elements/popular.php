<?php
/**
 * Zone element: the most read articles of the month in a footer column.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_ids = function_exists( 'mvweb_core_views_period_ids' ) ? mvweb_core_views_period_ids( 'month', array( 'count' => 5 ) ) : array();

if ( empty( $mvweb_ids ) ) {
	return;
}

_prime_post_caches( $mvweb_ids, false, true );

$mvweb_title = trim( (string) mvweb_cz_get( 'mvweb_footer_popular_title' ) );
?>
<div class="mvweb-t-el-popular mvweb-t-footer__col">
	<?php if ( '' !== $mvweb_title ) : ?>
		<div class="mvweb-t-footer__title"><?php echo esc_html( $mvweb_title ); ?></div>
	<?php endif; ?>

	<ol class="mvweb-t-footer__list mvweb-t-footer__popular">
		<?php foreach ( $mvweb_ids as $mvweb_index => $mvweb_id ) : ?>
			<?php $mvweb_thumb = 0 === $mvweb_index ? (int) get_post_thumbnail_id( $mvweb_id ) : 0; ?>
			<li<?php echo $mvweb_thumb ? ' class="mvweb-t-footer__popular-lead"' : ''; ?>>
				<?php if ( $mvweb_thumb ) : ?>
					<a class="mvweb-t-footer__popular-cover" href="<?php echo esc_url( get_permalink( $mvweb_id ) ); ?>" tabindex="-1" aria-hidden="true">
						<?php
						echo wp_get_attachment_image(
							$mvweb_thumb,
							'mvweb_card',
							false,
							array(
								'alt'     => '',
								'loading' => 'lazy',
								'sizes'   => '(min-width: 1024px) 300px, calc(100vw - 2rem)',
							)
						);
						?>
						<span class="mvweb-t-footer__popular-badge"><?php esc_html_e( 'No. 1 this month', 'journal' ); ?></span>
					</a>
				<?php endif; ?>
				<a href="<?php echo esc_url( get_permalink( $mvweb_id ) ); ?>"><?php echo esc_html( get_the_title( $mvweb_id ) ); ?></a>
			</li>
		<?php endforeach; ?>
	</ol>
</div>
