<?php
/**
 * Zone element: Secondary menu — the links of the top bar or of the header row, or a plain list in the mobile menu.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_context = isset( $args['context'] ) ? $args['context'] : 'bar';

if ( 'drawer' === $mvweb_context ) {
	mvweb_core_nav(
		'top',
		array(
			'menu_class' => 'mvweb-t-el-menu-top mvweb-t-drawer__list',
			'items_wrap' => '<ul class="%2$s">%3$s</ul>',
			'link_class' => 'mvweb-t-drawer__link',
			'item_class' => 'mvweb-t-drawer__item',
		)
	);

	return;
}

if ( isset( $args['zone'] ) && 'header-actions' === $args['zone'] ) {
	mvweb_core_nav(
		'top',
		array(
			'menu_class' => 'mvweb-t-header__links-list',
			'depth'      => 1,
			'items_wrap' => '<nav class="mvweb-t-el-menu-top mvweb-t-header__links" aria-label="' . esc_attr__( 'Secondary menu', 'journal' ) . '"><ul class="%2$s">%3$s</ul></nav>',
		)
	);

	return;
}

mvweb_core_nav(
	'top',
	array(
		'menu_class' => 'mvweb-t-notice__list',
		'items_wrap' => '<nav class="mvweb-t-el-menu-top mvweb-t-notice__links" aria-label="' . esc_attr__( 'Secondary menu', 'journal' ) . '"><ul class="%2$s">%3$s</ul></nav>',
	)
);
