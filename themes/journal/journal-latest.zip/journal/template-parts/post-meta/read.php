<?php
/**
 * Facts of a post, part: the reading time.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_minutes = mvweb_core_reading_minutes( get_the_ID() );

if ( 0 === $mvweb_minutes ) {
	return;
}
?>
<span>
	<?php
	echo mvweb_theme_icon( 'clock', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
	/* translators: %s: number of minutes. */
	echo esc_html( sprintf( _x( '%s min', 'reading time', 'journal' ), number_format_i18n( $mvweb_minutes ) ) );
	?>
</span>
