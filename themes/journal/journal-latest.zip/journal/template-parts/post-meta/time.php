<?php
/**
 * Facts of a post, part: the date of the publication.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<span>
	<?php
	printf(
		/* translators: %s: date of the publication. */
		esc_html__( 'Published %s', 'journal' ),
		'<time datetime="' . esc_attr( get_the_date( 'c' ) ) . '">' . esc_html( get_the_date() ) . '</time>'
	);
	?>
</span>
