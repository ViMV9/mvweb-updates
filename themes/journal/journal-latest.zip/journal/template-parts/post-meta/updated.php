<?php
/**
 * Facts of a post, part: the date of the last change, when it is a day or more after the publication.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( (int) get_post_modified_time( 'U', true ) - (int) get_post_time( 'U', true ) < DAY_IN_SECONDS ) {
	return;
}
?>
<span>
	<?php
	echo mvweb_theme_icon( 'refresh', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
	printf(
		/* translators: %s: date of the last change. */
		esc_html__( 'Updated %s', 'journal' ),
		'<time datetime="' . esc_attr( get_the_modified_date( 'c' ) ) . '">' . esc_html( get_the_modified_date() ) . '</time>'
	);
	?>
</span>
