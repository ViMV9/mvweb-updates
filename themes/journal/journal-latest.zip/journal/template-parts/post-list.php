<?php
/**
 * The posts of the main query in the look of the list, their pages, the text under them and what stands in for all of it when the query came back empty.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_args  = wp_parse_args(
	isset( $args ) && is_array( $args ) ? $args : array(),
	array(
		'view'              => '',
		'text'              => '',
		'empty_icon'        => 'search',
		'empty_title'       => '',
		'empty_text'        => '',
		'empty_button_url'  => '',
		'empty_button_text' => '',
		'empty_search_form' => false,
	)
);
$mvweb_view  = (string) $mvweb_args['view'];
$mvweb_wrap  = '' === $mvweb_view;
$mvweb_kind  = in_array( $mvweb_view, array( 'journal', 'feed', 'rows', 'wall', 'columns', 'photos', 'rhythm', 'text' ), true ) ? $mvweb_view : 'grid';
$mvweb_base  = array( 'author', 'views', 'more' );
$mvweb_look  = array(
	'journal' => array( '', array( 'comments' ), '(min-width: 1024px) 560px, (min-width: 600px) 50vw, 100vw' ),
	'grid'    => array( '', array( 'comments' ), '(min-width: 1024px) 560px, (min-width: 600px) 50vw, 100vw' ),
	'feed'    => array( 'row', array( 'date' ), '(min-width: 600px) 220px, 34vw' ),
	'rows'    => array( 'row', array(), '(min-width: 600px) 220px, 34vw' ),
	'wall'    => array( 'card', array( 'comments' ), '(min-width: 1024px) 380px, (min-width: 600px) 50vw, 100vw' ),
	'columns' => array( '', array( 'comments' ), '(min-width: 1024px) 300px, (min-width: 600px) 50vw, 100vw' ),
	'photos'  => array( 'sm', array( 'comments', 'read', 'lead' ), '(min-width: 1024px) 480px, (min-width: 600px) 45vw, 60vw' ),
	'rhythm'  => array( '', array( 'comments' ), '(min-width: 1024px) 380px, (min-width: 600px) 33vw, 50vw' ),
	'text'    => array( 'text', array( 'media', 'comments' ), '' ),
);
$mvweb_eager = true;

$mvweb_card = static function ( $look, $extra = array() ) use ( $mvweb_base, &$mvweb_eager ) {
	$eager = $mvweb_eager && has_post_thumbnail() && ! in_array( 'media', $look[1], true );

	if ( $eager ) {
		$mvweb_eager = false;
	}

	get_template_part(
		'template-parts/post-card',
		null,
		array_merge(
			array(
				'modifier' => $look[0],
				'hide'     => array_merge( $mvweb_base, $look[1] ),
				'sizes'    => $look[2],
				'eager'    => $eager,
			),
			$extra
		)
	);
};

if ( $mvweb_wrap ) {
	echo '<section class="mvweb-t-blog"><div class="mvweb-t-container">';
}

if ( have_posts() ) :
	update_post_thumbnail_cache();
	?>
	<div class="mvweb-t-blog__stream"<?php echo $mvweb_wrap ? '' : mvweb_core_stream_attrs( $mvweb_view ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>>
		<?php
		if ( 'journal' === $mvweb_kind && ! is_paged() ) {
			the_post();
			$mvweb_card(
				array( 'lg', array(), '(min-width: 1240px) 1176px, 100vw' ),
				array( 'size' => 'large' )
			);
		}

		if ( 'feed' === $mvweb_kind ) :
			?>
			<div class="mvweb-t-blog__days" data-list>
				<?php foreach ( mvweb_core_day_groups( $GLOBALS['wp_query']->posts ) as $mvweb_group ) : ?>
					<div class="mvweb-t-blog__day" data-day="<?php echo esc_attr( wp_date( 'Y-m-d', $mvweb_group['stamp'] ) ); ?>">
						<div class="mvweb-t-blog__date"><?php echo esc_html( $mvweb_group['day'] ); ?> <small><?php echo esc_html( $mvweb_group['week'] ); ?></small></div>
						<ol class="mvweb-t-blog__rows">
							<?php
							foreach ( $mvweb_group['posts'] as $mvweb_post ) :
								$GLOBALS['post'] = $mvweb_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- The grouped loop sets the post for the template tags; wp_reset_postdata() restores it.
								setup_postdata( $mvweb_post );
								?>
								<li data-id="<?php the_ID(); ?>"><?php $mvweb_card( $mvweb_look['feed'] ); ?></li>
							<?php endforeach; ?>
						</ol>
					</div>
				<?php endforeach; ?>
			</div>
			<?php
			wp_reset_postdata();
		else :
			?>
			<div class="mvweb-t-blog__list mvweb-t-blog__list--<?php echo esc_attr( $mvweb_kind ); ?>" data-list>
				<?php
				while ( have_posts() ) :
					the_post();

					if ( 'photos' === $mvweb_kind ) :
						$mvweb_src = has_post_thumbnail() ? wp_get_attachment_image_src( (int) get_post_thumbnail_id(), 'mvweb_card' ) : false;
						?>
						<div class="mvweb-t-blog__photo" data-id="<?php the_ID(); ?>"<?php echo is_array( $mvweb_src ) && $mvweb_src[2] > 0 ? ' style="--mvweb-t-ratio:' . esc_attr( (string) round( $mvweb_src[1] / $mvweb_src[2], 3 ) ) . '"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The value is escaped in place. ?>><?php $mvweb_card( $mvweb_look['photos'] ); ?></div>
						<?php
					else :
						$mvweb_card( $mvweb_look[ $mvweb_kind ] );
					endif;
				endwhile;
				?>
			</div>
			<?php
		endif;

		mvweb_theme_pagination();
		?>
	</div>

	<?php if ( '' !== trim( (string) $mvweb_args['text'] ) ) : ?>
		<div class="mvweb-t-prose mvweb-t-prose--measure mvweb-t-blog__text" data-prose>
			<?php echo apply_filters( 'the_content', $mvweb_args['text'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The saved value passed wp_kses_post: the key is registered with it as the sanitize callback. ?>
		</div>
	<?php endif; ?>

	<?php
else :
	get_template_part(
		'template-parts/empty',
		null,
		array(
			'icon'        => $mvweb_args['empty_icon'],
			'title'       => $mvweb_args['empty_title'],
			'text'        => $mvweb_args['empty_text'],
			'button_url'  => $mvweb_args['empty_button_url'],
			'button_text' => $mvweb_args['empty_button_text'],
		)
	);

	if ( $mvweb_args['empty_search_form'] ) {
		get_search_form();
	}
endif;

if ( $mvweb_wrap ) {
	echo '</div></section>';
}
