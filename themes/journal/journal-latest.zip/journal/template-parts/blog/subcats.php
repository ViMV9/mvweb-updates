<?php
/**
 * The subcategories of a blog category above its posts: tiles with an icon, the contents of the subcategories with their articles, tabs or an index.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tiles = isset( $args['tiles'] ) ? (array) $args['tiles'] : array();
$mvweb_view  = isset( $args['view'] ) && in_array( $args['view'], array( 'toc', 'tabs', 'index' ), true ) ? $args['view'] : 'tiles';

if ( empty( $mvweb_tiles ) ) {
	return;
}
?>
<?php if ( 'tiles' === $mvweb_view ) : ?>
	<ul class="mvweb-t-blog__tiles" aria-label="<?php esc_attr_e( 'Subcategories', 'journal' ); ?>">
		<?php foreach ( $mvweb_tiles as $mvweb_tile ) : ?>
			<li>
				<a class="mvweb-t-blog__tile" href="<?php echo esc_url( $mvweb_tile['url'] ); ?>">
					<?php if ( $mvweb_tile['image'] ) : ?>
						<span class="mvweb-t-blog__tile-ico">
							<?php
							echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds and escapes the tag.
								(int) $mvweb_tile['image'],
								'thumbnail',
								false,
								array(
									'alt'     => '',
									'loading' => 'lazy',
								)
							);
							?>
						</span>
					<?php else : ?>
						<span class="mvweb-t-blog__tile-ico"><?php echo mvweb_theme_icon( $mvweb_tile['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
					<?php endif; ?>
					<span class="mvweb-t-blog__tile-name"><?php echo esc_html( $mvweb_tile['title'] ); ?></span>
					<span class="mvweb-t-blog__tile-n"><?php echo esc_html( mvweb_core_articles( (int) $mvweb_tile['count'] ) ); ?></span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
<?php elseif ( 'tabs' === $mvweb_view ) : ?>
	<nav class="mvweb-t-blog__subtabs" aria-label="<?php esc_attr_e( 'Subcategories', 'journal' ); ?>">
		<a class="mvweb-t-blog__subtab" href="<?php echo esc_url( get_category_link( get_queried_object_id() ) ); ?>" aria-current="page"><?php esc_html_e( 'All articles', 'journal' ); ?></a>
		<?php foreach ( $mvweb_tiles as $mvweb_tile ) : ?>
			<a class="mvweb-t-blog__subtab" href="<?php echo esc_url( $mvweb_tile['url'] ); ?>">
				<?php echo esc_html( $mvweb_tile['title'] ); ?>
				<span class="mvweb-t-blog__subtab-n"><?php echo esc_html( number_format_i18n( (int) $mvweb_tile['count'] ) ); ?></span>
			</a>
		<?php endforeach; ?>
	</nav>
<?php elseif ( 'index' === $mvweb_view ) : ?>
	<div class="mvweb-t-blog__subidx" data-subidx>
		<ul class="mvweb-t-blog__subidx-list" aria-label="<?php esc_attr_e( 'Subcategories', 'journal' ); ?>">
			<?php foreach ( $mvweb_tiles as $mvweb_tile ) : ?>
				<li>
					<a class="mvweb-t-blog__subidx-a" href="<?php echo esc_url( $mvweb_tile['url'] ); ?>">
						<span class="mvweb-t-blog__subidx-name"><?php echo esc_html( $mvweb_tile['title'] ); ?></span>
						<span class="mvweb-t-blog__subidx-n"><?php echo esc_html( number_format_i18n( (int) $mvweb_tile['count'] ) ); ?></span>
						<?php echo mvweb_theme_icon( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php if ( count( $mvweb_tiles ) > 5 ) : ?>
			<button class="mvweb-t-blog__subidx-more" type="button" data-subidx-more>
				<?php
				/* translators: %s: number of subcategories. */
				echo esc_html( sprintf( __( 'Show all %s', 'journal' ), number_format_i18n( count( $mvweb_tiles ) ) ) );
				echo mvweb_theme_icon( 'chevron-down' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
				?>
			</button>
		<?php endif; ?>
	</div>
<?php else : ?>
	<div class="mvweb-t-blog__subtoc">
		<?php foreach ( $mvweb_tiles as $mvweb_tile ) : ?>
			<div class="mvweb-t-blog__subtoc-group">
				<a class="mvweb-t-blog__subtoc-name" href="<?php echo esc_url( $mvweb_tile['url'] ); ?>">
					<span><?php echo esc_html( $mvweb_tile['title'] ); ?></span>
					<small><?php echo esc_html( mvweb_core_articles( (int) $mvweb_tile['count'] ) ); ?></small>
				</a>
				<?php if ( ! empty( $mvweb_tile['posts'] ) ) : ?>
					<ul class="mvweb-t-blog__subtoc-posts">
						<?php foreach ( $mvweb_tile['posts'] as $mvweb_post ) : ?>
							<li><a href="<?php echo esc_url( get_permalink( $mvweb_post ) ); ?>"><?php echo esc_html( get_the_title( $mvweb_post ) ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>
			</div>
		<?php endforeach; ?>
	</div>
<?php endif; ?>
