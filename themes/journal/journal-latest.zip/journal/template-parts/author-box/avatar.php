<?php
/**
 * Block about the author, part: the picture, or the first letter of the name without one.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_author = isset( $args['author'] ) ? absint( $args['author'] ) : 0;
$mvweb_avatar = get_avatar(
	$mvweb_author,
	240,
	'',
	'',
	array(
		'class'         => 'mvweb-t-author-box__photo',
		'force_display' => false,
		'loading'       => 'lazy',
	)
);

if ( $mvweb_avatar ) {
	echo $mvweb_avatar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
	return;
}

$mvweb_name = trim( (string) get_the_author_meta( 'display_name', $mvweb_author ) );

if ( '' === $mvweb_name ) {
	return;
}
?>
<span class="mvweb-t-author-box__photo mvweb-t-author-box__photo--letter" aria-hidden="true"><?php echo esc_html( function_exists( 'mb_substr' ) ? mb_substr( $mvweb_name, 0, 1 ) : substr( $mvweb_name, 0, 1 ) ); ?></span>
