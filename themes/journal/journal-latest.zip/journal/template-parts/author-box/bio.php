<?php
/**
 * Block about the author, part: the description from the profile.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_bio = trim( (string) get_the_author_meta( 'description', isset( $args['author'] ) ? absint( $args['author'] ) : 0 ) );

if ( '' === $mvweb_bio ) {
	return;
}
?>
<div class="mvweb-t-author-box__bio"><?php echo wp_kses_post( wpautop( $mvweb_bio ) ); ?></div>
