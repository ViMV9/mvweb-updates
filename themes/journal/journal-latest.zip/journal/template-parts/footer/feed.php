<?php
/**
 * Footer look «Cards»: the most read articles of the month with pictures, the logo and the menus in rows under them.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_ids    = function_exists( 'mvweb_core_views_period_ids' ) ? mvweb_core_views_period_ids( 'month', array( 'count' => 5 ) ) : array();
$mvweb_title  = trim( (string) mvweb_cz_get( 'mvweb_footer_popular_title' ) );
$mvweb_first  = mvweb_theme_footer_menu( 'footer', 'mvweb_footer_menu_title', 'mvweb-t-footer__inline' );
$mvweb_second = mvweb_theme_footer_menu( 'footer-2', 'mvweb_footer_menu_2_title', 'mvweb-t-footer__inline mvweb-t-footer__inline--muted' );
$mvweb_head_1 = trim( (string) mvweb_cz_get( 'mvweb_footer_menu_title' ) );
$mvweb_head_2 = trim( (string) mvweb_cz_get( 'mvweb_footer_menu_2_title' ) );

if ( $mvweb_ids ) {
	_prime_post_caches( $mvweb_ids, false, true );
}
?>
<div class="mvweb-t-container mvweb-t-footer__feed">
	<?php if ( $mvweb_ids ) : ?>
		<?php if ( '' !== $mvweb_title ) : ?>
			<div class="mvweb-t-footer__feed-title"><?php echo esc_html( $mvweb_title ); ?></div>
		<?php endif; ?>

		<ol class="mvweb-t-footer__cards">
			<?php foreach ( $mvweb_ids as $mvweb_id ) : ?>
				<li>
					<a class="mvweb-t-footer__card" href="<?php echo esc_url( get_permalink( $mvweb_id ) ); ?>">
						<span class="mvweb-t-footer__card-cover">
							<?php
							if ( has_post_thumbnail( $mvweb_id ) ) {
								echo wp_get_attachment_image(
									(int) get_post_thumbnail_id( $mvweb_id ),
									'mvweb_card',
									false,
									array(
										'alt'     => '',
										'loading' => 'lazy',
										'sizes'   => '(min-width: 1024px) 240px, 78vw',
									)
								);
							}
							?>
						</span>
						<span class="mvweb-t-footer__card-title"><?php echo esc_html( get_the_title( $mvweb_id ) ); ?></span>
					</a>
				</li>
			<?php endforeach; ?>
		</ol>
	<?php endif; ?>

	<div class="mvweb-t-footer__links">
		<?php get_template_part( 'template-parts/elements/brand' ); ?>

		<div class="mvweb-t-footer__rows">
			<?php if ( '' !== $mvweb_first ) : ?>
				<div>
					<?php if ( '' !== $mvweb_head_1 ) : ?>
						<div class="mvweb-t-footer__title"><?php echo esc_html( $mvweb_head_1 ); ?></div>
					<?php endif; ?>
					<?php echo $mvweb_first; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of wp_nav_menu(), escaped by core. ?>
				</div>
			<?php endif; ?>

			<?php if ( '' !== $mvweb_second ) : ?>
				<div>
					<?php if ( '' !== $mvweb_head_2 ) : ?>
						<div class="mvweb-t-footer__title"><?php echo esc_html( $mvweb_head_2 ); ?></div>
					<?php endif; ?>
					<?php echo $mvweb_second; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of wp_nav_menu(), escaped by core. ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>
