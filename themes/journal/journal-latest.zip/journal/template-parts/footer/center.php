<?php
/**
 * Footer look «Centred»: the logo and the tagline in the middle, the first menu as buttons, the second as a row of links.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tagline = trim( (string) mvweb_cz_get( 'mvweb_footer_tagline', '' ) );
$mvweb_tagline = '' !== $mvweb_tagline ? $mvweb_tagline : get_bloginfo( 'description' );
$mvweb_socials = mvweb_cz_profile_socials();
$mvweb_first   = mvweb_theme_footer_menu( 'footer', 'mvweb_footer_menu_title', 'mvweb-t-footer__pills' );
$mvweb_second  = mvweb_theme_footer_menu( 'footer-2', 'mvweb_footer_menu_2_title', 'mvweb-t-footer__inline' );
?>
<div class="mvweb-t-container mvweb-t-footer__center">
	<?php
	mvweb_theme_logo(
		array(
			'lazy'  => true,
			'image' => absint( get_theme_mod( 'mvweb_footer_logo', 0 ) ),
		)
	);
	?>

	<?php if ( '' !== $mvweb_tagline ) : ?>
		<p class="mvweb-t-footer__about"><?php echo esc_html( $mvweb_tagline ); ?></p>
	<?php endif; ?>

	<?php if ( ! empty( $mvweb_socials ) ) : ?>
		<?php mvweb_theme_follow( $mvweb_socials, 'buttons', 0, 'mvweb-t-footer__follow-row' ); ?>
		<?php mvweb_theme_meta_note( $mvweb_socials ); ?>
	<?php endif; ?>

	<?php if ( '' !== $mvweb_first || '' !== $mvweb_second ) : ?>
		<span class="mvweb-t-footer__rule" aria-hidden="true"></span>
	<?php endif; ?>

	<?php echo $mvweb_first; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of wp_nav_menu(), escaped by core. ?>
	<?php echo $mvweb_second; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of wp_nav_menu(), escaped by core. ?>
</div>
