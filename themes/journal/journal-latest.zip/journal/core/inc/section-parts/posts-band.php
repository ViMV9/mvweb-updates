<?php
/**
 * Parts of a block type with posts of the blog: the same as the general block «Blog posts».
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return require __DIR__ . '/posts.php';
