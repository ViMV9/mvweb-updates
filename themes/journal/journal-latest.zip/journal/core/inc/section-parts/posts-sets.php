<?php
/**
 * Parts of a block type: the collections of posts.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Lead', 'mvweb-core' ),
		'more'   => __( 'Link to all collections', 'mvweb-core' ),
		'list'   => __( 'Collections', 'mvweb-core' ),
	),
	'item_parts' => array(
		'image'    => __( 'Picture', 'mvweb-core' ),
		'title'    => __( 'Name', 'mvweb-core' ),
		'text'     => __( 'Description', 'mvweb-core' ),
		'contents' => __( 'Posts inside', 'mvweb-core' ),
		'facts'    => __( 'Number of posts and reading time', 'mvweb-core' ),
		'button'   => __( 'Button', 'mvweb-core' ),
	),
);
