<?php
/**
 * Badges of the footer: the studio, partners and any other logo with a link.
 *
 * One list in the Customizer; every row has a caption over it, a logo, a link,
 * the text of the link and a view. Until the list is saved, it is read from the
 * former studio and partner badges, so a site keeps what it showed.
 *
 * @package MVweb_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_footer_badge_image' ) ) {
	/**
	 * The attachment id of a stored image, an id or an address.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Stored value.
	 *
	 * @return int
	 */
	function mvweb_core_footer_badge_image( $value ) {
		if ( '' === (string) $value ) {
			return 0;
		}

		$id = is_numeric( $value ) ? absint( $value ) : attachment_url_to_postid( (string) $value );

		return wp_attachment_is_image( $id ) ? $id : 0;
	}
}

if ( ! function_exists( 'mvweb_core_footer_badges_former' ) ) {
	/**
	 * The rows the former studio and partner badges make.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_footer_badges_former() {
		$rows = array();

		if ( get_theme_mod( 'mvweb_footer_dev_enable', true ) ) {
			$rows[] = array(
				'caption' => (string) get_theme_mod( 'mvweb_footer_dev_caption', __( 'Site by', 'mvweb-core' ) ),
				'image'   => mvweb_core_footer_badge_image( get_theme_mod( 'mvweb_footer_dev_image', '' ) ),
				'url'     => (string) get_theme_mod( 'mvweb_footer_dev_url', 'https://mvweb.ru' ),
				'title'   => (string) get_theme_mod( 'mvweb_footer_dev_title', __( 'MVweb studio — website development', 'mvweb-core' ) ),
				'view'    => 'plate',
			);
		}

		if ( get_theme_mod( 'mvweb_footer_partner_enable', false ) ) {
			$rows[] = array(
				'caption' => (string) get_theme_mod( 'mvweb_footer_partner_caption', __( 'Partner', 'mvweb-core' ) ),
				'image'   => mvweb_core_footer_badge_image( get_theme_mod( 'mvweb_footer_partner_image', 0 ) ),
				'url'     => (string) get_theme_mod( 'mvweb_footer_partner_url', '' ),
				'title'   => (string) get_theme_mod( 'mvweb_footer_partner_title', '' ),
				'view'    => 'plate',
			);
		}

		return $rows;
	}
}

if ( ! function_exists( 'mvweb_core_footer_badges' ) ) {
	/**
	 * The badges to print: rows with a link and its text.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array{caption:string,image:int,url:string,title:string,view:string}>
	 */
	function mvweb_core_footer_badges() {
		$saved = get_theme_mod( 'mvweb_footer_badges', null );
		$rows  = null === $saved ? mvweb_core_footer_badges_former() : json_decode( (string) $saved, true );
		$out   = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$url   = isset( $row['url'] ) ? trim( (string) $row['url'] ) : '';
			$title = isset( $row['title'] ) ? trim( (string) $row['title'] ) : '';

			if ( '' === $url || '' === $title ) {
				continue;
			}

			$out[] = array(
				'caption' => isset( $row['caption'] ) ? trim( (string) $row['caption'] ) : '',
				'image'   => isset( $row['image'] ) ? mvweb_core_footer_badge_image( $row['image'] ) : 0,
				'url'     => $url,
				'title'   => $title,
				'view'    => isset( $row['view'] ) && 'inline' === $row['view'] ? 'inline' : 'plate',
			);
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_core_footer_badges_fields' ) ) {
	/**
	 * The list of badges in the footer section.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Customizer Kit.
	 *
	 * @return void
	 */
	function mvweb_core_footer_badges_fields( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'heading',
					'section'     => 'mvweb_cz_footer_blocks',
					'label'       => __( 'Badges: studio, partners', 'mvweb-core' ),
					'priority'    => 40,
					'collapsible' => true,
					'collapsed'   => true,
				),
				array(
					'type'        => 'repeater',
					'settings'    => 'mvweb_footer_badges',
					'section'     => 'mvweb_cz_footer_blocks',
					'label'       => __( 'Badges in the bottom row', 'mvweb-core' ),
					'description' => __( 'The developer of the site, partners, certificates: a logo or a text with a link. A row without a link or its text is not shown. “Logo and text” puts the logo beside the text without a frame, “Plate” puts the caption and the logo or the text in a frame.', 'mvweb-core' ),
					'default'     => wp_json_encode( mvweb_core_footer_badges_former() ),
					'priority'    => 41,
					'fields'      => array(
						'caption' => array(
							'type'    => 'text',
							'label'   => __( 'Caption over it', 'mvweb-core' ),
							'choices' => array(),
						),
						'image'   => array(
							'type'    => 'image',
							'label'   => __( 'Logo', 'mvweb-core' ),
							'choices' => array(),
						),
						'url'     => array(
							'type'    => 'url',
							'label'   => __( 'Link', 'mvweb-core' ),
							'choices' => array(),
						),
						'title'   => array(
							'type'    => 'text',
							'label'   => __( 'Text of the link', 'mvweb-core' ),
							'choices' => array(),
						),
						'view'    => array(
							'type'    => 'select',
							'label'   => __( 'View', 'mvweb-core' ),
							'choices' => array(
								'plate'  => __( 'Plate', 'mvweb-core' ),
								'inline' => __( 'Logo and text', 'mvweb-core' ),
							),
						),
					),
				),
			)
		);
	}
}
add_action( 'mvweb_cz_register', 'mvweb_core_footer_badges_fields' );

if ( ! function_exists( 'mvweb_core_sanitize_footer_logo_height' ) ) {
	/**
	 * A height of the footer logo in pixels, or empty to follow the header.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Stored value.
	 *
	 * @return int|string
	 */
	function mvweb_core_sanitize_footer_logo_height( $value ) {
		return '' === trim( (string) $value ) ? '' : max( 16, min( 160, absint( $value ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_footer_logo_fields' ) ) {
	/**
	 * An own logo of the footer and its height; empty fields follow the logo of the header.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Customizer Kit.
	 *
	 * @return void
	 */
	function mvweb_core_footer_logo_fields( $kit ) {
		$hint = __( 'Empty: as in the header. The buttons switch between computers and phones.', 'mvweb-core' );

		$kit->add_fields(
			array(
				array(
					'type'        => 'heading',
					'section'     => 'mvweb_cz_footer_blocks',
					'label'       => __( 'Logo in the footer', 'mvweb-core' ),
					'priority'    => 25,
					'collapsible' => true,
					'collapsed'   => true,
				),
				array(
					'type'        => 'media',
					'settings'    => 'mvweb_footer_logo',
					'section'     => 'mvweb_cz_footer_blocks',
					'label'       => __( 'Logo', 'mvweb-core' ),
					'description' => __( 'Empty: the logo of the header for dark backgrounds, or its main logo.', 'mvweb-core' ),
					'priority'    => 26,
				),
				array(
					'type'              => 'range',
					'settings'          => 'mvweb_footer_logo_height',
					'section'           => 'mvweb_cz_footer_blocks',
					'label'             => __( 'Logo height, px', 'mvweb-core' ),
					'description'       => $hint,
					'default'           => '',
					'priority'          => 27,
					'device'            => 'desktop',
					'device_group'      => 'mvweb_footer_logo_height',
					'sanitize_callback' => 'mvweb_core_sanitize_footer_logo_height',
					'input_attrs'       => array(
						'min'  => 16,
						'max'  => 160,
						'step' => 1,
					),
					'output'            => array(
						array(
							'element'  => ':root',
							'property' => '--mvweb-t-footer-logo-h',
						),
					),
				),
				array(
					'type'              => 'range',
					'settings'          => 'mvweb_footer_logo_height_mobile',
					'section'           => 'mvweb_cz_footer_blocks',
					'label'             => __( 'Logo height, px', 'mvweb-core' ),
					'description'       => $hint,
					'default'           => '',
					'priority'          => 28,
					'device'            => 'mobile',
					'device_group'      => 'mvweb_footer_logo_height',
					'sanitize_callback' => 'mvweb_core_sanitize_footer_logo_height',
					'input_attrs'       => array(
						'min'  => 16,
						'max'  => 96,
						'step' => 1,
					),
					'output'            => array(
						array(
							'element'  => ':root',
							'property' => '--mvweb-t-footer-logo-h-mobile',
						),
					),
				),
			)
		);
	}
}
add_action( 'mvweb_cz_register', 'mvweb_core_footer_logo_fields' );

if ( ! function_exists( 'mvweb_core_footer_badges_element' ) ) {
	/**
	 * The element of the bottom row prints the whole list.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $elements Slug => label.
	 * @param string               $zone     Zone.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_footer_badges_element( $elements, $zone ) {
		if ( 'footer-bottom' === $zone && isset( $elements['dev-badge'] ) ) {
			$elements['dev-badge'] = __( 'Badges: studio, partners', 'mvweb-core' );
		}

		return $elements;
	}
}
add_filter( 'mvweb_core_zone_elements', 'mvweb_core_footer_badges_element', 20, 2 );
