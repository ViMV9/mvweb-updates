<?php
/**
 * Journal: the sources and the marks of the posts, the categories and the authors of the blog, the homepage as a feed, the loading of the next page, the callouts and the area inside the text of an article.
 *
 * The keys of the looks are the same in every theme; a theme draws each look and may rename it through the filters of this file.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_callouts_sets' ) ) {
	/**
	 * The sets of the look of the callouts.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Value => label.
	 */
	function mvweb_core_callouts_sets() {
		$list = array(
			'none' => __( 'None: the callouts and the card «Read also» are off', 'mvweb-core' ),
			'1'    => __( 'Line on the left', 'mvweb-core' ),
			'2'    => __( 'Tinted plates', 'mvweb-core' ),
			'3'    => __( 'Icon in a circle', 'mvweb-core' ),
			'4'    => __( 'Minimal lines', 'mvweb-core' ),
			'5'    => __( 'Magazine', 'mvweb-core' ),
		);

		/**
		 * Filter the sets of the look of the callouts: key => label.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $list
		 */
		return (array) apply_filters( 'mvweb_core_callouts_sets', $list );
	}
}

if ( ! function_exists( 'mvweb_core_callouts_set' ) ) {
	/**
	 * The set of the callouts chosen in the Customizer; empty when they are off.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_callouts_set() {
		$set = (string) get_theme_mod( 'mvweb_callouts_set', 'none' );

		return 'none' !== $set && isset( mvweb_core_callouts_sets()[ $set ] ) ? $set : '';
	}
}

if ( ! function_exists( 'mvweb_core_article_fields' ) ) {
	/**
	 * The set of the callouts and the place of the advertisement in the section of the article.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_article_fields( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_callouts_set',
					'section'     => 'mvweb_cz_inner_single',
					'label'       => __( 'Callouts in the text', 'mvweb-core' ),
					'description' => __( 'The styles «Important», «Tip», «Warning» of the block «Group» and «Pull quote» of the block «Quote» in the editor. A link to an own post on a line of its own becomes the card «Read also».', 'mvweb-core' ),
					'default'     => 'none',
					'choices'     => mvweb_core_callouts_sets(),
				),
				array(
					'type'        => 'number',
					'settings'    => 'mvweb_in_content_after',
					'section'     => 'mvweb_cz_inner_single',
					'label'       => __( 'Advertisement after the block', 'mvweb-core' ),
					'description' => __( 'The widgets of the area «Article: inside the text» stand after this paragraph or block of the article. Short articles show them at the end.', 'mvweb-core' ),
					'default'     => 3,
					'input_attrs' => array(
						'min'  => 1,
						'max'  => 30,
						'step' => 1,
					),
				),
				array(
					'type'        => 'toggle',
					'settings'    => 'mvweb_views_count',
					'section'     => 'mvweb_cz_inner_single',
					'label'       => __( 'Count the views of the articles', 'mvweb-core' ),
					'description' => __( 'The first view of an article in a visit adds one. Editors and search robots are not counted. The source «Most read» of the blocks and widgets and the lists «Most discussed» of the feed and of the blog categories then put the most read first.', 'mvweb-core' ),
					'default'     => false,
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_article_fields' );

if ( ! function_exists( 'mvweb_core_callouts_styles' ) ) {
	/**
	 * The styles of the blocks «Group» and «Quote» in the editor, when a set is chosen.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_callouts_styles() {
		if ( '' === mvweb_core_callouts_set() || ! function_exists( 'register_block_style' ) ) {
			return;
		}

		$styles = array(
			'mvweb-t-important' => __( 'Important', 'mvweb-core' ),
			'mvweb-t-tip'       => __( 'Tip', 'mvweb-core' ),
			'mvweb-t-warning'   => __( 'Warning', 'mvweb-core' ),
		);

		foreach ( $styles as $name => $label ) {
			register_block_style(
				'core/group',
				array(
					'name'  => $name,
					'label' => $label,
				)
			);
		}

		register_block_style(
			'core/quote',
			array(
				'name'  => 'mvweb-t-pull',
				'label' => __( 'Pull quote', 'mvweb-core' ),
			)
		);

		foreach ( mvweb_core_callouts_extra() as $name => $style ) {
			register_block_style(
				$style['block'],
				array(
					'name'  => 'mvweb-t-' . $name,
					'label' => $style['label'],
				)
			);
		}
	}
}
add_action( 'init', 'mvweb_core_callouts_styles' );

if ( ! function_exists( 'mvweb_core_callouts_extra' ) ) {
	/**
	 * The callouts a theme asks for beyond the base ones: «Key points» of the block «Group», «Sources» and «Steps» of the block «List».
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array{block:string,label:string}> Name => block and label.
	 */
	function mvweb_core_callouts_extra() {
		$support = get_theme_support( 'mvweb-callouts' );
		$wanted  = is_array( $support ) && isset( $support[0] ) ? array_map( 'strval', (array) $support[0] ) : array();
		$all     = array(
			'key'     => array(
				'block' => 'core/group',
				'label' => __( 'Key points', 'mvweb-core' ),
			),
			'sources' => array(
				'block' => 'core/list',
				'label' => __( 'Sources', 'mvweb-core' ),
			),
			'steps'   => array(
				'block' => 'core/list',
				'label' => __( 'Steps', 'mvweb-core' ),
			),
		);

		return array_intersect_key( $all, array_flip( $wanted ) );
	}
}

if ( ! function_exists( 'mvweb_core_callouts_labels' ) ) {
	/**
	 * The words of the callouts as custom properties: the stylesheet prints them, the author writes only the text.
	 *
	 * @since 0.1.0
	 *
	 * @return string CSS.
	 */
	function mvweb_core_callouts_labels() {
		$css   = '';
		$words = array(
			'important' => __( 'Important', 'mvweb-core' ),
			'tip'       => __( 'Tip', 'mvweb-core' ),
			'warning'   => __( 'Warning', 'mvweb-core' ),
			'related'   => __( 'Read also', 'mvweb-core' ),
		);

		foreach ( mvweb_core_callouts_extra() as $key => $style ) {
			$words[ $key ] = $style['label'];
		}

		foreach ( $words as $key => $word ) {
			$css .= '--mvweb-t-callout-' . $key . ':"' . addcslashes( wp_strip_all_tags( $word ), '"\\' ) . '";';
		}

		return ':root{' . $css . '}';
	}
}

if ( ! function_exists( 'mvweb_core_callouts_front' ) ) {
	/**
	 * The words of the callouts beside their stylesheet on the site.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_callouts_front() {
		if ( wp_style_is( 'mvweb-t-callouts', 'enqueued' ) ) {
			wp_add_inline_style( 'mvweb-t-callouts', mvweb_core_callouts_labels() );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_core_callouts_front', 20 );

if ( ! function_exists( 'mvweb_core_callouts_editor' ) ) {
	/**
	 * The stylesheets of the chosen set in the block editor, with the colours of the theme.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_callouts_editor() {
		$set = mvweb_core_callouts_set();

		if ( ! is_admin() || '' === $set ) {
			return;
		}

		$previous = array();

		foreach ( array( 'tokens', 'callouts', 'callouts-' . $set ) as $key ) {
			$file = file_exists( get_template_directory() . '/assets/css/' . $key . '.min.css' ) ? '/assets/css/' . $key . '.min.css' : '/assets/css/' . $key . '.css';

			if ( ! file_exists( get_template_directory() . $file ) ) {
				continue;
			}

			wp_enqueue_style( 'mvweb-t-editor-' . $key, get_template_directory_uri() . $file, $previous, (string) filemtime( get_template_directory() . $file ) );

			$previous = array( 'mvweb-t-editor-' . $key );
		}

		wp_add_inline_style( 'mvweb-t-editor-callouts', mvweb_core_callouts_labels() );
	}
}
add_action( 'enqueue_block_assets', 'mvweb_core_callouts_editor' );

if ( ! function_exists( 'mvweb_core_callouts_needed' ) ) {
	/**
	 * Whether the post being read carries a callout, a pull quote or an embed.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_callouts_needed() {
		if ( '' === mvweb_core_callouts_set() || ! is_singular() ) {
			return false;
		}

		$content = (string) get_post_field( 'post_content', get_queried_object_id() );

		return false !== strpos( $content, 'is-style-mvweb-t-' ) || false !== strpos( $content, '<!-- wp:embed' );
	}
}

if ( ! function_exists( 'mvweb_core_related_post' ) ) {
	/**
	 * The own published post a link leads to; 0 for a link elsewhere.
	 *
	 * @since 0.1.0
	 *
	 * @param string $url Address.
	 *
	 * @return int
	 */
	function mvweb_core_related_post( $url ) {
		if ( '' === $url || wp_parse_url( home_url(), PHP_URL_HOST ) !== wp_parse_url( $url, PHP_URL_HOST ) ) {
			return 0;
		}

		$id = url_to_postid( $url );

		return $id > 0 && 'publish' === get_post_status( $id ) && 'post' === get_post_type( $id ) && (int) get_queried_object_id() !== $id ? $id : 0;
	}
}

if ( ! function_exists( 'mvweb_core_related_card' ) ) {
	/**
	 * Put the card of the theme in place of the frame WordPress embeds for a link to an own post: one request, the styles of the set.
	 *
	 * @since 0.1.0
	 *
	 * @param string              $html  Markup of the block.
	 * @param array<string,mixed> $block Block.
	 *
	 * @return string
	 */
	function mvweb_core_related_card( $html, $block ) {
		if ( '' === mvweb_core_callouts_set() || is_feed() ) {
			return $html;
		}

		$id = mvweb_core_related_post( isset( $block['attrs']['url'] ) ? (string) $block['attrs']['url'] : '' );

		if ( 0 === $id ) {
			return $html;
		}

		ob_start();
		get_template_part( 'template-parts/journal/related', null, array( 'post' => $id ) );

		return (string) ob_get_clean();
	}
}
add_filter( 'render_block_core/embed', 'mvweb_core_related_card', 10, 2 );

if ( ! function_exists( 'mvweb_core_in_content_area' ) ) {
	/**
	 * The area of widgets inside the text of an article.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_in_content_area() {
		register_sidebar(
			array(
				'name'          => __( 'Article: inside the text', 'mvweb-core' ),
				'id'            => 'in-content',
				'description'   => __( 'An advertisement or a subscription inside the text of a post. The place is set in «Blog: article page», the field «Advertisement after the block».', 'mvweb-core' ),
				'before_widget' => '<div id="%1$s" class="' . esc_attr( mvweb_core_widget_class( 'insert' ) ) . ' %2$s">',
				'after_widget'  => '</div>',
				'before_title'  => '<div class="' . esc_attr( mvweb_core_widget_class( 'insert_title' ) ) . '">',
				'after_title'   => '</div>',
			)
		);
	}
}
add_action( 'widgets_init', 'mvweb_core_in_content_area', 20 );

if ( ! function_exists( 'mvweb_core_in_content_html' ) ) {
	/**
	 * The markup of the area inside the text, once a page and only in the text of the post being read; empty where it does not belong.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_in_content_html() {
		static $done = false;

		if ( $done || ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() || is_feed() || doing_filter( 'get_the_excerpt' ) || get_the_ID() !== get_queried_object_id() || ! is_active_sidebar( 'in-content' ) ) {
			return '';
		}

		$done = true;

		ob_start();
		dynamic_sidebar( 'in-content' );
		$widgets = trim( (string) ob_get_clean() );

		return '' === $widgets ? '' : '<aside class="' . esc_attr( mvweb_core_widget_class( 'inserts' ) ) . '" data-in-content aria-label="' . esc_attr__( 'Advertisement', 'mvweb-core' ) . '">' . $widgets . '</aside>';
	}
}

if ( ! function_exists( 'mvweb_core_in_content_after' ) ) {
	/**
	 * After which block of the text the area stands.
	 *
	 * @since 0.1.0
	 *
	 * @return int
	 */
	function mvweb_core_in_content_after() {
		return min( 30, max( 1, absint( get_theme_mod( 'mvweb_in_content_after', 3 ) ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_in_content_blocks' ) ) {
	/**
	 * Put the area between the blocks of the top level of an article of the block editor, before the blocks are rendered.
	 *
	 * @since 0.1.0
	 *
	 * @param string $content Content of the post.
	 *
	 * @return string
	 */
	function mvweb_core_in_content_blocks( $content ) {
		if ( ! has_blocks( $content ) ) {
			return $content;
		}

		$area = mvweb_core_in_content_html();

		if ( '' === $area ) {
			return $content;
		}

		$blocks = parse_blocks( $content );
		$after  = mvweb_core_in_content_after();
		$seen   = 0;
		$out    = array();
		$done   = false;

		foreach ( $blocks as $block ) {
			$out[] = $block;

			if ( ! $done && null !== $block['blockName'] && ++$seen === $after ) {
				$out[] = array(
					'blockName'    => null,
					'attrs'        => array(),
					'innerBlocks'  => array(),
					'innerHTML'    => "\n" . $area . "\n",
					'innerContent' => array( "\n" . $area . "\n" ),
				);
				$done  = true;
			}
		}

		if ( ! $done ) {
			$out[] = array(
				'blockName'    => null,
				'attrs'        => array(),
				'innerBlocks'  => array(),
				'innerHTML'    => "\n" . $area . "\n",
				'innerContent' => array( "\n" . $area . "\n" ),
			);
		}

		return serialize_blocks( $out );
	}
}
add_filter( 'the_content', 'mvweb_core_in_content_blocks', 8 );

if ( ! function_exists( 'mvweb_core_in_content_classic' ) ) {
	/**
	 * Put the area after a paragraph of an article of the classic editor, once the paragraphs are made.
	 *
	 * @since 0.1.0
	 *
	 * @param string $content Content of the post.
	 *
	 * @return string
	 */
	function mvweb_core_in_content_classic( $content ) {
		if ( false !== strpos( $content, 'data-in-content' ) || has_blocks( (string) get_post_field( 'post_content', get_the_ID() ) ) ) {
			return $content;
		}

		$area = mvweb_core_in_content_html();

		if ( '' === $area ) {
			return $content;
		}

		$parts = explode( '</p>', $content );
		$after = mvweb_core_in_content_after();

		if ( count( $parts ) <= $after ) {
			return $content . $area;
		}

		return implode( '</p>', array_slice( $parts, 0, $after ) ) . '</p>' . $area . implode( '</p>', array_slice( $parts, $after ) );
	}
}
add_filter( 'the_content', 'mvweb_core_in_content_classic', 12 );

if ( ! function_exists( 'mvweb_core_authors_block' ) ) {
	/**
	 * Register the block «Authors».
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_authors_block() {
		mvweb_core_register_section(
			'authors',
			array(
				'label'       => __( 'Authors', 'mvweb-core' ),
				'description' => __( 'The authors of the blog with the photo, the position, the number of articles and the links', 'mvweb-core' ),
				'category'    => 'trust',
				'fields'      => array(
					'kicker'      => array(
						'type'  => 'text',
						'label' => __( 'Line above the heading', 'mvweb-core' ),
					),
					'title'       => array(
						'type'  => 'text',
						'label' => __( 'Heading', 'mvweb-core' ),
					),
					'text'        => array(
						'type'  => 'textarea',
						'label' => __( 'Text under the heading', 'mvweb-core' ),
					),
					'ids'         => array(
						'type'        => 'text',
						'label'       => __( 'Authors chosen by hand', 'mvweb-core' ),
						'description' => __( 'Numbers of the users separated by commas, in the order of showing. The number is in the address of the profile editor: user_id=3. Empty: every author with articles, more articles first. The position is the field of the profile.', 'mvweb-core' ),
					),
					'count'       => array(
						'type'    => 'number',
						'label'   => __( 'How many authors', 'mvweb-core' ),
						'min'     => 1,
						'max'     => 48,
						'default' => 12,
					),
					'chief_label' => array(
						'type'        => 'text',
						'label'       => __( 'Label of the first author', 'mvweb-core' ),
						'description' => __( 'The first author of the list stands large.', 'mvweb-core' ),
						'default'     => __( 'Editor-in-chief', 'mvweb-core' ),
					),
					'letter'      => array(
						'type'        => 'textarea',
						'label'       => __( 'Letter of the first author', 'mvweb-core' ),
						'description' => __( 'A few words to the readers; an empty line starts a new paragraph. Empty: the biography from the profile.', 'mvweb-core' ),
					),
					'link_text'   => array(
						'type'    => 'text',
						'label'   => __( 'Link to all authors', 'mvweb-core' ),
						'default' => __( 'All authors', 'mvweb-core' ),
					),
					'link_url'    => array(
						'type'        => 'url',
						'label'       => __( 'Where the link leads', 'mvweb-core' ),
						'description' => __( 'For example the page about the editorial team. Empty: no link.', 'mvweb-core' ),
					),
					'button_text' => array(
						'type'  => 'text',
						'label' => __( 'Button text', 'mvweb-core' ),
					),
					'button_url'  => array(
						'type'        => 'url',
						'label'       => __( 'Button link', 'mvweb-core' ),
						'description' => __( 'For example the page about how the articles are checked. Empty: no button.', 'mvweb-core' ),
					),
					'facts'       => array(
						'type'        => 'repeat',
						'label'       => __( 'Figures', 'mvweb-core' ),
						'description' => __( 'Up to four figures that show why the readers trust the site.', 'mvweb-core' ),
						'max'         => 4,
						'fields'      => array(
							'number' => array(
								'type'  => 'text',
								'label' => __( 'Figure', 'mvweb-core' ),
							),
							'label'  => array(
								'type'  => 'text',
								'label' => __( 'What it counts', 'mvweb-core' ),
							),
						),
					),
					'groups'      => array(
						'type'   => 'repeat',
						'label'  => __( 'Groups', 'mvweb-core' ),
						'max'    => 8,
						'fields' => array(
							'title' => array(
								'type'  => 'text',
								'label' => __( 'Name of the group', 'mvweb-core' ),
							),
							'text'  => array(
								'type'  => 'textarea',
								'label' => __( 'What the group does', 'mvweb-core' ),
							),
							'ids'   => array(
								'type'        => 'text',
								'label'       => __( 'Authors of the group', 'mvweb-core' ),
								'description' => __( 'Numbers of the users separated by commas.', 'mvweb-core' ),
							),
						),
					),
				),
			)
		);
	}
}
add_action( 'mvweb_core_register_sections', 'mvweb_core_authors_block' );

if ( ! function_exists( 'mvweb_core_authors' ) ) {
	/**
	 * The authors of a block: by hand or every author with articles, more articles first.
	 *
	 * @since 0.1.0
	 *
	 * @param int[] $ids   Users by hand; empty for every author.
	 * @param int   $count How many.
	 *
	 * @return array<int,array{id:int,name:string,role:string,bio:string,url:string,posts:int}>
	 */
	function mvweb_core_authors( array $ids, $count ) {
		$args = array(
			'number' => max( 1, (int) $count ),
			'fields' => array( 'ID', 'display_name' ),
		);

		if ( ! empty( $ids ) ) {
			$args['include'] = $ids;
			$args['orderby'] = 'include';
		} else {
			$args['has_published_posts'] = array( 'post' );
			$args['orderby']             = 'post_count';
			$args['order']               = 'DESC';
		}

		$users = get_users( $args );

		if ( empty( $users ) ) {
			return array();
		}

		$counts  = count_many_users_posts( wp_list_pluck( $users, 'ID' ), 'post', true );
		$authors = array();

		foreach ( $users as $user ) {
			$id = (int) $user->ID;

			$authors[] = array(
				'id'    => $id,
				'name'  => (string) $user->display_name,
				'role'  => mvweb_core_author_role( $id ),
				'bio'   => trim( wp_strip_all_tags( (string) get_the_author_meta( 'description', $id ) ) ),
				'url'   => get_author_posts_url( $id ),
				'posts' => isset( $counts[ $id ] ) ? (int) $counts[ $id ] : 0,
			);
		}

		return $authors;
	}
}

if ( ! function_exists( 'mvweb_core_author_markup' ) ) {
	/**
	 * The page of an author as a ProfilePage about a Person, and the Person of an article with the links of the author.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $graph Nodes.
	 * @param string                         $url   Address of the page.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_author_markup( $graph, $url ) {
		$graph  = (array) $graph;
		$author = is_author() ? (int) get_queried_object_id() : 0;

		if ( ! mvweb_core_markup_on( 'site' ) ) {
			return $graph;
		}

		$person = static function ( $id ) {
			$node  = array(
				'@type' => 'Person',
				'@id'   => get_author_posts_url( $id ) . '#person',
				'name'  => (string) get_the_author_meta( 'display_name', $id ),
				'url'   => get_author_posts_url( $id ),
			);
			$bio   = mvweb_core_markup_text( get_the_author_meta( 'description', $id ) );
			$role  = mvweb_core_author_role( $id );
			$photo = mvweb_core_user_photo( $id ) > 0 ? (string) wp_get_attachment_image_url( mvweb_core_user_photo( $id ), 'large' ) : '';
			$same  = array();

			foreach ( mvweb_core_author_links( $id ) as $link ) {
				if ( 0 === strpos( $link['url'], 'http' ) ) {
					$same[] = $link['url'];
				}
			}

			if ( '' !== $bio ) {
				$node['description'] = $bio;
			}

			if ( '' !== $role ) {
				$node['jobTitle'] = $role;
			}

			if ( '' !== $photo ) {
				$node['image'] = $photo;
			}

			if ( ! empty( $same ) ) {
				$node['sameAs'] = array_values( array_unique( $same ) );
			}

			return $node;
		};

		foreach ( $graph as $index => $node ) {
			if ( ! is_array( $node ) || ! isset( $node['@type'] ) ) {
				continue;
			}

			if ( $author > 0 && isset( $node['@id'] ) && $url . '#webpage' === $node['@id'] ) {
				$graph[ $index ]['@type']      = 'ProfilePage';
				$graph[ $index ]['mainEntity'] = array( '@id' => get_author_posts_url( $author ) . '#person' );
			}

			if ( 'Person' === $node['@type'] && isset( $node['url'] ) ) {
				$user = (int) get_post_field( 'post_author', get_queried_object_id() );

				if ( is_singular( 'post' ) && $user > 0 && get_author_posts_url( $user ) === $node['url'] ) {
					$graph[ $index ] = $person( $user );
				}
			}
		}

		if ( $author > 0 ) {
			$graph[] = $person( $author );
		}

		return $graph;
	}
}
add_filter( 'mvweb_core_markup_graph', 'mvweb_core_author_markup', 10, 2 );

if ( ! function_exists( 'mvweb_core_posts_query' ) ) {
	/**
	 * The query of a block of posts by its source; null when the source has nothing to show.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $props   Values of the block.
	 * @param int                 $count   How many posts.
	 * @param int[]               $exclude Optional. Posts shown elsewhere in the block.
	 *
	 * @return WP_Query|null
	 */
	function mvweb_core_posts_query( array $props, $count, array $exclude = array() ) {
		$source  = isset( $props['source'] ) ? (string) $props['source'] : 'latest';
		$count   = max( 1, (int) $count );
		$exclude = array_map( 'absint', $exclude );

		if ( is_singular( 'post' ) ) {
			$exclude[] = (int) get_queried_object_id();
		}

		$exclude = array_values( array_unique( array_diff( $exclude, array( 0 ) ) ) );

		if ( 'sticky' === $source || 'ids' === $source ) {
			$ids = 'sticky' === $source ? (array) get_option( 'sticky_posts', array() ) : wp_parse_id_list( isset( $props['ids'] ) ? (string) $props['ids'] : '' );
			$ids = array_values( array_diff( array_map( 'absint', $ids ), $exclude, array( 0 ) ) );

			if ( empty( $ids ) ) {
				return null;
			}

			$args = array(
				'post_type'           => 'post',
				'post_status'         => 'publish',
				'post__in'            => $ids,
				'posts_per_page'      => $count,
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
				'orderby'             => 'ids' === $source ? 'post__in' : array(
					'date' => 'DESC',
					'ID'   => 'DESC',
				),
			);
		} else {
			$category = isset( $props['category'] ) ? absint( $props['category'] ) : 0;
			$period   = isset( $props['period'] ) ? (string) $props['period'] : ( mvweb_core_views_period_on() ? 'month' : 'all' );

			if ( 'read' === $source && 'all' !== $period && mvweb_core_views_period_on() ) {
				$ids = mvweb_core_views_period_ids(
					$period,
					array(
						'count'    => $count,
						'category' => $category,
						'exclude'  => $exclude,
					)
				);
			} else {
				$args = array(
					'post_type'      => 'post',
					'post_status'    => 'publish',
					'posts_per_page' => $count + count( $exclude ),
					'orderby'        => array(
						'date' => 'DESC',
						'ID'   => 'DESC',
					),
				);

				if ( 'tag' === $source ) {
					$tag = isset( $props['tag'] ) ? absint( $props['tag'] ) : 0;

					if ( 0 === $tag ) {
						return null;
					}

					$args['tag_id'] = $tag;
				} else {
					$args['cat'] = $category;
				}

				if ( in_array( $source, array( 'popular', 'read' ), true ) ) {
					$args = array_merge( $args, mvweb_core_top_args( $source ) );
				}

				$ids = mvweb_core_cached_ids( $args );
			}

			$ids = array_slice( array_values( array_diff( $ids, $exclude ) ), 0, $count );

			if ( empty( $ids ) ) {
				return null;
			}

			$args = mvweb_core_ids_args( $ids );
		}

		$query = new WP_Query( $args );

		if ( ! $query->have_posts() ) {
			return null;
		}

		update_post_thumbnail_cache( $query );

		return $query;
	}
}

if ( ! function_exists( 'mvweb_core_ids_generation' ) ) {
	/**
	 * The mark of the last change of the posts: it is part of the key of every cached list of posts, so a change of a post drops them all.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_ids_generation() {
		return (string) get_option( 'mvweb_core_ids_gen', '0' );
	}
}

if ( ! function_exists( 'mvweb_core_ids_reset' ) ) {
	/**
	 * Drop the cached lists of posts when a post is saved or deleted.
	 *
	 * @since 0.1.0
	 *
	 * @param int          $post_id Post id.
	 * @param WP_Post|null $post    Optional. The post.
	 *
	 * @return void
	 */
	function mvweb_core_ids_reset( $post_id, $post = null ) {
		$type = $post instanceof WP_Post ? $post->post_type : get_post_type( $post_id );

		if ( 'post' !== $type || wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		update_option( 'mvweb_core_ids_gen', (string) microtime( true ), true );
	}
}
add_action( 'save_post', 'mvweb_core_ids_reset', 10, 2 );
add_action( 'deleted_post', 'mvweb_core_ids_reset', 10, 2 );

if ( ! function_exists( 'mvweb_core_cached_ids' ) ) {
	/**
	 * The ids of the posts a query finds, kept for ten minutes in the object cache and in a transient.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $args WP_Query arguments.
	 *
	 * @return int[]
	 */
	function mvweb_core_cached_ids( array $args ) {
		$args = array_merge(
			$args,
			array(
				'fields'              => 'ids',
				'no_found_rows'       => true,
				'ignore_sticky_posts' => true,
			)
		);
		$key  = 'mvweb_ids_' . md5( (string) wp_json_encode( $args ) . '|' . get_locale() . '|' . mvweb_core_ids_generation() );
		$ids  = get_transient( $key );

		if ( ! is_array( $ids ) ) {
			$query = new WP_Query( $args );
			$ids   = array_map( 'intval', $query->posts );

			set_transient( $key, $ids, 10 * MINUTE_IN_SECONDS );
		}

		return array_map( 'intval', $ids );
	}
}

if ( ! function_exists( 'mvweb_core_ids_args' ) ) {
	/**
	 * The query arguments that fetch given published posts in the given order.
	 *
	 * @since 0.1.0
	 *
	 * @param int[] $ids Post ids.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_ids_args( array $ids ) {
		return array(
			'post_type'           => 'post',
			'post_status'         => 'publish',
			'post__in'            => array_map( 'absint', $ids ),
			'orderby'             => 'post__in',
			'posts_per_page'      => count( $ids ),
			'ignore_sticky_posts' => true,
			'no_found_rows'       => true,
		);
	}
}

if ( ! function_exists( 'mvweb_core_posts_link' ) ) {
	/**
	 * Where «All posts» of a block leads when the field is empty: the tag, the category or the blog.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $props Values of the block.
	 *
	 * @return string
	 */
	function mvweb_core_posts_link( array $props ) {
		$source   = isset( $props['source'] ) ? (string) $props['source'] : 'latest';
		$tag      = isset( $props['tag'] ) ? absint( $props['tag'] ) : 0;
		$category = isset( $props['category'] ) ? absint( $props['category'] ) : 0;
		$link     = '';

		if ( 'tag' === $source && $tag > 0 ) {
			$link = get_tag_link( $tag );
		} elseif ( in_array( $source, array( 'latest', 'popular', 'read' ), true ) && $category > 0 ) {
			$link = get_category_link( $category );
		} else {
			$link = mvweb_core_blog_url();
		}

		return is_string( $link ) ? $link : '';
	}
}

if ( ! function_exists( 'mvweb_core_flag_kinds' ) ) {
	/**
	 * The marks a post can carry in the feeds: urgent, important, partner material.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Kind => label.
	 */
	function mvweb_core_flag_kinds() {
		$list = array(
			'urgent'  => __( 'Urgent', 'mvweb-core' ),
			'key'     => __( 'Important', 'mvweb-core' ),
			'partner' => __( 'Partner material', 'mvweb-core' ),
		);

		/**
		 * Filter the marks of a post: kind => label.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $list
		 */
		return (array) apply_filters( 'mvweb_core_flag_kinds', $list );
	}
}

if ( ! function_exists( 'mvweb_core_flag_meta' ) ) {
	/**
	 * Register the mark of a post and its own text.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_flag_meta() {
		$auth = static function ( $allowed, $meta_key, $post_id ) {
			unset( $allowed, $meta_key );

			return current_user_can( 'edit_post', $post_id );
		};

		register_post_meta(
			'post',
			'_mvweb_flag',
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => static function ( $value ) {
					return is_string( $value ) && isset( mvweb_core_flag_kinds()[ $value ] ) ? $value : '';
				},
				'auth_callback'     => $auth,
				'show_in_rest'      => false,
			)
		);

		register_post_meta(
			'post',
			'_mvweb_flag_text',
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => $auth,
				'show_in_rest'      => false,
			)
		);
	}
}
add_action( 'init', 'mvweb_core_flag_meta' );

if ( ! function_exists( 'mvweb_core_flag_box' ) ) {
	/**
	 * The box «Mark» beside the post editor.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_flag_box() {
		add_meta_box(
			'mvweb-flag',
			__( 'Mark', 'mvweb-core' ),
			static function ( $post ) {
				$kind = (string) get_post_meta( $post->ID, '_mvweb_flag', true );

				wp_nonce_field( 'mvweb_flag', 'mvweb_flag_nonce' );
				?>
				<p>
					<label for="mvweb-flag"><?php esc_html_e( 'Mark in the feeds and on the cards', 'mvweb-core' ); ?></label>
					<select class="widefat" id="mvweb-flag" name="mvweb_flag">
						<option value=""><?php esc_html_e( 'None', 'mvweb-core' ); ?></option>
						<?php foreach ( mvweb_core_flag_kinds() as $value => $label ) : ?>
							<option value="<?php echo esc_attr( $value ); ?>"<?php selected( $kind, $value ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</p>
				<p>
					<label for="mvweb-flag-text"><?php esc_html_e( 'Own text of the mark', 'mvweb-core' ); ?></label>
					<input class="widefat" type="text" id="mvweb-flag-text" name="mvweb_flag_text" value="<?php echo esc_attr( (string) get_post_meta( $post->ID, '_mvweb_flag_text', true ) ); ?>">
					<span class="description"><?php esc_html_e( 'Empty: the name of the mark. For a partner material, for example: Advertisement. Advertiser LLC «Name», INN 0000000000.', 'mvweb-core' ); ?></span>
				</p>
				<?php
			},
			'post',
			'side'
		);
	}
}
add_action( 'add_meta_boxes_post', 'mvweb_core_flag_box' );

if ( ! function_exists( 'mvweb_core_flag_save' ) ) {
	/**
	 * Save the mark of a post.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Post id.
	 *
	 * @return void
	 */
	function mvweb_core_flag_save( $post_id ) {
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST['mvweb_flag_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mvweb_flag_nonce'] ) ), 'mvweb_flag' ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$kind = isset( $_POST['mvweb_flag'] ) ? sanitize_key( wp_unslash( $_POST['mvweb_flag'] ) ) : '';
		$text = isset( $_POST['mvweb_flag_text'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_flag_text'] ) ) : '';

		if ( isset( mvweb_core_flag_kinds()[ $kind ] ) ) {
			update_post_meta( $post_id, '_mvweb_flag', $kind );
		} else {
			delete_post_meta( $post_id, '_mvweb_flag' );
		}

		if ( '' !== $text ) {
			update_post_meta( $post_id, '_mvweb_flag_text', $text );
		} else {
			delete_post_meta( $post_id, '_mvweb_flag_text' );
		}
	}
}
add_action( 'save_post_post', 'mvweb_core_flag_save' );

if ( ! function_exists( 'mvweb_core_post_flag' ) ) {
	/**
	 * The mark of a post: kind and text; an empty kind when the post has none.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Optional. Post id; the current post by default.
	 *
	 * @return array{kind:string,label:string}
	 */
	function mvweb_core_post_flag( $post_id = 0 ) {
		$post_id = $post_id ? (int) $post_id : (int) get_the_ID();
		$kind    = (string) get_post_meta( $post_id, '_mvweb_flag', true );
		$kinds   = mvweb_core_flag_kinds();

		if ( ! isset( $kinds[ $kind ] ) ) {
			return array(
				'kind'  => '',
				'label' => '',
			);
		}

		$text = trim( (string) get_post_meta( $post_id, '_mvweb_flag_text', true ) );

		return array(
			'kind'  => $kind,
			'label' => '' !== $text ? $text : $kinds[ $kind ],
		);
	}
}

if ( ! function_exists( 'mvweb_core_day_groups' ) ) {
	/**
	 * The posts of a query grouped by the day of publishing, in the order of the query.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post[] $posts Posts.
	 *
	 * @return array<int,array{day:string,week:string,stamp:int,posts:WP_Post[]}>
	 */
	function mvweb_core_day_groups( array $posts ) {
		$groups = array();

		foreach ( $posts as $post ) {
			$stamp = (int) get_post_time( 'U', true, $post );
			$key   = wp_date( 'Y-m-d', $stamp );

			if ( ! isset( $groups[ $key ] ) ) {
				$groups[ $key ] = array(
					'day'   => wp_date( wp_date( 'Y', $stamp ) === wp_date( 'Y' ) ? 'j F' : 'j F Y', $stamp ),
					'week'  => mb_strtolower( (string) wp_date( 'l', $stamp ) ),
					'stamp' => $stamp,
					'posts' => array(),
				);
			}

			$groups[ $key ]['posts'][] = $post;
		}

		return array_values( $groups );
	}
}

if ( ! function_exists( 'mvweb_core_blog_views' ) ) {
	/**
	 * The looks of the list of posts on the blog, a category, a tag, an author and a date.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Value => label.
	 */
	function mvweb_core_blog_views() {
		$support = get_theme_support( 'mvweb-blog-views' );
		$wanted  = is_array( $support ) && isset( $support[0] ) ? array_map( 'strval', (array) $support[0] ) : array();
		$list    = array_merge(
			array(
				'grid'    => __( 'Grid of cards', 'mvweb-core' ),
				'journal' => __( 'Magazine: the first post large, a grid under it', 'mvweb-core' ),
				'feed'    => __( 'Feed by days with pictures', 'mvweb-core' ),
			),
			mvweb_core_masonry_views(),
			array_intersect_key(
				array(
					'rows' => __( 'Rows: the picture on the left, the text on the right', 'mvweb-core' ),
					'text' => __( 'Text list without pictures', 'mvweb-core' ),
				),
				array_flip( $wanted )
			)
		);

		/**
		 * Filter the looks of the list of posts: key => label; a theme renames the looks it draws.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $list
		 */
		return (array) apply_filters( 'mvweb_core_blog_views', $list );
	}
}

if ( ! function_exists( 'mvweb_core_blog_view' ) ) {
	/**
	 * The look of the list of posts chosen in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_blog_view() {
		$views = mvweb_core_blog_views();
		$first = (string) array_key_first( $views );
		$view  = (string) get_theme_mod( 'mvweb_blog_list_view', $first );

		return isset( $views[ $view ] ) ? $view : $first;
	}
}

if ( ! function_exists( 'mvweb_core_blog_view_field' ) ) {
	/**
	 * The field «Look of the list» in the section of the list of articles.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_blog_view_field( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_blog_list_view',
					'section'     => 'mvweb_cz_inner_archive',
					'label'       => __( 'Look of the list of posts', 'mvweb-core' ),
					'description' => __( 'On the blog page, in the categories, tags, the pages of the authors and the archive by dates.', 'mvweb-core' ),
					'default'     => (string) array_key_first( mvweb_core_blog_views() ),
					'choices'     => mvweb_core_blog_views(),
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_blog_view_field' );

if ( ! function_exists( 'mvweb_core_query_of' ) ) {
	/**
	 * A query that walks over given posts without asking the database again.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post[] $posts Posts.
	 *
	 * @return WP_Query
	 */
	function mvweb_core_query_of( array $posts ) {
		$query             = new WP_Query();
		$query->posts      = array_values( $posts );
		$query->post_count = count( $query->posts );

		return $query;
	}
}

if ( ! function_exists( 'mvweb_core_blog_order_field' ) ) {
	/**
	 * The field «Order of the posts» in the section of the list of articles.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_blog_order_field( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_blog_order',
					'section'     => 'mvweb_cz_inner_archive',
					'label'       => __( 'Order of the posts', 'mvweb-core' ),
					'description' => __( 'On the blog page, in the categories and the tags. By hand: the field «Order» in the box «Post attributes» of the post editor, smaller first.', 'mvweb-core' ),
					'default'     => 'date',
					'choices'     => array(
						'date'   => __( 'Newest first', 'mvweb-core' ),
						'title'  => __( 'By the title', 'mvweb-core' ),
						'manual' => __( 'By hand', 'mvweb-core' ),
					),
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_blog_order_field' );

if ( ! function_exists( 'mvweb_core_blog_order' ) ) {
	/**
	 * The order of the posts chosen in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_blog_order() {
		$order = (string) get_theme_mod( 'mvweb_blog_order', 'date' );

		return in_array( $order, array( 'date', 'title', 'manual' ), true ) ? $order : 'date';
	}
}

if ( ! function_exists( 'mvweb_core_blog_order_support' ) ) {
	/**
	 * The field «Order» in the post editor, only when the posts are ordered by hand.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_blog_order_support() {
		if ( 'manual' === mvweb_core_blog_order() ) {
			add_post_type_support( 'post', 'page-attributes' );
		}
	}
}
add_action( 'init', 'mvweb_core_blog_order_support' );

if ( ! function_exists( 'mvweb_core_blog_order_query' ) ) {
	/**
	 * Order the posts of the blog page, a category and a tag as the Customizer says; the feed by days keeps the order of the dates and the pinned posts in their day.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Query being prepared.
	 *
	 * @return void
	 */
	function mvweb_core_blog_order_query( $query ) {
		if ( is_admin() || ! $query->is_main_query() || ! ( $query->is_home() || $query->is_category() || $query->is_tag() ) ) {
			return;
		}

		$order = mvweb_core_blog_order();

		if ( 'feed' === mvweb_core_blog_view() ) {
			$query->set( 'ignore_sticky_posts', true );

			return;
		}

		if ( 'date' !== $order ) {
			$query->set( 'orderby', mvweb_core_blog_orderby() );
		}
	}
}
add_action( 'pre_get_posts', 'mvweb_core_blog_order_query' );

if ( ! function_exists( 'mvweb_core_short_date' ) ) {
	/**
	 * The date of the current post without the year, with the year when it is not this year.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_short_date() {
		return get_the_date( get_the_date( 'Y' ) === wp_date( 'Y' ) ? 'j F' : 'j F Y' );
	}
}

if ( ! function_exists( 'mvweb_core_blog_cats_block' ) ) {
	/**
	 * Register the block «Blog categories».
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_blog_cats_block() {
		mvweb_core_register_section(
			'blog-cats',
			array(
				'label'       => __( 'Blog categories', 'mvweb-core' ),
				'description' => __( 'The categories of the blog with their subcategories and articles', 'mvweb-core' ),
				'category'    => 'about',
				'fields'      => array(
					'kicker'    => array(
						'type'  => 'text',
						'label' => __( 'Line above the heading', 'mvweb-core' ),
					),
					'title'     => array(
						'type'  => 'text',
						'label' => __( 'Heading', 'mvweb-core' ),
					),
					'text'      => array(
						'type'  => 'textarea',
						'label' => __( 'Text under the heading', 'mvweb-core' ),
					),
					'category'  => array(
						'type'        => 'category',
						'label'       => __( 'Categories inside', 'mvweb-core' ),
						'description' => __( 'All categories: the categories of the top level.', 'mvweb-core' ),
						'default'     => 0,
					),
					'ids'       => array(
						'type'        => 'text',
						'label'       => __( 'Categories chosen by hand', 'mvweb-core' ),
						'description' => __( 'Numbers of the categories separated by commas, in the order of showing. The number is in the address of the category editor: tag_ID=12. Empty: the categories of the field above.', 'mvweb-core' ),
					),
					'order'     => array(
						'type'    => 'select',
						'label'   => __( 'Order of the categories', 'mvweb-core' ),
						'choices' => array(
							'count' => __( 'More articles first', 'mvweb-core' ),
							'name'  => __( 'By the name', 'mvweb-core' ),
						),
						'default' => 'count',
					),
					'count'     => array(
						'type'    => 'number',
						'label'   => _x( 'How many categories', 'blog', 'mvweb-core' ),
						'min'     => 1,
						'max'     => 24,
						'default' => 8,
					),
					'posts'     => array(
						'type'    => 'number',
						'label'   => __( 'Articles of a category', 'mvweb-core' ),
						'min'     => 3,
						'max'     => 5,
						'default' => 4,
					),
					'top_label' => array(
						'type'        => 'text',
						'label'       => __( 'Heading of the list of articles', 'mvweb-core' ),
						'description' => __( 'The most read articles come first when the views are counted, otherwise the most discussed.', 'mvweb-core' ),
						'default'     => __( 'Start with these articles', 'mvweb-core' ),
					),
					'link_text' => array(
						'type'    => 'text',
						'label'   => __( 'Link to all posts', 'mvweb-core' ),
						'default' => __( 'All posts', 'mvweb-core' ),
					),
					'link_url'  => array(
						'type'        => 'url',
						'label'       => __( 'Where the link leads', 'mvweb-core' ),
						'description' => __( 'Empty leads to the blog.', 'mvweb-core' ),
					),
				),
			)
		);
	}
}
add_action( 'mvweb_core_register_sections', 'mvweb_core_blog_cats_block' );

if ( ! function_exists( 'mvweb_core_blog_terms' ) ) {
	/**
	 * Every blog category with articles, the counts with the articles of the subcategories; a list by hand takes any of them.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,WP_Term> Term id => term, by the name.
	 */
	function mvweb_core_blog_terms() {
		static $terms = null;

		if ( null !== $terms ) {
			return $terms;
		}

		$terms = array();
		$found = get_terms(
			array(
				'taxonomy'   => 'category',
				'hide_empty' => true,
				'pad_counts' => true,
			)
		);

		foreach ( is_array( $found ) ? $found : array() as $term ) {
			$terms[ (int) $term->term_id ] = $term;
		}

		return $terms;
	}
}

if ( ! function_exists( 'mvweb_core_blog_children' ) ) {
	/**
	 * The blog categories with articles right inside a category, without the default category of WordPress.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $term_id Term id; 0 for the top level.
	 * @param string $order   Optional. count (more articles first) or name.
	 *
	 * @return WP_Term[]
	 */
	function mvweb_core_blog_children( $term_id, $order = 'name' ) {
		$children = array();
		$default  = (int) get_option( 'default_category' );

		foreach ( mvweb_core_blog_terms() as $term ) {
			if ( (int) $term->parent === (int) $term_id && (int) $term->term_id !== $default ) {
				$children[] = $term;
			}
		}

		if ( 'count' === $order ) {
			usort(
				$children,
				static function ( $a, $b ) {
					return (int) $b->count <=> (int) $a->count;
				}
			);
		}

		return $children;
	}
}

if ( ! function_exists( 'mvweb_core_blog_cats_terms' ) ) {
	/**
	 * The categories a block of blog categories shows.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $props Values of the block.
	 *
	 * @return WP_Term[]
	 */
	function mvweb_core_blog_cats_terms( array $props ) {
		$all   = mvweb_core_blog_terms();
		$count = isset( $props['count'] ) ? max( 1, min( 24, absint( $props['count'] ) ) ) : 8;
		$ids   = wp_parse_id_list( isset( $props['ids'] ) ? (string) $props['ids'] : '' );
		$terms = array();

		if ( ! empty( $ids ) ) {
			foreach ( $ids as $id ) {
				if ( isset( $all[ $id ] ) ) {
					$terms[] = $all[ $id ];
				}
			}
		} else {
			$terms = mvweb_core_blog_children( isset( $props['category'] ) ? absint( $props['category'] ) : 0, isset( $props['order'] ) ? (string) $props['order'] : 'count' );
		}

		return array_slice( $terms, 0, $count );
	}
}

if ( ! function_exists( 'mvweb_core_blog_orderby' ) ) {
	/**
	 * The order of the posts of the blog as the Customizer says, for WP_Query.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_blog_orderby() {
		$order = mvweb_core_blog_order();

		if ( 'title' === $order ) {
			return array( 'title' => 'ASC' );
		}

		if ( 'manual' === $order ) {
			return array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			);
		}

		return array(
			'date' => 'DESC',
			'ID'   => 'DESC',
		);
	}
}

if ( ! function_exists( 'mvweb_core_blog_cat_posts' ) ) {
	/**
	 * The articles of a blog category with its subcategories.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $term_id Term id.
	 * @param int    $count   How many.
	 * @param bool   $popular Optional. The most read or the most discussed first.
	 * @param string $period  Optional. For the most read: today, week, month, year or all.
	 *
	 * @return WP_Post[]
	 */
	function mvweb_core_blog_cat_posts( $term_id, $count, $popular = false, $period = 'all' ) {
		$count = max( 1, (int) $count );

		if ( $popular && 'read' === mvweb_core_top_by() && 'all' !== $period && mvweb_core_views_period_on() ) {
			$ids = mvweb_core_views_period_ids(
				$period,
				array(
					'count'    => $count,
					'category' => (int) $term_id,
				)
			);
		} else {
			$ids = mvweb_core_cached_ids(
				array_merge(
					array(
						'post_type'      => 'post',
						'post_status'    => 'publish',
						'cat'            => (int) $term_id,
						'posts_per_page' => $count,
						'orderby'        => mvweb_core_blog_orderby(),
					),
					$popular ? mvweb_core_top_args( mvweb_core_top_by() ) : array()
				)
			);
		}

		if ( empty( $ids ) ) {
			return array();
		}

		$query = new WP_Query( mvweb_core_ids_args( $ids ) );

		update_post_thumbnail_cache( $query );

		return $query->posts;
	}
}

if ( ! function_exists( 'mvweb_core_term_lead' ) ) {
	/**
	 * The first sentence of the description of a term, plain text.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Term.
	 *
	 * @return string
	 */
	function mvweb_core_term_lead( $term ) {
		$text = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $term->description ) ) );

		if ( preg_match( '/^.+?[.!?](?=\s|$)/u', $text, $match ) ) {
			return $match[0];
		}

		return $text;
	}
}

if ( ! function_exists( 'mvweb_core_term_picture' ) ) {
	/**
	 * The picture of a term; empty when it has none.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Term.
	 * @param string  $size Image size.
	 *
	 * @return string
	 */
	function mvweb_core_term_picture( $term, $size ) {
		$id = absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) );

		return wp_attachment_is_image( $id ) ? (string) wp_get_attachment_image(
			$id,
			$size,
			false,
			array(
				'alt'      => '',
				'loading'  => 'lazy',
				'decoding' => 'async',
			)
		) : '';
	}
}

if ( ! function_exists( 'mvweb_core_term_icon' ) ) {
	/**
	 * The icon of a term from the set of the theme, a page with lines when it has none.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Term.
	 *
	 * @return string Icon name.
	 */
	function mvweb_core_term_icon( $term ) {
		$icon = sanitize_key( (string) get_term_meta( $term->term_id, 'mvweb_icon', true ) );

		return '' !== $icon ? $icon : 'file-text';
	}
}

if ( ! function_exists( 'mvweb_core_articles' ) ) {
	/**
	 * «N articles» with the number in the words of the language.
	 *
	 * @since 0.1.0
	 *
	 * @param int $count Number of articles.
	 *
	 * @return string
	 */
	function mvweb_core_articles( $count ) {
		/* translators: %s: number of articles. */
		return sprintf( _n( '%s article', '%s articles', (int) $count, 'mvweb-core' ), number_format_i18n( (int) $count ) );
	}
}

if ( ! function_exists( 'mvweb_core_blog_subcats_views' ) ) {
	/**
	 * The looks of the subcategories above the posts of a blog category.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Value => label.
	 */
	function mvweb_core_blog_subcats_views() {
		$list = array(
			'none'    => __( 'None: the strip of all categories of the blog', 'mvweb-core' ),
			'more'    => __( 'Pills with the number of articles', 'mvweb-core' ),
			'cards'   => __( 'Tiles with an icon or a picture and a description', 'mvweb-core' ),
			'toc'     => __( 'Contents: the subcategories with their articles', 'mvweb-core' ),
			'rail'    => __( 'Ribbon of photos that scrolls sideways', 'mvweb-core' ),
			'columns' => __( 'Columns of links', 'mvweb-core' ),
			'button'  => __( '“Subcategories” button: the list opens on a click', 'mvweb-core' ),
		);

		/**
		 * Filter the looks of the subcategories of a blog category: key => label.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $list
		 */
		return (array) apply_filters( 'mvweb_core_blog_subcats_views', $list );
	}
}

if ( ! function_exists( 'mvweb_core_blog_subcats_view' ) ) {
	/**
	 * The look of the subcategories chosen in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_blog_subcats_view() {
		$view = (string) get_theme_mod( 'mvweb_blog_subcats_view', 'none' );

		return isset( mvweb_core_blog_subcats_views()[ $view ] ) ? $view : 'none';
	}
}

if ( ! function_exists( 'mvweb_core_blog_subcats' ) ) {
	/**
	 * The subcategories of the blog category being shown, as the tiles of the template of the subcategories; empty on the next pages and with the look «None».
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_blog_subcats() {
		static $tiles = null;

		if ( null !== $tiles ) {
			return $tiles;
		}

		$tiles = array();
		$view  = mvweb_core_blog_subcats_view();

		if ( 'none' === $view || ! is_category() || is_paged() ) {
			return $tiles;
		}

		$posts = 'toc' === $view ? min( 5, max( 2, absint( get_theme_mod( 'mvweb_blog_subcats_posts', 3 ) ) ) ) : 0;

		foreach ( mvweb_core_blog_children( get_queried_object_id(), 'count' ) as $term ) {
			$url = get_term_link( $term );

			if ( is_wp_error( $url ) ) {
				continue;
			}

			$tiles[] = array(
				'image' => wp_attachment_is_image( absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) ) ) ? absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) ) : 0,
				'icon'  => mvweb_core_term_icon( $term ),
				'desc'  => mvweb_core_term_lead( $term ),
				'title' => $term->name,
				'url'   => $url,
				'count' => (int) $term->count,
				'posts' => $posts > 0 ? mvweb_core_blog_cat_posts( $term->term_id, $posts ) : array(),
			);
		}

		return $tiles;
	}
}

if ( ! function_exists( 'mvweb_core_blog_subcats_fields' ) ) {
	/**
	 * The fields of the subcategories in the section of the list of articles.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_blog_subcats_fields( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_blog_subcats_view',
					'section'     => 'mvweb_cz_inner_archive',
					'label'       => __( 'Subcategories of a category', 'mvweb-core' ),
					'description' => __( 'Above the posts of a category that has subcategories with articles, on its first page. A category without them keeps the strip of all categories.', 'mvweb-core' ),
					'default'     => 'none',
					'choices'     => mvweb_core_blog_subcats_views(),
				),
				array(
					'type'        => 'number',
					'settings'    => 'mvweb_blog_subcats_posts',
					'section'     => 'mvweb_cz_inner_archive',
					'label'       => __( 'Articles under a subcategory', 'mvweb-core' ),
					'default'     => 3,
					'input_attrs' => array(
						'min'  => 2,
						'max'  => 5,
						'step' => 1,
					),
					'required'    => array(
						array(
							'setting'  => 'mvweb_blog_subcats_view',
							'operator' => '==',
							'value'    => 'toc',
						),
					),
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_blog_subcats_fields' );

if ( ! function_exists( 'mvweb_core_blog_cats_widget' ) ) {
	/**
	 * The widget «Blog categories»: the tree of the categories of the blog.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $kinds Kinds by key.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_blog_cats_widget( $kinds ) {
		$kinds['blog_cats'] = array(
			'name'        => __( 'MVweb: Blog categories', 'mvweb-core' ),
			'description' => __( 'The tree of the blog categories with the number of articles.', 'mvweb-core' ),
			'template'    => 'tree',
			'data'        => 'mvweb_core_widget_blog_cats',
			'fields'      => array(
				'hub'         => array(
					'type'    => 'checkbox',
					'label'   => __( 'In a category, only its top category and what is inside', 'mvweb-core' ),
					'default' => true,
				),
				'only_branch' => array(
					'type'    => 'checkbox',
					'label'   => _x( 'Open only the branch of the current category', 'blog', 'mvweb-core' ),
					'default' => true,
				),
			),
			'parts'       => array(
				'name'  => array(
					'label'  => __( 'Category name', 'mvweb-core' ),
					'locked' => true,
				),
				'count' => __( 'Number of articles', 'mvweb-core' ),
			),
		);

		return $kinds;
	}
}
add_filter( 'mvweb_core_widget_kinds', 'mvweb_core_blog_cats_widget' );

if ( ! function_exists( 'mvweb_core_widget_blog_cats' ) ) {
	/**
	 * Data of the widget of the blog categories: three levels, the branch of the current category open.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $instance Saved values.
	 * @param string[]            $parts    Parts in print order.
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_widget_blog_cats( array $instance, array $parts ) {
		$all     = mvweb_core_blog_terms();
		$current = is_category() ? (int) get_queried_object_id() : 0;

		if ( 0 === $current && is_singular( 'post' ) ) {
			$cats    = get_the_category( get_queried_object_id() );
			$current = empty( $cats ) ? 0 : (int) $cats[0]->term_id;
		}

		$trail = $current > 0 ? array_merge( array( $current ), array_map( 'intval', get_ancestors( $current, 'category', 'taxonomy' ) ) ) : array();
		$count = in_array( 'count', $parts, true );
		$open  = empty( $instance['only_branch'] );

		$row = static function ( $term, $depth ) use ( &$row, $current, $trail, $count, $open ) {
			$url = get_term_link( $term );

			if ( is_wp_error( $url ) ) {
				return null;
			}

			$children = array();

			if ( $depth < 3 ) {
				foreach ( mvweb_core_blog_children( $term->term_id ) as $kid ) {
					$child = $row( $kid, $depth + 1 );

					if ( null !== $child ) {
						$children[] = $child;
					}
				}
			}

			return array(
				'id'       => (int) $term->term_id,
				'url'      => $url,
				'name'     => $term->name,
				'count'    => $count ? (int) $term->count : null,
				'current'  => (int) $term->term_id === $current,
				'open'     => $open || in_array( (int) $term->term_id, $trail, true ),
				'children' => $children,
			);
		};

		$top  = ! empty( $instance['hub'] ) && ! empty( $trail ) && isset( $all[ (int) end( $trail ) ] ) ? array( $all[ (int) end( $trail ) ] ) : mvweb_core_blog_children( 0 );
		$rows = array();

		foreach ( $top as $term ) {
			$item = $row( $term, 1 );

			if ( null !== $item ) {
				$rows[] = $item;
			}
		}

		return empty( $rows ) ? null : array( 'rows' => $rows );
	}
}

if ( ! function_exists( 'mvweb_core_author_widget' ) ) {
	/**
	 * The widget «Author», when the theme asks for it with add_theme_support( 'mvweb-widget-author' ).
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $kinds Kinds by key.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_author_widget( $kinds ) {
		if ( ! current_theme_supports( 'mvweb-widget-author' ) ) {
			return $kinds;
		}

		$kinds['author'] = array(
			'name'        => __( 'MVweb: Author', 'mvweb-core' ),
			'description' => __( 'The card of the author of the article or of the author page being read.', 'mvweb-core' ),
			'template'    => 'author',
			'data'        => 'mvweb_core_widget_author',
			'ordered'     => true,
			'parts'       => array(
				'photo' => __( 'Photo', 'mvweb-core' ),
				'name'  => array(
					'label'  => __( 'Name', 'mvweb-core' ),
					'locked' => true,
				),
				'role'  => __( 'Position', 'mvweb-core' ),
				'bio'   => __( 'Description', 'mvweb-core' ),
				'links' => __( 'Links', 'mvweb-core' ),
			),
		);

		return $kinds;
	}
}
add_filter( 'mvweb_core_widget_kinds', 'mvweb_core_author_widget' );

if ( ! function_exists( 'mvweb_core_widget_author' ) ) {
	/**
	 * Data of the widget of the author: the author of the article, or the author whose page is open.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $instance Saved values.
	 * @param string[]            $parts    Parts in print order.
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_widget_author( array $instance, array $parts ) {
		unset( $instance );

		if ( is_author() ) {
			$user = (int) get_queried_object_id();
		} elseif ( is_singular( 'post' ) ) {
			$user = (int) get_post_field( 'post_author', get_queried_object_id() );
		} else {
			$user = 0;
		}

		$name = $user > 0 ? trim( (string) get_the_author_meta( 'display_name', $user ) ) : '';

		if ( '' === $name ) {
			return null;
		}

		return array(
			'author' => $user,
			'name'   => $name,
			'url'    => is_author() ? '' : get_author_posts_url( $user ),
			'role'   => in_array( 'role', $parts, true ) ? mvweb_core_author_role( $user ) : '',
			'bio'    => in_array( 'bio', $parts, true ) ? trim( (string) get_the_author_meta( 'description', $user ) ) : '',
			'links'  => in_array( 'links', $parts, true ) ? mvweb_core_author_links( $user ) : array(),
		);
	}
}

if ( ! function_exists( 'mvweb_core_category_fields' ) ) {
	/**
	 * The picture and the icon of a blog category: the fields of the core on the screens of the categories.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_category_fields() {
		add_action( 'category_add_form_fields', 'mvweb_core_term_image_field' );
		add_action( 'category_edit_form_fields', 'mvweb_core_term_image_edit_field' );
		add_action( 'created_category', 'mvweb_core_term_image_save' );
		add_action( 'edited_category', 'mvweb_core_term_image_save' );
		add_action( 'category_add_form_fields', 'mvweb_core_service_icon_field' );
		add_action( 'category_edit_form_fields', 'mvweb_core_service_icon_field' );
		add_action( 'created_category', 'mvweb_core_service_icon_save' );
		add_action( 'edited_category', 'mvweb_core_service_icon_save' );
	}
}
add_action( 'init', 'mvweb_core_category_fields', 30 );

if ( ! function_exists( 'mvweb_core_category_media' ) ) {
	/**
	 * The media picker of the core on the screens of the blog categories.
	 *
	 * @since 0.1.0
	 *
	 * @param string $hook Current admin screen.
	 *
	 * @return void
	 */
	function mvweb_core_category_media( $hook ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		if ( ! in_array( $hook, array( 'edit-tags.php', 'term.php' ), true ) || ! $screen || 'category' !== $screen->taxonomy ) {
			return;
		}

		wp_enqueue_media();

		$relative = mvweb_core_asset_path( '/admin/js/media-field.js' );

		wp_enqueue_script( 'mvweb-core-media-field', MVWEB_CORE_URI . $relative, array( 'media-editor' ), mvweb_core_asset_version( $relative ), true );

		mvweb_core_admin_style();
	}
}
add_action( 'admin_enqueue_scripts', 'mvweb_core_category_media' );

if ( ! function_exists( 'mvweb_core_masonry_views' ) ) {
	/**
	 * The masonry looks of a list of posts.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Value => label.
	 */
	function mvweb_core_masonry_views() {
		$list = array(
			'wall'    => __( 'Masonry: cards of any height without gaps', 'mvweb-core' ),
			'columns' => __( 'Masonry in columns: the posts run down the columns, no loading', 'mvweb-core' ),
			'photos'  => __( 'Photo rows: the pictures whole, rows of one height', 'mvweb-core' ),
			'rhythm'  => __( 'Rhythm of large, middle and small cards', 'mvweb-core' ),
		);

		/**
		 * Filter the masonry looks of a list of posts: key => label.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $list
		 */
		return (array) apply_filters( 'mvweb_core_masonry_views', $list );
	}
}

if ( ! function_exists( 'mvweb_core_home_modes' ) ) {
	/**
	 * The looks of the homepage: the blocks of the builder or a feed of posts.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Value => label.
	 */
	function mvweb_core_home_modes() {
		$list = array_merge(
			array(
				'blocks'  => __( 'Blocks of the homepage', 'mvweb-core' ),
				'cards'   => __( 'Feed of large cards in one column', 'mvweb-core' ),
				'inserts' => __( 'Grid of posts with the most discussed in between', 'mvweb-core' ),
				'days'    => __( 'Feed by days', 'mvweb-core' ),
				'side'    => __( 'Feed and a column of widgets beside it', 'mvweb-core' ),
				'top'     => __( 'Blocks of the homepage on top, the feed under them', 'mvweb-core' ),
			),
			mvweb_core_masonry_views()
		);

		/**
		 * Filter the looks of the homepage: key => label.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $list
		 */
		return (array) apply_filters( 'mvweb_core_home_modes', $list );
	}
}

if ( ! function_exists( 'mvweb_core_home_mode' ) ) {
	/**
	 * The look of the homepage chosen in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_home_mode() {
		$mode = (string) get_theme_mod( 'mvweb_home_mode', 'blocks' );

		return isset( mvweb_core_home_modes()[ $mode ] ) ? $mode : 'blocks';
	}
}

if ( ! function_exists( 'mvweb_core_stream_more' ) ) {
	/**
	 * How the next page of a list loads: -1 numbered pages only, 0 the button only, N pages by themselves and then the button.
	 *
	 * @since 0.1.0
	 *
	 * @return int
	 */
	function mvweb_core_stream_more() {
		$more = (string) get_theme_mod( 'mvweb_stream_more', 'off' );

		return in_array( $more, array( '0', '1', '3', '5' ), true ) ? (int) $more : -1;
	}
}

if ( ! function_exists( 'mvweb_core_stream_fields' ) ) {
	/**
	 * The look of the homepage and the loading of the next page.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_stream_fields( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_home_mode',
					'section'     => 'mvweb_cz_home_blocks',
					'label'       => __( 'Look of the homepage', 'mvweb-core' ),
					'description' => __( 'A feed shows the latest posts with numbered pages. How the next page loads: «Blog: list of articles», the field «Loading of the next page».', 'mvweb-core' ),
					'default'     => 'blocks',
					'choices'     => mvweb_core_home_modes(),
					'priority'    => 5,
				),
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_stream_more',
					'section'     => 'mvweb_cz_inner_archive',
					'label'       => __( 'Loading of the next page', 'mvweb-core' ),
					'description' => __( 'In the lists of the blog and in the feed of the homepage. The numbered pages stay under the list for the search engines and for visitors without scripts.', 'mvweb-core' ),
					'default'     => 'off',
					'choices'     => array(
						'off' => __( 'Numbered pages only', 'mvweb-core' ),
						'0'   => __( 'The button «Show more»', 'mvweb-core' ),
						'1'   => __( 'One page by itself, then the button', 'mvweb-core' ),
						'3'   => __( 'Three pages by themselves, then the button', 'mvweb-core' ),
						'5'   => __( 'Five pages by themselves, then the button', 'mvweb-core' ),
					),
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_stream_fields' );

if ( ! function_exists( 'mvweb_core_home_stream_on' ) ) {
	/**
	 * Whether the homepage being shown is a feed of posts.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_home_stream_on() {
		return is_front_page() && 'blocks' !== mvweb_core_home_mode();
	}
}

if ( ! function_exists( 'mvweb_core_home_top_ids' ) ) {
	/**
	 * The posts the blocks above the feed show by number: the pinned ones and the lists by hand. The feed leaves them out on every page.
	 *
	 * @since 0.1.0
	 *
	 * @return int[]
	 */
	function mvweb_core_home_top_ids() {
		if ( 'top' !== mvweb_core_home_mode() || ! function_exists( 'mvweb_core_home_sections' ) ) {
			return array();
		}

		$ids = array();

		foreach ( (array) mvweb_core_home_sections() as $row ) {
			if ( ! is_array( $row ) || ! isset( $row['type'] ) || ! in_array( $row['type'], mvweb_core_posts_types(), true ) || ! empty( $row['hidden'] ) ) {
				continue;
			}

			$props  = isset( $row['props'] ) && is_array( $row['props'] ) ? $row['props'] : array();
			$source = isset( $props['source'] ) ? (string) $props['source'] : 'latest';

			if ( 'sticky' === $source ) {
				$ids = array_merge( $ids, (array) get_option( 'sticky_posts', array() ) );
			} elseif ( 'ids' === $source ) {
				$ids = array_merge( $ids, wp_parse_id_list( isset( $props['ids'] ) ? (string) $props['ids'] : '' ) );
			}
		}

		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_home_page' ) ) {
	/**
	 * The number of the page of the feed of the homepage: WordPress keeps it as page when the homepage is a page.
	 *
	 * @since 0.1.0
	 *
	 * @return int
	 */
	function mvweb_core_home_page() {
		return max( 1, absint( get_query_var( 'paged' ) ), absint( get_query_var( 'page' ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_home_stream_query' ) ) {
	/**
	 * The posts of the feed of the homepage: the main query when the homepage shows the latest posts, an own query when it is a page.
	 *
	 * @since 0.1.0
	 *
	 * @return WP_Query|null
	 */
	function mvweb_core_home_stream_query() {
		static $query = false;

		if ( false !== $query ) {
			return $query;
		}

		if ( ! mvweb_core_home_stream_on() ) {
			$query = null;

			return $query;
		}

		if ( 'page' !== get_option( 'show_on_front' ) ) {
			$query = $GLOBALS['wp_query'];

			return $query;
		}

		$query = new WP_Query(
			array(
				'post_type'           => 'post',
				'post_status'         => 'publish',
				'posts_per_page'      => max( 1, (int) get_option( 'posts_per_page' ) ),
				'paged'               => mvweb_core_home_page(),
				'ignore_sticky_posts' => true,
				'post__not_in'        => mvweb_core_home_top_ids(),
				'orderby'             => array(
					'date' => 'DESC',
					'ID'   => 'DESC',
				),
			)
		);

		update_post_thumbnail_cache( $query );

		return $query;
	}
}

if ( ! function_exists( 'mvweb_core_home_stream_main' ) ) {
	/**
	 * The feed of a homepage of the latest posts: in the order of the dates, the pinned posts and the posts of the blocks above it left out.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Query being prepared.
	 *
	 * @return void
	 */
	function mvweb_core_home_stream_main( $query ) {
		if ( is_admin() || ! $query->is_main_query() || ! $query->is_home() || 'page' === get_option( 'show_on_front' ) || 'blocks' === mvweb_core_home_mode() ) {
			return;
		}

		$query->set( 'ignore_sticky_posts', true );
		$query->set( 'post__not_in', mvweb_core_home_top_ids() );
		$query->set(
			'orderby',
			array(
				'date' => 'DESC',
				'ID'   => 'DESC',
			)
		);
	}
}
add_action( 'pre_get_posts', 'mvweb_core_home_stream_main', 20 );

if ( ! function_exists( 'mvweb_core_home_stream_404' ) ) {
	/**
	 * The pages of the feed of a homepage that is a page: /page/2/ is the second page of the feed, past the last page is not found.
	 *
	 * @since 0.1.0
	 *
	 * @param bool     $handled Whether the 404 is decided already.
	 * @param WP_Query $query   Main query.
	 *
	 * @return bool
	 */
	function mvweb_core_home_stream_404( $handled, $query ) {
		if ( $handled || 'page' !== get_option( 'show_on_front' ) || ! $query->is_front_page() || mvweb_core_home_page() < 2 || 'blocks' === mvweb_core_home_mode() ) {
			return $handled;
		}

		$feed = mvweb_core_home_stream_query();

		if ( null !== $feed && mvweb_core_home_page() <= (int) $feed->max_num_pages ) {
			status_header( 200 );

			return true;
		}

		$query->set_404();
		status_header( 404 );
		nocache_headers();

		return true;
	}
}
add_filter( 'pre_handle_404', 'mvweb_core_home_stream_404', 10, 2 );

if ( ! function_exists( 'mvweb_core_home_stream_redirect' ) ) {
	/**
	 * Keep /page/N/ of the feed of a homepage that is a page: WordPress would send it to the homepage, and a page past the last one stays not found.
	 *
	 * @since 0.1.0
	 *
	 * @param string|false $redirect Address WordPress redirects to.
	 *
	 * @return string|false
	 */
	function mvweb_core_home_stream_redirect( $redirect ) {
		$feed = is_front_page() || ( is_404() && 1 === preg_match( '#^page/\d+$#', (string) $GLOBALS['wp']->request ) );
		$home = is_string( $redirect ) && untrailingslashit( (string) strtok( $redirect, '?' ) ) === untrailingslashit( home_url() );

		return $home && 'page' === get_option( 'show_on_front' ) && $feed && mvweb_core_home_page() > 1 && 'blocks' !== mvweb_core_home_mode() ? false : $redirect;
	}
}
add_filter( 'redirect_canonical', 'mvweb_core_home_stream_redirect' );

if ( ! function_exists( 'mvweb_core_home_stream_canonical' ) ) {
	/**
	 * The canonical address of /page/N/ of the feed of a homepage that is a page: the page itself, not the paged homepage.
	 *
	 * @since 0.1.0
	 *
	 * @param string $url Canonical address WordPress builds.
	 *
	 * @return string
	 */
	function mvweb_core_home_stream_canonical( $url ) {
		if ( 'page' !== get_option( 'show_on_front' ) || ! is_front_page() || mvweb_core_home_page() < 2 || 'blocks' === mvweb_core_home_mode() ) {
			return $url;
		}

		return get_pagenum_link( mvweb_core_home_page() );
	}
}
add_filter( 'get_canonical_url', 'mvweb_core_home_stream_canonical' );

if ( ! function_exists( 'mvweb_core_stream_pager' ) ) {
	/**
	 * The arguments of the numbered pages of a feed: its own query needs the number of pages and the current one.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Feed.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_stream_pager( $query ) {
		if ( $query === $GLOBALS['wp_query'] ) {
			return array();
		}

		return array(
			'base'    => trailingslashit( home_url() ) . '%_%',
			'format'  => get_option( 'permalink_structure' ) ? user_trailingslashit( 'page/%#%', 'paged' ) : '?paged=%#%',
			'current' => mvweb_core_home_page(),
			'total'   => (int) $query->max_num_pages,
		);
	}
}

if ( ! function_exists( 'mvweb_core_stream_sidebar' ) ) {
	/**
	 * The area of widgets beside the feed of the homepage.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_stream_sidebar() {
		register_sidebar(
			array(
				'name'          => __( 'Homepage: column beside the feed', 'mvweb-core' ),
				'id'            => 'home-stream',
				'description'   => __( 'Shown when the look of the homepage is «Feed and a column of widgets beside it». Empty: the most discussed posts.', 'mvweb-core' ),
				'before_widget' => '<section id="%1$s" class="' . esc_attr( mvweb_core_widget_class( 'widget' ) ) . ' %2$s">',
				'after_widget'  => '</section>',
				'before_title'  => '<div class="' . esc_attr( mvweb_core_widget_class( 'title' ) ) . '">',
				'after_title'   => '</div>',
			)
		);
	}
}
add_action( 'widgets_init', 'mvweb_core_stream_sidebar', 20 );

if ( ! function_exists( 'mvweb_core_stream_needed' ) ) {
	/**
	 * Whether the request prints a list that loads its next page or lays out as masonry.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_stream_needed() {
		if ( mvweb_core_home_stream_on() ) {
			return true;
		}

		if ( ! ( is_home() || is_category() || is_tag() || is_author() || is_date() ) ) {
			return false;
		}

		return mvweb_core_stream_more() >= 0 || isset( mvweb_core_masonry_views()[ mvweb_core_blog_view() ] );
	}
}

if ( ! function_exists( 'mvweb_core_stream_script' ) ) {
	/**
	 * The script module of the lists that load their next page and of the masonry.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules Script modules of the request.
	 *
	 * @return string[]
	 */
	function mvweb_core_stream_script( $modules ) {
		if ( mvweb_core_stream_needed() ) {
			$modules[] = 'stream';
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_core_stream_script' );

if ( ! function_exists( 'mvweb_core_stream_attrs' ) ) {
	/**
	 * The attributes of a list that loads its next page: the number of the pages it loads by itself and the words of the script.
	 *
	 * @since 0.1.0
	 *
	 * @param string $view Look of the list.
	 *
	 * @return string Attributes, each after a space; empty when the list does not load.
	 */
	function mvweb_core_stream_attrs( $view ) {
		$more = mvweb_core_stream_more();

		if ( $more < 0 || 'columns' === $view ) {
			return '';
		}

		$words = array(
			'auto'   => (string) $more,
			'more'   => __( 'Show more', 'mvweb-core' ),
			/* translators: %s: page number. */
			'page'   => __( 'Page %s', 'mvweb-core' ),
			/* translators: %s: page number. */
			'loaded' => __( 'Page %s is loaded', 'mvweb-core' ),
			'end'    => __( 'That is all for now', 'mvweb-core' ),
		);
		$html  = ' data-stream="' . esc_attr( $view ) . '"';

		foreach ( $words as $key => $word ) {
			$html .= ' data-' . $key . '="' . esc_attr( $word ) . '"';
		}

		return $html;
	}
}

if ( ! function_exists( 'mvweb_core_views_on' ) ) {
	/**
	 * Whether the theme counts the views of the articles.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_views_on() {
		return (bool) get_theme_mod( 'mvweb_views_count', false );
	}
}

if ( ! function_exists( 'mvweb_core_top_by' ) ) {
	/**
	 * What puts the posts of the lists «Most discussed» first: the views when they are counted, otherwise the comments.
	 *
	 * @since 0.1.0
	 *
	 * @return string read or popular.
	 */
	function mvweb_core_top_by() {
		return mvweb_core_views_on() ? 'read' : 'popular';
	}
}

if ( ! function_exists( 'mvweb_core_top_args' ) ) {
	/**
	 * The query arguments that put the most read or the most discussed posts first; posts without views follow by date, and without the counter the latest come first.
	 *
	 * @since 0.1.0
	 *
	 * @param string $by read or popular.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_top_args( $by ) {
		if ( 'read' === $by && ! mvweb_core_views_on() ) {
			return array(
				'orderby' => array(
					'date' => 'DESC',
					'ID'   => 'DESC',
				),
			);
		}

		if ( 'read' !== $by ) {
			return array(
				'orderby' => array(
					'comment_count' => 'DESC',
					'date'          => 'DESC',
				),
			);
		}

		return array(
			'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Ordering by the counter is the point.
				'relation' => 'OR',
				'views'    => array(
					'key'     => '_mvweb_views',
					'compare' => 'NOT EXISTS',
					'type'    => 'UNSIGNED',
				),
				array(
					'key'     => '_mvweb_views',
					'compare' => 'EXISTS',
				),
			),
			'orderby'    => array(
				'views' => 'DESC',
				'date'  => 'DESC',
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_top_posts' ) ) {
	/**
	 * The list «Most discussed» of the feed: the most read once the views are counted, otherwise the most discussed.
	 *
	 * @since 0.1.0
	 *
	 * @param int $count  How many.
	 * @param int $offset Optional. How many to skip, for the next page of the feed.
	 *
	 * @return WP_Post[]
	 */
	function mvweb_core_top_posts( $count, $offset = 0 ) {
		$ids = mvweb_core_cached_ids(
			array_merge(
				array(
					'post_type'      => 'post',
					'post_status'    => 'publish',
					'posts_per_page' => max( 1, (int) $count ),
					'offset'         => max( 0, (int) $offset ),
				),
				mvweb_core_top_args( mvweb_core_top_by() )
			)
		);

		if ( empty( $ids ) ) {
			return array();
		}

		$query = new WP_Query( array_merge( mvweb_core_ids_args( $ids ), array( 'update_post_term_cache' => false ) ) );

		update_post_thumbnail_cache( $query );

		return $query->posts;
	}
}

if ( ! function_exists( 'mvweb_core_views_route' ) ) {
	/**
	 * Register the route that counts a view.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_views_route() {
		register_rest_route(
			'mvweb-core/v1',
			'/views',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => 'mvweb_core_views_add',
				'permission_callback' => '__return_true',
				'args'                => array(
					'id' => array(
						'type'     => 'integer',
						'required' => true,
						'minimum'  => 1,
					),
				),
			)
		);
	}
}
add_action( 'rest_api_init', 'mvweb_core_views_route' );

if ( ! function_exists( 'mvweb_core_reader_ok' ) ) {
	/**
	 * Whether a request to count a view or a vote comes from a page of this site in a browser of a reader, not from a robot.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return bool
	 */
	function mvweb_core_reader_ok( WP_REST_Request $request ) {
		$agent  = (string) $request->get_header( 'user_agent' );
		$origin = wp_parse_url( (string) $request->get_header( 'origin' ), PHP_URL_HOST );

		return false !== stripos( $agent, 'Mozilla' ) && ! preg_match( '/bot|crawl|spider|slurp|headless|preview|fetch|python|curl|wget|lighthouse|pagespeed/i', $agent ) && wp_parse_url( home_url(), PHP_URL_HOST ) === $origin;
	}
}

if ( ! function_exists( 'mvweb_core_reader_once' ) ) {
	/**
	 * Let one address act once on a post for a while: a hash of the address and the post is kept, the address itself is not.
	 *
	 * @since 0.1.0
	 *
	 * @param string $action  What is done: view or vote.
	 * @param int    $post_id Post id.
	 * @param int    $ttl     Seconds before the same address may act again.
	 *
	 * @return bool Whether this is the first time within the period.
	 */
	function mvweb_core_reader_once( $action, $post_id, $ttl ) {
		$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$key = 'mvweb_' . substr( (string) $action, 0, 1 ) . '_' . md5( wp_hash( $ip . '|' . (int) $post_id . '|' . $action ) );

		if ( false !== get_transient( $key ) ) {
			return false;
		}

		set_transient( $key, 1, (int) $ttl );

		return true;
	}
}

if ( ! function_exists( 'mvweb_core_views_add' ) ) {
	/**
	 * Add a view to a published post: only from a page of this site, not from a robot and once in half an hour from one address; the answer is the same either way.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response
	 */
	function mvweb_core_views_add( WP_REST_Request $request ) {
		global $wpdb;

		$id = (int) $request['id'];

		if ( mvweb_core_views_on() && mvweb_core_reader_ok( $request ) && 'post' === get_post_type( $id ) && 'publish' === get_post_status( $id ) && mvweb_core_reader_once( 'view', $id, 30 * MINUTE_IN_SECONDS ) ) {
			if ( ! add_post_meta( $id, '_mvweb_views', 1, true ) ) {
				$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->postmeta} SET meta_value = meta_value + 1 WHERE post_id = %d AND meta_key = %s", $id, '_mvweb_views' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One atomic step instead of a read and a write; the cache is cleared below.
				wp_cache_delete( $id, 'post_meta' );
			}

			mvweb_core_views_day_add( $id );
		}

		return new WP_REST_Response( null, 204 );
	}
}

if ( ! function_exists( 'mvweb_core_views_script' ) ) {
	/**
	 * Count the view of the article once a visit: the page asks after the first scroll, touch, key or click of the reader, so a cached page counts too and a robot that only renders does not.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_views_script() {
		if ( ! mvweb_core_views_on() || ! is_singular( 'post' ) || is_preview() || current_user_can( 'edit_posts' ) ) {
			return;
		}

		$id = (int) get_queried_object_id();

		wp_print_inline_script_tag( sprintf( '(function(){var k="mvweb-view-%1$d",t=["wheel","touchstart","keydown","pointerdown"],d=0;if(navigator.webdriver||!navigator.sendBeacon){return;}try{if(sessionStorage.getItem(k)){return;}}catch(e){}function go(){if(d){return;}d=1;t.forEach(function(n){window.removeEventListener(n,go,true);});try{sessionStorage.setItem(k,"1");}catch(e){}navigator.sendBeacon(%2$s);}t.forEach(function(n){window.addEventListener(n,go,{capture:true,passive:true});});})();', $id, wp_json_encode( add_query_arg( 'id', $id, rest_url( 'mvweb-core/v1/views' ) ) ) ) );
	}
}
add_action( 'wp_footer', 'mvweb_core_views_script', 30 );

if ( ! function_exists( 'mvweb_core_post_updated' ) ) {
	/**
	 * The date of the last change of a post for the line «Article updated»: empty when the post was not changed a day or more after publishing.
	 *
	 * @since 0.1.0
	 *
	 * @param int|WP_Post|null $post Optional. The post; the current post by default.
	 *
	 * @return array{iso:string,date:string}|array{}
	 */
	function mvweb_core_post_updated( $post = null ) {
		$post = get_post( $post );

		if ( ! $post || (int) get_post_modified_time( 'U', true, $post ) - (int) get_post_time( 'U', true, $post ) < DAY_IN_SECONDS ) {
			return array();
		}

		return array(
			'iso'  => (string) get_the_modified_date( 'c', $post ),
			'date' => (string) get_the_modified_date( '', $post ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_helpful_on' ) ) {
	/**
	 * Whether the theme draws the part «Was the article helpful?» under the text of a post.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_helpful_on() {
		$support = get_theme_support( 'mvweb-post-after' );

		return is_array( $support ) && isset( $support[0] ) && in_array( 'helpful', (array) $support[0], true );
	}
}

if ( ! function_exists( 'mvweb_core_helpful_meta' ) ) {
	/**
	 * Register the two counters of the votes «Was the article helpful?».
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_helpful_meta() {
		foreach ( array( '_mvweb_helpful_yes', '_mvweb_helpful_no' ) as $key ) {
			register_post_meta(
				'post',
				$key,
				array(
					'type'              => 'integer',
					'single'            => true,
					'default'           => 0,
					'sanitize_callback' => 'absint',
					'auth_callback'     => static function ( $allowed, $meta_key, $post_id ) {
						unset( $allowed, $meta_key );

						return current_user_can( 'edit_post', $post_id );
					},
					'show_in_rest'      => false,
				)
			);
		}
	}
}
add_action( 'init', 'mvweb_core_helpful_meta' );

if ( ! function_exists( 'mvweb_core_helpful_counts' ) ) {
	/**
	 * The votes of a post: yes, no, all of them and the share of yes in per cent.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Optional. Post id; the current post by default.
	 *
	 * @return array{yes:int,no:int,total:int,share:int}
	 */
	function mvweb_core_helpful_counts( $post_id = 0 ) {
		$post_id = $post_id ? (int) $post_id : (int) get_the_ID();
		$yes     = absint( get_post_meta( $post_id, '_mvweb_helpful_yes', true ) );
		$no      = absint( get_post_meta( $post_id, '_mvweb_helpful_no', true ) );
		$total   = $yes + $no;

		return array(
			'yes'   => $yes,
			'no'    => $no,
			'total' => $total,
			'share' => $total > 0 ? (int) round( 100 * $yes / $total ) : 0,
		);
	}
}

if ( ! function_exists( 'mvweb_core_helpful_attrs' ) ) {
	/**
	 * The attributes of the wrapper of the part «Was the article helpful?»: the script finds it by them and shows it; empty when the part is off.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Optional. Post id; the current post by default.
	 *
	 * @return string Attributes, each after a space.
	 */
	function mvweb_core_helpful_attrs( $post_id = 0 ) {
		$post_id = $post_id ? (int) $post_id : (int) get_the_ID();

		if ( ! mvweb_core_helpful_on() || 'publish' !== get_post_status( $post_id ) ) {
			return '';
		}

		return ' data-helpful="' . esc_attr( (string) $post_id ) . '" hidden';
	}
}

if ( ! function_exists( 'mvweb_core_helpful_route' ) ) {
	/**
	 * Register the route that takes a vote «Was the article helpful?».
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_helpful_route() {
		if ( ! mvweb_core_helpful_on() ) {
			return;
		}

		register_rest_route(
			'mvweb-core/v1',
			'/helpful',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => 'mvweb_core_helpful_add',
				'permission_callback' => '__return_true',
				'args'                => array(
					'id'   => array(
						'type'              => 'integer',
						'required'          => true,
						'minimum'           => 1,
						'sanitize_callback' => 'absint',
					),
					'vote' => array(
						'type'     => 'string',
						'required' => true,
						'enum'     => array( 'yes', 'no' ),
					),
				),
			)
		);
	}
}
add_action( 'rest_api_init', 'mvweb_core_helpful_route' );

if ( ! function_exists( 'mvweb_core_helpful_add' ) ) {
	/**
	 * Add a vote to a published post: once a day from one address and not from a robot; the answer carries the votes so far.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	function mvweb_core_helpful_add( WP_REST_Request $request ) {
		global $wpdb;

		$id = (int) $request['id'];

		if ( 'post' !== get_post_type( $id ) || 'publish' !== get_post_status( $id ) || post_password_required( $id ) ) {
			return new WP_Error( 'mvweb_helpful_post', __( 'The article is not found.', 'mvweb-core' ), array( 'status' => 404 ) );
		}

		$key = 'yes' === $request['vote'] ? '_mvweb_helpful_yes' : '_mvweb_helpful_no';

		if ( mvweb_core_reader_ok( $request ) && mvweb_core_reader_once( 'vote', $id, DAY_IN_SECONDS ) && ! add_post_meta( $id, $key, 1, true ) ) {
			$wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->postmeta} SET meta_value = meta_value + 1 WHERE post_id = %d AND meta_key = %s", $id, $key ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One atomic step instead of a read and a write; the cache is cleared below.
			wp_cache_delete( $id, 'post_meta' );
		}

		return new WP_REST_Response( mvweb_core_helpful_counts( $id ), 200 );
	}
}

if ( ! function_exists( 'mvweb_core_helpful_script' ) ) {
	/**
	 * The script module of the votes on an article that shows the part.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules Script modules of the request.
	 *
	 * @return string[]
	 */
	function mvweb_core_helpful_script( $modules ) {
		if ( mvweb_core_helpful_on() && is_singular( 'post' ) && mvweb_core_layout_has( 'post-after', 'helpful' ) ) {
			$modules[] = 'helpful';
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_core_helpful_script' );

if ( ! function_exists( 'mvweb_core_helpful_data' ) ) {
	/**
	 * The address and the words the votes module needs.
	 *
	 * @since 0.1.0
	 *
	 * @param array $data Existing data.
	 *
	 * @return array
	 */
	function mvweb_core_helpful_data( $data ) {
		$data['url'] = rest_url( 'mvweb-core/v1/helpful' );
		/* translators: 1: share of the readers in per cent, 2: number of votes. */
		$data['thanks'] = __( 'Thank you for your answer. %1$s%% of the readers found the article helpful, votes: %2$s.', 'mvweb-core' );
		$data['first']  = __( 'Thank you for your answer.', 'mvweb-core' );
		$data['again']  = __( 'You have already answered. Thank you.', 'mvweb-core' );
		$data['error']  = __( 'The answer was not sent. Try again later.', 'mvweb-core' );

		return $data;
	}
}
add_filter( 'script_module_data_@mvweb-core/helpful', 'mvweb_core_helpful_data' );

add_action( 'rss2_head', 'update_post_thumbnail_cache' );

if ( ! function_exists( 'mvweb_core_feed_cover' ) ) {
	/**
	 * The cover of a post in the feed as an enclosure, for news aggregators; a post with its own enclosure keeps it.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_feed_cover() {
		$post = get_post();

		if ( ! $post || post_password_required( $post ) || ! has_post_thumbnail( $post ) || '' !== (string) get_post_meta( $post->ID, 'enclosure', true ) ) {
			return;
		}

		$id  = (int) get_post_thumbnail_id( $post );
		$src = wp_get_attachment_image_src( $id, 'large' );

		if ( ! $src ) {
			return;
		}

		$meta = (array) wp_get_attachment_metadata( $id );
		$file = ! empty( $src[3] ) && isset( $meta['sizes']['large'] ) ? (array) $meta['sizes']['large'] : $meta;
		$type = isset( $file['mime-type'] ) ? (string) $file['mime-type'] : (string) get_post_mime_type( $id );

		printf( "<enclosure url=\"%s\" length=\"%d\" type=\"%s\" />\n", esc_url( $src[0] ), isset( $file['filesize'] ) ? (int) $file['filesize'] : 0, esc_attr( $type ) );
	}
}
add_action( 'rss2_item', 'mvweb_core_feed_cover' );
