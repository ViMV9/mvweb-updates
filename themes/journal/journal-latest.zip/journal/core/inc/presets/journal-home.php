<?php
/**
 * Ready-made sets of sections of Journal: the home page in five views.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter(
	'mvweb_core_section_presets',
	static function ( $presets ) {
		$presets['journal-home-1'] = array(
			'label'       => __( 'Home · view 1', 'mvweb-core' ),
			'description' => __( 'A lead article with a column, a grid of the latest, category chips, the most read in two columns, a category band, a subscription strip and author cards', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'posts-lead',
					'props' => array(
						'view' => '1',
					),
				),
				array(
					'type'  => 'posts-latest',
					'props' => array(
						'view'      => '6',
						'title'     => __( 'Latest articles', 'mvweb-core' ),
						'count'     => 6,
						'link_text' => __( 'All posts', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'blog-cats',
					'props' => array(
						'view'      => '1',
						'title'     => __( 'Our categories', 'mvweb-core' ),
						'count'     => 8,
						'order'     => 'count',
						'posts'     => 3,
						'link_text' => __( 'All posts', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'posts-top',
					'props' => array(
						'view'   => '11',
						'title'  => __( 'Most read posts', 'mvweb-core' ),
						'text'   => __( 'Over the last 30 days', 'mvweb-core' ),
						'source' => 'read',
						'period' => 'month',
						'count'  => 6,
					),
				),
				array(
					'type'  => 'posts-band',
					'props' => array(
						'view'      => '16',
						'kicker'    => __( 'Rubric', 'mvweb-core' ),
						'title'     => '',
						'text'      => __( 'Guides and reviews we have tested ourselves', 'mvweb-core' ),
						'link_text' => __( 'All posts of the category', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'subscribe',
					'props' => array(
						'view'  => '1',
						'title' => __( 'One letter a week, five useful articles', 'mvweb-core' ),
						'text'  => __( 'No ads and no spam. Unsubscribe in one click.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'authors',
					'props' => array(
						'view'      => '1',
						'title'     => __( 'Who writes for you', 'mvweb-core' ),
						'text'      => __( 'Authors and experts of the editorial team', 'mvweb-core' ),
						'count'     => 4,
						'link_text' => __( 'The whole editorial team', 'mvweb-core' ),
					),
				),
			),
		);

		$presets['journal-home-2'] = array(
			'label'       => __( 'Home · view 2', 'mvweb-core' ),
			'description' => __( 'A cover with text, the latest with excerpts, category tiles, the most read with numbers and covers, a large article and a list, a dark subscription block and the editorial team', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'posts-lead',
					'props' => array(
						'view' => '2',
					),
				),
				array(
					'type'  => 'posts-latest',
					'props' => array(
						'view'      => '7',
						'title'     => __( 'Latest articles', 'mvweb-core' ),
						'text'      => __( 'New this week: guides and answers to common questions', 'mvweb-core' ),
						'count'     => 6,
						'link_text' => __( 'All posts', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'blog-cats',
					'props' => array(
						'view'      => '2',
						'title'     => __( 'Our categories', 'mvweb-core' ),
						'count'     => 8,
						'order'     => 'count',
						'posts'     => 3,
						'link_text' => '',
					),
				),
				array(
					'type'  => 'posts-top',
					'props' => array(
						'view'   => '12',
						'title'  => __( 'Most read posts', 'mvweb-core' ),
						'source' => 'read',
						'period' => 'month',
					),
				),
				array(
					'type'  => 'posts-band',
					'props' => array(
						'view'      => '17',
						'title'     => '',
						'link_text' => __( 'All posts', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'subscribe',
					'props' => array(
						'view'  => '2',
						'title' => __( 'One letter a week, five useful articles', 'mvweb-core' ),
						'text'  => __( 'No ads and no spam. Unsubscribe in one click.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'authors',
					'props' => array(
						'view'        => '2',
						'title'       => __( 'About the editorial team', 'mvweb-core' ),
						'text'        => __( 'We explain how to choose, set up and fix devices. We test the tips on our own devices.', 'mvweb-core' ),
						'count'       => 4,
						'button_text' => __( 'How we check the articles', 'mvweb-core' ),
					),
				),
			),
		);

		$presets['journal-home-3'] = array(
			'label'       => __( 'Home · view 3', 'mvweb-core' ),
			'description' => __( 'A heading without a photo, the latest as cards on a band, categories with their articles, the most read on a dark band, four columns of a category, a subscription card and trust in figures', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'posts-lead',
					'props' => array(
						'view'   => '3',
						'period' => 'month',
					),
				),
				array(
					'type'  => 'posts-latest',
					'props' => array(
						'view'      => '8',
						'title'     => __( 'Latest articles', 'mvweb-core' ),
						'count'     => 8,
						'link_text' => __( 'All posts', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'blog-cats',
					'props' => array(
						'view'      => '3',
						'title'     => __( 'By category', 'mvweb-core' ),
						'text'      => __( 'The most useful in every topic', 'mvweb-core' ),
						'count'     => 4,
						'order'     => 'count',
						'posts'     => 3,
						'link_text' => '',
					),
				),
				array(
					'type'  => 'posts-top',
					'props' => array(
						'view'   => '13',
						'title'  => __( 'Most read this month', 'mvweb-core' ),
						'source' => 'read',
						'period' => 'month',
					),
				),
				array(
					'type'  => 'posts-band',
					'props' => array(
						'view'      => '18',
						'title'     => '',
						'link_text' => __( 'All posts', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'subscribe',
					'props' => array(
						'view'   => '3',
						'title'  => __( 'One letter a week, five useful articles', 'mvweb-core' ),
						'text'   => '',
						'points' => implode(
							"\n",
							array(
								__( 'The 5 best articles of the week', 'mvweb-core' ),
								__( 'Editorial answers to questions from readers', 'mvweb-core' ),
								__( 'No ads, unsubscribe in one click', 'mvweb-core' ),
							)
						),
					),
				),
				array(
					'type'  => 'authors',
					'props' => array(
						'view'  => '3',
						'title' => __( 'Why readers trust us', 'mvweb-core' ),
						'text'  => '',
						'facts' => array(
							array(
								'number' => '1 160',
								'label'  => __( 'articles, each updated when the rules or prices change', 'mvweb-core' ),
							),
							array(
								'number' => '14',
								'label'  => __( 'authors and experts who know their topic', 'mvweb-core' ),
							),
							array(
								'number' => __( '2.4 million', 'mvweb-core' ),
								'label'  => __( 'readers a month find their answers here', 'mvweb-core' ),
							),
						),
					),
				),
			),
		);

		$presets['journal-home-4'] = array(
			'label'       => __( 'Home · view 4', 'mvweb-core' ),
			'description' => __( 'A lead article and four, a feed by dates, cards with subcategories, the most read in tabs, a cover with headings, networks as tiles and a word of the editor', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'posts-lead',
					'props' => array(
						'view' => '4',
					),
				),
				array(
					'type'  => 'posts-latest',
					'props' => array(
						'view'      => '9',
						'title'     => __( 'Feed', 'mvweb-core' ),
						'link_text' => __( 'All posts', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'blog-cats',
					'props' => array(
						'view'      => '4',
						'title'     => __( 'Our categories', 'mvweb-core' ),
						'count'     => 8,
						'order'     => 'count',
						'posts'     => 3,
						'link_text' => __( 'All posts', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'posts-top',
					'props' => array(
						'view'   => '14',
						'title'  => '',
						'period' => 'month',
					),
				),
				array(
					'type'  => 'posts-band',
					'props' => array(
						'view'      => '19',
						'title'     => '',
						'link_text' => __( 'All posts', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'subscribe',
					'props' => array(
						'view'  => '4',
						'title' => __( 'Read us where it suits you', 'mvweb-core' ),
						'text'  => __( 'New articles come out in every channel at once', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'authors',
					'props' => array(
						'view'        => '4',
						'title'       => '',
						'text'        => '',
						'chief_label' => __( 'Editor-in-chief', 'mvweb-core' ),
						'letter'      => __( '«We write only about what we have tested ourselves. If a tip did not work for us, it will not be on the site».', 'mvweb-core' ),
					),
				),
			),
		);

		$presets['journal-home-5'] = array(
			'label'       => __( 'Home · view 5', 'mvweb-core' ),
			'description' => __( 'A greeting with search, a scrolling ribbon of the latest, an index of topics, the most read with the first place large, two categories side by side, a subscription line and a strip of faces', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'posts-lead',
					'props' => array(
						'view'  => '5',
						'title' => __( 'We figure out devices together with you', 'mvweb-core' ),
						'text'  => __( 'Guides, comparisons and tips for those who would rather not dig into the settings alone.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'posts-latest',
					'props' => array(
						'view'      => '10',
						'title'     => __( 'Latest articles', 'mvweb-core' ),
						'count'     => 8,
						'link_text' => __( 'All posts', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'blog-cats',
					'props' => array(
						'view'      => '5',
						'title'     => __( 'All topics', 'mvweb-core' ),
						'count'     => 8,
						'order'     => 'count',
						'posts'     => 3,
						'link_text' => __( 'All posts', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'posts-top',
					'props' => array(
						'view'   => '15',
						'title'  => __( 'Most read posts', 'mvweb-core' ),
						'source' => 'read',
						'period' => 'month',
					),
				),
				array(
					'type'  => 'posts-band',
					'props' => array(
						'view'      => '20',
						'title'     => '',
						'link_text' => __( 'All', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'subscribe',
					'props' => array(
						'view'  => '5',
						'title' => __( 'One letter a week, five useful articles', 'mvweb-core' ),
						'text'  => '',
					),
				),
				array(
					'type'  => 'authors',
					'props' => array(
						'view'      => '5',
						'title'     => __( 'Our authors', 'mvweb-core' ),
						'text'      => '',
						'count'     => 4,
						'link_text' => __( 'All authors', 'mvweb-core' ),
					),
				),
			),
		);

		return $presets;
	}
);
