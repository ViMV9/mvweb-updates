<?php
/**
 * Admin scripts of the block look: the contrast check and its Customizer side.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_contrast_register' ) ) {
	/**
	 * Register the contrast script the builder and the Customizer depend on.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_contrast_register() {
		$script = mvweb_core_asset_path( '/admin/js/contrast.js' );

		wp_register_script( 'mvweb-core-contrast', MVWEB_CORE_URI . $script, array(), mvweb_core_asset_version( $script ), true );
		wp_localize_script(
			'mvweb-core-contrast',
			'mvwebCoreContrastText',
			array(
				'low' => __( 'Contrast is below 4.5:1: the text will be hard to read.', 'mvweb-core' ),
			)
		);
	}
}
add_action( 'admin_enqueue_scripts', 'mvweb_core_contrast_register', 1 );
add_action( 'customize_controls_enqueue_scripts', 'mvweb_core_contrast_register', 1 );

if ( ! function_exists( 'mvweb_core_look_customizer_script' ) ) {
	/**
	 * Warn in the Customizer when the colours of a block cannot be read together.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_look_customizer_script() {
		$pairs = array();

		foreach ( array_keys( mvweb_core_editable_sections() ) as $type ) {
			foreach ( array(
				'bg_color'      => 'ink_color',
				'bg_color_dark' => 'ink_color_dark',
			) as $bg => $ink ) {
				$pairs[] = array(
					'bg'  => mvweb_core_section_setting( $type, $bg ),
					'ink' => mvweb_core_section_setting( $type, $ink ),
				);
			}
		}

		if ( function_exists( 'mvweb_core_element_colors' ) ) {
			foreach ( mvweb_core_element_colors() as $group ) {
				foreach ( $group['items'] as $item ) {
					if ( 0 !== strpos( $item[2], 'ink:' ) ) {
						continue;
					}

					foreach ( array( '', '_dark' ) as $suffix ) {
						$pairs[] = array(
							'bg'  => substr( $item[2], 4 ) . $suffix,
							'ink' => $item[0] . $suffix,
						);
					}
				}
			}
		}

		$script = mvweb_core_asset_path( '/admin/js/customizer-look.js' );

		wp_enqueue_script( 'mvweb-core-customizer-look', MVWEB_CORE_URI . $script, array( 'customize-controls', 'mvweb-core-contrast' ), mvweb_core_asset_version( $script ), true );
		wp_localize_script(
			'mvweb-core-customizer-look',
			'mvwebCoreLook',
			array(
				'pairs' => $pairs,
				'zones' => mvweb_core_header_zone_sets(),
			)
		);
	}
}
add_action( 'customize_controls_enqueue_scripts', 'mvweb_core_look_customizer_script' );

if ( ! function_exists( 'mvweb_core_header_zone_sets' ) ) {
	/**
	 * The header zones each look of the header fills by default, for the zones whose set depends on the look.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,string>> Look => zone setting => JSON list of elements.
	 */
	function mvweb_core_header_zone_sets() {
		$sets = array();

		foreach ( array_keys( mvweb_core_header_views() ) as $view ) {
			$pin = static function () use ( $view ) {
				return $view;
			};

			add_filter( 'theme_mod_mvweb_header_layout', $pin, 999 );

			foreach ( array_keys( (array) mvweb_core_zones() ) as $zone ) {
				if ( 0 !== strpos( $zone, 'header-' ) ) {
					continue;
				}

				$order = array_diff( mvweb_core_zone_default_order( $zone ), 'header-main' === $zone ? array( 'logo' ) : array() );

				$sets[ $view ][ mvweb_core_zone_setting( $zone ) ] = wp_json_encode( array_values( $order ) );
			}

			remove_filter( 'theme_mod_mvweb_header_layout', $pin, 999 );
		}

		$first = (array) reset( $sets );

		foreach ( array_keys( $first ) as $setting ) {
			if ( 1 === count( array_unique( array_column( $sets, $setting ) ) ) ) {
				foreach ( array_keys( $sets ) as $view ) {
					unset( $sets[ $view ][ $setting ] );
				}
			}
		}

		return $sets;
	}
}
