# Journal — руководство разработчика

Документ для того, кто ставит тему на сайт и дорабатывает её под проект. Правило одно: **файлы темы не редактируются** — обновление перезапишет их вместе с правкой. Всё своё живёт в дочерней теме или в плагине сайта.

## Из чего собрана тема

| Слой | Где | Что |
|---|---|---|
| Ядро MVweb | `core/` | Записи блога, «Состав» страниц, блоки конструктора, колонки и виджеты, шапка и подвал из зон, SEO и разметка, поведение на фронте. Общее для всех тем студии |
| Движок настроек | `inc/customizer/kit/` | Поля Customizer, вывод CSS, условная видимость |
| Тема | остальное | Шаблоны, стили, токены, шрифты, иконки — вид |

`core/` и `inc/customizer/kit/` приходят копией из общих исходников студии и руками не правятся.

Journal — тема журнала: каталога, услуг, работ и команды в ней нет. Модули ядра выключены целиком: их типы записей, блоки, виджеты и настройки не регистрируются.

## Сначала — настройки, потом код

Прежде чем писать дочернюю тему, стоит открыть **Внешний вид → Настроить**. Там выбираются палитра, шрифт, «Линейки», скругление, виды шапки, объявления, «Тем дня», мега-меню, статьи, рубрики, автора, страниц, поиска, 404 и колонки, «Состав» каждой страницы, блоки Главной, соцсети и рассылка.

Готовые наборы блоков («Главная · вид 1…5», «О журнале», «Связаться») вставляются в конструктор страницы кнопкой «Готовые наборы».

## Дочерняя тема

```css
/*
Theme Name: Journal Child
Template: journal
Version: 1.0.0
*/
```

```php
add_action(
	'wp_enqueue_scripts',
	function () {
		wp_enqueue_style( 'journal-child', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );
	},
	20
);
```

Стили темы подключаются на приоритете 10 (по ключам запроса). Файл дочерней темы должен встать после них, поэтому приоритет 20.

При первой активации дочерней темы настройки родителя копируются в неё, если своих нет. Спрайты дочерней темы `assets/icons/sprite.svg` и `assets/icons/sprite-extra.svg` читаются вместе с родительскими; символы называются `mvweb-t-icon-{имя}`.

## Переопределение шаблонов

Любой шаблон дочерняя тема перекрывает копией по тому же пути:

| Путь | Что печатает |
|---|---|
| `single.php`, `home.php`, `archive.php`, `author.php`, `search.php`, `404.php`, `page.php` | Страницы: статья, все статьи, рубрика (метка, дата), автор, поиск, 404, страница |
| `page-templates/builder.php`, `contacts.php`, `sitemap.php` | Шаблоны страниц: конструктор, контакты, карта сайта |
| `template-parts/sections/{тип}.php` | Блоки конструктора, файл на тип. Блок без файла редактору не показывается |
| `template-parts/{область}/{часть}.php` | Части страниц, карточек и виджетов («Состав»): одна часть — один файл |
| `template-parts/widgets/{шаблон}.php` | Виджеты ядра в рамке темы: записи, рубрики, контакты, помощь, автор, соцсети и рассылка, поиск |
| `template-parts/elements/` | Элементы зон шапки и подвала |
| `template-parts/post-card.php`, `card-post/` | Карточка записи |
| `template-parts/page-hero.php`, `sidebar.php`, `crumbs.php` | Шапка страницы, колонка, хлебные крошки |
| `template-parts/topics.php`, `subscribe-popover.php`, `cookie.php`, `toc.php` | «Темы дня», окно «Подписаться», уведомление о cookie, оглавление |
| `header.php`, `footer.php`, `comments.php`, `searchform.php` | Каркас |

Файлы `inc/` и `core/` копией не перекрываются — их логика меняется хуками или переопределением функции: все функции темы и ядра объявлены внутри `if ( ! function_exists( … ) )`, а файл `functions.php` дочерней темы загружается раньше родительского.

## Виды

Вид — номер от 1 до 5. Он выбирается первым полем в разделе Customizer и печатается на `<html>` атрибутом.

| Что | Фильтр | Чтение | Атрибут |
|---|---|---|---|
| Статья, рубрика, автор, страница, контакты, поиск, 404, объявление, «Темы дня», мега-меню, колонка | `mvweb_core_area_views` (ключи `single`, `category`, `author`, `page`, `contacts`, `search`, `notfound`, `notice`, `topics`, `mega`, `sidebar`) | `mvweb_core_area_view( $area )` | `data-view-{область}` |
| Шапка | `mvweb_core_header_views` | `get_theme_mod( 'mvweb_header_layout' )` | `data-header-view` |
| Блоки конструктора | `mvweb_core_section_views` | `$args['view']` в шаблоне блока | класс блока |
| Виджеты (записи, рубрики блога, контакты, помощь) | `mvweb_core_widget_views` | `$args['view']` в шаблоне виджета | класс `mvweb-t-wg-{тип}--{вид}` |
| Список записей, подрубрики, карта сайта | `mvweb_core_blog_views`, `mvweb_core_blog_subcats_views`, `mvweb_core_sitemap_views` | `mvweb_core_blog_view()` | класс списка |

Вид без меток в списке скрывает поле. Виды, которые меняют разметку (страницы, колонка), перезагружают превью Customizer; объявление, «Темы дня» и мега-меню меняются в превью без перезагрузки.

## Шрифт и «Линейки»

| Настройка | Значения | Атрибут на `<html>` |
|---|---|---|
| `mvweb_font` | `golos`, `onest`, `literata`, `ptserif`, `nunito` | `data-font` |
| `mvweb_lines` | вкл/выкл: линии вместо плашек и теней | `data-lines="on\|off"` |

Значения токенов для каждой пары и «Линеек» — в `assets/css/tokens.css`. Шрифты лежат в `assets/fonts/`, подгружается только выбранная пара; внешних ссылок на шрифты нет.

## Движение

Анимации в CSS выключены при `prefers-reduced-motion: reduce` (`assets/css/base.css`). Слайдер первого экрана при этой настройке не листает сам, бегущая строка стоит и переносит текст. Свой скрипт с анимацией в дочерней теме проверяет то же условие: `window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches`.

## Хуки

Ядро (`core/`). Колонка «Тема» — хук, на который подписана сама тема.

| Хук | Что меняет | Тема |
|---|---|---|
| `mvweb_core_loaded` (action) | Ядро загружено, аргумент — версия | |
| `mvweb_core_register_sections` (action) | Место регистрации своего типа блока | |
| `mvweb_core_customizer_register` (action) | После полей ядра в Customizer, аргумент `$kit` | да |
| `mvweb_core_section_editable` | Показывать ли блок редактору — для блоков, шаблон которых отдаёт плагин | |
| `mvweb_core_pre_render_section` | Перехват печати блока | |
| `mvweb_core_section_presets` | Готовые наборы блоков | |
| `mvweb_core_seed_home_rows` | Блоки Главной при первой активации | да |
| `mvweb_core_sections_limit` | Потолок блоков на странице, по умолчанию 40 | |
| `mvweb_core_section_views`, `mvweb_core_section_parts` | Названия видов блока, части блока и элемента списка | да |
| `mvweb_core_area_views`, `mvweb_core_header_views`, `mvweb_core_widget_views` | Виды областей, шапки, виджетов | да |
| `mvweb_core_layouts`, `mvweb_core_layout_order`, `mvweb_core_render_part` | Области «Состава», показанные части, перехват печати части | да (`layouts`) |
| `mvweb_core_zones`, `mvweb_core_zone_elements`, `mvweb_core_zone_hints`, `mvweb_core_zone_default_order`, `mvweb_core_render_element` | Зоны шапки и подвала | да (кроме `render_element`) |
| `mvweb_core_style_map`, `mvweb_core_module_map` | Стили и JS-модули запроса | да |
| `mvweb_core_preview_attrs`, `mvweb_core_preview_partials` | Мгновенное превью атрибутов `<html>` и частей страницы в Customizer | да |
| `mvweb_core_palettes`, `mvweb_core_radius_default` | Пресеты палитры, скругление по умолчанию | да |
| `mvweb_core_image_sizes` | Размеры картинок | да |
| `mvweb_core_widget_kinds`, `mvweb_core_widget_classes` | Виджеты ядра, классы виджетов по ролям | да |
| `mvweb_core_mega_cards` | Карточки статей в мега-меню | да |
| `mvweb_core_supported_modules` | Модули ядра темы; пустой список — каталога, услуг и работ нет | да |
| `mvweb_core_blog_views`, `mvweb_core_blog_subcats_views`, `mvweb_core_callouts_sets` | Виды списка записей, подрубрик, наборы врезок | да (кроме `callouts_sets`) |
| `mvweb_core_sitemap_types`, `mvweb_core_sitemap_views` | Разделы карты сайта и её виды | да (`sitemap_views`) |
| `mvweb_core_markup_allowed`, `mvweb_core_markup_graph`, `mvweb_core_markup_plugins` | Нужна ли странице микроразметка, узлы графа, плагины с разметкой | |
| `mvweb_core_share_networks` | Сети «Поделиться» | |
| `mvweb_core_crumb_items` | Хлебные крошки | |
| `mvweb_core_reading_speed` | Слов в минуту для времени чтения | |

Тема:

| Хук | Что меняет |
|---|---|
| `mvweb_theme_header_class` | Классы шапки |

## Стартовые значения

Пока владелец не сохранил свои настройки, Journal включает оглавление, блок автора, врезки и счёт просмотров. Части страницы 404 до сохранения «Состава» следуют её виду. Список — `mvweb_theme_starter_mods()` в `inc/theme/setup.php`; дочерняя тема переопределяет функцию.

При включении темы Главная получает набор «Главная · вид 1», пустые колонки — стартовые виджеты по типам страниц. Заполненное владельцем не трогается.

## Сборка и переводы

```bash
npm install
npm run build          # .min для assets/ темы
npm run build:locale   # languages/ru_RU.po → .mo, проверка перевода ядра
```

Строки темы — в домене `journal` (`languages/ru_RU.po`), строки ядра — в `mvweb-core` (`core/languages/`, приходят переведёнными вместе с `core/`).
