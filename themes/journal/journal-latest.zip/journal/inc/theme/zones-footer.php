<?php
/**
 * The footer zones: their names, hints and the order of the contacts of the design.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_footer_contacts_parts' ) ) {
	/**
	 * The parts of the footer contacts in the order of the design.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $layouts Area => definition.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_footer_contacts_parts( $layouts ) {
		if ( ! isset( $layouts['footer.contacts']['parts'] ) ) {
			return $layouts;
		}

		$parts = $layouts['footer.contacts']['parts'];
		$first = array();

		foreach ( array( 'email', 'messengers', 'phones', 'hours', 'address' ) as $slug ) {
			if ( isset( $parts[ $slug ] ) ) {
				$first[ $slug ] = $parts[ $slug ];
			}
		}

		$layouts['footer.contacts']['parts'] = $first + $parts;

		return $layouts;
	}
}
add_filter( 'mvweb_core_layouts', 'mvweb_theme_footer_contacts_parts', 20 );

if ( ! function_exists( 'mvweb_theme_footer_zone_texts' ) ) {
	/**
	 * The name and the hint of every footer zone, in words of the owner.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,string>> Zone slug => name and hint.
	 */
	function mvweb_theme_footer_zone_texts() {
		return array(
			'footer-main'   => array(
				'label' => __( 'Footer: columns', 'journal' ),
				'hint'  => __( 'The columns at the bottom of the page: logo with the social networks, two menus, the most read articles of the month, contacts of the editorial office.', 'journal' ),
			),
			'footer-bottom' => array(
				'label' => __( 'Footer: bottom line', 'journal' ),
				'hint'  => __( 'The thin line at the very bottom: copyright, company details, legal links.', 'journal' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_footer_zone_labels' ) ) {
	/**
	 * The names of the footer zones.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $zones Zone slug => label.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_footer_zone_labels( $zones ) {
		foreach ( mvweb_theme_footer_zone_texts() as $zone => $texts ) {
			if ( isset( $zones[ $zone ] ) ) {
				$zones[ $zone ] = $texts['label'];
			}
		}

		return $zones;
	}
}
add_filter( 'mvweb_core_zones', 'mvweb_theme_footer_zone_labels', 20 );

if ( ! function_exists( 'mvweb_theme_footer_zone_hints' ) ) {
	/**
	 * The hints under the footer zones in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $hints Zone slug => hint.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_footer_zone_hints( $hints ) {
		foreach ( mvweb_theme_footer_zone_texts() as $zone => $texts ) {
			$hints[ $zone ] = $texts['hint'];
		}

		return $hints;
	}
}
add_filter( 'mvweb_core_zone_hints', 'mvweb_theme_footer_zone_hints' );

if ( ! function_exists( 'mvweb_theme_footer_elements' ) ) {
	/**
	 * The column of the most read articles in the footer.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $elements Element slug => label.
	 * @param string               $zone     Zone slug.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_footer_elements( $elements, $zone ) {
		if ( 'footer-main' === $zone ) {
			$elements['popular'] = __( 'Read now', 'journal' );
		}

		return $elements;
	}
}
add_filter( 'mvweb_core_zone_elements', 'mvweb_theme_footer_elements', 30, 2 );

if ( ! function_exists( 'mvweb_theme_footer_views' ) ) {
	/**
	 * The looks of the footer.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Key => name.
	 */
	function mvweb_theme_footer_views() {
		return array(
			'columns' => __( '1 · Columns', 'journal' ),
			'center'  => __( '2 · Centred, the menus in rows', 'journal' ),
			'feed'    => __( '3 · Most read articles in cards', 'journal' ),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_footer_view' ) ) {
	/**
	 * The look of the footer chosen in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @return string One of the keys of mvweb_theme_footer_views().
	 */
	function mvweb_theme_footer_view() {
		$view = (string) get_theme_mod( 'mvweb_footer_view', 'columns' );

		return isset( mvweb_theme_footer_views()[ $view ] ) ? $view : 'columns';
	}
}

if ( ! function_exists( 'mvweb_theme_footer_menu' ) ) {
	/**
	 * A footer menu as one row of links, without the sub-items.
	 *
	 * @since 0.1.0
	 *
	 * @param string $location Menu location.
	 * @param string $heading  Setting of the heading, used as the name of the navigation.
	 * @param string $classes  Classes of the list.
	 *
	 * @return string Markup, empty without a menu.
	 */
	function mvweb_theme_footer_menu( $location, $heading, $classes ) {
		$title = trim( (string) mvweb_cz_get( $heading ) );

		ob_start();
		mvweb_core_nav(
			$location,
			array(
				'menu_class'           => $classes,
				'depth'                => 1,
				'items_wrap'           => '<ul class="%2$s">%3$s</ul>',
				'container'            => 'nav',
				'container_aria_label' => '' !== $title ? $title : __( 'Footer menu', 'journal' ),
			)
		);

		return trim( (string) ob_get_clean() );
	}
}

if ( ! function_exists( 'mvweb_theme_footer_popular_field' ) ) {
	/**
	 * The heading of the column of the most read articles.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_theme_footer_popular_field( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_footer_view',
					'section'     => 'mvweb_cz_footer_blocks',
					'label'       => __( 'Footer view', 'journal' ),
					'description' => __( 'Columns: the parts below in their order. Centred: the logo, the first menu as buttons and the second as a row of links. Cards: the most read articles with pictures, the menus in rows under them.', 'journal' ),
					'default'     => 'columns',
					'choices'     => mvweb_theme_footer_views(),
				),
				array(
					'type'        => 'text',
					'settings'    => 'mvweb_footer_popular_title',
					'section'     => 'mvweb_cz_footer_blocks',
					'label'       => __( 'Heading of the most read articles', 'journal' ),
					'description' => __( 'Five articles read most in the last 30 days. Empty: no heading.', 'journal' ),
					'default'     => __( 'Read now', 'journal' ),
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_theme_footer_popular_field' );

if ( ! function_exists( 'mvweb_theme_footer_popular_order' ) ) {
	/**
	 * The look of the footer first, the heading of the most read articles after the headings of the footer menus.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string[]> $fields Section id => control ids.
	 *
	 * @return array<string,string[]>
	 */
	function mvweb_theme_footer_popular_order( $fields ) {
		if ( isset( $fields['mvweb_cz_footer_blocks'] ) ) {
			array_unshift( $fields['mvweb_cz_footer_blocks'], 'mvweb_footer_view' );

			$at = array_search( 'mvweb_footer_menu_2_title', $fields['mvweb_cz_footer_blocks'], true );

			array_splice( $fields['mvweb_cz_footer_blocks'], false === $at ? count( $fields['mvweb_cz_footer_blocks'] ) : $at + 1, 0, array( 'mvweb_footer_popular_title' ) );
		}

		return $fields;
	}
}
add_filter( 'mvweb_core_customizer_fields', 'mvweb_theme_footer_popular_order' );
