<?php
/**
 * Block description: a call to action.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Accent card', 'journal' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Line with a rule', 'journal' ),
			'class'  => 'line',
			'motion' => 'slide',
		),
		'3' => array(
			'label'  => __( 'Photo and buttons', 'journal' ),
			'class'  => 'photo',
			'motion' => 'wipe',
		),
		'4' => array(
			'label'  => __( 'Large type and a ribbon', 'journal' ),
			'class'  => 'marquee',
			'motion' => 'blur',
		),
		'5' => array(
			'label'  => __( 'Two halves', 'journal' ),
			'class'  => 'duo',
			'motion' => 'scale',
		),
	),
	'only'  => array(
		'icon'          => array( '5' ),
		'image'         => array( '3' ),
		'badge'         => array( '3' ),
		'ticker'        => array( '4' ),
		'second_icon'   => array( '5' ),
		'second_kicker' => array( '5' ),
		'second_title'  => array( '5' ),
		'second_text'   => array( '5' ),
		'second_button' => array( '5' ),
		'second_url'    => array( '5' ),
		'second_phone'  => array( '5' ),
		'parts.photo'   => array( '3' ),
		'parts.ticker'  => array( '4' ),
		'parts.second'  => array( '5' ),
		'image_side'    => array( '3' ),
		'image_size'    => array( '3' ),
	),
);
