<?php
/**
 * Block description: the latest posts of the blog.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'6'  => array(
			'label'  => __( 'Grid', 'journal' ),
			'class'  => 'grid',
			'motion' => 'rise',
		),
		'7'  => array(
			'label'  => __( 'List with excerpts', 'journal' ),
			'class'  => 'rows',
			'motion' => 'rise',
		),
		'8'  => array(
			'label'  => __( 'Cards on a band', 'journal' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
		'9'  => array(
			'label'  => __( 'Feed by dates', 'journal' ),
			'class'  => 'feed',
			'motion' => 'rise',
		),
		'10' => array(
			'label'  => __( 'Scrolling ribbon', 'journal' ),
			'class'  => 'rail',
			'motion' => 'rise',
		),
	),
	'item_parts' => array(
		'date'     => __( 'Date', 'journal' ),
		'read'     => __( 'Reading time', 'journal' ),
		'comments' => __( 'Number of comments', 'journal' ),
		'views'    => __( 'Number of views', 'journal' ),
		'author'   => __( 'Author', 'journal' ),
	),
	'off'        => array(
		'item_parts' => array( 'date', 'read', 'comments', 'views', 'author' ),
	),
	'only'       => array(
		'text'        => array( '7' ),
		'count'       => array( '6', '7', '8', '10' ),
		'parts.lead'  => array( '7' ),
		'parts.chips' => array(),
		'parts.hint'  => array(),
	),
);
