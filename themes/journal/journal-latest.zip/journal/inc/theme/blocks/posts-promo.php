<?php
/**
 * Block description: a promo banner of a collection beside a row of posts.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Banner on the left', 'journal' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Banner as a header', 'journal' ),
			'class'  => 'band',
			'motion' => 'wipe',
		),
		'3' => array(
			'label'  => __( 'Row overlapping the banner', 'journal' ),
			'class'  => 'overlap',
			'motion' => 'scale',
		),
		'4' => array(
			'label'  => __( 'Banner inside the row', 'journal' ),
			'class'  => 'lead',
			'motion' => 'slide',
		),
		'5' => array(
			'label'  => __( 'Compact strip', 'journal' ),
			'class'  => 'strip',
			'motion' => 'blur',
		),
	),
	'only'  => array(
		'text'        => array( '1', '2', '3', '4' ),
		'chips'       => array( '1', '2', '3', '5' ),
		'image_2'     => array( '1', '2', '3', '4' ),
		'image_3'     => array( '2' ),
		'parts.desc'  => array( '1', '2', '3', '4' ),
		'parts.chips' => array( '1', '2', '3', '5' ),
	),
);
