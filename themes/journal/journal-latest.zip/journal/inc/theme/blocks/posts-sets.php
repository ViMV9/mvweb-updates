<?php
/**
 * Block description: the collections of posts.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Cards; one collection as a banner', 'journal' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
	),
);
