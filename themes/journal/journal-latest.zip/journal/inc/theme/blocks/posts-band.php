<?php
/**
 * Block description: the band of a category.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'16' => array(
			'label'  => __( 'Head on the left', 'journal' ),
			'class'  => 'band-a',
			'motion' => 'rise',
		),
		'17' => array(
			'label'  => __( 'Large and list', 'journal' ),
			'class'  => 'band-b',
			'motion' => 'rise',
		),
		'18' => array(
			'label'  => __( 'Four columns', 'journal' ),
			'class'  => 'band-c',
			'motion' => 'rise',
		),
		'19' => array(
			'label'  => __( 'Cover and titles', 'journal' ),
			'class'  => 'band-d',
			'motion' => 'rise',
		),
		'20' => array(
			'label'  => __( 'Two categories', 'journal' ),
			'class'  => 'band-e',
			'motion' => 'rise',
		),
	),
	'item_parts' => array(
		'date'     => __( 'Date', 'journal' ),
		'read'     => __( 'Reading time', 'journal' ),
		'comments' => __( 'Number of comments', 'journal' ),
		'views'    => __( 'Number of views', 'journal' ),
		'author'   => __( 'Author', 'journal' ),
	),
	'off'        => array(
		'item_parts' => array( 'date', 'read', 'comments', 'views', 'author' ),
	),
	'only'       => array(
		'text'        => array( '16' ),
		'period'      => array(),
		'category_2'  => array( '20' ),
		'count'       => array(),
		'parts.lead'  => array( '16' ),
		'parts.chips' => array( '16', '18' ),
		'parts.hint'  => array(),
	),
);
