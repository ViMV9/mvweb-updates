<?php
/**
 * Block description: partners and documents.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Tiles', 'journal' ),
			'class'  => 'logos',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Running line', 'journal' ),
			'class'  => 'marquee',
			'motion' => 'fade',
		),
		'3' => array(
			'label'  => __( 'Grey row', 'journal' ),
			'class'  => 'mono',
			'motion' => 'blur',
		),
		'4' => array(
			'label'  => __( 'Coloured tiles', 'journal' ),
			'class'  => 'color',
			'motion' => 'scale',
		),
		'5' => array(
			'label'  => __( 'Documents to download', 'journal' ),
			'class'  => 'cards',
			'motion' => 'slide',
		),
	),
	'only'  => array(
		'logos.note'          => array( '5' ),
		'item_parts.kind'     => array( '5' ),
		'item_parts.arrow'    => array( '4' ),
		'item_parts.download' => array( '5' ),
		'item_parts.note'     => array( '5' ),
	),
);
