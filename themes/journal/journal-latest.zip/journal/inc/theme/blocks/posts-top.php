<?php
/**
 * Block description: the most read and discussed posts.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'11' => array(
			'label'  => __( 'Rating in two columns', 'journal' ),
			'class'  => 'top-a',
			'motion' => 'rise',
		),
		'12' => array(
			'label'  => __( 'Cards with a number', 'journal' ),
			'class'  => 'top-b',
			'motion' => 'rise',
		),
		'13' => array(
			'label'  => __( 'Dark band', 'journal' ),
			'class'  => 'top-c',
			'motion' => 'rise',
		),
		'14' => array(
			'label'  => __( 'Tabs', 'journal' ),
			'class'  => 'top-d',
			'motion' => 'rise',
		),
		'15' => array(
			'label'  => __( 'Leader and list', 'journal' ),
			'class'  => 'top-e',
			'motion' => 'rise',
		),
	),
	'item_parts' => array(
		'date'     => __( 'Date', 'journal' ),
		'read'     => __( 'Reading time', 'journal' ),
		'comments' => __( 'Number of comments', 'journal' ),
		'views'    => __( 'Number of views', 'journal' ),
		'author'   => __( 'Author', 'journal' ),
	),
	'off'        => array(
		'item_parts' => array( 'date', 'read', 'author' ),
	),
	'only'       => array(
		'text'        => array( '11' ),
		'source'      => array( '11', '12', '13', '15' ),
		'tab'         => array( '14' ),
		'count'       => array( '11' ),
		'link_text'   => array(),
		'link_url'    => array(),
		'parts.lead'  => array( '11' ),
		'parts.chips' => array(),
		'parts.hint'  => array(),
		'parts.more'  => array(),
	),
);
