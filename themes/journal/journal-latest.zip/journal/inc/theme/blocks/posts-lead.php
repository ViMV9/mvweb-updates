<?php
/**
 * Block description: the first screen with posts of the blog.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Lead and column', 'journal' ),
			'class'  => 'lead-a',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Cover with text', 'journal' ),
			'class'  => 'lead-b',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Headline without a photo', 'journal' ),
			'class'  => 'lead-c',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Lead and four', 'journal' ),
			'class'  => 'lead-d',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Hello and search', 'journal' ),
			'class'  => 'lead-e',
			'motion' => 'rise',
		),
	),
	'item_parts' => array(
		'date'     => __( 'Date', 'journal' ),
		'read'     => __( 'Reading time', 'journal' ),
		'comments' => __( 'Number of comments', 'journal' ),
		'views'    => __( 'Number of views', 'journal' ),
		'author'   => __( 'Author', 'journal' ),
	),
	'off'        => array(
		'item_parts' => array( 'date', 'read', 'comments', 'views', 'author' ),
	),
	'only'       => array(
		'kicker'       => array( '5' ),
		'title'        => array( '5' ),
		'text'         => array( '5' ),
		'period'       => array( '3' ),
		'count'        => array(),
		'link_text'    => array(),
		'link_url'     => array(),
		'parts.kicker' => array( '5' ),
		'parts.title'  => array( '5' ),
		'parts.lead'   => array( '5' ),
		'parts.chips'  => array(),
		'parts.hint'   => array( '5' ),
		'parts.more'   => array(),
	),
);
