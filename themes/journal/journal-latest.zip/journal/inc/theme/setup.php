<?php
/**
 * Theme setup that belongs to the design: content width, starter home and starter settings.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_load_textdomain' ) ) {
	/**
	 * Load the theme translations from languages/{locale}.mo.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_load_textdomain() {
		load_theme_textdomain( 'journal', MVWEB_THEME_DIR . '/languages' );
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_load_textdomain' );

if ( ! function_exists( 'mvweb_theme_content_width' ) ) {
	/**
	 * Set the global content width.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_content_width() {
		$GLOBALS['content_width'] = 1200;
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_content_width', 0 );

if ( ! function_exists( 'mvweb_theme_image_sizes' ) ) {
	/**
	 * Sizes that keep the ratio of the photo: the covers are cut to the ratio of the look by CSS.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array{0:int,1:int,2:bool}> $sizes Sizes of the core.
	 *
	 * @return array<string,array{0:int,1:int,2:bool}>
	 */
	function mvweb_theme_image_sizes( $sizes ) {
		$sizes['mvweb_card'] = array( 800, 800, false );
		$sizes['mvweb_wide'] = array( 1600, 1600, false );

		return $sizes;
	}
}
add_filter( 'mvweb_core_image_sizes', 'mvweb_theme_image_sizes' );

if ( ! function_exists( 'mvweb_theme_seed_home_rows' ) ) {
	/**
	 * The home page of a fresh activation: the ready-made set «Home · view 1», the band shows the fullest category.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_theme_seed_home_rows() {
		$presets = mvweb_core_section_presets();
		$rows    = isset( $presets['journal-home-1']['rows'] ) ? (array) $presets['journal-home-1']['rows'] : array();
		$top     = get_categories(
			array(
				'orderby' => 'count',
				'order'   => 'DESC',
				'number'  => 1,
				'exclude' => array( (int) get_option( 'default_category' ) ),
			)
		);

		if ( empty( $top ) ) {
			return $rows;
		}

		foreach ( $rows as $i => $row ) {
			if ( in_array( $row['type'], array( 'posts', 'posts-band' ), true ) && (int) $row['props']['view'] >= 16 ) {
				$rows[ $i ]['props']['category'] = (int) $top[0]->term_id;
			}
		}

		return $rows;
	}
}
add_filter( 'mvweb_core_seed_home_rows', 'mvweb_theme_seed_home_rows' );

if ( ! function_exists( 'mvweb_theme_starter_mods' ) ) {
	/**
	 * Settings of the core a magazine starts with until the owner saves their own.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_theme_starter_mods() {
		return array(
			'mvweb_toc'          => true,
			'mvweb_callouts_set' => '1',
			'mvweb_views_count'  => true,
		);
	}
}

if ( ! function_exists( 'mvweb_theme_notfound_parts' ) ) {
	/**
	 * The parts of the page «Not found» that its look shows until the owner saves the composition.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_theme_notfound_parts() {
		$parts = array(
			'1' => array( 'title', 'text', 'search' ),
			'2' => array( 'title', 'text', 'posts' ),
			'3' => array( 'title', 'text', 'similar', 'topics' ),
			'4' => array( 'title', 'text', 'search', 'popular' ),
			'5' => array( 'title', 'text', 'links' ),
		);
		$view  = mvweb_core_area_view( 'notfound' );

		return isset( $parts[ $view ] ) ? $parts[ $view ] : $parts['1'];
	}
}

if ( ! function_exists( 'mvweb_theme_starter_mod' ) ) {
	/**
	 * The starter value of a setting the owner has not saved yet.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Value of the setting.
	 *
	 * @return mixed
	 */
	function mvweb_theme_starter_mod( $value ) {
		$name = substr( current_filter(), strlen( 'theme_mod_' ) );
		$mods = get_theme_mods();

		if ( is_array( $mods ) && array_key_exists( $name, $mods ) ) {
			return $value;
		}

		if ( 'mvweb_layout_notfound' === $name ) {
			return wp_json_encode( mvweb_theme_notfound_parts() );
		}

		$starter = mvweb_theme_starter_mods();

		return array_key_exists( $name, $starter ) ? $starter[ $name ] : $value;
	}
}

if ( ! function_exists( 'mvweb_theme_seed_author_box' ) ) {
	/**
	 * Tick «Show the author block» on a fresh activation, before the core turns the old switches into parts of the composition.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_seed_author_box() {
		$mods = (array) get_theme_mods();

		if ( ! array_key_exists( 'mvweb_switches', $mods ) && ! array_key_exists( 'mvweb_author_box', $mods ) ) {
			set_theme_mod( 'mvweb_author_box', true );
		}
	}
}
add_action( 'after_switch_theme', 'mvweb_theme_seed_author_box' );

foreach ( array( 'mvweb_toc', 'mvweb_callouts_set', 'mvweb_views_count', 'mvweb_layout_notfound' ) as $mvweb_theme_starter ) {
	add_filter( 'theme_mod_' . $mvweb_theme_starter, 'mvweb_theme_starter_mod', 5 );
}
unset( $mvweb_theme_starter );
