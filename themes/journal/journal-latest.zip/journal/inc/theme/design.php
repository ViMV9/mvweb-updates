<?php
/**
 * What the theme tells the core about its design: palettes, the looks of every area, header and widget, the font pair and the rules.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_palette' ) ) {
	/**
	 * One palette: the accent family of the light scheme and of the dark one.
	 *
	 * @since 0.1.0
	 *
	 * @param string               $label Name of the palette.
	 * @param array<string,string> $light Accent, hover, ink and link of the light scheme.
	 * @param array<string,string> $dark  The same four colours of the dark scheme.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_theme_palette( $label, array $light, array $dark ) {
		$names = array(
			'accent' => '--mvweb-t-accent',
			'hover'  => '--mvweb-t-accent-hover',
			'ink'    => '--mvweb-t-accent-ink',
			'link'   => '--mvweb-t-accent-link',
		);
		$out   = array(
			'label'  => $label,
			'tokens' => array(),
			'dark'   => array(),
		);

		foreach ( $names as $key => $token ) {
			$out['tokens'][ $token ] = $light[ $key ];
			$out['dark'][ $token ]   = $dark[ $key ];
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_theme_palettes' ) ) {
	/**
	 * Register the six palettes of the theme; the values are in the head of DESIGN.md.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $palettes Presets so far.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_palettes( $palettes ) {
		if ( 'market' === mvweb_theme_style() ) {
			return array_merge( $palettes, mvweb_theme_market_palettes() );
		}

		$palettes['emerald']    = mvweb_theme_palette(
			__( 'Emerald', 'journal' ),
			array(
				'accent' => '#0b7356',
				'hover'  => '#085a43',
				'ink'    => '#ffffff',
				'link'   => '#0a6a4f',
			),
			array(
				'accent' => '#17946f',
				'hover'  => '#1fa97f',
				'ink'    => '#04140e',
				'link'   => '#6fd3ae',
			)
		);
		$palettes['ink']        = mvweb_theme_palette(
			__( 'Ink blue', 'journal' ),
			array(
				'accent' => '#2747c7',
				'hover'  => '#1e389f',
				'ink'    => '#ffffff',
				'link'   => '#2747c7',
			),
			array(
				'accent' => '#4766e0',
				'hover'  => '#3d5bd6',
				'ink'    => '#ffffff',
				'link'   => '#9db2ff',
			)
		);
		$palettes['terracotta'] = mvweb_theme_palette(
			__( 'Terracotta', 'journal' ),
			array(
				'accent' => '#c2410c',
				'hover'  => '#a2360a',
				'ink'    => '#ffffff',
				'link'   => '#a8390b',
			),
			array(
				'accent' => '#e2571c',
				'hover'  => '#ef6a30',
				'ink'    => '#160803',
				'link'   => '#ffa478',
			)
		);
		$palettes['violet']     = mvweb_theme_palette(
			__( 'Violet', 'journal' ),
			array(
				'accent' => '#6430d0',
				'hover'  => '#5024aa',
				'ink'    => '#ffffff',
				'link'   => '#5d2bc4',
			),
			array(
				'accent' => '#7c4ef0',
				'hover'  => '#6e3fe3',
				'ink'    => '#ffffff',
				'link'   => '#c3a9ff',
			)
		);
		$palettes['red']        = mvweb_theme_palette(
			__( 'Red', 'journal' ),
			array(
				'accent' => '#cc2b26',
				'hover'  => '#a8211d',
				'ink'    => '#ffffff',
				'link'   => '#b4241f',
			),
			array(
				'accent' => '#d0362f',
				'hover'  => '#b8261f',
				'ink'    => '#ffffff',
				'link'   => '#ff9a94',
			)
		);
		$palettes['graphite']   = mvweb_theme_palette(
			__( 'Graphite', 'journal' ),
			array(
				'accent' => '#16171a',
				'hover'  => '#000000',
				'ink'    => '#ffffff',
				'link'   => '#16171a',
			),
			array(
				'accent' => '#f1f0ec',
				'hover'  => '#ffffff',
				'ink'    => '#121315',
				'link'   => '#f1f0ec',
			)
		);

		return $palettes;
	}
}
add_filter( 'mvweb_core_palettes', 'mvweb_theme_palettes' );

if ( ! function_exists( 'mvweb_theme_market_palettes' ) ) {
	/**
	 * The five palettes of the style "Market", the ones of Brand Market; yellow is the default.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_market_palettes() {
		return array(
			'yellow'   => array(
				'label'  => __( 'Yellow', 'journal' ),
				'tokens' => array(
					'--mvweb-t-accent'       => '#ffd60a',
					'--mvweb-t-accent-hover' => '#e8c200',
					'--mvweb-t-accent-ink'   => '#1b1c1f',
					'--mvweb-t-accent-link'  => '#6b5700',
				),
				'dark'   => array(
					'--mvweb-t-accent-hover' => '#ffe047',
					'--mvweb-t-accent-link'  => '#ffd60a',
				),
			),
			'peach'    => array(
				'label'  => __( 'Peach', 'journal' ),
				'tokens' => array(
					'--mvweb-t-accent'       => '#ffb48a',
					'--mvweb-t-accent-hover' => '#f79e6c',
					'--mvweb-t-accent-ink'   => '#1b1c1f',
					'--mvweb-t-accent-link'  => '#9a4a1a',
				),
				'dark'   => array(
					'--mvweb-t-accent-hover' => '#ffc4a3',
					'--mvweb-t-accent-link'  => '#ffb48a',
				),
			),
			'navy'     => array(
				'label'  => __( 'Navy', 'journal' ),
				'tokens' => array(
					'--mvweb-t-accent'       => '#1f3a5f',
					'--mvweb-t-accent-hover' => '#162c49',
					'--mvweb-t-accent-ink'   => '#ffffff',
					'--mvweb-t-accent-link'  => '#1f3a5f',
				),
				'dark'   => array(
					'--mvweb-t-accent'       => '#8db2e6',
					'--mvweb-t-accent-hover' => '#a9c5ee',
					'--mvweb-t-accent-ink'   => '#10141a',
					'--mvweb-t-accent-link'  => '#8db2e6',
				),
			),
			'emerald'  => array(
				'label'  => __( 'Emerald', 'journal' ),
				'tokens' => array(
					'--mvweb-t-accent'       => '#0d6b4e',
					'--mvweb-t-accent-hover' => '#0a5840',
					'--mvweb-t-accent-ink'   => '#ffffff',
					'--mvweb-t-accent-link'  => '#0d6b4e',
				),
				'dark'   => array(
					'--mvweb-t-accent'       => '#4cc9a0',
					'--mvweb-t-accent-hover' => '#6bd8b5',
					'--mvweb-t-accent-ink'   => '#0a1a14',
					'--mvweb-t-accent-link'  => '#4cc9a0',
				),
			),
			'burgundy' => array(
				'label'  => __( 'Burgundy', 'journal' ),
				'tokens' => array(
					'--mvweb-t-accent'       => '#8c1d3f',
					'--mvweb-t-accent-hover' => '#741633',
					'--mvweb-t-accent-ink'   => '#ffffff',
					'--mvweb-t-accent-link'  => '#8c1d3f',
				),
				'dark'   => array(
					'--mvweb-t-accent'       => '#ec8aa5',
					'--mvweb-t-accent-hover' => '#f2a3b8',
					'--mvweb-t-accent-ink'   => '#1a0a10',
					'--mvweb-t-accent-link'  => '#ec8aa5',
				),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_area_views' ) ) {
	/**
	 * Name the five looks of every area; the number is the number of the mockup, the first look is the default.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $areas Areas of the core.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_area_views( $areas ) {
		$views = array(
			'single'   => array(
				__( 'Contents on the left', 'journal' ),
				__( 'Magazine headline', 'journal' ),
				__( 'Cover beside the title', 'journal' ),
				__( 'Card on a coloured head', 'journal' ),
				__( 'Text without a cover', 'journal' ),
				__( 'Column from the first line', 'journal' ),
				__( 'Cover as the background', 'journal' ),
				__( 'Lead beside the cover', 'journal' ),
				__( 'Tinted plate', 'journal' ),
				__( 'Facts on the left', 'journal' ),
			),
			'category' => array(
				__( 'Chips and grid', 'journal' ),
				__( 'Hub with subcategories', 'journal' ),
				__( 'Coloured head', 'journal' ),
				__( 'Category navigation', 'journal' ),
				__( 'Category contents', 'journal' ),
			),
			'author'   => array(
				__( 'Head and grid', 'journal' ),
				__( 'Card on the left', 'journal' ),
				__( 'Dark strip', 'journal' ),
				__( 'Expert with experience', 'journal' ),
				__( 'Text only', 'journal' ),
			),
			'page'     => array(
				__( 'Text in a column', 'journal' ),
				__( 'With a cover', 'journal' ),
				__( 'Rule and drop cap', 'journal' ),
				__( 'Coloured head', 'journal' ),
				__( 'Large title', 'journal' ),
			),
			'contacts' => array(
				__( 'Contacts and map', 'journal' ),
				__( 'Branches and map', 'journal' ),
				__( 'City tabs', 'journal' ),
				__( 'Form and contacts', 'journal' ),
				__( 'Map as a background', 'journal' ),
			),
			'search'   => array(
				__( 'Rows with highlight', 'journal' ),
				__( 'Filters in the column', 'journal' ),
				__( 'Tabs', 'journal' ),
				__( 'By category', 'journal' ),
				__( 'Centred cards', 'journal' ),
			),
			'notfound' => array(
				__( 'Big number', 'journal' ),
				__( 'Picture and popular', 'journal' ),
				__( 'You may have meant', 'journal' ),
				__( 'Dark strip', 'journal' ),
				__( 'Text only', 'journal' ),
			),
			'notice'   => array(
				__( 'Dark with an icon', 'journal' ),
				__( 'Accent, centred', 'journal' ),
				__( 'Light with a label', 'journal' ),
				__( 'Card with margins', 'journal' ),
				__( 'Thin line with a dot', 'journal' ),
			),
			'topics'   => array(
				__( 'Links with a fade', 'journal' ),
				__( 'One topic with a switch', 'journal' ),
				__( 'First topic and “All”', 'journal' ),
				__( 'Numbers in two rows', 'journal' ),
				__( 'Cards that scroll', 'journal' ),
			),
			'mega'     => array(
				__( 'Tabs on the left', 'journal' ),
				__( 'Tabs on top', 'journal' ),
				__( 'Lead article and list', 'journal' ),
				__( 'Dark panel', 'journal' ),
				__( 'Subcategories in columns', 'journal' ),
			),
			'sidebar'  => array(
				__( 'Line under the title', 'journal' ),
				__( 'Cards on a background', 'journal' ),
				__( 'Accent mark on the left', 'journal' ),
				__( 'Frame, title on the line', 'journal' ),
				__( 'Capitals and rules', 'journal' ),
				__( 'Soft cards', 'journal' ),
				__( 'Thin list', 'journal' ),
				__( 'Leader and subscription', 'journal' ),
				__( 'Dark card', 'journal' ),
				__( 'Tiles', 'journal' ),
			),
		);

		foreach ( $views as $area => $names ) {
			$list = array();

			foreach ( $names as $index => $name ) {
				$list[ (string) ( $index + 1 ) ] = ( $index + 1 ) . ' · ' . $name;
			}

			$areas[ $area ]['views'] = $list;
		}

		$areas['notice']['only'] = array( 'mvweb_notice_label' => array( '3', '5' ) );

		return $areas;
	}
}
add_filter( 'mvweb_core_area_views', 'mvweb_theme_area_views' );

if ( ! function_exists( 'mvweb_theme_header_views' ) ) {
	/**
	 * Name the looks of the header: the three of the core and two of the journal.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $views Looks so far.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_header_views( $views ) {
		return array_merge(
			$views,
			array(
				'simple'   => __( '1 · Search in the header', 'journal' ),
				'extended' => __( '2 · Socials on the right, search in the menu row', 'journal' ),
				'compact'  => __( '3 · Menu inline, search as an icon', 'journal' ),
				'rubrics'  => __( '4 · Rubrics beside the logo, links above', 'journal' ),
				'dark'     => __( '5 · Dark, rubrics in the second row', 'journal' ),
			)
		);
	}
}
add_filter( 'mvweb_core_header_views', 'mvweb_theme_header_views' );

if ( ! function_exists( 'mvweb_theme_header_colour_fields' ) ) {
	/**
	 * Two colours of the fourth and fifth looks of the header: the line under the current rubric and the glow of the dark header.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_theme_header_colour_fields( $kit ) {
		$only = array(
			array(
				'setting'  => 'mvweb_header_layout',
				'operator' => 'in',
				'value'    => array( 'rubrics', 'dark' ),
			),
		);

		$kit->add_fields(
			array(
				array(
					'type'        => 'color',
					'settings'    => 'mvweb_header_color_1',
					'section'     => 'mvweb_cz_header_blocks',
					'label'       => __( 'Header colour 1', 'journal' ),
					'description' => __( 'The line under the current rubric and the glow of the dark header start with it. Empty: the accent.', 'journal' ),
					'default'     => '',
					'required'    => $only,
					'output'      => array(
						array(
							'element'  => ':root',
							'property' => '--mvweb-t-header-c1',
						),
					),
				),
				array(
					'type'        => 'color',
					'settings'    => 'mvweb_header_color_2',
					'section'     => 'mvweb_cz_header_blocks',
					'label'       => __( 'Header colour 2', 'journal' ),
					'description' => __( 'They end with it. Empty: the accent under the pointer.', 'journal' ),
					'default'     => '',
					'required'    => $only,
					'output'      => array(
						array(
							'element'  => ':root',
							'property' => '--mvweb-t-header-c2',
						),
					),
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_theme_header_colour_fields' );

if ( ! function_exists( 'mvweb_theme_header_colour_order' ) ) {
	/**
	 * Put the two colours of the header right under the choice of its look.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string[]> $fields Section id => control ids.
	 *
	 * @return array<string,string[]>
	 */
	function mvweb_theme_header_colour_order( $fields ) {
		if ( isset( $fields['mvweb_cz_header_blocks'] ) ) {
			$at = array_search( 'mvweb_header_layout', $fields['mvweb_cz_header_blocks'], true );

			array_splice( $fields['mvweb_cz_header_blocks'], false === $at ? 0 : $at + 1, 0, array( 'mvweb_header_color_1', 'mvweb_header_color_2' ) );
		}

		return $fields;
	}
}
add_filter( 'mvweb_core_customizer_fields', 'mvweb_theme_header_colour_order' );

if ( ! function_exists( 'mvweb_theme_widget_views' ) ) {
	/**
	 * Name the looks of the widgets; the empty key stands for the look of the column.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,string>> $views Looks so far.
	 *
	 * @return array<string,array<string,string>>
	 */
	function mvweb_theme_widget_views( $views ) {
		$column = array( '' => __( 'As the column', 'journal' ) );

		$views['posts']     = $column + array(
			'row'   => __( 'Picture on the left', 'journal' ),
			'num'   => __( 'Numbers', 'journal' ),
			'lead'  => __( 'Large first, then rows', 'journal' ),
			'right' => __( 'Picture on the right', 'journal' ),
			'date'  => __( 'Date above the title', 'journal' ),
			'soft'  => __( 'Thumbnails and categories', 'journal' ),
			'thin'  => __( 'Thin numbers and categories', 'journal' ),
			'top'   => __( 'Cover of the first, numbers', 'journal' ),
			'ring'  => __( 'Outlined numbers', 'journal' ),
			'tiles' => __( 'Tiles', 'journal' ),
		);
		$views['blog_cats'] = $column + array(
			'list'      => __( 'List with subcategories', 'journal' ),
			'chips'     => __( 'Chips', 'journal' ),
			'icons'     => __( 'With category icons', 'journal' ),
			'accordion' => __( 'Expanding list', 'journal' ),
			'dots'      => __( 'Dotted leaders to the number', 'journal' ),
		);
		$views['contacts']  = $column + array(
			'dark'   => __( 'Dark', 'journal' ),
			'light'  => __( 'Light', 'journal' ),
			'accent' => __( 'Accent', 'journal' ),
		);
		$views['help']      = $column + array(
			'card'   => __( 'Card on a light accent', 'journal' ),
			'accent' => __( 'Accent card', 'journal' ),
			'line'   => __( 'Line on the left', 'journal' ),
			'dark'   => __( 'Dark card', 'journal' ),
			'dashed' => __( 'Dashed frame', 'journal' ),
		);

		return $views;
	}
}
add_filter( 'mvweb_core_widget_views', 'mvweb_theme_widget_views' );

if ( ! function_exists( 'mvweb_theme_sitemap_views' ) ) {
	/**
	 * Name the five looks of the sitemap as the mockup draws them; the keys stay those of the core.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $views Looks so far.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_sitemap_views( $views ) {
		$names = array(
			'columns' => __( 'Columns of sections', 'journal' ),
			'tree'    => __( 'Expanding tree', 'journal' ),
			'index'   => __( 'Index from A to Z', 'journal' ),
			'cards'   => __( 'Category cards', 'journal' ),
			'toc'     => __( 'Contents', 'journal' ),
		);

		return array_merge( $views, array_intersect_key( $names, $views ) );
	}
}
add_filter( 'mvweb_core_sitemap_views', 'mvweb_theme_sitemap_views' );

if ( ! function_exists( 'mvweb_theme_blog_views' ) ) {
	/**
	 * Name the eight looks of the list of posts; the first is the default.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_blog_views() {
		return array(
			'journal' => __( '1 · Magazine and grid', 'journal' ),
			'feed'    => __( '2 · Feed by days', 'journal' ),
			'rows'    => __( '3 · List of rows', 'journal' ),
			'wall'    => __( '4 · Wall of cards', 'journal' ),
			'text'    => __( '5 · Text list', 'journal' ),
			'columns' => __( '6 · Columns of posts', 'journal' ),
			'photos'  => __( '7 · Photo rows', 'journal' ),
			'rhythm'  => __( '8 · Large and small rhythm', 'journal' ),
		);
	}
}
add_filter( 'mvweb_core_blog_views', 'mvweb_theme_blog_views' );

if ( ! function_exists( 'mvweb_theme_blog_subcats_views' ) ) {
	/**
	 * Keep the looks of the subcategories the mockup draws and add the tabs and the index.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $views Looks so far.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_blog_subcats_views( $views ) {
		return array_intersect_key( $views, array_flip( array( 'none', 'more', 'cards', 'toc' ) ) ) + array(
			'tabs'  => __( 'Tabs in one row that scroll sideways', 'journal' ),
			'index' => __( 'Index: rows with the number of articles', 'journal' ),
		);
	}
}
add_filter( 'mvweb_core_blog_subcats_views', 'mvweb_theme_blog_subcats_views' );

if ( ! function_exists( 'mvweb_theme_subcats_note' ) ) {
	/**
	 * Tell under the look of the subcategories that a category without them shows nothing.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer manager.
	 *
	 * @return void
	 */
	function mvweb_theme_subcats_note( $wp_customize ) {
		$control = $wp_customize->get_control( 'mvweb_blog_subcats_view' );

		if ( $control ) {
			$control->description = __( 'Above the posts of a category that has subcategories with articles, on its first page. A category without them shows nothing above its posts. The look “None” shows the strip of all categories instead.', 'journal' );
		}
	}
}
add_action( 'customize_register', 'mvweb_theme_subcats_note', 40 );

if ( ! function_exists( 'mvweb_theme_layouts' ) ) {
	/**
	 * Drop the settings of the search the theme does not draw and keep the author off the post cards until the owner ticks it.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $layouts Areas of the composition.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_layouts( $layouts ) {
		unset( $layouts['search.groups'], $layouts['search.empty']['parts']['search'] );

		if ( isset( $layouts['card-post'] ) ) {
			$layouts['card-post']['off'] = array_values( array_unique( array_merge( (array) ( $layouts['card-post']['off'] ?? array() ), array( 'author' ) ) ) );
		}

		return $layouts;
	}
}
add_filter( 'mvweb_core_layouts', 'mvweb_theme_layouts', 20 );

if ( ! function_exists( 'mvweb_theme_supports' ) ) {
	/**
	 * Tell the core which optional parts of it this theme draws.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_supports() {
		add_theme_support( 'mvweb-mega-menu', array( 'items' ) );
		add_theme_support( 'mvweb-subscribe' );
		add_theme_support( 'mvweb-social-meta-note' );
		add_theme_support( 'mvweb-notfound-similar' );
		add_theme_support( 'mvweb-views-period' );
		add_theme_support( 'mvweb-hero-slider-posts' );
		add_theme_support( 'mvweb-categories-blog' );
		add_theme_support( 'mvweb-posts-parts', array( 'chips', 'hint' ) );
		add_theme_support( 'mvweb-card-post', array( 'author', 'comments', 'views' ) );
		add_theme_support( 'mvweb-ad-label' );
		add_theme_support( 'mvweb-banner-second-button' );
		add_theme_support( 'mvweb-banner-pair-extra' );
		add_theme_support( 'mvweb-sidebar-areas', array( 'single', 'author', 'search', 'utility' ) );
		add_theme_support( 'mvweb-post-after', array( 'helpful', 'updated' ) );
		add_theme_support( 'mvweb-callouts', array( 'key', 'sources', 'steps' ) );
		add_theme_support( 'mvweb-blog-views', array( 'rows', 'text' ) );
		add_theme_support( 'mvweb-post-meta', array( 'views', 'comments' ) );
		add_theme_support( 'mvweb-author-head', array( 'role' ) );
		add_theme_support( 'mvweb-notfound-parts', array( 'posts', 'topics', 'links' ) );
		add_theme_support( 'mvweb-widget-subscribe' );
		add_theme_support( 'mvweb-widget-author' );
		add_theme_support( 'mvweb-widget-ad' );
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_supports' );

add_filter( 'mvweb_core_supported_modules', '__return_empty_array' );

if ( ! function_exists( 'mvweb_theme_home_modes' ) ) {
	/**
	 * The homepage of the magazine is always the builder: the feeds are its block of posts.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $modes Looks of the homepage.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_home_modes( $modes ) {
		return array_intersect_key( $modes, array( 'blocks' => true ) );
	}
}
add_filter( 'mvweb_core_home_modes', 'mvweb_theme_home_modes' );

add_filter( 'theme_mod_mvweb_popup_form', '__return_empty_string' );

if ( ! function_exists( 'mvweb_theme_drop_stream_sidebar' ) ) {
	/**
	 * No column beside the feed of the homepage: the homepage is the builder.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_drop_stream_sidebar() {
		unregister_sidebar( 'home-stream' );
	}
}
add_action( 'widgets_init', 'mvweb_theme_drop_stream_sidebar', 30 );

if ( ! function_exists( 'mvweb_theme_customizer_drop' ) ) {
	/**
	 * Take out the fields of what the magazine does not draw: the look of the homepage and the request window.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer manager.
	 *
	 * @return void
	 */
	function mvweb_theme_customizer_drop( $wp_customize ) {
		foreach ( array( 'mvweb_home_mode', 'mvweb_popup_form', 'mvweb_popup_title', 'mvweb_popup_text', 'mvweb_popup_ok_title', 'mvweb_popup_ok_text', 'mvweb_popup_error_title', 'mvweb_popup_error_text' ) as $mvweb_id ) {
			$wp_customize->remove_control( $mvweb_id );
		}
	}
}
add_action( 'customize_register', 'mvweb_theme_customizer_drop', 40 );

if ( ! function_exists( 'mvweb_theme_radius_default' ) ) {
	/**
	 * The corners of the site until the owner picks others.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_theme_radius_default() {
		return '6';
	}
}
add_filter( 'mvweb_core_radius_default', 'mvweb_theme_radius_default' );

if ( ! function_exists( 'mvweb_theme_styles' ) ) {
	/**
	 * The styles of the whole theme: key => name; the first is the default.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_styles() {
		return array(
			'journal' => __( 'Journal: warm tones, the font of your choice', 'journal' ),
			'market'  => __( 'Market: cool greys, round corners, bright accent', 'journal' ),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_style' ) ) {
	/**
	 * The style picked in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @return string One of the keys of mvweb_theme_styles().
	 */
	function mvweb_theme_style() {
		$style = (string) get_theme_mod( 'mvweb_style', 'journal' );

		return isset( mvweb_theme_styles()[ $style ] ) ? $style : 'journal';
	}
}

if ( ! function_exists( 'mvweb_theme_fonts' ) ) {
	/**
	 * The font pairs the owner can pick: key => name; the first is the default.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_fonts() {
		return array(
			'golos'    => __( 'Golos Text', 'journal' ),
			'onest'    => __( 'Onest', 'journal' ),
			'literata' => __( 'Onest, text of the article in Literata', 'journal' ),
			'ptserif'  => __( 'PT Serif, details in Golos Text', 'journal' ),
			'nunito'   => __( 'Nunito, details in Golos Text', 'journal' ),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_font' ) ) {
	/**
	 * The font pair picked in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @return string One of the keys of mvweb_theme_fonts().
	 */
	function mvweb_theme_font() {
		$font = (string) get_theme_mod( 'mvweb_font', 'golos' );

		return isset( mvweb_theme_fonts()[ $font ] ) ? $font : 'golos';
	}
}

if ( ! function_exists( 'mvweb_theme_text_widths' ) ) {
	/**
	 * The widths of the text of an article beside the column of widgets: key => name; the first is the default.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_text_widths() {
		return array(
			'narrow' => __( 'Narrow, easiest to read', 'journal' ),
			'medium' => __( 'Medium', 'journal' ),
			'wide'   => __( 'Up to the column', 'journal' ),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_text_width' ) ) {
	/**
	 * The width of the text picked in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @return string One of the keys of mvweb_theme_text_widths().
	 */
	function mvweb_theme_text_width() {
		$width = (string) get_theme_mod( 'mvweb_text_width', 'narrow' );

		return isset( mvweb_theme_text_widths()[ $width ] ) ? $width : 'narrow';
	}
}

if ( ! function_exists( 'mvweb_theme_lines_on' ) ) {
	/**
	 * Whether the design draws rules instead of plates and shadows.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_theme_lines_on() {
		return (bool) get_theme_mod( 'mvweb_lines', false );
	}
}

if ( ! function_exists( 'mvweb_theme_html_settings' ) ) {
	/**
	 * The attributes of the root element that belong to the theme.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Attribute name => value.
	 */
	function mvweb_theme_html_settings() {
		$palette = (string) mvweb_cz_get( 'mvweb_palette' );

		return array(
			'data-style'      => mvweb_theme_style(),
			'data-font'       => mvweb_theme_font(),
			'data-lines'      => mvweb_theme_lines_on() ? 'on' : 'off',
			'data-palette'    => array_key_exists( $palette, mvweb_core_palettes() ) ? $palette : mvweb_core_default_palette(),
			'data-text-width' => mvweb_theme_text_width(),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_register_fields' ) ) {
	/**
	 * Hand the font pair and the rules to the Customizer Kit, next to the corners and the palette.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_theme_register_fields( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_style',
					'section'     => 'mvweb_cz_design_preset',
					'label'       => __( 'Style', 'journal' ),
					'description' => __( 'The look of the whole site: colours, fonts, corners, buttons and cards. The looks of the pages and blocks stay as they are. "Market" has its own palettes and fonts; save and reopen the Customizer to see its palettes.', 'journal' ),
					'default'     => 'journal',
					'choices'     => mvweb_theme_styles(),
				),
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_font',
					'section'     => 'mvweb_cz_design_preset',
					'label'       => __( 'Fonts', 'journal' ),
					'description' => __( 'The pair of fonts for the headings, the text and the details. All of them are stored in the theme.', 'journal' ),
					'default'     => 'golos',
					'choices'     => mvweb_theme_fonts(),
					'transport'   => 'postMessage',
					'required'    => array(
						array(
							'setting'  => 'mvweb_style',
							'operator' => '!=',
							'value'    => 'market',
						),
					),
				),
				array(
					'type'        => 'toggle',
					'settings'    => 'mvweb_lines',
					'section'     => 'mvweb_cz_design_preset',
					'label'       => __( 'Rules', 'journal' ),
					'description' => __( 'Thin lines instead of plates, borders and shadows; the details in capitals. Off: soft cards.', 'journal' ),
					'default'     => false,
					'transport'   => 'postMessage',
				),
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_text_width',
					'section'     => 'mvweb_cz_inner_single',
					'label'       => __( 'Width of the text beside the column', 'journal' ),
					'description' => __( 'How wide the text of an article runs when the column of widgets stands beside it. Without the column the text stays narrow, so the lines are not too long.', 'journal' ),
					'default'     => 'narrow',
					'choices'     => mvweb_theme_text_widths(),
					'transport'   => 'postMessage',
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_theme_register_fields' );

if ( ! function_exists( 'mvweb_theme_preview_attrs' ) ) {
	/**
	 * Settings the preview applies to the root element without a reload; the looks of the pages and of the column change their markup and reload it.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $attrs Setting => attribute so far.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_preview_attrs( $attrs ) {
		$attrs['mvweb_font']  = 'data-font';
		$attrs['mvweb_lines'] = 'data-lines';

		$attrs['mvweb_text_width'] = 'data-text-width';

		foreach ( array( 'notice', 'topics', 'mega' ) as $area ) {
			$attrs[ 'mvweb_view_' . $area ] = 'data-view-' . $area;
		}

		$attrs['mvweb_header_layout'] = 'data-header-view';

		return $attrs;
	}
}
add_filter( 'mvweb_core_preview_attrs', 'mvweb_theme_preview_attrs' );

if ( ! function_exists( 'mvweb_theme_preview_partials' ) ) {
	/**
	 * Where the parts of the frame stand in the markup, for the edit shortcuts of the preview.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $selectors Selectors so far.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_preview_partials( $selectors ) {
		return array_merge(
			$selectors,
			array(
				'header'  => '[data-header]',
				'notice'  => '.mvweb-t-notice',
				'topics'  => '.mvweb-t-topics',
				'mega'    => '.mvweb-t-mega-menu',
				'footer'  => '.mvweb-t-footer',
				'sidebar' => '.mvweb-t-sidebar',
			)
		);
	}
}
add_filter( 'mvweb_core_preview_partials', 'mvweb_theme_preview_partials' );

if ( ! function_exists( 'mvweb_theme_preload_fonts' ) ) {
	/**
	 * Preload the files of the picked pair that the first screen needs, in the script of the reader.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_preload_fonts() {
		$script = 1 === preg_match( '/^(ru|uk|be|bg|sr|kk)/', get_locale() ) ? 'cyrillic' : 'latin';
		$files  = array(
			'golos'    => array( 'golos-text' ),
			'onest'    => array( 'onest' ),
			'literata' => is_singular() ? array( 'onest', 'literata-normal-' . $script ) : array( 'onest' ),
			'ptserif'  => array( 'pt-serif-normal-400-' . $script, 'pt-serif-normal-700-' . $script, 'golos-text' ),
			'nunito'   => array( 'nunito-normal-' . $script, 'golos-text' ),
		);

		foreach ( 'market' === mvweb_theme_style() ? array( 'onest', 'golos-text' ) : $files[ mvweb_theme_font() ] as $file ) {
			printf( "<link rel=\"preload\" href=\"%s\" as=\"font\" type=\"font/woff2\" crossorigin>\n", esc_url( get_template_directory_uri() . '/assets/fonts/' . $file . '.woff2' ) );
		}
	}
}
add_action( 'wp_head', 'mvweb_theme_preload_fonts', 1 );
