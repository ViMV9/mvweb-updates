<?php
/**
 * Blocks of the theme: the views, the parts and the shell every block template prints.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_blocks' ) ) {
	/**
	 * Descriptions of the block types the theme draws.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>> Type => views, parts, item_parts.
	 */
	function mvweb_theme_blocks() {
		static $blocks = null;

		if ( null === $blocks ) {
			$blocks = array();

			foreach ( (array) glob( MVWEB_THEME_DIR . '/inc/theme/blocks/*.php' ) as $file ) {
				$description = require $file;

				if ( is_array( $description ) ) {
					$blocks[ basename( $file, '.php' ) ] = $description;
				}
			}
		}

		return $blocks;
	}
}

if ( ! function_exists( 'mvweb_theme_block_views' ) ) {
	/**
	 * Give the core the names of the views of a block type.
	 *
	 * @since 0.1.0
	 *
	 * @param array  $views Views so far.
	 * @param string $type  Block type.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_block_views( $views, $type ) {
		$blocks = mvweb_theme_blocks();

		if ( empty( $blocks[ $type ]['views'] ) ) {
			return $views;
		}

		foreach ( $blocks[ $type ]['views'] as $key => $view ) {
			$views[ (string) $key ] = $view['label'];
		}

		return $views;
	}
}
add_filter( 'mvweb_core_section_views', 'mvweb_theme_block_views', 10, 2 );

if ( ! function_exists( 'mvweb_theme_block_parts' ) ) {
	/**
	 * Give the core the parts of the block types and what works in some views only.
	 *
	 * @since 0.1.0
	 *
	 * @param array $table Type => parts, item_parts and only so far.
	 *
	 * @return array<string,array<string,array<string,string>>>
	 */
	function mvweb_theme_block_parts( $table ) {
		foreach ( mvweb_theme_blocks() as $type => $description ) {
			foreach ( array( 'parts', 'item_parts', 'only', 'off' ) as $key ) {
				if ( ! empty( $description[ $key ] ) ) {
					$table[ $type ][ $key ] = $description[ $key ];
				}
			}

			if ( empty( array_filter( array_column( isset( $description['views'] ) ? $description['views'] : array(), 'motion' ) ) ) ) {
				$table[ $type ]['only']['motion'] = array();
			}
		}

		return $table;
	}
}
add_filter( 'mvweb_core_section_parts', 'mvweb_theme_block_parts' );

if ( ! function_exists( 'mvweb_theme_block' ) ) {
	/**
	 * Everything a block template needs to know about the row it prints.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type Block type.
	 * @param array  $args Arguments the core passes to the template.
	 *
	 * @return array{type:string,props:array,view:string,mod:string,motion:string,look:array,parts:string[],item_parts:string[]}
	 */
	function mvweb_theme_block( $type, array $args ) {
		$props       = isset( $args['props'] ) && is_array( $args['props'] ) ? $args['props'] : array();
		$description = mvweb_theme_blocks();
		$description = isset( $description[ $type ] ) ? $description[ $type ] : array();
		$views       = isset( $description['views'] ) ? $description['views'] : array();
		$view        = mvweb_core_view( $props );

		if ( ! isset( $views[ $view ] ) ) {
			$view = (string) array_key_first( $views );
		}

		$current = isset( $views[ $view ] ) ? $views[ $view ] : array();

		return array(
			'type'       => $type,
			'props'      => $props,
			'view'       => $view,
			'mod'        => isset( $current['class'] ) ? (string) $current['class'] : '',
			'motion'     => mvweb_core_motion( $props, isset( $current['motion'] ) ? (string) $current['motion'] : '' ),
			'look'       => mvweb_core_section_look( $props ),
			'parts'      => mvweb_core_parts( $props ),
			'item_parts' => mvweb_core_parts( $props, 'item_parts' ),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_cards_colours' ) ) {
	/**
	 * Own colours of the cards and the icons of a block with a background.
	 *
	 * @since 0.1.0
	 *
	 * @param array $block Result of mvweb_theme_block(); its style gets the colours.
	 *
	 * @return string Classes of the section, each after a space.
	 */
	function mvweb_theme_cards_colours( array &$block ) {
		if ( 'plain' === $block['look']['background'] ) {
			return '';
		}

		$classes = '';
		$names   = array(
			'cards' => array( 'cards', '--mvweb-t-cards-bg', '--mvweb-t-cards-ink' ),
			'icon'  => array( 'icons', '--mvweb-t-cards-icon', '--mvweb-t-cards-icon-ink' ),
		);

		foreach ( mvweb_core_cards_colours( $block['props'] ) as $what => $colour ) {
			$classes                .= ' mvweb-t-' . $block['type'] . '--own-' . $names[ $what ][0];
			$block['look']['style'] .= $names[ $what ][1] . ':' . $colour['bg'] . ';' . $names[ $what ][2] . ':' . $colour['ink'] . ';';
		}

		return $classes;
	}
}

if ( ! function_exists( 'mvweb_theme_section_open' ) ) {
	/**
	 * Print the opening tags of a block: the section and, unless the view is full-bleed, the container.
	 *
	 * @since 0.1.0
	 *
	 * @param array  $block     Result of mvweb_theme_block().
	 * @param bool   $container Whether the container opens with the section.
	 * @param string $extra     Extra classes of the section.
	 *
	 * @return void
	 */
	function mvweb_theme_section_open( array $block, $container = true, $extra = '' ) {
		$class = 'mvweb-t-section mvweb-t-' . $block['type'];

		if ( '' !== $block['mod'] ) {
			$class .= ' mvweb-t-' . $block['type'] . '--' . $block['mod'];
		}

		if ( '' !== $extra ) {
			$class .= ' ' . $extra;
		}

		foreach ( mvweb_core_part_colours( $block['props'] ) as $part => $colour ) {
			$class                  .= ' mvweb-t-section--own-' . $part;
			$block['look']['style'] .= '--mvweb-t-own-' . $part . ':' . $colour['bg'] . ';--mvweb-t-own-' . $part . '-ink:' . $colour['ink'] . ';';
		}

		$background = $block['look']['background'];
		?>
		<section class="<?php echo esc_attr( $class ); ?>"<?php echo 'plain' !== $background ? ' data-bg="' . esc_attr( $background ) . '"' : ''; ?><?php echo '' !== $block['motion'] ? ' data-motion="' . esc_attr( $block['motion'] ) . '"' : ''; ?><?php echo '' !== $block['look']['style'] ? ' style="' . esc_attr( $block['look']['style'] ) . '"' : ''; ?>>
		<?php if ( $container ) : ?>
			<div class="mvweb-t-container"<?php echo '' !== $block['motion'] ? ' data-rv' : ''; ?>>
		<?php endif; ?>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_section_close' ) ) {
	/**
	 * Print the closing tags of a block.
	 *
	 * @since 0.1.0
	 *
	 * @param bool $container Whether the container was opened with the section.
	 *
	 * @return void
	 */
	function mvweb_theme_section_close( $container = true ) {
		if ( $container ) {
			echo '</div>';
		}

		echo '</section>';
	}
}

if ( ! function_exists( 'mvweb_theme_head' ) ) {
	/**
	 * Print the head of a block from the head parts that are switched on.
	 *
	 * @since 0.1.0
	 *
	 * @param array $block Result of mvweb_theme_block().
	 * @param array $slugs Head parts to print, in order.
	 * @param array $args  Optional. Keys: class (extra classes of the head), rv (bool, texts appear with the block), side (string, ready markup printed after the text, e.g. arrows or a button), title_tag (string, h1 when the heading is the h1 of the page).
	 *
	 * @return bool Whether anything was printed.
	 */
	function mvweb_theme_head( array $block, array $slugs, array $args = array() ) {
		$props  = $block['props'];
		$text   = array();
		$more   = '';
		$rv     = ! empty( $args['rv'] ) && '' !== $block['motion'];
		$tag    = isset( $args['title_tag'] ) && 'h1' === $args['title_tag'] ? 'h1' : 'div';
		$side   = isset( $args['side'] ) ? trim( (string) $args['side'] ) : '';
		$fields = array(
			'kicker' => 'kicker',
			'title'  => 'title',
			'lead'   => 'text',
		);

		foreach ( $slugs as $slug ) {
			if ( isset( $fields[ $slug ] ) && ! empty( $props[ $fields[ $slug ] ] ) ) {
				$text[ $slug ] = (string) $props[ $fields[ $slug ] ];
			}
		}

		if ( in_array( 'more', $slugs, true ) && ! empty( $props['link_text'] ) && ! empty( $props['link_url'] ) ) {
			$more = '<a class="mvweb-t-section__more" href="' . esc_url( (string) $props['link_url'] ) . '">' . esc_html( (string) $props['link_text'] ) . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>';
		}

		if ( empty( $text ) && '' === $more && '' === $side ) {
			return false;
		}

		$class = trim( 'mvweb-t-section__head ' . ( isset( $args['class'] ) ? (string) $args['class'] : '' ) );
		?>
		<div class="<?php echo esc_attr( $class ); ?>">
			<?php if ( ! empty( $text ) ) : ?>
				<div<?php echo $rv ? ' data-rv' : ''; ?>>
					<?php foreach ( $text as $slug => $value ) : ?>
						<?php if ( 'kicker' === $slug ) : ?>
							<span class="mvweb-t-kicker"><?php echo esc_html( $value ); ?></span>
						<?php elseif ( 'title' === $slug && 'h1' === $tag ) : ?>
							<h1 class="mvweb-t-h2"><?php echo esc_html( $value ); ?></h1>
						<?php elseif ( 'title' === $slug ) : ?>
							<div class="mvweb-t-h2" role="heading" aria-level="2"><?php echo esc_html( $value ); ?></div>
						<?php else : ?>
							<p class="mvweb-t-section__desc"><?php echo esc_html( $value ); ?></p>
						<?php endif; ?>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<?php echo $more; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
			<?php echo $side; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup built and escaped by the caller. ?>
		</div>
		<?php

		return true;
	}
}

if ( ! function_exists( 'mvweb_theme_render_parts' ) ) {
	/**
	 * Print the parts of a block in the order the editor set.
	 *
	 * @since 0.1.0
	 *
	 * @param array $block     Result of mvweb_theme_block().
	 * @param array $renderers Slug => callable( array $block ) that prints the part.
	 * @param array $head      Optional. Arguments of mvweb_theme_head().
	 *
	 * @return void
	 */
	function mvweb_theme_render_parts( array $block, array $renderers, array $head = array() ) {
		$pending = array();
		$side    = isset( $head['side'] ) ? (string) $head['side'] : '';

		foreach ( array_merge( $block['parts'], array( '' ) ) as $slug ) {
			if ( in_array( $slug, array( 'kicker', 'title', 'lead', 'more' ), true ) ) {
				$pending[] = $slug;
				continue;
			}

			if ( ! empty( $pending ) || ( '' === $slug && '' !== $side ) ) {
				mvweb_theme_head( $block, $pending, array_merge( $head, array( 'side' => $side ) ) );
				$pending = array();
				$side    = '';
			}

			if ( '' !== $slug && isset( $renderers[ $slug ] ) && is_callable( $renderers[ $slug ] ) ) {
				call_user_func( $renderers[ $slug ], $block );
			}
		}
	}
}

if ( ! function_exists( 'mvweb_theme_render_item_parts' ) ) {
	/**
	 * Print the parts of one item of a list in the order the editor set.
	 *
	 * @since 0.1.0
	 *
	 * @param array $block     Result of mvweb_theme_block().
	 * @param array $item      One row of the list.
	 * @param array $renderers Slug => callable( array $item, array $block ) that prints the part.
	 *
	 * @return void
	 */
	function mvweb_theme_render_item_parts( array $block, array $item, array $renderers ) {
		foreach ( $block['item_parts'] as $slug ) {
			if ( isset( $renderers[ $slug ] ) && is_callable( $renderers[ $slug ] ) ) {
				call_user_func( $renderers[ $slug ], $item, $block );
			}
		}
	}
}

if ( ! function_exists( 'mvweb_theme_posts_h1' ) ) {
	/**
	 * The welcome view of the first screen asks for the h1 of the front page when its heading is shown.
	 *
	 * @since 0.1.0
	 *
	 * @param bool   $asks  Whether the block prints the heading.
	 * @param string $type  Block type.
	 * @param array  $props Saved values of the block.
	 *
	 * @return bool
	 */
	function mvweb_theme_posts_h1( $asks, $type, $props ) {
		if ( ! in_array( $type, array( 'posts', 'posts-lead' ), true ) ) {
			return $asks;
		}

		$props = mvweb_core_section_props( $type, (array) $props );

		return '5' === mvweb_core_view( $props ) && '' !== trim( (string) ( isset( $props['title'] ) ? $props['title'] : '' ) ) && in_array( 'title', mvweb_core_parts( $props ), true );
	}
}
add_filter( 'mvweb_core_h1_first_screen', 'mvweb_theme_posts_h1', 10, 3 );

if ( ! function_exists( 'mvweb_theme_hide_posts_block' ) ) {
	/**
	 * The general block «Blog posts» stays for the rows saved before, the editor offers the four narrow ones instead.
	 *
	 * @since 0.1.0
	 *
	 * @param bool   $drawn Whether the theme draws the type.
	 * @param string $type  Block type.
	 *
	 * @return bool
	 */
	function mvweb_theme_hide_posts_block( $drawn, $type ) {
		return 'posts' === $type ? false : $drawn;
	}
}
add_filter( 'mvweb_core_section_editable', 'mvweb_theme_hide_posts_block', 10, 2 );

if ( ! function_exists( 'mvweb_theme_split_posts_rows' ) ) {
	/**
	 * Rows of the general block «Blog posts» get the narrow block of their look, a source the block lacks gives way to its first one.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,mixed> $rows Saved rows.
	 *
	 * @return array<int,mixed>
	 */
	function mvweb_theme_split_posts_rows( array $rows ) {
		foreach ( $rows as $i => $row ) {
			if ( ! is_array( $row ) || ! isset( $row['type'] ) || 'posts' !== $row['type'] ) {
				continue;
			}

			$props      = isset( $row['props'] ) && is_array( $row['props'] ) ? $row['props'] : array();
			$view       = isset( $props['view'] ) ? (int) $props['view'] : 1;
			$type       = $view <= 5 ? 'posts-lead' : ( $view <= 10 ? 'posts-latest' : ( $view <= 15 ? 'posts-top' : 'posts-band' ) );
			$definition = mvweb_core_get_section( $type );
			$source     = isset( $props['source'] ) ? (string) $props['source'] : 'latest';

			if ( $definition && ! isset( $definition['fields']['source']['choices'][ $source ] ) ) {
				$source = $definition['fields']['source']['default'];
			}

			$props['source']     = $source;
			$rows[ $i ]['type']  = $type;
			$rows[ $i ]['props'] = $props;
		}

		return $rows;
	}
}

if ( ! function_exists( 'mvweb_theme_split_posts' ) ) {
	/**
	 * Once after the update: the saved rows of «Blog posts» on the home page, the pages and the categories move to the narrow blocks.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_split_posts() {
		if ( get_theme_mod( 'mvweb_posts_split' ) ) {
			return;
		}

		$home = json_decode( (string) get_theme_mod( 'mvweb_home_rows', '' ), true, 10 );

		if ( is_array( $home ) && mvweb_theme_split_posts_rows( $home ) !== $home ) {
			set_theme_mod( 'mvweb_home_rows', wp_json_encode( mvweb_theme_split_posts_rows( $home ) ) );
		}

		$args = array(
			'meta_key' => '_mvweb_sections', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Runs once after the update.
			'fields'   => 'ids',
		);

		$posts = get_posts(
			$args + array(
				'post_type'   => mvweb_core_section_post_types(),
				'post_status' => 'any',
				'numberposts' => -1,
			)
		);

		foreach ( $posts as $id ) {
			$rows = get_post_meta( $id, '_mvweb_sections', true );

			if ( is_array( $rows ) && mvweb_theme_split_posts_rows( $rows ) !== $rows ) {
				update_post_meta( $id, '_mvweb_sections', wp_slash( mvweb_theme_split_posts_rows( $rows ) ) );
			}
		}

		$terms = get_terms(
			$args + array(
				'taxonomy'   => mvweb_core_section_taxonomies(),
				'hide_empty' => false,
			)
		);

		foreach ( is_array( $terms ) ? $terms : array() as $id ) {
			$rows = get_term_meta( $id, '_mvweb_sections', true );

			if ( is_array( $rows ) && mvweb_theme_split_posts_rows( $rows ) !== $rows ) {
				update_term_meta( $id, '_mvweb_sections', wp_slash( mvweb_theme_split_posts_rows( $rows ) ) );
			}
		}

		set_theme_mod( 'mvweb_posts_split', true );
	}
}
add_action( 'admin_init', 'mvweb_theme_split_posts' );
