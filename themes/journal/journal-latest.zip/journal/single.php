<?php
/**
 * Single entry in five looks.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	$mvweb_view  = mvweb_core_area_view( 'single' );
	$mvweb_view  = in_array( $mvweb_view, array( '1', '2', '3', '4', '5', '6', '7', '8', '9', '10' ), true ) ? $mvweb_view : '1';
	$mvweb_title = mvweb_core_alt_h1();
	$mvweb_title = '' !== $mvweb_title ? $mvweb_title : get_the_title();
	$mvweb_looks = array(
		'1'  => 'toc',
		'2'  => 'center',
		'3'  => 'split',
		'4'  => 'band',
		'5'  => 'plain',
		'6'  => 'column',
		'7'  => 'hero',
		'8'  => 'lead',
		'9'  => 'tint',
		'10' => 'rail',
	);
	$mvweb_sizes = array(
		'1'  => '(min-width: 1024px) 42rem, 100vw',
		'2'  => '(min-width: 1304px) 1240px, 100vw',
		'3'  => '(min-width: 1024px) 50vw, 100vw',
		'4'  => '(min-width: 1024px) 42rem, 100vw',
		'5'  => '100vw',
		'6'  => '(min-width: 1024px) 860px, 100vw',
		'7'  => '100vw',
		'8'  => '(min-width: 1024px) 45vw, 100vw',
		'9'  => '(min-width: 1024px) 45vw, 100vw',
		'10' => '(min-width: 1024px) 700px, 100vw',
	);
	$mvweb_look  = $mvweb_looks[ $mvweb_view ];
	$mvweb_head  = mvweb_core_blog_layout_html(
		'post-head',
		array(
			'sizes' => $mvweb_sizes[ $mvweb_view ],
			'cover' => in_array( $mvweb_view, array( '2', '7' ), true ) ? 'wide' : '',
		)
	);
	$mvweb_meta  = mvweb_core_blog_layout_html( 'post-meta' );
	$mvweb_kick  = '';
	$mvweb_cover = isset( $mvweb_head['cover'] ) && '5' !== $mvweb_view ? $mvweb_head['cover'] : '';
	$mvweb_lead  = '';
	$mvweb_top   = '';
	$mvweb_line  = false;

	unset( $mvweb_head['cover'] );

	if ( in_array( $mvweb_view, array( '2', '7', '9' ), true ) && isset( $mvweb_meta['topic'] ) ) {
		$mvweb_kick = $mvweb_meta['topic'];
		unset( $mvweb_meta['topic'] );
	} elseif ( in_array( $mvweb_view, array( '1', '3', '4', '6', '8', '10' ), true ) && mvweb_core_layout_has( 'page-hero', 'crumbs' ) ) {
		unset( $mvweb_meta['topic'] );
	}

	$mvweb_facts = empty( $mvweb_meta ) ? '' : '<div class="mvweb-t-meta mvweb-t-ahead__facts">' . implode( '', $mvweb_meta ) . '</div>';

	foreach ( $mvweb_head as $mvweb_slug => $mvweb_html ) {
		if ( 'lead' === $mvweb_slug && '4' === $mvweb_view ) {
			$mvweb_lead = $mvweb_html;
		} elseif ( 'byline' === $mvweb_slug && '5' !== $mvweb_view ) {
			$mvweb_top .= '<div class="mvweb-t-ahead__byline">' . $mvweb_html . $mvweb_facts . '</div>';
			$mvweb_line = true;
		} else {
			$mvweb_top .= $mvweb_html;
		}
	}

	if ( ! $mvweb_line && '5' !== $mvweb_view && '' !== $mvweb_facts ) {
		$mvweb_top .= '<div class="mvweb-t-ahead__byline">' . $mvweb_facts . '</div>';
	}

	ob_start();
	the_content();
	$mvweb_text = (string) ob_get_clean();
	$mvweb_toc  = '';

	if ( '1' === $mvweb_view && preg_match( '#<details[^>]*\sdata-toc[^>]*>.*?</details>#s', $mvweb_text, $mvweb_found ) ) {
		$mvweb_toc  = $mvweb_found[0];
		$mvweb_text = str_replace( $mvweb_found[0], '', $mvweb_text );
	}

	if ( in_array( $mvweb_view, array( '8', '10' ), true ) && ! isset( $mvweb_head['lead'] ) && mvweb_core_layout_has( 'post-head', 'lead' ) && preg_match( '#^\s*<p>(.+?)</p>#s', $mvweb_text, $mvweb_found ) ) {
		$mvweb_first = trim( wp_strip_all_tags( $mvweb_found[1] ) );

		if ( '' !== $mvweb_first ) {
			$mvweb_top  = '<p class="mvweb-t-ahead__lead">' . esc_html( $mvweb_first ) . '</p>' . $mvweb_top;
			$mvweb_text = substr( $mvweb_text, strlen( $mvweb_found[0] ) );
		}
	}

	$mvweb_inside = in_array( $mvweb_view, array( '6', '10' ), true );

	$mvweb_rows = array();
	$mvweb_pair = '';

	foreach ( mvweb_core_blog_layout_html( 'post-after' ) as $mvweb_slug => $mvweb_html ) {
		if ( in_array( $mvweb_slug, array( 'share', 'updated' ), true ) ) {
			$mvweb_pair .= $mvweb_html;
			continue;
		}

		if ( '' !== $mvweb_pair ) {
			$mvweb_rows[] = '<div class="mvweb-t-after__row">' . $mvweb_pair . '</div>';
			$mvweb_pair   = '';
		}

		$mvweb_rows[] = $mvweb_html;
	}

	if ( '' !== $mvweb_pair ) {
		$mvweb_rows[] = '<div class="mvweb-t-after__row">' . $mvweb_pair . '</div>';
	}
	?>

	<article <?php post_class( 'mvweb-t-article mvweb-t-article--' . $mvweb_look ); ?>>
		<?php
		ob_start();
		?>
		<header class="mvweb-t-ahead mvweb-t-ahead--<?php echo esc_attr( $mvweb_look ); ?>">
			<?php if ( '7' === $mvweb_view && '' !== $mvweb_cover ) : ?>
				<div class="mvweb-t-ahead__bg"><?php echo $mvweb_cover; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template. ?></div>
			<?php endif; ?>
			<div class="<?php echo esc_attr( $mvweb_inside ? 'mvweb-t-ahead__inner' : 'mvweb-t-container mvweb-t-ahead__inner' ); ?>">
				<?php
				get_template_part( 'template-parts/crumbs' );

				if ( '5' === $mvweb_view ) {
					echo $mvweb_facts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates.
				}

				echo $mvweb_kick; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template.
				?>
				<h1 class="mvweb-t-page-title mvweb-t-ahead__title"><?php echo esc_html( $mvweb_title ); ?></h1>
				<?php
				echo $mvweb_top; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates.

				if ( in_array( $mvweb_view, array( '2', '3', '6', '8', '9', '10' ), true ) ) {
					echo $mvweb_cover; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template.
				}
				?>
			</div>
		</header>
		<?php
		$mvweb_header = (string) ob_get_clean();

		if ( ! $mvweb_inside ) {
			echo $mvweb_header; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built above from escaped parts.
		}

		mvweb_theme_layout_open( mvweb_core_sidebar_area(), 'mvweb-t-layout--' . $mvweb_look );

		if ( $mvweb_inside ) {
			echo $mvweb_header; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built above from escaped parts.
		}
		?>

		<div class="mvweb-t-article__body<?php echo '' !== $mvweb_toc ? ' mvweb-t-article__body--toc' : ''; ?>">
			<?php
			echo $mvweb_toc; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the template of the table of contents.

			if ( in_array( $mvweb_view, array( '1', '4' ), true ) ) {
				echo $mvweb_cover; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template.
			}

			echo $mvweb_lead; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template.
			?>

			<div class="mvweb-t-prose mvweb-t-article__text<?php echo '2' === $mvweb_view ? ' mvweb-t-dropcap' : ''; ?>" data-prose>
				<?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The text of the entry after the filters of the content. ?>
			</div>

			<?php
			wp_link_pages(
				array(
					'before' => '<nav class="mvweb-t-article__pages" aria-label="' . esc_attr__( 'Page parts', 'journal' ) . '">',
					'after'  => '</nav>',
				)
			);
			?>

			<?php if ( ! empty( $mvweb_rows ) ) : ?>
				<div class="mvweb-t-after"><?php echo implode( '', $mvweb_rows ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?></div>
			<?php endif; ?>
		</div>

		<?php mvweb_theme_layout_close( mvweb_core_sidebar_area() ); ?>
	</article>

	<?php
	mvweb_core_render_layout( 'post-below', array( 'view' => $mvweb_view ) );
	mvweb_core_render_context_sections();
endwhile;

get_footer();
