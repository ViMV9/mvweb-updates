<?php
/**
 * Nothing at this address, in five looks.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_view  = mvweb_core_area_view( 'notfound' );
$mvweb_class = 'mvweb-t-404 mvweb-t-404--' . $mvweb_view . ( '4' === $mvweb_view ? ' mvweb-t-section--inverse' : '' );

get_header();

mvweb_theme_layout_open( mvweb_core_sidebar_area() );
?>

<div class="<?php echo esc_attr( $mvweb_class ); ?>">
	<?php
	get_template_part( 'template-parts/crumbs' );

	if ( ! mvweb_core_layout_has( 'notfound', 'title' ) ) {
		get_template_part( 'template-parts/notfound/title', null, array( 'hidden' => true ) );
	}

	mvweb_core_render_layout( 'notfound', array( 'view' => $mvweb_view ) );
	?>

	<?php if ( in_array( $mvweb_view, array( '1', '2' ), true ) ) : ?>
		<a class="<?php echo esc_attr( 'mvweb-t-btn mvweb-t-404__home' . ( '2' === $mvweb_view ? ' mvweb-t-btn--outline' : '' ) ); ?>" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'To the homepage', 'journal' ); ?></a>
	<?php endif; ?>
</div>

<?php
mvweb_theme_layout_close( mvweb_core_sidebar_area() );

get_footer();
