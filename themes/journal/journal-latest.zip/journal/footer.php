<?php
/**
 * Footer.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_view = mvweb_theme_footer_view();

ob_start();
if ( 'columns' === $mvweb_view ) {
	mvweb_core_render_zone( 'footer-main' );
} else {
	get_template_part( 'template-parts/footer/' . $mvweb_view );
}
$mvweb_columns = trim( (string) ob_get_clean() );

ob_start();
mvweb_core_render_zone( 'footer-bottom' );
$mvweb_bottom = trim( (string) ob_get_clean() );
?>
</main>

<footer data-footer class="mvweb-t-footer mvweb-t-footer--<?php echo esc_attr( $mvweb_view ); ?>"<?php echo is_customize_preview() ? ' data-mvweb-cz-section="mvweb_cz_footer_blocks"' : ''; ?>>
	<?php get_template_part( 'template-parts/footer-map' ); ?>

	<?php if ( '' !== $mvweb_columns && 'columns' === $mvweb_view ) : ?>
		<div class="mvweb-t-container mvweb-t-footer__main">
			<?php echo $mvweb_columns; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped element templates. ?>
		</div>
	<?php elseif ( '' !== $mvweb_columns ) : ?>
		<?php echo $mvweb_columns; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped templates of the look. ?>
	<?php endif; ?>

	<?php if ( '' !== $mvweb_bottom ) : ?>
		<div class="mvweb-t-footer__bottom">
			<div class="mvweb-t-container mvweb-t-footer__bottom-row">
				<?php echo $mvweb_bottom; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped element templates. ?>
			</div>
		</div>
	<?php endif; ?>
</footer>

<button class="mvweb-t-totop" data-totop type="button" title="<?php esc_attr_e( 'Back to top', 'journal' ); ?>">
	<?php echo mvweb_theme_icon( 'arrow-up' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<span class="screen-reader-text"><?php esc_html_e( 'Back to top', 'journal' ); ?></span>
</button>

<?php get_template_part( 'template-parts/subscribe-popover' ); ?>

<?php wp_footer(); ?>
</body>
</html>
