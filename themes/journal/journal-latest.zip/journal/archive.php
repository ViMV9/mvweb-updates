<?php
/**
 * A category, a tag and an archive by dates in the frame of the category.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_title   = mvweb_core_alt_h1();
$mvweb_frame   = mvweb_core_area_view( 'category' );
$mvweb_area    = mvweb_core_sidebar_area();
$mvweb_looks   = array(
	'3' => array( 'band' ),
	'5' => array( 'rule' ),
);
$mvweb_chips   = array();
$mvweb_subcats = array();
$mvweb_text    = '';
$mvweb_eyebrow = '';

if ( is_category() ) {
	$mvweb_tiles = mvweb_core_blog_subcats();
	$mvweb_kind  = mvweb_core_blog_subcats_view();
	$mvweb_title = '' !== $mvweb_title ? $mvweb_title : single_cat_title( '', false );
	$mvweb_text  = is_paged() ? '' : mvweb_core_term_text( get_queried_object_id() );

	if ( 'none' === $mvweb_kind ) {
		$mvweb_chips = array( 'kind' => 'topics' );
	} elseif ( empty( $mvweb_tiles ) ) {
		$mvweb_chips = array();
	} elseif ( 'more' === $mvweb_kind ) {
		$mvweb_chips = array(
			'kind'  => 'subcats',
			'tiles' => $mvweb_tiles,
		);
	} else {
		$mvweb_subcats = array(
			'tiles' => $mvweb_tiles,
			'view'  => 'cards' === $mvweb_kind ? 'tiles' : $mvweb_kind,
		);
	}
} elseif ( is_tag() ) {
	$mvweb_eyebrow = __( 'Tag', 'journal' );
	$mvweb_title   = '' !== $mvweb_title ? $mvweb_title : single_tag_title( '', false );
} elseif ( is_date() ) {
	$mvweb_chips = array( 'kind' => 'months' );
	$mvweb_title = '' !== $mvweb_title ? $mvweb_title : mvweb_core_blog_date_title();
}

if ( '' === $mvweb_title ) {
	$mvweb_title = wp_strip_all_tags( get_the_archive_title() );
}

$mvweb_after = '';

if ( ! empty( $mvweb_chips ) ) {
	ob_start();
	get_template_part( 'template-parts/blog/chips', null, $mvweb_chips );
	$mvweb_after = (string) ob_get_clean();
} elseif ( isset( $mvweb_subcats['view'] ) && 'tabs' === $mvweb_subcats['view'] ) {
	ob_start();
	get_template_part( 'template-parts/blog/subcats', null, $mvweb_subcats );
	$mvweb_after   = (string) ob_get_clean();
	$mvweb_subcats = array();
}

get_header();

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'title'   => $mvweb_title,
		'eyebrow' => mvweb_core_blog_hero_has( 'eyebrow' ) ? $mvweb_eyebrow : '',
		'lead'    => mvweb_core_blog_hero_has( 'lead' ) && ! is_paged() ? wp_strip_all_tags( get_the_archive_description() ) : '',
		'meta'    => '3' === $mvweb_frame && mvweb_core_blog_hero_has( 'meta' ) ? mvweb_core_blog_archive_facts() : array(),
		'after'   => $mvweb_after,
		'looks'   => isset( $mvweb_looks[ $mvweb_frame ] ) ? $mvweb_looks[ $mvweb_frame ] : array(),
	)
);

mvweb_theme_layout_open( $mvweb_area );

if ( ! empty( $mvweb_subcats ) ) {
	get_template_part( 'template-parts/blog/subcats', null, $mvweb_subcats );
}

get_template_part(
	'template-parts/post-list',
	null,
	array(
		'view'              => mvweb_core_blog_view(),
		'text'              => $mvweb_text,
		'empty_icon'        => 'checklist',
		'empty_title'       => __( 'This section is empty', 'journal' ),
		'empty_text'        => __( 'There are no entries here yet. Have a look at the other sections.', 'journal' ),
		'empty_button_url'  => home_url( '/' ),
		'empty_button_text' => __( 'To the homepage', 'journal' ),
	)
);

mvweb_theme_layout_close( $mvweb_area );

mvweb_core_render_context_sections();

get_footer();
