<?php
/**
 * Theme setup that belongs to the design: content width, starter home.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_load_textdomain' ) ) {
	/**
	 * Load the theme translations from languages/{locale}.mo.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_load_textdomain() {
		load_theme_textdomain( 'brand-market', MVWEB_THEME_DIR . '/languages' );
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_load_textdomain' );

if ( ! function_exists( 'mvweb_theme_content_width' ) ) {
	/**
	 * Set the global content width.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_content_width() {
		$GLOBALS['content_width'] = 1200;
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_content_width', 0 );

if ( ! function_exists( 'mvweb_theme_mega_menu' ) ) {
	/**
	 * Say that this theme draws the mega menu from the catalogue sections, not from the fields of the menu items.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_mega_menu() {
		add_theme_support( 'mvweb-mega-menu', array( 'catalog' ) );
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_mega_menu' );

if ( ! function_exists( 'mvweb_theme_supports' ) ) {
	/**
	 * Declare the parts of the core the theme draws.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_supports() {
		add_theme_support( 'mvweb-icons' );
		add_theme_support( 'mvweb-bottom-nav' );
		add_theme_support( 'mvweb-swatches' );
		add_theme_support( 'mvweb-sidebar-areas', array( 'single', 'author', 'search' ) );
		add_theme_support( 'mvweb-views-period' );
		add_theme_support( 'mvweb-widget-ad' );
		add_theme_support( 'mvweb-subscribe', array( 'mail' => false ) );
		add_theme_support( 'mvweb-social-meta-note' );
		add_theme_support( 'mvweb-widget-subscribe' );
		add_theme_support( 'mvweb-widget-author' );
		add_theme_support( 'mvweb-card-post', array( 'author', 'comments', 'views' ) );
		add_theme_support( 'mvweb-accent-2' );
		add_theme_support( 'mvweb-count-color' );
		add_theme_support( 'mvweb-menu-icon-color' );
		add_theme_support( 'mvweb-strip-color' );
		add_theme_support( 'mvweb-nav-messengers' );
		add_theme_support( 'mvweb-related-view' );
		add_theme_support( 'mvweb-product-photo' );
		add_theme_support( 'mvweb-viewed' );
		add_theme_support( 'mvweb-footer-badge-bare' );
		add_theme_support( 'mvweb-footer-badge-align' );
		add_theme_support( 'mvweb-footer-badge-logo' );
		add_theme_support( 'mvweb-hero-plate-clear' );
		add_theme_support( 'mvweb-catalog-per-page' );
		add_theme_support( 'mvweb-cards-any-background' );
		add_theme_support( 'mvweb-services-all-sections' );
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_supports' );

if ( ! function_exists( 'mvweb_theme_unused_controls' ) ) {
	/**
	 * Take out the fields of the core the theme does not draw: the head of the services pages has no picture, a service card has a square one and an arrow instead of the words of the link.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer manager.
	 *
	 * @return void
	 */
	function mvweb_theme_unused_controls( $wp_customize ) {
		$wp_customize->remove_control( 'mvweb_service_list_image' );
		$wp_customize->remove_control( 'mvweb_service_card_shape' );
		$wp_customize->remove_control( 'mvweb_service_card_more' );
	}
}
add_action( 'customize_register', 'mvweb_theme_unused_controls', 999 );
