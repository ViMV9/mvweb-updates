<?php
/**
 * Nothing at this address.
 *
 * The parts of the page are the layout "notfound"; the two buttons under them
 * lead back into the site.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$mvweb_catalog = ( post_type_exists( 'mv_item' ) || mvweb_core_is_woocommerce() ) ? mvweb_core_catalog_page_url() : '';
?>

<section class="mvweb-t-section mvweb-t-notfound">
	<div class="mvweb-t-container">
		<?php mvweb_core_render_layout( 'notfound' ); ?>

		<div class="mvweb-t-notfound__actions">
			<a class="mvweb-t-btn" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php esc_html_e( 'To the homepage', 'brand-market' ); ?></a>
			<?php if ( '' !== $mvweb_catalog ) : ?>
				<a class="mvweb-t-btn mvweb-t-btn--outline" href="<?php echo esc_url( $mvweb_catalog ); ?>"><?php esc_html_e( 'To the catalogue', 'brand-market' ); ?></a>
			<?php endif; ?>
		</div>
	</div>
</section>

<?php
get_footer();
