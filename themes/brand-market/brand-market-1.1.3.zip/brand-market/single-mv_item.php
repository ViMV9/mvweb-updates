<?php
/**
 * Catalogue item page of a site without WooCommerce.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	get_template_part( 'template-parts/catalog/single', null, array( 'id' => get_the_ID() ) );
endwhile;

get_footer();
