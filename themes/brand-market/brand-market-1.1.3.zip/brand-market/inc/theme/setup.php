<?php
/**
 * Theme setup that belongs to the design: content width, starter home.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_load_textdomain' ) ) {
	/**
	 * Load the theme translations from languages/{locale}.mo.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_load_textdomain() {
		load_theme_textdomain( 'brand-market', MVWEB_THEME_DIR . '/languages' );
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_load_textdomain' );

if ( ! function_exists( 'mvweb_theme_content_width' ) ) {
	/**
	 * Set the global content width.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_content_width() {
		$GLOBALS['content_width'] = 1200;
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_content_width', 0 );

if ( ! function_exists( 'mvweb_theme_mega_menu' ) ) {
	/**
	 * Say that this theme draws the mega menu from the catalogue sections, not from the fields of the menu items.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_mega_menu() {
		add_theme_support( 'mvweb-mega-menu', array( 'catalog' ) );
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_mega_menu' );

if ( ! function_exists( 'mvweb_theme_supports' ) ) {
	/**
	 * Declare the parts of the core the theme draws.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_supports() {
		add_theme_support( 'mvweb-icons' );
		add_theme_support( 'mvweb-swatches' );
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_supports' );
