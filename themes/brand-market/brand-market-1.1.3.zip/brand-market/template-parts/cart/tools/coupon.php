<?php
/**
 * Cart tools, part: the field for a promo code.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! wc_coupons_enabled() ) {
	return;
}
?>
<div class="mvweb-t-coupon coupon">
	<label class="screen-reader-text" for="coupon_code"><?php esc_html_e( 'Promo code', 'brand-market' ); ?></label>
	<input class="mvweb-t-field__input input-text" id="coupon_code" type="text" name="coupon_code" value="" placeholder="<?php esc_attr_e( 'Promo code', 'brand-market' ); ?>" autocomplete="off">
	<button class="mvweb-t-btn mvweb-t-btn--outline" type="submit" name="apply_coupon" value="<?php esc_attr_e( 'Apply', 'brand-market' ); ?>"><?php esc_html_e( 'Apply', 'brand-market' ); ?></button>
	<?php do_action( 'woocommerce_cart_coupon' ); ?>
</div>
