<?php
/**
 * Cart tools, part: the way back to the catalogue and the button that empties the cart.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="mvweb-t-cart__links">
	<a class="mvweb-t-cart__back" href="<?php echo esc_url( mvweb_core_catalog_page_url() ); ?>">
		<?php echo mvweb_theme_icon( 'arrow-left', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<?php esc_html_e( 'Continue shopping', 'brand-market' ); ?>
	</a>
	<button class="mvweb-t-cart__clear" type="submit" name="mvweb_clear_cart" value="1"><?php esc_html_e( 'Empty the cart', 'brand-market' ); ?></button>
</div>
