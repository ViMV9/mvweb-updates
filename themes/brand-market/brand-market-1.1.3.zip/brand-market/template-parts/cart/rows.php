<?php
/**
 * The rows of an order total: the goods, the promo codes, the delivery, the fees, the taxes and the sum.
 *
 * The same rows stand in the cart and in the review of the checkout.
 *
 * Arguments: context (cart or checkout).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_context = isset( $args['context'] ) && 'checkout' === $args['context'] ? 'checkout' : 'cart';
$mvweb_cart    = WC()->cart;
?>
<dl class="mvweb-t-summary__rows">
	<div class="cart-subtotal">
		<dt>
			<?php
			/* translators: %d: number of goods in the cart. */
			echo esc_html( sprintf( __( 'Goods (%d pos.)', 'brand-market' ), mvweb_core_cart_positions() ) );
			?>
		</dt>
		<dd><?php wc_cart_totals_subtotal_html(); ?></dd>
	</div>

	<?php foreach ( $mvweb_cart->get_coupons() as $mvweb_code => $mvweb_coupon ) : ?>
		<?php
		$mvweb_amount = (float) $mvweb_cart->get_coupon_discount_amount( $mvweb_code, $mvweb_cart->display_cart_ex_tax );
		$mvweb_value  = $mvweb_amount > 0 ? '&minus;' . wc_price( $mvweb_amount ) : '';
		$mvweb_value  = apply_filters( 'woocommerce_coupon_discount_amount_html', $mvweb_value, $mvweb_coupon ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
		?>
		<div class="cart-discount coupon-<?php echo esc_attr( sanitize_title( $mvweb_code ) ); ?>">
			<dt>
				<?php esc_html_e( 'Promo code', 'brand-market' ); ?>
				<span class="mvweb-t-summary__code"><?php echo esc_html( wc_format_coupon_code( $mvweb_coupon->get_code() ) ); ?>
					<a class="woocommerce-remove-coupon" role="button" href="<?php echo esc_url( add_query_arg( 'remove_coupon', rawurlencode( $mvweb_coupon->get_code() ), 'checkout' === $mvweb_context ? wc_get_checkout_url() : wc_get_cart_url() ) ); ?>" data-coupon="<?php echo esc_attr( $mvweb_coupon->get_code() ); ?>" title="<?php esc_attr_e( 'Remove promo code', 'brand-market' ); ?>">
						<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
						<span class="screen-reader-text"><?php esc_html_e( 'Remove promo code', 'brand-market' ); ?></span>
					</a>
				</span>
			</dt>
			<dd class="mvweb-t-summary__minus"><?php echo wp_kses_post( $mvweb_value ); ?></dd>
		</div>
	<?php endforeach; ?>

	<?php if ( $mvweb_cart->needs_shipping() ) : ?>
		<?php
		$mvweb_packages = mvweb_core_shipping_rates();
		$mvweb_shown    = $mvweb_cart->show_shipping() && ! empty( $mvweb_packages );
		$mvweb_fee      = (float) $mvweb_cart->get_shipping_total() + ( $mvweb_cart->display_prices_including_tax() ? (float) $mvweb_cart->get_shipping_tax() : 0 );
		?>
		<?php if ( $mvweb_shown ) : ?>
			<?php do_action( 'cart' === $mvweb_context ? 'woocommerce_cart_totals_before_shipping' : 'woocommerce_review_order_before_shipping' ); ?>
			<div class="shipping">
				<dt><?php esc_html_e( 'Delivery', 'brand-market' ); ?></dt>
				<dd><?php echo $mvweb_fee > 0 ? wp_kses_post( wc_price( $mvweb_fee ) ) : esc_html__( 'Free', 'brand-market' ); ?></dd>
			</div>
			<?php do_action( 'cart' === $mvweb_context ? 'woocommerce_cart_totals_after_shipping' : 'woocommerce_review_order_after_shipping' ); ?>
		<?php else : ?>
			<div class="shipping">
				<dt><?php esc_html_e( 'Delivery', 'brand-market' ); ?></dt>
				<dd class="mvweb-t-summary__later"><?php echo 'checkout' === $mvweb_context ? esc_html__( 'After the address', 'brand-market' ) : esc_html__( 'At checkout', 'brand-market' ); ?></dd>
			</div>
		<?php endif; ?>
	<?php endif; ?>

	<?php foreach ( $mvweb_cart->get_fees() as $mvweb_fee_row ) : ?>
		<div class="fee">
			<dt><?php echo esc_html( $mvweb_fee_row->name ); ?></dt>
			<dd><?php wc_cart_totals_fee_html( $mvweb_fee_row ); ?></dd>
		</div>
	<?php endforeach; ?>

	<?php if ( wc_tax_enabled() && ! $mvweb_cart->display_prices_including_tax() ) : ?>
		<?php if ( 'itemized' === get_option( 'woocommerce_tax_total_display' ) ) : ?>
			<?php foreach ( $mvweb_cart->get_tax_totals() as $mvweb_tax_code => $mvweb_tax ) : ?>
				<div class="tax-rate tax-rate-<?php echo esc_attr( sanitize_title( $mvweb_tax_code ) ); ?>">
					<dt><?php echo esc_html( $mvweb_tax->label ); ?></dt>
					<dd><?php echo wp_kses_post( $mvweb_tax->formatted_amount ); ?></dd>
				</div>
			<?php endforeach; ?>
		<?php else : ?>
			<div class="tax-total">
				<dt><?php echo esc_html( WC()->countries->tax_or_vat() ); ?></dt>
				<dd><?php wc_cart_totals_taxes_total_html(); ?></dd>
			</div>
		<?php endif; ?>
	<?php endif; ?>
</dl>

<?php do_action( 'cart' === $mvweb_context ? 'woocommerce_cart_totals_before_order_total' : 'woocommerce_review_order_before_order_total' ); ?>
<p class="mvweb-t-summary__total order-total">
	<span><?php esc_html_e( 'Total', 'brand-market' ); ?></span>
	<span class="mvweb-t-summary__amount"><?php wc_cart_totals_order_total_html(); ?></span>
</p>
<?php do_action( 'cart' === $mvweb_context ? 'woocommerce_cart_totals_after_order_total' : 'woocommerce_review_order_after_order_total' ); ?>
