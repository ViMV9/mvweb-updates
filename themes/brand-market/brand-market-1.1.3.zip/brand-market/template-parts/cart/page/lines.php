<?php
/**
 * Cart page, part: the lines, their tools and the order total beside them.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="mvweb-t-section mvweb-t-section--flush-top">
	<div class="mvweb-t-container mvweb-t-order">
		<form class="woocommerce-cart-form mvweb-t-order__main" action="<?php echo esc_url( wc_get_cart_url() ); ?>" method="post">
			<?php do_action( 'woocommerce_before_cart_table' ); ?>
			<div class="mvweb-t-cart woocommerce-cart-form__contents">
				<?php
				do_action( 'woocommerce_before_cart_contents' );

				foreach ( WC()->cart->get_cart() as $mvweb_key => $mvweb_item ) {
					get_template_part(
						'template-parts/cart/line',
						null,
						array(
							'key'  => $mvweb_key,
							'item' => $mvweb_item,
						)
					);
				}

				do_action( 'woocommerce_cart_contents' );
				?>
			</div>
			<?php
			$mvweb_tools = mvweb_core_layout_html( 'cart.tools' );

			if ( '' !== $mvweb_tools ) :
				?>
				<div class="mvweb-t-cart__tools">
					<?php echo $mvweb_tools; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the parts, escaped where it is printed. ?>
				</div>
			<?php endif; ?>
			<button class="screen-reader-text" type="submit" name="update_cart" value="<?php esc_attr_e( 'Update cart', 'brand-market' ); ?>" disabled><?php esc_html_e( 'Update cart', 'brand-market' ); ?></button>
			<?php do_action( 'woocommerce_cart_actions' ); ?>
			<?php wp_nonce_field( 'woocommerce-cart', 'woocommerce-cart-nonce' ); ?>
			<?php do_action( 'woocommerce_after_cart_contents' ); ?>
			<?php do_action( 'woocommerce_after_cart_table' ); ?>
		</form>
		<?php
		do_action( 'woocommerce_before_cart_collaterals' );
		woocommerce_cart_totals();
		?>
	</div>
</section>
