<?php
/**
 * Cart page, part: the goods bought together with those in the cart.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_limit = absint( mvweb_core_cart_option( 'mvweb_cart_cross_count' ) );
$mvweb_ids   = array();

foreach ( $mvweb_limit > 0 ? WC()->cart->get_cross_sells() : array() as $mvweb_id ) {
	if ( mvweb_core_item_visible( absint( $mvweb_id ) ) ) {
		$mvweb_ids[] = absint( $mvweb_id );
	}
}

$mvweb_ids   = array_slice( $mvweb_ids, 0, $mvweb_limit );
$mvweb_title = trim( (string) mvweb_core_cart_option( 'mvweb_cart_cross_title' ) );

if ( empty( $mvweb_ids ) ) {
	return;
}
?>
<section class="mvweb-t-section mvweb-t-section--tight mvweb-t-related mvweb-t-cart-cross" data-bg="surface">
	<div class="mvweb-t-container">
		<?php if ( '' !== $mvweb_title ) : ?>
			<div class="mvweb-t-section-head">
				<div class="mvweb-t-section-head__text">
					<div class="mvweb-t-section-head__title mvweb-t-h2" role="heading" aria-level="2"><?php echo esc_html( $mvweb_title ); ?></div>
				</div>
			</div>
		<?php endif; ?>
		<div class="mvweb-t-grid mvweb-t-catalog__grid">
			<?php foreach ( $mvweb_ids as $mvweb_id ) : ?>
				<?php
				get_template_part(
					'template-parts/catalog/card',
					null,
					array(
						'id' => $mvweb_id,
					)
				);
				?>
			<?php endforeach; ?>
		</div>
	</div>
</section>
