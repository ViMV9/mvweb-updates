<?php
/**
 * Cart summary, part: the short promises under the checkout button.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_notes = array_filter(
	mvweb_core_cart_rows( 'mvweb_cart_notes' ),
	static function ( $row ) {
		return ! empty( $row['text'] );
	}
);

if ( empty( $mvweb_notes ) ) {
	return;
}
?>
<ul class="mvweb-t-summary__notes">
	<?php foreach ( $mvweb_notes as $mvweb_note ) : ?>
		<li>
			<?php echo '' !== $mvweb_note['icon'] ? mvweb_theme_icon( $mvweb_note['icon'], array( 'class' => 'mvweb-t-icon--sm' ) ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<?php echo esc_html( $mvweb_note['text'] ); ?>
		</li>
	<?php endforeach; ?>
</ul>
