<?php
/**
 * Listing head part: the chips of the filter pages of a category, or the values of the filter page shown.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_chips = mvweb_core_listing_chips();

if ( empty( $mvweb_chips['items'] ) ) {
	return;
}
?>
<div class="<?php echo esc_attr( '' === $mvweb_chips['reset'] ? 'mvweb-t-chips mvweb-t-chips--scroll' : 'mvweb-t-chips' ); ?>">
	<?php foreach ( $mvweb_chips['items'] as $mvweb_chip ) : ?>
		<?php if ( $mvweb_chip['current'] ) : ?>
			<span class="mvweb-t-chip" aria-current="true"><?php echo esc_html( $mvweb_chip['label'] ); ?></span>
		<?php else : ?>
			<a class="mvweb-t-chip" href="<?php echo esc_url( $mvweb_chip['url'] ); ?>"><?php echo esc_html( $mvweb_chip['label'] ); ?></a>
		<?php endif; ?>
	<?php endforeach; ?>
	<?php if ( '' !== $mvweb_chips['reset'] ) : ?>
		<a class="mvweb-t-chip" href="<?php echo esc_url( $mvweb_chips['reset'] ); ?>"><?php esc_html_e( 'Clear the choice', 'brand-market' ); ?></a>
	<?php endif; ?>
</div>
