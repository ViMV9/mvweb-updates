<?php
/**
 * Listing head part: the text under the heading.
 *
 * A short text reads as the lead; a description with lists and links keeps
 * its markup. It follows the switch of the text under the heading of a page.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! mvweb_core_layout_has( 'page-hero', 'lead' ) ) {
	return;
}

$mvweb_lead  = isset( $args['lead'] ) ? trim( (string) $args['lead'] ) : '';
$mvweb_intro = isset( $args['intro'] ) ? trim( (string) $args['intro'] ) : '';
?>
<?php if ( '' !== $mvweb_lead ) : ?>
	<p class="mvweb-t-page-hero__lead"><?php echo esc_html( $mvweb_lead ); ?></p>
<?php endif; ?>

<?php if ( '' !== $mvweb_intro ) : ?>
	<div class="mvweb-t-prose mvweb-t-page-hero__intro" data-prose><?php echo wp_kses_post( $mvweb_intro ); ?></div>
<?php endif; ?>
