<?php
/**
 * Product sections: the tabs other plugins add to a WooCommerce product, each as a section of its own.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! mvweb_core_is_woocommerce() ) {
	return;
}

$mvweb_tabs = array_diff_key(
	(array) apply_filters( 'woocommerce_product_tabs', array() ), // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
	array_flip( array( 'description', 'additional_information', 'reviews' ) )
);

foreach ( $mvweb_tabs as $mvweb_key => $mvweb_tab ) :
	if ( empty( $mvweb_tab['callback'] ) || ! is_callable( $mvweb_tab['callback'] ) ) {
		continue;
	}

	ob_start();
	call_user_func( $mvweb_tab['callback'], $mvweb_key, $mvweb_tab );
	$mvweb_html = trim( (string) ob_get_clean() );

	if ( '' === $mvweb_html ) {
		continue;
	}

	$mvweb_odd = isset( $args['state'] ) ? (int) $args['state']['n'] % 2 : 0;

	if ( isset( $args['state'] ) ) {
		$args['state']['n'] = (int) $args['state']['n'] + 1;
	}
	?>
	<section class="mvweb-t-section mvweb-t-product-body" id="<?php echo esc_attr( 'tab-' . sanitize_html_class( $mvweb_key ) ); ?>"<?php echo $mvweb_odd ? ' data-bg="surface"' : ''; ?>>
		<div class="mvweb-t-container">
			<?php if ( ! empty( $mvweb_tab['title'] ) ) : ?>
				<div class="mvweb-t-section-head">
					<div class="mvweb-t-section-head__title mvweb-t-h2" role="heading" aria-level="2"><?php echo wp_kses_post( $mvweb_tab['title'] ); ?></div>
				</div>
			<?php endif; ?>
			<div class="mvweb-t-prose mvweb-t-product-content"><?php echo $mvweb_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the plugin that added the tab. ?></div>
		</div>
	</section>
	<?php
endforeach;
