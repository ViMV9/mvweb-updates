<?php
/**
 * The window with the terms of the wholesale price, once at the end of the page.
 *
 * Arguments: html, the terms cleaned by the core.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_html = isset( $args['html'] ) ? (string) $args['html'] : '';

if ( '' === $mvweb_html ) {
	return;
}
?>
<dialog class="mvweb-t-modal" aria-labelledby="mvweb-t-wholesale-title" data-wholesale-info>
	<div class="mvweb-t-modal__box">
		<button class="mvweb-t-round mvweb-t-modal__close" type="button" data-wholesale-close title="<?php esc_attr_e( 'Close', 'brand-market' ); ?>">
			<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span class="screen-reader-text"><?php esc_html_e( 'Close', 'brand-market' ); ?></span>
		</button>

		<div class="mvweb-t-modal__view">
			<div class="mvweb-t-modal__title mvweb-t-h2" role="heading" aria-level="2" id="mvweb-t-wholesale-title"><?php echo esc_html( mvweb_core_wholesale_label() ); ?></div>
			<div class="mvweb-t-modal__lead"><?php echo wp_kses_post( $mvweb_html ); ?></div>
		</div>
	</div>
</dialog>
