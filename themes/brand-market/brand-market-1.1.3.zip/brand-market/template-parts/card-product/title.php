<?php
/**
 * Product card part: the name, a link to the item.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $args['id'] ) ) {
	return;
}

mvweb_theme_card_group( $args, 'info' );
?>
<div class="mvweb-t-card__title mvweb-t-h3"><a href="<?php echo esc_url( get_permalink( absint( $args['id'] ) ) ); ?>"><?php echo esc_html( get_the_title( absint( $args['id'] ) ) ); ?></a></div>
