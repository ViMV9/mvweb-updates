<?php
/**
 * Product card part: the button.
 *
 * In a shop it puts the item in the cart, in a showcase it asks for the
 * price. A product the shop cannot sell now, without a price or a simple one
 * out of stock, shows the cart button switched off. A block may word the button itself and turn it into a form opener.
 * A listing asks for the quantity field as well (argument qty): the table look
 * of the listing shows it before the button.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : 0;

if ( 0 === $mvweb_id ) {
	return;
}

$mvweb_own     = isset( $args['button'] ) && is_array( $args['button'] ) ? $args['button'] : array();
$mvweb_text    = isset( $mvweb_own['text'] ) ? trim( (string) $mvweb_own['text'] ) : '';
$mvweb_form    = isset( $mvweb_own['action'] ) && 'form' === $mvweb_own['action'];
$mvweb_product = mvweb_core_shop_mode() ? mvweb_core_wc_item( $mvweb_id ) : null;
$mvweb_class   = 'mvweb-t-btn mvweb-t-btn--sm mvweb-t-btn--block';
$mvweb_url     = isset( $mvweb_own['url'] ) && '' !== trim( (string) $mvweb_own['url'] ) ? trim( (string) $mvweb_own['url'] ) : (string) get_theme_mod( 'mvweb_cta_url', '' );
$mvweb_cta     = '' !== $mvweb_text ? $mvweb_text : (string) get_theme_mod( 'mvweb_cta_text', __( 'Request a quote', 'brand-market' ) );
$mvweb_attrs   = '';
$mvweb_qty     = array();
$mvweb_off     = false;

if ( $mvweb_form ) {
	$mvweb_attrs = ' class="' . esc_attr( $mvweb_class ) . '" type="button" data-showcase-form="' . esc_attr( get_the_title( $mvweb_id ) ) . '"';
	$mvweb_label = $mvweb_cta;
} elseif ( $mvweb_product ) {
	$mvweb_ready = $mvweb_product->is_purchasable() && $mvweb_product->is_in_stock();
	$mvweb_data  = array(
		'href'            => $mvweb_product->add_to_cart_url(),
		'rel'             => 'nofollow',
		'data-product_id' => $mvweb_product->get_id(),
		'aria-label'      => wp_strip_all_tags( $mvweb_product->add_to_cart_description() ),
		'class'           => $mvweb_class . ' product_type_' . $mvweb_product->get_type() . ( $mvweb_ready ? ' add_to_cart_button' : '' ) . ( $mvweb_ready && $mvweb_product->supports( 'ajax_add_to_cart' ) ? ' ajax_add_to_cart' : '' ),
	);

	if ( $mvweb_ready ) {
		$mvweb_data['data-quantity']    = mvweb_core_quantity_rules( $mvweb_id )['min'];
		$mvweb_data['data-product_sku'] = $mvweb_product->get_sku();
	}

	foreach ( $mvweb_data as $mvweb_key => $mvweb_value ) {
		$mvweb_attrs .= ' ' . $mvweb_key . '="' . ( 'href' === $mvweb_key ? esc_url( (string) $mvweb_value ) : esc_attr( (string) $mvweb_value ) ) . '"';
	}

	$mvweb_label = '' !== $mvweb_text ? $mvweb_text : wp_strip_all_tags( $mvweb_product->add_to_cart_text() );
	$mvweb_off   = $mvweb_product->is_type( 'variable' ) ? ! $mvweb_product->is_purchasable() : ! $mvweb_ready && $mvweb_product->is_type( 'simple' );

	if ( $mvweb_off ) {
		$mvweb_label = wp_strip_all_tags( $mvweb_product->single_add_to_cart_text() );
	}

	if ( ! empty( $args['qty'] ) && $mvweb_ready && $mvweb_product->is_type( 'simple' ) && ! $mvweb_product->is_sold_individually() && mvweb_core_layout_has( 'card-product', 'qty' ) ) {
		$mvweb_rules = mvweb_core_quantity_rules( $mvweb_id );
		$mvweb_qty   = array(
			'min'  => $mvweb_rules['min'],
			'step' => $mvweb_rules['step'],
			'max'  => max( 0, (int) $mvweb_product->get_max_purchase_quantity() ),
		);
	}
} elseif ( '' !== $mvweb_url && '' !== $mvweb_cta ) {
	$mvweb_attrs = ' class="' . esc_attr( $mvweb_class ) . '" href="' . esc_url( $mvweb_url ) . '" data-request="' . esc_attr( get_the_title( $mvweb_id ) ) . '"';
	$mvweb_label = $mvweb_cta;
} else {
	return;
}

mvweb_theme_card_group( $args, 'foot' );
?>
<div class="mvweb-t-card__buy">
	<?php if ( ! empty( $mvweb_qty ) ) : ?>
		<div class="mvweb-t-qty" data-qty data-min="<?php echo (int) $mvweb_qty['min']; ?>" data-step="<?php echo (int) $mvweb_qty['step']; ?>" data-max="<?php echo (int) $mvweb_qty['max']; ?>">
			<button class="mvweb-t-qty__btn" type="button" data-qty-minus title="<?php esc_attr_e( 'Less', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'minus', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Less', 'brand-market' ); ?></span>
			</button>
			<input class="mvweb-t-qty__input" type="text" inputmode="numeric" value="<?php echo (int) $mvweb_qty['min']; ?>" data-qty-input aria-label="<?php esc_attr_e( 'Quantity', 'brand-market' ); ?>">
			<button class="mvweb-t-qty__btn" type="button" data-qty-plus title="<?php esc_attr_e( 'More', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'plus', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'More', 'brand-market' ); ?></span>
			</button>
		</div>
	<?php endif; ?>
	<?php if ( $mvweb_off ) : ?>
		<button class="<?php echo esc_attr( $mvweb_class ); ?>" type="button" aria-disabled="true"><?php echo esc_html( $mvweb_label ); ?></button>
	<?php elseif ( $mvweb_form ) : ?>
		<button<?php echo $mvweb_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Every value is escaped above. ?>><?php echo esc_html( $mvweb_label ); ?></button>
	<?php elseif ( $mvweb_product ) : ?>
		<?php
		echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Every value is escaped above; plugins return escaped markup.
			'woocommerce_loop_add_to_cart_link', // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
			'<a' . $mvweb_attrs . '>' . esc_html( $mvweb_label ) . '</a>',
			$mvweb_product,
			array(
				'quantity'   => isset( $mvweb_data['data-quantity'] ) ? $mvweb_data['data-quantity'] : 1,
				'class'      => $mvweb_data['class'],
				'attributes' => array_diff_key( $mvweb_data, array_flip( array( 'href', 'class' ) ) ),
			)
		);
		?>
	<?php else : ?>
		<a<?php echo $mvweb_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Every value is escaped above. ?>><?php echo esc_html( $mvweb_label ); ?></a>
	<?php endif; ?>
</div>
