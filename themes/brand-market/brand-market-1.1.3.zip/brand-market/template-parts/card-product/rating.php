<?php
/**
 * Product card part: the rating and the number of reviews.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rating = isset( $args['id'] ) ? mvweb_core_item_rating( absint( $args['id'] ) ) : array();

if ( empty( $mvweb_rating ) ) {
	return;
}

mvweb_theme_card_group( $args, 'info' );
?>
<span class="mvweb-t-rating">
	<?php echo mvweb_theme_icon( 'star-filled', array( 'class' => 'mvweb-t-icon--fill' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<?php echo esc_html( number_format_i18n( $mvweb_rating['value'], 1 ) ); ?>
	<span class="mvweb-t-rating__count">(<?php echo (int) $mvweb_rating['count']; ?>)</span>
</span>
