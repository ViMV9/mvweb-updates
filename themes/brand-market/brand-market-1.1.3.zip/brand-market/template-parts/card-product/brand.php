<?php
/**
 * Product card part: the brand above the name.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_brand = isset( $args['id'] ) ? mvweb_core_item_brand( absint( $args['id'] ) ) : '';

if ( '' === $mvweb_brand ) {
	return;
}

mvweb_theme_card_group( $args, 'info' );
?>
<span class="mvweb-t-card__brand"><?php echo esc_html( $mvweb_brand ); ?></span>
