<?php
/**
 * Work blocks part: the slider between the photos before and after.
 *
 * The block is the classic view with one pair; the modifier single lays the
 * pair beside its caption.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_props = mvweb_core_work_pair( absint( $args['id'] ) );

if ( empty( $mvweb_props ) ) {
	return;
}

ob_start();
mvweb_core_render_section( 'before-after', $mvweb_props );
echo preg_replace( '/\bmvweb-t-before-after--classic\b/', 'mvweb-t-before-after--classic mvweb-t-before-after--single', (string) ob_get_clean(), 1 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the block, escaped there; only a class is added.
