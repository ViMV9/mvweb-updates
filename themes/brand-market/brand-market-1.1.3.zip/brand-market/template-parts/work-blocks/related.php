<?php
/**
 * Work blocks part: the other works under the page.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_link = trim( (string) mvweb_core_works_option( 'mvweb_work_related_link' ) );

get_template_part(
	'template-parts/work/grid',
	null,
	array(
		'title'     => (string) mvweb_core_works_option( 'mvweb_work_related_title' ),
		'ids'       => mvweb_core_work_related( absint( $args['id'] ) ),
		'link_text' => $mvweb_link,
		'link_url'  => (string) get_post_type_archive_link( 'mv_work' ),
		'surface'   => true,
	)
);
