<?php
/**
 * Services listing: the archive itself and any of its sections.
 *
 * The head takes the text of the listing: the description of a section, or the
 * line set in the Customizer for the archive. A section adds the number of its
 * services and its points under the text. What follows the head, the strip of
 * subsections and the list, comes from the service-list layout. No filter
 * sidebar: a site has dozens of services, not hundreds, and a filter over a
 * list that fits on two screens is furniture rather than help.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_term  = get_queried_object() instanceof WP_Term ? get_queried_object() : null;
$mvweb_title = mvweb_core_alt_h1();

if ( '' === $mvweb_title ) {
	$mvweb_title = mvweb_core_service_title();
}

$mvweb_lead  = '';
$mvweb_intro = '';
$mvweb_meta  = array();

if ( $mvweb_term ) {
	$mvweb_image = absint( get_term_meta( $mvweb_term->term_id, 'thumbnail_id', true ) );
	$mvweb_intro = trim( (string) mvweb_core_listing_intro() );

	if ( 1 === preg_match( '#^<p>[^<]*</p>$#u', $mvweb_intro ) ) {
		$mvweb_lead  = wp_specialchars_decode( wp_strip_all_tags( $mvweb_intro ), ENT_QUOTES );
		$mvweb_intro = '';
	}

	foreach ( mvweb_core_layout_order( 'service-hero' ) as $mvweb_slug ) {
		if ( 'count' === $mvweb_slug && mvweb_core_service_count( $mvweb_term->term_id ) > 0 ) {
			$mvweb_total  = mvweb_core_service_count( $mvweb_term->term_id );
			$mvweb_meta[] = sprintf(
				/* translators: %s: number of services in the section. */
				_n( '%s service', '%s services', $mvweb_total, 'brand-market' ),
				number_format_i18n( $mvweb_total )
			);
		} elseif ( 'points' === $mvweb_slug ) {
			$mvweb_meta = array_merge( $mvweb_meta, mvweb_core_service_points( $mvweb_term->term_id ) );
		}
	}
} else {
	$mvweb_image = absint( mvweb_core_option( 'mvweb_service_list_image' ) );
	$mvweb_lead  = is_paged() ? '' : mvweb_core_service_list_lead();
}

mvweb_theme_column_open( 'services' );

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'title'    => $mvweb_title,
		'lead'     => $mvweb_lead,
		'intro'    => $mvweb_intro,
		'meta'     => $mvweb_meta,
		'image_id' => $mvweb_image,
	)
);

mvweb_core_render_layout( 'service-list', array( 'term' => $mvweb_term ) );

mvweb_theme_column_close( 'services' );

mvweb_core_render_context_sections();
