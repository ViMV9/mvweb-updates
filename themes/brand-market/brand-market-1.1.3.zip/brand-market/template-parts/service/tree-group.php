<?php
/**
 * One section of the services tree, with its subsections inside.
 *
 * The top level is a card: the head of the section on the left, set by the
 * tree-head layout, its services as a list on the right. A subsection is a
 * titled block inside that list, set off by a line on the left, and nests the
 * same way.
 *
 * Arguments: term (section), services (ids filed outside every section, when
 * there is no term), depth.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_term  = isset( $args['term'] ) && $args['term'] instanceof WP_Term ? $args['term'] : null;
$mvweb_depth = isset( $args['depth'] ) ? absint( $args['depth'] ) : 0;

if ( $mvweb_term ) {
	$mvweb_services = mvweb_core_service_ids( $mvweb_term->term_id );
	$mvweb_children = mvweb_core_service_child_terms( $mvweb_term->term_id );
	$mvweb_title    = $mvweb_term->name;
	$mvweb_link     = get_term_link( $mvweb_term );
	$mvweb_link     = is_string( $mvweb_link ) ? $mvweb_link : '';
	$mvweb_count    = mvweb_core_service_count( $mvweb_term->term_id );
} else {
	$mvweb_services = isset( $args['services'] ) ? array_map( 'absint', (array) $args['services'] ) : array();
	$mvweb_children = array();
	$mvweb_title    = __( 'Other services', 'brand-market' );
	$mvweb_link     = '';
	$mvweb_count    = count( $mvweb_services );
}

if ( empty( $mvweb_services ) && empty( $mvweb_children ) ) {
	return;
}

/* translators: %s: number of services in the section. */
$mvweb_count_text = sprintf( _n( '%s service', '%s services', $mvweb_count, 'brand-market' ), number_format_i18n( $mvweb_count ) );
$mvweb_head       = '';

if ( 0 === $mvweb_depth ) {
	$mvweb_head_args = array(
		'term'  => $mvweb_term,
		'title' => $mvweb_title,
		'link'  => $mvweb_link,
		'count' => $mvweb_count,
	);

	foreach ( mvweb_core_layout_order( 'tree-head' ) as $mvweb_slug ) {
		ob_start();
		get_template_part( 'template-parts/tree-head/' . sanitize_key( $mvweb_slug ), null, $mvweb_head_args );
		$mvweb_head .= trim( (string) ob_get_clean() );
	}
}
?>
<?php if ( 0 === $mvweb_depth ) : ?>
	<section class="mvweb-t-svc-group<?php echo '' === $mvweb_head ? ' mvweb-t-svc-group--plain' : ''; ?>">
		<?php if ( '' !== $mvweb_head ) : ?>
			<div class="mvweb-t-svc-group__head"><?php echo $mvweb_head; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there. ?></div>
		<?php endif; ?>

		<div class="mvweb-t-svc-group__body">
<?php else : ?>
	<div class="mvweb-t-svc-sub">
		<div class="mvweb-t-svc-sub__title <?php echo 1 === $mvweb_depth ? 'mvweb-t-h3' : 'mvweb-t-h4'; ?>">
			<a href="<?php echo esc_url( $mvweb_link ); ?>"><?php echo esc_html( $mvweb_title ); ?></a>
			<?php if ( mvweb_core_layout_has( 'tree-head', 'count' ) ) : ?>
				<span class="mvweb-t-svc-sub__count"><?php echo esc_html( $mvweb_count_text ); ?></span>
			<?php endif; ?>
		</div>
<?php endif; ?>

		<?php
		foreach ( $mvweb_children as $mvweb_child ) {
			get_template_part(
				'template-parts/service/tree-group',
				null,
				array(
					'term'  => $mvweb_child,
					'depth' => $mvweb_depth + 1,
				)
			);
		}
		?>

		<?php if ( ! empty( $mvweb_services ) ) : ?>
			<ul class="mvweb-t-svc-list">
				<?php foreach ( $mvweb_services as $mvweb_service ) : ?>
					<?php $mvweb_price = mvweb_core_service_price( $mvweb_service ); ?>
					<?php $mvweb_price = '' === trim( wp_strip_all_tags( $mvweb_price ) ) ? esc_html( mvweb_core_service_price_placeholder() ) : $mvweb_price; ?>
					<li>
						<a class="mvweb-t-svc-list__link" href="<?php echo esc_url( get_permalink( $mvweb_service ) ); ?>">
							<span class="mvweb-t-svc-list__name"><?php echo esc_html( get_the_title( $mvweb_service ) ); ?></span>
							<?php if ( '' !== $mvweb_price ) : ?>
								<span class="mvweb-t-svc-list__price"><?php echo wp_kses_post( $mvweb_price ); ?></span>
							<?php endif; ?>
							<?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>

<?php if ( 0 === $mvweb_depth ) : ?>
		</div>
	</section>
<?php else : ?>
	</div>
<?php endif; ?>
