<?php
/**
 * A section of services as a card in the listing.
 *
 * Same frame as a service card, so sections and the services filed next to
 * them read as one grid. The parts, their order and their visibility come from
 * the card-service-section layout.
 *
 * Arguments: term (section).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_term = isset( $args['term'] ) ? $args['term'] : null;

if ( ! $mvweb_term instanceof WP_Term ) {
	return;
}

$mvweb_link = get_term_link( $mvweb_term );

if ( ! is_string( $mvweb_link ) ) {
	return;
}

$mvweb_args = array(
	'term' => $mvweb_term,
	'link' => $mvweb_link,
);
$mvweb_html = array();

foreach ( mvweb_core_layout_order( 'card-service-section' ) as $mvweb_slug ) {
	ob_start();
	get_template_part( 'template-parts/card-service-section/' . sanitize_key( $mvweb_slug ), null, $mvweb_args );
	$mvweb_html[ $mvweb_slug ] = trim( (string) ob_get_clean() );
}

$mvweb_media = isset( $mvweb_html['image'] ) ? $mvweb_html['image'] : '';
$mvweb_body  = implode( '', array_diff_key( $mvweb_html, array( 'image' => '' ) ) );
?>
<article class="mvweb-t-card mvweb-t-card--service<?php echo 'landscape' === mvweb_core_option( 'mvweb_service_card_shape' ) ? '' : ' mvweb-t-card--tall'; ?>">
	<?php echo $mvweb_media; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there. ?>
	<?php if ( '' !== $mvweb_body ) : ?>
		<div class="mvweb-t-card__body"><?php echo $mvweb_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there. ?></div>
	<?php endif; ?>
</article>
