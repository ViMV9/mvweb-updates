<?php
/**
 * Service card in a listing.
 *
 * The parts, their order and their visibility come from the card-service
 * layout: a picture, the name, the line under it, the price and the link. The
 * picture always stands on top and the rest go into the body; a card whose
 * body is empty prints no body.
 *
 * Arguments: id (service), eager (bool, the picture loads at once).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : get_the_ID();

if ( 0 === $mvweb_id || 'publish' !== get_post_status( $mvweb_id ) ) {
	return;
}

$mvweb_args = array(
	'id'    => $mvweb_id,
	'link'  => (string) get_permalink( $mvweb_id ),
	'eager' => ! empty( $args['eager'] ),
);
$mvweb_html = array();

foreach ( mvweb_core_layout_order( 'card-service' ) as $mvweb_slug ) {
	ob_start();
	get_template_part( 'template-parts/card-service/' . sanitize_key( $mvweb_slug ), null, $mvweb_args );
	$mvweb_html[ $mvweb_slug ] = trim( (string) ob_get_clean() );
}

$mvweb_media = isset( $mvweb_html['image'] ) ? $mvweb_html['image'] : '';
$mvweb_body  = implode( '', array_diff_key( $mvweb_html, array( 'image' => '' ) ) );
?>
<article class="<?php echo esc_attr( implode( ' ', get_post_class( 'mvweb-t-card mvweb-t-card--service' . ( 'landscape' === mvweb_core_option( 'mvweb_service_card_shape' ) ? '' : ' mvweb-t-card--tall' ), $mvweb_id ) ) ); ?>">
	<?php echo $mvweb_media; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there. ?>
	<?php if ( '' !== $mvweb_body ) : ?>
		<div class="mvweb-t-card__body"><?php echo $mvweb_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there. ?></div>
	<?php endif; ?>
</article>
