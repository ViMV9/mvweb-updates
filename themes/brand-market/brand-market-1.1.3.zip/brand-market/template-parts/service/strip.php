<?php
/**
 * A band of cards under a heading, on the page of a service.
 *
 * The other services of the section and the works done on the service stand
 * in the same frame: a heading with an optional link and a grid of the cards
 * the listings print.
 *
 * Arguments: kind (service or work), ids, title, link_text, link_url, bg
 * (plain or surface).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_ids  = isset( $args['ids'] ) ? array_filter( array_map( 'absint', (array) $args['ids'] ) ) : array();
$mvweb_kind = isset( $args['kind'] ) && 'work' === $args['kind'] ? 'work' : 'service';
$mvweb_bg   = isset( $args['bg'] ) && 'surface' === $args['bg'] ? 'surface' : 'plain';

if ( empty( $mvweb_ids ) ) {
	return;
}
?>
<section class="mvweb-t-section"<?php echo 'plain' === $mvweb_bg ? '' : ' data-bg="' . esc_attr( $mvweb_bg ) . '"'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in place. ?>>
	<div class="mvweb-t-container">
		<?php
		mvweb_theme_head(
			array(
				'props'  => array(
					'title'     => isset( $args['title'] ) ? (string) $args['title'] : '',
					'link_text' => isset( $args['link_text'] ) ? (string) $args['link_text'] : '',
					'link_url'  => isset( $args['link_url'] ) ? (string) $args['link_url'] : '',
				),
				'motion' => '',
			),
			array( 'title', 'more' )
		);
		?>
		<div class="mvweb-t-catalog__grid mvweb-t-catalog__grid--services">
			<?php
			foreach ( $mvweb_ids as $mvweb_id ) {
				get_template_part( 'work' === $mvweb_kind ? 'template-parts/work/card' : 'template-parts/service/card', null, array( 'id' => $mvweb_id ) );
			}
			?>
		</div>
	</div>
</section>
