<?php
/**
 * The block about the author of an entry.
 *
 * Printed only when the site asked for it: a blog written under one name gains
 * nothing from repeating that name under every entry. The picture, the
 * description, the link to all posts and the links of the author stand in the
 * order the site sets for the area author-box.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! get_theme_mod( 'mvweb_author_box', false ) ) {
	return;
}

$mvweb_author = (int) get_post_field( 'post_author', get_the_ID() );
$mvweb_name   = trim( (string) get_the_author_meta( 'display_name', $mvweb_author ) );

if ( 0 === $mvweb_author || '' === $mvweb_name ) {
	return;
}

$mvweb_parts  = mvweb_core_blog_layout_html( 'author-box', array( 'author' => $mvweb_author ) );
$mvweb_avatar = isset( $mvweb_parts['avatar'] ) ? $mvweb_parts['avatar'] : '';

unset( $mvweb_parts['avatar'] );
?>
<aside class="mvweb-t-author" aria-label="<?php esc_attr_e( 'About the author', 'brand-market' ); ?>">
	<?php echo $mvweb_avatar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template. ?>
	<div class="mvweb-t-author__text">
		<p class="mvweb-t-author__label"><?php esc_html_e( 'Author of the article', 'brand-market' ); ?></p>
		<p class="mvweb-t-author__name"><?php echo esc_html( $mvweb_name ); ?></p>
		<?php echo implode( '', $mvweb_parts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?>
	</div>
</aside>
