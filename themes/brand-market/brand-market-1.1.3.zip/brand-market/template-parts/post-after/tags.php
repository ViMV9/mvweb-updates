<?php
/**
 * Under the text of a post, part: the tags.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tags = get_the_tags();

if ( empty( $mvweb_tags ) || is_wp_error( $mvweb_tags ) ) {
	return;
}
?>
<div class="mvweb-t-post__tags" aria-label="<?php esc_attr_e( 'Tags', 'brand-market' ); ?>">
	<?php foreach ( $mvweb_tags as $mvweb_tag ) : ?>
		<a class="mvweb-t-chip mvweb-t-chip--sm" href="<?php echo esc_url( get_tag_link( $mvweb_tag ) ); ?>" rel="tag"><?php echo esc_html( $mvweb_tag->name ); ?></a>
	<?php endforeach; ?>
</div>
