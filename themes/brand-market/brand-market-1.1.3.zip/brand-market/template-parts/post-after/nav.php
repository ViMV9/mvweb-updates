<?php
/**
 * Under the text of a post, part: the previous and the next post.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_prev = get_previous_post();
$mvweb_next = get_next_post();

if ( ! $mvweb_prev instanceof WP_Post && ! $mvweb_next instanceof WP_Post ) {
	return;
}
?>
<nav class="mvweb-t-post-nav" aria-label="<?php esc_attr_e( 'Other posts', 'brand-market' ); ?>">
	<?php if ( $mvweb_prev instanceof WP_Post ) : ?>
		<a class="mvweb-t-post-nav__link" href="<?php echo esc_url( get_permalink( $mvweb_prev ) ); ?>" rel="prev">
			<span class="mvweb-t-post-nav__label"><?php echo mvweb_theme_icon( 'arrow-left', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?><?php esc_html_e( 'Previous', 'brand-market' ); ?></span>
			<span class="mvweb-t-post-nav__title"><?php echo esc_html( get_the_title( $mvweb_prev ) ); ?></span>
		</a>
	<?php endif; ?>
	<?php if ( $mvweb_next instanceof WP_Post ) : ?>
		<a class="mvweb-t-post-nav__link mvweb-t-post-nav__link--next" href="<?php echo esc_url( get_permalink( $mvweb_next ) ); ?>" rel="next">
			<span class="mvweb-t-post-nav__label"><?php esc_html_e( 'Next', 'brand-market' ); ?><?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
			<span class="mvweb-t-post-nav__title"><?php echo esc_html( get_the_title( $mvweb_next ) ); ?></span>
		</a>
	<?php endif; ?>
</nav>
