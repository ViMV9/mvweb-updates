<?php
/**
 * The counter of the cart: the number in the header and the piece WooCommerce refreshes.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_count = function_exists( 'mvweb_core_cart_positions' ) ? mvweb_core_cart_positions() : 0;
?>
<span class="mvweb-t-round__count" data-cart-count data-announce="<?php echo esc_attr( function_exists( 'mvweb_core_cart_announce' ) ? mvweb_core_cart_announce() : '' ); ?>"<?php echo $mvweb_count > 0 ? '' : ' hidden'; ?>><?php echo $mvweb_count > 0 ? esc_html( number_format_i18n( $mvweb_count ) ) : ''; ?></span>
