<?php
/**
 * Price of a box: what its products cost, the price of the box and the discount.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @var array $args 'state' — result of mvweb_core_box_state().
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_state = isset( $args['state'] ) ? (array) $args['state'] : array();

if ( empty( $mvweb_state['sum'] ) ) {
	return;
}
?>
<p class="mvweb-t-box-price">
	<?php if ( ! empty( $mvweb_state['active'] ) && ! empty( $mvweb_state['discount'] ) ) : ?>
		<span class="mvweb-t-box-price__now"><?php echo wp_kses_post( wc_price( $mvweb_state['price'] ) ); ?></span>
		<del class="mvweb-t-box-price__old"><?php echo wp_kses_post( wc_price( $mvweb_state['sum'] ) ); ?></del>
		<span class="mvweb-t-badge mvweb-t-badge--accent mvweb-t-box-price__save">
			<?php
			/* translators: %s: discount sum. */
			printf( esc_html__( '−%s', 'brand-market' ), wp_kses_post( wc_price( $mvweb_state['discount'] ) ) );
			?>
		</span>
	<?php else : ?>
		<span class="mvweb-t-box-price__now"><?php echo wp_kses_post( wc_price( $mvweb_state['sum'] ) ); ?></span>
	<?php endif; ?>
</p>
