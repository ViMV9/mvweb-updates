<?php
/**
 * Terms of a box: until when the discount holds and how many boxes are left.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @var array $args 'state' — result of mvweb_core_box_state().
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_state = isset( $args['state'] ) ? (array) $args['state'] : array();
$mvweb_terms = array();

$mvweb_reason = isset( $mvweb_state['reason'] ) ? (string) $mvweb_state['reason'] : '';

if ( empty( $mvweb_state['active'] ) ) {
	if ( in_array( $mvweb_reason, array( 'ended', 'sold' ), true ) ) {
		$mvweb_terms[] = __( 'The box offer is over: the products sell at their own prices.', 'brand-market' );
	} elseif ( in_array( $mvweb_reason, array( 'stock', 'items' ), true ) ) {
		$mvweb_terms[] = __( 'The box is not available now: not all of its products are on sale.', 'brand-market' );
	}
} else {
	if ( ! empty( $mvweb_state['until'] ) ) {
		/* translators: %s: date and time. */
		$mvweb_terms[] = sprintf( __( 'Until %s', 'brand-market' ), wp_date( get_option( 'date_format' ) . ', H:i', (int) $mvweb_state['until'] ) );
	}

	if ( null !== $mvweb_state['left'] ) {
		/* translators: %d: boxes left. */
		$mvweb_terms[] = sprintf( _n( '%d box left', '%d boxes left', (int) $mvweb_state['left'], 'brand-market' ), (int) $mvweb_state['left'] );
	}
}

if ( empty( $mvweb_terms ) ) {
	return;
}
?>
<p class="mvweb-t-box-terms">
	<?php echo mvweb_theme_icon( 'clock', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<?php echo esc_html( implode( ' · ', $mvweb_terms ) ); ?>
</p>
