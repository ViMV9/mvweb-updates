<?php
/**
 * The button that puts the box into the cart as one item.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @var array $args 'product' — the box, 'state' — result of mvweb_core_box_state(), 'text' — the label of the button.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_box   = isset( $args['product'] ) ? $args['product'] : null;
$mvweb_state = isset( $args['state'] ) ? (array) $args['state'] : array();

if ( ! $mvweb_box instanceof WC_Product || empty( $mvweb_state['items'] ) || ! mvweb_core_shop_mode() ) {
	return;
}

$mvweb_ready = ! empty( $mvweb_state['active'] );

$mvweb_text = isset( $args['text'] ) && '' !== trim( (string) $args['text'] ) ? (string) $args['text'] : __( 'Buy the box', 'brand-market' );
?>
<form class="cart mvweb-t-box-form" action="<?php echo esc_url( $mvweb_box->get_permalink() ); ?>" method="post">
	<input type="hidden" name="quantity" value="1">
	<input type="hidden" name="add-to-cart" value="<?php echo esc_attr( (string) $mvweb_box->get_id() ); ?>">
	<button class="mvweb-t-btn mvweb-t-box-form__button" type="submit"<?php echo $mvweb_ready ? '' : ' disabled'; ?>>
		<?php echo mvweb_theme_icon( 'cart', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<?php echo esc_html( $mvweb_ready ? $mvweb_text : __( 'The box is not available', 'brand-market' ) ); ?>
	</button>
</form>
