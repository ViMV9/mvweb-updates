<?php
/**
 * Sitemap, look «Index from A to Z»: every section and entry by the first letter of its name, as the subject index of a book, with the place it comes from.
 *
 * The strip of the letters sticks to the top; the letters without names are dimmed.
 * The order of the kinds does not matter here.
 *
 * Arguments: the sitemap of the core (types, counts).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_index = mvweb_core_sitemap_index( $args );
$mvweb_keys  = array_keys( $mvweb_index['letters'] );
$mvweb_rail  = array_unique( array_merge( $mvweb_index['alphabet'], $mvweb_keys ) );
?>
<div class="mvweb-t-sitemap mvweb-t-sm-index">
	<nav class="mvweb-t-sm-index__rail" aria-label="<?php esc_attr_e( 'Letters of the index', 'brand-market' ); ?>">
		<?php foreach ( $mvweb_rail as $mvweb_letter ) : ?>
			<?php if ( isset( $mvweb_index['letters'][ $mvweb_letter ] ) ) : ?>
				<a class="mvweb-t-sm-index__key" href="#mvweb-sm-<?php echo esc_attr( (string) array_search( $mvweb_letter, $mvweb_keys, true ) ); ?>"><?php echo esc_html( $mvweb_letter ); ?></a>
			<?php else : ?>
				<span class="mvweb-t-sm-index__key" aria-disabled="true"><?php echo esc_html( $mvweb_letter ); ?></span>
			<?php endif; ?>
		<?php endforeach; ?>
	</nav>

	<div class="mvweb-t-sm-index__list">
		<?php foreach ( $mvweb_keys as $mvweb_at => $mvweb_letter ) : ?>
			<div class="mvweb-t-sm-index__letter" id="mvweb-sm-<?php echo esc_attr( (string) $mvweb_at ); ?>">
				<div class="mvweb-t-sm-index__glyph" aria-hidden="true"><?php echo esc_html( $mvweb_letter ); ?></div>
				<?php /* translators: %s: a letter of the index. */ ?>
				<ul class="mvweb-t-sm-index__entries" aria-label="<?php echo esc_attr( sprintf( __( 'Starting with %s', 'brand-market' ), $mvweb_letter ) ); ?>">
					<?php foreach ( $mvweb_index['letters'][ $mvweb_letter ] as $mvweb_row ) : ?>
						<li class="mvweb-t-sm-index__entry">
							<div class="mvweb-t-sm-index__name"><?php echo mvweb_theme_sitemap_link( $mvweb_row ) . mvweb_theme_sitemap_count( $mvweb_row['n'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers. ?></div>
							<div class="mvweb-t-sm-index__from"><?php echo esc_html( $mvweb_row['from'] ); ?></div>
						</li>
					<?php endforeach; ?>
				</ul>
			</div>
		<?php endforeach; ?>
	</div>
</div>
