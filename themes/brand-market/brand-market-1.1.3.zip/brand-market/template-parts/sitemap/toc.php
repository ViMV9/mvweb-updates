<?php
/**
 * Sitemap, look «Contents with a search field»: numbered contents with dots up to the number, as in a book; a strip with the search field and the anchors of the kinds sticks to the top.
 *
 * The search hides the rows that do not match and marks the matches; every link stays in the markup.
 * Without the script it is plain contents: the search field appears with the script.
 *
 * Arguments: the sitemap of the core (types, counts).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_find = static function ( $name ) {
	return str_replace( "\u{0451}", "\u{0435}", mb_strtolower( (string) $name ) );
};

$mvweb_row = static function ( $number, array $item, $count, $css ) use ( $mvweb_find ) {
	$dots = '' !== $count ? '<span class="mvweb-t-sm-toc__dots" aria-hidden="true"></span>' . $count : '';

	printf(
		'<li class="%1$s" data-text="%2$s"><div class="mvweb-t-sm-toc__row"><span class="mvweb-t-sm-toc__num">%3$s</span>%4$s%5$s</div>',
		esc_attr( $css ),
		esc_attr( $mvweb_find( $item['name'] ) ),
		esc_html( $number ),
		mvweb_theme_sitemap_link( $item, 'mvweb-t-sm-toc__name' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper.
		$dots // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper.
	);
};

$mvweb_walk = static function ( array $groups, $prefix ) use ( &$mvweb_walk, $mvweb_row ) {
	foreach ( $groups as $at => $group ) {
		$number = $prefix . '.' . ( $at + 1 );
		$more   = mvweb_theme_sitemap_more( $group );

		$mvweb_row( $number, $group, mvweb_theme_sitemap_count( $group['total'] ), 'mvweb-t-sm-toc__group' );

		if ( $group['subs'] || $group['items'] || '' !== $more ) {
			echo '<ol class="mvweb-t-sm-toc__list">';

			$mvweb_walk( $group['subs'], $number );

			foreach ( $group['items'] as $item ) {
				$mvweb_row( '', $item, '', 'mvweb-t-sm-toc__item' );
				echo '</li>';
			}

			if ( '' !== $more ) {
				echo '<li class="mvweb-t-sm-toc__more" data-text="">' . $more . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper.
			}

			echo '</ol>';
		}

		echo '</li>';
	}
};
?>
<div class="mvweb-t-sitemap mvweb-t-sm-toc" data-sitemap-toc>
	<div class="mvweb-t-sm-toc__bar">
		<label class="mvweb-t-sm-toc__search" data-sitemap-search hidden>
			<?php echo mvweb_theme_icon( 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Icon markup of the theme. ?>
			<span class="screen-reader-text"><?php esc_html_e( 'Search the sitemap', 'brand-market' ); ?></span>
			<input type="search" placeholder="<?php esc_attr_e( 'Find on the map', 'brand-market' ); ?>" autocomplete="off" data-sitemap-query>
		</label>
		<nav class="mvweb-t-sm-toc__chips" aria-label="<?php esc_attr_e( 'Sections of the map', 'brand-market' ); ?>">
			<?php foreach ( $args['types'] as $mvweb_at => $mvweb_type ) : ?>
				<a class="mvweb-t-sm-toc__chip" href="#mvweb-sm-<?php echo esc_attr( $mvweb_type['key'] ); ?>" data-sitemap-chip="mvweb-sm-<?php echo esc_attr( $mvweb_type['key'] ); ?>"><b><?php echo esc_html( (string) ( $mvweb_at + 1 ) ); ?></b><?php echo esc_html( $mvweb_type['label'] ); ?></a>
			<?php endforeach; ?>
		</nav>
		<?php /* translators: %s: number of the rows found. */ ?>
		<div class="mvweb-t-sm-toc__status" role="status" data-sitemap-status data-found="<?php echo esc_attr( __( 'Found: %s. Esc clears the search', 'brand-market' ) ); ?>" data-none="<?php esc_attr_e( 'Nothing found on the map. Try the search of the site', 'brand-market' ); ?>"></div>
	</div>

	<ol class="mvweb-t-sm-toc__toc">
		<?php foreach ( $args['types'] as $mvweb_at => $mvweb_type ) : ?>
			<li class="mvweb-t-sm-toc__type" id="mvweb-sm-<?php echo esc_attr( $mvweb_type['key'] ); ?>" data-text="<?php echo esc_attr( $mvweb_find( $mvweb_type['label'] ) ); ?>">
				<div class="mvweb-t-sm-toc__thead">
					<span class="mvweb-t-sm-toc__num"><?php echo esc_html( (string) ( $mvweb_at + 1 ) ); ?></span>
					<?php echo mvweb_theme_sitemap_title( $mvweb_type, 'mvweb-t-sm-toc__name' ) . mvweb_theme_sitemap_count( $mvweb_type['total'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers. ?>
				</div>
				<ol class="mvweb-t-sm-toc__list">
					<?php
					$mvweb_walk( $mvweb_type['groups'], (string) ( $mvweb_at + 1 ) );

					foreach ( $mvweb_type['items'] as $mvweb_item ) {
						$mvweb_row( '', $mvweb_item, mvweb_theme_sitemap_count( isset( $mvweb_item['n'] ) ? $mvweb_item['n'] : 0 ), 'mvweb-t-sm-toc__item' );
						echo '</li>';
					}

					if ( '' !== mvweb_theme_sitemap_more( $mvweb_type ) ) {
						echo '<li class="mvweb-t-sm-toc__more" data-text="">' . mvweb_theme_sitemap_more( $mvweb_type ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper.
					}
					?>
				</ol>
			</li>
		<?php endforeach; ?>
	</ol>
</div>
