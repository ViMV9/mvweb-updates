<?php
/**
 * Sitemap, look «Cards of the sections»: a card for every kind with its icon, description and number; the sections in rows, the subsections as pills, the entries in a line.
 *
 * Two levels only: a section with subsections shows the subsections as pills, not their entries.
 *
 * Arguments: the sitemap of the core (types, counts).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_line = static function ( array $items, $more ) {
	$parts = array();

	foreach ( $items as $item ) {
		$parts[] = mvweb_theme_sitemap_link( $item );
	}

	if ( '' !== $more ) {
		$parts[] = $more;
	}

	if ( $parts ) {
		echo '<p class="mvweb-t-sm-cards__items">' . implode( '&nbsp;· ', $parts ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers.
	}
};
?>
<div class="mvweb-t-sitemap mvweb-t-sm-cards">
	<?php foreach ( $args['types'] as $mvweb_type ) : ?>
		<div class="mvweb-t-sm-cards__card">
			<div class="mvweb-t-sm-cards__head">
				<?php echo mvweb_theme_sitemap_icon( $mvweb_type ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>
				<div class="mvweb-t-sm-cards__titles">
					<?php echo mvweb_theme_sitemap_title( $mvweb_type, 'mvweb-t-sm-cards__name' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>
					<span class="mvweb-t-sm-cards__desc"><?php echo esc_html( $mvweb_type['desc'] ); ?></span>
				</div>
				<?php if ( $args['counts'] ) : ?>
					<span class="mvweb-t-sm-cards__total"><?php echo esc_html( $mvweb_type['total_text'] ); ?></span>
				<?php endif; ?>
			</div>

			<ul class="mvweb-t-sm-cards__groups">
				<?php if ( ! $mvweb_type['groups'] ) : ?>
					<li class="mvweb-t-sm-cards__group">
						<?php if ( isset( $mvweb_type['items'][0]['n'] ) ) : ?>
							<div class="mvweb-t-sm-cards__chips">
								<?php foreach ( $mvweb_type['items'] as $mvweb_item ) : ?>
									<span class="mvweb-t-sm-cards__chip"><?php echo mvweb_theme_sitemap_link( $mvweb_item ) . mvweb_theme_sitemap_count( $mvweb_item['n'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers. ?></span>
								<?php endforeach; ?>
							</div>
						<?php else : ?>
							<?php $mvweb_line( $mvweb_type['items'], mvweb_theme_sitemap_more( $mvweb_type ) ); ?>
						<?php endif; ?>
					</li>
				<?php endif; ?>

				<?php foreach ( $mvweb_type['groups'] as $mvweb_group ) : ?>
					<li class="mvweb-t-sm-cards__group">
						<div class="mvweb-t-sm-cards__row"><?php echo mvweb_theme_sitemap_link( $mvweb_group ) . mvweb_theme_sitemap_count( $mvweb_group['total'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers. ?></div>
						<?php if ( $mvweb_group['subs'] ) : ?>
							<div class="mvweb-t-sm-cards__chips">
								<?php foreach ( $mvweb_group['subs'] as $mvweb_sub ) : ?>
									<span class="mvweb-t-sm-cards__chip"><?php echo mvweb_theme_sitemap_link( $mvweb_sub ) . mvweb_theme_sitemap_count( $mvweb_sub['total'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers. ?></span>
								<?php endforeach; ?>
							</div>
						<?php endif; ?>
						<?php $mvweb_line( $mvweb_group['items'], mvweb_theme_sitemap_more( $mvweb_group ) ); ?>
					</li>
				<?php endforeach; ?>
			</ul>

			<?php if ( $mvweb_type['archive'] ) : ?>
				<a class="mvweb-t-sm-cards__all" href="<?php echo esc_url( $mvweb_type['archive']['url'] ); ?>">
					<?php echo esc_html( $mvweb_type['archive']['name'] ) . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Icon markup of the theme. ?>
				</a>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>
</div>
