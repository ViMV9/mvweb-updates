<?php
/**
 * Sitemap, look «Tree»: the kinds open, their sections folded; inside a section the link to the whole section, its subsections and entries.
 *
 * The folding is the details element; the script only adds the buttons «Expand all» and «Collapse all».
 * The link of a section stands inside its branch, not in the summary: screen readers read a link in a summary badly.
 *
 * Arguments: the sitemap of the core (types, counts).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_arrow = mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) );

$mvweb_leaf = static function ( array $item, $css = 'mvweb-t-sm-tree__link' ) {
	echo '<li class="mvweb-t-sm-tree__leaf">' . mvweb_theme_sitemap_link( $item, $css ) . mvweb_theme_sitemap_count( isset( $item['n'] ) ? $item['n'] : 0 ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers.
};

$mvweb_node = static function ( array $group ) use ( &$mvweb_node, $mvweb_leaf ) {
	$more = mvweb_theme_sitemap_more( $group );

	if ( ! $group['subs'] && ! $group['items'] && '' === $more ) {
		$mvweb_leaf(
			array(
				'name' => $group['name'],
				'url'  => $group['url'],
				'n'    => $group['total'],
			),
			'mvweb-t-sm-tree__link mvweb-t-sm-tree__link--group'
		);

		return;
	}
	?>
	<li>
		<details class="mvweb-t-sm-tree__node">
			<summary class="mvweb-t-sm-tree__sum">
				<?php echo '<span>' . esc_html( $group['name'] ) . '</span>' . mvweb_theme_sitemap_count( $group['total'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers. ?>
			</summary>
			<ul class="mvweb-t-sm-tree__tree">
				<?php if ( '' !== $group['url'] ) : ?>
					<li class="mvweb-t-sm-tree__leaf">
						<a class="mvweb-t-sm-tree__open" href="<?php echo esc_url( $group['url'] ); ?>">
							<?php
							/* translators: %s: name of a section of the site. */
							echo esc_html( sprintf( __( 'Whole section «%s»', 'brand-market' ), $group['name'] ) );
							?>
						</a>
					</li>
				<?php endif; ?>
				<?php
				foreach ( $group['subs'] as $mvweb_sub ) {
					$mvweb_node( $mvweb_sub );
				}

				foreach ( $group['items'] as $mvweb_item ) {
					$mvweb_leaf( $mvweb_item );
				}
				?>
				<?php if ( '' !== $more ) : ?>
					<li class="mvweb-t-sm-tree__leaf"><?php echo $more; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?></li>
				<?php endif; ?>
			</ul>
		</details>
	</li>
	<?php
};
?>
<div class="mvweb-t-sitemap mvweb-t-sm-tree" data-sitemap-tree>
	<div class="mvweb-t-sm-tree__bar" data-sitemap-bar hidden>
		<button class="mvweb-t-sm-tree__btn" type="button" data-sitemap-all="open">
			<?php echo mvweb_theme_icon( 'plus', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Icon markup of the theme. ?>
			<?php esc_html_e( 'Expand all', 'brand-market' ); ?>
		</button>
		<button class="mvweb-t-sm-tree__btn" type="button" data-sitemap-all="close">
			<?php echo mvweb_theme_icon( 'minus', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Icon markup of the theme. ?>
			<?php esc_html_e( 'Collapse all', 'brand-market' ); ?>
		</button>
	</div>

	<div class="mvweb-t-sm-tree__types">
		<?php foreach ( $args['types'] as $mvweb_type ) : ?>
			<details class="mvweb-t-sm-tree__type" open>
				<summary class="mvweb-t-sm-tree__tsum">
					<?php echo mvweb_theme_sitemap_icon( $mvweb_type ) . '<span>' . esc_html( $mvweb_type['label'] ) . '</span>' . mvweb_theme_sitemap_count( $mvweb_type['total'] ) . mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-sm-tree__chev' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helpers. ?>
				</summary>
				<div class="mvweb-t-sm-tree__body">
					<?php if ( $mvweb_type['archive'] ) : ?>
						<a class="mvweb-t-sm-tree__all" href="<?php echo esc_url( $mvweb_type['archive']['url'] ); ?>"><?php echo esc_html( $mvweb_type['archive']['name'] ) . $mvweb_arrow; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Icon markup of the theme. ?></a>
					<?php endif; ?>
					<ul class="mvweb-t-sm-tree__tree">
						<?php
						foreach ( $mvweb_type['groups'] as $mvweb_group ) {
							$mvweb_node( $mvweb_group );
						}

						foreach ( $mvweb_type['items'] as $mvweb_item ) {
							$mvweb_leaf( $mvweb_item );
						}
						?>
						<?php if ( '' !== mvweb_theme_sitemap_more( $mvweb_type ) ) : ?>
							<li class="mvweb-t-sm-tree__leaf"><?php echo mvweb_theme_sitemap_more( $mvweb_type ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?></li>
						<?php endif; ?>
					</ul>
				</div>
			</details>
		<?php endforeach; ?>
	</div>
</div>
