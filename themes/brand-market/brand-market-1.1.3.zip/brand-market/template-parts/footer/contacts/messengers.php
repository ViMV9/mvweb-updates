<?php
/**
 * Footer contacts part: Messengers.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_chats = mvweb_cz_profile_chats();

if ( empty( $mvweb_chats ) ) {
	return;
}
?>
<li class="mvweb-t-footer__item">
	<div class="mvweb-t-footer__socials">
		<?php foreach ( $mvweb_chats as $mvweb_id => $mvweb_link ) : ?>
			<a class="mvweb-t-round" href="<?php echo esc_url( $mvweb_link['url'] ); ?>" title="<?php echo esc_attr( $mvweb_link['label'] ); ?>" rel="noopener" target="_blank">
				<?php echo mvweb_theme_icon( mvweb_core_social_icon( $mvweb_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php echo esc_html( $mvweb_link['label'] ); ?></span>
			</a>
		<?php endforeach; ?>
	</div>
</li>
