<?php
/**
 * Widget body: items or posts with a picture, a name, a price or a date.
 *
 * The picture stands before the text unless the owner put it after the first
 * line of the text in the composition of the widget.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rows  = isset( $args['rows'] ) ? (array) $args['rows'] : array();
$mvweb_parts = isset( $args['parts'] ) ? (array) $args['parts'] : array();
$mvweb_text  = array_values( array_diff( $mvweb_parts, array( 'image' ) ) );
$mvweb_image = array_search( 'image', $mvweb_parts, true );
$mvweb_end   = false !== $mvweb_image && ! empty( $mvweb_text ) && array_search( $mvweb_text[0], $mvweb_parts, true ) < $mvweb_image;

if ( empty( $mvweb_rows ) ) {
	return;
}
?>
<ul class="mvweb-t-widget__posts<?php echo $mvweb_end ? ' mvweb-t-widget__posts--end' : ''; ?>">
	<?php foreach ( $mvweb_rows as $mvweb_row ) : ?>
		<li>
			<a href="<?php echo esc_url( $mvweb_row['url'] ); ?>">
				<?php if ( '' !== $mvweb_row['image'] ) : ?>
					<?php echo $mvweb_row['image']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of an attachment image. ?>
				<?php endif; ?>
				<span>
					<?php foreach ( $mvweb_text as $mvweb_part ) : ?>
						<?php if ( 'title' === $mvweb_part ) : ?>
							<strong><?php echo esc_html( $mvweb_row['title'] ); ?></strong>
						<?php elseif ( 'price' === $mvweb_part && '' !== $mvweb_row['price'] ) : ?>
							<em class="mvweb-t-widget__price"><?php echo wp_kses_post( $mvweb_row['price'] ); ?></em>
						<?php elseif ( 'date' === $mvweb_part && '' !== $mvweb_row['date'] ) : ?>
							<time datetime="<?php echo esc_attr( $mvweb_row['time'] ); ?>"><?php echo esc_html( $mvweb_row['date'] ); ?></time>
						<?php endif; ?>
					<?php endforeach; ?>
				</span>
			</a>
		</li>
	<?php endforeach; ?>
</ul>
