<?php
/**
 * Widget body: a list of links with a note after each, and an icon before it where asked.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rows = isset( $args['rows'] ) ? (array) $args['rows'] : array();

if ( empty( $mvweb_rows ) ) {
	return;
}
?>
<ul class="mvweb-t-widget__list<?php echo ! empty( $args['icons'] ) ? ' mvweb-t-widget__list--icons' : ''; ?>">
	<?php foreach ( $mvweb_rows as $mvweb_row ) : ?>
		<li>
			<a href="<?php echo esc_url( $mvweb_row['url'] ); ?>"<?php echo ! empty( $mvweb_row['current'] ) ? ' aria-current="page"' : ''; ?>>
				<?php if ( ! empty( $mvweb_row['icon'] ) ) : ?>
					<?php echo mvweb_theme_icon( $mvweb_row['icon'], array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<?php endif; ?>
				<em class="mvweb-t-widget__name"><?php echo esc_html( $mvweb_row['name'] ); ?></em>
				<?php if ( '' !== $mvweb_row['meta'] ) : ?>
					<span><?php echo wp_kses_post( $mvweb_row['meta'] ); ?></span>
				<?php endif; ?>
			</a>
		</li>
	<?php endforeach; ?>
</ul>
