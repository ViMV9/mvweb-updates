<?php
/**
 * Widget body: a line of text and a button.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_parts = isset( $args['parts'] ) ? (array) $args['parts'] : array();
$mvweb_text  = isset( $args['text'] ) ? (string) $args['text'] : '';
$mvweb_label = isset( $args['button_text'] ) ? (string) $args['button_text'] : '';
$mvweb_url   = isset( $args['button_url'] ) ? (string) $args['button_url'] : '';

foreach ( $mvweb_parts as $mvweb_part ) {
	if ( 'text' === $mvweb_part && '' !== $mvweb_text ) {
		?>
		<p><?php echo esc_html( $mvweb_text ); ?></p>
		<?php
	} elseif ( 'button' === $mvweb_part && '' !== $mvweb_label && '' !== $mvweb_url ) {
		?>
		<a class="mvweb-t-btn mvweb-t-btn--block" href="<?php echo esc_url( $mvweb_url ); ?>"><?php echo esc_html( $mvweb_label ); ?></a>
		<?php
	}
}
