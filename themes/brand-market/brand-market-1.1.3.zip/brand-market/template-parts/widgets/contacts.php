<?php
/**
 * Widget body: the contacts of the site in the order the owner set.
 *
 * The opening hours stand under the phone when they follow it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_parts  = isset( $args['parts'] ) ? array_values( (array) $args['parts'] ) : array();
$mvweb_phones = isset( $args['phones'] ) ? (array) $args['phones'] : array();
$mvweb_hours  = isset( $args['hours'] ) ? (string) $args['hours'] : '';
$mvweb_email  = isset( $args['email'] ) ? (string) $args['email'] : '';
$mvweb_where  = isset( $args['address'] ) ? (string) $args['address'] : '';
$mvweb_chats  = isset( $args['messengers'] ) ? (array) $args['messengers'] : array();
$mvweb_look   = isset( $args['instance']['look'] ) && in_array( $args['instance']['look'], array( 'light', 'accent' ), true ) ? $args['instance']['look'] : 'dark';

$mvweb_row = static function ( $icon, $text, $accent = false ) {
	return '<li><span class="mvweb-t-widget__ico' . ( $accent ? ' mvweb-t-widget__ico--accent' : '' ) . '" aria-hidden="true">' . mvweb_theme_icon( $icon, array( 'class' => 'mvweb-t-icon--sm' ) ) . '</span><span class="mvweb-t-widget__txt">' . $text . '</span></li>';
};

ob_start();

foreach ( $mvweb_parts as $mvweb_at => $mvweb_part ) {
	$mvweb_prev = $mvweb_at > 0 ? $mvweb_parts[ $mvweb_at - 1 ] : '';
	$mvweb_next = isset( $mvweb_parts[ $mvweb_at + 1 ] ) ? $mvweb_parts[ $mvweb_at + 1 ] : '';

	if ( 'phone' === $mvweb_part && ! empty( $mvweb_phones ) ) {
		$mvweb_text = '';

		foreach ( $mvweb_phones as $mvweb_phone ) {
			$mvweb_text .= '<a class="mvweb-t-widget__phone" href="' . esc_url( $mvweb_phone['href'] ) . '">' . esc_html( $mvweb_phone['number'] ) . '</a>';
		}

		if ( 'hours' === $mvweb_next && '' !== $mvweb_hours ) {
			$mvweb_text .= '<span class="mvweb-t-widget__sub">' . esc_html( $mvweb_hours ) . '</span>';
		}

		echo $mvweb_row( 'phone', $mvweb_text, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from escaped values.
	} elseif ( 'hours' === $mvweb_part && '' !== $mvweb_hours && ! ( 'phone' === $mvweb_prev && ! empty( $mvweb_phones ) ) ) {
		echo $mvweb_row( 'clock', esc_html( $mvweb_hours ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from escaped values.
	} elseif ( 'email' === $mvweb_part && '' !== $mvweb_email ) {
		echo $mvweb_row( 'mail', '<a href="mailto:' . esc_attr( antispambot( $mvweb_email ) ) . '">' . esc_html( antispambot( $mvweb_email ) ) . '</a>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from escaped values.
	} elseif ( 'address' === $mvweb_part && '' !== $mvweb_where ) {
		echo $mvweb_row( 'map-pin', esc_html( $mvweb_where ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from escaped values.
	} elseif ( 'messengers' === $mvweb_part && ! empty( $mvweb_chats ) ) {
		?>
		<li class="mvweb-t-widget__chats">
			<?php foreach ( $mvweb_chats as $mvweb_id => $mvweb_chat ) : ?>
				<a class="mvweb-t-widget__chat mvweb-t-widget__chat--<?php echo esc_attr( sanitize_html_class( (string) $mvweb_id ) ); ?>" href="<?php echo esc_url( $mvweb_chat['url'] ); ?>" target="_blank" rel="noopener">
					<span class="mvweb-t-widget__chat-ico" aria-hidden="true"><?php echo mvweb_theme_icon( mvweb_core_social_icon( $mvweb_id ), array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
					<span class="mvweb-t-widget__chat-name"><?php echo esc_html( $mvweb_chat['label'] ); ?></span>
				</a>
			<?php endforeach; ?>
		</li>
		<?php
	}
}

$mvweb_list = trim( (string) ob_get_clean() );

if ( '' === $mvweb_list ) {
	return;
}
?>
<ul class="mvweb-t-widget__contacts mvweb-t-widget__contacts--<?php echo esc_attr( $mvweb_look ); ?>">
	<?php echo $mvweb_list; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled above from escaped values. ?>
</ul>
