<?php
/**
 * Widget body: the filter of the catalogue.
 *
 * The groups are the parts of the listing sidebar, in the order of the
 * composition of the widget. On a narrow screen the form slides in over the
 * page from the button of the toolbar.
 *
 * Checkboxes of a group share a name and assets/js/filters.js joins the
 * checked ones into a single comma-separated field before the form submits —
 * WooCommerce drops a filter whose value arrives as an array.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_state = new ArrayObject( array( 'open' => 0 ) );

ob_start();

foreach ( isset( $args['parts'] ) ? (array) $args['parts'] : array() as $mvweb_part ) {
	get_template_part( 'template-parts/catalog-filters/' . sanitize_key( $mvweb_part ), null, array( 'state' => $mvweb_state ) );
}

$mvweb_groups = trim( (string) ob_get_clean() );

if ( '' === $mvweb_groups ) {
	return;
}

$mvweb_order = mvweb_core_catalog_orderby();
?>
<div class="mvweb-t-filters" data-filters>
	<div class="mvweb-t-filters__scrim" data-filters-close></div>

	<form class="mvweb-t-filters__form" id="mvweb-t-filters-form" action="<?php echo esc_url( mvweb_core_catalog_base_url() ); ?>" method="get">
		<div class="mvweb-t-filters__head">
			<span><?php esc_html_e( 'Filters', 'brand-market' ); ?></span>
			<button class="mvweb-t-round" type="button" data-filters-close title="<?php esc_attr_e( 'Close', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Close', 'brand-market' ); ?></span>
			</button>
		</div>

		<?php if ( 'menu_order' !== $mvweb_order ) : ?>
			<input type="hidden" name="orderby" value="<?php echo esc_attr( $mvweb_order ); ?>">
		<?php endif; ?>

		<?php echo $mvweb_groups; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the parts of the sidebar, every value escaped there. ?>

		<div class="mvweb-t-filters__actions">
			<button class="mvweb-t-btn" type="submit"><?php esc_html_e( 'Apply', 'brand-market' ); ?></button>

			<?php if ( mvweb_core_listing_filtered() ) : ?>
				<a class="mvweb-t-btn mvweb-t-btn--outline" href="<?php echo esc_url( mvweb_core_catalog_url() ); ?>"><?php esc_html_e( 'Reset', 'brand-market' ); ?></a>
			<?php endif; ?>
		</div>
	</form>
</div>
