<?php
/**
 * Widget body: the request form, or the button to the request where there is no form.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_form = mvweb_core_form_shortcode( isset( $args['form'] ) ? (string) $args['form'] : '' );
$mvweb_text = isset( $args['cta_text'] ) ? (string) $args['cta_text'] : '';
$mvweb_url  = isset( $args['cta_url'] ) ? (string) $args['cta_url'] : '';
$mvweb_note = isset( $args['note'] ) ? (string) $args['note'] : '';

if ( '' === $mvweb_form && ( '' === $mvweb_text || '' === $mvweb_url ) ) {
	return;
}
?>
<?php if ( '' !== $mvweb_form ) : ?>
	<div class="mvweb-t-form">
		<?php echo $mvweb_form; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Shortcode output is escaped by the plugin that owns it. ?>
	</div>
<?php else : ?>
	<a class="mvweb-t-btn mvweb-t-btn--block" href="<?php echo esc_url( $mvweb_url ); ?>"><?php echo esc_html( $mvweb_text ); ?></a>
<?php endif; ?>
<?php if ( '' !== $mvweb_note ) : ?>
	<p class="mvweb-t-widget__note"><?php echo esc_html( $mvweb_note ); ?></p>
<?php endif; ?>
