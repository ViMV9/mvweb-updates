<?php
/**
 * Widget body: the tree of the categories of the catalogue or of the blog.
 *
 * A row with children is a link with its own button that opens the branch; the blog gives the children their own
 * children, three levels deep.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rows = isset( $args['rows'] ) ? (array) $args['rows'] : array();

if ( empty( $mvweb_rows ) ) {
	return;
}

$mvweb_label = static function ( $row ) {
	$html = '<em class="mvweb-t-widget__name">' . esc_html( $row['name'] ) . '</em>';

	return null !== $row['count'] ? $html . '<span>' . esc_html( number_format_i18n( $row['count'] ) ) . '</span>' : $html;
};

$mvweb_branch = static function ( $row, $top ) use ( &$mvweb_branch, $mvweb_label ) {
	$current = $row['current'] ? ' aria-current="page"' : '';

	if ( empty( $row['children'] ) ) {
		printf( '<a%1$s href="%2$s"%3$s>%4$s</a>', $top ? ' class="mvweb-t-widget__solo"' : '', esc_url( $row['url'] ), $current, $mvweb_label( $row ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attributes, the label is escaped in the helper.

		return;
	}

	/* translators: %s: name of the category. */
	$toggle = sprintf( __( 'Subcategories of %s', 'brand-market' ), $row['name'] );
	?>
	<div class="mvweb-t-widget__fork">
		<a class="mvweb-t-widget__fork-link" href="<?php echo esc_url( $row['url'] ); ?>"<?php echo $current; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>><?php echo $mvweb_label( $row ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?></a>
		<details<?php echo ! empty( $row['open'] ) ? ' open' : ''; ?>>
			<summary title="<?php echo esc_attr( $toggle ); ?>">
				<span class="screen-reader-text"><?php echo esc_html( $toggle ); ?></span>
				<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			</summary>
			<ul>
				<?php foreach ( $row['children'] as $mvweb_child ) : ?>
					<li><?php $mvweb_branch( $mvweb_child, false ); ?></li>
				<?php endforeach; ?>
			</ul>
		</details>
	</div>
	<?php
};
?>
<ul class="mvweb-t-widget__tree">
	<?php foreach ( $mvweb_rows as $mvweb_row ) : ?>
		<li><?php $mvweb_branch( $mvweb_row, true ); ?></li>
	<?php endforeach; ?>
</ul>
