<?php
/**
 * Widget body: pictures of works with a caption.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rows = isset( $args['rows'] ) ? (array) $args['rows'] : array();

if ( empty( $mvweb_rows ) ) {
	return;
}
?>
<ul class="mvweb-t-widget__works">
	<?php foreach ( $mvweb_rows as $mvweb_row ) : ?>
		<li>
			<a href="<?php echo esc_url( $mvweb_row['url'] ); ?>"<?php echo '' === $mvweb_row['title'] ? ' aria-label="' . esc_attr( $mvweb_row['label'] ) . '"' : ''; ?>>
				<?php echo $mvweb_row['image']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of an attachment image. ?>
				<?php if ( '' !== $mvweb_row['title'] ) : ?>
					<span><?php echo esc_html( $mvweb_row['title'] ); ?></span>
				<?php endif; ?>
			</a>
		</li>
	<?php endforeach; ?>
</ul>
