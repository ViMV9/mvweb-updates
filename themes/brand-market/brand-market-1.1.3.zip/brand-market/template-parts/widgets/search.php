<?php
/**
 * Widget body: the search field of a column.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id          = wp_unique_id( 'mvweb-t-wsearch-' );
$mvweb_placeholder = trim( (string) get_theme_mod( 'mvweb_search_placeholder', '' ) );
?>
<form class="mvweb-t-widget__search" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
	<label class="screen-reader-text" for="<?php echo esc_attr( $mvweb_id ); ?>"><?php esc_html_e( 'Search the site', 'brand-market' ); ?></label>
	<input class="mvweb-t-field__input" id="<?php echo esc_attr( $mvweb_id ); ?>" type="search" name="s" value="<?php echo esc_attr( get_search_query( false ) ); ?>"<?php echo '' !== $mvweb_placeholder ? ' placeholder="' . esc_attr( $mvweb_placeholder ) . '"' : ''; ?> autocomplete="off">
	<button class="mvweb-t-round mvweb-t-round--accent" type="submit" title="<?php esc_attr_e( 'Search', 'brand-market' ); ?>">
		<?php echo mvweb_theme_icon( 'search', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<span class="screen-reader-text"><?php esc_html_e( 'Search', 'brand-market' ); ?></span>
	</button>
</form>
