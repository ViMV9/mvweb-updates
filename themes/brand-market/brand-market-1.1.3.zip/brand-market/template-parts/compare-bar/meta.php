<?php
/**
 * Comparison bar part: the facts under the heading, the number of items and the category.
 *
 * The script fills them in, because the list of a guest is in the browser.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! isset( $args['place'] ) || 'hero' !== $args['place'] ) {
	return;
}
?>
<p class="mvweb-t-page-hero__meta" aria-live="polite" data-compare-meta hidden></p>
