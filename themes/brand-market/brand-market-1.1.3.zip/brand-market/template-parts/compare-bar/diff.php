<?php
/**
 * Comparison bar part: the switch that hides the rows where every item says the same.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_model = isset( $args['model'] ) && is_array( $args['model'] ) ? $args['model'] : array();

if ( ! isset( $args['place'] ) || 'bar' !== $args['place'] || empty( $mvweb_model['items'] ) || count( $mvweb_model['items'] ) < 2 ) {
	return;
}
?>
<label class="mvweb-t-switch">
	<input type="checkbox" data-compare-diff>
	<span class="mvweb-t-switch__track"></span>
	<span><?php esc_html_e( 'Only differences', 'brand-market' ); ?></span>
</label>
