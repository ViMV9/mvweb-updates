<?php
/**
 * Comparison bar part: the choice of the category being compared.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_model = isset( $args['model'] ) && is_array( $args['model'] ) ? $args['model'] : array();

if ( ! isset( $args['place'] ) || 'bar' !== $args['place'] || empty( $mvweb_model['groups'] ) || count( $mvweb_model['groups'] ) < 2 ) {
	return;
}
?>
<div class="mvweb-t-tabsel">
	<label class="mvweb-t-tabsel__label" for="mvweb-t-cmp-cat"><?php esc_html_e( 'Category', 'brand-market' ); ?></label>
	<select class="mvweb-t-tabsel__select" id="mvweb-t-cmp-cat" name="cat" data-compare-cat>
		<?php foreach ( $mvweb_model['groups'] as $mvweb_group ) : ?>
			<option value="<?php echo (int) $mvweb_group['id']; ?>"<?php selected( (int) $mvweb_group['id'], (int) $mvweb_model['cat'] ); ?>>
				<?php echo esc_html( $mvweb_group['name'] . ' · ' . count( $mvweb_group['ids'] ) ); ?>
			</option>
		<?php endforeach; ?>
	</select>
</div>
