<?php
/**
 * Line above the title of a post, part: the date of the last change, when the post was changed a day or more after publishing.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_updated = mvweb_core_post_updated();

if ( empty( $mvweb_updated ) ) {
	return;
}
?>
<span class="mvweb-t-post-card__time mvweb-t-post__updated">
	<?php
	printf(
		/* translators: %s: date of the last change. */
		esc_html__( 'Updated %s', 'brand-market' ),
		'<time datetime="' . esc_attr( $mvweb_updated['iso'] ) . '">' . esc_html( $mvweb_updated['date'] ) . '</time>'
	);
	?>
</span>
