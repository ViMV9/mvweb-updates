<?php
/**
 * Author block, part: the picture.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

echo get_avatar( isset( $args['author'] ) ? absint( $args['author'] ) : 0, 160, '', '', array( 'class' => 'mvweb-t-avatar mvweb-t-avatar--lg' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
