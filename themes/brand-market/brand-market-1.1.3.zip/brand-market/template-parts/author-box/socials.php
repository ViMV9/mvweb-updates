<?php
/**
 * Author block, part: the links of the author.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_links = mvweb_core_author_links( isset( $args['author'] ) ? absint( $args['author'] ) : 0 );

if ( empty( $mvweb_links ) ) {
	return;
}
?>
<div class="mvweb-t-author__socials">
	<?php foreach ( $mvweb_links as $mvweb_link ) : ?>
		<a class="mvweb-t-round mvweb-t-round--line" href="<?php echo esc_url( $mvweb_link['url'] ); ?>"<?php echo 0 === strpos( $mvweb_link['url'], 'http' ) ? ' target="_blank" rel="noopener"' : ''; ?> title="<?php echo esc_attr( $mvweb_link['label'] ); ?>">
			<?php echo mvweb_theme_icon( $mvweb_link['icon'], array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span class="screen-reader-text">
				<?php
				/* translators: %s: name of a network or a mail. */
				echo esc_html( sprintf( __( '%s of the author', 'brand-market' ), $mvweb_link['label'] ) );
				?>
			</span>
		</a>
	<?php endforeach; ?>
</div>
