<?php
/**
 * The question mark beside the wholesale price: opens the window with its terms.
 *
 * Prints nothing while the terms are off or empty. The window itself stands at
 * the end of the page, see wholesale-info.php.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_wholesale_info' ) || '' === mvweb_core_wholesale_info() ) {
	return;
}
?>
<button class="mvweb-t-hint" type="button" aria-haspopup="dialog" data-wholesale-open title="<?php esc_attr_e( 'Terms of the wholesale price', 'brand-market' ); ?>">
	<span class="mvweb-t-hint__mark" aria-hidden="true">?</span>
	<span class="screen-reader-text"><?php esc_html_e( 'Terms of the wholesale price', 'brand-market' ); ?></span>
</button>
