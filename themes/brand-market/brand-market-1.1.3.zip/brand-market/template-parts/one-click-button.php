<?php
/**
 * Order in one click: the button under "Add to cart", inside the cart form.
 *
 * Arguments: product.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_product = isset( $args['product'] ) ? $args['product'] : null;

if ( ! function_exists( 'mvweb_core_one_click' ) || ! mvweb_core_one_click( $mvweb_product ) ) {
	return;
}
?>
<button class="mvweb-t-btn mvweb-t-btn--block mvweb-t-product-cart__one-click" type="button" data-one-click-open>
	<?php echo mvweb_theme_icon( 'bolt', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<?php esc_html_e( 'Buy in one click', 'brand-market' ); ?>
</button>
