<?php
/**
 * Purchase box part: datasheets, certificates, manuals.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_docs = isset( $args['id'] ) ? mvweb_core_item_documents( absint( $args['id'] ) ) : array();

if ( empty( $mvweb_docs ) ) {
	return;
}
?>
<div class="mvweb-t-documents">
	<p class="mvweb-t-documents__title"><?php esc_html_e( 'Documents', 'brand-market' ); ?></p>
	<ul class="mvweb-t-documents__list">
		<?php foreach ( $mvweb_docs as $mvweb_doc ) : ?>
			<li>
				<a class="mvweb-t-documents__link" href="<?php echo esc_url( $mvweb_doc['url'] ); ?>" target="_blank" rel="noopener">
					<span class="mvweb-t-documents__type" aria-hidden="true"><?php echo esc_html( '' !== $mvweb_doc['type'] ? $mvweb_doc['type'] : 'DOC' ); ?></span>
					<span><?php echo esc_html( $mvweb_doc['title'] ); ?></span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</div>
