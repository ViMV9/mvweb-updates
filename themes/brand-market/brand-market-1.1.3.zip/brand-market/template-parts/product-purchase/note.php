<?php
/**
 * Purchase box part: the line under the buttons.
 *
 * A shop says how delivery goes, a showroom what the visitor gets for asking.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_shop = mvweb_core_shop_mode() && null !== mvweb_core_wc_item( isset( $args['id'] ) ? absint( $args['id'] ) : 0 );
$mvweb_text = $mvweb_shop ? mvweb_core_product_delivery_line() : trim( (string) get_theme_mod( 'mvweb_product_promo', '' ) );

if ( '' === $mvweb_text ) {
	return;
}
?>
<p class="mvweb-t-product-cart__note">
	<?php echo mvweb_theme_icon( $mvweb_shop ? 'truck-delivery' : 'clock', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<?php echo esc_html( $mvweb_text ); ?>
</p>
