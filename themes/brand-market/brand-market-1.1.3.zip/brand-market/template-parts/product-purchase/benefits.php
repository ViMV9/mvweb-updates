<?php
/**
 * Purchase box part: why customers order here.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_benefits = mvweb_core_product_benefits();

if ( empty( $mvweb_benefits ) ) {
	return;
}

$mvweb_lead = trim( (string) get_theme_mod( 'mvweb_product_benefits_title', '' ) );
?>
<div class="mvweb-t-product-benefits">
	<?php if ( '' !== $mvweb_lead ) : ?>
		<p class="mvweb-t-product-benefits__intro"><?php echo esc_html( $mvweb_lead ); ?></p>
	<?php endif; ?>
	<ol class="mvweb-t-product-benefits__list">
		<?php foreach ( $mvweb_benefits as $mvweb_benefit ) : ?>
			<li class="mvweb-t-product-benefits__item"><?php echo esc_html( $mvweb_benefit ); ?></li>
		<?php endforeach; ?>
	</ol>
</div>
