<?php
/**
 * Purchase box part: the total for the quantity and how many more pieces lead to the next price step.
 *
 * The script of the theme counts it again when the quantity changes; the line
 * printed here is the one for the smallest quantity.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_data = mvweb_core_buy_data( isset( $args['id'] ) ? absint( $args['id'] ) : 0 );

if ( empty( $mvweb_data ) ) {
	return;
}

$mvweb_qty  = (int) $mvweb_data['min'];
$mvweb_unit = mvweb_core_buy_unit( $mvweb_data, $mvweb_qty );
$mvweb_next = 0;

foreach ( array_keys( $mvweb_data['tiers'] ) as $mvweb_from ) {
	if ( $mvweb_from > $mvweb_qty ) {
		$mvweb_next = $mvweb_from;
		break;
	}
}

$mvweb_pcs = mvweb_core_qty_unit( absint( $args['id'] ) );
$mvweb_pcs = '' !== $mvweb_pcs ? $mvweb_pcs : __( 'pcs', 'brand-market' );
/* translators: 1: how many pieces more, 2: unit, for example pcs., 3: the price of the next step. */
$mvweb_left = __( '%1$d %2$s more to the price %3$s', 'brand-market' );
/* translators: %s: amount saved. */
$mvweb_save = __( 'you save %s', 'brand-market' );
$mvweb_note = '';

if ( $mvweb_next > 0 ) {
	$mvweb_note = sprintf( $mvweb_left, $mvweb_next - $mvweb_qty, $mvweb_pcs, wp_strip_all_tags( wc_price( $mvweb_data['tiers'][ $mvweb_next ] ) ) );
} elseif ( $mvweb_unit < $mvweb_data['price'] ) {
	$mvweb_note = sprintf( $mvweb_save, wp_strip_all_tags( wc_price( ( $mvweb_data['price'] - $mvweb_unit ) * $mvweb_qty ) ) );
}
?>
<p class="mvweb-t-product-total" data-buy-total data-left="<?php echo esc_attr( str_replace( '%2$s', $mvweb_pcs, $mvweb_left ) ); ?>" data-save="<?php echo esc_attr( $mvweb_save ); ?>">
	<span><?php esc_html_e( 'Total', 'brand-market' ); ?> <b class="mvweb-t-product-total__sum" data-buy-sum><?php echo esc_html( wp_strip_all_tags( wc_price( $mvweb_unit * $mvweb_qty ) ) ); ?></b></span>
	<span class="mvweb-t-product-total__note" data-buy-note<?php echo '' === $mvweb_note ? ' hidden' : ''; ?>><?php echo esc_html( $mvweb_note ); ?></span>
</p>
