<?php
/**
 * Purchase box part: the minimum quantity and the prices by quantity.
 *
 * In the look "price steps" the retail price and every step are tiles that set
 * the quantity, with a bar to the last step; in the other looks every step is a
 * chip.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : 0;

if ( 0 === $mvweb_id ) {
	return;
}

$mvweb_tiers = mvweb_core_tiers( $mvweb_id );
$mvweb_rules = mvweb_core_quantity_rules( $mvweb_id );
$mvweb_unit  = mvweb_core_qty_unit( $mvweb_id );
$mvweb_unit  = '' !== $mvweb_unit ? $mvweb_unit : __( 'pcs', 'brand-market' );

if ( empty( $mvweb_tiers ) && $mvweb_rules['min'] < 2 ) {
	return;
}

$mvweb_data  = mvweb_core_buy_data( $mvweb_id );
$mvweb_wc    = mvweb_core_wc_item( $mvweb_id );
$mvweb_base  = $mvweb_wc ? (float) wc_get_price_to_display( $mvweb_wc ) : 0.0;
$mvweb_tiles = ! empty( $mvweb_data['tiers'] ) && 'tiers' === mvweb_core_product_view();
$mvweb_cut   = static function ( $amount ) use ( $mvweb_base ) {
	return $mvweb_base > 0 && (float) $amount < $mvweb_base ? (int) round( ( $mvweb_base - (float) $amount ) / $mvweb_base * 100 ) : 0;
};
?>
<div class="<?php echo esc_attr( 'mvweb-t-tiers' . ( $mvweb_tiles ? ' mvweb-t-tiers--tiles' : '' ) ); ?>">
	<?php if ( $mvweb_rules['min'] > 1 ) : ?>
		<p class="mvweb-t-tiers__rule">
			<?php
			echo esc_html(
				$mvweb_rules['step'] > 1
					/* translators: 1: minimum quantity, 2: unit, for example pcs., 3: step. */
					? sprintf( __( 'Sold from %1$d %2$s, in steps of %3$d', 'brand-market' ), $mvweb_rules['min'], $mvweb_unit, $mvweb_rules['step'] )
					/* translators: 1: minimum quantity, 2: unit, for example pcs. */
					: sprintf( __( 'Sold from %1$d %2$s', 'brand-market' ), $mvweb_rules['min'], $mvweb_unit )
			);
			?>
		</p>
	<?php endif; ?>

	<?php if ( $mvweb_tiles ) : ?>
		<?php
		$mvweb_froms = array_keys( $mvweb_data['tiers'] );
		$mvweb_steps = min( $mvweb_froms ) > (int) $mvweb_data['min'] ? array( (int) $mvweb_data['min'] => $mvweb_data['price'] ) + $mvweb_data['tiers'] : $mvweb_data['tiers'];
		$mvweb_keys  = array_keys( $mvweb_steps );
		$mvweb_last  = (int) end( $mvweb_froms );
		$mvweb_now   = (int) $mvweb_data['min'];
		?>
		<div class="mvweb-t-tiers__tiles">
			<?php foreach ( $mvweb_keys as $mvweb_index => $mvweb_from ) : ?>
				<?php
				$mvweb_to   = isset( $mvweb_keys[ $mvweb_index + 1 ] ) ? (int) $mvweb_keys[ $mvweb_index + 1 ] - 1 : 0;
				$mvweb_here = $mvweb_now >= $mvweb_from && ( 0 === $mvweb_to || $mvweb_now <= $mvweb_to );
				$mvweb_off  = $mvweb_cut( $mvweb_steps[ $mvweb_from ] );
				?>
				<button class="mvweb-t-tiers__tile" type="button" data-tier-set="<?php echo (int) $mvweb_from; ?>" aria-pressed="<?php echo $mvweb_here ? 'true' : 'false'; ?>">
					<span class="mvweb-t-tiers__qty">
						<?php
						echo esc_html(
							$mvweb_to > $mvweb_from
								/* translators: 1: from, 2: to, 3: unit, for example pcs. */
								? sprintf( __( '%1$d–%2$d %3$s', 'brand-market' ), $mvweb_from, $mvweb_to, $mvweb_unit )
								/* translators: 1: quantity, 2: unit, for example pcs. */
								: sprintf( __( 'from %1$d %2$s', 'brand-market' ), $mvweb_from, $mvweb_unit )
						);
						?>
					</span>
					<span class="mvweb-t-tiers__price"><?php echo wp_kses_post( mvweb_core_price_html( $mvweb_steps[ $mvweb_from ] ) ); ?></span>
					<?php if ( $mvweb_off > 0 ) : ?>
						<span class="mvweb-t-tiers__off">
							<?php
							/* translators: %d: percent saved. */
							echo esc_html( sprintf( __( 'you save %d%%', 'brand-market' ), $mvweb_off ) );
							?>
						</span>
					<?php endif; ?>
				</button>
			<?php endforeach; ?>
		</div>
		<span class="mvweb-t-tiers__bar" aria-hidden="true"><span data-tier-bar style="<?php echo esc_attr( 'width:' . min( 100, round( $mvweb_now / max( 1, $mvweb_last ) * 100 ) ) . '%' ); ?>"></span></span>
	<?php elseif ( ! empty( $mvweb_tiers ) ) : ?>
		<ul class="mvweb-t-tiers__chips">
			<?php foreach ( $mvweb_tiers as $mvweb_from => $mvweb_amount ) : ?>
				<li class="mvweb-t-tiers__chip">
					<?php
					/* translators: 1: quantity, 2: unit, for example pcs. */
					echo esc_html( sprintf( __( 'from %1$d %2$s', 'brand-market' ), $mvweb_from, $mvweb_unit ) );
					?>
					<b><?php echo wp_kses_post( mvweb_core_price_html( $mvweb_amount ) ); ?></b>
					<?php if ( $mvweb_cut( $mvweb_amount ) > 0 ) : ?>
						<span class="mvweb-t-tiers__off"><?php echo esc_html( '−' . $mvweb_cut( $mvweb_amount ) . '%' ); ?></span>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
</div>
