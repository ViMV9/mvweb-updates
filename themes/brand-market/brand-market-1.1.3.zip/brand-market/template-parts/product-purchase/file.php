<?php
/**
 * Purchase box part: the file offered with the item, a model or a datasheet.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_file  = isset( $args['id'] ) ? mvweb_core_item_file( absint( $args['id'] ) ) : '';
$mvweb_label = trim( (string) get_theme_mod( 'mvweb_product_file_label', __( 'Download the model', 'brand-market' ) ) );

if ( '' === $mvweb_file || '' === $mvweb_label ) {
	return;
}

$mvweb_type = strtoupper( (string) pathinfo( (string) wp_parse_url( $mvweb_file, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
?>
<div class="mvweb-t-documents">
	<ul class="mvweb-t-documents__list">
		<li>
			<a class="mvweb-t-documents__link" href="<?php echo esc_url( $mvweb_file ); ?>" target="_blank" rel="noopener">
				<span class="mvweb-t-documents__type" aria-hidden="true"><?php echo esc_html( preg_match( '/^[A-Z0-9]{2,4}$/', $mvweb_type ) ? $mvweb_type : 'FILE' ); ?></span>
				<span><?php echo esc_html( $mvweb_label ); ?></span>
			</a>
		</li>
	</ul>
</div>
