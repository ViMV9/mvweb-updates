<?php
/**
 * Purchase box part: the buttons.
 *
 * A shop puts the item in the cart with the form of WooCommerce, dressed by
 * woocommerce/single-product/add-to-cart/; a showroom, and a product the shop
 * cannot sell right now, asks for the price and offers a call.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : 0;

if ( 0 === $mvweb_id ) {
	return;
}

$mvweb_product = mvweb_core_shop_mode() ? mvweb_core_wc_item( $mvweb_id ) : null;

if ( $mvweb_product && ! ( $mvweb_product->is_type( 'variable' ) && ! $mvweb_product->is_purchasable() ) ) {
	$GLOBALS['product'] = $mvweb_product;

	ob_start();
	woocommerce_template_single_add_to_cart();
	$mvweb_form = trim( (string) ob_get_clean() );

	if ( '' !== $mvweb_form ) {
		echo $mvweb_form; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The WooCommerce form, printed by its templates.

		return;
	}
}

$mvweb_text  = (string) get_theme_mod( 'mvweb_cta_text', __( 'Request a quote', 'brand-market' ) );
$mvweb_url   = (string) get_theme_mod( 'mvweb_cta_url', '' );
$mvweb_phone = mvweb_core_contacts();
$mvweb_phone = ! empty( $mvweb_phone['phones'][0]['href'] ) ? (string) $mvweb_phone['phones'][0]['href'] : '';
$mvweb_fav   = function_exists( 'mvweb_core_favorites_url' ) && '' !== mvweb_core_favorites_url();
$mvweb_ask   = '' !== $mvweb_text && '' !== $mvweb_url;
$mvweb_cmp   = mvweb_core_layout_has( 'product-purchase', 'compare' ) ? mvweb_theme_compare_button( $mvweb_id ) : '';

if ( ! $mvweb_ask && '' === $mvweb_phone && ! $mvweb_fav && '' === $mvweb_cmp ) {
	return;
}
?>
<div class="mvweb-t-product-request">
	<div class="mvweb-t-product-request__row">
		<?php if ( $mvweb_ask ) : ?>
			<a class="mvweb-t-btn mvweb-t-product-request__main" href="<?php echo esc_url( $mvweb_url ); ?>" data-request="<?php echo esc_attr( get_the_title( $mvweb_id ) ); ?>">
				<?php echo mvweb_theme_icon( 'messages', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<?php echo esc_html( $mvweb_text ); ?>
			</a>
		<?php endif; ?>

		<?php if ( '' !== $mvweb_phone ) : ?>
			<a class="mvweb-t-btn mvweb-t-btn--outline" href="<?php echo esc_url( $mvweb_phone, array( 'tel' ) ); ?>">
				<?php echo mvweb_theme_icon( 'phone', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<?php esc_html_e( 'Call', 'brand-market' ); ?>
			</a>
		<?php endif; ?>

		<?php if ( $mvweb_fav ) : ?>
			<button class="mvweb-t-round mvweb-t-round--line" type="button" data-fav-toggle="<?php echo (int) $mvweb_id; ?>" aria-pressed="false" title="<?php esc_attr_e( 'Add to favourites', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'heart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text" data-fav-label><?php esc_html_e( 'Add to favourites', 'brand-market' ); ?></span>
			</button>
		<?php endif; ?>

		<?php echo $mvweb_cmp; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	</div>
</div>
