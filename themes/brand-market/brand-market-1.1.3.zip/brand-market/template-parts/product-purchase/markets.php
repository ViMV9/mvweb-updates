<?php
/**
 * Purchase box part: where the item is sold at retail, with the logos set in the Customizer.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_markets = isset( $args['id'] ) ? mvweb_core_item_markets( absint( $args['id'] ) ) : array();

if ( empty( $mvweb_markets ) ) {
	return;
}

$mvweb_title = trim( (string) get_theme_mod( 'mvweb_markets_title', __( 'Buy at retail', 'brand-market' ) ) );
?>
<div class="mvweb-t-markets">
	<?php if ( '' !== $mvweb_title ) : ?>
		<p class="mvweb-t-markets__title"><?php echo esc_html( $mvweb_title ); ?></p>
	<?php endif; ?>
	<ul class="mvweb-t-markets__list">
		<?php foreach ( $mvweb_markets as $mvweb_market ) : ?>
			<li>
				<?php
				$mvweb_logo = function_exists( 'mvweb_core_market_logo' ) ? mvweb_core_market_logo( $mvweb_market['title'] ) : 0;
				$mvweb_logo = $mvweb_logo ? wp_get_attachment_image(
					$mvweb_logo,
					'thumbnail',
					false,
					array(
						'class'   => 'mvweb-t-markets__logo',
						'alt'     => '',
						'loading' => 'lazy',
					)
				) : '';
				?>
				<a class="mvweb-t-markets__link" href="<?php echo esc_url( $mvweb_market['url'] ); ?>" target="_blank" rel="noopener nofollow"><?php echo $mvweb_logo; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of wp_get_attachment_image(). ?><?php echo esc_html( $mvweb_market['title'] ); ?><?php echo mvweb_theme_icon( 'arrow-up-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></a>
			</li>
		<?php endforeach; ?>
	</ul>
</div>
