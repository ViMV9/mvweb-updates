<?php
/**
 * What a box holds and the button that buys it, on the page of the box.
 *
 * The core puts it in place of the WooCommerce form of a grouped product when
 * the product is a box.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;

$mvweb_state = mvweb_core_box_state( $product );

if ( empty( $mvweb_state['items'] ) ) {
	return;
}
?>
<div class="mvweb-t-box-buy">
	<div class="mvweb-t-box-buy__label"><?php esc_html_e( 'In the box', 'brand-market' ); ?></div>
	<ul class="mvweb-t-box-buy__list">
		<?php foreach ( $mvweb_state['items'] as $mvweb_item ) : ?>
			<li class="mvweb-t-box-buy__item">
				<span class="mvweb-t-box-buy__thumb"><?php echo $mvweb_item->get_image( 'thumbnail' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Image markup of WooCommerce, escaped inside. ?></span>
				<span class="mvweb-t-box-buy__what">
					<a class="mvweb-t-box-buy__name" href="<?php echo esc_url( $mvweb_item->get_permalink() ); ?>"><?php echo esc_html( $mvweb_item->get_name() ); ?></a>
					<?php if ( $mvweb_item->is_type( 'variation' ) ) : ?>
						<span class="mvweb-t-box-buy__variant"><?php echo esc_html( wc_get_formatted_variation( $mvweb_item, true, false ) ); ?></span>
					<?php endif; ?>
				</span>
				<?php if ( $mvweb_item->is_in_stock() ) : ?>
					<span class="mvweb-t-box-buy__cost"><?php echo wp_kses_post( wc_price( wc_get_price_to_display( $mvweb_item, array( 'price' => '' === (string) $mvweb_item->get_regular_price() ? $mvweb_item->get_price() : $mvweb_item->get_regular_price() ) ) ) ); ?></span>
				<?php else : ?>
					<span class="mvweb-t-box-buy__cost mvweb-t-box-buy__cost--out"><?php esc_html_e( 'Out of stock', 'brand-market' ); ?></span>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php
	get_template_part( 'template-parts/box/price', null, array( 'state' => $mvweb_state ) );
	get_template_part( 'template-parts/box/terms', null, array( 'state' => $mvweb_state ) );
	get_template_part(
		'template-parts/box/form',
		null,
		array(
			'product' => $product,
			'state'   => $mvweb_state,
		)
	);
	?>
</div>
