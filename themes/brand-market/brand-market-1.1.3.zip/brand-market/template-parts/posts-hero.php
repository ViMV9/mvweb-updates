<?php
/**
 * The main story of a block of posts: one post across the width, in five looks.
 *
 * Arguments: look (cover, split, headline, top, daily), query (WP_Query of the block), rv (the parts appear with the block).
 * The first post is the main one; headline adds the next three as related, top as small ones, daily as the list of the day.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_query = isset( $args['query'] ) && $args['query'] instanceof WP_Query ? $args['query'] : null;
$mvweb_look  = isset( $args['look'] ) ? (string) $args['look'] : 'cover';
$mvweb_rv    = ! empty( $args['rv'] ) ? ' data-rv' : '';

if ( null === $mvweb_query || ! $mvweb_query->have_posts() ) {
	return;
}

$mvweb_lead  = static function () {
	static $texts = array();

	$id = (int) get_the_ID();

	if ( ! isset( $texts[ $id ] ) ) {
		$texts[ $id ] = trim( wp_strip_all_tags( get_the_excerpt() ) );
	}

	return $texts[ $id ];
};
$mvweb_media = static function ( $css, $size = 'large' ) {
	if ( ! has_post_thumbnail() ) {
		return;
	}

	printf( '<a class="mvweb-t-jr-media %1$s" href="%2$s" tabindex="-1" aria-hidden="true">%3$s</a>', esc_attr( $css ), esc_url( get_permalink() ), get_the_post_thumbnail( null, $size ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds the image tag.
};
$mvweb_title = static function ( $css ) {
	printf( '<div class="%1$s mvweb-t-h2" role="heading" aria-level="2"><a class="mvweb-t-jr-link" href="%2$s">%3$s</a></div>', esc_attr( $css ), esc_url( get_permalink() ), esc_html( get_the_title() ) );
};
$mvweb_query->the_post();

if ( 'cover' === $mvweb_look ) :
	$mvweb_credit = trim( wp_strip_all_tags( (string) get_the_post_thumbnail_caption() ) );
	?>
	<article class="mvweb-t-posts__cover<?php echo has_post_thumbnail() ? '' : ' mvweb-t-posts__cover--plain'; ?>"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
		<?php if ( has_post_thumbnail() ) : ?>
			<div class="mvweb-t-posts__cover-media"><?php the_post_thumbnail( 'full' ); ?></div>
		<?php endif; ?>
		<?php if ( '' !== $mvweb_credit ) : ?>
			<span class="mvweb-t-posts__cover-credit"><?php echo esc_html( $mvweb_credit ); ?></span>
		<?php endif; ?>
		<div class="mvweb-t-posts__cover-body">
			<?php get_template_part( 'template-parts/journal/topic', null, array( 'class' => 'mvweb-t-posts__cover-topic' ) ); ?>
			<div class="mvweb-t-posts__cover-title mvweb-t-h2" role="heading" aria-level="2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
			<?php if ( '' !== $mvweb_lead() ) : ?>
				<p class="mvweb-t-posts__cover-lead"><?php echo esc_html( $mvweb_lead() ); ?></p>
			<?php endif; ?>
			<?php get_template_part( 'template-parts/journal/byline' ); ?>
		</div>
	</article>
	<?php
elseif ( 'split' === $mvweb_look ) :
	?>
	<article class="mvweb-t-posts__split"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
		<?php $mvweb_media( 'mvweb-t-posts__split-media', 'full' ); ?>
		<div class="mvweb-t-posts__split-text">
			<div class="mvweb-t-posts__split-top">
				<?php get_template_part( 'template-parts/journal/topic' ); ?>
				<?php $mvweb_title( 'mvweb-t-posts__split-title' ); ?>
				<?php if ( '' !== $mvweb_lead() ) : ?>
					<p class="mvweb-t-jr-lead"><?php echo esc_html( $mvweb_lead() ); ?></p>
				<?php endif; ?>
			</div>
			<?php get_template_part( 'template-parts/journal/byline' ); ?>
		</div>
	</article>
	<?php
elseif ( 'headline' === $mvweb_look ) :
	?>
	<div class="mvweb-t-posts__headline">
		<article class="mvweb-t-posts__headline-main"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
			<div class="mvweb-t-posts__headline-kicker">
				<span class="mvweb-t-posts__headline-label"><?php esc_html_e( 'Main story', 'brand-market' ); ?></span>
				<?php get_template_part( 'template-parts/journal/topic' ); ?>
			</div>
			<div class="mvweb-t-posts__headline-title mvweb-t-h2" role="heading" aria-level="2"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
			<?php if ( '' !== $mvweb_lead() ) : ?>
				<p class="mvweb-t-posts__headline-lead"><?php echo esc_html( $mvweb_lead() ); ?></p>
			<?php endif; ?>
			<?php get_template_part( 'template-parts/journal/byline' ); ?>
		</article>
		<?php if ( $mvweb_query->have_posts() ) : ?>
			<div class="mvweb-t-posts__headline-rel"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
				<div class="mvweb-t-posts__headline-rel-head"><?php esc_html_e( 'On the topic', 'brand-market' ); ?></div>
				<?php
				while ( $mvweb_query->have_posts() ) :
					$mvweb_query->the_post();
					?>
					<article class="mvweb-t-posts__headline-item">
						<div class="mvweb-t-jr-meta">
							<?php get_template_part( 'template-parts/journal/topic' ); ?>
							<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( mvweb_core_short_date() ); ?></time>
						</div>
						<div class="mvweb-t-posts__headline-item-title"><a class="mvweb-t-jr-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
					</article>
				<?php endwhile; ?>
			</div>
		<?php endif; ?>
	</div>
	<?php
elseif ( 'top' === $mvweb_look ) :
	?>
	<div class="mvweb-t-posts__top">
		<article class="mvweb-t-posts__top-main"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
			<?php $mvweb_media( 'mvweb-t-posts__top-media', 'full' ); ?>
			<div class="mvweb-t-posts__top-head">
				<?php get_template_part( 'template-parts/journal/topic' ); ?>
				<?php $mvweb_title( 'mvweb-t-posts__top-title' ); ?>
			</div>
			<div class="mvweb-t-posts__top-aside">
				<?php if ( '' !== $mvweb_lead() ) : ?>
					<p class="mvweb-t-jr-lead"><?php echo esc_html( $mvweb_lead() ); ?></p>
				<?php endif; ?>
				<?php get_template_part( 'template-parts/journal/byline' ); ?>
			</div>
		</article>
		<?php if ( $mvweb_query->have_posts() ) : ?>
			<div class="mvweb-t-posts__top-minor">
				<?php
				while ( $mvweb_query->have_posts() ) :
					$mvweb_query->the_post();
					?>
					<article class="mvweb-t-posts__top-item<?php echo has_post_thumbnail() ? '' : ' mvweb-t-posts__top-item--plain'; ?>"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
						<?php $mvweb_media( 'mvweb-t-posts__top-thumb', 'medium' ); ?>
						<div class="mvweb-t-posts__top-item-text">
							<?php get_template_part( 'template-parts/journal/topic' ); ?>
							<div class="mvweb-t-posts__top-item-title"><a class="mvweb-t-jr-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
						</div>
					</article>
				<?php endwhile; ?>
			</div>
		<?php endif; ?>
	</div>
	<?php
else :
	$mvweb_day = (int) get_post_time( 'U', true );
	$mvweb_all = (int) $mvweb_query->post_count;
	?>
	<div class="mvweb-t-posts__daily"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
		<div class="mvweb-t-posts__daily-bar">
			<div>
				<?php
				printf(
					/* translators: %s: date of the day. */
					esc_html__( 'Main stories of %s', 'brand-market' ),
					'<time datetime="' . esc_attr( wp_date( 'Y-m-d', $mvweb_day ) ) . '">' . esc_html( wp_date( 'j F', $mvweb_day ) ) . '</time>'
				);
				?>
			</div>
			<span>
				<?php
				/* translators: %s: number of posts. */
				echo esc_html( sprintf( _n( '%s story', '%s stories', $mvweb_all, 'brand-market' ), number_format_i18n( $mvweb_all ) ) );
				?>
			</span>
		</div>
		<article class="mvweb-t-posts__daily-main">
			<?php $mvweb_media( 'mvweb-t-posts__daily-media', 'full' ); ?>
			<div class="mvweb-t-posts__daily-text">
				<div class="mvweb-t-posts__daily-num" aria-hidden="true">01</div>
				<?php get_template_part( 'template-parts/journal/topic' ); ?>
				<?php $mvweb_title( 'mvweb-t-posts__daily-title' ); ?>
				<?php if ( '' !== $mvweb_lead() ) : ?>
					<p class="mvweb-t-posts__daily-lead"><?php echo esc_html( $mvweb_lead() ); ?></p>
				<?php endif; ?>
				<?php get_template_part( 'template-parts/journal/byline', null, array( 'when' => 'time' ) ); ?>
			</div>
		</article>
		<?php if ( $mvweb_query->have_posts() ) : ?>
			<ol class="mvweb-t-posts__daily-list">
				<?php
				$mvweb_number = 2;

				while ( $mvweb_query->have_posts() ) :
					$mvweb_query->the_post();
					?>
					<li class="mvweb-t-posts__daily-item">
						<span class="mvweb-t-posts__daily-item-num" aria-hidden="true"><?php echo esc_html( sprintf( '%02d', $mvweb_number ) ); ?></span>
						<div class="mvweb-t-posts__daily-item-title"><a class="mvweb-t-jr-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
						<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( wp_date( 'Y-m-d', (int) get_post_time( 'U', true ) ) === wp_date( 'Y-m-d', $mvweb_day ) ? get_the_time() : mvweb_core_short_date() ); ?></time>
					</li>
					<?php
					++$mvweb_number;
				endwhile;
				?>
			</ol>
		<?php endif; ?>
	</div>
	<?php
endif;

wp_reset_postdata();
