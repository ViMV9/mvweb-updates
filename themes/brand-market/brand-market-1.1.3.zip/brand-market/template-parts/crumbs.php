<?php
/**
 * Breadcrumb trail.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! mvweb_core_layout_has( 'page-hero', 'crumbs' ) || ! empty( $GLOBALS['mvweb_theme_crumbs_done'] ) ) {
	return;
}

$GLOBALS['mvweb_theme_crumbs_done'] = true;

$mvweb_items = mvweb_core_crumb_items();

if ( count( $mvweb_items ) < 2 ) {
	return;
}
?>
<?php if ( ! empty( $args['wrap'] ) ) : ?>
<div class="mvweb-t-container">
<?php endif; ?>
<nav class="mvweb-t-crumbs" aria-label="<?php esc_attr_e( 'Breadcrumbs', 'brand-market' ); ?>">
	<ol class="mvweb-t-crumbs__list">
		<?php
		foreach ( $mvweb_items as $mvweb_item ) :
			$mvweb_label = empty( $mvweb_item['allow_html'] )
				? esc_html( $mvweb_item['label'] )
				: wp_kses_post( $mvweb_item['label'] );
			?>
			<li class="mvweb-t-crumbs__item"<?php echo empty( $mvweb_item['url'] ) ? ' aria-current="page"' : ''; ?>>
				<?php if ( empty( $mvweb_item['url'] ) ) : ?>
					<?php echo $mvweb_label; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above by the item's own rule. ?>
				<?php else : ?>
					<a href="<?php echo esc_url( $mvweb_item['url'] ); ?>"><?php echo $mvweb_label; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped above by the item's own rule. ?></a>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ol>
</nav>
<?php if ( ! empty( $args['wrap'] ) ) : ?>
</div>
<?php endif; ?>
