<?php
/**
 * Dashboard part: the tiles that lead to the sections of the account.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_items  = wc_get_account_menu_items();
$mvweb_counts = mvweb_core_account_order_counts( get_current_user_id() );
$mvweb_orders = 0 === $mvweb_counts['total']
	? __( 'No orders yet', 'brand-market' )
	/* translators: %d: number of orders. */
	: sprintf( _n( '%d order', '%d orders', $mvweb_counts['total'], 'brand-market' ), $mvweb_counts['total'] );

if ( 0 < $mvweb_counts['active'] ) {
	/* translators: %d: number of orders being handled. */
	$mvweb_orders .= sprintf( __( ', %d in progress', 'brand-market' ), $mvweb_counts['active'] );
}

$mvweb_known = array(
	'orders'    => array(
		'endpoint' => 'orders',
		'title'    => __( 'Orders', 'brand-market' ),
		'text'     => $mvweb_orders,
		'icon'     => 'package',
	),
	'addresses' => array(
		'endpoint' => 'edit-address',
		'title'    => mvweb_core_account_labels()['edit-address'],
		'text'     => ! wc_ship_to_billing_address_only() && wc_shipping_enabled() ? __( 'Delivery and payment', 'brand-market' ) : __( 'Payment address', 'brand-market' ),
		'icon'     => 'map-pin',
	),
	'details'   => array(
		'endpoint' => 'edit-account',
		'title'    => __( 'My details', 'brand-market' ),
		'text'     => __( 'Name, email, password', 'brand-market' ),
		'icon'     => 'user',
	),
);

$mvweb_tiles = array();

foreach ( mvweb_core_account_tiles() as $mvweb_slug ) {
	if ( isset( $mvweb_known[ $mvweb_slug ] ) && isset( $mvweb_items[ $mvweb_known[ $mvweb_slug ]['endpoint'] ] ) ) {
		$mvweb_tiles[] = $mvweb_known[ $mvweb_slug ];
	}
}

if ( empty( $mvweb_tiles ) ) {
	return;
}
?>
<div class="mvweb-t-acc-tiles">
	<?php foreach ( $mvweb_tiles as $mvweb_tile ) : ?>
		<a class="mvweb-t-acc-tile" href="<?php echo esc_url( wc_get_account_endpoint_url( $mvweb_tile['endpoint'] ) ); ?>">
			<span class="mvweb-t-acc-tile__icon"><?php echo mvweb_theme_icon( $mvweb_tile['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
			<span class="mvweb-t-acc-tile__title"><?php echo esc_html( $mvweb_tile['title'] ); ?></span>
			<span class="mvweb-t-acc-tile__text"><?php echo esc_html( $mvweb_tile['text'] ); ?></span>
			<span class="mvweb-t-acc-tile__go"><?php echo mvweb_theme_icon( 'chevron-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
		</a>
	<?php endforeach; ?>
</div>
