<?php
/**
 * Dashboard part: the latest orders of the customer.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_limit = mvweb_core_account_recent_count();

if ( 0 === $mvweb_limit || ! isset( wc_get_account_menu_items()['orders'] ) ) {
	return;
}

$mvweb_orders = wc_get_orders(
	array(
		'customer' => get_current_user_id(),
		'limit'    => $mvweb_limit,
		'orderby'  => 'date',
		'order'    => 'DESC',
	)
);

if ( empty( $mvweb_orders ) ) {
	return;
}
?>
<section class="mvweb-t-account__block">
	<div class="mvweb-t-account__head">
		<div class="mvweb-t-account__title mvweb-t-h2" role="heading" aria-level="2"><?php esc_html_e( 'Recent orders', 'brand-market' ); ?></div>
		<a class="mvweb-t-btn mvweb-t-btn--ghost" href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>"><?php esc_html_e( 'All orders', 'brand-market' ); ?></a>
	</div>
	<?php get_template_part( 'template-parts/account/orders-table', null, array( 'orders' => $mvweb_orders ) ); ?>
</section>
