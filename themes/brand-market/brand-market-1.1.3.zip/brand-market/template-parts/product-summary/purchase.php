<?php
/**
 * Item summary part: the purchase box.
 *
 * Its parts are the area product-purchase; a box none of them printed
 * leaves no frame behind. The look "purchase column" prints the box in its own
 * column, so the summary skips it there. The box carries the price and the
 * price steps for the script that counts the total.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! empty( $args['purchase_apart'] ) ) {
	return;
}

ob_start();
mvweb_core_render_layout( 'product-purchase', $args );
$mvweb_box = trim( (string) ob_get_clean() );

if ( '' === $mvweb_box ) {
	return;
}

$mvweb_data = mvweb_core_buy_data( isset( $args['id'] ) ? absint( $args['id'] ) : 0 );
?>
<div class="mvweb-t-product-purchase"<?php echo empty( $mvweb_data ) ? '' : ' data-buy="' . esc_attr( (string) wp_json_encode( $mvweb_data ) ) . '"'; ?>>
	<?php echo $mvweb_box; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed and escaped by the parts of the area. ?>
</div>
