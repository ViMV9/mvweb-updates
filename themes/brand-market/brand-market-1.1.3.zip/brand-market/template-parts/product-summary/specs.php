<?php
/**
 * Item summary part: the main specifications next to the purchase box.
 *
 * A list in most looks, tiles with icons in the look "specifications with
 * icons", a folded list in the look "purchase bar". The link leads to the full
 * specifications under the item when they are printed there.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id   = isset( $args['id'] ) ? absint( $args['id'] ) : 0;
$mvweb_view = mvweb_core_product_view();
$mvweb_rows = $mvweb_id ? mvweb_core_item_main_specs( $mvweb_id, 'panel' === $mvweb_view ? 12 : 6 ) : array();

if ( empty( $mvweb_rows ) ) {
	return;
}

$mvweb_all = mvweb_core_layout_has( 'product-sections', 'specs' ) && mvweb_core_product_section_filled( $mvweb_id, 'specs' );
$mvweb_tag = 'icons' === $mvweb_view ? 'ul' : 'dl';
?>
<div class="<?php echo esc_attr( 'mvweb-t-main-specs mvweb-t-main-specs--' . ( 'icons' === $mvweb_view ? 'tiles' : 'list' ) ); ?>">
	<?php if ( 'panel' === $mvweb_view ) : ?>
		<details class="mvweb-t-main-specs__fold">
			<summary class="mvweb-t-main-specs__head"><?php esc_html_e( 'Specifications', 'brand-market' ); ?></summary>
	<?php endif; ?>

	<<?php echo esc_html( $mvweb_tag ); ?> class="mvweb-t-main-specs__list">
		<?php foreach ( $mvweb_rows as $mvweb_row ) : ?>
			<?php if ( 'ul' === $mvweb_tag ) : ?>
				<li class="mvweb-t-main-specs__tile">
					<?php if ( '' !== $mvweb_row['icon'] ) : ?>
						<span class="mvweb-t-main-specs__icon" aria-hidden="true"><?php echo mvweb_theme_icon( $mvweb_row['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
					<?php endif; ?>
					<span class="mvweb-t-main-specs__text">
						<span class="mvweb-t-main-specs__label"><?php echo esc_html( $mvweb_row['label'] ); ?></span>
						<span class="mvweb-t-main-specs__value"><?php echo esc_html( $mvweb_row['value'] ); ?></span>
					</span>
				</li>
			<?php else : ?>
				<div class="mvweb-t-main-specs__row">
					<dt class="mvweb-t-main-specs__label"><?php echo esc_html( $mvweb_row['label'] ); ?></dt>
					<dd class="mvweb-t-main-specs__value"><?php echo esc_html( $mvweb_row['value'] ); ?></dd>
				</div>
			<?php endif; ?>
		<?php endforeach; ?>
	</<?php echo esc_html( $mvweb_tag ); ?>>

	<?php if ( $mvweb_all ) : ?>
		<a class="mvweb-t-main-specs__all" href="#specs"><?php esc_html_e( 'All specifications', 'brand-market' ); ?></a>
	<?php endif; ?>

	<?php if ( 'panel' === $mvweb_view ) : ?>
		</details>
	<?php endif; ?>
</div>
