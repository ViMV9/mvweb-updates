<?php
/**
 * Item summary part: the same item in the other values of a property.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_switch = isset( $args['id'] ) ? mvweb_core_switch_links( absint( $args['id'] ) ) : array();

if ( empty( $mvweb_switch ) ) {
	return;
}
?>
<div class="mvweb-t-product-switch">
	<p class="mvweb-t-product-switch__label"><?php echo esc_html( $mvweb_switch['label'] ); ?></p>

	<ul class="mvweb-t-product-switch__list">
		<?php foreach ( $mvweb_switch['terms'] as $mvweb_value ) : ?>
			<li>
				<a class="<?php echo esc_attr( 'mvweb-t-product-switch__link' . ( $mvweb_value['current'] ? ' mvweb-t-product-switch__link--current' : '' ) ); ?>" href="<?php echo esc_url( $mvweb_value['url'] ); ?>"<?php echo $mvweb_value['current'] ? ' aria-current="true"' : ''; ?>><?php echo esc_html( $mvweb_value['label'] ); ?></a>
			</li>
		<?php endforeach; ?>
	</ul>
</div>
