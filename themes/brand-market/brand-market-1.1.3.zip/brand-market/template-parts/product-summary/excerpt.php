<?php
/**
 * Item summary part: the short description.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_excerpt = isset( $args['id'] ) ? mvweb_core_item_excerpt( absint( $args['id'] ) ) : '';

if ( '' === trim( wp_strip_all_tags( $mvweb_excerpt ) ) ) {
	return;
}
?>
<div class="mvweb-t-product-desc">
	<?php echo $mvweb_excerpt; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Post excerpt passes wp_kses_post(); a shop product goes through the woocommerce_short_description filter, as in the WooCommerce template. ?>
</div>
