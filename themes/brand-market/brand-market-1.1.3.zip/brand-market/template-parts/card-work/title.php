<?php
/**
 * Work card part: the name, a link to the work.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_title = get_the_title( absint( $args['id'] ) );

if ( '' === $mvweb_title ) {
	return;
}
?>
<div class="mvweb-t-card__title mvweb-t-works__title mvweb-t-h3"><a href="<?php echo esc_url( $args['link'] ); ?>"><?php echo esc_html( $mvweb_title ); ?></a></div>
