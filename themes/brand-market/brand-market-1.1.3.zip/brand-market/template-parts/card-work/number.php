<?php
/**
 * Work card part: the number of the card in the ribbon.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( 'ribbon' !== $args['view'] || $args['index'] < 0 ) {
	return;
}
?>
<span class="mvweb-t-works__num"><?php echo esc_html( sprintf( '%02d', $args['index'] + 1 ) ); ?></span>
