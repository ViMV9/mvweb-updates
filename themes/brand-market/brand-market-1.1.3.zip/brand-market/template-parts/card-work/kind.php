<?php
/**
 * Work card part: the kind of work, a badge on the picture or a line over the name.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_kinds = get_the_terms( absint( $args['id'] ), 'mv_work_type' );

if ( ! is_array( $mvweb_kinds ) || empty( $mvweb_kinds ) ) {
	return;
}

$mvweb_name = (string) $mvweb_kinds[0]->name;

if ( '' === $mvweb_name ) {
	return;
}
?>
<?php if ( 'list' === $args['view'] ) : ?>
	<span class="mvweb-t-works__kind"><?php echo esc_html( $mvweb_name ); ?></span>
<?php else : ?>
	<span class="mvweb-t-card__badges"><span class="mvweb-t-badge"><?php echo esc_html( $mvweb_name ); ?></span></span>
<?php endif; ?>
