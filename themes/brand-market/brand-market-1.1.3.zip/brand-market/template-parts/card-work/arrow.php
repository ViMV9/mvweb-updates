<?php
/**
 * Work card part: the round arrow of the photo view and of the list.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! in_array( $args['view'], array( 'reveal', 'list' ), true ) ) {
	return;
}
?>
<span class="mvweb-t-works__go" aria-hidden="true"><?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
