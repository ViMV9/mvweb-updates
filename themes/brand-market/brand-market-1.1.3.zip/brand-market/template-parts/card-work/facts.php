<?php
/**
 * Work card part: the first facts of the work, figures only, as many as the setting says.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_limit  = absint( mvweb_core_works_option( 'mvweb_work_card_facts' ) );
$mvweb_values = $mvweb_limit > 0 ? array_filter( wp_list_pluck( mvweb_core_work_facts( absint( $args['id'] ), $mvweb_limit ), 'value' ), 'strlen' ) : array();

if ( empty( $mvweb_values ) ) {
	return;
}
?>
<ul class="mvweb-t-works__facts">
	<?php foreach ( $mvweb_values as $mvweb_value ) : ?>
		<li><?php echo esc_html( $mvweb_value ); ?></li>
	<?php endforeach; ?>
</ul>
