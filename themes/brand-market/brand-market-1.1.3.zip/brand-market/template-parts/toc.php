<?php
/**
 * Table of contents of an entry: the core has given the headings anchors.
 *
 * The h3 stand in a list of their own under the h2 they follow. Arguments: items.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_items = isset( $args['items'] ) ? (array) $args['items'] : array();
$mvweb_title = trim( (string) mvweb_core_blog_option( 'mvweb_toc_title' ) );
$mvweb_open  = false;
$mvweb_sub   = false;
?>
<details class="mvweb-t-toc" data-toc open>
	<?php if ( '' !== $mvweb_title ) : ?>
		<summary class="mvweb-t-toc__title"><?php echo esc_html( $mvweb_title ); ?></summary>
	<?php else : ?>
		<summary class="mvweb-t-toc__title"><span class="screen-reader-text"><?php esc_html_e( 'Contents', 'brand-market' ); ?></span></summary>
	<?php endif; ?>
	<ol class="mvweb-t-toc__list">
		<?php
		foreach ( $mvweb_items as $mvweb_item ) :
			if ( 3 === (int) $mvweb_item['level'] && $mvweb_open ) :
				echo $mvweb_sub ? '' : '<ol class="mvweb-t-toc__sub">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
				$mvweb_sub = true;
				?>
				<li><a href="#<?php echo esc_attr( $mvweb_item['anchor'] ); ?>"><?php echo esc_html( $mvweb_item['text'] ); ?></a></li>
				<?php
				continue;
			endif;

			echo $mvweb_sub ? '</ol>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
			echo $mvweb_open ? '</li>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
			$mvweb_sub  = false;
			$mvweb_open = true;
			?>
			<li><a href="#<?php echo esc_attr( $mvweb_item['anchor'] ); ?>"><?php echo esc_html( $mvweb_item['text'] ); ?></a>
		<?php endforeach; ?>
		<?php
		echo $mvweb_sub ? '</ol>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
		echo $mvweb_open ? '</li>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
		?>
	</ol>
</details>
