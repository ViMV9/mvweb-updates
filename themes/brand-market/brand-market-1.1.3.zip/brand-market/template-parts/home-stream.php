<?php
/**
 * The homepage as a feed of posts with numbered pages.
 *
 * The look «Blocks on top» prints the blocks of the homepage on its first page
 * and the feed under them; the next pages print the feed only. When no block
 * takes the h1, the logo of the header does (mvweb_core_h1_reserve()).
 *
 * Arguments: rows (the blocks of the homepage).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rows  = isset( $args['rows'] ) && is_array( $args['rows'] ) ? $args['rows'] : array();
$mvweb_mode  = mvweb_core_home_mode();
$mvweb_top   = 'top' === $mvweb_mode && 1 === mvweb_core_home_page() && ! empty( $mvweb_rows );
$mvweb_query = mvweb_core_home_stream_query();

mvweb_core_h1_reserve( $mvweb_top ? $mvweb_rows : array() );

get_header();

if ( is_page() ) {
	while ( have_posts() ) {
		the_post();
	}
}

if ( $mvweb_top ) {
	mvweb_core_render_sections( $mvweb_rows );
}
?>
<section class="mvweb-t-section mvweb-t-stream-section">
	<div class="mvweb-t-container">
		<?php if ( $mvweb_top ) : ?>
			<div class="mvweb-t-section-head">
				<div class="mvweb-t-section-head__text">
					<div class="mvweb-t-section-head__title mvweb-t-h2" role="heading" aria-level="2"><?php esc_html_e( 'Latest stories', 'brand-market' ); ?></div>
				</div>
			</div>
		<?php endif; ?>
		<?php
		if ( null !== $mvweb_query ) {
			get_template_part(
				'template-parts/post-stream',
				null,
				array(
					'view'  => $mvweb_mode,
					'query' => $mvweb_query,
					'pager' => mvweb_core_stream_pager( $mvweb_query ),
				)
			);
		}
		?>
	</div>
</section>
<?php
get_footer();
