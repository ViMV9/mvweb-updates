<?php
/**
 * Tree head part: the description of the section.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! $args['term'] instanceof WP_Term || ! mvweb_core_option( 'mvweb_service_tree_desc' ) ) {
	return;
}

$mvweb_desc = wp_trim_words( wp_strip_all_tags( $args['term']->description ), 26 );

if ( '' === $mvweb_desc ) {
	return;
}
?>
<p class="mvweb-t-svc-group__desc"><?php echo esc_html( $mvweb_desc ); ?></p>
