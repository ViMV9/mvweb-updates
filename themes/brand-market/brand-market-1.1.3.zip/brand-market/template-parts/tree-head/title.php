<?php
/**
 * Tree head part: the name of the section.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="mvweb-t-svc-group__title mvweb-t-h2" role="heading" aria-level="2">
	<?php if ( '' !== $args['link'] ) : ?>
		<a href="<?php echo esc_url( $args['link'] ); ?>"><?php echo esc_html( $args['title'] ); ?></a>
	<?php else : ?>
		<?php echo esc_html( $args['title'] ); ?>
	<?php endif; ?>
</div>
