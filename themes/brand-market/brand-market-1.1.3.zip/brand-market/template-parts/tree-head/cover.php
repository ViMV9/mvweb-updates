<?php
/**
 * Tree head part: the cover of the section, a link to it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_term  = $args['term'];
$mvweb_thumb = $mvweb_term instanceof WP_Term ? absint( get_term_meta( $mvweb_term->term_id, 'thumbnail_id', true ) ) : 0;

if ( '' === $args['link'] || ! wp_attachment_is_image( $mvweb_thumb ) ) {
	return;
}
?>
<a class="mvweb-t-svc-group__cover" href="<?php echo esc_url( $args['link'] ); ?>" tabindex="-1" aria-hidden="true">
	<?php
	echo wp_get_attachment_image(
		$mvweb_thumb,
		'medium_large',
		false,
		array(
			'alt'      => mvweb_core_image_alt( $mvweb_thumb, $mvweb_term->name ),
			'loading'  => 'lazy',
			'decoding' => 'async',
		)
	);
	?>
</a>
