<?php
/**
 * Tree head part: the number of services in the section.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( 0 === $args['count'] ) {
	return;
}

/* translators: %s: number of services in the section. */
$mvweb_text = sprintf( _n( '%s service', '%s services', $args['count'], 'brand-market' ), number_format_i18n( $args['count'] ) );
?>
<p class="mvweb-t-svc-group__count"><?php echo esc_html( $mvweb_text ); ?></p>
