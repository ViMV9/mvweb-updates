<?php
/**
 * Tree head part: the link to the section.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( '' === $args['link'] ) {
	return;
}

$mvweb_more = trim( (string) mvweb_core_services_pages_option( 'mvweb_service_section_more' ) );
?>
<a class="mvweb-t-svc-group__more" href="<?php echo esc_url( $args['link'] ); ?>"<?php echo '' === $mvweb_more ? ' aria-label="' . esc_attr( $args['title'] ) . '"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in place. ?>>
	<?php echo esc_html( $mvweb_more ); ?>
	<?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
</a>
