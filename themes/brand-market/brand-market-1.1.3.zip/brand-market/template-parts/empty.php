<?php
/**
 * Empty state: a list that has nothing to show.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_theme_icon  = isset( $args['icon'] ) ? (string) $args['icon'] : 'search';
$mvweb_title       = isset( $args['title'] ) ? (string) $args['title'] : '';
$mvweb_text        = isset( $args['text'] ) ? (string) $args['text'] : '';
$mvweb_button_url  = isset( $args['button_url'] ) ? (string) $args['button_url'] : '';
$mvweb_button_text = isset( $args['button_text'] ) ? (string) $args['button_text'] : '';
?>
<div class="mvweb-t-empty mvweb-t-empty--card">
	<?php if ( '' !== $mvweb_theme_icon ) : ?>
		<span class="mvweb-t-empty__icon"><?php echo mvweb_theme_icon( $mvweb_theme_icon ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
	<?php endif; ?>

	<?php if ( '' !== $mvweb_title ) : ?>
		<div class="mvweb-t-empty__title mvweb-t-h2" role="heading" aria-level="2"><?php echo esc_html( $mvweb_title ); ?></div>
	<?php endif; ?>

	<?php if ( '' !== $mvweb_text ) : ?>
		<p class="mvweb-t-empty__text"><?php echo esc_html( $mvweb_text ); ?></p>
	<?php endif; ?>

	<?php if ( '' !== $mvweb_button_url && '' !== $mvweb_button_text ) : ?>
		<a class="mvweb-t-btn mvweb-t-btn--outline" href="<?php echo esc_url( $mvweb_button_url ); ?>"><?php echo esc_html( $mvweb_button_text ); ?></a>
	<?php endif; ?>
</div>
