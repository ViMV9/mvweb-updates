<?php
/**
 * Sign-in part: what an account gives, as a row of cards.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_perks = mvweb_core_account_perks();

if ( empty( $mvweb_perks ) ) {
	return;
}
?>
<section class="mvweb-t-perks" aria-label="<?php esc_attr_e( 'What an account gives', 'brand-market' ); ?>">
	<?php foreach ( $mvweb_perks as $mvweb_perk ) : ?>
		<div class="mvweb-t-perk">
			<?php if ( '' !== $mvweb_perk['icon'] ) : ?>
				<?php echo mvweb_theme_icon( $mvweb_perk['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<?php endif; ?>
			<?php if ( '' !== $mvweb_perk['title'] ) : ?>
				<div class="mvweb-t-perk__title mvweb-t-h2" role="heading" aria-level="2"><?php echo esc_html( $mvweb_perk['title'] ); ?></div>
			<?php endif; ?>
			<?php if ( '' !== $mvweb_perk['text'] ) : ?>
				<p><?php echo esc_html( $mvweb_perk['text'] ); ?></p>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>
</section>
