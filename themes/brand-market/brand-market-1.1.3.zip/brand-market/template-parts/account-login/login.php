<?php
/**
 * Sign-in part: the card with the login form.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_back = ( isset( $_GET['redirect_to'] ) && is_string( $_GET['redirect_to'] ) ) ? wp_validate_redirect( esc_url_raw( wp_unslash( $_GET['redirect_to'] ) ), '' ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only the page to return to after signing in, checked against the site.
$mvweb_user = ( ! empty( $_POST['username'] ) && is_string( $_POST['username'] ) ) ? sanitize_text_field( wp_unslash( $_POST['username'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Only fills the field back in after a failed sign in.
?>
<section class="mvweb-t-auth__card">
	<div class="mvweb-t-auth__title mvweb-t-h2" role="heading" aria-level="2"><?php esc_html_e( 'Login', 'brand-market' ); ?></div>
	<?php
	if ( empty( $_POST['register'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Only chooses the card that shows the notices.
		wc_print_notices();
	}
	?>
	<form class="mvweb-t-account__form mvweb-t-account__form--full woocommerce-form woocommerce-form-login login" method="post" novalidate>
		<?php do_action( 'woocommerce_login_form_start' ); ?>
		<div class="mvweb-t-field">
			<label class="mvweb-t-field__label" for="username"><?php esc_html_e( 'Email or login', 'brand-market' ); ?></label>
			<input class="mvweb-t-field__input" id="username" name="username" type="text" autocomplete="username" value="<?php echo esc_attr( $mvweb_user ); ?>" required>
		</div>
		<div class="mvweb-t-field">
			<label class="mvweb-t-field__label" for="password"><?php esc_html_e( 'Password', 'brand-market' ); ?></label>
			<?php
			get_template_part(
				'template-parts/account/password',
				null,
				array(
					'id'           => 'password',
					'autocomplete' => 'current-password',
					'required'     => true,
				)
			);
			?>
		</div>
		<?php do_action( 'woocommerce_login_form' ); ?>
		<div class="mvweb-t-auth__row">
			<label class="mvweb-t-check"><input type="checkbox" name="rememberme" id="rememberme" value="<?php echo esc_attr( 'forever' ); ?>"><span><?php esc_html_e( 'Remember me', 'brand-market' ); ?></span></label>
			<a href="<?php echo esc_url( wp_lostpassword_url() ); ?>"><?php esc_html_e( 'Forgot your password?', 'brand-market' ); ?></a>
		</div>
		<?php wp_nonce_field( 'woocommerce-login', 'woocommerce-login-nonce' ); ?>
		<?php if ( $mvweb_back ) : ?>
			<input type="hidden" name="redirect" value="<?php echo esc_url( $mvweb_back ); ?>">
		<?php endif; ?>
		<button class="mvweb-t-btn mvweb-t-btn--block" type="submit" name="login" value="<?php esc_attr_e( 'Log in', 'brand-market' ); ?>"><?php esc_html_e( 'Log in', 'brand-market' ); ?></button>
		<?php do_action( 'woocommerce_login_form_end' ); ?>
	</form>
</section>
