<?php
/**
 * Sign-in part: the card with the registration form.
 *
 * Arguments: register (bool, whether WooCommerce allows registration).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $args['register'] ) ) {
	return;
}

$mvweb_posted  = static function ( $key ) {
	return ( ! empty( $_POST[ $key ] ) && is_string( $_POST[ $key ] ) ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Only fills the field back in after a failed registration.
};
$mvweb_back    = ( isset( $_GET['redirect_to'] ) && is_string( $_GET['redirect_to'] ) ) ? wp_validate_redirect( esc_url_raw( wp_unslash( $_GET['redirect_to'] ) ), '' ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only the page to return to after signing up, checked against the site.
$mvweb_privacy = get_privacy_policy_url();
$mvweb_consent = '' !== $mvweb_privacy
	? sprintf(
		/* translators: %s: link to the privacy policy. */
		__( 'I agree to the processing of personal data and to the %s', 'brand-market' ),
		'<a href="' . esc_url( $mvweb_privacy ) . '">' . esc_html__( 'privacy policy', 'brand-market' ) . '</a>'
	)
	: esc_html__( 'I agree to the processing of personal data', 'brand-market' );
?>
<section class="mvweb-t-auth__card mvweb-t-auth__card--fill">
	<div class="mvweb-t-auth__title mvweb-t-h2" role="heading" aria-level="2"><?php esc_html_e( 'Registration', 'brand-market' ); ?></div>
	<p class="mvweb-t-auth__lead"><?php esc_html_e( 'Orders and addresses are saved, and a purchase can be repeated in one click.', 'brand-market' ); ?></p>
	<?php
	if ( ! empty( $_POST['register'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Only chooses the card that shows the notices.
		wc_print_notices();
	}
	?>
	<form class="mvweb-t-account__form mvweb-t-account__form--full woocommerce-form woocommerce-form-register register" method="post" <?php do_action( 'woocommerce_register_form_tag' ); ?>>
		<?php do_action( 'woocommerce_register_form_start' ); ?>
		<?php if ( 'no' === get_option( 'woocommerce_registration_generate_username' ) ) : ?>
			<div class="mvweb-t-field">
				<label class="mvweb-t-field__label" for="reg_username"><?php esc_html_e( 'Username', 'brand-market' ); ?></label>
				<input class="mvweb-t-field__input" id="reg_username" name="username" type="text" autocomplete="username" value="<?php echo esc_attr( $mvweb_posted( 'username' ) ); ?>" required>
			</div>
		<?php endif; ?>
		<div class="mvweb-t-field">
			<label class="mvweb-t-field__label" for="reg_first_name"><?php esc_html_e( 'First name', 'brand-market' ); ?></label>
			<input class="mvweb-t-field__input" id="reg_first_name" name="first_name" type="text" autocomplete="given-name" value="<?php echo esc_attr( $mvweb_posted( 'first_name' ) ); ?>">
		</div>
		<div class="mvweb-t-field">
			<label class="mvweb-t-field__label" for="reg_email"><?php esc_html_e( 'Email address', 'brand-market' ); ?></label>
			<input class="mvweb-t-field__input" id="reg_email" name="email" type="email" autocomplete="email" value="<?php echo esc_attr( $mvweb_posted( 'email' ) ); ?>" required>
		</div>
		<?php if ( 'no' === get_option( 'woocommerce_registration_generate_password' ) ) : ?>
			<div class="mvweb-t-field">
				<label class="mvweb-t-field__label" for="reg_password"><?php esc_html_e( 'Password', 'brand-market' ); ?></label>
				<?php
				get_template_part(
					'template-parts/account/password',
					null,
					array(
						'id'           => 'reg_password',
						'autocomplete' => 'new-password',
						'required'     => true,
						'minlength'    => 8,
					)
				);
				?>
				<span class="mvweb-t-form-hint"><?php esc_html_e( 'At least 8 characters', 'brand-market' ); ?></span>
			</div>
		<?php else : ?>
			<p class="mvweb-t-form-hint"><?php esc_html_e( 'A link to set a new password will be sent to your email.', 'brand-market' ); ?></p>
		<?php endif; ?>
		<?php do_action( 'woocommerce_register_form' ); ?>
		<label class="mvweb-t-check"><input type="checkbox" name="agree" value="1" required><span><?php echo wp_kses_post( $mvweb_consent ); ?></span></label>
		<?php wp_nonce_field( 'woocommerce-register', 'woocommerce-register-nonce' ); ?>
		<?php if ( $mvweb_back ) : ?>
			<input type="hidden" name="redirect" value="<?php echo esc_url( $mvweb_back ); ?>">
		<?php endif; ?>
		<button class="mvweb-t-btn mvweb-t-btn--block" type="submit" name="register" value="<?php esc_attr_e( 'Register', 'brand-market' ); ?>"><?php esc_html_e( 'Register', 'brand-market' ); ?></button>
		<?php do_action( 'woocommerce_register_form_end' ); ?>
	</form>
</section>
