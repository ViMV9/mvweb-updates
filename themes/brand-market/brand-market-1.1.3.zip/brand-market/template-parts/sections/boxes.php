<?php
/**
 * Section template: boxes on sale.
 *
 * One box stands as a wide banner with its picture beside the text; several
 * stand as cards in a row. The parts of a box come in the order the
 * composition sets; a part without data is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'boxes', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_ids   = array();
$mvweb_rows  = array();

if ( 'manual' === ( isset( $mvweb_props['source'] ) ? $mvweb_props['source'] : 'all' ) && ! empty( $mvweb_props['items'] ) && is_array( $mvweb_props['items'] ) ) {
	foreach ( mvweb_core_visible_rows( $mvweb_props['items'] ) as $mvweb_row ) {
		$mvweb_id = absint( isset( $mvweb_row['item'] ) ? $mvweb_row['item'] : 0 );

		if ( $mvweb_id && ! isset( $mvweb_rows[ $mvweb_id ] ) ) {
			$mvweb_rows[ $mvweb_id ] = $mvweb_row;
		}
	}

	$mvweb_ids = array_keys( $mvweb_rows );

	if ( empty( $mvweb_ids ) ) {
		return;
	}
}

$mvweb_boxes = mvweb_core_boxes( $mvweb_ids, empty( $mvweb_ids ) ? max( 1, absint( isset( $mvweb_props['count'] ) ? $mvweb_props['count'] : 3 ) ) : 6 );

if ( empty( $mvweb_boxes ) ) {
	return;
}

$mvweb_rv     = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_button = isset( $mvweb_props['button'] ) ? (string) $mvweb_props['button'] : '';

$mvweb_parts = array(
	'image'    => static function ( $box ) {
		$image = $box->get_image( 'mvweb_wide', array( 'class' => 'mvweb-t-boxes__img' ) );

		echo '<a class="mvweb-t-boxes__media" href="' . esc_url( $box->get_permalink() ) . '" tabindex="-1" aria-hidden="true">' . $image . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Image markup of WooCommerce, escaped inside.
	},
	'title'    => static function ( $box ) {
		echo '<div class="mvweb-t-boxes__title mvweb-t-h3"><a href="' . esc_url( $box->get_permalink() ) . '">' . esc_html( $box->get_name() ) . '</a></div>';
	},
	'text'     => static function ( $box ) {
		$text = trim( wp_strip_all_tags( (string) $box->get_short_description() ) );

		if ( '' !== $text ) {
			echo '<p class="mvweb-t-boxes__text">' . esc_html( $text ) . '</p>';
		}
	},
	'contents' => static function ( $box, $state ) {
		echo '<ul class="mvweb-t-boxes__contents" aria-label="' . esc_attr__( 'In the box', 'brand-market' ) . '">';

		foreach ( $state['items'] as $item ) {
			echo '<li class="mvweb-t-boxes__thing" title="' . esc_attr( $item->get_name() ) . '">' . $item->get_image( 'thumbnail' ) . '<span class="screen-reader-text">' . esc_html( $item->get_name() ) . '</span></li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Image markup of WooCommerce, escaped inside.
		}

		echo '</ul>';
	},
	'price'    => static function ( $box, $state ) {
		get_template_part( 'template-parts/box/price', null, array( 'state' => $state ) );
	},
	'terms'    => static function ( $box, $state ) {
		get_template_part( 'template-parts/box/terms', null, array( 'state' => $state ) );
	},
	'button'   => static function ( $box, $state ) use ( $mvweb_button ) {
		echo '<div class="mvweb-t-boxes__actions">';
		get_template_part(
			'template-parts/box/form',
			null,
			array(
				'product' => $box,
				'state'   => $state,
				'text'    => $mvweb_button,
			)
		);
		echo '<a class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-boxes__more" href="' . esc_url( $box->get_permalink() ) . '">' . esc_html__( 'Details', 'brand-market' ) . '</a>';
		echo '</div>';
	},
);

$mvweb_print_list = static function ( $block ) use ( $mvweb_boxes, $mvweb_parts, $mvweb_rv, $mvweb_rows ) {
	$single = 1 === count( $mvweb_boxes );

	echo '<ul class="mvweb-t-boxes__list' . ( $single ? ' mvweb-t-boxes__list--single' : '' ) . '">';

	foreach ( $mvweb_boxes as $box ) {
		$state = mvweb_core_box_state( $box );
		$media = in_array( 'image', $block['item_parts'], true ) && $box->get_image_id();
		$badge = mvweb_core_box_badge( $box, isset( $mvweb_rows[ $box->get_id() ] ) ? $mvweb_rows[ $box->get_id() ] : array() );

		echo '<li class="mvweb-t-boxes__item"' . $mvweb_rv . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute.

		if ( $badge ) {
			echo '<span class="mvweb-t-badge mvweb-t-boxes__badge mvweb-t-boxes__badge--' . esc_attr( $badge['place'] ) . ' mvweb-t-boxes__badge--' . esc_attr( $badge['shape'] ) . '"' . ( '' !== $badge['style'] ? ' style="' . esc_attr( $badge['style'] ) . '"' : '' ) . '>' . esc_html( $badge['text'] ) . '</span>';
		}

		if ( $media ) {
			$mvweb_parts['image']( $box, $state );
		}

		echo '<div class="mvweb-t-boxes__body">';

		foreach ( $block['item_parts'] as $slug ) {
			if ( 'image' !== $slug && isset( $mvweb_parts[ $slug ] ) ) {
				$mvweb_parts[ $slug ]( $box, $state );
			}
		}

		echo '</div></li>';
	}

	echo '</ul>';
};

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts( $mvweb_block, array( 'list' => $mvweb_print_list ), array( 'rv' => true ) );
mvweb_theme_section_close();
