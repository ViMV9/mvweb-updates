<?php
/**
 * Journal part: the author with the photo, the date and the reading time of the current post.
 *
 * Arguments: when (date or time: the time of the day for the posts of one day).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_author  = (int) get_post_field( 'post_author', get_the_ID() );
$mvweb_name    = trim( (string) get_the_author_meta( 'display_name', $mvweb_author ) );
$mvweb_minutes = mvweb_core_reading_minutes( get_the_ID() );
$mvweb_when    = isset( $args['when'] ) && 'time' === $args['when'] ? get_the_time() : mvweb_core_short_date();
?>
<div class="mvweb-t-jr-by">
	<?php if ( $mvweb_author > 0 && '' !== $mvweb_name ) : ?>
		<?php echo get_avatar( $mvweb_author, 80, '', '', array( 'class' => 'mvweb-t-jr-by__photo' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag. ?>
	<?php endif; ?>
	<div class="mvweb-t-jr-by__text">
		<?php if ( $mvweb_author > 0 && '' !== $mvweb_name ) : ?>
			<a class="mvweb-t-jr-by__name" href="<?php echo esc_url( get_author_posts_url( $mvweb_author ) ); ?>"><?php echo esc_html( $mvweb_name ); ?></a>
		<?php endif; ?>
		<div class="mvweb-t-jr-by__meta">
			<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( $mvweb_when ); ?></time>
			<?php if ( $mvweb_minutes > 0 ) : ?>
				<span>
					<?php
					/* translators: %s: number of minutes. */
					echo esc_html( sprintf( __( '%s min read', 'brand-market' ), number_format_i18n( $mvweb_minutes ) ) );
					?>
				</span>
			<?php endif; ?>
		</div>
	</div>
</div>
