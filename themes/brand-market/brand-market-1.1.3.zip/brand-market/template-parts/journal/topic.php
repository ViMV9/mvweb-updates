<?php
/**
 * Journal part: the first category of the current post as a link.
 *
 * Arguments: class (the class of the link).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_terms = get_the_category();

if ( empty( $mvweb_terms ) ) {
	return;
}

$mvweb_class = isset( $args['class'] ) ? (string) $args['class'] : 'mvweb-t-jr-topic';
?>
<a class="<?php echo esc_attr( $mvweb_class ); ?>" href="<?php echo esc_url( get_category_link( $mvweb_terms[0] ) ); ?>"><?php echo esc_html( $mvweb_terms[0]->name ); ?></a>
