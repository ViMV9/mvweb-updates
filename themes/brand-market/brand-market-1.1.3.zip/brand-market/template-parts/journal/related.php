<?php
/**
 * Journal part: the card «Read also» of an own post inside the text, in the markup of the card of an embed, so the set of the callouts styles it.
 *
 * Arguments: post (post id).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['post'] ) ? (int) $args['post'] : 0;

if ( $mvweb_id < 1 ) {
	return;
}

$mvweb_url     = get_permalink( $mvweb_id );
$mvweb_lead    = wp_trim_words( wp_strip_all_tags( get_the_excerpt( $mvweb_id ) ), 24 );
$mvweb_cats    = get_the_category( $mvweb_id );
$mvweb_minutes = mvweb_core_reading_minutes( $mvweb_id );
?>
<figure class="wp-block-embed is-type-wp-embed mvweb-t-related">
	<div class="wp-block-embed__wrapper">
		<div class="wp-embed">
			<?php if ( has_post_thumbnail( $mvweb_id ) ) : ?>
				<div class="wp-embed-featured-image">
					<a href="<?php echo esc_url( $mvweb_url ); ?>" tabindex="-1" aria-hidden="true"><?php echo get_the_post_thumbnail( $mvweb_id, 'medium_large', array( 'loading' => 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds the image tag. ?></a>
				</div>
			<?php endif; ?>
			<div class="wp-embed-heading"><a href="<?php echo esc_url( $mvweb_url ); ?>"><?php echo esc_html( get_the_title( $mvweb_id ) ); ?></a></div>
			<?php if ( '' !== $mvweb_lead ) : ?>
				<div class="wp-embed-excerpt"><p><?php echo esc_html( $mvweb_lead ); ?></p></div>
			<?php endif; ?>
			<div class="wp-embed-footer">
				<div class="wp-embed-meta">
					<?php if ( ! empty( $mvweb_cats ) ) : ?>
						<span><?php echo esc_html( $mvweb_cats[0]->name ); ?></span>
					<?php endif; ?>
					<?php if ( $mvweb_minutes > 0 ) : ?>
						<span>
							<?php
							/* translators: %s: number of minutes. */
							echo esc_html( sprintf( __( '%s min read', 'brand-market' ), number_format_i18n( $mvweb_minutes ) ) );
							?>
						</span>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</figure>
