<?php
/**
 * The entries of the query: the strip of links, the large first post, the grid of cards, the pagination, the text under them and what stands in for all of it when the query came back empty.
 *
 * The look follows the setting «Look of the list of posts»: the grid, the
 * magazine (the main story and a grid of four), the feed by days or masonry;
 * the list and its pages print through template-parts/post-stream.php.
 *
 * Arguments: chips (topics or months), feature (the first post is printed
 * large in the grid), text (the copy under the cards, markup), empty_icon, empty_title,
 * empty_text, empty_button_url, empty_button_text, empty_search_form.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_args = wp_parse_args(
	isset( $args ) && is_array( $args ) ? $args : array(),
	array(
		'chips'             => '',
		'feature'           => false,
		'text'              => '',
		'empty_icon'        => 'search',
		'empty_title'       => '',
		'empty_text'        => '',
		'empty_button_url'  => '',
		'empty_button_text' => '',
		'empty_search_form' => false,
	)
);
?>
<section class="mvweb-t-section mvweb-t-section--flush-top">
	<div class="mvweb-t-container">
		<?php
		if ( '' !== $mvweb_args['chips'] ) {
			get_template_part( 'template-parts/blog-chips', null, array( 'kind' => $mvweb_args['chips'] ) );
		}

		$mvweb_view  = mvweb_core_blog_view();
		$mvweb_found = have_posts();

		if ( $mvweb_found ) {
			if ( 'journal' === $mvweb_view && ! is_paged() ) {
				get_template_part(
					'template-parts/posts-hero',
					null,
					array(
						'look'  => 'top',
						'query' => mvweb_core_query_of( array_slice( $GLOBALS['wp_query']->posts, 0, 1 ) ),
					)
				);
				the_post();
			} elseif ( $mvweb_args['feature'] && 'grid' === $mvweb_view ) {
				the_post();

				get_template_part( 'template-parts/post-feature' );
			}

			get_template_part(
				'template-parts/post-stream',
				null,
				array(
					'view' => 'journal' === $mvweb_view ? 'grid' : $mvweb_view,
					'hide' => 'journal' === $mvweb_view ? array( 'lead', 'more' ) : array(),
				)
			);

			if ( '' !== trim( (string) $mvweb_args['text'] ) ) :
				?>
				<div class="mvweb-t-prose mvweb-t-catalog__text" data-prose>
					<?php echo apply_filters( 'the_content', $mvweb_args['text'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The saved value passed wp_kses_post: the key is registered with it as the sanitize callback. ?>
				</div>
				<?php
			endif;
		} else {
			get_template_part(
				'template-parts/empty',
				null,
				array(
					'icon'        => $mvweb_args['empty_icon'],
					'title'       => $mvweb_args['empty_title'],
					'text'        => $mvweb_args['empty_text'],
					'button_url'  => $mvweb_args['empty_button_url'],
					'button_text' => $mvweb_args['empty_button_text'],
				)
			);

			if ( $mvweb_args['empty_search_form'] ) {
				get_search_form();
			}
		}
		?>
	</div>
</section>
