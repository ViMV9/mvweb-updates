<?php
/**
 * The goods of an order and the rows of its total, for the order received page and the payment page.
 *
 * Arguments: order.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_order = isset( $args['order'] ) ? $args['order'] : null;

if ( ! $mvweb_order instanceof WC_Order ) {
	return;
}

$mvweb_rows  = $mvweb_order->get_order_item_totals();
$mvweb_total = isset( $mvweb_rows['order_total'] ) ? $mvweb_rows['order_total'] : null;
$mvweb_names = array(
	'cart_subtotal' => __( 'Goods', 'brand-market' ),
	'discount'      => __( 'Promo code', 'brand-market' ),
	'shipping'      => __( 'Delivery', 'brand-market' ),
);

unset( $mvweb_rows['order_total'], $mvweb_rows['payment_method'] );
?>
<ul class="mvweb-t-sitems">
	<?php foreach ( $mvweb_order->get_items() as $mvweb_item_id => $mvweb_item ) : ?>
		<?php
		if ( ! apply_filters( 'woocommerce_order_item_visible', true, $mvweb_item ) ) { // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
			continue;
		}

		$mvweb_product = $mvweb_item->get_product();
		?>
		<li class="mvweb-t-sitem">
			<span class="mvweb-t-sitem__media">
				<?php echo $mvweb_product ? $mvweb_product->get_image( 'mvweb_card', array( 'loading' => 'lazy' ) ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WooCommerce image markup. ?>
				<span class="mvweb-t-sitem__qty"><?php echo esc_html( number_format_i18n( (float) $mvweb_item->get_quantity() ) ); ?></span>
			</span>
			<div class="mvweb-t-sitem__name">
				<?php
				echo wp_kses_post( apply_filters( 'woocommerce_order_item_name', $mvweb_item->get_name(), $mvweb_item, false ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
				do_action( 'woocommerce_order_item_meta_start', $mvweb_item_id, $mvweb_item, $mvweb_order, false ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
				wc_display_item_meta( $mvweb_item );
				do_action( 'woocommerce_order_item_meta_end', $mvweb_item_id, $mvweb_item, $mvweb_order, false ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
				?>
			</div>
			<span class="mvweb-t-sitem__sum"><?php echo wp_kses_post( $mvweb_order->get_formatted_line_subtotal( $mvweb_item ) ); ?></span>
		</li>
	<?php endforeach; ?>
</ul>
<dl class="mvweb-t-summary__rows">
	<?php foreach ( $mvweb_rows as $mvweb_key => $mvweb_row ) : ?>
		<div>
			<dt><?php echo esc_html( isset( $mvweb_names[ $mvweb_key ] ) ? $mvweb_names[ $mvweb_key ] : rtrim( trim( wp_strip_all_tags( $mvweb_row['label'] ) ), ':' ) ); ?></dt>
			<dd><?php echo wp_kses_post( $mvweb_row['value'] ); ?></dd>
		</div>
	<?php endforeach; ?>
</dl>
<?php if ( $mvweb_total ) : ?>
	<p class="mvweb-t-summary__total">
		<span><?php esc_html_e( 'Total', 'brand-market' ); ?></span>
		<span class="mvweb-t-summary__amount"><strong><?php echo wp_kses_post( $mvweb_total['value'] ); ?></strong></span>
	</p>
<?php endif; ?>
