<?php
/**
 * Work head part: the heading of the page.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_title = mvweb_core_alt_h1();
$mvweb_title = '' !== $mvweb_title ? $mvweb_title : get_the_title( absint( $args['id'] ) );
?>
<h1 class="mvweb-t-product-title"><?php echo esc_html( $mvweb_title ); ?></h1>
