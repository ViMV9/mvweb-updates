<?php
/**
 * Work head part: the short text under the heading.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_excerpt = trim( (string) mvweb_core_item_excerpt( absint( $args['id'] ) ) );

if ( '' === $mvweb_excerpt ) {
	return;
}
?>
<div class="mvweb-t-product-desc"><?php echo $mvweb_excerpt; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Closes its chain with wp_kses_post(). ?></div>
