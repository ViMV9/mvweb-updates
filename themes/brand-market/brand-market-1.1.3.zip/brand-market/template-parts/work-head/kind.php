<?php
/**
 * Work head part: the kind of work, a link over the heading.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_kinds = get_the_terms( absint( $args['id'] ), 'mv_work_type' );

if ( ! is_array( $mvweb_kinds ) || empty( $mvweb_kinds ) ) {
	return;
}
?>
<p class="mvweb-t-work__kind">
	<?php foreach ( $mvweb_kinds as $mvweb_index => $mvweb_kind ) : ?>
		<?php echo 0 < $mvweb_index ? ' · ' : ''; ?><a href="<?php echo esc_url( (string) get_term_link( $mvweb_kind ) ); ?>"><?php echo esc_html( $mvweb_kind->name ); ?></a>
	<?php endforeach; ?>
</p>
