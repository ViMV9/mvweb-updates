<?php
/**
 * Favourites part: the number of items under the heading.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! isset( $args['place'] ) || 'hero' !== $args['place'] ) {
	return;
}
?>
<p class="mvweb-t-page-hero__meta" aria-live="polite"><span data-fav-total hidden></span></p>
