<?php
/**
 * Favourites part: the button that copies the link to the list.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! isset( $args['place'] ) || 'tools' !== $args['place'] ) {
	return;
}
?>
<button class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-btn--sm" type="button" data-fav-share>
	<?php echo mvweb_theme_icon( 'share', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<span data-fav-share-label><?php esc_html_e( 'Share the list', 'brand-market' ); ?></span>
</button>
