<?php
/**
 * Favourites part: the note that a guest's list lives in the browser.
 *
 * Printed hidden: the script shows it to a guest who has something in the list.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! isset( $args['place'] ) || 'body' !== $args['place'] ) {
	return;
}

$mvweb_login = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : '';

if ( '' === $mvweb_login ) {
	$mvweb_login = wp_login_url( (string) get_permalink() );
}
?>
<div class="mvweb-t-alert mvweb-t-alert--info" data-fav-guest hidden>
	<?php echo mvweb_theme_icon( 'info-circle', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<p>
		<?php
		/* translators: %s: link with the text "Sign in now". */
		$mvweb_note = __( 'The list is kept in this browser. %s to see it on all your devices.', 'brand-market' );

		echo wp_kses_post( sprintf( esc_html( $mvweb_note ), '<a href="' . esc_url( $mvweb_login ) . '">' . esc_html__( 'Sign in now', 'brand-market' ) . '</a>' ) );
		?>
	</p>
</div>
