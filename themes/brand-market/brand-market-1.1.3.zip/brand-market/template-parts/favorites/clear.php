<?php
/**
 * Favourites part: the button that empties the list.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! isset( $args['place'] ) || 'tools' !== $args['place'] ) {
	return;
}
?>
<button class="mvweb-t-btn mvweb-t-btn--ghost mvweb-t-fav-tools__clear" type="button" data-fav-clear><?php esc_html_e( 'Clear the list', 'brand-market' ); ?></button>
