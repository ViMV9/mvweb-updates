<?php
/**
 * Favourites part: the switch between the cards and the table.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! isset( $args['place'] ) || 'tools' !== $args['place'] || ! mvweb_core_catalog_view_switch() ) {
	return;
}

$mvweb_view = mvweb_core_catalog_view();
?>
<div class="mvweb-t-view" role="group" aria-label="<?php esc_attr_e( 'Look of the catalogue', 'brand-market' ); ?>" data-view-switch data-cookie="<?php echo esc_attr( MVWEB_CORE_CATALOG_VIEW_COOKIE ); ?>">
	<button class="mvweb-t-view__btn" type="button" data-view="card" aria-pressed="<?php echo 'card' === $mvweb_view ? 'true' : 'false'; ?>" title="<?php esc_attr_e( 'Cards', 'brand-market' ); ?>">
		<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><rect x="2" y="2" width="7" height="7" rx="1.5"/><rect x="11" y="2" width="7" height="7" rx="1.5"/><rect x="2" y="11" width="7" height="7" rx="1.5"/><rect x="11" y="11" width="7" height="7" rx="1.5"/></svg>
		<span class="screen-reader-text"><?php esc_html_e( 'Cards', 'brand-market' ); ?></span>
	</button>
	<button class="mvweb-t-view__btn" type="button" data-view="table" aria-pressed="<?php echo 'table' === $mvweb_view ? 'true' : 'false'; ?>" title="<?php esc_attr_e( 'Table', 'brand-market' ); ?>">
		<svg viewBox="0 0 20 20" aria-hidden="true" focusable="false"><rect x="2" y="3" width="16" height="3.5" rx="1.2"/><rect x="2" y="8.25" width="16" height="3.5" rx="1.2"/><rect x="2" y="13.5" width="16" height="3.5" rx="1.2"/></svg>
		<span class="screen-reader-text"><?php esc_html_e( 'Table', 'brand-market' ); ?></span>
	</button>
</div>
