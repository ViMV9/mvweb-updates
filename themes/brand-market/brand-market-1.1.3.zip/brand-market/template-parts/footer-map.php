<?php
/**
 * The map above the footer columns.
 *
 * Off unless the owner turns it on: the map of the company belongs on the
 * contacts page, and a frame of a third-party map on every page is the
 * heaviest thing in the footer. The map itself, its code or a still picture,
 * lives in the site profile.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! mvweb_cz_get( 'mvweb_footer_map_enable' ) ) {
	return;
}

$mvweb_map = mvweb_core_profile_map();

if ( '' === $mvweb_map['image'] && '' === $mvweb_map['src'] ) {
	return;
}

$mvweb_map_title = trim( (string) mvweb_cz_get( 'mvweb_footer_map_title', '' ) );
?>
<div class="mvweb-t-container mvweb-t-footer__map">
	<?php if ( '' !== $mvweb_map_title ) : ?>
		<div class="mvweb-t-h3 mvweb-t-footer__map-title"><?php echo esc_html( $mvweb_map_title ); ?></div>
	<?php endif; ?>

	<?php
	get_template_part(
		'template-parts/map-frame',
		null,
		array(
			'map'   => $mvweb_map,
			'name'  => $mvweb_map_title,
			'sizes' => '(max-width: 60rem) calc(100vw - 2rem), 1216px',
		)
	);
	?>
</div>
