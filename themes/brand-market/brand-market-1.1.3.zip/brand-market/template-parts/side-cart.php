<?php
/**
 * The side cart: a panel over the page with the goods of the cart.
 *
 * The panel is the piece WooCommerce replaces after every change of the
 * cart, so it holds no state of its own; the open or closed state sits on the
 * dialog around it. With the fragment argument only the panel is printed.
 *
 * Arguments: fragment (bool, the panel alone).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
	return;
}

$mvweb_fragment = ! empty( $args['fragment'] );
$mvweb_count    = mvweb_core_cart_positions();
$mvweb_words    = mvweb_core_cart_count_label( $mvweb_count );
?>
<?php if ( ! $mvweb_fragment ) : ?>
<dialog class="mvweb-t-minicart" data-minicart aria-label="<?php esc_attr_e( 'Cart', 'brand-market' ); ?>">
	<div class="screen-reader-text" role="status" aria-live="polite" data-minicart-live></div>
<?php endif; ?>
	<div class="mvweb-t-minicart__panel" data-minicart-panel data-announce="<?php echo esc_attr( mvweb_core_cart_announce() ); ?>">
		<div class="mvweb-t-minicart__head">
			<p class="mvweb-t-minicart__title"><?php esc_html_e( 'Cart', 'brand-market' ); ?><?php echo $mvweb_count > 0 ? ' <span>' . esc_html( $mvweb_words ) . '</span>' : ''; ?></p>
			<button class="mvweb-t-round" type="button" data-minicart-close title="<?php esc_attr_e( 'Close', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Close', 'brand-market' ); ?></span>
			</button>
		</div>
		<?php
		if ( $mvweb_count > 0 ) {
			mvweb_core_render_layout( 'side-cart' );
		}

		woocommerce_mini_cart();
		?>
	</div>
<?php if ( ! $mvweb_fragment ) : ?>
</dialog>
<?php endif; ?>
