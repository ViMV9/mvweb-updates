<?php
/**
 * Search results: the group "services".
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_group = isset( $args['groups']['services'] ) ? $args['groups']['services'] : array();
$mvweb_only  = isset( $args['only'] ) ? (string) $args['only'] : '';

if ( empty( $mvweb_group ) || ( '' !== $mvweb_only && 'services' !== $mvweb_only ) ) {
	return;
}

get_template_part(
	'template-parts/search/group',
	null,
	array(
		'slug'  => 'services',
		'group' => $mvweb_group,
		'full'  => 'services' === $mvweb_only,
	)
);
