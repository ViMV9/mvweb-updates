<?php
/**
 * Search results: the group "posts".
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_group = isset( $args['groups']['posts'] ) ? $args['groups']['posts'] : array();
$mvweb_only  = isset( $args['only'] ) ? (string) $args['only'] : '';

if ( empty( $mvweb_group ) || ( '' !== $mvweb_only && 'posts' !== $mvweb_only ) ) {
	return;
}

get_template_part(
	'template-parts/search/group',
	null,
	array(
		'slug'  => 'posts',
		'group' => $mvweb_group,
		'full'  => 'posts' === $mvweb_only,
	)
);
