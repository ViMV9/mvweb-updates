<?php
/**
 * Search results: the group "works".
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_group = isset( $args['groups']['works'] ) ? $args['groups']['works'] : array();
$mvweb_only  = isset( $args['only'] ) ? (string) $args['only'] : '';

if ( empty( $mvweb_group ) || ( '' !== $mvweb_only && 'works' !== $mvweb_only ) ) {
	return;
}

get_template_part(
	'template-parts/search/group',
	null,
	array(
		'slug'  => 'works',
		'group' => $mvweb_group,
		'full'  => 'works' === $mvweb_only,
	)
);
