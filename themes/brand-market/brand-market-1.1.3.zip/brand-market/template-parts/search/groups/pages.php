<?php
/**
 * Search results: the group "pages".
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_group = isset( $args['groups']['pages'] ) ? $args['groups']['pages'] : array();
$mvweb_only  = isset( $args['only'] ) ? (string) $args['only'] : '';

if ( empty( $mvweb_group ) || ( '' !== $mvweb_only && 'pages' !== $mvweb_only ) ) {
	return;
}

get_template_part(
	'template-parts/search/group',
	null,
	array(
		'slug'  => 'pages',
		'group' => $mvweb_group,
		'full'  => 'pages' === $mvweb_only,
	)
);
