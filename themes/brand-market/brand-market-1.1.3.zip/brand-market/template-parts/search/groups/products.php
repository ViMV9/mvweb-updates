<?php
/**
 * Search results: the group "products".
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_group = isset( $args['groups']['products'] ) ? $args['groups']['products'] : array();
$mvweb_only  = isset( $args['only'] ) ? (string) $args['only'] : '';

if ( empty( $mvweb_group ) || ( '' !== $mvweb_only && 'products' !== $mvweb_only ) ) {
	return;
}

get_template_part(
	'template-parts/search/group',
	null,
	array(
		'slug'  => 'products',
		'group' => $mvweb_group,
		'full'  => 'products' === $mvweb_only,
	)
);
