<?php
/**
 * Popular searches: chips that run the query.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_popular = array_filter( array_map( 'trim', preg_split( '/\R/', (string) get_theme_mod( 'mvweb_search_popular', '' ) ) ) );

if ( empty( $mvweb_popular ) ) {
	return;
}
?>
<nav class="mvweb-t-chips mvweb-t-search-pop" aria-label="<?php esc_attr_e( 'Popular searches', 'brand-market' ); ?>">
	<?php foreach ( $mvweb_popular as $mvweb_query ) : ?>
		<a class="mvweb-t-chip" href="<?php echo esc_url( add_query_arg( 's', rawurlencode( $mvweb_query ), home_url( '/' ) ) ); ?>"><?php echo esc_html( $mvweb_query ); ?></a>
	<?php endforeach; ?>
</nav>
