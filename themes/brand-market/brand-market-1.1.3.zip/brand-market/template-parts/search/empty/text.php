<?php
/**
 * Search that found nothing: the mark, the heading and the advice.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<span class="mvweb-t-empty__icon"><?php echo mvweb_theme_icon( 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
<div class="mvweb-t-empty__title mvweb-t-h2" role="heading" aria-level="2"><?php esc_html_e( 'Nothing found', 'brand-market' ); ?></div>
<p class="mvweb-t-empty__text"><?php esc_html_e( 'Check the spelling, try a shorter word or the name of a brand.', 'brand-market' ); ?></p>
