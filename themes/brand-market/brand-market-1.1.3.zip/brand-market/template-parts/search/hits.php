<?php
/**
 * Search that found nothing: the entries people take most.
 *
 * Printed only when the owner names the block.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_title = trim( (string) get_theme_mod( 'mvweb_search_hits_title', '' ) );

if ( '' === $mvweb_title ) {
	return;
}

$mvweb_ids = mvweb_core_showcase_items( 'featured', absint( get_theme_mod( 'mvweb_search_hits_count', 5 ) ) );

if ( empty( $mvweb_ids ) ) {
	return;
}
?>
<section class="mvweb-t-search-group">
	<div class="mvweb-t-search-group__head">
		<div class="mvweb-t-search-group__title mvweb-t-h2" role="heading" aria-level="2"><?php echo esc_html( $mvweb_title ); ?></div>
	</div>

	<div class="mvweb-t-catalog__grid mvweb-t-catalog__grid--wide mvweb-t-search-group__grid mvweb-t-search-group__grid--products">
		<?php foreach ( $mvweb_ids as $mvweb_id ) : ?>
			<?php
			get_template_part(
				'template-parts/catalog/card',
				null,
				array(
					'id' => $mvweb_id,
				)
			);
			?>
		<?php endforeach; ?>
	</div>
</section>
