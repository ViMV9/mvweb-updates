<?php
/**
 * Page not found: the line under the heading.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_text = trim( (string) get_theme_mod( 'mvweb_404_text', '' ) );

if ( '' === $mvweb_text ) {
	return;
}
?>
<p class="mvweb-t-notfound__text"><?php echo esc_html( $mvweb_text ); ?></p>
