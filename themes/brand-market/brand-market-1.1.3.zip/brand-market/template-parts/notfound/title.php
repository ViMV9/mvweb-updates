<?php
/**
 * Page not found: the code and the single h1.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_title = trim( (string) get_theme_mod( 'mvweb_404_title', '' ) );

if ( '' === $mvweb_title ) {
	$mvweb_title = __( 'Page not found', 'brand-market' );
}
?>
<p class="mvweb-t-notfound__code" aria-hidden="true">404</p>
<h1 class="mvweb-t-notfound__title"><?php echo esc_html( $mvweb_title ); ?></h1>
