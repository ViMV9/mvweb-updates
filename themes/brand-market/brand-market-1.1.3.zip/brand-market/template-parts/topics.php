<?php
/**
 * Topics of the day: the menu of its place as a row of chips under the header.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! has_nav_menu( 'topics' ) ) {
	return;
}
?>
<nav class="mvweb-t-topics" aria-label="<?php esc_attr_e( 'Topics of the day', 'brand-market' ); ?>">
	<div class="mvweb-t-container">
		<?php
		mvweb_core_nav(
			'topics',
			array(
				'menu_class'   => 'mvweb-t-topics__list',
				'link_class'   => 'mvweb-t-chip',
				'item_spacing' => 'discard',
			)
		);
		?>
	</div>
</nav>
