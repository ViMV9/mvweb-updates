<?php
/**
 * Heading of an author archive, part: the links of the author.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part( 'template-parts/author-box/socials', null, array( 'author' => isset( $args['author'] ) ? absint( $args['author'] ) : 0 ) );
