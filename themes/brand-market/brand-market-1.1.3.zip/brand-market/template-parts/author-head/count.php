<?php
/**
 * Heading of an author archive, part: the number of posts.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_count = (int) count_user_posts( isset( $args['author'] ) ? absint( $args['author'] ) : 0, 'post', true );

if ( $mvweb_count < 1 ) {
	return;
}
?>
<span>
	<?php
	/* translators: %s: number of posts. */
	echo esc_html( sprintf( _n( '%s article', '%s articles', $mvweb_count, 'brand-market' ), number_format_i18n( $mvweb_count ) ) );
	?>
</span>
