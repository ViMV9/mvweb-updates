<?php
/**
 * Heading of an author archive, part: the picture.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

echo get_avatar( isset( $args['author'] ) ? absint( $args['author'] ) : 0, 240, '', '', array( 'class' => 'mvweb-t-avatar mvweb-t-avatar--xl' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
