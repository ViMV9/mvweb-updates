<?php
/**
 * The feed of the latest posts grouped by days, in five looks.
 *
 * Arguments: look (wire, line, duo, thumbs, rail), query (WP_Query of the feed), aside (WP_Query of the main stories for duo
 * and rail, may be null), rv (the parts appear with the block), list (the feed with pictures takes the posts of the next page). Inside a day every row shows the time only, the date stands
 * in the caption of the day: a cached page never claims «today» after midnight.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_query = isset( $args['query'] ) && $args['query'] instanceof WP_Query ? $args['query'] : null;
$mvweb_aside = isset( $args['aside'] ) && $args['aside'] instanceof WP_Query ? $args['aside'] : null;
$mvweb_look  = isset( $args['look'] ) ? (string) $args['look'] : 'wire';
$mvweb_rv    = ! empty( $args['rv'] ) ? ' data-rv' : '';

if ( null === $mvweb_query || empty( $mvweb_query->posts ) ) {
	return;
}

$mvweb_groups = mvweb_core_day_groups( $mvweb_query->posts );
$mvweb_flag   = static function () {
	$flag = mvweb_core_post_flag();

	if ( '' !== $flag['kind'] ) {
		printf( '<span class="mvweb-t-feed-flag mvweb-t-feed-flag--%1$s">%2$s</span>', esc_attr( $flag['kind'] ), esc_html( $flag['label'] ) );
	}

	return $flag['kind'];
};
$mvweb_kind   = static function ( $base ) {
	$flag = mvweb_core_post_flag();

	return '' !== $flag['kind'] ? ' ' . $base . '--' . $flag['kind'] : '';
};
$mvweb_time   = static function ( $css ) {
	printf( '<time class="%1$s" datetime="%2$s">%3$s</time>', esc_attr( $css ), esc_attr( get_the_date( 'c' ) ), esc_html( get_the_time( 'H:i' ) ) );
};
$mvweb_topic  = static function ( $css = 'mvweb-t-feed-topic' ) {
	get_template_part( 'template-parts/journal/topic', null, array( 'class' => $css ) );
};
$mvweb_title  = static function ( $css ) {
	printf( '<div class="%1$s"><a href="%2$s">%3$s</a></div>', esc_attr( $css ), esc_url( get_permalink() ), esc_html( get_the_title() ) );
};
$mvweb_lead   = static function ( $css ) {
	$text = trim( wp_strip_all_tags( get_the_excerpt() ) );

	if ( '' !== $text ) {
		printf( '<p class="%1$s">%2$s</p>', esc_attr( $css ), esc_html( $text ) );
	}
};
$mvweb_thumb  = static function ( $css, $size = 'medium' ) {
	if ( has_post_thumbnail() ) {
		printf( '<a class="mvweb-t-jr-media %1$s" href="%2$s" tabindex="-1" aria-hidden="true">%3$s</a>', esc_attr( $css ), esc_url( get_permalink() ), get_the_post_thumbnail( null, $size ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds the image tag.
	}
};
$mvweb_day    = static function ( $group, $css, $sep = '' ) {
	if ( '' === $sep ) {
		printf( '<div class="%1$s">%2$s<span>%3$s</span></div>', esc_attr( $css ), esc_html( $group['day'] ), esc_html( $group['week'] ) );
	} else {
		printf( '<div class="%1$s">%2$s</div>', esc_attr( $css ), esc_html( $group['day'] . $sep . $group['week'] ) );
	}
};
$mvweb_each   = static function ( $posts, $row ) {
	foreach ( $posts as $item ) {
		$GLOBALS['post'] = $item; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- The loop of a grouped feed sets the post for the template tags; wp_reset_postdata() restores it.
		setup_postdata( $item );
		$row();
	}
};

if ( 'wire' === $mvweb_look ) :
	?>
	<div class="mvweb-t-feed-wire"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
		<?php foreach ( $mvweb_groups as $mvweb_group ) : ?>
			<div class="mvweb-t-feed-wire__group">
				<?php $mvweb_day( $mvweb_group, 'mvweb-t-feed-wire__day' ); ?>
				<ol class="mvweb-t-feed-wire__items">
					<?php
					$mvweb_each(
						$mvweb_group['posts'],
						static function () use ( $mvweb_kind, $mvweb_time, $mvweb_topic, $mvweb_title, $mvweb_flag ) {
							echo '<li class="mvweb-t-feed-wire__item' . esc_attr( $mvweb_kind( 'mvweb-t-feed-wire__item' ) ) . '">';
							$mvweb_time( 'mvweb-t-feed-wire__time' );
							$mvweb_topic( 'mvweb-t-feed-wire__topic' );
							$mvweb_title( 'mvweb-t-feed-wire__title' );
							$mvweb_flag();
							echo '</li>';
						}
					);
					?>
				</ol>
			</div>
		<?php endforeach; ?>
	</div>
	<?php
elseif ( 'line' === $mvweb_look ) :
	?>
	<div class="mvweb-t-feed-line"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
		<?php foreach ( $mvweb_groups as $mvweb_group ) : ?>
			<div class="mvweb-t-feed-line__group">
				<div class="mvweb-t-feed-line__day"><div class="mvweb-t-feed-line__mark"><?php $mvweb_day( $mvweb_group, 'mvweb-t-feed-line__pill', ' · ' ); ?></div></div>
				<ol class="mvweb-t-feed-line__items">
					<?php
					$mvweb_each(
						$mvweb_group['posts'],
						static function () use ( $mvweb_kind, $mvweb_time, $mvweb_topic, $mvweb_title, $mvweb_flag, $mvweb_lead, $mvweb_thumb ) {
							echo '<li class="mvweb-t-feed-line__item' . esc_attr( $mvweb_kind( 'mvweb-t-feed-line__item' ) ) . '">';
							$mvweb_time( 'mvweb-t-feed-line__time' );
							echo '<div class="mvweb-t-feed-line__body"><div class="mvweb-t-feed-line__text"><div class="mvweb-t-feed-meta">';
							$mvweb_topic();
							$mvweb_flag();
							echo '</div>';
							$mvweb_title( 'mvweb-t-feed-line__title' );
							$mvweb_lead( 'mvweb-t-feed-line__lead' );
							echo '</div>';
							$mvweb_thumb( 'mvweb-t-feed-line__thumb' );
							echo '</div></li>';
						}
					);
					?>
				</ol>
			</div>
		<?php endforeach; ?>
	</div>
	<?php
elseif ( 'duo' === $mvweb_look ) :
	?>
	<div class="mvweb-t-feed-duo<?php echo null === $mvweb_aside ? ' mvweb-t-feed-duo--single' : ''; ?>">
		<?php if ( null !== $mvweb_aside ) : ?>
			<aside class="mvweb-t-feed-duo__top" aria-label="<?php esc_attr_e( 'Main stories', 'brand-market' ); ?>"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
				<div class="mvweb-t-feed-duo__top-title mvweb-t-h3"><?php esc_html_e( 'Main stories', 'brand-market' ); ?></div>
				<?php
				$mvweb_number = 1;

				while ( $mvweb_aside->have_posts() ) :
					$mvweb_aside->the_post();

					if ( 1 === $mvweb_number ) {
						$mvweb_thumb( 'mvweb-t-feed-duo__top-media', 'large' );
						echo '<ol class="mvweb-t-feed-duo__top-list">';
					}
					?>
					<li class="mvweb-t-feed-duo__top-item"><span class="mvweb-t-feed-duo__top-num" aria-hidden="true"><?php echo esc_html( (string) $mvweb_number ); ?></span><div class="mvweb-t-feed-duo__top-name"><a class="mvweb-t-jr-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div></li>
					<?php
					++$mvweb_number;
				endwhile;

				echo $mvweb_number > 1 ? '</ol>' : '';
				wp_reset_postdata();
				?>
			</aside>
		<?php endif; ?>
		<div class="mvweb-t-feed-duo__feed"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
			<?php foreach ( $mvweb_groups as $mvweb_group ) : ?>
				<div class="mvweb-t-feed-duo__group">
					<?php $mvweb_day( $mvweb_group, 'mvweb-t-feed-duo__day' ); ?>
					<ol class="mvweb-t-feed-duo__items">
						<?php
						$mvweb_each(
							$mvweb_group['posts'],
							static function () use ( $mvweb_kind, $mvweb_time, $mvweb_topic, $mvweb_title, $mvweb_flag, $mvweb_thumb ) {
								echo '<li class="mvweb-t-feed-duo__item' . esc_attr( $mvweb_kind( 'mvweb-t-feed-duo__item' ) ) . '">';
								$mvweb_time( 'mvweb-t-feed-duo__time' );
								echo '<div class="mvweb-t-feed-duo__text"><div class="mvweb-t-feed-meta">';
								$mvweb_topic();
								$mvweb_flag();
								echo '</div>';
								$mvweb_title( 'mvweb-t-feed-duo__title' );
								echo '</div>';
								$mvweb_thumb( 'mvweb-t-feed-duo__thumb' );
								echo '</li>';
							}
						);
						?>
					</ol>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
	<?php
elseif ( 'thumbs' === $mvweb_look ) :
	?>
	<div class="mvweb-t-feed-thumbs"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?><?php echo ! empty( $args['list'] ) ? ' data-list' : ''; ?>>
		<?php foreach ( $mvweb_groups as $mvweb_group ) : ?>
			<div class="mvweb-t-feed-thumbs__group" data-day="<?php echo esc_attr( wp_date( 'Y-m-d', $mvweb_group['stamp'] ) ); ?>">
				<div class="mvweb-t-feed-thumbs__day"><b><?php echo esc_html( $mvweb_group['day'] ); ?></b><span><?php echo esc_html( $mvweb_group['week'] ); ?></span></div>
				<ol class="mvweb-t-feed-thumbs__items">
					<?php
					$mvweb_each(
						$mvweb_group['posts'],
						static function () use ( $mvweb_kind, $mvweb_time, $mvweb_topic, $mvweb_title, $mvweb_flag, $mvweb_lead, $mvweb_thumb ) {
							echo '<li class="mvweb-t-feed-thumbs__item' . ( has_post_thumbnail() ? '' : ' mvweb-t-feed-thumbs__item--bare' ) . esc_attr( $mvweb_kind( 'mvweb-t-feed-thumbs__item' ) ) . '" data-id="' . (int) get_the_ID() . '"><div class="mvweb-t-feed-thumbs__text"><div class="mvweb-t-feed-meta">';
							$mvweb_time( 'mvweb-t-feed-time' );
							$mvweb_topic();
							$mvweb_flag();
							echo '</div>';
							$mvweb_title( 'mvweb-t-feed-thumbs__title' );
							$mvweb_lead( 'mvweb-t-feed-thumbs__lead' );
							echo '</div>';
							$mvweb_thumb( 'mvweb-t-feed-thumbs__media' );
							echo '</li>';
						}
					);
					?>
				</ol>
			</div>
		<?php endforeach; ?>
	</div>
	<?php
else :
	$mvweb_main = null !== $mvweb_aside && $mvweb_aside->have_posts() ? $mvweb_aside : null;
	?>
	<div class="mvweb-t-feed-rail<?php echo null === $mvweb_main ? ' mvweb-t-feed-rail--single' : ''; ?>">
		<?php
		if ( null !== $mvweb_main ) :
			$mvweb_main->the_post();
			?>
			<article class="mvweb-t-feed-rail__main"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
				<?php $mvweb_thumb( 'mvweb-t-feed-rail__media', 'full' ); ?>
				<?php $mvweb_topic(); ?>
				<div class="mvweb-t-feed-rail__main-title mvweb-t-h2" role="heading" aria-level="2"><a class="mvweb-t-jr-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
				<?php $mvweb_lead( 'mvweb-t-feed-rail__lead' ); ?>
				<?php get_template_part( 'template-parts/journal/byline' ); ?>
			</article>
			<?php
			wp_reset_postdata();
		endif;
		?>
		<div class="mvweb-t-feed-rail__col">
			<div class="mvweb-t-feed-rail__box">
				<div class="mvweb-t-feed-rail__scroll" tabindex="0" role="region" aria-label="<?php esc_attr_e( 'Latest posts, the list scrolls', 'brand-market' ); ?>">
					<?php
					$mvweb_shown = 0;

					foreach ( $mvweb_groups as $mvweb_group ) :
						?>
						<div class="mvweb-t-feed-rail__group<?php echo $mvweb_shown >= 7 ? ' mvweb-t-feed-rail__group--extra' : ''; ?>">
							<?php $mvweb_day( $mvweb_group, 'mvweb-t-feed-rail__day', ', ' ); ?>
							<ol class="mvweb-t-feed-rail__items">
								<?php
								$mvweb_each(
									$mvweb_group['posts'],
									static function () use ( $mvweb_kind, $mvweb_time, $mvweb_title, $mvweb_flag, &$mvweb_shown ) {
										echo '<li class="mvweb-t-feed-rail__item' . esc_attr( $mvweb_kind( 'mvweb-t-feed-rail__item' ) ) . ( $mvweb_shown >= 7 ? ' mvweb-t-feed-rail__item--extra' : '' ) . '"><div class="mvweb-t-feed-rail__meta">';
										$mvweb_time( 'mvweb-t-feed-time' );
										$mvweb_flag();
										echo '</div>';
										$mvweb_title( 'mvweb-t-feed-rail__title' );
										echo '</li>';
										++$mvweb_shown;
									}
								);
								?>
							</ol>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
		</div>
	</div>
	<?php
endif;

wp_reset_postdata();
