<?php
/**
 * Service main part: the photos.
 *
 * A service with no photo of its own leaves the gallery out rather than
 * showing a placeholder: a measurement or a consultation has nothing to show,
 * and the text starts right under the heading.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = absint( $args['id'] );

if ( empty( mvweb_core_item_gallery( $mvweb_id ) ) ) {
	return;
}
?>
<div class="mvweb-t-service__media">
	<?php
	get_template_part(
		'template-parts/product-gallery',
		null,
		array(
			'id'      => $mvweb_id,
			'actions' => false,
			'wide'    => true,
		)
	);
	?>
</div>
