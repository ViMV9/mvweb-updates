<?php
/**
 * A list of posts with its numbered pages, in the look of the homepage feed or of the list of the blog.
 *
 * Looks: grid (the cards of the blog; hide leaves parts out), feed and days
 * (the feed by days), cards (large cards in one column), inserts (a grid with
 * the most discussed posts in between), side (a feed and a column of widgets),
 * top (text cards under the blocks of the homepage), wall, columns, photos,
 * rhythm (masonry). The list carries data-list: the script of the stream adds
 * the posts of the next page to it.
 *
 * Arguments: view, query (WP_Query), pager (arguments of the numbered pages),
 * hide (parts of the cards to leave out).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_query = isset( $args['query'] ) && $args['query'] instanceof WP_Query ? $args['query'] : $GLOBALS['wp_query'];
$mvweb_view  = isset( $args['view'] ) ? (string) $args['view'] : 'grid';
$mvweb_hide  = isset( $args['hide'] ) && is_array( $args['hide'] ) ? $args['hide'] : array();
$mvweb_pager = isset( $args['pager'] ) && is_array( $args['pager'] ) ? $args['pager'] : array();

if ( ! $mvweb_query->have_posts() ) {
	mvweb_theme_pagination( $mvweb_pager );

	return;
}

$mvweb_page = max( 1, isset( $mvweb_pager['current'] ) ? (int) $mvweb_pager['current'] : (int) get_query_var( 'paged' ) );

$mvweb_card = static function ( $modifier = '', $hide = array() ) {
	get_template_part(
		'template-parts/post-card',
		null,
		array(
			'modifier' => $modifier,
			'hide'     => $hide,
		)
	);
};

$mvweb_top_title = 'read' === mvweb_core_top_by() ? __( 'Most read', 'brand-market' ) : __( 'Most discussed', 'brand-market' );

$mvweb_popular = static function ( $count, $offset ) {
	$posts = mvweb_core_top_posts( $count, $offset );

	if ( empty( $posts ) ) {
		return;
	}

	echo '<ol class="mvweb-t-stream-top">';

	foreach ( $posts as $post ) {
		printf( '<li><a href="%1$s">%2$s</a></li>', esc_url( get_permalink( $post ) ), esc_html( get_the_title( $post ) ) );
	}

	echo '</ol>';
};

$mvweb_lead = static function ( $css ) {
	$text = trim( wp_strip_all_tags( get_the_excerpt() ) );

	if ( '' !== $text ) {
		printf( '<p class="%1$s">%2$s</p>', esc_attr( $css ), esc_html( $text ) );
	}
};

$mvweb_media = static function ( $css, $size = 'large' ) {
	if ( has_post_thumbnail() ) {
		printf( '<a class="mvweb-t-jr-media %1$s" href="%2$s" tabindex="-1" aria-hidden="true">%3$s</a>', esc_attr( $css ), esc_url( get_permalink() ), get_the_post_thumbnail( null, $size ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds the image tag.
	}
};

$mvweb_list  = array(
	'grid'    => 'mvweb-t-posts__grid mvweb-t-posts__grid--listing' . ( in_array( 'lead', $mvweb_hide, true ) ? ' mvweb-t-posts__grid--journal' : '' ),
	'inserts' => 'mvweb-t-posts__grid mvweb-t-posts__grid--listing',
	'cards'   => 'mvweb-t-stream__list mvweb-t-stream__list--cards',
	'side'    => 'mvweb-t-stream__list mvweb-t-stream__list--side',
	'top'     => 'mvweb-t-stream__list mvweb-t-stream__list--notes',
	'wall'    => 'mvweb-t-wall mvweb-t-wall--wall',
	'columns' => 'mvweb-t-wall mvweb-t-wall--columns',
	'photos'  => 'mvweb-t-wall mvweb-t-wall--photos',
	'rhythm'  => 'mvweb-t-wall mvweb-t-wall--rhythm',
);
$mvweb_feed  = in_array( $mvweb_view, array( 'feed', 'days' ), true );
$mvweb_attrs = mvweb_core_stream_attrs( $mvweb_view );
?>
<div class="mvweb-t-stream mvweb-t-stream--<?php echo esc_attr( $mvweb_view ); ?>"<?php echo $mvweb_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>>
	<?php if ( 'side' === $mvweb_view ) : ?>
		<div class="mvweb-t-stream__main">
	<?php endif; ?>

	<?php
	if ( $mvweb_feed ) {
		get_template_part(
			'template-parts/posts-feed',
			null,
			array(
				'look'  => 'thumbs',
				'query' => $mvweb_query,
				'list'  => true,
			)
		);
	} else {
		$mvweb_class = isset( $mvweb_list[ $mvweb_view ] ) ? $mvweb_list[ $mvweb_view ] : $mvweb_list['grid'];
		$mvweb_index = 0;
		$mvweb_half  = $mvweb_query->post_count > 6 ? 6 : (int) ceil( $mvweb_query->post_count / 2 );

		printf( '<div class="%1$s" data-list%2$s>', esc_attr( $mvweb_class ), 'wall' === $mvweb_view ? ' data-wall' : '' );

		while ( $mvweb_query->have_posts() ) {
			$mvweb_query->the_post();
			++$mvweb_index;

			if ( 'cards' === $mvweb_view ) {
				?>
				<article class="mvweb-t-stream-big" data-id="<?php the_ID(); ?>">
					<?php get_template_part( 'template-parts/journal/byline' ); ?>
					<div class="mvweb-t-stream-big__title mvweb-t-h2" role="heading" aria-level="2"><a class="mvweb-t-jr-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
					<?php $mvweb_lead( 'mvweb-t-stream-big__lead' ); ?>
					<?php $mvweb_media( 'mvweb-t-stream-big__media' ); ?>
				</article>
				<?php
			} elseif ( 'side' === $mvweb_view ) {
				?>
				<article class="mvweb-t-stream-row" data-id="<?php the_ID(); ?>">
					<?php $mvweb_media( 'mvweb-t-stream-row__media' ); ?>
					<div class="mvweb-t-stream-row__text">
						<?php get_template_part( 'template-parts/journal/topic' ); ?>
						<div class="mvweb-t-stream-row__title"><a class="mvweb-t-jr-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
						<?php $mvweb_lead( 'mvweb-t-stream-row__lead' ); ?>
						<?php get_template_part( 'template-parts/journal/byline' ); ?>
					</div>
				</article>
				<?php
			} elseif ( 'top' === $mvweb_view ) {
				?>
				<article class="mvweb-t-stream-note" data-id="<?php the_ID(); ?>">
					<div class="mvweb-t-jr-meta">
						<?php get_template_part( 'template-parts/journal/topic' ); ?>
						<time datetime="<?php echo esc_attr( get_the_date( 'c' ) ); ?>"><?php echo esc_html( mvweb_core_short_date() ); ?></time>
					</div>
					<div class="mvweb-t-stream-note__title"><a class="mvweb-t-jr-link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
					<?php $mvweb_lead( 'mvweb-t-stream-note__lead' ); ?>
				</article>
				<?php
			} elseif ( 'photos' === $mvweb_view ) {
				$mvweb_src   = has_post_thumbnail() ? wp_get_attachment_image_src( (int) get_post_thumbnail_id(), 'large' ) : false;
				$mvweb_ratio = is_array( $mvweb_src ) && $mvweb_src[2] > 0 ? round( $mvweb_src[1] / $mvweb_src[2], 3 ) : 1.333;
				?>
				<article class="mvweb-t-stream-photo" data-id="<?php the_ID(); ?>" style="--mvweb-t-ratio:<?php echo esc_attr( (string) $mvweb_ratio ); ?>">
					<a class="mvweb-t-stream-photo__pic" href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true"><?php the_post_thumbnail( 'large' ); ?></a>
					<div class="mvweb-t-stream-photo__cap">
						<a class="mvweb-t-stream-photo__title" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
						<span><?php echo esc_html( get_the_author() ); ?></span>
					</div>
				</article>
				<?php
			} else {
				$mvweb_card( '', 'grid' === $mvweb_view ? $mvweb_hide : array( 'more' ) );
			}

			if ( 'inserts' === $mvweb_view && $mvweb_index === $mvweb_half && $mvweb_query->post_count > 3 ) {
				?>
				<div class="mvweb-t-stream-ins" data-id="ins-<?php echo (int) $mvweb_page; ?>">
					<div class="mvweb-t-stream-ins__title mvweb-t-h3"><?php echo esc_html( $mvweb_top_title ); ?></div>
					<?php $mvweb_popular( 5, ( $mvweb_page - 1 ) * 5 ); ?>
				</div>
				<?php
			}
		}

		echo '</div>';
		wp_reset_postdata();
	}

	mvweb_theme_pagination( $mvweb_pager );
	?>

	<?php if ( 'side' === $mvweb_view ) : ?>
		</div>
		<aside class="mvweb-t-stream__aside" aria-label="<?php esc_attr_e( 'Column of the feed', 'brand-market' ); ?>">
			<?php if ( is_active_sidebar( 'home-stream' ) ) : ?>
				<?php dynamic_sidebar( 'home-stream' ); ?>
			<?php else : ?>
				<div class="mvweb-t-stream-ins">
					<div class="mvweb-t-stream-ins__title mvweb-t-h3"><?php echo esc_html( $mvweb_top_title ); ?></div>
					<?php $mvweb_popular( 5, 0 ); ?>
				</div>
			<?php endif; ?>
		</aside>
	<?php endif; ?>
</div>
