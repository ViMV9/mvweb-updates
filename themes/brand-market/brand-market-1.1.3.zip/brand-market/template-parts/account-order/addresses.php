<?php
/**
 * Order part: where the order goes and whom to call.
 *
 * Arguments: order (WC_Order).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_order = isset( $args['order'] ) ? $args['order'] : null;

if ( ! $mvweb_order instanceof WC_Order ) {
	return;
}

$mvweb_shipping = $mvweb_order->needs_shipping_address() ? $mvweb_order->get_formatted_shipping_address( '' ) : '';
$mvweb_billing  = $mvweb_order->get_formatted_billing_address( '' );
$mvweb_method   = $mvweb_order->get_shipping_method();
$mvweb_where    = '' !== $mvweb_shipping ? $mvweb_shipping : $mvweb_billing;
$mvweb_phone    = $mvweb_order->get_billing_phone();
$mvweb_email    = $mvweb_order->get_billing_email();

if ( '' === $mvweb_where && '' === $mvweb_method && '' === $mvweb_phone && '' === $mvweb_email ) {
	return;
}
?>
<section class="mvweb-t-account__block">
	<div class="mvweb-t-account__title mvweb-t-h2" role="heading" aria-level="2"><?php esc_html_e( 'Delivery and recipient', 'brand-market' ); ?></div>
	<div class="mvweb-t-addr-cards">
		<?php if ( '' !== $mvweb_where || '' !== $mvweb_method ) : ?>
			<div class="mvweb-t-addr-card">
				<div class="mvweb-t-addr-card__title mvweb-t-h3"><?php echo esc_html( '' !== $mvweb_shipping ? __( 'Delivery', 'brand-market' ) : __( 'Payment address', 'brand-market' ) ); ?></div>
				<address><?php echo wp_kses_post( implode( '<br>', array_filter( array( $mvweb_where, esc_html( $mvweb_method ) ) ) ) ); ?></address>
			</div>
		<?php endif; ?>
		<?php if ( '' !== $mvweb_phone || '' !== $mvweb_email ) : ?>
			<div class="mvweb-t-addr-card">
				<div class="mvweb-t-addr-card__title mvweb-t-h3"><?php esc_html_e( 'Contacts', 'brand-market' ); ?></div>
				<address><?php echo wp_kses_post( implode( '<br>', array_filter( array( esc_html( $mvweb_phone ), esc_html( $mvweb_email ) ) ) ) ); ?></address>
			</div>
		<?php endif; ?>
	</div>
</section>
