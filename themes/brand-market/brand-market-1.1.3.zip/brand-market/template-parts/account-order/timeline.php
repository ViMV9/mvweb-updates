<?php
/**
 * Order part: the history of the order, the current status first.
 *
 * The text under the current status is the latest note the store left for the
 * customer; older notes follow as messages of the store.
 *
 * Arguments: order (WC_Order).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_order = isset( $args['order'] ) ? $args['order'] : null;

if ( ! $mvweb_order instanceof WC_Order ) {
	return;
}

$mvweb_format = get_option( 'date_format' ) . ', ' . get_option( 'time_format' );
$mvweb_notes  = (array) $mvweb_order->get_customer_order_notes();
$mvweb_latest = array_shift( $mvweb_notes );
$mvweb_steps  = array();
$mvweb_now    = $mvweb_order->get_date_modified() ? $mvweb_order->get_date_modified() : $mvweb_order->get_date_created();

$mvweb_steps[] = array(
	'class' => 'now',
	'title' => wc_get_order_status_name( $mvweb_order->get_status() ),
	'date'  => $mvweb_now ? wc_format_datetime( $mvweb_now, $mvweb_format ) : '',
	'text'  => $mvweb_latest ? $mvweb_latest->comment_content : '',
);

foreach ( $mvweb_notes as $mvweb_note ) {
	$mvweb_steps[] = array(
		'class' => 'done',
		'title' => __( 'Message from the store', 'brand-market' ),
		'date'  => wc_format_datetime( wc_string_to_datetime( $mvweb_note->comment_date_gmt ), $mvweb_format ),
		'text'  => $mvweb_note->comment_content,
	);
}

if ( $mvweb_order->get_date_paid() ) {
	$mvweb_steps[] = array(
		'class' => 'done',
		'title' => __( 'Paid', 'brand-market' ),
		'date'  => wc_format_datetime( $mvweb_order->get_date_paid(), $mvweb_format ),
		'text'  => '',
	);
}

if ( $mvweb_order->get_date_created() ) {
	$mvweb_steps[] = array(
		'class' => 'done',
		'title' => __( 'Order placed', 'brand-market' ),
		'date'  => wc_format_datetime( $mvweb_order->get_date_created(), $mvweb_format ),
		'text'  => '',
	);
}
?>
<section class="mvweb-t-account__block">
	<div class="mvweb-t-account__title mvweb-t-h2" role="heading" aria-level="2"><?php esc_html_e( 'Order history', 'brand-market' ); ?></div>
	<ol class="mvweb-t-timeline">
		<?php foreach ( $mvweb_steps as $mvweb_step ) : ?>
			<li class="mvweb-t-timeline__item mvweb-t-timeline__item--<?php echo esc_attr( $mvweb_step['class'] ); ?>">
				<span class="mvweb-t-timeline__title"><?php echo esc_html( $mvweb_step['title'] ); ?></span>
				<?php if ( '' !== $mvweb_step['date'] ) : ?>
					<span class="mvweb-t-timeline__date"><?php echo esc_html( $mvweb_step['date'] ); ?></span>
				<?php endif; ?>
				<?php if ( '' !== trim( (string) $mvweb_step['text'] ) ) : ?>
					<span class="mvweb-t-timeline__text"><?php echo wp_kses_post( $mvweb_step['text'] ); ?></span>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ol>
</section>
