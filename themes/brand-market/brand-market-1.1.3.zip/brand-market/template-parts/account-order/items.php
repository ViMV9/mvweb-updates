<?php
/**
 * Order part: the contents of the order and its totals.
 *
 * Arguments: order (WC_Order).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_order = isset( $args['order'] ) ? $args['order'] : null;

if ( ! $mvweb_order instanceof WC_Order ) {
	return;
}

$mvweb_items  = $mvweb_order->get_items();
$mvweb_totals = $mvweb_order->get_order_item_totals();
$mvweb_total  = isset( $mvweb_totals['order_total'] ) ? $mvweb_totals['order_total'] : array();
$mvweb_tax    = 'incl' === get_option( 'woocommerce_tax_display_cart' );

unset( $mvweb_totals['order_total'], $mvweb_totals['payment_method'] );

if ( empty( $mvweb_items ) ) {
	return;
}
?>
<section class="mvweb-t-account__block">
	<div class="mvweb-t-account__title mvweb-t-h2" role="heading" aria-level="2"><?php esc_html_e( 'Order contents', 'brand-market' ); ?></div>
	<ul class="mvweb-t-oitems">
		<?php
		foreach ( $mvweb_items as $mvweb_item ) :
			if ( ! $mvweb_item instanceof WC_Order_Item_Product ) {
				continue;
			}

			$mvweb_product = $mvweb_item->get_product();
			$mvweb_link    = $mvweb_product && $mvweb_product->is_visible() ? $mvweb_product->get_permalink() : '';
			$mvweb_image   = $mvweb_product && $mvweb_product->get_image_id() ? wp_get_attachment_image(
				$mvweb_product->get_image_id(),
				'thumbnail',
				false,
				array(
					'alt'     => '',
					'loading' => 'lazy',
				)
			) : '';
			$mvweb_brand   = $mvweb_product && taxonomy_exists( 'product_brand' ) ? wp_strip_all_tags( (string) get_the_term_list( $mvweb_product->get_id(), 'product_brand', '', ', ' ) ) : '';
			$mvweb_meta    = wc_display_item_meta(
				$mvweb_item,
				array(
					'before'       => '',
					'after'        => '',
					'separator'    => ', ',
					'echo'         => false,
					'label_before' => '',
					'label_after'  => ': ',
				)
			);
			?>
			<li class="mvweb-t-oitem">
				<?php if ( '' !== $mvweb_link ) : ?>
					<a class="mvweb-t-oitem__media" href="<?php echo esc_url( $mvweb_link ); ?>" tabindex="-1" aria-hidden="true"><?php echo wp_kses_post( $mvweb_image ); ?></a>
				<?php else : ?>
					<span class="mvweb-t-oitem__media"><?php echo wp_kses_post( $mvweb_image ); ?></span>
				<?php endif; ?>
				<div class="mvweb-t-oitem__info">
					<?php if ( '' !== $mvweb_brand ) : ?>
						<span class="mvweb-t-card__brand"><?php echo esc_html( $mvweb_brand ); ?></span>
					<?php endif; ?>
					<?php if ( '' !== $mvweb_link ) : ?>
						<a class="mvweb-t-oitem__name" href="<?php echo esc_url( $mvweb_link ); ?>"><?php echo esc_html( $mvweb_item->get_name() ); ?></a>
					<?php else : ?>
						<span class="mvweb-t-oitem__name"><?php echo esc_html( $mvweb_item->get_name() ); ?></span>
					<?php endif; ?>
					<?php if ( '' !== $mvweb_meta ) : ?>
						<span class="mvweb-t-oitem__meta"><?php echo wp_kses_post( $mvweb_meta ); ?></span>
					<?php endif; ?>
				</div>
				<span class="mvweb-t-oitem__qty"><?php echo wp_kses_post( absint( $mvweb_item->get_quantity() ) . '&nbsp;×&nbsp;' . wc_price( $mvweb_order->get_item_subtotal( $mvweb_item, $mvweb_tax, true ), array( 'currency' => $mvweb_order->get_currency() ) ) ); ?></span>
				<strong class="mvweb-t-oitem__sum"><?php echo wp_kses_post( $mvweb_order->get_formatted_line_subtotal( $mvweb_item ) ); ?></strong>
			</li>
		<?php endforeach; ?>
	</ul>
	<?php if ( ! empty( $mvweb_totals ) || ! empty( $mvweb_total ) ) : ?>
		<div class="mvweb-t-ototals">
			<div class="mvweb-t-summary">
				<?php if ( ! empty( $mvweb_totals ) ) : ?>
					<dl class="mvweb-t-summary__rows">
						<?php foreach ( $mvweb_totals as $mvweb_key => $mvweb_row ) : ?>
							<div>
								<dt><?php echo esc_html( rtrim( trim( wp_strip_all_tags( $mvweb_row['label'] ) ), ':' ) ); ?></dt>
								<dd<?php echo 'discount' === $mvweb_key ? ' class="mvweb-t-summary__minus"' : ''; ?>><?php echo wp_kses_post( $mvweb_row['value'] ); ?></dd>
							</div>
						<?php endforeach; ?>
					</dl>
				<?php endif; ?>
				<?php if ( ! empty( $mvweb_total ) ) : ?>
					<p class="mvweb-t-summary__total"><span><?php echo esc_html( rtrim( trim( wp_strip_all_tags( $mvweb_total['label'] ) ), ':' ) ); ?></span><strong><?php echo wp_kses_post( $mvweb_total['value'] ); ?></strong></p>
				<?php endif; ?>
			</div>
		</div>
	<?php endif; ?>
</section>
