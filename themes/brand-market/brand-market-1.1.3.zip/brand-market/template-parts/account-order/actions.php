<?php
/**
 * Order part: the buttons under the order.
 *
 * Arguments: order (WC_Order).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_order = isset( $args['order'] ) ? $args['order'] : null;

if ( ! $mvweb_order instanceof WC_Order ) {
	return;
}

$mvweb_again = mvweb_core_shop_mode() && $mvweb_order->has_status( apply_filters( 'woocommerce_valid_order_statuses_for_order_again', array( 'completed' ) ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
?>
<div class="mvweb-t-auth__actions">
	<?php if ( $mvweb_again ) : ?>
		<a class="mvweb-t-btn" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'order_again', $mvweb_order->get_id(), wc_get_cart_url() ), 'woocommerce-order_again' ) ); ?>">
			<?php echo mvweb_theme_icon( 'refresh', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<?php esc_html_e( 'Repeat the order', 'brand-market' ); ?>
		</a>
	<?php endif; ?>
	<a class="mvweb-t-btn mvweb-t-btn--outline" href="<?php echo esc_url( wc_get_account_endpoint_url( 'orders' ) ); ?>">
		<?php echo mvweb_theme_icon( 'arrow-left', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<?php esc_html_e( 'All orders', 'brand-market' ); ?>
	</a>
</div>
