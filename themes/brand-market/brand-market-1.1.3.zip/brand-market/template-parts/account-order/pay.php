<?php
/**
 * Order reminder: the order waits for payment, with the buttons to pay and to cancel.
 *
 * Arguments: order (WC_Order).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_order = isset( $args['order'] ) ? $args['order'] : null;

if ( ! $mvweb_order instanceof WC_Order || ! $mvweb_order->needs_payment() ) {
	return;
}

$mvweb_actions = wc_get_account_orders_actions( $mvweb_order );
$mvweb_hold    = mvweb_core_account_hold_minutes();
?>
<div class="mvweb-t-alert" role="status">
	<?php echo mvweb_theme_icon( 'alert-circle', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<p>
		<?php
		esc_html_e( 'The order is waiting for payment.', 'brand-market' );

		if ( 0 < $mvweb_hold ) {
			echo ' ';
			/* translators: %s: how long the store keeps an unpaid order, for example "1 hour". */
			echo esc_html( sprintf( __( 'If it is not paid within %s, it will be cancelled automatically.', 'brand-market' ), human_time_diff( 0, $mvweb_hold * MINUTE_IN_SECONDS ) ) );
		}
		?>
	</p>
</div>
<div class="mvweb-t-auth__actions">
	<?php if ( isset( $mvweb_actions['pay']['url'] ) ) : ?>
		<a class="mvweb-t-btn" href="<?php echo esc_url( $mvweb_actions['pay']['url'] ); ?>">
			<?php
			/* translators: %s: total of the order. */
			echo wp_kses_post( sprintf( __( 'Pay %s', 'brand-market' ), $mvweb_order->get_formatted_order_total() ) );
			?>
		</a>
	<?php endif; ?>
	<?php if ( isset( $mvweb_actions['cancel']['url'] ) ) : ?>
		<a class="mvweb-t-btn mvweb-t-btn--outline" href="<?php echo esc_url( $mvweb_actions['cancel']['url'] ); ?>"><?php esc_html_e( 'Cancel the order', 'brand-market' ); ?></a>
	<?php endif; ?>
</div>
