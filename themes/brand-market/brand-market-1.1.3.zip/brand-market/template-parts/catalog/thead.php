<?php
/**
 * Catalogue listing: the header of the table look, over the columns of the cards.
 *
 * The last column says what the button of a card does: takes a quantity into
 * the cart, or sends a request. The style shows it only in the table look.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! mvweb_core_shop_mode() ) {
	$mvweb_last = __( 'Request', 'brand-market' );
} else {
	$mvweb_last = mvweb_core_layout_has( 'card-product', 'qty' ) ? __( 'Quantity', 'brand-market' ) : '';
}
?>
<div class="mvweb-t-catalog__thead" aria-hidden="true">
	<span></span>
	<span><?php esc_html_e( 'Product', 'brand-market' ); ?></span>
	<span><?php esc_html_e( 'Price', 'brand-market' ); ?></span>
	<span><?php echo esc_html( $mvweb_last ); ?></span>
	<span></span>
</div>
