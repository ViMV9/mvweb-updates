<?php
/**
 * Catalogue listing: the bar above the cards.
 *
 * The count, the sorting and the look of the list stand in the order of the
 * composition; the button that opens the filters of a narrow screen goes with
 * the sorting. The sort form is a plain GET form, so the order lives in the
 * address like the filters do and a sorted page can be shared or reloaded.
 *
 * Arguments: has_filters (bool, whether the sidebar is printed).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_args = array(
	'has_filters' => ! empty( $args['has_filters'] ),
	'state'       => new ArrayObject(
		array(
			'group'  => '',
			'toggle' => false,
			'cats'   => false,
		)
	),
);

ob_start();
mvweb_core_render_layout( 'catalog-toolbar', $mvweb_args );

if ( $mvweb_args['has_filters'] && ! $mvweb_args['state']['toggle'] ) {
	get_template_part( 'template-parts/catalog-toolbar/tools', null, $mvweb_args );
}

mvweb_core_listing_group( $mvweb_args, '' );
$mvweb_bar = trim( ob_get_clean() );

if ( '' === $mvweb_bar ) {
	return;
}
?>
<div class="mvweb-t-toolbar">
	<?php echo $mvweb_bar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the parts of the bar, every value escaped there. ?>
</div>
