<?php
/**
 * Catalogue listing: the sections inside the catalogue or the category, in the look chosen in the Customizer.
 *
 * Looks: tiles with a picture, pills with a "More" button, a scrolling ribbon,
 * columns of links, a "Sections" button that opens the columns. Every section
 * stays in the markup; the ones past the limit wait behind the button.
 *
 * Arguments of the blog: tiles (the subcategories, with icon, desc and posts),
 * view (adds cards: tiles with an icon and a description, and toc: the
 * subcategories with their articles), limit, label (the name of the button
 * and the ribbon). The blog counts articles, and its ribbon has photos.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_blog  = isset( $args['tiles'] ) && is_array( $args['tiles'] );
$mvweb_tiles = $mvweb_blog ? $args['tiles'] : mvweb_core_listing_subcats();

if ( empty( $mvweb_tiles ) ) {
	return;
}

$mvweb_view  = $mvweb_blog && isset( $args['view'] ) ? (string) $args['view'] : mvweb_core_subcats_view();
$mvweb_view  = '' === $mvweb_view ? 'tiles' : $mvweb_view;
$mvweb_limit = $mvweb_blog && isset( $args['limit'] ) ? max( 1, (int) $args['limit'] ) : mvweb_core_subcats_limit();
$mvweb_label = $mvweb_blog && isset( $args['label'] ) ? (string) $args['label'] : __( 'Sections', 'brand-market' );
$mvweb_total = count( $mvweb_tiles );
$mvweb_rest  = in_array( $mvweb_view, array( 'more', 'columns' ), true ) ? max( 0, $mvweb_total - $mvweb_limit ) : 0;
$mvweb_arrow = mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) );

$mvweb_noun = static function ( $tile ) use ( $mvweb_blog ) {
	if ( $mvweb_blog ) {
		return mvweb_core_articles( $tile['count'] );
	}

	/* translators: %s: number of items in a section. */
	return sprintf( _n( '%s item', '%s items', $tile['count'], 'brand-market' ), number_format_i18n( $tile['count'] ) );
};

$mvweb_count = static function ( $tile ) {
	return $tile['count'] > 0 ? '<span class="mvweb-t-subcats__count">' . esc_html( number_format_i18n( $tile['count'] ) ) . '</span>' : '';
};

$mvweb_extra = static function ( $index ) use ( $mvweb_rest, $mvweb_limit ) {
	return $mvweb_rest > 0 && $index >= $mvweb_limit ? ' data-extra' : '';
};

$mvweb_links = static function () use ( $mvweb_tiles, $mvweb_count, $mvweb_extra ) {
	foreach ( $mvweb_tiles as $mvweb_index => $mvweb_tile ) {
		printf(
			'<a class="mvweb-t-subcats__link" href="%1$s"%2$s><span class="mvweb-t-subcats__name">%3$s</span>%4$s</a>',
			esc_url( $mvweb_tile['url'] ),
			$mvweb_extra( $mvweb_index ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.
			esc_html( $mvweb_tile['title'] ),
			$mvweb_count( $mvweb_tile ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper.
		);
	}
};
?>
<section class="mvweb-t-section mvweb-t-section--tight mvweb-t-section--flush-top">
	<div class="mvweb-t-container">
		<?php if ( 'tiles' === $mvweb_view ) : ?>
			<div class="mvweb-t-subcats">
				<?php foreach ( $mvweb_tiles as $mvweb_tile ) : ?>
					<a class="mvweb-t-subcats__item" href="<?php echo esc_url( $mvweb_tile['url'] ); ?>">
						<span class="mvweb-t-subcats__pic">
							<?php
							if ( $mvweb_tile['image'] > 0 ) {
								echo wp_get_attachment_image(
									$mvweb_tile['image'],
									'medium',
									false,
									array(
										'alt'      => '',
										'loading'  => 'lazy',
										'decoding' => 'async',
									)
								);
							}
							?>
						</span>
						<span>
							<span class="mvweb-t-subcats__name"><?php echo esc_html( $mvweb_tile['title'] ); ?></span>
							<?php if ( $mvweb_tile['count'] > 0 ) : ?>
								<span class="mvweb-t-subcats__count"><?php echo esc_html( $mvweb_noun( $mvweb_tile ) ); ?></span>
							<?php endif; ?>
						</span>
					</a>
				<?php endforeach; ?>
			</div>

		<?php elseif ( 'more' === $mvweb_view ) : ?>
			<div class="mvweb-t-subcats mvweb-t-subcats--more" data-subcats>
				<?php
				foreach ( $mvweb_tiles as $mvweb_index => $mvweb_tile ) {
					printf(
						'<a class="mvweb-t-subcats__pill" href="%1$s"%2$s>%3$s%4$s</a>',
						esc_url( $mvweb_tile['url'] ),
						$mvweb_extra( $mvweb_index ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.
						esc_html( $mvweb_tile['title'] ),
						$mvweb_count( $mvweb_tile ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper.
					);
				}
				?>
				<?php if ( $mvweb_rest > 0 ) : ?>
					<button class="mvweb-t-subcats__pill mvweb-t-subcats__more" type="button" data-subcats-more>
						<?php
						/* translators: %s: number of hidden sections. */
						echo esc_html( sprintf( __( 'More %s', 'brand-market' ), number_format_i18n( $mvweb_rest ) ) );
						?>
					</button>
				<?php endif; ?>
			</div>

		<?php elseif ( 'cards' === $mvweb_view ) : ?>
			<nav class="mvweb-t-subcats mvweb-t-subcats--cards" aria-label="<?php echo esc_attr( $mvweb_label ); ?>">
				<?php foreach ( $mvweb_tiles as $mvweb_tile ) : ?>
					<a class="mvweb-t-subcats__card" href="<?php echo esc_url( $mvweb_tile['url'] ); ?>">
						<span class="mvweb-t-subcats__icon">
							<?php
							$mvweb_pic = $mvweb_tile['image'] > 0 ? wp_get_attachment_image(
								$mvweb_tile['image'],
								'thumbnail',
								false,
								array(
									'alt'      => '',
									'loading'  => 'lazy',
									'decoding' => 'async',
								)
							) : mvweb_theme_icon( isset( $mvweb_tile['icon'] ) ? $mvweb_tile['icon'] : 'file-text' );
							echo $mvweb_pic; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds the image tag, the helper escapes the icon.
							?>
						</span>
						<span class="mvweb-t-subcats__name"><?php echo esc_html( $mvweb_tile['title'] ); ?></span>
						<?php if ( ! empty( $mvweb_tile['desc'] ) ) : ?>
							<span class="mvweb-t-subcats__desc"><?php echo esc_html( $mvweb_tile['desc'] ); ?></span>
						<?php endif; ?>
						<span class="mvweb-t-subcats__count"><?php echo esc_html( $mvweb_noun( $mvweb_tile ) ); ?></span>
					</a>
				<?php endforeach; ?>
			</nav>

		<?php elseif ( 'toc' === $mvweb_view ) : ?>
			<nav class="mvweb-t-subcats mvweb-t-subcats--toc" aria-label="<?php echo esc_attr( $mvweb_label ); ?>">
				<?php foreach ( $mvweb_tiles as $mvweb_tile ) : ?>
					<div class="mvweb-t-subcats__group">
						<a class="mvweb-t-subcats__head" href="<?php echo esc_url( $mvweb_tile['url'] ); ?>">
							<span class="mvweb-t-subcats__name"><?php echo esc_html( $mvweb_tile['title'] ); ?></span>
							<span class="mvweb-t-subcats__count"><?php echo esc_html( number_format_i18n( $mvweb_tile['count'] ) ); ?></span>
						</a>
						<?php if ( ! empty( $mvweb_tile['posts'] ) ) : ?>
							<ul class="mvweb-t-subcats__posts">
								<?php foreach ( $mvweb_tile['posts'] as $mvweb_post ) : ?>
									<li><a href="<?php echo esc_url( get_permalink( $mvweb_post ) ); ?>"><?php echo esc_html( get_the_title( $mvweb_post ) ); ?></a></li>
								<?php endforeach; ?>
							</ul>
						<?php endif; ?>
						<a class="mvweb-t-subcats__every" href="<?php echo esc_url( $mvweb_tile['url'] ); ?>">
							<?php
							/* translators: %s: number and word, for example «12 articles». */
							echo esc_html( sprintf( __( 'All %s', 'brand-market' ), $mvweb_noun( $mvweb_tile ) ) );
							echo $mvweb_arrow; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
							?>
						</a>
					</div>
				<?php endforeach; ?>
			</nav>

		<?php elseif ( 'rail' === $mvweb_view ) : ?>
			<div class="mvweb-t-subcats mvweb-t-subcats--rail<?php echo $mvweb_blog ? ' mvweb-t-subcats--photos' : ''; ?>">
				<div class="mvweb-t-subcats__track" data-subcats-track data-scroller="<?php echo esc_attr( $mvweb_label ); ?>">
					<?php foreach ( $mvweb_tiles as $mvweb_tile ) : ?>
						<a class="mvweb-t-subcats__pill" href="<?php echo esc_url( $mvweb_tile['url'] ); ?>">
							<span class="mvweb-t-subcats__pic">
								<?php
								if ( $mvweb_tile['image'] > 0 ) {
									echo wp_get_attachment_image(
										$mvweb_tile['image'],
										$mvweb_blog ? 'medium' : 'thumbnail',
										false,
										array(
											'alt'      => '',
											'loading'  => 'lazy',
											'decoding' => 'async',
										)
									);
								}
								?>
							</span>
							<?php if ( $mvweb_blog ) : ?>
								<span class="mvweb-t-subcats__name"><?php echo esc_html( $mvweb_tile['title'] ); ?></span>
								<span class="mvweb-t-subcats__count"><?php echo esc_html( $mvweb_noun( $mvweb_tile ) ); ?></span>
							<?php else : ?>
								<?php echo esc_html( $mvweb_tile['title'] ); ?>
								<?php echo $mvweb_count( $mvweb_tile ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>
							<?php endif; ?>
						</a>
					<?php endforeach; ?>
				</div>
				<button class="mvweb-t-round mvweb-t-subcats__next" type="button" data-subcats-next hidden title="<?php esc_attr_e( 'Next', 'brand-market' ); ?>">
					<?php echo mvweb_theme_icon( 'chevron-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<span class="screen-reader-text"><?php esc_html_e( 'Next', 'brand-market' ); ?></span>
				</button>
			</div>

		<?php elseif ( 'columns' === $mvweb_view ) : ?>
			<div class="mvweb-t-subcats mvweb-t-subcats--columns" data-subcats>
				<div class="mvweb-t-subcats__cols"><?php $mvweb_links(); ?></div>
				<?php if ( $mvweb_rest > 0 ) : ?>
					<button class="mvweb-t-subcats__all" type="button" data-subcats-more>
						<?php
						/* translators: %s: number of all sections. */
						echo esc_html( sprintf( _n( 'All %s section', 'All %s sections', $mvweb_total, 'brand-market' ), number_format_i18n( $mvweb_total ) ) );
						?>
					</button>
				<?php endif; ?>
			</div>

		<?php else : ?>
			<details class="mvweb-t-subcats mvweb-t-subcats--button">
				<summary class="mvweb-t-subcats__pill mvweb-t-subcats__toggle">
					<?php echo mvweb_theme_icon( 'layout-grid', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<?php echo esc_html( $mvweb_label ); ?>
					<span class="mvweb-t-subcats__count"><?php echo esc_html( number_format_i18n( $mvweb_total ) ); ?></span>
					<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm mvweb-t-subcats__chevron' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				</summary>
				<div class="mvweb-t-subcats__cols mvweb-t-subcats__panel"><?php $mvweb_links(); ?></div>
			</details>
		<?php endif; ?>
	</div>
</section>
