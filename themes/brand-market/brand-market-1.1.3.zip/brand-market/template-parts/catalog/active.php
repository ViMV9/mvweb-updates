<?php
/**
 * Catalogue listing: the chips of the filters the visitor chose, each one takes its filter away.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_active = mvweb_core_listing_active();

if ( empty( $mvweb_active['items'] ) ) {
	return;
}
?>
<div class="mvweb-t-active" role="group" aria-label="<?php esc_attr_e( 'Chosen filters', 'brand-market' ); ?>">
	<?php foreach ( $mvweb_active['items'] as $mvweb_chip ) : ?>
		<a class="mvweb-t-active__chip" href="<?php echo esc_url( $mvweb_chip['url'] ); ?>">
			<?php echo esc_html( $mvweb_chip['label'] ); ?>
			<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span class="screen-reader-text"><?php esc_html_e( 'Remove the filter', 'brand-market' ); ?></span>
		</a>
	<?php endforeach; ?>
	<a class="mvweb-t-active__reset" href="<?php echo esc_url( $mvweb_active['reset'] ); ?>"><?php esc_html_e( 'Reset all', 'brand-market' ); ?></a>
</div>
