<?php
/**
 * Product card: one frame for listings, blocks and the favourites.
 *
 * The photo with its badges and the favourites and compare buttons is the frame; what
 * stands in the body, and in what order, is the composition of the card set
 * in the Customizer (inc/theme/layouts/card-product.php). Every part is a file
 * of template-parts/card-product/. Under WooCommerce the two outer hooks of a
 * loop item still fire, so a plugin decorating a card keeps working.
 *
 * Arguments: id, eager (bool), tag (the tag of the name: div, h2, h3), class
 * (extra classes), attrs (attribute => value, an empty value makes a flag),
 * button (text, action link or form, url: the wording of a block over the
 * settings of Conversion), qty (bool, the listing asks for the quantity field
 * before the button), badge (own, hit, new or none: the badge a block adds).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_args = isset( $args ) && is_array( $args ) ? $args : array();
$mvweb_id   = isset( $mvweb_args['id'] ) ? absint( $mvweb_args['id'] ) : get_the_ID();

if ( ! mvweb_core_item_visible( $mvweb_id ) ) {
	return;
}

$mvweb_args['id']    = $mvweb_id;
$mvweb_args['state'] = new ArrayObject( array( 'group' => '' ) );

$mvweb_class = trim( 'mvweb-t-card mvweb-t-card--product' . ( 'compact' === get_theme_mod( 'mvweb_card_buy', 'wide' ) ? ' mvweb-t-card--buy-compact ' : ' ' ) . ( isset( $mvweb_args['class'] ) ? (string) $mvweb_args['class'] : '' ) );
$mvweb_class = mvweb_core_is_woocommerce() && function_exists( 'wc_get_product_class' ) ? implode( ' ', array_unique( array_merge( explode( ' ', $mvweb_class ), wc_get_product_class( '', $mvweb_id ) ) ) ) : $mvweb_class;
$mvweb_attrs = '';

foreach ( isset( $mvweb_args['attrs'] ) && is_array( $mvweb_args['attrs'] ) ? $mvweb_args['attrs'] : array() as $mvweb_name => $mvweb_value ) {
	$mvweb_name   = sanitize_key( $mvweb_name );
	$mvweb_attrs .= '' === $mvweb_name ? '' : ' ' . $mvweb_name . ( '' === (string) $mvweb_value ? '' : '="' . esc_attr( (string) $mvweb_value ) . '"' );
}

$mvweb_link  = (string) get_permalink( $mvweb_id );
$mvweb_badge = mvweb_core_layout_has( 'card-product', 'badges' ) ? mvweb_core_item_badges( $mvweb_id, isset( $args['badge'] ) ? (string) $args['badge'] : 'own' ) : array();
?>
<article class="<?php echo esc_attr( $mvweb_class ); ?>"<?php echo $mvweb_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Names are cleaned, values escaped above. ?>>
	<?php
	if ( mvweb_core_is_woocommerce() ) {
		/**
		 * The first slot of a card. WooCommerce opened the product link here.
		 *
		 * @since 0.1.0
		 */
		do_action( 'woocommerce_before_shop_loop_item' );
	}
	?>
	<a class="mvweb-t-card__media" href="<?php echo esc_url( $mvweb_link ); ?>" tabindex="-1" aria-hidden="true">
		<?php
		echo mvweb_core_item_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core's escaped image markup.
			$mvweb_id,
			'mvweb_card',
			array(
				'loading'  => ! empty( $mvweb_args['eager'] ) ? false : 'lazy',
				'decoding' => 'async',
			)
		);
		?>
		<?php if ( ! empty( $mvweb_badge ) ) : ?>
			<span class="mvweb-t-card__badges">
				<?php foreach ( $mvweb_badge as $mvweb_one ) : ?>
					<span class="<?php echo esc_attr( 'mvweb-t-badge mvweb-t-badge--' . sanitize_html_class( $mvweb_one['type'] ) ); ?>"><?php echo esc_html( $mvweb_one['text'] ); ?></span>
				<?php endforeach; ?>
			</span>
		<?php endif; ?>
	</a>
	<?php if ( mvweb_core_layout_has( 'card-product', 'fav' ) && function_exists( 'mvweb_core_favorites_url' ) && mvweb_core_favorites_url() ) : ?>
		<button class="mvweb-t-round mvweb-t-card__fav" type="button" data-fav-toggle="<?php echo (int) $mvweb_id; ?>" aria-pressed="false" title="<?php esc_attr_e( 'Add to favourites', 'brand-market' ); ?>">
			<?php echo mvweb_theme_icon( 'heart', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span class="screen-reader-text" data-fav-label><?php esc_html_e( 'Add to favourites', 'brand-market' ); ?></span>
		</button>
	<?php endif; ?>
	<?php
	if ( mvweb_core_layout_has( 'card-product', 'compare' ) ) {
		echo mvweb_theme_compare_button( $mvweb_id, 'mvweb-t-round mvweb-t-card__fav mvweb-t-card__compare' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
	}
	?>
	<?php
	if ( mvweb_core_is_woocommerce() ) {
		do_action( 'woocommerce_before_shop_loop_item_title' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
	}
	?>
	<div class="mvweb-t-card__body">
		<?php
		mvweb_core_render_layout( 'card-product', $mvweb_args );
		mvweb_theme_card_group( $mvweb_args, '' );

		if ( mvweb_core_is_woocommerce() ) {
			do_action( 'woocommerce_shop_loop_item_title' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
			do_action( 'woocommerce_after_shop_loop_item_title' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
		}
		?>
	</div>
	<?php
	if ( mvweb_core_is_woocommerce() ) {
		/**
		 * Whatever a plugin appends to a card.
		 *
		 * @since 0.1.0
		 */
		do_action( 'woocommerce_after_shop_loop_item' );
	}
	?>
</article>
