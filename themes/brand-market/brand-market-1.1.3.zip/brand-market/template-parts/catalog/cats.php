<?php
/**
 * The subcategories of the listing as one select in the bar, for a phone.
 *
 * On a phone it stands instead of the row of pills above the bar, so the first
 * items stay on the first screen. Choosing a line opens that section.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tiles = mvweb_core_listing_subcats();

if ( empty( $mvweb_tiles ) ) {
	return;
}
?>
<div class="mvweb-t-cats">
	<label class="screen-reader-text" for="mvweb-t-cats-select"><?php esc_html_e( 'Categories', 'brand-market' ); ?></label>
	<select class="mvweb-t-cats__select" id="mvweb-t-cats-select" data-nav-select>
		<option value="" selected><?php esc_html_e( 'Categories', 'brand-market' ); ?></option>
		<?php foreach ( $mvweb_tiles as $mvweb_tile ) : ?>
			<option value="<?php echo esc_url( $mvweb_tile['url'] ); ?>"><?php echo esc_html( $mvweb_tile['count'] > 0 ? $mvweb_tile['title'] . ' (' . number_format_i18n( $mvweb_tile['count'] ) . ')' : $mvweb_tile['title'] ); ?></option>
		<?php endforeach; ?>
	</select>
</div>
