<?php
/**
 * Catalogue listing: the archive itself, any of its categories and a filter page.
 *
 * The loop is the main query in both sources — WooCommerce hands the shop page
 * one, and a post type archive is one already — so the template walks it
 * rather than running a query of its own. The head, the bar, the sidebar and
 * what stands under the cards are areas of the composition, set in the
 * Customizer.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_facet = mvweb_core_current_facet();
$mvweb_title = $mvweb_facet ? '' : mvweb_core_alt_h1();

if ( '' === $mvweb_title ) {
	$mvweb_title = mvweb_core_catalog_title();
}

$mvweb_term  = get_queried_object();
$mvweb_image = $mvweb_term instanceof WP_Term
	? absint( get_term_meta( $mvweb_term->term_id, 'thumbnail_id', true ) )
	: 0;

if ( $mvweb_facet && has_post_thumbnail( $mvweb_facet ) ) {
	$mvweb_image = (int) get_post_thumbnail_id( $mvweb_facet );
}

$mvweb_filtered = mvweb_core_listing_filtered();
$mvweb_total    = (int) $GLOBALS['wp_query']->found_posts;
/* translators: %s: number of items found. */
$mvweb_count = $mvweb_total > 0 && mvweb_core_layout_has( 'catalog-toolbar', 'count' ) ? sprintf( _n( 'Found %s item', 'Found %s items', $mvweb_total, 'brand-market' ), number_format_i18n( $mvweb_total ) ) : '';

ob_start();
mvweb_core_render_layout( 'listing-head', mvweb_core_listing_lead() );
$mvweb_after = ob_get_clean();

$mvweb_sidebar = mvweb_core_sidebar_html( 'catalog' );

if ( '' !== $mvweb_sidebar ) {
	get_template_part( 'template-parts/crumbs', null, array( 'wrap' => true ) );
}

ob_start();
get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'title'    => $mvweb_title,
		'count'    => $mvweb_count,
		'after'    => $mvweb_after,
		'image_id' => $mvweb_image,
	)
);
get_template_part( 'template-parts/catalog/subcats' );
$mvweb_head = (string) ob_get_clean();

if ( '' === $mvweb_sidebar ) {
	echo $mvweb_head; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates.
}
?>

<?php
if ( mvweb_core_wc_archive() ) {
	do_action( 'woocommerce_before_main_content' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
}
?>
<section class="mvweb-t-catalog">
	<div class="mvweb-t-container mvweb-t-catalog__layout<?php echo '' === $mvweb_sidebar ? '' : esc_attr( mvweb_theme_sidebar_side_class( 'catalog', 'mvweb-t-catalog__layout' ) ); ?>">

		<div class="mvweb-t-catalog__main">
			<?php
			if ( '' !== $mvweb_sidebar ) {
				echo $mvweb_head; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates.
			}

			if ( mvweb_core_wc_archive() ) {
				do_action( 'woocommerce_shop_loop_header' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
				do_action( 'woocommerce_archive_description' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
			}
			?>
			<?php if ( have_posts() ) : ?>

				<?php
				if ( mvweb_core_wc_archive() ) {
					do_action( 'woocommerce_before_shop_loop' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
				}

				get_template_part( 'template-parts/catalog/sort', null, array( 'has_filters' => false !== strpos( $mvweb_sidebar, 'data-filters' ) ) );
				get_template_part( 'template-parts/catalog/active' );
				get_template_part( 'template-parts/catalog/thead' );
				?>

				<div class="mvweb-t-catalog__grid" data-catalog-grid data-view="<?php echo esc_attr( mvweb_core_catalog_view() ); ?>" data-cols="<?php echo esc_attr( in_array( (string) get_theme_mod( 'mvweb_catalog_columns', '3' ), array( '4', '5' ), true ) ? (string) get_theme_mod( 'mvweb_catalog_columns', '3' ) : '3' ); ?>">
					<?php
					while ( have_posts() ) :
						the_post();

						get_template_part(
							'template-parts/catalog/card',
							null,
							array(
								'id'    => get_the_ID(),
								'eager' => $GLOBALS['wp_query']->current_post < 4,
								'qty'   => true,
							)
						);
					endwhile;
					?>
				</div>

				<?php
				mvweb_theme_pagination();

				if ( mvweb_core_wc_archive() ) {
					do_action( 'woocommerce_after_shop_loop' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
				}
				?>

			<?php else : ?>

				<?php
				get_template_part(
					'template-parts/empty',
					null,
					array(
						'icon'        => 'filter',
						'title'       => $mvweb_filtered
							? __( 'Nothing matches the filters', 'brand-market' )
							: __( 'This section is empty', 'brand-market' ),
						'text'        => $mvweb_filtered
							? __( 'Widen the price range or clear a few options.', 'brand-market' )
							: __( 'There are no items here yet. Have a look at the other sections.', 'brand-market' ),
						'button_url'  => $mvweb_filtered
							? mvweb_core_catalog_url()
							: ( $mvweb_term instanceof WP_Term ? mvweb_core_catalog_page_url() : '' ),
						'button_text' => $mvweb_filtered
							? __( 'Reset the filters', 'brand-market' )
							: __( 'To the catalog', 'brand-market' ),
					)
				);

				if ( mvweb_core_wc_archive() ) {
					do_action( 'woocommerce_no_products_found' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
				}
				?>

			<?php endif; ?>

			<?php mvweb_core_render_layout( 'listing-below', array( 'place' => 'main' ) ); ?>
		</div>

		<?php
		get_template_part(
			'template-parts/sidebar',
			null,
			array(
				'area'  => 'catalog',
				'class' => 'mvweb-t-catalog__aside',
			)
		);
		?>

	</div>
</section>

<?php
mvweb_core_render_layout( 'listing-below', array( 'place' => 'after' ) );

if ( mvweb_core_wc_archive() ) {
	do_action( 'woocommerce_after_main_content' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
	do_action( 'woocommerce_sidebar' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
}
