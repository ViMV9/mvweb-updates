<?php
/**
 * Service head part: the price and the button that leads to the form.
 *
 * Narrow screens only: the side card drops under the heading there, and this
 * line lets the visitor reach its form without scrolling past the text. The
 * button leads to the form of the side card, or to the address of the request
 * button when the service has no form.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id   = absint( $args['id'] );
$mvweb_form = '' !== trim( (string) mvweb_core_option( 'mvweb_service_form' ) ) && mvweb_core_layout_has( 'service-aside', 'form' );
$mvweb_text = (string) get_theme_mod( 'mvweb_cta_text', __( 'Request a quote', 'brand-market' ) );
$mvweb_url  = $mvweb_form ? '#mvweb-t-service-form' : (string) get_theme_mod( 'mvweb_cta_url', '' );

if ( '' === $mvweb_text || '' === $mvweb_url ) {
	return;
}

$mvweb_price = mvweb_core_item_price_html( $mvweb_id );
$mvweb_from  = mvweb_core_service_price_from();

if ( '' === trim( wp_strip_all_tags( $mvweb_price ) ) ) {
	$mvweb_price = esc_html( mvweb_core_service_price_placeholder() );
	$mvweb_from  = '';
}
?>
<a class="mvweb-t-service__jump" href="<?php echo esc_url( $mvweb_url ); ?>">
	<?php if ( '' !== $mvweb_price ) : ?>
		<span class="mvweb-t-service__jump-price">
			<?php if ( '' !== $mvweb_from ) : ?>
				<span class="mvweb-t-price__from"><?php echo esc_html( $mvweb_from ); ?></span>
			<?php endif; ?>
			<?php echo wp_kses_post( $mvweb_price ); ?>
		</span>
	<?php endif; ?>
	<span class="mvweb-t-btn mvweb-t-btn--sm"><?php echo esc_html( $mvweb_text ); ?></span>
</a>
