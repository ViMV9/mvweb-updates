<?php
/**
 * Service head part: the short text.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_excerpt = mvweb_core_item_excerpt( absint( $args['id'] ) );

if ( '' === trim( wp_strip_all_tags( $mvweb_excerpt ) ) ) {
	return;
}
?>
<div class="mvweb-t-product-desc"><?php echo $mvweb_excerpt; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Closes its chain with wp_kses_post(). ?></div>
