<?php
/**
 * Service head part: the line under the heading.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_advantage = mvweb_core_service_advantage( absint( $args['id'] ) );

if ( '' === $mvweb_advantage ) {
	return;
}
?>
<p class="mvweb-t-service__advantage">
	<?php echo mvweb_theme_icon( 'check', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<?php echo esc_html( $mvweb_advantage ); ?>
</p>
