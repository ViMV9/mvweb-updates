<?php
/**
 * Service below part: the blocks built in the page builder of the service.
 *
 * A price list, questions, reviews: what a landing page of its own would hold,
 * at the full width of the page.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_render_sections( mvweb_core_request_sections() );
