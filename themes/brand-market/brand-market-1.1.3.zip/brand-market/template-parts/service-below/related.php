<?php
/**
 * Service below part: the other services of the section.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id   = absint( $args['id'] );
$mvweb_term = mvweb_core_service_primary_term( $mvweb_id );
$mvweb_link = $mvweb_term ? get_term_link( $mvweb_term ) : mvweb_core_service_archive_url();

get_template_part(
	'template-parts/service/strip',
	null,
	array(
		'kind'      => 'service',
		'ids'       => mvweb_core_related_services( $mvweb_id ),
		'title'     => trim( (string) mvweb_core_services_pages_option( 'mvweb_service_related_title' ) ),
		'link_text' => trim( (string) mvweb_core_services_pages_option( 'mvweb_service_related_more' ) ),
		'link_url'  => is_string( $mvweb_link ) ? $mvweb_link : '',
		'bg'        => 'surface',
	)
);
