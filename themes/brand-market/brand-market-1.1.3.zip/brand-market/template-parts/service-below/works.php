<?php
/**
 * Service below part: the works done on this service.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_count = absint( mvweb_core_services_pages_option( 'mvweb_service_works_count' ) );

if ( 0 === $mvweb_count ) {
	return;
}

get_template_part(
	'template-parts/service/strip',
	null,
	array(
		'kind'  => 'work',
		'ids'   => mvweb_core_works(
			array(
				'count'   => $mvweb_count,
				'service' => absint( $args['id'] ),
			)
		),
		'title' => trim( (string) mvweb_core_services_pages_option( 'mvweb_service_works_title' ) ),
		'bg'    => 'plain',
	)
);
