<?php
/**
 * Order received, part: where the goods go and who gets them.
 *
 * Arguments: order.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_order = isset( $args['order'] ) ? $args['order'] : null;

if ( ! $mvweb_order instanceof WC_Order ) {
	return;
}

$mvweb_method  = trim( wp_strip_all_tags( (string) $mvweb_order->get_shipping_method() ) );
$mvweb_address = $mvweb_order->needs_shipping_address() ? trim( (string) ( $mvweb_order->get_formatted_shipping_address() ? $mvweb_order->get_formatted_shipping_address() : $mvweb_order->get_formatted_billing_address() ) ) : '';
$mvweb_name    = trim( $mvweb_order->get_formatted_billing_full_name() );
$mvweb_phone   = trim( (string) $mvweb_order->get_billing_phone() );
$mvweb_mail    = trim( (string) $mvweb_order->get_billing_email() );
$mvweb_ship    = '' !== $mvweb_method || '' !== $mvweb_address;
$mvweb_who     = '' !== $mvweb_name . $mvweb_phone . $mvweb_mail;

if ( ! $mvweb_ship && ! $mvweb_who ) {
	return;
}
?>
<div class="mvweb-t-info-cards">
	<?php if ( $mvweb_ship ) : ?>
		<section class="mvweb-t-info-card">
			<div class="mvweb-t-info-card__title mvweb-t-h2" role="heading" aria-level="2"><?php esc_html_e( 'Delivery', 'brand-market' ); ?></div>
			<p>
				<?php echo esc_html( $mvweb_method ); ?>
				<?php echo '' !== $mvweb_method && '' !== $mvweb_address ? '<br>' : ''; ?>
				<?php echo wp_kses( $mvweb_address, array( 'br' => array() ) ); ?>
			</p>
		</section>
	<?php endif; ?>
	<?php if ( $mvweb_who ) : ?>
		<section class="mvweb-t-info-card">
			<div class="mvweb-t-info-card__title mvweb-t-h2" role="heading" aria-level="2"><?php esc_html_e( 'Recipient', 'brand-market' ); ?></div>
			<p>
				<?php echo esc_html( $mvweb_name ); ?>
				<?php echo '' !== $mvweb_phone ? '<br>' . esc_html( $mvweb_phone ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the expression. ?>
				<?php echo '' !== $mvweb_mail ? '<br>' . esc_html( $mvweb_mail ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the expression. ?>
			</p>
		</section>
	<?php endif; ?>
</div>
