<?php
/**
 * Order received, part: what the payment method tells the customer to do, like the bank details.
 *
 * Arguments: order.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_order = isset( $args['order'] ) ? $args['order'] : null;

if ( ! $mvweb_order instanceof WC_Order ) {
	return;
}

ob_start();
do_action( 'woocommerce_thankyou_' . $mvweb_order->get_payment_method(), $mvweb_order->get_id() );
$mvweb_html = trim( (string) ob_get_clean() );

if ( '' === trim( wp_strip_all_tags( $mvweb_html ) ) ) {
	echo $mvweb_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Scripts that the gateway prints on the hook of WooCommerce.

	return;
}
?>
<section class="mvweb-t-info-card mvweb-t-thanks__pay mvweb-t-prose">
	<?php echo $mvweb_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the payment gateway, printed on the hook of WooCommerce. ?>
</section>
