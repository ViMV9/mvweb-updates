<?php
/**
 * Order received, part: the way on, to the catalogue and to the orders.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_orders = is_user_logged_in() ? wc_get_endpoint_url( 'orders', '', wc_get_page_permalink( 'myaccount' ) ) : '';
?>
<div class="mvweb-t-thanks__actions">
	<a class="mvweb-t-btn" href="<?php echo esc_url( mvweb_core_catalog_page_url() ); ?>"><?php esc_html_e( 'Continue shopping', 'brand-market' ); ?></a>
	<?php if ( '' !== $mvweb_orders ) : ?>
		<a class="mvweb-t-btn mvweb-t-btn--outline" href="<?php echo esc_url( $mvweb_orders ); ?>"><?php esc_html_e( 'My orders', 'brand-market' ); ?></a>
	<?php endif; ?>
</div>
