<?php
/**
 * Order received, part: the steps that follow the order.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_steps = array_filter(
	mvweb_core_cart_rows( 'mvweb_thanks_steps' ),
	static function ( $row ) {
		return ! empty( $row['title'] );
	}
);

if ( empty( $mvweb_steps ) ) {
	return;
}
?>
<section class="mvweb-t-next">
	<div class="mvweb-t-next__title mvweb-t-h2" role="heading" aria-level="2"><?php esc_html_e( 'What happens next', 'brand-market' ); ?></div>
	<ol class="mvweb-t-next__list">
		<?php foreach ( $mvweb_steps as $mvweb_step ) : ?>
			<li>
				<strong><?php echo esc_html( $mvweb_step['title'] ); ?></strong>
				<?php if ( ! empty( $mvweb_step['text'] ) ) : ?>
					<span><?php echo esc_html( $mvweb_step['text'] ); ?></span>
				<?php endif; ?>
			</li>
		<?php endforeach; ?>
	</ol>
</section>
