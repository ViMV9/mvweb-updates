<?php
/**
 * Zone element: Phone.
 *
 * In a bar it is the first number of the chosen city; the hours element that
 * follows it in the same zone becomes the line under the number. In the mobile
 * menu it is every number with its caption.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_zone     = isset( $args['zone'] ) ? $args['zone'] : '';
$mvweb_context  = isset( $args['context'] ) ? $args['context'] : 'bar';
$mvweb_contacts = mvweb_core_contacts();
$mvweb_phones   = $mvweb_contacts['phones'];

if ( empty( $mvweb_phones ) ) {
	return;
}

if ( 'drawer' === $mvweb_context ) :
	?>
	<div class="mvweb-t-el-phone mvweb-t-drawer__phones">
		<?php foreach ( $mvweb_phones as $mvweb_phone ) : ?>
			<?php $mvweb_tag = '' === $mvweb_phone['href'] ? 'span' : 'a'; ?>
			<<?php echo esc_html( $mvweb_tag ); ?> class="mvweb-t-drawer__phone"<?php echo 'a' === $mvweb_tag ? ' href="' . esc_url( $mvweb_phone['href'] ) . '"' : ''; ?>>
				<?php if ( '' !== $mvweb_phone['label'] ) : ?>
					<span class="mvweb-t-drawer__phone-label"><?php echo esc_html( $mvweb_phone['label'] ); ?></span>
				<?php endif; ?>
				<span class="mvweb-t-drawer__phone-num"><?php echo esc_html( $mvweb_phone['number'] ); ?></span>
			</<?php echo esc_html( $mvweb_tag ); ?>>
		<?php endforeach; ?>
	</div>
	<?php
	return;
endif;

$mvweb_first = $mvweb_phones[0];
$mvweb_tag   = '' === $mvweb_first['href'] ? 'span' : 'a';
$mvweb_note  = 'schedule' === mvweb_core_zone_neighbour( $mvweb_zone, 'phone', 1 ) ? mvweb_core_hours_line( $mvweb_contacts['hours'] ) : '';
$mvweb_icon  = 'none' !== get_theme_mod( 'mvweb_header_phone_icon', 'none' );
?>
<div class="mvweb-t-el-phone">
	<?php if ( $mvweb_icon ) : ?>
		<span class="mvweb-t-el-phone__ico"><?php echo mvweb_theme_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
	<?php endif; ?>
	<<?php echo esc_html( $mvweb_tag ); ?> class="mvweb-t-el-phone__number"<?php echo 'a' === $mvweb_tag ? ' href="' . esc_url( $mvweb_first['href'] ) . '"' : ''; ?>><?php echo esc_html( $mvweb_first['number'] ); ?></<?php echo esc_html( $mvweb_tag ); ?>>
	<?php if ( '' !== $mvweb_note ) : ?>
		<span class="mvweb-t-el-phone__note"><?php echo esc_html( $mvweb_note ); ?></span>
	<?php endif; ?>
</div>
