<?php
/**
 * Zone element: Cart link.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'wc_get_cart_url' ) ) {
	return;
}

$mvweb_zone = isset( $args['zone'] ) ? $args['zone'] : '';
?>
<a class="mvweb-t-el-cart mvweb-t-round<?php echo 'header-nav' === $mvweb_zone ? ' mvweb-t-round--ghost' : ''; ?>" href="<?php echo esc_url( wc_get_cart_url() ); ?>" title="<?php esc_attr_e( 'Cart', 'brand-market' ); ?>" data-cart-open>
	<?php echo mvweb_theme_icon( 'cart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<?php get_template_part( 'template-parts/cart-count' ); ?>
	<span class="screen-reader-text"><?php esc_html_e( 'Cart', 'brand-market' ); ?></span>
</a>
