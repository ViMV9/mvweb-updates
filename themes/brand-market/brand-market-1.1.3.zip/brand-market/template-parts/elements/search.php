<?php
/**
 * Zone element: Search button.
 *
 * Opens the search row printed under the header by mvweb_theme_search_panel().
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_zone = isset( $args['zone'] ) ? $args['zone'] : '';
?>
<button class="mvweb-t-el-search mvweb-t-round<?php echo 'header-nav' === $mvweb_zone ? ' mvweb-t-round--ghost' : ''; ?>" type="button" data-search-toggle aria-controls="mvweb-t-search-panel" aria-expanded="false" title="<?php esc_attr_e( 'Search', 'brand-market' ); ?>">
	<?php echo mvweb_theme_icon( 'search' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<span class="screen-reader-text"><?php esc_html_e( 'Search', 'brand-market' ); ?></span>
</button>
