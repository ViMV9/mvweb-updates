<?php
/**
 * Zone element: Action button.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_context = isset( $args['context'] ) ? $args['context'] : 'bar';
$mvweb_url     = mvweb_cz_get( 'mvweb_cta_url', '' );

if ( '' === $mvweb_url ) {
	return;
}

$mvweb_text  = mvweb_cz_get( 'mvweb_cta_text', __( 'Request a quote', 'brand-market' ) );
$mvweb_class = 'drawer' === $mvweb_context ? 'mvweb-t-btn mvweb-t-btn--block' : 'mvweb-t-btn mvweb-t-btn--sm';
?>
<a class="mvweb-t-el-cta <?php echo esc_attr( $mvweb_class ); ?>" href="<?php echo esc_url( $mvweb_url ); ?>"><?php echo esc_html( $mvweb_text ); ?></a>
