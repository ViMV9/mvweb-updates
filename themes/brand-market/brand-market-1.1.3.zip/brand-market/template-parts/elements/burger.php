<?php
/**
 * Zone element: Mobile menu button.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<button class="mvweb-t-el-burger mvweb-t-round mvweb-t-header__burger" type="button" data-drawer-open aria-expanded="false" title="<?php esc_attr_e( 'Menu', 'brand-market' ); ?>">
	<?php echo mvweb_theme_icon( 'menu' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'brand-market' ); ?></span>
</button>
