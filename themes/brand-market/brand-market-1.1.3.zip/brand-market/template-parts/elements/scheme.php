<?php
/**
 * Zone element: Colour scheme switch — a round button in a bar, a labelled one in the mobile menu.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_context = isset( $args['context'] ) ? $args['context'] : 'bar';
$mvweb_dark    = 'dark' === mvweb_core_default_scheme();
$mvweb_title   = $mvweb_dark ? __( 'Switch to the light scheme', 'brand-market' ) : __( 'Switch to the dark scheme', 'brand-market' );

echo mvweb_core_icon_symbol( 'moon' ) . mvweb_core_icon_symbol( 'sun' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted local SVG shipped with the theme.

if ( 'drawer' === $mvweb_context ) :
	?>
	<button class="mvweb-t-el-scheme mvweb-t-drawer__scheme" type="button" data-scheme-toggle aria-pressed="<?php echo $mvweb_dark ? 'true' : 'false'; ?>" title="<?php echo esc_attr( $mvweb_title ); ?>">
		<svg class="mvweb-t-icon" aria-hidden="true" focusable="false" data-scheme-icon="light"<?php echo $mvweb_dark ? ' hidden' : ''; ?>><use href="#mvweb-t-icon-moon"></use></svg>
		<svg class="mvweb-t-icon" aria-hidden="true" focusable="false" data-scheme-icon="dark"<?php echo $mvweb_dark ? '' : ' hidden'; ?>><use href="#mvweb-t-icon-sun"></use></svg>
		<span data-scheme-label><?php echo $mvweb_dark ? esc_html__( 'Light scheme', 'brand-market' ) : esc_html__( 'Dark scheme', 'brand-market' ); ?></span>
	</button>
	<?php
	return;
endif;
?>
<button class="mvweb-t-el-scheme mvweb-t-notice__scheme" type="button" data-scheme-toggle aria-pressed="<?php echo $mvweb_dark ? 'true' : 'false'; ?>" title="<?php echo esc_attr( $mvweb_title ); ?>">
	<svg class="mvweb-t-icon mvweb-t-icon--sm" aria-hidden="true" focusable="false" data-scheme-icon="light"<?php echo $mvweb_dark ? ' hidden' : ''; ?>><use href="#mvweb-t-icon-moon"></use></svg>
	<svg class="mvweb-t-icon mvweb-t-icon--sm" aria-hidden="true" focusable="false" data-scheme-icon="dark"<?php echo $mvweb_dark ? '' : ' hidden'; ?>><use href="#mvweb-t-icon-sun"></use></svg>
	<span class="screen-reader-text" data-scheme-sr><?php echo esc_html( $mvweb_title ); ?></span>
</button>
