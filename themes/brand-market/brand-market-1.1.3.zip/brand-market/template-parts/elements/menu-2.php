<?php
/**
 * Zone element: Second footer menu column.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part(
	'template-parts/elements/menu',
	null,
	array_merge(
		isset( $args ) && is_array( $args ) ? $args : array(),
		array(
			'location' => 'footer-2',
			'heading'  => 'mvweb_footer_menu_2_title',
			'element'  => 'menu-2',
		)
	)
);
