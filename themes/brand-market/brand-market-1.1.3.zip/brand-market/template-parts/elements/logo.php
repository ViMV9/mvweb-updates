<?php
/**
 * Zone element: Logo.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_theme_logo(
	array(
		'class'   => 'mvweb-t-el-logo',
		'heading' => 'h1' === mvweb_core_h1_tag( 'logo' ),
	)
);
