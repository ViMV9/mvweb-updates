<?php
/**
 * Zone element: Footer menu column.
 *
 * Serves both columns: the second one passes its own menu location, the
 * setting of its heading and its element slug.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_location = isset( $args['location'] ) ? (string) $args['location'] : 'footer';
$mvweb_heading  = isset( $args['heading'] ) ? (string) $args['heading'] : 'mvweb_footer_menu_title';
$mvweb_slug     = isset( $args['element'] ) ? (string) $args['element'] : 'menu';
$mvweb_title    = trim( (string) mvweb_cz_get( $mvweb_heading ) );

ob_start();
mvweb_core_nav(
	$mvweb_location,
	array(
		'menu_class'           => 'mvweb-t-footer__list',
		'items_wrap'           => '<ul id="%1$s" class="%2$s">%3$s</ul>',
		'container'            => 'nav',
		'container_aria_label' => '' !== $mvweb_title ? $mvweb_title : __( 'Footer menu', 'brand-market' ),
	)
);
$mvweb_menu = trim( (string) ob_get_clean() );

if ( '' === $mvweb_menu ) {
	return;
}
?>
<div class="mvweb-t-el-<?php echo esc_attr( $mvweb_slug ); ?> mvweb-t-footer__col">
	<?php if ( '' !== $mvweb_title ) : ?>
		<div class="mvweb-t-footer__title"><?php echo esc_html( $mvweb_title ); ?></div>
	<?php endif; ?>

	<?php echo $mvweb_menu; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of wp_nav_menu(), escaped by core. ?>
</div>
