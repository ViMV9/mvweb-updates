<?php
/**
 * Zone element: Account link; without WooCommerce, the profile or the login of WordPress.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_zone = isset( $args['zone'] ) ? $args['zone'] : '';
$mvweb_link = mvweb_core_account_link();

if ( empty( $mvweb_link ) ) {
	return;
}
?>
<a class="mvweb-t-el-account mvweb-t-round <?php echo 'header-nav' === $mvweb_zone ? 'mvweb-t-round--ghost' : ''; ?>" href="<?php echo esc_url( $mvweb_link['url'] ); ?>" title="<?php echo esc_attr( $mvweb_link['label'] ); ?>">
	<?php echo mvweb_theme_icon( 'user' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<span class="screen-reader-text"><?php echo esc_html( $mvweb_link['label'] ); ?></span>
</a>
