<?php
/**
 * Zone element: Social networks, in the mobile menu and in the rows of the header.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_links = mvweb_cz_profile_socials();

if ( empty( $mvweb_links ) ) {
	return;
}

$mvweb_zone = isset( $args['zone'] ) ? $args['zone'] : '';

if ( 'header-drawer-foot' !== $mvweb_zone ) :
	$mvweb_topbar = 'header-topbar' === $mvweb_zone;
	$mvweb_link   = $mvweb_topbar ? 'mvweb-t-notice__social' : 'mvweb-t-round' . ( 'header-nav' === $mvweb_zone ? ' mvweb-t-round--ghost' : '' );
	?>
	<div class="mvweb-t-el-socials <?php echo $mvweb_topbar ? 'mvweb-t-notice__socials' : 'mvweb-t-header__messengers'; ?>">
		<?php foreach ( $mvweb_links as $mvweb_id => $mvweb_social ) : ?>
			<a class="<?php echo esc_attr( $mvweb_link ); ?>" href="<?php echo esc_url( $mvweb_social['url'] ); ?>" title="<?php echo esc_attr( $mvweb_social['label'] ); ?>" rel="noopener" target="_blank">
				<?php echo mvweb_theme_icon( mvweb_core_social_icon( $mvweb_id ), array( 'class' => $mvweb_topbar ? 'mvweb-t-icon--sm' : '' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php echo esc_html( $mvweb_social['label'] ); ?></span>
			</a>
		<?php endforeach; ?>
	</div>
	<?php
	return;
endif;

$mvweb_title = trim( (string) get_theme_mod( 'mvweb_drawer_socials_title', '' ) );
?>
<div class="mvweb-t-el-socials">
	<?php if ( '' !== $mvweb_title ) : ?>
		<p class="mvweb-t-drawer__foot-title"><?php echo esc_html( $mvweb_title ); ?></p>
	<?php endif; ?>
	<div class="mvweb-t-drawer__socials">
		<?php foreach ( $mvweb_links as $mvweb_id => $mvweb_link ) : ?>
			<a class="mvweb-t-round" href="<?php echo esc_url( $mvweb_link['url'] ); ?>" title="<?php echo esc_attr( $mvweb_link['label'] ); ?>" rel="noopener" target="_blank">
				<?php echo mvweb_theme_icon( mvweb_core_social_icon( $mvweb_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php echo esc_html( $mvweb_link['label'] ); ?></span>
			</a>
		<?php endforeach; ?>
	</div>
</div>
