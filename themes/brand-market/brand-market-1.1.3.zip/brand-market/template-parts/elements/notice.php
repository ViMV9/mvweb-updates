<?php
/**
 * Zone element: Announcement of the top bar.
 *
 * A closed announcement stays closed: the small script right after it hides
 * it before the first paint, and the script of the core takes over from there.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_notice = mvweb_core_notice();

if ( empty( $mvweb_notice ) ) {
	return;
}

$mvweb_whole = '' === $mvweb_notice['link'] && '' !== $mvweb_notice['url'];
?>
<div class="mvweb-t-el-notice">
	<p class="mvweb-t-notice__text" data-notice-text>
		<?php echo mvweb_theme_icon( 'truck-delivery', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<?php if ( $mvweb_whole ) : ?>
			<a class="mvweb-t-notice__whole" href="<?php echo esc_url( $mvweb_notice['url'] ); ?>"><?php echo esc_html( $mvweb_notice['text'] ); ?></a>
		<?php else : ?>
			<span><?php echo esc_html( $mvweb_notice['text'] ); ?></span>
			<?php if ( '' !== $mvweb_notice['link'] && '' !== $mvweb_notice['url'] ) : ?>
				<a href="<?php echo esc_url( $mvweb_notice['url'] ); ?>"><?php echo esc_html( $mvweb_notice['link'] ); ?></a>
			<?php endif; ?>
		<?php endif; ?>
	</p>

	<?php if ( $mvweb_notice['closable'] ) : ?>
		<button class="mvweb-t-notice__close" type="button" data-notice-close title="<?php esc_attr_e( 'Close the announcement', 'brand-market' ); ?>">
			<?php echo mvweb_theme_icon( 'close', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span class="screen-reader-text"><?php esc_html_e( 'Close the announcement', 'brand-market' ); ?></span>
		</button>
	<?php endif; ?>
</div>
<?php
if ( $mvweb_notice['closable'] ) {
	wp_print_inline_script_tag(
		'(function(s){var n=s.closest("[data-notice]");if(!n){return;}try{if(!localStorage.getItem(n.getAttribute("data-notice"))){return;}}catch(e){return;}'
		. 'if(n.hasAttribute("data-notice-keep")){n.querySelectorAll("[data-notice-text],[data-notice-close]").forEach(function(e){e.hidden=true;});}else{n.hidden=true;}})(document.currentScript);'
	);
}
