<?php
/**
 * Zone element: Comparison link.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_zone = isset( $args['zone'] ) ? $args['zone'] : '';
$mvweb_url  = mvweb_core_compare_url();

if ( '' === $mvweb_url ) {
	return;
}
?>
<a class="mvweb-t-el-compare mvweb-t-round <?php echo 'header-nav' === $mvweb_zone ? 'mvweb-t-round--ghost' : 'mvweb-t-round--hide-sm'; ?>" href="<?php echo esc_url( $mvweb_url ); ?>" title="<?php esc_attr_e( 'Comparison', 'brand-market' ); ?>">
	<?php echo mvweb_theme_icon( 'arrows-left-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<span class="mvweb-t-round__count" data-compare-count aria-live="polite" hidden></span>
	<span class="screen-reader-text"><?php esc_html_e( 'Comparison', 'brand-market' ); ?></span>
</a>
