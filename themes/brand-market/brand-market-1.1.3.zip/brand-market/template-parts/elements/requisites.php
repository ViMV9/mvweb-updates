<?php
/**
 * Zone element: Company details.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_parts = array( trim( (string) mvweb_cz_profile( 'legal_name' ) ) );

foreach ( mvweb_cz_profile_requisites() as $mvweb_row ) {
	$mvweb_parts[] = trim( $mvweb_row['label'] . ' ' . $mvweb_row['value'] );
}

$mvweb_parts = array_filter( $mvweb_parts );

if ( empty( $mvweb_parts ) ) {
	return;
}
?>
<p class="mvweb-t-el-requisites mvweb-t-footer__org"><?php echo esc_html( implode( ', ', $mvweb_parts ) ); ?></p>
