<?php
/**
 * Zone element: Catalogue button, with the panel of the sections under it.
 *
 * The panel is built from the categories of the catalogue: sections are the
 * tabs, their subsections the columns, and the categories inside them the links.
 * A catalogue without categories gets a plain link instead of a panel.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! get_theme_mod( 'mvweb_catalog_button', true ) ) {
	return;
}

$mvweb_label = trim( (string) get_theme_mod( 'mvweb_catalog_button_label', '' ) );
$mvweb_label = '' === $mvweb_label ? mvweb_core_item_label() : $mvweb_label;
$mvweb_tree  = mvweb_core_catalog_tree();

if ( empty( $mvweb_tree[0] ) ) :
	?>
	<a class="mvweb-t-el-catalog-button mvweb-t-header__catalog" href="<?php echo esc_url( mvweb_core_catalog_page_url() ); ?>">
		<?php echo mvweb_theme_icon( 'layout-grid', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<?php echo esc_html( $mvweb_label ); ?>
	</a>
	<?php
	return;
endif;
?>
<div class="mvweb-t-el-catalog-button mvweb-t-header__catalog-box" data-nav-item>
	<button class="mvweb-t-header__catalog" type="button" data-nav-link aria-haspopup="true" aria-expanded="false" aria-controls="mvweb-t-mega">
		<?php echo mvweb_theme_icon( 'layout-grid', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<?php echo esc_html( $mvweb_label ); ?>
	</button>
	<?php mvweb_theme_mega_panel( $mvweb_tree, $mvweb_label ); ?>
</div>
