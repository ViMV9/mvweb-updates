<?php
/**
 * Zone element: Favourites link.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_zone = isset( $args['zone'] ) ? $args['zone'] : '';
$mvweb_url  = mvweb_core_favorites_url();

if ( '' === $mvweb_url ) {
	return;
}
?>
<a class="mvweb-t-el-favorites mvweb-t-round <?php echo 'header-nav' === $mvweb_zone ? 'mvweb-t-round--ghost' : 'mvweb-t-round--hide-sm'; ?>" href="<?php echo esc_url( $mvweb_url ); ?>" title="<?php esc_attr_e( 'Favourites', 'brand-market' ); ?>">
	<?php echo mvweb_theme_icon( 'heart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<span class="mvweb-t-round__count" data-fav-count aria-live="polite" hidden></span>
	<span class="screen-reader-text"><?php esc_html_e( 'Favourites', 'brand-market' ); ?></span>
</a>
