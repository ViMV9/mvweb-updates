<?php
/**
 * Zone element: City choice — the button with the chosen city, the list of cities and the "Is this your city?" tip.
 *
 * The script of the core reads the attributes; the page reloads on a new
 * choice, so the contacts of the chosen city are printed by the server.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! mvweb_core_has_city_choice() ) {
	return;
}

$mvweb_cities  = mvweb_core_cities();
$mvweb_current = mvweb_core_current_city();
$mvweb_id      = wp_unique_id( 'mvweb-t-city-' );

if ( ! isset( $mvweb_cities[ $mvweb_current ] ) ) {
	return;
}
?>
<div class="mvweb-t-city" data-city-box>
	<button class="mvweb-t-city__btn" type="button" aria-expanded="false" aria-controls="<?php echo esc_attr( $mvweb_id ); ?>" aria-haspopup="listbox" data-city-toggle>
		<?php echo mvweb_theme_icon( 'map-pin', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<span class="mvweb-t-city__name"><?php echo esc_html( $mvweb_cities[ $mvweb_current ]['name'] ); ?></span>
		<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	</button>

	<div class="mvweb-t-city__pop" id="<?php echo esc_attr( $mvweb_id ); ?>" data-city-pop hidden>
		<div class="mvweb-t-city__title"><?php esc_html_e( 'Your city', 'brand-market' ); ?></div>
		<ul class="mvweb-t-city__list" role="listbox" aria-label="<?php esc_attr_e( 'City', 'brand-market' ); ?>">
			<?php foreach ( $mvweb_cities as $mvweb_key => $mvweb_city ) : ?>
				<li>
					<button class="mvweb-t-city__item" type="button" role="option" aria-selected="<?php echo (string) $mvweb_key === $mvweb_current ? 'true' : 'false'; ?>" data-city-pick="<?php echo esc_attr( $mvweb_key ); ?>">
						<span>
							<?php echo esc_html( $mvweb_city['name'] ); ?>
							<small>
								<?php
								/* translators: %d: number of addresses in the city. */
								echo esc_html( sprintf( _n( '%d address', '%d addresses', $mvweb_city['count'], 'brand-market' ), $mvweb_city['count'] ) );
								?>
							</small>
						</span>
						<?php echo mvweb_theme_icon( 'check', array( 'class' => 'mvweb-t-icon--sm mvweb-t-city__check' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					</button>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>

	<?php if ( get_theme_mod( 'mvweb_city_tip', true ) ) : ?>
		<div class="mvweb-t-city__tip" role="dialog" aria-label="<?php esc_attr_e( 'Confirm the city', 'brand-market' ); ?>" data-city-tip data-city-key="<?php echo esc_attr( $mvweb_current ); ?>" hidden>
			<p class="mvweb-t-city__tip-text">
				<?php
				/* translators: %s: name of the city. */
				echo wp_kses( sprintf( __( 'Your city: %s?', 'brand-market' ), '<b>' . esc_html( $mvweb_cities[ $mvweb_current ]['name'] ) . '</b>' ), array( 'b' => array() ) );
				?>
			</p>
			<div class="mvweb-t-city__tip-actions">
				<button class="mvweb-t-btn mvweb-t-btn--sm" type="button" data-city-yes><?php esc_html_e( 'Yes', 'brand-market' ); ?></button>
				<button class="mvweb-t-btn mvweb-t-btn--sm mvweb-t-btn--outline" type="button" data-city-no><?php esc_html_e( 'No', 'brand-market' ); ?></button>
			</div>
		</div>
	<?php endif; ?>
</div>
