<?php
/**
 * Zone element: Primary menu.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_context = isset( $args['context'] ) ? $args['context'] : 'bar';

if ( 'drawer' === $mvweb_context ) {
	mvweb_theme_drawer_nav( 'primary' );

	return;
}

mvweb_theme_bar_nav( 'primary', 'mvweb-t-el-menu-primary' );
