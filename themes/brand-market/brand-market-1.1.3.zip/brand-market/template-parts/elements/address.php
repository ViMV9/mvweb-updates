<?php
/**
 * Zone element: Address.
 *
 * In the mobile menu it is every place of the chosen city with its hours. In a
 * bar it is the first address in one line.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_context   = isset( $args['context'] ) ? $args['context'] : 'bar';
$mvweb_contacts  = mvweb_core_contacts();
$mvweb_addresses = mvweb_core_header_addresses( $mvweb_contacts );

if ( empty( $mvweb_addresses ) ) {
	return;
}

if ( 'drawer' !== $mvweb_context ) {
	get_template_part( 'template-parts/header/contacts/address', null, array( 'contacts' => $mvweb_contacts ) );

	return;
}
?>
<ul class="mvweb-t-el-address mvweb-t-drawer__addrs">
	<?php foreach ( $mvweb_addresses as $mvweb_address ) : ?>
		<?php $mvweb_hours = mvweb_core_hours_line( $mvweb_address['hours'] ); ?>
		<li>
			<?php echo mvweb_theme_icon( 'map-pin', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span>
				<?php echo esc_html( mvweb_core_address_text( $mvweb_address ) ); ?>
				<?php if ( '' !== $mvweb_hours ) : ?>
					<small><?php echo esc_html( $mvweb_hours ); ?></small>
				<?php endif; ?>
			</span>
		</li>
	<?php endforeach; ?>
</ul>
