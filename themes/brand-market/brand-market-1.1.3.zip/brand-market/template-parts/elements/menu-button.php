<?php
/**
 * Zone element: Menu button with a caption — opens the mobile menu where the menu row folds.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<button class="mvweb-t-el-menu-button mvweb-t-header__menubtn" type="button" data-drawer-open aria-expanded="false">
	<?php echo mvweb_theme_icon( 'menu', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<?php esc_html_e( 'Menu', 'brand-market' ); ?>
</button>
