<?php
/**
 * Zone element: Email, in the mobile menu.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_contacts = mvweb_core_contacts();
$mvweb_email    = (string) $mvweb_contacts['email'];

if ( ! is_email( $mvweb_email ) ) {
	return;
}
?>
<a class="mvweb-t-el-email mvweb-t-drawer__mail" href="<?php echo esc_url( 'mailto:' . $mvweb_email ); ?>">
	<?php echo mvweb_theme_icon( 'mail', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<?php echo esc_html( $mvweb_email ); ?>
</a>
