<?php
/**
 * Zone element: Other items of the header row.
 *
 * The place in the header row where the zone "Header row: other items" stands:
 * icons, cart, phone, hours and the rest, in the order set in that zone.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="mvweb-t-header__actions">
	<?php echo mvweb_theme_zone_html( 'header-actions' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped element templates. ?>
	<?php get_template_part( 'template-parts/elements/burger' ); ?>
</div>
