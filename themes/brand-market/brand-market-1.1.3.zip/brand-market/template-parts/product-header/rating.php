<?php
/**
 * Item header part: the rating and the number of reviews.
 *
 * A link to the reviews while they are on the page, plain text otherwise.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id     = isset( $args['id'] ) ? absint( $args['id'] ) : 0;
$mvweb_rating = mvweb_core_item_rating( $mvweb_id );

if ( empty( $mvweb_rating ) ) {
	return;
}

if ( empty( $args['state']['meta'] ) ) {
	echo '<div class="mvweb-t-product-meta">';
	$args['state']['meta'] = 1;
}

$mvweb_link = in_array( 'reviews', mvweb_core_product_sections( $mvweb_id ), true );
?>
<<?php echo $mvweb_link ? 'a href="#reviews"' : 'span'; ?> class="mvweb-t-rating">
	<?php echo mvweb_theme_icon( 'star-filled', array( 'class' => 'mvweb-t-icon--fill' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<?php echo esc_html( number_format_i18n( $mvweb_rating['value'], 1 ) ); ?>
	<span class="mvweb-t-rating__count">
		<?php
		/* translators: %s: number of reviews. */
		echo esc_html( sprintf( _n( '%s review', '%s reviews', $mvweb_rating['count'], 'brand-market' ), number_format_i18n( $mvweb_rating['count'] ) ) );
		?>
	</span>
</<?php echo $mvweb_link ? 'a' : 'span'; ?>>
