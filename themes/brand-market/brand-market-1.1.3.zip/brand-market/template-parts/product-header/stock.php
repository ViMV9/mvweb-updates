<?php
/**
 * Item header part: the availability, in the line under the name.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id    = isset( $args['id'] ) ? absint( $args['id'] ) : 0;
$mvweb_stock = $mvweb_id ? mvweb_core_item_stock( $mvweb_id ) : array();

if ( empty( $mvweb_stock['label'] ) ) {
	return;
}

$mvweb_icons = array(
	'instock'     => 'check',
	'onbackorder' => 'clock',
	'outofstock'  => 'close',
);
$mvweb_unit  = mvweb_core_qty_unit( $mvweb_id );
$mvweb_note  = 'instock' === $mvweb_stock['status'] ? trim( (string) mvweb_core_product_option( 'mvweb_stock_note' ) ) : '';

if ( empty( $args['state']['meta'] ) ) {
	echo '<div class="mvweb-t-product-meta">';
	$args['state']['meta'] = 1;
}
?>
<span class="<?php echo esc_attr( 'mvweb-t-product-stock mvweb-t-product-stock--' . sanitize_html_class( $mvweb_stock['status'] ) ); ?>">
	<span class="mvweb-t-product-stock__icon" aria-hidden="true"><?php echo mvweb_theme_icon( isset( $mvweb_icons[ $mvweb_stock['status'] ] ) ? $mvweb_icons[ $mvweb_stock['status'] ] : 'check', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
	<span class="mvweb-t-product-stock__text">
		<?php
		if ( null !== $mvweb_stock['qty'] ) {
			/* translators: 1: how many are in stock, 2: unit, for example pcs. */
			echo esc_html( sprintf( __( 'In stock, %1$d %2$s', 'brand-market' ), $mvweb_stock['qty'], '' !== $mvweb_unit ? $mvweb_unit : __( 'pcs', 'brand-market' ) ) );
		} else {
			echo esc_html( $mvweb_stock['label'] );
		}
		?>
	</span>
	<?php if ( '' !== $mvweb_note ) : ?>
		<span class="mvweb-t-product-stock__note"><?php echo esc_html( $mvweb_note ); ?></span>
	<?php endif; ?>
</span>
