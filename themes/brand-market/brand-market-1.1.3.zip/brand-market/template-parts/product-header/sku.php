<?php
/**
 * Item header part: the article.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_sku = isset( $args['id'] ) ? mvweb_core_item_sku( absint( $args['id'] ) ) : '';

if ( '' === $mvweb_sku ) {
	return;
}

if ( empty( $args['state']['meta'] ) ) {
	echo '<div class="mvweb-t-product-meta">';
	$args['state']['meta'] = 1;
}
?>
<span class="mvweb-t-product-sku" data-sku-format="<?php /* translators: %s: stock keeping unit. */ echo esc_attr( __( 'Art. %s', 'brand-market' ) ); ?>">
	<?php
	/* translators: %s: stock keeping unit. */
	echo esc_html( sprintf( __( 'Art. %s', 'brand-market' ), $mvweb_sku ) );
	?>
</span>
