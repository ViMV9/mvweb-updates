<?php
/**
 * Item header part: the name, the one heading of the page.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id    = isset( $args['id'] ) ? absint( $args['id'] ) : 0;
$mvweb_title = mvweb_core_alt_h1();

if ( '' === $mvweb_title ) {
	$mvweb_title = get_the_title( $mvweb_id );
}

if ( ! empty( $args['state']['meta'] ) ) {
	echo '</div>';
	$args['state']['meta'] = 0;
}
?>
<?php if ( (int) $GLOBALS['wp_the_query']->get_queried_object_id() === $mvweb_id ) : ?>
	<h1 class="mvweb-t-product-title"><?php echo esc_html( $mvweb_title ); ?></h1>
<?php else : ?>
	<div class="mvweb-t-product-title mvweb-t-h1"><?php echo esc_html( get_the_title( $mvweb_id ) ); ?></div>
<?php endif; ?>
