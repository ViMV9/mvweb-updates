<?php
/**
 * Item header part: the categories of the item as links.
 *
 * While the breadcrumbs carry the main category, this line lists the other
 * ones; without the category in the breadcrumbs it lists them all.
 *
 * @package MVweb_Theme
 *
 * @since 1.0.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_terms = isset( $args['id'] ) ? mvweb_core_item_categories( absint( $args['id'] ) ) : array();
$mvweb_other = get_theme_mod( 'mvweb_product_crumb_category', true ) && mvweb_core_layout_has( 'page-hero', 'crumbs' );

if ( $mvweb_other ) {
	array_shift( $mvweb_terms );
}

if ( empty( $mvweb_terms ) ) {
	return;
}

$mvweb_links = array();

foreach ( $mvweb_terms as $mvweb_term ) {
	$mvweb_url = get_term_link( $mvweb_term );

	if ( is_string( $mvweb_url ) ) {
		$mvweb_links[] = '<a href="' . esc_url( $mvweb_url ) . '">' . esc_html( $mvweb_term->name ) . '</a>';
	}
}

if ( empty( $mvweb_links ) ) {
	return;
}

if ( empty( $args['state']['meta'] ) ) {
	echo '<div class="mvweb-t-product-meta">';
	$args['state']['meta'] = 1;
}
?>
<span class="mvweb-t-product-cats">
	<?php
	echo esc_html( $mvweb_other ? __( 'Also in:', 'brand-market' ) : _n( 'Category:', 'Categories:', count( $mvweb_links ), 'brand-market' ) );
	echo ' ' . implode( ', ', $mvweb_links ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	?>
</span>
