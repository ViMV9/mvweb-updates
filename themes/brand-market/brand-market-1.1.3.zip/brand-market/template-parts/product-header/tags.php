<?php
/**
 * Item header, part: the tags of a WooCommerce product as links.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! mvweb_core_is_woocommerce() || empty( $args['id'] ) ) {
	return;
}

$mvweb_terms = get_the_terms( absint( $args['id'] ), 'product_tag' );

if ( empty( $mvweb_terms ) || is_wp_error( $mvweb_terms ) ) {
	return;
}

$mvweb_links = array();

foreach ( $mvweb_terms as $mvweb_term ) {
	$mvweb_url = get_term_link( $mvweb_term );

	if ( is_string( $mvweb_url ) ) {
		$mvweb_links[] = '<a href="' . esc_url( $mvweb_url ) . '">' . esc_html( $mvweb_term->name ) . '</a>';
	}
}

if ( empty( $mvweb_links ) ) {
	return;
}

if ( empty( $args['state']['meta'] ) ) {
	echo '<div class="mvweb-t-product-meta">';
	$args['state']['meta'] = 1;
}
?>
<span class="mvweb-t-product-cats mvweb-t-product-tags">
	<?php
	echo esc_html( _n( 'Tag:', 'Tags:', count( $mvweb_links ), 'brand-market' ) );
	echo ' ' . implode( ', ', $mvweb_links ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	?>
</span>
