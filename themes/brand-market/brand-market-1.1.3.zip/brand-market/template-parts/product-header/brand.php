<?php
/**
 * Item header part: the brand above the name.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_brand = isset( $args['id'] ) ? mvweb_core_item_brand( absint( $args['id'] ) ) : '';

if ( '' === $mvweb_brand ) {
	return;
}

if ( ! empty( $args['state']['meta'] ) ) {
	echo '</div>';
	$args['state']['meta'] = 0;
}
?>
<p class="mvweb-t-product-collection"><?php echo esc_html( $mvweb_brand ); ?></p>
