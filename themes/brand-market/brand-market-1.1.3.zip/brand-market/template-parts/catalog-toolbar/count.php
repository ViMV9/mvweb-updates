<?php
/**
 * Bar part: how many items the listing holds.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_total = (int) $GLOBALS['wp_query']->found_posts;

if ( $mvweb_total < 1 ) {
	return;
}

mvweb_core_listing_group( $args, '' );
?>
<p class="mvweb-t-toolbar__count">
	<?php
	/* translators: %s: number of items found. */
	echo esc_html( sprintf( _n( 'Found %s item', 'Found %s items', $mvweb_total, 'brand-market' ), number_format_i18n( $mvweb_total ) ) );
	?>
</p>
