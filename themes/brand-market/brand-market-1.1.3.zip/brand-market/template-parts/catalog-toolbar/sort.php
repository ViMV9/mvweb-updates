<?php
/**
 * Bar part: the sorting.
 *
 * A plain GET form: the filters of the request ride along as hidden fields,
 * and assets/js/filters.js submits the form on change.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_orderings = mvweb_core_catalog_orderings();

if ( count( $mvweb_orderings ) < 2 ) {
	return;
}

get_template_part( 'template-parts/catalog-toolbar/tools', null, $args );

$mvweb_order = mvweb_core_catalog_orderby();
?>
<form class="mvweb-t-sort" action="<?php echo esc_url( mvweb_core_catalog_url() ); ?>" method="get" data-sort>
	<?php foreach ( mvweb_core_catalog_query_args( array( 'orderby' ) ) as $mvweb_key => $mvweb_value ) : ?>
		<input type="hidden" name="<?php echo esc_attr( $mvweb_key ); ?>" value="<?php echo esc_attr( $mvweb_value ); ?>">
	<?php endforeach; ?>

	<label class="mvweb-t-sort__label" for="mvweb-t-sort-order"><?php esc_html_e( 'Sort by', 'brand-market' ); ?></label>
	<select class="mvweb-t-sort__select" id="mvweb-t-sort-order" name="orderby">
		<?php foreach ( $mvweb_orderings as $mvweb_key => $mvweb_label ) : ?>
			<option value="<?php echo esc_attr( $mvweb_key ); ?>" <?php selected( $mvweb_order, $mvweb_key ); ?>><?php echo esc_html( $mvweb_label ); ?></option>
		<?php endforeach; ?>
	</select>

	<noscript><button class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-btn--sm" type="submit"><?php esc_html_e( 'Apply', 'brand-market' ); ?></button></noscript>
</form>
