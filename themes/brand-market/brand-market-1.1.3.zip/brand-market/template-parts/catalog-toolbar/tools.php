<?php
/**
 * Bar part helper: the row of tools with the button that opens the filters.
 *
 * Not a part of the composition. The sorting and the look ask for the row;
 * the select of the subcategories for a phone and the button stand first in it,
 * once, the button only where the sidebar exists.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! mvweb_core_listing_group( $args, 'mvweb-t-toolbar__tools' ) ) {
	return;
}

if ( isset( $args['state']['cats'] ) && ! $args['state']['cats'] ) {
	$args['state']['cats'] = true;
	get_template_part( 'template-parts/catalog/cats' );
}

if ( empty( $args['has_filters'] ) || $args['state']['toggle'] ) {
	return;
}

$args['state']['toggle'] = true;
?>
<button class="mvweb-t-filters__toggle" type="button" data-filters-toggle aria-expanded="false" aria-controls="mvweb-t-filters-form">
	<?php echo mvweb_theme_icon( 'adjustments-horizontal', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<span><?php echo esc_html_x( 'Filter', 'button that opens the filters', 'brand-market' ); ?></span>
</button>
