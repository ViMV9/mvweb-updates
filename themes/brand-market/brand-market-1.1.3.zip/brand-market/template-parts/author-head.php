<?php
/**
 * Heading of the archive of an author: the picture beside the name, the description and the facts.
 *
 * The parts stand in the order the site sets for the area author-head; the
 * facts are gathered into one line. The crumbs, the label over the name and the
 * name are those of every heading of the site.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_author = isset( $args['author'] ) ? absint( $args['author'] ) : 0;
$mvweb_title  = isset( $args['title'] ) ? (string) $args['title'] : '';
$mvweb_parts  = mvweb_core_blog_layout_html( 'author-head', array( 'author' => $mvweb_author ) );
$mvweb_avatar = isset( $mvweb_parts['avatar'] ) ? $mvweb_parts['avatar'] : '';
$mvweb_text   = '';
$mvweb_facts  = '';

unset( $mvweb_parts['avatar'] );

foreach ( $mvweb_parts as $mvweb_slug => $mvweb_html ) {
	if ( in_array( $mvweb_slug, array( 'count', 'since' ), true ) ) {
		$mvweb_facts .= $mvweb_html;
		continue;
	}

	if ( '' !== $mvweb_facts ) {
		$mvweb_text .= '<p class="mvweb-t-page-hero__meta">' . $mvweb_facts . '</p>';
		$mvweb_facts = '';
	}

	$mvweb_text .= $mvweb_html;
}

if ( '' !== $mvweb_facts ) {
	$mvweb_text .= '<p class="mvweb-t-page-hero__meta">' . $mvweb_facts . '</p>';
}
?>
<section class="mvweb-t-page-hero">
	<div class="mvweb-t-container">
		<?php if ( mvweb_core_layout_has( 'page-hero', 'crumbs' ) ) : ?>
			<?php get_template_part( 'template-parts/crumbs' ); ?>
		<?php endif; ?>

		<div class="mvweb-t-author-head">
			<?php echo $mvweb_avatar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template. ?>
			<div class="mvweb-t-author-head__text">
				<?php if ( mvweb_core_blog_hero_has( 'eyebrow' ) ) : ?>
					<p class="mvweb-t-page-hero__eyebrow"><?php esc_html_e( 'Author', 'brand-market' ); ?></p>
				<?php endif; ?>
				<h1 class="mvweb-t-page-hero__title"><?php echo esc_html( $mvweb_title ); ?></h1>
				<?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?>
			</div>
		</div>
	</div>
</section>
