<?php
/**
 * The purchase bar at the bottom of a phone screen: the total and "Add to cart".
 *
 * The button sends the add to cart form of the page, so the quantity chosen
 * there goes with it. Printed in the look "purchase bar" for a product that can
 * go to the cart as it is.
 *
 * Arguments: id.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id   = isset( $args['id'] ) ? absint( $args['id'] ) : 0;
$mvweb_data = mvweb_core_buy_data( $mvweb_id );

if ( empty( $mvweb_data ) ) {
	return;
}

$mvweb_product = mvweb_core_wc_item( $mvweb_id );
$mvweb_qty     = (int) $mvweb_data['min'];
?>
<div class="mvweb-t-buybar" data-buybar>
	<div class="mvweb-t-buybar__price">
		<b class="mvweb-t-buybar__sum" data-buy-sum><?php echo esc_html( wp_strip_all_tags( wc_price( mvweb_core_buy_unit( $mvweb_data, $mvweb_qty ) * $mvweb_qty ) ) ); ?></b>
		<span class="mvweb-t-buybar__note"><?php esc_html_e( 'In stock', 'brand-market' ); ?></span>
	</div>
	<button class="mvweb-t-btn mvweb-t-buybar__add" type="submit" form="<?php echo esc_attr( 'mvweb-t-cart-' . $mvweb_id ); ?>" name="add-to-cart" value="<?php echo (int) $mvweb_id; ?>">
		<?php echo mvweb_theme_icon( 'shopping-cart', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<?php echo esc_html( $mvweb_product->single_add_to_cart_text() ); ?>
	</button>
</div>
