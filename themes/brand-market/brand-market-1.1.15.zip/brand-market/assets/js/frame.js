( function () {
	"use strict";

	const entry = history.length;

	document.addEventListener( "click", function ( event ) {
		const back = event.target.closest( "[data-back]" );
		let from = null;

		if ( ! back || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey ) {
			return;
		}

		try {
			from = new URL( document.referrer );
		} catch ( e ) {
			return;
		}

		if ( from.origin === location.origin && from.pathname !== location.pathname && history.length > 1 ) {
			event.preventDefault();
			history.go( Math.min( -1, entry - history.length - 1 ) );
		}
	} );

	document.querySelectorAll( "[data-nav-select]" ).forEach( function ( select ) {
		select.addEventListener( "change", function () {
			if ( select.value ) {
				location.assign( select.value );
			}
		} );
	} );

	document.querySelectorAll( "[data-tab-select]" ).forEach( function ( form ) {
		const select = form.querySelector( "select" );

		if ( select ) {
			select.addEventListener( "change", function () {
				form.requestSubmit();
			} );
		}
	} );

	document.querySelectorAll( "[data-subcats-more]" ).forEach( function ( button ) {
		button.addEventListener( "click", function () {
			const box = button.closest( "[data-subcats]" );
			const first = box.querySelector( "[data-extra]" );

			box.setAttribute( "data-open", "" );
			button.remove();

			if ( first ) {
				first.focus();
			}
		} );
	} );

	document.querySelectorAll( "[data-subcats-next]" ).forEach( function ( button ) {
		const track = button.parentElement.querySelector( "[data-subcats-track]" );

		if ( ! track ) {
			return;
		}

		function sync() {
			button.hidden = track.scrollLeft + track.clientWidth >= track.scrollWidth - 1;
		}

		button.addEventListener( "click", function () {
			track.scrollBy( { left: track.clientWidth * 0.75 } );
		} );
		track.addEventListener( "scroll", sync, { passive: true } );
		new ResizeObserver( sync ).observe( track );
	} );

	document.querySelectorAll( "[data-search-filters]" ).forEach( function ( button ) {
		const aside = document.getElementById( button.getAttribute( "aria-controls" ) );

		if ( ! aside ) {
			return;
		}

		const toggle = function ( open ) {
			aside.toggleAttribute( "data-open", open );
			button.setAttribute( "aria-expanded", open ? "true" : "false" );
		};

		button.toggleAttribute( "data-ready", true );
		button.addEventListener( "click", function () {
			toggle( ! aside.hasAttribute( "data-open" ) );
		} );
		document.addEventListener( "keydown", function ( event ) {
			if ( "Escape" === event.key && aside.hasAttribute( "data-open" ) ) {
				toggle( false );
				button.focus();
			}
		} );
	} );

	document.querySelectorAll( "[data-whole]" ).forEach( function ( line ) {
		const box = line.closest( "[data-buy]" );
		const input = box ? box.querySelector( "input[name='quantity']:not([type='hidden'])" ) : null;
		let whole;
		let buy;

		try {
			whole = JSON.parse( line.getAttribute( "data-whole" ) );
			buy = JSON.parse( box.getAttribute( "data-buy" ) );
		} catch ( e ) {
			return;
		}

		if ( ! input || ! buy.money ) {
			return;
		}

		function money( amount ) {
			const parts = amount.toFixed( buy.money.decimals ).split( "." );
			const int = parts[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, buy.money.thousands );

			return buy.money.format.replace( "%s", parts[ 1 ] ? int + buy.money.point + parts[ 1 ] : int );
		}

		function sync() {
			const left = Number( ( whole.from - whole.cart - whole.price * Math.max( 0, parseFloat( input.value ) || 0 ) ).toFixed( 6 ) );
			const cents = Math.pow( 10, buy.money.decimals );

			line.classList.toggle( "mvweb-t-product-total__whole--on", left <= 0 );
			line.textContent = left > 0 ? line.getAttribute( "data-more" ).replace( "%s", money( Math.ceil( left * cents ) / cents ) ) : line.getAttribute( "data-done" );
		}

		box.addEventListener( "input", sync );
		box.addEventListener( "change", sync );
		box.addEventListener( "click", function () {
			setTimeout( sync );
		} );

		if ( window.jQuery ) {
			window.jQuery( document.body ).on( "added_to_cart", function ( event, fragments, hash, button ) {
				if ( button && button[ 0 ] && ! box.contains( button[ 0 ] ) ) {
					return;
				}

				whole.cart += whole.price * Math.max( 0, parseFloat( input.value ) || 0 );
				sync();
			} );
		}
	} );

	document.querySelectorAll( "[data-places]" ).forEach( function ( box ) {
		const toggle = box.querySelector( "[data-places-toggle]" );
		const pop = box.querySelector( "[data-places-pop]" );

		function show( open ) {
			pop.hidden = ! open;
			toggle.setAttribute( "aria-expanded", String( open ) );
		}

		toggle.addEventListener( "click", function () {
			show( pop.hidden );
		} );

		document.addEventListener( "click", function ( event ) {
			if ( ! pop.hidden && ! box.contains( event.target ) ) {
				show( false );
			}
		} );

		box.addEventListener( "keydown", function ( event ) {
			if ( "Escape" === event.key && ! pop.hidden ) {
				show( false );
				toggle.focus();
			}
		} );
	} );

	document.querySelectorAll( "[data-store]" ).forEach( function ( box ) {
		const curs = box.querySelectorAll( "[data-store-cur]" );
		const items = box.querySelectorAll( "[data-store-item]" );
		let saved = null;

		function pick( index ) {
			curs.forEach( function ( cur, n ) {
				cur.hidden = n !== index;
			} );

			items.forEach( function ( item, n ) {
				item.querySelector( "[data-store-mine]" ).hidden = n !== index;
				item.querySelector( "[data-store-pick]" ).hidden = n === index;
			} );
		}

		try {
			saved = localStorage.getItem( "mvweb-store" );
		} catch ( e ) {}

		items.forEach( function ( item, index ) {
			if ( item.dataset.storeItem === saved ) {
				pick( index );
			}

			item.querySelector( "[data-store-pick]" ).addEventListener( "click", function () {
				pick( index );

				try {
					localStorage.setItem( "mvweb-store", item.dataset.storeItem );
				} catch ( e ) {}

				box.querySelector( "[data-places-toggle]" ).click();
				box.querySelector( "[data-places-toggle]" ).focus();
			} );
		} );
	} );

	document.querySelectorAll( "[data-places-tabs]" ).forEach( function ( box ) {
		const tabs = Array.from( box.querySelectorAll( "[role=tab]" ) );

		function pick( tab ) {
			tabs.forEach( function ( item ) {
				const on = item === tab;

				item.setAttribute( "aria-selected", String( on ) );
				item.tabIndex = on ? 0 : -1;
				document.getElementById( item.getAttribute( "aria-controls" ) ).hidden = ! on;
			} );
		}

		tabs.forEach( function ( tab, index ) {
			tab.addEventListener( "click", function () {
				pick( tab );
			} );

			tab.addEventListener( "keydown", function ( event ) {
				const step = { ArrowRight: 1, ArrowLeft: -1 }[ event.key ];

				if ( step ) {
					const next = tabs[ ( index + step + tabs.length ) % tabs.length ];

					pick( next );
					next.focus();
				}
			} );
		} );
	} );

	document.querySelectorAll( "[data-places-m]" ).forEach( function ( box ) {
		const mode = box.getAttribute( "data-places-m" );
		const panels = Array.from( box.querySelectorAll( "[data-place-panel]" ) );
		const items = Array.from( box.querySelectorAll( "[data-place]" ) );
		const sheet = box.querySelector( "[data-places-sheet]" );
		const prev = box.querySelector( "[data-places-prev]" );
		const next = box.querySelector( "[data-places-next]" );
		let current = 0;

		function show( index ) {
			current = index;
			panels.forEach( function ( panel, k ) {
				panel.hidden = k !== index;
			} );

			if ( "open" === mode ) {
				items.forEach( function ( item, k ) {
					item.hidden = k === index;
				} );
			}

			box.querySelectorAll( "[data-places-name]" ).forEach( function ( name ) {
				name.textContent = panels[ index ].getAttribute( "data-name" );
			} );
			box.querySelectorAll( "[data-places-pos]" ).forEach( function ( pos ) {
				pos.textContent = pos.getAttribute( "data-places-pos" ).replace( "%1$s", index + 1 ).replace( "%2$s", panels.length );
			} );
			box.querySelectorAll( "[data-places-dot]" ).forEach( function ( dot, k ) {
				dot.toggleAttribute( "aria-current", k === index );
			} );
			box.querySelectorAll( "[data-places-go]" ).forEach( function ( option, k ) {
				option.setAttribute( "aria-pressed", String( k === index ) );
			} );

			if ( prev ) {
				const lost = document.activeElement;

				prev.disabled = 0 === index;
				next.disabled = panels.length - 1 === index;

				if ( lost === prev && prev.disabled ) {
					next.focus();
				} else if ( lost === next && next.disabled ) {
					prev.focus();
				}
			}
		}

		if ( sheet ) {
			box.querySelector( "[data-places-pick]" ).addEventListener( "click", function () {
				sheet.showModal();
			} );
			sheet.addEventListener( "click", function ( event ) {
				const option = event.target.closest( "[data-places-go]" );

				if ( option ) {
					show( parseInt( option.getAttribute( "data-places-go" ), 10 ) );
					sheet.close();
				} else if ( event.target === sheet ) {
					sheet.close();
				}
			} );
		}

		if ( prev ) {
			let start = null;
			let startY = 0;

			prev.addEventListener( "click", function () {
				show( Math.max( 0, current - 1 ) );
			} );
			next.addEventListener( "click", function () {
				show( Math.min( panels.length - 1, current + 1 ) );
			} );
			box.addEventListener( "touchstart", function ( event ) {
				start = event.touches[ 0 ].clientX;
				startY = event.touches[ 0 ].clientY;
			}, { passive: true } );
			box.addEventListener( "touchend", function ( event ) {
				const shift = null === start ? 0 : event.changedTouches[ 0 ].clientX - start;
				const drop = event.changedTouches[ 0 ].clientY - startY;

				if ( Math.abs( shift ) > 50 && Math.abs( shift ) > Math.abs( drop ) ) {
					show( Math.min( panels.length - 1, Math.max( 0, current + ( shift < 0 ? 1 : -1 ) ) ) );
				}

				start = null;
			} );
		}

		const rows = panels.length ? panels : items;
		const count = box.querySelector( "[data-places-count]" );

		function opened() {
			return rows.filter( function ( row ) {
				return row.querySelector( "[data-open=true]" );
			} );
		}

		function recount() {
			if ( count && rows.some( function ( row ) {
				return row.querySelector( "[data-open]" );
			} ) ) {
				count.textContent = count.getAttribute( "data-places-count" ).replace( "%1$s", opened().length ).replace( "%2$s", rows.length );
				count.hidden = false;
			}
		}

		window.addEventListener( "load", function () {
			const open = opened();

			recount();
			window.setInterval( recount, 60000 );

			if ( "open" === mode && open.length ) {
				show( panels.indexOf( open[ 0 ] ) );
				box.querySelector( "[data-places-badge]" ).hidden = false;
			}
		} );
	} );

	document.querySelectorAll( ".mvweb-t-sidebar" ).forEach( function ( aside ) {
		new ResizeObserver( function () {
			aside.style.setProperty( "--mvweb-t-aside-h", aside.offsetHeight + "px" );
		} ).observe( aside );
	} );
} )();
