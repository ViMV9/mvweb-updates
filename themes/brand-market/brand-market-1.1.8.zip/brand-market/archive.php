<?php
/**
 * Archive: category, tag, author, date.
 *
 * A category and a tag print the label, the description and the facts of the
 * heading that the Customizer leaves on; a category also prints its
 * subcategories in the look of the Customizer, or the strip of categories,
 * and the text kept in the category. An author has a heading of his
 * own, a month, a year and a day print the strip of months.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_title   = mvweb_core_alt_h1();
$mvweb_hero    = array();
$mvweb_chips   = '';
$mvweb_text    = '';
$mvweb_author  = is_author() ? get_queried_object_id() : 0;
$mvweb_eyebrow = '';

if ( is_category() ) {
	$mvweb_chips = array() === mvweb_core_blog_subcats() ? 'topics' : '';
	$mvweb_text  = is_paged() ? '' : mvweb_core_term_text( get_queried_object_id() );
	$mvweb_title = '' !== $mvweb_title ? $mvweb_title : single_cat_title( '', false );
} elseif ( is_tag() ) {
	$mvweb_eyebrow = __( 'Tag', 'brand-market' );
	$mvweb_title   = '' !== $mvweb_title ? $mvweb_title : single_tag_title( '', false );
} elseif ( is_author() ) {
	$mvweb_title = '' !== $mvweb_title ? $mvweb_title : get_the_author_meta( 'display_name', $mvweb_author );
} elseif ( is_date() ) {
	$mvweb_chips = 'months';
	$mvweb_title = '' !== $mvweb_title ? $mvweb_title : mvweb_core_blog_date_title();
}

if ( '' === $mvweb_title ) {
	$mvweb_title = wp_strip_all_tags( get_the_archive_title() );
}

if ( ! is_author() ) {
	$mvweb_hero = array(
		'title'   => $mvweb_title,
		'eyebrow' => mvweb_core_blog_hero_has( 'eyebrow' ) ? $mvweb_eyebrow : '',
		'lead'    => mvweb_core_blog_hero_has( 'lead' ) && ! is_paged() ? wp_strip_all_tags( get_the_archive_description() ) : '',
		'meta'    => mvweb_core_blog_hero_has( 'meta' ) ? mvweb_core_blog_archive_facts() : array(),
	);
}

$mvweb_column = 'author' === mvweb_core_sidebar_area() ? 'author' : 'blog';

get_header();

mvweb_theme_column_open( $mvweb_column );

if ( is_author() ) {
	get_template_part(
		'template-parts/author-head',
		null,
		array(
			'author' => $mvweb_author,
			'title'  => $mvweb_title,
		)
	);
} else {
	get_template_part( 'template-parts/page-hero', null, $mvweb_hero );
}

if ( is_category() && '' === $mvweb_chips ) {
	get_template_part(
		'template-parts/catalog/subcats',
		null,
		array(
			'tiles' => mvweb_core_blog_subcats(),
			'view'  => mvweb_core_blog_subcats_view(),
			'limit' => count( mvweb_core_blog_subcats() ),
			'label' => __( 'Subcategories', 'brand-market' ),
		)
	);
}

get_template_part(
	'template-parts/post-list',
	null,
	array(
		'chips'             => $mvweb_chips,
		'text'              => $mvweb_text,
		'empty_title'       => __( 'This section is empty', 'brand-market' ),
		'empty_text'        => __( 'There are no entries here yet. Have a look at the other sections.', 'brand-market' ),
		'empty_button_url'  => home_url( '/' ),
		'empty_button_text' => __( 'To the homepage', 'brand-market' ),
	)
);

mvweb_theme_column_close( $mvweb_column );

mvweb_core_render_context_sections();

get_footer();
