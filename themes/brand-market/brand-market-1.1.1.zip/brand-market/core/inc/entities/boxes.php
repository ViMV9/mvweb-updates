<?php
/**
 * Boxes: a grouped product sold whole, as one item of the cart.
 *
 * The box is a grouped product of WooCommerce marked as a box. It goes into the
 * cart and the order as one line at its own price: the sum of its products less
 * the discount. It is in stock while all its products are; an order takes their
 * stock down and a cancelled one gives it back, and so counts the purchases of
 * the box against its limit.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_is_box' ) ) {
	/**
	 * Whether a product is a box.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product|int|null $product Product or its id.
	 *
	 * @return bool
	 */
	function mvweb_core_is_box( $product ) {
		$product = is_numeric( $product ) ? wc_get_product( (int) $product ) : $product;

		return $product instanceof WC_Product && $product->is_type( 'grouped' ) && 'yes' === $product->get_meta( '_mvweb_box' );
	}
}

if ( ! function_exists( 'mvweb_core_box_fits' ) ) {
	/**
	 * Whether a product can go into a box: a simple product, or a variation with every attribute set.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product|false|null $item Product.
	 *
	 * @return bool
	 */
	function mvweb_core_box_fits( $item ) {
		if ( ! $item instanceof WC_Product || 'publish' !== $item->get_status() ) {
			return false;
		}

		if ( $item->is_type( 'variation' ) ) {
			$attributes = $item->get_variation_attributes();

			return 'publish' === get_post_status( $item->get_parent_id() ) && count( array_filter( $attributes, 'wc_array_filter_default_attributes' ) ) === count( $attributes );
		}

		return $item->is_type( 'simple' );
	}
}

if ( ! function_exists( 'mvweb_core_box_items' ) ) {
	/**
	 * The products of a box that can be bought.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Box.
	 *
	 * @return WC_Product[]
	 */
	function mvweb_core_box_items( $product ) {
		$items = array();

		foreach ( $product->get_children() as $child ) {
			$item = wc_get_product( $child );

			if ( mvweb_core_box_fits( $item ) ) {
				$items[] = $item;
			}
		}

		return $items;
	}
}

if ( ! function_exists( 'mvweb_core_box_labels' ) ) {
	/**
	 * The names of the products of a box, a variation with its choice.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Box.
	 *
	 * @return string[]
	 */
	function mvweb_core_box_labels( $product ) {
		$names = array();

		foreach ( mvweb_core_box_items( $product ) as $item ) {
			$name = $item->get_name();

			if ( $item->is_type( 'variation' ) ) {
				$choice = wc_get_formatted_variation( $item, true, false );
				$name   = '' !== $choice && false === strpos( $name, $choice ) ? $name . ' (' . $choice . ')' : $name;
			}

			$names[] = $name;
		}

		return $names;
	}
}

if ( ! function_exists( 'mvweb_core_box_names' ) ) {
	/**
	 * What a box holds, in words: for a cart line and an order line.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Box.
	 *
	 * @return string
	 */
	function mvweb_core_box_names( $product ) {
		return implode( ', ', mvweb_core_box_labels( $product ) );
	}
}

if ( ! function_exists( 'mvweb_core_box_list' ) ) {
	/**
	 * What a box holds, as a list under its line in the cart.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Box.
	 *
	 * @return string
	 */
	function mvweb_core_box_list( $product ) {
		$items = '';

		foreach ( mvweb_core_box_labels( $product ) as $name ) {
			$items .= '<li>' . esc_html( $name ) . '</li>';
		}

		return '<ul class="mvweb-t-box-parts">' . $items . '</ul>';
	}
}

if ( ! function_exists( 'mvweb_core_box_badge' ) ) {
	/**
	 * The discount badge of a box card: where it stands, its text and its colours, as the row of the block sets them.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Box.
	 * @param array      $row     Row of the block: badge, badge_shape, badge_bg, badge_ink.
	 *
	 * @return array{place:string,shape:string,text:string,style:string}|array{} Empty when the row has no badge or the box no discount.
	 */
	function mvweb_core_box_badge( $product, array $row ) {
		$place    = isset( $row['badge'] ) ? (string) $row['badge'] : '';
		$discount = mvweb_core_box_discount( $product );

		if ( ! isset( mvweb_core_box_badge_places()[ $place ] ) || '' === $place || $discount <= 0 ) {
			return array();
		}

		if ( 'percent' === $product->get_meta( '_mvweb_box_type' ) ) {
			$text = wc_format_localized_decimal( min( 100, (float) mvweb_core_sanitize_amount( $product->get_meta( '_mvweb_box_amount' ) ) ) ) . '%';
		} else {
			$sum  = wc_get_price_to_display( $product, array( 'price' => $discount ) );
			$text = html_entity_decode( wp_strip_all_tags( wc_price( $sum, array( 'decimals' => floor( $sum ) === (float) $sum ? 0 : wc_get_price_decimals() ) ) ), ENT_QUOTES, 'UTF-8' );
		}

		$bg    = mvweb_core_colour_css( isset( $row['badge_bg'] ) ? $row['badge_bg'] : '', true );
		$ink   = mvweb_core_colour_css( isset( $row['badge_ink'] ) ? $row['badge_ink'] : '' );
		$style = '';

		if ( $bg ) {
			$style .= '--mvweb-t-box-badge-bg:' . $bg['bg'] . ';--mvweb-t-box-badge-ink:' . $bg['ink'] . ';';
		}

		if ( $ink ) {
			$style .= '--mvweb-t-box-badge-ink:' . $ink['bg'] . ';';
		}

		$shape = isset( $row['badge_shape'] ) ? (string) $row['badge_shape'] : '';

		return array(
			'place' => $place,
			'shape' => isset( mvweb_core_box_badge_shapes()[ $shape ] ) ? $shape : 'pill',
			'text'  => '−' . $text,
			'style' => $style,
		);
	}
}

if ( ! function_exists( 'mvweb_core_box_badge_shapes' ) ) {
	/**
	 * The shapes of the discount badge of a box card; the theme draws each.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Shape => name.
	 */
	function mvweb_core_box_badge_shapes() {
		return array(
			'pill'   => __( 'Oval', 'mvweb-core' ),
			'plate'  => __( 'Plate', 'mvweb-core' ),
			'round'  => __( 'Circle', 'mvweb-core' ),
			'star'   => __( 'Star', 'mvweb-core' ),
			'ribbon' => __( 'Ribbon', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_box_badge_places' ) ) {
	/**
	 * Where the discount badge of a box card may stand.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Place => name; empty place means no badge.
	 */
	function mvweb_core_box_badge_places() {
		return array(
			''             => __( 'Not shown', 'mvweb-core' ),
			'top-start'    => __( 'Top left', 'mvweb-core' ),
			'top-end'      => __( 'Top right', 'mvweb-core' ),
			'bottom-start' => __( 'Bottom left', 'mvweb-core' ),
			'bottom-end'   => __( 'Bottom right', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_box_sum' ) ) {
	/**
	 * What the products of a box cost one by one: at their regular prices, or at the prices they sell at now.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Box.
	 * @param bool       $now     Whether to take the price a product sells at now, a sale price included.
	 *
	 * @return float
	 */
	function mvweb_core_box_sum( $product, $now = false ) {
		$sum = 0.0;

		foreach ( mvweb_core_box_items( $product ) as $item ) {
			$sum += (float) ( $now || '' === (string) $item->get_regular_price() ? $item->get_price() : $item->get_regular_price() );
		}

		return $sum;
	}
}

if ( ! function_exists( 'mvweb_core_box_discount' ) ) {
	/**
	 * The discount of a box in money: the sum as typed, or the share of the regular price of its products.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Box.
	 *
	 * @return float
	 */
	function mvweb_core_box_discount( $product ) {
		$amount = (float) mvweb_core_sanitize_amount( $product->get_meta( '_mvweb_box_amount' ) );

		if ( 'percent' === $product->get_meta( '_mvweb_box_type' ) ) {
			$amount = mvweb_core_box_sum( $product ) * min( 100, $amount ) / 100;
		}

		return round( max( 0, $amount ), wc_get_price_decimals() );
	}
}

if ( ! function_exists( 'mvweb_core_box_parts' ) ) {
	/**
	 * The products a line of an order holds as a box: the ones fixed when the order was made, or the box has now.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Order_Item_Product $item Order line.
	 *
	 * @return int[]
	 */
	function mvweb_core_box_parts( $item ) {
		$ids = $item->get_meta( '_mvweb_box_parts', true );

		if ( is_array( $ids ) && array() !== $ids ) {
			return array_map( 'absint', $ids );
		}

		$box = $item->get_product();

		return mvweb_core_is_box( $box ) ? array_map(
			static function ( $part ) {
				return $part->get_id();
			},
			mvweb_core_box_items( $box )
		) : array();
	}
}

if ( ! function_exists( 'mvweb_core_box_held' ) ) {
	/**
	 * Boxes and their products that orders waiting for payment hold, while WooCommerce holds stock for them.
	 *
	 * @since 0.1.0
	 *
	 * @return array{boxes:array<int,int>,parts:array<int,int>} Box id => boxes; id that keeps the stock => pieces.
	 */
	function mvweb_core_box_held() {
		static $held = null;

		if ( null !== $held ) {
			return $held;
		}

		$held    = array(
			'boxes' => array(),
			'parts' => array(),
		);
		$minutes = absint( get_option( 'woocommerce_hold_stock_minutes' ) );

		if ( 0 === $minutes || 'yes' !== get_option( 'woocommerce_manage_stock' ) ) {
			return $held;
		}

		$own    = WC()->session ? absint( WC()->session->get( 'order_awaiting_payment' ) ) : 0;
		$orders = wc_get_orders(
			array(
				'status'       => array( 'pending', 'checkout-draft' ),
				'date_created' => '>' . ( time() - $minutes * MINUTE_IN_SECONDS ),
				'exclude'      => $own ? array( $own ) : array(),
				'limit'        => -1,
			)
		);

		foreach ( $orders as $order ) {
			foreach ( $order->get_items() as $item ) {
				$box = $item->get_product();

				if ( ! mvweb_core_is_box( $box ) ) {
					continue;
				}

				$quantity                        = (int) $item->get_quantity();
				$held['boxes'][ $box->get_id() ] = ( isset( $held['boxes'][ $box->get_id() ] ) ? $held['boxes'][ $box->get_id() ] : 0 ) + $quantity;

				foreach ( mvweb_core_box_parts( $item ) as $id ) {
					$part = wc_get_product( $id );

					if ( $part ) {
						$key                   = $part->get_stock_managed_by_id();
						$held['parts'][ $key ] = ( isset( $held['parts'][ $key ] ) ? $held['parts'][ $key ] : 0 ) + $quantity;
					}
				}
			}
		}

		return $held;
	}
}

if ( ! function_exists( 'mvweb_core_box_free' ) ) {
	/**
	 * The stock of a product left for a new purchase: less what orders waiting for payment hold.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $part Product of a box.
	 *
	 * @return int
	 */
	function mvweb_core_box_free( $part ) {
		$held = mvweb_core_box_held()['parts'];
		$key  = $part->get_stock_managed_by_id();
		$own  = WC()->session ? absint( WC()->session->get( 'order_awaiting_payment' ) ) : 0;

		return (int) $part->get_stock_quantity() - wc_get_held_stock_quantity( $part, $own ) - ( isset( $held[ $key ] ) ? $held[ $key ] : 0 );
	}
}

if ( ! function_exists( 'mvweb_core_box_room' ) ) {
	/**
	 * How many boxes the stock of their products and the limit of purchases still allow.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Box.
	 * @param bool       $hold    Whether to leave out what orders waiting for payment hold.
	 *
	 * @return int|null Null: no bound.
	 */
	function mvweb_core_box_room( $product, $hold = false ) {
		$room  = null;
		$use   = array();
		$limit = absint( $product->get_meta( '_mvweb_box_limit' ) );
		$held  = $hold ? mvweb_core_box_held()['boxes'] : array();

		foreach ( mvweb_core_box_items( $product ) as $item ) {
			if ( $item->managing_stock() && ! $item->backorders_allowed() ) {
				$key         = $item->get_stock_managed_by_id();
				$use[ $key ] = array( $hold ? mvweb_core_box_free( $item ) : (int) $item->get_stock_quantity(), ( isset( $use[ $key ] ) ? $use[ $key ][1] : 0 ) + 1 );
			}
		}

		foreach ( $use as $pair ) {
			$room = min( null === $room ? PHP_INT_MAX : $room, intdiv( max( 0, $pair[0] ), $pair[1] ) );
		}

		if ( $limit > 0 ) {
			$room = min( null === $room ? PHP_INT_MAX : $room, $limit - absint( $product->get_meta( '_mvweb_box_sold' ) ) - ( isset( $held[ $product->get_id() ] ) ? $held[ $product->get_id() ] : 0 ) );
		}

		return null === $room ? null : max( 0, $room );
	}
}

if ( ! function_exists( 'mvweb_core_box_state' ) ) {
	/**
	 * What a box offers now.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product|int $product Box or its id.
	 *
	 * @return array{active:bool,reason:string,sum:float,discount:float,price:float,until:int,left:int|null,items:WC_Product[]}
	 */
	function mvweb_core_box_state( $product ) {
		static $memo = array();

		$product = is_numeric( $product ) ? wc_get_product( (int) $product ) : $product;

		if ( ! $product instanceof WC_Product ) {
			return mvweb_core_box_state_now( $product );
		}

		$key = implode( '-', array( $product->get_id(), $product->get_status(), did_action( 'woocommerce_reduce_order_stock' ), did_action( 'woocommerce_restore_order_stock' ), did_action( 'woocommerce_product_set_stock' ), did_action( 'woocommerce_variation_set_stock' ) ) );

		if ( ! isset( $memo[ $key ] ) ) {
			$memo[ $key ] = mvweb_core_box_state_now( $product );
		}

		return $memo[ $key ];
	}
}

if ( ! function_exists( 'mvweb_core_box_state_now' ) ) {
	/**
	 * What a box offers now, counted afresh.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product|null $product Box.
	 *
	 * @return array{active:bool,reason:string,sum:float,discount:float,price:float,until:int,left:int|null,items:WC_Product[]}
	 */
	function mvweb_core_box_state_now( $product ) {
		$state = array(
			'active'   => false,
			'reason'   => 'off',
			'sum'      => 0.0,
			'discount' => 0.0,
			'price'    => 0.0,
			'until'    => 0,
			'left'     => null,
			'items'    => array(),
		);

		if ( ! mvweb_core_is_box( $product ) ) {
			return $state;
		}

		$until    = (string) $product->get_meta( '_mvweb_box_until' );
		$expires  = '' !== $until ? date_create_immutable( $until, wp_timezone() ) : false;
		$limit    = absint( $product->get_meta( '_mvweb_box_limit' ) );
		$discount = mvweb_core_box_discount( $product );

		$state['items'] = mvweb_core_box_items( $product );
		$state['sum']   = mvweb_core_box_sum( $product );
		$state['price'] = $state['sum'];
		$state['until'] = $expires ? $expires->getTimestamp() : 0;
		$state['left']  = $limit > 0 ? max( 0, $limit - absint( $product->get_meta( '_mvweb_box_sold' ) ) ) : null;

		if ( 'publish' !== $product->get_status() ) {
			return $state;
		}

		$state['reason'] = 'items';

		if ( count( $state['items'] ) < 2 || count( $state['items'] ) !== count( $product->get_children() ) ) {
			return $state;
		}

		foreach ( $state['items'] as $item ) {
			if ( mvweb_core_quantity_rules( mvweb_core_product_parent( $item ) )['min'] > 1 ) {
				return $state;
			}
		}

		$state['reason'] = 'stock';

		foreach ( $state['items'] as $item ) {
			if ( ! $item->is_in_stock() || ! $item->is_purchasable() ) {
				return $state;
			}
		}

		$checks = array(
			'ended'     => $state['until'] && time() > $state['until'],
			'sold'      => 0 === $state['left'],
			'wholesale' => $discount > 0 && get_theme_mod( 'mvweb_wholesale', false ) && mvweb_core_is_wholesaler(),
		);

		foreach ( $checks as $reason => $failed ) {
			if ( $failed ) {
				$state['reason'] = $reason;

				return $state;
			}
		}

		if ( $discount >= $state['sum'] ) {
			$state['reason'] = 'price';

			return $state;
		}

		if ( $discount > 0 && mvweb_core_box_sum( $product, true ) <= $state['sum'] - $discount ) {
			$state['reason'] = 'sale';

			return $state;
		}

		$state['discount'] = $discount;
		$state['price']    = $state['sum'] - $discount;
		$state['active']   = true;
		$state['reason']   = '';

		return $state;
	}
}

if ( ! function_exists( 'mvweb_core_box_reason' ) ) {
	/**
	 * Why a box is not on sale, in words for the editor.
	 *
	 * @since 0.1.0
	 *
	 * @param string $reason Reason from mvweb_core_box_state().
	 *
	 * @return string
	 */
	function mvweb_core_box_reason( $reason ) {
		$texts = array(
			''          => __( 'On sale.', 'mvweb-core' ),
			'off'       => __( 'Not on sale: the box is not published.', 'mvweb-core' ),
			'items'     => __( 'Not on sale: a product of the box is gone, unpublished, has variations or is sold from more than one piece.', 'mvweb-core' ),
			'stock'     => __( 'Not on sale: a product of the box is out of stock.', 'mvweb-core' ),
			'ended'     => __( 'Not on sale: the sale has ended.', 'mvweb-core' ),
			'sold'      => __( 'Not on sale: all the purchases are made.', 'mvweb-core' ),
			'price'     => __( 'Not on sale: the discount is not less than the price of the products.', 'mvweb-core' ),
			'sale'      => __( 'Not on sale: the products cost less on their own sale than in the box.', 'mvweb-core' ),
			'wholesale' => __( 'Not on sale for a wholesale customer.', 'mvweb-core' ),
		);

		return isset( $texts[ $reason ] ) ? $texts[ $reason ] : '';
	}
}

if ( ! function_exists( 'mvweb_core_boxes' ) ) {
	/**
	 * Boxes on sale now.
	 *
	 * @since 0.1.0
	 *
	 * @param int[] $ids   Boxes chosen by hand; empty for every box on sale.
	 * @param int   $limit How many at most.
	 *
	 * @return WC_Product[]
	 */
	function mvweb_core_boxes( array $ids = array(), $limit = 6 ) {
		$args = array(
			'type'       => 'grouped',
			'status'     => 'publish',
			'limit'      => empty( $ids ) ? 24 : count( $ids ),
			'meta_key'   => '_mvweb_box', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- A handful of grouped products.
			'meta_value' => 'yes', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- A handful of grouped products.
		);

		if ( ! empty( $ids ) ) {
			$args['include'] = array_map( 'absint', $ids );
			$args['orderby'] = 'post__in';
		}

		$boxes = array();

		foreach ( wc_get_products( $args ) as $product ) {
			if ( mvweb_core_box_state( $product )['active'] ) {
				$boxes[] = $product;
			}

			if ( count( $boxes ) >= $limit ) {
				break;
			}
		}

		return $boxes;
	}
}

if ( ! function_exists( 'mvweb_core_box_tab' ) ) {
	/**
	 * The Box tab in the product data, for grouped products.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tabs Tabs.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_box_tab( $tabs ) {
		$tabs['mvweb_box'] = array(
			'label'    => _x( 'Box', 'set of products', 'mvweb-core' ),
			'target'   => 'mvweb_box_data',
			'class'    => array( 'show_if_grouped' ),
			'priority' => 25,
		);

		return $tabs;
	}
}

if ( ! function_exists( 'mvweb_core_box_panel' ) ) {
	/**
	 * The fields of the Box tab.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_box_panel() {
		global $product_object;

		$product = $product_object instanceof WC_Product ? $product_object : null;
		$limit   = $product ? absint( $product->get_meta( '_mvweb_box_limit' ) ) : 0;
		?>
		<div id="mvweb_box_data" class="panel woocommerce_options_panel hidden">
			<div class="options_group">
				<?php
				woocommerce_wp_checkbox(
					array(
						'id'          => '_mvweb_box',
						'label'       => __( 'This is a box', 'mvweb-core' ),
						'description' => __( 'The products of Linked products, Grouped products are sold as one item of the cart, at their price less the discount below. Simple products and variations count: type the name of a product with variations to pick its variation.', 'mvweb-core' ),
					)
				);

				woocommerce_wp_select(
					array(
						'id'      => '_mvweb_box_type',
						'label'   => __( 'Discount in', 'mvweb-core' ),
						'options' => array(
							'sum'     => get_woocommerce_currency_symbol(),
							'percent' => '%',
						),
					)
				);

				woocommerce_wp_text_input(
					array(
						'id'          => '_mvweb_box_amount',
						'label'       => __( 'Discount on the box', 'mvweb-core' ),
						'data_type'   => 'price',
						'desc_tip'    => true,
						'description' => __( 'A sum off the whole box, or a share of the price of its products. Empty: the box sells at the price of its products.', 'mvweb-core' ),
					)
				);
				?>
			</div>
			<div class="options_group">
				<?php
				woocommerce_wp_text_input(
					array(
						'id'          => '_mvweb_box_until',
						'label'       => __( 'Sale ends', 'mvweb-core' ),
						'type'        => 'datetime-local',
						'desc_tip'    => true,
						'description' => __( 'Date and time of the site. Empty: no end.', 'mvweb-core' ),
					)
				);

				woocommerce_wp_text_input(
					array(
						'id'                => '_mvweb_box_limit',
						'label'             => __( 'Purchases at most', 'mvweb-core' ),
						'type'              => 'number',
						'value'             => $limit > 0 ? (string) $limit : '',
						'custom_attributes' => array(
							'min'  => '0',
							'step' => '1',
						),
						'desc_tip'          => true,
						'description'       => __( 'Boxes sold in orders. A cancelled order gives its purchase back. Empty: no limit.', 'mvweb-core' ),
					)
				);

				if ( $product && mvweb_core_is_box( $product ) ) {
					printf(
						'<p class="form-field"><label>%1$s</label><span>%2$s</span></p>',
						esc_html__( 'Bought', 'mvweb-core' ),
						esc_html( (string) absint( $product->get_meta( '_mvweb_box_sold' ) ) )
					);

					printf(
						'<p class="form-field"><label>%1$s</label><span>%2$s</span></p>',
						esc_html__( 'Now', 'mvweb-core' ),
						esc_html( mvweb_core_box_reason( mvweb_core_box_state( $product )['reason'] ) )
					);
				}
				?>
			</div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_box_save' ) ) {
	/**
	 * Keep the fields of the Box tab.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Product being saved.
	 *
	 * @return void
	 */
	function mvweb_core_box_save( $product ) {
		if ( ! $product->is_type( 'grouped' ) ) {
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- WooCommerce checked the nonce of the product form.
		$box  = isset( $_POST['_mvweb_box'] );
		$type = isset( $_POST['_mvweb_box_type'] ) && 'percent' === $_POST['_mvweb_box_type'] ? 'percent' : 'sum';

		$product->update_meta_data( '_mvweb_box', $box ? 'yes' : 'no' );
		$product->update_meta_data( '_mvweb_box_type', $type );
		$product->update_meta_data( '_mvweb_box_amount', isset( $_POST['_mvweb_box_amount'] ) ? mvweb_core_sanitize_amount( wc_format_decimal( sanitize_text_field( wp_unslash( $_POST['_mvweb_box_amount'] ) ) ) ) : '' );
		$product->update_meta_data( '_mvweb_box_until', isset( $_POST['_mvweb_box_until'] ) ? sanitize_text_field( wp_unslash( $_POST['_mvweb_box_until'] ) ) : '' );
		$product->update_meta_data( '_mvweb_box_limit', isset( $_POST['_mvweb_box_limit'] ) ? absint( $_POST['_mvweb_box_limit'] ) : 0 );
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}
}

if ( ! function_exists( 'mvweb_core_box_sync' ) ) {
	/**
	 * Warn about products that cannot go into a saved box, and drop the coupon the box used to keep.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Product id.
	 *
	 * @return void
	 */
	function mvweb_core_box_sync( $post_id ) {
		$product = wc_get_product( $post_id );

		if ( ! $product ) {
			return;
		}

		$coupon = absint( $product->get_meta( '_mvweb_box_coupon' ) );

		if ( $coupon > 0 ) {
			if ( 'shop_coupon' === get_post_type( $coupon ) ) {
				$product->update_meta_data( '_mvweb_box_sold', max( absint( $product->get_meta( '_mvweb_box_sold' ) ), ( new WC_Coupon( $coupon ) )->get_usage_count() ) );
				wp_delete_post( $coupon, true );
			}

			$product->delete_meta_data( '_mvweb_box_coupon' );
			$product->save_meta_data();
		}

		if ( ! mvweb_core_is_box( $product ) ) {
			return;
		}

		foreach ( $product->get_children() as $child ) {
			$item = wc_get_product( $child );

			if ( ! mvweb_core_box_fits( $item ) ) {
				/* translators: %s: product name. */
				WC_Admin_Meta_Boxes::add_error( sprintf( __( '%s does not go into the box: only a simple product, or a variation with every attribute chosen.', 'mvweb-core' ), $item ? $item->get_name() : '#' . $child ) );
			} elseif ( mvweb_core_quantity_rules( mvweb_core_product_parent( $item ) )['min'] > 1 ) {
				/* translators: %s: product name. */
				WC_Admin_Meta_Boxes::add_error( sprintf( __( '%s is sold from more than one piece: the box cannot add it.', 'mvweb-core' ), $item->get_name() ) );
			}
		}

		if ( absint( $product->get_meta( '_mvweb_box_limit' ) ) > 0 && 'yes' !== get_option( 'woocommerce_manage_stock' ) ) {
			WC_Admin_Meta_Boxes::add_error( __( 'The limit of purchases counts boxes only while stock management is on in WooCommerce.', 'mvweb-core' ) );
		}

		if ( count( mvweb_core_box_items( $product ) ) < 2 ) {
			WC_Admin_Meta_Boxes::add_error( __( 'A box needs at least two products in Linked products, Grouped products.', 'mvweb-core' ) );
		} elseif ( mvweb_core_box_discount( $product ) >= mvweb_core_box_sum( $product ) ) {
			WC_Admin_Meta_Boxes::add_error( __( 'The discount is not less than the price of the products: the box is not on sale.', 'mvweb-core' ) );
		}
	}
}

if ( ! function_exists( 'mvweb_core_box_old_coupon' ) ) {
	/**
	 * A coupon a box used to keep no longer gives a discount, even typed by hand.
	 *
	 * @since 0.1.0
	 *
	 * @param bool      $valid  Valid so far.
	 * @param WC_Coupon $coupon Coupon.
	 *
	 * @return bool
	 */
	function mvweb_core_box_old_coupon( $valid, $coupon ) {
		return $coupon instanceof WC_Coupon && $coupon->get_meta( '_mvweb_box' ) ? false : $valid;
	}
}

if ( ! function_exists( 'mvweb_core_box_price' ) ) {
	/**
	 * The price of a box in the cart: the sum of its products less the discount.
	 *
	 * @since 0.1.0
	 *
	 * @param string     $price   Price.
	 * @param WC_Product $product Product.
	 *
	 * @return string
	 */
	function mvweb_core_box_price( $price, $product ) {
		if ( ! mvweb_core_is_box( $product ) ) {
			return $price;
		}

		$state = mvweb_core_box_state( $product );

		return $state['sum'] > 0 ? (string) $state['price'] : $price;
	}
}

if ( ! function_exists( 'mvweb_core_box_purchasable' ) ) {
	/**
	 * A box on sale can be bought, as one product.
	 *
	 * @since 0.1.0
	 *
	 * @param bool       $purchasable Purchasable so far.
	 * @param WC_Product $product     Product.
	 *
	 * @return bool
	 */
	function mvweb_core_box_purchasable( $purchasable, $product ) {
		return mvweb_core_is_box( $product ) ? mvweb_core_box_state( $product )['active'] : $purchasable;
	}
}

if ( ! function_exists( 'mvweb_core_box_in_stock' ) ) {
	/**
	 * A box is in stock while all its products are.
	 *
	 * @since 0.1.0
	 *
	 * @param bool       $in_stock In stock so far.
	 * @param WC_Product $product  Product.
	 *
	 * @return bool
	 */
	function mvweb_core_box_in_stock( $in_stock, $product ) {
		if ( ! mvweb_core_is_box( $product ) ) {
			return $in_stock;
		}

		return ! in_array( mvweb_core_box_state( $product )['reason'], array( 'items', 'stock' ), true ) && 0 !== mvweb_core_box_room( $product );
	}
}

if ( ! function_exists( 'mvweb_core_box_handler' ) ) {
	/**
	 * WooCommerce adds a box to the cart as it adds a simple product.
	 *
	 * @since 0.1.0
	 *
	 * @param string     $handler Product type of the handler.
	 * @param WC_Product $product Product.
	 *
	 * @return string
	 */
	function mvweb_core_box_handler( $handler, $product ) {
		return mvweb_core_is_box( $product ) ? 'simple' : $handler;
	}
}

if ( ! function_exists( 'mvweb_core_box_cart_url' ) ) {
	/**
	 * The add to cart link of a box on sale, in a card.
	 *
	 * @since 0.1.0
	 *
	 * @param string     $url     Link.
	 * @param WC_Product $product Product.
	 *
	 * @return string
	 */
	function mvweb_core_box_cart_url( $url, $product ) {
		return mvweb_core_is_box( $product ) && $product->is_purchasable() ? add_query_arg( 'add-to-cart', $product->get_id(), $product->get_permalink() ) : $url;
	}
}

if ( ! function_exists( 'mvweb_core_box_cart_text' ) ) {
	/**
	 * The add to cart words of a box on sale, in a card.
	 *
	 * @since 0.1.0
	 *
	 * @param string     $text    Words.
	 * @param WC_Product $product Product.
	 *
	 * @return string
	 */
	function mvweb_core_box_cart_text( $text, $product ) {
		return mvweb_core_is_box( $product ) && $product->is_purchasable() ? __( 'Buy the box', 'mvweb-core' ) : $text;
	}
}

if ( ! function_exists( 'mvweb_core_box_supports' ) ) {
	/**
	 * A box on sale goes into the cart from a card without leaving the page.
	 *
	 * @since 0.1.0
	 *
	 * @param bool       $supports Supported so far.
	 * @param string     $feature  Feature.
	 * @param WC_Product $product  Product.
	 *
	 * @return bool
	 */
	function mvweb_core_box_supports( $supports, $feature, $product ) {
		return 'ajax_add_to_cart' === $feature && mvweb_core_is_box( $product ) ? $product->is_purchasable() : $supports;
	}
}

if ( ! function_exists( 'mvweb_core_box_quantity_max' ) ) {
	/**
	 * The quantity field of a box stops at the boxes the stock and the limit allow.
	 *
	 * @since 0.1.0
	 *
	 * @param int|float  $max     Maximum so far; -1 for none.
	 * @param WC_Product $product Product.
	 *
	 * @return int|float
	 */
	function mvweb_core_box_quantity_max( $max, $product ) {
		$room = mvweb_core_is_box( $product ) ? mvweb_core_box_room( $product ) : null;

		return null === $room ? $max : $room;
	}
}

if ( ! function_exists( 'mvweb_core_box_add_check' ) ) {
	/**
	 * Refuse more boxes than the stock of their products and the limit allow.
	 *
	 * @since 0.1.0
	 *
	 * @param bool $passed     Passed so far.
	 * @param int  $product_id Product id.
	 * @param int  $quantity   Quantity added.
	 *
	 * @return bool
	 */
	function mvweb_core_box_add_check( $passed, $product_id, $quantity ) {
		$box = wc_get_product( $product_id );

		if ( ! $passed || ! mvweb_core_is_box( $box ) || ! WC()->cart ) {
			return $passed;
		}

		$room = mvweb_core_box_room( $box, true );
		$have = 0;

		foreach ( WC()->cart->get_cart() as $line ) {
			$have += absint( $line['product_id'] ) === $box->get_id() ? (int) $line['quantity'] : 0;
		}

		if ( null !== $room && $have + (int) $quantity > $room ) {
			/* translators: %d: boxes that can be bought. */
			wc_add_notice( sprintf( _n( 'Only %d such box can be bought.', 'Only %d such boxes can be bought.', $room, 'mvweb-core' ), $room ), 'error' );

			return false;
		}

		return $passed;
	}
}

if ( ! function_exists( 'mvweb_core_box_cart_check' ) ) {
	/**
	 * Stop the checkout while a box in the cart is off sale or its products are short, counting them bought on their own too.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_box_cart_check() {
		$need  = array();
		$parts = array();
		$boxes = array();

		foreach ( WC()->cart->get_cart() as $line ) {
			$product = $line['data'];

			if ( ! mvweb_core_is_box( $product ) ) {
				$id          = $product instanceof WC_Product ? $product->get_stock_managed_by_id() : 0;
				$need[ $id ] = ( isset( $need[ $id ] ) ? $need[ $id ] : 0 ) + (int) $line['quantity'];
				continue;
			}

			if ( ! mvweb_core_box_state( $product )['active'] ) {
				/* translators: %s: box name. */
				wc_add_notice( sprintf( __( 'The box %s is not on sale any more: remove it from the cart.', 'mvweb-core' ), $product->get_name() ), 'error' );
				continue;
			}

			$boxes[ $product->get_id() ] = array( $product, ( isset( $boxes[ $product->get_id() ] ) ? $boxes[ $product->get_id() ][1] : 0 ) + (int) $line['quantity'] );

			foreach ( mvweb_core_box_items( $product ) as $item ) {
				$id           = $item->get_stock_managed_by_id();
				$need[ $id ]  = ( isset( $need[ $id ] ) ? $need[ $id ] : 0 ) + (int) $line['quantity'];
				$parts[ $id ] = $item;
			}
		}

		foreach ( $boxes as $pair ) {
			$room = mvweb_core_box_room( $pair[0], true );

			if ( null !== $room && $pair[1] > $room ) {
				/* translators: %d: boxes that can be bought. */
				wc_add_notice( sprintf( _n( 'Only %d such box can be bought.', 'Only %d such boxes can be bought.', $room, 'mvweb-core' ), $room ), 'error' );
			}
		}

		foreach ( $parts as $id => $item ) {
			if ( $item->managing_stock() && ! $item->backorders_allowed() && $need[ $id ] > mvweb_core_box_free( $item ) ) {
				/* translators: %s: product name. */
				wc_add_notice( sprintf( __( 'Not enough %s in stock for the boxes in the cart.', 'mvweb-core' ), $item->get_name() ), 'error' );
			}
		}
	}
}

if ( ! function_exists( 'mvweb_core_box_item_data' ) ) {
	/**
	 * What a box holds, under its line in the cart.
	 *
	 * @since 0.1.0
	 *
	 * @param array $data      Shown data of the line.
	 * @param array $cart_item Cart line.
	 *
	 * @return array
	 */
	function mvweb_core_box_item_data( $data, $cart_item ) {
		if ( isset( $cart_item['data'] ) && mvweb_core_is_box( $cart_item['data'] ) ) {
			$data[] = array(
				'key'     => __( 'In the box', 'mvweb-core' ),
				'value'   => mvweb_core_box_names( $cart_item['data'] ),
				'display' => mvweb_core_box_list( $cart_item['data'] ),
			);
		}

		return $data;
	}
}

if ( ! function_exists( 'mvweb_core_box_order_item' ) ) {
	/**
	 * What a box holds, under its line in the order, for whoever packs it.
	 *
	 * @since 0.1.0
	 *
	 * @param int           $item_id Order item id.
	 * @param WC_Order_Item $item    Order item.
	 *
	 * @return void
	 */
	function mvweb_core_box_order_item( $item_id, $item ) {
		if ( ! $item instanceof WC_Order_Item_Product || ! mvweb_core_is_box( $item->get_product() ) ) {
			return;
		}

		$item->add_meta_data( __( 'In the box', 'mvweb-core' ), mvweb_core_box_names( $item->get_product() ), true );
		$item->add_meta_data(
			'_mvweb_box_parts',
			array_map(
				static function ( $part ) {
					return $part->get_id();
				},
				mvweb_core_box_items( $item->get_product() )
			),
			true
		);
		$item->save_meta_data();
	}
}

if ( ! function_exists( 'mvweb_core_box_count' ) ) {
	/**
	 * Change the count of purchases of a box in one query, so that two orders at once do not lose one.
	 *
	 * @since 0.1.0
	 *
	 * @param int $box_id Box id.
	 * @param int $change Boxes bought, or given back when negative.
	 *
	 * @return void
	 */
	function mvweb_core_box_count( $box_id, $change ) {
		global $wpdb;

		if ( 0 === $change || ! $box_id ) {
			return;
		}

		$done = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->postmeta} SET meta_value = GREATEST( 0, CAST( meta_value AS SIGNED ) + %d ) WHERE post_id = %d AND meta_key = '_mvweb_box_sold'", $change, $box_id ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One atomic step on the count; the cache is dropped below.

		if ( ! $done && $change > 0 && '' === (string) get_post_meta( $box_id, '_mvweb_box_sold', true ) ) {
			add_post_meta( $box_id, '_mvweb_box_sold', $change, true );
		}

		wp_cache_delete( $box_id, 'post_meta' );
	}
}

if ( ! function_exists( 'mvweb_core_box_settle' ) ) {
	/**
	 * Bring the stock a box line of an order took to the boxes it should hold now, and the count of purchases with it.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Order_Item $item   Order line.
	 * @param int           $target Boxes the line should hold taken off the stock.
	 *
	 * @return void
	 */
	function mvweb_core_box_settle( $item, $target ) {
		if ( ! $item instanceof WC_Order_Item_Product ) {
			return;
		}

		$box     = $item->get_product();
		$counted = (int) $item->get_meta( '_mvweb_box_counted', true );
		$change  = max( 0, (int) $target ) - $counted;

		if ( 0 === $change || ( $change > 0 && ! mvweb_core_is_box( $box ) ) ) {
			return;
		}

		$done    = $item->get_meta( '_mvweb_box_reduced', true );
		$done    = is_array( $done ) ? $done : array();
		$changes = array();

		foreach ( mvweb_core_box_parts( $item ) as $id ) {
			$part = wc_get_product( $id );
			$had  = isset( $done[ $id ] ) ? (int) $done[ $id ] : 0;
			$step = $change > 0 ? $change : -min( $had, -$change );

			if ( ! $part || 0 === $step || ( $step > 0 && ! $part->managing_stock() ) ) {
				continue;
			}

			if ( $part->managing_stock() ) {
				$stock     = (int) wc_update_product_stock( $part, abs( $step ), $step > 0 ? 'decrease' : 'increase' );
				$changes[] = $part->get_formatted_name() . ' ' . ( $stock + $step ) . '→' . $stock;
			}

			$done[ $id ] = $had + $step;
		}

		$done = array_filter( $done );

		if ( array() === $done ) {
			$item->delete_meta_data( '_mvweb_box_reduced' );
		} else {
			$item->update_meta_data( '_mvweb_box_reduced', $done );
		}

		if ( $counted + $change > 0 ) {
			$item->update_meta_data( '_mvweb_box_counted', $counted + $change );
		} else {
			$item->delete_meta_data( '_mvweb_box_counted' );
		}

		$item->save();
		mvweb_core_box_count( $box ? $box->get_id() : 0, $change );

		$order = $item->get_order();

		if ( $changes && $order ) {
			$name = $box ? $box->get_name() : $item->get_name();
			/* translators: 1: box name, 2: stock changes. */
			$order->add_order_note( sprintf( $change > 0 ? __( 'Box %1$s, stock reduced: %2$s', 'mvweb-core' ) : __( 'Box %1$s, stock restored: %2$s', 'mvweb-core' ), $name, implode( ', ', $changes ) ) );
		}
	}
}

if ( ! function_exists( 'mvweb_core_box_reduce' ) ) {
	/**
	 * Take the products of the boxes of an order off the stock when WooCommerce takes the stock of the order.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Order $order Order.
	 *
	 * @return void
	 */
	function mvweb_core_box_reduce( $order ) {
		foreach ( $order->get_items() as $item_id => $item ) {
			if ( mvweb_core_is_box( $item->get_product() ) && (int) $item->get_meta( '_mvweb_box_counted', true ) <= 0 ) {
				mvweb_core_box_settle( $item, (int) $item->get_quantity() + (int) $order->get_qty_refunded_for_item( $item_id ) );
			}
		}
	}
}

if ( ! function_exists( 'mvweb_core_box_restore' ) ) {
	/**
	 * Give back the stock the boxes of an order took when WooCommerce gives back the stock of the order.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Order $order Order.
	 *
	 * @return void
	 */
	function mvweb_core_box_restore( $order ) {
		foreach ( $order->get_items() as $item ) {
			mvweb_core_box_settle( $item, 0 );
		}
	}
}

if ( ! function_exists( 'mvweb_core_box_refund' ) ) {
	/**
	 * Give back the stock of the boxes a refund returns to stock.
	 *
	 * @since 0.1.0
	 *
	 * @param int   $refund_id Refund id.
	 * @param array $args      Refund arguments.
	 *
	 * @return void
	 */
	function mvweb_core_box_refund( $refund_id, $args ) {
		$order = empty( $args['restock_items'] ) || empty( $args['order_id'] ) ? false : wc_get_order( $args['order_id'] );

		if ( ! $order || empty( $args['line_items'] ) || ! is_array( $args['line_items'] ) ) {
			return;
		}

		foreach ( $args['line_items'] as $item_id => $line ) {
			$item    = $order->get_item( absint( $item_id ) );
			$counted = $item ? (int) $item->get_meta( '_mvweb_box_counted', true ) : 0;

			if ( $counted > 0 && ! empty( $line['qty'] ) ) {
				mvweb_core_box_settle( $item, $counted - absint( $line['qty'] ) );
			}
		}
	}
}

if ( ! function_exists( 'mvweb_core_box_order_edited' ) ) {
	/**
	 * Follow a box line changed, added or removed in an order whose stock is already taken.
	 *
	 * @since 0.1.0
	 *
	 * @param int|WC_Order|WC_Order_Item[] $first  Order id, order, or added lines, by the hook.
	 * @param WC_Order|array|null          $second Order or posted lines, by the hook.
	 *
	 * @return void
	 */
	function mvweb_core_box_order_edited( $first, $second = null ) {
		$order = $second instanceof WC_Order ? $second : wc_get_order( is_numeric( $first ) ? (int) $first : 0 );

		if ( ! $order || ! $order->get_data_store()->get_stock_reduced( $order->get_id() ) ) {
			return;
		}

		foreach ( $order->get_items() as $item_id => $item ) {
			if ( mvweb_core_is_box( $item->get_product() ) || (int) $item->get_meta( '_mvweb_box_counted', true ) > 0 ) {
				mvweb_core_box_settle( $item, (int) $item->get_quantity() + (int) $order->get_qty_refunded_for_item( $item_id ) );
			}
		}
	}
}

if ( ! function_exists( 'mvweb_core_box_line_removed' ) ) {
	/**
	 * Give back the stock of a box line removed from an order.
	 *
	 * @since 0.1.0
	 *
	 * @param int $item_id Order item id.
	 *
	 * @return void
	 */
	function mvweb_core_box_line_removed( $item_id ) {
		$item = WC_Order_Factory::get_order_item( absint( $item_id ) );

		if ( $item && (int) $item->get_meta( '_mvweb_box_counted', true ) > 0 ) {
			mvweb_core_box_settle( $item, 0 );
		}
	}
}

if ( ! function_exists( 'mvweb_core_box_price_html' ) ) {
	/**
	 * The price of a box: what its products cost and, on sale, the price with the discount.
	 *
	 * @since 0.1.0
	 *
	 * @param string     $html    Price HTML.
	 * @param WC_Product $product Product.
	 *
	 * @return string
	 */
	function mvweb_core_box_price_html( $html, $product ) {
		if ( ! mvweb_core_is_box( $product ) ) {
			return $html;
		}

		$state = mvweb_core_box_state( $product );

		if ( $state['sum'] <= 0 ) {
			return $html;
		}

		$sum   = wc_get_price_to_display( $product, array( 'price' => $state['sum'] ) );
		$price = wc_get_price_to_display( $product, array( 'price' => $state['price'] ) );

		return $state['active'] && $state['discount'] > 0 ? wc_format_sale_price( $sum, $price ) : wc_price( $sum );
	}
}

if ( ! function_exists( 'mvweb_core_box_schema' ) ) {
	/**
	 * The offer of a box in the structured data of WooCommerce: one price, the one of the box.
	 *
	 * @since 0.1.0
	 *
	 * @param array      $markup  Product markup.
	 * @param WC_Product $product Product.
	 *
	 * @return array
	 */
	function mvweb_core_box_schema( $markup, $product ) {
		if ( ! mvweb_core_is_box( $product ) || empty( $markup['offers'][0] ) ) {
			return $markup;
		}

		$state = mvweb_core_box_state( $product );
		$offer = $markup['offers'][0];

		unset( $offer['lowPrice'], $offer['highPrice'], $offer['offerCount'], $offer['priceSpecification'] );

		$offer['@type'] = 'Offer';
		$offer['price'] = wc_format_decimal( $state['price'], wc_get_price_decimals() );

		if ( $state['active'] && $state['until'] ) {
			$offer['priceValidUntil'] = wp_date( 'Y-m-d', $state['until'] );
		}

		$markup['offers'] = array( $offer );

		return $markup;
	}
}

if ( ! function_exists( 'mvweb_core_box_template' ) ) {
	/**
	 * The form of a box: the template of the theme in place of the form of a grouped product, when the theme has one.
	 *
	 * @since 0.1.0
	 *
	 * @param string $template Template path.
	 * @param string $name     Template name.
	 *
	 * @return string
	 */
	function mvweb_core_box_template( $template, $name ) {
		if ( 'single-product/add-to-cart/grouped.php' !== $name || ! mvweb_core_is_box( isset( $GLOBALS['product'] ) ? $GLOBALS['product'] : null ) ) {
			return $template;
		}

		$own = locate_template( 'template-parts/box-buy.php' );

		return '' !== $own ? $own : $template;
	}
}

if ( ! function_exists( 'mvweb_core_box_search' ) ) {
	/**
	 * Let the Grouped products field find variations while the product is a box.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_box_search() {
		$screen = get_current_screen();

		if ( ! $screen || 'product' !== $screen->id ) {
			return;
		}

		wp_add_inline_script(
			'wc-enhanced-select',
			'jQuery(function($){var box=$("#_mvweb_box"),field=$("#grouped_products");function sync(){field.data("action",box.is(":checked")?"woocommerce_json_search_products_and_variations":"woocommerce_json_search_products");}box.on("change",sync);sync();});'
		);
	}
}

if ( ! function_exists( 'mvweb_core_box_duplicate' ) ) {
	/**
	 * A copy of a box starts with no purchases.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $keys Meta keys left out of the copy.
	 *
	 * @return string[]
	 */
	function mvweb_core_box_duplicate( $keys ) {
		$keys[] = '_mvweb_box_sold';

		return $keys;
	}
}

if ( mvweb_core_is_woocommerce() ) {
	add_filter( 'woocommerce_duplicate_product_exclude_meta', 'mvweb_core_box_duplicate' );
	add_action( 'admin_enqueue_scripts', 'mvweb_core_box_search', 20 );
	add_filter( 'woocommerce_product_data_tabs', 'mvweb_core_box_tab' );
	add_action( 'woocommerce_product_data_panels', 'mvweb_core_box_panel' );
	add_action( 'woocommerce_admin_process_product_object', 'mvweb_core_box_save' );
	add_action( 'woocommerce_process_product_meta', 'mvweb_core_box_sync', 20 );
	add_filter( 'woocommerce_coupon_is_valid', 'mvweb_core_box_old_coupon', 10, 2 );
	add_filter( 'woocommerce_product_get_price', 'mvweb_core_box_price', 30, 2 );
	add_filter( 'woocommerce_is_purchasable', 'mvweb_core_box_purchasable', 10, 2 );
	add_filter( 'woocommerce_product_is_in_stock', 'mvweb_core_box_in_stock', 10, 2 );
	add_filter( 'woocommerce_add_to_cart_handler', 'mvweb_core_box_handler', 10, 2 );
	add_filter( 'woocommerce_product_add_to_cart_url', 'mvweb_core_box_cart_url', 10, 2 );
	add_filter( 'woocommerce_product_add_to_cart_text', 'mvweb_core_box_cart_text', 10, 2 );
	add_filter( 'woocommerce_product_supports', 'mvweb_core_box_supports', 10, 3 );
	add_filter( 'woocommerce_quantity_input_max', 'mvweb_core_box_quantity_max', 10, 2 );
	add_filter( 'woocommerce_add_to_cart_validation', 'mvweb_core_box_add_check', 10, 3 );
	add_action( 'woocommerce_check_cart_items', 'mvweb_core_box_cart_check' );
	add_filter( 'woocommerce_get_item_data', 'mvweb_core_box_item_data', 10, 2 );
	add_action( 'woocommerce_new_order_item', 'mvweb_core_box_order_item', 10, 2 );
	add_action( 'woocommerce_reduce_order_stock', 'mvweb_core_box_reduce' );
	add_action( 'woocommerce_restore_order_stock', 'mvweb_core_box_restore' );
	add_action( 'woocommerce_refund_created', 'mvweb_core_box_refund', 10, 2 );
	add_action( 'woocommerce_saved_order_items', 'mvweb_core_box_order_edited', 10, 2 );
	add_action( 'woocommerce_ajax_order_items_added', 'mvweb_core_box_order_edited', 10, 2 );
	add_action( 'woocommerce_before_delete_order_item', 'mvweb_core_box_line_removed' );
	add_filter( 'woocommerce_get_price_html', 'mvweb_core_box_price_html', 20, 2 );
	add_filter( 'woocommerce_structured_data_product', 'mvweb_core_box_schema', 10, 2 );
	add_filter( 'wc_get_template', 'mvweb_core_box_template', 10, 2 );
}
