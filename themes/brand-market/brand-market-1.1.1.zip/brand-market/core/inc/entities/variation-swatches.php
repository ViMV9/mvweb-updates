<?php
/**
 * Options of a variable product as buttons, and the first variation chosen from the start.
 *
 * The select of WooCommerce stays in the form and keeps the choice; the buttons set it.
 * A value of an attribute of the "Color / image" type of WooCommerce shows its colour or picture.
 * The theme draws the buttons when it declares the mvweb-swatches support.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_swatch_types' ) ) {
	/**
	 * Offer the "Color / image" attribute type of WooCommerce, which it keeps for block themes.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $types Attribute type => label.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_swatch_types( $types ) {
		if ( current_theme_supports( 'mvweb-swatches' ) && ! isset( $types['wc-visual'] ) ) {
			$types['wc-visual'] = __( 'Colour / image', 'mvweb-core' );
		}

		return $types;
	}
}
add_filter( 'product_attributes_type_selector', 'mvweb_core_swatch_types' );

if ( ! function_exists( 'mvweb_core_swatch_selected' ) ) {
	/**
	 * Choose the first variation a buyer can buy when the owner set no default.
	 *
	 * @since 0.1.0
	 *
	 * @param array $args Arguments of the select.
	 *
	 * @return array
	 */
	function mvweb_core_swatch_selected( $args ) {
		static $first = array();

		$product = isset( $args['product'] ) ? $args['product'] : null;

		if ( ! current_theme_supports( 'mvweb-swatches' ) || ! $product instanceof WC_Product_Variable || empty( $args['attribute'] ) || ( isset( $args['selected'] ) && false !== $args['selected'] ) ) {
			return $args;
		}

		$key = sanitize_title( $args['attribute'] );

		if ( isset( $_REQUEST[ 'attribute_' . $key ] ) || array() !== $product->get_default_attributes() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only checks that the buyer already chose.
			return $args;
		}

		$id = $product->get_id();

		if ( ! isset( $first[ $id ] ) ) {
			$first[ $id ] = array();
			$limit        = (int) apply_filters( 'woocommerce_ajax_variation_threshold', 30, $product );

			foreach ( array_slice( $product->get_children(), 0, $limit ) as $child ) {
				$variation = wc_get_product( $child );

				if ( $variation instanceof WC_Product_Variation && $variation->variation_is_visible() && $variation->is_purchasable() && $variation->is_in_stock() ) {
					$first[ $id ] = $variation->get_attributes();
					break;
				}
			}
		}

		if ( array() === $first[ $id ] ) {
			return $args;
		}

		$value = isset( $first[ $id ][ $key ] ) ? (string) $first[ $id ][ $key ] : '';

		if ( '' === $value && ! empty( $args['options'] ) ) {
			$value = (string) reset( $args['options'] );
		}

		$args['selected'] = $value;

		return $args;
	}
}
add_filter( 'woocommerce_dropdown_variation_attribute_options_args', 'mvweb_core_swatch_selected' );

if ( ! function_exists( 'mvweb_core_swatch_visual' ) ) {
	/**
	 * The colour or picture WooCommerce keeps for a value of a "Color / image" attribute.
	 *
	 * @since 0.1.0
	 *
	 * @param string $taxonomy Attribute taxonomy.
	 * @param string $slug     Value slug.
	 *
	 * @return array{color:string,image:int} Empty values when the attribute is of another type.
	 */
	function mvweb_core_swatch_visual( $taxonomy, $slug ) {
		$none = array(
			'color' => '',
			'image' => 0,
		);

		if ( ! taxonomy_exists( $taxonomy ) ) {
			return $none;
		}

		$attribute = wc_get_attribute( wc_attribute_taxonomy_id_by_name( $taxonomy ) );
		$term      = get_term_by( 'slug', $slug, $taxonomy );

		if ( ! $attribute || 'wc-visual' !== $attribute->type || ! $term ) {
			return $none;
		}

		$image = absint( get_term_meta( $term->term_id, 'image', true ) );

		return array(
			'color' => (string) sanitize_hex_color( get_term_meta( $term->term_id, 'color', true ) ),
			'image' => $image && wp_attachment_is_image( $image ) ? $image : 0,
		);
	}
}

if ( ! function_exists( 'mvweb_core_swatch_buttons' ) ) {
	/**
	 * Add the buttons of the options after the select, which hides.
	 *
	 * @since 0.1.0
	 *
	 * @param string $html Markup of the select.
	 * @param array  $args Arguments of the select.
	 *
	 * @return string
	 */
	function mvweb_core_swatch_buttons( $html, $args ) {
		$product = isset( $args['product'] ) ? $args['product'] : null;

		if ( ! current_theme_supports( 'mvweb-swatches' ) || ! $product instanceof WC_Product_Variable || empty( $args['attribute'] ) ) {
			return $html;
		}

		preg_match_all( '#<option value="([^"]+)"([^>]*)>([^<]*)</option>#', $html, $found, PREG_SET_ORDER );

		if ( ! $found ) {
			return $html;
		}

		$key    = sanitize_title( $args['attribute'] );
		$label  = wc_attribute_label( $args['attribute'], $product );
		$chosen = '';
		$items  = '';
		$visual = false;

		foreach ( $found as $option ) {
			$name = $option[3];
			$on   = false !== strpos( $option[2], 'selected' );
			$look = mvweb_core_swatch_visual( $args['attribute'], html_entity_decode( $option[1], ENT_QUOTES, 'UTF-8' ) );
			$fill = '';

			if ( $look['image'] ) {
				$fill = wp_get_attachment_image(
					$look['image'],
					'thumbnail',
					false,
					array(
						'alt'     => '',
						'loading' => 'lazy',
					)
				);
			} elseif ( '' !== $look['color'] ) {
				$fill = '<span class="mvweb-t-swatch__color" style="background-color:' . esc_attr( $look['color'] ) . '"></span>';
			}

			$visual = $visual || '' !== $fill;
			$chosen = $on ? $name : $chosen;
			$items .= sprintf(
				'<button class="mvweb-t-swatch %1$s" type="button" data-swatch="%2$s" aria-pressed="%3$s"%4$s>%5$s</button>',
				$fill ? 'mvweb-t-swatch--visual' : 'mvweb-t-chip',
				$option[1],
				$on ? 'true' : 'false',
				$fill ? ' title="' . $name . '"' : '',
				$fill ? $fill . '<span class="screen-reader-text">' . $name . '</span>' : $name
			);
		}

		return preg_replace( '#^<select #', '<select hidden ', $html ) . sprintf(
			'<div class="mvweb-t-swatches%1$s" data-swatches="attribute_%2$s">%3$s<div class="mvweb-t-swatches__list mvweb-t-chips" role="group" aria-label="%4$s">%5$s</div></div>',
			$visual ? ' mvweb-t-swatches--visual' : '',
			esc_attr( $key ),
			$visual ? '<span class="mvweb-t-swatches__name" data-swatch-name>' . $chosen . '</span>' : '',
			esc_attr( $label ),
			$items
		);
	}
}
add_filter( 'woocommerce_dropdown_variation_attribute_options_html', 'mvweb_core_swatch_buttons', 10, 2 );

if ( ! function_exists( 'mvweb_core_swatch_reset_link' ) ) {
	/**
	 * Drop the link that clears the choice: an option is always chosen.
	 *
	 * @since 0.1.0
	 *
	 * @param string $link Markup of the link.
	 *
	 * @return string
	 */
	function mvweb_core_swatch_reset_link( $link ) {
		return current_theme_supports( 'mvweb-swatches' ) ? '' : $link;
	}
}
add_filter( 'woocommerce_reset_variations_link', 'mvweb_core_swatch_reset_link' );
