<?php
/**
 * Comments under a blog entry.
 *
 * Printed only when the entry takes comments or already has some (see
 * comments_template()). The form uses the fields of the theme's own forms, so
 * it looks like the request forms of the site; the consent line and the
 * refusal of a comment sent without it are settings of the core.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( post_password_required() ) {
	return;
}

$mvweb_required  = (bool) get_option( 'require_name_email' );
$mvweb_commenter = wp_get_current_commenter();
$mvweb_field     = static function ( $name, $label, $type, $autocomplete, $placeholder = '' ) use ( $mvweb_required, $mvweb_commenter ) {
	return sprintf(
		'<div class="mvweb-t-field"><label class="mvweb-t-field__label" for="%1$s">%2$s</label><input class="mvweb-t-field__input" id="%1$s" name="%1$s" type="%3$s" value="%4$s" autocomplete="%5$s"%6$s%7$s></div>',
		esc_attr( $name ),
		esc_html( $label ),
		esc_attr( $type ),
		esc_attr( $mvweb_commenter[ 'author' === $name ? 'comment_author' : 'comment_author_' . $name ] ?? '' ),
		esc_attr( $autocomplete ),
		'' !== $placeholder ? ' placeholder="' . esc_attr( $placeholder ) . '"' : '',
		$mvweb_required ? ' required' : ''
	);
};
$mvweb_consent   = mvweb_core_blog_comment_consent();
$mvweb_walker    = new class() extends Walker_Comment {
	/**
	 * Open the list of replies under a comment.
	 *
	 * @param string $output Markup so far.
	 * @param int    $depth  Depth of the comment.
	 * @param array  $args   Arguments of the list.
	 *
	 * @return void
	 */
	public function start_lvl( &$output, $depth = 0, $args = array() ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- Signature of the parent method.
		$output .= '<div class="mvweb-t-comment__children"><ul class="mvweb-t-comments__list">';
	}

	/**
	 * Close the list of replies under a comment.
	 *
	 * @param string $output Markup so far.
	 * @param int    $depth  Depth of the comment.
	 * @param array  $args   Arguments of the list.
	 *
	 * @return void
	 */
	public function end_lvl( &$output, $depth = 0, $args = array() ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter -- Signature of the parent method.
		$output .= '</ul></div>';
	}
};
$mvweb_item      = static function ( $comment, $args, $depth ) {
	$mvweb_by_author = $comment->user_id && (int) get_post_field( 'post_author', $comment->comment_post_ID ) === (int) $comment->user_id;
	$mvweb_reply     = get_comment_reply_link(
		array_merge(
			$args,
			array(
				'add_below'  => 'comment',
				'depth'      => $depth,
				'max_depth'  => $args['max_depth'],
				'reply_text' => __( 'Reply', 'brand-market' ),
				'before'     => '',
				'after'      => '',
			)
		),
		$comment
	);
	?>
	<li class="mvweb-t-comment" id="comment-<?php echo (int) $comment->comment_ID; ?>">
		<article class="mvweb-t-comment__box" id="div-comment-<?php echo (int) $comment->comment_ID; ?>">
			<?php echo get_avatar( $comment, 88, '', '', array( 'class' => 'mvweb-t-avatar' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag. ?>
			<div class="mvweb-t-comment__main">
				<p class="mvweb-t-comment__head">
					<strong class="mvweb-t-comment__name"><?php echo esc_html( get_comment_author( $comment ) ); ?></strong>
					<?php if ( $mvweb_by_author ) : ?>
						<span class="mvweb-t-comment__date"><?php esc_html_e( 'Author of the article', 'brand-market' ); ?> · <time datetime="<?php echo esc_attr( get_comment_date( 'c', $comment ) ); ?>"><?php echo esc_html( get_comment_date( '', $comment ) ); ?></time></span>
					<?php else : ?>
						<time class="mvweb-t-comment__date" datetime="<?php echo esc_attr( get_comment_date( 'c', $comment ) ); ?>"><?php echo esc_html( get_comment_date( '', $comment ) ); ?></time>
					<?php endif; ?>
				</p>
				<?php if ( '0' === (string) $comment->comment_approved ) : ?>
					<p class="mvweb-t-comment__note"><?php esc_html_e( 'Your comment is awaiting moderation.', 'brand-market' ); ?></p>
				<?php endif; ?>
				<div class="mvweb-t-comment__text"><?php comment_text( $comment ); ?></div>
				<?php if ( $mvweb_reply ) : ?>
					<?php echo str_replace( 'comment-reply-link', 'comment-reply-link mvweb-t-comment__reply', $mvweb_reply ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the link. ?>
				<?php endif; ?>
			</div>
		</article>
	<?php
};
$mvweb_reorder = static function ( $fields ) {
	$row = isset( $fields['author'] ) ? array( 'author' => $fields['author'] ) : array();

	return $row + $fields;
};
$mvweb_cookies = static function ( $field ) {
	return (string) preg_replace( '#<p class="comment-form-cookies-consent">(<input[^>]*>)\s*<label[^>]*>(.*?)</label></p>#s', '<label class="mvweb-t-check">$1<span>$2</span></label>', $field );
};
$mvweb_count   = (int) get_comments_number();
?>
<section class="mvweb-t-section mvweb-t-section--tight mvweb-t-comments" id="comments">
	<div class="mvweb-t-container">
		<div class="mvweb-t-comments__inner">
			<?php if ( have_comments() ) : ?>
				<div class="mvweb-t-comments__title mvweb-t-h2"><?php esc_html_e( 'Comments', 'brand-market' ); ?> <span class="mvweb-t-comments__count"><?php echo esc_html( number_format_i18n( $mvweb_count ) ); ?></span></div>

				<ol class="mvweb-t-comments__list">
					<?php
					wp_list_comments(
						array(
							'walker'   => $mvweb_walker,
							'callback' => $mvweb_item,
							'style'    => 'ol',
						)
					);
					?>
				</ol>

				<?php the_comments_navigation(); ?>
			<?php endif; ?>

			<?php
			if ( comments_open() ) {
				add_filter( 'comment_form_fields', $mvweb_reorder );
				add_filter( 'comment_form_field_cookies', $mvweb_cookies );

				comment_form(
					array(
						'class_form'           => 'mvweb-t-form mvweb-t-comments__form',
						'class_submit'         => 'mvweb-t-btn',
						'title_reply'          => __( 'Leave a comment', 'brand-market' ),
						'title_reply_before'   => '<div id="reply-title" class="mvweb-t-comments__form-title mvweb-t-h3">',
						'title_reply_after'    => '</div>',
						'cancel_reply_before'  => ' <small>',
						'cancel_reply_after'   => '</small>',
						'comment_notes_before' => '',
						'comment_notes_after'  => '',
						'logged_in_as'         => '',
						'label_submit'         => __( 'Send', 'brand-market' ),
						'submit_button'        => '<button name="%1$s" type="submit" id="%2$s" class="%3$s">%4$s</button>',
						'submit_field'         => '%1$s %2$s',
						'comment_field'        => sprintf(
							'<div class="mvweb-t-field"><label class="mvweb-t-field__label" for="comment">%s</label><textarea class="mvweb-t-field__input" id="comment" name="comment" rows="4" required></textarea></div>',
							esc_html__( 'Comment', 'brand-market' )
						) . ( '' !== $mvweb_consent ? '<label class="mvweb-t-check"><input type="checkbox" name="mvweb_comment_agree" value="1" required><span>' . $mvweb_consent . '</span></label>' : '' ),
						'fields'               => array(
							'author' => '<div class="mvweb-t-comments__form-row">' . $mvweb_field( 'author', __( 'Name', 'brand-market' ), 'text', 'name' ) . $mvweb_field( 'email', __( 'Email', 'brand-market' ), 'email', 'email', __( 'Not published', 'brand-market' ) ) . '</div>',
						),
					)
				);

				remove_filter( 'comment_form_fields', $mvweb_reorder );
				remove_filter( 'comment_form_field_cookies', $mvweb_cookies );
			}
			?>
		</div>
	</div>
</section>
