<?php
/**
 * Search results, grouped by what was found.
 *
 * With no type chosen every group shows its first entries and a link to the
 * rest; a chosen type is the main query itself, paged. The groups are the
 * layout "search.groups", what is printed for a query that found nothing is
 * "search.empty".
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_needle = get_search_query( false );
$mvweb_sets   = array(
	'products' => array(
		'label' => mvweb_core_item_label(),
		'types' => array( mvweb_core_is_woocommerce() ? 'product' : 'mv_item' ),
		'limit' => 4,
	),
	'services' => array(
		'label' => mvweb_core_service_label(),
		'types' => array( 'mv_service' ),
		'limit' => 3,
	),
	'works'    => array(
		'label' => mvweb_core_work_label(),
		'types' => array( 'mv_work' ),
		'limit' => 3,
	),
	'posts'    => array(
		'label' => __( 'Articles', 'brand-market' ),
		'types' => array( 'post' ),
		'limit' => 3,
	),
	'pages'    => array(
		'label' => __( 'Pages', 'brand-market' ),
		'types' => array( 'page' ),
		'limit' => 3,
	),
);

$mvweb_asked = get_query_var( 'post_type' );
$mvweb_asked = is_string( $mvweb_asked ) ? sanitize_key( $mvweb_asked ) : '';
$mvweb_only  = '';
$mvweb_total = 0;
$mvweb_group = array();

if ( '' !== $mvweb_needle ) {
	foreach ( mvweb_core_layout_order( 'search.groups' ) as $mvweb_slug ) {
		if ( ! isset( $mvweb_sets[ $mvweb_slug ] ) || ! post_type_exists( $mvweb_sets[ $mvweb_slug ]['types'][0] ) ) {
			continue;
		}

		$mvweb_set = $mvweb_sets[ $mvweb_slug ];

		if ( $mvweb_asked === $mvweb_set['types'][0] ) {
			$mvweb_only = $mvweb_slug;
			$mvweb_hit  = $GLOBALS['wp_query'];
		} else {
			$mvweb_hit = new WP_Query(
				array(
					's'                   => $mvweb_needle,
					'post_type'           => $mvweb_set['types'],
					'post_status'         => 'publish',
					'posts_per_page'      => $mvweb_set['limit'],
					'ignore_sticky_posts' => true,
				)
			);
		}

		if ( 0 === (int) $mvweb_hit->found_posts ) {
			continue;
		}

		$mvweb_total               += (int) $mvweb_hit->found_posts;
		$mvweb_group[ $mvweb_slug ] = array(
			'label' => $mvweb_set['label'],
			'type'  => $mvweb_set['types'][0],
			'query' => $mvweb_hit,
			'count' => (int) $mvweb_hit->found_posts,
			'limit' => $mvweb_set['limit'],
			'url'   => add_query_arg(
				array(
					's'         => rawurlencode( $mvweb_needle ),
					'post_type' => $mvweb_set['types'][0],
				),
				home_url( '/' )
			),
		);
	}
}

get_header();

$mvweb_lead = '';

if ( '' !== $mvweb_needle ) {
	$mvweb_lead = $mvweb_total > 0
		? sprintf(
			/* translators: 1: search query, 2: number of results. */
			_n( 'For “%1$s” found %2$s result', 'For “%1$s” found %2$s results', $mvweb_total, 'brand-market' ),
			$mvweb_needle,
			number_format_i18n( $mvweb_total )
		)
		: sprintf(
			/* translators: %s: search query. */
			__( 'Nothing found for “%s”', 'brand-market' ),
			$mvweb_needle
		);
}

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'title' => __( 'Search results', 'brand-market' ),
		'lead'  => $mvweb_lead,
	)
);
?>

<section class="mvweb-t-section mvweb-t-section--flush-top mvweb-t-search-page">
	<div class="mvweb-t-container">
		<?php if ( $mvweb_total > 0 ) : ?>

			<?php get_search_form(); ?>

			<?php if ( count( $mvweb_group ) > 1 || '' !== $mvweb_only ) : ?>
				<div class="mvweb-t-search-bar">
					<form class="mvweb-t-tabsel" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" data-tab-select>
						<input type="hidden" name="s" value="<?php echo esc_attr( $mvweb_needle ); ?>">
						<label class="mvweb-t-tabsel__label" for="mvweb-t-search-type"><?php esc_html_e( 'Show', 'brand-market' ); ?></label>
						<select class="mvweb-t-tabsel__select" id="mvweb-t-search-type" name="post_type" aria-label="<?php esc_attr_e( 'Show', 'brand-market' ); ?>">
							<option value=""<?php selected( '', $mvweb_only ); ?>>
								<?php
								/* translators: %s: number of results. */
								echo esc_html( sprintf( __( 'All · %s', 'brand-market' ), number_format_i18n( $mvweb_total ) ) );
								?>
							</option>
							<?php foreach ( $mvweb_group as $mvweb_slug => $mvweb_item ) : ?>
								<option value="<?php echo esc_attr( $mvweb_item['type'] ); ?>"<?php selected( $mvweb_slug, $mvweb_only ); ?>><?php echo esc_html( $mvweb_item['label'] . ' · ' . number_format_i18n( $mvweb_item['count'] ) ); ?></option>
							<?php endforeach; ?>
						</select>
						<button class="screen-reader-text" type="submit"><?php esc_html_e( 'Show', 'brand-market' ); ?></button>
					</form>
				</div>
			<?php endif; ?>

			<?php
			mvweb_core_render_layout(
				'search.groups',
				array(
					'groups' => $mvweb_group,
					'only'   => $mvweb_only,
				)
			);

			if ( '' !== $mvweb_only ) {
				mvweb_theme_pagination();
			}
			?>

		<?php else : ?>

			<div class="mvweb-t-empty mvweb-t-search-none">
				<?php mvweb_core_render_layout( 'search.empty' ); ?>
			</div>

			<?php get_template_part( 'template-parts/search/hits' ); ?>

		<?php endif; ?>
	</div>
</section>

<?php
wp_reset_postdata();

get_footer();
