<?php
/**
 * MVweb Customizer Kit — declarative layer over the native Customizer API.
 *
 * The Kit keeps one registry of panels, sections and fields. That registry is
 * collected once per request and consumed by three independent consumers:
 *
 *   - customize_register    => panels / sections / settings / controls
 *   - wp_head               => CSS built from every field 'output' map
 *   - customize_preview_init => live-preview data for the same output maps
 *
 * Because all three read the same registry, a field declared by a plugin gets
 * its CSS and its live preview for free — no second registration anywhere.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'MVWEB_CZ_VERSION' ) ) {
	/**
	 * Kit contract version. Themes check this before relying on a feature.
	 */
	define( 'MVWEB_CZ_VERSION', '1.3.0' );
}

require_once __DIR__ . '/fields.php';
require_once __DIR__ . '/controls.php';
require_once __DIR__ . '/output.php';
require_once __DIR__ . '/dependencies.php';
require_once __DIR__ . '/assets.php';
require_once __DIR__ . '/baseline.php';

if ( ! class_exists( 'MVweb_Customizer_Kit' ) ) {
	/**
	 * Registry and registrar for Customizer panels, sections and fields.
	 *
	 * @since 1.0.0
	 */
	final class MVweb_Customizer_Kit {

		/**
		 * Singleton instance.
		 *
		 * @var MVweb_Customizer_Kit|null
		 */
		private static $instance = null;

		/**
		 * Declared panels: id => args.
		 *
		 * @var array<string,array>
		 */
		private $panels = array();

		/**
		 * Declared sections: id => args.
		 *
		 * @var array<string,array>
		 */
		private $sections = array();

		/**
		 * Normalized fields: setting id => field.
		 *
		 * @var array<string,array>
		 */
		private $fields = array();

		/**
		 * Every declared field in declaration order, decorations included.
		 *
		 * Order matters: WordPress breaks priority ties by the order controls
		 * were instantiated, so registering decorations in a second pass would
		 * push every heading to the bottom of its section.
		 *
		 * @var array<int,array>
		 */
		private $items = array();

		/**
		 * Whether the registry has been collected.
		 *
		 * @var bool
		 */
		private $collected = false;

		/**
		 * Private constructor — use instance().
		 */
		private function __construct() {}

		/**
		 * Get the singleton.
		 *
		 * @since 1.0.0
		 *
		 * @return MVweb_Customizer_Kit
		 */
		public static function instance() {
			if ( null === self::$instance ) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Declare a panel.
		 *
		 * @since 1.0.0
		 *
		 * @param string $id   Panel id.
		 * @param array  $args Native WP_Customize_Panel args.
		 *
		 * @return MVweb_Customizer_Kit
		 */
		public function add_panel( $id, array $args ) {
			$this->panels[ $id ] = $args;

			return $this;
		}

		/**
		 * Declare a section.
		 *
		 * @since 1.0.0
		 *
		 * @param string $id   Section id.
		 * @param array  $args Native WP_Customize_Section args.
		 *
		 * @return MVweb_Customizer_Kit
		 */
		public function add_section( $id, array $args ) {
			$this->sections[ $id ] = $args;

			return $this;
		}

		/**
		 * Declare a field.
		 *
		 * @since 1.0.0
		 *
		 * @param array $field Field definition, see fields.php for the schema.
		 *
		 * @return MVweb_Customizer_Kit
		 */
		public function add_field( array $field ) {
			$field = mvweb_cz_normalize_field( $field );

			if ( mvweb_cz_is_decoration( $field['type'] ) ) {
				$this->items[] = $field;

				return $this;
			}

			if ( '' === $field['settings'] ) {
				return $this;
			}

			$this->items[]                      = $field;
			$this->fields[ $field['settings'] ] = $field;

			return $this;
		}

		/**
		 * Declare many fields at once.
		 *
		 * @since 1.0.0
		 *
		 * @param array<int,array> $fields Field definitions.
		 *
		 * @return MVweb_Customizer_Kit
		 */
		public function add_fields( array $fields ) {
			foreach ( $fields as $field ) {
				$this->add_field( $field );
			}

			return $this;
		}

		/**
		 * Collect the registry once per request.
		 *
		 * @since 1.0.0
		 *
		 * @return MVweb_Customizer_Kit
		 */
		public function collect() {
			if ( $this->collected ) {
				return $this;
			}

			$this->collected = true;

			do_action( 'mvweb_cz_register', $this );

			return $this;
		}

		/**
		 * All declared fields, keyed by setting id.
		 *
		 * @since 1.0.0
		 *
		 * @return array<string,array>
		 */
		public function get_fields() {
			$this->collect();

			return $this->fields;
		}

		/**
		 * A single field definition.
		 *
		 * @since 1.0.0
		 *
		 * @param string $setting Setting id.
		 *
		 * @return array|null
		 */
		public function get_field( $setting ) {
			$fields = $this->get_fields();

			return isset( $fields[ $setting ] ) ? $fields[ $setting ] : null;
		}

		/**
		 * Every declared item in order, decorations included.
		 *
		 * @since 1.0.0
		 *
		 * @return array<int,array>
		 */
		public function get_items() {
			$this->collect();

			return $this->items;
		}

		/**
		 * Fields that declare a CSS output map.
		 *
		 * @since 1.0.0
		 *
		 * @return array<int,array>
		 */
		public function get_output_fields() {
			$fields = array();

			foreach ( $this->get_fields() as $field ) {
				if ( ! empty( $field['output'] ) ) {
					$fields[] = $field;
				}
			}

			/**
			 * Filter the fields feeding the CSS output layer.
			 *
			 * @since 1.0.0
			 *
			 * @param array<int,array> $fields Fields with an output map.
			 */
			return apply_filters( 'mvweb_cz_output_fields', $fields );
		}

		/**
		 * Register everything on the Customizer manager.
		 *
		 * @since 1.0.0
		 *
		 * @param WP_Customize_Manager $wp_customize Customizer manager.
		 *
		 * @return void
		 */
		public function register( $wp_customize ) {
			$this->collect();

			foreach ( $this->panels as $id => $args ) {
				$wp_customize->add_panel( $id, $args );
			}

			foreach ( $this->sections as $id => $args ) {
				$wp_customize->add_section( $id, $args );
			}

			foreach ( $this->items as $index => $field ) {
				if ( ! mvweb_cz_is_decoration( $field['type'] ) ) {
					$wp_customize->add_setting(
						$field['settings'],
						array(
							'default'           => $field['default'],
							'transport'         => $field['transport'],
							'sanitize_callback' => $field['sanitize_callback'],
						)
					);

					mvweb_cz_register_partial( $wp_customize, $field );
				}

				mvweb_cz_register_control( $wp_customize, $field, $index );
			}
		}
	}
}

if ( ! function_exists( 'mvweb_cz' ) ) {
	/**
	 * Kit accessor.
	 *
	 * @since 1.0.0
	 *
	 * @return MVweb_Customizer_Kit
	 */
	function mvweb_cz() {
		return MVweb_Customizer_Kit::instance();
	}
}

if ( ! function_exists( 'mvweb_cz_customize_register' ) ) {
	/**
	 * Hand the registry to the Customizer manager.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer manager.
	 *
	 * @return void
	 */
	function mvweb_cz_customize_register( $wp_customize ) {
		mvweb_cz()->register( $wp_customize );
	}
}
add_action( 'customize_register', 'mvweb_cz_customize_register' );

if ( ! function_exists( 'mvweb_cz_goto' ) ) {
	/**
	 * A link from a description to another section or panel of the Customizer.
	 *
	 * A note like "the wording comes from Conversion" becomes one click away
	 * from that section instead of a hunt through the panels.
	 *
	 * @since 1.2.0
	 *
	 * @param string $target Section or panel id.
	 * @param string $text   Link text.
	 *
	 * @return string Markup.
	 */
	function mvweb_cz_goto( $target, $text ) {
		return sprintf(
			'<a href="#" class="mvweb-cz-goto" data-target="%1$s">%2$s</a>',
			esc_attr( $target ),
			esc_html( $text )
		);
	}
}

if ( ! function_exists( 'mvweb_cz_get' ) ) {
	/**
	 * Read a Kit value with the declared field default as fallback.
	 *
	 * get_theme_mod() alone returns false for an unset option, which is the
	 * single most common bug in themes built this way. This helper falls back
	 * to the value declared in the field definition instead.
	 *
	 * @since 1.0.0
	 *
	 * @param string $setting       Setting id.
	 * @param mixed  $default_value Explicit fallback, overrides the declared one.
	 *
	 * @return mixed
	 */
	function mvweb_cz_get( $setting, $default_value = null ) {
		if ( null === $default_value ) {
			$field = mvweb_cz()->get_field( $setting );

			$default_value = ( null !== $field ) ? $field['default'] : '';
		}

		return get_theme_mod( $setting, $default_value );
	}
}

if ( ! function_exists( 'mvweb_cz_get_json' ) ) {
	/**
	 * Read a Kit value stored as JSON (repeater / sortable / typography).
	 *
	 * @since 1.0.0
	 *
	 * @param string $setting Setting id.
	 *
	 * @return array
	 */
	function mvweb_cz_get_json( $setting ) {
		$value = json_decode( (string) mvweb_cz_get( $setting ), true );

		return is_array( $value ) ? $value : array();
	}
}
