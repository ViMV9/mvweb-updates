<?php
/**
 * Baseline — the option tree every MVweb theme starts from.
 *
 * Derived from what four production themes actually ship (Service Lux, Bono,
 * Venezia, MVweb Base): the sections below are the ones that recur, so a new
 * theme gets them for free and a client always finds the same option in the
 * same place.
 *
 * Deliberately NOT here, because a studio plugin already owns it:
 *   - head / body code and the cookie notice  => MVweb Site Optimizer
 *   - LocalBusiness schema                    => MVweb Local Business
 *   - pop-ups and lead forms                  => MVweb Pop-up
 *   - price tables                            => MVweb Price Table
 * A theme option that duplicates a plugin is an option that goes stale.
 *
 * The theme calls mvweb_cz_baseline() inside its own mvweb_cz_register
 * handler, then fills the sections with its own fields.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_cz_baseline_tree' ) ) {
	/**
	 * The baseline panel / section tree.
	 *
	 * The panels go in the order an owner sets a site up: how it looks, who
	 * the business is, then the page from top to bottom — header, footer,
	 * homepage, inner pages — and the site's own content types last.
	 * Priorities 30–39 keep them together as one block: core Site Identity
	 * (20) stays above, Menus (100), Homepage Settings (120) and Additional
	 * CSS (200) below. A theme panel takes a free number inside the range —
	 * 37 and 38 are left for content types such as services. Titles read
	 * "MVweb: Section".
	 *
	 * @since 1.0.0
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_cz_baseline_tree() {
		$tree = array(
			'mvweb_cz_design'     => array(
				'title'    => 'MVweb: Оформление',
				'priority' => 30,
				'sections' => array(
					'mvweb_cz_design_preset'     => 'Пресет оформления',
					'mvweb_cz_design_colors'     => 'Цвета',
					'mvweb_cz_design_typography' => 'Типографика',
					'mvweb_cz_design_layout'     => 'Макет и отступы',
				),
			),
			'mvweb_cz_profile'    => array(
				'title'    => 'MVweb: Контакты и реквизиты',
				'priority' => 31,
				'sections' => array(
					'mvweb_cz_profile_contacts' => 'Контакты',
					'mvweb_cz_profile_schedule' => 'График работы',
					'mvweb_cz_profile_socials'  => 'Соцсети и мессенджеры',
					'mvweb_cz_profile_legal'    => 'Карта и реквизиты',
				),
			),
			'mvweb_cz_header'     => array(
				'title'    => 'MVweb: Шапка',
				'priority' => 32,
				'sections' => array(
					'mvweb_cz_header_blocks' => 'Состав шапки',
					'mvweb_cz_header_topbar' => 'Верхняя полоса',
					'mvweb_cz_header_brand'  => 'Логотип и меню',
					'mvweb_cz_header_action' => 'Поиск и кнопка действия',
				),
			),
			'mvweb_cz_footer'     => array(
				'title'    => 'MVweb: Подвал',
				'priority' => 33,
				'sections' => array(
					'mvweb_cz_footer_blocks' => 'Состав подвала',
				),
			),
			'mvweb_cz_home'       => array(
				'title'    => 'MVweb: Главная',
				'priority' => 34,
				'sections' => array(
					'mvweb_cz_home_blocks' => 'Порядок блоков',
					'mvweb_cz_home_hero'   => 'Первый экран',
					'mvweb_cz_home_extra'  => 'Остальные блоки',
				),
			),
			'mvweb_cz_inner'      => array(
				'title'    => 'MVweb: Внутренние страницы',
				'priority' => 35,
				'sections' => array(
					'mvweb_cz_inner_page'    => 'Страницы',
					'mvweb_cz_inner_single'  => 'Записи',
					'mvweb_cz_inner_archive' => 'Архивы и блог',
					'mvweb_cz_inner_sidebar' => 'Боковая колонка',
				),
			),
			'mvweb_cz_conversion' => array(
				'title'    => 'MVweb: Конверсия',
				'priority' => 39,
				'sections' => array(
					'mvweb_cz_conversion_cta'   => 'Кнопки и призывы',
					'mvweb_cz_conversion_share' => 'Кнопки «Поделиться»',
				),
			),
		);

		if ( class_exists( 'WooCommerce' ) ) {
			$tree['mvweb_cz_catalog'] = array(
				'title'    => 'MVweb: Каталог',
				'priority' => 36,
				'sections' => array(
					'mvweb_cz_catalog_archive' => 'Витрина и категории',
					'mvweb_cz_catalog_product' => 'Карточка товара',
				),
			);
		}

		/**
		 * Filter the baseline tree.
		 *
		 * A theme drops a panel by unsetting it, or adds its own sections to
		 * an existing panel here.
		 *
		 * @since 1.0.0
		 *
		 * @param array $tree Panels with their sections.
		 */
		return apply_filters( 'mvweb_cz_baseline_tree', $tree );
	}
}

if ( ! function_exists( 'mvweb_cz_panel_groups' ) ) {
	/**
	 * Group titles of the panels, printed above them in the root list.
	 *
	 * A panel of the tree may carry a 'group' key; the title shows once, above
	 * the first panel of the group. Order and names of the panels stay as they
	 * are, the titles only say why they stand in that order.
	 *
	 * @since 1.2.0
	 *
	 * @return array<string,string> Panel id => group title.
	 */
	function mvweb_cz_panel_groups() {
		$groups = array();

		foreach ( mvweb_cz_baseline_tree() as $panel_id => $panel ) {
			if ( ! empty( $panel['group'] ) ) {
				$groups[ $panel_id ] = (string) $panel['group'];
			}
		}

		return $groups;
	}
}

if ( ! function_exists( 'mvweb_cz_socials' ) ) {
	/**
	 * Social networks offered by the profile: id => label.
	 *
	 * @since 1.0.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_cz_socials() {
		$socials = array(
			'vk'            => 'VK',
			'telegram'      => 'Telegram',
			'whatsapp'      => 'WhatsApp',
			'viber'         => 'Viber',
			'max'           => 'MAX',
			'facebook'      => 'Facebook',
			'instagram'     => 'Instagram',
			'x'             => 'X',
			'linkedin'      => 'LinkedIn',
			'tiktok'        => 'TikTok',
			'pinterest'     => 'Pinterest',
			'youtube'       => 'YouTube',
			'rutube'        => 'RuTube',
			'odnoklassniki' => 'Одноклассники',
			'dzen'          => 'Дзен',
		);

		/**
		 * Filter the social networks the profile offers.
		 *
		 * @since 1.0.0
		 *
		 * @param array<string,string> $socials Network id => label.
		 */
		return apply_filters( 'mvweb_cz_socials', $socials );
	}
}

if ( ! function_exists( 'mvweb_cz_chats' ) ) {
	/**
	 * Messengers a visitor writes to directly: id => label.
	 *
	 * A contact, not a channel: the link opens a chat with the business
	 * (t.me/name, wa.me/number). The same networks stay among the social
	 * networks for a channel or a group.
	 *
	 * @since 1.3.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_cz_chats() {
		$chats = array(
			'telegram' => 'Telegram',
			'whatsapp' => 'WhatsApp',
			'viber'    => 'Viber',
			'max'      => 'MAX',
		);

		/**
		 * Filter the messengers offered as contacts.
		 *
		 * @since 1.3.0
		 *
		 * @param array<string,string> $chats Messenger id => label.
		 */
		return apply_filters( 'mvweb_cz_chats', $chats );
	}
}

if ( ! function_exists( 'mvweb_cz_requisite_types' ) ) {
	/**
	 * Kinds of company details the profile offers: id => label.
	 *
	 * Kinds, not national codes: a tax number is ИНН in Russia, УНП in
	 * Belarus and NIP in Poland, and the owner types that word in the row.
	 * The kind's label is what the site prints when the row has none.
	 *
	 * @since 1.3.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_cz_requisite_types() {
		$types = array(
			'tax_id'       => 'Налоговый номер',
			'registration' => 'Регистрационный номер',
			'license'      => 'Лицензия',
			'certificate'  => 'Сертификат',
			'membership'   => 'Членство (СРО, ассоциация)',
			'bank'         => 'Банковские реквизиты',
			'other'        => 'Другое',
		);

		/**
		 * Filter the kinds of company details.
		 *
		 * @since 1.3.0
		 *
		 * @param array<string,string> $types Kind id => label.
		 */
		return apply_filters( 'mvweb_cz_requisite_types', $types );
	}
}

if ( ! function_exists( 'mvweb_cz_legacy_requisites' ) ) {
	/**
	 * Rows made of the fields the details list replaced.
	 *
	 * Before 1.3.0 the profile held two fixed Russian fields. A site that
	 * filled them keeps showing them until the owner saves the list.
	 *
	 * @since 1.3.0
	 *
	 * @return array<int,array<string,string>>
	 */
	function mvweb_cz_legacy_requisites() {
		$rows   = array();
		$legacy = array(
			'inn'  => array( 'tax_id', 'ИНН' ),
			'ogrn' => array( 'registration', 'ОГРН' ),
		);

		foreach ( $legacy as $key => $row ) {
			$value = trim( (string) get_theme_mod( 'mvweb_cz_' . $key, '' ) );

			if ( '' !== $value ) {
				$rows[] = array(
					'type'  => $row[0],
					'label' => $row[1],
					'value' => $value,
				);
			}
		}

		return $rows;
	}
}

if ( ! function_exists( 'mvweb_cz_profile_requisites' ) ) {
	/**
	 * Company details ready to print: rows of [ label, value ].
	 *
	 * @since 1.3.0
	 *
	 * @return array<int,array<string,string>>
	 */
	function mvweb_cz_profile_requisites() {
		$stored = get_theme_mod( 'mvweb_cz_requisites', null );
		$rows   = null === $stored ? mvweb_cz_legacy_requisites() : json_decode( (string) $stored, true );
		$types  = mvweb_cz_requisite_types();
		$out    = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$value = trim( (string) ( $row['value'] ?? '' ) );

			if ( '' === $value ) {
				continue;
			}

			$label = trim( (string) ( $row['label'] ?? '' ) );
			$type  = (string) ( $row['type'] ?? '' );

			if ( '' === $label && isset( $types[ $type ] ) && 'other' !== $type ) {
				$label = $types[ $type ];
			}

			$out[] = array(
				'label' => $label,
				'value' => $value,
			);
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_cz_baseline_fields' ) ) {
	/**
	 * The universal profile fields.
	 *
	 * Business details live in one place and are read by the header, the
	 * footer, contact blocks and any studio plugin, instead of being retyped
	 * per block.
	 *
	 * @since 1.0.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_cz_baseline_fields() {
		$chats = array();

		foreach ( mvweb_cz_chats() as $id => $label ) {
			$chats[] = array(
				'type'     => 'url',
				'settings' => 'mvweb_cz_chat_' . $id,
				'section'  => 'mvweb_cz_profile_contacts',
				'label'    => $label,
			);
		}

		$fields = array(
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_cz_phone',
				'section'     => 'mvweb_cz_profile_contacts',
				'label'       => 'Телефон',
				'description' => 'С кодом страны, например +7 900 000-00-00.',
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_cz_phone_extra',
				'section'  => 'mvweb_cz_profile_contacts',
				'label'    => 'Дополнительный телефон',
			),
			array(
				'type'              => 'text',
				'settings'          => 'mvweb_cz_email',
				'section'           => 'mvweb_cz_profile_contacts',
				'label'             => 'Электронная почта',
				'sanitize_callback' => 'sanitize_email',
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_cz_city',
				'section'  => 'mvweb_cz_profile_contacts',
				'label'    => 'Город',
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_cz_address',
				'section'     => 'mvweb_cz_profile_contacts',
				'label'       => 'Адрес',
				'description' => 'Улица, дом, офис.',
			),
			array(
				'type'        => 'heading',
				'settings'    => 'mvweb_cz_chats_heading',
				'section'     => 'mvweb_cz_profile_contacts',
				'label'       => 'Мессенджеры для связи',
				'description' => 'Ссылка на личный чат с компанией: t.me/имя, wa.me/79001234567. Каналы и группы — в «Соцсетях и мессенджерах».',
			),
			...$chats,
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_cz_schedule_weekdays',
				'section'     => 'mvweb_cz_profile_schedule',
				'label'       => 'Часы работы',
				'description' => 'Например: Пн-Пт 9:00-18:00',
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_cz_schedule_weekend',
				'section'     => 'mvweb_cz_profile_schedule',
				'label'       => 'Вторая строка графика',
				'description' => 'Например: Сб-Вс выходной',
			),
			array(
				'type'     => 'toggle',
				'settings' => 'mvweb_cz_schedule_round',
				'section'  => 'mvweb_cz_profile_schedule',
				'label'    => 'Работаем круглосуточно',
				'default'  => false,
			),
			array(
				'type'     => 'radio',
				'settings' => 'mvweb_cz_map_mode',
				'section'  => 'mvweb_cz_profile_legal',
				'label'    => 'Карта',
				'default'  => 'code',
				'choices'  => array(
					'code'  => 'Код карты',
					'image' => 'Картинка',
				),
			),
			array(
				'type'              => 'textarea',
				'settings'          => 'mvweb_cz_map',
				'section'           => 'mvweb_cz_profile_legal',
				'label'             => 'Код карты',
				'description'       => 'Код iframe из сервиса карт: Яндекс Карты, Google Maps, OpenStreetMap.',
				'sanitize_callback' => 'mvweb_cz_sanitize_map_embed',
				'required'          => array(
					array(
						'setting'  => 'mvweb_cz_map_mode',
						'operator' => '==',
						'value'    => 'code',
					),
				),
			),
			array(
				'type'        => 'image',
				'settings'    => 'mvweb_cz_map_image',
				'section'     => 'mvweb_cz_profile_legal',
				'label'       => 'Картинка карты',
				'description' => 'Статичная картинка грузится быстрее встроенной карты.',
				'required'    => array(
					array(
						'setting'  => 'mvweb_cz_map_mode',
						'operator' => '==',
						'value'    => 'image',
					),
				),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_cz_legal_name',
				'section'     => 'mvweb_cz_profile_legal',
				'label'       => 'Название организации',
				'description' => 'Как в регистрационных документах.',
			),
			array(
				'type'        => 'repeater',
				'settings'    => 'mvweb_cz_requisites',
				'section'     => 'mvweb_cz_profile_legal',
				'label'       => 'Реквизиты',
				'description' => 'Налоговый и регистрационный номер, лицензии, сертификаты.',
				'tooltip'     => 'Подпись — как принято в стране: ИНН, УНП, NIP, VAT. Пустая подпись выводит название типа.',
				'default'     => wp_json_encode( mvweb_cz_legacy_requisites() ),
				'row_label'   => 'label',
				'fields'      => array(
					'type'  => array(
						'type'    => 'select',
						'label'   => 'Тип',
						'choices' => mvweb_cz_requisite_types(),
					),
					'label' => array(
						'type'  => 'text',
						'label' => 'Подпись на сайте',
					),
					'value' => array(
						'type'  => 'text',
						'label' => 'Номер или текст',
					),
				),
			),
		);

		foreach ( mvweb_cz_socials() as $id => $label ) {
			$fields[] = array(
				'type'     => 'url',
				'settings' => 'mvweb_cz_social_' . $id,
				'section'  => 'mvweb_cz_profile_socials',
				'label'    => $label,
			);
		}

		/**
		 * Filter the baseline profile fields.
		 *
		 * @since 1.0.0
		 *
		 * @param array<int,array<string,mixed>> $fields Field definitions.
		 */
		return apply_filters( 'mvweb_cz_baseline_fields', $fields );
	}
}

if ( ! function_exists( 'mvweb_cz_baseline' ) ) {
	/**
	 * Register the baseline tree and its fields.
	 *
	 * @since 1.0.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_cz_baseline( $kit ) {
		foreach ( mvweb_cz_baseline_tree() as $panel_id => $panel ) {
			$kit->add_panel(
				$panel_id,
				array(
					'title'    => $panel['title'],
					'priority' => $panel['priority'],
				)
			);

			$priority = 10;

			foreach ( $panel['sections'] as $section_id => $title ) {
				$kit->add_section(
					$section_id,
					array(
						'title'    => $title,
						'panel'    => $panel_id,
						'priority' => $priority,
					)
				);

				$priority += 10;
			}
		}

		$kit->add_fields( mvweb_cz_baseline_fields() );
	}
}

if ( ! function_exists( 'mvweb_cz_sanitize_map_embed' ) ) {
	/**
	 * Sanitize a map embed, allowing a single iframe.
	 *
	 * WordPress strips iframes by default; a map embed is the one place a
	 * theme option legitimately needs one. Only users who can edit theme
	 * options reach this.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $value Raw markup.
	 *
	 * @return string
	 */
	function mvweb_cz_sanitize_map_embed( $value ) {
		return wp_kses(
			(string) $value,
			array(
				'iframe' => array(
					'src'             => true,
					'width'           => true,
					'height'          => true,
					'style'           => true,
					'frameborder'     => true,
					'allowfullscreen' => true,
					'allow'           => true,
					'loading'         => true,
					'title'           => true,
					'referrerpolicy'  => true,
				),
			)
		);
	}
}

if ( ! function_exists( 'mvweb_cz_profile' ) ) {
	/**
	 * Read one profile value.
	 *
	 * Stored sanitized, still escape on output. The 'map' key is the
	 * exception: it holds trusted markup already passed through wp_kses, so
	 * echo it directly and never wrap it in esc_html().
	 *
	 * @since 1.0.0
	 *
	 * @param string $key           Key without the mvweb_cz_ prefix.
	 * @param mixed  $default_value Fallback.
	 *
	 * @return mixed
	 */
	function mvweb_cz_profile( $key, $default_value = '' ) {
		return get_theme_mod( 'mvweb_cz_' . $key, $default_value );
	}
}

if ( ! function_exists( 'mvweb_cz_profile_chats' ) ) {
	/**
	 * Contact chats that have a link: id => [ url, label ].
	 *
	 * Read from the contact fields alone. The social link of the same
	 * messenger is a channel and never stands in for a chat.
	 *
	 * @since 1.3.0
	 *
	 * @return array<string,array<string,string>>
	 */
	function mvweb_cz_profile_chats() {
		$links = array();

		foreach ( mvweb_cz_chats() as $id => $label ) {
			$url = (string) mvweb_cz_profile( 'chat_' . $id );

			if ( '' !== $url ) {
				$links[ $id ] = array(
					'url'   => $url,
					'label' => $label,
				);
			}
		}

		return $links;
	}
}

if ( ! function_exists( 'mvweb_cz_profile_socials' ) ) {
	/**
	 * Social links that have a URL: id => [ url, label ].
	 *
	 * @since 1.0.0
	 *
	 * @return array<string,array<string,string>>
	 */
	function mvweb_cz_profile_socials() {
		$links = array();

		foreach ( mvweb_cz_socials() as $id => $label ) {
			$url = mvweb_cz_profile( 'social_' . $id );

			if ( '' !== $url ) {
				$links[ $id ] = array(
					'url'   => $url,
					'label' => $label,
				);
			}
		}

		return $links;
	}
}
