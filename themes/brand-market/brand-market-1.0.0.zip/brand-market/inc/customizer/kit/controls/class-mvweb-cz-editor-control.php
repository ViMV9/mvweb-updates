<?php
/**
 * Editor control — a rich text field inside the Customizer.
 *
 * Renders a plain textarea and lets kit-controls.js attach the editor through
 * wp.editor.initialize(). Calling wp_editor() here would print an editor into
 * a hidden section, where TinyMCE regularly fails to measure itself.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'MVweb_CZ_Control' ) && ! class_exists( 'MVweb_CZ_Editor_Control' ) ) {
	/**
	 * Rich text control.
	 *
	 * @since 1.0.0
	 */
	final class MVweb_CZ_Editor_Control extends MVweb_CZ_Control {

		/**
		 * Control type.
		 *
		 * @var string
		 */
		public $type = 'mvweb_cz_editor';

		/**
		 * Render the control's content.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function render_content() {
			?>
			<?php $this->render_header(); ?>
			<div class="mvweb-cz-editor">
				<textarea
					id="<?php echo esc_attr( $this->input_id() ); ?>"
					class="mvweb-cz-editor__input"
					rows="<?php echo esc_attr( $this->attr( 'rows', 8 ) ); ?>"
					<?php echo $this->describedby(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from esc_attr. ?>
					<?php $this->link(); ?>
				><?php echo esc_textarea( (string) $this->value() ); ?></textarea>
			</div>
			<?php
		}
	}
}
