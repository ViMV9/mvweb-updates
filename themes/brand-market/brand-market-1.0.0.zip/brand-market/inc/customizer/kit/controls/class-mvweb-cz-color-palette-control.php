<?php
/**
 * Colour palette control — pick one colour from a fixed set.
 *
 * Choice shape: slug => '#hex' or slug => [ 'color' => '#hex', 'label' => … ].
 * The saved value is the slug, not the colour, so a palette can be re-themed
 * later without rewriting stored options.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'MVweb_CZ_Control' ) && ! class_exists( 'MVweb_CZ_Color_Palette_Control' ) ) {
	/**
	 * Swatch picker.
	 *
	 * @since 1.0.0
	 */
	final class MVweb_CZ_Color_Palette_Control extends MVweb_CZ_Control {

		/**
		 * Control type.
		 *
		 * @var string
		 */
		public $type = 'mvweb_cz_color_palette';

		/**
		 * Render the control's content.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function render_content() {
			$value = (string) $this->value();
			$name  = '_customize-palette-' . $this->id;
			?>
			<?php $this->render_header( false ); ?>
			<?php $index = 0; ?>
			<fieldset class="mvweb-cz-palette">
				<legend class="screen-reader-text"><?php echo esc_html( $this->label ); ?></legend>
				<?php foreach ( (array) $this->choices as $slug => $choice ) : ?>
					<?php
					$color   = is_array( $choice ) && isset( $choice['color'] ) ? $choice['color'] : (string) $choice;
					$label   = is_array( $choice ) && isset( $choice['label'] ) ? $choice['label'] : (string) $slug;
					$item_id = $this->input_id() . '-' . $index;
					++$index;
					$color = mvweb_cz_sanitize_color( $color );
					?>
					<label class="mvweb-cz-palette__option" for="<?php echo esc_attr( $item_id ); ?>" title="<?php echo esc_attr( $label ); ?>">
						<input
							type="radio"
							id="<?php echo esc_attr( $item_id ); ?>"
							class="mvweb-cz-palette__input"
							name="<?php echo esc_attr( $name ); ?>"
							value="<?php echo esc_attr( $slug ); ?>"
							<?php checked( $value, (string) $slug ); ?>
							<?php $this->link(); ?>
						/>
						<span class="mvweb-cz-palette__swatch" style="background-color:<?php echo esc_attr( $color ); ?>" aria-hidden="true"></span>
						<span class="screen-reader-text"><?php echo esc_html( $label ); ?></span>
					</label>
				<?php endforeach; ?>
			</fieldset>
			<?php
		}
	}
}
