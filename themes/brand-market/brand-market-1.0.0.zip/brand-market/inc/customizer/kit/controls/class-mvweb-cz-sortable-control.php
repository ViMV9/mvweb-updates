<?php
/**
 * Sortable control — order and toggle a fixed list of items.
 *
 * Powers block order inside a zone. The value is a JSON array of the active
 * slugs in their chosen order; a disabled item is simply absent. It keeps its
 * place while the panel stays open, but the stored value carries no position
 * for it, so after a reload a disabled item appears at the end of the list.
 *
 * Rendered from a JS template (register_control_type), so no render_content().
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'MVweb_CZ_Control' ) && ! class_exists( 'MVweb_CZ_Sortable_Control' ) ) {
	/**
	 * Orderable, toggleable list.
	 *
	 * @since 1.0.0
	 */
	final class MVweb_CZ_Sortable_Control extends MVweb_CZ_Control {

		/**
		 * Control type.
		 *
		 * @var string
		 */
		public $type = 'mvweb_cz_sortable';

		/**
		 * Available items: slug => label.
		 *
		 * @var array
		 */
		public $choices = array();

		/**
		 * Pass items, active order and strings to the template.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function to_json() {
			parent::to_json();

			$this->json['choices'] = array_map( 'sanitize_text_field', (array) $this->choices );
			$this->json['order']   = array_values( array_filter( $this->value_array(), 'is_string' ) );
			$this->json['l10n']    = mvweb_cz_l10n();
		}

		/**
		 * Whole-control template.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		protected function content_template() {
			?>
			<# if ( data.label ) { #>
				<span class="customize-control-title">{{ data.label }}</span>
			<# } #>
			<div class="customize-control-notifications-container"></div>
			<# if ( data.description ) { #>
				<span class="description customize-control-description">{{{ data.description }}}</span>
			<# } #>

			<ul class="mvweb-cz-sortable__items"></ul>
			<input type="hidden" class="mvweb-cz-sortable__value" data-customize-setting-link="{{ data.settings['default'] }}" />
			<?php
		}
	}
}

if ( ! function_exists( 'mvweb_cz_sortable_item_template' ) ) {
	/**
	 * Print the per-item template once, in the Customizer footer.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function mvweb_cz_sortable_item_template() {
		?>
		<script type="text/html" id="tmpl-mvweb-cz-sortable-item">
			<li class="mvweb-cz-sortable__item" data-slug="{{ data.slug }}">
				<span class="mvweb-cz-sortable__handle dashicons dashicons-menu" aria-hidden="true"></span>
				<label class="mvweb-cz-sortable__label">
					<input type="checkbox" class="mvweb-cz-sortable__toggle" <# if ( data.active ) { #>checked<# } #> />
					<span class="mvweb-cz-sortable__name">{{ data.label }}</span>
				</label>
			</li>
		</script>
		<?php
	}
}
add_action( 'customize_controls_print_footer_scripts', 'mvweb_cz_sortable_item_template' );
