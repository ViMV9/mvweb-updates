<?php
/**
 * Typography control — family, size, weight, line height, spacing, transform.
 *
 * Stores one JSON object, so a whole type scale is a single setting and a
 * single output map with per-key rules:
 *
 *   'output' => array(
 *       array( 'element' => ':root', 'property' => '--h1-size',   'key' => 'size' ),
 *       array( 'element' => ':root', 'property' => '--h1-weight', 'key' => 'weight' ),
 *   )
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'MVweb_CZ_Control' ) && ! class_exists( 'MVweb_CZ_Typography_Control' ) ) {
	/**
	 * Grouped typography settings.
	 *
	 * @since 1.0.0
	 */
	final class MVweb_CZ_Typography_Control extends MVweb_CZ_Control {

		/**
		 * Control type.
		 *
		 * @var string
		 */
		public $type = 'mvweb_cz_typography';

		/**
		 * Font families offered, as label => CSS stack. Set with 'choices'.
		 *
		 * @var array
		 */
		public $choices = array();

		/**
		 * Font family options with a sane default stack list.
		 *
		 * @since 1.0.0
		 *
		 * @return array<string,string>
		 */
		private function families() {
			if ( ! empty( $this->choices ) ) {
				return (array) $this->choices;
			}

			return array(
				''                                    => mvweb_cz_text( 'inherit' ),
				'system-ui, -apple-system, "Segoe UI", sans-serif' => 'System UI',
				'Georgia, "Times New Roman", serif'   => 'Georgia',
				'"Helvetica Neue", Arial, sans-serif' => 'Helvetica',
				'ui-monospace, SFMono-Regular, Menlo, monospace' => 'Monospace',
			);
		}

		/**
		 * Render the control's content.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function render_content() {
			$value = $this->value_array();

			$get = static function ( $key ) use ( $value ) {
				return isset( $value[ $key ] ) ? (string) $value[ $key ] : '';
			};

			$weights    = array(
				''    => '—',
				'300' => '300',
				'400' => '400',
				'500' => '500',
				'600' => '600',
				'700' => '700',
				'800' => '800',
			);
			$transforms = array(
				'none'       => mvweb_cz_text( 'caseNone' ),
				'uppercase'  => mvweb_cz_text( 'caseUpper' ),
				'lowercase'  => mvweb_cz_text( 'caseLower' ),
				'capitalize' => mvweb_cz_text( 'caseTitle' ),
			);
			?>
			<?php $this->render_header( false ); ?>
			<fieldset class="mvweb-cz-typography">
				<legend class="screen-reader-text"><?php echo esc_html( $this->label ); ?></legend>

				<div class="mvweb-cz-field">
					<label class="mvweb-cz-field__label" for="<?php echo esc_attr( $this->input_id() ); ?>-family"><?php echo esc_html( mvweb_cz_text( 'fontFamily' ) ); ?></label>
					<select id="<?php echo esc_attr( $this->input_id() ); ?>-family" class="mvweb-cz-typography__input" data-key="family">
						<?php foreach ( $this->families() as $stack => $label ) : ?>
							<option value="<?php echo esc_attr( $stack ); ?>" <?php selected( $get( 'family' ), $stack ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<div class="mvweb-cz-row">
					<div class="mvweb-cz-field">
						<label class="mvweb-cz-field__label" for="<?php echo esc_attr( $this->input_id() ); ?>-size"><?php echo esc_html( mvweb_cz_text( 'fontSize' ) ); ?></label>
						<input type="text" id="<?php echo esc_attr( $this->input_id() ); ?>-size" class="mvweb-cz-typography__input" data-key="size" value="<?php echo esc_attr( $get( 'size' ) ); ?>" placeholder="16px" />
					</div>
					<div class="mvweb-cz-field">
						<label class="mvweb-cz-field__label" for="<?php echo esc_attr( $this->input_id() ); ?>-weight"><?php echo esc_html( mvweb_cz_text( 'fontWeight' ) ); ?></label>
						<select id="<?php echo esc_attr( $this->input_id() ); ?>-weight" class="mvweb-cz-typography__input" data-key="weight">
							<?php foreach ( $weights as $weight => $label ) : ?>
								<option value="<?php echo esc_attr( $weight ); ?>" <?php selected( $get( 'weight' ), $weight ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>

				<div class="mvweb-cz-row">
					<div class="mvweb-cz-field">
						<label class="mvweb-cz-field__label" for="<?php echo esc_attr( $this->input_id() ); ?>-lh"><?php echo esc_html( mvweb_cz_text( 'lineHeight' ) ); ?></label>
						<input type="text" id="<?php echo esc_attr( $this->input_id() ); ?>-lh" class="mvweb-cz-typography__input" data-key="line-height" value="<?php echo esc_attr( $get( 'line-height' ) ); ?>" placeholder="1.5" />
					</div>
					<div class="mvweb-cz-field">
						<label class="mvweb-cz-field__label" for="<?php echo esc_attr( $this->input_id() ); ?>-ls"><?php echo esc_html( mvweb_cz_text( 'letterSpacing' ) ); ?></label>
						<input type="text" id="<?php echo esc_attr( $this->input_id() ); ?>-ls" class="mvweb-cz-typography__input" data-key="letter-spacing" value="<?php echo esc_attr( $get( 'letter-spacing' ) ); ?>" placeholder="0" />
					</div>
				</div>

				<div class="mvweb-cz-field">
					<label class="mvweb-cz-field__label" for="<?php echo esc_attr( $this->input_id() ); ?>-tt"><?php echo esc_html( mvweb_cz_text( 'textTransform' ) ); ?></label>
					<select id="<?php echo esc_attr( $this->input_id() ); ?>-tt" class="mvweb-cz-typography__input" data-key="transform">
						<?php foreach ( $transforms as $transform => $label ) : ?>
							<option value="<?php echo esc_attr( $transform ); ?>" <?php selected( $get( 'transform' ), $transform ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<input
					type="hidden"
					class="mvweb-cz-typography__value"
					value="<?php echo esc_attr( (string) $this->value() ); ?>"
					<?php $this->link(); ?>
				/>
			</fieldset>
			<?php
		}
	}
}
