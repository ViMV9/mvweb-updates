<?php
/**
 * Radio image control — pick one option by its preview image.
 *
 * Choice shape: slug => [ 'label' => string, 'preview' => image URL ].
 * A plain string choice is treated as the label with no preview.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'MVweb_CZ_Control' ) && ! class_exists( 'MVweb_CZ_Radio_Image_Control' ) ) {
	/**
	 * Visual radio group.
	 *
	 * @since 1.0.0
	 */
	final class MVweb_CZ_Radio_Image_Control extends MVweb_CZ_Control {

		/**
		 * Control type.
		 *
		 * @var string
		 */
		public $type = 'mvweb_cz_radio_image';

		/**
		 * Render the control's content.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function render_content() {
			$value = (string) $this->value();
			$name  = '_customize-radio-image-' . $this->id;
			?>
			<?php $this->render_header( false ); ?>
			<?php $index = 0; ?>
			<fieldset class="mvweb-cz-radio-image">
				<legend class="screen-reader-text"><?php echo esc_html( $this->label ); ?></legend>
				<?php foreach ( (array) $this->choices as $slug => $choice ) : ?>
					<?php
					$label   = is_array( $choice ) && isset( $choice['label'] ) ? $choice['label'] : (string) $choice;
					$preview = is_array( $choice ) && isset( $choice['preview'] ) ? $choice['preview'] : '';
					$item_id = $this->input_id() . '-' . $index;
					++$index;
					?>
					<label class="mvweb-cz-radio-image__option" for="<?php echo esc_attr( $item_id ); ?>">
						<input
							type="radio"
							id="<?php echo esc_attr( $item_id ); ?>"
							class="mvweb-cz-radio-image__input"
							name="<?php echo esc_attr( $name ); ?>"
							value="<?php echo esc_attr( $slug ); ?>"
							<?php checked( $value, (string) $slug ); ?>
							<?php $this->link(); ?>
						/>
						<?php if ( '' !== $preview ) : ?>
							<img class="mvweb-cz-radio-image__preview" src="<?php echo esc_url( $preview ); ?>" alt="" />
						<?php endif; ?>
						<span class="mvweb-cz-radio-image__label"><?php echo esc_html( $label ); ?></span>
					</label>
				<?php endforeach; ?>
			</fieldset>
			<?php
		}
	}
}
