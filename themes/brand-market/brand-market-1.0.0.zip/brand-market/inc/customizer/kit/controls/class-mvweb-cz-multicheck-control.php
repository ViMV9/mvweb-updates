<?php
/**
 * Multicheck control — several checkboxes stored as one JSON array.
 *
 * A group of inputs, so the title is a <span> and the checkboxes sit inside a
 * <fieldset> with a screen-reader <legend>, matching how core renders groups.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'MVweb_CZ_Control' ) && ! class_exists( 'MVweb_CZ_Multicheck_Control' ) ) {
	/**
	 * Multiple checkboxes in a single setting.
	 *
	 * @since 1.0.0
	 */
	final class MVweb_CZ_Multicheck_Control extends MVweb_CZ_Control {

		/**
		 * Control type.
		 *
		 * @var string
		 */
		public $type = 'mvweb_cz_multicheck';

		/**
		 * Render the control's content.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function render_content() {
			$selected = $this->value_array();
			?>
			<?php $this->render_header( false ); ?>
			<?php $index = 0; ?>
			<fieldset class="mvweb-cz-multicheck">
				<legend class="screen-reader-text"><?php echo esc_html( $this->label ); ?></legend>
				<?php foreach ( (array) $this->choices as $slug => $label ) : ?>
					<?php
					$item_id = $this->input_id() . '-' . $index;
					++$index;
					?>
					<span class="mvweb-cz-multicheck__item">
						<input
							type="checkbox"
							id="<?php echo esc_attr( $item_id ); ?>"
							class="mvweb-cz-multicheck__input"
							value="<?php echo esc_attr( $slug ); ?>"
							<?php checked( in_array( (string) $slug, $selected, true ) ); ?>
						/>
						<label for="<?php echo esc_attr( $item_id ); ?>"><?php echo esc_html( $label ); ?></label>
					</span>
				<?php endforeach; ?>
				<input
					type="hidden"
					class="mvweb-cz-multicheck__value"
					value="<?php echo esc_attr( (string) $this->value() ); ?>"
					<?php $this->link(); ?>
				/>
			</fieldset>
			<?php
		}
	}
}
