<?php
/**
 * Range control — slider plus an editable number field and a reset button.
 *
 * WordPress ships no styling for input[type=range] at all, so the visual side
 * lives entirely in kit.css. The range input carries the setting link; the
 * number input is a mirror kept in sync by kit-controls.js.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'MVweb_CZ_Control' ) && ! class_exists( 'MVweb_CZ_Range_Control' ) ) {
	/**
	 * Slider with numeric input.
	 *
	 * @since 1.0.0
	 */
	final class MVweb_CZ_Range_Control extends MVweb_CZ_Control {

		/**
		 * Control type.
		 *
		 * @var string
		 */
		public $type = 'mvweb_cz_range';

		/**
		 * Render the control's content.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function render_content() {
			$min   = $this->attr( 'min', 0 );
			$max   = $this->attr( 'max', 100 );
			$step  = $this->attr( 'step', 1 );
			$value = $this->value();
			$reset = ( null !== $this->setting ) ? $this->setting->default : '';
			?>
			<?php $this->render_header(); ?>
			<div class="mvweb-cz-range" data-reset="<?php echo esc_attr( $reset ); ?>">
				<input
					type="range"
					id="<?php echo esc_attr( $this->input_id() ); ?>"
					class="mvweb-cz-range__slider"
					min="<?php echo esc_attr( $min ); ?>"
					max="<?php echo esc_attr( $max ); ?>"
					step="<?php echo esc_attr( $step ); ?>"
					value="<?php echo esc_attr( $value ); ?>"
					<?php echo $this->describedby(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from esc_attr. ?>
					<?php $this->print_input_attrs( array( 'min', 'max', 'step' ) ); ?>
					<?php $this->link(); ?>
				/>
				<input
					type="number"
					class="mvweb-cz-range__number"
					min="<?php echo esc_attr( $min ); ?>"
					max="<?php echo esc_attr( $max ); ?>"
					step="<?php echo esc_attr( $step ); ?>"
					value="<?php echo esc_attr( $value ); ?>"
					aria-label="<?php echo esc_attr( $this->label ); ?>"
				/>
				<button type="button" class="mvweb-cz-range__reset" title="<?php echo esc_attr( mvweb_cz_text( 'reset' ) ); ?>">
					<span class="dashicons dashicons-image-rotate" aria-hidden="true"></span>
					<span class="screen-reader-text"><?php echo esc_html( mvweb_cz_text( 'reset' ) ); ?></span>
				</button>
			</div>
			<?php
		}
	}
}
