<?php
/**
 * Radio buttonset — radio inputs painted as a segmented button group.
 *
 * No JavaScript: native radios carry the setting link, the visual side is CSS
 * only, so keyboard and screen-reader behaviour are the platform's.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'MVweb_CZ_Control' ) && ! class_exists( 'MVweb_CZ_Radio_Buttonset_Control' ) ) {
	/**
	 * Segmented radio group.
	 *
	 * @since 1.0.0
	 */
	final class MVweb_CZ_Radio_Buttonset_Control extends MVweb_CZ_Control {

		/**
		 * Control type.
		 *
		 * @var string
		 */
		public $type = 'mvweb_cz_radio_buttonset';

		/**
		 * Render the control's content.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function render_content() {
			$value = (string) $this->value();
			$name  = '_customize-radio-' . $this->id;
			?>
			<?php $this->render_header( false ); ?>
			<?php $index = 0; ?>
			<fieldset class="mvweb-cz-buttonset">
				<legend class="screen-reader-text"><?php echo esc_html( $this->label ); ?></legend>
				<?php foreach ( (array) $this->choices as $slug => $label ) : ?>
					<?php
					$item_id = $this->input_id() . '-' . $index;
					++$index;
					?>
					<input
						type="radio"
						id="<?php echo esc_attr( $item_id ); ?>"
						class="mvweb-cz-buttonset__input"
						name="<?php echo esc_attr( $name ); ?>"
						value="<?php echo esc_attr( $slug ); ?>"
						<?php checked( $value, (string) $slug ); ?>
						<?php $this->link(); ?>
					/>
					<label class="mvweb-cz-buttonset__label" for="<?php echo esc_attr( $item_id ); ?>"><?php echo esc_html( $label ); ?></label>
				<?php endforeach; ?>
			</fieldset>
			<?php
		}
	}
}
