<?php
/**
 * Base class for Kit controls.
 *
 * Provides the header markup every control shares — title, notifications
 * container, description — in the exact shape core uses, so Kit controls sit
 * in the panel like native ones and the notification system finds its anchor.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'WP_Customize_Control' ) && ! class_exists( 'MVweb_CZ_Control' ) ) {
	/**
	 * Shared base for every Kit control.
	 *
	 * @since 1.0.0
	 */
	abstract class MVweb_CZ_Control extends WP_Customize_Control {

		/**
		 * Id of the visible input, used for the label's "for" attribute.
		 *
		 * @since 1.0.0
		 *
		 * @return string
		 */
		protected function input_id() {
			return '_customize-input-' . $this->id;
		}

		/**
		 * Id of the description element, referenced by aria-describedby.
		 *
		 * @since 1.0.0
		 *
		 * @return string
		 */
		protected function description_id() {
			return '_customize-description-' . $this->id;
		}

		/**
		 * The aria-describedby attribute, or an empty string.
		 *
		 * @since 1.0.0
		 *
		 * @return string
		 */
		protected function describedby() {
			if ( '' === (string) $this->description ) {
				return '';
			}

			return ' aria-describedby="' . esc_attr( $this->description_id() ) . '"';
		}

		/**
		 * Print the control header.
		 *
		 * @since 1.0.0
		 *
		 * @param bool $as_label Whether the title is a <label for> (single input)
		 *                       or a <span> (group of inputs).
		 *
		 * @return void
		 */
		protected function render_header( $as_label = true ) {
			if ( '' !== (string) $this->label ) {
				if ( $as_label ) {
					printf(
						'<label for="%s" class="customize-control-title">%s</label>',
						esc_attr( $this->input_id() ),
						esc_html( $this->label )
					);
				} else {
					printf(
						'<span class="customize-control-title">%s</span>',
						esc_html( $this->label )
					);
				}
			}

			echo '<div class="customize-control-notifications-container"></div>';

			if ( '' !== (string) $this->description ) {
				printf(
					'<span id="%s" class="description customize-control-description">%s</span>',
					esc_attr( $this->description_id() ),
					wp_kses_post( $this->description )
				);
			}
		}

		/**
		 * Print the declared input attributes.
		 *
		 * Core prints attribute names unescaped; the Kit escapes both sides
		 * because input_attrs may come from a plugin-supplied field.
		 *
		 * @since 1.0.0
		 *
		 * @param array $skip Attribute names to omit.
		 *
		 * @return void
		 */
		protected function print_input_attrs( $skip = array() ) {
			foreach ( (array) $this->input_attrs as $attr => $value ) {
				if ( in_array( $attr, $skip, true ) ) {
					continue;
				}

				$attr = preg_replace( '/[^a-z0-9_-]/', '', strtolower( (string) $attr ) );

				if ( '' === $attr ) {
					continue;
				}

				printf( ' %s="%s"', esc_attr( $attr ), esc_attr( $value ) );
			}
		}

		/**
		 * Read one input attribute with a fallback.
		 *
		 * @since 1.0.0
		 *
		 * @param string $key           Attribute name.
		 * @param mixed  $default_value Fallback.
		 *
		 * @return mixed
		 */
		protected function attr( $key, $default_value = '' ) {
			return isset( $this->input_attrs[ $key ] ) ? $this->input_attrs[ $key ] : $default_value;
		}

		/**
		 * Decode a JSON-stored value into an array.
		 *
		 * @since 1.0.0
		 *
		 * @return array
		 */
		protected function value_array() {
			$data = json_decode( (string) $this->value(), true );

			return is_array( $data ) ? $data : array();
		}
	}
}
