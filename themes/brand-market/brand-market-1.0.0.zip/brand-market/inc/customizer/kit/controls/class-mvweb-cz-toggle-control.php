<?php
/**
 * Toggle control — an accessible switch on top of a real checkbox.
 *
 * The checkbox itself stays in the accessibility tree and in tab order; only
 * its painting is replaced. Hiding it with display:none, as several published
 * toggle controls do, removes it from both.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'MVweb_CZ_Control' ) && ! class_exists( 'MVweb_CZ_Toggle_Control' ) ) {
	/**
	 * Switch-styled checkbox.
	 *
	 * @since 1.0.0
	 */
	final class MVweb_CZ_Toggle_Control extends MVweb_CZ_Control {

		/**
		 * Control type.
		 *
		 * @var string
		 */
		public $type = 'mvweb_cz_toggle';

		/**
		 * Render the control's content.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function render_content() {
			$checked = (bool) $this->value();
			?>
			<div class="mvweb-cz-toggle">
				<div class="mvweb-cz-toggle__text">
					<?php if ( '' !== (string) $this->label ) : ?>
						<label for="<?php echo esc_attr( $this->input_id() ); ?>" class="customize-control-title"><?php echo esc_html( $this->label ); ?></label>
					<?php endif; ?>
					<div class="customize-control-notifications-container"></div>
					<?php if ( '' !== (string) $this->description ) : ?>
						<span id="<?php echo esc_attr( $this->description_id() ); ?>" class="description customize-control-description"><?php echo wp_kses_post( $this->description ); ?></span>
					<?php endif; ?>
				</div>
				<span class="mvweb-cz-toggle__switch">
					<input
						type="checkbox"
						id="<?php echo esc_attr( $this->input_id() ); ?>"
						class="mvweb-cz-toggle__input"
						value="1"
						<?php echo $this->describedby(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from esc_attr. ?>
						<?php checked( $checked ); ?>
						<?php $this->link(); ?>
					/>
					<span class="mvweb-cz-toggle__track" aria-hidden="true"></span>
				</span>
			</div>
			<?php
		}
	}
}
