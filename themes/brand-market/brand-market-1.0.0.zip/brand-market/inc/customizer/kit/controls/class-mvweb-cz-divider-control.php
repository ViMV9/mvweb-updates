<?php
/**
 * Divider control — a horizontal rule between groups of fields.
 *
 * Owns no setting.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'MVweb_CZ_Control' ) && ! class_exists( 'MVweb_CZ_Divider_Control' ) ) {
	/**
	 * Visual separator.
	 *
	 * @since 1.0.0
	 */
	final class MVweb_CZ_Divider_Control extends MVweb_CZ_Control {

		/**
		 * Control type.
		 *
		 * @var string
		 */
		public $type = 'mvweb_cz_divider';

		/**
		 * Render the control's content.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function render_content() {
			echo '<hr class="mvweb-cz-divider" />';
		}
	}
}
