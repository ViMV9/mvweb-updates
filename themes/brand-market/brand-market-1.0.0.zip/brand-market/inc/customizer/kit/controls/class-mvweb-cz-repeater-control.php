<?php
/**
 * Repeater control — a list of rows with typed subfields.
 *
 * Rendered from a JS template (register_control_type), so this class must not
 * implement render_content(). The whole list is stored as one JSON string in a
 * single hidden input: one setting link, one sanitizer, no array juggling in
 * $_POST.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'MVweb_CZ_Control' ) && ! class_exists( 'MVweb_CZ_Repeater_Control' ) ) {
	/**
	 * Repeatable rows.
	 *
	 * @since 1.0.0
	 */
	final class MVweb_CZ_Repeater_Control extends MVweb_CZ_Control {

		/**
		 * Control type.
		 *
		 * @var string
		 */
		public $type = 'mvweb_cz_repeater';

		/**
		 * Subfield schema: key => [ type, label, choices ].
		 *
		 * @var array
		 */
		public $fields = array();

		/**
		 * Subfield whose value names the row in the collapsed header.
		 *
		 * Empty means "first subfield holding something readable", which is
		 * right for lists that start with a name and wrong for lists that
		 * start with a picture or a page picker.
		 *
		 * @var string
		 */
		public $row_label = '';

		/**
		 * Pass the schema, the rows and the UI strings to the template.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function to_json() {
			parent::to_json();

			$fields = array();

			foreach ( (array) $this->fields as $key => $field ) {
				$fields[ $key ] = array(
					'type'    => isset( $field['type'] ) ? $field['type'] : 'text',
					'label'   => isset( $field['label'] ) ? $field['label'] : $key,
					'choices' => isset( $field['choices'] ) ? $field['choices'] : array(),
				);
			}

			$this->json['fields']   = $fields;
			$this->json['rows']     = $this->value_array();
			$this->json['rowLabel'] = (string) $this->row_label;
			$this->json['l10n']     = mvweb_cz_l10n();
		}

		/**
		 * Whole-control template.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		protected function content_template() {
			?>
			<# if ( data.label ) { #>
				<span class="customize-control-title">{{ data.label }}</span>
			<# } #>
			<div class="customize-control-notifications-container"></div>
			<# if ( data.description ) { #>
				<span class="description customize-control-description">{{{ data.description }}}</span>
			<# } #>

			<ul class="mvweb-cz-repeater__rows"></ul>
			<button type="button" class="button mvweb-cz-repeater__add">{{ data.l10n.add }}</button>
			<input type="hidden" class="mvweb-cz-repeater__value" data-customize-setting-link="{{ data.settings['default'] }}" />
			<?php
		}
	}
}

if ( ! function_exists( 'mvweb_cz_repeater_row_template' ) ) {
	/**
	 * Print the per-row template once, in the Customizer footer.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function mvweb_cz_repeater_row_template() {
		?>
		<script type="text/html" id="tmpl-mvweb-cz-repeater-row">
			<li class="mvweb-cz-repeater__row{{ data.collapsed ? ' is-collapsed' : '' }}" data-index="{{ data.index }}">
				<div class="mvweb-cz-repeater__head">
					<span class="mvweb-cz-repeater__handle dashicons dashicons-menu" aria-hidden="true"></span>
					<button type="button" class="mvweb-cz-repeater__toggle" aria-expanded="{{ data.collapsed ? 'false' : 'true' }}" aria-controls="mvweb-cz-{{ data.uid }}-{{ data.index }}-body">
						<span class="mvweb-cz-repeater__title">{{ data.title }}</span>
						<span class="mvweb-cz-repeater__chevron dashicons dashicons-arrow-down" aria-hidden="true"></span>
					</button>
					<button type="button" class="mvweb-cz-repeater__remove" aria-label="{{ data.l10n.remove }}">
						<span class="dashicons dashicons-trash" aria-hidden="true"></span>
					</button>
				</div>
				<div class="mvweb-cz-repeater__body" id="mvweb-cz-{{ data.uid }}-{{ data.index }}-body">
					<# _.each( data.fields, function ( field, key ) { #>
						<# var value = ( data.row[ key ] !== undefined ) ? data.row[ key ] : ''; #>
						<div class="mvweb-cz-field mvweb-cz-repeater__field" data-key="{{ key }}">
							<label class="mvweb-cz-field__label" for="mvweb-cz-{{ data.uid }}-{{ data.index }}-{{ key }}">{{ field.label }}</label>

							<# if ( 'textarea' === field.type ) { #>
								<textarea id="mvweb-cz-{{ data.uid }}-{{ data.index }}-{{ key }}" class="mvweb-cz-repeater__input" rows="3">{{ value }}</textarea>

							<# } else if ( 'select' === field.type ) { #>
								<select id="mvweb-cz-{{ data.uid }}-{{ data.index }}-{{ key }}" class="mvweb-cz-repeater__input">
									<# _.each( field.choices, function ( label, slug ) { #>
										<option value="{{ slug }}" <# if ( String( value ) === String( slug ) ) { #>selected<# } #>>{{ label }}</option>
									<# } ); #>
								</select>

							<# } else if ( 'image' === field.type ) { #>
								<#
								/*
								 * The value here is an attachment id, not an address, so the
								 * template has nothing to put in src. The control fills the
								 * preview in after rendering, once the media library has been
								 * asked what that id looks like.
								 */
								#>
								<div class="mvweb-cz-repeater__image">
									<# if ( value ) { #>
										<img alt="" hidden />
									<# } #>
									<input type="hidden" class="mvweb-cz-repeater__input" value="{{ value }}" />
									<button type="button" class="button button-small mvweb-cz-repeater__pick">{{ value ? data.l10n.changeImage : data.l10n.selectImage }}</button>
									<# if ( value ) { #>
										<button type="button" class="button-link mvweb-cz-repeater__unpick">{{ data.l10n.removeImage }}</button>
									<# } #>
								</div>

							<# } else if ( 'color' === field.type ) { #>
								<input id="mvweb-cz-{{ data.uid }}-{{ data.index }}-{{ key }}" type="text" class="mvweb-cz-repeater__input mvweb-cz-repeater__color" value="{{ value }}" />

							<# } else { #>
								<input id="mvweb-cz-{{ data.uid }}-{{ data.index }}-{{ key }}" type="{{ 'url' === field.type ? 'url' : 'text' }}" class="mvweb-cz-repeater__input" value="{{ value }}" />
							<# } #>
						</div>
					<# } ); #>
				</div>
			</li>
		</script>
		<?php
	}
}
add_action( 'customize_controls_print_footer_scripts', 'mvweb_cz_repeater_row_template' );
