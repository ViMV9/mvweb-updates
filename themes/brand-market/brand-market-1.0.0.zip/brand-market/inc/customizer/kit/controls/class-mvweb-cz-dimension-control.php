<?php
/**
 * Dimension control — a number and a unit, stored as one CSS length.
 *
 * Value is a plain string such as "24px". The visible number and unit inputs
 * are joined by kit-controls.js into the hidden input that carries the link.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'MVweb_CZ_Control' ) && ! class_exists( 'MVweb_CZ_Dimension_Control' ) ) {
	/**
	 * Number plus unit.
	 *
	 * @since 1.0.0
	 */
	final class MVweb_CZ_Dimension_Control extends MVweb_CZ_Control {

		/**
		 * Control type.
		 *
		 * @var string
		 */
		public $type = 'mvweb_cz_dimension';

		/**
		 * Available units. Overridden with the 'choices' field key.
		 *
		 * @var array
		 */
		public $choices = array();

		/**
		 * Render the control's content.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function render_content() {
			$units = ! empty( $this->choices ) ? array_values( (array) $this->choices ) : array( 'px', 'rem', 'em', '%' );
			$value = trim( (string) $this->value() );

			preg_match( '/^(-?\d*\.?\d*)\s*([a-z%]*)$/i', $value, $parts );

			$number = isset( $parts[1] ) ? $parts[1] : '';
			$unit   = ( isset( $parts[2] ) && '' !== $parts[2] ) ? $parts[2] : reset( $units );
			?>
			<?php $this->render_header(); ?>
			<div class="mvweb-cz-dimension">
				<input
					type="number"
					id="<?php echo esc_attr( $this->input_id() ); ?>"
					class="mvweb-cz-dimension__number"
					value="<?php echo esc_attr( $number ); ?>"
					step="<?php echo esc_attr( $this->attr( 'step', 1 ) ); ?>"
					<?php echo $this->describedby(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from esc_attr. ?>
					<?php $this->print_input_attrs( array( 'step' ) ); ?>
				/>
				<select class="mvweb-cz-dimension__unit" aria-label="<?php echo esc_attr( mvweb_cz_text( 'unit' ) ); ?>">
					<?php foreach ( $units as $option ) : ?>
						<option value="<?php echo esc_attr( $option ); ?>" <?php selected( $unit, $option ); ?>><?php echo esc_html( $option ); ?></option>
					<?php endforeach; ?>
				</select>
				<input
					type="hidden"
					class="mvweb-cz-dimension__value"
					value="<?php echo esc_attr( $value ); ?>"
					<?php $this->link(); ?>
				/>
			</div>
			<?php
		}
	}
}
