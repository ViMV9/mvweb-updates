<?php
/**
 * Heading control — a titled group separator inside a section.
 *
 * Owns no setting. Long sections become unreadable without them, which is why
 * Service Lux ended up with 245 Kirki headline fields.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'MVweb_CZ_Control' ) && ! class_exists( 'MVweb_CZ_Heading_Control' ) ) {
	/**
	 * Group heading.
	 *
	 * @since 1.0.0
	 */
	final class MVweb_CZ_Heading_Control extends MVweb_CZ_Control {

		/**
		 * Control type.
		 *
		 * @var string
		 */
		public $type = 'mvweb_cz_heading';

		/**
		 * Render the control's content.
		 *
		 * @since 1.0.0
		 *
		 * @return void
		 */
		public function render_content() {
			?>
			<div class="mvweb-cz-heading">
				<h3 class="mvweb-cz-heading__title"><?php echo esc_html( $this->label ); ?></h3>
				<?php if ( '' !== (string) $this->description ) : ?>
					<p class="mvweb-cz-heading__text"><?php echo wp_kses_post( $this->description ); ?></p>
				<?php endif; ?>
			</div>
			<?php
		}
	}
}
