<?php
/**
 * Type-to-control mapping and selective refresh registration.
 *
 * Every field type resolves either to a native WP_Customize_*_Control or to a
 * Kit control class in controls/. Kit controls follow one rule: a control that
 * calls register_control_type() must implement content_template() and must NOT
 * implement render_content() — WordPress overwrites the server-rendered HTML
 * with the JS template, leaving an empty control otherwise.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_cz_control_class' ) ) {
	/**
	 * Kit control class per field type, or null for native handling.
	 *
	 * @since 1.0.0
	 *
	 * @param string $type Field type.
	 *
	 * @return string|null
	 */
	function mvweb_cz_control_class( $type ) {
		$map = array(
			'toggle'          => 'MVweb_CZ_Toggle_Control',
			'range'           => 'MVweb_CZ_Range_Control',
			'multicheck'      => 'MVweb_CZ_Multicheck_Control',
			'radio_buttonset' => 'MVweb_CZ_Radio_Buttonset_Control',
			'radio_image'     => 'MVweb_CZ_Radio_Image_Control',
			'color_palette'   => 'MVweb_CZ_Color_Palette_Control',
			'dimension'       => 'MVweb_CZ_Dimension_Control',
			'typography'      => 'MVweb_CZ_Typography_Control',
			'editor'          => 'MVweb_CZ_Editor_Control',
			'repeater'        => 'MVweb_CZ_Repeater_Control',
			'sortable'        => 'MVweb_CZ_Sortable_Control',
			'heading'         => 'MVweb_CZ_Heading_Control',
			'divider'         => 'MVweb_CZ_Divider_Control',
		);

		return isset( $map[ $type ] ) ? $map[ $type ] : null;
	}
}

if ( ! function_exists( 'mvweb_cz_templated_controls' ) ) {
	/**
	 * Kit controls rendered from a JS template (register_control_type).
	 *
	 * @since 1.0.0
	 *
	 * @return array<int,string>
	 */
	function mvweb_cz_templated_controls() {
		return array( 'MVweb_CZ_Repeater_Control', 'MVweb_CZ_Sortable_Control' );
	}
}

if ( ! function_exists( 'mvweb_cz_require_control' ) ) {
	/**
	 * Load a Kit control class on demand.
	 *
	 * @since 1.0.0
	 *
	 * @param string $class_name Control class name.
	 *
	 * @return bool Whether the class is available.
	 */
	function mvweb_cz_require_control( $class_name ) {
		if ( class_exists( $class_name ) ) {
			return true;
		}

		require_once __DIR__ . '/controls/class-mvweb-cz-control.php';

		$file = __DIR__ . '/controls/class-' . str_replace( '_', '-', strtolower( $class_name ) ) . '.php';

		if ( is_readable( $file ) ) {
			require_once $file;
		}

		return class_exists( $class_name );
	}
}

if ( ! function_exists( 'mvweb_cz_control_args' ) ) {
	/**
	 * Build the argument array shared by every control.
	 *
	 * @since 1.0.0
	 *
	 * @param array $field Normalized field.
	 *
	 * @return array
	 */
	function mvweb_cz_control_args( array $field ) {
		$args = array(
			'label'       => $field['label'],
			'description' => $field['description'],
			'section'     => $field['section'],
			'priority'    => $field['priority'],
		);

		if ( ! mvweb_cz_is_decoration( $field['type'] ) ) {
			$args['settings'] = $field['settings'];
		} else {
			$args['settings'] = array();
		}

		if ( ! empty( $field['input_attrs'] ) ) {
			$args['input_attrs'] = $field['input_attrs'];
		}

		if ( is_callable( $field['active_callback'] ) ) {
			$args['active_callback'] = $field['active_callback'];
		}

		return $args;
	}
}

if ( ! function_exists( 'mvweb_cz_register_control' ) ) {
	/**
	 * Instantiate and register the control for a normalized field.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer manager.
	 * @param array                $field        Normalized field.
	 * @param int                  $index        Declaration index, used to keep
	 *                                           decoration ids unique.
	 *
	 * @return void
	 */
	function mvweb_cz_register_control( $wp_customize, array $field, $index = 0 ) {
		$args       = mvweb_cz_control_args( $field );
		$control_id = mvweb_cz_is_decoration( $field['type'] )
			? 'mvweb_cz_' . $field['type'] . '_' . (int) $index
			: $field['settings'];

		$class_name = mvweb_cz_control_class( $field['type'] );

		if ( null !== $class_name && mvweb_cz_require_control( $class_name ) ) {
			if ( in_array( $class_name, mvweb_cz_templated_controls(), true ) ) {
				$wp_customize->register_control_type( $class_name );
			}

			if ( ! empty( $field['choices'] ) ) {
				$args['choices'] = $field['choices'];
			}

			if ( ! empty( $field['fields'] ) ) {
				$args['fields'] = $field['fields'];
			}

			if ( ! empty( $field['row_label'] ) ) {
				$args['row_label'] = $field['row_label'];
			}

			$wp_customize->add_control( new $class_name( $wp_customize, $control_id, $args ) );

			return;
		}

		switch ( $field['type'] ) {
			case 'color':
				$wp_customize->add_control(
					new WP_Customize_Color_Control( $wp_customize, $control_id, $args )
				);
				break;

			case 'image':
				$wp_customize->add_control(
					new WP_Customize_Image_Control( $wp_customize, $control_id, $args )
				);
				break;

			case 'media':
				$wp_customize->add_control(
					new WP_Customize_Media_Control( $wp_customize, $control_id, $args )
				);
				break;

			case 'code':
				$wp_customize->add_control(
					new WP_Customize_Code_Editor_Control(
						$wp_customize,
						$control_id,
						$args + array(
							'code_type' => isset( $field['choices']['language'] ) ? $field['choices']['language'] : 'text/css',
						)
					)
				);
				break;

			case 'select':
			case 'radio':
				$wp_customize->add_control(
					$control_id,
					$args + array(
						'type'    => $field['type'],
						'choices' => $field['choices'],
					)
				);
				break;

			case 'dropdown_pages':
				$wp_customize->add_control(
					$control_id,
					$args + array( 'type' => 'dropdown-pages' )
				);
				break;

			case 'checkbox':
				$wp_customize->add_control( $control_id, $args + array( 'type' => 'checkbox' ) );
				break;

			case 'textarea':
				$wp_customize->add_control( $control_id, $args + array( 'type' => 'textarea' ) );
				break;

			case 'url':
				$wp_customize->add_control( $control_id, $args + array( 'type' => 'url' ) );
				break;

			case 'number':
				$wp_customize->add_control( $control_id, $args + array( 'type' => 'number' ) );
				break;

			default:
				$wp_customize->add_control( $control_id, $args + array( 'type' => 'text' ) );
				break;
		}
	}
}

if ( ! function_exists( 'mvweb_cz_register_partial' ) ) {
	/**
	 * Register a selective refresh partial declared by a field.
	 *
	 * Partial shape:
	 *   'partial' => array(
	 *       'selector'            => '.site-footer',
	 *       'render_callback'     => 'my_render_footer',
	 *       'container_inclusive' => true,   // optional
	 *       'fallback_refresh'    => true,   // optional
	 *   )
	 *
	 * @since 1.0.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer manager.
	 * @param array                $field        Normalized field.
	 *
	 * @return void
	 */
	function mvweb_cz_register_partial( $wp_customize, array $field ) {
		if ( empty( $field['partial'] ) || ! isset( $wp_customize->selective_refresh ) ) {
			return;
		}

		$partial = $field['partial'];

		if ( empty( $partial['selector'] ) || empty( $partial['render_callback'] ) ) {
			return;
		}

		$wp_customize->selective_refresh->add_partial(
			$field['settings'],
			array(
				'selector'            => $partial['selector'],
				'settings'            => array( $field['settings'] ),
				'render_callback'     => $partial['render_callback'],
				'container_inclusive' => ! empty( $partial['container_inclusive'] ),
				'fallback_refresh'    => ! isset( $partial['fallback_refresh'] ) || (bool) $partial['fallback_refresh'],
			)
		);
	}
}
