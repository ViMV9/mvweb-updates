<?php
/**
 * Field schema: normalization, transport resolution and default sanitizers.
 *
 * A field is a plain array. Only the keys listed in mvweb_cz_field_defaults()
 * are understood; anything else is ignored. The schema is the contract every
 * MVweb theme writes against, so it is kept small and explicit.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_cz_field_defaults' ) ) {
	/**
	 * The full field schema with its defaults.
	 *
	 * @since 1.0.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_cz_field_defaults() {
		return array(
			'type'              => 'text',
			'settings'          => '',
			'section'           => '',
			'label'             => '',
			'description'       => '',
			'default'           => '',
			'choices'           => array(),
			'fields'            => array(),
			'row_label'         => '',
			'priority'          => 10,
			'transport'         => null,
			'sanitize_callback' => null,
			'output'            => array(),
			'active_callback'   => null,
			'input_attrs'       => array(),
			'required'          => array(),
			'partial'           => array(),
			'tooltip'           => '',
			'device'            => '',
			'device_group'      => '',
			'collapsible'       => false,
			'collapsed'         => false,
			'summary'           => array(),
			'toggle'            => '',
		);
	}
}

if ( ! function_exists( 'mvweb_cz_decoration_types' ) ) {
	/**
	 * Field types that render UI but own no setting.
	 *
	 * @since 1.0.0
	 *
	 * @return array<int,string>
	 */
	function mvweb_cz_decoration_types() {
		return array( 'heading', 'divider' );
	}
}

if ( ! function_exists( 'mvweb_cz_is_decoration' ) ) {
	/**
	 * Whether a type is decorative (no setting, no value).
	 *
	 * @since 1.0.0
	 *
	 * @param string $type Field type.
	 *
	 * @return bool
	 */
	function mvweb_cz_is_decoration( $type ) {
		return in_array( $type, mvweb_cz_decoration_types(), true );
	}
}

if ( ! function_exists( 'mvweb_cz_normalize_field' ) ) {
	/**
	 * Fill a field definition with safe defaults and resolve its transport.
	 *
	 * Transport rule (this is the piece that makes live preview work):
	 *   - explicit value in the field always wins;
	 *   - a field with an 'output' map gets postMessage, because the Kit
	 *     generates its preview JS from that very map;
	 *   - a field with a 'partial' map gets postMessage, because selective
	 *     refresh re-renders it server-side;
	 *   - everything else gets refresh, which always shows the change.
	 *
	 * Defaulting to postMessage without a JS binding silently breaks preview:
	 * the value changes, nothing on screen does.
	 *
	 * @since 1.0.0
	 *
	 * @param array $field Raw field definition.
	 *
	 * @return array Normalized field.
	 */
	function mvweb_cz_normalize_field( array $field ) {
		$field = wp_parse_args( $field, mvweb_cz_field_defaults() );

		$field['output']      = mvweb_cz_normalize_output( $field['output'] );
		$field['required']    = mvweb_cz_normalize_required( $field['required'] );
		$field['input_attrs'] = is_array( $field['input_attrs'] ) ? $field['input_attrs'] : array();

		/* An incomplete partial would give postMessage with nothing bound to it. */
		if ( empty( $field['partial']['selector'] ) || empty( $field['partial']['render_callback'] ) ) {
			$field['partial'] = array();
		}

		if ( null === $field['transport'] ) {
			$field['transport'] = ( ! empty( $field['output'] ) || ! empty( $field['partial'] ) )
				? 'postMessage'
				: 'refresh';
		}

		if ( null === $field['sanitize_callback'] ) {
			$field['sanitize_callback'] = mvweb_cz_resolve_sanitizer( $field );
		}

		return $field;
	}
}

if ( ! function_exists( 'mvweb_cz_normalize_output' ) ) {
	/**
	 * Normalize the output map to a list of complete rules.
	 *
	 * Accepts a single rule array or a list of them; drops rules missing the
	 * two mandatory keys so downstream consumers can trust the shape.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $output Raw output map.
	 *
	 * @return array<int,array<string,string>>
	 */
	function mvweb_cz_normalize_output( $output ) {
		if ( empty( $output ) || ! is_array( $output ) ) {
			return array();
		}

		if ( isset( $output['element'] ) || isset( $output['property'] ) ) {
			$output = array( $output );
		}

		$rules = array();

		foreach ( $output as $rule ) {
			if ( ! is_array( $rule ) || empty( $rule['element'] ) || empty( $rule['property'] ) ) {
				continue;
			}

			$rules[] = array(
				'element'  => (string) $rule['element'],
				'property' => (string) $rule['property'],
				'unit'     => isset( $rule['unit'] ) ? (string) $rule['unit'] : '',
				'prefix'   => isset( $rule['prefix'] ) ? (string) $rule['prefix'] : '',
				'suffix'   => isset( $rule['suffix'] ) ? (string) $rule['suffix'] : '',
				'key'      => isset( $rule['key'] ) ? (string) $rule['key'] : '',
			);
		}

		return $rules;
	}
}

if ( ! function_exists( 'mvweb_cz_normalize_required' ) ) {
	/**
	 * Normalize dependency rules to a list of complete conditions.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $required Raw dependency rules.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_cz_normalize_required( $required ) {
		if ( empty( $required ) || ! is_array( $required ) ) {
			return array();
		}

		if ( isset( $required['setting'] ) ) {
			$required = array( $required );
		}

		$rules     = array();
		$operators = array( '==', '!=', '>', '>=', '<', '<=', 'in', 'not in', 'contains' );

		foreach ( $required as $rule ) {
			if ( ! is_array( $rule ) || empty( $rule['setting'] ) ) {
				continue;
			}

			$operator = isset( $rule['operator'] ) ? (string) $rule['operator'] : '==';

			$rules[] = array(
				'setting'  => (string) $rule['setting'],
				'operator' => in_array( $operator, $operators, true ) ? $operator : '==',
				'value'    => isset( $rule['value'] ) ? $rule['value'] : true,
			);
		}

		return $rules;
	}
}

if ( ! function_exists( 'mvweb_cz_resolve_sanitizer' ) ) {
	/**
	 * Pick the sanitizer for a normalized field.
	 *
	 * Types whose valid values depend on the field itself (choice sets,
	 * repeater subfields) get a closure capturing that context; the rest map
	 * to a plain callable by type.
	 *
	 * The captured choice set is frozen when the field is declared. A plugin
	 * adding choices must do so before mvweb_cz_register fires, otherwise its
	 * values are rejected on save.
	 *
	 * @since 1.0.0
	 *
	 * @param array $field Field definition (already merged with defaults).
	 *
	 * @return callable
	 */
	function mvweb_cz_resolve_sanitizer( array $field ) {
		switch ( $field['type'] ) {
			case 'repeater':
				$subfields = $field['fields'];

				return static function ( $value ) use ( $subfields ) {
					return mvweb_cz_sanitize_repeater( $value, $subfields );
				};

			case 'sortable':
				$allowed = array_keys( $field['choices'] );

				return static function ( $value ) use ( $allowed ) {
					return mvweb_cz_sanitize_sortable( $value, $allowed );
				};

			case 'multicheck':
				$allowed = array_keys( $field['choices'] );

				return static function ( $value ) use ( $allowed ) {
					return mvweb_cz_sanitize_multicheck( $value, $allowed );
				};

			case 'select':
			case 'radio':
			case 'radio_buttonset':
			case 'radio_image':
			case 'color_palette':
				$allowed  = array_keys( $field['choices'] );
				$fallback = $field['default'];

				return static function ( $value ) use ( $allowed, $fallback ) {
					return mvweb_cz_sanitize_choice( $value, $allowed, $fallback );
				};

			case 'number':
			case 'range':
				$attrs = $field['input_attrs'];

				return static function ( $value ) use ( $attrs ) {
					return mvweb_cz_sanitize_number( $value, $attrs );
				};

			default:
				return mvweb_cz_default_sanitizer( $field['type'] );
		}
	}
}

if ( ! function_exists( 'mvweb_cz_default_sanitizer' ) ) {
	/**
	 * Sanitizer for types that need no field context.
	 *
	 * @since 1.0.0
	 *
	 * @param string $type Field type.
	 *
	 * @return callable
	 */
	function mvweb_cz_default_sanitizer( $type ) {
		return match ( $type ) {
			'color'              => 'mvweb_cz_sanitize_color',
			'image', 'url'       => 'esc_url_raw',
			'checkbox', 'toggle' => 'mvweb_cz_sanitize_checkbox',
			'textarea'           => 'sanitize_textarea_field',
			'editor'             => 'wp_kses_post',
			'code'               => 'mvweb_cz_sanitize_code',
			'dimension'          => 'mvweb_cz_sanitize_dimension',
			'typography'         => 'mvweb_cz_sanitize_typography',
			default              => 'sanitize_text_field',
		};
	}
}

if ( ! function_exists( 'mvweb_cz_sanitize_checkbox' ) ) {
	/**
	 * Sanitize a checkbox value to a strict boolean.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return bool
	 */
	function mvweb_cz_sanitize_checkbox( $value ) {
		return ( '1' === $value || 1 === $value || true === $value );
	}
}

if ( ! function_exists( 'mvweb_cz_sanitize_color' ) ) {
	/**
	 * Sanitize a colour: hex, rgba() or an empty string.
	 *
	 * sanitize_hex_color() alone drops rgba values, which the palette and
	 * overlay options need.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string
	 */
	function mvweb_cz_sanitize_color( $value ) {
		$value = trim( (string) $value );

		if ( '' === $value ) {
			return '';
		}

		$hex = sanitize_hex_color( $value );

		if ( null !== $hex && '' !== $hex ) {
			return $hex;
		}

		if ( preg_match( '/^rgba?\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*(,\s*(0|1|0?\.\d+)\s*)?\)$/i', $value ) ) {
			return strtolower( str_replace( ' ', '', $value ) );
		}

		return '';
	}
}

if ( ! function_exists( 'mvweb_cz_sanitize_number' ) ) {
	/**
	 * Sanitize a number and clamp it to the declared min / max.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $value Raw value.
	 * @param array $attrs Input attributes (min, max, step).
	 *
	 * @return int|float
	 */
	function mvweb_cz_sanitize_number( $value, $attrs = array() ) {
		$step  = isset( $attrs['step'] ) ? (float) $attrs['step'] : 1;
		$value = is_numeric( $value ) ? $value + 0 : 0;

		if ( isset( $attrs['min'] ) && $value < $attrs['min'] ) {
			$value = $attrs['min'] + 0;
		}

		if ( isset( $attrs['max'] ) && $value > $attrs['max'] ) {
			$value = $attrs['max'] + 0;
		}

		$is_integer = ( 0.0 === fmod( $step, 1 ) );

		return $is_integer ? (int) round( $value ) : (float) $value;
	}
}

if ( ! function_exists( 'mvweb_cz_sanitize_code' ) ) {
	/**
	 * Sanitize a code editor value.
	 *
	 * CSS and JS legitimately contain "<" (a < b), so stripping tags would eat
	 * the code. Only users with edit_theme_options reach the Customizer, so the
	 * value is kept verbatim minus the sequences that could break out of the
	 * element it is printed into.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string
	 */
	function mvweb_cz_sanitize_code( $value ) {
		return str_ireplace(
			array( '</style', '</script', '<script', '<?php', '<?=' ),
			'',
			(string) $value
		);
	}
}

if ( ! function_exists( 'mvweb_cz_sanitize_dimension' ) ) {
	/**
	 * Sanitize a dimension value like "24px", "1.5rem", "10%".
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string
	 */
	function mvweb_cz_sanitize_dimension( $value ) {
		$value = trim( (string) $value );

		if ( '' === $value ) {
			return '';
		}

		if ( preg_match( '/^-?\d+(\.\d+)?(px|em|rem|%|vh|vw|vmin|vmax|ch|ex|pt)?$/', $value ) ) {
			return $value;
		}

		return '';
	}
}

if ( ! function_exists( 'mvweb_cz_sanitize_typography' ) ) {
	/**
	 * Sanitize a typography value (JSON: family / size / weight / spacing).
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $value Raw JSON string.
	 *
	 * @return string
	 */
	function mvweb_cz_sanitize_typography( $value ) {
		$data = json_decode( (string) $value, true );

		if ( ! is_array( $data ) ) {
			return wp_json_encode( array() );
		}

		$clean   = array();
		$weights = array( '100', '200', '300', '400', '500', '600', '700', '800', '900', 'normal', 'bold' );

		if ( isset( $data['family'] ) ) {
			$clean['family'] = sanitize_text_field( $data['family'] );
		}

		foreach ( array( 'size', 'line-height', 'letter-spacing' ) as $key ) {
			if ( isset( $data[ $key ] ) ) {
				$clean[ $key ] = mvweb_cz_sanitize_dimension( $data[ $key ] );
			}
		}

		if ( isset( $data['weight'] ) && in_array( (string) $data['weight'], $weights, true ) ) {
			$clean['weight'] = (string) $data['weight'];
		}

		if ( isset( $data['transform'] ) ) {
			$transforms         = array( 'none', 'uppercase', 'lowercase', 'capitalize' );
			$clean['transform'] = in_array( (string) $data['transform'], $transforms, true ) ? (string) $data['transform'] : 'none';
		}

		return wp_json_encode( $clean );
	}
}

if ( ! function_exists( 'mvweb_cz_sanitize_repeater' ) ) {
	/**
	 * Sanitize a repeater value (JSON array of rows).
	 *
	 * Always returns a JSON string: returning null would make the Customizer
	 * silently discard the change and fall back to the default.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $value     Raw JSON string.
	 * @param array $subfields Subfield schema: id => [ type, choices,
	 *                         sanitize_callback, ... ].
	 *
	 * @return string
	 */
	function mvweb_cz_sanitize_repeater( $value, $subfields = array() ) {
		$rows = json_decode( (string) $value, true );

		if ( ! is_array( $rows ) ) {
			return wp_json_encode( array() );
		}

		$clean = array();

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$clean_row = array();

			foreach ( $row as $key => $leaf ) {
				if ( ! empty( $subfields ) && ! isset( $subfields[ $key ] ) ) {
					continue;
				}

				$type    = isset( $subfields[ $key ]['type'] ) ? $subfields[ $key ]['type'] : 'text';
				$choices = isset( $subfields[ $key ]['choices'] ) ? (array) $subfields[ $key ]['choices'] : array();

				// A subfield may name its own sanitizer, for a value the stock
				// type would strip — a caption that keeps its <br>, say.
				if ( isset( $subfields[ $key ]['sanitize_callback'] ) && is_callable( $subfields[ $key ]['sanitize_callback'] ) ) {
					$clean_row[ $key ] = call_user_func( $subfields[ $key ]['sanitize_callback'], $leaf );
					continue;
				}

				$clean_row[ $key ] = mvweb_cz_sanitize_repeater_leaf( $leaf, $type, $choices );
			}

			$clean[] = $clean_row;
		}

		return wp_json_encode( $clean );
	}
}

if ( ! function_exists( 'mvweb_cz_sanitize_repeater_leaf' ) ) {
	/**
	 * Sanitize one repeater subfield value by its declared type.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed  $leaf    Raw value.
	 * @param string $type    Subfield type.
	 * @param array  $choices Allowed values, for choice-based subfields.
	 *
	 * @return string|int
	 */
	function mvweb_cz_sanitize_repeater_leaf( $leaf, $type, $choices = array() ) {
		return match ( $type ) {
			'image'        => wp_attachment_is_image( absint( $leaf ) ) ? absint( $leaf ) : 0,
			'url'          => esc_url_raw( (string) $leaf ),
			'textarea'     => sanitize_textarea_field( (string) $leaf ),
			'editor'       => wp_kses_post( (string) $leaf ),
			'color'        => mvweb_cz_sanitize_color( $leaf ),
			'select', 'radio' => mvweb_cz_sanitize_choice( $leaf, array_keys( $choices ), '' ),
			default        => sanitize_text_field( (string) $leaf ),
		};
	}
}

if ( ! function_exists( 'mvweb_cz_sanitize_sortable' ) ) {
	/**
	 * Sanitize a sortable value (JSON array of active slugs, ordered).
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $value   Raw JSON string.
	 * @param array $allowed Allowed slugs.
	 *
	 * @return string
	 */
	function mvweb_cz_sanitize_sortable( $value, $allowed = array() ) {
		$slugs = json_decode( (string) $value, true, 3 );

		if ( ! is_array( $slugs ) || empty( $allowed ) ) {
			return wp_json_encode( array() );
		}

		$clean = array();

		foreach ( $slugs as $slug ) {
			if ( ! is_string( $slug ) || ! in_array( $slug, $allowed, true ) || in_array( $slug, $clean, true ) ) {
				continue;
			}

			$clean[] = $slug;
		}

		return wp_json_encode( $clean );
	}
}

if ( ! function_exists( 'mvweb_cz_sanitize_multicheck' ) ) {
	/**
	 * Sanitize a multicheck value (JSON array of checked slugs).
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $value   Raw JSON string.
	 * @param array $allowed Allowed slugs.
	 *
	 * @return string
	 */
	function mvweb_cz_sanitize_multicheck( $value, $allowed = array() ) {
		return mvweb_cz_sanitize_sortable( $value, $allowed );
	}
}

if ( ! function_exists( 'mvweb_cz_sanitize_choice' ) ) {
	/**
	 * Sanitize a single value against the allowed set.
	 *
	 * The allowed set comes from array_keys() of a choices map, and PHP casts
	 * numeric string keys to integers on the way in. Without casting them back,
	 * a strict comparison against the submitted string would reject every
	 * numeric choice — "2 columns", a rating of "4" — and silently fall back to
	 * the default.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed  $value    Raw value.
	 * @param array  $allowed  Allowed keys.
	 * @param string $fallback Value used when not allowed.
	 *
	 * @return string
	 */
	function mvweb_cz_sanitize_choice( $value, $allowed = array(), $fallback = '' ) {
		$value   = sanitize_text_field( (string) $value );
		$allowed = array_map( 'strval', (array) $allowed );

		return in_array( $value, $allowed, true ) ? $value : (string) $fallback;
	}
}
