<?php
/**
 * Field dependencies — conditional visibility that reacts immediately.
 *
 * WordPress evaluates active_callback on the server and ships the result to
 * the controls pane only when the preview reloads. A field controlled by a
 * postMessage setting therefore never re-evaluates, and the dependent control
 * stays visible. So dependencies declared as 'required' are resolved in JS
 * against the live setting value; active_callback is left for static
 * conditions (template type, theme support, active plugin).
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_cz_dependencies_data' ) ) {
	/**
	 * Dependency rules per control, for the controls script.
	 *
	 * @since 1.0.0
	 *
	 * @return array<string,array>
	 */
	function mvweb_cz_dependencies_data() {
		$data = array();

		foreach ( mvweb_cz()->get_items() as $index => $field ) {
			if ( empty( $field['required'] ) ) {
				continue;
			}

			$control_id = mvweb_cz_is_decoration( $field['type'] )
				? 'mvweb_cz_' . $field['type'] . '_' . (int) $index
				: $field['settings'];

			$data[ $control_id ] = $field['required'];
		}

		return $data;
	}
}

if ( ! function_exists( 'mvweb_cz_ui_data' ) ) {
	/**
	 * Layout hints for the panel script, keyed by control id.
	 *
	 * None of them changes what is stored: a group folds its fields away, a
	 * tooltip moves a long note behind a button, a device pair shows one of
	 * two ranges at a time. A field without hints is left out.
	 *
	 * @since 1.2.0
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_cz_ui_data() {
		$data = array();

		foreach ( mvweb_cz()->get_items() as $index => $field ) {
			$hints = array_filter(
				array(
					'tooltip'     => (string) $field['tooltip'],
					'device'      => (string) $field['device'],
					'deviceGroup' => (string) $field['device_group'],
					'collapsible' => (bool) $field['collapsible'],
					'collapsed'   => (bool) $field['collapsed'],
					'summary'     => array_values( array_filter( (array) $field['summary'], 'is_string' ) ),
					'toggle'      => (string) $field['toggle'],
					'dependent'   => ! empty( $field['required'] ),
				)
			);

			if ( empty( $hints ) ) {
				continue;
			}

			$control_id = mvweb_cz_is_decoration( $field['type'] )
				? 'mvweb_cz_' . $field['type'] . '_' . (int) $index
				: $field['settings'];

			$data[ $control_id ] = $hints;
		}

		return $data;
	}
}
