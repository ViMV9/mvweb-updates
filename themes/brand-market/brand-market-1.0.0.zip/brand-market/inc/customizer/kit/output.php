<?php
/**
 * Field-to-CSS output layer.
 *
 * A field that declares an 'output' map is turned into CSS on the front end
 * and into a live-preview binding inside the Customizer, from the same
 * declaration. This is what removes hand-written "if option X then CSS Y"
 * blocks from the theme: the field says where its value goes, once.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_cz_sanitize_css_selector' ) ) {
	/**
	 * Sanitize a CSS selector.
	 *
	 * @since 1.0.0
	 *
	 * @param string $selector Raw selector.
	 *
	 * @return string
	 */
	function mvweb_cz_sanitize_css_selector( $selector ) {
		$selector = (string) $selector;

		if ( preg_match( '/[{}<>;@]/', $selector ) ) {
			return '';
		}

		return trim( preg_replace( '/\s+/', ' ', $selector ) );
	}
}

if ( ! function_exists( 'mvweb_cz_sanitize_css_property' ) ) {
	/**
	 * Sanitize a CSS property name, including custom properties.
	 *
	 * @since 1.0.0
	 *
	 * @param string $property Raw property.
	 *
	 * @return string
	 */
	function mvweb_cz_sanitize_css_property( $property ) {
		$property = strtolower( trim( (string) $property ) );

		return preg_match( '/^(--)?[a-z][a-z0-9_-]*$/', $property ) ? $property : '';
	}
}

if ( ! function_exists( 'mvweb_cz_sanitize_css_value' ) ) {
	/**
	 * Sanitize a CSS value: no braces, no semicolons, no at-rules, no tags, no
	 * comments, no expression() and no javascript: protocol.
	 *
	 * Backslashes are rejected too: CSS lets any character be written as a hex
	 * escape, so "\6a\61\76..." would spell javascript: past a literal check.
	 * No legitimate option value here needs one.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string
	 */
	function mvweb_cz_sanitize_css_value( $value ) {
		$value = (string) $value;

		if ( preg_match( '#[{}<>;@\\\\]|/\*|expression\s*\(|javascript:#i', $value ) ) {
			return '';
		}

		return trim( wp_strip_all_tags( $value ) );
	}
}

if ( ! function_exists( 'mvweb_cz_output_value' ) ) {
	/**
	 * Resolve the value a single output rule writes.
	 *
	 * A rule may target one key of a JSON value (typography), in which case
	 * 'key' says which one.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $value Saved setting value.
	 * @param array $rule  Normalized output rule.
	 *
	 * @return string
	 */
	function mvweb_cz_output_value( $value, array $rule ) {
		if ( '' !== $rule['key'] ) {
			$data = json_decode( (string) $value, true );

			$value = ( is_array( $data ) && isset( $data[ $rule['key'] ] ) ) ? $data[ $rule['key'] ] : '';
		}

		if ( is_bool( $value ) ) {
			$value = $value ? '1' : '';
		}

		if ( is_array( $value ) ) {
			return '';
		}

		return (string) $value;
	}
}

if ( ! function_exists( 'mvweb_cz_build_css' ) ) {
	/**
	 * Build the CSS for every field that declares an output map.
	 *
	 * Rules are grouped by selector so one element yields one block.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	function mvweb_cz_build_css() {
		$blocks = array();

		foreach ( mvweb_cz()->get_output_fields() as $field ) {
			$saved = get_theme_mod( $field['settings'], $field['default'] );

			foreach ( $field['output'] as $rule ) {
				$value = mvweb_cz_output_value( $saved, $rule );

				if ( '' === $value ) {
					continue;
				}

				$element  = mvweb_cz_sanitize_css_selector( $rule['element'] );
				$property = mvweb_cz_sanitize_css_property( $rule['property'] );
				$value    = mvweb_cz_sanitize_css_value( $rule['prefix'] . $value . $rule['unit'] . $rule['suffix'] );

				if ( '' === $element || '' === $property || '' === $value ) {
					continue;
				}

				if ( ! isset( $blocks[ $element ] ) ) {
					$blocks[ $element ] = array();
				}

				$blocks[ $element ][] = $property . ':' . $value . ';';
			}
		}

		$css = '';

		foreach ( $blocks as $element => $declarations ) {
			$css .= $element . '{' . implode( '', $declarations ) . '}';
		}

		return $css;
	}
}

if ( ! function_exists( 'mvweb_cz_print_css' ) ) {
	/**
	 * Print the generated CSS in wp_head.
	 *
	 * Priority 20 puts it after enqueued stylesheets and after a theme's design
	 * preset tokens (which print at priority 10): the preset is the baseline,
	 * an option the owner set by hand overrides it.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function mvweb_cz_print_css() {
		$css = mvweb_cz_build_css();

		if ( '' === $css ) {
			return;
		}

		printf( "<style id=\"mvweb-cz-output\">%s</style>\n", $css ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Pre-sanitized selector/property/value.
	}
}
add_action( 'wp_head', 'mvweb_cz_print_css', 20 );

if ( ! function_exists( 'mvweb_cz_preview_data' ) ) {
	/**
	 * Output maps handed to the preview script.
	 *
	 * The preview script rewrites one <style> tag from these rules whenever a
	 * bound setting changes, which is why fields with an output map can safely
	 * default to postMessage.
	 *
	 * Every field with an output map is included, transport aside: the preview
	 * script takes over the whole layer from the server-rendered block, so a
	 * value cleared in the panel disappears on screen instead of lingering.
	 *
	 * @since 1.0.0
	 *
	 * @return array<string,array>
	 */
	function mvweb_cz_preview_data() {
		$data = array();

		foreach ( mvweb_cz()->get_output_fields() as $field ) {
			$rules = array();

			foreach ( $field['output'] as $rule ) {
				$element  = mvweb_cz_sanitize_css_selector( $rule['element'] );
				$property = mvweb_cz_sanitize_css_property( $rule['property'] );

				if ( '' === $element || '' === $property ) {
					continue;
				}

				$rules[] = array(
					'element'  => $element,
					'property' => $property,
					'unit'     => $rule['unit'],
					'prefix'   => $rule['prefix'],
					'suffix'   => $rule['suffix'],
					'key'      => $rule['key'],
				);
			}

			if ( ! empty( $rules ) ) {
				$data[ $field['settings'] ] = $rules;
			}
		}

		return $data;
	}
}
