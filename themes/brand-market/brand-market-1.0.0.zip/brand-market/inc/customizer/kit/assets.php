<?php
/**
 * Kit assets: control scripts and styles, preview script, localized data.
 *
 * The Kit resolves its own URL from its location on disk, so the same folder
 * works whether it is vendored into a theme or into a companion plugin.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_cz_url' ) ) {
	/**
	 * Absolute URL of a file inside the Kit folder.
	 *
	 * @since 1.0.0
	 *
	 * @param string $path Path relative to the Kit folder, with a leading slash.
	 *
	 * @return string
	 */
	function mvweb_cz_url( $path = '' ) {
		static $base = null;

		if ( null === $base ) {
			$dir        = wp_normalize_path( __DIR__ );
			$stylesheet = wp_normalize_path( get_stylesheet_directory() );
			$template   = wp_normalize_path( get_template_directory() );

			if ( 0 === strpos( $dir, $stylesheet ) ) {
				$base = get_stylesheet_directory_uri() . substr( $dir, strlen( $stylesheet ) );
			} elseif ( 0 === strpos( $dir, $template ) ) {
				$base = get_template_directory_uri() . substr( $dir, strlen( $template ) );
			} else {
				$base = untrailingslashit( plugins_url( '', __FILE__ ) );
			}
		}

		return $base . $path;
	}
}

if ( ! function_exists( 'mvweb_cz_asset' ) ) {
	/**
	 * Asset URL, preferring the minified build when it exists.
	 *
	 * @since 1.0.0
	 *
	 * @param string $path Path relative to the Kit folder, with a leading slash.
	 *
	 * @return string
	 */
	function mvweb_cz_asset( $path ) {
		$debug = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG );
		$min   = preg_replace( '/\.(css|js)$/', '.min.$1', $path );

		if ( ! $debug && $min !== $path && is_readable( __DIR__ . $min ) ) {
			$path = $min;
		}

		return mvweb_cz_url( $path );
	}
}

if ( ! function_exists( 'mvweb_cz_l10n' ) ) {
	/**
	 * Strings used by the Kit's own JS.
	 *
	 * Kept behind a filter instead of a text domain so the Kit stays portable
	 * between themes and plugins without shipping its own translation files.
	 *
	 * @since 1.0.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_cz_l10n() {
		$strings = array(
			'add'           => 'Добавить',
			'remove'        => 'Удалить',
			'row'           => 'Элемент',
			'selectImage'   => 'Выбрать изображение',
			'changeImage'   => 'Заменить',
			'removeImage'   => 'Убрать',
			'reset'         => 'Сбросить',
			'confirm'       => 'Удалить этот элемент?',
			'unit'          => 'Единица измерения',
			'fontFamily'    => 'Шрифт',
			'fontSize'      => 'Размер',
			'fontWeight'    => 'Насыщенность',
			'lineHeight'    => 'Интерлиньяж',
			'letterSpacing' => 'Трекинг',
			'textTransform' => 'Регистр',
			'inherit'       => 'Наследовать',
			'caseNone'      => 'Как есть',
			'caseUpper'     => 'ПРОПИСНЫЕ',
			'caseLower'     => 'строчные',
			'caseTitle'     => 'С Заглавной',
			'dragToReorder' => 'Перетащите, чтобы изменить порядок',
			'search'        => 'Найти настройку…',
			'nothingFound'  => 'Ничего не найдено',
			'notSet'        => 'не задано',
			'hint'          => 'Подсказка',
			'desktop'       => 'Компьютер',
			'mobile'        => 'Телефон и планшет',
			'otherGroup'    => 'WordPress',
			'edit'          => 'Настроить этот блок',
		);

		/**
		 * Filter the Kit UI strings.
		 *
		 * @since 1.0.0
		 *
		 * @param array<string,string> $strings Strings keyed by id.
		 */
		return apply_filters( 'mvweb_cz_l10n', $strings );
	}
}

if ( ! function_exists( 'mvweb_cz_text' ) ) {
	/**
	 * One Kit UI string.
	 *
	 * @since 1.0.0
	 *
	 * @param string $key String id.
	 *
	 * @return string
	 */
	function mvweb_cz_text( $key ) {
		$strings = mvweb_cz_l10n();

		return isset( $strings[ $key ] ) ? $strings[ $key ] : '';
	}
}

if ( ! function_exists( 'mvweb_cz_controls_assets' ) ) {
	/**
	 * Enqueue Kit assets in the Customizer controls pane.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function mvweb_cz_controls_assets() {
		wp_enqueue_media();
		wp_enqueue_editor();
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );

		wp_enqueue_style(
			'mvweb-cz-controls',
			mvweb_cz_asset( '/assets/css/kit.css' ),
			array( 'customize-controls' ),
			MVWEB_CZ_VERSION
		);

		wp_enqueue_script(
			'mvweb-cz-controls',
			mvweb_cz_asset( '/assets/js/kit-controls.js' ),
			array( 'jquery', 'jquery-ui-sortable', 'customize-controls', 'wp-util', 'wp-color-picker' ),
			MVWEB_CZ_VERSION,
			true
		);

		wp_localize_script(
			'mvweb-cz-controls',
			'mvwebCZ',
			array(
				'dependencies' => mvweb_cz_dependencies_data(),
				'ui'           => mvweb_cz_ui_data(),
				'panelGroups'  => mvweb_cz_panel_groups(),
				'l10n'         => mvweb_cz_l10n(),
			)
		);
	}
}
add_action( 'customize_controls_enqueue_scripts', 'mvweb_cz_controls_assets' );

if ( ! function_exists( 'mvweb_cz_preview_assets' ) ) {
	/**
	 * Enqueue the live-preview script inside the preview frame.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function mvweb_cz_preview_assets() {
		wp_enqueue_script(
			'mvweb-cz-preview',
			mvweb_cz_asset( '/assets/js/kit-preview.js' ),
			array( 'customize-preview' ),
			MVWEB_CZ_VERSION,
			true
		);

		wp_localize_script(
			'mvweb-cz-preview',
			'mvwebCZPreview',
			array(
				'output' => mvweb_cz_preview_data(),
				'edit'   => mvweb_cz_text( 'edit' ),
			)
		);
	}
}
add_action( 'customize_preview_init', 'mvweb_cz_preview_assets' );
