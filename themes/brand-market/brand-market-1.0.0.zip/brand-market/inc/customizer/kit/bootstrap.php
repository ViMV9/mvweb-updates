<?php
/**
 * Kit bootstrap and version guard.
 *
 * The Kit is vendored: a theme carries a copy, and a companion plugin may
 * carry another. Two copies of the same classes in one request would fatal, so
 * every copy registers itself here instead of loading immediately, and the
 * newest one wins on after_setup_theme.
 *
 * A theme loads the Kit with a single line in functions.php:
 *
 *   require_once get_template_directory() . '/inc/customizer/kit/bootstrap.php';
 *
 * Everything the Kit exposes is available from after_setup_theme onwards,
 * which is before customize_register, wp_head and customize_preview_init.
 *
 * @package MVweb_Customizer_Kit
 *
 * @since 1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_cz_register_candidate' ) ) {
	/**
	 * Register one copy of the Kit as a load candidate.
	 *
	 * @since 1.0.0
	 *
	 * @param string $dir     Absolute path of the Kit folder.
	 * @param string $version Version of that copy.
	 *
	 * @return void
	 */
	function mvweb_cz_register_candidate( $dir, $version ) {
		if ( ! isset( $GLOBALS['mvweb_cz_candidates'] ) ) {
			$GLOBALS['mvweb_cz_candidates'] = array();
		}

		$GLOBALS['mvweb_cz_candidates'][ $dir ] = $version;
	}

	/**
	 * Load the newest registered copy.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	function mvweb_cz_load() {
		if ( class_exists( 'MVweb_Customizer_Kit' ) || empty( $GLOBALS['mvweb_cz_candidates'] ) ) {
			return;
		}

		$winner  = '';
		$version = '0';

		foreach ( $GLOBALS['mvweb_cz_candidates'] as $dir => $candidate ) {
			if ( version_compare( $candidate, $version, '>' ) ) {
				$winner  = $dir;
				$version = $candidate;
			}
		}

		if ( '' === $winner ) {
			return;
		}

		if ( ! defined( 'MVWEB_CZ_VERSION' ) ) {
			define( 'MVWEB_CZ_VERSION', $version );
		}

		require_once $winner . '/kit.php';

		/**
		 * Fires once the Kit is loaded and ready to take declarations.
		 *
		 * @since 1.0.0
		 *
		 * @param string $version Loaded Kit version.
		 */
		do_action( 'mvweb_cz_loaded', $version );
	}

	add_action( 'after_setup_theme', 'mvweb_cz_load', 0 );
}

mvweb_cz_register_candidate( __DIR__, '1.3.0' );
