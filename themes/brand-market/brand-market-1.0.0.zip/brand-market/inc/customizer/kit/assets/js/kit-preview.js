/*
 * MVweb Customizer Kit — live preview.
 *
 * Rebuilds one <style> tag from the same output maps the PHP layer uses, so a
 * field that declares where its value goes gets instant preview without a line
 * of per-field JavaScript. Appended last in <head>, it wins over the
 * server-rendered block at equal specificity.
 */
( function ( api ) {
	'use strict';

	var maps = ( window.mvwebCZPreview || {} ).output || {};
	var values = {};
	var styleId = 'mvweb-cz-preview';

	/*
	 * The server-rendered block covers the same fields, so leaving it in place
	 * would keep showing the old value of an option the user just cleared.
	 * Emptying it hands the whole layer to this script.
	 */
	function releaseServerStyle() {
		var server = document.getElementById( 'mvweb-cz-output' );

		if ( server ) {
			server.textContent = '';
		}
	}

	function styleElement() {
		var el = document.getElementById( styleId );

		if ( ! el ) {
			el = document.createElement( 'style' );
			el.id = styleId;
			document.head.appendChild( el );
		}

		return el;
	}

	function ruleValue( raw, rule ) {
		var value = raw;

		if ( rule.key ) {
			try {
				var parsed = JSON.parse( raw );

				value = parsed && parsed[ rule.key ] !== undefined ? parsed[ rule.key ] : '';
			} catch ( e ) {
				value = '';
			}
		}

		if ( true === value ) {
			value = '1';
		}

		if ( false === value || null === value || undefined === value ) {
			value = '';
		}

		return String( value );
	}

	function render() {
		var blocks = {};

		Object.keys( maps ).forEach( function ( setting ) {
			maps[ setting ].forEach( function ( rule ) {
				var value = ruleValue( values[ setting ], rule );

				if ( '' === value ) {
					return;
				}

				blocks[ rule.element ] = blocks[ rule.element ] || [];
				blocks[ rule.element ].push(
					rule.property + ':' + rule.prefix + value + rule.unit + rule.suffix + ';'
				);
			} );
		} );

		var css = Object.keys( blocks )
			.map( function ( element ) {
				return element + '{' + blocks[ element ].join( '' ) + '}';
			} )
			.join( '' );

		styleElement().textContent = css;
		releaseServerStyle();
	}

	/* Core creates the settings after this file runs, so the first paint belongs in the callback. */
	Object.keys( maps ).forEach( function ( setting ) {
		api( setting, function ( value ) {
			values[ setting ] = value.get();
			render();

			value.bind( function ( to ) {
				values[ setting ] = to;
				render();
			} );
		} );
	} );

	/*
	 * A pencil on every block the theme marked with data-mvweb-cz-section:
	 * a click opens that section in the panel. Core draws such buttons only
	 * for selective-refresh partials, and most blocks here reload the preview
	 * instead.
	 */
	function addShortcuts() {
		var label = ( window.mvwebCZPreview || {} ).edit || '';

		if ( ! document.getElementById( 'mvweb-cz-shortcut-style' ) ) {
			var style = document.createElement( 'style' );

			style.id = 'mvweb-cz-shortcut-style';
			style.textContent = '.mvweb-cz-shortcut{position:absolute;top:10px;left:10px;z-index:9999;display:grid;place-items:center;width:30px;height:30px;padding:0;border:2px solid #fff;border-radius:50%;background:#3582c4;box-shadow:0 2px 4px rgba(0,0,0,.3);color:#fff;cursor:pointer;opacity:.85}.mvweb-cz-shortcut:hover,.mvweb-cz-shortcut:focus-visible{opacity:1;background:#2271b1}.mvweb-cz-shortcut svg{width:16px;height:16px;fill:currentColor}';
			document.head.appendChild( style );
		}

		document.querySelectorAll( '[data-mvweb-cz-section]' ).forEach( function ( el ) {
			var button;

			if ( el.querySelector( ':scope > .mvweb-cz-shortcut' ) ) {
				return;
			}

			if ( 'static' === getComputedStyle( el ).position ) {
				el.style.position = 'relative';
			}

			button = document.createElement( 'button' );
			button.type = 'button';
			button.className = 'mvweb-cz-shortcut';
			button.setAttribute( 'aria-label', label );
			button.title = label;
			button.innerHTML = '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M13.89 3.39l2.71 2.72c.46.46.42 1.24.03 1.64l-8.01 8.02-5.56 1.16 1.16-5.58 8.02-8c.4-.4 1.18-.44 1.65.04zm-2.34 2.8l-5.6 5.6 1.1 1.1 5.6-5.6zm-1.54-1.54l-5.6 5.6 1.1 1.1 5.6-5.6z"/></svg>';
			button.addEventListener( 'click', function ( event ) {
				event.preventDefault();
				event.stopPropagation();
				api.preview.send( 'mvweb-cz-focus', el.getAttribute( 'data-mvweb-cz-section' ) );
			} );

			el.insertBefore( button, el.firstChild );
		} );
	}

	api.bind( 'preview-ready', addShortcuts );
} )( wp.customize );
