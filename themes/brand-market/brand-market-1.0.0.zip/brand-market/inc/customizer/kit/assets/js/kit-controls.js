/*
 * MVweb Customizer Kit — controls pane behaviour.
 *
 * Covers three things core does not: conditional visibility that reacts to a
 * setting immediately, the compound controls (range, dimension, typography,
 * multicheck, editor) and the two templated controls (repeater, sortable).
 *
 * Compound controls write into a hidden input carrying
 * data-customize-setting-link and fire "change"; core picks the value up from
 * there, so no control object is needed for them.
 */
( function ( $, api ) {
	'use strict';

	var data = window.mvwebCZ || {};
	var l10n = data.l10n || {};

	function setValue( $input, value ) {
		$input.val( value ).trigger( 'change' );
	}

	/* Smallest copy that is still recognisable, with the original as fallback. */
	function thumbUrl( attachment ) {
		if ( attachment && attachment.sizes && attachment.sizes.thumbnail ) {
			return attachment.sizes.thumbnail.url;
		}

		return attachment && attachment.url ? attachment.url : '';
	}

	/*
	 * Bring the whole picture field in line with what it now holds: the
	 * preview, the label of the pick button and whether "remove" is offered at
	 * all. The row template prints those once, from the value it was rendered
	 * with, so without this a picture chosen in a fresh row could not be taken
	 * back — the button to do it was never printed.
	 */
	function showImage( $field, url ) {
		var $img = $field.find( 'img' );
		var $box = $field.find( '.mvweb-cz-repeater__image' );
		var filled = '' !== url;

		if ( ! $img.length && filled ) {
			$img = $( '<img alt="" />' );
			$box.prepend( $img );
		}

		if ( filled ) {
			$img.attr( 'src', url ).prop( 'hidden', false );
		} else {
			$img.prop( 'hidden', true ).removeAttr( 'src' );
		}

		$box.find( '.mvweb-cz-repeater__pick' ).text( filled ? l10n.changeImage : l10n.selectImage );

		var $unpick = $box.find( '.mvweb-cz-repeater__unpick' );

		if ( filled && ! $unpick.length ) {
			$box.append( $( '<button type="button" class="button-link mvweb-cz-repeater__unpick" />' ).text( l10n.removeImage ) );
		} else if ( ! filled ) {
			$unpick.remove();
		}
	}

	/* Conditional visibility. */

	function compare( current, operator, expected ) {
		var a = current;
		var b = expected;

		if ( 'boolean' === typeof b ) {
			a = ! ! a && '0' !== a && '' !== a;
		} else if ( 'in' !== operator && 'not in' !== operator ) {
			a = String( a );
			b = String( b );
		}

		switch ( operator ) {
			case '!=':
				return a !== b;
			case '>':
				return parseFloat( a ) > parseFloat( b );
			case '>=':
				return parseFloat( a ) >= parseFloat( b );
			case '<':
				return parseFloat( a ) < parseFloat( b );
			case '<=':
				return parseFloat( a ) <= parseFloat( b );
			case 'in':
				return _.contains( b, a );
			case 'not in':
				return ! _.contains( b, a );
			case 'contains':
				return -1 !== String( a ).indexOf( String( b ) );
			default:
				return a === b;
		}
	}

	function bindDependencies() {
		_.each( data.dependencies || {}, function ( rules, controlId ) {
			api.control( controlId, function ( control ) {
				var evaluate = function () {
					return _.every( rules, function ( rule ) {
						var setting = api( rule.setting );

						return setting ? compare( setting.get(), rule.operator, rule.value ) : true;
					} );
				};

				var apply = function () {
					control.active.set( evaluate() );
				};

				_.each( rules, function ( rule ) {
					api( rule.setting, function ( setting ) {
						setting.bind( apply );
					} );
				} );

				/* Without this the next preview "ready" event overwrites the state. */
				control.active.validate = evaluate;

				apply();
			} );
		} );
	}

	/* Range: keep the number mirror and the slider in sync. */

	function bindRange( context ) {
		context.on( 'input change', '.mvweb-cz-range__slider', function () {
			$( this ).closest( '.mvweb-cz-range' ).find( '.mvweb-cz-range__number' ).val( this.value );
		} );

		/*
		 * "change" only: on "input" the slider would clamp every intermediate
		 * keystroke and write it back, so typing 1200 into a field with
		 * min=960 would collapse to 960 after the first character.
		 */
		context.on( 'change', '.mvweb-cz-range__number', function () {
			var $wrap = $( this ).closest( '.mvweb-cz-range' );

			setValue( $wrap.find( '.mvweb-cz-range__slider' ), this.value );
		} );

		context.on( 'click', '.mvweb-cz-range__reset', function () {
			var $wrap = $( this ).closest( '.mvweb-cz-range' );
			var value = $wrap.data( 'reset' );

			$wrap.find( '.mvweb-cz-range__number' ).val( value );
			setValue( $wrap.find( '.mvweb-cz-range__slider' ), value );
		} );
	}

	/* Multicheck: collect checked boxes into one JSON value. */

	function bindMulticheck( context ) {
		context.on( 'change', '.mvweb-cz-multicheck__input', function () {
			var $wrap = $( this ).closest( '.mvweb-cz-multicheck' );
			var slugs = $wrap
				.find( '.mvweb-cz-multicheck__input:checked' )
				.map( function () {
					return this.value;
				} )
				.get();

			setValue( $wrap.find( '.mvweb-cz-multicheck__value' ), JSON.stringify( slugs ) );
		} );
	}

	/* Dimension: number + unit joined into a CSS length. */

	function bindDimension( context ) {
		context.on( 'change input', '.mvweb-cz-dimension__number, .mvweb-cz-dimension__unit', function () {
			var $wrap = $( this ).closest( '.mvweb-cz-dimension' );
			var num = $wrap.find( '.mvweb-cz-dimension__number' ).val();
			var unit = $wrap.find( '.mvweb-cz-dimension__unit' ).val();

			setValue( $wrap.find( '.mvweb-cz-dimension__value' ), '' === num ? '' : num + unit );
		} );
	}

	/* Typography: every sub-input into one JSON object. */

	function bindTypography( context ) {
		context.on( 'change input', '.mvweb-cz-typography__input', function () {
			var $wrap = $( this ).closest( '.mvweb-cz-typography' );
			var value = {};

			$wrap.find( '.mvweb-cz-typography__input' ).each( function () {
				var key = $( this ).data( 'key' );
				var val = $( this ).val();

				if ( key && '' !== val ) {
					value[ key ] = val;
				}
			} );

			setValue( $wrap.find( '.mvweb-cz-typography__value' ), JSON.stringify( value ) );
		} );
	}

	/*
	 * Editor: attach TinyMCE only when its section is open. Initializing it
	 * inside a collapsed section leaves the editor unable to measure itself.
	 */

	function initEditors( $scope ) {
		if ( ! window.wp || ! wp.editor || ! wp.editor.initialize ) {
			return;
		}

		$scope.find( '.mvweb-cz-editor__input' ).each( function () {
			var id = this.id;
			var $textarea = $( this );

			if ( $textarea.data( 'mvwebCzReady' ) ) {
				return;
			}

			$textarea.data( 'mvwebCzReady', true );

			wp.editor.initialize( id, {
				tinymce: {
					wpautop: true,
					toolbar1: 'bold,italic,bullist,numlist,link,unlink,undo,redo',
					setup: function ( editor ) {
						editor.on( 'change keyup NodeChange', function () {
							editor.save();
							$textarea.trigger( 'change' );
						} );
					}
				},
				quicktags: true,
				mediaButtons: false
			} );
		} );
	}

	/* Colour pickers inside repeater rows. */

	function initColorPickers( $scope ) {
		if ( ! $.fn.wpColorPicker ) {
			return;
		}

		$scope.find( '.mvweb-cz-repeater__color' ).each( function () {
			var $input = $( this );

			if ( $input.data( 'mvwebCzReady' ) ) {
				return;
			}

			$input.data( 'mvwebCzReady', true ).wpColorPicker( {
				change: function () {
					$input.trigger( 'change' );
				},
				clear: function () {
					$input.trigger( 'change' );
				}
			} );
		} );
	}

	/* Repeater. */

	api.controlConstructor.mvweb_cz_repeater = api.Control.extend( {
		ready: function () {
			var control = this;

			control.uid = _.uniqueId( 'mvcz' );
			control.rows = _.isArray( control.params.rows ) ? control.params.rows : [];
			control.rowTemplate = wp.template( 'mvweb-cz-repeater-row' );
			control.$list = control.container.find( '.mvweb-cz-repeater__rows' );
			control.$value = control.container.find( '.mvweb-cz-repeater__value' );

			/* Rows start collapsed: a long list must stay draggable. */
			control.open = _.map( control.rows, function () {
				return false;
			} );

			control.renderRows();

			control.container.on( 'click', '.mvweb-cz-repeater__add', function () {
				control.rows.push( {} );
				control.open.push( true );
				control.renderRows();
				control.sync();
			} );

			control.container.on( 'click', '.mvweb-cz-repeater__toggle', function () {
				var $row = $( this ).closest( '.mvweb-cz-repeater__row' );
				var index = $row.data( 'index' );
				var collapsed = ! $row.hasClass( 'is-collapsed' );

				control.open[ index ] = ! collapsed;
				$row.toggleClass( 'is-collapsed', collapsed );
				$( this ).attr( 'aria-expanded', collapsed ? 'false' : 'true' );
			} );

			control.container.on( 'click', '.mvweb-cz-repeater__remove', function () {
				var index = $( this ).closest( '.mvweb-cz-repeater__row' ).data( 'index' );

				if ( window.confirm( l10n.confirm ) ) {
					control.rows.splice( index, 1 );
					control.open.splice( index, 1 );
					control.renderRows();
					control.sync();
				}
			} );

			control.container.on( 'change input', '.mvweb-cz-repeater__input', function () {
				var $field = $( this ).closest( '.mvweb-cz-repeater__field' );
				var index = $( this ).closest( '.mvweb-cz-repeater__row' ).data( 'index' );

				control.rows[ index ] = control.rows[ index ] || {};
				control.rows[ index ][ $field.data( 'key' ) ] = $( this ).val();

				control.updateTitle( index );
				control.sync();
			} );

			control.container.on( 'click', '.mvweb-cz-repeater__pick', function () {
				control.pickImage( $( this ).closest( '.mvweb-cz-repeater__field' ) );
			} );

			control.container.on( 'click', '.mvweb-cz-repeater__unpick', function () {
				var $field = $( this ).closest( '.mvweb-cz-repeater__field' );

				setValue( $field.find( '.mvweb-cz-repeater__input' ), '' );
				showImage( $field, '' );
			} );

			control.$list.sortable( {
				handle: '.mvweb-cz-repeater__handle',
				update: function () {
					var ordered = [];
					var orderedOpen = [];

					control.$list.find( '.mvweb-cz-repeater__row' ).each( function () {
						var index = $( this ).data( 'index' );

						ordered.push( control.rows[ index ] );
						orderedOpen.push( ! ! control.open[ index ] );
					} );

					control.rows = ordered;
					control.open = orderedOpen;
					control.renderRows();
					control.sync();
				}
			} );
		},

		renderRows: function () {
			var control = this;

			control.$list.empty();

			_.each( control.rows, function ( row, index ) {
				control.$list.append(
					control.rowTemplate( {
						uid: control.uid,
						index: index,
						row: row || {},
						fields: control.params.fields || {},
						title: control.rowTitle( row, index ),
						collapsed: ! control.open[ index ],
						l10n: l10n
					} )
				);
			} );

			initColorPickers( control.$list );
			control.previewImages();
		},

		/*
		 * Readable text of one subfield. A select stores a key (a page id, a
		 * slug), so the header must show the option label instead — otherwise
		 * rows are named "33" and "31". Pictures and colours name nothing.
		 */
		fieldText: function ( key, value ) {
			var field = ( this.params.fields || {} )[ key ] || {};

			if ( 'image' === field.type || 'color' === field.type ) {
				return '';
			}

			if ( undefined === value || null === value || '' === value ) {
				return '';
			}

			if ( 'select' === field.type ) {
				var choices = field.choices || {};

				return undefined !== choices[ value ] ? String( choices[ value ] ) : String( value );
			}

			return String( value ).replace( /\s+/g, ' ' ).trim();
		},

		rowTitle: function ( row, index ) {
			var control = this;
			var keys = _.keys( control.params.fields || {} );
			var label = control.params.rowLabel;
			var title = '';

			/* The declared label field goes first, the rest stay as a fallback. */
			if ( label && _.contains( keys, label ) ) {
				keys = [ label ].concat( _.without( keys, label ) );
			}

			_.find( keys, function ( key ) {
				title = control.fieldText( key, ( row || {} )[ key ] );

				return '' !== title;
			} );

			return title ? title.substring( 0, 60 ) : l10n.row + ' ' + ( index + 1 );
		},

		updateTitle: function ( index ) {
			this.$list
				.find( '.mvweb-cz-repeater__row[data-index="' + index + '"] .mvweb-cz-repeater__title' )
				.text( this.rowTitle( this.rows[ index ], index ) );
		},

		/*
		 * An attachment id is stored, not an address. An address stops working
		 * the moment the site moves to another domain, and it carries no sizes,
		 * so a template holding one can only print the original file.
		 */
		pickImage: function ( $field ) {
			var frame = wp.media( { multiple: false, library: { type: 'image' } } );

			frame.on( 'select', function () {
				var attachment = frame.state().get( 'selection' ).first().toJSON();

				setValue( $field.find( '.mvweb-cz-repeater__input' ), attachment.id );
				showImage( $field, thumbUrl( attachment ) );
			} );

			frame.open();
		},

		/*
		 * Rows arrive holding ids, and only the media library knows what an id
		 * looks like. One fetch per picture, after the rows are in the DOM.
		 */
		previewImages: function () {
			this.$list.find( '.mvweb-cz-repeater__image' ).each( function () {
				var $field = $( this ).closest( '.mvweb-cz-repeater__field' );
				var id = parseInt( $field.find( '.mvweb-cz-repeater__input' ).val(), 10 );

				if ( ! id || ! wp.media || ! wp.media.attachment ) {
					return;
				}

				var attachment = wp.media.attachment( id );

				attachment.fetch().then( function () {
					showImage( $field, thumbUrl( attachment.toJSON() ) );
				} ).fail( function () {
					showImage( $field, '' );
				} );
			} );
		},

		sync: function () {
			setValue( this.$value, JSON.stringify( this.rows ) );
		}
	} );

	/* Sortable. */

	api.controlConstructor.mvweb_cz_sortable = api.Control.extend( {
		ready: function () {
			var control = this;

			control.itemTemplate = wp.template( 'mvweb-cz-sortable-item' );
			control.$list = control.container.find( '.mvweb-cz-sortable__items' );
			control.$value = control.container.find( '.mvweb-cz-sortable__value' );

			control.renderItems();

			control.container.on( 'change', '.mvweb-cz-sortable__toggle', function () {
				control.sync();
			} );

			control.$list.sortable( {
				handle: '.mvweb-cz-sortable__handle',
				update: function () {
					control.sync();
				}
			} );
		},

		renderItems: function () {
			var control = this;
			var choices = control.params.choices || {};
			var order = _.isArray( control.params.order ) ? control.params.order : [];
			var slugs = _.union( _.filter( order, function ( slug ) {
				return _.has( choices, slug );
			} ), _.keys( choices ) );

			control.$list.empty();

			_.each( slugs, function ( slug ) {
				control.$list.append(
					control.itemTemplate( {
						slug: slug,
						label: choices[ slug ],
						active: _.contains( order, slug )
					} )
				);
			} );
		},

		sync: function () {
			var active = [];

			this.$list.find( '.mvweb-cz-sortable__item' ).each( function () {
				var $item = $( this );

				if ( $item.find( '.mvweb-cz-sortable__toggle' ).is( ':checked' ) ) {
					active.push( $item.data( 'slug' ) );
				}
			} );

			setValue( this.$value, JSON.stringify( active ) );
		}
	} );

	/*
	 * Layout hints. Nothing here writes a setting: groups fold fields away,
	 * tooltips hold long notes, device pairs show one of two ranges, links jump
	 * to another section, the search finds a field by its label.
	 */

	var ui = data.ui || {};

	function isHeading( control ) {
		return 'mvweb_cz_heading' === control.params.type;
	}

	/* The fields between a heading and the next one, in the order core sorts them. */
	function groupMembers( heading ) {
		var section = api.section( heading.section() );
		var members = [];
		var inside = false;

		if ( ! section ) {
			return members;
		}

		_.each( section.controls(), function ( control ) {
			if ( control === heading ) {
				inside = true;
				return;
			}

			if ( inside && isHeading( control ) ) {
				inside = false;
			}

			if ( inside ) {
				members.push( control );
			}
		} );

		return members;
	}

	function summaryText( settings ) {
		var parts = [];

		_.each( settings, function ( id ) {
			var value = api( id ) ? api( id ).get() : '';
			var control = api.control( id );
			var choices = control && control.params.choices ? control.params.choices : {};

			if ( 'string' === typeof value && /^\s*\[/.test( value ) ) {
				try {
					value = JSON.parse( value );
				} catch ( e ) {
					value = [];
				}
			}

			if ( _.isArray( value ) ) {
				_.each( value, function ( slug ) {
					parts.push( choices[ slug ] || slug );
				} );
			} else if ( value && 'string' === typeof value ) {
				parts.push( value.replace( /<[^>]*>/g, '' ).trim() );
			}
		} );

		parts = _.filter( parts, Boolean );

		return parts.length ? parts.join( ' · ' ) : ( l10n.notSet || '' );
	}

	function bindGroup( heading, hints ) {
		var $title = heading.container.find( '.mvweb-cz-heading__title' );
		var $button = $( '<button type="button" class="mvweb-cz-heading__toggle"></button>' ).text( $title.text() );
		var $summary = $( '<span class="mvweb-cz-heading__summary"></span>' );
		var collapsed = !! hints.collapsed;

		heading.container.addClass( 'mvweb-cz-group' );
		$title.empty().append( $button, $summary );

		function apply() {
			$button.attr( 'aria-expanded', String( ! collapsed ) );
			heading.container.toggleClass( 'is-collapsed', collapsed );

			_.each( groupMembers( heading ), function ( control ) {
				control.container.toggleClass( 'mvweb-cz-group-hidden', collapsed );
			} );
		}

		heading.mvwebCzExpand = function () {
			collapsed = false;
			apply();
		};

		$button.on( 'click', function () {
			collapsed = ! collapsed;
			apply();
		} );

		if ( hints.summary ) {
			var refresh = function () {
				$summary.text( summaryText( hints.summary ) );
			};

			_.each( hints.summary, function ( id ) {
				api( id, function ( setting ) {
					setting.bind( refresh );
				} );
			} );

			refresh();
		}

		/* A switch for the whole group sits in the heading row instead of a field of its own. */
		if ( hints.toggle ) {
			api.control( hints.toggle, function ( toggle ) {
				var $switch = toggle.container.find( '.mvweb-cz-toggle__switch' );

				$switch.find( 'input' ).attr( 'aria-label', $title.text() || $button.text() );
				$title.append( $switch );
				toggle.container.addClass( 'mvweb-cz-moved' );
			} );
		}

		apply();
	}

	function bindTooltip( control, text ) {
		var id = 'mvweb-cz-tip-' + control.id.replace( /[^\w-]/g, '_' );
		var $title = control.container.find( '.customize-control-title' ).first();
		var $tip = $( '<span class="mvweb-cz-tip"></span>' );

		if ( ! $title.length ) {
			return;
		}

		$tip.append(
			$( '<button type="button" class="mvweb-cz-tip__button"></button>' )
				.attr( { 'aria-label': l10n.hint || '?', 'aria-describedby': id } )
				.text( '?' ),
			$( '<span class="mvweb-cz-tip__text" role="tooltip"></span>' ).attr( 'id', id ).text( text )
		);

		control.container.addClass( 'mvweb-cz-has-tip' );
		$title.after( $tip );
	}

	/* Two ranges for the same thing on two kinds of screens show as one, with a switch. */
	function bindDevices( pairs ) {
		function current() {
			return 'desktop' === api.previewedDevice.get() ? 'desktop' : 'mobile';
		}

		function apply() {
			_.each( pairs, function ( members ) {
				_.each( members, function ( member ) {
					api.control( member.id, function ( control ) {
						control.container.toggleClass( 'mvweb-cz-device-hidden', member.device !== current() );
					} );
				} );
			} );
		}

		_.each( pairs, function ( members ) {
			_.each( members, function ( member ) {
				api.control( member.id, function ( control ) {
					var $switch = $( '<span class="mvweb-cz-devices"></span>' );

					_.each( [ 'desktop', 'mobile' ], function ( device ) {
						$switch.append(
							$( '<button type="button" class="mvweb-cz-devices__button"></button>' )
								.toggleClass( 'is-active', device === member.device )
								.attr( { 'aria-label': l10n[ device ] || device, 'aria-pressed': String( device === member.device ) } )
								.append( $( '<span class="dashicons" aria-hidden="true"></span>' ).addClass( 'desktop' === device ? 'dashicons-desktop' : 'dashicons-smartphone' ) )
								.on( 'click', function () {
									api.previewedDevice.set( device );
								} )
						);
					} );

					control.container.addClass( 'mvweb-cz-has-devices' ).find( '.customize-control-title' ).first().after( $switch );
				} );
			} );
		} );

		api.previewedDevice.bind( apply );
		apply();
	}

	/* Open the folded group a field sits in, then hand over to core. */
	function reveal( control ) {
		var section = api.section( control.section() );

		if ( section ) {
			_.each( section.controls(), function ( other ) {
				if ( other.mvwebCzExpand && _.contains( groupMembers( other ), control ) ) {
					other.mvwebCzExpand();
				}
			} );
		}

		control.focus();
	}

	function focusTarget( id ) {
		if ( api.section( id ) ) {
			api.section( id ).focus();
		} else if ( api.panel( id ) ) {
			api.panel( id ).focus();
		} else if ( api.control( id ) ) {
			reveal( api.control( id ) );
		}
	}

	function bindSearch() {
		var $root = $( '#customize-theme-controls > .customize-pane-parent' );
		var $box = $( '<li class="mvweb-cz-search"></li>' );
		var $input = $( '<input type="search" class="mvweb-cz-search__input" autocomplete="off">' ).attr( { placeholder: l10n.search || '', 'aria-label': l10n.search || '' } );
		var $results = $( '<ul class="mvweb-cz-search__results" hidden></ul>' );
		var index = [];

		function build() {
			index = [];

			api.control.each( function ( control ) {
				var label = String( control.params.label || '' ).replace( /<[^>]*>/g, '' ).trim();
				var section = api.section( control.section() );
				var panel = section && section.panel() ? api.panel( section.panel() ) : null;

				if ( ! label || ! section || /^nav_menu/.test( control.params.type ) ) {
					return;
				}

				index.push( {
					control: control,
					label: label,
					path: ( panel ? panel.params.title + ' ▸ ' : '' ) + section.params.title,
					haystack: ( label + ' ' + section.params.title ).toLowerCase(),
				} );
			} );
		}

		function show( query ) {
			var found;

			$results.empty();

			if ( query.length < 2 ) {
				$results.attr( 'hidden', true );
				return;
			}

			found = _.filter( index, function ( item ) {
				return -1 !== item.haystack.indexOf( query );
			} ).slice( 0, 15 );

			if ( ! found.length ) {
				$results.append( $( '<li class="mvweb-cz-search__empty"></li>' ).text( l10n.nothingFound || '' ) );
			}

			_.each( found, function ( item ) {
				$results.append(
					$( '<li></li>' ).append(
						$( '<button type="button" class="mvweb-cz-search__item"></button>' )
							.append( $( '<span class="mvweb-cz-search__label"></span>' ).text( item.label ), $( '<span class="mvweb-cz-search__path"></span>' ).text( item.path ) )
							.on( 'click', function () {
								$input.val( '' );
								$results.attr( 'hidden', true ).empty();
								reveal( item.control );
							} )
					)
				);
			} );

			$results.removeAttr( 'hidden' );
		}

		if ( ! $root.length ) {
			return;
		}

		$box.append( $input, $results );
		$root.prepend( $box );

		$input.on( 'focus', build ).on( 'input', function () {
			show( $input.val().trim().toLowerCase() );
		} ).on( 'keydown', function ( event ) {
			if ( 'Escape' === event.key ) {
				$input.val( '' );
				show( '' );
			}
		} );
	}

	/* Titles over groups of panels; core re-appends its items on reflow, so they are put back each time. */
	function placePanelGroups() {
		var groups = data.panelGroups || {};
		var items = [];
		var previous;

		if ( _.isEmpty( groups ) ) {
			return;
		}

		$( '.mvweb-cz-panel-group' ).remove();

		api.panel.each( function ( panel ) {
			items.push( panel );
		} );

		api.section.each( function ( section ) {
			if ( ! section.panel() ) {
				items.push( section );
			}
		} );

		items = _.sortBy( _.filter( items, function ( item ) {
			return item.active() && item.headContainer && item.headContainer.parent().length;
		} ), function ( item ) {
			return item.priority();
		} );

		_.each( items, function ( item ) {
			var group = groups[ item.id ] || '';

			if ( undefined !== previous && group !== previous ) {
				item.headContainer.before( $( '<li class="mvweb-cz-panel-group" aria-hidden="true"></li>' ).text( group || l10n.otherGroup || '' ) );
			}

			previous = group;
		} );
	}

	function bindUi() {
		var pairs = {};

		_.each( ui, function ( hints, controlId ) {
			api.control( controlId, function ( control ) {
				if ( hints.dependent ) {
					control.container.addClass( 'mvweb-cz-dependent' );
				}

				if ( hints.tooltip ) {
					bindTooltip( control, hints.tooltip );
				}

				if ( hints.collapsible && isHeading( control ) ) {
					bindGroup( control, hints );
				}
			} );

			if ( hints.deviceGroup && hints.device ) {
				pairs[ hints.deviceGroup ] = pairs[ hints.deviceGroup ] || [];
				pairs[ hints.deviceGroup ].push( { id: controlId, device: hints.device } );
			}
		} );

		bindDevices( pairs );

		$( document ).on( 'click', '.mvweb-cz-goto', function ( event ) {
			event.preventDefault();
			focusTarget( $( this ).data( 'target' ) );
		} );

		/* The pencil buttons in the preview ask for a section by id. */
		api.previewer.bind( 'mvweb-cz-focus', focusTarget );

		bindSearch();
		placePanelGroups();
		api.bind( 'pane-contents-reflowed', placePanelGroups );
	}

	/* Boot. */

	api.bind( 'ready', function () {
		var context = $( '#customize-theme-controls' );

		bindRange( context );
		bindMulticheck( context );
		bindDimension( context );
		bindTypography( context );
		bindDependencies();
		bindUi();

		api.section.each( function ( section ) {
			section.expanded.bind( function ( expanded ) {
				if ( expanded ) {
					initEditors( section.contentContainer );
				}
			} );
		} );
	} );
} )( jQuery, wp.customize );
