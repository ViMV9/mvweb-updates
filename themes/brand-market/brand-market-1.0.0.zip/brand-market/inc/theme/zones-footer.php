<?php
/**
 * The footer zones: their names, hints and the default order of the design.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_footer_default_order' ) ) {
	/**
	 * The elements of the footer zones in the order of the design.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $order Element slugs.
	 * @param string   $zone  Zone slug.
	 *
	 * @return string[]
	 */
	function mvweb_theme_footer_default_order( $order, $zone ) {
		$design = array(
			'footer-main'   => array( 'brand', 'menu', 'menu-2', 'contacts' ),
			'footer-bottom' => array( 'copyright', 'requisites', 'legal', 'dev-badge' ),
		);

		return isset( $design[ $zone ] ) ? $design[ $zone ] : $order;
	}
}
add_filter( 'mvweb_core_zone_default_order', 'mvweb_theme_footer_default_order', 10, 2 );

if ( ! function_exists( 'mvweb_theme_footer_contacts_parts' ) ) {
	/**
	 * The parts of the footer contacts in the order of the design.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $layouts Area => definition.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_footer_contacts_parts( $layouts ) {
		if ( ! isset( $layouts['footer.contacts']['parts'] ) ) {
			return $layouts;
		}

		$parts = $layouts['footer.contacts']['parts'];
		$first = array();

		foreach ( array( 'phones', 'hours', 'email', 'address' ) as $slug ) {
			if ( isset( $parts[ $slug ] ) ) {
				$first[ $slug ] = $parts[ $slug ];
			}
		}

		$layouts['footer.contacts']['parts'] = $first + $parts;

		return $layouts;
	}
}
add_filter( 'mvweb_core_layouts', 'mvweb_theme_footer_contacts_parts', 20 );

if ( ! function_exists( 'mvweb_theme_footer_zone_texts' ) ) {
	/**
	 * The name and the hint of every footer zone, in words of the owner.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,string>> Zone slug => name and hint.
	 */
	function mvweb_theme_footer_zone_texts() {
		return array(
			'footer-main'   => array(
				'label' => __( 'Footer: columns', 'brand-market' ),
				'hint'  => __( 'The columns at the bottom of the page: logo, menus, contacts.', 'brand-market' ),
			),
			'footer-bottom' => array(
				'label' => __( 'Footer: bottom line', 'brand-market' ),
				'hint'  => __( 'The thin line at the very bottom: copyright, company details, legal links.', 'brand-market' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_footer_zone_labels' ) ) {
	/**
	 * The names of the footer zones.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $zones Zone slug => label.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_footer_zone_labels( $zones ) {
		foreach ( mvweb_theme_footer_zone_texts() as $zone => $texts ) {
			if ( isset( $zones[ $zone ] ) ) {
				$zones[ $zone ] = $texts['label'];
			}
		}

		return $zones;
	}
}
add_filter( 'mvweb_core_zones', 'mvweb_theme_footer_zone_labels', 20 );

if ( ! function_exists( 'mvweb_theme_footer_zone_hints' ) ) {
	/**
	 * The hints under the footer zones in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $hints Zone slug => hint.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_footer_zone_hints( $hints ) {
		foreach ( mvweb_theme_footer_zone_texts() as $zone => $texts ) {
			$hints[ $zone ] = $texts['hint'];
		}

		return $hints;
	}
}
add_filter( 'mvweb_core_zone_hints', 'mvweb_theme_footer_zone_hints' );
