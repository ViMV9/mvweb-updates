<?php
/**
 * Composition areas of the cart, the checkout, the order received page and the side cart.
 *
 * The steps of the checkout and the order total are not here: their order is
 * the order of the actions of the customer.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_panel   = 'mvweb_cz_conversion';
$mvweb_section = 'mvweb_cz_conversion_cart';
$mvweb_hint    = __( 'Drag to reorder. Untick to hide. A part with nothing to say is not printed.', 'brand-market' );

return array(
	'cart.hero'     => array(
		'label'       => __( 'Cart: facts under the heading', 'brand-market' ),
		'description' => $mvweb_hint,
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'count'    => __( 'Number of goods', 'brand-market' ),
			'shipping' => __( 'Free delivery', 'brand-market' ),
		),
	),
	'cart.page'     => array(
		'label'       => __( 'Cart: blocks of the page', 'brand-market' ),
		'description' => $mvweb_hint,
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'lines' => __( 'Lines and order total', 'brand-market' ),
			'cross' => __( 'Goods bought together', 'brand-market' ),
		),
	),
	'cart.tools'    => array(
		'label'       => __( 'Cart: tools under the lines', 'brand-market' ),
		'description' => $mvweb_hint,
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'coupon' => __( 'Promo code', 'brand-market' ),
			'links'  => __( 'Continue shopping and empty the cart', 'brand-market' ),
		),
	),
	'cart.aside'    => array(
		'label'       => __( 'Cart: under the order total', 'brand-market' ),
		'description' => $mvweb_hint,
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'notes' => __( 'Notes', 'brand-market' ),
		),
	),
	'cart-line'     => array(
		'label'       => __( 'Cart: a line', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The name and the price stay. The minimum line always stands under the quantity field.', 'brand-market' ),
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'brand' => __( 'Brand', 'brand-market' ),
			'title' => __( 'Name', 'brand-market' ),
			'meta'  => __( 'Article and stock', 'brand-market' ),
			'price' => __( 'Price', 'brand-market' ),
			'hint'  => __( 'Wholesale price hint', 'brand-market' ),
			'limit' => __( 'Minimum and step', 'brand-market' ),
		),
	),
	'checkout.hero' => array(
		'label'       => __( 'Checkout: facts under the heading', 'brand-market' ),
		'description' => $mvweb_hint,
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'secure' => __( 'Protected connection', 'brand-market' ),
			'login'  => __( 'Link for a returning customer', 'brand-market' ),
		),
	),
	'thanks.page'   => array(
		'label'       => __( 'Order received: blocks of the page', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The order number, the date, the total and the order items stay.', 'brand-market' ),
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'info'    => __( 'Delivery and recipient', 'brand-market' ),
			'pay'     => __( 'Instructions of the payment method', 'brand-market' ),
			'next'    => __( 'What happens next', 'brand-market' ),
			'actions' => __( 'Buttons', 'brand-market' ),
		),
	),
	'pay-fail'      => array(
		'label'       => __( 'Failed payment: blocks of the page', 'brand-market' ),
		'description' => $mvweb_hint,
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'actions' => __( 'Buttons', 'brand-market' ),
			'reasons' => __( 'Usual reasons and contacts', 'brand-market' ),
		),
	),
	'side-cart'     => array(
		'label'       => __( 'Side cart: parts', 'brand-market' ),
		'description' => $mvweb_hint,
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'ship' => __( 'Line about free delivery', 'brand-market' ),
		),
	),
);
