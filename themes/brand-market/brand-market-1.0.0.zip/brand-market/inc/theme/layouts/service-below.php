<?php
/**
 * Composition area: Blocks under the page of a service.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'service-below' => array(
		'label'       => __( 'Under the service page', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The blocks are those built in the page builder of the service.', 'brand-market' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_page',
		'parts'       => array(
			'sections' => __( 'Blocks of the service', 'brand-market' ),
			'works'    => __( 'Works on the service', 'brand-market' ),
			'related'  => __( 'Other services of the section', 'brand-market' ),
		),
	),
);
