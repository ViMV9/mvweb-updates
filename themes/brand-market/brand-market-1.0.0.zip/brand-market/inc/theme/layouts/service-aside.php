<?php
/**
 * Composition area: Side card of the page of a service.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'service-aside' => array(
		'label'       => __( 'Side card of the service page', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide.', 'brand-market' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_page',
		'parts'       => array(
			'title'      => __( 'Heading', 'brand-market' ),
			'price'      => __( 'Price', 'brand-market' ),
			'form'       => __( 'Form or button', 'brand-market' ),
			'phone'      => __( 'Phone', 'brand-market' ),
			'messengers' => __( 'Messengers', 'brand-market' ),
			'note'       => __( 'Note', 'brand-market' ),
			'share'      => __( 'Share buttons', 'brand-market' ),
		),
	),
);
