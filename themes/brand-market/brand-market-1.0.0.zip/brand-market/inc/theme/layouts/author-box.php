<?php
/**
 * Composition area: the block about the author under an entry.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'author-box' => array(
		'label'       => __( 'Author block', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The picture stays on the left.', 'brand-market' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_single',
		'parts'       => array(
			'avatar'  => __( 'Picture', 'brand-market' ),
			'bio'     => __( 'Description from the profile', 'brand-market' ),
			'more'    => __( 'Link to all posts of the author', 'brand-market' ),
			'socials' => __( 'Links of the author', 'brand-market' ),
		),
	),
);
