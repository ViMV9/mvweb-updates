<?php
/**
 * Composition area: what follows the title of an entry.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'post-head' => array(
		'label'       => __( 'Under the title of a post', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The parts that stand after the cover go under it.', 'brand-market' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_single',
		'parts'       => array(
			'lead'   => __( 'Excerpt', 'brand-market' ),
			'byline' => __( 'Author with position', 'brand-market' ),
			'cover'  => __( 'Cover', 'brand-market' ),
		),
	),
);
