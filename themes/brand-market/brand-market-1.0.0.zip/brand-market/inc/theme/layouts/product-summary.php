<?php
/**
 * Composition area: the column beside the photo of an item.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'product-summary' => array(
		'label'       => __( 'Item summary', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The header stays first.', 'brand-market' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_product',
		'parts'       => array(
			'excerpt'  => __( 'Short description', 'brand-market' ),
			'switch'   => __( 'Links by the value of a property', 'brand-market' ),
			'purchase' => __( 'Purchase box', 'brand-market' ),
			'specs'    => __( 'Main specifications', 'brand-market' ),
			'share'    => __( 'Share buttons', 'brand-market' ),
		),
	),
);
