<?php
/**
 * Composition area: the photo of an item.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'product-media' => array(
		'label'       => __( 'Item photo', 'brand-market' ),
		'description' => __( 'Untick to hide. The big photo and the arrows stay; the badges and the strip of small photos can go.', 'brand-market' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_product',
		'parts'       => array(
			'badges' => __( 'Badges on the photo', 'brand-market' ),
			'thumbs' => __( 'Strip of small photos', 'brand-market' ),
		),
	),
);
