<?php
/**
 * Composition of the product card: which parts it shows and in what order.
 *
 * One composition for every place the card stands in: listings, blocks, the
 * favourites. The badges, the favourites button and the wholesale column
 * have no file of their own: they sit on the photo and beside the price,
 * so the card reads their switch and the order of the rest.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'card-product' => array(
		'label'       => __( 'Product card', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The badges and the favourites button stay on the photo, the wholesale price stays beside the price, the quantity stays before the button of a shop listing, the article and the stock show in the table view of a listing.', 'brand-market' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_archive',
		'parts'       => array(
			'badges'  => __( 'Badges on the photo', 'brand-market' ),
			'fav'     => __( 'Favourites button', 'brand-market' ),
			'compare' => __( 'Compare button', 'brand-market' ),
			'brand'   => __( 'Brand', 'brand-market' ),
			'rating'  => __( 'Rating', 'brand-market' ),
			'title'   => __( 'Name', 'brand-market' ),
			'meta'    => __( 'Article and stock', 'brand-market' ),
			'price'   => __( 'Price', 'brand-market' ),
			'opt'     => __( 'Wholesale price', 'brand-market' ),
			'qty'     => __( 'Quantity field', 'brand-market' ),
			'buy'     => __( 'Button', 'brand-market' ),
		),
	),
);
