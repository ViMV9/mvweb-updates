<?php
/**
 * Composition area: Head of the page of a service: the line, the short text and the button for a phone.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'service-head' => array(
		'label'       => __( 'Head of the service page', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The button with the price shows on narrow screens only.', 'brand-market' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_page',
		'parts'       => array(
			'advantage' => __( 'Line under the heading', 'brand-market' ),
			'excerpt'   => __( 'Short text', 'brand-market' ),
			'jump'      => __( 'Price and button', 'brand-market' ),
		),
	),
);
