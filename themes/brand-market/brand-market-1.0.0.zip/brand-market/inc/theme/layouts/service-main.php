<?php
/**
 * Composition area: Text column of the page of a service.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'service-main' => array(
		'label'       => __( 'Text of the service page', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide.', 'brand-market' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_page',
		'parts'       => array(
			'gallery' => __( 'Photos', 'brand-market' ),
			'story'   => __( 'Text', 'brand-market' ),
		),
	),
);
