<?php
/**
 * Composition area: the card of a blog post.
 *
 * One card for the blog, the archives, the search and the blocks, so its parts
 * are set once for the site.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'card-post' => array(
		'label'   => __( 'Card of a post', 'brand-market' ),
		'panel'   => 'mvweb_cz_inner',
		'section' => 'mvweb_cz_inner_archive',
		'parts'   => array(
			'media' => __( 'Cover', 'brand-market' ),
			'topic' => __( 'Category', 'brand-market' ),
			'date'  => __( 'Date', 'brand-market' ),
			'read'  => __( 'Reading time', 'brand-market' ),
			'title' => __( 'Title', 'brand-market' ),
			'lead'  => __( 'Excerpt', 'brand-market' ),
			'more'  => __( 'Read more', 'brand-market' ),
		),
	),
);
