<?php
/**
 * Composition area: Section card: the picture, the name, the number of services and the link.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'card-service-section' => array(
		'label'       => __( 'Card of a section of services', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The picture stays on top of the card. The strip of subsections shows the picture, the name and the number only.', 'brand-market' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_list',
		'parts'       => array(
			'image' => __( 'Picture', 'brand-market' ),
			'title' => __( 'Name', 'brand-market' ),
			'count' => __( 'Number of services', 'brand-market' ),
			'more'  => __( 'Link', 'brand-market' ),
		),
	),
);
