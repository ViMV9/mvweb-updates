<?php
/**
 * Composition area: the bands under an entry.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'post-below' => array(
		'label'       => __( 'Bands under a post', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. Comments are also switched off in Settings, Discussion.', 'brand-market' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_single',
		'parts'       => array(
			'related'  => __( 'More posts', 'brand-market' ),
			'comments' => __( 'Comments', 'brand-market' ),
		),
	),
);
