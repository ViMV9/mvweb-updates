<?php
/**
 * Composition area: the line above the title of an entry.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'post-meta' => array(
		'label'       => __( 'Line above the title of a post', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide.', 'brand-market' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_single',
		'parts'       => array(
			'topic' => __( 'Category', 'brand-market' ),
			'time'  => __( 'Date', 'brand-market' ),
			'read'  => __( 'Reading time', 'brand-market' ),
		),
	),
);
