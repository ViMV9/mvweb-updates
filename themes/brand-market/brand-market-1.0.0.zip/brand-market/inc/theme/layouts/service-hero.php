<?php
/**
 * Composition area: Facts under the heading of a section of services.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'service-hero' => array(
		'label'       => __( 'Under the heading of a section', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The points are written in the section itself.', 'brand-market' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_list',
		'parts'       => array(
			'count'  => __( 'Number of services', 'brand-market' ),
			'points' => __( 'Points of the section', 'brand-market' ),
		),
	),
);
