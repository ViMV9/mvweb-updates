<?php
/**
 * Composition area: the sections under an item.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'product-sections' => array(
		'label'       => __( 'Sections under the item', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The links above the sections follow this order. A section with nothing to say is not printed.', 'brand-market' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_product',
		'parts'       => array(
			'description' => __( 'Description', 'brand-market' ),
			'specs'       => __( 'Specifications', 'brand-market' ),
			'reviews'     => __( 'Reviews', 'brand-market' ),
			'upsells'     => __( 'Goods bought together', 'brand-market' ),
			'related'     => __( 'Similar items', 'brand-market' ),
		),
	),
);
