<?php
/**
 * Composition area: Service card: the picture, the name, the line under it, the price and the link.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'card-service' => array(
		'label'       => __( 'Card of a service', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The picture stays on top of the card. The price and the link stand in one line under the rest.', 'brand-market' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_list',
		'parts'       => array(
			'image'     => __( 'Picture', 'brand-market' ),
			'title'     => __( 'Name', 'brand-market' ),
			'advantage' => __( 'Line under the name', 'brand-market' ),
			'price'     => __( 'Price', 'brand-market' ),
			'more'      => __( 'Link', 'brand-market' ),
		),
	),
);
