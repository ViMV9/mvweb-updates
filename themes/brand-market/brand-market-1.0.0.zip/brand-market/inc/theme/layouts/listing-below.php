<?php
/**
 * Composition of what stands under a listing: the text of the category and the blocks.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'listing-below' => array(
		'label'       => __( 'Under a listing', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The pages of the listing stay above.', 'brand-market' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_archive',
		'parts'       => array(
			'text'   => __( 'Text of the category', 'brand-market' ),
			'blocks' => __( 'Blocks', 'brand-market' ),
		),
	),
);
