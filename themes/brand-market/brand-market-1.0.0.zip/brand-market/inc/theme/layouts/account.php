<?php
/**
 * Composition areas: the account of a customer.
 *
 * Three areas, one for each page that holds parts in an order that carries no
 * fixed meaning: the dashboard under the greeting, the page of an order under
 * its overview, and the sign-in page. The forms of WooCommerce print their own
 * fields, so what moves here are the blocks of the page, not the fields.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WooCommerce' ) ) {
	return array();
}

return array(
	'account-dashboard' => array(
		'label'         => __( 'Account: dashboard', 'brand-market' ),
		'description'   => __( 'Drag to reorder. Untick to hide. The greeting stays first.', 'brand-market' ),
		'panel'         => 'mvweb_cz_catalog',
		'section'       => 'mvweb_cz_catalog_account',
		'section_title' => __( 'Account', 'brand-market' ),
		'parts'         => array(
			'tiles'  => __( 'Tiles', 'brand-market' ),
			'recent' => __( 'Recent orders', 'brand-market' ),
		),
	),
	'account-order'     => array(
		'label'         => __( 'Account: page of an order', 'brand-market' ),
		'description'   => __( 'Drag to reorder. Untick to hide. The overview and the payment reminder stay on top.', 'brand-market' ),
		'panel'         => 'mvweb_cz_catalog',
		'section'       => 'mvweb_cz_catalog_account',
		'section_title' => __( 'Account', 'brand-market' ),
		'parts'         => array(
			'items'     => __( 'Contents and totals', 'brand-market' ),
			'addresses' => __( 'Delivery and contacts', 'brand-market' ),
			'timeline'  => __( 'History of the order', 'brand-market' ),
			'actions'   => __( 'Buttons', 'brand-market' ),
		),
	),
	'account-login'     => array(
		'label'         => __( 'Account: sign in page', 'brand-market' ),
		'description'   => __( 'Drag to reorder. Untick to hide. Registration also depends on the account settings of WooCommerce.', 'brand-market' ),
		'panel'         => 'mvweb_cz_catalog',
		'section'       => 'mvweb_cz_catalog_account',
		'section_title' => __( 'Account', 'brand-market' ),
		'parts'         => array(
			'login'    => __( 'Sign in', 'brand-market' ),
			'register' => __( 'Registration', 'brand-market' ),
			'perks'    => __( 'What an account gives', 'brand-market' ),
		),
	),
);
