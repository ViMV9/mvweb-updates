<?php
/**
 * Composition area: Head of a section in the tree of services.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'tree-head' => array(
		'label'       => __( 'Head of a section in the tree', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The number of services also stands beside the subsections.', 'brand-market' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_list',
		'parts'       => array(
			'cover' => __( 'Cover', 'brand-market' ),
			'count' => __( 'Number of services', 'brand-market' ),
			'title' => __( 'Name', 'brand-market' ),
			'desc'  => __( 'Description', 'brand-market' ),
			'more'  => __( 'Link', 'brand-market' ),
		),
	),
);
