<?php
/**
 * Composition of the pages of the lists: the favourites and the comparison.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_lists_section = __( 'Favourites and comparison', 'brand-market' );

return array(
	'favorites'    => array(
		'label'         => __( 'Favourites page', 'brand-market' ),
		'description'   => __( 'Drag to reorder. Untick to hide. The number of items stands under the heading, the note for a guest above the tools.', 'brand-market' ),
		'panel'         => 'mvweb_cz_catalog',
		'section'       => 'mvweb_cz_catalog_lists',
		'section_title' => $mvweb_lists_section,
		'parts'         => array(
			'count' => __( 'Number of items', 'brand-market' ),
			'note'  => __( 'Note for a guest', 'brand-market' ),
			'share' => __( 'Share the list', 'brand-market' ),
			'clear' => __( 'Clear the list', 'brand-market' ),
			'view'  => __( 'Cards or table', 'brand-market' ),
		),
	),
	'compare-bar'  => array(
		'label'         => __( 'Comparison: facts and tools', 'brand-market' ),
		'description'   => __( 'Drag to reorder. Untick to hide. The category choice shows only while items of more than one category are compared.', 'brand-market' ),
		'panel'         => 'mvweb_cz_catalog',
		'section'       => 'mvweb_cz_catalog_lists',
		'section_title' => $mvweb_lists_section,
		'parts'         => array(
			'meta'     => __( 'Facts under the heading', 'brand-market' ),
			'category' => __( 'Category choice', 'brand-market' ),
			'diff'     => __( 'Only differences switch', 'brand-market' ),
		),
	),
	'compare-rows' => array(
		'label'         => __( 'Comparison: rows of the table', 'brand-market' ),
		'description'   => __( 'Drag to reorder. Untick to hide. A row nobody has data for is not printed.', 'brand-market' ),
		'panel'         => 'mvweb_cz_catalog',
		'section'       => 'mvweb_cz_catalog_lists',
		'section_title' => $mvweb_lists_section,
		'parts'         => array(
			'wholesale' => __( 'Wholesale price', 'brand-market' ),
			'specs'     => __( 'Characteristics', 'brand-market' ),
			'sku'       => __( 'Article', 'brand-market' ),
			'stock'     => __( 'Availability', 'brand-market' ),
			'rating'    => __( 'Rating', 'brand-market' ),
		),
	),
);
