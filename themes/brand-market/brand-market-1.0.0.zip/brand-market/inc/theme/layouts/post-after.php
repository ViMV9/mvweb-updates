<?php
/**
 * Composition area: what follows the text of an entry.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'post-after' => array(
		'label'       => __( 'Under the text of a post', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The author block also needs the tick box "Show the author block" below.', 'brand-market' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_single',
		'parts'       => array(
			'tags'   => __( 'Tags', 'brand-market' ),
			'share'  => __( 'Share buttons', 'brand-market' ),
			'author' => __( 'Author block', 'brand-market' ),
			'nav'    => __( 'Previous and next post', 'brand-market' ),
		),
	),
);
