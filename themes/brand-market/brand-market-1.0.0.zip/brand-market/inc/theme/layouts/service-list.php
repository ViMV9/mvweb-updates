<?php
/**
 * Composition area: Blocks of the services listing: the strip of subsections and the list itself.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'service-list' => array(
		'label'       => __( 'Services listing', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The text under the list follows the list.', 'brand-market' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_list',
		'parts'       => array(
			'subs' => __( 'Strip of subsections', 'brand-market' ),
			'list' => __( 'Services', 'brand-market' ),
		),
	),
);
