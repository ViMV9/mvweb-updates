<?php
/**
 * Composition area: the purchase box of an item.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'product-purchase' => array(
		'label'       => __( 'Item purchase box', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. A part with nothing to say is not printed.', 'brand-market' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_product',
		'parts'       => array(
			'prices'    => __( 'Prices', 'brand-market' ),
			'tiers'     => __( 'Prices by quantity', 'brand-market' ),
			'total'     => __( 'Total for the quantity', 'brand-market' ),
			'buy'       => __( 'Buy or request buttons', 'brand-market' ),
			'compare'   => __( 'Compare button', 'brand-market' ),
			'note'      => __( 'Line under the buttons', 'brand-market' ),
			'markets'   => __( 'Marketplaces', 'brand-market' ),
			'benefits'  => __( 'Benefits', 'brand-market' ),
			'documents' => __( 'Documents', 'brand-market' ),
			'file'      => __( 'File link', 'brand-market' ),
		),
	),
);
