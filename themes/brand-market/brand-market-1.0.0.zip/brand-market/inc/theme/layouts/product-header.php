<?php
/**
 * Composition area: the header of an item page.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'product-header' => array(
		'label'       => __( 'Item header', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The name is always shown: it is the heading of the page.', 'brand-market' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_product',
		'parts'       => array(
			'brand'  => __( 'Brand', 'brand-market' ),
			'title'  => __( 'Name (always shown)', 'brand-market' ),
			'stock'  => __( 'Availability', 'brand-market' ),
			'sku'    => __( 'Article', 'brand-market' ),
			'rating' => __( 'Rating', 'brand-market' ),
		),
	),
);
