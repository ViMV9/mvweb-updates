<?php
/**
 * Composition areas: the page of a work.
 *
 * Four areas, one for each place of the page: the head, the side card, the
 * main column and the blocks under the page. The listing of the portfolio has
 * no area of its own: its parts stand in an order that carries meaning and are
 * switched by settings.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'work-head'   => array(
		'label'         => __( 'Work: head', 'brand-market' ),
		'description'   => __( 'Drag to reorder. Untick to hide. A hidden heading stays on the page for screen readers and search engines.', 'brand-market' ),
		'panel'         => 'mvweb_cz_services',
		'section'       => 'mvweb_cz_services_work',
		'section_title' => __( 'Work page', 'brand-market' ),
		'parts'         => array(
			'kind'    => __( 'Kind of work', 'brand-market' ),
			'title'   => __( 'Heading', 'brand-market' ),
			'excerpt' => __( 'Short text', 'brand-market' ),
		),
	),
	'work-aside'  => array(
		'label'         => __( 'Work: side card', 'brand-market' ),
		'description'   => __( 'Drag to reorder. Untick to hide.', 'brand-market' ),
		'panel'         => 'mvweb_cz_services',
		'section'       => 'mvweb_cz_services_work',
		'section_title' => __( 'Work page', 'brand-market' ),
		'parts'         => array(
			'title'   => __( 'Heading of the card', 'brand-market' ),
			'facts'   => __( 'Facts', 'brand-market' ),
			'service' => __( 'Service of the work', 'brand-market' ),
			'cta'     => __( 'Request button', 'brand-market' ),
			'share'   => __( 'Share', 'brand-market' ),
		),
	),
	'work-main'   => array(
		'label'         => __( 'Work: main column', 'brand-market' ),
		'description'   => __( 'Drag to reorder. Untick to hide.', 'brand-market' ),
		'panel'         => 'mvweb_cz_services',
		'section'       => 'mvweb_cz_services_work',
		'section_title' => __( 'Work page', 'brand-market' ),
		'parts'         => array(
			'gallery' => __( 'Gallery', 'brand-market' ),
			'story'   => __( 'Task and result', 'brand-market' ),
			'body'    => __( 'Text of the work', 'brand-market' ),
			'review'  => __( 'Review of the client', 'brand-market' ),
		),
	),
	'work-blocks' => array(
		'label'         => __( 'Work: blocks under the page', 'brand-market' ),
		'description'   => __( 'Drag to reorder. Untick to hide.', 'brand-market' ),
		'panel'         => 'mvweb_cz_services',
		'section'       => 'mvweb_cz_services_work',
		'section_title' => __( 'Work page', 'brand-market' ),
		'parts'         => array(
			'before-after' => __( 'Before and after', 'brand-market' ),
			'related'      => __( 'Other works', 'brand-market' ),
		),
	),
);
