<?php
/**
 * Composition area: the heading of the archive of an author.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'author-head' => array(
		'label'       => __( 'Heading of an author archive', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The picture stays on the left.', 'brand-market' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_archive',
		'parts'       => array(
			'avatar' => __( 'Picture', 'brand-market' ),
			'lead'   => __( 'Description from the profile', 'brand-market' ),
			'count'  => __( 'Number of posts', 'brand-market' ),
			'since'  => __( 'With the site since', 'brand-market' ),
		),
	),
);
