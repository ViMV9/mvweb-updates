<?php
/**
 * Composition area: the card of a work.
 *
 * One composition for every card of a work: in the block, in the portfolio,
 * under a service and among the other works.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'card-work' => array(
		'label'       => __( 'Card of a work', 'brand-market' ),
		'description' => __( 'Drag to reorder. Untick to hide. The picture stays where the view of the block puts it.', 'brand-market' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_works',
		'parts'       => array(
			'number' => __( 'Number in the ribbon view', 'brand-market' ),
			'kind'   => __( 'Kind of work', 'brand-market' ),
			'title'  => __( 'Name', 'brand-market' ),
			'facts'  => __( 'Facts', 'brand-market' ),
			'arrow'  => __( 'Arrow in the photo and list views', 'brand-market' ),
		),
	),
);
