<?php
/**
 * Updates over the air.
 *
 * The studio wrapper MVweb_Updater is not used: its class name is global, every
 * studio plugin bundles a copy, and an older copy loaded first drops the flag
 * that says "theme". The theme talks to the library directly.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_register_updates' ) ) {
	/**
	 * Point the update checker at the studio's metadata for this theme.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_register_updates() {
		$library = MVWEB_THEME_DIR . '/includes/plugin-update-checker/plugin-update-checker.php';

		if ( ! class_exists( 'YahnisElsts\PluginUpdateChecker\v5\PucFactory' ) ) {
			if ( ! file_exists( $library ) ) {
				return;
			}

			require_once $library;
		}

		if ( ! class_exists( 'YahnisElsts\PluginUpdateChecker\v5\PucFactory' ) ) {
			return;
		}

		$checker = \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
			'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/themes/brand-market/info.json',
			MVWEB_THEME_DIR . '/style.css',
			'brand-market'
		);

		if ( ! class_exists( 'MVweb_License' ) && file_exists( MVWEB_THEME_DIR . '/includes/class-mvweb-license.php' ) ) {
			require_once MVWEB_THEME_DIR . '/includes/class-mvweb-license.php';
		}

		if ( class_exists( 'MVweb_License' ) ) {
			MVweb_License::init( 'brand-market', $checker, 'theme' );
		}
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_register_updates' );
