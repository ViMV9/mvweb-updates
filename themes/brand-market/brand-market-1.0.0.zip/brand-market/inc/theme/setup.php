<?php
/**
 * Theme setup that belongs to the design: content width, starter home.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_load_textdomain' ) ) {
	/**
	 * Load the theme translations from languages/{locale}.mo.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_load_textdomain() {
		load_theme_textdomain( 'brand-market', MVWEB_THEME_DIR . '/languages' );
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_load_textdomain' );

if ( ! function_exists( 'mvweb_theme_content_width' ) ) {
	/**
	 * Set the global content width.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_content_width() {
		$GLOBALS['content_width'] = 1200;
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_content_width', 0 );

if ( ! function_exists( 'mvweb_theme_seed_home' ) ) {
	/**
	 * Fill the homepage on first activation.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_seed_home() {
		$unset = '__mvweb_unset__';

		if ( get_theme_mod( 'mvweb_home_rows', $unset ) !== $unset ) {
			return;
		}

		$rows = array(
			array(
				'uid'   => wp_generate_uuid4(),
				'type'  => 'hero',
				'props' => array(
					'title'       => __( 'A heading that says what the company makes', 'brand-market' ),
					'button_text' => __( 'Request a quote', 'brand-market' ),
					'button_url'  => '#request',
					'features'    => array(
						array( 'text' => __( 'A promise the visitor cares about', 'brand-market' ) ),
						array( 'text' => __( 'A second promise', 'brand-market' ) ),
						array( 'text' => __( 'A third promise', 'brand-market' ) ),
					),
					'trust'       => array(
						array(
							'number' => '14',
							'text'   => __( 'years in the trade', 'brand-market' ),
						),
						array(
							'number' => '3000',
							'text'   => __( 'projects delivered', 'brand-market' ),
						),
					),
				),
			),
			array(
				'uid'   => wp_generate_uuid4(),
				'type'  => 'features',
				'props' => array(
					'title'  => __( 'What the company is good at', 'brand-market' ),
					'text'   => __( 'Two or three sentences about the approach.', 'brand-market' ),
					'blocks' => array(
						array(
							'icon'  => 'tools',
							'title' => __( 'The whole job, start to finish', 'brand-market' ),
							'text'  => __( "Design\nEngineering\nProduction\nInstallation", 'brand-market' ),
						),
						array(
							'icon'  => 'star',
							'title' => __( 'Quality', 'brand-market' ),
							'text'  => __( "What the materials are\nHow the work is checked", 'brand-market' ),
						),
						array(
							'icon'  => 'clock',
							'title' => __( 'Experience', 'brand-market' ),
							'text'  => __( "Since which year\nHow many people", 'brand-market' ),
						),
					),
				),
			),
			array(
				'uid'   => wp_generate_uuid4(),
				'type'  => 'banner',
				'props' => array(
					'title'       => __( 'A line that carries the offer', 'brand-market' ),
					'text'        => __( 'A short sentence under it.', 'brand-market' ),
					'button_text' => __( 'See the work', 'brand-market' ),
					'button_url'  => '#request',
				),
			),
		);

		set_theme_mod( 'mvweb_home_rows', wp_json_encode( $rows ) );
	}
}
add_action( 'after_switch_theme', 'mvweb_theme_seed_home' );

if ( ! function_exists( 'mvweb_theme_inherit_mods' ) ) {
	/**
	 * Hand the settings of the parent theme to a child theme activated for the first time.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_inherit_mods() {
		$child = 'theme_mods_' . get_stylesheet();

		if ( get_template() === get_stylesheet() || get_option( $child ) ) {
			return;
		}

		update_option( $child, get_option( 'theme_mods_' . get_template() ) );
	}
}
add_action( 'after_switch_theme', 'mvweb_theme_inherit_mods', 5 );
