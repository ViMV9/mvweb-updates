<?php
/**
 * The Customizer as the owner of a shop sees it.
 *
 * Sections named after the shop and grouped by task, fields in the order the
 * page shows them, one switch per thing: a part of a list is its only switch.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_customizer_switches' ) ) {
	/**
	 * Switches that duplicated a part of a list: setting => default, then area => part.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array{0:bool,1:array<string,string>}>
	 */
	function mvweb_theme_customizer_switches() {
		return array(
			'mvweb_crumbs_enable'       => array( true, array( 'page-hero' => 'crumbs' ) ),
			'mvweb_404_search'          => array( true, array( 'notfound' => 'search' ) ),
			'mvweb_author_box'          => array( false, array( 'post-after' => 'author' ) ),
			'mvweb_catalog_view_switch' => array(
				true,
				array(
					'catalog-toolbar' => 'view',
					'favorites'       => 'view',
				),
			),
			'mvweb_service_tree_desc'   => array( true, array( 'tree-head' => 'desc' ) ),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_customizer_switches_on' ) ) {
	/**
	 * The old switches always read as on: the part of the list decides.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_customizer_switches_on() {
		foreach ( array_keys( mvweb_theme_customizer_switches() ) as $setting ) {
			add_filter( 'theme_mod_' . $setting, '__return_true' );
		}
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_customizer_switches_on' );

if ( ! function_exists( 'mvweb_theme_customizer_switches_move' ) ) {
	/**
	 * Once: a switch that was off takes its part out of the lists.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_customizer_switches_move() {
		$mods = get_theme_mods();

		if ( ! empty( $mods['mvweb_switches'] ) ) {
			return;
		}

		foreach ( mvweb_theme_customizer_switches() as $setting => $switch ) {
			$on = array_key_exists( $setting, (array) $mods ) ? (bool) $mods[ $setting ] : $switch[0];

			if ( ! $on ) {
				foreach ( $switch[1] as $area => $part ) {
					$key   = mvweb_core_layout_setting( $area );
					$order = json_decode( isset( $mods[ $key ] ) ? (string) $mods[ $key ] : '', true );
					$order = is_array( $order ) ? $order : mvweb_core_layout_default_order( $area );

					set_theme_mod( $key, wp_json_encode( array_values( array_diff( $order, array( $part ) ) ) ) );
				}
			}

			remove_theme_mod( $setting );
		}

		set_theme_mod( 'mvweb_switches', 1 );
	}
}
add_action( 'wp_loaded', 'mvweb_theme_customizer_switches_move' );

if ( ! function_exists( 'mvweb_theme_customizer_tree' ) ) {
	/**
	 * Sections of the panels: names of a shop, new sections for the announcement,
	 * the search, the filters and the checkout, the blog section shown.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panel id => panel.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_customizer_tree( $tree ) {
		$sections = array(
			'mvweb_cz_design'     => array(
				'mvweb_cz_design_preset'  => __( 'General look', 'brand-market' ),
				'mvweb_cz_design_colors'  => __( 'Colours: light scheme', 'brand-market' ),
				'mvweb_cz_design_dark'    => null,
				'mvweb_cz_design_buttons' => null,
				'mvweb_cz_design_links'   => null,
				'mvweb_cz_design_fields'  => null,
			),
			'mvweb_cz_profile'    => array(
				'mvweb_cz_profile_contacts' => null,
				'mvweb_cz_profile_schedule' => null,
				'mvweb_cz_profile_socials'  => __( 'Social networks and channels', 'brand-market' ),
				'mvweb_cz_profile_legal'    => __( 'Company details', 'brand-market' ),
				'mvweb_cz_profile_branches' => __( 'Branches and cities', 'brand-market' ),
			),
			'mvweb_cz_header'     => array(
				'mvweb_cz_header_blocks' => null,
				'mvweb_cz_header_notice' => __( 'Announcement above the header', 'brand-market' ),
				'mvweb_cz_header_brand'  => __( 'Logo', 'brand-market' ),
				'mvweb_cz_header_drawer' => null,
			),
			'mvweb_cz_inner'      => array(
				'mvweb_cz_inner_frame'   => __( 'All pages', 'brand-market' ),
				'mvweb_cz_inner_archive' => __( 'Blog: list of articles', 'brand-market' ),
				'mvweb_cz_inner_single'  => __( 'Blog: article page', 'brand-market' ),
				'mvweb_cz_inner_search'  => __( 'Site search', 'brand-market' ),
				'mvweb_cz_inner_404'     => __( 'Page 404', 'brand-market' ),
				'mvweb_cz_inner_source'  => __( 'Blocks at the bottom of pages', 'brand-market' ),
			),
			'mvweb_cz_catalog'    => array(
				'mvweb_cz_catalog_archive' => __( 'Product list', 'brand-market' ),
				'mvweb_cz_catalog_filters' => __( 'Filters', 'brand-market' ),
				'mvweb_cz_catalog_product' => __( 'Purchase block', 'brand-market' ),
				'mvweb_cz_catalog_lists'   => null,
				'mvweb_cz_catalog_account' => null,
				'mvweb_cz_catalog_setup'   => null,
			),
			'mvweb_cz_conversion' => array(
				'mvweb_cz_conversion_cta'      => null,
				'mvweb_cz_conversion_cart'     => __( 'Cart', 'brand-market' ),
				'mvweb_cz_conversion_checkout' => __( 'Checkout and order', 'brand-market' ),
				'mvweb_cz_conversion_share'    => null,
				'mvweb_cz_codes_cookie'        => null,
			),
		);

		$titles = array();

		foreach ( $tree as $panel ) {
			$titles += (array) ( isset( $panel['sections'] ) ? $panel['sections'] : array() );
		}

		foreach ( $sections as $panel => $list ) {
			if ( ! isset( $tree[ $panel ] ) ) {
				continue;
			}

			$tree[ $panel ]['sections'] = array();

			foreach ( $list as $section => $title ) {
				if ( null === $title && ! isset( $titles[ $section ] ) ) {
					continue;
				}

				$tree[ $panel ]['sections'][ $section ] = null === $title ? $titles[ $section ] : $title;
			}
		}

		if ( isset( $tree['mvweb_cz_inner'] ) ) {
			$tree['mvweb_cz_inner']['title'] = __( 'MVweb: Pages and blog', 'brand-market' );
		}

		if ( isset( $tree['mvweb_cz_codes']['sections'] ) ) {
			unset( $tree['mvweb_cz_codes']['sections']['mvweb_cz_codes_cookie'] );
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_theme_customizer_tree', 100 );

if ( ! function_exists( 'mvweb_theme_customizer_product' ) ) {
	/**
	 * The product page in sections by task: the look, the header, the purchase, the marketplaces, the sections under the product.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panel id => panel.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_customizer_product( $tree ) {
		if ( ! isset( $tree['mvweb_cz_product']['sections']['mvweb_cz_catalog_product'] ) ) {
			return $tree;
		}

		$sections = array();

		if ( isset( $tree['mvweb_cz_product']['sections']['mvweb_cz_product_view'] ) ) {
			$sections['mvweb_cz_product_view'] = $tree['mvweb_cz_product']['sections']['mvweb_cz_product_view'];
		}

		$tree['mvweb_cz_product']['sections'] = $sections + array(
			'mvweb_cz_product_head'    => __( 'Header and photo', 'brand-market' ),
			'mvweb_cz_catalog_product' => __( 'Purchase block', 'brand-market' ),
			'mvweb_cz_product_markets' => __( 'Marketplaces', 'brand-market' ),
			'mvweb_cz_product_body'    => __( 'Description, specifications, reviews', 'brand-market' ),
			'mvweb_cz_product_more'    => __( 'Similar and bought together', 'brand-market' ),
		);

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_theme_customizer_product', 102 );

if ( ! function_exists( 'mvweb_theme_customizer_fields' ) ) {
	/**
	 * Fields of the rearranged sections, in the order the owner meets them.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string[]> Section id => control ids.
	 */
	function mvweb_theme_customizer_fields() {
		return array(
			'mvweb_cz_design_preset'       => array( 'mvweb_motion', 'mvweb_container_width', 'mvweb_radius' ),
			'mvweb_cz_modules_main'        => array( 'mvweb_module_catalog', 'mvweb_shop_mode', 'mvweb_module_services', 'mvweb_module_works', 'mvweb_module_team', 'mvweb_search_engine' ),
			'mvweb_cz_design_colors'       => array( 'mvweb_palette', 'mvweb_scheme_mode', 'mvweb_scheme_default', 'mvweb_color_accent', 'mvweb_color_accent_hover', 'mvweb_color_accent_ink', 'mvweb_color_link', 'mvweb_color_link_hover', 'mvweb_color_btn_bg', 'mvweb_color_btn_ink', 'mvweb_color_btn_hover_bg', 'mvweb_color_btn_hover_ink', 'mvweb_color_menu_bg', 'mvweb_color_menu_ink', 'mvweb_color_menu_hover', 'mvweb_color_notice_bg', 'mvweb_color_notice_ink', 'mvweb_color_footer_bg', 'mvweb_color_footer_ink', 'mvweb_color_field_bg', 'mvweb_color_field_border', 'mvweb_color_field_ink' ),
			'mvweb_cz_design_fields'       => array( 'mvweb_field_radius', 'mvweb_chip_radius', 'mvweb_badge_color_sale', 'mvweb_badge_color_hit', 'mvweb_badge_color_new', 'mvweb_badge_color_custom' ),
			'mvweb_cz_profile_contacts'    => array( 'mvweb_cz_phone', 'mvweb_cz_phone_label', 'mvweb_cz_phone_extra', 'mvweb_cz_phone_extra_label', 'mvweb_cz_email', 'mvweb_cz_city', 'mvweb_cz_address', 'mvweb_cz_map_mode', 'mvweb_cz_map', 'mvweb_cz_map_image', 'mvweb_cz_chat_telegram', 'mvweb_cz_chat_whatsapp', 'mvweb_cz_chat_viber', 'mvweb_cz_chat_max' ),
			'mvweb_cz_profile_branches'    => array( 'mvweb_branches', 'mvweb_city_default', 'mvweb_city_tip' ),
			'mvweb_cz_header_blocks'       => array( 'mvweb_header_layout', 'mvweb_header_phone_icon', 'mvweb_zone_header_topbar', 'mvweb_zone_header_main', 'mvweb_zone_header_actions', 'mvweb_zone_header_nav', 'mvweb_catalog_button', 'mvweb_catalog_button_label', 'mvweb_mega_preview_image', 'mvweb_mega_preview_caption', 'mvweb_mega_preview_url', 'mvweb_menu_icons', 'mvweb_header_messengers' ),
			'mvweb_cz_header_notice'       => array( 'mvweb_notice_text', 'mvweb_notice_link_text', 'mvweb_notice_url', 'mvweb_notice_closable' ),
			'mvweb_cz_header_brand'        => array( 'custom_logo', 'mvweb_logo_dark', 'mvweb_logo_layout', 'mvweb_logo_name', 'mvweb_logo_tagline', 'mvweb_logo_height', 'mvweb_logo_height_mobile', 'mvweb_logo_name_color', 'mvweb_logo_name_color_dark', 'mvweb_logo_tagline_color', 'mvweb_logo_tagline_color_dark' ),
			'mvweb_cz_header_drawer'       => array( 'mvweb_zone_header_drawer_contacts', 'mvweb_drawer_contacts_pos', 'mvweb_zone_header_drawer_nav', 'mvweb_zone_header_drawer_foot', 'mvweb_drawer_socials_title' ),
			'mvweb_cz_footer_blocks'       => array( 'mvweb_zone_footer_main', 'mvweb_footer_tagline', 'mvweb_footer_socials_title', 'mvweb_footer_menu_title', 'mvweb_footer_menu_2_title', 'mvweb_footer_contacts_title', 'mvweb_layout_footer_contacts', 'mvweb_footer_contacts_cta' ),
			'mvweb_cz_inner_frame'         => array( 'mvweb_layout_page_hero', 'mvweb_sidebar_side_page', 'mvweb_sidebar_side_blog', 'mvweb_sidebar_side_services', 'mvweb_sidebar_side_works' ),
			'mvweb_cz_inner_archive'       => array( 'mvweb_blog_topics_nav', 'mvweb_blog_months_nav', 'mvweb_blog_all_label', 'mvweb_blog_feature', 'mvweb_blog_feature_more', 'mvweb_layout_card_post', 'mvweb_blog_hero_parts', 'mvweb_layout_author_head' ),
			'mvweb_cz_inner_single'        => array( 'mvweb_layout_post_meta', 'mvweb_layout_post_head', 'mvweb_toc', 'mvweb_toc_title', 'mvweb_toc_position', 'mvweb_layout_post_after', 'mvweb_layout_author_box', 'mvweb_layout_post_below', 'mvweb_post_related_title', 'mvweb_post_related_link', 'mvweb_post_related_count', 'mvweb_comment_consent' ),
			'mvweb_cz_inner_search'        => array( 'mvweb_search_placeholder', 'mvweb_layout_search_groups', 'mvweb_layout_search_empty', 'mvweb_search_popular', 'mvweb_search_hits_title', 'mvweb_search_hits_count' ),
			'mvweb_cz_inner_404'           => array( 'mvweb_layout_notfound', 'mvweb_404_title', 'mvweb_404_text' ),
			'mvweb_cz_catalog_archive'     => array( 'mvweb_wholesale', 'mvweb_wholesale_label', 'mvweb_catalog_view', 'mvweb_catalog_columns', 'mvweb_sidebar_side_catalog', 'mvweb_layout_catalog_toolbar', 'mvweb_catalog_orderings', 'mvweb_layout_listing_head', 'mvweb_listing_chips', 'mvweb_catalog_subcats', 'mvweb_layout_listing_below', 'mvweb_layout_card_product', 'mvweb_card_buy', 'mvweb_badge_new_days', 'mvweb_badge_hit', 'mvweb_badge_new', 'mvweb_stock_show_qty', 'mvweb_price_label', 'mvweb_second_price', 'mvweb_second_price_label', 'mvweb_price_empty', 'mvweb_price_request_out', 'mvweb_placeholder_image' ),
			'mvweb_cz_product_view'        => array( 'mvweb_product_view', 'mvweb_product_main_specs' ),
			'mvweb_cz_product_head'        => array( 'mvweb_product_back', 'mvweb_layout_product_header', 'mvweb_stock_note', 'mvweb_layout_product_media' ),
			'mvweb_cz_catalog_product'     => array( 'mvweb_layout_product_summary', 'mvweb_layout_product_purchase', 'mvweb_one_click', 'mvweb_product_delivery', 'mvweb_product_promo', 'mvweb_switch_property', 'mvweb_product_benefits_title', 'mvweb_product_benefits', 'mvweb_product_file_label' ),
			'mvweb_cz_product_markets'     => array( 'mvweb_markets', 'mvweb_markets_title' ),
			'mvweb_cz_product_body'        => array( 'mvweb_layout_product_sections', 'mvweb_product_nav', 'mvweb_product_help_title', 'mvweb_product_help_text', 'mvweb_product_help_button', 'mvweb_product_specs_title', 'mvweb_product_note', 'mvweb_product_reviews_title', 'mvweb_reviews_count' ),
			'mvweb_cz_product_more'        => array( 'mvweb_product_upsells_title', 'mvweb_upsells_count', 'mvweb_related_title', 'mvweb_related_count' ),
			'mvweb_cz_catalog_filters'     => array( 'mvweb_filter_price', 'mvweb_filter_subcategories', 'mvweb_filter_visible', 'mvweb_filter_open' ),
			'mvweb_cz_catalog_lists'       => array( 'mvweb_favorites_page', 'mvweb_compare_page', 'mvweb_compare_max', 'mvweb_layout_favorites', 'mvweb_layout_compare_bar', 'mvweb_layout_compare_rows' ),
			'mvweb_cz_conversion_cta'      => array( 'mvweb_cta_text', 'mvweb_cta_url', 'mvweb_popup_form', 'mvweb_popup_title', 'mvweb_popup_text', 'mvweb_popup_ok_title', 'mvweb_popup_ok_text', 'mvweb_popup_error_title', 'mvweb_popup_error_text' ),
			'mvweb_cz_conversion_cart'     => array( 'mvweb_cart_add_action', 'mvweb_layout_side_cart', 'mvweb_minicart_ship_text', 'mvweb_free_shipping_min', 'mvweb_layout_cart_hero', 'mvweb_cart_ship_text', 'mvweb_layout_cart_page', 'mvweb_layout_cart_line', 'mvweb_layout_cart_tools', 'mvweb_layout_cart_aside', 'mvweb_cart_notes', 'mvweb_cart_cross_title', 'mvweb_cart_cross_count', 'mvweb_cart_empty_text' ),
			'mvweb_cz_conversion_checkout' => array( 'mvweb_layout_checkout_hero', 'mvweb_shipping_hints', 'mvweb_layout_thanks_page', 'mvweb_thanks_lead', 'mvweb_thanks_steps', 'mvweb_layout_pay_fail', 'mvweb_pay_fail_reasons' ),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_customizer_texts' ) ) {
	/**
	 * Names in the words of a shop: control id => label, or label and description.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string|string[]>
	 */
	function mvweb_theme_customizer_texts() {
		return array(
			'mvweb_radius'                => array( __( 'Corners of the site', 'brand-market' ), __( 'Cards, windows and pictures, and the buttons, fields and badges left at “As the site”.', 'brand-market' ) ),
			'mvweb_layout_page_hero'      => array( __( 'Top of the page', 'brand-market' ), __( 'Breadcrumbs, the heading and the text under it on every inner page.', 'brand-market' ) ),
			'mvweb_sidebar_side_page'     => array( __( 'Widget column on ordinary pages', 'brand-market' ), __( 'The widgets of the columns are added in Appearance → Widgets. The column of the catalogue is set in Catalogue → Product list.', 'brand-market' ) ),
			'mvweb_sidebar_side_blog'     => __( 'Widget column in the blog and articles', 'brand-market' ),
			'mvweb_sidebar_side_services' => __( 'Widget column in the services', 'brand-market' ),
			'mvweb_sidebar_side_works'    => __( 'Widget column in the portfolio', 'brand-market' ),
			'mvweb_blog_topics_nav'       => __( 'Row of categories above the articles', 'brand-market' ),
			'mvweb_blog_months_nav'       => __( 'Row of months above the articles', 'brand-market' ),
			'mvweb_blog_all_label'        => __( 'First button in the row of categories', 'brand-market' ),
			'mvweb_blog_feature'          => __( 'First article large', 'brand-market' ),
			'mvweb_blog_feature_more'     => __( 'Link text of the large article', 'brand-market' ),
			'mvweb_layout_card_post'      => __( 'Article card', 'brand-market' ),
			'mvweb_blog_hero_parts'       => __( 'Heading of categories, tags and archives by date', 'brand-market' ),
			'mvweb_layout_author_head'    => __( 'Heading of the author page', 'brand-market' ),
			'mvweb_layout_post_meta'      => __( 'Line above the heading', 'brand-market' ),
			'mvweb_layout_post_head'      => __( 'Under the heading', 'brand-market' ),
			'mvweb_toc'                   => __( 'Table of contents', 'brand-market' ),
			'mvweb_toc_title'             => __( 'Heading of the table of contents', 'brand-market' ),
			'mvweb_toc_position'          => __( 'Where the table of contents stands', 'brand-market' ),
			'mvweb_layout_post_after'     => __( 'Under the text of the article', 'brand-market' ),
			'mvweb_layout_post_below'     => __( 'At the bottom of the page', 'brand-market' ),
			'mvweb_post_related_title'    => __( 'Heading of “More articles”', 'brand-market' ),
			'mvweb_post_related_link'     => __( 'Text of the link to the whole blog', 'brand-market' ),
			'mvweb_post_related_count'    => __( 'How many articles to show', 'brand-market' ),
			'mvweb_layout_search_groups'  => __( 'Order of the groups in the results', 'brand-market' ),
			'mvweb_layout_search_empty'   => __( 'When nothing is found', 'brand-market' ),
			'mvweb_search_hits_title'     => __( 'Heading of the products shown when nothing is found', 'brand-market' ),
			'mvweb_search_hits_count'     => __( 'How many of those products', 'brand-market' ),
			'mvweb_layout_notfound'       => __( 'What the 404 page shows', 'brand-market' ),
			'mvweb_404_title'             => __( 'Heading', 'brand-market' ),
			'mvweb_404_text'              => __( 'Text', 'brand-market' ),
			'mvweb_cz_social_telegram'    => __( 'Telegram channel', 'brand-market' ),
			'mvweb_cz_social_whatsapp'    => __( 'WhatsApp channel', 'brand-market' ),
			'mvweb_cz_social_viber'       => __( 'Viber channel', 'brand-market' ),
			'mvweb_cz_social_max'         => __( 'MAX channel', 'brand-market' ),
			'mvweb_cz_map_mode'           => array( __( 'Map', 'brand-market' ), __( 'On the contacts page and in the “Branches” block. In the footer, when “Footer → Show the map” is on.', 'brand-market' ) ),
			'mvweb_zone_footer_main'      => __( 'Footer columns', 'brand-market' ),
			'mvweb_zone_footer_bottom'    => __( 'Bottom line', 'brand-market' ),
			'mvweb_badge_new_days'        => __( 'How many days a product counts as new', 'brand-market' ),
			'mvweb_badge_hit'             => __( 'Badge of a recommended product', 'brand-market' ),
			'mvweb_badge_new'             => __( 'Badge of a new product', 'brand-market' ),
			'mvweb_placeholder_image'     => __( 'Picture for a product without its own', 'brand-market' ),
			'mvweb_sidebar_side_catalog'  => array( __( 'Sidebar of the shop and the catalogue', 'brand-market' ), __( 'Filters and widgets beside the list of products. The widgets are placed in Appearance - Widgets; without widgets or with “Do not show” the list takes the whole width, the filters disappear on phones too.', 'brand-market' ) ),
			'mvweb_source_product'        => __( 'Product page', 'brand-market' ),
			'mvweb_markup_catalog'        => __( 'Products and services', 'brand-market' ),
			'mvweb_product_view'          => array( __( 'Price and purchase block', 'brand-market' ), __( 'How the price, the quantity and the buttons stand next to the photo. The parts and their order are set in “Purchase block”.', 'brand-market' ) ),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_customizer_arrange' ) ) {
	/**
	 * Move the fields into their sections and order, rename them, drop the duplicate switches.
	 *
	 * A field the list does not name keeps its place before the field it stood before.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer manager.
	 *
	 * @return void
	 */
	function mvweb_theme_customizer_arrange( $wp_customize ) {
		foreach ( array_keys( mvweb_theme_customizer_switches() ) as $setting ) {
			$wp_customize->remove_control( $setting );
		}

		foreach ( mvweb_theme_customizer_texts() as $id => $text ) {
			$control = $wp_customize->get_control( $id );

			if ( $control ) {
				$control->label = is_array( $text ) ? $text[0] : $text;

				if ( is_array( $text ) ) {
					$control->description = $text[1];
				}
			}
		}

		$controls = $wp_customize->controls();

		uasort(
			$controls,
			static function ( $a, $b ) {
				return $a->priority === $b->priority ? $a->instance_number - $b->instance_number : $a->priority - $b->priority;
			}
		);

		foreach ( mvweb_theme_customizer_fields() as $section => $ids ) {
			$order = array();

			foreach ( $ids as $id ) {
				$control = $wp_customize->get_control( $id );

				if ( $control ) {
					$control->section = $section;
					$order[]          = $id;
				}
			}

			$rest = array();

			foreach ( $controls as $id => $control ) {
				if ( $section === $control->section && ! in_array( $id, $order, true ) ) {
					$rest[] = $id;
				}
			}

			foreach ( $rest as $id ) {
				$next = null;
				$seen = false;

				foreach ( $controls as $other => $control ) {
					if ( $seen && $section === $control->section && in_array( $other, $order, true ) ) {
						$next = $other;
						break;
					}

					$seen = $seen || $other === $id;
				}

				$at = null === $next ? count( $order ) : array_search( $next, $order, true );
				array_splice( $order, $at, 0, array( $id ) );
			}

			foreach ( $order as $index => $id ) {
				$wp_customize->get_control( $id )->priority = $index + 1;
			}
		}
	}
}
add_action( 'customize_register', 'mvweb_theme_customizer_arrange', 30 );

if ( ! function_exists( 'mvweb_theme_customizer_rules' ) ) {
	/**
	 * Fields that work only with another one on show only then.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_customizer_rules() {
		$filled = static function ( $setting ) {
			return array(
				array(
					'setting'  => $setting,
					'operator' => '!=',
					'value'    => '',
				),
			);
		};

		$on = static function ( $setting ) {
			return array(
				array(
					'setting'  => $setting,
					'operator' => '==',
					'value'    => true,
				),
			);
		};

		$rules = array(
			'mvweb_notice_link_text'     => $filled( 'mvweb_notice_text' ),
			'mvweb_notice_url'           => $filled( 'mvweb_notice_text' ),
			'mvweb_notice_closable'      => $filled( 'mvweb_notice_text' ),
			'mvweb_catalog_button_label' => $on( 'mvweb_catalog_button' ),
			'mvweb_mega_preview_image'   => $on( 'mvweb_catalog_button' ),
			'mvweb_mega_preview_caption' => $on( 'mvweb_catalog_button' ),
			'mvweb_mega_preview_url'     => $on( 'mvweb_catalog_button' ),
			'mvweb_toc_title'            => $on( 'mvweb_toc' ),
			'mvweb_toc_position'         => $on( 'mvweb_toc' ),
			'mvweb_popup_title'          => $filled( 'mvweb_popup_form' ),
			'mvweb_popup_text'           => $filled( 'mvweb_popup_form' ),
			'mvweb_popup_ok_title'       => $filled( 'mvweb_popup_form' ),
			'mvweb_popup_ok_text'        => $filled( 'mvweb_popup_form' ),
			'mvweb_popup_error_title'    => $filled( 'mvweb_popup_form' ),
			'mvweb_popup_error_text'     => $filled( 'mvweb_popup_form' ),
		);

		wp_add_inline_script( 'mvweb-cz-controls', 'window.mvwebCZ && Object.assign( window.mvwebCZ.dependencies, ' . wp_json_encode( $rules ) . ' );', 'before' );
	}
}
add_action( 'customize_controls_enqueue_scripts', 'mvweb_theme_customizer_rules', 20 );

if ( ! function_exists( 'mvweb_theme_top_menu_name' ) ) {
	/**
	 * One name for the menu of the strip above the header.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_top_menu_name() {
		register_nav_menus( array( 'top' => __( 'Top menu', 'brand-market' ) ) );
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_top_menu_name', 20 );
