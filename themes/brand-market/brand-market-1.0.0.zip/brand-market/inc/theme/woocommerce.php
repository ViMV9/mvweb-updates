<?php
/**
 * WooCommerce as the theme draws it. Loaded only with WooCommerce.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_woocommerce_body_class' ) ) {
	/**
	 * Tell WooCommerce the theme styles its buttons.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $classes Body classes.
	 *
	 * @return string[]
	 */
	function mvweb_theme_woocommerce_body_class( $classes ) {
		$classes[] = 'woocommerce-block-theme-has-button-styles';

		return $classes;
	}
}
add_filter( 'body_class', 'mvweb_theme_woocommerce_body_class' );

if ( ! function_exists( 'mvweb_theme_woocommerce_unhook' ) ) {
	/**
	 * Take the default loop output off its hooks.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_woocommerce_unhook() {
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50 );

		remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
		remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
		remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_woocommerce_unhook' );

if ( ! function_exists( 'mvweb_theme_sale_flash' ) ) {
	/**
	 * Re-dress the sale marker in the card's own class.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_theme_sale_flash() {
		return '<span class="mvweb-t-product__badge">' . esc_html__( 'Sale', 'brand-market' ) . '</span>';
	}
}
add_filter( 'woocommerce_sale_flash', 'mvweb_theme_sale_flash' );

if ( ! function_exists( 'mvweb_theme_wc_price_html' ) ) {
	/**
	 * Wrap a price in the span the layout keeps on one line.
	 *
	 * @since 0.1.0
	 *
	 * @param string $html Price markup.
	 *
	 * @return string
	 */
	function mvweb_theme_wc_price_html( $html ) {
		if ( '' === trim( (string) $html ) ) {
			return $html;
		}

		return '<span class="mvweb-t-product__amount">' . $html . '</span>';
	}
}
add_filter( 'woocommerce_get_price_html', 'mvweb_theme_wc_price_html' );
