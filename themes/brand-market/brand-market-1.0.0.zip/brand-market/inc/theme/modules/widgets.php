<?php
/**
 * Columns with widgets: the wrapper beside the content of a page.
 *
 * The areas and the widgets are the core's. Here the theme decides where the
 * column stands and what encloses it. An area with nothing to print prints
 * nothing at all and the page keeps the whole width.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter( 'use_widgets_block_editor', '__return_false' );
add_filter( 'gutenberg_use_widgets_block_editor', '__return_false' );

if ( ! function_exists( 'mvweb_theme_widget_classes' ) ) {
	/**
	 * Give the roles of the widgets the classes of the theme.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $classes Role => classes.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_widget_classes( $classes ) {
		return array_merge(
			(array) $classes,
			array(
				'widget' => 'mvweb-t-widget',
				'title'  => 'mvweb-t-widget__title mvweb-t-h2',
				'count'  => 'mvweb-t-widget__count',
				'chip'   => 'mvweb-t-chip',
				'list'   => 'mvweb-t-widget__list',
				'name'   => 'mvweb-t-widget__name',
				'filter' => 'mvweb-t-widget--filter',
				'help'   => 'mvweb-t-widget--help',
			)
		);
	}
}
add_filter( 'mvweb_core_widget_classes', 'mvweb_theme_widget_classes' );

if ( ! function_exists( 'mvweb_theme_sidebar_html' ) ) {
	/**
	 * Markup of the widgets of an area, printed once per request.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area key.
	 *
	 * @return string Empty when the area has no widget or none of them prints anything.
	 */
	function mvweb_theme_sidebar_html( $area ) {
		static $html = array();

		if ( isset( $html[ $area ] ) ) {
			return $html[ $area ];
		}

		$html[ $area ] = '';

		if ( 'none' !== mvweb_core_sidebar_side( $area ) && is_active_sidebar( mvweb_core_sidebar_id( $area ) ) ) {
			ob_start();
			dynamic_sidebar( mvweb_core_sidebar_id( $area ) );
			$html[ $area ] = trim( (string) ob_get_clean() );
		}

		return $html[ $area ];
	}
}

if ( ! function_exists( 'mvweb_theme_sidebar_on' ) ) {
	/**
	 * Whether the column of an area has something to print and the request belongs to the area.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area key.
	 *
	 * @return bool
	 */
	function mvweb_theme_sidebar_on( $area ) {
		return mvweb_core_sidebar_area() === $area && '' !== mvweb_theme_sidebar_html( $area );
	}
}

if ( ! function_exists( 'mvweb_theme_sidebar_side_class' ) ) {
	/**
	 * Modifier of a layout for the side its column stands on.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area key.
	 * @param string $base Class of the layout.
	 *
	 * @return string A class with a leading space.
	 */
	function mvweb_theme_sidebar_side_class( $area, $base ) {
		return ' ' . $base . '--' . mvweb_core_sidebar_side( $area );
	}
}

if ( ! function_exists( 'mvweb_theme_column_open' ) ) {
	/**
	 * Open the two columns of a page above its head: the breadcrumbs go over
	 * both, the column of widgets starts beside the heading.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area key.
	 *
	 * @return void
	 */
	function mvweb_theme_column_open( $area ) {
		if ( ! mvweb_theme_sidebar_on( $area ) ) {
			return;
		}

		get_template_part( 'template-parts/crumbs', null, array( 'wrap' => true ) );

		printf(
			'<div class="mvweb-t-container mvweb-t-page-layout%s"><div class="mvweb-t-page-layout__main">',
			esc_attr( mvweb_theme_sidebar_side_class( $area, 'mvweb-t-page-layout' ) )
		);
	}
}

if ( ! function_exists( 'mvweb_theme_column_close' ) ) {
	/**
	 * Close the content and print the column of widgets beside it.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area key.
	 *
	 * @return void
	 */
	function mvweb_theme_column_close( $area ) {
		if ( ! mvweb_theme_sidebar_on( $area ) ) {
			return;
		}

		echo '</div>';
		get_template_part(
			'template-parts/sidebar',
			null,
			array(
				'area'  => $area,
				'class' => 'mvweb-t-page-layout__aside',
			)
		);
		echo '</div>';
	}
}
