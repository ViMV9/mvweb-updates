<?php
/**
 * The cart, the checkout, the order received page and the side cart as the theme draws them.
 *
 * WooCommerce prints these pages from its own templates; this module takes the
 * default output off its hooks, hands the cart and the checkout a page template
 * with a heading of their own and dresses the fields of the forms in the
 * classes of the theme. Loaded only with WooCommerce.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WooCommerce' ) ) {
	return;
}

if ( ! function_exists( 'mvweb_theme_cart_unhook' ) ) {
	/**
	 * Take the default output of the cart and the checkout off its hooks.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_cart_unhook() {
		remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
		remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cart_totals', 10 );
		remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_login_form', 10 );
		remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10 );
		remove_action( 'woocommerce_checkout_order_review', 'woocommerce_checkout_payment', 20 );
		remove_action( 'woocommerce_thankyou', 'woocommerce_order_details_table', 10 );
		remove_action( 'woocommerce_cart_is_empty', 'wc_empty_cart_message', 10 );

		if ( WC()->checkout() ) {
			remove_action( 'woocommerce_checkout_billing', array( WC()->checkout(), 'checkout_form_billing' ) );
			remove_action( 'woocommerce_checkout_shipping', array( WC()->checkout(), 'checkout_form_shipping' ) );
		}
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_cart_unhook', 20 );

if ( ! function_exists( 'mvweb_theme_order_page_here' ) ) {
	/**
	 * Whether this request is a page of the cart or of the checkout.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_theme_order_page_here() {
		return is_cart() || is_checkout();
	}
}

if ( ! function_exists( 'mvweb_theme_shop_page_here' ) ) {
	/**
	 * Whether this request is a page of the cart, of the checkout or of the account.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_theme_shop_page_here() {
		return mvweb_theme_order_page_here() || mvweb_theme_account_on();
	}
}

if ( ! function_exists( 'mvweb_theme_cart_wc_styles' ) ) {
	/**
	 * Leave the stylesheets of WooCommerce off the pages the theme styles itself.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $styles Styles WooCommerce would enqueue.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_cart_wc_styles( $styles ) {
		return mvweb_theme_shop_page_here() ? array() : $styles;
	}
}
add_filter( 'woocommerce_enqueue_styles', 'mvweb_theme_cart_wc_styles' );

if ( ! function_exists( 'mvweb_theme_cart_plain_selects' ) ) {
	/**
	 * Keep the country and the region as plain selects, in the field classes of the theme.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_cart_plain_selects() {
		if ( mvweb_theme_shop_page_here() ) {
			wp_dequeue_script( 'selectWoo' );
			wp_dequeue_style( 'select2' );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_theme_cart_plain_selects', 100 );

if ( ! function_exists( 'mvweb_theme_cart_template' ) ) {
	/**
	 * Give the cart, the checkout and the account the template that draws their heading.
	 *
	 * @since 0.1.0
	 *
	 * @param string $template Template WordPress has chosen.
	 *
	 * @return string
	 */
	function mvweb_theme_cart_template( $template ) {
		if ( ! is_page() ) {
			return $template;
		}

		if ( mvweb_theme_account_on() ) {
			$own = locate_template( 'woocommerce/account-page.php' );
		} elseif ( mvweb_theme_order_page_here() ) {
			$own = locate_template( 'woocommerce/page-order.php' );
		} else {
			return $template;
		}

		return '' === $own ? $template : $own;
	}
}
add_filter( 'template_include', 'mvweb_theme_cart_template', 99 );

if ( ! function_exists( 'mvweb_theme_cart_crumbs' ) ) {
	/**
	 * The trail of the cart and of the checkout: the catalogue leads to the cart, the cart to the checkout.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $items Trail items.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_theme_cart_crumbs( $items ) {
		if ( ! mvweb_theme_order_page_here() || empty( $items ) ) {
			return $items;
		}

		$home = reset( $items );
		$cart = array(
			'label' => mvweb_theme_cart_page_title( 'cart' ),
			'url'   => wc_get_cart_url(),
		);

		if ( is_cart() ) {
			$catalog = mvweb_core_catalog_page_url();
			$trail   = array( $home );

			if ( trailingslashit( $catalog ) !== trailingslashit( home_url( '/' ) ) ) {
				$trail[] = array(
					'label' => __( 'Catalog', 'brand-market' ),
					'url'   => $catalog,
				);
			}

			$trail[] = array( 'label' => $cart['label'] );

			return $trail;
		}

		if ( is_wc_endpoint_url( 'order-received' ) ) {
			return array( $home, array( 'label' => __( 'Order received', 'brand-market' ) ) );
		}

		if ( is_wc_endpoint_url( 'order-pay' ) ) {
			return array( $home, $cart, array( 'label' => __( 'Order payment', 'brand-market' ) ) );
		}

		return array( $home, $cart, array( 'label' => mvweb_theme_cart_page_title( 'checkout' ) ) );
	}
}
add_filter( 'mvweb_core_crumb_items', 'mvweb_theme_cart_crumbs', 20 );

if ( ! function_exists( 'mvweb_theme_cart_page_title' ) ) {
	/**
	 * The title of the cart or of the checkout page.
	 *
	 * @since 0.1.0
	 *
	 * @param string $page cart or checkout.
	 *
	 * @return string
	 */
	function mvweb_theme_cart_page_title( $page ) {
		$id    = wc_get_page_id( $page );
		$title = $id > 0 ? trim( (string) get_the_title( $id ) ) : '';

		if ( '' !== $title ) {
			return $title;
		}

		return 'cart' === $page ? __( 'Cart', 'brand-market' ) : __( 'Checkout', 'brand-market' );
	}
}

if ( ! function_exists( 'mvweb_theme_cart_field_args' ) ) {
	/**
	 * Dress a field of a WooCommerce form of the cart, the checkout or the account in the classes of the theme.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $args  Arguments of the field.
	 * @param string              $key   Name of the field.
	 * @param mixed               $value Value of the field.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_theme_cart_field_args( $args, $key, $value ) {
		unset( $key, $value );

		$account = mvweb_theme_account_on();

		if ( ! $account && ! mvweb_theme_order_page_here() ) {
			return $args;
		}

		$type = isset( $args['type'] ) ? (string) $args['type'] : 'text';

		if ( in_array( $type, array( 'checkbox', 'radio', 'hidden' ), true ) ) {
			return $args;
		}

		$own     = array_map( 'strval', (array) $args['class'] );
		$classes = array( 'mvweb-t-field' );

		if ( in_array( 'form-row-wide', $own, true ) || ( $account && ! array_intersect( array( 'form-row-first', 'form-row-last' ), $own ) ) ) {
			$classes[] = 'mvweb-t-field--wide';
		}

		$args['class']       = array_values( array_unique( array_merge( $own, $classes ) ) );
		$args['label_class'] = array_values( array_unique( array_merge( (array) $args['label_class'], array( 'mvweb-t-field__label' ) ) ) );
		$args['input_class'] = array_values( array_unique( array_merge( (array) $args['input_class'], array( 'mvweb-t-field__input' ) ) ) );

		if ( $account && ! empty( $args['required'] ) ) {
			$args['custom_attributes']             = (array) $args['custom_attributes'];
			$args['custom_attributes']['required'] = 'required';
		}

		return $args;
	}
}
add_filter( 'woocommerce_form_field_args', 'mvweb_theme_cart_field_args', 20, 3 );

if ( ! function_exists( 'mvweb_theme_checkout_fields' ) ) {
	/**
	 * Put the phone beside the e-mail, pair the address fields and say what the e-mail and the note are for.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,array<string,mixed>>> $fields Fields of the checkout.
	 *
	 * @return array<string,array<string,array<string,mixed>>>
	 */
	function mvweb_theme_checkout_fields( $fields ) {
		if ( isset( $fields['billing']['billing_phone'], $fields['billing']['billing_email'] ) ) {
			$fields['billing']['billing_phone']['class'] = array( 'form-row-first' );
			$fields['billing']['billing_email']['class'] = array( 'form-row-last' );
		}

		foreach ( array( 'billing', 'shipping' ) as $group ) {
			$pairs = array(
				$group . '_address_2' => 'form-row-first',
				$group . '_city'      => 'form-row-last',
				$group . '_state'     => 'form-row-first',
				$group . '_postcode'  => 'form-row-last',
			);

			foreach ( $pairs as $key => $class ) {
				if ( isset( $fields[ $group ][ $key ] ) ) {
					$fields[ $group ][ $key ]['class'] = array( $class );
				}
			}
		}

		if ( isset( $fields['billing']['billing_email'] ) ) {
			$fields['billing']['billing_email']['placeholder'] = __( 'We will send the confirmation and the receipt', 'brand-market' );
		}

		if ( isset( $fields['order']['order_comments'] ) ) {
			$fields['order']['order_comments']['label']       = __( 'Wishes for the order', 'brand-market' );
			$fields['order']['order_comments']['placeholder'] = __( 'For example, call an hour before delivery', 'brand-market' );
		}

		return $fields;
	}
}
add_filter( 'woocommerce_checkout_fields', 'mvweb_theme_checkout_fields', 20 );

if ( ! function_exists( 'mvweb_theme_cart_positions' ) ) {
	/**
	 * How many different goods lie in the cart.
	 *
	 * @since 0.1.0
	 *
	 * @return int
	 */
	function mvweb_theme_cart_positions() {
		return WC()->cart ? count( WC()->cart->get_cart() ) : 0;
	}
}

if ( ! function_exists( 'mvweb_theme_cart_announce' ) ) {
	/**
	 * What a screen reader is told when the cart has changed.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_theme_cart_announce() {
		$count = mvweb_theme_cart_positions();

		if ( $count < 1 ) {
			return __( 'The cart is empty', 'brand-market' );
		}

		/* translators: 1: number of goods with the word, 2: sum. */
		return sprintf( __( 'In the cart: %1$s, %2$s', 'brand-market' ), mvweb_theme_cart_count_label( $count ), html_entity_decode( wp_strip_all_tags( (string) WC()->cart->get_cart_subtotal() ), ENT_QUOTES, 'UTF-8' ) );
	}
}

if ( ! function_exists( 'mvweb_theme_cart_count_label' ) ) {
	/**
	 * The number of goods in the cart as a phrase.
	 *
	 * @since 0.1.0
	 *
	 * @param int $count Number of pieces.
	 *
	 * @return string
	 */
	function mvweb_theme_cart_count_label( $count ) {
		/* translators: %s: number of items in the cart. */
		return sprintf( _n( '%s item', '%s items', (int) $count, 'brand-market' ), number_format_i18n( (int) $count ) );
	}
}

if ( ! function_exists( 'mvweb_theme_cart_hero_meta' ) ) {
	/**
	 * The facts under the heading of the cart, in the order of the composition.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_theme_cart_hero_meta() {
		if ( ! WC()->cart ) {
			return array();
		}

		$facts = array();

		foreach ( mvweb_core_layout_order( 'cart.hero' ) as $slug ) {
			$text = 'count' === $slug
				? mvweb_theme_cart_count_label( mvweb_theme_cart_positions() )
				: ( 'shipping' === $slug ? mvweb_core_cart_ship_text( 'mvweb_cart_ship_text' ) : '' );

			if ( '' !== $text ) {
				$facts[] = $text;
			}
		}

		return $facts;
	}
}

if ( ! function_exists( 'mvweb_theme_layout_html' ) ) {
	/**
	 * The parts of a composition area as markup, empty when none of them printed anything.
	 *
	 * @since 0.1.0
	 *
	 * @param string              $area Area name.
	 * @param array<string,mixed> $args Arguments passed to every part.
	 *
	 * @return string
	 */
	function mvweb_theme_layout_html( $area, array $args = array() ) {
		ob_start();
		mvweb_core_render_layout( $area, $args );

		return trim( (string) ob_get_clean() );
	}
}

if ( ! function_exists( 'mvweb_theme_order_hero' ) ) {
	/**
	 * The heading strip of the cart and of the checkout.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_order_hero() {
		if ( ! WC()->cart || is_wc_endpoint_url( 'order-received' ) || is_wc_endpoint_url( 'order-pay' ) ) {
			return;
		}

		$title = mvweb_core_alt_h1();
		$title = '' === $title ? get_the_title() : $title;
		$args  = array( 'title' => $title );

		if ( is_cart() ) {
			$args['meta'] = WC()->cart->is_empty() ? array() : mvweb_theme_cart_hero_meta();
		} else {
			$meta = mvweb_theme_layout_html( 'checkout.hero' );

			$args['after'] = '' === $meta ? '' : '<p class="mvweb-t-page-hero__meta">' . $meta . '</p>';
		}

		get_template_part( 'template-parts/page-hero', null, $args );
	}
}

if ( ! function_exists( 'mvweb_theme_status_hero' ) ) {
	/**
	 * The heading strip of the order received page and of the payment page.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $args Arguments.
	 *
	 * @return void
	 */
	function mvweb_theme_status_hero( array $args ) {
		$state = isset( $args['state'] ) && 'fail' === $args['state'] ? 'fail' : 'ok';
		$title = isset( $args['title'] ) ? (string) $args['title'] : '';
		$lead  = isset( $args['lead'] ) ? trim( (string) $args['lead'] ) : '';
		$icon  = 'fail' === $state ? 'alert-circle' : 'check';
		?>
		<section class="mvweb-t-page-hero mvweb-t-thanks__hero">
			<div class="mvweb-t-container">
				<?php if ( mvweb_core_layout_has( 'page-hero', 'crumbs' ) ) : ?>
					<?php get_template_part( 'template-parts/crumbs' ); ?>
				<?php endif; ?>
				<span class="mvweb-t-thanks__mark mvweb-t-thanks__mark--<?php echo esc_attr( $state ); ?>"><?php echo mvweb_theme_icon( $icon ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
				<h1 class="mvweb-t-page-hero__title"><?php echo esc_html( $title ); ?></h1>
				<?php if ( '' !== $lead ) : ?>
					<p class="mvweb-t-page-hero__lead"><?php echo esc_html( $lead ); ?></p>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_address_keys' ) ) {
	/**
	 * The billing fields that make up an address, the rest are contacts.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_theme_address_keys() {
		return array( 'billing_country', 'billing_address_1', 'billing_address_2', 'billing_city', 'billing_state', 'billing_postcode' );
	}
}

if ( ! function_exists( 'mvweb_theme_pay_fail_lead' ) ) {
	/**
	 * The text under the heading of a payment that did not go through.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Order $order Order.
	 *
	 * @return string
	 */
	function mvweb_theme_pay_fail_lead( $order ) {
		/* translators: %s: number of the order. */
		$lead = sprintf( __( 'Order No. %s is created, but the payment did not complete. The money was not taken.', 'brand-market' ), $order->get_order_number() );
		$hold = 'yes' === get_option( 'woocommerce_manage_stock' ) ? absint( get_option( 'woocommerce_hold_stock_minutes' ) ) : 0;

		if ( $hold > 0 ) {
			/* translators: %s: how long the goods are held, like "24 hours". */
			$lead .= ' ' . sprintf( __( 'The goods are held for you for %s.', 'brand-market' ), human_time_diff( 0, $hold * MINUTE_IN_SECONDS ) );
		}

		return $lead;
	}
}

if ( ! function_exists( 'mvweb_theme_order_payment_line' ) ) {
	/**
	 * How the order is paid and whether the money has come.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Order $order Order.
	 *
	 * @return string Empty for an order that needs no payment.
	 */
	function mvweb_theme_order_payment_line( $order ) {
		$title = trim( wp_strip_all_tags( (string) $order->get_payment_method_title() ) );

		if ( '' === $title ) {
			return '';
		}

		if ( $order->get_date_paid() ) {
			return $title . ', ' . __( 'paid', 'brand-market' );
		}

		if ( $order->has_status( array( 'on-hold', 'pending' ) ) ) {
			return $title . ', ' . __( 'waiting for the payment', 'brand-market' );
		}

		return $title;
	}
}

if ( ! function_exists( 'mvweb_theme_shipping_rates' ) ) {
	/**
	 * The delivery methods the customer can choose from, for every package of the cart.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>> Each package: index, chosen (rate id), rates (id, method, label, cost, taxed).
	 */
	function mvweb_theme_shipping_rates() {
		$packages = WC()->shipping() ? WC()->shipping()->get_packages() : array();
		$chosen   = (array) WC()->session->get( 'chosen_shipping_methods', array() );
		$result   = array();

		foreach ( $packages as $index => $package ) {
			if ( empty( $package['rates'] ) ) {
				continue;
			}

			$rates = array();

			foreach ( $package['rates'] as $rate ) {
				$rates[] = array(
					'id'     => $rate->get_id(),
					'method' => $rate->get_method_id(),
					'label'  => $rate->get_label(),
					'cost'   => (float) $rate->get_cost() + ( WC()->cart->display_prices_including_tax() ? array_sum( $rate->get_taxes() ) : 0 ),
					'rate'   => $rate,
				);
			}

			$result[] = array(
				'index'  => (int) $index,
				'chosen' => isset( $chosen[ $index ] ) ? (string) $chosen[ $index ] : '',
				'rates'  => $rates,
			);
		}

		return $result;
	}
}

if ( ! function_exists( 'mvweb_theme_shipping_choices_html' ) ) {
	/**
	 * The delivery methods of the step of the checkout.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_theme_shipping_choices_html() {
		ob_start();
		get_template_part( 'template-parts/checkout/shipping-choices' );

		return trim( (string) ob_get_clean() );
	}
}

if ( ! function_exists( 'mvweb_theme_shipping_choices_fragment' ) ) {
	/**
	 * Refresh the delivery methods together with the order review.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $fragments Selector => markup.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_shipping_choices_fragment( $fragments ) {
		$fragments['.mvweb-t-shipping-choices'] = mvweb_theme_shipping_choices_html();

		return $fragments;
	}
}
add_filter( 'woocommerce_update_order_review_fragments', 'mvweb_theme_shipping_choices_fragment' );

if ( ! function_exists( 'mvweb_theme_cart_body_class' ) ) {
	/**
	 * Mark the pages of the order flow for the stylesheet.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $classes Body classes.
	 *
	 * @return string[]
	 */
	function mvweb_theme_cart_body_class( $classes ) {
		if ( mvweb_theme_order_page_here() ) {
			$classes[] = 'mvweb-t-order-page';
		}

		return $classes;
	}
}
add_filter( 'body_class', 'mvweb_theme_cart_body_class' );
