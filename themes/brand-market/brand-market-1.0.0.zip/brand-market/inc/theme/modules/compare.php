<?php
/**
 * The comparison in the theme: the button, a row of the table and the place of the header icon.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_compare_button' ) ) {
	/**
	 * The button that puts an item into the comparison and takes it out.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $id      Item id.
	 * @param string $classes Classes of the button.
	 *
	 * @return string Markup, empty while the comparison is off.
	 */
	function mvweb_theme_compare_button( $id, $classes = 'mvweb-t-round mvweb-t-round--line' ) {
		$id = absint( $id );

		if ( 0 === $id || ! mvweb_core_compare_enabled() ) {
			return '';
		}

		$text = __( 'Add to comparison', 'brand-market' );

		return '<button class="' . esc_attr( $classes ) . '" type="button" data-compare-toggle="' . $id . '" data-compare-cat="' . (int) mvweb_core_compare_category( $id ) . '" aria-pressed="false" title="' . esc_attr( $text ) . '">'
			. mvweb_theme_icon( 'arrows-left-right' )
			. '<span class="screen-reader-text" data-compare-label>' . esc_html( $text ) . '</span>'
			. '</button>';
	}
}

if ( ! function_exists( 'mvweb_theme_compare_row' ) ) {
	/**
	 * Print a row of the comparison table.
	 *
	 * @since 0.1.0
	 *
	 * @param string            $label Text of the row head.
	 * @param int[]             $ids   Items in the order of the columns.
	 * @param array<int,string> $cells Ready markup of the cell by item id.
	 *
	 * @return void
	 */
	function mvweb_theme_compare_row( $label, array $ids, array $cells ) {
		$values = array();
		$filled = false;

		foreach ( $ids as $id ) {
			$values[ $id ] = isset( $cells[ $id ] ) ? trim( (string) $cells[ $id ] ) : '';
			$filled        = $filled || '' !== trim( wp_strip_all_tags( $values[ $id ] ) );
		}

		if ( ! $filled ) {
			return;
		}

		echo '<tr' . ( mvweb_core_compare_same( $values ) ? ' data-same' : '' ) . '><th scope="row">' . esc_html( $label ) . '</th>';

		foreach ( $values as $value ) {
			if ( '' === trim( wp_strip_all_tags( $value ) ) ) {
				echo '<td><span aria-hidden="true">&mdash;</span><span class="screen-reader-text">' . esc_html__( 'No data', 'brand-market' ) . '</span></td>';
			} else {
				echo '<td>' . wp_kses_post( $value ) . '</td>';
			}
		}

		echo '</tr>';
	}
}

if ( ! function_exists( 'mvweb_theme_compare_default_order' ) ) {
	/**
	 * Put the comparison icon before the favourites in the header.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $order Element slugs.
	 * @param string   $zone  Zone slug.
	 *
	 * @return string[]
	 */
	function mvweb_theme_compare_default_order( $order, $zone ) {
		if ( ! in_array( $zone, array( 'header-actions', 'header-nav' ), true ) || in_array( 'compare', $order, true ) ) {
			return $order;
		}

		$at = array_search( 'favorites', $order, true );

		if ( false === $at ) {
			return $order;
		}

		array_splice( $order, $at, 0, 'compare' );

		return $order;
	}
}
add_filter( 'mvweb_core_zone_default_order', 'mvweb_theme_compare_default_order', 20, 2 );
