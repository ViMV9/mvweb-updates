<?php
/**
 * The account of a customer as the theme draws it. Loaded only with WooCommerce.
 *
 * WooCommerce keeps the pages and the forms; this file takes over what they
 * print around them: the template of the page with its own head and breadcrumbs,
 * the navigation, the labels, the look of the fields and of the notices, and the
 * two fields the registration form of the design adds.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WooCommerce' ) ) {
	return;
}

if ( ! function_exists( 'mvweb_theme_account_on' ) ) {
	/**
	 * Whether the request is a page of the account that the theme draws itself.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_theme_account_on() {
		return mvweb_core_account_active();
	}
}

if ( ! function_exists( 'mvweb_theme_account_endpoint' ) ) {
	/**
	 * The endpoint of the account being shown.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty on the dashboard and on the page of sign in.
	 */
	function mvweb_theme_account_endpoint() {
		return WC()->query ? (string) WC()->query->get_current_endpoint() : '';
	}
}

if ( ! function_exists( 'mvweb_theme_account_unhook' ) ) {
	/**
	 * Take the defaults of WooCommerce off the hooks the design replaces.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_account_unhook() {
		remove_action( 'woocommerce_before_customer_login_form', 'woocommerce_output_all_notices', 10 );
		remove_action( 'woocommerce_before_lost_password_form', 'woocommerce_output_all_notices', 10 );
		remove_action( 'woocommerce_before_reset_password_form', 'woocommerce_output_all_notices', 10 );
		remove_action( 'woocommerce_view_order', 'woocommerce_order_details_table', 10 );
		remove_action( 'woocommerce_register_form', 'wc_registration_privacy_policy_text', 20 );
	}
}
add_action( 'wp', 'mvweb_theme_account_unhook' );

if ( ! function_exists( 'mvweb_theme_account_labels' ) ) {
	/**
	 * The names of the sections of the account.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Endpoint => label.
	 */
	function mvweb_theme_account_labels() {
		return array(
			'dashboard'       => __( 'Dashboard', 'brand-market' ),
			'orders'          => __( 'Orders', 'brand-market' ),
			'downloads'       => __( 'Downloads', 'brand-market' ),
			'edit-address'    => ! wc_ship_to_billing_address_only() && wc_shipping_enabled() ? __( 'Addresses', 'brand-market' ) : __( 'Address', 'brand-market' ),
			'edit-account'    => __( 'My details', 'brand-market' ),
			'customer-logout' => __( 'Log out', 'brand-market' ),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_account_menu_items' ) ) {
	/**
	 * Name the sections of the navigation the way the design does.
	 *
	 * @since 0.1.0
	 *
	 * @param array $items Endpoint => label.
	 *
	 * @return array
	 */
	function mvweb_theme_account_menu_items( $items ) {
		return array_merge( $items, array_intersect_key( mvweb_theme_account_labels(), $items ) );
	}
}
add_filter( 'woocommerce_account_menu_items', 'mvweb_theme_account_menu_items', 20 );

if ( ! function_exists( 'mvweb_theme_account_icon' ) ) {
	/**
	 * The icon of a section of the account.
	 *
	 * @since 0.1.0
	 *
	 * @param string $endpoint Endpoint.
	 *
	 * @return string Icon name.
	 */
	function mvweb_theme_account_icon( $endpoint ) {
		$icons = array(
			'dashboard'       => 'layout-grid',
			'orders'          => 'package',
			'downloads'       => 'download',
			'edit-address'    => 'map-pin',
			'edit-account'    => 'user',
			'payment-methods' => 'lock',
			'customer-logout' => 'door',
		);

		return isset( $icons[ $endpoint ] ) ? $icons[ $endpoint ] : 'layout-grid';
	}
}

if ( ! function_exists( 'mvweb_theme_account_order_id' ) ) {
	/**
	 * The order the account shows, when the customer may see it.
	 *
	 * @since 0.1.0
	 *
	 * @return int Zero outside the page of an order or for an order that is not theirs.
	 */
	function mvweb_theme_account_order_id() {
		global $wp;

		$id = isset( $wp->query_vars['view-order'] ) ? absint( $wp->query_vars['view-order'] ) : 0;

		return $id && current_user_can( 'view_order', $id ) ? $id : 0; // phpcs:ignore WordPress.WP.Capabilities.Unknown -- Capability of WooCommerce.
	}
}

if ( ! function_exists( 'mvweb_theme_account_head' ) ) {
	/**
	 * What the head of the page of the account says: the heading, the text under it and the trail.
	 *
	 * @since 0.1.0
	 *
	 * @return array{title:string,lead:string,trail:array<int,array{label:string,url:string}>}
	 */
	function mvweb_theme_account_head() {
		static $head = null;

		if ( null !== $head ) {
			return $head;
		}

		$endpoint = mvweb_theme_account_endpoint();
		$labels   = mvweb_theme_account_labels();
		$page     = wc_get_page_id( 'myaccount' );
		$account  = array(
			'label' => '' !== get_the_title( $page ) ? get_the_title( $page ) : $labels['dashboard'],
			'url'   => (string) get_permalink( $page ),
		);
		$register = 'yes' === get_option( 'woocommerce_enable_myaccount_registration' );
		$head     = array(
			'title' => $account['label'],
			'lead'  => '',
			'trail' => array(),
		);

		if ( 'lost-password' === $endpoint ) {
			$sign_in       = array(
				'label' => __( 'Login', 'brand-market' ),
				'url'   => $account['url'],
			);
			$head['title'] = __( 'Password reset', 'brand-market' );
			$head['trail'] = is_user_logged_in() ? array() : array( $sign_in );

			return $head;
		}

		if ( ! is_user_logged_in() ) {
			$head['title'] = $register ? __( 'Sign in and register', 'brand-market' ) : __( 'Login', 'brand-market' );
			$head['lead']  = $register ? __( 'Sign in to see your orders, or create an account in a minute.', 'brand-market' ) : __( 'Sign in to see your orders.', 'brand-market' );

			return $head;
		}

		if ( '' === $endpoint ) {
			return $head;
		}

		$head['trail'] = array( $account );
		$head['title'] = isset( $labels[ $endpoint ] ) ? $labels[ $endpoint ] : (string) WC()->query->get_endpoint_title( $endpoint );

		if ( 'view-order' === $endpoint ) {
			$order = wc_get_order( mvweb_theme_account_order_id() );

			$head['trail'][] = array(
				'label' => $labels['orders'],
				'url'   => wc_get_account_endpoint_url( 'orders' ),
			);
			$head['title']   = $order ? sprintf(
				/* translators: %s: order number. */
				__( 'Order No. %s', 'brand-market' ),
				$order->get_order_number()
			) : $labels['orders'];
		}

		if ( 'edit-address' === $endpoint && empty( mvweb_theme_account_address_type() ) ) {
			$head['lead'] = wp_strip_all_tags( (string) apply_filters( 'woocommerce_my_account_my_address_description', __( 'These addresses are filled in at the checkout.', 'brand-market' ) ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
		}

		return $head;
	}
}

if ( ! function_exists( 'mvweb_theme_account_address_type' ) ) {
	/**
	 * The address being edited.
	 *
	 * @since 0.1.0
	 *
	 * @return string billing, shipping, or empty on the list of addresses.
	 */
	function mvweb_theme_account_address_type() {
		global $wp;

		$type = isset( $wp->query_vars['edit-address'] ) ? sanitize_key( $wp->query_vars['edit-address'] ) : '';

		return in_array( $type, array( 'billing', 'shipping' ), true ) ? $type : '';
	}
}

if ( ! function_exists( 'mvweb_theme_account_crumbs' ) ) {
	/**
	 * The breadcrumbs of the account: home, the account, the section.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $items Trail so far.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_theme_account_crumbs( $items ) {
		if ( ! mvweb_theme_account_on() || ! is_page() || empty( $items ) ) {
			return $items;
		}

		$head  = mvweb_theme_account_head();
		$trail = array( reset( $items ) );

		foreach ( $head['trail'] as $crumb ) {
			$trail[] = $crumb;
		}

		$trail[] = array( 'label' => $head['title'] );

		return $trail;
	}
}
add_filter( 'mvweb_core_crumb_items', 'mvweb_theme_account_crumbs' );

if ( ! function_exists( 'mvweb_theme_account_layout_html' ) ) {
	/**
	 * Print the parts of an area one by one and keep what each printed.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area name.
	 * @param array  $args Arguments passed to every part template.
	 *
	 * @return array<string,string> Part slug => markup, in the order of the area, empty parts left out.
	 */
	function mvweb_theme_account_layout_html( $area, array $args = array() ) {
		$area = mvweb_core_layout_area( $area );
		$html = array();

		foreach ( mvweb_core_layout_order( $area ) as $slug ) {
			$part = sanitize_key( $slug );

			if ( '' === $part || 0 !== validate_file( 'template-parts/' . $area . '/' . $part ) ) {
				continue;
			}

			ob_start();
			get_template_part( 'template-parts/' . $area . '/' . $part, null, array_merge( $args, array( 'area' => $area ) ) );
			$markup = trim( (string) ob_get_clean() );

			if ( '' !== $markup ) {
				$html[ $part ] = $markup;
			}
		}

		return $html;
	}
}

if ( ! function_exists( 'mvweb_theme_account_notice_tags' ) ) {
	/**
	 * Let the notices keep the icon of the alert.
	 *
	 * @since 0.1.0
	 *
	 * @param array $tags Allowed tags.
	 *
	 * @return array
	 */
	function mvweb_theme_account_notice_tags( $tags ) {
		$tags['svg']    = array(
			'class'       => array(),
			'aria-hidden' => array(),
			'focusable'   => array(),
			'role'        => array(),
			'style'       => array(),
			'xmlns'       => array(),
		);
		$tags['symbol'] = array(
			'id'      => array(),
			'viewbox' => array(),
		);
		$tags['path']   = array( 'd' => array() );
		$tags['use']    = array( 'href' => array() );

		return $tags;
	}
}
add_filter( 'woocommerce_kses_notice_allowed_tags', 'mvweb_theme_account_notice_tags' );

if ( ! function_exists( 'mvweb_theme_account_register_name' ) ) {
	/**
	 * Keep the name the registration form asked for.
	 *
	 * @since 0.1.0
	 *
	 * @param int $customer_id New customer.
	 *
	 * @return void
	 */
	function mvweb_theme_account_register_name( $customer_id ) {
		if ( empty( $_POST['first_name'] ) || ! is_string( $_POST['first_name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked by WooCommerce before the customer is created.
			return;
		}

		$name = sanitize_text_field( wp_unslash( $_POST['first_name'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked by WooCommerce before the customer is created.

		if ( '' === $name ) {
			return;
		}

		wp_update_user(
			array(
				'ID'           => absint( $customer_id ),
				'first_name'   => $name,
				'display_name' => $name,
			)
		);
		update_user_meta( absint( $customer_id ), 'billing_first_name', $name );
	}
}
add_action( 'woocommerce_created_customer', 'mvweb_theme_account_register_name' );

if ( ! function_exists( 'mvweb_theme_account_register_consent' ) ) {
	/**
	 * Refuse a registration without the consent the form asks for.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Error $errors Errors so far.
	 *
	 * @return WP_Error
	 */
	function mvweb_theme_account_register_consent( $errors ) {
		if ( empty( $_POST['agree'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked by WooCommerce before this filter runs.
			$errors->add( 'mvweb_consent', __( 'Please confirm your consent to the processing of personal data.', 'brand-market' ) );
		}

		return $errors;
	}
}
add_filter( 'woocommerce_process_registration_errors', 'mvweb_theme_account_register_consent' );

if ( ! function_exists( 'mvweb_theme_account_scripts' ) ) {
	/**
	 * Leave out the strength meter of WooCommerce on the account.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_account_scripts() {
		if ( ! mvweb_theme_account_on() ) {
			return;
		}

		wp_dequeue_script( 'wc-password-strength-meter' );
		wp_dequeue_script( 'zxcvbn-async' );
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_theme_account_scripts', 100 );
