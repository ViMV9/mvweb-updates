<?php
/**
 * Stylesheets of the theme for the keys the core asks for.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_enqueue_styles' ) ) {
	/**
	 * Enqueue assets/css/{key}.css of the theme for every key of the request, in order.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_enqueue_styles() {
		$previous = '';

		foreach ( mvweb_core_style_map() as $key ) {
			$file = '';

			foreach ( array( '.min.css', '.css' ) as $extension ) {
				if ( '' === $file && file_exists( get_template_directory() . '/assets/css/' . $key . $extension ) ) {
					$file = '/assets/css/' . $key . $extension;
				}
			}

			if ( '' === $file ) {
				continue;
			}

			$handle = 'mvweb-t-' . str_replace( '/', '-', $key );

			wp_enqueue_style(
				$handle,
				get_template_directory_uri() . $file,
				'' === $previous ? array() : array( $previous ),
				(string) filemtime( get_template_directory() . $file )
			);

			$previous = $handle;
		}
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_theme_enqueue_styles' );

if ( ! function_exists( 'mvweb_theme_style_map' ) ) {
	/**
	 * Add the sheets of the theme that the core does not know: the width of the content and the entrance animation.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Keys of the request.
	 *
	 * @return string[]
	 */
	function mvweb_theme_style_map( $styles ) {
		$at = array_search( 'base', $styles, true );
		$at = false === $at ? 0 : $at + 1;

		array_splice( $styles, $at, 0, array( 'wide' ) );

		if ( mvweb_core_motion_active() ) {
			array_splice( $styles, $at + 1, 0, array( 'motion' ) );
		}

		if ( is_search() ) {
			array_push( $styles, 'catalog', 'service', 'works', 'blog' );
		}

		$first = count( $styles );

		foreach ( $styles as $index => $style ) {
			if ( 0 === strpos( $style, 'sections/' ) ) {
				$first = $index;
				break;
			}
		}

		$types = mvweb_core_request_section_types();

		if ( ! in_array( 'catalog', $styles, true ) && array_intersect( array( 'products', 'promo-products' ), $types ) ) {
			array_splice( $styles, $first, 0, array( 'catalog' ) );
			++$first;
		}

		if ( is_page() || in_array( 'embed', $types, true ) ) {
			$styles[] = 'form';
		}

		if ( mvweb_core_is_product() && function_exists( 'mvweb_core_one_click' ) && mvweb_core_one_click() ) {
			$styles[] = 'modal';
		}

		if ( array_intersect( array( 'content', 'seo-text' ), $types ) && ! in_array( 'article', $styles, true ) ) {
			array_splice( $styles, $first, 0, array( 'article' ) );
		}

		return $styles;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_theme_style_map' );

if ( ! function_exists( 'mvweb_theme_module_map' ) ) {
	/**
	 * Add the modules of the core that the blocks of the theme lean on.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules File names without extension.
	 *
	 * @return string[]
	 */
	function mvweb_theme_module_map( $modules ) {
		if ( in_array( 'promo-products', mvweb_core_request_section_types(), true ) ) {
			$modules[] = 'showcase';
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_theme_module_map' );

if ( ! function_exists( 'mvweb_theme_preload_fonts' ) ) {
	/**
	 * Preload the two font files so the text does not jump when they arrive.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_preload_fonts() {
		foreach ( array( 'onest', 'golos-text' ) as $font ) {
			printf( "<link rel=\"preload\" href=\"%s\" as=\"font\" type=\"font/woff2\" crossorigin>\n", esc_url( get_template_directory_uri() . '/assets/fonts/' . $font . '.woff2' ) );
		}
	}
}
add_action( 'wp_head', 'mvweb_theme_preload_fonts', 1 );

if ( ! function_exists( 'mvweb_theme_enqueue_scripts' ) ) {
	/**
	 * Enqueue the script of the theme: the states of the request window and the search type select.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_enqueue_scripts() {
		$file = '/assets/js/frame.js';

		wp_enqueue_script(
			'mvweb-t-frame',
			get_template_directory_uri() . $file,
			array(),
			(string) filemtime( get_template_directory() . $file ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_theme_enqueue_scripts' );
