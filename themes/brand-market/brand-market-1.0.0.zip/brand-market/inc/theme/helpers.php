<?php
/**
 * Design helpers the templates of the theme call.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_header_class' ) ) {
	/**
	 * Class list for the header element.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_theme_header_class() {
		$classes = array( 'mvweb-t-header' );

		if ( is_singular( 'page' ) && has_post_thumbnail() ) {
			$classes[] = 'mvweb-t-header--overlay';
		}

		/**
		 * Filter the header class list.
		 *
		 * @since 0.1.0
		 *
		 * @param string[] $classes Class names.
		 */
		$classes = (array) apply_filters( 'mvweb_theme_header_class', $classes );

		return implode( ' ', array_filter( array_map( 'sanitize_html_class', $classes ) ) );
	}
}

if ( ! function_exists( 'mvweb_theme_pagination' ) ) {
	/**
	 * Print pagination in the theme's own markup.
	 *
	 * @since 0.1.0
	 *
	 * @param array $args Optional. Arguments passed to paginate_links(). The
	 *                    'type' key is ignored — this function needs an array.
	 *
	 * @return void
	 */
	function mvweb_theme_pagination( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'mid_size'  => 1,
				'end_size'  => 1,
				'prev_text' => mvweb_theme_icon( 'chevron-left', array( 'class' => 'mvweb-t-icon--sm' ) ) . '<span class="screen-reader-text">' . esc_html__( 'Previous page', 'brand-market' ) . '</span>',
				'next_text' => mvweb_theme_icon( 'chevron-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '<span class="screen-reader-text">' . esc_html__( 'Next page', 'brand-market' ) . '</span>',
			)
		);

		$args['type'] = 'array';

		$links = paginate_links( $args );

		if ( empty( $links ) ) {
			return;
		}

		$map = array(
			'class="prev page-numbers"' => 'class="mvweb-t-pagination__item" title="' . esc_attr__( 'Previous page', 'brand-market' ) . '"',
			'class="next page-numbers"' => 'class="mvweb-t-pagination__item" title="' . esc_attr__( 'Next page', 'brand-market' ) . '"',
			'page-numbers dots'         => 'mvweb-t-pagination__item mvweb-t-pagination__item--dots',
			'page-numbers current'      => 'mvweb-t-pagination__item',
			'page-numbers'              => 'mvweb-t-pagination__item',
		);

		printf(
			'<nav class="mvweb-t-pagination" aria-label="%s">',
			esc_attr__( 'Pagination', 'brand-market' )
		);

		foreach ( $links as $link ) {
			echo str_replace( array_keys( $map ), array_values( $map ), $link ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup comes from paginate_links(), which escapes it.
		}

		echo '</nav>';
	}
}

if ( ! function_exists( 'mvweb_theme_logo' ) ) {
	/**
	 * Print the site logo: the uploaded image, or the site name as a wordmark.
	 *
	 * @since 0.1.0
	 *
	 * @param array $args Optional. 'class' — extra classes on the link,
	 *                    'tag' — 'a' (default) or 'span' for the drawer copy,
	 *                    'lazy' — true for copies below the first screen.
	 *
	 * @return void
	 */
	function mvweb_theme_logo( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'class' => '',
				'tag'   => 'a',
				'lazy'  => false,
			)
		);

		$light = (int) get_theme_mod( 'custom_logo' );
		$dark  = (int) get_theme_mod( 'mvweb_logo_dark' );
		$light = wp_attachment_is_image( $light ) ? $light : 0;
		$dark  = wp_attachment_is_image( $dark ) ? $dark : 0;
		$sign  = ( $light || $dark ) && 'mark' === mvweb_cz_get( 'mvweb_logo_layout', 'image' );
		$alt   = $sign ? '' : get_bloginfo( 'name' );

		$tag        = 'span' === $args['tag'] ? 'span' : 'a';
		$class      = trim( 'mvweb-t-logo ' . ( $sign ? 'mvweb-t-logo--sign ' : '' ) . $args['class'] );
		$attributes = 'a' === $tag ? sprintf( ' href="%s" rel="home"', esc_url( home_url( '/' ) ) ) : '';

		printf( '<%1$s class="%2$s"%3$s>', esc_html( $tag ), esc_attr( $class ), $attributes ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Attributes escaped above.

		if ( $light && $dark && $light !== $dark ) {
			echo mvweb_theme_logo_image( $light, 'mvweb-t-logo__img mvweb-t-logo__img--light', $args['lazy'], $alt ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
			echo mvweb_theme_logo_image( $dark, 'mvweb-t-logo__img mvweb-t-logo__img--dark', $args['lazy'], $alt ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
		} elseif ( $light || $dark ) {
			echo mvweb_theme_logo_image( $light ? $light : $dark, 'mvweb-t-logo__img', $args['lazy'], $alt ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
		}

		if ( $sign ) {
			$name    = trim( (string) mvweb_cz_get( 'mvweb_logo_name', '' ) );
			$name    = '' !== $name ? $name : get_bloginfo( 'name' );
			$tagline = trim( (string) mvweb_cz_get( 'mvweb_logo_tagline', '' ) );

			printf( '<span class="mvweb-t-logo__brand"><span class="mvweb-t-logo__name">%s</span>', esc_html( $name ) );

			if ( '' !== $tagline ) {
				printf( '<span class="mvweb-t-logo__tagline">%s</span>', esc_html( $tagline ) );
			}

			echo '</span>';
		} elseif ( ! $light && ! $dark ) {
			$name  = get_bloginfo( 'name' );
			$words = preg_split( '/\s+/u', trim( $name ), 2, PREG_SPLIT_NO_EMPTY );
			$words = is_array( $words ) ? $words : array( $name );

			$mark = '';
			foreach ( $words as $word ) {
				$mark .= mb_substr( $word, 0, 1 );
			}

			printf( '<span class="mvweb-t-logo__mark" aria-hidden="true">%s</span>', esc_html( $mark ) );
			echo '<span class="mvweb-t-logo__text">';
			foreach ( $words as $word ) {
				printf( '<span>%s</span>', esc_html( $word ) );
			}
			echo '</span>';
		}

		printf( '</%s>', esc_html( $tag ) );
	}
}

if ( ! function_exists( 'mvweb_theme_logo_image' ) ) {
	/**
	 * One logo image, with a sizes value that matches how big it is shown.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $id      Attachment id.
	 * @param string $classes Class list.
	 * @param bool   $lazy    Whether the copy sits below the first screen.
	 * @param string $alt     Alternative text; empty when the name is printed
	 *                        next to the image.
	 *
	 * @return string
	 */
	function mvweb_theme_logo_image( $id, $classes, $lazy, $alt ) {
		$attr = array(
			'class'         => $classes,
			'alt'           => $alt,
			'loading'       => $lazy ? 'lazy' : false,
			'fetchpriority' => $lazy ? false : 'auto',
		);

		$image = wp_get_attachment_image_src( $id, 'full' );

		if ( $image && $image[2] > 0 ) {
			$ratio         = $image[1] / $image[2];
			$attr['sizes'] = sprintf(
				'(max-width: 1000px) %dpx, %dpx',
				ceil( (int) mvweb_cz_get( 'mvweb_logo_height_mobile', 40 ) * $ratio ),
				ceil( (int) mvweb_cz_get( 'mvweb_logo_height', 40 ) * $ratio )
			);
		}

		return wp_get_attachment_image( $id, 'full', false, $attr );
	}
}

if ( ! function_exists( 'mvweb_theme_drop_breadcrumbs_block_style' ) ) {
	/**
	 * Drop the stylesheet the breadcrumbs block enqueues when it renders.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_drop_breadcrumbs_block_style() {
		wp_deregister_style( 'wp-block-breadcrumbs' );
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_theme_drop_breadcrumbs_block_style', 20 );

if ( ! function_exists( 'mvweb_theme_card_group' ) ) {
	/**
	 * Open and close the groups of the body of a product card.
	 *
	 * @since 0.1.0
	 *
	 * @param array  $args  Arguments of the card, with its state.
	 * @param string $group Group the part belongs to: info or foot. Empty closes the open one.
	 *
	 * @return void
	 */
	function mvweb_theme_card_group( array $args, $group ) {
		if ( ! isset( $args['state'] ) || ! $args['state'] instanceof ArrayObject ) {
			return;
		}

		$open = (string) $args['state']['group'];

		if ( $open === $group ) {
			return;
		}

		if ( '' !== $open ) {
			echo '</div>';
		}

		if ( '' !== $group ) {
			echo '<div class="mvweb-t-card__' . esc_attr( $group ) . '">';
		}

		$args['state']['group'] = $group;
	}
}

if ( ! function_exists( 'mvweb_theme_product_ids' ) ) {
	/**
	 * The products a block shows, from its source field.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props Values of the block: source, count, items, category.
	 *
	 * @return int[]
	 */
	function mvweb_theme_product_ids( array $props ) {
		$source = isset( $props['source'] ) ? (string) $props['source'] : 'featured';
		$count  = isset( $props['count'] ) ? absint( $props['count'] ) : 0;

		if ( 'category' !== $source ) {
			$rows = isset( $props['items'] ) && is_array( $props['items'] ) ? mvweb_core_visible_rows( $props['items'] ) : array();

			return mvweb_core_showcase_items( $source, $count, array_column( $rows, 'item' ) );
		}

		$args = array(
			'post_type'        => mvweb_core_post_type(),
			'post_status'      => 'publish',
			'numberposts'      => $count > 0 ? $count : 4,
			'fields'           => 'ids',
			'suppress_filters' => false,
			'orderby'          => array(
				'menu_order' => 'ASC',
				'date'       => 'DESC',
			),
		);
		$term = isset( $props['category'] ) ? absint( $props['category'] ) : 0;

		if ( $term > 0 ) {
			$args['tax_query'] = array_merge( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- The department is what the block is for.
				array(
					array(
						'taxonomy' => mvweb_core_taxonomy(),
						'field'    => 'term_id',
						'terms'    => array( $term ),
					),
				),
				mvweb_core_visibility_query()
			);
		}

		return array_values( array_filter( array_map( 'absint', (array) get_posts( $args ) ), 'mvweb_core_item_visible' ) );
	}
}

if ( ! function_exists( 'mvweb_theme_departments' ) ) {
	/**
	 * The top level departments of a set of products.
	 *
	 * @since 0.1.0
	 *
	 * @param int[] $ids Product ids.
	 *
	 * @return array{by_item:array<int,string[]>,names:array<string,string>} Slugs of each product; slug => name in the order they first appear.
	 */
	function mvweb_theme_departments( array $ids ) {
		$by_item  = array();
		$names    = array();
		$taxonomy = mvweb_core_taxonomy();

		foreach ( $ids as $id ) {
			$by_item[ $id ] = array();
			$terms          = wp_get_post_terms( $id, $taxonomy );

			foreach ( is_array( $terms ) ? $terms : array() as $term ) {
				$ancestors = get_ancestors( $term->term_id, $taxonomy, 'taxonomy' );
				$top       = empty( $ancestors ) ? $term : get_term( (int) end( $ancestors ), $taxonomy );

				if ( $top instanceof WP_Term ) {
					$by_item[ $id ][ $top->slug ] = $top->slug;
					$names[ $top->slug ]          = $top->name;
				}
			}

			$by_item[ $id ] = array_values( $by_item[ $id ] );
		}

		return array(
			'by_item' => $by_item,
			'names'   => $names,
		);
	}
}

if ( ! function_exists( 'mvweb_theme_form_shortcode' ) ) {
	/**
	 * Render a form shortcode, or nothing when the plugin that owns it is off.
	 *
	 * An unregistered shortcode would print as plain text on the page.
	 *
	 * @since 0.1.0
	 *
	 * @param string $shortcode Shortcode as the editor entered it.
	 *
	 * @return string Markup of the plugin, or an empty string.
	 */
	function mvweb_theme_form_shortcode( $shortcode ) {
		$shortcode = trim( (string) $shortcode );

		if ( '' === $shortcode || 1 !== preg_match( '/\[([\w-]+)/', $shortcode, $match ) || ! shortcode_exists( $match[1] ) ) {
			return '';
		}

		return trim( do_shortcode( $shortcode ) );
	}
}

if ( ! function_exists( 'mvweb_theme_showcase_arrows' ) ) {
	/**
	 * The previous and next buttons of a scrolling row, driven by showcase.js.
	 *
	 * @since 0.1.0
	 *
	 * @param array $args Optional. Keys: prev and next (labels), class (own class of a button, with a --prev / --next modifier), hide_prev (bool, the previous button starts hidden), small (bool, smaller icons).
	 *
	 * @return string Escaped markup of two buttons.
	 */
	function mvweb_theme_showcase_arrows( array $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'prev'      => __( 'Previous', 'brand-market' ),
				'next'      => __( 'Next', 'brand-market' ),
				'class'     => '',
				'hide_prev' => false,
				'small'     => false,
			)
		);
		$html = '';
		$icon = $args['small'] ? array( 'class' => 'mvweb-t-icon--sm' ) : array();

		foreach ( array( 'prev', 'next' ) as $way ) {
			$class = 'mvweb-t-round mvweb-t-round--line' . ( '' !== $args['class'] ? ' ' . $args['class'] . ' ' . $args['class'] . '--' . $way : '' );
			$label = (string) $args[ $way ];
			$html .= '<button class="' . esc_attr( $class ) . '" type="button" data-showcase-' . $way . ( 'prev' === $way && $args['hide_prev'] ? ' hidden' : '' ) . ' title="' . esc_attr( $label ) . '">' . mvweb_theme_icon( 'prev' === $way ? 'chevron-left' : 'chevron-right', $icon ) . '<span class="screen-reader-text">' . esc_html( $label ) . '</span></button>';
		}

		return $html;
	}
}

if ( ! function_exists( 'mvweb_theme_buy_data' ) ) {
	/**
	 * What the purchase block needs to count a total: the price, the price steps and the money format.
	 *
	 * Only the steps below the price, as the cart takes them.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return array<string,mixed> Empty outside the shop mode and for a product that cannot go to the cart as it is.
	 */
	function mvweb_theme_buy_data( $id ) {
		$product = mvweb_core_shop_mode() ? mvweb_core_wc_item( $id ) : null;

		if ( ! $product || ! $product->is_type( 'simple' ) || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
			return array();
		}

		$price = (float) wc_get_price_to_display( $product );

		if ( $price <= 0 ) {
			return array();
		}

		$tiers = array();

		foreach ( mvweb_core_tiers( $id ) as $from => $amount ) {
			if ( (float) $amount < $price ) {
				$tiers[ (int) $from ] = (float) $amount;
			}
		}

		return array(
			'price' => $price,
			'tiers' => $tiers,
			'min'   => max( 1, (int) $product->get_min_purchase_quantity(), mvweb_core_quantity_rules( $id )['min'] ),
			'money' => array(
				'decimals'  => wc_get_price_decimals(),
				'point'     => wc_get_price_decimal_separator(),
				'thousands' => wc_get_price_thousand_separator(),
				'format'    => html_entity_decode( sprintf( get_woocommerce_price_format(), get_woocommerce_currency_symbol(), '%s' ), ENT_QUOTES, 'UTF-8' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_buy_unit' ) ) {
	/**
	 * The price of one piece for a quantity.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $data     What mvweb_theme_buy_data() returns.
	 * @param int                 $quantity Quantity.
	 *
	 * @return float
	 */
	function mvweb_theme_buy_unit( array $data, $quantity ) {
		$unit = (float) $data['price'];

		foreach ( $data['tiers'] as $from => $amount ) {
			if ( $quantity >= $from ) {
				$unit = (float) $amount;
			}
		}

		return $unit;
	}
}

if ( ! function_exists( 'mvweb_theme_back_url' ) ) {
	/**
	 * Where the back button of an item page leads without the browser history: the last link of the breadcrumbs.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty when the button is switched off.
	 */
	function mvweb_theme_back_url() {
		if ( ! get_theme_mod( 'mvweb_product_back', true ) ) {
			return '';
		}

		$url = '';

		foreach ( mvweb_core_crumb_items() as $item ) {
			if ( ! empty( $item['url'] ) ) {
				$url = (string) $item['url'];
			}
		}

		return '' !== $url ? $url : home_url( '/' );
	}
}
