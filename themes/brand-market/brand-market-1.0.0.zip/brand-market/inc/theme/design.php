<?php
/**
 * Palette presets.
 *
 * 'tokens' are printed for both schemes, 'dark' only under the dark one.
 * Text on the accent is always `accent-ink`, a link is `accent-link`.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_palettes' ) ) {
	/**
	 * Register the theme palettes.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $palettes Presets so far.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_palettes( $palettes ) {
		$palettes['yellow']   = array(
			'label'  => __( 'Yellow', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#ffd60a',
				'--mvweb-t-accent-hover' => '#e8c200',
				'--mvweb-t-accent-ink'   => '#1b1c1f',
				'--mvweb-t-accent-link'  => '#6b5700',
			),
			'dark'   => array(
				'--mvweb-t-accent-hover' => '#ffe047',
				'--mvweb-t-accent-link'  => '#ffd60a',
			),
		);
		$palettes['peach']    = array(
			'label'  => __( 'Peach', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#ffb48a',
				'--mvweb-t-accent-hover' => '#f79e6c',
				'--mvweb-t-accent-ink'   => '#1b1c1f',
				'--mvweb-t-accent-link'  => '#9a4a1a',
			),
			'dark'   => array(
				'--mvweb-t-accent-hover' => '#ffc4a3',
				'--mvweb-t-accent-link'  => '#ffb48a',
			),
		);
		$palettes['navy']     = array(
			'label'  => __( 'Navy', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#1f3a5f',
				'--mvweb-t-accent-hover' => '#162c49',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#1f3a5f',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#8db2e6',
				'--mvweb-t-accent-hover' => '#a9c5ee',
				'--mvweb-t-accent-ink'   => '#10141a',
				'--mvweb-t-accent-link'  => '#8db2e6',
			),
		);
		$palettes['emerald']  = array(
			'label'  => __( 'Emerald', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#0d6b4e',
				'--mvweb-t-accent-hover' => '#0a5840',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#0d6b4e',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#4cc9a0',
				'--mvweb-t-accent-hover' => '#6bd8b5',
				'--mvweb-t-accent-ink'   => '#0a1a14',
				'--mvweb-t-accent-link'  => '#4cc9a0',
			),
		);
		$palettes['burgundy'] = array(
			'label'  => __( 'Burgundy', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#8c1d3f',
				'--mvweb-t-accent-hover' => '#741633',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#8c1d3f',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#ec8aa5',
				'--mvweb-t-accent-hover' => '#f2a3b8',
				'--mvweb-t-accent-ink'   => '#1a0a10',
				'--mvweb-t-accent-link'  => '#ec8aa5',
			),
		);

		return $palettes;
	}
}
add_filter( 'mvweb_core_palettes', 'mvweb_theme_palettes' );
