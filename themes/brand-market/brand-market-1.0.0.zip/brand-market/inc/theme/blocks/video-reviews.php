<?php
/**
 * Block description: video reviews.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Carousel of covers', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Wall of stories', 'brand-market' ),
			'class'  => 'wall',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Main video and a list', 'brand-market' ),
			'class'  => 'feature',
			'motion' => 'slide',
		),
		'4' => array(
			'label'  => __( 'Phone frames', 'brand-market' ),
			'class'  => 'phones',
			'motion' => 'blur',
		),
		'5' => array(
			'label'  => __( 'List with descriptions', 'brand-market' ),
			'class'  => 'list',
			'motion' => 'wipe',
		),
	),
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'lead'   => __( 'Lead', 'brand-market' ),
		'nav'    => __( 'Arrows', 'brand-market' ),
		'list'   => __( 'Video reviews', 'brand-market' ),
	),
	'item_parts' => array(
		'duration' => __( 'Length', 'brand-market' ),
		'title'    => __( 'Title', 'brand-market' ),
		'note'     => __( 'Line under the title', 'brand-market' ),
		'text'     => __( 'Description', 'brand-market' ),
		'cta'      => __( 'Watch link', 'brand-market' ),
	),
	'only'       => array(
		'items.text'      => array( '5' ),
		'parts.nav'       => array( '1' ),
		'item_parts.text' => array( '5' ),
		'item_parts.cta'  => array( '5' ),
	),
);
