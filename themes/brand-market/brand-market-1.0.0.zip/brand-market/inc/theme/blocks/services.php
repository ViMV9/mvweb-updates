<?php
/**
 * Block description: services of the company.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Cards with an icon', 'brand-market' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Cards with a photo', 'brand-market' ),
			'class'  => 'photos',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Rows with prices', 'brand-market' ),
			'class'  => 'rows',
			'motion' => 'wipe',
		),
		'4' => array(
			'label'  => __( 'Large card and small ones', 'brand-market' ),
			'class'  => 'hero',
			'motion' => 'slide',
		),
		'5' => array(
			'label'  => __( 'Tabs with a price list', 'brand-market' ),
			'class'  => 'tabs',
			'motion' => 'blur',
		),
	),
	'parts'      => array(
		'kicker' => __( 'Kicker', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'lead'   => __( 'Lead', 'brand-market' ),
		'list'   => __( 'Services', 'brand-market' ),
		'foot'   => __( 'Link under the list', 'brand-market' ),
	),
	'item_parts' => array(
		'icon'  => __( 'Icon', 'brand-market' ),
		'image' => __( 'Picture', 'brand-market' ),
		'text'  => __( 'Short text', 'brand-market' ),
		'price' => __( 'Price', 'brand-market' ),
		'go'    => __( 'Arrow', 'brand-market' ),
	),
	'only'       => array(
		'items.icon'       => array( '1', '5' ),
		'items.image'      => array( '2', '4' ),
		'items.group'      => array( '5' ),
		'item_parts.icon'  => array( '1', '5' ),
		'item_parts.image' => array( '2', '4' ),
		'item_parts.go'    => array( '1', '2', '3', '4' ),
	),
);
