<?php
/**
 * Block description: partners and documents.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Tiles', 'brand-market' ),
			'class'  => 'logos',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Running line', 'brand-market' ),
			'class'  => 'marquee',
			'motion' => 'fade',
		),
		'3' => array(
			'label'  => __( 'Grey row', 'brand-market' ),
			'class'  => 'mono',
			'motion' => 'blur',
		),
		'4' => array(
			'label'  => __( 'Coloured tiles', 'brand-market' ),
			'class'  => 'color',
			'motion' => 'scale',
		),
		'5' => array(
			'label'  => __( 'Documents to download', 'brand-market' ),
			'class'  => 'cards',
			'motion' => 'slide',
		),
	),
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'lead'   => __( 'Lead', 'brand-market' ),
		'badge'  => __( 'Sign beside the heading', 'brand-market' ),
		'list'   => __( 'List', 'brand-market' ),
	),
	'item_parts' => array(
		'image'    => __( 'Logo or preview', 'brand-market' ),
		'kind'     => __( 'File type and size', 'brand-market' ),
		'name'     => __( 'Name', 'brand-market' ),
		'arrow'    => __( 'Arrow', 'brand-market' ),
		'download' => __( 'Download button', 'brand-market' ),
		'note'     => __( 'Note', 'brand-market' ),
	),
	'only'       => array(
		'logos.note'          => array( '5' ),
		'item_parts.kind'     => array( '5' ),
		'item_parts.arrow'    => array( '4' ),
		'item_parts.download' => array( '5' ),
		'item_parts.note'     => array( '5' ),
	),
);
