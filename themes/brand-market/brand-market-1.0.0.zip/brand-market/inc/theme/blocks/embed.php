<?php
/**
 * Block description: a widget of another plugin.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Widget in a frame', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'On a backdrop with a ribbon', 'brand-market' ),
			'class'  => 'stage',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Numbered steps', 'brand-market' ),
			'class'  => 'steps',
			'motion' => 'blur',
		),
		'4' => array(
			'label'  => __( 'Bar', 'brand-market' ),
			'class'  => 'bar',
			'motion' => 'slide',
		),
		'5' => array(
			'label'  => __( 'Dark panel', 'brand-market' ),
			'class'  => 'dark',
			'motion' => 'wipe',
		),
	),
	'parts' => array(
		'kicker' => __( 'Kicker', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'lead'   => __( 'Lead', 'brand-market' ),
		'ticker' => __( 'Ribbon', 'brand-market' ),
	),
	'only'  => array(
		'ticker'       => array( '2' ),
		'parts.ticker' => array( '2' ),
	),
);
