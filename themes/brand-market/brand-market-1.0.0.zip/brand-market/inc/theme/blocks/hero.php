<?php
/**
 * Block description: first screen.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Photo across the screen', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Text and photo slab', 'brand-market' ),
			'class'  => 'split',
			'motion' => 'slide',
		),
		'3' => array(
			'label'  => __( 'Centred, three frames', 'brand-market' ),
			'class'  => 'center',
			'motion' => 'scale',
		),
		'4' => array(
			'label'  => __( 'Card on the photo', 'brand-market' ),
			'class'  => 'card',
			'motion' => 'wipe',
		),
		'5' => array(
			'label'  => __( 'Large type and a running line', 'brand-market' ),
			'class'  => 'type',
			'motion' => 'blur',
		),
	),
	'parts'      => array(
		'title'    => __( 'Heading', 'brand-market' ),
		'features' => __( 'Short promises', 'brand-market' ),
		'button'   => __( 'Button', 'brand-market' ),
		'trust'    => __( 'Figures', 'brand-market' ),
		'plate'    => __( 'Plate on the photo', 'brand-market' ),
	),
	'item_parts' => array(
		'image'   => __( 'Frame', 'brand-market' ),
		'number'  => __( 'Figure', 'brand-market' ),
		'caption' => __( 'Caption', 'brand-market' ),
	),
	'only'       => array(
		'trust.image'      => array( '3' ),
		'parts.plate'      => array( '2' ),
		'item_parts.image' => array( '3' ),
		'image_side'       => array( '2' ),
		'image_size'       => array( '2' ),
	),
);
