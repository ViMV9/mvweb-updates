<?php
/**
 * Block description: two lists side by side.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Two cards', 'brand-market' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Large marks', 'brand-market' ),
			'class'  => 'marks',
			'motion' => 'slide',
		),
		'3' => array(
			'label'  => __( 'One card', 'brand-market' ),
			'class'  => 'split',
			'motion' => 'wipe',
		),
		'4' => array(
			'label'  => __( 'Table', 'brand-market' ),
			'class'  => 'table',
			'motion' => 'blur',
		),
		'5' => array(
			'label'  => __( 'Tabs', 'brand-market' ),
			'class'  => 'tabs',
			'motion' => 'scale',
		),
	),
	'parts'      => array(
		'kicker'  => __( 'Kicker', 'brand-market' ),
		'title'   => __( 'Heading', 'brand-market' ),
		'lead'    => __( 'Lead', 'brand-market' ),
		'col_1'   => __( 'First list', 'brand-market' ),
		'divider' => __( 'Divider between the lists (one card)', 'brand-market' ),
		'col_2'   => __( 'Second list', 'brand-market' ),
	),
	'item_parts' => array(
		'mark'  => __( 'Mark before an item', 'brand-market' ),
		'count' => __( 'Number of items (large marks, tabs)', 'brand-market' ),
	),
	'only'       => array(
		'left_tab'         => array( '5' ),
		'right_tab'        => array( '5' ),
		'parts.divider'    => array( '3' ),
		'item_parts.count' => array( '2', '5' ),
	),
);
