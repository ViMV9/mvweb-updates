<?php
/**
 * Block description: plans side by side.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Three cards', 'brand-market' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Plans in rows', 'brand-market' ),
			'class'  => 'table',
			'motion' => 'wipe',
		),
		'3' => array(
			'label'  => __( 'Coloured headers', 'brand-market' ),
			'class'  => 'color',
			'motion' => 'scale',
		),
		'4' => array(
			'label'  => __( 'Steps', 'brand-market' ),
			'class'  => 'steps',
			'motion' => 'slide',
		),
		'5' => array(
			'label'  => __( 'Month or year', 'brand-market' ),
			'class'  => 'toggle',
			'motion' => 'blur',
		),
	),
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'lead'   => __( 'Lead', 'brand-market' ),
		'switch' => __( 'Monthly or yearly switch', 'brand-market' ),
		'list'   => __( 'Plans', 'brand-market' ),
	),
	'item_parts' => array(
		'badge'  => __( 'Badge', 'brand-market' ),
		'name'   => __( 'Name', 'brand-market' ),
		'text'   => __( 'Line under the name', 'brand-market' ),
		'price'  => __( 'Price', 'brand-market' ),
		'items'  => __( 'What is included', 'brand-market' ),
		'button' => __( 'Button', 'brand-market' ),
	),
	'only'       => array(
		'period_month'     => array( '5' ),
		'period_year'      => array( '5' ),
		'period_year_note' => array( '5' ),
		'plans.note_month' => array( '5' ),
		'plans.price_year' => array( '5' ),
		'plans.unit_year'  => array( '5' ),
		'plans.note_year'  => array( '5' ),
		'parts.switch'     => array( '5' ),
	),
);
