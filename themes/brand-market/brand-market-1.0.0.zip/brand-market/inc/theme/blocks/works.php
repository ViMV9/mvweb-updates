<?php
/**
 * Block description: works from the portfolio.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Grid of cards', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Mosaic', 'brand-market' ),
			'class'  => 'mosaic',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Photo and caption', 'brand-market' ),
			'class'  => 'reveal',
			'motion' => 'wipe',
		),
		'4' => array(
			'label'  => __( 'Horizontal ribbon', 'brand-market' ),
			'class'  => 'ribbon',
			'motion' => 'slide',
		),
		'5' => array(
			'label'  => __( 'List with rows', 'brand-market' ),
			'class'  => 'list',
			'motion' => 'blur',
		),
	),
	'parts' => array(
		'kicker' => __( 'Line above the heading', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'lead'   => __( 'Text under the heading', 'brand-market' ),
		'more'   => __( 'Link to all works', 'brand-market' ),
		'list'   => __( 'Cards of works', 'brand-market' ),
	),
);
