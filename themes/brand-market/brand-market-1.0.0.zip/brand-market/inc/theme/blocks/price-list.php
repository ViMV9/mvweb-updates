<?php
/**
 * Block description: a price list.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Classic price list', 'brand-market' ),
			'class'  => 'table',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Menu with dotted lines', 'brand-market' ),
			'class'  => 'dots',
			'motion' => 'wipe',
		),
		'3' => array(
			'label'  => __( 'Cards with icons', 'brand-market' ),
			'class'  => 'cards',
			'motion' => 'scale',
		),
		'4' => array(
			'label'  => __( 'Groups in tabs', 'brand-market' ),
			'class'  => 'tabs',
			'motion' => 'slide',
		),
		'5' => array(
			'label'  => __( 'Accordion of groups', 'brand-market' ),
			'class'  => 'accordion',
			'motion' => 'blur',
		),
	),
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'lead'   => __( 'Lead', 'brand-market' ),
		'list'   => __( 'Prices', 'brand-market' ),
		'footer' => __( 'Button and footnote', 'brand-market' ),
	),
	'item_parts' => array(
		'icon'    => __( 'Group icon', 'brand-market' ),
		'summary' => __( 'Line beside a folded group', 'brand-market' ),
		'note'    => __( 'Note under the name', 'brand-market' ),
	),
	'only'       => array(
		'col_0'              => array( '1', '4' ),
		'col_1'              => array( '1', '4' ),
		'col_2'              => array( '1', '4' ),
		'col_3'              => array( '1', '4' ),
		'rows.icon'          => array( '3' ),
		'rows.col_1'         => array( '4' ),
		'rows.col_2'         => array( '4' ),
		'rows.col_3'         => array( '4' ),
		'rows.button_text'   => array( '4' ),
		'rows.button_url'    => array( '4' ),
		'rows.footnote'      => array( '4' ),
		'item_parts.icon'    => array( '3' ),
		'item_parts.summary' => array( '5' ),
	),
);
