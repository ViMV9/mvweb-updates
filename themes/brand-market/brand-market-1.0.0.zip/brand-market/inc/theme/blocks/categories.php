<?php
/**
 * Block description: what the shop sells, in picture cards.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Mosaic', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Round pictures', 'brand-market' ),
			'class'  => 'circles',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Ribbon of pills', 'brand-market' ),
			'class'  => 'ribbon',
			'motion' => 'slide',
		),
		'4' => array(
			'label'  => __( 'Photo tiles', 'brand-market' ),
			'class'  => 'photo',
			'motion' => 'wipe',
		),
		'5' => array(
			'label'  => __( 'List with previews', 'brand-market' ),
			'class'  => 'list',
			'motion' => 'blur',
		),
	),
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'lead'   => __( 'Text under the heading', 'brand-market' ),
		'more'   => __( 'Link to all', 'brand-market' ),
		'list'   => __( 'Cards', 'brand-market' ),
	),
	'item_parts' => array(
		'title' => __( 'Name', 'brand-market' ),
		'desc'  => __( 'Description', 'brand-market' ),
		'count' => __( 'Line under the name', 'brand-market' ),
		'image' => __( 'Picture', 'brand-market' ),
	),
	'only'       => array(
		'cards.image_2'    => array( '1' ),
		'cards.text'       => array( '1' ),
		'cards.note'       => array( '1', '3', '4', '5' ),
		'cards.size'       => array( '1' ),
		'item_parts.desc'  => array( '1' ),
		'item_parts.count' => array( '1', '3', '4', '5' ),
	),
);
