<?php
/**
 * Block description: what a client gets.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Card with a photo', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Around the photo', 'brand-market' ),
			'class'  => 'orbit',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Cards with numbers', 'brand-market' ),
			'class'  => 'numbers',
			'motion' => 'wipe',
		),
		'4' => array(
			'label'  => __( 'Alternating rows', 'brand-market' ),
			'class'  => 'rows',
			'motion' => 'slide',
		),
		'5' => array(
			'label'  => __( 'List with figures', 'brand-market' ),
			'class'  => 'checks',
			'motion' => 'blur',
		),
	),
	'parts'      => array(
		'title'      => __( 'Heading', 'brand-market' ),
		'lead'       => __( 'Lead', 'brand-market' ),
		'media'      => __( 'Photo', 'brand-market' ),
		'card_icon'  => __( 'Card icon', 'brand-market' ),
		'card_title' => __( 'Card heading', 'brand-market' ),
		'list'       => __( 'Points', 'brand-market' ),
	),
	'item_parts' => array(
		'mark'   => __( 'Icon or number', 'brand-market' ),
		'name'   => __( 'Short name', 'brand-market' ),
		'text'   => __( 'Text', 'brand-market' ),
		'figure' => __( 'Figure', 'brand-market' ),
	),
	'only'       => array(
		'image'             => array( '1', '2' ),
		'icon'              => array( '1' ),
		'card_title'        => array( '1' ),
		'items.icon'        => array( '2', '4' ),
		'items.figure'      => array( '5' ),
		'items.group'       => array( '4' ),
		'items.image'       => array( '4' ),
		'parts.media'       => array( '1', '2', '4' ),
		'parts.card_icon'   => array( '1' ),
		'parts.card_title'  => array( '1', '4' ),
		'item_parts.name'   => array( '2', '3', '4', '5' ),
		'item_parts.figure' => array( '5' ),
		'image_side'        => array( '1', '4' ),
		'image_size'        => array( '1', '2', '4' ),
		'cards_bg'          => array( '1', '3' ),
		'cards_ink'         => array( '1', '3' ),
	),
);
