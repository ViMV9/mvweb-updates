<?php
/**
 * Block description: before and after.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Classic slider', 'brand-market' ),
			'class'  => 'classic',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Two photos side by side', 'brand-market' ),
			'class'  => 'duo',
			'motion' => 'slide',
		),
		'3' => array(
			'label'  => __( 'Card with facts', 'brand-market' ),
			'class'  => 'card',
			'motion' => 'scale',
		),
		'4' => array(
			'label'  => __( 'Round lens', 'brand-market' ),
			'class'  => 'lens',
			'motion' => 'blur',
		),
		'5' => array(
			'label'  => __( 'Grid of small pairs', 'brand-market' ),
			'class'  => 'tiles',
			'motion' => 'wipe',
		),
	),
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'lead'   => __( 'Text under the heading', 'brand-market' ),
		'list'   => __( 'Jobs', 'brand-market' ),
		'button' => __( 'Button', 'brand-market' ),
	),
	'item_parts' => array(
		'labels' => __( 'Marks on the photos', 'brand-market' ),
		'title'  => __( 'Caption', 'brand-market' ),
		'text'   => __( 'Description', 'brand-market' ),
		'facts'  => __( 'Facts (card view)', 'brand-market' ),
	),
	'only'       => array(
		'pairs.facts'      => array( '3' ),
		'item_parts.facts' => array( '3' ),
	),
);
