<?php
/**
 * Block description: the latest posts of the blog.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Three cards', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Large and a list', 'brand-market' ),
			'class'  => 'feature',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Horizontal ribbon', 'brand-market' ),
			'class'  => 'ribbon',
			'motion' => 'slide',
		),
		'4' => array(
			'label'  => __( 'Magazine grid', 'brand-market' ),
			'class'  => 'magazine',
			'motion' => 'blur',
		),
		'5' => array(
			'label'  => __( 'List with dates', 'brand-market' ),
			'class'  => 'dates',
			'motion' => 'wipe',
		),
	),
	'parts' => array(
		'kicker' => __( 'Line above the heading', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'lead'   => __( 'Text under the heading', 'brand-market' ),
		'more'   => __( 'Link to all posts', 'brand-market' ),
		'list'   => __( 'Posts', 'brand-market' ),
	),
);
