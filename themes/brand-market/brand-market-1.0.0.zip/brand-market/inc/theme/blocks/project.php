<?php
/**
 * Block description: one work, wide.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Gallery and card', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Photo and table', 'brand-market' ),
			'class'  => 'table',
			'motion' => 'slide',
		),
		'3' => array(
			'label'  => __( 'Cover with plates', 'brand-market' ),
			'class'  => 'cover',
			'motion' => 'scale',
		),
		'4' => array(
			'label'  => __( 'Ribbon of steps', 'brand-market' ),
			'class'  => 'steps',
			'motion' => 'wipe',
		),
		'5' => array(
			'label'  => __( 'Large figures', 'brand-market' ),
			'class'  => 'numbers',
			'motion' => 'blur',
		),
	),
	'parts' => array(
		'gallery' => __( 'Pictures', 'brand-market' ),
		'eyebrow' => __( 'Line above the heading', 'brand-market' ),
		'name'    => __( 'Heading', 'brand-market' ),
		'text'    => __( 'Description', 'brand-market' ),
		'facts'   => __( 'Facts', 'brand-market' ),
		'prices'  => __( 'Prices', 'brand-market' ),
		'link'    => __( 'Link', 'brand-market' ),
	),
);
