<?php
/**
 * Block description: the team.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Card grid', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Round portraits', 'brand-market' ),
			'class'  => 'round',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Horizontal cards', 'brand-market' ),
			'class'  => 'wide',
			'motion' => 'slide',
		),
		'4' => array(
			'label'  => __( 'Leader large', 'brand-market' ),
			'class'  => 'lead',
			'motion' => 'wipe',
		),
		'5' => array(
			'label'  => __( 'Ribbon of portraits', 'brand-market' ),
			'class'  => 'ribbon',
			'motion' => 'blur',
		),
	),
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'lead'   => __( 'Text under the heading', 'brand-market' ),
		'list'   => __( 'People', 'brand-market' ),
	),
	'item_parts' => array(
		'photo'  => __( 'Photo', 'brand-market' ),
		'role'   => __( 'Position', 'brand-market' ),
		'bio'    => __( 'About', 'brand-market' ),
		'button' => __( 'Booking button', 'brand-market' ),
	),
	'only'       => array(
		'lead_label'     => array( '4' ),
		'item_parts.bio' => array( '3', '4' ),
	),
);
