<?php
/**
 * Block description: first screen as a slider of offers.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Fan of cards', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Photo with a plate', 'brand-market' ),
			'class'  => 'plate',
			'motion' => 'wipe',
		),
		'3' => array(
			'label'  => __( 'Showcase with mini cards', 'brand-market' ),
			'class'  => 'showcase',
			'motion' => 'slide',
		),
		'4' => array(
			'label'  => __( 'Item on a circle', 'brand-market' ),
			'class'  => 'circle',
			'motion' => 'scale',
		),
		'5' => array(
			'label'  => __( 'Running ribbon', 'brand-market' ),
			'class'  => 'ribbon',
			'motion' => 'blur',
		),
	),
	'parts'      => array(
		'arrows' => __( 'Arrows', 'brand-market' ),
		'dots'   => __( 'Dots', 'brand-market' ),
		'pause'  => __( 'Pause button', 'brand-market' ),
	),
	'item_parts' => array(
		'kicker'   => __( 'Line above the heading', 'brand-market' ),
		'title'    => __( 'Heading', 'brand-market' ),
		'lead'     => __( 'Lead', 'brand-market' ),
		'facts'    => __( 'Facts', 'brand-market' ),
		'actions'  => __( 'Button and price', 'brand-market' ),
		'pics'     => __( 'Pictures', 'brand-market' ),
		'products' => __( 'Mini cards of items', 'brand-market' ),
	),
	'only'       => array(
		'slides.facts'        => array( '1', '3', '4' ),
		'slides.image_1'      => array( '1' ),
		'slides.image_2'      => array( '1', '3', '4' ),
		'slides.image_3'      => array( '1', '4' ),
		'slides.photo'        => array( '2' ),
		'slides.products'     => array( '3', '5' ),
		'item_parts.facts'    => array( '1', '3', '4' ),
		'item_parts.pics'     => array( '1', '2', '3', '4' ),
		'item_parts.products' => array( '3', '5' ),
	),
);
