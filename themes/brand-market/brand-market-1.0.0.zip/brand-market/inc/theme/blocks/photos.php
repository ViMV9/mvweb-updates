<?php
/**
 * Block description: photographs with captions.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Mosaic with captions', 'brand-market' ),
			'class'  => '',
			'motion' => 'scale',
		),
		'2' => array(
			'label'  => __( 'Columns', 'brand-market' ),
			'class'  => 'masonry',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Stage with a strip', 'brand-market' ),
			'class'  => 'stage',
			'motion' => 'blur',
		),
		'4' => array(
			'label'  => __( 'Strips with parallax', 'brand-market' ),
			'class'  => 'strips',
			'motion' => 'wipe',
		),
		'5' => array(
			'label'  => __( 'Two reels', 'brand-market' ),
			'class'  => 'reel',
			'motion' => 'slide',
		),
	),
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'lead'   => __( 'Text under the heading', 'brand-market' ),
		'list'   => __( 'Photographs', 'brand-market' ),
		'thumbs' => __( 'Strip of thumbnails', 'brand-market' ),
	),
	'item_parts' => array(
		'caption' => __( 'Caption', 'brand-market' ),
	),
	'only'       => array(
		'items.url'    => array( '1', '2', '4', '5' ),
		'items.size'   => array( '1', '2' ),
		'parts.thumbs' => array( '3' ),
	),
);
