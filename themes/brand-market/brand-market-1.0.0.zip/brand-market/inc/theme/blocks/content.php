<?php
/**
 * Block description: text block.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Text column', 'brand-market' ),
			'class'  => 'column',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Photo and card', 'brand-market' ),
			'class'  => 'float',
			'motion' => 'slide',
		),
		'3' => array(
			'label'  => __( 'Photo and plate', 'brand-market' ),
			'class'  => 'cover',
			'motion' => 'blur',
		),
		'4' => array(
			'label'  => __( 'Drop cap and quote', 'brand-market' ),
			'class'  => 'letter',
			'motion' => 'fade',
		),
		'5' => array(
			'label'  => __( 'Photo mosaic', 'brand-market' ),
			'class'  => 'mosaic',
			'motion' => 'wipe',
		),
	),
	'parts' => array(
		'title'   => __( 'Heading', 'brand-market' ),
		'text'    => __( 'Text', 'brand-market' ),
		'image'   => __( 'Picture', 'brand-market' ),
		'image_2' => __( 'Second picture', 'brand-market' ),
		'badge'   => __( 'Badge over the picture', 'brand-market' ),
		'quote'   => __( 'Quote', 'brand-market' ),
		'button'  => __( 'Button', 'brand-market' ),
	),
	'only'  => array(
		'image'         => array( '2', '3', '5' ),
		'image_2'       => array( '5' ),
		'badge_icon'    => array( '2' ),
		'badge_title'   => array( '2' ),
		'badge_text'    => array( '2' ),
		'quote'         => array( '4' ),
		'quote_cite'    => array( '4' ),
		'parts.image'   => array( '2', '3', '5' ),
		'parts.image_2' => array( '5' ),
		'parts.badge'   => array( '2' ),
		'parts.quote'   => array( '4' ),
		'image_side'    => array( '2', '5' ),
		'image_size'    => array( '2', '3', '5' ),
	),
);
