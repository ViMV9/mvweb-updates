<?php
/**
 * Block description: a promo banner and a row of products of one department.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Banner on the left', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Banner as a header', 'brand-market' ),
			'class'  => 'band',
			'motion' => 'wipe',
		),
		'3' => array(
			'label'  => __( 'Row overlapping the banner', 'brand-market' ),
			'class'  => 'overlap',
			'motion' => 'scale',
		),
		'4' => array(
			'label'  => __( 'Banner inside the row', 'brand-market' ),
			'class'  => 'lead',
			'motion' => 'slide',
		),
		'5' => array(
			'label'  => __( 'Compact strip', 'brand-market' ),
			'class'  => 'strip',
			'motion' => 'blur',
		),
	),
	'parts' => array(
		'kicker' => __( 'Line above the heading', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'desc'   => __( 'Text of the banner', 'brand-market' ),
		'chips'  => __( 'Links to subsections', 'brand-market' ),
		'button' => __( 'Button of the banner', 'brand-market' ),
		'pics'   => __( 'Pictures of the banner', 'brand-market' ),
		'cards'  => __( 'Row of products', 'brand-market' ),
		'arrows' => __( 'Arrows of the row', 'brand-market' ),
	),
	'only'  => array(
		'text'        => array( '1', '2', '3', '4' ),
		'chips'       => array( '1', '2', '3', '5' ),
		'image_2'     => array( '1', '2', '3', '4' ),
		'image_3'     => array( '2' ),
		'parts.desc'  => array( '1', '2', '3', '4' ),
		'parts.chips' => array( '1', '2', '3', '5' ),
	),
);
