<?php
/**
 * Block description: what the company is good at.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Lines and icons', 'brand-market' ),
			'class'  => 'plain',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Cards', 'brand-market' ),
			'class'  => 'cards',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Large numbers', 'brand-market' ),
			'class'  => 'numbered',
			'motion' => 'wipe',
		),
		'4' => array(
			'label'  => __( 'Strip of facts', 'brand-market' ),
			'class'  => 'strip',
			'motion' => 'slide',
		),
		'5' => array(
			'label'  => __( 'Heading on the left', 'brand-market' ),
			'class'  => 'aside',
			'motion' => 'blur',
		),
	),
	'parts'      => array(
		'kicker' => __( 'Kicker', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'lead'   => __( 'Lead', 'brand-market' ),
		'image'  => __( 'Picture', 'brand-market' ),
		'list'   => __( 'Blocks', 'brand-market' ),
	),
	'item_parts' => array(
		'icon'  => __( 'Icon', 'brand-market' ),
		'num'   => __( 'Number', 'brand-market' ),
		'title' => __( 'Heading', 'brand-market' ),
		'text'  => __( 'Text', 'brand-market' ),
	),
	'only'       => array(
		'image'           => array( '1', '5' ),
		'blocks.icon'     => array( '1', '2', '4', '5' ),
		'blocks.text'     => array( '1', '2', '3', '5' ),
		'parts.image'     => array( '1', '5' ),
		'item_parts.icon' => array( '1', '2', '4', '5' ),
		'item_parts.num'  => array( '3' ),
		'item_parts.text' => array( '1', '2', '3', '5' ),
		'image_side'      => array( '5' ),
		'image_size'      => array( '1', '5' ),
		'cards_bg'        => array( '2' ),
		'cards_ink'       => array( '2' ),
		'cards_icon'      => array( '2' ),
	),
);
