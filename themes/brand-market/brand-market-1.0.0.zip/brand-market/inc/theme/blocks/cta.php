<?php
/**
 * Block description: a call to action.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Accent card', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Line with a rule', 'brand-market' ),
			'class'  => 'line',
			'motion' => 'slide',
		),
		'3' => array(
			'label'  => __( 'Photo and buttons', 'brand-market' ),
			'class'  => 'photo',
			'motion' => 'wipe',
		),
		'4' => array(
			'label'  => __( 'Large type and a ribbon', 'brand-market' ),
			'class'  => 'marquee',
			'motion' => 'blur',
		),
		'5' => array(
			'label'  => __( 'Two halves', 'brand-market' ),
			'class'  => 'duo',
			'motion' => 'scale',
		),
	),
	'parts' => array(
		'kicker' => __( 'Kicker', 'brand-market' ),
		'title'  => __( 'Heading', 'brand-market' ),
		'lead'   => __( 'Lead', 'brand-market' ),
		'button' => __( 'Button', 'brand-market' ),
		'phone'  => __( 'Phone', 'brand-market' ),
		'photo'  => __( 'Photo', 'brand-market' ),
		'ticker' => __( 'Ribbon', 'brand-market' ),
		'second' => __( 'Second half', 'brand-market' ),
	),
	'only'  => array(
		'icon'          => array( '5' ),
		'image'         => array( '3' ),
		'badge'         => array( '3' ),
		'ticker'        => array( '4' ),
		'second_icon'   => array( '5' ),
		'second_kicker' => array( '5' ),
		'second_title'  => array( '5' ),
		'second_text'   => array( '5' ),
		'second_button' => array( '5' ),
		'second_url'    => array( '5' ),
		'second_phone'  => array( '5' ),
		'parts.photo'   => array( '3' ),
		'parts.ticker'  => array( '4' ),
		'parts.second'  => array( '5' ),
		'image_side'    => array( '3' ),
		'image_size'    => array( '3' ),
	),
);
