<?php
/**
 * Block description: products of the catalogue in cards.
 *
 * The composition of a card is one for the whole site and is set in the
 * Customizer, so the block lists only its own parts.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Dense grid', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Scrolling row', 'brand-market' ),
			'class'  => 'rail',
			'motion' => 'slide',
		),
		'3' => array(
			'label'  => __( 'Large cards', 'brand-market' ),
			'class'  => 'large',
			'motion' => 'scale',
		),
		'4' => array(
			'label'  => __( 'Bento grid', 'brand-market' ),
			'class'  => 'bento',
			'motion' => 'blur',
		),
		'5' => array(
			'label'  => __( 'List as a table', 'brand-market' ),
			'class'  => 'list',
			'motion' => 'wipe',
		),
	),
	'parts' => array(
		'kicker'  => __( 'Line above the heading', 'brand-market' ),
		'title'   => __( 'Heading', 'brand-market' ),
		'lead'    => __( 'Lead', 'brand-market' ),
		'more'    => __( 'Link beside the heading', 'brand-market' ),
		'arrows'  => __( 'Arrows of the row', 'brand-market' ),
		'chips'   => __( 'Pills of departments', 'brand-market' ),
		'list'    => __( 'Cards', 'brand-market' ),
		'dots'    => __( 'Dots of the row', 'brand-market' ),
		'closing' => __( 'Closing block', 'brand-market' ),
	),
	'only'  => array(
		'parts.arrows' => array( '2' ),
		'parts.dots'   => array( '2' ),
	),
);
