<?php
/**
 * Block description: how the work is done, step by step.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views'      => array(
		'1' => array(
			'label'  => __( 'Cards with a photo', 'brand-market' ),
			'class'  => 'media',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Cards with numbers', 'brand-market' ),
			'class'  => 'compact',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Timeline', 'brand-market' ),
			'class'  => 'timeline',
			'motion' => 'fade',
		),
		'4' => array(
			'label'  => __( 'Stairs', 'brand-market' ),
			'class'  => 'stairs',
			'motion' => 'slide',
		),
		'5' => array(
			'label'  => __( 'Large numbers', 'brand-market' ),
			'class'  => 'numbers',
			'motion' => 'wipe',
		),
	),
	'parts'      => array(
		'title' => __( 'Heading', 'brand-market' ),
		'lead'  => __( 'Lead', 'brand-market' ),
		'list'  => __( 'Steps', 'brand-market' ),
	),
	'item_parts' => array(
		'image' => __( 'Photo', 'brand-market' ),
		'num'   => __( 'Number', 'brand-market' ),
		'title' => __( 'Heading', 'brand-market' ),
		'text'  => __( 'Text', 'brand-market' ),
	),
	'only'       => array(
		'items.image'      => array( '1' ),
		'item_parts.image' => array( '1' ),
	),
);
