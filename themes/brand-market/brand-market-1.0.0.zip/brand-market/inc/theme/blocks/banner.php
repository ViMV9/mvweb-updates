<?php
/**
 * Block description: wide banner.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Photo with text', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Accent strip', 'brand-market' ),
			'class'  => 'strip',
			'motion' => 'slide',
		),
		'3' => array(
			'label'  => __( 'Card with a saving', 'brand-market' ),
			'class'  => 'deal',
			'motion' => 'scale',
		),
		'4' => array(
			'label'  => __( 'Photo and text', 'brand-market' ),
			'class'  => 'split',
			'motion' => 'wipe',
		),
		'5' => array(
			'label'  => __( 'Running line', 'brand-market' ),
			'class'  => 'ticker',
			'motion' => 'fade',
		),
	),
	'parts' => array(
		'tag'     => __( 'Label', 'brand-market' ),
		'title'   => __( 'Heading', 'brand-market' ),
		'lead'    => __( 'Lead', 'brand-market' ),
		'prices'  => __( 'Prices', 'brand-market' ),
		'button'  => __( 'Button', 'brand-market' ),
		'until'   => __( 'Last day of the offer', 'brand-market' ),
		'sale'    => __( 'Saving', 'brand-market' ),
		'sticker' => __( 'Sticker', 'brand-market' ),
		'reel'    => __( 'Running line', 'brand-market' ),
	),
	'only'  => array(
		'image'         => array( '1', '2', '3', '4' ),
		'tag'           => array( '4', '5' ),
		'text'          => array( '1', '2', '3', '4' ),
		'price_new'     => array( '1', '3', '5' ),
		'price_old'     => array( '1', '3', '5' ),
		'sale_label'    => array( '3' ),
		'sticker_num'   => array( '2' ),
		'sticker_text'  => array( '2' ),
		'ticker'        => array( '5' ),
		'parts.tag'     => array( '4', '5' ),
		'parts.title'   => array( '1', '2', '3', '4' ),
		'parts.lead'    => array( '1', '2', '3', '4' ),
		'parts.prices'  => array( '1', '3' ),
		'parts.until'   => array( '1', '3' ),
		'parts.sale'    => array( '3' ),
		'parts.sticker' => array( '2' ),
		'parts.reel'    => array( '5' ),
		'image_side'    => array( '2', '4' ),
		'image_size'    => array( '2', '3', '4' ),
	),
);
