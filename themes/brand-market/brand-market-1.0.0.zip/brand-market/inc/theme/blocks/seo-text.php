<?php
/**
 * Block description: long text for search.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Reading column', 'brand-market' ),
			'class'  => 'column',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Newspaper columns', 'brand-market' ),
			'class'  => 'paper',
			'motion' => 'blur',
		),
		'3' => array(
			'label'  => __( 'Sticky heading on the left', 'brand-market' ),
			'class'  => 'aside',
			'motion' => 'slide',
		),
		'4' => array(
			'label'  => __( 'Text on a card', 'brand-market' ),
			'class'  => 'card',
			'motion' => 'scale',
		),
		'5' => array(
			'label'  => __( 'Centred with a lead', 'brand-market' ),
			'class'  => 'center',
			'motion' => 'wipe',
		),
	),
	'parts' => array(
		'kicker'  => __( 'Kicker', 'brand-market' ),
		'title'   => __( 'Heading', 'brand-market' ),
		'text'    => __( 'Text', 'brand-market' ),
		'spoiler' => __( 'Spoiler button', 'brand-market' ),
	),
);
