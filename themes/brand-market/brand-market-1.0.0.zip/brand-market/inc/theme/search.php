<?php
/**
 * Search field of the header and the search panel under it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_search_field' ) ) {
	/**
	 * The search field of the chosen engine.
	 *
	 * @since 0.1.0
	 *
	 * @param string $variant Where the field stands: '' for the main row, 'nav' for the menu row, 'pop' for the panel.
	 *
	 * @return string Escaped markup.
	 */
	function mvweb_theme_search_field( $variant = '' ) {
		if ( 'smart' === mvweb_core_search_engine() ) {
			return '<div class="mvweb-t-el-search-form mvweb-t-el-search-form--smart">' . preg_replace( '/\s?mvweb-ss--(?:icon|word)-(?:desktop|mobile)/', '', mvweb_ss_get_search_bar() ) . '</div>';
		}

		$id          = wp_unique_id( 'mvweb-t-search-' );
		$placeholder = trim( (string) get_theme_mod( 'mvweb_search_placeholder', '' ) );
		$class       = 'mvweb-t-el-search-form' . ( '' === $variant ? '' : ' mvweb-t-el-search-form--' . sanitize_html_class( $variant ) );

		ob_start();
		?>
		<form class="<?php echo esc_attr( $class ); ?>" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label class="screen-reader-text" for="<?php echo esc_attr( $id ); ?>"><?php esc_html_e( 'Search the site', 'brand-market' ); ?></label>
			<input class="mvweb-t-el-search-form__input" id="<?php echo esc_attr( $id ); ?>" type="search" name="s" value="<?php echo esc_attr( get_search_query( false ) ); ?>"<?php echo '' === $placeholder ? '' : ' placeholder="' . esc_attr( $placeholder ) . '"'; ?> autocomplete="off">
			<button class="mvweb-t-round mvweb-t-round--accent mvweb-t-el-search-form__submit" type="submit" title="<?php esc_attr_e( 'Search', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'search', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Search', 'brand-market' ); ?></span>
			</button>
		</form>
		<?php
		return trim( (string) ob_get_clean() );
	}
}

if ( ! function_exists( 'mvweb_theme_search_panel' ) ) {
	/**
	 * The row that the magnifier opens under the header.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_search_panel() {
		if ( ! ( mvweb_core_zone_has( 'header-main', 'actions' ) && mvweb_core_zone_has( 'header-actions', 'search' ) ) && ! mvweb_core_zone_has( 'header-nav', 'search' ) ) {
			return;
		}
		?>
		<div class="mvweb-t-header__search-pop" id="mvweb-t-search-panel" data-search-panel hidden>
			<div class="mvweb-t-container mvweb-t-header__search-pop-row">
				<?php echo mvweb_theme_search_field( 'pop' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts, or by the renderer of the plugin. ?>
				<button class="mvweb-t-round" type="button" data-search-close title="<?php esc_attr_e( 'Close search', 'brand-market' ); ?>">
					<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<span class="screen-reader-text"><?php esc_html_e( 'Close search', 'brand-market' ); ?></span>
				</button>
			</div>
		</div>
		<?php
	}
}
