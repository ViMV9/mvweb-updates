<?php
/**
 * Icons: SVG sprites of the theme and the icon helper.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_icon' ) ) {
	/**
	 * Build an inline icon reference.
	 *
	 * @since 0.1.0
	 *
	 * @param string $name Icon id without the "mvweb-t-icon-" prefix, e.g. phone.
	 * @param array  $args Optional. 'class' — extra CSS classes, 'label' — an
	 *                     accessible name; without it the icon is hidden from
	 *                     assistive technology. Size comes from CSS.
	 *
	 * @return string Icon HTML.
	 */
	function mvweb_theme_icon( $name, $args = array() ) {
		$name = preg_replace( '/[^a-z0-9\-]/', '', strtolower( (string) $name ) );

		if ( '' === $name ) {
			return '';
		}

		$args = wp_parse_args(
			$args,
			array(
				'class' => '',
				'label' => '',
			)
		);

		$a11y = '' !== $args['label']
			? sprintf( ' role="img" aria-label="%s"', esc_attr( $args['label'] ) )
			: ' aria-hidden="true" focusable="false"';

		return mvweb_theme_extra_icon_symbol( $name ) . sprintf(
			'<svg class="%1$s"%2$s><use href="#mvweb-t-icon-%3$s"></use></svg>',
			esc_attr( trim( 'mvweb-t-icon ' . $args['class'] ) ),
			$a11y,
			esc_attr( $name )
		);
	}
}

if ( ! function_exists( 'mvweb_theme_extra_icons' ) ) {
	/**
	 * Symbols of the extra sprite, keyed by icon name.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Name => <symbol> markup.
	 */
	function mvweb_theme_extra_icons() {
		static $symbols = null;

		if ( null !== $symbols ) {
			return $symbols;
		}

		$symbols = array();

		foreach ( array_unique( array( get_template_directory(), get_stylesheet_directory() ) ) as $directory ) {
			$path = $directory . '/assets/icons/sprite-extra.svg';

			if ( is_readable( $path ) && preg_match_all( '#<symbol id="mvweb-t-icon-([a-z0-9-]+)".*?</symbol>#s', (string) file_get_contents( $path ), $found, PREG_SET_ORDER ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local SVG shipped with the theme.
				foreach ( $found as $match ) {
					$symbols[ $match[1] ] = $match[0];
				}
			}
		}

		return $symbols;
	}
}

if ( ! function_exists( 'mvweb_theme_extra_icon_symbol' ) ) {
	/**
	 * The symbol of an extra icon, the first time the page asks for it.
	 *
	 * @since 0.1.0
	 *
	 * @param string $name Icon name.
	 *
	 * @return string A hidden <svg> with the symbol, or an empty string.
	 */
	function mvweb_theme_extra_icon_symbol( $name ) {
		static $printed = array();

		$symbols = mvweb_theme_extra_icons();

		if ( ! isset( $symbols[ $name ] ) || isset( $printed[ $name ] ) ) {
			return '';
		}

		$printed[ $name ] = true;

		return '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" style="display:none">' . $symbols[ $name ] . '</svg>';
	}
}

if ( ! function_exists( 'mvweb_theme_print_icon_sprite' ) ) {
	/**
	 * Inline the icon sprite so <use> can resolve it.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_print_icon_sprite() {
		foreach ( array_unique( array( get_template_directory(), get_stylesheet_directory() ) ) as $directory ) {
			$path = $directory . '/assets/icons/sprite.svg';

			if ( is_readable( $path ) ) {
				echo file_get_contents( $path ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Trusted local SVG sprite shipped with the theme.
			}
		}
	}
}
add_action( 'wp_body_open', 'mvweb_theme_print_icon_sprite' );
