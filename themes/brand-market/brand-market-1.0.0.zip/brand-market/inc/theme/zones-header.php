<?php
/**
 * The header zones: their names, hints and elements, and the default order of each of the three views.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_header_default_order' ) ) {
	/**
	 * The elements of the header zones in the order of the chosen view.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $order Element slugs.
	 * @param string   $zone  Zone slug.
	 *
	 * @return string[]
	 */
	function mvweb_theme_header_default_order( $order, $zone ) {
		$common = array(
			'header-topbar'          => array( 'city', 'notice', 'menu-top', 'scheme' ),
			'header-drawer-contacts' => array( 'phone', 'address', 'schedule' ),
			'header-drawer-nav'      => array( 'menu-primary' ),
			'header-drawer-foot'     => array( 'socials', 'scheme' ),
		);

		$views = array(
			'simple'   => array(
				'header-main'    => array( 'logo', 'search-form', 'actions' ),
				'header-actions' => array( 'phone', 'schedule', 'favorites', 'account', 'cart' ),
				'header-nav'     => array( 'catalog-button', 'menu-primary' ),
			),
			'extended' => array(
				'header-main'    => array( 'logo', 'actions' ),
				'header-actions' => array( 'address', 'phone', 'schedule' ),
				'header-nav'     => array( 'catalog-button', 'menu-primary', 'search-form', 'favorites', 'account', 'cart' ),
			),
			'compact'  => array(
				'header-main'    => array( 'logo', 'actions' ),
				'header-actions' => array( 'address', 'phone', 'schedule' ),
				'header-nav'     => array( 'catalog-button', 'menu-primary', 'search', 'favorites', 'account', 'cart' ),
			),
		);

		if ( isset( $common[ $zone ] ) ) {
			return $common[ $zone ];
		}

		$view = (string) get_theme_mod( 'mvweb_header_layout', 'simple' );
		$view = isset( $views[ $view ] ) ? $view : 'simple';

		return isset( $views[ $view ][ $zone ] ) ? $views[ $view ][ $zone ] : $order;
	}
}
add_filter( 'mvweb_core_zone_default_order', 'mvweb_theme_header_default_order', 10, 2 );

if ( ! function_exists( 'mvweb_theme_header_zone_texts' ) ) {
	/**
	 * The name and the hint of every header zone, in words of the owner.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,string>> Zone slug => name and hint.
	 */
	function mvweb_theme_header_zone_texts() {
		return array(
			'header-topbar'          => array(
				'label' => __( 'Strip above the header', 'brand-market' ),
				'hint'  => __( 'The thin coloured strip at the very top of the page: announcement, city, extra menu, colour scheme switch. The tick hides the switch here only; to remove it from the whole site choose one scheme in “Design → Colours → Colour scheme”.', 'brand-market' ),
			),
			'header-main'            => array(
				'label' => __( 'Header row', 'brand-market' ),
				'hint'  => __( 'The white row with the logo. Arrange its three parts: logo, search and “Other items” (the icons and contacts on the right).', 'brand-market' ),
			),
			'header-actions'         => array(
				'label' => __( 'Header row: other items', 'brand-market' ),
				'hint'  => __( 'What stands in the “Other items” part: icons, cart, phone, opening hours.', 'brand-market' ),
			),
			'header-nav'             => array(
				'label' => __( 'Main menu', 'brand-market' ),
				'hint'  => __( 'The strip under the header: the “Catalogue” button, the main menu, search and icons. “Search (line)” is a field, “Search (icon)” is a magnifier.', 'brand-market' ),
			),
			'header-drawer-contacts' => array(
				'label' => __( 'Mobile menu: contacts', 'brand-market' ),
				'hint'  => __( 'Phone, address, opening hours, messengers in the menu that opens on a phone. Above or below the menu items: see “Where the contacts stand”.', 'brand-market' ),
			),
			'header-drawer-nav'      => array(
				'label' => __( 'Mobile menu: sections', 'brand-market' ),
				'hint'  => __( 'The menus of the site in the mobile menu.', 'brand-market' ),
			),
			'header-drawer-foot'     => array(
				'label' => __( 'Mobile menu: bottom', 'brand-market' ),
				'hint'  => __( 'The bottom of the mobile menu: social networks and the colour scheme switch. The tick hides the switch here only; to remove it from the whole site choose one scheme in “Design → Colours → Colour scheme”.', 'brand-market' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_header_zone_labels' ) ) {
	/**
	 * The names of the header zones.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $zones Zone slug => label.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_header_zone_labels( $zones ) {
		foreach ( mvweb_theme_header_zone_texts() as $zone => $texts ) {
			if ( isset( $zones[ $zone ] ) ) {
				$zones[ $zone ] = $texts['label'];
			}
		}

		return $zones;
	}
}
add_filter( 'mvweb_core_zones', 'mvweb_theme_header_zone_labels', 20 );

if ( ! function_exists( 'mvweb_theme_header_zone_hints' ) ) {
	/**
	 * The hints under the header zones in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $hints Zone slug => hint.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_header_zone_hints( $hints ) {
		foreach ( mvweb_theme_header_zone_texts() as $zone => $texts ) {
			$hints[ $zone ] = $texts['hint'];
		}

		return $hints;
	}
}
add_filter( 'mvweb_core_zone_hints', 'mvweb_theme_header_zone_hints' );

if ( ! function_exists( 'mvweb_theme_header_zone_elements' ) ) {
	/**
	 * The elements of the header zones: three parts of the header row, the other items one by one, and plain names.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $elements Element slug => label.
	 * @param string               $zone     Zone slug.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_header_zone_elements( $elements, $zone ) {
		if ( 'header-main' === $zone ) {
			return array(
				'logo'        => __( 'Logo', 'brand-market' ),
				'search-form' => __( 'Search', 'brand-market' ),
				'actions'     => __( 'Other items', 'brand-market' ),
			);
		}

		if ( 'header-actions' === $zone ) {
			$elements += array( 'address' => '' );
		}

		unset( $elements['burger'], $elements['menu-button'] );

		$labels = array(
			'phone'       => __( 'Phone', 'brand-market' ),
			'address'     => __( 'Address', 'brand-market' ),
			'schedule'    => __( 'Opening hours', 'brand-market' ),
			'scheme'      => __( 'Light and dark scheme switch', 'brand-market' ),
			'menu-top'    => __( 'Top menu', 'brand-market' ),
			'cta'         => __( 'Request button (own link)', 'brand-market' ),
			'search'      => __( 'Search (icon)', 'brand-market' ),
			'search-form' => __( 'Search (line)', 'brand-market' ),
			'notice'      => __( 'Announcement (line of text)', 'brand-market' ),
		);

		return array_merge( $elements, array_intersect_key( $labels, $elements ) );
	}
}
add_filter( 'mvweb_core_zone_elements', 'mvweb_theme_header_zone_elements', 20, 2 );

if ( ! function_exists( 'mvweb_theme_header_row_compat' ) ) {
	/**
	 * A header row saved before it had the "Other items" part.
	 *
	 * The contacts and the menu leave the row: the part "Other items" takes the
	 * place of the first of them, or the end of the row, and the contacts go to
	 * the start of "Header row: other items".
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Saved order, a JSON list of element slugs.
	 *
	 * @return mixed
	 */
	function mvweb_theme_header_row_compat( $value ) {
		$mods = get_theme_mods();
		$main = isset( $mods['mvweb_zone_header_main'] ) ? json_decode( (string) $mods['mvweb_zone_header_main'], true ) : null;

		if ( ! empty( $mods['mvweb_header_row'] ) || ! is_array( $main ) || in_array( 'actions', $main, true ) ) {
			return $value;
		}

		$gone = array( 'contacts-block', 'phone', 'address', 'schedule', 'menu-primary' );

		if ( 'theme_mod_mvweb_zone_header_main' === current_filter() ) {
			$row = array();

			foreach ( $main as $slug ) {
				if ( ! in_array( $slug, $gone, true ) ) {
					$row[] = $slug;
				} elseif ( ! in_array( 'actions', $row, true ) ) {
					$row[] = 'actions';
				}
			}

			return wp_json_encode( in_array( 'actions', $row, true ) ? $row : array_merge( $row, array( 'actions' ) ) );
		}

		$items = json_decode( (string) $value, true );
		$moved = array_intersect( $main, array_slice( $gone, 0, 4 ) );

		if ( ! is_array( $items ) ) {
			$items = array_diff( mvweb_core_zone_default_order( 'header-actions' ), $moved ? array_slice( $gone, 0, 4 ) : array() );
		}

		$moved = array_diff( $moved, $items );

		return wp_json_encode( array_values( array_merge( $moved, $items ) ) );
	}
}
add_filter( 'theme_mod_mvweb_zone_header_main', 'mvweb_theme_header_row_compat' );
add_filter( 'theme_mod_mvweb_zone_header_actions', 'mvweb_theme_header_row_compat' );

if ( ! function_exists( 'mvweb_theme_header_contacts_split' ) ) {
	/**
	 * The block "Phones, addresses and hours" is gone: a saved order with it gets
	 * the address, the phone and the opening hours in its place.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Saved order, a JSON list of element slugs.
	 *
	 * @return mixed
	 */
	function mvweb_theme_header_contacts_split( $value ) {
		$items = is_string( $value ) ? json_decode( $value, true ) : null;

		if ( ! is_array( $items ) || ! in_array( 'contacts-block', $items, true ) ) {
			return $value;
		}

		$row = array();

		foreach ( array_filter( $items, 'is_string' ) as $slug ) {
			$row = array_merge( $row, 'contacts-block' === $slug ? array( 'address', 'phone', 'schedule' ) : array( $slug ) );
		}

		return wp_json_encode( array_values( array_unique( $row ) ) );
	}
}
add_filter( 'theme_mod_mvweb_zone_header_actions', 'mvweb_theme_header_contacts_split', 20 );

if ( ! function_exists( 'mvweb_theme_header_row_save' ) ) {
	/**
	 * When the Customizer opens, the header row read the new way is saved, so the
	 * owner can hide "Other items" and every element without the old order coming back.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_header_row_save() {
		if ( get_theme_mod( 'mvweb_header_row' ) ) {
			return;
		}

		$values = array(
			'mvweb_zone_header_main'    => get_theme_mod( 'mvweb_zone_header_main', '' ),
			'mvweb_zone_header_actions' => get_theme_mod( 'mvweb_zone_header_actions', '' ),
		);

		foreach ( array_filter( $values ) as $name => $value ) {
			set_theme_mod( $name, $value );
		}

		set_theme_mod( 'mvweb_header_row', 1 );
	}
}
add_action( 'customize_register', 'mvweb_theme_header_row_save', 1 );
