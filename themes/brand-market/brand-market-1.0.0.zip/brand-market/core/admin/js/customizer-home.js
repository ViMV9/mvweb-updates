/*
 * Homepage panel: which blocks are on the page.
 *
 * A section of a block that is not in "Blocks of the homepage" gets a "hidden"
 * mark and a paler title, and the order section counts what is shown. It
 * reads the same setting the page is built from, so the marks follow every
 * tick in the list without a reload.
 */
( function ( $, api ) {
	'use strict';

	var data = window.mvwebCoreHome || {};
	var setting = 'mvweb_home_order';

	function sectionId( type ) {
		return 'hero' === type ? 'mvweb_cz_home_hero' : 'mvweb_cz_home_' + type.replace( /-/g, '_' );
	}

	function shown() {
		var value = [];

		try {
			value = JSON.parse( api( setting ).get() || '[]' );
		} catch ( e ) {
			value = [];
		}

		return Array.isArray( value ) ? value : [];
	}

	function mark( section, text, className ) {
		var trigger = section.headContainer.find( '.accordion-trigger' ).first();
		var badge = trigger.find( '.mvweb-core-cz-badge' );

		if ( ! text ) {
			badge.remove();
			return;
		}

		if ( ! badge.length ) {
			badge = $( '<span></span>' ).appendTo( trigger );
		}

		badge.attr( 'class', 'mvweb-core-cz-badge ' + ( className || '' ) ).text( text );
	}

	function apply() {
		var on = shown();
		var types = data.types || [];
		var count = 0;

		types.forEach( function ( type ) {
			var section = api.section( sectionId( type ) );
			var visible = -1 !== on.indexOf( type );

			if ( visible ) {
				count++;
			}

			if ( section ) {
				section.headContainer.toggleClass( 'mvweb-core-cz-off', ! visible );
				mark( section, visible ? '' : data.hidden );
			}
		} );

	}

	function followPages() {
		Object.keys( data.pages || {} ).forEach( function ( id ) {
			api.section( id, function ( section ) {
				section.expanded.bind( function ( open ) {
					if ( open && api.previewer.previewUrl() !== data.pages[ id ] ) {
						api.previewer.previewUrl.set( data.pages[ id ] );
					}
				} );
			} );
		} );
	}

	api.bind( 'ready', function () {
		followPages();

		api( setting, function ( value ) {
			value.bind( apply );
			apply();
		} );
	} );
} )( jQuery, wp.customize );
