( function () {
	"use strict";

	const text = window.mvwebCoreContrastText || {};

	function normalize( hex ) {
		const value = String( hex || "" ).toLowerCase();

		if ( /^#[0-9a-f]{3}$/.test( value ) ) {
			return "#" + value[ 1 ] + value[ 1 ] + value[ 2 ] + value[ 2 ] + value[ 3 ] + value[ 3 ];
		}

		return /^#[0-9a-f]{6}$/.test( value ) ? value : "";
	}

	function channel( value ) {
		const v = value / 255;

		return v <= 0.03928 ? v / 12.92 : Math.pow( ( v + 0.055 ) / 1.055, 2.4 );
	}

	function luminance( hex ) {
		const n = parseInt( hex.slice( 1 ), 16 );

		return 0.2126 * channel( ( n >> 16 ) & 255 ) + 0.7152 * channel( ( n >> 8 ) & 255 ) + 0.0722 * channel( n & 255 );
	}

	function ratio( a, b ) {
		const one = normalize( a );
		const two = normalize( b );

		if ( ! one || ! two ) {
			return 0;
		}

		const l1 = luminance( one );
		const l2 = luminance( two );

		return ( Math.max( l1, l2 ) + 0.05 ) / ( Math.min( l1, l2 ) + 0.05 );
	}

	function warning( a, b ) {
		const value = ratio( a, b );

		return value && value < 4.5 ? String( text.low || "" ) + " (" + value.toFixed( 1 ) + ":1)" : "";
	}

	window.mvwebCoreContrast = { normalize: normalize, ratio: ratio, warning: warning, text: text };
}() );
