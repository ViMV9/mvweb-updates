( function ( api ) {
	"use strict";

	const data = window.mvwebCoreLook || {};
	const contrast = window.mvwebCoreContrast;

	if ( ! contrast ) {
		return;
	}

	( data.pairs || [] ).forEach( function ( pair ) {
		const code = "mvweb-contrast";

		function check() {
			api.control( pair.ink, function ( control ) {
				const message = contrast.warning( api( pair.bg ).get(), api( pair.ink ).get() );

				control.notifications.remove( code );

				if ( message ) {
					control.notifications.add( new api.Notification( code, { type: "warning", message: message } ) );
				}
			} );
		}

		api( pair.bg, pair.ink, function ( bg, ink ) {
			bg.bind( check );
			ink.bind( check );
			check();
		} );
	} );
}( wp.customize ) );
