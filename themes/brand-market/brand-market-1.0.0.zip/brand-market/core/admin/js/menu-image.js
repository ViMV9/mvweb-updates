( function () {
	"use strict";

	function setup( box ) {
		if ( box.dataset.menuImageReady === "1" ) {
			return;
		}

		box.dataset.menuImageReady = "1";

		const field = box.querySelector( "[data-menu-image-value]" );
		const preview = box.querySelector( ".mvweb-core-menu-image__preview" );
		const pick = box.querySelector( "[data-menu-image-pick]" );
		const clear = box.querySelector( "[data-menu-image-clear]" );

		if ( ! field || ! pick || ! clear ) {
			return;
		}

		function show( url ) {
			preview.textContent = "";

			if ( ! url ) {
				return;
			}

			const image = document.createElement( "img" );
			image.src = url;
			image.alt = "";
			preview.appendChild( image );
		}

		pick.addEventListener( "click", function () {
			const frame = wp.media( { multiple: false, library: { type: "image" } } );

			frame.on( "select", function () {
				const item = frame.state().get( "selection" ).first().toJSON();

				field.value = item.id;
				show( item.sizes && item.sizes.thumbnail ? item.sizes.thumbnail.url : item.url );
			} );

			frame.open();
		} );

		clear.addEventListener( "click", function () {
			field.value = 0;
			show( "" );
		} );
	}

	function init() {
		document.querySelectorAll( "[data-menu-image]" ).forEach( setup );

		const list = document.getElementById( "menu-to-edit" );

		if ( ! list || list.dataset.menuImageWatched === "1" ) {
			return;
		}

		list.dataset.menuImageWatched = "1";

		new MutationObserver( function () {
			document.querySelectorAll( "[data-menu-image]" ).forEach( setup );
		} ).observe( list, { childList: true, subtree: true } );
	}

	if ( document.readyState === "loading" ) {
		document.addEventListener( "DOMContentLoaded", init );
	} else {
		init();
	}
} )();
