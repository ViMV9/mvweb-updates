( function () {
	"use strict";

	const data = window.mvwebCoreMarkets;
	const area = document.querySelector( 'textarea[name="_mvweb_markets"], textarea[name="mvweb_markets"]' );

	if ( ! data || ! area ) {
		return;
	}

	const box = document.createElement( "div" );
	const list = document.createElement( "div" );
	const add = document.createElement( "button" );

	function same( a, b ) {
		return a.toLowerCase() === b.toLowerCase();
	}

	function parse() {
		return area.value.split( "\n" ).map( ( line ) => line.trim() ).filter( Boolean ).map( function ( line ) {
			const at = line.indexOf( "|" );

			return at < 0 ? { name: "", url: line } : { name: line.slice( 0, at ).trim(), url: line.slice( at + 1 ).trim() };
		} );
	}

	function save() {
		area.value = Array.from( list.children ).map( function ( row ) {
			const name = row.querySelector( "select" ).value;
			const url = row.querySelector( "input" ).value.trim();

			return "" === url ? "" : ( name ? name + " | " + url : url );
		} ).filter( Boolean ).join( "\n" );
	}

	function row( item ) {
		const line = document.createElement( "div" );
		const select = document.createElement( "select" );
		const url = document.createElement( "input" );
		const remove = document.createElement( "button" );
		const names = data.names.slice();

		if ( item.name && ! names.some( ( name ) => same( name, item.name ) ) ) {
			names.push( item.name );
		}

		select.add( new Option( data.l10n.choose, "" ) );
		names.forEach( ( name ) => select.add( new Option( name, name ) ) );
		select.value = names.find( ( name ) => same( name, item.name ) ) || "";
		select.setAttribute( "aria-label", data.l10n.choose );

		url.type = "text";
		url.inputMode = "url";
		url.value = item.url;
		url.placeholder = "https://";
		url.setAttribute( "aria-label", data.l10n.url );
		url.style.flex = "1 1 14rem";
		url.style.minWidth = "0";

		remove.type = "button";
		remove.className = "button-link button-link-delete";
		remove.textContent = data.l10n.remove;
		remove.setAttribute( "aria-label", data.l10n.remove + " " + ( item.name || item.url ) );
		remove.addEventListener( "click", function () {
			line.remove();
			save();
		} );

		line.style.cssText = "display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin-bottom:6px";
		line.append( select, url, remove );
		list.append( line );

		return select;
	}

	add.type = "button";
	add.className = "button";
	add.textContent = data.l10n.add;
	add.addEventListener( "click", function () {
		row( { name: "", url: "" } ).focus();
	} );

	box.addEventListener( "input", save );
	box.addEventListener( "change", save );
	parse().forEach( row );

	if ( ! list.children.length ) {
		row( { name: "", url: "" } );
	}

	const label = area.id ? document.querySelector( 'label[for="' + area.id + '"]' ) : null;

	if ( label ) {
		box.setAttribute( "role", "group" );
		box.setAttribute( "aria-label", label.textContent.trim() );
	}

	box.style.cssText = "display:inline-block;width:100%;max-width:40rem";
	box.append( list, add );
	area.hidden = true;
	area.after( box );
} )();
