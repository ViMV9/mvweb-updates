( function () {
	"use strict";

	const SVG = "http://www.w3.org/2000/svg";
	const text = window.mvwebCoreMenuIcon || {};

	function icon( name ) {
		const svg = document.createElementNS( SVG, "svg" );
		const use = document.createElementNS( SVG, "use" );

		svg.setAttribute( "class", "mvweb-core-menu-icon__svg" + ( name ? "" : " mvweb-core-menu-icon__svg--none" ) );
		svg.setAttribute( "aria-hidden", "true" );

		if ( name ) {
			use.setAttribute( "href", "#mvweb-t-icon-" + name );
		}

		svg.appendChild( use );

		return svg;
	}

	function setup( box ) {
		if ( box.dataset.menuIconReady === "1" ) {
			return;
		}

		const select = box.querySelector( "select" );
		const label = box.querySelector( "label" );

		if ( ! select || ! label ) {
			return;
		}

		box.dataset.menuIconReady = "1";

		const toggle = document.createElement( "button" );
		const current = document.createElement( "span" );
		const panel = document.createElement( "div" );

		toggle.type = "button";
		toggle.id = select.id + "-toggle";
		toggle.className = "mvweb-core-menu-icon__toggle";
		toggle.setAttribute( "aria-expanded", "false" );
		toggle.setAttribute( "aria-controls", select.id + "-panel" );
		current.id = select.id + "-current";
		toggle.setAttribute( "aria-labelledby", label.id + " " + current.id );
		label.htmlFor = toggle.id;

		panel.id = select.id + "-panel";
		panel.className = "mvweb-core-menu-icon__panel";
		panel.hidden = true;

		function paint() {
			const option = select.options[ select.selectedIndex ];

			current.textContent = option ? option.text : "";
			toggle.replaceChildren( icon( select.value ), current );
		}

		function close( focus ) {
			panel.hidden = true;
			toggle.setAttribute( "aria-expanded", "false" );

			if ( focus ) {
				toggle.focus();
			}
		}

		function build() {
			const search = document.createElement( "input" );
			const grid = document.createElement( "div" );

			search.type = "search";
			search.className = "mvweb-core-menu-icon__search";
			search.placeholder = text.find || "";
			search.setAttribute( "aria-label", text.find || "" );
			grid.className = "mvweb-core-menu-icon__grid";

			Array.from( select.options ).forEach( function ( option ) {
				const pick = document.createElement( "button" );
				const name = document.createElement( "span" );

				pick.type = "button";
				pick.className = "mvweb-core-menu-icon__pick";
				pick.dataset.value = option.value;
				name.textContent = option.text;
				pick.append( icon( option.value ), name );
				grid.appendChild( pick );
			} );

			search.addEventListener( "input", function () {
				const query = search.value.trim().toLowerCase();

				grid.querySelectorAll( "button" ).forEach( function ( pick ) {
					pick.hidden = "" !== query && ! pick.textContent.toLowerCase().includes( query ) && ! pick.dataset.value.includes( query );
				} );
			} );

			search.addEventListener( "keydown", function ( event ) {
				if ( "Enter" === event.key ) {
					event.preventDefault();
				}
			} );

			grid.addEventListener( "click", function ( event ) {
				const pick = event.target.closest( "button" );

				if ( ! pick ) {
					return;
				}

				select.value = pick.dataset.value;
				select.dispatchEvent( new Event( "change", { bubbles: true } ) );
				paint();
				close( true );
			} );

			panel.addEventListener( "keydown", function ( event ) {
				if ( "Escape" === event.key ) {
					event.preventDefault();
					close( true );
				}
			} );

			panel.append( search, grid );
		}

		toggle.addEventListener( "click", function () {
			if ( ! panel.hidden ) {
				close( false );
				return;
			}

			if ( ! panel.firstChild ) {
				build();
			}

			panel.querySelectorAll( ".mvweb-core-menu-icon__pick" ).forEach( function ( pick ) {
				pick.setAttribute( "aria-pressed", pick.dataset.value === select.value ? "true" : "false" );
			} );

			panel.hidden = false;
			toggle.setAttribute( "aria-expanded", "true" );
			panel.querySelector( "input" ).focus();
		} );

		select.hidden = true;
		select.after( toggle, panel );
		paint();
	}

	function init() {
		document.querySelectorAll( "[data-menu-icon]" ).forEach( setup );

		const list = document.getElementById( "menu-to-edit" );

		if ( ! list || list.dataset.menuIconWatched === "1" ) {
			return;
		}

		list.dataset.menuIconWatched = "1";

		new MutationObserver( function () {
			list.querySelectorAll( "[data-menu-icon]:not([data-menu-icon-ready])" ).forEach( setup );
		} ).observe( list, { childList: true, subtree: true } );
	}

	if ( document.readyState === "loading" ) {
		document.addEventListener( "DOMContentLoaded", init );
	} else {
		init();
	}
} )();
