( function () {
	"use strict";

	function setup( box ) {
		if ( box.dataset.mvwebCoreMediaReady === "1" ) {
			return;
		}

		box.dataset.mvwebCoreMediaReady = "1";

		const field = box.querySelector( "[data-mvweb-core-media-value]" );
		const preview = box.querySelector( "[data-mvweb-core-media-preview]" );
		const pick = box.querySelector( "[data-mvweb-core-media-pick]" );
		const clear = box.querySelector( "[data-mvweb-core-media-clear]" );
		const multiple = box.dataset.mvwebCoreMediaMultiple === "1";

		if ( ! field || ! pick || ! clear ) {
			return;
		}

		function show( items ) {
			preview.textContent = "";

			items.forEach( function ( item ) {
				const url = item.sizes && item.sizes.thumbnail ? item.sizes.thumbnail.url : item.url;

				if ( ! url ) {
					return;
				}

				const image = document.createElement( "img" );
				image.src = url;
				image.alt = "";
				preview.appendChild( image );
			} );
		}

		pick.addEventListener( "click", function () {
			const frame = wp.media( { multiple: multiple, library: { type: "image" } } );

			frame.on( "select", function () {
				const items = frame.state().get( "selection" ).toJSON();

				field.value = items.map( function ( item ) {
					return item.id;
				} ).join( "," );

				show( items );
			} );

			frame.open();
		} );

		clear.addEventListener( "click", function () {
			field.value = multiple ? "" : 0;
			preview.textContent = "";
		} );
	}

	function init() {
		document.querySelectorAll( "[data-mvweb-core-media]" ).forEach( setup );
	}

	if ( document.readyState === "loading" ) {
		document.addEventListener( "DOMContentLoaded", init );
	} else {
		init();
	}
} )();
