jQuery( function ( $ ) {
	"use strict";

	const root = document.getElementById( "mvweb-core-builder" );

	if ( ! root ) {
		return;
	}

	const config = window.mvwebCoreBuilder || { types: {}, limit: 40, categories: {} };
	const store = document.getElementById( "mvweb-core-builder-data" );
	const list = root.querySelector( ".mvweb-core-builder__list" );
	const empty = root.querySelector( ".mvweb-core-builder__empty" );
	const addBtn = root.querySelector( ".mvweb-core-builder__add-btn" );
	const count = root.querySelector( ".mvweb-core-builder__count" );
	const toggleAll = root.querySelector( ".mvweb-core-builder__toggle-all" );
	const warn = root.querySelector( ".mvweb-core-builder__warn" );
	const notice = root.querySelector( ".mvweb-core-builder__notice" );
	const library = root.querySelector( ".mvweb-core-builder__library" );
	const sets = root.querySelector( ".mvweb-core-builder__sets" );
	const setsBtn = root.querySelector( ".mvweb-core-builder__sets-btn" );
	const setCards = [];
	const { __, _n, sprintf } = wp.i18n;
	const svgNS = "http://www.w3.org/2000/svg";

	let counter = 0;
	let live = false;
	let insertAt = null;
	let undo = null;
	let undoTimer = 0;

	function uid() {
		if ( window.crypto && window.crypto.randomUUID ) {
			return window.crypto.randomUUID();
		}

		return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace( /[xy]/g, function ( c ) {
			const r = ( Math.random() * 16 ) | 0;
			return ( c === "x" ? r : ( r & 0x3 ) | 0x8 ).toString( 16 );
		} );
	}

	function readStore() {
		try {
			const parsed = JSON.parse( store.value );
			return Array.isArray( parsed ) ? parsed : [];
		} catch ( e ) {
			return [];
		}
	}

	function rows() {
		return Array.prototype.slice.call( list.children );
	}

	function collect() {
		const data = rows().map( function ( el ) {
			return el.rowData;
		} );

		store.value = JSON.stringify( data );

	if ( live && store.hasAttribute( "data-customize-setting-link" ) ) {
		store.dispatchEvent( new Event( "input", { bubbles: true } ) );
	}
		empty.hidden = data.length > 0;
		addBtn.disabled = data.length >= config.limit;
		setsBtn.disabled = addBtn.disabled;
		setCards.forEach( function ( card ) {
			card.disabled = data.length + card.size > config.limit;
		} );
		rows().forEach( paintHead );
		paintBar();
	}

	function describe( field, wrap ) {
		if ( ! field.description ) {
			return;
		}

		const note = document.createElement( "p" );
		note.className = "description";
		note.textContent = field.description;
		wrap.appendChild( note );
	}

	function plainText( value ) {
		const box = document.createElement( "div" );
		box.innerHTML = String( value || "" );
		return ( box.textContent || "" ).replace( /\s+/g, " " ).trim();
	}

	function wireframe( type, className ) {
		const box = document.createElement( "span" );
		const svg = document.createElementNS( svgNS, "svg" );
		const use = document.createElementNS( svgNS, "use" );

		box.className = className;
		box.setAttribute( "aria-hidden", "true" );
		svg.setAttribute( "viewBox", "0 0 120 72" );
		use.setAttribute( "href", document.getElementById( "mvweb-core-wf-" + type ) ? "#mvweb-core-wf-" + type : "#mvweb-core-wf-default" );
		svg.appendChild( use );
		box.appendChild( svg );

		return box;
	}

	function isSegment( field ) {
		const labels = Object.keys( field.choices || {} ).map( function ( key ) {
			return String( field.choices[ key ] );
		} );

		return field.type === "select" && labels.length >= 2 && labels.length <= 3 && labels.every( function ( label ) {
			return label.length <= 28;
		} );
	}

	function buildSegment( field, control ) {
		const group = document.createElement( "div" );
		group.className = "mvweb-core-builder__segment";
		group.setAttribute( "role", "radiogroup" );

		const buttons = Object.keys( field.choices ).map( function ( value ) {
			const btn = document.createElement( "button" );
			btn.type = "button";
			btn.setAttribute( "role", "radio" );
			btn.textContent = field.choices[ value ];
			btn.dataset.value = value;
			btn.addEventListener( "click", function () {
				control.value = value;
				paint();
				control.dispatchEvent( new Event( "change" ) );
			} );
			group.appendChild( btn );
			return btn;
		} );

		function paint() {
			buttons.forEach( function ( btn ) {
				btn.setAttribute( "aria-checked", String( btn.dataset.value === control.value ) );
			} );
		}

		paint();

		return group;
	}

	const colorLinks = new WeakMap();
	const colorPair = { bg_color: "ink_color", ink_color: "bg_color", bg_color_dark: "ink_color_dark", ink_color_dark: "bg_color_dark" };

	function buildColor( fieldId, field, props, notify ) {
		const contrast = window.mvwebCoreContrast;
		const wrap = document.createElement( "div" );
		wrap.className = "mvweb-core-builder__field mvweb-core-builder__field--color";

		const text = document.createElement( "label" );
		text.className = "mvweb-core-builder__label";
		text.textContent = field.label;

		const input = document.createElement( "input" );
		input.type = "text";
		input.id = "mvweb-core-builder-field-" + ++counter;
		text.htmlFor = input.id;

		props[ fieldId ] = contrast ? contrast.normalize( props[ fieldId ] ) : "";
		input.value = props[ fieldId ] || "";

		const note = document.createElement( "p" );
		note.className = "description mvweb-core-builder__contrast";
		note.hidden = true;

		const links = colorLinks.get( props ) || {};

		colorLinks.set( props, links );

		function paint() {
			const message = contrast && colorPair[ fieldId ] ? contrast.warning( props[ fieldId ], props[ colorPair[ fieldId ] ] ) : "";

			note.textContent = message;
			note.hidden = ! message;
		}

		function update() {
			Object.keys( links ).forEach( function ( id ) {
				links[ id ]();
			} );
			notify();
		}

		function pick( value ) {
			const color = contrast ? contrast.normalize( value ) : value;

			if ( color !== props[ fieldId ] ) {
				props[ fieldId ] = color;
				update();
			}
		}

		links[ fieldId ] = paint;
		wrap.appendChild( text );
		wrap.appendChild( input );
		wrap.appendChild( note );

		$( input ).wpColorPicker( {
			change: function ( event, ui ) {
				pick( ui.color.toString() );
			},
			clear: function () {
				pick( "" );
			}
		} );

		const toggler = wrap.querySelector( ".wp-color-result" );

		if ( toggler ) {
			toggler.setAttribute( "aria-label", field.label + ": " + toggler.textContent.trim() );
		}

		paint();
		describe( field, wrap );

		return { wrap: wrap, control: null, type: "color", push: update, ready: false };
	}

	function buildParts( fieldId, field, props, notify ) {
		const wrap = document.createElement( "div" );
		wrap.className = "mvweb-core-builder__field mvweb-core-builder__field--parts mvweb-core-builder__field--wide";

		const caption = document.createElement( "span" );
		caption.className = "mvweb-core-builder__label";
		caption.id = "mvweb-core-builder-label-" + ++counter;
		caption.textContent = field.label;
		wrap.appendChild( caption );

		const list = document.createElement( "ul" );
		list.className = "mvweb-core-builder__parts";
		list.setAttribute( "aria-labelledby", caption.id );
		wrap.appendChild( list );

		const keys = Object.keys( field.choices );
		const shown = ( Array.isArray( props[ fieldId ] ) ? props[ fieldId ] : field.default ).filter( function ( slug ) {
			return keys.indexOf( slug ) !== -1;
		} );
		const order = shown.concat( keys.filter( function ( slug ) {
			return shown.indexOf( slug ) === -1;
		} ) );

		function collectParts() {
			return Array.prototype.filter.call( list.children, function ( item ) {
				return item.querySelector( "input" ).checked;
			} ).map( function ( item ) {
				return item.dataset.part;
			} );
		}

		function sync() {
			props[ fieldId ] = collectParts();
			notify();
		}

		function move( item, before ) {
			list.insertBefore( item, before );
			sync();
		}

		order.forEach( function ( slug ) {
			const item = document.createElement( "li" );
			item.className = "mvweb-core-builder__part";
			item.dataset.part = slug;

			if ( field.choice_views && field.choice_views[ slug ] ) {
				item.dataset.views = field.choice_views[ slug ].join( " " );
			}

			const handle = document.createElement( "span" );
			handle.className = "mvweb-core-builder__part-handle dashicons dashicons-menu";
			handle.setAttribute( "aria-hidden", "true" );

			const line = document.createElement( "label" );
			const box = document.createElement( "input" );
			box.type = "checkbox";
			box.checked = shown.indexOf( slug ) !== -1;
			box.addEventListener( "change", sync );
			line.appendChild( box );
			line.appendChild( document.createTextNode( " " + field.choices[ slug ] ) );

			const up = button( "arrow-up-alt2", __( "Move up", "mvweb-core" ), function () {
				if ( item.previousElementSibling ) {
					move( item, item.previousElementSibling );
				}

				up.focus();
			} );
			const down = button( "arrow-down-alt2", __( "Move down", "mvweb-core" ), function () {
				if ( item.nextElementSibling ) {
					move( item, item.nextElementSibling.nextElementSibling );
				}

				down.focus();
			} );

			item.appendChild( handle );
			item.appendChild( line );
			item.appendChild( up );
			item.appendChild( down );
			list.appendChild( item );
		} );

		props[ fieldId ] = collectParts();

		$( list ).sortable( {
			handle: ".mvweb-core-builder__part-handle",
			axis: "y",
			stop: sync
		} );

		describe( field, wrap );

		return { wrap: wrap, control: null, type: "parts", push: sync, ready: false };
	}

	function buildField( fieldId, field, props, onChange ) {
		const built = buildInput( fieldId, field, props, onChange );

		if ( built && field.views && field.views.length ) {
			built.wrap.dataset.views = field.views.join( " " );
		}

		return built;
	}

	function buildInput( fieldId, field, props, onChange ) {
		const notify = onChange || collect;

		if ( field.type === "repeat" ) {
			return buildRepeat( fieldId, field, props, notify );
		}

		if ( field.type === "parts" ) {
			return buildParts( fieldId, field, props, notify );
		}

		if ( field.type === "color" ) {
			return buildColor( fieldId, field, props, notify );
		}

		const wrap = document.createElement( "div" );
		wrap.className = "mvweb-core-builder__field mvweb-core-builder__field--" + field.type;

		if ( field.type === "textarea" || field.type === "richtext" || field.type === "code" ) {
			wrap.classList.add( "mvweb-core-builder__field--wide" );
		}

		const current = Object.prototype.hasOwnProperty.call( props, fieldId ) ? props[ fieldId ] : field.default;
		const segment = isSegment( field );
		let control;

		switch ( field.type ) {
			case "richtext":
				control = document.createElement( "textarea" );
				control.id = "mvweb-core-builder-editor-" + ++counter;
				control.className = "mvweb-core-builder__editor";
				control.value = current || "";
				break;

			case "textarea":
				control = document.createElement( "textarea" );
				control.className = "widefat";
				control.rows = 3;
				control.value = current || "";
				break;

			case "code":
				control = document.createElement( "textarea" );
				control.className = "widefat code";
				control.rows = 6;
				control.spellcheck = false;
				control.value = current || "";
				break;

			case "toggle":
				control = document.createElement( "input" );
				control.type = "checkbox";
				control.checked = !! current;
				break;

			case "number":
				control = document.createElement( "input" );
				control.type = "number";
				control.className = "small-text";
				if ( field.min !== null ) {
					control.min = field.min;
				}
				if ( field.max !== null ) {
					control.max = field.max;
				}
				control.value = current === "" ? "" : current;
				break;

			case "select":
			case "icon":
			case "item":
			case "category":
				if ( segment ) {
					control = document.createElement( "input" );
					control.type = "hidden";
					control.value = current || Object.keys( field.choices )[ 0 ];
					break;
				}

				control = document.createElement( "select" );
				Object.keys( field.choices ).forEach( function ( value ) {
					const option = document.createElement( "option" );
					option.value = value;
					option.textContent = field.choices[ value ];
					control.appendChild( option );
				} );
				control.value = current || "";
				break;

			case "image":
				control = document.createElement( "input" );
				control.type = "hidden";
				control.value = current || 0;
				break;

			case "url":
				control = document.createElement( "input" );
				control.type = "url";
				control.className = "widefat";
				control.value = current || "";
				break;

			case "text":
			case "line":
				control = document.createElement( "input" );
				control.type = "text";
				control.className = "widefat";
				control.value = current || "";
				break;

			default:
				return null;
		}

		function push() {
			if ( field.type === "toggle" ) {
				props[ fieldId ] = control.checked;
			} else if ( field.type === "number" || field.type === "image" ) {
				props[ fieldId ] = control.value === "" ? "" : Number( control.value );
			} else {
				props[ fieldId ] = control.value;
			}

			notify();
		}

		props[ fieldId ] = segment ? control.value : current;

		if ( field.type === "toggle" ) {
			const line = document.createElement( "label" );
			line.className = "mvweb-core-builder__toggle";
			line.appendChild( control );
			line.appendChild( document.createTextNode( " " + field.label ) );
			wrap.appendChild( line );
		} else {
			const text = document.createElement( segment ? "span" : "label" );
			text.className = "mvweb-core-builder__label";
			text.textContent = field.label;
			wrap.appendChild( text );
			wrap.appendChild( control );

			if ( segment ) {
				text.id = "mvweb-core-builder-label-" + ++counter;
				const group = buildSegment( field, control );
				group.setAttribute( "aria-labelledby", text.id );
				wrap.appendChild( group );
			} else {
				control.id = control.id || "mvweb-core-builder-field-" + ++counter;
				text.htmlFor = control.id;
			}
		}

		if ( field.type === "image" ) {
			wrap.appendChild( buildImagePicker( control, push ) );
		}

		if ( field.type === "icon" ) {
			iconPreview( control );
		}

		control.addEventListener( "change", push );
		control.addEventListener( "input", push );

		describe( field, wrap );

		return { wrap: wrap, control: control, type: field.type, push: push, ready: false };
	}

	function iconPreview( select ) {
		const box = document.createElement( "span" );
		const preview = document.createElementNS( svgNS, "svg" );
		const use = document.createElementNS( svgNS, "use" );

		box.className = "mvweb-core-icon-pick";
		preview.setAttribute( "class", "mvweb-core-icon-pick__preview" );
		preview.setAttribute( "aria-hidden", "true" );
		preview.appendChild( use );

		select.parentNode.insertBefore( box, select );
		box.appendChild( preview );
		box.appendChild( select );

		function paint() {
			use.setAttribute( "href", select.value ? "#mvweb-t-icon-" + select.value : "" );
		}

		select.addEventListener( "change", paint );
		paint();
	}

	function buildRepeat( fieldId, field, props, notify ) {
		const wrap = document.createElement( "div" );
		wrap.className = "mvweb-core-builder__field mvweb-core-builder__field--repeat mvweb-core-builder__field--wide";

		const caption = document.createElement( "span" );
		caption.className = "mvweb-core-builder__label";
		caption.textContent = field.label;
		wrap.appendChild( caption );

		const items = document.createElement( "div" );
		items.className = "mvweb-core-builder__repeat";
		wrap.appendChild( items );

		const add = document.createElement( "button" );
		add.type = "button";
		add.className = "button mvweb-core-builder__repeat-add";
		add.textContent = __( "Add row", "mvweb-core" );

		const limit = field.max === null ? 50 : field.max;

		function rowTitle( el ) {
			const ids = Object.keys( field.fields );

			for ( let i = 0; i < ids.length; i++ ) {
				const type = field.fields[ ids[ i ] ].type;
				const value = el.rowData[ ids[ i ] ];

				if ( ( type === "text" || type === "line" || type === "textarea" || type === "richtext" ) && typeof value === "string" ) {
					const text = value.replace( /<[^>]*>/g, "" ).replace( /\s+/g, " " ).trim();

					if ( text !== "" ) {
						return text.length > 60 ? text.slice( 0, 60 ) + "…" : text;
					}
				}
			}

			return sprintf( __( "Row %d", "mvweb-core" ), Array.prototype.indexOf.call( items.children, el ) + 1 );
		}

		function setRepeatOpen( el, open ) {
			el.classList.toggle( "is-open", open );
			el.repeatBody.hidden = ! open;
			el.repeatToggle.setAttribute( "aria-expanded", open ? "true" : "false" );
		}

		function sync() {
			props[ fieldId ] = Array.prototype.map.call( items.children, function ( el ) {
				el.repeatTitle.textContent = rowTitle( el );
				el.classList.toggle( "is-muted", el.rowData.visible === "hide" );

				return el.rowData;
			} );

			add.disabled = items.children.length >= limit;
			notify();
		}

		function addRepeatRow( data ) {
			const el = document.createElement( "div" );
			el.className = "mvweb-core-builder__repeat-row";
			el.rowData = data && typeof data === "object" ? data : {};

			const head = document.createElement( "div" );
			head.className = "mvweb-core-builder__repeat-head";

			const handle = document.createElement( "span" );
			handle.className = "mvweb-core-builder__repeat-handle dashicons dashicons-menu";
			handle.title = __( "Drag to reorder", "mvweb-core" );
			head.appendChild( handle );

			const toggle = document.createElement( "button" );
			toggle.type = "button";
			toggle.className = "mvweb-core-builder__repeat-toggle";
			toggle.setAttribute( "aria-expanded", "false" );

			const title = document.createElement( "span" );
			title.className = "mvweb-core-builder__repeat-title";
			toggle.appendChild( title );
			head.appendChild( toggle );

			const remove = button( "no-alt", __( "Remove row", "mvweb-core" ), function () {
				el.remove();

				if ( items.children.length === 1 ) {
					setRepeatOpen( items.children[ 0 ], true );
				}

				sync();
			} );

			remove.classList.add( "mvweb-core-builder__repeat-remove" );
			head.appendChild( remove );
			el.appendChild( head );

			const body = document.createElement( "div" );
			body.className = "mvweb-core-builder__repeat-body";
			body.hidden = true;
			el.appendChild( body );

			el.repeatBody = body;
			el.repeatToggle = toggle;
			el.repeatTitle = title;

			toggle.addEventListener( "click", function () {
				setRepeatOpen( el, ! el.classList.contains( "is-open" ) );
			} );

			Object.keys( field.fields ).forEach( function ( subId ) {
				const sub = field.fields[ subId ];

				const flat = sub.type === "richtext" ? Object.assign( {}, sub, { type: "textarea" } ) : sub;
				const built = buildField( subId, flat, el.rowData, sync );

				if ( built ) {
					body.appendChild( built.wrap );
				}
			} );

			items.appendChild( el );

			return el;
		}

		( Array.isArray( props[ fieldId ] ) ? props[ fieldId ] : [] ).forEach( addRepeatRow );

		if ( items.children.length === 1 ) {
			setRepeatOpen( items.children[ 0 ], true );
		}

		add.addEventListener( "click", function () {
			if ( items.children.length >= limit ) {
				return;
			}

			setRepeatOpen( addRepeatRow( {} ), true );
			sync();
		} );

		wrap.appendChild( add );
		describe( field, wrap );
		sync();

		$( items ).sortable( {
			items: "> .mvweb-core-builder__repeat-row",
			handle: ".mvweb-core-builder__repeat-handle",
			axis: "y",
			tolerance: "pointer",
			stop: sync,
		} );

		return { wrap: wrap, control: null, type: "repeat", push: sync, ready: false };
	}

	function buildImagePicker( control, push ) {
		const box = document.createElement( "div" );
		box.className = "mvweb-core-builder__image";

		const preview = document.createElement( "img" );
		preview.alt = "";

		const pick = document.createElement( "button" );
		pick.type = "button";
		pick.className = "button";
		pick.textContent = __( "Choose image", "mvweb-core" );

		const clear = document.createElement( "button" );
		clear.type = "button";
		clear.className = "button-link";
		clear.textContent = __( "Remove", "mvweb-core" );

		function show( url ) {
			preview.hidden = ! url;
			preview.src = url || "";
			clear.hidden = ! url;
		}

		show( "" );

		if ( Number( control.value ) > 0 && wp.media && wp.media.attachment ) {
			const known = wp.media.attachment( control.value );

			known.fetch().then( function () {
				const sizes = known.get( "sizes" );
				show( sizes && sizes.thumbnail ? sizes.thumbnail.url : known.get( "url" ) );
			} ).catch( function () {
				show( "" );
			} );
		}

		pick.addEventListener( "click", function () {
			const frame = wp.media( { multiple: false, library: { type: "image" } } );

			frame.on( "select", function () {
				const item = frame.state().get( "selection" ).first().toJSON();
				control.value = item.id;
				show( item.sizes && item.sizes.thumbnail ? item.sizes.thumbnail.url : item.url );
				push();
			} );

			frame.open();
		} );

		clear.addEventListener( "click", function () {
			control.value = 0;
			show( "" );
			push();
		} );

		box.appendChild( preview );
		box.appendChild( pick );
		box.appendChild( clear );

		return box;
	}

	function button( icon, text, onClick ) {
		const btn = document.createElement( "button" );
		btn.type = "button";
		btn.className = "button-link mvweb-core-builder__action";
		btn.title = text;
		btn.setAttribute( "aria-label", text );

		const glyph = document.createElement( "span" );
		glyph.className = "dashicons dashicons-" + icon;
		glyph.setAttribute( "aria-hidden", "true" );

		btn.appendChild( glyph );
		btn.addEventListener( "click", onClick );

		return btn;
	}

	function summary( el ) {
		const definition = config.types[ el.rowData.type ];
		const props = el.rowData.props || {};

		if ( ! definition ) {
			return __( "Unknown type, data kept", "mvweb-core" );
		}

		if ( definition.global ) {
			return definition.note;
		}

		const parts = [];
		let heading = plainText( props.title );

		if ( ! heading ) {
			Object.keys( definition.fields ).some( function ( id ) {
				const type = definition.fields[ id ].type;
				heading = ( type === "text" || type === "line" ) ? plainText( props[ id ] ) : "";
				return heading !== "";
			} );
		}

		if ( heading ) {
			parts.push( "«" + ( heading.length > 80 ? heading.slice( 0, 78 ) + "…" : heading ) + "»" );
		}

		Object.keys( definition.fields ).forEach( function ( id ) {
			const field = definition.fields[ id ];

			if ( field.type === "repeat" && Array.isArray( props[ id ] ) && props[ id ].length ) {
				parts.push( field.label + ": " + props[ id ].length );
			}
		} );

		return parts.length ? parts.join( " · " ) : __( "Not filled in yet", "mvweb-core" );
	}

	function badges( el ) {
		const definition = config.types[ el.rowData.type ];
		const props = el.rowData.props || {};
		const out = [];

		if ( el.rowData.hidden ) {
			out.push( [ "off", __( "hidden", "mvweb-core" ) ] );
		}

		if ( ! definition ) {
			return out;
		}

		if ( definition.global ) {
			out.push( [ "global", __( "the same on every page", "mvweb-core" ) ] );
		}

		if ( definition.fields.variant && definition.fields.variant.choices && props.variant ) {
			out.push( [ "", String( definition.fields.variant.choices[ props.variant ] || "" ).toLowerCase() ] );
		}

		return out;
	}

	function paintHead( el ) {
		const hidden = !! el.rowData.hidden;

		el.classList.toggle( "is-hidden", hidden );
		el.summaryText.textContent = summary( el );
		el.badgeBox.textContent = "";

		badges( el ).forEach( function ( item ) {
			if ( ! item[ 1 ] ) {
				return;
			}

			const badge = document.createElement( "span" );
			badge.className = "mvweb-core-builder__badge" + ( item[ 0 ] ? " mvweb-core-builder__badge--" + item[ 0 ] : "" );
			badge.textContent = item[ 1 ];
			el.badgeBox.appendChild( badge );
		} );

		if ( el.hideBtn ) {
			const label = hidden ? __( "Show on the page", "mvweb-core" ) : __( "Hide from the page", "mvweb-core" );
			el.hideBtn.firstChild.className = "dashicons dashicons-" + ( hidden ? "hidden" : "visibility" );
			el.hideBtn.title = label;
			el.hideBtn.setAttribute( "aria-label", label );
			el.hideBtn.setAttribute( "aria-pressed", String( hidden ) );
		}
	}

	function paintBar() {
		const all = rows();
		const hidden = all.filter( function ( el ) {
			return el.rowData.hidden;
		} ).length;
		// translators: %d: number of sections on the page.
		const parts = [ sprintf( _n( "%d section", "%d sections", all.length, "mvweb-core" ), all.length ) ];

		if ( hidden ) {
			// translators: %d: number of hidden sections.
			parts.push( sprintf( _n( "%d hidden", "%d hidden", hidden, "mvweb-core" ), hidden ) );
		}

		count.textContent = parts.join( " · " );

		const closed = all.some( function ( el ) {
			return ! el.classList.contains( "is-open" );
		} );

		toggleAll.hidden = all.length < 2;
		toggleAll.textContent = closed ? __( "Expand all", "mvweb-core" ) : __( "Collapse all", "mvweb-core" );
		toggleAll.dataset.open = closed ? "1" : "";

		paintWarn();
	}

	function paintWarn() {
		const select = document.getElementById( "page_template" );
		const current = select ? select.value : config.current;
		const useBtn = warn.querySelector( ".mvweb-core-builder__use-template" );

		warn.hidden = ! config.template || ! rows().length || current === config.template;
		useBtn.hidden = ! select || ! select.querySelector( 'option[value="' + config.template + '"]' );
	}

	function startEditors( el ) {
		el.editors.forEach( function ( built ) {
			if ( built.ready ) {
				return;
			}

			wp.editor.initialize( built.control.id, {
				tinymce: {
					wpautop: true,
					toolbar1: "formatselect,bold,italic,bullist,numlist,link,unlink,undo,redo",
					setup: function ( editor ) {
						editor.on( "change keyup SetContent", function () {
							editor.save();
							built.push();
						} );
					},
				},
				quicktags: true,
				mediaButtons: true,
			} );

			built.ready = true;
		} );
	}

	function stopEditors( el ) {
		el.editors.forEach( function ( built ) {
			if ( ! built.ready ) {
				return;
			}

			const editor = window.tinymce && window.tinymce.get( built.control.id );

			if ( editor ) {
				editor.save();
			}

			built.push();
			wp.editor.remove( built.control.id );
			built.ready = false;
		} );
	}

	function setOpen( el, open ) {
		if ( ! el.body ) {
			return;
		}

		if ( ! open ) {
			stopEditors( el );
		}

		el.body.hidden = ! open;
		el.classList.toggle( "is-open", open );
		el.toggle.setAttribute( "aria-expanded", String( open ) );

		if ( open ) {
			startEditors( el );
		}

		paintBar();
	}

	function move( el, reorder ) {
		const open = el.classList.contains( "is-open" );

		stopEditors( el );
		reorder();

		if ( open ) {
			startEditors( el );
		}

		collect();
	}

	function moveUp( el ) {
		const prev = el.previousElementSibling;

		if ( prev ) {
			move( el, function () {
				list.insertBefore( el, prev );
			} );
		}
	}

	function moveDown( el ) {
		const next = el.nextElementSibling;

		if ( next ) {
			move( el, function () {
				list.insertBefore( next, el );
			} );
		}
	}

	function remove( el ) {
		const index = rows().indexOf( el );
		const definition = config.types[ el.rowData.type ];

		stopEditors( el );
		el.remove();
		collect();

		undo = { el: el, index: index };
		clearTimeout( undoTimer );

		// translators: %s: name of the section type.
		notice.textContent = sprintf( __( "Section “%s” removed.", "mvweb-core" ), definition ? definition.label : el.rowData.type ) + " ";

		const back = document.createElement( "button" );
		back.type = "button";
		back.className = "button-link";
		back.textContent = __( "Undo", "mvweb-core" );
		back.addEventListener( "click", restore );
		notice.appendChild( back );
		notice.hidden = false;

		undoTimer = setTimeout( function () {
			notice.hidden = true;
			undo = null;
		}, 12000 );
	}

	function restore() {
		if ( ! undo ) {
			return;
		}

		list.insertBefore( undo.el, rows()[ undo.index ] || null );

		if ( undo.el.classList.contains( "is-open" ) ) {
			startEditors( undo.el );
		}

		undo.el.toggle.focus();
		undo = null;
		notice.hidden = true;
		collect();
	}

	function duplicate( el ) {
		stopEditors( el );

		if ( el.classList.contains( "is-open" ) ) {
			startEditors( el );
		}

		const copy = JSON.parse( JSON.stringify( el.rowData ) );
		copy.uid = uid();

		const clone = insertRow( copy, rows().indexOf( el ) + 1 );
		setOpen( clone, true );
		clone.toggle.focus();
	}

	function buildBody( el, definition ) {
		const body = document.createElement( "div" );
		body.className = "mvweb-core-builder__body";
		body.hidden = true;

		if ( definition.note ) {
			const note = document.createElement( "p" );
			note.className = "description";
			note.textContent = definition.note + " ";

			if ( definition.link ) {
				const link = document.createElement( "a" );
				link.href = definition.link.url;
				link.textContent = definition.link.label;
				note.appendChild( link );
			}

			body.appendChild( note );
		}

		const fields = {};
		let groupName = null;
		let grid = null;

		Object.keys( definition.fields ).forEach( function ( fieldId ) {
			const field = definition.fields[ fieldId ];
			const built = buildField( fieldId, field, el.rowData.props );

			if ( ! built ) {
				return;
			}

			if ( ! grid || ( field.group || "" ) !== groupName ) {
				groupName = field.group || "";

				const group = document.createElement( "div" );
				group.className = "mvweb-core-builder__group";

				if ( groupName ) {
					const heading = document.createElement( "h4" );
					heading.className = "mvweb-core-builder__group-title";
					heading.textContent = groupName;
					group.appendChild( heading );
				}

				grid = document.createElement( "div" );
				grid.className = "mvweb-core-builder__fields";
				group.appendChild( grid );
				body.appendChild( group );
			}

			fields[ fieldId ] = built;
			grid.appendChild( built.wrap );

			if ( built.type === "richtext" ) {
				el.editors.push( built );
			}
		} );

		Object.keys( fields ).forEach( function ( fieldId ) {
			const rule = definition.fields[ fieldId ].show_when;
			const source = rule && rule.field ? fields[ rule.field ] : null;

			if ( ! source || ! source.control ) {
				return;
			}

			function apply() {
				fields[ fieldId ].wrap.hidden = rule.in.indexOf( String( source.control.value ) ) === -1;
			}

			source.control.addEventListener( "change", apply );
			apply();
		} );

		if ( fields.view && fields.view.control ) {
			const view = fields.view.control;

			function showView() {
				body.dataset.view = String( view.value );

				body.querySelectorAll( ".mvweb-core-builder__group" ).forEach( function ( group ) {
					group.hidden = ! Array.prototype.some.call( group.querySelectorAll( ".mvweb-core-builder__fields > .mvweb-core-builder__field" ), function ( wrap ) {
						return ! wrap.hidden && ( ! wrap.dataset.views || wrap.dataset.views.split( " " ).indexOf( body.dataset.view ) !== -1 );
					} );
				} );
			}

			view.addEventListener( "change", showView );
			showView();
		}

		return body;
	}

	function buildRow( row ) {
		const definition = config.types[ row.type ];
		const el = document.createElement( "div" );
		el.className = "mvweb-core-builder__row";
		el.rowData = row;
		el.editors = [];

		row.props = row.props && typeof row.props === "object" ? row.props : {};

		const head = document.createElement( "div" );
		head.className = "mvweb-core-builder__head";

		const handle = document.createElement( "span" );
		handle.className = "mvweb-core-builder__handle dashicons dashicons-menu";
		handle.title = __( "Drag to reorder", "mvweb-core" );

		const toggle = document.createElement( "button" );
		toggle.type = "button";
		toggle.className = "mvweb-core-builder__toggle-row";
		toggle.setAttribute( "aria-expanded", "false" );

		const title = document.createElement( "span" );
		title.className = "mvweb-core-builder__title";

		const name = document.createElement( "strong" );
		name.textContent = definition ? definition.label : row.type;

		const badgeBox = document.createElement( "span" );
		badgeBox.className = "mvweb-core-builder__badges";

		const summaryText = document.createElement( "span" );
		summaryText.className = "mvweb-core-builder__summary";

		title.appendChild( name );
		title.appendChild( badgeBox );
		toggle.appendChild( wireframe( row.type, "mvweb-core-builder__thumb" ) );
		toggle.appendChild( title );
		toggle.appendChild( summaryText );

		const actions = document.createElement( "span" );
		actions.className = "mvweb-core-builder__actions";

		el.hideBtn = button( "visibility", "", function () {
			if ( el.rowData.hidden ) {
				delete el.rowData.hidden;
			} else {
				el.rowData.hidden = true;
			}

			collect();
		} );

		actions.appendChild( el.hideBtn );

		if ( definition && ! definition.global ) {
			actions.appendChild( button( "admin-page", __( "Duplicate", "mvweb-core" ), function () {
				duplicate( el );
			} ) );
		}

		actions.appendChild( button( "arrow-up-alt2", __( "Move up", "mvweb-core" ), function () {
			moveUp( el );
		} ) );

		actions.appendChild( button( "arrow-down-alt2", __( "Move down", "mvweb-core" ), function () {
			moveDown( el );
		} ) );

		const trash = button( "trash", __( "Remove section", "mvweb-core" ), function () {
			remove( el );
		} );

		trash.classList.add( "mvweb-core-builder__action--danger" );
		actions.appendChild( trash );

		head.appendChild( handle );
		head.appendChild( toggle );
		head.appendChild( actions );
		el.appendChild( head );

		el.toggle = toggle;
		el.badgeBox = badgeBox;
		el.summaryText = summaryText;

		if ( definition && ( Object.keys( definition.fields ).length || definition.note ) ) {
			el.body = buildBody( el, definition );
			el.appendChild( el.body );

			toggle.addEventListener( "click", function () {
				setOpen( el, ! el.classList.contains( "is-open" ) );
			} );
		} else {
			toggle.disabled = true;
		}

		head.addEventListener( "keydown", function ( event ) {
			if ( ! event.altKey || ( event.key !== "ArrowUp" && event.key !== "ArrowDown" ) ) {
				return;
			}

			event.preventDefault();

			if ( event.key === "ArrowUp" ) {
				moveUp( el );
			} else {
				moveDown( el );
			}

			event.target.focus();
		} );

		const insert = document.createElement( "button" );
		insert.type = "button";
		insert.className = "mvweb-core-builder__insert";
		insert.title = __( "Insert a section here", "mvweb-core" );
		insert.setAttribute( "aria-label", insert.title );
		insert.innerHTML = '<span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span>';
		insert.addEventListener( "click", function () {
			openLibrary( rows().indexOf( el ) + 1 );
		} );
		el.appendChild( insert );

		paintHead( el );

		return el;
	}

	function insertRow( row, index ) {
		const el = buildRow( row );
		const before = typeof index === "number" ? rows()[ index ] : null;

		list.insertBefore( el, before || null );
		collect();

		return el;
	}


	const tiles = library.querySelector( ".mvweb-core-builder__tiles" );
	const chips = library.querySelector( ".mvweb-core-builder__chips" );
	const search = library.querySelector( ".mvweb-core-builder__search" );
	const nothing = library.querySelector( ".mvweb-core-builder__nothing" );
	let shelf = "";

	function chip( key, label, total ) {
		const btn = document.createElement( "button" );
		btn.type = "button";
		btn.className = "mvweb-core-builder__chip";
		btn.dataset.shelf = key;
		btn.textContent = total === null ? label : label + " " + total;
		btn.setAttribute( "aria-pressed", String( key === shelf ) );
		btn.addEventListener( "click", function () {
			shelf = key;
			chips.querySelectorAll( ".mvweb-core-builder__chip" ).forEach( function ( other ) {
				other.setAttribute( "aria-pressed", String( other === btn ) );
			} );
			filter();
		} );
		chips.appendChild( btn );
	}

	const shelves = Object.keys( config.categories || {} );

	const typeKeys = Object.keys( config.types ).sort( function ( a, b ) {
		return shelves.indexOf( config.types[ a ].category ) - shelves.indexOf( config.types[ b ].category );
	} );

	chip( "", __( "All", "mvweb-core" ), typeKeys.length );

	Object.keys( config.categories || {} ).forEach( function ( key ) {
		if ( typeKeys.some( function ( type ) {
			return config.types[ type ].category === key;
		} ) ) {
			chip( key, config.categories[ key ], null );
		}
	} );

	typeKeys.forEach( function ( type ) {
		const definition = config.types[ type ];
		const tile = document.createElement( "button" );
		tile.type = "button";
		tile.className = "mvweb-core-builder__tile";
		tile.dataset.type = type;
		tile.dataset.shelf = definition.category || "other";
		tile.dataset.name = definition.label.toLowerCase();
		tile.dataset.find = ( definition.label + " " + ( definition.description || "" ) ).toLowerCase();

		const name = document.createElement( "strong" );
		name.textContent = definition.label;

		const text = document.createElement( "span" );
		text.textContent = definition.description || "";

		tile.appendChild( wireframe( type, "mvweb-core-builder__thumb" ) );
		tile.appendChild( name );
		tile.appendChild( text );
		tile.addEventListener( "click", function () {
			const el = insertRow( { uid: uid(), type: type, v: 1, props: {} }, insertAt );
			library.close();
			setOpen( el, true );
			el.scrollIntoView( { block: "nearest", behavior: "smooth" } );
			el.toggle.focus( { preventScroll: true } );
		} );
		tiles.appendChild( tile );
	} );

	function filter() {
		const query = search.value.trim().toLowerCase();
		let shown = 0;

		tiles.querySelectorAll( ".mvweb-core-builder__tile" ).forEach( function ( tile ) {
			const match = ( ! shelf || tile.dataset.shelf === shelf ) && ( ! query || tile.dataset.find.indexOf( query ) !== -1 );
			tile.hidden = ! match;
			shown += match ? 1 : 0;
		} );

		nothing.hidden = shown > 0;
	}

	function openLibrary( index ) {
		if ( rows().length >= config.limit ) {
			return;
		}

		insertAt = typeof index === "number" ? index : null;
		search.value = "";
		filter();
		library.showModal();
		search.focus();
	}

	search.addEventListener( "input", filter );

	search.addEventListener( "keydown", function ( event ) {
		if ( event.key !== "Enter" ) {
			return;
		}

		event.preventDefault();

		const query = search.value.trim().toLowerCase();
		const shown = Array.prototype.slice.call( tiles.querySelectorAll( ".mvweb-core-builder__tile:not([hidden])" ) );
		const first = shown.find( function ( tile ) {
			return query && tile.dataset.name.indexOf( query ) !== -1;
		} ) || shown[ 0 ];

		if ( first ) {
			first.click();
		}
	} );

	library.querySelector( ".mvweb-core-builder__library-close" ).addEventListener( "click", function () {
		library.close();
	} );

	library.addEventListener( "click", function ( event ) {
		if ( event.target === library ) {
			library.close();
		}
	} );


	( config.presets || [] ).forEach( function ( preset ) {
		const card = document.createElement( "button" );
		card.type = "button";
		card.className = "mvweb-core-builder__preset";

		const thumbs = document.createElement( "span" );
		thumbs.className = "mvweb-core-builder__preset-thumbs";
		preset.rows.forEach( function ( row ) {
			thumbs.appendChild( wireframe( row.type, "mvweb-core-builder__preset-thumb" ) );
		} );

		const name = document.createElement( "strong" );
		name.textContent = preset.label;

		const text = document.createElement( "span" );
		text.className = "mvweb-core-builder__preset-text";
		text.textContent = preset.description;

		card.appendChild( thumbs );
		card.appendChild( name );
		card.appendChild( text );
		card.size = preset.rows.length;
		card.addEventListener( "click", function () {
			const first = rows().length;

			preset.rows.forEach( function ( row ) {
				insertRow( { uid: uid(), type: row.type, v: 1, props: JSON.parse( JSON.stringify( row.props || {} ) ) } );
			} );

			sets.close();

			const added = rows()[ first ];

			if ( added ) {
				added.scrollIntoView( { block: "start", behavior: "smooth" } );
				added.toggle.focus( { preventScroll: true } );
			}
		} );
		setCards.push( card );
		sets.querySelector( ".mvweb-core-builder__presets-list" ).appendChild( card );
	} );

	setsBtn.hidden = ! setCards.length;

	setsBtn.addEventListener( "click", function () {
		sets.showModal();
	} );

	sets.querySelector( ".mvweb-core-builder__library-close" ).addEventListener( "click", function () {
		sets.close();
	} );

	sets.addEventListener( "click", function ( event ) {
		if ( event.target === sets ) {
			sets.close();
		}
	} );


	readStore().forEach( function ( row ) {
		insertRow( row );
	} );

	collect();
	live = true;

	addBtn.addEventListener( "click", function () {
		openLibrary( null );
	} );

	toggleAll.addEventListener( "click", function () {
		const open = toggleAll.dataset.open === "1";

		rows().forEach( function ( el ) {
			setOpen( el, open );
		} );
	} );

	warn.querySelector( ".mvweb-core-builder__use-template" ).addEventListener( "click", function () {
		const select = document.getElementById( "page_template" );

		if ( select ) {
			select.value = config.template;
			select.dispatchEvent( new Event( "change", { bubbles: true } ) );
			paintWarn();
		}
	} );

	const templateSelect = document.getElementById( "page_template" );

	if ( templateSelect ) {
		templateSelect.addEventListener( "change", paintWarn );
	}

	if ( root.closest( "form" ) ) {
		root.closest( "form" ).addEventListener( "submit", function () {
			rows().forEach( function ( el ) {
				el.editors.forEach( function ( built ) {
					const editor = built.ready && window.tinymce && window.tinymce.get( built.control.id );

					if ( editor && ! editor.isHidden() ) {
						editor.save();
					}

					built.push();
				} );
			} );
		} );
	}

	$( list ).sortable( {
		handle: ".mvweb-core-builder__handle",
		axis: "y",
		start: function ( event, ui ) {
			ui.item[ 0 ].wasOpen = ui.item[ 0 ].classList.contains( "is-open" );
			stopEditors( ui.item[ 0 ] );
		},
		stop: function ( event, ui ) {
			if ( ui.item[ 0 ].wasOpen ) {
				startEditors( ui.item[ 0 ] );
			}

			collect();
		},
	} );
} );
