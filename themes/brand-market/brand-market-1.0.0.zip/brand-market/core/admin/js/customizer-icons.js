( function ( api ) {
	"use strict";

	var SVG = "http://www.w3.org/2000/svg";
	var fields = window.mvwebCoreIconFields || [];

	function paint( select ) {
		var use = select.parentNode.querySelector( "use" );

		if ( use ) {
			use.setAttribute( "href", select.value ? "#mvweb-t-icon-" + select.value : "" );
		}
	}

	function decorate( select ) {
		if ( select.dataset.mvwebCoreIcon ) {
			return;
		}

		select.dataset.mvwebCoreIcon = "1";

		var wrap = document.createElement( "span" );
		var preview = document.createElementNS( SVG, "svg" );

		wrap.className = "mvweb-core-icon-pick";
		preview.setAttribute( "class", "mvweb-core-icon-pick__preview" );
		preview.setAttribute( "aria-hidden", "true" );
		preview.appendChild( document.createElementNS( SVG, "use" ) );

		select.parentNode.insertBefore( wrap, select );
		wrap.appendChild( preview );
		wrap.appendChild( select );

		select.addEventListener( "change", function () {
			paint( select );
		} );

		paint( select );
	}

	function scan( container, key ) {
		var selector = key ? '.mvweb-cz-repeater__field[data-key="' + key + '"] select' : "select";

		container.querySelectorAll( selector ).forEach( decorate );
	}

	fields.forEach( function ( field ) {
		api.control( field.setting, function ( control ) {
			control.deferred.embedded.done( function () {
				var container = control.container[ 0 ];

				scan( container, field.key );

				if ( field.key ) {
					new MutationObserver( function () {
						scan( container, field.key );
					} ).observe( container, { childList: true, subtree: true } );
				}
			} );
		} );
	} );
} )( wp.customize );
