/**
 * Dragging the cards of the order screen.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

( function ( $ ) {
	'use strict';

	$( function () {
		var list = $( '[data-mvweb-core-order]' );
		var value = $( '[data-mvweb-core-order-value]' );

		if ( ! list.length || ! value.length ) {
			return;
		}

		function sync() {
			value.val(
				list
					.children( '[data-id]' )
					.map( function () {
						return $( this ).data( 'id' );
					} )
					.get()
					.join( ',' )
			);
		}

		list.sortable( {
			items: '> [data-id]',
			placeholder: 'mvweb-core-order__item mvweb-core-order__item--drop',
			forcePlaceholderSize: true,
			tolerance: 'pointer',
			update: sync
		} );
	} );
}( jQuery ) );
