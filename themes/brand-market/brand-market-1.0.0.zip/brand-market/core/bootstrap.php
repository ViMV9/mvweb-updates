<?php
/**
 * MVweb Theme Core bootstrap.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'MVWEB_CORE_VERSION' ) ) {
	return;
}

define( 'MVWEB_CORE_VERSION', '0.1.0' );
define( 'MVWEB_CORE_DIR', __DIR__ );
define(
	'MVWEB_CORE_URI',
	str_replace(
		wp_normalize_path( get_template_directory() ),
		get_template_directory_uri(),
		wp_normalize_path( __DIR__ )
	)
);

if ( ! function_exists( 'mvweb_core_load_textdomain' ) ) {
	/**
	 * Load translations of the core strings.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_load_textdomain() {
		load_textdomain( 'mvweb-core', MVWEB_CORE_DIR . '/languages/mvweb-core-' . determine_locale() . '.mo' );
	}
}
add_action( 'after_setup_theme', 'mvweb_core_load_textdomain', 1 );

$mvweb_core_modules = array(
	'setup',
	'helpers',
	'footer-badges',
	'modules',
	'one-click',
	'product-view',
	'markets',
	'icons',
	'design',
	'breadcrumbs',
	'nav',
	'enqueue',
	'zones',
	'layouts',
	'section-common',
	'motion',
	'look-admin',
	'context-sections',
	'home-builder',
	'branches',
	'shop-data',
	'frame',
	'menu-icon',
	'user-photo',
	'design-elements',
	'cpt',
	'meta-boxes',
	'catalog',
	'catalog/cpt',
	'catalog/meta',
	'catalog/query',
	'catalog/order',
	'catalog/facets',
	'catalog-view',
	'commerce',
	'services',
	'services/cpt',
	'services/meta',
	'works',
	'schema',
	'share',
	'favorites',
	'sections',
	'search',
	'robots',
	'header-search',
	'popup',
	'toc',
	'section-presets',
	'presets',
	'meta-box-sections',
	'customizer/customizer',
	'entities',
);

if ( class_exists( 'WooCommerce' ) ) {
	$mvweb_core_modules[] = 'woocommerce';
}

foreach ( $mvweb_core_modules as $mvweb_core_module ) {
	require_once MVWEB_CORE_DIR . '/inc/' . $mvweb_core_module . '.php';
}
unset( $mvweb_core_modules, $mvweb_core_module );

/**
 * Fires once the core modules are loaded.
 *
 * @since 0.1.0
 *
 * @param string $version Core version.
 */
do_action( 'mvweb_core_loaded', MVWEB_CORE_VERSION );
