const sections = Array.prototype.slice.call( document.querySelectorAll( "[data-motion]" ) );

function prepare( section ) {
	section.querySelectorAll( "[data-rv]" ).forEach( function ( node, index ) {
		node.style.setProperty( "--mvweb-t-i", Math.min( index, 8 ) );
		node.style.setProperty( "--mvweb-t-rv-dir", node.hasAttribute( "data-rv-dir" ) ? node.getAttribute( "data-rv-dir" ) : index % 2 ? -1 : 1 );
	} );
}

function play( section ) {
	section.setAttribute( "data-in", "" );
	window.setTimeout( function () {
		section.setAttribute( "data-done", "" );
	}, 1900 );
}

function playAt( node ) {
	if ( node.nodeType !== 1 ) {
		return;
	}

	const found = node.matches( "[data-motion]" ) ? [ node ] : Array.prototype.slice.call( node.querySelectorAll( "[data-motion]" ) );

	found.forEach( function ( section ) {
		prepare( section );
		play( section );
	} );
}

sections.forEach( prepare );

if ( document.body.classList.contains( "customize-preview" ) ) {
	sections.forEach( play );

	new MutationObserver( function ( records ) {
		records.forEach( function ( record ) {
			Array.prototype.forEach.call( record.addedNodes, playAt );
		} );
	} ).observe( document.body, { childList: true, subtree: true } );
} else if ( "IntersectionObserver" in window ) {
	const observer = new IntersectionObserver(
		function ( entries ) {
			entries.forEach( function ( entry ) {
				if ( entry.isIntersecting ) {
					observer.unobserve( entry.target );
					play( entry.target );
				}
			} );
		},
		{ threshold: 0, rootMargin: "0px 0px -12% 0px" }
	);

	sections.forEach( function ( section ) {
		observer.observe( section );
	} );
} else {
	sections.forEach( play );
}
