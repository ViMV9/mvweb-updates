const jq = window.jQuery;
let timer = 0;

function update() {
	const button = document.querySelector( '.woocommerce-cart-form [name="update_cart"]' );

	if ( button ) {
		button.disabled = false;
		button.click();
	}
}

document.addEventListener( "change", function ( event ) {
	if ( ! event.target.matches || ! event.target.matches( ".woocommerce-cart-form .qty" ) ) {
		return;
	}

	window.clearTimeout( timer );
	timer = window.setTimeout( update, 600 );
} );

function heading() {
	const totals = document.querySelector( ".cart_totals[data-hero]" );
	const meta = document.querySelector( "[data-hero-meta]" );
	let facts = [];

	if ( ! totals ) {
		return;
	}

	try {
		facts = JSON.parse( totals.getAttribute( "data-hero" ) );
	} catch ( error ) {
		return;
	}

	if ( meta ) {
		meta.replaceChildren.apply(
			meta,
			facts.map( function ( text ) {
				const span = document.createElement( "span" );

				span.textContent = text;

				return span;
			} )
		);
	}

	document.querySelectorAll( "[data-cart-count]" ).forEach( function ( badge ) {
		const count = totals.getAttribute( "data-count" ) || "0";

		badge.textContent = "0" === count ? "" : count;
		badge.hidden = "0" === count;
	} );
}

if ( jq ) {
	jq( document.body ).on( "updated_wc_div updated_cart_totals", heading );

	jq( document.body ).on( "wc_cart_emptied", function () {
		window.location.reload();
	} );
}
