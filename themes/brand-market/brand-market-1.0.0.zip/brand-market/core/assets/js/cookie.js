const box = document.querySelector( "[data-cookie-name]" );
const root = document.documentElement;

function accepted( name ) {
	return document.cookie.split( "; " ).some( function ( part ) {
		return part.split( "=" )[ 0 ] === name;
	} );
}

function remember( name, days ) {
	const secure = location.protocol === "https:" ? "; Secure" : "";

	document.cookie = name + "=1; Max-Age=" + days * 86400 + "; Path=/; SameSite=Lax" + secure;
}

if ( box ) {
	const name = box.getAttribute( "data-cookie-name" );
	const days = parseInt( box.getAttribute( "data-cookie-days" ), 10 ) || 30;
	const button = box.querySelector( "[data-cookie-accept]" );
	const observer = typeof ResizeObserver === "function" ? new ResizeObserver( measure ) : null;

	function measure() {
		root.style.setProperty( "--mvweb-t-cookie-h", box.offsetHeight + "px" );
	}

	function close() {
		box.hidden = true;
		root.removeAttribute( "data-cookie-open" );
		root.style.removeProperty( "--mvweb-t-cookie-h" );

		if ( observer ) {
			observer.disconnect();
		}
	}

	if ( box.hasAttribute( "data-cookie-preview" ) || ! accepted( name ) ) {
		box.hidden = false;
		root.setAttribute( "data-cookie-open", box.getAttribute( "data-cookie-pos" ) || "bar" );
		measure();

		if ( observer ) {
			observer.observe( box );
		}
	}

	if ( button ) {
		button.addEventListener( "click", function () {
			if ( ! box.hasAttribute( "data-cookie-preview" ) ) {
				remember( name, days );
			}

			close();
		} );
	}
}
