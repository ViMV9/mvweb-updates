function initNotice(header) {
	var notice = document.querySelector('[data-notice]');
	if (!notice) {
		return function () {};
	}

	function place() {
		if (header.style.top) {
			header.style.top = '';
		}
		var position = getComputedStyle(header).position;
		if (position !== 'absolute' && position !== 'fixed') {
			return;
		}
		var bottom = notice.hidden ? 0 : notice.getBoundingClientRect().bottom;
		if (position === 'absolute') {
			bottom += window.scrollY;
		}
		if (bottom > parseFloat(getComputedStyle(header).top)) {
			header.style.top = bottom + 'px';
		}
	}

	window.addEventListener('scroll', place, { passive: true });
	window.addEventListener('resize', place);
	var key = notice.getAttribute('data-notice');
	var parts = notice.hasAttribute('data-notice-keep') ? notice.querySelectorAll('[data-notice-text], [data-notice-close]') : [notice];

	function close(state) {
		Array.prototype.forEach.call(parts, function (part) {
			part.hidden = state;
		});
	}

	try {
		if (key && window.localStorage.getItem(key)) {
			close(true);
		}
	} catch (e) {
		key = '';
	}

	var closer = notice.querySelector('[data-notice-close]');

	if (closer) {
		closer.addEventListener('click', function () {
			close(true);

			try {
				if (key) {
					window.localStorage.setItem(key, '1');
				}
			} catch (e) {
				key = '';
			}

			place();
		});
	}
	return place;
}

function initSticky(header, onChange) {
	var sentinel = document.createElement('div');
	sentinel.setAttribute('aria-hidden', 'true');
	sentinel.style.cssText = 'position:absolute;top:0;left:0;width:1px;height:1px;pointer-events:none';
	header.before(sentinel);

	if (getComputedStyle(header).position === 'sticky') {
		var spacer = document.createElement('div');
		spacer.setAttribute('data-header-spacer', '');
		spacer.setAttribute('aria-hidden', 'true');
		spacer.style.height = header.offsetHeight + 'px';
		header.after(spacer);
		header.setAttribute('data-pinned', '');

		window.addEventListener('resize', function () {
			if (!header.hasAttribute('data-stuck')) {
				spacer.style.height = header.offsetHeight + 'px';
			}
		});
	}

	new IntersectionObserver(function (entries) {
		header.toggleAttribute('data-stuck', !entries[0].isIntersecting);
		onChange();
	}, { threshold: 0 }).observe(sentinel);
}

function initMega(header) {
	var items = Array.prototype.filter.call(
		header.querySelectorAll('[data-nav-item]'),
		function (item) { return item.querySelector('[data-nav-sub]'); }
	);
	var timer = null;

	function close(item) {
		delete item.dataset.open;
		var link = item.querySelector('[data-nav-link]');
		if (link) {
			link.setAttribute('aria-expanded', 'false');
		}
	}

	function open(item) {
		items.forEach(function (other) {
			if (other !== item) {
				close(other);
			}
		});
		item.dataset.open = '';
		var link = item.querySelector('[data-nav-link]');
		if (link) {
			link.setAttribute('aria-expanded', 'true');
		}
	}

	items.forEach(function (item) {
		item.addEventListener('pointerenter', function (event) {
			if (event.pointerType === 'mouse') {
				clearTimeout(timer);
				open(item);
			}
		});

		item.addEventListener('pointerleave', function (event) {
			if (event.pointerType === 'mouse') {
				timer = setTimeout(function () { close(item); }, 160);
			}
		});

		item.addEventListener('focusin', function (event) {
			if (event.target.matches(':focus-visible')) {
				open(item);
			}
		});

		item.addEventListener('focusout', function (event) {
			if (!item.contains(event.relatedTarget)) {
				close(item);
			}
		});

		var link = item.querySelector('[data-nav-link]');
		if (link) {
			link.setAttribute('aria-expanded', 'false');
			link.addEventListener('click', function (event) {
				if (window.matchMedia('(hover: none)').matches) {
					event.preventDefault();
					if (item.dataset.open === '') {
						close(item);
					} else {
						open(item);
					}
				}
			});
		}

		item.querySelectorAll('[data-mega-tab]').forEach(function (tab) {
			function activate() {
				var panelId = tab.getAttribute('aria-controls');
				item.querySelectorAll('[data-mega-tab]').forEach(function (other) {
					other.setAttribute('aria-selected', String(other === tab));
				});
				item.querySelectorAll('[data-mega-panel]').forEach(function (panel) {
					panel.toggleAttribute('data-active', panel.id === panelId);
				});
			}
			tab.addEventListener('pointerenter', activate);
			tab.addEventListener('focus', activate);
		});
	});

	document.addEventListener('click', function (event) {
		items.forEach(function (item) {
			if (!item.contains(event.target)) {
				close(item);
			}
		});
	});

	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape') {
			var current = Array.prototype.filter.call(items, function (item) {
				return item.contains(document.activeElement);
			})[0];
			var link = current && current.querySelector('[data-nav-link]');

			items.forEach(close);

			if (link) {
				link.focus();
			}
		}
	});
}

function initDrawer() {
	var drawer = document.querySelector('[data-drawer]');
	if (!drawer) {
		return;
	}

	function expand(open) {
		document.querySelectorAll('[data-drawer-open]').forEach(function (btn) {
			btn.setAttribute('aria-expanded', String(open));
		});
	}

	document.addEventListener('click', function (event) {
		if (event.target.closest('[data-drawer-open]')) {
			drawer.showModal();
			expand(true);
		} else if (event.target === drawer || event.target.closest('[data-drawer-close]')) {
			drawer.close();
		}
	});

	drawer.addEventListener('close', function () {
		expand(false);
	});
}

function initSearch() {
	var panel = document.querySelector('[data-search-panel]');
	if (!panel) {
		return;
	}

	var lastFocused = null;

	function setState(open) {
		if (open === !panel.hidden) {
			return;
		}
		panel.hidden = !open;
		document.querySelectorAll('[data-search-toggle]').forEach(function (btn) {
			btn.setAttribute('aria-expanded', String(open));
		});

		if (open) {
			lastFocused = document.activeElement;
			var input = panel.querySelector('input[type="search"]');
			if (input) {
				input.focus();
			}
		} else if (lastFocused && (panel.contains(document.activeElement) || document.activeElement === document.body)) {
			lastFocused.focus();
		}
	}

	document.addEventListener('click', function (event) {
		if (event.target.closest('[data-search-toggle]')) {
			setState(panel.hidden);
		} else if (event.target.closest('[data-search-close]') || !panel.contains(event.target)) {
			setState(false);
		}
	});

	document.addEventListener('keydown', function (event) {
		if (event.key === 'Escape') {
			setState(false);
		}
	});
}

function init() {
	var header = document.querySelector('[data-header]');
	if (!header) {
		return;
	}
	var place = initNotice(header);
	initSticky(header, place);
	place();
	initMega(header);
	initDrawer();
	initSearch();
}

init();
