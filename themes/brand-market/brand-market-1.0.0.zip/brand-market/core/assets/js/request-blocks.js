( function () {
	"use strict";

	const settings = window.wc.wcSettings.getSetting( "mvweb_request_data", {} );
	const { createElement } = window.wp.element;
	const { decodeEntities } = window.wp.htmlEntities;
	const title = decodeEntities( settings.title || "" );

	function Content() {
		return createElement( "p", null, decodeEntities( settings.description || "" ) );
	}

	window.wc.wcBlocksRegistry.registerPaymentMethod( {
		name: "mvweb_request",
		label: createElement( "span", null, title ),
		ariaLabel: title,
		content: createElement( Content ),
		edit: createElement( Content ),
		canMakePayment: function () {
			return true;
		},
		supports: { features: settings.supports || [ "products" ] },
	} );
} )();
