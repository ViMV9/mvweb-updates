const data = JSON.parse(
	document.getElementById( "wp-script-module-data-@mvweb-core/compare" )?.textContent || "{}"
);

const KEY = "mvweb_compare";
const GROUPS = "mvweb_compare_cats";

function readJson( key, fallback ) {
	try {
		const raw = JSON.parse( window.localStorage.getItem( key ) );

		return raw === null ? fallback : raw;
	} catch ( error ) {
		return fallback;
	}
}

function writeJson( key, value ) {
	try {
		window.localStorage.setItem( key, JSON.stringify( value ) );
	} catch ( error ) {
		return;
	}
}

function readList() {
	const raw = readJson( KEY, [] );

	return Array.isArray( raw ) ? raw.map( Number ).filter( Boolean ) : [];
}

let list = data.loggedIn ? ( data.stored || [] ).map( Number ) : readList();
const cats = Object.assign( {}, data.loggedIn ? data.cats : readJson( GROUPS, {} ) );
let ticket = 0;
let rendering = 0;
let category = 0;
let onlyDiff = false;
let toastNode = null;
let toastTimer = 0;

function send( path, body ) {
	return fetch( data.root + path, {
		method: "POST",
		keepalive: true,
		credentials: "same-origin",
		headers: {
			"Content-Type": "application/json",
			"X-WP-Nonce": data.nonce
		},
		body: JSON.stringify( body )
	} ).then( function ( response ) {
		return response.ok ? response.json() : Promise.reject( response.status );
	} );
}

function keep() {
	if ( ! data.loggedIn ) {
		writeJson( KEY, list );
		writeJson( GROUPS, cats );
	}
}

function persist() {
	if ( ! data.loggedIn ) {
		keep();

		return Promise.resolve();
	}

	ticket += 1;

	const mine = ticket;

	return send( "", { ids: list } ).then( function ( result ) {
		if ( mine === ticket ) {
			list = result.ids.map( Number );
			Object.assign( cats, result.cats );
		}
	} );
}

function toast( text ) {
	if ( ! toastNode ) {
		toastNode = document.createElement( "div" );
		toastNode.setAttribute( "data-compare-toast", "" );
		toastNode.setAttribute( "role", "status" );
		document.body.appendChild( toastNode );
	}

	toastNode.textContent = text;
	toastNode.setAttribute( "data-visible", "" );
	window.clearTimeout( toastTimer );
	toastTimer = window.setTimeout( function () {
		toastNode.removeAttribute( "data-visible" );
		toastNode.textContent = "";
	}, 2600 );
}

function paint() {
	document.querySelectorAll( "[data-compare-count]" ).forEach( function ( node ) {
		node.textContent = String( list.length );
		node.hidden = list.length === 0;
	} );

	document.querySelectorAll( "[data-compare-toggle]" ).forEach( function ( button ) {
		const active = list.indexOf( Number( button.dataset.compareToggle ) ) !== -1;

		button.setAttribute( "aria-pressed", String( active ) );
		button.title = active ? data.added : data.add;
		button.querySelectorAll( "[data-compare-label]" ).forEach( function ( label ) {
			label.textContent = button.title;
		} );
	} );
}

function toggle( button ) {
	const id = Number( button.dataset.compareToggle );

	if ( ! id ) {
		return;
	}

	const before = list;
	const at = list.indexOf( id );

	if ( at === -1 ) {
		const group = Number( button.dataset.compareCat || 0 );
		const taken = list.filter( function ( other ) {
			return Number( cats[ other ] || 0 ) === group;
		} ).length;

		if ( taken >= data.max ) {
			toast( data.toast.limit );

			return;
		}

		cats[ id ] = group;
		list = list.concat( id );
		toast( data.toast.added );
	} else {
		list = list.slice( 0, at ).concat( list.slice( at + 1 ) );
		toast( data.toast.removed );
	}

	paint();

	persist().then( function () {
		if ( list.indexOf( id ) === -1 && at === -1 ) {
			toast( data.toast.limit );
		}

		paint();
	} ).catch( function () {
		list = before;
		paint();
		toast( data.toast.failed );
	} );
}

function box() {
	return document.querySelector( "[data-compare-page]" );
}

function fill( target, html ) {
	const parsed = new DOMParser().parseFromString( html, "text/html" );

	target.replaceChildren.apply( target, Array.prototype.slice.call( parsed.body.childNodes ) );
}

function meta( parts ) {
	document.querySelectorAll( "[data-compare-meta]" ).forEach( function ( node ) {
		node.replaceChildren.apply(
			node,
			( parts || [] ).map( function ( text ) {
				const span = document.createElement( "span" );

				span.textContent = text;

				return span;
			} )
		);
		node.hidden = ! parts || parts.length === 0;
	} );
}

function syncDiff() {
	const table = document.querySelector( "[data-cmp]" );

	if ( ! table ) {
		return;
	}

	table.toggleAttribute( "data-diff", onlyDiff );
	table.querySelectorAll( "[data-compare-diff]" ).forEach( function ( input ) {
		input.checked = onlyDiff;
	} );
}

function showEmpty( root ) {
	root.querySelector( "[data-compare-body]" ).replaceChildren();
	root.querySelector( "[data-compare-empty]" ).hidden = false;
	root.querySelector( "[data-compare-error]" ).hidden = true;
	meta( [] );
}

function render() {
	const root = box();

	if ( ! root ) {
		return;
	}

	if ( list.length === 0 ) {
		showEmpty( root );

		return;
	}

	rendering += 1;

	const mine = rendering;
	const body = root.querySelector( "[data-compare-body]" );

	send( "/table", { ids: list, cat: category } ).then( function ( result ) {
		if ( mine !== rendering ) {
			return;
		}

		list = result.ids.map( Number );
		Object.assign( cats, result.cats );
		category = Number( result.cat );
		keep();

		if ( list.length === 0 ) {
			showEmpty( root );
			paint();

			return;
		}

		const hadSelect = document.activeElement && document.activeElement.matches( "[data-compare-cat]" );

		fill( body, result.html );
		root.querySelector( "[data-compare-empty]" ).hidden = true;
		root.querySelector( "[data-compare-error]" ).hidden = true;
		meta( result.meta );
		syncDiff();
		paint();

		if ( hadSelect ) {
			body.querySelector( "[data-compare-cat]" )?.focus();
		}
	} ).catch( function () {
		if ( mine !== rendering ) {
			return;
		}

		root.querySelector( "[data-compare-error]" ).hidden = false;
		root.querySelector( "[data-compare-empty]" ).hidden = true;
	} );
}

function remove( button ) {
	const id = Number( button.dataset.compareRemove );
	const before = list;

	list = list.filter( function ( other ) {
		return other !== id;
	} );

	paint();
	render();

	const body = box()?.querySelector( "[data-compare-body]" );

	if ( body ) {
		body.focus();
	}

	persist().catch( function () {
		list = before;
		paint();
		render();
		toast( data.toast.failed );
	} );
}

function start() {
	document.addEventListener( "click", function ( event ) {
		const add = event.target.closest( "[data-compare-toggle]" );
		const drop = event.target.closest( "[data-compare-remove]" );

		if ( add ) {
			event.preventDefault();
			toggle( add );
		} else if ( drop ) {
			event.preventDefault();
			remove( drop );
		}
	} );

	document.addEventListener( "change", function ( event ) {
		if ( event.target.matches( "[data-compare-cat]" ) ) {
			category = Number( event.target.value );
			render();
		} else if ( event.target.matches( "[data-compare-diff]" ) ) {
			onlyDiff = event.target.checked;
			syncDiff();
		}
	} );

	const local = readList();

	if ( data.loggedIn && local.length ) {
		send( "", { ids: local, merge: true } ).then( function ( result ) {
			list = result.ids.map( Number );
			Object.assign( cats, result.cats );
			writeJson( KEY, [] );
			paint();
			render();
		} ).catch( render );

		paint();

		return;
	}

	paint();
	render();
}

start();
