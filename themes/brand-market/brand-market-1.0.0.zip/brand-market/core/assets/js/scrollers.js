document.querySelectorAll("[data-scroller]").forEach(function (el) {
	new ResizeObserver(function () {
		if (el.scrollWidth > el.clientWidth + 1) {
			el.setAttribute("tabindex", "0");
			el.setAttribute("role", "group");
			el.setAttribute("aria-label", el.getAttribute("data-scroller"));
		} else {
			el.removeAttribute("tabindex");
			el.removeAttribute("role");
			el.removeAttribute("aria-label");
		}
	}).observe(el);
});
