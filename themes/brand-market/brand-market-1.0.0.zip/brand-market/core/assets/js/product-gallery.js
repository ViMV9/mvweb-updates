document.querySelectorAll("[data-product-gallery]").forEach(function (gallery) {
	const main = gallery.querySelector("[data-gallery-main]");
	const zoom = gallery.querySelector("[data-gallery-zoom]");
	const thumbs = Array.from(gallery.querySelectorAll("[data-gallery-thumb]"));
	const prevs = gallery.querySelectorAll("[data-gallery-prev]");
	const nexts = gallery.querySelectorAll("[data-gallery-next]");
	const up = gallery.querySelector("[data-gallery-up]");
	const down = gallery.querySelector("[data-gallery-down]");
	let current = 0;

	if (!main || thumbs.length < 2) {
		prevs.forEach(function (btn) { btn.hidden = true; });
		nexts.forEach(function (btn) { btn.hidden = true; });
		return;
	}

	const rail = thumbs[0].parentElement;

	function edges() {
		const room = rail.scrollHeight - rail.clientHeight;

		up.hidden = down.hidden = room < 2;
		up.disabled = rail.scrollTop < 2;
		down.disabled = rail.scrollTop > room - 2;
	}

	function reveal(thumb) {
		const box = rail.getBoundingClientRect();
		const spot = thumb.getBoundingClientRect();

		rail.scrollBy({
			top: Math.min(0, spot.top - box.top - 4) || Math.max(0, spot.bottom - box.bottom + 4),
			left: Math.min(0, spot.left - box.left - 4) || Math.max(0, spot.right - box.right + 4)
		});
	}

	if (up && down) {
		up.addEventListener("click", function () {
			rail.scrollBy({ top: -rail.clientHeight * 0.75 });
		});

		down.addEventListener("click", function () {
			rail.scrollBy({ top: rail.clientHeight * 0.75 });
		});

		rail.addEventListener("scroll", edges, { passive: true });
		new ResizeObserver(edges).observe(rail);
	}

	function show(index) {
		current = (index + thumbs.length) % thumbs.length;

		const thumb = thumbs[current];
		const image = thumb.querySelector("img");
		const srcset = thumb.getAttribute("data-gallery-srcset");

		if (srcset) {
			main.srcset = srcset;
		} else {
			main.removeAttribute("srcset");
		}

		main.src = thumb.getAttribute("data-gallery-full") || image.src;
		main.alt = image.alt;

		if (zoom) {
			zoom.href = thumb.dataset.galleryLarge;
		}

		thumbs.forEach(function (other, i) {
			other.setAttribute("aria-current", i === current ? "true" : "false");
		});

		reveal(thumb);
	}

	thumbs.forEach(function (thumb, i) {
		thumb.addEventListener("click", function () {
			show(i);
		});
	});

	prevs.forEach(function (btn) {
		btn.addEventListener("click", function () {
			show(current - 1);
		});
	});

	nexts.forEach(function (btn) {
		btn.addEventListener("click", function () {
			show(current + 1);
		});
	});

	show(0);
});
