const data = JSON.parse(
	document.getElementById("wp-script-module-data-@mvweb-core/prose-tables")?.textContent || "{}"
);

document.querySelectorAll("[data-prose] table").forEach(function (table) {
	const parent = table.parentNode;

	if (parent.hasAttribute && parent.hasAttribute("data-table-scroll")) {
		return;
	}

	const wrap = document.createElement("div");
	wrap.setAttribute("data-table-scroll", "");

	parent.insertBefore(wrap, table);
	wrap.appendChild(table);

	const observer = new ResizeObserver(function () {
		if (wrap.scrollWidth > wrap.clientWidth + 1) {
			wrap.setAttribute("tabindex", "0");
			wrap.setAttribute("role", "region");
			wrap.setAttribute("aria-label", data.scrollLabel || "");
		} else {
			wrap.removeAttribute("tabindex");
			wrap.removeAttribute("role");
			wrap.removeAttribute("aria-label");
		}
	});

	observer.observe(wrap);
	observer.observe(table);
});
