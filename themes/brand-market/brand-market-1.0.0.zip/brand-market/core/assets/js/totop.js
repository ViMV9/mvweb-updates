const btn = document.querySelector('[data-totop]');

if (btn) {
	const sentinel = document.createElement('div');
	sentinel.setAttribute('aria-hidden', 'true');
	sentinel.style.cssText = 'position:absolute;top:100vh;left:0;width:1px;height:1px;pointer-events:none';
	document.body.prepend(sentinel);

	let scrolled = false;
	let footerVisible = false;

	function sync() {
		btn.toggleAttribute('data-visible', scrolled && !footerVisible);
	}

	new IntersectionObserver(function (entries) {
		scrolled = !entries[0].isIntersecting;
		sync();
	}, { threshold: 0 }).observe(sentinel);

	const footer = document.querySelector('[data-footer]');
	if (footer) {
		new IntersectionObserver(function (entries) {
			footerVisible = entries[0].isIntersecting;
			sync();
		}, { rootMargin: '0px 0px -60% 0px' }).observe(footer);
	}

	btn.addEventListener('click', function () {
		window.scrollTo({ top: 0 });
	});
}
