const list = document.querySelector("[data-catalog-grid]");
const group = document.querySelector("[data-view-switch]");

if (list && group) {
	const buttons = group.querySelectorAll("[data-view]");
	const cookie = group.getAttribute("data-cookie") || "mvweb_catalog_view";
	const secure = location.protocol === "https:" ? ";secure" : "";

	buttons.forEach(function (button) {
		button.addEventListener("click", function () {
			const view = button.getAttribute("data-view");

			list.setAttribute("data-view", view);
			buttons.forEach(function (other) {
				other.setAttribute("aria-pressed", other === button ? "true" : "false");
			});
			document.cookie = cookie + "=" + encodeURIComponent(view) + ";path=/;max-age=" + 30 * 24 * 60 * 60 + ";samesite=lax" + secure;
		});
	});
}
