const root = document.querySelector( "[data-minicart]" );
const modal = !! root && "function" === typeof root.showModal;
const jq = window.jQuery;
const reach = 'button, [href], input:not([type="hidden"]), select, textarea';
let pending = "";
let held = false;
let live = document.querySelector( "[data-minicart-live]" );

if ( ! live ) {
	live = document.createElement( "div" );
	live.className = "screen-reader-text";
	live.setAttribute( "role", "status" );
	live.setAttribute( "aria-live", "polite" );
	( root || document.body ).appendChild( live );
}

function panel() {
	return root ? root.querySelector( "[data-minicart-panel]" ) : null;
}

function isOpen() {
	return !! root && root.open;
}

function inside() {
	const box = panel();

	return !! box && box.contains( document.activeElement );
}

function say( text ) {
	live.textContent = "";

	if ( text ) {
		window.setTimeout( function () {
			live.textContent = text;
		}, 60 );
	}
}

function announce() {
	const box = panel();
	const count = document.querySelector( "[data-cart-count][data-announce]" );

	say( box ? box.getAttribute( "data-announce" ) : count ? count.getAttribute( "data-announce" ) : "" );
}

function focusIn() {
	const box = panel();
	const first = box ? box.querySelector( reach ) : null;

	if ( first ) {
		first.focus();
	}
}

function open() {
	if ( modal && ! root.open ) {
		root.showModal();
	}
}

function afterChange() {
	const kind = pending;

	pending = "";

	if ( held && isOpen() ) {
		focusIn();
	}

	held = false;

	if ( "add" === kind ) {
		open();
	}

	announce();
}

document.addEventListener( "click", function ( event ) {
	const link = event.target.closest( "[data-cart-open]" );

	if ( link && modal && ! event.defaultPrevented && 0 === event.button && ! ( event.metaKey || event.ctrlKey || event.shiftKey || event.altKey ) ) {
		event.preventDefault();
		open();

		return;
	}

	if ( root && root.contains( event.target ) && ( event.target === root || event.target.closest( "[data-minicart-close]" ) ) ) {
		root.close();
	}
} );

if ( root ) {
	root.addEventListener( "close", function () {
		const back = document.activeElement === document.body ? document.querySelector( "[data-cart-open]" ) : null;

		if ( back ) {
			back.focus();
		}
	} );
}

if ( jq ) {
	jq( document.body ).on( "added_to_cart", function () {
		pending = "add";
		held = isOpen() && inside();
	} );

	jq( document.body ).on( "removed_from_cart", function () {
		pending = "remove";
		held = isOpen() && inside();
	} );

	jq( document.body ).on( "wc_fragments_loaded", function () {
		if ( pending ) {
			afterChange();
		}
	} );
}

document.addEventListener( "submit", function ( event ) {
	const form = event.target;
	const params = window.wc_add_to_cart_params;

	if ( ! jq || ! params || ! params.wc_ajax_url || ! form.matches || ! form.matches( "form.cart" ) || form.dataset.mvwebNative || form.classList.contains( "grouped_form" ) ) {
		return;
	}

	const data = new FormData( form );
	const button = event.submitter || form.querySelector( '[type="submit"]' );
	const variation = parseInt( data.get( "variation_id" ), 10 ) || 0;
	const id = variation || parseInt( data.get( "add-to-cart" ) || ( button ? button.value : "" ), 10 ) || 0;

	if ( ! id || ( form.classList.contains( "variations_form" ) && ! variation ) ) {
		return;
	}

	event.preventDefault();

	const body = new URLSearchParams();

	body.set( "product_id", String( id ) );
	body.set( "quantity", String( data.get( "quantity" ) || 1 ) );

	if ( button ) {
		button.classList.remove( "added" );
		button.classList.add( "loading" );
	}

	function native() {
		if ( button ) {
			button.classList.remove( "loading" );
		}

		form.dataset.mvwebNative = "1";
		form.requestSubmit( button || undefined );
	}

	fetch( params.wc_ajax_url.toString().replace( "%%endpoint%%", "add_to_cart" ), { method: "POST", body: body, credentials: "same-origin" } )
		.then( function ( response ) {
			return response.json();
		} )
		.then( function ( result ) {
			if ( ! result || result.error || ! result.fragments ) {
				native();

				return;
			}

			jq( document.body ).trigger( "added_to_cart", [ result.fragments, result.cart_hash, button ? jq( button ) : undefined ] );
		} )
		.catch( native );
} );
