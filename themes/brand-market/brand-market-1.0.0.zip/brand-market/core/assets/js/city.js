const box = document.querySelector( "[data-city-box]" );

if ( box ) {
	const pop = box.querySelector( "[data-city-pop]" );
	const toggle = box.querySelector( "[data-city-toggle]" );
	const tip = box.querySelector( "[data-city-tip]" );
	const answered = "mvweb_city_answered";
	const chosen = "mvweb_city";

	function read( name ) {
		const found = document.cookie.split( "; " ).filter( function ( part ) {
			return part.indexOf( name + "=" ) === 0;
		} );

		return found.length ? decodeURIComponent( found[ 0 ].slice( name.length + 1 ) ) : "";
	}

	function write( name, value, days ) {
		const secure = location.protocol === "https:" ? "; Secure" : "";

		document.cookie = name + "=" + encodeURIComponent( value ) + "; max-age=" + days * 86400 + "; path=/; samesite=lax" + secure;
	}

	function remember() {
		write( answered, "1", 60 );

		if ( tip ) {
			tip.hidden = true;
		}
	}

	function show( open ) {
		pop.hidden = ! open;
		toggle.setAttribute( "aria-expanded", String( open ) );

		if ( open && tip ) {
			tip.hidden = true;
		}
	}

	toggle.addEventListener( "click", function () {
		show( pop.hidden );
	} );

	box.querySelectorAll( "[data-city-pick]" ).forEach( function ( button ) {
		button.addEventListener( "click", function () {
			write( chosen, button.getAttribute( "data-city-pick" ), 365 );
			write( answered, "1", 60 );

			if ( button.getAttribute( "aria-selected" ) === "true" ) {
				remember();
				show( false );
				toggle.focus();

				return;
			}

			window.location.reload();
		} );
	} );

	if ( tip ) {
		tip.hidden = read( answered ) === "1";

		tip.querySelector( "[data-city-yes]" ).addEventListener( "click", function () {
			write( chosen, tip.getAttribute( "data-city-key" ) || read( chosen ), 365 );
			remember();
		} );

		tip.querySelector( "[data-city-no]" ).addEventListener( "click", function () {
			tip.hidden = true;
			show( true );
		} );
	}

	document.querySelectorAll( "[data-city-reset]" ).forEach( function ( button ) {
		button.addEventListener( "click", function () {
			write( answered, "", 0 );
			show( false );

			if ( tip ) {
				tip.hidden = false;
			}
		} );
	} );

	document.addEventListener( "click", function ( event ) {
		if ( ! pop.hidden && ! box.contains( event.target ) ) {
			show( false );
		}
	} );

	document.addEventListener( "keydown", function ( event ) {
		if ( event.key === "Escape" && ! pop.hidden ) {
			show( false );
			toggle.focus();
		}
	} );
}
