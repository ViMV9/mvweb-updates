const data = JSON.parse(
	document.getElementById( "wp-script-module-data-@mvweb-core/account" )?.textContent || "{}"
);

function togglePassword( button ) {
	const input = button.parentNode.querySelector( "input" );

	if ( ! input ) {
		return;
	}

	const show = "password" === input.type;
	const label = show ? data.hide : data.show;

	input.type = show ? "text" : "password";
	button.setAttribute( "aria-pressed", show ? "true" : "false" );

	if ( label ) {
		button.title = label;
		button.querySelectorAll( ".screen-reader-text" ).forEach( function ( node ) {
			node.textContent = label;
		} );
	}
}

function toggleNav( button ) {
	const open = "true" !== button.getAttribute( "aria-expanded" );

	button.closest( "nav" ).toggleAttribute( "data-open", open );
	button.setAttribute( "aria-expanded", open ? "true" : "false" );
}

function score( value ) {
	if ( value.length < 6 ) {
		return 0;
	}

	let points = 0;

	points += value.length >= 8 ? 1 : 0;
	points += value.length >= 12 ? 1 : 0;
	points += /[a-zа-яё]/.test( value ) && /[A-ZА-ЯЁ]/.test( value ) ? 1 : 0;
	points += /\d/.test( value ) && /\D/.test( value ) ? 1 : 0;
	points += /[^\p{L}\d]/u.test( value ) ? 1 : 0;

	return Math.min( 4, Math.max( 1, points ) );
}

function setupStrength( input ) {
	const meter = document.querySelector( "[data-strength]" );

	if ( ! meter ) {
		return;
	}

	const bars = meter.querySelectorAll( "i" );
	const label = meter.querySelector( "[data-strength-label]" );
	const names = Array.isArray( data.strength ) ? data.strength : [];

	input.addEventListener( "input", function () {
		const level = input.value ? score( input.value ) : -1;

		meter.hidden = level < 0;
		bars.forEach( function ( bar, index ) {
			bar.toggleAttribute( "data-on", index < level );
		} );

		if ( label && level >= 0 ) {
			label.textContent = names[ level ] || "";
		}
	} );
}

function setupResend( link ) {
	const total = parseInt( link.dataset.resend, 10 ) || 60;
	const ready = link.dataset.ready || link.textContent;
	const pattern = data.wait || "%s";
	let left = total;

	link.addEventListener( "click", function ( event ) {
		if ( left > 0 ) {
			event.preventDefault();
		}
	} );

	link.setAttribute( "aria-disabled", "true" );
	link.setAttribute( "tabindex", "-1" );
	link.textContent = pattern.replace( "%s", String( left ) );

	const timer = window.setInterval( function () {
		left -= 1;

		if ( left > 0 ) {
			link.textContent = pattern.replace( "%s", String( left ) );
			return;
		}

		window.clearInterval( timer );
		link.removeAttribute( "aria-disabled" );
		link.removeAttribute( "tabindex" );
		link.textContent = ready;
	}, 1000 );
}

document.addEventListener( "click", function ( event ) {
	const pass = event.target.closest( "[data-pass-toggle]" );
	const nav = event.target.closest( "[data-accnav-toggle]" );

	if ( pass ) {
		togglePassword( pass );
	}

	if ( nav ) {
		toggleNav( nav );
	}
} );

document.querySelectorAll( "[data-strength-input]" ).forEach( setupStrength );
document.querySelectorAll( "[data-resend]" ).forEach( setupResend );
