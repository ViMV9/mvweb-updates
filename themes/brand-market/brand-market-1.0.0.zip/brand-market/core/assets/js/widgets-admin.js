( function () {
	"use strict";

	document.addEventListener( "click", function ( event ) {
		const button = event.target.closest( "[data-mvweb-parts] [data-move]" );

		if ( ! button ) {
			return;
		}

		const item = button.closest( "[data-part]" );
		const box = button.closest( "[data-mvweb-parts]" );
		const step = parseInt( button.getAttribute( "data-move" ), 10 );
		const sibling = step < 0 ? item.previousElementSibling : item.nextElementSibling;
		const order = box.querySelector( "[data-mvweb-order]" );

		if ( ! sibling ) {
			return;
		}

		if ( step < 0 ) {
			sibling.before( item );
		} else {
			sibling.after( item );
		}

		order.value = Array.prototype.map.call( box.querySelectorAll( "[data-part]" ), function ( row ) {
			return row.getAttribute( "data-part" );
		} ).join( "," );
		order.dispatchEvent( new Event( "change", { bubbles: true } ) );
		button.focus();
	} );
}() );
