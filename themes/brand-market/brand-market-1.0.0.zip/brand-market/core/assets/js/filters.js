document.querySelectorAll("[data-sort] select").forEach(function (select) {
	select.addEventListener("change", function () {
		select.form.submit();
	});
});

document.querySelectorAll("[data-filters] form").forEach(function (form) {
	form.addEventListener("submit", function (event) {
		const fields = new FormData(form);
		const query = new URLSearchParams();
		const groups = new Set();
		const url = new URL(form.action, location.href);

		fields.forEach(function (value, name) {
			if (name.startsWith("filter_")) {
				groups.add(name);
			} else if (!name.startsWith("query_type_") && String(value).trim()) {
				query.append(name, value);
			}
		});

		groups.forEach(function (name) {
			const type = "query_type_" + name.slice(7);

			query.set(name, fields.getAll(name).join(","));

			if (fields.has(type)) {
				query.set(type, fields.get(type));
			}
		});

		event.preventDefault();
		url.search = query.toString();
		location.assign(url);
	});
});
