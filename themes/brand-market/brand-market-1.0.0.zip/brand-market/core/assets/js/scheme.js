const COOKIE = 'mvweb_scheme';
const data = JSON.parse(document.getElementById('wp-script-module-data-@mvweb-core/scheme')?.textContent || '{}');
const MAX_AGE = 60 * 60 * 24 * 365;

function read() {
	const match = document.cookie.match(new RegExp('(?:^|; )' + COOKIE + '=(light|dark)'));
	return match ? match[1] : null;
}

function write(value) {
	const secure = location.protocol === 'https:' ? '; Secure' : '';
	document.cookie = COOKIE + '=' + value + '; path=/; max-age=' + MAX_AGE + '; samesite=lax' + secure;
}

function apply(value) {
	document.documentElement.dataset.scheme = value;

	document.querySelectorAll('[data-scheme-toggle]').forEach(function (btn) {
		const dark = value === 'dark';
		btn.setAttribute('aria-pressed', String(dark));
		if (data.toDark && btn.title) {
			btn.title = dark ? data.toLight : data.toDark;
			btn.querySelectorAll('[data-scheme-sr]').forEach(function (label) {
				label.textContent = btn.title;
			});
		}
		btn.querySelectorAll('[data-scheme-icon]').forEach(function (icon) {
			icon.toggleAttribute('hidden', icon.dataset.schemeIcon !== (dark ? 'dark' : 'light'));
		});
		btn.querySelectorAll('[data-scheme-label]').forEach(function (label) {
			if (data.dark) {
				label.textContent = dark ? data.light : data.dark;
			}
		});
	});
}

apply(read() || document.documentElement.dataset.scheme || 'light');

document.addEventListener('click', function (event) {
	if (!event.target.closest('[data-scheme-toggle]')) {
		return;
	}
	const next = document.documentElement.dataset.scheme === 'dark' ? 'light' : 'dark';
	write(next);
	apply(next);
});
