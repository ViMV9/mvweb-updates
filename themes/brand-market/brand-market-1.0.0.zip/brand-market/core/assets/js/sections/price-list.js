document.querySelectorAll("[data-tabs]").forEach(function (box) {
	var tabs = box.querySelectorAll("[data-tab]");
	var panels = box.querySelectorAll("[data-tab-panel]");

	if (tabs.length < 2) {
		return;
	}

	function pick(id) {
		tabs.forEach(function (tab) {
			var on = tab.getAttribute("data-tab") === id;

			tab.setAttribute("aria-selected", on ? "true" : "false");
			tab.tabIndex = on ? 0 : -1;
		});
		panels.forEach(function (panel) {
			panel.hidden = panel.getAttribute("data-tab-panel") !== id;
		});
	}

	tabs.forEach(function (tab, index) {
		tab.addEventListener("click", function () {
			pick(tab.getAttribute("data-tab"));
		});
		tab.addEventListener("keydown", function (event) {
			var step = event.key === "ArrowRight" ? 1 : event.key === "ArrowLeft" ? -1 : 0;

			if (!step) {
				return;
			}

			var next = tabs[(index + step + tabs.length) % tabs.length];

			pick(next.getAttribute("data-tab"));
			next.focus();
		});
	});
});
