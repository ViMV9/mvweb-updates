document.querySelectorAll( "[data-docs]" ).forEach( function ( list ) {
	const box = list.parentNode.querySelector( "[data-docs-box]" );

	if ( ! box || ! box.showModal ) {
		return;
	}

	const img = box.querySelector( "img" );

	list.addEventListener( "click", function ( event ) {
		const link = event.target.closest( "[data-docs-open]" );

		if ( ! link ) {
			return;
		}

		event.preventDefault();
		img.src = link.href;
		img.alt = link.querySelector( "img" ) ? link.querySelector( "img" ).alt : "";
		box.showModal();
	} );

	box.querySelector( "[data-docs-close]" ).addEventListener( "click", function () {
		box.close();
	} );

	box.addEventListener( "click", function ( event ) {
		if ( event.target === box ) {
			box.close();
		}
	} );
} );
