function player( href ) {
	let url;

	try {
		url = new URL( href, window.location.href );
	} catch ( error ) {
		return null;
	}

	if ( url.protocol !== "https:" && url.protocol !== "http:" ) {
		return null;
	}

	const host = url.hostname.replace( /^www\./, "" );
	const path = url.pathname;
	let match;

	if ( /\.(mp4|webm|ogg|m4v|mov)$/i.test( path ) ) {
		return { file: url.href };
	}

	if ( host === "youtu.be" ) {
		match = path.match( /^\/([\w-]{6,})/ );
	} else if ( /(^|\.)youtube\.com$/.test( host ) ) {
		match = path.match( /^\/(?:shorts|embed|live)\/([\w-]{6,})/ ) || [ null, url.searchParams.get( "v" ) ];
	}

	if ( match && match[ 1 ] && /^[\w-]{6,}$/.test( match[ 1 ] ) ) {
		return { frame: "https://www.youtube-nocookie.com/embed/" + match[ 1 ] + "?autoplay=1&rel=0&playsinline=1" };
	}

	if ( host === "rutube.ru" ) {
		match = path.match( /^\/(?:video|shorts|play\/embed)\/([0-9a-f]{32})/ );

		if ( match ) {
			return { frame: "https://rutube.ru/play/embed/" + match[ 1 ] };
		}
	}

	if ( host === "vk.com" || host === "vkvideo.ru" || host === "vk.ru" ) {
		match = path.match( /video(-?\d+)_(\d+)/ );

		if ( match ) {
			const hash = url.searchParams.get( "hash" );

			return { frame: "https://vk.com/video_ext.php?oid=" + match[ 1 ] + "&id=" + match[ 2 ] + ( hash ? "&hash=" + encodeURIComponent( hash ) : "" ) + "&autoplay=1" };
		}
	}

	if ( host === "vimeo.com" ) {
		match = path.match( /^\/(\d+)/ );

		if ( match ) {
			return { frame: "https://player.vimeo.com/video/" + match[ 1 ] + "?autoplay=1" };
		}
	}

	return null;
}

document.querySelectorAll( "[data-video-dialog]" ).forEach( function ( dialog ) {
	const section = dialog.closest( "section" );
	const stage = dialog.querySelector( "[data-video-stage]" );

	if ( ! section || ! stage || ! dialog.showModal ) {
		return;
	}

	section.addEventListener( "click", function ( event ) {
		const link = event.target.closest( "[data-video-play]" );

		if ( ! link || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey ) {
			return;
		}

		const media = player( link.href );

		if ( ! media ) {
			return;
		}

		event.preventDefault();

		let node;

		if ( media.file ) {
			node = document.createElement( "video" );
			node.src = media.file;
			node.controls = true;
			node.autoplay = true;
			node.playsInline = true;
		} else {
			node = document.createElement( "iframe" );
			node.src = media.frame;
			node.allow = "autoplay; encrypted-media; picture-in-picture; fullscreen";
			node.allowFullscreen = true;
			node.referrerPolicy = "strict-origin-when-cross-origin";
			node.title = link.getAttribute( "aria-label" ) || "";
		}

		stage.replaceChildren( node );
		dialog.showModal();
	} );

	dialog.addEventListener( "close", function () {
		stage.replaceChildren();
	} );

	dialog.addEventListener( "click", function ( event ) {
		if ( event.target === dialog ) {
			dialog.close();
		}
	} );

	dialog.querySelector( "[data-video-close]" ).addEventListener( "click", function () {
		dialog.close();
	} );
} );
