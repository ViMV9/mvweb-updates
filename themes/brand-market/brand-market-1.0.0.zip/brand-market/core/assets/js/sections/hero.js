const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

document.querySelectorAll("[data-hero-slides][data-effect]").forEach(function (box) {
	const slides = box.querySelectorAll("[data-hero-slide]");

	if (slides.length < 2 || reduced) {
		return;
	}

	const interval = Math.max(3, parseFloat(getComputedStyle(box).getPropertyValue("--mvweb-t-hero-interval")) || 6) * 1000;
	let current = 0;
	let timer = 0;

	function show(next) {
		const leaving = slides[current];

		leaving.setAttribute("data-state", "leaving");
		slides[next].setAttribute("data-state", "active");
		current = next;

		window.setTimeout(function () {
			leaving.removeAttribute("data-state");
		}, 1300);
	}

	function start() {
		window.clearInterval(timer);
		timer = window.setInterval(function () {
			show((current + 1) % slides.length);
		}, interval);
	}

	document.addEventListener("visibilitychange", function () {
		if (document.hidden) {
			window.clearInterval(timer);
		} else {
			start();
		}
	});

	start();
});

if (!reduced && window.matchMedia("(min-width: 48rem)").matches) {
	document.querySelectorAll("[data-hero-video][data-src]").forEach(function (video) {
		video.addEventListener("playing", function () {
			video.setAttribute("data-playing", "");
		}, { once: true });
		video.src = video.getAttribute("data-src");
		video.play().catch(function () {});
	});
}
