var CONTROLS = "input:not([type=hidden]), select, textarea, button";
var SECOND = "textarea, .wpcf7-acceptance, input[type=checkbox], input[type=submit], button[type=submit]";

document.querySelectorAll("[data-steps]").forEach(function (root) {
	var form = root.querySelector(".wpcf7-form");
	var progress = root.querySelector("[data-steps-progress]");
	var next = root.querySelector("[data-steps-next]");
	var back = root.querySelector("[data-steps-back]");
	var status = root.querySelector("[data-steps-status]");

	if (!form || !progress || !next || !back) {
		return;
	}

	var rows = Array.prototype.filter.call(form.children, function (row) {
		return row.querySelector(CONTROLS);
	});
	var cut = rows.findIndex(function (row) {
		return row.querySelector(SECOND);
	});

	if (cut < 1) {
		return;
	}

	var pills = progress.querySelectorAll("[data-step-to]");
	var submitRow = rows.filter(function (row) {
		return row.querySelector("input[type=submit], button[type=submit]");
	})[0];
	var template = root.getAttribute("data-steps-label") || "";

	rows.forEach(function (row, index) {
		row.setAttribute("data-step-pane", index < cut ? "1" : "2");
	});

	next.setAttribute("data-step-pane", "1");
	rows[cut - 1].after(next);

	if (submitRow) {
		submitRow.insertBefore(back, submitRow.firstChild);
	}

	progress.hidden = false;
	next.hidden = false;
	back.hidden = false;

	function first(step) {
		var row = form.querySelector("[data-step-pane='" + step + "']");

		return row ? row.querySelector("input:not([type=hidden]), select, textarea") : null;
	}

	function show(step, focus) {
		root.setAttribute("data-step", step);
		root.querySelectorAll("[data-step-pane]").forEach(function (pane) {
			pane.hidden = pane.getAttribute("data-step-pane") !== step;
		});
		pills.forEach(function (pill) {
			if (pill.getAttribute("data-step-to") === step) {
				pill.setAttribute("aria-current", "step");
			} else {
				pill.removeAttribute("aria-current");
			}
		});

		if (status) {
			status.textContent = template.replace("{n}", step).replace("{total}", "2");
		}

		if (focus && first(step)) {
			first(step).focus();
		}
	}

	function complete() {
		var wrong = null;

		form.querySelectorAll("[data-step-pane='1'] [aria-required=true], [data-step-pane='1'] [required]").forEach(function (control) {
			var empty = control.type === "checkbox" ? !control.checked : !control.value.trim();

			if (empty || !control.checkValidity()) {
				control.classList.add("wpcf7-not-valid");
				control.setAttribute("aria-invalid", "true");
				wrong = wrong || control;
			}
		});

		if (wrong) {
			wrong.focus();
		}

		return !wrong;
	}

	form.addEventListener("input", function (event) {
		if (event.target.classList) {
			event.target.classList.remove("wpcf7-not-valid");
			event.target.setAttribute("aria-invalid", "false");
		}
	});

	next.addEventListener("click", function () {
		if (complete()) {
			show("2", true);
		}
	});

	back.addEventListener("click", function () {
		show("1", true);
	});

	pills.forEach(function (pill) {
		pill.addEventListener("click", function () {
			var step = pill.getAttribute("data-step-to");

			if ("1" === step || complete()) {
				show(step, true);
			}
		});
	});

	form.addEventListener("wpcf7invalid", function (event) {
		var fields = event.detail && event.detail.apiResponse && event.detail.apiResponse.invalid_fields ? event.detail.apiResponse.invalid_fields : [];
		var wrap = fields.length ? form.querySelector(".wpcf7-form-control-wrap[data-name='" + fields[0].field + "']") : null;
		var row = wrap ? wrap.closest("[data-step-pane]") : null;

		if (row) {
			show(row.getAttribute("data-step-pane"), false);
		}
	});

	form.addEventListener("wpcf7mailsent", function () {
		show("1", false);
	});

	show("1", false);
});
