document.querySelectorAll("[data-showcase-modal]").forEach(function (modal) {
	var section = modal.closest("[data-products]");
	var product = modal.querySelector("[data-showcase-modal-product]");

	if (!section || typeof modal.showModal !== "function") {
		return;
	}

	section.addEventListener("click", function (event) {
		var opener = event.target.closest("[data-showcase-form]");

		if (!opener) {
			return;
		}

		var name = opener.getAttribute("data-showcase-form");

		product.textContent = name;
		modal.querySelectorAll('input[name="product"]').forEach(function (input) {
			input.value = name;
		});
		modal.showModal();
	});

	modal.addEventListener("click", function (event) {
		if (event.target === modal || event.target.closest("[data-showcase-modal-close]")) {
			modal.close();
		}
	});
});

document.querySelectorAll("[data-products-chips]").forEach(function (chips) {
	var section = chips.closest("[data-products]");

	if (!section) {
		return;
	}

	var buttons = chips.querySelectorAll("[data-products-chip]");
	var cards = section.querySelectorAll("[data-products-card]");

	buttons.forEach(function (button) {
		button.addEventListener("click", function () {
			var slug = button.getAttribute("data-products-chip");

			buttons.forEach(function (other) {
				other.setAttribute("aria-pressed", other === button ? "true" : "false");
			});
			cards.forEach(function (card) {
				var own = (card.getAttribute("data-products-cat") || "").split(" ");

				card.hidden = "" !== slug && own.indexOf(slug) === -1;
			});
		});
	});
});
