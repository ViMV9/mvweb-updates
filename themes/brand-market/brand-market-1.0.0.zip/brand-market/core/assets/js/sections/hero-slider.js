const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

document.querySelectorAll("[data-hero-slider]").forEach(function (box) {
	const slides = box.querySelectorAll("[data-hero-slider-slide]");
	const dots = box.querySelectorAll("[data-hero-slider-dot]");
	const pause = box.querySelector("[data-hero-slider-pause]");
	const interval = Math.max(3, parseFloat(box.getAttribute("data-interval")) || 6);
	let current = 0;
	let timer = 0;
	let paused = reduced || box.hasAttribute("data-manual");

	if (slides.length < 2) {
		return;
	}

	box.style.setProperty("--mvweb-t-slider-interval", interval + "s");

	function show(next) {
		current = (next + slides.length) % slides.length;

		slides.forEach(function (slide, index) {
			const active = index === current;

			slide.toggleAttribute("data-active", active);
			slide.toggleAttribute("inert", !active);
			slide.setAttribute("aria-hidden", active ? "false" : "true");
		});
		dots.forEach(function (dot, index) {
			dot.toggleAttribute("data-active", index === current);
			dot.setAttribute("aria-current", index === current ? "true" : "false");
		});
	}

	function stop() {
		window.clearTimeout(timer);
		box.removeAttribute("data-running");
	}

	function start() {
		stop();

		if (paused || document.hidden) {
			return;
		}

		void box.offsetWidth;
		box.setAttribute("data-running", "");
		timer = window.setTimeout(function () {
			show(current + 1);
			start();
		}, interval * 1000);
	}

	function go(next) {
		show(next);
		start();
	}

	box.querySelectorAll("[data-hero-slider-prev]").forEach(function (button) {
		button.addEventListener("click", function () {
			go(current - 1);
		});
	});
	box.querySelectorAll("[data-hero-slider-next]").forEach(function (button) {
		button.addEventListener("click", function () {
			go(current + 1);
		});
	});
	dots.forEach(function (dot, index) {
		dot.addEventListener("click", function () {
			go(index);
		});
	});

	if (pause) {
		pause.setAttribute("aria-pressed", paused ? "true" : "false");
		pause.addEventListener("click", function () {
			paused = !paused;
			pause.setAttribute("aria-pressed", paused ? "true" : "false");
			start();
		});
	}

	let touch = null;

	function scroller(node) {
		while (node && node !== box) {
			if (node.scrollWidth > node.clientWidth && "visible" !== window.getComputedStyle(node).overflowX) {
				return true;
			}

			node = node.parentElement;
		}

		return false;
	}

	box.addEventListener("touchstart", function (event) {
		touch = 1 === event.touches.length && !scroller(event.target) ? { x: event.touches[0].clientX, y: event.touches[0].clientY } : null;

		if (!paused) {
			paused = true;

			if (pause) {
				pause.setAttribute("aria-pressed", "true");
			}

			stop();
		}
	}, { passive: true });

	box.addEventListener("touchend", function (event) {
		if (!touch) {
			return;
		}

		const dx = event.changedTouches[0].clientX - touch.x;
		const dy = event.changedTouches[0].clientY - touch.y;

		touch = null;

		if (Math.abs(dx) > 40 && Math.abs(dx) > Math.abs(dy) * 1.5) {
			go(current + (dx < 0 ? 1 : -1));
		}
	}, { passive: true });

	document.addEventListener("visibilitychange", start);

	show(0);
	start();
});
