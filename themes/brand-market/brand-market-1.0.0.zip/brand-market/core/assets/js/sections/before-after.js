document.addEventListener( "input", function ( event ) {
	const range = event.target;

	if ( ! range.hasAttribute || ! range.hasAttribute( "data-ba-range" ) ) {
		return;
	}

	range.parentNode.style.setProperty( "--mvweb-t-ba-pos", range.value + "%" );
} );
