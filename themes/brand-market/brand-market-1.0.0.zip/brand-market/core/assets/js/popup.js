const modal = document.querySelector( "[data-request-modal]" );

function subject( opener ) {
	const named = opener && opener.getAttribute( "data-request" );
	const heading = document.querySelector( "main h1" );

	return named || ( heading ? heading.textContent.trim() : document.title );
}

function open( opener ) {
	const name = subject( opener );

	modal.querySelectorAll( 'input[name="product"]' ).forEach( function ( input ) {
		input.value = name;
	} );
	modal.showModal();
}

if ( modal && typeof modal.showModal === "function" ) {
	document.addEventListener( "click", function ( event ) {
		const link = event.target.closest( 'a[href$="#request"]' );

		if ( ! link ) {
			return;
		}

		const here = link.getAttribute( "href" ) === "#request" || ( link.origin === location.origin && link.pathname === location.pathname );

		if ( ! here ) {
			return;
		}

		event.preventDefault();
		open( link );
	} );

	modal.addEventListener( "click", function ( event ) {
		if ( event.target === modal || event.target.closest( "[data-request-close]" ) ) {
			modal.close();
		}
	} );

	if ( location.hash === "#request" ) {
		open( null );
		history.replaceState( null, "", location.pathname + location.search );
	}
}
