const panel = document.querySelector( "[data-filters]" );
const toggles = document.querySelectorAll( "[data-filters-toggle]" );

function setFilters( open ) {
	if ( ! panel ) {
		return;
	}

	panel.toggleAttribute( "data-open", open );
	toggles.forEach( function ( button ) {
		button.setAttribute( "aria-expanded", open ? "true" : "false" );
	} );
}

if ( panel ) {
	let opener = null;

	toggles.forEach( function ( button ) {
		button.addEventListener( "click", function () {
			const open = ! panel.hasAttribute( "data-open" );

			opener = open ? button : null;
			setFilters( open );

			if ( open ) {
				const close = panel.querySelector( "form [data-filters-close]" );

				if ( close && close.offsetParent !== null ) {
					close.focus();
				}
			}
		} );
	} );

	panel.querySelectorAll( "[data-filters-close]" ).forEach( function ( button ) {
		button.addEventListener( "click", function () {
			setFilters( false );

			if ( opener ) {
				opener.focus();
			}
		} );
	} );

	document.addEventListener( "keydown", function ( event ) {
		if ( "Escape" === event.key && panel.hasAttribute( "data-open" ) ) {
			setFilters( false );

			if ( opener ) {
				opener.focus();
			}
		}
	} );
}

function bounds( input ) {
	const box = input.closest( "[data-qty]" );

	return {
		min: Number( input.dataset.qtyMin || box.dataset.min ) || 1,
		max: Number( input.dataset.qtyMax || box.dataset.max ) || 0,
		step: Number( input.dataset.qtyStep || box.dataset.step ) || 1
	};
}

function clampQuantity( input, value ) {
	const { min, max, step } = bounds( input );
	let next = Math.max( min, value );

	if ( step > 1 ) {
		next = min + Math.round( ( next - min ) / step ) * step;
	}

	return max > 0 ? Math.min( max, next ) : next;
}

function stepQuantity( event ) {
	const minus = event.target.closest( "[data-qty-minus]" );
	const button = minus || event.target.closest( "[data-qty-plus]" );
	const input = button?.closest( "[data-qty]" )?.querySelector( "[data-qty-input]" );

	if ( ! input ) {
		return;
	}

	const { min, step } = bounds( input );
	const current = parseInt( input.value, 10 ) || min;

	input.value = String( clampQuantity( input, current + ( minus ? -step : step ) ) );
	input.dispatchEvent( new Event( "change", { bubbles: true } ) );
}

function syncQuantity( event ) {
	const input = event.target;

	if ( ! input.matches || ! input.matches( "[data-qty-input]" ) ) {
		return;
	}

	const value = parseInt( input.value, 10 );
	const add = input.closest( "[data-qty]" ).parentNode.querySelector( ".add_to_cart_button" );

	input.value = String( clampQuantity( input, Number.isNaN( value ) ? 1 : value ) );

	if ( ! add ) {
		return;
	}

	add.setAttribute( "data-quantity", input.value );

	if ( add.href ) {
		const link = new URL( add.href, location.href );

		link.searchParams.set( "quantity", input.value );
		add.href = link.toString();
	}
}

document.addEventListener( "click", stepQuantity );
document.addEventListener( "change", syncQuantity );
