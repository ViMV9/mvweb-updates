const data = JSON.parse(
	document.getElementById( "wp-script-module-data-@mvweb-core/showcase" )?.textContent || "{}"
);

function setup(gallery) {
	var track = gallery.querySelector("[data-showcase-track]");
	var dotsBox = gallery.querySelector("[data-showcase-dots]");
	var prev = gallery.querySelector("[data-showcase-prev]");
	var next = gallery.querySelector("[data-showcase-next]");

	if (!track) {
		return;
	}

	var counterCurrent = gallery.querySelector("[data-showcase-current]");
	var counterTotal = gallery.querySelector("[data-showcase-total]");
	var slides = Array.prototype.slice.call(track.children);

	if (slides.length < 2) {
		if (prev) prev.hidden = true;
		if (next) next.hidden = true;
		if (dotsBox) dotsBox.hidden = true;
		return;
	}

	if (counterTotal) {
		counterTotal.textContent = slides.length;
	}

	var dots = [];

	if (dotsBox) {
		slides.forEach(function (slide, i) {
			var dot = document.createElement("button");
			dot.type = "button";
			dot.setAttribute("data-showcase-dot", "");
			dot.title = (data.frame || "") + " " + (i + 1);
			var label = document.createElement("span");
			label.className = "screen-reader-text";
			label.textContent = dot.title;
			dot.appendChild(label);
			dot.addEventListener("click", function () {
				slide.scrollIntoView({ inline: "start", block: "nearest" });
			});
			dotsBox.appendChild(dot);
			dots.push(dot);
		});
	}

	function mark(first, last) {
		dots.forEach(function (dot, i) {
			dot.setAttribute("aria-current", i === first ? "true" : "false");
		});

		if (counterCurrent) {
			counterCurrent.textContent = first + 1;
		}

		if (prev) prev.hidden = first === 0;
		if (next) next.hidden = last === slides.length - 1;
	}

	mark(0, 0);

	var visible = [];

	var observer = new IntersectionObserver(function (entries) {
		entries.forEach(function (entry) {
			var index = slides.indexOf(entry.target);
			var at = visible.indexOf(index);

			if (entry.isIntersecting && at === -1) {
				visible.push(index);
			} else if (!entry.isIntersecting && at !== -1) {
				visible.splice(at, 1);
			}
		});

		if (visible.length) {
			mark(Math.min.apply(null, visible), Math.max.apply(null, visible));
		}
	}, { root: track, threshold: 0.6 });

	slides.forEach(function (slide) {
		observer.observe(slide);
	});

	function step(direction) {
		track.scrollBy({ left: direction * track.clientWidth });
	}

	if (prev) {
		prev.addEventListener("click", function () {
			step(-1);
		});
	}

	if (next) {
		next.addEventListener("click", function () {
			step(1);
		});
	}
}

document.querySelectorAll("[data-showcase]").forEach(setup);
