<?php
/**
 * Share buttons.
 *
 * Plain links to the share endpoints of the networks, no third party script and
 * no counters: a counter costs a request to someone else's server on every page
 * and tells the visitor nothing they asked for.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_share_networks' ) ) {
	/**
	 * The networks the buttons can point at.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,string>> Keyed by id, with 'label',
	 *                                            'icon' and 'url' holding the
	 *                                            endpoint with %1$s for the
	 *                                            address and %2$s for the title.
	 */
	function mvweb_core_share_networks() {
		$networks = array(
			'vk'       => array(
				'label' => __( 'VK', 'mvweb-core' ),
				'icon'  => 'vk',
				'url'   => 'https://vk.com/share.php?url=%1$s&title=%2$s',
			),
			'telegram' => array(
				'label' => __( 'Telegram', 'mvweb-core' ),
				'icon'  => 'telegram',
				'url'   => 'https://t.me/share/url?url=%1$s&text=%2$s',
			),
			'whatsapp' => array(
				'label' => __( 'WhatsApp', 'mvweb-core' ),
				'icon'  => 'whatsapp',
				'url'   => 'https://api.whatsapp.com/send?text=%2$s%%20%1$s',
			),
			'viber'    => array(
				'label' => __( 'Viber', 'mvweb-core' ),
				'icon'  => 'viber',
				'url'   => 'viber://forward?text=%2$s%%20%1$s',
			),
			'ok'       => array(
				'label' => __( 'Odnoklassniki', 'mvweb-core' ),
				'icon'  => 'ok',
				'url'   => 'https://connect.ok.ru/offer?url=%1$s&title=%2$s',
			),
			'facebook' => array(
				'label' => __( 'Facebook', 'mvweb-core' ),
				'icon'  => 'facebook',
				'url'   => 'https://www.facebook.com/sharer/sharer.php?u=%1$s',
			),
			'x'        => array(
				'label' => __( 'X', 'mvweb-core' ),
				'icon'  => 'x',
				'url'   => 'https://x.com/intent/post?url=%1$s&text=%2$s',
			),
			'linkedin' => array(
				'label' => __( 'LinkedIn', 'mvweb-core' ),
				'icon'  => 'linkedin',
				'url'   => 'https://www.linkedin.com/sharing/share-offsite/?url=%1$s',
			),
			'email'    => array(
				'label' => __( 'E-mail', 'mvweb-core' ),
				'icon'  => 'mail',
				'url'   => 'mailto:?subject=%2$s&body=%1$s',
			),
		);

		/**
		 * Filter the networks offered in the settings.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,array<string,string>> $networks Networks by id.
		 */
		return (array) apply_filters( 'mvweb_core_share_networks', $networks );
	}
}

if ( ! function_exists( 'mvweb_core_share_places' ) ) {
	/**
	 * The pages the buttons may be printed on.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_share_places() {
		return array(
			'post'    => __( 'Blog entry', 'mvweb-core' ),
			'item'    => __( 'Catalogue item', 'mvweb-core' ),
			'service' => __( 'Service', 'mvweb-core' ),
			'work'    => __( 'Portfolio work', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_share_chosen' ) ) {
	/**
	 * The values ticked in one of the two settings.
	 *
	 * @since 0.1.0
	 *
	 * @param string $setting Setting id.
	 *
	 * @return string[]
	 */
	function mvweb_core_share_chosen( $setting ) {
		$chosen = json_decode( (string) get_theme_mod( $setting, '' ), true );

		return is_array( $chosen ) ? array_filter( array_map( 'sanitize_key', $chosen ) ) : array();
	}
}

if ( ! function_exists( 'mvweb_core_share_here' ) ) {
	/**
	 * Whether this request is a place the buttons were asked for.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_share_here() {
		$places = mvweb_core_share_chosen( 'mvweb_share_places' );

		if ( empty( $places ) || empty( mvweb_core_share_chosen( 'mvweb_share_networks' ) ) ) {
			return false;
		}

		if ( in_array( 'post', $places, true ) && is_singular( 'post' ) ) {
			return true;
		}

		if ( in_array( 'work', $places, true ) && is_singular( 'mv_work' ) ) {
			return true;
		}

		if ( in_array( 'item', $places, true ) && mvweb_core_is_product() ) {
			return true;
		}

		return in_array( 'service', $places, true ) && mvweb_core_is_service();
	}
}

if ( ! function_exists( 'mvweb_core_share_links' ) ) {
	/**
	 * The buttons themselves, in the order the networks are declared.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Entry id.
	 *
	 * @return array<int,array<string,string>> Items with 'label', 'icon' and 'url'.
	 */
	function mvweb_core_share_links( $id ) {
		$chosen = mvweb_core_share_chosen( 'mvweb_share_networks' );

		if ( empty( $chosen ) ) {
			return array();
		}

		$address = rawurlencode( (string) get_permalink( $id ) );
		$title   = rawurlencode( get_the_title( $id ) );
		$links   = array();

		foreach ( mvweb_core_share_networks() as $slug => $network ) {
			if ( ! in_array( $slug, $chosen, true ) ) {
				continue;
			}

			$links[] = array(
				'label' => $network['label'],
				'icon'  => $network['icon'],
				'url'   => sprintf( $network['url'], $address, $title ),
			);
		}

		return $links;
	}
}
