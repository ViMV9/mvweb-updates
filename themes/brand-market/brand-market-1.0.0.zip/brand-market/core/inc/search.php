<?php
/**
 * Making builder pages findable.
 *
 * What the builder writes never reaches post_content, and site search only
 * looks at the post columns — so a page assembled from sections would answer no
 * query at all. Every time the section meta is written its text is flattened
 * into a second key, and search is taught to look there as well.
 *
 * The flat copy is for the database, not for reading: Yoast's own analysis
 * still sees an empty page, which is the price of keeping the content out of
 * post_content.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_sections_flat_text' ) ) {
	/**
	 * Every readable string of a section list, as one line.
	 *
	 * @since 0.1.0
	 *
	 * @param array $rows Section rows.
	 *
	 * @return string
	 */
	function mvweb_core_sections_flat_text( array $rows ) {
		$parts = array();

		array_walk_recursive(
			$rows,
			static function ( $value, $key ) use ( &$parts ) {
				if ( ! is_string( $value ) || in_array( $key, array( 'uid', 'type', 'v' ), true ) ) {
					return;
				}

				$value = trim( wp_strip_all_tags( $value ) );

				if ( '' !== $value ) {
					$parts[] = $value;
				}
			}
		);

		return implode( ' ', $parts );
	}
}

if ( ! function_exists( 'mvweb_core_sync_sections_text' ) ) {
	/**
	 * Keep the searchable copy in step with the sections.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $meta_id    Meta row id.
	 * @param int    $post_id    Post the meta belongs to.
	 * @param string $meta_key   Meta key written.
	 * @param mixed  $meta_value Value written.
	 *
	 * @return void
	 */
	function mvweb_core_sync_sections_text( $meta_id, $post_id, $meta_key, $meta_value ) {
		if ( '_mvweb_sections' !== $meta_key ) {
			return;
		}

		$text = is_array( $meta_value ) ? mvweb_core_sections_flat_text( $meta_value ) : '';

		if ( '' === $text ) {
			delete_post_meta( $post_id, '_mvweb_sections_text' );

			return;
		}

		update_post_meta( $post_id, '_mvweb_sections_text', $text );
	}
}
add_action( 'added_post_meta', 'mvweb_core_sync_sections_text', 10, 4 );
add_action( 'updated_post_meta', 'mvweb_core_sync_sections_text', 10, 4 );

if ( ! function_exists( 'mvweb_core_search_is_ours' ) ) {
	/**
	 * Whether this query is the site search the visitor asked for.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Query being built.
	 *
	 * @return bool
	 */
	function mvweb_core_search_is_ours( $query ) {
		return $query instanceof WP_Query
			&& $query->is_search()
			&& $query->is_main_query()
			&& ! is_admin()
			&& ! $query->get( 'mvweb_ss' )
			&& ! empty( $query->query_vars['search_terms'] );
	}
}

if ( ! function_exists( 'mvweb_core_search_join' ) ) {
	/**
	 * Bring the searchable copy into the search query.
	 *
	 * @since 0.1.0
	 *
	 * @param string   $join  JOIN clause.
	 * @param WP_Query $query Query being built.
	 *
	 * @return string
	 */
	function mvweb_core_search_join( $join, $query ) {
		global $wpdb;

		if ( ! mvweb_core_search_is_ours( $query ) ) {
			return $join;
		}

		return $join . $wpdb->prepare(
			" LEFT JOIN {$wpdb->postmeta} AS mv_sections ON ( {$wpdb->posts}.ID = mv_sections.post_id AND mv_sections.meta_key = %s ) ",
			'_mvweb_sections_text'
		);
	}
}
add_filter( 'posts_join', 'mvweb_core_search_join', 10, 2 );

if ( ! function_exists( 'mvweb_core_search_where' ) ) {
	/**
	 * Let a page match on its sections as well as on its own columns.
	 *
	 * @since 0.1.0
	 *
	 * @param string   $search WHERE fragment core built, always " AND (…) ".
	 * @param WP_Query $query  Query being built.
	 *
	 * @return string
	 */
	function mvweb_core_search_where( $search, $query ) {
		global $wpdb;

		if ( '' === trim( $search ) || ! mvweb_core_search_is_ours( $query ) ) {
			return $search;
		}

		$core = trim( $search );

		if ( 0 !== stripos( $core, 'AND ' ) ) {
			return $search;
		}

		$core = substr( $core, 4 );

		$exclusion_prefix = apply_filters( 'wp_query_search_exclusion_prefix', '-' );

		$parts  = array();
		$wanted = false;

		foreach ( $query->query_vars['search_terms'] as $term ) {
			$exclude = '' !== $exclusion_prefix && str_starts_with( $term, $exclusion_prefix );

			if ( $exclude ) {
				$term = substr( $term, 1 );
			}

			if ( '' === $term ) {
				continue;
			}

			$like = '%' . $wpdb->esc_like( $term ) . '%';

			if ( $exclude ) {
				$parts[] = $wpdb->prepare( 'mv_sections.meta_value NOT LIKE %s', $like );
			} else {
				$parts[] = $wpdb->prepare( 'mv_sections.meta_value LIKE %s', $like );
				$wanted  = true;
			}
		}

		if ( ! $wanted ) {
			return $search;
		}

		return ' AND ( ' . $core . ' OR ( ' . implode( ' AND ', $parts ) . ' ) ) ';
	}
}
add_filter( 'posts_search', 'mvweb_core_search_where', 10, 2 );
