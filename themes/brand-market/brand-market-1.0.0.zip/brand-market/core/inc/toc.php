<?php
/**
 * The table of contents of a blog entry.
 *
 * Built from the h2 and h3 of the text at print time: a heading without an id
 * gets one from its words, and the list goes above the text. A short entry
 * with fewer than three headings has nothing to navigate and gets no list.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_toc' ) ) {
	/**
	 * Put the table of contents above the text of a blog entry.
	 *
	 * @since 0.1.0
	 *
	 * @param string $content Entry text, already formatted.
	 *
	 * @return string
	 */
	function mvweb_core_toc( $content ) {
		if ( ! is_singular( 'post' ) || ! in_the_loop() || ! is_main_query() || ! get_theme_mod( 'mvweb_toc', false ) ) {
			return $content;
		}

		$items = array();
		$used  = array();

		$content = (string) preg_replace_callback(
			'#<h([23])([^>]*)>(.*?)</h\1>#is',
			static function ( $found ) use ( &$items, &$used ) {
				$text = trim( wp_strip_all_tags( $found[3] ) );

				if ( '' === $text ) {
					return $found[0];
				}

				if ( preg_match( '/\sid=(["\'])(.*?)\1/i', $found[2], $id ) && ! isset( $used[ $id[2] ] ) ) {
					$anchor = $id[2];
					$attrs  = $found[2];
				} else {
					$base   = rawurldecode( sanitize_title( $text ) );
					$base   = '' !== $base ? $base : 'section';
					$anchor = $base;
					$suffix = 2;

					while ( isset( $used[ $anchor ] ) ) {
						$anchor = $base . '-' . $suffix;
						++$suffix;
					}

					$attrs = (string) preg_replace( '/\sid=(["\']).*?\1/i', '', $found[2] ) . ' id="' . esc_attr( $anchor ) . '"';
				}

				$used[ $anchor ] = true;
				$items[]         = array(
					'level'  => (int) $found[1],
					'text'   => $text,
					'anchor' => $anchor,
				);

				return '<h' . $found[1] . $attrs . '>' . $found[3] . '</h' . $found[1] . '>';
			},
			$content
		);

		if ( count( $items ) < 3 ) {
			return $content;
		}

		ob_start();
		get_template_part( 'template-parts/toc', null, array( 'items' => $items ) );

		return (string) ob_get_clean() . $content;
	}
}
add_filter( 'the_content', 'mvweb_core_toc', 20 );
