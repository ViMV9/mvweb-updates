<?php
/**
 * Primary navigation and the mega menu.
 *
 * The mega menu is not built with a Walker: its tabs and its panels are
 * siblings, and a walker visits a branch depth first, so the panels would come
 * out interleaved with the tabs. Reading the menu with wp_get_nav_menu_items()
 * and grouping it by parent gives the markup the layout needs in far less code.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_menu_tree' ) ) {
	/**
	 * Items of a menu location, grouped by their parent.
	 *
	 * @since 0.1.0
	 *
	 * @param string $location Registered menu location.
	 *
	 * @return array<int,WP_Post[]> Keyed by parent id, 0 for the top level.
	 */
	function mvweb_core_menu_tree( $location ) {
		$locations = get_nav_menu_locations();

		if ( empty( $locations[ $location ] ) ) {
			return array();
		}

		$items = wp_get_nav_menu_items( $locations[ $location ] );

		if ( ! is_array( $items ) ) {
			return array();
		}

		$tree = array();

		foreach ( $items as $item ) {
			$tree[ (int) $item->menu_item_parent ][] = $item;
		}

		return $tree;
	}
}

if ( ! function_exists( 'mvweb_core_menu_url_is_real' ) ) {
	/**
	 * Whether a menu item leads anywhere.
	 *
	 * @since 0.1.0
	 *
	 * @param string $url Item address.
	 *
	 * @return bool
	 */
	function mvweb_core_menu_url_is_real( $url ) {
		$url = trim( (string) $url );

		return '' !== $url && '#' !== $url;
	}
}

if ( ! function_exists( 'mvweb_core_menu_href' ) ) {
	/**
	 * The link attributes of a menu item.
	 *
	 * @since 0.1.0
	 *
	 * @param string $url    Item address.
	 * @param bool   $button Whether an item without an address acts as a button.
	 *
	 * @return string Escaped attributes.
	 */
	function mvweb_core_menu_href( $url, $button = true ) {
		if ( mvweb_core_menu_url_is_real( $url ) ) {
			return 'href="' . esc_url( $url ) . '"';
		}

		return $button ? 'role="button" tabindex="0"' : 'tabindex="0"';
	}
}

if ( ! function_exists( 'mvweb_core_menu_item_is_mega' ) ) {
	/**
	 * Whether a top-level menu item opens the mega menu.
	 *
	 * @since 0.1.0
	 *
	 * @param int $item_id Menu item id.
	 *
	 * @return bool
	 */
	function mvweb_core_menu_item_is_mega( $item_id ) {
		return '1' === get_post_meta( $item_id, '_mvweb_menu_mega', true );
	}
}

if ( ! function_exists( 'mvweb_core_menu_image_field' ) ) {
	/**
	 * The picture field on a menu item.
	 *
	 * @since 0.1.0
	 *
	 * @param int $item_id Menu item id.
	 *
	 * @return void
	 */
	function mvweb_core_menu_image_field( $item_id ) {
		$id  = absint( get_post_meta( $item_id, '_mvweb_menu_image', true ) );
		$src = wp_attachment_is_image( $id ) ? wp_get_attachment_image_url( $id, 'thumbnail' ) : '';
		?>
		<p class="description description-wide mvweb-core-menu-image" data-menu-image>
			<label for="mvweb-core-menu-image-<?php echo (int) $item_id; ?>">
				<?php esc_html_e( 'Picture in the mega menu', 'mvweb-core' ); ?>
			</label>

			<span class="mvweb-core-menu-image__preview">
				<?php if ( '' !== $src ) : ?>
					<img src="<?php echo esc_url( $src ); ?>" alt="">
				<?php endif; ?>
			</span>

			<input
				type="hidden"
				id="mvweb-core-menu-image-<?php echo (int) $item_id; ?>"
				name="mvweb_menu_image[<?php echo (int) $item_id; ?>]"
				value="<?php echo (int) $id; ?>"
				data-menu-image-value
			>

			<button type="button" class="button" data-menu-image-pick><?php esc_html_e( 'Select', 'mvweb-core' ); ?></button>
			<button type="button" class="button-link" data-menu-image-clear><?php esc_html_e( 'Remove', 'mvweb-core' ); ?></button>

			<span class="description">
				<?php esc_html_e( 'Leave empty: an item pointing at a category takes the category picture.', 'mvweb-core' ); ?>
			</span>
		</p>
		<?php
	}
}
add_action( 'wp_nav_menu_item_custom_fields', 'mvweb_core_menu_image_field' );

if ( ! function_exists( 'mvweb_core_menu_mega_field' ) ) {
	/**
	 * The mega menu checkbox on a menu item.
	 *
	 * @since 0.1.0
	 *
	 * @param int $item_id Menu item id.
	 *
	 * @return void
	 */
	function mvweb_core_menu_mega_field( $item_id ) {
		$name = 'mvweb_menu_mega[' . (int) $item_id . ']';
		?>
		<p class="description description-wide mvweb-core-menu-mega">
			<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="0">
			<label for="mvweb-core-menu-mega-<?php echo (int) $item_id; ?>">
				<input
					type="checkbox"
					id="mvweb-core-menu-mega-<?php echo (int) $item_id; ?>"
					name="<?php echo esc_attr( $name ); ?>"
					value="1"
					<?php checked( mvweb_core_menu_item_is_mega( $item_id ) ); ?>
				>
				<?php esc_html_e( 'Mega menu with previews', 'mvweb-core' ); ?>
			</label>

			<span class="description">
				<?php esc_html_e( 'Sub-items become tabs, their own items become picture cards. Unticked, the sub-items open as a plain list.', 'mvweb-core' ); ?>
			</span>
		</p>
		<?php
	}
}
add_action( 'wp_nav_menu_item_custom_fields', 'mvweb_core_menu_mega_field', 5 );

if ( ! function_exists( 'mvweb_core_menu_mega_save' ) ) {
	/**
	 * Store the mega menu checkbox of a menu item.
	 *
	 * @since 0.1.0
	 *
	 * @param int $menu_id Menu id.
	 * @param int $item_id Menu item id.
	 *
	 * @return void
	 */
	function mvweb_core_menu_mega_save( $menu_id, $item_id ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified below, once the field is known to be present.
		if ( ! isset( $_POST['mvweb_menu_mega'][ $item_id ] ) ) {
			return;
		}

		$nonce = isset( $_POST['update-nav-menu-nonce'] ) ? sanitize_key( wp_unslash( $_POST['update-nav-menu-nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'update-nav_menu' ) || ! current_user_can( 'edit_theme_options' ) ) {
			return;
		}

		if ( '1' === sanitize_key( wp_unslash( $_POST['mvweb_menu_mega'][ $item_id ] ) ) ) {
			update_post_meta( $item_id, '_mvweb_menu_mega', '1' );

			return;
		}

		delete_post_meta( $item_id, '_mvweb_menu_mega' );
	}
}
add_action( 'wp_update_nav_menu_item', 'mvweb_core_menu_mega_save', 10, 2 );

if ( ! function_exists( 'mvweb_core_menu_image_save' ) ) {
	/**
	 * Store the picture of a menu item.
	 *
	 * @since 0.1.0
	 *
	 * @param int $menu_id Menu id.
	 * @param int $item_id Menu item id.
	 *
	 * @return void
	 */
	function mvweb_core_menu_image_save( $menu_id, $item_id ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified below, once the field is known to be present.
		if ( ! isset( $_POST['mvweb_menu_image'][ $item_id ] ) ) {
			return;
		}

		$nonce = isset( $_POST['update-nav-menu-nonce'] ) ? sanitize_key( wp_unslash( $_POST['update-nav-menu-nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'update-nav_menu' ) || ! current_user_can( 'edit_theme_options' ) ) {
			return;
		}

		$id = absint( wp_unslash( $_POST['mvweb_menu_image'][ $item_id ] ) );

		if ( wp_attachment_is_image( $id ) ) {
			update_post_meta( $item_id, '_mvweb_menu_image', $id );

			return;
		}

		delete_post_meta( $item_id, '_mvweb_menu_image' );
	}
}
add_action( 'wp_update_nav_menu_item', 'mvweb_core_menu_image_save', 10, 2 );

if ( ! function_exists( 'mvweb_core_menu_admin_assets' ) ) {
	/**
	 * The media picker of the menu screen.
	 *
	 * @since 0.1.0
	 *
	 * @param string $hook Current admin screen.
	 *
	 * @return void
	 */
	function mvweb_core_menu_admin_assets( $hook ) {
		if ( 'nav-menus.php' !== $hook ) {
			return;
		}

		wp_enqueue_media();

		$relative = mvweb_core_asset_path( '/admin/js/menu-image.js' );

		wp_enqueue_script(
			'mvweb-core-menu-image',
			MVWEB_CORE_URI . $relative,
			array( 'media-editor' ),
			mvweb_core_asset_version( $relative ),
			true
		);

		$style = mvweb_core_asset_path( '/admin/css/menu-image.css' );

		wp_enqueue_style(
			'mvweb-core-menu-image',
			MVWEB_CORE_URI . $style,
			array(),
			mvweb_core_asset_version( $style )
		);
	}
}
add_action( 'admin_enqueue_scripts', 'mvweb_core_menu_admin_assets' );
