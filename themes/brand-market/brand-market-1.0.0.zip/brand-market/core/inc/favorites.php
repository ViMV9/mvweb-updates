<?php
/**
 * Favourites.
 *
 * A guest keeps the list in the browser, a signed-in visitor keeps it in user
 * meta — so it survives a change of browser. The WooCommerce session was ruled
 * out on purpose: its cookie name starts with wp, which makes caching plugins
 * stop caching the whole site for that visitor.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_favorites_key' ) ) {
	/**
	 * Meta key the list is stored under.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_favorites_key() {
		return '_mvweb_favorites';
	}
}

if ( ! function_exists( 'mvweb_core_favorites_ids' ) ) {
	/**
	 * Turn whatever arrived into a plain list of ids.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $ids Raw list.
	 *
	 * @return int[]
	 */
	function mvweb_core_favorites_ids( $ids ) {
		if ( ! is_array( $ids ) ) {
			return array();
		}

		$clean = array();

		foreach ( array_slice( $ids, 0, 48 ) as $id ) {
			$id = absint( $id );

			if ( 0 !== $id ) {
				$clean[ $id ] = $id;
			}
		}

		return array_values( $clean );
	}
}

if ( ! function_exists( 'mvweb_core_favorites_clean' ) ) {
	/**
	 * Keep only ids of items a visitor may actually see.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $ids Raw list.
	 *
	 * @return int[]
	 */
	function mvweb_core_favorites_clean( $ids ) {
		if ( ! is_array( $ids ) ) {
			return array();
		}

		$clean = array();

		foreach ( array_slice( $ids, 0, 48 ) as $id ) {
			$id = absint( $id );

			if ( 0 === $id || isset( $clean[ $id ] ) ) {
				continue;
			}

			if ( mvweb_core_item_visible( $id ) ) {
				$clean[ $id ] = $id;
			}
		}

		return array_values( $clean );
	}
}

if ( ! function_exists( 'mvweb_core_favorites_get' ) ) {
	/**
	 * The stored list of the current visitor.
	 *
	 * @since 0.1.0
	 *
	 * @return int[] Empty for a guest: their list lives in the browser.
	 */
	function mvweb_core_favorites_get() {
		if ( ! is_user_logged_in() ) {
			return array();
		}

		return mvweb_core_favorites_clean( get_user_meta( get_current_user_id(), mvweb_core_favorites_key(), true ) );
	}
}

if ( ! function_exists( 'mvweb_core_favorites_save' ) ) {
	/**
	 * Replace the stored list of the current visitor.
	 *
	 * @since 0.1.0
	 *
	 * @param array $ids Product ids.
	 *
	 * @return int[] The list as it was stored.
	 */
	function mvweb_core_favorites_save( $ids ) {
		$clean = mvweb_core_favorites_clean( $ids );

		update_user_meta( get_current_user_id(), mvweb_core_favorites_key(), $clean );

		return $clean;
	}
}

if ( ! function_exists( 'mvweb_core_favorites_page_id' ) ) {
	/**
	 * The page the heart in the header points at.
	 *
	 * @since 0.1.0
	 *
	 * @return int
	 */
	function mvweb_core_favorites_page_id() {
		return absint( get_theme_mod( 'mvweb_favorites_page', 0 ) );
	}
}

if ( ! function_exists( 'mvweb_core_favorites_url' ) ) {
	/**
	 * Address of the favourites page.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_favorites_url() {
		$id = mvweb_core_favorites_page_id();

		if ( 0 === $id || 'publish' !== get_post_status( $id ) ) {
			return '';
		}

		return (string) get_permalink( $id );
	}
}

if ( ! function_exists( 'mvweb_core_favorites_routes' ) ) {
	/**
	 * Two routes: writing the list of a signed-in visitor, and cards by a list of ids.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_favorites_routes() {
		register_rest_route(
			'mvweb-core/v1',
			'/favorites',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => 'mvweb_core_favorites_write',
					'permission_callback' => 'is_user_logged_in',
					'args'                => array(
						'ids'   => array(
							'type'     => 'array',
							'required' => true,
							'maxItems' => 48,
							'items'    => array( 'type' => 'integer' ),
						),
						'merge' => array(
							'type'    => 'boolean',
							'default' => false,
						),
					),
				),
			)
		);

		register_rest_route(
			'mvweb-core/v1',
			'/favorites/cards',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => 'mvweb_core_favorites_cards',
				'permission_callback' => '__return_true',
				'args'                => array(
					'ids' => array(
						'type'     => 'array',
						'required' => true,
						'maxItems' => 48,
						'items'    => array( 'type' => 'integer' ),
					),
				),
			)
		);
	}
}
add_action( 'rest_api_init', 'mvweb_core_favorites_routes' );

if ( ! function_exists( 'mvweb_core_favorites_write' ) ) {
	/**
	 * Store the list of the signed-in visitor.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response
	 */
	function mvweb_core_favorites_write( $request ) {
		$ids = (array) $request->get_param( 'ids' );

		if ( $request->get_param( 'merge' ) ) {
			$ids = array_merge( mvweb_core_favorites_get(), $ids );
		}

		return rest_ensure_response( array( 'ids' => mvweb_core_favorites_save( $ids ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_favorites_cards' ) ) {
	/**
	 * Render the catalog card for every id of the list.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response
	 */
	function mvweb_core_favorites_cards( $request ) {
		$ids = mvweb_core_favorites_ids( $request->get_param( 'ids' ) );

		if ( empty( $ids ) ) {
			return rest_ensure_response(
				array(
					'ids'  => array(),
					'html' => '',
				)
			);
		}

		$query = new WP_Query(
			array(
				'post_type'           => mvweb_core_post_type(),
				'post__in'            => $ids,
				'orderby'             => 'post__in',
				'posts_per_page'      => count( $ids ),
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			)
		);

		$shown = array();

		ob_start();

		while ( $query->have_posts() ) {
			$query->the_post();

			if ( ! mvweb_core_item_visible( get_the_ID() ) ) {
				continue;
			}

			$shown[] = (int) get_the_ID();

			get_template_part(
				'template-parts/catalog/card',
				null,
				array(
					'id'  => get_the_ID(),
					'qty' => true,
				)
			);
		}

		wp_reset_postdata();

		return rest_ensure_response(
			array(
				'ids'  => $shown,
				'html' => ob_get_clean(),
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_favorites_data' ) ) {
	/**
	 * What the favourites module needs to talk to the site.
	 *
	 * @since 0.1.0
	 *
	 * @param array $data Existing data.
	 *
	 * @return array
	 */
	function mvweb_core_favorites_data( $data ) {
		$data['root']     = esc_url_raw( rest_url( 'mvweb-core/v1/favorites' ) );
		$data['nonce']    = wp_create_nonce( 'wp_rest' );
		$data['loggedIn'] = is_user_logged_in();
		$data['stored']   = mvweb_core_favorites_get();
		$data['added']    = __( 'In favourites', 'mvweb-core' );
		$data['add']      = __( 'Add to favourites', 'mvweb-core' );

		return $data;
	}
}
add_filter( 'script_module_data_@mvweb-core/favorites', 'mvweb_core_favorites_data' );

if ( ! function_exists( 'mvweb_core_favorites_fields' ) ) {
	/**
	 * The setting that says which page shows the list.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_favorites_fields() {
		return array(
			array(
				'type'              => 'dropdown_pages',
				'settings'          => 'mvweb_favorites_page',
				'section'           => 'mvweb_cz_conversion_cta',
				'label'             => __( 'Favourites page', 'mvweb-core' ),
				'description'       => __( 'A page with the Favourites template. Not selected: the heart in the header stays hidden.', 'mvweb-core' ),
				'default'           => 0,
				'sanitize_callback' => 'absint',
			),
		);
	}
}
