<?php
/**
 * What the catalogue listing asks the database for.
 *
 * With WooCommerce this is the plugin's job — WC_Query already reads the very
 * same request parameters. Without it the listing is a plain post type archive,
 * and the filters have to reach the query here.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_is_catalog_query' ) ) {
	/**
	 * Whether this query is the catalogue listing of the page being shown.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Query being prepared.
	 *
	 * @return bool
	 */
	function mvweb_core_is_catalog_query( $query ) {
		if ( is_admin() || ! $query->is_main_query() ) {
			return false;
		}

		return $query->is_post_type_archive( 'mv_item' ) || $query->is_tax( 'mv_item_cat' );
	}
}

if ( ! function_exists( 'mvweb_core_catalog_query' ) ) {
	/**
	 * Narrow the listing by the filters the visitor submitted.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Query being prepared.
	 *
	 * @return void
	 */
	function mvweb_core_catalog_query( $query ) {
		if ( mvweb_core_is_woocommerce() || ! mvweb_core_is_catalog_query( $query ) ) {
			return;
		}

		mvweb_core_listing_query( $query, 'mvweb_items_per_page' );

		$tax_query = (array) $query->get( 'tax_query', array() );

		foreach ( mvweb_core_properties() as $property ) {
			$selected = mvweb_core_catalog_selected( $property['slug'] );

			if ( empty( $selected ) ) {
				continue;
			}

			$tax_query[] = array(
				'taxonomy' => $property['taxonomy'],
				'field'    => 'slug',
				'terms'    => $selected,
				'operator' => 'IN',
			);
		}

		$subcategories = mvweb_core_subcategory_tax_query();

		if ( null !== $subcategories ) {
			$tax_query[] = $subcategories;
		}

		if ( count( $tax_query ) > 1 ) {
			$tax_query['relation'] = 'AND';
		}

		if ( ! empty( $tax_query ) ) {
			$query->set( 'tax_query', $tax_query ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- A catalogue filter is exactly what a taxonomy query is for.
		}

		$meta_query = mvweb_core_price_query();

		if ( ! empty( $meta_query ) ) {
			$query->set( 'meta_query', array_merge( (array) $query->get( 'meta_query', array() ), $meta_query ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- The price filter has no taxonomy to live in.
		}

		if ( 'date' === mvweb_core_catalog_orderby() ) {
			$query->set( 'orderby', array( 'date' => 'DESC' ) );
		} elseif ( 'menu_order' === mvweb_core_catalog_orderby() ) {
			$query->set(
				'orderby',
				array(
					'menu_order' => 'ASC',
					'date'       => 'DESC',
				)
			);
		}
	}
}
add_action( 'pre_get_posts', 'mvweb_core_catalog_query' );

if ( ! function_exists( 'mvweb_core_catalog_price_order' ) ) {
	/**
	 * Sort the theme's own catalogue by price, items with no price last.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $clauses Query clauses.
	 * @param WP_Query             $query   Query being run.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_catalog_price_order( $clauses, $query ) {
		if ( mvweb_core_is_woocommerce() || ! mvweb_core_is_catalog_query( $query ) ) {
			return $clauses;
		}

		$orderby = mvweb_core_catalog_orderby();

		if ( 'price' !== $orderby && 'price-desc' !== $orderby ) {
			return $clauses;
		}

		global $wpdb;

		$direction = 'price' === $orderby ? 'ASC' : 'DESC';

		$clauses['join']   .= $wpdb->prepare( " LEFT JOIN {$wpdb->postmeta} AS mv_order_price ON ( mv_order_price.post_id = {$wpdb->posts}.ID AND mv_order_price.meta_key = %s )", '_mvweb_price' );
		$clauses['orderby'] = "( mv_order_price.meta_value IS NULL OR mv_order_price.meta_value = '' ) ASC, CAST( mv_order_price.meta_value AS DECIMAL(20,2) ) {$direction}, {$wpdb->posts}.menu_order ASC, {$wpdb->posts}.post_date DESC";

		return $clauses;
	}
}
add_filter( 'posts_clauses', 'mvweb_core_catalog_price_order', 10, 2 );

if ( ! function_exists( 'mvweb_core_price_query' ) ) {
	/**
	 * The price bounds of the request, as a meta query.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_price_query() {
		$min = mvweb_core_catalog_price_bound( 'min_price' );
		$max = mvweb_core_catalog_price_bound( 'max_price' );

		$clauses = array();

		if ( '' !== $min ) {
			$clauses[] = array(
				'key'     => '_mvweb_price',
				'value'   => (float) $min,
				'type'    => 'DECIMAL(20,2)',
				'compare' => '>=',
			);
		}

		if ( '' !== $max ) {
			$clauses[] = array(
				'key'     => '_mvweb_price',
				'value'   => (float) $max,
				'type'    => 'DECIMAL(20,2)',
				'compare' => '<=',
			);
		}

		return $clauses;
	}
}
