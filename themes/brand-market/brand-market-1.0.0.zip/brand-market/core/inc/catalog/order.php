<?php
/**
 * The manual order of a category.
 *
 * A showroom arranges a category the way it wants it seen, and no sorting by
 * date or by price says that. The order is kept on the term it belongs to
 * rather than on the top of the branch: a moved entry then keeps its place
 * instead of falling out of a slice taken from its parent.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_term_order' ) ) {
	/**
	 * The order stored on a term.
	 *
	 * @since 0.1.0
	 *
	 * @param int $term_id Term id.
	 *
	 * @return int[] Ids, first one first. Empty when nothing was arranged.
	 */
	function mvweb_core_term_order( $term_id ) {
		$stored = (string) get_term_meta( absint( $term_id ), 'mvweb_order', true );

		return array_values( array_filter( array_map( 'absint', explode( ',', $stored ) ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_order_query' ) ) {
	/**
	 * Arrange the listing of a category by hand.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Query being prepared.
	 *
	 * @return void
	 */
	function mvweb_core_order_query( $query ) {
		if ( is_admin() || ! $query->is_main_query() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading a public listing parameter, not acting on it.
		if ( isset( $_GET['orderby'] ) ) {
			return;
		}

		$term = $query->get_queried_object();

		if ( ! $term instanceof WP_Term || ! in_array( $term->taxonomy, mvweb_core_listing_taxonomies(), true ) ) {
			return;
		}

		$order = mvweb_core_term_order( $term->term_id );
		$scope = empty( $order ) ? array() : mvweb_core_term_objects( $term );

		if ( empty( $scope ) ) {
			return;
		}

		$query->set( 'post__in', array_values( array_unique( array_merge( array_intersect( $order, $scope ), $scope ) ) ) );
		$query->set( 'orderby', 'post__in' );
	}
}
add_action( 'pre_get_posts', 'mvweb_core_order_query', 20 );

if ( ! function_exists( 'mvweb_core_order_screen' ) ) {
	/**
	 * The entity the order screen was opened for.
	 *
	 * @since 0.1.0
	 *
	 * @return array{0:string,1:string} Post type and its taxonomy.
	 */
	function mvweb_core_order_screen() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading which admin screen is open, not acting on it.
		$post_type = isset( $_GET['post_type'] ) ? sanitize_key( wp_unslash( $_GET['post_type'] ) ) : '';

		if ( 'mv_service' === $post_type ) {
			return array( 'mv_service', 'mv_service_cat' );
		}

		return array( mvweb_core_post_type(), mvweb_core_taxonomy() );
	}
}

if ( ! function_exists( 'mvweb_core_order_menu' ) ) {
	/**
	 * Add the order screen under both listings.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_order_menu() {
		$screens = array(
			mvweb_core_post_type() => __( 'Order in a category', 'mvweb-core' ),
			'mv_service'           => __( 'Order in a section', 'mvweb-core' ),
		);

		foreach ( $screens as $post_type => $title ) {
			add_submenu_page(
				'edit.php?post_type=' . $post_type,
				$title,
				__( 'Order', 'mvweb-core' ),
				'manage_categories',
				'mvweb-core-order',
				'mvweb_core_order_page'
			);
		}
	}
}
add_action( 'admin_menu', 'mvweb_core_order_menu' );

if ( ! function_exists( 'mvweb_core_order_entries' ) ) {
	/**
	 * Entries of a term, arranged ones first.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Term being arranged.
	 *
	 * @return int[]
	 */
	function mvweb_core_order_entries( $term ) {
		$taxonomy = get_taxonomy( $term->taxonomy );

		if ( ! $taxonomy ) {
			return array();
		}

		$found = get_posts(
			array(
				'post_type'        => $taxonomy->object_type,
				'post_status'      => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'numberposts'      => -1,
				'fields'           => 'ids',
				'suppress_filters' => false,
				'orderby'          => array(
					'menu_order' => 'ASC',
					'date'       => 'DESC',
				),
				'tax_query'        => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- One term is what the screen arranges.
					array(
						'taxonomy'         => $term->taxonomy,
						'field'            => 'term_id',
						'terms'            => $term->term_id,
						'include_children' => false,
					),
				),
			)
		);

		$found = array_map( 'absint', (array) $found );
		$order = mvweb_core_term_order( $term->term_id );

		return array_values( array_merge( array_intersect( $order, $found ), array_diff( $found, $order ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_order_page' ) ) {
	/**
	 * The screen itself: pick a category, drag its cards, save.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_order_page() {
		list( $post_type, $taxonomy ) = mvweb_core_order_screen();

		if ( ! current_user_can( 'manage_categories' ) || ! taxonomy_exists( $taxonomy ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Choosing what to look at, not acting on it.
		$term_id = isset( $_GET['mv_term'] ) ? absint( wp_unslash( $_GET['mv_term'] ) ) : 0;
		$term    = $term_id > 0 ? get_term( $term_id, $taxonomy ) : null;
		$term    = $term instanceof WP_Term ? $term : null;
		$entries = $term ? mvweb_core_order_entries( $term ) : array();
		?>
		<div class="wrap mvweb-core-order">
			<h1><?php echo esc_html( get_admin_page_title() ); ?></h1>

			<?php
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading the result of the redirect that follows a save.
			if ( isset( $_GET['updated'] ) ) :
				?>
				<div class="notice notice-success is-dismissible">
					<p><?php esc_html_e( 'The order is saved.', 'mvweb-core' ); ?></p>
				</div>
			<?php endif; ?>

			<form method="get" action="<?php echo esc_url( admin_url( 'edit.php' ) ); ?>">
				<input type="hidden" name="post_type" value="<?php echo esc_attr( $post_type ); ?>">
				<input type="hidden" name="page" value="mvweb-core-order">

				<?php
				wp_dropdown_categories(
					array(
						'taxonomy'          => $taxonomy,
						'name'              => 'mv_term',
						'selected'          => $term_id,
						'hierarchical'      => true,
						'hide_empty'        => false,
						'show_option_none'  => __( '— pick a category —', 'mvweb-core' ),
						'option_none_value' => 0,
					)
				);
				?>

				<button type="submit" class="button"><?php esc_html_e( 'Show', 'mvweb-core' ); ?></button>
			</form>

			<?php if ( ! $term ) : ?>

				<p class="description"><?php esc_html_e( 'Pick a category to arrange what is filed under it.', 'mvweb-core' ); ?></p>

			<?php elseif ( empty( $entries ) ) : ?>

				<p class="description"><?php esc_html_e( 'Nothing is filed under this category yet.', 'mvweb-core' ); ?></p>

			<?php else : ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'mvweb_order' ); ?>
				<input type="hidden" name="action" value="mvweb_order">
				<input type="hidden" name="post_type" value="<?php echo esc_attr( $post_type ); ?>">
				<input type="hidden" name="taxonomy" value="<?php echo esc_attr( $taxonomy ); ?>">
				<input type="hidden" name="mv_term" value="<?php echo (int) $term->term_id; ?>">
				<input type="hidden" name="mvweb_order" value="<?php echo esc_attr( implode( ',', $entries ) ); ?>" data-mvweb-core-order-value>

				<p class="description"><?php esc_html_e( 'Drag the cards. The listing of the category follows this order; whatever is added later lands at the end.', 'mvweb-core' ); ?></p>

				<ul class="mvweb-core-order__list" data-mvweb-core-order>
					<?php foreach ( $entries as $entry ) : ?>
						<li class="mvweb-core-order__item" data-id="<?php echo (int) $entry; ?>">
							<span class="mvweb-core-order__thumb">
								<?php echo get_the_post_thumbnail( $entry, 'thumbnail' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag. ?>
							</span>
							<span class="mvweb-core-order__title"><?php echo esc_html( get_the_title( $entry ) ); ?></span>
							<a class="mvweb-core-order__edit" href="<?php echo esc_url( (string) get_edit_post_link( $entry ) ); ?>"><?php esc_html_e( 'Edit', 'mvweb-core' ); ?></a>
						</li>
					<?php endforeach; ?>
				</ul>

				<p class="submit">
					<button type="submit" class="button button-primary"><?php esc_html_e( 'Save the order', 'mvweb-core' ); ?></button>
				</p>
			</form>

			<?php endif; ?>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_order_save' ) ) {
	/**
	 * Store what the screen submitted.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_order_save() {
		check_admin_referer( 'mvweb_order' );

		if ( ! current_user_can( 'manage_categories' ) ) {
			wp_die( esc_html__( 'You are not allowed to arrange the catalogue.', 'mvweb-core' ) );
		}

		$post_type = isset( $_POST['post_type'] ) ? sanitize_key( wp_unslash( $_POST['post_type'] ) ) : '';
		$taxonomy  = isset( $_POST['taxonomy'] ) ? sanitize_key( wp_unslash( $_POST['taxonomy'] ) ) : '';
		$term_id   = isset( $_POST['mv_term'] ) ? absint( wp_unslash( $_POST['mv_term'] ) ) : 0;
		$order     = isset( $_POST['mvweb_order'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_order'] ) ) : '';

		if ( $term_id > 0 && in_array( $taxonomy, mvweb_core_listing_taxonomies(), true ) && get_term( $term_id, $taxonomy ) instanceof WP_Term ) {
			if ( '' === $order ) {
				delete_term_meta( $term_id, 'mvweb_order' );
			} else {
				update_term_meta( $term_id, 'mvweb_order', $order );
			}
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'post_type' => $post_type,
					'page'      => 'mvweb-core-order',
					'mv_term'   => $term_id,
					'updated'   => 1,
				),
				admin_url( 'edit.php' )
			)
		);

		exit;
	}
}
add_action( 'admin_post_mvweb_order', 'mvweb_core_order_save' );

if ( ! function_exists( 'mvweb_core_order_assets' ) ) {
	/**
	 * Assets of the order screen.
	 *
	 * @since 0.1.0
	 *
	 * @param string $hook Current admin screen.
	 *
	 * @return void
	 */
	function mvweb_core_order_assets( $hook ) {
		if ( ! str_ends_with( $hook, 'mvweb-core-order' ) ) {
			return;
		}

		$script = mvweb_core_asset_path( '/admin/js/order.js' );

		wp_enqueue_script(
			'mvweb-core-order',
			MVWEB_CORE_URI . $script,
			array( 'jquery-ui-sortable' ),
			mvweb_core_asset_version( $script ),
			true
		);

		mvweb_core_admin_style();
	}
}
add_action( 'admin_enqueue_scripts', 'mvweb_core_order_assets' );
