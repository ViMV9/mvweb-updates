<?php
/**
 * The catalogue of a site without WooCommerce.
 *
 * Nothing here is registered while the plugin is active: the store owns the
 * catalogue then, and a second post type beside it would only split the data
 * of one shop across two places.
 *
 * The bases of the archive and of the categories are settings, because an
 * existing site that moves onto this theme cannot afford new addresses —
 * every one of them is already indexed and already redirected once.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_item_label' ) ) {
	/**
	 * What the catalogue is called in the admin menu.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_item_label() {
		$label = trim( (string) mvweb_core_option( 'mvweb_item_label' ) );

		return '' === $label ? __( 'Catalogue', 'mvweb-core' ) : $label;
	}
}

if ( ! function_exists( 'mvweb_core_register_catalog' ) ) {
	/**
	 * Register the item type, its categories and its properties.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_catalog() {
		if ( mvweb_core_is_woocommerce() ) {
			return;
		}

		$name     = mvweb_core_item_label();
		$base     = sanitize_title( (string) mvweb_core_option( 'mvweb_item_slug' ) );
		$category = sanitize_title( (string) mvweb_core_option( 'mvweb_item_cat_slug' ) );

		$base     = '' === $base ? 'catalog' : $base;
		$category = '' === $category ? 'catalog-cat' : $category;

		register_post_type(
			'mv_item',
			array(
				'labels'        => array(
					'name'                  => $name,
					'singular_name'         => __( 'Item', 'mvweb-core' ),
					'add_new_item'          => __( 'Add item', 'mvweb-core' ),
					'edit_item'             => __( 'Edit item', 'mvweb-core' ),
					'new_item'              => __( 'New item', 'mvweb-core' ),
					'view_item'             => __( 'View item', 'mvweb-core' ),
					'search_items'          => __( 'Search the catalogue', 'mvweb-core' ),
					'not_found'             => __( 'Nothing in the catalogue yet', 'mvweb-core' ),
					'not_found_in_trash'    => __( 'Nothing in the bin', 'mvweb-core' ),
					'all_items'             => $name,
					'menu_name'             => $name,
					'featured_image'        => __( 'Main picture', 'mvweb-core' ),
					'set_featured_image'    => __( 'Set the picture', 'mvweb-core' ),
					'remove_featured_image' => __( 'Remove the picture', 'mvweb-core' ),
					'use_featured_image'    => __( 'Use as the picture', 'mvweb-core' ),
				),
				'description'   => __( 'What the site shows: models, works, goods.', 'mvweb-core' ),
				'public'        => true,
				'show_in_rest'  => true,
				'has_archive'   => $base,
				'rewrite'       => array(
					'slug'       => $base,
					'with_front' => false,
				),
				'menu_icon'     => 'dashicons-products',
				'menu_position' => 25,
				'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
			)
		);

		register_taxonomy(
			'mv_item_cat',
			'mv_item',
			array(
				'labels'            => array(
					'name'              => __( 'Categories', 'mvweb-core' ),
					'singular_name'     => __( 'Category', 'mvweb-core' ),
					'add_new_item'      => __( 'Add category', 'mvweb-core' ),
					'edit_item'         => __( 'Edit category', 'mvweb-core' ),
					'update_item'       => __( 'Update category', 'mvweb-core' ),
					'search_items'      => __( 'Search categories', 'mvweb-core' ),
					'parent_item'       => __( 'Parent category', 'mvweb-core' ),
					'parent_item_colon' => __( 'Parent category:', 'mvweb-core' ),
					'not_found'         => __( 'No categories yet', 'mvweb-core' ),
					'menu_name'         => __( 'Categories', 'mvweb-core' ),
				),
				'hierarchical'      => true,
				'public'            => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'rewrite'           => array(
					'slug'         => $category,
					'with_front'   => false,
					'hierarchical' => true,
				),
			)
		);

		foreach ( mvweb_core_property_settings() as $property ) {
			register_taxonomy(
				mvweb_core_property_taxonomy( $property['slug'] ),
				'mv_item',
				array(
					'labels'             => array(
						'name'          => $property['label'],
						'singular_name' => $property['label'],
						'add_new_item'  => __( 'Add value', 'mvweb-core' ),
						'edit_item'     => __( 'Edit value', 'mvweb-core' ),
						'search_items'  => __( 'Search values', 'mvweb-core' ),
						'not_found'     => __( 'No values yet', 'mvweb-core' ),
						'menu_name'     => $property['label'],
					),
					'hierarchical'       => false,
					'public'             => false,
					'publicly_queryable' => false,
					'show_ui'            => true,
					'show_in_rest'       => true,
					'show_admin_column'  => true,
					'show_in_nav_menus'  => false,
					'query_var'          => false,
					'rewrite'            => false,
				)
			);
		}
	}
}
add_action( 'init', 'mvweb_core_register_catalog' );

if ( ! function_exists( 'mvweb_core_flush_rewrites' ) ) {
	/**
	 * Rebuild the rewrite rules after a base changed.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_flush_rewrites() {
		$fingerprint = md5(
			wp_json_encode(
				array(
					mvweb_core_store(),
					mvweb_core_option( 'mvweb_item_slug' ),
					mvweb_core_option( 'mvweb_item_cat_slug' ),
					mvweb_core_option( 'mvweb_service_slug' ),
					mvweb_core_option( 'mvweb_work_slug' ),
					wp_list_pluck( mvweb_core_property_settings(), 'slug' ),
					mvweb_core_facet_paths(),
				)
			)
		);

		if ( get_option( 'mvweb_core_rewrites' ) === $fingerprint ) {
			return;
		}

		update_option( 'mvweb_core_rewrites', $fingerprint, false );

		flush_rewrite_rules( false );
	}
}
add_action( 'init', 'mvweb_core_flush_rewrites', 20 );

if ( ! function_exists( 'mvweb_core_term_image_field' ) ) {
	/**
	 * The picture of a category, on the form that creates one.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_term_image_field() {
		wp_nonce_field( 'mvweb_term_image', 'mvweb_term_image_nonce' );
		?>
		<div class="form-field mvweb-core-media" data-mvweb-core-media>
			<label><?php esc_html_e( 'Picture', 'mvweb-core' ); ?></label>

			<span class="mvweb-core-media__preview" data-mvweb-core-media-preview></span>

			<input type="hidden" name="mvweb_term_image" value="0" data-mvweb-core-media-value>

			<button type="button" class="button" data-mvweb-core-media-pick><?php esc_html_e( 'Select', 'mvweb-core' ); ?></button>
			<button type="button" class="button-link" data-mvweb-core-media-clear><?php esc_html_e( 'Remove', 'mvweb-core' ); ?></button>

			<p class="description"><?php esc_html_e( 'Shown on the cards of the sections and in the mega menu.', 'mvweb-core' ); ?></p>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_term_image_edit_field' ) ) {
	/**
	 * The picture of a category, on the form that edits one.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Term being edited.
	 *
	 * @return void
	 */
	function mvweb_core_term_image_edit_field( $term ) {
		$id  = absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) );
		$src = wp_attachment_is_image( $id ) ? (string) wp_get_attachment_image_url( $id, 'thumbnail' ) : '';

		wp_nonce_field( 'mvweb_term_image', 'mvweb_term_image_nonce' );
		?>
		<tr class="form-field mvweb-core-media" data-mvweb-core-media>
			<th scope="row"><label><?php esc_html_e( 'Picture', 'mvweb-core' ); ?></label></th>
			<td>
				<span class="mvweb-core-media__preview" data-mvweb-core-media-preview>
					<?php if ( '' !== $src ) : ?>
						<img src="<?php echo esc_url( $src ); ?>" alt="">
					<?php endif; ?>
				</span>

				<input type="hidden" name="mvweb_term_image" value="<?php echo (int) $id; ?>" data-mvweb-core-media-value>

				<button type="button" class="button" data-mvweb-core-media-pick><?php esc_html_e( 'Select', 'mvweb-core' ); ?></button>
				<button type="button" class="button-link" data-mvweb-core-media-clear><?php esc_html_e( 'Remove', 'mvweb-core' ); ?></button>

				<p class="description"><?php esc_html_e( 'Shown on the cards of the sections and in the mega menu.', 'mvweb-core' ); ?></p>
			</td>
		</tr>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_term_image_save' ) ) {
	/**
	 * Store the picture of a category.
	 *
	 * @since 0.1.0
	 *
	 * @param int $term_id Term id.
	 *
	 * @return void
	 */
	function mvweb_core_term_image_save( $term_id ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified below, once the field is known to be present.
		if ( ! isset( $_POST['mvweb_term_image'] ) ) {
			return;
		}

		check_admin_referer( 'mvweb_term_image', 'mvweb_term_image_nonce' );

		if ( ! current_user_can( 'manage_categories' ) ) {
			return;
		}

		$id = absint( wp_unslash( $_POST['mvweb_term_image'] ) );

		if ( wp_attachment_is_image( $id ) ) {
			update_term_meta( $term_id, 'thumbnail_id', $id );

			return;
		}

		delete_term_meta( $term_id, 'thumbnail_id' );
	}
}

if ( ! function_exists( 'mvweb_core_term_image_hooks' ) ) {
	/**
	 * Hang the picture field on the category screens.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_term_image_hooks() {
		if ( mvweb_core_is_woocommerce() ) {
			return;
		}

		add_action( 'mv_item_cat_add_form_fields', 'mvweb_core_term_image_field' );
		add_action( 'mv_item_cat_edit_form_fields', 'mvweb_core_term_image_edit_field' );
		add_action( 'created_mv_item_cat', 'mvweb_core_term_image_save' );
		add_action( 'edited_mv_item_cat', 'mvweb_core_term_image_save' );
	}
}
add_action( 'init', 'mvweb_core_term_image_hooks', 30 );

if ( ! function_exists( 'mvweb_core_term_meta_auth' ) ) {
	/**
	 * Who may write the fields of a category.
	 *
	 * @since 0.1.0
	 *
	 * @param bool   $allowed  Whether the key may be written.
	 * @param string $meta_key Key being written.
	 * @param int    $term_id  Term id.
	 * @param int    $user_id  User doing the writing.
	 *
	 * @return bool
	 */
	function mvweb_core_term_meta_auth( $allowed, $meta_key, $term_id, $user_id ) {
		return user_can( $user_id, 'manage_categories' );
	}
}

if ( ! function_exists( 'mvweb_core_term_text_field' ) ) {
	/**
	 * The second description of a category, on the form that edits one.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Term being edited.
	 *
	 * @return void
	 */
	function mvweb_core_term_text_field( $term ) {
		wp_nonce_field( 'mvweb_term_text', 'mvweb_term_text_nonce' );
		?>
		<tr class="form-field">
			<th scope="row"><label for="mvwebcoretermtext"><?php esc_html_e( 'Text under the listing', 'mvweb-core' ); ?></label></th>
			<td>
				<?php
				wp_editor(
					mvweb_core_term_text( $term->term_id ),
					'mvwebcoretermtext',
					array(
						'textarea_name' => 'mvweb_term_text',
						'textarea_rows' => 12,
						'media_buttons' => false,
					)
				);
				?>
				<p class="description"><?php esc_html_e( 'Printed under the cards, on the first page of the category only. The description above prints over them.', 'mvweb-core' ); ?></p>
			</td>
		</tr>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_term_text_save' ) ) {
	/**
	 * Store the second description of a category.
	 *
	 * @since 0.1.0
	 *
	 * @param int $term_id Term id.
	 *
	 * @return void
	 */
	function mvweb_core_term_text_save( $term_id ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified below, once the field is known to be present.
		if ( ! isset( $_POST['mvweb_term_text'] ) ) {
			return;
		}

		check_admin_referer( 'mvweb_term_text', 'mvweb_term_text_nonce' );

		if ( ! current_user_can( 'manage_categories' ) ) {
			return;
		}

		$value = $_POST['mvweb_term_text']; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- See above.

		if ( '' === trim( (string) $value ) ) {
			delete_term_meta( $term_id, 'mvweb_text' );

			return;
		}

		update_term_meta( $term_id, 'mvweb_text', $value );
	}
}

if ( ! function_exists( 'mvweb_core_register_term_meta' ) ) {
	/**
	 * Register what a listing category carries, on every such taxonomy.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_term_meta() {
		$keys = array(
			'mvweb_text'  => 'wp_kses_post',
			'mvweb_order' => 'mvweb_core_sanitize_ids',
		);

		foreach ( mvweb_core_listing_taxonomies() as $taxonomy ) {
			if ( ! taxonomy_exists( $taxonomy ) ) {
				continue;
			}

			foreach ( $keys as $key => $sanitizer ) {
				register_term_meta(
					$taxonomy,
					$key,
					array(
						'type'              => 'string',
						'single'            => true,
						'default'           => '',
						'sanitize_callback' => $sanitizer,
						'auth_callback'     => 'mvweb_core_term_meta_auth',
						'show_in_rest'      => false,
					)
				);
			}

			add_action( $taxonomy . '_edit_form_fields', 'mvweb_core_term_text_field' );
			add_action( 'edited_' . $taxonomy, 'mvweb_core_term_text_save' );
		}
	}
}
add_action( 'init', 'mvweb_core_register_term_meta', 30 );

if ( ! function_exists( 'mvweb_core_media_field_assets' ) ) {
	/**
	 * The media picker of the catalogue and services screens.
	 *
	 * @since 0.1.0
	 *
	 * @param string $hook Current admin screen.
	 *
	 * @return void
	 */
	function mvweb_core_media_field_assets( $hook ) {
		if ( ! in_array( $hook, array( 'post.php', 'post-new.php', 'edit-tags.php', 'term.php' ), true ) ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		$screens = array( 'mv_item', 'mv_item_cat', 'mv_service', 'mv_service_cat', 'mv_work', 'mv_work_type', 'mv_facet' );

		if ( ! $screen || ( ! in_array( $screen->post_type, $screens, true ) && ! in_array( $screen->taxonomy, $screens, true ) ) ) {
			return;
		}

		wp_enqueue_media();

		$relative = mvweb_core_asset_path( '/admin/js/media-field.js' );

		wp_enqueue_script(
			'mvweb-core-media-field',
			MVWEB_CORE_URI . $relative,
			array( 'media-editor' ),
			mvweb_core_asset_version( $relative ),
			true
		);

		mvweb_core_admin_style();
	}
}
add_action( 'admin_enqueue_scripts', 'mvweb_core_media_field_assets' );

if ( ! function_exists( 'mvweb_core_admin_style' ) ) {
	/**
	 * The stylesheet every screen of the catalogue shares.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_admin_style() {
		$style = mvweb_core_asset_path( '/admin/css/catalog.css' );

		wp_enqueue_style(
			'mvweb-core-admin-catalog',
			MVWEB_CORE_URI . $style,
			array(),
			mvweb_core_asset_version( $style )
		);
	}
}
