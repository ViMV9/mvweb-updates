<?php
/**
 * Fields of a catalogue item.
 *
 * The keys match the ones the WooCommerce side of the theme already writes —
 * the second price and the file link — so a site that switches sources keeps
 * what it typed instead of finding the fields blank.
 *
 * Every key is registered with register_post_meta(), which means the sanitizer
 * travels with the key itself: the box below, wp-cli and an importer all go
 * through the same callback.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_item_meta' ) ) {
	/**
	 * The meta keys of an item and how each is cleaned.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Key => sanitizer.
	 */
	function mvweb_core_item_meta() {
		return array(
			'_mvweb_price'        => 'mvweb_core_sanitize_amount',
			'_mvweb_second_price' => 'mvweb_core_sanitize_amount',
			'_mvweb_sku'          => 'sanitize_text_field',
			'_mvweb_brand'        => 'sanitize_text_field',
			'_mvweb_file_url'     => 'esc_url_raw',
			'_mvweb_featured'     => 'mvweb_core_sanitize_flag',
			'_mvweb_gallery'      => 'mvweb_core_sanitize_ids',
			'_mvweb_specs'        => 'mvweb_core_sanitize_specs',
		);
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_amount' ) ) {
	/**
	 * An amount as it is stored: digits and at most one dot.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string
	 */
	function mvweb_core_sanitize_amount( $value ) {
		if ( is_array( $value ) ) {
			return '';
		}

		$value = preg_replace( '/[^0-9.,]/', '', (string) $value );

		if ( preg_match( '/[.,](?=[^.,]*$)/', $value, $match, PREG_OFFSET_CAPTURE ) ) {
			$last     = $match[0][1];
			$mark     = $match[0][0];
			$whole    = substr( $value, 0, $last );
			$fraction = substr( $value, $last + 1 );
			$mixed    = str_contains( $whole, '.' === $mark ? ',' : '.' );
			$grouping = ! $mixed && ( str_contains( $whole, $mark ) || ( 3 === strlen( $fraction ) && '' !== $whole ) );
			$whole    = preg_replace( '/[.,]/', '', $whole );
			$value    = $grouping ? $whole . $fraction : $whole . '.' . $fraction;
		}

		if ( '' === $value || '.' === $value ) {
			return '';
		}

		return is_numeric( $value ) ? (string) (float) $value : '';
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_flag' ) ) {
	/**
	 * A checkbox as it is stored.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string
	 */
	function mvweb_core_sanitize_flag( $value ) {
		return empty( $value ) ? '' : '1';
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_ids' ) ) {
	/**
	 * A list of attachment ids as it is stored.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string Comma separated ids.
	 */
	function mvweb_core_sanitize_ids( $value ) {
		$ids = is_array( $value ) ? $value : explode( ',', (string) $value );
		$ids = array_filter( array_map( 'absint', $ids ) );

		return implode( ',', array_unique( $ids ) );
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_specs' ) ) {
	/**
	 * Specification rows as they are stored.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string JSON list of rows.
	 */
	function mvweb_core_sanitize_specs( $value ) {
		if ( is_string( $value ) && str_starts_with( ltrim( $value ), '[' ) ) {
			$decoded = json_decode( $value, true );
			$value   = is_array( $decoded ) ? $decoded : $value;
		}

		if ( is_array( $value ) ) {
			$lines = array();

			foreach ( $value as $row ) {
				if ( is_array( $row ) && isset( $row['label'], $row['value'] ) ) {
					$lines[] = $row['label'] . '|' . $row['value'];
				}
			}
		} else {
			$lines = preg_split( '/\R/u', (string) $value );
		}

		$rows = array();

		foreach ( (array) $lines as $line ) {
			$parts = explode( '|', (string) $line, 2 );

			if ( count( $parts ) < 2 ) {
				continue;
			}

			$label = sanitize_text_field( trim( $parts[0] ) );
			$text  = sanitize_text_field( trim( $parts[1] ) );

			if ( '' === $label || '' === $text ) {
				continue;
			}

			$rows[] = array(
				'label' => $label,
				'value' => $text,
			);
		}

		return empty( $rows ) ? '' : (string) wp_json_encode( $rows );
	}
}

if ( ! function_exists( 'mvweb_core_specs_text' ) ) {
	/**
	 * The stored rows, back in the shape the field is typed in.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return string
	 */
	function mvweb_core_specs_text( $id ) {
		$rows  = json_decode( (string) get_post_meta( $id, '_mvweb_specs', true ), true );
		$lines = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			if ( ! is_array( $row ) || ! isset( $row['label'], $row['value'] ) ) {
				continue;
			}

			$lines[] = $row['label'] . ' | ' . $row['value'];
		}

		return implode( "\n", $lines );
	}
}

if ( ! function_exists( 'mvweb_core_register_item_meta' ) ) {
	/**
	 * Register the meta of the item type.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_item_meta() {
		if ( mvweb_core_is_woocommerce() ) {
			return;
		}

		foreach ( mvweb_core_item_meta() as $key => $sanitizer ) {
			register_post_meta(
				'mv_item',
				$key,
				array(
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'sanitize_callback' => $sanitizer,
					'auth_callback'     => 'mvweb_core_post_meta_auth',
					'show_in_rest'      => false,
				)
			);
		}
	}
}
add_action( 'init', 'mvweb_core_register_item_meta', 5 );

if ( ! function_exists( 'mvweb_core_item_meta_boxes' ) ) {
	/**
	 * Add the boxes to the item screen.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_item_meta_boxes() {
		if ( mvweb_core_is_woocommerce() ) {
			return;
		}

		add_meta_box(
			'mvweb-core-item',
			__( 'Catalogue', 'mvweb-core' ),
			'mvweb_core_item_box',
			'mv_item',
			'normal',
			'high'
		);

		add_meta_box(
			'mvweb-core-item-specs',
			__( 'Specifications', 'mvweb-core' ),
			'mvweb_core_item_specs_box',
			'mv_item',
			'normal',
			'default'
		);

		add_meta_box(
			'mvweb-core-item-gallery',
			__( 'Gallery', 'mvweb-core' ),
			'mvweb_core_item_gallery_box',
			'mv_item',
			'side',
			'low'
		);
	}
}
add_action( 'add_meta_boxes', 'mvweb_core_item_meta_boxes' );

if ( ! function_exists( 'mvweb_core_item_box' ) ) {
	/**
	 * Prices, article, brand, file and the showcase flag.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Post being edited.
	 *
	 * @return void
	 */
	function mvweb_core_item_box( $post ) {
		wp_nonce_field( 'mvweb_item', 'mvweb_item_nonce' );

		$price    = (string) get_post_meta( $post->ID, '_mvweb_price', true );
		$turnkey  = (string) get_post_meta( $post->ID, '_mvweb_second_price', true );
		$sku      = (string) get_post_meta( $post->ID, '_mvweb_sku', true );
		$brand    = (string) get_post_meta( $post->ID, '_mvweb_brand', true );
		$file     = (string) get_post_meta( $post->ID, '_mvweb_file_url', true );
		$featured = (string) get_post_meta( $post->ID, '_mvweb_featured', true );
		$empty    = mvweb_core_price_placeholder();
		?>
		<div class="mvweb-core-fields">
			<p class="mvweb-core-field">
				<label for="mvweb-core-price"><?php esc_html_e( 'Price', 'mvweb-core' ); ?></label>
				<input class="widefat" type="text" inputmode="decimal" id="mvweb-core-price" name="mvweb_price" value="<?php echo esc_attr( $price ); ?>">
				<span class="description">
					<?php
					if ( '' === $empty ) {
						esc_html_e( 'Leave empty to print no price at all.', 'mvweb-core' );
					} else {
						printf(
							/* translators: %s: the wording set in the Customizer. */
							esc_html__( 'Leave empty to print «%s» instead.', 'mvweb-core' ),
							esc_html( $empty )
						);
					}
					?>
				</span>
			</p>

			<p class="mvweb-core-field">
				<label for="mvweb-core-second-price"><?php esc_html_e( 'Second price', 'mvweb-core' ); ?></label>
				<input class="widefat" type="text" inputmode="decimal" id="mvweb-core-second-price" name="mvweb_second_price" value="<?php echo esc_attr( $turnkey ); ?>">
				<span class="description"><?php esc_html_e( 'What it is called is set in the Customizer, in the Catalogue panel.', 'mvweb-core' ); ?></span>
			</p>

			<p class="mvweb-core-field">
				<label for="mvweb-core-sku"><?php esc_html_e( 'Article', 'mvweb-core' ); ?></label>
				<input class="widefat" type="text" id="mvweb-core-sku" name="mvweb_sku" value="<?php echo esc_attr( $sku ); ?>">
			</p>

			<p class="mvweb-core-field">
				<label for="mvweb-core-brand"><?php esc_html_e( 'Brand', 'mvweb-core' ); ?></label>
				<input class="widefat" type="text" id="mvweb-core-brand" name="mvweb_brand" value="<?php echo esc_attr( $brand ); ?>">
				<span class="description"><?php esc_html_e( 'The line above the name, on the card and on the page.', 'mvweb-core' ); ?></span>
			</p>

			<p class="mvweb-core-field">
				<label for="mvweb-core-file"><?php esc_html_e( 'File link', 'mvweb-core' ); ?></label>
				<input class="widefat" type="url" id="mvweb-core-file" name="mvweb_file_url" value="<?php echo esc_url( $file ); ?>" placeholder="https://">
				<span class="description"><?php esc_html_e( 'A model, a datasheet, a manual. The label of the link is set in the Customizer.', 'mvweb-core' ); ?></span>
			</p>

			<p class="mvweb-core-field">
				<label>
					<input type="checkbox" name="mvweb_featured" value="1" <?php checked( '1', $featured ); ?>>
					<?php esc_html_e( 'Show in the featured section', 'mvweb-core' ); ?>
				</label>
			</p>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_item_specs_box' ) ) {
	/**
	 * The specifications field.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Post being edited.
	 *
	 * @return void
	 */
	function mvweb_core_item_specs_box( $post ) {
		?>
		<p class="mvweb-core-field">
			<label for="mvweb-core-specs"><?php esc_html_e( 'One row per line, name and value separated by a vertical bar.', 'mvweb-core' ); ?></label>
			<textarea class="widefat" id="mvweb-core-specs" name="mvweb_specs" rows="6" placeholder="<?php esc_attr_e( 'Width | 900 mm', 'mvweb-core' ); ?>"><?php echo esc_textarea( mvweb_core_specs_text( $post->ID ) ); ?></textarea>
			<span class="description"><?php esc_html_e( 'The categories and properties the item is filed under are added to this list on their own.', 'mvweb-core' ); ?></span>
		</p>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_item_gallery_box' ) ) {
	/**
	 * The gallery field.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Post being edited.
	 *
	 * @return void
	 */
	function mvweb_core_item_gallery_box( $post ) {
		$stored = (string) get_post_meta( $post->ID, '_mvweb_gallery', true );
		$ids    = array_filter( array_map( 'absint', explode( ',', $stored ) ) );
		?>
		<div class="mvweb-core-media" data-mvweb-core-media data-mvweb-core-media-multiple="1">
			<span class="mvweb-core-media__preview" data-mvweb-core-media-preview>
				<?php foreach ( $ids as $id ) : ?>
					<?php if ( wp_attachment_is_image( $id ) ) : ?>
						<img src="<?php echo esc_url( (string) wp_get_attachment_image_url( $id, 'thumbnail' ) ); ?>" alt="">
					<?php endif; ?>
				<?php endforeach; ?>
			</span>

			<input type="hidden" name="mvweb_gallery" value="<?php echo esc_attr( implode( ',', $ids ) ); ?>" data-mvweb-core-media-value>

			<button type="button" class="button" data-mvweb-core-media-pick><?php esc_html_e( 'Select', 'mvweb-core' ); ?></button>
			<button type="button" class="button-link" data-mvweb-core-media-clear><?php esc_html_e( 'Remove', 'mvweb-core' ); ?></button>

			<p class="description"><?php esc_html_e( 'The main picture comes first on its own — it is the featured image.', 'mvweb-core' ); ?></p>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_save_item_meta' ) ) {
	/**
	 * Store what the boxes submitted.
	 *
	 * @since 0.1.0
	 *
	 * @param int     $post_id Post being saved.
	 * @param WP_Post $post    Post object.
	 *
	 * @return void
	 */
	function mvweb_core_save_item_meta( $post_id, $post ) {
		if ( 'mv_item' !== $post->post_type ) {
			return;
		}

		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified on the next line.
		if ( ! isset( $_POST['mvweb_item_nonce'] ) ) {
			return;
		}

		check_admin_referer( 'mvweb_item', 'mvweb_item_nonce' );

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		foreach ( mvweb_core_item_meta() as $key => $sanitizer ) {
			$input = 'mvweb_' . substr( $key, strlen( '_mvweb_' ) );

			if ( '_mvweb_featured' === $key ) {
				update_post_meta( $post_id, $key, isset( $_POST[ $input ] ) ? '1' : '' );

				continue;
			}

			if ( ! isset( $_POST[ $input ] ) ) {
				continue;
			}

			update_post_meta( $post_id, $key, $_POST[ $input ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- update_post_meta() unslashes and runs the callback the key is registered with.
		}
	}
}
add_action( 'save_post', 'mvweb_core_save_item_meta', 10, 2 );
