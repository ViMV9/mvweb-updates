<?php
/**
 * Filter pages: a catalogue listing narrowed by a few property values, with an
 * address, a heading and a text of its own.
 *
 * A filtered listing lives at a query string and stays out of the index. A
 * combination that people search for — marble fireplaces, white tiles — gets
 * a landing here instead: the owner picks a category and the values, and the
 * page answers at /category/slug/ with its own H1, text and SEO fields.
 *
 * The request of a landing is turned into the listing of its category before
 * the query runs, so the template, the sidebar, the order and the pages are
 * the listing's own; only the ticked values come from the landing. Yoast is
 * told to describe the page by the landing entry, which gives it the title,
 * description, canonical and sitemap entry of that entry.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_register_facets' ) ) {
	/**
	 * Register the post type of filter pages.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_facets() {
		register_post_type(
			'mv_facet',
			array(
				'labels'              => array(
					'name'               => __( 'Filter pages', 'mvweb-core' ),
					'singular_name'      => __( 'Filter page', 'mvweb-core' ),
					'add_new_item'       => __( 'Add filter page', 'mvweb-core' ),
					'edit_item'          => __( 'Edit filter page', 'mvweb-core' ),
					'new_item'           => __( 'New filter page', 'mvweb-core' ),
					'view_item'          => __( 'View filter page', 'mvweb-core' ),
					'search_items'       => __( 'Search filter pages', 'mvweb-core' ),
					'not_found'          => __( 'No filter pages yet', 'mvweb-core' ),
					'not_found_in_trash' => __( 'No filter pages in the bin', 'mvweb-core' ),
					'all_items'          => __( 'Filter pages', 'mvweb-core' ),
					'menu_name'          => __( 'Filter pages', 'mvweb-core' ),
				),
				'description'         => __( 'Listings narrowed by property values, with an address and a text of their own.', 'mvweb-core' ),
				'public'              => true,
				'publicly_queryable'  => true,
				'exclude_from_search' => true,
				'show_in_menu'        => 'edit.php?post_type=' . mvweb_core_post_type(),
				'show_in_nav_menus'   => true,
				'show_in_rest'        => true,
				'has_archive'         => false,
				'rewrite'             => false,
				'query_var'           => false,
				'supports'            => array( 'title', 'editor', 'excerpt', 'thumbnail' ),
			)
		);

		register_post_meta(
			'mv_facet',
			'_mvweb_facet_term',
			array(
				'type'              => 'integer',
				'single'            => true,
				'default'           => 0,
				'sanitize_callback' => 'mvweb_core_sanitize_facet_term',
				'auth_callback'     => static function ( $allowed, $meta_key, $post_id ) {
					return current_user_can( 'edit_post', $post_id );
				},
			)
		);

		register_post_meta(
			'mv_facet',
			'_mvweb_facet_values',
			array(
				'type'              => 'array',
				'single'            => true,
				'default'           => array(),
				'sanitize_callback' => 'mvweb_core_sanitize_facet_values',
				'auth_callback'     => static function ( $allowed, $meta_key, $post_id ) {
					return current_user_can( 'edit_post', $post_id );
				},
			)
		);
	}
}
add_action( 'init', 'mvweb_core_register_facets', 11 );

if ( ! function_exists( 'mvweb_core_sanitize_facet_term' ) ) {
	/**
	 * A category of the catalogue, or 0 for the whole catalogue.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return int
	 */
	function mvweb_core_sanitize_facet_term( $value ) {
		$term = get_term( absint( $value ), mvweb_core_taxonomy() );

		return $term instanceof WP_Term ? $term->term_id : 0;
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_facet_values' ) ) {
	/**
	 * Term ids of the filterable properties, the rest dropped.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return int[]
	 */
	function mvweb_core_sanitize_facet_values( $value ) {
		$taxonomies = wp_list_pluck( mvweb_core_properties(), 'taxonomy' );
		$ids        = array();

		foreach ( (array) $value as $id ) {
			$term = get_term( absint( $id ) );

			if ( $term instanceof WP_Term && in_array( $term->taxonomy, $taxonomies, true ) ) {
				$ids[] = $term->term_id;
			}
		}

		return array_values( array_unique( $ids ) );
	}
}

if ( ! function_exists( 'mvweb_core_facet_selection' ) ) {
	/**
	 * The values of a landing, by property slug.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Landing id.
	 *
	 * @return array<string,string[]> Term slugs keyed by property slug.
	 */
	function mvweb_core_facet_selection( $id ) {
		$slugs = array();

		foreach ( mvweb_core_properties() as $property ) {
			$slugs[ $property['taxonomy'] ] = $property['slug'];
		}

		$selection = array();

		foreach ( (array) get_post_meta( $id, '_mvweb_facet_values', true ) as $term_id ) {
			$term = get_term( absint( $term_id ) );

			if ( $term instanceof WP_Term && isset( $slugs[ $term->taxonomy ] ) ) {
				$selection[ $slugs[ $term->taxonomy ] ][] = $term->slug;
			}
		}

		return $selection;
	}
}

if ( ! function_exists( 'mvweb_core_facet_key' ) ) {
	/**
	 * One string for a category and a set of values, whatever their order.
	 *
	 * @since 0.1.0
	 *
	 * @param int                   $term_id   Category id, 0 for the catalogue.
	 * @param array<string,mixed[]> $selection Term slugs keyed by property slug.
	 *
	 * @return string Empty when nothing is selected.
	 */
	function mvweb_core_facet_key( $term_id, array $selection ) {
		$parts = array();

		foreach ( $selection as $slug => $values ) {
			$values = array_filter( array_map( 'strval', (array) $values ) );

			if ( $values ) {
				sort( $values );
				$parts[ $slug ] = $slug . '=' . implode( ',', $values );
			}
		}

		if ( ! $parts ) {
			return '';
		}

		ksort( $parts );

		return absint( $term_id ) . '|' . implode( ';', $parts );
	}
}

if ( ! function_exists( 'mvweb_core_facet_conflict' ) ) {
	/**
	 * Whether the address of a landing is taken by a category, an item or a page.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Landing id.
	 *
	 * @return bool
	 */
	function mvweb_core_facet_conflict( $id ) {
		$slug = (string) get_post_field( 'post_name', $id );

		if ( '' === $slug ) {
			return false;
		}

		$own  = untrailingslashit( mvweb_core_facet_url( $id ) );
		$same = static function ( $link ) use ( $own ) {
			return is_string( $link ) && untrailingslashit( $link ) === $own;
		};

		$term = get_term_by( 'slug', $slug, mvweb_core_taxonomy() );

		if ( $term instanceof WP_Term && $same( get_term_link( $term ) ) ) {
			return true;
		}

		$item = get_page_by_path( $slug, OBJECT, mvweb_core_post_type() );

		if ( $item && $same( get_permalink( $item ) ) ) {
			return true;
		}

		$home = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
		$path = trim( (string) wp_parse_url( $own, PHP_URL_PATH ), '/' );
		$path = '' !== $home && str_starts_with( $path, $home . '/' ) ? substr( $path, strlen( $home ) + 1 ) : $path;

		return null !== get_page_by_path( $path );
	}
}

if ( ! function_exists( 'mvweb_core_facets' ) ) {
	/**
	 * Published landings with a free address, keyed by id.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array{term:int,key:string,path:string}>
	 */
	function mvweb_core_facets() {
		static $facets = null;

		if ( null !== $facets ) {
			return $facets;
		}

		$cached = get_option( 'mvweb_core_facets' );

		if ( is_array( $cached ) && isset( $cached['store'], $cached['facets'] ) && mvweb_core_store() === $cached['store'] ) {
			$facets = (array) $cached['facets'];

			return $facets;
		}

		$facets = array();
		$home   = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );

		$posts = get_posts(
			array(
				'post_type'      => 'mv_facet',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'ID',
				'order'          => 'ASC',
			)
		);

		foreach ( $posts as $post ) {
			if ( mvweb_core_facet_conflict( $post->ID ) ) {
				continue;
			}

			$term = absint( get_post_meta( $post->ID, '_mvweb_facet_term', true ) );
			$key  = mvweb_core_facet_key( $term, mvweb_core_facet_selection( $post->ID ) );
			$path = trim( (string) wp_parse_url( mvweb_core_facet_url( $post->ID ), PHP_URL_PATH ), '/' );
			$path = '' !== $home && str_starts_with( $path, $home . '/' ) ? substr( $path, strlen( $home ) + 1 ) : $path;

			if ( '' !== $key && '' !== $path ) {
				$facets[ $post->ID ] = array(
					'term' => $term,
					'key'  => $key,
					'path' => $path,
				);
			}
		}

		update_option(
			'mvweb_core_facets',
			array(
				'store'  => mvweb_core_store(),
				'facets' => $facets,
			),
			true
		);

		return $facets;
	}
}

if ( ! function_exists( 'mvweb_core_facets_reset' ) ) {
	/**
	 * Forget the kept landings; the next request works them out again.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_facets_reset() {
		delete_option( 'mvweb_core_facets' );
	}
}
add_action( 'save_post', 'mvweb_core_facets_reset', 20 );
add_action( 'deleted_post', 'mvweb_core_facets_reset' );
add_action( 'created_term', 'mvweb_core_facets_reset' );
add_action( 'edited_term', 'mvweb_core_facets_reset' );
add_action( 'delete_term', 'mvweb_core_facets_reset' );
add_action( 'customize_save_after', 'mvweb_core_facets_reset' );
add_action( 'update_option_permalink_structure', 'mvweb_core_facets_reset' );
add_action( 'update_option_woocommerce_permalinks', 'mvweb_core_facets_reset' );

if ( ! function_exists( 'mvweb_core_facets_meta_reset' ) ) {
	/**
	 * Forget the kept landings when the values of one change outside its form.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $meta_id  Meta id.
	 * @param int    $post_id  Post id.
	 * @param string $meta_key Meta key.
	 *
	 * @return void
	 */
	function mvweb_core_facets_meta_reset( $meta_id, $post_id, $meta_key ) {
		if ( str_starts_with( (string) $meta_key, '_mvweb_facet_' ) ) {
			mvweb_core_facets_reset();
		}
	}
}
add_action( 'added_post_meta', 'mvweb_core_facets_meta_reset', 10, 3 );
add_action( 'updated_post_meta', 'mvweb_core_facets_meta_reset', 10, 3 );
add_action( 'deleted_post_meta', 'mvweb_core_facets_meta_reset', 10, 3 );

if ( ! function_exists( 'mvweb_core_facet_find' ) ) {
	/**
	 * The landing of a category and a set of values.
	 *
	 * @since 0.1.0
	 *
	 * @param int                   $term_id   Category id, 0 for the catalogue.
	 * @param array<string,mixed[]> $selection Term slugs keyed by property slug.
	 *
	 * @return int Landing id, 0 when there is none.
	 */
	function mvweb_core_facet_find( $term_id, array $selection ) {
		$key = mvweb_core_facet_key( $term_id, $selection );

		if ( '' === $key ) {
			return 0;
		}

		foreach ( mvweb_core_facets() as $id => $facet ) {
			if ( $facet['key'] === $key ) {
				return $id;
			}
		}

		return 0;
	}
}

if ( ! function_exists( 'mvweb_core_filter_url' ) ) {
	/**
	 * Where a set of ticked values leads: the filter page, if there is one.
	 *
	 * @since 0.1.0
	 *
	 * @param int                   $term_id   Category id, 0 for the catalogue.
	 * @param array<string,mixed[]> $selection Term slugs keyed by property slug.
	 * @param string                $base      Listing to add the values to otherwise.
	 *
	 * @return string
	 */
	function mvweb_core_filter_url( $term_id, array $selection, $base ) {
		$facet = mvweb_core_facet_find( $term_id, $selection );

		if ( $facet ) {
			return mvweb_core_facet_url( $facet );
		}

		foreach ( $selection as $slug => $values ) {
			$base = add_query_arg( 'filter_' . $slug, implode( ',', (array) $values ), $base );
		}

		return $base;
	}
}

if ( ! function_exists( 'mvweb_core_facet_base_url' ) ) {
	/**
	 * The listing a landing narrows: its category, or the catalogue.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Landing id.
	 *
	 * @return string
	 */
	function mvweb_core_facet_base_url( $id ) {
		$term = absint( get_post_meta( $id, '_mvweb_facet_term', true ) );

		if ( $term ) {
			$link = get_term_link( $term, mvweb_core_taxonomy() );

			if ( ! is_wp_error( $link ) ) {
				return $link;
			}
		}

		return mvweb_core_catalog_page_url();
	}
}

if ( ! function_exists( 'mvweb_core_facet_url' ) ) {
	/**
	 * Address of a landing: its slug under the listing it narrows.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Landing id.
	 *
	 * @return string
	 */
	function mvweb_core_facet_url( $id ) {
		$slug = (string) get_post_field( 'post_name', $id );

		return user_trailingslashit( untrailingslashit( mvweb_core_facet_base_url( $id ) ) . '/' . $slug );
	}
}

if ( ! function_exists( 'mvweb_core_facet_link' ) ) {
	/**
	 * The address of a published landing wherever WordPress asks for one.
	 *
	 * @since 0.1.0
	 *
	 * @param string  $link Default link.
	 * @param WP_Post $post Post.
	 *
	 * @return string
	 */
	function mvweb_core_facet_link( $link, $post ) {
		if ( 'mv_facet' !== $post->post_type || 'publish' !== $post->post_status || '' === $post->post_name ) {
			return $link;
		}

		return mvweb_core_facet_url( $post->ID );
	}
}
add_filter( 'post_type_link', 'mvweb_core_facet_link', 10, 2 );

if ( ! function_exists( 'mvweb_core_facet_paths' ) ) {
	/**
	 * The path of every landing with a free address, relative to the site root.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,string> Paths keyed by landing id.
	 */
	function mvweb_core_facet_paths() {
		return wp_list_pluck( mvweb_core_facets(), 'path' );
	}
}

if ( ! function_exists( 'mvweb_core_facet_rewrites' ) ) {
	/**
	 * One rule per landing, on top of the others.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_facet_rewrites() {
		if ( ! mvweb_core_module( 'catalog' ) ) {
			return;
		}

		foreach ( mvweb_core_facet_paths() as $id => $path ) {
			$path = preg_quote( rawurldecode( $path ), '#' );

			add_rewrite_rule( '^' . $path . '/page/([0-9]{1,})/?$', 'index.php?mv_landing=' . $id . '&paged=$matches[1]', 'top' );
			add_rewrite_rule( '^' . $path . '/?$', 'index.php?mv_landing=' . $id, 'top' );
		}
	}
}
add_action( 'init', 'mvweb_core_facet_rewrites', 15 );

if ( ! function_exists( 'mvweb_core_facet_query_var' ) ) {
	/**
	 * The query variable of a landing request.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $vars Public query variables.
	 *
	 * @return string[]
	 */
	function mvweb_core_facet_query_var( $vars ) {
		$vars[] = 'mv_landing';

		return $vars;
	}
}
add_filter( 'query_vars', 'mvweb_core_facet_query_var' );

if ( ! function_exists( 'mvweb_core_current_facet' ) ) {
	/**
	 * The landing this request shows, 0 when it shows none.
	 *
	 * @since 0.1.0
	 *
	 * @param int|null $set Landing id to remember; only the request parser sets it.
	 *
	 * @return int
	 */
	function mvweb_core_current_facet( $set = null ) {
		static $current = 0;

		if ( null !== $set ) {
			$current = absint( $set );
		}

		return $current;
	}
}

if ( ! function_exists( 'mvweb_core_facet_request' ) ) {
	/**
	 * Turn a landing request into the listing it narrows.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $vars Parsed query variables.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_facet_request( $vars ) {
		if ( is_admin() ) {
			return $vars;
		}

		$post = null;

		if ( ! empty( $vars['mv_landing'] ) ) {
			$post = get_post( absint( $vars['mv_landing'] ) );

			if ( ! $post || 'mv_facet' !== $post->post_type || 'publish' !== $post->post_status ) {
				return array( 'error' => '404' );
			}
		} elseif ( isset( $vars['post_type'], $vars['p'] ) && 'mv_facet' === $vars['post_type'] ) {
			$post = get_post( absint( $vars['p'] ) );

			if ( ! $post || 'mv_facet' !== $post->post_type ) {
				return $vars;
			}

			if ( 'publish' !== $post->post_status && ! current_user_can( 'edit_post', $post->ID ) ) {
				return array( 'error' => '404' );
			}
		}

		if ( ! $post ) {
			return $vars;
		}

		mvweb_core_current_facet( $post->ID );

		$listing = array();
		$term    = get_term( absint( get_post_meta( $post->ID, '_mvweb_facet_term', true ) ), mvweb_core_taxonomy() );

		if ( $term instanceof WP_Term ) {
			$listing[ mvweb_core_taxonomy() ] = $term->slug;
		} else {
			$listing['post_type'] = mvweb_core_post_type();
		}

		if ( ! empty( $vars['paged'] ) ) {
			$listing['paged'] = absint( $vars['paged'] );
		}

		return $listing;
	}
}
add_filter( 'request', 'mvweb_core_facet_request' );

if ( ! function_exists( 'mvweb_core_facet_tax_query' ) ) {
	/**
	 * The values of the current landing as taxonomy clauses.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_facet_tax_query() {
		$facet = mvweb_core_current_facet();

		if ( ! $facet ) {
			return array();
		}

		$taxonomies = array();

		foreach ( mvweb_core_properties() as $property ) {
			$taxonomies[ $property['slug'] ] = $property['taxonomy'];
		}

		$clauses = array();

		foreach ( mvweb_core_facet_selection( $facet ) as $slug => $values ) {
			$clauses[] = array(
				'taxonomy' => $taxonomies[ $slug ],
				'field'    => 'slug',
				'terms'    => $values,
				'operator' => 'IN',
			);
		}

		return $clauses;
	}
}

if ( ! function_exists( 'mvweb_core_wc_facet_query' ) ) {
	/**
	 * Narrow the store's listing to the values of the landing.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Product query.
	 *
	 * @return void
	 */
	function mvweb_core_wc_facet_query( $query ) {
		$clauses = mvweb_core_facet_tax_query();

		if ( ! $clauses ) {
			return;
		}

		$query->set( 'tax_query', array_merge( (array) $query->get( 'tax_query', array() ), $clauses ) ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- A catalogue filter is exactly what a taxonomy query is for.
	}
}
add_action( 'woocommerce_product_query', 'mvweb_core_wc_facet_query' );

if ( ! function_exists( 'mvweb_core_facet_redirect' ) ) {
	/**
	 * Send a filtered address that matches a landing to the landing.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_facet_redirect() {
		if ( mvweb_core_current_facet() || ! mvweb_core_is_catalog() || is_paged() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading public listing parameters, not acting on them.
		if ( isset( $_GET['min_price'] ) || isset( $_GET['max_price'] ) || ! empty( mvweb_core_catalog_requested( 'subcategory' ) ) ) {
			return;
		}

		$term  = get_queried_object();
		$facet = mvweb_core_facet_find(
			$term instanceof WP_Term && mvweb_core_taxonomy() === $term->taxonomy ? $term->term_id : 0,
			mvweb_core_catalog_selection( false )
		);

		if ( ! $facet ) {
			return;
		}

		$url   = mvweb_core_facet_url( $facet );
		$order = mvweb_core_catalog_orderby();

		if ( 'menu_order' !== $order ) {
			$url = add_query_arg( 'orderby', $order, $url );
		}

		wp_safe_redirect( $url, 301 );
		exit;
	}
}
add_action( 'template_redirect', 'mvweb_core_facet_redirect', 5 );

if ( ! function_exists( 'mvweb_core_facet_yoast_page' ) ) {
	/**
	 * Let Yoast describe a landing by its own entry.
	 *
	 * @since 0.1.0
	 *
	 * @param int $page_id Page id Yoast found.
	 *
	 * @return int
	 */
	function mvweb_core_facet_yoast_page( $page_id ) {
		$facet = mvweb_core_current_facet();

		return $facet ? $facet : $page_id;
	}
}
add_filter( 'wpseo_frontend_page_type_simple_page_id', 'mvweb_core_facet_yoast_page', 20 );

if ( ! function_exists( 'mvweb_core_facet_canonical' ) ) {
	/**
	 * The address of the landing as it is now, page number included; its first page when Site Optimizer leads the canonical of the next pages to the first one.
	 *
	 * @since 0.1.0
	 *
	 * @param string $url Address Yoast built.
	 *
	 * @return string
	 */
	function mvweb_core_facet_canonical( $url ) {
		$facet = mvweb_core_current_facet();

		if ( ! $facet || ! is_string( $url ) || '' === $url ) {
			return $url;
		}

		$first = function_exists( 'mvweb_so_check_option' ) && mvweb_so_check_option( 'yoast_canonical_pagination' );

		return mvweb_core_facet_page_url( $facet, $first ? 1 : absint( get_query_var( 'paged' ) ) );
	}
}
add_filter( 'wpseo_canonical', 'mvweb_core_facet_canonical', 20 );
add_filter( 'wpseo_opengraph_url', 'mvweb_core_facet_canonical', 20 );

if ( ! function_exists( 'mvweb_core_facet_page_url' ) ) {
	/**
	 * The address of one page of a landing.
	 *
	 * @since 0.1.0
	 *
	 * @param int $facet Landing id.
	 * @param int $paged Page number.
	 *
	 * @return string
	 */
	function mvweb_core_facet_page_url( $facet, $paged ) {
		$own = mvweb_core_facet_url( $facet );

		return $paged > 1 ? user_trailingslashit( untrailingslashit( $own ) . '/page/' . $paged ) : $own;
	}
}

if ( ! function_exists( 'mvweb_core_facet_adjacent' ) ) {
	/**
	 * The previous and the next page of the landing for Yoast, empty outside the pages it has.
	 *
	 * @since 0.1.0
	 *
	 * @param string $link Address Yoast built.
	 * @param string $rel  Prev or next.
	 *
	 * @return string
	 */
	function mvweb_core_facet_adjacent( $link, $rel ) {
		$facet = mvweb_core_current_facet();

		if ( ! $facet || ! in_array( $rel, array( 'prev', 'next' ), true ) ) {
			return $link;
		}

		$paged = max( 1, absint( get_query_var( 'paged' ) ) );
		$page  = 'prev' === $rel ? $paged - 1 : $paged + 1;

		return $page >= 1 && $page <= (int) $GLOBALS['wp_query']->max_num_pages ? mvweb_core_facet_page_url( $facet, $page ) : '';
	}
}
add_filter( 'wpseo_adjacent_rel_url', 'mvweb_core_facet_adjacent', 20, 2 );

if ( ! function_exists( 'mvweb_core_facet_yoast_title' ) ) {
	/**
	 * The title of a landing over the whole catalogue from its own fields, or from the template of the landings when they are empty.
	 *
	 * @since 0.1.0
	 *
	 * @param string $title        Title Yoast built.
	 * @param object $presentation Yoast presentation of the page.
	 *
	 * @return string
	 */
	function mvweb_core_facet_yoast_title( $title, $presentation = null ) {
		if ( ! mvweb_core_current_facet() || ! is_object( $presentation ) || ! function_exists( 'wpseo_replace_vars' ) || ! function_exists( 'is_shop' ) || ! is_shop() ) {
			return $title;
		}

		return wpseo_replace_vars( (string) $presentation->title, $presentation->source );
	}
}
add_filter( 'wpseo_title', 'mvweb_core_facet_yoast_title', 20, 2 );

if ( ! function_exists( 'mvweb_core_facet_yoast_description' ) ) {
	/**
	 * The description of a landing over the whole catalogue from its own fields, or from the template of the landings when they are empty.
	 *
	 * @since 0.1.0
	 *
	 * @param string $description  Description Yoast built.
	 * @param object $presentation Yoast presentation of the page.
	 *
	 * @return string
	 */
	function mvweb_core_facet_yoast_description( $description, $presentation = null ) {
		if ( ! mvweb_core_current_facet() || ! is_object( $presentation ) || ! function_exists( 'wpseo_replace_vars' ) || ! function_exists( 'is_shop' ) || ! is_shop() ) {
			return $description;
		}

		return wpseo_replace_vars( (string) $presentation->meta_description, $presentation->source );
	}
}
add_filter( 'wpseo_metadesc', 'mvweb_core_facet_yoast_description', 20, 2 );

if ( ! function_exists( 'mvweb_core_facet_sitemap_url' ) ) {
	/**
	 * The current address of a landing in the Yoast sitemap.
	 *
	 * @since 0.1.0
	 *
	 * @param string  $url  Address.
	 * @param WP_Post $post Entry.
	 *
	 * @return string
	 */
	function mvweb_core_facet_sitemap_url( $url, $post ) {
		return $post instanceof WP_Post && 'mv_facet' === $post->post_type ? mvweb_core_facet_url( $post->ID ) : $url;
	}
}
add_filter( 'wpseo_xml_sitemap_post_url', 'mvweb_core_facet_sitemap_url', 10, 2 );

if ( ! function_exists( 'mvweb_core_facet_document_title' ) ) {
	/**
	 * The heading of the landing in the title tag, when no SEO plugin sets it.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $parts Title parts.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_facet_document_title( $parts ) {
		$facet = mvweb_core_current_facet();

		if ( $facet ) {
			$parts['title'] = get_the_title( $facet );
		}

		return $parts;
	}
}
add_filter( 'document_title_parts', 'mvweb_core_facet_document_title' );

if ( ! function_exists( 'mvweb_core_facet_crumbs' ) ) {
	/**
	 * Put the landing after the listing it narrows.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $items Trail items.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_facet_crumbs( $items ) {
		$facet = mvweb_core_current_facet();

		if ( ! $facet || empty( $items ) ) {
			return $items;
		}

		$crumb = array( 'label' => get_the_title( $facet ) );

		$page = is_paged() && count( $items ) > 2 ? array_pop( $items ) : null;

		if ( $page ) {
			$crumb['url'] = mvweb_core_facet_url( $facet );
		}

		$last                  = count( $items ) - 1;
		$items[ $last ]['url'] = mvweb_core_facet_base_url( $facet );
		$items[]               = $crumb;

		if ( $page ) {
			$items[] = $page;
		}

		return $items;
	}
}
add_filter( 'mvweb_core_crumb_items', 'mvweb_core_facet_crumbs' );

if ( ! function_exists( 'mvweb_core_facet_meta_box' ) ) {
	/**
	 * Add the box that says what the landing shows.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_facet_meta_box() {
		add_meta_box( 'mvweb-core-facet', __( 'What the page shows', 'mvweb-core' ), 'mvweb_core_facet_box', 'mv_facet', 'normal', 'high' );
	}
}
add_action( 'add_meta_boxes', 'mvweb_core_facet_meta_box' );

if ( ! function_exists( 'mvweb_core_facet_box' ) ) {
	/**
	 * Print the category and the property values of a landing.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Landing being edited.
	 *
	 * @return void
	 */
	function mvweb_core_facet_box( $post ) {
		wp_nonce_field( 'mvweb_facet', 'mvweb_facet_nonce' );

		$term   = absint( get_post_meta( $post->ID, '_mvweb_facet_term', true ) );
		$values = array_map( 'absint', (array) get_post_meta( $post->ID, '_mvweb_facet_values', true ) );
		?>
		<div class="mvweb-core-fields">
			<p class="mvweb-core-field">
				<label for="mvweb-core-facet-term"><?php esc_html_e( 'Category', 'mvweb-core' ); ?></label>
				<?php
				wp_dropdown_categories(
					array(
						'taxonomy'          => mvweb_core_taxonomy(),
						'name'              => 'mvweb_facet_term',
						'id'                => 'mvweb-core-facet-term',
						'class'             => 'widefat',
						'selected'          => $term,
						'hierarchical'      => true,
						'hide_empty'        => false,
						'show_option_none'  => __( 'The whole catalogue', 'mvweb-core' ),
						'option_none_value' => 0,
					)
				);
				?>
				<span class="description"><?php esc_html_e( 'The page lives under this category and shows its items.', 'mvweb-core' ); ?></span>
			</p>

			<?php
			foreach ( mvweb_core_properties() as $property ) :
				$terms = get_terms(
					array(
						'taxonomy'   => $property['taxonomy'],
						'hide_empty' => false,
					)
				);

				if ( is_wp_error( $terms ) || empty( $terms ) ) {
					continue;
				}
				?>
				<fieldset class="mvweb-core-field">
					<legend><strong><?php echo esc_html( $property['label'] ); ?></strong></legend>
					<?php foreach ( $terms as $value ) : ?>
						<label class="mvweb-core-facet__value">
							<input type="checkbox" name="mvweb_facet_values[]" value="<?php echo esc_attr( (string) $value->term_id ); ?>" <?php checked( in_array( $value->term_id, $values, true ) ); ?>>
							<?php echo esc_html( $value->name ); ?>
						</label>
					<?php endforeach; ?>
				</fieldset>
			<?php endforeach; ?>

			<p class="description">
				<?php esc_html_e( 'The title of the entry is the H1 of the page, the excerpt goes above the items and the text below them. A visitor who ticks exactly these values in the filter is sent here.', 'mvweb-core' ); ?>
			</p>

			<?php if ( mvweb_core_facet_conflict( $post->ID ) ) : ?>
				<p class="notice notice-error inline"><?php esc_html_e( 'This address is taken by a subcategory or an item, so the page does not open. Change the slug.', 'mvweb-core' ); ?></p>
			<?php elseif ( 'publish' === $post->post_status && '' !== $post->post_name ) : ?>
				<p class="mvweb-core-field">
					<strong><?php esc_html_e( 'Address', 'mvweb-core' ); ?>:</strong>
					<a href="<?php echo esc_url( mvweb_core_facet_url( $post->ID ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( rawurldecode( mvweb_core_facet_url( $post->ID ) ) ); ?></a>
				</p>
			<?php endif; ?>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_facet_save' ) ) {
	/**
	 * Store the category and the values of a landing.
	 *
	 * @since 0.1.0
	 *
	 * @param int     $post_id Post id.
	 * @param WP_Post $post    Post.
	 *
	 * @return void
	 */
	function mvweb_core_facet_save( $post_id, $post ) {
		if ( 'mv_facet' !== $post->post_type || ! isset( $_POST['mvweb_facet_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mvweb_facet_nonce'] ) ), 'mvweb_facet' ) ) {
			return;
		}

		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$term   = isset( $_POST['mvweb_facet_term'] ) ? absint( wp_unslash( $_POST['mvweb_facet_term'] ) ) : 0;
		$values = isset( $_POST['mvweb_facet_values'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['mvweb_facet_values'] ) ) : array();

		update_post_meta( $post_id, '_mvweb_facet_term', $term );
		update_post_meta( $post_id, '_mvweb_facet_values', $values );
	}
}
add_action( 'save_post', 'mvweb_core_facet_save', 10, 2 );
