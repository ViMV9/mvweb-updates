<?php
/**
 * Catalog options.
 *
 * The card can carry two prices, and whether it does and what each of them is
 * called depends on the trade — a fireplace shop sells a facing and a turnkey
 * job, a furniture shop sells one thing at one price. The second price is
 * therefore a switch and both captions are fields, empty out of the box.
 *
 * Without WooCommerce the theme also owns the post type behind the catalogue,
 * so the addresses, the properties and the currency are settings too.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_customizer_tree' ) ) {
	/**
	 * Offer the catalogue panel on a site without the store.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_customizer_tree( $tree ) {
		if ( ! isset( $tree['mvweb_cz_catalog'] ) ) {
			$tree['mvweb_cz_catalog'] = array(
				'title'    => __( 'MVweb: Catalogue', 'mvweb-core' ),
				'priority' => 36,
				'sections' => array(
					'mvweb_cz_catalog_archive' => __( 'Listing and categories', 'mvweb-core' ),
					'mvweb_cz_catalog_product' => __( 'Item page', 'mvweb-core' ),
				),
			);
		}

		if ( ! mvweb_core_is_woocommerce() ) {
			$tree['mvweb_cz_catalog']['sections'] = array( 'mvweb_cz_catalog_setup' => __( 'Post type and addresses', 'mvweb-core' ) ) + $tree['mvweb_cz_catalog']['sections'];
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_customizer_tree' );

if ( ! function_exists( 'mvweb_core_catalog_fields' ) ) {
	/**
	 * Fields of the catalog sections.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_catalog_fields() {
		$defaults = mvweb_core_catalog_defaults();

		$fields = array(
			...mvweb_core_catalog_view_fields( 'mvweb_cz_catalog_archive' ),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_price_label',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'Caption of the price', 'mvweb-core' ),
				'description' => __( 'For example: facing only. Leave empty to print the price on its own.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_price_label'],
			),
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_second_price',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'Second price', 'mvweb-core' ),
				'description' => __( 'A second line of price on every card and item page, for example the price with installation. The amount is filled in on the item; where it is missing, the line is not printed.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_second_price'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_second_price_label',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'Caption of the second price', 'mvweb-core' ),
				'description' => __( 'For example: turnkey. Leave empty to print the price on its own.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_second_price_label'],
				'required'    => array(
					array(
						'setting'  => 'mvweb_second_price',
						'operator' => '==',
						'value'    => true,
					),
				),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_price_empty',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'Instead of a price nobody filled in', 'mvweb-core' ),
				'description' => __( 'For example: on request. Empty prints no price line at all.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_price_empty'],
			),
			array(
				'type'        => 'checkbox',
				'settings'    => 'mvweb_price_request_out',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'The same for items out of stock', 'mvweb-core' ),
				'description' => __( 'A WooCommerce product that is out of stock shows the line above instead of its price.', 'mvweb-core' ),
				'default'     => false,
			),
			array(
				'type'        => 'image',
				'settings'    => 'mvweb_placeholder_image',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'Picture for an item that has none', 'mvweb-core' ),
				'description' => __( 'Leave empty to print nothing in that place.', 'mvweb-core' ),
				'default'     => (string) $defaults['mvweb_placeholder_image'],
			),
			array(
				'type'        => 'textarea',
				'settings'    => 'mvweb_product_promo',
				'section'     => 'mvweb_cz_catalog_product',
				'label'       => __( 'Line at the buttons', 'mvweb-core' ),
				'description' => __( 'What the visitor gets for asking. It stands where the part “Line under the buttons” of the purchase block stands. Leave empty to hide.', 'mvweb-core' ),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_product_file_label',
				'section'     => 'mvweb_cz_catalog_product',
				'label'       => __( 'Label of the file link', 'mvweb-core' ),
				'description' => __( 'The address itself is filled in on the item.', 'mvweb-core' ),
				'default'     => __( 'Download the model', 'mvweb-core' ),
			),
			array(
				'type'        => 'radio',
				'settings'    => 'mvweb_shop_mode',
				'section'     => 'mvweb_cz_modules_main',
				'required'    => array(
					array(
						'setting'  => 'mvweb_module_catalog',
						'operator' => '==',
						'value'    => 'woocommerce',
					),
				),
				'label'       => __( 'How the catalogue sells', 'mvweb-core' ),
				'description' => __( 'The shop puts a quantity and an add to cart button on the cards and the item page. Works with WooCommerce only. In the showroom the cards print the price as “from” without its caption, the old price and the wholesale price; the item page prints them all.', 'mvweb-core' ),
				'default'     => 'showcase',
				'choices'     => array(
					'showcase' => __( 'Showroom: orders by request', 'mvweb-core' ),
					'shop'     => __( 'Shop: through the cart', 'mvweb-core' ),
				),
			),
			array(
				'type'        => 'checkbox',
				'settings'    => 'mvweb_wholesale',
				'section'     => 'mvweb_cz_catalog_product',
				'label'       => __( 'Wholesale prices', 'mvweb-core' ),
				'description' => __( 'Shows the wholesale price of an item next to the retail one. A customer marked as wholesale in their profile sees and pays the wholesale price after signing in.', 'mvweb-core' ),
				'default'     => false,
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_wholesale_label',
				'section'  => 'mvweb_cz_catalog_product',
				'label'    => __( 'Caption of the wholesale price', 'mvweb-core' ),
				'default'  => __( 'Wholesale', 'mvweb-core' ),
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_markets_title',
				'section'  => 'mvweb_cz_catalog_product',
				'label'    => __( 'Heading above the marketplaces', 'mvweb-core' ),
				'default'  => __( 'Buy at retail', 'mvweb-core' ),
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_product_benefits_title',
				'section'  => 'mvweb_cz_catalog_product',
				'label'    => __( 'Heading of the benefits list', 'mvweb-core' ),
			),
			array(
				'type'        => 'repeater',
				'settings'    => 'mvweb_product_benefits',
				'section'     => 'mvweb_cz_catalog_product',
				'label'       => __( 'Benefits list', 'mvweb-core' ),
				'description' => __( 'The same list on every item. Empty means no block.', 'mvweb-core' ),
				'default'     => wp_json_encode( array() ),
				'fields'      => array(
					'text' => array(
						'type'    => 'textarea',
						'label'   => __( 'Line', 'mvweb-core' ),
						'choices' => array(),
					),
				),
			),
			array(
				'type'        => 'textarea',
				'settings'    => 'mvweb_product_note',
				'section'     => 'mvweb_cz_catalog_product',
				'label'       => __( 'Note under the specifications', 'mvweb-core' ),
				'description' => __( 'What the price does and does not cover, how the measurement works.', 'mvweb-core' ),
			),
			array(
				'type'        => 'select',
				'settings'    => 'mvweb_switch_property',
				'section'     => 'mvweb_cz_catalog_product',
				'label'       => __( 'Links by the value of a property', 'mvweb-core' ),
				'description' => __( 'Under the price: the same kind of item in the other values of this property.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_switch_property'],
				'choices'     => mvweb_core_property_choices(),
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_related_count',
				'section'     => 'mvweb_cz_catalog_product',
				'label'       => __( 'How many similar items to show', 'mvweb-core' ),
				'description' => __( 'Under the item: the ones of its category, filled up by matching properties. 0 hides the block.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_related_count'],
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 12,
					'step' => 1,
				),
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_related_title',
				'section'  => 'mvweb_cz_catalog_product',
				'label'    => __( 'Heading of the similar items', 'mvweb-core' ),
				'default'  => $defaults['mvweb_related_title'],
			),
		);

		if ( mvweb_core_is_woocommerce() ) {
			return array_merge( $fields, mvweb_core_sidebar_fields( 'mvweb_cz_catalog_archive' ) );
		}

		return array_merge( $fields, mvweb_core_setup_fields() );
	}
}

if ( ! function_exists( 'mvweb_core_sidebar_fields' ) ) {
	/**
	 * The two sidebar blocks that are not properties: the price and the subcategories.
	 *
	 * @since 0.1.0
	 *
	 * @param string $section Section the switches go to.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_sidebar_fields( $section ) {
		return array(
			array(
				'type'     => 'toggle',
				'settings' => 'mvweb_filter_price',
				'section'  => $section,
				'label'    => __( 'Price filter in the sidebar', 'mvweb-core' ),
				'default'  => true,
			),
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_filter_subcategories',
				'section'     => $section,
				'label'       => __( 'Subcategories in the sidebar', 'mvweb-core' ),
				'description' => __( 'The children of the category being shown; on the catalogue itself, the top level.', 'mvweb-core' ),
				'default'     => true,
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_property_choices' ) ) {
	/**
	 * The filterable properties, as the options of a field.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_property_choices() {
		$choices = array( '' => __( 'Do not show', 'mvweb-core' ) );

		foreach ( mvweb_core_properties() as $property ) {
			$choices[ $property['slug'] ] = $property['label'];
		}

		return $choices;
	}
}

if ( ! function_exists( 'mvweb_core_setup_fields' ) ) {
	/**
	 * Fields that only matter while the theme owns the catalogue.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_setup_fields() {
		$defaults = mvweb_core_catalog_defaults();

		return array(
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_item_label',
				'section'     => 'mvweb_cz_catalog_setup',
				'label'       => __( 'What the section is called', 'mvweb-core' ),
				'description' => __( 'In the admin menu. For example: Catalogue, Models, Works.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_item_label'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_item_slug',
				'section'     => 'mvweb_cz_catalog_setup',
				'label'       => __( 'Base of the addresses', 'mvweb-core' ),
				'description' => __( 'The archive lives at /base/ and an item at /base/name/. Changing this on a live site breaks every address it already has.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_item_slug'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_item_cat_slug',
				'section'     => 'mvweb_cz_catalog_setup',
				'label'       => __( 'Base of the category addresses', 'mvweb-core' ),
				'description' => __( 'A category lives at /base/name/.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_item_cat_slug'],
			),
			...mvweb_core_sidebar_fields( 'mvweb_cz_catalog_setup' ),
			array(
				'type'        => 'repeater',
				'settings'    => 'mvweb_item_properties',
				'section'     => 'mvweb_cz_catalog_setup',
				'label'       => __( 'Filterable properties', 'mvweb-core' ),
				'description' => __( 'A line here is a field on the item and a filter in the sidebar, in the order of the lines. The slug is latin, lowercase, and must not change once values are assigned to it.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_item_properties'],
				'fields'      => array(
					'label'   => array(
						'type'    => 'text',
						'label'   => __( 'Name', 'mvweb-core' ),
						'choices' => array(),
					),
					'slug'    => array(
						'type'    => 'text',
						'label'   => __( 'Slug', 'mvweb-core' ),
						'choices' => array(),
					),
					'sidebar' => array(
						'type'    => 'select',
						'label'   => __( 'In the sidebar', 'mvweb-core' ),
						'choices' => array(
							'show' => __( 'Shown', 'mvweb-core' ),
							'hide' => __( 'Hidden', 'mvweb-core' ),
						),
					),
				),
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_items_per_page',
				'section'     => 'mvweb_cz_catalog_setup',
				'label'       => __( 'Items per page', 'mvweb-core' ),
				'default'     => $defaults['mvweb_items_per_page'],
				'input_attrs' => array(
					'min'  => 1,
					'max'  => 96,
					'step' => 1,
				),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_currency',
				'section'     => 'mvweb_cz_catalog_setup',
				'label'       => __( 'Currency symbol', 'mvweb-core' ),
				'description' => __( 'Empty prints the number on its own.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_currency'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_currency_code',
				'section'     => 'mvweb_cz_catalog_setup',
				'label'       => __( 'Currency code', 'mvweb-core' ),
				'description' => __( 'Three letters for search engines: RUB, BYN, KZT, PLN, EUR, USD. The symbol above is what visitors see.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_currency_code'],
			),
			array(
				'type'     => 'radio',
				'settings' => 'mvweb_currency_position',
				'section'  => 'mvweb_cz_catalog_setup',
				'label'    => __( 'Where the symbol goes', 'mvweb-core' ),
				'default'  => $defaults['mvweb_currency_position'],
				'choices'  => array(
					'after'  => __( 'After', 'mvweb-core' ),
					'before' => __( 'Before', 'mvweb-core' ),
				),
			),
		);
	}
}
