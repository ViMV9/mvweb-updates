<?php
/**
 * Theme options.
 *
 * The studio baseline already carries contacts, schedule, socials and company
 * details, and the elements read them from there — this file adds only what is
 * specific to this theme: the composition of every zone and the few fields no
 * baseline section covers.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_customizer_register' ) ) {
	/**
	 * Register the baseline tree and this theme's fields.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_customizer_register( $kit ) {
		mvweb_cz_baseline( $kit );

		$kit->add_fields( mvweb_core_design_fields() );
		$kit->add_fields( mvweb_core_zone_fields() );
		$kit->add_fields( mvweb_core_layout_fields() );
		$kit->add_fields( mvweb_core_motion_fields() );
		$kit->add_fields( mvweb_core_source_fields() );
		$kit->add_fields( mvweb_core_city_fields() );
		$kit->add_fields( mvweb_core_shop_data_fields() );
		$kit->add_fields( mvweb_core_frame_fields() );
		$kit->add_fields( mvweb_core_logo_fields() );
		$kit->add_fields( mvweb_core_home_fields() );
		$kit->add_fields( mvweb_core_catalog_fields() );
		$kit->add_fields( mvweb_core_services_fields() );
		$kit->add_fields( mvweb_core_conversion_fields() );
		$kit->add_fields( mvweb_core_single_fields() );
		$kit->add_fields( mvweb_core_share_fields() );

		if ( function_exists( 'mvweb_core_favorites_fields' ) ) {
			$kit->add_fields( mvweb_core_favorites_fields() );
		}
		$kit->add_fields( mvweb_core_footer_fields() );

		/**
		 * Let companion plugins add their own sections and fields.
		 *
		 * @since 0.1.0
		 *
		 * @param MVweb_Customizer_Kit $kit Kit instance.
		 */
		do_action( 'mvweb_core_customizer_register', $kit );
	}
}
add_action( 'mvweb_cz_register', 'mvweb_core_customizer_register' );

if ( ! function_exists( 'mvweb_core_zone_fields' ) ) {
	/**
	 * A sortable control per zone.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_zone_fields() {
		$sections = array(
			'header-topbar'          => 'mvweb_cz_header_blocks',
			'header-main'            => 'mvweb_cz_header_blocks',
			'header-actions'         => 'mvweb_cz_header_blocks',
			'header-drawer-contacts' => 'mvweb_cz_header_drawer',
			'header-drawer-nav'      => 'mvweb_cz_header_drawer',
			'footer-main'            => 'mvweb_cz_footer_blocks',
			'footer-bottom'          => 'mvweb_cz_footer_blocks',
		);

		/**
		 * Filters the Customizer sections the zones are set in.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $sections Zone slug => section id.
		 */
		$sections = (array) apply_filters( 'mvweb_core_zone_sections', $sections );

		$priorities = array(
			'footer-main'   => 2,
			'footer-bottom' => 31,
		);

		/**
		 * Filters the one-line hints under the zones in the Customizer.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $hints Zone slug => hint.
		 */
		$hints = (array) apply_filters( 'mvweb_core_zone_hints', array() );

		$fields = array();
		$told   = array();

		foreach ( mvweb_core_zones() as $zone => $label ) {
			if ( ! isset( $sections[ $zone ] ) ) {
				continue;
			}

			$field = array(
				'type'        => 'sortable',
				'settings'    => mvweb_core_zone_setting( $zone ),
				'section'     => $sections[ $zone ],
				'label'       => isset( $priorities[ $zone ] ) ? '' : $label,
				'description' => trim( ( isset( $hints[ $zone ] ) ? $hints[ $zone ] . ' ' : '' ) . ( isset( $told[ $sections[ $zone ] ] ) ? '' : __( 'Drag to reorder. Untick to hide.', 'mvweb-core' ) ) ),
				'choices'     => mvweb_core_zone_elements( $zone ),
				'default'     => wp_json_encode( mvweb_core_zone_default_order( $zone ) ),
			);

			if ( isset( $priorities[ $zone ] ) ) {
				$field['priority'] = $priorities[ $zone ];
			}

			$fields[]                   = $field;
			$told[ $sections[ $zone ] ] = true;
		}

		$fields[] = array(
			'type'        => 'text',
			'settings'    => 'mvweb_notice_text',
			'section'     => 'mvweb_cz_header_blocks',
			'label'       => __( 'Announcement above the header', 'mvweb-core' ),
			'description' => __( 'One line across the top of every page: an offer, new opening hours. A visitor can close it; a new text shows again. Empty hides the line.', 'mvweb-core' ),
		);

		$fields[] = array(
			'type'     => 'url',
			'settings' => 'mvweb_notice_url',
			'section'  => 'mvweb_cz_header_blocks',
			'label'    => __( 'Where the announcement leads', 'mvweb-core' ),
		);

		$fields[] = array(
			'type'        => 'multicheck',
			'settings'    => 'mvweb_header_messengers',
			'section'     => 'mvweb_cz_header_blocks',
			'label'       => __( 'Messengers in the header', 'mvweb-core' ),
			'description' => __( 'The buttons beside the phone and in the mobile menu open a chat with you. A messenger without a link is not shown.', 'mvweb-core' ) . ' ' . mvweb_cz_goto( 'mvweb_cz_profile_contacts', __( 'Links', 'mvweb-core' ) ),
			'default'     => wp_json_encode( mvweb_core_header_messengers_default() ),
			'choices'     => mvweb_cz_chats(),
		);

		$fields[] = array(
			'type'        => 'radio',
			'settings'    => 'mvweb_search_engine',
			'section'     => 'mvweb_cz_modules_main',
			'label'       => __( 'Site search', 'mvweb-core' ),
			'description' => mvweb_core_smart_search_active()
				? __( 'What answers the magnifier in the header and the results page.', 'mvweb-core' )
				: __( 'What answers the magnifier in the header and the results page. MVweb Smart Search is not active, so the WordPress search is used.', 'mvweb-core' ),
			'default'     => 'native',
			'choices'     => array(
				'native' => __( 'WordPress search', 'mvweb-core' ),
				'smart'  => __( 'MVweb Smart Search plugin', 'mvweb-core' ),
			),
		);

		return $fields;
	}
}

if ( ! function_exists( 'mvweb_core_header_tree' ) ) {
	/**
	 * A section of its own for the mobile menu.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_header_tree( $tree ) {
		if ( isset( $tree['mvweb_cz_header']['sections'] ) ) {
			$tree['mvweb_cz_header']['sections']['mvweb_cz_header_drawer'] = __( 'Mobile menu', 'mvweb-core' );
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_header_tree' );

if ( ! function_exists( 'mvweb_core_logo_fields' ) ) {
	/**
	 * The logo layout, its text, its colours and its height.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_logo_fields() {
		$mark_only = array(
			array(
				'setting'  => 'mvweb_logo_layout',
				'operator' => '==',
				'value'    => 'mark',
			),
		);

		$colors = array(
			'mvweb_logo_name_color'         => array( __( 'Name colour, light scheme', 'mvweb-core' ), '--mvweb-t-logo-name-light', 30 ),
			'mvweb_logo_name_color_dark'    => array( __( 'Name colour, dark backgrounds', 'mvweb-core' ), '--mvweb-t-logo-name-dark', 31 ),
			'mvweb_logo_tagline_color'      => array( __( 'Slogan colour, light scheme', 'mvweb-core' ), '--mvweb-t-logo-tagline-light', 32 ),
			'mvweb_logo_tagline_color_dark' => array( __( 'Slogan colour, dark backgrounds', 'mvweb-core' ), '--mvweb-t-logo-tagline-dark', 33 ),
		);

		$fields = array(
			array(
				'type'     => 'radio',
				'settings' => 'mvweb_logo_layout',
				'section'  => 'mvweb_cz_header_brand',
				'label'    => __( 'Logo layout', 'mvweb-core' ),
				'default'  => 'image',
				'priority' => 5,
				'choices'  => array(
					'image' => __( 'Whole picture', 'mvweb-core' ),
					'mark'  => __( 'Sign and name', 'mvweb-core' ),
				),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_logo_name',
				'section'     => 'mvweb_cz_header_brand',
				'label'       => __( 'Name next to the sign', 'mvweb-core' ),
				'description' => __( 'Empty takes the site title.', 'mvweb-core' ),
				'priority'    => 12,
				'required'    => $mark_only,
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_logo_tagline',
				'section'     => 'mvweb_cz_header_brand',
				'label'       => __( 'Slogan under the name', 'mvweb-core' ),
				'description' => __( 'Optional. A city or a short line; empty hides it.', 'mvweb-core' ),
				'priority'    => 13,
				'required'    => $mark_only,
			),
			array(
				'type'         => 'range',
				'settings'     => 'mvweb_logo_height',
				'section'      => 'mvweb_cz_header_brand',
				'label'        => __( 'Logo height, px', 'mvweb-core' ),
				'description'  => __( 'In the header, the mobile menu and the footer. The buttons switch between computers and phones: the phone height works on screens up to 600 px.', 'mvweb-core' ),
				'default'      => 40,
				'priority'     => 20,
				'device'       => 'desktop',
				'device_group' => 'mvweb_logo_height',
				'input_attrs'  => array(
					'min'  => 24,
					'max'  => 96,
					'step' => 1,
				),
				'output'       => array(
					array(
						'element'  => ':root',
						'property' => '--mvweb-t-logo-h',
					),
				),
			),
			array(
				'type'         => 'range',
				'settings'     => 'mvweb_logo_height_mobile',
				'section'      => 'mvweb_cz_header_brand',
				'label'        => __( 'Logo height, px', 'mvweb-core' ),
				'description'  => __( 'In the header, the mobile menu and the footer. The buttons switch between computers and phones: the phone height works on screens up to 600 px.', 'mvweb-core' ),
				'default'      => 40,
				'priority'     => 21,
				'device'       => 'mobile',
				'device_group' => 'mvweb_logo_height',
				'input_attrs'  => array(
					'min'  => 24,
					'max'  => 64,
					'step' => 1,
				),
				'output'       => array(
					array(
						'element'  => ':root',
						'property' => '--mvweb-t-logo-h-mobile',
					),
				),
			),
		);

		foreach ( $colors as $setting => $color ) {
			$fields[] = array(
				'type'        => 'color',
				'settings'    => $setting,
				'section'     => 'mvweb_cz_header_brand',
				'label'       => $color[0],
				'description' => __( 'Empty keeps the header colour.', 'mvweb-core' ),
				'default'     => '',
				'priority'    => $color[2],
				'required'    => $mark_only,
				'output'      => array(
					array(
						'element'  => ':root',
						'property' => $color[1],
					),
				),
			);
		}

		return $fields;
	}
}

if ( ! function_exists( 'mvweb_core_customize_logo' ) ) {
	/**
	 * Put both logos in the header section.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer manager.
	 *
	 * @return void
	 */
	function mvweb_core_customize_logo( $wp_customize ) {
		$setting = $wp_customize->get_setting( 'custom_logo' );
		$control = $wp_customize->get_control( 'custom_logo' );

		if ( $setting ) {
			$setting->transport = 'refresh';
			$wp_customize->selective_refresh->remove_partial( 'custom_logo' );
		}

		if ( $control ) {
			$control->section     = 'mvweb_cz_header_brand';
			$control->priority    = 10;
			$control->label       = __( 'Logo', 'mvweb-core' );
			$control->description = __( 'For the light scheme: the whole logo, or the square sign in the “Sign and name” layout. Upload it two or three times larger than it is shown, so it stays sharp on high-density screens.', 'mvweb-core' );
		}

		$wp_customize->add_setting(
			'mvweb_logo_dark',
			array(
				'default'           => 0,
				'sanitize_callback' => 'mvweb_core_sanitize_image_id',
			)
		);

		$wp_customize->add_control(
			new WP_Customize_Media_Control(
				$wp_customize,
				'mvweb_logo_dark',
				array(
					'label'       => __( 'Logo for dark backgrounds', 'mvweb-core' ),
					'description' => __( 'Shown in the dark scheme, in the footer and in a header that lies over a photo. Without it the main logo is shown there as it is.', 'mvweb-core' ),
					'section'     => 'mvweb_cz_header_brand',
					'mime_type'   => 'image',
					'priority'    => 11,
				)
			)
		);
	}
}
add_action( 'customize_register', 'mvweb_core_customize_logo', 20 );

if ( ! function_exists( 'mvweb_core_sanitize_image_id' ) ) {
	/**
	 * Keep an attachment id only when it points at an image.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return int Attachment id, or 0.
	 */
	function mvweb_core_sanitize_image_id( $value ) {
		$id = absint( $value );

		return ( $id && wp_attachment_is_image( $id ) ) ? $id : 0;
	}
}

if ( ! function_exists( 'mvweb_core_design_fields' ) ) {
	/**
	 * The palette preset and the accents that override it.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_design_fields() {
		$fields = array(
			array(
				'type'        => 'color_palette',
				'settings'    => 'mvweb_palette',
				'section'     => 'mvweb_cz_design_preset',
				'label'       => __( 'Palette', 'mvweb-core' ),
				'description' => __( 'Sets the accent colours. Backgrounds and text stay as they are.', 'mvweb-core' ),
				'default'     => mvweb_core_default_palette(),
				'choices'     => mvweb_core_palette_choices(),
			),
			array(
				'type'        => 'radio',
				'settings'    => 'mvweb_scheme_mode',
				'section'     => 'mvweb_cz_design_colors',
				'label'       => __( 'Colour scheme', 'mvweb-core' ),
				'description' => __( 'With one scheme the switch disappears from the header and the mobile menu.', 'mvweb-core' ),
				'default'     => 'both',
				'priority'    => 1,
				'choices'     => array(
					'light' => __( 'Light only', 'mvweb-core' ),
					'dark'  => __( 'Dark only', 'mvweb-core' ),
					'both'  => __( 'Visitor chooses', 'mvweb-core' ),
				),
			),
			array(
				'type'        => 'radio',
				'settings'    => 'mvweb_scheme_default',
				'section'     => 'mvweb_cz_design_colors',
				'label'       => __( 'Scheme on the first visit', 'mvweb-core' ),
				'description' => __( 'Until the visitor switches; the choice is then remembered in the browser.', 'mvweb-core' ),
				'default'     => 'light',
				'priority'    => 2,
				'choices'     => array(
					'light' => __( 'Light', 'mvweb-core' ),
					'dark'  => __( 'Dark', 'mvweb-core' ),
				),
				'required'    => array(
					array(
						'setting'  => 'mvweb_scheme_mode',
						'operator' => '==',
						'value'    => 'both',
					),
				),
			),
		);

		if ( ! mvweb_core_palette_choices() ) {
			array_shift( $fields );
		}

		return $fields;
	}
}

if ( ! function_exists( 'mvweb_core_conversion_fields' ) ) {
	/**
	 * The action button shown in the header and the drawer.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_conversion_fields() {
		return array(
			array(
				'type'     => 'text',
				'settings' => 'mvweb_cta_text',
				'section'  => 'mvweb_cz_conversion_cta',
				'label'    => __( 'Button label', 'mvweb-core' ),
				'default'  => __( 'Request a quote', 'mvweb-core' ),
			),
			array(
				'type'        => 'url',
				'settings'    => 'mvweb_cta_url',
				'section'     => 'mvweb_cz_conversion_cta',
				'label'       => __( 'Button link', 'mvweb-core' ),
				'description' => __( 'Leave empty to hide the button. #request opens the form below in a window.', 'mvweb-core' ),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_popup_form',
				'section'     => 'mvweb_cz_conversion_cta',
				'label'       => __( 'Form in a window', 'mvweb-core' ),
				'description' => __( 'Form shortcode, for example [contact-form-7 id="12"]. Any link to #request opens it: the header button, a button of a section, a menu item. A hidden field named product receives the name of the page.', 'mvweb-core' ),
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_popup_title',
				'section'  => 'mvweb_cz_conversion_cta',
				'label'    => __( 'Heading of the window', 'mvweb-core' ),
				'default'  => __( 'Leave a request', 'mvweb-core' ),
			),
			array(
				'type'     => 'textarea',
				'settings' => 'mvweb_popup_text',
				'section'  => 'mvweb_cz_conversion_cta',
				'label'    => __( 'Text under the heading', 'mvweb-core' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_single_fields' ) ) {
	/**
	 * What an entry of the blog carries below its text.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_single_fields() {
		return array(
			array(
				'type'        => 'checkbox',
				'settings'    => 'mvweb_author_box',
				'section'     => 'mvweb_cz_inner_single',
				'label'       => __( 'Show the author block', 'mvweb-core' ),
				'description' => __( 'Under the text of an entry: picture, name and the description from the profile.', 'mvweb-core' ),
				'default'     => false,
			),
			array(
				'type'        => 'checkbox',
				'settings'    => 'mvweb_toc',
				'section'     => 'mvweb_cz_inner_single',
				'label'       => __( 'Show the table of contents', 'mvweb-core' ),
				'description' => __( 'Above the text of an entry with three or more subheadings: a list of its h2 and h3 that jumps to them.', 'mvweb-core' ),
				'default'     => false,
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_share_fields' ) ) {
	/**
	 * The share buttons: which networks and on what pages.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_share_fields() {
		return array(
			array(
				'type'        => 'multicheck',
				'settings'    => 'mvweb_share_networks',
				'section'     => 'mvweb_cz_conversion_share',
				'label'       => __( 'Networks', 'mvweb-core' ),
				'description' => __( 'Nothing ticked — no buttons at all.', 'mvweb-core' ),
				'default'     => wp_json_encode( array() ),
				'choices'     => wp_list_pluck( mvweb_core_share_networks(), 'label' ),
			),
			array(
				'type'     => 'multicheck',
				'settings' => 'mvweb_share_places',
				'section'  => 'mvweb_cz_conversion_share',
				'label'    => __( 'Where to show them', 'mvweb-core' ),
				'default'  => wp_json_encode( array() ),
				'choices'  => mvweb_core_share_places(),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_footer_fields' ) ) {
	/**
	 * Footer-only fields: the tagline, the column headings, the copyright line and the studio badge.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_footer_fields() {
		$section = 'mvweb_cz_footer_blocks';

		return array(
			array(
				'type'        => 'heading',
				'section'     => $section,
				'label'       => __( 'Columns', 'mvweb-core' ),
				'priority'    => 1,
				'collapsible' => true,
			),
			array(
				'type'        => 'textarea',
				'settings'    => 'mvweb_footer_tagline',
				'section'     => $section,
				'label'       => __( 'Tagline under the logo', 'mvweb-core' ),
				'description' => __( 'Empty falls back to the site tagline.', 'mvweb-core' ),
				'priority'    => 3,
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_footer_menu_title',
				'section'     => $section,
				'label'       => __( 'Menu column heading', 'mvweb-core' ),
				'description' => __( 'Empty hides the heading.', 'mvweb-core' ) . ' ' . mvweb_cz_goto( 'menu_locations', __( 'Menus of the columns', 'mvweb-core' ) ),
				'default'     => __( 'Sections', 'mvweb-core' ),
				'priority'    => 4,
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_footer_menu_2_title',
				'section'  => $section,
				'label'    => __( 'Second menu column heading', 'mvweb-core' ),
				'default'  => __( 'Company', 'mvweb-core' ),
				'priority' => 5,
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_footer_contacts_title',
				'section'  => $section,
				'label'    => __( 'Contacts column heading', 'mvweb-core' ),
				'default'  => __( 'Contacts', 'mvweb-core' ),
				'priority' => 6,
			),
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_footer_contacts_cta',
				'section'     => $section,
				'label'       => __( 'Request button in the contacts column', 'mvweb-core' ),
				'description' => mvweb_cz_goto( 'mvweb_cz_conversion_cta', __( 'Wording and address', 'mvweb-core' ) ),
				'default'     => true,
				'priority'    => 7,
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_footer_socials_title',
				'section'     => $section,
				'label'       => __( 'Heading above the social networks', 'mvweb-core' ),
				'description' => __( 'Above the social networks under the logo: the networks of the site profile that have a link. Empty hides the heading.', 'mvweb-core' ) . ' ' . mvweb_cz_goto( 'mvweb_cz_profile_socials', __( 'Open the links', 'mvweb-core' ) ),
				'default'     => __( 'We are on social networks', 'mvweb-core' ),
				'priority'    => 8,
			),
			array(
				'type'        => 'heading',
				'section'     => $section,
				'label'       => __( 'Map above the columns', 'mvweb-core' ),
				'priority'    => 20,
				'collapsible' => true,
				'collapsed'   => true,
				'toggle'      => 'mvweb_footer_map_enable',
			),
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_footer_map_enable',
				'section'     => $section,
				'label'       => __( 'Show the map', 'mvweb-core' ),
				'description' => __( 'Off by default: the map of the company stands on the contacts page. On, it shows on every page. The map itself — its code or a picture — is set in the company details.', 'mvweb-core' ) . ' ' . mvweb_cz_goto( 'mvweb_cz_profile_legal', __( 'Open the map', 'mvweb-core' ) ),
				'default'     => false,
				'priority'    => 21,
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_footer_map_title',
				'section'  => $section,
				'label'    => __( 'Map heading', 'mvweb-core' ),
				'priority' => 22,
				'required' => array(
					array(
						'setting'  => 'mvweb_footer_map_enable',
						'operator' => '==',
						'value'    => true,
					),
				),
			),
			array(
				'type'        => 'heading',
				'section'     => $section,
				'label'       => __( 'Bottom row', 'mvweb-core' ),
				'priority'    => 30,
				'collapsible' => true,
				'collapsed'   => true,
				'summary'     => array( mvweb_core_zone_setting( 'footer-bottom' ) ),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_footer_copyright',
				'section'     => $section,
				'label'       => __( 'Copyright line', 'mvweb-core' ),
				'description' => __( '{year} becomes the current year. Empty prints the standard line with the year and the site name.', 'mvweb-core' ),
				'priority'    => 32,
			),
		);
	}
}
