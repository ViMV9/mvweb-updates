<?php
/**
 * Customizer bootstrap.
 *
 * Loads the MVweb Customizer Kit and declares this theme's options on top of
 * the studio baseline. The Kit owns the schema, the controls, the CSS output
 * layer and the live preview; this folder only says what the theme offers.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once __DIR__ . '/home.php';
require_once __DIR__ . '/catalog.php';
require_once __DIR__ . '/services.php';
require_once __DIR__ . '/panels.php';

if ( ! function_exists( 'mvweb_core_kit_strings' ) ) {
	/**
	 * Put the Kit interface strings through the theme's translation.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $strings Kit defaults.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_kit_strings( $strings ) {
		return array_merge(
			(array) $strings,
			array(
				'add'           => __( 'Add', 'mvweb-core' ),
				'remove'        => __( 'Remove', 'mvweb-core' ),
				'row'           => __( 'Item', 'mvweb-core' ),
				'selectImage'   => __( 'Choose image', 'mvweb-core' ),
				'changeImage'   => __( 'Replace', 'mvweb-core' ),
				'removeImage'   => __( 'Remove', 'mvweb-core' ),
				'reset'         => __( 'Reset', 'mvweb-core' ),
				'confirm'       => __( 'Remove this item?', 'mvweb-core' ),
				'unit'          => __( 'Unit', 'mvweb-core' ),
				'fontFamily'    => __( 'Font', 'mvweb-core' ),
				'fontSize'      => __( 'Size', 'mvweb-core' ),
				'fontWeight'    => __( 'Weight', 'mvweb-core' ),
				'lineHeight'    => __( 'Line height', 'mvweb-core' ),
				'letterSpacing' => __( 'Letter spacing', 'mvweb-core' ),
				'textTransform' => __( 'Case', 'mvweb-core' ),
				'inherit'       => __( 'Inherit', 'mvweb-core' ),
				'caseNone'      => __( 'As is', 'mvweb-core' ),
				'caseUpper'     => __( 'UPPERCASE', 'mvweb-core' ),
				'caseLower'     => __( 'lowercase', 'mvweb-core' ),
				'caseTitle'     => __( 'Title Case', 'mvweb-core' ),
				'dragToReorder' => __( 'Drag to reorder', 'mvweb-core' ),
				'search'        => __( 'Find a setting…', 'mvweb-core' ),
				'nothingFound'  => __( 'Nothing found', 'mvweb-core' ),
				'notSet'        => __( 'not set', 'mvweb-core' ),
				'hint'          => __( 'Hint', 'mvweb-core' ),
				'desktop'       => __( 'Computer', 'mvweb-core' ),
				'mobile'        => __( 'Phone and tablet', 'mvweb-core' ),
				'otherGroup'    => __( 'WordPress', 'mvweb-core' ),
				'edit'          => __( 'Set up this block', 'mvweb-core' ),
			)
		);
	}
}
add_filter( 'mvweb_cz_l10n', 'mvweb_core_kit_strings' );

if ( ! function_exists( 'mvweb_core_profile_fields' ) ) {
	/**
	 * Put the profile fields of the Kit through the theme's translation.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $fields Kit profile fields.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_profile_fields( $fields ) {
		$texts = array(
			'mvweb_cz_phone'             => array( __( 'Phone', 'mvweb-core' ), __( 'With the country code, for example +44 20 7946 0000.', 'mvweb-core' ) ),
			'mvweb_cz_phone_extra'       => array( __( 'Second phone', 'mvweb-core' ) ),
			'mvweb_cz_email'             => array( __( 'E-mail', 'mvweb-core' ) ),
			'mvweb_cz_chats_heading'     => array( __( 'Messengers to reach you', 'mvweb-core' ), __( 'A link to a chat with the company: t.me/name, wa.me/number. The buttons beside the phone, in the header and on the contacts page open it. Channels and groups go to the social networks.', 'mvweb-core' ) ),
			'mvweb_cz_city'              => array( __( 'City', 'mvweb-core' ), __( 'Printed before the address. Where the city goes after the street, leave it empty and write the whole address below.', 'mvweb-core' ) ),
			'mvweb_cz_address'           => array( __( 'Address', 'mvweb-core' ), __( 'Street, building, office — or the whole address in the order of your country.', 'mvweb-core' ) ),
			'mvweb_cz_schedule_weekdays' => array( __( 'Opening hours', 'mvweb-core' ), __( 'For example: Mon-Fri 9:00-18:00', 'mvweb-core' ) ),
			'mvweb_cz_schedule_weekend'  => array( __( 'Second line of the hours', 'mvweb-core' ), __( 'For example: Sat-Sun closed', 'mvweb-core' ) ),
			'mvweb_cz_schedule_round'    => array( __( 'Open around the clock', 'mvweb-core' ) ),
			'mvweb_cz_map_mode'          => array( __( 'Map', 'mvweb-core' ), __( 'Shown above the footer columns.', 'mvweb-core' ) ),
			'mvweb_cz_map'               => array( __( 'Map code', 'mvweb-core' ), '', __( 'Paste the embed code of a map from Google Maps, OpenStreetMap or Yandex Maps (an iframe or the script of the map constructor), or the address of the embedded map. Only the address is kept from the code.', 'mvweb-core' ) ),
			'mvweb_cz_map_image'         => array( __( 'Picture of the map', 'mvweb-core' ), __( 'A still picture loads faster than an embedded map.', 'mvweb-core' ), __( 'Any proportions: the picture is shown whole and is never stretched past its own size. A wide one fills the block — take it at least 1840 px wide to stay sharp on high-density screens.', 'mvweb-core' ) ),
			'mvweb_cz_legal_name'        => array( __( 'Organisation name', 'mvweb-core' ), __( 'As in the registration documents.', 'mvweb-core' ) ),
			'mvweb_cz_requisites'        => array( __( 'Company details', 'mvweb-core' ), __( 'Tax and registration number, licences, certificates.', 'mvweb-core' ), __( 'The caption is the word used in your country: VAT, EIN, NIP. An empty caption prints the name of the kind.', 'mvweb-core' ) ),
		);

		$sub = array(
			'type'  => __( 'Kind', 'mvweb-core' ),
			'label' => __( 'Caption on the site', 'mvweb-core' ),
			'value' => __( 'Number or text', 'mvweb-core' ),
		);

		foreach ( mvweb_cz_chats() as $chat => $label ) {
			$texts[ 'mvweb_cz_social_' . $chat ] = array( $label, __( 'A channel or a group. A chat with the company goes to the contacts.', 'mvweb-core' ) );
		}

		foreach ( $fields as $index => $field ) {
			$id = isset( $field['settings'] ) ? $field['settings'] : '';

			if ( 'mvweb_cz_map' === $id ) {
				$fields[ $index ]['sanitize_callback'] = 'mvweb_core_sanitize_map';
			}

			if ( 'mvweb_cz_map_mode' === $id ) {
				$fields[ $index ]['choices'] = array(
					'code'  => __( 'Map code', 'mvweb-core' ),
					'image' => __( 'Picture', 'mvweb-core' ),
				);
			}

			if ( isset( $texts[ $id ] ) ) {
				$fields[ $index ]['label'] = $texts[ $id ][0];

				if ( isset( $texts[ $id ][1] ) && '' !== $texts[ $id ][1] ) {
					$fields[ $index ]['description'] = $texts[ $id ][1];
				}

				if ( isset( $texts[ $id ][2] ) ) {
					$fields[ $index ]['tooltip'] = $texts[ $id ][2];
				}
			}

			if ( 'mvweb_cz_requisites' === $id ) {
				foreach ( $sub as $key => $label ) {
					$fields[ $index ]['fields'][ $key ]['label'] = $label;
				}
			}
		}

		return $fields;
	}
}
add_filter( 'mvweb_cz_baseline_fields', 'mvweb_core_profile_fields' );

if ( ! function_exists( 'mvweb_core_socials' ) ) {
	/**
	 * Names of the networks that are not written in Latin letters.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $socials Network id => label.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_socials( $socials ) {
		$names = array(
			'odnoklassniki' => __( 'Odnoklassniki', 'mvweb-core' ),
			'dzen'          => __( 'Dzen', 'mvweb-core' ),
		);

		return array_merge( (array) $socials, array_intersect_key( $names, (array) $socials ) );
	}
}
add_filter( 'mvweb_cz_socials', 'mvweb_core_socials' );

if ( ! function_exists( 'mvweb_core_requisite_types' ) ) {
	/**
	 * Kinds of company details in the theme's translation.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_requisite_types() {
		return array(
			'tax_id'       => __( 'Tax number', 'mvweb-core' ),
			'registration' => __( 'Registration number', 'mvweb-core' ),
			'license'      => __( 'Licence', 'mvweb-core' ),
			'certificate'  => __( 'Certificate', 'mvweb-core' ),
			'membership'   => __( 'Membership (association, SRO)', 'mvweb-core' ),
			'bank'         => __( 'Bank details', 'mvweb-core' ),
			'other'        => __( 'Other', 'mvweb-core' ),
		);
	}
}
add_filter( 'mvweb_cz_requisite_types', 'mvweb_core_requisite_types' );

if ( ! function_exists( 'mvweb_core_customizer_layout' ) ) {
	/**
	 * Group titles over the panels, and no sections the theme leaves empty.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_customizer_layout( $tree ) {
		$groups = array(
			'mvweb_cz_design'     => __( 'Base of the site', 'mvweb-core' ),
			'mvweb_cz_profile'    => __( 'Base of the site', 'mvweb-core' ),
			'mvweb_cz_header'     => __( 'Frame of every page', 'mvweb-core' ),
			'mvweb_cz_footer'     => __( 'Frame of every page', 'mvweb-core' ),
			'mvweb_cz_home'       => __( 'Pages', 'mvweb-core' ),
			'mvweb_cz_inner'      => __( 'Pages', 'mvweb-core' ),
			'mvweb_cz_catalog'    => __( 'Pages', 'mvweb-core' ),
			'mvweb_cz_services'   => __( 'Pages', 'mvweb-core' ),
			'mvweb_cz_conversion' => __( 'Sales', 'mvweb-core' ),
		);

		$empty = array(
			'mvweb_cz_design' => array( 'mvweb_cz_design_typography', 'mvweb_cz_design_layout' ),
			'mvweb_cz_header' => array( 'mvweb_cz_header_topbar', 'mvweb_cz_header_action' ),
			'mvweb_cz_inner'  => array( 'mvweb_cz_inner_page', 'mvweb_cz_inner_archive', 'mvweb_cz_inner_sidebar' ),
		);

		$titles = array(
			'mvweb_cz_design'     => __( 'MVweb: Design', 'mvweb-core' ),
			'mvweb_cz_profile'    => __( 'MVweb: Contacts and company details', 'mvweb-core' ),
			'mvweb_cz_header'     => __( 'MVweb: Header', 'mvweb-core' ),
			'mvweb_cz_footer'     => __( 'MVweb: Footer', 'mvweb-core' ),
			'mvweb_cz_home'       => __( 'MVweb: Homepage', 'mvweb-core' ),
			'mvweb_cz_inner'      => __( 'MVweb: Inner pages', 'mvweb-core' ),
			'mvweb_cz_catalog'    => __( 'MVweb: Catalogue', 'mvweb-core' ),
			'mvweb_cz_conversion' => __( 'MVweb: Conversion', 'mvweb-core' ),
		);

		$sections = array(
			'mvweb_cz_design_preset'    => __( 'Design preset', 'mvweb-core' ),
			'mvweb_cz_design_colors'    => __( 'Colours', 'mvweb-core' ),
			'mvweb_cz_profile_contacts' => __( 'Contacts', 'mvweb-core' ),
			'mvweb_cz_profile_schedule' => __( 'Opening hours', 'mvweb-core' ),
			'mvweb_cz_profile_socials'  => __( 'Social networks and messengers', 'mvweb-core' ),
			'mvweb_cz_profile_legal'    => __( 'Map and company details', 'mvweb-core' ),
			'mvweb_cz_header_blocks'    => __( 'Header layout', 'mvweb-core' ),
			'mvweb_cz_header_brand'     => __( 'Logo and menu', 'mvweb-core' ),
			'mvweb_cz_footer_blocks'    => __( 'Footer layout', 'mvweb-core' ),
			'mvweb_cz_home_blocks'      => __( 'Blocks of the homepage', 'mvweb-core' ),
			'mvweb_cz_home_hero'        => __( 'First screen', 'mvweb-core' ),
			'mvweb_cz_inner_single'     => __( 'Posts', 'mvweb-core' ),
			'mvweb_cz_catalog_archive'  => __( 'Listing and categories', 'mvweb-core' ),
			'mvweb_cz_catalog_product'  => __( 'Item page', 'mvweb-core' ),
			'mvweb_cz_conversion_cta'   => __( 'Buttons and calls to action', 'mvweb-core' ),
			'mvweb_cz_conversion_share' => __( 'Share buttons', 'mvweb-core' ),
		);

		foreach ( $tree as $panel => $data ) {
			if ( isset( $titles[ $panel ] ) ) {
				$tree[ $panel ]['title'] = $titles[ $panel ];
			}

			foreach ( array_keys( (array) ( $data['sections'] ?? array() ) ) as $section ) {
				if ( isset( $sections[ $section ] ) ) {
					$tree[ $panel ]['sections'][ $section ] = $sections[ $section ];
				}
			}
		}

		foreach ( $groups as $panel => $group ) {
			if ( isset( $tree[ $panel ] ) ) {
				$tree[ $panel ]['group'] = $group;
			}
		}

		foreach ( $empty as $panel => $sections ) {
			foreach ( $sections as $section ) {
				unset( $tree[ $panel ]['sections'][ $section ] );
			}
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_customizer_layout', 99 );

if ( ! function_exists( 'mvweb_core_customizer_refresh_buffer' ) ) {
	/**
	 * Wait for a pause in typing before the preview reloads.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_customizer_refresh_buffer() {
		if ( function_exists( 'mvweb_so_check_option' ) && mvweb_so_check_option( 'customizer_manual_preview' ) ) {
			return;
		}

		$buffer = (int) apply_filters( 'mvweb_core_customizer_refresh_buffer', 3000 );

		wp_add_inline_script(
			'customize-controls',
			'if ( window.wp && wp.customize && wp.customize.Previewer ) { wp.customize.Previewer.prototype.refreshBuffer = ' . $buffer . '; }'
		);
	}
}
add_action( 'customize_controls_enqueue_scripts', 'mvweb_core_customizer_refresh_buffer', 99 );
