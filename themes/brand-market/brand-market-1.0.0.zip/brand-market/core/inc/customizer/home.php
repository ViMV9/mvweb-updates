<?php
/**
 * The homepage in the Customizer.
 *
 * The order of the blocks and the value of every field come from the same
 * registry the builder and the renderer use, so a type is declared once and
 * shows up in all three. The homepage keeps its values in theme_mods rather
 * than in a page's meta: it has no page of its own when the site shows the
 * latest posts, and an owner expects to arrange the front of the site where
 * they arrange the header and the footer.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_home_fields' ) ) {
	/**
	 * The order control and one control per field of every type.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_home_fields() {
		$types = mvweb_core_editable_sections();

		if ( empty( $types ) ) {
			return array();
		}

		$fields = array();

		foreach ( $types as $type => $definition ) {
			if ( empty( $definition['global'] ) ) {
				continue;
			}

			$section = mvweb_core_home_section( $type );
			$group   = '';
			$first   = true;

			foreach ( $definition['fields'] as $id => $field ) {
				if ( '' !== $field['group'] && $field['group'] !== $group ) {
					$fields[] = array(
						'type'        => 'heading',
						'section'     => $section,
						'label'       => $field['group'],
						'collapsible' => true,
						'collapsed'   => ! $first,
					);

					$group = $field['group'];
					$first = false;
				}

				$control = mvweb_core_home_control( $type, $id, $field, $section );

				if ( ! empty( $control ) ) {
					$fields[] = $control;
				}
			}
		}

		return $fields;
	}
}

if ( ! function_exists( 'mvweb_core_home_section' ) ) {
	/**
	 * The Customizer section a block type of the homepage is edited in.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type Section type slug.
	 *
	 * @return string
	 */
	function mvweb_core_home_section( $type ) {
		return 'hero' === $type ? 'mvweb_cz_home_hero' : 'mvweb_cz_home_' . str_replace( '-', '_', $type );
	}
}

if ( ! function_exists( 'mvweb_core_home_tree' ) ) {
	/**
	 * A section of its own for every block type of the homepage.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_home_tree( $tree ) {
		if ( ! isset( $tree['mvweb_cz_home']['sections'] ) ) {
			return $tree;
		}

		unset( $tree['mvweb_cz_home']['sections']['mvweb_cz_home_extra'], $tree['mvweb_cz_home']['sections']['mvweb_cz_home_hero'] );

		$types = mvweb_core_editable_sections();
		$shown = array();

		foreach ( array_keys( $shown + $types ) as $type ) {
			if ( empty( $types[ $type ]['fields'] ) || empty( $types[ $type ]['global'] ) ) {
				continue;
			}

			$global = $types[ $type ]['global'];

			if ( ! empty( $global['panel'] ) && isset( $tree[ $global['panel'] ] ) ) {
				$tree[ $global['panel'] ]['sections'][ mvweb_core_home_section( $type ) ] = $global['title'] ?? $types[ $type ]['label'];
				continue;
			}

			$tree['mvweb_cz_home']['sections'][ mvweb_core_home_section( $type ) ] = $types[ $type ]['label'];
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_home_tree' );

if ( ! function_exists( 'mvweb_core_home_control' ) ) {
	/**
	 * One section field as a Customizer control.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type    Section type slug.
	 * @param string $id      Field id.
	 * @param array  $field   Normalized field definition.
	 * @param string $section Customizer section the control belongs to.
	 *
	 * @return array<string,mixed> Empty when the field has no counterpart.
	 */
	function mvweb_core_home_control( $type, $id, array $field, $section ) {
		$map = array(
			'text'     => 'text',
			'line'     => 'text',
			'textarea' => 'textarea',
			'richtext' => 'editor',
			'code'     => 'textarea',
			'url'      => 'url',
			'email'    => 'text',
			'image'    => 'media',
			'select'   => 'select',
			'toggle'   => 'toggle',
			'number'   => 'number',
			'icon'     => 'select',
			'item'     => 'select',
			'category' => 'select',
			'repeat'   => 'repeater',
			'sortable' => 'sortable',
			'parts'    => 'sortable',
			'color'    => 'color',
		);

		if ( ! isset( $map[ $field['type'] ] ) ) {
			return array();
		}

		$control = array(
			'type'        => $map[ $field['type'] ],
			'settings'    => mvweb_core_section_setting( $type, $id ),
			'section'     => $section,
			'label'       => '' !== $field['label'] ? $field['label'] : $id,
			'description' => $field['description'],
			'default'     => $field['default'],
		);

		if ( '' !== $field['tooltip'] ) {
			$control['tooltip'] = $field['tooltip'];
		}

		if ( '' !== $field['placeholder'] ) {
			$control['input_attrs'] = array( 'placeholder' => $field['placeholder'] );
		}

		if ( isset( $field['goto'][0], $field['goto'][1] ) ) {
			$control['description'] = trim( $control['description'] . ' ' . mvweb_cz_goto( $field['goto'][0], $field['goto'][1] ) );
		}

		if ( in_array( $field['type'], array( 'select', 'sortable', 'parts' ), true ) ) {
			$control['choices'] = $field['choices'];
		}

		if ( in_array( $field['type'], array( 'item', 'category' ), true ) ) {
			$control['choices'] = mvweb_core_field_choices( $field );
		}

		if ( ! empty( $field['show_when'] ) ) {
			$control['required'] = array(
				array(
					'setting'  => mvweb_core_section_setting( $type, $field['show_when']['field'] ),
					'operator' => 'in',
					'value'    => $field['show_when']['in'],
				),
			);
		}

		if ( 'line' === $field['type'] ) {
			$control['sanitize_callback'] = 'mvweb_core_sanitize_line';
		}

		if ( 'code' === $field['type'] ) {
			$control['sanitize_callback'] = 'mvweb_core_sanitize_code';
		}

		if ( 'icon' === $field['type'] ) {
			$control['choices']     = mvweb_core_icon_choices();
			$control['description'] = '';
		}

		if ( 'number' === $field['type'] ) {
			$control['input_attrs'] = array_filter(
				array(
					'min' => $field['min'],
					'max' => $field['max'],
				),
				static function ( $value ) {
					return null !== $value;
				}
			);
		}

		if ( 'parts' === $field['type'] ) {
			$control['default'] = wp_json_encode( $field['default'] );
		}

		if ( 'repeat' === $field['type'] ) {
			$control['default'] = wp_json_encode( array() );
			$control['fields']  = array();

			if ( isset( $field['fields']['title'] ) ) {
				$control['row_label'] = 'title';
			}

			$row_map          = $map;
			$row_map['image'] = 'image';

			foreach ( $field['fields'] as $sub_id => $sub ) {
				$control['fields'][ $sub_id ] = array(
					'type'    => isset( $row_map[ $sub['type'] ] ) ? $row_map[ $sub['type'] ] : 'text',
					'label'   => '' !== $sub['label'] ? $sub['label'] : $sub_id,
					'choices' => mvweb_core_field_choices( $sub ),
				);

				if ( 'line' === $sub['type'] ) {
					$control['fields'][ $sub_id ]['sanitize_callback'] = 'mvweb_core_sanitize_line';
				}

				if ( 'item' === $sub['type'] ) {
					$control['fields'][ $sub_id ]['sanitize_callback'] = 'absint';
				}
			}
		}

		return $control;
	}
}

if ( ! function_exists( 'mvweb_core_home_icon_fields' ) ) {
	/**
	 * Where the homepage picks an icon: settings and repeater subfields.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array{setting:string,key:string}> An empty key means
	 *                                                     the setting itself.
	 */
	function mvweb_core_home_icon_fields() {
		$found = array();

		foreach ( mvweb_core_editable_sections() as $type => $definition ) {
			foreach ( $definition['fields'] as $id => $field ) {
				$setting = mvweb_core_section_setting( $type, $id );

				if ( 'icon' === $field['type'] ) {
					$found[] = array(
						'setting' => $setting,
						'key'     => '',
					);
				}

				if ( 'repeat' === $field['type'] ) {
					foreach ( $field['fields'] as $sub_id => $sub ) {
						if ( 'icon' === $sub['type'] ) {
							$found[] = array(
								'setting' => $setting,
								'key'     => (string) $sub_id,
							);
						}
					}
				}
			}
		}

		return $found;
	}
}

if ( ! function_exists( 'mvweb_core_home_icon_picker' ) ) {
	/**
	 * Show the picked icon next to its list in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_home_icon_picker() {
		$fields = mvweb_core_home_icon_fields();

		if ( empty( $fields ) ) {
			return;
		}

		$script = mvweb_core_asset_path( '/admin/js/customizer-icons.js' );
		$style  = mvweb_core_asset_path( '/admin/css/icon-picker.css' );

		wp_enqueue_style( 'mvweb-core-icon-picker', MVWEB_CORE_URI . $style, array(), mvweb_core_asset_version( $style ) );
		wp_enqueue_script( 'mvweb-core-customizer-icons', MVWEB_CORE_URI . $script, array( 'customize-controls' ), mvweb_core_asset_version( $script ), true );
		wp_add_inline_script( 'mvweb-core-customizer-icons', 'window.mvwebCoreIconFields = ' . wp_json_encode( $fields ) . ';', 'before' );
	}
}
add_action( 'customize_controls_enqueue_scripts', 'mvweb_core_home_icon_picker' );

if ( ! function_exists( 'mvweb_core_global_pages' ) ) {
	/**
	 * Where the preview goes when the section of a global type opens.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Customizer section id => page address.
	 */
	function mvweb_core_global_pages() {
		$pages = array();

		foreach ( mvweb_core_sections() as $type => $definition ) {
			if ( empty( $definition['global'] ) ) {
				continue;
			}

			$found = get_posts(
				array(
					'post_type'      => mvweb_core_section_post_types(),
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'orderby'        => 'ID',
					'order'          => 'ASC',
					'fields'         => 'ids',
					'meta_key'       => '_mvweb_sections', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Runs once when the Customizer opens.
					'meta_value'     => '"' . $type . '"', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Same.
					'meta_compare'   => 'LIKE',
				)
			);

			if ( ! empty( $found ) ) {
				$pages[ mvweb_core_home_section( $type ) ] = (string) get_permalink( $found[0] );
			}
		}

		return $pages;
	}
}

if ( ! function_exists( 'mvweb_core_home_marks' ) ) {
	/**
	 * Mark the homepage sections of blocks that are not on the page.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_home_marks() {
		$script = mvweb_core_asset_path( '/admin/js/customizer-home.js' );
		$style  = mvweb_core_asset_path( '/admin/css/customizer.css' );

		wp_enqueue_style( 'mvweb-core-customizer', MVWEB_CORE_URI . $style, array(), mvweb_core_asset_version( $style ) );
		wp_enqueue_script( 'mvweb-core-customizer-home', MVWEB_CORE_URI . $script, array( 'jquery', 'customize-controls' ), mvweb_core_asset_version( $script ), true );
		wp_localize_script(
			'mvweb-core-customizer-home',
			'mvwebCoreHome',
			array(
				'types'  => array(),
				'pages'  => mvweb_core_global_pages(),
				'hidden' => __( 'hidden', 'mvweb-core' ),
				/* translators: 1: blocks on the homepage, 2: blocks there are. */
				'count'  => __( '%1$s of %2$s', 'mvweb-core' ),
			)
		);
	}
}
add_action( 'customize_controls_enqueue_scripts', 'mvweb_core_home_marks' );
add_action( 'customize_controls_print_footer_scripts', 'mvweb_core_print_icon_picker_sprites' );
