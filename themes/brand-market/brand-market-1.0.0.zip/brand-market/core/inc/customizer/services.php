<?php
/**
 * Services options.
 *
 * The bases of the addresses, what the section is called and the form printed
 * beside a service. The phone under the buttons is not a field here — it lives
 * once in the site profile, and a second copy is a copy that goes stale.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_services_tree' ) ) {
	/**
	 * Offer the services panel.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_services_tree( $tree ) {
		$tree['mvweb_cz_services'] = array(
			'title'    => __( 'MVweb: Services', 'mvweb-core' ),
			'priority' => 37,
			'sections' => array(
				'mvweb_cz_services_setup' => __( 'Post type and addresses', 'mvweb-core' ),
				'mvweb_cz_services_list'  => __( 'Services listing', 'mvweb-core' ),
				'mvweb_cz_services_page'  => __( 'Service page', 'mvweb-core' ),
				'mvweb_cz_services_works' => __( 'Portfolio', 'mvweb-core' ),
			),
		);

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_services_tree' );

if ( ! function_exists( 'mvweb_core_services_fields' ) ) {
	/**
	 * Fields of the services sections.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_services_fields() {
		$defaults = mvweb_core_service_defaults();

		return array(
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_service_label',
				'section'     => 'mvweb_cz_services_setup',
				'label'       => __( 'What the section is called', 'mvweb-core' ),
				'description' => __( 'In the admin menu and above the listing. For example: Services, Works, What we do.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_service_label'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_service_slug',
				'section'     => 'mvweb_cz_services_setup',
				'label'       => __( 'Base of the addresses', 'mvweb-core' ),
				'description' => __( 'The listing lives at /base/, a section at /base/section/ and a service at /base/section/name/. Changing this on a live site breaks every address it already has.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_service_slug'],
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_services_per_page',
				'section'     => 'mvweb_cz_services_setup',
				'label'       => __( 'Services per page', 'mvweb-core' ),
				'description' => __( 'Works when the services page shows all services as cards. The other views print the whole list.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_services_per_page'],
				'input_attrs' => array(
					'min'  => 1,
					'max'  => 96,
					'step' => 1,
				),
			),
			array(
				'type'        => 'select',
				'settings'    => 'mvweb_service_list_mode',
				'section'     => 'mvweb_cz_services_list',
				'label'       => __( 'What the services page shows', 'mvweb-core' ),
				'description' => __( 'The same goes for a section page. A section without subsections always shows its services as cards.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_service_list_mode'],
				'choices'     => array(
					'flat'  => __( 'All services as cards, page by page', 'mvweb-core' ),
					'level' => __( 'Only the next level: sections and the services beside them', 'mvweb-core' ),
					'tree'  => __( 'All levels as a tree: sections with their services listed', 'mvweb-core' ),
				),
			),
			array(
				'type'     => 'toggle',
				'settings' => 'mvweb_service_tree_desc',
				'section'  => 'mvweb_cz_services_list',
				'label'    => __( 'Description of the section in the tree', 'mvweb-core' ),
				'default'  => $defaults['mvweb_service_tree_desc'],
				'required' => array(
					array(
						'setting'  => 'mvweb_service_list_mode',
						'operator' => '==',
						'value'    => 'tree',
					),
				),
			),
			array(
				'type'     => 'radio',
				'settings' => 'mvweb_service_card_shape',
				'section'  => 'mvweb_cz_services_list',
				'label'    => __( 'Photo on the service cards', 'mvweb-core' ),
				'default'  => $defaults['mvweb_service_card_shape'],
				'choices'  => array(
					'portrait'  => __( 'Upright, 4:5', 'mvweb-core' ),
					'landscape' => __( 'Wide, 4:3', 'mvweb-core' ),
				),
			),
			array(
				'type'              => 'media',
				'settings'          => 'mvweb_service_list_image',
				'section'           => 'mvweb_cz_services_list',
				'label'             => __( 'Photo in the heading of the listing', 'mvweb-core' ),
				'description'       => __( 'A photo beside the title of the services page. A section of services takes its own picture from the section.', 'mvweb-core' ),
				'default'           => $defaults['mvweb_service_list_image'],
				'sanitize_callback' => 'absint',
			),
			array(
				'type'        => 'editor',
				'settings'    => 'mvweb_service_list_text',
				'section'     => 'mvweb_cz_services_list',
				'label'       => __( 'Text under the listing', 'mvweb-core' ),
				'description' => __( 'Printed under the page numbers, on the first page only. A section of services has its own text in the section.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_service_list_text'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_service_price_from',
				'section'     => 'mvweb_cz_services_page',
				'label'       => __( 'Word before the price', 'mvweb-core' ),
				'description' => __( 'A service is quoted after a measurement, so the number is a floor. Empty prints it on its own.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_service_price_from'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_service_price_empty',
				'section'     => 'mvweb_cz_services_page',
				'label'       => __( 'Instead of a price nobody filled in', 'mvweb-core' ),
				'description' => __( 'For example: on request. Empty prints no price line at all.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_service_price_empty'],
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_service_form_title',
				'section'  => 'mvweb_cz_services_page',
				'label'    => __( 'Heading of the side card', 'mvweb-core' ),
				'default'  => $defaults['mvweb_service_form_title'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_service_form',
				'section'     => 'mvweb_cz_services_page',
				'label'       => __( 'Form shortcode', 'mvweb-core' ),
				'description' => __( 'For example [contact-form-7 id="12"]. Empty hides the form and points the button at the address set in Conversion.', 'mvweb-core' ) . ' ' . mvweb_cz_goto( 'mvweb_cz_conversion_cta', __( 'Open Conversion', 'mvweb-core' ) ),
			),
			array(
				'type'        => 'textarea',
				'settings'    => 'mvweb_service_form_note',
				'section'     => 'mvweb_cz_services_page',
				'label'       => __( 'Note in the side card', 'mvweb-core' ),
				'description' => __( 'When you answer, what happens next.', 'mvweb-core' ),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_work_label',
				'section'     => 'mvweb_cz_services_works',
				'label'       => __( 'What the portfolio is called', 'mvweb-core' ),
				'description' => __( 'In the admin menu and above the listing. Empty is "Our works".', 'mvweb-core' ),
				'default'     => $defaults['mvweb_work_label'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_work_slug',
				'section'     => 'mvweb_cz_services_works',
				'label'       => __( 'Base of the addresses', 'mvweb-core' ),
				'description' => __( 'The portfolio lives at /base/, a kind at /base/kind/ and a work at /base/kind/name/.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_work_slug'],
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_works_per_page',
				'section'     => 'mvweb_cz_services_works',
				'label'       => __( 'Works per page', 'mvweb-core' ),
				'default'     => $defaults['mvweb_works_per_page'],
				'input_attrs' => array(
					'min'  => 1,
					'max'  => 96,
					'step' => 1,
				),
			),
		);
	}
}
