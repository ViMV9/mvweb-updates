<?php
/**
 * Ready-made sets of sections for an empty page.
 *
 * A set is a list of rows in the same shape the builder stores, filled with
 * sample texts of a trade. Fields a set leaves out take their defaults, so a
 * set names only what makes it look like the trade.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_section_presets' ) ) {
	/**
	 * The registered sets.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array{label:string,description:string,rows:array<int,array{type:string,props:array<string,mixed>}>}>
	 */
	function mvweb_core_section_presets() {
		$request = '#request';

		$presets = array(
			'clinic-service'     => array(
				'label'       => __( 'Clinic service', 'mvweb-core' ),
				'description' => __( 'Prices, how the treatment goes, who it suits, doctors, reviews and questions', 'mvweb-core' ),
				'rows'        => array(
					array(
						'type'  => 'price-list',
						'props' => array(
							'kicker'      => __( 'Prices', 'mvweb-core' ),
							'title'       => __( 'Treatment prices', 'mvweb-core' ),
							'text'        => __( 'The price is fixed after the consultation and does not change during the treatment.', 'mvweb-core' ),
							'col_1'       => __( 'Price', 'mvweb-core' ),
							'rows'        => array(
								array(
									'title'   => __( 'Consultation and treatment plan', 'mvweb-core' ),
									'price_1' => __( 'Free', 'mvweb-core' ),
								),
								array(
									'title'   => __( 'Professional teeth cleaning', 'mvweb-core' ),
									'note'    => __( 'Ultrasound and Air Flow', 'mvweb-core' ),
									'price_1' => __( 'from 4 500 ₽', 'mvweb-core' ),
								),
								array(
									'title'   => __( 'Filling', 'mvweb-core' ),
									'note'    => __( 'Light-cured material', 'mvweb-core' ),
									'price_1' => __( 'from 5 900 ₽', 'mvweb-core' ),
								),
								array(
									'title'   => __( 'Implant with a crown', 'mvweb-core' ),
									'note'    => __( 'Turnkey', 'mvweb-core' ),
									'price_1' => __( 'from 45 000 ₽', 'mvweb-core' ),
								),
							),
							'button_text' => __( 'Book a consultation', 'mvweb-core' ),
							'button_url'  => $request,
							'footnote'    => __( 'Prices are indicative; the final one depends on the clinical picture.', 'mvweb-core' ),
						),
					),
					array(
						'type'  => 'steps',
						'props' => array(
							'title' => __( 'How the treatment goes', 'mvweb-core' ),
							'items' => array(
								array(
									'title' => __( 'Consultation', 'mvweb-core' ),
									'text'  => __( 'The doctor examines you, takes a scan and explains the options.', 'mvweb-core' ),
								),
								array(
									'title' => __( 'Treatment plan', 'mvweb-core' ),
									'text'  => __( 'You get a plan with the stages, the dates and a fixed price.', 'mvweb-core' ),
								),
								array(
									'title' => __( 'Treatment', 'mvweb-core' ),
									'text'  => __( 'Under modern anaesthesia, in one visit or several.', 'mvweb-core' ),
								),
								array(
									'title' => __( 'Check-up', 'mvweb-core' ),
									'text'  => __( 'A free check-up visit after the treatment.', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'two-lists',
						'props' => array(
							'title'       => __( 'Who it suits', 'mvweb-core' ),
							'left_title'  => __( 'Indications', 'mvweb-core' ),
							'left_items'  => __( "Pain or sensitivity\nA chipped or broken tooth\nA missing tooth", 'mvweb-core' ),
							'right_title' => __( 'Contraindications', 'mvweb-core' ),
							'right_items' => __( "Acute inflammation\nSome chronic diseases, discussed with the doctor", 'mvweb-core' ),
						),
					),
					array(
						'type'  => 'team',
						'props' => array(
							'title' => __( 'Our doctors', 'mvweb-core' ),
						),
					),
					array(
						'type'  => 'reviews',
						'props' => array(
							'title' => __( 'Patient reviews', 'mvweb-core' ),
							'items' => array(
								array(
									'title'  => __( 'Anna', 'mvweb-core' ),
									'text'   => __( 'I was afraid of dentists all my life. Here everything was explained in advance and nothing hurt.', 'mvweb-core' ),
									'source' => __( 'Yandex Maps', 'mvweb-core' ),
									'stars'  => 'five',
								),
								array(
									'title'  => __( 'Sergey', 'mvweb-core' ),
									'text'   => __( 'The price in the plan stayed the same to the end. The implant was placed in two visits.', 'mvweb-core' ),
									'source' => __( '2GIS', 'mvweb-core' ),
									'stars'  => 'five',
								),
							),
						),
					),
					array(
						'type'  => 'faq',
						'props' => array(
							'title' => __( 'Questions', 'mvweb-core' ),
							'items' => array(
								array(
									'title'  => __( 'Does it hurt?', 'mvweb-core' ),
									'answer' => __( 'No. We use modern anaesthesia and check that it works before we start.', 'mvweb-core' ),
								),
								array(
									'title'  => __( 'How long does the result last?', 'mvweb-core' ),
									'answer' => __( 'With regular check-ups, for years. The doctor gives a warranty on the work.', 'mvweb-core' ),
								),
								array(
									'title'  => __( 'Can I pay in instalments?', 'mvweb-core' ),
									'answer' => __( 'Yes, the treatment can be paid in stages or in instalments.', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'cta',
						'props' => array(
							'title'       => __( 'Book a consultation', 'mvweb-core' ),
							'text'        => __( 'We will call you back within 15 minutes and find a convenient time.', 'mvweb-core' ),
							'button_text' => __( 'Book', 'mvweb-core' ),
							'button_url'  => $request,
						),
					),
				),
			),
			'barbershop-home'    => array(
				'label'       => __( 'Barbershop, home page', 'mvweb-core' ),
				'description' => __( 'First screen, prices of two levels of masters, the team, ratings and addresses', 'mvweb-core' ),
				'rows'        => array(
					array(
						'type'  => 'hero',
						'props' => array(
							'title'       => __( 'Men’s haircuts and beard care', 'mvweb-core' ),
							'features'    => array(
								array( 'text' => __( 'Masters with over five years of experience', 'mvweb-core' ) ),
								array( 'text' => __( 'Coffee and tea while you wait', 'mvweb-core' ) ),
								array( 'text' => __( 'Open daily from 10:00 to 22:00', 'mvweb-core' ) ),
							),
							'button_text' => __( 'Book a visit', 'mvweb-core' ),
							'button_url'  => $request,
							'trust'       => array(
								array(
									'number' => '4.9',
									'text'   => __( 'rating<br>on the maps', 'mvweb-core' ),
								),
								array(
									'number' => '10 000+',
									'text'   => __( 'clients<br>a year', 'mvweb-core' ),
								),
								array(
									'number' => '6',
									'text'   => __( 'masters<br>in the team', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'price-list',
						'props' => array(
							'kicker'      => __( 'Prices', 'mvweb-core' ),
							'title'       => __( 'Services and prices', 'mvweb-core' ),
							'col_1'       => __( 'Master', 'mvweb-core' ),
							'col_2'       => __( 'Top master', 'mvweb-core' ),
							'rows'        => array(
								array(
									'title'   => __( 'Men’s haircut', 'mvweb-core' ),
									'price_1' => '1 800 ₽',
									'price_2' => '2 300 ₽',
								),
								array(
									'title'   => __( 'Beard trim and shaping', 'mvweb-core' ),
									'price_1' => '1 200 ₽',
									'price_2' => '1 500 ₽',
								),
								array(
									'title'   => __( 'Haircut and beard', 'mvweb-core' ),
									'price_1' => '2 700 ₽',
									'price_2' => '3 400 ₽',
								),
								array(
									'title'   => __( 'Father and son', 'mvweb-core' ),
									'note'    => __( 'Two haircuts at once', 'mvweb-core' ),
									'price_1' => '3 000 ₽',
									'price_2' => '3 600 ₽',
								),
							),
							'button_text' => __( 'Book a visit', 'mvweb-core' ),
							'button_url'  => $request,
						),
					),
					array(
						'type'  => 'team',
						'props' => array(
							'title' => __( 'Our masters', 'mvweb-core' ),
						),
					),
					array(
						'type'  => 'reviews',
						'props' => array(
							'title'   => __( 'What clients say', 'mvweb-core' ),
							'ratings' => array(
								array(
									'title' => __( 'Yandex Maps', 'mvweb-core' ),
									'score' => '4.9',
									'note'  => __( '300+ reviews', 'mvweb-core' ),
								),
								array(
									'title' => __( '2GIS', 'mvweb-core' ),
									'score' => '4.8',
									'note'  => __( '150+ reviews', 'mvweb-core' ),
								),
							),
							'items'   => array(
								array(
									'title'  => __( 'Dmitry', 'mvweb-core' ),
									'text'   => __( 'I have been coming for two years. The haircut holds its shape until the next visit.', 'mvweb-core' ),
									'source' => __( 'Yandex Maps', 'mvweb-core' ),
									'stars'  => 'five',
								),
								array(
									'title'  => __( 'Alexey', 'mvweb-core' ),
									'text'   => __( 'Booked for the evening on the same day. The beard was shaped exactly as I asked.', 'mvweb-core' ),
									'source' => __( '2GIS', 'mvweb-core' ),
									'stars'  => 'five',
								),
							),
						),
					),
					array(
						'type'  => 'branches',
						'props' => array(
							'title' => __( 'Where we are', 'mvweb-core' ),
						),
					),
					array(
						'type'  => 'cta',
						'props' => array(
							'title'       => __( 'Book a visit', 'mvweb-core' ),
							'text'        => __( 'Pick a master and a time, and we will confirm by phone.', 'mvweb-core' ),
							'button_text' => __( 'Book', 'mvweb-core' ),
							'button_url'  => $request,
						),
					),
				),
			),
			'renovation-landing' => array(
				'label'       => __( 'Flat renovation, landing page', 'mvweb-core' ),
				'description' => __( 'First screen, packages per square metre, stages, before and after, works and questions', 'mvweb-core' ),
				'rows'        => array(
					array(
						'type'  => 'hero',
						'props' => array(
							'title'       => __( 'Turnkey flat renovation with a fixed estimate', 'mvweb-core' ),
							'features'    => array(
								array( 'text' => __( 'The estimate does not grow', 'mvweb-core' ) ),
								array( 'text' => __( 'Warranty up to three years', 'mvweb-core' ) ),
								array( 'text' => __( 'Contract and payment in stages', 'mvweb-core' ) ),
							),
							'button_text' => __( 'Get an estimate', 'mvweb-core' ),
							'button_url'  => $request,
							'trust'       => array(
								array(
									'number' => '12',
									'text'   => __( 'years<br>of work', 'mvweb-core' ),
								),
								array(
									'number' => '350+',
									'text'   => __( 'flats<br>renovated', 'mvweb-core' ),
								),
								array(
									'number' => '3',
									'text'   => __( 'years<br>of warranty', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'plans',
						'props' => array(
							'kicker' => __( 'Prices', 'mvweb-core' ),
							'title'  => __( 'Renovation packages', 'mvweb-core' ),
							'text'   => __( 'Price per square metre of floor, materials not included.', 'mvweb-core' ),
							'plans'  => array(
								array(
									'title'       => __( 'Cosmetic', 'mvweb-core' ),
									'text'        => __( 'A refresh without moving walls', 'mvweb-core' ),
									'price'       => __( 'from 6 000 ₽', 'mvweb-core' ),
									'unit'        => __( 'per m²', 'mvweb-core' ),
									'items'       => __( "Wallpaper or paint\nFloor covering\nNew sockets and switches", 'mvweb-core' ),
									'button_text' => __( 'Get an estimate', 'mvweb-core' ),
									'button_url'  => $request,
								),
								array(
									'title'       => __( 'Major', 'mvweb-core' ),
									'badge'       => __( 'Popular', 'mvweb-core' ),
									'text'        => __( 'New wiring and plumbing', 'mvweb-core' ),
									'price'       => __( 'from 12 000 ₽', 'mvweb-core' ),
									'unit'        => __( 'per m²', 'mvweb-core' ),
									'items'       => __( "New wiring and plumbing\nLevelled walls and floors\nTiled bathroom", 'mvweb-core' ),
									'button_text' => __( 'Get an estimate', 'mvweb-core' ),
									'button_url'  => $request,
								),
								array(
									'title'       => __( 'By design', 'mvweb-core' ),
									'text'        => __( 'Renovation by a design project', 'mvweb-core' ),
									'price'       => __( 'from 18 000 ₽', 'mvweb-core' ),
									'unit'        => __( 'per m²', 'mvweb-core' ),
									'items'       => __( "Design project included\nThe designer supervises the work\nWe buy the materials", 'mvweb-core' ),
									'button_text' => __( 'Get an estimate', 'mvweb-core' ),
									'button_url'  => $request,
								),
							),
						),
					),
					array(
						'type'  => 'steps',
						'props' => array(
							'title' => __( 'How we work', 'mvweb-core' ),
							'items' => array(
								array(
									'title' => __( 'Measurement', 'mvweb-core' ),
									'text'  => __( 'An engineer comes free of charge, measures the flat and notes your wishes.', 'mvweb-core' ),
								),
								array(
									'title' => __( 'Estimate and contract', 'mvweb-core' ),
									'text'  => __( 'A detailed estimate and a contract with fixed dates and price.', 'mvweb-core' ),
								),
								array(
									'title' => __( 'Renovation', 'mvweb-core' ),
									'text'  => __( 'The team works to a schedule, and you get photo reports every week.', 'mvweb-core' ),
								),
								array(
									'title' => __( 'Handover', 'mvweb-core' ),
									'text'  => __( 'We hand the flat over clean, with the warranty documents.', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'before-after',
						'props' => array(
							'title' => __( 'Before and after', 'mvweb-core' ),
							'text'  => __( 'Flats we have finished: drag the slider to compare.', 'mvweb-core' ),
						),
					),
					array(
						'type'  => 'works',
						'props' => array(
							'title' => __( 'Our works', 'mvweb-core' ),
						),
					),
					array(
						'type'  => 'faq',
						'props' => array(
							'title' => __( 'Questions', 'mvweb-core' ),
							'items' => array(
								array(
									'title'  => __( 'Can I live in the flat during the renovation?', 'mvweb-core' ),
									'answer' => __( 'During a cosmetic one, yes, room by room. During a major one it is better to move out for the rough stage.', 'mvweb-core' ),
								),
								array(
									'title'  => __( 'Who buys the materials?', 'mvweb-core' ),
									'answer' => __( 'As you prefer: we buy them at our trade prices, or you buy them from our list.', 'mvweb-core' ),
								),
								array(
									'title'  => __( 'What if the estimate grows?', 'mvweb-core' ),
									'answer' => __( 'It does not: the price in the contract is fixed. New work is added only with your written consent.', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'cta',
						'props' => array(
							'title'       => __( 'Get an estimate', 'mvweb-core' ),
							'text'        => __( 'The engineer’s visit and the estimate are free.', 'mvweb-core' ),
							'button_text' => __( 'Call the engineer', 'mvweb-core' ),
							'button_url'  => $request,
						),
					),
				),
			),
			'lawyer-service'     => array(
				'label'       => __( 'Lawyer, service', 'mvweb-core' ),
				'description' => __( 'What is included, prices, stages, figures, reviews and questions', 'mvweb-core' ),
				'rows'        => array(
					array(
						'type'  => 'two-lists',
						'props' => array(
							'title'       => __( 'What the service includes', 'mvweb-core' ),
							'marks'       => 'yes-yes',
							'left_title'  => __( 'We do', 'mvweb-core' ),
							'left_items'  => __( "Study the documents and the prospects\nDraft the claim and the motions\nRepresent you in court", 'mvweb-core' ),
							'right_title' => __( 'You get', 'mvweb-core' ),
							'right_items' => __( "A clear plan and a fixed price\nA report at every stage\nA court decision and a writ of execution", 'mvweb-core' ),
						),
					),
					array(
						'type'  => 'price-list',
						'props' => array(
							'kicker'      => __( 'Prices', 'mvweb-core' ),
							'title'       => __( 'How much it costs', 'mvweb-core' ),
							'col_1'       => __( 'Price', 'mvweb-core' ),
							'rows'        => array(
								array(
									'title'   => __( 'Consultation', 'mvweb-core' ),
									'note'    => __( '30 minutes, in the office or online', 'mvweb-core' ),
									'price_1' => __( 'Free', 'mvweb-core' ),
								),
								array(
									'title'   => __( 'Study of the documents', 'mvweb-core' ),
									'price_1' => __( 'from 5 000 ₽', 'mvweb-core' ),
								),
								array(
									'title'   => __( 'Drafting a claim', 'mvweb-core' ),
									'price_1' => __( 'from 10 000 ₽', 'mvweb-core' ),
								),
								array(
									'title'   => __( 'Representation in court', 'mvweb-core' ),
									'note'    => __( 'One instance', 'mvweb-core' ),
									'price_1' => __( 'from 40 000 ₽', 'mvweb-core' ),
								),
							),
							'button_text' => __( 'Ask a lawyer', 'mvweb-core' ),
							'button_url'  => $request,
							'footnote'    => __( 'The price is fixed in the contract.', 'mvweb-core' ),
						),
					),
					array(
						'type'  => 'steps',
						'props' => array(
							'title' => __( 'How we work', 'mvweb-core' ),
							'items' => array(
								array(
									'title' => __( 'Consultation', 'mvweb-core' ),
									'text'  => __( 'We listen, study the documents and assess the prospects.', 'mvweb-core' ),
								),
								array(
									'title' => __( 'Contract', 'mvweb-core' ),
									'text'  => __( 'We fix the scope of work, the dates and the price.', 'mvweb-core' ),
								),
								array(
									'title' => __( 'Work on the case', 'mvweb-core' ),
									'text'  => __( 'We prepare the documents and represent you, with a report after every hearing.', 'mvweb-core' ),
								),
								array(
									'title' => __( 'Result', 'mvweb-core' ),
									'text'  => __( 'You get the decision and, if needed, help with its enforcement.', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'stats',
						'props' => array(
							'title' => __( 'In figures', 'mvweb-core' ),
							'items' => array(
								array(
									'number' => '15',
									'label'  => __( 'years of practice', 'mvweb-core' ),
								),
								array(
									'number' => '1 200+',
									'label'  => __( 'cases won', 'mvweb-core' ),
								),
								array(
									'number' => '87%',
									'label'  => __( 'cases in favour of clients', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'reviews',
						'props' => array(
							'title' => __( 'Client reviews', 'mvweb-core' ),
							'items' => array(
								array(
									'title'  => __( 'Olga', 'mvweb-core' ),
									'text'   => __( 'The case with the developer took four months. The penalty was recovered in full.', 'mvweb-core' ),
									'source' => __( 'Yandex Maps', 'mvweb-core' ),
									'stars'  => 'five',
								),
								array(
									'title'  => __( 'Igor', 'mvweb-core' ),
									'text'   => __( 'Everything was explained in plain words, and the price did not change along the way.', 'mvweb-core' ),
									'source' => __( 'Yandex Maps', 'mvweb-core' ),
									'stars'  => 'five',
								),
							),
						),
					),
					array(
						'type'  => 'faq',
						'props' => array(
							'title' => __( 'Questions', 'mvweb-core' ),
							'items' => array(
								array(
									'title'  => __( 'How much does going to court cost?', 'mvweb-core' ),
									'answer' => __( 'It depends on the case. After the consultation we name a fixed price and put it in the contract.', 'mvweb-core' ),
								),
								array(
									'title'  => __( 'Is the first consultation really free?', 'mvweb-core' ),
									'answer' => __( 'Yes. It takes up to 30 minutes and does not oblige you to anything.', 'mvweb-core' ),
								),
								array(
									'title'  => __( 'Can you work remotely?', 'mvweb-core' ),
									'answer' => __( 'Yes. Documents are sent by e-mail, and most hearings can be attended without you.', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'cta',
						'props' => array(
							'title'       => __( 'Get a free consultation', 'mvweb-core' ),
							'text'        => __( 'Describe your situation, and a lawyer will call you back within an hour.', 'mvweb-core' ),
							'button_text' => __( 'Ask a lawyer', 'mvweb-core' ),
							'button_url'  => $request,
						),
					),
				),
			),
			'repair-service'     => array(
				'label'       => __( 'Device repair', 'mvweb-core' ),
				'description' => __( 'Prices with repair times, advantages, stages, questions and service centres', 'mvweb-core' ),
				'rows'        => array(
					array(
						'type'  => 'price-list',
						'props' => array(
							'kicker'      => __( 'Prices', 'mvweb-core' ),
							'title'       => __( 'Repair prices', 'mvweb-core' ),
							'col_1'       => __( 'Time', 'mvweb-core' ),
							'col_2'       => __( 'Price', 'mvweb-core' ),
							'rows'        => array(
								array(
									'title'   => __( 'Diagnostics', 'mvweb-core' ),
									'price_1' => __( '15 minutes', 'mvweb-core' ),
									'price_2' => __( 'Free', 'mvweb-core' ),
								),
								array(
									'title'   => __( 'Screen replacement', 'mvweb-core' ),
									'price_1' => __( 'from 40 minutes', 'mvweb-core' ),
									'price_2' => __( 'from 3 900 ₽', 'mvweb-core' ),
								),
								array(
									'title'   => __( 'Battery replacement', 'mvweb-core' ),
									'price_1' => __( '30 minutes', 'mvweb-core' ),
									'price_2' => __( 'from 2 500 ₽', 'mvweb-core' ),
								),
								array(
									'title'   => __( 'Charging port repair', 'mvweb-core' ),
									'price_1' => __( '1 hour', 'mvweb-core' ),
									'price_2' => __( 'from 2 000 ₽', 'mvweb-core' ),
								),
								array(
									'title'   => __( 'Recovery after water', 'mvweb-core' ),
									'price_1' => __( 'from 1 day', 'mvweb-core' ),
									'price_2' => __( 'from 3 000 ₽', 'mvweb-core' ),
								),
							),
							'button_text' => __( 'Book a repair', 'mvweb-core' ),
							'button_url'  => $request,
							'footnote'    => __( 'The final price is agreed after the diagnostics, before the repair.', 'mvweb-core' ),
						),
					),
					array(
						'type'  => 'features',
						'props' => array(
							'title'  => __( 'Why us', 'mvweb-core' ),
							'blocks' => array(
								array(
									'icon'  => 'search',
									'title' => __( 'Free diagnostics', 'mvweb-core' ),
									'text'  => __( 'We find the fault and name the price before we start.', 'mvweb-core' ),
								),
								array(
									'icon'  => 'clock',
									'title' => __( 'Repair in 30 minutes', 'mvweb-core' ),
									'text'  => __( 'Most repairs are done while you wait.', 'mvweb-core' ),
								),
								array(
									'icon'  => 'shield-check',
									'title' => __( 'Warranty up to a year', 'mvweb-core' ),
									'text'  => __( 'On the work and on the parts we fitted.', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'steps',
						'props' => array(
							'title' => __( 'How the repair goes', 'mvweb-core' ),
							'items' => array(
								array(
									'title' => __( 'Bring the device', 'mvweb-core' ),
									'text'  => __( 'Or call a courier, who picks it up anywhere in the city.', 'mvweb-core' ),
								),
								array(
									'title' => __( 'Diagnostics', 'mvweb-core' ),
									'text'  => __( 'Fifteen minutes, free, with the price before the repair.', 'mvweb-core' ),
								),
								array(
									'title' => __( 'Repair', 'mvweb-core' ),
									'text'  => __( 'Usually while you wait; with a part to order, from one day.', 'mvweb-core' ),
								),
								array(
									'title' => __( 'Check and warranty', 'mvweb-core' ),
									'text'  => __( 'We test everything with you and issue a warranty.', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'faq',
						'props' => array(
							'title' => __( 'Questions', 'mvweb-core' ),
							'items' => array(
								array(
									'title'  => __( 'How long does a repair take?', 'mvweb-core' ),
									'answer' => __( 'Most repairs take 30 minutes to an hour. With a part to order, one to three days.', 'mvweb-core' ),
								),
								array(
									'title'  => __( 'Will my data be kept?', 'mvweb-core' ),
									'answer' => __( 'In most repairs, yes. If there is a risk, we warn you before we start.', 'mvweb-core' ),
								),
								array(
									'title'  => __( 'What if the repair is not worth it?', 'mvweb-core' ),
									'answer' => __( 'We say so after the diagnostics, and you pay nothing.', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'branches',
						'props' => array(
							'title' => __( 'Service centres', 'mvweb-core' ),
						),
					),
					array(
						'type'  => 'cta',
						'props' => array(
							'title'       => __( 'Book a repair', 'mvweb-core' ),
							'text'        => __( 'Leave a request, and we will call back with the price and the time.', 'mvweb-core' ),
							'button_text' => __( 'Book a repair', 'mvweb-core' ),
							'button_url'  => $request,
						),
					),
				),
			),
			'shop-home'          => array(
				'label'       => __( 'Shop, home page', 'mvweb-core' ),
				'description' => __( 'Sale banner, categories, bestsellers, delivery and payment, reviews and articles', 'mvweb-core' ),
				'rows'        => array(
					array(
						'type'  => 'banner',
						'props' => array(
							'title'       => __( 'Seasonal sale', 'mvweb-core' ),
							'text'        => __( 'Up to 30% off the whole collection', 'mvweb-core' ),
							'button_text' => __( 'To the catalogue', 'mvweb-core' ),
							'button_url'  => '/catalog/',
						),
					),
					array(
						'type'  => 'categories',
						'props' => array(
							'title'  => __( 'Catalogue', 'mvweb-core' ),
							'source' => 'product_cat',
						),
					),
					array(
						'type'  => 'products',
						'props' => array(
							'title' => __( 'Bestsellers', 'mvweb-core' ),
						),
					),
					array(
						'type'  => 'features',
						'props' => array(
							'title'  => __( 'Why buy from us', 'mvweb-core' ),
							'blocks' => array(
								array(
									'icon'  => 'truck-delivery',
									'title' => __( 'Fast delivery', 'mvweb-core' ),
									'text'  => __( 'Across the city the next day, to other regions by carriers.', 'mvweb-core' ),
								),
								array(
									'icon'  => 'credit-card',
									'title' => __( 'Easy payment', 'mvweb-core' ),
									'text'  => __( 'By card online, in cash, or on invoice for companies.', 'mvweb-core' ),
								),
								array(
									'icon'  => 'shield-check',
									'title' => __( 'Official warranty', 'mvweb-core' ),
									'text'  => __( 'Every item comes with documents and a warranty.', 'mvweb-core' ),
								),
								array(
									'icon'  => 'rosette-discount-check',
									'title' => __( 'Fair prices', 'mvweb-core' ),
									'text'  => __( 'We buy directly from the manufacturers.', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'reviews',
						'props' => array(
							'title' => __( 'Customer reviews', 'mvweb-core' ),
							'items' => array(
								array(
									'title'  => __( 'Marina', 'mvweb-core' ),
									'text'   => __( 'Ordered in the evening and received it the next day. Everything was packed carefully.', 'mvweb-core' ),
									'source' => __( 'Yandex Maps', 'mvweb-core' ),
									'stars'  => 'five',
								),
								array(
									'title'  => __( 'Pavel', 'mvweb-core' ),
									'text'   => __( 'The manager helped me choose and sent the documents for the company the same day.', 'mvweb-core' ),
									'source' => __( 'Yandex Maps', 'mvweb-core' ),
									'stars'  => 'five',
								),
							),
						),
					),
					array(
						'type'  => 'posts',
						'props' => array(
							'title' => __( 'Useful articles', 'mvweb-core' ),
						),
					),
				),
			),
			'artist'             => array(
				'label'       => __( 'Artist or maker', 'mvweb-core' ),
				'description' => __( 'First screen, about me, works, commission prices, reviews and questions', 'mvweb-core' ),
				'rows'        => array(
					array(
						'type'  => 'hero',
						'props' => array(
							'title'       => __( 'Paintings to order and finished works', 'mvweb-core' ),
							'features'    => array(
								array( 'text' => __( 'Oil and acrylic on canvas', 'mvweb-core' ) ),
								array( 'text' => __( 'Portraits from a photo', 'mvweb-core' ) ),
								array( 'text' => __( 'Delivery across the country', 'mvweb-core' ) ),
							),
							'button_text' => __( 'Order a painting', 'mvweb-core' ),
							'button_url'  => $request,
							'trust'       => array(
								array(
									'number' => '15',
									'text'   => __( 'years<br>of painting', 'mvweb-core' ),
								),
								array(
									'number' => '400+',
									'text'   => __( 'paintings<br>sold', 'mvweb-core' ),
								),
								array(
									'number' => '12',
									'text'   => __( 'exhibitions<br>held', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'content',
						'props' => array(
							'title' => __( 'About me', 'mvweb-core' ),
							'text'  => '<p>' . __( 'I paint landscapes, portraits and still lifes. Every painting is made by hand from start to finish, and I send you photos at every stage so that the result is what you pictured.', 'mvweb-core' ) . '</p>',
						),
					),
					array(
						'type'  => 'works',
						'props' => array(
							'title' => __( 'Works', 'mvweb-core' ),
							'count' => 6,
						),
					),
					array(
						'type'  => 'plans',
						'props' => array(
							'title' => __( 'Order a painting', 'mvweb-core' ),
							'text'  => __( 'The price depends on the size and the technique.', 'mvweb-core' ),
							'plans' => array(
								array(
									'title'       => __( 'Sketch', 'mvweb-core' ),
									'text'        => __( 'Pencil or ink, A4', 'mvweb-core' ),
									'price'       => __( 'from 3 000 ₽', 'mvweb-core' ),
									'items'       => __( "One figure or object\nReady in three days", 'mvweb-core' ),
									'button_text' => __( 'Place an order', 'mvweb-core' ),
									'button_url'  => $request,
								),
								array(
									'title'       => __( 'Painting', 'mvweb-core' ),
									'badge'       => __( 'Popular', 'mvweb-core' ),
									'text'        => __( 'Oil or acrylic, 40×50 cm', 'mvweb-core' ),
									'price'       => __( 'from 15 000 ₽', 'mvweb-core' ),
									'items'       => __( "Two sketches to choose from\nReady in two weeks\nVarnished", 'mvweb-core' ),
									'button_text' => __( 'Place an order', 'mvweb-core' ),
									'button_url'  => $request,
								),
								array(
									'title'       => __( 'Large format', 'mvweb-core' ),
									'text'        => __( 'From 80×100 cm', 'mvweb-core' ),
									'price'       => __( 'from 40 000 ₽', 'mvweb-core' ),
									'items'       => __( "Composition agreed in advance\nReady in a month\nFrame of your choice", 'mvweb-core' ),
									'button_text' => __( 'Place an order', 'mvweb-core' ),
									'button_url'  => $request,
								),
							),
						),
					),
					array(
						'type'  => 'reviews',
						'props' => array(
							'title' => __( 'Reviews', 'mvweb-core' ),
							'items' => array(
								array(
									'title'  => __( 'Elena', 'mvweb-core' ),
									'text'   => __( 'I ordered a portrait of my parents as a gift. The likeness is striking, and everyone was moved.', 'mvweb-core' ),
									'source' => __( 'VK', 'mvweb-core' ),
									'stars'  => 'five',
								),
								array(
									'title'  => __( 'Mikhail', 'mvweb-core' ),
									'text'   => __( 'The landscape for the living room came out exactly in our colours. Delivered well packed.', 'mvweb-core' ),
									'source' => __( 'VK', 'mvweb-core' ),
									'stars'  => 'five',
								),
							),
						),
					),
					array(
						'type'  => 'faq',
						'props' => array(
							'title' => __( 'Questions', 'mvweb-core' ),
							'items' => array(
								array(
									'title'  => __( 'How long does an order take?', 'mvweb-core' ),
									'answer' => __( 'From three days for a sketch to a month for a large canvas.', 'mvweb-core' ),
								),
								array(
									'title'  => __( 'Can I see the painting before paying the rest?', 'mvweb-core' ),
									'answer' => __( 'Yes. You pay half in advance and the rest after you have seen the finished work.', 'mvweb-core' ),
								),
								array(
									'title'  => __( 'Do you send to other cities?', 'mvweb-core' ),
									'answer' => __( 'Yes, by courier service, in a rigid package.', 'mvweb-core' ),
								),
							),
						),
					),
					array(
						'type'  => 'cta',
						'props' => array(
							'title'       => __( 'Order a painting', 'mvweb-core' ),
							'text'        => __( 'Tell me the idea and the size, and I will reply with the price and the dates.', 'mvweb-core' ),
							'button_text' => __( 'Discuss the order', 'mvweb-core' ),
							'button_url'  => $request,
						),
					),
				),
			),
		);

		/**
		 * Filter the ready-made sets of sections.
		 *
		 * @since 0.1.0
		 *
		 * @param array $presets Sets keyed by slug.
		 */
		return (array) apply_filters( 'mvweb_core_section_presets', $presets );
	}
}

if ( ! function_exists( 'mvweb_core_builder_presets' ) ) {
	/**
	 * The sets in the shape the builder reads, without rows of unknown types.
	 *
	 * @since 0.1.0
	 *
	 * @param array $types Types known to the builder, keyed by slug.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_builder_presets( array $types ) {
		$out = array();

		foreach ( mvweb_core_section_presets() as $id => $preset ) {
			$rows = array_values(
				array_filter(
					isset( $preset['rows'] ) ? (array) $preset['rows'] : array(),
					static function ( $row ) use ( $types ) {
						return is_array( $row ) && isset( $row['type'] ) && isset( $types[ $row['type'] ] );
					}
				)
			);

			if ( $rows && count( $rows ) === count( (array) $preset['rows'] ) ) {
				$out[] = array(
					'id'          => (string) $id,
					'label'       => isset( $preset['label'] ) ? (string) $preset['label'] : (string) $id,
					'description' => isset( $preset['description'] ) ? (string) $preset['description'] : '',
					'rows'        => $rows,
				);
			}
		}

		return $out;
	}
}
