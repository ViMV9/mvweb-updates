<?php
/**
 * The blocks of the homepage.
 *
 * They are rows like the blocks of a page — any type, any number of times, each
 * with its own settings — kept in one theme_mod and edited by the same builder
 * inside the Customizer.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_sanitize_home_rows' ) ) {
	/**
	 * Sanitize the rows of the homepage as the Customizer sends them.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value JSON of the rows, or the rows.
	 *
	 * @return string JSON of the clean rows.
	 */
	function mvweb_core_sanitize_home_rows( $value ) {
		$rows = is_string( $value ) ? json_decode( $value, true, 10 ) : $value;

		return (string) wp_json_encode( mvweb_core_sanitize_sections( is_array( $rows ) ? $rows : array() ) );
	}
}

if ( ! function_exists( 'mvweb_core_home_builder_register' ) ) {
	/**
	 * Register the setting and the control of the homepage blocks.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer.
	 *
	 * @return void
	 */
	function mvweb_core_home_builder_register( $wp_customize ) {
		require_once MVWEB_CORE_DIR . '/inc/class-mvweb-core-home-builder-control.php';

		$wp_customize->add_setting(
			'mvweb_home_rows',
			array(
				'type'              => 'theme_mod',
				'default'           => '',
				'sanitize_callback' => 'mvweb_core_sanitize_home_rows',
				'transport'         => 'refresh',
			)
		);

		$wp_customize->add_control(
			new MVweb_Core_Home_Builder_Control(
				$wp_customize,
				'mvweb_home_rows',
				array(
					'section'     => 'mvweb_cz_home_blocks',
					'label'       => __( 'Blocks of the homepage', 'mvweb-core' ),
					'description' => __( 'Add blocks, drag to reorder, duplicate a block to use it twice.', 'mvweb-core' ),
				)
			)
		);
	}
}
add_action( 'customize_register', 'mvweb_core_home_builder_register', 20 );
add_action( 'customize_controls_enqueue_scripts', 'mvweb_core_enqueue_builder' );
