<?php
/**
 * Admin scripts of the block look: the contrast check and its Customizer side.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_contrast_register' ) ) {
	/**
	 * Register the contrast script the builder and the Customizer depend on.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_contrast_register() {
		$script = mvweb_core_asset_path( '/admin/js/contrast.js' );

		wp_register_script( 'mvweb-core-contrast', MVWEB_CORE_URI . $script, array(), mvweb_core_asset_version( $script ), true );
		wp_localize_script(
			'mvweb-core-contrast',
			'mvwebCoreContrastText',
			array(
				'low' => __( 'Contrast is below 4.5:1: the text will be hard to read.', 'mvweb-core' ),
			)
		);
	}
}
add_action( 'admin_enqueue_scripts', 'mvweb_core_contrast_register', 1 );
add_action( 'customize_controls_enqueue_scripts', 'mvweb_core_contrast_register', 1 );

if ( ! function_exists( 'mvweb_core_look_customizer_script' ) ) {
	/**
	 * Warn in the Customizer when the colours of a block cannot be read together.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_look_customizer_script() {
		$pairs = array();

		foreach ( array_keys( mvweb_core_editable_sections() ) as $type ) {
			foreach ( array(
				'bg_color'      => 'ink_color',
				'bg_color_dark' => 'ink_color_dark',
			) as $bg => $ink ) {
				$pairs[] = array(
					'bg'  => mvweb_core_section_setting( $type, $bg ),
					'ink' => mvweb_core_section_setting( $type, $ink ),
				);
			}
		}

		$script = mvweb_core_asset_path( '/admin/js/customizer-look.js' );

		wp_enqueue_script( 'mvweb-core-customizer-look', MVWEB_CORE_URI . $script, array( 'customize-controls', 'mvweb-core-contrast' ), mvweb_core_asset_version( $script ), true );
		wp_localize_script( 'mvweb-core-customizer-look', 'mvwebCoreLook', array( 'pairs' => $pairs ) );
	}
}
add_action( 'customize_controls_enqueue_scripts', 'mvweb_core_look_customizer_script' );
