<?php
/**
 * Shared helpers.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_nav' ) ) {
	/**
	 * Print a nav menu, or nothing when the location has none assigned.
	 *
	 * @since 0.1.0
	 *
	 * @param string $location Registered menu location.
	 * @param array  $args     Optional. Arguments passed to wp_nav_menu().
	 *
	 * @return void
	 */
	function mvweb_core_nav( $location, $args = array() ) {
		if ( ! has_nav_menu( $location ) ) {
			return;
		}

		$args = wp_parse_args(
			$args,
			array(
				'theme_location' => $location,
				'container'      => false,
				'depth'          => 1,
				'fallback_cb'    => false,
				'link_class'     => '',
				'item_class'     => '',
			)
		);

		$link_class = $args['link_class'];
		$item_class = $args['item_class'];
		unset( $args['link_class'], $args['item_class'] );

		$link_filter = static function ( $atts ) use ( $link_class ) {
			$atts['class'] = trim( ( isset( $atts['class'] ) ? $atts['class'] . ' ' : '' ) . $link_class );

			return $atts;
		};

		$item_filter = static function ( $classes ) use ( $item_class ) {
			$classes[] = $item_class;

			return $classes;
		};

		if ( '' !== $link_class ) {
			add_filter( 'nav_menu_link_attributes', $link_filter );
		}

		if ( '' !== $item_class ) {
			add_filter( 'nav_menu_css_class', $item_filter );
		}

		wp_nav_menu( $args );

		if ( '' !== $link_class ) {
			remove_filter( 'nav_menu_link_attributes', $link_filter );
		}

		if ( '' !== $item_class ) {
			remove_filter( 'nav_menu_css_class', $item_filter );
		}
	}
}

if ( ! function_exists( 'mvweb_core_scheme_mode' ) ) {
	/**
	 * Which colour schemes the site offers: light, dark or both.
	 *
	 * @since 0.1.0
	 *
	 * @return string One of light, dark, both.
	 */
	function mvweb_core_scheme_mode() {
		$mode = (string) get_theme_mod( 'mvweb_scheme_mode', 'both' );

		return in_array( $mode, array( 'light', 'dark', 'both' ), true ) ? $mode : 'both';
	}
}

if ( ! function_exists( 'mvweb_core_default_scheme' ) ) {
	/**
	 * The scheme a page opens in before the visitor has chosen one.
	 *
	 * @since 0.1.0
	 *
	 * @return string Either light or dark.
	 */
	function mvweb_core_default_scheme() {
		$mode = mvweb_core_scheme_mode();

		if ( 'both' !== $mode ) {
			return $mode;
		}

		return 'dark' === get_theme_mod( 'mvweb_scheme_default', 'light' ) ? 'dark' : 'light';
	}
}

if ( ! function_exists( 'mvweb_core_header_messengers_default' ) ) {
	/**
	 * The messengers the header shows until the owner picks their own.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_header_messengers_default() {
		return array_keys( mvweb_cz_chats() );
	}
}

if ( ! function_exists( 'mvweb_core_allowed_protocols' ) ) {
	/**
	 * Let a link open Viber.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $protocols Allowed schemes.
	 *
	 * @return string[]
	 */
	function mvweb_core_allowed_protocols( $protocols ) {
		return array_merge( (array) $protocols, array( 'viber' ) );
	}
}
add_filter( 'kses_allowed_protocols', 'mvweb_core_allowed_protocols' );

if ( ! function_exists( 'mvweb_core_header_messengers' ) ) {
	/**
	 * Links for the messenger buttons of the header, in the profile's order.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array{url:string,label:string}> Network id => link.
	 */
	function mvweb_core_header_messengers() {
		$chosen = json_decode( (string) get_theme_mod( 'mvweb_header_messengers', wp_json_encode( mvweb_core_header_messengers_default() ) ), true );
		$chosen = is_array( $chosen ) ? array_map( 'sanitize_key', $chosen ) : array();

		return array_intersect_key( mvweb_cz_profile_chats(), array_flip( $chosen ) );
	}
}

if ( ! function_exists( 'mvweb_core_alt_h1' ) ) {
	/**
	 * The alternative visible heading of the queried object.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty when nothing is set.
	 */
	function mvweb_core_alt_h1() {
		$object = get_queried_object();

		if ( $object instanceof WP_Post ) {
			$value = get_post_meta( $object->ID, '_mvweb_alt_h1', true );
		} elseif ( $object instanceof WP_Term ) {
			$value = get_term_meta( $object->term_id, '_mvweb_alt_h1', true );
		} else {
			$value = '';
		}

		return is_string( $value ) ? trim( $value ) : '';
	}
}

if ( ! function_exists( 'mvweb_core_reading_time' ) ) {
	/**
	 * How long the current entry takes to read.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty for an entry too short to bother stating.
	 */
	function mvweb_core_reading_time() {
		$words = preg_match_all( '/[\p{L}\p{N}]+/u', wp_strip_all_tags( get_the_content() ) );

		/**
		 * Filter the reading speed used for the estimate.
		 *
		 * @since 0.1.0
		 *
		 * @param int $per_minute Words per minute.
		 */
		$per_minute = max( 1, (int) apply_filters( 'mvweb_core_reading_speed', 180 ) );
		$minutes    = (int) ceil( $words / $per_minute );

		if ( $minutes < 2 ) {
			return '';
		}

		return sprintf(
			/* translators: %s: number of minutes. */
			_n( '%s minute read', '%s minutes read', $minutes, 'mvweb-core' ),
			number_format_i18n( $minutes )
		);
	}
}

if ( ! function_exists( 'mvweb_core_is_catalog' ) ) {
	/**
	 * Whether this request prints a catalogue listing.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_is_catalog() {
		if ( function_exists( 'is_shop' ) ) {
			return is_shop() || is_product_taxonomy();
		}

		return is_post_type_archive( 'mv_item' ) || is_tax( 'mv_item_cat' );
	}
}

if ( ! function_exists( 'mvweb_core_is_product' ) ) {
	/**
	 * Whether this request prints the page of one catalogue item.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_is_product() {
		if ( function_exists( 'is_product' ) ) {
			return is_product();
		}

		return is_singular( 'mv_item' );
	}
}

if ( ! function_exists( 'mvweb_core_is_services' ) ) {
	/**
	 * Whether this request prints a services listing.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_is_services() {
		return is_post_type_archive( 'mv_service' ) || is_tax( 'mv_service_cat' );
	}
}

if ( ! function_exists( 'mvweb_core_is_service' ) ) {
	/**
	 * Whether this request prints the page of one service.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_is_service() {
		return is_singular( 'mv_service' );
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_map' ) ) {
	/**
	 * The address of an embedded map, from whatever the owner pasted.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Pasted snippet or address.
	 *
	 * @return string Address to load in an iframe, or empty.
	 */
	function mvweb_core_sanitize_map( $value ) {
		$value = trim( (string) $value );

		if ( preg_match( '/um=(constructor(?:%3A|:)[A-Za-z0-9_\-]+)/', $value, $match ) ) {
			return esc_url_raw( 'https://yandex.ru/map-widget/v1/?um=' . rawurlencode( rawurldecode( $match[1] ) ) . '&source=constructor' );
		}

		if ( preg_match( '/\bsrc\s*=\s*["\']([^"\']+)["\']/i', $value, $match ) ) {
			$value = html_entity_decode( $match[1] );
		}

		$parts = wp_parse_url( $value );
		$hosts = array(
			'yandex.ru'         => '/map',
			'yandex.com'        => '/map',
			'yandex.by'         => '/map',
			'google.com'        => '/maps',
			'maps.google.com'   => '/maps',
			'openstreetmap.org' => '/',
			'2gis.ru'           => '/',
			'2gis.com'          => '/',
			'widgets.2gis.com'  => '/',
		);
		$host  = isset( $parts['host'] ) ? preg_replace( '/^www\./', '', strtolower( $parts['host'] ) ) : '';
		$path  = isset( $parts['path'] ) ? $parts['path'] : '/';

		if ( ! isset( $parts['scheme'] ) || 'https' !== $parts['scheme'] || ! isset( $hosts[ $host ] ) || ! str_starts_with( $path, $hosts[ $host ] ) ) {
			return '';
		}

		return esc_url_raw( $value );
	}
}

if ( ! function_exists( 'mvweb_core_profile_map' ) ) {
	/**
	 * The map of the site profile, as the owner chose to show it.
	 *
	 * @since 0.1.0
	 *
	 * @return array{image:string,src:string} Both empty when there is no map.
	 */
	function mvweb_core_profile_map() {
		if ( 'image' === mvweb_cz_profile( 'map_mode', 'code' ) ) {
			return array(
				'image' => (string) mvweb_cz_profile( 'map_image' ),
				'src'   => '',
			);
		}

		return array(
			'image' => '',
			'src'   => mvweb_core_sanitize_map( mvweb_cz_profile( 'map' ) ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_tel' ) ) {
	/**
	 * A phone written by hand, as an address a phone can dial.
	 *
	 * @since 0.1.0
	 *
	 * @param string $phone Phone as the owner typed it.
	 *
	 * @return string
	 */
	function mvweb_core_tel( $phone ) {
		$digits = preg_replace( '/[^0-9+]/', '', (string) $phone );

		return '' === trim( (string) $digits, '+' ) ? '' : 'tel:' . $digits;
	}
}

if ( ! function_exists( 'mvweb_core_image_alt' ) ) {
	/**
	 * Alternative text of a picture that is the only content of a link.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $attachment Attachment id.
	 * @param string $fallback   Name of the linked entry.
	 *
	 * @return string
	 */
	function mvweb_core_image_alt( $attachment, $fallback ) {
		$alt = trim( wp_strip_all_tags( (string) get_post_meta( $attachment, '_wp_attachment_image_alt', true ) ) );

		return '' !== $alt ? $alt : html_entity_decode( wp_strip_all_tags( (string) $fallback ), ENT_QUOTES, 'UTF-8' );
	}
}
