<?php
/**
 * Search in the header, and which engine answers it.
 *
 * The magnifier in the header opens a row with the search field under the
 * header. The field is either the theme's own form over the WordPress search,
 * or the bar of MVweb Smart Search with its live suggestions — the owner picks
 * one in the Customizer. With the WordPress search picked, the plugin is kept
 * away from the results page as well, so the choice means what it says.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_smart_search_active' ) ) {
	/**
	 * Whether MVweb Smart Search is active.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_smart_search_active() {
		return function_exists( 'mvweb_ss_get_search_bar' ) && class_exists( 'MVweb_SS_Search' );
	}
}

if ( ! function_exists( 'mvweb_core_search_engine' ) ) {
	/**
	 * The engine that answers the site search: 'native' or 'smart'.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_search_engine() {
		if ( 'smart' === get_theme_mod( 'mvweb_search_engine', 'native' ) && mvweb_core_smart_search_active() ) {
			return 'smart';
		}

		return 'native';
	}
}

if ( ! function_exists( 'mvweb_core_search_keep_native' ) ) {
	/**
	 * Take the plugin off the search when WordPress search is picked.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_search_keep_native() {
		if ( ! mvweb_core_smart_search_active() || 'native' !== mvweb_core_search_engine() ) {
			return;
		}

		remove_action( 'template_redirect', array( 'MVweb_SS_Search', 'maybe_redirect' ), 5 );
		remove_action( 'pre_get_posts', array( 'MVweb_SS_Search', 'intercept' ), 20 );

		if ( class_exists( 'MVweb_SS_Frontend' ) ) {
			remove_filter( 'get_search_form', array( 'MVweb_SS_Frontend', 'replace_get_search_form' ), 20 );
			remove_filter( 'render_block_core/search', array( 'MVweb_SS_Frontend', 'replace_core_search' ), 10 );
		}
	}
}
add_action( 'wp_loaded', 'mvweb_core_search_keep_native', 20 );
