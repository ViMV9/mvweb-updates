<?php
/**
 * The one extra field each of the theme's post types carries.
 *
 * A team member has a role and a booking link, a video review has an address
 * to open. Both are
 * registered with register_post_meta() so the sanitizer travels with the key
 * itself: whatever writes the meta — this box, wp-cli, an importer — goes
 * through the same callback.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_register_post_type_meta' ) ) {
	/**
	 * Register the meta of the team and video review types.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_post_type_meta() {
		register_post_meta(
			'mv_person',
			'_mvweb_role',
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => 'mvweb_core_post_meta_auth',
				'show_in_rest'      => false,
			)
		);

		register_post_meta(
			'mv_person',
			'_mvweb_booking_url',
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
				'auth_callback'     => 'mvweb_core_post_meta_auth',
				'show_in_rest'      => false,
			)
		);

		register_post_meta(
			'mv_video',
			'_mvweb_video_url',
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => 'esc_url_raw',
				'auth_callback'     => 'mvweb_core_post_meta_auth',
				'show_in_rest'      => false,
			)
		);

		$more = array(
			'mv_person' => array( '_mvweb_bio' => 'sanitize_textarea_field' ),
			'mv_video'  => array(
				'_mvweb_video_duration' => 'sanitize_text_field',
				'_mvweb_video_note'     => 'sanitize_text_field',
				'_mvweb_video_text'     => 'sanitize_textarea_field',
			),
		);

		foreach ( $more as $type => $keys ) {
			foreach ( $keys as $key => $callback ) {
				register_post_meta(
					$type,
					$key,
					array(
						'type'              => 'string',
						'single'            => true,
						'default'           => '',
						'sanitize_callback' => $callback,
						'auth_callback'     => 'mvweb_core_post_meta_auth',
						'show_in_rest'      => false,
					)
				);
			}
		}
	}
}
add_action( 'init', 'mvweb_core_register_post_type_meta' );

if ( ! function_exists( 'mvweb_core_post_meta_auth' ) ) {
	/**
	 * Whether a user may write the meta of one of the theme's records.
	 *
	 * @since 0.1.0
	 *
	 * @param bool   $allowed  Current answer.
	 * @param string $meta_key Meta key.
	 * @param int    $post_id  Post the meta belongs to.
	 * @param int    $user_id  User asking.
	 *
	 * @return bool
	 */
	function mvweb_core_post_meta_auth( $allowed, $meta_key, $post_id, $user_id ) {
		return user_can( $user_id, 'edit_post', $post_id );
	}
}

if ( ! function_exists( 'mvweb_core_meta_boxes' ) ) {
	/**
	 * Add the box to both editing screens.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_meta_boxes() {
		add_meta_box(
			'mvweb-core-person',
			__( 'Role and booking', 'mvweb-core' ),
			'mvweb_core_person_box',
			'mv_person',
			'normal',
			'high'
		);

		add_meta_box(
			'mvweb-core-video',
			__( 'Video', 'mvweb-core' ),
			'mvweb_core_video_box',
			'mv_video',
			'normal',
			'high'
		);
	}
}
add_action( 'add_meta_boxes', 'mvweb_core_meta_boxes' );

if ( ! function_exists( 'mvweb_core_person_box' ) ) {
	/**
	 * The role and booking link fields.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Post being edited.
	 *
	 * @return void
	 */
	function mvweb_core_person_box( $post ) {
		wp_nonce_field( 'mvweb_meta', 'mvweb_meta_nonce' );
		?>
		<p>
			<label for="mvweb-core-role"><?php esc_html_e( 'Position or role, shown under the name.', 'mvweb-core' ); ?></label><br>
			<input class="widefat" type="text" id="mvweb-core-role" name="mvweb_role" value="<?php echo esc_attr( (string) get_post_meta( $post->ID, '_mvweb_role', true ) ); ?>">
		</p>
		<p>
			<label for="mvweb-core-booking-url"><?php esc_html_e( 'Link to book with this person. The card in the Team section shows a button to it.', 'mvweb-core' ); ?></label><br>
			<input class="widefat" type="url" id="mvweb-core-booking-url" name="mvweb_booking_url" value="<?php echo esc_url( (string) get_post_meta( $post->ID, '_mvweb_booking_url', true ) ); ?>" placeholder="https://">
		</p>
		<p>
			<label for="mvweb-core-bio"><?php esc_html_e( 'A few lines about the person. Some views of the Team section show them.', 'mvweb-core' ); ?></label><br>
			<textarea class="widefat" rows="4" id="mvweb-core-bio" name="mvweb_bio"><?php echo esc_textarea( (string) get_post_meta( $post->ID, '_mvweb_bio', true ) ); ?></textarea>
		</p>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_video_box' ) ) {
	/**
	 * The video address field.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Post being edited.
	 *
	 * @return void
	 */
	function mvweb_core_video_box( $post ) {
		wp_nonce_field( 'mvweb_meta', 'mvweb_meta_nonce' );
		?>
		<p>
			<label for="mvweb-core-video-url"><?php esc_html_e( 'Address of the video. The card opens it in a new tab.', 'mvweb-core' ); ?></label><br>
			<input class="widefat" type="url" id="mvweb-core-video-url" name="mvweb_video_url" value="<?php echo esc_url( (string) get_post_meta( $post->ID, '_mvweb_video_url', true ) ); ?>" placeholder="https://">
		</p>
		<p>
			<label for="mvweb-core-video-duration"><?php esc_html_e( 'Length, for example 2:35.', 'mvweb-core' ); ?></label><br>
			<input class="widefat" type="text" id="mvweb-core-video-duration" name="mvweb_video_duration" value="<?php echo esc_attr( (string) get_post_meta( $post->ID, '_mvweb_video_duration', true ) ); ?>">
		</p>
		<p>
			<label for="mvweb-core-video-note"><?php esc_html_e( 'Who speaks and about what, a short line under the name.', 'mvweb-core' ); ?></label><br>
			<input class="widefat" type="text" id="mvweb-core-video-note" name="mvweb_video_note" value="<?php echo esc_attr( (string) get_post_meta( $post->ID, '_mvweb_video_note', true ) ); ?>">
		</p>
		<p>
			<label for="mvweb-core-video-text"><?php esc_html_e( 'Quote from the video, if the view shows one.', 'mvweb-core' ); ?></label><br>
			<textarea class="widefat" rows="3" id="mvweb-core-video-text" name="mvweb_video_text"><?php echo esc_textarea( (string) get_post_meta( $post->ID, '_mvweb_video_text', true ) ); ?></textarea>
		</p>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_save_meta_boxes' ) ) {
	/**
	 * Store what the box submitted.
	 *
	 * @since 0.1.0
	 *
	 * @param int     $post_id Post being saved.
	 * @param WP_Post $post    Post object.
	 *
	 * @return void
	 */
	function mvweb_core_save_meta_boxes( $post_id, $post ) {
		$fields = array(
			'mv_person' => array(
				'mvweb_role'        => '_mvweb_role',
				'mvweb_booking_url' => '_mvweb_booking_url',
				'mvweb_bio'         => '_mvweb_bio',
			),
			'mv_video'  => array(
				'mvweb_video_url'      => '_mvweb_video_url',
				'mvweb_video_duration' => '_mvweb_video_duration',
				'mvweb_video_note'     => '_mvweb_video_note',
				'mvweb_video_text'     => '_mvweb_video_text',
			),
		);

		if ( ! isset( $fields[ $post->post_type ] ) ) {
			return;
		}

		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified on the next line.
		if ( ! isset( $_POST['mvweb_meta_nonce'] ) ) {
			return;
		}

		check_admin_referer( 'mvweb_meta', 'mvweb_meta_nonce' );

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		foreach ( $fields[ $post->post_type ] as $input => $key ) {
			if ( ! isset( $_POST[ $input ] ) ) {
				continue;
			}

			update_post_meta( $post_id, $key, $_POST[ $input ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- update_post_meta() unslashes and runs the callback the key is registered with.
		}
	}
}
add_action( 'save_post', 'mvweb_core_save_meta_boxes', 10, 2 );
