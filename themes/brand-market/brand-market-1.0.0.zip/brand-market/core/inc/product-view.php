<?php
/**
 * The look of the product page, of the badges and of the card button: the panel "MVweb: Product", the main specifications, the badge colours, the button beside the price.
 *
 * The names of the looks come from the theme through mvweb_core_product_views;
 * a theme that has none gets no choice. The main specifications are the rows
 * shown next to the purchase box, picked once for the whole site.
 *
 * @package MVweb_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_product_views' ) ) {
	/**
	 * The looks of the product page the theme draws.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Slug => name, the first is the default.
	 */
	function mvweb_core_product_views() {
		/**
		 * Filter the looks of the product page.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $views Slug => name.
		 */
		return (array) apply_filters( 'mvweb_core_product_views', array() );
	}
}

if ( ! function_exists( 'mvweb_core_product_view' ) ) {
	/**
	 * The look of the product page chosen in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty when the theme has no looks.
	 */
	function mvweb_core_product_view() {
		$views = mvweb_core_product_views();

		if ( empty( $views ) ) {
			return '';
		}

		$view = (string) get_theme_mod( 'mvweb_product_view', '' );

		return isset( $views[ $view ] ) ? $view : (string) array_key_first( $views );
	}
}

if ( ! function_exists( 'mvweb_core_product_panel' ) ) {
	/**
	 * The panel "MVweb: Product" after the catalogue: the look and the product page.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panel id => panel.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_product_panel( $tree ) {
		if ( ! isset( $tree['mvweb_cz_catalog']['sections']['mvweb_cz_catalog_product'] ) ) {
			return $tree;
		}

		$catalog  = $tree['mvweb_cz_catalog'];
		$sections = array();

		if ( ! empty( mvweb_core_product_views() ) ) {
			$sections['mvweb_cz_product_view'] = __( 'Look of the page', 'mvweb-core' );
		}

		$sections['mvweb_cz_catalog_product'] = $catalog['sections']['mvweb_cz_catalog_product'];
		unset( $tree['mvweb_cz_catalog']['sections']['mvweb_cz_catalog_product'] );

		$panel = array(
			'title'    => __( 'MVweb: Product', 'mvweb-core' ),
			'priority' => isset( $catalog['priority'] ) ? (int) $catalog['priority'] : 36,
			'sections' => $sections,
		);

		if ( isset( $catalog['group'] ) ) {
			$panel['group'] = $catalog['group'];
		}

		$at = array_search( 'mvweb_cz_catalog', array_keys( $tree ), true ) + 1;

		return array_slice( $tree, 0, $at, true ) + array( 'mvweb_cz_product' => $panel ) + array_slice( $tree, $at, null, true );
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_product_panel', 101 );

if ( ! function_exists( 'mvweb_core_product_view_fields' ) ) {
	/**
	 * The look of the product page, the main specifications and the badge colours.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Customizer Kit.
	 *
	 * @return void
	 */
	function mvweb_core_product_view_fields( $kit ) {
		$views  = mvweb_core_product_views();
		$fields = array();

		if ( ! empty( $views ) ) {
			$fields[] = array(
				'type'        => 'radio',
				'settings'    => 'mvweb_product_view',
				'section'     => 'mvweb_cz_product_view',
				'label'       => __( 'Price and purchase block', 'mvweb-core' ),
				'description' => __( 'How the price, the quantity and the buttons stand next to the photo. The parts and their order are set in “Product page”.', 'mvweb-core' ),
				'default'     => (string) array_key_first( $views ),
				'choices'     => $views,
			);
			$fields[] = array(
				'type'        => 'repeater',
				'settings'    => 'mvweb_product_main_specs',
				'section'     => 'mvweb_cz_product_view',
				'label'       => __( 'Main specifications', 'mvweb-core' ),
				'description' => __( 'The rows next to the purchase block, in this order. Write the name as it stands in the product. Empty: the first six of each product.', 'mvweb-core' ),
				'default'     => wp_json_encode( array() ),
				'fields'      => array(
					'name' => array(
						'type'    => 'text',
						'label'   => __( 'Name of the specification', 'mvweb-core' ),
						'choices' => array(),
					),
					'icon' => array(
						'type'    => 'select',
						'label'   => __( 'Icon', 'mvweb-core' ),
						'choices' => array( '' => __( 'No icon', 'mvweb-core' ) ) + mvweb_core_icon_choices(),
					),
				),
			);
		}

		$fields[] = array(
			'type'        => 'toggle',
			'settings'    => 'mvweb_product_back',
			'section'     => 'mvweb_cz_catalog_product',
			'label'       => __( 'Back button', 'mvweb-core' ),
			'description' => __( 'Before the breadcrumbs: returns the visitor to the page they came from, or to the category of the product.', 'mvweb-core' ),
			'default'     => true,
		);
		$fields[] = array(
			'type'        => 'radio',
			'settings'    => 'mvweb_card_buy',
			'section'     => 'mvweb_cz_catalog_archive',
			'label'       => __( 'Button on the card', 'mvweb-core' ),
			'description' => __( 'On the cards of the catalogue and of the blocks. A compact button goes under the price when the card is too narrow for both.', 'mvweb-core' ),
			'default'     => 'wide',
			'choices'     => array(
				'wide'    => __( 'Full width under the price', 'mvweb-core' ),
				'compact' => __( 'Compact, beside the price', 'mvweb-core' ),
			),
		);

		foreach ( mvweb_core_badge_kinds() as $kind => $label ) {
			$fields[] = array(
				'type'        => 'color',
				'settings'    => 'mvweb_badge_color_' . $kind,
				'section'     => 'mvweb_cz_catalog_archive',
				/* translators: %s: kind of the badge, for example Hit. */
				'label'       => sprintf( __( 'Colour of the badge “%s”', 'mvweb-core' ), $label ),
				'description' => 'sale' === $kind ? __( 'Leave empty to keep the colour of the theme. The text turns white or black by itself, whichever reads better.', 'mvweb-core' ) : '',
				'default'     => '',
			);
		}

		$kit->add_fields( $fields );
	}
}
add_action( 'mvweb_cz_register', 'mvweb_core_product_view_fields' );

if ( ! function_exists( 'mvweb_core_badge_kinds' ) ) {
	/**
	 * The kinds of the badges on the cards and the product photo.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Kind => name.
	 */
	function mvweb_core_badge_kinds() {
		return array(
			'sale'   => __( 'Discount', 'mvweb-core' ),
			'hit'    => (string) get_theme_mod( 'mvweb_badge_hit', __( 'Hit', 'mvweb-core' ) ),
			'new'    => (string) get_theme_mod( 'mvweb_badge_new', __( 'New', 'mvweb-core' ) ),
			'custom' => __( 'Own text of the product', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_print_badge_colors' ) ) {
	/**
	 * The badge colours as tokens, with a readable text colour for each.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_print_badge_colors() {
		$css = '';

		foreach ( array_keys( mvweb_core_badge_kinds() ) as $kind ) {
			$color = sanitize_hex_color( (string) get_theme_mod( 'mvweb_badge_color_' . $kind, '' ) );

			if ( $color ) {
				$css .= '--mvweb-t-badge-' . $kind . ':' . $color . ';--mvweb-t-badge-' . $kind . '-ink:' . mvweb_core_readable_ink( $color ) . ';';
			}
		}

		if ( '' !== $css ) {
			printf( "<style id='mvweb-core-badges'>:root{%s}</style>\n", $css ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from sanitized hex colours.
		}
	}
}
add_action( 'wp_head', 'mvweb_core_print_badge_colors', 11 );

if ( ! function_exists( 'mvweb_core_item_main_specs' ) ) {
	/**
	 * The main specifications of an item: the ones named in the Customizer, all of them, or its first rows.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id    Item id.
	 * @param int $limit How many first rows when the Customizer names none.
	 *
	 * @return array<int,array{label:string,value:string,icon:string}>
	 */
	function mvweb_core_item_main_specs( $id, $limit = 6 ) {
		$product = mvweb_core_wc_item( $id );
		$rows    = array();

		if ( $product ) {
			foreach ( $product->get_attributes() as $attribute ) {
				if ( ! $attribute instanceof WC_Product_Attribute || ! $attribute->get_visible() ) {
					continue;
				}

				$values = $attribute->is_taxonomy() ? wc_get_product_terms( $id, $attribute->get_name(), array( 'fields' => 'names' ) ) : $attribute->get_options();
				$value  = implode( ', ', array_filter( array_map( 'trim', array_map( 'strval', (array) $values ) ) ) );

				if ( '' !== $value ) {
					$rows[] = array(
						'label' => wc_attribute_label( $attribute->get_name(), $product ),
						'value' => $value,
					);
				}
			}
		} else {
			$rows = mvweb_core_item_specs( $id );
		}

		$picked = array();
		$icons  = mvweb_core_icon_choices();
		$wanted = json_decode( (string) get_theme_mod( 'mvweb_product_main_specs', '' ), true );

		foreach ( is_array( $wanted ) ? $wanted : array() as $want ) {
			$name = is_array( $want ) && isset( $want['name'] ) ? mb_strtolower( trim( (string) $want['name'] ) ) : '';
			$icon = is_array( $want ) && isset( $want['icon'] ) ? (string) $want['icon'] : '';

			foreach ( $rows as $row ) {
				if ( '' !== $name && mb_strtolower( trim( $row['label'] ) ) === $name ) {
					$picked[] = array(
						'label' => $row['label'],
						'value' => $row['value'],
						'icon'  => array_key_exists( $icon, $icons ) ? $icon : '',
					);
					break;
				}
			}
		}

		if ( ! empty( $picked ) ) {
			return $picked;
		}

		foreach ( array_slice( $rows, 0, max( 1, (int) $limit ) ) as $row ) {
			$picked[] = array(
				'label' => (string) $row['label'],
				'value' => (string) $row['value'],
				'icon'  => '',
			);
		}

		return $picked;
	}
}
