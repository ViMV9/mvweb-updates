<?php
/**
 * Entrance animation of the blocks.
 *
 * The core decides whether blocks animate and when the script runs; which
 * effect a block plays and how it looks is the theme's: it prints data-motion
 * on the block and data-rv on what moves, and draws the states in its CSS.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_motion_enabled' ) ) {
	/**
	 * Whether the site animates its blocks.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_motion_enabled() {
		return (bool) get_theme_mod( 'mvweb_motion', true );
	}
}

if ( ! function_exists( 'mvweb_core_motion' ) ) {
	/**
	 * The effect a block plays, or nothing when the block stands still.
	 *
	 * @since 0.1.0
	 *
	 * @param array  $props  Values of the block.
	 * @param string $effect The effect of the chosen view.
	 *
	 * @return string Empty when the site or the block turns animation off.
	 */
	function mvweb_core_motion( array $props, $effect ) {
		if ( ! mvweb_core_motion_enabled() || ( isset( $props['motion'] ) && 'none' === $props['motion'] ) ) {
			return '';
		}

		return sanitize_key( $effect );
	}
}

if ( ! function_exists( 'mvweb_core_motion_active' ) ) {
	/**
	 * Whether this request loads the animation script.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_motion_active() {
		return mvweb_core_motion_enabled() && function_exists( 'mvweb_core_request_section_types' ) && (bool) mvweb_core_request_section_types();
	}
}

if ( ! function_exists( 'mvweb_core_motion_ready' ) ) {
	/**
	 * Tell the stylesheet that the script will run, before the first paint.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_motion_ready() {
		if ( mvweb_core_motion_active() ) {
			wp_print_inline_script_tag( 'document.documentElement.setAttribute("data-motion-ready","");' );
		}
	}
}
add_action( 'wp_head', 'mvweb_core_motion_ready', 1 );

if ( ! function_exists( 'mvweb_core_motion_fields' ) ) {
	/**
	 * The site-wide switch of the animation.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_motion_fields() {
		return array(
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_motion',
				'section'     => 'mvweb_cz_design_preset',
				'label'       => __( 'Animate the blocks', 'mvweb-core' ),
				'description' => __( 'Blocks appear as the visitor scrolls to them. Off shows everything at once. Visitors who ask their system for less motion never see it.', 'mvweb-core' ),
				'default'     => true,
			),
		);
	}
}
