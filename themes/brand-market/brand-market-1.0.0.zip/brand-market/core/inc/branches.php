<?php
/**
 * Branches and cities.
 *
 * A business with several places lists them in the Customizer, one row for each:
 * its city, address, phones with captions, opening hours, map. The cities the visitor can choose
 * from are the cities of the branches; the choice lives in a cookie, so the
 * server prints the contacts of the chosen city at once. Without branches every
 * contact comes from the profile of the site.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_branch_row_fields' ) ) {
	/**
	 * The fields of one branch in the Customizer list.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_branch_row_fields() {
		return array(
			'title'     => array(
				'type'  => 'text',
				'label' => __( 'Name of the branch', 'mvweb-core' ),
			),
			'city'      => array(
				'type'  => 'text',
				'label' => __( 'City', 'mvweb-core' ),
			),
			'address'   => array(
				'type'  => 'text',
				'label' => __( 'Address, street and house without the city', 'mvweb-core' ),
			),
			'note'      => array(
				'type'  => 'text',
				'label' => __( 'How to find it: the floor, the entrance, the mall', 'mvweb-core' ),
			),
			'phones'    => array(
				'type'  => 'textarea',
				'label' => __( 'Phones: one a line, the number, a bar, a caption', 'mvweb-core' ),
			),
			'hours'     => array(
				'type'  => 'textarea',
				'label' => __( 'Opening hours: one line for a group of days, the days, a bar, the hours', 'mvweb-core' ),
			),
			'email'     => array(
				'type'              => 'text',
				'label'             => __( 'E-mail', 'mvweb-core' ),
				'sanitize_callback' => 'sanitize_email',
			),
			'image'     => array(
				'type'  => 'image',
				'label' => __( 'Photo', 'mvweb-core' ),
			),
			'map'       => array(
				'type'              => 'textarea',
				'label'             => __( 'Map: embed code or the address of the embedded map', 'mvweb-core' ),
				'sanitize_callback' => 'mvweb_core_sanitize_map',
			),
			'map_link'  => array(
				'type'  => 'url',
				'label' => __( 'Link to the map', 'mvweb-core' ),
			),
			'route_url' => array(
				'type'  => 'url',
				'label' => __( 'Link to the route', 'mvweb-core' ),
			),
			'book_url'  => array(
				'type'  => 'url',
				'label' => __( 'Link to book a visit', 'mvweb-core' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_split_lines' ) ) {
	/**
	 * Lines of a text as pairs, split at the first bar.
	 *
	 * @since 0.1.0
	 *
	 * @param string $text Lines such as «Mon-Fri | 9:00-21:00».
	 *
	 * @return array<int,array{0:string,1:string}> Left part, right part; the right one is empty without a bar.
	 */
	function mvweb_core_split_lines( $text ) {
		$pairs = array();

		foreach ( mvweb_core_text_lines( $text ) as $line ) {
			$parts   = array_map( 'trim', explode( '|', $line, 2 ) );
			$pairs[] = array( $parts[0], isset( $parts[1] ) ? $parts[1] : '' );
		}

		return $pairs;
	}
}

if ( ! function_exists( 'mvweb_core_branches' ) ) {
	/**
	 * Every branch of the Customizer list, in the order the editor set.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_branches() {
		static $branches = null;

		if ( null !== $branches ) {
			return $branches;
		}

		$branches = array();
		$rows     = json_decode( (string) get_theme_mod( 'mvweb_branches', '[]' ), true );

		foreach ( is_array( $rows ) ? array_values( $rows ) : array() as $index => $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$value = static function ( $key ) use ( $row ) {
				return isset( $row[ $key ] ) ? (string) $row[ $key ] : '';
			};
			$city  = $value( 'city' );

			$phones = array();

			foreach ( mvweb_core_split_lines( $value( 'phones' ) ) as $pair ) {
				$phones[] = array(
					'number' => $pair[0],
					'label'  => $pair[1],
					'href'   => mvweb_core_tel( $pair[0] ),
				);
			}

			$hours = array();

			foreach ( mvweb_core_split_lines( $value( 'hours' ) ) as $pair ) {
				$hours[] = array(
					'days' => '' === $pair[1] ? '' : $pair[0],
					'time' => '' === $pair[1] ? $pair[0] : $pair[1],
				);
			}

			$branches[] = array(
				'id'        => $index + 1,
				'title'     => $value( 'title' ),
				'city'      => $city,
				'key'       => mvweb_core_city_key( $city ),
				'address'   => $value( 'address' ),
				'note'      => $value( 'note' ),
				'phones'    => $phones,
				'hours'     => $hours,
				'email'     => $value( 'email' ),
				'map'       => $value( 'map' ),
				'map_link'  => $value( 'map_link' ),
				'route_url' => $value( 'route_url' ),
				'book_url'  => $value( 'book_url' ),
				'image'     => absint( $value( 'image' ) ),
			);
		}

		return $branches;
	}
}

if ( ! function_exists( 'mvweb_core_city_key' ) ) {
	/**
	 * The stable key of a city name.
	 *
	 * @since 0.1.0
	 *
	 * @param string $city City name.
	 *
	 * @return string
	 */
	function mvweb_core_city_key( $city ) {
		return '' === trim( (string) $city ) ? '' : substr( md5( mb_strtolower( trim( (string) $city ) ) ), 0, 8 );
	}
}

if ( ! function_exists( 'mvweb_core_cities' ) ) {
	/**
	 * The cities the visitor can choose from.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array{name:string,count:int}> City key => name and number of branches, in the order of the branches.
	 */
	function mvweb_core_cities() {
		$cities = array();

		foreach ( mvweb_core_branches() as $branch ) {
			if ( '' === $branch['key'] ) {
				continue;
			}

			if ( ! isset( $cities[ $branch['key'] ] ) ) {
				$cities[ $branch['key'] ] = array(
					'name'  => $branch['city'],
					'count' => 0,
				);
			}

			++$cities[ $branch['key'] ]['count'];
		}

		return $cities;
	}
}

if ( ! function_exists( 'mvweb_core_has_city_choice' ) ) {
	/**
	 * Whether the visitor has a choice of city to make.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_has_city_choice() {
		return count( mvweb_core_cities() ) > 1;
	}
}

if ( ! function_exists( 'mvweb_core_current_city' ) ) {
	/**
	 * The key of the city whose contacts this request prints.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty when there are no branches.
	 */
	function mvweb_core_current_city() {
		$cities = mvweb_core_cities();

		if ( empty( $cities ) ) {
			return '';
		}

		$chosen = isset( $_COOKIE['mvweb_city'] ) ? sanitize_key( wp_unslash( $_COOKIE['mvweb_city'] ) ) : '';

		if ( isset( $cities[ $chosen ] ) ) {
			return $chosen;
		}

		$default = (string) get_theme_mod( 'mvweb_city_default', '' );

		return isset( $cities[ $default ] ) ? $default : (string) array_key_first( $cities );
	}
}

if ( ! function_exists( 'mvweb_core_contacts' ) ) {
	/**
	 * The contacts to print: those of a city, else those of the site profile.
	 *
	 * @since 0.1.0
	 *
	 * @param string $city City key; the current city by default.
	 *
	 * @return array<string,mixed> Keys city, phones, hours, addresses, email, branches.
	 */
	function mvweb_core_contacts( $city = '' ) {
		$city     = '' === $city ? mvweb_core_current_city() : $city;
		$cities   = mvweb_core_cities();
		$branches = array_values(
			array_filter(
				mvweb_core_branches(),
				static function ( $branch ) use ( $city ) {
					return '' !== $city && $branch['key'] === $city;
				}
			)
		);

		if ( ! empty( $branches ) ) {
			$phones = array();
			$hours  = array();
			$email  = '';

			$seen = array();

			foreach ( $branches as $branch ) {
				foreach ( $branch['phones'] as $phone ) {
					if ( ! isset( $seen[ $phone['number'] ] ) ) {
						$seen[ $phone['number'] ] = true;
						$phones[]                 = $phone;
					}
				}

				$hours = empty( $hours ) ? $branch['hours'] : $hours;
				$email = '' === $email ? $branch['email'] : $email;
			}

			return array(
				'city'      => $cities[ $city ]['name'],
				'phones'    => $phones,
				'hours'     => $hours,
				'addresses' => $branches,
				'email'     => $email,
				'branches'  => $branches,
			);
		}

		$phones = array();

		foreach ( array(
			'phone'       => 'phone_label',
			'phone_extra' => 'phone_extra_label',
		) as $key => $label ) {
			$number = trim( (string) mvweb_cz_profile( $key, '' ) );

			if ( '' !== $number && ! in_array( $number, wp_list_pluck( $phones, 'number' ), true ) ) {
				$phones[] = array(
					'number' => $number,
					'label'  => trim( (string) mvweb_cz_profile( $label, '' ) ),
					'href'   => mvweb_core_tel( $number ),
				);
			}
		}

		$hours = array();

		foreach ( array( 'schedule_weekdays', 'schedule_weekend' ) as $key ) {
			$line = trim( (string) mvweb_cz_profile( $key, '' ) );

			if ( '' !== $line ) {
				$hours[] = array(
					'days' => '',
					'time' => $line,
				);
			}
		}

		if ( mvweb_cz_profile( 'schedule_round' ) ) {
			$hours = array(
				array(
					'days' => '',
					'time' => __( 'Open around the clock', 'mvweb-core' ),
				),
			);
		}

		$address = trim( (string) mvweb_cz_profile( 'address', '' ) );

		return array(
			'city'      => trim( (string) mvweb_cz_profile( 'city', '' ) ),
			'phones'    => $phones,
			'hours'     => $hours,
			'addresses' => '' === $address ? array() : array(
				array(
					'id'        => 0,
					'title'     => '',
					'city'      => trim( (string) mvweb_cz_profile( 'city', '' ) ),
					'address'   => $address,
					'note'      => '',
					'phones'    => array(),
					'hours'     => $hours,
					'email'     => '',
					'map'       => '',
					'map_link'  => '',
					'route_url' => '',
					'book_url'  => '',
					'image'     => 0,
				),
			),
			'email'     => trim( (string) mvweb_cz_profile( 'email', '' ) ),
			'branches'  => array(),
		);
	}
}

if ( ! function_exists( 'mvweb_core_city_fields' ) ) {
	/**
	 * The settings of the city choice.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_city_fields() {
		$choices = array( '' => __( 'The first city of the list', 'mvweb-core' ) );

		foreach ( mvweb_core_cities() as $key => $city ) {
			$choices[ $key ] = $city['name'];
		}

		return array(
			array(
				'type'        => 'repeater',
				'settings'    => 'mvweb_branches',
				'section'     => 'mvweb_cz_profile_branches',
				'label'       => __( 'Branches', 'mvweb-core' ),
				'description' => __( 'Only for a business with several places. Without rows every contact comes from the profile.', 'mvweb-core' ),
				'default'     => '[]',
				'row_label'   => 'title',
				'fields'      => mvweb_core_branch_row_fields(),
			),
			array(
				'type'        => 'select',
				'settings'    => 'mvweb_city_default',
				'section'     => 'mvweb_cz_profile_cities',
				'label'       => __( 'City for a new visitor', 'mvweb-core' ),
				'description' => __( 'The cities are those of the branches. The choice list appears when there are two or more.', 'mvweb-core' ),
				'default'     => '',
				'choices'     => $choices,
			),
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_city_tip',
				'section'     => 'mvweb_cz_profile_cities',
				'label'       => __( 'Ask “Is this your city?”', 'mvweb-core' ),
				'description' => __( 'A small question under the city button on the first visit. The answer is remembered for 60 days.', 'mvweb-core' ),
				'default'     => true,
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_city_tree' ) ) {
	/**
	 * Put the section of the cities into the panel of the contacts.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_city_tree( $tree ) {
		if ( isset( $tree['mvweb_cz_profile'] ) ) {
			$tree['mvweb_cz_profile']['sections']['mvweb_cz_profile_branches'] = __( 'Branches', 'mvweb-core' );
			$tree['mvweb_cz_profile']['sections']['mvweb_cz_profile_cities']   = __( 'Cities', 'mvweb-core' );
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_city_tree', 98 );
