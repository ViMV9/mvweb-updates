<?php
/**
 * The portfolio: finished works.
 *
 * A work is a record of its own rather than a page, so it can be listed,
 * filtered by kind, shown under the service it illustrates and pulled into a
 * section. Its gallery is kept under the very key a service keeps its own, so
 * the gallery of the item page shows it unchanged.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_work_label' ) ) {
	/**
	 * The name of the portfolio in menus and headings.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_work_label() {
		$label = trim( (string) mvweb_core_option( 'mvweb_work_label' ) );

		return '' !== $label ? $label : __( 'Our works', 'mvweb-core' );
	}
}

if ( ! function_exists( 'mvweb_core_register_works' ) ) {
	/**
	 * Register the work type and its kinds.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_works() {
		$name = mvweb_core_work_label();
		$base = sanitize_title( (string) mvweb_core_option( 'mvweb_work_slug' ) );
		$base = '' === $base ? 'works' : $base;

		register_taxonomy(
			'mv_work_type',
			'mv_work',
			array(
				'labels'            => array(
					'name'          => __( 'Kinds of work', 'mvweb-core' ),
					'singular_name' => __( 'Kind of work', 'mvweb-core' ),
					'add_new_item'  => __( 'Add kind', 'mvweb-core' ),
					'edit_item'     => __( 'Edit kind', 'mvweb-core' ),
					'search_items'  => __( 'Search kinds', 'mvweb-core' ),
					'not_found'     => __( 'No kinds yet', 'mvweb-core' ),
					'menu_name'     => __( 'Kinds', 'mvweb-core' ),
				),
				'hierarchical'      => true,
				'public'            => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'rewrite'           => array(
					'slug'         => $base,
					'with_front'   => false,
					'hierarchical' => true,
				),
			)
		);

		register_post_type(
			'mv_work',
			array(
				'labels'        => array(
					'name'               => $name,
					'singular_name'      => __( 'Work', 'mvweb-core' ),
					'add_new_item'       => __( 'Add work', 'mvweb-core' ),
					'edit_item'          => __( 'Edit work', 'mvweb-core' ),
					'new_item'           => __( 'New work', 'mvweb-core' ),
					'view_item'          => __( 'View work', 'mvweb-core' ),
					'search_items'       => __( 'Search works', 'mvweb-core' ),
					'not_found'          => __( 'No works yet', 'mvweb-core' ),
					'not_found_in_trash' => __( 'No works in the bin', 'mvweb-core' ),
					'all_items'          => $name,
					'menu_name'          => $name,
					'featured_image'     => __( 'Main picture', 'mvweb-core' ),
				),
				'description'   => __( 'Finished jobs: photos, figures, the task and the result.', 'mvweb-core' ),
				'public'        => true,
				'show_in_rest'  => true,
				'has_archive'   => $base,
				'rewrite'       => array(
					'slug'       => $base . '/%mv_work_type%',
					'with_front' => false,
				),
				'menu_icon'     => 'dashicons-format-gallery',
				'menu_position' => 25,
				'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
			)
		);
	}
}
add_action( 'init', 'mvweb_core_register_works' );

if ( ! function_exists( 'mvweb_core_work_meta' ) ) {
	/**
	 * The meta keys of a work and how each is cleaned.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Key => sanitizer.
	 */
	function mvweb_core_work_meta() {
		return array(
			'_mvweb_gallery'       => 'mvweb_core_sanitize_ids',
			'_mvweb_facts'         => 'sanitize_textarea_field',
			'_mvweb_task'          => 'sanitize_textarea_field',
			'_mvweb_result'        => 'sanitize_textarea_field',
			'_mvweb_before'        => 'absint',
			'_mvweb_after'         => 'absint',
			'_mvweb_work_service'  => 'mvweb_core_sanitize_service_id',
			'_mvweb_review'        => 'sanitize_textarea_field',
			'_mvweb_review_author' => 'sanitize_text_field',
		);
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_service_id' ) ) {
	/**
	 * The id of a service, or 0 for anything else.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return int
	 */
	function mvweb_core_sanitize_service_id( $value ) {
		$id = absint( $value );

		return $id > 0 && 'mv_service' === get_post_type( $id ) ? $id : 0;
	}
}

if ( ! function_exists( 'mvweb_core_register_work_meta' ) ) {
	/**
	 * Register the meta of the work type.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_work_meta() {
		foreach ( mvweb_core_work_meta() as $key => $sanitizer ) {
			register_post_meta(
				'mv_work',
				$key,
				array(
					'type'              => 'absint' === $sanitizer || 'mvweb_core_sanitize_service_id' === $sanitizer ? 'integer' : 'string',
					'single'            => true,
					'default'           => 'absint' === $sanitizer || 'mvweb_core_sanitize_service_id' === $sanitizer ? 0 : '',
					'sanitize_callback' => $sanitizer,
					'auth_callback'     => 'mvweb_core_post_meta_auth',
					'show_in_rest'      => false,
				)
			);
		}
	}
}
add_action( 'init', 'mvweb_core_register_work_meta', 5 );

if ( ! function_exists( 'mvweb_core_work_meta_boxes' ) ) {
	/**
	 * Add the boxes to the work screen.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_work_meta_boxes() {
		add_meta_box( 'mvweb-core-work', __( 'About the work', 'mvweb-core' ), 'mvweb_core_work_box', 'mv_work', 'normal', 'high' );
		add_meta_box( 'mvweb-core-work-gallery', __( 'Gallery', 'mvweb-core' ), 'mvweb_core_service_gallery_box', 'mv_work', 'side', 'low' );
	}
}
add_action( 'add_meta_boxes', 'mvweb_core_work_meta_boxes' );

if ( ! function_exists( 'mvweb_core_work_image_field' ) ) {
	/**
	 * One picture picker of the work box.
	 *
	 * @since 0.1.0
	 *
	 * @param string $name  Input name.
	 * @param int    $id    Attachment id.
	 * @param string $label Field label.
	 *
	 * @return void
	 */
	function mvweb_core_work_image_field( $name, $id, $label ) {
		?>
		<div class="mvweb-core-field">
			<span class="mvweb-core-field__label"><?php echo esc_html( $label ); ?></span>
			<div class="mvweb-core-media" data-mvweb-core-media>
				<span class="mvweb-core-media__preview" data-mvweb-core-media-preview>
					<?php if ( wp_attachment_is_image( $id ) ) : ?>
						<img src="<?php echo esc_url( (string) wp_get_attachment_image_url( $id, 'thumbnail' ) ); ?>" alt="">
					<?php endif; ?>
				</span>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $id ? (string) $id : '' ); ?>" data-mvweb-core-media-value>
				<button type="button" class="button" data-mvweb-core-media-pick><?php esc_html_e( 'Select', 'mvweb-core' ); ?></button>
				<button type="button" class="button-link" data-mvweb-core-media-clear><?php esc_html_e( 'Remove', 'mvweb-core' ); ?></button>
			</div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_work_box' ) ) {
	/**
	 * The fields of a work.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Post being edited.
	 *
	 * @return void
	 */
	function mvweb_core_work_box( $post ) {
		wp_nonce_field( 'mvweb_work', 'mvweb_work_nonce' );

		$value = static function ( $key ) use ( $post ) {
			return (string) get_post_meta( $post->ID, $key, true );
		};

		$services = get_posts(
			array(
				'post_type'      => 'mv_service',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
				'fields'         => 'ids',
			)
		);
		?>
		<div class="mvweb-core-fields">
			<p class="mvweb-core-field">
				<label for="mvweb-core-facts"><?php esc_html_e( 'Facts', 'mvweb-core' ); ?></label>
				<textarea class="widefat" rows="4" id="mvweb-core-facts" name="mvweb_facts"><?php echo esc_textarea( $value( '_mvweb_facts' ) ); ?></textarea>
				<span class="description"><?php esc_html_e( 'One per line, caption and figure through a colon: Area: 68 m². The card shows the first three.', 'mvweb-core' ); ?></span>
			</p>

			<p class="mvweb-core-field">
				<label for="mvweb-core-task"><?php esc_html_e( 'Task', 'mvweb-core' ); ?></label>
				<textarea class="widefat" rows="3" id="mvweb-core-task" name="mvweb_task"><?php echo esc_textarea( $value( '_mvweb_task' ) ); ?></textarea>
			</p>

			<p class="mvweb-core-field">
				<label for="mvweb-core-result"><?php esc_html_e( 'Result', 'mvweb-core' ); ?></label>
				<textarea class="widefat" rows="3" id="mvweb-core-result" name="mvweb_result"><?php echo esc_textarea( $value( '_mvweb_result' ) ); ?></textarea>
			</p>

			<?php
			mvweb_core_work_image_field( 'mvweb_before', absint( $value( '_mvweb_before' ) ), __( 'Before', 'mvweb-core' ) );
			mvweb_core_work_image_field( 'mvweb_after', absint( $value( '_mvweb_after' ) ), __( 'After', 'mvweb-core' ) );
			?>
			<p class="description"><?php esc_html_e( 'Both photos together show a slider between them on the page of the work.', 'mvweb-core' ); ?></p>

			<p class="mvweb-core-field">
				<label for="mvweb-core-work-service"><?php esc_html_e( 'Service', 'mvweb-core' ); ?></label>
				<select class="widefat" id="mvweb-core-work-service" name="mvweb_work_service">
					<option value="0"><?php esc_html_e( '— None —', 'mvweb-core' ); ?></option>
					<?php foreach ( $services as $service ) : ?>
						<option value="<?php echo absint( $service ); ?>" <?php selected( absint( $value( '_mvweb_work_service' ) ), $service ); ?>><?php echo esc_html( get_the_title( $service ) ); ?></option>
					<?php endforeach; ?>
				</select>
				<span class="description"><?php esc_html_e( 'The work then shows on the page of that service, and links to it.', 'mvweb-core' ); ?></span>
			</p>

			<p class="mvweb-core-field">
				<label for="mvweb-core-review"><?php esc_html_e( 'Review of the client', 'mvweb-core' ); ?></label>
				<textarea class="widefat" rows="3" id="mvweb-core-review" name="mvweb_review"><?php echo esc_textarea( $value( '_mvweb_review' ) ); ?></textarea>
			</p>

			<p class="mvweb-core-field">
				<label for="mvweb-core-review-author"><?php esc_html_e( 'Who left it', 'mvweb-core' ); ?></label>
				<input class="widefat" type="text" id="mvweb-core-review-author" name="mvweb_review_author" value="<?php echo esc_attr( $value( '_mvweb_review_author' ) ); ?>">
			</p>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_save_work_meta' ) ) {
	/**
	 * Store what the boxes submitted.
	 *
	 * @since 0.1.0
	 *
	 * @param int     $post_id Post being saved.
	 * @param WP_Post $post    Post object.
	 *
	 * @return void
	 */
	function mvweb_core_save_work_meta( $post_id, $post ) {
		if ( 'mv_work' !== $post->post_type || wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified on the next line.
		if ( ! isset( $_POST['mvweb_work_nonce'] ) ) {
			return;
		}

		check_admin_referer( 'mvweb_work', 'mvweb_work_nonce' );

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		foreach ( array_keys( mvweb_core_work_meta() ) as $key ) {
			$input = 'mvweb_' . substr( $key, strlen( '_mvweb_' ) );

			if ( ! isset( $_POST[ $input ] ) ) {
				continue;
			}

			update_post_meta( $post_id, $key, $_POST[ $input ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- update_post_meta() unslashes and runs the callback the key is registered with.
		}
	}
}
add_action( 'save_post', 'mvweb_core_save_work_meta', 10, 2 );

if ( ! function_exists( 'mvweb_core_work_facts' ) ) {
	/**
	 * The facts of a work, parsed from their lines.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id    Work id.
	 * @param int $limit Optional. How many; 0 for all.
	 *
	 * @return array<int,array{label:string,value:string}>
	 */
	function mvweb_core_work_facts( $id, $limit = 0 ) {
		$facts = array();

		foreach ( mvweb_core_text_lines( (string) get_post_meta( $id, '_mvweb_facts', true ) ) as $line ) {
			$parts   = array_map( 'trim', explode( ':', $line, 2 ) );
			$facts[] = 2 === count( $parts )
				? array(
					'label' => $parts[0],
					'value' => $parts[1],
				)
				: array(
					'label' => '',
					'value' => $parts[0],
				);
		}

		return $limit > 0 ? array_slice( $facts, 0, $limit ) : $facts;
	}
}

if ( ! function_exists( 'mvweb_core_works' ) ) {
	/**
	 * Published works, newest by menu order first.
	 *
	 * @since 0.1.0
	 *
	 * @param array $args Optional. 'count', 'type' (term id), 'service' (id),
	 *                    'exclude' (id).
	 *
	 * @return int[]
	 */
	function mvweb_core_works( array $args = array() ) {
		static $cache = array();

		$key = md5( (string) wp_json_encode( $args ) );

		if ( isset( $cache[ $key ] ) ) {
			return $cache[ $key ];
		}

		$query = array(
			'post_type'      => 'mv_work',
			'post_status'    => 'publish',
			'posts_per_page' => isset( $args['count'] ) ? max( 1, absint( $args['count'] ) ) : 6,
			'orderby'        => array(
				'menu_order' => 'ASC',
				'date'       => 'DESC',
			),
			'fields'         => 'ids',
			'no_found_rows'  => true,
		);

		if ( ! empty( $args['type'] ) ) {
			$query['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- A handful of works on one page.
				array(
					'taxonomy' => 'mv_work_type',
					'terms'    => absint( $args['type'] ),
				),
			);
		}

		if ( ! empty( $args['service'] ) ) {
			$query['meta_key']   = '_mvweb_work_service'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Same.
			$query['meta_value'] = absint( $args['service'] ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Same.
		}

		if ( ! empty( $args['exclude'] ) ) {
			$query['post__not_in'] = array( absint( $args['exclude'] ) );
		}

		$cache[ $key ] = mvweb_core_prime_items( get_posts( $query ) );

		return $cache[ $key ];
	}
}

if ( ! function_exists( 'mvweb_core_works_per_page' ) ) {
	/**
	 * Works on one page of the portfolio.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Main query.
	 *
	 * @return void
	 */
	function mvweb_core_works_per_page( $query ) {
		if ( is_admin() || ! $query->is_main_query() || ! ( $query->is_post_type_archive( 'mv_work' ) || $query->is_tax( 'mv_work_type' ) ) ) {
			return;
		}

		$query->set( 'posts_per_page', max( 1, absint( mvweb_core_option( 'mvweb_works_per_page' ) ) ) );
		$query->set(
			'orderby',
			array(
				'menu_order' => 'ASC',
				'date'       => 'DESC',
			)
		);
	}
}
add_action( 'pre_get_posts', 'mvweb_core_works_per_page' );

if ( ! function_exists( 'mvweb_core_is_works' ) ) {
	/**
	 * Whether the request is the portfolio listing.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_is_works() {
		return is_post_type_archive( 'mv_work' ) || is_tax( 'mv_work_type' );
	}
}
