<?php
/**
 * The page builder screen.
 *
 * The whole list of sections travels in one hidden field as JSON, not as a tree
 * of name="sections[0][props][title]" inputs: the rows are reordered, added and
 * removed in the browser, and renaming every input on every move is the part of
 * that approach that breaks. If the script never runs the field still holds
 * what was saved, so a page cannot lose its sections to a JavaScript error.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_sections_meta_box' ) ) {
	/**
	 * Register the builder box.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_sections_meta_box() {
		add_meta_box(
			'mvweb-core-sections',
			__( 'Page sections', 'mvweb-core' ),
			'mvweb_core_sections_meta_box_render',
			mvweb_core_section_post_types(),
			'normal',
			'high'
		);
	}
}
add_action( 'add_meta_boxes', 'mvweb_core_sections_meta_box' );

if ( ! function_exists( 'mvweb_core_sections_meta_box_render' ) ) {
	/**
	 * Print the builder.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Page being edited.
	 *
	 * @return void
	 */
	function mvweb_core_sections_meta_box_render( $post ) {
		wp_nonce_field( 'mvweb_sections_save_' . $post->ID, 'mvweb_sections_nonce' );
		mvweb_core_sections_builder( mvweb_core_post_sections( $post->ID ), 'publish' === get_post_status( $post ) ? (string) get_permalink( $post ) : '' );
	}
}

if ( ! function_exists( 'mvweb_core_sections_builder' ) ) {
	/**
	 * Print the builder around a list of rows.
	 *
	 * @since 0.1.0
	 *
	 * @param array  $rows Saved rows.
	 * @param string $url     Address of what the rows belong to; empty hides the link.
	 * @param string $setting Customizer setting the list is linked to; empty outside the Customizer.
	 *
	 * @return void
	 */
	function mvweb_core_sections_builder( array $rows, $url, $setting = '' ) {
		?>
		<div class="mvweb-core-builder" id="mvweb-core-builder">
			<div class="mvweb-core-builder__warn" hidden>
				<span class="dashicons dashicons-warning" aria-hidden="true"></span>
				<span><?php esc_html_e( 'The page has another template, so its sections are not printed.', 'mvweb-core' ); ?></span>
				<button type="button" class="button button-small mvweb-core-builder__use-template"><?php esc_html_e( 'Switch on “Page builder”', 'mvweb-core' ); ?></button>
			</div>

			<div class="mvweb-core-builder__bar">
				<span class="mvweb-core-builder__count" aria-live="polite"></span>
				<button type="button" class="button-link mvweb-core-builder__toggle-all"></button>
				<?php if ( '' !== $url ) : ?>
					<a class="mvweb-core-builder__open" href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener"><span class="dashicons dashicons-external" aria-hidden="true"></span><?php esc_html_e( 'Open the page', 'mvweb-core' ); ?></a>
				<?php endif; ?>
			</div>

			<div class="mvweb-core-builder__list"></div>

			<p class="mvweb-core-builder__empty"><?php esc_html_e( 'No sections yet. Add the first one — pick it by its look.', 'mvweb-core' ); ?></p>

			<p class="mvweb-core-builder__notice" role="status" hidden></p>

			<div class="mvweb-core-builder__add">
				<button type="button" class="button button-primary mvweb-core-builder__add-btn"><span class="dashicons dashicons-plus-alt2" aria-hidden="true"></span><?php esc_html_e( 'Add section', 'mvweb-core' ); ?></button>
				<button type="button" class="button mvweb-core-builder__sets-btn" hidden><span class="dashicons dashicons-layout" aria-hidden="true"></span><?php esc_html_e( 'Ready-made sets', 'mvweb-core' ); ?></button>
			</div>

			<dialog class="mvweb-core-builder__sets" aria-labelledby="mvweb-core-builder-sets-title">
				<div class="mvweb-core-builder__library-head">
					<h2 id="mvweb-core-builder-sets-title"><?php esc_html_e( 'Ready-made sets', 'mvweb-core' ); ?></h2>
					<button type="button" class="button-link mvweb-core-builder__library-close" aria-label="<?php esc_attr_e( 'Close', 'mvweb-core' ); ?>"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>
				</div>
				<p class="mvweb-core-builder__sets-text"><?php esc_html_e( 'A set adds its sections after the ones already on the page. Then change the texts and pictures.', 'mvweb-core' ); ?></p>
				<div class="mvweb-core-builder__presets-list"></div>
			</dialog>

			<dialog class="mvweb-core-builder__library" aria-labelledby="mvweb-core-builder-library-title">
				<div class="mvweb-core-builder__library-head">
					<h2 id="mvweb-core-builder-library-title"><?php esc_html_e( 'Add a section', 'mvweb-core' ); ?></h2>
					<button type="button" class="button-link mvweb-core-builder__library-close" aria-label="<?php esc_attr_e( 'Close', 'mvweb-core' ); ?>"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>
				</div>
				<div class="mvweb-core-builder__library-tools">
					<label class="screen-reader-text" for="mvweb-core-builder-search"><?php esc_html_e( 'Find a section', 'mvweb-core' ); ?></label>
					<input type="search" id="mvweb-core-builder-search" class="mvweb-core-builder__search" placeholder="<?php esc_attr_e( 'Find a section: form, figures, team…', 'mvweb-core' ); ?>">
					<div class="mvweb-core-builder__chips" role="group" aria-label="<?php esc_attr_e( 'Section groups', 'mvweb-core' ); ?>"></div>
				</div>
				<div class="mvweb-core-builder__tiles"></div>
				<p class="mvweb-core-builder__nothing" hidden><?php esc_html_e( 'Nothing found.', 'mvweb-core' ); ?></p>
			</dialog>

			<textarea id="mvweb-core-builder-data" name="mvweb_sections" hidden<?php echo '' !== $setting ? ' data-customize-setting-link="' . esc_attr( $setting ) . '"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The setting id is escaped above. ?>><?php echo esc_textarea( (string) wp_json_encode( $rows ) ); ?></textarea>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_sections_meta_box_assets' ) ) {
	/**
	 * Load the builder on the page edit screen only.
	 *
	 * @since 0.1.0
	 *
	 * @param string $hook Current admin page.
	 *
	 * @return void
	 */
	function mvweb_core_sections_meta_box_assets( $hook ) {
		if ( ! mvweb_core_builder_screen( $hook ) ) {
			return;
		}

		mvweb_core_enqueue_builder();
	}
}

if ( ! function_exists( 'mvweb_core_enqueue_builder' ) ) {
	/**
	 * Load the builder scripts, styles and sprites.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_enqueue_builder() {
		wp_enqueue_media();
		wp_enqueue_editor();

		$picker = mvweb_core_asset_path( '/admin/css/icon-picker.css' );

		wp_enqueue_style( 'mvweb-core-icon-picker', MVWEB_CORE_URI . $picker, array(), mvweb_core_asset_version( $picker ) );
		add_action( 'admin_footer', 'mvweb_core_print_icon_picker_sprites' );
		add_action( 'admin_footer', 'mvweb_core_print_section_wireframes' );
		add_action( 'customize_controls_print_footer_scripts', 'mvweb_core_print_icon_picker_sprites' );
		add_action( 'customize_controls_print_footer_scripts', 'mvweb_core_print_section_wireframes' );

		$style  = mvweb_core_asset_path( '/admin/css/sections-builder.css' );
		$script = mvweb_core_asset_path( '/admin/js/sections-builder.js' );

		wp_enqueue_style(
			'mvweb-core-builder',
			MVWEB_CORE_URI . $style,
			array( 'wp-color-picker' ),
			mvweb_core_asset_version( $style )
		);

		wp_enqueue_script(
			'mvweb-core-builder',
			MVWEB_CORE_URI . $script,
			array( 'jquery-ui-sortable', 'editor', 'wp-i18n', 'wp-color-picker', 'mvweb-core-contrast' ),
			mvweb_core_asset_version( $script ),
			true
		);

		wp_add_inline_script(
			'mvweb-core-builder',
			'window.mvwebCoreBuilder = ' . wp_json_encode( mvweb_core_builder_schema() ) . ';',
			'before'
		);

		wp_set_script_translations( 'mvweb-core-builder', 'mvweb-core', MVWEB_CORE_DIR . '/languages' );
	}
}
add_action( 'admin_enqueue_scripts', 'mvweb_core_sections_meta_box_assets' );

if ( ! function_exists( 'mvweb_core_builder_schema' ) ) {
	/**
	 * What the builder needs to know about the registered types.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_builder_schema() {
		$types = array();

		foreach ( mvweb_core_editable_sections() as $type => $definition ) {
			$types[ $type ] = array(
				'label'       => $definition['label'],
				'description' => (string) $definition['description'],
				'category'    => (string) $definition['category'],
				'fields'      => array(),
			);

			if ( ! empty( $definition['global'] ) ) {
				$types[ $type ]['global'] = true;
				$types[ $type ]['note']   = __( 'The same on every page. Its content is set up in the Customizer.', 'mvweb-core' );
				$types[ $type ]['link']   = array(
					'url'   => add_query_arg(
						array(
							'autofocus[section]' => mvweb_core_home_section( $type ),
							'url'                => rawurlencode( (string) get_permalink() ),
						),
						admin_url( 'customize.php' )
					),
					'label' => __( 'Open in the Customizer', 'mvweb-core' ),
				);
				continue;
			}

			$types[ $type ]['fields'] = mvweb_core_builder_fields( $definition['fields'] );
		}

		return array(
			'types'      => $types,
			'limit'      => mvweb_core_sections_limit(),
			'template'   => 'page' === get_post_type() ? 'page-templates/builder.php' : '',
			'current'    => (string) get_page_template_slug(),
			'presets'    => mvweb_core_builder_presets( $types ),
			'categories' => array(
				'intro'   => __( 'First screen', 'mvweb-core' ),
				'about'   => __( 'About the company', 'mvweb-core' ),
				'catalog' => __( 'Catalogue and works', 'mvweb-core' ),
				'prices'  => __( 'Prices', 'mvweb-core' ),
				'trust'   => __( 'Trust', 'mvweb-core' ),
				'contact' => __( 'Request and contacts', 'mvweb-core' ),
				'other'   => __( 'Other', 'mvweb-core' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_builder_fields' ) ) {
	/**
	 * A field schema in the shape the builder reads.
	 *
	 * @since 0.1.0
	 *
	 * @param array $fields Normalized field schema.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_builder_fields( array $fields ) {
		$out = array();

		foreach ( $fields as $id => $field ) {
			$out[ $id ] = array(
				'type'         => $field['type'],
				'group'        => (string) $field['group'],
				'label'        => '' !== $field['label'] ? $field['label'] : $id,
				'description'  => 'icon' === $field['type'] ? '' : trim( $field['description'] . ' ' . $field['tooltip'] ),
				'default'      => $field['default'],
				'choices'      => mvweb_core_field_choices( $field ),
				'min'          => $field['min'],
				'max'          => $field['max'],
				'show_when'    => $field['show_when'],
				'views'        => isset( $field['views'] ) ? array_map( 'strval', (array) $field['views'] ) : array(),
				'choice_views' => isset( $field['choice_views'] ) ? array_map( 'array_values', (array) $field['choice_views'] ) : array(),
				'fields'       => 'repeat' === $field['type'] ? mvweb_core_builder_fields( $field['fields'] ) : array(),
			);
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_core_sections_save' ) ) {
	/**
	 * Store what the builder sent.
	 *
	 * @since 0.1.0
	 *
	 * @param int     $post_id Page being saved.
	 * @param WP_Post $post    Page object.
	 *
	 * @return void
	 */
	function mvweb_core_sections_save( $post_id, $post ) {
		if ( ! isset( $_POST['mvweb_sections_nonce'], $_POST['mvweb_sections'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mvweb_sections_nonce'] ) ), 'mvweb_sections_save_' . $post_id ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! in_array( $post->post_type, mvweb_core_section_post_types(), true ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$raw = json_decode( wp_unslash( $_POST['mvweb_sections'] ), true, 10 ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized by the meta key's sanitize_callback.

		update_post_meta( $post_id, '_mvweb_sections', is_array( $raw ) ? $raw : array() );
	}
}
add_action( 'save_post', 'mvweb_core_sections_save', 10, 2 );

if ( ! function_exists( 'mvweb_core_print_section_wireframes' ) ) {
	/**
	 * Print the schemes the builder draws its section types with.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_print_section_wireframes() {
		$file = MVWEB_CORE_DIR . '/admin/images/sections.svg';

		if ( is_readable( $file ) ) {
			echo file_get_contents( $file ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- The theme's own static sprite.
		}
	}
}
