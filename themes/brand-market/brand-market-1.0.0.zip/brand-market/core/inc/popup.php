<?php
/**
 * The request form in a window.
 *
 * One form for the whole site, set in "MVweb: Conversion". Any link to
 * #request opens it — the header button, a button of a section, a menu item —
 * and so does an address ending in #request that brings a visitor from another
 * page. Without a script the link simply stays an anchor.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_popup_form' ) ) {
	/**
	 * The shortcode of the form in a window, empty when there is none.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_popup_form() {
		return trim( (string) get_theme_mod( 'mvweb_popup_form', '' ) );
	}
}

if ( ! function_exists( 'mvweb_core_popup' ) ) {
	/**
	 * Print the window at the end of the page.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_popup() {
		$form = mvweb_core_popup_form();

		if ( '' === $form || is_admin() ) {
			return;
		}

		get_template_part(
			'template-parts/popup',
			null,
			array(
				'form'  => $form,
				'title' => (string) get_theme_mod( 'mvweb_popup_title', __( 'Leave a request', 'mvweb-core' ) ),
				'text'  => (string) get_theme_mod( 'mvweb_popup_text', '' ),
			)
		);
	}
}
add_action( 'wp_footer', 'mvweb_core_popup', 5 );
