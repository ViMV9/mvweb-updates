<?php
/**
 * A way to place an order that takes no payment.
 *
 * The order is a request: it goes straight to "Processing", the customer
 * sees the thank-you page with the text set here, and a manager calls back
 * to agree on the payment and the delivery.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The request gateway.
 *
 * @since 0.1.0
 */
class MVweb_Core_Request_Gateway extends WC_Payment_Gateway {

	/**
	 * Text of the thank-you page.
	 *
	 * @var string
	 */
	public $instructions = '';

	/**
	 * Set the gateway up.
	 *
	 * @since 0.1.0
	 */
	public function __construct() {
		$this->id                 = 'mvweb_request';
		$this->method_title       = __( 'Order as a request', 'mvweb-core' );
		$this->method_description = __( 'No payment on the site: the order goes to processing and a manager contacts the customer.', 'mvweb-core' );
		$this->has_fields         = false;

		$this->init_form_fields();
		$this->init_settings();

		$this->title        = (string) $this->get_option( 'title' );
		$this->description  = (string) $this->get_option( 'description' );
		$this->instructions = (string) $this->get_option( 'instructions' );

		add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );
		add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'thankyou' ) );
	}

	/**
	 * The settings of the gateway.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	public function init_form_fields() {
		$this->form_fields = array(
			'enabled'      => array(
				'title'   => __( 'Enable', 'mvweb-core' ),
				'type'    => 'checkbox',
				'label'   => __( 'Accept orders without payment', 'mvweb-core' ),
				'default' => 'no',
			),
			'title'        => array(
				'title'   => __( 'Title', 'mvweb-core' ),
				'type'    => 'text',
				'default' => __( 'No payment now', 'mvweb-core' ),
			),
			'description'  => array(
				'title'   => __( 'Description', 'mvweb-core' ),
				'type'    => 'textarea',
				'default' => __( 'A manager will contact you to agree on the payment and the delivery.', 'mvweb-core' ),
			),
			'instructions' => array(
				'title'   => __( 'Text on the thank-you page', 'mvweb-core' ),
				'type'    => 'textarea',
				'default' => __( 'Thank you! Your request has been received, a manager will contact you shortly.', 'mvweb-core' ),
			),
		);
	}

	/**
	 * Take the order without payment.
	 *
	 * @since 0.1.0
	 *
	 * @param int $order_id Order id.
	 *
	 * @return array{result:string,redirect:string}
	 */
	public function process_payment( $order_id ) {
		$order = wc_get_order( $order_id );

		$order->update_status( 'processing', __( 'Order placed as a request, no payment taken.', 'mvweb-core' ) );
		WC()->cart->empty_cart();

		return array(
			'result'   => 'success',
			'redirect' => $this->get_return_url( $order ),
		);
	}

	/**
	 * The text of the thank-you page.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	public function thankyou() {
		if ( '' !== $this->instructions ) {
			echo wp_kses_post( wpautop( wptexturize( $this->instructions ) ) );
		}
	}
}
