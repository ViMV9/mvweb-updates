<?php
/**
 * Zone engine for the header and footer.
 *
 * A zone is a strip of the page assembled from ordered, toggleable elements.
 * Each zone keeps a registry of available elements (slug => label) and the
 * saved order of the active ones in a theme_mod. The same registry feeds the
 * sortable control and the renderer, so what an owner can toggle and what can
 * actually print never drift apart.
 *
 * Element templates live in one flat folder and receive the zone as an
 * argument: the logo and the primary menu appear in more than one zone, and a
 * per-zone folder would mean keeping duplicate copies in step.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_zones' ) ) {
	/**
	 * Known zones.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Zone slug => label.
	 */
	function mvweb_core_zones() {
		$zones = array(
			'header-topbar'          => __( 'Top bar, above the header', 'mvweb-core' ),
			'header-main'            => __( 'Main row, on the left', 'mvweb-core' ),
			'header-actions'         => __( 'Main row, on the right', 'mvweb-core' ),
			'header-drawer-contacts' => __( 'Contacts at the top of the menu', 'mvweb-core' ),
			'header-drawer-nav'      => __( 'Menus under the contacts', 'mvweb-core' ),
			'footer-main'            => __( 'Columns', 'mvweb-core' ),
			'footer-bottom'          => __( 'Bottom row', 'mvweb-core' ),
		);

		/**
		 * Filter the list of zones.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $zones Zone slug => label.
		 */
		return (array) apply_filters( 'mvweb_core_zones', $zones );
	}
}

if ( ! function_exists( 'mvweb_core_zone_elements' ) ) {
	/**
	 * Available elements for a zone: slug => label.
	 *
	 * @since 0.1.0
	 *
	 * @param string $zone Zone slug.
	 *
	 * @return array<string,string> Element slug => label.
	 */
	function mvweb_core_zone_elements( $zone ) {
		$core = array(
			'header-topbar'          => array(
				'menu-top' => __( 'Secondary menu', 'mvweb-core' ),
				'scheme'   => __( 'Colour scheme switch', 'mvweb-core' ),
			),
			'header-main'            => array(
				'logo'         => __( 'Logo', 'mvweb-core' ),
				'menu-primary' => __( 'Primary menu', 'mvweb-core' ),
				'search-form'  => __( 'Search field', 'mvweb-core' ),
			),
			'header-actions'         => array(
				'favorites'  => __( 'Favourites', 'mvweb-core' ),
				'search'     => __( 'Search', 'mvweb-core' ),
				'cta'        => __( 'Action button', 'mvweb-core' ),
				'phone'      => __( 'Phone', 'mvweb-core' ),
				'schedule'   => __( 'Opening hours', 'mvweb-core' ),
				'messengers' => __( 'Messengers', 'mvweb-core' ),
				'cart'       => __( 'Cart', 'mvweb-core' ),
				'burger'     => __( 'Mobile menu button', 'mvweb-core' ),
			),
			'header-drawer-contacts' => array(
				'phone'      => __( 'Phone', 'mvweb-core' ),
				'schedule'   => __( 'Opening hours', 'mvweb-core' ),
				'address'    => __( 'Address', 'mvweb-core' ),
				'email'      => __( 'Email', 'mvweb-core' ),
				'messengers' => __( 'Messengers', 'mvweb-core' ),
				'cta'        => __( 'Action button', 'mvweb-core' ),
			),
			'header-drawer-nav'      => array(
				'menu-primary' => __( 'Primary menu', 'mvweb-core' ),
				'menu-top'     => __( 'Secondary menu', 'mvweb-core' ),
			),
			'footer-main'            => array(
				'brand'    => __( 'Logo and tagline', 'mvweb-core' ),
				'menu'     => __( 'First menu column', 'mvweb-core' ),
				'menu-2'   => __( 'Second menu column', 'mvweb-core' ),
				'contacts' => __( 'Contacts', 'mvweb-core' ),
			),
			'footer-bottom'          => array(
				'copyright'  => __( 'Copyright', 'mvweb-core' ),
				'requisites' => __( 'Company details', 'mvweb-core' ),
				'legal'      => __( 'Legal links', 'mvweb-core' ),
				'dev-badge'  => __( 'Studio badge', 'mvweb-core' ),
			),
		);

		$elements = isset( $core[ $zone ] ) ? $core[ $zone ] : array();

		/**
		 * Filter the elements available in a zone.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $elements Element slug => label.
		 * @param string               $zone     Zone slug.
		 */
		return (array) apply_filters( 'mvweb_core_zone_elements', $elements, $zone );
	}
}

if ( ! function_exists( 'mvweb_core_zone_setting' ) ) {
	/**
	 * The theme_mod key that stores a zone's order.
	 *
	 * @since 0.1.0
	 *
	 * @param string $zone Zone slug.
	 *
	 * @return string
	 */
	function mvweb_core_zone_setting( $zone ) {
		return 'mvweb_zone_' . str_replace( '-', '_', sanitize_key( $zone ) );
	}
}

if ( ! function_exists( 'mvweb_core_zone_default_order' ) ) {
	/**
	 * Default order for a zone: every available element, in registry order.
	 *
	 * @since 0.1.0
	 *
	 * @param string $zone Zone slug.
	 *
	 * @return string[]
	 */
	function mvweb_core_zone_default_order( $zone ) {
		/**
		 * Filters the default order of a zone.
		 *
		 * @since 0.1.0
		 *
		 * @param string[] $order Element slugs; every element of the zone by default.
		 * @param string   $zone  Zone slug.
		 */
		return (array) apply_filters( 'mvweb_core_zone_default_order', array_keys( mvweb_core_zone_elements( $zone ) ), $zone );
	}
}

if ( ! function_exists( 'mvweb_core_zone_order' ) ) {
	/**
	 * Active, ordered element slugs for a zone.
	 *
	 * @since 0.1.0
	 *
	 * @param string $zone Zone slug.
	 *
	 * @return string[]
	 */
	function mvweb_core_zone_order( $zone ) {
		static $resolved = array();

		if ( isset( $resolved[ $zone ] ) ) {
			return $resolved[ $zone ];
		}

		$available = mvweb_core_zone_elements( $zone );

		if ( empty( $available ) ) {
			return array();
		}

		$saved = get_theme_mod( mvweb_core_zone_setting( $zone ), '' );
		$order = json_decode( (string) $saved, true );

		if ( ! is_array( $order ) ) {
			$order = mvweb_core_zone_default_order( $zone );
		}

		if ( 'both' !== mvweb_core_scheme_mode() ) {
			unset( $available['scheme'] );
		}

		$resolved[ $zone ] = array_values(
			array_filter(
				$order,
				static function ( $slug ) use ( $available ) {
					return is_string( $slug ) && isset( $available[ $slug ] );
				}
			)
		);

		return $resolved[ $zone ];
	}
}

if ( ! function_exists( 'mvweb_core_render_zone' ) ) {
	/**
	 * Render a zone by walking its active order.
	 *
	 * @since 0.1.0
	 *
	 * @param string $zone Zone slug.
	 * @param array  $args Extra arguments passed to each element template.
	 *
	 * @return void
	 */
	function mvweb_core_render_zone( $zone, array $args = array() ) {
		if ( ! isset( mvweb_core_zones()[ $zone ] ) ) {
			return;
		}

		$args['zone']    = $zone;
		$args['context'] = str_starts_with( $zone, 'header-drawer' ) ? 'drawer' : 'bar';

		foreach ( mvweb_core_zone_order( $zone ) as $slug ) {
			/**
			 * Short-circuit the render of one element.
			 *
			 * @since 0.1.0
			 *
			 * @param bool   $handled Whether the element has been rendered already.
			 * @param string $zone    Zone slug.
			 * @param string $slug    Element slug.
			 * @param array  $args    Render arguments.
			 */
			if ( true === apply_filters( 'mvweb_core_render_element', false, $zone, $slug, $args ) ) {
				continue;
			}

			$safe_slug = sanitize_key( $slug );

			if ( 0 !== validate_file( $safe_slug ) ) {
				continue;
			}

			get_template_part( 'template-parts/elements/' . $safe_slug, null, $args );
		}
	}
}

if ( ! function_exists( 'mvweb_core_zone_has' ) ) {
	/**
	 * Whether a zone currently renders a given element.
	 *
	 * @since 0.1.0
	 *
	 * @param string $zone Zone slug.
	 * @param string $slug Element slug.
	 *
	 * @return bool
	 */
	function mvweb_core_zone_has( $zone, $slug ) {
		return in_array( $slug, mvweb_core_zone_order( $zone ), true );
	}
}
