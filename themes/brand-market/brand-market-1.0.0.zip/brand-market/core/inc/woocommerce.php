<?php
/**
 * WooCommerce integration.
 *
 * What the catalogue asks for — cards, prices, galleries, filters — is answered
 * in inc/catalog.php, which speaks to whichever source the site has. This file
 * is only the WooCommerce side of that: the hooks to take off, the fields to
 * add to a product, and the two lists the plugin builds itself.
 *
 * The catalog templates in woocommerce/ print their own markup, so the default
 * loop callbacks are taken off their hooks — but the hooks themselves keep
 * firing, which is what plugins that decorate a product card hang on.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_woocommerce_setup' ) ) {
	/**
	 * Declare support for the store.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_woocommerce_setup() {
		add_theme_support( 'woocommerce' );
	}
}
add_action( 'after_setup_theme', 'mvweb_core_woocommerce_setup' );

if ( ! function_exists( 'mvweb_core_second_price_field' ) ) {
	/**
	 * The second price field, next to the regular one.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_second_price_field() {
		woocommerce_wp_text_input(
			array(
				'id'          => '_mvweb_second_price',
				'value'       => (string) get_post_meta( get_the_ID(), '_mvweb_second_price', true ),
				/* translators: %s: currency symbol. */
				'label'       => sprintf( __( 'Second price (%s)', 'mvweb-core' ), get_woocommerce_currency_symbol() ),
				'description' => __( 'Second price on the card. Leave empty to print one price only.', 'mvweb-core' ),
				'desc_tip'    => true,
				'data_type'   => 'price',
			)
		);
	}
}
add_action( 'woocommerce_product_options_pricing', 'mvweb_core_second_price_field' );

if ( ! function_exists( 'mvweb_core_second_price_save' ) ) {
	/**
	 * Store the second price.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Product id.
	 *
	 * @return void
	 */
	function mvweb_core_second_price_save( $post_id ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified in WC_Admin_Meta_Boxes::save_meta_boxes() before this hook fires.
		$raw = isset( $_POST['_mvweb_second_price'] ) ? sanitize_text_field( wp_unslash( $_POST['_mvweb_second_price'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$raw = wc_format_decimal( $raw );

		$product = wc_get_product( $post_id );

		if ( ! $product ) {
			return;
		}

		$product->update_meta_data( '_mvweb_second_price', '' === $raw ? '' : $raw );
		$product->save_meta_data();
	}
}
add_action( 'woocommerce_process_product_meta', 'mvweb_core_second_price_save' );

if ( ! function_exists( 'mvweb_core_file_field' ) ) {
	/**
	 * Address of a file offered on the product page.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_file_field() {
		woocommerce_wp_text_input(
			array(
				'id'          => '_mvweb_file_url',
				'label'       => __( 'File link', 'mvweb-core' ),
				'description' => __( 'A model, a datasheet, a manual. The label of the link is set in the Customizer.', 'mvweb-core' ),
				'desc_tip'    => true,
				'type'        => 'url',
			)
		);
	}
}
add_action( 'woocommerce_product_options_advanced', 'mvweb_core_file_field' );

if ( ! function_exists( 'mvweb_core_file_save' ) ) {
	/**
	 * Store the file address.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Product id.
	 *
	 * @return void
	 */
	function mvweb_core_file_save( $post_id ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified in WC_Admin_Meta_Boxes::save_meta_boxes() before this hook fires.
		$raw = isset( $_POST['_mvweb_file_url'] ) ? sanitize_text_field( wp_unslash( $_POST['_mvweb_file_url'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$product = wc_get_product( $post_id );

		if ( ! $product ) {
			return;
		}

		$product->update_meta_data( '_mvweb_file_url', esc_url_raw( $raw ) );
		$product->save_meta_data();
	}
}
add_action( 'woocommerce_process_product_meta', 'mvweb_core_file_save' );

if ( ! function_exists( 'mvweb_core_brand_attribute' ) ) {
	/**
	 * Put the brand into the specifications table.
	 *
	 * @since 0.1.0
	 *
	 * @param array      $attributes Prepared rows.
	 * @param WC_Product $product    Product.
	 *
	 * @return array
	 */
	function mvweb_core_brand_attribute( $attributes, $product ) {
		$brand = mvweb_core_item_brand( $product->get_id() );

		if ( '' === $brand ) {
			return $attributes;
		}

		return array_merge(
			array(
				'mvweb_brand' => array(
					'label' => __( 'Brand', 'mvweb-core' ),
					'value' => esc_html( $brand ),
				),
			),
			$attributes
		);
	}
}
add_filter( 'woocommerce_display_product_attributes', 'mvweb_core_brand_attribute', 10, 2 );

if ( ! function_exists( 'mvweb_core_wc_subcategory_query' ) ) {
	/**
	 * Narrow the store listing by the subcategories ticked in the sidebar.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Product query.
	 *
	 * @return void
	 */
	function mvweb_core_wc_subcategory_query( $query ) {
		$clause = mvweb_core_subcategory_tax_query();

		if ( null === $clause ) {
			return;
		}

		$tax_query   = (array) $query->get( 'tax_query', array() );
		$tax_query[] = $clause;

		$query->set( 'tax_query', $tax_query ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- A catalogue filter is exactly what a taxonomy query is for.
	}
}
add_action( 'woocommerce_product_query', 'mvweb_core_wc_subcategory_query' );
