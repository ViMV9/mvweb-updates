<?php
/**
 * The request gateway in the block checkout.
 *
 * The block checkout lists only the ways to pay that register themselves with
 * WooCommerce Blocks; a classic gateway alone does not show there.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Automattic\WooCommerce\Blocks\Payments\Integrations\AbstractPaymentMethodType;

/**
 * Block checkout integration of the request gateway.
 *
 * @since 0.1.0
 */
final class MVweb_Core_Request_Blocks extends AbstractPaymentMethodType {

	/**
	 * Gateway id.
	 *
	 * @var string
	 */
	protected $name = 'mvweb_request';

	/**
	 * Read the gateway settings.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	public function initialize() {
		$this->settings = (array) get_option( 'woocommerce_mvweb_request_settings', array() );
	}

	/**
	 * Whether the gateway is switched on.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	public function is_active() {
		return 'yes' === $this->get_setting( 'enabled', 'no' );
	}

	/**
	 * The script that adds the gateway to the checkout.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	public function get_payment_method_script_handles() {
		$script = mvweb_core_asset_path( '/assets/js/request-blocks.js' );

		wp_register_script(
			'mvweb-core-request-blocks',
			MVWEB_CORE_URI . $script,
			array( 'wc-blocks-registry', 'wc-settings', 'wp-element', 'wp-html-entities' ),
			mvweb_core_asset_version( $script ),
			true
		);

		return array( 'mvweb-core-request-blocks' );
	}

	/**
	 * What the script needs: the name and the description the customer sees.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	public function get_payment_method_data() {
		$gateway = WC()->payment_gateways() ? ( WC()->payment_gateways()->payment_gateways()[ $this->name ] ?? null ) : null;

		return array(
			'title'       => $gateway ? $gateway->get_title() : (string) $this->get_setting( 'title' ),
			'description' => $gateway ? $gateway->get_description() : (string) $this->get_setting( 'description' ),
			'supports'    => $gateway ? array_values( array_filter( $gateway->supports, array( $gateway, 'supports' ) ) ) : array( 'products' ),
		);
	}
}
