<?php
/**
 * Asset enqueue.
 *
 * The stylesheet is split by area, and a template only pays for what it shows.
 * mvweb_core_style_map() is the single place that says which template needs
 * which file; template files never enqueue anything themselves.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_asset_version' ) ) {
	/**
	 * Cache-busting version for a theme asset.
	 *
	 * @since 0.1.0
	 *
	 * @param string $relative Path relative to the theme root, with a leading slash.
	 *
	 * @return string
	 */
	function mvweb_core_asset_version( $relative ) {
		$path = MVWEB_CORE_DIR . $relative;

		$time = file_exists( $path ) ? filemtime( $path ) : false;

		return false !== $time ? (string) $time : MVWEB_CORE_VERSION;
	}
}

if ( ! function_exists( 'mvweb_core_asset_path' ) ) {
	/**
	 * The built copy of an asset, or the source when it has not been built.
	 *
	 * @since 0.1.0
	 *
	 * @param string $relative Source path relative to the theme root, with a leading slash.
	 *
	 * @return string
	 */
	function mvweb_core_asset_path( $relative ) {
		$extension = '.' . pathinfo( $relative, PATHINFO_EXTENSION );
		$minified  = substr( $relative, 0, - strlen( $extension ) ) . '.min' . $extension;

		return file_exists( MVWEB_CORE_DIR . $minified ) ? $minified : $relative;
	}
}

if ( ! function_exists( 'mvweb_core_style_handle' ) ) {
	/**
	 * Registered handle for a stylesheet of the map.
	 *
	 * @since 0.1.0
	 *
	 * @param string $handle Map key, without the theme prefix.
	 *
	 * @return string
	 */
	function mvweb_core_style_handle( $handle ) {
		return 'mvweb-core-' . str_replace( '/', '-', $handle );
	}
}

if ( ! function_exists( 'mvweb_core_section_assets' ) ) {
	/**
	 * Assets belonging to the section types this request prints.
	 *
	 * @since 0.1.0
	 *
	 * @param string $extension Either css or js.
	 *
	 * @return string[] Map keys, without the theme prefix.
	 */
	function mvweb_core_section_assets( $extension ) {
		$found = array();

		foreach ( mvweb_core_request_section_types() as $type ) {
			$relative = '/assets/' . $extension . '/sections/' . $type . '.';

			if ( file_exists( MVWEB_CORE_DIR . $relative . $extension )
				|| file_exists( MVWEB_CORE_DIR . $relative . 'min.' . $extension ) ) {
				$found[] = 'sections/' . $type;
			}
		}

		return $found;
	}
}

if ( ! function_exists( 'mvweb_core_style_map' ) ) {
	/**
	 * Stylesheets this request needs, in cascade order.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_style_map() {
		$styles   = array( 'fonts', 'tokens', 'base', 'header', 'footer' );
		$catalog  = mvweb_core_is_catalog();
		$product  = mvweb_core_is_product();
		$services = mvweb_core_is_services();
		$service  = mvweb_core_is_service();

		$assembled = is_front_page()
			&& ! empty( mvweb_core_request_sections() );

		if ( is_singular() && ! $product ) {
			$styles[] = 'crumbs';
			$styles[] = 'article';
		}

		if ( is_singular( 'post' ) && comments_open( get_queried_object_id() ) ) {
			$styles[] = 'form';
		}

		if ( is_singular() && ! is_singular( array( 'post', 'mv_work' ) ) && ! $product && ! $service ) {
			$styles[] = 'page-hero';
		}

		if ( $product ) {
			$styles[] = 'crumbs';
			$styles[] = 'form';
			$styles[] = 'article';
			$styles[] = 'product';

			if ( absint( mvweb_core_option( 'mvweb_related_count' ) ) > 0 ) {
				$styles[] = 'catalog';
			}
		}

		if ( $service ) {
			$styles[] = 'form';
			$styles[] = 'product';
			$styles[] = 'service';
		}

		if ( ! $assembled && ( is_home() || is_archive() || is_search() || is_404() ) ) {
			$styles[] = 'page-hero';
			$styles[] = 'crumbs';
			$styles[] = 'pagination';

			if ( ! $catalog && ! $services ) {
				$styles[] = 'blog';
			}
		}

		if ( $catalog ) {
			$styles[] = 'form';
			$styles[] = 'catalog';
			$styles[] = 'empty';
		}

		if ( $services ) {
			$styles[] = 'catalog';
			$styles[] = 'empty';
			$styles[] = 'service';
		}

		if ( mvweb_core_share_here() ) {
			$styles[] = 'share';
		}

		if ( ( $catalog || $services ) && ( '' !== mvweb_core_listing_intro() || '' !== mvweb_core_listing_text() ) ) {
			$styles[] = 'article';
		}

		if ( ( mvweb_core_favorites_page_id() && is_page( mvweb_core_favorites_page_id() ) ) ) {
			$styles[] = 'catalog';
			$styles[] = 'empty';
		}

		if ( is_search() || is_404() ) {
			$styles[] = 'empty';
			$styles[] = 'form';
		}

		$printed = mvweb_core_request_section_types();

		if ( array_intersect( array( 'contact-form', 'products', 'embed' ), $printed ) ) {
			$styles[] = 'form';
		}

		if ( array_intersect( array( 'products', 'project' ), $printed ) ) {
			$styles[] = 'gallery';
		}

		$works_band = in_array( 'works', $printed, true )
			|| ( $service && mvweb_core_works(
				array(
					'count'   => 3,
					'service' => get_queried_object_id(),
				)
			) );

		if ( mvweb_core_is_works() ) {
			array_push( $styles, 'page-hero', 'crumbs', 'pagination', 'catalog', 'empty', 'works' );
		}

		if ( is_singular( 'mv_work' ) ) {
			array_push( $styles, 'product', 'service', 'catalog', 'works', 'sections/before-after' );
		}

		if ( $works_band ) {
			array_push( $styles, 'catalog', 'works' );
		}

		if ( in_array( 'posts', $printed, true ) ) {
			$styles[] = 'blog';
		}

		$popup = '' !== mvweb_core_popup_form();

		if ( $popup ) {
			$styles[] = 'form';
		}

		if ( $popup || in_array( 'products', $printed, true ) ) {
			$styles[] = 'modal';
		}

		foreach ( mvweb_core_request_section_types() as $mvweb_core_type ) {
			$handle   = 'sections/' . $mvweb_core_type;
			$styles[] = $handle;
		}

		/**
		 * Filter the stylesheets enqueued for the current request.
		 *
		 * @since 0.1.0
		 *
		 * @param string[] $styles Handles without the theme prefix.
		 */
		return array_values( array_unique( (array) apply_filters( 'mvweb_core_style_map', $styles ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_enqueue_assets' ) ) {
	/**
	 * Enqueue front-end styles and script modules.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_enqueue_assets() {
		$modules = array( 'header', 'totop', 'scrollers' );

		if ( 'both' === mvweb_core_scheme_mode() ) {
			$modules[] = 'scheme';
		}

		if ( ( is_singular() && ! mvweb_core_is_product() ) || '' !== mvweb_core_listing_intro() || '' !== mvweb_core_listing_text() ) {
			$modules[] = 'prose-tables';
		}

		if ( mvweb_core_is_catalog() ) {
			$modules[] = 'filters';

			if ( mvweb_core_catalog_view_switch() ) {
				$modules[] = 'catalog-view';
			}
		}

		if ( mvweb_core_is_product() || mvweb_core_is_service() || is_singular( 'mv_work' ) ) {
			$modules[] = 'product-gallery';
		}

		if ( is_singular( 'mv_work' ) ) {
			$modules[] = 'showcase';
			$modules[] = 'sections/before-after';
		}

		if ( mvweb_core_favorites_url() ) {
			$modules[] = 'favorites';
		}

		if ( mvweb_core_motion_active() ) {
			$modules[] = 'motion';
		}

		if ( mvweb_core_has_city_choice() ) {
			$modules[] = 'city';
		}

		if ( array_intersect( array( 'video-reviews', 'products', 'project', 'reviews', 'before-after' ), mvweb_core_request_section_types() ) ) {
			$modules[] = 'showcase';
		}

		if ( '' !== mvweb_core_popup_form() ) {
			$modules[] = 'popup';
		}

		foreach ( mvweb_core_section_assets( 'js' ) as $module ) {
			$modules[] = $module;
		}

		/**
		 * Filter the script modules enqueued for the current request.
		 *
		 * @since 0.1.0
		 *
		 * @param string[] $modules File names without extension, from assets/js/.
		 */
		$modules = array_values( array_unique( (array) apply_filters( 'mvweb_core_module_map', $modules ) ) );

		foreach ( $modules as $module ) {
			$relative = mvweb_core_asset_path( '/assets/js/' . $module . '.js' );

			wp_enqueue_script_module(
				'@mvweb-core/' . $module,
				MVWEB_CORE_URI . $relative,
				array(),
				mvweb_core_asset_version( $relative )
			);
		}
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_core_enqueue_assets' );

if ( ! function_exists( 'mvweb_core_prose_tables_data' ) ) {
	/**
	 * Strings the prose-tables module needs.
	 *
	 * @since 0.1.0
	 *
	 * @param array $data Existing data.
	 *
	 * @return array
	 */
	function mvweb_core_prose_tables_data( $data ) {
		$data['scrollLabel'] = __( 'Table, scrolls sideways', 'mvweb-core' );

		return $data;
	}
}
add_filter( 'script_module_data_@mvweb-core/prose-tables', 'mvweb_core_prose_tables_data' );

if ( ! function_exists( 'mvweb_core_showcase_data' ) ) {
	/**
	 * Strings the card scroller needs.
	 *
	 * @since 0.1.0
	 *
	 * @param array $data Existing data.
	 *
	 * @return array
	 */
	function mvweb_core_showcase_data( $data ) {
		$data['frame'] = __( 'Frame', 'mvweb-core' );

		return $data;
	}
}
add_filter( 'script_module_data_@mvweb-core/showcase', 'mvweb_core_showcase_data' );

if ( ! function_exists( 'mvweb_core_scheme_data' ) ) {
	/**
	 * Strings the scheme switch needs.
	 *
	 * @since 0.1.0
	 *
	 * @param array $data Existing data.
	 *
	 * @return array
	 */
	function mvweb_core_scheme_data( $data ) {
		$data['toDark']  = __( 'Switch to the dark scheme', 'mvweb-core' );
		$data['toLight'] = __( 'Switch to the light scheme', 'mvweb-core' );
		$data['dark']    = __( 'Dark scheme', 'mvweb-core' );
		$data['light']   = __( 'Light scheme', 'mvweb-core' );

		return $data;
	}
}
add_filter( 'script_module_data_@mvweb-core/scheme', 'mvweb_core_scheme_data' );

if ( ! function_exists( 'mvweb_core_print_scheme_bootstrap' ) ) {
	/**
	 * Apply the visitor's colour scheme before the first paint.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_print_scheme_bootstrap() {
		if ( 'both' !== mvweb_core_scheme_mode() ) {
			return;
		}
		?>
<script>document.documentElement.dataset.scheme=(document.cookie.match(/(?:^|; )mvweb_scheme=(light|dark)/)||[,<?php echo wp_json_encode( mvweb_core_default_scheme() ); ?>])[1];</script>
		<?php
	}
}
add_action( 'wp_head', 'mvweb_core_print_scheme_bootstrap', 0 );
