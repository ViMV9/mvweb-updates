<?php
/**
 * The look of the elements: colours of both schemes, buttons, links, fields and chips.
 *
 * Every field starts empty or at "as the site", so a site that sets nothing
 * looks as the theme drew it. A colour of the light scheme is printed for
 * both schemes when it is a brand colour (accent, button, announcement) and
 * for the light scheme only when it is a surface (menu, footer, field): the
 * dark scheme keeps its own surfaces until the owner sets them. An empty
 * colour of the dark scheme is derived from the light one: links and hovers
 * get lighter until they read on the dark background, text on a coloured
 * background turns black or white.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_element_colors' ) ) {
	/**
	 * The colour groups: group => title and items; an item is setting, token, kind, label, description.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array{title:string,items:array<int,array{0:string,1:string,2:string,3:string,4:string}>}>
	 */
	function mvweb_core_element_colors() {
		return array(
			'accent' => array(
				'title' => __( 'Accent', 'mvweb-core' ),
				'items' => array(
					array( 'mvweb_color_accent', '--mvweb-t-accent', 'brand', __( 'Accent', 'mvweb-core' ), __( 'Icons, badges, highlights, and the buttons while they have no colour of their own.', 'mvweb-core' ) ),
					array( 'mvweb_color_accent_hover', '--mvweb-t-accent-hover', 'hover', __( 'Accent on hover', 'mvweb-core' ), '' ),
					array( 'mvweb_color_accent_ink', '--mvweb-t-accent-ink', 'ink:mvweb_color_accent', __( 'Text on the accent', 'mvweb-core' ), __( 'Empty: black or white, whichever reads better.', 'mvweb-core' ) ),
				),
			),
			'link'   => array(
				'title' => __( 'Links in the text', 'mvweb-core' ),
				'items' => array(
					array( 'mvweb_color_link', '--mvweb-t-accent-link', 'link', __( 'Link', 'mvweb-core' ), __( 'Empty: the accent, darkened or lightened until it reads on the background.', 'mvweb-core' ) ),
					array( 'mvweb_color_link_hover', '--mvweb-t-link-hover', 'link', __( 'Link on hover', 'mvweb-core' ), '' ),
				),
			),
			'button' => array(
				'title' => __( 'Buttons', 'mvweb-core' ),
				'items' => array(
					array( 'mvweb_color_btn_bg', '--mvweb-t-button-bg', 'brand', __( 'Button', 'mvweb-core' ), __( 'Empty: the accent.', 'mvweb-core' ) ),
					array( 'mvweb_color_btn_ink', '--mvweb-t-button-ink', 'ink:mvweb_color_btn_bg', __( 'Text of the button', 'mvweb-core' ), '' ),
					array( 'mvweb_color_btn_hover_bg', '--mvweb-t-button-hover-bg', 'brand', __( 'Button on hover', 'mvweb-core' ), '' ),
					array( 'mvweb_color_btn_hover_ink', '--mvweb-t-button-hover-ink', 'ink:mvweb_color_btn_hover_bg', __( 'Text of the button on hover', 'mvweb-core' ), '' ),
				),
			),
			'menu'   => array(
				'title' => __( 'Drop-down menu and catalogue', 'mvweb-core' ),
				'items' => array(
					array( 'mvweb_color_menu_bg', '--mvweb-t-menu-bg', 'surface', __( 'Background', 'mvweb-core' ), '' ),
					array( 'mvweb_color_menu_ink', '--mvweb-t-menu-ink', 'ink:mvweb_color_menu_bg', __( 'Text', 'mvweb-core' ), '' ),
					array( 'mvweb_color_menu_hover', '--mvweb-t-menu-hover', 'surface', __( 'Item under the pointer', 'mvweb-core' ), '' ),
				),
			),
			'notice' => array(
				'title' => __( 'Announcement above the header', 'mvweb-core' ),
				'items' => array(
					array( 'mvweb_color_notice_bg', '--mvweb-t-notice-bg', 'brand', __( 'Background', 'mvweb-core' ), __( 'Empty: the accent.', 'mvweb-core' ) ),
					array( 'mvweb_color_notice_ink', '--mvweb-t-notice-ink', 'ink:mvweb_color_notice_bg', __( 'Text', 'mvweb-core' ), '' ),
				),
			),
			'footer' => array(
				'title' => __( 'Footer', 'mvweb-core' ),
				'items' => array(
					array( 'mvweb_color_footer_bg', '--mvweb-t-footer-bg', 'surface', __( 'Background', 'mvweb-core' ), '' ),
					array( 'mvweb_color_footer_ink', '--mvweb-t-footer-ink', 'ink:mvweb_color_footer_bg', __( 'Text', 'mvweb-core' ), '' ),
				),
			),
			'field'  => array(
				'title' => __( 'Form fields', 'mvweb-core' ),
				'items' => array(
					array( 'mvweb_color_field_bg', '--mvweb-t-field-bg', 'surface', __( 'Background of the field', 'mvweb-core' ), '' ),
					array( 'mvweb_color_field_border', '--mvweb-t-field-border', 'surface', __( 'Border of the field', 'mvweb-core' ), '' ),
					array( 'mvweb_color_field_ink', '--mvweb-t-field-ink', 'ink:mvweb_color_field_bg', __( 'Text in the field', 'mvweb-core' ), __( 'Empty: black or white, whichever reads better.', 'mvweb-core' ) ),
				),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_element_shapes' ) ) {
	/**
	 * The shape settings: setting => section, label, description, default and choices.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array{section:string,label:string,description:string,choices:array<string,string>}>
	 */
	function mvweb_core_element_shapes() {
		$radius = array(
			''     => __( 'As the site', 'mvweb-core' ),
			'0'    => __( 'Sharp corners', 'mvweb-core' ),
			'4'    => '4 px',
			'6'    => '6 px',
			'8'    => '8 px',
			'10'   => '10 px',
			'16'   => '16 px',
			'pill' => __( 'Fully round', 'mvweb-core' ),
		);

		return array(
			'mvweb_btn_radius'   => array(
				'section'     => 'mvweb_cz_design_buttons',
				'label'       => __( 'Rounding', 'mvweb-core' ),
				'description' => __( '“As the site” follows the corners in General look.', 'mvweb-core' ),
				'choices'     => $radius,
			),
			'mvweb_btn_size'     => array(
				'section'     => 'mvweb_cz_design_buttons',
				'label'       => __( 'Size', 'mvweb-core' ),
				'description' => '',
				'choices'     => array(
					'compact' => __( 'Compact buttons', 'mvweb-core' ),
					''        => __( 'Normal buttons', 'mvweb-core' ),
					'large'   => __( 'Large buttons', 'mvweb-core' ),
				),
			),
			'mvweb_btn_weight'   => array(
				'section'     => 'mvweb_cz_design_buttons',
				'label'       => __( 'Weight of the label', 'mvweb-core' ),
				'description' => '',
				'choices'     => array(
					'500' => __( 'Regular weight', 'mvweb-core' ),
					''    => __( 'Semi-bold', 'mvweb-core' ),
					'700' => __( 'Bold weight', 'mvweb-core' ),
				),
			),
			'mvweb_btn_case'     => array(
				'section'     => 'mvweb_cz_design_buttons',
				'label'       => __( 'Letters of the label', 'mvweb-core' ),
				'description' => '',
				'choices'     => array(
					''      => __( 'As written', 'mvweb-core' ),
					'upper' => __( 'CAPITALS', 'mvweb-core' ),
				),
			),
			'mvweb_btn_hover'    => array(
				'section'     => 'mvweb_cz_design_buttons',
				'label'       => __( 'On hover', 'mvweb-core' ),
				'description' => __( 'Visitors who turned animation off in their system see the change of colour only.', 'mvweb-core' ),
				'choices'     => array(
					''      => __( 'Colour changes', 'mvweb-core' ),
					'lift'  => __( 'Rises a little', 'mvweb-core' ),
					'shine' => __( 'A gleam runs across', 'mvweb-core' ),
				),
			),
			'mvweb_link_line'    => array(
				'section'     => 'mvweb_cz_design_links',
				'label'       => __( 'Underline', 'mvweb-core' ),
				'description' => __( 'Links inside the text of pages, articles and descriptions.', 'mvweb-core' ),
				'choices'     => array(
					''      => __( 'Always', 'mvweb-core' ),
					'hover' => __( 'On hover only', 'mvweb-core' ),
					'none'  => __( 'Never', 'mvweb-core' ),
				),
			),
			'mvweb_link_width'   => array(
				'section'     => 'mvweb_cz_design_links',
				'label'       => __( 'Thickness of the line', 'mvweb-core' ),
				'description' => '',
				'choices'     => array(
					'thin' => __( 'Thin', 'mvweb-core' ),
					''     => __( 'Normal line', 'mvweb-core' ),
					'bold' => __( 'Bold line', 'mvweb-core' ),
				),
			),
			'mvweb_field_radius' => array(
				'section'     => 'mvweb_cz_design_fields',
				'label'       => __( 'Corners of the fields', 'mvweb-core' ),
				'description' => __( 'Fields of the forms and the choice of product options.', 'mvweb-core' ),
				'choices'     => array_diff_key( $radius, array( 'pill' => '' ) ),
			),
			'mvweb_chip_radius'  => array(
				'section'     => 'mvweb_cz_design_fields',
				'label'       => __( 'Corners of the badges and chips', 'mvweb-core' ),
				'description' => __( 'Badges on the products, categories of the articles, tags.', 'mvweb-core' ),
				'choices'     => array(
					''     => __( 'Round', 'mvweb-core' ),
					'site' => __( 'As the site', 'mvweb-core' ),
				),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_element_sections' ) ) {
	/**
	 * Add the sections of the elements to the design panel.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panel id => panel.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_element_sections( $tree ) {
		if ( ! isset( $tree['mvweb_cz_design'] ) ) {
			return $tree;
		}

		$tree['mvweb_cz_design']['sections'] = (array) ( $tree['mvweb_cz_design']['sections'] ?? array() ) + array(
			'mvweb_cz_design_dark'    => __( 'Colours: dark scheme', 'mvweb-core' ),
			'mvweb_cz_design_buttons' => __( 'Buttons', 'mvweb-core' ),
			'mvweb_cz_design_links'   => __( 'Links in the text', 'mvweb-core' ),
			'mvweb_cz_design_fields'  => __( 'Fields and badges', 'mvweb-core' ),
		);

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_element_sections', 20 );

if ( ! function_exists( 'mvweb_core_element_fields' ) ) {
	/**
	 * Hand the fields to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_element_fields( $kit ) {
		$fields   = array();
		$priority = 100;
		$only     = array(
			array(
				'setting'  => 'mvweb_scheme_mode',
				'operator' => '!=',
				'value'    => 'light',
			),
		);

		foreach ( array( 'mvweb_cz_design_colors', 'mvweb_cz_design_dark' ) as $section ) {
			$dark = 'mvweb_cz_design_dark' === $section;

			if ( $dark ) {
				$fields[] = array(
					'type'        => 'heading',
					'settings'    => 'mvweb_cz_dark_note',
					'section'     => $section,
					'label'       => __( 'Empty fields take care of themselves', 'mvweb-core' ),
					'description' => __( 'The theme takes the colour of the light scheme and makes it readable on the dark background. Set a colour here only to change that.', 'mvweb-core' ),
					'priority'    => 1,
					'required'    => $only,
				);
			}

			foreach ( mvweb_core_element_colors() as $group => $data ) {
				$start    = count( $fields );
				$fields[] = array(
					'type'        => 'heading',
					'settings'    => 'mvweb_cz_colors_' . $group . ( $dark ? '_dark' : '' ),
					'section'     => $section,
					'label'       => $data['title'],
					'priority'    => $priority++,
					'collapsible' => 'accent' !== $group,
				);

				foreach ( $data['items'] as $item ) {
					$fields[] = array(
						'type'        => 'color',
						'settings'    => $item[0] . ( $dark ? '_dark' : '' ),
						'section'     => $section,
						'label'       => $item[3],
						'description' => $item[4],
						'default'     => '',
						'priority'    => $priority++,
					);
				}

				if ( $dark ) {
					for ( $i = $start, $n = count( $fields ); $i < $n; $i++ ) {
						$fields[ $i ]['required'] = $only;
					}
				}
			}
		}

		foreach ( mvweb_core_element_shapes() as $setting => $data ) {
			$fields[] = array(
				'type'        => count( $data['choices'] ) > 4 || 'mvweb_btn_hover' === $setting ? 'select' : 'radio_buttonset',
				'settings'    => $setting,
				'section'     => $data['section'],
				'label'       => $data['label'],
				'description' => $data['description'],
				'default'     => '',
				'choices'     => $data['choices'],
			);
		}

		$kit->add_fields( $fields );
	}
}
add_action( 'mvweb_cz_register', 'mvweb_core_element_fields' );

if ( ! function_exists( 'mvweb_core_element_shape' ) ) {
	/**
	 * The value of a shape setting, already one of its choices.
	 *
	 * @since 0.1.0
	 *
	 * @param string $setting Setting id.
	 *
	 * @return string
	 */
	function mvweb_core_element_shape( $setting ) {
		$shapes = mvweb_core_element_shapes();
		$value  = (string) get_theme_mod( $setting, '' );

		return isset( $shapes[ $setting ]['choices'][ $value ] ) ? $value : '';
	}
}

if ( ! function_exists( 'mvweb_core_element_html_settings' ) ) {
	/**
	 * The settings the root element carries for the CSS: the hover of the buttons, the underline of the links, a light footer.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Attribute name => value.
	 */
	function mvweb_core_element_html_settings() {
		$out = array();

		foreach ( array(
			'data-btn-hover' => 'mvweb_btn_hover',
			'data-link-line' => 'mvweb_link_line',
		) as $name => $setting ) {
			$value = mvweb_core_element_shape( $setting );

			if ( '' !== $value ) {
				$out[ $name ] = $value;
			}
		}

		foreach ( array(
			'data-footer-tone'      => 'mvweb_color_footer_bg',
			'data-footer-tone-dark' => 'mvweb_color_footer_bg_dark',
		) as $name => $setting ) {
			$color = (string) sanitize_hex_color( (string) get_theme_mod( $setting, '' ) );

			if ( '' !== $color && '#000000' === mvweb_core_readable_ink( $color ) ) {
				$out[ $name ] = 'light';
			}
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_core_mix_hex' ) ) {
	/**
	 * Mix two hex colours.
	 *
	 * @since 0.1.0
	 *
	 * @param string $a      Hex colour.
	 * @param string $b      Hex colour.
	 * @param float  $amount Share of the second colour, 0 to 1.
	 *
	 * @return string
	 */
	function mvweb_core_mix_hex( $a, $b, $amount ) {
		$rgb = static function ( $hex ) {
			$hex = ltrim( (string) $hex, '#' );
			$hex = 3 === strlen( $hex ) ? $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2] : $hex;

			return array( hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ) );
		};
		$one = $rgb( $a );
		$two = $rgb( $b );
		$out = '#';

		foreach ( array( 0, 1, 2 ) as $i ) {
			$out .= sprintf( '%02x', (int) round( $one[ $i ] + ( $two[ $i ] - $one[ $i ] ) * $amount ) );
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_core_readable_on' ) ) {
	/**
	 * A colour moved towards black or white until it reads on the background at 4.5:1.
	 *
	 * @since 0.1.0
	 *
	 * @param string $color      Hex colour.
	 * @param string $background Hex colour.
	 *
	 * @return string
	 */
	function mvweb_core_readable_on( $color, $background ) {
		$target = mvweb_core_readable_ink( $background );

		for ( $step = 0; $step <= 20; $step++ ) {
			$mixed = mvweb_core_mix_hex( $color, $target, $step / 20 );

			if ( mvweb_core_contrast_ratio( $mixed, $background ) >= 4.5 ) {
				return $mixed;
			}
		}

		return $target;
	}
}

if ( ! function_exists( 'mvweb_core_scheme_backgrounds' ) ) {
	/**
	 * The page backgrounds of both schemes, which the derived colours must read on.
	 *
	 * @since 0.1.0
	 *
	 * @return array{light:string,dark:string}
	 */
	function mvweb_core_scheme_backgrounds() {
		/**
		 * Filter the page backgrounds of the light and the dark scheme.
		 *
		 * @since 0.1.0
		 *
		 * @param array{light:string,dark:string} $backgrounds Hex colours.
		 */
		return (array) apply_filters(
			'mvweb_core_scheme_backgrounds',
			array(
				'light' => '#ffffff',
				'dark'  => '#131416',
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_element_color_css' ) ) {
	/**
	 * The colour tokens: for both schemes, for the light one only, for the dark one.
	 *
	 * @since 0.1.0
	 *
	 * @return array{both:array<string,string>,light:array<string,string>,dark:array<string,string>}
	 */
	function mvweb_core_element_color_css() {
		$read  = static function ( $setting ) {
			return (string) sanitize_hex_color( (string) get_theme_mod( $setting, '' ) );
		};
		$bg    = mvweb_core_scheme_backgrounds();
		$kinds = array();

		foreach ( mvweb_core_element_colors() as $data ) {
			foreach ( $data['items'] as $item ) {
				$kinds[ $item[0] ] = $item[2];
			}
		}

		$out = array(
			'both'  => array(),
			'light' => array(),
			'dark'  => array(),
		);

		foreach ( mvweb_core_element_colors() as $data ) {
			foreach ( $data['items'] as $item ) {
				list( $setting, $token, $kind ) = $item;

				$light = $read( $setting );
				$dark  = $read( $setting . '_dark' );
				$pair  = str_starts_with( $kind, 'ink:' ) ? substr( $kind, 4 ) : '';

				if ( '' !== $pair ) {
					$pair_light = $read( $pair );
					$pair_dark  = $read( $pair . '_dark' );
					$scope      = 'surface' === ( $kinds[ $pair ] ?? '' ) ? 'light' : 'both';
					$ink        = '' !== $light ? $light : ( '' !== $pair_light ? mvweb_core_readable_ink( $pair_light ) : '' );

					if ( '' !== $ink ) {
						$out[ $scope ][ $token ] = $ink;
					}

					if ( '' !== $dark ) {
						$out['dark'][ $token ] = $dark;
					} elseif ( '' !== $pair_dark ) {
						$out['dark'][ $token ] = '' !== $light && mvweb_core_contrast_ratio( $light, $pair_dark ) >= 4.5 ? $light : mvweb_core_readable_ink( $pair_dark );
					}

					continue;
				}

				if ( 'brand' === $kind ) {
					if ( '' !== $light ) {
						$out['both'][ $token ] = $light;
					}

					if ( '' !== $dark ) {
						$out['dark'][ $token ] = $dark;
					}

					continue;
				}

				if ( 'surface' === $kind ) {
					if ( '' !== $light ) {
						$out['light'][ $token ] = $light;
					}

					if ( '' !== $dark ) {
						$out['dark'][ $token ] = $dark;
					}

					continue;
				}

				$accent_light = $read( 'mvweb_color_accent' );
				$accent_dark  = '' !== $read( 'mvweb_color_accent_dark' ) ? $read( 'mvweb_color_accent_dark' ) : $accent_light;

				if ( 'hover' === $kind ) {
					if ( '' !== $light ) {
						$out['light'][ $token ] = $light;
					} elseif ( '' !== $accent_light ) {
						$out['light'][ $token ] = mvweb_core_mix_hex( $accent_light, '#000000', 0.12 );
					}

					if ( '' !== $dark ) {
						$out['dark'][ $token ] = $dark;
					} elseif ( '' !== $accent_dark ) {
						$out['dark'][ $token ] = mvweb_core_mix_hex( $accent_dark, '#ffffff', 0.18 );
					}

					continue;
				}

				$base_light = '' !== $light ? $light : ( '--mvweb-t-accent-link' === $token ? $accent_light : '' );
				$base_dark  = '' !== $light ? $light : ( '--mvweb-t-accent-link' === $token ? $accent_dark : '' );

				if ( '' !== $base_light ) {
					$out['light'][ $token ] = mvweb_core_readable_on( $base_light, $bg['light'] );
				}

				if ( '' !== $dark ) {
					$out['dark'][ $token ] = $dark;
				} elseif ( '' !== $base_dark ) {
					$out['dark'][ $token ] = mvweb_core_readable_on( $base_dark, $bg['dark'] );
				}
			}
		}

		foreach ( array( 'light', 'dark' ) as $scheme ) {
			$menu_bg  = $out[ $scheme ]['--mvweb-t-menu-bg'] ?? '';
			$menu_ink = $out[ $scheme ]['--mvweb-t-menu-ink'] ?? ( $out['both']['--mvweb-t-menu-ink'] ?? '' );

			if ( '' === $menu_bg || '' === $menu_ink ) {
				continue;
			}

			$out[ $scheme ]['--mvweb-t-menu-muted']   = mvweb_core_mix_hex( $menu_ink, $menu_bg, 0.28 );
			$out[ $scheme ]['--mvweb-t-menu-dim']     = mvweb_core_mix_hex( $menu_ink, $menu_bg, 0.38 );
			$out[ $scheme ]['--mvweb-t-menu-surface'] = mvweb_core_mix_hex( $menu_bg, $menu_ink, 0.07 );

			if ( ! isset( $out[ $scheme ]['--mvweb-t-menu-hover'] ) ) {
				$out[ $scheme ]['--mvweb-t-menu-hover'] = mvweb_core_mix_hex( $menu_bg, $menu_ink, 0.12 );
			}
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_core_element_shape_css' ) ) {
	/**
	 * The shape tokens of the buttons, the links, the fields and the chips.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_element_shape_css() {
		$px     = static function ( $value ) {
			return 'pill' === $value ? '999px' : absint( $value ) . 'px';
		};
		$tokens = array();
		$radius = mvweb_core_element_shape( 'mvweb_btn_radius' );

		if ( '' !== $radius ) {
			$tokens['--mvweb-t-btn-radius'] = $px( $radius );
		}

		$size = mvweb_core_element_shape( 'mvweb_btn_size' );

		if ( 'compact' === $size ) {
			$tokens['--mvweb-t-btn-h']   = '2.75rem';
			$tokens['--mvweb-t-btn-pad'] = '1.125rem';
		} elseif ( 'large' === $size ) {
			$tokens['--mvweb-t-btn-h']   = '3.5rem';
			$tokens['--mvweb-t-btn-pad'] = '2rem';
		}

		$weight = mvweb_core_element_shape( 'mvweb_btn_weight' );

		if ( '' !== $weight ) {
			$tokens['--mvweb-t-btn-weight'] = $weight;
		}

		if ( 'upper' === mvweb_core_element_shape( 'mvweb_btn_case' ) ) {
			$tokens['--mvweb-t-btn-case'] = 'uppercase';
			$tokens['--mvweb-t-btn-ls']   = '0.04em';
		}

		$width = mvweb_core_element_shape( 'mvweb_link_width' );

		if ( 'thin' === $width ) {
			$tokens['--mvweb-t-link-w']       = '1px';
			$tokens['--mvweb-t-link-w-hover'] = '2px';
		} elseif ( 'bold' === $width ) {
			$tokens['--mvweb-t-link-w']       = '2px';
			$tokens['--mvweb-t-link-w-hover'] = '3px';
		}

		$field = mvweb_core_element_shape( 'mvweb_field_radius' );

		if ( '' !== $field ) {
			$tokens['--mvweb-t-field-radius'] = $px( $field );
		}

		if ( 'site' === mvweb_core_element_shape( 'mvweb_chip_radius' ) ) {
			$tokens['--mvweb-t-chip-radius'] = 'var(--mvweb-t-radius-sm)';
		}

		return $tokens;
	}
}

if ( ! function_exists( 'mvweb_core_print_elements' ) ) {
	/**
	 * Print the tokens of the elements after the palette, the radius and the Kit.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_print_elements() {
		$colors = mvweb_core_element_color_css();
		$blocks = array(
			':root'                           => $colors['both'] + mvweb_core_element_shape_css(),
			':root:not([data-scheme="dark"])' => $colors['light'],
			'[data-scheme="dark"]'            => $colors['dark'],
		);
		$css    = '';

		foreach ( $blocks as $selector => $tokens ) {
			$declarations = '';

			foreach ( $tokens as $property => $value ) {
				$value = 'var(--mvweb-t-radius-sm)' === $value ? $value : mvweb_cz_sanitize_css_value( $value );

				if ( '' !== $value ) {
					$declarations .= $property . ':' . $value . ';';
				}
			}

			if ( '' !== $declarations ) {
				$css .= $selector . '{' . $declarations . '}';
			}
		}

		if ( '' !== $css ) {
			printf( "<style id='mvweb-core-elements'>%s</style>\n", $css ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed properties, sanitized hex colours and fixed values.
		}
	}
}
add_action( 'wp_head', 'mvweb_core_print_elements', 21 );
