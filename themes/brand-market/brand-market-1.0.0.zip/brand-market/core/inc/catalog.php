<?php
/**
 * Catalogue engine.
 *
 * Templates ask this file for a card, a price, a gallery or a set of filters
 * and never touch the source those come from. Two sources answer: WooCommerce
 * when the plugin is active, and the theme's own post type when it is not.
 *
 * Everything below takes a post id rather than a product object, because that
 * is the one handle both sources share.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_locale_currency' ) ) {
	/**
	 * The currency a new site starts with, guessed from its language.
	 *
	 * @since 0.1.0
	 *
	 * @return array{0:string,1:string,2:string} Sign, ISO code, position.
	 */
	function mvweb_core_locale_currency() {
		$locale = get_locale();
		$map    = array(
			'ru'    => array( '₽', 'RUB', 'after' ),
			'be'    => array( 'Br', 'BYN', 'after' ),
			'kk'    => array( '₸', 'KZT', 'after' ),
			'uk'    => array( '₴', 'UAH', 'after' ),
			'pl'    => array( 'zł', 'PLN', 'after' ),
			'cs'    => array( 'Kč', 'CZK', 'after' ),
			'en_US' => array( '$', 'USD', 'before' ),
			'en_GB' => array( '£', 'GBP', 'before' ),
		);

		if ( isset( $map[ $locale ] ) ) {
			return $map[ $locale ];
		}

		$language = strtok( $locale, '_' );

		return isset( $map[ $language ] ) ? $map[ $language ] : array( '€', 'EUR', 'after' );
	}
}

if ( ! function_exists( 'mvweb_core_catalog_defaults' ) ) {
	/**
	 * Defaults of the catalogue settings.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_catalog_defaults() {
		$currency = mvweb_core_locale_currency();

		return array(
			'mvweb_item_slug'          => 'catalog',
			'mvweb_item_cat_slug'      => 'catalog-cat',
			'mvweb_item_label'         => '',
			'mvweb_item_properties'    => '[]',
			'mvweb_items_per_page'     => 12,
			'mvweb_price_label'        => '',
			'mvweb_second_price'       => false,
			'mvweb_second_price_label' => '',
			'mvweb_currency'           => $currency[0],
			'mvweb_currency_code'      => $currency[1],
			'mvweb_currency_position'  => $currency[2],
			'mvweb_price_empty'        => __( 'Check with us', 'mvweb-core' ),
			'mvweb_placeholder_image'  => '',
			'mvweb_related_count'      => 4,
			'mvweb_related_title'      => __( 'Similar models', 'mvweb-core' ),
			'mvweb_switch_property'    => '',
		);
	}
}

if ( ! function_exists( 'mvweb_core_option' ) ) {
	/**
	 * A catalogue setting, with the default it was declared with.
	 *
	 * @since 0.1.0
	 *
	 * @param string $setting Setting id.
	 *
	 * @return mixed
	 */
	function mvweb_core_option( $setting ) {
		$defaults = array_merge( mvweb_core_catalog_defaults(), mvweb_core_service_defaults() );

		return get_theme_mod( $setting, isset( $defaults[ $setting ] ) ? $defaults[ $setting ] : '' );
	}
}

if ( ! function_exists( 'mvweb_core_store' ) ) {
	/**
	 * Which source answers for the catalogue.
	 *
	 * @since 0.1.0
	 *
	 * @return string Either woocommerce or native.
	 */
	function mvweb_core_store() {
		return 'woocommerce' === mvweb_core_catalog_mode() ? 'woocommerce' : 'native';
	}
}

if ( ! function_exists( 'mvweb_core_is_woocommerce' ) ) {
	/**
	 * Whether the store plugin is the source.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_is_woocommerce() {
		return 'woocommerce' === mvweb_core_store();
	}
}

if ( ! function_exists( 'mvweb_core_post_type' ) ) {
	/**
	 * Post type of a catalogue item.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_post_type() {
		return mvweb_core_is_woocommerce() ? 'product' : 'mv_item';
	}
}

if ( ! function_exists( 'mvweb_core_taxonomy' ) ) {
	/**
	 * Taxonomy the catalogue is divided into.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_taxonomy() {
		return mvweb_core_is_woocommerce() ? 'product_cat' : 'mv_item_cat';
	}
}

if ( ! function_exists( 'mvweb_core_listing_taxonomies' ) ) {
	/**
	 * Taxonomies a listing of the theme is divided into.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_listing_taxonomies() {
		return array( mvweb_core_taxonomy(), 'mv_service_cat' );
	}
}

if ( ! function_exists( 'mvweb_core_term_text' ) ) {
	/**
	 * The second description of a category.
	 *
	 * @since 0.1.0
	 *
	 * @param int $term_id Term id.
	 *
	 * @return string Raw text, as it was typed.
	 */
	function mvweb_core_term_text( $term_id ) {
		return trim( (string) get_term_meta( absint( $term_id ), 'mvweb_text', true ) );
	}
}

if ( ! function_exists( 'mvweb_core_listing_intro' ) ) {
	/**
	 * The description that opens the listing being shown.
	 *
	 * @since 0.1.0
	 *
	 * @return string Markup, empty when there is none to print.
	 */
	function mvweb_core_listing_intro() {
		if ( is_paged() || ( mvweb_core_is_catalog() && mvweb_core_catalog_is_filtered() ) ) {
			return '';
		}

		if ( mvweb_core_current_facet() ) {
			return trim( wp_kses_post( wpautop( (string) get_post_field( 'post_excerpt', mvweb_core_current_facet() ) ) ) );
		}

		if ( ! get_queried_object() instanceof WP_Term ) {
			$page = mvweb_core_is_woocommerce() && is_shop() ? max( 0, (int) wc_get_page_id( 'shop' ) ) : 0;

			return $page > 0 ? trim( wc_format_content( wp_kses_post( (string) get_post_field( 'post_content', $page ) ) ) ) : '';
		}

		return trim( (string) get_the_archive_description() );
	}
}

if ( ! function_exists( 'mvweb_core_listing_text' ) ) {
	/**
	 * The second description belonging to the listing being shown.
	 *
	 * @since 0.1.0
	 *
	 * @return string Raw text, empty when there is none to print.
	 */
	function mvweb_core_listing_text() {
		$term = get_queried_object();

		if ( is_paged() ) {
			return '';
		}

		if ( is_post_type_archive( 'mv_service' ) ) {
			return trim( (string) mvweb_core_option( 'mvweb_service_list_text' ) );
		}

		if ( mvweb_core_current_facet() ) {
			return mvweb_core_catalog_is_filtered() ? '' : trim( (string) get_post_field( 'post_content', mvweb_core_current_facet() ) );
		}

		if ( ! $term instanceof WP_Term ) {
			return '';
		}

		if ( mvweb_core_is_catalog() && mvweb_core_catalog_is_filtered() ) {
			return '';
		}

		return mvweb_core_term_text( $term->term_id );
	}
}

if ( ! function_exists( 'mvweb_core_properties' ) ) {
	/**
	 * Filterable properties, in the order they are printed.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>> Items with 'slug', 'label',
	 *                                        'taxonomy' and 'sidebar' — false
	 *                                        when the owner hid the filter.
	 */
	function mvweb_core_properties() {
		$properties = array();

		if ( mvweb_core_is_woocommerce() ) {
			foreach ( wc_get_attribute_taxonomies() as $attribute ) {
				$taxonomy = wc_attribute_taxonomy_name( $attribute->attribute_name );

				if ( ! taxonomy_exists( $taxonomy ) ) {
					continue;
				}

				$properties[] = array(
					'slug'     => $attribute->attribute_name,
					'label'    => wc_attribute_label( $taxonomy ),
					'taxonomy' => $taxonomy,
					'sidebar'  => true,
				);
			}
		} else {
			foreach ( mvweb_core_property_settings() as $property ) {
				$properties[] = array(
					'slug'     => $property['slug'],
					'label'    => $property['label'],
					'taxonomy' => mvweb_core_property_taxonomy( $property['slug'] ),
					'sidebar'  => $property['sidebar'],
				);
			}
		}

		/**
		 * Filter the filterable properties of the catalogue.
		 *
		 * @since 0.1.0
		 *
		 * @param array<int,array<string,string>> $properties Properties in print order.
		 */
		return (array) apply_filters( 'mvweb_core_properties', $properties );
	}
}

if ( ! function_exists( 'mvweb_core_property_settings' ) ) {
	/**
	 * Properties declared in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,string>>
	 */
	function mvweb_core_property_settings() {
		$rows = json_decode( (string) mvweb_core_option( 'mvweb_item_properties' ), true );

		if ( ! is_array( $rows ) ) {
			return array();
		}

		$properties = array();

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$slug  = isset( $row['slug'] ) ? sanitize_key( $row['slug'] ) : '';
			$label = isset( $row['label'] ) ? trim( (string) $row['label'] ) : '';

			$key = mvweb_core_property_taxonomy( $slug );

			if ( '' === $slug || isset( $properties[ $key ] ) ) {
				continue;
			}

			$properties[ $key ] = array(
				'slug'    => $slug,
				'label'   => '' === $label ? $slug : $label,
				'sidebar' => ! isset( $row['sidebar'] ) || 'hide' !== $row['sidebar'],
			);
		}

		return array_values( $properties );
	}
}

if ( ! function_exists( 'mvweb_core_property_taxonomy' ) ) {
	/**
	 * Taxonomy name of a theme property.
	 *
	 * @since 0.1.0
	 *
	 * @param string $slug Property slug.
	 *
	 * @return string
	 */
	function mvweb_core_property_taxonomy( $slug ) {
		return 'mv_p_' . substr( sanitize_key( $slug ), 0, 27 );
	}
}

if ( ! function_exists( 'mvweb_core_catalog_page_url' ) ) {
	/**
	 * Address of the catalogue itself.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_catalog_page_url() {
		if ( mvweb_core_is_woocommerce() ) {
			$shop = wc_get_page_permalink( 'shop' );

			return $shop ? $shop : home_url( '/' );
		}

		$archive = get_post_type_archive_link( 'mv_item' );

		return $archive ? $archive : home_url( '/' );
	}
}

if ( ! function_exists( 'mvweb_core_catalog_title' ) ) {
	/**
	 * Heading of the listing being shown.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_catalog_title() {
		if ( mvweb_core_current_facet() ) {
			return wp_strip_all_tags( get_the_title( mvweb_core_current_facet() ) );
		}

		if ( mvweb_core_is_woocommerce() ) {
			return wp_strip_all_tags( woocommerce_page_title( false ) );
		}

		if ( is_post_type_archive() ) {
			return wp_strip_all_tags( post_type_archive_title( '', false ) );
		}

		if ( is_tax() ) {
			return wp_strip_all_tags( single_term_title( '', false ) );
		}

		return wp_strip_all_tags( get_the_archive_title() );
	}
}

if ( ! function_exists( 'mvweb_core_listing_query' ) ) {
	/**
	 * How many entries a listing page holds, and in what order.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query   Query being prepared.
	 * @param string   $setting Setting holding the page size.
	 *
	 * @return void
	 */
	function mvweb_core_listing_query( $query, $setting ) {
		$per_page = absint( mvweb_core_option( $setting ) );

		if ( $per_page > 0 ) {
			$query->set( 'posts_per_page', $per_page );
		}

		if ( ! $query->get( 'orderby' ) ) {
			$query->set(
				'orderby',
				array(
					'menu_order' => 'ASC',
					'date'       => 'DESC',
				)
			);
		}
	}
}

if ( ! function_exists( 'mvweb_core_item_visible' ) ) {
	/**
	 * Whether a visitor may be shown this item.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return bool
	 */
	function mvweb_core_item_visible( $id ) {
		$id = absint( $id );

		if ( 0 === $id ) {
			return false;
		}

		if ( mvweb_core_is_woocommerce() ) {
			$product = wc_get_product( $id );

			return (bool) $product && $product->is_visible();
		}

		return 'mv_item' === get_post_type( $id ) && 'publish' === get_post_status( $id );
	}
}

if ( ! function_exists( 'mvweb_core_item_brand' ) ) {
	/**
	 * The line above an item's name.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return string
	 */
	function mvweb_core_item_brand( $id ) {
		if ( ! mvweb_core_is_woocommerce() ) {
			return trim( (string) get_post_meta( $id, '_mvweb_brand', true ) );
		}

		if ( ! taxonomy_exists( 'product_brand' ) ) {
			return '';
		}

		$terms = get_the_terms( $id, 'product_brand' );

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return '';
		}

		return $terms[0]->name;
	}
}

if ( ! function_exists( 'mvweb_core_item_sku' ) ) {
	/**
	 * Stock keeping unit of an item.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return string
	 */
	function mvweb_core_item_sku( $id ) {
		if ( mvweb_core_is_woocommerce() ) {
			$product = wc_get_product( $id );

			return $product ? (string) $product->get_sku() : '';
		}

		return trim( (string) get_post_meta( $id, '_mvweb_sku', true ) );
	}
}

if ( ! function_exists( 'mvweb_core_item_excerpt' ) ) {
	/**
	 * The short description printed above the prices.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return string Markup, already filtered.
	 */
	function mvweb_core_item_excerpt( $id ) {
		if ( mvweb_core_is_woocommerce() && 'product' === get_post_type( $id ) ) {
			$product = wc_get_product( $id );

			if ( ! $product ) {
				return '';
			}

			return (string) apply_filters( 'woocommerce_short_description', $product->get_short_description() );
		}

		$post = get_post( $id );

		if ( ! $post || '' === trim( $post->post_excerpt ) ) {
			return '';
		}

		return wpautop( wp_kses_post( $post->post_excerpt ) );
	}
}

if ( ! function_exists( 'mvweb_core_item_content' ) ) {
	/**
	 * The body text of an item or a service, ready to print.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Entry id.
	 *
	 * @return string Markup, already filtered.
	 */
	function mvweb_core_item_content( $id ) {
		$content = (string) get_post_field( 'post_content', $id );

		if ( '' === trim( $content ) ) {
			/**
			 * Filter the text of an entry whose editor is empty.
			 *
			 * @since 0.1.0
			 *
			 * @param string $content Empty, unless a site fills it in.
			 * @param int    $id      Entry id.
			 */
			$content = (string) apply_filters( 'mvweb_core_item_content', '', $id );
		}

		if ( '' === trim( $content ) ) {
			return '';
		}

		return trim( (string) apply_filters( 'the_content', $content ) );
	}
}

if ( ! function_exists( 'mvweb_core_item_price_html' ) ) {
	/**
	 * The first price of an item, ready to print.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return string
	 */
	function mvweb_core_item_price_html( $id ) {
		if ( mvweb_core_is_woocommerce() && 'product' === get_post_type( $id ) ) {
			$product = wc_get_product( $id );

			if ( $product && get_theme_mod( 'mvweb_price_request_out', false ) && ! $product->is_in_stock() ) {
				return '';
			}

			return $product ? (string) $product->get_price_html() : '';
		}

		$amount = (string) get_post_meta( $id, '_mvweb_price', true );

		return mvweb_core_price_html( function_exists( 'mvweb_core_customer_amount' ) ? mvweb_core_customer_amount( $id, $amount ) : $amount );
	}
}

if ( ! function_exists( 'mvweb_core_item_second_price_html' ) ) {
	/**
	 * The second price of an item, ready to print.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return string
	 */
	function mvweb_core_item_second_price_html( $id ) {
		return mvweb_core_price_html( get_post_meta( $id, '_mvweb_second_price', true ) );
	}
}

if ( ! function_exists( 'mvweb_core_price_html' ) ) {
	/**
	 * An amount in the wrapper the layout keeps on one line.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $amount Raw amount.
	 *
	 * @return string Empty when there is no amount to print.
	 */
	function mvweb_core_price_html( $amount ) {
		$amount = trim( (string) $amount );

		if ( '' === $amount || ! is_numeric( $amount ) ) {
			return '';
		}

		if ( mvweb_core_is_woocommerce() ) {
			return wc_price( (float) $amount );
		}

		return esc_html( mvweb_core_price_format( (float) $amount ) );
	}
}

if ( ! function_exists( 'mvweb_core_price_format' ) ) {
	/**
	 * An amount written the way the site writes prices.
	 *
	 * @since 0.1.0
	 *
	 * @param float $amount Amount.
	 *
	 * @return string
	 */
	function mvweb_core_price_format( $amount ) {
		$decimals = ( floor( (float) $amount ) === (float) $amount ) ? 0 : 2;
		$number   = number_format_i18n( (float) $amount, $decimals );
		$currency = trim( (string) mvweb_core_option( 'mvweb_currency' ) );

		if ( '' === $currency ) {
			return $number;
		}

		if ( 'before' === mvweb_core_option( 'mvweb_currency_position' ) ) {
			return $currency . ( preg_match( '/\p{L}/u', $currency ) ? "\xc2\xa0" : '' ) . $number;
		}

		return $number . "\xc2\xa0" . $currency;
	}
}

if ( ! function_exists( 'mvweb_core_price_placeholder' ) ) {
	/**
	 * What stands in for a price nobody filled in.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty to print nothing at all.
	 */
	function mvweb_core_price_placeholder() {
		return trim( (string) mvweb_core_option( 'mvweb_price_empty' ) );
	}
}

if ( ! function_exists( 'mvweb_core_item_second_price_line' ) ) {
	/**
	 * The second price of an item as its line prints it.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return string
	 */
	function mvweb_core_item_second_price_line( $id ) {
		if ( ! mvweb_core_option( 'mvweb_second_price' ) ) {
			return null;
		}

		return mvweb_core_item_second_price_html( $id );
	}
}

if ( ! function_exists( 'mvweb_core_item_gallery' ) ) {
	/**
	 * Pictures of an item, the main one first.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return int[]
	 */
	function mvweb_core_item_gallery( $id ) {
		if ( mvweb_core_is_woocommerce() && 'product' === get_post_type( $id ) ) {
			$product = wc_get_product( $id );

			if ( ! $product ) {
				return array();
			}

			$ids = array_merge( array( (int) $product->get_image_id() ), array_map( 'absint', $product->get_gallery_image_ids() ) );
		} else {
			$stored = get_post_meta( $id, '_mvweb_gallery', true );
			$stored = is_string( $stored ) ? explode( ',', $stored ) : (array) $stored;

			$ids = array_merge( array( (int) get_post_thumbnail_id( $id ) ), array_map( 'absint', $stored ) );
		}

		return array_values( array_unique( array_filter( $ids, 'wp_attachment_is_image' ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_item_image' ) ) {
	/**
	 * The picture of an item as a card shows it.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $id         Item id.
	 * @param string $size       Image size.
	 * @param array  $attributes Image attributes.
	 *
	 * @return string Markup, empty when there is no picture and no placeholder.
	 */
	function mvweb_core_item_image( $id, $size = 'mvweb_card', $attributes = array() ) {
		if ( isset( $GLOBALS['wp_query'] ) && ! $GLOBALS['wp_query']->thumbnails_cached ) {
			update_post_thumbnail_cache();
		}

		$thumbnail = get_post_thumbnail_id( $id );

		if ( wp_attachment_is_image( $thumbnail ) ) {
			$attributes += array( 'alt' => mvweb_core_image_alt( $thumbnail, get_post_field( 'post_title', $id ) ) );

			return (string) wp_get_attachment_image( $thumbnail, $size, false, $attributes );
		}

		$placeholder = mvweb_core_placeholder_src( $size );

		if ( '' === $placeholder ) {
			return '';
		}

		$class = isset( $attributes['class'] ) ? $attributes['class'] : '';

		return sprintf(
			'<img class="%1$s" src="%2$s" alt="" loading="lazy" decoding="async">',
			esc_attr( $class ),
			esc_url( $placeholder )
		);
	}
}

if ( ! function_exists( 'mvweb_core_placeholder_src' ) ) {
	/**
	 * Address of the picture shown where an item has none.
	 *
	 * @since 0.1.0
	 *
	 * @param string $size Image size.
	 *
	 * @return string Empty when the site set none.
	 */
	function mvweb_core_placeholder_src( $size = 'mvweb_card' ) {
		$own = esc_url_raw( trim( (string) mvweb_core_option( 'mvweb_placeholder_image' ) ) );

		if ( '' !== $own ) {
			return $own;
		}

		if ( function_exists( 'wc_placeholder_img_src' ) ) {
			return (string) wc_placeholder_img_src( $size );
		}

		return '';
	}
}

if ( ! function_exists( 'mvweb_core_item_file' ) ) {
	/**
	 * Address of the file offered on an item page.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return string
	 */
	function mvweb_core_item_file( $id ) {
		return trim( (string) get_post_meta( $id, '_mvweb_file_url', true ) );
	}
}

if ( ! function_exists( 'mvweb_core_item_specs' ) ) {
	/**
	 * Specification rows of an item.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return array<int,array<string,string>> Rows with 'label' and 'value'.
	 */
	function mvweb_core_item_specs( $id ) {
		$rows  = array();
		$brand = mvweb_core_item_brand( $id );

		if ( '' !== $brand ) {
			$rows[] = array(
				'label' => __( 'Brand', 'mvweb-core' ),
				'value' => $brand,
			);
		}

		foreach ( mvweb_core_properties() as $property ) {
			$terms = get_the_terms( $id, $property['taxonomy'] );

			if ( is_wp_error( $terms ) || empty( $terms ) ) {
				continue;
			}

			$rows[] = array(
				'label' => $property['label'],
				'value' => implode( ', ', wp_list_pluck( $terms, 'name' ) ),
			);
		}

		$stored = json_decode( (string) get_post_meta( $id, '_mvweb_specs', true ), true );

		foreach ( is_array( $stored ) ? $stored : array() as $row ) {
			$label = is_array( $row ) && isset( $row['label'] ) ? trim( (string) $row['label'] ) : '';
			$value = is_array( $row ) && isset( $row['value'] ) ? trim( (string) $row['value'] ) : '';

			if ( '' === $label || '' === $value ) {
				continue;
			}

			$rows[] = array(
				'label' => $label,
				'value' => $value,
			);
		}

		/**
		 * Filter the specification rows of an item.
		 *
		 * @since 0.1.0
		 *
		 * @param array<int,array<string,string>> $rows Rows in print order.
		 * @param int                             $id   Item id.
		 */
		return (array) apply_filters( 'mvweb_core_item_specs', $rows, $id );
	}
}

if ( ! function_exists( 'mvweb_core_related_items' ) ) {
	/**
	 * Items close enough to the one being shown to offer beside it.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id    Item id.
	 * @param int $limit How many to return. 0 for the number set in the settings.
	 *
	 * @return int[]
	 */
	function mvweb_core_related_items( $id, $limit = 0 ) {
		$limit = $limit > 0 ? (int) $limit : absint( mvweb_core_option( 'mvweb_related_count' ) );

		if ( $limit < 1 ) {
			return array();
		}

		$found = mvweb_core_related_by( $id, mvweb_core_taxonomy(), $limit, array() );

		foreach ( mvweb_core_properties() as $property ) {
			if ( count( $found ) >= $limit ) {
				break;
			}

			$found = array_merge( $found, mvweb_core_related_by( $id, $property['taxonomy'], $limit - count( $found ), $found ) );
		}

		return $found;
	}
}

if ( ! function_exists( 'mvweb_core_visibility_query' ) ) {
	/**
	 * The clause that keeps items hidden from the catalogue out of a selection.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>> Empty without the store.
	 */
	function mvweb_core_visibility_query() {
		if ( ! mvweb_core_is_woocommerce() || ! function_exists( 'wc_get_product_visibility_term_ids' ) ) {
			return array();
		}

		$terms = wc_get_product_visibility_term_ids();

		if ( empty( $terms['exclude-from-catalog'] ) ) {
			return array();
		}

		return array(
			array(
				'taxonomy' => 'product_visibility',
				'field'    => 'term_taxonomy_id',
				'terms'    => array( $terms['exclude-from-catalog'] ),
				'operator' => 'NOT IN',
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_related_by' ) ) {
	/**
	 * Items sharing a term of one taxonomy with the given one.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $id       Item id.
	 * @param string $taxonomy Taxonomy to match on.
	 * @param int    $limit    How many to return.
	 * @param int[]  $exclude  Ids already found.
	 *
	 * @return int[]
	 */
	function mvweb_core_related_by( $id, $taxonomy, $limit, $exclude ) {
		if ( $limit < 1 || ! taxonomy_exists( $taxonomy ) ) {
			return array();
		}

		$terms = wp_get_post_terms( $id, $taxonomy, array( 'fields' => 'ids' ) );

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return array();
		}

		$exclude[] = absint( $id );

		$tax_query = array(
			array(
				'taxonomy' => $taxonomy,
				'field'    => 'term_id',
				'terms'    => $terms,
			),
		);

		$tax_query = array_merge( $tax_query, mvweb_core_visibility_query() );

		$found = get_posts(
			array(
				'post_type'        => mvweb_core_post_type(),
				'post_status'      => 'publish',
				'numberposts'      => (int) $limit,
				'fields'           => 'ids',
				'post__not_in'     => array_map( 'absint', $exclude ),
				'suppress_filters' => false,
				'orderby'          => array(
					'menu_order' => 'ASC',
					'date'       => 'DESC',
				),
				'tax_query'        => $tax_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Matching on a term is what makes two items similar.
			)
		);

		return array_map( 'absint', (array) $found );
	}
}

if ( ! function_exists( 'mvweb_core_switch_links' ) ) {
	/**
	 * Links to the other values of one filterable property.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return array<string,mixed> Keys 'label' and 'terms'. Empty when off.
	 */
	function mvweb_core_switch_links( $id ) {
		$slug = sanitize_key( (string) mvweb_core_option( 'mvweb_switch_property' ) );

		if ( '' === $slug ) {
			return array();
		}

		$property = array();

		foreach ( mvweb_core_properties() as $candidate ) {
			if ( $candidate['slug'] === $slug ) {
				$property = $candidate;

				break;
			}
		}

		if ( empty( $property ) ) {
			return array();
		}

		$terms = get_terms(
			array(
				'taxonomy'   => $property['taxonomy'],
				'hide_empty' => true,
			)
		);

		if ( is_wp_error( $terms ) || count( $terms ) < 2 ) {
			return array();
		}

		$current = wp_get_post_terms( $id, $property['taxonomy'], array( 'fields' => 'slugs' ) );
		$current = is_wp_error( $current ) ? array() : $current;

		$links = array();

		foreach ( $terms as $term ) {
			$links[] = array(
				'label'   => $term->name,
				'url'     => mvweb_core_filter_url( 0, array( $slug => array( $term->slug ) ), mvweb_core_catalog_page_url() ),
				'current' => in_array( $term->slug, $current, true ),
			);
		}

		return array(
			'label' => $property['label'],
			'terms' => $links,
		);
	}
}

if ( ! function_exists( 'mvweb_core_item_choices' ) ) {
	/**
	 * Every published item of the catalogue, as the options of a list.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Item id => title, the empty choice first.
	 */
	function mvweb_core_item_choices() {
		static $choices = null;

		if ( null !== $choices ) {
			return $choices;
		}

		$choices = array( '' => __( '— Choose a product —', 'mvweb-core' ) );
		$posts   = get_posts(
			array(
				'post_type'              => mvweb_core_is_woocommerce() ? 'product' : 'mv_item',
				'post_status'            => 'publish',
				'numberposts'            => -1,
				'orderby'                => 'title',
				'order'                  => 'ASC',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		foreach ( $posts as $post ) {
			$choices[ (string) $post->ID ] = wp_strip_all_tags( get_the_title( $post ) );
		}

		return $choices;
	}
}

if ( ! function_exists( 'mvweb_core_showcase_items' ) ) {
	/**
	 * Items for the showcase section.
	 *
	 * @since 0.1.0
	 *
	 * @param string $source Manual, featured or recent.
	 * @param int    $limit  How many to return; not used for manual.
	 * @param int[]  $picked Items chosen by hand, in their order.
	 *
	 * @return int[]
	 */
	function mvweb_core_showcase_items( $source, $limit, $picked = array() ) {
		if ( 'manual' === $source ) {
			$picked = array_values( array_unique( array_filter( array_map( 'absint', (array) $picked ) ) ) );

			return mvweb_core_prime_items( array_filter( $picked, 'mvweb_core_item_visible' ) );
		}

		$limit = $limit > 0 ? (int) $limit : 4;

		if ( mvweb_core_is_woocommerce() ) {
			$args = array(
				'status'     => 'publish',
				'limit'      => $limit,
				'return'     => 'ids',
				'visibility' => 'catalog',
			);

			if ( 'recent' === $source ) {
				$args['orderby'] = 'date';
				$args['order']   = 'DESC';
			} else {
				$args['featured'] = true;
				$args['orderby']  = 'menu_order';
				$args['order']    = 'ASC';
			}

			$ids = wc_get_products( $args );

			return mvweb_core_prime_items( $ids );
		}

		$args = array(
			'post_type'        => 'mv_item',
			'post_status'      => 'publish',
			'numberposts'      => $limit,
			'fields'           => 'ids',
			'suppress_filters' => false,
		);

		if ( 'recent' === $source ) {
			$args['orderby'] = 'date';
			$args['order']   = 'DESC';
		} else {
			$args['meta_key']   = '_mvweb_featured'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Indexed lookup over a handful of flagged items.
			$args['meta_value'] = '1'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- See above.
			$args['orderby']    = array(
				'menu_order' => 'ASC',
				'date'       => 'DESC',
			);
		}

		return mvweb_core_prime_items( get_posts( $args ) );
	}
}

if ( ! function_exists( 'mvweb_core_category_cards' ) ) {
	/**
	 * Top level catalogue categories, shaped like the cards of a section.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $limit    How many to return. 0 for all.
	 * @param string $taxonomy Taxonomy to walk. Empty for the catalogue's own.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_category_cards( $limit = 0, $taxonomy = '' ) {
		$taxonomy = '' === $taxonomy ? mvweb_core_taxonomy() : $taxonomy;

		if ( ! taxonomy_exists( $taxonomy ) ) {
			return array();
		}

		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'parent'     => 0,
				'hide_empty' => true,
				'number'     => $limit > 0 ? (int) $limit : 0,
			)
		);

		if ( is_wp_error( $terms ) ) {
			return array();
		}

		$cards = array();

		foreach ( $terms as $term ) {
			$cards[] = array(
				'image' => absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) ),
				'title' => $term->name,
				'url'   => (string) get_term_link( $term ),
				'wide'  => false,
			);
		}

		return $cards;
	}
}

if ( ! function_exists( 'mvweb_core_product_benefits' ) ) {
	/**
	 * Lines of the benefits list.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_product_benefits() {
		$rows = json_decode( (string) get_theme_mod( 'mvweb_product_benefits', '' ), true );

		if ( ! is_array( $rows ) ) {
			return array();
		}

		$lines = array();

		foreach ( $rows as $row ) {
			$text = is_array( $row ) && isset( $row['text'] ) ? trim( (string) $row['text'] ) : '';

			if ( '' !== $text ) {
				$lines[] = $text;
			}
		}

		return $lines;
	}
}

if ( ! function_exists( 'mvweb_core_catalog_url' ) ) {
	/**
	 * Address the filter form submits to.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_catalog_url() {
		$facet = mvweb_core_current_facet();

		return $facet ? mvweb_core_facet_url( $facet ) : mvweb_core_catalog_base_url();
	}
}

if ( ! function_exists( 'mvweb_core_catalog_base_url' ) ) {
	/**
	 * Address of the listing being shown, a filter page included: its category.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_catalog_base_url() {
		$object = get_queried_object();

		if ( $object instanceof WP_Term && mvweb_core_taxonomy() === $object->taxonomy ) {
			$link = get_term_link( $object );

			if ( ! is_wp_error( $link ) ) {
				return $link;
			}
		}

		return mvweb_core_catalog_page_url();
	}
}

if ( ! function_exists( 'mvweb_core_is_catalog_term' ) ) {
	/**
	 * Whether a term belongs to the catalogue.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Term to judge.
	 *
	 * @return bool
	 */
	function mvweb_core_is_catalog_term( $term ) {
		if ( ! $term instanceof WP_Term ) {
			return false;
		}

		if ( mvweb_core_is_woocommerce() ) {
			return in_array( $term->taxonomy, (array) get_object_taxonomies( 'product' ), true );
		}

		$taxonomies = array( mvweb_core_taxonomy() );

		foreach ( mvweb_core_properties() as $property ) {
			$taxonomies[] = $property['taxonomy'];
		}

		return in_array( $term->taxonomy, $taxonomies, true );
	}
}

if ( ! function_exists( 'mvweb_core_term_objects' ) ) {
	/**
	 * Ids filed under a term or under any term below it.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Term to walk.
	 *
	 * @return int[]
	 */
	function mvweb_core_term_objects( $term ) {
		if ( ! $term instanceof WP_Term ) {
			return array();
		}

		$branch = get_term_children( $term->term_id, $term->taxonomy );
		$branch = is_wp_error( $branch ) ? array() : $branch;

		$branch[] = $term->term_id;

		$ids = get_objects_in_term( $branch, $term->taxonomy );

		return is_wp_error( $ids ) ? array() : array_map( 'absint', $ids );
	}
}

if ( ! function_exists( 'mvweb_core_catalog_scope' ) ) {
	/**
	 * Ids the listing is limited to, or null on an unfiltered catalogue.
	 *
	 * @since 0.1.0
	 *
	 * @return int[]|null
	 */
	function mvweb_core_catalog_scope() {
		$current = get_queried_object();

		if ( ! $current instanceof WP_Term || ! mvweb_core_is_catalog_term( $current ) ) {
			return null;
		}

		return mvweb_core_term_objects( $current );
	}
}

if ( ! function_exists( 'mvweb_core_catalog_selected' ) ) {
	/**
	 * Term slugs a visitor ticked for one property.
	 *
	 * @since 0.1.0
	 *
	 * @param string $slug Property slug.
	 *
	 * @return string[]
	 */
	function mvweb_core_catalog_selected( $slug ) {
		$selected = mvweb_core_catalog_requested( $slug );
		$facet    = mvweb_core_current_facet();

		if ( $facet ) {
			$own      = mvweb_core_facet_selection( $facet );
			$selected = array_values( array_unique( array_merge( $selected, isset( $own[ $slug ] ) ? $own[ $slug ] : array() ) ) );
		}

		return $selected;
	}
}

if ( ! function_exists( 'mvweb_core_catalog_selection' ) ) {
	/**
	 * Ticked values of every property, empty ones left out.
	 *
	 * @since 0.1.0
	 *
	 * @param bool $with_facet Whether the values of the filter page count too.
	 *
	 * @return array<string,string[]> Term slugs keyed by property slug.
	 */
	function mvweb_core_catalog_selection( $with_facet = true ) {
		$selection = array();

		foreach ( mvweb_core_properties() as $property ) {
			$values = $with_facet ? mvweb_core_catalog_selected( $property['slug'] ) : mvweb_core_catalog_requested( $property['slug'] );

			if ( $values ) {
				$selection[ $property['slug'] ] = $values;
			}
		}

		return $selection;
	}
}

if ( ! function_exists( 'mvweb_core_catalog_requested' ) ) {
	/**
	 * Term slugs the address asks for one property, the filter page aside.
	 *
	 * @since 0.1.0
	 *
	 * @param string $slug Property slug.
	 *
	 * @return string[]
	 */
	function mvweb_core_catalog_requested( $slug ) {
		$key = 'filter_' . $slug;

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading a public listing filter, not acting on it.
		if ( ! isset( $_GET[ $key ] ) ) {
			return array();
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading a public listing filter, not acting on it.
		$raw = sanitize_text_field( wp_unslash( $_GET[ $key ] ) );

		return array_values( array_filter( array_map( 'sanitize_title', explode( ',', $raw ) ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_catalog_filters' ) ) {
	/**
	 * Property groups for the sidebar.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_catalog_filters() {
		$groups = array();
		$scope  = mvweb_core_catalog_scope();

		foreach ( mvweb_core_properties() as $property ) {
			if ( isset( $property['sidebar'] ) && ! $property['sidebar'] ) {
				continue;
			}

			$args = array(
				'taxonomy'   => $property['taxonomy'],
				'hide_empty' => true,
			);

			if ( is_array( $scope ) ) {
				if ( empty( $scope ) ) {
					continue;
				}

				$args['object_ids'] = $scope;
			}

			$terms = get_terms( $args );

			if ( is_wp_error( $terms ) || empty( $terms ) ) {
				continue;
			}

			$groups[] = array(
				'slug'     => $property['slug'],
				'label'    => $property['label'],
				'terms'    => $terms,
				'selected' => mvweb_core_catalog_selected( $property['slug'] ),
			);
		}

		/**
		 * Filter the property groups the catalog sidebar prints.
		 *
		 * @since 0.1.0
		 *
		 * @param array<int,array<string,mixed>> $groups Groups in print order.
		 */
		return (array) apply_filters( 'mvweb_core_catalog_filters', $groups );
	}
}

if ( ! function_exists( 'mvweb_core_catalog_subcategories' ) ) {
	/**
	 * The sidebar group of subcategories for the listing being shown.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>|null Group in the shape of a property group.
	 */
	function mvweb_core_catalog_subcategories() {
		$taxonomy = mvweb_core_taxonomy();
		$current  = get_queried_object();

		if ( $current instanceof WP_Term ) {
			if ( $taxonomy !== $current->taxonomy ) {
				return null;
			}

			$parent = $current->term_id;
		} else {
			$parent = 0;
		}

		$args = array(
			'taxonomy'   => $taxonomy,
			'parent'     => $parent,
			'hide_empty' => true,
		);

		if ( mvweb_core_is_woocommerce() ) {
			$args['exclude'] = array( absint( get_option( 'default_product_cat' ) ) );
		}

		$terms = get_terms( $args );

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return null;
		}

		return array(
			'slug'     => 'subcategory',
			'label'    => __( 'Subcategories', 'mvweb-core' ),
			'terms'    => $terms,
			'selected' => mvweb_core_catalog_selected( 'subcategory' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_subcategory_tax_query' ) ) {
	/**
	 * The ticked subcategories as a taxonomy clause, children included.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_subcategory_tax_query() {
		$selected = mvweb_core_catalog_selected( 'subcategory' );

		if ( empty( $selected ) ) {
			return null;
		}

		return array(
			'taxonomy'         => mvweb_core_taxonomy(),
			'field'            => 'slug',
			'terms'            => $selected,
			'operator'         => 'IN',
			'include_children' => true,
		);
	}
}

if ( ! function_exists( 'mvweb_core_catalog_orderings' ) ) {
	/**
	 * Orders a visitor can sort the listing by.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_catalog_orderings() {
		/**
		 * Filters the orders a visitor can sort the listing by.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $orderings Order key => label.
		 */
		return (array) apply_filters(
			'mvweb_core_catalog_orderings',
			array(
				'menu_order' => __( 'Default', 'mvweb-core' ),
				'date'       => __( 'Newest first', 'mvweb-core' ),
				'price'      => __( 'Price: low to high', 'mvweb-core' ),
				'price-desc' => __( 'Price: high to low', 'mvweb-core' ),
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_catalog_orderby' ) ) {
	/**
	 * The order the visitor asked for, or the default one.
	 *
	 * @since 0.1.0
	 *
	 * @return string A key of mvweb_core_catalog_orderings().
	 */
	function mvweb_core_catalog_orderby() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading a public listing order, not acting on it.
		$orderby = isset( $_GET['orderby'] ) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : '';

		return array_key_exists( $orderby, mvweb_core_catalog_orderings() ) ? $orderby : 'menu_order';
	}
}

if ( ! function_exists( 'mvweb_core_catalog_query_args' ) ) {
	/**
	 * Filter and order parameters of the current request.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $skip Parameter names to leave out.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_catalog_query_args( $skip = array() ) {
		$args = array();

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading public listing parameters, not acting on them.
		foreach ( wp_unslash( $_GET ) as $key => $value ) {
			$key = sanitize_key( $key );

			if ( in_array( $key, $skip, true ) || ! is_string( $value ) ) {
				continue;
			}

			if ( in_array( $key, array( 'min_price', 'max_price', 'orderby' ), true ) || str_starts_with( $key, 'filter_' ) || str_starts_with( $key, 'query_type_' ) ) {
				$args[ $key ] = sanitize_text_field( $value );
			}
		}

		return $args;
	}
}

if ( ! function_exists( 'mvweb_core_catalog_is_filtered' ) ) {
	/**
	 * Whether the visitor narrowed the listing.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_catalog_is_filtered() {
		if ( ! empty( mvweb_core_catalog_requested( 'subcategory' ) ) ) {
			return true;
		}

		foreach ( mvweb_core_properties() as $property ) {
			if ( ! empty( mvweb_core_catalog_requested( $property['slug'] ) ) ) {
				return true;
			}
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading a public listing filter, not acting on it.
		return isset( $_GET['min_price'] ) || isset( $_GET['max_price'] );
	}
}

if ( ! function_exists( 'mvweb_core_catalog_price_bound' ) ) {
	/**
	 * The value a price field should show back to the visitor.
	 *
	 * @since 0.1.0
	 *
	 * @param string $key Either min_price or max_price.
	 *
	 * @return string
	 */
	function mvweb_core_catalog_price_bound( $key ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading a public listing filter, not acting on it.
		if ( ! isset( $_GET[ $key ] ) ) {
			return '';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading a public listing filter, not acting on it.
		return mvweb_core_sanitize_amount( sanitize_text_field( wp_unslash( $_GET[ $key ] ) ) );
	}
}
