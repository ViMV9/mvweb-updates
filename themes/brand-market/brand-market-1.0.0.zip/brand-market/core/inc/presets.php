<?php
/**
 * Ready-made sets of rows for the page builder.
 *
 * Every file of inc/presets/ adds the sets of one page kind to the registry
 * of mvweb_core_section_presets(), so the sets do not share a file.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

foreach ( (array) glob( MVWEB_CORE_DIR . '/inc/presets/*.php' ) as $mvweb_core_preset_module ) {
	require_once $mvweb_core_preset_module;
}
unset( $mvweb_core_preset_module );
