<?php
/**
 * Breadcrumb trail.
 *
 * The trail itself comes from core: WordPress 7.0 ships core/breadcrumbs, and
 * its render already walks the home page, the posts page, hierarchical parents,
 * taxonomy terms, archives, search, 404 and pagination — in the site language.
 * A hand-written builder would only be a worse copy of it.
 *
 * What the theme cannot take from core is the markup: the block prints its own
 * classes and pulls its own stylesheet. So the block is rendered for its data,
 * the item list is caught on the filter core fires just before it builds HTML,
 * and the markup here is the theme's own.
 *
 * Two corrections on top of core. A trail mirrors the address: an entry whose
 * address holds no section gets no section crumb, and a section page gets the
 * listing it belongs to. The same trail feeds Yoast's BreadcrumbList, so the
 * markup never tells a search engine a different path than the page shows.
 *
 * MVweb Site Optimizer's "remove the last item" switch is written for Yoast's
 * trail, which this theme does not print, so the theme honours it itself — on
 * the page only: the markup keeps the current page as its last item.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_crumb_trail' ) ) {
	/**
	 * The whole breadcrumb trail of the current request, current page included.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>> Items with 'label', optional 'url'
	 *                                        and optional 'allow_html'.
	 */
	function mvweb_core_crumb_trail() {
		static $trail = null;

		if ( null !== $trail ) {
			return $trail;
		}

		$trail = array();

		if ( ! WP_Block_Type_Registry::get_instance()->is_registered( 'core/breadcrumbs' ) ) {
			return $trail;
		}

		$items = array();

		$capture = static function ( $collected ) use ( &$items ) {
			$items = $collected;

			return $collected;
		};

		add_filter( 'block_core_breadcrumbs_items', $capture, PHP_INT_MAX );

		render_block(
			array(
				'blockName'    => 'core/breadcrumbs',
				'attrs'        => array( 'showOnHomePage' => false ),
				'innerBlocks'  => array(),
				'innerHTML'    => '',
				'innerContent' => array(),
			)
		);

		remove_filter( 'block_core_breadcrumbs_items', $capture, PHP_INT_MAX );

		$items = is_array( $items ) ? $items : array();

		if ( is_singular() ) {
			$items = mvweb_core_crumb_follow_address( $items );
		}

		$archive = mvweb_core_crumb_term_archive();

		if ( $archive && ! empty( $items ) ) {
			array_splice( $items, 1, 0, array( $archive ) );
		}

		/**
		 * Filter the breadcrumb trail.
		 *
		 * @since 0.1.0
		 *
		 * @param array<int,array<string,mixed>> $items Trail items.
		 */
		$trail = (array) apply_filters( 'mvweb_core_crumb_items', $items );

		return $trail;
	}
}

if ( ! function_exists( 'mvweb_core_crumb_items' ) ) {
	/**
	 * The breadcrumb trail as the page prints it.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>> Trail items.
	 */
	function mvweb_core_crumb_items() {
		$items = mvweb_core_crumb_trail();

		if ( function_exists( 'mvweb_so_check_option' ) && mvweb_so_check_option( 'remove_last_item_breadcrumb_yoast' ) ) {
			array_pop( $items );
		}

		return $items;
	}
}

if ( ! function_exists( 'mvweb_core_crumb_follow_address' ) ) {
	/**
	 * Drop the crumbs of an entry that its address does not pass through.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $items Trail items.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_crumb_follow_address( $items ) {
		$own  = untrailingslashit( (string) get_permalink() );
		$keep = array(
			untrailingslashit( home_url() ),
			untrailingslashit( (string) get_post_type_archive_link( (string) get_post_type() ) ),
			$own,
		);

		return array_values(
			array_filter(
				$items,
				static function ( $item ) use ( $own, $keep ) {
					if ( empty( $item['url'] ) ) {
						return true;
					}

					$url = untrailingslashit( (string) $item['url'] );

					return in_array( $url, $keep, true ) || str_starts_with( $own . '/', $url . '/' );
				}
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_crumb_term_archive' ) ) {
	/**
	 * The listing a section page belongs to, as a crumb.
	 *
	 * @since 0.1.0
	 *
	 * @return array{label:string,url:string}|null Null outside a section page,
	 *                                             or when the listing is home.
	 */
	function mvweb_core_crumb_term_archive() {
		$term = get_queried_object();

		if ( ! $term instanceof WP_Term || ! ( is_tax() || is_category() || is_tag() ) ) {
			return null;
		}

		$taxonomy = get_taxonomy( $term->taxonomy );

		foreach ( $taxonomy ? (array) $taxonomy->object_type : array() as $post_type ) {
			$url = get_post_type_archive_link( $post_type );

			if ( ! $url || untrailingslashit( home_url() ) === untrailingslashit( $url ) ) {
				continue;
			}

			$page  = (int) get_option( 'page_for_posts' );
			$label = 'post' === $post_type && $page ? get_the_title( $page ) : get_post_type_object( $post_type )->labels->archives;

			return array(
				'label' => $label,
				'url'   => $url,
			);
		}

		return null;
	}
}

if ( ! function_exists( 'mvweb_core_yoast_crumbs' ) ) {
	/**
	 * Hand the theme's trail to Yoast, whose BreadcrumbList is the markup.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $crumbs Yoast's own trail.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_yoast_crumbs( $crumbs ) {
		if ( is_admin() || ! did_action( 'wp' ) || is_front_page() ) {
			return $crumbs;
		}

		$trail = mvweb_core_crumb_trail();

		if ( count( $trail ) < 2 ) {
			return $crumbs;
		}

		return array_map(
			static function ( $item ) {
				return array(
					'url'  => isset( $item['url'] ) ? (string) $item['url'] : '',
					'text' => html_entity_decode( wp_strip_all_tags( (string) $item['label'] ), ENT_QUOTES, 'UTF-8' ),
				);
			},
			$trail
		);
	}
}
add_filter( 'wpseo_breadcrumb_links', 'mvweb_core_yoast_crumbs' );
