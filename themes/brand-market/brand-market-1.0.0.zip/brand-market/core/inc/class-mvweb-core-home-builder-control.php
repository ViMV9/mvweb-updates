<?php
/**
 * The Customizer control that holds the blocks of the homepage.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The page builder inside the Customizer.
 *
 * @since 0.1.0
 */
class MVweb_Core_Home_Builder_Control extends WP_Customize_Control {

	/**
	 * Control type.
	 *
	 * @var string
	 */
	public $type = 'mvweb_home_builder';

	/**
	 * Print the builder.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	public function render_content() {
		$rows = json_decode( (string) $this->value(), true, 10 );
		?>
		<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
		<?php if ( '' !== $this->description ) : ?>
			<span class="description customize-control-description"><?php echo esc_html( $this->description ); ?></span>
			<?php
		endif;

		mvweb_core_sections_builder( is_array( $rows ) ? $rows : array(), '', $this->id );
	}
}
