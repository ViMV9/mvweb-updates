<?php
/**
 * Fields every block carries besides its own: the view, the look and the animation.
 *
 * The registry adds them, so a block declares only what is its own. The names
 * of the views belong to the theme: the data keeps a key.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_section_views' ) ) {
	/**
	 * The views a theme draws for a block type.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type Block type.
	 *
	 * @return array<string,string> View key => name; empty when there is no choice to make.
	 */
	function mvweb_core_section_views( $type ) {
		/**
		 * Filter the views of a block type.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $views View key => name.
		 * @param string               $type  Block type.
		 */
		$raw   = (array) apply_filters( 'mvweb_core_section_views', array(), $type );
		$views = array();

		foreach ( $raw as $key => $name ) {
			$key = sanitize_key( $key );

			if ( '' !== $key && is_string( $name ) && '' !== $name ) {
				$views[ $key ] = $name;
			}
		}

		return count( $views ) > 1 ? $views : array();
	}
}

if ( ! function_exists( 'mvweb_core_look_colour_field' ) ) {
	/**
	 * A colour field of the look group, shown while the background is the editor's own.
	 *
	 * @since 0.1.0
	 *
	 * @param string $label Field label.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_look_colour_field( $label ) {
		return array(
			'type'      => 'color',
			'group'     => __( 'Block design', 'mvweb-core' ),
			'label'     => $label,
			'show_when' => array(
				'field' => 'background',
				'in'    => array( 'custom' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_cards_colour_fields' ) ) {
	/**
	 * The colours of the cards and the icons of a block, shown while the block has a background.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_cards_colour_fields() {
		$when = array(
			'field' => 'background',
			'in'    => array( 'surface', 'accent', 'inverse', 'custom' ),
		);

		return array(
			'cards_bg'   => array(
				'type'      => 'color',
				'look'      => true,
				'label'     => __( 'Background of the cards', 'mvweb-core' ),
				'show_when' => $when,
			),
			'cards_ink'  => array(
				'type'        => 'color',
				'look'        => true,
				'label'       => __( 'Text colour of the cards', 'mvweb-core' ),
				'description' => __( 'Works with the background of the cards. Empty colour is picked by itself, black or white.', 'mvweb-core' ),
				'show_when'   => $when,
			),
			'cards_icon' => array(
				'type'        => 'color',
				'look'        => true,
				'label'       => __( 'Colour of the icons', 'mvweb-core' ),
				'description' => __( 'The plate under the icon or number; the sign on it is black or white by itself. The colours of the cards stay the same in the dark scheme.', 'mvweb-core' ),
				'show_when'   => $when,
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_section_common_fields' ) ) {
	/**
	 * Split a block's fields and add the common ones around them.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type Block type.
	 * @param array  $own  Raw fields the block declared.
	 *
	 * @return array{first:array,own:array,last:array} Fields before the block's own, the block's own, and after.
	 */
	function mvweb_core_section_common_fields( $type, array $own ) {
		$first = array();
		$views = mvweb_core_section_views( $type );

		if ( ! empty( $views ) ) {
			$first['view'] = array(
				'type'    => 'select',
				'label'   => __( 'View', 'mvweb-core' ),
				'choices' => $views,
				'default' => (string) array_key_first( $views ),
			);
		}

		unset( $own['background'] );

		$look = __( 'Block design', 'mvweb-core' );
		$last = array(
			'background'     => array(
				'type'    => 'select',
				'group'   => $look,
				'label'   => __( 'Background', 'mvweb-core' ),
				'choices' => array(
					'plain'   => __( 'Page background', 'mvweb-core' ),
					'surface' => __( 'Tinted', 'mvweb-core' ),
					'accent'  => __( 'Accent colour', 'mvweb-core' ),
					'inverse' => __( 'Inverse, dark', 'mvweb-core' ),
					'custom'  => __( 'Own colours', 'mvweb-core' ),
				),
				'default' => 'plain',
			),
			'bg_color'       => mvweb_core_look_colour_field( __( 'Background colour', 'mvweb-core' ) ),
			'ink_color'      => mvweb_core_look_colour_field( __( 'Text colour', 'mvweb-core' ) ),
			'bg_color_dark'  => mvweb_core_look_colour_field( __( 'Background colour, dark scheme', 'mvweb-core' ) ),
			'ink_color_dark' => mvweb_core_look_colour_field( __( 'Text colour, dark scheme', 'mvweb-core' ) ),
		);

		$last['ink_color']['description'] = __( 'Empty text colour is picked by itself, black or white. The dark scheme keeps the light colours until its own are set.', 'mvweb-core' );

		foreach ( $own as $key => $field ) {
			if ( ! empty( $field['look'] ) ) {
				unset( $field['look'], $own[ $key ] );
				$field['group'] = $look;
				$last[ $key ]   = $field;
			}
		}

		if ( isset( $own['image'] ) && 'image' === $own['image']['type'] ) {
			$side = isset( $own['image']['side'] ) && 'end' === $own['image']['side'] ? 'end' : 'start';

			unset( $own['image']['side'] );

			$last['image_side'] = array(
				'type'    => 'select',
				'group'   => $look,
				'label'   => __( 'Picture side', 'mvweb-core' ),
				'choices' => array(
					'start' => __( 'Left', 'mvweb-core' ),
					'end'   => __( 'Right', 'mvweb-core' ),
				),
				'default' => $side,
			);
			$last['image_size'] = array(
				'type'    => 'select',
				'group'   => $look,
				'label'   => __( 'Picture size', 'mvweb-core' ),
				'choices' => array(
					's' => __( 'Small', 'mvweb-core' ),
					'm' => __( 'Medium', 'mvweb-core' ),
					'l' => __( 'Large', 'mvweb-core' ),
				),
				'default' => 'm',
			);
		}

		if ( isset( $own['button_text'] ) ) {
			$last['button_kind'] = array(
				'type'    => 'select',
				'group'   => $look,
				'label'   => __( 'Button look', 'mvweb-core' ),
				'choices' => array(
					'primary'   => __( 'Filled', 'mvweb-core' ),
					'secondary' => __( 'Outlined', 'mvweb-core' ),
					'link'      => __( 'Link', 'mvweb-core' ),
				),
				'default' => 'primary',
			);
		}

		$last['motion'] = array(
			'type'    => 'select',
			'group'   => __( 'Animation', 'mvweb-core' ),
			'label'   => __( 'Animation on appearance', 'mvweb-core' ),
			'choices' => array(
				'auto' => __( 'As in the view', 'mvweb-core' ),
				'none' => __( 'No animation', 'mvweb-core' ),
			),
			'default' => 'auto',
		);

		return array(
			'first' => $first,
			'own'   => $own,
			'last'  => $last,
		);
	}
}

if ( ! function_exists( 'mvweb_core_view' ) ) {
	/**
	 * The chosen view of a block.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props Values of the block.
	 *
	 * @return string Empty when the block has one look only.
	 */
	function mvweb_core_view( array $props ) {
		return isset( $props['view'] ) ? sanitize_key( $props['view'] ) : '';
	}
}

if ( ! function_exists( 'mvweb_core_contrast_ratio' ) ) {
	/**
	 * The WCAG contrast ratio of two colours.
	 *
	 * @since 0.1.0
	 *
	 * @param string $a Hex colour.
	 * @param string $b Hex colour.
	 *
	 * @return float 1 to 21.
	 */
	function mvweb_core_contrast_ratio( $a, $b ) {
		$luminance = static function ( $hex ) {
			$hex = ltrim( (string) $hex, '#' );
			$hex = 3 === strlen( $hex ) ? $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2] : $hex;
			$sum = 0.0;

			foreach ( array( 0.2126, 0.7152, 0.0722 ) as $i => $weight ) {
				$value = hexdec( substr( $hex, $i * 2, 2 ) ) / 255;
				$sum  += $weight * ( $value <= 0.03928 ? $value / 12.92 : pow( ( $value + 0.055 ) / 1.055, 2.4 ) );
			}

			return $sum;
		};

		$one = $luminance( $a );
		$two = $luminance( $b );

		return ( max( $one, $two ) + 0.05 ) / ( min( $one, $two ) + 0.05 );
	}
}

if ( ! function_exists( 'mvweb_core_readable_ink' ) ) {
	/**
	 * The text colour a background can always be read with.
	 *
	 * @since 0.1.0
	 *
	 * @param string $background Hex colour.
	 *
	 * @return string
	 */
	function mvweb_core_readable_ink( $background ) {
		return mvweb_core_contrast_ratio( $background, '#ffffff' ) >= mvweb_core_contrast_ratio( $background, '#000000' ) ? '#ffffff' : '#000000';
	}
}

if ( ! function_exists( 'mvweb_core_section_look' ) ) {
	/**
	 * The look of a block, ready for the template.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props Values of the block.
	 *
	 * @return array{background:string,style:string,image_side:string,image_size:string,button_kind:string}
	 */
	function mvweb_core_section_look( array $props ) {
		$background = isset( $props['background'] ) ? (string) $props['background'] : 'plain';
		$style      = '';

		if ( 'custom' === $background ) {
			$bg = isset( $props['bg_color'] ) ? (string) $props['bg_color'] : '';

			if ( '' === $bg ) {
				$background = 'plain';
			} else {
				$pairs   = array(
					array(
						'bg'  => $bg,
						'ink' => isset( $props['ink_color'] ) ? (string) $props['ink_color'] : '',
					),
				);
				$dark    = isset( $props['bg_color_dark'] ) ? (string) $props['bg_color_dark'] : '';
				$pairs[] = array(
					'bg'  => '' !== $dark ? $dark : $bg,
					'ink' => '' !== $dark ? ( isset( $props['ink_color_dark'] ) ? (string) $props['ink_color_dark'] : '' ) : $pairs[0]['ink'],
				);

				$names = array( 'light', 'dark' );

				foreach ( $pairs as $i => $pair ) {
					$ink    = '' !== $pair['ink'] && mvweb_core_contrast_ratio( $pair['bg'], $pair['ink'] ) >= 4.5 ? $pair['ink'] : mvweb_core_readable_ink( $pair['bg'] );
					$style .= '--mvweb-t-sec-bg-' . $names[ $i ] . ':' . $pair['bg'] . ';--mvweb-t-sec-ink-' . $names[ $i ] . ':' . $ink . ';';
				}
			}
		}

		return array(
			'background'  => $background,
			'style'       => $style,
			'image_side'  => isset( $props['image_side'] ) ? (string) $props['image_side'] : 'start',
			'image_size'  => isset( $props['image_size'] ) ? (string) $props['image_size'] : 'm',
			'button_kind' => isset( $props['button_kind'] ) ? (string) $props['button_kind'] : 'primary',
		);
	}
}
