<?php
/**
 * The frame of every page: the zones the header and the footer add, and their settings.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_frame_zones' ) ) {
	/**
	 * The zones the frame adds to the header.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $zones Zone slug => label.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_frame_zones( $zones ) {
		$zones['header-nav']         = __( 'Menu row', 'mvweb-core' );
		$zones['header-drawer-foot'] = __( 'Bottom of the mobile menu', 'mvweb-core' );

		return $zones;
	}
}
add_filter( 'mvweb_core_zones', 'mvweb_core_frame_zones' );

if ( ! function_exists( 'mvweb_core_frame_elements' ) ) {
	/**
	 * The elements the frame adds to the zones.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $elements Element slug => label.
	 * @param string               $zone     Zone slug.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_frame_elements( $elements, $zone ) {
		$more = array(
			'header-topbar'      => array(
				'city'   => __( 'City choice', 'mvweb-core' ),
				'notice' => __( 'Announcement', 'mvweb-core' ),
			),
			'header-actions'     => array(
				'account' => __( 'Account', 'mvweb-core' ),
			),
			'header-nav'         => array(
				'catalog-button' => __( 'Catalogue button', 'mvweb-core' ),
				'menu-primary'   => __( 'Primary menu', 'mvweb-core' ),
				'menu-button'    => __( 'Menu button', 'mvweb-core' ),
				'search-form'    => __( 'Search field', 'mvweb-core' ),
				'search'         => __( 'Search', 'mvweb-core' ),
				'favorites'      => __( 'Favourites', 'mvweb-core' ),
				'account'        => __( 'Account', 'mvweb-core' ),
				'cart'           => __( 'Cart', 'mvweb-core' ),
			),
			'header-drawer-foot' => array(
				'socials' => __( 'Social networks', 'mvweb-core' ),
				'scheme'  => __( 'Colour scheme switch', 'mvweb-core' ),
			),
		);

		return isset( $more[ $zone ] ) ? array_merge( $elements, $more[ $zone ] ) : $elements;
	}
}
add_filter( 'mvweb_core_zone_elements', 'mvweb_core_frame_elements', 10, 2 );

if ( ! function_exists( 'mvweb_core_frame_zone_sections' ) ) {
	/**
	 * The Customizer sections of the added zones.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $sections Zone slug => section id.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_frame_zone_sections( $sections ) {
		$sections['header-nav']         = 'mvweb_cz_header_blocks';
		$sections['header-drawer-foot'] = 'mvweb_cz_header_drawer';

		return $sections;
	}
}
add_filter( 'mvweb_core_zone_sections', 'mvweb_core_frame_zone_sections' );

if ( ! function_exists( 'mvweb_core_frame_html_settings' ) ) {
	/**
	 * The settings the look of the frame depends on, ready for the root element.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Attribute name => value.
	 */
	function mvweb_core_frame_html_settings() {
		$layout = (string) get_theme_mod( 'mvweb_header_layout', 'simple' );
		$icon   = (string) get_theme_mod( 'mvweb_header_phone_icon', 'none' );
		$width  = (string) get_theme_mod( 'mvweb_container_width', '1280' );

		return array(
			'data-header-view' => in_array( $layout, array( 'simple', 'extended', 'compact' ), true ) ? $layout : 'simple',
			'data-hc-icon'     => in_array( $icon, array( 'none', 'plate', 'circle' ), true ) ? $icon : 'none',
			'data-container'   => in_array( $width, array( '1280', '1440', '1920' ), true ) ? $width : '1280',
			'data-menu-icons'  => get_theme_mod( 'mvweb_menu_icons', true ) ? 'on' : 'off',
			'data-city'        => function_exists( 'mvweb_core_has_city_choice' ) && mvweb_core_has_city_choice() ? 'on' : 'off',
		);
	}
}

if ( ! function_exists( 'mvweb_core_frame_fields' ) ) {
	/**
	 * The settings of the header, the footer and the pages around the content.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_frame_fields() {
		$header = 'mvweb_cz_header_blocks';
		$inner  = 'mvweb_cz_inner_frame';

		return array(
			array(
				'type'        => 'radio',
				'settings'    => 'mvweb_header_layout',
				'section'     => $header,
				'label'       => __( 'Header view', 'mvweb-core' ),
				'description' => __( 'Where the search, the contacts and the icons stand.', 'mvweb-core' ),
				'default'     => 'simple',
				'priority'    => 1,
				'choices'     => array(
					'simple'   => __( 'Search in the header, one phone', 'mvweb-core' ),
					'extended' => __( 'Contacts on the right, search in the menu row', 'mvweb-core' ),
					'compact'  => __( 'Menu on the left, search as an icon', 'mvweb-core' ),
				),
			),
			array(
				'type'     => 'radio',
				'settings' => 'mvweb_header_phone_icon',
				'section'  => $header,
				'label'    => __( 'Icon beside the phone', 'mvweb-core' ),
				'default'  => 'none',
				'priority' => 2,
				'choices'  => array(
					'none'   => __( 'No icon', 'mvweb-core' ),
					'plate'  => __( 'On the plate', 'mvweb-core' ),
					'circle' => __( 'In a circle', 'mvweb-core' ),
				),
			),
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_menu_icons',
				'section'     => $header,
				'label'       => __( 'Icons of the menu items', 'mvweb-core' ),
				'description' => __( 'The icon of an item is chosen in Appearance → Menus. Shown in the menus and the wide header only.', 'mvweb-core' ),
				'default'     => true,
				'priority'    => 3,
			),
			array(
				'type'     => 'toggle',
				'settings' => 'mvweb_catalog_button',
				'section'  => $header,
				'label'    => __( 'Catalogue button', 'mvweb-core' ),
				'default'  => true,
				'priority' => 4,
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_catalog_button_label',
				'section'     => $header,
				'label'       => __( 'Catalogue button caption', 'mvweb-core' ),
				'description' => __( 'Empty — “Catalogue”.', 'mvweb-core' ),
				'default'     => '',
				'priority'    => 5,
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_notice_link_text',
				'section'     => $header,
				'label'       => __( 'Link caption of the announcement', 'mvweb-core' ),
				'description' => __( 'For example “More”. Empty — the whole line is the link.', 'mvweb-core' ),
				'default'     => '',
			),
			array(
				'type'     => 'toggle',
				'settings' => 'mvweb_notice_closable',
				'section'  => $header,
				'label'    => __( 'Visitor can close the announcement', 'mvweb-core' ),
				'default'  => true,
			),
			array(
				'type'        => 'media',
				'settings'    => 'mvweb_mega_preview_image',
				'section'     => 'mvweb_cz_header_brand',
				'label'       => __( 'Picture of the mega menu', 'mvweb-core' ),
				'description' => __( 'One picture beside the columns of the catalogue menu.', 'mvweb-core' ),
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_mega_preview_caption',
				'section'  => 'mvweb_cz_header_brand',
				'label'    => __( 'Caption of the picture', 'mvweb-core' ),
			),
			array(
				'type'     => 'url',
				'settings' => 'mvweb_mega_preview_url',
				'section'  => 'mvweb_cz_header_brand',
				'label'    => __( 'Where the picture leads', 'mvweb-core' ),
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_drawer_socials_title',
				'section'  => 'mvweb_cz_header_drawer',
				'label'    => __( 'Heading above the social networks', 'mvweb-core' ),
				'default'  => '',
			),
			array(
				'type'        => 'radio',
				'settings'    => 'mvweb_drawer_contacts_pos',
				'section'     => 'mvweb_cz_header_drawer',
				'label'       => __( 'Where the contacts stand in the mobile menu', 'mvweb-core' ),
				'description' => __( 'The contacts are chosen in “Mobile menu: contacts”.', 'mvweb-core' ),
				'default'     => 'top',
				'choices'     => array(
					'top'    => __( 'Above the menu items', 'mvweb-core' ),
					'bottom' => __( 'Below the menu items', 'mvweb-core' ),
				),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_cz_phone_label',
				'section'     => 'mvweb_cz_profile_contacts',
				'label'       => __( 'Caption of the phone', 'mvweb-core' ),
				'description' => __( 'For example “Shop”.', 'mvweb-core' ),
				'default'     => '',
				'priority'    => 21,
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_cz_phone_extra_label',
				'section'  => 'mvweb_cz_profile_contacts',
				'label'    => __( 'Caption of the second phone', 'mvweb-core' ),
				'default'  => '',
				'priority' => 22,
			),
			array(
				'type'        => 'radio',
				'settings'    => 'mvweb_container_width',
				'section'     => 'mvweb_cz_design_preset',
				'label'       => __( 'Width of the content', 'mvweb-core' ),
				'description' => __( 'The wider the content, the more columns the blocks take on a big screen.', 'mvweb-core' ),
				'default'     => '1280',
				'choices'     => array(
					'1280' => '1280',
					'1440' => '1440',
					'1920' => '1920',
				),
			),
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_crumbs_enable',
				'section'     => $inner,
				'label'       => __( 'Breadcrumbs', 'mvweb-core' ),
				'description' => __( 'The trail above the heading of inner pages.', 'mvweb-core' ),
				'default'     => true,
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_search_placeholder',
				'section'  => $inner,
				'label'    => __( 'Hint in the search field', 'mvweb-core' ),
				'default'  => '',
			),
			array(
				'type'        => 'textarea',
				'settings'    => 'mvweb_search_popular',
				'section'     => $inner,
				'label'       => __( 'Popular searches', 'mvweb-core' ),
				'description' => __( 'One query a line; shown on the “nothing found” page and on the 404 page.', 'mvweb-core' ),
				'default'     => '',
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_search_hits_title',
				'section'     => $inner,
				'label'       => __( 'Search found nothing: heading of the suggested items', 'mvweb-core' ),
				'description' => __( 'Recommended items under the “nothing found” message. Empty hides the block.', 'mvweb-core' ),
				'default'     => '',
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_search_hits_count',
				'section'     => $inner,
				'label'       => __( 'Search found nothing: how many suggested items', 'mvweb-core' ),
				'default'     => 5,
				'input_attrs' => array(
					'min' => 1,
					'max' => 12,
				),
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_404_title',
				'section'  => $inner,
				'label'    => __( 'Heading of the “not found” page', 'mvweb-core' ),
				'default'  => '',
			),
			array(
				'type'     => 'textarea',
				'settings' => 'mvweb_404_text',
				'section'  => $inner,
				'label'    => __( 'Text of the “not found” page', 'mvweb-core' ),
				'default'  => '',
			),
			array(
				'type'     => 'toggle',
				'settings' => 'mvweb_404_search',
				'section'  => $inner,
				'label'    => __( 'Search field on the “not found” page', 'mvweb-core' ),
				'default'  => true,
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_popup_ok_title',
				'section'  => 'mvweb_cz_conversion_cta',
				'label'    => __( 'Heading after the request is sent', 'mvweb-core' ),
				'default'  => '',
			),
			array(
				'type'     => 'textarea',
				'settings' => 'mvweb_popup_ok_text',
				'section'  => 'mvweb_cz_conversion_cta',
				'label'    => __( 'Text after the request is sent', 'mvweb-core' ),
				'default'  => '',
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_popup_error_title',
				'section'  => 'mvweb_cz_conversion_cta',
				'label'    => __( 'Heading when sending failed', 'mvweb-core' ),
				'default'  => '',
			),
			array(
				'type'     => 'textarea',
				'settings' => 'mvweb_popup_error_text',
				'section'  => 'mvweb_cz_conversion_cta',
				'label'    => __( 'Text when sending failed', 'mvweb-core' ),
				'default'  => '',
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_frame_tree' ) ) {
	/**
	 * Put the section of the page frame into the panel of the inner pages.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_frame_tree( $tree ) {
		if ( isset( $tree['mvweb_cz_inner'] ) ) {
			$tree['mvweb_cz_inner']['sections']['mvweb_cz_inner_frame'] = __( 'Search, breadcrumbs and “not found”', 'mvweb-core' );
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_frame_tree', 98 );

if ( ! function_exists( 'mvweb_core_frame_layouts' ) ) {
	/**
	 * The layouts of the frame: which parts a template can print and in what order.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $layouts Area => definition.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_frame_layouts( $layouts ) {
		$layouts['footer.contacts'] = array(
			'label'   => __( 'Contacts in the footer', 'mvweb-core' ),
			'panel'   => 'mvweb_cz_footer',
			'section' => 'mvweb_cz_footer_blocks',
			'parts'   => array(
				'address'    => __( 'Address', 'mvweb-core' ),
				'phones'     => __( 'Phones', 'mvweb-core' ),
				'hours'      => __( 'Opening hours', 'mvweb-core' ),
				'email'      => __( 'E-mail', 'mvweb-core' ),
				'messengers' => __( 'Messengers', 'mvweb-core' ),
				'cta'        => __( 'Action button', 'mvweb-core' ),
			),
		);

		$layouts['page-hero'] = array(
			'label'   => __( 'Head of a page', 'mvweb-core' ),
			'panel'   => 'mvweb_cz_inner',
			'section' => 'mvweb_cz_inner_frame',
			'parts'   => array(
				'crumbs' => __( 'Breadcrumbs', 'mvweb-core' ),
				'title'  => __( 'Heading', 'mvweb-core' ),
				'lead'   => __( 'Text under the heading', 'mvweb-core' ),
			),
		);

		$layouts['search.groups'] = array(
			'label'   => __( 'Groups of the search results', 'mvweb-core' ),
			'panel'   => 'mvweb_cz_inner',
			'section' => 'mvweb_cz_inner_frame',
			'parts'   => array(
				'products' => __( 'Catalogue', 'mvweb-core' ),
				'services' => __( 'Services', 'mvweb-core' ),
				'works'    => __( 'Works', 'mvweb-core' ),
				'posts'    => __( 'Posts', 'mvweb-core' ),
				'pages'    => __( 'Pages', 'mvweb-core' ),
			),
		);

		$layouts['search.empty'] = array(
			'label'   => __( 'When nothing is found', 'mvweb-core' ),
			'panel'   => 'mvweb_cz_inner',
			'section' => 'mvweb_cz_inner_frame',
			'parts'   => array(
				'text'    => __( 'Text', 'mvweb-core' ),
				'search'  => __( 'Search field', 'mvweb-core' ),
				'popular' => __( 'Popular searches', 'mvweb-core' ),
			),
		);

		$layouts['notfound'] = array(
			'label'   => __( 'Page not found', 'mvweb-core' ),
			'panel'   => 'mvweb_cz_inner',
			'section' => 'mvweb_cz_inner_frame',
			'parts'   => array(
				'title'   => __( 'Heading', 'mvweb-core' ),
				'text'    => __( 'Text', 'mvweb-core' ),
				'search'  => __( 'Search field', 'mvweb-core' ),
				'popular' => __( 'Popular searches', 'mvweb-core' ),
			),
		);

		return $layouts;
	}
}
add_filter( 'mvweb_core_layouts', 'mvweb_core_frame_layouts' );
