<?php
/**
 * The photo of a user: a picture from the media library instead of Gravatar.
 *
 * The profile screen gets a field to pick the picture. Every avatar WordPress
 * prints for the user, in the theme, the comments and the admin bar, takes
 * it, also when Settings → Discussion hides avatars: that switch is about
 * Gravatar. A user without a photo keeps Gravatar and its switch.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_user_photo' ) ) {
	/**
	 * The picture a user chose for the profile.
	 *
	 * @since 0.1.0
	 *
	 * @param int $user_id User id.
	 *
	 * @return int Attachment id, 0 without one.
	 */
	function mvweb_core_user_photo( $user_id ) {
		$id = absint( get_user_meta( absint( $user_id ), '_mvweb_photo', true ) );

		return $id && wp_attachment_is_image( $id ) ? $id : 0;
	}
}

if ( ! function_exists( 'mvweb_core_user_photo_field' ) ) {
	/**
	 * The field of the photo on the profile screen.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_User $user User being edited.
	 *
	 * @return void
	 */
	function mvweb_core_user_photo_field( $user ) {
		$id = mvweb_core_user_photo( $user->ID );
		?>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Profile photo', 'mvweb-core' ); ?></th>
				<td>
					<div class="mvweb-core-media" data-mvweb-core-media>
						<span class="mvweb-core-media__preview" data-mvweb-core-media-preview>
							<?php if ( $id ) : ?>
								<img src="<?php echo esc_url( (string) wp_get_attachment_image_url( $id, 'thumbnail' ) ); ?>" alt="">
							<?php endif; ?>
						</span>
						<input type="hidden" name="mvweb_photo" value="<?php echo esc_attr( $id ? (string) $id : '' ); ?>" data-mvweb-core-media-value>
						<button type="button" class="button" data-mvweb-core-media-pick><?php esc_html_e( 'Select', 'mvweb-core' ); ?></button>
						<button type="button" class="button-link" data-mvweb-core-media-clear><?php esc_html_e( 'Remove', 'mvweb-core' ); ?></button>
					</div>
					<p class="description"><?php esc_html_e( 'Shown on the site instead of Gravatar: beside the posts, on the author page and in the comments. A square picture of 300 pixels or more looks best.', 'mvweb-core' ); ?></p>
				</td>
			</tr>
		</table>
		<?php
	}
}
add_action( 'show_user_profile', 'mvweb_core_user_photo_field' );
add_action( 'edit_user_profile', 'mvweb_core_user_photo_field' );

if ( ! function_exists( 'mvweb_core_user_photo_save' ) ) {
	/**
	 * Store the photo of a user. WordPress checks the nonce of the profile form before this runs.
	 *
	 * @since 0.1.0
	 *
	 * @param int $user_id User id.
	 *
	 * @return void
	 */
	function mvweb_core_user_photo_save( $user_id ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- The profile form nonce is checked by WordPress before the update hooks.
		if ( ! isset( $_POST['mvweb_photo'] ) || ! current_user_can( 'edit_user', $user_id ) ) {
			return;
		}

		$id = absint( wp_unslash( $_POST['mvweb_photo'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Same.

		if ( $id && wp_attachment_is_image( $id ) ) {
			update_user_meta( $user_id, '_mvweb_photo', $id );
		} else {
			delete_user_meta( $user_id, '_mvweb_photo' );
		}
	}
}
add_action( 'personal_options_update', 'mvweb_core_user_photo_save' );
add_action( 'edit_user_profile_update', 'mvweb_core_user_photo_save' );

if ( ! function_exists( 'mvweb_core_user_photo_assets' ) ) {
	/**
	 * The media picker of the profile screen.
	 *
	 * @since 0.1.0
	 *
	 * @param string $hook Admin page.
	 *
	 * @return void
	 */
	function mvweb_core_user_photo_assets( $hook ) {
		if ( ! in_array( $hook, array( 'profile.php', 'user-edit.php' ), true ) || ! current_user_can( 'upload_files' ) ) {
			return;
		}

		wp_enqueue_media();

		$relative = mvweb_core_asset_path( '/admin/js/media-field.js' );

		wp_enqueue_script( 'mvweb-core-media-field', MVWEB_CORE_URI . $relative, array( 'media-editor' ), mvweb_core_asset_version( $relative ), true );
		mvweb_core_admin_style();
	}
}
add_action( 'admin_enqueue_scripts', 'mvweb_core_user_photo_assets' );

if ( ! function_exists( 'mvweb_core_user_photo_of' ) ) {
	/**
	 * The chosen photo of whoever an avatar is asked for.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $id_or_email User id, email, WP_User, WP_Post or WP_Comment.
	 *
	 * @return int Attachment id, 0 without one.
	 */
	function mvweb_core_user_photo_of( $id_or_email ) {
		$user_id = 0;

		if ( is_numeric( $id_or_email ) ) {
			$user_id = absint( $id_or_email );
		} elseif ( $id_or_email instanceof WP_User ) {
			$user_id = $id_or_email->ID;
		} elseif ( $id_or_email instanceof WP_Post ) {
			$user_id = (int) $id_or_email->post_author;
		} elseif ( $id_or_email instanceof WP_Comment ) {
			$user_id = (int) $id_or_email->user_id;
		} elseif ( is_string( $id_or_email ) && is_email( $id_or_email ) ) {
			$user    = get_user_by( 'email', $id_or_email );
			$user_id = $user ? $user->ID : 0;
		}

		return $user_id ? mvweb_core_user_photo( $user_id ) : 0;
	}
}

if ( ! function_exists( 'mvweb_core_user_photo_avatar' ) ) {
	/**
	 * Give the avatar address of a user the chosen photo.
	 *
	 * @since 0.1.0
	 *
	 * @param array $args        Avatar arguments.
	 * @param mixed $id_or_email User id, email, WP_User, WP_Post or WP_Comment.
	 *
	 * @return array
	 */
	function mvweb_core_user_photo_avatar( $args, $id_or_email ) {
		$photo = mvweb_core_user_photo_of( $id_or_email );

		if ( ! $photo ) {
			return $args;
		}

		$size = isset( $args['size'] ) ? max( 1, absint( $args['size'] ) ) : 96;
		$url  = wp_get_attachment_image_url( $photo, array( $size, $size ) );

		if ( $url ) {
			$args['url']          = $url;
			$args['found_avatar'] = true;
		}

		return $args;
	}
}
add_filter( 'pre_get_avatar_data', 'mvweb_core_user_photo_avatar', 10, 2 );

if ( ! function_exists( 'mvweb_core_user_photo_tag' ) ) {
	/**
	 * Print the chosen photo even where the site hides avatars: that switch is about Gravatar, the photo is the site's own.
	 *
	 * @since 0.1.0
	 *
	 * @param string|null $avatar      Markup, null to let WordPress build it.
	 * @param mixed       $id_or_email User id, email, WP_User, WP_Post or WP_Comment.
	 * @param array       $args        Avatar arguments.
	 *
	 * @return string|null
	 */
	function mvweb_core_user_photo_tag( $avatar, $id_or_email, $args ) {
		$photo = null === $avatar ? mvweb_core_user_photo_of( $id_or_email ) : 0;

		if ( ! $photo ) {
			return $avatar;
		}

		$size   = isset( $args['size'] ) ? max( 1, absint( $args['size'] ) ) : 96;
		$width  = ! empty( $args['width'] ) ? absint( $args['width'] ) : $size;
		$height = ! empty( $args['height'] ) ? absint( $args['height'] ) : $size;
		$class  = array( 'avatar', 'avatar-' . $size, 'photo' );

		if ( ! empty( $args['class'] ) ) {
			$class = array_merge( $class, is_array( $args['class'] ) ? $args['class'] : explode( ' ', (string) $args['class'] ) );
		}

		$html = wp_get_attachment_image(
			$photo,
			array( $width * 2, $height * 2 ),
			false,
			array(
				'class'    => implode( ' ', array_filter( $class ) ),
				'alt'      => isset( $args['alt'] ) ? (string) $args['alt'] : '',
				'width'    => $width,
				'height'   => $height,
				'loading'  => ! empty( $args['loading'] ) ? (string) $args['loading'] : 'lazy',
				'decoding' => 'async',
				'sizes'    => $width . 'px',
			)
		);

		return '' !== $html ? $html : $avatar;
	}
}
add_filter( 'pre_get_avatar', 'mvweb_core_user_photo_tag', 10, 3 );

if ( ! function_exists( 'mvweb_core_user_photo_note' ) ) {
	/**
	 * Point the Gravatar line of the profile to the own photo.
	 *
	 * @since 0.1.0
	 *
	 * @param string  $description Line under the picture.
	 * @param WP_User $user        User being edited.
	 *
	 * @return string
	 */
	function mvweb_core_user_photo_note( $description, $user ) {
		return $user instanceof WP_User && mvweb_core_user_photo( $user->ID ) ? esc_html__( 'The photo is set below, in the Profile photo field.', 'mvweb-core' ) : $description;
	}
}
add_filter( 'user_profile_picture_description', 'mvweb_core_user_photo_note', 10, 2 );
