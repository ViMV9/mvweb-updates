<?php
/**
 * Modules the owner turns on and off: catalogue, services, portfolio, team.
 *
 * A module that is off keeps its data in the database, but its post types and
 * taxonomies are not registered, so it leaves the admin menu, the addresses,
 * the search and the sitemap. Its Customizer sections, sidebar, source fields
 * and the blocks that cannot work without it go too.
 *
 * @package MVweb_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_catalog_mode' ) ) {
	/**
	 * How the site keeps its catalogue: off, its own post type or WooCommerce.
	 *
	 * @since 0.1.0
	 *
	 * @return string One of off, items, woocommerce.
	 */
	function mvweb_core_catalog_mode() {
		$woo  = class_exists( 'WooCommerce' );
		$mode = (string) get_theme_mod( 'mvweb_module_catalog', $woo ? 'woocommerce' : 'items' );

		if ( 'woocommerce' === $mode && ! $woo ) {
			return 'items';
		}

		return in_array( $mode, array( 'off', 'items', 'woocommerce' ), true ) ? $mode : 'items';
	}
}

if ( ! function_exists( 'mvweb_core_module' ) ) {
	/**
	 * Whether a module is on.
	 *
	 * @since 0.1.0
	 *
	 * @param string $name One of catalog, services, works, team.
	 *
	 * @return bool
	 */
	function mvweb_core_module( $name ) {
		if ( 'catalog' === $name ) {
			return 'off' !== mvweb_core_catalog_mode();
		}

		$defaults = array(
			'services' => true,
			'works'    => true,
			'team'     => false,
		);

		return isset( $defaults[ $name ] ) && (bool) get_theme_mod( 'mvweb_module_' . $name, $defaults[ $name ] );
	}
}

if ( ! function_exists( 'mvweb_core_module_parts' ) ) {
	/**
	 * What every module brings: post types, sidebar area, Customizer sections and controls, blocks.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,string[]>>
	 */
	function mvweb_core_module_parts() {
		return array(
			'catalog'  => array(
				'types'    => array( 'mv_item', 'mv_facet' ),
				'area'     => array( 'catalog' ),
				'panels'   => array( 'mvweb_cz_catalog', 'mvweb_cz_product' ),
				'sections' => array(),
				'controls' => array( 'mvweb_sidebar_side_catalog', 'mvweb_source_catalog', 'mvweb_source_catalog_term', 'mvweb_source_product', 'mvweb_source_facet' ),
				'blocks'   => array( 'products', 'promo-products' ),
			),
			'services' => array(
				'types'    => array( 'mv_service' ),
				'area'     => array( 'services' ),
				'panels'   => array(),
				'sections' => array( 'mvweb_cz_services_setup', 'mvweb_cz_services_list', 'mvweb_cz_services_page' ),
				'controls' => array( 'mvweb_sidebar_side_services', 'mvweb_source_services', 'mvweb_source_services_term' ),
				'blocks'   => array(),
			),
			'works'    => array(
				'types'    => array( 'mv_work' ),
				'area'     => array( 'works' ),
				'panels'   => array(),
				'sections' => array( 'mvweb_cz_services_works', 'mvweb_cz_services_work' ),
				'controls' => array( 'mvweb_sidebar_side_works', 'mvweb_source_works', 'mvweb_source_works_term', 'mvweb_source_work' ),
				'blocks'   => array( 'works' ),
			),
			'team'     => array(
				'types'    => array( 'mv_person', 'mv_video' ),
				'area'     => array(),
				'panels'   => array(),
				'sections' => array(),
				'controls' => array(),
				'blocks'   => array(),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_modules_off' ) ) {
	/**
	 * The parts of the modules that are off, merged.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string[]>
	 */
	function mvweb_core_modules_off() {
		$off = array(
			'types'    => array(),
			'area'     => array(),
			'panels'   => array(),
			'sections' => array(),
			'controls' => array(),
			'blocks'   => array(),
		);

		foreach ( mvweb_core_module_parts() as $name => $parts ) {
			if ( mvweb_core_module( $name ) ) {
				continue;
			}

			foreach ( $parts as $key => $list ) {
				$off[ $key ] = array_merge( $off[ $key ], $list );
			}
		}

		return $off;
	}
}

if ( ! function_exists( 'mvweb_core_modules_unregister' ) ) {
	/**
	 * Take the post types and taxonomies of the modules that are off out of WordPress.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_modules_unregister() {
		foreach ( mvweb_core_modules_off()['types'] as $type ) {
			if ( ! post_type_exists( $type ) ) {
				continue;
			}

			foreach ( get_object_taxonomies( $type ) as $taxonomy ) {
				unregister_taxonomy( $taxonomy );
			}

			unregister_post_type( $type );
		}

		if ( get_option( 'mvweb_core_rules_stale' ) ) {
			delete_option( 'mvweb_core_rules_stale' );
			flush_rewrite_rules( false );
		}
	}
}
add_action( 'init', 'mvweb_core_modules_unregister', 99 );

if ( ! function_exists( 'mvweb_core_modules_blocks' ) ) {
	/**
	 * The blocks that cannot work without their module leave the registry.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_modules_blocks() {
		foreach ( mvweb_core_modules_off()['blocks'] as $type ) {
			unset( $GLOBALS['mvweb_sections'][ $type ] );
		}
	}
}
add_action( 'after_setup_theme', 'mvweb_core_modules_blocks', 30 );

if ( ! function_exists( 'mvweb_core_modules_sidebars' ) ) {
	/**
	 * No widget area for a module that is off.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_modules_sidebars() {
		foreach ( mvweb_core_modules_off()['area'] as $area ) {
			unregister_sidebar( mvweb_core_sidebar_id( $area ) );
		}
	}
}
add_action( 'widgets_init', 'mvweb_core_modules_sidebars', 20 );

if ( ! function_exists( 'mvweb_core_modules_tree' ) ) {
	/**
	 * The panel of the modules, and no panels and sections of the modules that are off.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panel id => panel.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_modules_tree( $tree ) {
		$off = mvweb_core_modules_off();

		foreach ( $off['panels'] as $panel ) {
			unset( $tree[ $panel ] );
		}

		foreach ( $tree as $panel => $data ) {
			foreach ( $off['sections'] as $section ) {
				unset( $tree[ $panel ]['sections'][ $section ] );
			}

			if ( isset( $data['sections'] ) && empty( $tree[ $panel ]['sections'] ) ) {
				unset( $tree[ $panel ] );
			}
		}

		$modules = array(
			'mvweb_cz_modules' => array(
				'title'    => __( 'MVweb: Modules', 'mvweb-core' ),
				'priority' => isset( $tree['mvweb_cz_design']['priority'] ) ? (int) $tree['mvweb_cz_design']['priority'] - 1 : 29,
				'sections' => array(
					'mvweb_cz_modules_main' => __( 'Modules and search', 'mvweb-core' ),
				),
			),
		);

		if ( isset( $tree['mvweb_cz_design']['group'] ) ) {
			$modules['mvweb_cz_modules']['group'] = $tree['mvweb_cz_design']['group'];
		}

		return array_merge( $modules, $tree );
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_modules_tree', 1000 );

if ( ! function_exists( 'mvweb_core_module_fields' ) ) {
	/**
	 * The switches of the modules.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Customizer Kit.
	 *
	 * @return void
	 */
	function mvweb_core_module_fields( $kit ) {
		$catalog = array(
			'off'   => __( 'Off', 'mvweb-core' ),
			'items' => __( 'Own catalogue', 'mvweb-core' ),
		);

		if ( class_exists( 'WooCommerce' ) ) {
			$catalog['woocommerce'] = __( 'WooCommerce', 'mvweb-core' );
		}

		$note = __( 'A section that is off leaves the admin menu, the site addresses, the search and the sitemap; its entries stay in the database. Publish and reload the page after the change.', 'mvweb-core' );

		$kit->add_fields(
			array(
				array(
					'type'        => 'radio',
					'settings'    => 'mvweb_module_catalog',
					'section'     => 'mvweb_cz_modules_main',
					'label'       => __( 'Catalogue', 'mvweb-core' ),
					'description' => $note,
					'default'     => mvweb_core_catalog_mode(),
					'choices'     => $catalog,
					'transport'   => 'refresh',
				),
				array(
					'type'      => 'toggle',
					'settings'  => 'mvweb_module_services',
					'section'   => 'mvweb_cz_modules_main',
					'label'     => __( 'Services', 'mvweb-core' ),
					'default'   => true,
					'transport' => 'refresh',
				),
				array(
					'type'      => 'toggle',
					'settings'  => 'mvweb_module_works',
					'section'   => 'mvweb_cz_modules_main',
					'label'     => __( 'Portfolio', 'mvweb-core' ),
					'default'   => true,
					'transport' => 'refresh',
				),
				array(
					'type'        => 'toggle',
					'settings'    => 'mvweb_module_team',
					'section'     => 'mvweb_cz_modules_main',
					'label'       => __( 'Team and video reviews as entries', 'mvweb-core' ),
					'description' => __( 'The entries “Team” and “Video reviews” in the admin. The blocks “Team” and “Video reviews” keep people and videos in their own fields and do not need them.', 'mvweb-core' ),
					'default'     => false,
					'transport'   => 'refresh',
				),
			)
		);
	}
}
add_action( 'mvweb_cz_register', 'mvweb_core_module_fields', 5 );

if ( ! function_exists( 'mvweb_core_modules_controls' ) ) {
	/**
	 * No sidebar side and no source of blocks for a module that is off.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer manager.
	 *
	 * @return void
	 */
	function mvweb_core_modules_controls( $wp_customize ) {
		foreach ( mvweb_core_modules_off()['controls'] as $id ) {
			$wp_customize->remove_control( $id );
		}
	}
}
add_action( 'customize_register', 'mvweb_core_modules_controls', 40 );

if ( ! function_exists( 'mvweb_core_modules_saved' ) ) {
	/**
	 * Address rules are rebuilt on the next request after a module changed.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer manager.
	 *
	 * @return void
	 */
	function mvweb_core_modules_saved( $wp_customize ) {
		foreach ( array_keys( $wp_customize->unsanitized_post_values() ) as $id ) {
			if ( 0 === strpos( $id, 'mvweb_module_' ) ) {
				update_option( 'mvweb_core_rules_stale', 1, false );

				return;
			}
		}
	}
}
add_action( 'customize_save_after', 'mvweb_core_modules_saved' );
