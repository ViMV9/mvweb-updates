<?php
/**
 * Pages the theme keeps out of the index.
 *
 * A filtered or re-sorted listing prints the same heading and the same items
 * as the listing itself, and every tick of the filter makes another address
 * of it; the favourites page is drawn by a script and is empty to a robot.
 * Both stay open to crawling — their links still lead somewhere — and are only
 * marked noindex.
 *
 * Yoast keeps its own list of directives and drops the canonical when that
 * list says noindex, so the mark goes into it too: a page must not say
 * "don't index me" and "index that one instead" at once.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_noindex' ) ) {
	/**
	 * Whether the page being shown should stay out of the index.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_noindex() {
		if ( ( function_exists( 'mvweb_core_favorites_page_id' ) && mvweb_core_favorites_page_id() && is_page( mvweb_core_favorites_page_id() ) ) ) {
			return true;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Reading a public listing parameter, not acting on it.
		return mvweb_core_is_catalog() && ( mvweb_core_catalog_is_filtered() || isset( $_GET['orderby'] ) );
	}
}

if ( ! function_exists( 'mvweb_core_wp_robots' ) ) {
	/**
	 * Mark the page noindex, follow in core's robots tag.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $robots Directives.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_wp_robots( $robots ) {
		if ( ! mvweb_core_noindex() ) {
			return $robots;
		}

		unset( $robots['index'], $robots['nofollow'] );

		$robots['noindex'] = true;
		$robots['follow']  = true;

		return $robots;
	}
}
add_filter( 'wp_robots', 'mvweb_core_wp_robots' );

if ( ! function_exists( 'mvweb_core_yoast_robots' ) ) {
	/**
	 * Mark the page noindex, follow in Yoast's directives.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $robots Directives in Yoast's shape.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_yoast_robots( $robots ) {
		if ( ! mvweb_core_noindex() ) {
			return $robots;
		}

		$robots['index']  = 'noindex';
		$robots['follow'] = 'follow';

		return $robots;
	}
}
add_filter( 'wpseo_robots_array', 'mvweb_core_yoast_robots' );
