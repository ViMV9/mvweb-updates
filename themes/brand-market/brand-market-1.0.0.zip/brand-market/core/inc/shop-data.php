<?php
/**
 * What a shop card and an item page say about an item, beyond its price.
 *
 * Badges, rating, availability, the goods bought together and the next price
 * tier: WooCommerce keeps most of it, the theme's own catalogue keeps part, and
 * a template asks one function whichever store answers.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_wc_item' ) ) {
	/**
	 * The WooCommerce product of an id, when the id is one.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Post id.
	 *
	 * @return WC_Product|null
	 */
	function mvweb_core_wc_item( $id ) {
		if ( ! mvweb_core_is_woocommerce() || 'product' !== get_post_type( $id ) ) {
			return null;
		}

		$product = wc_get_product( $id );

		return $product instanceof WC_Product ? $product : null;
	}
}

if ( ! function_exists( 'mvweb_core_item_sale_percent' ) ) {
	/**
	 * How many percent the sale takes off a product.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Product on sale.
	 *
	 * @return int 0 when there is no honest figure.
	 */
	function mvweb_core_item_sale_percent( $product ) {
		if ( $product->is_type( 'variable' ) ) {
			$regular = (float) $product->get_variation_regular_price( 'min' );
			$sale    = (float) $product->get_variation_sale_price( 'min' );
		} else {
			$regular = (float) $product->get_regular_price();
			$sale    = (float) $product->get_sale_price();
		}

		return $regular > 0 && $sale > 0 && $sale < $regular ? (int) round( ( $regular - $sale ) / $regular * 100 ) : 0;
	}
}

if ( ! function_exists( 'mvweb_core_item_badges' ) ) {
	/**
	 * The badges of an item: its own words, the sale, a hit, a novelty.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $id  Item id.
	 * @param string $add Own, hit, new or none.
	 *
	 * @return array<int,array{type:string,text:string}>
	 */
	function mvweb_core_item_badges( $id, $add = 'own' ) {
		if ( 'none' === $add ) {
			return array();
		}

		$badges  = array();
		$product = mvweb_core_wc_item( $id );
		$custom  = trim( (string) get_post_meta( $id, '_mvweb_badge', true ) );

		if ( '' !== $custom ) {
			$badges[] = array(
				'type' => 'custom',
				'text' => $custom,
			);
		}

		if ( $product && $product->is_on_sale() && mvweb_core_item_sale_percent( $product ) > 0 ) {
			$badges[] = array(
				'type' => 'sale',
				'text' => '−' . mvweb_core_item_sale_percent( $product ) . '%',
			);
		}

		$featured = $product ? $product->is_featured() : '1' === (string) get_post_meta( $id, '_mvweb_featured', true );

		if ( $featured || 'hit' === $add ) {
			$badges[] = array(
				'type' => 'hit',
				'text' => (string) get_theme_mod( 'mvweb_badge_hit', __( 'Hit', 'mvweb-core' ) ),
			);
		}

		$days = absint( get_theme_mod( 'mvweb_badge_new_days', 30 ) );

		if ( 'new' === $add || ( $days > 0 && get_post_time( 'U', true, $id ) > time() - $days * DAY_IN_SECONDS ) ) {
			$badges[] = array(
				'type' => 'new',
				'text' => (string) get_theme_mod( 'mvweb_badge_new', __( 'New', 'mvweb-core' ) ),
			);
		}

		return array_values(
			array_filter(
				$badges,
				static function ( $badge ) {
					return '' !== $badge['text'];
				}
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_item_rating' ) ) {
	/**
	 * The rating of an item and the number of reviews behind it.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return array{value:float,count:int} Empty for an item nobody has reviewed and for the own catalogue, which has no reviews.
	 */
	function mvweb_core_item_rating( $id ) {
		$product = mvweb_core_wc_item( $id );

		if ( ! $product || ! wc_review_ratings_enabled() || $product->get_review_count() < 1 ) {
			return array();
		}

		return array(
			'value' => round( (float) $product->get_average_rating(), 1 ),
			'count' => (int) $product->get_review_count(),
		);
	}
}

if ( ! function_exists( 'mvweb_core_item_stock' ) ) {
	/**
	 * Whether an item is there.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return array{status:string,label:string,qty:int|null} Empty for the own catalogue, which keeps no stock.
	 */
	function mvweb_core_item_stock( $id ) {
		$product = mvweb_core_wc_item( $id );

		if ( ! $product ) {
			return array();
		}

		$status = (string) $product->get_stock_status();
		$labels = array(
			'instock'     => __( 'In stock', 'mvweb-core' ),
			'outofstock'  => __( 'Out of stock', 'mvweb-core' ),
			'onbackorder' => __( 'On backorder', 'mvweb-core' ),
		);
		$qty    = get_theme_mod( 'mvweb_stock_show_qty', false ) && 'instock' === $status && $product->managing_stock() ? max( 0, (int) $product->get_stock_quantity() ) : null;

		return array(
			'status' => $status,
			'label'  => isset( $labels[ $status ] ) ? $labels[ $status ] : '',
			'qty'    => $qty,
		);
	}
}

if ( ! function_exists( 'mvweb_core_upsell_items' ) ) {
	/**
	 * The goods bought together with an item.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id    Item id.
	 * @param int $limit How many.
	 *
	 * @return int[]
	 */
	function mvweb_core_upsell_items( $id, $limit = 4 ) {
		$product = mvweb_core_wc_item( $id );
		$ids     = array();

		if ( $product ) {
			$ids = array_merge( $product->get_upsell_ids(), $product->get_cross_sell_ids() );
		}

		if ( empty( $ids ) ) {
			$ids = mvweb_core_related_by( $id, mvweb_core_taxonomy(), $limit, array( $id ) );
		}

		$ids = array_filter( array_unique( array_map( 'absint', $ids ) ), 'mvweb_core_item_visible' );

		return array_slice( array_values( $ids ), 0, max( 1, (int) $limit ) );
	}
}

if ( ! function_exists( 'mvweb_core_next_tier' ) ) {
	/**
	 * The price tier a customer is one step short of.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id       Item id.
	 * @param int $quantity Quantity in the cart, or the one the customer has picked.
	 *
	 * @return array{from:int,amount:string,left:int} Empty when the last tier is reached.
	 */
	function mvweb_core_next_tier( $id, $quantity = 1 ) {
		foreach ( mvweb_core_tiers( $id ) as $from => $amount ) {
			if ( $from > $quantity ) {
				return array(
					'from'   => (int) $from,
					'amount' => (string) $amount,
					'left'   => (int) $from - (int) $quantity,
				);
			}
		}

		return array();
	}
}

if ( ! function_exists( 'mvweb_core_qty_unit' ) ) {
	/**
	 * The unit the minimum quantity is counted in.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return string Empty when the owner left it out: the theme says «pcs».
	 */
	function mvweb_core_qty_unit( $id ) {
		return trim( (string) get_post_meta( $id, '_mvweb_qty_unit', true ) );
	}
}

if ( ! function_exists( 'mvweb_core_free_shipping_min' ) ) {
	/**
	 * The order total from which delivery is free.
	 *
	 * @since 0.1.0
	 *
	 * @return float 0 when the shop promises nothing.
	 */
	function mvweb_core_free_shipping_min() {
		return max( 0.0, (float) get_theme_mod( 'mvweb_free_shipping_min', 0 ) );
	}
}

if ( ! function_exists( 'mvweb_core_free_shipping_left' ) ) {
	/**
	 * How much is missing for free delivery.
	 *
	 * @since 0.1.0
	 *
	 * @param float $total Total of the cart.
	 *
	 * @return float 0 when delivery is free already, or promised for no total.
	 */
	function mvweb_core_free_shipping_left( $total ) {
		$min = mvweb_core_free_shipping_min();

		return $min > 0 && $total < $min ? $min - (float) $total : 0.0;
	}
}

if ( ! function_exists( 'mvweb_core_catalog_orderings_shop' ) ) {
	/**
	 * Add the orders WooCommerce knows: by popularity and by rating.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $orderings Order key => label.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_catalog_orderings_shop( $orderings ) {
		if ( mvweb_core_is_woocommerce() ) {
			$orderings['popularity'] = __( 'By popularity', 'mvweb-core' );
			$orderings['rating']     = __( 'By rating', 'mvweb-core' );
		}

		return $orderings;
	}
}
add_filter( 'mvweb_core_catalog_orderings', 'mvweb_core_catalog_orderings_shop' );

if ( ! function_exists( 'mvweb_core_shop_data_fields' ) ) {
	/**
	 * The settings of the badges, the availability and the free delivery.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_shop_data_fields() {
		return array(
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_badge_new_days',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'Days an item is new', 'mvweb-core' ),
				'description' => __( 'A newly added item carries the “New” badge for this long. 0 switches the badge off.', 'mvweb-core' ),
				'default'     => 30,
				'input_attrs' => array(
					'min' => 0,
					'max' => 365,
				),
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_badge_hit',
				'section'  => 'mvweb_cz_catalog_archive',
				'label'    => __( 'Badge of a featured item', 'mvweb-core' ),
				'default'  => __( 'Hit', 'mvweb-core' ),
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_badge_new',
				'section'  => 'mvweb_cz_catalog_archive',
				'label'    => __( 'Badge of a new item', 'mvweb-core' ),
				'default'  => __( 'New', 'mvweb-core' ),
			),
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_stock_show_qty',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'Show how many are in stock', 'mvweb-core' ),
				'description' => __( 'Only for goods whose stock WooCommerce counts.', 'mvweb-core' ),
				'default'     => false,
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_free_shipping_min',
				'section'     => 'mvweb_cz_conversion_shipping',
				'label'       => __( 'Free delivery from', 'mvweb-core' ),
				'description' => __( 'The order total from which delivery is free; the cart, the side cart and the item page print “free delivery from” this sum. It does not change the delivery prices of WooCommerce. 0 promises nothing.', 'mvweb-core' ),
				'default'     => 0,
				'input_attrs' => array( 'min' => 0 ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_shop_data_tree' ) ) {
	/**
	 * Put the delivery section into the conversion panel.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_shop_data_tree( $tree ) {
		if ( isset( $tree['mvweb_cz_conversion'] ) ) {
			$tree['mvweb_cz_conversion']['sections']['mvweb_cz_conversion_shipping'] = __( 'Delivery', 'mvweb-core' );
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_shop_data_tree', 98 );
