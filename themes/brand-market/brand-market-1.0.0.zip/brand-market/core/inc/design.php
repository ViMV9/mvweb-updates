<?php
/**
 * Palette presets.
 *
 * A preset is the baseline the owner picks in one click; the colour fields of
 * the Customizer override it afterwards. That order is what decides where the
 * tokens are printed — this file prints at wp_head priority 10, the Kit prints
 * the hand-set values at 20, and the later declaration of an equally specific
 * selector wins.
 *
 * Only the accent family travels with a preset. Backgrounds, ink and borders
 * carry the contrast the theme was measured on, and a preset that moved them
 * would quietly invalidate that measurement on every page at once.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_palettes' ) ) {
	/**
	 * The palette presets on offer.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_palettes() {
		$palettes = array();

		/**
		 * Filter the palette presets.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,array<string,mixed>> $palettes Slug => preset.
		 */
		return (array) apply_filters( 'mvweb_core_palettes', $palettes );
	}
}

if ( ! function_exists( 'mvweb_core_default_palette' ) ) {
	/**
	 * The preset a site falls back to.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_default_palette() {
		$slugs = array_keys( mvweb_core_palettes() );

		return $slugs ? (string) $slugs[0] : '';
	}
}

if ( ! function_exists( 'mvweb_core_palette' ) ) {
	/**
	 * The preset in force, already resolved to an existing one.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_palette() {
		$palettes = mvweb_core_palettes();
		$slug     = (string) mvweb_cz_get( 'mvweb_palette' );

		if ( ! isset( $palettes[ $slug ] ) ) {
			$slug = mvweb_core_default_palette();
		}

		return isset( $palettes[ $slug ] ) ? $palettes[ $slug ] : array();
	}
}

if ( ! function_exists( 'mvweb_core_palette_choices' ) ) {
	/**
	 * The presets in the shape the swatch control expects.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,string>>
	 */
	function mvweb_core_palette_choices() {
		$choices = array();

		foreach ( mvweb_core_palettes() as $slug => $palette ) {
			$choices[ $slug ] = array(
				'color' => isset( $palette['tokens']['--mvweb-t-accent'] ) ? $palette['tokens']['--mvweb-t-accent'] : '#000000',
				'label' => isset( $palette['label'] ) ? $palette['label'] : $slug,
			);
		}

		return $choices;
	}
}

if ( ! function_exists( 'mvweb_core_palette_css' ) ) {
	/**
	 * The declarations of the current preset.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_palette_css() {
		$palette = mvweb_core_palette();
		$css     = '';

		foreach ( array(
			':root'                => 'tokens',
			'[data-scheme="dark"]' => 'dark',
		) as $selector => $key ) {
			$declarations = '';

			foreach ( isset( $palette[ $key ] ) ? (array) $palette[ $key ] : array() as $property => $value ) {
				$property = mvweb_cz_sanitize_css_property( $property );
				$value    = mvweb_cz_sanitize_color( $value );

				if ( '' === $property || '' === $value ) {
					continue;
				}

				$declarations .= $property . ':' . $value . ';';
			}

			if ( '' !== $declarations ) {
				$css .= $selector . '{' . $declarations . '}';
			}
		}

		return $css;
	}
}

if ( ! function_exists( 'mvweb_core_print_palette' ) ) {
	/**
	 * Print the preset above the hand-set colours.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_print_palette() {
		$css = mvweb_core_palette_css();

		if ( '' === $css ) {
			return;
		}

		printf( "<style id='mvweb-core-palette'>%s</style>\n", $css ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from sanitized properties and colours.
	}
}
add_action( 'wp_head', 'mvweb_core_print_palette', 10 );
