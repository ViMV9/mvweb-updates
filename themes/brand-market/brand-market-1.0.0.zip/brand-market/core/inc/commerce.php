<?php
/**
 * Trade: wholesale prices, quantity tiers, documents and marketplaces of an
 * item, and the shop mode of the store.
 *
 * Two kinds of wholesale live side by side, both seen on sites of the studio:
 * a wholesale price that a customer marked as wholesale pays after signing in,
 * and prices that fall with the quantity, with a minimum and a step. Without
 * WooCommerce they are shown on the item and the order goes through a request;
 * with it and the shop mode on, the cart counts them.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_trade_meta' ) ) {
	/**
	 * The trade meta of an item or a product and how each is cleaned.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Key => sanitizer.
	 */
	function mvweb_core_trade_meta() {
		return array(
			'_mvweb_wholesale_price' => 'mvweb_core_sanitize_amount',
			'_mvweb_qty_min'         => 'absint',
			'_mvweb_qty_step'        => 'absint',
			'_mvweb_tiers'           => 'sanitize_textarea_field',
			'_mvweb_documents'       => 'sanitize_textarea_field',
			'_mvweb_markets'         => 'sanitize_textarea_field',
			'_mvweb_qty_unit'        => 'sanitize_text_field',
			'_mvweb_badge'           => 'sanitize_text_field',
		);
	}
}

if ( ! function_exists( 'mvweb_core_shop_mode' ) ) {
	/**
	 * Whether the store sells through the cart rather than by request.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_shop_mode() {
		return mvweb_core_is_woocommerce() && 'shop' === get_theme_mod( 'mvweb_shop_mode', 'showcase' );
	}
}


if ( ! function_exists( 'mvweb_core_is_wholesaler' ) ) {
	/**
	 * Whether the visitor is a customer marked as wholesale.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_is_wholesaler() {
		return is_user_logged_in() && (bool) get_user_meta( get_current_user_id(), 'mvweb_wholesale', true );
	}
}

if ( ! function_exists( 'mvweb_core_wholesale_amount' ) ) {
	/**
	 * The wholesale price of an item, as stored.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item or product id.
	 *
	 * @return string Empty when there is none.
	 */
	function mvweb_core_wholesale_amount( $id ) {
		$amount = (string) get_post_meta( $id, '_mvweb_wholesale_price', true );

		if ( '' === $amount ) {
			$amount = (string) get_post_meta( $id, '_mvweb_pi_wholesale_price', true );
		}

		return is_numeric( $amount ) && (float) $amount > 0 ? $amount : '';
	}
}

if ( ! function_exists( 'mvweb_core_item_wholesale_line' ) ) {
	/**
	 * The wholesale price a card prints under the regular one.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item or product id.
	 *
	 * @return string Markup, empty when there is nothing to print.
	 */
	function mvweb_core_item_wholesale_line( $id ) {
		if ( ! get_theme_mod( 'mvweb_wholesale', false ) || mvweb_core_is_wholesaler() ) {
			return '';
		}

		return mvweb_core_price_html( mvweb_core_wholesale_amount( $id ) );
	}
}

if ( ! function_exists( 'mvweb_core_wholesale_label' ) ) {
	/**
	 * The caption of the wholesale price.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_wholesale_label() {
		return (string) get_theme_mod( 'mvweb_wholesale_label', __( 'Wholesale', 'mvweb-core' ) );
	}
}

if ( ! function_exists( 'mvweb_core_customer_amount' ) ) {
	/**
	 * The price this visitor pays for an item of the theme's own catalogue.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $id     Item id.
	 * @param string $amount Regular price as stored.
	 *
	 * @return string
	 */
	function mvweb_core_customer_amount( $id, $amount ) {
		if ( mvweb_core_is_wholesaler() && get_theme_mod( 'mvweb_wholesale', false ) ) {
			$wholesale = mvweb_core_wholesale_amount( $id );

			if ( '' !== $wholesale ) {
				return $wholesale;
			}
		}

		return (string) $amount;
	}
}

if ( ! function_exists( 'mvweb_core_wc_wholesale_price' ) ) {
	/**
	 * The price WooCommerce charges a wholesale customer.
	 *
	 * @since 0.1.0
	 *
	 * @param string     $price   Price as WooCommerce has it.
	 * @param WC_Product $product Product.
	 *
	 * @return string
	 */
	function mvweb_core_wc_wholesale_price( $price, $product ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return $price;
		}

		if ( ! get_theme_mod( 'mvweb_wholesale', false ) || ! mvweb_core_is_wholesaler() ) {
			return $price;
		}

		$wholesale = mvweb_core_wholesale_amount( mvweb_core_product_parent( $product ) );

		if ( '' === $wholesale ) {
			return $price;
		}

		return is_numeric( $price ) && (float) $price < (float) $wholesale ? $price : $wholesale;
	}
}

if ( ! function_exists( 'mvweb_core_wc_variation_hash' ) ) {
	/**
	 * Keep the cached price range of a variable product apart for wholesale.
	 *
	 * @since 0.1.0
	 *
	 * @param array $hash Parts of the cache key.
	 *
	 * @return array
	 */
	function mvweb_core_wc_variation_hash( $hash ) {
		$hash[] = mvweb_core_is_wholesaler() ? 'mvweb-wholesale' : 'mvweb-retail';

		return $hash;
	}
}

if ( ! function_exists( 'mvweb_core_wc_wholesale_only' ) ) {
	/**
	 * A product with a wholesale price and no retail one is not sold at retail.
	 *
	 * @since 0.1.0
	 *
	 * @param bool       $purchasable Whether WooCommerce would sell it.
	 * @param WC_Product $product     Product.
	 *
	 * @return bool
	 */
	function mvweb_core_wc_wholesale_only( $purchasable, $product ) {
		if ( ! get_theme_mod( 'mvweb_wholesale', false ) || mvweb_core_is_wholesaler() ) {
			return $purchasable;
		}

		if ( '' === (string) $product->get_regular_price( 'edit' ) && '' !== mvweb_core_wholesale_amount( mvweb_core_product_parent( $product ) ) ) {
			return false;
		}

		return $purchasable;
	}
}

if ( ! function_exists( 'mvweb_core_wholesale_user_field' ) ) {
	/**
	 * The wholesale mark on the profile screen, for those who manage users.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_User $user User being edited.
	 *
	 * @return void
	 */
	function mvweb_core_wholesale_user_field( $user ) {
		if ( ! current_user_can( 'edit_users' ) ) {
			return;
		}
		?>
		<h2><?php esc_html_e( 'Wholesale', 'mvweb-core' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Wholesale customer', 'mvweb-core' ); ?></th>
				<td>
					<?php wp_nonce_field( 'mvweb_wholesale_user', 'mvweb_wholesale_nonce' ); ?>
					<label>
						<input type="checkbox" name="mvweb_wholesale" value="1" <?php checked( (bool) get_user_meta( $user->ID, 'mvweb_wholesale', true ) ); ?>>
						<?php esc_html_e( 'Sees and pays the wholesale prices once signed in', 'mvweb-core' ); ?>
					</label>
				</td>
			</tr>
		</table>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_wholesale_user_save' ) ) {
	/**
	 * Store the wholesale mark.
	 *
	 * @since 0.1.0
	 *
	 * @param int $user_id User being saved.
	 *
	 * @return void
	 */
	function mvweb_core_wholesale_user_save( $user_id ) {
		if ( ! current_user_can( 'edit_users' ) || ! isset( $_POST['mvweb_wholesale_nonce'] ) ) {
			return;
		}

		check_admin_referer( 'mvweb_wholesale_user', 'mvweb_wholesale_nonce' );

		if ( empty( $_POST['mvweb_wholesale'] ) ) {
			delete_user_meta( $user_id, 'mvweb_wholesale' );
		} else {
			update_user_meta( $user_id, 'mvweb_wholesale', 1 );
		}
	}
}
add_action( 'show_user_profile', 'mvweb_core_wholesale_user_field' );
add_action( 'edit_user_profile', 'mvweb_core_wholesale_user_field' );
add_action( 'personal_options_update', 'mvweb_core_wholesale_user_save' );
add_action( 'edit_user_profile_update', 'mvweb_core_wholesale_user_save' );


if ( ! function_exists( 'mvweb_core_tiers' ) ) {
	/**
	 * The quantity tiers of an item: from how many, at what price.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item or product id.
	 *
	 * @return array<int,string> Quantity => amount, smallest quantity first.
	 */
	function mvweb_core_tiers( $id ) {
		$tiers = array();

		foreach ( mvweb_core_text_lines( (string) get_post_meta( $id, '_mvweb_tiers', true ) ) as $line ) {
			$parts = array_map( 'trim', explode( ':', $line, 2 ) );

			if ( 2 !== count( $parts ) ) {
				continue;
			}

			$quantity = absint( $parts[0] );
			$amount   = mvweb_core_sanitize_amount( $parts[1] );

			if ( $quantity > 0 && '' !== $amount ) {
				$tiers[ $quantity ] = $amount;
			}
		}

		ksort( $tiers );

		return $tiers;
	}
}

if ( ! function_exists( 'mvweb_core_quantity_rules' ) ) {
	/**
	 * The minimum and the step an item is ordered in.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item or product id.
	 *
	 * @return array{min:int,step:int}
	 */
	function mvweb_core_quantity_rules( $id ) {
		return array(
			'min'  => max( 1, absint( get_post_meta( $id, '_mvweb_qty_min', true ) ) ),
			'step' => max( 1, absint( get_post_meta( $id, '_mvweb_qty_step', true ) ) ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_tier_amount' ) ) {
	/**
	 * The tier price for a quantity, empty when no tier is reached.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id       Item or product id.
	 * @param int $quantity Quantity.
	 *
	 * @return string
	 */
	function mvweb_core_tier_amount( $id, $quantity ) {
		$found = '';

		foreach ( mvweb_core_tiers( $id ) as $from => $amount ) {
			if ( $quantity >= $from ) {
				$found = $amount;
			}
		}

		return $found;
	}
}

if ( ! function_exists( 'mvweb_core_product_parent' ) ) {
	/**
	 * The product whose fields rule a cart line: the parent of a variation.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Product or variation.
	 *
	 * @return int
	 */
	function mvweb_core_product_parent( $product ) {
		return $product->get_parent_id() ? $product->get_parent_id() : $product->get_id();
	}
}

if ( ! function_exists( 'mvweb_core_wc_quantity_args' ) ) {
	/**
	 * Start the quantity field at the minimum and move it by the step.
	 *
	 * @since 0.1.0
	 *
	 * @param array      $args    Field arguments.
	 * @param WC_Product $product Product.
	 *
	 * @return array
	 */
	function mvweb_core_wc_quantity_args( $args, $product ) {
		$rules = mvweb_core_quantity_rules( mvweb_core_product_parent( $product ) );

		if ( $rules['min'] > 1 || $rules['step'] > 1 ) {
			$args['min_value'] = $rules['min'];
			$args['step']      = $rules['step'];

			if ( isset( $args['input_value'] ) && ! is_cart() ) {
				$args['input_value'] = max( $rules['min'], (int) $args['input_value'] );
			}
		}

		return $args;
	}
}

if ( ! function_exists( 'mvweb_core_quantity_error' ) ) {
	/**
	 * Why a quantity cannot be ordered, empty when it can.
	 *
	 * @since 0.1.0
	 *
	 * @param int $product_id Product id.
	 * @param int $quantity   Quantity.
	 *
	 * @return string
	 */
	function mvweb_core_quantity_error( $product_id, $quantity ) {
		$rules = mvweb_core_quantity_rules( $product_id );
		$name  = get_the_title( $product_id );

		if ( $quantity < $rules['min'] ) {
			/* translators: 1: product name, 2: minimum quantity. */
			return sprintf( __( '%1$s is ordered from %2$d pcs.', 'mvweb-core' ), $name, $rules['min'] );
		}

		if ( 0 !== ( $quantity - $rules['min'] ) % $rules['step'] ) {
			/* translators: 1: product name, 2: step of the quantity. */
			return sprintf( __( '%1$s is ordered in steps of %2$d pcs.', 'mvweb-core' ), $name, $rules['step'] );
		}

		return '';
	}
}

if ( ! function_exists( 'mvweb_core_wc_add_validation' ) ) {
	/**
	 * Check the minimum and the step when a product goes into the cart.
	 *
	 * @since 0.1.0
	 *
	 * @param bool $passed     Whether it passed so far.
	 * @param int  $product_id Product id.
	 * @param int  $quantity   Quantity.
	 *
	 * @return bool
	 */
	function mvweb_core_wc_add_validation( $passed, $product_id, $quantity ) {
		$error = mvweb_core_quantity_error( absint( $product_id ), (int) $quantity );

		if ( '' !== $error ) {
			wc_add_notice( $error, 'error' );

			return false;
		}

		return $passed;
	}
}

if ( ! function_exists( 'mvweb_core_wc_update_validation' ) ) {
	/**
	 * Check the minimum and the step when the cart is updated.
	 *
	 * @since 0.1.0
	 *
	 * @param bool   $passed   Whether it passed so far.
	 * @param string $key      Cart line key.
	 * @param array  $values   Cart line.
	 * @param int    $quantity New quantity.
	 *
	 * @return bool
	 */
	function mvweb_core_wc_update_validation( $passed, $key, $values, $quantity ) {
		$error = mvweb_core_quantity_error( absint( $values['product_id'] ), (int) $quantity );

		if ( '' !== $error ) {
			wc_add_notice( $error, 'error' );

			return false;
		}

		return $passed;
	}
}

if ( ! function_exists( 'mvweb_core_store_api_minimum' ) ) {
	/**
	 * The minimum quantity for the cart and checkout blocks.
	 *
	 * @since 0.1.0
	 *
	 * @param int        $value   Minimum so far.
	 * @param WC_Product $product Product.
	 *
	 * @return int
	 */
	function mvweb_core_store_api_minimum( $value, $product ) {
		return max( (int) $value, mvweb_core_quantity_rules( mvweb_core_product_parent( $product ) )['min'] );
	}
}

if ( ! function_exists( 'mvweb_core_store_api_step' ) ) {
	/**
	 * The quantity step for the cart and checkout blocks.
	 *
	 * @since 0.1.0
	 *
	 * @param int        $value   Step so far.
	 * @param WC_Product $product Product.
	 *
	 * @return int
	 */
	function mvweb_core_store_api_step( $value, $product ) {
		$step = mvweb_core_quantity_rules( mvweb_core_product_parent( $product ) )['step'];

		return $step > 1 ? $step : (int) $value;
	}
}

if ( ! function_exists( 'mvweb_core_wc_tier_prices' ) ) {
	/**
	 * Charge each cart line the tier its quantity reached.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Cart $cart Cart.
	 *
	 * @return void
	 */
	function mvweb_core_wc_tier_prices( $cart ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return;
		}

		foreach ( $cart->get_cart() as $line ) {
			$product = $line['data'];
			$tier    = mvweb_core_tier_amount( absint( $line['product_id'] ), (int) $line['quantity'] );

			if ( '' !== $tier && ( '' === (string) $product->get_price() || (float) $tier < (float) $product->get_price() ) ) {
				$product->set_price( $tier );
			}
		}
	}
}


if ( ! function_exists( 'mvweb_core_pairs' ) ) {
	/**
	 * Lines typed as "Name | address", as pairs with a valid address.
	 *
	 * @since 0.1.0
	 *
	 * @param string $text Stored text.
	 *
	 * @return array<int,array{title:string,url:string}>
	 */
	function mvweb_core_pairs( $text ) {
		$pairs = array();

		foreach ( mvweb_core_text_lines( $text ) as $line ) {
			$parts = array_map( 'trim', explode( '|', $line, 2 ) );
			$url   = esc_url_raw( 2 === count( $parts ) ? $parts[1] : $parts[0] );

			if ( '' === $url ) {
				continue;
			}

			$pairs[] = array(
				'title' => 2 === count( $parts ) && '' !== $parts[0] ? $parts[0] : wp_basename( (string) wp_parse_url( $url, PHP_URL_PATH ) ),
				'url'   => $url,
			);
		}

		return $pairs;
	}
}

if ( ! function_exists( 'mvweb_core_item_documents' ) ) {
	/**
	 * The documents of an item: datasheets, certificates, manuals.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item or product id.
	 *
	 * @return array<int,array{title:string,url:string,type:string}>
	 */
	function mvweb_core_item_documents( $id ) {
		$documents = mvweb_core_pairs( (string) get_post_meta( $id, '_mvweb_documents', true ) );

		foreach ( $documents as &$document ) {
			$extension        = strtolower( (string) pathinfo( (string) wp_parse_url( $document['url'], PHP_URL_PATH ), PATHINFO_EXTENSION ) );
			$document['type'] = preg_match( '/^[a-z0-9]{2,4}$/', $extension ) ? strtoupper( $extension ) : '';
		}

		return $documents;
	}
}

if ( ! function_exists( 'mvweb_core_item_markets' ) ) {
	/**
	 * Where the item is sold at retail: marketplaces and partner shops.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item or product id.
	 *
	 * @return array<int,array{title:string,url:string}>
	 */
	function mvweb_core_item_markets( $id ) {
		return mvweb_core_pairs( (string) get_post_meta( $id, '_mvweb_markets', true ) );
	}
}


if ( ! function_exists( 'mvweb_core_register_trade_meta' ) ) {
	/**
	 * Register the trade meta of the theme's own items.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_trade_meta() {
		if ( mvweb_core_is_woocommerce() ) {
			return;
		}

		foreach ( mvweb_core_trade_meta() as $key => $sanitizer ) {
			register_post_meta(
				'mv_item',
				$key,
				array(
					'type'              => 'absint' === $sanitizer ? 'integer' : 'string',
					'single'            => true,
					'default'           => 'absint' === $sanitizer ? 0 : '',
					'sanitize_callback' => $sanitizer,
					'auth_callback'     => 'mvweb_core_post_meta_auth',
					'show_in_rest'      => false,
				)
			);
		}
	}
}
add_action( 'init', 'mvweb_core_register_trade_meta', 5 );

if ( ! function_exists( 'mvweb_core_trade_fields' ) ) {
	/**
	 * The trade fields as the editing screens draw them.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array{label:string,description:string,type:string}>
	 */
	function mvweb_core_trade_fields() {
		return array(
			'_mvweb_wholesale_price' => array(
				'label'       => __( 'Wholesale price', 'mvweb-core' ),
				'description' => __( 'Paid by customers marked as wholesale in their profile. Without a retail price the item is sold wholesale only.', 'mvweb-core' ),
				'type'        => 'text',
			),
			'_mvweb_qty_min'         => array(
				'label'       => __( 'Minimum quantity', 'mvweb-core' ),
				'description' => __( 'Empty or 1 — any quantity.', 'mvweb-core' ),
				'type'        => 'number',
			),
			'_mvweb_qty_step'        => array(
				'label'       => __( 'Quantity step', 'mvweb-core' ),
				'description' => __( 'For example 10: from the minimum on, in tens.', 'mvweb-core' ),
				'type'        => 'number',
			),
			'_mvweb_tiers'           => array(
				'label'       => __( 'Prices by quantity', 'mvweb-core' ),
				'description' => __( 'One per line: quantity, colon, price. For example 100: 95 and 500: 90.', 'mvweb-core' ),
				'type'        => 'textarea',
			),
			'_mvweb_documents'       => array(
				'label'       => __( 'Documents', 'mvweb-core' ),
				'description' => __( 'One per line: name, a vertical bar, address of the file. For example: Datasheet | https://…/tds.pdf', 'mvweb-core' ),
				'type'        => 'textarea',
			),
			'_mvweb_markets'         => array(
				'label'       => __( 'Marketplaces', 'mvweb-core' ),
				'description' => __( 'Where to buy at retail: pick a marketplace and paste the address of the product there. The list and the logos are set in the Customizer, in the product page.', 'mvweb-core' ),
				'type'        => 'textarea',
			),
			'_mvweb_qty_unit'        => array(
				'label'       => __( 'Unit of the minimum quantity', 'mvweb-core' ),
				'description' => __( 'For example pcs or sets. Empty — pcs.', 'mvweb-core' ),
				'type'        => 'text',
			),
			'_mvweb_badge'           => array(
				'label'       => __( 'Own badge', 'mvweb-core' ),
				'description' => __( 'A word on the card of the item, for example Sale of the season. Empty — none.', 'mvweb-core' ),
				'type'        => 'text',
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_trade_box' ) ) {
	/**
	 * The trade box of an item of the theme's own catalogue.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Post being edited.
	 *
	 * @return void
	 */
	function mvweb_core_trade_box( $post ) {
		wp_nonce_field( 'mvweb_trade', 'mvweb_trade_nonce' );
		?>
		<div class="mvweb-core-fields">
			<?php
			foreach ( mvweb_core_trade_fields() as $key => $field ) :
				$name  = substr( $key, 1 );
				$value = (string) get_post_meta( $post->ID, $key, true );
				?>
				<p class="mvweb-core-field">
					<label for="<?php echo esc_attr( $name ); ?>"><?php echo esc_html( $field['label'] ); ?></label>
					<?php if ( 'textarea' === $field['type'] ) : ?>
						<textarea class="widefat" rows="3" id="<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>"><?php echo esc_textarea( $value ); ?></textarea>
					<?php else : ?>
						<input class="widefat" type="<?php echo esc_attr( $field['type'] ); ?>" id="<?php echo esc_attr( $name ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( '0' === $value ? '' : $value ); ?>"<?php echo 'number' === $field['type'] ? ' min="0" step="1"' : ''; ?>>
					<?php endif; ?>
					<span class="description"><?php echo esc_html( $field['description'] ); ?></span>
				</p>
			<?php endforeach; ?>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_trade_meta_box' ) ) {
	/**
	 * Add the trade box to the item screen.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_trade_meta_box() {
		if ( mvweb_core_is_woocommerce() ) {
			return;
		}

		add_meta_box( 'mvweb-core-trade', __( 'Wholesale, documents, marketplaces', 'mvweb-core' ), 'mvweb_core_trade_box', 'mv_item', 'normal', 'default' );
	}
}
add_action( 'add_meta_boxes', 'mvweb_core_trade_meta_box' );

if ( ! function_exists( 'mvweb_core_trade_save' ) ) {
	/**
	 * Store the trade fields of an item.
	 *
	 * @since 0.1.0
	 *
	 * @param int     $post_id Post being saved.
	 * @param WP_Post $post    Post object.
	 *
	 * @return void
	 */
	function mvweb_core_trade_save( $post_id, $post ) {
		if ( 'mv_item' !== $post->post_type || wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified on the next line.
		if ( ! isset( $_POST['mvweb_trade_nonce'] ) ) {
			return;
		}

		check_admin_referer( 'mvweb_trade', 'mvweb_trade_nonce' );

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		foreach ( array_keys( mvweb_core_trade_meta() ) as $key ) {
			$name = substr( $key, 1 );

			if ( isset( $_POST[ $name ] ) ) {
				update_post_meta( $post_id, $key, $_POST[ $name ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- update_post_meta() unslashes and runs the callback the key is registered with.
			}
		}
	}
}
add_action( 'save_post', 'mvweb_core_trade_save', 10, 2 );

if ( ! function_exists( 'mvweb_core_wc_trade_fields' ) ) {
	/**
	 * The trade fields on the product screen of WooCommerce.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_wc_trade_fields() {
		echo '<div class="options_group">';

		foreach ( mvweb_core_trade_fields() as $key => $field ) {
			$args = array(
				'id'          => $key,
				'label'       => $field['label'],
				'description' => $field['description'],
				'desc_tip'    => 'textarea' !== $field['type'],
			);

			if ( 'textarea' === $field['type'] ) {
				woocommerce_wp_textarea_input( $args );
				continue;
			}

			if ( 'number' === $field['type'] ) {
				$args['type']              = 'number';
				$args['custom_attributes'] = array(
					'min'  => '0',
					'step' => '1',
				);
			} elseif ( '_mvweb_wholesale_price' === $key ) {
				$args['data_type'] = 'price';
			}

			woocommerce_wp_text_input( $args );
		}

		echo '</div>';
	}
}

if ( ! function_exists( 'mvweb_core_wc_trade_save' ) ) {
	/**
	 * Store the trade fields of a product.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Product being saved.
	 *
	 * @return void
	 */
	function mvweb_core_wc_trade_save( $product ) {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified in WC_Admin_Meta_Boxes::save_meta_boxes() before this hook fires.
		foreach ( mvweb_core_trade_meta() as $key => $sanitizer ) {
			if ( ! isset( $_POST[ $key ] ) ) {
				continue;
			}

			$raw = 'sanitize_textarea_field' === $sanitizer
				? sanitize_textarea_field( wp_unslash( $_POST[ $key ] ) )
				: sanitize_text_field( wp_unslash( $_POST[ $key ] ) );

			$product->update_meta_data( $key, call_user_func( $sanitizer, $raw ) );
		}
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}
}


if ( ! function_exists( 'mvweb_core_register_request_gateway' ) ) {
	/**
	 * Offer the "no payment, a manager calls back" way to place an order.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $gateways Gateway classes.
	 *
	 * @return string[]
	 */
	function mvweb_core_register_request_gateway( $gateways ) {
		if ( ! class_exists( 'MVweb_Core_Request_Gateway' ) ) {
			require_once MVWEB_CORE_DIR . '/inc/class-mvweb-core-request-gateway.php';
		}

		$gateways[] = 'MVweb_Core_Request_Gateway';

		return $gateways;
	}
}

if ( ! function_exists( 'mvweb_core_register_request_blocks' ) ) {
	/**
	 * Show the request gateway in the block checkout too.
	 *
	 * @since 0.1.0
	 *
	 * @param \Automattic\WooCommerce\Blocks\Payments\PaymentMethodRegistry $registry Registry of the block checkout.
	 *
	 * @return void
	 */
	function mvweb_core_register_request_blocks( $registry ) {
		require_once MVWEB_CORE_DIR . '/inc/class-mvweb-core-request-blocks.php';

		$registry->register( new MVweb_Core_Request_Blocks() );
	}
}

if ( mvweb_core_is_woocommerce() ) {
	add_filter( 'woocommerce_product_get_price', 'mvweb_core_wc_wholesale_price', 20, 2 );
	add_filter( 'woocommerce_product_variation_get_price', 'mvweb_core_wc_wholesale_price', 20, 2 );
	add_filter( 'woocommerce_is_purchasable', 'mvweb_core_wc_wholesale_only', 20, 2 );
	add_filter( 'woocommerce_quantity_input_args', 'mvweb_core_wc_quantity_args', 10, 2 );
	add_filter( 'woocommerce_add_to_cart_validation', 'mvweb_core_wc_add_validation', 10, 3 );
	add_filter( 'woocommerce_update_cart_validation', 'mvweb_core_wc_update_validation', 10, 4 );
	add_action( 'woocommerce_before_calculate_totals', 'mvweb_core_wc_tier_prices', 20 );
	add_filter( 'woocommerce_store_api_product_quantity_minimum', 'mvweb_core_store_api_minimum', 10, 2 );
	add_filter( 'woocommerce_store_api_product_quantity_multiple_of', 'mvweb_core_store_api_step', 10, 2 );
	add_filter( 'woocommerce_get_variation_prices_hash', 'mvweb_core_wc_variation_hash' );
	add_action( 'woocommerce_product_options_general_product_data', 'mvweb_core_wc_trade_fields', 20 );
	add_action( 'woocommerce_admin_process_product_object', 'mvweb_core_wc_trade_save' );
	add_filter( 'woocommerce_payment_gateways', 'mvweb_core_register_request_gateway' );
	add_action( 'woocommerce_blocks_payment_method_type_registration', 'mvweb_core_register_request_blocks' );
}
