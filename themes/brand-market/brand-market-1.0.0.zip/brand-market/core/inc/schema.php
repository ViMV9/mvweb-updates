<?php
/**
 * Structured data of the theme's own entities.
 *
 * Two nodes: the Product of a catalogue item of the theme and the Service of a
 * service. They are not printed from here: inc/entities/markup.php places them
 * into the graph of the page, next to the company, the page and the trail.
 *
 * WooCommerce answers for its own goods through WC_Structured_Data, so a store
 * product never reaches this file.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_currency_code' ) ) {
	/**
	 * The currency of the prices, as the three letters schema.org asks for.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_currency_code() {
		if ( mvweb_core_is_woocommerce() ) {
			return (string) get_woocommerce_currency();
		}

		$code = strtoupper( trim( (string) mvweb_core_option( 'mvweb_currency_code' ) ) );

		return preg_match( '/^[A-Z]{3}$/', $code ) ? $code : '';
	}
}

if ( ! function_exists( 'mvweb_core_schema_images' ) ) {
	/**
	 * Addresses of the pictures of an entry, the main one first.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Entry id.
	 *
	 * @return string[]
	 */
	function mvweb_core_schema_images( $id ) {
		$images = array();

		foreach ( mvweb_core_item_gallery( $id ) as $attachment ) {
			$src = wp_get_attachment_image_url( $attachment, 'full' );

			if ( $src ) {
				$images[] = $src;
			}
		}

		return $images;
	}
}

if ( ! function_exists( 'mvweb_core_schema_description' ) ) {
	/**
	 * The short description of an entry as plain text.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Entry id.
	 *
	 * @return string
	 */
	function mvweb_core_schema_description( $id ) {
		$text = wp_strip_all_tags( mvweb_core_item_excerpt( $id ), true );

		if ( '' === trim( $text ) ) {
			$text = wp_strip_all_tags( mvweb_core_item_content( $id ), true );
		}

		return trim( wp_html_excerpt( trim( $text ), 300, '…' ) );
	}
}

if ( ! function_exists( 'mvweb_core_item_schema' ) ) {
	/**
	 * The Product node of a catalogue item.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_item_schema( $id ) {
		$node = array(
			'@context' => 'https://schema.org',
			'@type'    => 'Product',
			'name'     => get_post_field( 'post_title', $id ),
			'url'      => (string) get_permalink( $id ),
		);

		$description = mvweb_core_schema_description( $id );

		if ( '' !== $description ) {
			$node['description'] = $description;
		}

		$images = mvweb_core_schema_images( $id );

		if ( ! empty( $images ) ) {
			$node['image'] = $images;
		}

		$sku = mvweb_core_item_sku( $id );

		if ( '' !== $sku ) {
			$node['sku'] = $sku;
		}

		$brand = mvweb_core_item_brand( $id );

		if ( '' !== $brand ) {
			$node['brand'] = array(
				'@type' => 'Brand',
				'name'  => $brand,
			);
		}

		$price    = mvweb_core_sanitize_amount( get_post_meta( $id, '_mvweb_price', true ) );
		$currency = mvweb_core_currency_code();

		if ( '' !== $price && '' !== $currency ) {
			$node['offers'] = array(
				'@type'         => 'Offer',
				'url'           => (string) get_permalink( $id ),
				'price'         => $price,
				'priceCurrency' => $currency,
			);
		}

		return $node;
	}
}

if ( ! function_exists( 'mvweb_core_service_schema' ) ) {
	/**
	 * The Service node of a service.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Service id.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_service_schema( $id ) {
		$node = array(
			'@context' => 'https://schema.org',
			'@type'    => 'Service',
			'name'     => get_post_field( 'post_title', $id ),
			'url'      => (string) get_permalink( $id ),
			'provider' => array(
				'@type' => 'Organization',
				'name'  => get_bloginfo( 'name' ),
				'url'   => home_url( '/' ),
			),
		);

		$description = mvweb_core_schema_description( $id );

		if ( '' !== $description ) {
			$node['description'] = $description;
		}

		$images = mvweb_core_schema_images( $id );

		if ( ! empty( $images ) ) {
			$node['image'] = $images;
		}

		$terms = get_the_terms( $id, 'mv_service_cat' );

		if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
			$node['serviceType'] = $terms[0]->name;
		}

		$price    = mvweb_core_sanitize_amount( get_post_meta( $id, '_mvweb_price', true ) );
		$currency = mvweb_core_currency_code();

		if ( '' !== $price && '' !== $currency ) {
			$node['offers'] = array(
				'@type'              => 'Offer',
				'url'                => (string) get_permalink( $id ),
				'priceSpecification' => array(
					'@type'         => 'PriceSpecification',
					'minPrice'      => $price,
					'priceCurrency' => $currency,
				),
			);
		}

		return $node;
	}
}

if ( ! function_exists( 'mvweb_core_schema_node' ) ) {
	/**
	 * The node this request should print, if any.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed> Empty when there is nothing of ours to mark up.
	 */
	function mvweb_core_schema_node() {
		$node = array();
		$id   = get_queried_object_id();

		if ( is_singular( 'mv_item' ) ) {
			$node = mvweb_core_item_schema( $id );
		} elseif ( is_singular( 'mv_service' ) ) {
			$node = mvweb_core_service_schema( $id );
		}

		/**
		 * Filter the structured data node of the request.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,mixed> $node Node, empty when the theme prints none.
		 * @param int                 $id   Queried entry id.
		 */
		return (array) apply_filters( 'mvweb_core_schema', $node, $id );
	}
}

if ( ! function_exists( 'mvweb_core_print_schema' ) ) {
	/**
	 * Print the node in the head.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_print_schema() {
		$node = mvweb_core_schema_node();

		if ( empty( $node ) ) {
			return;
		}

		$json = wp_json_encode( $node, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP );

		if ( ! $json ) {
			return;
		}

		printf( '<script type="application/ld+json">%s</script>' . "\n", $json ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_json_encode() escapes the slashes that could close the block.
	}
}
add_action( 'wp_head', 'mvweb_core_print_schema', 20 );
