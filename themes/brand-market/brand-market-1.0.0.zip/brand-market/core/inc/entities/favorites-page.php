<?php
/**
 * The page of the favourites: sharing the list, clearing it and the look of the cards.
 *
 * The list and its routes live in inc/favorites.php; this file adds, by hooks,
 * what the page of the list needs on top of them.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_favorites_is_page' ) ) {
	/**
	 * Whether the page being shown is the page of the favourites.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_favorites_is_page() {
		return function_exists( 'mvweb_core_favorites_page_id' ) && mvweb_core_favorites_page_id() > 0 && is_page( mvweb_core_favorites_page_id() );
	}
}

if ( ! function_exists( 'mvweb_core_favorites_page_data' ) ) {
	/**
	 * The words the page of the favourites says in the browser.
	 *
	 * @since 0.1.0
	 *
	 * @param array $data Existing data.
	 *
	 * @return array
	 */
	function mvweb_core_favorites_page_data( $data ) {
		$data['forms'] = array(
			/* translators: %d: number of items in the list. */
			'one'  => _n( '%d item', '%d items', 1, 'mvweb-core' ),
			/* translators: %d: number of items in the list. */
			'few'  => _n( '%d item', '%d items', 2, 'mvweb-core' ),
			/* translators: %d: number of items in the list. */
			'many' => _n( '%d item', '%d items', 5, 'mvweb-core' ),
		);

		$data['copied']     = __( 'Link copied', 'mvweb-core' );
		$data['copyPrompt'] = __( 'Copy the link to the list', 'mvweb-core' );
		$data['cleared']    = __( 'The list is cleared', 'mvweb-core' );
		$data['clearAsk']   = __( 'Remove everything from the favourites?', 'mvweb-core' );

		return $data;
	}
}
add_filter( 'script_module_data_@mvweb-core/favorites', 'mvweb_core_favorites_page_data', 20 );

if ( ! function_exists( 'mvweb_core_favorites_page_styles' ) ) {
	/**
	 * The stylesheet of the tools above the list.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Handles without the theme prefix.
	 *
	 * @return string[]
	 */
	function mvweb_core_favorites_page_styles( $styles ) {
		if ( mvweb_core_favorites_is_page() ) {
			$styles[] = 'favorites';
		}

		return $styles;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_core_favorites_page_styles', 20 );

if ( ! function_exists( 'mvweb_core_favorites_page_modules' ) ) {
	/**
	 * The switch between the cards and the table works on the page of the list too.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules File names without extension.
	 *
	 * @return string[]
	 */
	function mvweb_core_favorites_page_modules( $modules ) {
		if ( mvweb_core_favorites_is_page() && mvweb_core_catalog_view_switch() ) {
			$modules[] = 'catalog-view';
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_core_favorites_page_modules', 20 );
