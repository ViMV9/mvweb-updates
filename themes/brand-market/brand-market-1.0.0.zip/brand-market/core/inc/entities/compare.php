<?php
/**
 * Comparison of items.
 *
 * Built on the pattern of the favourites: a guest keeps the list in the
 * browser, a signed-in visitor keeps it in user meta. The items are compared
 * in groups by the top category, because the characteristics of dog food and
 * of a toy have nothing in common; a group takes as many items as the owner
 * allows. The table is rendered on the server from the template part
 * template-parts/compare/table and returned as markup, so the page shows the
 * same data in every theme and the client keeps no copy of the layout.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_compare_key' ) ) {
	/**
	 * Meta key the list is stored under.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_compare_key() {
		return '_mvweb_compare';
	}
}

if ( ! function_exists( 'mvweb_core_compare_limit' ) ) {
	/**
	 * How many items of one category can be compared.
	 *
	 * @since 0.1.0
	 *
	 * @return int
	 */
	function mvweb_core_compare_limit() {
		return max( 2, min( 6, absint( get_theme_mod( 'mvweb_compare_max', 4 ) ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_compare_page_id' ) ) {
	/**
	 * The page the comparison is shown on.
	 *
	 * @since 0.1.0
	 *
	 * @return int
	 */
	function mvweb_core_compare_page_id() {
		return absint( get_theme_mod( 'mvweb_compare_page', 0 ) );
	}
}

if ( ! function_exists( 'mvweb_core_compare_url' ) ) {
	/**
	 * Address of the comparison page.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty while no published page is chosen.
	 */
	function mvweb_core_compare_url() {
		$id = mvweb_core_compare_page_id();

		if ( 0 === $id || 'publish' !== get_post_status( $id ) ) {
			return '';
		}

		return (string) get_permalink( $id );
	}
}

if ( ! function_exists( 'mvweb_core_compare_enabled' ) ) {
	/**
	 * Whether the comparison is on: a page is chosen for it.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_compare_enabled() {
		return '' !== mvweb_core_compare_url();
	}
}

if ( ! function_exists( 'mvweb_core_compare_is_page' ) ) {
	/**
	 * Whether the page being shown is the comparison page.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_compare_is_page() {
		return mvweb_core_compare_page_id() > 0 && is_page( mvweb_core_compare_page_id() );
	}
}

if ( ! function_exists( 'mvweb_core_compare_category' ) ) {
	/**
	 * The group an item is compared in: the top category it is filed under.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return int Term id, 0 for an item without a category.
	 */
	function mvweb_core_compare_category( $id ) {
		$taxonomy = mvweb_core_taxonomy();
		$terms    = get_the_terms( absint( $id ), $taxonomy );

		if ( ! is_array( $terms ) || empty( $terms ) ) {
			return 0;
		}

		$term      = reset( $terms );
		$ancestors = get_ancestors( $term->term_id, $taxonomy, 'taxonomy' );

		return empty( $ancestors ) ? (int) $term->term_id : (int) end( $ancestors );
	}
}

if ( ! function_exists( 'mvweb_core_compare_cats' ) ) {
	/**
	 * The group of every item of a list.
	 *
	 * @since 0.1.0
	 *
	 * @param int[] $ids Item ids.
	 *
	 * @return array<int,int> Item id => term id.
	 */
	function mvweb_core_compare_cats( $ids ) {
		$cats = array();

		foreach ( (array) $ids as $id ) {
			$cats[ (int) $id ] = mvweb_core_compare_category( $id );
		}

		return $cats;
	}
}

if ( ! function_exists( 'mvweb_core_compare_clean' ) ) {
	/**
	 * Keep the items a visitor may see, within the limit of their group.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $ids Raw list.
	 *
	 * @return int[]
	 */
	function mvweb_core_compare_clean( $ids ) {
		if ( ! is_array( $ids ) ) {
			return array();
		}

		$limit = mvweb_core_compare_limit();
		$clean = array();
		$taken = array();

		foreach ( array_slice( $ids, 0, 48 ) as $id ) {
			$id = absint( $id );

			if ( 0 === $id || isset( $clean[ $id ] ) || ! mvweb_core_item_visible( $id ) ) {
				continue;
			}

			$group           = mvweb_core_compare_category( $id );
			$taken[ $group ] = isset( $taken[ $group ] ) ? $taken[ $group ] + 1 : 1;

			if ( $taken[ $group ] <= $limit ) {
				$clean[ $id ] = $id;
			}
		}

		return array_values( $clean );
	}
}

if ( ! function_exists( 'mvweb_core_compare_get' ) ) {
	/**
	 * The stored list of the current visitor.
	 *
	 * @since 0.1.0
	 *
	 * @return int[] Empty for a guest: their list lives in the browser.
	 */
	function mvweb_core_compare_get() {
		if ( ! is_user_logged_in() ) {
			return array();
		}

		return mvweb_core_compare_clean( get_user_meta( get_current_user_id(), mvweb_core_compare_key(), true ) );
	}
}

if ( ! function_exists( 'mvweb_core_compare_save' ) ) {
	/**
	 * Replace the stored list of the current visitor.
	 *
	 * @since 0.1.0
	 *
	 * @param array $ids Item ids.
	 *
	 * @return int[] The list as it was stored.
	 */
	function mvweb_core_compare_save( $ids ) {
		$clean = mvweb_core_compare_clean( $ids );

		update_user_meta( get_current_user_id(), mvweb_core_compare_key(), $clean );

		return $clean;
	}
}

if ( ! function_exists( 'mvweb_core_compare_same' ) ) {
	/**
	 * Whether every cell of a row says the same.
	 *
	 * @since 0.1.0
	 *
	 * @param array $values Cell texts of the row.
	 *
	 * @return bool
	 */
	function mvweb_core_compare_same( $values ) {
		$texts = array_map(
			static function ( $value ) {
				return trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) $value ) ) );
			},
			array_values( (array) $values )
		);

		return 1 === count( array_unique( $texts ) );
	}
}

if ( ! function_exists( 'mvweb_core_compare_specs' ) ) {
	/**
	 * The characteristics of the items as rows of one table.
	 *
	 * @since 0.1.0
	 *
	 * @param int[] $ids Item ids.
	 *
	 * @return array<int,array{label:string,cells:array<int,string>,same:bool}>
	 */
	function mvweb_core_compare_specs( $ids ) {
		$brand = __( 'Brand', 'mvweb-core' );
		$rows  = array();

		foreach ( $ids as $id ) {
			$own = mvweb_core_item_brand( $id );

			foreach ( mvweb_core_item_specs( $id ) as $spec ) {
				$label = trim( (string) $spec['label'] );
				$value = trim( (string) $spec['value'] );

				if ( '' === $label || '' === $value || ( $brand === $label && $own === $value ) ) {
					continue;
				}

				if ( ! isset( $rows[ $label ] ) ) {
					$rows[ $label ] = array(
						'label' => $label,
						'cells' => array_fill_keys( $ids, '' ),
						'same'  => false,
					);
				}

				$rows[ $label ]['cells'][ $id ] = $value;
			}
		}

		foreach ( $rows as $label => $row ) {
			$rows[ $label ]['same'] = mvweb_core_compare_same( $row['cells'] );
		}

		return array_values( $rows );
	}
}

if ( ! function_exists( 'mvweb_core_compare_model' ) ) {
	/**
	 * Everything the table needs, for a list and the group being looked at.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $ids Raw list.
	 * @param int   $cat Group asked for; the biggest one when it is not in the list.
	 *
	 * @return array{ids:int[],groups:array<int,array<string,mixed>>,cat:int,items:int[],rows:array}
	 */
	function mvweb_core_compare_model( $ids, $cat = 0 ) {
		$ids    = mvweb_core_compare_clean( $ids );
		$groups = array();

		foreach ( $ids as $id ) {
			$key = mvweb_core_compare_category( $id );

			if ( ! isset( $groups[ $key ] ) ) {
				$term           = $key ? get_term( $key ) : null;
				$groups[ $key ] = array(
					'id'   => $key,
					'name' => $term instanceof WP_Term ? $term->name : __( 'Other', 'mvweb-core' ),
					'ids'  => array(),
				);
			}

			$groups[ $key ]['ids'][] = $id;
		}

		$cat = absint( $cat );

		if ( ! isset( $groups[ $cat ] ) ) {
			$cat  = 0;
			$best = 0;

			foreach ( $groups as $key => $group ) {
				if ( count( $group['ids'] ) > $best ) {
					$best = count( $group['ids'] );
					$cat  = (int) $key;
				}
			}
		}

		$items = isset( $groups[ $cat ] ) ? $groups[ $cat ]['ids'] : array();

		return array(
			'ids'    => $ids,
			'groups' => $groups,
			'cat'    => $cat,
			'items'  => $items,
			'rows'   => count( $items ) > 1 ? mvweb_core_compare_specs( $items ) : array(),
		);
	}
}

if ( ! function_exists( 'mvweb_core_compare_routes' ) ) {
	/**
	 * Two routes: writing the list of a signed-in visitor, and the table by a list of ids.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_compare_routes() {
		register_rest_route(
			'mvweb-core/v1',
			'/compare',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => 'mvweb_core_compare_write',
				'permission_callback' => 'is_user_logged_in',
				'args'                => array(
					'ids'   => array(
						'type'     => 'array',
						'required' => true,
						'maxItems' => 48,
						'items'    => array( 'type' => 'integer' ),
					),
					'merge' => array(
						'type'    => 'boolean',
						'default' => false,
					),
				),
			)
		);

		register_rest_route(
			'mvweb-core/v1',
			'/compare/table',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => 'mvweb_core_compare_table',
				'permission_callback' => '__return_true',
				'args'                => array(
					'ids' => array(
						'type'     => 'array',
						'required' => true,
						'maxItems' => 48,
						'items'    => array( 'type' => 'integer' ),
					),
					'cat' => array(
						'type'    => 'integer',
						'default' => 0,
					),
				),
			)
		);
	}
}
add_action( 'rest_api_init', 'mvweb_core_compare_routes' );

if ( ! function_exists( 'mvweb_core_compare_write' ) ) {
	/**
	 * Store the list of the signed-in visitor.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response
	 */
	function mvweb_core_compare_write( $request ) {
		$ids = (array) $request->get_param( 'ids' );

		if ( $request->get_param( 'merge' ) ) {
			$ids = array_merge( mvweb_core_compare_get(), $ids );
		}

		$saved = mvweb_core_compare_save( $ids );

		return rest_ensure_response(
			array(
				'ids'  => $saved,
				'cats' => mvweb_core_compare_cats( $saved ),
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_compare_table' ) ) {
	/**
	 * The table of one group, with the facts the head of the page shows.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response
	 */
	function mvweb_core_compare_table( $request ) {
		$model = mvweb_core_compare_model( $request->get_param( 'ids' ), $request->get_param( 'cat' ) );
		$meta  = array();
		$count = count( $model['items'] );

		if ( $count > 1 ) {
			/* translators: %d: number of compared items. */
			$meta[] = sprintf( _n( '%d item', '%d items', $count, 'mvweb-core' ), $count );

			if ( $model['cat'] > 0 ) {
				/* translators: %s: name of the category. */
				$meta[] = sprintf( __( 'Category “%s”', 'mvweb-core' ), $model['groups'][ $model['cat'] ]['name'] );
			}
		}

		ob_start();

		get_template_part( 'template-parts/compare/table', null, array( 'model' => $model ) );

		return rest_ensure_response(
			array(
				'ids'  => $model['ids'],
				'cats' => mvweb_core_compare_cats( $model['ids'] ),
				'cat'  => $model['cat'],
				'meta' => $meta,
				'html' => ob_get_clean(),
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_compare_data' ) ) {
	/**
	 * What the comparison module needs to talk to the site.
	 *
	 * @since 0.1.0
	 *
	 * @param array $data Existing data.
	 *
	 * @return array
	 */
	function mvweb_core_compare_data( $data ) {
		$stored = mvweb_core_compare_get();

		$data['root']     = esc_url_raw( rest_url( 'mvweb-core/v1/compare' ) );
		$data['nonce']    = wp_create_nonce( 'wp_rest' );
		$data['loggedIn'] = is_user_logged_in();
		$data['stored']   = $stored;
		$data['cats']     = (object) mvweb_core_compare_cats( $stored );
		$data['max']      = mvweb_core_compare_limit();
		$data['added']    = __( 'In comparison', 'mvweb-core' );
		$data['add']      = __( 'Add to comparison', 'mvweb-core' );
		$data['toast']    = array(
			'added'   => __( 'Added to comparison', 'mvweb-core' ),
			'removed' => __( 'Removed from comparison', 'mvweb-core' ),
			/* translators: %d: how many items of one category can be compared. */
			'limit'   => sprintf( __( 'You can compare up to %d items of one category', 'mvweb-core' ), mvweb_core_compare_limit() ),
			'failed'  => __( 'Could not save the list. Try again', 'mvweb-core' ),
		);

		return $data;
	}
}
add_filter( 'script_module_data_@mvweb-core/compare', 'mvweb_core_compare_data' );

if ( ! function_exists( 'mvweb_core_compare_fields' ) ) {
	/**
	 * The settings of the comparison: its page and how many items it takes.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_compare_fields() {
		return array(
			array(
				'type'              => 'dropdown_pages',
				'settings'          => 'mvweb_compare_page',
				'section'           => 'mvweb_cz_conversion_cta',
				'label'             => __( 'Comparison page', 'mvweb-core' ),
				'description'       => __( 'A page with the Comparison template. Not selected: the comparison is off, no button and no icon in the header.', 'mvweb-core' ),
				'default'           => 0,
				'sanitize_callback' => 'absint',
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_compare_max',
				'section'     => 'mvweb_cz_conversion_cta',
				'label'       => __( 'Items of one category in the comparison', 'mvweb-core' ),
				'description' => __( 'Items of different categories are compared separately, each category takes this many.', 'mvweb-core' ),
				'default'     => 4,
				'input_attrs' => array(
					'min'  => 2,
					'max'  => 6,
					'step' => 1,
				),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_compare_register' ) ) {
	/**
	 * Hand the fields to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_compare_register( $kit ) {
		$kit->add_fields( mvweb_core_compare_fields() );
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_compare_register' );

if ( ! function_exists( 'mvweb_core_compare_zone_elements' ) ) {
	/**
	 * The comparison link as an element of the header zones.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $elements Element slug => label.
	 * @param string               $zone     Zone slug.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_compare_zone_elements( $elements, $zone ) {
		if ( in_array( $zone, array( 'header-actions', 'header-nav' ), true ) ) {
			$elements['compare'] = __( 'Comparison', 'mvweb-core' );
		}

		return $elements;
	}
}
add_filter( 'mvweb_core_zone_elements', 'mvweb_core_compare_zone_elements', 20, 2 );

if ( ! function_exists( 'mvweb_core_compare_template_names' ) ) {
	/**
	 * Name of the page template in the site language.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $templates Template names keyed by file.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_compare_template_names( $templates ) {
		if ( isset( $templates['page-templates/compare.php'] ) ) {
			$templates['page-templates/compare.php'] = __( 'Comparison', 'mvweb-core' );
		}

		return $templates;
	}
}
add_filter( 'theme_page_templates', 'mvweb_core_compare_template_names' );

if ( ! function_exists( 'mvweb_core_compare_styles' ) ) {
	/**
	 * The stylesheets of the comparison: the button goes where cards are, the table and the cards of its head belong to the page.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Handles without the theme prefix.
	 *
	 * @return string[]
	 */
	function mvweb_core_compare_styles( $styles ) {
		if ( ! mvweb_core_compare_enabled() ) {
			return $styles;
		}

		$styles[] = 'compare';

		if ( mvweb_core_compare_is_page() ) {
			array_push( $styles, 'catalog', 'empty' );
		}

		return $styles;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_core_compare_styles', 20 );

if ( ! function_exists( 'mvweb_core_compare_modules' ) ) {
	/**
	 * Load the script of the comparison where it is switched on.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules File names without extension.
	 *
	 * @return string[]
	 */
	function mvweb_core_compare_modules( $modules ) {
		if ( mvweb_core_compare_enabled() ) {
			$modules[] = 'compare';
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_core_compare_modules' );

if ( ! function_exists( 'mvweb_core_compare_wp_robots' ) ) {
	/**
	 * Keep the comparison page out of the index: it is drawn by a script and is empty to a robot.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $robots Directives.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_compare_wp_robots( $robots ) {
		if ( ! mvweb_core_compare_is_page() ) {
			return $robots;
		}

		unset( $robots['index'], $robots['nofollow'] );

		$robots['noindex'] = true;
		$robots['follow']  = true;

		return $robots;
	}
}
add_filter( 'wp_robots', 'mvweb_core_compare_wp_robots', 11 );

if ( ! function_exists( 'mvweb_core_compare_yoast_robots' ) ) {
	/**
	 * The same for the directives Yoast prints.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $robots Directives in Yoast's shape.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_compare_yoast_robots( $robots ) {
		if ( mvweb_core_compare_is_page() ) {
			$robots['index']  = 'noindex';
			$robots['follow'] = 'follow';
		}

		return $robots;
	}
}
add_filter( 'wpseo_robots_array', 'mvweb_core_compare_yoast_robots', 11 );
