<?php
/**
 * Warm the caches of a list of items before their cards are drawn.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_prime_items' ) ) {
	/**
	 * Load the posts, their meta and their thumbnails in one query each.
	 *
	 * @since 0.1.0
	 *
	 * @param int[] $ids Item ids.
	 *
	 * @return int[] The same ids, cleaned.
	 */
	function mvweb_core_prime_items( $ids ) {
		$ids = array_values( array_filter( array_map( 'absint', (array) $ids ) ) );

		if ( count( $ids ) > 1 ) {
			_prime_post_caches( $ids, false, true );

			$thumbnails = array_filter( array_map( 'get_post_thumbnail_id', $ids ) );

			if ( $thumbnails ) {
				_prime_post_caches( $thumbnails, false, true );
			}
		}

		return $ids;
	}
}
