<?php
/**
 * Structured data of the site: one graph in the head, three groups to switch.
 *
 * The theme answers for its markup itself and does not lean on an SEO plugin.
 * The groups are "Site and pages" (WebSite, the page, the breadcrumbs, the
 * article and its author), "Organization" (the company, from the contacts of
 * the chosen city) and "Items and services" (Product and Service, which
 * inc/schema.php builds and this file only places in the graph). A node is
 * printed only when the page shows what it says: the breadcrumbs follow their
 * switch, the author follows the parts of the post that print it.
 *
 * Nothing is turned off by itself. When an SEO plugin prints the same nodes,
 * the owner is told where the switches are. One exception is the company
 * node: MVweb Local Business prints it with much more than the contacts hold,
 * so while the plugin is ready the theme leaves it that node and only refers
 * to it.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_markup_tree' ) ) {
	/**
	 * A section of its own in the panel of codes.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_markup_tree( $tree ) {
		if ( isset( $tree['mvweb_cz_codes']['sections'] ) ) {
			$tree['mvweb_cz_codes']['sections']['mvweb_cz_codes_markup'] = __( 'Structured data', 'mvweb-core' );
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_markup_tree', 98 );

if ( ! function_exists( 'mvweb_core_markup_groups' ) ) {
	/**
	 * The groups of nodes the owner can switch.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,string>> Key => label and description.
	 */
	function mvweb_core_markup_groups() {
		return array(
			'site'    => array(
				'label'       => __( 'Site and pages', 'mvweb-core' ),
				'description' => __( 'WebSite with the search, the page, the breadcrumbs, the article and its author.', 'mvweb-core' ),
			),
			'org'     => array(
				'label'       => __( 'Organization', 'mvweb-core' ),
				'description' => __( 'The company: name, logo, phone, email, address and social networks. The phone, email and address are those of the chosen city.', 'mvweb-core' ),
			),
			'catalog' => array(
				'label'       => __( 'Items and services', 'mvweb-core' ),
				'description' => __( 'Product of an item of the own catalogue and Service of a service. The goods of WooCommerce are marked up by WooCommerce.', 'mvweb-core' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_markup_on' ) ) {
	/**
	 * Whether a group is switched on.
	 *
	 * @since 0.1.0
	 *
	 * @param string $group Group key.
	 *
	 * @return bool
	 */
	function mvweb_core_markup_on( $group ) {
		return (bool) get_theme_mod( 'mvweb_markup_' . $group, true );
	}
}

if ( ! function_exists( 'mvweb_core_markup_plugins' ) ) {
	/**
	 * SEO plugins that print structured data of their own.
	 *
	 * @since 0.1.0
	 *
	 * @return string[] Names of the active ones.
	 */
	function mvweb_core_markup_plugins() {
		$found = array();

		$checks = array(
			'Yoast SEO'         => defined( 'WPSEO_VERSION' ),
			'Rank Math'         => defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ),
			'All in One SEO'    => defined( 'AIOSEO_VERSION' ),
			'SEOPress'          => defined( 'SEOPRESS_VERSION' ),
			'The SEO Framework' => defined( 'THE_SEO_FRAMEWORK_VERSION' ),
			'Slim SEO'          => defined( 'SLIM_SEO_VER' ),
		);

		foreach ( $checks as $name => $active ) {
			if ( $active ) {
				$found[] = $name;
			}
		}

		/**
		 * Filter the plugins that print structured data.
		 *
		 * @since 0.1.0
		 *
		 * @param string[] $found Names of the active ones.
		 */
		return array_values( array_unique( (array) apply_filters( 'mvweb_core_markup_plugins', $found ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_markup_conflicts' ) ) {
	/**
	 * The plugins whose nodes the theme would print a second time.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_markup_conflicts() {
		if ( ! mvweb_core_markup_on( 'site' ) && ! mvweb_core_markup_on( 'org' ) ) {
			return array();
		}

		return mvweb_core_markup_plugins();
	}
}

if ( ! function_exists( 'mvweb_core_markup_company_owned' ) ) {
	/**
	 * Whether MVweb Local Business prints the node of the company.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_markup_company_owned() {
		return class_exists( 'MVweb_LB_Schema' ) && function_exists( 'mvweb_lb_is_ready' ) && mvweb_lb_is_ready();
	}
}

if ( ! function_exists( 'mvweb_core_markup_settings_url' ) ) {
	/**
	 * Where the switches are.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_markup_settings_url() {
		return add_query_arg( 'autofocus[section]', 'mvweb_cz_codes_markup', admin_url( 'customize.php' ) );
	}
}

if ( ! function_exists( 'mvweb_core_markup_fields' ) ) {
	/**
	 * Fields of the groups, with the warnings that the active plugins call for.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_markup_fields() {
		$section   = 'mvweb_cz_codes_markup';
		$fields    = array();
		$conflicts = mvweb_core_markup_conflicts();

		if ( ! empty( $conflicts ) ) {
			$fields[] = array(
				'type'        => 'heading',
				'section'     => $section,
				'label'       => sprintf(
					/* translators: %s: names of the plugins. */
					__( 'Structured data also comes from: %s', 'mvweb-core' ),
					implode( ', ', $conflicts )
				),
				'description' => __( 'A page would carry two copies of the same nodes. Switch off “Site and pages” and “Organization” below, or turn the markup off in the plugin. Nothing is switched off by itself.', 'mvweb-core' ),
				'priority'    => 1,
			);
		}

		if ( mvweb_core_markup_company_owned() ) {
			$fields[] = array(
				'type'        => 'heading',
				'section'     => $section,
				'label'       => __( 'MVweb Local Business prints the company', 'mvweb-core' ),
				'description' => __( 'While the plugin is ready, “Organization” stays silent and the other nodes refer to the plugin’s one.', 'mvweb-core' ),
				'priority'    => 2,
			);
		}

		foreach ( mvweb_core_markup_groups() as $key => $group ) {
			$fields[] = array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_markup_' . $key,
				'section'     => $section,
				'label'       => $group['label'],
				'description' => $group['description'],
				'default'     => true,
			);
		}

		return $fields;
	}
}

if ( ! function_exists( 'mvweb_core_markup_register_fields' ) ) {
	/**
	 * Hand the fields to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_markup_register_fields( $kit ) {
		$kit->add_fields( mvweb_core_markup_fields() );
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_markup_register_fields' );

if ( ! function_exists( 'mvweb_core_markup_admin_notice' ) ) {
	/**
	 * Tell the owner about a plugin that prints the same nodes.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_markup_admin_notice() {
		$screen = get_current_screen();

		if ( ! $screen || ! in_array( $screen->id, array( 'dashboard', 'plugins', 'themes' ), true ) || ! current_user_can( 'edit_theme_options' ) ) {
			return;
		}

		$conflicts = mvweb_core_markup_conflicts();

		if ( empty( $conflicts ) ) {
			return;
		}

		printf(
			'<div class="notice notice-warning is-dismissible"><p>%1$s <a href="%2$s">%3$s</a></p></div>',
			esc_html(
				sprintf(
					/* translators: %s: names of the plugins. */
					__( 'The theme and %s both print structured data: a page gets two copies of the same nodes.', 'mvweb-core' ),
					implode( ', ', $conflicts )
				)
			),
			esc_url( mvweb_core_markup_settings_url() ),
			esc_html__( 'Open the switches', 'mvweb-core' )
		);
	}
}
add_action( 'admin_notices', 'mvweb_core_markup_admin_notice' );

if ( ! function_exists( 'mvweb_core_markup_allowed' ) ) {
	/**
	 * Whether the page may carry structured data.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_markup_allowed() {
		$allowed = ! is_admin() && ! is_feed() && ! is_404() && ! is_search() && ! is_embed()
			&& (bool) get_option( 'blog_public' )
			&& ! mvweb_core_noindex();

		if ( $allowed && function_exists( 'is_cart' ) ) {
			$allowed = ! ( is_cart() || is_checkout() || is_account_page() );
		}

		/**
		 * Filter whether the page carries structured data.
		 *
		 * @since 0.1.0
		 *
		 * @param bool $allowed Whether it does.
		 */
		return (bool) apply_filters( 'mvweb_core_markup_allowed', $allowed );
	}
}

if ( ! function_exists( 'mvweb_core_markup_url' ) ) {
	/**
	 * The address of the page being shown, without the parameters of the visit.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_markup_url() {
		if ( is_singular() ) {
			return (string) get_permalink();
		}

		if ( is_front_page() ) {
			return home_url( '/' );
		}

		$link = (string) get_pagenum_link( max( 1, (int) get_query_var( 'paged' ) ), false );

		return get_option( 'permalink_structure' ) ? (string) strtok( $link, '?' ) : $link;
	}
}

if ( ! function_exists( 'mvweb_core_markup_id' ) ) {
	/**
	 * The @id of a node of the site.
	 *
	 * @since 0.1.0
	 *
	 * @param string $node Node name.
	 *
	 * @return string
	 */
	function mvweb_core_markup_id( $node ) {
		return home_url( '/' ) . '#' . $node;
	}
}

if ( ! function_exists( 'mvweb_core_markup_text' ) ) {
	/**
	 * Plain text of a label that may carry tags and entities.
	 *
	 * @since 0.1.0
	 *
	 * @param string $text Label.
	 *
	 * @return string
	 */
	function mvweb_core_markup_text( $text ) {
		return trim( html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES, 'UTF-8' ) );
	}
}

if ( ! function_exists( 'mvweb_core_markup_organization' ) ) {
	/**
	 * The node of the company, from the contacts of the chosen city.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed> Empty while the site has no name.
	 */
	function mvweb_core_markup_organization() {
		$name = mvweb_core_markup_text( get_bloginfo( 'name' ) );

		if ( '' === $name ) {
			return array();
		}

		$contacts = mvweb_core_contacts();
		$node     = array(
			'@type' => 'Organization',
			'@id'   => mvweb_core_markup_id( 'organization' ),
			'name'  => $name,
			'url'   => home_url( '/' ),
		);

		$logo = (int) get_theme_mod( 'custom_logo' );
		$logo = $logo ? wp_get_attachment_image_url( $logo, 'full' ) : '';

		if ( $logo ) {
			$node['logo'] = $logo;
		}

		$phones = array();

		foreach ( (array) $contacts['phones'] as $phone ) {
			if ( ! empty( $phone['number'] ) ) {
				$phones[] = array(
					'@type'       => 'ContactPoint',
					'telephone'   => (string) $phone['number'],
					'contactType' => 'customer service',
				);
			}
		}

		if ( ! empty( $phones ) ) {
			$node['telephone']    = $phones[0]['telephone'];
			$node['contactPoint'] = $phones;
		}

		if ( is_email( $contacts['email'] ) ) {
			$node['email'] = $contacts['email'];
		}

		$place = ! empty( $contacts['addresses'] ) ? $contacts['addresses'][0] : array();

		if ( ! empty( $place['address'] ) ) {
			$address = array(
				'@type'         => 'PostalAddress',
				'streetAddress' => (string) $place['address'],
			);
			$city    = ! empty( $place['city'] ) ? (string) $place['city'] : (string) $contacts['city'];

			if ( '' !== $city ) {
				$address['addressLocality'] = $city;
			}

			$node['address'] = $address;
		}

		$same = array();

		foreach ( mvweb_cz_profile_socials() as $social ) {
			$url = esc_url_raw( $social['url'] );

			if ( '' !== $url ) {
				$same[] = $url;
			}
		}

		if ( ! empty( $same ) ) {
			$node['sameAs'] = array_values( array_unique( $same ) );
		}

		return $node;
	}
}

if ( ! function_exists( 'mvweb_core_markup_website' ) ) {
	/**
	 * The node of the site, with its search.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string>|null $publisher Reference to the company, when the page has one.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_markup_website( $publisher ) {
		$node = array(
			'@type'           => 'WebSite',
			'@id'             => mvweb_core_markup_id( 'website' ),
			'url'             => home_url( '/' ),
			'name'            => mvweb_core_markup_text( get_bloginfo( 'name' ) ),
			'inLanguage'      => get_bloginfo( 'language' ),
			'potentialAction' => array(
				'@type'       => 'SearchAction',
				'target'      => array(
					'@type'       => 'EntryPoint',
					'urlTemplate' => home_url( '/?s={search_term_string}' ),
				),
				'query-input' => 'required name=search_term_string',
			),
		);

		if ( $publisher ) {
			$node['publisher'] = $publisher;
		}

		return $node;
	}
}

if ( ! function_exists( 'mvweb_core_markup_breadcrumbs' ) ) {
	/**
	 * The breadcrumb list, from the trail the page prints.
	 *
	 * @since 0.1.0
	 *
	 * @param string $url Address of the page.
	 *
	 * @return array<string,mixed> Empty when the trail is hidden or has one step.
	 */
	function mvweb_core_markup_breadcrumbs( $url ) {
		if ( ! mvweb_cz_get( 'mvweb_crumbs_enable' ) ) {
			return array();
		}

		$trail = mvweb_core_crumb_trail();
		$last  = count( $trail ) - 1;
		$items = array();

		foreach ( array_values( $trail ) as $index => $crumb ) {
			$name = mvweb_core_markup_text( isset( $crumb['label'] ) ? $crumb['label'] : '' );

			if ( '' === $name ) {
				continue;
			}

			$address = ! empty( $crumb['url'] ) ? (string) $crumb['url'] : ( $index === $last ? $url : '' );
			$item    = array(
				'@type'    => 'ListItem',
				'position' => count( $items ) + 1,
				'name'     => $name,
			);

			if ( '' !== $address ) {
				$item['item'] = $address;
			}

			$items[] = $item;
		}

		return count( $items ) < 2 ? array() : array(
			'@type'           => 'BreadcrumbList',
			'@id'             => $url . '#breadcrumb',
			'itemListElement' => $items,
		);
	}
}

if ( ! function_exists( 'mvweb_core_markup_page_name' ) ) {
	/**
	 * The name of the page: the last step of the trail, which is what the heading says.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_markup_page_name() {
		$trail = mvweb_core_crumb_trail();
		$last  = empty( $trail ) ? array() : end( $trail );
		$name  = mvweb_core_markup_text( isset( $last['label'] ) ? $last['label'] : '' );

		return '' !== $name ? $name : mvweb_core_markup_text( wp_get_document_title() );
	}
}

if ( ! function_exists( 'mvweb_core_markup_page' ) ) {
	/**
	 * The node of the page.
	 *
	 * @since 0.1.0
	 *
	 * @param string $url        Address of the page.
	 * @param bool   $breadcrumb Whether the page has a breadcrumb node to refer to.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_markup_page( $url, $breadcrumb ) {
		$listing = ! is_singular() && ! is_front_page();
		$node    = array(
			'@type'      => $listing ? 'CollectionPage' : 'WebPage',
			'@id'        => $url . '#webpage',
			'url'        => $url,
			'name'       => mvweb_core_markup_page_name(),
			'isPartOf'   => array( '@id' => mvweb_core_markup_id( 'website' ) ),
			'inLanguage' => get_bloginfo( 'language' ),
		);

		if ( is_singular() ) {
			$node['datePublished'] = get_the_date( 'c' );
			$node['dateModified']  = get_the_modified_date( 'c' );

			$image = get_the_post_thumbnail_url( get_the_ID(), 'full' );

			if ( $image ) {
				$node['primaryImageOfPage'] = array(
					'@type' => 'ImageObject',
					'url'   => $image,
				);
			}
		}

		if ( $breadcrumb ) {
			$node['breadcrumb'] = array( '@id' => $url . '#breadcrumb' );
		}

		return $node;
	}
}

if ( ! function_exists( 'mvweb_core_markup_author_shown' ) ) {
	/**
	 * Whether the post shows its author: under the title or in the block after the text.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_markup_author_shown() {
		$areas = mvweb_core_layouts();

		if ( ! isset( $areas['post-head'] ) && ! isset( $areas['post-after'] ) ) {
			return true;
		}

		return mvweb_core_layout_has( 'post-head', 'byline' )
			|| ( mvweb_core_layout_has( 'post-after', 'author' ) && (bool) get_theme_mod( 'mvweb_author_box', false ) );
	}
}

if ( ! function_exists( 'mvweb_core_markup_article' ) ) {
	/**
	 * The article and its author.
	 *
	 * @since 0.1.0
	 *
	 * @param string                    $url       Address of the page.
	 * @param array<string,string>|null $publisher Reference to the company, when the page has one.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_markup_article( $url, $publisher ) {
		$article = array(
			'@type'            => 'Article',
			'@id'              => $url . '#article',
			'headline'         => mvweb_core_markup_text( get_the_title() ),
			'mainEntityOfPage' => array( '@id' => $url . '#webpage' ),
			'datePublished'    => get_the_date( 'c' ),
			'dateModified'     => get_the_modified_date( 'c' ),
			'inLanguage'       => get_bloginfo( 'language' ),
		);
		$nodes   = array();

		$image = get_the_post_thumbnail_url( get_the_ID(), 'full' );

		if ( $image ) {
			$article['image'] = array( $image );
		}

		if ( $publisher ) {
			$article['publisher'] = $publisher;
		}

		$author = (int) get_post_field( 'post_author', get_the_ID() );
		$name   = mvweb_core_markup_text( get_the_author_meta( 'display_name', $author ) );

		if ( $author && '' !== $name && mvweb_core_markup_author_shown() ) {
			$link = get_author_posts_url( $author );

			$nodes[]           = array(
				'@type' => 'Person',
				'@id'   => $link . '#person',
				'name'  => $name,
				'url'   => $link,
			);
			$article['author'] = array( '@id' => $link . '#person' );
		}

		array_unshift( $nodes, $article );

		return $nodes;
	}
}

if ( ! function_exists( 'mvweb_core_markup_catalog' ) ) {
	/**
	 * The Product or Service node that inc/schema.php builds for the page.
	 *
	 * @since 0.1.0
	 *
	 * @param bool $company Whether the page has a company node to refer to.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_markup_catalog( $company ) {
		$node = mvweb_core_schema_node();

		if ( empty( $node ) ) {
			return array();
		}

		unset( $node['@context'] );

		if ( $company && isset( $node['provider'] ) ) {
			$node['provider'] = array( '@id' => mvweb_core_markup_id( 'organization' ) );
		}

		return $node;
	}
}

if ( ! function_exists( 'mvweb_core_markup_graph' ) ) {
	/**
	 * The nodes of the page.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_markup_graph() {
		if ( ! mvweb_core_markup_allowed() ) {
			return array();
		}

		$graph   = array();
		$owned   = mvweb_core_markup_company_owned();
		$company = array();
		$refer   = null;
		$url     = mvweb_core_markup_url();

		if ( mvweb_core_markup_on( 'org' ) && ! $owned ) {
			$company = mvweb_core_markup_organization();
		}

		if ( ! empty( $company ) || $owned ) {
			$refer = array( '@id' => mvweb_core_markup_id( 'organization' ) );
		}

		if ( mvweb_core_markup_on( 'site' ) ) {
			$crumbs = mvweb_core_markup_breadcrumbs( $url );

			$graph[] = mvweb_core_markup_website( $refer );
			$graph[] = mvweb_core_markup_page( $url, ! empty( $crumbs ) );

			if ( ! empty( $crumbs ) ) {
				$graph[] = $crumbs;
			}

			if ( is_singular( 'post' ) ) {
				$graph = array_merge( $graph, mvweb_core_markup_article( $url, $refer ) );
			}
		}

		if ( ! empty( $company ) ) {
			$graph[] = $company;
		}

		if ( mvweb_core_markup_on( 'catalog' ) ) {
			$catalog = mvweb_core_markup_catalog( null !== $refer );

			if ( ! empty( $catalog ) ) {
				$graph[] = $catalog;
			}
		}

		/**
		 * Filter the nodes of the page.
		 *
		 * @since 0.1.0
		 *
		 * @param array<int,array<string,mixed>> $graph Nodes.
		 * @param string                         $url   Address of the page.
		 */
		return array_values( (array) apply_filters( 'mvweb_core_markup_graph', $graph, $url ) );
	}
}

if ( ! function_exists( 'mvweb_core_markup_print' ) ) {
	/**
	 * Print the graph in the head.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_markup_print() {
		$graph = mvweb_core_markup_graph();

		if ( empty( $graph ) ) {
			return;
		}

		$json = wp_json_encode(
			array(
				'@context' => 'https://schema.org',
				'@graph'   => $graph,
			),
			JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP
		);

		if ( ! $json ) {
			return;
		}

		printf( '<script type="application/ld+json">%s</script>' . "\n", $json ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_json_encode() escapes the slashes that could close the block.
	}
}
add_action( 'wp_head', 'mvweb_core_markup_print', 20 );

if ( ! function_exists( 'mvweb_core_markup_take_over' ) ) {
	/**
	 * Take the printing of the Product and Service nodes from schema.php.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_markup_take_over() {
		remove_action( 'wp_head', 'mvweb_core_print_schema', 20 );
	}
}
add_action( 'wp', 'mvweb_core_markup_take_over' );

if ( ! function_exists( 'mvweb_core_markup_quiet_woocommerce' ) ) {
	/**
	 * Keep WooCommerce from printing the site and the trail a second time.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $markup Node WooCommerce is about to print.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_markup_quiet_woocommerce( $markup ) {
		return mvweb_core_markup_on( 'site' ) ? array() : $markup;
	}
}
add_filter( 'woocommerce_structured_data_website', 'mvweb_core_markup_quiet_woocommerce' );
add_filter( 'woocommerce_structured_data_breadcrumblist', 'mvweb_core_markup_quiet_woocommerce' );
