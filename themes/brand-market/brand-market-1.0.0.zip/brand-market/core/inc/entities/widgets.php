<?php
/**
 * Sidebars and widgets.
 *
 * Five areas of widgets (catalogue, services, blog, portfolio, pages), the
 * widgets of the base and the look of the widgets WordPress ships. A widget
 * keeps its data and its form here; the markup is the template part of the
 * theme, and the column beside the content is the theme's wrapper. An area
 * without a widget prints nothing and the page takes the whole width.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_sidebar_areas' ) ) {
	/**
	 * Areas of widgets: key => name.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_sidebar_areas() {
		return array(
			'catalog'  => __( 'Catalogue', 'mvweb-core' ),
			'services' => __( 'Services', 'mvweb-core' ),
			'blog'     => __( 'Blog and posts', 'mvweb-core' ),
			'works'    => __( 'Portfolio', 'mvweb-core' ),
			'page'     => __( 'Pages', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_sidebar_id' ) ) {
	/**
	 * Id of the sidebar of an area.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area key.
	 *
	 * @return string
	 */
	function mvweb_core_sidebar_id( $area ) {
		return 'sidebar-' . sanitize_key( $area );
	}
}

if ( ! function_exists( 'mvweb_core_sidebar_area' ) ) {
	/**
	 * The area the current request belongs to.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty when the page has no column.
	 */
	function mvweb_core_sidebar_area() {
		$area = '';

		if ( mvweb_core_is_catalog() ) {
			$area = 'catalog';
		} elseif ( mvweb_core_is_services() ) {
			$area = 'services';
		} elseif ( function_exists( 'mvweb_core_is_works' ) && mvweb_core_is_works() ) {
			$area = 'works';
		} elseif ( is_home() || is_singular( 'post' ) || is_category() || is_tag() || is_author() || is_date() ) {
			$area = 'blog';
		} elseif ( is_page() && ! is_front_page() ) {
			$shop = function_exists( 'is_cart' ) && ( is_cart() || is_checkout() || is_account_page() );
			$area = $shop ? '' : 'page';
		}

		/**
		 * Filter the area of widgets of the current request.
		 *
		 * @since 0.1.0
		 *
		 * @param string $area Area key, empty for none.
		 */
		$area = (string) apply_filters( 'mvweb_core_sidebar_area', $area );

		return array_key_exists( $area, mvweb_core_sidebar_areas() ) ? $area : '';
	}
}

if ( ! function_exists( 'mvweb_core_sidebar_active' ) ) {
	/**
	 * Whether the current request has a column with widgets.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_sidebar_active() {
		$area = mvweb_core_sidebar_area();

		return '' !== $area && 'none' !== mvweb_core_sidebar_side( $area ) && is_active_sidebar( mvweb_core_sidebar_id( $area ) );
	}
}

if ( ! function_exists( 'mvweb_core_sidebar_side' ) ) {
	/**
	 * Side of the column of an area.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area key.
	 *
	 * @return string One of start (left), end (right), none (no column).
	 */
	function mvweb_core_sidebar_side( $area ) {
		$side = get_theme_mod( 'mvweb_sidebar_side_' . $area, 'catalog' === $area ? 'start' : 'end' );

		return in_array( $side, array( 'start', 'none' ), true ) ? $side : 'end';
	}
}

if ( ! function_exists( 'mvweb_core_widget_class' ) ) {
	/**
	 * A class the widgets print, by role; the theme gives the roles its own names.
	 *
	 * @since 0.1.0
	 *
	 * @param string $role One of widget, title, count, chip, list, name, filter, help.
	 *
	 * @return string Classes separated by a space.
	 */
	function mvweb_core_widget_class( $role ) {
		/**
		 * Filter the classes of the widgets by role.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $classes Role => classes.
		 */
		$classes = (array) apply_filters(
			'mvweb_core_widget_classes',
			array(
				'widget' => 'mvweb-core-widget',
				'title'  => 'mvweb-core-widget__title',
				'count'  => 'mvweb-core-widget__count',
				'chip'   => 'mvweb-core-widget__chip',
				'list'   => 'mvweb-core-widget__list',
				'name'   => 'mvweb-core-widget__name',
				'filter' => 'mvweb-core-widget--filter',
				'help'   => 'mvweb-core-widget--help',
			)
		);

		return isset( $classes[ $role ] ) ? (string) $classes[ $role ] : '';
	}
}

if ( ! function_exists( 'mvweb_core_register_sidebars' ) ) {
	/**
	 * Register an area of widgets for every part of the site.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_sidebars() {
		foreach ( mvweb_core_sidebar_areas() as $area => $name ) {
			/**
			 * Filter the markup a widget of an area is printed in.
			 *
			 * @since 0.1.0
			 *
			 * @param array<string,string> $args Arguments of register_sidebar().
			 * @param string               $area Area key.
			 */
			$args = (array) apply_filters(
				'mvweb_core_sidebar_args',
				array(
					'name'          => sprintf(
						/* translators: %s: name of the part of the site. */
						__( 'Sidebar: %s', 'mvweb-core' ),
						$name
					),
					'id'            => mvweb_core_sidebar_id( $area ),
					'description'   => __( 'The column beside the content. With no widget here the page takes the whole width.', 'mvweb-core' ),
					'before_widget' => '<section id="%1$s" class="' . esc_attr( mvweb_core_widget_class( 'widget' ) ) . ' %2$s">',
					'after_widget'  => '</section>',
					'before_title'  => '<div class="' . esc_attr( mvweb_core_widget_class( 'title' ) ) . '">',
					'after_title'   => '</div>',
				),
				$area
			);

			register_sidebar( $args );
		}
	}
}
add_action( 'widgets_init', 'mvweb_core_register_sidebars' );

if ( ! function_exists( 'mvweb_core_widget_number' ) ) {
	/**
	 * A numeric field of a widget.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $default_value Default.
	 * @param int    $min           Smallest.
	 * @param int    $max           Largest.
	 * @param string $label         Label of the field.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_widget_number( $default_value, $min, $max, $label ) {
		return array(
			'type'    => 'number',
			'label'   => $label,
			'default' => $default_value,
			'min'     => $min,
			'max'     => $max,
		);
	}
}

if ( ! function_exists( 'mvweb_core_widget_kinds' ) ) {
	/**
	 * Kinds of the widgets of the base.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_widget_kinds() {
		$kinds = array(
			'items'        => array(
				'name'        => __( 'MVweb: Catalogue items', 'mvweb-core' ),
				'description' => __( 'The latest, the featured or the items of the current category, with a picture and a price.', 'mvweb-core' ),
				'template'    => 'posts',
				'data'        => 'mvweb_core_widget_items',
				'ordered'     => true,
				'fields'      => array(
					'number' => mvweb_core_widget_number( 3, 1, 12, __( 'How many:', 'mvweb-core' ) ),
					'source' => array(
						'type'    => 'select',
						'label'   => __( 'Which items:', 'mvweb-core' ),
						'default' => 'recent',
						'choices' => array(
							'recent'   => __( 'The latest', 'mvweb-core' ),
							'featured' => __( 'The featured', 'mvweb-core' ),
							'category' => __( 'Of the current category', 'mvweb-core' ),
						),
					),
				),
				'parts'       => array(
					'image' => __( 'Picture', 'mvweb-core' ),
					'title' => array(
						'label'  => __( 'Entry name', 'mvweb-core' ),
						'locked' => true,
					),
					'price' => __( 'Price', 'mvweb-core' ),
				),
			),
			'item_cats'    => array(
				'name'        => __( 'MVweb: Catalogue categories', 'mvweb-core' ),
				'description' => __( 'The tree of the categories with the number of items.', 'mvweb-core' ),
				'template'    => 'tree',
				'data'        => 'mvweb_core_widget_item_cats',
				'fields'      => array(
					'hide_empty'  => array(
						'type'    => 'checkbox',
						'label'   => __( 'Hide empty categories', 'mvweb-core' ),
						'default' => true,
					),
					'only_branch' => array(
						'type'    => 'checkbox',
						'label'   => __( 'Open only the branch of the current category', 'mvweb-core' ),
						'default' => false,
					),
				),
				'parts'       => array(
					'name'  => array(
						'label'  => __( 'Entry name', 'mvweb-core' ),
						'locked' => true,
					),
					'count' => __( 'Number of items', 'mvweb-core' ),
				),
			),
			'filter'       => array(
				'name'        => __( 'MVweb: Catalogue filter', 'mvweb-core' ),
				'description' => __( 'Price, sections, brand, properties and availability. Printed on the pages of the catalogue only.', 'mvweb-core' ),
				'classname'   => mvweb_core_widget_class( 'filter' ),
				'template'    => 'filter',
				'data'        => 'mvweb_core_widget_filter',
				'ordered'     => true,
				'parts'       => array(
					'price'      => __( 'Price', 'mvweb-core' ),
					'subcats'    => __( 'Sections', 'mvweb-core' ),
					'brand'      => __( 'Brand', 'mvweb-core' ),
					'properties' => __( 'Properties', 'mvweb-core' ),
					'stock'      => __( 'Availability', 'mvweb-core' ),
				),
			),
			'service_cats' => array(
				'name'        => __( 'MVweb: Service sections', 'mvweb-core' ),
				'description' => __( 'The sections of the services with an icon and the number of services.', 'mvweb-core' ),
				'template'    => 'list',
				'data'        => 'mvweb_core_widget_service_cats',
				'parts'       => array(
					'icon'  => __( 'Icon', 'mvweb-core' ),
					'name'  => array(
						'label'  => __( 'Entry name', 'mvweb-core' ),
						'locked' => true,
					),
					'count' => __( 'Number of services', 'mvweb-core' ),
				),
			),
			'services'     => array(
				'name'        => __( 'MVweb: Services', 'mvweb-core' ),
				'description' => __( 'A few services with their prices.', 'mvweb-core' ),
				'template'    => 'list',
				'data'        => 'mvweb_core_widget_services',
				'fields'      => array(
					'number' => mvweb_core_widget_number( 4, 1, 20, __( 'How many:', 'mvweb-core' ) ),
					'source' => array(
						'type'    => 'select',
						'label'   => __( 'Which services:', 'mvweb-core' ),
						'default' => 'all',
						'choices' => array(
							'all'     => __( 'All', 'mvweb-core' ),
							'section' => __( 'Of the current section', 'mvweb-core' ),
						),
					),
				),
				'parts'       => array(
					'name'  => array(
						'label'  => __( 'Entry name', 'mvweb-core' ),
						'locked' => true,
					),
					'price' => __( 'Price', 'mvweb-core' ),
				),
			),
			'works'        => array(
				'name'        => __( 'MVweb: Portfolio works', 'mvweb-core' ),
				'description' => __( 'Pictures of the latest works, or of the same kind as the current one.', 'mvweb-core' ),
				'template'    => 'works',
				'data'        => 'mvweb_core_widget_works',
				'fields'      => array(
					'number' => mvweb_core_widget_number( 4, 1, 12, __( 'How many:', 'mvweb-core' ) ),
					'source' => array(
						'type'    => 'select',
						'label'   => __( 'Which works:', 'mvweb-core' ),
						'default' => 'recent',
						'choices' => array(
							'recent' => __( 'The latest', 'mvweb-core' ),
							'kind'   => __( 'Of the current kind', 'mvweb-core' ),
						),
					),
				),
				'parts'       => array(
					'image' => array(
						'label'  => __( 'Picture', 'mvweb-core' ),
						'locked' => true,
					),
					'title' => __( 'Entry name', 'mvweb-core' ),
				),
			),
			'request'      => array(
				'name'           => __( 'MVweb: Request form', 'mvweb-core' ),
				'description'    => __( 'The request form of the services, the form of the request window or a shortcode of your own. An empty title takes the heading of the form of the services.', 'mvweb-core' ),
				'title_fallback' => 'mvweb_core_widget_request_title',
				'template'       => 'request',
				'data'           => 'mvweb_core_widget_request',
				'fields'         => array(
					'form'      => array(
						'type'    => 'select',
						'label'   => __( 'Form:', 'mvweb-core' ),
						'default' => 'service',
						'choices' => array(
							'service'   => __( 'Form of the services', 'mvweb-core' ),
							'popup'     => __( 'Form of the request window', 'mvweb-core' ),
							'shortcode' => __( 'Shortcode of my own', 'mvweb-core' ),
						),
					),
					'shortcode' => array(
						'type'    => 'text',
						'label'   => __( 'Shortcode of my own:', 'mvweb-core' ),
						'default' => '',
					),
				),
				'parts'          => array(
					'form' => array(
						'label'  => __( 'Form', 'mvweb-core' ),
						'locked' => true,
					),
					'note' => __( 'Note under the form', 'mvweb-core' ),
				),
			),
			'posts'        => array(
				'name'        => __( 'MVweb: Recent posts', 'mvweb-core' ),
				'description' => __( 'The latest or the most discussed posts with a picture and a date.', 'mvweb-core' ),
				'template'    => 'posts',
				'data'        => 'mvweb_core_widget_posts',
				'ordered'     => true,
				'fields'      => array(
					'number' => mvweb_core_widget_number( 3, 1, 10, __( 'How many:', 'mvweb-core' ) ),
					'source' => array(
						'type'    => 'select',
						'label'   => __( 'Which posts:', 'mvweb-core' ),
						'default' => 'recent',
						'choices' => array(
							'recent'    => __( 'The latest', 'mvweb-core' ),
							'commented' => __( 'The most discussed', 'mvweb-core' ),
						),
					),
				),
				'parts'       => array(
					'image' => __( 'Picture', 'mvweb-core' ),
					'title' => array(
						'label'  => __( 'Title', 'mvweb-core' ),
						'locked' => true,
					),
					'date'  => __( 'Date', 'mvweb-core' ),
				),
			),
			'contacts'     => array(
				'name'        => __( 'MVweb: Contacts', 'mvweb-core' ),
				'description' => __( 'The phone, the hours, the e-mail, the address and the messengers of the site.', 'mvweb-core' ),
				'template'    => 'contacts',
				'data'        => 'mvweb_core_widget_contacts',
				'ordered'     => true,
				'fields'      => array(
					'look' => array(
						'type'    => 'select',
						'label'   => __( 'Look:', 'mvweb-core' ),
						'default' => 'dark',
						'choices' => array(
							'dark'   => __( 'Dark card', 'mvweb-core' ),
							'light'  => __( 'Light card', 'mvweb-core' ),
							'accent' => __( 'Card in the accent colour', 'mvweb-core' ),
						),
					),
				),
				'parts'       => array(
					'phone'      => __( 'Phone', 'mvweb-core' ),
					'hours'      => __( 'Opening hours', 'mvweb-core' ),
					'email'      => __( 'E-mail', 'mvweb-core' ),
					'address'    => array(
						'label' => __( 'Address', 'mvweb-core' ),
						'off'   => true,
					),
					'messengers' => array(
						'label' => __( 'Messengers', 'mvweb-core' ),
						'off'   => true,
					),
				),
			),
			'help'         => array(
				'name'        => __( 'MVweb: Help block', 'mvweb-core' ),
				'description' => __( 'A heading, a line of text and a button to the request.', 'mvweb-core' ),
				'classname'   => mvweb_core_widget_class( 'help' ),
				'template'    => 'help',
				'data'        => 'mvweb_core_widget_help',
				'ordered'     => true,
				'fields'      => array(
					'text'        => array(
						'type'    => 'textarea',
						'label'   => __( 'Text:', 'mvweb-core' ),
						'default' => '',
					),
					'button_text' => array(
						'type'    => 'text',
						'label'   => __( 'Button:', 'mvweb-core' ),
						'default' => __( 'Write to us', 'mvweb-core' ),
					),
					'button_url'  => array(
						'type'    => 'url',
						'label'   => __( 'Button link:', 'mvweb-core' ),
						'hint'    => __( 'Empty takes the link of the request button of the site.', 'mvweb-core' ),
						'default' => '',
					),
				),
				'parts'       => array(
					'text'   => __( 'Text', 'mvweb-core' ),
					'button' => __( 'Button', 'mvweb-core' ),
				),
			),
		);

		/**
		 * Filter the kinds of widgets of the base.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,array<string,mixed>> $kinds Kinds by key.
		 */
		return (array) apply_filters( 'mvweb_core_widget_kinds', $kinds );
	}
}

if ( ! function_exists( 'mvweb_core_register_widgets' ) ) {
	/**
	 * Register the widgets of the base.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_widgets() {
		foreach ( mvweb_core_widget_kinds() as $key => $kind ) {
			register_widget( new MVweb_Core_Widget( $key, $kind ) );
		}
	}
}
add_action( 'widgets_init', 'mvweb_core_register_widgets' );

if ( ! function_exists( 'mvweb_core_widget_term_url' ) ) {
	/**
	 * Address of a term, empty when it has none.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Term.
	 *
	 * @return string
	 */
	function mvweb_core_widget_term_url( $term ) {
		$url = get_term_link( $term );

		return is_string( $url ) ? $url : '';
	}
}

if ( ! function_exists( 'mvweb_core_widget_rows' ) ) {
	/**
	 * Rows of a list of items for the template: address, name, picture, price, date.
	 *
	 * @since 0.1.0
	 *
	 * @param int[]    $ids   Post ids.
	 * @param string[] $parts Parts the widget prints.
	 * @param string   $kind  Either item or post.
	 *
	 * @return array<int,array<string,string>>
	 */
	function mvweb_core_widget_rows( array $ids, array $parts, $kind ) {
		$rows = array();

		foreach ( $ids as $id ) {
			$row = array(
				'url'   => (string) get_permalink( $id ),
				'title' => get_the_title( $id ),
				'image' => '',
				'price' => '',
				'date'  => '',
				'time'  => '',
			);

			if ( in_array( 'image', $parts, true ) ) {
				if ( 'item' === $kind ) {
					$row['image'] = mvweb_core_item_image(
						$id,
						'thumbnail',
						array(
							'loading'  => 'lazy',
							'decoding' => 'async',
						)
					);
				} elseif ( has_post_thumbnail( $id ) ) {
					$row['image'] = (string) get_the_post_thumbnail(
						$id,
						'thumbnail',
						array(
							'loading'  => 'lazy',
							'decoding' => 'async',
						)
					);
				}
			}

			if ( in_array( 'price', $parts, true ) ) {
				$row['price'] = mvweb_core_item_price_html( $id );
			}

			if ( in_array( 'date', $parts, true ) ) {
				$row['date'] = get_the_date( '', $id );
				$row['time'] = get_the_date( 'c', $id );
			}

			$rows[] = $row;
		}

		return $rows;
	}
}

if ( ! function_exists( 'mvweb_core_widget_items' ) ) {
	/**
	 * Data of the widget of catalogue items.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $instance Saved values.
	 * @param string[]            $parts    Parts in print order.
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_widget_items( array $instance, array $parts ) {
		$count = absint( $instance['number'] );
		$term  = get_queried_object();

		if ( 'category' === $instance['source'] && $term instanceof WP_Term && mvweb_core_is_catalog() ) {
			$ids = get_posts(
				array(
					'post_type'        => mvweb_core_post_type(),
					'post_status'      => 'publish',
					'numberposts'      => $count * 2,
					'fields'           => 'ids',
					'suppress_filters' => false,
					'orderby'          => array(
						'menu_order' => 'ASC',
						'date'       => 'DESC',
					),
					'tax_query'        => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- One term, a handful of items.
						array(
							'taxonomy' => $term->taxonomy,
							'terms'    => $term->term_id,
						),
					),
				)
			);
		} else {
			$ids = mvweb_core_showcase_items( 'featured' === $instance['source'] ? 'featured' : 'recent', $count );
		}

		$ids = array_slice( array_values( array_filter( array_map( 'absint', $ids ), 'mvweb_core_item_visible' ) ), 0, $count );

		return empty( $ids ) ? null : array( 'rows' => mvweb_core_widget_rows( $ids, $parts, 'item' ) );
	}
}

if ( ! function_exists( 'mvweb_core_widget_item_cats' ) ) {
	/**
	 * Data of the widget of catalogue categories.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $instance Saved values.
	 * @param string[]            $parts    Parts in print order.
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_widget_item_cats( array $instance, array $parts ) {
		$taxonomy = mvweb_core_taxonomy();
		$current  = is_tax( $taxonomy ) ? (int) get_queried_object_id() : 0;
		$trail    = $current > 0 ? array_merge( array( $current ), get_ancestors( $current, $taxonomy, 'taxonomy' ) ) : array();
		$args     = array(
			'taxonomy'   => $taxonomy,
			'hide_empty' => ! empty( $instance['hide_empty'] ),
		);
		$top      = get_terms( $args + array( 'parent' => 0 ) );
		$rows     = array();

		if ( ! is_array( $top ) ) {
			return null;
		}

		foreach ( $top as $term ) {
			if ( 'uncategorized' === $term->slug && mvweb_core_is_woocommerce() ) {
				continue;
			}

			$children = array();
			$kids     = get_terms( $args + array( 'parent' => $term->term_id ) );

			foreach ( is_array( $kids ) ? $kids : array() as $kid ) {
				$children[] = array(
					'url'     => mvweb_core_widget_term_url( $kid ),
					'name'    => $kid->name,
					'count'   => in_array( 'count', $parts, true ) ? (int) $kid->count : null,
					'current' => $kid->term_id === $current,
				);
			}

			$count = (int) $term->count;

			if ( ! mvweb_core_is_woocommerce() ) {
				$count += array_sum( wp_list_pluck( $children, 'count' ) );
			}

			$rows[] = array(
				'url'      => mvweb_core_widget_term_url( $term ),
				'name'     => $term->name,
				'count'    => in_array( 'count', $parts, true ) ? $count : null,
				'current'  => $term->term_id === $current,
				'open'     => empty( $instance['only_branch'] ) || in_array( $term->term_id, $trail, true ),
				'children' => $children,
			);
		}

		return empty( $rows ) ? null : array( 'rows' => $rows );
	}
}

if ( ! function_exists( 'mvweb_core_widget_filter' ) ) {
	/**
	 * Data of the widget of the catalogue filter.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $instance Saved values.
	 * @param string[]            $parts    Parts in print order.
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_widget_filter( array $instance, array $parts ) {
		unset( $instance, $parts );

		return mvweb_core_is_catalog() ? array() : null;
	}
}

if ( ! function_exists( 'mvweb_core_widget_service_cats' ) ) {
	/**
	 * Data of the widget of the sections of the services.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $instance Saved values.
	 * @param string[]            $parts    Parts in print order.
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_widget_service_cats( array $instance, array $parts ) {
		unset( $instance );

		if ( ! function_exists( 'mvweb_core_service_child_terms' ) ) {
			return null;
		}

		$current = 0;

		if ( is_tax( 'mv_service_cat' ) ) {
			$current = (int) get_queried_object_id();
		} elseif ( is_singular( 'mv_service' ) && function_exists( 'mvweb_core_service_primary_term' ) ) {
			$term    = mvweb_core_service_primary_term( get_queried_object_id() );
			$current = $term ? $term->term_id : 0;
		}

		$trail = $current > 0 ? array_merge( array( $current ), get_ancestors( $current, 'mv_service_cat', 'taxonomy' ) ) : array();
		$rows  = array();

		foreach ( mvweb_core_service_child_terms( 0 ) as $term ) {
			$rows[] = array(
				'url'     => mvweb_core_widget_term_url( $term ),
				'name'    => $term->name,
				'icon'    => in_array( 'icon', $parts, true ) ? (string) get_term_meta( $term->term_id, 'mvweb_icon', true ) : '',
				'meta'    => in_array( 'count', $parts, true ) ? (string) mvweb_core_service_count( $term->term_id ) : '',
				'current' => in_array( $term->term_id, $trail, true ),
			);
		}

		return empty( $rows ) ? null : array(
			'rows'  => $rows,
			'icons' => in_array( 'icon', $parts, true ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_widget_services' ) ) {
	/**
	 * Data of the widget of services.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $instance Saved values.
	 * @param string[]            $parts    Parts in print order.
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_widget_services( array $instance, array $parts ) {
		$count   = absint( $instance['number'] );
		$exclude = is_singular( 'mv_service' ) ? (int) get_queried_object_id() : 0;
		$term    = 0;

		if ( 'section' === $instance['source'] ) {
			if ( is_tax( 'mv_service_cat' ) ) {
				$term = (int) get_queried_object_id();
			} elseif ( $exclude > 0 && function_exists( 'mvweb_core_service_primary_term' ) ) {
				$primary = mvweb_core_service_primary_term( $exclude );
				$term    = $primary ? $primary->term_id : 0;
			}
		}

		$args = array(
			'post_type'      => 'mv_service',
			'post_status'    => 'publish',
			'posts_per_page' => $count,
			'fields'         => 'ids',
			'no_found_rows'  => true,
			'post__not_in'   => $exclude > 0 ? array( $exclude ) : array(),
			'orderby'        => array(
				'menu_order' => 'ASC',
				'date'       => 'DESC',
			),
		);

		if ( $term > 0 ) {
			$args['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- One section, a handful of services.
				array(
					'taxonomy' => 'mv_service_cat',
					'terms'    => $term,
				),
			);
		}

		$rows = array();

		foreach ( array_map( 'absint', get_posts( $args ) ) as $id ) {
			$rows[] = array(
				'url'  => (string) get_permalink( $id ),
				'name' => get_the_title( $id ),
				'meta' => in_array( 'price', $parts, true ) && function_exists( 'mvweb_core_service_price' ) ? mvweb_core_service_price( $id ) : '',
				'html' => true,
			);
		}

		return empty( $rows ) ? null : array(
			'rows'  => $rows,
			'icons' => false,
		);
	}
}

if ( ! function_exists( 'mvweb_core_widget_works' ) ) {
	/**
	 * Data of the widget of works.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $instance Saved values.
	 * @param string[]            $parts    Parts in print order.
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_widget_works( array $instance, array $parts ) {
		if ( ! function_exists( 'mvweb_core_works' ) ) {
			return null;
		}

		$args = array( 'count' => absint( $instance['number'] ) );

		if ( is_singular( 'mv_work' ) ) {
			$args['exclude'] = (int) get_queried_object_id();
		}

		if ( 'kind' === $instance['source'] ) {
			if ( is_tax( 'mv_work_type' ) ) {
				$args['type'] = (int) get_queried_object_id();
			} elseif ( is_singular( 'mv_work' ) ) {
				$kinds = get_the_terms( get_queried_object_id(), 'mv_work_type' );

				if ( is_array( $kinds ) && ! empty( $kinds ) ) {
					$args['type'] = (int) reset( $kinds )->term_id;
				}
			}
		}

		$rows = array();

		foreach ( mvweb_core_works( $args ) as $id ) {
			$rows[] = array(
				'url'   => (string) get_permalink( $id ),
				'title' => in_array( 'title', $parts, true ) ? get_the_title( $id ) : '',
				'label' => get_the_title( $id ),
				'image' => mvweb_core_item_image(
					$id,
					'medium',
					array(
						'loading'  => 'lazy',
						'decoding' => 'async',
					)
				),
			);
		}

		return empty( $rows ) ? null : array( 'rows' => $rows );
	}
}

if ( ! function_exists( 'mvweb_core_widget_request' ) ) {
	/**
	 * Data of the widget of the request form.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $instance Saved values.
	 * @param string[]            $parts    Parts in print order.
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_widget_request( array $instance, array $parts ) {
		if ( 'shortcode' === $instance['form'] ) {
			$form = trim( (string) $instance['shortcode'] );
		} elseif ( 'popup' === $instance['form'] ) {
			$form = function_exists( 'mvweb_core_popup_form' ) ? trim( (string) mvweb_core_popup_form() ) : '';
		} else {
			$form = trim( (string) mvweb_core_option( 'mvweb_service_form' ) );
		}

		return array(
			'form'     => $form,
			'cta_text' => (string) get_theme_mod( 'mvweb_cta_text', __( 'Request a quote', 'mvweb-core' ) ),
			'cta_url'  => (string) get_theme_mod( 'mvweb_cta_url', '' ),
			'note'     => in_array( 'note', $parts, true ) ? trim( (string) mvweb_core_option( 'mvweb_service_form_note' ) ) : '',
		);
	}
}

if ( ! function_exists( 'mvweb_core_widget_request_title' ) ) {
	/**
	 * The heading of the request form when the widget has none of its own.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_widget_request_title() {
		return trim( (string) mvweb_core_option( 'mvweb_service_form_title' ) );
	}
}

if ( ! function_exists( 'mvweb_core_widget_posts' ) ) {
	/**
	 * Data of the widget of posts.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $instance Saved values.
	 * @param string[]            $parts    Parts in print order.
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_widget_posts( array $instance, array $parts ) {
		$ids = get_posts(
			array(
				'post_type'           => 'post',
				'post_status'         => 'publish',
				'numberposts'         => absint( $instance['number'] ),
				'fields'              => 'ids',
				'ignore_sticky_posts' => true,
				'post__not_in'        => is_singular( 'post' ) ? array( (int) get_queried_object_id() ) : array(),
				'orderby'             => 'commented' === $instance['source'] ? 'comment_count' : 'date',
				'order'               => 'DESC',
			)
		);

		return empty( $ids ) ? null : array( 'rows' => mvweb_core_widget_rows( array_map( 'absint', $ids ), $parts, 'post' ) );
	}
}

if ( ! function_exists( 'mvweb_core_widget_contacts' ) ) {
	/**
	 * Data of the widget of contacts.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $instance Saved values.
	 * @param string[]            $parts    Parts in print order.
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_widget_contacts( array $instance, array $parts ) {
		unset( $instance );

		$contacts = mvweb_core_contacts();
		$hours    = array();
		$address  = array();

		foreach ( (array) $contacts['hours'] as $row ) {
			$hours[] = trim( $row['days'] . ' ' . $row['time'] );
		}

		foreach ( (array) $contacts['addresses'] as $place ) {
			$address[] = trim( (string) $place['address'] );
		}

		return array(
			'phones'     => in_array( 'phone', $parts, true ) ? (array) $contacts['phones'] : array(),
			'hours'      => in_array( 'hours', $parts, true ) ? implode( ', ', array_filter( $hours ) ) : '',
			'email'      => in_array( 'email', $parts, true ) ? (string) $contacts['email'] : '',
			'address'    => in_array( 'address', $parts, true ) ? implode( '; ', array_filter( $address ) ) : '',
			'messengers' => in_array( 'messengers', $parts, true ) ? mvweb_core_header_messengers() : array(),
		);
	}
}

if ( ! function_exists( 'mvweb_core_widget_help' ) ) {
	/**
	 * Data of the help block.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $instance Saved values.
	 * @param string[]            $parts    Parts in print order.
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_widget_help( array $instance, array $parts ) {
		$url = '' !== trim( (string) $instance['button_url'] ) ? $instance['button_url'] : (string) get_theme_mod( 'mvweb_cta_url', '' );

		return array(
			'text'        => in_array( 'text', $parts, true ) ? trim( (string) $instance['text'] ) : '',
			'button_text' => in_array( 'button', $parts, true ) ? trim( (string) $instance['button_text'] ) : '',
			'button_url'  => $url,
		);
	}
}

if ( ! function_exists( 'mvweb_core_widgets_tree' ) ) {
	/**
	 * The section of the columns stays in the tree of the inner pages.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_widgets_tree( $tree ) {
		if ( isset( $tree['mvweb_cz_inner'] ) ) {
			$tree['mvweb_cz_inner']['sections']['mvweb_cz_inner_sidebar'] = __( 'Sidebars', 'mvweb-core' );
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_widgets_tree', 100 );

if ( ! function_exists( 'mvweb_core_widgets_fields' ) ) {
	/**
	 * Settings of the columns: which side each one stands on.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_widgets_fields() {
		$fields = array();

		foreach ( mvweb_core_sidebar_areas() as $area => $name ) {
			$fields[] = array(
				'type'        => 'radio',
				'settings'    => 'mvweb_sidebar_side_' . $area,
				'section'     => 'catalog' === $area ? 'mvweb_cz_catalog_archive' : 'mvweb_cz_inner_sidebar',
				'label'       => sprintf(
					/* translators: %s: name of the part of the site. */
					__( 'Column: %s', 'mvweb-core' ),
					$name
				),
				'description' => 'catalog' === $area ? __( 'The widgets are placed in Appearance - Widgets. A column with no widget is not printed and the page takes the whole width.', 'mvweb-core' ) : '',
				'default'     => 'catalog' === $area ? 'start' : 'end',
				'choices'     => array(
					'start' => __( 'On the left', 'mvweb-core' ),
					'end'   => __( 'On the right', 'mvweb-core' ),
					'none'  => __( 'Do not show', 'mvweb-core' ),
				),
			);
		}

		return $fields;
	}
}

if ( ! function_exists( 'mvweb_core_widgets_register_fields' ) ) {
	/**
	 * Hand the settings of the columns to the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_widgets_register_fields( $kit ) {
		$kit->add_fields( mvweb_core_widgets_fields() );
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_widgets_register_fields' );

if ( ! function_exists( 'mvweb_core_widgets_style_map' ) ) {
	/**
	 * The sheet of the widgets is loaded where the page has a column.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Handles without the theme prefix.
	 *
	 * @return string[]
	 */
	function mvweb_core_widgets_style_map( $styles ) {
		if ( mvweb_core_sidebar_active() ) {
			$styles[] = 'widgets';
		}

		return $styles;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_core_widgets_style_map', 20 );

if ( ! function_exists( 'mvweb_core_widgets_admin_assets' ) ) {
	/**
	 * The buttons that move the parts of a widget, on the widgets screen and in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @param string $hook Screen being loaded, empty in the Customizer.
	 *
	 * @return void
	 */
	function mvweb_core_widgets_admin_assets( $hook = '' ) {
		if ( '' !== $hook && 'widgets.php' !== $hook ) {
			return;
		}

		$script = mvweb_core_asset_path( '/assets/js/widgets-admin.js' );

		wp_enqueue_script( 'mvweb-core-widgets-admin', MVWEB_CORE_URI . $script, array(), mvweb_core_asset_version( $script ), true );

		wp_register_style( 'mvweb-core-widgets-admin', false, array(), MVWEB_CORE_VERSION );
		wp_add_inline_style(
			'mvweb-core-widgets-admin',
			'.mvweb-widget-parts{margin:0 0 1em;padding:.5em .75em;border:1px solid #c3c4c7;background:#fff}.mvweb-widget-parts legend{padding:0 .25em;font-weight:600}.mvweb-widget-parts__list{margin:0}.mvweb-widget-parts__item{display:flex;align-items:center;justify-content:space-between;gap:.5em;margin:0;padding:.25em 0}.mvweb-widget-parts__item+.mvweb-widget-parts__item{border-top:1px solid #f0f0f1}.mvweb-widget-parts__move{display:flex;gap:.25em}.mvweb-widget-parts__move .button-link{line-height:1;text-decoration:none}'
		);
		wp_enqueue_style( 'mvweb-core-widgets-admin' );
	}
}
add_action( 'admin_enqueue_scripts', 'mvweb_core_widgets_admin_assets' );
add_action( 'customize_controls_enqueue_scripts', 'mvweb_core_widgets_admin_assets' );

if ( ! function_exists( 'mvweb_core_in_sidebar' ) ) {
	/**
	 * Whether a sidebar is being printed right now.
	 *
	 * @since 0.1.0
	 *
	 * @param bool|null $set New state, null only reads.
	 *
	 * @return bool
	 */
	function mvweb_core_in_sidebar( $set = null ) {
		static $inside = 0;

		if ( true === $set ) {
			++$inside;
		} elseif ( false === $set ) {
			$inside = max( 0, $inside - 1 );
		}

		return $inside > 0;
	}
}
add_action(
	'dynamic_sidebar_before',
	static function () {
		mvweb_core_in_sidebar( true );
	}
);
add_action(
	'dynamic_sidebar_after',
	static function () {
		mvweb_core_in_sidebar( false );
	}
);

if ( ! function_exists( 'mvweb_core_widget_search_form' ) ) {
	/**
	 * The search form inside a column is the form of the widget.
	 *
	 * @since 0.1.0
	 *
	 * @param string $form Markup of the form.
	 *
	 * @return string
	 */
	function mvweb_core_widget_search_form( $form ) {
		if ( ! mvweb_core_in_sidebar() ) {
			return $form;
		}

		ob_start();
		get_template_part( 'template-parts/widgets/search' );
		$widget = trim( (string) ob_get_clean() );

		return '' === $widget ? $form : $widget;
	}
}
add_filter( 'get_search_form', 'mvweb_core_widget_search_form', 20 );

if ( ! function_exists( 'mvweb_core_widget_categories_count' ) ) {
	/**
	 * The number of posts of a category stands in a span of its own.
	 *
	 * @since 0.1.0
	 *
	 * @param string $output Markup of the list.
	 *
	 * @return string
	 */
	function mvweb_core_widget_categories_count( $output ) {
		if ( ! mvweb_core_in_sidebar() ) {
			return $output;
		}

		return (string) preg_replace( '~</a>\s*\(([^)]*)\)~u', '</a><span class="' . esc_attr( mvweb_core_widget_class( 'count' ) ) . '">$1</span>', (string) $output );
	}
}
add_filter( 'wp_list_categories', 'mvweb_core_widget_categories_count' );

if ( ! function_exists( 'mvweb_core_widget_archives_link' ) ) {
	/**
	 * A month of the archive widget: the name and the number of posts apart.
	 *
	 * @since 0.1.0
	 *
	 * @param string $link   Markup of the link.
	 * @param string $url    Address.
	 * @param string $text   Name of the month.
	 * @param string $format Format of the list.
	 * @param string $before Markup before the link.
	 * @param string $after  Markup after the link.
	 *
	 * @return string
	 */
	function mvweb_core_widget_archives_link( $link, $url, $text, $format, $before, $after ) {
		if ( ! mvweb_core_in_sidebar() || 'html' !== $format ) {
			return $link;
		}

		$count = 1 === preg_match( '~\(([^)]*)\)~u', (string) $after, $found ) ? '<span class="' . esc_attr( mvweb_core_widget_class( 'count' ) ) . '">' . esc_html( $found[1] ) . '</span>' : '';

		return sprintf( "\t<li>%s<a href=\"%s\">%s</a>%s</li>\n", $before, esc_url( $url ), esc_html( wp_strip_all_tags( $text ) ), $count );
	}
}
add_filter( 'get_archives_link', 'mvweb_core_widget_archives_link', 10, 6 );

if ( ! function_exists( 'mvweb_core_widget_tag_cloud' ) ) {
	/**
	 * Tags of the cloud widget are chips of one size.
	 *
	 * @since 0.1.0
	 *
	 * @param string $cloud Markup of the cloud.
	 *
	 * @return string
	 */
	function mvweb_core_widget_tag_cloud( $cloud ) {
		if ( ! mvweb_core_in_sidebar() || ! is_string( $cloud ) ) {
			return $cloud;
		}

		return (string) preg_replace(
			array( '~\sstyle=([\'"]).*?\1~u', '~\sclass=([\'"])tag-cloud-link[^\'"]*\1~u' ),
			array( '', ' class="' . esc_attr( mvweb_core_widget_class( 'chip' ) ) . '"' ),
			$cloud
		);
	}
}
add_filter( 'wp_generate_tag_cloud', 'mvweb_core_widget_tag_cloud' );

if ( ! function_exists( 'mvweb_core_widget_menu_args' ) ) {
	/**
	 * The menu widget prints the list of the widgets.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $args Arguments of wp_nav_menu().
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_widget_menu_args( $args ) {
		return array_merge(
			(array) $args,
			array(
				'container'   => false,
				'menu_class'  => mvweb_core_widget_class( 'list' ),
				'link_before' => '<em class="' . esc_attr( mvweb_core_widget_class( 'name' ) ) . '">',
				'link_after'  => '</em>',
			)
		);
	}
}
add_filter( 'widget_nav_menu_args', 'mvweb_core_widget_menu_args' );

if ( ! function_exists( 'mvweb_core_service_icon_field' ) ) {
	/**
	 * The icon of a section of the services, in the form of the term.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term|string $term Term being edited; the taxonomy on the add form.
	 *
	 * @return void
	 */
	function mvweb_core_service_icon_field( $term = '' ) {
		$value = $term instanceof WP_Term ? (string) get_term_meta( $term->term_id, 'mvweb_icon', true ) : '';
		$wrap  = $term instanceof WP_Term;

		wp_nonce_field( 'mvweb_service_icon', 'mvweb_service_icon_nonce' );

		echo $wrap ? '<tr class="form-field"><th scope="row">' : '<div class="form-field">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
		echo '<label for="mvweb-service-icon">' . esc_html__( 'Icon', 'mvweb-core' ) . '</label>';
		echo $wrap ? '</th><td>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
		echo '<select name="mvweb_icon" id="mvweb-service-icon">';

		foreach ( mvweb_core_icon_choices() as $name => $label ) {
			printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $name ), selected( $value, $name, false ), esc_html( $label ) );
		}

		echo '</select>';
		echo '<p class="description">' . esc_html__( 'Printed before the name in the widget of the service sections.', 'mvweb-core' ) . '</p>';
		echo $wrap ? '</td></tr>' : '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
	}
}
add_action( 'mv_service_cat_add_form_fields', 'mvweb_core_service_icon_field' );
add_action( 'mv_service_cat_edit_form_fields', 'mvweb_core_service_icon_field' );

if ( ! function_exists( 'mvweb_core_service_icon_save' ) ) {
	/**
	 * Store the icon of a section of the services.
	 *
	 * @since 0.1.0
	 *
	 * @param int $term_id Term id.
	 *
	 * @return void
	 */
	function mvweb_core_service_icon_save( $term_id ) {
		if ( ! isset( $_POST['mvweb_service_icon_nonce'], $_POST['mvweb_icon'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mvweb_service_icon_nonce'] ) ), 'mvweb_service_icon' ) || ! current_user_can( 'manage_categories' ) ) {
			return;
		}

		$name = sanitize_key( wp_unslash( $_POST['mvweb_icon'] ) );

		if ( '' === $name || ! array_key_exists( $name, mvweb_core_icon_choices() ) ) {
			delete_term_meta( $term_id, 'mvweb_icon' );

			return;
		}

		update_term_meta( $term_id, 'mvweb_icon', $name );
	}
}
add_action( 'created_mv_service_cat', 'mvweb_core_service_icon_save' );
add_action( 'edited_mv_service_cat', 'mvweb_core_service_icon_save' );

if ( ! function_exists( 'mvweb_core_widgets_register_meta' ) ) {
	/**
	 * Register the icon of a section of the services.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_widgets_register_meta() {
		register_term_meta(
			'mv_service_cat',
			'mvweb_icon',
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => 'sanitize_key',
				'auth_callback'     => 'mvweb_core_term_meta_auth',
				'show_in_rest'      => false,
			)
		);
	}
}
add_action( 'init', 'mvweb_core_widgets_register_meta', 31 );
