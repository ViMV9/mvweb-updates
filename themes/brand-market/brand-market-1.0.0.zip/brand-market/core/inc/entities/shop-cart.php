<?php
/**
 * The cart, the checkout, the order received page and the side cart.
 *
 * What these pages print and a theme cannot decide alone lives here: the
 * settings of the Customizer, the choice between a panel and a counter on
 * adding to the cart, the fragments WooCommerce refreshes after every change
 * of the cart, the payment icons and the stylesheets and scripts the pages
 * ask for. The markup stays in the theme.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_cart_reasons_default' ) ) {
	/**
	 * The usual reasons a payment fails, as the rows of the list.
	 *
	 * @since 0.1.0
	 *
	 * @return string JSON of the rows.
	 */
	function mvweb_core_cart_reasons_default() {
		return wp_json_encode(
			array(
				array( 'text' => __( 'There is not enough money on the card or the limit is exceeded.', 'mvweb-core' ) ),
				array( 'text' => __( 'The bank declined the operation: check the confirmation in its app.', 'mvweb-core' ) ),
				array( 'text' => __( 'The time on the payment page ran out, try once more.', 'mvweb-core' ) ),
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_cart_defaults' ) ) {
	/**
	 * Values of the cart settings that nobody has changed.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_cart_defaults() {
		return array(
			'mvweb_cart_add_action'    => 'panel',
			'mvweb_minicart_ship_text' => __( 'Free delivery on orders over {amount}', 'mvweb-core' ),
			'mvweb_cart_ship_text'     => __( 'Free delivery from {amount}', 'mvweb-core' ),
			'mvweb_cart_notes'         => wp_json_encode( array() ),
			'mvweb_cart_cross_title'   => __( 'Often bought together', 'mvweb-core' ),
			'mvweb_cart_cross_count'   => 4,
			'mvweb_cart_empty_text'    => '',
			'mvweb_shipping_hints'     => wp_json_encode( array() ),
			'mvweb_thanks_lead'        => __( 'Thank you for your purchase! We have sent the confirmation to your email.', 'mvweb-core' ),
			'mvweb_thanks_steps'       => wp_json_encode( array() ),
			'mvweb_pay_fail_reasons'   => mvweb_core_cart_reasons_default(),
		);
	}
}

if ( ! function_exists( 'mvweb_core_cart_option' ) ) {
	/**
	 * A cart setting.
	 *
	 * @since 0.1.0
	 *
	 * @param string $key Setting name.
	 *
	 * @return mixed The saved value, the default while nothing is saved. The default is not handed to get_theme_mod(), which fills a %s of it with the address of the theme.
	 */
	function mvweb_core_cart_option( $key ) {
		$value = get_theme_mod( $key, null );

		if ( null !== $value ) {
			return $value;
		}

		$defaults = mvweb_core_cart_defaults();

		return isset( $defaults[ $key ] ) ? $defaults[ $key ] : '';
	}
}

if ( ! function_exists( 'mvweb_core_cart_rows' ) ) {
	/**
	 * The rows of a list setting, without the empty ones.
	 *
	 * @since 0.1.0
	 *
	 * @param string $key Setting name.
	 *
	 * @return array<int,array<string,string>>
	 */
	function mvweb_core_cart_rows( $key ) {
		$rows  = json_decode( (string) mvweb_core_cart_option( $key ), true );
		$clean = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$row = array_map( 'trim', array_map( 'strval', $row ) );

			if ( '' !== implode( '', $row ) ) {
				$clean[] = $row;
			}
		}

		return $clean;
	}
}

if ( ! function_exists( 'mvweb_core_cart_icon_choices' ) ) {
	/**
	 * The icons a note of the cart can carry.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Icon => label.
	 */
	function mvweb_core_cart_icon_choices() {
		return array(
			''               => __( 'No icon', 'mvweb-core' ),
			'shield-check'   => __( 'Shield', 'mvweb-core' ),
			'refresh'        => __( 'Return', 'mvweb-core' ),
			'truck-delivery' => __( 'Delivery', 'mvweb-core' ),
			'package'        => __( 'Parcel', 'mvweb-core' ),
			'credit-card'    => __( 'Card', 'mvweb-core' ),
			'lock'           => __( 'Lock', 'mvweb-core' ),
			'clock'          => __( 'Clock', 'mvweb-core' ),
			'gift'           => __( 'Gift', 'mvweb-core' ),
			'headset'        => __( 'Support', 'mvweb-core' ),
			'thumb-up'       => __( 'Thumb up', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_cart_tree' ) ) {
	/**
	 * A section of its own for the cart, the checkout and the side cart.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_cart_tree( $tree ) {
		if ( isset( $tree['mvweb_cz_conversion']['sections'] ) ) {
			$tree['mvweb_cz_conversion']['sections']['mvweb_cz_conversion_cart'] = __( 'Cart and checkout', 'mvweb-core' );
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_cart_tree', 97 );

if ( ! function_exists( 'mvweb_core_cart_fields' ) ) {
	/**
	 * Fields of the cart, the checkout, the order received page and the side cart.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_cart_fields() {
		$defaults = mvweb_core_cart_defaults();
		$section  = 'mvweb_cz_conversion_cart';

		return array(
			array(
				'type'        => 'radio',
				'settings'    => 'mvweb_cart_add_action',
				'section'     => $section,
				'label'       => __( 'When an item is added to the cart', 'mvweb-core' ),
				'description' => __( 'The counter in the header is refreshed either way; the panel slides in over the page on top of that.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_cart_add_action'],
				'choices'     => array(
					'panel'   => __( 'Open the side cart', 'mvweb-core' ),
					'counter' => __( 'Only refresh the counter', 'mvweb-core' ),
				),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_minicart_ship_text',
				'section'     => $section,
				'label'       => __( 'Side cart: line about free delivery', 'mvweb-core' ),
				'description' => __( '{amount} stands for the order total from which delivery is free, set in Delivery. Nothing is printed while that total is 0.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_minicart_ship_text'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_cart_ship_text',
				'section'     => $section,
				'label'       => __( 'Cart: fact about free delivery under the heading', 'mvweb-core' ),
				'description' => __( '{amount} stands for the order total from which delivery is free. Nothing is printed while that total is 0.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_cart_ship_text'],
			),
			array(
				'type'        => 'repeater',
				'settings'    => 'mvweb_cart_notes',
				'section'     => $section,
				'label'       => __( 'Cart: notes under the order total', 'mvweb-core' ),
				'description' => __( 'Short promises next to the checkout button. Empty means no block.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_cart_notes'],
				'fields'      => array(
					'icon' => array(
						'type'    => 'select',
						'label'   => __( 'Icon', 'mvweb-core' ),
						'choices' => mvweb_core_cart_icon_choices(),
					),
					'text' => array(
						'type'    => 'text',
						'label'   => __( 'Line', 'mvweb-core' ),
						'choices' => array(),
					),
				),
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_cart_cross_title',
				'section'  => $section,
				'label'    => __( 'Cart: heading of the goods bought together', 'mvweb-core' ),
				'default'  => $defaults['mvweb_cart_cross_title'],
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_cart_cross_count',
				'section'     => $section,
				'label'       => __( 'Cart: how many goods bought together', 'mvweb-core' ),
				'description' => __( 'The cross-sells of the goods in the cart. 0 hides the block.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_cart_cross_count'],
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 12,
					'step' => 1,
				),
			),
			array(
				'type'        => 'textarea',
				'settings'    => 'mvweb_cart_empty_text',
				'section'     => $section,
				'label'       => __( 'Empty cart: text', 'mvweb-core' ),
				'description' => __( 'What the shop sells and where to look. Empty prints a neutral line.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_cart_empty_text'],
			),
			array(
				'type'        => 'repeater',
				'settings'    => 'mvweb_shipping_hints',
				'section'     => $section,
				'label'       => __( 'Checkout: line under a delivery method', 'mvweb-core' ),
				'description' => __( 'The term or the address of a method. The method is its id from WooCommerce (flat_rate, flat_rate:2, local_pickup); an id without the number fits every method of the kind. A pickup point without a line shows the address from the contacts.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_shipping_hints'],
				'fields'      => array(
					'method' => array(
						'type'    => 'text',
						'label'   => __( 'Method id', 'mvweb-core' ),
						'choices' => array(),
					),
					'text'   => array(
						'type'    => 'text',
						'label'   => __( 'Line', 'mvweb-core' ),
						'choices' => array(),
					),
				),
			),
			array(
				'type'     => 'textarea',
				'settings' => 'mvweb_thanks_lead',
				'section'  => $section,
				'label'    => __( 'Order received: text under the heading', 'mvweb-core' ),
				'default'  => $defaults['mvweb_thanks_lead'],
			),
			array(
				'type'        => 'repeater',
				'settings'    => 'mvweb_thanks_steps',
				'section'     => $section,
				'label'       => __( 'Order received: what happens next', 'mvweb-core' ),
				'description' => __( 'Steps the customer can expect, in order. Empty means no block.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_thanks_steps'],
				'fields'      => array(
					'title' => array(
						'type'    => 'text',
						'label'   => __( 'Step', 'mvweb-core' ),
						'choices' => array(),
					),
					'text'  => array(
						'type'    => 'textarea',
						'label'   => __( 'Text', 'mvweb-core' ),
						'choices' => array(),
					),
				),
			),
			array(
				'type'        => 'repeater',
				'settings'    => 'mvweb_pay_fail_reasons',
				'section'     => $section,
				'label'       => __( 'Failed payment: usual reasons', 'mvweb-core' ),
				'description' => __( 'Empty means no list.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_pay_fail_reasons'],
				'fields'      => array(
					'text' => array(
						'type'    => 'textarea',
						'label'   => __( 'Reason', 'mvweb-core' ),
						'choices' => array(),
					),
				),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_cart_register' ) ) {
	/**
	 * Hand the fields to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_cart_register( $kit ) {
		$kit->add_fields( mvweb_core_cart_fields() );
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_cart_register' );

if ( ! function_exists( 'mvweb_core_cart_money' ) ) {
	/**
	 * An amount as plain text in the currency of the shop.
	 *
	 * @since 0.1.0
	 *
	 * @param float $amount Amount.
	 *
	 * @return string
	 */
	function mvweb_core_cart_money( $amount ) {
		return trim( html_entity_decode( wp_strip_all_tags( wc_price( (float) $amount ) ), ENT_QUOTES, 'UTF-8' ) );
	}
}

if ( ! function_exists( 'mvweb_core_cart_ship_text' ) ) {
	/**
	 * The line about free delivery, with the total filled in.
	 *
	 * @since 0.1.0
	 *
	 * @param string $key Setting that holds the wording.
	 *
	 * @return string Empty while the shop promises no free delivery.
	 */
	function mvweb_core_cart_ship_text( $key ) {
		$min  = mvweb_core_free_shipping_min();
		$text = trim( (string) mvweb_core_cart_option( $key ) );

		if ( $min <= 0 || '' === $text || ! function_exists( 'wc_price' ) ) {
			return '';
		}

		return str_replace( '{amount}', mvweb_core_cart_money( $min ), $text );
	}
}

if ( ! function_exists( 'mvweb_core_cart_theme_ready' ) ) {
	/**
	 * Whether the theme draws the cart pages and the counter: it says so by having the counter template.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_cart_theme_ready() {
		return mvweb_core_is_woocommerce() && '' !== locate_template( 'template-parts/cart-count.php' );
	}
}

if ( ! function_exists( 'mvweb_core_side_cart_mode' ) ) {
	/**
	 * What happens on adding an item to the cart.
	 *
	 * @since 0.1.0
	 *
	 * @return string panel or counter.
	 */
	function mvweb_core_side_cart_mode() {
		return 'counter' === get_theme_mod( 'mvweb_cart_add_action', 'panel' ) ? 'counter' : 'panel';
	}
}

if ( ! function_exists( 'mvweb_core_cart_page_here' ) ) {
	/**
	 * Whether this request is the cart, the checkout or a page of it.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_cart_page_here() {
		return mvweb_core_is_woocommerce() && ( is_cart() || is_checkout() );
	}
}

if ( ! function_exists( 'mvweb_core_side_cart_on' ) ) {
	/**
	 * Whether the side cart is printed on this request.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_side_cart_on() {
		return mvweb_core_is_woocommerce()
			&& 'panel' === mvweb_core_side_cart_mode()
			&& ! mvweb_core_cart_page_here()
			&& '' !== locate_template( 'template-parts/side-cart.php' );
	}
}

if ( ! function_exists( 'mvweb_core_side_cart_body_class' ) ) {
	/**
	 * Tell the stylesheets how the cart answers an added item.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $classes Body classes.
	 *
	 * @return string[]
	 */
	function mvweb_core_side_cart_body_class( $classes ) {
		if ( mvweb_core_cart_theme_ready() ) {
			$classes[] = 'has-cart-' . mvweb_core_side_cart_mode();
		}

		return $classes;
	}
}
add_filter( 'body_class', 'mvweb_core_side_cart_body_class' );

if ( ! function_exists( 'mvweb_core_side_cart_print' ) ) {
	/**
	 * Print the side cart at the end of the page.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_side_cart_print() {
		if ( mvweb_core_side_cart_on() ) {
			get_template_part( 'template-parts/side-cart' );
		}
	}
}
add_action( 'wp_footer', 'mvweb_core_side_cart_print', 5 );

if ( ! function_exists( 'mvweb_core_cart_fragments' ) ) {
	/**
	 * The parts of the page WooCommerce replaces after the cart has changed.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $fragments Selector => markup.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_cart_fragments( $fragments ) {
		if ( '' !== locate_template( 'template-parts/cart-count.php' ) ) {
			ob_start();
			get_template_part( 'template-parts/cart-count' );
			$fragments['[data-cart-count]'] = trim( (string) ob_get_clean() );
		}

		if ( 'panel' === mvweb_core_side_cart_mode() && '' !== locate_template( 'template-parts/side-cart.php' ) ) {
			ob_start();
			get_template_part( 'template-parts/side-cart', null, array( 'fragment' => true ) );
			$fragments['[data-minicart-panel]'] = trim( (string) ob_get_clean() );
		}

		return $fragments;
	}
}
add_filter( 'woocommerce_add_to_cart_fragments', 'mvweb_core_cart_fragments' );

if ( ! function_exists( 'mvweb_core_cart_clear' ) ) {
	/**
	 * Empty the cart on the button under the list.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_cart_clear() {
		if ( empty( $_POST['mvweb_clear_cart'] ) || ! function_exists( 'WC' ) || ! WC()->cart ) {
			return;
		}

		$nonce = isset( $_POST['woocommerce-cart-nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['woocommerce-cart-nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'woocommerce-cart' ) ) {
			return;
		}

		WC()->cart->empty_cart();
		wc_add_notice( __( 'The cart is empty now.', 'mvweb-core' ) );
		wp_safe_redirect( wc_get_cart_url() );
		exit;
	}
}
add_action( 'wp_loaded', 'mvweb_core_cart_clear', 21 );

if ( ! function_exists( 'mvweb_core_payment_icon' ) ) {
	/**
	 * The icon of a payment method.
	 *
	 * @since 0.1.0
	 *
	 * @param string $gateway_id Id of the payment gateway.
	 *
	 * @return string Icon name of the sprite of the theme.
	 */
	function mvweb_core_payment_icon( $gateway_id ) {
		$icons = array(
			'bacs'          => 'receipt-2',
			'cheque'        => 'receipt',
			'cod'           => 'wallet',
			'mvweb_request' => 'messages',
			'ppcp-gateway'  => 'credit-card',
			'stripe'        => 'credit-card',
			'yookassa'      => 'credit-card',
			'cloudpayments' => 'credit-card',
			'robokassa'     => 'credit-card',
			'tinkoff'       => 'credit-card',
			'sberbank'      => 'credit-card',
		);

		/**
		 * Filter the icons of the payment methods.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $icons Gateway id => icon name.
		 */
		$icons = (array) apply_filters( 'mvweb_core_payment_icons', $icons );

		return isset( $icons[ $gateway_id ] ) ? (string) $icons[ $gateway_id ] : 'credit-card';
	}
}

if ( ! function_exists( 'mvweb_core_shipping_icon' ) ) {
	/**
	 * The icon of a delivery method.
	 *
	 * @since 0.1.0
	 *
	 * @param string $method_id Id of the shipping method, without the instance.
	 *
	 * @return string Icon name of the sprite of the theme.
	 */
	function mvweb_core_shipping_icon( $method_id ) {
		$icons = array(
			'flat_rate'     => 'truck-delivery',
			'free_shipping' => 'truck-delivery',
			'local_pickup'  => 'home',
		);

		/**
		 * Filter the icons of the delivery methods.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $icons Method id => icon name.
		 */
		$icons = (array) apply_filters( 'mvweb_core_shipping_icons', $icons );

		return isset( $icons[ $method_id ] ) ? (string) $icons[ $method_id ] : 'package';
	}
}

if ( ! function_exists( 'mvweb_core_shipping_hint' ) ) {
	/**
	 * The line under a delivery method: the term, the address of the pickup point.
	 *
	 * @since 0.1.0
	 *
	 * @param string $rate_id    Id of the rate: flat_rate:2.
	 * @param string $method_id  Id of the method: flat_rate.
	 *
	 * @return string
	 */
	function mvweb_core_shipping_hint( $rate_id, $method_id ) {
		$generic = '';

		foreach ( mvweb_core_cart_rows( 'mvweb_shipping_hints' ) as $row ) {
			$key = isset( $row['method'] ) ? $row['method'] : '';

			if ( $key === $rate_id ) {
				return isset( $row['text'] ) ? $row['text'] : '';
			}

			if ( $key === $method_id ) {
				$generic = isset( $row['text'] ) ? $row['text'] : '';
			}
		}

		if ( '' === $generic && 'local_pickup' === $method_id ) {
			$contacts = mvweb_core_contacts();
			$first    = isset( $contacts['addresses'][0]['address'] ) ? (string) $contacts['addresses'][0]['address'] : '';

			return $first;
		}

		return $generic;
	}
}

if ( ! function_exists( 'mvweb_core_cart_line_order' ) ) {
	/**
	 * Keep the name and the price in a line of the cart.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $order Shown parts in order.
	 * @param string   $area  Area name.
	 *
	 * @return string[]
	 */
	function mvweb_core_cart_line_order( $order, $area ) {
		if ( 'cart-line' !== $area ) {
			return $order;
		}

		foreach ( array( 'title', 'price' ) as $slug ) {
			if ( ! in_array( $slug, $order, true ) ) {
				$order[] = $slug;
			}
		}

		return $order;
	}
}
add_filter( 'mvweb_core_layout_order', 'mvweb_core_cart_line_order', 10, 2 );

if ( ! function_exists( 'mvweb_core_cart_styles' ) ) {
	/**
	 * The stylesheets of the cart pages and of the side cart.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Keys of the request.
	 *
	 * @return string[]
	 */
	function mvweb_core_cart_styles( $styles ) {
		if ( ! mvweb_core_cart_theme_ready() ) {
			return $styles;
		}

		if ( mvweb_core_cart_page_here() ) {
			array_push( $styles, 'crumbs', 'page-hero', 'form', 'catalog', 'empty', 'cart' );
		} elseif ( ! is_admin() ) {
			$styles[] = 'side-cart';
		}

		return $styles;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_core_cart_styles', 20 );

if ( ! function_exists( 'mvweb_core_cart_modules' ) ) {
	/**
	 * The scripts of the cart pages and of the side cart.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules File names without extension.
	 *
	 * @return string[]
	 */
	function mvweb_core_cart_modules( $modules ) {
		if ( ! mvweb_core_cart_theme_ready() ) {
			return $modules;
		}

		if ( mvweb_core_cart_page_here() ) {
			array_push( $modules, 'product-page', 'cart-page' );
		} else {
			$modules[] = 'side-cart';
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_core_cart_modules', 20 );

if ( ! function_exists( 'mvweb_core_cart_classic_blocks' ) ) {
	/**
	 * Print the classic cart and checkout where WooCommerce put its blocks.
	 *
	 * @since 0.1.0
	 *
	 * @param string|null $pre_render   Output decided before, or null.
	 * @param array       $parsed_block The block being rendered.
	 *
	 * @return string|null
	 */
	function mvweb_core_cart_classic_blocks( $pre_render, $parsed_block ) {
		if ( null !== $pre_render || is_admin() || ! class_exists( 'WooCommerce' ) || empty( $parsed_block['blockName'] ) ) {
			return $pre_render;
		}

		$shortcodes = array(
			'woocommerce/cart'     => 'woocommerce_cart',
			'woocommerce/checkout' => 'woocommerce_checkout',
		);

		if ( ! isset( $shortcodes[ $parsed_block['blockName'] ] ) ) {
			return $pre_render;
		}

		return do_shortcode( '[' . $shortcodes[ $parsed_block['blockName'] ] . ']' );
	}
}
add_filter( 'pre_render_block', 'mvweb_core_cart_classic_blocks', 10, 2 );
