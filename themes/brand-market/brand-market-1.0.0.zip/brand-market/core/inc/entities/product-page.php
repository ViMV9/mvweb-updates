<?php
/**
 * The page of one item of the catalogue: what its sections say and how they are set.
 *
 * The page is the same for a WooCommerce product and an item of the theme's own
 * catalogue. The photo, the header, the summary, the purchase box and the sections
 * under it are areas of the composition; the reviews, the goods bought together, the
 * help card and the settings of their headings come from here.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_product_page_defaults' ) ) {
	/**
	 * The settings of the item page and what they say until the owner changes them.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_product_page_defaults() {
		return array(
			'mvweb_stock_note'            => '',
			'mvweb_product_delivery'      => '',
			'mvweb_product_nav'           => true,
			'mvweb_product_specs_title'   => __( 'Specifications', 'mvweb-core' ),
			'mvweb_product_reviews_title' => __( 'Customer reviews', 'mvweb-core' ),
			'mvweb_product_upsells_title' => __( 'Bought together', 'mvweb-core' ),
			'mvweb_upsells_count'         => 4,
			'mvweb_reviews_count'         => 10,
			'mvweb_product_help_title'    => '',
			'mvweb_product_help_text'     => '',
			'mvweb_product_help_button'   => __( 'Ask a question', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_product_option' ) ) {
	/**
	 * A setting of the item page, with the default it was declared with.
	 *
	 * @since 0.1.0
	 *
	 * @param string $setting Setting id.
	 *
	 * @return mixed
	 */
	function mvweb_core_product_option( $setting ) {
		$defaults = mvweb_core_product_page_defaults();

		return get_theme_mod( $setting, isset( $defaults[ $setting ] ) ? $defaults[ $setting ] : '' );
	}
}

if ( ! function_exists( 'mvweb_core_product_page_fields' ) ) {
	/**
	 * The fields of the item page that the catalogue section does not have yet.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_product_page_fields() {
		$defaults = mvweb_core_product_page_defaults();
		$section  = 'mvweb_cz_catalog_product';

		return array(
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_stock_note',
				'section'     => $section,
				'label'       => __( 'Note beside the availability', 'mvweb-core' ),
				'description' => __( 'For example: ships today. Empty prints nothing.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_stock_note'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_product_delivery',
				'section'     => $section,
				'label'       => __( 'Line under the add to cart button', 'mvweb-core' ),
				'description' => __( 'Delivery terms in a shop. Empty says how much is missing for free delivery when the shop promises it, and nothing otherwise. A showroom prints the line above the buttons instead.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_product_delivery'],
			),
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_product_nav',
				'section'     => $section,
				'label'       => __( 'Links to the sections under the item', 'mvweb-core' ),
				'description' => __( 'A strip of anchors above the description, the specifications and the reviews. It follows the order of the sections and appears when there are two or more.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_product_nav'],
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_product_specs_title',
				'section'  => $section,
				'label'    => __( 'Heading of the specifications', 'mvweb-core' ),
				'default'  => $defaults['mvweb_product_specs_title'],
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_product_reviews_title',
				'section'  => $section,
				'label'    => __( 'Heading of the reviews', 'mvweb-core' ),
				'default'  => $defaults['mvweb_product_reviews_title'],
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_reviews_count',
				'section'     => $section,
				'label'       => __( 'How many reviews to show', 'mvweb-core' ),
				'description' => __( 'The newest ones. WooCommerce only.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_reviews_count'],
				'input_attrs' => array(
					'min'  => 1,
					'max'  => 50,
					'step' => 1,
				),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_product_upsells_title',
				'section'     => $section,
				'label'       => __( 'Heading of the goods bought together', 'mvweb-core' ),
				'description' => __( 'The goods are set on the product, in the linked products. Without them the block is not shown.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_product_upsells_title'],
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_upsells_count',
				'section'     => $section,
				'label'       => __( 'How many goods bought together to show', 'mvweb-core' ),
				'description' => __( '0 hides the block.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_upsells_count'],
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 12,
					'step' => 1,
				),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_product_help_title',
				'section'     => $section,
				'label'       => __( 'Heading of the help card', 'mvweb-core' ),
				'description' => __( 'A card beside the description that offers to ask a question. Empty means no card.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_product_help_title'],
			),
			array(
				'type'     => 'textarea',
				'settings' => 'mvweb_product_help_text',
				'section'  => $section,
				'label'    => __( 'Text of the help card', 'mvweb-core' ),
				'default'  => $defaults['mvweb_product_help_text'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_product_help_button',
				'section'     => $section,
				'label'       => __( 'Button of the help card', 'mvweb-core' ),
				'description' => __( 'Opens the request form. It needs the address of the request button in the conversion settings.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_product_help_button'],
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_product_page_register' ) ) {
	/**
	 * Hand the fields to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_product_page_register( $kit ) {
		$kit->add_fields( mvweb_core_product_page_fields() );
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_product_page_register' );

if ( ! function_exists( 'mvweb_core_product_page_modules' ) ) {
	/**
	 * The script of the item page: the quantity stepper and the photo in the lightbox.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules File names without extension.
	 *
	 * @return string[]
	 */
	function mvweb_core_product_page_modules( $modules ) {
		if ( mvweb_core_is_product() ) {
			$modules[] = 'product-page';
			$modules[] = 'prose-tables';
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_core_product_page_modules' );

if ( ! function_exists( 'mvweb_core_product_header_order' ) ) {
	/**
	 * Keep the name in the header of the item: it is the one heading of the page.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $order Shown parts in order.
	 * @param string   $area  Area name.
	 *
	 * @return string[]
	 */
	function mvweb_core_product_header_order( $order, $area ) {
		if ( 'product-header' === $area && ! in_array( 'title', $order, true ) ) {
			array_unshift( $order, 'title' );
		}

		return $order;
	}
}
add_filter( 'mvweb_core_layout_order', 'mvweb_core_product_header_order', 10, 2 );

if ( ! function_exists( 'mvweb_core_item_rating_counts' ) ) {
	/**
	 * How many reviews gave each number of stars.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return array<int,int> Stars, five to one => reviews. Empty without reviews.
	 */
	function mvweb_core_item_rating_counts( $id ) {
		$product = mvweb_core_wc_item( $id );

		if ( ! $product || $product->get_review_count() < 1 ) {
			return array();
		}

		$raw    = (array) $product->get_rating_counts();
		$counts = array();

		for ( $stars = 5; $stars >= 1; $stars-- ) {
			$counts[ $stars ] = isset( $raw[ $stars ] ) ? absint( $raw[ $stars ] ) : 0;
		}

		return $counts;
	}
}

if ( ! function_exists( 'mvweb_core_item_reviews_open' ) ) {
	/**
	 * Whether a visitor may leave a review under an item.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return bool
	 */
	function mvweb_core_item_reviews_open( $id ) {
		return null !== mvweb_core_wc_item( $id ) && function_exists( 'wc_reviews_enabled' ) && wc_reviews_enabled() && comments_open( $id );
	}
}

if ( ! function_exists( 'mvweb_core_item_reviews' ) ) {
	/**
	 * The approved reviews of an item, the newest first.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return array<int,array{name:string,initial:string,date:string,verified:bool,rating:int,text:string}>
	 */
	function mvweb_core_item_reviews( $id ) {
		if ( null === mvweb_core_wc_item( $id ) || ! function_exists( 'wc_reviews_enabled' ) || ! wc_reviews_enabled() ) {
			return array();
		}

		$comments = get_comments(
			array(
				'post_id' => $id,
				'status'  => 'approve',
				'type'    => 'review',
				'parent'  => 0,
				'number'  => max( 1, absint( mvweb_core_product_option( 'mvweb_reviews_count' ) ) ),
			)
		);
		$show     = 'yes' === get_option( 'woocommerce_review_rating_verification_label' );
		$rows     = array();

		foreach ( $comments as $comment ) {
			$name = trim( (string) $comment->comment_author );
			$name = '' === $name ? __( 'Anonymous', 'mvweb-core' ) : $name;

			$rows[] = array(
				'name'     => $name,
				'initial'  => function_exists( 'mb_substr' ) ? mb_strtoupper( mb_substr( $name, 0, 1 ) ) : strtoupper( substr( $name, 0, 1 ) ),
				'date'     => (string) get_comment_date( '', $comment ),
				'verified' => $show && function_exists( 'wc_review_is_from_verified_owner' ) && wc_review_is_from_verified_owner( (int) $comment->comment_ID ),
				'rating'   => min( 5, max( 0, absint( get_comment_meta( $comment->comment_ID, 'rating', true ) ) ) ),
				'text'     => trim( (string) $comment->comment_content ),
			);
		}

		return $rows;
	}
}

if ( ! function_exists( 'mvweb_core_item_upsell_ids' ) ) {
	/**
	 * The goods the owner linked to a product as bought together.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return int[]
	 */
	function mvweb_core_item_upsell_ids( $id ) {
		$product = mvweb_core_wc_item( $id );
		$limit   = absint( mvweb_core_product_option( 'mvweb_upsells_count' ) );

		if ( ! $product || $limit < 1 ) {
			return array();
		}

		$ids = array_filter( array_unique( array_map( 'absint', array_merge( $product->get_upsell_ids(), $product->get_cross_sell_ids() ) ) ), 'mvweb_core_item_visible' );

		return array_slice( array_values( $ids ), 0, $limit );
	}
}

if ( ! function_exists( 'mvweb_core_item_wholesale_from' ) ) {
	/**
	 * From how many pieces the wholesale price holds.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return int The first tier, else the minimum of the item; 1 when there is no minimum.
	 */
	function mvweb_core_item_wholesale_from( $id ) {
		$tiers = mvweb_core_tiers( $id );

		return ! empty( $tiers ) ? (int) array_key_first( $tiers ) : (int) mvweb_core_quantity_rules( $id )['min'];
	}
}

if ( ! function_exists( 'mvweb_core_product_delivery_line' ) ) {
	/**
	 * The line under the add to cart button.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty when the shop says nothing about delivery.
	 */
	function mvweb_core_product_delivery_line() {
		$own = trim( (string) mvweb_core_product_option( 'mvweb_product_delivery' ) );

		if ( '' !== $own ) {
			return $own;
		}

		$min = mvweb_core_free_shipping_min();

		if ( $min <= 0 ) {
			return '';
		}

		/* translators: %s: order total from which delivery is free, with the currency. */
		return sprintf( __( 'Free delivery on orders from %s', 'mvweb-core' ), html_entity_decode( wp_strip_all_tags( mvweb_core_price_html( $min ) ), ENT_QUOTES, 'UTF-8' ) );
	}
}

if ( ! function_exists( 'mvweb_core_item_specs_markup' ) ) {
	/**
	 * The specifications of a WooCommerce product as the store prints them.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return string Empty for a product with nothing to list and for the own catalogue.
	 */
	function mvweb_core_item_specs_markup( $id ) {
		static $cache = array();

		$product = mvweb_core_wc_item( $id );

		if ( ! $product ) {
			return '';
		}

		if ( ! isset( $cache[ $id ] ) ) {
			ob_start();
			wc_display_product_attributes( $product );
			$cache[ $id ] = trim( (string) ob_get_clean() );
		}

		return $cache[ $id ];
	}
}

if ( ! function_exists( 'mvweb_core_product_section_filled' ) ) {
	/**
	 * Whether a section under the item has anything to say.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $id   Item id.
	 * @param string $slug Section: description, specs, reviews, upsells or related.
	 *
	 * @return bool
	 */
	function mvweb_core_product_section_filled( $id, $slug ) {
		static $cache = array();

		$key = $id . ':' . $slug;

		if ( isset( $cache[ $key ] ) ) {
			return $cache[ $key ];
		}

		switch ( $slug ) {
			case 'description':
				$filled = '' !== trim( mvweb_core_item_content( $id ) );
				break;
			case 'specs':
				$filled = mvweb_core_is_woocommerce() && null !== mvweb_core_wc_item( $id )
					? '' !== mvweb_core_item_specs_markup( $id )
					: ! empty( mvweb_core_item_specs( $id ) );
				break;
			case 'reviews':
				$filled = null !== mvweb_core_wc_item( $id ) && ( ! empty( mvweb_core_item_reviews( $id ) ) || mvweb_core_item_reviews_open( $id ) );
				break;
			case 'upsells':
				$filled = ! empty( mvweb_core_item_upsell_ids( $id ) );
				break;
			case 'related':
				$filled = ! empty( mvweb_core_related_items( $id ) );
				break;
			default:
				$filled = false;
		}

		$cache[ $key ] = (bool) apply_filters( 'mvweb_core_product_section_filled', $filled, $id, $slug );

		return $cache[ $key ];
	}
}

if ( ! function_exists( 'mvweb_core_product_sections' ) ) {
	/**
	 * The sections under the item that will be printed, in order.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return string[]
	 */
	function mvweb_core_product_sections( $id ) {
		return array_values(
			array_filter(
				mvweb_core_layout_order( 'product-sections' ),
				static function ( $slug ) use ( $id ) {
					return mvweb_core_product_section_filled( $id, $slug );
				}
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_product_section_title' ) ) {
	/**
	 * The heading of a section under the item and its name in the strip of anchors.
	 *
	 * @since 0.1.0
	 *
	 * @param string $slug Section slug.
	 *
	 * @return string
	 */
	function mvweb_core_product_section_title( $slug ) {
		$titles = array(
			'specs'   => (string) mvweb_core_product_option( 'mvweb_product_specs_title' ),
			'reviews' => (string) mvweb_core_product_option( 'mvweb_product_reviews_title' ),
			'upsells' => (string) mvweb_core_product_option( 'mvweb_product_upsells_title' ),
			'related' => (string) mvweb_core_option( 'mvweb_related_title' ),
		);

		return isset( $titles[ $slug ] ) ? $titles[ $slug ] : '';
	}
}

if ( ! function_exists( 'mvweb_core_product_help' ) ) {
	/**
	 * The card beside the description that offers to ask a question.
	 *
	 * @since 0.1.0
	 *
	 * @return array{title:string,text:string,button:string,url:string} Empty without a heading.
	 */
	function mvweb_core_product_help() {
		$title = trim( (string) mvweb_core_product_option( 'mvweb_product_help_title' ) );

		if ( '' === $title ) {
			return array();
		}

		return array(
			'title'  => $title,
			'text'   => trim( (string) mvweb_core_product_option( 'mvweb_product_help_text' ) ),
			'button' => trim( (string) mvweb_core_product_option( 'mvweb_product_help_button' ) ),
			'url'    => trim( (string) get_theme_mod( 'mvweb_cta_url', '' ) ),
		);
	}
}
