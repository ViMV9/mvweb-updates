<?php
/**
 * Pages of the services: the listing, a section and the page of one service.
 *
 * What the templates of the services family print and the core has no home
 * for yet: the wording of the strips and of the links, the line of a section
 * under its heading, the note beside a price, the messengers of a service and
 * the services that stand next to the one being read.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_services_pages_defaults' ) ) {
	/**
	 * Defaults of the settings this module adds.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_services_pages_defaults() {
		return array(
			'mvweb_service_list_lead'     => '',
			'mvweb_service_card_more'     => __( 'Details', 'mvweb-core' ),
			'mvweb_service_section_more'  => __( 'Open the section', 'mvweb-core' ),
			'mvweb_service_related_title' => __( 'Other services of the section', 'mvweb-core' ),
			'mvweb_service_related_more'  => __( 'The whole section', 'mvweb-core' ),
			'mvweb_service_related_count' => 3,
			'mvweb_service_works_title'   => __( 'Works on this service', 'mvweb-core' ),
			'mvweb_service_works_count'   => 3,
			'mvweb_service_message'       => __( 'Hello! I am interested in the service «{service}».', 'mvweb-core' ),
			'mvweb_service_messengers'    => wp_json_encode( array_keys( function_exists( 'mvweb_cz_chats' ) ? mvweb_cz_chats() : array() ) ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_services_pages_option' ) ) {
	/**
	 * One setting of this module.
	 *
	 * @since 0.1.0
	 *
	 * @param string $setting Setting id.
	 *
	 * @return mixed
	 */
	function mvweb_core_services_pages_option( $setting ) {
		$defaults = mvweb_core_services_pages_defaults();

		return get_theme_mod( $setting, isset( $defaults[ $setting ] ) ? $defaults[ $setting ] : '' );
	}
}

if ( ! function_exists( 'mvweb_core_services_pages_fields' ) ) {
	/**
	 * Fields of the services sections that belong to the pages.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_services_pages_fields() {
		$defaults = mvweb_core_services_pages_defaults();

		return array(
			array(
				'type'        => 'textarea',
				'settings'    => 'mvweb_service_list_lead',
				'section'     => 'mvweb_cz_services_list',
				'label'       => __( 'Text under the heading of the services page', 'mvweb-core' ),
				'description' => __( 'One or two sentences over the list. A section of services takes its own description instead. Empty prints nothing.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_service_list_lead'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_service_card_more',
				'section'     => 'mvweb_cz_services_list',
				'label'       => __( 'Link on the service card', 'mvweb-core' ),
				'description' => __( 'Shown when the card lists the link. Empty prints an arrow alone.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_service_card_more'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_service_section_more',
				'section'     => 'mvweb_cz_services_list',
				'label'       => __( 'Link on the card of a section', 'mvweb-core' ),
				'description' => __( 'Empty prints an arrow alone.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_service_section_more'],
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_service_related_title',
				'section'  => 'mvweb_cz_services_page',
				'label'    => __( 'Heading of the other services of the section', 'mvweb-core' ),
				'default'  => $defaults['mvweb_service_related_title'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_service_related_more',
				'section'     => 'mvweb_cz_services_page',
				'label'       => __( 'Link to the whole section', 'mvweb-core' ),
				'description' => __( 'Empty prints no link.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_service_related_more'],
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_service_related_count',
				'section'     => 'mvweb_cz_services_page',
				'label'       => __( 'How many other services to show', 'mvweb-core' ),
				'description' => __( '0 hides the strip.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_service_related_count'],
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 12,
					'step' => 1,
				),
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_service_works_title',
				'section'  => 'mvweb_cz_services_page',
				'label'    => __( 'Heading of the works on the service', 'mvweb-core' ),
				'default'  => $defaults['mvweb_service_works_title'],
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_service_works_count',
				'section'     => 'mvweb_cz_services_page',
				'label'       => __( 'How many works to show', 'mvweb-core' ),
				'description' => __( '0 hides the strip.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_service_works_count'],
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 12,
					'step' => 1,
				),
			),
			array(
				'type'        => 'multicheck',
				'settings'    => 'mvweb_service_messengers',
				'section'     => 'mvweb_cz_services_page',
				'label'       => __( 'Messengers in the side card', 'mvweb-core' ),
				'description' => __( 'The buttons open a chat with you. A messenger without a link is not shown.', 'mvweb-core' ) . ' ' . mvweb_cz_goto( 'mvweb_cz_profile_contacts', __( 'Links', 'mvweb-core' ) ),
				'default'     => $defaults['mvweb_service_messengers'],
				'choices'     => mvweb_cz_chats(),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_service_message',
				'section'     => 'mvweb_cz_services_page',
				'label'       => __( 'First message in the messenger', 'mvweb-core' ),
				'description' => __( '{service} is replaced by the name of the service. Telegram and WhatsApp open the chat with this text typed in; the others open it empty. Empty here opens every chat empty.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_service_message'],
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_services_pages_register' ) ) {
	/**
	 * Hand the fields to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_services_pages_register( $kit ) {
		$kit->add_fields( mvweb_core_services_pages_fields() );
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_services_pages_register' );

if ( ! function_exists( 'mvweb_core_service_list_lead' ) ) {
	/**
	 * The text under the heading of the services page.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_service_list_lead() {
		return trim( (string) mvweb_core_services_pages_option( 'mvweb_service_list_lead' ) );
	}
}

if ( ! function_exists( 'mvweb_core_register_service_pages_meta' ) ) {
	/**
	 * Register the note beside the price and the points of a section.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_service_pages_meta() {
		register_post_meta(
			'mv_service',
			'_mvweb_price_note',
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => 'mvweb_core_post_meta_auth',
				'show_in_rest'      => false,
			)
		);

		register_term_meta(
			'mv_service_cat',
			'mvweb_points',
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => 'sanitize_textarea_field',
				'auth_callback'     => 'mvweb_core_term_meta_auth',
				'show_in_rest'      => false,
			)
		);
	}
}
add_action( 'init', 'mvweb_core_register_service_pages_meta', 30 );

if ( ! function_exists( 'mvweb_core_service_price_note' ) ) {
	/**
	 * The words beside the price of a service: the size, the unit, the condition.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Service id.
	 *
	 * @return string
	 */
	function mvweb_core_service_price_note( $id ) {
		return trim( (string) get_post_meta( absint( $id ), '_mvweb_price_note', true ) );
	}
}

if ( ! function_exists( 'mvweb_core_service_points' ) ) {
	/**
	 * The short lines a section prints under its heading.
	 *
	 * @since 0.1.0
	 *
	 * @param int $term_id Section id.
	 *
	 * @return string[]
	 */
	function mvweb_core_service_points( $term_id ) {
		$lines = preg_split( '/\R/u', (string) get_term_meta( absint( $term_id ), 'mvweb_points', true ) );

		return array_values( array_filter( array_map( 'trim', (array) $lines ), 'strlen' ) );
	}
}

if ( ! function_exists( 'mvweb_core_service_count' ) ) {
	/**
	 * How many services a section holds, its subsections included.
	 *
	 * @since 0.1.0
	 *
	 * @param int $term_id Section id.
	 *
	 * @return int
	 */
	function mvweb_core_service_count( $term_id ) {
		return count( mvweb_core_service_ids( absint( $term_id ), true ) );
	}
}

if ( ! function_exists( 'mvweb_core_service_term_image' ) ) {
	/**
	 * The picture of a section: its own, else the placeholder of the site.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Section.
	 * @param string  $size Image size.
	 *
	 * @return string Markup, empty when there is no picture and no placeholder.
	 */
	function mvweb_core_service_term_image( $term, $size = 'medium_large' ) {
		$thumb = absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) );

		if ( wp_attachment_is_image( $thumb ) ) {
			return (string) wp_get_attachment_image(
				$thumb,
				$size,
				false,
				array(
					'alt'      => mvweb_core_image_alt( $thumb, $term->name ),
					'loading'  => 'lazy',
					'decoding' => 'async',
				)
			);
		}

		$src = mvweb_core_placeholder_src( $size );

		return '' !== $src ? '<img src="' . esc_url( $src ) . '" alt="" loading="lazy" decoding="async">' : '';
	}
}

if ( ! function_exists( 'mvweb_core_service_terms_order' ) ) {
	/**
	 * Keep the sections of services in the order they were made in.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $args       Query arguments.
	 * @param string[]            $taxonomies Taxonomies asked for.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_service_terms_order( $args, $taxonomies ) {
		if ( ! is_admin() && array( 'mv_service_cat' ) === array_values( (array) $taxonomies ) && isset( $args['orderby'] ) && 'name' === $args['orderby'] ) {
			$args['orderby'] = 'term_id';
		}

		return $args;
	}
}
add_filter( 'get_terms_args', 'mvweb_core_service_terms_order', 10, 2 );

if ( ! function_exists( 'mvweb_core_service_price_note_box' ) ) {
	/**
	 * The note beside the price, in a box under the fields of the service.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Post being edited.
	 *
	 * @return void
	 */
	function mvweb_core_service_price_note_box( $post ) {
		wp_nonce_field( 'mvweb_service_note', 'mvweb_service_note_nonce' );
		?>
		<p class="mvweb-core-field">
			<label for="mvweb-core-service-price-note"><?php esc_html_e( 'Note beside the price', 'mvweb-core' ); ?></label>
			<input class="widefat" type="text" id="mvweb-core-service-price-note" name="mvweb_price_note" value="<?php echo esc_attr( mvweb_core_service_price_note( $post->ID ) ); ?>">
			<span class="description"><?php esc_html_e( 'What the price is for, in a few words: small breeds, per day, per square metre. Printed in the side card of the service.', 'mvweb-core' ); ?></span>
		</p>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_service_price_note_boxes' ) ) {
	/**
	 * Add the box to the service screen.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_service_price_note_boxes() {
		add_meta_box( 'mvweb-core-service-note', __( 'Price note', 'mvweb-core' ), 'mvweb_core_service_price_note_box', 'mv_service', 'normal', 'high' );
	}
}
add_action( 'add_meta_boxes', 'mvweb_core_service_price_note_boxes' );

if ( ! function_exists( 'mvweb_core_service_price_note_save' ) ) {
	/**
	 * Store the note beside the price.
	 *
	 * @since 0.1.0
	 *
	 * @param int     $post_id Post being saved.
	 * @param WP_Post $post    Post object.
	 *
	 * @return void
	 */
	function mvweb_core_service_price_note_save( $post_id, $post ) {
		if ( 'mv_service' !== $post->post_type || wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST['mvweb_service_note_nonce'], $_POST['mvweb_price_note'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mvweb_service_note_nonce'] ) ), 'mvweb_service_note' ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		update_post_meta( $post_id, '_mvweb_price_note', sanitize_text_field( wp_unslash( $_POST['mvweb_price_note'] ) ) );
	}
}
add_action( 'save_post', 'mvweb_core_service_price_note_save', 10, 2 );

if ( ! function_exists( 'mvweb_core_service_points_field' ) ) {
	/**
	 * The points of a section, on the form that edits one.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Term being edited.
	 *
	 * @return void
	 */
	function mvweb_core_service_points_field( $term ) {
		wp_nonce_field( 'mvweb_service_points', 'mvweb_service_points_nonce' );
		?>
		<tr class="form-field">
			<th scope="row"><label for="mvweb-core-service-points"><?php esc_html_e( 'Points under the heading', 'mvweb-core' ); ?></label></th>
			<td>
				<textarea class="large-text" rows="4" id="mvweb-core-service-points" name="mvweb_points"><?php echo esc_textarea( (string) get_term_meta( $term->term_id, 'mvweb_points', true ) ); ?></textarea>
				<p class="description"><?php esc_html_e( 'One short line per point, for example: Booking on the day you call. They stand in a row under the heading of the section, after the number of services.', 'mvweb-core' ); ?></p>
			</td>
		</tr>
		<?php
	}
}
add_action( 'mv_service_cat_edit_form_fields', 'mvweb_core_service_points_field' );

if ( ! function_exists( 'mvweb_core_service_points_save' ) ) {
	/**
	 * Store the points of a section.
	 *
	 * @since 0.1.0
	 *
	 * @param int $term_id Term id.
	 *
	 * @return void
	 */
	function mvweb_core_service_points_save( $term_id ) {
		if ( ! isset( $_POST['mvweb_service_points_nonce'], $_POST['mvweb_points'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mvweb_service_points_nonce'] ) ), 'mvweb_service_points' ) || ! current_user_can( 'manage_categories' ) ) {
			return;
		}

		$value = sanitize_textarea_field( wp_unslash( $_POST['mvweb_points'] ) );

		if ( '' === trim( $value ) ) {
			delete_term_meta( $term_id, 'mvweb_points' );

			return;
		}

		update_term_meta( $term_id, 'mvweb_points', $value );
	}
}
add_action( 'edited_mv_service_cat', 'mvweb_core_service_points_save' );

if ( ! function_exists( 'mvweb_core_service_primary_term' ) ) {
	/**
	 * The section a service is filed under: the primary one, else the first.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Service id.
	 *
	 * @return WP_Term|null
	 */
	function mvweb_core_service_primary_term( $id ) {
		$terms = get_the_terms( absint( $id ), 'mv_service_cat' );

		if ( ! is_array( $terms ) || empty( $terms ) ) {
			return null;
		}

		$primary = (int) get_post_meta( absint( $id ), '_yoast_wpseo_primary_mv_service_cat', true );

		foreach ( $terms as $term ) {
			if ( $term->term_id === $primary ) {
				return $term;
			}
		}

		return reset( $terms );
	}
}

if ( ! function_exists( 'mvweb_core_related_services' ) ) {
	/**
	 * The services standing next to one: the others of its section.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id    Service id.
	 * @param int $limit How many at most; 0 takes the setting of the page.
	 *
	 * @return int[]
	 */
	function mvweb_core_related_services( $id, $limit = 0 ) {
		$id    = absint( $id );
		$limit = $limit > 0 ? absint( $limit ) : absint( mvweb_core_services_pages_option( 'mvweb_service_related_count' ) );
		$term  = mvweb_core_service_primary_term( $id );

		if ( 0 === $limit || null === $term ) {
			return array();
		}

		return array_slice( array_values( array_diff( mvweb_core_service_ids( $term->term_id, true ), array( $id ) ) ), 0, $limit );
	}
}

if ( ! function_exists( 'mvweb_core_service_messengers' ) ) {
	/**
	 * The chats offered in the side card of a service, each with its first message.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Service id.
	 *
	 * @return array<string,array{url:string,label:string,icon:string}> Network id => link.
	 */
	function mvweb_core_service_messengers( $id ) {
		$chosen = json_decode( (string) mvweb_core_services_pages_option( 'mvweb_service_messengers' ), true );
		$chosen = is_array( $chosen ) ? array_map( 'sanitize_key', $chosen ) : array();
		$chats  = array_intersect_key( mvweb_cz_profile_chats(), array_flip( $chosen ) );
		$text   = trim( (string) mvweb_core_services_pages_option( 'mvweb_service_message' ) );
		$links  = array();

		if ( '' !== $text ) {
			$text = str_replace( '{service}', get_the_title( absint( $id ) ), $text );
		}

		foreach ( $chats as $network => $chat ) {
			$url = (string) $chat['url'];

			if ( '' !== $text && in_array( $network, array( 'telegram', 'whatsapp' ), true ) ) {
				$url = add_query_arg( 'text', rawurlencode( $text ), $url );
			}

			$links[ $network ] = array(
				'url'   => $url,
				'label' => (string) $chat['label'],
				'icon'  => mvweb_core_social_icon( $network ),
			);
		}

		return $links;
	}
}

if ( ! function_exists( 'mvweb_core_services_pages_styles' ) ) {
	/**
	 * Load the sheets of the cards a service page prints under its text.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Keys of the request.
	 *
	 * @return string[]
	 */
	function mvweb_core_services_pages_styles( $styles ) {
		if ( ! mvweb_core_is_service() ) {
			return $styles;
		}

		$id   = get_queried_object_id();
		$more = array();

		if ( ! empty( mvweb_core_related_services( $id ) ) ) {
			$more[] = 'catalog';
		}

		if ( absint( mvweb_core_services_pages_option( 'mvweb_service_works_count' ) ) > 0 && ! empty( mvweb_core_works( array( 'service' => $id ) ) ) ) {
			$more[] = 'catalog';
			$more[] = 'works';
		}

		$more = array_values( array_diff( array_unique( $more ), $styles ) );
		$at   = array_search( 'service', $styles, true );

		array_splice( $styles, false === $at ? count( $styles ) : $at, 0, $more );

		return $styles;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_core_services_pages_styles', 20 );
