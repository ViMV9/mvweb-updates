<?php
/**
 * Pages of the portfolio: the listing, a kind of works and a work.
 *
 * What these pages print and a theme cannot decide alone lives here: the
 * settings of the Customizer, the second description of a kind, the source of
 * a review, the works that go under a work and the parts of a page a template
 * has printed. The markup stays in the theme.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_works_defaults' ) ) {
	/**
	 * Values of the portfolio settings that nobody has changed.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_works_defaults() {
		return array(
			'mvweb_work_list_lead'     => '',
			'mvweb_work_kinds_nav'     => true,
			'mvweb_work_card_facts'    => 3,
			'mvweb_work_cta_text'      => __( 'Book the same', 'mvweb-core' ),
			'mvweb_work_ba_kicker'     => __( 'Result', 'mvweb-core' ),
			'mvweb_work_ba_title'      => __( 'Before and after', 'mvweb-core' ),
			'mvweb_work_ba_text'       => __( 'Move the slider to compare the result with the original state.', 'mvweb-core' ),
			'mvweb_work_related_title' => __( 'Other works', 'mvweb-core' ),
			'mvweb_work_related_link'  => __( 'All works', 'mvweb-core' ),
			'mvweb_work_related_count' => 3,
		);
	}
}

if ( ! function_exists( 'mvweb_core_works_option' ) ) {
	/**
	 * A portfolio setting.
	 *
	 * @since 0.1.0
	 *
	 * @param string $key Setting name.
	 *
	 * @return mixed The saved value, the default while nothing is saved.
	 */
	function mvweb_core_works_option( $key ) {
		$defaults = mvweb_core_works_defaults();

		return get_theme_mod( $key, isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
	}
}

if ( ! function_exists( 'mvweb_core_works_tree' ) ) {
	/**
	 * A section of its own for the page of a work.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_works_tree( $tree ) {
		if ( isset( $tree['mvweb_cz_services']['sections'] ) ) {
			$tree['mvweb_cz_services']['sections']['mvweb_cz_services_work'] = __( 'Work page', 'mvweb-core' );
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_works_tree', 97 );

if ( ! function_exists( 'mvweb_core_works_fields' ) ) {
	/**
	 * Fields of the portfolio listing and of the page of a work.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_works_fields() {
		$defaults = mvweb_core_works_defaults();

		return array(
			array(
				'type'        => 'textarea',
				'settings'    => 'mvweb_work_list_lead',
				'section'     => 'mvweb_cz_services_works',
				'label'       => __( 'Text under the heading of the portfolio', 'mvweb-core' ),
				'description' => __( 'A kind of works takes its own description instead.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_work_list_lead'],
			),
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_work_kinds_nav',
				'section'     => 'mvweb_cz_services_works',
				'label'       => __( 'Kinds of work above the cards', 'mvweb-core' ),
				'description' => __( 'A row of links to every kind. It is not printed while there are fewer than two kinds.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_work_kinds_nav'],
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_work_card_facts',
				'section'     => 'mvweb_cz_services_works',
				'label'       => __( 'Facts on a card', 'mvweb-core' ),
				'description' => __( 'How many of the first facts of a work its card shows. 0 shows none.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_work_card_facts'],
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 6,
					'step' => 1,
				),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_work_cta_text',
				'section'     => 'mvweb_cz_services_work',
				'label'       => __( 'Button on the page of a work', 'mvweb-core' ),
				'description' => __( 'Empty takes the label of the button of the site. The link is the one set in Conversion.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_work_cta_text'],
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_work_ba_kicker',
				'section'  => 'mvweb_cz_services_work',
				'label'    => __( 'Before and after: line above the heading', 'mvweb-core' ),
				'default'  => $defaults['mvweb_work_ba_kicker'],
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_work_ba_title',
				'section'  => 'mvweb_cz_services_work',
				'label'    => __( 'Before and after: heading', 'mvweb-core' ),
				'default'  => $defaults['mvweb_work_ba_title'],
			),
			array(
				'type'     => 'textarea',
				'settings' => 'mvweb_work_ba_text',
				'section'  => 'mvweb_cz_services_work',
				'label'    => __( 'Before and after: text under the heading', 'mvweb-core' ),
				'default'  => $defaults['mvweb_work_ba_text'],
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_work_related_title',
				'section'  => 'mvweb_cz_services_work',
				'label'    => __( 'Other works: heading', 'mvweb-core' ),
				'default'  => $defaults['mvweb_work_related_title'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_work_related_link',
				'section'     => 'mvweb_cz_services_work',
				'label'       => __( 'Other works: link to the portfolio', 'mvweb-core' ),
				'description' => __( 'Empty hides the link.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_work_related_link'],
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_work_related_count',
				'section'     => 'mvweb_cz_services_work',
				'label'       => __( 'Other works: how many', 'mvweb-core' ),
				'description' => __( 'Works of the same service come first, the rest of the portfolio fills the gap.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_work_related_count'],
				'input_attrs' => array(
					'min'  => 1,
					'max'  => 12,
					'step' => 1,
				),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_works_register_fields' ) ) {
	/**
	 * Hand the fields to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_works_register_fields( $kit ) {
		$kit->add_fields( mvweb_core_works_fields() );
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_works_register_fields' );

if ( ! function_exists( 'mvweb_core_works_register_meta' ) ) {
	/**
	 * Register what the portfolio keeps beyond the core: the text under a kind and the source of a review.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_works_register_meta() {
		register_term_meta(
			'mv_work_type',
			'mvweb_text',
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => 'wp_kses_post',
				'auth_callback'     => 'mvweb_core_term_meta_auth',
				'show_in_rest'      => false,
			)
		);

		register_post_meta(
			'mv_work',
			'_mvweb_review_source',
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => 'mvweb_core_post_meta_auth',
				'show_in_rest'      => false,
			)
		);

		add_action( 'mv_work_type_edit_form_fields', 'mvweb_core_term_text_field' );
		add_action( 'edited_mv_work_type', 'mvweb_core_term_text_save' );
	}
}
add_action( 'init', 'mvweb_core_works_register_meta', 31 );

if ( ! function_exists( 'mvweb_core_works_meta_boxes' ) ) {
	/**
	 * Add the box of the source of a review to the work screen.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_works_meta_boxes() {
		add_meta_box( 'mvweb-core-work-review-source', __( 'Where the review is from', 'mvweb-core' ), 'mvweb_core_work_review_source_box', 'mv_work', 'normal', 'default' );
	}
}
add_action( 'add_meta_boxes', 'mvweb_core_works_meta_boxes' );

if ( ! function_exists( 'mvweb_core_work_review_source_box' ) ) {
	/**
	 * The field of the source of a review.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Post being edited.
	 *
	 * @return void
	 */
	function mvweb_core_work_review_source_box( $post ) {
		wp_nonce_field( 'mvweb_work_review_source', 'mvweb_work_review_source_nonce' );
		?>
		<p class="mvweb-core-field">
			<label for="mvweb-core-review-source"><?php esc_html_e( 'Source', 'mvweb-core' ); ?></label>
			<input class="widefat" type="text" id="mvweb-core-review-source" name="mvweb_review_source" value="<?php echo esc_attr( (string) get_post_meta( $post->ID, '_mvweb_review_source', true ) ); ?>">
			<span class="description"><?php esc_html_e( 'For example: Review from Yandex Maps. Printed under the name of the client.', 'mvweb-core' ); ?></span>
		</p>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_work_review_source_save' ) ) {
	/**
	 * Store the source of a review.
	 *
	 * @since 0.1.0
	 *
	 * @param int     $post_id Post being saved.
	 * @param WP_Post $post    Post object.
	 *
	 * @return void
	 */
	function mvweb_core_work_review_source_save( $post_id, $post ) {
		if ( 'mv_work' !== $post->post_type || wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST['mvweb_work_review_source_nonce'], $_POST['mvweb_review_source'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mvweb_work_review_source_nonce'] ) ), 'mvweb_work_review_source' ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		update_post_meta( $post_id, '_mvweb_review_source', sanitize_text_field( wp_unslash( $_POST['mvweb_review_source'] ) ) );
	}
}
add_action( 'save_post', 'mvweb_core_work_review_source_save', 10, 2 );

if ( ! function_exists( 'mvweb_core_works_kinds' ) ) {
	/**
	 * The kinds of work the row above the cards links to.
	 *
	 * @since 0.1.0
	 *
	 * @return WP_Term[] Empty while the row is switched off or there are fewer than two kinds.
	 */
	function mvweb_core_works_kinds() {
		if ( ! mvweb_core_works_option( 'mvweb_work_kinds_nav' ) ) {
			return array();
		}

		$kinds = get_terms(
			array(
				'taxonomy'   => 'mv_work_type',
				'hide_empty' => true,
			)
		);

		return is_array( $kinds ) && count( $kinds ) > 1 ? array_values( $kinds ) : array();
	}
}

if ( ! function_exists( 'mvweb_core_works_listing_lead' ) ) {
	/**
	 * The plain text under the heading of the portfolio or of a kind.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_works_listing_lead() {
		if ( is_paged() ) {
			return '';
		}

		$term = get_queried_object();

		if ( $term instanceof WP_Term ) {
			return trim( wp_strip_all_tags( term_description( $term ) ) );
		}

		return trim( (string) mvweb_core_works_option( 'mvweb_work_list_lead' ) );
	}
}

if ( ! function_exists( 'mvweb_core_work_cta' ) ) {
	/**
	 * The request button of the page of a work.
	 *
	 * @since 0.1.0
	 *
	 * @return array{text:string,url:string} Empty while the site has no address for the button.
	 */
	function mvweb_core_work_cta() {
		$text = trim( (string) mvweb_core_works_option( 'mvweb_work_cta_text' ) );
		$text = '' !== $text ? $text : trim( (string) get_theme_mod( 'mvweb_cta_text', __( 'Request a quote', 'mvweb-core' ) ) );
		$url  = trim( (string) get_theme_mod( 'mvweb_cta_url', '' ) );

		return '' === $text || '' === $url ? array() : array(
			'text' => $text,
			'url'  => $url,
		);
	}
}

if ( ! function_exists( 'mvweb_core_work_related' ) ) {
	/**
	 * The works that go under a work: those of its service, else the rest of the portfolio.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Work id.
	 *
	 * @return int[]
	 */
	function mvweb_core_work_related( $id ) {
		$id      = absint( $id );
		$count   = max( 1, absint( mvweb_core_works_option( 'mvweb_work_related_count' ) ) );
		$service = mvweb_core_sanitize_service_id( get_post_meta( $id, '_mvweb_work_service', true ) );
		$others  = mvweb_core_works(
			array(
				'count'   => $count,
				'service' => $service,
				'exclude' => $id,
			)
		);

		if ( count( $others ) < $count && $service ) {
			$others = mvweb_core_works(
				array(
					'count'   => $count,
					'exclude' => $id,
				)
			);
		}

		return $others;
	}
}

if ( ! function_exists( 'mvweb_core_work_pair' ) ) {
	/**
	 * The before and after block of a work.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Work id.
	 *
	 * @return array<string,mixed> Properties of the block, empty when the work lacks one of the two photos.
	 */
	function mvweb_core_work_pair( $id ) {
		$id     = absint( $id );
		$before = absint( get_post_meta( $id, '_mvweb_before', true ) );
		$after  = absint( get_post_meta( $id, '_mvweb_after', true ) );
		$cta    = mvweb_core_work_cta();

		if ( ! wp_attachment_is_image( $before ) || ! wp_attachment_is_image( $after ) ) {
			return array();
		}

		return array(
			'kicker'      => (string) mvweb_core_works_option( 'mvweb_work_ba_kicker' ),
			'title'       => (string) mvweb_core_works_option( 'mvweb_work_ba_title' ),
			'text'        => (string) mvweb_core_works_option( 'mvweb_work_ba_text' ),
			'button_text' => isset( $cta['text'] ) ? $cta['text'] : '',
			'button_url'  => isset( $cta['url'] ) ? $cta['url'] : '',
			'pairs'       => array(
				array(
					'before' => $before,
					'after'  => $after,
					'title'  => get_the_title( $id ),
					'text'   => (string) get_post_meta( $id, '_mvweb_result', true ),
				),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_works_layout_html' ) ) {
	/**
	 * Print the parts of a layout one by one and keep what each printed.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area name.
	 * @param array  $args Arguments passed to every part template.
	 *
	 * @return array<string,string> Part slug => markup, in the order of the area, empty parts left out.
	 */
	function mvweb_core_works_layout_html( $area, array $args = array() ) {
		$area = mvweb_core_layout_area( $area );
		$html = array();

		foreach ( mvweb_core_layout_order( $area ) as $slug ) {
			$part = sanitize_key( $slug );

			if ( '' === $part || 0 !== validate_file( 'template-parts/' . $area . '/' . $part ) ) {
				continue;
			}

			ob_start();
			get_template_part( 'template-parts/' . $area . '/' . $part, null, array_merge( $args, array( 'area' => $area ) ) );
			$markup = trim( (string) ob_get_clean() );

			if ( '' !== $markup ) {
				$html[ $part ] = $markup;
			}
		}

		return $html;
	}
}

if ( ! function_exists( 'mvweb_core_works_style_map' ) ) {
	/**
	 * The text under the cards of a kind is set in the rules of an article.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Handles without the theme prefix.
	 *
	 * @return string[]
	 */
	function mvweb_core_works_style_map( $styles ) {
		if ( is_tax( 'mv_work_type' ) && '' !== mvweb_core_listing_text() ) {
			$styles[] = 'article';
		}

		return $styles;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_core_works_style_map' );
