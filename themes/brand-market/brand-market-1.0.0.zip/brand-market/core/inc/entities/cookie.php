<?php
/**
 * The notice about cookies.
 *
 * It shows on the first visit and is silent for thirty days after the visitor
 * accepts it. The notice is printed right after the opening body tag, so it is
 * the first stop of the keyboard, while the theme places it on the screen
 * without pushing the page. A script takes the notice out of hiding when the
 * cookie of consent is missing, which keeps the page the same for everyone and
 * safe to cache.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_cookie_tree' ) ) {
	/**
	 * A section of its own in the panel of codes.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_cookie_tree( $tree ) {
		if ( isset( $tree['mvweb_cz_codes']['sections'] ) ) {
			$tree['mvweb_cz_codes']['sections']['mvweb_cz_codes_cookie'] = __( 'Cookie notice', 'mvweb-core' );
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_cookie_tree', 98 );

if ( ! function_exists( 'mvweb_core_cookie_defaults' ) ) {
	/**
	 * Values of the settings that nobody has changed.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_cookie_defaults() {
		return array(
			'mvweb_cookie_on'           => false,
			'mvweb_cookie_text'         => __( 'This site uses cookies. By staying on the site you agree to their use.', 'mvweb-core' ),
			'mvweb_cookie_button'       => __( 'Accept', 'mvweb-core' ),
			'mvweb_cookie_policy_url'   => '',
			'mvweb_cookie_policy_label' => __( 'Privacy policy', 'mvweb-core' ),
			'mvweb_cookie_position'     => 'bar',
			'mvweb_cookie_color'        => 'surface',
		);
	}
}

if ( ! function_exists( 'mvweb_core_cookie_option' ) ) {
	/**
	 * A setting of the notice.
	 *
	 * @since 0.1.0
	 *
	 * @param string $key Setting name.
	 *
	 * @return mixed The saved value, the default while nothing is saved.
	 */
	function mvweb_core_cookie_option( $key ) {
		$defaults = mvweb_core_cookie_defaults();

		return get_theme_mod( $key, isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
	}
}

if ( ! function_exists( 'mvweb_core_cookie_name' ) ) {
	/**
	 * The name of the cookie that remembers the consent.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_cookie_name() {
		return 'mvweb_cookie_ok';
	}
}

if ( ! function_exists( 'mvweb_core_cookie_days' ) ) {
	/**
	 * How long the consent is remembered.
	 *
	 * @since 0.1.0
	 *
	 * @return int
	 */
	function mvweb_core_cookie_days() {
		return 30;
	}
}

if ( ! function_exists( 'mvweb_core_cookie_policy' ) ) {
	/**
	 * The page of the privacy policy and its label.
	 *
	 * @since 0.1.0
	 *
	 * @return array{url:string,label:string} Empty while there is no page to link.
	 */
	function mvweb_core_cookie_policy() {
		$url   = trim( (string) mvweb_core_cookie_option( 'mvweb_cookie_policy_url' ) );
		$url   = '' !== $url ? $url : (string) get_privacy_policy_url();
		$label = trim( (string) mvweb_core_cookie_option( 'mvweb_cookie_policy_label' ) );

		return '' === $url || '' === $label ? array() : array(
			'url'   => $url,
			'label' => $label,
		);
	}
}

if ( ! function_exists( 'mvweb_core_cookie_overlap' ) ) {
	/**
	 * Whether MVweb Site Optimizer prints a notice of its own.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_cookie_overlap() {
		return function_exists( 'mvweb_so_check_option' ) && mvweb_so_check_option( 'message_cookie' );
	}
}

if ( ! function_exists( 'mvweb_core_cookie_fields' ) ) {
	/**
	 * Fields of the notice.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_cookie_fields() {
		$defaults = mvweb_core_cookie_defaults();
		$section  = 'mvweb_cz_codes_cookie';
		$on       = array(
			array(
				'setting'  => 'mvweb_cookie_on',
				'operator' => '==',
				'value'    => true,
			),
		);
		$custom   = array(
			array(
				'setting'  => 'mvweb_cookie_on',
				'operator' => '==',
				'value'    => true,
			),
			array(
				'setting'  => 'mvweb_cookie_color',
				'operator' => '==',
				'value'    => 'custom',
			),
		);
		$fields   = array();

		if ( mvweb_core_cookie_overlap() ) {
			$fields[] = array(
				'type'        => 'heading',
				'section'     => $section,
				'label'       => __( 'MVweb Site Optimizer also shows a cookie notice', 'mvweb-core' ),
				'description' => __( 'Two notices on one page are too many: keep one of them.', 'mvweb-core' ),
				'priority'    => 1,
			);
		}

		$fields[] = array(
			'type'        => 'toggle',
			'settings'    => 'mvweb_cookie_on',
			'section'     => $section,
			'label'       => __( 'Show the cookie notice', 'mvweb-core' ),
			'description' => __( 'It appears on the first visit and does not come back for 30 days after the visitor accepts it.', 'mvweb-core' ),
			'default'     => $defaults['mvweb_cookie_on'],
		);
		$fields[] = array(
			'type'     => 'textarea',
			'settings' => 'mvweb_cookie_text',
			'section'  => $section,
			'label'    => __( 'Text of the notice', 'mvweb-core' ),
			'default'  => $defaults['mvweb_cookie_text'],
			'required' => $on,
		);
		$fields[] = array(
			'type'     => 'text',
			'settings' => 'mvweb_cookie_button',
			'section'  => $section,
			'label'    => __( 'Text of the button', 'mvweb-core' ),
			'default'  => $defaults['mvweb_cookie_button'],
			'required' => $on,
		);
		$fields[] = array(
			'type'        => 'url',
			'settings'    => 'mvweb_cookie_policy_url',
			'section'     => $section,
			'label'       => __( 'Page of the privacy policy', 'mvweb-core' ),
			'description' => __( 'Empty takes the page chosen in Settings, Privacy.', 'mvweb-core' ),
			'default'     => $defaults['mvweb_cookie_policy_url'],
			'required'    => $on,
		);
		$fields[] = array(
			'type'        => 'text',
			'settings'    => 'mvweb_cookie_policy_label',
			'section'     => $section,
			'label'       => __( 'Label of the policy link', 'mvweb-core' ),
			'description' => __( 'Empty hides the link.', 'mvweb-core' ),
			'default'     => $defaults['mvweb_cookie_policy_label'],
			'required'    => $on,
		);
		$fields[] = array(
			'type'     => 'radio',
			'settings' => 'mvweb_cookie_position',
			'section'  => $section,
			'label'    => __( 'Place', 'mvweb-core' ),
			'default'  => $defaults['mvweb_cookie_position'],
			'choices'  => array(
				'bar'   => __( 'Bar along the bottom', 'mvweb-core' ),
				'left'  => __( 'Card at the bottom left', 'mvweb-core' ),
				'right' => __( 'Card at the bottom right', 'mvweb-core' ),
			),
			'required' => $on,
		);
		$fields[] = array(
			'type'     => 'select',
			'settings' => 'mvweb_cookie_color',
			'section'  => $section,
			'label'    => __( 'Colour', 'mvweb-core' ),
			'default'  => $defaults['mvweb_cookie_color'],
			'choices'  => array(
				'plain'   => __( 'Page background', 'mvweb-core' ),
				'surface' => __( 'Tinted', 'mvweb-core' ),
				'accent'  => __( 'Accent colour', 'mvweb-core' ),
				'inverse' => __( 'Inverse, dark', 'mvweb-core' ),
				'custom'  => __( 'Own colours', 'mvweb-core' ),
			),
			'required' => $on,
		);

		$pairs = array(
			'mvweb_cookie_bg'       => __( 'Background colour', 'mvweb-core' ),
			'mvweb_cookie_ink'      => __( 'Text colour', 'mvweb-core' ),
			'mvweb_cookie_bg_dark'  => __( 'Background colour, dark scheme', 'mvweb-core' ),
			'mvweb_cookie_ink_dark' => __( 'Text colour, dark scheme', 'mvweb-core' ),
		);

		foreach ( $pairs as $setting => $label ) {
			$field = array(
				'type'     => 'color',
				'settings' => $setting,
				'section'  => $section,
				'label'    => $label,
				'default'  => '',
				'required' => $custom,
			);

			if ( 'mvweb_cookie_ink' === $setting ) {
				$field['description'] = __( 'Empty text colour is picked by itself, black or white. A colour that cannot be read on the background is replaced. The dark scheme keeps the light colours until its own are set.', 'mvweb-core' );
			}

			$fields[] = $field;
		}

		return $fields;
	}
}

if ( ! function_exists( 'mvweb_core_cookie_register_fields' ) ) {
	/**
	 * Hand the fields to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_cookie_register_fields( $kit ) {
		$kit->add_fields( mvweb_core_cookie_fields() );
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_cookie_register_fields' );

if ( ! function_exists( 'mvweb_core_cookie_enabled' ) ) {
	/**
	 * Whether the request should carry the notice.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_cookie_enabled() {
		return ! is_admin() && ! is_feed() && (bool) mvweb_core_cookie_option( 'mvweb_cookie_on' );
	}
}

if ( ! function_exists( 'mvweb_core_cookie_args' ) ) {
	/**
	 * What the template of the notice prints.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_cookie_args() {
		$position = (string) mvweb_core_cookie_option( 'mvweb_cookie_position' );
		$look     = mvweb_core_section_look(
			array(
				'background'     => (string) mvweb_core_cookie_option( 'mvweb_cookie_color' ),
				'bg_color'       => (string) get_theme_mod( 'mvweb_cookie_bg', '' ),
				'ink_color'      => (string) get_theme_mod( 'mvweb_cookie_ink', '' ),
				'bg_color_dark'  => (string) get_theme_mod( 'mvweb_cookie_bg_dark', '' ),
				'ink_color_dark' => (string) get_theme_mod( 'mvweb_cookie_ink_dark', '' ),
			)
		);

		return array(
			'text'       => trim( (string) mvweb_core_cookie_option( 'mvweb_cookie_text' ) ),
			'button'     => trim( (string) mvweb_core_cookie_option( 'mvweb_cookie_button' ) ),
			'policy'     => mvweb_core_cookie_policy(),
			'position'   => in_array( $position, array( 'bar', 'left', 'right' ), true ) ? $position : 'bar',
			'background' => $look['background'],
			'style'      => $look['style'],
			'name'       => mvweb_core_cookie_name(),
			'days'       => mvweb_core_cookie_days(),
			'preview'    => is_customize_preview(),
		);
	}
}

if ( ! function_exists( 'mvweb_core_cookie_print' ) ) {
	/**
	 * Print the notice right after the opening body tag.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_cookie_print() {
		if ( ! mvweb_core_cookie_enabled() ) {
			return;
		}

		$args = mvweb_core_cookie_args();

		if ( '' === $args['text'] && '' === $args['button'] ) {
			return;
		}

		get_template_part( 'template-parts/cookie', null, $args );
	}
}
add_action( 'wp_body_open', 'mvweb_core_cookie_print', 20 );

if ( ! function_exists( 'mvweb_core_cookie_styles' ) ) {
	/**
	 * Add the stylesheet of the notice to the pages that carry it.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Handles without the theme prefix.
	 *
	 * @return string[]
	 */
	function mvweb_core_cookie_styles( $styles ) {
		if ( mvweb_core_cookie_enabled() ) {
			$styles[] = 'cookie';
		}

		return $styles;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_core_cookie_styles' );

if ( ! function_exists( 'mvweb_core_cookie_modules' ) ) {
	/**
	 * Add the script of the notice to the pages that carry it.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules File names without extension, from assets/js/.
	 *
	 * @return string[]
	 */
	function mvweb_core_cookie_modules( $modules ) {
		if ( mvweb_core_cookie_enabled() ) {
			$modules[] = 'cookie';
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_core_cookie_modules' );
