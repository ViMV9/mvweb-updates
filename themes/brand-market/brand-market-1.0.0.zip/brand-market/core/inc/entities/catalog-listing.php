<?php
/**
 * Catalogue listings: the shop, a category, a filter page, the archive of the own catalogue.
 *
 * What the listing templates ask for beyond the catalogue core: the head of the
 * page (lead, chips of the filter pages), the tiles of the subcategories, the
 * groups of the sidebar for the brand and the availability, the counts beside
 * the values, the chips of the chosen filters and the settings that go with them.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_listing_ordering_choices' ) ) {
	/**
	 * The orders a listing can offer besides the default one.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Order key => label, in the order the select prints them.
	 */
	function mvweb_core_listing_ordering_choices() {
		return array(
			'popularity' => __( 'By popularity', 'mvweb-core' ),
			'price'      => __( 'Price: low to high', 'mvweb-core' ),
			'price-desc' => __( 'Price: high to low', 'mvweb-core' ),
			'date'       => __( 'Newest first', 'mvweb-core' ),
			'rating'     => __( 'By rating', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_listing_fields' ) ) {
	/**
	 * Customizer fields of the listing.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_listing_fields() {
		$choices = mvweb_core_listing_ordering_choices();
		$fields  = array(
			array(
				'type'        => 'radio',
				'settings'    => 'mvweb_catalog_columns',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'Items in a row', 'mvweb-core' ),
				'description' => __( 'For the cards on a computer. Narrower screens show 3 items in a row, phones 2; with 5 a row keeps 4 on screens up to 1260 px.', 'mvweb-core' ),
				'default'     => '3',
				'choices'     => array(
					'3' => '3',
					'4' => '4',
					'5' => '5',
				),
			),
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_catalog_subcats',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'Tiles of the subcategories', 'mvweb-core' ),
				'description' => __( 'Under the head of the catalogue and of a category: the sections inside, with a picture and the number of items.', 'mvweb-core' ),
				'default'     => true,
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_listing_chips',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'Filter pages in the head of a category', 'mvweb-core' ),
				'description' => __( 'How many filter pages of the category are offered as chips under its heading. 0 shows none.', 'mvweb-core' ),
				'default'     => 8,
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 24,
					'step' => 1,
				),
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_filter_visible',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'Values shown in a filter group', 'mvweb-core' ),
				'description' => __( 'The rest opens with “Show all”. 0 shows every value at once.', 'mvweb-core' ),
				'default'     => 6,
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 50,
					'step' => 1,
				),
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_filter_open',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'Filter groups open at first', 'mvweb-core' ),
				'description' => __( 'A group with a chosen value is always open. 0 opens only those.', 'mvweb-core' ),
				'default'     => 3,
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 12,
					'step' => 1,
				),
			),
			array(
				'type'        => 'multicheck',
				'settings'    => 'mvweb_catalog_orderings',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'Orders in the sorting', 'mvweb-core' ),
				'description' => __( 'The default order is always there. By popularity and by rating work with WooCommerce only.', 'mvweb-core' ),
				'choices'     => $choices,
				'default'     => wp_json_encode( array_keys( $choices ) ),
			),
		);

		if ( ! mvweb_core_is_woocommerce() ) {
			$fields[] = array(
				'type'        => 'textarea',
				'settings'    => 'mvweb_catalog_lead',
				'section'     => 'mvweb_cz_catalog_archive',
				'label'       => __( 'Text under the heading of the catalogue', 'mvweb-core' ),
				'description' => __( 'One or two sentences on the archive page. Under WooCommerce this is the excerpt of the shop page.', 'mvweb-core' ),
			);
		}

		return $fields;
	}
}

if ( ! function_exists( 'mvweb_core_listing_register' ) ) {
	/**
	 * Hand the fields to the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_listing_register( $kit ) {
		$kit->add_fields( mvweb_core_listing_fields() );
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_listing_register' );

if ( ! function_exists( 'mvweb_core_listing_orderings' ) ) {
	/**
	 * Keep the orders the owner ticked, in the order of the wireframe.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $orderings Order key => label.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_listing_orderings( $orderings ) {
		$saved = json_decode( (string) get_theme_mod( 'mvweb_catalog_orderings', '' ), true );

		if ( ! is_array( $saved ) ) {
			$saved = array_keys( mvweb_core_listing_ordering_choices() );
		}

		$kept = array();

		if ( isset( $orderings['menu_order'] ) ) {
			$kept['menu_order'] = $orderings['menu_order'];
		}

		foreach ( array_keys( mvweb_core_listing_ordering_choices() ) as $key ) {
			if ( isset( $orderings[ $key ] ) && in_array( $key, $saved, true ) ) {
				$kept[ $key ] = $orderings[ $key ];
			}
		}

		return $kept;
	}
}
add_filter( 'mvweb_core_catalog_orderings', 'mvweb_core_listing_orderings', 20 );

if ( ! function_exists( 'mvweb_core_listing_modules' ) ) {
	/**
	 * Load the script of the listing where a listing is shown.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules File names without extension.
	 *
	 * @return string[]
	 */
	function mvweb_core_listing_modules( $modules ) {
		if ( mvweb_core_is_catalog() ) {
			$modules[] = 'catalog-listing';
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_core_listing_modules' );

if ( ! function_exists( 'mvweb_core_listing_currency' ) ) {
	/**
	 * The currency sign of the store.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_listing_currency() {
		if ( mvweb_core_is_woocommerce() && function_exists( 'get_woocommerce_currency_symbol' ) ) {
			return html_entity_decode( get_woocommerce_currency_symbol(), ENT_QUOTES, 'UTF-8' );
		}

		return trim( (string) mvweb_core_option( 'mvweb_currency' ) );
	}
}

if ( ! function_exists( 'mvweb_core_listing_group' ) ) {
	/**
	 * Open a wrapper for the parts that follow, closing the one that is open.
	 *
	 * @since 0.1.0
	 *
	 * @param array  $args  Arguments of the area, holding the shared state.
	 * @param string $wrapper Class of the wrapper, empty to close.
	 *
	 * @return bool Whether the wrapper was opened just now.
	 */
	function mvweb_core_listing_group( array $args, $wrapper ) {
		if ( ! isset( $args['state'] ) || ! $args['state'] instanceof ArrayObject ) {
			return false;
		}

		$open = (string) $args['state']['group'];

		if ( $open === $wrapper ) {
			return false;
		}

		if ( '' !== $open ) {
			echo '</div>';
		}

		$args['state']['group'] = $wrapper;

		if ( '' !== $wrapper ) {
			echo '<div class="' . esc_attr( $wrapper ) . '">';
		}

		return '' !== $wrapper;
	}
}

if ( ! function_exists( 'mvweb_core_listing_stock_selected' ) ) {
	/**
	 * The availability values the address asks for.
	 *
	 * @since 0.1.0
	 *
	 * @return string[] in, sale.
	 */
	function mvweb_core_listing_stock_selected() {
		if ( ! mvweb_core_is_woocommerce() ) {
			return array();
		}

		return array_values( array_intersect( array( 'in', 'sale' ), mvweb_core_catalog_requested( 'stock' ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_listing_filtered' ) ) {
	/**
	 * Whether the visitor narrowed the listing, the brand and the availability included.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_listing_filtered() {
		return mvweb_core_catalog_is_filtered() || ! empty( mvweb_core_catalog_requested( 'brand' ) ) || ! empty( mvweb_core_listing_stock_selected() );
	}
}

if ( ! function_exists( 'mvweb_core_listing_tree' ) ) {
	/**
	 * The term taxonomy ids of a term and of everything below it.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Term.
	 *
	 * @return int[]
	 */
	function mvweb_core_listing_tree( $term ) {
		$below = get_terms(
			array(
				'taxonomy'   => $term->taxonomy,
				'child_of'   => $term->term_id,
				'hide_empty' => false,
				'fields'     => 'tt_ids',
			)
		);

		return array_merge( array( (int) $term->term_taxonomy_id ), is_wp_error( $below ) ? array() : array_map( 'intval', $below ) );
	}
}

if ( ! function_exists( 'mvweb_core_listing_branch' ) ) {
	/**
	 * The term taxonomy ids the listing is limited to, null for the whole catalogue.
	 *
	 * @since 0.1.0
	 *
	 * @return int[]|null
	 */
	function mvweb_core_listing_branch() {
		$current = get_queried_object();

		if ( ! $current instanceof WP_Term || ! mvweb_core_is_catalog_term( $current ) ) {
			return null;
		}

		return mvweb_core_listing_tree( $current );
	}
}

if ( ! function_exists( 'mvweb_core_listing_counts' ) ) {
	/**
	 * How many published items each term holds inside the listing.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,int[]> $sets Key => term taxonomy ids that count for the key.
	 * @param bool             $limit Whether to stay inside the category being shown.
	 *
	 * @return array<int,int> Key => number of items.
	 */
	function mvweb_core_listing_counts( array $sets, $limit = true ) {
		global $wpdb;

		$branch = $limit ? mvweb_core_listing_branch() : null;
		$counts = array();

		foreach ( $sets as $key => $ids ) {
			$counts[ $key ] = 0;
		}

		$all = array_values( array_unique( array_map( 'absint', array_merge( array(), ...array_values( $sets ) ) ) ) );

		if ( empty( $all ) || ( null !== $branch && empty( $branch ) ) ) {
			return $counts;
		}

		$join = null === $branch ? '' : ' INNER JOIN ' . $wpdb->term_relationships . ' b ON b.object_id = r.object_id AND b.term_taxonomy_id IN (' . implode( ',', array_map( 'absint', $branch ) ) . ')';
		$sql  = 'SELECT r.term_taxonomy_id AS tt, r.object_id AS item FROM ' . $wpdb->term_relationships . ' r INNER JOIN ' . $wpdb->posts . ' p ON p.ID = r.object_id AND p.post_status = %s AND p.post_type = %s' . $join . ' WHERE r.term_taxonomy_id IN (' . implode( ',', $all ) . ') GROUP BY r.term_taxonomy_id, r.object_id';
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, 'publish', mvweb_core_post_type() ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Only table names and integers are joined into the text; the values go through prepare().

		$found = array();

		foreach ( (array) $rows as $row ) {
			$found[ (int) $row->tt ][ (int) $row->item ] = true;
		}

		foreach ( $sets as $key => $ids ) {
			$items = array();

			foreach ( $ids as $id ) {
				if ( isset( $found[ (int) $id ] ) ) {
					$items += $found[ (int) $id ];
				}
			}

			$counts[ $key ] = count( $items );
		}

		return $counts;
	}
}

if ( ! function_exists( 'mvweb_core_listing_group_counts' ) ) {
	/**
	 * The counts of the values of a sidebar group, by value slug.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $group Group of mvweb_core_catalog_filters().
	 *
	 * @return array<string,int>
	 */
	function mvweb_core_listing_group_counts( array $group ) {
		if ( isset( $group['counts'] ) ) {
			return (array) $group['counts'];
		}

		$sets = array();

		foreach ( $group['terms'] as $term ) {
			if ( ! $term instanceof WP_Term ) {
				continue;
			}

			$sets[ $term->slug ] = 'subcategory' === $group['slug'] ? mvweb_core_listing_tree( $term ) : array( (int) $term->term_taxonomy_id );
		}

		return mvweb_core_listing_counts( $sets, 'subcategory' !== $group['slug'] );
	}
}

if ( ! function_exists( 'mvweb_core_listing_brand_group' ) ) {
	/**
	 * The sidebar group of brands.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_listing_brand_group() {
		global $wpdb;

		foreach ( mvweb_core_properties() as $property ) {
			if ( 'brand' === $property['slug'] ) {
				return null;
			}
		}

		$terms  = array();
		$counts = array();

		if ( mvweb_core_is_woocommerce() ) {
			if ( ! taxonomy_exists( 'product_brand' ) ) {
				return null;
			}

			$args  = array(
				'taxonomy'   => 'product_brand',
				'hide_empty' => true,
			);
			$scope = mvweb_core_catalog_scope();

			if ( is_array( $scope ) ) {
				if ( empty( $scope ) ) {
					return null;
				}

				$args['object_ids'] = $scope;
			}

			$found = get_terms( $args );
			$terms = is_wp_error( $found ) ? array() : $found;
			$sets  = array();

			foreach ( $terms as $term ) {
				$sets[ $term->slug ] = array( (int) $term->term_taxonomy_id );
			}

			$counts = mvweb_core_listing_counts( $sets );
		} else {
			$branch = mvweb_core_listing_branch();

			if ( null !== $branch && empty( $branch ) ) {
				return null;
			}

			$join = null === $branch ? '' : ' INNER JOIN ' . $wpdb->term_relationships . ' b ON b.object_id = p.ID AND b.term_taxonomy_id IN (' . implode( ',', array_map( 'absint', $branch ) ) . ')';
			$sql  = 'SELECT m.meta_value AS name, COUNT(DISTINCT p.ID) AS total FROM ' . $wpdb->postmeta . ' m INNER JOIN ' . $wpdb->posts . ' p ON p.ID = m.post_id AND p.post_status = %s AND p.post_type = %s' . $join . ' WHERE m.meta_key = %s AND m.meta_value <> %s GROUP BY m.meta_value ORDER BY m.meta_value ASC';
			$rows = $wpdb->get_results( $wpdb->prepare( $sql, 'publish', mvweb_core_post_type(), '_mvweb_brand', '' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- Only table names and integers are joined into the text; the values go through prepare().

			foreach ( (array) $rows as $row ) {
				$slug = sanitize_title( $row->name );

				if ( '' === $slug || isset( $counts[ $slug ] ) ) {
					continue;
				}

				$terms[]         = (object) array(
					'name' => (string) $row->name,
					'slug' => $slug,
				);
				$counts[ $slug ] = (int) $row->total;
			}
		}

		if ( empty( $terms ) ) {
			return null;
		}

		return array(
			'slug'     => 'brand',
			'part'     => 'brand',
			'label'    => __( 'Brand', 'mvweb-core' ),
			'terms'    => $terms,
			'counts'   => $counts,
			'selected' => mvweb_core_catalog_requested( 'brand' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_listing_stock_group' ) ) {
	/**
	 * The sidebar group of availability: only what is in stock, only what is on sale.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>|null Null without WooCommerce, which alone keeps stock and sales.
	 */
	function mvweb_core_listing_stock_group() {
		if ( ! mvweb_core_is_woocommerce() ) {
			return null;
		}

		return array(
			'slug'     => 'stock',
			'part'     => 'stock',
			'label'    => __( 'Availability', 'mvweb-core' ),
			'terms'    => array(
				(object) array(
					'name' => __( 'In stock only', 'mvweb-core' ),
					'slug' => 'in',
				),
				(object) array(
					'name' => __( 'On sale', 'mvweb-core' ),
					'slug' => 'sale',
				),
			),
			'counts'   => array(),
			'selected' => mvweb_core_listing_stock_selected(),
		);
	}
}

if ( ! function_exists( 'mvweb_core_listing_groups' ) ) {
	/**
	 * Add the brand and the availability to the property groups and count their values.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $groups Property groups.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_listing_groups( $groups ) {
		static $done = array();

		$key = md5( wp_json_encode( array_map( 'strval', wp_list_pluck( $groups, 'slug' ) ) ) . wp_json_encode( $_GET ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- The key of a cache, not a value in use.

		if ( isset( $done[ $key ] ) ) {
			return $done[ $key ];
		}

		foreach ( $groups as $index => $group ) {
			if ( isset( $group['part'] ) || empty( $group['terms'] ) ) {
				continue;
			}

			$groups[ $index ]['counts'] = mvweb_core_listing_group_counts( $group );
		}

		$brand = mvweb_core_listing_brand_group();
		$stock = mvweb_core_listing_stock_group();

		if ( null !== $brand ) {
			$groups[] = $brand;
		}

		if ( null !== $stock ) {
			$groups[] = $stock;
		}

		$done[ $key ] = $groups;

		return $groups;
	}
}
add_filter( 'mvweb_core_catalog_filters', 'mvweb_core_listing_groups', 20 );

if ( ! function_exists( 'mvweb_core_listing_value_url' ) ) {
	/**
	 * The filter page a value of the sidebar leads to, when there is one.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $group Group of the sidebar.
	 * @param object              $term  Value of the group.
	 *
	 * @return string Empty when the value only narrows the listing.
	 */
	function mvweb_core_listing_value_url( array $group, $term ) {
		if ( isset( $group['part'] ) || 'subcategory' === $group['slug'] || in_array( $term->slug, $group['selected'], true ) ) {
			return '';
		}

		$current  = get_queried_object();
		$category = $current instanceof WP_Term && mvweb_core_taxonomy() === $current->taxonomy ? $current->term_id : 0;
		$target   = mvweb_core_catalog_selection();

		$target[ $group['slug'] ][] = $term->slug;

		$facet = mvweb_core_facet_find( $category, $target );

		return $facet ? mvweb_core_facet_url( $facet ) : '';
	}
}

if ( ! function_exists( 'mvweb_core_listing_wc_query' ) ) {
	/**
	 * Narrow the store's listing by the brand and the availability.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Product query.
	 *
	 * @return void
	 */
	function mvweb_core_listing_wc_query( $query ) {
		$brands = mvweb_core_catalog_requested( 'brand' );
		$stock  = mvweb_core_listing_stock_selected();

		if ( ! empty( $brands ) && taxonomy_exists( 'product_brand' ) ) {
			$tax_query   = (array) $query->get( 'tax_query', array() );
			$tax_query[] = array(
				'taxonomy' => 'product_brand',
				'field'    => 'slug',
				'terms'    => $brands,
				'operator' => 'IN',
			);

			$query->set( 'tax_query', $tax_query ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- A catalogue filter is exactly what a taxonomy query is for.
		}

		if ( in_array( 'in', $stock, true ) ) {
			$meta_query   = (array) $query->get( 'meta_query', array() );
			$meta_query[] = array(
				'key'   => '_stock_status',
				'value' => 'instock',
			);

			$query->set( 'meta_query', $meta_query ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- The stock status lives in a meta field only.
		}

		if ( in_array( 'sale', $stock, true ) ) {
			$sale = array_map( 'absint', wc_get_product_ids_on_sale() );
			$have = array_map( 'absint', (array) $query->get( 'post__in', array() ) );

			if ( ! empty( $have ) ) {
				$sale = array_values( array_intersect( $have, $sale ) );
			}

			$query->set( 'post__in', empty( $sale ) ? array( 0 ) : $sale );
		}
	}
}
add_action( 'woocommerce_product_query', 'mvweb_core_listing_wc_query' );

if ( ! function_exists( 'mvweb_core_listing_native_query' ) ) {
	/**
	 * Narrow the own catalogue by the brand.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Query being prepared.
	 *
	 * @return void
	 */
	function mvweb_core_listing_native_query( $query ) {
		if ( mvweb_core_is_woocommerce() || ! mvweb_core_is_catalog_query( $query ) ) {
			return;
		}

		$chosen = mvweb_core_catalog_requested( 'brand' );

		if ( empty( $chosen ) ) {
			return;
		}

		$group = mvweb_core_listing_brand_group();
		$names = array();

		$terms = null === $group ? array() : $group['terms'];

		foreach ( $terms as $term ) {
			if ( in_array( $term->slug, $chosen, true ) ) {
				$names[] = $term->name;
			}
		}

		$meta_query   = (array) $query->get( 'meta_query', array() );
		$meta_query[] = array(
			'key'     => '_mvweb_brand',
			'value'   => empty( $names ) ? array( '' ) : $names,
			'compare' => 'IN',
		);

		$query->set( 'meta_query', $meta_query ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- The brand of the own catalogue lives in a meta field only.
	}
}
add_action( 'pre_get_posts', 'mvweb_core_listing_native_query', 11 );

if ( ! function_exists( 'mvweb_core_listing_url_without' ) ) {
	/**
	 * The address of the listing with one chosen value taken away.
	 *
	 * @since 0.1.0
	 *
	 * @param string   $key   Parameter: filter_x, min_price or max_price.
	 * @param string[] $drop  Values to take out of a list; empty drops the parameter whole.
	 *
	 * @return string
	 */
	function mvweb_core_listing_url_without( $key, array $drop = array() ) {
		$args = mvweb_core_catalog_query_args();

		if ( 'price' === $key ) {
			unset( $args['min_price'], $args['max_price'] );
		} elseif ( isset( $args[ $key ] ) ) {
			$left = array_values( array_diff( array_filter( array_map( 'sanitize_title', explode( ',', $args[ $key ] ) ) ), $drop ) );

			if ( empty( $left ) ) {
				unset( $args[ $key ], $args[ 'query_type_' . substr( $key, 7 ) ] );
			} else {
				$args[ $key ] = implode( ',', $left );
			}
		}

		return add_query_arg( $args, mvweb_core_catalog_url() );
	}
}

if ( ! function_exists( 'mvweb_core_listing_active' ) ) {
	/**
	 * The filters the visitor chose, each with the address that takes it away.
	 *
	 * @since 0.1.0
	 *
	 * @return array{items:array<int,array{label:string,url:string}>,reset:string}
	 */
	function mvweb_core_listing_active() {
		$items  = array();
		$groups = mvweb_core_catalog_filters();
		$sub    = mvweb_core_catalog_subcategories();

		if ( null !== $sub ) {
			array_unshift( $groups, $sub );
		}

		$min  = mvweb_core_catalog_price_bound( 'min_price' );
		$max  = mvweb_core_catalog_price_bound( 'max_price' );
		$sign = mvweb_core_listing_currency();
		$sign = '' === $sign ? '' : "\xc2\xa0" . $sign;

		if ( '' !== $min || '' !== $max ) {
			$low  = number_format_i18n( (float) $min, 0 );
			$high = number_format_i18n( (float) $max, 0 );

			if ( '' !== $min && '' !== $max ) {
				$label = $low . '–' . $high . $sign;
			} elseif ( '' !== $min ) {
				/* translators: %s: lowest price with the currency sign. */
				$label = sprintf( __( 'from %s', 'mvweb-core' ), $low . $sign );
			} else {
				/* translators: %s: highest price with the currency sign. */
				$label = sprintf( __( 'up to %s', 'mvweb-core' ), $high . $sign );
			}

			$items[] = array(
				'label' => $label,
				'url'   => mvweb_core_listing_url_without( 'price' ),
			);
		}

		foreach ( $groups as $group ) {
			$requested = mvweb_core_catalog_requested( $group['slug'] );

			foreach ( $requested as $slug ) {
				$label = $slug;

				foreach ( $group['terms'] as $term ) {
					if ( $term->slug === $slug ) {
						$label = $term->name;
					}
				}

				$items[] = array(
					'label' => $label,
					'url'   => mvweb_core_listing_url_without( 'filter_' . $group['slug'], array( $slug ) ),
				);
			}
		}

		return array(
			'items' => $items,
			'reset' => mvweb_core_catalog_url(),
		);
	}
}

if ( ! function_exists( 'mvweb_core_listing_lead' ) ) {
	/**
	 * The text under the heading of the listing.
	 *
	 * @since 0.1.0
	 *
	 * @return array{lead:string,intro:string}
	 */
	function mvweb_core_listing_lead() {
		$none = array(
			'lead'  => '',
			'intro' => '',
		);

		if ( is_paged() || mvweb_core_listing_filtered() ) {
			return $none;
		}

		$current = get_queried_object();

		if ( ! mvweb_core_current_facet() && ! $current instanceof WP_Term ) {
			$page = mvweb_core_is_woocommerce() && function_exists( 'wc_get_page_id' ) ? max( 0, (int) wc_get_page_id( 'shop' ) ) : 0;
			$lead = $page > 0 ? trim( (string) get_post_field( 'post_excerpt', $page ) ) : trim( (string) get_theme_mod( 'mvweb_catalog_lead', '' ) );

			if ( '' !== $lead ) {
				return array(
					'lead'  => $lead,
					'intro' => '',
				);
			}
		}

		$intro = mvweb_core_listing_intro();

		if ( '' === $intro ) {
			return $none;
		}

		if ( substr_count( $intro, '<p' ) <= 1 && strip_tags( $intro, '<p><br>' ) === $intro ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.strip_tags_strip_tags -- Whether any tag but a paragraph is there, not the text.
			return array(
				'lead'  => trim( html_entity_decode( wp_strip_all_tags( $intro ), ENT_QUOTES, 'UTF-8' ) ),
				'intro' => '',
			);
		}

		return array(
			'lead'  => '',
			'intro' => $intro,
		);
	}
}

if ( ! function_exists( 'mvweb_core_listing_text_now' ) ) {
	/**
	 * The second text of the listing, empty for a listing the visitor narrowed.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_listing_text_now() {
		return mvweb_core_listing_filtered() ? '' : mvweb_core_listing_text();
	}
}

if ( ! function_exists( 'mvweb_core_listing_chips' ) ) {
	/**
	 * The chips in the head: the filter pages of a category, or the values of the page shown.
	 *
	 * @since 0.1.0
	 *
	 * @return array{items:array<int,array{label:string,url:string,current:bool}>,reset:string}
	 */
	function mvweb_core_listing_chips() {
		$items = array();
		$reset = '';
		$facet = mvweb_core_current_facet();

		if ( $facet ) {
			$names = array();

			foreach ( mvweb_core_properties() as $property ) {
				$names[ $property['slug'] ] = $property['taxonomy'];
			}

			foreach ( mvweb_core_facet_selection( $facet ) as $slug => $values ) {
				foreach ( $values as $value ) {
					$term = isset( $names[ $slug ] ) ? get_term_by( 'slug', $value, $names[ $slug ] ) : false;

					if ( $term instanceof WP_Term ) {
						$items[] = array(
							'label'   => $term->name,
							'url'     => '',
							'current' => true,
						);
					}
				}
			}

			$category = get_term( absint( get_post_meta( $facet, '_mvweb_facet_term', true ) ), mvweb_core_taxonomy() );
			$link     = $category instanceof WP_Term ? get_term_link( $category ) : mvweb_core_catalog_page_url();
			$reset    = is_wp_error( $link ) ? '' : $link;

			return array(
				'items' => $items,
				'reset' => $reset,
			);
		}

		$current = get_queried_object();
		$limit   = absint( get_theme_mod( 'mvweb_listing_chips', 8 ) );

		if ( ! $current instanceof WP_Term || mvweb_core_taxonomy() !== $current->taxonomy || 0 === $limit ) {
			return array(
				'items' => array(),
				'reset' => '',
			);
		}

		foreach ( mvweb_core_facets() as $id => $landing ) {
			if ( (int) $landing['term'] !== (int) $current->term_id ) {
				continue;
			}

			$items[] = array(
				'label'   => get_the_title( $id ),
				'url'     => mvweb_core_facet_url( $id ),
				'current' => false,
			);

			if ( count( $items ) >= $limit ) {
				break;
			}
		}

		return array(
			'items' => $items,
			'reset' => '',
		);
	}
}

if ( ! function_exists( 'mvweb_core_listing_subcats' ) ) {
	/**
	 * The tiles of the sections inside the catalogue or the category being shown.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array{image:int,title:string,url:string,count:int}>
	 */
	function mvweb_core_listing_subcats() {
		if ( ! get_theme_mod( 'mvweb_catalog_subcats', true ) || is_paged() || mvweb_core_current_facet() || mvweb_core_listing_filtered() ) {
			return array();
		}

		$taxonomy = mvweb_core_taxonomy();
		$current  = get_queried_object();

		if ( $current instanceof WP_Term ) {
			if ( $taxonomy !== $current->taxonomy ) {
				return array();
			}

			$parent = $current->term_id;
		} else {
			$parent = 0;
		}

		$args = array(
			'taxonomy'   => $taxonomy,
			'parent'     => $parent,
			'hide_empty' => true,
		);

		if ( mvweb_core_is_woocommerce() ) {
			$args['exclude'] = array( absint( get_option( 'default_product_cat' ) ) );
		}

		$terms = get_terms( $args );

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return array();
		}

		$sets = array();

		foreach ( $terms as $term ) {
			$sets[ $term->term_id ] = mvweb_core_listing_tree( $term );
		}

		$counts = mvweb_core_listing_counts( $sets, false );
		$tiles  = array();

		foreach ( $terms as $term ) {
			$link = get_term_link( $term );

			if ( is_wp_error( $link ) ) {
				continue;
			}

			$tiles[] = array(
				'image' => absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) ),
				'title' => $term->name,
				'url'   => $link,
				'count' => $counts[ $term->term_id ],
			);
		}

		return $tiles;
	}
}

if ( ! function_exists( 'mvweb_core_listing_grid' ) ) {
	/**
	 * Tell WooCommerce the grid of the listing has three columns and four rows.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_listing_grid() {
		if ( mvweb_core_is_woocommerce() ) {
			add_theme_support(
				'woocommerce',
				array(
					'product_grid' => array(
						'default_columns' => 3,
						'default_rows'    => 4,
						'min_columns'     => 2,
						'max_columns'     => 4,
					),
				)
			);
		}
	}
}
add_action( 'after_setup_theme', 'mvweb_core_listing_grid', 11 );
