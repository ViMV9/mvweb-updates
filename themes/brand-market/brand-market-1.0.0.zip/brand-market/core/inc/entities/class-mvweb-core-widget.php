<?php
/**
 * The widget of the base: one class, many kinds.
 *
 * A kind is a line of the list in mvweb_core_widget_kinds(): its name, the
 * fields of its form, the parts the owner can tick and reorder, and the
 * function that gathers its data. The class only keeps the form, the saving
 * and the printing the same for all of them; the markup is the template part
 * of the theme named by the kind.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'MVweb_Core_Widget' ) ) {

	/**
	 * A sidebar widget built from the description of its kind.
	 *
	 * @since 0.1.0
	 */
	class MVweb_Core_Widget extends WP_Widget {

		/**
		 * Description of the kind.
		 *
		 * @since 0.1.0
		 *
		 * @var array<string,mixed>
		 */
		protected $kind = array();

		/**
		 * Keep the description of the kind and register the widget under its id.
		 *
		 * @since 0.1.0
		 *
		 * @param string              $key  Kind key.
		 * @param array<string,mixed> $kind Name, description, fields, parts, data callback, template.
		 */
		public function __construct( $key, array $kind ) {
			$this->kind = $kind;

			parent::__construct(
				'mvweb_' . $key,
				$kind['name'],
				array(
					'classname'                   => isset( $kind['classname'] ) ? $kind['classname'] : 'mvweb-widget-' . $key,
					'description'                 => $kind['description'],
					'customize_selective_refresh' => true,
				)
			);
		}

		/**
		 * The instance with every field filled in.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,mixed> $instance Saved values.
		 *
		 * @return array<string,mixed>
		 */
		protected function complete( $instance ) {
			$instance = is_array( $instance ) ? $instance : array();
			$complete = array(
				'title' => isset( $this->kind['title'] ) ? $this->kind['title'] : '',
			);

			foreach ( $this->fields() as $name => $field ) {
				$complete[ $name ] = $field['default'];
			}

			return array_merge( $complete, $instance );
		}

		/**
		 * Fields of the form besides the title and the parts.
		 *
		 * @since 0.1.0
		 *
		 * @return array<string,array<string,mixed>>
		 */
		protected function fields() {
			return isset( $this->kind['fields'] ) ? (array) $this->kind['fields'] : array();
		}

		/**
		 * Parts of the widget in their default order.
		 *
		 * @since 0.1.0
		 *
		 * @return array<string,array{label:string,locked:bool,off:bool}>
		 */
		protected function parts() {
			$parts = array();

			foreach ( isset( $this->kind['parts'] ) ? (array) $this->kind['parts'] : array() as $slug => $part ) {
				$part           = is_array( $part ) ? $part : array( 'label' => $part );
				$parts[ $slug ] = $part + array(
					'locked' => false,
					'off'    => false,
				);
			}

			return $parts;
		}

		/**
		 * Slugs of the parts in the order the owner set, hidden ones included.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,mixed> $instance Saved values.
		 *
		 * @return string[]
		 */
		protected function order( $instance ) {
			$known = array_keys( $this->parts() );
			$saved = isset( $instance['order'] ) && is_array( $instance['order'] ) ? array_values( array_intersect( $instance['order'], $known ) ) : array();

			return array_merge( $saved, array_values( array_diff( $known, $saved ) ) );
		}

		/**
		 * Slugs of the parts the widget prints, in print order.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,mixed> $instance Saved values.
		 *
		 * @return string[]
		 */
		public function enabled( $instance ) {
			$parts   = $this->parts();
			$ticked  = isset( $instance['show'] ) && is_array( $instance['show'] ) ? $instance['show'] : null;
			$enabled = array();

			foreach ( $this->order( $instance ) as $slug ) {
				$on = null === $ticked ? ! $parts[ $slug ]['off'] : in_array( $slug, $ticked, true );

				if ( $on || $parts[ $slug ]['locked'] ) {
					$enabled[] = $slug;
				}
			}

			return $enabled;
		}

		/**
		 * Print the widget.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,mixed> $args     Sidebar markup.
		 * @param array<string,mixed> $instance Saved values.
		 *
		 * @return void
		 */
		public function widget( $args, $instance ) {
			$instance = $this->complete( $instance );
			$enabled  = $this->enabled( $instance );
			$data     = call_user_func( $this->kind['data'], $instance, $enabled );

			if ( ! is_array( $data ) ) {
				return;
			}

			$data['parts']    = $enabled;
			$data['instance'] = $instance;

			ob_start();
			get_template_part( 'template-parts/widgets/' . $this->kind['template'], null, $data );
			$body = trim( (string) ob_get_clean() );

			if ( '' === $body ) {
				return;
			}

			$title = (string) apply_filters( 'widget_title', $instance['title'], $instance, $this->id_base );

			if ( '' === trim( $title ) && ! empty( $this->kind['title_fallback'] ) ) {
				$title = (string) call_user_func( $this->kind['title_fallback'] );
			}

			echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the sidebar, set by the theme.

			if ( '' !== trim( $title ) ) {
				echo $args['before_title'] . esc_html( $title ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the sidebar, set by the theme; the title is escaped.
			}

			echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the template part, every value escaped there.
			echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the sidebar, set by the theme.
		}

		/**
		 * Sanitize the form.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,mixed> $new_instance Posted values.
		 * @param array<string,mixed> $old_instance Saved values.
		 *
		 * @return array<string,mixed>
		 */
		public function update( $new_instance, $old_instance ) {
			unset( $old_instance );

			$instance = array( 'title' => sanitize_text_field( isset( $new_instance['title'] ) ? $new_instance['title'] : '' ) );

			foreach ( $this->fields() as $name => $field ) {
				$value = isset( $new_instance[ $name ] ) ? $new_instance[ $name ] : '';

				if ( 'number' === $field['type'] ) {
					$instance[ $name ] = min( $field['max'], max( $field['min'], absint( $value ) ) );
				} elseif ( 'select' === $field['type'] ) {
					$instance[ $name ] = array_key_exists( $value, $field['choices'] ) ? $value : $field['default'];
				} elseif ( 'checkbox' === $field['type'] ) {
					$instance[ $name ] = ! empty( $value );
				} elseif ( 'textarea' === $field['type'] ) {
					$instance[ $name ] = sanitize_textarea_field( $value );
				} elseif ( 'url' === $field['type'] ) {
					$instance[ $name ] = esc_url_raw( $value );
				} else {
					$instance[ $name ] = sanitize_text_field( $value );
				}
			}

			if ( ! empty( $this->kind['parts'] ) ) {
				$known  = array_keys( $this->parts() );
				$order  = isset( $new_instance['order'] ) ? array_filter( array_map( 'sanitize_key', explode( ',', (string) $new_instance['order'] ) ) ) : array();
				$ticked = isset( $new_instance['show'] ) && is_array( $new_instance['show'] ) ? array_map( 'sanitize_key', $new_instance['show'] ) : array();

				$instance['order'] = array_values( array_intersect( $order, $known ) );
				$instance['show']  = array_values( array_intersect( $known, $ticked ) );
			}

			return $instance;
		}

		/**
		 * Print the form of the widget.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,mixed> $instance Saved values.
		 *
		 * @return void
		 */
		public function form( $instance ) {
			$instance = $this->complete( $instance );
			?>
			<p>
				<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'mvweb-core' ); ?></label>
				<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>">
			</p>
			<?php
			foreach ( $this->fields() as $name => $field ) {
				$this->field( $name, $field, $instance[ $name ] );
			}

			if ( ! empty( $this->kind['parts'] ) ) {
				$this->parts_form( $instance );
			}
		}

		/**
		 * Print one field of the form.
		 *
		 * @since 0.1.0
		 *
		 * @param string              $name  Field name.
		 * @param array<string,mixed> $field Description of the field.
		 * @param mixed               $value Saved value.
		 *
		 * @return void
		 */
		protected function field( $name, array $field, $value ) {
			$id    = $this->get_field_id( $name );
			$input = $this->get_field_name( $name );
			$label = '<label for="' . esc_attr( $id ) . '">' . esc_html( $field['label'] ) . '</label>';

			echo '<p>';

			if ( 'checkbox' === $field['type'] ) {
				printf(
					'<input class="checkbox" type="checkbox" id="%1$s" name="%2$s" value="1"%3$s> %4$s',
					esc_attr( $id ),
					esc_attr( $input ),
					checked( ! empty( $value ), true, false ),
					$label // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built above with the label escaped.
				);
			} elseif ( 'select' === $field['type'] ) {
				echo $label; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built above with the label escaped.
				echo '<select class="widefat" id="' . esc_attr( $id ) . '" name="' . esc_attr( $input ) . '">';

				foreach ( $field['choices'] as $key => $text ) {
					printf( '<option value="%1$s"%2$s>%3$s</option>', esc_attr( $key ), selected( (string) $value, (string) $key, false ), esc_html( $text ) );
				}

				echo '</select>';
			} elseif ( 'textarea' === $field['type'] ) {
				echo $label; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built above with the label escaped.
				echo '<textarea class="widefat" rows="3" id="' . esc_attr( $id ) . '" name="' . esc_attr( $input ) . '">' . esc_textarea( $value ) . '</textarea>';
			} else {
				$type = 'number' === $field['type'] ? 'number' : ( 'url' === $field['type'] ? 'url' : 'text' );
				$more = 'number' === $field['type'] ? sprintf( ' min="%1$d" max="%2$d" step="1"', $field['min'], $field['max'] ) : '';

				echo $label; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built above with the label escaped.
				echo '<input class="widefat" type="' . esc_attr( $type ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $input ) . '" value="' . esc_attr( $value ) . '"' . $more . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The numbers are cast above.
			}

			if ( ! empty( $field['hint'] ) && 'checkbox' !== $field['type'] ) {
				echo '<small class="description">' . esc_html( $field['hint'] ) . '</small>';
			}

			echo '</p>';
		}

		/**
		 * Print the composition of the widget: a tick and a place for every part.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,mixed> $instance Saved values.
		 *
		 * @return void
		 */
		protected function parts_form( $instance ) {
			$parts   = $this->parts();
			$order   = $this->order( $instance );
			$enabled = $this->enabled( $instance );
			$moving  = ! empty( $this->kind['ordered'] );
			?>
			<fieldset class="mvweb-widget-parts" data-mvweb-parts>
				<legend><?php esc_html_e( 'Composition', 'mvweb-core' ); ?></legend>
				<ul class="mvweb-widget-parts__list">
					<?php foreach ( $order as $slug ) : ?>
						<li class="mvweb-widget-parts__item" data-part="<?php echo esc_attr( $slug ); ?>">
							<label>
								<input class="checkbox" type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'show' ) ); ?>[]" value="<?php echo esc_attr( $slug ); ?>"<?php checked( in_array( $slug, $enabled, true ) ); ?><?php disabled( $parts[ $slug ]['locked'] ); ?>>
								<?php echo esc_html( $parts[ $slug ]['label'] ); ?>
							</label>
							<?php if ( $parts[ $slug ]['locked'] ) : ?>
								<input type="hidden" name="<?php echo esc_attr( $this->get_field_name( 'show' ) ); ?>[]" value="<?php echo esc_attr( $slug ); ?>">
							<?php endif; ?>
							<?php if ( $moving ) : ?>
								<span class="mvweb-widget-parts__move">
									<button type="button" class="button-link" data-move="-1"><span class="dashicons dashicons-arrow-up-alt2" aria-hidden="true"></span><span class="screen-reader-text"><?php esc_html_e( 'Move up', 'mvweb-core' ); ?></span></button>
									<button type="button" class="button-link" data-move="1"><span class="dashicons dashicons-arrow-down-alt2" aria-hidden="true"></span><span class="screen-reader-text"><?php esc_html_e( 'Move down', 'mvweb-core' ); ?></span></button>
								</span>
							<?php endif; ?>
						</li>
					<?php endforeach; ?>
				</ul>
				<input type="hidden" data-mvweb-order name="<?php echo esc_attr( $this->get_field_name( 'order' ) ); ?>" value="<?php echo esc_attr( implode( ',', $order ) ); ?>">
			</fieldset>
			<?php
		}
	}
}
