<?php
/**
 * Codes of counters and confirmation of the site in the webmasters' tools.
 *
 * Three fields take a code as a service gave it — the head, right after the
 * opening body tag, the end of the page. Only a user who may post unfiltered
 * HTML can save them: the code runs on every visit, so the right to change it
 * is the right to put a script on the site. Everybody else sees the field but
 * cannot change it, and a value sent by force is dropped. The confirmations of
 * Yandex Webmaster, Google Search Console and Bing are values, not code: only
 * the value is typed, the tag is printed here.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_codes_tree' ) ) {
	/**
	 * The panel of codes, cookie notice and structured data.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_codes_tree( $tree ) {
		$tree['mvweb_cz_codes'] = array(
			'title'    => __( 'MVweb: Codes and analytics', 'mvweb-core' ),
			'priority' => 38,
			'group'    => __( 'Analytics and privacy', 'mvweb-core' ),
			'sections' => array(
				'mvweb_cz_codes_scripts' => __( 'Counters and codes', 'mvweb-core' ),
				'mvweb_cz_codes_verify'  => __( 'Search engine confirmation', 'mvweb-core' ),
			),
		);

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_codes_tree', 98 );

if ( ! function_exists( 'mvweb_core_codes_slots' ) ) {
	/**
	 * Where a code can be put.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Slot => label.
	 */
	function mvweb_core_codes_slots() {
		return array(
			'head'   => __( 'Code in the head', 'mvweb-core' ),
			'body'   => __( 'Code right after the opening body tag', 'mvweb-core' ),
			'footer' => __( 'Code at the end of the page', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_codes_sanitize' ) ) {
	/**
	 * Keep a code as it was typed, for the one who may post it.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed                $value   Value sent by the Customizer.
	 * @param WP_Customize_Setting $setting Setting being saved.
	 *
	 * @return string The new value, or the saved one when the user may not change it.
	 */
	function mvweb_core_codes_sanitize( $value, $setting = null ) {
		if ( current_user_can( 'unfiltered_html' ) ) {
			return trim( (string) $value );
		}

		return $setting instanceof WP_Customize_Setting ? (string) get_theme_mod( $setting->id, '' ) : '';
	}
}

if ( ! function_exists( 'mvweb_core_verify_sanitize' ) ) {
	/**
	 * The value of a confirmation, without the tag around it.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string
	 */
	function mvweb_core_verify_sanitize( $value ) {
		$value = trim( (string) $value );

		if ( preg_match( '/content\s*=\s*["\']([^"\']+)["\']/i', $value, $found ) ) {
			$value = $found[1];
		}

		return (string) preg_replace( '/[^A-Za-z0-9_\-.:=]/', '', $value );
	}
}

if ( ! function_exists( 'mvweb_core_verify_names' ) ) {
	/**
	 * The search engines that ask for a confirmation tag.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,string>> Key => tag name and label.
	 */
	function mvweb_core_verify_names() {
		return array(
			'yandex' => array(
				'name'  => 'yandex-verification',
				'label' => __( 'Yandex Webmaster', 'mvweb-core' ),
			),
			'google' => array(
				'name'  => 'google-site-verification',
				'label' => __( 'Google Search Console', 'mvweb-core' ),
			),
			'bing'   => array(
				'name'  => 'msvalidate.01',
				'label' => __( 'Bing Webmaster Tools', 'mvweb-core' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_codes_overlap' ) ) {
	/**
	 * Whether MVweb Site Optimizer inserts codes of its own.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_codes_overlap() {
		if ( ! function_exists( 'mvweb_so_get_option' ) ) {
			return false;
		}

		return '' !== trim( (string) mvweb_so_get_option( 'insert_code_in_head', '' ) )
			|| '' !== trim( (string) mvweb_so_get_option( 'insert_code_in_body', '' ) );
	}
}

if ( ! function_exists( 'mvweb_core_codes_fields' ) ) {
	/**
	 * Fields of the codes and of the confirmations.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_codes_fields() {
		$can    = current_user_can( 'unfiltered_html' );
		$fields = array();

		if ( mvweb_core_codes_overlap() ) {
			$fields[] = array(
				'type'        => 'heading',
				'section'     => 'mvweb_cz_codes_scripts',
				'label'       => __( 'Codes are also set in MVweb Site Optimizer', 'mvweb-core' ),
				'description' => __( 'The theme prints its codes on its own. A counter put in both places fires twice: keep it in one.', 'mvweb-core' ),
				'priority'    => 1,
			);
		}

		if ( ! $can ) {
			$fields[] = array(
				'type'        => 'heading',
				'section'     => 'mvweb_cz_codes_scripts',
				'label'       => __( 'Read only', 'mvweb-core' ),
				'description' => __( 'Only a user who may post unfiltered HTML can change these codes.', 'mvweb-core' ),
				'priority'    => 2,
			);
		}

		$attrs = array(
			'spellcheck' => 'false',
			'style'      => 'height:10em;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:12px',
		);

		if ( ! $can ) {
			$attrs['readonly'] = 'readonly';
		}

		$notes = array(
			'head'   => __( 'Metrica, Google Analytics, pixels: the code as the service gave it, with its script tags.', 'mvweb-core' ),
			'body'   => __( 'Google Tag Manager noscript and the like: it is printed where the page body begins.', 'mvweb-core' ),
			'footer' => __( 'Chats and widgets that can load last.', 'mvweb-core' ),
		);

		foreach ( mvweb_core_codes_slots() as $slot => $label ) {
			$fields[] = array(
				'type'              => 'textarea',
				'settings'          => 'mvweb_code_' . $slot,
				'section'           => 'mvweb_cz_codes_scripts',
				'label'             => $label,
				'description'       => $notes[ $slot ],
				'default'           => '',
				'sanitize_callback' => 'mvweb_core_codes_sanitize',
				'input_attrs'       => $attrs,
			);
		}

		foreach ( mvweb_core_verify_names() as $key => $engine ) {
			$fields[] = array(
				'type'              => 'text',
				'settings'          => 'mvweb_verify_' . $key,
				'section'           => 'mvweb_cz_codes_verify',
				'label'             => $engine['label'],
				'description'       => sprintf(
					/* translators: %s: name of the meta tag. */
					__( 'Only the value from the content attribute of the tag %s.', 'mvweb-core' ),
					$engine['name']
				),
				'default'           => '',
				'sanitize_callback' => 'mvweb_core_verify_sanitize',
			);
		}

		return $fields;
	}
}

if ( ! function_exists( 'mvweb_core_codes_register_fields' ) ) {
	/**
	 * Hand the fields to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_codes_register_fields( $kit ) {
		$kit->add_fields( mvweb_core_codes_fields() );
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_codes_register_fields' );

if ( ! function_exists( 'mvweb_core_codes_print' ) ) {
	/**
	 * Print the code of a slot, as it was saved.
	 *
	 * @since 0.1.0
	 *
	 * @param string $slot Slot: head, body or footer.
	 *
	 * @return void
	 */
	function mvweb_core_codes_print( $slot ) {
		if ( is_admin() || is_customize_preview() || is_feed() ) {
			return;
		}

		$code = trim( (string) get_theme_mod( 'mvweb_code_' . $slot, '' ) );

		if ( '' === $code ) {
			return;
		}

		echo $code . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Code of a counter, saved only by a user who may post unfiltered HTML.
	}
}

if ( ! function_exists( 'mvweb_core_codes_print_head' ) ) {
	/**
	 * Print the code of the head.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_codes_print_head() {
		mvweb_core_codes_print( 'head' );
	}
}
add_action( 'wp_head', 'mvweb_core_codes_print_head', 5 );

if ( ! function_exists( 'mvweb_core_codes_print_body' ) ) {
	/**
	 * Print the code that goes right after the opening body tag.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_codes_print_body() {
		mvweb_core_codes_print( 'body' );
	}
}
add_action( 'wp_body_open', 'mvweb_core_codes_print_body', 1 );

if ( ! function_exists( 'mvweb_core_codes_print_footer' ) ) {
	/**
	 * Print the code of the end of the page.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_codes_print_footer() {
		mvweb_core_codes_print( 'footer' );
	}
}
add_action( 'wp_footer', 'mvweb_core_codes_print_footer', 99 );

if ( ! function_exists( 'mvweb_core_verify_print' ) ) {
	/**
	 * Print the confirmation tags that have a value.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_verify_print() {
		foreach ( mvweb_core_verify_names() as $key => $engine ) {
			$value = mvweb_core_verify_sanitize( get_theme_mod( 'mvweb_verify_' . $key, '' ) );

			if ( '' !== $value ) {
				printf( '<meta name="%1$s" content="%2$s">' . "\n", esc_attr( $engine['name'] ), esc_attr( $value ) );
			}
		}
	}
}
add_action( 'wp_head', 'mvweb_core_verify_print', 1 );
