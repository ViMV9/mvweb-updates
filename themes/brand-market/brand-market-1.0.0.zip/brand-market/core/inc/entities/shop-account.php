<?php
/**
 * The account of a customer in the store: sign in, registration, password reset, the orders and the details.
 *
 * WooCommerce owns the pages and the forms; what it does not know lives here: the
 * benefits printed beside the sign-in form, the tiles of the dashboard, how many
 * recent orders it lists, how long an unpaid order waits, the tone of a status and
 * the script of the account pages. The markup stays in the theme.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_account_active' ) ) {
	/**
	 * Whether the request is a page of the account of WooCommerce.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_account_active() {
		return function_exists( 'is_account_page' ) && is_account_page();
	}
}

if ( ! function_exists( 'mvweb_core_account_defaults' ) ) {
	/**
	 * Values of the account settings that nobody has changed.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_account_defaults() {
		return array(
			'mvweb_account_tiles'  => wp_json_encode( array( 'orders', 'addresses', 'details' ) ),
			'mvweb_account_recent' => 3,
			'mvweb_account_perks'  => wp_json_encode(
				array(
					array(
						'icon'  => 'package',
						'title' => __( 'Order history', 'mvweb-core' ),
						'text'  => __( 'Status, contents and a repeat of an order in one click.', 'mvweb-core' ),
					),
					array(
						'icon'  => 'map-pin',
						'title' => __( 'Saved addresses', 'mvweb-core' ),
						'text'  => __( 'No need to enter the details with every order.', 'mvweb-core' ),
					),
					array(
						'icon'  => 'heart',
						'title' => __( 'Favourites on every device', 'mvweb-core' ),
						'text'  => __( 'The list of items is not lost when you change the phone.', 'mvweb-core' ),
					),
				)
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_account_tree' ) ) {
	/**
	 * A section of its own for the account.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_account_tree( $tree ) {
		if ( class_exists( 'WooCommerce' ) && isset( $tree['mvweb_cz_catalog']['sections'] ) ) {
			$tree['mvweb_cz_catalog']['sections']['mvweb_cz_catalog_account'] = __( 'Account', 'mvweb-core' );
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_account_tree', 97 );

if ( ! function_exists( 'mvweb_core_account_tile_choices' ) ) {
	/**
	 * The tiles the dashboard can carry.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Slug => label.
	 */
	function mvweb_core_account_tile_choices() {
		return array(
			'orders'    => __( 'Orders', 'mvweb-core' ),
			'addresses' => __( 'Addresses', 'mvweb-core' ),
			'details'   => __( 'Account details', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_account_fields' ) ) {
	/**
	 * The fields of the account section.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_account_fields() {
		$defaults = mvweb_core_account_defaults();
		$section  = 'mvweb_cz_catalog_account';

		return array(
			array(
				'type'        => 'multicheck',
				'settings'    => 'mvweb_account_tiles',
				'section'     => $section,
				'label'       => __( 'Tiles of the dashboard', 'mvweb-core' ),
				'description' => __( 'The links under the greeting. A tile of a page that the store has switched off is not printed.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_account_tiles'],
				'choices'     => mvweb_core_account_tile_choices(),
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_account_recent',
				'section'     => $section,
				'label'       => __( 'Recent orders on the dashboard', 'mvweb-core' ),
				'description' => __( 'How many orders the dashboard lists. 0 hides the list.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_account_recent'],
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 10,
					'step' => 1,
				),
			),
			array(
				'type'        => 'repeater',
				'settings'    => 'mvweb_account_perks',
				'section'     => $section,
				'label'       => __( 'What an account gives', 'mvweb-core' ),
				'description' => __( 'The cards under the sign-in form. Empty means no cards.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_account_perks'],
				'fields'      => array(
					'icon'  => array(
						'type'    => 'select',
						'label'   => __( 'Icon', 'mvweb-core' ),
						'choices' => mvweb_core_icon_choices(),
					),
					'title' => array(
						'type'    => 'text',
						'label'   => __( 'Heading', 'mvweb-core' ),
						'choices' => array(),
					),
					'text'  => array(
						'type'    => 'textarea',
						'label'   => __( 'Text', 'mvweb-core' ),
						'choices' => array(),
					),
				),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_account_register_fields' ) ) {
	/**
	 * Hand the fields to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_account_register_fields( $kit ) {
		if ( class_exists( 'WooCommerce' ) ) {
			$kit->add_fields( mvweb_core_account_fields() );
		}
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_account_register_fields' );

if ( ! function_exists( 'mvweb_core_account_option' ) ) {
	/**
	 * A setting of the account, with the default it was declared with.
	 *
	 * @since 0.1.0
	 *
	 * @param string $key Setting id.
	 *
	 * @return mixed
	 */
	function mvweb_core_account_option( $key ) {
		$defaults = mvweb_core_account_defaults();

		return get_theme_mod( $key, isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
	}
}

if ( ! function_exists( 'mvweb_core_account_perks' ) ) {
	/**
	 * The cards printed beside the sign-in form.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array{icon:string,title:string,text:string}> Rows with a heading or a text.
	 */
	function mvweb_core_account_perks() {
		$rows  = json_decode( (string) mvweb_core_account_option( 'mvweb_account_perks' ), true );
		$perks = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$perk = array(
				'icon'  => isset( $row['icon'] ) ? sanitize_key( $row['icon'] ) : '',
				'title' => isset( $row['title'] ) ? trim( (string) $row['title'] ) : '',
				'text'  => isset( $row['text'] ) ? trim( (string) $row['text'] ) : '',
			);

			if ( '' !== $perk['title'] || '' !== $perk['text'] ) {
				$perks[] = $perk;
			}
		}

		return $perks;
	}
}

if ( ! function_exists( 'mvweb_core_account_tiles' ) ) {
	/**
	 * The tiles of the dashboard the owner left on, in their own order.
	 *
	 * @since 0.1.0
	 *
	 * @return string[] Slugs of mvweb_core_account_tile_choices().
	 */
	function mvweb_core_account_tiles() {
		$chosen = json_decode( (string) mvweb_core_account_option( 'mvweb_account_tiles' ), true );
		$chosen = is_array( $chosen ) ? array_map( 'sanitize_key', $chosen ) : array();

		return array_values( array_intersect( array_keys( mvweb_core_account_tile_choices() ), $chosen ) );
	}
}

if ( ! function_exists( 'mvweb_core_account_recent_count' ) ) {
	/**
	 * How many recent orders the dashboard lists.
	 *
	 * @since 0.1.0
	 *
	 * @return int
	 */
	function mvweb_core_account_recent_count() {
		return min( 10, absint( mvweb_core_account_option( 'mvweb_account_recent' ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_account_order_counts' ) ) {
	/**
	 * How many orders a customer has and how many of them are being handled.
	 *
	 * @since 0.1.0
	 *
	 * @param int $user_id Customer id.
	 *
	 * @return array{total:int,active:int}
	 */
	function mvweb_core_account_order_counts( $user_id ) {
		$user_id = absint( $user_id );

		if ( 0 === $user_id || ! function_exists( 'wc_get_orders' ) ) {
			return array(
				'total'  => 0,
				'active' => 0,
			);
		}

		$active = wc_get_orders(
			array(
				'customer' => $user_id,
				'status'   => array( 'processing', 'on-hold' ),
				'limit'    => -1,
				'return'   => 'ids',
			)
		);

		return array(
			'total'  => (int) wc_get_customer_order_count( $user_id ),
			'active' => is_array( $active ) ? count( $active ) : 0,
		);
	}
}

if ( ! function_exists( 'mvweb_core_account_hold_minutes' ) ) {
	/**
	 * How long an unpaid order waits before the store cancels it.
	 *
	 * @since 0.1.0
	 *
	 * @return int Minutes, 0 when orders are not cancelled by the store.
	 */
	function mvweb_core_account_hold_minutes() {
		if ( 'yes' !== get_option( 'woocommerce_manage_stock' ) ) {
			return 0;
		}

		return absint( get_option( 'woocommerce_hold_stock_minutes', 60 ) );
	}
}

if ( ! function_exists( 'mvweb_core_account_status_tone' ) ) {
	/**
	 * The tone of the pill of an order status.
	 *
	 * @since 0.1.0
	 *
	 * @param string $status Order status without the wc- prefix.
	 *
	 * @return string One of info, ok, warn, muted.
	 */
	function mvweb_core_account_status_tone( $status ) {
		$tones = array(
			'pending'    => 'warn',
			'failed'     => 'warn',
			'processing' => 'info',
			'on-hold'    => 'info',
			'completed'  => 'ok',
			'cancelled'  => 'muted',
			'refunded'   => 'muted',
		);

		$tone = isset( $tones[ $status ] ) ? $tones[ $status ] : 'info';

		/**
		 * Filter the tone of the pill of an order status.
		 *
		 * @since 0.1.0
		 *
		 * @param string $tone   One of info, ok, warn, muted.
		 * @param string $status Order status without the wc- prefix.
		 */
		return (string) apply_filters( 'mvweb_core_account_status_tone', $tone, $status );
	}
}

if ( ! function_exists( 'mvweb_core_account_style_map' ) ) {
	/**
	 * The sheets of the account: its own rules, the alerts, the empty states and the pages of the orders.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Handles without the theme prefix.
	 *
	 * @return string[]
	 */
	function mvweb_core_account_style_map( $styles ) {
		if ( mvweb_core_account_active() ) {
			array_push( $styles, 'empty', 'pagination', 'account' );
		}

		return array_values( array_unique( $styles ) );
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_core_account_style_map', 20 );

if ( ! function_exists( 'mvweb_core_account_modules' ) ) {
	/**
	 * The script of the account pages: show the password, the menu of the sections, the strength, the repeat of a letter.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules File names without extension.
	 *
	 * @return string[]
	 */
	function mvweb_core_account_modules( $modules ) {
		if ( mvweb_core_account_active() ) {
			$modules[] = 'account';
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_core_account_modules' );

if ( ! function_exists( 'mvweb_core_account_script_data' ) ) {
	/**
	 * Strings the script of the account needs.
	 *
	 * @since 0.1.0
	 *
	 * @param array $data Existing data.
	 *
	 * @return array
	 */
	function mvweb_core_account_script_data( $data ) {
		$data['show']     = __( 'Show password', 'mvweb-core' );
		$data['hide']     = __( 'Hide password', 'mvweb-core' );
		$data['strength'] = array(
			__( 'Too short', 'mvweb-core' ),
			__( 'Weak password', 'mvweb-core' ),
			__( 'Fair password', 'mvweb-core' ),
			__( 'Good password', 'mvweb-core' ),
			__( 'Strong password', 'mvweb-core' ),
		);
		/* translators: %s: seconds left. */
		$data['wait'] = __( 'Send again in %s s', 'mvweb-core' );

		return $data;
	}
}
add_filter( 'script_module_data_@mvweb-core/account', 'mvweb_core_account_script_data' );
