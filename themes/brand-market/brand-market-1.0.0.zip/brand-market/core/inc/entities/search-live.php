<?php
/**
 * The live search of MVweb Smart Search, dressed in the theme.
 *
 * The plugin prints the field and the panel of the suggestions on every page
 * that has a search field, so the theme's stylesheet for them goes wherever the
 * plugin answers the site search, not only to the results page.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_search_live_styles' ) ) {
	/**
	 * Add the stylesheet of the live search while Smart Search answers the site search.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Handles without the theme prefix.
	 *
	 * @return string[]
	 */
	function mvweb_core_search_live_styles( $styles ) {
		if ( 'smart' === mvweb_core_search_engine() ) {
			$styles[] = 'search-live';
		}

		return $styles;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_core_search_live_styles' );
