<?php
/**
 * Corner radius of the whole site: one setting, four tokens.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_radius_choices' ) ) {
	/**
	 * The radii an owner can pick, in pixels.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_radius_choices() {
		return array(
			'0'  => __( 'Sharp corners', 'mvweb-core' ),
			'4'  => '4 px',
			'6'  => '6 px',
			'8'  => '8 px',
			'10' => '10 px',
		);
	}
}

if ( ! function_exists( 'mvweb_core_radius' ) ) {
	/**
	 * The radius picked for the site.
	 *
	 * @since 0.1.0
	 *
	 * @return string One of the keys of mvweb_core_radius_choices().
	 */
	function mvweb_core_radius() {
		$radius = (string) get_theme_mod( 'mvweb_radius', '10' );

		return isset( mvweb_core_radius_choices()[ $radius ] ) ? $radius : '10';
	}
}

if ( ! function_exists( 'mvweb_core_radius_register_fields' ) ) {
	/**
	 * Hand the field to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_radius_register_fields( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'radio',
					'settings'    => 'mvweb_radius',
					'section'     => 'mvweb_cz_design_preset',
					'label'       => __( 'Corners', 'mvweb-core' ),
					'description' => __( 'One radius for buttons, fields, cards, windows and pictures. With sharp corners the round chips and counters turn sharp too.', 'mvweb-core' ),
					'default'     => '10',
					'choices'     => mvweb_core_radius_choices(),
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_radius_register_fields' );

if ( ! function_exists( 'mvweb_core_print_radius' ) ) {
	/**
	 * Print the radius tokens when the owner moved them off the default.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_print_radius() {
		$radius = mvweb_core_radius();

		if ( '10' === $radius ) {
			return;
		}

		$full = '0' === $radius ? '0' : '999px';

		printf(
			"<style id='mvweb-core-radius'>:root{--mvweb-t-radius-sm:%1\$spx;--mvweb-t-radius:%1\$spx;--mvweb-t-radius-lg:%1\$spx;--mvweb-t-radius-full:%2\$s}</style>\n",
			(int) $radius,
			$full // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- One of two fixed values.
		);
	}
}
add_action( 'wp_head', 'mvweb_core_print_radius', 11 );
