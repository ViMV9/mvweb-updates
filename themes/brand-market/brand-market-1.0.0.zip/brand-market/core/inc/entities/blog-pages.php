<?php
/**
 * Pages of the blog: the blog itself, a category, a tag, an author, a month and an entry.
 *
 * What these pages print and a theme cannot decide alone lives here: the
 * settings of the Customizer, the second description of a category, the lead
 * of the blog page, the role and the links of an author, the strips of
 * categories and months, the entries that go under an entry and the parts of
 * a page a template has printed. The markup stays in the theme.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_blog_defaults' ) ) {
	/**
	 * Values of the blog settings that nobody has changed.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_blog_defaults() {
		return array(
			'mvweb_blog_topics_nav'    => true,
			'mvweb_blog_months_nav'    => true,
			'mvweb_blog_all_label'     => __( 'All', 'mvweb-core' ),
			'mvweb_blog_feature'       => true,
			'mvweb_blog_feature_more'  => __( 'Read the article', 'mvweb-core' ),
			'mvweb_blog_hero_parts'    => wp_json_encode( array( 'eyebrow', 'lead', 'meta' ) ),
			'mvweb_post_related_title' => __( 'Read also', 'mvweb-core' ),
			'mvweb_post_related_link'  => __( 'All articles', 'mvweb-core' ),
			'mvweb_post_related_count' => 3,
			'mvweb_toc_title'          => __( 'Contents', 'mvweb-core' ),
			'mvweb_toc_position'       => 'after',
			'mvweb_comment_consent'    => __( 'I agree to the processing of personal data and the {privacy policy}', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_blog_option' ) ) {
	/**
	 * A blog setting.
	 *
	 * @since 0.1.0
	 *
	 * @param string $key Setting name.
	 *
	 * @return mixed The saved value, the default while nothing is saved.
	 */
	function mvweb_core_blog_option( $key ) {
		$defaults = mvweb_core_blog_defaults();

		return get_theme_mod( $key, isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
	}
}

if ( ! function_exists( 'mvweb_core_blog_fields' ) ) {
	/**
	 * Fields of the blog listing and of the page of an entry.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_blog_fields() {
		$defaults = mvweb_core_blog_defaults();

		return array(
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_blog_feature',
				'section'     => 'mvweb_cz_inner_archive',
				'label'       => __( 'Large first entry on the blog page', 'mvweb-core' ),
				'description' => __( 'The newest entry of the first page (a sticky one goes before it) is printed large above the cards.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_blog_feature'],
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_blog_feature_more',
				'section'  => 'mvweb_cz_inner_archive',
				'label'    => __( 'Large entry: link text', 'mvweb-core' ),
				'default'  => $defaults['mvweb_blog_feature_more'],
			),
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_blog_topics_nav',
				'section'     => 'mvweb_cz_inner_archive',
				'label'       => __( 'Categories above the entries', 'mvweb-core' ),
				'description' => __( 'A row of links to every category on the blog page and on a category. It is not printed while the blog has no categories with entries.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_blog_topics_nav'],
			),
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_blog_months_nav',
				'section'     => 'mvweb_cz_inner_archive',
				'label'       => __( 'Months above the entries', 'mvweb-core' ),
				'description' => __( 'A row of links to the latest months on the archive of a month, a year or a day.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_blog_months_nav'],
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_blog_all_label',
				'section'  => 'mvweb_cz_inner_archive',
				'label'    => __( 'Link to the whole blog in the row of categories', 'mvweb-core' ),
				'default'  => $defaults['mvweb_blog_all_label'],
			),
			array(
				'type'        => 'multicheck',
				'settings'    => 'mvweb_blog_hero_parts',
				'section'     => 'mvweb_cz_inner_archive',
				'label'       => __( 'Heading of a category, a tag, an author and a date', 'mvweb-core' ),
				'description' => __( 'What stands beside the title. The order is set by the design.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_blog_hero_parts'],
				'choices'     => mvweb_core_blog_hero_choices(),
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_post_related_title',
				'section'  => 'mvweb_cz_inner_single',
				'label'    => __( 'More entries: heading', 'mvweb-core' ),
				'default'  => $defaults['mvweb_post_related_title'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_post_related_link',
				'section'     => 'mvweb_cz_inner_single',
				'label'       => __( 'More entries: link to the blog', 'mvweb-core' ),
				'description' => __( 'Empty hides the link.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_post_related_link'],
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_post_related_count',
				'section'     => 'mvweb_cz_inner_single',
				'label'       => __( 'More entries: how many', 'mvweb-core' ),
				'description' => __( 'Entries of the same category come first, the newest ones fill the gap. 0 hides the block.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_post_related_count'],
				'input_attrs' => array(
					'min'  => 0,
					'max'  => 12,
					'step' => 1,
				),
			),
			array(
				'type'     => 'text',
				'settings' => 'mvweb_toc_title',
				'section'  => 'mvweb_cz_inner_single',
				'label'    => __( 'Table of contents: heading', 'mvweb-core' ),
				'default'  => $defaults['mvweb_toc_title'],
			),
			array(
				'type'     => 'select',
				'settings' => 'mvweb_toc_position',
				'section'  => 'mvweb_cz_inner_single',
				'label'    => __( 'Table of contents: place', 'mvweb-core' ),
				'default'  => $defaults['mvweb_toc_position'],
				'choices'  => array(
					'after' => __( 'After the first paragraph', 'mvweb-core' ),
					'top'   => __( 'Above the text', 'mvweb-core' ),
				),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_comment_consent',
				'section'     => 'mvweb_cz_inner_single',
				'label'       => __( 'Consent under the comment form', 'mvweb-core' ),
				'description' => __( 'Words in curly braces become the link to the privacy policy page. Empty removes the tick box.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_comment_consent'],
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_blog_register_fields' ) ) {
	/**
	 * Hand the fields to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_blog_register_fields( $kit ) {
		$kit->add_fields( mvweb_core_blog_fields() );
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_blog_register_fields' );

if ( ! function_exists( 'mvweb_core_blog_hero_choices' ) ) {
	/**
	 * The parts of the heading of a blog archive that can be switched off.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_blog_hero_choices() {
		return array(
			'eyebrow' => __( 'Small label over the title', 'mvweb-core' ),
			'lead'    => __( 'Description under the title', 'mvweb-core' ),
			'meta'    => __( 'Line of facts: number of entries, date', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_blog_hero_has' ) ) {
	/**
	 * Whether the heading of a blog archive shows a part.
	 *
	 * @since 0.1.0
	 *
	 * @param string $part Part: eyebrow, lead or meta.
	 *
	 * @return bool
	 */
	function mvweb_core_blog_hero_has( $part ) {
		$chosen = json_decode( (string) mvweb_core_blog_option( 'mvweb_blog_hero_parts' ), true );

		return is_array( $chosen ) && in_array( (string) $part, array_map( 'strval', $chosen ), true );
	}
}

if ( ! function_exists( 'mvweb_core_blog_register_meta' ) ) {
	/**
	 * Register what the blog keeps beyond the core: the text under a category, the lead of the blog page, the role and the links of an author.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_blog_register_meta() {
		add_post_type_support( 'page', 'excerpt' );

		register_term_meta(
			'category',
			'mvweb_text',
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => 'wp_kses_post',
				'auth_callback'     => 'mvweb_core_term_meta_auth',
				'show_in_rest'      => false,
			)
		);

		add_action( 'category_edit_form_fields', 'mvweb_core_term_text_field' );
		add_action( 'edited_category', 'mvweb_core_term_text_save' );

		register_meta(
			'user',
			'mvweb_user_role',
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => 'mvweb_core_blog_user_meta_auth',
				'show_in_rest'      => false,
			)
		);

		register_meta(
			'user',
			'mvweb_user_links',
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => '',
				'sanitize_callback' => 'mvweb_core_blog_sanitize_links',
				'auth_callback'     => 'mvweb_core_blog_user_meta_auth',
				'show_in_rest'      => false,
			)
		);
	}
}
add_action( 'init', 'mvweb_core_blog_register_meta', 31 );

if ( ! function_exists( 'mvweb_core_blog_user_meta_auth' ) ) {
	/**
	 * Whether a user may write the role and the links of another user.
	 *
	 * @since 0.1.0
	 *
	 * @param bool   $allowed  Current answer.
	 * @param string $meta_key Meta key.
	 * @param int    $user_id  User the meta belongs to.
	 * @param int    $editor   User asking.
	 *
	 * @return bool
	 */
	function mvweb_core_blog_user_meta_auth( $allowed, $meta_key, $user_id, $editor ) {
		return user_can( $editor, 'edit_user', $user_id );
	}
}

if ( ! function_exists( 'mvweb_core_blog_sanitize_links' ) ) {
	/**
	 * Clean a list of links typed one to a line.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Text as typed.
	 *
	 * @return string One address per line, only those with a safe protocol.
	 */
	function mvweb_core_blog_sanitize_links( $value ) {
		$lines = array();

		foreach ( preg_split( '/\R/', (string) $value ) as $line ) {
			$url = esc_url_raw( trim( $line ), array( 'http', 'https', 'mailto', 'tg' ) );

			if ( '' !== $url ) {
				$lines[] = $url;
			}
		}

		return implode( "\n", array_slice( array_unique( $lines ), 0, 8 ) );
	}
}

if ( ! function_exists( 'mvweb_core_blog_profile_fields' ) ) {
	/**
	 * The role and the links of an author, on the profile form.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_User $user User being edited.
	 *
	 * @return void
	 */
	function mvweb_core_blog_profile_fields( $user ) {
		wp_nonce_field( 'mvweb_user_card', 'mvweb_user_card_nonce' );
		?>
		<h2><?php esc_html_e( 'Author on the blog', 'mvweb-core' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th><label for="mvweb-user-role"><?php esc_html_e( 'Position', 'mvweb-core' ); ?></label></th>
				<td>
					<input class="regular-text" type="text" id="mvweb-user-role" name="mvweb_user_role" value="<?php echo esc_attr( (string) get_user_meta( $user->ID, 'mvweb_user_role', true ) ); ?>">
					<p class="description"><?php esc_html_e( 'For example: zootechnician. Printed under the name in the line of the author.', 'mvweb-core' ); ?></p>
				</td>
			</tr>
			<tr>
				<th><label for="mvweb-user-links"><?php esc_html_e( 'Links of the author', 'mvweb-core' ); ?></label></th>
				<td>
					<textarea class="large-text" rows="4" id="mvweb-user-links" name="mvweb_user_links"><?php echo esc_textarea( (string) get_user_meta( $user->ID, 'mvweb_user_links', true ) ); ?></textarea>
					<p class="description"><?php esc_html_e( 'One address per line: https://t.me/name, https://vk.com/name, mailto:name@example.com. The icon follows the site.', 'mvweb-core' ); ?></p>
				</td>
			</tr>
		</table>
		<?php
	}
}
add_action( 'show_user_profile', 'mvweb_core_blog_profile_fields' );
add_action( 'edit_user_profile', 'mvweb_core_blog_profile_fields' );

if ( ! function_exists( 'mvweb_core_blog_profile_save' ) ) {
	/**
	 * Store the role and the links of an author.
	 *
	 * @since 0.1.0
	 *
	 * @param int $user_id User being saved.
	 *
	 * @return void
	 */
	function mvweb_core_blog_profile_save( $user_id ) {
		if ( ! isset( $_POST['mvweb_user_card_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mvweb_user_card_nonce'] ) ), 'mvweb_user_card' ) || ! current_user_can( 'edit_user', $user_id ) ) {
			return;
		}

		foreach ( array( 'mvweb_user_role', 'mvweb_user_links' ) as $key ) {
			$value = isset( $_POST[ $key ] ) ? trim( (string) wp_unslash( $_POST[ $key ] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized by the callback the key is registered with.

			if ( '' === $value ) {
				delete_user_meta( $user_id, $key );
			} else {
				update_user_meta( $user_id, $key, $value );
			}
		}
	}
}
add_action( 'personal_options_update', 'mvweb_core_blog_profile_save' );
add_action( 'edit_user_profile_update', 'mvweb_core_blog_profile_save' );

if ( ! function_exists( 'mvweb_core_blog_contact_methods' ) ) {
	/**
	 * The networks of the country in the contact block of the profile.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $methods Contact methods by key.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_blog_contact_methods( $methods ) {
		return array_merge(
			array(
				'mvweb_telegram' => __( 'Telegram', 'mvweb-core' ),
				'mvweb_vk'       => __( 'VK', 'mvweb-core' ),
				'mvweb_max'      => __( 'MAX', 'mvweb-core' ),
				'mvweb_ok'       => __( 'Odnoklassniki', 'mvweb-core' ),
			),
			(array) $methods
		);
	}
}
add_filter( 'user_contactmethods', 'mvweb_core_blog_contact_methods' );

if ( ! function_exists( 'mvweb_core_author_role' ) ) {
	/**
	 * The position of an author.
	 *
	 * @since 0.1.0
	 *
	 * @param int $user_id User id.
	 *
	 * @return string
	 */
	function mvweb_core_author_role( $user_id ) {
		return trim( (string) get_user_meta( absint( $user_id ), 'mvweb_user_role', true ) );
	}
}

if ( ! function_exists( 'mvweb_core_author_links' ) ) {
	/**
	 * The links of an author with the icon and the name of the place each leads to.
	 *
	 * @since 0.1.0
	 *
	 * @param int $user_id User id.
	 *
	 * @return array<int,array<string,string>> Items with url, icon and label.
	 */
	function mvweb_core_author_links( $user_id ) {
		$places  = array(
			't.me'          => array( 'telegram', __( 'Telegram', 'mvweb-core' ) ),
			'telegram.me'   => array( 'telegram', __( 'Telegram', 'mvweb-core' ) ),
			'vk.com'        => array( 'vk', __( 'VK', 'mvweb-core' ) ),
			'vk.ru'         => array( 'vk', __( 'VK', 'mvweb-core' ) ),
			'wa.me'         => array( 'whatsapp', __( 'WhatsApp', 'mvweb-core' ) ),
			'whatsapp.com'  => array( 'whatsapp', __( 'WhatsApp', 'mvweb-core' ) ),
			'max.ru'        => array( 'max', __( 'MAX', 'mvweb-core' ) ),
			'ok.ru'         => array( 'ok', __( 'Odnoklassniki', 'mvweb-core' ) ),
			'youtube.com'   => array( 'youtube', __( 'YouTube', 'mvweb-core' ) ),
			'youtu.be'      => array( 'youtube', __( 'YouTube', 'mvweb-core' ) ),
			'rutube.ru'     => array( 'rutube', __( 'Rutube', 'mvweb-core' ) ),
			'dzen.ru'       => array( 'dzen', __( 'Dzen', 'mvweb-core' ) ),
			'instagram.com' => array( 'instagram', __( 'Instagram', 'mvweb-core' ) ),
			'facebook.com'  => array( 'facebook', __( 'Facebook', 'mvweb-core' ) ),
			'x.com'         => array( 'x', __( 'X', 'mvweb-core' ) ),
			'twitter.com'   => array( 'x', __( 'X', 'mvweb-core' ) ),
			'linkedin.com'  => array( 'linkedin', __( 'LinkedIn', 'mvweb-core' ) ),
			'pinterest.com' => array( 'pinterest', __( 'Pinterest', 'mvweb-core' ) ),
			'tiktok.com'    => array( 'tiktok', __( 'TikTok', 'mvweb-core' ) ),
		);
		$user_id = absint( $user_id );
		$lines   = array( (string) get_the_author_meta( 'user_url', $user_id ) );
		$links   = array();
		$handles = array(
			'mvweb_telegram' => 'https://t.me/',
			'mvweb_vk'       => 'https://vk.com/',
			'mvweb_ok'       => 'https://ok.ru/',
			'twitter'        => 'https://x.com/',
		);

		foreach ( array_keys( wp_get_user_contact_methods() ) as $method ) {
			$value = trim( (string) get_user_meta( $user_id, $method, true ) );

			if ( isset( $handles[ $method ] ) && '' !== $value && false === strpbrk( $value, '/:' ) ) {
				$value = $handles[ $method ] . ltrim( $value, '@' );
			}

			$lines[] = $value;
		}

		$lines = array_merge( $lines, preg_split( '/\R/', (string) get_user_meta( $user_id, 'mvweb_user_links', true ) ) );

		foreach ( $lines as $line ) {
			$url = esc_url( trim( $line ), array( 'http', 'https', 'mailto', 'tg' ) );

			if ( '' === $url || isset( $links[ $url ] ) ) {
				continue;
			}

			if ( 0 === strpos( $url, 'mailto:' ) ) {
				$icon  = 'mail';
				$label = __( 'E-mail', 'mvweb-core' );
			} else {
				$host  = preg_replace( '/^www\./', '', strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) ) );
				$icon  = 'world';
				$label = '' !== $host ? $host : $url;

				if ( 0 === strpos( $url, 'tg:' ) ) {
					$host = 't.me';
				}

				if ( isset( $places[ $host ] ) ) {
					list( $icon, $label ) = $places[ $host ];
				}
			}

			$links[ $url ] = array(
				'url'   => $url,
				'icon'  => $icon,
				'label' => $label,
			);
		}

		return array_values( $links );
	}
}

if ( ! function_exists( 'mvweb_core_reading_minutes' ) ) {
	/**
	 * The minutes an entry takes to read.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Entry id.
	 *
	 * @return int At least 1, 0 for an entry without words.
	 */
	function mvweb_core_reading_minutes( $post_id ) {
		$words = preg_match_all( '/[\p{L}\p{N}]+/u', wp_strip_all_tags( (string) get_post_field( 'post_content', absint( $post_id ) ) ) );

		if ( ! $words ) {
			return 0;
		}

		$per_minute = max( 1, (int) apply_filters( 'mvweb_core_reading_speed', 180 ) );

		return max( 1, (int) ceil( $words / $per_minute ) );
	}
}

if ( ! function_exists( 'mvweb_core_related_posts' ) ) {
	/**
	 * The entries that go under an entry: of its category, then of its tags, then the newest.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Entry id.
	 * @param int $limit   How many.
	 *
	 * @return int[]
	 */
	function mvweb_core_related_posts( $post_id, $limit = 3 ) {
		$post_id = absint( $post_id );
		$limit   = absint( $limit );
		$found   = array();
		$stages  = array(
			array( 'category__in' => array_map( 'absint', (array) wp_get_post_categories( $post_id ) ) ),
			array( 'tag__in' => array_map( 'absint', (array) wp_get_post_tags( $post_id, array( 'fields' => 'ids' ) ) ) ),
			array(),
		);

		if ( 0 === $post_id || 0 === $limit ) {
			return array();
		}

		foreach ( $stages as $stage ) {
			if ( count( $found ) >= $limit ) {
				break;
			}

			if ( ! empty( $stage ) && empty( reset( $stage ) ) ) {
				continue;
			}

			$found = array_merge(
				$found,
				array_map(
					'absint',
					get_posts(
						array_merge(
							$stage,
							array(
								'post_type'           => 'post',
								'post_status'         => 'publish',
								'numberposts'         => $limit - count( $found ),
								'fields'              => 'ids',
								'post__not_in'        => array_merge( array( $post_id ), $found ),
								'ignore_sticky_posts' => true,
								'no_found_rows'       => true,
							)
						)
					)
				)
			);
		}

		return $found;
	}
}

if ( ! function_exists( 'mvweb_core_blog_url' ) ) {
	/**
	 * The address of all the articles: the posts page, else the category of the post, else the only category.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Post whose category stands in when the site has no posts page; 0 for none.
	 *
	 * @return string Empty when the site has no such page.
	 */
	function mvweb_core_blog_url( $post_id = 0 ) {
		$page = (int) get_option( 'page_for_posts' );

		if ( $page > 0 ) {
			return (string) get_permalink( $page );
		}

		$terms = $post_id ? get_the_category( $post_id ) : array();

		if ( ! $terms ) {
			$terms = get_categories(
				array(
					'hide_empty' => true,
					'number'     => 2,
				)
			);
			$terms = is_array( $terms ) && 1 === count( $terms ) ? $terms : array();
		}

		$url = $terms ? get_category_link( $terms[0] ) : '';

		return is_string( $url ) ? $url : '';
	}
}

if ( ! function_exists( 'mvweb_core_blog_topics' ) ) {
	/**
	 * The strip of categories: the whole blog, then every category that has entries.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>> Items with label, url and current; empty while the strip is off or has nothing to choose from.
	 */
	function mvweb_core_blog_topics() {
		if ( ! mvweb_core_blog_option( 'mvweb_blog_topics_nav' ) ) {
			return array();
		}

		$terms = get_categories(
			array(
				'hide_empty' => true,
				'orderby'    => 'name',
			)
		);

		if ( ! is_array( $terms ) || count( $terms ) < 2 ) {
			return array();
		}

		$all   = mvweb_core_blog_url();
		$items = array();

		if ( '' !== $all ) {
			$items[] = array(
				'label'   => (string) mvweb_core_blog_option( 'mvweb_blog_all_label' ),
				'url'     => $all,
				'current' => is_home(),
			);
		}

		foreach ( $terms as $term ) {
			$items[] = array(
				'label'   => $term->name,
				'url'     => get_category_link( $term ),
				'current' => is_category() && get_queried_object_id() === (int) $term->term_id,
			);
		}

		return $items;
	}
}

if ( ! function_exists( 'mvweb_core_blog_months' ) ) {
	/**
	 * The strip of the latest months.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>> Items with label, url and current; empty while the strip is off or has nothing to choose from.
	 */
	function mvweb_core_blog_months() {
		if ( ! mvweb_core_blog_option( 'mvweb_blog_months_nav' ) ) {
			return array();
		}

		$html = wp_get_archives(
			array(
				'type'   => 'monthly',
				'format' => 'custom',
				'before' => '',
				'after'  => "\n",
				'limit'  => 12,
				'echo'   => false,
			)
		);

		if ( ! preg_match_all( '#<a href=([\'"])(.+?)\1[^>]*>(.*?)</a>#s', (string) $html, $found, PREG_SET_ORDER ) || count( $found ) < 2 ) {
			return array();
		}

		$current = is_month() ? get_month_link( (int) get_query_var( 'year' ), (int) get_query_var( 'monthnum' ) ) : '';
		$items   = array();

		foreach ( $found as $match ) {
			$items[] = array(
				'label'   => trim( wp_strip_all_tags( $match[3] ) ),
				'url'     => html_entity_decode( $match[2] ),
				'current' => '' !== $current && trailingslashit( $current ) === trailingslashit( html_entity_decode( $match[2] ) ),
			);
		}

		return $items;
	}
}

if ( ! function_exists( 'mvweb_core_blog_archive_facts' ) ) {
	/**
	 * The short facts under the title of a category, a tag or a date.
	 *
	 * @since 0.1.0
	 *
	 * @return string[] Empty for any other page.
	 */
	function mvweb_core_blog_archive_facts() {
		global $wp_query;

		$count = (int) $wp_query->found_posts;
		$facts = array();

		if ( is_category() ) {
			/* translators: %s: number of entries. */
			$facts[] = sprintf( _n( '%s article', '%s articles', $count, 'mvweb-core' ), number_format_i18n( $count ) );

			$latest = get_posts(
				array(
					'post_type'           => 'post',
					'post_status'         => 'publish',
					'cat'                 => get_queried_object_id(),
					'numberposts'         => 1,
					'orderby'             => 'modified',
					'order'               => 'DESC',
					'ignore_sticky_posts' => true,
					'no_found_rows'       => true,
				)
			);

			if ( ! empty( $latest ) ) {
				/* translators: %s: date. */
				$facts[] = sprintf( __( 'Updated %s', 'mvweb-core' ), get_the_modified_date( '', $latest[0] ) );
			}
		} elseif ( is_tag() ) {
			/* translators: %s: number of entries. */
			$facts[] = sprintf( _n( '%s article with this tag', '%s articles with this tag', $count, 'mvweb-core' ), number_format_i18n( $count ) );
		} elseif ( is_day() ) {
			/* translators: %s: number of entries. */
			$facts[] = sprintf( _n( '%s article for the day', '%s articles for the day', $count, 'mvweb-core' ), number_format_i18n( $count ) );
		} elseif ( is_month() ) {
			/* translators: %s: number of entries. */
			$facts[] = sprintf( _n( '%s article for the month', '%s articles for the month', $count, 'mvweb-core' ), number_format_i18n( $count ) );
		} elseif ( is_year() ) {
			/* translators: %s: number of entries. */
			$facts[] = sprintf( _n( '%s article for the year', '%s articles for the year', $count, 'mvweb-core' ), number_format_i18n( $count ) );
		}

		return $facts;
	}
}

if ( ! function_exists( 'mvweb_core_blog_date_title' ) ) {
	/**
	 * The title of the archive of a day, a month or a year.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_blog_date_title() {
		if ( is_day() ) {
			return get_the_date();
		}

		if ( is_month() ) {
			return single_month_title( ' ', false );
		}

		return is_year() ? get_the_date( 'Y' ) : '';
	}
}

if ( ! function_exists( 'mvweb_core_blog_lead' ) ) {
	/**
	 * The plain text under the title of the blog page.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_blog_lead() {
		$page = (int) get_option( 'page_for_posts' );

		return $page > 0 ? trim( wp_strip_all_tags( (string) get_post_field( 'post_excerpt', $page ) ) ) : '';
	}
}

if ( ! function_exists( 'mvweb_core_blog_layout_html' ) ) {
	/**
	 * Print the parts of a layout one by one and keep what each printed.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area name.
	 * @param array  $args Arguments passed to every part template.
	 *
	 * @return array<string,string> Part slug => markup, in the order of the area, empty parts left out.
	 */
	function mvweb_core_blog_layout_html( $area, array $args = array() ) {
		$area = mvweb_core_layout_area( $area );
		$html = array();

		foreach ( mvweb_core_layout_order( $area ) as $slug ) {
			$part = sanitize_key( $slug );

			if ( '' === $part || 0 !== validate_file( 'template-parts/' . $area . '/' . $part ) ) {
				continue;
			}

			ob_start();
			get_template_part( 'template-parts/' . $area . '/' . $part, null, array_merge( $args, array( 'area' => $area ) ) );
			$markup = trim( (string) ob_get_clean() );

			if ( '' !== $markup ) {
				$html[ $part ] = $markup;
			}
		}

		return $html;
	}
}

if ( ! function_exists( 'mvweb_core_blog_toc' ) ) {
	/**
	 * The table of contents of the entry itself: after the first paragraph or above the text.
	 *
	 * @since 0.1.0
	 *
	 * @param string $content Entry text, already formatted.
	 *
	 * @return string
	 */
	function mvweb_core_blog_toc( $content ) {
		if ( get_the_ID() !== get_queried_object_id() ) {
			return $content;
		}

		$content = mvweb_core_toc( $content );

		if ( 'after' !== mvweb_core_blog_option( 'mvweb_toc_position' ) || ! preg_match( '#^\s*<details[^>]*\sdata-toc[^>]*>.*?</details>#s', $content, $toc ) ) {
			return $content;
		}

		$text = substr( $content, strlen( $toc[0] ) );

		$end = strpos( $text, '</p>' );

		return false === $end ? $content : substr_replace( $text, "\n" . trim( $toc[0] ), $end + 4, 0 );
	}
}

if ( ! function_exists( 'mvweb_core_blog_swap_toc' ) ) {
	/**
	 * Put the filter above in place of the one of the core.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_blog_swap_toc() {
		if ( false !== has_filter( 'the_content', 'mvweb_core_toc' ) ) {
			remove_filter( 'the_content', 'mvweb_core_toc', 20 );
			add_filter( 'the_content', 'mvweb_core_blog_toc', 20 );
		}
	}
}
add_action( 'init', 'mvweb_core_blog_swap_toc', 31 );

if ( ! function_exists( 'mvweb_core_blog_comment_consent' ) ) {
	/**
	 * The consent line under the comment form, the link in place.
	 *
	 * @since 0.1.0
	 *
	 * @return string Markup, empty while the site asks for no consent.
	 */
	function mvweb_core_blog_comment_consent() {
		$text = trim( (string) mvweb_core_blog_option( 'mvweb_comment_consent' ) );

		if ( '' === $text ) {
			return '';
		}

		$url  = get_privacy_policy_url();
		$html = esc_html( $text );

		return (string) preg_replace_callback(
			'/\{(.+?)\}/u',
			static function ( $found ) use ( $url ) {
				return '' === $url ? $found[1] : '<a href="' . esc_url( $url ) . '">' . $found[1] . '</a>';
			},
			$html
		);
	}
}

if ( ! function_exists( 'mvweb_core_blog_comment_consent_check' ) ) {
	/**
	 * Refuse a comment sent without the consent the form asks for.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_blog_comment_consent_check() {
		$type = get_post_type( absint( isset( $_POST['comment_post_ID'] ) ? $_POST['comment_post_ID'] : 0 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- A comment form has no nonce: anyone may send one.

		if ( in_array( $type, array( 'product', 'mv_item' ), true ) ) {
			return;
		}

		if ( '' === trim( (string) mvweb_core_blog_option( 'mvweb_comment_consent' ) ) || ! empty( $_POST['mvweb_comment_agree'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- A comment form has no nonce: anyone may send one.
			return;
		}

		wp_die(
			esc_html__( 'Tick the consent to the processing of personal data to send a comment.', 'mvweb-core' ),
			esc_html__( 'Comment not sent', 'mvweb-core' ),
			array(
				'response'  => 400,
				'back_link' => true,
			)
		);
	}
}
add_action( 'pre_comment_on_post', 'mvweb_core_blog_comment_consent_check' );

if ( ! function_exists( 'mvweb_core_blog_style_map' ) ) {
	/**
	 * The sheets the blog pages ask for beyond the ones of the core.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Keys of the request.
	 *
	 * @return string[]
	 */
	function mvweb_core_blog_style_map( $styles ) {
		if ( is_singular( 'post' ) ) {
			array_push( $styles, 'blog', 'pagination' );
		}

		if ( ( is_home() || is_archive() ) && ! have_posts() ) {
			$styles[] = 'empty';
		}

		if ( is_category() && '' !== mvweb_core_term_text( get_queried_object_id() ) ) {
			$styles[] = 'article';
		}

		return array_values( array_unique( $styles ) );
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_core_blog_style_map', 20 );
