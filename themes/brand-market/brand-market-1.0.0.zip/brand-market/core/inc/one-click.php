<?php
/**
 * Order in one click: a name and a phone on the product page make a WooCommerce order.
 *
 * The order is created as a guest order, or for the signed-in customer, in the
 * status "processing", so the shop gets the usual new order e-mail and the stock
 * goes down. The price follows the quantity tiers of the product.
 *
 * @package MVweb_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_one_click' ) ) {
	/**
	 * Whether a product can be ordered in one click.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product|null $product Product.
	 *
	 * @return bool
	 */
	function mvweb_core_one_click( $product = null ) {
		if ( ! mvweb_core_shop_mode() || ! get_theme_mod( 'mvweb_one_click', true ) ) {
			return false;
		}

		return null === $product || ( $product instanceof WC_Product && $product->is_type( 'simple' ) && $product->is_purchasable() && $product->is_in_stock() );
	}
}

if ( ! function_exists( 'mvweb_core_one_click_fields' ) ) {
	/**
	 * The switch of the order in one click.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Customizer Kit.
	 *
	 * @return void
	 */
	function mvweb_core_one_click_fields( $kit ) {
		if ( ! mvweb_core_is_woocommerce() ) {
			return;
		}

		$kit->add_fields(
			array(
				array(
					'type'        => 'toggle',
					'settings'    => 'mvweb_one_click',
					'section'     => 'mvweb_cz_catalog_product',
					'label'       => __( 'Order in one click', 'mvweb-core' ),
					'description' => __( 'A button under “Add to cart”: the visitor leaves a name and a phone, and the shop gets a WooCommerce order with the item and the quantity. Works in the shop mode, for simple products in stock.', 'mvweb-core' ),
					'default'     => true,
				),
			)
		);
	}
}
add_action( 'mvweb_cz_register', 'mvweb_core_one_click_fields' );

if ( ! function_exists( 'mvweb_core_one_click_route' ) ) {
	/**
	 * The route that takes the order.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_one_click_route() {
		register_rest_route(
			'mvweb-core/v1',
			'/one-click',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => 'mvweb_core_one_click_order',
				'permission_callback' => '__return_true',
				'args'                => array(
					'product'  => array(
						'type'     => 'integer',
						'required' => true,
						'minimum'  => 1,
					),
					'quantity' => array(
						'type'    => 'integer',
						'default' => 1,
						'minimum' => 1,
						'maximum' => 100000,
					),
					'name'     => array(
						'type'              => 'string',
						'default'           => '',
						'maxLength'         => 100,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'phone'    => array(
						'type'              => 'string',
						'required'          => true,
						'maxLength'         => 40,
						'sanitize_callback' => 'sanitize_text_field',
					),
					'website'  => array(
						'type'    => 'string',
						'default' => '',
					),
				),
			)
		);
	}
}
add_action( 'rest_api_init', 'mvweb_core_one_click_route' );

if ( ! function_exists( 'mvweb_core_one_click_order' ) ) {
	/**
	 * Check the request and create the order.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_REST_Request $request Request.
	 *
	 * @return WP_REST_Response|WP_Error
	 */
	function mvweb_core_one_click_order( $request ) {
		$product  = function_exists( 'wc_get_product' ) ? wc_get_product( (int) $request->get_param( 'product' ) ) : null;
		$quantity = (int) $request->get_param( 'quantity' );
		$phone    = (string) $request->get_param( 'phone' );
		$digits   = preg_replace( '/\D+/', '', $phone );

		if ( '' !== (string) $request->get_param( 'website' ) ) {
			return rest_ensure_response( array( 'number' => '' ) );
		}

		if ( ! $product || ! mvweb_core_one_click( $product ) ) {
			return new WP_Error( 'mvweb_one_click_product', __( 'This item cannot be ordered in one click.', 'mvweb-core' ), array( 'status' => 400 ) );
		}

		if ( strlen( $digits ) < 10 || strlen( $digits ) > 15 ) {
			return new WP_Error( 'mvweb_one_click_phone', __( 'Enter the phone number with the area code.', 'mvweb-core' ), array( 'status' => 400 ) );
		}

		$error = mvweb_core_quantity_error( $product->get_id(), $quantity );

		if ( '' === $error && ! $product->has_enough_stock( $quantity ) ) {
			/* translators: %d: quantity in stock. */
			$error = sprintf( __( 'Only %d pcs. are in stock.', 'mvweb-core' ), (int) $product->get_stock_quantity() );
		}

		if ( '' !== $error ) {
			return new WP_Error( 'mvweb_one_click_quantity', $error, array( 'status' => 400 ) );
		}

		$ip  = WC_Geolocation::get_ip_address();
		$key = 'mvweb_one_click_' . md5( isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : $ip );

		if ( get_transient( $key ) ) {
			return new WP_Error( 'mvweb_one_click_wait', __( 'The order is already sent. Wait a minute before the next one.', 'mvweb-core' ), array( 'status' => 429 ) );
		}

		set_transient( $key, 1, MINUTE_IN_SECONDS );

		$unit = (string) $product->get_price();
		$tier = mvweb_core_tier_amount( $product->get_id(), $quantity );

		if ( '' !== $tier && ( '' === $unit || (float) $tier < (float) $unit ) ) {
			$unit = $tier;
		}

		$total = wc_get_price_excluding_tax(
			$product,
			array(
				'qty'   => $quantity,
				'price' => $unit,
			)
		);

		$order = wc_create_order(
			array(
				'customer_id' => get_current_user_id(),
				'created_via' => 'one-click',
			)
		);

		if ( is_wp_error( $order ) ) {
			delete_transient( $key );

			return new WP_Error( 'mvweb_one_click_failed', __( 'Could not create the order. Call us, please.', 'mvweb-core' ), array( 'status' => 500 ) );
		}

		$order->add_product(
			$product,
			$quantity,
			array(
				'subtotal' => $total,
				'total'    => $total,
			)
		);
		$order->set_billing_first_name( (string) $request->get_param( 'name' ) );
		$order->set_billing_phone( $phone );
		$order->set_customer_ip_address( $ip );
		$order->calculate_totals();
		$order->update_status( 'processing', __( 'Order in one click from the product page. Call the customer to confirm it.', 'mvweb-core' ) );

		return rest_ensure_response( array( 'number' => $order->get_order_number() ) );
	}
}
