<?php
/**
 * The look of the catalogue listing: cards or a table.
 *
 * Both looks print the same markup, and the look is an attribute of the list,
 * so the visitor switches it at once and the page does not reload. The choice
 * is kept in a cookie that is read here, on the server: the look arrives in
 * the HTML and the list does not jump on load.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'MVWEB_CORE_CATALOG_VIEW_COOKIE' ) ) {
	define( 'MVWEB_CORE_CATALOG_VIEW_COOKIE', 'mvweb_catalog_view' );
}

if ( ! function_exists( 'mvweb_core_catalog_views' ) ) {
	/**
	 * The looks the listing knows.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Slug => label.
	 */
	function mvweb_core_catalog_views() {
		return array(
			'card'  => __( 'Cards', 'mvweb-core' ),
			'table' => __( 'Table', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_catalog_view_switch' ) ) {
	/**
	 * Whether the visitor may switch the look.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_catalog_view_switch() {
		return (bool) get_theme_mod( 'mvweb_catalog_view_switch', true );
	}
}

if ( ! function_exists( 'mvweb_core_catalog_view' ) ) {
	/**
	 * The look of the listing for this request: the visitor's choice when switching is on, the look set in the Customizer otherwise.
	 *
	 * @since 0.1.0
	 *
	 * @return string 'card' or 'table'.
	 */
	function mvweb_core_catalog_view() {
		$views   = mvweb_core_catalog_views();
		$default = (string) get_theme_mod( 'mvweb_catalog_view', 'card' );
		$default = isset( $views[ $default ] ) ? $default : 'card';

		if ( ! mvweb_core_catalog_view_switch() || ! isset( $_COOKIE[ MVWEB_CORE_CATALOG_VIEW_COOKIE ] ) ) {
			return $default;
		}

		$chosen = sanitize_key( wp_unslash( $_COOKIE[ MVWEB_CORE_CATALOG_VIEW_COOKIE ] ) );

		return isset( $views[ $chosen ] ) ? $chosen : $default;
	}
}

if ( ! function_exists( 'mvweb_core_catalog_view_fields' ) ) {
	/**
	 * Customizer fields of the listing look.
	 *
	 * @since 0.1.0
	 *
	 * @param string $section Section the fields go to.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_catalog_view_fields( $section ) {
		return array(
			array(
				'type'        => 'radio',
				'settings'    => 'mvweb_catalog_view',
				'section'     => $section,
				'label'       => __( 'Look of the listing', 'mvweb-core' ),
				'description' => __( 'Cards suit a few items with photos, a table suits a long list with prices and quantities.', 'mvweb-core' ),
				'choices'     => mvweb_core_catalog_views(),
				'default'     => 'card',
			),
			array(
				'type'        => 'toggle',
				'settings'    => 'mvweb_catalog_view_switch',
				'section'     => $section,
				'label'       => __( 'Let the visitor switch the look', 'mvweb-core' ),
				'description' => __( 'Two buttons beside the sorting. The choice is kept for 30 days.', 'mvweb-core' ),
				'default'     => true,
			),
		);
	}
}
