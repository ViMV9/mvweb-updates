<?php
/**
 * Blocks under the content of listings and posts.
 *
 * A category, a service section, a kind of works and a post category carry
 * blocks of their own, built in the same builder as a page. Where a screen has
 * none, and for the screens that have no term to hold them — the shop, the
 * blog, a single post — one page is chosen in the Customizer and its blocks
 * are printed instead.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_section_taxonomies' ) ) {
	/**
	 * The taxonomies whose terms carry blocks.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_section_taxonomies() {
		/**
		 * Filter the taxonomies whose terms carry blocks.
		 *
		 * @since 0.1.0
		 *
		 * @param string[] $taxonomies Taxonomy slugs.
		 */
		$taxonomies = (array) apply_filters( 'mvweb_core_section_taxonomies', array( mvweb_core_taxonomy(), 'mv_service_cat', 'mv_work_type', 'category' ) );

		return array_values( array_filter( array_unique( array_map( 'strval', $taxonomies ) ), 'taxonomy_exists' ) );
	}
}

if ( ! function_exists( 'mvweb_core_register_term_sections_meta' ) ) {
	/**
	 * Register the meta a term keeps its blocks in.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_term_sections_meta() {
		foreach ( mvweb_core_section_taxonomies() as $taxonomy ) {
			register_term_meta(
				$taxonomy,
				'_mvweb_sections',
				array(
					'type'              => 'array',
					'single'            => true,
					'default'           => array(),
					'sanitize_callback' => 'mvweb_core_sanitize_sections',
					'auth_callback'     => 'mvweb_core_term_sections_auth',
					'show_in_rest'      => false,
				)
			);
		}
	}
}
add_action( 'init', 'mvweb_core_register_term_sections_meta', 30 );

if ( ! function_exists( 'mvweb_core_term_sections_auth' ) ) {
	/**
	 * Whether a user may write the blocks of a term.
	 *
	 * @since 0.1.0
	 *
	 * @param bool   $allowed  Current answer.
	 * @param string $meta_key Meta key.
	 * @param int    $term_id  Term the meta belongs to.
	 * @param int    $user_id  User asking.
	 *
	 * @return bool
	 */
	function mvweb_core_term_sections_auth( $allowed, $meta_key, $term_id, $user_id ) {
		return user_can( $user_id, 'edit_term', $term_id );
	}
}

if ( ! function_exists( 'mvweb_core_term_sections' ) ) {
	/**
	 * The blocks saved on a term.
	 *
	 * @since 0.1.0
	 *
	 * @param int $term_id Term id.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_term_sections( $term_id ) {
		$rows = get_term_meta( (int) $term_id, '_mvweb_sections', true );

		return is_array( $rows ) ? $rows : array();
	}
}

if ( ! function_exists( 'mvweb_core_source_contexts' ) ) {
	/**
	 * The screens that print blocks under their content.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Context => label, only for the modules that are on.
	 */
	function mvweb_core_source_contexts() {
		$contexts = array(
			'catalog'       => __( 'Catalogue listing', 'mvweb-core' ),
			'catalog-term'  => __( 'Catalogue category', 'mvweb-core' ),
			'product'       => __( 'Item page', 'mvweb-core' ),
			'services'      => __( 'Services listing', 'mvweb-core' ),
			'services-term' => __( 'Service section', 'mvweb-core' ),
			'works'         => __( 'Works listing', 'mvweb-core' ),
			'works-term'    => __( 'Kind of works', 'mvweb-core' ),
			'work'          => __( 'Work page', 'mvweb-core' ),
			'blog'          => __( 'Blog listing', 'mvweb-core' ),
			'blog-term'     => __( 'Blog category', 'mvweb-core' ),
			'post'          => __( 'Post page', 'mvweb-core' ),
		);

		if ( post_type_exists( 'mv_facet' ) ) {
			$contexts['facet'] = __( 'Filter page', 'mvweb-core' );
		}

		$off = array();

		if ( ! post_type_exists( 'mv_service' ) ) {
			$off = array_merge( $off, array( 'services', 'services-term' ) );
		}

		if ( ! post_type_exists( 'mv_work' ) ) {
			$off = array_merge( $off, array( 'works', 'works-term', 'work' ) );
		}

		return array_diff_key( $contexts, array_flip( $off ) );
	}
}

if ( ! function_exists( 'mvweb_core_source_setting' ) ) {
	/**
	 * The theme_mod key that stores the source page of a context.
	 *
	 * @since 0.1.0
	 *
	 * @param string $context Context.
	 *
	 * @return string
	 */
	function mvweb_core_source_setting( $context ) {
		return 'mvweb_source_' . str_replace( '-', '_', sanitize_key( $context ) );
	}
}

if ( ! function_exists( 'mvweb_core_request_context' ) ) {
	/**
	 * Which screen this request is and what holds its blocks.
	 *
	 * @since 0.1.0
	 *
	 * @return array{context:string,term:int,post:int}
	 */
	function mvweb_core_request_context() {
		$found = array(
			'context' => '',
			'term'    => 0,
			'post'    => 0,
		);

		if ( is_singular( 'post' ) ) {
			$found['context'] = 'post';
		} elseif ( function_exists( 'mvweb_core_is_product' ) && mvweb_core_is_product() ) {
			$found['context'] = 'product';
		} elseif ( is_singular( 'mv_work' ) ) {
			$found['context'] = 'work';
		} elseif ( function_exists( 'mvweb_core_current_facet' ) && mvweb_core_current_facet() ) {
			$found['context'] = 'facet';
			$found['post']    = (int) mvweb_core_current_facet();
		} elseif ( is_tax( 'mv_service_cat' ) ) {
			$found['context'] = 'services-term';
			$found['term']    = get_queried_object_id();
		} elseif ( is_post_type_archive( 'mv_service' ) ) {
			$found['context'] = 'services';
		} elseif ( is_tax( 'mv_work_type' ) ) {
			$found['context'] = 'works-term';
			$found['term']    = get_queried_object_id();
		} elseif ( is_post_type_archive( 'mv_work' ) ) {
			$found['context'] = 'works';
		} elseif ( is_category() ) {
			$found['context'] = 'blog-term';
			$found['term']    = get_queried_object_id();
		} elseif ( is_home() ) {
			$found['context'] = 'blog';
		} elseif ( is_tax( mvweb_core_taxonomy() ) ) {
			$found['context'] = 'catalog-term';
			$found['term']    = get_queried_object_id();
		} elseif ( function_exists( 'mvweb_core_is_catalog' ) && mvweb_core_is_catalog() && ! is_search() ) {
			$found['context'] = 'catalog';
		}

		return $found;
	}
}

if ( ! function_exists( 'mvweb_core_context_sections' ) ) {
	/**
	 * The shown blocks of a screen: its own, else those of the source page.
	 *
	 * @since 0.1.0
	 *
	 * @param string $context Context.
	 * @param int    $term_id Term of the screen, if it has one.
	 * @param int    $post_id Post of the screen, if it has one.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_context_sections( $context, $term_id = 0, $post_id = 0 ) {
		$shown = static function ( array $rows ) {
			return array_values(
				array_filter(
					$rows,
					static function ( $row ) {
						return is_array( $row ) && empty( $row['hidden'] );
					}
				)
			);
		};

		if ( ! isset( mvweb_core_source_contexts()[ $context ] ) || is_paged() ) {
			return array();
		}

		$rows = array();

		if ( $post_id > 0 ) {
			$rows = $shown( mvweb_core_post_sections( $post_id ) );
		} elseif ( $term_id > 0 ) {
			$rows = $shown( mvweb_core_term_sections( $term_id ) );
		}

		if ( empty( $rows ) ) {
			$page = absint( get_theme_mod( mvweb_core_source_setting( $context ), 0 ) );

			if ( $page > 0 && 'publish' === get_post_status( $page ) ) {
				$rows = $shown( mvweb_core_post_sections( $page ) );
			}
		}

		return $rows;
	}
}

if ( ! function_exists( 'mvweb_core_context_rows' ) ) {
	/**
	 * The blocks this request prints under its content.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_context_rows() {
		$request = mvweb_core_request_context();

		return '' === $request['context'] ? array() : mvweb_core_context_sections( $request['context'], $request['term'], $request['post'] );
	}
}

if ( ! function_exists( 'mvweb_core_render_context_sections' ) ) {
	/**
	 * Print the blocks under the content of this screen.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_render_context_sections() {
		mvweb_core_render_sections( mvweb_core_context_rows() );
	}
}

if ( ! function_exists( 'mvweb_core_source_fields' ) ) {
	/**
	 * A page picker for every screen that can print blocks.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_source_fields() {
		$pages = array( 0 => __( 'No blocks', 'mvweb-core' ) );

		$listed = get_pages(
			array(
				'sort_column' => 'post_title',
				'number'      => 200,
			)
		);

		foreach ( $listed as $page ) {
			$pages[ $page->ID ] = get_the_title( $page );
		}

		$fields = array();

		foreach ( mvweb_core_source_contexts() as $context => $label ) {
			$fields[] = array(
				'type'        => 'select',
				'settings'    => mvweb_core_source_setting( $context ),
				'section'     => 'mvweb_cz_inner_source',
				'label'       => $label,
				'description' => __( 'The blocks of this page are printed under the content of the screen. Build the page in the page builder.', 'mvweb-core' ),
				'default'     => 0,
				'choices'     => $pages,
			);
		}

		return $fields;
	}
}

if ( ! function_exists( 'mvweb_core_source_tree' ) ) {
	/**
	 * Put the section of the source pages into the panel of the inner pages.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_source_tree( $tree ) {
		if ( isset( $tree['mvweb_cz_inner'] ) ) {
			$tree['mvweb_cz_inner']['sections']['mvweb_cz_inner_source'] = __( 'Blocks under the content', 'mvweb-core' );
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_source_tree', 98 );

if ( ! function_exists( 'mvweb_core_builder_screen' ) ) {
	/**
	 * Whether the current admin screen carries the builder.
	 *
	 * @since 0.1.0
	 *
	 * @param string $hook Current admin page.
	 *
	 * @return bool
	 */
	function mvweb_core_builder_screen( $hook ) {
		$screen = get_current_screen();

		if ( ! $screen ) {
			return false;
		}

		if ( 'post.php' === $hook || 'post-new.php' === $hook ) {
			return in_array( $screen->post_type, mvweb_core_section_post_types(), true );
		}

		return 'term.php' === $hook && in_array( $screen->taxonomy, mvweb_core_section_taxonomies(), true );
	}
}

if ( ! function_exists( 'mvweb_core_term_builder_hooks' ) ) {
	/**
	 * Hang the builder on the edit screens of the terms.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_term_builder_hooks() {
		foreach ( mvweb_core_section_taxonomies() as $taxonomy ) {
			add_action( $taxonomy . '_edit_form', 'mvweb_core_term_builder_render', 20, 2 );
		}
	}
}
add_action( 'admin_init', 'mvweb_core_term_builder_hooks' );

if ( ! function_exists( 'mvweb_core_term_builder_render' ) ) {
	/**
	 * Print the builder under the fields of a term.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term     Term being edited.
	 * @param string  $taxonomy Taxonomy.
	 *
	 * @return void
	 */
	function mvweb_core_term_builder_render( $term, $taxonomy ) {
		unset( $taxonomy );

		if ( ! current_user_can( 'edit_term', $term->term_id ) ) {
			return;
		}

		wp_nonce_field( 'mvweb_sections_save_term_' . $term->term_id, 'mvweb_sections_nonce' );
		?>
		<h2><?php esc_html_e( 'Blocks under the content', 'mvweb-core' ); ?></h2>
		<p class="description"><?php esc_html_e( 'Printed under the list of this category. Without blocks here, the page chosen in the Customizer is printed instead.', 'mvweb-core' ); ?></p>
		<?php
		mvweb_core_sections_builder( mvweb_core_term_sections( $term->term_id ), (string) get_term_link( $term ) );
	}
}

if ( ! function_exists( 'mvweb_core_term_sections_save' ) ) {
	/**
	 * Store the blocks the builder sent for a term.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $term_id  Term id.
	 * @param int    $tt_id    Term taxonomy id.
	 * @param string $taxonomy Taxonomy.
	 *
	 * @return void
	 */
	function mvweb_core_term_sections_save( $term_id, $tt_id, $taxonomy ) {
		unset( $tt_id );

		if ( ! isset( $_POST['mvweb_sections_nonce'], $_POST['mvweb_sections'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mvweb_sections_nonce'] ) ), 'mvweb_sections_save_term_' . $term_id ) ) {
			return;
		}

		if ( ! in_array( $taxonomy, mvweb_core_section_taxonomies(), true ) || ! current_user_can( 'edit_term', $term_id ) ) {
			return;
		}

		$raw = json_decode( wp_unslash( $_POST['mvweb_sections'] ), true, 10 ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Sanitized by the meta key's sanitize_callback.

		update_term_meta( $term_id, '_mvweb_sections', is_array( $raw ) ? $raw : array() );
	}
}
add_action( 'edited_term', 'mvweb_core_term_sections_save', 10, 3 );

if ( ! function_exists( 'mvweb_core_page_excerpt' ) ) {
	/**
	 * Give pages a short text: the lead under the title of a listing that a page stands for.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_page_excerpt() {
		add_post_type_support( 'page', 'excerpt' );
	}
}
add_action( 'init', 'mvweb_core_page_excerpt' );
