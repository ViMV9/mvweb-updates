<?php
/**
 * Order and visibility of the parts of a page, a card and a block.
 *
 * One scheme for everything that is not a zone of the header or the footer: a
 * layout lists the parts a template can print and stores which of them are
 * shown and in what order. A layout of the whole site is a sortable control in
 * the Customizer, a block keeps its list in its own fields.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_layout_area' ) ) {
	/**
	 * The clean name of a layout area.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Raw area name.
	 *
	 * @return string Lower-case letters, digits, dashes and single dots.
	 */
	function mvweb_core_layout_area( $area ) {
		$area = (string) preg_replace( '/[^a-z0-9.\-]/', '', strtolower( (string) $area ) );

		return false !== strpos( $area, '..' ) || '.' === substr( $area, 0, 1 ) || '.' === substr( $area, -1 ) ? '' : $area;
	}
}

if ( ! function_exists( 'mvweb_core_layouts' ) ) {
	/**
	 * Every registered layout.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>> Area => label, description, panel, section, section title, parts.
	 */
	function mvweb_core_layouts() {
		static $cache = null;

		if ( null !== $cache ) {
			return $cache;
		}

		/**
		 * Filter the layouts of the site.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,array<string,mixed>> $layouts Area => definition; parts is slug => label.
		 */
		$raw     = (array) apply_filters( 'mvweb_core_layouts', array() );
		$layouts = array();

		foreach ( $raw as $area => $layout ) {
			$area = mvweb_core_layout_area( $area );

			if ( '' === $area || ! is_array( $layout ) || empty( $layout['parts'] ) || ! is_array( $layout['parts'] ) ) {
				continue;
			}

			$layouts[ $area ] = wp_parse_args(
				$layout,
				array(
					'label'         => $area,
					'description'   => '',
					'panel'         => '',
					'section'       => '',
					'section_title' => '',
					'parts'         => array(),
				)
			);
		}

		if ( did_action( 'init' ) ) {
			$cache = $layouts;
		}

		return $layouts;
	}
}

if ( ! function_exists( 'mvweb_core_layout_setting' ) ) {
	/**
	 * The theme_mod key that stores the order of a layout.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area name.
	 *
	 * @return string
	 */
	function mvweb_core_layout_setting( $area ) {
		return 'mvweb_layout_' . str_replace( array( '.', '-' ), '_', mvweb_core_layout_area( $area ) );
	}
}

if ( ! function_exists( 'mvweb_core_layout_default_order' ) ) {
	/**
	 * The default order of a layout: every part, in the order of the registry.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area name.
	 *
	 * @return string[]
	 */
	function mvweb_core_layout_default_order( $area ) {
		$layouts = mvweb_core_layouts();

		return isset( $layouts[ $area ] ) ? array_map( 'strval', array_keys( $layouts[ $area ]['parts'] ) ) : array();
	}
}

if ( ! function_exists( 'mvweb_core_layout_order' ) ) {
	/**
	 * The shown parts of a layout, in order.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area name.
	 *
	 * @return string[]
	 */
	function mvweb_core_layout_order( $area ) {
		$layouts = mvweb_core_layouts();
		$area    = mvweb_core_layout_area( $area );

		if ( ! isset( $layouts[ $area ] ) ) {
			return array();
		}

		$order = json_decode( (string) get_theme_mod( mvweb_core_layout_setting( $area ), '' ), true );

		if ( ! is_array( $order ) ) {
			$order = mvweb_core_layout_default_order( $area );
		}

		$known = array_map( 'strval', array_keys( $layouts[ $area ]['parts'] ) );
		$order = array_values(
			array_unique(
				array_filter(
					array_map( 'strval', $order ),
					static function ( $slug ) use ( $known ) {
						return in_array( $slug, $known, true );
					}
				)
			)
		);

		/**
		 * Filter the shown parts of a layout.
		 *
		 * @since 0.1.0
		 *
		 * @param string[] $order Part slugs in order.
		 * @param string   $area  Area name.
		 */
		return array_values( array_map( 'strval', (array) apply_filters( 'mvweb_core_layout_order', $order, $area ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_layout_has' ) ) {
	/**
	 * Whether a layout shows a part.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area name.
	 * @param string $slug Part slug.
	 *
	 * @return bool
	 */
	function mvweb_core_layout_has( $area, $slug ) {
		return in_array( (string) $slug, mvweb_core_layout_order( $area ), true );
	}
}

if ( ! function_exists( 'mvweb_core_render_layout' ) ) {
	/**
	 * Print a layout by walking its shown parts.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area name.
	 * @param array  $args Arguments passed to every part template.
	 *
	 * @return void
	 */
	function mvweb_core_render_layout( $area, array $args = array() ) {
		$area = mvweb_core_layout_area( $area );

		if ( '' === $area ) {
			return;
		}

		$args['area'] = $area;
		$folder       = 'template-parts/' . str_replace( '.', '/', $area ) . '/';

		foreach ( mvweb_core_layout_order( $area ) as $slug ) {
			/**
			 * Short-circuit the print of one part.
			 *
			 * @since 0.1.0
			 *
			 * @param bool   $handled Whether the part has been printed already.
			 * @param string $area    Area name.
			 * @param string $slug    Part slug.
			 * @param array  $args    Print arguments.
			 */
			if ( true === apply_filters( 'mvweb_core_render_part', false, $area, $slug, $args ) ) {
				continue;
			}

			$part = sanitize_key( $slug );

			if ( '' === $part || 0 !== validate_file( $folder . $part ) ) {
				continue;
			}

			get_template_part( $folder . $part, null, $args );
		}
	}
}

if ( ! function_exists( 'mvweb_core_layout_fields' ) ) {
	/**
	 * A sortable control for every layout that names a Customizer section.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_layout_fields() {
		$fields = array();

		foreach ( mvweb_core_layouts() as $area => $layout ) {
			if ( '' === $layout['section'] ) {
				continue;
			}

			$fields[] = array(
				'type'        => 'sortable',
				'settings'    => mvweb_core_layout_setting( $area ),
				'section'     => $layout['section'],
				'label'       => $layout['label'],
				'description' => '' !== $layout['description'] ? $layout['description'] : __( 'Drag to reorder. Untick to hide.', 'mvweb-core' ),
				'choices'     => $layout['parts'],
				'default'     => wp_json_encode( mvweb_core_layout_default_order( $area ) ),
			);
		}

		return $fields;
	}
}

if ( ! function_exists( 'mvweb_core_layout_tree' ) ) {
	/**
	 * Put the sections of the layouts into the panels of the baseline tree.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_layout_tree( $tree ) {
		foreach ( mvweb_core_layouts() as $layout ) {
			$panel   = (string) $layout['panel'];
			$section = (string) $layout['section'];

			if ( '' === $section || '' === $layout['section_title'] || ! isset( $tree[ $panel ] ) || isset( $tree[ $panel ]['sections'][ $section ] ) ) {
				continue;
			}

			$tree[ $panel ]['sections'][ $section ] = $layout['section_title'];
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_layout_tree', 98 );

if ( ! function_exists( 'mvweb_core_section_layout' ) ) {
	/**
	 * The parts a block type lets the editor hide and reorder.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type Block type.
	 *
	 * @return array<string,array<string,string>> Keys parts and item_parts, each slug => label; only, name => views.
	 */
	function mvweb_core_section_layout( $type ) {
		/**
		 * Filter the parts of the block types.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,array<string,array<string,string>>> $table Type => parts, item_parts and only.
		 */
		$table = (array) apply_filters( 'mvweb_core_section_parts', array() );

		return isset( $table[ $type ] ) && is_array( $table[ $type ] ) ? $table[ $type ] : array();
	}
}

if ( ! function_exists( 'mvweb_core_section_parts_fields' ) ) {
	/**
	 * The fields that keep the composition of a block.
	 *
	 * @since 0.1.0
	 *
	 * @param array $layout Result of mvweb_core_section_layout().
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_section_parts_fields( array $layout ) {
		$fields = array();
		$labels = array(
			'parts'      => __( 'Parts of the block', 'mvweb-core' ),
			'item_parts' => __( 'Parts of an item', 'mvweb-core' ),
		);

		foreach ( $labels as $key => $label ) {
			if ( empty( $layout[ $key ] ) || ! is_array( $layout[ $key ] ) ) {
				continue;
			}

			$fields[ $key ] = array(
				'type'        => 'parts',
				'group'       => __( 'Composition', 'mvweb-core' ),
				'label'       => $label,
				'description' => __( 'Drag to reorder. Untick to hide.', 'mvweb-core' ),
				'choices'     => $layout[ $key ],
				'default'     => array_map( 'strval', array_keys( $layout[ $key ] ) ),
			);
		}

		return $fields;
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_parts' ) ) {
	/**
	 * Sanitize the shown parts of a block.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Array of slugs, or its JSON from the Customizer.
	 * @param array $field Normalized field definition.
	 *
	 * @return string[] Known slugs in the given order; the default when the value is no list.
	 */
	function mvweb_core_sanitize_parts( $value, array $field ) {
		if ( is_string( $value ) ) {
			$value = json_decode( $value, true );
		}

		if ( ! is_array( $value ) ) {
			return (array) $field['default'];
		}

		$known = array_map( 'strval', array_keys( (array) $field['choices'] ) );
		$clean = array();

		foreach ( $value as $slug ) {
			if ( is_string( $slug ) && in_array( $slug, $known, true ) && ! in_array( $slug, $clean, true ) ) {
				$clean[] = $slug;
			}
		}

		return $clean;
	}
}

if ( ! function_exists( 'mvweb_core_parts' ) ) {
	/**
	 * The shown parts of a block, in order.
	 *
	 * @since 0.1.0
	 *
	 * @param array  $props Values of the block.
	 * @param string $key   Field: parts for the block, item_parts for one item.
	 *
	 * @return string[]
	 */
	function mvweb_core_parts( array $props, $key = 'parts' ) {
		return isset( $props[ $key ] ) && is_array( $props[ $key ] ) ? array_map( 'strval', $props[ $key ] ) : array();
	}
}

if ( ! function_exists( 'mvweb_core_has_part' ) ) {
	/**
	 * Whether a block shows a part.
	 *
	 * @since 0.1.0
	 *
	 * @param array  $props Values of the block.
	 * @param string $slug  Part slug.
	 * @param string $key   Field: parts or item_parts.
	 *
	 * @return bool
	 */
	function mvweb_core_has_part( array $props, $slug, $key = 'parts' ) {
		return in_array( (string) $slug, mvweb_core_parts( $props, $key ), true );
	}
}

if ( ! function_exists( 'mvweb_core_visible_rows' ) ) {
	/**
	 * The rows of a list that the editor has not hidden.
	 *
	 * @since 0.1.0
	 *
	 * @param array $rows Rows of a repeatable field.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_visible_rows( array $rows ) {
		return array_values(
			array_filter(
				$rows,
				static function ( $row ) {
					return is_array( $row ) && 'hide' !== ( isset( $row['visible'] ) ? $row['visible'] : 'show' );
				}
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_section_view_marks' ) ) {
	/**
	 * Mark the fields, the fields of a list and the parts that work in some views of the block only.
	 *
	 * @since 0.1.0
	 *
	 * @param array $fields Fields of the block.
	 * @param array $layout Result of mvweb_core_section_layout().
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_section_view_marks( array $fields, array $layout ) {
		foreach ( isset( $layout['only'] ) && is_array( $layout['only'] ) ? $layout['only'] : array() as $key => $views ) {
			$views = array_values( array_map( 'strval', (array) $views ) );
			$path  = explode( '.', (string) $key, 2 );

			if ( ! isset( $fields[ $path[0] ] ) || ! is_array( $fields[ $path[0] ] ) ) {
				continue;
			}

			if ( 1 === count( $path ) ) {
				$fields[ $path[0] ]['views'] = $views;
			} elseif ( isset( $fields[ $path[0] ]['type'] ) && 'parts' === $fields[ $path[0] ]['type'] ) {
				$fields[ $path[0] ]['choice_views'][ $path[1] ] = $views;
			} elseif ( isset( $fields[ $path[0] ]['fields'][ $path[1] ] ) ) {
				$fields[ $path[0] ]['fields'][ $path[1] ]['views'] = $views;
			}
		}

		return $fields;
	}
}
