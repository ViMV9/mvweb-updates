<?php
/**
 * The services of the site.
 *
 * Registered whatever the catalogue runs on: WooCommerce sells goods, and the
 * work done around them has never been its business. One base holds the whole
 * tree: the listing, the sections under it and each service under its section.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_register_services' ) ) {
	/**
	 * Register the service type and its sections.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_services() {
		$name = mvweb_core_service_label();
		$base = sanitize_title( (string) mvweb_core_option( 'mvweb_service_slug' ) );
		$base = '' === $base ? 'services' : $base;

		register_taxonomy(
			'mv_service_cat',
			'mv_service',
			array(
				'labels'            => array(
					'name'              => __( 'Service sections', 'mvweb-core' ),
					'singular_name'     => __( 'Section', 'mvweb-core' ),
					'add_new_item'      => __( 'Add section', 'mvweb-core' ),
					'edit_item'         => __( 'Edit section', 'mvweb-core' ),
					'update_item'       => __( 'Update section', 'mvweb-core' ),
					'search_items'      => __( 'Search sections', 'mvweb-core' ),
					'parent_item'       => __( 'Parent section', 'mvweb-core' ),
					'parent_item_colon' => __( 'Parent section:', 'mvweb-core' ),
					'not_found'         => __( 'No sections yet', 'mvweb-core' ),
					'menu_name'         => __( 'Sections', 'mvweb-core' ),
				),
				'hierarchical'      => true,
				'public'            => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'rewrite'           => array(
					'slug'         => $base,
					'with_front'   => false,
					'hierarchical' => true,
				),
			)
		);

		register_post_type(
			'mv_service',
			array(
				'labels'        => array(
					'name'                  => $name,
					'singular_name'         => __( 'Service', 'mvweb-core' ),
					'add_new_item'          => __( 'Add service', 'mvweb-core' ),
					'edit_item'             => __( 'Edit service', 'mvweb-core' ),
					'new_item'              => __( 'New service', 'mvweb-core' ),
					'view_item'             => __( 'View service', 'mvweb-core' ),
					'search_items'          => __( 'Search services', 'mvweb-core' ),
					'not_found'             => __( 'No services yet', 'mvweb-core' ),
					'not_found_in_trash'    => __( 'No services in the bin', 'mvweb-core' ),
					'all_items'             => $name,
					'menu_name'             => $name,
					'featured_image'        => __( 'Main picture', 'mvweb-core' ),
					'set_featured_image'    => __( 'Set the picture', 'mvweb-core' ),
					'remove_featured_image' => __( 'Remove the picture', 'mvweb-core' ),
					'use_featured_image'    => __( 'Use as the picture', 'mvweb-core' ),
				),
				'description'   => __( 'The work the site offers: measurement, installation, repair.', 'mvweb-core' ),
				'public'        => true,
				'show_in_rest'  => true,
				'has_archive'   => $base,
				'rewrite'       => array(
					'slug'       => $base . '/%mv_service_cat%',
					'with_front' => false,
				),
				'menu_icon'     => 'dashicons-hammer',
				'menu_position' => 24,
				'supports'      => array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ),
			)
		);
	}
}
add_action( 'init', 'mvweb_core_register_services' );

if ( ! function_exists( 'mvweb_core_service_term_image_hooks' ) ) {
	/**
	 * Hang the picture field on the section screens.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_service_term_image_hooks() {
		add_action( 'mv_service_cat_add_form_fields', 'mvweb_core_term_image_field' );
		add_action( 'mv_service_cat_edit_form_fields', 'mvweb_core_term_image_edit_field' );
		add_action( 'created_mv_service_cat', 'mvweb_core_term_image_save' );
		add_action( 'edited_mv_service_cat', 'mvweb_core_term_image_save' );
	}
}
add_action( 'init', 'mvweb_core_service_term_image_hooks', 30 );
