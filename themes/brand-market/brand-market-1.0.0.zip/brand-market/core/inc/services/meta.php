<?php
/**
 * Fields of a service.
 *
 * Three of them, and the price shares its key and its sanitizer with the
 * catalogue: a site that prices a fireplace and its installation writes the
 * same kind of number in both places.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_service_meta' ) ) {
	/**
	 * The meta keys of a service and how each is cleaned.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Key => sanitizer.
	 */
	function mvweb_core_service_meta() {
		return array(
			'_mvweb_price'     => 'mvweb_core_sanitize_amount',
			'_mvweb_advantage' => 'sanitize_text_field',
			'_mvweb_gallery'   => 'mvweb_core_sanitize_ids',
		);
	}
}

if ( ! function_exists( 'mvweb_core_register_service_meta' ) ) {
	/**
	 * Register the meta of the service type.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_service_meta() {
		foreach ( mvweb_core_service_meta() as $key => $sanitizer ) {
			register_post_meta(
				'mv_service',
				$key,
				array(
					'type'              => 'string',
					'single'            => true,
					'default'           => '',
					'sanitize_callback' => $sanitizer,
					'auth_callback'     => 'mvweb_core_post_meta_auth',
					'show_in_rest'      => false,
				)
			);
		}
	}
}
add_action( 'init', 'mvweb_core_register_service_meta', 5 );

if ( ! function_exists( 'mvweb_core_service_meta_boxes' ) ) {
	/**
	 * Add the boxes to the service screen.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_service_meta_boxes() {
		add_meta_box(
			'mvweb-core-service',
			__( 'Service', 'mvweb-core' ),
			'mvweb_core_service_box',
			'mv_service',
			'normal',
			'high'
		);

		add_meta_box(
			'mvweb-core-service-gallery',
			__( 'Gallery', 'mvweb-core' ),
			'mvweb_core_service_gallery_box',
			'mv_service',
			'side',
			'low'
		);
	}
}
add_action( 'add_meta_boxes', 'mvweb_core_service_meta_boxes' );

if ( ! function_exists( 'mvweb_core_service_box' ) ) {
	/**
	 * The price and the line that sells the service.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Post being edited.
	 *
	 * @return void
	 */
	function mvweb_core_service_box( $post ) {
		wp_nonce_field( 'mvweb_service', 'mvweb_service_nonce' );

		$price     = (string) get_post_meta( $post->ID, '_mvweb_price', true );
		$advantage = (string) get_post_meta( $post->ID, '_mvweb_advantage', true );
		$empty     = mvweb_core_service_price_placeholder();
		$from      = mvweb_core_service_price_from();
		?>
		<div class="mvweb-core-fields">
			<p class="mvweb-core-field">
				<label for="mvweb-core-service-price"><?php esc_html_e( 'Price', 'mvweb-core' ); ?></label>
				<input class="widefat" type="text" inputmode="decimal" id="mvweb-core-service-price" name="mvweb_price" value="<?php echo esc_attr( $price ); ?>">
				<span class="description">
					<?php
					if ( '' === $empty ) {
						esc_html_e( 'Leave empty to print no price at all.', 'mvweb-core' );
					} else {
						printf(
							/* translators: %s: the wording set in the Customizer. */
							esc_html__( 'Leave empty to print «%s» instead.', 'mvweb-core' ),
							esc_html( $empty )
						);
					}

					if ( '' !== $from ) {
						echo ' ';
						printf(
							/* translators: %s: the word set in the Customizer, for example: from. */
							esc_html__( 'The word «%s» is printed before it.', 'mvweb-core' ),
							esc_html( $from )
						);
					}
					?>
				</span>
			</p>

			<p class="mvweb-core-field">
				<label for="mvweb-core-service-advantage"><?php esc_html_e( 'Line beside the price', 'mvweb-core' ); ?></label>
				<input class="widefat" type="text" id="mvweb-core-service-advantage" name="mvweb_advantage" value="<?php echo esc_attr( $advantage ); ?>">
				<span class="description"><?php esc_html_e( 'What sets this service apart, in a few words: free measurement, two year guarantee.', 'mvweb-core' ); ?></span>
			</p>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_service_gallery_box' ) ) {
	/**
	 * The gallery field.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Post being edited.
	 *
	 * @return void
	 */
	function mvweb_core_service_gallery_box( $post ) {
		$stored = (string) get_post_meta( $post->ID, '_mvweb_gallery', true );
		$ids    = array_filter( array_map( 'absint', explode( ',', $stored ) ) );
		?>
		<div class="mvweb-core-media" data-mvweb-core-media data-mvweb-core-media-multiple="1">
			<span class="mvweb-core-media__preview" data-mvweb-core-media-preview>
				<?php foreach ( $ids as $id ) : ?>
					<?php if ( wp_attachment_is_image( $id ) ) : ?>
						<img src="<?php echo esc_url( (string) wp_get_attachment_image_url( $id, 'thumbnail' ) ); ?>" alt="">
					<?php endif; ?>
				<?php endforeach; ?>
			</span>

			<input type="hidden" name="mvweb_gallery" value="<?php echo esc_attr( implode( ',', $ids ) ); ?>" data-mvweb-core-media-value>

			<button type="button" class="button" data-mvweb-core-media-pick><?php esc_html_e( 'Select', 'mvweb-core' ); ?></button>
			<button type="button" class="button-link" data-mvweb-core-media-clear><?php esc_html_e( 'Remove', 'mvweb-core' ); ?></button>

			<p class="description"><?php esc_html_e( 'The main picture comes first on its own — it is the featured image.', 'mvweb-core' ); ?></p>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_save_service_meta' ) ) {
	/**
	 * Store what the boxes submitted.
	 *
	 * @since 0.1.0
	 *
	 * @param int     $post_id Post being saved.
	 * @param WP_Post $post    Post object.
	 *
	 * @return void
	 */
	function mvweb_core_save_service_meta( $post_id, $post ) {
		if ( 'mv_service' !== $post->post_type ) {
			return;
		}

		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified on the next line.
		if ( ! isset( $_POST['mvweb_service_nonce'] ) ) {
			return;
		}

		check_admin_referer( 'mvweb_service', 'mvweb_service_nonce' );

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		foreach ( array_keys( mvweb_core_service_meta() ) as $key ) {
			$input = 'mvweb_' . substr( $key, strlen( '_mvweb_' ) );

			if ( ! isset( $_POST[ $input ] ) ) {
				continue;
			}

			update_post_meta( $post_id, $key, $_POST[ $input ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- update_post_meta() unslashes and runs the callback the key is registered with.
		}
	}
}
add_action( 'save_post', 'mvweb_core_save_service_meta', 10, 2 );
