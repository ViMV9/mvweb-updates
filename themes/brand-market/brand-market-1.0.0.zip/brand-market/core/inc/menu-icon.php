<?php
/**
 * The icon of a menu item.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_menu_item_icon' ) ) {
	/**
	 * The icon chosen for a menu item.
	 *
	 * @since 0.1.0
	 *
	 * @param int $item_id Menu item id.
	 *
	 * @return string Icon name of the registry; empty when the item has none.
	 */
	function mvweb_core_menu_item_icon( $item_id ) {
		$name = (string) get_post_meta( $item_id, '_mvweb_menu_icon', true );

		return isset( mvweb_core_icon_choices()[ $name ] ) ? $name : '';
	}
}

if ( ! function_exists( 'mvweb_core_menu_icon_field' ) ) {
	/**
	 * The icon field on a menu item.
	 *
	 * @since 0.1.0
	 *
	 * @param int $item_id Menu item id.
	 *
	 * @return void
	 */
	function mvweb_core_menu_icon_field( $item_id ) {
		$current = mvweb_core_menu_item_icon( $item_id );
		?>
		<div class="description description-wide mvweb-core-menu-icon" data-menu-icon>
			<label id="mvweb-core-menu-icon-label-<?php echo (int) $item_id; ?>" for="mvweb-core-menu-icon-<?php echo (int) $item_id; ?>"><?php esc_html_e( 'Icon of the item', 'mvweb-core' ); ?></label>
			<select id="mvweb-core-menu-icon-<?php echo (int) $item_id; ?>" name="mvweb_menu_icon[<?php echo (int) $item_id; ?>]" class="widefat">
				<?php foreach ( mvweb_core_icon_choices() as $name => $label ) : ?>
					<option value="<?php echo esc_attr( $name ); ?>"<?php selected( $current, (string) $name ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
			<span class="description"><?php esc_html_e( 'Shown before the name in the menus, when icons of the menu items are on in the Customizer.', 'mvweb-core' ); ?></span>
		</div>
		<?php
	}
}
add_action( 'wp_nav_menu_item_custom_fields', 'mvweb_core_menu_icon_field', 6 );

if ( ! function_exists( 'mvweb_core_menu_icon_assets' ) ) {
	/**
	 * The icon grid of the menu screen.
	 *
	 * @since 0.1.0
	 *
	 * @param string $hook Current admin screen.
	 *
	 * @return void
	 */
	function mvweb_core_menu_icon_assets( $hook ) {
		if ( 'nav-menus.php' !== $hook ) {
			return;
		}

		$script = mvweb_core_asset_path( '/admin/js/menu-icon.js' );
		$style  = mvweb_core_asset_path( '/admin/css/menu-icon.css' );

		wp_enqueue_style( 'mvweb-core-menu-icon', MVWEB_CORE_URI . $style, array(), mvweb_core_asset_version( $style ) );
		wp_enqueue_script( 'mvweb-core-menu-icon', MVWEB_CORE_URI . $script, array(), mvweb_core_asset_version( $script ), true );
		wp_add_inline_script( 'mvweb-core-menu-icon', 'window.mvwebCoreMenuIcon = ' . wp_json_encode( array( 'find' => __( 'Find an icon', 'mvweb-core' ) ) ) . ';', 'before' );
		add_action( 'admin_footer', 'mvweb_core_print_icon_picker_sprites' );
	}
}
add_action( 'admin_enqueue_scripts', 'mvweb_core_menu_icon_assets' );

if ( ! function_exists( 'mvweb_core_menu_icon_save' ) ) {
	/**
	 * Store the icon of a menu item.
	 *
	 * @since 0.1.0
	 *
	 * @param int $menu_id Menu id.
	 * @param int $item_id Menu item id.
	 *
	 * @return void
	 */
	function mvweb_core_menu_icon_save( $menu_id, $item_id ) {
		unset( $menu_id );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified below, once the field is known to be present.
		if ( ! isset( $_POST['mvweb_menu_icon'][ $item_id ] ) ) {
			return;
		}

		$nonce = isset( $_POST['update-nav-menu-nonce'] ) ? sanitize_key( wp_unslash( $_POST['update-nav-menu-nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'update-nav_menu' ) || ! current_user_can( 'edit_theme_options' ) ) {
			return;
		}

		$name = sanitize_key( wp_unslash( $_POST['mvweb_menu_icon'][ $item_id ] ) );

		if ( '' !== $name && isset( mvweb_core_icon_choices()[ $name ] ) ) {
			update_post_meta( $item_id, '_mvweb_menu_icon', $name );
		} else {
			delete_post_meta( $item_id, '_mvweb_menu_icon' );
		}
	}
}
add_action( 'wp_update_nav_menu_item', 'mvweb_core_menu_icon_save', 10, 2 );
