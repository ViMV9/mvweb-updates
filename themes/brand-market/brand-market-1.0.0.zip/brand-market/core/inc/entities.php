<?php
/**
 * Modules of the entity pages: listings, product, services, works, blog.
 *
 * Every file of inc/entities/ adds what one family of pages needs, so the
 * families do not share a file.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

foreach ( (array) glob( MVWEB_CORE_DIR . '/inc/entities/*.php' ) as $mvweb_core_entity_module ) {
	require_once $mvweb_core_entity_module;
}
unset( $mvweb_core_entity_module );
