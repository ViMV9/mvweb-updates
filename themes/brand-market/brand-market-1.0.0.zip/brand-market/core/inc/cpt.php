<?php
/**
 * Post types the sections draw from.
 *
 * Neither type has a page of its own: a team member and a video review are
 * material for a section, not a destination. They are registered with
 * 'public' => false and the three flags that follow from it spelled out, so a
 * plugin that reads the arguments back sees the intent rather than a default.
 * 'page-attributes' is what gives the editor the order field — a collage and a
 * grid both print in the order the owner arranges, not by date.
 *
 * The slugs stay short on purpose: a post type name is capped at 20 characters
 * by register_post_type(), and mvweb_person would already be 21.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_register_post_types' ) ) {
	/**
	 * Register the team and the video review post types.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_post_types() {
		register_post_type(
			'mv_person',
			array(
				'labels'              => array(
					'name'                  => __( 'Team', 'mvweb-core' ),
					'singular_name'         => __( 'Team member', 'mvweb-core' ),
					'add_new_item'          => __( 'Add team member', 'mvweb-core' ),
					'edit_item'             => __( 'Edit team member', 'mvweb-core' ),
					'new_item'              => __( 'New team member', 'mvweb-core' ),
					'view_item'             => __( 'View team member', 'mvweb-core' ),
					'search_items'          => __( 'Search team', 'mvweb-core' ),
					'not_found'             => __( 'Nobody added yet', 'mvweb-core' ),
					'not_found_in_trash'    => __( 'Nobody in the bin', 'mvweb-core' ),
					'all_items'             => __( 'Team', 'mvweb-core' ),
					'menu_name'             => __( 'Team', 'mvweb-core' ),
					'featured_image'        => __( 'Photo', 'mvweb-core' ),
					'set_featured_image'    => __( 'Set photo', 'mvweb-core' ),
					'remove_featured_image' => __( 'Remove photo', 'mvweb-core' ),
					'use_featured_image'    => __( 'Use as photo', 'mvweb-core' ),
				),
				'description'         => __( 'People the team section prints. No page of their own.', 'mvweb-core' ),
				'public'              => false,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_nav_menus'   => false,
				'show_in_rest'        => false,
				'has_archive'         => false,
				'rewrite'             => false,
				'query_var'           => false,
				'menu_icon'           => 'dashicons-groups',
				'menu_position'       => 26,
				'supports'            => array( 'title', 'thumbnail', 'page-attributes' ),
			)
		);

		register_post_type(
			'mv_video',
			array(
				'labels'              => array(
					'name'                  => __( 'Video reviews', 'mvweb-core' ),
					'singular_name'         => __( 'Video review', 'mvweb-core' ),
					'add_new_item'          => __( 'Add video review', 'mvweb-core' ),
					'edit_item'             => __( 'Edit video review', 'mvweb-core' ),
					'new_item'              => __( 'New video review', 'mvweb-core' ),
					'view_item'             => __( 'View video review', 'mvweb-core' ),
					'search_items'          => __( 'Search video reviews', 'mvweb-core' ),
					'not_found'             => __( 'No video reviews yet', 'mvweb-core' ),
					'not_found_in_trash'    => __( 'No video reviews in the bin', 'mvweb-core' ),
					'all_items'             => __( 'Video reviews', 'mvweb-core' ),
					'menu_name'             => __( 'Video reviews', 'mvweb-core' ),
					'featured_image'        => __( 'Preview', 'mvweb-core' ),
					'set_featured_image'    => __( 'Set preview', 'mvweb-core' ),
					'remove_featured_image' => __( 'Remove preview', 'mvweb-core' ),
					'use_featured_image'    => __( 'Use as preview', 'mvweb-core' ),
				),
				'description'         => __( 'Video reviews the stories section prints. No page of their own.', 'mvweb-core' ),
				'public'              => false,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_nav_menus'   => false,
				'show_in_rest'        => false,
				'has_archive'         => false,
				'rewrite'             => false,
				'query_var'           => false,
				'menu_icon'           => 'dashicons-format-video',
				'menu_position'       => 27,
				'supports'            => array( 'title', 'thumbnail', 'page-attributes' ),
			)
		);
	}
}
add_action( 'init', 'mvweb_core_register_post_types' );

if ( ! function_exists( 'mvweb_core_people' ) ) {
	/**
	 * Published team members, in the order the editor arranged them.
	 *
	 * @since 0.1.0
	 *
	 * @param int $limit How many to return. 0 for all.
	 *
	 * @return WP_Post[]
	 */
	function mvweb_core_people( $limit = 0 ) {
		return get_posts(
			array(
				'post_type'        => 'mv_person',
				'post_status'      => 'publish',
				'numberposts'      => $limit > 0 ? (int) $limit : -1,
				'orderby'          => array(
					'menu_order' => 'ASC',
					'date'       => 'DESC',
				),
				'suppress_filters' => false,
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_videos' ) ) {
	/**
	 * Published video reviews, in the order the editor arranged them.
	 *
	 * @since 0.1.0
	 *
	 * @param int $limit How many to return. 0 for all.
	 *
	 * @return WP_Post[]
	 */
	function mvweb_core_videos( $limit = 0 ) {
		return get_posts(
			array(
				'post_type'        => 'mv_video',
				'post_status'      => 'publish',
				'numberposts'      => $limit > 0 ? (int) $limit : -1,
				'orderby'          => array(
					'menu_order' => 'ASC',
					'date'       => 'DESC',
				),
				'suppress_filters' => false,
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_initials' ) ) {
	/**
	 * Two letters standing in for a photo that was never uploaded.
	 *
	 * @since 0.1.0
	 *
	 * @param string $name Full name.
	 *
	 * @return string
	 */
	function mvweb_core_initials( $name ) {
		$words = preg_split( '/[\s\-]+/u', trim( (string) $name ), -1, PREG_SPLIT_NO_EMPTY );

		if ( empty( $words ) ) {
			return '';
		}

		$words = array_values(
			array_filter(
				array_map(
					static function ( $word ) {
						return preg_replace( '/^[^\p{L}\p{N}]+/u', '', $word );
					},
					$words
				),
				'strlen'
			)
		);

		$letters = '';

		foreach ( array_slice( $words, 0, 2 ) as $word ) {
			$letters .= mb_substr( $word, 0, 1 );
		}

		return $letters;
	}
}
