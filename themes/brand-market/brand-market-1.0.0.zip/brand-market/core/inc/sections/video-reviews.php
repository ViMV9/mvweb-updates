<?php
/**
 * Section type: video reviews.
 *
 * The reviews come from their own records, in the order the editor arranged
 * them there, or from rows of the block itself. A video is only an address:
 * the player of the video site loads when a visitor opens the review, not with
 * the page.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'video-reviews',
	array(
		'label'       => __( 'Video reviews', 'mvweb-core' ),
		'description' => __( 'Video reviews with a cover; the player opens on a click', 'mvweb-core' ),
		'category'    => 'trust',
		'fields'      => mvweb_core_section_head_fields() + array(
			'source' => array(
				'type'    => 'select',
				'label'   => __( 'Where the video reviews come from', 'mvweb-core' ),
				'choices' => array(
					'records' => __( 'Video review records', 'mvweb-core' ),
					'rows'    => __( 'Rows of this block', 'mvweb-core' ),
				),
				'default' => 'records',
			),
			'count'  => array(
				'type'        => 'number',
				'label'       => __( 'How many to show', 'mvweb-core' ),
				'description' => __( 'Zero shows all of them.', 'mvweb-core' ),
				'default'     => 0,
				'min'         => 0,
				'max'         => 24,
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'records' ),
				),
			),
			'items'  => array(
				'type'      => 'repeat',
				'label'     => __( 'Video reviews', 'mvweb-core' ),
				'max'       => 24,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'rows' ),
				),
				'fields'    => array(
					'title'     => array(
						'type'  => 'text',
						'label' => __( 'Title', 'mvweb-core' ),
					),
					'image'     => array(
						'type'        => 'image',
						'label'       => __( 'Cover', 'mvweb-core' ),
						'description' => __( 'A vertical picture 3 by 4 or 9 by 16 fits the layouts best.', 'mvweb-core' ),
					),
					'video_url' => array(
						'type'        => 'url',
						'label'       => __( 'Address of the video', 'mvweb-core' ),
						'description' => __( 'A page of YouTube, Rutube, VK Video or Vimeo, or a link to an mp4 or webm file. Without an address the row is not shown.', 'mvweb-core' ),
					),
					'duration'  => array(
						'type'        => 'text',
						'label'       => __( 'Length', 'mvweb-core' ),
						'description' => __( 'For example 0:48.', 'mvweb-core' ),
					),
					'note'      => array(
						'type'  => 'text',
						'label' => __( 'Line under the title', 'mvweb-core' ),
					),
					'text'      => array(
						'type'        => 'textarea',
						'label'       => __( 'Description', 'mvweb-core' ),
						'description' => __( 'Only the list view shows it.', 'mvweb-core' ),
					),
				),
			),
		),
	)
);
