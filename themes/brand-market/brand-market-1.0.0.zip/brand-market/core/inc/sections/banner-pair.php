<?php
/**
 * Section type: two promo banners side by side.
 *
 * Each banner carries a line above the heading, a heading, a text, a button,
 * two pictures, a running line and, if wanted, a round sticker with the
 * discount. The look of the pair, which one is dark and which one takes the
 * accent, is the theme's.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'banner-pair',
	array(
		'label'       => __( 'Two promo banners', 'mvweb-core' ),
		'description' => __( 'Two offers side by side, with pictures and a sticker', 'mvweb-core' ),
		'category'    => 'intro',
		'fields'      => array(
			'title'   => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'banners' => array(
				'type'   => 'repeat',
				'label'  => __( 'Banners', 'mvweb-core' ),
				'max'    => 2,
				'fields' => array(
					'kicker'      => array(
						'type'  => 'text',
						'label' => __( 'Line above the heading', 'mvweb-core' ),
					),
					'title'       => array(
						'type'  => 'text',
						'label' => __( 'Heading', 'mvweb-core' ),
					),
					'text'        => array(
						'type'  => 'textarea',
						'label' => __( 'Text', 'mvweb-core' ),
					),
					'button_text' => array(
						'type'  => 'text',
						'label' => __( 'Button', 'mvweb-core' ),
					),
					'button_url'  => array(
						'type'  => 'url',
						'label' => __( 'Where the button leads', 'mvweb-core' ),
					),
					'sticker'     => array(
						'type'        => 'text',
						'label'       => __( 'Sticker', 'mvweb-core' ),
						'description' => __( 'A short label in a circle, for example: −10%. The view with a large figure shows it as the figure. Empty hides it.', 'mvweb-core' ),
					),
					'ticker'      => array(
						'type'        => 'text',
						'label'       => __( 'Running line', 'mvweb-core' ),
						'description' => __( 'The line that runs over the picture in the view with a strip. Empty takes the line above the heading and the sticker.', 'mvweb-core' ),
					),
					'until'       => array(
						'type'        => 'text',
						'label'       => __( 'Last day of the offer', 'mvweb-core' ),
						'description' => __( 'In the form 2026-10-31. The next day the banner hides itself.', 'mvweb-core' ),
					),
					'image_1'     => array(
						'type'        => 'image',
						'label'       => __( 'First picture', 'mvweb-core' ),
						'description' => __( 'The picture of the banner. Some views take only this one.', 'mvweb-core' ),
					),
					'image_2'     => array(
						'type'        => 'image',
						'label'       => __( 'Second picture', 'mvweb-core' ),
						'description' => __( 'Used by the views with two pictures.', 'mvweb-core' ),
					),
				),
			),
		),
	)
);
