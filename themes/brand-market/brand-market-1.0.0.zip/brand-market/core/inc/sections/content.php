<?php
/**
 * Section type: text block.
 *
 * The only type that can fall back to the entry itself: left empty it prints
 * post_content, which is how a plain page keeps working after it is switched
 * over to the builder.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'content',
	array(
		'label'       => __( 'Text block', 'mvweb-core' ),
		'description' => __( 'Heading and formatted text', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => array(
			'title'       => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'        => array(
				'type'        => 'richtext',
				'label'       => __( 'Text', 'mvweb-core' ),
				'description' => __( 'Leave empty to print the content of the entry itself.', 'mvweb-core' ),
			),
			'image'       => array(
				'type'        => 'image',
				'label'       => __( 'Picture', 'mvweb-core' ),
				'description' => __( 'The views without a picture ignore it.', 'mvweb-core' ),
			),
			'image_2'     => array(
				'type'        => 'image',
				'label'       => __( 'Second picture', 'mvweb-core' ),
				'description' => __( 'Stands beside the first one in the views that show two.', 'mvweb-core' ),
			),
			'badge_icon'  => array(
				'type'        => 'icon',
				'label'       => __( 'Badge icon', 'mvweb-core' ),
				'description' => __( 'Name from the theme sprite. The badge lies over the picture in the views that have one.', 'mvweb-core' ),
			),
			'badge_title' => array(
				'type'  => 'text',
				'label' => __( 'Badge heading', 'mvweb-core' ),
			),
			'badge_text'  => array(
				'type'  => 'text',
				'label' => __( 'Badge text', 'mvweb-core' ),
			),
			'quote'       => array(
				'type'        => 'textarea',
				'label'       => __( 'Quote', 'mvweb-core' ),
				'description' => __( 'A pull quote beside the text in the views that have a place for it.', 'mvweb-core' ),
			),
			'quote_cite'  => array(
				'type'  => 'text',
				'label' => __( 'Who said it', 'mvweb-core' ),
			),
			'button_text' => array(
				'type'  => 'text',
				'label' => __( 'Button', 'mvweb-core' ),
			),
			'button_url'  => array(
				'type'  => 'url',
				'label' => __( 'Where the button leads', 'mvweb-core' ),
			),
		),
	)
);
