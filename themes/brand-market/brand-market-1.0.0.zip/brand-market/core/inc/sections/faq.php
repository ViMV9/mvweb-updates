<?php
/**
 * Section type: questions and answers.
 *
 * Every answer folds into a native <details>, so the block works before any
 * script and a search on the page finds a closed answer too. The theme prints
 * no FAQ markup for search engines: that is the SEO plugin's job.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'faq',
	array(
		'label'       => __( 'Questions and answers', 'mvweb-core' ),
		'description' => __( 'Questions that open their answers on a click', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => array(
			'kicker'      => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'       => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'        => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'button_text' => array(
				'type'  => 'text',
				'label' => __( 'Button under the text', 'mvweb-core' ),
			),
			'button_url'  => array(
				'type'  => 'url',
				'label' => __( 'Where the button leads', 'mvweb-core' ),
			),
			'open_first'  => array(
				'type'        => 'toggle',
				'label'       => __( 'First question open', 'mvweb-core' ),
				'description' => __( 'The first shown question opens with the page.', 'mvweb-core' ),
				'default'     => true,
			),
			'items'       => array(
				'type'   => 'repeat',
				'label'  => __( 'Questions', 'mvweb-core' ),
				'max'    => 40,
				'fields' => array(
					'icon'   => array(
						'type'        => 'icon',
						'label'       => __( 'Icon', 'mvweb-core' ),
						'description' => __( 'Name from the theme sprite. The view with tiles shows it.', 'mvweb-core' ),
					),
					'title'  => array(
						'type'  => 'text',
						'label' => __( 'Question', 'mvweb-core' ),
					),
					'answer' => array(
						'type'        => 'textarea',
						'label'       => __( 'Answer', 'mvweb-core' ),
						'description' => __( 'A blank line starts a new paragraph.', 'mvweb-core' ),
					),
				),
			),
		),
	)
);
