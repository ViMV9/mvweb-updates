<?php
/**
 * Section type: plans side by side.
 *
 * What a plan includes is one line per item in a text box; a line that starts
 * with a minus is an item the plan leaves out, printed struck through. A plan
 * with a badge is the one the site recommends and stands out in the row. A plan
 * with a yearly price lets the visitor switch between paying by the month and
 * by the year.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'plans',
	array(
		'label'       => __( 'Plans', 'mvweb-core' ),
		'description' => __( 'Two to four plans with a price and what they include', 'mvweb-core' ),
		'category'    => 'prices',
		'fields'      => mvweb_core_section_head_fields() + array(
			'period_month'     => array(
				'group'       => __( 'Monthly or yearly switch', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Monthly payment', 'mvweb-core' ),
				'description' => __( 'The switch shows when a plan has a yearly price and the view has one.', 'mvweb-core' ),
				'default'     => __( 'Monthly', 'mvweb-core' ),
			),
			'period_year'      => array(
				'group'   => __( 'Monthly or yearly switch', 'mvweb-core' ),
				'type'    => 'text',
				'label'   => __( 'Yearly payment', 'mvweb-core' ),
				'default' => __( 'Yearly', 'mvweb-core' ),
			),
			'period_year_note' => array(
				'group'       => __( 'Monthly or yearly switch', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Saving beside the yearly payment', 'mvweb-core' ),
				'description' => __( 'For example, minus 20%.', 'mvweb-core' ),
			),
			'plans'            => array(
				'type'   => 'repeat',
				'label'  => __( 'Plans', 'mvweb-core' ),
				'max'    => 4,
				'fields' => array(
					'title'       => array(
						'type'  => 'text',
						'label' => __( 'Plan name', 'mvweb-core' ),
					),
					'badge'       => array(
						'type'        => 'text',
						'label'       => __( 'Badge that singles the plan out', 'mvweb-core' ),
						'description' => __( 'A plan with a badge stands out in the row even when the badge itself is hidden.', 'mvweb-core' ),
					),
					'text'        => array(
						'type'  => 'text',
						'label' => __( 'Line under the name', 'mvweb-core' ),
					),
					'price'       => array(
						'type'  => 'text',
						'label' => __( 'Price', 'mvweb-core' ),
					),
					'unit'        => array(
						'type'  => 'text',
						'label' => __( 'Per what', 'mvweb-core' ),
					),
					'note_month'  => array(
						'type'  => 'text',
						'label' => __( 'Note under the monthly price', 'mvweb-core' ),
					),
					'price_year'  => array(
						'type'        => 'text',
						'label'       => __( 'Price when paying for a year', 'mvweb-core' ),
						'description' => __( 'Empty keeps the plan on the same price in both positions of the switch.', 'mvweb-core' ),
					),
					'unit_year'   => array(
						'type'  => 'text',
						'label' => __( 'Per what, when paying for a year', 'mvweb-core' ),
					),
					'note_year'   => array(
						'type'  => 'text',
						'label' => __( 'Note under the yearly price', 'mvweb-core' ),
					),
					'items'       => array(
						'type'  => 'textarea',
						'label' => __( 'What is included, one per line; a minus in front marks what is not', 'mvweb-core' ),
					),
					'button_text' => array(
						'type'        => 'text',
						'label'       => __( 'Button', 'mvweb-core' ),
						'description' => __( 'Shown together with the address it leads to.', 'mvweb-core' ),
					),
					'button_url'  => array(
						'type'  => 'url',
						'label' => __( 'Where the button leads', 'mvweb-core' ),
					),
				),
			),
		),
	)
);
