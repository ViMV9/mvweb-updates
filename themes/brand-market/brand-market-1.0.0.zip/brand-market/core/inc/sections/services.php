<?php
/**
 * Section type: list of services.
 *
 * Services with an icon or a picture, a short text, the price from and a link.
 * The list is filled in by hand or taken from the services of the site or from
 * their sections; the look is a view of the theme.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'services',
	array(
		'label'       => __( 'Services', 'mvweb-core' ),
		'description' => __( 'Cards, rows or tabs with an icon, a text and the price from', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => array(
			'kicker'    => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'     => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'      => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'source'    => array(
				'type'    => 'select',
				'label'   => __( 'What to show', 'mvweb-core' ),
				'choices' => array(
					'manual'      => __( 'The list below', 'mvweb-core' ),
					'service_cat' => __( 'Service sections', 'mvweb-core' ),
					'service'     => __( 'Services', 'mvweb-core' ),
				),
				'default' => 'manual',
			),
			'section'   => array(
				'type'        => 'category',
				'taxonomy'    => 'mv_service_cat',
				'label'       => __( 'Section of services', 'mvweb-core' ),
				'description' => __( 'Only the services of this section and its subsections. All takes every service.', 'mvweb-core' ),
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'service' ),
				),
			),
			'count'     => array(
				'type'        => 'number',
				'label'       => __( 'How many', 'mvweb-core' ),
				'description' => __( 'Sections or services to show. The view with tabs takes this many sections.', 'mvweb-core' ),
				'default'     => 6,
				'min'         => 1,
				'max'         => 24,
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'service_cat', 'service' ),
				),
			),
			'items'     => array(
				'type'        => 'repeat',
				'label'       => __( 'Services', 'mvweb-core' ),
				'description' => __( 'The view with a large card takes the first shown row for it.', 'mvweb-core' ),
				'max'         => 24,
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'manual' ),
				),
				'fields'      => array(
					'icon'  => array(
						'type'        => 'icon',
						'label'       => __( 'Icon', 'mvweb-core' ),
						'description' => __( 'Name from the theme sprite. The views with cards and with tabs show it.', 'mvweb-core' ),
					),
					'image' => array(
						'type'        => 'image',
						'label'       => __( 'Picture', 'mvweb-core' ),
						'description' => __( 'The views with photos and with a large card show it.', 'mvweb-core' ),
					),
					'title' => array(
						'type'  => 'text',
						'label' => __( 'Name', 'mvweb-core' ),
					),
					'text'  => array(
						'type'  => 'textarea',
						'label' => __( 'Short text', 'mvweb-core' ),
					),
					'price' => array(
						'type'        => 'text',
						'label'       => __( 'Price', 'mvweb-core' ),
						'description' => __( 'The number with the unit, for example 700 ₽/m². The word before it is set for all services in the Customizer.', 'mvweb-core' ),
					),
					'url'   => array(
						'type'  => 'url',
						'label' => __( 'Link', 'mvweb-core' ),
					),
					'group' => array(
						'type'        => 'text',
						'label'       => __( 'Tab', 'mvweb-core' ),
						'description' => __( 'The view with tabs puts the service under the tab of this name. Rows with the same name share a tab, twelve tabs at most.', 'mvweb-core' ),
					),
				),
			),
			'link_text' => array(
				'type'    => 'text',
				'label'   => __( 'Link under the list', 'mvweb-core' ),
				'default' => __( 'All services', 'mvweb-core' ),
			),
			'link_url'  => array(
				'type'  => 'url',
				'label' => __( 'Where that link leads', 'mvweb-core' ),
			),
		),
	)
);
