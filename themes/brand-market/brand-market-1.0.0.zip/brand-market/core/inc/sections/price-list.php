<?php
/**
 * Section type: a price list.
 *
 * Rows are flat on purpose: a row without a price is the heading of the group
 * under it. Groups of rows inside rows would be a list inside a list, which
 * the homepage's repeater cannot draw, and an editor reads the flat form as
 * a plain price sheet anyway. Up to three price columns cover a barbershop
 * that prices by the grade of the master. A group heading may carry its own
 * column names, button and footnote, the way tabs by kind of pet need.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'price-list',
	array(
		'label'       => __( 'Price list', 'mvweb-core' ),
		'description' => __( 'Services and prices, in groups and up to three columns', 'mvweb-core' ),
		'category'    => 'prices',
		'fields'      => mvweb_core_section_head_fields() + array(
			'col_0'       => array(
				'group'       => __( 'Price columns', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Column of names', 'mvweb-core' ),
				'description' => __( 'The heading over the names of the services, for example: Service. The table head shows when any column has a name.', 'mvweb-core' ),
			),
			'col_1'       => array(
				'group'       => __( 'Price columns', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'First column', 'mvweb-core' ),
				'description' => __( 'Fill in the names only when there are two or three prices a row, for example: barber, senior, chief.', 'mvweb-core' ),
			),
			'col_2'       => array(
				'group' => __( 'Price columns', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Second column', 'mvweb-core' ),
			),
			'col_3'       => array(
				'group' => __( 'Price columns', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Third column', 'mvweb-core' ),
			),
			'rows'        => array(
				'type'        => 'repeat',
				'label'       => __( 'Rows', 'mvweb-core' ),
				'description' => __( 'A row without a price becomes the heading of the group below it.', 'mvweb-core' ),
				'max'         => 120,
				'fields'      => array(
					'title'       => array(
						'type'  => 'text',
						'label' => __( 'Service or group', 'mvweb-core' ),
					),
					'note'        => array(
						'type'        => 'text',
						'label'       => __( 'Note under the name', 'mvweb-core' ),
						'description' => __( 'On a group heading: the line beside a folded group, for example from 500.', 'mvweb-core' ),
					),
					'price_1'     => array(
						'type'  => 'text',
						'label' => __( 'Price', 'mvweb-core' ),
					),
					'price_2'     => array(
						'type'  => 'text',
						'label' => __( 'Price, second column', 'mvweb-core' ),
					),
					'price_3'     => array(
						'type'  => 'text',
						'label' => __( 'Price, third column', 'mvweb-core' ),
					),
					'icon'        => array(
						'type'        => 'icon',
						'label'       => __( 'Group icon', 'mvweb-core' ),
						'description' => __( 'Only on a group heading. Views with cards show it.', 'mvweb-core' ),
					),
					'col_1'       => array(
						'type'        => 'text',
						'label'       => __( 'Group: first column', 'mvweb-core' ),
						'description' => __( 'Only on a group heading. Column names of this group in the tabs view; empty takes the block\'s.', 'mvweb-core' ),
					),
					'col_2'       => array(
						'type'  => 'text',
						'label' => __( 'Group: second column', 'mvweb-core' ),
					),
					'col_3'       => array(
						'type'  => 'text',
						'label' => __( 'Group: third column', 'mvweb-core' ),
					),
					'button_text' => array(
						'type'        => 'text',
						'label'       => __( 'Group: button', 'mvweb-core' ),
						'description' => __( 'Only on a group heading. The button of this tab; empty takes the block\'s.', 'mvweb-core' ),
					),
					'button_url'  => array(
						'type'  => 'url',
						'label' => __( 'Group: where the button leads', 'mvweb-core' ),
					),
					'footnote'    => array(
						'type'  => 'text',
						'label' => __( 'Group: line beside the button', 'mvweb-core' ),
					),
				),
			),
			'button_text' => array(
				'group' => __( 'Under the list', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Button', 'mvweb-core' ),
			),
			'button_url'  => array(
				'group' => __( 'Under the list', 'mvweb-core' ),
				'type'  => 'url',
				'label' => __( 'Where the button leads', 'mvweb-core' ),
			),
			'footnote'    => array(
				'group' => __( 'Under the list', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Line beside the button', 'mvweb-core' ),
			),
		),
	)
);
