<?php
/**
 * Section type: written reviews with the ratings of review sites.
 *
 * The reviews come from two places: rows typed into the block itself, or the
 * reviews the works of the portfolio carry. The ratings of the sites are
 * always rows of the block.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'reviews',
	array(
		'label'       => __( 'Reviews', 'mvweb-core' ),
		'description' => __( 'Written reviews and ratings on review sites', 'mvweb-core' ),
		'category'    => 'trust',
		'fields'      => mvweb_core_section_head_fields() + array(
			'source'        => array(
				'type'    => 'select',
				'label'   => __( 'Where the reviews come from', 'mvweb-core' ),
				'choices' => array(
					'own'   => __( 'Rows of this block', 'mvweb-core' ),
					'works' => __( 'Reviews of the works in the portfolio', 'mvweb-core' ),
				),
				'default' => 'own',
			),
			'works_count'   => array(
				'type'        => 'number',
				'label'       => __( 'How many reviews of works to show', 'mvweb-core' ),
				'description' => __( 'Works without a review are skipped. The author and the review are filled in on the work.', 'mvweb-core' ),
				'default'     => 6,
				'min'         => 1,
				'max'         => 24,
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'works' ),
				),
			),
			'ratings_title' => array(
				'type'    => 'text',
				'label'   => __( 'Title of the ratings', 'mvweb-core' ),
				'default' => __( 'Ratings on review sites', 'mvweb-core' ),
			),
			'ratings'       => array(
				'type'        => 'repeat',
				'label'       => __( 'Ratings', 'mvweb-core' ),
				'description' => __( 'For example: Yandex Maps, 4.9, 1,240 ratings.', 'mvweb-core' ),
				'max'         => 6,
				'fields'      => array(
					'title' => array(
						'type'  => 'text',
						'label' => __( 'Site', 'mvweb-core' ),
					),
					'score' => array(
						'type'  => 'text',
						'label' => __( 'Score', 'mvweb-core' ),
					),
					'note'  => array(
						'type'  => 'text',
						'label' => __( 'Line under the site', 'mvweb-core' ),
					),
					'url'   => array(
						'type'  => 'url',
						'label' => __( 'Page with the reviews', 'mvweb-core' ),
					),
				),
			),
			'items'         => array(
				'type'      => 'repeat',
				'label'     => __( 'Reviews', 'mvweb-core' ),
				'max'       => 40,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'own' ),
				),
				'fields'    => array(
					'title'  => array(
						'type'  => 'text',
						'label' => __( 'Name', 'mvweb-core' ),
					),
					'text'   => array(
						'type'  => 'textarea',
						'label' => __( 'Review', 'mvweb-core' ),
					),
					'source' => array(
						'type'  => 'text',
						'label' => __( 'Where it was left and when', 'mvweb-core' ),
					),
					'stars'  => array(
						'type'    => 'select',
						'label'   => __( 'Stars', 'mvweb-core' ),
						'choices' => array(
							'five'  => '5',
							'four'  => '4',
							'three' => '3',
							'none'  => __( 'None', 'mvweb-core' ),
						),
						'default' => 'five',
					),
					'photo'  => array(
						'type'        => 'image',
						'label'       => __( 'Photo', 'mvweb-core' ),
						'description' => __( 'Without a photo the initials of the name stand in its place.', 'mvweb-core' ),
					),
				),
			),
		),
	)
);
