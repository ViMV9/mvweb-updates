<?php
/**
 * Section type: the branches of a business.
 *
 * The block holds no addresses of its own. It lists the branches of the city
 * the visitor has chosen, with what each branch has: the photo, the address and
 * the landmark, the phones, the hours, the map and the links to book a visit and
 * to build a route. Without branches it shows the address of the company
 * details. The block adds only the words around them.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'branches',
	array(
		'label'       => __( 'Branches', 'mvweb-core' ),
		'description' => __( 'The addresses of the chosen city with hours, phone, map and links', 'mvweb-core' ),
		'category'    => 'contact',
		'fields'      => array(
			'kicker'      => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'       => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'        => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'book_text'   => array(
				'type'        => 'text',
				'label'       => __( 'Booking button', 'mvweb-core' ),
				'description' => __( 'The button appears when the branch has a link to book a visit.', 'mvweb-core' ),
				'default'     => __( 'Book', 'mvweb-core' ),
			),
			'route_text'  => array(
				'type'        => 'text',
				'label'       => __( 'Route button', 'mvweb-core' ),
				'description' => __( 'The button appears when the branch has a link to the route or to the map.', 'mvweb-core' ),
				'default'     => __( 'Route', 'mvweb-core' ),
			),
			'status_text' => array(
				'type'        => 'text',
				'label'       => __( 'Status label', 'mvweb-core' ),
				'description' => __( 'A short line with a pulsing dot, the same for every branch. Empty prints nothing.', 'mvweb-core' ),
			),
		),
	)
);
