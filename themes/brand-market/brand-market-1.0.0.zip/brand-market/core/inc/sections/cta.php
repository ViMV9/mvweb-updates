<?php
/**
 * Section type: a closing card with one call to action.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'cta',
	array(
		'label'       => __( 'Call to action', 'mvweb-core' ),
		'description' => __( 'A card with a call and a button', 'mvweb-core' ),
		'category'    => 'contact',
		'fields'      => array(
			'kicker'        => array(
				'type'        => 'text',
				'label'       => __( 'Line above the heading', 'mvweb-core' ),
				'description' => __( 'A short label or status.', 'mvweb-core' ),
			),
			'title'         => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'          => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'button_text'   => array(
				'type'  => 'text',
				'label' => __( 'Button', 'mvweb-core' ),
			),
			'button_url'    => array(
				'type'  => 'url',
				'label' => __( 'Where the button leads', 'mvweb-core' ),
			),
			'phone_label'   => array(
				'type'        => 'text',
				'label'       => __( 'Words before the phone', 'mvweb-core' ),
				'description' => __( 'The number itself comes from the contacts of the site and follows the chosen city.', 'mvweb-core' ),
				'default'     => __( 'Call:', 'mvweb-core' ),
			),
			'icon'          => array(
				'type'        => 'icon',
				'label'       => __( 'Icon', 'mvweb-core' ),
				'description' => __( 'The view with two halves draws it large behind the text.', 'mvweb-core' ),
			),
			'image'         => array(
				'type'        => 'image',
				'label'       => __( 'Picture', 'mvweb-core' ),
				'description' => __( 'Only the view with a photo shows it.', 'mvweb-core' ),
			),
			'badge'         => array(
				'type'        => 'text',
				'label'       => __( 'Label on the picture', 'mvweb-core' ),
				'description' => __( 'Only the view with a photo shows it.', 'mvweb-core' ),
			),
			'ticker'        => array(
				'type'        => 'textarea',
				'label'       => __( 'Words of the running line', 'mvweb-core' ),
				'description' => __( 'One per line. Only the view with the large type shows them.', 'mvweb-core' ),
			),
			'second_icon'   => array(
				'group' => __( 'Second half', 'mvweb-core' ),
				'type'  => 'icon',
				'label' => __( 'Icon', 'mvweb-core' ),
			),
			'second_kicker' => array(
				'group' => __( 'Second half', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'second_title'  => array(
				'group'       => __( 'Second half', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Heading', 'mvweb-core' ),
				'description' => __( 'The view with two halves prints the second one only when it has a heading.', 'mvweb-core' ),
			),
			'second_text'   => array(
				'group' => __( 'Second half', 'mvweb-core' ),
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'second_button' => array(
				'group' => __( 'Second half', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Button', 'mvweb-core' ),
			),
			'second_url'    => array(
				'group' => __( 'Second half', 'mvweb-core' ),
				'type'  => 'url',
				'label' => __( 'Where the button leads', 'mvweb-core' ),
			),
			'second_phone'  => array(
				'group'   => __( 'Second half', 'mvweb-core' ),
				'type'    => 'toggle',
				'label'   => __( 'Show the phone', 'mvweb-core' ),
				'default' => false,
			),
		),
	)
);
