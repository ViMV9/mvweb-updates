<?php
/**
 * Section type: how the work is done, step by step.
 *
 * One list of steps; the view sets how it is drawn: cards with a photo, cards
 * with numbers, a timeline, stairs, large numbers in rows.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'steps',
	array(
		'label'       => __( 'Stages', 'mvweb-core' ),
		'description' => __( 'Stages with photos or numbers', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => array(
			'title' => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'  => array(
				'type'  => 'textarea',
				'label' => __( 'Lead', 'mvweb-core' ),
			),
			'items' => array(
				'type'   => 'repeat',
				'label'  => __( 'Steps', 'mvweb-core' ),
				'max'    => 8,
				'fields' => array(
					'image' => array(
						'type'        => 'image',
						'label'       => __( 'Photo', 'mvweb-core' ),
						'description' => __( 'The first view only.', 'mvweb-core' ),
					),
					'title' => array(
						'type'  => 'text',
						'label' => __( 'Step heading', 'mvweb-core' ),
					),
					'text'  => array(
						'type'  => 'textarea',
						'label' => __( 'Text', 'mvweb-core' ),
					),
				),
			),
		),
	)
);
