<?php
/**
 * Section type: what the company is good at.
 *
 * One list of blocks with an icon, a heading and lines of text; the view sets
 * how the list is drawn. A banner or a photo stands beside the head in the
 * views that have room for it.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'features',
	array(
		'label'       => __( 'Advantages', 'mvweb-core' ),
		'description' => __( 'A row or a grid of short blocks with an icon', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => mvweb_core_cards_colour_fields() + array(
			'kicker' => array(
				'type'  => 'text',
				'label' => __( 'Kicker', 'mvweb-core' ),
			),
			'title'  => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'   => array(
				'type'  => 'textarea',
				'label' => __( 'Lead', 'mvweb-core' ),
			),
			'image'  => array(
				'type'        => 'image',
				'label'       => __( 'Picture', 'mvweb-core' ),
				'description' => __( 'A banner under the head in the first view, a photo under the head in the last one. The other views do not show it.', 'mvweb-core' ),
				'default'     => 0,
			),
			'blocks' => array(
				'type'   => 'repeat',
				'label'  => __( 'Blocks', 'mvweb-core' ),
				'max'    => 8,
				'fields' => array(
					'icon'  => array(
						'type'        => 'icon',
						'label'       => __( 'Icon', 'mvweb-core' ),
						'description' => __( 'Name from the theme sprite, for example tools or clock. The numbered view shows a number instead.', 'mvweb-core' ),
					),
					'title' => array(
						'type'        => 'text',
						'label'       => __( 'Block heading', 'mvweb-core' ),
						'description' => __( 'The strip view shows only this line as a short fact.', 'mvweb-core' ),
					),
					'text'  => array(
						'type'        => 'textarea',
						'label'       => __( 'Lines', 'mvweb-core' ),
						'description' => __( 'One per line. The first view prints them as a list, the others as a paragraph.', 'mvweb-core' ),
					),
				),
			),
		),
	)
);
