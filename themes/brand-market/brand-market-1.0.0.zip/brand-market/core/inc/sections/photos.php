<?php
/**
 * Section type: photographs with captions.
 *
 * The look of the photographs is the view the theme draws, not a field of the
 * block: a mosaic, columns, a stage with a strip of thumbnails, strips, two
 * running reels. A photograph can lead to a page of its own.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'photos',
	array(
		'label'       => __( 'Photo tiles', 'mvweb-core' ),
		'description' => __( 'Photographs with captions', 'mvweb-core' ),
		'category'    => 'catalog',
		'fields'      => array(
			'kicker' => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'  => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'   => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'items'  => array(
				'type'        => 'repeat',
				'label'       => __( 'Photographs', 'mvweb-core' ),
				'description' => __( 'The view with a stage shows the first eight.', 'mvweb-core' ),
				'max'         => 40,
				'fields'      => array(
					'image'   => array(
						'type'  => 'image',
						'label' => __( 'Photograph', 'mvweb-core' ),
					),
					'caption' => array(
						'type'  => 'text',
						'label' => __( 'Caption', 'mvweb-core' ),
					),
					'url'     => array(
						'type'        => 'url',
						'label'       => __( 'Where the photograph leads', 'mvweb-core' ),
						'description' => __( 'Empty leaves the photograph without a link. The stage does not link.', 'mvweb-core' ),
					),
					'size'    => array(
						'type'        => 'select',
						'label'       => __( 'Photograph shape', 'mvweb-core' ),
						'description' => __( 'The mosaic and the columns use it; the other views cut every photograph the same way.', 'mvweb-core' ),
						'default'     => 'normal',
						'choices'     => array(
							'normal' => __( 'Usual', 'mvweb-core' ),
							'tall'   => __( 'Tall', 'mvweb-core' ),
							'square' => __( 'Square', 'mvweb-core' ),
						),
					),
				),
			),
		),
	)
);
