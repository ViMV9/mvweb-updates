<?php
/**
 * Section type: where to find us and whom to call.
 *
 * The block holds no contacts of its own. The phones, the e-mail, the addresses,
 * the hours and the map are those of the city the visitor has chosen: they come
 * from the branches, and from the company details while there are no branches.
 * The messengers come from the company details. The block adds only the words
 * around them.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'contacts',
	array(
		'label'       => __( 'Contacts', 'mvweb-core' ),
		'description' => __( 'Phone, e-mail, address, hours, messengers and a map of the chosen city', 'mvweb-core' ),
		'category'    => 'contact',
		'fields'      => array(
			'kicker'      => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'       => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'        => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'phone_note'  => array(
				'type'        => 'text',
				'label'       => __( 'Note under the phone', 'mvweb-core' ),
				'description' => __( 'A phone that has a caption in the branch shows the caption instead.', 'mvweb-core' ),
			),
			'email_note'  => array(
				'type'  => 'text',
				'label' => __( 'Note under the e-mail', 'mvweb-core' ),
			),
			'hours_note'  => array(
				'type'  => 'text',
				'label' => __( 'Note under the opening hours', 'mvweb-core' ),
			),
			'chats_title' => array(
				'type'        => 'text',
				'label'       => __( 'Heading above the messengers', 'mvweb-core' ),
				'description' => __( 'The chat links come from the company details.', 'mvweb-core' ),
				'default'     => __( 'Write to a messenger', 'mvweb-core' ),
			),
			'chats_lead'  => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading of the messengers', 'mvweb-core' ),
			),
			'map_title'   => array(
				'type'        => 'text',
				'label'       => __( 'Heading of the map card', 'mvweb-core' ),
				'description' => __( 'The map itself is the map of the branch of the city, else the map of the company details.', 'mvweb-core' ),
			),
			'map_text'    => array(
				'type'  => 'textarea',
				'label' => __( 'Text of the map card', 'mvweb-core' ),
			),
			'map_button'  => array(
				'type'        => 'text',
				'label'       => __( 'Map button', 'mvweb-core' ),
				'description' => __( 'The button appears when the branch has a link to the map.', 'mvweb-core' ),
				'default'     => __( 'Open in maps', 'mvweb-core' ),
			),
		),
	)
);
