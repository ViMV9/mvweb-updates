<?php
/**
 * Section type: two lists side by side.
 *
 * Indications and contraindications, what the price includes and what it
 * does not, what the client brings and what the company does: a pair of
 * lists the reader compares at a glance.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'two-lists',
	array(
		'label'       => __( 'Two lists', 'mvweb-core' ),
		'description' => __( 'Two lists side by side: yes and no, included and not', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => array(
			'kicker'      => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'       => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'        => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'marks'       => array(
				'type'    => 'select',
				'label'   => __( 'Marks', 'mvweb-core' ),
				'choices' => array(
					'yes-no'  => __( 'Tick and cross', 'mvweb-core' ),
					'yes-yes' => __( 'Ticks in both', 'mvweb-core' ),
				),
				'default' => 'yes-no',
			),
			'left_title'  => array(
				'group' => __( 'First list', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'left_tab'    => array(
				'group'       => __( 'First list', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Short name for the tab', 'mvweb-core' ),
				'description' => __( 'The view with tabs shows it on the switch. Empty takes the heading.', 'mvweb-core' ),
			),
			'left_items'  => array(
				'group' => __( 'First list', 'mvweb-core' ),
				'type'  => 'textarea',
				'label' => __( 'Items, one per line', 'mvweb-core' ),
			),
			'right_title' => array(
				'group' => __( 'Second list', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'right_tab'   => array(
				'group'       => __( 'Second list', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Short name for the tab', 'mvweb-core' ),
				'description' => __( 'The view with tabs shows it on the switch. Empty takes the heading.', 'mvweb-core' ),
			),
			'right_items' => array(
				'group' => __( 'Second list', 'mvweb-core' ),
				'type'  => 'textarea',
				'label' => __( 'Items, one per line', 'mvweb-core' ),
			),
		),
	)
);
