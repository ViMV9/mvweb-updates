<?php
/**
 * Section type: one work, wide, with a gallery beside the text.
 *
 * Unlike the showcase this one is filled by hand and asks nothing of the store:
 * it is the block a site uses to push a single project, a finished job or an
 * offer of the month, and such a block outlives whatever product it started
 * from. Its facts, such as area, time or district, and its prices stand apart
 * from the description; how the pictures and the figures are laid out is the
 * view the theme draws.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'project',
	array(
		'label'       => __( 'One work, wide', 'mvweb-core' ),
		'description' => __( 'One project: gallery and description', 'mvweb-core' ),
		'category'    => 'catalog',
		'fields'      => array(
			'kicker'    => array(
				'type'        => 'text',
				'label'       => __( 'Line above the heading', 'mvweb-core' ),
				'description' => __( 'For example: a finished project.', 'mvweb-core' ),
			),
			'title'     => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'      => array(
				'type'  => 'textarea',
				'label' => __( 'Description', 'mvweb-core' ),
			),
			'facts'     => array(
				'type'        => 'repeat',
				'label'       => __( 'Facts', 'mvweb-core' ),
				'description' => __( 'Up to four figures, for example: 68, m², area. The view with steps puts each fact under the picture of the same number.', 'mvweb-core' ),
				'max'         => 4,
				'fields'      => array(
					'value' => array(
						'type'  => 'text',
						'label' => __( 'Figure', 'mvweb-core' ),
					),
					'unit'  => array(
						'type'        => 'text',
						'label'       => __( 'Unit', 'mvweb-core' ),
						'description' => __( 'Stands after the figure, smaller in the view with large figures.', 'mvweb-core' ),
					),
					'label' => array(
						'type'  => 'text',
						'label' => __( 'Caption', 'mvweb-core' ),
					),
				),
			),
			'prices'    => array(
				'type'   => 'repeat',
				'label'  => __( 'Prices', 'mvweb-core' ),
				'max'    => 4,
				'fields' => array(
					'label' => array(
						'type'  => 'text',
						'label' => __( 'What for', 'mvweb-core' ),
					),
					'value' => array(
						'type'  => 'text',
						'label' => __( 'How much', 'mvweb-core' ),
					),
				),
			),
			'link_text' => array(
				'type'  => 'text',
				'label' => __( 'Link', 'mvweb-core' ),
			),
			'link_url'  => array(
				'type'  => 'url',
				'label' => __( 'Where the link leads', 'mvweb-core' ),
			),
			'photos'    => array(
				'type'        => 'repeat',
				'label'       => __( 'Pictures', 'mvweb-core' ),
				'description' => __( 'The first one is the main picture. The views with a gallery show four and count the rest; the view with steps shows all of them.', 'mvweb-core' ),
				'max'         => 8,
				'fields'      => array(
					'image' => array(
						'type'  => 'image',
						'label' => __( 'Picture', 'mvweb-core' ),
					),
					'title' => array(
						'type'        => 'text',
						'label'       => __( 'Step name', 'mvweb-core' ),
						'description' => __( 'Written under the picture in the view with steps.', 'mvweb-core' ),
					),
				),
			),
		),
	)
);
