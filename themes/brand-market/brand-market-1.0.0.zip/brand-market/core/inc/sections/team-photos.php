<?php
/**
 * Section type: the team as a wall of photographs.
 *
 * The photographs come with a name and a role each. The group view also takes
 * one shared photograph and the places of the people on it.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'team-photos',
	array(
		'label'       => __( 'Team, photo wall', 'mvweb-core' ),
		'description' => __( 'Photos of the team with names and roles', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => array(
			'kicker'      => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'       => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'        => array(
				'type'  => 'textarea',
				'label' => __( 'Lead', 'mvweb-core' ),
			),
			'button_text' => array(
				'type'    => 'text',
				'label'   => __( 'Button', 'mvweb-core' ),
				'default' => __( 'Meet the team', 'mvweb-core' ),
			),
			'button_url'  => array(
				'type'        => 'url',
				'label'       => __( 'Button address', 'mvweb-core' ),
				'description' => __( 'Without an address there is no button.', 'mvweb-core' ),
			),
			'group_image' => array(
				'type'        => 'image',
				'label'       => __( 'Group photo', 'mvweb-core' ),
				'description' => __( 'The picture the people are marked on. Only the group view shows it.', 'mvweb-core' ),
				'show_when'   => array(
					'field' => 'view',
					'in'    => array( '5' ),
				),
			),
			'photos'      => array(
				'type'        => 'repeat',
				'label'       => __( 'Photographs', 'mvweb-core' ),
				'description' => __( 'Six of them: the compositions are laid out for that many. Fewer simply leaves gaps.', 'mvweb-core' ),
				'max'         => 6,
				'fields'      => array(
					'image' => array(
						'type'  => 'image',
						'label' => __( 'Photo', 'mvweb-core' ),
					),
					'name'  => array(
						'type'  => 'text',
						'label' => __( 'Name', 'mvweb-core' ),
					),
					'role'  => array(
						'type'  => 'text',
						'label' => __( 'Role', 'mvweb-core' ),
					),
					'pin_x' => array(
						'type'        => 'number',
						'label'       => __( 'Place on the group photo, from the left', 'mvweb-core' ),
						'description' => __( 'Percent of the width, 1 to 100. Zero keeps the person off the group photo.', 'mvweb-core' ),
						'default'     => 0,
						'min'         => 0,
						'max'         => 100,
					),
					'pin_y' => array(
						'type'        => 'number',
						'label'       => __( 'Place on the group photo, from the top', 'mvweb-core' ),
						'description' => __( 'Percent of the height, 1 to 100. Zero keeps the person off the group photo.', 'mvweb-core' ),
						'default'     => 0,
						'min'         => 0,
						'max'         => 100,
					),
				),
			),
		),
	)
);
