<?php
/**
 * Section type: the request form.
 *
 * The theme ships no form of its own: a form is a plugin's job — it validates,
 * stores, mails and keeps the anti-spam up to date. The section holds the
 * shortcode of Contact Form 7 and prints it in the layout; the markup of the
 * form stays the plugin's, the theme only draws it.
 *
 * The phone, the address and the messengers are not fields here. They already
 * live once in the site profile, and a second copy is a copy that goes stale.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'contact-form',
	array(
		'label'       => __( 'Request form', 'mvweb-core' ),
		'description' => __( 'Text beside a request form', 'mvweb-core' ),
		'category'    => 'contact',
		'fields'      => array(
			'title' => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'  => array(
				'type'  => 'textarea',
				'label' => __( 'Lead', 'mvweb-core' ),
			),
			'note'  => array(
				'type'        => 'textarea',
				'label'       => __( 'Note beside the form', 'mvweb-core' ),
				'description' => __( 'When you answer, how to reach you faster.', 'mvweb-core' ),
			),
			'form'  => array(
				'type'        => 'text',
				'label'       => __( 'Form shortcode', 'mvweb-core' ),
				'description' => __( 'Form shortcode, for example [contact-form-7 id="12"]. Without it the block prints nothing.', 'mvweb-core' ),
				'tooltip'     => __( 'The theme draws the fields of Contact Form 7 itself. The two-step view starts the second step at the first text area or consent box of the form.', 'mvweb-core' ),
			),
			'photo' => array(
				'type'        => 'image',
				'label'       => __( 'Photo behind the form', 'mvweb-core' ),
				'description' => __( 'Only the view with a photo shows it.', 'mvweb-core' ),
			),
		),
	)
);
