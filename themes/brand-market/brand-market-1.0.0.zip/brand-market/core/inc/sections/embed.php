<?php
/**
 * Section type: something another plugin or service draws.
 *
 * A calculator, a gallery, the reviews of a plugin, a booking widget: the
 * theme gives it a heading and a frame, the content comes from a shortcode or
 * from pasted code. The code keeps scripts and frames only for a user allowed
 * to publish any markup (see mvweb_core_sanitize_code()). The markup of the
 * widget stays its own; the theme draws the frame and the fields of Contact
 * Form 7.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'embed',
	array(
		'label'       => __( 'Embed', 'mvweb-core' ),
		'description' => __( 'A plugin shortcode or the code of a widget: calculator, booking, map', 'mvweb-core' ),
		'category'    => 'other',
		'fields'      => array(
			'kicker'    => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'     => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'      => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'width'     => array(
				'type'    => 'select',
				'label'   => __( 'Width', 'mvweb-core' ),
				'choices' => array(
					'page'   => __( 'Page width', 'mvweb-core' ),
					'narrow' => __( 'Narrow, like text', 'mvweb-core' ),
				),
				'default' => 'page',
			),
			'shortcode' => array(
				'type'        => 'text',
				'label'       => __( 'Shortcode', 'mvweb-core' ),
				'description' => __( 'For example [contact-form-7 id="12"] or [mvweb_reviews]. The numbered, bar and dark views draw the fields of Contact Form 7.', 'mvweb-core' ),
			),
			'code'      => array(
				'type'        => 'code',
				'label'       => __( 'Code', 'mvweb-core' ),
				'description' => __( 'The code of a widget: an online booking form, a map, a player. Scripts and frames are kept only for administrators.', 'mvweb-core' ),
			),
			'ticker'    => array(
				'type'        => 'textarea',
				'label'       => __( 'Words of the running line', 'mvweb-core' ),
				'description' => __( 'One per line. Only the view on a backdrop shows them.', 'mvweb-core' ),
			),
		),
	)
);
