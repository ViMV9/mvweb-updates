<?php
/**
 * Section type: products of the catalogue in cards.
 *
 * The cards are items of the catalogue rather than a hand-made list: picture,
 * name, price, rating and badges already live on the item, and a second copy
 * of them here would go stale the day the price changes. What the section
 * does hold is which items to show — picked by hand and dragged into order,
 * the featured or newest ones, or those of one department — and the wording
 * around the cards. The card itself is the one of the theme; its composition
 * is set in the Customizer.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'products',
	array(
		'label'       => __( 'Products from the catalogue', 'mvweb-core' ),
		'description' => __( 'Items from the catalogue with prices', 'mvweb-core' ),
		'category'    => 'catalog',
		'fields'      => array(
			'kicker'          => array(
				'group' => __( 'Heading', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'           => array(
				'group' => __( 'Heading', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'            => array(
				'group' => __( 'Heading', 'mvweb-core' ),
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'link_text'       => array(
				'group'       => __( 'Heading', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Link beside the heading', 'mvweb-core' ),
				'description' => __( 'For example: All products. Empty shows no link.', 'mvweb-core' ),
			),
			'link_url'        => array(
				'group'       => __( 'Heading', 'mvweb-core' ),
				'type'        => 'url',
				'label'       => __( 'Where the link leads', 'mvweb-core' ),
				'description' => __( 'Empty leads to the catalogue.', 'mvweb-core' ),
			),
			'source'          => array(
				'group'   => __( 'Which products', 'mvweb-core' ),
				'type'    => 'select',
				'label'   => __( 'Which products', 'mvweb-core' ),
				'choices' => array(
					'manual'   => __( 'Chosen by hand', 'mvweb-core' ),
					'featured' => __( 'Featured ones', 'mvweb-core' ),
					'recent'   => __( 'The newest ones', 'mvweb-core' ),
					'category' => __( 'Of one department', 'mvweb-core' ),
				),
				'default' => 'featured',
			),
			'items'           => array(
				'group'       => __( 'Which products', 'mvweb-core' ),
				'type'        => 'repeat',
				'label'       => __( 'Products', 'mvweb-core' ),
				'description' => __( 'Add the products to show and drag them into order.', 'mvweb-core' ),
				'max'         => 12,
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'manual' ),
				),
				'fields'      => array(
					'item' => array(
						'type'  => 'item',
						'label' => __( 'Product', 'mvweb-core' ),
					),
				),
			),
			'category'        => array(
				'group'     => __( 'Which products', 'mvweb-core' ),
				'type'      => 'category',
				'taxonomy'  => mvweb_core_taxonomy(),
				'label'     => __( 'Department', 'mvweb-core' ),
				'default'   => 0,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'category' ),
				),
			),
			'count'           => array(
				'group'     => __( 'Which products', 'mvweb-core' ),
				'type'      => 'number',
				'label'     => __( 'How many', 'mvweb-core' ),
				'default'   => 8,
				'min'       => 1,
				'max'       => 12,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'featured', 'recent', 'category' ),
				),
			),
			'badge'           => array(
				'group'       => __( 'Which products', 'mvweb-core' ),
				'type'        => 'select',
				'label'       => __( 'Badge on the cards', 'mvweb-core' ),
				'description' => __( 'A hit or a novelty is added to every card of the block, next to the badges of the product. The colour is set in “Product list”.', 'mvweb-core' ),
				'choices'     => array(
					'own'  => __( 'As the product has', 'mvweb-core' ),
					'hit'  => __( 'Hit', 'mvweb-core' ),
					'new'  => __( 'New', 'mvweb-core' ),
					'none' => __( 'No badges', 'mvweb-core' ),
				),
				'default'     => 'own',
			),
			'filter'          => array(
				'group'       => __( 'Which products', 'mvweb-core' ),
				'type'        => 'select',
				'label'       => __( 'Pills above the cards', 'mvweb-core' ),
				'description' => __( 'With departments, the visitor narrows the cards to one department without leaving the page.', 'mvweb-core' ),
				'choices'     => array(
					'none'       => __( 'None', 'mvweb-core' ),
					'categories' => __( 'By department', 'mvweb-core' ),
				),
				'default'     => 'none',
			),
			'filter_all'      => array(
				'group'     => __( 'Which products', 'mvweb-core' ),
				'type'      => 'text',
				'label'     => __( 'Pill that shows everything', 'mvweb-core' ),
				'default'   => __( 'All', 'mvweb-core' ),
				'show_when' => array(
					'field' => 'filter',
					'in'    => array( 'categories' ),
				),
			),
			'card_button'     => array(
				'group'       => __( 'Button on the cards', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Button on the cards', 'mvweb-core' ),
				'description' => __( 'Empty takes the wording from Conversion.', 'mvweb-core' ),
				'placeholder' => __( 'As in Conversion', 'mvweb-core' ),
				'goto'        => array( 'mvweb_cz_conversion_cta', __( 'Open Conversion', 'mvweb-core' ) ),
			),
			'card_action'     => array(
				'group'   => __( 'Button on the cards', 'mvweb-core' ),
				'type'    => 'select',
				'label'   => __( 'What the button does', 'mvweb-core' ),
				'choices' => array(
					'link' => __( 'Opens a page', 'mvweb-core' ),
					'form' => __( 'Opens a form in a pop-up window', 'mvweb-core' ),
				),
				'default' => 'link',
			),
			'card_url'        => array(
				'group'       => __( 'Button on the cards', 'mvweb-core' ),
				'type'        => 'url',
				'label'       => __( 'Page the button opens', 'mvweb-core' ),
				'description' => __( 'Empty takes the address from Conversion.', 'mvweb-core' ),
				'placeholder' => __( 'As in Conversion', 'mvweb-core' ),
				'goto'        => array( 'mvweb_cz_conversion_cta', __( 'Open Conversion', 'mvweb-core' ) ),
				'show_when'   => array(
					'field' => 'card_action',
					'in'    => array( 'link' ),
				),
			),
			'card_form_title' => array(
				'group'     => __( 'Button on the cards', 'mvweb-core' ),
				'type'      => 'text',
				'label'     => __( 'Heading of the pop-up window', 'mvweb-core' ),
				'default'   => __( 'Request for a product', 'mvweb-core' ),
				'show_when' => array(
					'field' => 'card_action',
					'in'    => array( 'form' ),
				),
			),
			'card_form'       => array(
				'group'       => __( 'Button on the cards', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Form in the pop-up window', 'mvweb-core' ),
				'description' => __( 'Form shortcode, for example [contact-form-7 id="12"].', 'mvweb-core' ),
				'tooltip'     => __( 'A hidden field named product in the form receives the name of the product the button belongs to.', 'mvweb-core' ),
				'show_when'   => array(
					'field' => 'card_action',
					'in'    => array( 'form' ),
				),
			),
			'cta_lead'        => array(
				'group'       => __( 'Closing block', 'mvweb-core' ),
				'type'        => 'textarea',
				'label'       => __( 'Text under the cards', 'mvweb-core' ),
				'description' => __( 'Leave the three fields of the closing block empty to drop it.', 'mvweb-core' ),
			),
			'cta_button'      => array(
				'group' => __( 'Closing block', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Button under the cards', 'mvweb-core' ),
			),
			'cta_url'         => array(
				'group' => __( 'Closing block', 'mvweb-core' ),
				'type'  => 'url',
				'label' => __( 'Where that button leads', 'mvweb-core' ),
			),
			'cta_note'        => array(
				'group' => __( 'Closing block', 'mvweb-core' ),
				'type'  => 'textarea',
				'label' => __( 'Note under the button', 'mvweb-core' ),
			),
			'form_title'      => array(
				'group' => __( 'Closing block', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Heading of the form', 'mvweb-core' ),
			),
			'form'            => array(
				'group'       => __( 'Closing block', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Form in the closing block', 'mvweb-core' ),
				'description' => __( 'Form shortcode, for example [contact-form-7 id="12"].', 'mvweb-core' ),
				'tooltip'     => __( 'Give the fields of the form the classes mvweb-t-field, mvweb-t-field__label and mvweb-t-field__input to get the look of the theme.', 'mvweb-core' ),
			),
		),
	)
);
