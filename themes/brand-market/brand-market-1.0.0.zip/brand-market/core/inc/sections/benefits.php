<?php
/**
 * Section type: what a client gets.
 *
 * One list of points; the view sets how it is drawn: a card beside a photo,
 * points around a photo, numbered cards, rows with a photo each, lines with a
 * figure on the right.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'benefits',
	array(
		'label'       => __( 'Benefits', 'mvweb-core' ),
		'description' => __( 'A list of benefits with a photo, numbers or figures', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => mvweb_core_cards_colour_fields() + array(
			'title'      => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'       => array(
				'type'  => 'textarea',
				'label' => __( 'Lead', 'mvweb-core' ),
			),
			'image'      => array(
				'type'        => 'image',
				'label'       => __( 'Photo', 'mvweb-core' ),
				'description' => __( 'Beside the card in the first view, in the middle in the second one. The other views take photos from the rows or have none.', 'mvweb-core' ),
				'default'     => 0,
				'side'        => 'end',
			),
			'icon'       => array(
				'type'        => 'icon',
				'label'       => __( 'Icon of the card', 'mvweb-core' ),
				'description' => __( 'Name from the theme sprite, for example brush, tools, shield-check. The first view only.', 'mvweb-core' ),
			),
			'card_title' => array(
				'type'        => 'text',
				'label'       => __( 'Heading of the card', 'mvweb-core' ),
				'description' => __( 'The first view only.', 'mvweb-core' ),
			),
			'items'      => array(
				'type'   => 'repeat',
				'label'  => __( 'Points', 'mvweb-core' ),
				'max'    => 12,
				'fields' => array(
					'icon'   => array(
						'type'        => 'icon',
						'label'       => __( 'Icon', 'mvweb-core' ),
						'description' => __( 'Name from the theme sprite. The views with points around a photo and with rows show it.', 'mvweb-core' ),
					),
					'title'  => array(
						'type'        => 'text',
						'label'       => __( 'Short name', 'mvweb-core' ),
						'description' => __( 'Every view but the first one shows it above the text.', 'mvweb-core' ),
					),
					'text'   => array(
						'type'        => 'textarea',
						'label'       => __( 'Text', 'mvweb-core' ),
						'description' => __( 'The first view prints it as one line of the card.', 'mvweb-core' ),
					),
					'figure' => array(
						'type'        => 'text',
						'label'       => __( 'Figure', 'mvweb-core' ),
						'description' => __( 'A short value on the right, for example 9 months. The last view only.', 'mvweb-core' ),
					),
					'group'  => array(
						'type'        => 'text',
						'label'       => __( 'Group heading', 'mvweb-core' ),
						'description' => __( 'The view with rows joins the neighbouring points with the same heading into one row.', 'mvweb-core' ),
					),
					'image'  => array(
						'type'        => 'image',
						'label'       => __( 'Photo of the group', 'mvweb-core' ),
						'description' => __( 'The view with rows takes the first photo of a group. Set it on one point of the group.', 'mvweb-core' ),
					),
				),
			),
		),
	)
);
