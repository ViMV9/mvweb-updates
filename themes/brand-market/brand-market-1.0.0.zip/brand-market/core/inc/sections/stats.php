<?php
/**
 * Section type: figures the company stands on.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'stats',
	array(
		'label'       => __( 'Figures', 'mvweb-core' ),
		'description' => __( 'Three or four figures with captions', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => array(
			'title' => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'  => array(
				'type'  => 'textarea',
				'label' => __( 'Lead', 'mvweb-core' ),
			),
			'items' => array(
				'type'        => 'repeat',
				'label'       => __( 'Figures', 'mvweb-core' ),
				'description' => __( 'Three or four is what the layouts are built for.', 'mvweb-core' ),
				'max'         => 4,
				'fields'      => array(
					'icon'   => array(
						'type'        => 'icon',
						'label'       => __( 'Icon', 'mvweb-core' ),
						'description' => __( 'Name from the theme sprite. Views with cards show it.', 'mvweb-core' ),
					),
					'number' => array(
						'type'  => 'text',
						'label' => __( 'Figure', 'mvweb-core' ),
					),
					'label'  => array(
						'type'  => 'text',
						'label' => __( 'What it counts', 'mvweb-core' ),
					),
				),
			),
		),
	)
);
