<?php
/**
 * Section type: the latest posts of the blog.
 *
 * The cards are the blog's own, so a post looks the same on a landing page as
 * in its category, and the parts of the card are set once for the whole site.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'posts',
	array(
		'label'       => __( 'Blog posts', 'mvweb-core' ),
		'description' => __( 'The latest posts, of the whole blog or of one category', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => array(
			'kicker'    => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'     => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'      => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'category'  => array(
				'type'    => 'category',
				'label'   => __( 'Category', 'mvweb-core' ),
				'default' => 0,
			),
			'count'     => array(
				'type'    => 'number',
				'label'   => __( 'How many posts', 'mvweb-core' ),
				'min'     => 1,
				'max'     => 12,
				'default' => 3,
			),
			'link_text' => array(
				'type'    => 'text',
				'label'   => __( 'Link to all posts', 'mvweb-core' ),
				'default' => __( 'All posts', 'mvweb-core' ),
			),
			'link_url'  => array(
				'type'        => 'url',
				'label'       => __( 'Where the link leads', 'mvweb-core' ),
				'description' => __( 'Empty leads to the category, or to the blog when no category is picked.', 'mvweb-core' ),
			),
		),
	)
);
