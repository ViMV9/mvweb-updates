<?php
/**
 * Section type: before and after.
 *
 * Two photos of one job. The jobs are written into the block or taken from the
 * portfolio: a work that has both photos is a job. How the pair is shown, a
 * slider between the photos, two photos side by side, a card with figures, a
 * round lens or a grid of small pairs, is the view the theme draws.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'before-after',
	array(
		'label'       => __( 'Before and after', 'mvweb-core' ),
		'description' => __( 'Two photos of one job with a slider between them', 'mvweb-core' ),
		'category'    => 'trust',
		'fields'      => array(
			'kicker'       => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'        => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'         => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'source'       => array(
				'type'    => 'select',
				'label'   => __( 'Where the jobs come from', 'mvweb-core' ),
				'choices' => array(
					'rows'  => __( 'The list below', 'mvweb-core' ),
					'works' => __( 'Works of the portfolio', 'mvweb-core' ),
				),
				'default' => 'rows',
			),
			'kind'         => array(
				'type'        => 'category',
				'taxonomy'    => 'mv_work_type',
				'label'       => __( 'Kind of work', 'mvweb-core' ),
				'description' => __( 'Only works with both photos are taken. Empty takes every kind.', 'mvweb-core' ),
				'default'     => 0,
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'works' ),
				),
			),
			'count'        => array(
				'type'      => 'number',
				'label'     => __( 'How many jobs', 'mvweb-core' ),
				'min'       => 1,
				'max'       => 12,
				'default'   => 2,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'works' ),
				),
			),
			'pairs'        => array(
				'type'      => 'repeat',
				'label'     => __( 'Jobs', 'mvweb-core' ),
				'max'       => 12,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'rows' ),
				),
				'fields'    => array(
					'before' => array(
						'type'  => 'image',
						'label' => __( 'Before', 'mvweb-core' ),
					),
					'after'  => array(
						'type'  => 'image',
						'label' => __( 'After', 'mvweb-core' ),
					),
					'title'  => array(
						'type'  => 'text',
						'label' => __( 'Caption', 'mvweb-core' ),
					),
					'text'   => array(
						'type'  => 'textarea',
						'label' => __( 'Description', 'mvweb-core' ),
					),
					'facts'  => array(
						'type'        => 'textarea',
						'label'       => __( 'Facts', 'mvweb-core' ),
						'description' => __( 'One per line, caption and figure through a colon: Time: 20 minutes. The view with a card shows up to three.', 'mvweb-core' ),
					),
				),
			),
			'label_before' => array(
				'type'    => 'text',
				'label'   => __( 'Mark on the first photo', 'mvweb-core' ),
				'default' => __( 'Before', 'mvweb-core' ),
			),
			'label_after'  => array(
				'type'    => 'text',
				'label'   => __( 'Mark on the second photo', 'mvweb-core' ),
				'default' => __( 'After', 'mvweb-core' ),
			),
			'button_text'  => array(
				'type'    => 'text',
				'label'   => __( 'Button', 'mvweb-core' ),
				'default' => __( 'See all works', 'mvweb-core' ),
			),
			'button_url'   => array(
				'type'        => 'url',
				'label'       => __( 'Where the button leads', 'mvweb-core' ),
				'description' => __( 'Empty leads to the portfolio.', 'mvweb-core' ),
			),
		),
	)
);
