<?php
/**
 * Section type: a promo banner and a row of products of one department.
 *
 * The banner stands beside, above or inside the row with a line, a heading, a
 * text, chips that lead to subsections, a button and up to three pictures.
 * The row of products scrolls with the arrows of the showcase module. The
 * card is the one of the theme; its composition is set in the Customizer.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'promo-products',
	array(
		'label'       => __( 'Promo banner with products', 'mvweb-core' ),
		'description' => __( 'A banner beside a row of products of one department', 'mvweb-core' ),
		'category'    => 'catalog',
		'fields'      => array(
			'kicker'      => array(
				'group' => __( 'Banner', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'       => array(
				'group' => __( 'Banner', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'        => array(
				'group' => __( 'Banner', 'mvweb-core' ),
				'type'  => 'textarea',
				'label' => __( 'Text', 'mvweb-core' ),
			),
			'chips'       => array(
				'group'       => __( 'Banner', 'mvweb-core' ),
				'type'        => 'repeat',
				'label'       => __( 'Links to subsections', 'mvweb-core' ),
				'description' => __( 'Short pills under the text.', 'mvweb-core' ),
				'max'         => 8,
				'fields'      => array(
					'text' => array(
						'type'  => 'text',
						'label' => __( 'Label', 'mvweb-core' ),
					),
					'url'  => array(
						'type'  => 'url',
						'label' => __( 'Link', 'mvweb-core' ),
					),
				),
			),
			'button_text' => array(
				'group' => __( 'Banner', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Button', 'mvweb-core' ),
			),
			'button_url'  => array(
				'group' => __( 'Banner', 'mvweb-core' ),
				'type'  => 'url',
				'label' => __( 'Where the button leads', 'mvweb-core' ),
			),
			'image'       => array(
				'group'       => __( 'Banner', 'mvweb-core' ),
				'type'        => 'image',
				'label'       => __( 'Picture', 'mvweb-core' ),
				'description' => __( 'The main picture of the banner. The views with more pictures use the two below as well.', 'mvweb-core' ),
			),
			'image_2'     => array(
				'group' => __( 'Banner', 'mvweb-core' ),
				'type'  => 'image',
				'label' => __( 'Second picture', 'mvweb-core' ),
			),
			'image_3'     => array(
				'group' => __( 'Banner', 'mvweb-core' ),
				'type'  => 'image',
				'label' => __( 'Third picture', 'mvweb-core' ),
			),
			'source'      => array(
				'group'   => __( 'Products', 'mvweb-core' ),
				'type'    => 'select',
				'label'   => __( 'Which products', 'mvweb-core' ),
				'choices' => array(
					'manual'   => __( 'Chosen by hand', 'mvweb-core' ),
					'featured' => __( 'Featured ones', 'mvweb-core' ),
					'recent'   => __( 'The newest ones', 'mvweb-core' ),
					'category' => __( 'Of one department', 'mvweb-core' ),
				),
				'default' => 'featured',
			),
			'items'       => array(
				'group'     => __( 'Products', 'mvweb-core' ),
				'type'      => 'repeat',
				'label'     => __( 'Products', 'mvweb-core' ),
				'max'       => 12,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'manual' ),
				),
				'fields'    => array(
					'item' => array(
						'type'  => 'item',
						'label' => __( 'Product', 'mvweb-core' ),
					),
				),
			),
			'category'    => array(
				'group'     => __( 'Products', 'mvweb-core' ),
				'type'      => 'category',
				'taxonomy'  => mvweb_core_taxonomy(),
				'label'     => __( 'Department', 'mvweb-core' ),
				'default'   => 0,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'category' ),
				),
			),
			'count'       => array(
				'group'     => __( 'Products', 'mvweb-core' ),
				'type'      => 'number',
				'label'     => __( 'How many', 'mvweb-core' ),
				'default'   => 8,
				'min'       => 2,
				'max'       => 12,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'featured', 'recent', 'category' ),
				),
			),
			'card_button' => array(
				'group'       => __( 'Products', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Button on the cards', 'mvweb-core' ),
				'description' => __( 'Empty takes the wording from Conversion.', 'mvweb-core' ),
				'placeholder' => __( 'As in Conversion', 'mvweb-core' ),
			),
		),
	)
);
