<?php
/**
 * Section type: first screen.
 *
 * The only section allowed to print an h1: it stands where a page hero would,
 * and the homepage has no entry title of its own to show. On any other page
 * the title of the page already holds the h1, so the heading here is a div.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'hero',
	array(
		'label'       => __( 'First screen', 'mvweb-core' ),
		'description' => __( 'Photo or slides, heading, button', 'mvweb-core' ),
		'category'    => 'intro',
		'fields'      => array(
			'image'          => array(
				'group'       => __( 'Photo', 'mvweb-core' ),
				'type'        => 'image',
				'label'       => __( 'Photo', 'mvweb-core' ),
				'description' => __( 'A wide photo. It is the background, or the picture beside the text where the view has one.', 'mvweb-core' ),
				'side'        => 'end',
				'default'     => 0,
				'show_when'   => array(
					'field' => 'view',
					'in'    => array( '1', '2', '4' ),
				),
			),
			'video'          => array(
				'group'       => __( 'Photo', 'mvweb-core' ),
				'type'        => 'url',
				'label'       => __( 'Video over the photo', 'mvweb-core' ),
				'description' => __( 'Address of an .mp4 or .webm file, for example from the media library. It plays silently in a loop on a computer; on a phone, and for visitors who asked for less motion, the photo stays.', 'mvweb-core' ),
				'show_when'   => array(
					'field' => 'view',
					'in'    => array( '1' ),
				),
			),
			'slides'         => array(
				'group'       => __( 'Photo', 'mvweb-core' ),
				'type'        => 'repeat',
				'label'       => __( 'More background photos', 'mvweb-core' ),
				'description' => __( 'Add at least one, and the background turns into a slideshow that starts with the photo above.', 'mvweb-core' ),
				'max'         => 9,
				'show_when'   => array(
					'field' => 'view',
					'in'    => array( '1' ),
				),
				'fields'      => array(
					'image' => array(
						'type'  => 'image',
						'label' => __( 'Photo', 'mvweb-core' ),
					),
				),
			),
			'slide_effect'   => array(
				'group'     => __( 'Photo', 'mvweb-core' ),
				'type'      => 'select',
				'label'     => __( 'How the photos change', 'mvweb-core' ),
				'choices'   => array(
					'fade'  => __( 'Cross-fade', 'mvweb-core' ),
					'zoom'  => __( 'Cross-fade with a slow zoom', 'mvweb-core' ),
					'slide' => __( 'Slide in from the right', 'mvweb-core' ),
				),
				'default'   => 'fade',
				'show_when' => array(
					'field' => 'view',
					'in'    => array( '1' ),
				),
			),
			'slide_interval' => array(
				'group'     => __( 'Photo', 'mvweb-core' ),
				'type'      => 'number',
				'label'     => __( 'Seconds per photo', 'mvweb-core' ),
				'min'       => 3,
				'max'       => 30,
				'default'   => 6,
				'show_when' => array(
					'field' => 'view',
					'in'    => array( '1' ),
				),
			),
			'title'          => array(
				'group' => __( 'Text and button', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'features'       => array(
				'group'       => __( 'Text and button', 'mvweb-core' ),
				'type'        => 'repeat',
				'label'       => __( 'Short promises', 'mvweb-core' ),
				'description' => __( 'Ticks, pills or a running line: the view decides.', 'mvweb-core' ),
				'max'         => 5,
				'fields'      => array(
					'text' => array(
						'type'  => 'text',
						'label' => __( 'Line', 'mvweb-core' ),
					),
				),
			),
			'button_text'    => array(
				'group' => __( 'Text and button', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Button label', 'mvweb-core' ),
			),
			'button_url'     => array(
				'group'       => __( 'Text and button', 'mvweb-core' ),
				'type'        => 'url',
				'label'       => __( 'Button link', 'mvweb-core' ),
				'description' => __( 'Leave empty to hide the button.', 'mvweb-core' ),
			),
			'trust'          => array(
				'group'       => __( 'Figures', 'mvweb-core' ),
				'type'        => 'repeat',
				'label'       => __( 'Figures', 'mvweb-core' ),
				'description' => __( 'In a caption, type <br> where the line should break. The frame shows in the view with three frames.', 'mvweb-core' ),
				'max'         => 4,
				'fields'      => array(
					'image'  => array(
						'type'  => 'image',
						'label' => __( 'Frame', 'mvweb-core' ),
					),
					'number' => array(
						'type'  => 'text',
						'label' => __( 'Figure', 'mvweb-core' ),
					),
					'text'   => array(
						'type'  => 'line',
						'label' => __( 'Caption', 'mvweb-core' ),
					),
				),
			),
			'plate_title'    => array(
				'group'     => __( 'Plate on the photo', 'mvweb-core' ),
				'type'      => 'text',
				'label'     => __( 'Plate heading', 'mvweb-core' ),
				'show_when' => array(
					'field' => 'view',
					'in'    => array( '2' ),
				),
			),
			'plate_text'     => array(
				'group'     => __( 'Plate on the photo', 'mvweb-core' ),
				'type'      => 'text',
				'label'     => __( 'Plate text', 'mvweb-core' ),
				'show_when' => array(
					'field' => 'view',
					'in'    => array( '2' ),
				),
			),
			'plate_icon'     => array(
				'group'     => __( 'Plate on the photo', 'mvweb-core' ),
				'type'      => 'icon',
				'label'     => __( 'Plate icon', 'mvweb-core' ),
				'default'   => '',
				'show_when' => array(
					'field' => 'view',
					'in'    => array( '2' ),
				),
			),
		),
	)
);
