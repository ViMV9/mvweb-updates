<?php
/**
 * Section type: the team, card by card.
 *
 * The people come from the Team records, in the order the editor arranged them
 * there. The section carries no list of its own: a name typed twice in two
 * sections is a name that will be right in one of them and stale in the other.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'team',
	array(
		'label'       => __( 'Team', 'mvweb-core' ),
		'description' => __( 'Staff with photos', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => array(
			'kicker'     => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'      => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'       => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'count'      => array(
				'type'        => 'number',
				'label'       => __( 'How many to show', 'mvweb-core' ),
				'description' => __( 'Zero shows everyone.', 'mvweb-core' ),
				'default'     => 0,
				'min'         => 0,
				'max'         => 48,
			),
			'book_text'  => array(
				'type'        => 'text',
				'label'       => __( 'Booking button', 'mvweb-core' ),
				'description' => __( 'Shown on the cards of people who have a booking link.', 'mvweb-core' ),
				'default'     => __( 'Book', 'mvweb-core' ),
			),
			'lead_label' => array(
				'type'        => 'text',
				'label'       => __( 'Label over the first name', 'mvweb-core' ),
				'description' => __( 'A small tag above the name of the first person in the view that puts one person forward.', 'mvweb-core' ),
			),
		),
	)
);
