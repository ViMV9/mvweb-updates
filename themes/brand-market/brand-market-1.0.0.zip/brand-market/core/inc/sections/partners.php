<?php
/**
 * Section type: companies we work with, and the papers that vouch for the brand.
 *
 * A partner without an uploaded logo is not a hole in the list: the plate shows
 * the initials of the name, the way a person without a photo does in the team
 * section. The same list serves as a shelf of documents: a scan opens full size
 * on a click and the file can be downloaded.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'partners',
	array(
		'label'       => __( 'Partners', 'mvweb-core' ),
		'description' => __( 'Logos of partners and shops, or documents to open and download', 'mvweb-core' ),
		'category'    => 'trust',
		'fields'      => mvweb_core_section_head_fields() + array(
			'badge' => array(
				'type'        => 'image',
				'label'       => __( 'Picture beside the heading', 'mvweb-core' ),
				'description' => __( 'A membership or exhibition sign, for example.', 'mvweb-core' ),
			),
			'logos' => array(
				'type'        => 'repeat',
				'label'       => __( 'Companies or documents', 'mvweb-core' ),
				'description' => __( 'A logo needs a name only when the picture is missing: the initials take its place.', 'mvweb-core' ),
				'max'         => 24,
				'fields'      => array(
					'image' => array(
						'type'        => 'image',
						'label'       => __( 'Logo or first page of the document', 'mvweb-core' ),
						'description' => __( 'The documents view opens this picture full size.', 'mvweb-core' ),
					),
					'name'  => array(
						'type'  => 'text',
						'label' => __( 'Company or document name', 'mvweb-core' ),
					),
					'url'   => array(
						'type'        => 'url',
						'label'       => __( 'Link or file', 'mvweb-core' ),
						'description' => __( 'Where the plate leads. The documents view downloads this address; empty offers the picture itself. Empty in the other views leaves the plate without a link.', 'mvweb-core' ),
					),
					'note'  => array(
						'type'  => 'text',
						'label' => __( 'Line under the document', 'mvweb-core' ),
					),
				),
			),
		),
	)
);
