<?php
/**
 * Section type: first screen as a slider of offers.
 *
 * Every slide is a small offer of its own: a line above the heading, the
 * heading, a lead, a few facts, a button with a price, pictures that the
 * view lays out as it draws them, and a few items of the catalogue for the
 * views with mini cards. All slides sit in one cell of a grid, so the block
 * never changes height when the slide changes.
 *
 * The heading of a slide is the only one of the block. Which tag it takes is
 * the editor's call: the first screen of a shop usually needs an h1, a second
 * slider further down the page does not.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'hero-slider',
	array(
		'label'       => __( 'First screen: slider of offers', 'mvweb-core' ),
		'description' => __( 'Slides with a heading, facts, a button and pictures', 'mvweb-core' ),
		'category'    => 'intro',
		'fields'      => array(
			'slide_interval' => array(
				'type'        => 'number',
				'label'       => __( 'Seconds per slide', 'mvweb-core' ),
				'description' => __( 'Slides change by themselves only while the pause button is shown.', 'mvweb-core' ),
				'min'         => 3,
				'max'         => 30,
				'default'     => 6,
			),
			'slides'         => array(
				'type'   => 'repeat',
				'label'  => __( 'Slides', 'mvweb-core' ),
				'max'    => 6,
				'fields' => array(
					'kicker'      => array(
						'type'  => 'text',
						'label' => __( 'Line above the heading', 'mvweb-core' ),
					),
					'title'       => array(
						'type'  => 'text',
						'label' => __( 'Heading', 'mvweb-core' ),
					),
					'accent_word' => array(
						'type'        => 'text',
						'label'       => __( 'Word in the heading to highlight', 'mvweb-core' ),
						'description' => __( 'Written exactly as in the heading.', 'mvweb-core' ),
					),
					'text'        => array(
						'type'  => 'textarea',
						'label' => __( 'Lead', 'mvweb-core' ),
					),
					'facts'       => array(
						'type'        => 'textarea',
						'label'       => __( 'Facts, one per line', 'mvweb-core' ),
						'description' => __( 'Up to four short lines shown as chips.', 'mvweb-core' ),
					),
					'button_text' => array(
						'type'  => 'text',
						'label' => __( 'Button', 'mvweb-core' ),
					),
					'button_url'  => array(
						'type'  => 'url',
						'label' => __( 'Where the button leads', 'mvweb-core' ),
					),
					'price_label' => array(
						'type'        => 'text',
						'label'       => __( 'Word before the price', 'mvweb-core' ),
						'description' => __( 'For example: from. Empty prints the price alone.', 'mvweb-core' ),
						'default'     => __( 'from', 'mvweb-core' ),
					),
					'price'       => array(
						'type'        => 'text',
						'label'       => __( 'Price beside the button', 'mvweb-core' ),
						'description' => __( 'For example: 990 ₽. The view with a circle puts it on the circle.', 'mvweb-core' ),
					),
					'image_1'     => array(
						'type'        => 'image',
						'label'       => __( 'Picture 1: on the left', 'mvweb-core' ),
						'description' => __( 'Used by the view with a fan of cards.', 'mvweb-core' ),
					),
					'image_2'     => array(
						'type'        => 'image',
						'label'       => __( 'Picture 2: the main one', 'mvweb-core' ),
						'description' => __( 'The middle of the fan, the item on the circle, the large picture of the showcase.', 'mvweb-core' ),
					),
					'image_3'     => array(
						'type'        => 'image',
						'label'       => __( 'Picture 3: on the right', 'mvweb-core' ),
						'description' => __( 'The right of the fan, the second item on the circle.', 'mvweb-core' ),
					),
					'photo'       => array(
						'type'        => 'image',
						'label'       => __( 'Wide photograph', 'mvweb-core' ),
						'description' => __( 'Fills the whole slide in the view with a photo and a plate.', 'mvweb-core' ),
					),
					'products'    => array(
						'type'        => 'repeat',
						'label'       => __( 'Items shown as mini cards', 'mvweb-core' ),
						'description' => __( 'The showcase shows the first three, the ribbon up to six.', 'mvweb-core' ),
						'max'         => 6,
						'fields'      => array(
							'item' => array(
								'type'  => 'item',
								'label' => __( 'Item', 'mvweb-core' ),
							),
						),
					),
				),
			),
		),
	)
);
