<?php
/**
 * Section type: long text for search.
 *
 * A heading and a long formatted text, usually at the foot of the home page.
 * The heading can be the h1 of the page (home page only). A long text can be
 * cut by height or folded away entirely; the whole text stays in the markup,
 * so a search engine reads it and the page works without a script.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'seo-text',
	array(
		'label'       => __( 'Long text for search', 'mvweb-core' ),
		'description' => __( 'A heading and a long text with a spoiler', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => array(
			'kicker'        => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'         => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'title_h1'      => array(
				'type'        => 'toggle',
				'label'       => __( 'Heading is the h1 of the page (home page only)', 'mvweb-core' ),
				'description' => __( 'On the home page, with a filled heading, this block prints the h1 and the first-screen blocks print plain lines. Elsewhere the switch is ignored.', 'mvweb-core' ),
				'default'     => false,
			),
			'text'          => array(
				'type'        => 'richtext',
				'label'       => __( 'Text', 'mvweb-core' ),
				'description' => __( 'Subheadings, lists, tables and links are allowed. Empty hides the block.', 'mvweb-core' ),
			),
			'spoiler'       => array(
				'group'       => __( 'Spoiler', 'mvweb-core' ),
				'type'        => 'select',
				'label'       => __( 'How to show a long text', 'mvweb-core' ),
				'description' => __( 'The whole text stays on the page for search engines and without a script.', 'mvweb-core' ),
				'choices'     => array(
					'none'   => __( 'Show in full', 'mvweb-core' ),
					'height' => __( 'Cut by height, with a button', 'mvweb-core' ),
					'all'    => __( 'Fold all, the heading and a button stay', 'mvweb-core' ),
				),
				'default'     => 'none',
			),
			'spoiler_lines' => array(
				'group'     => __( 'Spoiler', 'mvweb-core' ),
				'type'      => 'number',
				'label'     => __( 'Lines in sight', 'mvweb-core' ),
				'min'       => 3,
				'max'       => 40,
				'default'   => 8,
				'show_when' => array(
					'field' => 'spoiler',
					'in'    => array( 'height' ),
				),
			),
			'more_label'    => array(
				'group'     => __( 'Spoiler', 'mvweb-core' ),
				'type'      => 'text',
				'label'     => __( 'Button, closed', 'mvweb-core' ),
				'default'   => _x( 'Read more', 'Text spoiler button', 'mvweb-core' ),
				'show_when' => array(
					'field' => 'spoiler',
					'in'    => array( 'height', 'all' ),
				),
			),
			'less_label'    => array(
				'group'     => __( 'Spoiler', 'mvweb-core' ),
				'type'      => 'text',
				'label'     => __( 'Button, open', 'mvweb-core' ),
				'default'   => __( 'Collapse', 'mvweb-core' ),
				'show_when' => array(
					'field' => 'spoiler',
					'in'    => array( 'height', 'all' ),
				),
			),
		),
	)
);
