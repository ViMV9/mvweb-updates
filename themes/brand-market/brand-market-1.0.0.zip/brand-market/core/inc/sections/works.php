<?php
/**
 * Section type: works from the portfolio.
 *
 * The cards come from the records of the portfolio, so a work added there
 * shows up on every page that has this section. The look of the cards, which
 * parts they show and in what order, is set once for the site, not per block.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'works',
	array(
		'label'       => __( 'Works', 'mvweb-core' ),
		'description' => __( 'Cards of finished works from the portfolio', 'mvweb-core' ),
		'category'    => 'catalog',
		'fields'      => array(
			'kicker'    => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'     => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'      => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'link_text' => array(
				'type'    => 'text',
				'label'   => __( 'Link to the portfolio', 'mvweb-core' ),
				'default' => __( 'All works', 'mvweb-core' ),
			),
			'link_url'  => array(
				'type'        => 'url',
				'label'       => __( 'Where the link leads', 'mvweb-core' ),
				'description' => __( 'Empty leads to the portfolio.', 'mvweb-core' ),
			),
			'kind'      => array(
				'type'        => 'category',
				'taxonomy'    => 'mv_work_type',
				'label'       => __( 'Kind of work', 'mvweb-core' ),
				'description' => __( 'Empty shows works of every kind.', 'mvweb-core' ),
				'default'     => 0,
			),
			'count'     => array(
				'type'        => 'number',
				'label'       => __( 'How many works', 'mvweb-core' ),
				'description' => __( 'The first ones in the order of the portfolio.', 'mvweb-core' ),
				'min'         => 1,
				'max'         => 12,
				'default'     => 3,
			),
		),
	)
);
