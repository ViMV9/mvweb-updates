<?php
/**
 * Section type: what the shop sells, in picture cards.
 *
 * Two ways to fill it. A hand-made list gives control over the order and lets
 * one card span the full width; product categories fill themselves, so a new
 * category shows up on the front without anyone remembering to add it here.
 * The look of the cards is the view the theme draws, not a field of the block.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'categories',
	array(
		'label'       => __( 'Product groups', 'mvweb-core' ),
		'description' => __( 'Cards leading to catalogue sections', 'mvweb-core' ),
		'category'    => 'catalog',
		'fields'      => array(
			'kicker'    => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'     => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'      => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'link_text' => array(
				'type'        => 'text',
				'label'       => __( 'Link to all', 'mvweb-core' ),
				'description' => __( 'Empty hides the link.', 'mvweb-core' ),
				'default'     => __( 'All catalogue', 'mvweb-core' ),
			),
			'link_url'  => array(
				'type'        => 'url',
				'label'       => __( 'Where the link leads', 'mvweb-core' ),
				'description' => __( 'Empty leads to the catalogue, or to the services for service sections.', 'mvweb-core' ),
			),
			'source'    => array(
				'type'    => 'select',
				'label'   => __( 'What to show', 'mvweb-core' ),
				'choices' => array(
					'manual'      => __( 'The list below', 'mvweb-core' ),
					'product_cat' => __( 'Product categories', 'mvweb-core' ),
					'service_cat' => __( 'Service sections', 'mvweb-core' ),
				),
				'default' => 'manual',
			),
			'count'     => array(
				'type'        => 'number',
				'label'       => __( 'How many categories', 'mvweb-core' ),
				'description' => __( 'Top level only. Used when the cards are filled in on their own.', 'mvweb-core' ),
				'default'     => 6,
				'min'         => 1,
				'max'         => 24,
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'product_cat', 'service_cat' ),
				),
			),
			'cards'     => array(
				'type'      => 'repeat',
				'label'     => __( 'Cards', 'mvweb-core' ),
				'max'       => 12,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'manual' ),
				),
				'fields'    => array(
					'image'   => array(
						'type'  => 'image',
						'label' => __( 'Picture', 'mvweb-core' ),
					),
					'image_2' => array(
						'type'        => 'image',
						'label'       => __( 'Second picture', 'mvweb-core' ),
						'description' => __( 'Shown beside the first one on the full width card of the mosaic.', 'mvweb-core' ),
					),
					'title'   => array(
						'type'  => 'text',
						'label' => __( 'Card heading', 'mvweb-core' ),
					),
					'text'    => array(
						'type'        => 'textarea',
						'label'       => __( 'Short description', 'mvweb-core' ),
						'description' => __( 'The full width card of the mosaic shows it.', 'mvweb-core' ),
					),
					'note'    => array(
						'type'        => 'text',
						'label'       => __( 'Line under the heading', 'mvweb-core' ),
						'description' => __( 'For example: 248 items. Cards filled in on their own count their items themselves.', 'mvweb-core' ),
					),
					'url'     => array(
						'type'  => 'url',
						'label' => __( 'Address', 'mvweb-core' ),
					),
					'size'    => array(
						'type'        => 'select',
						'label'       => __( 'Card size', 'mvweb-core' ),
						'description' => __( 'The mosaic gives a full width card twice the room.', 'mvweb-core' ),
						'default'     => 'normal',
						'choices'     => array(
							'normal' => __( 'Half the width', 'mvweb-core' ),
							'wide'   => __( 'Full width', 'mvweb-core' ),
						),
					),
				),
			),
		),
	)
);
