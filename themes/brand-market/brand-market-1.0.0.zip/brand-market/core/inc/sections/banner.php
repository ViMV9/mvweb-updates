<?php
/**
 * Section type: wide banner with one link.
 *
 * Filled in with two prices and a closing date, the banner turns into an
 * offer: it shows the old price struck through and hides itself the day after
 * the date.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'banner',
	array(
		'label'       => __( 'Wide banner', 'mvweb-core' ),
		'description' => __( 'A photo across the page with a line of text', 'mvweb-core' ),
		'category'    => 'intro',
		'fields'      => array(
			'image'        => array(
				'group'       => __( 'Picture', 'mvweb-core' ),
				'type'        => 'image',
				'label'       => __( 'Picture', 'mvweb-core' ),
				'description' => __( 'The background, or the picture beside the text where the view has one.', 'mvweb-core' ),
				'side'        => 'end',
				'default'     => 0,
			),
			'tag'          => array(
				'group'       => __( 'Text and button', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Label above the heading', 'mvweb-core' ),
				'description' => __( 'A short word in a pill, for example: New.', 'mvweb-core' ),
				'show_when'   => array(
					'field' => 'view',
					'in'    => array( '4', '5' ),
				),
			),
			'title'        => array(
				'group' => __( 'Text and button', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'         => array(
				'group' => __( 'Text and button', 'mvweb-core' ),
				'type'  => 'textarea',
				'label' => __( 'Lead', 'mvweb-core' ),
			),
			'button_text'  => array(
				'group' => __( 'Text and button', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Button label', 'mvweb-core' ),
			),
			'button_url'   => array(
				'group'       => __( 'Text and button', 'mvweb-core' ),
				'type'        => 'url',
				'label'       => __( 'Button link', 'mvweb-core' ),
				'description' => __( 'Leave empty to hide the button.', 'mvweb-core' ),
			),
			'price_new'    => array(
				'group' => __( 'Offer', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Price', 'mvweb-core' ),
			),
			'price_old'    => array(
				'group'       => __( 'Offer', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Old price, struck through', 'mvweb-core' ),
				'description' => __( 'The saving is counted from the two prices.', 'mvweb-core' ),
			),
			'until'        => array(
				'group'       => __( 'Offer', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Last day of the offer', 'mvweb-core' ),
				'description' => __( 'In the form 2026-10-31. The next day the banner hides itself.', 'mvweb-core' ),
			),
			'sale_label'   => array(
				'group'     => __( 'Offer', 'mvweb-core' ),
				'type'      => 'text',
				'label'     => __( 'Caption of the saving', 'mvweb-core' ),
				'default'   => __( 'Saving on the offer', 'mvweb-core' ),
				'show_when' => array(
					'field' => 'view',
					'in'    => array( '3' ),
				),
			),
			'sticker_num'  => array(
				'group'       => __( 'Sticker and running line', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Sticker, figure', 'mvweb-core' ),
				'description' => __( 'A round sticker on the picture, for example: 24. Empty hides it.', 'mvweb-core' ),
				'show_when'   => array(
					'field' => 'view',
					'in'    => array( '2' ),
				),
			),
			'sticker_text' => array(
				'group'     => __( 'Sticker and running line', 'mvweb-core' ),
				'type'      => 'text',
				'label'     => __( 'Sticker, caption', 'mvweb-core' ),
				'show_when' => array(
					'field' => 'view',
					'in'    => array( '2' ),
				),
			),
			'ticker'       => array(
				'group'       => __( 'Sticker and running line', 'mvweb-core' ),
				'type'        => 'textarea',
				'label'       => __( 'Running line', 'mvweb-core' ),
				'description' => __( 'One item per line. Empty takes the heading, the prices and the last day of the offer.', 'mvweb-core' ),
				'show_when'   => array(
					'field' => 'view',
					'in'    => array( '5' ),
				),
			),
		),
	)
);
