<?php
/**
 * Section registry, sanitizer and renderer.
 *
 * A section is one horizontal band of a page. Every type declares its label and
 * its field schema once; that single declaration drives the builder UI, the
 * sanitizer that guards the database and the renderer. Adding a type means
 * three new files — a declaration in inc/sections/, a template in
 * template-parts/sections/ and, if it needs any, a stylesheet in
 * assets/css/sections/ — and no edit to an existing one.
 *
 * The same type prints from two stores: the homepage keeps its order and field
 * values in theme_mods, every other page in the post meta the builder writes.
 * Templates never learn which one they came from.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_load_section_types' ) ) {
	/**
	 * Load the declaration of every section type.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_load_section_types() {
		$files = glob( MVWEB_CORE_DIR . '/inc/sections/*.php' );

		foreach ( is_array( $files ) ? $files : array() as $file ) {
			require_once $file;
		}

		/**
		 * Let a plugin register its own section types.
		 *
		 * @since 0.1.0
		 */
		do_action( 'mvweb_core_register_sections' );
	}
}
add_action( 'after_setup_theme', 'mvweb_core_load_section_types', 20 );

if ( ! function_exists( 'mvweb_core_register_section' ) ) {
	/**
	 * Register a section type.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type Type slug, also the template and stylesheet name.
	 * @param array  $args Optional. 'label' — name in the builder, 'fields' —
	 *                     field schema, 'render' — template slug relative to
	 *                     the theme root, 'active' — callable deciding whether
	 *                     the type may print at all, 'global' — where the
	 *                     type is set up in the Customizer ('panel', 'title')
	 *                     when its values are one for every page instead of
	 *                     living in the row of each page, 'description' —
	 *                     one line under the name in the builder's library,
	 *                     'category' — its shelf there: intro, about, catalog,
	 *                     prices, trust, contact or other.
	 *
	 * @return bool Whether the type was registered.
	 */
	function mvweb_core_register_section( $type, array $args = array() ) {
		$type = sanitize_key( $type );

		if ( '' === $type || 0 !== validate_file( $type ) ) {
			return false;
		}

		$args = wp_parse_args(
			$args,
			array(
				'label'       => $type,
				'description' => '',
				'category'    => 'other',
				'fields'      => array(),
				'render'      => 'template-parts/sections/' . $type,
				'active'      => '__return_true',
				'global'      => array(),
			)
		);

		$common         = mvweb_core_section_common_fields( $type, $args['fields'] );
		$args['fields'] = $common['first'] + $common['own'] + mvweb_core_section_parts_fields( mvweb_core_section_layout( $type ) ) + $common['last'];

		$args['fields'] = mvweb_core_normalize_section_fields( mvweb_core_section_view_marks( $args['fields'], mvweb_core_section_layout( $type ) ) );

		$GLOBALS['mvweb_sections'][ $type ] = $args;

		return true;
	}
}

if ( ! function_exists( 'mvweb_core_section_head_fields' ) ) {
	/**
	 * The fields every section with a plain heading block opens with.
	 *
	 * @since 0.1.0
	 *
	 * @return array Raw schema: background, kicker, heading, text.
	 */
	function mvweb_core_section_head_fields() {
		return array(
			'background' => array(
				'type'    => 'select',
				'label'   => __( 'Background', 'mvweb-core' ),
				'choices' => array(
					'plain'   => __( 'Page background', 'mvweb-core' ),
					'surface' => __( 'Tinted', 'mvweb-core' ),
				),
				'default' => 'plain',
			),
			'kicker'     => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'      => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'       => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_text_lines' ) ) {
	/**
	 * The non-empty lines of a textarea value.
	 *
	 * @since 0.1.0
	 *
	 * @param string $text Raw value.
	 *
	 * @return string[]
	 */
	function mvweb_core_text_lines( $text ) {
		return array_values( array_filter( array_map( 'trim', (array) preg_split( '/\R/u', (string) $text ) ), 'strlen' ) );
	}
}

if ( ! function_exists( 'mvweb_core_normalize_section_fields' ) ) {
	/**
	 * Fill in the defaults of a field schema.
	 *
	 * @since 0.1.0
	 *
	 * @param array $fields Raw schema: field id => definition.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_normalize_section_fields( $fields ) {
		$clean = array();

		foreach ( (array) $fields as $id => $field ) {
			$id = sanitize_key( $id );

			if ( '' === $id || ! is_array( $field ) ) {
				continue;
			}

			$field = wp_parse_args(
				$field,
				array(
					'type'        => 'text',
					'label'       => '',
					'description' => '',
					'default'     => '',
					'choices'     => array(),
					'fields'      => array(),
					'min'         => null,
					'max'         => null,
					'show_when'   => array(),
					'group'       => '',
					'tooltip'     => '',
					'placeholder' => '',
					'goto'        => array(),
					'taxonomy'    => 'category',
				)
			);

			$field['show_when'] = isset( $field['show_when']['field'], $field['show_when']['in'] )
				? array(
					'field' => sanitize_key( $field['show_when']['field'] ),
					'in'    => array_map( 'strval', (array) $field['show_when']['in'] ),
				)
				: array();

			if ( 'repeat' === $field['type'] ) {
				if ( ! isset( $field['fields']['visible'] ) && false !== ( isset( $field['hideable'] ) ? $field['hideable'] : true ) ) {
					$field['fields']['visible'] = array(
						'type'    => 'select',
						'label'   => __( 'Row on the page', 'mvweb-core' ),
						'choices' => array(
							'show' => __( 'Shown', 'mvweb-core' ),
							'hide' => __( 'Hidden', 'mvweb-core' ),
						),
						'default' => 'show',
					);
				}

				$field['fields']  = mvweb_core_normalize_section_fields( $field['fields'] );
				$field['default'] = is_array( $field['default'] ) ? $field['default'] : array();
			}

			$clean[ $id ] = $field;
		}

		return $clean;
	}
}

if ( ! function_exists( 'mvweb_core_sections' ) ) {
	/**
	 * Every registered section type.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>> Type slug => definition.
	 */
	function mvweb_core_sections() {
		return isset( $GLOBALS['mvweb_sections'] ) ? (array) $GLOBALS['mvweb_sections'] : array();
	}
}

if ( ! function_exists( 'mvweb_core_editable_sections' ) ) {
	/**
	 * The section types the editor may place: registered and drawn by the theme.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>> Type slug => definition.
	 */
	function mvweb_core_editable_sections() {
		return array_filter(
			mvweb_core_sections(),
			static function ( $definition, $type ) {
				$drawn = '' !== locate_template( (string) $definition['render'] . '.php' );

				/**
				 * Filters whether the editor offers a section type.
				 *
				 * @since 0.1.0
				 *
				 * @param bool   $drawn Whether the theme has a template for the type.
				 * @param string $type  Type slug.
				 */
				return (bool) apply_filters( 'mvweb_core_section_editable', $drawn, $type );
			},
			ARRAY_FILTER_USE_BOTH
		);
	}
}

if ( ! function_exists( 'mvweb_core_get_section' ) ) {
	/**
	 * One section type's definition.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type Type slug.
	 *
	 * @return array<string,mixed>|false Definition, or false when unregistered.
	 */
	function mvweb_core_get_section( $type ) {
		$types = mvweb_core_sections();

		return isset( $types[ $type ] ) ? $types[ $type ] : false;
	}
}

if ( ! function_exists( 'mvweb_core_section_is_active' ) ) {
	/**
	 * Whether a registered type may print on this site.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type Type slug.
	 *
	 * @return bool
	 */
	function mvweb_core_section_is_active( $type ) {
		$definition = mvweb_core_get_section( $type );

		if ( ! $definition ) {
			return false;
		}

		return is_callable( $definition['active'] ) && (bool) call_user_func( $definition['active'] );
	}
}

if ( ! function_exists( 'mvweb_core_section_setting' ) ) {
	/**
	 * The theme_mod key holding one field of one type on the homepage.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type  Type slug.
	 * @param string $field Field id.
	 *
	 * @return string
	 */
	function mvweb_core_section_setting( $type, $field ) {
		return 'mvweb_section_' . str_replace( '-', '_', sanitize_key( $type ) ) . '_' . sanitize_key( $field );
	}
}

if ( ! function_exists( 'mvweb_core_sections_limit' ) ) {
	/**
	 * How many sections one page may hold.
	 *
	 * @since 0.1.0
	 *
	 * @return int
	 */
	function mvweb_core_sections_limit() {
		/**
		 * Filter the maximum number of sections on a page.
		 *
		 * @since 0.1.0
		 *
		 * @param int $limit Maximum rows kept by the sanitizer.
		 */
		return max( 1, (int) apply_filters( 'mvweb_core_sections_limit', 40 ) );
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_sections' ) ) {
	/**
	 * Sanitize the whole section list of a page.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw list of rows.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_sanitize_sections( $value ) {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$clean = array();
		$limit = mvweb_core_sections_limit();

		foreach ( $value as $row ) {
			if ( count( $clean ) >= $limit ) {
				break;
			}

			if ( ! is_array( $row ) || empty( $row['type'] ) || ! is_string( $row['type'] ) ) {
				continue;
			}

			$type = $row['type'];

			if ( '' === $type || sanitize_key( $type ) !== $type ) {
				continue;
			}

			$definition = mvweb_core_get_section( $type );
			$props      = isset( $row['props'] ) && is_array( $row['props'] ) ? $row['props'] : array();
			$uid        = isset( $row['uid'] ) && is_string( $row['uid'] ) ? $row['uid'] : '';

			$item = array(
				'uid'   => wp_is_uuid( $uid, 4 ) ? $uid : wp_generate_uuid4(),
				'type'  => $type,
				'v'     => isset( $row['v'] ) ? max( 1, absint( $row['v'] ) ) : 1,
				'props' => $definition
					? mvweb_core_sanitize_props( $props, $definition['fields'] )
					: mvweb_core_sanitize_unknown_props( $props ),
			);

			if ( ! empty( $row['hidden'] ) ) {
				$item['hidden'] = true;
			}

			$clean[] = $item;
		}

		return $clean;
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_props' ) ) {
	/**
	 * Sanitize one section's values against its schema.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props  Raw values.
	 * @param array $fields Normalized field schema.
	 * @param int   $depth  Current nesting level.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_sanitize_props( $props, array $fields, $depth = 0 ) {
		$clean = array();

		foreach ( $fields as $id => $field ) {
			$clean[ $id ] = array_key_exists( $id, $props )
				? mvweb_core_sanitize_value( $props[ $id ], $field, $depth )
				: $field['default'];
		}

		return $clean;
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_value' ) ) {
	/**
	 * Sanitize one value by its declared field type.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 * @param array $field Normalized field definition.
	 * @param int   $depth Current nesting level.
	 *
	 * @return mixed
	 */
	function mvweb_core_sanitize_value( $value, array $field, $depth = 0 ) {
		switch ( $field['type'] ) {
			case 'richtext':
				return wp_kses_post( (string) $value );

			case 'code':
				return mvweb_core_sanitize_code( $value );

			case 'textarea':
				return sanitize_textarea_field( (string) $value );

			case 'line':
				return mvweb_core_sanitize_line( $value );

			case 'url':
				return esc_url_raw( (string) $value );

			case 'email':
				return sanitize_email( (string) $value );

			case 'image':
				$id = absint( $value );

				return wp_attachment_is_image( $id ) ? $id : 0;

			case 'toggle':
				return (bool) rest_sanitize_boolean( $value );

			case 'number':
				return mvweb_core_sanitize_number( $value, $field );

			case 'icon':
				return (string) preg_replace( '/[^a-z0-9\-]/', '', strtolower( (string) $value ) );

			case 'item':
				$id = absint( $value );

				return $id > 0 && get_post_type( $id ) === mvweb_core_post_type() ? $id : 0;

			case 'category':
				$id = absint( $value );

				return $id > 0 && term_exists( $id, (string) $field['taxonomy'] ) ? $id : 0;

			case 'select':
				$allowed = array_keys( (array) $field['choices'] );

				return in_array( (string) $value, array_map( 'strval', $allowed ), true )
					? (string) $value
					: $field['default'];

			case 'color':
				return (string) sanitize_hex_color( (string) $value );

			case 'parts':
				return mvweb_core_sanitize_parts( $value, $field );

			case 'repeat':
				return mvweb_core_sanitize_repeat( $value, $field, $depth );

			default:
				return sanitize_text_field( (string) $value );
		}
	}
}

if ( ! function_exists( 'mvweb_core_field_choices' ) ) {
	/**
	 * The options of a field that is drawn as a list.
	 *
	 * @since 0.1.0
	 *
	 * @param array $field Normalized field definition.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_field_choices( array $field ) {
		if ( 'icon' === $field['type'] ) {
			return mvweb_core_icon_choices();
		}

		if ( 'item' === $field['type'] ) {
			return mvweb_core_item_choices();
		}

		if ( 'category' === $field['type'] ) {
			return mvweb_core_category_choices( (string) $field['taxonomy'] );
		}

		return (array) $field['choices'];
	}
}

if ( ! function_exists( 'mvweb_core_category_choices' ) ) {
	/**
	 * Terms for a field that picks one, "all of them" first.
	 *
	 * @since 0.1.0
	 *
	 * @param string $taxonomy Optional. Taxonomy; blog categories by default.
	 *
	 * @return array<int,string> Term id => name; 0 stands for every term.
	 */
	function mvweb_core_category_choices( $taxonomy = 'category' ) {
		$choices = array( 0 => 'category' === $taxonomy ? __( 'All categories', 'mvweb-core' ) : __( 'All', 'mvweb-core' ) );
		$terms   = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
			)
		);

		foreach ( is_array( $terms ) ? $terms : array() as $term ) {
			$choices[ $term->term_id ] = $term->name;
		}

		return $choices;
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_line' ) ) {
	/**
	 * One line of plain text where <br> is the only markup kept.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string
	 */
	function mvweb_core_sanitize_line( $value ) {
		$parts = preg_split( '#<br\s*/?>#i', (string) $value );

		return implode( '<br>', array_map( 'sanitize_text_field', (array) $parts ) );
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_code' ) ) {
	/**
	 * A piece of markup pasted from a widget: a booking form, a map, a player.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string
	 */
	function mvweb_core_sanitize_code( $value ) {
		return current_user_can( 'unfiltered_html' ) ? trim( (string) $value ) : wp_kses_post( (string) $value );
	}
}

if ( ! function_exists( 'mvweb_core_line' ) ) {
	/**
	 * Print-ready HTML of a 'line' value.
	 *
	 * @since 0.1.0
	 *
	 * @param string $value Stored value.
	 *
	 * @return string
	 */
	function mvweb_core_line( $value ) {
		return wp_kses( (string) $value, array( 'br' => array() ) );
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_number' ) ) {
	/**
	 * Clamp a number to the bounds its field declares.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 * @param array $field Normalized field definition.
	 *
	 * @return float|int
	 */
	function mvweb_core_sanitize_number( $value, array $field ) {
		if ( ! is_numeric( $value ) ) {
			return is_numeric( $field['default'] ) ? $field['default'] + 0 : 0;
		}

		$number = $value + 0;

		if ( is_numeric( $field['min'] ) ) {
			$number = max( $field['min'] + 0, $number );
		}

		if ( is_numeric( $field['max'] ) ) {
			$number = min( $field['max'] + 0, $number );
		}

		return $number;
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_repeat' ) ) {
	/**
	 * Sanitize a repeatable list against its subfield schema.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw list.
	 * @param array $field Normalized field definition.
	 * @param int   $depth Current nesting level.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_sanitize_repeat( $value, array $field, $depth = 0 ) {
		if ( ! is_array( $value ) || $depth >= 2 || empty( $field['fields'] ) ) {
			return array();
		}

		$rows  = array();
		$limit = is_numeric( $field['max'] ) ? (int) $field['max'] : 50;

		foreach ( $value as $row ) {
			if ( count( $rows ) >= $limit ) {
				break;
			}

			if ( ! is_array( $row ) ) {
				continue;
			}

			$rows[] = mvweb_core_sanitize_props( $row, $field['fields'], $depth + 1 );
		}

		return $rows;
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_unknown_props' ) ) {
	/**
	 * Sanitize the values of a type no schema describes.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 * @param int   $depth Current nesting level.
	 *
	 * @return mixed
	 */
	function mvweb_core_sanitize_unknown_props( $value, $depth = 0 ) {
		if ( is_array( $value ) ) {
			if ( $depth >= 4 ) {
				return array();
			}

			$clean = array();

			foreach ( $value as $key => $item ) {
				$clean[ sanitize_key( $key ) ] = mvweb_core_sanitize_unknown_props( $item, $depth + 1 );
			}

			return $clean;
		}

		if ( is_bool( $value ) || is_int( $value ) || is_float( $value ) ) {
			return $value;
		}

		return sanitize_text_field( (string) $value );
	}
}

if ( ! function_exists( 'mvweb_core_post_sections' ) ) {
	/**
	 * The section rows saved on a page.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Optional. Defaults to the current post.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_post_sections( $post_id = 0 ) {
		$post_id = $post_id ? (int) $post_id : (int) get_the_ID();

		if ( $post_id <= 0 ) {
			return array();
		}

		$rows = get_post_meta( $post_id, '_mvweb_sections', true );

		return is_array( $rows ) ? $rows : array();
	}
}

if ( ! function_exists( 'mvweb_core_home_sections' ) ) {
	/**
	 * The section rows of the homepage.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_home_sections() {
		$rows = json_decode( (string) get_theme_mod( 'mvweb_home_rows', '' ), true, 10 );

		if ( ! is_array( $rows ) ) {
			return array();
		}

		$shown = array();

		foreach ( $rows as $row ) {
			if ( is_array( $row ) && ! empty( $row['type'] ) && empty( $row['hidden'] ) ) {
				$row['home'] = true;
				$shown[]     = $row;
			}
		}

		return $shown;
	}
}

if ( ! function_exists( 'mvweb_core_theme_mod_props' ) ) {
	/**
	 * One type's field values as the homepage stores them.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type Type slug.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_theme_mod_props( $type ) {
		$definition = mvweb_core_get_section( $type );

		if ( ! $definition ) {
			return array();
		}

		$props = array();

		foreach ( $definition['fields'] as $id => $field ) {
			$value = get_theme_mod( mvweb_core_section_setting( $type, $id ), $field['default'] );

			if ( 'repeat' === $field['type'] ) {
				if ( is_string( $value ) ) {
					$decoded = json_decode( $value, true, 5 );
					$value   = is_array( $decoded ) ? $decoded : array();
				}

				$value = mvweb_core_sanitize_repeat( $value, $field );
			}

			if ( 'parts' === $field['type'] ) {
				$value = mvweb_core_sanitize_parts( $value, $field );
			}

			$props[ $id ] = $value;
		}

		return $props;
	}
}

if ( ! function_exists( 'mvweb_core_render_sections' ) ) {
	/**
	 * Render a list of section rows.
	 *
	 * @since 0.1.0
	 *
	 * @param array $rows Rows as stored: 'type' and 'props'.
	 *
	 * @return void
	 */
	function mvweb_core_render_sections( array $rows ) {
		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) || empty( $row['type'] ) || ! is_string( $row['type'] ) ) {
				continue;
			}

			mvweb_core_render_section(
				$row['type'],
				isset( $row['props'] ) && is_array( $row['props'] ) ? $row['props'] : array(),
				array(
					'uid'  => isset( $row['uid'] ) ? (string) $row['uid'] : '',
					'home' => ! empty( $row['home'] ),
				)
			);
		}
	}
}

if ( ! function_exists( 'mvweb_core_render_section' ) ) {
	/**
	 * Render one section.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type  Type slug.
	 * @param array  $props Field values.
	 * @param array  $args  Extra arguments passed to the template.
	 *
	 * @return void
	 */
	function mvweb_core_render_section( $type, array $props = array(), array $args = array() ) {
		$type       = sanitize_key( $type );
		$definition = mvweb_core_get_section( $type );

		if ( ! $definition || ! mvweb_core_section_is_active( $type ) ) {
			return;
		}

		if ( ! empty( $definition['global'] ) ) {
			$props       = mvweb_core_theme_mod_props( $type );
			$args['uid'] = '';
		}

		$args['type']  = $type;
		$args['props'] = mvweb_core_section_props( $type, $props );

		if ( 'banner' === $type && mvweb_core_offer_ended( isset( $args['props']['until'] ) ? $args['props']['until'] : '' ) ) {
			return;
		}

		/**
		 * Short-circuit the render of one section.
		 *
		 * @since 0.1.0
		 *
		 * @param bool   $handled Whether the section has been rendered already.
		 * @param string $type    Type slug.
		 * @param array  $args    Render arguments, including the merged props.
		 */
		if ( true === apply_filters( 'mvweb_core_pre_render_section', false, $type, $args ) ) {
			return;
		}

		$slug = (string) $definition['render'];

		if ( '' === $slug || 0 !== validate_file( $slug ) ) {
			return;
		}

		if ( is_customize_preview() && ( empty( $args['uid'] ) || ! empty( $args['home'] ) ) && function_exists( 'mvweb_core_home_section' ) ) {
			ob_start();
			get_template_part( $slug, null, $args );

			echo preg_replace( '/<([a-z][a-z0-9]*)\b/i', '<$1 data-mvweb-cz-section="' . esc_attr( ! empty( $args['home'] ) && empty( $definition['global'] ) ? 'mvweb_cz_home_blocks' : mvweb_core_home_section( $type ) ) . '"', (string) ob_get_clean(), 1 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The theme's own template, escaped inside; only an escaped attribute is added.

			return;
		}

		get_template_part( $slug, null, $args );
	}
}

if ( ! function_exists( 'mvweb_core_section_props' ) ) {
	/**
	 * Merge stored values with the schema defaults.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type  Type slug.
	 * @param array  $props Stored values.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_section_props( $type, array $props = array() ) {
		$definition = mvweb_core_get_section( $type );

		if ( ! $definition ) {
			return array();
		}

		$merged = array();

		foreach ( $definition['fields'] as $id => $field ) {
			$merged[ $id ] = array_key_exists( $id, $props ) && null !== $props[ $id ]
				? $props[ $id ]
				: $field['default'];
		}

		return $merged;
	}
}

if ( ! function_exists( 'mvweb_core_request_sections' ) ) {
	/**
	 * The rows this request is going to print.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_request_sections() {
		static $rows = null;

		if ( null !== $rows ) {
			return $rows;
		}

		if ( is_front_page() ) {
			$rows = mvweb_core_home_sections();
		} elseif ( is_page() && ! is_page_template() ) {
			$rows = array( array( 'type' => 'content' ) );
		} elseif ( is_singular( mvweb_core_section_post_types() ) ) {
			$rows = array_values(
				array_filter(
					mvweb_core_post_sections( get_queried_object_id() ),
					static function ( $row ) {
						return empty( $row['hidden'] );
					}
				)
			);
		} else {
			$rows = mvweb_core_context_rows();
		}

		return $rows;
	}
}

if ( ! function_exists( 'mvweb_core_request_section_types' ) ) {
	/**
	 * The distinct, printable section types of this request.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_request_section_types() {
		$types = array();

		foreach ( mvweb_core_request_sections() as $row ) {
			if ( ! is_array( $row ) || empty( $row['type'] ) || ! is_string( $row['type'] ) ) {
				continue;
			}

			$type = sanitize_key( $row['type'] );

			if ( mvweb_core_section_is_active( $type ) ) {
				$types[ $type ] = $type;
			}
		}

		return array_values( $types );
	}
}

if ( ! function_exists( 'mvweb_core_section_post_types' ) ) {
	/**
	 * The post types whose entries are assembled from sections.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_section_post_types() {
		/**
		 * Filters the post types assembled from sections.
		 *
		 * @since 0.1.0
		 *
		 * @param string[] $post_types Post type slugs.
		 */
		return (array) apply_filters( 'mvweb_core_section_post_types', array( 'page', 'mv_service', 'mv_facet' ) );
	}
}

if ( ! function_exists( 'mvweb_core_register_section_meta' ) ) {
	/**
	 * Register the meta the page builder writes.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_section_meta() {
		foreach ( mvweb_core_section_post_types() as $post_type ) {
			register_post_meta(
				$post_type,
				'_mvweb_sections',
				array(
					'type'              => 'array',
					'single'            => true,
					'default'           => array(),
					'sanitize_callback' => 'mvweb_core_sanitize_sections',
					'auth_callback'     => 'mvweb_core_section_meta_auth',
					'show_in_rest'      => false,
					'revisions_enabled' => post_type_supports( $post_type, 'revisions' ),
				)
			);
		}
	}
}
add_action( 'init', 'mvweb_core_register_section_meta' );

if ( ! function_exists( 'mvweb_core_section_meta_auth' ) ) {
	/**
	 * Whether a user may write the section meta of a page.
	 *
	 * @since 0.1.0
	 *
	 * @param bool   $allowed  Current answer.
	 * @param string $meta_key Meta key.
	 * @param int    $post_id  Post the meta belongs to.
	 * @param int    $user_id  User asking.
	 *
	 * @return bool
	 */
	function mvweb_core_section_meta_auth( $allowed, $meta_key, $post_id, $user_id ) {
		return user_can( $user_id, 'edit_post', $post_id );
	}
}

if ( ! function_exists( 'mvweb_core_offer_ended' ) ) {
	/**
	 * Whether an offer is over: the site's own calendar has passed its last day.
	 *
	 * @since 0.1.0
	 *
	 * @param string $until Last day, Y-m-d; empty — the offer does not end.
	 *
	 * @return bool
	 */
	function mvweb_core_offer_ended( $until ) {
		$until = trim( (string) $until );

		if ( '' === $until ) {
			return false;
		}

		$last = date_create_immutable( $until, wp_timezone() );

		return $last && $last->format( 'Y-m-d' ) < wp_date( 'Y-m-d' );
	}
}
