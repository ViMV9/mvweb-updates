<?php
/**
 * The marketplaces: the list with logos in the Customizer, the choice from it on the item.
 *
 * The item keeps its marketplaces in _mvweb_markets as before, one line of
 * name, vertical bar and address; the editing screen draws the lines as a
 * select of the list and an address field.
 *
 * @package MVweb_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_markets_default' ) ) {
	/**
	 * The marketplaces a new site starts with.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array{name:string,logo:string}>
	 */
	function mvweb_core_markets_default() {
		$rows = array();

		foreach ( array( 'Ozon', 'Wildberries', __( 'Yandex Market', 'mvweb-core' ), __( 'Megamarket', 'mvweb-core' ), __( 'Avito', 'mvweb-core' ) ) as $name ) {
			$rows[] = array(
				'name' => $name,
				'logo' => '',
			);
		}

		return $rows;
	}
}

if ( ! function_exists( 'mvweb_core_markets' ) ) {
	/**
	 * The marketplaces of the site.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,int> Name => logo attachment id, 0 without a logo.
	 */
	function mvweb_core_markets() {
		$rows    = json_decode( (string) get_theme_mod( 'mvweb_markets', wp_json_encode( mvweb_core_markets_default() ) ), true );
		$markets = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$name = is_array( $row ) && isset( $row['name'] ) ? trim( sanitize_text_field( (string) $row['name'] ) ) : '';

			if ( '' !== $name && ! isset( $markets[ $name ] ) ) {
				$markets[ $name ] = isset( $row['logo'] ) ? absint( $row['logo'] ) : 0;
			}
		}

		return $markets;
	}
}

if ( ! function_exists( 'mvweb_core_market_logo' ) ) {
	/**
	 * The logo of a marketplace, by its name in any case.
	 *
	 * @since 0.1.0
	 *
	 * @param string $name Name of the marketplace on the item.
	 *
	 * @return int Attachment id, 0 without a logo.
	 */
	function mvweb_core_market_logo( $name ) {
		$name = mb_strtolower( trim( (string) $name ) );

		foreach ( mvweb_core_markets() as $market => $logo ) {
			if ( mb_strtolower( $market ) === $name ) {
				return $logo && wp_attachment_is_image( $logo ) ? $logo : 0;
			}
		}

		return 0;
	}
}

if ( ! function_exists( 'mvweb_core_markets_fields' ) ) {
	/**
	 * The list of the marketplaces in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Customizer Kit.
	 *
	 * @return void
	 */
	function mvweb_core_markets_fields( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'repeater',
					'settings'    => 'mvweb_markets',
					'section'     => 'mvweb_cz_catalog_product',
					'label'       => __( 'Marketplaces', 'mvweb-core' ),
					'description' => __( 'The product picks a marketplace from this list and gets the address of its page there. A logo is a small square picture; without it the name alone is shown.', 'mvweb-core' ),
					'default'     => wp_json_encode( mvweb_core_markets_default() ),
					'fields'      => array(
						'name' => array(
							'type'    => 'text',
							'label'   => __( 'Name of the marketplace', 'mvweb-core' ),
							'choices' => array(),
						),
						'logo' => array(
							'type'    => 'image',
							'label'   => __( 'Logo', 'mvweb-core' ),
							'choices' => array(),
						),
					),
				),
			)
		);
	}
}
add_action( 'mvweb_cz_register', 'mvweb_core_markets_fields' );

if ( ! function_exists( 'mvweb_core_markets_assets' ) ) {
	/**
	 * The script that draws the marketplaces of an item as rows of a select and an address.
	 *
	 * @since 0.1.0
	 *
	 * @param string $hook Admin page.
	 *
	 * @return void
	 */
	function mvweb_core_markets_assets( $hook ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		if ( ! in_array( $hook, array( 'post.php', 'post-new.php' ), true ) || ! $screen || ! in_array( $screen->post_type, array( 'product', 'mv_item' ), true ) ) {
			return;
		}

		$relative = mvweb_core_asset_path( '/admin/js/markets-field.js' );

		wp_enqueue_script( 'mvweb-core-markets-field', MVWEB_CORE_URI . $relative, array(), mvweb_core_asset_version( $relative ), true );
		wp_add_inline_script(
			'mvweb-core-markets-field',
			'window.mvwebCoreMarkets = ' . wp_json_encode(
				array(
					'names' => array_map( 'strval', array_keys( mvweb_core_markets() ) ),
					'l10n'  => array(
						'choose' => __( 'Marketplace', 'mvweb-core' ),
						'url'    => __( 'Address of the product page', 'mvweb-core' ),
						'add'    => __( 'Add a marketplace', 'mvweb-core' ),
						'remove' => __( 'Remove', 'mvweb-core' ),
					),
				)
			) . ';',
			'before'
		);
	}
}
add_action( 'admin_enqueue_scripts', 'mvweb_core_markets_assets' );
