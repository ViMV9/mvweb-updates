<?php
/**
 * Theme setup.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_setup' ) ) {
	/**
	 * Register theme supports, menus and image sizes.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_setup() {
		add_theme_support( 'title-tag' );
		add_theme_support( 'post-thumbnails' );
		add_theme_support( 'automatic-feed-links' );
		add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption' ) );
		add_theme_support( 'responsive-embeds' );
		add_theme_support(
			'custom-logo',
			array(
				'height'      => 120,
				'width'       => 480,
				'flex-height' => true,
				'flex-width'  => true,
			)
		);

		register_nav_menus(
			array(
				'primary'  => __( 'Primary menu', 'mvweb-core' ),
				'top'      => __( 'Top bar menu', 'mvweb-core' ),
				'footer'   => __( 'Footer menu, first column', 'mvweb-core' ),
				'footer-2' => __( 'Footer menu, second column', 'mvweb-core' ),
				'legal'    => __( 'Legal links', 'mvweb-core' ),
			)
		);

		/**
		 * Filters the image sizes the core asks for, by role.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,array{0:int,1:int,2:bool}> $sizes Width, height and crop by size name.
		 */
		$sizes = (array) apply_filters(
			'mvweb_core_image_sizes',
			array(
				'mvweb_card' => array( 800, 1000, true ),
				'mvweb_wide' => array( 1600, 1000, true ),
			)
		);

		foreach ( $sizes as $name => $size ) {
			add_image_size( $name, (int) $size[0], (int) $size[1], ! empty( $size[2] ) );
		}
	}
}
add_action( 'after_setup_theme', 'mvweb_core_setup' );

if ( ! function_exists( 'mvweb_core_separate_block_assets' ) ) {
	/**
	 * Load block styles per rendered block instead of one bundle.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_separate_block_assets() {
		return true;
	}
}
add_filter( 'should_load_separate_core_block_assets', 'mvweb_core_separate_block_assets' );

if ( ! function_exists( 'mvweb_core_keep_hyphens' ) ) {
	/**
	 * Leave a typed hyphen alone.
	 *
	 * @since 0.1.0
	 *
	 * @param string $translation Translated text.
	 * @param string $text        Text to translate.
	 * @param string $context     Context of the string.
	 * @param string $domain      Text domain.
	 *
	 * @return string
	 */
	function mvweb_core_keep_hyphens( $translation, $text, $context, $domain ) {
		if ( 'default' === $domain && ( 'en dash' === $context || 'em dash' === $context ) ) {
			return '-';
		}

		return $translation;
	}
}
add_filter( 'gettext_with_context', 'mvweb_core_keep_hyphens', 10, 4 );

if ( ! function_exists( 'mvweb_core_archive_title_prefix' ) ) {
	/**
	 * Drop the "Category:" core puts before the name of an archive.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_archive_title_prefix() {
		return '';
	}
}
add_filter( 'get_the_archive_title_prefix', 'mvweb_core_archive_title_prefix' );

if ( ! function_exists( 'mvweb_core_page_template_names' ) ) {
	/**
	 * Names of the theme's page templates in the site language.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $templates Template names keyed by file.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_page_template_names( $templates ) {
		$names = array(
			'page-templates/builder.php'   => __( 'Page builder', 'mvweb-core' ),
			'page-templates/favorites.php' => __( 'Favourites', 'mvweb-core' ),
		);

		foreach ( $names as $file => $name ) {
			if ( isset( $templates[ $file ] ) ) {
				$templates[ $file ] = $name;
			}
		}

		return $templates;
	}
}
add_filter( 'theme_page_templates', 'mvweb_core_page_template_names' );
