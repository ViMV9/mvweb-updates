<?php
/**
 * Ready-made set of sections: a service page.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter(
	'mvweb_core_section_presets',
	static function ( $presets ) {
		$request = '#request';

		$presets['market-service'] = array(
			'label'       => __( 'Service page', 'mvweb-core' ),
			'description' => __( 'Heading, benefits, price list, steps, plans, photos, before and after, works, questions and a call to action', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'hero',
					'props' => array(
						'view'        => '5',
						'title'       => __( 'Everything for your pet, from food to a bed, in one shop', 'mvweb-core' ),
						'features'    => array(
							array( 'text' => __( 'Free delivery over 3 000 ₽', 'mvweb-core' ) ),
							array( 'text' => __( 'Fresh food with a guarantee', 'mvweb-core' ) ),
							array( 'text' => __( 'Returns within 14 days', 'mvweb-core' ) ),
							array( 'text' => __( 'Wholesale prices from 10 pieces', 'mvweb-core' ) ),
						),
						'button_text' => __( 'Go to the catalogue', 'mvweb-core' ),
						'button_url'  => $request,
						'trust'       => array(
							array(
								'number' => '12 000+',
								'text'   => __( 'happy<br>customers', 'mvweb-core' ),
							),
							array(
								'number' => __( '4.9', 'mvweb-core' ),
								'text'   => __( 'average rating<br>from reviews', 'mvweb-core' ),
							),
							array(
								'number' => __( '1–2 days', 'mvweb-core' ),
								'text'   => __( 'delivery to<br>most cities', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'features',
					'props' => array(
						'view'       => '1',
						'background' => 'plain',
						'title'      => __( 'Everything we are chosen for', 'mvweb-core' ),
						'text'       => __( 'We make a shop that is easy to buy from for your pet: fast, honest and without surprises.', 'mvweb-core' ),
						'blocks'     => array(
							array(
								'icon'  => 'truck-delivery',
								'title' => __( 'Fast delivery', 'mvweb-core' ),
								'text'  => implode(
									"\n",
									array(
										__( 'By courier across the city in a day', 'mvweb-core' ),
										__( 'To pickup points all over Russia', 'mvweb-core' ),
										__( 'The tracking number arrives right after dispatch', 'mvweb-core' ),
									),
								),
							),
							array(
								'icon'  => 'leaf',
								'title' => __( 'Natural ingredients', 'mvweb-core' ),
								'text'  => implode(
									"\n",
									array(
										__( 'No artificial colours', 'mvweb-core' ),
										__( 'Raw materials selected at our own production', 'mvweb-core' ),
										__( 'The full composition is on the pack', 'mvweb-core' ),
									),
								),
							),
							array(
								'icon'  => 'refresh',
								'title' => __( 'Exchange and returns', 'mvweb-core' ),
								'text'  => implode(
									"\n",
									array(
										__( '30 days to return', 'mvweb-core' ),
										__( 'We pick the order up by courier', 'mvweb-core' ),
										__( 'Money back within three days', 'mvweb-core' ),
									),
								),
							),
							array(
								'icon'  => 'headset',
								'title' => __( 'Live support', 'mvweb-core' ),
								'text'  => implode(
									"\n",
									array(
										__( 'We answer daily from 9:00 to 21:00', 'mvweb-core' ),
										__( 'Phone, Telegram and WhatsApp', 'mvweb-core' ),
										__( 'We will suggest food for the age and breed', 'mvweb-core' ),
									),
								),
							),
						),
					),
				),
				array(
					'type'  => 'services',
					'props' => array(
						'view'       => '3',
						'background' => 'surface',
						'kicker'     => __( 'Services', 'mvweb-core' ),
						'title'      => __( 'We build and rebuild country houses', 'mvweb-core' ),
						'text'       => __( 'From design to handover: one contract, a fixed estimate and a warranty on all work.', 'mvweb-core' ),
						'source'     => 'manual',
						'items'      => array(
							array(
								'icon'  => 'file-text',
								'title' => __( 'House design', 'mvweb-core' ),
								'text'  => __( 'Architectural and structural design, a layout for your plot and budget.', 'mvweb-core' ),
								'price' => __( '900 ₽/m²', 'mvweb-core' ),
							),
							array(
								'icon'  => 'home',
								'title' => __( 'Aerated concrete houses', 'mvweb-core' ),
								'text'  => __( 'Warm houses with even walls, the shell in 2 months, built to the design.', 'mvweb-core' ),
								'price' => __( '32 000 ₽/m²', 'mvweb-core' ),
							),
							array(
								'icon'  => 'layout-grid',
								'title' => __( 'Timber frame houses', 'mvweb-core' ),
								'text'  => __( 'Fast building on screw piles, ready for finishing in 6 weeks.', 'mvweb-core' ),
								'price' => __( '24 000 ₽/m²', 'mvweb-core' ),
							),
							array(
								'icon'  => 'sparkles',
								'title' => __( 'Banyas and saunas', 'mvweb-core' ),
								'text'  => __( 'Log and frame banyas with a steam room, a washroom and a terrace, all utilities included.', 'mvweb-core' ),
								'price' => '420 000 ₽',
							),
							array(
								'icon'  => 'package',
								'title' => __( 'Garages and outbuildings', 'mvweb-core' ),
								'text'  => __( 'Garages for one and two cars, sheds and canopies: foundation, walls, gates.', 'mvweb-core' ),
								'price' => '290 000 ₽',
							),
							array(
								'icon'  => 'refresh',
								'title' => __( 'Reconstruction and extensions', 'mvweb-core' ),
								'text'  => __( 'Extensions, a second floor, remodelling and strengthening of structures.', 'mvweb-core' ),
								'price' => __( '15 000 ₽/m²', 'mvweb-core' ),
							),
							array(
								'icon'  => 'shield-check',
								'title' => __( 'Foundations', 'mvweb-core' ),
								'text'  => __( 'Strip, slab and pile foundations with a soil survey and waterproofing.', 'mvweb-core' ),
								'price' => __( '4 500 ₽/m²', 'mvweb-core' ),
							),
							array(
								'icon'  => 'award',
								'title' => __( 'Roofing', 'mvweb-core' ),
								'text'  => __( 'Roofs of any complexity: metal tiles, standing seam, soft roofing.', 'mvweb-core' ),
								'price' => __( '1 800 ₽/m²', 'mvweb-core' ),
							),
							array(
								'icon'  => 'adjustments-horizontal',
								'title' => __( 'Utility systems', 'mvweb-core' ),
								'text'  => __( 'Heating, water supply, sewage and electrics turnkey, with commissioning.', 'mvweb-core' ),
								'price' => __( '1 200 ₽/m²', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'price-list',
					'props' => array(
						'view'        => '1',
						'background'  => 'plain',
						'kicker'      => __( 'Grooming salon', 'mvweb-core' ),
						'title'       => __( 'Grooming price list', 'mvweb-core' ),
						'text'        => __( 'The price depends on the size of the breed and the condition of the coat.', 'mvweb-core' ),
						'col_0'       => __( 'Service', 'mvweb-core' ),
						'col_1'       => __( 'Small breeds', 'mvweb-core' ),
						'col_2'       => __( 'Medium breeds', 'mvweb-core' ),
						'col_3'       => __( 'Large breeds', 'mvweb-core' ),
						'rows'        => array(
							array( 'title' => __( 'Clipping', 'mvweb-core' ) ),
							array(
								'title'   => __( 'Hygienic trim', 'mvweb-core' ),
								'note'    => __( 'Paws, belly, under the tail', 'mvweb-core' ),
								'price_1' => '800 ₽',
								'price_2' => '1 000 ₽',
								'price_3' => '1 300 ₽',
							),
							array(
								'title'   => __( 'Full clipper cut', 'mvweb-core' ),
								'price_1' => '1 800 ₽',
								'price_2' => '2 400 ₽',
								'price_3' => '3 200 ₽',
							),
							array(
								'title'   => __( 'Styled cut', 'mvweb-core' ),
								'note'    => __( 'Finished with scissors', 'mvweb-core' ),
								'price_1' => '2 500 ₽',
								'price_2' => '3 300 ₽',
								'price_3' => '4 200 ₽',
							),
							array( 'title' => __( 'Care', 'mvweb-core' ) ),
							array(
								'title'   => __( 'Bath with brushing', 'mvweb-core' ),
								'note'    => __( 'Shampoo and mask for the coat type', 'mvweb-core' ),
								'price_1' => '1 200 ₽',
								'price_2' => '1 600 ₽',
								'price_3' => '2 200 ₽',
							),
							array(
								'title'   => __( 'Undercoat combing', 'mvweb-core' ),
								'price_1' => '900 ₽',
								'price_2' => '1 300 ₽',
								'price_3' => '1 900 ₽',
							),
							array(
								'title'   => __( 'Nail trimming', 'mvweb-core' ),
								'price_1' => '300 ₽',
								'price_2' => '300 ₽',
								'price_3' => '400 ₽',
							),
						),
						'button_text' => __( 'Book a grooming', 'mvweb-core' ),
						'button_url'  => $request,
						'footnote'    => __( 'We will name the exact price after examining the pet. Prices are per procedure.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'steps',
					'props' => array(
						'view'       => '3',
						'background' => 'surface',
						'title'      => __( 'How an order goes', 'mvweb-core' ),
						'text'       => __( 'The whole way from choosing a product to a parcel at your door takes two or three days.', 'mvweb-core' ),
						'items'      => array(
							array(
								'title' => __( 'You choose products', 'mvweb-core' ),
								'text'  => __( 'You add food, toys and care products to the cart. If in doubt, write to us and we will advise.', 'mvweb-core' ),
							),
							array(
								'title' => __( 'You place the order', 'mvweb-core' ),
								'text'  => __( 'You give the address and a payment method. You can pay by card online or on delivery.', 'mvweb-core' ),
							),
							array(
								'title' => __( 'We pack the parcel', 'mvweb-core' ),
								'text'  => __( 'We pack it on the day of the order. Fragile items go in protective padding.', 'mvweb-core' ),
							),
							array(
								'title' => __( 'We hand it to delivery', 'mvweb-core' ),
								'text'  => __( 'We send the tracking number in a message. The courier calls an hour before arriving.', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'two-lists',
					'props' => array(
						'view'        => '1',
						'background'  => 'plain',
						'kicker'      => __( 'Subscription', 'mvweb-core' ),
						'title'       => __( 'What a food subscription includes', 'mvweb-core' ),
						'text'        => __( 'Terms of a monthly delivery of the set.', 'mvweb-core' ),
						'marks'       => 'yes-no',
						'left_title'  => __( 'Included in the subscription', 'mvweb-core' ),
						'left_items'  => implode(
							"\n",
							array(
								__( 'A month of food from the chosen line', 'mvweb-core' ),
								__( 'Free delivery to the door', 'mvweb-core' ),
								__( '10 % off everything else', 'mvweb-core' ),
								__( 'Pause or cancel at any time', 'mvweb-core' ),
								__( 'A gift with every third delivery', 'mvweb-core' ),
							),
						),
						'right_title' => __( 'Not included in the subscription', 'mvweb-core' ),
						'right_items' => implode(
							"\n",
							array(
								__( 'Treats and vitamins (paid separately)', 'mvweb-core' ),
								__( 'Urgent same-day delivery', 'mvweb-core' ),
								__( 'Carrying up the stairs without a lift', 'mvweb-core' ),
								__( 'Prescription veterinary diets', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'plans',
					'props' => array(
						'view'       => '3',
						'background' => 'surface',
						'kicker'     => __( 'Subscription', 'mvweb-core' ),
						'title'      => __( 'Food by subscription without the hassle', 'mvweb-core' ),
						'text'       => __( 'Choose a set, and we will take care of delivery and payment.', 'mvweb-core' ),
						'plans'      => array(
							array(
								'title'       => __( 'Trial', 'mvweb-core' ),
								'text'        => __( 'To get to know the service', 'mvweb-core' ),
								'price'       => '990 ₽',
								'unit'        => __( 'per month', 'mvweb-core' ),
								'items'       => implode(
									"\n",
									array(
										__( 'One kind of food to choose', 'mvweb-core' ),
										__( 'Delivery once a month', 'mvweb-core' ),
										__( 'Cancel without penalties', 'mvweb-core' ),
										'-' . __( 'A gift with delivery', 'mvweb-core' ),
										'-' . __( 'A personal manager', 'mvweb-core' ),
									),
								),
								'button_text' => __( 'Try it', 'mvweb-core' ),
								'button_url'  => $request,
							),
							array(
								'title'       => __( 'Standard', 'mvweb-core' ),
								'badge'       => __( 'Popular', 'mvweb-core' ),
								'text'        => __( 'The best choice for one pet', 'mvweb-core' ),
								'price'       => '1 890 ₽',
								'unit'        => __( 'per month', 'mvweb-core' ),
								'items'       => implode(
									"\n",
									array(
										__( 'A month of food and treats', 'mvweb-core' ),
										__( 'Free delivery', 'mvweb-core' ),
										__( '10% off the catalogue', 'mvweb-core' ),
										__( 'Pause at any time', 'mvweb-core' ),
										'-' . __( 'A personal manager', 'mvweb-core' ),
									),
								),
								'button_text' => __( 'Subscribe', 'mvweb-core' ),
								'button_url'  => $request,
							),
							array(
								'title'       => __( 'Family', 'mvweb-core' ),
								'text'        => __( 'For two or more pets', 'mvweb-core' ),
								'price'       => '3 290 ₽',
								'unit'        => __( 'per month', 'mvweb-core' ),
								'items'       => implode(
									"\n",
									array(
										__( 'Food for two pets', 'mvweb-core' ),
										__( 'Free delivery', 'mvweb-core' ),
										__( '15% off the catalogue', 'mvweb-core' ),
										__( 'A gift with every delivery', 'mvweb-core' ),
										__( 'A personal manager', 'mvweb-core' ),
									),
								),
								'button_text' => __( 'Subscribe', 'mvweb-core' ),
								'button_url'  => $request,
							),
						),
					),
				),
				array(
					'type'  => 'before-after',
					'props' => array(
						'view'       => '3',
						'background' => 'plain',
						'kicker'     => __( 'Result', 'mvweb-core' ),
						'title'      => __( 'Before and after', 'mvweb-core' ),
						'text'       => __( 'Move the slider to compare the result with the original state.', 'mvweb-core' ),
						'source'     => 'rows',
						'pairs'      => array(
							array(
								'title' => __( 'Combing after shedding', 'mvweb-core' ),
								'text'  => __( 'A home procedure in 20 minutes: the undercoat is gone and the coat shines. We used a deshedding tool and a detangling spray.', 'mvweb-core' ),
								'facts' => implode(
									"\n",
									array(
										__( 'Time: 20 minutes', 'mvweb-core' ),
										__( 'Tool: Deshedding tool', 'mvweb-core' ),
										__( 'Product: Detangling spray', 'mvweb-core' ),
									),
								),
							),
							array(
								'title' => __( 'Pet bed repair', 'mvweb-core' ),
								'text'  => __( 'We replaced the filling and renewed the cover. The bed is back in use and keeps its shape again.', 'mvweb-core' ),
								'facts' => implode(
									"\n",
									array(
										__( 'Job: Filling replaced', 'mvweb-core' ),
										__( 'Cover: Renewed', 'mvweb-core' ),
										__( 'Result: Keeps its shape', 'mvweb-core' ),
									),
								),
							),
						),
					),
				),
				array(
					'type'  => 'works',
					'props' => array(
						'view'       => '1',
						'background' => 'surface',
						'kicker'     => __( 'Portfolio', 'mvweb-core' ),
						'title'      => __( 'Finished works', 'mvweb-core' ),
						'text'       => __( 'How the pet zones and corners look once they are done.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'project',
					'props' => array(
						'view'       => '5',
						'background' => 'accent',
						'kicker'     => __( 'A ready set', 'mvweb-core' ),
						'title'      => __( 'The “Puppy’s first month” set', 'mvweb-core' ),
						'text'       => __( 'Everything needed for the first weeks at home: balanced food, bowls, a harness with a lead, teething toys and puppy pads. We put the set together with a vet.', 'mvweb-core' ),
						'facts'      => array(
							array(
								'value' => '12',
								'label' => __( 'items in the set', 'mvweb-core' ),
							),
							array(
								'value' => '30',
								'unit'  => __( 'days', 'mvweb-core' ),
								'label' => __( 'of food rations', 'mvweb-core' ),
							),
							array(
								'value' => __( '3.4', 'mvweb-core' ),
								'unit'  => __( 'kg', 'mvweb-core' ),
								'label' => __( 'box weight', 'mvweb-core' ),
							),
							array(
								'value' => '1–2',
								'unit'  => __( 'day(s)', 'mvweb-core' ),
								'label' => __( 'delivery across Russia', 'mvweb-core' ),
							),
						),
						'prices'     => array(
							array(
								'label' => __( 'The whole set', 'mvweb-core' ),
								'value' => '4 990 ₽',
							),
							array(
								'label' => __( 'The set with delivery', 'mvweb-core' ),
								'value' => '5 390 ₽',
							),
							array(
								'label' => __( 'Food alone, 2 kg', 'mvweb-core' ),
								'value' => '1 290 ₽',
							),
						),
						'link_text'  => __( 'See what is in the set', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'photos',
					'props' => array(
						'view'       => '1',
						'background' => 'plain',
						'kicker'     => __( 'Our customers', 'mvweb-core' ),
						'title'      => __( 'Pets who are already with us', 'mvweb-core' ),
						'text'       => __( 'Send a photo of your pet in a review: we publish the best ones here.', 'mvweb-core' ),
						'items'      => array(
							array( 'caption' => __( 'Murka on her new bed', 'mvweb-core' ) ),
							array( 'caption' => __( 'Bim, three years old, loves ropes', 'mvweb-core' ) ),
							array( 'caption' => __( 'The first walk in a harness', 'mvweb-core' ) ),
							array( 'caption' => __( 'A ginger cat and a scratching post', 'mvweb-core' ) ),
							array( 'caption' => __( 'A puppy and his bowl', 'mvweb-core' ) ),
							array( 'caption' => __( 'Two friends on one mat', 'mvweb-core' ) ),
						),
					),
				),
				array(
					'type'  => 'faq',
					'props' => array(
						'view'        => '1',
						'background'  => 'surface',
						'kicker'      => __( 'Questions and answers', 'mvweb-core' ),
						'title'       => __( 'We answer frequent questions', 'mvweb-core' ),
						'text'        => __( 'Did not find your question? Write to us and we will answer in a messenger within 15 minutes.', 'mvweb-core' ),
						'button_text' => __( 'Ask a question', 'mvweb-core' ),
						'button_url'  => $request,
						'items'       => array(
							array(
								'icon'   => 'truck-delivery',
								'title'  => __( 'How much is delivery and when will it arrive?', 'mvweb-core' ),
								'answer' => __( 'We deliver within the city in a day and send to other regions by a carrier in 2–5 days. Delivery is free for orders over 3 000 ₽.', 'mvweb-core' ),
							),
							array(
								'icon'   => 'refresh',
								'title'  => __( 'Can I return food if my pet will not eat it?', 'mvweb-core' ),
								'answer' => __( 'Yes. We take back unopened packs within 14 days. If the food did not suit after a trial, write to us and we will offer a replacement.', 'mvweb-core' ),
							),
							array(
								'icon'   => 'arrows-left-right',
								'title'  => __( 'How do I choose the size of a collar or harness?', 'mvweb-core' ),
								'answer' => __( 'Measure the neck or chest with a soft tape and add two fingers of room. Every product page has a size chart.', 'mvweb-core' ),
							),
							array(
								'icon'   => 'leaf',
								'title'  => __( 'Do you have food for animals with allergies?', 'mvweb-core' ),
								'answer' => __( 'There is a separate line of single-protein and hypoallergenic foods. The “Features” filter in the catalogue shows only the suitable ones.', 'mvweb-core' ),
							),
							array(
								'icon'   => 'credit-card',
								'title'  => __( 'How do I pay for an order?', 'mvweb-core' ),
								'answer' => __( 'By card on the site, on delivery or by invoice for companies. All payments go through a secure bank gateway.', 'mvweb-core' ),
							),
							array(
								'icon'   => 'map-pin',
								'title'  => __( 'Can I pick up the order myself?', 'mvweb-core' ),
								'answer' => __( 'Yes, pickup is available from any of our shops. The order is ready an hour after confirmation.', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'cta',
					'props' => array(
						'view'        => '1',
						'background'  => 'accent',
						'title'       => __( 'Can’t find the right food? We will pick it in five minutes', 'mvweb-core' ),
						'text'        => __( 'Tell us about your pet and we will suggest three suitable options based on age, weight and allergies.', 'mvweb-core' ),
						'button_text' => __( 'Get a selection', 'mvweb-core' ),
						'button_url'  => $request,
					),
				),
			),
		);

		return $presets;
	}
);
