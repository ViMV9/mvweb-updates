<?php
/**
 * Ready-made set: the about-the-company page of a shop.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter(
	'mvweb_core_section_presets',
	static function ( $presets ) {
		$request = '#request';

		$presets['market-about'] = array(
			'label'       => __( 'About the company', 'mvweb-core' ),
			'description' => __( 'Story, figures, team, photos of the team, branches, contacts, map, contact form and a call to action', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'content',
					'props' => array(
						'view'       => '1',
						'background' => 'plain',
						'title'      => __( 'How we choose goods for the shelf', 'mvweb-core' ),
						'text'       => __( '<p>Our range includes only what we buy ourselves for our own pets. Before an item reaches the shelf, it is checked: the composition, the packaging, the shelf life and the reviews of people who use it every day.</p><p>We work directly with manufacturers, so we know where every batch comes from and can answer any question about the composition. If an item does not suit, it can be returned within 14 days.</p><p>We also pick separately what is rarely found in ordinary shops: food for sensitive digestion, soft beds made of dense cotton and toys that do not tear in one evening.</p>', 'mvweb-core' ),
						'image_side' => 'end',
						'image_size' => 'm',
					),
				),
				array(
					'type'  => 'stats',
					'props' => array(
						'view'       => '2',
						'background' => 'accent',
						'title'      => __( 'The brand in numbers', 'mvweb-core' ),
						'items'      => array(
							array(
								'icon'   => 'history',
								'number' => __( '12 years', 'mvweb-core' ),
								'label'  => __( 'we have been making pet goods', 'mvweb-core' ),
							),
							array(
								'icon'   => 'package',
								'number' => '86 000',
								'label'  => __( 'orders sent to customers', 'mvweb-core' ),
							),
							array(
								'icon'   => 'star',
								'number' => __( '4.9', 'mvweb-core' ),
								'label'  => __( 'average rating in reviews', 'mvweb-core' ),
							),
							array(
								'icon'   => 'category-2',
								'number' => '320',
								'label'  => __( 'items in the catalog', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'team',
					'props' => array(
						'view'       => '3',
						'background' => 'plain',
						'kicker'     => __( 'Specialists', 'mvweb-core' ),
						'title'      => __( 'Our team', 'mvweb-core' ),
						'text'       => __( 'We answer questions about nutrition, behaviour and care of pets.', 'mvweb-core' ),
						'count'      => 8,
					),
				),
				array(
					'type'  => 'team-photos',
					'props' => array(
						'view'        => '2',
						'background'  => 'surface',
						'kicker'      => __( 'Our team', 'mvweb-core' ),
						'title'       => __( 'People who care about your pet', 'mvweb-core' ),
						'text'        => __( 'Vets, technologists and dog trainers work together: they choose the composition, check every batch and answer the questions of customers.', 'mvweb-core' ),
						'button_text' => __( 'Meet the team', 'mvweb-core' ),
						'photos'      => array(
							array(
								'name' => __( 'Anna Lebedeva', 'mvweb-core' ),
								'role' => __( 'Feed consultant', 'mvweb-core' ),
							),
							array(
								'name' => __( 'Igor Sokolov', 'mvweb-core' ),
								'role' => __( 'Vet', 'mvweb-core' ),
							),
							array(
								'name' => __( 'Marina Orlova', 'mvweb-core' ),
								'role' => __( 'Warehouse and packing', 'mvweb-core' ),
							),
							array(
								'name' => __( 'Denis Krylov', 'mvweb-core' ),
								'role' => __( 'Dog trainer', 'mvweb-core' ),
							),
							array(
								'name' => __( 'The whole team', 'mvweb-core' ),
								'role' => __( 'Friday lunch', 'mvweb-core' ),
							),
							array(
								'name' => __( 'Olga Vetrova', 'mvweb-core' ),
								'role' => __( 'Technologist', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'branches',
					'props' => array(
						'view'       => '3',
						'background' => 'plain',
						'title'      => __( 'Addresses and opening hours', 'mvweb-core' ),
						'text'       => __( 'Choose where it is easier to drop in: you can pick up an online order everywhere.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'contacts',
					'props' => array(
						'view'       => '4',
						'background' => 'surface',
						'kicker'     => __( 'Contacts', 'mvweb-core' ),
						'title'      => __( 'Call us, we are in touch', 'mvweb-core' ),
						'phone_note' => __( 'Daily from 9:00 to 21:00', 'mvweb-core' ),
						'email_note' => __( 'We reply within a day', 'mvweb-core' ),
						'hours_note' => __( 'No breaks', 'mvweb-core' ),
						'chats_lead' => __( 'It is faster: we reply within a few minutes and can send a photo of the item.', 'mvweb-core' ),
						'map_title'  => __( 'How to find us', 'mvweb-core' ),
						'map_text'   => __( 'The map is shown here. Landmark: the entrance is from the yard, next to the pharmacy.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'embed',
					'props' => array(
						'view'       => '1',
						'background' => 'plain',
						'title'      => __( 'We are on the map', 'mvweb-core' ),
						'width'      => 'page',
					),
				),
				array(
					'type'  => 'contact-form',
					'props' => array(
						'view'       => '4',
						'background' => 'surface',
						'title'      => __( 'Request in two steps', 'mvweb-core' ),
						'text'       => __( 'First leave your contacts, then tell us what you are looking for: a manager will pick the goods with prices and terms.', 'mvweb-core' ),
						'note'       => __( 'We reply within 15 minutes from 9:00 to 21:00. If you wrote at night, we will reply in the morning.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'cta',
					'props' => array(
						'view'        => '1',
						'background'  => 'plain',
						'title'       => __( 'Can’t find the right food? We will pick it in five minutes', 'mvweb-core' ),
						'text'        => __( 'Tell us about your pet, and we will suggest three suitable options based on age, weight and allergies.', 'mvweb-core' ),
						'button_text' => __( 'Get a selection', 'mvweb-core' ),
						'button_url'  => $request,
					),
				),
			),
		);

		return $presets;
	}
);
