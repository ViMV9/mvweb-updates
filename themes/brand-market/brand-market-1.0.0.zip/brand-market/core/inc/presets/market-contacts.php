<?php
/**
 * Ready-made set: the contacts page of a shop.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter(
	'mvweb_core_section_presets',
	static function ( $presets ) {
		$presets['market-contacts'] = array(
			'label'       => __( 'Contacts', 'mvweb-core' ),
			'description' => __( 'Phone, e-mail, hours, messengers and map, pick-up points, questions, contact form and company details', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'contacts',
					'props' => array(
						'view'       => '1',
						'background' => 'plain',
						'title'      => __( 'How to reach us', 'mvweb-core' ),
						'text'       => __( 'Call, write to a messenger or come to the shop: we will help you choose the goods and place an order.', 'mvweb-core' ),
						'phone_note' => __( 'Daily from 9:00 to 21:00', 'mvweb-core' ),
						'email_note' => __( 'We reply within a day', 'mvweb-core' ),
						'hours_note' => __( 'No breaks', 'mvweb-core' ),
						'chats_lead' => __( 'It is faster: we reply within a few minutes and can send a photo of the item.', 'mvweb-core' ),
						'map_title'  => __( 'How to find us', 'mvweb-core' ),
						'map_text'   => __( 'The map is shown here. Landmark: the entrance is from the yard, next to the pharmacy.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'branches',
					'props' => array(
						'view'       => '2',
						'background' => 'surface',
						'title'      => __( 'Shops and pick-up points', 'mvweb-core' ),
						'text'       => __( 'Choose where it is easier to drop in: you can pick up an online order everywhere.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'faq',
					'props' => array(
						'view'       => '2',
						'background' => 'plain',
						'title'      => __( 'Before you call', 'mvweb-core' ),
						'items'      => array(
							array(
								'title'  => __( 'Can I pick up an order myself?', 'mvweb-core' ),
								'answer' => __( 'Yes, at any of our shops. We will send a message when the order is ready; it is kept for 5 days.', 'mvweb-core' ),
							),
							array(
								'title'  => __( 'How fast do you reply?', 'mvweb-core' ),
								'answer' => __( 'In messengers within 15 minutes during working hours, by e-mail within a day. If you wrote at night, we will reply in the morning.', 'mvweb-core' ),
							),
							array(
								'title'  => __( 'Where to write about wholesale and partnership?', 'mvweb-core' ),
								'answer' => __( 'To the e-mail on this page: describe the task, and a manager will send the terms and the price list.', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'contact-form',
					'props' => array(
						'view'       => '1',
						'background' => 'surface',
						'title'      => __( 'Write to us', 'mvweb-core' ),
						'text'       => __( 'Leave your phone and question: we will call back and answer.', 'mvweb-core' ),
						'note'       => __( 'We reply within 15 minutes from 9:00 to 21:00. If you wrote at night, we will reply in the morning.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'content',
					'props' => array(
						'view'       => '1',
						'background' => 'plain',
						'title'      => __( 'Company details', 'mvweb-core' ),
						'text'       => __( '<p>LLC “Company name”<br>TIN 0000000000, KPP 000000000<br>OGRN 0000000000000<br>Legal address: 000000, City, Street, 1</p>', 'mvweb-core' ),
					),
				),
			),
		);

		return $presets;
	}
);
