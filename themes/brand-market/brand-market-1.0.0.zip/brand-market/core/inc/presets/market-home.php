<?php
/**
 * Ready-made set of sections: home page of an online store.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter(
	'mvweb_core_section_presets',
	static function ( $presets ) {
		$request = '#request';

		$presets['market-home'] = array(
			'label'       => __( 'Online store, home page', 'mvweb-core' ),
			'description' => __( 'Slider, categories, products, banners, benefits, brands, reviews, video reviews, articles, a call to action and a long text about the shop', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'hero-slider',
					'props' => array(
						'view'       => '3',
						'background' => 'plain',
						'slides'     => array(
							array(
								'kicker'      => __( 'New this season', 'mvweb-core' ),
								'title'       => __( 'Food loved even by the pickiest', 'mvweb-core' ),
								'accent_word' => __( 'the pickiest', 'mvweb-core' ),
								'text'        => __( 'Balanced recipes with meat first, no colourings and no needless chemistry. Fast delivery all over Russia.', 'mvweb-core' ),
								'facts'       => implode(
									"\n",
									array(
										__( 'No colourings', 'mvweb-core' ),
										__( 'For sensitive digestion', 'mvweb-core' ),
										__( 'Delivery in 1–2 days', 'mvweb-core' ),
									)
								),
								'button_text' => __( 'Choose food', 'mvweb-core' ),
								'price'       => '690 ₽',
							),
							array(
								'kicker'      => __( 'Games and walks', 'mvweb-core' ),
								'title'       => __( 'Toys for active walks and fun evenings', 'mvweb-core' ),
								'accent_word' => __( 'active walks', 'mvweb-core' ),
								'text'        => __( 'Ropes, balls and squeakers made of tough materials that survive even the most determined teeth.', 'mvweb-core' ),
								'facts'       => implode(
									"\n",
									array(
										__( 'Tough materials', 'mvweb-core' ),
										__( 'Safe dyes', 'mvweb-core' ),
										__( 'Machine washable', 'mvweb-core' ),
									)
								),
								'button_text' => __( 'Browse toys', 'mvweb-core' ),
								'price'       => '290 ₽',
							),
							array(
								'kicker'      => __( 'Care and comfort', 'mvweb-core' ),
								'title'       => __( 'Care that is a pleasure to cuddle after', 'mvweb-core' ),
								'accent_word' => __( 'a pleasure to cuddle after', 'mvweb-core' ),
								'text'        => __( 'Shampoos, combs and products for ears and paws: a gentle formula chosen together with vets.', 'mvweb-core' ),
								'facts'       => implode(
									"\n",
									array(
										__( 'Hypoallergenic', 'mvweb-core' ),
										__( 'Gentle formula', 'mvweb-core' ),
										__( 'Approved by vets', 'mvweb-core' ),
									)
								),
								'button_text' => __( 'Choose care', 'mvweb-core' ),
								'price'       => '390 ₽',
							),
						),
					),
				),
				array(
					'type'  => 'categories',
					'props' => array(
						'view'       => '1',
						'background' => 'surface',
						'title'      => __( 'Catalogue sections', 'mvweb-core' ),
						'source'     => 'product_cat',
						'count'      => 6,
					),
				),
				array(
					'type'  => 'products',
					'props' => array(
						'view'       => '2',
						'background' => 'plain',
						'title'      => __( 'Bestsellers', 'mvweb-core' ),
						'text'       => __( 'What our customers put in the basket most often', 'mvweb-core' ),
						'source'     => 'recent',
						'count'      => 8,
					),
				),
				array(
					'type'  => 'banner-pair',
					'props' => array(
						'view'       => '4',
						'background' => 'surface',
						'title'      => __( 'Offers of the month', 'mvweb-core' ),
						'banners'    => array(
							array(
								'kicker'      => __( 'Only in October', 'mvweb-core' ),
								'title'       => __( '15% off puppy food', 'mvweb-core' ),
								'text'        => __( 'A complete diet for growth, from two months to a year. The discount covers the whole section.', 'mvweb-core' ),
								'button_text' => __( 'Choose food', 'mvweb-core' ),
								'sticker'     => '−15%',
								'ticker'      => __( 'Only in October · 15% off · Puppy food', 'mvweb-core' ),
							),
							array(
								'kicker'      => __( 'A gift with your order', 'mvweb-core' ),
								'title'       => __( 'A rope toy as a gift from 3 000 ₽', 'mvweb-core' ),
								'text'        => __( 'Add items worth 3 000 ₽ or more to the basket and the rope toy arrives for free.', 'mvweb-core' ),
								'button_text' => __( 'Terms of the offer', 'mvweb-core' ),
								'sticker'     => '+1',
								'ticker'      => __( 'A gift with your order · Rope toy · From 3 000 ₽', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'promo-products',
					'props' => array(
						'view'        => '1',
						'background'  => 'plain',
						'kicker'      => __( 'For the little ones', 'mvweb-core' ),
						'title'       => __( 'Everything for puppies and kittens', 'mvweb-core' ),
						'text'        => __( 'Food, treats and toys for growth and first games. The selection is made together with vets.', 'mvweb-core' ),
						'button_text' => __( 'All products of the section', 'mvweb-core' ),
						'source'      => 'recent',
						'count'       => 8,
					),
				),
				array(
					'type'  => 'benefits',
					'props' => array(
						'view'       => '3',
						'background' => 'accent',
						'title'      => __( 'Why buy from the maker', 'mvweb-core' ),
						'text'       => __( 'We make the food and accessories ourselves, so we answer for every pack.', 'mvweb-core' ),
						'items'      => array(
							array(
								'text' => __( 'A fresh batch: the best-before date on the pack is at least nine months away', 'mvweb-core' ),
							),
							array(
								'text' => __( 'Shipped from the warehouse on the day of the order if it is placed before 15:00', 'mvweb-core' ),
							),
							array(
								'text' => __( 'A free gift with an order from 3 000 ₽: a treat or a toy', 'mvweb-core' ),
							),
							array(
								'text' => __( 'Exchange or return within 30 days, even if the pack is opened', 'mvweb-core' ),
							),
							array(
								'text' => __( 'Advice from a veterinary nutritionist by phone and in messengers', 'mvweb-core' ),
							),
							array(
								'text' => __( '5% off a repeat order of the same item', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'partners',
					'props' => array(
						'view'       => '4',
						'background' => 'plain',
						'title'      => __( 'Our partners', 'mvweb-core' ),
						'text'       => __( 'Our brand\'s goods are sold in partner shops and on marketplaces.', 'mvweb-core' ),
						'logos'      => array(
							array(
								'name' => __( 'Marketplace 1', 'mvweb-core' ),
							),
							array(
								'name' => __( 'Marketplace 2', 'mvweb-core' ),
							),
							array(
								'name' => __( 'Marketplace 3', 'mvweb-core' ),
							),
							array(
								'name' => __( 'Marketplace 4', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'reviews',
					'props' => array(
						'view'       => '1',
						'background' => 'surface',
						'kicker'     => __( 'Customer reviews', 'mvweb-core' ),
						'title'      => __( 'Pet owners trust us', 'mvweb-core' ),
						'text'       => __( 'Real reviews from maps and review sites, with no edits and no moderation.', 'mvweb-core' ),
						'source'     => 'own',
						'ratings'    => array(
							array(
								'title' => __( 'City maps', 'mvweb-core' ),
								'score' => '4,9',
								'note'  => __( '1 240 ratings', 'mvweb-core' ),
							),
							array(
								'title' => __( 'Organisation directory', 'mvweb-core' ),
								'score' => '4,8',
								'note'  => __( '860 ratings', 'mvweb-core' ),
							),
							array(
								'title' => __( 'Map search', 'mvweb-core' ),
								'score' => '4,9',
								'note'  => __( '410 ratings', 'mvweb-core' ),
							),
							array(
								'title' => __( 'Review service', 'mvweb-core' ),
								'score' => '4,7',
								'note'  => __( '320 reviews', 'mvweb-core' ),
							),
						),
						'items'      => array(
							array(
								'title'  => __( 'Anna Sokolova', 'mvweb-core' ),
								'text'   => __( 'We ordered puppy food and a couple of toys. It came the next day, the pack was intact, the best-before date was long. The puppy ate it all in a week and his coat is visibly better. We will order again.', 'mvweb-core' ),
								'source' => __( 'City maps, 12 September', 'mvweb-core' ),
								'stars'  => 'five',
							),
							array(
								'title'  => __( 'Dmitry Orlov', 'mvweb-core' ),
								'text'   => __( 'We had long looked for a bowl for a cat that eats too fast. We took one on the advice of a consultant and the problem went away. The manager answered in the messenger in five minutes.', 'mvweb-core' ),
								'source' => __( 'Organisation directory, 3 September', 'mvweb-core' ),
								'stars'  => 'five',
							),
							array(
								'title'  => __( 'Elena K.', 'mvweb-core' ),
								'text'   => __( 'A good shop, everything is as in the photos. The only thing is that we waited a day longer than promised, but they warned us in advance and added a treat as a gift.', 'mvweb-core' ),
								'source' => __( 'Map search, 28 August', 'mvweb-core' ),
								'stars'  => 'four',
							),
							array(
								'title'  => __( 'Maria Belova', 'mvweb-core' ),
								'text'   => __( 'This is my second order of shampoo and a nail clipper. The quality is stable and the prices are lower than in the pet shops nearby. Special thanks for the samples in the box.', 'mvweb-core' ),
								'source' => __( 'City maps, 19 August', 'mvweb-core' ),
								'stars'  => 'five',
							),
						),
					),
				),
				array(
					'type'  => 'video-reviews',
					'props' => array(
						'view'       => '3',
						'background' => 'plain',
						'source'     => 'records',
						'count'      => 6,
						'title'      => __( 'Video reviews from customers', 'mvweb-core' ),
						'text'       => __( 'Pet owners show how the goods work at home.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'posts',
					'props' => array(
						'view'       => '1',
						'background' => 'surface',
						'title'      => __( 'Useful in the blog', 'mvweb-core' ),
						'text'       => __( 'Tips on choosing food, grooming and toys.', 'mvweb-core' ),
						'count'      => 3,
					),
				),
				array(
					'type'  => 'banner',
					'props' => array(
						'view'         => '2',
						'background'   => 'plain',
						'title'        => __( 'A new collection of beds and houses', 'mvweb-core' ),
						'text'         => __( 'Soft, warm and washable: 24 models for any size of pet.', 'mvweb-core' ),
						'button_text'  => __( 'View the collection', 'mvweb-core' ),
						'sticker_num'  => '24',
						'sticker_text' => __( 'models', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'cta',
					'props' => array(
						'view'        => '1',
						'background'  => 'inverse',
						'title'       => __( 'Can’t find the right food? We will pick it in five minutes', 'mvweb-core' ),
						'text'        => __( 'Tell us about your pet and we will suggest three suitable options based on age, weight and allergies.', 'mvweb-core' ),
						'button_text' => __( 'Get a selection', 'mvweb-core' ),
						'button_url'  => $request,
					),
				),
				array(
					'type'  => 'seo-text',
					'props' => array(
						'view'          => '3',
						'background'    => 'plain',
						'kicker'        => __( 'About the range', 'mvweb-core' ),
						'title'         => __( 'Everything for pets in one shop', 'mvweb-core' ),
						'text'          => implode(
							'',
							array(
								'<p>' . esc_html__( 'We have gathered everything dogs and cats need every day in one place: food, treats, toys, beds, walking gear and grooming products. There is no need to drive between shops and compare labels: the range is chosen by us, and a consultant can advise on every item.', 'mvweb-core' ) . '</p>',
								'<h2>' . esc_html__( 'Food for dogs and cats', 'mvweb-core' ) . '</h2>',
								'<p>' . esc_html__( 'The diet depends on the age, the size and the health of a pet. Puppies and kittens need food with more energy and a balanced mineral content, adult animals need a diet that keeps them in shape, and older pets need food that is gentler on joints and digestion. A separate line is made for pets with sensitive digestion or a tendency to allergies.', 'mvweb-core' ) . '</p>',
								'<h3>' . esc_html__( 'What to look for in the ingredients', 'mvweb-core' ) . '</h3>',
								'<ul><li>' . esc_html__( 'Meat or fish comes first, not unspecified by-products.', 'mvweb-core' ) . '</li><li>' . esc_html__( 'There are no artificial colourings or flavour enhancers.', 'mvweb-core' ) . '</li><li>' . esc_html__( 'The age, the breed size and the purpose of the food are stated.', 'mvweb-core' ) . '</li><li>' . esc_html__( 'The pack is sealed and the shelf life is long enough for the pet to finish it.', 'mvweb-core' ) . '</li></ul>',
								/* translators: %s: link to the request form. */
								'<p>' . sprintf( esc_html__( 'Move a pet to new food gradually, over a week, and watch how it feels. %s and a consultant will help to choose a diet.', 'mvweb-core' ), '<a href="' . esc_url( $request ) . '">' . esc_html__( 'Ask us a question', 'mvweb-core' ) . '</a>' ) . '</p>',
								'<h2>' . esc_html__( 'Toys and active walks', 'mvweb-core' ) . '</h2>',
								'<p>' . esc_html__( 'A toy is not just fun: it relieves tension, keeps a pet busy while you are at work and teaches it to play together with its owner. For dogs we choose ropes, balls and chew toys made of tough materials, for cats teasers, bell balls and scratching posts. The size of a toy should match the size of the mouth, and the material should withstand the strength of the teeth.', 'mvweb-core' ) . '</p>',
								'<h2>' . esc_html__( 'Care and comfort at home', 'mvweb-core' ) . '</h2>',
								'<p>' . esc_html__( 'Shampoos, combs and products for ears and paws are chosen for the type of coat and the sensitivity of the skin. A bed, a house or a carrier should be a little bigger than the animal so that it can stretch out, and the cover should come off and go in the wash.', 'mvweb-core' ) . '</p>',
								/* translators: %s: link to the request form. */
								'<p>' . sprintf( esc_html__( 'Did not find the right item or not sure about the choice? %s and a consultant will pick the goods for your pet. An order can be placed on the site and then collected from the shop or delivered by a courier.', 'mvweb-core' ), '<a href="' . esc_url( $request ) . '">' . esc_html__( 'Message us', 'mvweb-core' ) . '</a>' ) . '</p>',
							)
						),
						'spoiler'       => 'height',
						'spoiler_lines' => 8,
					),
				),
			),
		);

		return $presets;
	}
);
