<?php
/**
 * Services engine.
 *
 * A service behaves like a catalogue item with a different set of fields: the
 * listing, the sections and the page are built by the same helpers, and only
 * what a card carries differs. Nothing here asks WooCommerce anything — the
 * plugin sells goods, and a service is the theme's own from either source.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_service_defaults' ) ) {
	/**
	 * Defaults of the services settings.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_service_defaults() {
		return array(
			'mvweb_service_label'       => '',
			'mvweb_work_label'          => '',
			'mvweb_work_slug'           => 'works',
			'mvweb_works_per_page'      => 12,
			'mvweb_service_slug'        => 'services',
			'mvweb_services_per_page'   => 12,
			'mvweb_service_card_shape'  => 'landscape',
			'mvweb_service_list_mode'   => 'flat',
			'mvweb_service_tree_desc'   => true,
			'mvweb_service_list_image'  => 0,
			'mvweb_service_list_text'   => '',
			'mvweb_service_price_from'  => __( 'from', 'mvweb-core' ),
			'mvweb_service_price_empty' => '',
			'mvweb_service_form_title'  => __( 'Get a consultation', 'mvweb-core' ),
			'mvweb_service_form'        => '',
			'mvweb_service_form_note'   => '',
		);
	}
}

if ( ! function_exists( 'mvweb_core_service_label' ) ) {
	/**
	 * What the section is called in the admin menu.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_service_label() {
		$label = trim( (string) mvweb_core_option( 'mvweb_service_label' ) );

		return '' === $label ? __( 'Services', 'mvweb-core' ) : $label;
	}
}

if ( ! function_exists( 'mvweb_core_service_archive_url' ) ) {
	/**
	 * Address of the services listing.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_service_archive_url() {
		$archive = get_post_type_archive_link( 'mv_service' );

		return $archive ? $archive : home_url( '/' );
	}
}

if ( ! function_exists( 'mvweb_core_service_title' ) ) {
	/**
	 * Heading of the listing being shown.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_service_title() {
		if ( is_tax( 'mv_service_cat' ) ) {
			return wp_strip_all_tags( single_term_title( '', false ) );
		}

		return wp_strip_all_tags( post_type_archive_title( '', false ) );
	}
}

if ( ! function_exists( 'mvweb_core_service_price_placeholder' ) ) {
	/**
	 * What a service with no price shows in its place.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty prints nothing.
	 */
	function mvweb_core_service_price_placeholder() {
		return trim( (string) mvweb_core_option( 'mvweb_service_price_empty' ) );
	}
}

if ( ! function_exists( 'mvweb_core_service_price_from' ) ) {
	/**
	 * The word standing before a price that is a starting one.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_service_price_from() {
		return trim( (string) mvweb_core_option( 'mvweb_service_price_from' ) );
	}
}

if ( ! function_exists( 'mvweb_core_service_advantage' ) ) {
	/**
	 * The single line a service card carries beside its price.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Service id.
	 *
	 * @return string
	 */
	function mvweb_core_service_advantage( $id ) {
		return trim( (string) get_post_meta( $id, '_mvweb_advantage', true ) );
	}
}

if ( ! function_exists( 'mvweb_core_service_query' ) ) {
	/**
	 * How many services a listing page holds, and in what order.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Query being prepared.
	 *
	 * @return void
	 */
	function mvweb_core_service_query( $query ) {
		if ( is_admin() || ! $query->is_main_query() ) {
			return;
		}

		if ( ! $query->is_post_type_archive( 'mv_service' ) && ! $query->is_tax( 'mv_service_cat' ) ) {
			return;
		}

		mvweb_core_listing_query( $query, 'mvweb_services_per_page' );
	}
}
add_action( 'pre_get_posts', 'mvweb_core_service_query' );

if ( ! function_exists( 'mvweb_core_service_price' ) ) {
	/**
	 * The price line of a service, ready to print.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Service id.
	 *
	 * @return string Markup, empty when there is nothing to print.
	 */
	function mvweb_core_service_price( $id ) {
		$price = mvweb_core_item_price_html( $id );

		if ( '' === $price ) {
			return '';
		}

		$from = mvweb_core_service_price_from();

		return '' !== $from ? esc_html( $from ) . ' ' . $price : $price;
	}
}

if ( ! function_exists( 'mvweb_core_service_list_mode' ) ) {
	/**
	 * How the services page and a section page lay out what they hold.
	 *
	 * @since 0.1.0
	 *
	 * @return string One of flat, level, tree.
	 */
	function mvweb_core_service_list_mode() {
		$mode = (string) mvweb_core_option( 'mvweb_service_list_mode' );

		return in_array( $mode, array( 'flat', 'level', 'tree' ), true ) ? $mode : 'flat';
	}
}

if ( ! function_exists( 'mvweb_core_service_ids' ) ) {
	/**
	 * Published services of one level, in the order the listing uses.
	 *
	 * @since 0.1.0
	 *
	 * @param int  $term_id Section id; 0 means the services outside any section.
	 * @param bool $deep    Whether services of the subsections count too.
	 *
	 * @return int[]
	 */
	function mvweb_core_service_ids( $term_id, $deep = false ) {
		static $cache = array();

		$key = $term_id . ( $deep ? ':deep' : '' );

		if ( isset( $cache[ $key ] ) ) {
			return $cache[ $key ];
		}

		$tax = 0 === $term_id
			? array(
				'taxonomy' => 'mv_service_cat',
				'operator' => 'NOT EXISTS',
			)
			: array(
				'taxonomy'         => 'mv_service_cat',
				'terms'            => $term_id,
				'include_children' => $deep,
			);

		$cache[ $key ] = array_map(
			'absint',
			get_posts(
				array(
					'post_type'      => 'mv_service',
					'post_status'    => 'publish',
					'posts_per_page' => -1,
					'fields'         => 'ids',
					'no_found_rows'  => true,
					'orderby'        => array(
						'menu_order' => 'ASC',
						'date'       => 'DESC',
					),
					'tax_query'      => array( $tax ), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- One level of one taxonomy, printed whole.
				)
			)
		);

		return $cache[ $key ];
	}
}

if ( ! function_exists( 'mvweb_core_service_child_terms' ) ) {
	/**
	 * Subsections of a section that hold at least one service, however deep.
	 *
	 * @since 0.1.0
	 *
	 * @param int $parent_id Section id; 0 for the top level.
	 *
	 * @return WP_Term[]
	 */
	function mvweb_core_service_child_terms( $parent_id ) {
		$terms = get_terms(
			array(
				'taxonomy'   => 'mv_service_cat',
				'parent'     => $parent_id,
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) ) {
			return array();
		}

		return array_values(
			array_filter(
				$terms,
				static function ( $term ) {
					return array() !== mvweb_core_service_ids( $term->term_id, true );
				}
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_service_level' ) ) {
	/**
	 * What the listing prints instead of the grid, when the setting asks so.
	 *
	 * @since 0.1.0
	 *
	 * @return array{root:int,terms:WP_Term[],services:int[]}|null Null keeps
	 *                                                              the grid.
	 */
	function mvweb_core_service_level() {
		if ( 'flat' === mvweb_core_service_list_mode() ) {
			return null;
		}

		if ( is_post_type_archive( 'mv_service' ) ) {
			$root = 0;
		} elseif ( is_tax( 'mv_service_cat' ) ) {
			$root = (int) get_queried_object_id();
		} else {
			return null;
		}

		$terms = mvweb_core_service_child_terms( $root );

		if ( empty( $terms ) ) {
			return null;
		}

		return array(
			'root'     => $root,
			'terms'    => $terms,
			'services' => mvweb_core_service_ids( $root ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_service_level_redirect' ) ) {
	/**
	 * Send page two and on of a listing that is printed whole to page one.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_service_level_redirect() {
		if ( ! is_paged() ) {
			return;
		}

		$level = mvweb_core_service_level();

		if ( null === $level ) {
			return;
		}

		$url = 0 === $level['root'] ? mvweb_core_service_archive_url() : get_term_link( $level['root'], 'mv_service_cat' );

		if ( is_string( $url ) && '' !== $url ) {
			wp_safe_redirect( $url, 301 );
			exit;
		}
	}
}
add_action( 'template_redirect', 'mvweb_core_service_level_redirect' );

if ( ! function_exists( 'mvweb_core_nested_types' ) ) {
	/**
	 * The types whose records live under their term: type => taxonomy.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_nested_types() {
		return array(
			'mv_service' => 'mv_service_cat',
			'mv_work'    => 'mv_work_type',
		);
	}
}

if ( ! function_exists( 'mvweb_core_nested_path' ) ) {
	/**
	 * Slugs of a term and its parents, "parent/child/".
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Term.
	 * @return string
	 */
	function mvweb_core_nested_path( $term ) {
		$path = get_term_parents_list(
			$term->term_id,
			$term->taxonomy,
			array(
				'format'    => 'slug',
				'separator' => '/',
				'link'      => false,
			)
		);

		return is_string( $path ) ? $path : '';
	}
}

if ( ! function_exists( 'mvweb_core_nested_link' ) ) {
	/**
	 * Put the term of a record into its address.
	 *
	 * @since 0.1.0
	 *
	 * @param string  $link Permalink.
	 * @param WP_Post $post Post.
	 * @return string
	 */
	function mvweb_core_nested_link( $link, $post ) {
		$types = mvweb_core_nested_types();

		if ( ! isset( $types[ $post->post_type ] ) ) {
			return $link;
		}

		$taxonomy = $types[ $post->post_type ];
		$terms    = get_the_terms( $post, $taxonomy );
		$path     = '';

		if ( is_array( $terms ) && ! empty( $terms ) ) {
			$primary = (int) get_post_meta( $post->ID, '_yoast_wpseo_primary_' . $taxonomy, true );
			$term    = $terms[0];

			foreach ( $terms as $candidate ) {
				if ( $candidate->term_id === $primary ) {
					$term = $candidate;
				}
			}

			$path = mvweb_core_nested_path( $term );
		}

		return str_replace( '%' . $taxonomy . '%/', $path, $link );
	}
}
add_filter( 'post_type_link', 'mvweb_core_nested_link', 10, 2 );

if ( ! function_exists( 'mvweb_core_nested_request' ) ) {
	/**
	 * Hand to the record an address the term rules took but no term owns.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $vars Query vars.
	 * @return array<string,mixed>
	 */
	function mvweb_core_nested_request( $vars ) {
		foreach ( mvweb_core_nested_types() as $type => $taxonomy ) {
			if ( empty( $vars[ $taxonomy ] ) || ! is_string( $vars[ $taxonomy ] ) ) {
				continue;
			}

			$path = trim( $vars[ $taxonomy ], '/' );
			$slug = wp_basename( $path );
			$term = get_term_by( 'slug', $slug, $taxonomy );

			if ( $term instanceof WP_Term && mvweb_core_nested_path( $term ) === $path . '/' ) {
				continue;
			}

			if ( ! get_page_by_path( $slug, OBJECT, $type ) ) {
				continue;
			}

			unset( $vars[ $taxonomy ], $vars['paged'] );

			$vars['post_type'] = $type;
			$vars[ $type ]     = $slug;
			$vars['name']      = $slug;
		}

		return $vars;
	}
}
add_filter( 'request', 'mvweb_core_nested_request' );

if ( ! function_exists( 'mvweb_core_nested_canonical' ) ) {
	/**
	 * Send a record reached by a wrong or old term path to its address.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_nested_canonical() {
		if ( ! is_singular( array_keys( mvweb_core_nested_types() ) ) || is_preview() || is_embed() || is_feed() ) {
			return;
		}

		$link = (string) get_permalink();
		$want = untrailingslashit( rawurldecode( (string) wp_parse_url( $link, PHP_URL_PATH ) ) );
		$have = untrailingslashit( rawurldecode( (string) wp_parse_url( add_query_arg( array() ), PHP_URL_PATH ) ) );

		if ( '' !== $link && $want !== $have ) {
			wp_safe_redirect( $link, 301 );
			exit;
		}
	}
}
add_action( 'template_redirect', 'mvweb_core_nested_canonical' );
