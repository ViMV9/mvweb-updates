<?php
/**
 * Icon system.
 *
 * One monochrome stroke sprite (Tabler Icons, MIT) covers the whole theme.
 * It is inlined right after <body> opens, before the header markup that uses
 * it — an icon referenced by <use> before its <symbol> exists renders empty in
 * Safari. The 7.1 SVG Icon API does not produce sprites, so <use> stays.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_icon_choices' ) ) {
	/**
	 * Both sprites as a list to pick from: icon name => readable label.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_icon_choices() {
		return array(
			''                       => __( '— No icon —', 'mvweb-core' ),
			'tools'                  => __( 'Tools', 'mvweb-core' ),
			'hammer'                 => __( 'Hammer', 'mvweb-core' ),
			'shovel'                 => __( 'Shovel', 'mvweb-core' ),
			'axe'                    => __( 'Axe', 'mvweb-core' ),
			'ruler-measure'          => __( 'Tape measure', 'mvweb-core' ),
			'ruler-2'                => __( 'Ruler', 'mvweb-core' ),
			'pencil'                 => __( 'Pencil', 'mvweb-core' ),
			'palette'                => __( 'Palette', 'mvweb-core' ),
			'brush'                  => __( 'Brush', 'mvweb-core' ),
			'wall'                   => __( 'Brick wall', 'mvweb-core' ),
			'settings'               => __( 'Gear', 'mvweb-core' ),
			'adjustments-horizontal' => __( 'Sliders', 'mvweb-core' ),
			'checklist'              => __( 'Checklist', 'mvweb-core' ),
			'clipboard-check'        => __( 'Clipboard with a tick', 'mvweb-core' ),
			'flame'                  => __( 'Flame', 'mvweb-core' ),
			'campfire'               => __( 'Campfire', 'mvweb-core' ),
			'grill'                  => __( 'Grill', 'mvweb-core' ),
			'wood'                   => __( 'Firewood', 'mvweb-core' ),
			'trees'                  => __( 'Trees', 'mvweb-core' ),
			'leaf'                   => __( 'Leaf', 'mvweb-core' ),
			'temperature'            => __( 'Thermometer', 'mvweb-core' ),
			'temperature-sun'        => __( 'Heat', 'mvweb-core' ),
			'snowflake'              => __( 'Snowflake', 'mvweb-core' ),
			'wind'                   => __( 'Wind', 'mvweb-core' ),
			'droplet'                => __( 'Drop', 'mvweb-core' ),
			'bolt'                   => __( 'Lightning', 'mvweb-core' ),
			'sun'                    => __( 'Sun', 'mvweb-core' ),
			'moon'                   => __( 'Moon', 'mvweb-core' ),
			'home'                   => __( 'House', 'mvweb-core' ),
			'home-check'             => __( 'House with a tick', 'mvweb-core' ),
			'home-heart'             => __( 'House with a heart', 'mvweb-core' ),
			'building-cottage'       => __( 'Cottage', 'mvweb-core' ),
			'building-factory-2'     => __( 'Factory', 'mvweb-core' ),
			'building-warehouse'     => __( 'Warehouse', 'mvweb-core' ),
			'door'                   => __( 'Door', 'mvweb-core' ),
			'window'                 => __( 'Window', 'mvweb-core' ),
			'fence'                  => __( 'Fence', 'mvweb-core' ),
			'armchair'               => __( 'Armchair', 'mvweb-core' ),
			'sofa'                   => __( 'Sofa', 'mvweb-core' ),
			'lamp'                   => __( 'Lamp', 'mvweb-core' ),
			'shield-check'           => __( 'Shield with a tick', 'mvweb-core' ),
			'shield'                 => __( 'Shield', 'mvweb-core' ),
			'certificate'            => __( 'Certificate', 'mvweb-core' ),
			'file-certificate'       => __( 'Document with a seal', 'mvweb-core' ),
			'award'                  => __( 'Award', 'mvweb-core' ),
			'medal'                  => __( 'Medal', 'mvweb-core' ),
			'trophy'                 => __( 'Cup', 'mvweb-core' ),
			'crown'                  => __( 'Crown', 'mvweb-core' ),
			'diamond'                => __( 'Diamond', 'mvweb-core' ),
			'star'                   => __( 'Star', 'mvweb-core' ),
			'sparkles'               => __( 'Sparkles', 'mvweb-core' ),
			'thumb-up'               => __( 'Thumbs up', 'mvweb-core' ),
			'rosette-discount-check' => __( 'Quality mark', 'mvweb-core' ),
			'check'                  => __( 'Tick', 'mvweb-core' ),
			'heart'                  => __( 'Heart', 'mvweb-core' ),
			'heart-handshake'        => __( 'Handshake', 'mvweb-core' ),
			'target'                 => __( 'Target', 'mvweb-core' ),
			'rocket'                 => __( 'Rocket', 'mvweb-core' ),
			'key'                    => __( 'Key', 'mvweb-core' ),
			'lock'                   => __( 'Padlock', 'mvweb-core' ),
			'clock'                  => __( 'Clock', 'mvweb-core' ),
			'clock-24'               => __( 'Round the clock', 'mvweb-core' ),
			'stopwatch'              => __( 'Stopwatch', 'mvweb-core' ),
			'hourglass'              => __( 'Hourglass', 'mvweb-core' ),
			'history'                => __( 'Clock with an arrow back', 'mvweb-core' ),
			'calendar-event'         => __( 'Calendar', 'mvweb-core' ),
			'calendar-check'         => __( 'Calendar with a tick', 'mvweb-core' ),
			'currency-ruble'         => __( 'Rouble sign', 'mvweb-core' ),
			'currency-euro'          => __( 'Euro sign', 'mvweb-core' ),
			'currency-dollar'        => __( 'Dollar sign', 'mvweb-core' ),
			'coin'                   => __( 'Coin', 'mvweb-core' ),
			'wallet'                 => __( 'Wallet', 'mvweb-core' ),
			'credit-card'            => __( 'Bank card', 'mvweb-core' ),
			'receipt'                => __( 'Receipt', 'mvweb-core' ),
			'discount'               => __( 'Per cent', 'mvweb-core' ),
			'gift'                   => __( 'Gift', 'mvweb-core' ),
			'cart'                   => __( 'Cart', 'mvweb-core' ),
			'truck'                  => __( 'Lorry', 'mvweb-core' ),
			'truck-delivery'         => __( 'Delivery lorry', 'mvweb-core' ),
			'package'                => __( 'Parcel', 'mvweb-core' ),
			'box'                    => __( 'Box', 'mvweb-core' ),
			'cube'                   => __( 'Cube', 'mvweb-core' ),
			'route'                  => __( 'Route', 'mvweb-core' ),
			'map'                    => __( 'Map', 'mvweb-core' ),
			'map-pin'                => __( 'Map pin', 'mvweb-core' ),
			'users'                  => __( 'People', 'mvweb-core' ),
			'users-group'            => __( 'Team', 'mvweb-core' ),
			'user-check'             => __( 'Person with a tick', 'mvweb-core' ),
			'headset'                => __( 'Headset', 'mvweb-core' ),
			'phone'                  => __( 'Phone', 'mvweb-core' ),
			'phone-call'             => __( 'Phone call', 'mvweb-core' ),
			'message-circle'         => __( 'Speech bubble', 'mvweb-core' ),
			'messages'               => __( 'Chat', 'mvweb-core' ),
			'mail'                   => __( 'Envelope', 'mvweb-core' ),
			'telegram'               => __( 'Telegram', 'mvweb-core' ),
			'whatsapp'               => __( 'WhatsApp', 'mvweb-core' ),
			'vk'                     => __( 'VK', 'mvweb-core' ),
			'ok'                     => __( 'Odnoklassniki', 'mvweb-core' ),
			'file-text'              => __( 'Document', 'mvweb-core' ),
			'photo'                  => __( 'Photo', 'mvweb-core' ),
			'eye'                    => __( 'Eye', 'mvweb-core' ),
			'search'                 => __( 'Magnifier', 'mvweb-core' ),
			'filter'                 => __( 'Filter', 'mvweb-core' ),
			'refresh'                => __( 'Two arrows in a circle', 'mvweb-core' ),
			'user'                   => __( 'Person', 'mvweb-core' ),
			'layout-grid'            => __( 'Grid of tiles', 'mvweb-core' ),
			'category-2'             => __( 'Categories', 'mvweb-core' ),
			'play'                   => __( 'Play', 'mvweb-core' ),
			'arrow-right'            => __( 'Arrow right', 'mvweb-core' ),
			'arrow-up'               => __( 'Arrow up', 'mvweb-core' ),
			'chevron-right'          => __( 'Chevron right', 'mvweb-core' ),
			'chevron-left'           => __( 'Chevron left', 'mvweb-core' ),
			'chevron-down'           => __( 'Chevron down', 'mvweb-core' ),
			'menu'                   => __( 'Menu', 'mvweb-core' ),
			'close'                  => __( 'Cross', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_social_icon' ) ) {
	/**
	 * Sprite icon name for a social network id.
	 *
	 * @since 0.1.0
	 *
	 * @param string $id Network id, e.g. telegram.
	 *
	 * @return string Icon name without the "lc-" prefix.
	 */
	function mvweb_core_social_icon( $id ) {
		$known = array(
			'telegram'      => 'telegram',
			'whatsapp'      => 'whatsapp',
			'viber'         => 'viber',
			'max'           => 'max',
			'vk'            => 'vk',
			'odnoklassniki' => 'ok',
			'rutube'        => 'rutube',
			'dzen'          => 'dzen',
			'facebook'      => 'facebook',
			'instagram'     => 'instagram',
			'x'             => 'x',
			'linkedin'      => 'linkedin',
			'tiktok'        => 'tiktok',
			'pinterest'     => 'pinterest',
			'youtube'       => 'youtube',
		);

		return isset( $known[ $id ] ) ? $known[ $id ] : 'arrow-right';
	}
}

if ( ! function_exists( 'mvweb_core_print_icon_picker_sprites' ) ) {
	/**
	 * Both sprites, for the admin screens that let the owner pick an icon.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_print_icon_picker_sprites() {
		foreach ( (array) glob( get_template_directory() . '/assets/icons/*.svg' ) as $path ) {
			if ( is_readable( $path ) ) {
				echo file_get_contents( $path ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped, WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Trusted local SVG sprite shipped with the theme.
			}
		}
	}
}
