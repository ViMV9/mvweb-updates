<?php
/**
 * Blog index.
 *
 * The heading takes the title and the excerpt of the page set as the page of
 * entries. The strip of categories, the large first entry and the blocks under
 * the list are set in the Customizer.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_posts_page = (int) get_option( 'page_for_posts' );
$mvweb_title      = mvweb_core_alt_h1();

if ( '' === $mvweb_title ) {
	$mvweb_title = $mvweb_posts_page > 0
		? get_the_title( $mvweb_posts_page )
		: __( 'Blog', 'brand-market' );
}

get_header();

mvweb_theme_column_open( 'blog' );

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'title' => $mvweb_title,
		'lead'  => is_paged() ? '' : mvweb_core_blog_lead(),
	)
);

get_template_part(
	'template-parts/post-list',
	null,
	array(
		'chips'             => 'topics',
		'feature'           => ! is_paged() && (bool) mvweb_core_blog_option( 'mvweb_blog_feature' ),
		'empty_title'       => __( 'Nothing here yet', 'brand-market' ),
		'empty_text'        => __( 'The first entry will appear as soon as it is published.', 'brand-market' ),
		'empty_button_url'  => home_url( '/' ),
		'empty_button_text' => __( 'To the homepage', 'brand-market' ),
	)
);

mvweb_theme_column_close( 'blog' );

mvweb_core_render_context_sections();

get_footer();
