<?php
/**
 * Services section.
 *
 * A post type archive template is not consulted for a taxonomy, so the listing
 * is asked for here as well rather than left to fall through to archive.php.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

get_template_part( 'template-parts/service/listing' );

get_footer();
