<?php
/**
 * The order received page: what was ordered, where it goes, what comes next.
 *
 * A paid or accepted order gets the acknowledgement, a failed one gets the
 * way to pay again. The hooks other plugins print their own blocks on keep
 * firing.
 *
 * Arguments: order (WC_Order or false).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

defined( 'ABSPATH' ) || exit;

$mvweb_failed = $order && $order->has_status( 'failed' );
?>
<div class="woocommerce-order">
	<?php
	if ( $order ) {
		do_action( 'woocommerce_before_thankyou', $order->get_id() );
	}

	if ( $mvweb_failed ) {
		mvweb_theme_status_hero(
			array(
				'state' => 'fail',
				'title' => __( 'Payment failed', 'brand-market' ),
				'lead'  => mvweb_theme_pay_fail_lead( $order ),
			)
		);
		?>
		<section class="mvweb-t-section mvweb-t-section--flush-top">
			<div class="mvweb-t-container mvweb-t-thanks__fail">
				<?php
				mvweb_core_render_layout(
					'pay-fail',
					array(
						'order'   => $order,
						'context' => 'received',
					)
				);
				?>
			</div>
		</section>
		<?php
	} else {
		mvweb_theme_status_hero(
			array(
				'state' => 'ok',
				'title' => __( 'Order received', 'brand-market' ),
				'lead'  => (string) mvweb_core_cart_option( 'mvweb_thanks_lead' ),
			)
		);
		?>
		<section class="mvweb-t-section mvweb-t-section--flush-top">
			<div class="mvweb-t-container mvweb-t-order">
				<div class="mvweb-t-order__main">
					<?php if ( $order ) : ?>
						<dl class="mvweb-t-overview">
							<div><dt><?php esc_html_e( 'Order number', 'brand-market' ); ?></dt><dd>
								<?php
								/* translators: %s: number of the order. */
								echo esc_html( sprintf( __( 'No. %s', 'brand-market' ), $order->get_order_number() ) );
								?>
							</dd></div>
							<div><dt><?php esc_html_e( 'Date', 'brand-market' ); ?></dt><dd><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></dd></div>
							<div><dt><?php esc_html_e( 'Total', 'brand-market' ); ?></dt><dd><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></dd></div>
							<?php if ( '' !== mvweb_theme_order_payment_line( $order ) ) : ?>
								<div><dt><?php esc_html_e( 'Payment', 'brand-market' ); ?></dt><dd><?php echo esc_html( mvweb_theme_order_payment_line( $order ) ); ?></dd></div>
							<?php endif; ?>
						</dl>
						<?php mvweb_core_render_layout( 'thanks.page', array( 'order' => $order ) ); ?>
					<?php else : ?>
						<?php mvweb_core_render_layout( 'thanks.page', array( 'order' => false ) ); ?>
					<?php endif; ?>
				</div>
				<?php if ( $order ) : ?>
					<aside class="mvweb-t-summary mvweb-t-order__aside" aria-label="<?php esc_attr_e( 'Order items', 'brand-market' ); ?>">
						<div class="mvweb-t-summary__title mvweb-t-h2"><?php esc_html_e( 'Order items', 'brand-market' ); ?></div>
						<?php get_template_part( 'template-parts/order/summary', null, array( 'order' => $order ) ); ?>
					</aside>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}

	if ( $order ) {
		ob_start();
		do_action( 'woocommerce_thankyou', $order->get_id() );
		$mvweb_hooked = trim( (string) ob_get_clean() );

		if ( '' !== trim( wp_strip_all_tags( $mvweb_hooked ) ) ) {
			echo '<section class="mvweb-t-section mvweb-t-section--tight"><div class="mvweb-t-container mvweb-t-prose">' . $mvweb_hooked . '</div></section>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Blocks that other plugins print on the hook of WooCommerce.
		} else {
			echo $mvweb_hooked; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Scripts that other plugins print on the hook of WooCommerce.
		}
	}
	?>
</div>
