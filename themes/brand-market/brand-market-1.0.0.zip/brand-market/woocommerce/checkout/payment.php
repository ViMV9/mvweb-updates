<?php
/**
 * The payment methods of the checkout.
 *
 * Only the choice stands here: the terms and the button are in the summary,
 * so this element can be replaced alone when the methods change.
 *
 * Arguments: checkout, available_gateways, order_button_text.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! wp_doing_ajax() ) {
	do_action( 'woocommerce_review_order_before_payment' );
}
?>
<div id="payment" class="woocommerce-checkout-payment">
	<?php if ( WC()->cart && WC()->cart->needs_payment() ) : ?>
		<ul class="mvweb-t-step__choices wc_payment_methods payment_methods methods" aria-label="<?php esc_attr_e( 'Payment methods', 'brand-market' ); ?>">
			<?php
			if ( ! empty( $available_gateways ) ) {
				foreach ( $available_gateways as $mvweb_gateway ) {
					wc_get_template( 'checkout/payment-method.php', array( 'gateway' => $mvweb_gateway ) );
				}
			} else {
				echo '<li class="mvweb-t-step__note">';
				echo esc_html( apply_filters( 'woocommerce_no_available_payment_methods_message', WC()->customer->get_billing_country() ? __( 'Sorry, there are no payment methods for your address. Write to us and we will find a way.', 'brand-market' ) : __( 'Fill in your details above to see the payment methods.', 'brand-market' ) ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
				echo '</li>';
			}
			?>
		</ul>
	<?php else : ?>
		<p class="mvweb-t-step__note"><?php esc_html_e( 'Nothing to pay for this order.', 'brand-market' ); ?></p>
	<?php endif; ?>
</div>
<?php
if ( ! wp_doing_ajax() ) {
	do_action( 'woocommerce_review_order_after_payment' );
}
