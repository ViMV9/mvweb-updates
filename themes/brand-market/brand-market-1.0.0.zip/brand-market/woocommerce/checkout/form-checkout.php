<?php
/**
 * The checkout: four steps in the column, the order review and the button in the summary.
 *
 * The steps are fixed by their meaning (contacts, delivery, payment, note);
 * only the blocks of the page around them are a composition. The form keeps
 * the classes and ids WooCommerce's checkout script looks for.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

defined( 'ABSPATH' ) || exit;

if ( WC()->cart->is_empty() ) {
	wc_get_template( 'cart/cart-empty.php' );

	return;
}

$mvweb_number = 0;
$mvweb_step   = static function ( $slug ) use ( &$mvweb_number ) {
	$mvweb_args = array( 'number' => ++$mvweb_number );

	get_template_part( 'template-parts/checkout/' . $slug, null, $mvweb_args );
};
?>
<section class="mvweb-t-section mvweb-t-section--flush-top">
	<div class="mvweb-t-container">
		<div class="mvweb-t-wc-notices"><?php do_action( 'woocommerce_before_checkout_form', $checkout ); ?></div>
		<?php if ( ! $checkout->is_registration_enabled() && $checkout->is_registration_required() && ! is_user_logged_in() ) : ?>
			<p class="mvweb-t-order__req"><?php echo esc_html( apply_filters( 'woocommerce_checkout_must_be_logged_in_message', __( 'You must be logged in to checkout.', 'woocommerce' ) ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment, WordPress.WP.I18n.TextDomainMismatch -- Hook and message of WooCommerce. ?></p>
		<?php else : ?>
			<form name="checkout" method="post" class="checkout woocommerce-checkout mvweb-t-order mvweb-t-checkout" action="<?php echo esc_url( wc_get_checkout_url() ); ?>" enctype="multipart/form-data" aria-label="<?php esc_attr_e( 'Checkout', 'brand-market' ); ?>">
				<div class="mvweb-t-order__main" id="customer_details">
					<p class="mvweb-t-order__req"><span class="mvweb-t-required" aria-hidden="true">*</span> <?php esc_html_e( 'Required fields', 'brand-market' ); ?></p>
					<?php
					if ( $checkout->get_checkout_fields() ) {
						do_action( 'woocommerce_checkout_before_customer_details' );

						$mvweb_step( 'contacts' );
						$mvweb_step( 'delivery' );
					}

					$mvweb_step( 'payment' );

					if ( $checkout->get_checkout_fields() ) {
						$mvweb_step( 'comment' );
						do_action( 'woocommerce_checkout_after_customer_details' );
					}
					?>
				</div>

				<?php do_action( 'woocommerce_checkout_before_order_review_heading' ); ?>
				<aside class="mvweb-t-summary mvweb-t-order__aside" id="order_review" aria-label="<?php esc_attr_e( 'Your order', 'brand-market' ); ?>">
					<div class="mvweb-t-summary__title mvweb-t-h2"><?php esc_html_e( 'Your order', 'brand-market' ); ?></div>
					<?php do_action( 'woocommerce_checkout_before_order_review' ); ?>
					<?php do_action( 'woocommerce_checkout_order_review' ); ?>
					<?php get_template_part( 'template-parts/checkout/place-order' ); ?>
					<a class="mvweb-t-summary__edit" href="<?php echo esc_url( wc_get_cart_url() ); ?>">
						<?php echo mvweb_theme_icon( 'arrow-left', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
						<?php esc_html_e( 'Edit the cart', 'brand-market' ); ?>
					</a>
					<?php do_action( 'woocommerce_checkout_after_order_review' ); ?>
				</aside>
			</form>
		<?php endif; ?>
		<?php do_action( 'woocommerce_after_checkout_form', $checkout ); ?>
	</div>
</section>
