<?php
/**
 * The review of the order at the checkout: the goods with their sums and the rows of the total.
 *
 * WooCommerce replaces this element after every change of the address or of
 * the delivery method, so it is one element with the class it looks for.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="woocommerce-checkout-review-order-table">
	<ul class="mvweb-t-sitems">
		<?php
		do_action( 'woocommerce_review_order_before_cart_contents' );

		foreach ( WC()->cart->get_cart() as $mvweb_key => $mvweb_item ) {
			$mvweb_product = apply_filters( 'woocommerce_cart_item_product', $mvweb_item['data'], $mvweb_item, $mvweb_key );

			if ( ! $mvweb_product instanceof WC_Product || ! $mvweb_product->exists() || $mvweb_item['quantity'] <= 0 || ! apply_filters( 'woocommerce_checkout_cart_item_visible', true, $mvweb_item, $mvweb_key ) ) {
				continue;
			}
			?>
			<li class="mvweb-t-sitem <?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $mvweb_item, $mvweb_key ) ); ?>">
				<span class="mvweb-t-sitem__media">
					<?php echo $mvweb_product->get_image( 'mvweb_card', array( 'loading' => 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WooCommerce image markup. ?>
					<span class="mvweb-t-sitem__qty"><?php echo esc_html( number_format_i18n( (float) $mvweb_item['quantity'] ) ); ?></span>
				</span>
				<span class="mvweb-t-sitem__name">
					<?php echo wp_kses_post( apply_filters( 'woocommerce_cart_item_name', $mvweb_product->get_name(), $mvweb_item, $mvweb_key ) ); ?>
					<?php echo wc_get_formatted_cart_item_data( $mvweb_item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by WooCommerce. ?>
				</span>
				<span class="mvweb-t-sitem__sum"><?php echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $mvweb_product, $mvweb_item['quantity'] ), $mvweb_item, $mvweb_key ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WooCommerce price markup. ?></span>
			</li>
			<?php
		}

		do_action( 'woocommerce_review_order_after_cart_contents' );
		?>
	</ul>
	<?php get_template_part( 'template-parts/cart/rows', null, array( 'context' => 'checkout' ) ); ?>
</div>
