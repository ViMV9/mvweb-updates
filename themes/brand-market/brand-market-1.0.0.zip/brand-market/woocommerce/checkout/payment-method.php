<?php
/**
 * One payment method: a card to choose, with the fields the gateway asks for under it.
 *
 * Arguments: gateway.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_fields = $gateway->has_fields();
$mvweb_text   = $mvweb_fields ? '' : trim( wp_strip_all_tags( (string) $gateway->get_description() ) );
?>
<li class="wc_payment_method payment_method_<?php echo esc_attr( $gateway->id ); ?>">
	<label class="mvweb-t-choice" for="payment_method_<?php echo esc_attr( $gateway->id ); ?>">
		<input id="payment_method_<?php echo esc_attr( $gateway->id ); ?>" type="radio" class="input-radio" name="payment_method" value="<?php echo esc_attr( $gateway->id ); ?>" <?php checked( $gateway->chosen, true ); ?> data-order_button_text="<?php echo esc_attr( $gateway->order_button_text ); ?>">
		<span class="mvweb-t-choice__icon"><?php echo mvweb_theme_icon( mvweb_core_payment_icon( $gateway->id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
		<span class="mvweb-t-choice__text">
			<strong><?php echo wp_kses_post( $gateway->get_title() ); ?></strong>
			<?php if ( '' !== $mvweb_text ) : ?>
				<small><?php echo esc_html( $mvweb_text ); ?></small>
			<?php endif; ?>
		</span>
		<span class="mvweb-t-choice__price"><?php echo wp_kses_post( $gateway->get_icon() ); ?></span>
	</label>
	<?php if ( $mvweb_fields || ( '' === $mvweb_text && $gateway->get_description() ) ) : ?>
		<div class="payment_box payment_method_<?php echo esc_attr( $gateway->id ); ?>"<?php echo $gateway->chosen ? '' : ' style="display:none;"'; ?>>
			<?php $gateway->payment_fields(); ?>
		</div>
	<?php endif; ?>
</li>
