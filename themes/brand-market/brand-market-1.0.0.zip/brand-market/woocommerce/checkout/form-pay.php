<?php
/**
 * The payment of an order that is already made: the methods, the goods and the button.
 *
 * An order whose payment failed opens with the word about it and the usual
 * reasons; an order that waits for the payment opens with a plain heading.
 *
 * Arguments: order, available_gateways, order_button_text.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

defined( 'ABSPATH' ) || exit;

$mvweb_failed = $order->has_status( 'failed' );

if ( $mvweb_failed ) {
	mvweb_theme_status_hero(
		array(
			'state' => 'fail',
			'title' => __( 'Payment failed', 'brand-market' ),
			'lead'  => mvweb_theme_pay_fail_lead( $order ),
		)
	);
} else {
	get_template_part(
		'template-parts/page-hero',
		null,
		array(
			'title' => __( 'Order payment', 'brand-market' ),
			/* translators: %s: number of the order. */
			'lead'  => sprintf( __( 'Order No. %s is waiting for the payment.', 'brand-market' ), $order->get_order_number() ),
		)
	);
}
?>
<section class="mvweb-t-section mvweb-t-section--flush-top">
	<div class="mvweb-t-container">
		<div class="mvweb-t-wc-notices"><?php woocommerce_output_all_notices(); ?></div>
		<form id="order_review" method="post" class="mvweb-t-order mvweb-t-checkout">
			<div class="mvweb-t-order__main">
				<fieldset class="mvweb-t-step">
					<legend class="mvweb-t-step__title"><span class="mvweb-t-step__num">1</span><?php esc_html_e( 'Payment', 'brand-market' ); ?></legend>
					<?php do_action( 'woocommerce_pay_order_before_payment' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce. ?>
					<div id="payment" class="woocommerce-checkout-payment">
						<?php if ( $order->needs_payment() ) : ?>
							<ul class="mvweb-t-step__choices wc_payment_methods payment_methods methods" aria-label="<?php esc_attr_e( 'Payment methods', 'brand-market' ); ?>">
								<?php
								if ( ! empty( $available_gateways ) ) {
									foreach ( $available_gateways as $mvweb_gateway ) {
										wc_get_template( 'checkout/payment-method.php', array( 'gateway' => $mvweb_gateway ) );
									}
								} else {
									echo '<li class="mvweb-t-step__note">' . esc_html( apply_filters( 'woocommerce_no_available_payment_methods_message', __( 'Sorry, there are no payment methods for your address. Write to us and we will find a way.', 'brand-market' ) ) ) . '</li>'; // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
								}
								?>
							</ul>
						<?php else : ?>
							<p class="mvweb-t-step__note"><?php esc_html_e( 'Nothing to pay for this order.', 'brand-market' ); ?></p>
						<?php endif; ?>
					</div>
				</fieldset>
				<?php
				if ( $mvweb_failed ) {
					mvweb_core_render_layout(
						'pay-fail',
						array(
							'order'   => $order,
							'context' => 'pay',
						)
					);
				}
				?>
			</div>
			<aside class="mvweb-t-summary mvweb-t-order__aside" aria-label="<?php esc_attr_e( 'Order items', 'brand-market' ); ?>">
				<div class="mvweb-t-summary__title mvweb-t-h2"><?php esc_html_e( 'Order items', 'brand-market' ); ?></div>
				<?php get_template_part( 'template-parts/order/summary', null, array( 'order' => $order ) ); ?>
				<div class="form-row">
					<input type="hidden" name="woocommerce_pay" value="1">
					<?php wc_get_template( 'checkout/terms.php' ); ?>
					<?php do_action( 'woocommerce_pay_order_before_submit' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce. ?>
					<?php echo apply_filters( 'woocommerce_pay_order_button_html', '<button type="submit" class="mvweb-t-btn mvweb-t-btn--block mvweb-t-btn--lg" id="place_order" value="' . esc_attr( $order_button_text ) . '" data-value="' . esc_attr( $order_button_text ) . '">' . esc_html( $order_button_text ) . '</button>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped,WooCommerce.Commenting.CommentHooks.MissingHookComment -- Escaped above; hook of WooCommerce. ?>
					<?php do_action( 'woocommerce_pay_order_after_submit' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce. ?>
					<?php wp_nonce_field( 'woocommerce-pay', 'woocommerce-pay-nonce' ); ?>
				</div>
			</aside>
		</form>
	</div>
</section>
