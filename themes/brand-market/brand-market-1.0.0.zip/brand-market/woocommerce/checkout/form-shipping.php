<?php
/**
 * The address the goods go to when it differs from the one of the payer.
 *
 * The note to the order has a step of its own (template-parts/checkout/comment.php).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

defined( 'ABSPATH' ) || exit;

if ( true !== WC()->cart->needs_shipping_address() ) {
	return;
}
?>
<div class="woocommerce-shipping-fields">
	<label class="mvweb-t-check woocommerce-form__label woocommerce-form__label-for-checkbox checkbox" for="ship-to-different-address-checkbox">
		<input id="ship-to-different-address-checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" <?php checked( apply_filters( 'woocommerce_ship_to_different_address_checked', 'shipping' === get_option( 'woocommerce_ship_to_destination' ) ? 1 : 0 ), 1 ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce. ?> type="checkbox" name="ship_to_different_address" value="1">
		<span><?php esc_html_e( 'Deliver to another address', 'brand-market' ); ?></span>
	</label>
	<div class="shipping_address">
		<?php do_action( 'woocommerce_before_checkout_shipping_form', $checkout ); ?>
		<div class="mvweb-t-step__grid woocommerce-shipping-fields__field-wrapper">
			<?php
			foreach ( $checkout->get_checkout_fields( 'shipping' ) as $mvweb_key => $mvweb_field ) {
				woocommerce_form_field( $mvweb_key, $mvweb_field, $checkout->get_value( $mvweb_key ) );
			}
			?>
		</div>
		<?php do_action( 'woocommerce_after_checkout_shipping_form', $checkout ); ?>
	</div>
</div>
