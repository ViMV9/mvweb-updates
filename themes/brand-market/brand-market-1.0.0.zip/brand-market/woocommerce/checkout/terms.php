<?php
/**
 * The agreement under the order total and the privacy text.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

defined( 'ABSPATH' ) || exit;

if ( ! apply_filters( 'woocommerce_checkout_show_terms', true ) || ! function_exists( 'wc_terms_and_conditions_checkbox_enabled' ) ) { // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
	return;
}

do_action( 'woocommerce_checkout_before_terms_and_conditions' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
?>
<div class="woocommerce-terms-and-conditions-wrapper mvweb-t-terms">
	<?php do_action( 'woocommerce_checkout_terms_and_conditions' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce. ?>
	<?php if ( wc_terms_and_conditions_checkbox_enabled() ) : ?>
		<p class="form-row validate-required">
			<label class="mvweb-t-check woocommerce-form__label woocommerce-form__label-for-checkbox checkbox">
				<input type="checkbox" class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" name="terms" id="terms" aria-required="true" <?php checked( apply_filters( 'woocommerce_terms_is_checked_default', isset( $_POST['terms'] ) ), true ); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WooCommerce.Commenting.CommentHooks.MissingHookComment -- Echoes the state of a failed submit back, as WooCommerce does. ?>>
				<span class="woocommerce-terms-and-conditions-checkbox-text"><?php wc_terms_and_conditions_checkbox_text(); ?> <span class="mvweb-t-required" aria-hidden="true">*</span></span>
			</label>
			<input type="hidden" name="terms-field" value="1">
		</p>
	<?php endif; ?>
</div>
<?php
do_action( 'woocommerce_checkout_after_terms_and_conditions' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
