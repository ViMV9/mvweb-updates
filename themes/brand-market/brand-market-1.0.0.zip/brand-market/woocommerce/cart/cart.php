<?php
/**
 * The cart: the lines with their tools, the order total, the goods bought together.
 *
 * The composition decides what stands where (inc/theme/layouts/cart.php); the
 * class names WooCommerce's cart script looks for stay on the form, the lines
 * and the totals.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

defined( 'ABSPATH' ) || exit;

?>
<div class="mvweb-t-container mvweb-t-wc-notices"><?php do_action( 'woocommerce_before_cart' ); ?></div>
<?php

mvweb_core_render_layout( 'cart.page' );

if ( has_action( 'woocommerce_cart_collaterals' ) ) :
	?>
	<div class="mvweb-t-container cart-collaterals">
		<?php do_action( 'woocommerce_cart_collaterals' ); ?>
	</div>
	<?php
endif;

do_action( 'woocommerce_after_cart' );
