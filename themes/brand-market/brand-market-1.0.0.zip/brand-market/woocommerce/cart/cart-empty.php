<?php
/**
 * The empty cart.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

defined( 'ABSPATH' ) || exit;

$mvweb_text      = trim( (string) mvweb_core_cart_option( 'mvweb_cart_empty_text' ) );
$mvweb_favorites = function_exists( 'mvweb_core_favorites_url' ) ? mvweb_core_favorites_url() : '';
?>
<section class="mvweb-t-section mvweb-t-section--flush-top wc-empty-cart-message">
	<div class="mvweb-t-container">
		<?php woocommerce_output_all_notices(); ?>
		<div class="mvweb-t-empty">
			<span class="mvweb-t-empty__icon"><?php echo mvweb_theme_icon( 'shopping-cart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
			<div class="mvweb-t-empty__title mvweb-t-h2"><?php esc_html_e( 'Your cart is empty', 'brand-market' ); ?></div>
			<p class="mvweb-t-empty__text"><?php echo esc_html( '' !== $mvweb_text ? $mvweb_text : __( 'Goods you add will appear here.', 'brand-market' ) ); ?></p>
			<div class="mvweb-t-empty__actions">
				<a class="mvweb-t-btn" href="<?php echo esc_url( mvweb_core_catalog_page_url() ); ?>"><?php esc_html_e( 'Go to the catalog', 'brand-market' ); ?></a>
				<?php if ( '' !== $mvweb_favorites ) : ?>
					<a class="mvweb-t-btn mvweb-t-btn--outline" href="<?php echo esc_url( $mvweb_favorites ); ?>"><?php esc_html_e( 'Open favourites', 'brand-market' ); ?></a>
				<?php endif; ?>
			</div>
		</div>
		<?php do_action( 'woocommerce_cart_is_empty' ); ?>
	</div>
</section>
