<?php
/**
 * The order total of the cart: the rows, the checkout button and the notes.
 *
 * The aside is the element WooCommerce's cart script replaces after every
 * change, so it carries its own heading facts for the script to copy up.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

defined( 'ABSPATH' ) || exit;
?>
<aside class="cart_totals mvweb-t-summary mvweb-t-order__aside<?php echo WC()->customer->has_calculated_shipping() ? ' calculated_shipping' : ''; ?>" aria-label="<?php esc_attr_e( 'Order total', 'brand-market' ); ?>" data-count="<?php echo (int) mvweb_theme_cart_positions(); ?>" data-hero="<?php echo esc_attr( (string) wp_json_encode( mvweb_theme_cart_hero_meta() ) ); ?>">
	<?php do_action( 'woocommerce_before_cart_totals' ); ?>
	<div class="mvweb-t-summary__title mvweb-t-h2"><?php esc_html_e( 'Your order', 'brand-market' ); ?></div>
	<?php get_template_part( 'template-parts/cart/rows', null, array( 'context' => 'cart' ) ); ?>
	<div class="wc-proceed-to-checkout">
		<?php do_action( 'woocommerce_proceed_to_checkout' ); ?>
	</div>
	<?php mvweb_core_render_layout( 'cart.aside' ); ?>
	<?php do_action( 'woocommerce_after_cart_totals' ); ?>
</aside>
