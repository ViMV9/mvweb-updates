<?php
/**
 * The button under the order total of the cart.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<a class="checkout-button wc-forward mvweb-t-btn mvweb-t-btn--block mvweb-t-btn--lg" href="<?php echo esc_url( wc_get_checkout_url() ); ?>"><?php esc_html_e( 'Checkout', 'brand-market' ); ?></a>
