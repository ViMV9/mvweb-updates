<?php
/**
 * The content of the side cart: the goods, the total and the two buttons.
 *
 * The remove link keeps the classes WooCommerce's script takes the click by,
 * so a good leaves the cart without a reload.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_mini_cart' );

if ( WC()->cart && ! WC()->cart->is_empty() ) :
	?>
	<ul class="mvweb-t-minicart__list">
		<?php
		do_action( 'woocommerce_before_mini_cart_contents' );

		foreach ( WC()->cart->get_cart() as $mvweb_key => $mvweb_item ) {
			$mvweb_product = apply_filters( 'woocommerce_cart_item_product', $mvweb_item['data'], $mvweb_item, $mvweb_key );

			if ( ! $mvweb_product instanceof WC_Product || ! $mvweb_product->exists() || $mvweb_item['quantity'] <= 0 || ! apply_filters( 'woocommerce_widget_cart_item_visible', true, $mvweb_item, $mvweb_key ) ) {
				continue;
			}

			$mvweb_id    = apply_filters( 'woocommerce_cart_item_product_id', $mvweb_item['product_id'], $mvweb_item, $mvweb_key );
			$mvweb_name  = apply_filters( 'woocommerce_cart_item_name', $mvweb_product->get_name(), $mvweb_item, $mvweb_key );
			$mvweb_link  = apply_filters( 'woocommerce_cart_item_permalink', $mvweb_product->is_visible() ? $mvweb_product->get_permalink( $mvweb_item ) : '', $mvweb_item, $mvweb_key );
			$mvweb_price = apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $mvweb_product ), $mvweb_item, $mvweb_key );
			$mvweb_sum   = apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $mvweb_product, $mvweb_item['quantity'] ), $mvweb_item, $mvweb_key );
			$mvweb_plain = wp_strip_all_tags( (string) $mvweb_name );
			?>
			<li class="mvweb-t-mitem woocommerce-mini-cart-item <?php echo esc_attr( apply_filters( 'woocommerce_mini_cart_item_class', 'mini_cart_item', $mvweb_item, $mvweb_key ) ); ?>">
				<a class="mvweb-t-mitem__media" href="<?php echo esc_url( '' !== $mvweb_link ? $mvweb_link : '#' ); ?>" tabindex="-1" aria-hidden="true">
					<?php echo $mvweb_product->get_image( 'mvweb_card', array( 'loading' => 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WooCommerce image markup. ?>
				</a>
				<div class="mvweb-t-mitem__info">
					<?php if ( '' !== $mvweb_link ) : ?>
						<a class="mvweb-t-mitem__name" href="<?php echo esc_url( $mvweb_link ); ?>"><?php echo wp_kses_post( $mvweb_name ); ?></a>
					<?php else : ?>
						<span class="mvweb-t-mitem__name"><?php echo wp_kses_post( $mvweb_name ); ?></span>
					<?php endif; ?>
					<?php echo wc_get_formatted_cart_item_data( $mvweb_item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by WooCommerce. ?>
					<span class="mvweb-t-mitem__calc"><?php echo wp_kses_post( apply_filters( 'woocommerce_widget_cart_item_quantity', sprintf( '%s &times; %s', number_format_i18n( (float) $mvweb_item['quantity'] ), $mvweb_price ), $mvweb_item, $mvweb_key ) ); ?></span>
				</div>
				<span class="mvweb-t-mitem__sum"><?php echo wp_kses_post( $mvweb_sum ); ?></span>
				<?php
				echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Every value is escaped below.
					'woocommerce_cart_item_remove_link',
					sprintf(
						'<a class="mvweb-t-mitem__remove remove_from_cart_button" role="button" href="%1$s" aria-label="%2$s" data-product_id="%3$s" data-cart_item_key="%4$s" data-product_sku="%5$s" data-success_message="%6$s">%7$s</a>',
						esc_url( wc_get_cart_remove_url( $mvweb_key ) ),
						/* translators: %s: name of the good. */
						esc_attr( sprintf( __( 'Remove %s from the cart', 'brand-market' ), $mvweb_plain ) ),
						esc_attr( $mvweb_id ),
						esc_attr( $mvweb_key ),
						esc_attr( $mvweb_product->get_sku() ),
						/* translators: %s: name of the good. */
						esc_attr( sprintf( __( '%s is removed from the cart', 'brand-market' ), $mvweb_plain ) ),
						mvweb_theme_icon( 'close' ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
					),
					$mvweb_key
				);
				?>
			</li>
			<?php
		}

		do_action( 'woocommerce_mini_cart_contents' );
		?>
	</ul>
	<div class="mvweb-t-minicart__foot">
		<p class="mvweb-t-minicart__sum woocommerce-mini-cart__total total">
			<span><?php esc_html_e( 'Total before promo code', 'brand-market' ); ?></span>
			<strong><?php echo wp_kses_post( WC()->cart->get_cart_subtotal() ); ?></strong>
		</p>
		<?php do_action( 'woocommerce_widget_shopping_cart_before_buttons' ); ?>
		<a class="mvweb-t-btn mvweb-t-btn--block" href="<?php echo esc_url( wc_get_checkout_url() ); ?>"><?php esc_html_e( 'Checkout', 'brand-market' ); ?></a>
		<a class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-btn--block" href="<?php echo esc_url( wc_get_cart_url() ); ?>"><?php esc_html_e( 'Go to the cart', 'brand-market' ); ?></a>
		<?php do_action( 'woocommerce_widget_shopping_cart_after_buttons' ); ?>
	</div>
<?php else : ?>
	<div class="mvweb-t-minicart__empty woocommerce-mini-cart__empty-message">
		<span class="mvweb-t-empty__icon"><?php echo mvweb_theme_icon( 'shopping-cart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
		<p class="mvweb-t-minicart__empty-title"><?php esc_html_e( 'Your cart is empty', 'brand-market' ); ?></p>
		<a class="mvweb-t-btn mvweb-t-btn--outline" href="<?php echo esc_url( mvweb_core_catalog_page_url() ); ?>"><?php esc_html_e( 'Go to the catalog', 'brand-market' ); ?></a>
	</div>
<?php endif; ?>
<?php do_action( 'woocommerce_after_mini_cart' ); ?>
