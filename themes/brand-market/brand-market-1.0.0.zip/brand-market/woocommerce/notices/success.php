<?php
/**
 * Success notices: an alert with the tick, one for each message.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 8.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! $notices ) {
	return;
}

foreach ( $notices as $mvweb_notice ) :
	?>
	<div class="mvweb-t-alert mvweb-t-alert--ok" role="status"<?php echo wc_get_notice_data_attr( $mvweb_notice ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by WooCommerce. ?>>
		<?php echo mvweb_theme_icon( 'check', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<p><?php echo wc_kses_notice( $mvweb_notice['notice'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by WooCommerce. ?></p>
	</div>
<?php endforeach; ?>
