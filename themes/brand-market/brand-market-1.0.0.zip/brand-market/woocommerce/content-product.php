<?php
/**
 * Product card in a listing.
 *
 * The card is the same for both catalogue sources and lives in
 * template-parts/catalog/card.php; this file is what WooCommerce looks for.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part( 'template-parts/catalog/card', null, array( 'id' => get_the_ID() ) );
