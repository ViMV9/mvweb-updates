<?php
/**
 * Product page.
 *
 * The page itself is the same for both catalogue sources and lives in
 * template-parts/catalog/single.php; this file is what WooCommerce looks for.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<div class="mvweb-t-container mvweb-t-wc-notices"><?php woocommerce_output_all_notices(); ?></div>
<?php

while ( have_posts() ) :
	the_post();

	get_template_part( 'template-parts/catalog/single', null, array( 'id' => get_the_ID() ) );
endwhile;

get_footer();
