<?php
/**
 * The cart and the checkout pages: the heading strip, then what WooCommerce prints in the text of the page.
 *
 * The strip comes from the context (inc/theme/modules/cart.php): the cart and
 * the checkout have one, the empty cart, the order received page and the
 * payment page draw their own.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	mvweb_theme_order_hero();

	the_content();
endwhile;

get_footer();
