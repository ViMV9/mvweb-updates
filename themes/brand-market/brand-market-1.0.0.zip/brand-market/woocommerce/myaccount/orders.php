<?php
/**
 * Orders: the table of orders with the pages, or the empty state.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 9.5.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_account_orders', $has_orders );

if ( $has_orders ) :
	get_template_part( 'template-parts/account/orders-table', null, array( 'orders' => array_map( 'wc_get_order', (array) $customer_orders->orders ) ) );

	do_action( 'woocommerce_before_account_orders_pagination' );

	if ( 1 < $customer_orders->max_num_pages ) :
		mvweb_theme_pagination(
			array(
				'base'    => esc_url_raw( wc_get_endpoint_url( 'orders', '%#%' ) ),
				'format'  => '',
				'current' => $current_page,
				'total'   => (int) $customer_orders->max_num_pages,
			)
		);
	endif;
else :
	get_template_part(
		'template-parts/account/empty',
		null,
		array(
			'icon'        => 'package',
			'title'       => __( 'No orders yet', 'brand-market' ),
			'text'        => __( 'When you place the first order, it will appear here with its status and contents.', 'brand-market' ),
			'button_url'  => apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ), // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
			'button_text' => __( 'Go to the catalogue', 'brand-market' ),
		)
	);
endif;

do_action( 'woocommerce_after_account_orders', $has_orders );
