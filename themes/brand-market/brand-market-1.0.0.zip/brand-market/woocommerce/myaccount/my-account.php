<?php
/**
 * My Account page: the navigation and the section beside it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 3.5.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_account_navigation' );
?>

<div class="mvweb-t-account__main woocommerce-MyAccount-content">
	<?php do_action( 'woocommerce_account_content' ); ?>
</div>
