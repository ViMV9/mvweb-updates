<?php
/**
 * My Addresses: a card for the delivery address and one for the payment address.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 9.3.0
 */

defined( 'ABSPATH' ) || exit;

$mvweb_customer = get_current_user_id();
$mvweb_titles   = array(
	'shipping' => __( 'Shipping address', 'brand-market' ),
	'billing'  => __( 'Billing address', 'brand-market' ),
);
$mvweb_empty    = array(
	'shipping' => __( 'Not set yet.', 'brand-market' ),
	'billing'  => __( 'Not set. Useful if you need documents for a company.', 'brand-market' ),
);

if ( ! wc_ship_to_billing_address_only() && wc_shipping_enabled() ) {
	$mvweb_addresses = apply_filters( 'woocommerce_my_account_get_addresses', $mvweb_titles, $mvweb_customer ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
} else {
	$mvweb_addresses = apply_filters( 'woocommerce_my_account_get_addresses', array( 'billing' => $mvweb_titles['billing'] ), $mvweb_customer ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
}
?>

<div class="mvweb-t-addr-cards">
	<?php
	foreach ( $mvweb_addresses as $mvweb_name => $mvweb_title ) :
		$mvweb_address = wc_get_account_formatted_address( $mvweb_name );
		$mvweb_title   = isset( $mvweb_titles[ $mvweb_name ] ) ? $mvweb_titles[ $mvweb_name ] : $mvweb_title;
		?>
		<section class="mvweb-t-addr-card">
			<div class="mvweb-t-addr-card__title mvweb-t-h2"><?php echo esc_html( $mvweb_title ); ?></div>
			<?php if ( $mvweb_address ) : ?>
				<address>
					<?php echo wp_kses_post( $mvweb_address ); ?>
					<?php do_action( 'woocommerce_my_account_after_my_address', $mvweb_name ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce. ?>
				</address>
			<?php else : ?>
				<p class="mvweb-t-addr-card__empty"><?php echo esc_html( isset( $mvweb_empty[ $mvweb_name ] ) ? $mvweb_empty[ $mvweb_name ] : $mvweb_empty['shipping'] ); ?></p>
			<?php endif; ?>
			<a class="mvweb-t-btn mvweb-t-btn--sm" href="<?php echo esc_url( wc_get_endpoint_url( 'edit-address', $mvweb_name ) ); ?>">
				<?php echo mvweb_theme_icon( $mvweb_address ? 'pencil' : 'plus', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<?php echo esc_html( $mvweb_address ? __( 'Edit', 'brand-market' ) : __( 'Add', 'brand-market' ) ); ?>
			</a>
		</section>
	<?php endforeach; ?>
</div>
