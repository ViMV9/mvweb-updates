<?php
/**
 * Edit account: the name, the email and the change of the password.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 11.0.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_edit_account_form' );
?>

<form class="mvweb-t-account__form" action="" method="post" <?php do_action( 'woocommerce_edit_account_form_tag' ); ?>>

	<?php do_action( 'woocommerce_edit_account_form_start' ); ?>

	<p class="mvweb-t-order__req"><span class="mvweb-t-required" aria-hidden="true">*</span> <?php esc_html_e( 'Required fields', 'brand-market' ); ?></p>

	<div class="mvweb-t-form-grid">
		<div class="mvweb-t-field">
			<label class="mvweb-t-field__label" for="account_first_name"><?php esc_html_e( 'First name', 'brand-market' ); ?></label>
			<input class="mvweb-t-field__input" id="account_first_name" name="account_first_name" type="text" value="<?php echo esc_attr( $user->first_name ); ?>" autocomplete="given-name" required>
		</div>
		<div class="mvweb-t-field">
			<label class="mvweb-t-field__label" for="account_last_name"><?php esc_html_e( 'Last name', 'brand-market' ); ?></label>
			<input class="mvweb-t-field__input" id="account_last_name" name="account_last_name" type="text" value="<?php echo esc_attr( $user->last_name ); ?>" autocomplete="family-name" required>
		</div>
		<div class="mvweb-t-field mvweb-t-field--wide">
			<label class="mvweb-t-field__label" for="account_display_name"><?php esc_html_e( 'Display name', 'brand-market' ); ?></label>
			<input class="mvweb-t-field__input" id="account_display_name" name="account_display_name" type="text" value="<?php echo esc_attr( $user->display_name ); ?>" aria-describedby="account_display_name_description" required>
			<span class="mvweb-t-form-hint" id="account_display_name_description"><?php echo wc_reviews_enabled() ? esc_html__( 'This is how your name is shown in the account and in reviews', 'brand-market' ) : esc_html__( 'This is how your name is shown in the account', 'brand-market' ); ?></span>
		</div>
		<div class="mvweb-t-field mvweb-t-field--wide">
			<label class="mvweb-t-field__label" for="account_email"><?php esc_html_e( 'Email address', 'brand-market' ); ?></label>
			<input class="mvweb-t-field__input" id="account_email" name="account_email" type="email" value="<?php echo esc_attr( $user->user_email ); ?>" autocomplete="email" required>
		</div>
	</div>

	<?php do_action( 'woocommerce_edit_account_form_fields' ); ?>

	<fieldset>
		<legend><?php esc_html_e( 'Change of password', 'brand-market' ); ?></legend>
		<p class="mvweb-t-form-hint"><?php esc_html_e( 'Leave the fields empty if you do not need to change the password.', 'brand-market' ); ?></p>
		<?php
		$mvweb_passwords = array(
			'password_current' => array( __( 'Current password', 'brand-market' ), 'current-password' ),
			'password_1'       => array( __( 'New password', 'brand-market' ), 'new-password' ),
			'password_2'       => array( __( 'Repeat the new password', 'brand-market' ), 'new-password' ),
		);

		foreach ( $mvweb_passwords as $mvweb_id => $mvweb_password ) :
			?>
			<div class="mvweb-t-field">
				<label class="mvweb-t-field__label" for="<?php echo esc_attr( $mvweb_id ); ?>"><?php echo esc_html( $mvweb_password[0] ); ?></label>
				<?php
				get_template_part(
					'template-parts/account/password',
					null,
					array(
						'id'           => $mvweb_id,
						'autocomplete' => $mvweb_password[1],
					)
				);
				?>
			</div>
		<?php endforeach; ?>
	</fieldset>

	<?php do_action( 'woocommerce_edit_account_form' ); ?>

	<div>
		<?php wp_nonce_field( 'save_account_details', 'save-account-details-nonce' ); ?>
		<button class="mvweb-t-btn" type="submit" name="save_account_details" value="<?php esc_attr_e( 'Save changes', 'brand-market' ); ?>"><?php esc_html_e( 'Save changes', 'brand-market' ); ?></button>
		<input type="hidden" name="action" value="<?php echo esc_attr( 'save_account_details' ); ?>">
	</div>

	<?php do_action( 'woocommerce_edit_account_form_end' ); ?>
</form>

<?php do_action( 'woocommerce_after_edit_account_form' ); ?>
