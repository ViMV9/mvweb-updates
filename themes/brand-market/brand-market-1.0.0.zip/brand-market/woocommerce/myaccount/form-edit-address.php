<?php
/**
 * Edit address: the fields of WooCommerce in a grid, the button under them.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 9.3.0
 */

defined( 'ABSPATH' ) || exit;

$mvweb_title = 'billing' === $load_address ? __( 'Billing address', 'brand-market' ) : __( 'Shipping address', 'brand-market' );

do_action( 'woocommerce_before_edit_account_address_form' );

if ( ! $load_address ) :
	wc_get_template( 'myaccount/my-address.php' );
else :
	?>
	<form class="mvweb-t-account__form" id="edit-<?php echo esc_attr( $load_address ); ?>" method="post" novalidate>
		<fieldset>
			<legend><?php echo esc_html( (string) apply_filters( 'woocommerce_my_account_edit_address_title', $mvweb_title, $load_address ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce. ?></legend>
			<p class="mvweb-t-order__req"><span class="mvweb-t-required" aria-hidden="true">*</span> <?php esc_html_e( 'Required fields', 'brand-market' ); ?></p>

			<?php do_action( "woocommerce_before_edit_address_form_{$load_address}" ); ?>

			<div class="mvweb-t-form-grid">
				<?php
				foreach ( $address as $mvweb_key => $mvweb_field ) {
					woocommerce_form_field( $mvweb_key, $mvweb_field, wc_get_post_data_by_key( $mvweb_key, $mvweb_field['value'] ) );
				}
				?>
			</div>

			<?php do_action( "woocommerce_after_edit_address_form_{$load_address}" ); ?>
		</fieldset>
		<div>
			<button class="mvweb-t-btn" type="submit" name="save_address" value="<?php esc_attr_e( 'Save address', 'brand-market' ); ?>"><?php esc_html_e( 'Save address', 'brand-market' ); ?></button>
			<?php wp_nonce_field( 'woocommerce-edit_address', 'woocommerce-edit-address-nonce' ); ?>
			<input type="hidden" name="action" value="<?php echo esc_attr( 'edit_address' ); ?>">
		</div>
	</form>
	<?php
endif;

do_action( 'woocommerce_after_edit_account_address_form' );
