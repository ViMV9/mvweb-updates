<?php
/**
 * View order: the reminder to pay and the overview, then the parts of the account-order area.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 10.6.0
 */

defined( 'ABSPATH' ) || exit;

$mvweb_args = array( 'order' => $order );
?>

<?php get_template_part( 'template-parts/account-order/pay', null, $mvweb_args ); ?>

<dl class="mvweb-t-overview">
	<div>
		<dt><?php esc_html_e( 'Order number', 'brand-market' ); ?></dt>
		<dd>
			<?php
			/* translators: %s: order number. */
			echo esc_html( sprintf( __( '#%s', 'brand-market' ), $order->get_order_number() ) );
			?>
		</dd>
	</div>
	<div>
		<dt><?php esc_html_e( 'Date', 'brand-market' ); ?></dt>
		<dd><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></dd>
	</div>
	<div>
		<dt><?php esc_html_e( 'Status', 'brand-market' ); ?></dt>
		<dd><?php get_template_part( 'template-parts/account/status', null, $mvweb_args ); ?></dd>
	</div>
	<?php if ( '' !== $order->get_payment_method_title() ) : ?>
		<div>
			<dt><?php esc_html_e( 'Payment', 'brand-market' ); ?></dt>
			<dd><?php echo esc_html( $order->get_payment_method_title() ); ?></dd>
		</div>
	<?php endif; ?>
</dl>

<?php
mvweb_core_render_layout( 'account-order', $mvweb_args );

do_action( 'woocommerce_view_order', $order_id );
