<?php
/**
 * Lost password, the letter is sent: the card that says so, with the button to ask again.
 *
 * The page cannot name the address: it would tell a stranger which emails have an account.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 3.9.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_lost_password_confirmation_message' );

get_template_part(
	'template-parts/account/card',
	null,
	array(
		'icon'    => 'mail',
		'title'   => __( 'Check your mail', 'brand-market' ),
		'text'    => (string) apply_filters( 'woocommerce_lost_password_confirmation_message', __( 'If there is an account with this address, we have sent it a link to reset the password. The letter comes within a couple of minutes; look in the Spam folder too.', 'brand-market' ) ), // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
		'actions' => array(
			array(
				'url'  => wc_get_page_permalink( 'myaccount' ),
				'text' => __( 'Back to sign in', 'brand-market' ),
			),
			array(
				'url'   => wc_lostpassword_url(),
				'text'  => __( 'Send again', 'brand-market' ),
				'class' => 'mvweb-t-btn--outline',
				'attrs' => array(
					'data-resend' => '60',
					'data-ready'  => __( 'Send again', 'brand-market' ),
				),
			),
		),
	)
);

do_action( 'woocommerce_after_lost_password_confirmation_message' );
