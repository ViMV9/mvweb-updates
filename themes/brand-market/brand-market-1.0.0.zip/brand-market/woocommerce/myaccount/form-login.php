<?php
/**
 * Login and registration: the cards of the account-login area, the forms of WooCommerce inside them.
 *
 * The cards of the forms share one grid, the benefits of an account stand in a
 * row of their own. After a password has been reset the page shows the card that
 * says so instead of the forms.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 9.9.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_customer_login_form' );

if ( ! empty( $_GET['password-reset'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Only chooses which card to print.
	wc_clear_notices();

	get_template_part(
		'template-parts/account/card',
		null,
		array(
			'icon'    => 'check',
			'title'   => __( 'Password changed', 'brand-market' ),
			'text'    => __( 'Now you can sign in with the new password.', 'brand-market' ),
			'actions' => array(
				array(
					'url'  => wc_get_page_permalink( 'myaccount' ),
					'text' => __( 'Log in', 'brand-market' ),
				),
			),
		)
	);
else :
	$mvweb_register = 'yes' === get_option( 'woocommerce_enable_myaccount_registration' );
	$mvweb_parts    = mvweb_theme_account_layout_html( 'account-login', array( 'register' => $mvweb_register ) );
	$mvweb_cards    = array();
	$mvweb_out      = '';

	foreach ( $mvweb_parts as $mvweb_slug => $mvweb_markup ) {
		if ( 'perks' !== $mvweb_slug ) {
			$mvweb_cards[] = $mvweb_markup;
			continue;
		}

		$mvweb_out  .= empty( $mvweb_cards ) ? '' : '<div class="mvweb-t-auth' . ( 1 === count( $mvweb_cards ) ? ' mvweb-t-auth--single' : '' ) . '">' . implode( '', $mvweb_cards ) . '</div>';
		$mvweb_cards = array();
		$mvweb_out  .= $mvweb_markup;
	}

	$mvweb_out .= empty( $mvweb_cards ) ? '' : '<div class="mvweb-t-auth' . ( 1 === count( $mvweb_cards ) ? ' mvweb-t-auth--single' : '' ) . '">' . implode( '', $mvweb_cards ) . '</div>';

	echo $mvweb_out; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there.
endif;

do_action( 'woocommerce_after_customer_login_form' );
