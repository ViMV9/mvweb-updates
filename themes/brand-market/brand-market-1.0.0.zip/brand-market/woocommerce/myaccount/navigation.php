<?php
/**
 * My Account navigation: the sections of the account, a drop-down list on a phone.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 9.3.0
 */

defined( 'ABSPATH' ) || exit;

$mvweb_items   = wc_get_account_menu_items();
$mvweb_current = mvweb_theme_account_endpoint();
$mvweb_same    = array(
	'view-order'         => 'orders',
	'add-payment-method' => 'payment-methods',
);
$mvweb_current = isset( $mvweb_same[ $mvweb_current ] ) ? $mvweb_same[ $mvweb_current ] : $mvweb_current;
$mvweb_current = isset( $mvweb_items[ $mvweb_current ] ) ? $mvweb_current : 'dashboard';

do_action( 'woocommerce_before_account_navigation' );
?>

<nav class="mvweb-t-accnav" aria-label="<?php esc_attr_e( 'Account pages', 'brand-market' ); ?>">
	<button class="mvweb-t-accnav__toggle" type="button" aria-expanded="false" aria-controls="accnav-list" data-accnav-toggle>
		<?php echo mvweb_theme_icon( mvweb_theme_account_icon( $mvweb_current ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<span class="mvweb-t-accnav__cur"><small><?php esc_html_e( 'Account section', 'brand-market' ); ?></small><?php echo esc_html( isset( $mvweb_items[ $mvweb_current ] ) ? $mvweb_items[ $mvweb_current ] : '' ); ?></span>
		<?php echo mvweb_theme_icon( 'chevron-down' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	</button>
	<ul class="mvweb-t-accnav__list" id="accnav-list">
		<?php foreach ( $mvweb_items as $mvweb_endpoint => $mvweb_label ) : ?>
			<li class="mvweb-t-accnav__item<?php echo 'customer-logout' === $mvweb_endpoint ? ' mvweb-t-accnav__item--exit' : ''; ?>">
				<a class="mvweb-t-accnav__link" href="<?php echo esc_url( wc_get_account_endpoint_url( $mvweb_endpoint ) ); ?>"<?php echo $mvweb_endpoint === $mvweb_current ? ' aria-current="page"' : ''; ?>>
					<?php echo mvweb_theme_icon( mvweb_theme_account_icon( $mvweb_endpoint ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<span><?php echo esc_html( $mvweb_label ); ?></span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</nav>

<?php do_action( 'woocommerce_after_account_navigation' ); ?>
