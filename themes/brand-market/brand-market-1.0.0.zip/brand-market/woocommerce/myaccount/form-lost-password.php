<?php
/**
 * Lost password: the request for the link, or the card that says the link is out of date.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 9.2.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_lost_password_form' );

$mvweb_login = wc_get_page_permalink( 'myaccount' );

if ( wc_has_notice( __( 'This key is invalid or has already been used. Please reset your password again if needed.', 'woocommerce' ), 'error' ) ) : // phpcs:ignore WordPress.WP.I18n.TextDomainMismatch -- The text of WooCommerce is the notice to find.
	wc_clear_notices();

	get_template_part(
		'template-parts/account/card',
		null,
		array(
			'icon'    => 'clock',
			'tone'    => 'muted',
			'title'   => __( 'The link is out of date', 'brand-market' ),
			/* translators: %s: how long the link of the letter works, for example "1 day". */
			'text'    => sprintf( __( 'The link to reset the password works for %s and only once. Ask for a new one.', 'brand-market' ), human_time_diff( 0, (int) apply_filters( 'password_reset_expiration', DAY_IN_SECONDS ) ) ), // phpcs:ignore WordPress.WP.I18n.MissingTranslatorsComment -- Comment stands above.
			'actions' => array(
				array(
					'url'  => wc_lostpassword_url(),
					'text' => __( 'Get a link', 'brand-market' ),
				),
			),
		)
	);
else :
	?>
	<div class="mvweb-t-auth mvweb-t-auth--single">
		<section class="mvweb-t-auth__card">
			<div class="mvweb-t-auth__title mvweb-t-h2"><?php esc_html_e( 'Forgot your password?', 'brand-market' ); ?></div>
			<p class="mvweb-t-auth__lead"><?php echo wp_kses_post( (string) apply_filters( 'woocommerce_lost_password_message', esc_html__( 'Enter the email you registered with. We will send a link to create a new password.', 'brand-market' ) ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce. ?></p>
			<?php wc_print_notices(); ?>
			<form class="mvweb-t-account__form mvweb-t-account__form--full woocommerce-ResetPassword lost_reset_password" method="post">
				<div class="mvweb-t-field">
					<label class="mvweb-t-field__label" for="user_login"><?php esc_html_e( 'Email or login', 'brand-market' ); ?></label>
					<input class="mvweb-t-field__input" id="user_login" name="user_login" type="text" autocomplete="username" required>
				</div>
				<?php do_action( 'woocommerce_lostpassword_form' ); ?>
				<input type="hidden" name="wc_reset_password" value="<?php echo esc_attr( 'true' ); ?>">
				<?php wp_nonce_field( 'lost_password', 'woocommerce-lost-password-nonce' ); ?>
				<button class="mvweb-t-btn mvweb-t-btn--block" type="submit" value="<?php esc_attr_e( 'Reset password', 'brand-market' ); ?>"><?php esc_html_e( 'Get a link', 'brand-market' ); ?></button>
			</form>
			<a class="mvweb-t-btn mvweb-t-btn--link" href="<?php echo esc_url( $mvweb_login ); ?>"><?php esc_html_e( 'Back to sign in', 'brand-market' ); ?></a>
		</section>
	</div>
	<?php
endif;

do_action( 'woocommerce_after_lost_password_form' );
