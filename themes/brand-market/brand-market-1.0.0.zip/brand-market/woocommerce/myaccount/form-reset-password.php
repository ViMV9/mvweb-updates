<?php
/**
 * Reset password: the new password twice, with the strength of the first.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 9.2.0
 */

defined( 'ABSPATH' ) || exit;

do_action( 'woocommerce_before_reset_password_form' );
?>
<div class="mvweb-t-auth mvweb-t-auth--single">
	<section class="mvweb-t-auth__card">
		<div class="mvweb-t-auth__title mvweb-t-h2"><?php esc_html_e( 'New password', 'brand-market' ); ?></div>
		<p class="mvweb-t-auth__lead"><?php echo wp_kses_post( (string) apply_filters( 'woocommerce_reset_password_message', esc_html__( 'Think of a password that is not used on other sites.', 'brand-market' ) ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce. ?></p>
		<?php wc_print_notices(); ?>
		<form class="mvweb-t-account__form mvweb-t-account__form--full woocommerce-ResetPassword lost_reset_password" method="post">
			<div class="mvweb-t-field">
				<label class="mvweb-t-field__label" for="password_1"><?php esc_html_e( 'New password', 'brand-market' ); ?></label>
				<?php
				get_template_part(
					'template-parts/account/password',
					null,
					array(
						'id'           => 'password_1',
						'autocomplete' => 'new-password',
						'required'     => true,
						'minlength'    => 8,
						'strength'     => true,
					)
				);
				?>
			</div>
			<div class="mvweb-t-strength" data-strength hidden>
				<span class="mvweb-t-strength__bar"><i></i><i></i><i></i><i></i></span>
				<span data-strength-label aria-live="polite"></span>
			</div>
			<div class="mvweb-t-field">
				<label class="mvweb-t-field__label" for="password_2"><?php esc_html_e( 'Repeat the password', 'brand-market' ); ?></label>
				<?php
				get_template_part(
					'template-parts/account/password',
					null,
					array(
						'id'           => 'password_2',
						'autocomplete' => 'new-password',
						'required'     => true,
					)
				);
				?>
			</div>
			<input type="hidden" name="reset_key" value="<?php echo esc_attr( $args['key'] ); ?>">
			<input type="hidden" name="reset_login" value="<?php echo esc_attr( $args['login'] ); ?>">
			<?php do_action( 'woocommerce_resetpassword_form' ); ?>
			<input type="hidden" name="wc_reset_password" value="<?php echo esc_attr( 'true' ); ?>">
			<?php wp_nonce_field( 'reset_password', 'woocommerce-reset-password-nonce' ); ?>
			<button class="mvweb-t-btn mvweb-t-btn--block" type="submit" value="<?php esc_attr_e( 'Save', 'brand-market' ); ?>"><?php esc_html_e( 'Save password', 'brand-market' ); ?></button>
		</form>
	</section>
</div>
<?php
do_action( 'woocommerce_after_reset_password_form' );
