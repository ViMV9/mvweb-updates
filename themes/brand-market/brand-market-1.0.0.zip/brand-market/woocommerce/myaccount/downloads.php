<?php
/**
 * Downloads: the files of the purchased goods, or the empty state.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 7.8.0
 */

defined( 'ABSPATH' ) || exit;

$mvweb_downloads     = WC()->customer->get_downloadable_products();
$mvweb_has_downloads = (bool) $mvweb_downloads;

do_action( 'woocommerce_before_account_downloads', $mvweb_has_downloads );

if ( $mvweb_has_downloads ) :
	do_action( 'woocommerce_before_available_downloads' );
	?>
	<table class="mvweb-t-otable mvweb-t-otable--files">
		<thead>
			<tr>
				<th scope="col"><?php esc_html_e( 'File', 'brand-market' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Downloads left', 'brand-market' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Valid until', 'brand-market' ); ?></th>
				<th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Download', 'brand-market' ); ?></span></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $mvweb_downloads as $mvweb_download ) : ?>
				<tr>
					<td>
						<span class="mvweb-t-otable__file">
							<a href="<?php echo esc_url( get_permalink( $mvweb_download['product_id'] ) ); ?>"><?php echo esc_html( $mvweb_download['download_name'] ); ?></a>
							<span><?php echo esc_html( $mvweb_download['product_name'] ); ?></span>
						</span>
					</td>
					<td data-label="<?php esc_attr_e( 'Left', 'brand-market' ); ?>"><?php echo is_numeric( $mvweb_download['downloads_remaining'] ) ? esc_html( (string) $mvweb_download['downloads_remaining'] ) : esc_html__( 'unlimited', 'brand-market' ); ?></td>
					<td data-label="<?php esc_attr_e( 'Valid', 'brand-market' ); ?>"><?php echo ! empty( $mvweb_download['access_expires'] ) ? esc_html( date_i18n( get_option( 'date_format' ), strtotime( $mvweb_download['access_expires'] ) ) ) : esc_html__( 'no time limit', 'brand-market' ); ?></td>
					<td>
						<div class="mvweb-t-otable__btns">
							<a class="mvweb-t-btn mvweb-t-btn--sm" href="<?php echo esc_url( $mvweb_download['download_url'] ); ?>">
								<?php echo mvweb_theme_icon( 'download', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
								<?php esc_html_e( 'Download', 'brand-market' ); ?>
							</a>
						</div>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
	<?php
	do_action( 'woocommerce_after_available_downloads' );
else :
	get_template_part(
		'template-parts/account/empty',
		null,
		array(
			'icon'        => 'download',
			'title'       => __( 'No downloads yet', 'brand-market' ),
			'text'        => __( 'Files for the purchased goods will appear here.', 'brand-market' ),
			'button_url'  => apply_filters( 'woocommerce_return_to_shop_redirect', wc_get_page_permalink( 'shop' ) ), // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
			'button_text' => __( 'Go to the catalogue', 'brand-market' ),
		)
	);
endif;

do_action( 'woocommerce_after_account_downloads', $mvweb_has_downloads );
