<?php
/**
 * The page of the account: the head of the section, then the sign-in forms or the navigation with the section.
 *
 * WooCommerce prints everything after the head through the shortcode in the
 * content of the page; a signed-in customer gets the grid of the navigation
 * and the section, a guest gets the forms.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	$mvweb_head = mvweb_theme_account_head();
	$mvweb_grid = is_user_logged_in() && 'lost-password' !== mvweb_theme_account_endpoint();

	get_template_part(
		'template-parts/page-hero',
		null,
		array(
			'title' => $mvweb_head['title'],
			'lead'  => $mvweb_head['lead'],
		)
	);
	?>
	<section class="mvweb-t-section mvweb-t-section--flush-top">
		<div class="mvweb-t-container<?php echo $mvweb_grid ? ' mvweb-t-account' : ''; ?>">
			<?php the_content(); ?>
		</div>
	</section>
	<?php
endwhile;

get_footer();
