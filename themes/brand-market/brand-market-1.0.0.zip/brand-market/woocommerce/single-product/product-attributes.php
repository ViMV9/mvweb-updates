<?php
/**
 * Specifications of a product.
 *
 * Overrides the WooCommerce template so the layout gets its definition list
 * instead of a table; the rows themselves are still prepared by
 * wc_display_product_attributes(), including weight, dimensions and brand.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $product_attributes ) ) {
	return;
}
?>
<dl class="mvweb-t-specs">
	<?php foreach ( $product_attributes as $mvweb_key => $mvweb_row ) : ?>
		<div class="mvweb-t-specs__row mvweb-t-specs__row--<?php echo esc_attr( $mvweb_key ); ?>">
			<dt class="mvweb-t-specs__label"><?php echo wp_kses_post( $mvweb_row['label'] ); ?></dt>
			<dd class="mvweb-t-specs__value"><?php echo wp_kses_post( $mvweb_row['value'] ); ?></dd>
		</div>
	<?php endforeach; ?>
</dl>
