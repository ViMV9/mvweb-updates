<?php
/**
 * Add to cart form of a simple product.
 *
 * Overrides the WooCommerce template: the row of the quantity stepper, the
 * button and the favourites heart is the theme's own
 * (template-parts/product-cart-row.php), the availability is told by the
 * purchase box and not repeated here. The hooks around the form and the button
 * are kept, so plugins that hang on them keep working.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;

if ( ! $product->is_purchasable() || ! $product->is_in_stock() ) {
	return;
}

do_action( 'woocommerce_before_add_to_cart_form' );
?>
<form class="cart mvweb-t-product-cart" id="<?php echo esc_attr( 'mvweb-t-cart-' . $product->get_id() ); ?>" action="<?php echo esc_url( apply_filters( 'woocommerce_add_to_cart_form_action', $product->get_permalink() ) ); ?>" method="post" enctype="multipart/form-data">
	<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>

	<?php
	get_template_part(
		'template-parts/product-cart-row',
		null,
		array(
			'product' => $product,
			'name'    => 'add-to-cart',
		)
	);
	?>

	<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>

	<?php get_template_part( 'template-parts/one-click-button', null, array( 'product' => $product ) ); ?>
</form>

<?php do_action( 'woocommerce_after_add_to_cart_form' ); ?>

<?php get_template_part( 'template-parts/one-click', null, array( 'product' => $product ) ); ?>
