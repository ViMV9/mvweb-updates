<?php
/**
 * The button of the add to cart form of a variable product.
 *
 * Overrides the WooCommerce template with the row the simple product form has:
 * the quantity stepper, the button and the favourites heart. The hidden fields
 * that carry the product and the chosen variation stay.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

global $product;
?>
<div class="woocommerce-variation-add-to-cart variations_button mvweb-t-product-cart">
	<?php do_action( 'woocommerce_before_add_to_cart_button' ); ?>

	<?php get_template_part( 'template-parts/product-cart-row', null, array( 'product' => $product ) ); ?>

	<?php do_action( 'woocommerce_after_add_to_cart_button' ); ?>

	<input type="hidden" name="add-to-cart" value="<?php echo absint( $product->get_id() ); ?>">
	<input type="hidden" name="product_id" value="<?php echo absint( $product->get_id() ); ?>">
	<input type="hidden" name="variation_id" class="variation_id" value="0">
</div>
