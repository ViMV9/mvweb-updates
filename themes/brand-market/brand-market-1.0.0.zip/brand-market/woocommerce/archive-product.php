<?php
/**
 * Catalog listing: the shop page, a product category, a tag, an attribute.
 *
 * The listing itself is the same for both catalogue sources and lives in
 * template-parts/catalog/listing.php; this file is what WooCommerce looks for.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();
?>
<div class="mvweb-t-container mvweb-t-wc-notices"><?php woocommerce_output_all_notices(); ?></div>
<?php

get_template_part( 'template-parts/catalog/listing' );

get_footer();
