<?php
/**
 * Section card part: the picture, a link to the section.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_image = mvweb_core_service_term_image( $args['term'], 'medium_large' );

if ( '' === $mvweb_image ) {
	return;
}
?>
<a class="mvweb-t-card__media" href="<?php echo esc_url( $args['link'] ); ?>" tabindex="-1" aria-hidden="true">
	<?php echo $mvweb_image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core's escaped image markup or the escaped placeholder. ?>
</a>
