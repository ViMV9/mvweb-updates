<?php
/**
 * Section card part: the name, a link to the section.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="mvweb-t-card__title mvweb-t-h3"><a href="<?php echo esc_url( $args['link'] ); ?>"><?php echo esc_html( $args['term']->name ); ?></a></div>
