<?php
/**
 * Section card part: the number of services in the section.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_count = mvweb_core_service_count( $args['term']->term_id );

if ( 0 === $mvweb_count ) {
	return;
}

/* translators: %s: number of services in the section. */
$mvweb_text = sprintf( _n( '%s service', '%s services', $mvweb_count, 'brand-market' ), number_format_i18n( $mvweb_count ) );
?>
<p class="mvweb-t-card__advantage"><?php echo esc_html( $mvweb_text ); ?></p>
