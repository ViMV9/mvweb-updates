<?php
/**
 * Section card part: the link to the section.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_more = trim( (string) mvweb_core_services_pages_option( 'mvweb_service_section_more' ) );
?>
<div class="mvweb-t-card__foot"><a class="mvweb-t-card__more" href="<?php echo esc_url( $args['link'] ); ?>"<?php echo '' === $mvweb_more ? ' aria-label="' . esc_attr( $args['term']->name ) . '"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in place. ?>><?php echo esc_html( $mvweb_more ); ?><?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></a></div>
