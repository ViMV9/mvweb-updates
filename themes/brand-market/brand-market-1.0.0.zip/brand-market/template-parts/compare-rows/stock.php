<?php
/**
 * Comparison row: the availability.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_items = isset( $args['model']['items'] ) ? (array) $args['model']['items'] : array();
$mvweb_cells = array();

foreach ( $mvweb_items as $mvweb_id ) {
	$mvweb_stock = mvweb_core_item_stock( $mvweb_id );

	if ( empty( $mvweb_stock['label'] ) ) {
		continue;
	}

	/* translators: %d: how many pieces are in stock. */
	$mvweb_cells[ $mvweb_id ] = esc_html( null !== $mvweb_stock['qty'] ? sprintf( __( '%d left', 'brand-market' ), $mvweb_stock['qty'] ) : $mvweb_stock['label'] );
}

mvweb_theme_compare_row( __( 'Availability', 'brand-market' ), $mvweb_items, $mvweb_cells );
