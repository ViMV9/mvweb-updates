<?php
/**
 * Comparison rows: the characteristics of the items.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_items = isset( $args['model']['items'] ) ? (array) $args['model']['items'] : array();
$mvweb_rows  = isset( $args['model']['rows'] ) ? (array) $args['model']['rows'] : array();

foreach ( $mvweb_rows as $mvweb_row ) {
	mvweb_theme_compare_row( $mvweb_row['label'], $mvweb_items, array_map( 'esc_html', $mvweb_row['cells'] ) );
}
