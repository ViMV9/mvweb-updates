<?php
/**
 * Comparison row: the rating and the number of reviews.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_items = isset( $args['model']['items'] ) ? (array) $args['model']['items'] : array();
$mvweb_cells = array();

foreach ( $mvweb_items as $mvweb_id ) {
	$mvweb_rating = mvweb_core_item_rating( $mvweb_id );

	if ( empty( $mvweb_rating ) ) {
		continue;
	}

	$mvweb_cells[ $mvweb_id ] = esc_html( number_format_i18n( $mvweb_rating['value'], 1 ) ) . ' <small>(' . (int) $mvweb_rating['count'] . ')</small>';
}

mvweb_theme_compare_row( __( 'Rating', 'brand-market' ), $mvweb_items, $mvweb_cells );
