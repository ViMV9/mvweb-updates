<?php
/**
 * Comparison row: the wholesale price and the quantity it starts from.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_items = isset( $args['model']['items'] ) ? (array) $args['model']['items'] : array();

if ( ! mvweb_core_shop_mode() ) {
	return;
}

$mvweb_cells = array();

foreach ( $mvweb_items as $mvweb_id ) {
	$mvweb_price = '' === trim( wp_strip_all_tags( mvweb_core_item_price_html( $mvweb_id ) ) ) ? '' : mvweb_core_item_wholesale_line( $mvweb_id );

	if ( '' === $mvweb_price ) {
		continue;
	}

	$mvweb_tiers = mvweb_core_tiers( $mvweb_id );
	$mvweb_min   = ! empty( $mvweb_tiers ) ? (int) array_key_first( $mvweb_tiers ) : (int) mvweb_core_quantity_rules( $mvweb_id )['min'];
	$mvweb_unit  = mvweb_core_qty_unit( $mvweb_id );

	$mvweb_cells[ $mvweb_id ] = $mvweb_price;

	if ( $mvweb_min > 1 ) {
		/* translators: 1: minimum quantity, 2: unit, for example pcs. */
		$mvweb_cells[ $mvweb_id ] .= ' <small>' . esc_html( sprintf( __( 'from %1$d %2$s', 'brand-market' ), $mvweb_min, '' !== $mvweb_unit ? $mvweb_unit : __( 'pcs', 'brand-market' ) ) ) . '</small>';
	}
}

mvweb_theme_compare_row( mvweb_core_wholesale_label(), $mvweb_items, $mvweb_cells );
