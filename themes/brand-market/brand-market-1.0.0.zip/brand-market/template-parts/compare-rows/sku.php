<?php
/**
 * Comparison row: the article number.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_items = isset( $args['model']['items'] ) ? (array) $args['model']['items'] : array();
$mvweb_cells = array();

foreach ( $mvweb_items as $mvweb_id ) {
	$mvweb_cells[ $mvweb_id ] = esc_html( mvweb_core_item_sku( $mvweb_id ) );
}

mvweb_theme_compare_row( __( 'Article', 'brand-market' ), $mvweb_items, $mvweb_cells );
