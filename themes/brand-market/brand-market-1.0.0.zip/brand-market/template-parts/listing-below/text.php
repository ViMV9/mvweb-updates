<?php
/**
 * Under a listing, part: the text of the category.
 *
 * It stands in the column of the cards when it comes before the blocks, and
 * under the blocks, on its own, when the composition puts it after them.
 *
 * Arguments: place (main: the column of the cards; after: under the section).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_text = mvweb_core_listing_text_now();

if ( '' === $mvweb_text ) {
	return;
}

$mvweb_order = mvweb_core_layout_order( 'listing-below' );
$mvweb_from  = array_search( 'text', $mvweb_order, true );
$mvweb_to    = array_search( 'blocks', $mvweb_order, true );
$mvweb_late  = false !== $mvweb_to && false !== $mvweb_from && $mvweb_to < $mvweb_from;
$mvweb_place = isset( $args['place'] ) ? (string) $args['place'] : 'main';

if ( ( $mvweb_late ? 'after' : 'main' ) !== $mvweb_place ) {
	return;
}
?>
<?php if ( $mvweb_late ) : ?>
<section class="mvweb-t-section mvweb-t-section--tight">
	<div class="mvweb-t-container">
<?php endif; ?>
<div class="mvweb-t-prose mvweb-t-catalog__text" data-prose>
	<?php echo apply_filters( 'the_content', $mvweb_text ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The key is registered with wp_kses_post, and the_content closes with kses of its own. ?>
</div>
<?php if ( $mvweb_late ) : ?>
	</div>
</section>
<?php endif; ?>
