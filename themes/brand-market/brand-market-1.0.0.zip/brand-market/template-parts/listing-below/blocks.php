<?php
/**
 * Under a listing, part: the blocks of the category, the filter page or the page chosen for the catalogue.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( isset( $args['place'] ) && 'after' !== $args['place'] ) {
	return;
}

mvweb_core_render_context_sections();
