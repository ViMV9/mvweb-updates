<?php
/**
 * Failed payment, part: the usual reasons and where to ask for help.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_reasons  = array_filter(
	mvweb_core_cart_rows( 'mvweb_pay_fail_reasons' ),
	static function ( $row ) {
		return ! empty( $row['text'] );
	}
);
$mvweb_contacts = mvweb_core_contacts();
$mvweb_phone    = isset( $mvweb_contacts['phones'][0] ) ? $mvweb_contacts['phones'][0] : array();

if ( empty( $mvweb_reasons ) && empty( $mvweb_phone['number'] ) ) {
	return;
}
?>
<section class="mvweb-t-info-card">
	<?php if ( ! empty( $mvweb_reasons ) ) : ?>
		<div class="mvweb-t-info-card__title mvweb-t-h2"><?php esc_html_e( 'Usual reasons', 'brand-market' ); ?></div>
		<ul class="mvweb-t-info-card__list">
			<?php foreach ( $mvweb_reasons as $mvweb_reason ) : ?>
				<li><?php echo esc_html( $mvweb_reason['text'] ); ?></li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	<?php if ( ! empty( $mvweb_phone['number'] ) ) : ?>
		<p class="mvweb-t-info-card__note">
			<?php esc_html_e( 'It does not work? Write to us in a messenger or call:', 'brand-market' ); ?>
			<a href="<?php echo esc_url( $mvweb_phone['href'], array( 'tel' ) ); ?>"><?php echo esc_html( $mvweb_phone['number'] ); ?></a>
		</p>
	<?php endif; ?>
</section>
