<?php
/**
 * Failed payment, part: pay again, pay another way, back to the cart.
 *
 * Shown on the order received page; on the payment page the form itself is
 * the way to pay again.
 *
 * Arguments: order, context.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_order = isset( $args['order'] ) ? $args['order'] : null;

if ( ! $mvweb_order instanceof WC_Order || ( isset( $args['context'] ) && 'received' !== $args['context'] ) ) {
	return;
}

$mvweb_pay   = $mvweb_order->get_checkout_payment_url();
$mvweb_other = count( WC()->payment_gateways()->get_available_payment_gateways() ) > 1;
?>
<div class="mvweb-t-thanks__actions">
	<a class="mvweb-t-btn" href="<?php echo esc_url( $mvweb_pay ); ?>"><?php esc_html_e( 'Pay again', 'brand-market' ); ?></a>
	<?php if ( $mvweb_other ) : ?>
		<a class="mvweb-t-btn mvweb-t-btn--outline" href="<?php echo esc_url( $mvweb_pay . '#payment' ); ?>"><?php esc_html_e( 'Choose another method', 'brand-market' ); ?></a>
	<?php endif; ?>
	<a class="mvweb-t-btn mvweb-t-btn--link" href="<?php echo esc_url( wc_get_cart_url() ); ?>"><?php esc_html_e( 'Back to the cart', 'brand-market' ); ?></a>
</div>
