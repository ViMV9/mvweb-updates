<?php
/**
 * One work of the portfolio.
 *
 * Laid out like a service: the head and the main column on the left, the side
 * card with the figures on the right. Every group of parts is an area of the
 * composition; a group with nothing to print leaves no wrapper behind, and a
 * page without the side card gives its width to the main column. Under the page
 * come the blocks of the work-blocks area and the blocks the work carries.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : get_the_ID();

if ( 0 === $mvweb_id ) {
	return;
}

$mvweb_args   = array( 'id' => $mvweb_id );
$mvweb_head   = mvweb_core_works_layout_html( 'work-head', $mvweb_args );
$mvweb_aside  = mvweb_core_works_layout_html( 'work-aside', $mvweb_args );
$mvweb_aside  = array_diff_key( $mvweb_aside, array( 'title' => '' ) ) ? $mvweb_aside : array();
$mvweb_main   = mvweb_core_works_layout_html( 'work-main', $mvweb_args );
$mvweb_blocks = mvweb_core_works_layout_html( 'work-blocks', $mvweb_args );
$mvweb_flow   = '';
$mvweb_text   = array();

foreach ( $mvweb_main as $mvweb_slug => $mvweb_html ) {
	if ( 'gallery' === $mvweb_slug ) {
		$mvweb_flow .= empty( $mvweb_text ) ? '' : '<div class="mvweb-t-service__text">' . implode( '', $mvweb_text ) . '</div>';
		$mvweb_flow .= $mvweb_html;
		$mvweb_text  = array();
		continue;
	}

	$mvweb_text[] = $mvweb_html;
}

$mvweb_flow .= empty( $mvweb_text ) ? '' : '<div class="mvweb-t-service__text">' . implode( '', $mvweb_text ) . '</div>';
?>

<section class="mvweb-t-service mvweb-t-work">
	<div class="mvweb-t-container">

		<?php get_template_part( 'template-parts/crumbs' ); ?>

		<div class="mvweb-t-service__layout<?php echo empty( $mvweb_aside ) ? ' mvweb-t-work__layout--solo' : ''; ?>">
			<header class="mvweb-t-service__head">
				<?php echo implode( '', $mvweb_head ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there. ?>
				<?php if ( ! mvweb_core_layout_has( 'work-head', 'title' ) ) : ?>
					<h1 class="screen-reader-text"><?php echo esc_html( '' !== mvweb_core_alt_h1() ? mvweb_core_alt_h1() : get_the_title( $mvweb_id ) ); ?></h1>
				<?php endif; ?>
			</header>

			<?php if ( ! empty( $mvweb_aside ) ) : ?>
				<aside class="mvweb-t-service__aside">
					<?php echo implode( '', $mvweb_aside ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there. ?>
				</aside>
			<?php endif; ?>

			<?php if ( '' !== $mvweb_flow ) : ?>
				<div class="mvweb-t-service__main">
					<?php echo $mvweb_flow; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there. ?>
				</div>
			<?php endif; ?>
		</div>

	</div>
</section>

<?php
echo implode( '', $mvweb_blocks ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there.

mvweb_core_render_context_sections();
