<?php
/**
 * A band of work cards under a heading.
 *
 * Shared by the page of a work (other works) and the page of a service (works
 * of the service).
 *
 * Arguments: ids (works), title, link_text and link_url (the link at the end
 * of the heading; both needed), surface (true for the tinted background).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_ids     = isset( $args['ids'] ) ? array_filter( array_map( 'absint', (array) $args['ids'] ) ) : array();
$mvweb_title   = isset( $args['title'] ) ? trim( (string) $args['title'] ) : '';
$mvweb_link    = isset( $args['link_text'] ) ? trim( (string) $args['link_text'] ) : '';
$mvweb_url     = isset( $args['link_url'] ) ? trim( (string) $args['link_url'] ) : '';
$mvweb_surface = ! empty( $args['surface'] );

if ( empty( $mvweb_ids ) ) {
	return;
}

$mvweb_more = '' !== $mvweb_link && '' !== $mvweb_url;
?>
<section class="mvweb-t-section"<?php echo $mvweb_surface ? ' data-bg="surface"' : ''; ?>>
	<div class="mvweb-t-container">
		<?php if ( '' !== $mvweb_title || $mvweb_more ) : ?>
			<div class="mvweb-t-section-head">
				<?php if ( '' !== $mvweb_title ) : ?>
					<div class="mvweb-t-section-head__text"><div class="mvweb-t-section-head__title mvweb-t-h2"><?php echo esc_html( $mvweb_title ); ?></div></div>
				<?php endif; ?>
				<?php if ( $mvweb_more ) : ?>
					<a class="mvweb-t-section-head__more" href="<?php echo esc_url( $mvweb_url ); ?>"><?php echo esc_html( $mvweb_link ); ?></a>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<div class="mvweb-t-works__grid">
			<?php foreach ( $mvweb_ids as $mvweb_id ) : ?>
				<?php get_template_part( 'template-parts/work/card', null, array( 'id' => $mvweb_id ) ); ?>
			<?php endforeach; ?>
		</div>
	</div>
</section>
