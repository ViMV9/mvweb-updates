<?php
/**
 * The portfolio listing: the head, the kinds to pick from, the cards, the text and the blocks.
 *
 * The kinds are plain links to their own addresses, not a script filter: each
 * kind is a page a visitor can land on and share. The text under the cards is
 * the second description of a kind. The blocks under the listing are the
 * ones the kind, or the page chosen for the portfolio, carries.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_term  = get_queried_object();
$mvweb_kind  = $mvweb_term instanceof WP_Term;
$mvweb_title = mvweb_core_alt_h1();

if ( '' === $mvweb_title ) {
	$mvweb_title = $mvweb_kind ? $mvweb_term->name : mvweb_core_work_label();
}

$mvweb_kinds = mvweb_core_works_kinds();
$mvweb_text  = mvweb_core_listing_text();

mvweb_theme_column_open( 'works' );

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'title' => $mvweb_title,
		'lead'  => mvweb_core_works_listing_lead(),
	)
);
?>

<section class="mvweb-t-section mvweb-t-section--flush-top">
	<div class="mvweb-t-container">

		<?php if ( ! empty( $mvweb_kinds ) ) : ?>
			<nav class="mvweb-t-chips mvweb-t-chips--scroll mvweb-t-works__kinds" aria-label="<?php esc_attr_e( 'Kinds of work', 'brand-market' ); ?>">
				<a class="mvweb-t-chip" href="<?php echo esc_url( (string) get_post_type_archive_link( 'mv_work' ) ); ?>"<?php echo $mvweb_kind ? '' : ' aria-current="page"'; ?>><?php esc_html_e( 'All', 'brand-market' ); ?></a>
				<?php foreach ( $mvweb_kinds as $mvweb_item ) : ?>
					<a class="mvweb-t-chip" href="<?php echo esc_url( (string) get_term_link( $mvweb_item ) ); ?>"<?php echo $mvweb_kind && $mvweb_term->term_id === $mvweb_item->term_id ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $mvweb_item->name ); ?></a>
				<?php endforeach; ?>
			</nav>
		<?php endif; ?>

		<?php if ( have_posts() ) : ?>

			<div class="mvweb-t-works__grid mvweb-t-works__grid--listing">
				<?php
				while ( have_posts() ) :
					the_post();

					get_template_part(
						'template-parts/work/card',
						null,
						array(
							'id'    => get_the_ID(),
							'eager' => $GLOBALS['wp_query']->current_post < 3,
						)
					);
				endwhile;
				?>
			</div>

			<?php mvweb_theme_pagination(); ?>

		<?php else : ?>

			<?php
			get_template_part(
				'template-parts/empty',
				null,
				array(
					'icon'        => 'photo',
					'title'       => __( 'No works here yet', 'brand-market' ),
					'text'        => $mvweb_kind ? __( 'Have a look at the other kinds of work.', 'brand-market' ) : '',
					'button_url'  => $mvweb_kind ? (string) get_post_type_archive_link( 'mv_work' ) : '',
					'button_text' => __( 'All works', 'brand-market' ),
				)
			);
			?>

		<?php endif; ?>

		<?php if ( '' !== $mvweb_text ) : ?>
			<div class="mvweb-t-prose mvweb-t-catalog__text mvweb-t-works__text" data-prose>
				<?php echo apply_filters( 'the_content', $mvweb_text ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The key is registered with wp_kses_post, and the_content closes with kses of its own. ?>
			</div>
		<?php endif; ?>

	</div>
</section>

<?php mvweb_theme_column_close( 'works' ); ?>

<?php
mvweb_core_render_context_sections();
