<?php
/**
 * Work card: the picture and the parts the card composition lists.
 *
 * The composition is one for the site, set in the Customizer: the number, the
 * kind, the name, the facts and the arrow, each shown or not and in its order.
 * The view decides where a part stands: the kind is a badge on the picture
 * except in the list, where it stands over the name; the arrow sits on the
 * picture in the photo view and at the end of the row in the list. A card
 * whose name is hidden keeps a link a keyboard can reach: the picture.
 *
 * Arguments: id (work), tag (heading tag of the name), eager (first screen),
 * view (grid, mosaic, reveal, ribbon or list), index (place in the block),
 * lead (the first card of the mosaic), rv (the block moves cards in).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : get_the_ID();

if ( 0 === $mvweb_id || 'publish' !== get_post_status( $mvweb_id ) ) {
	return;
}

$mvweb_views = array( 'grid', 'mosaic', 'reveal', 'ribbon', 'list' );
$mvweb_view  = isset( $args['view'] ) && in_array( $args['view'], $mvweb_views, true ) ? $args['view'] : 'grid';
$mvweb_args  = array(
	'id'    => $mvweb_id,
	'view'  => $mvweb_view,
	'index' => isset( $args['index'] ) ? absint( $args['index'] ) : -1,
	'link'  => (string) get_permalink( $mvweb_id ),
);
$mvweb_rv    = ! empty( $args['rv'] ) ? ' data-rv' : '';
$mvweb_lead  = ! empty( $args['lead'] ) && 'mosaic' === $mvweb_view;
$mvweb_order = mvweb_core_layout_order( 'card-work' );
$mvweb_html  = array();

foreach ( $mvweb_order as $mvweb_slug ) {
	ob_start();
	get_template_part( 'template-parts/card-work/' . sanitize_key( $mvweb_slug ), null, $mvweb_args );
	$mvweb_html[ $mvweb_slug ] = trim( (string) ob_get_clean() );
}

$mvweb_listed = 'list' === $mvweb_view;
$mvweb_flow   = array();
$mvweb_main   = false;

foreach ( $mvweb_order as $mvweb_slug ) {
	if ( '' === $mvweb_html[ $mvweb_slug ] || ( 'kind' === $mvweb_slug && ! $mvweb_listed ) || ( 'arrow' === $mvweb_slug && 'reveal' === $mvweb_view ) ) {
		continue;
	}

	if ( $mvweb_listed && in_array( $mvweb_slug, array( 'kind', 'title' ), true ) ) {
		if ( ! $mvweb_main ) {
			$mvweb_flow[] = 'main';
			$mvweb_main   = true;
		}

		continue;
	}

	$mvweb_flow[] = $mvweb_slug;
}

$mvweb_badge = ! $mvweb_listed && isset( $mvweb_html['kind'] ) ? $mvweb_html['kind'] : '';
$mvweb_go    = 'reveal' === $mvweb_view && isset( $mvweb_html['arrow'] ) ? $mvweb_html['arrow'] : '';
$mvweb_named = isset( $mvweb_html['title'] ) && '' !== $mvweb_html['title'];
?>
<article class="mvweb-t-card mvweb-t-works__card<?php echo $mvweb_lead ? ' mvweb-t-works__card--lead' : ''; ?>"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
	<a class="mvweb-t-card__media mvweb-t-works__media" href="<?php echo esc_url( $mvweb_args['link'] ); ?>"<?php echo $mvweb_named ? ' tabindex="-1" aria-hidden="true"' : ' aria-label="' . esc_attr( get_the_title( $mvweb_id ) ) . '"'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in place. ?>>
		<?php
		echo mvweb_core_item_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core's escaped image markup.
			$mvweb_id,
			'mvweb_card',
			array(
				'alt'      => '',
				'loading'  => empty( $args['eager'] ) ? 'lazy' : false,
				'decoding' => 'async',
			)
		);
		echo $mvweb_badge . $mvweb_go; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there.
		?>
	</a>
	<?php if ( ! empty( $mvweb_flow ) ) : ?>
		<div class="mvweb-t-card__body">
			<?php foreach ( $mvweb_flow as $mvweb_slug ) : ?>
				<?php if ( 'main' === $mvweb_slug ) : ?>
					<div class="mvweb-t-works__main">
						<?php foreach ( array_intersect( $mvweb_order, array( 'kind', 'title' ) ) as $mvweb_inner ) : ?>
							<?php echo $mvweb_html[ $mvweb_inner ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there. ?>
						<?php endforeach; ?>
					</div>
				<?php else : ?>
					<?php echo $mvweb_html[ $mvweb_slug ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there. ?>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</article>
