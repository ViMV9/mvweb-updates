<?php
/**
 * The comparison of one category: the bar with its tools and the table.
 *
 * Returned by the route of the comparison and put on the page by the script.
 * Fewer than two items of a category are not a comparison, and the empty
 * state says so.
 *
 * Arguments: model (result of mvweb_core_compare_model()).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_model = isset( $args['model'] ) && is_array( $args['model'] ) ? $args['model'] : array();
$mvweb_items = isset( $mvweb_model['items'] ) ? (array) $mvweb_model['items'] : array();

if ( empty( $mvweb_model ) ) {
	return;
}

ob_start();
mvweb_core_render_layout( 'compare-bar', array_merge( $args, array( 'place' => 'bar' ) ) );
$mvweb_bar = trim( ob_get_clean() );
?>
<div class="mvweb-t-cmp" data-cmp>
	<?php if ( '' !== $mvweb_bar ) : ?>
		<div class="mvweb-t-cmp__bar">
			<?php echo $mvweb_bar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the parts above, every value escaped there. ?>
		</div>
	<?php endif; ?>

	<?php if ( count( $mvweb_items ) < 2 ) : ?>
		<?php get_template_part( 'template-parts/compare/empty' ); ?>
	<?php else : ?>
		<div class="mvweb-t-cmp__scroll" role="region" tabindex="0" aria-label="<?php esc_attr_e( 'Comparison table, scrolls sideways', 'brand-market' ); ?>">
			<table class="mvweb-t-cmp__table">
				<caption class="screen-reader-text"><?php esc_html_e( 'Comparison of items', 'brand-market' ); ?></caption>
				<thead>
					<tr>
						<td class="mvweb-t-cmp__corner"></td>
						<?php
						foreach ( $mvweb_items as $mvweb_id ) {
							get_template_part( 'template-parts/compare/head', null, array( 'id' => $mvweb_id ) );
						}
						?>
					</tr>
				</thead>
				<tbody>
					<?php mvweb_core_render_layout( 'compare-rows', $args ); ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</div>
