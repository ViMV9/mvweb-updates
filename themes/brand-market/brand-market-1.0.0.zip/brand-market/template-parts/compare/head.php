<?php
/**
 * Comparison: the head of the column of one item.
 *
 * Arguments: id.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : 0;

if ( 0 === $mvweb_id ) {
	return;
}

$mvweb_link  = (string) get_permalink( $mvweb_id );
$mvweb_brand = mvweb_core_item_brand( $mvweb_id );
$mvweb_value = mvweb_core_item_price_html( $mvweb_id );
$mvweb_old   = '';

if ( false !== strpos( $mvweb_value, '<ins' ) && preg_match( '~<del[^>]*>(.*?)</del>~s', $mvweb_value, $mvweb_del ) && preg_match( '~<ins[^>]*>(.*?)</ins>~s', $mvweb_value, $mvweb_ins ) ) {
	$mvweb_old   = $mvweb_del[1];
	$mvweb_value = $mvweb_ins[1];
}

$mvweb_asking  = ! mvweb_core_shop_mode();
$mvweb_request = '' === trim( wp_strip_all_tags( $mvweb_value ) );

if ( $mvweb_asking ) {
	$mvweb_old = '';
}
?>
<th scope="col" class="mvweb-t-cmp__prod">
	<button class="mvweb-t-cmp__remove" type="button" data-compare-remove="<?php echo (int) $mvweb_id; ?>" title="<?php esc_attr_e( 'Remove from comparison', 'brand-market' ); ?>">
		<?php echo mvweb_theme_icon( 'close', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<span class="screen-reader-text">
			<?php
			/* translators: %s: name of the item. */
			echo esc_html( sprintf( __( 'Remove from comparison: %s', 'brand-market' ), get_the_title( $mvweb_id ) ) );
			?>
		</span>
	</button>
	<a class="mvweb-t-cmp__media" href="<?php echo esc_url( $mvweb_link ); ?>" tabindex="-1" aria-hidden="true">
		<?php
		echo mvweb_core_item_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core's escaped image markup.
			$mvweb_id,
			'mvweb_card',
			array(
				'loading'  => 'lazy',
				'decoding' => 'async',
			)
		);
		?>
	</a>
	<?php if ( $mvweb_brand ) : ?>
		<span class="mvweb-t-card__brand"><?php echo esc_html( $mvweb_brand ); ?></span>
	<?php endif; ?>
	<a class="mvweb-t-cmp__name" href="<?php echo esc_url( $mvweb_link ); ?>"><?php echo esc_html( get_the_title( $mvweb_id ) ); ?></a>
	<?php if ( ! $mvweb_request || '' !== mvweb_core_price_placeholder() ) : ?>
		<span class="mvweb-t-cmp__price">
			<strong>
				<?php
				if ( $mvweb_request ) {
					echo esc_html( mvweb_core_price_placeholder() );
				} else {
					echo $mvweb_asking ? esc_html__( 'from', 'brand-market' ) . ' ' : '';
					echo wp_kses_post( $mvweb_value );
				}
				?>
			</strong>
			<?php if ( '' !== $mvweb_old ) : ?>
				<span class="mvweb-t-price__old"><?php echo wp_kses_post( $mvweb_old ); ?></span>
			<?php endif; ?>
		</span>
	<?php endif; ?>
	<?php get_template_part( 'template-parts/compare/buy', null, array( 'id' => $mvweb_id ) ); ?>
</th>
