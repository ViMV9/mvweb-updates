<?php
/**
 * Comparison: the button under an item, to the cart in a shop and to the request in a showcase.
 *
 * Arguments: id.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : 0;

if ( 0 === $mvweb_id ) {
	return;
}

$mvweb_product = mvweb_core_shop_mode() ? mvweb_core_wc_item( $mvweb_id ) : null;
$mvweb_class   = 'mvweb-t-btn mvweb-t-btn--sm mvweb-t-btn--block';
$mvweb_attrs   = '';
$mvweb_icon    = '';

if ( $mvweb_product ) {
	$mvweb_ready = $mvweb_product->is_purchasable() && $mvweb_product->is_in_stock();
	$mvweb_data  = array(
		'href'            => $mvweb_product->add_to_cart_url(),
		'rel'             => 'nofollow',
		'data-product_id' => $mvweb_product->get_id(),
		'aria-label'      => wp_strip_all_tags( $mvweb_product->add_to_cart_description() ),
		'class'           => $mvweb_class . ' product_type_' . $mvweb_product->get_type() . ( $mvweb_ready ? ' add_to_cart_button' : '' ) . ( $mvweb_ready && $mvweb_product->supports( 'ajax_add_to_cart' ) ? ' ajax_add_to_cart' : '' ),
	);

	if ( $mvweb_ready ) {
		$mvweb_data['data-quantity']    = mvweb_core_quantity_rules( $mvweb_id )['min'];
		$mvweb_data['data-product_sku'] = $mvweb_product->get_sku();
	}

	foreach ( $mvweb_data as $mvweb_key => $mvweb_value ) {
		$mvweb_attrs .= ' ' . $mvweb_key . '="' . esc_attr( (string) $mvweb_value ) . '"';
	}

	$mvweb_label = wp_strip_all_tags( $mvweb_product->add_to_cart_text() );
	$mvweb_icon  = 'shopping-cart';

	if ( $mvweb_product->is_type( 'variable' ) ? ! $mvweb_product->is_purchasable() : ! $mvweb_ready && $mvweb_product->is_type( 'simple' ) ) {
		?>
		<button class="<?php echo esc_attr( $mvweb_class ); ?>" type="button" aria-disabled="true">
			<?php echo mvweb_theme_icon( 'ban', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<?php echo esc_html( wp_strip_all_tags( $mvweb_product->single_add_to_cart_text() ) ); ?>
		</button>
		<?php
		return;
	}
} else {
	$mvweb_url   = (string) get_theme_mod( 'mvweb_cta_url', '' );
	$mvweb_label = (string) get_theme_mod( 'mvweb_cta_text', __( 'Request a quote', 'brand-market' ) );

	if ( '' === $mvweb_url || '' === $mvweb_label ) {
		return;
	}

	$mvweb_attrs = ' class="' . esc_attr( $mvweb_class ) . '" href="' . esc_url( $mvweb_url ) . '" data-request="' . esc_attr( get_the_title( $mvweb_id ) ) . '"';
	$mvweb_icon  = 'messages';
}
?>
<a<?php echo $mvweb_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Every value is escaped above. ?>>
	<?php echo mvweb_theme_icon( $mvweb_icon, array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<?php echo esc_html( $mvweb_label ); ?>
</a>
