<?php
/**
 * Comparison: the state with nothing to compare yet.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part(
	'template-parts/empty',
	null,
	array(
		'icon'        => 'arrows-left-right',
		'title'       => __( 'Add items to compare', 'brand-market' ),
		'text'        => __( 'To compare you need at least two items of one category. Press the compare icon on the card of an item.', 'brand-market' ),
		'button_url'  => mvweb_core_catalog_page_url(),
		'button_text' => __( 'To the catalog', 'brand-market' ),
	)
);
