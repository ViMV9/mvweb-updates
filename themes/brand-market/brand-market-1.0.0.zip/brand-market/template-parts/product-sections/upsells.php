<?php
/**
 * Sections under the item: the goods the owner linked as bought together.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : 0;

if ( 0 === $mvweb_id || ! mvweb_core_product_section_filled( $mvweb_id, 'upsells' ) ) {
	return;
}

$mvweb_odd = isset( $args['state'] ) ? (int) $args['state']['n'] % 2 : 0;

if ( isset( $args['state'] ) ) {
	$args['state']['n'] = (int) $args['state']['n'] + 1;
}

$mvweb_title = mvweb_core_product_section_title( 'upsells' );
?>
<section class="mvweb-t-section mvweb-t-related" id="upsells"<?php echo $mvweb_odd ? ' data-bg="surface"' : ''; ?>>
	<div class="mvweb-t-container">
		<?php if ( '' !== $mvweb_title ) : ?>
			<div class="mvweb-t-section-head">
				<div class="mvweb-t-section-head__text">
					<div class="mvweb-t-section-head__title mvweb-t-related__title mvweb-t-h2"><?php echo esc_html( $mvweb_title ); ?></div>
				</div>
			</div>
		<?php endif; ?>
		<div class="mvweb-t-grid mvweb-t-catalog__grid">
			<?php foreach ( mvweb_core_item_upsell_ids( $mvweb_id ) as $mvweb_item ) : ?>
				<?php
				get_template_part(
					'template-parts/catalog/card',
					null,
					array(
						'id' => $mvweb_item,
					)
				);
				?>
			<?php endforeach; ?>
		</div>
	</div>
</section>
