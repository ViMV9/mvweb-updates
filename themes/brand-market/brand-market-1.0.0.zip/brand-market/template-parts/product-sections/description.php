<?php
/**
 * Sections under the item: the description and the help card beside it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : 0;

if ( 0 === $mvweb_id || ! mvweb_core_product_section_filled( $mvweb_id, 'description' ) ) {
	return;
}

$mvweb_odd = isset( $args['state'] ) ? (int) $args['state']['n'] % 2 : 0;

if ( isset( $args['state'] ) ) {
	$args['state']['n'] = (int) $args['state']['n'] + 1;
}

$mvweb_help = mvweb_core_product_help();
?>
<section class="mvweb-t-section mvweb-t-product-body" id="description"<?php echo $mvweb_odd ? ' data-bg="surface"' : ''; ?>>
	<div class="mvweb-t-container mvweb-t-product-body__grid">
		<div class="mvweb-t-prose mvweb-t-product-content" data-prose>
			<?php echo mvweb_core_item_content( $mvweb_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Passed through the_content, which closes with kses for an author without unfiltered_html. ?>
		</div>
		<?php if ( ! empty( $mvweb_help ) ) : ?>
			<aside class="mvweb-t-product-note-card">
				<p class="mvweb-t-product-note-card__title"><?php echo esc_html( $mvweb_help['title'] ); ?></p>
				<?php if ( '' !== $mvweb_help['text'] ) : ?>
					<p class="mvweb-t-product-note-card__text"><?php echo esc_html( $mvweb_help['text'] ); ?></p>
				<?php endif; ?>
				<?php if ( '' !== $mvweb_help['button'] && '' !== $mvweb_help['url'] ) : ?>
					<a class="mvweb-t-btn mvweb-t-btn--dark mvweb-t-btn--block" href="<?php echo esc_url( $mvweb_help['url'] ); ?>" data-request="<?php echo esc_attr( get_the_title( $mvweb_id ) ); ?>"><?php echo esc_html( $mvweb_help['button'] ); ?></a>
				<?php endif; ?>
			</aside>
		<?php endif; ?>
	</div>
</section>
