<?php
/**
 * Sections under the item: the specifications.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : 0;

if ( 0 === $mvweb_id || ! mvweb_core_product_section_filled( $mvweb_id, 'specs' ) ) {
	return;
}

$mvweb_odd = isset( $args['state'] ) ? (int) $args['state']['n'] % 2 : 0;

if ( isset( $args['state'] ) ) {
	$args['state']['n'] = (int) $args['state']['n'] + 1;
}

$mvweb_markup = mvweb_core_item_specs_markup( $mvweb_id );
$mvweb_rows   = '' === $mvweb_markup ? mvweb_core_item_specs( $mvweb_id ) : array();
$mvweb_title  = mvweb_core_product_section_title( 'specs' );
$mvweb_note   = trim( (string) get_theme_mod( 'mvweb_product_note', '' ) );
?>
<section class="mvweb-t-section mvweb-t-product-specs" id="specs"<?php echo $mvweb_odd ? ' data-bg="surface"' : ''; ?>>
	<div class="mvweb-t-container">
		<?php if ( '' !== $mvweb_title ) : ?>
			<div class="mvweb-t-section-head">
				<div class="mvweb-t-section-head__text">
					<div class="mvweb-t-section-head__title mvweb-t-product-specs__title mvweb-t-h2"><?php echo esc_html( $mvweb_title ); ?></div>
				</div>
			</div>
		<?php endif; ?>

		<?php if ( '' !== $mvweb_markup ) : ?>
			<?php echo $mvweb_markup; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The WooCommerce specification list, printed by the template of the theme. ?>
		<?php else : ?>
			<dl class="mvweb-t-specs">
				<?php foreach ( $mvweb_rows as $mvweb_row ) : ?>
					<div class="mvweb-t-specs__row">
						<dt class="mvweb-t-specs__label"><?php echo esc_html( $mvweb_row['label'] ); ?></dt>
						<dd class="mvweb-t-specs__value"><?php echo esc_html( $mvweb_row['value'] ); ?></dd>
					</div>
				<?php endforeach; ?>
			</dl>
		<?php endif; ?>

		<?php if ( '' !== $mvweb_note ) : ?>
			<p class="mvweb-t-specs__note"><?php echo esc_html( $mvweb_note ); ?></p>
		<?php endif; ?>
	</div>
</section>
