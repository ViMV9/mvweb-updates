<?php
/**
 * Sections under the item: the reviews of a product, their summary and the form.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : 0;

if ( 0 === $mvweb_id || ! mvweb_core_product_section_filled( $mvweb_id, 'reviews' ) ) {
	return;
}

$mvweb_odd = isset( $args['state'] ) ? (int) $args['state']['n'] % 2 : 0;

if ( isset( $args['state'] ) ) {
	$args['state']['n'] = (int) $args['state']['n'] + 1;
}

$mvweb_title   = mvweb_core_product_section_title( 'reviews' );
$mvweb_rating  = mvweb_core_item_rating( $mvweb_id );
$mvweb_counts  = mvweb_core_item_rating_counts( $mvweb_id );
$mvweb_reviews = mvweb_core_item_reviews( $mvweb_id );
$mvweb_open    = mvweb_core_item_reviews_open( $mvweb_id );
$mvweb_total   = array_sum( $mvweb_counts );
$mvweb_product = mvweb_core_wc_item( $mvweb_id );
$mvweb_stars   = function_exists( 'wc_review_ratings_enabled' ) && wc_review_ratings_enabled();
$mvweb_bought  = 'yes' === get_option( 'woocommerce_review_rating_verification_required' ) && ! wc_customer_bought_product( '', get_current_user_id(), $mvweb_id );
?>
<section class="mvweb-t-section mvweb-t-product-reviews" id="reviews"<?php echo $mvweb_odd ? ' data-bg="surface"' : ''; ?>>
	<div class="mvweb-t-container">
		<?php if ( '' !== $mvweb_title ) : ?>
			<div class="mvweb-t-section-head">
				<div class="mvweb-t-section-head__text">
					<div class="mvweb-t-section-head__title mvweb-t-h2"><?php echo esc_html( $mvweb_title ); ?></div>
				</div>
			</div>
		<?php endif; ?>

		<div class="mvweb-t-product-reviews__grid">
			<?php if ( ! empty( $mvweb_rating ) && $mvweb_total > 0 ) : ?>
				<div class="mvweb-t-rate-summary">
					<p class="mvweb-t-rate-summary__score">
						<?php echo esc_html( number_format_i18n( $mvweb_rating['value'], 1 ) ); ?>
						<span class="mvweb-t-rate-summary__of"><?php esc_html_e( 'out of 5', 'brand-market' ); ?></span>
					</p>
					<p class="mvweb-t-rate-summary__count">
						<?php
						/* translators: %s: number of reviews. */
						echo esc_html( sprintf( _n( '%s review', '%s reviews', $mvweb_rating['count'], 'brand-market' ), number_format_i18n( $mvweb_rating['count'] ) ) );
						?>
					</p>
					<ul class="mvweb-t-rate-summary__bars">
						<?php foreach ( $mvweb_counts as $mvweb_star => $mvweb_number ) : ?>
							<li>
								<span><?php echo (int) $mvweb_star; ?></span>
								<span class="mvweb-t-rate-summary__bar"><i style="<?php echo esc_attr( 'width:' . round( $mvweb_number / $mvweb_total * 100 ) . '%' ); ?>"></i></span>
								<span><?php echo (int) $mvweb_number; ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $mvweb_reviews ) ) : ?>
				<div class="mvweb-t-review-list">
					<?php foreach ( $mvweb_reviews as $mvweb_review ) : ?>
						<article class="mvweb-t-review">
							<div class="mvweb-t-review__head">
								<span class="mvweb-t-review__avatar" aria-hidden="true"><?php echo esc_html( $mvweb_review['initial'] ); ?></span>
								<div>
									<p class="mvweb-t-review__name"><?php echo esc_html( $mvweb_review['name'] ); ?></p>
									<p class="mvweb-t-review__date">
										<?php
										echo esc_html( $mvweb_review['date'] );

										if ( $mvweb_review['verified'] ) {
											echo esc_html( ' · ' . __( 'Purchase confirmed', 'brand-market' ) );
										}
										?>
									</p>
								</div>
								<?php if ( $mvweb_review['rating'] > 0 ) : ?>
									<span class="mvweb-t-rating">
										<?php echo mvweb_theme_icon( 'star-filled', array( 'class' => 'mvweb-t-icon--fill' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
										<?php echo (int) $mvweb_review['rating']; ?>
									</span>
								<?php endif; ?>
							</div>
							<p class="mvweb-t-review__text"><?php echo wp_kses( nl2br( esc_html( $mvweb_review['text'] ) ), array( 'br' => array() ) ); ?></p>
						</article>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( $mvweb_open && $mvweb_bought ) : ?>
				<p class="mvweb-t-review-form__note"><?php esc_html_e( 'Only customers who have bought this product can leave a review.', 'brand-market' ); ?></p>
			<?php elseif ( $mvweb_open ) : ?>
				<?php
				$mvweb_commenter = wp_get_current_commenter();
				$mvweb_field     = static function ( $name, $label, $type, $value, $autocomplete ) {
					return '<div class="mvweb-t-field"><label class="mvweb-t-field__label" for="' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label><input class="mvweb-t-field__input" id="' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" type="' . esc_attr( $type ) . '" value="' . esc_attr( $value ) . '" autocomplete="' . esc_attr( $autocomplete ) . '" required></div>';
				};
				$mvweb_rate      = '<p class="mvweb-t-review-form__title">' . esc_html__( 'Leave a review', 'brand-market' ) . '</p>';

	if ( $mvweb_stars ) {
		$mvweb_rate .= '<fieldset class="mvweb-t-review-form__stars"><legend class="mvweb-t-field__label">' . esc_html__( 'Your rating', 'brand-market' ) . '</legend><div class="mvweb-t-stars-input">';

		for ( $mvweb_star = 5; $mvweb_star >= 1; $mvweb_star-- ) {
			$mvweb_rate .= '<input type="radio" id="mvweb-star-' . $mvweb_star . '" name="rating" value="' . $mvweb_star . '"' . ( wc_review_ratings_required() ? ' required' : '' ) . '><label for="mvweb-star-' . $mvweb_star . '" title="' . $mvweb_star . '">' . mvweb_theme_icon( 'star-filled' ) . '<span class="screen-reader-text">' . $mvweb_star . '</span></label>';
		}

		$mvweb_rate .= '</div></fieldset>';
	}

				$mvweb_before = static function () {
					echo '<div class="mvweb-t-review-form__row">';
				};
				$mvweb_after  = static function () {
					echo '</div>';
				};

				$mvweb_clean = static function ( $fields ) {
					unset( $fields['cookies'], $fields['url'] );

					return $fields;
				};

				add_filter( 'comment_form_fields', $mvweb_clean );
				add_action( 'comment_form_before_fields', $mvweb_before );
				add_action( 'comment_form_after_fields', $mvweb_after );

				comment_form(
					array(
						'class_form'           => 'mvweb-t-review-form',
						'title_reply'          => '',
						'title_reply_before'   => '',
						'title_reply_after'    => '',
						'cancel_reply_before'  => '',
						'cancel_reply_after'   => '',
						'comment_notes_before' => '',
						'comment_notes_after'  => '',
						'logged_in_as'         => '',
						'must_log_in'          => '<p class="mvweb-t-review-form__note">' . esc_html__( 'Log in to leave a review.', 'brand-market' ) . '</p>',
						'label_submit'         => __( 'Send the review', 'brand-market' ),
						'submit_button'        => '<button name="%1$s" type="submit" id="%2$s" class="%3$s">%4$s</button>',
						'class_submit'         => 'mvweb-t-btn',
						'submit_field'         => '%1$s %2$s',
						'comment_field'        => $mvweb_rate . '<div class="mvweb-t-field"><label class="mvweb-t-field__label" for="comment">' . esc_html__( 'Review', 'brand-market' ) . '</label><textarea class="mvweb-t-field__input" id="comment" name="comment" rows="4" required></textarea></div>',
						'fields'               => array(
							'author' => $mvweb_field( 'author', __( 'Your name', 'brand-market' ), 'text', $mvweb_commenter['comment_author'], 'name' ),
							'email'  => $mvweb_field( 'email', __( 'Email', 'brand-market' ), 'email', $mvweb_commenter['comment_author_email'], 'email' ),
						),
					),
					$mvweb_id
				);

				remove_filter( 'comment_form_fields', $mvweb_clean );
				remove_action( 'comment_form_before_fields', $mvweb_before );
				remove_action( 'comment_form_after_fields', $mvweb_after );
				?>
			<?php endif; ?>
		</div>
	</div>
</section>
