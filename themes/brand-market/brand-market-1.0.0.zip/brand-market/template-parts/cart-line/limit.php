<?php
/**
 * Cart line, part: the smallest quantity and the step the good is ordered in.
 *
 * It stands under the quantity field, not with the information of the good.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( isset( $args['cell'] ) && 'limit' !== $args['cell'] ) {
	return;
}

$mvweb_id    = isset( $args['id'] ) ? absint( $args['id'] ) : 0;
$mvweb_rules = mvweb_core_quantity_rules( $mvweb_id );
$mvweb_unit  = trim( mvweb_core_qty_unit( $mvweb_id ) );
$mvweb_unit  = '' !== $mvweb_unit ? $mvweb_unit : __( 'pc', 'brand-market' );

if ( $mvweb_rules['step'] > 1 ) {
	/* translators: 1: smallest quantity, 2: unit, 3: step. */
	$mvweb_text = sprintf( __( 'Minimum %1$d %2$s, step %3$d', 'brand-market' ), $mvweb_rules['min'], $mvweb_unit, $mvweb_rules['step'] );
} else {
	/* translators: 1: smallest quantity, 2: unit. */
	$mvweb_text = sprintf( __( 'Minimum %1$d %2$s', 'brand-market' ), $mvweb_rules['min'], $mvweb_unit );
}
?>
<span class="mvweb-t-cline__limit"><?php echo esc_html( $mvweb_text ); ?></span>
