<?php
/**
 * Cart line, part: how far the wholesale price is, or how much it saves.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_product = isset( $args['product'] ) ? $args['product'] : null;
$mvweb_id      = isset( $args['id'] ) ? absint( $args['id'] ) : 0;
$mvweb_qty     = isset( $args['qty'] ) ? (int) $args['qty'] : 1;

if ( ! $mvweb_product instanceof WC_Product || $mvweb_id < 1 ) {
	return;
}

$mvweb_unit = trim( mvweb_core_qty_unit( $mvweb_id ) );
$mvweb_unit = '' !== $mvweb_unit ? $mvweb_unit : __( 'pc', 'brand-market' );
$mvweb_next = mvweb_core_next_tier( $mvweb_id, $mvweb_qty );
$mvweb_text = '';

if ( ! empty( $mvweb_next ) ) {
	/* translators: 1: pieces to add, 2: their unit, 3: the wholesale price. */
	$mvweb_text = sprintf( __( '%1$d %2$s more to the wholesale price %3$s', 'brand-market' ), $mvweb_next['left'], $mvweb_unit, mvweb_core_cart_money( (float) $mvweb_next['amount'] ) );
} elseif ( '' !== mvweb_core_tier_amount( $mvweb_id, $mvweb_qty ) ) {
	$mvweb_base   = wc_get_product( $mvweb_id );
	$mvweb_retail = $mvweb_base ? (float) wc_get_price_to_display( $mvweb_base ) : 0.0;
	$mvweb_save   = ( $mvweb_retail - (float) wc_get_price_to_display( $mvweb_product ) ) * $mvweb_qty;

	if ( $mvweb_save > 0 ) {
		/* translators: 1: the retail price, 2: the saving on the line. */
		$mvweb_text = sprintf( __( 'Retail price %1$s, you save %2$s', 'brand-market' ), mvweb_core_cart_money( $mvweb_retail ), mvweb_core_cart_money( $mvweb_save ) );
	}
}

if ( '' === $mvweb_text ) {
	return;
}
?>
<p class="mvweb-t-cline__hint"><?php echo esc_html( $mvweb_text ); ?></p>
