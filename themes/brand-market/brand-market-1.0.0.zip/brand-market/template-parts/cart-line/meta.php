<?php
/**
 * Cart line, part: the article and the availability.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_product = isset( $args['product'] ) ? $args['product'] : null;
$mvweb_id      = isset( $args['id'] ) ? absint( $args['id'] ) : 0;

if ( ! $mvweb_product instanceof WC_Product ) {
	return;
}

$mvweb_sku   = (string) $mvweb_product->get_sku();
$mvweb_stock = mvweb_core_item_stock( $mvweb_id );
$mvweb_icons = array(
	'instock'     => 'check',
	'onbackorder' => 'clock',
	'outofstock'  => 'close',
);

if ( '' === $mvweb_sku && empty( $mvweb_stock['label'] ) ) {
	return;
}
?>
<p class="mvweb-t-cline__meta">
	<?php if ( '' !== $mvweb_sku ) : ?>
		<span>
			<?php
			/* translators: %s: article number of an item. */
			echo esc_html( sprintf( __( 'Art. %s', 'brand-market' ), $mvweb_sku ) );
			?>
		</span>
	<?php endif; ?>
	<?php if ( ! empty( $mvweb_stock['label'] ) ) : ?>
		<span class="mvweb-t-cline__stock">
			<?php echo mvweb_theme_icon( isset( $mvweb_icons[ $mvweb_stock['status'] ] ) ? $mvweb_icons[ $mvweb_stock['status'] ] : 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<?php echo esc_html( $mvweb_stock['label'] ); ?>
		</span>
	<?php endif; ?>
</p>
