<?php
/**
 * Cart line, part: the price of one piece, the old price and the mark of the wholesale price.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_product = isset( $args['product'] ) ? $args['product'] : null;
$mvweb_item    = isset( $args['item'] ) && is_array( $args['item'] ) ? $args['item'] : array();
$mvweb_key     = isset( $args['key'] ) ? (string) $args['key'] : '';
$mvweb_id      = isset( $args['id'] ) ? absint( $args['id'] ) : 0;
$mvweb_qty     = isset( $args['qty'] ) ? (int) $args['qty'] : 1;

if ( ! $mvweb_product instanceof WC_Product ) {
	return;
}

$mvweb_tier = '' !== mvweb_core_tier_amount( $mvweb_id, $mvweb_qty );
$mvweb_old  = ! $mvweb_tier && $mvweb_product->is_on_sale() && '' !== (string) $mvweb_product->get_regular_price() ? wc_get_price_to_display( $mvweb_product, array( 'price' => $mvweb_product->get_regular_price() ) ) : 0;
$mvweb_unit = trim( mvweb_core_qty_unit( $mvweb_id ) );
?>
<p class="mvweb-t-cline__price">
	<span class="mvweb-t-cline__unit"><?php echo apply_filters( 'woocommerce_cart_item_price', WC()->cart->get_product_price( $mvweb_product ), $mvweb_item, $mvweb_key ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WooCommerce price markup. ?></span>
	<?php if ( $mvweb_old > 0 ) : ?>
		<span class="mvweb-t-price__old"><?php echo wp_kses_post( wc_price( $mvweb_old ) ); ?></span>
	<?php endif; ?>
	<?php if ( $mvweb_tier ) : ?>
		<span class="mvweb-t-badge mvweb-t-badge--accent"><?php echo esc_html( mvweb_core_wholesale_label() ); ?></span>
	<?php endif; ?>
	<span class="mvweb-t-cline__per">
		<?php
		/* translators: %s: unit of the good: pcs, packs, sets. */
		echo esc_html( sprintf( __( 'per %s', 'brand-market' ), '' !== $mvweb_unit ? $mvweb_unit : __( 'pc', 'brand-market' ) ) );
		?>
	</span>
</p>
