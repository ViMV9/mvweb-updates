<?php
/**
 * Cart line, part: the name of the good and what sets the variation apart.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_name = isset( $args['name'] ) ? (string) $args['name'] : '';
$mvweb_link = isset( $args['link'] ) ? (string) $args['link'] : '';
$mvweb_item = isset( $args['item'] ) && is_array( $args['item'] ) ? $args['item'] : array();
$mvweb_key  = isset( $args['key'] ) ? (string) $args['key'] : '';
?>
<p class="mvweb-t-cline__title">
	<?php if ( '' !== $mvweb_link ) : ?>
		<a href="<?php echo esc_url( $mvweb_link ); ?>"><?php echo wp_kses_post( $mvweb_name ); ?></a>
	<?php else : ?>
		<?php echo wp_kses_post( $mvweb_name ); ?>
	<?php endif; ?>
</p>
<?php
do_action( 'woocommerce_after_cart_item_name', $mvweb_item, $mvweb_key );

echo wc_get_formatted_cart_item_data( $mvweb_item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by WooCommerce.
