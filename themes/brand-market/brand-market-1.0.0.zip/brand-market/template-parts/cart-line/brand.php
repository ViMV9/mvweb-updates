<?php
/**
 * Cart line, part: the brand.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_brand = isset( $args['id'] ) ? mvweb_core_item_brand( absint( $args['id'] ) ) : '';

if ( '' === $mvweb_brand ) {
	return;
}
?>
<span class="mvweb-t-card__brand"><?php echo esc_html( $mvweb_brand ); ?></span>
