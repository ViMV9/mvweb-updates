<?php
/**
 * Sidebar part: the price range.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! get_theme_mod( 'mvweb_filter_price', true ) ) {
	return;
}

$mvweb_min  = mvweb_core_catalog_price_bound( 'min_price' );
$mvweb_max  = mvweb_core_catalog_price_bound( 'max_price' );
$mvweb_sign = mvweb_core_listing_currency();
$mvweb_open = '' !== $mvweb_min || '' !== $mvweb_max;

if ( isset( $args['state'] ) && $args['state'] instanceof ArrayObject ) {
	$mvweb_open = $mvweb_open || $args['state']['open'] < absint( get_theme_mod( 'mvweb_filter_open', 3 ) );

	$args['state']['open'] = $args['state']['open'] + 1;
}
?>
<details class="mvweb-t-filters__group"<?php echo $mvweb_open ? ' open' : ''; ?>>
	<summary class="mvweb-t-filters__legend">
		<?php
		if ( '' === $mvweb_sign ) {
			esc_html_e( 'Price', 'brand-market' );
		} else {
			/* translators: %s: currency sign. */
			echo esc_html( sprintf( __( 'Price, %s', 'brand-market' ), $mvweb_sign ) );
		}
		?>
		<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	</summary>

	<div class="mvweb-t-filters__range">
		<label class="mvweb-t-filters__field">
			<span><?php esc_html_e( 'From', 'brand-market' ); ?></span>
			<input class="mvweb-t-filters__input" type="text" inputmode="numeric" name="min_price" value="<?php echo esc_attr( $mvweb_min ); ?>" placeholder="0">
		</label>
		<label class="mvweb-t-filters__field">
			<span><?php esc_html_e( 'To', 'brand-market' ); ?></span>
			<input class="mvweb-t-filters__input" type="text" inputmode="numeric" name="max_price" value="<?php echo esc_attr( $mvweb_max ); ?>" placeholder="0">
		</label>
	</div>
</details>
