<?php
/**
 * Sidebar part: the sections inside the catalogue or the category, with the number of items.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! get_theme_mod( 'mvweb_filter_subcategories', true ) ) {
	return;
}

$mvweb_group = mvweb_core_catalog_subcategories();

if ( null === $mvweb_group ) {
	return;
}

$mvweb_group['label'] = __( 'Section', 'brand-market' );

get_template_part(
	'template-parts/catalog-filters/group',
	null,
	array(
		'group' => $mvweb_group,
		'state' => isset( $args['state'] ) ? $args['state'] : null,
	)
);
