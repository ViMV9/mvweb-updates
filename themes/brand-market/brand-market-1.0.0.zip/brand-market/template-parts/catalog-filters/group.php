<?php
/**
 * One group of the sidebar: a legend and the values to tick.
 *
 * Not a part of the composition, the parts of the sidebar call it for every
 * group they own. A group folds; it stays open while a value of it is chosen,
 * and the values beyond the first few fold into “Show all”.
 *
 * Arguments: group (slug, label, terms, selected, counts, part), state (open
 * groups counted so far).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_group = isset( $args['group'] ) && is_array( $args['group'] ) ? $args['group'] : array();

if ( empty( $mvweb_group['terms'] ) ) {
	return;
}

$mvweb_counts   = mvweb_core_listing_group_counts( $mvweb_group );
$mvweb_selected = (array) $mvweb_group['selected'];
$mvweb_terms    = array();

foreach ( $mvweb_group['terms'] as $mvweb_term ) {
	if ( isset( $mvweb_counts[ $mvweb_term->slug ] ) && 0 === (int) $mvweb_counts[ $mvweb_term->slug ] && ! in_array( $mvweb_term->slug, $mvweb_selected, true ) ) {
		continue;
	}

	$mvweb_terms[] = $mvweb_term;
}

if ( empty( $mvweb_terms ) ) {
	return;
}

$mvweb_join = 'or';
$mvweb_open = ! empty( $mvweb_selected );

if ( isset( $args['state'] ) && $args['state'] instanceof ArrayObject ) {
	$mvweb_open = $mvweb_open || $args['state']['open'] < absint( get_theme_mod( 'mvweb_filter_open', 3 ) );

	$args['state']['open'] = $args['state']['open'] + 1;
}

$mvweb_visible = absint( get_theme_mod( 'mvweb_filter_visible', 6 ) );
$mvweb_head    = $mvweb_terms;
$mvweb_rest    = array();

if ( $mvweb_visible > 0 && count( $mvweb_terms ) > $mvweb_visible ) {
	$mvweb_head = array_slice( $mvweb_terms, 0, $mvweb_visible );
	$mvweb_rest = array_slice( $mvweb_terms, $mvweb_visible );
}

$mvweb_rest_open = false;

foreach ( $mvweb_rest as $mvweb_term ) {
	$mvweb_rest_open = $mvweb_rest_open || in_array( $mvweb_term->slug, $mvweb_selected, true );
}

$mvweb_option = static function ( $mvweb_term ) use ( $mvweb_group, $mvweb_counts, $mvweb_selected ) {
	$mvweb_landing = mvweb_core_listing_value_url( $mvweb_group, $mvweb_term );
	?>
	<label class="mvweb-t-filters__option">
		<input
			class="mvweb-t-filters__checkbox"
			type="checkbox"
			name="filter_<?php echo esc_attr( $mvweb_group['slug'] ); ?>"
			value="<?php echo esc_attr( $mvweb_term->slug ); ?>"
			<?php checked( in_array( $mvweb_term->slug, $mvweb_selected, true ) ); ?>
		>
		<?php if ( '' !== $mvweb_landing ) : ?>
			<a class="mvweb-t-filters__link" href="<?php echo esc_url( $mvweb_landing ); ?>"><?php echo esc_html( $mvweb_term->name ); ?></a>
		<?php else : ?>
			<span><?php echo esc_html( $mvweb_term->name ); ?></span>
		<?php endif; ?>
		<?php if ( isset( $mvweb_counts[ $mvweb_term->slug ] ) ) : ?>
			<span class="mvweb-t-filters__count"><?php echo esc_html( number_format_i18n( (int) $mvweb_counts[ $mvweb_term->slug ] ) ); ?></span>
		<?php endif; ?>
	</label>
	<?php
};
?>
<details class="mvweb-t-filters__group"<?php echo $mvweb_open ? ' open' : ''; ?>>
	<summary class="mvweb-t-filters__legend">
		<?php echo esc_html( $mvweb_group['label'] ); ?>
		<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	</summary>

	<?php if ( ! isset( $mvweb_group['part'] ) && 'subcategory' !== $mvweb_group['slug'] ) : ?>
		<input type="hidden" name="query_type_<?php echo esc_attr( $mvweb_group['slug'] ); ?>" value="<?php echo esc_attr( $mvweb_join ); ?>">
	<?php endif; ?>

	<div class="mvweb-t-filters__options">
		<?php
		foreach ( $mvweb_head as $mvweb_term ) {
			$mvweb_option( $mvweb_term );
		}
		?>
	</div>

	<?php if ( ! empty( $mvweb_rest ) ) : ?>
		<details class="mvweb-t-filters__rest"<?php echo $mvweb_rest_open ? ' open' : ''; ?>>
			<summary class="mvweb-t-filters__more">
				<span data-when="closed"><?php esc_html_e( 'Show all', 'brand-market' ); ?></span>
				<span data-when="open"><?php esc_html_e( 'Show fewer', 'brand-market' ); ?></span>
			</summary>
			<div class="mvweb-t-filters__options">
				<?php
				foreach ( $mvweb_rest as $mvweb_term ) {
					$mvweb_option( $mvweb_term );
				}
				?>
			</div>
		</details>
	<?php endif; ?>
</details>
