<?php
/**
 * Sidebar part: the properties of the catalogue, one group each, in the order they are declared.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

foreach ( mvweb_core_catalog_filters() as $mvweb_group ) {
	if ( ! isset( $mvweb_group['part'] ) ) {
		get_template_part(
			'template-parts/catalog-filters/group',
			null,
			array(
				'group' => $mvweb_group,
				'state' => isset( $args['state'] ) ? $args['state'] : null,
			)
		);
	}
}
