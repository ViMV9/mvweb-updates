<?php
/**
 * Card of a post, part: the "read more" line.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<span class="mvweb-t-post-card__more"><?php esc_html_e( 'Read more', 'brand-market' ); ?> <?php echo mvweb_theme_icon( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
