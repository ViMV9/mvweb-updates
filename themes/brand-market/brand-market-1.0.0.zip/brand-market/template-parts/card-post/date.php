<?php
/**
 * Card of a post, part: the date.
 *
 * In the row view the date stands beside the post as a big day and a month.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( isset( $args['modifier'] ) && 'row' === $args['modifier'] ) :
	?>
	<time class="mvweb-t-posts__date" datetime="<?php echo esc_attr( get_the_date( 'Y-m-d' ) ); ?>"><b><?php echo esc_html( get_the_date( 'j' ) ); ?></b><span><?php echo esc_html( trim( (string) preg_replace( '/^\d+\s*/u', '', get_the_date( 'j F' ) ) ) ); ?></span></time>
<?php else : ?>
	<time class="mvweb-t-post-card__time" datetime="<?php echo esc_attr( get_the_date( 'Y-m-d' ) ); ?>"><?php echo esc_html( get_the_date() ); ?></time>
	<?php
endif;
