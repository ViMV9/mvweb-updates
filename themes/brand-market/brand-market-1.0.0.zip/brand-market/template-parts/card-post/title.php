<?php
/**
 * Card of a post, part: the title, the link of the card.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="mvweb-t-post-card__title mvweb-t-h3"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
