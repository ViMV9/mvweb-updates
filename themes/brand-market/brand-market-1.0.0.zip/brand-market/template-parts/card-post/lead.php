<?php
/**
 * Card of a post, part: the excerpt.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_excerpt = trim( wp_strip_all_tags( get_the_excerpt() ) );

if ( '' === $mvweb_excerpt ) {
	return;
}
?>
<p class="mvweb-t-post-card__lead"><?php echo esc_html( $mvweb_excerpt ); ?></p>
