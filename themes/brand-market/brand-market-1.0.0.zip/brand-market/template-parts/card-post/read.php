<?php
/**
 * Card of a post, part: the reading time.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_minutes = mvweb_core_reading_minutes( get_the_ID() );

if ( 0 === $mvweb_minutes ) {
	return;
}
?>
<span class="mvweb-t-post-card__read">
	<?php
	/* translators: %s: number of minutes. */
	echo esc_html( sprintf( _x( '%s min', 'reading time', 'brand-market' ), number_format_i18n( $mvweb_minutes ) ) );
	?>
</span>
