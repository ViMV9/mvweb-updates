<?php
/**
 * Card of a post, part: the cover.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! has_post_thumbnail() ) {
	return;
}
?>
<div class="mvweb-t-post-card__media">
	<?php the_post_thumbnail( 'large', array( 'loading' => 'lazy' ) ); ?>
	<?php if ( ! empty( $args['go'] ) ) : ?>
		<span class="mvweb-t-posts__go" aria-hidden="true"><?php echo mvweb_theme_icon( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
	<?php endif; ?>
</div>
