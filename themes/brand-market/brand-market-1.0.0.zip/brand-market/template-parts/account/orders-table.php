<?php
/**
 * Table of orders: the number, the date, the status, the total and the buttons.
 *
 * Arguments: orders (WC_Order[]).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_orders = isset( $args['orders'] ) ? (array) $args['orders'] : array();
$mvweb_names  = array(
	'pay'    => __( 'Pay', 'brand-market' ),
	'view'   => __( 'Details', 'brand-market' ),
	'cancel' => '',
);

if ( empty( $mvweb_orders ) ) {
	return;
}
?>
<table class="mvweb-t-otable">
	<thead>
		<tr>
			<th scope="col"><?php esc_html_e( 'Order', 'brand-market' ); ?></th>
			<th scope="col"><?php esc_html_e( 'Date', 'brand-market' ); ?></th>
			<th scope="col"><?php esc_html_e( 'Status', 'brand-market' ); ?></th>
			<th scope="col"><?php esc_html_e( 'Total', 'brand-market' ); ?></th>
			<th scope="col"><span class="screen-reader-text"><?php esc_html_e( 'Actions', 'brand-market' ); ?></span></th>
		</tr>
	</thead>
	<tbody>
		<?php
		foreach ( $mvweb_orders as $mvweb_order ) :
			if ( ! $mvweb_order instanceof WC_Order ) {
				continue;
			}

			$mvweb_count   = max( 0, $mvweb_order->get_item_count() - $mvweb_order->get_item_count_refunded() );
			$mvweb_created = $mvweb_order->get_date_created();
			?>
			<tr>
				<td>
					<a class="mvweb-t-otable__no" href="<?php echo esc_url( $mvweb_order->get_view_order_url() ); ?>">
						<?php
						/* translators: %s: order number. */
						echo esc_html( sprintf( __( '#%s', 'brand-market' ), $mvweb_order->get_order_number() ) );
						?>
					</a>
				</td>
				<td>
					<?php if ( $mvweb_created ) : ?>
						<time datetime="<?php echo esc_attr( $mvweb_created->date( 'c' ) ); ?>"><?php echo esc_html( wc_format_datetime( $mvweb_created ) ); ?></time>
					<?php endif; ?>
				</td>
				<td><?php get_template_part( 'template-parts/account/status', null, array( 'order' => $mvweb_order ) ); ?></td>
				<td>
					<strong><?php echo wp_kses_post( $mvweb_order->get_formatted_order_total() ); ?></strong>
					<span class="mvweb-t-otable__cnt">
						<?php
						/* translators: %d: number of goods in the order. */
						echo esc_html( sprintf( _n( '%d item', '%d items', $mvweb_count, 'brand-market' ), $mvweb_count ) );
						?>
					</span>
				</td>
				<td>
					<div class="mvweb-t-otable__btns">
						<?php
						foreach ( wc_get_account_orders_actions( $mvweb_order ) as $mvweb_key => $mvweb_action ) :
							if ( ! isset( $mvweb_action['url'], $mvweb_action['name'] ) || ( isset( $mvweb_names[ $mvweb_key ] ) && '' === $mvweb_names[ $mvweb_key ] ) ) {
								continue;
							}

							$mvweb_label = isset( $mvweb_names[ $mvweb_key ] ) ? $mvweb_names[ $mvweb_key ] : $mvweb_action['name'];
							$mvweb_aria  = isset( $mvweb_action['aria-label'] ) ? $mvweb_action['aria-label'] : '';
							?>
							<a class="mvweb-t-btn mvweb-t-btn--sm<?php echo 'pay' === $mvweb_key ? '' : ' mvweb-t-btn--outline'; ?>" href="<?php echo esc_url( $mvweb_action['url'] ); ?>"<?php echo '' !== $mvweb_aria ? ' aria-label="' . esc_attr( $mvweb_aria ) . '"' : ''; ?>><?php echo esc_html( $mvweb_label ); ?></a>
						<?php endforeach; ?>
					</div>
				</td>
			</tr>
		<?php endforeach; ?>
	</tbody>
</table>
