<?php
/**
 * A password input with the button that shows what is typed.
 *
 * Arguments: id (name and id of the input), autocomplete, required (bool), minlength (int).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id        = isset( $args['id'] ) ? sanitize_key( $args['id'] ) : 'password';
$mvweb_autofill  = isset( $args['autocomplete'] ) ? (string) $args['autocomplete'] : 'current-password';
$mvweb_minlength = isset( $args['minlength'] ) ? absint( $args['minlength'] ) : 0;
$mvweb_strength  = ! empty( $args['strength'] );
?>
<span class="mvweb-t-field__wrap"><input class="mvweb-t-field__input" id="<?php echo esc_attr( $mvweb_id ); ?>" name="<?php echo esc_attr( $mvweb_id ); ?>" type="password" autocomplete="<?php echo esc_attr( $mvweb_autofill ); ?>"<?php echo 0 < $mvweb_minlength ? ' minlength="' . esc_attr( (string) $mvweb_minlength ) . '"' : ''; ?><?php echo ! empty( $args['required'] ) ? ' required' : ''; ?><?php echo $mvweb_strength ? ' data-strength-input' : ''; ?>><button class="mvweb-t-field__eye" type="button" data-pass-toggle aria-pressed="false" title="<?php esc_attr_e( 'Show password', 'brand-market' ); ?>"><?php echo mvweb_theme_icon( 'eye', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?><span class="screen-reader-text"><?php esc_html_e( 'Show password', 'brand-market' ); ?></span></button></span>
