<?php
/**
 * The pill with the status of an order.
 *
 * Arguments: order (WC_Order).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_order = isset( $args['order'] ) ? $args['order'] : null;

if ( ! $mvweb_order instanceof WC_Order ) {
	return;
}
?>
<span class="mvweb-t-status mvweb-t-status--<?php echo esc_attr( mvweb_core_account_status_tone( $mvweb_order->get_status() ) ); ?>"><?php echo esc_html( wc_get_order_status_name( $mvweb_order->get_status() ) ); ?></span>
