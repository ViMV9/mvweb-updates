<?php
/**
 * A single card of the sign-in area that tells the state of the password reset.
 *
 * Arguments: icon, tone (empty or muted), title, text, actions (list of url, text, class, attrs).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_actions = isset( $args['actions'] ) ? (array) $args['actions'] : array();
?>
<div class="mvweb-t-auth mvweb-t-auth--single">
	<section class="mvweb-t-auth__card">
		<span class="mvweb-t-auth__mark<?php echo ! empty( $args['tone'] ) ? ' mvweb-t-auth__mark--' . esc_attr( $args['tone'] ) : ''; ?>"><?php echo mvweb_theme_icon( isset( $args['icon'] ) ? (string) $args['icon'] : 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
		<div class="mvweb-t-auth__title mvweb-t-h2"><?php echo esc_html( isset( $args['title'] ) ? (string) $args['title'] : '' ); ?></div>
		<?php if ( ! empty( $args['text'] ) ) : ?>
			<p class="mvweb-t-auth__lead"><?php echo esc_html( (string) $args['text'] ); ?></p>
		<?php endif; ?>
		<?php if ( ! empty( $mvweb_actions ) ) : ?>
			<div class="mvweb-t-auth__actions">
				<?php
				foreach ( $mvweb_actions as $mvweb_action ) :
					$mvweb_attrs = '';

					foreach ( isset( $mvweb_action['attrs'] ) ? (array) $mvweb_action['attrs'] : array() as $mvweb_name => $mvweb_value ) {
						$mvweb_attrs .= ' ' . sanitize_key( $mvweb_name ) . '="' . esc_attr( (string) $mvweb_value ) . '"';
					}
					?>
					<a class="mvweb-t-btn<?php echo ! empty( $mvweb_action['class'] ) ? ' ' . esc_attr( $mvweb_action['class'] ) : ''; ?>" href="<?php echo esc_url( $mvweb_action['url'] ); ?>"<?php echo $mvweb_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Names and values are escaped above. ?>><?php echo esc_html( $mvweb_action['text'] ); ?></a>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</section>
</div>
