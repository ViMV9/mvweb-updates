<?php
/**
 * Empty state of a section of the account.
 *
 * Arguments: icon, title, text, button_url, button_text.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_icon = isset( $args['icon'] ) ? (string) $args['icon'] : 'package';
$mvweb_url  = isset( $args['button_url'] ) ? (string) $args['button_url'] : '';
$mvweb_btn  = isset( $args['button_text'] ) ? (string) $args['button_text'] : '';
?>
<div class="mvweb-t-empty">
	<span class="mvweb-t-empty__icon"><?php echo mvweb_theme_icon( $mvweb_icon ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
	<div class="mvweb-t-empty__title mvweb-t-h2"><?php echo esc_html( isset( $args['title'] ) ? (string) $args['title'] : '' ); ?></div>
	<?php if ( ! empty( $args['text'] ) ) : ?>
		<p class="mvweb-t-empty__text"><?php echo esc_html( (string) $args['text'] ); ?></p>
	<?php endif; ?>
	<?php if ( '' !== $mvweb_url && '' !== $mvweb_btn ) : ?>
		<a class="mvweb-t-btn" href="<?php echo esc_url( $mvweb_url ); ?>"><?php echo esc_html( $mvweb_btn ); ?></a>
	<?php endif; ?>
</div>
