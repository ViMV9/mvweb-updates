<?php
/**
 * Work side card part: the service the work was done under.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_service = mvweb_core_sanitize_service_id( get_post_meta( absint( $args['id'] ), '_mvweb_work_service', true ) );

if ( ! $mvweb_service || 'publish' !== get_post_status( $mvweb_service ) ) {
	return;
}
?>
<p class="mvweb-t-work__service">
	<span><?php esc_html_e( 'Service', 'brand-market' ); ?></span>
	<a href="<?php echo esc_url( (string) get_permalink( $mvweb_service ) ); ?>"><?php echo esc_html( get_the_title( $mvweb_service ) ); ?></a>
</p>
