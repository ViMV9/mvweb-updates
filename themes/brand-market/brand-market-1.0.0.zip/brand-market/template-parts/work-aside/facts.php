<?php
/**
 * Work side card part: the facts of the work, caption and figure.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_facts = mvweb_core_work_facts( absint( $args['id'] ) );

if ( empty( $mvweb_facts ) ) {
	return;
}
?>
<dl class="mvweb-t-work__facts">
	<?php foreach ( $mvweb_facts as $mvweb_fact ) : ?>
		<div>
			<?php if ( '' !== $mvweb_fact['label'] ) : ?>
				<dt><?php echo esc_html( $mvweb_fact['label'] ); ?></dt>
			<?php endif; ?>
			<dd><?php echo esc_html( $mvweb_fact['value'] ); ?></dd>
		</div>
	<?php endforeach; ?>
</dl>
