<?php
/**
 * Work side card part: the heading of the card.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<p class="mvweb-t-service__form-title"><?php esc_html_e( 'About the work', 'brand-market' ); ?></p>
