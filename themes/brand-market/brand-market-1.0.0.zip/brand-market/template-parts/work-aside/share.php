<?php
/**
 * Work side card part: the share buttons.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part( 'template-parts/share', null, array( 'id' => absint( $args['id'] ) ) );
