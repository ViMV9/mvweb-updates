<?php
/**
 * Work side card part: the request button.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_cta = mvweb_core_work_cta();

if ( empty( $mvweb_cta ) ) {
	return;
}
?>
<div class="mvweb-t-service__actions">
	<a class="mvweb-t-btn mvweb-t-btn--block" href="<?php echo esc_url( $mvweb_cta['url'] ); ?>" data-request><?php echo esc_html( $mvweb_cta['text'] ); ?></a>
</div>
