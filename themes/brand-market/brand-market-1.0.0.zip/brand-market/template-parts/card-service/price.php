<?php
/**
 * Service card part: the price.
 *
 * The price and the link share one line. Whichever of the two the layout
 * lists first prints that line; the other prints nothing.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part( 'template-parts/card-service/foot', null, array_merge( $args, array( 'part' => 'price' ) ) );
