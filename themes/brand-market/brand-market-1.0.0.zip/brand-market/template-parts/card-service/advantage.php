<?php
/**
 * Service card part: the line under the name.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_advantage = mvweb_core_service_advantage( absint( $args['id'] ) );

if ( '' === $mvweb_advantage ) {
	return;
}
?>
<p class="mvweb-t-card__advantage"><?php echo esc_html( $mvweb_advantage ); ?></p>
