<?php
/**
 * Service card part: the picture, a link to the service.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_image = mvweb_core_item_image(
	absint( $args['id'] ),
	'medium_large',
	array(
		'loading'  => empty( $args['eager'] ) ? 'lazy' : false,
		'decoding' => 'async',
	)
);

if ( '' === $mvweb_image ) {
	return;
}
?>
<a class="mvweb-t-card__media" href="<?php echo esc_url( $args['link'] ); ?>" tabindex="-1" aria-hidden="true">
	<?php echo $mvweb_image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core's escaped image markup. ?>
</a>
