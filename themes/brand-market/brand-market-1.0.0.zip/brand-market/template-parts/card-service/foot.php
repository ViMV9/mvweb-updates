<?php
/**
 * Service card line: the price and the link in the order of the layout.
 *
 * Not a part of the layout itself: the price and more parts call it, and only
 * the first of them prints.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_order = array_values( array_intersect( mvweb_core_layout_order( 'card-service' ), array( 'price', 'more' ) ) );

if ( empty( $mvweb_order ) || $mvweb_order[0] !== $args['part'] ) {
	return;
}

$mvweb_id    = absint( $args['id'] );
$mvweb_price = mvweb_core_service_price( $mvweb_id );

if ( '' === trim( wp_strip_all_tags( $mvweb_price ) ) ) {
	$mvweb_price = esc_html( mvweb_core_service_price_placeholder() );
}

$mvweb_more = trim( (string) mvweb_core_services_pages_option( 'mvweb_service_card_more' ) );
$mvweb_bits = array(
	'price' => '' !== $mvweb_price ? '<div class="mvweb-t-price">' . $mvweb_price . '</div>' : '',
	'more'  => '<a class="mvweb-t-card__more" href="' . esc_url( $args['link'] ) . '"' . ( '' === $mvweb_more ? ' aria-label="' . esc_attr( get_the_title( $mvweb_id ) ) . '"' : '' ) . '>' . esc_html( $mvweb_more ) . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>',
);

$mvweb_html = '';

foreach ( $mvweb_order as $mvweb_slug ) {
	$mvweb_html .= $mvweb_bits[ $mvweb_slug ];
}

if ( '' === $mvweb_html ) {
	return;
}
?>
<div class="mvweb-t-card__foot"><?php echo $mvweb_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?></div>
