<?php
/**
 * Service card part: the name, a link to the service.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="mvweb-t-card__title mvweb-t-h3"><a href="<?php echo esc_url( $args['link'] ); ?>"><?php echo esc_html( get_the_title( absint( $args['id'] ) ) ); ?></a></div>
