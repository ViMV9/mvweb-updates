<?php
/**
 * Section template: a price list.
 *
 * Five views: a table, a menu with dotted lines, cards with an icon, groups in
 * tabs, an accordion of groups. A row with no price heads the group under it.
 * The head, the prices and the button come in the order the composition sets;
 * a note, a group icon and a line beside a folded group can be switched off,
 * and a part without data is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'price-list', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_view  = $mvweb_block['mod'];
$mvweb_keys  = array( 'price_1', 'price_2', 'price_3' );

$mvweb_filled = static function ( $row, $key ) {
	return isset( $row[ $key ] ) && '' !== trim( (string) $row[ $key ] );
};

$mvweb_groups = array();

if ( isset( $mvweb_props['rows'] ) && is_array( $mvweb_props['rows'] ) ) {
	foreach ( mvweb_core_visible_rows( $mvweb_props['rows'] ) as $mvweb_row ) {
		$mvweb_priced = $mvweb_filled( $mvweb_row, 'price_1' ) || $mvweb_filled( $mvweb_row, 'price_2' ) || $mvweb_filled( $mvweb_row, 'price_3' );

		if ( ! $mvweb_priced && $mvweb_filled( $mvweb_row, 'title' ) ) {
			$mvweb_groups[] = array_merge( $mvweb_row, array( 'lines' => array() ) );
			continue;
		}

		if ( ! $mvweb_priced ) {
			continue;
		}

		if ( empty( $mvweb_groups ) ) {
			$mvweb_groups[] = array(
				'title' => '',
				'lines' => array(),
			);
		}

		$mvweb_groups[ count( $mvweb_groups ) - 1 ]['lines'][] = $mvweb_row;
	}
}

$mvweb_groups = array_values(
	array_filter(
		$mvweb_groups,
		static function ( $group ) {
			return ! empty( $group['lines'] );
		}
	)
);

if ( empty( $mvweb_groups ) ) {
	return;
}

$mvweb_motion = '' !== $mvweb_block['motion'];
$mvweb_rv     = $mvweb_motion ? ' data-rv' : '';
$mvweb_id     = wp_unique_id( 'price-list-' );
$mvweb_shown  = static function ( $block, $slug ) {
	return in_array( $slug, $block['item_parts'], true );
};

$mvweb_names = static function ( array $group ) use ( $mvweb_props ) {
	$names = array();

	foreach ( array( 1, 2, 3 ) as $index ) {
		$own     = isset( $group[ 'col_' . $index ] ) ? trim( (string) $group[ 'col_' . $index ] ) : '';
		$names[] = '' !== $own ? $own : trim( (string) $mvweb_props[ 'col_' . $index ] );
	}

	return $names;
};

$mvweb_columns = static function ( array $groups, array $names ) use ( $mvweb_keys, $mvweb_filled ) {
	$count = 0;

	foreach ( $names as $index => $name ) {
		if ( '' !== $name ) {
			$count = max( $count, $index + 1 );
		}
	}

	foreach ( $groups as $group ) {
		foreach ( $group['lines'] as $line ) {
			foreach ( $mvweb_keys as $index => $key ) {
				if ( $mvweb_filled( $line, $key ) ) {
					$count = max( $count, $index + 1 );
				}
			}
		}
	}

	return max( 1, $count );
};

$mvweb_table = static function ( array $groups, array $names, $caption, $show_groups, $block, $rv ) use ( $mvweb_props, $mvweb_columns, $mvweb_shown, $mvweb_keys ) {
	$count = $mvweb_columns( $groups, $names );
	$head  = '' !== trim( (string) $mvweb_props['col_0'] ) || '' !== implode( '', $names );
	$attr  = $rv ? ' data-rv' : '';

	echo '<table class="mvweb-t-price-list__table mvweb-t-price-list__table--cols-' . (int) $count . '">';

	if ( '' !== $caption ) {
		echo '<caption class="screen-reader-text">' . esc_html( $caption ) . '</caption>';
	}

	if ( $head ) {
		echo '<thead><tr><th class="mvweb-t-price-list__colname mvweb-t-price-list__colname--service" scope="col">' . esc_html( $mvweb_props['col_0'] ) . '</th>';

		for ( $index = 0; $index < $count; $index++ ) {
			echo '<th class="mvweb-t-price-list__colname" scope="col">' . esc_html( $names[ $index ] ) . '</th>';
		}

		echo '</tr></thead>';
	}

	foreach ( $groups as $group ) {
		echo '<tbody>';

		if ( $show_groups && '' !== trim( (string) $group['title'] ) ) {
			echo '<tr' . $attr . '><th class="mvweb-t-price-list__group" colspan="' . (int) ( $count + 1 ) . '" scope="colgroup">' . esc_html( $group['title'] ) . '</th></tr>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.
		}

		foreach ( $group['lines'] as $line ) {
			echo '<tr class="mvweb-t-price-list__row"' . $attr . '><th class="mvweb-t-price-list__name" scope="row">' . esc_html( $line['title'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.

			if ( $mvweb_shown( $block, 'note' ) && '' !== trim( (string) $line['note'] ) ) {
				echo '<span class="mvweb-t-price-list__note">' . esc_html( $line['note'] ) . '</span>';
			}

			echo '</th>';

			for ( $index = 0; $index < $count; $index++ ) {
				echo '<td class="mvweb-t-price-list__price"' . ( '' !== $names[ $index ] ? ' data-label="' . esc_attr( $names[ $index ] ) . '"' : '' ) . '>' . esc_html( isset( $line[ $mvweb_keys[ $index ] ] ) ? $line[ $mvweb_keys[ $index ] ] : '' ) . '</td>';
			}

			echo '</tr>';
		}

		echo '</tbody>';
	}

	echo '</table>';
};

$mvweb_items = static function ( array $lines, $block, $rv ) use ( $mvweb_keys, $mvweb_shown ) {
	echo '<ul class="mvweb-t-price-list__items">';

	foreach ( $lines as $line ) {
		$prices = array();

		foreach ( $mvweb_keys as $key ) {
			if ( isset( $line[ $key ] ) && '' !== trim( (string) $line[ $key ] ) ) {
				$prices[] = trim( (string) $line[ $key ] );
			}
		}

		echo '<li class="mvweb-t-price-list__item"' . ( $rv ? ' data-rv' : '' ) . '><span class="mvweb-t-price-list__item-name">' . esc_html( $line['title'] ) . '</span><span class="mvweb-t-price-list__item-fill" aria-hidden="true"></span><span class="mvweb-t-price-list__item-price">' . esc_html( implode( ' / ', $prices ) ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.

		if ( $mvweb_shown( $block, 'note' ) && '' !== trim( (string) $line['note'] ) ) {
			echo '<span class="mvweb-t-price-list__item-note">' . esc_html( $line['note'] ) . '</span>';
		}

		echo '</li>';
	}

	echo '</ul>';
};

$mvweb_footer = static function ( $group, $rv ) use ( $mvweb_props, $mvweb_block ) {
	$pick = static function ( $key ) use ( $group, $mvweb_props ) {
		$own = is_array( $group ) && isset( $group[ $key ] ) ? trim( (string) $group[ $key ] ) : '';

		return '' !== $own ? $own : trim( (string) $mvweb_props[ $key ] );
	};
	$text = $pick( 'button_text' );
	$url  = $pick( 'button_url' );
	$note = $pick( 'footnote' );
	$kind = $mvweb_block['look']['button_kind'];
	$css  = 'mvweb-t-btn' . ( 'secondary' === $kind ? ' mvweb-t-btn--outline' : '' ) . ( 'link' === $kind ? ' mvweb-t-btn--link' : '' );
	$show = '' !== $text && '' !== $url;

	if ( ! $show && '' === $note ) {
		return;
	}

	echo '<div class="mvweb-t-price-list__foot"' . ( $rv ? ' data-rv' : '' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.

	if ( $show ) {
		echo '<a class="' . esc_attr( $css ) . '" href="' . esc_url( $url ) . '">' . esc_html( $text ) . '</a>';
	}

	if ( '' !== $note ) {
		echo '<p class="mvweb-t-price-list__footnote">' . esc_html( $note ) . '</p>';
	}

	echo '</div>';
};

$mvweb_parts = array(
	'list'   => static function ( $block ) use ( $mvweb_groups, $mvweb_names, $mvweb_table, $mvweb_items, $mvweb_footer, $mvweb_rv, $mvweb_id, $mvweb_props ) {
		$view = $block['mod'];
		$rv   = '' !== $mvweb_rv;

		if ( 'table' === $view ) {
			echo '<div class="mvweb-t-price-list__wrap">';
			$mvweb_table( $mvweb_groups, $mvweb_names( array() ), (string) $mvweb_props['title'], true, $block, $rv );
			echo '</div>';

			return;
		}

		if ( 'dots' === $view ) {
			echo '<div class="mvweb-t-price-list__menu">';

			foreach ( $mvweb_groups as $group ) {
				echo '<div class="mvweb-t-price-list__block">';

				if ( '' !== trim( (string) $group['title'] ) ) {
					echo '<div class="mvweb-t-price-list__block-title"' . ( $rv ? ' data-rv' : '' ) . '>' . esc_html( $group['title'] ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.
				}

				$mvweb_items( $group['lines'], $block, $rv );
				echo '</div>';
			}

			echo '</div>';

			return;
		}

		if ( 'cards' === $view ) {
			echo '<div class="mvweb-t-price-list__cards">';

			foreach ( $mvweb_groups as $group ) {
				echo '<article class="mvweb-t-price-list__card"' . ( $rv ? ' data-rv' : '' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.

				if ( in_array( 'icon', $block['item_parts'], true ) && ! empty( $group['icon'] ) ) {
					echo '<span class="mvweb-t-price-list__badge" aria-hidden="true">' . mvweb_theme_icon( $group['icon'] ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
				}

				if ( '' !== trim( (string) $group['title'] ) ) {
					echo '<div class="mvweb-t-price-list__card-title">' . esc_html( $group['title'] ) . '</div>';
				}

				$mvweb_items( $group['lines'], $block, false );
				echo '</article>';
			}

			echo '</div>';

			return;
		}

		if ( 'tabs' === $view ) {
			$tabs = count( $mvweb_groups ) > 1;

			echo '<div data-tabs>';

			if ( $tabs ) {
				echo '<div class="mvweb-t-price-list__tabs" role="tablist" aria-label="' . esc_attr__( 'Groups of prices', 'brand-market' ) . '"' . ( $rv ? ' data-rv data-rv-dir="-1"' : '' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.

				foreach ( $mvweb_groups as $index => $group ) {
					$label = '' !== trim( (string) $group['title'] ) ? $group['title'] : __( 'Prices', 'brand-market' );

					echo '<button class="mvweb-t-price-list__tab" type="button" role="tab" id="' . esc_attr( $mvweb_id . '-tab-' . $index ) . '" aria-controls="' . esc_attr( $mvweb_id . '-panel-' . $index ) . '" aria-selected="' . ( 0 === $index ? 'true' : 'false' ) . '"' . ( 0 === $index ? '' : ' tabindex="-1"' ) . ' data-tab="' . esc_attr( 'g' . $index ) . '">' . esc_html( $label ) . '</button>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
				}

				echo '</div>';
			}

			foreach ( $mvweb_groups as $index => $group ) {
				echo '<div class="mvweb-t-price-list__panel"' . ( $tabs ? ' role="tabpanel" id="' . esc_attr( $mvweb_id . '-panel-' . $index ) . '" aria-labelledby="' . esc_attr( $mvweb_id . '-tab-' . $index ) . '" data-tab-panel="' . esc_attr( 'g' . $index ) . '"' . ( 0 === $index ? '' : ' hidden' ) : '' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
				echo '<div class="mvweb-t-price-list__wrap"' . ( $rv ? ' data-rv data-rv-dir="1"' : '' ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.
				$mvweb_table( array( $group ), $mvweb_names( $group ), (string) $group['title'], false, $block, false );
				echo '</div>';

				if ( in_array( 'footer', $block['parts'], true ) ) {
					$mvweb_footer( $group, false );
				}

				echo '</div>';
			}

			echo '</div>';

			return;
		}

		echo '<div class="mvweb-t-price-list__acc-list">';

		foreach ( $mvweb_groups as $index => $group ) {
			echo '<details class="mvweb-t-price-list__acc"' . ( $rv ? ' data-rv' : '' ) . ( 0 === $index ? ' open' : '' ) . '><summary class="mvweb-t-price-list__acc-sum"><span class="mvweb-t-price-list__acc-title">' . esc_html( '' !== trim( (string) $group['title'] ) ? $group['title'] : __( 'Prices', 'brand-market' ) ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.

			if ( in_array( 'summary', $block['item_parts'], true ) && ! empty( $group['note'] ) ) {
				echo '<span class="mvweb-t-price-list__acc-from">' . esc_html( $group['note'] ) . '</span>';
			}

			echo '<span class="mvweb-t-price-list__acc-icon">' . mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</span></summary>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
			$mvweb_items( $group['lines'], $block, false );
			echo '</details>';
		}

		echo '</div>';
	},
	'footer' => static function ( $block ) use ( $mvweb_footer, $mvweb_rv ) {
		if ( 'tabs' !== $block['mod'] ) {
			$mvweb_footer( null, '' !== $mvweb_rv );
		}
	},
);

mvweb_theme_section_open( $mvweb_block );

if ( 'accordion' === $mvweb_view ) {
	$mvweb_side          = $mvweb_block;
	$mvweb_side['parts'] = array_values( array_diff( $mvweb_block['parts'], array( 'list' ) ) );

	ob_start();
	mvweb_theme_render_parts( $mvweb_side, $mvweb_parts, array( 'rv' => true ) );
	$mvweb_side_html = (string) ob_get_clean();

	echo '<div class="mvweb-t-price-list__layout">' . ( '' !== $mvweb_side_html ? '<div class="mvweb-t-price-list__side">' . $mvweb_side_html . '</div>' : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped markup.

	if ( in_array( 'list', $mvweb_block['parts'], true ) ) {
		$mvweb_parts['list']( $mvweb_block );
	}

	echo '</div>';
} else {
	mvweb_theme_render_parts( $mvweb_block, $mvweb_parts, array( 'rv' => true ) );
}

mvweb_theme_section_close();
