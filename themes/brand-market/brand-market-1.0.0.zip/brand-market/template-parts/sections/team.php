<?php
/**
 * Section template: the team.
 *
 * Five views: a grid of cards, round portraits, horizontal cards, the leader
 * put forward with the rest in a row, a ribbon of portraits. The people are
 * the Team records; the head and the list follow the order the composition
 * sets, and so do the parts of a card. The short text about a person belongs
 * to the horizontal cards and to the leader; a part without data is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block  = mvweb_theme_block( 'team', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props  = $mvweb_block['props'];
$mvweb_count  = isset( $mvweb_props['count'] ) ? absint( $mvweb_props['count'] ) : 0;
$mvweb_people = function_exists( 'mvweb_core_people' ) ? mvweb_core_people( $mvweb_count ) : array();

if ( empty( $mvweb_people ) ) {
	return;
}

$mvweb_view  = $mvweb_block['view'];
$mvweb_rv    = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_book  = isset( $mvweb_props['book_text'] ) ? trim( (string) $mvweb_props['book_text'] ) : '';
$mvweb_label = isset( $mvweb_props['lead_label'] ) ? trim( (string) $mvweb_props['lead_label'] ) : '';

$mvweb_item_parts = array(
	'role'   => static function ( $item ) {
		if ( '' !== $item['role'] ) {
			echo '<p class="mvweb-t-team__role"' . $item['rv'] . '>' . esc_html( $item['role'] ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.
		}
	},
	'bio'    => static function ( $item ) {
		if ( '' !== $item['bio'] ) {
			echo '<p class="mvweb-t-team__bio"' . $item['rv'] . '>' . esc_html( $item['bio'] ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.
		}
	},
	'button' => static function ( $item ) {
		if ( '' !== $item['url'] && '' !== $item['book'] ) {
			echo '<div class="mvweb-t-card__foot"' . $item['rv'] . '><a class="' . esc_attr( $item['button'] ) . '" href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['book'] ) . '</a></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.
		}
	},
);

$mvweb_card = static function ( $person, $lead = false ) use ( $mvweb_block, $mvweb_view, $mvweb_rv, $mvweb_book, $mvweb_label, $mvweb_item_parts ) {
	$name  = get_the_title( $person );
	$photo = has_post_thumbnail( $person ) ? get_the_post_thumbnail( $person, 'large', array( 'loading' => 'lazy' ) ) : '';
	$mark  = function_exists( 'mvweb_core_initials' ) ? mvweb_core_initials( $name ) : '';
	$child = $lead ? $mvweb_rv : '';
	$block = in_array( $mvweb_view, array( '1', '4', '5' ), true ) && ! $lead ? ' mvweb-t-btn--block' : '';
	$item  = array(
		'role'   => trim( (string) get_post_meta( $person->ID, '_mvweb_role', true ) ),
		'bio'    => '3' === $mvweb_view || ( $lead && '4' === $mvweb_view ) ? trim( (string) get_post_meta( $person->ID, '_mvweb_bio', true ) ) : '',
		'url'    => trim( (string) get_post_meta( $person->ID, '_mvweb_booking_url', true ) ),
		'book'   => $mvweb_book,
		'button' => $lead ? 'mvweb-t-btn' : 'mvweb-t-btn mvweb-t-btn--sm mvweb-t-btn--outline' . $block,
		'rv'     => $child,
	);

	if ( '' === $photo && '' !== $mark ) {
		$photo = '<span class="mvweb-t-team__initials" aria-hidden="true">' . esc_html( $mark ) . '</span>';
	}

	echo '<article class="mvweb-t-card mvweb-t-team__card' . ( $lead ? ' mvweb-t-team__card--lead' : '' ) . '"' . ( $lead ? '' : $mvweb_rv ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.

	if ( '' !== $photo && in_array( 'photo', $mvweb_block['item_parts'], true ) ) {
		echo '<div class="mvweb-t-card__media mvweb-t-team__media"' . $child . '>' . $photo . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Attachment image or escaped initials.
	}

	echo '<div class="mvweb-t-card__body">';

	if ( $lead && '' !== $mvweb_label ) {
		echo '<span class="mvweb-t-team__label"' . $child . '>' . esc_html( $mvweb_label ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.
	}

	echo '<div class="mvweb-t-team__name mvweb-t-h3"' . $child . '>' . esc_html( $name ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.

	mvweb_theme_render_item_parts( $mvweb_block, $item, $mvweb_item_parts );

	echo '</div></article>';
};

$mvweb_parts = array(
	'list' => static function () use ( $mvweb_people, $mvweb_view, $mvweb_card ) {
		if ( '4' === $mvweb_view ) {
			echo '<div class="mvweb-t-team__stage">';
			$mvweb_card( $mvweb_people[0], true );

			if ( count( $mvweb_people ) > 1 ) {
				echo '<div class="mvweb-t-team__row">';

				foreach ( array_slice( $mvweb_people, 1 ) as $person ) {
					$mvweb_card( $person );
				}

				echo '</div>';
			}

			echo '</div>';

			return;
		}

		if ( '3' === $mvweb_view ) {
			echo '<div class="mvweb-t-team__list">';
		} elseif ( '5' === $mvweb_view ) {
			echo '<div class="mvweb-t-team__track" tabindex="0" role="group" aria-label="' . esc_attr__( 'Team, scroll sideways', 'brand-market' ) . '">';
		} else {
			echo '<div class="mvweb-t-grid">';
		}

		foreach ( $mvweb_people as $person ) {
			$mvweb_card( $person );
		}

		echo '</div>';
	},
);

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts(
	$mvweb_block,
	$mvweb_parts,
	array(
		'rv'    => true,
		'class' => '2' === $mvweb_view ? 'mvweb-t-section-head--center' : '',
	)
);
mvweb_theme_section_close();
