<?php
/**
 * Section template: video reviews.
 *
 * Five views: a carousel of covers, a wall of stories, a main video with a
 * list, phone frames, a list with descriptions. A video is an address: the
 * cover is a light picture, and the player of the video site loads only when
 * a visitor opens the review. The reviews are video review records or rows of
 * the block. The head, the arrows and the reviews come in the order the
 * composition sets where the layout allows it; a part without data is not
 * printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'video-reviews', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_view  = $mvweb_block['mod'];
$mvweb_rv    = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_rows  = array();

if ( isset( $mvweb_props['source'] ) && 'rows' === $mvweb_props['source'] ) {
	foreach ( isset( $mvweb_props['items'] ) && is_array( $mvweb_props['items'] ) ? mvweb_core_visible_rows( $mvweb_props['items'] ) : array() as $mvweb_item ) {
		$mvweb_rows[] = array(
			'title' => (string) $mvweb_item['title'],
			'image' => (int) $mvweb_item['image'],
			'url'   => (string) $mvweb_item['video_url'],
			'time'  => (string) $mvweb_item['duration'],
			'note'  => (string) $mvweb_item['note'],
			'text'  => (string) $mvweb_item['text'],
		);
	}
} else {
	foreach ( mvweb_core_videos( isset( $mvweb_props['count'] ) ? absint( $mvweb_props['count'] ) : 0 ) as $mvweb_video ) {
		$mvweb_rows[] = array(
			'title' => get_the_title( $mvweb_video ),
			'image' => (int) get_post_thumbnail_id( $mvweb_video ),
			'url'   => (string) get_post_meta( $mvweb_video->ID, '_mvweb_video_url', true ),
			'time'  => (string) get_post_meta( $mvweb_video->ID, '_mvweb_video_duration', true ),
			'note'  => (string) get_post_meta( $mvweb_video->ID, '_mvweb_video_note', true ),
			'text'  => (string) get_post_meta( $mvweb_video->ID, '_mvweb_video_text', true ),
		);
	}
}

$mvweb_rows = array_values(
	array_filter(
		$mvweb_rows,
		static function ( $row ) {
			return '' !== $row['url'];
		}
	)
);

if ( empty( $mvweb_rows ) ) {
	return;
}

$mvweb_has = static function ( $slug ) use ( $mvweb_block ) {
	return in_array( $slug, $mvweb_block['parts'], true );
};

$mvweb_info = static function ( $row, $block ) use ( $mvweb_view ) {
	$html = '';

	foreach ( $block['item_parts'] as $slug ) {
		if ( 'title' === $slug && '' !== $row['title'] ) {
			$html .= '<span class="mvweb-t-video-reviews__name mvweb-t-h3">' . esc_html( $row['title'] ) . '</span>';
		} elseif ( 'note' === $slug && '' !== $row['note'] ) {
			$html .= '<span class="mvweb-t-video-reviews__role">' . esc_html( $row['note'] ) . '</span>';
		} elseif ( 'list' === $mvweb_view && 'text' === $slug && '' !== $row['text'] ) {
			$html .= '<span class="mvweb-t-video-reviews__quote">' . esc_html( $row['text'] ) . '</span>';
		} elseif ( 'list' === $mvweb_view && 'cta' === $slug ) {
			/* translators: %s: length of the video. */
			$label = '' !== $row['time'] ? sprintf( __( 'Watch, %s', 'brand-market' ), $row['time'] ) : __( 'Watch', 'brand-market' );
			$html .= '<span class="mvweb-t-video-reviews__cta">' . esc_html( $label ) . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</span>';
		}
	}

	return '' !== $html ? '<span class="mvweb-t-video-reviews__info">' . $html . '</span>' : '';
};

$mvweb_item = static function ( $row, $block, $classes, $dir = '' ) use ( $mvweb_view, $mvweb_rv, $mvweb_info ) {
	$names = array_filter( array( $row['title'], $row['time'] ), 'strlen' );

	if ( empty( $names ) ) {
		$label = __( 'Watch video review', 'brand-market' );
	} else {
		/* translators: %s: title and length of the video review. */
		$label = sprintf( __( 'Watch video review: %s', 'brand-market' ), implode( ', ', $names ) );
	}

	$cover = '';

	if ( ! empty( $row['image'] ) ) {
		$cover = wp_get_attachment_image(
			$row['image'],
			'large',
			false,
			array(
				'alt'     => '',
				'loading' => 'lazy',
			)
		);
	}

	$cover .= '<span class="mvweb-t-video-reviews__play">' . mvweb_theme_icon( 'player-play', array( 'class' => 'mvweb-t-icon--fill' ) ) . '</span>';

	if ( '' !== $row['time'] && in_array( 'duration', $block['item_parts'], true ) ) {
		$cover .= '<span class="mvweb-t-badge mvweb-t-video-reviews__time">' . esc_html( $row['time'] ) . '</span>';
	}

	$info = $mvweb_info( $row, $block );
	?>
	<article class="<?php echo esc_attr( $classes ); ?>"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?><?php echo '' !== $mvweb_rv && '' !== $dir ? ' data-rv-dir="' . esc_attr( $dir ) . '"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped attribute. ?>>
		<a class="mvweb-t-video-reviews__link" href="<?php echo esc_url( $row['url'] ); ?>" target="_blank" rel="noopener" aria-label="<?php echo esc_attr( $label ); ?>" data-video-play>
			<?php if ( 'phones' === $mvweb_view ) : ?>
				<span class="mvweb-t-video-reviews__phone"><span class="mvweb-t-video-reviews__cover"><?php echo $cover; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and core image markup. ?></span></span>
				<?php echo $info; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
			<?php elseif ( 'wall' === $mvweb_view ) : ?>
				<span class="mvweb-t-video-reviews__cover"><?php echo $cover . $info; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and core image markup. ?></span>
			<?php else : ?>
				<span class="mvweb-t-video-reviews__cover"><?php echo $cover; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and core image markup. ?></span>
				<?php echo $info; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
			<?php endif; ?>
		</a>
	</article>
	<?php
};

$mvweb_dialog = static function () {
	?>
	<dialog class="mvweb-t-video-reviews__dialog" data-video-dialog aria-label="<?php esc_attr_e( 'Video review', 'brand-market' ); ?>">
		<button class="mvweb-t-round mvweb-t-round--line mvweb-t-video-reviews__close" type="button" data-video-close title="<?php esc_attr_e( 'Close', 'brand-market' ); ?>">
			<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span class="screen-reader-text"><?php esc_html_e( 'Close', 'brand-market' ); ?></span>
		</button>
		<div class="mvweb-t-video-reviews__player" data-video-stage></div>
	</dialog>
	<?php
};

$mvweb_list = static function ( $block ) use ( $mvweb_view, $mvweb_rows, $mvweb_item, $mvweb_dialog ) {
	$item = 'mvweb-t-video-reviews__item';

	if ( 'feature' === $mvweb_view ) {
		?>
		<div class="mvweb-t-video-reviews__layout">
			<?php $mvweb_item( $mvweb_rows[0], $block, $item . ' ' . $item . '--main', '-1' ); ?>
			<?php if ( count( $mvweb_rows ) > 1 ) : ?>
				<div class="mvweb-t-video-reviews__list">
					<?php
					foreach ( array_slice( $mvweb_rows, 1 ) as $row ) {
						$mvweb_item( $row, $block, $item . ' ' . $item . '--mini', '1' );
					}
					?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	} else {
		$wrappers = array(
			''       => array( 'div', 'mvweb-t-rail__track', ' data-showcase-track' ),
			'wall'   => array( 'div', 'mvweb-t-video-reviews__wall', '' ),
			'phones' => array( 'div', 'mvweb-t-video-reviews__phones', '' ),
			'list'   => array( 'div', 'mvweb-t-video-reviews__rows', '' ),
		);
		$wrapper  = $wrappers[ $mvweb_view ];

		if ( 'phones' === $mvweb_view ) {
			echo '<div class="mvweb-t-video-reviews__stage">';
		}
		?>
		<div class="<?php echo esc_attr( $wrapper[1] ); ?>"<?php echo $wrapper[2]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
			<?php
			foreach ( $mvweb_rows as $row ) {
				$mvweb_item( $row, $block, $item );
			}
			?>
		</div>
		<?php
		if ( 'phones' === $mvweb_view ) {
			echo '</div>';
		}
	}

	$mvweb_dialog();
};

$mvweb_nav = static function () use ( $mvweb_rv ) {
	?>
	<div class="mvweb-t-section-head__nav"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
		<?php
		echo mvweb_theme_showcase_arrows( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
			array(
				'prev' => __( 'Back', 'brand-market' ),
				'next' => __( 'Forward', 'brand-market' ),
			)
		);
		?>
	</div>
	<?php
};

$mvweb_head = static function ( array $slugs ) use ( $mvweb_block, $mvweb_view, $mvweb_nav ) {
	ob_start();

	if ( in_array( 'nav', $slugs, true ) ) {
		$mvweb_nav();
	}

	$mvweb_side = (string) ob_get_clean();

	mvweb_theme_head(
		$mvweb_block,
		$slugs,
		array(
			'class' => 'wall' === $mvweb_view ? 'mvweb-t-section-head--center' : '',
			'rv'    => true,
			'side'  => $mvweb_side,
		)
	);
};

$mvweb_head_slugs = '' === $mvweb_view ? array( 'kicker', 'title', 'lead', 'nav' ) : array( 'kicker', 'title', 'lead' );

$mvweb_pass = static function () use ( $mvweb_block, $mvweb_head, $mvweb_head_slugs, $mvweb_list, $mvweb_has ) {
	$pending = array();

	foreach ( array_merge( $mvweb_block['parts'], array( '' ) ) as $slug ) {
		if ( 'nav' === $slug && ! in_array( 'nav', $mvweb_head_slugs, true ) ) {
			continue;
		}

		if ( in_array( $slug, $mvweb_head_slugs, true ) ) {
			$pending[] = $slug;
			continue;
		}

		if ( ! empty( $pending ) ) {
			$mvweb_head( $pending );
			$pending = array();
		}

		if ( 'list' === $slug && $mvweb_has( 'list' ) ) {
			$mvweb_list( $mvweb_block );
		}
	}
};

if ( '' === $mvweb_view ) {
	mvweb_theme_section_open( $mvweb_block, false );
	echo '<div class="mvweb-t-container" data-showcase>';
	$mvweb_pass();
	echo '</div>';
	mvweb_theme_section_close( false );
} else {
	mvweb_theme_section_open( $mvweb_block );
	$mvweb_pass();
	mvweb_theme_section_close();
}
