<?php
/**
 * Section template: partners and documents.
 *
 * Five views: tiles, a running line, a grey row that turns to colour, coloured
 * tiles, documents with a preview and a download button. The head, the sign
 * beside it and the list come in the order the composition sets; a plate prints
 * its logo, name and the rest the same way, and a part without data is not
 * printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'partners', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_rows  = array();

if ( isset( $mvweb_block['props']['logos'] ) && is_array( $mvweb_block['props']['logos'] ) ) {
	foreach ( mvweb_core_visible_rows( $mvweb_block['props']['logos'] ) as $mvweb_row ) {
		if ( ! empty( $mvweb_row['image'] ) || '' !== trim( (string) ( isset( $mvweb_row['name'] ) ? $mvweb_row['name'] : '' ) ) ) {
			$mvweb_rows[] = $mvweb_row;
		}
	}
}

if ( empty( $mvweb_rows ) ) {
	return;
}

$mvweb_view   = $mvweb_block['mod'];
$mvweb_motion = '' !== $mvweb_block['motion'];
$mvweb_rv     = $mvweb_motion ? ' data-rv' : '';
$mvweb_host   = (string) wp_parse_url( home_url(), PHP_URL_HOST );
$mvweb_dup    = false;
$mvweb_badge  = false;

$mvweb_name = static function ( $item ) {
	return isset( $item['name'] ) ? trim( (string) $item['name'] ) : '';
};

$mvweb_shown = static function ( $item, $block, $slug ) use ( $mvweb_name ) {
	return in_array( $slug, $block['item_parts'], true ) && '' !== $mvweb_name( $item );
};

$mvweb_picture = static function ( $item, $css, $alt, $extra = array() ) {
	$id = isset( $item['image'] ) ? absint( $item['image'] ) : 0;

	if ( ! $id ) {
		return '';
	}

	return wp_get_attachment_image(
		$id,
		'medium',
		false,
		array_merge(
			array(
				'class'   => $css,
				'alt'     => $alt,
				'loading' => 'lazy',
			),
			$extra
		)
	);
};

$mvweb_logo_alt = static function ( $item, $block ) use ( $mvweb_shown, $mvweb_name ) {
	if ( $mvweb_shown( $item, $block, 'name' ) ) {
		return '';
	}

	$alt = isset( $item['image'] ) ? (string) get_post_meta( absint( $item['image'] ), '_wp_attachment_image_alt', true ) : '';

	return '' !== $alt ? $alt : $mvweb_name( $item );
};

$mvweb_file = static function ( $item ) {
	$url   = isset( $item['url'] ) ? (string) $item['url'] : '';
	$image = isset( $item['image'] ) ? absint( $item['image'] ) : 0;
	$id    = 0;

	if ( '' === $url && $image ) {
		$url = (string) wp_get_attachment_url( $image );
		$id  = $image;
	} elseif ( '' !== $url ) {
		$id = (int) attachment_url_to_postid( $url );
	}

	if ( '' === $url ) {
		return array(
			'url'  => '',
			'kind' => '',
		);
	}

	$extension = strtoupper( (string) pathinfo( (string) wp_parse_url( $url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
	$path      = $id ? get_attached_file( $id ) : '';
	$size      = $path && is_readable( $path ) ? size_format( (int) filesize( $path ), filesize( $path ) >= KB_IN_BYTES ? 1 : 0 ) : '';
	$kind      = array_filter( array( preg_match( '/^[A-Z0-9]{2,4}$/', $extension ) ? $extension : '', is_string( $size ) ? $size : '' ) );

	return array(
		'url'  => $url,
		'kind' => implode( ' · ', $kind ),
	);
};

$mvweb_initials = static function ( $item, $modifier = '' ) use ( $mvweb_name ) {
	$letters = mvweb_core_initials( $mvweb_name( $item ) );

	if ( '' === $letters ) {
		return '';
	}

	return '<span class="mvweb-t-partners__initials' . ( '' !== $modifier ? ' mvweb-t-partners__initials--' . esc_attr( $modifier ) : '' ) . '" aria-hidden="true">' . esc_html( $letters ) . '</span>';
};

$mvweb_item_parts = array(
	'image'    => static function ( $item, $block ) use ( $mvweb_picture, $mvweb_logo_alt, $mvweb_initials, $mvweb_name, $mvweb_file ) {
		if ( 'cards' === $block['mod'] ) {
			$id = isset( $item['image'] ) ? absint( $item['image'] ) : 0;

			if ( ! $id ) {
				return;
			}

			$name  = $mvweb_name( $item );
			$label = '' !== $name ? sprintf( /* translators: %s: document name. */ __( 'Open: %s', 'brand-market' ), $name ) : __( 'Open the document', 'brand-market' );
			$alt   = (string) get_post_meta( $id, '_wp_attachment_image_alt', true );

			echo '<a class="mvweb-t-partners__file-thumb" href="' . esc_url( (string) wp_get_attachment_url( $id ) ) . '" data-docs-open title="' . esc_attr( $label ) . '">' . $mvweb_picture( $item, '', '' !== $alt ? $alt : $name ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.

			return;
		}

		$alt = $mvweb_logo_alt( $item, $block );

		if ( 'mono' === $block['mod'] ) {
			$gray  = $mvweb_picture( $item, 'mvweb-t-partners__logo mvweb-t-partners__logo--gray', $alt );
			$color = $mvweb_picture( $item, 'mvweb-t-partners__logo mvweb-t-partners__logo--color', '', array( 'aria-hidden' => 'true' ) );

			if ( '' === $gray ) {
				$gray  = $mvweb_initials( $item, 'gray' );
				$color = $mvweb_initials( $item, 'color' );
			}

			if ( '' !== $gray ) {
				echo '<span class="mvweb-t-partners__pair">' . $gray . $color . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped markup.
			}

			return;
		}

		$picture = $mvweb_picture( $item, 'mvweb-t-partners__logo', $alt );

		echo '' !== $picture ? $picture : $mvweb_initials( $item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped markup.
	},
	'kind'     => static function ( $item, $block ) use ( $mvweb_file ) {
		$file = $mvweb_file( $item );

		if ( 'cards' === $block['mod'] && '' !== $file['kind'] ) {
			echo '<p class="mvweb-t-partners__file-kind">' . esc_html( $file['kind'] ) . '</p>';
		}
	},
	'name'     => static function ( $item, $block ) use ( $mvweb_name ) {
		$name = $mvweb_name( $item );

		if ( '' === $name ) {
			return;
		}

		echo 'cards' === $block['mod']
			? '<p class="mvweb-t-partners__file-title">' . esc_html( $name ) . '</p>'
			: '<span class="mvweb-t-partners__name">' . esc_html( $name ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	},
	'arrow'    => static function ( $item, $block ) {
		if ( 'color' === $block['mod'] && ! empty( $item['url'] ) ) {
			echo '<span class="mvweb-t-partners__go" aria-hidden="true">' . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
		}
	},
	'download' => static function ( $item, $block ) use ( $mvweb_file, $mvweb_name ) {
		$file = $mvweb_file( $item );

		if ( 'cards' !== $block['mod'] || '' === $file['url'] ) {
			return;
		}

		$name  = $mvweb_name( $item );
		$label = '' !== $name ? ' aria-label="' . esc_attr( sprintf( /* translators: %s: document name. */ __( 'Download: %s', 'brand-market' ), $name ) ) . '"' : '';

		echo '<a class="mvweb-t-btn mvweb-t-btn--sm mvweb-t-btn--outline mvweb-t-partners__file-get" href="' . esc_url( $file['url'] ) . '" download' . $label . '>' . esc_html__( 'Download', 'brand-market' ) . mvweb_theme_icon( 'arrow-up', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	},
	'note'     => static function ( $item, $block ) {
		if ( 'cards' === $block['mod'] && ! empty( $item['note'] ) ) {
			echo '<p class="mvweb-t-partners__file-note">' . esc_html( $item['note'] ) . '</p>';
		}
	},
);

$mvweb_collect = static function ( array $block, array $item, array $slugs ) use ( $mvweb_item_parts ) {
	$block['item_parts'] = array_values( array_intersect( $block['item_parts'], $slugs ) );

	ob_start();
	mvweb_theme_render_item_parts( $block, $item, $mvweb_item_parts );

	return (string) ob_get_clean();
};

$mvweb_link = static function ( $item, $css, $inner ) use ( $mvweb_host, &$mvweb_dup ) {
	$url = isset( $item['url'] ) ? (string) $item['url'] : '';

	if ( '' === $url ) {
		return '<div class="' . esc_attr( $css ) . '">' . $inner . '</div>';
	}

	$host     = (string) wp_parse_url( $url, PHP_URL_HOST );
	$external = '' !== $host && $host !== $mvweb_host;

	return '<a class="' . esc_attr( $css ) . '" href="' . esc_url( $url ) . '"' . ( $external ? ' target="_blank" rel="noopener"' : '' ) . ( $mvweb_dup ? ' tabindex="-1"' : '' ) . '>' . $inner . '</a>';
};

$mvweb_plate = static function ( $item, $block, $index ) use ( $mvweb_collect, $mvweb_link, $mvweb_rv ) {
	$view = $block['mod'];

	if ( 'cards' === $view ) {
		$thumb = $mvweb_collect( $block, $item, array( 'image' ) );
		$body  = $mvweb_collect( $block, $item, array( 'kind', 'name', 'download', 'note' ) );
		$dir   = 0 === $index % 2 ? '-1' : '1';

		if ( '' === $thumb && '' === $body ) {
			return '';
		}

		return '<li' . ( '' !== $mvweb_rv ? ' data-rv data-rv-dir="' . $dir . '"' : '' ) . '><div class="mvweb-t-partners__file">' . $thumb . ( '' !== $body ? '<div class="mvweb-t-partners__file-body">' . $body . '</div>' : '' ) . '</div></li>';
	}

	if ( 'color' === $view ) {
		$top  = $mvweb_collect( $block, $item, array( 'image' ) );
		$foot = $mvweb_collect( $block, $item, array( 'name', 'arrow' ) );
		$link = $mvweb_link( $item, 'mvweb-t-partners__swatch', ( '' !== $top ? '<span class="mvweb-t-partners__swatch-top">' . $top . '</span>' : '' ) . ( '' !== $foot ? '<span class="mvweb-t-partners__swatch-foot">' . $foot . '</span>' : '' ) );

		return '<li' . $mvweb_rv . '>' . $link . '</li>';
	}

	$inner = $mvweb_collect( $block, $item, array( 'image', 'name' ) );

	if ( '' === $inner ) {
		return '';
	}

	if ( 'marquee' === $view ) {
		return '<li>' . $mvweb_link( $item, 'mvweb-t-partners__chip', $inner ) . '</li>';
	}

	return '<li' . $mvweb_rv . '>' . $mvweb_link( $item, 'mono' === $view ? 'mvweb-t-partners__cell' : 'mvweb-t-partners__tile', $inner ) . '</li>';
};

$mvweb_list = static function ( $block ) use ( $mvweb_rows, $mvweb_plate, $mvweb_rv, &$mvweb_dup ) {
	$view    = $block['mod'];
	$classes = array(
		'mono'  => ' mvweb-t-partners__list--mono',
		'color' => ' mvweb-t-partners__list--color',
		'cards' => ' mvweb-t-partners__list--files',
	);
	$class   = 'mvweb-t-partners__list' . ( isset( $classes[ $view ] ) ? $classes[ $view ] : '' );

	if ( 'marquee' === $view ) {
		?>
		<div class="mvweb-t-partners__marquee"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
			<div class="mvweb-t-partners__track">
				<?php foreach ( array( false, true ) as $mvweb_dup ) : ?>
					<ul class="mvweb-t-partners__reel"<?php echo $mvweb_dup ? ' aria-hidden="true"' : ''; ?>>
						<?php
						foreach ( $mvweb_rows as $index => $item ) {
							echo $mvweb_plate( $item, $block, $index ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped markup.
						}
						?>
					</ul>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
		$mvweb_dup = false;

		return;
	}

	if ( 'cards' === $view ) {
		echo '<div class="mvweb-t-partners__docs">';
	}
	?>
	<ul class="<?php echo esc_attr( $class ); ?>"<?php echo 'cards' === $view ? ' data-docs' : ''; ?>>
		<?php
		foreach ( $mvweb_rows as $index => $item ) {
			echo $mvweb_plate( $item, $block, $index ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped markup.
		}
		?>
	</ul>
	<?php if ( 'cards' === $view ) : ?>
		<dialog class="mvweb-t-partners__box" data-docs-box aria-label="<?php esc_attr_e( 'Document preview', 'brand-market' ); ?>">
			<button class="mvweb-t-round mvweb-t-round--line mvweb-t-partners__box-close" type="button" data-docs-close title="<?php esc_attr_e( 'Close', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Close', 'brand-market' ); ?></span>
			</button>
			<img class="mvweb-t-partners__box-img" src="" alt="">
		</dialog>
		</div>
	<?php endif; ?>
	<?php
};

$mvweb_top = static function ( array $run ) use ( $mvweb_block, $mvweb_picture, &$mvweb_badge ) {
	$sub          = $mvweb_block;
	$sub['parts'] = $run;
	$mvweb_badge  = false;

	ob_start();
	mvweb_theme_render_parts(
		$sub,
		array(
			'badge' => static function ( $block ) use ( $mvweb_picture, &$mvweb_badge ) {
				$picture = $mvweb_picture( array( 'image' => isset( $block['props']['badge'] ) ? $block['props']['badge'] : 0 ), 'mvweb-t-partners__badge', (string) get_post_meta( isset( $block['props']['badge'] ) ? absint( $block['props']['badge'] ) : 0, '_wp_attachment_image_alt', true ) );

				if ( '' !== $picture ) {
					$mvweb_badge = true;
					echo $picture; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
				}
			},
		),
		array( 'rv' => true )
	);
	$html = (string) ob_get_clean();

	return $mvweb_badge ? '<div class="mvweb-t-partners__top">' . $html . '</div>' : $html;
};

$mvweb_bleed = 'marquee' === $mvweb_view;
$mvweb_heads = array( 'kicker', 'title', 'lead', 'more', 'badge' );
$mvweb_run   = array();

mvweb_theme_section_open( $mvweb_block, ! $mvweb_bleed );

foreach ( array_merge( $mvweb_block['parts'], array( '' ) ) as $mvweb_slug ) {
	if ( in_array( $mvweb_slug, $mvweb_heads, true ) ) {
		$mvweb_run[] = $mvweb_slug;
		continue;
	}

	if ( ! empty( $mvweb_run ) ) {
		$mvweb_head = $mvweb_top( $mvweb_run );
		$mvweb_run  = array();

		if ( '' !== $mvweb_head ) {
			echo $mvweb_bleed ? '<div class="mvweb-t-container">' . $mvweb_head . '</div>' : $mvweb_head; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped markup.
		}
	}

	if ( 'list' === $mvweb_slug ) {
		$mvweb_list( $mvweb_block );
	}
}

mvweb_theme_section_close( ! $mvweb_bleed );
