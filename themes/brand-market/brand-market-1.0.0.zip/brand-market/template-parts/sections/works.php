<?php
/**
 * Section template: works from the portfolio.
 *
 * Five views of the same cards: a grid, a mosaic with a large first card, a
 * photo whose caption appears on hover, a horizontal ribbon and a list with
 * rows. The cards are the card of a work, whose parts the site sets once; the
 * head comes in the order the composition sets. A block with no work to show
 * is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'works', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_ids   = mvweb_core_works(
	array(
		'count' => isset( $mvweb_props['count'] ) ? absint( $mvweb_props['count'] ) : 3,
		'type'  => isset( $mvweb_props['kind'] ) ? absint( $mvweb_props['kind'] ) : 0,
	)
);

if ( empty( $mvweb_ids ) ) {
	return;
}

if ( empty( $mvweb_props['link_url'] ) ) {
	$mvweb_block['props']['link_url'] = (string) get_post_type_archive_link( 'mv_work' );
}

$mvweb_layouts = array(
	'1' => 'grid',
	'2' => 'mosaic',
	'3' => 'reveal',
	'4' => 'ribbon',
	'5' => 'list',
);
$mvweb_layout  = isset( $mvweb_layouts[ $mvweb_block['view'] ] ) ? $mvweb_layouts[ $mvweb_block['view'] ] : 'grid';
$mvweb_motion  = '' !== $mvweb_block['motion'];
$mvweb_name    = isset( $mvweb_props['title'] ) && '' !== (string) $mvweb_props['title'] ? (string) $mvweb_props['title'] : mvweb_core_work_label();

$mvweb_parts = array(
	'list' => static function () use ( $mvweb_ids, $mvweb_layout, $mvweb_motion, $mvweb_name ) {
		$ribbon = 'ribbon' === $mvweb_layout;
		$label  = sprintf(
			/* translators: %s: heading of the block. */
			__( '%s, ribbon: scroll sideways', 'brand-market' ),
			$mvweb_name
		);
		$class  = array(
			'grid'   => 'grid',
			'mosaic' => 'grid',
			'reveal' => 'grid',
			'ribbon' => 'track',
			'list'   => 'list',
		);
		?>
		<div class="<?php echo esc_attr( 'mvweb-t-works__' . $class[ $mvweb_layout ] ); ?>"<?php echo $ribbon ? ' tabindex="0" role="region" aria-label="' . esc_attr( $label ) . '"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in place. ?>>
			<?php
			foreach ( $mvweb_ids as $mvweb_index => $mvweb_id ) {
				get_template_part(
					'template-parts/work/card',
					null,
					array(
						'id'    => $mvweb_id,
						'view'  => $mvweb_layout,
						'index' => $mvweb_index,
						'lead'  => 0 === $mvweb_index,
						'rv'    => $mvweb_motion,
					)
				);
			}
			?>
		</div>
		<?php
	},
);

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts( $mvweb_block, $mvweb_parts, array( 'rv' => true ) );
mvweb_theme_section_close();
