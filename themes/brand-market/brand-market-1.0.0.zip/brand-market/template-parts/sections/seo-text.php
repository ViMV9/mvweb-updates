<?php
/**
 * Section template: long text for search.
 *
 * Five views: a reading column, newspaper columns, a sticky heading beside the
 * text, the text on a card, a centred text with a lead. The text is the
 * editor's formatted text and is always in the markup. A long text is shown in
 * full, or sits in a native details element: closed, it is folded away or cut
 * by height (the lines are reserved in the style, so the layout never jumps),
 * the summary is the button. A short text is never folded. The heading can be
 * the h1 of the front page (see mvweb_theme_h1_reserve()); the headings inside
 * the text keep the editor's own levels. A block without a text prints nothing.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'seo-text', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_parts = $mvweb_block['parts'];
$mvweb_view  = $mvweb_block['mod'];
$mvweb_rv    = '' !== $mvweb_block['motion'] ? ' data-rv' : '';

$mvweb_value = static function ( $key ) use ( $mvweb_props ) {
	return isset( $mvweb_props[ $key ] ) ? trim( (string) $mvweb_props[ $key ] ) : '';
};

$mvweb_text = '' !== $mvweb_value( 'text' ) ? preg_replace( '#<(/?)h1(?=[\s>])#i', '<$1h2', wp_kses_post( wpautop( $mvweb_value( 'text' ) ) ) ) : '';

if ( '' === $mvweb_text ) {
	return;
}

$mvweb_mode = $mvweb_value( 'spoiler' );
$mvweb_fold = in_array( $mvweb_mode, array( 'height', 'all' ), true ) && in_array( 'text', $mvweb_parts, true ) && in_array( 'spoiler', $mvweb_parts, true );
$mvweb_mode = $mvweb_fold ? $mvweb_mode : 'none';

$mvweb_lines = absint( $mvweb_value( 'spoiler_lines' ) );
$mvweb_lines = $mvweb_lines > 0 ? min( 40, max( 3, $mvweb_lines ) ) : 8;

if ( 'height' === $mvweb_mode && mb_strlen( wp_strip_all_tags( $mvweb_text ) ) < $mvweb_lines * 70 && ! preg_match( '#<(table|ul|ol|dl|blockquote|pre|h[1-6])[\s>]#i', $mvweb_text ) ) {
	$mvweb_mode = 'none';
}

$mvweb_more = '' !== $mvweb_value( 'more_label' ) ? $mvweb_value( 'more_label' ) : _x( 'Read more', 'Text spoiler button', 'brand-market' );
$mvweb_less = '' !== $mvweb_value( 'less_label' ) ? $mvweb_value( 'less_label' ) : __( 'Collapse', 'brand-market' );

$mvweb_toggle = '<span class="mvweb-t-seo-text__more">' . esc_html( $mvweb_more ) . '</span><span class="mvweb-t-seo-text__less">' . esc_html( $mvweb_less ) . '</span>' . mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) );

$mvweb_tag = 'div';

if ( ! empty( $mvweb_props['title_h1'] ) && '' !== $mvweb_value( 'title' ) && in_array( 'title', $mvweb_parts, true ) && is_front_page() ) {
	$mvweb_tag = mvweb_theme_h1_tag( 'seo-text' );
}

$mvweb_head = array(
	'rv'        => true,
	'title_tag' => $mvweb_tag,
	'class'     => 'center' === $mvweb_view ? 'mvweb-t-section-head--center' : '',
);

$mvweb_renderers = array(
	'text'    => static function () use ( $mvweb_text, $mvweb_mode, $mvweb_lines, $mvweb_toggle, $mvweb_rv ) {
		if ( 'none' === $mvweb_mode ) {
			echo '<div class="mvweb-t-prose mvweb-t-seo-text__text"' . $mvweb_rv . '>' . $mvweb_text . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute, filtered text of the editor.

			return;
		}

		$class = 'height' === $mvweb_mode ? 'mvweb-t-seo-text__fold mvweb-t-seo-text__fold--cut' : 'mvweb-t-seo-text__fold';
		$style = 'height' === $mvweb_mode ? ' style="--mvweb-t-seo-lines:' . absint( $mvweb_lines ) . '"' : '';

		echo '<details class="' . esc_attr( $class ) . '"' . $style . $mvweb_rv . '><summary class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-seo-text__toggle">' . $mvweb_toggle . '</summary><div class="mvweb-t-prose mvweb-t-seo-text__text">' . $mvweb_text . '</div></details>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute, escaped values, filtered text of the editor.
	},
	'spoiler' => static function () {},
);

$mvweb_capture = static function ( array $slugs ) use ( $mvweb_block, $mvweb_renderers, $mvweb_head ) {
	$part = $mvweb_block;

	$part['parts'] = $slugs;

	ob_start();
	mvweb_theme_render_parts( $part, $mvweb_renderers, $mvweb_head );

	return trim( (string) ob_get_clean() );
};

$mvweb_aside = 'aside' === $mvweb_view;
$mvweb_intro = '';
$mvweb_body  = '';

if ( $mvweb_aside ) {
	$mvweb_intro = $mvweb_capture( array_values( array_intersect( $mvweb_parts, array( 'kicker', 'title' ) ) ) );
	$mvweb_body  = $mvweb_capture( array_values( array_diff( $mvweb_parts, array( 'kicker', 'title' ) ) ) );
} else {
	$mvweb_body = $mvweb_capture( $mvweb_parts );
}

if ( '' === $mvweb_intro && '' === $mvweb_body ) {
	return;
}

mvweb_theme_section_open( $mvweb_block, true );
?>
<?php if ( $mvweb_aside ) : ?>
	<div class="mvweb-t-seo-text__layout">
		<?php if ( '' !== $mvweb_intro ) : ?>
			<div class="mvweb-t-seo-text__intro">
				<?php echo $mvweb_intro; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part renderers above. ?>
			</div>
		<?php endif; ?>
		<?php if ( '' !== $mvweb_body ) : ?>
			<div class="mvweb-t-seo-text__body">
				<?php echo $mvweb_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part renderers above. ?>
			</div>
		<?php endif; ?>
	</div>
<?php else : ?>
	<div class="mvweb-t-seo-text__flow">
		<?php echo $mvweb_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part renderers above. ?>
	</div>
<?php endif; ?>
<?php
mvweb_theme_section_close();
