<?php
/**
 * Section template: what a client gets.
 *
 * Five views of one list: a card beside a photo, points around a photo,
 * numbered cards, rows with a photo each, lines with a figure. The head comes
 * first; the parts of the card come in the order the composition sets, the
 * columns of the other views stay where the view puts them. A point prints its
 * icon or number, name, text and figure the same way, and a part without data
 * is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'benefits', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_items = isset( $mvweb_props['items'] ) && is_array( $mvweb_props['items'] ) ? mvweb_core_visible_rows( $mvweb_props['items'] ) : array();

if ( empty( $mvweb_items ) ) {
	return;
}

$mvweb_view   = '' === $mvweb_block['mod'] ? 'card' : $mvweb_block['mod'];
$mvweb_rv     = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_parts  = $mvweb_block['parts'];
$mvweb_side   = $mvweb_block['look']['image_side'];
$mvweb_size   = $mvweb_block['look']['image_size'];
$mvweb_photo  = in_array( 'media', $mvweb_parts, true ) && ! empty( $mvweb_props['image'] ) && in_array( $mvweb_view, array( 'card', 'orbit' ), true ) ? wp_get_attachment_image( (int) $mvweb_props['image'], 'large' ) : '';
$mvweb_head   = array_values( array_intersect( $mvweb_parts, array( 'title', 'lead' ) ) );
$mvweb_tags   = array(
	'card'    => 'item',
	'orbit'   => 'point',
	'numbers' => 'cell',
	'rows'    => 'point',
	'checks'  => 'line',
);
$mvweb_joined = in_array( $mvweb_view, array( 'orbit', 'rows', 'checks' ), true );

$mvweb_groups = array();

if ( 'rows' === $mvweb_view && in_array( 'list', $mvweb_parts, true ) ) {
	foreach ( $mvweb_items as $mvweb_item ) {
		$mvweb_name = isset( $mvweb_item['group'] ) ? trim( (string) $mvweb_item['group'] ) : '';
		$mvweb_last = count( $mvweb_groups ) - 1;

		if ( $mvweb_last < 0 || $mvweb_groups[ $mvweb_last ]['name'] !== $mvweb_name ) {
			$mvweb_groups[] = array(
				'name'  => $mvweb_name,
				'image' => 0,
				'items' => array(),
			);
			$mvweb_last     = count( $mvweb_groups ) - 1;
		}

		if ( ! $mvweb_groups[ $mvweb_last ]['image'] && ! empty( $mvweb_item['image'] ) ) {
			$mvweb_groups[ $mvweb_last ]['image'] = (int) $mvweb_item['image'];
		}

		$mvweb_groups[ $mvweb_last ]['items'][] = $mvweb_item;
	}
}

$mvweb_extra = '';

if ( 'card' === $mvweb_view ) {
	$mvweb_extra .= '' === $mvweb_photo ? ' mvweb-t-benefits--no-photo' : ( 'end' === $mvweb_side ? '' : ' mvweb-t-benefits--image-start' );
}

if ( 'rows' === $mvweb_view && 'end' === $mvweb_side ) {
	$mvweb_extra .= ' mvweb-t-benefits--image-end';
}

if ( in_array( $mvweb_size, array( 's', 'l' ), true ) && ( '' !== $mvweb_photo || 'rows' === $mvweb_view ) ) {
	$mvweb_extra .= ' mvweb-t-benefits--image-' . $mvweb_size;
}

$mvweb_extra .= mvweb_theme_cards_colours( $mvweb_block );

$mvweb_render_item = static function ( $item, $number, $direction ) use ( $mvweb_view, $mvweb_tags, $mvweb_joined, $mvweb_rv, $mvweb_block ) {
	$title  = isset( $item['title'] ) ? trim( (string) $item['title'] ) : '';
	$text   = isset( $item['text'] ) ? trim( (string) $item['text'] ) : '';
	$figure = isset( $item['figure'] ) ? trim( (string) $item['figure'] ) : '';
	$pieces = array(
		'mark'   => '',
		'name'   => '',
		'text'   => '',
		'figure' => '',
	);

	if ( 'card' === $mvweb_view ) {
		$text = '' !== $text ? $text : $title;

		if ( '' === $text ) {
			return '';
		}

		$pieces['mark'] = '<span class="mvweb-t-benefits__check">' . mvweb_theme_icon( 'check' ) . '</span>';
		$pieces['text'] = '<span>' . esc_html( $text ) . '</span>';
	} else {
		if ( 'checks' === $mvweb_view ) {
			$pieces['mark'] = '<span class="mvweb-t-benefits__check">' . mvweb_theme_icon( 'check' ) . '</span>';
		} elseif ( 'numbers' === $mvweb_view ) {
			$pieces['mark'] = '<span class="mvweb-t-benefits__num" aria-hidden="true">' . esc_html( sprintf( '%02d', $number ) ) . '</span>';
		} elseif ( ! empty( $item['icon'] ) ) {
			$pieces['mark'] = '<span class="mvweb-t-benefits__mark">' . mvweb_theme_icon( $item['icon'] ) . '</span>';
		}

		$pieces['name']   = '' !== $title ? '<div class="mvweb-t-benefits__name">' . esc_html( $title ) . '</div>' : '';
		$pieces['text']   = '' !== $text ? '<p class="mvweb-t-benefits__desc">' . esc_html( $text ) . '</p>' : '';
		$pieces['figure'] = 'checks' === $mvweb_view && '' !== $figure ? '<span class="mvweb-t-benefits__figure">' . esc_html( $figure ) . '</span>' : '';
	}

	$html  = '';
	$inner = '';

	foreach ( $mvweb_block['item_parts'] as $slug ) {
		if ( ! isset( $pieces[ $slug ] ) ) {
			continue;
		}

		if ( $mvweb_joined && in_array( $slug, array( 'name', 'text' ), true ) ) {
			$inner .= $pieces[ $slug ];
			continue;
		}

		if ( '' !== $inner ) {
			$html .= '<div class="mvweb-t-benefits__text">' . $inner . '</div>';
			$inner = '';
		}

		$html .= $pieces[ $slug ];
	}

	if ( '' !== $inner ) {
		$html .= '<div class="mvweb-t-benefits__text">' . $inner . '</div>';
	}

	return '<li class="mvweb-t-benefits__' . $mvweb_tags[ $mvweb_view ] . '"' . $mvweb_rv . ( '' !== $direction && '' !== $mvweb_rv ? ' data-rv-dir="' . $direction . '"' : '' ) . '>' . $html . '</li>';
};

$mvweb_render_items = static function ( array $items, $offset = 0, $direction = '' ) use ( $mvweb_render_item ) {
	$html = '';

	foreach ( $items as $index => $item ) {
		$html .= $mvweb_render_item( $item, $offset + $index + 1, $direction );
	}

	return $html;
};

mvweb_theme_section_open( $mvweb_block, true, ltrim( $mvweb_extra ) );

if ( 'checks' === $mvweb_view ) {
	echo '<div class="mvweb-t-benefits__wrap">';
}

mvweb_theme_head( $mvweb_block, $mvweb_head, array( 'rv' => true ) );

if ( 'card' === $mvweb_view ) {
	$mvweb_body = '';

	foreach ( array_intersect( $mvweb_parts, array( 'card_icon', 'card_title', 'list' ) ) as $mvweb_slug ) {
		if ( 'card_icon' === $mvweb_slug && ! empty( $mvweb_props['icon'] ) ) {
			$mvweb_body .= '<span class="mvweb-t-benefits__icon"' . $mvweb_rv . '>' . mvweb_theme_icon( $mvweb_props['icon'] ) . '</span>';
		} elseif ( 'card_title' === $mvweb_slug && ! empty( $mvweb_props['card_title'] ) ) {
			$mvweb_body .= '<div class="mvweb-t-benefits__title mvweb-t-h3"' . $mvweb_rv . '>' . esc_html( (string) $mvweb_props['card_title'] ) . '</div>';
		} elseif ( 'list' === $mvweb_slug ) {
			$mvweb_body .= '<ul class="mvweb-t-benefits__list">' . $mvweb_render_items( $mvweb_items ) . '</ul>';
		}
	}

	$mvweb_media = '' !== $mvweb_photo ? '<div class="mvweb-t-benefits__media"' . $mvweb_rv . '>' . $mvweb_photo . '</div>' : '';

	if ( '' !== $mvweb_body || '' !== $mvweb_media ) {
		echo '<div class="mvweb-t-benefits__card">' . ( '' !== $mvweb_body ? '<div class="mvweb-t-benefits__body">' . $mvweb_body . '</div>' : '' ) . $mvweb_media . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and attachment markup.
	}
} elseif ( 'orbit' === $mvweb_view ) {
	$mvweb_half  = (int) ceil( count( $mvweb_items ) / 2 );
	$mvweb_start = in_array( 'list', $mvweb_parts, true ) ? $mvweb_render_items( array_slice( $mvweb_items, 0, $mvweb_half ) ) : '';
	$mvweb_end   = in_array( 'list', $mvweb_parts, true ) ? $mvweb_render_items( array_slice( $mvweb_items, $mvweb_half ), $mvweb_half ) : '';

	if ( '' !== $mvweb_photo || '' !== $mvweb_start ) {
		echo '<div class="mvweb-t-benefits__orbit">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.
		echo '' !== $mvweb_photo ? '<div class="mvweb-t-benefits__hub"' . $mvweb_rv . '>' . $mvweb_photo . '</div>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and attachment markup.
		echo '' !== $mvweb_start ? '<ul class="mvweb-t-benefits__side mvweb-t-benefits__side--start">' . $mvweb_start . '</ul>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
		echo '' !== $mvweb_end ? '<ul class="mvweb-t-benefits__side mvweb-t-benefits__side--end">' . $mvweb_end . '</ul>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
		echo '</div>';
	}
} elseif ( 'numbers' === $mvweb_view ) {
	if ( in_array( 'list', $mvweb_parts, true ) ) {
		echo '<ol class="mvweb-t-benefits__cells">' . $mvweb_render_items( $mvweb_items ) . '</ol>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	}
} elseif ( 'rows' === $mvweb_view ) {
	if ( ! empty( $mvweb_groups ) ) {
		echo '<div class="mvweb-t-benefits__rows">';

		$mvweb_offset = 0;

		foreach ( $mvweb_groups as $mvweb_index => $mvweb_group ) {
			$mvweb_left = ( 0 === $mvweb_index % 2 ) !== ( 'end' === $mvweb_side );
			$mvweb_pic  = in_array( 'media', $mvweb_parts, true ) && $mvweb_group['image'] ? wp_get_attachment_image( $mvweb_group['image'], 'large' ) : '';
			$mvweb_copy = '';

			if ( in_array( 'card_title', $mvweb_parts, true ) && '' !== $mvweb_group['name'] ) {
				$mvweb_copy .= '<div class="mvweb-t-benefits__group mvweb-t-h3"' . ( '' !== $mvweb_rv ? ' data-rv data-rv-dir="' . ( $mvweb_left ? '1' : '-1' ) . '"' : '' ) . '>' . esc_html( $mvweb_group['name'] ) . '</div>';
			}

			$mvweb_copy .= '<ul class="mvweb-t-benefits__list">' . $mvweb_render_items( $mvweb_group['items'], $mvweb_offset, $mvweb_left ? '1' : '-1' ) . '</ul>';

			$mvweb_offset += count( $mvweb_group['items'] );

			echo '<article class="mvweb-t-benefits__row">' . ( '' !== $mvweb_pic ? '<div class="mvweb-t-benefits__pic"' . ( '' !== $mvweb_rv ? ' data-rv data-rv-dir="' . ( $mvweb_left ? '-1' : '1' ) . '"' : '' ) . '>' . $mvweb_pic . '</div>' : '' ) . '<div class="mvweb-t-benefits__copy">' . $mvweb_copy . '</div></article>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and attachment markup.
		}

		echo '</div>';
	}
} elseif ( in_array( 'list', $mvweb_parts, true ) ) {
	echo '<ul class="mvweb-t-benefits__lines">' . $mvweb_render_items( $mvweb_items ) . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
}

if ( 'checks' === $mvweb_view ) {
	echo '</div>';
}

mvweb_theme_section_close();
