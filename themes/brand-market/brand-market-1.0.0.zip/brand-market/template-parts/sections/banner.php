<?php
/**
 * Section template: wide banner.
 *
 * Five views: a photo with text and an offer beside it, an accent strip with
 * a sticker, a card with the saving counted from the two prices, a photo
 * beside text, a running line. The heading, lead, prices and button come in
 * the order the composition sets inside the text side of the view; the
 * picture, the sticker, the saving and the running line keep their place and
 * only hide. A part without data is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'banner', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_mod   = $mvweb_block['mod'];
$mvweb_look  = $mvweb_block['look'];
$mvweb_rv    = '' !== $mvweb_block['motion'] ? ' data-rv' : '';

$mvweb_text = static function ( $key ) use ( $mvweb_props ) {
	return isset( $mvweb_props[ $key ] ) ? trim( (string) $mvweb_props[ $key ] ) : '';
};

$mvweb_image = isset( $mvweb_props['image'] ) ? absint( $mvweb_props['image'] ) : 0;
$mvweb_image = $mvweb_image > 0 && wp_attachment_is_image( $mvweb_image ) ? $mvweb_image : 0;
$mvweb_title = $mvweb_text( 'title' );
$mvweb_lead  = $mvweb_text( 'text' );
$mvweb_tag   = $mvweb_text( 'tag' );
$mvweb_label = $mvweb_text( 'button_text' );
$mvweb_url   = $mvweb_text( 'button_url' );
$mvweb_new   = $mvweb_text( 'price_new' );
$mvweb_old   = $mvweb_text( 'price_old' );
$mvweb_last  = '' !== $mvweb_text( 'until' ) ? date_create_immutable( $mvweb_text( 'until' ), wp_timezone() ) : false;
$mvweb_until = $mvweb_last ? sprintf(
	/* translators: %s: last day of the offer, such as 31 October. */
	__( 'Offer until %s', 'brand-market' ),
	wp_date( 'j F', $mvweb_last->getTimestamp() )
) : '';

if ( ! $mvweb_image && '' === $mvweb_title && '' === $mvweb_lead && '' === $mvweb_new && ( '' === $mvweb_label || '' === $mvweb_url ) ) {
	return;
}

$mvweb_amount = static function ( $price ) {
	$digits = preg_replace( '/[^\d.,]/u', '', $price );
	$digits = str_replace( ',', '.', (string) $digits );

	if ( substr_count( $digits, '.' ) > 1 ) {
		$digits = str_replace( '.', '', substr( $digits, 0, (int) strrpos( $digits, '.' ) ) ) . substr( $digits, (int) strrpos( $digits, '.' ) );
	}

	return is_numeric( $digits ) ? (float) $digits : null;
};

$mvweb_saving = '';
$mvweb_from   = $mvweb_amount( $mvweb_old );
$mvweb_to     = $mvweb_amount( $mvweb_new );

if ( null !== $mvweb_from && null !== $mvweb_to && $mvweb_from > $mvweb_to ) {
	$mvweb_diff   = $mvweb_from - $mvweb_to;
	$mvweb_sign   = trim( (string) preg_replace( '/[\d\s\x{00a0}.,]+/u', '', $mvweb_new ) );
	$mvweb_figure = number_format_i18n( $mvweb_diff, floor( $mvweb_diff ) === $mvweb_diff ? 0 : 2 );

	if ( '' === $mvweb_sign ) {
		$mvweb_saving = "\u{2212}" . $mvweb_figure;
	} elseif ( 1 === preg_match( '/^\D/u', $mvweb_new ) ) {
		$mvweb_saving = "\u{2212}" . $mvweb_sign . $mvweb_figure;
	} else {
		$mvweb_saving = "\u{2212}" . $mvweb_figure . "\u{00a0}" . $mvweb_sign;
	}
}

$mvweb_reel = mvweb_core_text_lines( $mvweb_text( 'ticker' ) );

if ( empty( $mvweb_reel ) ) {
	$mvweb_reel = array_values(
		array_filter(
			array(
				$mvweb_title,
				'' !== $mvweb_new && '' !== $mvweb_old ? sprintf(
					/* translators: 1: price, 2: old price. */
					__( '%1$s instead of %2$s', 'brand-market' ),
					$mvweb_new,
					$mvweb_old
				) : '',
				$mvweb_until,
			),
			'strlen'
		)
	);
}

$mvweb_kinds = array(
	'secondary' => ' mvweb-t-btn--outline',
	'link'      => ' mvweb-t-btn--link',
);
$mvweb_kind  = isset( $mvweb_kinds[ $mvweb_look['button_kind'] ] ) ? $mvweb_kinds[ $mvweb_look['button_kind'] ] : '';
$mvweb_extra = '';

if ( in_array( $mvweb_mod, array( 'strip', 'split' ), true ) && 'end' === $mvweb_look['image_side'] ) {
	$mvweb_extra .= ' mvweb-t-banner--image-end';
}

if ( in_array( $mvweb_mod, array( 'strip', 'deal', 'split' ), true ) && 'm' !== $mvweb_look['image_size'] ) {
	$mvweb_extra .= ' mvweb-t-banner--size-' . $mvweb_look['image_size'];
}

$mvweb_groups = array(
	''       => array( 'title', 'lead', 'button' ),
	'strip'  => array( 'title', 'lead' ),
	'deal'   => array( 'title', 'lead', 'prices', 'button' ),
	'split'  => array( 'tag', 'title', 'lead', 'button' ),
	'ticker' => array(),
);
$mvweb_shown  = static function ( $slug ) use ( $mvweb_block ) {
	return in_array( $slug, $mvweb_block['parts'], true );
};

$mvweb_renderers = array(
	'tag'    => static function () use ( $mvweb_tag, $mvweb_rv ) {
		if ( '' !== $mvweb_tag ) {
			echo '<span class="mvweb-t-banner__tag"' . $mvweb_rv . '>' . esc_html( $mvweb_tag ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute, escaped text.
		}
	},
	'title'  => static function () use ( $mvweb_title, $mvweb_props, $mvweb_rv ) {
		if ( '' !== $mvweb_title ) {
			echo '<div class="mvweb-t-banner__title mvweb-t-h2"' . $mvweb_rv . '>' . esc_html( $mvweb_title ) . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute, escaped values.
		}
	},
	'lead'   => static function () use ( $mvweb_lead, $mvweb_rv ) {
		if ( '' !== $mvweb_lead ) {
			echo '<p class="mvweb-t-banner__lead"' . $mvweb_rv . '>' . esc_html( $mvweb_lead ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute, escaped text.
		}
	},
	'prices' => static function () use ( $mvweb_new, $mvweb_old, $mvweb_mod, $mvweb_rv ) {
		if ( '' !== $mvweb_new ) {
			echo '<p class="mvweb-t-banner__prices"' . ( 'deal' === $mvweb_mod ? $mvweb_rv : '' ) . '><span class="mvweb-t-banner__price">' . esc_html( $mvweb_new ) . '</span>' . ( '' !== $mvweb_old ? '<s class="mvweb-t-banner__price-old">' . esc_html( $mvweb_old ) . '</s>' : '' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute, escaped text.
		}
	},
	'until'  => static function () use ( $mvweb_until ) {
		if ( '' !== $mvweb_until ) {
			echo '<p class="mvweb-t-banner__until">' . mvweb_theme_icon( 'calendar', array( 'class' => 'mvweb-t-icon--sm' ) ) . esc_html( $mvweb_until ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Icon helper and escaped text.
		}
	},
	'button' => static function () use ( $mvweb_label, $mvweb_url, $mvweb_mod, $mvweb_kind, $mvweb_rv ) {
		if ( '' === $mvweb_label || '' === $mvweb_url ) {
			return;
		}

		$mvweb_arrow = mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) );

		if ( '' === $mvweb_mod ) {
			echo '<a class="mvweb-t-banner__link"' . $mvweb_rv . ' href="' . esc_url( $mvweb_url ) . '"><span>' . esc_html( $mvweb_label ) . '</span><span class="mvweb-t-round mvweb-t-round--accent">' . $mvweb_arrow . '</span></a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup, escaped values.

			return;
		}

		echo '<a class="mvweb-t-btn' . esc_attr( $mvweb_kind ) . ' mvweb-t-banner__btn"' . $mvweb_rv . ' href="' . esc_url( $mvweb_url ) . '"><span>' . esc_html( $mvweb_label ) . '</span>' . $mvweb_arrow . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup, escaped values.
	},
);

$mvweb_capture = static function ( array $slugs ) use ( $mvweb_renderers ) {
	ob_start();

	foreach ( $slugs as $mvweb_slug ) {
		if ( isset( $mvweb_renderers[ $mvweb_slug ] ) ) {
			call_user_func( $mvweb_renderers[ $mvweb_slug ] );
		}
	}

	return (string) ob_get_clean();
};

$mvweb_picture = static function ( $size, array $attr ) use ( $mvweb_image ) {
	return $mvweb_image ? wp_get_attachment_image( $mvweb_image, $size, false, array_merge( array( 'decoding' => 'async' ), $attr ) ) : '';
};

$mvweb_order = array_values( array_intersect( $mvweb_block['parts'], $mvweb_groups[ $mvweb_mod ] ) );
$mvweb_main  = $mvweb_capture( $mvweb_order );

ob_start();

if ( '' === $mvweb_mod ) :
	$mvweb_offer = $mvweb_capture( array_values( array_intersect( $mvweb_block['parts'], array( 'prices', 'until' ) ) ) );
	?>
	<div class="mvweb-t-banner__box">
		<?php echo $mvweb_picture( 'mvweb_wide', array( 'class' => 'mvweb-t-banner__img' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup. ?>
		<?php if ( '' !== $mvweb_main || '' !== $mvweb_offer ) : ?>
			<div class="mvweb-t-banner__body">
				<?php if ( '' !== $mvweb_main ) : ?>
					<div class="mvweb-t-banner__text">
						<?php echo $mvweb_main; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
					</div>
				<?php endif; ?>
				<?php if ( '' !== $mvweb_offer ) : ?>
					<div class="mvweb-t-banner__offer"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
						<?php echo $mvweb_offer; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
					</div>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</div>
	<?php
elseif ( 'strip' === $mvweb_mod ) :
	$mvweb_thumb = '';

	if ( $mvweb_image ) {
		$mvweb_sticker = '';

		if ( $mvweb_shown( 'sticker' ) && ( '' !== $mvweb_text( 'sticker_num' ) || '' !== $mvweb_text( 'sticker_text' ) ) ) {
			$mvweb_sticker = '<span class="mvweb-t-banner__sticker">' . ( '' !== $mvweb_text( 'sticker_num' ) ? '<strong>' . esc_html( $mvweb_text( 'sticker_num' ) ) . '</strong>' : '' ) . ( '' !== $mvweb_text( 'sticker_text' ) ? '<span>' . esc_html( $mvweb_text( 'sticker_text' ) ) . '</span>' : '' ) . '</span>';
		}

		$mvweb_thumb = '<div class="mvweb-t-banner__thumb"' . $mvweb_rv . '><div class="mvweb-t-banner__frame">' . $mvweb_picture( 'mvweb_card', array( 'class' => 'mvweb-t-banner__thumb-img' ) ) . '</div>' . $mvweb_sticker . '</div>';
	}

	$mvweb_button = $mvweb_shown( 'button' ) ? $mvweb_capture( array( 'button' ) ) : '';
	?>
	<?php if ( '' !== $mvweb_thumb || '' !== $mvweb_main || '' !== $mvweb_button ) : ?>
		<div class="mvweb-t-banner__plate">
			<?php echo $mvweb_thumb; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
			<?php if ( '' !== $mvweb_main ) : ?>
				<div class="mvweb-t-banner__info">
					<?php echo $mvweb_main; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
				</div>
			<?php endif; ?>
			<?php echo $mvweb_button; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
		</div>
	<?php endif; ?>
	<?php
elseif ( 'deal' === $mvweb_mod ) :
	$mvweb_panel = '';

	if ( $mvweb_shown( 'sale' ) && '' !== $mvweb_saving ) {
		$mvweb_panel .= ( '' !== $mvweb_text( 'sale_label' ) ? '<span class="mvweb-t-banner__sale-label">' . esc_html( $mvweb_text( 'sale_label' ) ) . '</span>' : '' ) . '<span class="mvweb-t-banner__sale-num">' . esc_html( $mvweb_saving ) . '</span>';
	}

	if ( $mvweb_shown( 'until' ) && '' !== $mvweb_until ) {
		$mvweb_panel .= '<span class="mvweb-t-banner__timer">' . mvweb_theme_icon( 'hourglass', array( 'class' => 'mvweb-t-icon--sm mvweb-t-banner__timer-icon' ) ) . esc_html( $mvweb_until ) . '</span>';
	}
	?>
	<?php if ( '' !== $mvweb_panel || '' !== $mvweb_main || $mvweb_image ) : ?>
		<div class="mvweb-t-banner__card">
			<?php if ( '' !== $mvweb_panel ) : ?>
				<div class="mvweb-t-banner__sale"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
					<?php echo $mvweb_panel; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
				</div>
			<?php endif; ?>
			<?php if ( '' !== $mvweb_main ) : ?>
				<div class="mvweb-t-banner__info">
					<?php echo $mvweb_main; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
				</div>
			<?php endif; ?>
			<?php if ( $mvweb_image ) : ?>
				<div class="mvweb-t-banner__frame mvweb-t-banner__frame--photo"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
					<?php echo $mvweb_picture( 'large', array( 'class' => 'mvweb-t-banner__pan' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup. ?>
				</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<?php
elseif ( 'split' === $mvweb_mod ) :
	?>
	<?php if ( $mvweb_image || '' !== $mvweb_main ) : ?>
		<div class="mvweb-t-banner__pair">
			<?php if ( $mvweb_image ) : ?>
				<div class="mvweb-t-banner__frame mvweb-t-banner__frame--wide"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
					<?php echo $mvweb_picture( 'mvweb_wide', array( 'class' => 'mvweb-t-banner__pan' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup. ?>
				</div>
			<?php endif; ?>
			<?php if ( '' !== $mvweb_main ) : ?>
				<div class="mvweb-t-banner__info">
					<?php echo $mvweb_main; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
				</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<?php
else :
	$mvweb_marquee = '';
	$mvweb_count   = count( $mvweb_reel );

	if ( $mvweb_shown( 'reel' ) && $mvweb_count ) {
		$mvweb_repeat = (int) ceil( 4 / $mvweb_count );

		for ( $mvweb_copy = 0; $mvweb_copy < 2; $mvweb_copy++ ) {
			$mvweb_marquee .= 0 === $mvweb_copy ? '<ul class="mvweb-t-banner__reel">' : '<ul class="mvweb-t-banner__reel" aria-hidden="true">';

			for ( $mvweb_line = 0; $mvweb_line < $mvweb_count * $mvweb_repeat; $mvweb_line++ ) {
				$mvweb_marquee .= ( 0 === $mvweb_copy && $mvweb_line >= $mvweb_count ? '<li class="mvweb-t-banner__item" aria-hidden="true">' : '<li class="mvweb-t-banner__item">' ) . esc_html( $mvweb_reel[ $mvweb_line % $mvweb_count ] ) . '</li>';
			}

			$mvweb_marquee .= '</ul>';
		}

		$mvweb_marquee = '<div class="mvweb-t-banner__marquee"' . $mvweb_rv . '><div class="mvweb-t-banner__track">' . $mvweb_marquee . '</div></div>';
	}

	$mvweb_band = $mvweb_capture( array_values( array_intersect( $mvweb_block['parts'], array( 'tag' ) ) ) ) . $mvweb_marquee . ( $mvweb_shown( 'button' ) ? $mvweb_capture( array( 'button' ) ) : '' );
	?>
	<?php if ( '' !== $mvweb_band ) : ?>
		<div class="mvweb-t-banner__band">
			<?php echo $mvweb_band; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
		</div>
	<?php endif; ?>
	<?php
endif;

$mvweb_html = trim( (string) ob_get_clean() );

if ( '' === $mvweb_html ) {
	return;
}

mvweb_theme_section_open( $mvweb_block, true, trim( $mvweb_extra ) );
echo $mvweb_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts.
mvweb_theme_section_close();
