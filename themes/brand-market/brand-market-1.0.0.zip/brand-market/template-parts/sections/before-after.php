<?php
/**
 * Section template: before and after.
 *
 * Five views of the same jobs: a slider between the photos, two photos side by
 * side, a card with figures, a round lens, a grid of small pairs. The jobs are
 * the rows of the block or the works of the portfolio that carry both photos.
 * A job with one photo missing is skipped; the head, the jobs and the button
 * come in the order the composition sets, and a part with no data is not
 * printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'before-after', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_pairs = array();

$mvweb_facts = static function ( $lines ) {
	$facts = array();

	foreach ( mvweb_core_text_lines( (string) $lines ) as $line ) {
		$cells = array_map( 'trim', explode( ':', $line, 2 ) );

		if ( 2 === count( $cells ) && '' !== $cells[0] && '' !== $cells[1] ) {
			$facts[] = $cells;
		}
	}

	return array_slice( $facts, 0, 3 );
};

if ( isset( $mvweb_props['source'] ) && 'works' === $mvweb_props['source'] ) {
	$mvweb_query = array(
		'post_type'      => 'mv_work',
		'post_status'    => 'publish',
		'posts_per_page' => isset( $mvweb_props['count'] ) ? max( 1, absint( $mvweb_props['count'] ) ) : 2,
		'orderby'        => array(
			'menu_order' => 'ASC',
			'date'       => 'DESC',
		),
		'fields'         => 'ids',
		'no_found_rows'  => true,
		'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- A handful of works on one page.
			array(
				'key'     => '_mvweb_before',
				'value'   => 0,
				'compare' => '>',
				'type'    => 'NUMERIC',
			),
			array(
				'key'     => '_mvweb_after',
				'value'   => 0,
				'compare' => '>',
				'type'    => 'NUMERIC',
			),
		),
	);

	if ( ! empty( $mvweb_props['kind'] ) ) {
		$mvweb_query['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Same.
			array(
				'taxonomy' => 'mv_work_type',
				'terms'    => absint( $mvweb_props['kind'] ),
			),
		);
	}

	foreach ( get_posts( $mvweb_query ) as $mvweb_work ) {
		$mvweb_pairs[] = array(
			'before' => absint( get_post_meta( $mvweb_work, '_mvweb_before', true ) ),
			'after'  => absint( get_post_meta( $mvweb_work, '_mvweb_after', true ) ),
			'title'  => get_the_title( $mvweb_work ),
			'text'   => (string) get_post_meta( $mvweb_work, '_mvweb_result', true ),
			'facts'  => array_map(
				static function ( $fact ) {
					return array( $fact['label'], $fact['value'] );
				},
				array_filter(
					mvweb_core_work_facts( $mvweb_work, 3 ),
					static function ( $fact ) {
						return '' !== $fact['label'];
					}
				)
			),
		);
	}
} elseif ( isset( $mvweb_props['pairs'] ) && is_array( $mvweb_props['pairs'] ) ) {
	foreach ( mvweb_core_visible_rows( $mvweb_props['pairs'] ) as $mvweb_row ) {
		$mvweb_pairs[] = array(
			'before' => isset( $mvweb_row['before'] ) ? absint( $mvweb_row['before'] ) : 0,
			'after'  => isset( $mvweb_row['after'] ) ? absint( $mvweb_row['after'] ) : 0,
			'title'  => isset( $mvweb_row['title'] ) ? (string) $mvweb_row['title'] : '',
			'text'   => isset( $mvweb_row['text'] ) ? (string) $mvweb_row['text'] : '',
			'facts'  => $mvweb_facts( isset( $mvweb_row['facts'] ) ? $mvweb_row['facts'] : '' ),
		);
	}
}

$mvweb_pairs = array_values(
	array_filter(
		$mvweb_pairs,
		static function ( $pair ) {
			return wp_attachment_is_image( $pair['before'] ) && wp_attachment_is_image( $pair['after'] );
		}
	)
);

if ( empty( $mvweb_pairs ) ) {
	return;
}

$mvweb_view   = $mvweb_block['mod'];
$mvweb_motion = '' !== $mvweb_block['motion'];
$mvweb_rv     = $mvweb_motion ? ' data-rv' : '';
$mvweb_marks  = array(
	'before' => array_key_exists( 'label_before', $mvweb_props ) ? trim( (string) $mvweb_props['label_before'] ) : __( 'Before', 'brand-market' ),
	'after'  => array_key_exists( 'label_after', $mvweb_props ) ? trim( (string) $mvweb_props['label_after'] ) : __( 'After', 'brand-market' ),
);
$mvweb_marked = mvweb_core_has_part( $mvweb_props, 'labels', 'item_parts' );

$mvweb_photo = static function ( $id, $css, $side, $title ) use ( $mvweb_marks ) {
	$alt = trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) );

	if ( '' === $alt ) {
		$mark = '' !== $mvweb_marks[ $side ] ? $mvweb_marks[ $side ] : ( 'before' === $side ? __( 'Before', 'brand-market' ) : __( 'After', 'brand-market' ) );
		$alt  = '' !== $title ? $mark . ': ' . $title : $mark;
	}

	$attributes = array(
		'alt'      => $alt,
		'loading'  => 'lazy',
		'decoding' => 'async',
	);

	if ( '' !== $css ) {
		$attributes['class'] = $css;
	}

	return wp_get_attachment_image( $id, 'large', false, $attributes );
};

$mvweb_frame = static function ( $pair ) use ( $mvweb_photo, $mvweb_marks, $mvweb_marked ) {
	$label = '' !== $pair['title']
		/* translators: %s: caption of the job. */
		? sprintf( __( 'Compare before and after: %s', 'brand-market' ), $pair['title'] )
		: __( 'Compare before and after', 'brand-market' );
	?>
	<div class="mvweb-t-before-after__frame">
		<?php echo $mvweb_photo( $pair['after'], 'mvweb-t-before-after__img', 'after', $pair['title'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core's escaped image markup. ?>
		<?php echo $mvweb_photo( $pair['before'], 'mvweb-t-before-after__img mvweb-t-before-after__img--before', 'before', $pair['title'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Same. ?>
		<?php if ( $mvweb_marked && '' !== $mvweb_marks['before'] ) : ?>
			<span class="mvweb-t-badge mvweb-t-before-after__label mvweb-t-before-after__label--before"><?php echo esc_html( $mvweb_marks['before'] ); ?></span>
		<?php endif; ?>
		<?php if ( $mvweb_marked && '' !== $mvweb_marks['after'] ) : ?>
			<span class="mvweb-t-badge mvweb-t-before-after__label mvweb-t-before-after__label--after"><?php echo esc_html( $mvweb_marks['after'] ); ?></span>
		<?php endif; ?>
		<span class="mvweb-t-before-after__handle" aria-hidden="true"><span class="mvweb-t-before-after__knob"><?php echo mvweb_theme_icon( 'arrows-left-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span></span>
		<input class="mvweb-t-before-after__range" type="range" min="0" max="100" value="50" step="1" data-ba-range aria-label="<?php echo esc_attr( $label ); ?>">
	</div>
	<?php
};

$mvweb_item_parts = array(
	'title' => static function ( $item ) {
		if ( '' !== $item['title'] ) {
			echo '<div class="mvweb-t-before-after__title mvweb-t-h3">' . esc_html( $item['title'] ) . '</div>';
		}
	},
	'text'  => static function ( $item ) {
		if ( '' !== $item['text'] ) {
			echo '<p class="mvweb-t-before-after__text">' . esc_html( $item['text'] ) . '</p>';
		}
	},
	'facts' => static function ( $item, $block ) {
		if ( 'card' !== $block['mod'] || empty( $item['facts'] ) ) {
			return;
		}
		?>
		<dl class="mvweb-t-before-after__facts">
			<?php foreach ( $item['facts'] as $fact ) : ?>
				<div><dt><?php echo esc_html( $fact[0] ); ?></dt><dd><?php echo esc_html( $fact[1] ); ?></dd></div>
			<?php endforeach; ?>
		</dl>
		<?php
	},
);

$mvweb_has_info = static function ( $pair ) use ( $mvweb_block ) {
	$shown = $mvweb_block['item_parts'];

	return ( in_array( 'title', $shown, true ) && '' !== $pair['title'] )
		|| ( in_array( 'text', $shown, true ) && '' !== $pair['text'] )
		|| ( in_array( 'facts', $shown, true ) && 'card' === $mvweb_block['mod'] && ! empty( $pair['facts'] ) );
};

$mvweb_info = static function ( $pair ) use ( $mvweb_block, $mvweb_item_parts, $mvweb_has_info ) {
	if ( ! $mvweb_has_info( $pair ) ) {
		return;
	}
	?>
	<div class="mvweb-t-before-after__info">
		<?php mvweb_theme_render_item_parts( $mvweb_block, $pair, $mvweb_item_parts ); ?>
	</div>
	<?php
};

$mvweb_parts = array(
	'list'   => static function () use ( $mvweb_pairs, $mvweb_view, $mvweb_rv, $mvweb_frame, $mvweb_info, $mvweb_has_info, $mvweb_photo, $mvweb_marks, $mvweb_marked ) {
		?>
		<div class="mvweb-t-before-after__list">
			<?php foreach ( $mvweb_pairs as $mvweb_pair ) : ?>
				<?php if ( 'duo' === $mvweb_view ) : ?>
					<article class="mvweb-t-before-after__pair">
						<div class="mvweb-t-before-after__duo">
							<figure class="mvweb-t-before-after__shot"<?php echo $mvweb_rv ? ' data-rv data-rv-dir="-1"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
								<?php echo $mvweb_photo( $mvweb_pair['before'], '', 'before', $mvweb_pair['title'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core's escaped image markup. ?>
								<?php if ( $mvweb_marked && '' !== $mvweb_marks['before'] ) : ?>
									<figcaption class="mvweb-t-badge mvweb-t-before-after__cap"><?php echo esc_html( $mvweb_marks['before'] ); ?></figcaption>
								<?php endif; ?>
							</figure>
							<figure class="mvweb-t-before-after__shot mvweb-t-before-after__shot--after"<?php echo $mvweb_rv ? ' data-rv data-rv-dir="1"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
								<?php echo $mvweb_photo( $mvweb_pair['after'], '', 'after', $mvweb_pair['title'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Same. ?>
								<?php if ( $mvweb_marked && '' !== $mvweb_marks['after'] ) : ?>
									<figcaption class="mvweb-t-badge mvweb-t-badge--accent mvweb-t-before-after__cap"><?php echo esc_html( $mvweb_marks['after'] ); ?></figcaption>
								<?php endif; ?>
							</figure>
							<span class="mvweb-t-before-after__arrow" aria-hidden="true"><?php echo mvweb_theme_icon( 'arrow-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
						</div>
						<?php if ( $mvweb_has_info( $mvweb_pair ) ) : ?>
							<div<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
								<?php $mvweb_info( $mvweb_pair ); ?>
							</div>
						<?php endif; ?>
					</article>
				<?php else : ?>
					<article class="mvweb-t-before-after__pair"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
						<?php if ( 'lens' === $mvweb_view ) : ?>
							<div class="mvweb-t-before-after__lens"><div class="mvweb-t-before-after__loupe">
								<?php $mvweb_frame( $mvweb_pair ); ?>
							</div></div>
						<?php else : ?>
							<?php $mvweb_frame( $mvweb_pair ); ?>
						<?php endif; ?>
						<?php $mvweb_info( $mvweb_pair ); ?>
					</article>
				<?php endif; ?>
			<?php endforeach; ?>
		</div>
		<?php
	},
	'button' => static function () use ( $mvweb_props, $mvweb_block, $mvweb_rv ) {
		$text = array_key_exists( 'button_text', $mvweb_props ) ? trim( (string) $mvweb_props['button_text'] ) : __( 'See all works', 'brand-market' );
		$url  = ! empty( $mvweb_props['button_url'] ) ? (string) $mvweb_props['button_url'] : (string) get_post_type_archive_link( 'mv_work' );
		$kind = array(
			'secondary' => ' mvweb-t-btn--outline',
			'link'      => ' mvweb-t-btn--link',
		);
		$look = $mvweb_block['look']['button_kind'];

		if ( '' === $text || '' === $url ) {
			return;
		}
		?>
		<div class="mvweb-t-before-after__more"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
			<a class="mvweb-t-btn<?php echo isset( $kind[ $look ] ) ? esc_attr( $kind[ $look ] ) : ''; ?><?php echo mb_strlen( $text ) > 26 ? ' mvweb-t-btn--wrap' : ''; ?>" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $text ); ?></a>
		</div>
		<?php
	},
);

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts( $mvweb_block, $mvweb_parts, array( 'rv' => true ) );
mvweb_theme_section_close();
