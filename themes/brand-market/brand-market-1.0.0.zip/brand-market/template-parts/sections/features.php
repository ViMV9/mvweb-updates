<?php
/**
 * Section template: what the company is good at.
 *
 * Five views of one list: lines under icons, cards, large numbers, a strip of
 * facts, a heading beside the list. The head, the picture and the list come in
 * the order the composition sets (the last view keeps its columns); a block
 * prints its icon, number, heading and text the same way, and a part without
 * data is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'features', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_items = isset( $mvweb_props['blocks'] ) && is_array( $mvweb_props['blocks'] ) ? mvweb_core_visible_rows( $mvweb_props['blocks'] ) : array();

if ( empty( $mvweb_items ) ) {
	return;
}

$mvweb_view  = $mvweb_block['mod'];
$mvweb_rv    = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_list  = 'numbered' === $mvweb_view ? 'ol' : 'ul';
$mvweb_image = ! empty( $mvweb_props['image'] ) ? wp_get_attachment_image( (int) $mvweb_props['image'], 'aside' === $mvweb_view ? 'large' : 'mvweb_wide' ) : '';
$mvweb_extra = '';

if ( '' !== $mvweb_image && 'aside' === $mvweb_view && 'end' === $mvweb_block['look']['image_side'] ) {
	$mvweb_extra .= ' mvweb-t-features--image-end';
}

if ( '' !== $mvweb_image && in_array( $mvweb_block['look']['image_size'], array( 's', 'l' ), true ) ) {
	$mvweb_extra .= ' mvweb-t-features--image-' . $mvweb_block['look']['image_size'];
}

$mvweb_render_item = static function ( $item, $number, $block ) use ( $mvweb_rv ) {
	$view   = $block['mod'];
	$title  = isset( $item['title'] ) ? (string) $item['title'] : '';
	$text   = isset( $item['text'] ) ? trim( (string) $item['text'] ) : '';
	$pieces = array(
		'icon'  => '',
		'num'   => '',
		'title' => '',
		'text'  => '',
	);

	if ( 'numbered' !== $view && ! empty( $item['icon'] ) ) {
		$pieces['icon'] = '<span class="mvweb-t-features__icon">' . mvweb_theme_icon( $item['icon'] ) . '</span>';
	}

	if ( 'numbered' === $view ) {
		$pieces['num'] = '<span class="mvweb-t-features__num" aria-hidden="true">' . esc_html( sprintf( '%02d', $number ) ) . '</span>';
	}

	if ( '' !== $title ) {
		$pieces['title'] = 'strip' === $view
			? '<p class="mvweb-t-features__fact">' . esc_html( $title ) . '</p>'
			: '<div class="mvweb-t-features__title mvweb-t-h3">' . esc_html( $title ) . '</div>';
	}

	if ( '' !== $text && 'strip' !== $view ) {
		if ( 'plain' === $view ) {
			$lines = array_filter( array_map( 'trim', preg_split( '/\R/u', $text ) ), 'strlen' );

			$pieces['text'] = '<ul class="mvweb-t-features__lines"><li>' . implode( '</li><li>', array_map( 'esc_html', $lines ) ) . '</li></ul>';
		} else {
			$pieces['text'] = '<p class="mvweb-t-features__desc">' . esc_html( $text ) . '</p>';
		}
	}

	$html  = '';
	$inner = '';

	foreach ( $block['item_parts'] as $slug ) {
		if ( ! isset( $pieces[ $slug ] ) ) {
			continue;
		}

		if ( 'strip' !== $view && in_array( $slug, array( 'title', 'text' ), true ) ) {
			$inner .= $pieces[ $slug ];
			continue;
		}

		if ( '' !== $inner ) {
			$html .= '<div class="mvweb-t-features__text">' . $inner . '</div>';
			$inner = '';
		}

		$html .= $pieces[ $slug ];
	}

	if ( '' !== $inner ) {
		$html .= '<div class="mvweb-t-features__text">' . $inner . '</div>';
	}

	echo '<li class="mvweb-t-features__block"' . $mvweb_rv . '>' . $html . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
};

$mvweb_print_list = static function ( $block ) use ( $mvweb_items, $mvweb_list, $mvweb_render_item ) {
	echo '<' . esc_attr( $mvweb_list ) . ' class="mvweb-t-features__row">';

	foreach ( $mvweb_items as $mvweb_index => $mvweb_item ) {
		$mvweb_render_item( $mvweb_item, $mvweb_index + 1, $block );
	}

	echo '</' . esc_attr( $mvweb_list ) . '>';
};

$mvweb_extra .= mvweb_theme_cards_colours( $mvweb_block );

mvweb_theme_section_open( $mvweb_block, true, ltrim( $mvweb_extra ) );

if ( 'aside' === $mvweb_view ) {
	$mvweb_head_slugs = array_values( array_intersect( $mvweb_block['parts'], array( 'kicker', 'title', 'lead' ) ) );

	ob_start();
	mvweb_theme_head( $mvweb_block, $mvweb_head_slugs, array( 'rv' => true ) );

	if ( '' !== $mvweb_image && in_array( 'image', $mvweb_block['parts'], true ) ) {
		echo '<div class="mvweb-t-features__photo"' . $mvweb_rv . '>' . $mvweb_image . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute and attachment markup.
	}

	$mvweb_side = trim( (string) ob_get_clean() );
	?>
	<div class="mvweb-t-features__layout">
		<?php if ( '' !== $mvweb_side ) : ?>
			<div class="mvweb-t-features__side">
				<?php echo $mvweb_side; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
			</div>
		<?php endif; ?>
		<?php
		if ( in_array( 'list', $mvweb_block['parts'], true ) ) {
			$mvweb_print_list( $mvweb_block );
		}
		?>
	</div>
	<?php
} else {
	mvweb_theme_render_parts(
		$mvweb_block,
		array(
			'image' => static function () use ( $mvweb_image, $mvweb_rv, $mvweb_view ) {
				if ( '' !== $mvweb_image && 'plain' === $mvweb_view ) {
					echo '<div class="mvweb-t-features__banner"' . $mvweb_rv . '>' . $mvweb_image . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute and attachment markup.
				}
			},
			'list'  => $mvweb_print_list,
		),
		array( 'rv' => true )
	);
}

mvweb_theme_section_close();
