<?php
/**
 * Section template: first screen.
 *
 * Five views: a photo across the screen (one photo, a slideshow or a video),
 * text beside a photo slab, centred text over three frames, a card on the
 * photo, large type over a running line. The heading is the h1 of the front
 * page and a plain div anywhere else, where the page hero holds the h1. The
 * parts of the text side come in the order the composition sets; the figures,
 * the running line and the plate keep their place in the view and only hide.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'hero', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_mod   = $mvweb_block['mod'];
$mvweb_look  = $mvweb_block['look'];
$mvweb_rv    = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_leaf  = in_array( $mvweb_mod, array( '', 'center', 'type' ), true ) ? $mvweb_rv : '';

$mvweb_title    = isset( $mvweb_props['title'] ) ? trim( (string) $mvweb_props['title'] ) : '';
$mvweb_features = isset( $mvweb_props['features'] ) && is_array( $mvweb_props['features'] ) ? array_values( array_filter( array_map( 'trim', array_column( mvweb_core_visible_rows( $mvweb_props['features'] ), 'text' ) ), 'strlen' ) ) : array();
$mvweb_figures  = isset( $mvweb_props['trust'] ) && is_array( $mvweb_props['trust'] ) ? array_values(
	array_filter(
		mvweb_core_visible_rows( $mvweb_props['trust'] ),
		static function ( $row ) {
			return ! empty( $row['number'] ) || ! empty( $row['text'] ) || ! empty( $row['image'] );
		}
	)
) : array();
$mvweb_label    = isset( $mvweb_props['button_text'] ) ? trim( (string) $mvweb_props['button_text'] ) : '';
$mvweb_url      = isset( $mvweb_props['button_url'] ) ? trim( (string) $mvweb_props['button_url'] ) : '';
$mvweb_plate    = array(
	'title' => isset( $mvweb_props['plate_title'] ) ? trim( (string) $mvweb_props['plate_title'] ) : '',
	'text'  => isset( $mvweb_props['plate_text'] ) ? trim( (string) $mvweb_props['plate_text'] ) : '',
	'icon'  => isset( $mvweb_props['plate_icon'] ) ? (string) $mvweb_props['plate_icon'] : '',
);
$mvweb_photos   = array( isset( $mvweb_props['image'] ) ? absint( $mvweb_props['image'] ) : 0 );

if ( '' === $mvweb_mod && isset( $mvweb_props['slides'] ) && is_array( $mvweb_props['slides'] ) ) {
	$mvweb_photos = array_merge( $mvweb_photos, array_map( 'absint', array_column( mvweb_core_visible_rows( $mvweb_props['slides'] ), 'image' ) ) );
}

$mvweb_photos = array_values(
	array_unique(
		array_filter(
			$mvweb_photos,
			static function ( $id ) {
				return $id > 0 && wp_attachment_is_image( $id );
			}
		)
	)
);
$mvweb_video  = '' === $mvweb_mod && isset( $mvweb_props['video'] ) && 1 === preg_match( '/\.(mp4|webm)(\?.*)?$/i', (string) $mvweb_props['video'] ) ? (string) $mvweb_props['video'] : '';

if ( '' === $mvweb_title && empty( $mvweb_features ) && empty( $mvweb_figures ) && ( '' === $mvweb_label || '' === $mvweb_url ) && empty( $mvweb_photos ) ) {
	return;
}

$mvweb_kinds = array(
	'secondary' => ' mvweb-t-btn--outline',
	'link'      => ' mvweb-t-btn--link',
);
$mvweb_kind  = isset( $mvweb_kinds[ $mvweb_look['button_kind'] ] ) ? $mvweb_kinds[ $mvweb_look['button_kind'] ] : '';
$mvweb_extra = '';

if ( 'split' === $mvweb_mod ) {
	$mvweb_extra .= 'start' === $mvweb_look['image_side'] ? ' mvweb-t-hero--image-start' : '';
	$mvweb_extra .= 'm' !== $mvweb_look['image_size'] ? ' mvweb-t-hero--size-' . $mvweb_look['image_size'] : '';
}

$mvweb_groups = array(
	''       => array( 'title', 'features', 'button' ),
	'split'  => array( 'title', 'features', 'button', 'trust' ),
	'center' => array( 'title', 'features', 'button' ),
	'card'   => array( 'title', 'features', 'button', 'trust' ),
	'type'   => array( 'title', 'button' ),
);
$mvweb_group  = isset( $mvweb_groups[ $mvweb_mod ] ) ? $mvweb_groups[ $mvweb_mod ] : $mvweb_groups[''];
$mvweb_order  = array_values( array_intersect( $mvweb_block['parts'], $mvweb_group ) );
$mvweb_shown  = static function ( $slug ) use ( $mvweb_block ) {
	return in_array( $slug, $mvweb_block['parts'], true );
};

$mvweb_figure_parts = array(
	'image'   => static function ( $item ) use ( $mvweb_mod ) {
		if ( 'center' === $mvweb_mod && ! empty( $item['image'] ) && wp_attachment_is_image( $item['image'] ) ) {
			echo '<div class="mvweb-t-hero__snap"><div class="mvweb-t-hero__snap-frame">' . wp_get_attachment_image( absint( $item['image'] ), 'medium_large', false, array( 'loading' => 'lazy' ) ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup.
		}
	},
	'number'  => static function ( $item ) {
		if ( ! empty( $item['number'] ) ) {
			echo '<span class="mvweb-t-hero__number">' . esc_html( $item['number'] ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped here.
		}
	},
	'caption' => static function ( $item ) {
		if ( ! empty( $item['text'] ) ) {
			echo '<span class="mvweb-t-hero__caption">' . mvweb_core_line( $item['text'] ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Only br survives.
		}
	},
);

$mvweb_figure_tag = 'center' === $mvweb_mod ? 'tile' : 'figure';
$mvweb_list_tags  = array(
	''       => 'trust',
	'split'  => 'stats',
	'center' => 'tiles',
	'card'   => 'stats',
	'type'   => 'stats',
);

$mvweb_renderers = array(
	'title'    => static function () use ( $mvweb_title, $mvweb_leaf ) {
		if ( '' !== $mvweb_title ) {
			$mvweb_tag = mvweb_theme_h1_tag();

			echo '<' . $mvweb_tag . ' class="mvweb-t-hero__title"' . $mvweb_leaf . '>' . esc_html( $mvweb_title ) . '</' . $mvweb_tag . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute, escaped values.
		}
	},
	'features' => static function () use ( $mvweb_features, $mvweb_mod, $mvweb_leaf ) {
		if ( empty( $mvweb_features ) ) {
			return;
		}

		if ( 'type' === $mvweb_mod ) {
			$mvweb_count  = count( $mvweb_features );
			$mvweb_repeat = (int) ceil( 4 / $mvweb_count );
			echo '<div class="mvweb-t-hero__run"' . $mvweb_leaf . '><div class="mvweb-t-hero__run-track">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.

			for ( $mvweb_group_index = 0; $mvweb_group_index < 4; $mvweb_group_index++ ) {
				echo 0 === $mvweb_group_index ? '<ul class="mvweb-t-hero__run-group">' : '<ul class="mvweb-t-hero__run-group" aria-hidden="true">'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed markup.

				for ( $mvweb_line_index = 0; $mvweb_line_index < $mvweb_count * $mvweb_repeat; $mvweb_line_index++ ) {
					echo ( 0 === $mvweb_group_index && $mvweb_line_index >= $mvweb_count ? '<li class="mvweb-t-hero__run-item" aria-hidden="true">' : '<li class="mvweb-t-hero__run-item">' ) . mvweb_theme_icon( 'sparkles', array( 'class' => 'mvweb-t-icon--sm' ) ) . esc_html( $mvweb_features[ $mvweb_line_index % $mvweb_count ] ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Icon helper and escaped text.
				}

				echo '</ul>';
			}

			echo '</div></div>';

			return;
		}

		$mvweb_classes = array(
			''       => array( 'features', 'feature' ),
			'split'  => array( 'list', 'item' ),
			'center' => array( 'pills', 'pill' ),
			'card'   => array( 'list', 'item' ),
		);
		$mvweb_class   = $mvweb_classes[ $mvweb_mod ];
		$mvweb_ticks   = in_array( $mvweb_mod, array( 'split', 'card' ), true );

		echo '<ul class="mvweb-t-hero__' . esc_attr( $mvweb_class[0] ) . '"' . $mvweb_leaf . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute.

		foreach ( $mvweb_features as $mvweb_feature ) {
			$mvweb_check = mvweb_theme_icon( 'check', array( 'class' => 'mvweb-t-icon--sm' ) );

			echo '<li class="mvweb-t-hero__' . esc_attr( $mvweb_class[1] ) . '">' . ( $mvweb_ticks ? '<span class="mvweb-t-hero__tick">' . $mvweb_check . '</span>' : $mvweb_check ) . esc_html( $mvweb_feature ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Icon helper and escaped text.
		}

		echo '</ul>';
	},
	'button'   => static function () use ( $mvweb_label, $mvweb_url, $mvweb_kind, $mvweb_leaf ) {
		if ( '' !== $mvweb_label && '' !== $mvweb_url ) {
			echo '<a class="mvweb-t-btn' . esc_attr( $mvweb_kind ) . ' mvweb-t-hero__cta"' . $mvweb_leaf . ' href="' . esc_url( $mvweb_url ) . '">' . esc_html( $mvweb_label ) . ' ' . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute, escaped values.
		}
	},
	'trust'    => static function () use ( $mvweb_figures, $mvweb_block, $mvweb_figure_parts, $mvweb_figure_tag, $mvweb_list_tags, $mvweb_mod, $mvweb_leaf ) {
		$mvweb_items = '';

		foreach ( $mvweb_figures as $mvweb_figure ) {
			ob_start();
			mvweb_theme_render_item_parts( $mvweb_block, $mvweb_figure, $mvweb_figure_parts );
			$mvweb_html = (string) ob_get_clean();

			if ( '' !== $mvweb_html ) {
				$mvweb_items .= '<li class="mvweb-t-hero__' . esc_attr( $mvweb_figure_tag ) . '"' . $mvweb_leaf . '>' . $mvweb_html . '</li>';
			}
		}

		if ( '' !== $mvweb_items ) {
			echo '<ul class="mvweb-t-hero__' . esc_attr( $mvweb_list_tags[ $mvweb_mod ] ) . '">' . $mvweb_items . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts.
		}
	},
);

$mvweb_capture = static function ( array $slugs ) use ( $mvweb_renderers ) {
	ob_start();

	foreach ( $slugs as $mvweb_slug ) {
		if ( isset( $mvweb_renderers[ $mvweb_slug ] ) ) {
			call_user_func( $mvweb_renderers[ $mvweb_slug ] );
		}
	}

	return (string) ob_get_clean();
};

$mvweb_image = static function ( $id, array $attr = array() ) {
	return wp_get_attachment_image( $id, 'mvweb_wide', false, $attr );
};

$mvweb_text = $mvweb_capture( $mvweb_order );

ob_start();

if ( '' !== $mvweb_title && ! $mvweb_shown( 'title' ) && 'h1' === mvweb_theme_h1_tag() ) {
	echo '<h1 class="mvweb-t-visually-hidden">' . esc_html( $mvweb_title ) . '</h1>';
}
?>
<?php if ( '' === $mvweb_mod && ( ! empty( $mvweb_photos ) || '' !== $mvweb_video ) ) : ?>
	<?php if ( count( $mvweb_photos ) > 1 ) : ?>
		<div class="mvweb-t-hero__media" data-hero-slides data-effect="<?php echo esc_attr( isset( $mvweb_props['slide_effect'] ) ? (string) $mvweb_props['slide_effect'] : 'fade' ); ?>" style="--mvweb-t-hero-interval:<?php echo esc_attr( max( 3, absint( isset( $mvweb_props['slide_interval'] ) ? $mvweb_props['slide_interval'] : 6 ) ) ); ?>s">
			<?php foreach ( $mvweb_photos as $mvweb_index => $mvweb_photo ) : ?>
				<div class="mvweb-t-hero__slide" data-hero-slide<?php echo 0 === $mvweb_index ? ' data-state="active"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
					<?php
					echo $mvweb_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup.
						$mvweb_photo,
						0 === $mvweb_index ? array(
							'fetchpriority' => 'high',
							'decoding'      => 'async',
							'loading'       => false,
						) : array(
							'fetchpriority' => 'low',
							'decoding'      => 'async',
							'loading'       => 'lazy',
						)
					);
					?>
				</div>
			<?php endforeach; ?>
			<?php if ( '' !== $mvweb_video ) : ?>
				<video class="mvweb-t-hero__video" data-hero-video data-src="<?php echo esc_url( $mvweb_video ); ?>" muted loop playsinline preload="none" aria-hidden="true"></video>
			<?php endif; ?>
		</div>
	<?php else : ?>
		<div class="mvweb-t-hero__media">
			<?php
			echo $mvweb_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup.
				$mvweb_photos ? $mvweb_photos[0] : 0,
				array(
					'fetchpriority' => 'high',
					'decoding'      => 'async',
					'loading'       => false,
				)
			);
			?>
			<?php if ( '' !== $mvweb_video ) : ?>
				<video class="mvweb-t-hero__video" data-hero-video data-src="<?php echo esc_url( $mvweb_video ); ?>" muted loop playsinline preload="none" aria-hidden="true"></video>
			<?php endif; ?>
		</div>
	<?php endif; ?>
<?php endif; ?>
<?php if ( 'card' === $mvweb_mod && ! empty( $mvweb_photos ) ) : ?>
	<div class="mvweb-t-hero__media">
		<?php
		echo $mvweb_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup.
			$mvweb_photos[0],
			array(
				'fetchpriority' => 'high',
				'decoding'      => 'async',
				'loading'       => false,
			)
		);
		?>
	</div>
<?php endif; ?>
<?php if ( 'type' === $mvweb_mod ) : ?>
	<?php if ( '' !== $mvweb_text ) : ?>
		<div class="mvweb-t-container mvweb-t-hero__inner">
			<?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
		</div>
	<?php endif; ?>
	<?php if ( $mvweb_shown( 'features' ) ) : ?>
		<?php $mvweb_renderers['features'](); ?>
	<?php endif; ?>
	<?php $mvweb_stats = $mvweb_shown( 'trust' ) ? $mvweb_capture( array( 'trust' ) ) : ''; ?>
	<?php if ( '' !== $mvweb_stats ) : ?>
		<div class="mvweb-t-container">
			<?php echo $mvweb_stats; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
		</div>
	<?php endif; ?>
<?php elseif ( 'split' === $mvweb_mod ) : ?>
	<?php
	$mvweb_slab = '';

	if ( ! empty( $mvweb_photos ) ) {
		$mvweb_slab .= '<div class="mvweb-t-hero__photo">' . $mvweb_image( $mvweb_photos[0], array( 'decoding' => 'async' ) ) . '</div>';
	}

	if ( ! empty( $mvweb_photos ) && $mvweb_shown( 'plate' ) && ( '' !== $mvweb_plate['title'] || '' !== $mvweb_plate['text'] ) ) {
		$mvweb_slab .= '<div class="mvweb-t-hero__plate"' . $mvweb_rv . '>';
		$mvweb_slab .= '' !== $mvweb_plate['icon'] ? '<span class="mvweb-t-hero__plate-icon">' . mvweb_theme_icon( $mvweb_plate['icon'] ) . '</span>' : '';
		$mvweb_slab .= '<span class="mvweb-t-hero__plate-text">';
		$mvweb_slab .= '' !== $mvweb_plate['title'] ? '<strong>' . esc_html( $mvweb_plate['title'] ) . '</strong>' : '';
		$mvweb_slab .= '' !== $mvweb_plate['text'] ? '<span>' . esc_html( $mvweb_plate['text'] ) . '</span>' : '';
		$mvweb_slab .= '</span></div>';
	}
	?>
	<?php if ( '' !== $mvweb_text || '' !== $mvweb_slab ) : ?>
		<div class="mvweb-t-container mvweb-t-hero__inner">
			<?php if ( '' !== $mvweb_text ) : ?>
				<div class="mvweb-t-hero__content"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
					<?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
				</div>
			<?php endif; ?>
			<?php if ( '' !== $mvweb_slab ) : ?>
				<div class="mvweb-t-hero__slab"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
					<?php echo $mvweb_slab; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
				</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>
<?php elseif ( 'card' === $mvweb_mod ) : ?>
	<?php if ( '' !== $mvweb_text ) : ?>
		<div class="mvweb-t-container mvweb-t-hero__inner">
			<div class="mvweb-t-hero__panel"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
				<?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
			</div>
		</div>
	<?php endif; ?>
<?php else : ?>
	<?php $mvweb_tail = $mvweb_shown( 'trust' ) ? $mvweb_capture( array( 'trust' ) ) : ''; ?>
	<?php if ( '' !== $mvweb_text || '' !== $mvweb_tail ) : ?>
		<div class="mvweb-t-container mvweb-t-hero__inner">
			<?php if ( '' !== $mvweb_text ) : ?>
				<div class="mvweb-t-hero__content">
					<?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
				</div>
			<?php endif; ?>
			<?php echo $mvweb_tail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts. ?>
		</div>
	<?php endif; ?>
<?php endif; ?>
<?php
$mvweb_html = trim( (string) ob_get_clean() );

if ( '' === $mvweb_html ) {
	return;
}

mvweb_theme_section_open( $mvweb_block, false, trim( $mvweb_extra ) );
echo $mvweb_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts.
mvweb_theme_section_close( false );
