<?php
/**
 * Section template: services of the company.
 *
 * Five views: cards with an icon, cards with a photo, rows with prices, a
 * large card with small ones, tabs with a price list. The rows come from the
 * list of the block, from the services of the site or from their sections.
 * The head and the list come in the order the composition sets; a part of a
 * service (icon, picture, text, price, arrow) is printed only when the
 * composition shows it and the service has it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block  = mvweb_theme_block( 'services', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props  = $mvweb_block['props'];
$mvweb_view   = $mvweb_block['mod'];
$mvweb_rv     = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_source = isset( $mvweb_props['source'] ) ? (string) $mvweb_props['source'] : 'manual';
$mvweb_count  = isset( $mvweb_props['count'] ) ? max( 1, absint( $mvweb_props['count'] ) ) : 6;
$mvweb_from   = mvweb_core_service_price_from();
$mvweb_rows   = array();

$mvweb_value = static function ( $row, $key ) {
	return isset( $row[ $key ] ) ? trim( (string) $row[ $key ] ) : '';
};

$mvweb_of_post = static function ( $id, $group ) {
	return array(
		'title' => get_the_title( $id ),
		'text'  => trim( wp_strip_all_tags( mvweb_core_item_excerpt( $id ) ) ),
		'price' => mvweb_core_item_price_html( $id ),
		'url'   => (string) get_permalink( $id ),
		'icon'  => '',
		'image' => absint( get_post_thumbnail_id( $id ) ),
		'group' => $group,
	);
};

if ( 'manual' === $mvweb_source ) {
	$mvweb_manual = isset( $mvweb_props['items'] ) && is_array( $mvweb_props['items'] ) ? mvweb_core_visible_rows( $mvweb_props['items'] ) : array();

	foreach ( $mvweb_manual as $mvweb_row ) {
		if ( '' === $mvweb_value( $mvweb_row, 'title' ) ) {
			continue;
		}

		$mvweb_rows[] = array(
			'title' => $mvweb_value( $mvweb_row, 'title' ),
			'text'  => $mvweb_value( $mvweb_row, 'text' ),
			'price' => esc_html( $mvweb_value( $mvweb_row, 'price' ) ),
			'url'   => $mvweb_value( $mvweb_row, 'url' ),
			'icon'  => $mvweb_value( $mvweb_row, 'icon' ),
			'image' => isset( $mvweb_row['image'] ) ? absint( $mvweb_row['image'] ) : 0,
			'group' => $mvweb_value( $mvweb_row, 'group' ),
		);
	}
} elseif ( 'service' === $mvweb_source ) {
	$mvweb_section = isset( $mvweb_props['section'] ) ? absint( $mvweb_props['section'] ) : 0;
	$mvweb_ids     = $mvweb_section > 0
		? mvweb_core_service_ids( $mvweb_section, true )
		: get_posts(
			array(
				'post_type'      => 'mv_service',
				'post_status'    => 'publish',
				'posts_per_page' => $mvweb_count,
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'orderby'        => array(
					'menu_order' => 'ASC',
					'date'       => 'DESC',
				),
			)
		);

	foreach ( array_slice( $mvweb_ids, 0, $mvweb_count ) as $mvweb_id ) {
		$mvweb_terms  = get_the_terms( $mvweb_id, 'mv_service_cat' );
		$mvweb_rows[] = $mvweb_of_post( $mvweb_id, is_array( $mvweb_terms ) ? reset( $mvweb_terms )->name : '' );
	}
} elseif ( 'service_cat' === $mvweb_source ) {
	foreach ( array_slice( mvweb_core_service_child_terms( 0 ), 0, $mvweb_count ) as $mvweb_term ) {
		if ( 'tabs' === $mvweb_view ) {
			foreach ( mvweb_core_service_ids( $mvweb_term->term_id, true ) as $mvweb_id ) {
				$mvweb_rows[] = $mvweb_of_post( $mvweb_id, $mvweb_term->name );
			}

			continue;
		}

		$mvweb_link   = get_term_link( $mvweb_term );
		$mvweb_rows[] = array(
			'title' => $mvweb_term->name,
			'text'  => wp_trim_words( wp_strip_all_tags( $mvweb_term->description ), 20 ),
			'price' => '',
			'url'   => is_string( $mvweb_link ) ? $mvweb_link : '',
			'icon'  => '',
			'image' => absint( get_term_meta( $mvweb_term->term_id, 'thumbnail_id', true ) ),
			'group' => '',
		);
	}
}

if ( empty( $mvweb_rows ) ) {
	return;
}

$mvweb_has = static function ( $slug ) use ( $mvweb_block ) {
	return in_array( $slug, $mvweb_block['item_parts'], true );
};

$mvweb_bits = array(
	'name'  => static function ( $item ) {
		$link = '' !== $item['url']
			? '<a class="mvweb-t-services__link" href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['title'] ) . '</a>'
			: '<span class="mvweb-t-services__link">' . esc_html( $item['title'] ) . '</span>';

		return '<div class="mvweb-t-services__title mvweb-t-h3">' . $link . '</div>';
	},
	'icon'  => static function ( $item ) {
		return '' !== $item['icon'] ? '<span class="mvweb-t-services__icon">' . mvweb_theme_icon( $item['icon'] ) . '</span>' : '';
	},
	'text'  => static function ( $item ) {
		return '' !== $item['text'] ? '<p class="mvweb-t-services__desc">' . esc_html( $item['text'] ) . '</p>' : '';
	},
	'price' => static function ( $item ) use ( $mvweb_from ) {
		if ( '' === trim( wp_strip_all_tags( $item['price'] ) ) ) {
			return '';
		}

		return '<div class="mvweb-t-price mvweb-t-services__price">' . ( '' !== $mvweb_from ? '<span class="mvweb-t-price__from">' . esc_html( $mvweb_from ) . '</span> ' : '' ) . $item['price'] . '</div>';
	},
	'go'    => static function ( $item ) {
		return '' !== $item['url'] ? '<span class="mvweb-t-services__go" aria-hidden="true">' . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</span>' : '';
	},
);

$mvweb_part = static function ( $item, $slug ) use ( $mvweb_has, $mvweb_bits ) {
	return $mvweb_has( $slug ) ? $mvweb_bits[ $slug ]( $item ) : '';
};

$mvweb_pair = static function ( $item, array $slugs ) use ( $mvweb_block, $mvweb_bits ) {
	$html = '';

	foreach ( array_intersect( $mvweb_block['item_parts'], $slugs ) as $slug ) {
		$html .= $mvweb_bits[ $slug ]( $item );
	}

	return $html;
};

$mvweb_wrap = static function ( $html, $classes ) {
	return '' !== $html ? '<div class="' . $classes . '">' . $html . '</div>' : '';
};

$mvweb_media = static function ( $item, $tag, $classes, $size ) use ( $mvweb_has ) {
	if ( ! $mvweb_has( 'image' ) || ! wp_attachment_is_image( $item['image'] ) ) {
		return '';
	}

	$image = wp_get_attachment_image(
		$item['image'],
		$size,
		false,
		array(
			'loading'  => 'lazy',
			'decoding' => 'async',
		)
	);

	return '<' . $tag . ' class="' . $classes . '">' . $image . '</' . $tag . '>';
};

$mvweb_parts = array(
	'list' => static function () use ( $mvweb_rows, $mvweb_view, $mvweb_rv, $mvweb_bits, $mvweb_part, $mvweb_pair, $mvweb_wrap, $mvweb_media, $mvweb_props ) {
		if ( 'cards' === $mvweb_view || 'photos' === $mvweb_view ) {
			echo '<div class="mvweb-t-services__grid">';

			foreach ( $mvweb_rows as $mvweb_item ) {
				$mvweb_media_html = 'photos' === $mvweb_view ? $mvweb_media( $mvweb_item, 'div', 'mvweb-t-services__media', 'medium_large' ) : '';
				$mvweb_icon_html  = 'cards' === $mvweb_view ? $mvweb_part( $mvweb_item, 'icon' ) : '';
				$mvweb_text_html  = $mvweb_wrap( $mvweb_bits['name']( $mvweb_item ) . $mvweb_part( $mvweb_item, 'text' ), 'mvweb-t-services__text' );
				$mvweb_foot_html  = $mvweb_wrap( $mvweb_pair( $mvweb_item, array( 'price', 'go' ) ), 'mvweb-t-services__foot-row' );

				echo '<article class="mvweb-t-services__card"' . $mvweb_rv . '>' . $mvweb_media_html . '<div class="mvweb-t-services__body">' . $mvweb_icon_html . $mvweb_text_html . $mvweb_foot_html . '</div></article>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
			}

			echo '</div>';
		} elseif ( 'rows' === $mvweb_view ) {
			echo '<ul class="mvweb-t-services__rows">';

			foreach ( $mvweb_rows as $mvweb_item ) {
				$mvweb_text_html = $mvweb_wrap( $mvweb_bits['name']( $mvweb_item ) . $mvweb_part( $mvweb_item, 'text' ), 'mvweb-t-services__text' );
				$mvweb_side_html = $mvweb_wrap( $mvweb_pair( $mvweb_item, array( 'price', 'go' ) ), 'mvweb-t-services__side' );

				echo '<li class="mvweb-t-services__row"' . $mvweb_rv . '>' . $mvweb_text_html . $mvweb_side_html . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
			}

			echo '</ul>';
		} elseif ( 'hero' === $mvweb_view ) {
			$mvweb_lead  = $mvweb_rows[0];
			$mvweb_minis = array_slice( $mvweb_rows, 1 );

			echo '<div class="mvweb-t-services__stage">';

			$mvweb_panel = $mvweb_wrap( $mvweb_bits['name']( $mvweb_lead ) . $mvweb_part( $mvweb_lead, 'text' ), 'mvweb-t-services__text' ) . $mvweb_wrap( $mvweb_pair( $mvweb_lead, array( 'price', 'go' ) ), 'mvweb-t-services__foot-row' );

			echo '<article class="mvweb-t-services__hero"' . $mvweb_rv . '>' . $mvweb_media( $mvweb_lead, 'div', 'mvweb-t-services__hero-media', 'large' ) . '<div class="mvweb-t-services__hero-panel">' . $mvweb_panel . '</div></article>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.

			if ( ! empty( $mvweb_minis ) ) {
				echo '<ul class="mvweb-t-services__minis">';

				foreach ( $mvweb_minis as $mvweb_item ) {
					$mvweb_thumb_html = $mvweb_media( $mvweb_item, 'span', 'mvweb-t-services__thumb', 'thumbnail' );
					$mvweb_text_html  = $mvweb_wrap( $mvweb_bits['name']( $mvweb_item ) . $mvweb_part( $mvweb_item, 'price' ), 'mvweb-t-services__text' );

					echo '<li class="mvweb-t-services__mini"' . $mvweb_rv . '>' . $mvweb_thumb_html . $mvweb_text_html . $mvweb_part( $mvweb_item, 'go' ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
				}

				echo '</ul>';
			}

			echo '</div>';
		} else {
			$mvweb_other  = __( 'Other services', 'brand-market' );
			$mvweb_groups = array();

			foreach ( $mvweb_rows as $mvweb_item ) {
				$mvweb_name = '' !== $mvweb_item['group'] ? $mvweb_item['group'] : $mvweb_other;
				$mvweb_key  = md5( $mvweb_name );

				if ( ! isset( $mvweb_groups[ $mvweb_key ] ) ) {
					$mvweb_groups[ $mvweb_key ] = array(
						'name' => $mvweb_name,
						'rows' => array(),
					);
				}

				$mvweb_groups[ $mvweb_key ]['rows'][] = $mvweb_item;
			}

			$mvweb_groups = array_slice( array_values( $mvweb_groups ), 0, 12 );
			$mvweb_uid    = wp_unique_id( 'mvweb-t-services-tab-' );
			?>
			<div class="mvweb-t-services__tabs">
				<div class="mvweb-t-services__tablist" role="radiogroup" aria-label="<?php esc_attr_e( 'Service sections', 'brand-market' ); ?>"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
					<?php foreach ( $mvweb_groups as $mvweb_index => $mvweb_group ) : ?>
						<?php $mvweb_total = count( $mvweb_group['rows'] ); ?>
						<input class="mvweb-t-services__tab screen-reader-text" type="radio" name="<?php echo esc_attr( $mvweb_uid ); ?>" id="<?php echo esc_attr( $mvweb_uid . '-' . ( $mvweb_index + 1 ) ); ?>"<?php checked( 0, $mvweb_index ); ?>>
						<label class="mvweb-t-services__tab-label" for="<?php echo esc_attr( $mvweb_uid . '-' . ( $mvweb_index + 1 ) ); ?>">
							<span class="mvweb-t-services__tab-name"><?php echo esc_html( $mvweb_group['name'] ); ?></span>
							<span class="mvweb-t-services__tab-count">
								<?php
								/* translators: %s: number of services under the tab. */
								echo esc_html( sprintf( _n( '%s service', '%s services', $mvweb_total, 'brand-market' ), number_format_i18n( $mvweb_total ) ) );
								?>
							</span>
						</label>
					<?php endforeach; ?>
				</div>
				<div class="mvweb-t-services__panels"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
					<?php foreach ( $mvweb_groups as $mvweb_group ) : ?>
						<ul class="mvweb-t-services__panel" aria-label="<?php echo esc_attr( $mvweb_group['name'] ); ?>">
							<?php
							foreach ( $mvweb_group['rows'] as $mvweb_item ) {
								$mvweb_price_html = $mvweb_part( $mvweb_item, 'price' );
								$mvweb_dots_html  = '' !== $mvweb_price_html ? '<span class="mvweb-t-services__dots" aria-hidden="true"></span>' : '';
								$mvweb_head_html  = '<div class="mvweb-t-services__line-head">' . $mvweb_bits['name']( $mvweb_item ) . $mvweb_dots_html . $mvweb_price_html . '</div>';

								echo '<li class="mvweb-t-services__line">' . $mvweb_part( $mvweb_item, 'icon' ) . '<div class="mvweb-t-services__text">' . $mvweb_head_html . $mvweb_part( $mvweb_item, 'text' ) . '</div></li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
							}
							?>
						</ul>
					<?php endforeach; ?>
				</div>
			</div>
			<?php
		}
	},
	'foot' => static function ( $block ) use ( $mvweb_rv ) {
		$text = isset( $block['props']['link_text'] ) ? trim( (string) $block['props']['link_text'] ) : '';
		$url  = isset( $block['props']['link_url'] ) ? trim( (string) $block['props']['link_url'] ) : '';

		if ( '' === $text || '' === $url ) {
			return;
		}
		?>
		<div class="mvweb-t-services__foot"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>><a class="mvweb-t-btn mvweb-t-btn--outline" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $text ); ?><?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></a></div>
		<?php
	},
);

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts( $mvweb_block, $mvweb_parts, array( 'rv' => true ) );
mvweb_theme_section_close();
