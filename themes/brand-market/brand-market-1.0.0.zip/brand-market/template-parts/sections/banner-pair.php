<?php
/**
 * Section template: two promo banners side by side.
 *
 * Five views: coloured cards with pictures and a sticker, photo banners, a
 * large and a small one, a large figure, a caption strip under a picture. The
 * first banner takes the dark look and the second the accent. The line, the
 * heading, the text and the button of a banner come in the order the
 * composition sets; the pictures, the sticker and the running line keep their
 * place in the view and only hide. A banner whose last day has passed is not
 * printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'banner-pair', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_mod   = $mvweb_block['mod'];
$mvweb_rv    = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_rows  = isset( $mvweb_props['banners'] ) && is_array( $mvweb_props['banners'] ) ? array_values(
	array_filter(
		mvweb_core_visible_rows( $mvweb_props['banners'] ),
		static function ( $row ) {
			return ! mvweb_core_offer_ended( isset( $row['until'] ) ? $row['until'] : '' );
		}
	)
) : array();

if ( empty( $mvweb_rows ) ) {
	return;
}


$mvweb_pictures = static function ( array $row ) {
	$ids = array();

	foreach ( array( 'image_1', 'image_2' ) as $key ) {
		$id = isset( $row[ $key ] ) ? absint( $row[ $key ] ) : 0;

		if ( $id > 0 && wp_attachment_is_image( $id ) ) {
			$ids[] = $id;
		}
	}

	return $ids;
};

$mvweb_texts = array(
	'kicker' => static function ( array $row ) {
		return isset( $row['kicker'] ) && '' !== trim( (string) $row['kicker'] ) ? '<span class="mvweb-t-banner-pair__kicker">' . esc_html( trim( (string) $row['kicker'] ) ) . '</span>' : '';
	},
	'title'  => static function ( array $row ) {
		return isset( $row['title'] ) && '' !== trim( (string) $row['title'] ) ? '<div class="mvweb-t-banner-pair__title mvweb-t-h3">' . esc_html( trim( (string) $row['title'] ) ) . '</div>' : '';
	},
	'text'   => static function ( array $row ) {
		return isset( $row['text'] ) && '' !== trim( (string) $row['text'] ) ? '<p class="mvweb-t-banner-pair__desc">' . esc_html( trim( (string) $row['text'] ) ) . '</p>' : '';
	},
);

$mvweb_button = static function ( array $row ) {
	$label = isset( $row['button_text'] ) ? trim( (string) $row['button_text'] ) : '';
	$url   = isset( $row['button_url'] ) ? trim( (string) $row['button_url'] ) : '';

	return '' !== $label && '' !== $url ? '<a class="mvweb-t-btn" href="' . esc_url( $url ) . '">' . esc_html( $label ) . ' ' . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>' : '';
};

$mvweb_item_html = static function ( array $row, $index ) use ( $mvweb_block, $mvweb_mod, $mvweb_rv, $mvweb_texts, $mvweb_button, $mvweb_pictures ) {
	$parts   = $mvweb_block['item_parts'];
	$has     = static function ( $slug ) use ( $parts ) {
		return in_array( $slug, $parts, true );
	};
	$images  = $mvweb_pictures( $row );
	$sticker = isset( $row['sticker'] ) ? trim( (string) $row['sticker'] ) : '';
	$ticker  = isset( $row['ticker'] ) ? trim( (string) $row['ticker'] ) : '';
	$ticker  = '' !== $ticker ? $ticker : implode( ' · ', array_filter( array( isset( $row['kicker'] ) ? trim( (string) $row['kicker'] ) : '', $sticker ), 'strlen' ) );
	$text    = '';
	$run     = '';

	foreach ( $parts as $slug ) {
		if ( isset( $mvweb_texts[ $slug ] ) ) {
			$run .= $mvweb_texts[ $slug ]( $row );
			continue;
		}

		if ( '' !== $run ) {
			$text .= '<div class="mvweb-t-banner-pair__text">' . $run . '</div>';
			$run   = '';
		}

		if ( 'button' === $slug ) {
			$text .= $mvweb_button( $row );
		}
	}

	if ( '' !== $run ) {
		$text .= '<div class="mvweb-t-banner-pair__text">' . $run . '</div>';
	}

	$image = static function ( $id, $size ) {
		return wp_get_attachment_image( $id, $size, false, array( 'decoding' => 'async' ) );
	};
	$lead  = '';
	$tail  = '';

	if ( '' === $mvweb_mod ) {
		if ( $has( 'pics' ) && ! empty( $images ) ) {
			$tail .= '<div class="mvweb-t-banner-pair__pics" aria-hidden="true"><div class="mvweb-t-banner-pair__pic mvweb-t-banner-pair__pic--front">' . $image( $images[0], 'mvweb_card' ) . '</div>' . ( isset( $images[1] ) ? '<div class="mvweb-t-banner-pair__pic mvweb-t-banner-pair__pic--back">' . $image( $images[1], 'mvweb_card' ) . '</div>' : '' ) . '</div>';
		}

		if ( $has( 'sticker' ) && '' !== $sticker ) {
			$tail .= '<span class="mvweb-t-banner-pair__sticker"' . $mvweb_rv . '>' . esc_html( $sticker ) . '</span>';
		}
	} elseif ( 'photo' === $mvweb_mod ) {
		if ( $has( 'pics' ) && ! empty( $images ) ) {
			$lead .= '<div class="mvweb-t-banner-pair__photo" aria-hidden="true">' . $image( $images[0], 'mvweb_wide' ) . '</div>';
		}
	} elseif ( 'asym' === $mvweb_mod ) {
		if ( $has( 'pics' ) && ! empty( $images ) ) {
			$lead .= 0 === $index % 2
				? '<div class="mvweb-t-banner-pair__panel" aria-hidden="true">' . $image( $images[0], 'mvweb_card' ) . ( isset( $images[1] ) ? $image( $images[1], 'mvweb_card' ) : '' ) . '</div>'
				: '<div class="mvweb-t-banner-pair__orb" aria-hidden="true">' . $image( $images[0], 'medium' ) . '</div>';
		}
	} elseif ( 'number' === $mvweb_mod ) {
		$top  = $has( 'sticker' ) && '' !== $sticker ? '<div class="mvweb-t-banner-pair__num"' . $mvweb_rv . '>' . esc_html( $sticker ) . '</div>' : '';
		$top .= $has( 'pics' ) && ! empty( $images ) ? '<div class="mvweb-t-banner-pair__thumb" aria-hidden="true">' . $image( $images[0], 'mvweb_card' ) . '</div>' : '';
		$lead = '' !== $top ? '<div class="mvweb-t-banner-pair__top">' . $top . '</div>' : '';
	} else {
		$cover = $has( 'pics' ) && ! empty( $images ) ? $image( $images[0], 'mvweb_wide' ) : '';
		$strip = '';

		if ( $has( 'ticker' ) && '' !== $ticker ) {
			$unit  = $ticker . ' · ';
			$copy  = str_repeat( $unit, max( 1, (int) ceil( 140 / max( 1, mb_strlen( $unit ) ) ) ) );
			$strip = '<div class="mvweb-t-banner-pair__ticker"><div class="mvweb-t-banner-pair__track"><span>' . esc_html( $copy ) . '</span><span>' . esc_html( $copy ) . '</span></div></div>';
		}

		$lead = '' !== $cover || '' !== $strip ? '<div class="mvweb-t-banner-pair__cover" aria-hidden="true">' . $cover . $strip . '</div>' : '';
		$text = '' !== $text ? '<div class="mvweb-t-banner-pair__caption">' . $text . '</div>' : '';
	}

	$inner = $lead . $text . $tail;

	if ( '' === $inner ) {
		return '';
	}

	return '<article class="mvweb-t-banner-pair__item mvweb-t-banner-pair__item--' . ( 0 === $index % 2 ? 'inverse' : 'accent' ) . '"' . $mvweb_rv . '>' . $inner . '</article>';
};

$mvweb_items = '';

foreach ( $mvweb_rows as $mvweb_index => $mvweb_row ) {
	$mvweb_items .= $mvweb_item_html( $mvweb_row, $mvweb_index );
}

if ( '' === $mvweb_items ) {
	return;
}

$mvweb_parts = array(
	'list' => static function () use ( $mvweb_items ) {
		echo '<div class="mvweb-t-banner-pair__grid">' . $mvweb_items . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts.
	},
);

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts( $mvweb_block, $mvweb_parts, array( 'rv' => true ) );
mvweb_theme_section_close();
