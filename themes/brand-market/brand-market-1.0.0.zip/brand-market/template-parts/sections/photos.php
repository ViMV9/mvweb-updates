<?php
/**
 * Section template: photographs with captions.
 *
 * Five views: a mosaic, columns, a stage with a strip of thumbnails, strips,
 * two running reels. A photograph without an address is not a link; a
 * caption that is switched off stays as the name of the link for screen
 * readers. A part without data is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'photos', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_rows  = isset( $mvweb_props['items'] ) && is_array( $mvweb_props['items'] ) ? mvweb_core_visible_rows( $mvweb_props['items'] ) : array();
$mvweb_shots = array();

foreach ( $mvweb_rows as $mvweb_row ) {
	$mvweb_image = isset( $mvweb_row['image'] ) ? absint( $mvweb_row['image'] ) : 0;

	if ( ! wp_attachment_is_image( $mvweb_image ) ) {
		continue;
	}

	$mvweb_shots[] = array(
		'image'   => $mvweb_image,
		'caption' => isset( $mvweb_row['caption'] ) ? trim( (string) $mvweb_row['caption'] ) : '',
		'url'     => isset( $mvweb_row['url'] ) ? trim( (string) $mvweb_row['url'] ) : '',
		'size'    => isset( $mvweb_row['size'] ) ? (string) $mvweb_row['size'] : 'normal',
	);
}

if ( empty( $mvweb_shots ) ) {
	return;
}

$mvweb_view    = $mvweb_block['mod'];
$mvweb_rv      = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_caption = in_array( 'caption', $mvweb_block['item_parts'], true );
$mvweb_base    = 'mvweb-t-photos__';
$mvweb_uid     = isset( $args['uid'] ) ? sanitize_html_class( (string) $args['uid'] ) : '';
$mvweb_uid     = '' !== $mvweb_uid ? $mvweb_uid : (string) wp_unique_id( 'photos-' );

$mvweb_img = static function ( $shot, $size ) {
	return (string) wp_get_attachment_image( $shot['image'], $size );
};

$mvweb_name = static function ( $shot, $number ) use ( $mvweb_caption ) {
	if ( $mvweb_caption && '' !== $shot['caption'] ) {
		return '';
	}

	if ( '' !== $shot['caption'] ) {
		return $shot['caption'];
	}

	return '' === trim( (string) get_post_meta( $shot['image'], '_wp_attachment_image_alt', true ) )
		? sprintf( /* translators: %d: number of the photograph. */ __( 'Photo %d', 'brand-market' ), $number )
		: '';
};

$mvweb_open = static function ( $shot, $number, $css, $extra = '' ) use ( $mvweb_name ) {
	$label = $mvweb_name( $shot, $number );

	if ( '' === $shot['url'] ) {
		return '<div class="' . $css . '"' . $extra . '>';
	}

	return '<a class="' . $css . '" href="' . esc_url( $shot['url'] ) . '"' . ( '' !== $label ? ' aria-label="' . esc_attr( $label ) . '"' : '' ) . $extra . '>';
};

$mvweb_close = static function ( $shot ) {
	return '' === $shot['url'] ? '</div>' : '</a>';
};

$mvweb_cap = static function ( $shot, $suffix ) use ( $mvweb_caption, $mvweb_base ) {
	return $mvweb_caption && '' !== $shot['caption'] ? '<span class="' . $mvweb_base . $suffix . '">' . esc_html( $shot['caption'] ) . '</span>' : '';
};

$mvweb_list = static function ( $block ) use ( $mvweb_shots, $mvweb_view, $mvweb_rv, $mvweb_base, $mvweb_img, $mvweb_open, $mvweb_close, $mvweb_cap, $mvweb_uid, $mvweb_caption ) {
	$html = '';

	if ( '' === $mvweb_view ) {
		$html .= '<div class="' . $mvweb_base . 'grid">';

		foreach ( $mvweb_shots as $i => $shot ) {
			$html .= $mvweb_open( $shot, $i + 1, $mvweb_base . 'tile' . ( 'tall' === $shot['size'] ? ' ' . $mvweb_base . 'tile--tall' : '' ), $mvweb_rv );
			$html .= $mvweb_img( $shot, 'large' ) . $mvweb_cap( $shot, 'caption' ) . $mvweb_close( $shot );
		}

		return $html . '</div>';
	}

	if ( 'masonry' === $mvweb_view ) {
		$html .= '<div class="' . $mvweb_base . 'cols">';

		foreach ( $mvweb_shots as $i => $shot ) {
			$shape = array(
				'tall'   => ' ' . $mvweb_base . 'shot--tall',
				'square' => ' ' . $mvweb_base . 'shot--sq',
			);
			$html .= $mvweb_open( $shot, $i + 1, $mvweb_base . 'item', $mvweb_rv );
			$html .= '<span class="' . $mvweb_base . 'shot' . ( isset( $shape[ $shot['size'] ] ) ? $shape[ $shot['size'] ] : '' ) . '">' . $mvweb_img( $shot, 'large' ) . '</span>';
			$html .= $mvweb_cap( $shot, 'name' ) . $mvweb_close( $shot );
		}

		return $html . '</div>';
	}

	if ( 'stage' === $mvweb_view ) {
		$shots  = array_slice( $mvweb_shots, 0, 8 );
		$frames = '';
		$thumbs = '';

		foreach ( $shots as $i => $shot ) {
			$chip    = $mvweb_caption && '' !== $shot['caption'] ? '<figcaption class="' . $mvweb_base . 'chip">' . esc_html( $shot['caption'] ) . '</figcaption>' : '';
			$frames .= '<figure class="' . $mvweb_base . 'frame">' . $mvweb_img( $shot, 'large' ) . $chip . '</figure>';
			$name    = '' !== $shot['caption'] ? $shot['caption'] : sprintf( /* translators: %d: number of the photograph. */ __( 'Photo %d', 'brand-market' ), $i + 1 );
			$thumbs .= '<label class="' . $mvweb_base . 'thumb"><input class="' . $mvweb_base . 'radio" type="radio" name="' . esc_attr( $mvweb_uid ) . '" value="' . ( $i + 1 ) . '"' . ( 0 === $i ? ' checked' : '' ) . '>' . wp_get_attachment_image( $shot['image'], 'medium', false, array( 'alt' => $name ) ) . '</label>';
		}

		$html .= '<div class="' . $mvweb_base . 'stage"><div class="' . $mvweb_base . 'view"' . $mvweb_rv . '>' . $frames . '</div>';

		if ( in_array( 'thumbs', $block['parts'], true ) ) {
			$html .= '<div class="' . $mvweb_base . 'ribbon" role="radiogroup" aria-label="' . esc_attr__( 'Choose a photo', 'brand-market' ) . '"' . $mvweb_rv . '>' . $thumbs . '</div>';
		}

		return $html . '</div>';
	}

	if ( 'strips' === $mvweb_view ) {
		$html .= '<div class="' . $mvweb_base . 'strips">';

		foreach ( $mvweb_shots as $i => $shot ) {
			$html .= $mvweb_open( $shot, $i + 1, $mvweb_base . 'strip', $mvweb_rv );
			$html .= $mvweb_img( $shot, 'large' ) . $mvweb_cap( $shot, 'chip' ) . $mvweb_close( $shot );
		}

		return $html . '</div>';
	}

	$rows = array(
		array(),
		array(),
	);

	foreach ( $mvweb_shots as $i => $shot ) {
		$rows[ $i % 2 ][] = $i;
	}

	$html .= '<div class="' . $mvweb_base . 'reel">';

	foreach ( $rows as $indexes ) {
		if ( empty( $indexes ) ) {
			continue;
		}

		$sets = '';

		foreach ( array( false, true ) as $copy ) {
			$sets .= '<div class="' . $mvweb_base . 'set"' . ( $copy ? ' aria-hidden="true"' : '' ) . '>';

			$cells = max( 6, count( $indexes ) );

			for ( $n = 0; $n < $cells; $n++ ) {
				$index = $indexes[ $n % count( $indexes ) ];
				$shot  = $mvweb_shots[ $index ];
				$sets .= $mvweb_open( $shot, $index + 1, $mvweb_base . 'cell', $copy ? ' tabindex="-1"' : '' );
				$sets .= $mvweb_img( $shot, 'medium_large' ) . $mvweb_cap( $shot, 'chip' ) . $mvweb_close( $shot );
			}

			$sets .= '</div>';
		}

		$html .= '<div class="' . $mvweb_base . 'row"' . $mvweb_rv . '><div class="' . $mvweb_base . 'track">' . $sets . '</div></div>';
	}

	return $html . '</div>';
};

mvweb_theme_section_open( $mvweb_block, 'reel' !== $mvweb_view );

if ( 'reel' === $mvweb_view ) {
	$mvweb_pending = array();

	foreach ( array_merge( $mvweb_block['parts'], array( '' ) ) as $mvweb_slug ) {
		if ( in_array( $mvweb_slug, array( 'kicker', 'title', 'lead', 'more' ), true ) ) {
			$mvweb_pending[] = $mvweb_slug;
			continue;
		}

		if ( ! empty( $mvweb_pending ) ) {
			echo '<div class="mvweb-t-container">';
			mvweb_theme_head( $mvweb_block, $mvweb_pending, array( 'rv' => true ) );
			echo '</div>';
			$mvweb_pending = array();
		}

		if ( 'list' === $mvweb_slug ) {
			echo $mvweb_list( $mvweb_block ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
		}
	}
} else {
	mvweb_theme_render_parts(
		$mvweb_block,
		array(
			'list' => static function ( $block ) use ( $mvweb_list ) {
				echo $mvweb_list( $block ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
			},
		),
		array( 'rv' => true )
	);
}

mvweb_theme_section_close( 'reel' !== $mvweb_view );
