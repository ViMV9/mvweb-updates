<?php
/**
 * Section template: a widget of another plugin.
 *
 * Five views: a frame, a backdrop with a running ribbon, numbered steps, a
 * bar, a dark panel. The widget is a shortcode or pasted code and its markup
 * stays its own; the theme draws the head, the frame and, for Contact Form 7,
 * the fields. The head parts come in the order the composition sets.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block     = mvweb_theme_block( 'embed', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props     = $mvweb_block['props'];
$mvweb_shortcode = mvweb_theme_form_shortcode( isset( $mvweb_props['shortcode'] ) ? (string) $mvweb_props['shortcode'] : '' );
$mvweb_code      = isset( $mvweb_props['code'] ) ? trim( (string) $mvweb_props['code'] ) : '';

if ( '' === $mvweb_shortcode && '' === $mvweb_code ) {
	return;
}

$mvweb_view   = $mvweb_block['mod'];
$mvweb_motion = '' !== $mvweb_block['motion'];
$mvweb_rv     = $mvweb_motion ? ' data-rv' : '';
$mvweb_narrow = isset( $mvweb_props['width'] ) && 'narrow' === $mvweb_props['width'] ? 'mvweb-t-embed--narrow' : '';
$mvweb_wrap   = 'stage' === $mvweb_view || 'bar' === $mvweb_view;

ob_start();
mvweb_theme_render_parts(
	$mvweb_block,
	array(),
	array(
		'rv'    => $mvweb_motion && 'steps' !== $mvweb_view,
		'class' => $mvweb_wrap ? 'mvweb-t-section-head--center' : '',
	)
);
$mvweb_head = (string) ob_get_clean();

$mvweb_widget = static function () use ( $mvweb_shortcode, $mvweb_code ) {
	if ( '' !== $mvweb_shortcode ) {
		echo $mvweb_shortcode; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Shortcode output is escaped by the plugin that owns it.
	}

	if ( '' !== $mvweb_code ) {
		echo $mvweb_code; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Filtered on save by mvweb_core_sanitize_code(): raw only for users with unfiltered_html.
	}
};

$mvweb_ribbon = '';

if ( 'stage' === $mvweb_view && in_array( 'ticker', $mvweb_block['parts'], true ) && ! empty( $mvweb_props['ticker'] ) ) {
	$mvweb_items = '';

	foreach ( mvweb_core_text_lines( $mvweb_props['ticker'] ) as $mvweb_line ) {
		$mvweb_items .= '<li>' . esc_html( $mvweb_line ) . '</li>';
	}

	$mvweb_ribbon = '<div class="mvweb-t-embed__ribbon"><div class="mvweb-t-embed__ribbon-track"><ul class="mvweb-t-embed__ribbon-list">' . $mvweb_items . '</ul><ul class="mvweb-t-embed__ribbon-list" aria-hidden="true">' . $mvweb_items . '</ul></div></div>';
}

mvweb_theme_section_open( $mvweb_block, true, $mvweb_narrow );
?>
<?php if ( 'stage' === $mvweb_view ) : ?>
	<div class="mvweb-t-embed__stage"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
		<?php echo $mvweb_ribbon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
		<div class="mvweb-t-embed__stage-body">
			<?php echo $mvweb_head; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the head helper. ?>
			<div class="mvweb-t-embed__widget mvweb-t-formgrid"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>><?php $mvweb_widget(); ?></div>
		</div>
	</div>
<?php elseif ( 'steps' === $mvweb_view ) : ?>
	<div class="mvweb-t-embed__layout">
		<?php if ( '' !== $mvweb_head ) : ?>
			<div class="mvweb-t-embed__intro"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>><?php echo $mvweb_head; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the head helper. ?></div>
		<?php endif; ?>
		<div class="mvweb-t-embed__steps mvweb-t-formgrid"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>><?php $mvweb_widget(); ?></div>
	</div>
<?php elseif ( 'bar' === $mvweb_view ) : ?>
	<div class="mvweb-t-embed__wrap">
		<?php echo $mvweb_head; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the head helper. ?>
		<div class="mvweb-t-embed__bar mvweb-t-formgrid"<?php echo $mvweb_rv . ( $mvweb_motion ? ' data-rv-dir="1"' : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attributes. ?>><?php $mvweb_widget(); ?></div>
	</div>
<?php elseif ( 'dark' === $mvweb_view ) : ?>
	<?php echo $mvweb_head; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the head helper. ?>
	<div class="mvweb-t-embed__panel mvweb-t-formgrid"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>><?php $mvweb_widget(); ?></div>
<?php else : ?>
	<?php echo $mvweb_head; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the head helper. ?>
	<div class="mvweb-t-embed__widget mvweb-t-formgrid"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>><?php $mvweb_widget(); ?></div>
<?php endif; ?>
<?php
mvweb_theme_section_close();
