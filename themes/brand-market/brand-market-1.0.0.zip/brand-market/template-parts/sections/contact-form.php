<?php
/**
 * Section template: the request form.
 *
 * Five views: a card, a colour panel, a single row, two steps, a form on a
 * photo. The form is the shortcode of Contact Form 7 and its markup stays the
 * plugin's; the theme draws it and wraps it. The heading, the lead and the
 * note come in the order the composition sets, a part without data is not
 * printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'contact-form', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_code  = mvweb_theme_form_shortcode( isset( $mvweb_props['form'] ) ? (string) $mvweb_props['form'] : '' );

if ( '' === $mvweb_code ) {
	return;
}

$mvweb_view   = $mvweb_block['mod'];
$mvweb_motion = '' !== $mvweb_block['motion'];
$mvweb_rv     = $mvweb_motion ? ' data-rv' : '';
$mvweb_dir    = in_array( $mvweb_view, array( 'bar', 'photo' ), true ) ? ' data-rv-dir="1"' : '';
$mvweb_rvtext = $mvweb_motion && 'panel' !== $mvweb_view ? ' data-rv' . $mvweb_dir : '';

$mvweb_html = array();

if ( ! empty( $mvweb_props['title'] ) ) {
	$mvweb_html['title'] = '<div class="mvweb-t-contact-form__title mvweb-t-h2"' . $mvweb_rvtext . '>' . esc_html( (string) $mvweb_props['title'] ) . '</div>';
}

if ( ! empty( $mvweb_props['text'] ) ) {
	$mvweb_html['lead'] = '<p class="mvweb-t-contact-form__lead"' . $mvweb_rvtext . '>' . esc_html( (string) $mvweb_props['text'] ) . '</p>';
}

if ( ! empty( $mvweb_props['note'] ) ) {
	$mvweb_html['note'] = '<div class="mvweb-t-contact-form__note"' . $mvweb_rvtext . '><span class="mvweb-t-contact-form__note-icon">' . mvweb_theme_icon( 'clock', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</span><p class="mvweb-t-contact-form__note-text">' . esc_html( (string) $mvweb_props['note'] ) . '</p></div>';
}

$mvweb_text = '';
$mvweb_note = '';

foreach ( $mvweb_block['parts'] as $mvweb_slug ) {
	if ( ! isset( $mvweb_html[ $mvweb_slug ] ) ) {
		continue;
	}

	if ( 'bar' === $mvweb_view && 'note' === $mvweb_slug ) {
		$mvweb_note = $mvweb_html[ $mvweb_slug ];
	} else {
		$mvweb_text .= $mvweb_html[ $mvweb_slug ];
	}
}

if ( '' !== $mvweb_text ) {
	$mvweb_text = '<div class="mvweb-t-contact-form__text">' . $mvweb_text . '</div>';
}

$mvweb_photo = '';

if ( 'photo' === $mvweb_view && in_array( 'photo', $mvweb_block['parts'], true ) && ! empty( $mvweb_props['photo'] ) ) {
	$mvweb_photo = wp_get_attachment_image( (int) $mvweb_props['photo'], 'large', false, array( 'class' => 'mvweb-t-contact-form__img' ) );
}

$mvweb_steps = 'steps' === $mvweb_view;
$mvweb_open  = '<div class="mvweb-t-contact-form__form mvweb-t-formgrid"' . $mvweb_rv . ( $mvweb_steps ? ' data-steps data-steps-label="' . esc_attr__( 'Step {n} of {total}', 'brand-market' ) . '"' : '' ) . '>';
$mvweb_form  = static function () use ( $mvweb_steps, $mvweb_code ) {
	if ( $mvweb_steps ) {
		?>
		<div class="mvweb-t-contact-form__progress" data-steps-progress hidden>
			<button class="mvweb-t-contact-form__pill mvweb-t-contact-form__pill--1" type="button" data-step-to="1" aria-current="step"><span class="mvweb-t-contact-form__pill-num">1</span><span><?php esc_html_e( 'Contacts', 'brand-market' ); ?></span></button>
			<button class="mvweb-t-contact-form__pill mvweb-t-contact-form__pill--2" type="button" data-step-to="2"><span class="mvweb-t-contact-form__pill-num">2</span><span><?php esc_html_e( 'Message', 'brand-market' ); ?></span></button>
			<span class="mvweb-t-contact-form__track" aria-hidden="true"></span>
		</div>
		<span class="screen-reader-text" role="status" data-steps-status></span>
		<?php
	}

	echo $mvweb_code; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Shortcode output is escaped by the plugin that owns it.

	if ( $mvweb_steps ) {
		?>
		<button class="mvweb-t-btn mvweb-t-btn--block mvweb-t-contact-form__submit mvweb-t-contact-form__next" type="button" data-steps-next hidden><span><?php esc_html_e( 'Next', 'brand-market' ); ?></span><?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></button>
		<button class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-contact-form__submit mvweb-t-contact-form__back" type="button" data-steps-back hidden><?php echo mvweb_theme_icon( 'arrow-left', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?><span><?php esc_html_e( 'Back', 'brand-market' ); ?></span></button>
		<?php
	}
};

mvweb_theme_section_open( $mvweb_block );
?>
<?php if ( 'panel' === $mvweb_view ) : ?>
	<div class="mvweb-t-contact-form__panel"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
		<span class="mvweb-t-contact-form__badge" aria-hidden="true"><?php echo mvweb_theme_icon( 'messages' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
		<?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
		<?php echo $mvweb_open; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
			<?php $mvweb_form(); ?>
		</div>
	</div>
<?php elseif ( 'bar' === $mvweb_view ) : ?>
	<?php if ( '' !== $mvweb_text || '' !== $mvweb_note ) : ?>
		<div class="mvweb-t-contact-form__intro">
			<?php echo $mvweb_text . $mvweb_note; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
		</div>
	<?php endif; ?>
	<?php echo $mvweb_open; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
		<?php $mvweb_form(); ?>
	</div>
<?php elseif ( 'photo' === $mvweb_view ) : ?>
	<div class="mvweb-t-contact-form__stage">
		<?php echo $mvweb_photo; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup. ?>
		<?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
		<?php echo $mvweb_open; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
			<?php $mvweb_form(); ?>
		</div>
	</div>
<?php else : ?>
	<div class="mvweb-t-contact-form__layout">
		<?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
		<?php echo $mvweb_open; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
			<?php $mvweb_form(); ?>
		</div>
	</div>
<?php endif; ?>
<?php
mvweb_theme_section_close();
