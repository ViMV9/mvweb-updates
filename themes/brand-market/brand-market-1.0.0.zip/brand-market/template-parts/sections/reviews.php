<?php
/**
 * Section template: written reviews with the ratings of review sites.
 *
 * Five views: a row of cards, a large quote with avatars to pick from, a wall
 * of notes, one review beside a list, a running strip. The reviews are rows of
 * the block or the reviews the works of the portfolio carry. The head, the
 * ratings and the reviews come in the order the composition sets where the
 * layout allows it; a part without data is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'reviews', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_view  = $mvweb_block['mod'];
$mvweb_rv    = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_rows  = array();
$mvweb_stars = array(
	'five'  => 5,
	'four'  => 4,
	'three' => 3,
);

if ( isset( $mvweb_props['source'] ) && 'works' === $mvweb_props['source'] ) {
	$mvweb_limit = isset( $mvweb_props['works_count'] ) ? max( 1, absint( $mvweb_props['works_count'] ) ) : 6;

	foreach ( mvweb_core_works( array( 'count' => 40 ) ) as $mvweb_work ) {
		$mvweb_text = trim( (string) get_post_meta( $mvweb_work, '_mvweb_review', true ) );

		if ( '' === $mvweb_text ) {
			continue;
		}

		$mvweb_rows[] = array(
			'name'   => (string) get_post_meta( $mvweb_work, '_mvweb_review_author', true ),
			'text'   => $mvweb_text,
			'source' => get_the_title( $mvweb_work ),
			'stars'  => 0,
			'photo'  => 0,
		);

		if ( count( $mvweb_rows ) >= $mvweb_limit ) {
			break;
		}
	}
} elseif ( isset( $mvweb_props['items'] ) && is_array( $mvweb_props['items'] ) ) {
	foreach ( mvweb_core_visible_rows( $mvweb_props['items'] ) as $mvweb_item ) {
		$mvweb_item += array(
			'title'  => '',
			'text'   => '',
			'source' => '',
			'stars'  => '',
			'photo'  => 0,
		);

		if ( '' === trim( (string) $mvweb_item['text'] ) ) {
			continue;
		}

		$mvweb_rows[] = array(
			'name'   => (string) $mvweb_item['title'],
			'text'   => (string) $mvweb_item['text'],
			'source' => (string) $mvweb_item['source'],
			'stars'  => isset( $mvweb_stars[ $mvweb_item['stars'] ] ) ? $mvweb_stars[ $mvweb_item['stars'] ] : 0,
			'photo'  => (int) $mvweb_item['photo'],
		);
	}
}

if ( empty( $mvweb_rows ) ) {
	return;
}

if ( 'quote' === $mvweb_view ) {
	$mvweb_rows = array_slice( $mvweb_rows, 0, 10 );
}

$mvweb_ratings = array();

if ( isset( $mvweb_props['ratings'] ) && is_array( $mvweb_props['ratings'] ) ) {
	foreach ( mvweb_core_visible_rows( $mvweb_props['ratings'] ) as $mvweb_rating ) {
		$mvweb_rating += array(
			'title' => '',
			'score' => '',
			'note'  => '',
			'url'   => '',
		);

		if ( '' !== (string) $mvweb_rating['title'] || '' !== (string) $mvweb_rating['score'] ) {
			$mvweb_ratings[] = $mvweb_rating;
		}
	}
}

$mvweb_kinds           = array( '', '', 'photo', 'lead', 'photo', '' );
$mvweb_shot_attributes = array(
	'class'   => 'mvweb-t-reviews__shot-img',
	'alt'     => '',
	'loading' => 'lazy',
);
$mvweb_hero_attributes = array(
	'class'   => 'mvweb-t-reviews__hero-img',
	'alt'     => '',
	'loading' => 'lazy',
);
$mvweb_state           = array( 'foot' => false );

$mvweb_has = static function ( $slug ) use ( $mvweb_block ) {
	return in_array( $slug, $mvweb_block['parts'], true );
};

$mvweb_has_item = static function ( $slug ) use ( $mvweb_block ) {
	return in_array( $slug, $mvweb_block['item_parts'], true );
};

$mvweb_stars_html = static function ( $count ) {
	if ( $count < 1 ) {
		return '';
	}

	$icons = '';

	for ( $i = 1; $i <= 5; $i++ ) {
		$icons .= $i <= $count ? mvweb_theme_icon( 'star-filled', array( 'class' => 'mvweb-t-icon--fill' ) ) : mvweb_theme_icon( 'star' );
	}

	/* translators: %d: number of stars out of five. */
	$label = sprintf( __( 'Rating: %d out of 5', 'brand-market' ), $count );

	return '<span class="mvweb-t-reviews__stars" role="img" aria-label="' . esc_attr( $label ) . '">' . $icons . '</span>';
};

$mvweb_photo = static function ( $row ) {
	if ( ! empty( $row['photo'] ) ) {
		return wp_get_attachment_image(
			(int) $row['photo'],
			'thumbnail',
			false,
			array(
				'class'   => 'mvweb-t-reviews__photo',
				'alt'     => '',
				'loading' => 'lazy',
			)
		);
	}

	$initials = mvweb_core_initials( $row['name'] );

	return '' !== $initials ? '<span class="mvweb-t-reviews__photo mvweb-t-reviews__photo--initials" aria-hidden="true">' . esc_html( $initials ) . '</span>' : '';
};

$mvweb_foot = static function ( $row, $block, $with_photo ) use ( $mvweb_photo ) {
	$order = array_values( array_intersect( $block['item_parts'], array( 'photo', 'name', 'source' ) ) );
	$who   = '';
	$html  = '';

	foreach ( $order as $slug ) {
		if ( 'name' === $slug && '' !== $row['name'] ) {
			$who .= '<div class="mvweb-t-reviews__name mvweb-t-h3">' . esc_html( $row['name'] ) . '</div>';
		} elseif ( 'source' === $slug && '' !== $row['source'] ) {
			$who .= '<p class="mvweb-t-reviews__source">' . esc_html( $row['source'] ) . '</p>';
		}
	}

	foreach ( $order as $slug ) {
		if ( 'photo' === $slug ) {
			$html .= $with_photo ? $mvweb_photo( $row ) : '';
		} elseif ( '' !== $who ) {
			$html .= '<div class="mvweb-t-reviews__who">' . $who . '</div>';
			$who   = '';
		}
	}

	if ( '' !== $html ) {
		echo '<footer class="mvweb-t-reviews__foot">' . $html . '</footer>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and core image markup.
	}
};

$mvweb_with_photo = true;

$mvweb_foot_part = static function ( $row, $block ) use ( &$mvweb_state, &$mvweb_with_photo, $mvweb_foot ) {
	if ( $mvweb_state['foot'] ) {
		return;
	}

	$mvweb_state['foot'] = true;
	$mvweb_foot( $row, $block, $mvweb_with_photo );
};

$mvweb_item_parts = array(
	'stars'  => static function ( $row ) use ( $mvweb_stars_html ) {
		echo $mvweb_stars_html( $row['stars'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and helper markup.
	},
	'text'   => static function ( $row ) {
		echo '<p class="mvweb-t-reviews__text">' . esc_html( $row['text'] ) . '</p>';
	},
	'photo'  => $mvweb_foot_part,
	'name'   => $mvweb_foot_part,
	'source' => $mvweb_foot_part,
);

$mvweb_card = static function ( $row, $block, $args ) use ( $mvweb_item_parts, $mvweb_rv, $mvweb_shot_attributes, &$mvweb_state, &$mvweb_with_photo ) {
	$args = wp_parse_args(
		$args,
		array(
			'tag'   => 'article',
			'class' => '',
			'rv'    => false,
			'mark'  => false,
			'shot'  => 0,
			'dir'   => '',
			'photo' => true,
			'bare'  => false,
		)
	);

	$mvweb_state['foot'] = false;
	$mvweb_with_photo    = $args['photo'] && 0 === $args['shot'];

	if ( $args['bare'] ) {
		mvweb_theme_render_item_parts( $block, $row, $mvweb_item_parts );

		return;
	}
	?>
	<<?php echo esc_attr( $args['tag'] ); ?> class="<?php echo esc_attr( $args['class'] ); ?>"<?php echo $args['rv'] ? $mvweb_rv : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?><?php echo $args['rv'] && '' !== $mvweb_rv && '' !== $args['dir'] ? ' data-rv-dir="' . esc_attr( $args['dir'] ) . '"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped attribute. ?>>
		<?php if ( $args['mark'] ) : ?>
			<span class="mvweb-t-reviews__mark" aria-hidden="true"><?php echo mvweb_theme_icon( 'quote' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
		<?php endif; ?>
		<?php if ( $args['shot'] ) : ?>
			<div class="mvweb-t-reviews__shot"><?php echo wp_get_attachment_image( (int) $args['shot'], 'large', false, $mvweb_shot_attributes ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup. ?></div>
			<div class="mvweb-t-reviews__note-body">
		<?php endif; ?>
		<?php mvweb_theme_render_item_parts( $block, $row, $mvweb_item_parts ); ?>
		<?php if ( $args['shot'] ) : ?>
			</div>
		<?php endif; ?>
	</<?php echo esc_attr( $args['tag'] ); ?>>
	<?php
};

$mvweb_rating_items = static function ( $link_class, $item_rv ) use ( $mvweb_ratings, $mvweb_rv ) {
	foreach ( $mvweb_ratings as $rating ) {
		$tag = '' !== (string) $rating['url'] ? 'a' : 'div';
		?>
		<li<?php echo $item_rv ? $mvweb_rv : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
			<<?php echo esc_attr( $tag ); ?> class="<?php echo esc_attr( $link_class ); ?>"<?php echo 'a' === $tag ? ' href="' . esc_url( (string) $rating['url'] ) . '"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped attribute. ?>>
				<?php if ( '' !== (string) $rating['score'] ) : ?>
					<span class="mvweb-t-reviews__score"><?php echo esc_html( $rating['score'] ); ?><?php echo mvweb_theme_icon( 'star-filled', array( 'class' => 'mvweb-t-icon--fill' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
				<?php endif; ?>
				<?php if ( '' !== (string) $rating['title'] || '' !== (string) $rating['note'] ) : ?>
					<span class="mvweb-t-reviews__site">
						<?php if ( '' !== (string) $rating['title'] ) : ?>
							<strong><?php echo esc_html( $rating['title'] ); ?></strong>
						<?php endif; ?>
						<?php if ( '' !== (string) $rating['note'] ) : ?>
							<span><?php echo esc_html( $rating['note'] ); ?></span>
						<?php endif; ?>
					</span>
				<?php endif; ?>
			</<?php echo esc_attr( $tag ); ?>>
		</li>
		<?php
	}
};

$mvweb_tally = static function ( $modifier ) use ( $mvweb_ratings, $mvweb_rv, $mvweb_rating_items ) {
	if ( empty( $mvweb_ratings ) ) {
		return;
	}
	?>
	<ul class="<?php echo esc_attr( trim( 'mvweb-t-reviews__tally ' . $modifier ) ); ?>"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
		<?php $mvweb_rating_items( 'mvweb-t-reviews__tally-link', false ); ?>
	</ul>
	<?php
};

$mvweb_nav = static function () {
	?>
	<div class="mvweb-t-section-head__nav">
		<?php
		echo mvweb_theme_showcase_arrows( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
			array(
				'prev' => __( 'Back', 'brand-market' ),
				'next' => __( 'Forward', 'brand-market' ),
			)
		);
		?>
	</div>
	<?php
};

$mvweb_head = static function ( array $slugs ) use ( $mvweb_block, $mvweb_view, $mvweb_nav, $mvweb_tally ) {
	ob_start();

	if ( in_array( 'nav', $slugs, true ) ) {
		$mvweb_nav();
	}

	if ( in_array( 'ratings', $slugs, true ) ) {
		$mvweb_tally( 'mvweb-t-reviews__tally--grid' );
	}

	$mvweb_side = (string) ob_get_clean();

	mvweb_theme_head(
		$mvweb_block,
		$slugs,
		array(
			'class' => 'ticker' === $mvweb_view ? 'mvweb-t-section-head--center' : '',
			'rv'    => true,
			'side'  => $mvweb_side,
		)
	);
};

$mvweb_head_slugs = array( 'kicker', 'title', 'lead' );

if ( 'rail' === $mvweb_view ) {
	$mvweb_head_slugs[] = 'nav';
} elseif ( 'split' === $mvweb_view ) {
	$mvweb_head_slugs[] = 'ratings';
}

$mvweb_pass = static function ( array $free ) use ( $mvweb_block, $mvweb_head, $mvweb_head_slugs ) {
	$pending = array();

	foreach ( array_merge( $mvweb_block['parts'], array( '' ) ) as $slug ) {
		if ( 'nav' === $slug && ! in_array( 'nav', $mvweb_head_slugs, true ) ) {
			continue;
		}

		if ( in_array( $slug, $mvweb_head_slugs, true ) ) {
			$pending[] = $slug;
			continue;
		}

		if ( ! empty( $pending ) ) {
			$mvweb_head( $pending );
			$pending = array();
		}

		if ( '' !== $slug && isset( $free[ $slug ] ) ) {
			call_user_func( $free[ $slug ], $mvweb_block );
		}
	}
};

$mvweb_rail = static function ( $block ) use ( $mvweb_rows, $mvweb_card ) {
	?>
	<div class="mvweb-t-rail__track mvweb-t-reviews__track" data-showcase-track data-scroller="<?php esc_attr_e( 'Reviews', 'brand-market' ); ?>">
		<?php
		foreach ( $mvweb_rows as $row ) {
			$mvweb_card(
				$row,
				$block,
				array(
					'class' => 'mvweb-t-reviews__card',
					'rv'    => true,
				)
			);
		}
		?>
	</div>
	<?php
};

$mvweb_quote = static function ( $block ) use ( $mvweb_rows, $mvweb_card, $mvweb_photo, $mvweb_rv ) {
	$group = wp_unique_id( 'mvweb-reviews-' );
	?>
	<div class="mvweb-t-reviews__quotes">
		<span class="mvweb-t-reviews__mark" aria-hidden="true"><?php echo mvweb_theme_icon( 'quote' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
		<div class="mvweb-t-reviews__stage"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
			<?php
			foreach ( $mvweb_rows as $row ) {
				$mvweb_card( $row, $block, array( 'class' => 'mvweb-t-reviews__slide' ) );
			}
			?>
		</div>
		<?php if ( count( $mvweb_rows ) > 1 ) : ?>
			<div class="mvweb-t-reviews__picks" role="radiogroup" aria-label="<?php esc_attr_e( 'Choose a review', 'brand-market' ); ?>"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
				<?php foreach ( array_values( $mvweb_rows ) as $index => $row ) : ?>
					<?php
					/* translators: %d: number of the review. */
					$label = '' !== $row['name'] ? $row['name'] : sprintf( __( 'Review %d', 'brand-market' ), $index + 1 );
					?>
					<label class="mvweb-t-reviews__pick"<?php echo '' !== $row['name'] ? ' title="' . esc_attr( $row['name'] ) . '"' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped attribute. ?>>
						<input class="screen-reader-text" type="radio" name="<?php echo esc_attr( $group ); ?>"<?php echo 0 === $index ? ' checked' : ''; ?>>
						<?php echo $mvweb_photo( $row ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and core image markup. ?>
						<span class="screen-reader-text"><?php echo esc_html( $label ); ?></span>
					</label>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</div>
	<?php
};

$mvweb_wall_notes = static function ( $block ) use ( $mvweb_rows, $mvweb_card, $mvweb_kinds, $mvweb_has_item ) {
	foreach ( array_values( $mvweb_rows ) as $index => $row ) {
		$kind  = $mvweb_kinds[ $index % count( $mvweb_kinds ) ];
		$class = 'mvweb-t-reviews__note';
		$args  = array( 'rv' => true );

		if ( 'photo' === $kind && ! empty( $row['photo'] ) && $mvweb_has_item( 'photo' ) ) {
			$class       .= ' mvweb-t-reviews__note--photo';
			$args['shot'] = (int) $row['photo'];
		} elseif ( 'lead' === $kind ) {
			$class       .= ' mvweb-t-reviews__note--lead';
			$args['mark'] = true;
		}

		$args['class'] = $class;
		$mvweb_card( $row, $block, $args );
	}
};

$mvweb_combo = static function ( $with_list, $with_ratings ) use ( $mvweb_view, $mvweb_block, $mvweb_ratings, $mvweb_props, $mvweb_rv, $mvweb_quote, $mvweb_wall_notes, $mvweb_tally, $mvweb_rating_items ) {
	$with_ratings = $with_ratings && ! empty( $mvweb_ratings );

	if ( 'quote' === $mvweb_view ) {
		?>
		<div class="mvweb-t-reviews__layout">
			<?php
			if ( $with_list ) {
				$mvweb_quote( $mvweb_block );
			}

			if ( $with_ratings ) {
				$mvweb_tally( '' );
			}
			?>
		</div>
		<?php
		return;
	}
	?>
	<div class="mvweb-t-reviews__wall">
		<?php if ( $with_ratings ) : ?>
			<div class="mvweb-t-reviews__tile"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
				<?php if ( ! empty( $mvweb_props['ratings_title'] ) ) : ?>
					<p class="mvweb-t-reviews__tile-title"><?php echo esc_html( $mvweb_props['ratings_title'] ); ?></p>
				<?php endif; ?>
				<ul class="mvweb-t-reviews__tally">
					<?php $mvweb_rating_items( 'mvweb-t-reviews__tally-link', false ); ?>
				</ul>
			</div>
		<?php endif; ?>
		<?php
		if ( $with_list ) {
			$mvweb_wall_notes( $mvweb_block );
		}
		?>
	</div>
	<?php
};

$mvweb_split = static function ( $block ) use ( $mvweb_hero_attributes, $mvweb_rows, $mvweb_card, $mvweb_photo, $mvweb_stars_html, $mvweb_has_item, $mvweb_rv ) {
	$hero = $mvweb_rows[0];
	$rest = array_slice( $mvweb_rows, 1 );
	$shot = ! empty( $hero['photo'] ) && $mvweb_has_item( 'photo' ) ? (int) $hero['photo'] : 0;
	$dir  = static function ( $value ) use ( $mvweb_rv ) {
		return '' !== $mvweb_rv ? ' data-rv-dir="' . esc_attr( $value ) . '"' : '';
	};
	?>
	<div class="mvweb-t-reviews__split">
		<article class="mvweb-t-reviews__hero"<?php echo $mvweb_rv . $dir( '-1' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attributes. ?>>
			<?php if ( $shot ) : ?>
				<div class="mvweb-t-reviews__hero-shot"><?php echo wp_get_attachment_image( $shot, 'large', false, $mvweb_hero_attributes ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup. ?></div>
			<?php endif; ?>
			<div class="mvweb-t-reviews__hero-body">
				<?php
				$mvweb_card(
					$hero,
					$block,
					array(
						'bare'  => true,
						'photo' => false,
					)
				);
				?>
			</div>
		</article>
		<?php if ( ! empty( $rest ) ) : ?>
			<ul class="mvweb-t-reviews__list">
				<?php foreach ( $rest as $row ) : ?>
					<?php
					$photo = $mvweb_has_item( 'photo' ) ? $mvweb_photo( $row ) : '';
					$name  = $mvweb_has_item( 'name' ) && '' !== $row['name'] ? '<div class="mvweb-t-reviews__name mvweb-t-h3">' . esc_html( $row['name'] ) . '</div>' : '';
					$stars = $mvweb_has_item( 'stars' ) ? $mvweb_stars_html( $row['stars'] ) : '';
					?>
					<li class="mvweb-t-reviews__row"<?php echo $mvweb_rv . $dir( '1' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attributes. ?>>
						<?php echo $photo; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and core image markup. ?>
						<div class="mvweb-t-reviews__row-body">
							<?php if ( '' !== $name . $stars ) : ?>
								<div class="mvweb-t-reviews__row-head"><?php echo $name . $stars; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and helper markup. ?></div>
							<?php endif; ?>
							<?php if ( $mvweb_has_item( 'text' ) ) : ?>
								<p class="mvweb-t-reviews__text"><?php echo esc_html( $row['text'] ); ?></p>
							<?php endif; ?>
							<?php if ( $mvweb_has_item( 'source' ) && '' !== $row['source'] ) : ?>
								<p class="mvweb-t-reviews__source"><?php echo esc_html( $row['source'] ); ?></p>
							<?php endif; ?>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
	<?php
};

$mvweb_belts = static function ( $block ) use ( $mvweb_rows, $mvweb_card, $mvweb_rv ) {
	$few  = count( $mvweb_rows ) < 5;
	$back = array_merge( array_slice( $mvweb_rows, (int) floor( count( $mvweb_rows ) * 2 / 3 ) ), array_slice( $mvweb_rows, 0, (int) floor( count( $mvweb_rows ) * 2 / 3 ) ) );
	$set  = static function ( array $rows, $hidden ) use ( $mvweb_card, $block ) {
		?>
		<ul class="mvweb-t-reviews__set"<?php echo $hidden ? ' aria-hidden="true"' : ''; ?>>
			<?php foreach ( $rows as $row ) : ?>
				<li>
					<?php $mvweb_card( $row, $block, array( 'class' => 'mvweb-t-reviews__slip' ) ); ?>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php
	};
	?>
	<div class="mvweb-t-reviews__belt"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?><?php echo $few ? ' data-few' : ''; ?>>
		<div class="mvweb-t-reviews__reel">
			<?php
			$set( $mvweb_rows, false );

			if ( ! $few ) {
				$set( $mvweb_rows, true );
			}
			?>
		</div>
	</div>
	<?php if ( ! $few ) : ?>
		<div class="mvweb-t-reviews__belt mvweb-t-reviews__belt--back" aria-hidden="true"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
			<div class="mvweb-t-reviews__reel">
				<?php
				$set( $back, false );
				$set( $back, false );
				?>
			</div>
		</div>
	<?php endif; ?>
	<?php
};

if ( 'rail' === $mvweb_view ) {
	mvweb_theme_section_open( $mvweb_block, false );
	echo '<div class="mvweb-t-container" data-showcase>';
	$mvweb_pass(
		array(
			'ratings' => static function () use ( $mvweb_ratings, $mvweb_rating_items ) {
				if ( ! empty( $mvweb_ratings ) ) {
					echo '<ul class="mvweb-t-reviews__ratings">';
					$mvweb_rating_items( 'mvweb-t-reviews__rating', true );
					echo '</ul>';
				}
			},
			'list'    => $mvweb_rail,
		)
	);
	echo '</div>';
	mvweb_theme_section_close( false );
} elseif ( 'quote' === $mvweb_view || 'wall' === $mvweb_view ) {
	mvweb_theme_section_open( $mvweb_block );
	$mvweb_pass(
		array(
			'ratings' => static function () use ( $mvweb_has, $mvweb_combo ) {
				if ( ! $mvweb_has( 'list' ) ) {
					$mvweb_combo( false, true );
				}
			},
			'list'    => static function () use ( $mvweb_has, $mvweb_combo ) {
				$mvweb_combo( true, $mvweb_has( 'ratings' ) );
			},
		)
	);
	mvweb_theme_section_close();
} elseif ( 'split' === $mvweb_view ) {
	mvweb_theme_section_open( $mvweb_block );
	$mvweb_pass( array( 'list' => $mvweb_split ) );
	mvweb_theme_section_close();
} else {
	mvweb_theme_section_open( $mvweb_block );
	$mvweb_pass(
		array(
			'ratings' => static function () use ( $mvweb_tally ) {
				$mvweb_tally( 'mvweb-t-reviews__tally--center' );
			},
		)
	);
	echo '</div>';

	if ( $mvweb_has( 'list' ) ) {
		$mvweb_belts( $mvweb_block );
	}

	mvweb_theme_section_close( false );
}
