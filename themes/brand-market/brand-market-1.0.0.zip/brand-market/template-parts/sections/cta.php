<?php
/**
 * Section template: a call to action.
 *
 * Five views: an accent card, a line with a rule, a photo with buttons, large
 * type between two running lines, two halves. The heading, the text and the
 * buttons come in the order the composition sets; the phone is the one of the
 * contacts of the site. A part without data is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'cta', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_view  = $mvweb_block['mod'];
$mvweb_parts = $mvweb_block['parts'];
$mvweb_look  = $mvweb_block['look'];
$mvweb_rv    = '' !== $mvweb_block['motion'] && 'duo' !== $mvweb_view ? ' data-rv' : '';
$mvweb_kind  = 'mvweb-t-btn' . ( 'secondary' === $mvweb_look['button_kind'] ? ' mvweb-t-btn--outline' : ( 'link' === $mvweb_look['button_kind'] ? ' mvweb-t-btn--link' : '' ) );
$mvweb_book  = mvweb_core_contacts();
$mvweb_tel   = ! empty( $mvweb_book['phones'][0] ) ? $mvweb_book['phones'][0] : array();
$mvweb_call  = static function ( $props ) use ( $mvweb_tel, $mvweb_view ) {
	if ( empty( $mvweb_tel['href'] ) || empty( $mvweb_tel['number'] ) ) {
		return '';
	}

	$label = isset( $props['phone_label'] ) ? trim( (string) $props['phone_label'] ) : '';
	$text  = trim( $label . ' ' . $mvweb_tel['number'] );

	if ( 'photo' === $mvweb_view ) {
		return '<a class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-cta__call" href="' . esc_url( $mvweb_tel['href'] ) . '">' . mvweb_theme_icon( 'phone', array( 'class' => 'mvweb-t-icon--sm' ) ) . '<span>' . esc_html( $text ) . '</span></a>';
	}

	return '<a class="mvweb-t-cta__phone" href="' . esc_url( $mvweb_tel['href'] ) . '">' . mvweb_theme_icon( 'phone', array( 'class' => 'mvweb-t-icon--sm' ) ) . '<span>' . esc_html( $text ) . '</span></a>';
};

$mvweb_pieces = static function ( $one, $parts ) use ( $mvweb_view, $mvweb_rv, $mvweb_kind ) {
	$html = array();

	if ( ! empty( $one['kicker'] ) ) {
		$html['kicker'] = 'line' === $mvweb_view
			? '<p class="mvweb-t-cta__status"' . $mvweb_rv . '><span class="mvweb-t-cta__dot" aria-hidden="true"></span>' . esc_html( (string) $one['kicker'] ) . '</p>'
			: '<p class="mvweb-t-cta__kicker">' . esc_html( (string) $one['kicker'] ) . '</p>';
	}

	if ( ! empty( $one['title'] ) ) {
		$html['title'] = '<div class="mvweb-t-cta__title mvweb-t-h2"' . $mvweb_rv . '>' . esc_html( (string) $one['title'] ) . '</div>';
	}

	if ( ! empty( $one['text'] ) ) {
		$html['lead'] = '<p class="mvweb-t-cta__lead"' . $mvweb_rv . '>' . esc_html( (string) $one['text'] ) . '</p>';
	}

	if ( ! empty( $one['button_text'] ) && ! empty( $one['button_url'] ) ) {
		$html['button'] = '<a class="' . esc_attr( $mvweb_kind ) . ' mvweb-t-cta__button" href="' . esc_url( (string) $one['button_url'] ) . '">' . esc_html( (string) $one['button_text'] ) . ' ' . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm mvweb-t-cta__arrow' ) ) . '</a>';
	}

	if ( ! empty( $one['phone'] ) ) {
		$html['phone'] = $one['phone'];
	}

	$text    = '';
	$actions = '';

	foreach ( $parts as $slug ) {
		if ( ! isset( $html[ $slug ] ) ) {
			continue;
		}

		if ( in_array( $slug, array( 'button', 'phone' ), true ) ) {
			$actions .= $html[ $slug ];
		} else {
			$text .= $html[ $slug ];
		}
	}

	return array(
		'text'    => $text,
		'actions' => $actions,
	);
};

$mvweb_main = $mvweb_pieces(
	array(
		'kicker'      => isset( $mvweb_props['kicker'] ) ? $mvweb_props['kicker'] : '',
		'title'       => isset( $mvweb_props['title'] ) ? $mvweb_props['title'] : '',
		'text'        => isset( $mvweb_props['text'] ) ? $mvweb_props['text'] : '',
		'button_text' => isset( $mvweb_props['button_text'] ) ? $mvweb_props['button_text'] : '',
		'button_url'  => isset( $mvweb_props['button_url'] ) ? $mvweb_props['button_url'] : '',
		'phone'       => $mvweb_call( $mvweb_props ),
	),
	$mvweb_parts
);

$mvweb_dir     = '' !== $mvweb_rv && 'line' === $mvweb_view ? ' data-rv-dir="-1"' : '';
$mvweb_actions = static function ( $inner, $dir = '' ) use ( $mvweb_rv ) {
	return '' === $inner ? '' : '<div class="mvweb-t-cta__actions"' . $mvweb_rv . $dir . '>' . $inner . '</div>';
};
$mvweb_ticker  = '';

if ( 'marquee' === $mvweb_view && in_array( 'ticker', $mvweb_parts, true ) && ! empty( $mvweb_props['ticker'] ) ) {
	$mvweb_words = '';

	foreach ( mvweb_core_text_lines( $mvweb_props['ticker'] ) as $mvweb_word ) {
		$mvweb_words .= '<li class="mvweb-t-cta__word">' . esc_html( $mvweb_word ) . '</li>';
	}

	$mvweb_reel   = '<ul class="mvweb-t-cta__reel">' . $mvweb_words . '</ul>';
	$mvweb_ticker = '<div class="mvweb-t-cta__track">' . $mvweb_reel . $mvweb_reel . '</div>';
}

if ( '' === $mvweb_main['text'] && '' === $mvweb_main['actions'] && '' === $mvweb_ticker ) {
	return;
}

mvweb_theme_section_open( $mvweb_block, 'marquee' !== $mvweb_view );
?>
<?php if ( 'line' === $mvweb_view ) : ?>
	<div class="mvweb-t-cta__row">
		<?php if ( '' !== $mvweb_main['text'] ) : ?>
			<div class="mvweb-t-cta__text"><?php echo $mvweb_main['text']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?></div>
		<?php endif; ?>
		<?php echo $mvweb_actions( $mvweb_main['actions'], $mvweb_dir ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
	</div>
<?php elseif ( 'photo' === $mvweb_view ) : ?>
	<?php
	$mvweb_frame = '';

	if ( in_array( 'photo', $mvweb_parts, true ) && ! empty( $mvweb_props['image'] ) ) {
		$mvweb_frame = '<div class="mvweb-t-cta__frame"' . $mvweb_rv . '>' . wp_get_attachment_image( (int) $mvweb_props['image'], 'large', false, array( 'class' => 'mvweb-t-cta__pic' ) ) . ( ! empty( $mvweb_props['badge'] ) ? '<span class="mvweb-t-cta__chip">' . esc_html( (string) $mvweb_props['badge'] ) . '</span>' : '' ) . '</div>';
	}

	$mvweb_panel = 'mvweb-t-cta__panel' . ( 'end' === $mvweb_look['image_side'] ? ' mvweb-t-cta__panel--end' : '' ) . ( in_array( $mvweb_look['image_size'], array( 's', 'l' ), true ) ? ' mvweb-t-cta__panel--' . $mvweb_look['image_size'] : '' );
	?>
	<div class="<?php echo esc_attr( $mvweb_panel ); ?>">
		<?php echo $mvweb_frame; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
		<div class="mvweb-t-cta__text">
			<?php echo $mvweb_main['text']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
			<?php echo $mvweb_actions( $mvweb_main['actions'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
		</div>
	</div>
<?php elseif ( 'marquee' === $mvweb_view ) : ?>
	<div class="mvweb-t-cta__stage">
		<?php if ( '' !== $mvweb_ticker ) : ?>
			<div class="mvweb-t-cta__belt" aria-hidden="true"><?php echo $mvweb_ticker; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?></div>
		<?php endif; ?>
		<?php if ( '' !== $mvweb_main['text'] || '' !== $mvweb_main['actions'] ) : ?>
			<div class="mvweb-t-container">
				<div class="mvweb-t-cta__big">
					<?php echo $mvweb_main['text']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
					<?php echo $mvweb_actions( $mvweb_main['actions'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
				</div>
			</div>
		<?php endif; ?>
		<?php if ( '' !== $mvweb_ticker ) : ?>
			<div class="mvweb-t-cta__belt mvweb-t-cta__belt--back" aria-hidden="true"><?php echo $mvweb_ticker; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?></div>
		<?php endif; ?>
	</div>
<?php elseif ( 'duo' === $mvweb_view ) : ?>
	<?php
	$mvweb_halves = array();
	$mvweb_motion = '' !== $mvweb_block['motion'] ? ' data-rv' : '';

	if ( '' !== $mvweb_main['text'] || '' !== $mvweb_main['actions'] ) {
		$mvweb_halves[] = array(
			'class'   => 'mvweb-t-cta__half--retail',
			'icon'    => isset( $mvweb_props['icon'] ) ? (string) $mvweb_props['icon'] : '',
			'content' => $mvweb_main,
		);
	}

	if ( in_array( 'second', $mvweb_parts, true ) ) {
		$mvweb_second = $mvweb_pieces(
			array(
				'kicker'      => isset( $mvweb_props['second_kicker'] ) ? $mvweb_props['second_kicker'] : '',
				'title'       => isset( $mvweb_props['second_title'] ) ? $mvweb_props['second_title'] : '',
				'text'        => isset( $mvweb_props['second_text'] ) ? $mvweb_props['second_text'] : '',
				'button_text' => isset( $mvweb_props['second_button'] ) ? $mvweb_props['second_button'] : '',
				'button_url'  => isset( $mvweb_props['second_url'] ) ? $mvweb_props['second_url'] : '',
				'phone'       => ! empty( $mvweb_props['second_phone'] ) ? $mvweb_call( $mvweb_props ) : '',
			),
			array_unique( array_merge( $mvweb_parts, array( 'phone' ) ) )
		);

		if ( '' !== $mvweb_second['text'] || '' !== $mvweb_second['actions'] ) {
			$mvweb_halves[] = array(
				'class'   => 'mvweb-t-cta__half--trade',
				'icon'    => isset( $mvweb_props['second_icon'] ) ? (string) $mvweb_props['second_icon'] : '',
				'content' => $mvweb_second,
			);
		}
	}
	?>
	<div class="mvweb-t-cta__pair">
		<?php foreach ( $mvweb_halves as $mvweb_half ) : ?>
			<div class="<?php echo esc_attr( 'mvweb-t-cta__half ' . $mvweb_half['class'] ); ?>"<?php echo $mvweb_motion; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
				<?php if ( '' !== $mvweb_half['icon'] ) : ?>
					<span class="mvweb-t-cta__glyph" aria-hidden="true"><?php echo mvweb_theme_icon( $mvweb_half['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
				<?php endif; ?>
				<?php echo $mvweb_half['content']['text']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
				<?php echo $mvweb_actions( $mvweb_half['content']['actions'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
			</div>
		<?php endforeach; ?>
	</div>
<?php else : ?>
	<div class="<?php echo esc_attr( 'mvweb-t-cta__card' . ( 'inverse' === $mvweb_look['background'] ? ' mvweb-t-cta__card--inverse' : '' ) ); ?>">
		<?php if ( '' !== $mvweb_main['text'] ) : ?>
			<div class="mvweb-t-cta__text"><?php echo $mvweb_main['text']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?></div>
		<?php endif; ?>
		<?php echo $mvweb_actions( $mvweb_main['actions'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
	</div>
<?php endif; ?>
<?php
mvweb_theme_section_close( 'marquee' !== $mvweb_view );
