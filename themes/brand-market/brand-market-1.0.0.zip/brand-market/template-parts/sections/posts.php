<?php
/**
 * Section template: the latest posts of the blog.
 *
 * Five views: a grid of cards, one large post beside a list, a horizontal
 * ribbon, a magazine grid, rows with a big date. The cards are the blog's own
 * (the area card-post, set once for the site); the head and the list follow the
 * order the composition sets, and a part without data is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block    = mvweb_theme_block( 'posts', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props    = $mvweb_block['props'];
$mvweb_category = isset( $mvweb_props['category'] ) ? absint( $mvweb_props['category'] ) : 0;
$mvweb_count    = isset( $mvweb_props['count'] ) ? max( 1, min( 12, absint( $mvweb_props['count'] ) ) ) : 3;

$mvweb_query = new WP_Query(
	array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'posts_per_page'      => $mvweb_count,
		'cat'                 => $mvweb_category,
		'orderby'             => array(
			'date' => 'DESC',
			'ID'   => 'DESC',
		),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
		'post__not_in'        => is_singular( 'post' ) ? array( get_queried_object_id() ) : array(),
	)
);

if ( ! $mvweb_query->have_posts() ) {
	return;
}

if ( empty( $mvweb_block['props']['link_url'] ) ) {
	$mvweb_link = '';

	if ( $mvweb_category > 0 ) {
		$mvweb_link = get_category_link( $mvweb_category );
	} else {
		$mvweb_link = mvweb_core_blog_url();
	}

	$mvweb_block['props']['link_url'] = is_string( $mvweb_link ) ? $mvweb_link : '';
}

$mvweb_view  = $mvweb_block['view'];
$mvweb_rv    = '' !== $mvweb_block['motion'];
$mvweb_card  = static function ( $modifier = '', $hide = array(), $go = false ) use ( $mvweb_rv ) {
	get_template_part(
		'template-parts/post-card',
		null,
		array(
			'modifier' => $modifier,
			'hide'     => $hide,
			'go'       => $go,
			'rv'       => $mvweb_rv,
		)
	);
};
$mvweb_parts = array(
	'list' => static function () use ( $mvweb_query, $mvweb_view, $mvweb_card ) {
		$index = 0;

		if ( '2' === $mvweb_view ) {
			echo '<div class="mvweb-t-posts__feature">';
		} elseif ( '3' === $mvweb_view ) {
			echo '<div class="mvweb-t-posts__track" tabindex="0" role="region" aria-label="' . esc_attr__( 'Blog posts, scroll sideways', 'brand-market' ) . '">';
		} elseif ( '4' === $mvweb_view ) {
			echo '<div class="mvweb-t-posts__mag">';
		} elseif ( '5' === $mvweb_view ) {
			echo '<div class="mvweb-t-posts__rows">';
		} else {
			echo '<div class="mvweb-t-posts__grid">';
		}

		while ( $mvweb_query->have_posts() ) {
			$mvweb_query->the_post();

			if ( '2' === $mvweb_view && $index >= 5 ) {
				break;
			}

			if ( '2' === $mvweb_view ) {
				if ( 0 === $index ) {
					$mvweb_card( 'lead' );
				} else {
					echo 1 === $index ? '<div class="mvweb-t-posts__side">' : '';
					$mvweb_card( 'compact', array( 'lead', 'more' ) );
				}
			} elseif ( '4' === $mvweb_view ) {
				$wide = in_array( $index % 4, array( 0, 3 ), true );
				$mvweb_card( $wide ? 'wide' : 'narrow', $wide ? array() : array( 'lead', 'more' ), true );
			} elseif ( '5' === $mvweb_view ) {
				$mvweb_card( 'row' );
			} else {
				$mvweb_card();
			}

			++$index;
		}

		if ( '2' === $mvweb_view && $index > 1 ) {
			echo '</div>';
		}

		echo '</div>';
		wp_reset_postdata();
	},
);

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts( $mvweb_block, $mvweb_parts, array( 'rv' => true ) );
mvweb_theme_section_close();
