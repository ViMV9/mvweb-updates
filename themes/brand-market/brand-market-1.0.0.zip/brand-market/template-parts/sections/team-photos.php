<?php
/**
 * Section template: the team as a wall of photographs.
 *
 * Five views: a mosaic beside the text, a square grid, a tilted collage, a
 * panoramic strip, one group photo with dots on the people. The head, the
 * button and the photographs come in the order the composition sets where the
 * layout allows it; the mosaic, the strip and the group photo keep their
 * geometry and only hide what is switched off. A part without data is not
 * printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'team-photos', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_rows  = array();

foreach ( isset( $mvweb_props['photos'] ) && is_array( $mvweb_props['photos'] ) ? mvweb_core_visible_rows( $mvweb_props['photos'] ) : array() as $mvweb_row ) {
	if ( ! empty( $mvweb_row['image'] ) ) {
		$mvweb_rows[] = $mvweb_row;
	}
}

if ( empty( $mvweb_rows ) ) {
	return;
}

$mvweb_view  = $mvweb_block['mod'];
$mvweb_rv    = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_state = array(
	'caption' => false,
	'decor'   => false,
);
$mvweb_kits  = array(
	''         => array(
		'list'    => 'wall',
		'item'    => 'item',
		'shot'    => '',
		'caption' => 'figcaption',
		'class'   => 'chip',
		'rv'      => true,
	),
	'grid'     => array(
		'list'    => 'squares',
		'item'    => 'card',
		'shot'    => 'shot',
		'caption' => 'figcaption',
		'class'   => 'caption',
		'rv'      => true,
	),
	'collage'  => array(
		'list'    => 'board',
		'item'    => 'polaroid',
		'shot'    => 'pic',
		'caption' => 'figcaption',
		'class'   => 'label',
		'rv'      => true,
	),
	'panorama' => array(
		'list'    => '',
		'item'    => 'frame',
		'shot'    => '',
		'caption' => 'figcaption',
		'class'   => 'chip',
		'rv'      => false,
	),
	'group'    => array(
		'list'    => 'crew',
		'item'    => 'person',
		'shot'    => '',
		'caption' => 'span',
		'class'   => 'who',
		'rv'      => true,
	),
);
$mvweb_kit   = isset( $mvweb_kits[ $mvweb_view ] ) ? $mvweb_kits[ $mvweb_view ] : $mvweb_kits[''];
$mvweb_group = 'group' === $mvweb_view;
$mvweb_few   = count( $mvweb_rows ) < 3;

$mvweb_caption_lines = static function ( $item, $block ) {
	$lines = array();

	foreach ( $block['item_parts'] as $slug ) {
		if ( ( 'name' === $slug || 'role' === $slug ) && '' !== (string) $item[ $slug ] ) {
			$lines[ $slug ] = (string) $item[ $slug ];
		}
	}

	return $lines;
};

$mvweb_caption = static function ( $item, $block ) use ( &$mvweb_state, $mvweb_kit, $mvweb_caption_lines ) {
	if ( $mvweb_state['caption'] ) {
		return;
	}

	$mvweb_state['caption'] = true;
	$lines                  = $mvweb_caption_lines( $item, $block );

	if ( empty( $lines ) ) {
		return;
	}
	?>
	<<?php echo esc_attr( $mvweb_kit['caption'] ); ?> class="<?php echo esc_attr( 'mvweb-t-team-photos__' . $mvweb_kit['class'] ); ?>">
		<?php foreach ( $lines as $slug => $line ) : ?>
			<span class="<?php echo esc_attr( 'mvweb-t-team-photos__' . $slug ); ?>"><?php echo esc_html( $line ); ?></span>
		<?php endforeach; ?>
	</<?php echo esc_attr( $mvweb_kit['caption'] ); ?>>
	<?php
};

$mvweb_item_parts = array(
	'image' => static function ( $item ) use ( $mvweb_kit, $mvweb_group, &$mvweb_state ) {
		$attributes = array( 'loading' => 'lazy' );

		if ( $mvweb_group ) {
			$attributes['class'] = 'mvweb-t-team-photos__avatar';
		}

		if ( $mvweb_group || $mvweb_state['decor'] ) {
			$attributes['alt'] = '';
		}

		$image = wp_get_attachment_image( (int) $item['image'], $mvweb_group ? 'thumbnail' : 'large', false, $attributes );

		echo '' === $mvweb_kit['shot'] ? $image : '<span class="mvweb-t-team-photos__' . esc_attr( $mvweb_kit['shot'] ) . '">' . $image . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup and escaped values.
	},
	'name'  => $mvweb_caption,
	'role'  => $mvweb_caption,
);

$mvweb_items = static function ( $block ) use ( $mvweb_rows, $mvweb_kit, $mvweb_group, $mvweb_rv, $mvweb_item_parts, &$mvweb_state ) {
	$tag = $mvweb_group ? 'li' : 'figure';

	foreach ( $mvweb_rows as $row ) {
		$mvweb_state['caption'] = false;
		?>
		<<?php echo esc_attr( $tag ); ?> class="<?php echo esc_attr( 'mvweb-t-team-photos__' . $mvweb_kit['item'] ); ?>"<?php echo $mvweb_kit['rv'] ? $mvweb_rv : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
			<?php mvweb_theme_render_item_parts( $block, $row, $mvweb_item_parts ); ?>
		</<?php echo esc_attr( $tag ); ?>>
		<?php
	}
};

$mvweb_wall = static function ( $block ) use ( $mvweb_view, $mvweb_kit, $mvweb_group, $mvweb_few, $mvweb_rv, $mvweb_items, &$mvweb_state ) {
	if ( 'panorama' === $mvweb_view ) {
		$sets = $mvweb_few ? 1 : 3;
		?>
		<div class="mvweb-t-team-photos__reel"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?> role="group" aria-label="<?php esc_attr_e( 'Team photos', 'brand-market' ); ?>"<?php echo $mvweb_few ? ' data-few' : ''; ?>>
			<div class="mvweb-t-team-photos__track">
				<?php for ( $set = 0; $set < $sets; $set++ ) : ?>
					<div class="mvweb-t-team-photos__set"<?php echo $set > 0 ? ' aria-hidden="true"' : ''; ?>>
						<?php
						$mvweb_state['decor'] = $set > 0;
						$mvweb_items( $block );
						?>
					</div>
				<?php endfor; ?>
			</div>
		</div>
		<?php
		$mvweb_state['decor'] = false;

		return;
	}

	$tag = $mvweb_group ? 'ul' : 'div';
	?>
	<<?php echo esc_attr( $tag ); ?> class="<?php echo esc_attr( 'mvweb-t-team-photos__' . $mvweb_kit['list'] ); ?>">
		<?php $mvweb_items( $block ); ?>
	</<?php echo esc_attr( $tag ); ?>>
	<?php
};

$mvweb_stage = static function ( $block ) use ( $mvweb_props, $mvweb_rows, $mvweb_rv, $mvweb_caption_lines ) {
	$image = isset( $mvweb_props['group_image'] ) ? (int) $mvweb_props['group_image'] : 0;

	if ( ! $image ) {
		return;
	}

	$pins = array();

	foreach ( $mvweb_rows as $row ) {
		$label = implode( ', ', array_filter( array( (string) $row['name'], (string) $row['role'] ), 'strlen' ) );

		if ( $row['pin_x'] > 0 && $row['pin_y'] > 0 && '' !== $label ) {
			$pins[] = array(
				'style' => '--x:' . (float) $row['pin_x'] . '%;--y:' . (float) $row['pin_y'] . '%',
				'label' => $label,
				'lines' => $mvweb_caption_lines( $row, $block ),
			);
		}
	}
	?>
	<div class="mvweb-t-team-photos__stage"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
		<figure class="mvweb-t-team-photos__group"><?php echo wp_get_attachment_image( $image, 'large', false, array( 'loading' => 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core image markup. ?></figure>
		<?php if ( ! empty( $pins ) ) : ?>
			<ul class="mvweb-t-team-photos__pins">
				<?php foreach ( $pins as $pin ) : ?>
					<li class="mvweb-t-team-photos__pin" style="<?php echo esc_attr( $pin['style'] ); ?>">
						<button class="mvweb-t-team-photos__dot" type="button" aria-label="<?php echo esc_attr( $pin['label'] ); ?>"></button>
						<?php if ( ! empty( $pin['lines'] ) ) : ?>
							<span class="mvweb-t-team-photos__tag">
								<?php foreach ( $pin['lines'] as $slug => $line ) : ?>
									<span class="<?php echo esc_attr( 'mvweb-t-team-photos__' . $slug ); ?>"><?php echo esc_html( $line ); ?></span>
								<?php endforeach; ?>
							</span>
						<?php endif; ?>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
	<?php
};

$mvweb_button = static function () use ( $mvweb_props, $mvweb_block, $mvweb_rv ) {
	$text = isset( $mvweb_props['button_text'] ) ? (string) $mvweb_props['button_text'] : '';
	$url  = isset( $mvweb_props['button_url'] ) ? (string) $mvweb_props['button_url'] : '';
	$kind = array(
		'secondary' => ' mvweb-t-btn--outline',
		'link'      => ' mvweb-t-btn--link',
	);

	if ( '' === $text || '' === $url ) {
		return false;
	}

	$modifier = isset( $kind[ $mvweb_block['look']['button_kind'] ] ) ? $kind[ $mvweb_block['look']['button_kind'] ] : '';
	?>
	<a class="<?php echo esc_attr( 'mvweb-t-btn' . $modifier ); ?>" href="<?php echo esc_url( $url ); ?>"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>><?php echo esc_html( $text ); ?></a>
	<?php

	return true;
};

$mvweb_head = static function ( array $slugs ) use ( $mvweb_block, $mvweb_view, $mvweb_button ) {
	ob_start();

	if ( in_array( 'button', $slugs, true ) ) {
		$mvweb_button();
	}

	$mvweb_side = (string) ob_get_clean();

	mvweb_theme_head(
		$mvweb_block,
		$slugs,
		array(
			'class' => 'collage' === $mvweb_view ? 'mvweb-t-section-head--center' : '',
			'rv'    => true,
			'side'  => $mvweb_side,
		)
	);
};

$mvweb_pass = static function ( array $free, $inside ) use ( $mvweb_block, $mvweb_head, $mvweb_button ) {
	$pending = array();

	foreach ( array_merge( $mvweb_block['parts'], array( '' ) ) as $slug ) {
		if ( in_array( $slug, array( 'kicker', 'title', 'lead' ), true ) || ( $inside && 'button' === $slug ) ) {
			$pending[] = $slug;
			continue;
		}

		if ( ! empty( $pending ) ) {
			$mvweb_head( $pending );
			$pending = array();
		}

		if ( 'button' === $slug ) {
			$mvweb_button();
		} elseif ( '' !== $slug && isset( $free[ $slug ] ) ) {
			call_user_func( $free[ $slug ], $mvweb_block );
		}
	}
};

$mvweb_has = static function ( $slug ) use ( $mvweb_block ) {
	return in_array( $slug, $mvweb_block['parts'], true );
};

mvweb_theme_section_open( $mvweb_block );

if ( '' === $mvweb_view ) {
	ob_start();
	$mvweb_pass( array(), false );
	$mvweb_text = trim( (string) ob_get_clean() );
	?>
	<div class="mvweb-t-team-photos__layout">
		<?php if ( '' !== $mvweb_text ) : ?>
			<div class="mvweb-t-team-photos__text"><?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts above. ?></div>
		<?php endif; ?>
		<?php
		if ( $mvweb_has( 'wall' ) ) {
			$mvweb_wall( $mvweb_block );
		}
		?>
	</div>
	<?php
} elseif ( 'panorama' === $mvweb_view ) {
	$mvweb_pass( array(), true );
	echo '</div>';

	if ( $mvweb_has( 'wall' ) ) {
		$mvweb_wall( $mvweb_block );
	}
} elseif ( 'group' === $mvweb_view ) {
	$mvweb_pass( array(), true );
	ob_start();

	if ( $mvweb_has( 'group_photo' ) ) {
		$mvweb_stage( $mvweb_block );
	}

	if ( $mvweb_has( 'wall' ) ) {
		$mvweb_wall( $mvweb_block );
	}

	$mvweb_board = trim( (string) ob_get_clean() );

	if ( '' !== $mvweb_board ) {
		?>
		<div class="mvweb-t-team-photos__board"><?php echo $mvweb_board; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts above. ?></div>
		<?php
	}
} else {
	$mvweb_pass( array( 'wall' => $mvweb_wall ), true );
}

mvweb_theme_section_close( 'panorama' !== $mvweb_view );
