<?php
/**
 * Section template: where to find us and whom to call.
 *
 * Five views: tiles above a map, a map beside the rows, a card over the map, a
 * large phone, tabs of cities. Every contact is that of the chosen city, from
 * the branches; the messengers are those of the company details. The parts
 * come in the order the composition sets, each view keeping the columns and
 * the boxes of its layout; a part without data is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block  = mvweb_theme_block( 'contacts', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props  = $mvweb_block['props'];
$mvweb_view   = $mvweb_block['view'];
$mvweb_motion = '' !== $mvweb_block['motion'];
$mvweb_data   = mvweb_core_contacts();

$mvweb_text = static function ( $key ) use ( $mvweb_props ) {
	return isset( $mvweb_props[ $key ] ) ? trim( (string) $mvweb_props[ $key ] ) : '';
};

$mvweb_rv = static function ( $dir = 0 ) use ( $mvweb_motion ) {
	if ( ! $mvweb_motion ) {
		return '';
	}

	return ' data-rv' . ( 0 !== $dir ? ' data-rv-dir="' . (int) $dir . '"' : '' );
};

$mvweb_nest = static function ( array $items, array $wrap, $depth = 0 ) use ( &$mvweb_nest ) {
	$out  = '';
	$name = '';
	$run  = array();

	$items[] = array(
		'path' => array(),
		'html' => '',
	);

	foreach ( $items as $item ) {
		$next = isset( $item['path'][ $depth ] ) ? $item['path'][ $depth ] : '';

		if ( $next !== $name || '' === $name ) {
			if ( '' !== $name && ! empty( $run ) ) {
				$inner = $mvweb_nest( $run, $wrap, $depth + 1 );
				$out  .= '' === trim( $inner ) ? '' : call_user_func( $wrap[ $name ], $inner );
			}

			$run  = array();
			$name = $next;

			if ( '' === $next ) {
				$out .= $item['html'];
				continue;
			}
		}

		$run[] = $item;
	}

	return $out;
};

$mvweb_facts_of = static function ( array $data ) use ( $mvweb_text ) {
	$facts = array(
		'phone'   => array(),
		'email'   => array(),
		'address' => array(),
		'hours'   => array(),
	);

	foreach ( $data['phones'] as $phone ) {
		$number = trim( (string) $phone['number'] );
		$label  = trim( (string) $phone['label'] );

		if ( '' !== $number ) {
			$facts['phone'][] = array(
				'icon'  => 'phone',
				'label' => __( 'Phone', 'brand-market' ),
				'value' => $number,
				'href'  => (string) $phone['href'],
				'note'  => '' !== $label ? $label : $mvweb_text( 'phone_note' ),
			);
		}
	}

	$email = trim( (string) $data['email'] );

	if ( '' !== $email ) {
		$facts['email'][] = array(
			'icon'  => 'mail',
			'label' => __( 'E-mail', 'brand-market' ),
			'value' => $email,
			'href'  => 'mailto:' . $email,
			'note'  => $mvweb_text( 'email_note' ),
		);
	}

	foreach ( $data['addresses'] as $place ) {
		$street = trim( (string) $place['address'] );
		$city   = trim( (string) $place['city'] );
		$name   = count( $data['addresses'] ) > 1 ? trim( (string) $place['title'] ) : '';

		if ( '' !== $street ) {
			$facts['address'][] = array(
				'icon'  => 'map-pin',
				'label' => '' !== $name ? $name : __( 'Address', 'brand-market' ),
				'value' => '' === $city || str_contains( $street, $city ) ? $street : $city . ', ' . $street,
				'href'  => '',
				'note'  => trim( (string) $place['note'] ),
			);
		}
	}

	$hours = array();

	foreach ( $data['hours'] as $row ) {
		$line = trim( $row['days'] . ' ' . $row['time'] );

		if ( '' !== $line ) {
			$hours[] = $line;
		}
	}

	if ( ! empty( $hours ) ) {
		$facts['hours'][] = array(
			'icon'  => 'clock',
			'label' => __( 'Opening hours', 'brand-market' ),
			'value' => implode( ', ', $hours ),
			'href'  => '',
			'note'  => $mvweb_text( 'hours_note' ),
		);
	}

	return $facts;
};

$mvweb_map_of = static function ( array $data ) {
	$map = array(
		'src'   => '',
		'image' => '',
		'link'  => '',
	);

	foreach ( $data['branches'] as $branch ) {
		$map['src']  = '' === $map['src'] ? (string) $branch['map'] : $map['src'];
		$map['link'] = '' === $map['link'] ? (string) $branch['map_link'] : $map['link'];
	}

	if ( '' === $map['src'] ) {
		$profile      = mvweb_core_profile_map();
		$map['src']   = $profile['src'];
		$map['image'] = $profile['image'];
	}

	return $map;
};

$mvweb_frame = static function ( array $map, $name ) {
	if ( '' !== $map['image'] ) {
		$id = attachment_url_to_postid( $map['image'] );

		return $id
			? wp_get_attachment_image(
				$id,
				'large',
				false,
				array(
					'class'    => 'mvweb-t-contacts__frame',
					'alt'      => $name,
					'loading'  => 'lazy',
					'decoding' => 'async',
				)
			)
			: '<img class="mvweb-t-contacts__frame" src="' . esc_url( $map['image'] ) . '" alt="' . esc_attr( $name ) . '" loading="lazy" decoding="async">';
	}

	return '<iframe class="mvweb-t-contacts__frame" src="' . esc_url( $map['src'] ) . '" title="' . esc_attr( $name ) . '" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>';
};

$mvweb_fact = static function ( array $fact, $kind ) use ( $mvweb_block, $mvweb_view, $mvweb_rv ) {
	$pieces = array(
		'icon'  => 'fact' === $kind ? '' : '<span class="mvweb-t-contacts__icon">' . mvweb_theme_icon( $fact['icon'] ) . '</span>',
		'label' => '<p class="mvweb-t-contacts__label">' . esc_html( $fact['label'] ) . '</p>',
		'value' => '' !== $fact['href']
			? '<a class="mvweb-t-contacts__value" href="' . esc_url( $fact['href'] ) . '">' . esc_html( $fact['value'] ) . '</a>'
			: '<p class="mvweb-t-contacts__value">' . esc_html( $fact['value'] ) . '</p>',
		'note'  => '' !== $fact['note'] ? '<p class="mvweb-t-contacts__note">' . esc_html( $fact['note'] ) . '</p>' : '',
	);

	$html = '';
	$body = '';
	$wrap = static function ( $inner ) use ( $kind ) {
		return '' === $inner || 'fact' === $kind ? $inner : '<div class="mvweb-t-contacts__' . $kind . '-body">' . $inner . '</div>';
	};

	foreach ( $mvweb_block['item_parts'] as $slug ) {
		if ( empty( $pieces[ $slug ] ) ) {
			continue;
		}

		if ( 'icon' === $slug ) {
			$html .= $wrap( $body ) . $pieces[ $slug ];
			$body  = '';
			continue;
		}

		$body .= $pieces[ $slug ];
	}

	$html .= $wrap( $body );

	if ( '' === $html ) {
		return '';
	}

	if ( 'tile' === $kind ) {
		return '<div class="mvweb-t-contacts__tile"' . $mvweb_rv() . '>' . $html . '</div>';
	}

	if ( 'row' === $kind ) {
		return '<li class="mvweb-t-contacts__row">' . $html . '</li>';
	}

	return '<div class="mvweb-t-contacts__fact"' . ( '4' === $mvweb_view ? $mvweb_rv() : '' ) . '>' . $html . '</div>';
};

$mvweb_giant = static function ( array $fact ) use ( $mvweb_block, $mvweb_rv ) {
	$html = '';

	foreach ( $mvweb_block['item_parts'] as $slug ) {
		if ( 'value' === $slug ) {
			$html .= '' !== $fact['href']
				? '<a class="mvweb-t-contacts__giant" href="' . esc_url( $fact['href'] ) . '"' . $mvweb_rv() . '>' . esc_html( $fact['value'] ) . '</a>'
				: '<span class="mvweb-t-contacts__giant"' . $mvweb_rv() . '>' . esc_html( $fact['value'] ) . '</span>';
		}

		if ( 'note' === $slug && '' !== $fact['note'] ) {
			$html .= '<p class="mvweb-t-contacts__status"' . $mvweb_rv() . '><span class="mvweb-t-contacts__dot" aria-hidden="true"></span><span>' . esc_html( $fact['note'] ) . '</span></p>';
		}
	}

	return $html;
};

$mvweb_chat = static function ( $id, array $chat, $kind ) {
	$icon = mvweb_theme_icon( mvweb_core_social_icon( $id ) );
	$url  = esc_url( $chat['url'] );
	$data = ' data-chat="' . esc_attr( sanitize_html_class( (string) $id ) ) . '"';

	if ( 'link' === $kind ) {
		return '<a class="mvweb-t-contacts__link" href="' . $url . '"' . $data . ' rel="noopener" target="_blank">' . $icon . '<span>' . esc_html( $chat['label'] ) . '</span>' . mvweb_theme_icon( 'arrow-up-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>';
	}

	$size = 'wide' === $kind ? '' : ' mvweb-t-contacts__chat--sm';

	return '<a class="mvweb-t-contacts__chat' . $size . '" href="' . $url . '"' . $data . ' rel="noopener" target="_blank">' . $icon . '<span>' . esc_html( $chat['label'] ) . '</span></a>';
};

$mvweb_chats_html = static function () use ( $mvweb_view, $mvweb_rv, $mvweb_text, $mvweb_chat ) {
	$chats = mvweb_cz_profile_chats();

	if ( empty( $chats ) ) {
		return '';
	}

	$class = array(
		'1' => 'wide',
		'4' => 'link',
	);
	$class = isset( $class[ $mvweb_view ] ) ? $class[ $mvweb_view ] : 'small';
	$list  = '';

	foreach ( $chats as $id => $chat ) {
		$list .= $mvweb_chat( $id, $chat, $class );
	}

	$title = $mvweb_text( 'chats_title' );
	$lead  = $mvweb_text( 'chats_lead' );

	if ( '1' === $mvweb_view ) {
		return '<div class="mvweb-t-contacts__chats"' . $mvweb_rv() . '>'
			. ( '' !== $title ? '<div class="mvweb-t-contacts__chats-title mvweb-t-h3">' . esc_html( $title ) . '</div>' : '' )
			. ( '' !== $lead ? '<p class="mvweb-t-contacts__chats-lead">' . esc_html( $lead ) . '</p>' : '' )
			. '<div class="mvweb-t-contacts__chat-list">' . $list . '</div></div>';
	}

	if ( '5' === $mvweb_view ) {
		return '<div class="mvweb-t-contacts__bar"' . $mvweb_rv() . '>'
			. ( '' !== $title ? '<p class="mvweb-t-contacts__bar-text">' . esc_html( $title ) . '</p>' : '' )
			. '<div class="mvweb-t-contacts__chat-row">' . $list . '</div></div>';
	}

	return $list;
};

$mvweb_map_html = static function ( array $data ) use ( $mvweb_view, $mvweb_rv, $mvweb_text, $mvweb_map_of, $mvweb_frame ) {
	$map    = $mvweb_map_of( $data );
	$live   = '' !== $map['src'] || '' !== $map['image'];
	$title  = $mvweb_text( 'map_title' );
	$note   = $mvweb_text( 'map_text' );
	$label  = $mvweb_text( 'map_button' );
	$name   = '' !== $title ? $title : __( 'Map', 'brand-market' );
	$pin    = '<span class="mvweb-t-contacts__map-pin">' . mvweb_theme_icon( 'map-pin' ) . '</span>';
	$button = '' !== $label && '' !== $map['link'] ? '<a class="mvweb-t-btn mvweb-t-btn--sm" href="' . esc_url( $map['link'] ) . '">' . esc_html( $label ) . '</a>' : '';
	$frame  = $live ? $mvweb_frame( $map, $name ) : '';
	$class  = 'mvweb-t-contacts__map' . ( $live ? ' mvweb-t-contacts__map--live' : '' );
	$text   = ( '' !== $title ? '<div class="mvweb-t-contacts__map-title mvweb-t-h3">' . esc_html( $title ) . '</div>' : '' )
		. ( '' !== $note ? '<p class="mvweb-t-contacts__map-text">' . esc_html( $note ) . '</p>' : '' )
		. $button;

	if ( '5' === $mvweb_view ) {
		return $live || '' !== $button ? '<div class="' . esc_attr( $class ) . '">' . $frame . ( $live ? '' : $pin ) . $button . '</div>' : '';
	}

	if ( '3' === $mvweb_view ) {
		if ( ! $live && '' === $text ) {
			return '';
		}

		return '<div class="' . esc_attr( $class ) . '"' . ( $live ? '' : ' aria-hidden="true"' ) . '>' . $frame . ( $live ? '' : '<span class="mvweb-t-contacts__marker">' . $pin . '</span>' ) . '</div>'
			. ( '' !== $text ? '<div class="mvweb-t-contacts__map-note"' . $mvweb_rv() . '>' . $text . '</div>' : '' );
	}

	if ( ! $live && '' === $text ) {
		return '';
	}

	return '<div class="' . esc_attr( $class ) . '"' . $mvweb_rv( '2' === $mvweb_view ? -1 : 0 ) . '>' . $frame
		. ( '' !== $text ? '<div class="mvweb-t-contacts__map-card">' . ( $live ? '' : $pin ) . $text . '</div>' : '' ) . '</div>';
};

$mvweb_fact_kind = array(
	'1' => 'tile',
	'2' => 'row',
	'3' => 'row',
);
$mvweb_fact_kind = isset( $mvweb_fact_kind[ $mvweb_view ] ) ? $mvweb_fact_kind[ $mvweb_view ] : 'fact';

$mvweb_head_piece = static function ( $slug ) use ( $mvweb_view, $mvweb_rv, $mvweb_text ) {
	$value = $mvweb_text( 'lead' === $slug ? 'text' : $slug );
	$rv    = '4' === $mvweb_view ? $mvweb_rv() : '';

	if ( '' === $value ) {
		return '';
	}

	if ( 'kicker' === $slug ) {
		return '4' === $mvweb_view
			? '<span class="mvweb-t-section-head__kicker"' . $rv . '>' . esc_html( $value ) . '</span>'
			: '<p class="mvweb-t-section-head__kicker">' . esc_html( $value ) . '</p>';
	}

	if ( 'title' === $slug ) {
		return '<div class="mvweb-t-section-head__title mvweb-t-h2"' . $rv . '>' . esc_html( $value ) . '</div>';
	}

	return '3' === $mvweb_view
		? '<p class="mvweb-t-contacts__float-lead">' . esc_html( $value ) . '</p>'
		: '<p class="mvweb-t-section-head__lead"' . $rv . '>' . esc_html( $value ) . '</p>';
};

$mvweb_piece = static function ( $slug, array $data ) use ( $mvweb_view, $mvweb_fact_kind, $mvweb_facts_of, $mvweb_fact, $mvweb_giant, $mvweb_chats_html, $mvweb_map_html, $mvweb_head_piece ) {
	if ( in_array( $slug, array( 'kicker', 'title', 'lead' ), true ) ) {
		return $mvweb_head_piece( $slug );
	}

	if ( 'chats' === $slug ) {
		return $mvweb_chats_html();
	}

	if ( 'map' === $slug ) {
		return $mvweb_map_html( $data );
	}

	$facts = $mvweb_facts_of( $data );
	$html  = '';

	foreach ( isset( $facts[ $slug ] ) ? $facts[ $slug ] : array() as $fact ) {
		$html .= '4' === $mvweb_view && 'phone' === $slug ? $mvweb_giant( $fact ) : $mvweb_fact( $fact, $mvweb_fact_kind );
	}

	return $html;
};

$mvweb_wrap = array(
	'head'    => static function ( $inner ) use ( $mvweb_view, $mvweb_rv ) {
		return '<div class="mvweb-t-section-head"' . $mvweb_rv( '2' === $mvweb_view ? -1 : 0 ) . '><div class="mvweb-t-section-head__text">' . $inner . '</div></div>';
	},
	'top'     => static function ( $inner ) {
		return '<div class="mvweb-t-contacts__top">' . $inner . '</div>';
	},
	'tiles'   => static function ( $inner ) {
		return '<div class="mvweb-t-contacts__tiles">' . $inner . '</div>';
	},
	'split'   => static function ( $inner ) {
		return '<div class="mvweb-t-contacts__split">' . $inner . '</div>';
	},
	'panel'   => static function ( $inner ) use ( $mvweb_rv ) {
		return '<div class="mvweb-t-contacts__panel"' . $mvweb_rv( 1 ) . '>' . $inner . '</div>';
	},
	'rows'    => static function ( $inner ) {
		return '<ul class="mvweb-t-contacts__rows">' . $inner . '</ul>';
	},
	'chatrow' => static function ( $inner ) {
		return '<div class="mvweb-t-contacts__chat-row">' . $inner . '</div>';
	},
	'stage'   => static function ( $inner ) use ( $mvweb_rv ) {
		return '<div class="mvweb-t-contacts__stage"' . $mvweb_rv() . '>' . $inner . '</div>';
	},
	'float'   => static function ( $inner ) use ( $mvweb_rv ) {
		return '<div class="mvweb-t-contacts__float"' . $mvweb_rv() . '>' . $inner . '</div>';
	},
	'hero'    => static function ( $inner ) {
		return '<div class="mvweb-t-contacts__hero">' . $inner . '</div>';
	},
	'facts'   => static function ( $inner ) {
		return '<div class="mvweb-t-contacts__facts">' . $inner . '</div>';
	},
	'links'   => static function ( $inner ) {
		return '<div class="mvweb-t-contacts__links">' . $inner . '</div>';
	},
	'tabs'    => static function ( $inner ) {
		return '<div class="mvweb-t-contacts__tabs">' . $inner . '</div>';
	},
	'info'    => static function ( $inner ) {
		return '<div class="mvweb-t-contacts__info">' . $inner . '</div>';
	},
);

$mvweb_fact_path = array(
	'1' => array( 'top', 'tiles' ),
	'2' => array( 'split', 'panel', 'rows' ),
	'3' => array( 'stage', 'float', 'rows' ),
	'4' => array( 'facts' ),
);
$mvweb_head_path = array(
	'1' => array( 'head' ),
	'2' => array( 'head' ),
	'3' => array( 'stage', 'float' ),
	'4' => array( 'hero' ),
	'5' => array( 'head' ),
);
$mvweb_chat_path = array(
	'1' => array( 'top' ),
	'2' => array( 'split', 'panel', 'chatrow' ),
	'3' => array( 'stage', 'float', 'chatrow' ),
	'4' => array( 'links' ),
	'5' => array( 'tabs' ),
);
$mvweb_map_path  = array(
	'1' => array(),
	'2' => array( 'split' ),
	'3' => array( 'stage' ),
);

$mvweb_panes_html = static function () use ( $mvweb_block, $mvweb_data, $mvweb_piece, $mvweb_nest, $mvweb_wrap, $mvweb_rv ) {
	$cities = mvweb_core_cities();
	$sets   = array();

	if ( empty( $cities ) ) {
		$sets[''] = array(
			'name' => (string) $mvweb_data['city'],
			'data' => $mvweb_data,
		);
	}

	foreach ( $cities as $key => $city ) {
		$sets[ $key ] = array(
			'name' => (string) $city['name'],
			'data' => mvweb_core_contacts( $key ),
		);
	}

	$current = mvweb_core_current_city();
	$uid     = wp_unique_id( 'contacts-tabs-' );
	$tabs    = '';
	$panes   = '';
	$number  = 0;

	foreach ( $sets as $key => $set ) {
		++$number;

		if ( count( $sets ) > 1 ) {
			$tabs .= '<input class="mvweb-t-contacts__tab-input" type="radio" name="' . esc_attr( $uid ) . '" id="' . esc_attr( $uid . '-' . $number ) . '"' . checked( $key === $current || ( '' === $current && 1 === $number ), true, false ) . '>'
				. '<label class="mvweb-t-contacts__tab" for="' . esc_attr( $uid . '-' . $number ) . '">' . esc_html( $set['name'] ) . '</label>';
		}

		$items = array();

		foreach ( $mvweb_block['parts'] as $slug ) {
			if ( ! in_array( $slug, array( 'phone', 'email', 'address', 'hours', 'map' ), true ) ) {
				continue;
			}

			$html = $mvweb_piece( $slug, $set['data'] );

			if ( '' !== $html ) {
				$items[] = array(
					'path' => 'map' === $slug ? array() : array( 'info' ),
					'html' => $html,
				);
			}
		}

		$inner = $mvweb_nest( $items, $mvweb_wrap );

		if ( '' !== $inner ) {
			$panes .= '<div class="mvweb-t-contacts__pane"' . ( '' !== $set['name'] ? ' role="group" aria-label="' . esc_attr( $set['name'] ) . '"' : '' ) . '>' . $inner . '</div>';
		}
	}

	if ( '' === $panes ) {
		return '';
	}

	return ( '' !== $tabs ? '<div class="mvweb-t-contacts__tablist" role="radiogroup" aria-label="' . esc_attr__( 'City', 'brand-market' ) . '"' . $mvweb_rv() . '>' . $tabs . '</div>' : '' )
		. '<div class="mvweb-t-contacts__panes"' . $mvweb_rv() . '>' . $panes . '</div>';
};

$mvweb_items  = array();
$mvweb_panned = false;

foreach ( $mvweb_block['parts'] as $mvweb_slug ) {
	$mvweb_is_fact = in_array( $mvweb_slug, array( 'phone', 'email', 'address', 'hours' ), true );

	if ( '5' === $mvweb_view && ( $mvweb_is_fact || 'map' === $mvweb_slug ) ) {
		if ( ! $mvweb_panned ) {
			$mvweb_panned = true;
			$mvweb_html   = $mvweb_panes_html();

			if ( '' !== $mvweb_html ) {
				$mvweb_items[] = array(
					'path' => array( 'tabs' ),
					'html' => $mvweb_html,
				);
			}
		}

		continue;
	}

	if ( '4' === $mvweb_view && 'map' === $mvweb_slug ) {
		continue;
	}

	if ( 'phone' === $mvweb_slug && '4' === $mvweb_view ) {
		$mvweb_path = array( 'hero' );
	} elseif ( $mvweb_is_fact ) {
		$mvweb_path = $mvweb_fact_path[ $mvweb_view ];
	} elseif ( 'chats' === $mvweb_slug ) {
		$mvweb_path = $mvweb_chat_path[ $mvweb_view ];
	} elseif ( 'map' === $mvweb_slug ) {
		$mvweb_path = $mvweb_map_path[ $mvweb_view ];
	} else {
		$mvweb_path = $mvweb_head_path[ $mvweb_view ];
	}

	$mvweb_html = $mvweb_piece( $mvweb_slug, $mvweb_data );

	if ( '' !== $mvweb_html ) {
		$mvweb_items[] = array(
			'path' => $mvweb_path,
			'html' => $mvweb_html,
		);
	}
}

if ( '2' === $mvweb_view ) {
	$mvweb_maps  = array();
	$mvweb_first = null;

	foreach ( $mvweb_items as $mvweb_at => $mvweb_item ) {
		if ( 'split' !== $mvweb_item['path'][0] ) {
			continue;
		}

		$mvweb_first = null === $mvweb_first ? $mvweb_at : $mvweb_first;

		if ( 1 === count( $mvweb_item['path'] ) ) {
			$mvweb_maps[] = $mvweb_item;
			unset( $mvweb_items[ $mvweb_at ] );
		}
	}

	array_splice( $mvweb_items, (int) $mvweb_first, 0, $mvweb_maps );
}

$mvweb_body = $mvweb_nest( $mvweb_items, $mvweb_wrap );

if ( '' === trim( $mvweb_body ) ) {
	return;
}

mvweb_theme_section_open( $mvweb_block );
echo $mvweb_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts.
mvweb_theme_section_close();
