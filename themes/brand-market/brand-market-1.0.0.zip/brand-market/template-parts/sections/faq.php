<?php
/**
 * Section template: questions and answers.
 *
 * Five views: the heading on the left, a classic list, two columns, tiles with
 * icons, a numbered list. Every question folds into a native details element.
 * The kicker, the heading, the lead and the button stand in one column in the
 * order the composition sets; the list of questions follows it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'faq', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_view  = $mvweb_block['mod'];
$mvweb_rv    = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_items = array();

if ( isset( $mvweb_props['items'] ) && is_array( $mvweb_props['items'] ) ) {
	foreach ( mvweb_core_visible_rows( $mvweb_props['items'] ) as $mvweb_row ) {
		$mvweb_question = isset( $mvweb_row['title'] ) ? trim( (string) $mvweb_row['title'] ) : '';
		$mvweb_answer   = isset( $mvweb_row['answer'] ) ? trim( (string) $mvweb_row['answer'] ) : '';

		if ( '' !== $mvweb_question && '' !== $mvweb_answer ) {
			$mvweb_items[] = array(
				'question' => $mvweb_question,
				'answer'   => $mvweb_answer,
				'icon'     => isset( $mvweb_row['icon'] ) ? (string) $mvweb_row['icon'] : '',
			);
		}
	}
}

if ( empty( $mvweb_items ) ) {
	return;
}

$mvweb_glyphs = array(
	'side'  => 'plus',
	'stack' => 'chevron-down',
	'cols'  => 'chevron-down',
	'tiles' => 'arrow-right',
	'num'   => 'plus',
);
$mvweb_glyph  = isset( $mvweb_glyphs[ $mvweb_view ] ) ? $mvweb_glyphs[ $mvweb_view ] : 'plus';
$mvweb_first  = ! isset( $mvweb_props['open_first'] ) || $mvweb_props['open_first'];
$mvweb_badge  = 'tiles' === $mvweb_view && in_array( 'badge', $mvweb_block['item_parts'], true );
$mvweb_extra  = 'num' === $mvweb_view && ! in_array( 'num', $mvweb_block['item_parts'], true ) ? 'mvweb-t-faq--plain' : '';
$mvweb_look   = $mvweb_block['look']['button_kind'];
$mvweb_btn    = 'mvweb-t-btn' . ( 'secondary' === $mvweb_look ? ' mvweb-t-btn--outline' : '' ) . ( 'link' === $mvweb_look ? ' mvweb-t-btn--link' : '' );

$mvweb_value = static function ( $key ) use ( $mvweb_props ) {
	return isset( $mvweb_props[ $key ] ) ? trim( (string) $mvweb_props[ $key ] ) : '';
};

$mvweb_bits = array(
	'kicker' => '' !== $mvweb_value( 'kicker' ) ? '<span class="mvweb-t-section-head__kicker">' . esc_html( $mvweb_value( 'kicker' ) ) . '</span>' : '',
	'title'  => '' !== $mvweb_value( 'title' ) ? '<div class="mvweb-t-section-head__title mvweb-t-h2">' . esc_html( $mvweb_value( 'title' ) ) . '</div>' : '',
	'lead'   => '' !== $mvweb_value( 'text' ) ? '<p class="mvweb-t-section-head__lead">' . esc_html( $mvweb_value( 'text' ) ) . '</p>' : '',
	'button' => '' !== $mvweb_value( 'button_text' ) && '' !== $mvweb_value( 'button_url' ) ? '<a class="' . esc_attr( $mvweb_btn ) . '" href="' . esc_url( $mvweb_value( 'button_url' ) ) . '">' . esc_html( $mvweb_value( 'button_text' ) ) . '</a>' : '',
);

$mvweb_intro = '';

foreach ( $mvweb_block['parts'] as $mvweb_slug ) {
	if ( isset( $mvweb_bits[ $mvweb_slug ] ) ) {
		$mvweb_intro .= $mvweb_bits[ $mvweb_slug ];
	}
}

mvweb_theme_section_open( $mvweb_block, true, $mvweb_extra );
?>
<div class="mvweb-t-faq__layout">
	<?php if ( '' !== $mvweb_intro ) : ?>
		<div class="mvweb-t-faq__intro"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
			<?php echo $mvweb_intro; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
		</div>
	<?php endif; ?>
	<div class="mvweb-t-faq__list">
		<?php foreach ( $mvweb_items as $mvweb_index => $mvweb_item ) : ?>
			<details class="mvweb-t-faq__item"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?><?php echo $mvweb_first && 0 === $mvweb_index ? ' open' : ''; ?>>
				<summary class="mvweb-t-faq__question">
					<?php if ( $mvweb_badge && '' !== $mvweb_item['icon'] ) : ?>
						<span class="mvweb-t-faq__badge"><?php echo mvweb_theme_icon( $mvweb_item['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
					<?php endif; ?>
					<span class="mvweb-t-faq__text"><?php echo esc_html( $mvweb_item['question'] ); ?></span>
					<span class="mvweb-t-faq__icon"><?php echo mvweb_theme_icon( $mvweb_glyph, array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
				</summary>
				<div class="mvweb-t-faq__answer"><?php echo wp_kses_post( wpautop( esc_html( $mvweb_item['answer'] ) ) ); ?></div>
			</details>
		<?php endforeach; ?>
	</div>
</div>
<?php
mvweb_theme_section_close();
