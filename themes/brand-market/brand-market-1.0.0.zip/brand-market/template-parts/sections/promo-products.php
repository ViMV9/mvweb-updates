<?php
/**
 * Section template: a promo banner and a row of products of one department.
 *
 * Five views: the banner beside the row, as a header over it, under the row
 * that overlaps it, as the first card of the row, and a compact strip. The
 * text of the banner comes in the order the composition sets; the pictures
 * stand where the view puts them. A part without data is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'promo-products', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_ids   = mvweb_theme_product_ids( $mvweb_props );

if ( empty( $mvweb_ids ) ) {
	return;
}

$mvweb_view   = $mvweb_block['mod'];
$mvweb_parts  = $mvweb_block['parts'];
$mvweb_look   = $mvweb_block['look'];
$mvweb_motion = '' !== $mvweb_block['motion'];
$mvweb_rv     = $mvweb_motion ? ' data-rv' : '';
$mvweb_prefix = 'mvweb-t-promo-products__';
$mvweb_has    = static function ( $slug ) use ( $mvweb_parts ) {
	return in_array( $slug, $mvweb_parts, true );
};
$mvweb_chips  = isset( $mvweb_props['chips'] ) && is_array( $mvweb_props['chips'] ) ? array_values(
	array_filter(
		mvweb_core_visible_rows( $mvweb_props['chips'] ),
		static function ( $row ) {
			return '' !== trim( (string) $row['text'] );
		}
	)
) : array();
$mvweb_kinds  = array(
	'secondary' => ' mvweb-t-btn--outline',
	'link'      => ' mvweb-t-btn--link',
);

$mvweb_extra = '';

if ( 'end' === $mvweb_look['image_side'] ) {
	$mvweb_extra .= ' mvweb-t-promo-products--flip';
}

if ( in_array( $mvweb_look['image_size'], array( 's', 'l' ), true ) ) {
	$mvweb_extra .= ' mvweb-t-promo-products--pic-' . $mvweb_look['image_size'];
}

$mvweb_button = static function () use ( $mvweb_props, $mvweb_look, $mvweb_kinds ) {
	if ( '' === (string) $mvweb_props['button_text'] || '' === (string) $mvweb_props['button_url'] ) {
		return '';
	}

	return '<a class="mvweb-t-btn mvweb-t-btn--sm' . esc_attr( isset( $mvweb_kinds[ $mvweb_look['button_kind'] ] ) ? $mvweb_kinds[ $mvweb_look['button_kind'] ] : '' ) . '" href="' . esc_url( $mvweb_props['button_url'] ) . '">' . esc_html( $mvweb_props['button_text'] ) . ' ' . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>';
};

$mvweb_text = array(
	'kicker' => static function () use ( $mvweb_props, $mvweb_prefix ) {
		if ( '' !== (string) $mvweb_props['kicker'] ) {
			echo '<span class="' . esc_attr( $mvweb_prefix . 'kicker' ) . '">' . esc_html( $mvweb_props['kicker'] ) . '</span>';
		}
	},
	'title'  => static function () use ( $mvweb_props, $mvweb_prefix ) {
		if ( '' !== (string) $mvweb_props['title'] ) {

			echo '<div class="' . esc_attr( $mvweb_prefix . 'title mvweb-t-h2' ) . '">' . esc_html( $mvweb_props['title'] ) . '</div>';
		}
	},
	'desc'   => static function () use ( $mvweb_props, $mvweb_prefix, $mvweb_view ) {
		if ( 'strip' !== $mvweb_view && '' !== (string) $mvweb_props['text'] ) {
			echo '<p class="' . esc_attr( $mvweb_prefix . 'desc' ) . '">' . esc_html( $mvweb_props['text'] ) . '</p>';
		}
	},
	'chips'  => static function () use ( $mvweb_chips, $mvweb_prefix, $mvweb_view ) {
		if ( empty( $mvweb_chips ) || in_array( $mvweb_view, array( 'lead', 'strip' ), true ) ) {
			return;
		}
		?>
		<ul class="<?php echo esc_attr( 'mvweb-t-chips mvweb-t-chips--scroll ' . $mvweb_prefix . 'chips' ); ?>">
			<?php foreach ( $mvweb_chips as $row ) : ?>
				<li>
					<?php if ( '' !== (string) $row['url'] ) : ?>
						<a class="mvweb-t-chip" href="<?php echo esc_url( $row['url'] ); ?>"><?php echo esc_html( $row['text'] ); ?></a>
					<?php else : ?>
						<span class="mvweb-t-chip"><?php echo esc_html( $row['text'] ); ?></span>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php
	},
	'button' => static function () use ( $mvweb_button, $mvweb_view ) {
		echo 'strip' === $mvweb_view ? '' : $mvweb_button(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The closure returns escaped markup.
	},
);

$mvweb_picture = static function ( $field ) use ( $mvweb_props ) {
	$id = isset( $mvweb_props[ $field ] ) ? absint( $mvweb_props[ $field ] ) : 0;

	return $id > 0 ? (string) wp_get_attachment_image(
		$id,
		'mvweb_card',
		false,
		array(
			'loading'  => 'lazy',
			'decoding' => 'async',
		)
	) : '';
};

$mvweb_pics = static function () use ( $mvweb_view, $mvweb_prefix, $mvweb_picture, $mvweb_has ) {
	if ( ! $mvweb_has( 'pics' ) ) {
		return;
	}

	$layouts = array(
		''        => array(
			'wrap'  => 'pics',
			'item'  => 'pic',
			'slots' => array(
				'front' => 'image',
				'back'  => 'image_2',
			),
		),
		'band'    => array(
			'wrap'  => 'gallery',
			'item'  => 'photo',
			'slots' => array(
				'a' => 'image_2',
				'b' => 'image',
				'c' => 'image_3',
			),
		),
		'overlap' => array(
			'wrap'  => 'gallery',
			'item'  => 'photo',
			'slots' => array(
				'a' => 'image_2',
				'b' => 'image',
			),
		),
		'lead'    => array(
			'wrap'  => 'gallery',
			'item'  => 'photo',
			'slots' => array(
				'a' => 'image_2',
				'b' => 'image',
			),
		),
		'strip'   => array(
			'wrap'  => 'gallery',
			'item'  => 'photo',
			'slots' => array(
				'b' => 'image',
			),
		),
	);
	$layout  = isset( $layouts[ $mvweb_view ] ) ? $layouts[ $mvweb_view ] : $layouts[''];
	$html    = '';

	foreach ( $layout['slots'] as $slot => $field ) {
		$picture = $mvweb_picture( $field );

		if ( '' !== $picture ) {
			$html .= '<div class="' . esc_attr( $mvweb_prefix . $layout['item'] . ' ' . $mvweb_prefix . $layout['item'] . '--' . $slot ) . '">' . $picture . '</div>';
		}
	}

	if ( '' !== $html ) {
		echo '<div class="' . esc_attr( $mvweb_prefix . $layout['wrap'] ) . '" aria-hidden="true">' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Images come from core, the rest is escaped above.
	}
};

$mvweb_banner = static function () use ( $mvweb_view, $mvweb_parts, $mvweb_text, $mvweb_pics, $mvweb_button, $mvweb_has, $mvweb_rv, $mvweb_prefix, $mvweb_chips ) {
	ob_start();

	if ( 'strip' === $mvweb_view ) {
		$mvweb_pics();

		echo '<div class="' . esc_attr( $mvweb_prefix . 'text' ) . '">';

		foreach ( $mvweb_parts as $slug ) {
			if ( in_array( $slug, array( 'kicker', 'title' ), true ) ) {
				$mvweb_text[ $slug ]();
			}
		}

		echo '</div>';

		if ( $mvweb_has( 'chips' ) && ! empty( $mvweb_chips ) ) {
			?>
			<div class="<?php echo esc_attr( $mvweb_prefix . 'ticker' ); ?>">
				<div class="<?php echo esc_attr( $mvweb_prefix . 'ticker-track' ); ?>">
					<?php foreach ( array( false, true ) as $copy ) : ?>
						<ul class="<?php echo esc_attr( 'mvweb-t-chips ' . $mvweb_prefix . 'chips' ); ?>"<?php echo $copy ? ' aria-hidden="true"' : ''; ?>>
							<?php foreach ( $mvweb_chips as $row ) : ?>
								<li>
									<?php if ( '' !== (string) $row['url'] ) : ?>
										<a class="mvweb-t-chip" href="<?php echo esc_url( $row['url'] ); ?>"<?php echo $copy ? ' tabindex="-1"' : ''; ?>><?php echo esc_html( $row['text'] ); ?></a>
									<?php else : ?>
										<span class="mvweb-t-chip"><?php echo esc_html( $row['text'] ); ?></span>
									<?php endif; ?>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endforeach; ?>
				</div>
			</div>
			<?php
		}

		echo $mvweb_has( 'button' ) ? $mvweb_button() : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The closure returns escaped markup.
	} else {
		ob_start();

		foreach ( $mvweb_parts as $slug ) {
			if ( isset( $mvweb_text[ $slug ] ) ) {
				$mvweb_text[ $slug ]();
			}
		}

		$text = trim( (string) ob_get_clean() );

		if ( '' !== $text ) {
			echo '<div class="' . esc_attr( $mvweb_prefix . 'text' ) . '">' . $text . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by the parts.
		}

		$mvweb_pics();
	}

	$inner = trim( (string) ob_get_clean() );

	if ( '' !== $inner ) {
		echo '<div class="' . esc_attr( $mvweb_prefix . 'banner' ) . '"' . $mvweb_rv . '>' . $inner . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts.
	}
};

$mvweb_card = static function ( $id ) use ( $mvweb_motion, $mvweb_props ) {
	get_template_part(
		'template-parts/catalog/card',
		null,
		array(
			'id'     => $id,
			'attrs'  => $mvweb_motion ? array( 'data-rv' => '' ) : array(),
			'button' => array(
				'text' => isset( $mvweb_props['card_button'] ) ? (string) $mvweb_props['card_button'] : '',
			),
		)
	);
};

$mvweb_arrows = '';

if ( $mvweb_has( 'arrows' ) && count( $mvweb_ids ) > 1 ) {
	$mvweb_arrows = mvweb_theme_showcase_arrows(
		array(
			'class'     => $mvweb_prefix . 'arrow',
			'hide_prev' => true,
			'small'     => true,
		)
	);
}

mvweb_theme_section_open( $mvweb_block, true, trim( $mvweb_extra ) );
?>
<div class="<?php echo esc_attr( $mvweb_prefix . 'grid' ); ?>" data-showcase>
	<?php
	if ( 'lead' !== $mvweb_view ) {
		$mvweb_banner();
	}

	if ( $mvweb_has( 'cards' ) ) :
		?>
		<div class="<?php echo esc_attr( $mvweb_prefix . 'shelf' ); ?>">
			<div class="mvweb-t-rail">
				<div class="mvweb-t-rail__track" data-showcase-track data-scroller="<?php esc_attr_e( 'Products', 'brand-market' ); ?>">
					<?php
					if ( 'lead' === $mvweb_view ) {
						$mvweb_banner();
					}

					foreach ( $mvweb_ids as $mvweb_id ) {
						$mvweb_card( $mvweb_id );
					}
					?>
				</div>
				<?php echo $mvweb_arrows; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and the icon helper. ?>
			</div>
		</div>
	<?php endif; ?>
</div>
<?php
mvweb_theme_section_close();
