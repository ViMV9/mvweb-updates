<?php
/**
 * Section template: first screen as a slider of offers.
 *
 * Five views: a fan of cards, a photo with a plate, a showcase with mini
 * cards, an item on a circle, a running ribbon. A slide prints its parts in
 * the order the composition sets; the text parts stand together where the
 * first of them stands. A part without data is not printed. The mini cards
 * are drawn here from the data of the catalogue.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block  = mvweb_theme_block( 'hero-slider', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props  = $mvweb_block['props'];
$mvweb_slides = isset( $mvweb_props['slides'] ) && is_array( $mvweb_props['slides'] ) ? mvweb_core_visible_rows( $mvweb_props['slides'] ) : array();

if ( empty( $mvweb_slides ) ) {
	return;
}

$mvweb_view      = $mvweb_block['mod'];
$mvweb_total     = count( $mvweb_slides );
$mvweb_motion    = '' !== $mvweb_block['motion'];
$mvweb_order     = $mvweb_block['item_parts'];
$mvweb_interval  = isset( $mvweb_props['slide_interval'] ) && absint( $mvweb_props['slide_interval'] ) > 0 ? absint( $mvweb_props['slide_interval'] ) : 6;
$mvweb_manual    = ! in_array( 'pause', $mvweb_block['parts'], true );
$mvweb_other_tag = '' === $mvweb_view ? 'p' : 'div';
$mvweb_slide_cls = '' === $mvweb_view ? 'slide' : 'pane';
$mvweb_tag_cls   = '' === $mvweb_view ? 'kicker' : 'tag';
$mvweb_text_keys = array( 'kicker', 'title', 'lead', 'facts', 'actions' );

$mvweb_val = static function ( $row, $key ) {
	return isset( $row[ $key ] ) && is_scalar( $row[ $key ] ) ? trim( (string) $row[ $key ] ) : '';
};

$mvweb_image = static function ( $id, $size, $eager ) {
	$id = absint( $id );

	return wp_attachment_is_image( $id ) ? (string) wp_get_attachment_image( $id, $size, false, array( 'loading' => $eager ? 'eager' : 'lazy' ) ) : '';
};

$mvweb_mini = static function ( $id, $prefix, $hidden ) {
	$image = mvweb_core_item_image( $id, 'medium', array( 'alt' => '' ) );
	$price = mvweb_core_item_price_html( $id );
	$base  = 'mvweb-t-hero-slider__' . $prefix;
	$html  = '<a class="' . $base . '" href="' . esc_url( get_permalink( $id ) ) . '"' . ( $hidden ? ' aria-hidden="true" tabindex="-1"' : '' ) . '>';
	$html .= '' !== $image ? '<span class="' . $base . '-pic">' . $image . '</span>' : '';
	$html .= '<span class="' . $base . '-name">' . esc_html( get_the_title( $id ) ) . '</span>';
	$html .= '' !== $price ? '<span class="' . $base . '-price">' . wp_kses_post( $price ) . '</span>' : '';

	return $html . '</a>';
};

$mvweb_item_ids = static function ( $slide, $limit ) {
	$ids  = array();
	$rows = isset( $slide['products'] ) && is_array( $slide['products'] ) ? mvweb_core_visible_rows( $slide['products'] ) : array();

	foreach ( $rows as $row ) {
		$id = isset( $row['item'] ) ? absint( $row['item'] ) : 0;

		if ( $id > 0 && mvweb_core_item_visible( $id ) ) {
			$ids[] = $id;
		}

		if ( count( $ids ) >= $limit ) {
			break;
		}
	}

	return $ids;
};

$mvweb_text = array(
	'kicker'  => static function ( $slide ) use ( $mvweb_val, $mvweb_tag_cls ) {
		$kicker = $mvweb_val( $slide, 'kicker' );

		return '' !== $kicker ? '<span class="mvweb-t-hero-slider__' . $mvweb_tag_cls . '">' . esc_html( $kicker ) . '</span>' : '';
	},
	'title'   => static function ( $slide, $index ) use ( $mvweb_val, $mvweb_other_tag ) {
		$title = $mvweb_val( $slide, 'title' );
		$word  = $mvweb_val( $slide, 'accent_word' );
		$pos   = '' !== $word ? strpos( $title, $word ) : false;

		if ( '' === $title ) {
			return '';
		}

		$tag  = 0 === $index ? mvweb_theme_h1_tag() : $mvweb_other_tag;
		$html = false === $pos
			? esc_html( $title )
			: esc_html( substr( $title, 0, $pos ) ) . '<span class="mvweb-t-hero-slider__mark">' . esc_html( $word ) . '</span>' . esc_html( substr( $title, $pos + strlen( $word ) ) );

		return '<' . $tag . ' class="mvweb-t-hero-slider__title">' . $html . '</' . $tag . '>';
	},
	'lead'    => static function ( $slide ) use ( $mvweb_val ) {
		$lead = $mvweb_val( $slide, 'text' );

		return '' !== $lead ? '<p class="mvweb-t-hero-slider__lead">' . esc_html( $lead ) . '</p>' : '';
	},
	'facts'   => static function ( $slide ) use ( $mvweb_val, $mvweb_view ) {
		$lines = in_array( $mvweb_view, array( 'plate', 'ribbon' ), true ) ? array() : array_slice( mvweb_core_text_lines( $mvweb_val( $slide, 'facts' ) ), 0, 4 );
		$html  = '';

		foreach ( $lines as $line ) {
			$html .= '<li class="mvweb-t-hero-slider__fact">' . esc_html( $line ) . '</li>';
		}

		return '' !== $html ? '<ul class="mvweb-t-hero-slider__facts">' . $html . '</ul>' : '';
	},
	'actions' => static function ( $slide ) use ( $mvweb_val, $mvweb_view ) {
		$text   = $mvweb_val( $slide, 'button_text' );
		$url    = $mvweb_val( $slide, 'button_url' );
		$price  = $mvweb_val( $slide, 'price' );
		$label  = $mvweb_val( $slide, 'price_label' );
		$button = '' !== $text && '' !== $url ? '<a class="mvweb-t-btn" href="' . esc_url( $url ) . '">' . esc_html( $text ) . ' ' . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>' : '';
		$cost   = '' !== $price && 'circle' !== $mvweb_view ? '<p class="mvweb-t-hero-slider__price">' . ( '' !== $label ? '<span class="mvweb-t-hero-slider__price-from">' . esc_html( $label ) . '</span>' : '' ) . esc_html( $price ) . '</p>' : '';

		return '' !== $button . $cost ? '<div class="mvweb-t-hero-slider__actions">' . $button . $cost . '</div>' : '';
	},
);

$mvweb_pics = static function ( $slide, $index, $rv ) use ( $mvweb_view, $mvweb_val, $mvweb_image ) {
	$first = 0 === $index;

	if ( 'plate' === $mvweb_view ) {
		$photo = $mvweb_image( $mvweb_val( $slide, 'photo' ), 'mvweb_wide', $first );

		return '' !== $photo ? '<div class="mvweb-t-hero-slider__photo"' . $rv . '>' . $photo . '</div>' : '';
	}

	if ( 'showcase' === $mvweb_view ) {
		$main = $mvweb_image( $mvweb_val( $slide, 'image_2' ), 'large', $first );

		return '' !== $main ? '<div class="mvweb-t-hero-slider__main"' . $rv . '>' . $main . '</div>' : '';
	}

	if ( 'circle' === $mvweb_view ) {
		$item  = $mvweb_image( $mvweb_val( $slide, 'image_2' ), 'large', $first );
		$aside = $mvweb_image( $mvweb_val( $slide, 'image_3' ), 'large', $first );
		$price = $mvweb_val( $slide, 'price' );
		$label = $mvweb_val( $slide, 'price_label' );

		if ( '' === $item . $aside ) {
			return '';
		}

		$html  = '<div class="mvweb-t-hero-slider__disc"' . $rv . '>';
		$html .= '<span class="mvweb-t-hero-slider__circle"></span><span class="mvweb-t-hero-slider__ring"></span>';
		$html .= '' !== $item ? '<div class="mvweb-t-hero-slider__item">' . $item . '</div>' : '';
		$html .= '' !== $aside ? '<div class="mvweb-t-hero-slider__item mvweb-t-hero-slider__item--aside">' . $aside . '</div>' : '';
		$html .= '' !== $price ? '<div class="mvweb-t-hero-slider__badge">' . ( '' !== $label ? '<span class="mvweb-t-hero-slider__price-from">' . esc_html( $label ) . '</span>' : '' ) . esc_html( $price ) . '</div>' : '';

		return $html . '</div>';
	}

	if ( 'ribbon' === $mvweb_view ) {
		return '';
	}

	$html = '';

	foreach ( array(
		'left'  => 'image_1',
		'mid'   => 'image_2',
		'right' => 'image_3',
	) as $side => $key ) {
		$picture = $mvweb_image( $mvweb_val( $slide, $key ), 'large', $first );
		$html   .= '' !== $picture ? '<div class="mvweb-t-hero-slider__pic mvweb-t-hero-slider__pic--' . $side . '">' . $picture . '</div>' : '';
	}

	return '' !== $html ? '<div class="mvweb-t-hero-slider__fan">' . $html . '</div>' : '';
};

$mvweb_products = static function ( $slide, $rv ) use ( $mvweb_view, $mvweb_item_ids, $mvweb_mini ) {
	if ( 'showcase' === $mvweb_view ) {
		$html = '';

		foreach ( $mvweb_item_ids( $slide, 3 ) as $id ) {
			$html .= $mvweb_mini( $id, 'thumb', false );
		}

		return '' !== $html ? '<div class="mvweb-t-hero-slider__thumbs mvweb-t-hero-slider__seq"' . $rv . '>' . $html . '</div>' : '';
	}

	if ( 'ribbon' === $mvweb_view ) {
		$cards = '';
		$copy  = '';

		foreach ( $mvweb_item_ids( $slide, 6 ) as $id ) {
			$cards .= $mvweb_mini( $id, 'card', false );
			$copy  .= $mvweb_mini( $id, 'card', true );
		}

		if ( '' === $cards ) {
			return '';
		}

		return '<div class="mvweb-t-hero-slider__ribbon"' . $rv . '><div class="mvweb-t-hero-slider__track"><div class="mvweb-t-hero-slider__set mvweb-t-hero-slider__seq">' . $cards . '</div><div class="mvweb-t-hero-slider__set mvweb-t-hero-slider__set--copy mvweb-t-hero-slider__seq" aria-hidden="true">' . $copy . '</div></div></div>';
	}

	return '';
};

$mvweb_slide = static function ( $slide, $index ) use ( $mvweb_view, $mvweb_motion, $mvweb_order, $mvweb_total, $mvweb_slide_cls, $mvweb_text, $mvweb_text_keys, $mvweb_pics, $mvweb_products ) {
	$first = 0 === $index;
	$rv    = $first && $mvweb_motion && '' !== $mvweb_view ? ' data-rv' : '';
	$texts = array();
	$html  = '';
	$done  = false;

	foreach ( $mvweb_order as $slug ) {
		if ( isset( $mvweb_text[ $slug ] ) ) {
			$part = call_user_func( $mvweb_text[ $slug ], $slide, $index );

			if ( '' !== $part ) {
				$texts[ $slug ] = $part;
			}
		}
	}

	if ( 'plate' === $mvweb_view && in_array( 'pics', $mvweb_order, true ) ) {
		$html .= $mvweb_pics( $slide, $index, $rv );
	}

	foreach ( $mvweb_order as $slug ) {
		if ( in_array( $slug, $mvweb_text_keys, true ) ) {
			if ( $done || empty( $texts ) ) {
				continue;
			}

			$done = true;

			if ( 'ribbon' === $mvweb_view ) {
				$main  = implode( '', array_intersect_key( $texts, array_flip( array( 'kicker', 'title' ) ) ) );
				$side  = implode( '', array_intersect_key( $texts, array_flip( array( 'lead', 'actions' ) ) ) );
				$head  = '' !== $main ? '<div class="mvweb-t-hero-slider__head-main mvweb-t-hero-slider__seq">' . $main . '</div>' : '';
				$head .= '' !== $side ? '<div class="mvweb-t-hero-slider__head-side mvweb-t-hero-slider__seq">' . $side . '</div>' : '';
				$html .= '' !== $head ? '<div class="mvweb-t-hero-slider__head"' . $rv . '>' . $head . '</div>' : '';
			} elseif ( 'plate' === $mvweb_view ) {
				$html .= '<div class="mvweb-t-hero-slider__plate mvweb-t-hero-slider__seq"' . $rv . '>' . implode( '', $texts ) . '</div>';
			} elseif ( '' === $mvweb_view ) {
				$html .= '<div class="mvweb-t-hero-slider__text">' . implode( '', $texts ) . '</div>';
			} else {
				$html .= '<div class="mvweb-t-hero-slider__text mvweb-t-hero-slider__seq"' . $rv . '>' . implode( '', $texts ) . '</div>';
			}
		} elseif ( 'pics' === $slug && 'plate' !== $mvweb_view ) {
			$html .= $mvweb_pics( $slide, $index, $rv );
		} elseif ( 'products' === $slug ) {
			$html .= $mvweb_products( $slide, $rv );
		}
	}

	$label = sprintf(
		/* translators: 1: number of the slide, 2: number of slides. */
		__( '%1$d of %2$d', 'brand-market' ),
		$index + 1,
		$mvweb_total
	);

	return '<article class="mvweb-t-hero-slider__' . $mvweb_slide_cls . '" data-hero-slider-slide' . ( $first ? ' data-active' : '' ) . ' role="group" aria-roledescription="' . esc_attr__( 'slide', 'brand-market' ) . '" aria-label="' . esc_attr( $label ) . '">' . $html . '</article>';
};

$mvweb_controls = array(
	'arrows' => static function () {
		?>
		<button class="mvweb-t-round" type="button" data-hero-slider-prev title="<?php esc_attr_e( 'Previous slide', 'brand-market' ); ?>"><?php echo mvweb_theme_icon( 'chevron-left', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?><span class="screen-reader-text"><?php esc_html_e( 'Previous slide', 'brand-market' ); ?></span></button>
		<button class="mvweb-t-round" type="button" data-hero-slider-next title="<?php esc_attr_e( 'Next slide', 'brand-market' ); ?>"><?php echo mvweb_theme_icon( 'chevron-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?><span class="screen-reader-text"><?php esc_html_e( 'Next slide', 'brand-market' ); ?></span></button>
		<?php
	},
	'dots'   => static function () use ( $mvweb_total ) {
		?>
		<div class="mvweb-t-hero-slider__dots">
			<?php for ( $mvweb_n = 1; $mvweb_n <= $mvweb_total; $mvweb_n++ ) : ?>
				<?php $mvweb_dot = sprintf( /* translators: %d: number of the slide. */ __( 'Slide %d', 'brand-market' ), $mvweb_n ); ?>
				<button class="mvweb-t-hero-slider__dot" type="button" data-hero-slider-dot title="<?php echo esc_attr( $mvweb_dot ); ?>"<?php echo 1 === $mvweb_n ? ' data-active' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?> aria-current="<?php echo 1 === $mvweb_n ? 'true' : 'false'; ?>"><span class="mvweb-t-hero-slider__bar"></span><span class="screen-reader-text"><?php echo esc_html( $mvweb_dot ); ?></span></button>
			<?php endfor; ?>
		</div>
		<?php
	},
	'pause'  => static function () {
		?>
		<button class="mvweb-t-round mvweb-t-hero-slider__pause" type="button" data-hero-slider-pause aria-pressed="false" title="<?php esc_attr_e( 'Pause the slides', 'brand-market' ); ?>"><?php echo mvweb_theme_icon( 'player-pause', array( 'class' => 'mvweb-t-icon--sm mvweb-t-hero-slider__icon-pause' ) ), mvweb_theme_icon( 'player-play', array( 'class' => 'mvweb-t-icon--sm mvweb-t-hero-slider__icon-play' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?><span class="screen-reader-text"><?php esc_html_e( 'Pause the slides', 'brand-market' ); ?></span></button>
		<?php
	},
);

$mvweb_has_controls = $mvweb_total > 1 && (bool) array_intersect( array( 'arrows', 'dots', 'pause' ), $mvweb_block['parts'] );

mvweb_theme_section_open( $mvweb_block );
?>
<div class="mvweb-t-hero-slider__box"<?php echo $mvweb_motion && '' === $mvweb_view ? ' data-rv' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?> data-hero-slider<?php echo $mvweb_manual ? ' data-manual' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?> data-interval="<?php echo esc_attr( $mvweb_interval ); ?>" role="region" aria-roledescription="<?php esc_attr_e( 'carousel', 'brand-market' ); ?>" aria-label="<?php esc_attr_e( 'Special offers', 'brand-market' ); ?>">
	<div class="mvweb-t-hero-slider__slides">
		<?php foreach ( $mvweb_slides as $mvweb_index => $mvweb_row ) : ?>
			<?php echo $mvweb_slide( $mvweb_row, $mvweb_index ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
		<?php endforeach; ?>
	</div>
	<?php if ( $mvweb_has_controls ) : ?>
		<div class="<?php echo '' === $mvweb_view ? 'mvweb-t-hero-slider__nav' : 'mvweb-t-hero-slider__controls'; ?>"<?php echo $mvweb_motion && '' !== $mvweb_view ? ' data-rv' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
			<?php mvweb_theme_render_parts( $mvweb_block, $mvweb_controls ); ?>
		</div>
	<?php endif; ?>
</div>
<?php
mvweb_theme_section_close();
