<?php
/**
 * Section template: how the work is done, step by step.
 *
 * Five views of one list: cards with a photo, cards with numbers, a timeline,
 * stairs, large numbers in rows. The head and the steps come in the order the
 * composition sets; a step prints its photo, number, heading and text the same
 * way, and a part without data is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'steps', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_items = isset( $mvweb_props['items'] ) && is_array( $mvweb_props['items'] ) ? mvweb_core_visible_rows( $mvweb_props['items'] ) : array();

if ( empty( $mvweb_items ) ) {
	return;
}

$mvweb_view = $mvweb_block['mod'];
$mvweb_rv   = '' !== $mvweb_block['motion'] ? ' data-rv' : '';

$mvweb_render_item = static function ( $item, $number, $block ) use ( $mvweb_rv ) {
	$view   = $block['mod'];
	$title  = isset( $item['title'] ) ? trim( (string) $item['title'] ) : '';
	$text   = isset( $item['text'] ) ? trim( (string) $item['text'] ) : '';
	$image  = 'media' === $view && ! empty( $item['image'] ) && in_array( 'image', $block['item_parts'], true ) ? wp_get_attachment_image( (int) $item['image'], 'medium_large' ) : '';
	$number = '<span class="mvweb-t-steps__num" aria-hidden="true">' . (int) $number . '</span>';
	$has    = in_array( 'num', $block['item_parts'], true );
	$html   = '';

	foreach ( $block['item_parts'] as $slug ) {
		if ( 'image' === $slug ) {
			if ( '' !== $image ) {
				$html .= '<div class="mvweb-t-steps__media">' . $image . ( $has ? $number : '' ) . '</div>';
			}
		} elseif ( 'num' === $slug ) {
			if ( 'numbers' !== $view && '' === $image ) {
				$html .= $number;
			}
		} elseif ( 'title' === $slug && '' !== $title ) {
			$html .= '<div class="mvweb-t-steps__title mvweb-t-h3">' . esc_html( $title ) . '</div>';
		} elseif ( 'text' === $slug && '' !== $text ) {
			$html .= '<p class="mvweb-t-steps__text">' . esc_html( $text ) . '</p>';
		}
	}

	$class = 'mvweb-t-steps__item';

	if ( 'numbers' === $view && ! $has ) {
		$class .= ' mvweb-t-steps__item--plain';
	}

	echo '<li class="' . esc_attr( $class ) . '"' . $mvweb_rv . '>' . $html . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values and attachment markup.
};

$mvweb_print_list = static function ( $block ) use ( $mvweb_items, $mvweb_render_item ) {
	echo '<ol class="mvweb-t-steps__list">';

	foreach ( $mvweb_items as $mvweb_index => $mvweb_item ) {
		$mvweb_render_item( $mvweb_item, $mvweb_index + 1, $block );
	}

	echo '</ol>';
};

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts( $mvweb_block, array( 'list' => $mvweb_print_list ), array( 'rv' => true ) );
mvweb_theme_section_close();
