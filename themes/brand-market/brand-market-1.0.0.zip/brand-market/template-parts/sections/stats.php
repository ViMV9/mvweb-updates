<?php
/**
 * Section template: figures the company stands on.
 *
 * Five views: a row with dividers, an accent panel, cards with an icon, a
 * heading beside a list, rings. The head and the figures come in the order
 * the composition sets; a figure prints its icon, number and caption the same
 * way, and a part without data is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'stats', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_items = isset( $mvweb_block['props']['items'] ) && is_array( $mvweb_block['props']['items'] ) ? mvweb_core_visible_rows( $mvweb_block['props']['items'] ) : array();

if ( empty( $mvweb_items ) ) {
	return;
}

$mvweb_view   = $mvweb_block['mod'];
$mvweb_motion = '' !== $mvweb_block['motion'];
$mvweb_rv     = $mvweb_motion ? ' data-rv' : '';
$mvweb_tags   = array(
	'line'   => array( 'row', 'item' ),
	'accent' => array( 'row', 'item' ),
	'cards'  => array( 'grid', 'card' ),
	'split'  => array( 'list', 'line' ),
	'rings'  => array( 'grid', 'dial' ),
);
$mvweb_tag    = isset( $mvweb_tags[ $mvweb_view ] ) ? $mvweb_tags[ $mvweb_view ] : $mvweb_tags['line'];

$mvweb_item_parts = array(
	'icon'   => static function ( $item, $block ) {
		if ( 'cards' === $block['mod'] && ! empty( $item['icon'] ) ) {
			echo '<span class="mvweb-t-stats__icon">' . mvweb_theme_icon( $item['icon'] ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
		}
	},
	'number' => static function ( $item, $block ) {
		if ( '' === (string) $item['number'] ) {
			return;
		}

		$number = '<span class="mvweb-t-stats__number">' . esc_html( $item['number'] ) . '</span>';

		echo 'rings' === $block['mod'] ? '<span class="mvweb-t-stats__ring">' . $number . '</span>' : $number; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	},
	'label'  => static function ( $item ) {
		if ( '' !== (string) $item['label'] ) {
			echo '<span class="mvweb-t-stats__label">' . esc_html( $item['label'] ) . '</span>';
		}
	},
);

$mvweb_parts = array(
	'list' => static function ( $block ) use ( $mvweb_items, $mvweb_tag, $mvweb_item_parts, $mvweb_rv ) {
		?>
		<ul class="<?php echo esc_attr( 'mvweb-t-stats__' . $mvweb_tag[0] ); ?>">
			<?php foreach ( $mvweb_items as $mvweb_item ) : ?>
				<li class="<?php echo esc_attr( 'mvweb-t-stats__' . $mvweb_tag[1] ); ?>"<?php echo 'accent' === $block['mod'] ? '' : $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
					<?php mvweb_theme_render_item_parts( $block, $mvweb_item, $mvweb_item_parts ); ?>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php
	},
);

mvweb_theme_section_open( $mvweb_block );
?>
<?php if ( 'accent' === $mvweb_view ) : ?>
	<div class="mvweb-t-stats__panel"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
<?php endif; ?>
	<?php mvweb_theme_render_parts( $mvweb_block, $mvweb_parts, array( 'rv' => 'accent' !== $mvweb_view ) ); ?>
<?php if ( 'accent' === $mvweb_view ) : ?>
	</div>
<?php endif; ?>
<?php
mvweb_theme_section_close();
