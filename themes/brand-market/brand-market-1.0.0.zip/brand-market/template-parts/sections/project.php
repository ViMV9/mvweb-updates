<?php
/**
 * Section template: one work, wide.
 *
 * Five views of one project: a gallery beside a card, a photo beside a table,
 * a cover with plates, a ribbon of steps, large figures. The parts (pictures,
 * line, heading, description, facts, prices, link) come in the order the
 * composition sets inside the container the view gives them; the pictures keep
 * the place the view gives them. A part with no data is not printed, and
 * neither is a container left with nothing in it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block  = mvweb_theme_block( 'project', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props  = $mvweb_block['props'];
$mvweb_mod    = $mvweb_block['mod'];
$mvweb_shown  = $mvweb_block['parts'];
$mvweb_motion = '' !== $mvweb_block['motion'];
$mvweb_name   = isset( $mvweb_props['title'] ) ? (string) $mvweb_props['title'] : '';

$mvweb_text = static function ( $key ) use ( $mvweb_props ) {
	return isset( $mvweb_props[ $key ] ) ? trim( (string) $mvweb_props[ $key ] ) : '';
};

$mvweb_rows = static function ( $key, array $needs ) use ( $mvweb_props ) {
	$rows = array();

	if ( isset( $mvweb_props[ $key ] ) && is_array( $mvweb_props[ $key ] ) ) {
		foreach ( mvweb_core_visible_rows( $mvweb_props[ $key ] ) as $row ) {
			$clean = array();

			foreach ( $needs as $field ) {
				$clean[ $field ] = isset( $row[ $field ] ) ? trim( (string) $row[ $field ] ) : '';
			}

			if ( '' !== implode( '', array_diff_key( $clean, array( 'unit' => 1 ) ) ) ) {
				$rows[] = $clean;
			}
		}
	}

	return $rows;
};

$mvweb_photos = array();

if ( isset( $mvweb_props['photos'] ) && is_array( $mvweb_props['photos'] ) ) {
	foreach ( mvweb_core_visible_rows( $mvweb_props['photos'] ) as $mvweb_row ) {
		$mvweb_id = isset( $mvweb_row['image'] ) ? absint( $mvweb_row['image'] ) : 0;

		if ( wp_attachment_is_image( $mvweb_id ) ) {
			$mvweb_photos[] = array(
				'id'    => $mvweb_id,
				'title' => isset( $mvweb_row['title'] ) ? trim( (string) $mvweb_row['title'] ) : '',
			);
		}
	}
}

$mvweb_facts  = $mvweb_rows( 'facts', array( 'value', 'unit', 'label' ) );
$mvweb_prices = $mvweb_rows( 'prices', array( 'label', 'value' ) );
$mvweb_more   = max( 0, count( $mvweb_photos ) - 4 );

$mvweb_rv = static function ( $on ) use ( $mvweb_motion ) {
	return $on && $mvweb_motion ? ' data-rv' : '';
};

$mvweb_fact_value = static function ( $fact ) {
	return trim( $fact['value'] . ( '' !== $fact['unit'] ? ' ' . $fact['unit'] : '' ) );
};

$mvweb_shot = static function ( $photo, $css, $image_class = '', $badge = '', $rv = false ) use ( $mvweb_name, $mvweb_rv ) {
	$alt = trim( (string) get_post_meta( $photo['id'], '_wp_attachment_image_alt', true ) );
	$alt = '' !== $alt ? $alt : ( '' !== $photo['title'] ? $photo['title'] : $mvweb_name );
	$att = array( 'alt' => $alt );

	if ( '' !== $image_class ) {
		$att['class'] = $image_class;
	}

	return '<a class="' . esc_attr( $css ) . '" href="' . esc_url( (string) wp_get_attachment_url( $photo['id'] ) ) . '"' . $mvweb_rv( $rv ) . '>'
		. wp_get_attachment_image( $photo['id'], 'large', false, $att )
		. $badge
		. '</a>';
};

$mvweb_thumbs = static function () use ( $mvweb_photos, $mvweb_shot, $mvweb_more ) {
	$html = '';

	foreach ( array_slice( $mvweb_photos, 1, 3 ) as $index => $photo ) {
		$badge = 2 === $index && $mvweb_more > 0 ? '<span class="mvweb-t-project__more">' . esc_html( '+' . $mvweb_more ) . '</span>' : '';
		$html .= $mvweb_shot( $photo, 'mvweb-t-project__thumb', '', $badge );
	}

	return $html;
};

$mvweb_part = array(
	'eyebrow' => static function ( $rv ) use ( $mvweb_text, $mvweb_rv ) {
		$line = $mvweb_text( 'kicker' );

		return '' !== $line ? '<span class="mvweb-t-project__kicker"' . $mvweb_rv( $rv ) . '>' . esc_html( $line ) . '</span>' : '';
	},
	'name'    => static function ( $rv ) use ( $mvweb_text, $mvweb_rv ) {
		$head = $mvweb_text( 'title' );

		return '' !== $head ? '<div class="mvweb-t-project__title mvweb-t-h2"' . $mvweb_rv( $rv ) . '>' . esc_html( $head ) . '</div>' : '';
	},
	'text'    => static function ( $rv ) use ( $mvweb_text, $mvweb_rv ) {
		$body = $mvweb_text( 'text' );

		return '' !== $body ? '<p class="mvweb-t-project__text"' . $mvweb_rv( $rv ) . '>' . esc_html( $body ) . '</p>' : '';
	},
	'facts'   => static function ( $rv ) use ( $mvweb_facts, $mvweb_fact_value, $mvweb_rv, $mvweb_mod ) {
		$html = '';

		foreach ( $mvweb_facts as $fact ) {
			if ( 'table' === $mvweb_mod ) {
				$html .= '<div class="mvweb-t-project__spec"><dt class="mvweb-t-project__spec-label">' . esc_html( $fact['label'] ) . '</dt><dd class="mvweb-t-project__spec-value">' . esc_html( $mvweb_fact_value( $fact ) ) . '</dd></div>';
			} elseif ( 'numbers' === $mvweb_mod ) {
				$unit  = '' !== $fact['unit'] ? '<span class="mvweb-t-project__unit"> ' . esc_html( $fact['unit'] ) . '</span>' : '';
				$html .= '<li class="mvweb-t-project__tile"' . $mvweb_rv( true ) . '><span class="mvweb-t-project__big">' . esc_html( $fact['value'] ) . $unit . '</span><span class="mvweb-t-project__fact-label">' . esc_html( $fact['label'] ) . '</span></li>';
			} else {
				$html .= '<li class="mvweb-t-project__fact"><span class="mvweb-t-project__fact-value">' . esc_html( $mvweb_fact_value( $fact ) ) . '</span><span class="mvweb-t-project__fact-label">' . esc_html( $fact['label'] ) . '</span></li>';
			}
		}

		if ( '' === $html || 'table' === $mvweb_mod ) {
			return $html;
		}

		return 'numbers' === $mvweb_mod
			? '<ul class="mvweb-t-project__tiles">' . $html . '</ul>'
			: '<ul class="mvweb-t-project__facts"' . $mvweb_rv( $rv ) . '>' . $html . '</ul>';
	},
	'prices'  => static function ( $rv ) use ( $mvweb_prices, $mvweb_rv, $mvweb_mod ) {
		$html = '';

		foreach ( $mvweb_prices as $price ) {
			if ( 'table' === $mvweb_mod ) {
				$html .= '<div class="mvweb-t-project__spec mvweb-t-project__spec--price"><dt class="mvweb-t-project__spec-label">' . esc_html( $price['label'] ) . '</dt><dd class="mvweb-t-project__spec-value">' . esc_html( $price['value'] ) . '</dd></div>';
			} else {
				$html .= '<div class="mvweb-t-project__price"><dt class="mvweb-t-project__price-label">' . esc_html( $price['label'] ) . '</dt><dd class="mvweb-t-project__price-value">' . esc_html( $price['value'] ) . '</dd></div>';
			}
		}

		if ( '' === $html || 'table' === $mvweb_mod ) {
			return $html;
		}

		return '<dl class="mvweb-t-project__prices"' . $mvweb_rv( $rv ) . '>' . $html . '</dl>';
	},
	'link'    => static function ( $rv ) use ( $mvweb_text, $mvweb_rv ) {
		$label = $mvweb_text( 'link_text' );
		$url   = $mvweb_text( 'link_url' );

		return '' !== $label && '' !== $url
			? '<a class="mvweb-t-btn mvweb-t-project__link' . ( mb_strlen( $label ) > 26 ? ' mvweb-t-project__link--wrap' : '' ) . '" href="' . esc_url( $url ) . '"' . $mvweb_rv( $rv ) . '>' . esc_html( $label ) . ' ' . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>'
			: '';
	},
);

$mvweb_group = static function ( array $members, $rv, array $merge = array(), array $wrap = array() ) use ( $mvweb_shown, $mvweb_part, $mvweb_rv ) {
	$html   = '';
	$merged = false;

	foreach ( $mvweb_shown as $slug ) {
		if ( ! in_array( $slug, $members, true ) || ! isset( $mvweb_part[ $slug ] ) ) {
			continue;
		}

		if ( in_array( $slug, $merge, true ) ) {
			if ( $merged ) {
				continue;
			}

			$inner  = '';
			$merged = true;

			foreach ( $mvweb_shown as $other ) {
				if ( in_array( $other, $merge, true ) ) {
					$inner .= $mvweb_part[ $other ]( false );
				}
			}

			$html .= '' !== $inner ? '<dl class="' . esc_attr( $wrap['class'] ) . '"' . $mvweb_rv( $rv ) . '>' . $inner . '</dl>' : '';
			continue;
		}

		$html .= $mvweb_part[ $slug ]( $rv );
	}

	return $html;
};

$mvweb_frame = static function ( $html, $css, $rv = false, $tag = 'div' ) use ( $mvweb_rv ) {
	return '' !== $html ? '<' . $tag . ' class="' . esc_attr( $css ) . '"' . $mvweb_rv( $rv ) . '>' . $html . '</' . $tag . '>' : '';
};

$mvweb_has_pictures = ! empty( $mvweb_photos ) && in_array( 'gallery', $mvweb_shown, true );
$mvweb_first        = $mvweb_has_pictures ? $mvweb_photos[0] : array();
$mvweb_out          = '';

if ( 'table' === $mvweb_mod ) {
	$mvweb_gallery = $mvweb_has_pictures
		? $mvweb_frame( $mvweb_shot( $mvweb_first, 'mvweb-t-project__main', 'mvweb-t-project__pan' ) . $mvweb_frame( $mvweb_thumbs(), 'mvweb-t-project__thumbs' ), 'mvweb-t-project__view', true )
		: '';
	$mvweb_info    = $mvweb_group( array( 'eyebrow', 'name', 'text', 'facts', 'prices', 'link' ), true, array( 'facts', 'prices' ), array( 'class' => 'mvweb-t-project__specs' ) );
	$mvweb_out     = $mvweb_frame( $mvweb_gallery . $mvweb_frame( $mvweb_info, 'mvweb-t-project__info' ), 'mvweb-t-project__sheet', false, 'article' );
} elseif ( 'cover' === $mvweb_mod ) {
	$mvweb_gallery = $mvweb_has_pictures
		? $mvweb_shot( $mvweb_first, 'mvweb-t-project__hero', 'mvweb-t-project__pan', '', true ) . $mvweb_frame( $mvweb_thumbs(), 'mvweb-t-project__thumbs', true )
		: '';
	$mvweb_deck    = $mvweb_frame( $mvweb_group( array( 'eyebrow', 'name', 'text', 'link' ), false ), 'mvweb-t-project__plate mvweb-t-project__plate--text', true )
		. $mvweb_frame( $mvweb_group( array( 'facts', 'prices' ), false ), 'mvweb-t-project__plate mvweb-t-project__plate--facts', true );
	$mvweb_out     = $mvweb_frame( $mvweb_gallery . $mvweb_frame( $mvweb_deck, 'mvweb-t-project__deck' ), 'mvweb-t-project__cover', false, 'article' );
} elseif ( 'steps' === $mvweb_mod ) {
	$mvweb_steps = '';

	if ( $mvweb_has_pictures ) {
		foreach ( $mvweb_photos as $mvweb_index => $mvweb_photo ) {
			$mvweb_fact   = in_array( 'facts', $mvweb_shown, true ) && isset( $mvweb_facts[ $mvweb_index ] ) ? $mvweb_facts[ $mvweb_index ] : array();
			$mvweb_body   = ( '' !== $mvweb_photo['title'] ? '<span class="mvweb-t-project__step-title">' . esc_html( $mvweb_photo['title'] ) . '</span>' : '' )
				. ( ! empty( $mvweb_fact ) ? '<span class="mvweb-t-project__step-fact"><span class="mvweb-t-project__fact-value">' . esc_html( $mvweb_fact_value( $mvweb_fact ) ) . '</span><span class="mvweb-t-project__fact-label">' . esc_html( $mvweb_fact['label'] ) . '</span></span>' : '' );
			$mvweb_steps .= '<li class="mvweb-t-project__step"><span class="mvweb-t-project__step-num" aria-hidden="true">' . esc_html( (string) ( $mvweb_index + 1 ) ) . '</span><div class="mvweb-t-project__step-card">'
				. $mvweb_shot( $mvweb_photo, 'mvweb-t-project__step-photo', '', '', true )
				. $mvweb_frame( $mvweb_body, 'mvweb-t-project__step-body', true )
				. '</div></li>';
		}
	}

	$mvweb_lead = $mvweb_group( array( 'eyebrow', 'name', 'text', 'prices', 'link' ), true );
	$mvweb_out  = $mvweb_frame(
		$mvweb_frame( $mvweb_lead, 'mvweb-t-project__lead' ) . ( '' !== $mvweb_steps ? '<ol class="mvweb-t-project__steps">' . $mvweb_steps . '</ol>' : '' ),
		'mvweb-t-project__route',
		false,
		'article'
	);
} elseif ( 'numbers' === $mvweb_mod ) {
	$mvweb_collage = '';

	if ( $mvweb_has_pictures ) {
		$mvweb_collage = $mvweb_frame( $mvweb_shot( $mvweb_first, 'mvweb-t-project__main' ) . $mvweb_thumbs(), 'mvweb-t-project__collage', true );
	}

	$mvweb_info  = $mvweb_frame( $mvweb_group( array( 'eyebrow', 'name', 'text' ), true ), 'mvweb-t-project__info' );
	$mvweb_tiles = in_array( 'facts', $mvweb_shown, true ) ? $mvweb_part['facts']( true ) : '';
	$mvweb_out   = $mvweb_frame(
		$mvweb_frame( $mvweb_info . $mvweb_collage, 'mvweb-t-project__head' ) . $mvweb_tiles . $mvweb_frame( $mvweb_group( array( 'prices', 'link' ), true ), 'mvweb-t-project__foot' ),
		'mvweb-t-project__board',
		false,
		'article'
	);
} else {
	$mvweb_gallery = $mvweb_has_pictures
		? $mvweb_frame( $mvweb_shot( $mvweb_first, 'mvweb-t-project__main' ) . $mvweb_frame( $mvweb_thumbs(), 'mvweb-t-project__thumbs' ), 'mvweb-t-project__gallery', true )
		: '';
	$mvweb_info    = $mvweb_frame( $mvweb_group( array( 'eyebrow', 'name', 'text', 'facts', 'prices', 'link' ), true ), 'mvweb-t-project__info' );
	$mvweb_out     = $mvweb_frame( $mvweb_gallery . $mvweb_info, 'mvweb-t-project__card', false, 'article' );
}

if ( '' === $mvweb_out ) {
	return;
}

mvweb_theme_section_open( $mvweb_block );
echo $mvweb_out; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
mvweb_theme_section_close();
