<?php
/**
 * Section template: the branches of the chosen city.
 *
 * Five views: cards with a photo, a list beside a map, a table, tabs, ribbon
 * cards. The branches are those of the chosen city, from the branch records;
 * without records the address of the company details stands in. The head and
 * the list come in the order the composition sets, a branch prints its parts
 * the same way inside the boxes of its view, and a part without data is not
 * printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block  = mvweb_theme_block( 'branches', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props  = $mvweb_block['props'];
$mvweb_view   = $mvweb_block['view'];
$mvweb_motion = '' !== $mvweb_block['motion'];
$mvweb_data   = mvweb_core_contacts();
$mvweb_list   = ! empty( $mvweb_data['branches'] ) ? $mvweb_data['branches'] : $mvweb_data['addresses'];

if ( empty( $mvweb_list ) ) {
	return;
}

foreach ( $mvweb_list as $mvweb_key => $mvweb_branch ) {
	if ( empty( $mvweb_data['branches'] ) ) {
		$mvweb_list[ $mvweb_key ]['phones'] = $mvweb_data['phones'];
	}
}

$mvweb_text = static function ( $key ) use ( $mvweb_props ) {
	return isset( $mvweb_props[ $key ] ) ? trim( (string) $mvweb_props[ $key ] ) : '';
};

$mvweb_rv = static function ( $dir = 0 ) use ( $mvweb_motion ) {
	if ( ! $mvweb_motion ) {
		return '';
	}

	return ' data-rv' . ( 0 !== $dir ? ' data-rv-dir="' . (int) $dir . '"' : '' );
};

$mvweb_nest = static function ( array $items, array $wrap, $depth = 0 ) use ( &$mvweb_nest ) {
	$out  = '';
	$name = '';
	$run  = array();

	$items[] = array(
		'path' => array(),
		'html' => '',
	);

	foreach ( $items as $item ) {
		$next = isset( $item['path'][ $depth ] ) ? $item['path'][ $depth ] : '';

		if ( $next !== $name || '' === $name ) {
			if ( '' !== $name && ! empty( $run ) ) {
				$inner = $mvweb_nest( $run, $wrap, $depth + 1 );
				$out  .= '' === trim( $inner ) ? '' : call_user_func( $wrap[ $name ], $inner );
			}

			$run  = array();
			$name = $next;

			if ( '' === $next ) {
				$out .= $item['html'];
				continue;
			}
		}

		$run[] = $item;
	}

	return $out;
};

$mvweb_hours_line = static function ( array $branch ) {
	$lines = array();

	foreach ( $branch['hours'] as $row ) {
		$line = trim( $row['days'] . ' ' . $row['time'] );

		if ( '' !== $line ) {
			$lines[] = $line;
		}
	}

	return implode( ', ', $lines );
};

$mvweb_landmark = static function ( $note ) {
	return '' !== $note ? '<span class="mvweb-t-branches__landmark">' . esc_html( $note ) . '</span>' : '';
};

$mvweb_image = static function ( array $branch, $size ) {
	return $branch['image'] ? wp_get_attachment_image( (int) $branch['image'], $size ) : '';
};

$mvweb_route_url = static function ( array $branch ) {
	return '' !== $branch['route_url'] ? $branch['route_url'] : $branch['map_link'];
};

$mvweb_first_action = static function ( array $branch ) use ( $mvweb_block, $mvweb_view, $mvweb_route_url, $mvweb_text ) {
	foreach ( $mvweb_block['item_parts'] as $slug ) {
		if ( 'book' === $slug && in_array( $mvweb_view, array( '1', '4' ), true ) && '' !== $branch['book_url'] && '' !== $mvweb_text( 'book_text' ) ) {
			return 'book';
		}

		if ( 'route' === $slug && '' !== $mvweb_route_url( $branch ) && '' !== $mvweb_text( 'route_text' ) ) {
			return 'route';
		}
	}

	return '';
};

$mvweb_button = static function ( $slug, array $branch ) use ( $mvweb_view, $mvweb_text, $mvweb_route_url, $mvweb_first_action ) {
	$label   = $mvweb_text( 'book' === $slug ? 'book_text' : 'route_text' );
	$url     = 'book' === $slug ? $branch['book_url'] : $mvweb_route_url( $branch );
	$outline = $mvweb_first_action( $branch ) !== $slug ? ' mvweb-t-btn--outline' : '';

	if ( '' === $label || '' === $url || ( 'book' === $slug && ! in_array( $mvweb_view, array( '1', '4' ), true ) ) ) {
		return '';
	}

	if ( 'book' === $slug || '1' === $mvweb_view ) {
		return '<a class="mvweb-t-btn mvweb-t-btn--sm' . $outline . '" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
	}

	$aria = '' !== $branch['title'] ? ' aria-label="' . esc_attr( $label . ': ' . $branch['title'] ) . '"' : '';

	if ( '3' === $mvweb_view ) {
		return '<a class="mvweb-t-branches__go" href="' . esc_url( $url ) . '"' . $aria . '><span>' . esc_html( $label ) . '</span>' . mvweb_theme_icon( 'arrow-up-right' ) . '</a>';
	}

	return '<a class="mvweb-t-btn mvweb-t-btn--sm' . $outline . '" href="' . esc_url( $url ) . '"' . $aria . '>' . esc_html( $label ) . mvweb_theme_icon( 'arrow-up-right' ) . '</a>';
};

$mvweb_phones = static function ( array $branch ) {
	$phones = array();

	foreach ( $branch['phones'] as $phone ) {
		$number = trim( (string) $phone['number'] );

		if ( '' !== $number ) {
			$phones[] = array(
				'link'    => '' !== $phone['href']
					? '<a class="mvweb-t-branches__phone" href="' . esc_url( $phone['href'] ) . '">' . esc_html( $number ) . '</a>'
					: '<span class="mvweb-t-branches__phone">' . esc_html( $number ) . '</span>',
				'caption' => trim( (string) $phone['label'] ),
				'number'  => $number,
				'href'    => (string) $phone['href'],
			);
		}
	}

	return $phones;
};

$mvweb_row = static function ( $icon, $inner ) {
	return '<p class="mvweb-t-branches__row">' . mvweb_theme_icon( $icon ) . $inner . '</p>';
};

$mvweb_piece = static function ( $slug, array $branch, $number ) use ( $mvweb_view, $mvweb_rv, $mvweb_text, $mvweb_hours_line, $mvweb_landmark, $mvweb_image, $mvweb_button, $mvweb_phones, $mvweb_row ) {
	$title = trim( (string) $branch['title'] );

	switch ( $slug ) {
		case 'icon':
			return '5' === $mvweb_view ? '<span class="mvweb-t-branches__badge" aria-hidden="true">' . mvweb_theme_icon( 'map-pin' ) . '</span>' : '';

		case 'index':
			return '2' === $mvweb_view ? '<span class="mvweb-t-branches__num" aria-hidden="true">' . (int) $number . '</span>' : '';

		case 'image':
			if ( '2' === $mvweb_view || '5' === $mvweb_view ) {
				return '';
			}

			$sizes = array(
				'1' => 'medium_large',
				'3' => 'thumbnail',
				'4' => 'large',
			);
			$image = $mvweb_image( $branch, $sizes[ $mvweb_view ] );

			if ( '' === $image ) {
				return '';
			}

			return '3' === $mvweb_view ? '<span class="mvweb-t-branches__thumb">' . $image . '</span>' : '<div class="mvweb-t-branches__media">' . $image . '</div>';

		case 'title':
			if ( '' === $title ) {
				return '';
			}

			return '3' === $mvweb_view
				? '<span class="mvweb-t-branches__title mvweb-t-h3">' . esc_html( $title ) . '</span>'
				: '<div class="mvweb-t-branches__title mvweb-t-h3">' . esc_html( $title ) . '</div>';

		case 'address':
			$address = trim( (string) $branch['address'] );

			if ( '' === $address ) {
				return '';
			}

			if ( '5' === $mvweb_view ) {
				return '<p class="mvweb-t-branches__addr">' . esc_html( $address ) . $mvweb_landmark( trim( (string) $branch['note'] ) ) . '</p>';
			}

			return '3' === $mvweb_view
				? esc_html( $address ) . $mvweb_landmark( trim( (string) $branch['note'] ) )
				: $mvweb_row( 'map-pin', '<span>' . esc_html( $address ) . $mvweb_landmark( trim( (string) $branch['note'] ) ) . '</span>' );

		case 'status':
			return '5' === $mvweb_view && '' !== $mvweb_text( 'status_text' )
				? '<span class="mvweb-t-branches__status"><span class="mvweb-t-branches__dot" aria-hidden="true"></span>' . esc_html( $mvweb_text( 'status_text' ) ) . '</span>'
				: '';

		case 'hours':
			$hours = $mvweb_hours_line( $branch );

			if ( '' === $hours ) {
				return '';
			}

			if ( '3' === $mvweb_view ) {
				return esc_html( $hours );
			}

			return '5' === $mvweb_view ? '<span class="mvweb-t-branches__hours">' . esc_html( $hours ) . '</span>' : $mvweb_row( 'clock', '<span>' . esc_html( $hours ) . '</span>' );

		case 'phone':
			$phones = $mvweb_phones( $branch );
			$html   = '';

			if ( '5' === $mvweb_view ) {
				foreach ( $phones as $phone ) {
					$html .= '' !== $phone['href']
						? '<a class="mvweb-t-branches__phone mvweb-t-branches__call" href="' . esc_url( $phone['href'] ) . '">' . mvweb_theme_icon( 'phone' ) . esc_html( $phone['number'] ) . '</a>'
						: '<span class="mvweb-t-branches__phone mvweb-t-branches__call">' . mvweb_theme_icon( 'phone' ) . esc_html( $phone['number'] ) . '</span>';
				}

				return count( $phones ) > 1 ? '<div class="mvweb-t-branches__calls">' . $html . '</div>' : $html;
			}

			foreach ( $phones as $phone ) {
				if ( '3' === $mvweb_view ) {
					$one   = $phone['link'] . $mvweb_landmark( $phone['caption'] );
					$html .= count( $phones ) > 1 || '' !== $phone['caption'] ? '<span class="mvweb-t-branches__tel">' . $one . '</span>' : $one;
					continue;
				}

				$html .= $mvweb_row( 'phone', '' !== $phone['caption'] ? '<span>' . $phone['link'] . $mvweb_landmark( $phone['caption'] ) . '</span>' : $phone['link'] );
			}

			return $html;

		case 'book':
		case 'route':
			return '3' === $mvweb_view ? '' : $mvweb_button( $slug, $branch );
	}

	return '';
};

$mvweb_paths = array(
	'icon'    => array(),
	'index'   => array(),
	'image'   => array(),
	'title'   => array( 'body' ),
	'address' => array( 'body', 'info' ),
	'hours'   => array( 'body', 'info' ),
	'phone'   => array( 'body', 'info' ),
	'status'  => array( 'body', 'info' ),
	'book'    => array( 'body', 'actions' ),
	'route'   => array( 'body', 'actions' ),
);

if ( '2' === $mvweb_view ) {
	$mvweb_paths['index'] = array();
}

if ( '5' === $mvweb_view ) {
	$mvweb_paths['title']   = array( 'main' );
	$mvweb_paths['address'] = array( 'main' );
	$mvweb_paths['status']  = array( 'when' );
	$mvweb_paths['hours']   = array( 'when' );
	$mvweb_paths['phone']   = array();
	$mvweb_paths['route']   = array( 'act' );
}

$mvweb_wrap = array(
	'body'    => static function ( $inner ) {
		return '<div class="mvweb-t-branches__body">' . $inner . '</div>';
	},
	'info'    => static function ( $inner ) {
		return '<div class="mvweb-t-branches__info">' . $inner . '</div>';
	},
	'actions' => static function ( $inner ) {
		return '<div class="mvweb-t-branches__actions">' . $inner . '</div>';
	},
	'main'    => static function ( $inner ) {
		return '<div class="mvweb-t-branches__main">' . $inner . '</div>';
	},
	'when'    => static function ( $inner ) {
		return '<div class="mvweb-t-branches__when">' . $inner . '</div>';
	},
	'act'     => static function ( $inner ) {
		return '<div class="mvweb-t-branches__act">' . $inner . '</div>';
	},
);

$mvweb_branch_html = static function ( array $branch, $number ) use ( $mvweb_block, $mvweb_piece, $mvweb_paths, $mvweb_nest, $mvweb_wrap ) {
	$items = array();

	foreach ( $mvweb_block['item_parts'] as $slug ) {
		$html = isset( $mvweb_paths[ $slug ] ) ? $mvweb_piece( $slug, $branch, $number ) : '';

		if ( '' !== $html ) {
			$items[] = array(
				'path' => $mvweb_paths[ $slug ],
				'html' => $html,
			);
		}
	}

	return $mvweb_nest( $items, $mvweb_wrap );
};

$mvweb_table_html = static function () use ( $mvweb_block, $mvweb_list, $mvweb_piece, $mvweb_rv, $mvweb_button ) {
	$columns = array();

	foreach ( $mvweb_block['item_parts'] as $slug ) {
		$column = in_array( $slug, array( 'image', 'title' ), true ) ? 'name' : $slug;

		if ( in_array( $column, array( 'name', 'address', 'hours', 'phone', 'route' ), true ) && ! in_array( $column, $columns, true ) ) {
			$columns[] = $column;
		}
	}

	$labels = array(
		'name'    => __( 'Branch', 'brand-market' ),
		'address' => __( 'Address', 'brand-market' ),
		'hours'   => __( 'Opening hours', 'brand-market' ),
		'phone'   => __( 'Phone', 'brand-market' ),
	);
	$head   = '';

	foreach ( $columns as $column ) {
		$head .= 'route' === $column
			? '<th scope="col"><span class="screen-reader-text">' . esc_html__( 'Route', 'brand-market' ) . '</span></th>'
			: '<th scope="col">' . esc_html( $labels[ $column ] ) . '</th>';
	}

	$rows = '';

	foreach ( $mvweb_list as $index => $branch ) {
		$cells = '';

		foreach ( $columns as $column ) {
			if ( 'name' === $column ) {
				$thumb  = in_array( 'image', $mvweb_block['item_parts'], true ) ? $mvweb_piece( 'image', $branch, $index + 1 ) : '';
				$title  = in_array( 'title', $mvweb_block['item_parts'], true ) ? $mvweb_piece( 'title', $branch, $index + 1 ) : '';
				$cells .= '<th scope="row" class="mvweb-t-branches__cell mvweb-t-branches__cell--name"><span class="mvweb-t-branches__namebox">' . $thumb . $title . '</span></th>';
				continue;
			}

			if ( 'route' === $column ) {
				$cells .= '<td class="mvweb-t-branches__cell mvweb-t-branches__cell--go">' . $mvweb_button( 'route', $branch ) . '</td>';
				continue;
			}

			$inner  = $mvweb_piece( $column, $branch, $index + 1 );
			$cells .= '<td class="mvweb-t-branches__cell"' . ( '' !== $inner ? ' data-label="' . esc_attr( $labels[ $column ] ) . '"' : '' ) . '>' . $inner . '</td>';
		}

		$rows .= '<tr class="mvweb-t-branches__tr"' . $mvweb_rv() . '>' . $cells . '</tr>';
	}

	return '<table class="mvweb-t-branches__table"><caption class="screen-reader-text">' . esc_html__( 'Addresses, opening hours and phones', 'brand-market' ) . '</caption><thead><tr>' . $head . '</tr></thead><tbody>' . $rows . '</tbody></table>';
};

$mvweb_tabs_html = static function () use ( $mvweb_list, $mvweb_branch_html, $mvweb_rv ) {
	$branches = array_slice( $mvweb_list, 0, 8 );
	$uid      = wp_unique_id( 'branches-tabs-' );
	$radios   = '';
	$labels   = '';
	$panels   = '';

	foreach ( $branches as $index => $branch ) {
		$id = $uid . '-' . ( $index + 1 );

		if ( count( $branches ) > 1 ) {
			$radios .= '<input class="mvweb-t-branches__radio" type="radio" name="' . esc_attr( $uid ) . '" id="' . esc_attr( $id ) . '"' . checked( 0, $index, false ) . '>';
			$labels .= '<label class="mvweb-t-branches__tab" for="' . esc_attr( $id ) . '">' . esc_html( '' !== trim( (string) $branch['title'] ) ? $branch['title'] : (string) ( $index + 1 ) ) . '</label>';
		}

		$panels .= '<article class="mvweb-t-branches__panel">' . $mvweb_branch_html( $branch, $index + 1 ) . '</article>';
	}

	return '<fieldset class="mvweb-t-branches__tabs"><legend class="screen-reader-text">' . esc_html__( 'Choose a branch', 'brand-market' ) . '</legend>' . $radios
		. ( '' !== $labels ? '<div class="mvweb-t-branches__tablist"' . $mvweb_rv() . '>' . $labels . '</div>' : '' )
		. '<div class="mvweb-t-branches__panels"' . $mvweb_rv() . '>' . $panels . '</div></fieldset>';
};

$mvweb_map_html = static function () use ( $mvweb_list, $mvweb_rv ) {
	$map = array(
		'src'   => '',
		'image' => '',
	);

	foreach ( $mvweb_list as $branch ) {
		if ( '' === $map['src'] && ! empty( $branch['map'] ) ) {
			$map['src'] = (string) $branch['map'];
		}
	}

	if ( '' === $map['src'] ) {
		$map = mvweb_core_profile_map();
	}

	$titles = array_values( array_filter( array_map( 'trim', wp_list_pluck( $mvweb_list, 'title' ) ), 'strlen' ) );
	$name   = ! empty( $titles ) ? __( 'Locations', 'brand-market' ) . ': ' . implode( ', ', $titles ) : __( 'Map', 'brand-market' );

	if ( '' !== $map['image'] || '' !== $map['src'] ) {
		$id    = '' !== $map['image'] ? attachment_url_to_postid( $map['image'] ) : 0;
		$frame = '' !== $map['image']
			? ( $id ? wp_get_attachment_image( $id, 'large', false, array( 'class' => 'mvweb-t-branches__frame' ) ) : '<img class="mvweb-t-branches__frame" src="' . esc_url( $map['image'] ) . '" alt="' . esc_attr( $name ) . '" loading="lazy" decoding="async">' )
			: '<iframe class="mvweb-t-branches__frame" src="' . esc_url( $map['src'] ) . '" title="' . esc_attr( $name ) . '" loading="lazy" referrerpolicy="no-referrer-when-downgrade" allowfullscreen></iframe>';

		return '<div class="mvweb-t-branches__map mvweb-t-branches__map--live"' . $mvweb_rv( 1 ) . '>' . $frame . '</div>';
	}

	$pins  = '';
	$total = min( 8, count( $mvweb_list ) );

	for ( $mvweb_pin = 1; $mvweb_pin <= $total; $mvweb_pin++ ) {
		$pins .= '<span class="mvweb-t-branches__pin"><span class="mvweb-t-branches__pin-dot" aria-hidden="true">' . $mvweb_pin . '</span></span>';
	}

	return '<div class="mvweb-t-branches__map"' . ( ! empty( $titles ) ? ' role="img" aria-label="' . esc_attr( $name ) . '"' : ' aria-hidden="true"' ) . $mvweb_rv( 1 ) . '>' . $pins . '</div>';
};

$mvweb_list_html = static function () use ( $mvweb_view, $mvweb_list, $mvweb_branch_html, $mvweb_rv, $mvweb_table_html, $mvweb_tabs_html ) {
	if ( '3' === $mvweb_view ) {
		return $mvweb_table_html();
	}

	if ( '4' === $mvweb_view ) {
		return $mvweb_tabs_html();
	}

	$html = '';

	foreach ( $mvweb_list as $index => $branch ) {
		$inner = $mvweb_branch_html( $branch, $index + 1 );

		if ( '1' === $mvweb_view ) {
			$html .= '<article class="mvweb-t-branches__card"' . $mvweb_rv() . '>' . $inner . '</article>';
		} elseif ( '2' === $mvweb_view ) {
			$html .= '<li class="mvweb-t-branches__place"' . $mvweb_rv( -1 ) . '>' . $inner . '</li>';
		} else {
			$html .= '<article class="mvweb-t-branches__ribbon"' . $mvweb_rv() . '>' . $inner . '</article>';
		}
	}

	$wrappers = array(
		'1' => '<div class="mvweb-t-branches__grid' . ( count( $mvweb_list ) < 3 ? ' mvweb-t-branches__grid--2' : '' ) . '">%s</div>',
		'2' => '<ol class="mvweb-t-branches__places">%s</ol>',
		'5' => '<div class="mvweb-t-branches__ribbons">%s</div>',
	);

	return sprintf( $wrappers[ $mvweb_view ], $html );
};

$mvweb_out     = '';
$mvweb_pending = array();
$mvweb_split   = '';
$mvweb_head    = static function ( array $slugs ) use ( $mvweb_block, $mvweb_view ) {
	ob_start();
	mvweb_theme_head(
		$mvweb_block,
		$slugs,
		array(
			'rv'    => true,
			'class' => '4' === $mvweb_view ? 'mvweb-t-section-head--center' : '',
		)
	);

	return (string) ob_get_clean();
};

foreach ( array_merge( $mvweb_block['parts'], array( '' ) ) as $mvweb_slug ) {
	if ( in_array( $mvweb_slug, array( 'kicker', 'title', 'lead' ), true ) ) {
		$mvweb_pending[] = $mvweb_slug;
		continue;
	}

	if ( ! empty( $mvweb_pending ) ) {
		$mvweb_out    .= ( '' !== $mvweb_split ? '<div class="mvweb-t-branches__split">' . $mvweb_split . '</div>' : '' ) . $mvweb_head( $mvweb_pending );
		$mvweb_split   = '';
		$mvweb_pending = array();
	}

	if ( 'list' === $mvweb_slug ) {
		$mvweb_html = $mvweb_list_html();

		if ( '2' === $mvweb_view ) {
			$mvweb_split .= $mvweb_html;
		} else {
			$mvweb_out .= $mvweb_html;
		}
	}

	if ( 'map' === $mvweb_slug && '2' === $mvweb_view ) {
		$mvweb_split .= $mvweb_map_html();
	}
}

$mvweb_out .= '' !== $mvweb_split ? '<div class="mvweb-t-branches__split">' . $mvweb_split . '</div>' : '';

if ( '' === trim( $mvweb_out ) ) {
	return;
}

mvweb_theme_section_open( $mvweb_block );
echo $mvweb_out; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts.
mvweb_theme_section_close();
