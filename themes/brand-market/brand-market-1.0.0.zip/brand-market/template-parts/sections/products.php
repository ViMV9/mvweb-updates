<?php
/**
 * Section template: products of the catalogue in cards.
 *
 * Five views: a dense grid, a scrolling row, large cards, a bento grid and a
 * list as a table. Every card is the one of the theme, so what it shows is set
 * once for the site. The head, the pills of departments, the cards and the
 * closing block come in the order the composition sets; a part without data
 * is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'products', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_ids   = mvweb_theme_product_ids( $mvweb_props );

if ( empty( $mvweb_ids ) ) {
	return;
}

if ( ! empty( $mvweb_props['link_text'] ) && empty( $mvweb_props['link_url'] ) ) {
	$mvweb_block['props']['link_url'] = mvweb_core_catalog_page_url();
}

$mvweb_view   = $mvweb_block['mod'];
$mvweb_rail   = 'rail' === $mvweb_view;
$mvweb_motion = '' !== $mvweb_block['motion'];
$mvweb_total  = count( $mvweb_ids );
$mvweb_deps   = 'categories' === ( isset( $mvweb_props['filter'] ) ? $mvweb_props['filter'] : 'none' ) ? mvweb_theme_departments( $mvweb_ids ) : array();
$mvweb_form   = mvweb_theme_form_shortcode( isset( $mvweb_props['card_form'] ) ? (string) $mvweb_props['card_form'] : '' );
$mvweb_popup  = isset( $mvweb_props['card_action'] ) && 'form' === $mvweb_props['card_action'] && '' !== $mvweb_form;
$mvweb_button = array(
	'text'   => isset( $mvweb_props['card_button'] ) ? (string) $mvweb_props['card_button'] : '',
	'url'    => isset( $mvweb_props['card_url'] ) ? (string) $mvweb_props['card_url'] : '',
	'action' => $mvweb_popup ? 'form' : 'link',
);

$mvweb_card = static function ( $id, $index ) use ( $mvweb_view, $mvweb_motion, $mvweb_total, $mvweb_deps, $mvweb_button, $mvweb_props ) {
	$class = '';
	$attrs = array();

	if ( 'bento' === $mvweb_view ) {
		if ( 0 === $index ) {
			$class = 'mvweb-t-products__feature';
		} elseif ( $mvweb_total > 3 && 0 === $mvweb_total % 4 && $mvweb_total - 1 === $index ) {
			$class = 'mvweb-t-products__wide';
		}
	}

	if ( $mvweb_motion ) {
		$attrs['data-rv'] = '';
	}

	if ( ! empty( $mvweb_deps['names'] ) && count( $mvweb_deps['names'] ) > 1 ) {
		$attrs['data-products-card'] = '';
		$attrs['data-products-cat']  = implode( ' ', isset( $mvweb_deps['by_item'][ $id ] ) ? $mvweb_deps['by_item'][ $id ] : array() );
	}

	get_template_part(
		'template-parts/catalog/card',
		null,
		array(
			'id'     => $id,
			'class'  => $class,
			'attrs'  => $attrs,
			'button' => $mvweb_button,
			'badge'  => isset( $mvweb_props['badge'] ) ? (string) $mvweb_props['badge'] : 'own',
		)
	);
};

$mvweb_parts = array(
	'chips'   => static function () use ( $mvweb_deps, $mvweb_props ) {
		if ( empty( $mvweb_deps['names'] ) || count( $mvweb_deps['names'] ) < 2 ) {
			return;
		}
		?>
		<div class="mvweb-t-chips mvweb-t-chips--scroll mvweb-t-products__chips" data-products-chips role="group" aria-label="<?php esc_attr_e( 'Departments of the catalogue', 'brand-market' ); ?>">
			<button class="mvweb-t-chip" type="button" data-products-chip="" aria-pressed="true"><?php echo esc_html( isset( $mvweb_props['filter_all'] ) && '' !== $mvweb_props['filter_all'] ? $mvweb_props['filter_all'] : __( 'All', 'brand-market' ) ); ?></button>
			<?php foreach ( $mvweb_deps['names'] as $slug => $name ) : ?>
				<button class="mvweb-t-chip" type="button" data-products-chip="<?php echo esc_attr( $slug ); ?>" aria-pressed="false"><?php echo esc_html( $name ); ?></button>
			<?php endforeach; ?>
		</div>
		<?php
	},
	'list'    => static function ( $block ) use ( $mvweb_ids, $mvweb_card, $mvweb_rail ) {
		if ( $mvweb_rail ) :
			?>
			<div class="mvweb-t-rail">
				<div class="mvweb-t-rail__track" data-showcase-track data-scroller="<?php esc_attr_e( 'Products', 'brand-market' ); ?>">
					<?php foreach ( $mvweb_ids as $index => $id ) : ?>
						<?php $mvweb_card( $id, $index ); ?>
					<?php endforeach; ?>
				</div>
				<?php if ( count( $mvweb_ids ) > 1 && mvweb_core_has_part( $block['props'], 'dots' ) ) : ?>
					<div class="mvweb-t-rail__dots" data-showcase-dots></div>
				<?php endif; ?>
			</div>
			<?php
		else :
			?>
			<div class="<?php echo esc_attr( 'mvweb-t-grid' . ( '' !== $block['mod'] ? ' mvweb-t-products__grid' : '' ) ); ?>">
				<?php foreach ( $mvweb_ids as $index => $id ) : ?>
					<?php $mvweb_card( $id, $index ); ?>
				<?php endforeach; ?>
			</div>
			<?php
		endif;
	},
	'closing' => static function ( $block ) {
		$props  = $block['props'];
		$lead   = isset( $props['cta_lead'] ) ? (string) $props['cta_lead'] : '';
		$note   = isset( $props['cta_note'] ) ? (string) $props['cta_note'] : '';
		$button = isset( $props['cta_button'] ) ? (string) $props['cta_button'] : '';
		$url    = isset( $props['cta_url'] ) ? (string) $props['cta_url'] : '';
		$form   = mvweb_theme_form_shortcode( isset( $props['form'] ) ? (string) $props['form'] : '' );
		$copy   = '' !== $lead || '' !== $note || ( '' !== $button && '' !== $url );

		if ( ! $copy && '' === $form ) {
			return;
		}
		?>
		<div class="<?php echo esc_attr( '' !== $form ? 'mvweb-t-products__closing mvweb-t-products__closing--form' : 'mvweb-t-products__closing' ); ?>">
			<?php if ( $copy ) : ?>
				<div class="mvweb-t-products__closing-text">
					<?php if ( '' !== $lead ) : ?>
						<p class="mvweb-t-products__closing-lead"><?php echo esc_html( $lead ); ?></p>
					<?php endif; ?>
					<?php if ( '' !== $button && '' !== $url ) : ?>
						<a class="mvweb-t-btn" href="<?php echo esc_url( $url ); ?>"><?php echo esc_html( $button ); ?> <?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></a>
					<?php endif; ?>
					<?php if ( '' !== $note ) : ?>
						<p class="mvweb-t-products__closing-note"><?php echo esc_html( $note ); ?></p>
					<?php endif; ?>
				</div>
			<?php endif; ?>
			<?php if ( '' !== $form ) : ?>
				<div class="mvweb-t-products__form">
					<?php if ( ! empty( $props['form_title'] ) ) : ?>
						<div class="mvweb-t-products__form-title mvweb-t-h3"><?php echo esc_html( (string) $props['form_title'] ); ?></div>
					<?php endif; ?>
					<div class="mvweb-t-form">
						<?php echo $form; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Shortcode output is escaped by the plugin that owns it. ?>
					</div>
				</div>
			<?php endif; ?>
		</div>
		<?php
	},
);

$mvweb_head = array( 'kicker', 'title', 'lead', 'more', 'arrows' );
$mvweb_nav  = '';

if ( $mvweb_rail && $mvweb_total > 1 && mvweb_core_has_part( $mvweb_props, 'arrows' ) ) {
	$mvweb_nav = '<div class="mvweb-t-section-head__nav">' . mvweb_theme_showcase_arrows(
		array(
			'hide_prev' => true,
			'small'     => true,
		)
	) . '</div>';
}

$mvweb_print_head = static function ( array $slugs ) use ( &$mvweb_block, $mvweb_nav, $mvweb_rail ) {
	mvweb_theme_head(
		$mvweb_block,
		array_diff( $slugs, array( 'arrows' ) ),
		array(
			'rv'   => ! $mvweb_rail,
			'side' => in_array( 'arrows', $slugs, true ) ? $mvweb_nav : '',
		)
	);
};

mvweb_theme_section_open( $mvweb_block, false );
?>
<div class="mvweb-t-container" data-products<?php echo $mvweb_rail ? ' data-showcase' : ''; ?>>
	<?php
	$mvweb_pending = array();

	foreach ( array_merge( $mvweb_block['parts'], array( '' ) ) as $mvweb_slug ) {
		if ( in_array( $mvweb_slug, $mvweb_head, true ) ) {
			$mvweb_pending[] = $mvweb_slug;
			continue;
		}

		if ( ! empty( $mvweb_pending ) ) {
			$mvweb_print_head( $mvweb_pending );
			$mvweb_pending = array();
		}

		if ( '' !== $mvweb_slug && isset( $mvweb_parts[ $mvweb_slug ] ) ) {
			call_user_func( $mvweb_parts[ $mvweb_slug ], $mvweb_block );
		}
	}
	?>
	<?php if ( $mvweb_popup ) : ?>
		<?php $mvweb_modal = wp_unique_id( 'mvweb-t-products-modal-' ); ?>
		<dialog class="mvweb-t-products__modal" data-showcase-modal aria-labelledby="<?php echo esc_attr( $mvweb_modal ); ?>">
			<div class="mvweb-t-products__modal-box">
				<button class="mvweb-t-round mvweb-t-products__modal-close" type="button" data-showcase-modal-close title="<?php esc_attr_e( 'Close', 'brand-market' ); ?>">
					<?php echo mvweb_theme_icon( 'close', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<span class="screen-reader-text"><?php esc_html_e( 'Close', 'brand-market' ); ?></span>
				</button>
				<div class="mvweb-t-products__modal-title mvweb-t-h3" id="<?php echo esc_attr( $mvweb_modal ); ?>"><?php echo esc_html( isset( $mvweb_props['card_form_title'] ) && '' !== $mvweb_props['card_form_title'] ? $mvweb_props['card_form_title'] : __( 'Request for a product', 'brand-market' ) ); ?></div>
				<p class="mvweb-t-products__modal-product" data-showcase-modal-product></p>
				<div class="mvweb-t-form">
					<?php echo $mvweb_form; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Shortcode output is escaped by the plugin that owns it. ?>
				</div>
			</div>
		</dialog>
	<?php endif; ?>
</div>
<?php
mvweb_theme_section_close( false );
