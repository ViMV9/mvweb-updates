<?php
/**
 * Section template: two lists side by side.
 *
 * Five views: two cards, large marks, one card, a table, tabs. The head and
 * the lists come in the order the composition sets; the two lists and the
 * divider between them are printed as one body at the place of the first of
 * them. A list without a heading and without items is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block  = mvweb_theme_block( 'two-lists', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props  = $mvweb_block['props'];
$mvweb_view   = $mvweb_block['mod'];
$mvweb_rv     = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_binary = ! isset( $mvweb_props['marks'] ) || 'yes-yes' !== $mvweb_props['marks'];

$mvweb_value = static function ( $key ) use ( $mvweb_props ) {
	return isset( $mvweb_props[ $key ] ) ? trim( (string) $mvweb_props[ $key ] ) : '';
};

$mvweb_lists = array();

$mvweb_sides = array(
	'col_1' => 'left',
	'col_2' => 'right',
);

foreach ( $mvweb_sides as $mvweb_slug => $mvweb_side ) {
	$mvweb_lines = mvweb_core_text_lines( $mvweb_value( $mvweb_side . '_items' ) );
	$mvweb_name  = $mvweb_value( $mvweb_side . '_title' );

	if ( in_array( $mvweb_slug, $mvweb_block['parts'], true ) && ( '' !== $mvweb_name || ! empty( $mvweb_lines ) ) ) {
		$mvweb_lists[ $mvweb_slug ] = array(
			'title' => $mvweb_name,
			'tab'   => '' !== $mvweb_value( $mvweb_side . '_tab' ) ? $mvweb_value( $mvweb_side . '_tab' ) : $mvweb_name,
			'lines' => $mvweb_lines,
			'no'    => 'col_2' === $mvweb_slug && $mvweb_binary,
		);
	}
}

if ( empty( $mvweb_lists ) ) {
	return;
}

$mvweb_ordered = array();

foreach ( $mvweb_block['parts'] as $mvweb_slug ) {
	if ( isset( $mvweb_lists[ $mvweb_slug ] ) ) {
		$mvweb_ordered[ $mvweb_slug ] = $mvweb_lists[ $mvweb_slug ];
	}
}

$mvweb_lists = $mvweb_ordered;

$mvweb_has = static function ( $slug ) use ( $mvweb_block ) {
	return in_array( $slug, $mvweb_block['item_parts'], true );
};

$mvweb_icon = static function ( $entry ) {
	return mvweb_theme_icon( $entry['no'] ? 'close' : 'check' );
};

$mvweb_column = static function ( $entry ) use ( $mvweb_view, $mvweb_rv, $mvweb_has, $mvweb_icon ) {
	$no    = $entry['no'] ? ' mvweb-t-two-lists__col--no' : '';
	$rv    = in_array( $mvweb_view, array( 'cards', 'marks' ), true ) ? $mvweb_rv : '';
	$title = '';

	if ( '' !== $entry['title'] ) {
		$name    = '<span class="mvweb-t-two-lists__title-text">' . esc_html( $entry['title'] ) . '</span>';
		$classes = 'mvweb-t-two-lists__title mvweb-t-h3';
		$rvt     = '';

		if ( 'cards' === $mvweb_view ) {
			$name = esc_html( $entry['title'] );
		} elseif ( 'marks' === $mvweb_view && $mvweb_has( 'count' ) ) {
			$name .= '<span class="mvweb-t-two-lists__count" aria-hidden="true">' . esc_html( sprintf( '%02d', count( $entry['lines'] ) ) ) . '</span>';
		} elseif ( 'table' === $mvweb_view ) {
			$name = '<span class="mvweb-t-two-lists__title-icon" aria-hidden="true">' . $mvweb_icon( $entry ) . '</span>' . $name;
			$rvt  = $mvweb_rv;
		} elseif ( 'tabs' === $mvweb_view ) {
			$name     = esc_html( $entry['title'] );
			$classes .= ' screen-reader-text';
		}

		$title = '<div class="' . $classes . '"' . $rvt . '>' . $name . '</div>';
	}

	$items = '';

	foreach ( $entry['lines'] as $line ) {
		$mark   = $mvweb_has( 'mark' ) ? '<span class="mvweb-t-two-lists__mark' . ( $entry['no'] ? ' mvweb-t-two-lists__mark--no' : '' ) . '">' . $mvweb_icon( $entry ) . '</span>' : '';
		$items .= '<li class="mvweb-t-two-lists__item"' . ( 'table' === $mvweb_view ? $mvweb_rv : '' ) . '>' . $mark . '<span class="mvweb-t-two-lists__text">' . esc_html( $line ) . '</span></li>';
	}

	return '<div class="mvweb-t-two-lists__col' . $no . '"' . $rv . '>' . $title . ( '' !== $items ? '<ul class="mvweb-t-two-lists__list">' . $items . '</ul>' : '' ) . '</div>';
};

$mvweb_body = static function () use ( $mvweb_view, $mvweb_rv, $mvweb_lists, $mvweb_column, $mvweb_has, $mvweb_icon, $mvweb_block ) {
	if ( 'tabs' === $mvweb_view ) {
		$uid    = wp_unique_id( 'two-lists-tab-' );
		$radios = '';
		$labels = '';
		$panels = '';
		$place  = 0;

		foreach ( $mvweb_lists as $entry ) {
			$mod     = 0 === $place ? 'yes' : 'no';
			$id      = $uid . '-' . $mod;
			$radios .= '<input class="mvweb-t-two-lists__radio mvweb-t-two-lists__radio--' . $mod . ' screen-reader-text" type="radio" name="' . esc_attr( $uid ) . '" id="' . esc_attr( $id ) . '"' . ( 0 === $place ? ' checked' : '' ) . '>';
			$labels .= '<label class="mvweb-t-two-lists__tab mvweb-t-two-lists__tab--' . $mod . '" for="' . esc_attr( $id ) . '">' . $mvweb_icon( $entry ) . '<span class="mvweb-t-two-lists__tab-text">' . esc_html( $entry['tab'] ) . '</span>' . ( $mvweb_has( 'count' ) ? '<span class="mvweb-t-two-lists__tab-count">' . esc_html( (string) count( $entry['lines'] ) ) . '</span>' : '' ) . '</label>';
			$panels .= $mvweb_column( $entry );
			++$place;
		}

		echo '<div class="mvweb-t-two-lists__tabs"' . $mvweb_rv . '>' . $radios . '<div class="mvweb-t-two-lists__tablist">' . $labels . '</div><div class="mvweb-t-two-lists__panels">' . $panels . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.

		return;
	}

	$html    = '';
	$divider = 'split' === $mvweb_view && count( $mvweb_lists ) > 1 && in_array( 'divider', $mvweb_block['parts'], true )
		? '<div class="mvweb-t-two-lists__divider" aria-hidden="true"><span class="mvweb-t-two-lists__badge">' . mvweb_theme_icon( 'arrows-left-right' ) . '</span></div>'
		: '';

	foreach ( array_values( $mvweb_lists ) as $index => $entry ) {
		$html .= ( 1 === $index ? $divider : '' ) . $mvweb_column( $entry );
	}

	if ( 'split' === $mvweb_view ) {
		echo '<div class="mvweb-t-two-lists__card"' . $mvweb_rv . '>' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	} else {
		echo '<div class="mvweb-t-two-lists__grid">' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	}
};

$mvweb_done = false;
$mvweb_once = static function () use ( &$mvweb_done, $mvweb_body ) {
	if ( ! $mvweb_done ) {
		$mvweb_done = true;
		$mvweb_body();
	}
};

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts(
	$mvweb_block,
	array(
		'col_1'   => $mvweb_once,
		'divider' => $mvweb_once,
		'col_2'   => $mvweb_once,
	),
	array( 'rv' => true )
);
mvweb_theme_section_close();
