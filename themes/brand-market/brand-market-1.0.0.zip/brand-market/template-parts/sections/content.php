<?php
/**
 * Section template: text block.
 *
 * Five views: a column of text, a photo with a floating card, a photo with a
 * plate over it, a drop cap beside a quote, a mosaic of two photos. The text
 * is the editor's formatted text (the content of the entry itself when the
 * field is left empty); the heading, the text and the button follow the order
 * the composition sets, the pictures, the badge and the quote keep the places
 * the view gives them. A part without data is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'content', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_parts = $mvweb_block['parts'];
$mvweb_look  = $mvweb_block['look'];
$mvweb_view  = $mvweb_block['mod'];
$mvweb_rv    = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_inner = in_array( $mvweb_view, array( 'column', 'letter' ), true );

$mvweb_value = static function ( $key ) use ( $mvweb_props ) {
	return isset( $mvweb_props[ $key ] ) ? trim( (string) $mvweb_props[ $key ] ) : '';
};

$mvweb_text = '';

if ( in_array( 'text', $mvweb_parts, true ) ) {
	$mvweb_raw  = $mvweb_value( 'text' );
	$mvweb_text = '' !== $mvweb_raw ? wp_kses_post( wpautop( $mvweb_raw ) ) : trim( (string) apply_filters( 'the_content', get_post_field( 'post_content', get_the_ID() ) ) );
}

$mvweb_image = static function ( $key ) use ( $mvweb_props, $mvweb_parts ) {
	$id = isset( $mvweb_props[ $key ] ) ? absint( $mvweb_props[ $key ] ) : 0;

	return $id > 0 && in_array( $key, $mvweb_parts, true ) ? wp_get_attachment_image( $id, 'large', false, array( 'loading' => 'lazy' ) ) : '';
};

$mvweb_button = '';

if ( in_array( 'button', $mvweb_parts, true ) && '' !== $mvweb_value( 'button_text' ) && '' !== $mvweb_value( 'button_url' ) ) {
	$mvweb_kinds  = array(
		'secondary' => ' mvweb-t-btn--outline',
		'link'      => ' mvweb-t-btn--link',
	);
	$mvweb_kind   = isset( $mvweb_kinds[ $mvweb_look['button_kind'] ] ) ? $mvweb_kinds[ $mvweb_look['button_kind'] ] : '';
	$mvweb_label  = esc_html( $mvweb_value( 'button_text' ) );
	$mvweb_label  = in_array( $mvweb_view, array( 'cover', 'mosaic' ), true ) ? '<span>' . $mvweb_label . '</span>' . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) : $mvweb_label;
	$mvweb_button = '<div class="mvweb-t-content__actions"><a class="mvweb-t-btn' . $mvweb_kind . '" href="' . esc_url( $mvweb_value( 'button_url' ) ) . '">' . $mvweb_label . '</a></div>';
}

$mvweb_renderers = array(
	'text'   => static function () use ( $mvweb_text, $mvweb_inner, $mvweb_rv ) {
		if ( '' !== $mvweb_text ) {
			echo '<div class="mvweb-t-prose"' . ( $mvweb_inner ? $mvweb_rv : '' ) . '>' . $mvweb_text . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Filtered text of the editor or of the entry.
		}
	},
	'button' => static function () use ( $mvweb_button ) {
		echo $mvweb_button; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	},
);

ob_start();
mvweb_theme_render_parts( $mvweb_block, $mvweb_renderers, array( 'rv' => $mvweb_inner ) );
$mvweb_body = trim( (string) ob_get_clean() );

$mvweb_photo  = $mvweb_image( 'image' );
$mvweb_photo2 = $mvweb_image( 'image_2' );
$mvweb_badge  = '';

if ( in_array( 'badge', $mvweb_parts, true ) && ( '' !== $mvweb_value( 'badge_title' ) || '' !== $mvweb_value( 'badge_text' ) ) ) {
	$mvweb_badge = '<div class="mvweb-t-content__badge">'
		. ( '' !== $mvweb_value( 'badge_icon' ) ? '<span class="mvweb-t-content__badge-icon">' . mvweb_theme_icon( $mvweb_value( 'badge_icon' ) ) . '</span>' : '' )
		. '<span class="mvweb-t-content__badge-text">'
		. ( '' !== $mvweb_value( 'badge_title' ) ? '<strong>' . esc_html( $mvweb_value( 'badge_title' ) ) . '</strong>' : '' )
		. ( '' !== $mvweb_value( 'badge_text' ) ? '<span>' . esc_html( $mvweb_value( 'badge_text' ) ) . '</span>' : '' )
		. '</span></div>';
}

$mvweb_quote = '';

if ( in_array( 'quote', $mvweb_parts, true ) && '' !== $mvweb_value( 'quote' ) ) {
	$mvweb_quote = '<figure class="mvweb-t-content__pull"' . $mvweb_rv . '><blockquote><p>' . esc_html( $mvweb_value( 'quote' ) ) . '</p></blockquote>'
		. ( '' !== $mvweb_value( 'quote_cite' ) ? '<figcaption>' . esc_html( $mvweb_value( 'quote_cite' ) ) . '</figcaption>' : '' )
		. '</figure>';
}

$mvweb_extra = '';

if ( in_array( $mvweb_view, array( 'float', 'mosaic', 'cover' ), true ) && 'm' !== $mvweb_look['image_size'] ) {
	$mvweb_extra .= ' mvweb-t-content--img-' . sanitize_html_class( $mvweb_look['image_size'] );
}

if ( in_array( $mvweb_view, array( 'float', 'mosaic' ), true ) && 'start' === $mvweb_look['image_side'] ) {
	$mvweb_extra .= ' mvweb-t-content--start';
}

if ( '' === $mvweb_body && '' === $mvweb_photo && '' === $mvweb_photo2 && '' === $mvweb_quote ) {
	return;
}

mvweb_theme_section_open( $mvweb_block, true, trim( $mvweb_extra ) );
?>
<?php if ( 'float' === $mvweb_view ) : ?>
	<div class="mvweb-t-content__split">
		<?php if ( '' !== $mvweb_photo ) : ?>
			<figure class="mvweb-t-content__media"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
				<div class="mvweb-t-content__frame"><?php echo $mvweb_photo; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the attachment image. ?></div>
				<?php echo $mvweb_badge; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
			</figure>
		<?php endif; ?>
		<?php if ( '' !== $mvweb_body ) : ?>
			<div class="mvweb-t-content__body"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
				<?php echo $mvweb_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part renderers above. ?>
			</div>
		<?php endif; ?>
	</div>
<?php elseif ( 'cover' === $mvweb_view ) : ?>
	<div class="mvweb-t-content__cover">
		<?php if ( '' !== $mvweb_photo ) : ?>
			<div class="mvweb-t-content__photo"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>><?php echo $mvweb_photo; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the attachment image. ?></div>
		<?php endif; ?>
		<?php if ( '' !== $mvweb_body ) : ?>
			<div class="mvweb-t-content__plate"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
				<?php echo $mvweb_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part renderers above. ?>
			</div>
		<?php endif; ?>
	</div>
<?php elseif ( 'mosaic' === $mvweb_view ) : ?>
	<div class="mvweb-t-content__split">
		<?php if ( '' !== $mvweb_body ) : ?>
			<div class="mvweb-t-content__body"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
				<?php echo $mvweb_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part renderers above. ?>
			</div>
		<?php endif; ?>
		<?php if ( '' !== $mvweb_photo || '' !== $mvweb_photo2 ) : ?>
			<div class="mvweb-t-content__mosaic">
				<?php if ( '' !== $mvweb_photo ) : ?>
					<figure class="mvweb-t-content__tile mvweb-t-content__tile--tall"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>><?php echo $mvweb_photo; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the attachment image. ?></figure>
				<?php endif; ?>
				<?php if ( '' !== $mvweb_photo2 ) : ?>
					<figure class="mvweb-t-content__tile mvweb-t-content__tile--square"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>><?php echo $mvweb_photo2; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the attachment image. ?></figure>
				<?php endif; ?>
			</div>
		<?php endif; ?>
	</div>
<?php elseif ( 'letter' === $mvweb_view ) : ?>
	<?php
	if ( in_array( 'title', $mvweb_parts, true ) ) {
		mvweb_theme_head( $mvweb_block, array( 'title' ), array( 'rv' => true ) );
	}
	?>
	<?php if ( '' !== $mvweb_text || '' !== $mvweb_quote ) : ?>
		<div class="mvweb-t-content__letter">
			<?php
			if ( '' !== $mvweb_text ) {
				call_user_func( $mvweb_renderers['text'] );
			}

			echo $mvweb_quote; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
			?>
		</div>
	<?php endif; ?>
	<?php echo $mvweb_button; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?>
<?php else : ?>
	<?php echo $mvweb_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part renderers above. ?>
<?php endif; ?>
<?php
mvweb_theme_section_close();
