<?php
/**
 * Section template: plans side by side.
 *
 * Five views: three cards, plans in rows, coloured headers, steps, and cards
 * with a monthly or yearly price. The head, the switch and the plans come in
 * the order the composition sets; a plan prints its badge, name, price and the
 * rest the same way in the card views, while rows and coloured headers keep
 * their own order and only hide what is switched off. A part without data is
 * not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'plans', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_plans = array();

if ( isset( $mvweb_block['props']['plans'] ) && is_array( $mvweb_block['props']['plans'] ) ) {
	foreach ( mvweb_core_visible_rows( $mvweb_block['props']['plans'] ) as $mvweb_row ) {
		if ( '' !== trim( (string) $mvweb_row['title'] ) || '' !== trim( (string) $mvweb_row['price'] ) || '' !== trim( (string) $mvweb_row['items'] ) ) {
			$mvweb_plans[] = $mvweb_row;
		}
	}
}

if ( empty( $mvweb_plans ) ) {
	return;
}

$mvweb_view   = $mvweb_block['mod'];
$mvweb_props  = $mvweb_block['props'];
$mvweb_motion = '' !== $mvweb_block['motion'];
$mvweb_rv     = $mvweb_motion ? ' data-rv' : '';
$mvweb_dir    = $mvweb_motion && 'steps' === $mvweb_view ? ' data-rv-dir="-1"' : '';
$mvweb_yearly = false;

foreach ( $mvweb_plans as $mvweb_row ) {
	if ( '' !== trim( (string) $mvweb_row['price_year'] ) ) {
		$mvweb_yearly = true;
		break;
	}
}

$mvweb_item_parts = array(
	'badge'  => static function ( $plan ) {
		if ( '' !== trim( (string) $plan['badge'] ) ) {
			echo '<span class="mvweb-t-badge mvweb-t-plans__badge">' . esc_html( $plan['badge'] ) . '</span>';
		}
	},
	'name'   => static function ( $plan, $block ) {
		if ( '' === trim( (string) $plan['title'] ) ) {
			return;
		}

		$title = '<div class="mvweb-t-plans__name mvweb-t-h3">' . esc_html( $plan['title'] ) . '</div>';

		echo in_array( $block['mod'], array( 'table', 'color' ), true ) ? $title : '<div class="mvweb-t-plans__head">' . $title . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	},
	'text'   => static function ( $plan ) {
		if ( '' !== trim( (string) $plan['text'] ) ) {
			echo '<p class="mvweb-t-plans__text">' . esc_html( $plan['text'] ) . '</p>';
		}
	},
	'price'  => static function ( $plan, $block ) {
		if ( '' === trim( (string) $plan['price'] ) ) {
			return;
		}

		if ( 'toggle' !== $block['mod'] ) {
			echo '<p class="mvweb-t-plans__price"><span class="mvweb-t-plans__amount">' . esc_html( $plan['price'] ) . '</span>' . ( '' !== trim( (string) $plan['unit'] ) ? '<span class="mvweb-t-plans__unit">' . esc_html( $plan['unit'] ) . '</span>' : '' ) . '</p>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.

			return;
		}

		$period = static function ( $modifier, $amount, $unit, $note ) {
			return '<p class="mvweb-t-plans__period mvweb-t-plans__period--' . esc_attr( $modifier ) . '"><span class="mvweb-t-plans__amount">' . esc_html( $amount ) . '</span>' . ( '' !== trim( (string) $unit ) ? '<span class="mvweb-t-plans__unit">' . esc_html( $unit ) . '</span>' : '' ) . ( '' !== trim( (string) $note ) ? '<span class="mvweb-t-plans__save">' . esc_html( $note ) . '</span>' : '' ) . '</p>';
		};
		$yearly = '' !== trim( (string) $plan['price_year'] );
		$html   = $period( $yearly ? 'month' : 'month mvweb-t-plans__period--both', $plan['price'], $plan['unit'], $plan['note_month'] );

		if ( $yearly ) {
			$unit  = '' === trim( (string) $plan['unit_year'] ) ? $plan['unit'] : $plan['unit_year'];
			$html .= $period( 'year', $plan['price_year'], $unit, $plan['note_year'] );
		}

		echo '<div class="mvweb-t-plans__prices">' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	},
	'items'  => static function ( $plan ) {
		$lines = mvweb_core_text_lines( $plan['items'] );

		if ( empty( $lines ) ) {
			return;
		}

		echo '<ul class="mvweb-t-plans__list">';

		foreach ( $lines as $line ) {
			$off  = (bool) preg_match( '/^[-\x{2212}\x{2013}\x{2014}]\s*(.*)$/u', $line, $match );
			$text = $off ? $match[1] : $line;

			echo '<li class="mvweb-t-plans__item' . ( $off ? ' mvweb-t-plans__item--off' : '' ) . '">' . mvweb_theme_icon( $off ? 'minus' : 'check' ) . '<span>' . esc_html( $text ) . '</span></li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
		}

		echo '</ul>';
	},
	'button' => static function ( $plan, $block ) {
		if ( '' === trim( (string) $plan['button_text'] ) || '' === trim( (string) $plan['button_url'] ) ) {
			return;
		}

		$class = 'mvweb-t-btn' . ( '' === trim( (string) $plan['badge'] ) ? ' mvweb-t-btn--outline' : '' ) . ( 'table' === $block['mod'] ? '' : ' mvweb-t-btn--block' );

		echo '<a class="' . esc_attr( $class ) . '" href="' . esc_url( $plan['button_url'] ) . '">' . esc_html( $plan['button_text'] ) . '</a>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
	},
);

$mvweb_collect = static function ( array $block, array $plan, array $slugs ) use ( $mvweb_item_parts ) {
	$block['item_parts'] = array_values( array_intersect( array( 'name', 'text', 'price', 'badge', 'items', 'button' ), $block['item_parts'], $slugs ) );

	ob_start();
	mvweb_theme_render_item_parts( $block, $plan, $mvweb_item_parts );

	return (string) ob_get_clean();
};

$mvweb_card = static function ( $plan, $block ) use ( $mvweb_collect, $mvweb_item_parts, $mvweb_rv, $mvweb_dir ) {
	$view     = $block['mod'];
	$featured = '' !== trim( (string) $plan['badge'] );

	if ( 'table' === $view ) {
		$name  = $mvweb_collect( $block, $plan, array( 'name' ) );
		$badge = $mvweb_collect( $block, $plan, array( 'badge' ) );
		$text  = $mvweb_collect( $block, $plan, array( 'text' ) );
		$wrap  = '' !== $name . $badge ? '<div class="mvweb-t-plans__namewrap">' . $name . $badge . '</div>' : '';
		$main  = '' !== $wrap . $text ? '<div class="mvweb-t-plans__main">' . $wrap . $text . '</div>' : '';
		$html  = $main . $mvweb_collect( $block, $plan, array( 'price' ) ) . $mvweb_collect( $block, $plan, array( 'items' ) ) . $mvweb_collect( $block, $plan, array( 'button' ) );

		return '' === $html ? '' : '<article class="mvweb-t-plans__row' . ( $featured ? ' mvweb-t-plans__row--featured' : '' ) . '"' . $mvweb_rv . '>' . $html . '</article>';
	}

	if ( 'color' === $view ) {
		$head = $mvweb_collect( $block, $plan, array( 'name', 'text', 'price', 'badge' ) );
		$body = $mvweb_collect( $block, $plan, array( 'items', 'button' ) );
		$html = ( '' !== $head ? '<div class="mvweb-t-plans__head">' . $head . '</div>' : '' ) . ( '' !== $body ? '<div class="mvweb-t-plans__body">' . $body . '</div>' : '' );

		return '' === $html ? '' : '<article class="mvweb-t-plans__card' . ( $featured ? ' mvweb-t-plans__card--featured' : '' ) . '"' . $mvweb_rv . '>' . $html . '</article>';
	}

	ob_start();
	mvweb_theme_render_item_parts( $block, $plan, $mvweb_item_parts );
	$html = (string) ob_get_clean();

	return '' === $html ? '' : '<article class="mvweb-t-plans__card' . ( $featured ? ' mvweb-t-plans__card--featured' : '' ) . '"' . $mvweb_rv . $mvweb_dir . '>' . $html . '</article>';
};

$mvweb_parts = array(
	'switch' => static function ( $block ) use ( $mvweb_yearly, $mvweb_rv ) {
		if ( 'toggle' !== $block['mod'] || ! $mvweb_yearly ) {
			return;
		}

		$props   = $block['props'];
		$id      = wp_unique_id( 'plans-period-' );
		$options = array(
			'month' => '' !== trim( (string) $props['period_month'] ) ? $props['period_month'] : __( 'Monthly', 'brand-market' ),
			'year'  => '' !== trim( (string) $props['period_year'] ) ? $props['period_year'] : __( 'Yearly', 'brand-market' ),
		);
		?>
		<div class="mvweb-t-plans__switch" role="radiogroup" aria-label="<?php esc_attr_e( 'Billing period', 'brand-market' ); ?>"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Fixed attribute. ?>>
			<?php foreach ( $options as $key => $label ) : ?>
				<input class="screen-reader-text" type="radio" name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id . '-' . $key ); ?>" value="<?php echo esc_attr( $key ); ?>"<?php echo 'month' === $key ? ' checked' : ''; ?>>
				<label class="mvweb-t-plans__switch-item" for="<?php echo esc_attr( $id . '-' . $key ); ?>"><?php echo esc_html( $label ); ?><?php echo 'year' === $key && '' !== trim( (string) $props['period_year_note'] ) ? ' <span class="mvweb-t-plans__switch-note">' . esc_html( $props['period_year_note'] ) . '</span>' : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?></label>
			<?php endforeach; ?>
		</div>
		<?php
	},
	'list'   => static function ( $block ) use ( $mvweb_plans, $mvweb_card ) {
		$count = max( 2, min( 4, count( $mvweb_plans ) ) );
		$html  = '';

		foreach ( $mvweb_plans as $plan ) {
			$html .= $mvweb_card( $plan, $block );
		}

		if ( '' === $html ) {
			return;
		}

		echo 'table' === $block['mod'] ? '<div class="mvweb-t-plans__rows">' . $html . '</div>' : '<div class="mvweb-t-plans__grid mvweb-t-plans__grid--' . (int) $count . '">' . $html . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped markup.
	},
);

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts( $mvweb_block, $mvweb_parts, array( 'rv' => true ) );
mvweb_theme_section_close();
