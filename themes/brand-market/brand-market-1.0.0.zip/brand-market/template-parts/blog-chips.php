<?php
/**
 * The strip of links above the entries: the categories of the blog or the latest months.
 *
 * Arguments: kind (topics or months).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_months = isset( $args['kind'] ) && 'months' === $args['kind'];
$mvweb_items  = $mvweb_months ? mvweb_core_blog_months() : mvweb_core_blog_topics();

if ( empty( $mvweb_items ) ) {
	return;
}
?>
<nav class="mvweb-t-chips mvweb-t-chips--scroll mvweb-t-blog__topics" aria-label="<?php echo $mvweb_months ? esc_attr__( 'Months', 'brand-market' ) : esc_attr__( 'Blog categories', 'brand-market' ); ?>">
	<?php foreach ( $mvweb_items as $mvweb_item ) : ?>
		<a class="mvweb-t-chip" href="<?php echo esc_url( $mvweb_item['url'] ); ?>"<?php echo $mvweb_item['current'] ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $mvweb_item['label'] ); ?></a>
	<?php endforeach; ?>
</nav>
