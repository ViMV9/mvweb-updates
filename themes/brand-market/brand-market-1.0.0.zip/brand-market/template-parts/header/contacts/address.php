<?php
/**
 * Part of the header contacts: the main address in one line.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_addresses = mvweb_theme_header_addresses( $args['contacts'] );

if ( empty( $mvweb_addresses ) ) {
	return;
}
?>
<div class="mvweb-t-hc__addr">
	<span class="mvweb-t-hc__addr-main">
		<?php echo mvweb_theme_icon( 'map-pin', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<span><?php echo esc_html( mvweb_theme_address_text( $mvweb_addresses[0] ) ); ?></span>
	</span>
</div>
