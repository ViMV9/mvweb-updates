<?php
/**
 * Work main column part: the photos of the work.
 *
 * Every picture is a link to its full file. The lightbox plugin opens such a
 * link on its own, so the theme carries no lightbox of its own here. The
 * strip of small pictures is there only when the work has more than one.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id     = absint( $args['id'] );
$mvweb_images = mvweb_core_item_gallery( $mvweb_id );

if ( empty( $mvweb_images ) ) {
	return;
}

$mvweb_title = get_the_title( $mvweb_id );
?>
<div class="mvweb-t-service__media">
	<div class="mvweb-t-pgallery mvweb-t-pgallery--wide">
		<?php if ( count( $mvweb_images ) > 1 ) : ?>
			<div class="mvweb-t-pgallery__thumbs">
				<?php foreach ( $mvweb_images as $mvweb_index => $mvweb_image ) : ?>
					<a class="mvweb-t-pgallery__thumb" href="<?php echo esc_url( (string) wp_get_attachment_image_url( $mvweb_image, 'full' ) ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %d: number of the photo. */ __( 'Photo %d', 'brand-market' ), $mvweb_index + 1 ) ); ?>">
						<?php
						echo wp_get_attachment_image(
							$mvweb_image,
							'medium',
							false,
							array(
								'alt'      => '',
								'loading'  => 'lazy',
								'decoding' => 'async',
							)
						);
						?>
					</a>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
		<div class="mvweb-t-pgallery__main">
			<a class="mvweb-t-pgallery__zoom" href="<?php echo esc_url( (string) wp_get_attachment_image_url( $mvweb_images[0], 'full' ) ); ?>">
				<?php
				echo wp_get_attachment_image(
					$mvweb_images[0],
					'mvweb_wide',
					false,
					array(
						'class'         => 'mvweb-t-pgallery__img',
						'alt'           => mvweb_core_image_alt( $mvweb_images[0], $mvweb_title ),
						'fetchpriority' => 'high',
						'decoding'      => 'async',
					)
				);
				?>
			</a>
		</div>
	</div>
</div>
