<?php
/**
 * Work main column part: the review of the client.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id     = absint( $args['id'] );
$mvweb_review = trim( (string) get_post_meta( $mvweb_id, '_mvweb_review', true ) );
$mvweb_author = trim( (string) get_post_meta( $mvweb_id, '_mvweb_review_author', true ) );
$mvweb_source = trim( (string) get_post_meta( $mvweb_id, '_mvweb_review_source', true ) );

if ( '' === $mvweb_review ) {
	return;
}
?>
<figure class="mvweb-t-work__review">
	<span class="mvweb-t-work__review-mark"><?php echo mvweb_theme_icon( 'quote' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
	<blockquote><?php echo wp_kses_post( wpautop( esc_html( $mvweb_review ) ) ); ?></blockquote>
	<?php if ( '' !== $mvweb_author || '' !== $mvweb_source ) : ?>
		<figcaption>
			<?php if ( '' !== $mvweb_author ) : ?>
				<strong><?php echo esc_html( $mvweb_author ); ?></strong>
			<?php endif; ?>
			<?php if ( '' !== $mvweb_source ) : ?>
				<span><?php echo esc_html( $mvweb_source ); ?></span>
			<?php endif; ?>
		</figcaption>
	<?php endif; ?>
</figure>
