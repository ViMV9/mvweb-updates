<?php
/**
 * Work main column part: the text written in the editor.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_content = mvweb_core_item_content( absint( $args['id'] ) );

if ( '' === $mvweb_content ) {
	return;
}
?>
<div class="mvweb-t-prose mvweb-t-service__story" data-prose>
	<?php echo $mvweb_content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Passed through the_content, which closes with kses for an author without unfiltered_html. ?>
</div>
