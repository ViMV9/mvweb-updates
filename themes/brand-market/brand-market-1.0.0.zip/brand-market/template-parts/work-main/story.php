<?php
/**
 * Work main column part: the task and the result.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id    = absint( $args['id'] );
$mvweb_parts = array(
	__( 'Task', 'brand-market' )   => trim( (string) get_post_meta( $mvweb_id, '_mvweb_task', true ) ),
	__( 'Result', 'brand-market' ) => trim( (string) get_post_meta( $mvweb_id, '_mvweb_result', true ) ),
);
$mvweb_parts = array_filter( $mvweb_parts, 'strlen' );

if ( empty( $mvweb_parts ) ) {
	return;
}
?>
<div class="mvweb-t-work__story">
	<?php foreach ( $mvweb_parts as $mvweb_label => $mvweb_text ) : ?>
		<div class="mvweb-t-work__story-part">
			<div class="mvweb-t-work__story-title mvweb-t-h2"><?php echo esc_html( $mvweb_label ); ?></div>
			<?php echo wp_kses_post( wpautop( esc_html( $mvweb_text ) ) ); ?>
		</div>
	<?php endforeach; ?>
</div>
