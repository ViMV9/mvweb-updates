<?php
/**
 * Under the title of a post, part: the author with the position.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_author = (int) get_post_field( 'post_author', get_the_ID() );
$mvweb_name   = trim( (string) get_the_author_meta( 'display_name', $mvweb_author ) );

if ( 0 === $mvweb_author || '' === $mvweb_name ) {
	return;
}

$mvweb_role = mvweb_core_author_role( $mvweb_author );
?>
<a class="mvweb-t-post__byline" href="<?php echo esc_url( get_author_posts_url( $mvweb_author ) ); ?>">
	<?php echo get_avatar( $mvweb_author, 88, '', '', array( 'class' => 'mvweb-t-avatar' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag. ?>
	<span>
		<strong><?php echo esc_html( $mvweb_name ); ?></strong>
		<?php if ( '' !== $mvweb_role ) : ?>
			<small><?php echo esc_html( $mvweb_role ); ?></small>
		<?php endif; ?>
	</span>
</a>
