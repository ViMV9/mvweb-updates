<?php
/**
 * Under the title of a post, part: the cover.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! has_post_thumbnail() ) {
	return;
}
?>
<figure class="mvweb-t-post__cover">
	<?php the_post_thumbnail( 'large', array( 'fetchpriority' => 'high' ) ); ?>
</figure>
