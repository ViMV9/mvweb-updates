<?php
/**
 * Under the title of a post, part: the excerpt written by hand.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_lead = has_excerpt() ? trim( wp_strip_all_tags( get_the_excerpt() ) ) : '';

if ( '' === $mvweb_lead ) {
	return;
}
?>
<p class="mvweb-t-post__lead"><?php echo esc_html( $mvweb_lead ); ?></p>
