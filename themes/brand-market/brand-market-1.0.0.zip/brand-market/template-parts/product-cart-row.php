<?php
/**
 * The row of the add to cart form: the quantity stepper, the button, the favourites heart and the compare button.
 *
 * Shared by the simple product form and the button of a variable product, so
 * both dress the hooks of WooCommerce the same way.
 *
 * Arguments: product (WC_Product), name and value of the submit button (empty
 * when the form carries them in hidden fields).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_product = isset( $args['product'] ) ? $args['product'] : null;

if ( ! $mvweb_product instanceof WC_Product ) {
	return;
}

$mvweb_args = wc_get_quantity_input_args(
	array(
		'input_value' => isset( $_POST['quantity'] ) ? wc_stock_amount( sanitize_text_field( wp_unslash( $_POST['quantity'] ) ) ) : $mvweb_product->get_min_purchase_quantity(), // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Echoes the quantity of a failed add to cart back into the field, as the WooCommerce template does.
	),
	$mvweb_product
);
$mvweb_only = '' !== $mvweb_args['max_value'] && $mvweb_args['min_value'] === $mvweb_args['max_value'];
$mvweb_fav  = function_exists( 'mvweb_core_favorites_url' ) && '' !== mvweb_core_favorites_url();
$mvweb_name = isset( $args['name'] ) ? (string) $args['name'] : '';
$mvweb_cmp  = mvweb_core_layout_has( 'product-purchase', 'compare' ) ? mvweb_theme_compare_button( $mvweb_product->get_id() ) : '';
?>
<div class="mvweb-t-product-cart__row">
	<?php do_action( 'woocommerce_before_add_to_cart_quantity' ); ?>

	<?php if ( $mvweb_only ) : ?>
		<input type="hidden" name="<?php echo esc_attr( $mvweb_args['input_name'] ); ?>" value="<?php echo esc_attr( $mvweb_args['min_value'] ); ?>">
	<?php else : ?>
		<div class="mvweb-t-qty" data-qty>
			<button class="mvweb-t-qty__btn" type="button" data-qty-minus title="<?php esc_attr_e( 'Less', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'minus', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Less', 'brand-market' ); ?></span>
			</button>
			<input
				class="mvweb-t-qty__input qty"
				type="text"
				inputmode="<?php echo esc_attr( $mvweb_args['inputmode'] ); ?>"
				id="<?php echo esc_attr( $mvweb_args['input_id'] ); ?>"
				name="<?php echo esc_attr( $mvweb_args['input_name'] ); ?>"
				value="<?php echo esc_attr( $mvweb_args['input_value'] ); ?>"
				autocomplete="off"
				data-qty-input
				data-qty-min="<?php echo esc_attr( $mvweb_args['min_value'] ); ?>"
				data-qty-max="<?php echo esc_attr( $mvweb_args['max_value'] ); ?>"
				data-qty-step="<?php echo esc_attr( $mvweb_args['step'] ); ?>"
				aria-label="<?php esc_attr_e( 'Quantity', 'brand-market' ); ?>"
			>
			<button class="mvweb-t-qty__btn" type="button" data-qty-plus title="<?php esc_attr_e( 'More', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'plus', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'More', 'brand-market' ); ?></span>
			</button>
		</div>
	<?php endif; ?>

	<?php do_action( 'woocommerce_after_add_to_cart_quantity' ); ?>

	<button class="mvweb-t-btn mvweb-t-product-cart__add single_add_to_cart_button" type="submit"<?php echo '' !== $mvweb_name ? ' name="' . esc_attr( $mvweb_name ) . '" value="' . esc_attr( $mvweb_product->get_id() ) . '"' : ''; ?>>
		<?php echo mvweb_theme_icon( 'shopping-cart', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<?php echo esc_html( $mvweb_product->single_add_to_cart_text() ); ?>
	</button>

	<?php if ( $mvweb_fav ) : ?>
		<button class="mvweb-t-round mvweb-t-round--line mvweb-t-product-cart__fav" type="button" data-fav-toggle="<?php echo (int) $mvweb_product->get_id(); ?>" aria-pressed="false" title="<?php esc_attr_e( 'Add to favourites', 'brand-market' ); ?>">
			<?php echo mvweb_theme_icon( 'heart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span class="screen-reader-text" data-fav-label><?php esc_html_e( 'Add to favourites', 'brand-market' ); ?></span>
		</button>
	<?php endif; ?>

	<?php echo $mvweb_cmp; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
</div>
