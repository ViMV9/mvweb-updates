<?php
/**
 * Checkout, step: how and where the goods go.
 *
 * The methods of delivery, the address fields of the billing form and, when
 * the goods go elsewhere, the shipping address.
 *
 * Arguments: number.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_checkout = WC()->checkout();
$mvweb_number   = isset( $args['number'] ) ? (int) $args['number'] : 2;
$mvweb_address  = mvweb_theme_address_keys();
$mvweb_fields   = array_intersect_key( $mvweb_checkout->get_checkout_fields( 'billing' ), array_flip( $mvweb_address ) );
$mvweb_ships    = WC()->cart->needs_shipping();
?>
<fieldset class="mvweb-t-step">
	<legend class="mvweb-t-step__title"><span class="mvweb-t-step__num"><?php echo (int) $mvweb_number; ?></span><?php echo $mvweb_ships ? esc_html__( 'Delivery', 'brand-market' ) : esc_html__( 'Address', 'brand-market' ); ?></legend>
	<?php get_template_part( 'template-parts/checkout/shipping-choices' ); ?>
	<?php if ( ! empty( $mvweb_fields ) ) : ?>
		<div class="mvweb-t-step__grid woocommerce-billing-fields__field-wrapper">
			<?php
			foreach ( $mvweb_fields as $mvweb_key => $mvweb_field ) {
				woocommerce_form_field( $mvweb_key, $mvweb_field, $mvweb_checkout->get_value( $mvweb_key ) );
			}
			?>
		</div>
	<?php endif; ?>
	<?php wc_get_template( 'checkout/form-shipping.php', array( 'checkout' => $mvweb_checkout ) ); ?>
	<?php do_action( 'woocommerce_checkout_shipping' ); ?>
</fieldset>
