<?php
/**
 * Checkout heading, part: a word about the protected connection.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! is_ssl() ) {
	return;
}
?>
<span><?php echo mvweb_theme_icon( 'lock', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?><?php esc_html_e( 'The data goes over a protected connection', 'brand-market' ); ?></span>
