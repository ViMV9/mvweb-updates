<?php
/**
 * Checkout heading, part: the link for a returning customer.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( is_user_logged_in() || 'yes' !== get_option( 'woocommerce_enable_checkout_login_reminder' ) ) {
	return;
}
?>
<span><?php esc_html_e( 'Bought here before?', 'brand-market' ); ?> <a href="<?php echo esc_url( wc_get_page_permalink( 'myaccount' ) ); ?>"><?php esc_html_e( 'Sign in', 'brand-market' ); ?></a></span>
