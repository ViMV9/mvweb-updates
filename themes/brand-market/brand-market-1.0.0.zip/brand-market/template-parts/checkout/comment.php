<?php
/**
 * Checkout, step: the wishes of the customer for the order.
 *
 * Arguments: number.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_checkout = WC()->checkout();
$mvweb_number   = isset( $args['number'] ) ? (int) $args['number'] : 4;
$mvweb_fields   = apply_filters( 'woocommerce_enable_order_notes_field', 'yes' === get_option( 'woocommerce_enable_order_comments', 'yes' ) ) ? $mvweb_checkout->get_checkout_fields( 'order' ) : array(); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.

if ( empty( $mvweb_fields ) ) {
	return;
}
?>
<fieldset class="mvweb-t-step woocommerce-additional-fields">
	<legend class="mvweb-t-step__title"><span class="mvweb-t-step__num"><?php echo (int) $mvweb_number; ?></span><?php esc_html_e( 'Comment', 'brand-market' ); ?></legend>
	<?php do_action( 'woocommerce_before_order_notes', $mvweb_checkout ); ?>
	<div class="woocommerce-additional-fields__field-wrapper">
		<?php
		foreach ( $mvweb_fields as $mvweb_key => $mvweb_field ) {
			woocommerce_form_field( $mvweb_key, $mvweb_field, $mvweb_checkout->get_value( $mvweb_key ) );
		}
		?>
	</div>
	<?php do_action( 'woocommerce_after_order_notes', $mvweb_checkout ); ?>
</fieldset>
