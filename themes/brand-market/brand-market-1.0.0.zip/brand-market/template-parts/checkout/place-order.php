<?php
/**
 * Checkout summary: the agreement and the button that places the order.
 *
 * It stands in the summary beside the steps, not in the payment step, so it
 * is printed once and WooCommerce's script never has to replace it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_text = apply_filters( 'woocommerce_order_button_text', __( 'Confirm the order', 'brand-market' ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
?>
<div class="form-row place-order">
	<noscript>
		<?php
		/* translators: 1, 2: opening and closing emphasis tags. */
		printf( esc_html__( 'Your browser does not run scripts. Press %1$sUpdate totals%2$s before placing the order, or the amount may differ.', 'brand-market' ), '<em>', '</em>' );
		?>
		<br><button type="submit" class="mvweb-t-btn mvweb-t-btn--outline" name="woocommerce_checkout_update_totals" value="<?php esc_attr_e( 'Update totals', 'brand-market' ); ?>"><?php esc_html_e( 'Update totals', 'brand-market' ); ?></button>
	</noscript>
	<?php wc_get_template( 'checkout/terms.php' ); ?>
	<?php do_action( 'woocommerce_review_order_before_submit' ); ?>
	<?php echo apply_filters( 'woocommerce_order_button_html', '<button type="submit" class="mvweb-t-btn mvweb-t-btn--block mvweb-t-btn--lg" name="woocommerce_checkout_place_order" id="place_order" value="' . esc_attr( $mvweb_text ) . '" data-value="' . esc_attr( $mvweb_text ) . '">' . esc_html( $mvweb_text ) . '</button>' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped,WooCommerce.Commenting.CommentHooks.MissingHookComment -- Escaped above; hook of WooCommerce. ?>
	<?php do_action( 'woocommerce_review_order_after_submit' ); ?>
	<?php wp_nonce_field( 'woocommerce-process_checkout', 'woocommerce-process-checkout-nonce' ); ?>
</div>
