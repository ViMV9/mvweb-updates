<?php
/**
 * Checkout, step: who the order is for.
 *
 * Takes the billing fields that are not part of an address, and the
 * fields of a new account.
 *
 * Arguments: number.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_checkout = WC()->checkout();
$mvweb_number   = isset( $args['number'] ) ? (int) $args['number'] : 1;
$mvweb_address  = mvweb_theme_address_keys();
?>
<fieldset class="mvweb-t-step woocommerce-billing-fields">
	<legend class="mvweb-t-step__title"><span class="mvweb-t-step__num"><?php echo (int) $mvweb_number; ?></span><?php esc_html_e( 'Contacts', 'brand-market' ); ?></legend>
	<?php do_action( 'woocommerce_before_checkout_billing_form', $mvweb_checkout ); ?>
	<div class="mvweb-t-step__grid woocommerce-billing-fields__field-wrapper">
		<?php
		foreach ( $mvweb_checkout->get_checkout_fields( 'billing' ) as $mvweb_key => $mvweb_field ) {
			if ( ! in_array( $mvweb_key, $mvweb_address, true ) ) {
				woocommerce_form_field( $mvweb_key, $mvweb_field, $mvweb_checkout->get_value( $mvweb_key ) );
			}
		}
		?>
	</div>
	<?php do_action( 'woocommerce_after_checkout_billing_form', $mvweb_checkout ); ?>
	<?php if ( ! is_user_logged_in() && $mvweb_checkout->is_registration_enabled() ) : ?>
		<div class="woocommerce-account-fields">
			<?php if ( ! $mvweb_checkout->is_registration_required() ) : ?>
				<label class="mvweb-t-check woocommerce-form__label woocommerce-form__label-for-checkbox checkbox" for="createaccount">
					<input class="woocommerce-form__input woocommerce-form__input-checkbox input-checkbox" id="createaccount" <?php checked( ( true === $mvweb_checkout->get_value( 'createaccount' ) || ( true === apply_filters( 'woocommerce_create_account_default_checked', false ) ) ), true ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce. ?> type="checkbox" name="createaccount" value="1">
					<span><?php esc_html_e( 'Create an account', 'brand-market' ); ?></span>
				</label>
			<?php endif; ?>
			<?php do_action( 'woocommerce_before_checkout_registration_form', $mvweb_checkout ); ?>
			<?php if ( $mvweb_checkout->get_checkout_fields( 'account' ) ) : ?>
				<div class="create-account mvweb-t-step__grid">
					<?php
					foreach ( $mvweb_checkout->get_checkout_fields( 'account' ) as $mvweb_key => $mvweb_field ) {
						woocommerce_form_field( $mvweb_key, $mvweb_field, $mvweb_checkout->get_value( $mvweb_key ) );
					}
					?>
				</div>
			<?php endif; ?>
			<?php do_action( 'woocommerce_after_checkout_registration_form', $mvweb_checkout ); ?>
		</div>
	<?php endif; ?>
	<?php do_action( 'woocommerce_checkout_billing' ); ?>
</fieldset>
