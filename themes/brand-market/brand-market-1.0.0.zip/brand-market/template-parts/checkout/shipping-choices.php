<?php
/**
 * Checkout, delivery step: the methods to choose from.
 *
 * WooCommerce's checkout script replaces this element with the methods the
 * new address or the new cart allows.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! WC()->cart || ! WC()->cart->needs_shipping() ) {
	return;
}

$mvweb_packages = mvweb_theme_shipping_rates();
?>
<div class="mvweb-t-step__choices mvweb-t-shipping-choices">
	<?php if ( empty( $mvweb_packages ) ) : ?>
		<p class="mvweb-t-step__note"><?php esc_html_e( 'Enter the address to see the delivery methods.', 'brand-market' ); ?></p>
	<?php endif; ?>
	<?php foreach ( $mvweb_packages as $mvweb_package ) : ?>
		<?php foreach ( $mvweb_package['rates'] as $mvweb_rate ) : ?>
			<?php
			$mvweb_id   = 'shipping_method_' . $mvweb_package['index'] . '_' . sanitize_title( $mvweb_rate['id'] );
			$mvweb_hint = mvweb_core_shipping_hint( $mvweb_rate['id'], $mvweb_rate['method'] );
			?>
			<label class="mvweb-t-choice" for="<?php echo esc_attr( $mvweb_id ); ?>">
				<input type="radio" name="shipping_method[<?php echo (int) $mvweb_package['index']; ?>]" data-index="<?php echo (int) $mvweb_package['index']; ?>" id="<?php echo esc_attr( $mvweb_id ); ?>" value="<?php echo esc_attr( $mvweb_rate['id'] ); ?>" class="shipping_method" <?php checked( $mvweb_rate['id'], $mvweb_package['chosen'] ); ?>>
				<span class="mvweb-t-choice__icon"><?php echo mvweb_theme_icon( mvweb_core_shipping_icon( $mvweb_rate['method'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
				<span class="mvweb-t-choice__text">
					<strong><?php echo esc_html( $mvweb_rate['label'] ); ?></strong>
					<?php if ( '' !== $mvweb_hint ) : ?>
						<small><?php echo esc_html( $mvweb_hint ); ?></small>
					<?php endif; ?>
				</span>
				<span class="mvweb-t-choice__price"><?php echo $mvweb_rate['cost'] > 0 ? wp_kses_post( wc_price( $mvweb_rate['cost'] ) ) : esc_html__( 'Free', 'brand-market' ); ?></span>
			</label>
			<?php do_action( 'woocommerce_after_shipping_rate', $mvweb_rate['rate'], $mvweb_package['index'] ); ?>
		<?php endforeach; ?>
	<?php endforeach; ?>
</div>
