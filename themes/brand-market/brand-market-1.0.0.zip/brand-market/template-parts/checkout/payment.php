<?php
/**
 * Checkout, step: how to pay.
 *
 * Arguments: number.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_number = isset( $args['number'] ) ? (int) $args['number'] : 3;
?>
<fieldset class="mvweb-t-step">
	<legend class="mvweb-t-step__title"><span class="mvweb-t-step__num"><?php echo (int) $mvweb_number; ?></span><?php esc_html_e( 'Payment', 'brand-market' ); ?></legend>
	<?php woocommerce_checkout_payment(); ?>
</fieldset>
