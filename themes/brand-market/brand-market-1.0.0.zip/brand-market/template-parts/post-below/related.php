<?php
/**
 * Bands under a post, part: more posts.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_ids = mvweb_core_related_posts( get_the_ID(), absint( mvweb_core_blog_option( 'mvweb_post_related_count' ) ) );

if ( empty( $mvweb_ids ) ) {
	return;
}

$mvweb_title = trim( (string) mvweb_core_blog_option( 'mvweb_post_related_title' ) );
$mvweb_link  = trim( (string) mvweb_core_blog_option( 'mvweb_post_related_link' ) );
$mvweb_url   = mvweb_core_blog_url( get_the_ID() );

if ( '' === $mvweb_url ) {
	$mvweb_link = '';
}

$mvweb_query = new WP_Query(
	array(
		'post_type'           => 'post',
		'post_status'         => 'publish',
		'post__in'            => $mvweb_ids,
		'orderby'             => 'post__in',
		'posts_per_page'      => count( $mvweb_ids ),
		'ignore_sticky_posts' => true,
		'no_found_rows'       => true,
	)
);
?>
<section class="mvweb-t-section mvweb-t-section--tight mvweb-t-post-related" data-bg="surface">
	<div class="mvweb-t-container">
		<?php if ( '' !== $mvweb_title || '' !== $mvweb_link ) : ?>
			<div class="mvweb-t-section-head">
				<?php if ( '' !== $mvweb_title ) : ?>
					<div class="mvweb-t-section-head__text"><div class="mvweb-t-section-head__title mvweb-t-h2"><?php echo esc_html( $mvweb_title ); ?></div></div>
				<?php endif; ?>
				<?php if ( '' !== $mvweb_link ) : ?>
					<a class="mvweb-t-section-head__more" href="<?php echo esc_url( $mvweb_url ); ?>"><?php echo esc_html( $mvweb_link ); ?></a>
				<?php endif; ?>
			</div>
		<?php endif; ?>
		<div class="mvweb-t-posts__grid">
			<?php
			while ( $mvweb_query->have_posts() ) :
				$mvweb_query->the_post();

				get_template_part( 'template-parts/post-card' );
			endwhile;
			wp_reset_postdata();
			?>
		</div>
	</div>
</section>
