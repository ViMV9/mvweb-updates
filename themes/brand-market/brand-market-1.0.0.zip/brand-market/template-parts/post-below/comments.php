<?php
/**
 * Bands under a post, part: the comments.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( comments_open() || get_comments_number() ) {
	comments_template();
}
