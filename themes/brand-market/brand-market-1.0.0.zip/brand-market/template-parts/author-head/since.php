<?php
/**
 * Heading of an author archive, part: the year the author joined.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_user = get_userdata( isset( $args['author'] ) ? absint( $args['author'] ) : 0 );
$mvweb_year = $mvweb_user instanceof WP_User ? (int) mysql2date( 'Y', $mvweb_user->user_registered ) : 0;

if ( $mvweb_year < 1 ) {
	return;
}
?>
<span>
	<?php
	/* translators: %s: year. */
	echo esc_html( sprintf( __( 'With us since %s', 'brand-market' ), $mvweb_year ) );
	?>
</span>
