<?php
/**
 * Heading of an author archive, part: the description from the profile.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_bio = trim( (string) get_the_author_meta( 'description', isset( $args['author'] ) ? absint( $args['author'] ) : 0 ) );

if ( '' === $mvweb_bio ) {
	return;
}
?>
<p class="mvweb-t-page-hero__lead"><?php echo esc_html( $mvweb_bio ); ?></p>
