<?php
/**
 * Page head part: Breadcrumbs.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! empty( $args['above'] ) ) {
	return;
}

get_template_part( 'template-parts/crumbs' );
