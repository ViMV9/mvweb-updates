<?php
/**
 * Page head part: Heading, the one h1 of the page.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_eyebrow = isset( $args['eyebrow'] ) ? trim( (string) $args['eyebrow'] ) : '';
$mvweb_title   = isset( $args['title'] ) ? (string) $args['title'] : '';
$mvweb_count   = isset( $args['count'] ) ? trim( (string) $args['count'] ) : '';
?>
<?php if ( '' !== $mvweb_eyebrow ) : ?>
	<p class="mvweb-t-page-hero__eyebrow"><?php echo esc_html( $mvweb_eyebrow ); ?></p>
<?php endif; ?>

<?php if ( '' !== $mvweb_count ) : ?>
	<div class="mvweb-t-page-hero__head">
		<h1 class="mvweb-t-page-hero__title"><?php echo esc_html( $mvweb_title ); ?></h1>
		<p class="mvweb-t-page-hero__count"><?php echo esc_html( $mvweb_count ); ?></p>
	</div>
<?php else : ?>
	<h1 class="mvweb-t-page-hero__title"><?php echo esc_html( $mvweb_title ); ?></h1>
<?php endif; ?>
