<?php
/**
 * A badge of the footer: a caption over a picture or a text, as one link.
 *
 * The plate frames the caption and the picture or the text; the inline view
 * puts the picture beside the text without a frame.
 *
 * Shared by the studio and the partner. The title names the link: with a
 * picture it becomes the alt, without one it is the text of the link itself.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_class    = isset( $args['class'] ) ? (string) $args['class'] : '';
$mvweb_caption  = isset( $args['caption'] ) ? trim( (string) $args['caption'] ) : '';
$mvweb_url      = isset( $args['url'] ) ? trim( (string) $args['url'] ) : '';
$mvweb_title    = isset( $args['title'] ) ? trim( (string) $args['title'] ) : '';
$mvweb_image_id = isset( $args['image_id'] ) ? absint( $args['image_id'] ) : 0;
$mvweb_image    = isset( $args['image_url'] ) ? trim( (string) $args['image_url'] ) : '';
$mvweb_view     = isset( $args['view'] ) && 'inline' === $args['view'] ? 'inline' : 'plate';

if ( 0 === $mvweb_image_id && '' !== $mvweb_image ) {
	$mvweb_image_id = attachment_url_to_postid( $mvweb_image );
}

if ( ! wp_attachment_is_image( $mvweb_image_id ) ) {
	$mvweb_image_id = 0;
}

if ( '' === $mvweb_url || '' === $mvweb_title ) {
	return;
}
?>
<a class="<?php echo esc_attr( trim( 'mvweb-t-footer__badge mvweb-t-footer__badge--' . $mvweb_view . ' ' . $mvweb_class ) ); ?>" href="<?php echo esc_url( $mvweb_url ); ?>" rel="nofollow noopener" target="_blank" title="<?php echo esc_attr( $mvweb_title ); ?>">
	<?php if ( '' !== $mvweb_caption ) : ?>
		<small class="mvweb-t-footer__badge-caption"><?php echo esc_html( $mvweb_caption ); ?></small>
	<?php endif; ?>

	<?php if ( 0 !== $mvweb_image_id ) : ?>
		<?php
		echo wp_get_attachment_image(
			$mvweb_image_id,
			'medium',
			false,
			array(
				'class'    => 'mvweb-t-footer__badge-img',
				'alt'      => 'inline' === $mvweb_view ? '' : $mvweb_title,
				'loading'  => 'lazy',
				'decoding' => 'async',
			)
		);
		?>
	<?php elseif ( '' !== $mvweb_image ) : ?>
		<img class="mvweb-t-footer__badge-img" src="<?php echo esc_url( $mvweb_image ); ?>" alt="<?php echo esc_attr( 'inline' === $mvweb_view ? '' : $mvweb_title ); ?>" loading="lazy" decoding="async">
	<?php endif; ?>

	<?php if ( 'inline' === $mvweb_view || ( 0 === $mvweb_image_id && '' === $mvweb_image ) ) : ?>
		<span class="mvweb-t-footer__badge-text"><?php echo esc_html( $mvweb_title ); ?></span>
	<?php endif; ?>
</a>
