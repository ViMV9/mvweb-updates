<?php
/**
 * Footer contacts part: E-mail.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_contacts = isset( $args['contacts'] ) && is_array( $args['contacts'] ) ? $args['contacts'] : array();
$mvweb_email    = isset( $mvweb_contacts['email'] ) ? trim( (string) $mvweb_contacts['email'] ) : '';

if ( '' === $mvweb_email ) {
	return;
}
?>
<li class="mvweb-t-footer__item"><a class="mvweb-t-footer__mail" href="<?php echo esc_url( 'mailto:' . $mvweb_email ); ?>"><?php echo esc_html( $mvweb_email ); ?></a></li>
