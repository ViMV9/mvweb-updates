<?php
/**
 * Footer contacts part: Opening hours.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_contacts = isset( $args['contacts'] ) && is_array( $args['contacts'] ) ? $args['contacts'] : array();

foreach ( isset( $mvweb_contacts['hours'] ) ? (array) $mvweb_contacts['hours'] : array() as $mvweb_row ) :
	$mvweb_line = trim( $mvweb_row['days'] . ' ' . $mvweb_row['time'] );

	if ( '' === $mvweb_line ) {
		continue;
	}
	?>
	<li class="mvweb-t-footer__item"><?php echo esc_html( $mvweb_line ); ?></li>
	<?php
endforeach;
