<?php
/**
 * Footer contacts part: Phones.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_contacts = isset( $args['contacts'] ) && is_array( $args['contacts'] ) ? $args['contacts'] : array();
$mvweb_seen     = array();

$mvweb_captions = array(
	trim( (string) mvweb_cz_profile( 'phone' ) )       => trim( (string) mvweb_cz_get( 'mvweb_cz_phone_label' ) ),
	trim( (string) mvweb_cz_profile( 'phone_extra' ) ) => trim( (string) mvweb_cz_get( 'mvweb_cz_phone_extra_label' ) ),
);

foreach ( isset( $mvweb_contacts['phones'] ) ? (array) $mvweb_contacts['phones'] : array() as $mvweb_phone ) :
	$mvweb_number = trim( (string) $mvweb_phone['number'] );

	if ( '' === $mvweb_number || isset( $mvweb_seen[ $mvweb_number ] ) ) {
		continue;
	}

	$mvweb_seen[ $mvweb_number ] = true;

	$mvweb_label = trim( (string) $mvweb_phone['label'] );

	if ( '' === $mvweb_label && empty( $mvweb_contacts['branches'] ) && isset( $mvweb_captions[ $mvweb_number ] ) ) {
		$mvweb_label = $mvweb_captions[ $mvweb_number ];
	}

	$mvweb_href = (string) $mvweb_phone['href'];
	?>
	<li class="mvweb-t-footer__item">
		<?php if ( '' !== $mvweb_label ) : ?>
			<span class="mvweb-t-footer__note"><?php echo esc_html( $mvweb_label ); ?></span>
		<?php endif; ?>

		<?php if ( '' !== $mvweb_href ) : ?>
			<a class="mvweb-t-footer__phone" href="<?php echo esc_url( $mvweb_href ); ?>"><?php echo esc_html( $mvweb_number ); ?></a>
		<?php else : ?>
			<span class="mvweb-t-footer__phone"><?php echo esc_html( $mvweb_number ); ?></span>
		<?php endif; ?>
	</li>
	<?php
endforeach;
