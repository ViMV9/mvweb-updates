<?php
/**
 * Footer contacts part: Messengers.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_chats = mvweb_cz_profile_chats();

if ( empty( $mvweb_chats ) ) {
	return;
}
?>
<li class="mvweb-t-footer__item">
	<div class="mvweb-t-footer__socials">
		<?php foreach ( $mvweb_chats as $mvweb_id => $mvweb_link ) : ?>
			<a class="mvweb-t-round" href="<?php echo esc_url( $mvweb_link['url'] ); ?>" title="<?php echo esc_attr( $mvweb_link['label'] ); ?>" rel="noopener" target="_blank">
				<svg class="mvweb-t-icon" aria-hidden="true" focusable="false"><use href="#mvweb-t-icon-<?php echo esc_attr( mvweb_core_social_icon( $mvweb_id ) ); ?>"></use></svg>
				<span class="screen-reader-text"><?php echo esc_html( $mvweb_link['label'] ); ?></span>
			</a>
		<?php endforeach; ?>
	</div>
</li>
