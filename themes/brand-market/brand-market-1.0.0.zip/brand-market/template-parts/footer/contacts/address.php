<?php
/**
 * Footer contacts part: Address.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_contacts  = isset( $args['contacts'] ) && is_array( $args['contacts'] ) ? $args['contacts'] : array();
$mvweb_addresses = isset( $mvweb_contacts['addresses'] ) ? (array) $mvweb_contacts['addresses'] : array();

foreach ( $mvweb_addresses as $mvweb_place ) :
	$mvweb_street = trim( (string) $mvweb_place['address'] );
	$mvweb_city   = trim( (string) $mvweb_place['city'] );

	if ( '' === $mvweb_street ) {
		continue;
	}

	$mvweb_line = '' === $mvweb_city || str_contains( $mvweb_street, $mvweb_city ) ? $mvweb_street : $mvweb_city . ', ' . $mvweb_street;
	$mvweb_name = count( $mvweb_addresses ) > 1 ? trim( (string) $mvweb_place['title'] ) : '';
	?>
	<li class="mvweb-t-footer__item">
		<?php if ( '' !== $mvweb_name ) : ?>
			<span class="mvweb-t-footer__note"><?php echo esc_html( $mvweb_name ); ?></span>
		<?php endif; ?>

		<address class="mvweb-t-footer__address"><?php echo esc_html( $mvweb_line ); ?></address>
	</li>
	<?php
endforeach;
