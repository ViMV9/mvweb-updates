<?php
/**
 * Footer contacts part: Action button.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_url  = mvweb_cz_get( 'mvweb_footer_contacts_cta' ) ? trim( (string) mvweb_cz_get( 'mvweb_cta_url', '' ) ) : '';
$mvweb_text = trim( (string) mvweb_cz_get( 'mvweb_cta_text', __( 'Request a quote', 'brand-market' ) ) );

if ( '' === $mvweb_url || '' === $mvweb_text ) {
	return;
}
?>
<li class="mvweb-t-footer__item"><a class="mvweb-t-btn mvweb-t-btn--sm" href="<?php echo esc_url( $mvweb_url ); ?>"><?php echo esc_html( $mvweb_text ); ?></a></li>
