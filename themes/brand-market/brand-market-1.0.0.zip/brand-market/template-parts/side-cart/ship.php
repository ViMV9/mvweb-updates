<?php
/**
 * Side cart, part: the line about free delivery.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_text = mvweb_core_cart_ship_text( 'mvweb_minicart_ship_text' );

if ( '' === $mvweb_text ) {
	return;
}
?>
<p class="mvweb-t-minicart__ship">
	<?php echo mvweb_theme_icon( 'truck-delivery', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<?php echo esc_html( $mvweb_text ); ?>
</p>
