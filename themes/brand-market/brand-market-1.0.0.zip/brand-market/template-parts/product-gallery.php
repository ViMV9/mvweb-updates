<?php
/**
 * Photo of an item: the big picture, the strip of small ones and the badges.
 *
 * The big picture is a link to the file: the lightbox plugin takes it from
 * there. The other photos stand beside it as hidden links, so the lightbox
 * pages through all of them; the slider of the core swaps the picture, and
 * the module of the page hands a click on a later photo to its own link.
 *
 * Arguments: id, class (extra classes of the gallery). A service or a work has no
 * badges and always shows the strip; the composition is the item page's.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : get_the_ID();

if ( 0 === $mvweb_id ) {
	return;
}

$mvweb_photos = mvweb_core_item_gallery( $mvweb_id );
$mvweb_many   = count( $mvweb_photos ) > 1;
$mvweb_title  = get_the_title( $mvweb_id );
$mvweb_item   = in_array( get_post_type( $mvweb_id ), array( 'product', 'mv_item' ), true );
$mvweb_badge  = $mvweb_item && mvweb_core_layout_has( 'product-media', 'badges' ) ? mvweb_core_item_badges( $mvweb_id ) : array();
$mvweb_class  = trim( 'mvweb-t-pgallery ' . ( isset( $args['class'] ) ? (string) $args['class'] : '' ) );
$mvweb_first  = ! empty( $mvweb_photos ) ? $mvweb_photos[0] : 0;
$mvweb_sizes  = '(max-width: 960px) 100vw, 50vw';
?>
<div class="<?php echo esc_attr( $mvweb_class ); ?>" data-product-gallery>
	<?php if ( $mvweb_many ) : ?>
		<div class="mvweb-t-pgallery__thumbs"<?php echo ! $mvweb_item || mvweb_core_layout_has( 'product-media', 'thumbs' ) ? '' : ' hidden'; ?>>
			<?php foreach ( $mvweb_photos as $mvweb_index => $mvweb_photo ) : ?>
				<?php
				$mvweb_large = wp_get_attachment_image_src( $mvweb_photo, 'large' );
				$mvweb_full  = wp_get_attachment_image_url( $mvweb_photo, 'full' );
				$mvweb_alt   = mvweb_core_image_alt( $mvweb_photo, $mvweb_title );
				?>
				<button
					class="mvweb-t-pgallery__thumb"
					type="button"
					data-gallery-thumb
					data-gallery-full="<?php echo esc_url( $mvweb_large ? $mvweb_large[0] : $mvweb_full ); ?>"
					data-gallery-large="<?php echo esc_url( $mvweb_full ); ?>"
					data-gallery-srcset="<?php echo esc_attr( (string) wp_get_attachment_image_srcset( $mvweb_photo, 'large' ) ); ?>"
					aria-current="<?php echo 0 === $mvweb_index ? 'true' : 'false'; ?>"
					aria-label="<?php echo esc_attr( sprintf( /* translators: %d: number of a photo. */ __( 'Photo %d', 'brand-market' ), $mvweb_index + 1 ) ); ?>"
				>
					<?php
					echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core's escaped image markup.
						$mvweb_photo,
						'thumbnail',
						false,
						array(
							'alt'      => $mvweb_alt,
							'loading'  => 'lazy',
							'decoding' => 'async',
						)
					);
					?>
				</button>
			<?php endforeach; ?>
		</div>
		<button class="mvweb-t-pgallery__step mvweb-t-pgallery__step--up" type="button" data-gallery-up hidden title="<?php esc_attr_e( 'Scroll the photos up', 'brand-market' ); ?>">
			<?php echo mvweb_theme_icon( 'chevron-down' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span class="screen-reader-text"><?php esc_html_e( 'Scroll the photos up', 'brand-market' ); ?></span>
		</button>
		<button class="mvweb-t-pgallery__step mvweb-t-pgallery__step--down" type="button" data-gallery-down hidden title="<?php esc_attr_e( 'Scroll the photos down', 'brand-market' ); ?>">
			<?php echo mvweb_theme_icon( 'chevron-down' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span class="screen-reader-text"><?php esc_html_e( 'Scroll the photos down', 'brand-market' ); ?></span>
		</button>
	<?php endif; ?>

	<div class="mvweb-t-pgallery__main">
		<?php if ( $mvweb_first ) : ?>
			<a class="mvweb-t-pgallery__zoom" href="<?php echo esc_url( (string) wp_get_attachment_image_url( $mvweb_first, 'full' ) ); ?>" data-gallery-zoom title="<?php esc_attr_e( 'Open the photo', 'brand-market' ); ?>">
				<?php
				echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core's escaped image markup.
					$mvweb_first,
					'large',
					false,
					array(
						'class'             => 'mvweb-t-pgallery__img',
						'alt'               => mvweb_core_image_alt( $mvweb_first, $mvweb_title ),
						'sizes'             => $mvweb_sizes,
						'loading'           => 'eager',
						'fetchpriority'     => 'high',
						'decoding'          => 'async',
						'data-gallery-main' => '',
					)
				);
				?>
				<span class="screen-reader-text"><?php esc_html_e( 'Open the photo', 'brand-market' ); ?></span>
			</a>
		<?php else : ?>
			<?php
			$mvweb_placeholder = mvweb_core_placeholder_src( 'large' );

			if ( '' !== $mvweb_placeholder ) :
				?>
				<img class="mvweb-t-pgallery__img" src="<?php echo esc_url( $mvweb_placeholder ); ?>" alt="">
			<?php endif; ?>
		<?php endif; ?>

		<?php if ( ! empty( $mvweb_badge ) ) : ?>
			<span class="mvweb-t-card__badges">
				<?php foreach ( $mvweb_badge as $mvweb_one ) : ?>
					<span class="<?php echo esc_attr( 'mvweb-t-badge mvweb-t-badge--' . sanitize_html_class( $mvweb_one['type'] ) ); ?>"><?php echo esc_html( $mvweb_one['text'] ); ?></span>
				<?php endforeach; ?>
			</span>
		<?php endif; ?>

		<?php if ( $mvweb_many ) : ?>
			<button class="mvweb-t-pgallery__nav mvweb-t-pgallery__nav--prev" type="button" data-gallery-prev title="<?php esc_attr_e( 'Previous photo', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'chevron-left' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Previous photo', 'brand-market' ); ?></span>
			</button>
			<button class="mvweb-t-pgallery__nav mvweb-t-pgallery__nav--next" type="button" data-gallery-next title="<?php esc_attr_e( 'Next photo', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'chevron-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Next photo', 'brand-market' ); ?></span>
			</button>

			<span data-gallery-more hidden>
				<?php foreach ( array_slice( $mvweb_photos, 1 ) as $mvweb_photo ) : ?>
					<a href="<?php echo esc_url( (string) wp_get_attachment_image_url( $mvweb_photo, 'full' ) ); ?>" tabindex="-1"><?php echo esc_html( mvweb_core_image_alt( $mvweb_photo, $mvweb_title ) ); ?></a>
				<?php endforeach; ?>
			</span>
		<?php endif; ?>
	</div>
</div>
