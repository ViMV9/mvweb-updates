<?php
/**
 * Service aside part: the request form, or the button that stands in for it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_form = mvweb_theme_form_shortcode( (string) mvweb_core_option( 'mvweb_service_form' ) );
$mvweb_text = (string) get_theme_mod( 'mvweb_cta_text', __( 'Request a quote', 'brand-market' ) );
$mvweb_url  = (string) get_theme_mod( 'mvweb_cta_url', '' );
?>
<?php if ( '' !== $mvweb_form ) : ?>
	<div class="mvweb-t-form">
		<?php echo $mvweb_form; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Shortcode output is escaped by the plugin that owns it. ?>
	</div>
<?php elseif ( '' !== $mvweb_text && '' !== $mvweb_url ) : ?>
	<div class="mvweb-t-service__actions">
		<a class="mvweb-t-btn mvweb-t-btn--block" href="<?php echo esc_url( $mvweb_url ); ?>"><?php echo esc_html( $mvweb_text ); ?></a>
	</div>
<?php endif; ?>
