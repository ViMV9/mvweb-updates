<?php
/**
 * Service aside part: the note under the buttons.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_note = trim( (string) mvweb_core_option( 'mvweb_service_form_note' ) );

if ( '' === $mvweb_note ) {
	return;
}
?>
<p class="mvweb-t-service__form-note"><?php echo esc_html( $mvweb_note ); ?></p>
