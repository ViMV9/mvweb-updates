<?php
/**
 * Service aside part: the button with the phone.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_phone = (string) mvweb_cz_profile( 'phone' );
$mvweb_tel   = mvweb_core_tel( $mvweb_phone );

if ( '' === $mvweb_tel ) {
	return;
}
?>
<div class="mvweb-t-service__actions">
	<a class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-btn--block" href="<?php echo esc_url( $mvweb_tel ); ?>">
		<?php echo mvweb_theme_icon( 'phone', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<?php echo esc_html( $mvweb_phone ); ?>
	</a>
</div>
