<?php
/**
 * Service aside part: the heading of the side card.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_title = trim( (string) mvweb_core_option( 'mvweb_service_form_title' ) );

if ( '' === $mvweb_title ) {
	return;
}
?>
<p class="mvweb-t-service__form-title"><?php echo esc_html( $mvweb_title ); ?></p>
