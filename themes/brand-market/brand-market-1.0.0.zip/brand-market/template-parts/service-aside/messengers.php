<?php
/**
 * Service aside part: the buttons that open a chat, each with the first message typed in.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_links = mvweb_core_service_messengers( absint( $args['id'] ) );

if ( empty( $mvweb_links ) ) {
	return;
}
?>
<div class="mvweb-t-service__messengers">
	<?php foreach ( $mvweb_links as $mvweb_link ) : ?>
		<a class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-btn--sm" href="<?php echo esc_url( $mvweb_link['url'] ); ?>" target="_blank" rel="noopener">
			<?php echo mvweb_theme_icon( $mvweb_link['icon'], array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<?php echo esc_html( $mvweb_link['label'] ); ?>
		</a>
	<?php endforeach; ?>
</div>
