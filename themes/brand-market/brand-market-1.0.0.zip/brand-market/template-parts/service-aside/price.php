<?php
/**
 * Service aside part: the price with the word before it and the note after it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id    = absint( $args['id'] );
$mvweb_price = mvweb_core_item_price_html( $mvweb_id );
$mvweb_from  = mvweb_core_service_price_from();
$mvweb_note  = mvweb_core_service_price_note( $mvweb_id );

if ( '' === trim( wp_strip_all_tags( $mvweb_price ) ) ) {
	$mvweb_price = esc_html( mvweb_core_service_price_placeholder() );
	$mvweb_from  = '';
}

if ( '' === $mvweb_price ) {
	return;
}
?>
<p class="mvweb-t-service__price">
	<?php if ( '' !== $mvweb_from ) : ?>
		<span class="mvweb-t-service__price-from"><?php echo esc_html( $mvweb_from ); ?></span>
	<?php endif; ?>
	<span class="mvweb-t-price__value"><?php echo wp_kses_post( $mvweb_price ); ?></span>
	<?php if ( '' !== $mvweb_note ) : ?>
		<span class="mvweb-t-service__price-note"><?php echo esc_html( $mvweb_note ); ?></span>
	<?php endif; ?>
</p>
