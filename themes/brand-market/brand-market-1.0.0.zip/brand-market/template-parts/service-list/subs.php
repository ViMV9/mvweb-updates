<?php
/**
 * Services listing part: the strip of subsections.
 *
 * Each item is one link: the picture, then the name and the number of
 * services in the order of the card-service-section layout. A listing that
 * shows its sections as cards or as a tree leaves the strip out.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( null !== mvweb_core_service_level() ) {
	return;
}

$mvweb_terms = mvweb_core_service_child_terms( $args['term'] instanceof WP_Term ? $args['term']->term_id : 0 );

if ( empty( $mvweb_terms ) ) {
	return;
}

$mvweb_order = array_values( array_intersect( mvweb_core_layout_order( 'card-service-section' ), array( 'image', 'title', 'count' ) ) );
$mvweb_show  = array_diff( $mvweb_order, array( 'image' ) );
?>
<section class="mvweb-t-section mvweb-t-section--tight mvweb-t-section--flush-top">
	<div class="mvweb-t-container">
		<div class="mvweb-t-subcats">
			<?php foreach ( $mvweb_terms as $mvweb_child ) : ?>
				<?php
				$mvweb_link = get_term_link( $mvweb_child );

				if ( ! is_string( $mvweb_link ) ) {
					continue;
				}

				$mvweb_image = in_array( 'image', $mvweb_order, true ) ? mvweb_core_service_term_image( $mvweb_child, 'medium' ) : '';
				$mvweb_total = mvweb_core_service_count( $mvweb_child->term_id );

				/* translators: %s: number of services in the section. */
				$mvweb_count = sprintf( _n( '%s service', '%s services', $mvweb_total, 'brand-market' ), number_format_i18n( $mvweb_total ) );
				?>
				<a class="mvweb-t-subcats__item" href="<?php echo esc_url( $mvweb_link ); ?>"<?php echo in_array( 'title', $mvweb_show, true ) ? '' : ' aria-label="' . esc_attr( $mvweb_child->name ) . '"'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in place. ?>>
					<?php if ( '' !== $mvweb_image ) : ?>
						<span class="mvweb-t-subcats__pic"><?php echo $mvweb_image; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core's escaped image markup or the escaped placeholder. ?></span>
					<?php endif; ?>
					<?php if ( ! empty( $mvweb_show ) ) : ?>
						<span>
							<?php foreach ( $mvweb_show as $mvweb_slug ) : ?>
								<?php if ( 'title' === $mvweb_slug ) : ?>
									<span class="mvweb-t-subcats__name"><?php echo esc_html( $mvweb_child->name ); ?></span>
								<?php elseif ( $mvweb_total > 0 ) : ?>
									<span class="mvweb-t-subcats__count"><?php echo esc_html( $mvweb_count ); ?></span>
								<?php endif; ?>
							<?php endforeach; ?>
						</span>
					<?php endif; ?>
				</a>
			<?php endforeach; ?>
		</div>
	</div>
</section>
