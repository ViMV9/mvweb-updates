<?php
/**
 * Services listing part: the services themselves.
 *
 * The list is the grid of cards, page by page, or what the listing mode asks
 * for instead: the sections of the next level as cards, or every section as a
 * tree with its services listed. The text under the list follows it, on the
 * first page only.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_level = mvweb_core_service_level();
$mvweb_text  = mvweb_core_listing_text();
$mvweb_tree  = null !== $mvweb_level && 'tree' === mvweb_core_service_list_mode();
?>

<?php if ( $mvweb_tree ) : ?>
	<section class="mvweb-t-section mvweb-t-section--flush-top">
		<div class="mvweb-t-container">
			<div class="mvweb-t-svc-tree">
				<?php
				foreach ( $mvweb_level['terms'] as $mvweb_child ) {
					get_template_part( 'template-parts/service/tree-group', null, array( 'term' => $mvweb_child ) );
				}

				get_template_part( 'template-parts/service/tree-group', null, array( 'services' => $mvweb_level['services'] ) );
				?>
			</div>
<?php else : ?>
	<section class="mvweb-t-catalog">
		<div class="mvweb-t-container">
		<?php if ( null !== $mvweb_level ) : ?>
			<div class="mvweb-t-catalog__grid mvweb-t-catalog__grid--services">
				<?php
				foreach ( $mvweb_level['terms'] as $mvweb_child ) {
					get_template_part( 'template-parts/service/term-card', null, array( 'term' => $mvweb_child ) );
				}

				foreach ( $mvweb_level['services'] as $mvweb_service ) {
					get_template_part( 'template-parts/service/card', null, array( 'id' => $mvweb_service ) );
				}
				?>
			</div>
		<?php elseif ( have_posts() ) : ?>
			<div class="mvweb-t-catalog__grid mvweb-t-catalog__grid--services">
				<?php
				while ( have_posts() ) :
					the_post();

					get_template_part(
						'template-parts/service/card',
						null,
						array(
							'id'    => get_the_ID(),
							'eager' => $GLOBALS['wp_query']->current_post < 4,
						)
					);
				endwhile;
				?>
			</div>

			<?php mvweb_theme_pagination(); ?>
		<?php else : ?>
			<?php
			get_template_part(
				'template-parts/empty',
				null,
				array(
					'icon'        => 'tools',
					'title'       => __( 'This section is empty', 'brand-market' ),
					'text'        => __( 'There are no services here yet. Have a look at the other sections.', 'brand-market' ),
					'button_url'  => is_tax( 'mv_service_cat' ) ? mvweb_core_service_archive_url() : '',
					'button_text' => __( 'To the services', 'brand-market' ),
				)
			);
			?>
		<?php endif; ?>
<?php endif; ?>

		<?php if ( '' !== $mvweb_text ) : ?>
			<div class="mvweb-t-prose mvweb-t-catalog__text" data-prose>
				<?php echo apply_filters( 'the_content', $mvweb_text ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The key is registered with wp_kses_post, and the_content closes with kses of its own. ?>
			</div>
		<?php endif; ?>

	</div>
</section>
