<?php
/**
 * Catalogue archive of a site without WooCommerce.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

get_template_part( 'template-parts/catalog/listing' );

get_footer();
