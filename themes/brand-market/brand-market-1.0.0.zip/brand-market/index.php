<?php
/**
 * Fallback template.
 *
 * Every request WordPress cannot match to a more specific template lands here:
 * a custom post type archive without its own file, mostly. It prints the same
 * list as an archive, with the heading the query object gives it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_title = mvweb_core_alt_h1();

if ( '' === $mvweb_title ) {
	$mvweb_title = is_archive()
		? wp_strip_all_tags( get_the_archive_title() )
		: get_bloginfo( 'name' );
}

get_header();

mvweb_theme_column_open( 'blog' );

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'title' => $mvweb_title,
		'lead'  => is_archive() ? wp_strip_all_tags( get_the_archive_description() ) : '',
	)
);

get_template_part(
	'template-parts/post-list',
	null,
	array(
		'empty_title'       => __( 'Nothing here yet', 'brand-market' ),
		'empty_text'        => __( 'There are no entries for this request.', 'brand-market' ),
		'empty_button_url'  => home_url( '/' ),
		'empty_button_text' => __( 'To the homepage', 'brand-market' ),
	)
);

mvweb_theme_column_close( 'blog' );

get_footer();
