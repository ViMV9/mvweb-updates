( function () {
	"use strict";

	const modal = document.querySelector( "[data-request-modal]" );

	if ( modal ) {
		const views = modal.querySelectorAll( "[data-view]" );
		const box = modal.querySelector( "[data-request-subject-box]" );
		const subject = modal.querySelector( "[data-request-subject]" );

		function show( state ) {
			views.forEach( function ( view ) {
				const on = view.getAttribute( "data-view" ) === state;

				view.hidden = ! on;

				if ( on ) {
					modal.setAttribute( "aria-labelledby", view.getAttribute( "data-title" ) );
				}
			} );

			modal.setAttribute( "data-state", state );
		}

		document.addEventListener( "click", function ( event ) {
			const link = event.target.closest( 'a[href$="#request"]' );

			if ( ! link ) {
				return;
			}

			const name = link.getAttribute( "data-request" ) || "";

			if ( subject && box ) {
				subject.textContent = name;
				box.hidden = "" === name;
			}

			show( "form" );
		} );

		document.addEventListener( "wpcf7mailsent", function ( event ) {
			if ( modal.contains( event.target ) ) {
				show( "ok" );
			}
		} );

		document.addEventListener( "wpcf7mailfailed", function ( event ) {
			if ( modal.contains( event.target ) ) {
				show( "error" );
			}
		} );

		modal.addEventListener( "click", function ( event ) {
			if ( event.target.closest( "[data-request-retry]" ) ) {
				show( "form" );
			}
		} );

		modal.addEventListener( "close", function () {
			show( "form" );
		} );
	}

	const oneClick = document.querySelector( "[data-one-click]" );

	if ( oneClick && typeof oneClick.showModal === "function" ) {
		const order = oneClick.querySelector( "[data-one-click-form]" );
		const error = oneClick.querySelector( "[data-one-click-error]" );
		const send = order.querySelector( '[type="submit"]' );

		function view( state ) {
			oneClick.querySelectorAll( "[data-view]" ).forEach( function ( item ) {
				item.hidden = item.getAttribute( "data-view" ) !== state;
			} );
		}

		function fail( text ) {
			error.textContent = text;
			error.hidden = false;
			send.disabled = false;
		}

		document.addEventListener( "click", function ( event ) {
			if ( ! event.target.closest( "[data-one-click-open]" ) ) {
				return;
			}

			const qty = document.querySelector( 'form.cart [name="quantity"]' );
			const amount = qty ? Math.max( 1, parseInt( qty.value, 10 ) || 1 ) : 1;

			order.elements.quantity.value = amount;
			oneClick.querySelector( "[data-one-click-qty]" ).textContent = amount;
			error.hidden = true;
			view( "form" );
			oneClick.showModal();
		} );

		oneClick.addEventListener( "click", function ( event ) {
			if ( event.target === oneClick || event.target.closest( "[data-one-click-close]" ) ) {
				oneClick.close();
			}
		} );

		order.addEventListener( "submit", function ( event ) {
			const headers = { "Content-Type": "application/json" };
			const nonce = order.getAttribute( "data-nonce" );

			event.preventDefault();
			error.hidden = true;
			send.disabled = true;

			if ( nonce ) {
				headers[ "X-WP-Nonce" ] = nonce;
			}

			fetch( order.getAttribute( "data-endpoint" ), {
				method: "POST",
				credentials: "same-origin",
				headers: headers,
				body: JSON.stringify( Object.fromEntries( new FormData( order ) ) )
			} ).then( function ( response ) {
				return response.json().then( function ( data ) {
					if ( ! response.ok ) {
						fail( data.message || error.getAttribute( "data-offline" ) );
						return;
					}

					oneClick.querySelector( "[data-one-click-number]" ).textContent = data.number;
					order.reset();
					send.disabled = false;
					view( "ok" );
				} );
			} ).catch( function () {
				fail( error.getAttribute( "data-offline" ) );
			} );
		} );
	}

	function qtyEdges( box ) {
		const input = box ? box.querySelector( "[data-qty-input]" ) : null;

		if ( ! input ) {
			return;
		}

		const value = parseInt( input.value, 10 ) || 0;
		const min = Number( input.dataset.qtyMin || box.dataset.min ) || 1;
		const max = Number( input.dataset.qtyMax || box.dataset.max ) || 0;
		const minus = box.querySelector( "[data-qty-minus]" );
		const plus = box.querySelector( "[data-qty-plus]" );

		if ( minus ) {
			minus.disabled = value <= min;
		}

		if ( plus ) {
			plus.disabled = max > 0 && value >= max;
		}
	}

	function money( amount, format ) {
		const parts = amount.toFixed( format.decimals ).split( "." );
		const whole = parts[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, format.thousands );

		return format.format.replace( "%s", parts[ 1 ] ? whole + format.point + parts[ 1 ] : whole );
	}

	function buyCount( input ) {
		const box = input.closest( "[data-buy]" );
		let data;

		if ( ! box ) {
			return;
		}

		try {
			data = JSON.parse( box.getAttribute( "data-buy" ) );
		} catch ( e ) {
			return;
		}

		const qty = Math.max( data.min, parseInt( input.value, 10 ) || data.min );
		const froms = Object.keys( data.tiers ).map( Number ).sort( ( a, b ) => a - b );
		const next = froms.find( ( from ) => from > qty );
		let unit = data.price;
		let step = data.min;

		froms.forEach( function ( from ) {
			if ( qty >= from ) {
				unit = data.tiers[ from ];
				step = from;
			}
		} );

		document.querySelectorAll( "[data-buy-sum]" ).forEach( function ( sum ) {
			sum.textContent = money( unit * qty, data.money );
		} );

		box.querySelectorAll( "[data-buy-total]" ).forEach( function ( total ) {
			const note = total.querySelector( "[data-buy-note]" );
			let text = "";

			if ( next ) {
				text = total.getAttribute( "data-left" ).replace( "%1$d", next - qty ).replace( "%3$s", money( data.tiers[ next ], data.money ) );
			} else if ( unit < data.price ) {
				text = total.getAttribute( "data-save" ).replace( "%s", money( ( data.price - unit ) * qty, data.money ) );
			}

			note.textContent = text;
			note.hidden = "" === text;
		} );

		box.querySelectorAll( "[data-tier-set]" ).forEach( function ( tile ) {
			tile.setAttribute( "aria-pressed", Number( tile.getAttribute( "data-tier-set" ) ) === step ? "true" : "false" );
		} );

		box.querySelectorAll( "[data-tier-bar]" ).forEach( function ( bar ) {
			bar.style.width = Math.min( 100, Math.round( qty / ( froms[ froms.length - 1 ] || qty ) * 100 ) ) + "%";
		} );
	}

	function qtyChanged( event ) {
		const input = event.target;

		if ( ! input.matches || ! input.matches( "[data-qty-input]" ) ) {
			return;
		}

		setTimeout( function () {
			qtyEdges( input.closest( "[data-qty]" ) );
			buyCount( input );
		} );
	}

	document.querySelectorAll( "[data-qty]" ).forEach( qtyEdges );
	document.querySelectorAll( "[data-buy] [data-qty-input]" ).forEach( buyCount );
	document.addEventListener( "change", qtyChanged );
	document.addEventListener( "input", qtyChanged );

	document.addEventListener( "click", function ( event ) {
		const tile = event.target.closest( "[data-tier-set]" );
		const box = tile ? tile.closest( "[data-buy]" ) : null;
		const input = box ? box.querySelector( "[data-qty-input]" ) : null;

		if ( ! input ) {
			return;
		}

		input.value = tile.getAttribute( "data-tier-set" );
		input.dispatchEvent( new Event( "change", { bubbles: true } ) );
	} );

	const entry = history.length;

	document.addEventListener( "click", function ( event ) {
		const back = event.target.closest( "[data-back]" );
		let from = null;

		if ( ! back || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey ) {
			return;
		}

		try {
			from = new URL( document.referrer );
		} catch ( e ) {
			return;
		}

		if ( from.origin === location.origin && from.pathname !== location.pathname && history.length > 1 ) {
			event.preventDefault();
			history.go( Math.min( -1, entry - history.length - 1 ) );
		}
	} );

	document.querySelectorAll( "[data-nav-select]" ).forEach( function ( select ) {
		select.addEventListener( "change", function () {
			if ( select.value ) {
				location.assign( select.value );
			}
		} );
	} );

	document.querySelectorAll( "[data-tab-select]" ).forEach( function ( form ) {
		const select = form.querySelector( "select" );

		if ( select ) {
			select.addEventListener( "change", function () {
				form.requestSubmit();
			} );
		}
	} );
} )();
