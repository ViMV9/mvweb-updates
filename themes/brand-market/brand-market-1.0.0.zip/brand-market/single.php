<?php
/**
 * Single entry.
 *
 * The line above the title, what follows it, what follows the text and the
 * bands under the article stand in the order the site sets for the areas
 * post-meta, post-head, post-after and post-below. The column beside the text
 * is the widget area of the blog: without widgets the text takes the page.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	$mvweb_title = mvweb_core_alt_h1();
	$mvweb_title = '' !== $mvweb_title ? $mvweb_title : get_the_title();
	$mvweb_meta  = mvweb_core_blog_layout_html( 'post-meta' );
	$mvweb_top   = '';
	$mvweb_cover = '';
	$mvweb_tail  = '';

	foreach ( mvweb_core_blog_layout_html( 'post-head' ) as $mvweb_slug => $mvweb_html ) {
		if ( 'cover' === $mvweb_slug ) {
			$mvweb_cover = $mvweb_html;
		} elseif ( '' === $mvweb_cover ) {
			$mvweb_top .= $mvweb_html;
		} else {
			$mvweb_tail .= $mvweb_html;
		}
	}

	$mvweb_aside = mvweb_theme_sidebar_on( 'blog' );
	?>

	<article <?php post_class( 'mvweb-t-post' ); ?>>
		<div class="mvweb-t-container">
			<?php get_template_part( 'template-parts/crumbs' ); ?>

			<div class="mvweb-t-post__layout<?php echo $mvweb_aside ? esc_attr( mvweb_theme_sidebar_side_class( 'blog', 'mvweb-t-post__layout' ) ) : ' mvweb-t-post__layout--solo'; ?>">
				<div class="mvweb-t-post__main">
					<header class="mvweb-t-post__head">
						<?php if ( ! empty( $mvweb_meta ) ) : ?>
							<div class="mvweb-t-post__meta"><?php echo implode( '', $mvweb_meta ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?></div>
						<?php endif; ?>
						<h1 class="mvweb-t-post__title"><?php echo esc_html( $mvweb_title ); ?></h1>
						<?php echo $mvweb_top; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?>
					</header>

					<?php echo $mvweb_cover; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template. ?>

					<?php if ( '' !== $mvweb_tail ) : ?>
						<div class="mvweb-t-post__head"><?php echo $mvweb_tail; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?></div>
					<?php endif; ?>

					<div class="mvweb-t-prose mvweb-t-post__body" data-prose>
						<?php the_content(); ?>
					</div>

					<?php
					wp_link_pages(
						array(
							'before'    => '<nav class="mvweb-t-pagination" aria-label="' . esc_attr__( 'Pagination', 'brand-market' ) . '"><ul class="mvweb-t-pagination__list"><li>',
							'after'     => '</li></ul></nav>',
							'separator' => '</li><li>',
						)
					);

					mvweb_core_render_layout( 'post-after' );
					?>
				</div>

				<?php
				get_template_part(
					'template-parts/sidebar',
					null,
					array(
						'area'  => 'blog',
						'class' => 'mvweb-t-post__aside',
					)
				);
				?>
			</div>
		</div>
	</article>

	<?php
	mvweb_core_render_layout( 'post-below' );
	mvweb_core_render_context_sections();
endwhile;

get_footer();
