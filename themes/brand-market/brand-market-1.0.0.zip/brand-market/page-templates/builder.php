<?php
/**
 * Template Name: Page builder
 *
 * A page assembled from sections instead of the editor. The hero still owns the
 * single h1, taken from the entry title; everything below it comes from the
 * builder meta.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	$mvweb_title = mvweb_core_alt_h1();

	if ( '' === $mvweb_title ) {
		$mvweb_title = get_the_title();
	}

	get_template_part(
		'template-parts/page-hero',
		null,
		array(
			'title'    => $mvweb_title,
			'lead'     => has_excerpt() ? get_the_excerpt() : '',
			'image_id' => get_post_thumbnail_id(),
		)
	);

	mvweb_core_render_sections( mvweb_core_request_sections() );

endwhile;

get_footer();
