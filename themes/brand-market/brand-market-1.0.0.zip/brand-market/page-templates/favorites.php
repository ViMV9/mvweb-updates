<?php
/**
 * Template Name: Favourites
 *
 * The list itself is filled in the browser: a guest keeps it there, and a page
 * that varies by visitor must not be baked into a cache. What stands around
 * the list (the number, the note for a guest, the tools) is the composition
 * «Favourites page» set in the Customizer.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_title = mvweb_core_alt_h1();

if ( '' === $mvweb_title ) {
	$mvweb_title = get_the_title();
}

ob_start();
mvweb_core_render_layout( 'favorites', array( 'place' => 'hero' ) );
$mvweb_after = ob_get_clean();

ob_start();
mvweb_core_render_layout( 'favorites', array( 'place' => 'tools' ) );
$mvweb_tools = trim( ob_get_clean() );

get_header();

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'title'    => $mvweb_title,
		'lead'     => get_the_excerpt(),
		'image_id' => get_post_thumbnail_id(),
		'after'    => $mvweb_after,
	)
);
?>

<section class="mvweb-t-section mvweb-t-section--flush-top">
	<div class="mvweb-t-container" data-fav-list>
		<span class="screen-reader-text" role="status" data-fav-live></span>

		<div class="mvweb-t-alert mvweb-t-alert--info" data-fav-shared hidden>
			<?php echo mvweb_theme_icon( 'info-circle', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<p>
				<?php esc_html_e( 'This is a list somebody shared with you.', 'brand-market' ); ?>
				<a href="<?php echo esc_url( get_permalink() ); ?>"><?php esc_html_e( 'Show my list', 'brand-market' ); ?></a>
			</p>
		</div>

		<?php mvweb_core_render_layout( 'favorites', array( 'place' => 'body' ) ); ?>

		<?php if ( '' !== $mvweb_tools ) : ?>
			<div class="mvweb-t-fav-tools" data-fav-tools hidden>
				<?php echo $mvweb_tools; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the parts, every value escaped there. ?>
			</div>
		<?php endif; ?>

		<?php get_template_part( 'template-parts/catalog/thead' ); ?>

		<div class="mvweb-t-catalog__grid mvweb-t-catalog__grid--wide" data-fav-grid data-catalog-grid data-view="<?php echo esc_attr( mvweb_core_catalog_view() ); ?>" hidden></div>

		<div data-fav-error hidden>
			<?php
			get_template_part(
				'template-parts/empty',
				null,
				array(
					'icon'  => 'search',
					'title' => __( 'Could not load the list', 'brand-market' ),
					'text'  => __( 'The connection dropped. Reload the page — nothing was lost.', 'brand-market' ),
				)
			);
			?>
		</div>

		<div data-fav-empty>
			<?php
			get_template_part(
				'template-parts/empty',
				null,
				array(
					'icon'        => 'heart',
					'title'       => __( 'Nothing put aside yet', 'brand-market' ),
					'text'        => __( 'Tap the heart on a card and the item will wait for you here.', 'brand-market' ),
					'button_url'  => mvweb_core_catalog_page_url(),
					'button_text' => __( 'To the catalog', 'brand-market' ),
				)
			);
			?>
		</div>
	</div>
</section>

<?php
get_footer();
