<?php
/**
 * Template Name: Comparison
 *
 * The table is drawn by the script of the comparison from the list: a guest
 * keeps it in the browser, and a page that varies by visitor must not be
 * baked into a cache. The facts under the heading, the category choice and
 * the rows are the compositions «Comparison» set in the Customizer.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_title = mvweb_core_alt_h1();

if ( '' === $mvweb_title ) {
	$mvweb_title = get_the_title();
}

ob_start();
mvweb_core_render_layout( 'compare-bar', array( 'place' => 'hero' ) );
$mvweb_after = ob_get_clean();

get_header();

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'title'    => $mvweb_title,
		'lead'     => get_the_excerpt(),
		'image_id' => get_post_thumbnail_id(),
		'after'    => $mvweb_after,
	)
);
?>

<section class="mvweb-t-section mvweb-t-section--flush-top">
	<div class="mvweb-t-container" data-compare-page>
		<div data-compare-body tabindex="-1"></div>

		<div data-compare-empty hidden>
			<?php get_template_part( 'template-parts/compare/empty' ); ?>
		</div>

		<div data-compare-error hidden>
			<?php
			get_template_part(
				'template-parts/empty',
				null,
				array(
					'icon'  => 'search',
					'title' => __( 'Could not load the comparison', 'brand-market' ),
					'text'  => __( 'The connection dropped. Reload the page — nothing was lost.', 'brand-market' ),
				)
			);
			?>
		</div>
	</div>
</section>

<?php
get_footer();
