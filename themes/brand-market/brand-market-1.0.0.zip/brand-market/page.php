<?php
/**
 * Single page.
 *
 * The heading strip, then the text of the page in the prose area. A page
 * carries no sidebar of its own; widgets come with the sidebars.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	$mvweb_title = mvweb_core_alt_h1();

	if ( '' === $mvweb_title ) {
		$mvweb_title = get_the_title();
	}

	mvweb_theme_column_open( 'page' );

	get_template_part(
		'template-parts/page-hero',
		null,
		array(
			'title'    => $mvweb_title,
			'lead'     => has_excerpt() ? get_the_excerpt() : '',
			'image_id' => get_post_thumbnail_id(),
		)
	);

	if ( '' !== trim( get_the_content() ) ) :
		?>
		<section class="mvweb-t-section mvweb-t-section--flush-top">
			<div class="mvweb-t-container">
				<div class="mvweb-t-prose" data-prose>
					<?php
					the_content();

					wp_link_pages(
						array(
							'before' => '<nav class="page-links" aria-label="' . esc_attr__( 'Page parts', 'brand-market' ) . '">',
							'after'  => '</nav>',
						)
					);
					?>
				</div>
			</div>
		</section>
		<?php
	endif;

	mvweb_theme_column_close( 'page' );

endwhile;

get_footer();
