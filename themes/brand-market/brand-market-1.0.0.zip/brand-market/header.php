<?php
/**
 * Header.
 *
 * The top bar, both rows of the header and the mobile menu are assembled from
 * zones, so their contents and order are the owner's business, not this file's.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_root = '';

foreach ( array_merge( array( 'data-scheme' => mvweb_core_default_scheme() ), mvweb_core_frame_html_settings(), mvweb_core_element_html_settings() ) as $mvweb_name => $mvweb_value ) {
	$mvweb_root .= ' ' . sanitize_key( $mvweb_name ) . '="' . esc_attr( $mvweb_value ) . '"';
}

$mvweb_notice = mvweb_theme_notice();
$mvweb_topbar = mvweb_theme_zone_html( 'header-topbar' );
$mvweb_lead   = mvweb_theme_zone_html( 'header-main' );

if ( false === strpos( $mvweb_lead, 'mvweb-t-header__burger' ) ) {
	ob_start();
	get_template_part( 'template-parts/elements/burger' );
	$mvweb_lead .= ob_get_clean();
}

$mvweb_nav          = mvweb_theme_zone_html( 'header-nav' );
$mvweb_contact      = mvweb_theme_zone_html( 'header-drawer-contacts' );
$mvweb_menu         = mvweb_theme_zone_html( 'header-drawer-nav' );
$mvweb_foot         = mvweb_theme_zone_html( 'header-drawer-foot' );
$mvweb_contact_pos  = 'bottom' === get_theme_mod( 'mvweb_drawer_contacts_pos', 'top' ) ? 'bottom' : 'top';
$mvweb_contact_html = '' !== $mvweb_contact ? '<div class="mvweb-t-drawer__contacts">' . $mvweb_contact . '</div>' : '';

?><!doctype html>
<html <?php language_attributes(); ?><?php echo $mvweb_root; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Names are sanitized and values escaped above. ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<a class="mvweb-t-skip-link" href="#main"><?php esc_html_e( 'Skip to content', 'brand-market' ); ?></a>

<?php if ( '' !== $mvweb_topbar ) : ?>
	<div class="mvweb-t-notice"<?php echo ! empty( $mvweb_notice['closable'] ) ? ' data-notice="' . esc_attr( $mvweb_notice['key'] ) . '"' . ( $mvweb_notice['keep'] ? ' data-notice-keep' : '' ) : ''; ?>>
		<div class="mvweb-t-container mvweb-t-notice__row">
			<?php echo $mvweb_topbar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped element templates. ?>
		</div>
	</div>
<?php endif; ?>

<header data-header class="<?php echo esc_attr( mvweb_theme_header_class() ); ?>"<?php echo is_customize_preview() ? ' data-mvweb-cz-section="mvweb_cz_header_blocks"' : ''; ?>>
	<div class="mvweb-t-container mvweb-t-header__inner">
		<?php if ( '' !== $mvweb_lead ) : ?>
			<div class="mvweb-t-header__lead">
				<?php echo $mvweb_lead; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped element templates. ?>
			</div>
		<?php endif; ?>

		<?php if ( '' !== $mvweb_nav ) : ?>
			<div class="mvweb-t-header__nav">
				<?php echo $mvweb_nav; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped element templates. ?>
			</div>
		<?php endif; ?>
	</div>

	<?php mvweb_theme_search_panel(); ?>
</header>

<dialog class="mvweb-t-drawer" data-drawer aria-label="<?php esc_attr_e( 'Mobile menu', 'brand-market' ); ?>">
	<div class="mvweb-t-drawer__panel">
		<div class="mvweb-t-drawer__head">
			<?php
			mvweb_theme_logo(
				array(
					'tag'  => 'span',
					'lazy' => true,
				)
			);
			?>

			<button class="mvweb-t-round" type="button" data-drawer-close title="<?php esc_attr_e( 'Close', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Close', 'brand-market' ); ?></span>
			</button>
		</div>

		<?php if ( 'top' === $mvweb_contact_pos ) : ?>
			<?php echo $mvweb_contact_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped box built above. ?>
		<?php endif; ?>

		<?php if ( '' !== $mvweb_menu ) : ?>
			<nav class="mvweb-t-drawer__nav" aria-label="<?php esc_attr_e( 'Mobile navigation', 'brand-market' ); ?>">
				<?php echo $mvweb_menu; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped element templates. ?>
			</nav>
		<?php endif; ?>

		<?php if ( 'bottom' === $mvweb_contact_pos ) : ?>
			<?php echo $mvweb_contact_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped box built above. ?>
		<?php endif; ?>

		<?php if ( '' !== $mvweb_foot ) : ?>
			<div class="mvweb-t-drawer__foot">
				<?php echo $mvweb_foot; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped element templates. ?>
			</div>
		<?php endif; ?>
	</div>
</dialog>

<main id="main">
