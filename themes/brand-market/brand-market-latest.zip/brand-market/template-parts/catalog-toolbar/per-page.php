<?php
/**
 * Bar part: how many goods a page holds.
 *
 * A plain GET form like the sorting: the filters and the order ride along as
 * hidden fields, and assets/js/filters.js submits the form on change. The
 * choice starts the listing from its first page.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_choices = mvweb_core_per_page_choices();

if ( (int) $GLOBALS['wp_query']->found_posts <= min( $mvweb_choices ) ) {
	return;
}

get_template_part( 'template-parts/catalog-toolbar/tools', null, $args );

$mvweb_per_page = mvweb_core_per_page();
?>
<form class="mvweb-t-sort mvweb-t-sort--per-page" action="<?php echo esc_url( mvweb_core_catalog_url() ); ?>" method="get" data-sort>
	<?php foreach ( mvweb_core_catalog_query_args( array( 'per_page' ) ) as $mvweb_key => $mvweb_value ) : ?>
		<input type="hidden" name="<?php echo esc_attr( $mvweb_key ); ?>" value="<?php echo esc_attr( $mvweb_value ); ?>">
	<?php endforeach; ?>

	<label class="mvweb-t-sort__label" for="mvweb-t-sort-per-page"><?php esc_html_e( 'Per page', 'brand-market' ); ?></label>
	<select class="mvweb-t-sort__select" id="mvweb-t-sort-per-page" name="per_page">
		<?php foreach ( $mvweb_choices as $mvweb_choice ) : ?>
			<option value="<?php echo esc_attr( (string) $mvweb_choice ); ?>" <?php selected( $mvweb_per_page, $mvweb_choice ); ?>><?php echo esc_html( number_format_i18n( $mvweb_choice ) ); ?></option>
		<?php endforeach; ?>
	</select>

	<noscript><button class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-btn--sm" type="submit"><?php esc_html_e( 'Apply', 'brand-market' ); ?></button></noscript>
</form>
