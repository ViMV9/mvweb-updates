<?php
/**
 * Request dialog: the form of "Conversion" behind every link to #request, or
 * the form of a block behind the link to the id of its window.
 *
 * Three views share one dialog: the form, "sent" and "failed". The script of
 * the theme switches them by the events of the form plugin; without it the
 * form view is the only one that is not hidden.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_title = isset( $args['title'] ) ? (string) $args['title'] : '';
$mvweb_text  = isset( $args['text'] ) ? (string) $args['text'] : '';
$mvweb_id    = isset( $args['id'] ) && '' !== $args['id'] ? sanitize_html_class( (string) $args['id'] ) : 'request';
$mvweb_form  = mvweb_core_form_shortcode( isset( $args['form'] ) ? (string) $args['form'] : '' );

if ( '' === $mvweb_form ) {
	return;
}

$mvweb_ok_title = trim( (string) get_theme_mod( 'mvweb_popup_ok_title', '' ) );
$mvweb_ok_text  = trim( (string) get_theme_mod( 'mvweb_popup_ok_text', '' ) );
$mvweb_er_title = trim( (string) get_theme_mod( 'mvweb_popup_error_title', '' ) );
$mvweb_er_text  = trim( (string) get_theme_mod( 'mvweb_popup_error_text', '' ) );
$mvweb_phone    = mvweb_core_contact_phone();
$mvweb_tel      = mvweb_core_tel( $mvweb_phone );

if ( '' === $mvweb_ok_title ) {
	$mvweb_ok_title = __( 'Request sent', 'brand-market' );
}

if ( '' === $mvweb_er_title ) {
	$mvweb_er_title = __( 'Could not send', 'brand-market' );
}
?>
<dialog class="mvweb-t-modal" id="<?php echo esc_attr( $mvweb_id ); ?>" aria-labelledby="<?php echo esc_attr( 'mvweb-t-' . $mvweb_id . '-title-form' ); ?>" data-request-modal data-state="form">
	<div class="mvweb-t-modal__box">

		<div class="mvweb-t-modal__view" data-view="form" data-title="<?php echo esc_attr( 'mvweb-t-' . $mvweb_id . '-title-form' ); ?>">
			<button class="mvweb-t-round mvweb-t-modal__close" type="button" data-request-close title="<?php esc_attr_e( 'Close', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Close', 'brand-market' ); ?></span>
			</button>

			<div class="mvweb-t-modal__title mvweb-t-h2" role="heading" aria-level="2" id="<?php echo esc_attr( 'mvweb-t-' . $mvweb_id . '-title-form' ); ?>"><?php echo esc_html( $mvweb_title ); ?></div>

			<p class="mvweb-t-modal__subject" data-request-subject-box hidden>
				<span class="mvweb-t-modal__subject-label"><?php esc_html_e( 'You are interested in', 'brand-market' ); ?></span>
				<strong data-request-subject></strong>
			</p>

			<?php if ( '' !== $mvweb_text ) : ?>
				<p class="mvweb-t-modal__lead"><?php echo esc_html( $mvweb_text ); ?></p>
			<?php endif; ?>

			<div class="mvweb-t-modal__form">
				<?php echo $mvweb_form; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Shortcode output is escaped by the plugin that owns it. ?>
			</div>

			<p class="mvweb-t-form-note"><?php esc_html_e( '* Required fields', 'brand-market' ); ?></p>
		</div>

		<div class="mvweb-t-modal__view mvweb-t-modal__view--center" data-view="ok" data-title="<?php echo esc_attr( 'mvweb-t-' . $mvweb_id . '-title-ok' ); ?>" hidden>
			<button class="mvweb-t-round mvweb-t-modal__close" type="button" data-request-close title="<?php esc_attr_e( 'Close', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Close', 'brand-market' ); ?></span>
			</button>
			<span class="mvweb-t-modal__mark"><?php echo mvweb_theme_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
			<div class="mvweb-t-modal__title mvweb-t-h2" role="heading" aria-level="2" id="<?php echo esc_attr( 'mvweb-t-' . $mvweb_id . '-title-ok' ); ?>"><?php echo esc_html( $mvweb_ok_title ); ?></div>
			<?php if ( '' !== $mvweb_ok_text ) : ?>
				<p class="mvweb-t-modal__lead"><?php echo esc_html( $mvweb_ok_text ); ?></p>
			<?php endif; ?>
			<button class="mvweb-t-btn" type="button" data-request-close><?php esc_html_e( 'Close', 'brand-market' ); ?></button>
		</div>

		<div class="mvweb-t-modal__view mvweb-t-modal__view--center" data-view="error" data-title="<?php echo esc_attr( 'mvweb-t-' . $mvweb_id . '-title-error' ); ?>" hidden>
			<button class="mvweb-t-round mvweb-t-modal__close" type="button" data-request-close title="<?php esc_attr_e( 'Close', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Close', 'brand-market' ); ?></span>
			</button>
			<span class="mvweb-t-modal__mark mvweb-t-modal__mark--muted"><?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
			<div class="mvweb-t-modal__title mvweb-t-h2" role="heading" aria-level="2" id="<?php echo esc_attr( 'mvweb-t-' . $mvweb_id . '-title-error' ); ?>"><?php echo esc_html( $mvweb_er_title ); ?></div>
			<?php if ( '' !== $mvweb_er_text || '' !== $mvweb_tel ) : ?>
				<p class="mvweb-t-modal__lead">
					<?php echo esc_html( $mvweb_er_text ); ?>
					<?php if ( '' !== $mvweb_tel ) : ?>
						<a href="<?php echo esc_url( $mvweb_tel ); ?>"><?php echo esc_html( $mvweb_phone ); ?></a>
					<?php endif; ?>
				</p>
			<?php endif; ?>
			<button class="mvweb-t-btn" type="button" data-request-retry><?php esc_html_e( 'Try again', 'brand-market' ); ?></button>
		</div>

	</div>
</dialog>
