<?php
/**
 * The page of one service.
 *
 * A service is read, not browsed: the heading, the photo and the text run in
 * one column, and the way to order stays beside them in a card that follows
 * the reader down the page. The parts of the head, of the side card and of the
 * text come from the service-head, service-aside and service-main layouts,
 * what stands under the page from service-below. A side card whose parts are
 * all hidden or empty is not printed and the text takes the whole width. The
 * look with benefits and tabs puts a small photo, the benefits, the price and
 * the buttons in the head and the text with the shared tabs under it. With
 * widgets in the column of the services the whole page stands beside that
 * column, as a section does, and the side card goes under the head.
 * Questions and answers, when the services take them, close the main column.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : get_the_ID();

if ( 0 === $mvweb_id ) {
	return;
}

$mvweb_title = mvweb_core_alt_h1();

if ( '' === $mvweb_title ) {
	$mvweb_title = get_the_title( $mvweb_id );
}

$mvweb_parts = array();
$mvweb_tabs  = 'tabs' === mvweb_theme_service_view();

foreach ( array( 'service-head', 'service-aside', 'service-main' ) as $mvweb_area ) {
	ob_start();

	if ( $mvweb_tabs && 'service-aside' !== $mvweb_area ) {
		get_template_part( 'service-head' === $mvweb_area ? 'template-parts/service/hero' : 'template-parts/service/tabs', null, array( 'id' => $mvweb_id ) );
	} else {
		mvweb_core_render_layout( $mvweb_area, array( 'id' => $mvweb_id ) );
	}

	$mvweb_parts[ $mvweb_area ] = trim( (string) ob_get_clean() );
}

ob_start();
get_template_part( 'template-parts/service/questions' );
$mvweb_parts['service-main'] .= trim( (string) ob_get_clean() );

mvweb_theme_column_open( 'services' );
?>

<section class="mvweb-t-service<?php echo $mvweb_tabs ? ' mvweb-t-service--tabs' : ''; ?>">
	<div class="mvweb-t-container">

		<?php
		if ( ! mvweb_core_sidebar_on( 'services' ) ) {
			get_template_part( 'template-parts/crumbs' );
		}
		?>

		<div class="mvweb-t-service__layout<?php echo '' === $mvweb_parts['service-aside'] ? ' mvweb-t-service__layout--solo' : ''; ?>">
			<header class="mvweb-t-service__head">
				<h1 class="mvweb-t-product-title"><?php echo esc_html( $mvweb_title ); ?></h1>
				<?php echo $mvweb_parts['service-head']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there. ?>
			</header>

			<?php if ( '' !== $mvweb_parts['service-aside'] ) : ?>
				<aside class="mvweb-t-service__aside" id="mvweb-t-service-form">
					<?php echo $mvweb_parts['service-aside']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there. ?>
				</aside>
			<?php endif; ?>

			<?php if ( '' !== trim( $mvweb_parts['service-main'] ) ) : ?>
				<div class="mvweb-t-service__main">
					<?php echo $mvweb_parts['service-main']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there. ?>
				</div>
			<?php endif; ?>
		</div>

	</div>
</section>
<?php
mvweb_theme_column_close( 'services' );
mvweb_core_render_layout( 'service-below', array( 'id' => $mvweb_id ) );
