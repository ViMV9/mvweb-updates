<?php
/**
 * The head of a service in the look with benefits and tabs.
 *
 * A small photo beside the line under the heading, the short text and the
 * shared benefits; under them the price with its note, the main button and the
 * link to the tab of prices. The line and the short text follow the
 * service-head layout; its price button is left out, the price stands here.
 *
 * Arguments: id (service).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id    = absint( $args['id'] );
$mvweb_photo = has_post_thumbnail( $mvweb_id )
	? get_the_post_thumbnail(
		$mvweb_id,
		'medium_large',
		array(
			'class'         => 'mvweb-t-service__pic-img',
			'sizes'         => '(max-width: 600px) 160px, 256px',
			'fetchpriority' => 'high',
		)
	)
	: '';
$mvweb_lines = '';

foreach ( mvweb_core_layout_order( 'service-head' ) as $mvweb_slug ) {
	if ( 'jump' !== $mvweb_slug ) {
		ob_start();
		get_template_part( 'template-parts/service-head/' . sanitize_key( $mvweb_slug ), null, array( 'id' => $mvweb_id ) );
		$mvweb_lines .= trim( (string) ob_get_clean() );
	}
}

$mvweb_pros  = mvweb_theme_service_pros();
$mvweb_price = mvweb_core_item_price_html( $mvweb_id );
$mvweb_from  = mvweb_core_service_price_from();
$mvweb_note  = mvweb_theme_service_price_note( $mvweb_id );
$mvweb_btn   = mvweb_theme_service_button();
$mvweb_tabs  = mvweb_theme_service_tabs( $mvweb_id );

if ( '' === trim( wp_strip_all_tags( $mvweb_price ) ) ) {
	$mvweb_price = esc_html( mvweb_core_service_price_placeholder() );
	$mvweb_from  = '';
}
?>
<?php if ( '' !== $mvweb_photo || '' !== $mvweb_lines || ! empty( $mvweb_pros ) ) : ?>
	<div class="mvweb-t-service__top<?php echo '' === $mvweb_photo ? ' mvweb-t-service__top--text' : ( '' === $mvweb_lines ? ' mvweb-t-service__top--bare' : '' ); ?>">
		<?php if ( '' !== $mvweb_photo ) : ?>
			<div class="mvweb-t-service__pic" style="--mvweb-t-service-pic-ratio: <?php echo esc_attr( mvweb_theme_service_photo_ratio() ); ?>"><?php echo $mvweb_photo; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core's escaped image markup. ?></div>
		<?php endif; ?>

		<?php if ( '' !== $mvweb_lines ) : ?>
			<div class="mvweb-t-service__lines"><?php echo $mvweb_lines; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the part templates, escaped there. ?></div>
		<?php endif; ?>

		<?php if ( ! empty( $mvweb_pros ) ) : ?>
			<ul class="mvweb-t-service__pros">
				<?php foreach ( $mvweb_pros as $mvweb_pro ) : ?>
					<li>
						<?php if ( '' !== $mvweb_pro['icon'] ) : ?>
							<span class="mvweb-t-service__pro-icon"><?php echo mvweb_theme_icon( $mvweb_pro['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
						<?php endif; ?>
						<?php echo esc_html( $mvweb_pro['text'] ); ?>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
<?php endif; ?>

<?php if ( '' !== $mvweb_price ) : ?>
	<p class="mvweb-t-service__price mvweb-t-service__price--head">
		<?php if ( '' !== $mvweb_from ) : ?>
			<span class="mvweb-t-service__price-from"><?php echo esc_html( $mvweb_from ); ?></span>
		<?php endif; ?>
		<span class="mvweb-t-price__value"><?php echo wp_kses_post( $mvweb_price ); ?></span>
		<?php if ( '' !== $mvweb_note ) : ?>
			<span class="mvweb-t-service__price-note"><?php echo esc_html( $mvweb_note ); ?></span>
		<?php endif; ?>
	</p>
<?php endif; ?>

<?php if ( '' !== $mvweb_btn['url'] || isset( $mvweb_tabs['prices'] ) ) : ?>
	<div class="mvweb-t-service__buttons">
		<?php if ( '' !== $mvweb_btn['url'] ) : ?>
			<a class="mvweb-t-btn" href="<?php echo esc_url( $mvweb_btn['url'] ); ?>"><?php echo esc_html( $mvweb_btn['text'] ); ?></a>
		<?php endif; ?>
		<?php if ( isset( $mvweb_tabs['prices'] ) ) : ?>
			<a class="mvweb-t-btn mvweb-t-btn--outline" href="#mvweb-t-service-tabs" data-tab-open="prices">
				<?php echo esc_html( $mvweb_tabs['prices']['title'] ); ?>
				<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			</a>
		<?php endif; ?>
	</div>
<?php endif; ?>
