<?php
/**
 * Questions and answers under a service or a section.
 *
 * Every question is a card, newest first; the answers and the follow-ups of the
 * thread run under it in the order they came, without nesting deeper, an answer
 * of the site beside a bar of the accent with its mark. A visitor sees the own
 * question waiting for moderation on the page the form returns to. The script
 * folds the form into one line and the questions after the fifth under a
 * button; without it everything stays open.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_post = mvweb_theme_questions_post();

if ( 0 === $mvweb_post || ! comments_open( $mvweb_post ) ) {
	return;
}

$mvweb_wrap      = ! empty( $args['wrap'] );
$mvweb_commenter = wp_get_current_commenter();
$mvweb_mine      = array_values( array_filter( array( get_current_user_id(), wp_get_unapproved_comment_author_email() ) ) );
$mvweb_all       = get_comments(
	array(
		'post_id'            => $mvweb_post,
		'status'             => 'approve',
		'type'               => 'comment',
		'orderby'            => 'comment_date_gmt',
		'order'              => 'ASC',
		'include_unapproved' => $mvweb_mine,
	)
);
$mvweb_by_id     = array();
$mvweb_threads   = array();

foreach ( $mvweb_all as $mvweb_comment ) {
	$mvweb_by_id[ (int) $mvweb_comment->comment_ID ] = $mvweb_comment;
}

foreach ( $mvweb_all as $mvweb_comment ) {
	$mvweb_root = $mvweb_comment;

	while ( (int) $mvweb_root->comment_parent > 0 && isset( $mvweb_by_id[ (int) $mvweb_root->comment_parent ] ) ) {
		$mvweb_root = $mvweb_by_id[ (int) $mvweb_root->comment_parent ];
	}

	$mvweb_threads[ (int) $mvweb_root->comment_ID ][] = $mvweb_comment;
}

$mvweb_threads = array_reverse( $mvweb_threads, true );
$mvweb_count   = (int) get_comments_number( $mvweb_post );
$mvweb_depth   = max( 2, (int) get_option( 'thread_comments_depth' ) );
$mvweb_consent = mvweb_core_blog_comment_consent();
$mvweb_field   = static function ( $name, $label, $type, $autocomplete ) use ( $mvweb_commenter ) {
	return sprintf(
		'<div class="mvweb-t-field"><label class="mvweb-t-field__label" for="%1$s">%2$s</label><input class="mvweb-t-field__input" id="%1$s" name="%1$s" type="%3$s" value="%4$s" autocomplete="%5$s"%6$s></div>',
		esc_attr( $name ),
		esc_html( $label ),
		esc_attr( $type ),
		esc_attr( $mvweb_commenter[ 'author' === $name ? 'comment_author' : 'comment_author_' . $name ] ?? '' ),
		esc_attr( $autocomplete ),
		get_option( 'require_name_email' ) ? ' required' : ''
	);
};
$mvweb_who     = static function ( $comment, $staff ) {
	$date = '<time class="mvweb-t-qa__date" datetime="' . esc_attr( get_comment_date( 'c', $comment ) ) . '">' . esc_html( get_comment_date( '', $comment ) ) . '</time>';

	if ( $staff ) {
		return '<div class="mvweb-t-qa__who"><span class="mvweb-t-qa__ava mvweb-t-qa__ava--site">' . mvweb_theme_questions_mark() . '</span><div class="mvweb-t-qa__by"><span class="mvweb-t-qa__name">' . esc_html( get_option( 'blogname' ) ) . '</span><span class="mvweb-t-qa__badge">' . mvweb_theme_icon( 'check', array( 'class' => 'mvweb-t-icon--sm' ) ) . esc_html__( 'Answer of a specialist', 'brand-market' ) . '</span>' . $date . '</div></div>';
	}

	return '<div class="mvweb-t-qa__who"><span class="mvweb-t-qa__ava">' . esc_html( mb_strtoupper( mvweb_core_initials( get_comment_author( $comment ) ) ) ) . '</span><div class="mvweb-t-qa__by"><span class="mvweb-t-qa__name">' . esc_html( get_comment_author( $comment ) ) . '</span>' . $date . '</div></div>';
};
$mvweb_wait    = static function ( $comment ) {
	return '0' === (string) $comment->comment_approved ? '<p class="mvweb-t-qa__wait">' . esc_html__( 'Your question is waiting for moderation.', 'brand-market' ) . '</p>' : '';
};

wp_enqueue_script( 'comment-reply' );
wp_enqueue_script(
	'mvweb-t-questions',
	get_template_directory_uri() . '/assets/js/questions.min.js',
	array(),
	(string) filemtime( get_template_directory() . '/assets/js/questions.min.js' ),
	array(
		'in_footer' => true,
		'strategy'  => 'defer',
	)
);
?>
<?php if ( $mvweb_wrap ) : ?>
<section class="mvweb-t-section">
	<div class="mvweb-t-container">
<?php endif; ?>
<div class="mvweb-t-qa" id="comments" data-qa>
	<div class="mvweb-t-qa__head">
		<div class="mvweb-t-qa__title" role="heading" aria-level="2">
			<?php esc_html_e( 'Questions and answers', 'brand-market' ); ?>
			<?php if ( $mvweb_count > 0 ) : ?>
				<span class="mvweb-t-qa__count"><?php echo esc_html( number_format_i18n( $mvweb_count ) ); ?></span>
			<?php endif; ?>
		</div>
		<p class="mvweb-t-qa__lead"><?php echo empty( $mvweb_threads ) ? esc_html__( 'No questions yet. Ask the first one, the answer comes to your email.', 'brand-market' ) : esc_html__( 'The answer comes to your email.', 'brand-market' ); ?></p>
	</div>

	<?php if ( ! empty( $mvweb_threads ) ) : ?>
		<div class="mvweb-t-qa__feed">
			<?php
			$mvweb_index = 0;

			foreach ( $mvweb_threads as $mvweb_root_id => $mvweb_thread ) :
				$mvweb_root     = array_shift( $mvweb_thread );
				$mvweb_answered = (bool) array_filter( $mvweb_thread, 'mvweb_theme_questions_staff' );
				$mvweb_reply    = get_comment_reply_link(
					array(
						'add_below'  => 'comment',
						'respond_id' => 'respond',
						'depth'      => 1,
						'max_depth'  => $mvweb_depth,
						'reply_text' => $mvweb_answered ? __( 'Ask more', 'brand-market' ) : __( 'Reply', 'brand-market' ),
					),
					$mvweb_root
				);
				?>
				<article class="mvweb-t-qa__card" id="comment-<?php echo (int) $mvweb_root_id; ?>"<?php echo $mvweb_index++ >= 5 ? ' data-qa-more' : ''; ?>>
					<?php echo $mvweb_who( $mvweb_root, mvweb_theme_questions_staff( $mvweb_root ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>
					<div class="mvweb-t-qa__text"><?php comment_text( $mvweb_root ); ?></div>
					<?php echo $mvweb_wait( $mvweb_root ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>

					<?php foreach ( $mvweb_thread as $mvweb_comment ) : ?>
						<?php $mvweb_staff = mvweb_theme_questions_staff( $mvweb_comment ); ?>
						<div class="mvweb-t-qa__answer<?php echo $mvweb_staff ? '' : ' mvweb-t-qa__answer--guest'; ?>" id="comment-<?php echo (int) $mvweb_comment->comment_ID; ?>">
							<?php echo $mvweb_who( $mvweb_comment, $mvweb_staff ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>
							<div class="mvweb-t-qa__text"><?php comment_text( $mvweb_comment ); ?></div>
							<?php echo $mvweb_wait( $mvweb_comment ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>
						</div>
					<?php endforeach; ?>

					<?php if ( $mvweb_reply ) : ?>
						<?php echo str_replace( 'comment-reply-link', 'comment-reply-link mvweb-t-qa__reply', $mvweb_reply ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the link. ?>
					<?php endif; ?>
				</article>
			<?php endforeach; ?>
		</div>

		<?php if ( count( $mvweb_threads ) > 5 ) : ?>
			<button class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-qa__more" type="button" data-qa-show hidden><?php esc_html_e( 'Show more questions', 'brand-market' ); ?></button>
		<?php endif; ?>
	<?php endif; ?>

	<?php
	comment_form(
		array(
			'id_form'              => 'mvweb-t-qa-form',
			'class_container'      => 'comment-respond mvweb-t-qa__ask',
			'class_form'           => 'mvweb-t-form mvweb-t-qa__form',
			'class_submit'         => 'mvweb-t-btn',
			'title_reply'          => __( 'Have a question about the service?', 'brand-market' ),
			/* translators: %s: name of the visitor answered. */
			'title_reply_to'       => __( 'Reply to %s', 'brand-market' ),
			'title_reply_before'   => '<div class="mvweb-t-qa__bar">' . mvweb_theme_icon( 'message-circle', array( 'class' => 'mvweb-t-icon--sm' ) ) . '<span id="reply-title" class="mvweb-t-qa__bar-title">',
			'title_reply_after'    => '</span><button class="mvweb-t-btn mvweb-t-btn--sm mvweb-t-qa__open" type="button" data-qa-open hidden>' . esc_html__( 'Ask a question', 'brand-market' ) . '</button></div>',
			'cancel_reply_before'  => ' <small>',
			'cancel_reply_after'   => '</small>',
			'cancel_reply_link'    => __( 'Cancel', 'brand-market' ),
			'comment_notes_before' => '',
			'comment_notes_after'  => '',
			'logged_in_as'         => '',
			'label_submit'         => __( 'Send the question', 'brand-market' ),
			'submit_button'        => '<button name="%1$s" type="submit" id="%2$s" class="%3$s">%4$s</button>',
			'submit_field'         => '%1$s %2$s',
			'comment_field'        => sprintf(
				'<div class="mvweb-t-field"><label class="mvweb-t-field__label" for="comment">%s</label><textarea class="mvweb-t-field__input" id="comment" name="comment" rows="3" required></textarea></div>',
				esc_html__( 'Question', 'brand-market' )
			) . ( '' !== $mvweb_consent ? '<label class="mvweb-t-check"><input type="checkbox" name="mvweb_comment_agree" value="1" required><span>' . $mvweb_consent . '</span></label>' : '' ),
			'fields'               => array(
				'author' => '<div class="mvweb-t-qa__row">' . $mvweb_field( 'author', __( 'Name', 'brand-market' ), 'text', 'name' ) . $mvweb_field( 'email', __( 'Email: the answer comes here, not published', 'brand-market' ), 'email', 'email' ) . '</div>',
			),
		),
		$mvweb_post
	);
	?>
</div>
<?php if ( $mvweb_wrap ) : ?>
	</div>
</section>
<?php endif; ?>
