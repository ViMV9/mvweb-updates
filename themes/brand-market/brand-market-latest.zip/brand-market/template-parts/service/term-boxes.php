<?php
/**
 * Sections of services as tiles: the picture, the name and the number of services.
 *
 * The same tiles as the view «Cards with a picture» of the block «Product
 * groups». The name and the number follow the card-service-section layout; the
 * picture stands first when the layout keeps it and the section has one. A
 * section without services shows no number.
 *
 * Arguments: terms (sections).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_terms = isset( $args['terms'] ) ? array_filter(
	(array) $args['terms'],
	static function ( $term ) {
		return $term instanceof WP_Term;
	}
) : array();

if ( empty( $mvweb_terms ) ) {
	return;
}

$mvweb_order = mvweb_core_layout_order( 'card-service-section' );
?>
<ul class="mvweb-t-categories__boxes mvweb-t-catalog__boxes">
	<?php foreach ( $mvweb_terms as $mvweb_child ) : ?>
		<?php
		$mvweb_link = get_term_link( $mvweb_child );

		if ( ! is_string( $mvweb_link ) ) {
			continue;
		}

		$mvweb_thumb = absint( get_term_meta( $mvweb_child->term_id, 'thumbnail_id', true ) );
		$mvweb_total = mvweb_core_service_count( $mvweb_child->term_id );
		$mvweb_text  = '';

		foreach ( $mvweb_order as $mvweb_slug ) {
			if ( 'title' === $mvweb_slug ) {
				$mvweb_text .= '<span class="mvweb-t-categories__box-name">' . esc_html( $mvweb_child->name ) . '</span>';
			} elseif ( 'count' === $mvweb_slug && $mvweb_total > 0 ) {
				/* translators: %s: number of services in the section. */
				$mvweb_text .= '<span class="mvweb-t-categories__box-count">' . esc_html( sprintf( _n( '%s service', '%s services', $mvweb_total, 'brand-market' ), number_format_i18n( $mvweb_total ) ) ) . '</span>';
			}
		}
		?>
		<li>
			<a class="mvweb-t-categories__box" href="<?php echo esc_url( $mvweb_link ); ?>">
				<?php if ( in_array( 'image', $mvweb_order, true ) && wp_attachment_is_image( $mvweb_thumb ) ) : ?>
					<span class="mvweb-t-categories__box-pic" aria-hidden="true">
						<?php
						echo wp_get_attachment_image(
							$mvweb_thumb,
							'medium_large',
							false,
							array(
								'alt'     => $mvweb_child->name,
								'loading' => 'lazy',
								'sizes'   => '(max-width: 600px) 45vw, 13rem',
							)
						);
						?>
					</span>
				<?php endif; ?>
				<?php if ( in_array( 'title', $mvweb_order, true ) ) : ?>
					<span class="mvweb-t-categories__box-text"><?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in place. ?></span>
				<?php else : ?>
					<span class="screen-reader-text"><?php echo esc_html( $mvweb_child->name ); ?></span>
					<?php if ( '' !== $mvweb_text ) : ?>
						<span class="mvweb-t-categories__box-text"><?php echo $mvweb_text; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in place. ?></span>
					<?php endif; ?>
				<?php endif; ?>
			</a>
		</li>
	<?php endforeach; ?>
</ul>
