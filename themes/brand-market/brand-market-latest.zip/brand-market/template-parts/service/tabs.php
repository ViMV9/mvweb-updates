<?php
/**
 * The tabs of a service: description, prices, reviews and contacts.
 *
 * A tab with nothing to show is left out; a single one is printed without the
 * switches. Every panel is in the page, those after the first hidden until
 * their tab is chosen.
 *
 * Arguments: id (service).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tabs = mvweb_theme_service_tabs( absint( $args['id'] ) );

if ( empty( $mvweb_tabs ) ) {
	return;
}

$mvweb_switch = count( $mvweb_tabs ) > 1;
$mvweb_first  = array_key_first( $mvweb_tabs );
?>
<div class="mvweb-t-service__tabs" id="mvweb-t-service-tabs"<?php echo $mvweb_switch ? ' data-tabs' : ''; ?>>
	<?php if ( $mvweb_switch ) : ?>
		<div class="mvweb-t-service__tablist" role="tablist">
			<?php foreach ( $mvweb_tabs as $mvweb_key => $mvweb_tab ) : ?>
				<button class="mvweb-t-service__tab" type="button" data-tab="<?php echo esc_attr( $mvweb_key ); ?>" aria-selected="<?php echo $mvweb_key === $mvweb_first ? 'true' : 'false'; ?>"<?php echo $mvweb_key === $mvweb_first ? '' : ' tabindex="-1"'; ?>><?php echo esc_html( $mvweb_tab['title'] ); ?></button>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<?php foreach ( $mvweb_tabs as $mvweb_key => $mvweb_tab ) : ?>
		<div class="mvweb-t-service__panel mvweb-t-service__panel--<?php echo esc_attr( $mvweb_key ); ?>"<?php echo $mvweb_switch ? ' data-tabpanel="' . esc_attr( $mvweb_key ) . '"' . ( $mvweb_key === $mvweb_first ? '' : ' hidden' ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in place. ?>>
			<?php echo $mvweb_tab['html']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Text of the service through the_content, code cleaned on save, or the contacts block. ?>
		</div>
	<?php endforeach; ?>
</div>
