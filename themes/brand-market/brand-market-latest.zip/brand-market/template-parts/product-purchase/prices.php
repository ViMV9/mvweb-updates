<?php
/**
 * Purchase box part: the price, the old price, the second and the wholesale price.
 *
 * The prices come from the core whichever store answers; a sale is told from
 * the markup WooCommerce gives, the wholesale line shows when the shop sells
 * at wholesale.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : 0;

if ( 0 === $mvweb_id ) {
	return;
}

$mvweb_value = mvweb_core_item_price_html( $mvweb_id );
$mvweb_old   = '';

if ( false !== strpos( $mvweb_value, '<ins' ) && preg_match( '~<del[^>]*>(.*?)</del>~s', $mvweb_value, $mvweb_del ) && preg_match( '~<ins[^>]*>(.*?)</ins>~s', $mvweb_value, $mvweb_ins ) ) {
	$mvweb_old   = $mvweb_del[1];
	$mvweb_value = $mvweb_ins[1];
}

$mvweb_request = '' === trim( wp_strip_all_tags( $mvweb_value ) );
$mvweb_empty   = $mvweb_request ? mvweb_core_price_placeholder() : '';
$mvweb_label   = $mvweb_request ? '' : (string) mvweb_core_option( 'mvweb_price_label' );
$mvweb_second  = mvweb_core_item_second_price_line( $mvweb_id );
$mvweb_second  = is_string( $mvweb_second ) && '' !== trim( wp_strip_all_tags( $mvweb_second ) ) ? $mvweb_second : '';
$mvweb_whole   = $mvweb_request ? '' : mvweb_core_item_wholesale_line( $mvweb_id );
$mvweb_from    = '' !== $mvweb_whole ? mvweb_core_item_wholesale_from( $mvweb_id ) : 0;
$mvweb_unit    = mvweb_core_qty_unit( $mvweb_id );

if ( $mvweb_request && '' === $mvweb_empty && '' === $mvweb_second ) {
	return;
}
?>
<div class="mvweb-t-product-prices">
	<?php if ( ! $mvweb_request || '' !== $mvweb_empty ) : ?>
		<div class="mvweb-t-product-prices__row">
			<?php if ( $mvweb_request ) : ?>
				<span class="mvweb-t-product-prices__value"><?php echo esc_html( $mvweb_empty ); ?></span>
			<?php else : ?>
				<span class="mvweb-t-product-prices__value"><?php echo '' !== mvweb_core_price_icon() ? mvweb_theme_icon( mvweb_core_price_icon(), array( 'class' => 'mvweb-t-product-prices__icon' ) ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?><?php echo wp_kses_post( $mvweb_value ); ?></span>
				<?php if ( '' !== $mvweb_old ) : ?>
					<span class="mvweb-t-price__old"><?php echo wp_kses_post( $mvweb_old ); ?></span>
				<?php endif; ?>
				<?php if ( '' !== $mvweb_label ) : ?>
					<span class="mvweb-t-product-prices__label"><?php echo esc_html( $mvweb_label ); ?></span>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php if ( '' !== $mvweb_second ) : ?>
		<div class="mvweb-t-product-prices__row mvweb-t-product-prices__row--second-price">
			<span class="mvweb-t-product-prices__value"><?php echo wp_kses_post( $mvweb_second ); ?></span>
			<?php if ( '' !== (string) mvweb_core_option( 'mvweb_second_price_label' ) ) : ?>
				<span class="mvweb-t-product-prices__label"><?php echo esc_html( (string) mvweb_core_option( 'mvweb_second_price_label' ) ); ?></span>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php if ( '' !== $mvweb_whole ) : ?>
		<div class="mvweb-t-product-prices__row mvweb-t-product-prices__row--second-price mvweb-t-product-prices__row--whole">
			<span class="mvweb-t-product-prices__value"><?php echo wp_kses_post( $mvweb_whole ); ?></span>
			<span class="mvweb-t-product-prices__label">
				<?php
				echo esc_html(
					$mvweb_from > 1
						/* translators: 1: wholesale caption, 2: minimum quantity, 3: unit, for example pcs. */
						? sprintf( __( '%1$s, from %2$d %3$s', 'brand-market' ), mvweb_core_wholesale_label(), $mvweb_from, '' !== $mvweb_unit ? $mvweb_unit : __( 'pcs', 'brand-market' ) )
						: mvweb_core_wholesale_label()
				);
				?>
			</span>
			<?php get_template_part( 'template-parts/wholesale-hint' ); ?>
		</div>
	<?php endif; ?>
</div>
