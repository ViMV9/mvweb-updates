<?php
/**
 * Footer contacts part: Address; the hours of each place when the places of the city keep different hours.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_contacts  = isset( $args['contacts'] ) && is_array( $args['contacts'] ) ? $args['contacts'] : array();
$mvweb_addresses = isset( $mvweb_contacts['addresses'] ) ? (array) $mvweb_contacts['addresses'] : array();
$mvweb_own_hours = empty( $mvweb_contacts['hours'] ) && count( $mvweb_addresses ) > 1 && mvweb_core_layout_has( 'footer.contacts', 'hours' );

foreach ( $mvweb_addresses as $mvweb_place ) :
	$mvweb_street = trim( (string) $mvweb_place['address'] );
	$mvweb_city   = trim( (string) $mvweb_place['city'] );

	if ( '' === $mvweb_street ) {
		continue;
	}

	$mvweb_line  = '' === $mvweb_city || str_contains( $mvweb_street, $mvweb_city ) ? $mvweb_street : $mvweb_city . ', ' . $mvweb_street;
	$mvweb_name  = count( $mvweb_addresses ) > 1 ? trim( (string) $mvweb_place['title'] ) : '';
	$mvweb_hours = $mvweb_own_hours ? mvweb_core_hours_line( (array) $mvweb_place['hours'] ) : '';
	?>
	<li class="mvweb-t-footer__item">
		<?php if ( '' !== $mvweb_name ) : ?>
			<span class="mvweb-t-footer__note"><?php echo esc_html( $mvweb_name ); ?></span>
		<?php endif; ?>

		<address class="mvweb-t-footer__address"><?php echo esc_html( $mvweb_line ); ?></address>

		<?php if ( '' !== $mvweb_hours ) : ?>
			<span class="mvweb-t-footer__note"><?php echo esc_html( $mvweb_hours ); ?></span>
		<?php endif; ?>
	</li>
	<?php
endforeach;
