<?php
/**
 * Services listing part: the services themselves.
 *
 * The list is the grid of cards, page by page, or what the listing mode asks
 * for instead: every section of the next level as a tile with the services
 * filed beside them as cards under the tiles, or every section as a tree with
 * its services listed. The text under the list follows it, on the
 * first page only. A section without services prints no notice: its own
 * text is the page, the services come later. A section that prints the plain
 * grid shows it as its own setting asks: cards page by page or one button over
 * all of them, before or after its text, or only where the shortcode in the
 * text stands.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_level = mvweb_core_service_level();
$mvweb_text  = mvweb_core_listing_text();
$mvweb_tree  = null !== $mvweb_level && 'tree' === mvweb_core_service_list_mode();
$mvweb_term  = is_tax( 'mv_service_cat' ) ? get_queried_object() : null;
$mvweb_leaf  = null === $mvweb_level && $mvweb_term instanceof WP_Term ? mvweb_theme_leaf( $mvweb_term->term_id ) : null;
$mvweb_after = null !== $mvweb_leaf && 'after' === $mvweb_leaf['place'];
$mvweb_prose = static function () use ( $mvweb_text ) {
	if ( '' === $mvweb_text ) {
		return;
	}
	?>
	<div class="mvweb-t-prose mvweb-t-catalog__text" data-prose>
		<?php echo apply_filters( 'the_content', $mvweb_text ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The key is registered with wp_kses_post, and the_content closes with kses of its own. ?>
	</div>
	<?php
};
?>

<?php if ( $mvweb_tree ) : ?>
	<section class="mvweb-t-section mvweb-t-section--flush-top">
		<div class="mvweb-t-container">
			<div class="mvweb-t-svc-tree">
				<?php
				foreach ( $mvweb_level['terms'] as $mvweb_child ) {
					get_template_part( 'template-parts/service/tree-group', null, array( 'term' => $mvweb_child ) );
				}

				get_template_part( 'template-parts/service/tree-group', null, array( 'services' => $mvweb_level['services'] ) );
				?>
			</div>
<?php else : ?>
	<section class="mvweb-t-catalog">
		<div class="mvweb-t-container">
		<?php
		if ( $mvweb_after ) {
			$mvweb_prose();
		}
		?>
		<?php if ( null !== $mvweb_level ) : ?>
			<?php get_template_part( 'template-parts/service/term-boxes', null, array( 'terms' => $mvweb_level['terms'] ) ); ?>

			<?php if ( ! empty( $mvweb_level['services'] ) ) : ?>
				<div class="mvweb-t-catalog__grid mvweb-t-catalog__grid--services">
					<?php
					foreach ( $mvweb_level['services'] as $mvweb_service ) {
						get_template_part( 'template-parts/service/card', null, array( 'id' => $mvweb_service ) );
					}
					?>
				</div>
			<?php endif; ?>
		<?php elseif ( null !== $mvweb_leaf && ( $mvweb_leaf['code'] || 'button' === $mvweb_leaf['view'] ) ) : ?>
			<?php echo $mvweb_leaf['code'] ? '' : mvweb_theme_leaf_list( $mvweb_term, 'button' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper and the card template. ?>
		<?php elseif ( have_posts() ) : ?>
			<div class="mvweb-t-catalog__grid mvweb-t-catalog__grid--services">
				<?php
				while ( have_posts() ) :
					the_post();

					get_template_part(
						'template-parts/service/card',
						null,
						array(
							'id'    => get_the_ID(),
							'eager' => $GLOBALS['wp_query']->current_post < 4,
						)
					);
				endwhile;
				?>
			</div>

			<?php mvweb_theme_pagination(); ?>
		<?php endif; ?>
<?php endif; ?>

		<?php
		if ( ! $mvweb_after ) {
			$mvweb_prose();
		}
		?>

	</div>
</section>
