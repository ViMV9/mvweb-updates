<?php
/**
 * Service card line: the price and the arrow in the order of the layout, the
 * arrow pressed to the right. A card without a price has no line, and no arrow.
 *
 * Not a part of the layout itself: the price and more parts call it, and only
 * the first of them prints.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_order = array_values( array_intersect( mvweb_core_layout_order( 'card-service' ), array( 'price', 'more' ) ) );

if ( empty( $mvweb_order ) || $mvweb_order[0] !== $args['part'] ) {
	return;
}

$mvweb_id    = absint( $args['id'] );
$mvweb_price = mvweb_core_service_price( $mvweb_id );

if ( '' === trim( wp_strip_all_tags( $mvweb_price ) ) ) {
	$mvweb_price = esc_html( mvweb_core_service_price_placeholder() );
}

if ( '' === $mvweb_price ) {
	return;
}

$mvweb_bits = array(
	'price' => '<div class="mvweb-t-price">' . $mvweb_price . '</div>',
	'more'  => '<span class="mvweb-t-card__arrow" aria-hidden="true">' . mvweb_theme_icon( 'arrow-right' ) . '</span>',
);

$mvweb_html = '';

foreach ( $mvweb_order as $mvweb_slug ) {
	$mvweb_html .= $mvweb_bits[ $mvweb_slug ];
}

if ( '' === $mvweb_html ) {
	return;
}
?>
<div class="mvweb-t-card__foot"><?php echo $mvweb_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values. ?></div>
