<?php
/**
 * Post card part: the number of comments, a link to them.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_count = (int) get_comments_number();

if ( 0 === $mvweb_count && ! comments_open() ) {
	return;
}

/* translators: %s: number of comments. */
$mvweb_label = sprintf( _n( '%s comment', '%s comments', $mvweb_count, 'brand-market' ), number_format_i18n( $mvweb_count ) );
?>
<a class="mvweb-t-post-card__count" href="<?php echo esc_url( get_comments_link() ); ?>">
	<?php echo mvweb_theme_icon( 'message-circle', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<span aria-hidden="true"><?php echo esc_html( number_format_i18n( $mvweb_count ) ); ?></span>
	<span class="screen-reader-text"><?php echo esc_html( $mvweb_label ); ?></span>
</a>
