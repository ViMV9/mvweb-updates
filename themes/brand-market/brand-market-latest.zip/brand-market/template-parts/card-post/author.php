<?php
/**
 * Post card part: the author with the photo, a link to the author page.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_author = (int) get_the_author_meta( 'ID' );
$mvweb_name   = (string) get_the_author_meta( 'display_name', $mvweb_author );

if ( '' === $mvweb_name ) {
	return;
}

$mvweb_avatar = (string) get_avatar(
	$mvweb_author,
	48,
	'',
	'',
	array(
		'class'         => 'mvweb-t-avatar',
		'force_display' => false,
		'loading'       => 'lazy',
	)
);
?>
<a class="mvweb-t-post-card__author" href="<?php echo esc_url( get_author_posts_url( $mvweb_author ) ); ?>">
	<?php echo $mvweb_avatar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag. ?>
	<span><?php echo esc_html( $mvweb_name ); ?></span>
</a>
