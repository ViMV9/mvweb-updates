<?php
/**
 * Zone element: Other items of the header row.
 *
 * The place in the header row where the zone "Header row: other items" stands:
 * icons, cart, phone, hours and the rest, in the order set in that zone.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_phone_copies = '';

if ( 'simple' === get_theme_mod( 'mvweb_header_layout', 'simple' ) ) {
	$mvweb_here  = array_merge( mvweb_core_zone_order( 'header-actions' ), mvweb_core_zone_order( 'header-main' ) );
	$mvweb_strip = mvweb_core_zone_order( 'header-nav' );

	foreach ( array( 'account', 'cart' ) as $mvweb_slug ) {
		if ( in_array( $mvweb_slug, $mvweb_strip, true ) && ! in_array( $mvweb_slug, $mvweb_here, true ) ) {
			$mvweb_phone_copies .= (string) preg_replace( '/class="/', 'class="mvweb-t-round--sm-only ', mvweb_core_element_html( 'header-actions', $mvweb_slug ), 1 );
		}
	}
}

?>
<div class="mvweb-t-header__actions">
	<?php echo mvweb_theme_zone_html( 'header-actions' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped element templates. ?>
	<?php echo $mvweb_phone_copies; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by the element templates. ?>
	<?php get_template_part( 'template-parts/elements/burger' ); ?>
</div>
