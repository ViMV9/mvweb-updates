<?php
/**
 * Zone element: Action button.
 *
 * The icon, the look and the place on a phone come from "MVweb: Conversion".
 * In the menu the button stands full width and always shows. In the header of
 * a phone it shows only its icon, the phone one when no icon is chosen.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_context = isset( $args['context'] ) ? $args['context'] : 'bar';
$mvweb_url     = mvweb_cz_get( 'mvweb_cta_url', '' );

if ( '' === $mvweb_url ) {
	return;
}

$mvweb_text   = mvweb_cz_get( 'mvweb_cta_text', __( 'Request a quote', 'brand-market' ) );
$mvweb_icon   = (string) mvweb_cz_get( 'mvweb_cta_icon', '' );
$mvweb_icon   = isset( mvweb_core_icon_choices()[ $mvweb_icon ] ) ? $mvweb_icon : '';
$mvweb_phone  = 'drawer' !== $mvweb_context && 'bar' === mvweb_cz_get( 'mvweb_cta_phone', 'menu' );
$mvweb_class  = 'mvweb-t-el-cta mvweb-t-btn' . ( 'outline' === mvweb_cz_get( 'mvweb_cta_look', 'fill' ) ? ' mvweb-t-btn--outline' : '' );
$mvweb_class .= 'drawer' === $mvweb_context ? ' mvweb-t-btn--block' : ' mvweb-t-btn--sm' . ( $mvweb_phone ? ' mvweb-t-el-cta--phone' : ' mvweb-t-el-cta--wide' );
?>
<a class="<?php echo esc_attr( $mvweb_class ); ?>" href="<?php echo esc_url( $mvweb_url ); ?>"<?php echo $mvweb_phone ? ' title="' . esc_attr( $mvweb_text ) . '"' : ''; ?>>
	<?php if ( '' !== $mvweb_icon ) : ?>
		<?php echo mvweb_theme_icon( $mvweb_icon, array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<?php elseif ( $mvweb_phone ) : ?>
		<?php echo mvweb_theme_icon( 'phone', array( 'class' => 'mvweb-t-icon--sm mvweb-t-el-cta__phone-icon' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<?php endif; ?>
	<span class="mvweb-t-el-cta__text"><?php echo esc_html( $mvweb_text ); ?></span>
</a>
