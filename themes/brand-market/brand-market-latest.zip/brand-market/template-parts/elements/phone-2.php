<?php
/**
 * Zone element: Phone 2, the second number of the chosen city.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_template_part( 'template-parts/elements/phone', null, array_merge( (array) $args, array( 'nth' => 1 ) ) );
