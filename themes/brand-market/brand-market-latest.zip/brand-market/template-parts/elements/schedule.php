<?php
/**
 * Zone element: Opening hours.
 *
 * Right after the phone in a bar it is printed by the phone, as the line under
 * the number. Anywhere else it stands on its own; in the mobile menu it lists
 * every row of the hours.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_zone     = isset( $args['zone'] ) ? $args['zone'] : '';
$mvweb_context  = isset( $args['context'] ) ? $args['context'] : 'bar';
$mvweb_contacts = mvweb_core_contacts();

if ( empty( $mvweb_contacts['hours'] ) ) {
	return;
}

if ( 'drawer' === $mvweb_context ) :
	?>
	<p class="mvweb-t-el-schedule mvweb-t-drawer__hours">
		<?php foreach ( $mvweb_contacts['hours'] as $mvweb_row ) : ?>
			<span>
				<?php echo esc_html( $mvweb_row['days'] ); ?>
				<b><?php echo esc_html( $mvweb_row['time'] ); ?></b>
			</span>
		<?php endforeach; ?>
	</p>
	<?php
	return;
endif;

if ( mvweb_theme_header_facts( $mvweb_zone ) ) {
	$mvweb_caption = (string) get_theme_mod( 'mvweb_header_facts_hours', '' );

	get_template_part(
		'template-parts/header/fact',
		null,
		array(
			'icon'  => 'clock',
			'value' => mvweb_core_hours_line( array_slice( $mvweb_contacts['hours'], 0, 1 ) ),
			'note'  => '' !== trim( $mvweb_caption ) ? $mvweb_caption : mvweb_core_hours_line( array_slice( $mvweb_contacts['hours'], 1 ) ),
			'class' => 'mvweb-t-fact--hours',
		)
	);

	return;
}

if ( 'phone' === mvweb_core_zone_neighbour( $mvweb_zone, 'schedule', -1 ) && ! empty( $mvweb_contacts['phones'] ) ) {
	return;
}
?>
<p class="mvweb-t-el-schedule"><?php echo esc_html( mvweb_core_hours_line( $mvweb_contacts['hours'] ) ); ?></p>
