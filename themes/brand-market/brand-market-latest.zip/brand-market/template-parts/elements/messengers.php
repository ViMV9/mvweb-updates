<?php
/**
 * Zone element: Messengers.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_context = isset( $args['context'] ) ? $args['context'] : 'bar';
$mvweb_links   = mvweb_core_header_messengers();

if ( empty( $mvweb_links ) ) {
	return;
}

$mvweb_drawer = 'drawer' === $mvweb_context;
$mvweb_round  = 'mvweb-t-round' . ( isset( $args['zone'] ) && 'header-nav' === $args['zone'] ? ' mvweb-t-round--ghost' : '' );
?>
<div class="mvweb-t-el-messengers <?php echo $mvweb_drawer ? 'mvweb-t-drawer__messengers' : 'mvweb-t-header__messengers'; ?>">
	<?php foreach ( $mvweb_links as $mvweb_id => $mvweb_link ) : ?>
		<a class="<?php echo esc_attr( $mvweb_drawer ? 'mvweb-t-drawer__messenger' : $mvweb_round ); ?>" href="<?php echo esc_url( $mvweb_link['url'] ); ?>" title="<?php echo esc_attr( $mvweb_link['label'] ); ?>" rel="noopener" target="_blank">
			<?php echo mvweb_theme_icon( mvweb_core_social_icon( $mvweb_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span<?php echo $mvweb_drawer ? '' : ' class="screen-reader-text"'; ?>><?php echo esc_html( $mvweb_link['label'] ); ?></span>
		</a>
	<?php endforeach; ?>
</div>
