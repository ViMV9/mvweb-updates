<?php
/**
 * Zone element: Phone.
 *
 * In a bar it is the first number of the chosen city, or the number given as
 * nth (the element "Phone 2"); the hours element that follows the first number
 * in the same zone becomes the line under it. In the mobile menu it is every
 * number with its caption.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_zone     = isset( $args['zone'] ) ? $args['zone'] : '';
$mvweb_context  = isset( $args['context'] ) ? $args['context'] : 'bar';
$mvweb_contacts = mvweb_core_contacts();
$mvweb_phones   = $mvweb_contacts['phones'];
$mvweb_nth      = isset( $args['nth'] ) ? (int) $args['nth'] : 0;

if ( ! isset( $mvweb_phones[ $mvweb_nth ] ) || ( $mvweb_nth > 0 && 'drawer' === $mvweb_context ) ) {
	return;
}

if ( 'drawer' === $mvweb_context ) :
	?>
	<div class="mvweb-t-el-phone mvweb-t-drawer__phones">
		<?php foreach ( $mvweb_phones as $mvweb_phone ) : ?>
			<?php $mvweb_tag = '' === $mvweb_phone['href'] ? 'span' : 'a'; ?>
			<<?php echo esc_html( $mvweb_tag ); ?> class="mvweb-t-drawer__phone"<?php echo 'a' === $mvweb_tag ? ' href="' . esc_url( $mvweb_phone['href'] ) . '"' : ''; ?>>
				<?php if ( '' !== $mvweb_phone['label'] ) : ?>
					<span class="mvweb-t-drawer__phone-label"><?php echo esc_html( $mvweb_phone['label'] ); ?></span>
				<?php endif; ?>
				<span class="mvweb-t-drawer__phone-num"><?php echo esc_html( $mvweb_phone['number'] ); ?></span>
			</<?php echo esc_html( $mvweb_tag ); ?>>
		<?php endforeach; ?>
	</div>
	<?php
	return;
endif;

$mvweb_first = $mvweb_phones[ $mvweb_nth ];

if ( mvweb_theme_header_facts( $mvweb_zone ) ) :
	$mvweb_label = trim( (string) $mvweb_first['label'] );

	get_template_part(
		'template-parts/header/fact',
		null,
		array(
			'icon'  => 'phone',
			'value' => $mvweb_first['number'],
			'note'  => '' !== $mvweb_label ? $mvweb_label : ( 0 === $mvweb_nth ? get_theme_mod( 'mvweb_header_facts_phone', __( 'Call us', 'brand-market' ) ) : '' ),
			'href'  => $mvweb_first['href'],
			'class' => 'mvweb-t-fact--phone',
		)
	);

	if ( 0 === $mvweb_nth && '' !== $mvweb_phones[0]['href'] ) :
		?>
		<a class="mvweb-t-round mvweb-t-fact-call" href="<?php echo esc_url( $mvweb_phones[0]['href'] ); ?>" title="<?php echo esc_attr( $mvweb_phones[0]['number'] ); ?>">
			<?php echo mvweb_theme_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span class="screen-reader-text"><?php echo esc_html( $mvweb_phones[0]['number'] ); ?></span>
		</a>
		<?php
	endif;

	return;
endif;

$mvweb_tag  = '' === $mvweb_first['href'] ? 'span' : 'a';
$mvweb_note = 0 === $mvweb_nth && 'schedule' === mvweb_core_zone_neighbour( $mvweb_zone, 'phone', 1 ) ? mvweb_core_hours_line( $mvweb_contacts['hours'] ) : '';
$mvweb_icon  = 'none' !== get_theme_mod( 'mvweb_header_phone_icon', 'none' );
?>
<div class="mvweb-t-el-phone">
	<?php if ( $mvweb_icon ) : ?>
		<span class="mvweb-t-el-phone__ico"><?php echo mvweb_theme_icon( 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
	<?php endif; ?>
	<<?php echo esc_html( $mvweb_tag ); ?> class="mvweb-t-el-phone__number"<?php echo 'a' === $mvweb_tag ? ' href="' . esc_url( $mvweb_first['href'] ) . '"' : ''; ?>><?php echo esc_html( $mvweb_first['number'] ); ?></<?php echo esc_html( $mvweb_tag ); ?>>
	<?php if ( '' !== $mvweb_note ) : ?>
		<span class="mvweb-t-el-phone__note"><?php echo esc_html( $mvweb_note ); ?></span>
	<?php endif; ?>
</div>
