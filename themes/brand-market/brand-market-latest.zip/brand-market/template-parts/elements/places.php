<?php
/**
 * Zone element: Addresses of the city in the header row.
 *
 * One place: its address and its hours with the status. Several places: their
 * names in a row, each with a window; where the row does not fit, one button
 * with the list.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_places = mvweb_core_header_addresses( mvweb_core_contacts() );
$mvweb_count  = count( $mvweb_places );

if ( 0 === $mvweb_count ) {
	return;
}

if ( 1 === $mvweb_count ) :
	$mvweb_place = $mvweb_places[0];
	$mvweb_hours = mvweb_core_hours_line( $mvweb_place['hours'] );
	$mvweb_note  = trim( (string) $mvweb_place['note'] );
	$mvweb_title = trim( (string) $mvweb_place['title'] );
	?>
	<div class="mvweb-t-el-places mvweb-t-el-places--one">
		<div class="mvweb-t-el-places__fact">
			<span class="mvweb-t-el-places__ico"><?php echo mvweb_theme_icon( 'map-pin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
			<span class="mvweb-t-el-places__text">
				<b><?php echo esc_html( ( '' !== $mvweb_title ? $mvweb_title . ', ' : '' ) . trim( (string) $mvweb_place['address'] ) ); ?></b>
				<span class="mvweb-t-el-places__sub">
					<?php if ( '' !== $mvweb_note ) : ?>
						<span class="mvweb-t-el-places__note"><?php echo esc_html( $mvweb_note ); ?></span>
					<?php endif; ?>
					<?php echo mvweb_theme_place_status( $mvweb_place ) . mvweb_theme_place_route( $mvweb_place ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts. ?>
				</span>
			</span>
		</div>
		<?php if ( '' !== $mvweb_hours ) : ?>
			<div class="mvweb-t-el-places__fact mvweb-t-el-places__hours">
				<span class="mvweb-t-el-places__ico"><?php echo mvweb_theme_icon( 'clock' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
				<span class="mvweb-t-el-places__text"><b><?php echo esc_html( $mvweb_hours ); ?></b></span>
			</div>
		<?php endif; ?>
	</div>
	<?php
	return;
endif;

$mvweb_id = wp_unique_id( 'mvweb-t-places-' );
?>
<div class="mvweb-t-el-places">
	<?php if ( $mvweb_count <= 5 ) : ?>
		<ul class="mvweb-t-el-places__row">
			<?php foreach ( $mvweb_places as $mvweb_place ) : ?>
				<?php $mvweb_one = wp_unique_id( 'mvweb-t-place-' ); ?>
				<li class="mvweb-t-el-places__item" data-places>
					<button class="mvweb-t-el-places__btn" type="button" aria-expanded="false" aria-controls="<?php echo esc_attr( $mvweb_one ); ?>" data-places-toggle>
						<b><?php echo esc_html( mvweb_theme_place_name( $mvweb_place ) ); ?></b>
						<?php echo mvweb_theme_place_status( $mvweb_place, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped attribute. ?>
					</button>
					<?php echo mvweb_theme_places_pop( array( $mvweb_place ), $mvweb_one ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts. ?>
				</li>
			<?php endforeach; ?>
		</ul>
	<?php endif; ?>

	<div class="mvweb-t-el-places__more" data-places>
		<button class="mvweb-t-el-places__btn" type="button" aria-expanded="false" aria-controls="<?php echo esc_attr( $mvweb_id ); ?>" data-places-toggle>
			<?php echo mvweb_theme_icon( 'map-pin', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<b>
				<?php
				/* translators: %d: number of addresses in the city. */
				echo esc_html( sprintf( _n( '%d address', '%d addresses', $mvweb_count, 'brand-market' ), $mvweb_count ) );
				?>
			</b>
			<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		</button>
		<?php echo mvweb_theme_places_pop( $mvweb_places, $mvweb_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts. ?>
	</div>
</div>
