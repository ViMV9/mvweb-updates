<?php
/**
 * Zone element: Footer contacts, the column of the chosen city.
 *
 * The parts inside the column, their order and their visibility come from the
 * footer.contacts layout. The ways to pay follow when the footer keeps them
 * under the contacts; with them alone the column still stands.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

ob_start();
mvweb_core_render_layout( 'footer.contacts', array( 'contacts' => mvweb_core_contacts() ) );
$mvweb_parts = trim( (string) ob_get_clean() );

ob_start();
mvweb_theme_payments( 'contacts' );
$mvweb_pay = trim( (string) ob_get_clean() );

if ( '' === $mvweb_parts && '' === $mvweb_pay ) {
	return;
}

$mvweb_title = trim( (string) mvweb_cz_get( 'mvweb_footer_contacts_title' ) );
?>
<div class="mvweb-t-el-contacts mvweb-t-footer__col">
	<?php if ( '' !== $mvweb_title && '' !== $mvweb_parts ) : ?>
		<div class="mvweb-t-footer__title"><?php echo esc_html( $mvweb_title ); ?></div>
	<?php endif; ?>

	<?php if ( '' !== $mvweb_parts ) : ?>
		<ul class="mvweb-t-footer__list mvweb-t-footer__contacts">
			<?php echo $mvweb_parts; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped part templates. ?>
		</ul>
	<?php endif; ?>

	<?php echo $mvweb_pay; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the escaped template of the ways to pay. ?>
</div>
