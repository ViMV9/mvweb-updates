<?php
/**
 * Zone element: Footer brand, the logo with the tagline and the social networks.
 *
 * The ways to pay follow when the footer keeps them under the logo.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tagline = trim( (string) mvweb_cz_get( 'mvweb_footer_tagline', '' ) );

if ( '' === $mvweb_tagline ) {
	$mvweb_tagline = get_bloginfo( 'description' );
}

$mvweb_socials       = mvweb_cz_profile_socials();
$mvweb_socials_title = trim( (string) mvweb_cz_get( 'mvweb_footer_socials_title' ) );
?>
<div class="mvweb-t-el-brand mvweb-t-footer__brand">
	<?php
	mvweb_theme_logo(
		array(
			'lazy'   => true,
			'footer' => true,
		)
	);
	?>

	<?php if ( '' !== $mvweb_tagline ) : ?>
		<p class="mvweb-t-footer__about"><?php echo esc_html( $mvweb_tagline ); ?></p>
	<?php endif; ?>

	<?php if ( ! empty( $mvweb_socials ) && '' !== $mvweb_socials_title ) : ?>
		<div class="mvweb-t-footer__title"><?php echo esc_html( $mvweb_socials_title ); ?></div>
	<?php endif; ?>

	<?php if ( ! empty( $mvweb_socials ) ) : ?>
		<div class="mvweb-t-footer__socials">
			<?php foreach ( $mvweb_socials as $mvweb_id => $mvweb_link ) : ?>
				<a class="mvweb-t-round" href="<?php echo esc_url( $mvweb_link['url'] ); ?>" title="<?php echo esc_attr( $mvweb_link['label'] ); ?>" rel="noopener" target="_blank">
					<?php echo mvweb_theme_icon( mvweb_core_social_icon( $mvweb_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<span class="screen-reader-text"><?php echo esc_html( $mvweb_link['label'] ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<?php mvweb_theme_payments( 'brand' ); ?>
</div>
