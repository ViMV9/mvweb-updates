<?php
/**
 * Zone element: My service centre.
 *
 * One place of the city stands in the header row: its name and whether it is
 * open now. The button opens the places of the city; where there are several,
 * the visitor chooses one and the browser remembers it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_places = mvweb_core_header_addresses( mvweb_core_contacts() );
$mvweb_count  = count( $mvweb_places );

if ( 0 === $mvweb_count ) {
	return;
}

$mvweb_id = wp_unique_id( 'mvweb-t-store-' );
?>
<div class="mvweb-t-el-store" data-places<?php echo $mvweb_count > 1 ? ' data-store' : ''; ?>>
	<button class="mvweb-t-el-store__btn" type="button" aria-expanded="false" aria-controls="<?php echo esc_attr( $mvweb_id ); ?>" data-places-toggle>
		<span class="mvweb-t-el-store__ico"><?php echo mvweb_theme_icon( 'map-pin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
		<span class="mvweb-t-el-store__now">
			<?php foreach ( $mvweb_places as $mvweb_i => $mvweb_place ) : ?>
				<span class="mvweb-t-el-store__cur" data-store-cur<?php echo $mvweb_i ? ' hidden' : ''; ?>>
					<b><?php echo esc_html( mvweb_theme_place_name( $mvweb_place ) ); ?></b>
					<?php echo mvweb_theme_place_status( $mvweb_place, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped attribute. ?>
				</span>
			<?php endforeach; ?>
		</span>
		<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	</button>
	<div class="mvweb-t-city__pop mvweb-t-hc__places-pop mvweb-t-el-store__pop" id="<?php echo esc_attr( $mvweb_id ); ?>" data-places-pop hidden>
		<?php echo mvweb_theme_places_items( $mvweb_places, $mvweb_count > 1 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts. ?>
	</div>
</div>
