<?php
/**
 * Zone element: Quick buttons.
 *
 * The items of the menu of the bottom bar as icons with a caption, for the
 * header row on a computer; on a phone the same items stand in the bottom bar.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_items = mvweb_core_bottom_nav();

if ( empty( $mvweb_items ) ) {
	return;
}
?>
<nav class="mvweb-t-el-quick" aria-label="<?php esc_attr_e( 'Quick menu', 'brand-market' ); ?>">
	<?php foreach ( $mvweb_items as $mvweb_item ) : ?>
		<a class="<?php echo esc_attr( trim( 'mvweb-t-el-quick__item' . ( $mvweb_item['main'] ? ' mvweb-t-el-quick__item--main' : '' ) . ' ' . $mvweb_item['classes'] ) ); ?>" href="<?php echo esc_url( $mvweb_item['url'] ); ?>"<?php echo $mvweb_item['current'] ? ' aria-current="page"' : ''; ?>>
			<?php echo mvweb_theme_icon( '' === $mvweb_item['icon'] ? ( $mvweb_item['main'] ? 'calendar-check' : 'arrow-right' ) : $mvweb_item['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span><?php echo esc_html( $mvweb_item['title'] ); ?></span>
		</a>
	<?php endforeach; ?>
</nav>
