<?php
/**
 * Card of a blog post.
 *
 * The parts stand in the order the site sets for the area card-post; the
 * cover, the line of meta and the text are wrapped as the design draws them,
 * and a part without data is not printed. Arguments: modifier (lead, compact,
 * wide, narrow, row), tag (the tag of the title), hide (parts the view leaves
 * out), go (arrow over the cover), rv (the card appears with its block).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_args = isset( $args ) && is_array( $args ) ? $args : array();
$mvweb_mod  = isset( $mvweb_args['modifier'] ) ? sanitize_html_class( (string) $mvweb_args['modifier'] ) : '';
$mvweb_row  = 'row' === $mvweb_mod;
$mvweb_hide = isset( $mvweb_args['hide'] ) && is_array( $mvweb_args['hide'] ) ? $mvweb_args['hide'] : array();
$mvweb_out  = array(
	'front' => '',
	'meta'  => '',
	'body'  => '',
	'back'  => '',
);
$mvweb_done = array();
$mvweb_kind = array(
	'media'    => $mvweb_row ? 'back' : 'media',
	'topic'    => 'meta',
	'date'     => $mvweb_row ? 'front' : 'meta',
	'read'     => 'meta',
	'author'   => 'meta',
	'comments' => 'meta',
	'views'    => 'meta',
);

$mvweb_print = static function ( $slug, $part_args ) {
	ob_start();
	get_template_part( 'template-parts/card-post/' . sanitize_key( $slug ), null, $part_args );

	return trim( (string) ob_get_clean() );
};

$mvweb_place = static function ( $slug, $html ) use ( &$mvweb_out, $mvweb_kind ) {
	$kind = isset( $mvweb_kind[ $slug ] ) ? $mvweb_kind[ $slug ] : 'text';

	if ( 'meta' === $kind ) {
		$mvweb_out['meta'] .= $html;
	} elseif ( 'media' === $kind ) {
		$slot = '' === $mvweb_out['body'] && '' === $mvweb_out['meta'] ? 'front' : 'back';

		$mvweb_out[ $slot ] .= $html;
	} elseif ( 'text' === $kind ) {
		if ( '' !== $mvweb_out['meta'] ) {
			$mvweb_out['body'] .= '<div class="mvweb-t-post-card__meta">' . $mvweb_out['meta'] . '</div>';
			$mvweb_out['meta']  = '';
		}

		$mvweb_out['body'] .= $html;
	} else {
		$mvweb_out[ $kind ] .= $html;
	}
};

$mvweb_walk = static function ( $handled, $area, $slug, $part_args ) use ( $mvweb_hide, $mvweb_print, $mvweb_place, &$mvweb_done ) {
	if ( true === $handled || 'card-post' !== $area ) {
		return $handled;
	}

	$html = in_array( $slug, $mvweb_hide, true ) ? '' : $mvweb_print( $slug, $part_args );

	if ( '' !== $html ) {
		$mvweb_place( $slug, $html );
	}

	$mvweb_done[] = $slug;

	return true;
};

add_filter( 'mvweb_core_render_part', $mvweb_walk, 10, 4 );
mvweb_core_render_layout( 'card-post', $mvweb_args );
remove_filter( 'mvweb_core_render_part', $mvweb_walk, 10 );

if ( ! in_array( 'title', $mvweb_done, true ) && ! in_array( 'title', $mvweb_hide, true ) ) {
	$mvweb_place( 'title', $mvweb_print( 'title', $mvweb_args ) );
}

if ( '' !== $mvweb_out['meta'] ) {
	$mvweb_out['body'] .= '<div class="mvweb-t-post-card__meta' . ( '' !== $mvweb_out['body'] ? ' mvweb-t-post-card__meta--foot' : '' ) . '">' . $mvweb_out['meta'] . '</div>';
}

if ( '' === $mvweb_out['front'] . $mvweb_out['body'] . $mvweb_out['back'] ) {
	return;
}
?>
<article class="mvweb-t-post-card<?php echo '' !== $mvweb_mod ? ' mvweb-t-post-card--' . esc_attr( $mvweb_mod ) : ''; ?>" data-id="<?php the_ID(); ?>"<?php echo ! empty( $mvweb_args['rv'] ) ? ' data-rv' : ''; ?>>
	<?php echo $mvweb_out['front']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?>
	<?php if ( '' !== $mvweb_out['body'] ) : ?>
		<div class="mvweb-t-post-card__body"><?php echo $mvweb_out['body']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?></div>
	<?php endif; ?>
	<?php echo $mvweb_out['back']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part templates. ?>
</article>
