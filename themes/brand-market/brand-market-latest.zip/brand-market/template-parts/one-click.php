<?php
/**
 * Order in one click: the dialog behind the button under "Add to cart".
 *
 * It stands after the cart form, since a form cannot hold another one. The
 * script of the theme takes the quantity from the stepper of the page and
 * sends the form to the route of the core; the dialog shows the number of the
 * order or what went wrong.
 *
 * Arguments: product.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_product = isset( $args['product'] ) ? $args['product'] : null;

if ( ! function_exists( 'mvweb_core_one_click' ) || ! mvweb_core_one_click( $mvweb_product ) ) {
	return;
}

$mvweb_policy = get_privacy_policy_url();
$mvweb_phone  = mvweb_core_contact_phone();
$mvweb_tel    = mvweb_core_tel( $mvweb_phone );
?>
<dialog class="mvweb-t-modal" aria-labelledby="mvweb-t-one-click-title" data-one-click>
	<div class="mvweb-t-modal__box">

		<form class="mvweb-t-modal__view mvweb-t-one-click" data-view="form" data-one-click-form data-endpoint="<?php echo esc_url( rest_url( 'mvweb-core/v1/one-click' ) ); ?>" data-nonce="<?php echo is_user_logged_in() ? esc_attr( wp_create_nonce( 'wp_rest' ) ) : ''; ?>">
			<button class="mvweb-t-round mvweb-t-modal__close" type="button" data-one-click-close title="<?php esc_attr_e( 'Close', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Close', 'brand-market' ); ?></span>
			</button>

			<div class="mvweb-t-modal__title mvweb-t-h2" role="heading" aria-level="2" id="mvweb-t-one-click-title"><?php esc_html_e( 'Buy in one click', 'brand-market' ); ?></div>

			<p class="mvweb-t-modal__subject">
				<strong><?php echo esc_html( $mvweb_product->get_name() ); ?></strong>
				<span class="mvweb-t-modal__subject-label"><?php esc_html_e( 'Quantity:', 'brand-market' ); ?> <span data-one-click-qty>1</span> <?php esc_html_e( 'pcs.', 'brand-market' ); ?></span>
			</p>

			<p class="mvweb-t-modal__lead"><?php esc_html_e( 'Leave a phone number: we call back to confirm the order and agree on the delivery.', 'brand-market' ); ?></p>

			<input type="hidden" name="product" value="<?php echo (int) $mvweb_product->get_id(); ?>">
			<input type="hidden" name="quantity" value="1">
			<input class="mvweb-t-one-click__trap" type="text" name="website" value="" tabindex="-1" autocomplete="off" aria-hidden="true">

			<label class="mvweb-t-field">
				<span class="mvweb-t-field__label"><?php esc_html_e( 'Name', 'brand-market' ); ?></span>
				<input class="mvweb-t-field__input" type="text" name="name" maxlength="100" autocomplete="name">
			</label>

			<label class="mvweb-t-field">
				<span class="mvweb-t-field__label"><?php esc_html_e( 'Phone', 'brand-market' ); ?></span>
				<input class="mvweb-t-field__input" type="tel" name="phone" maxlength="40" autocomplete="tel" inputmode="tel" required>
			</label>

			<p class="mvweb-t-one-click__error" data-one-click-error data-offline="<?php esc_attr_e( 'Could not send the order. Check the connection or call us.', 'brand-market' ); ?>" role="alert" hidden></p>

			<button class="mvweb-t-btn mvweb-t-btn--block" type="submit"><?php esc_html_e( 'Send the order', 'brand-market' ); ?></button>

			<p class="mvweb-t-form-note">
				<?php if ( '' !== $mvweb_policy ) : ?>
					<?php
					printf(
						/* translators: %s: link to the privacy policy. */
						esc_html__( 'By sending the order you agree to the processing of personal data under the %s.', 'brand-market' ),
						'<a href="' . esc_url( $mvweb_policy ) . '" target="_blank" rel="noopener">' . esc_html__( 'privacy policy', 'brand-market' ) . '</a>'
					);
					?>
				<?php else : ?>
					<?php esc_html_e( 'By sending the order you agree to the processing of personal data.', 'brand-market' ); ?>
				<?php endif; ?>
			</p>
		</form>

		<div class="mvweb-t-modal__view mvweb-t-modal__view--center" data-view="ok" hidden>
			<button class="mvweb-t-round mvweb-t-modal__close" type="button" data-one-click-close title="<?php esc_attr_e( 'Close', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Close', 'brand-market' ); ?></span>
			</button>
			<span class="mvweb-t-modal__mark"><?php echo mvweb_theme_icon( 'check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
			<div class="mvweb-t-modal__title mvweb-t-h2" role="heading" aria-level="2"><?php esc_html_e( 'Order accepted', 'brand-market' ); ?></div>
			<p class="mvweb-t-modal__lead">
				<?php esc_html_e( 'Order number:', 'brand-market' ); ?> <strong data-one-click-number></strong>.
				<?php esc_html_e( 'We will call you back soon.', 'brand-market' ); ?>
				<?php if ( '' !== $mvweb_tel ) : ?>
					<a href="<?php echo esc_url( $mvweb_tel ); ?>"><?php echo esc_html( $mvweb_phone ); ?></a>
				<?php endif; ?>
			</p>
			<button class="mvweb-t-btn" type="button" data-one-click-close><?php esc_html_e( 'Close', 'brand-market' ); ?></button>
		</div>

	</div>
</dialog>
