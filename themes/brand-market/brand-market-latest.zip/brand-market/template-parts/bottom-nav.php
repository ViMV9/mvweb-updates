<?php
/**
 * The bottom bar of the phone: up to five items with an icon and a caption, the request item as a round button in the middle of the row.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_items = isset( $args['items'] ) ? (array) $args['items'] : array();
?>
<nav class="mvweb-t-tabbar" data-bottom-nav aria-label="<?php esc_attr_e( 'Quick menu', 'brand-market' ); ?>">
	<?php
	foreach ( $mvweb_items as $mvweb_item ) :
		$mvweb_icon = '' === $mvweb_item['icon'] ? ( $mvweb_item['main'] ? 'calendar-check' : 'arrow-right' ) : $mvweb_item['icon'];
		$mvweb_svg  = mvweb_theme_icon( $mvweb_icon );
		?>
		<a class="<?php echo esc_attr( trim( 'mvweb-t-tabbar__item' . ( $mvweb_item['main'] ? ' mvweb-t-tabbar__item--main' : '' ) . ' ' . $mvweb_item['classes'] ) ); ?>" href="<?php echo esc_url( $mvweb_item['url'] ); ?>"<?php echo $mvweb_item['current'] ? ' aria-current="page"' : ''; ?>>
			<?php echo $mvweb_item['main'] ? '<span class="mvweb-t-tabbar__main">' . $mvweb_svg . '</span>' : $mvweb_svg; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<?php echo esc_html( $mvweb_item['title'] ); ?>
		</a>
	<?php endforeach; ?>
</nav>
