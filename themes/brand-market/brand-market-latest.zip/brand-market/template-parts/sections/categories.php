<?php
/**
 * Section template: what the shop sells, in picture cards.
 *
 * Five views: a mosaic, round pictures, a ribbon of pills, photo tiles, a
 * list with previews. The cards come from a list the editor made or from the
 * categories of the catalogue. A card prints its name, description, line and
 * picture in the order the composition sets; a part without data is not
 * printed, and a card whose name is hidden keeps its link for screen readers.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block  = mvweb_theme_block( 'categories', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props  = $mvweb_block['props'];
$mvweb_source = isset( $mvweb_props['source'] ) ? (string) $mvweb_props['source'] : 'manual';
$mvweb_cards  = mvweb_core_categories_cards( $mvweb_props );

if ( empty( $mvweb_cards ) ) {
	return;
}

if ( '' === trim( (string) ( isset( $mvweb_props['link_url'] ) ? $mvweb_props['link_url'] : '' ) ) ) {
	$mvweb_block['props']['link_url'] = 'service_cat' === $mvweb_source ? mvweb_core_service_archive_url() : mvweb_core_catalog_page_url();
}

$mvweb_view   = $mvweb_block['mod'];
$mvweb_motion = '' !== $mvweb_block['motion'];
$mvweb_rv     = $mvweb_motion ? ' data-rv' : '';
$mvweb_order  = $mvweb_block['item_parts'];
$mvweb_arrow  = mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) );
$mvweb_base   = 'mvweb-t-categories__';

$mvweb_img = static function ( $id, $size ) {
	return wp_attachment_is_image( absint( $id ) ) ? (string) wp_get_attachment_image(
		absint( $id ),
		$size,
		false,
		array(
			'alt'     => '',
			'loading' => 'lazy',
		)
	) : '';
};

$mvweb_link = static function ( $card, $css, $inner ) {
	return '<a class="' . $css . '" href="' . esc_url( $card['url'] ) . '">' . $inner . '</a>';
};

$mvweb_wide_cards = array_filter(
	$mvweb_cards,
	static function ( $card ) {
		return $card['wide'];
	}
);

$mvweb_list_html = static function () use ( $mvweb_cards, $mvweb_view, $mvweb_rv, $mvweb_order, $mvweb_arrow, $mvweb_base, $mvweb_img, $mvweb_link, $mvweb_wide_cards ) {
	$has_title = in_array( 'title', $mvweb_order, true );
	$has_count = in_array( 'count', $mvweb_order, true );
	$has_image = in_array( 'image', $mvweb_order, true );
	$texts     = static function ( $card, $names ) use ( $mvweb_order, $mvweb_base ) {
		$html = '';

		foreach ( $mvweb_order as $slug ) {
			if ( 'title' === $slug ) {
				$html .= '<span class="' . $mvweb_base . $names['name'] . '">' . esc_html( $card['title'] ) . '</span>';
			} elseif ( 'count' === $slug && '' !== $card['note'] ) {
				$html .= '<span class="' . $mvweb_base . $names['count'] . '">' . esc_html( $card['note'] ) . '</span>';
			}
		}

		return $html;
	};
	$sr_title  = static function ( $card ) {
		return '<span class="screen-reader-text">' . esc_html( $card['title'] ) . '</span>';
	};
	$html      = '';

	if ( '' === $mvweb_view ) {
		$equal = empty( $mvweb_wide_cards );
		$place = static function ( $cols, $wide_rows ) use ( $mvweb_cards ) {
			$taken = array();
			$cells = array();

			foreach ( $mvweb_cards as $i => $card ) {
				$w = $card['wide'] ? min( 2, $cols ) : 1;
				$h = $card['wide'] ? $wide_rows : 1;

				for ( $row = 0, $found = false; ! $found; $row++ ) {
					for ( $col = 0; $col + $w <= $cols && ! $found; $col++ ) {
						$free = true;

						for ( $y = $row; $y < $row + $h && $free; $y++ ) {
							for ( $x = $col; $x < $col + $w && $free; $x++ ) {
								$free = empty( $taken[ $y ][ $x ] );
							}
						}

						if ( $free ) {
							for ( $y = $row; $y < $row + $h; $y++ ) {
								for ( $x = $col; $x < $col + $w; $x++ ) {
									$taken[ $y ][ $x ] = true;
								}
							}

							$cells[ $i ] = array( $row, $col, $card['wide'] );
							$found       = true;
						}
					}
				}
			}

			$rows = array();

			foreach ( $cells as $cell ) {
				if ( ! $cell[2] ) {
					$rows[ $cell[0] ] = true;
				}
			}

			ksort( $rows );
			$order = array_flip( array_keys( $rows ) );

			foreach ( $cells as $i => $cell ) {
				$cells[ $i ] = ! $cell[2] && 1 === ( $order[ $cell[0] ] + $cell[1] ) % 2;
			}

			return $cells;
		};
		$large = $place( $equal ? 3 : 4, 2 );
		$small = $place( 2, 1 );
		$huge  = $equal && '1920' === (string) get_theme_mod( 'mvweb_container_width', '1280' ) ? $place( 4, 2 ) : array();
		$html .= '<div class="' . $mvweb_base . 'grid' . ( $equal ? ' ' . $mvweb_base . 'grid--equal' : '' ) . '">';

		foreach ( $mvweb_cards as $i => $card ) {
			$class = $mvweb_base . 'card' . ( $card['wide'] ? ' ' . $mvweb_base . 'card--wide' : '' );
			$paint = '';
			$style = '';

			if ( ! empty( $card['pattern'] ) ) {
				$class .= ' ' . $mvweb_base . 'card--pattern';
				$paint  = ' data-pattern="' . esc_attr( $card['pattern']['name'] ) . '" data-pattern-repeat="' . esc_attr( $card['pattern']['repeat'] ) . '"';
				$style  = '--mvweb-t-card-pattern-opacity:' . ( $card['pattern']['opacity'] / 100 ) . ';' . ( '' !== $card['pattern']['tile'] ? '--mvweb-t-card-pattern-tile:url("' . esc_url_raw( $card['pattern']['tile'] ) . '");' : '' );
			}

			if ( ! empty( $card['bg'] ) ) {
				$class .= ' ' . $mvweb_base . 'card--custom';
				$style .= '--mvweb-t-card-bg:' . $card['bg']['bg'] . ';--mvweb-t-card-ink:' . $card['bg']['ink'] . ';';
			} elseif ( ! $card['wide'] ) {
				$class .= $large[ $i ] ? ' ' . $mvweb_base . 'card--soft' : '';
				$class .= $small[ $i ] ? ' ' . $mvweb_base . 'card--soft-sm' : '';
				$class .= ! empty( $huge[ $i ] ) ? ' ' . $mvweb_base . 'card--soft-xl' : '';
			}

			$parts = array();

			foreach ( $mvweb_order as $slug ) {
				if ( in_array( $slug, array( 'title', 'desc' ), true ) ) {
					if ( ! isset( $parts['body'] ) ) {
						$parts['body'] = '';
					}

					if ( 'title' === $slug ) {
						$parts['body'] .= '<div class="' . $mvweb_base . 'title mvweb-t-h3">' . $mvweb_link( $card, $mvweb_base . 'link', esc_html( $card['title'] ) ) . '</div>';
					} elseif ( $card['wide'] && '' !== $card['text'] ) {
						$parts['body'] .= '<p class="' . $mvweb_base . 'desc">' . esc_html( $card['text'] ) . '</p>';
					}
				} elseif ( 'count' === $slug && '' !== $card['note'] ) {
					$parts['count'] = '<span class="' . $mvweb_base . 'count">' . esc_html( $card['note'] ) . $mvweb_arrow . '</span>';
				}
			}

			if ( ! $has_title ) {
				$parts = array_merge(
					array( 'body' => '' ),
					$parts
				);

				$parts['body'] = '<div>' . $mvweb_link( $card, $mvweb_base . 'link', $sr_title( $card ) ) . '</div>' . $parts['body'];
			}

			$pics = '';

			if ( $has_image ) {
				$first  = $mvweb_img( $card['image'], 'large' );
				$second = $card['wide'] ? $mvweb_img( $card['image_2'], 'large' ) : '';
				$pics  .= '' !== $first ? '<div class="' . $mvweb_base . 'pic" aria-hidden="true">' . $first . '</div>' : '';
				$pics  .= '' !== $second ? '<div class="' . $mvweb_base . 'pic ' . $mvweb_base . 'pic--second" aria-hidden="true">' . $second . '</div>' : '';
			}

			$body = '';

			foreach ( $parts as $key => $part ) {
				$body .= 'body' === $key ? '<div class="' . $mvweb_base . 'body">' . $part . '</div>' : $part;
			}

			$paint .= '' !== $style ? ' style="' . esc_attr( $style ) . '"' : '';
			$html  .= '<article' . $mvweb_rv . ' class="' . $class . '"' . $paint . '>' . $body . $pics . '</article>';
		}

		return $html . '</div>';
	}

	if ( 'circles' === $mvweb_view ) {
		$html .= '<ul class="' . $mvweb_base . 'circles">';

		foreach ( $mvweb_cards as $card ) {
			$disc   = $has_image ? $mvweb_img( $card['image'], 'medium' ) : '';
			$inner  = '' !== $disc ? '<span class="' . $mvweb_base . 'disc">' . $disc . '</span>' : '';
			$inner .= $has_title ? '<span class="' . $mvweb_base . 'name">' . esc_html( $card['title'] ) . '</span>' : $sr_title( $card );
			$html  .= '<li' . $mvweb_rv . '>' . $mvweb_link( $card, $mvweb_base . 'circle', $inner ) . '</li>';
		}

		return $html . '</ul>';
	}

	if ( 'ribbon' === $mvweb_view ) {
		$sets = '';

		foreach ( array( false, true ) as $copy ) {
			$sets .= '<ul class="' . $mvweb_base . 'set"' . ( $copy ? ' aria-hidden="true"' : '' ) . '>';

			foreach ( $mvweb_cards as $card ) {
				$thumb  = $has_image ? $mvweb_img( $card['image'], 'medium' ) : '';
				$text   = $texts(
					$card,
					array(
						'name'  => 'pill-name',
						'count' => 'pill-count',
					)
				);
				$inner  = '' !== $thumb ? '<span class="' . $mvweb_base . 'pill-thumb">' . $thumb . '</span>' : '';
				$inner .= '' !== $text ? '<span class="' . $mvweb_base . 'pill-text">' . $text . '</span>' : $sr_title( $card );
				$inner .= $mvweb_arrow;
				$link   = '<a class="' . $mvweb_base . 'pill" href="' . esc_url( $card['url'] ) . '"' . ( $copy ? ' tabindex="-1"' : '' ) . '>' . $inner . '</a>';
				$sets  .= '<li>' . $link . '</li>';
			}

			$sets .= '</ul>';
		}

		return '<div class="' . $mvweb_base . 'ribbon"' . $mvweb_rv . '><div class="' . $mvweb_base . 'track">' . $sets . '</div></div>';
	}

	if ( 'photo' === $mvweb_view ) {
		$html .= '<div class="' . $mvweb_base . 'tiles">';

		foreach ( $mvweb_cards as $card ) {
			$photo = $has_image ? $mvweb_img( $card['image'], 'large' ) : '';
			$text  = '';

			foreach ( $mvweb_order as $slug ) {
				if ( 'title' === $slug ) {
					$text .= '<div class="' . $mvweb_base . 'tile-name">' . $mvweb_link( $card, $mvweb_base . 'link', esc_html( $card['title'] ) ) . '</div>';
				} elseif ( 'count' === $slug && '' !== $card['note'] ) {
					$text .= '<span class="' . $mvweb_base . 'tile-count">' . esc_html( $card['note'] ) . '</span>';
				}
			}

			$text  = $has_title ? $text : $text . $mvweb_link( $card, $mvweb_base . 'link', $sr_title( $card ) );
			$html .= '<article class="' . $mvweb_base . 'tile"' . $mvweb_rv . '>';
			$html .= '' !== $photo ? '<div class="' . $mvweb_base . 'tile-photo" aria-hidden="true">' . $photo . '</div>' : '';
			$html .= '<div class="' . $mvweb_base . 'tile-plate"><div class="' . $mvweb_base . 'tile-text">' . $text . '</div>' . $mvweb_arrow . '</div></article>';
		}

		return $html . '</div>';
	}

	$html .= '<ul class="' . $mvweb_base . 'lines">';

	foreach ( $mvweb_cards as $i => $card ) {
		$text   = $texts(
			$card,
			array(
				'name'  => 'line-name',
				'count' => 'line-count',
			)
		);
		$thumb  = $has_image ? $mvweb_img( $card['image'], 'medium' ) : '';
		$inner  = '<span class="' . $mvweb_base . 'line-num" aria-hidden="true">' . esc_html( str_pad( (string) ( $i + 1 ), 2, '0', STR_PAD_LEFT ) ) . '</span>';
		$inner .= '<span class="' . $mvweb_base . 'line-text">' . ( '' !== $text ? $text : $sr_title( $card ) ) . '</span>' . $mvweb_arrow;
		$inner .= '' !== $thumb ? '<span class="' . $mvweb_base . 'line-thumb" aria-hidden="true">' . $thumb . '</span>' : '';
		$html  .= '<li' . $mvweb_rv . '>' . $mvweb_link( $card, $mvweb_base . 'line', $inner ) . '</li>';
	}

	return $html . '</ul>';
};

$mvweb_head = array( 'rv' => true );

mvweb_theme_section_open( $mvweb_block, 'ribbon' !== $mvweb_view );

if ( 'ribbon' === $mvweb_view ) {
	$mvweb_pending = array();

	foreach ( array_merge( $mvweb_block['parts'], array( '' ) ) as $mvweb_slug ) {
		if ( in_array( $mvweb_slug, array( 'kicker', 'title', 'lead', 'more' ), true ) ) {
			$mvweb_pending[] = $mvweb_slug;
			continue;
		}

		if ( ! empty( $mvweb_pending ) ) {
			echo '<div class="mvweb-t-container">';
			mvweb_theme_head( $mvweb_block, $mvweb_pending, $mvweb_head );
			echo '</div>';
			$mvweb_pending = array();
		}

		if ( 'list' === $mvweb_slug ) {
			echo $mvweb_list_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
		}
	}
} else {
	mvweb_theme_render_parts(
		$mvweb_block,
		array(
			'list' => static function () use ( $mvweb_list_html ) {
				echo $mvweb_list_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
			},
		),
		$mvweb_head
	);
}

mvweb_theme_section_close( 'ribbon' !== $mvweb_view );
