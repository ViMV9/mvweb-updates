<?php
/**
 * Section template: what the company is good at.
 *
 * Cards with an icon, a heading and a text. The head and the list come in the
 * order the composition sets; a card prints its icon, heading and text in the
 * order of the parts of an item, and a part without data is not printed. The
 * cards, the plate of the icon and its sign take the colours set in the block;
 * on a phone the cards stand one per row or two per row.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'features', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_items = isset( $mvweb_props['blocks'] ) && is_array( $mvweb_props['blocks'] ) ? mvweb_core_visible_rows( $mvweb_props['blocks'] ) : array();

if ( empty( $mvweb_items ) ) {
	return;
}

$mvweb_rv    = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_extra = isset( $mvweb_props['mobile'] ) && 'grid' === $mvweb_props['mobile'] ? ' mvweb-t-features--m-grid' : '';

$mvweb_render_item = static function ( $item, $block ) use ( $mvweb_rv ) {
	$title  = isset( $item['title'] ) ? (string) $item['title'] : '';
	$text   = isset( $item['text'] ) ? trim( (string) $item['text'] ) : '';
	$pieces = array(
		'icon'  => empty( $item['icon'] ) ? '' : '<span class="mvweb-t-features__icon">' . mvweb_theme_icon( $item['icon'] ) . '</span>',
		'title' => '' === $title ? '' : '<div class="mvweb-t-features__title mvweb-t-h3">' . esc_html( $title ) . '</div>',
		'text'  => '' === $text ? '' : '<p class="mvweb-t-features__desc">' . esc_html( $text ) . '</p>',
	);
	$html   = '';
	$inner  = '';

	foreach ( $block['item_parts'] as $slug ) {
		if ( ! isset( $pieces[ $slug ] ) ) {
			continue;
		}

		if ( 'icon' !== $slug ) {
			$inner .= $pieces[ $slug ];
			continue;
		}

		if ( '' !== $inner ) {
			$html .= '<div class="mvweb-t-features__text">' . $inner . '</div>';
			$inner = '';
		}

		$html .= $pieces[ $slug ];
	}

	if ( '' !== $inner ) {
		$html .= '<div class="mvweb-t-features__text">' . $inner . '</div>';
	}

	echo '<li class="mvweb-t-features__block"' . $mvweb_rv . '>' . $html . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
};

$mvweb_extra .= mvweb_theme_cards_colours( $mvweb_block );

mvweb_theme_section_open( $mvweb_block, true, ltrim( $mvweb_extra ) );

mvweb_theme_render_parts(
	$mvweb_block,
	array(
		'list' => static function ( $block ) use ( $mvweb_items, $mvweb_render_item ) {
			echo '<ul class="mvweb-t-features__row">';

			foreach ( $mvweb_items as $mvweb_item ) {
				$mvweb_render_item( $mvweb_item, $block );
			}

			echo '</ul>';
		},
	),
	array( 'rv' => true )
);

mvweb_theme_section_close();
