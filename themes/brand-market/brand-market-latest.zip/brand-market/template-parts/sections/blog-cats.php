<?php
/**
 * Section template: the categories of the blog.
 *
 * Five views: tiles with a picture and a description, a band of every category
 * with its subcategories and articles, a knowledge index of the categories and
 * their subcategories, colour tiles with icons, a category beside its most
 * discussed articles. The categories are the top ones, the ones inside a
 * category or a list by hand; a category without articles is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'blog-cats', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_terms = mvweb_core_blog_cats_terms( $mvweb_props );

if ( empty( $mvweb_terms ) ) {
	return;
}

if ( empty( $mvweb_block['props']['link_url'] ) ) {
	$mvweb_block['props']['link_url'] = mvweb_core_blog_url();
}

$mvweb_rv    = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_posts = isset( $mvweb_props['posts'] ) ? max( 3, min( 5, absint( $mvweb_props['posts'] ) ) ) : 4;
$mvweb_arrow = mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) );

$mvweb_count = static function ( $term ) {
	return '<span class="mvweb-t-blog-cats__count">' . esc_html( mvweb_core_articles( $term->count ) ) . '</span>';
};

$mvweb_chips = static function ( $term, $limit ) {
	$kids = array_slice( mvweb_core_blog_children( $term->term_id, 'count' ), 0, $limit );

	if ( empty( $kids ) ) {
		return;
	}

	echo '<div class="mvweb-t-blog-cats__subs">';

	foreach ( $kids as $kid ) {
		printf( '<a class="mvweb-t-blog-cats__chip" href="%1$s">%2$s <span>%3$s</span></a>', esc_url( (string) get_term_link( $kid ) ), esc_html( $kid->name ), esc_html( number_format_i18n( $kid->count ) ) );
	}

	echo '</div>';
};

$mvweb_time = static function ( $post ) {
	$minutes = mvweb_core_reading_minutes( $post->ID );

	if ( $minutes > 0 ) {
		/* translators: %s: number of minutes. */
		echo '<span class="mvweb-t-blog-cats__time">' . mvweb_theme_icon( 'clock', array( 'class' => 'mvweb-t-icon--sm' ) ) . esc_html( sprintf( __( '%s min read', 'brand-market' ), number_format_i18n( $minutes ) ) ) . '</span>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
	}
};

$mvweb_all = static function ( $term, $css ) use ( $mvweb_arrow ) {
	printf( '<a class="%1$s" href="%2$s">%3$s %4$s</a>', esc_attr( $css ), esc_url( (string) get_term_link( $term ) ), esc_html__( 'All articles of the category', 'brand-market' ), $mvweb_arrow ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
};

$mvweb_list = array(
	'tiles' => static function () use ( $mvweb_terms, $mvweb_rv, $mvweb_count ) {
		echo '<div class="mvweb-t-blog-cats__grid">';

		foreach ( $mvweb_terms as $term ) {
			$picture = mvweb_core_term_picture( $term, 'medium_large' );
			$lead    = mvweb_core_term_lead( $term );
			$kids    = count( mvweb_core_blog_children( $term->term_id ) );
			?>
			<article class="mvweb-t-blog-cats__tile"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
				<div class="mvweb-t-blog-cats__pic">
					<?php
					echo '' !== $picture ? $picture : mvweb_theme_icon( mvweb_core_term_icon( $term ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds the image tag, the helper escapes the icon.
					?>
				</div>
				<div class="mvweb-t-blog-cats__body">
					<a class="mvweb-t-blog-cats__name mvweb-t-blog-cats__stretch" href="<?php echo esc_url( (string) get_term_link( $term ) ); ?>"><?php echo esc_html( $term->name ); ?></a>
					<?php if ( '' !== $lead ) : ?>
						<p class="mvweb-t-blog-cats__desc"><?php echo esc_html( $lead ); ?></p>
					<?php endif; ?>
					<div class="mvweb-t-blog-cats__meta">
						<span class="mvweb-t-blog-cats__badge"><?php echo esc_html( mvweb_core_articles( $term->count ) ); ?></span>
						<?php if ( $kids > 0 ) : ?>
							<span class="mvweb-t-blog-cats__count">
								<?php
								/* translators: %s: number of subcategories. */
								echo esc_html( sprintf( _n( '%s subcategory', '%s subcategories', $kids, 'brand-market' ), number_format_i18n( $kids ) ) );
								?>
							</span>
						<?php endif; ?>
					</div>
				</div>
			</article>
			<?php
		}

		echo '</div>';
	},
	'strip' => static function () use ( $mvweb_terms, $mvweb_rv, $mvweb_count, $mvweb_chips, $mvweb_time, $mvweb_all, $mvweb_posts ) {
		foreach ( $mvweb_terms as $term ) {
			$posts = mvweb_core_blog_cat_posts( $term->term_id, $mvweb_posts );
			?>
			<div class="mvweb-t-blog-cats__band"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
				<div class="mvweb-t-blog-cats__band-head">
					<div class="mvweb-t-blog-cats__band-title">
						<a class="mvweb-t-blog-cats__band-name" href="<?php echo esc_url( (string) get_term_link( $term ) ); ?>"><?php echo esc_html( $term->name ); ?></a>
						<?php echo $mvweb_count( $term ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>
					</div>
					<?php $mvweb_chips( $term, 6 ); ?>
					<?php $mvweb_all( $term, 'mvweb-t-blog-cats__all' ); ?>
				</div>
				<?php if ( ! empty( $posts ) ) : ?>
					<div class="mvweb-t-blog-cats__posts" style="--mvweb-t-blog-cats-posts:<?php echo (int) $mvweb_posts; ?>">
						<?php foreach ( $posts as $post ) : ?>
							<article class="mvweb-t-blog-cats__post">
								<div class="mvweb-t-blog-cats__thumb">
									<?php echo get_the_post_thumbnail( $post, 'medium_large', array( 'loading' => 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds the image tag. ?>
								</div>
								<div class="mvweb-t-blog-cats__post-text">
									<a class="mvweb-t-blog-cats__post-link mvweb-t-blog-cats__stretch" href="<?php echo esc_url( get_permalink( $post ) ); ?>"><?php echo esc_html( get_the_title( $post ) ); ?></a>
									<?php $mvweb_time( $post ); ?>
								</div>
							</article>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
			</div>
			<?php
		}
	},
	'index' => static function () use ( $mvweb_terms, $mvweb_rv, $mvweb_count ) {
		echo '<div class="mvweb-t-blog-cats__cols">';

		foreach ( $mvweb_terms as $index => $term ) {
			$kids = mvweb_core_blog_children( $term->term_id, 'count' );
			?>
			<div class="mvweb-t-blog-cats__group"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
				<div class="mvweb-t-blog-cats__group-top">
					<span class="mvweb-t-blog-cats__num" aria-hidden="true"><?php echo esc_html( sprintf( '%02d', $index + 1 ) ); ?></span>
					<a class="mvweb-t-blog-cats__group-name" href="<?php echo esc_url( (string) get_term_link( $term ) ); ?>"><?php echo esc_html( $term->name ); ?></a>
					<?php echo $mvweb_count( $term ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in the helper. ?>
				</div>
				<ul class="mvweb-t-blog-cats__links<?php echo empty( $kids ) ? ' mvweb-t-blog-cats__links--posts' : ''; ?>">
					<?php if ( ! empty( $kids ) ) : ?>
						<?php foreach ( $kids as $kid ) : ?>
							<li><a class="mvweb-t-blog-cats__link" href="<?php echo esc_url( (string) get_term_link( $kid ) ); ?>"><?php echo esc_html( $kid->name ); ?><span class="mvweb-t-blog-cats__count"><?php echo esc_html( number_format_i18n( $kid->count ) ); ?></span></a></li>
						<?php endforeach; ?>
					<?php else : ?>
						<?php foreach ( mvweb_core_blog_cat_posts( $term->term_id, 3 ) as $post ) : ?>
							<li><a class="mvweb-t-blog-cats__link" href="<?php echo esc_url( get_permalink( $post ) ); ?>"><?php echo esc_html( get_the_title( $post ) ); ?></a></li>
						<?php endforeach; ?>
					<?php endif; ?>
				</ul>
			</div>
			<?php
		}

		echo '</div>';
	},
	'color' => static function () use ( $mvweb_terms, $mvweb_rv ) {
		$tones = array( 'soft', 'inverse', 'surface', 'accent' );

		echo '<div class="mvweb-t-blog-cats__colors">';

		foreach ( $mvweb_terms as $index => $term ) {
			$lead = mvweb_core_term_lead( $term );
			?>
			<a class="mvweb-t-blog-cats__color mvweb-t-blog-cats__color--<?php echo esc_attr( $tones[ $index % 4 ] ); ?>" href="<?php echo esc_url( (string) get_term_link( $term ) ); ?>"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
				<span class="mvweb-t-blog-cats__color-top">
					<span class="mvweb-t-blog-cats__icon"><?php echo mvweb_theme_icon( mvweb_core_term_icon( $term ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
					<span class="mvweb-t-blog-cats__color-count"><?php echo esc_html( mvweb_core_articles( $term->count ) ); ?></span>
				</span>
				<span class="mvweb-t-blog-cats__color-bottom">
					<span class="mvweb-t-blog-cats__color-name"><?php echo esc_html( $term->name ); ?></span>
					<?php if ( '' !== $lead ) : ?>
						<span class="mvweb-t-blog-cats__color-desc"><?php echo esc_html( $lead ); ?></span>
					<?php endif; ?>
				</span>
			</a>
			<?php
		}

		echo '</div>';
	},
	'top'   => static function () use ( $mvweb_terms, $mvweb_rv, $mvweb_chips, $mvweb_time, $mvweb_all, $mvweb_posts, $mvweb_props ) {
		$label = isset( $mvweb_props['top_label'] ) ? trim( (string) $mvweb_props['top_label'] ) : '';

		foreach ( $mvweb_terms as $term ) {
			$picture = mvweb_core_term_picture( $term, 'medium_large' );
			$lead    = trim( wp_strip_all_tags( (string) $term->description ) );
			$posts   = mvweb_core_blog_cat_posts( $term->term_id, $mvweb_posts, true );
			?>
			<div class="mvweb-t-blog-cats__duo"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
				<div class="mvweb-t-blog-cats__about">
					<?php if ( '' !== $picture ) : ?>
						<div class="mvweb-t-blog-cats__about-pic"><?php echo $picture; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds the image tag. ?></div>
					<?php endif; ?>
					<div class="mvweb-t-blog-cats__kicker"><span><?php esc_html_e( 'Category', 'brand-market' ); ?></span><span><?php echo esc_html( mvweb_core_articles( $term->count ) ); ?></span></div>
					<a class="mvweb-t-blog-cats__about-name" href="<?php echo esc_url( (string) get_term_link( $term ) ); ?>"><?php echo esc_html( $term->name ); ?></a>
					<?php if ( '' !== $lead ) : ?>
						<p class="mvweb-t-blog-cats__about-desc"><?php echo esc_html( $lead ); ?></p>
					<?php endif; ?>
					<?php $mvweb_chips( $term, 5 ); ?>
					<?php $mvweb_all( $term, 'mvweb-t-btn mvweb-t-blog-cats__about-btn' ); ?>
				</div>
				<?php if ( ! empty( $posts ) ) : ?>
					<div class="mvweb-t-blog-cats__popular">
						<?php if ( '' !== $label ) : ?>
							<div class="mvweb-t-blog-cats__label"><?php echo esc_html( $label ); ?></div>
						<?php endif; ?>
						<ol class="mvweb-t-blog-cats__top">
							<?php foreach ( $posts as $post ) : ?>
								<li class="mvweb-t-blog-cats__top-item">
									<a class="mvweb-t-blog-cats__top-link" href="<?php echo esc_url( get_permalink( $post ) ); ?>"><?php echo esc_html( get_the_title( $post ) ); ?></a>
									<?php $mvweb_time( $post ); ?>
								</li>
							<?php endforeach; ?>
						</ol>
					</div>
				<?php endif; ?>
			</div>
			<?php
		}
	},
);

$mvweb_parts = array(
	'list' => static function () use ( $mvweb_block, $mvweb_list ) {
		$view = isset( $mvweb_list[ $mvweb_block['mod'] ] ) ? $mvweb_block['mod'] : 'tiles';

		$mvweb_list[ $view ]();
	},
);

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts( $mvweb_block, $mvweb_parts, array( 'rv' => true ) );
mvweb_theme_section_close();
