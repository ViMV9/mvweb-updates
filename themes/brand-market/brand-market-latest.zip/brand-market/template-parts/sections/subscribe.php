<?php
/**
 * Section template: the subscription to the social networks of the site.
 *
 * Three views: an accent card with the points, a light card with the text on
 * the left and the networks on the right, a dark strip. The heading, the lead
 * and the points come in the order the composition sets; the networks are the
 * buttons of the contacts widget. Without networks the block is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block     = mvweb_theme_block( 'subscribe', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_subscribe = mvweb_core_subscribe();
$mvweb_socials   = ! empty( $mvweb_subscribe['socials'] ) && in_array( 'socials', $mvweb_block['parts'], true ) ? (array) $mvweb_subscribe['socials'] : array();

if ( empty( $mvweb_socials ) ) {
	return;
}

$mvweb_rv   = '' !== $mvweb_block['motion'];
$mvweb_note = mvweb_core_social_meta_note( $mvweb_socials );

mvweb_theme_section_open( $mvweb_block );
?>
<div class="mvweb-t-subscribe__box">
	<div class="mvweb-t-subscribe__text">
		<?php
		mvweb_theme_render_parts(
			$mvweb_block,
			array(
				'points' => static function ( $block ) {
					$points = mvweb_core_text_lines( isset( $block['props']['points'] ) ? (string) $block['props']['points'] : '' );

					if ( empty( $points ) || 'strip' === $block['mod'] ) {
						return;
					}

					echo '<ul class="mvweb-t-subscribe__points">';

					foreach ( $points as $point ) {
						echo '<li>' . mvweb_theme_icon( 'check', array( 'class' => 'mvweb-t-icon--sm' ) ) . esc_html( $point ) . '</li>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
					}

					echo '</ul>';
				},
			),
			array( 'rv' => $mvweb_rv )
		);
		?>
	</div>
	<div class="mvweb-t-subscribe__nets"<?php echo $mvweb_rv ? ' data-rv' : ''; ?>>
		<ul class="mvweb-t-subscribe__list">
			<?php foreach ( $mvweb_socials as $mvweb_id => $mvweb_social ) : ?>
				<li>
					<a class="<?php echo esc_attr( 'mvweb-t-widget__chat mvweb-t-widget__chat--' . sanitize_html_class( (string) $mvweb_id ) ); ?>" href="<?php echo esc_url( $mvweb_social['url'] ); ?>" target="_blank" rel="noopener">
						<span class="mvweb-t-widget__chat-ico" aria-hidden="true"><?php echo mvweb_theme_icon( mvweb_core_social_icon( (string) $mvweb_id ), array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
						<span class="mvweb-t-widget__chat-name"><?php echo esc_html( $mvweb_social['label'] ); ?></span>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php if ( '' !== $mvweb_note ) : ?>
			<p class="mvweb-t-subscribe__note"><?php echo esc_html( $mvweb_note ); ?></p>
		<?php endif; ?>
	</div>
</div>
<?php
mvweb_theme_section_close();
