<?php
/**
 * Section template: a wall of brand logos.
 *
 * Two views: a grid of square tiles and an endless running line across the
 * whole width. A logo keeps its own proportions inside the tile or at the
 * height of the line. Black and white logos light up in colour on hover, at
 * random or in the middle of the screen, as the block asks.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'brands', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_rows  = array();

foreach ( isset( $mvweb_props['logos'] ) && is_array( $mvweb_props['logos'] ) ? mvweb_core_visible_rows( $mvweb_props['logos'] ) : array() as $mvweb_row ) {
	$mvweb_id = isset( $mvweb_row['image'] ) ? absint( $mvweb_row['image'] ) : 0;

	if ( wp_attachment_is_image( $mvweb_id ) ) {
		$mvweb_alt    = trim( (string) get_post_meta( $mvweb_id, '_wp_attachment_image_alt', true ) );
		$mvweb_rows[] = array(
			'image' => $mvweb_id,
			'alt'   => '' !== $mvweb_alt ? $mvweb_alt : trim( (string) ( isset( $mvweb_row['name'] ) ? $mvweb_row['name'] : '' ) ),
			'url'   => isset( $mvweb_row['url'] ) ? trim( (string) $mvweb_row['url'] ) : '',
		);
	}
}

if ( empty( $mvweb_rows ) ) {
	return;
}

$mvweb_run    = 'run' === $mvweb_block['mod'];
$mvweb_rv     = '' !== $mvweb_block['motion'] ? ' data-rv' : '';
$mvweb_host   = (string) wp_parse_url( home_url(), PHP_URL_HOST );
$mvweb_effect = $mvweb_run
	? ( isset( $mvweb_props['run_effect'] ) && 'center' === $mvweb_props['run_effect'] ? 'center' : '' )
	: ( isset( $mvweb_props['effect'] ) && in_array( $mvweb_props['effect'], array( 'hover', 'random' ), true ) ? $mvweb_props['effect'] : '' );

$mvweb_item = static function ( $row, $copy ) use ( $mvweb_host, $mvweb_run ) {
	$logo = (string) wp_get_attachment_image(
		$row['image'],
		'medium',
		false,
		array(
			'class'   => 'mvweb-t-brands__logo',
			'alt'     => $copy ? '' : $row['alt'],
			'loading' => 'lazy',
			'sizes'   => $mvweb_run ? '12rem' : '(max-width: 600px) 45vw, 12rem',
		)
	);

	if ( '' === $row['url'] ) {
		return '<div class="mvweb-t-brands__item">' . $logo . '</div>';
	}

	$host = (string) wp_parse_url( $row['url'], PHP_URL_HOST );
	$away = '' !== $host && $host !== $mvweb_host;

	return '<a class="mvweb-t-brands__item" href="' . esc_url( $row['url'] ) . '"' . ( $away ? ' target="_blank" rel="noopener"' : '' ) . ( $copy ? ' tabindex="-1"' : '' ) . '>' . $logo . '</a>';
};

$mvweb_list = static function () use ( $mvweb_rows, $mvweb_props, $mvweb_run, $mvweb_rv, $mvweb_effect, $mvweb_item ) {
	$data = in_array( $mvweb_effect, array( 'random', 'center' ), true ) ? ' data-brands="' . $mvweb_effect . '"' : '';

	if ( $mvweb_run ) {
		$pace  = array(
			'slow'   => 5,
			'normal' => 3,
			'fast'   => 1.8,
		);
		$speed = isset( $mvweb_props['speed'], $pace[ $mvweb_props['speed'] ] ) ? $pace[ $mvweb_props['speed'] ] : $pace['normal'];
		$sets  = (int) ceil( 24 / count( $mvweb_rows ) );
		$time  = max( 16, round( $sets * count( $mvweb_rows ) * $speed ) );
		$html  = '';

		for ( $i = 0; $i < 2 * $sets; $i++ ) {
			$copy  = $i > 0;
			$html .= '<ul class="mvweb-t-brands__reel"' . ( $copy ? ' aria-hidden="true"' : '' ) . '>';

			foreach ( $mvweb_rows as $row ) {
				$html .= '<li>' . $mvweb_item( $row, $copy ) . '</li>';
			}

			$html .= '</ul>';
		}

		echo '<div class="mvweb-t-brands__run" style="--mvweb-t-brands-time:' . esc_attr( (string) $time ) . 's"' . $data . $mvweb_rv . '><div class="mvweb-t-brands__track">' . $html . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.

		return;
	}

	$cols  = isset( $mvweb_props['cols'] ) ? min( 8, max( 2, absint( $mvweb_props['cols'] ) ) ) : 6;
	$small = isset( $mvweb_props['cols_mobile'] ) && in_array( (string) $mvweb_props['cols_mobile'], array( '1', '2', '3' ), true ) ? (string) $mvweb_props['cols_mobile'] : '2';
	$html  = '';

	foreach ( $mvweb_rows as $row ) {
		$html .= '<li' . $mvweb_rv . '>' . $mvweb_item( $row, false ) . '</li>';
	}

	echo '<ul class="mvweb-t-brands__grid" style="--mvweb-t-brands-cols:' . esc_attr( (string) $cols ) . ';--mvweb-t-brands-cols-sm:' . esc_attr( $small ) . '"' . $data . '>' . $html . '</ul>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped values.
};

$mvweb_class = '' !== $mvweb_effect ? 'mvweb-t-brands--gray' : '';

mvweb_theme_section_open( $mvweb_block, ! $mvweb_run, $mvweb_class );

if ( $mvweb_run ) {
	$mvweb_pending = array();

	foreach ( array_merge( $mvweb_block['parts'], array( '' ) ) as $mvweb_slug ) {
		if ( in_array( $mvweb_slug, array( 'kicker', 'title', 'lead' ), true ) ) {
			$mvweb_pending[] = $mvweb_slug;
			continue;
		}

		if ( ! empty( $mvweb_pending ) ) {
			echo '<div class="mvweb-t-container">';
			mvweb_theme_head( $mvweb_block, $mvweb_pending, array( 'rv' => true ) );
			echo '</div>';
			$mvweb_pending = array();
		}

		if ( 'list' === $mvweb_slug ) {
			$mvweb_list();
		}
	}
} else {
	mvweb_theme_render_parts(
		$mvweb_block,
		array(
			'list' => static function () use ( $mvweb_list ) {
				$mvweb_list();
			},
		),
		array( 'rv' => true )
	);
}

mvweb_theme_section_close( ! $mvweb_run );
