<?php
/**
 * Section template: the authors of the blog.
 *
 * Five views: a grid of cards, a list in rows, the first author large with a
 * letter to the readers and the others under him, groups with their authors,
 * cards with the latest article of every author. The position comes from the
 * profile, the links from the profile fields of the networks.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'authors', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_view  = '' !== $mvweb_block['mod'] ? $mvweb_block['mod'] : 'grid';
$mvweb_count = isset( $mvweb_props['count'] ) ? max( 1, min( 48, absint( $mvweb_props['count'] ) ) ) : 12;
$mvweb_ids   = wp_parse_id_list( isset( $mvweb_props['ids'] ) ? (string) $mvweb_props['ids'] : '' );
$mvweb_sets  = array();

if ( 'groups' === $mvweb_view ) {
	foreach ( isset( $mvweb_props['groups'] ) && is_array( $mvweb_props['groups'] ) ? mvweb_core_visible_rows( $mvweb_props['groups'] ) : array() as $mvweb_group ) {
		$mvweb_people = wp_parse_id_list( isset( $mvweb_group['ids'] ) ? (string) $mvweb_group['ids'] : '' );

		if ( ! empty( $mvweb_people ) ) {
			$mvweb_sets[] = array(
				'title'   => isset( $mvweb_group['title'] ) ? trim( (string) $mvweb_group['title'] ) : '',
				'text'    => isset( $mvweb_group['text'] ) ? trim( (string) $mvweb_group['text'] ) : '',
				'authors' => mvweb_core_authors( $mvweb_people, 48 ),
			);
		}
	}

	if ( empty( $mvweb_sets ) ) {
		$mvweb_sets[] = array(
			'title'   => '',
			'text'    => '',
			'authors' => mvweb_core_authors( array(), 48 ),
		);
	}

	$mvweb_authors = array_filter( array_column( $mvweb_sets, 'authors' ) );
} else {
	$mvweb_authors = mvweb_core_authors( $mvweb_ids, $mvweb_count );
}

if ( empty( $mvweb_authors ) ) {
	return;
}

$mvweb_rv = '' !== $mvweb_block['motion'] ? ' data-rv' : '';

$mvweb_ava = static function ( $author, $size = 160, $css = 'mvweb-t-authors__ava' ) {
	return '<span class="' . esc_attr( $css ) . '">' . get_avatar( $author['id'], $size, '', '', array( 'loading' => 'lazy' ) ) . '</span>';
};

$mvweb_who = static function ( $author, $size = 160 ) use ( $mvweb_ava ) {
	?>
	<div class="mvweb-t-authors__who">
		<?php echo $mvweb_ava( $author, $size ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds the image tag. ?>
		<div class="mvweb-t-authors__who-text">
			<a class="mvweb-t-authors__name" href="<?php echo esc_url( $author['url'] ); ?>"><?php echo esc_html( $author['name'] ); ?></a>
			<?php if ( '' !== $author['role'] ) : ?>
				<p class="mvweb-t-authors__role"><?php echo esc_html( $author['role'] ); ?></p>
			<?php endif; ?>
		</div>
	</div>
	<?php
};

$mvweb_socials = static function ( $author ) {
	$links = mvweb_core_author_links( $author['id'] );

	if ( empty( $links ) ) {
		return;
	}

	echo '<div class="mvweb-t-authors__socials">';

	foreach ( $links as $link ) {
		printf(
			'<a class="mvweb-t-authors__social" href="%1$s"%2$s aria-label="%3$s">%4$s</a>',
			esc_url( $link['url'] ),
			0 === strpos( $link['url'], 'http' ) ? ' target="_blank" rel="noopener"' : '',
			/* translators: 1: name of a network, 2: name of the author. */
			esc_attr( sprintf( __( '%1$s: %2$s', 'brand-market' ), $link['label'], $author['name'] ) ),
			mvweb_theme_icon( $link['icon'] ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
		);
	}

	echo '</div>';
};

$mvweb_posts = static function ( $author ) {
	if ( $author['posts'] > 0 ) {
		echo '<span class="mvweb-t-authors__badge">' . esc_html( mvweb_core_articles( $author['posts'] ) ) . '</span>';
	}
};

$mvweb_more = static function ( $author, $all = false ) {
	$text = $all && $author['posts'] > 1 ? sprintf( /* translators: %s: number and word, for example «12 articles». */ __( 'All %s', 'brand-market' ), mvweb_core_articles( $author['posts'] ) ) : __( 'Articles of the author', 'brand-market' );

	printf( '<a class="mvweb-t-authors__more" href="%1$s">%2$s</a>', esc_url( $author['url'] ), esc_html( $text ) );
};

$mvweb_bio = static function ( $author ) {
	if ( '' !== $author['bio'] ) {
		echo '<p class="mvweb-t-authors__bio">' . esc_html( $author['bio'] ) . '</p>';
	}
};

$mvweb_card = static function ( $author ) use ( $mvweb_who, $mvweb_bio, $mvweb_posts, $mvweb_socials, $mvweb_more, $mvweb_rv ) {
	?>
	<article class="mvweb-t-authors__card"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
		<?php $mvweb_who( $author ); ?>
		<?php $mvweb_bio( $author ); ?>
		<div class="mvweb-t-authors__foot">
			<?php $mvweb_posts( $author ); ?>
			<?php $mvweb_socials( $author ); ?>
			<?php $mvweb_more( $author ); ?>
		</div>
	</article>
	<?php
};

$mvweb_list = array(
	'grid'   => static function () use ( $mvweb_authors, $mvweb_card ) {
		echo '<div class="mvweb-t-authors__grid">';
		array_map( $mvweb_card, $mvweb_authors );
		echo '</div>';
	},
	'rows'   => static function () use ( $mvweb_authors, $mvweb_who, $mvweb_bio, $mvweb_posts, $mvweb_socials, $mvweb_more, $mvweb_rv ) {
		?>
		<div class="mvweb-t-authors__rows">
			<div class="mvweb-t-authors__rows-head" aria-hidden="true">
				<span><?php esc_html_e( 'Author', 'brand-market' ); ?></span>
				<span><?php esc_html_e( 'About the author', 'brand-market' ); ?></span>
				<span><?php esc_html_e( 'Articles', 'brand-market' ); ?></span>
				<span><?php esc_html_e( 'Links', 'brand-market' ); ?></span>
				<span></span>
			</div>
			<?php foreach ( $mvweb_authors as $mvweb_author ) : ?>
				<article class="mvweb-t-authors__row"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
					<?php $mvweb_who( $mvweb_author ); ?>
					<div class="mvweb-t-authors__row-bio"><?php $mvweb_bio( $mvweb_author ); ?></div>
					<div class="mvweb-t-authors__row-meta">
						<div><?php $mvweb_posts( $mvweb_author ); ?></div>
						<div><?php $mvweb_socials( $mvweb_author ); ?></div>
						<div><?php $mvweb_more( $mvweb_author ); ?></div>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
		<?php
	},
	'chief'  => static function () use ( $mvweb_authors, $mvweb_props, $mvweb_ava, $mvweb_posts, $mvweb_socials, $mvweb_more, $mvweb_rv ) {
		$chief  = $mvweb_authors[0];
		$label  = isset( $mvweb_props['chief_label'] ) ? trim( (string) $mvweb_props['chief_label'] ) : '';
		$letter = isset( $mvweb_props['letter'] ) ? trim( (string) $mvweb_props['letter'] ) : '';
		$lines  = '' !== $letter ? preg_split( '/\n\s*\n/', $letter ) : ( '' !== $chief['bio'] ? array( $chief['bio'] ) : array() );
		?>
		<div class="mvweb-t-authors__chief"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
			<?php echo $mvweb_ava( $chief, 640, 'mvweb-t-authors__photo' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds the image tag. ?>
			<div class="mvweb-t-authors__chief-text">
				<?php if ( '' !== $label ) : ?>
					<span class="mvweb-t-authors__label"><?php echo esc_html( $label ); ?></span>
				<?php endif; ?>
				<a class="mvweb-t-authors__chief-name" href="<?php echo esc_url( $chief['url'] ); ?>"><?php echo esc_html( $chief['name'] ); ?></a>
				<?php if ( '' !== $chief['role'] ) : ?>
					<p class="mvweb-t-authors__role"><?php echo esc_html( $chief['role'] ); ?></p>
				<?php endif; ?>
				<?php if ( ! empty( $lines ) ) : ?>
					<div class="mvweb-t-authors__letter">
						<?php foreach ( $lines as $line ) : ?>
							<p><?php echo esc_html( trim( $line ) ); ?></p>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>
				<div class="mvweb-t-authors__chief-meta">
					<?php $mvweb_posts( $chief ); ?>
					<?php $mvweb_socials( $chief ); ?>
					<?php $mvweb_more( $chief ); ?>
				</div>
			</div>
		</div>
		<?php if ( count( $mvweb_authors ) > 1 ) : ?>
			<div class="mvweb-t-authors__rest">
				<?php foreach ( array_slice( $mvweb_authors, 1 ) as $mvweb_author ) : ?>
					<a class="mvweb-t-authors__item" href="<?php echo esc_url( $mvweb_author['url'] ); ?>"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
						<?php echo $mvweb_ava( $mvweb_author, 120 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds the image tag. ?>
						<span class="mvweb-t-authors__item-text">
							<span class="mvweb-t-authors__name"><?php echo esc_html( $mvweb_author['name'] ); ?></span>
							<?php if ( '' !== $mvweb_author['role'] ) : ?>
								<span class="mvweb-t-authors__role"><?php echo esc_html( $mvweb_author['role'] ); ?></span>
							<?php endif; ?>
						</span>
						<?php $mvweb_posts( $mvweb_author ); ?>
					</a>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
		<?php
	},
	'groups' => static function () use ( $mvweb_sets, $mvweb_who, $mvweb_bio, $mvweb_posts, $mvweb_socials, $mvweb_rv ) {
		foreach ( $mvweb_sets as $set ) {
			if ( empty( $set['authors'] ) ) {
				continue;
			}
			?>
			<div class="mvweb-t-authors__group"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
				<div class="mvweb-t-authors__group-about">
					<?php if ( '' !== $set['title'] ) : ?>
						<div class="mvweb-t-authors__group-name"><?php echo esc_html( $set['title'] ); ?></div>
					<?php endif; ?>
					<?php if ( '' !== $set['text'] ) : ?>
						<p class="mvweb-t-authors__group-text"><?php echo esc_html( $set['text'] ); ?></p>
					<?php endif; ?>
					<span class="mvweb-t-authors__count">
						<?php
						/* translators: %s: number of people. */
						echo esc_html( sprintf( _n( '%s person', '%s people', count( $set['authors'] ), 'brand-market' ), number_format_i18n( count( $set['authors'] ) ) ) );
						?>
					</span>
				</div>
				<div class="mvweb-t-authors__people">
					<?php foreach ( $set['authors'] as $mvweb_author ) : ?>
						<div class="mvweb-t-authors__person">
							<?php $mvweb_who( $mvweb_author ); ?>
							<?php $mvweb_bio( $mvweb_author ); ?>
							<div class="mvweb-t-authors__person-meta">
								<?php $mvweb_posts( $mvweb_author ); ?>
								<?php $mvweb_socials( $mvweb_author ); ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			</div>
			<?php
		}
	},
	'latest' => static function () use ( $mvweb_authors, $mvweb_who, $mvweb_socials, $mvweb_more, $mvweb_rv ) {
		echo '<div class="mvweb-t-authors__grid">';

		foreach ( $mvweb_authors as $author ) {
			$last = get_posts(
				array(
					'author'                 => $author['id'],
					'numberposts'            => 1,
					'post_status'            => 'publish',
					'update_post_term_cache' => false,
				)
			);
			?>
			<article class="mvweb-t-authors__card mvweb-t-authors__card--latest"<?php echo $mvweb_rv; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- A fixed attribute. ?>>
				<?php $mvweb_who( $author, 120 ); ?>
				<?php if ( ! empty( $last ) ) : ?>
					<div class="mvweb-t-authors__last">
						<?php if ( has_post_thumbnail( $last[0] ) ) : ?>
							<span class="mvweb-t-authors__last-pic"><?php echo get_the_post_thumbnail( $last[0], 'medium', array( 'loading' => 'lazy' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core builds the image tag. ?></span>
						<?php endif; ?>
						<span class="mvweb-t-authors__last-text">
							<span class="mvweb-t-authors__last-label"><?php esc_html_e( 'Latest article', 'brand-market' ); ?></span>
							<a class="mvweb-t-authors__last-link" href="<?php echo esc_url( get_permalink( $last[0] ) ); ?>"><?php echo esc_html( get_the_title( $last[0] ) ); ?></a>
						</span>
					</div>
				<?php endif; ?>
				<div class="mvweb-t-authors__foot">
					<?php $mvweb_more( $author, true ); ?>
					<?php $mvweb_socials( $author ); ?>
				</div>
			</article>
			<?php
		}

		echo '</div>';
	},
);

$mvweb_parts = array(
	'list' => static function () use ( $mvweb_list, $mvweb_view ) {
		$mvweb_list[ isset( $mvweb_list[ $mvweb_view ] ) ? $mvweb_view : 'grid' ]();
	},
);

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts( $mvweb_block, $mvweb_parts, array( 'rv' => true ) );
mvweb_theme_section_close();
