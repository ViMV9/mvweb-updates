<?php
/**
 * Section template: the latest posts of the blog.
 *
 * Fifteen views: a grid of cards, one large post beside a list, a horizontal
 * ribbon, a magazine grid, rows with a big date; five looks of the main story
 * (template-parts/posts-hero.php) and five of the feed (posts-feed.php). The
 * cards are the blog's own (the area card-post, set once for the site); the head
 * and the list follow the order the composition sets, and a part without data
 * is not printed.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_block = mvweb_theme_block( 'posts', isset( $args ) && is_array( $args ) ? $args : array() );
$mvweb_props = $mvweb_block['props'];
$mvweb_hero  = array(
	'cover'    => 1,
	'split'    => 1,
	'headline' => 4,
	'top'      => 4,
	'daily'    => 5,
);
$mvweb_feed  = array( 'wire', 'line', 'duo', 'thumbs', 'rail' );
$mvweb_count = isset( $mvweb_hero[ $mvweb_block['mod'] ] ) ? $mvweb_hero[ $mvweb_block['mod'] ] : ( isset( $mvweb_props['count'] ) ? max( 1, min( 20, absint( $mvweb_props['count'] ) ) ) : 3 );
$mvweb_aside = null;

if ( 'duo' === $mvweb_block['mod'] || 'rail' === $mvweb_block['mod'] ) {
	$mvweb_aside = mvweb_core_posts_query( array( 'source' => 'sticky' ), 'duo' === $mvweb_block['mod'] ? 5 : 1 );

	if ( null === $mvweb_aside && 'rail' === $mvweb_block['mod'] ) {
		$mvweb_aside = mvweb_core_posts_query( $mvweb_props, 1 );
	}
}

$mvweb_query = mvweb_core_posts_query( $mvweb_props, $mvweb_count, null !== $mvweb_aside ? wp_list_pluck( $mvweb_aside->posts, 'ID' ) : array() );

if ( null === $mvweb_query && null !== $mvweb_aside ) {
	$mvweb_query = mvweb_core_posts_query( $mvweb_props, $mvweb_count );
}

if ( null === $mvweb_query ) {
	return;
}

if ( empty( $mvweb_block['props']['link_url'] ) ) {
	$mvweb_block['props']['link_url'] = mvweb_core_posts_link( $mvweb_props );
}

$mvweb_view  = $mvweb_block['view'];
$mvweb_rv    = '' !== $mvweb_block['motion'];
$mvweb_card  = static function ( $modifier = '', $hide = array(), $go = false ) use ( $mvweb_rv ) {
	get_template_part(
		'template-parts/post-card',
		null,
		array(
			'modifier' => $modifier,
			'hide'     => $hide,
			'go'       => $go,
			'rv'       => $mvweb_rv,
		)
	);
};
$mvweb_parts = array(
	'list' => static function () use ( $mvweb_query, $mvweb_view, $mvweb_card, $mvweb_block, $mvweb_hero, $mvweb_feed, $mvweb_aside, $mvweb_rv ) {
		$index = 0;

		if ( in_array( $mvweb_block['mod'], $mvweb_feed, true ) ) {
			get_template_part(
				'template-parts/posts-feed',
				null,
				array(
					'look'  => $mvweb_block['mod'],
					'query' => $mvweb_query,
					'aside' => $mvweb_aside,
					'rv'    => $mvweb_rv,
				)
			);

			return;
		}

		if ( isset( $mvweb_hero[ $mvweb_block['mod'] ] ) ) {
			get_template_part(
				'template-parts/posts-hero',
				null,
				array(
					'look'  => $mvweb_block['mod'],
					'query' => $mvweb_query,
					'rv'    => $mvweb_rv,
				)
			);

			return;
		}

		if ( '2' === $mvweb_view ) {
			echo '<div class="mvweb-t-posts__feature">';
		} elseif ( '3' === $mvweb_view ) {
			echo '<div class="mvweb-t-posts__track" tabindex="0" role="region" aria-label="' . esc_attr__( 'Blog posts, scroll sideways', 'brand-market' ) . '">';
		} elseif ( '4' === $mvweb_view ) {
			echo '<div class="mvweb-t-posts__mag">';
		} elseif ( '5' === $mvweb_view ) {
			echo '<div class="mvweb-t-posts__rows">';
		} else {
			echo '<div class="mvweb-t-posts__grid">';
		}

		while ( $mvweb_query->have_posts() ) {
			$mvweb_query->the_post();

			if ( '2' === $mvweb_view && $index >= 5 ) {
				break;
			}

			if ( '2' === $mvweb_view ) {
				if ( 0 === $index ) {
					$mvweb_card( 'lead' );
				} else {
					echo 1 === $index ? '<div class="mvweb-t-posts__side">' : '';
					$mvweb_card( 'compact', array( 'lead', 'more' ) );
				}
			} elseif ( '4' === $mvweb_view ) {
				$wide = in_array( $index % 4, array( 0, 3 ), true );
				$mvweb_card( $wide ? 'wide' : 'narrow', $wide ? array() : array( 'lead', 'more' ), true );
			} elseif ( '5' === $mvweb_view ) {
				$mvweb_card( 'row' );
			} else {
				$mvweb_card();
			}

			++$index;
		}

		if ( '2' === $mvweb_view && $index > 1 ) {
			echo '</div>';
		}

		echo '</div>';
		wp_reset_postdata();
	},
);

mvweb_theme_section_open( $mvweb_block );
mvweb_theme_render_parts( $mvweb_block, $mvweb_parts, array( 'rv' => true ) );
mvweb_theme_section_close();
