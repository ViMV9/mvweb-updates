<?php
/**
 * Sections under the item: the items close to the one shown.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : 0;

if ( 0 === $mvweb_id || ! mvweb_core_product_section_filled( $mvweb_id, 'related' ) ) {
	return;
}

$mvweb_odd = isset( $args['state'] ) ? (int) $args['state']['n'] % 2 : 0;

if ( isset( $args['state'] ) ) {
	$args['state']['n'] = (int) $args['state']['n'] + 1;
}

$mvweb_items = mvweb_core_related_items( $mvweb_id );
$mvweb_view  = mvweb_core_related_view( count( $mvweb_items ) );
$mvweb_items = array_slice( $mvweb_items, 0, (int) $mvweb_view['cols'] );
$mvweb_title = mvweb_core_product_section_title( 'related' );
?>
<section class="mvweb-t-section mvweb-t-related" id="related" data-cols="<?php echo esc_attr( $mvweb_view['cols'] ); ?>"<?php echo $mvweb_odd ? ' data-bg="surface"' : ''; ?>>
	<div class="mvweb-t-container">
		<?php if ( '' !== $mvweb_title ) : ?>
			<div class="mvweb-t-section-head">
				<div class="mvweb-t-section-head__text">
					<div class="mvweb-t-section-head__title mvweb-t-related__title mvweb-t-h2" role="heading" aria-level="2"><?php echo esc_html( $mvweb_title ); ?></div>
				</div>
			</div>
		<?php endif; ?>
		<div class="mvweb-t-grid mvweb-t-catalog__grid">
			<?php foreach ( $mvweb_items as $mvweb_item ) : ?>
				<?php
				get_template_part(
					'template-parts/catalog/card',
					null,
					array(
						'id'    => $mvweb_item,
						'plain' => 'short' === $mvweb_view['card'],
					)
				);
				?>
			<?php endforeach; ?>
		</div>
	</div>
</section>
