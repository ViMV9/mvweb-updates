<?php
/**
 * Widget template: the social networks of the site.
 *
 * Three looks: buttons of the networks as in the contacts, round buttons on a
 * dark card, a list of the networks.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_socials = isset( $args['socials'] ) ? (array) $args['socials'] : array();
$mvweb_max     = isset( $args['max'] ) ? absint( $args['max'] ) : 0;
$mvweb_view    = isset( $args['view'] ) ? (string) $args['view'] : 'chats';
$mvweb_socials = $mvweb_max > 0 ? array_slice( $mvweb_socials, 0, $mvweb_max, true ) : $mvweb_socials;

if ( empty( $mvweb_socials ) ) {
	return;
}

$mvweb_note = mvweb_core_social_meta_note( $mvweb_socials );
?>
<?php if ( 'dark' === $mvweb_view ) : ?>
	<ul class="mvweb-t-widget__rounds">
		<?php foreach ( $mvweb_socials as $mvweb_id => $mvweb_social ) : ?>
			<li>
				<a class="mvweb-t-round" href="<?php echo esc_url( $mvweb_social['url'] ); ?>" target="_blank" rel="noopener" title="<?php echo esc_attr( $mvweb_social['label'] ); ?>">
					<?php echo mvweb_theme_icon( mvweb_core_social_icon( (string) $mvweb_id ), array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<span class="screen-reader-text"><?php echo esc_html( $mvweb_social['label'] ); ?></span>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
<?php elseif ( 'rows' === $mvweb_view ) : ?>
	<ul class="mvweb-t-widget__nets">
		<?php foreach ( $mvweb_socials as $mvweb_id => $mvweb_social ) : ?>
			<li>
				<a class="<?php echo esc_attr( 'mvweb-t-widget__net mvweb-t-widget__chat--' . sanitize_html_class( (string) $mvweb_id ) ); ?>" href="<?php echo esc_url( $mvweb_social['url'] ); ?>" target="_blank" rel="noopener">
					<span class="mvweb-t-widget__ico" aria-hidden="true"><?php echo mvweb_theme_icon( mvweb_core_social_icon( (string) $mvweb_id ), array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
					<span class="mvweb-t-widget__net-name"><?php echo esc_html( $mvweb_social['label'] ); ?></span>
					<?php echo mvweb_theme_icon( 'chevron-right', array( 'class' => 'mvweb-t-icon--sm mvweb-t-widget__net-go' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
<?php else : ?>
	<ul class="mvweb-t-widget__contacts">
		<li class="mvweb-t-widget__chats">
			<?php foreach ( $mvweb_socials as $mvweb_id => $mvweb_social ) : ?>
				<a class="<?php echo esc_attr( 'mvweb-t-widget__chat mvweb-t-widget__chat--' . sanitize_html_class( (string) $mvweb_id ) ); ?>" href="<?php echo esc_url( $mvweb_social['url'] ); ?>" target="_blank" rel="noopener">
					<span class="mvweb-t-widget__chat-ico" aria-hidden="true"><?php echo mvweb_theme_icon( mvweb_core_social_icon( (string) $mvweb_id ), array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
					<span class="mvweb-t-widget__chat-name"><?php echo esc_html( $mvweb_social['label'] ); ?></span>
				</a>
			<?php endforeach; ?>
		</li>
	</ul>
<?php endif; ?>
<?php if ( '' !== $mvweb_note ) : ?>
	<p class="mvweb-t-widget__note"><?php echo esc_html( $mvweb_note ); ?></p>
<?php endif; ?>
