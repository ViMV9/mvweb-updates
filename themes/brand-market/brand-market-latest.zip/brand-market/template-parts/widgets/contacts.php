<?php
/**
 * Widget body: the contacts of the site in the order the owner set.
 *
 * Every phone, the opening hours, every address and the e-mail stand as rows
 * of the header facts: an icon in a circle, the value and a note under it.
 * The messengers close the card as a row of chips. The row takes the value
 * and the link escaped, the note as plain text.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_parts  = isset( $args['parts'] ) ? array_values( (array) $args['parts'] ) : array();
$mvweb_phones = isset( $args['phones'] ) ? (array) $args['phones'] : array();
$mvweb_hours  = isset( $args['hours_rows'] ) ? (array) $args['hours_rows'] : array();
$mvweb_email  = isset( $args['email'] ) ? (string) $args['email'] : '';
$mvweb_places = isset( $args['places'] ) ? (array) $args['places'] : array();
$mvweb_chats  = isset( $args['messengers'] ) ? (array) $args['messengers'] : array();
$mvweb_look   = isset( $args['instance']['look'] ) && in_array( $args['instance']['look'], array( 'light', 'accent' ), true ) ? $args['instance']['look'] : 'dark';

$mvweb_row = static function ( $icon, $value, $note = '', $href = '' ) {
	$tag  = '' !== $href ? 'a' : 'div';
	$html = '<li><' . $tag . ' class="mvweb-t-fact"' . ( '' !== $href ? ' href="' . $href . '"' : '' ) . '>';

	$html .= '<span class="mvweb-t-fact__ico" aria-hidden="true">' . mvweb_theme_icon( $icon ) . '</span>';
	$html .= '<span class="mvweb-t-fact__text"><span class="mvweb-t-fact__value">' . $value . '</span>';

	if ( '' !== $note ) {
		$html .= '<span class="mvweb-t-fact__note">' . esc_html( $note ) . '</span>';
	}

	return $html . '</span></' . $tag . '></li>';
};

ob_start();

foreach ( $mvweb_parts as $mvweb_part ) {
	if ( 'phone' === $mvweb_part ) {
		foreach ( array_values( $mvweb_phones ) as $mvweb_nth => $mvweb_phone ) {
			$mvweb_label = isset( $mvweb_phone['label'] ) ? trim( (string) $mvweb_phone['label'] ) : '';
			$mvweb_note  = '' !== $mvweb_label ? $mvweb_label : ( 0 === $mvweb_nth ? (string) get_theme_mod( 'mvweb_header_facts_phone', __( 'Call us', 'brand-market' ) ) : '' );

			echo $mvweb_row( 'phone', esc_html( (string) $mvweb_phone['number'] ), $mvweb_note, esc_url( (string) $mvweb_phone['href'] ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from escaped values.
		}
	} elseif ( 'hours' === $mvweb_part && ! empty( $mvweb_hours ) ) {
		echo $mvweb_row( 'clock', esc_html( (string) array_shift( $mvweb_hours ) ), implode( ', ', $mvweb_hours ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from escaped values.
	} elseif ( 'email' === $mvweb_part && '' !== $mvweb_email ) {
		echo $mvweb_row( 'mail', esc_html( antispambot( $mvweb_email ) ), '', esc_attr( 'mailto:' . antispambot( $mvweb_email ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from escaped values.
	} elseif ( 'address' === $mvweb_part ) {
		foreach ( $mvweb_places as $mvweb_place ) {
			echo $mvweb_row( 'map-pin', esc_html( (string) $mvweb_place['street'] ), implode( ', ', array_filter( array( (string) $mvweb_place['city'], (string) $mvweb_place['hours'] ) ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from escaped values.
		}
	} elseif ( 'messengers' === $mvweb_part && ! empty( $mvweb_chats ) ) {
		?>
		<li class="mvweb-t-widget__chats">
			<?php foreach ( $mvweb_chats as $mvweb_id => $mvweb_chat ) : ?>
				<a class="mvweb-t-widget__chat mvweb-t-widget__chat--<?php echo esc_attr( sanitize_html_class( (string) $mvweb_id ) ); ?>" href="<?php echo esc_url( $mvweb_chat['url'] ); ?>" target="_blank" rel="noopener" data-qr>
					<span class="mvweb-t-widget__chat-ico" aria-hidden="true"><?php echo mvweb_theme_icon( mvweb_core_social_icon( $mvweb_id ), array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
					<span class="mvweb-t-widget__chat-name"><?php echo esc_html( $mvweb_chat['label'] ); ?></span>
				</a>
			<?php endforeach; ?>
		</li>
		<?php
	}
}

$mvweb_list = trim( (string) ob_get_clean() );

if ( '' === $mvweb_list ) {
	return;
}
?>
<ul class="mvweb-t-widget__contacts mvweb-t-widget__contacts--<?php echo esc_attr( $mvweb_look ); ?>">
	<?php echo $mvweb_list; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled above from escaped values. ?>
</ul>
