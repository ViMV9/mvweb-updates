<?php
/**
 * Widget template: the author of the article or of the author page.
 *
 * Two looks: a card in the centre with a button to all the articles, a photo on
 * the left with a link. The parts come in the order set in the widget; the
 * links are the part of the author box under the article.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_parts  = isset( $args['parts'] ) ? (array) $args['parts'] : array();
$mvweb_author = isset( $args['author'] ) ? absint( $args['author'] ) : 0;
$mvweb_name   = isset( $args['name'] ) ? (string) $args['name'] : '';
$mvweb_url    = isset( $args['url'] ) ? (string) $args['url'] : '';
$mvweb_role   = isset( $args['role'] ) ? (string) $args['role'] : '';
$mvweb_bio    = isset( $args['bio'] ) ? (string) $args['bio'] : '';
$mvweb_view   = isset( $args['view'] ) && 'row' === $args['view'] ? 'row' : 'center';

if ( '' === $mvweb_name ) {
	return;
}

$mvweb_photo = '';

if ( in_array( 'photo', $mvweb_parts, true ) ) {
	$mvweb_photo = (string) get_avatar(
		$mvweb_author,
		'row' === $mvweb_view ? 80 : 120,
		'',
		'',
		array(
			'class'         => 'mvweb-t-avatar ' . ( 'row' === $mvweb_view ? 'mvweb-t-avatar--lg' : 'mvweb-t-avatar--xl' ),
			'force_display' => false,
			'loading'       => 'lazy',
		)
	);
}
?>
<div class="<?php echo esc_attr( 'mvweb-t-widget__author mvweb-t-widget__author--' . $mvweb_view ); ?>">
	<div class="mvweb-t-widget__author-head">
		<?php echo $mvweb_photo; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag. ?>
		<div class="mvweb-t-widget__author-who">
			<?php if ( '' !== $mvweb_url && 'row' === $mvweb_view ) : ?>
				<a class="mvweb-t-author__name" href="<?php echo esc_url( $mvweb_url ); ?>"><?php echo esc_html( $mvweb_name ); ?></a>
			<?php else : ?>
				<p class="mvweb-t-author__name"><?php echo esc_html( $mvweb_name ); ?></p>
			<?php endif; ?>
			<?php if ( '' !== $mvweb_role ) : ?>
				<p class="mvweb-t-author__label"><?php echo esc_html( $mvweb_role ); ?></p>
			<?php endif; ?>
		</div>
	</div>
	<?php foreach ( $mvweb_parts as $mvweb_part ) : ?>
		<?php if ( 'bio' === $mvweb_part && '' !== $mvweb_bio ) : ?>
			<p class="mvweb-t-author__bio"><?php echo esc_html( $mvweb_bio ); ?></p>
		<?php elseif ( 'links' === $mvweb_part ) : ?>
			<?php get_template_part( 'template-parts/author-box/socials', null, array( 'author' => $mvweb_author ) ); ?>
		<?php endif; ?>
	<?php endforeach; ?>
	<?php if ( '' !== $mvweb_url ) : ?>
		<?php if ( 'row' === $mvweb_view ) : ?>
			<a class="mvweb-t-author__more" href="<?php echo esc_url( $mvweb_url ); ?>"><?php esc_html_e( 'All posts of the author', 'brand-market' ); ?> <?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></a>
		<?php else : ?>
			<a class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-btn--sm mvweb-t-btn--block" href="<?php echo esc_url( $mvweb_url ); ?>"><?php esc_html_e( 'All posts of the author', 'brand-market' ); ?></a>
		<?php endif; ?>
	<?php endif; ?>
</div>
