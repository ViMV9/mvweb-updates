<?php
/**
 * The strip "Addresses of the city" on a phone, when the city has several places.
 *
 * List: one line with the number of places, the list opens under it. Select:
 * a field with the chosen place and a sheet with all of them. Stepper: the
 * places one by one between arrows. Open: the place open now and the list of
 * the others. The script of the theme switches the places and counts those
 * open by the status the core paints.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_places   = $args['places'];
$mvweb_mode     = $args['mode'];
$mvweb_count    = count( $mvweb_places );
$mvweb_contacts = mvweb_core_contacts();
$mvweb_city_tel = empty( $mvweb_contacts['phones'][0]['href'] ) ? '' : $mvweb_contacts['phones'][0]['href'];
$mvweb_sm       = array( 'class' => 'mvweb-t-icon--sm' );
$mvweb_first    = mvweb_theme_place_name( $mvweb_places[0] );
/* translators: 1: number of the place, 2: number of all places. */
$mvweb_pos = __( 'Address %1$s of %2$s', 'brand-market' );

$mvweb_panels = '';

if ( 'list' !== $mvweb_mode ) {
	foreach ( $mvweb_places as $mvweb_i => $mvweb_place ) {
		$mvweb_hours = mvweb_core_hours_line( $mvweb_place['hours'] );
		$mvweb_note  = trim( (string) $mvweb_place['note'] );
		$mvweb_url   = '' !== $mvweb_place['route_url'] ? $mvweb_place['route_url'] : $mvweb_place['map_link'];
		$mvweb_tel   = empty( $mvweb_place['phones'][0]['href'] ) ? $mvweb_city_tel : $mvweb_place['phones'][0]['href'];

		$mvweb_panels .= '<div class="mvweb-t-places__panel" data-place-panel data-name="' . esc_attr( mvweb_theme_place_name( $mvweb_place ) ) . '"' . ( $mvweb_i ? ' hidden' : '' ) . '>';
		$mvweb_panels .= '<span class="mvweb-t-places__where">' . mvweb_theme_icon( 'map-pin', $mvweb_sm ) . '<b>' . esc_html( trim( (string) $mvweb_place['address'] ) ) . '</b>' . ( '' !== $mvweb_note ? ', ' . esc_html( $mvweb_note ) : '' ) . '</span>';
		$mvweb_panels .= '' !== $mvweb_hours ? '<span class="mvweb-t-places__muted">' . esc_html( $mvweb_hours ) . '</span>' : '';
		$mvweb_panels .= mvweb_theme_place_status( $mvweb_place );

		if ( '' !== $mvweb_url || '' !== $mvweb_tel ) {
			$mvweb_panels .= '<span class="mvweb-t-places__acts">';
			$mvweb_panels .= '' !== $mvweb_url ? '<a class="mvweb-t-btn mvweb-t-btn--sm" href="' . esc_url( $mvweb_url ) . '" target="_blank" rel="noopener">' . mvweb_theme_icon( 'route', $mvweb_sm ) . esc_html__( 'Route', 'brand-market' ) . '</a>' : '';
			$mvweb_panels .= '' !== $mvweb_tel ? '<a class="mvweb-t-btn mvweb-t-btn--sm mvweb-t-btn--outline" href="' . esc_url( $mvweb_tel ) . '">' . mvweb_theme_icon( 'phone', $mvweb_sm ) . esc_html__( 'Call', 'brand-market' ) . '</a>' : '';
			$mvweb_panels .= '</span>';
		}

		$mvweb_panels .= '</div>';
	}
}

$mvweb_list = '';

if ( 'list' === $mvweb_mode || 'open' === $mvweb_mode ) {
	$mvweb_list = '<ul class="mvweb-t-places__mlist">';

	foreach ( $mvweb_places as $mvweb_i => $mvweb_place ) {
		$mvweb_url   = '' !== $mvweb_place['route_url'] ? $mvweb_place['route_url'] : $mvweb_place['map_link'];
		$mvweb_list .= '<li class="mvweb-t-places__mitem" data-place' . ( 'open' === $mvweb_mode && 0 === $mvweb_i ? ' hidden' : '' ) . '>';
		$mvweb_list .= '<b>' . esc_html( mvweb_theme_place_name( $mvweb_place ) ) . '</b>';
		$mvweb_list .= '<span class="mvweb-t-places__mline"><span class="mvweb-t-places__muted">' . esc_html( trim( (string) $mvweb_place['address'] ) ) . '</span>' . mvweb_theme_place_status( $mvweb_place, true ) . '</span>';
		$mvweb_list .= '' !== $mvweb_url ? '<a class="mvweb-t-places__go" href="' . esc_url( $mvweb_url ) . '" target="_blank" rel="noopener" title="' . esc_attr__( 'Route', 'brand-market' ) . '">' . mvweb_theme_icon( 'route', $mvweb_sm ) . '<span class="screen-reader-text">' . esc_html__( 'Route', 'brand-market' ) . '</span></a>' : '';
		$mvweb_list .= '</li>';
	}

	$mvweb_list .= '</ul>';
}

/* translators: 1: number of places open now, 2: number of all places. */
$mvweb_open_now = __( 'Open now: %1$s of %2$s', 'brand-market' );
?>
<div class="mvweb-t-places__m mvweb-t-places__m--<?php echo esc_attr( $mvweb_mode ); ?>" data-places-m="<?php echo esc_attr( $mvweb_mode ); ?>">
	<?php if ( 'list' === $mvweb_mode ) : ?>
		<details class="mvweb-t-places__acc">
			<summary class="mvweb-t-places__sum">
				<?php echo mvweb_theme_icon( 'map-pin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="mvweb-t-places__sum-text">
					<b>
						<?php
						/* translators: %d: number of addresses in the city. */
						echo esc_html( sprintf( _n( '%d address', '%d addresses', $mvweb_count, 'brand-market' ), $mvweb_count ) );
						?>
					</b>
					<span class="mvweb-t-places__open" data-places-count="<?php echo esc_attr( $mvweb_open_now ); ?>" hidden></span>
				</span>
				<?php echo mvweb_theme_icon( 'chevron-down', $mvweb_sm ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			</summary>
			<?php echo $mvweb_list; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts. ?>
		</details>
	<?php elseif ( 'select' === $mvweb_mode ) : ?>
		<button class="mvweb-t-places__pick" type="button" aria-haspopup="dialog" data-places-pick>
			<span class="mvweb-t-places__pick-text">
				<small data-places-pos="<?php echo esc_attr( $mvweb_pos ); ?>"><?php echo esc_html( sprintf( $mvweb_pos, 1, $mvweb_count ) ); ?></small>
				<b data-places-name><?php echo esc_html( $mvweb_first ); ?></b>
			</span>
			<?php echo mvweb_theme_icon( 'chevron-down' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		</button>
		<?php echo $mvweb_panels; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts. ?>
		<dialog class="mvweb-t-places__sheet" data-places-sheet aria-label="<?php esc_attr_e( 'Addresses', 'brand-market' ); ?>">
			<div class="mvweb-t-places__sheet-in">
				<div class="mvweb-t-places__sheet-head">
					<b><?php esc_html_e( 'Addresses', 'brand-market' ); ?></b>
					<form method="dialog">
						<button class="mvweb-t-round" type="submit" title="<?php esc_attr_e( 'Close', 'brand-market' ); ?>">
							<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
							<span class="screen-reader-text"><?php esc_html_e( 'Close', 'brand-market' ); ?></span>
						</button>
					</form>
				</div>
				<?php foreach ( $mvweb_places as $mvweb_i => $mvweb_place ) : ?>
					<button class="mvweb-t-places__opt" type="button" aria-pressed="<?php echo 0 === $mvweb_i ? 'true' : 'false'; ?>" data-places-go="<?php echo esc_attr( (string) $mvweb_i ); ?>">
						<b><?php echo esc_html( mvweb_theme_place_name( $mvweb_place ) ); ?></b>
						<span class="mvweb-t-places__muted"><?php echo esc_html( trim( (string) $mvweb_place['address'] ) ); ?></span>
						<?php echo mvweb_theme_place_status( $mvweb_place, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped attribute. ?>
					</button>
				<?php endforeach; ?>
			</div>
		</dialog>
	<?php elseif ( 'stepper' === $mvweb_mode ) : ?>
		<div class="mvweb-t-places__step">
			<button class="mvweb-t-round" type="button" title="<?php esc_attr_e( 'Previous address', 'brand-market' ); ?>" data-places-prev disabled>
				<?php echo mvweb_theme_icon( 'chevron-left' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Previous address', 'brand-market' ); ?></span>
			</button>
			<span class="mvweb-t-places__step-mid" aria-live="polite">
				<b data-places-name><?php echo esc_html( $mvweb_first ); ?></b>
				<span class="mvweb-t-places__muted" data-places-pos="<?php echo esc_attr( $mvweb_pos ); ?>"><?php echo esc_html( sprintf( $mvweb_pos, 1, $mvweb_count ) ); ?></span>
				<span class="mvweb-t-places__dots" aria-hidden="true">
					<?php for ( $mvweb_i = 0; $mvweb_i < $mvweb_count; $mvweb_i++ ) : ?>
						<span data-places-dot<?php echo 0 === $mvweb_i ? ' aria-current="true"' : ''; ?>></span>
					<?php endfor; ?>
				</span>
			</span>
			<button class="mvweb-t-round" type="button" title="<?php esc_attr_e( 'Next address', 'brand-market' ); ?>" data-places-next>
				<?php echo mvweb_theme_icon( 'chevron-right' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Next address', 'brand-market' ); ?></span>
			</button>
		</div>
		<?php echo $mvweb_panels; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts. ?>
	<?php else : ?>
		<span class="mvweb-t-places__badge" data-places-badge hidden><?php esc_html_e( 'Open now', 'brand-market' ); ?></span>
		<b class="mvweb-t-places__name" data-places-name><?php echo esc_html( $mvweb_first ); ?></b>
		<?php echo $mvweb_panels; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts. ?>
		<details class="mvweb-t-places__acc">
			<summary class="mvweb-t-places__more">
				<?php
				/* translators: %d: number of the other addresses in the city. */
				echo esc_html( sprintf( _n( '%d more address', '%d more addresses', $mvweb_count - 1, 'brand-market' ), $mvweb_count - 1 ) );
				?>
				<?php echo mvweb_theme_icon( 'chevron-down', $mvweb_sm ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			</summary>
			<?php echo $mvweb_list; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts. ?>
		</details>
	<?php endif; ?>
</div>
