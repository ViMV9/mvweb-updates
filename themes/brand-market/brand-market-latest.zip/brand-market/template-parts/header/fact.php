<?php
/**
 * One contact of the header view "Contacts in circles": an icon in a circle,
 * the value and the caption under it. The argument more is a ready button that
 * follows the caption; the fact is then a plain block, never a link.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_value = isset( $args['value'] ) ? trim( (string) $args['value'] ) : '';

if ( '' === $mvweb_value ) {
	return;
}

$mvweb_note  = isset( $args['note'] ) ? trim( (string) $args['note'] ) : '';
$mvweb_href  = isset( $args['href'] ) ? (string) $args['href'] : '';
$mvweb_attrs = isset( $args['attrs'] ) ? (string) $args['attrs'] : '';
$mvweb_more  = isset( $args['more'] ) ? (string) $args['more'] : '';
$mvweb_tag   = '' !== $mvweb_href ? 'a' : ( '' !== $mvweb_attrs ? 'button' : 'div' );
$mvweb_class = trim( 'mvweb-t-fact ' . ( isset( $args['class'] ) ? (string) $args['class'] : '' ) );
$mvweb_title = '' !== $mvweb_note ? $mvweb_value . ', ' . $mvweb_note : $mvweb_value;
?>
<<?php echo esc_html( $mvweb_tag ); ?> class="<?php echo esc_attr( $mvweb_class ); ?>" title="<?php echo esc_attr( $mvweb_title ); ?>"
	<?php
	if ( 'a' === $mvweb_tag ) {
		echo ' href="' . esc_url( $mvweb_href ) . '"' . ( ! empty( $args['external'] ) ? ' target="_blank" rel="noopener"' : '' );
	} elseif ( 'button' === $mvweb_tag ) {
		echo ' type="button" ' . $mvweb_attrs; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The caller escapes the attributes.
	}
	?>
>
	<span class="mvweb-t-fact__ico"><?php echo mvweb_theme_icon( isset( $args['icon'] ) ? (string) $args['icon'] : 'phone' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
	<span class="mvweb-t-fact__text">
		<span class="mvweb-t-fact__value"><?php echo esc_html( $mvweb_value ); ?></span>
		<?php if ( '' !== $mvweb_note || '' !== $mvweb_more ) : ?>
			<span class="mvweb-t-fact__note"><?php echo esc_html( $mvweb_note ); ?><?php echo $mvweb_more; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The caller escapes the button. ?></span>
		<?php endif; ?>
	</span>
	<?php if ( 'button' === $mvweb_tag ) : ?>
		<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm mvweb-t-fact__arrow' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	<?php endif; ?>
</<?php echo esc_html( $mvweb_tag ); ?>>
