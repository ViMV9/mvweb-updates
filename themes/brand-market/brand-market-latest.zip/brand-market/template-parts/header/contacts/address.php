<?php
/**
 * Part of the header contacts: the address in one line, or, when the chosen
 * city has several places, a button with the list of them.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_addresses = mvweb_core_header_addresses( $args['contacts'] );
$mvweb_count     = count( $mvweb_addresses );

if ( 0 === $mvweb_count ) {
	return;
}

if ( 1 === $mvweb_count ) :
	?>
	<div class="mvweb-t-hc__addr">
		<span class="mvweb-t-hc__addr-main">
			<?php echo mvweb_theme_icon( 'map-pin', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span><?php echo esc_html( mvweb_core_address_text( $mvweb_addresses[0] ) ); ?></span>
		</span>
	</div>
	<?php
	return;
endif;

$mvweb_id = wp_unique_id( 'mvweb-t-places-' );
?>
<div class="mvweb-t-hc__addr mvweb-t-hc__places" data-places>
	<button class="mvweb-t-hc__addr-main mvweb-t-hc__places-btn" type="button" aria-expanded="false" aria-controls="<?php echo esc_attr( $mvweb_id ); ?>" data-places-toggle>
		<?php echo mvweb_theme_icon( 'map-pin', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<span>
			<?php
			/* translators: %d: number of addresses in the city. */
			echo esc_html( sprintf( _n( '%d address', '%d addresses', $mvweb_count, 'brand-market' ), $mvweb_count ) );
			?>
		</span>
		<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
	</button>

	<div class="mvweb-t-city__pop mvweb-t-hc__places-pop" id="<?php echo esc_attr( $mvweb_id ); ?>" data-places-pop hidden>
		<div class="mvweb-t-city__title"><?php esc_html_e( 'Addresses', 'brand-market' ); ?></div>
		<ul class="mvweb-t-hc__places-list">
			<?php foreach ( $mvweb_addresses as $mvweb_place ) : ?>
				<?php
				$mvweb_hours = mvweb_core_hours_line( $mvweb_place['hours'] );
				$mvweb_route = '' !== $mvweb_place['route_url'] ? $mvweb_place['route_url'] : $mvweb_place['map_link'];
				?>
				<li class="mvweb-t-hc__place">
					<?php if ( '' !== trim( (string) $mvweb_place['title'] ) ) : ?>
						<small><?php echo esc_html( $mvweb_place['title'] ); ?></small>
					<?php endif; ?>
					<b><?php echo esc_html( $mvweb_place['address'] ); ?></b>
					<?php if ( '' !== trim( (string) $mvweb_place['note'] ) ) : ?>
						<small><?php echo esc_html( $mvweb_place['note'] ); ?></small>
					<?php endif; ?>
					<?php if ( '' !== $mvweb_hours ) : ?>
						<small><?php echo esc_html( $mvweb_hours ); ?></small>
					<?php endif; ?>
					<?php if ( '' !== $mvweb_route ) : ?>
						<a class="mvweb-t-hc__place-route" href="<?php echo esc_url( $mvweb_route ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Route', 'brand-market' ); ?></a>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</div>
