<?php
/**
 * Part of the header contacts: the address in one line, or, when the chosen
 * city has several places, a button with the list of them.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_addresses = mvweb_core_header_addresses( $args['contacts'] );
$mvweb_count     = count( $mvweb_addresses );

if ( 0 === $mvweb_count ) {
	return;
}

$mvweb_fact = ! empty( $args['fact'] );
$mvweb_city = trim( (string) $mvweb_addresses[0]['city'] );
$mvweb_note = $mvweb_fact ? trim( (string) get_theme_mod( 'mvweb_header_facts_address', '' ) ) : '';
$mvweb_note = '' !== $mvweb_note ? $mvweb_note : $mvweb_city;

if ( $mvweb_fact && 1 === $mvweb_count ) {
	$mvweb_street = trim( (string) $mvweb_addresses[0]['address'] );
	$mvweb_route  = '' !== $mvweb_addresses[0]['route_url'] ? $mvweb_addresses[0]['route_url'] : $mvweb_addresses[0]['map_link'];
	$mvweb_how    = trim( (string) ( empty( $args['contacts']['branches'] ) ? mvweb_cz_profile( 'address_how', '' ) : $mvweb_addresses[0]['note'] ) );
	$mvweb_item   = array(
		'icon'     => 'map-pin',
		'value'    => '' !== $mvweb_street ? $mvweb_street : $mvweb_city,
		'note'     => '' !== $mvweb_street ? $mvweb_note : '',
		'href'     => $mvweb_route,
		'external' => true,
		'class'    => 'mvweb-t-fact--addr',
	);

	if ( '' === $mvweb_how ) {
		get_template_part( 'template-parts/header/fact', null, $mvweb_item );

		return;
	}

	$mvweb_id           = wp_unique_id( 'mvweb-t-how-' );
	$mvweb_item['href'] = '';
	$mvweb_item['more'] = '<button class="mvweb-t-fact__more" type="button" aria-expanded="false" aria-controls="' . esc_attr( $mvweb_id ) . '" data-places-toggle>' . esc_html__( 'More details', 'brand-market' ) . '</button>';
	?>
	<div class="mvweb-t-fact-box mvweb-t-fact--addr mvweb-t-hc__places" data-places>
		<?php get_template_part( 'template-parts/header/fact', null, $mvweb_item ); ?>
		<div class="mvweb-t-city__pop mvweb-t-hc__places-pop" id="<?php echo esc_attr( $mvweb_id ); ?>" data-places-pop hidden>
			<div class="mvweb-t-city__title"><?php esc_html_e( 'How to find us', 'brand-market' ); ?></div>
			<p class="mvweb-t-hc__how"><?php echo nl2br( esc_html( $mvweb_how ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped before the line breaks. ?></p>
			<?php if ( '' !== $mvweb_route ) : ?>
				<a class="mvweb-t-hc__place-route" href="<?php echo esc_url( $mvweb_route ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Route', 'brand-market' ); ?></a>
			<?php endif; ?>
		</div>
	</div>
	<?php
	return;
}

if ( 1 === $mvweb_count ) :
	?>
	<div class="mvweb-t-hc__addr">
		<span class="mvweb-t-hc__addr-main">
			<?php echo mvweb_theme_icon( 'map-pin', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span><?php echo esc_html( mvweb_core_address_text( $mvweb_addresses[0] ) ); ?></span>
		</span>
	</div>
	<?php
	return;
endif;

$mvweb_id = wp_unique_id( 'mvweb-t-places-' );
/* translators: %d: number of addresses in the city. */
$mvweb_many = sprintf( _n( '%d address', '%d addresses', $mvweb_count, 'brand-market' ), $mvweb_count );
?>
<div class="<?php echo $mvweb_fact ? 'mvweb-t-fact-box mvweb-t-fact--addr' : 'mvweb-t-hc__addr'; ?> mvweb-t-hc__places" data-places>
	<?php if ( $mvweb_fact ) : ?>
		<?php
		get_template_part(
			'template-parts/header/fact',
			null,
			array(
				'icon'  => 'map-pin',
				'value' => $mvweb_many,
				'note'  => $mvweb_note,
				'attrs' => 'aria-expanded="false" aria-controls="' . esc_attr( $mvweb_id ) . '" data-places-toggle',
				'class' => 'mvweb-t-hc__places-btn',
			)
		);
		?>
	<?php else : ?>
		<button class="mvweb-t-hc__addr-main mvweb-t-hc__places-btn" type="button" aria-expanded="false" aria-controls="<?php echo esc_attr( $mvweb_id ); ?>" data-places-toggle>
			<?php echo mvweb_theme_icon( 'map-pin', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<span><?php echo esc_html( $mvweb_many ); ?></span>
			<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		</button>
	<?php endif; ?>

	<div class="mvweb-t-city__pop mvweb-t-hc__places-pop" id="<?php echo esc_attr( $mvweb_id ); ?>" data-places-pop hidden>
		<div class="mvweb-t-city__title"><?php esc_html_e( 'Addresses', 'brand-market' ); ?></div>
		<ul class="mvweb-t-hc__places-list">
			<?php foreach ( $mvweb_addresses as $mvweb_place ) : ?>
				<?php
				$mvweb_hours = mvweb_core_hours_line( $mvweb_place['hours'] );
				$mvweb_route = '' !== $mvweb_place['route_url'] ? $mvweb_place['route_url'] : $mvweb_place['map_link'];
				?>
				<li class="mvweb-t-hc__place">
					<?php if ( '' !== trim( (string) $mvweb_place['title'] ) ) : ?>
						<small><?php echo esc_html( $mvweb_place['title'] ); ?></small>
					<?php endif; ?>
					<b><?php echo esc_html( $mvweb_place['address'] ); ?></b>
					<?php if ( '' !== trim( (string) $mvweb_place['note'] ) ) : ?>
						<small><?php echo esc_html( $mvweb_place['note'] ); ?></small>
					<?php endif; ?>
					<?php if ( '' !== $mvweb_hours ) : ?>
						<small><?php echo esc_html( $mvweb_hours ); ?></small>
					<?php endif; ?>
					<?php if ( '' !== $mvweb_route ) : ?>
						<a class="mvweb-t-hc__place-route" href="<?php echo esc_url( $mvweb_route ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Route', 'brand-market' ); ?></a>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</div>
