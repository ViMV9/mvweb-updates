<?php
/**
 * The strip "Addresses of the city" under the header.
 *
 * Line: one place in a row; several places as chips with a window each on a
 * computer and one button with the list on a phone. Cards: a card for every
 * place. Tabs: the names of the places, the chosen one below.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_view   = $args['view'];
$mvweb_places = $args['places'];
$mvweb_count  = count( $mvweb_places );

$mvweb_where = static function ( $place, $with_name ) {
	$note = trim( (string) $place['note'] );
	$name = $with_name && '' !== trim( (string) $place['title'] ) ? '<b>' . esc_html( mvweb_theme_place_name( $place ) ) . '</b>, ' : '';

	return $name . esc_html( trim( (string) $place['address'] ) ) . ( '' !== $note ? '<span class="mvweb-t-places__note">, ' . esc_html( $note ) . '</span>' : '' );
};

$mvweb_classes = 'mvweb-t-places mvweb-t-places--' . $mvweb_view . ( 1 === $mvweb_count ? ' mvweb-t-places--one' : ' mvweb-t-places--multi' ) . ( $args['desktop'] ? ' mvweb-t-places--desktop' : '' );
?>
<div class="<?php echo esc_attr( $mvweb_classes ); ?>"<?php echo 'tabs' === $mvweb_view && $mvweb_count > 1 ? ' data-places-tabs' : ''; ?>>
	<div class="mvweb-t-container mvweb-t-places__inner">
		<?php if ( 'cards' === $mvweb_view ) : ?>
			<ul class="mvweb-t-places__cards">
				<?php foreach ( $mvweb_places as $mvweb_place ) : ?>
					<?php $mvweb_hours = mvweb_core_hours_line( $mvweb_place['hours'] ); ?>
					<li class="mvweb-t-places__card">
						<b class="mvweb-t-places__name"><?php echo esc_html( mvweb_theme_place_name( $mvweb_place ) ); ?></b>
						<?php if ( '' !== trim( (string) $mvweb_place['title'] ) ) : ?>
							<span><?php echo $mvweb_where( $mvweb_place, false ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts. ?></span>
						<?php endif; ?>
						<?php if ( '' !== $mvweb_hours ) : ?>
							<span class="mvweb-t-places__muted"><?php echo esc_html( $mvweb_hours ); ?></span>
						<?php endif; ?>
						<span class="mvweb-t-places__row mvweb-t-places__foot"><?php echo mvweb_theme_place_status( $mvweb_place ) . mvweb_theme_place_route( $mvweb_place ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts. ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php elseif ( 1 === $mvweb_count || 'tabs' === $mvweb_view ) : ?>
			<?php if ( $mvweb_count > 1 ) : ?>
				<?php $mvweb_tabs = wp_unique_id( 'mvweb-t-places-tab-' ); ?>
				<div class="mvweb-t-places__tabs" role="tablist">
					<?php foreach ( $mvweb_places as $mvweb_i => $mvweb_place ) : ?>
						<button class="mvweb-t-places__tab" type="button" role="tab" id="<?php echo esc_attr( $mvweb_tabs . '-' . $mvweb_i ); ?>" aria-controls="<?php echo esc_attr( $mvweb_tabs . '-p' . $mvweb_i ); ?>" aria-selected="<?php echo 0 === $mvweb_i ? 'true' : 'false'; ?>" tabindex="<?php echo 0 === $mvweb_i ? '0' : '-1'; ?>">
							<?php echo esc_html( mvweb_theme_place_name( $mvweb_place ) ); ?>
						</button>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<?php foreach ( $mvweb_places as $mvweb_i => $mvweb_place ) : ?>
				<?php $mvweb_hours = mvweb_core_hours_line( $mvweb_place['hours'] ); ?>
				<div class="mvweb-t-places__line"<?php echo $mvweb_count > 1 ? ' role="tabpanel" id="' . esc_attr( $mvweb_tabs . '-p' . $mvweb_i ) . '" aria-labelledby="' . esc_attr( $mvweb_tabs . '-' . $mvweb_i ) . '"' . ( $mvweb_i ? ' hidden' : '' ) : ''; ?>>
					<span class="mvweb-t-places__where"><?php echo mvweb_theme_icon( 'map-pin', array( 'class' => 'mvweb-t-icon--sm' ) ) . $mvweb_where( $mvweb_place, 1 === $mvweb_count ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts. ?></span>
					<?php if ( '' !== $mvweb_hours ) : ?>
						<span class="mvweb-t-places__muted"><?php echo esc_html( $mvweb_hours ); ?></span>
					<?php endif; ?>
					<?php echo mvweb_theme_place_status( $mvweb_place ) . mvweb_theme_place_route( $mvweb_place ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts. ?>
				</div>
			<?php endforeach; ?>
		<?php else : ?>
			<ul class="mvweb-t-places__chips">
				<?php foreach ( $mvweb_places as $mvweb_place ) : ?>
					<?php $mvweb_id = wp_unique_id( 'mvweb-t-place-' ); ?>
					<li class="mvweb-t-places__chip" data-places>
						<button class="mvweb-t-places__chip-btn" type="button" aria-expanded="false" aria-controls="<?php echo esc_attr( $mvweb_id ); ?>" data-places-toggle>
							<b><?php echo esc_html( mvweb_theme_place_name( $mvweb_place ) ); ?></b>
							<?php echo mvweb_theme_place_status( $mvweb_place, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped attribute. ?>
						</button>
						<?php echo mvweb_theme_places_pop( array( $mvweb_place ), $mvweb_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped parts. ?>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>

		<?php
		if ( $mvweb_count > 1 ) {
			get_template_part(
				'template-parts/header/places-mobile',
				null,
				array(
					'places' => $mvweb_places,
					'mode'   => $args['mobile'],
				)
			);
		}
		?>
	</div>
</div>
