<?php
/**
 * The column of widgets: a list of widgets in an aside.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_area  = isset( $args['area'] ) ? (string) $args['area'] : '';
$mvweb_class = isset( $args['class'] ) ? (string) $args['class'] : '';
$mvweb_id    = isset( $args['id'] ) ? (string) $args['id'] : '';
$mvweb_html  = mvweb_core_sidebar_html( $mvweb_area );

if ( '' === $mvweb_html ) {
	return;
}
?>
<aside<?php echo '' === $mvweb_id ? '' : ' id="' . esc_attr( $mvweb_id ) . '"'; ?> class="<?php echo esc_attr( trim( $mvweb_class . ' mvweb-t-sidebar' ) ); ?>" aria-label="<?php esc_attr_e( 'Sidebar', 'brand-market' ); ?>">
	<?php echo $mvweb_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the widgets, every value escaped there. ?>
</aside>
