<?php
/**
 * A line of the cart: the photo, the composed information, the quantity, the sum and the remove link.
 *
 * The part of the line that names the good is the composition "cart-line";
 * the quantity, the sum and the link stay where the grid of the line puts them.
 *
 * Arguments: key (cart item key), item (cart item).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_key  = isset( $args['key'] ) ? (string) $args['key'] : '';
$mvweb_item = isset( $args['item'] ) && is_array( $args['item'] ) ? $args['item'] : array();

if ( '' === $mvweb_key || empty( $mvweb_item['data'] ) ) {
	return;
}

$mvweb_product = apply_filters( 'woocommerce_cart_item_product', $mvweb_item['data'], $mvweb_item, $mvweb_key );

if ( ! $mvweb_product instanceof WC_Product || ! $mvweb_product->exists() || $mvweb_item['quantity'] <= 0 || ! apply_filters( 'woocommerce_cart_item_visible', true, $mvweb_item, $mvweb_key ) ) {
	return;
}

$mvweb_id    = mvweb_core_product_parent( $mvweb_product );
$mvweb_base  = method_exists( WC()->cart, 'get_item_product_name' ) ? WC()->cart->get_item_product_name( $mvweb_item, $mvweb_product ) : $mvweb_product->get_name();
$mvweb_name  = apply_filters( 'woocommerce_cart_item_name', $mvweb_base, $mvweb_item, $mvweb_key );
$mvweb_link  = apply_filters( 'woocommerce_cart_item_permalink', $mvweb_product->is_visible() ? $mvweb_product->get_permalink( $mvweb_item ) : '', $mvweb_item, $mvweb_key );
$mvweb_plain = wp_strip_all_tags( (string) $mvweb_name );
$mvweb_part  = array(
	'key'     => $mvweb_key,
	'item'    => $mvweb_item,
	'product' => $mvweb_product,
	'id'      => $mvweb_id,
	'tier'    => mvweb_core_tier_line_id( $mvweb_item['product_id'] ?? 0, $mvweb_item['variation_id'] ?? 0 ),
	'name'    => $mvweb_name,
	'base'    => $mvweb_base,
	'link'    => $mvweb_link,
	'qty'     => (int) $mvweb_item['quantity'],
	'cell'    => 'info',
);

if ( $mvweb_product->is_sold_individually() ) {
	$mvweb_min = 1;
	$mvweb_max = 1;
} else {
	$mvweb_min = 0;
	$mvweb_max = $mvweb_product->get_max_purchase_quantity();
}

$mvweb_field = wc_get_quantity_input_args(
	array(
		'input_name'   => 'cart[' . $mvweb_key . '][qty]',
		'input_value'  => $mvweb_item['quantity'],
		'max_value'    => $mvweb_max,
		'min_value'    => $mvweb_min,
		'product_name' => $mvweb_plain,
	),
	$mvweb_product
);
/* translators: %s: name of the good. */
$mvweb_label = sprintf( __( 'Quantity of %s', 'brand-market' ), $mvweb_plain );
$mvweb_fixed = '' !== $mvweb_field['max_value'] && (float) $mvweb_field['min_value'] === (float) $mvweb_field['max_value'];
?>
<article class="mvweb-t-cline woocommerce-cart-form__cart-item <?php echo esc_attr( apply_filters( 'woocommerce_cart_item_class', 'cart_item', $mvweb_item, $mvweb_key ) ); ?>">
	<a class="mvweb-t-cline__media" href="<?php echo esc_url( '' !== $mvweb_link ? $mvweb_link : '#' ); ?>" tabindex="-1" aria-hidden="true">
		<?php echo apply_filters( 'woocommerce_cart_item_thumbnail', $mvweb_product->get_image( 'mvweb_card', array( 'loading' => 'lazy' ) ), $mvweb_item, $mvweb_key ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WooCommerce image markup. ?>
	</a>
	<div class="mvweb-t-cline__info">
		<?php mvweb_core_render_layout( 'cart-line', $mvweb_part ); ?>
	</div>
	<div class="mvweb-t-cline__qty">
		<?php
		ob_start();

		if ( $mvweb_fixed ) :
			?>
			<input type="hidden" name="<?php echo esc_attr( $mvweb_field['input_name'] ); ?>" value="<?php echo esc_attr( $mvweb_field['min_value'] ); ?>">
		<?php else : ?>
			<div class="mvweb-t-qty" data-qty>
				<button class="mvweb-t-qty__btn" type="button" data-qty-minus title="<?php esc_attr_e( 'Less', 'brand-market' ); ?>">
					<?php echo mvweb_theme_icon( 'minus', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<span class="screen-reader-text"><?php esc_html_e( 'Less', 'brand-market' ); ?></span>
				</button>
				<input
					class="mvweb-t-qty__input qty"
					type="text"
					inputmode="<?php echo esc_attr( $mvweb_field['inputmode'] ); ?>"
					id="<?php echo esc_attr( $mvweb_field['input_id'] ); ?>"
					name="<?php echo esc_attr( $mvweb_field['input_name'] ); ?>"
					value="<?php echo esc_attr( $mvweb_field['input_value'] ); ?>"
					autocomplete="off"
					data-qty-input
					data-qty-min="<?php echo esc_attr( $mvweb_field['min_value'] ); ?>"
					data-qty-max="<?php echo esc_attr( $mvweb_field['max_value'] ); ?>"
					data-qty-step="<?php echo esc_attr( $mvweb_field['step'] ); ?>"
					aria-label="<?php echo esc_attr( $mvweb_label ); ?>"
				>
				<button class="mvweb-t-qty__btn" type="button" data-qty-plus title="<?php esc_attr_e( 'More', 'brand-market' ); ?>">
					<?php echo mvweb_theme_icon( 'plus', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<span class="screen-reader-text"><?php esc_html_e( 'More', 'brand-market' ); ?></span>
				</button>
			</div>
			<?php
		endif;

		echo apply_filters( 'woocommerce_cart_item_quantity', trim( (string) ob_get_clean() ), $mvweb_key, $mvweb_item ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The markup above, escaped where it is printed.
		?>
	</div>
	<?php
	$mvweb_part['cell'] = 'limit';

	if ( mvweb_core_layout_has( 'cart-line', 'limit' ) && ! $mvweb_fixed ) {
		get_template_part( 'template-parts/cart-line/limit', null, $mvweb_part );
	}
	?>
	<p class="mvweb-t-cline__total"><?php echo apply_filters( 'woocommerce_cart_item_subtotal', WC()->cart->get_product_subtotal( $mvweb_product, $mvweb_item['quantity'] ), $mvweb_item, $mvweb_key ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WooCommerce price markup. ?></p>
	<span class="product-remove">
		<?php
		echo apply_filters( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Every value is escaped below.
			'woocommerce_cart_item_remove_link',
			sprintf(
				'<a class="mvweb-t-cline__remove" role="button" href="%1$s" aria-label="%2$s" data-product_id="%3$s" data-product_sku="%4$s">%5$s</a>',
				esc_url( wc_get_cart_remove_url( $mvweb_key ) ),
				/* translators: %s: name of the good. */
				esc_attr( sprintf( __( 'Remove %s from the cart', 'brand-market' ), $mvweb_plain ) ),
				esc_attr( $mvweb_id ),
				esc_attr( $mvweb_product->get_sku() ),
				mvweb_theme_icon( 'trash' ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
			),
			$mvweb_key
		);
		?>
	</span>
</article>
