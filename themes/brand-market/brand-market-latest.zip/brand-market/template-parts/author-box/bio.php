<?php
/**
 * Author block, part: the description from the profile.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_bio = trim( (string) get_the_author_meta( 'description', isset( $args['author'] ) ? absint( $args['author'] ) : 0 ) );

if ( '' === $mvweb_bio ) {
	return;
}
?>
<p class="mvweb-t-author__bio"><?php echo esc_html( $mvweb_bio ); ?></p>
