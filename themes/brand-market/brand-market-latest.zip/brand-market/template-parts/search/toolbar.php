<?php
/**
 * Search results: the bar above the cards, as in the catalogue.
 *
 * The button that opens the filters of a phone, the sorting of the search
 * plugin and the look of the list. The sorting and the look follow the parts
 * shown in the bar of the catalogue; the address keeps the query and the
 * filters of the plugin.
 *
 * Arguments: filter (bool, whether the column of the area Search is printed),
 * smart (bool, whether the search plugin answers the query and sorts it).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_args  = array(
	'has_filters' => false,
	'state'       => new ArrayObject(
		array(
			'group'  => '',
			'toggle' => true,
			'cats'   => true,
		)
	),
);
$mvweb_sorts = ! empty( $args['smart'] ) && mvweb_core_layout_has( 'catalog-toolbar', 'sort' ) && is_callable( array( 'MVweb_SS_Search', 'sort_options' ) ) ? (array) MVweb_SS_Search::sort_options() : array();
$mvweb_sort  = is_callable( array( 'MVweb_SS_Search', 'requested_sort' ) ) ? (string) MVweb_SS_Search::requested_sort() : '';
$mvweb_keep  = array();

foreach ( wp_unslash( $_GET ) as $mvweb_key => $mvweb_value ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Read-only public search address; every value is sanitized below.
	$mvweb_key = sanitize_key( $mvweb_key );

	if ( 's' === $mvweb_key || ( 0 === strpos( $mvweb_key, 'mvweb_ss_' ) && 'mvweb_ss_sort' !== $mvweb_key ) ) {
		$mvweb_keep[ $mvweb_key ] = is_array( $mvweb_value ) ? array_map( 'sanitize_text_field', array_filter( $mvweb_value, 'is_scalar' ) ) : sanitize_text_field( (string) $mvweb_value );
	}
}

ob_start();
mvweb_core_listing_group( $mvweb_args, 'mvweb-t-toolbar__tools' );

if ( ! empty( $args['filter'] ) ) :
	?>
	<button class="mvweb-t-filters__toggle" type="button" data-search-filters aria-expanded="false" aria-controls="mvweb-t-search-aside">
		<?php echo mvweb_theme_icon( 'adjustments-horizontal', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<span><?php echo esc_html_x( 'Filter', 'button that opens the filters', 'brand-market' ); ?></span>
	</button>
	<?php
endif;

if ( count( $mvweb_sorts ) > 1 ) :
	?>
	<form class="mvweb-t-sort" action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get" data-sort>
		<?php foreach ( $mvweb_keep as $mvweb_key => $mvweb_value ) : ?>
			<?php foreach ( (array) $mvweb_value as $mvweb_item ) : ?>
				<input type="hidden" name="<?php echo esc_attr( $mvweb_key . ( is_array( $mvweb_value ) ? '[]' : '' ) ); ?>" value="<?php echo esc_attr( $mvweb_item ); ?>">
			<?php endforeach; ?>
		<?php endforeach; ?>

		<label class="mvweb-t-sort__label" for="mvweb-t-sort-order"><?php esc_html_e( 'Sort by', 'brand-market' ); ?></label>
		<select class="mvweb-t-sort__select" id="mvweb-t-sort-order" name="mvweb_ss_sort">
			<?php foreach ( $mvweb_sorts as $mvweb_key => $mvweb_label ) : ?>
				<option value="<?php echo esc_attr( (string) $mvweb_key ); ?>" <?php selected( $mvweb_sort, (string) $mvweb_key ); ?>><?php echo esc_html( $mvweb_label ); ?></option>
			<?php endforeach; ?>
		</select>

		<noscript><button class="mvweb-t-btn mvweb-t-btn--outline mvweb-t-btn--sm" type="submit"><?php esc_html_e( 'Apply', 'brand-market' ); ?></button></noscript>
	</form>
	<?php
endif;

if ( ! empty( $args['shop'] ) ) {
	get_template_part( 'template-parts/catalog-toolbar/view', null, $mvweb_args );
}

mvweb_core_listing_group( $mvweb_args, '' );

$mvweb_bar = trim( (string) ob_get_clean() );

if ( '<div class="mvweb-t-toolbar__tools"></div>' === preg_replace( '/>\s+</', '><', $mvweb_bar ) ) {
	return;
}
?>
<div class="mvweb-t-toolbar mvweb-t-search-page__toolbar">
	<?php echo $mvweb_bar; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed above, every value escaped there. ?>
</div>
