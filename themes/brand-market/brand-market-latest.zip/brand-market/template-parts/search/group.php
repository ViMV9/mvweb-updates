<?php
/**
 * Search results: one group under its heading.
 *
 * Cards are the very ones of the listings; entries with no card of their own
 * (pages) go into a plain list.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_slug  = isset( $args['slug'] ) ? (string) $args['slug'] : '';
$mvweb_group = isset( $args['group'] ) && is_array( $args['group'] ) ? $args['group'] : array();
$mvweb_full  = ! empty( $args['full'] );
$mvweb_grids = array(
	'products' => 'mvweb-t-catalog__grid mvweb-t-catalog__grid--wide',
	'services' => 'mvweb-t-catalog__grid mvweb-t-catalog__grid--services',
	'works'    => 'mvweb-t-catalog__grid',
	'posts'    => 'mvweb-t-posts__grid mvweb-t-posts__grid--listing',
	'pages'    => 'mvweb-t-search-list',
);
$mvweb_cards = array(
	'products' => 'template-parts/catalog/card',
	'services' => 'template-parts/service/card',
	'works'    => 'template-parts/work/card',
	'posts'    => 'template-parts/post-card',
);

if ( empty( $mvweb_group['query'] ) || ! isset( $mvweb_grids[ $mvweb_slug ] ) ) {
	return;
}

$mvweb_query = $mvweb_group['query'];
$mvweb_shop  = 'products' === $mvweb_slug;
$mvweb_cols  = (string) get_theme_mod( 'mvweb_catalog_columns', '3' );
?>
<section class="mvweb-t-search-group">
	<div class="mvweb-t-search-group__head">
		<div class="mvweb-t-search-group__title mvweb-t-h2" role="heading" aria-level="2"><?php echo esc_html( $mvweb_group['label'] ); ?></div>
		<?php if ( ! $mvweb_full && $mvweb_group['count'] > $mvweb_group['limit'] ) : ?>
			<a class="mvweb-t-btn mvweb-t-btn--ghost" href="<?php echo esc_url( $mvweb_group['url'] ); ?>">
				<?php
				/* translators: %s: number of results in the group. */
				echo esc_html( sprintf( __( 'Show all (%s)', 'brand-market' ), number_format_i18n( $mvweb_group['count'] ) ) );
				?>
			</a>
		<?php endif; ?>
	</div>

	<?php if ( $mvweb_shop ) : ?>
		<?php get_template_part( 'template-parts/catalog/thead' ); ?>
		<div class="mvweb-t-catalog__grid" data-catalog-grid data-view="<?php echo esc_attr( mvweb_core_catalog_view() ); ?>" data-cols="<?php echo esc_attr( in_array( $mvweb_cols, array( '4', '5' ), true ) ? $mvweb_cols : '3' ); ?>">
	<?php else : ?>
		<div class="<?php echo esc_attr( $mvweb_grids[ $mvweb_slug ] . ' mvweb-t-search-group__grid mvweb-t-search-group__grid--' . $mvweb_slug ); ?>">
	<?php endif; ?>
		<?php
		while ( $mvweb_query->have_posts() ) :
			$mvweb_query->the_post();

			if ( $mvweb_shop ) {
				get_template_part(
					'template-parts/catalog/card',
					null,
					array(
						'id'    => get_the_ID(),
						'eager' => $mvweb_query->current_post < 4,
						'qty'   => true,
					)
				);
				continue;
			}

			if ( isset( $mvweb_cards[ $mvweb_slug ] ) ) {
				get_template_part( $mvweb_cards[ $mvweb_slug ] );
				continue;
			}
			?>
			<article class="mvweb-t-search-list__item">
				<a class="mvweb-t-search-list__link" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
				<?php if ( '' !== get_the_excerpt() ) : ?>
					<p class="mvweb-t-search-list__text"><?php echo esc_html( get_the_excerpt() ); ?></p>
				<?php endif; ?>
			</article>
			<?php
		endwhile;

		wp_reset_postdata();
		?>
	</div>
</section>
