<?php
/**
 * The large first post of the blog page.
 *
 * The category, the date, the reading time and the cover stand as the site
 * sets them for the card of a post (the area card-post); the title is the link
 * of the card and is never dropped.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_print = static function ( $slug ) {
	ob_start();
	get_template_part( 'template-parts/card-post/' . $slug );

	return trim( (string) ob_get_clean() );
};
$mvweb_more  = trim( (string) mvweb_core_blog_option( 'mvweb_blog_feature_more' ) );
$mvweb_media = mvweb_core_layout_has( 'card-post', 'media' ) && has_post_thumbnail();
$mvweb_body  = '';
$mvweb_meta  = '';
$mvweb_title = '<div class="mvweb-t-post-feature__title mvweb-t-h2" role="heading" aria-level="2"><a href="' . esc_url( get_permalink() ) . '">' . esc_html( get_the_title() ) . '</a></div>';
$mvweb_flush = static function () use ( &$mvweb_body, &$mvweb_meta ) {
	if ( '' !== $mvweb_meta ) {
		$mvweb_body .= '<div class="mvweb-t-post-card__meta">' . $mvweb_meta . '</div>';
		$mvweb_meta  = '';
	}
};

foreach ( mvweb_core_layout_order( 'card-post' ) as $mvweb_slug ) {
	if ( in_array( $mvweb_slug, array( 'topic', 'date', 'read', 'author', 'comments', 'views' ), true ) ) {
		$mvweb_meta .= $mvweb_print( $mvweb_slug );
		continue;
	}

	$mvweb_flush();

	if ( 'title' === $mvweb_slug ) {
		$mvweb_body .= $mvweb_title;
		$mvweb_title = '';
	} elseif ( 'lead' === $mvweb_slug && '' !== trim( wp_strip_all_tags( get_the_excerpt() ) ) ) {
		$mvweb_body .= '<p class="mvweb-t-post-feature__lead">' . esc_html( trim( wp_strip_all_tags( get_the_excerpt() ) ) ) . '</p>';
	} elseif ( 'more' === $mvweb_slug && '' !== $mvweb_more ) {
		$mvweb_body .= '<span class="mvweb-t-post-card__more">' . esc_html( $mvweb_more ) . ' ' . mvweb_theme_icon( 'arrow-right' ) . '</span>';
	}
}

$mvweb_flush();
$mvweb_body .= $mvweb_title;
?>
<article class="mvweb-t-post-feature<?php echo $mvweb_media ? '' : ' mvweb-t-post-feature--plain'; ?>">
	<?php if ( $mvweb_media ) : ?>
		<div class="mvweb-t-post-feature__media"><?php the_post_thumbnail( 'large', array( 'fetchpriority' => 'high' ) ); ?></div>
	<?php endif; ?>
	<div class="mvweb-t-post-feature__body"><?php echo $mvweb_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Every piece is escaped where it is built or printed by a part template. ?></div>
</article>
