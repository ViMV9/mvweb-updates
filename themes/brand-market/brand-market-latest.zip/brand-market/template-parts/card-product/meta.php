<?php
/**
 * Product card part: the article and the stock.
 *
 * The grid hides the line; the table view of a listing shows it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id    = isset( $args['id'] ) ? absint( $args['id'] ) : 0;
$mvweb_sku   = $mvweb_id ? mvweb_core_item_sku( $mvweb_id ) : '';
$mvweb_stock = $mvweb_id ? mvweb_core_item_stock( $mvweb_id ) : array();
$mvweb_icons = array(
	'instock'     => 'check',
	'onbackorder' => 'clock',
	'outofstock'  => 'close',
);

if ( '' === $mvweb_sku && empty( $mvweb_stock['label'] ) ) {
	return;
}

mvweb_theme_card_group( $args, 'foot' );
?>
<span class="mvweb-t-card__meta">
	<?php if ( '' !== $mvweb_sku ) : ?>
		<span class="mvweb-t-card__sku">
			<?php
			/* translators: %s: article number of an item. */
			echo esc_html( sprintf( __( 'Art. %s', 'brand-market' ), $mvweb_sku ) );
			?>
		</span>
	<?php endif; ?>
	<?php if ( ! empty( $mvweb_stock['label'] ) ) : ?>
		<span class="mvweb-t-card__stock">
			<?php echo mvweb_theme_icon( isset( $mvweb_icons[ $mvweb_stock['status'] ] ) ? $mvweb_icons[ $mvweb_stock['status'] ] : 'check', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<?php
			if ( ! empty( $mvweb_stock['html'] ) ) {
				echo wp_kses_post( $mvweb_stock['html'] );
			} elseif ( null !== $mvweb_stock['qty'] ) {
				/* translators: %d: how many pieces are in stock. */
				echo esc_html( sprintf( __( '%d left', 'brand-market' ), $mvweb_stock['qty'] ) );
			} else {
				echo esc_html( $mvweb_stock['label'] );
			}
			?>
		</span>
	<?php endif; ?>
</span>
