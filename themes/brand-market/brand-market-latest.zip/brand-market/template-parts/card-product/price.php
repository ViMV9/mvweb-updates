<?php
/**
 * Product card part: the price, the old price and the wholesale column.
 *
 * The prices come from the core whichever store answers; a sale is told from
 * the markup WooCommerce gives, a wholesale price shows beside the retail one
 * when the layout keeps the part and the shop sells at wholesale. Where the
 * catalogue sells by request the price is a guide: «from» goes before it and
 * neither the old price nor the wholesale one is shown.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : 0;

if ( 0 === $mvweb_id ) {
	return;
}

$mvweb_value = mvweb_core_item_price_html( $mvweb_id );
$mvweb_old   = '';

if ( false !== strpos( $mvweb_value, '<ins' ) && preg_match( '~<del[^>]*>(.*?)</del>~s', $mvweb_value, $mvweb_del ) && preg_match( '~<ins[^>]*>(.*?)</ins>~s', $mvweb_value, $mvweb_ins ) ) {
	$mvweb_old   = $mvweb_del[1];
	$mvweb_value = $mvweb_ins[1];
}

$mvweb_asking  = ! mvweb_core_shop_mode();
$mvweb_request = '' === trim( wp_strip_all_tags( $mvweb_value ) );
$mvweb_empty   = $mvweb_request ? mvweb_core_price_placeholder() : '';

if ( $mvweb_request && '' === $mvweb_empty ) {
	return;
}

if ( $mvweb_asking ) {
	$mvweb_old = '';
}

$mvweb_label = $mvweb_asking ? '' : mvweb_core_price_label( $mvweb_id );
$mvweb_whole = '';
$mvweb_min   = 0;

if ( ! $mvweb_request && ! $mvweb_asking && mvweb_core_layout_has( 'card-product', 'opt' ) ) {
	$mvweb_whole = mvweb_core_item_wholesale_line( $mvweb_id );
	$mvweb_tiers = mvweb_core_tiers( $mvweb_id );
	$mvweb_min   = ! empty( $mvweb_tiers ) ? (int) array_key_first( $mvweb_tiers ) : (int) mvweb_core_quantity_rules( $mvweb_id )['min'];
}

$mvweb_unit   = mvweb_core_qty_unit( $mvweb_id );
$mvweb_second = mvweb_core_item_second_price_line( $mvweb_id );
$mvweb_stack  = is_string( $mvweb_second ) && '' !== trim( wp_strip_all_tags( $mvweb_second ) );

mvweb_theme_card_group( $args, 'foot' );
?>
<?php if ( $mvweb_stack ) : ?>
<div class="mvweb-t-card__prices">
<?php endif; ?>
<div class="<?php echo esc_attr( 'mvweb-t-price' . ( '' !== $mvweb_whole ? ' mvweb-t-price--pair' : '' ) . ( $mvweb_request ? ' mvweb-t-price--request' : '' ) ); ?>">
	<span class="mvweb-t-price__col">
		<?php if ( '' !== $mvweb_label && ! $mvweb_request ) : ?>
			<span class="mvweb-t-price__label"><?php echo esc_html( $mvweb_label ); ?></span>
		<?php endif; ?>
		<span class="mvweb-t-price__row">
			<?php if ( $mvweb_request ) : ?>
				<span class="mvweb-t-price__value"><?php echo esc_html( $mvweb_empty ); ?></span>
			<?php else : ?>
				<strong class="mvweb-t-price__value">
					<?php
					if ( $mvweb_asking ) {
						echo esc_html__( 'from', 'brand-market' ) . ' ';
					}

					echo wp_kses_post( $mvweb_value );
					?>
				</strong>
				<?php if ( '' !== $mvweb_old ) : ?>
					<span class="mvweb-t-price__old"><?php echo wp_kses_post( $mvweb_old ); ?></span>
				<?php endif; ?>
			<?php endif; ?>
		</span>
	</span>
	<?php if ( '' !== $mvweb_whole ) : ?>
		<span class="mvweb-t-price__col mvweb-t-price__col--opt">
			<span class="mvweb-t-price__head">
				<span class="mvweb-t-price__label"><?php echo esc_html( mvweb_core_wholesale_label() ); ?></span>
			</span>
			<strong class="mvweb-t-price__value"><?php echo wp_kses_post( $mvweb_whole ); ?></strong>
			<?php if ( $mvweb_min > 1 ) : ?>
				<span class="mvweb-t-price__min">
					<?php
					/* translators: 1: minimum quantity, 2: unit, for example pcs. */
					echo esc_html( sprintf( __( 'from %1$d %2$s', 'brand-market' ), $mvweb_min, '' !== $mvweb_unit ? $mvweb_unit : __( 'pcs', 'brand-market' ) ) );
					?>
				</span>
			<?php endif; ?>
		</span>
	<?php endif; ?>
</div>
<?php if ( is_string( $mvweb_second ) && '' !== trim( wp_strip_all_tags( $mvweb_second ) ) ) : ?>
	<div class="mvweb-t-price">
		<span class="mvweb-t-price__col">
			<?php if ( '' !== (string) mvweb_core_option( 'mvweb_second_price_label' ) ) : ?>
				<span class="mvweb-t-price__label"><?php echo esc_html( (string) mvweb_core_option( 'mvweb_second_price_label' ) ); ?></span>
			<?php endif; ?>
			<span class="mvweb-t-price__row"><strong class="mvweb-t-price__value"><?php echo wp_kses_post( $mvweb_second ); ?></strong></span>
		</span>
	</div>
<?php endif; ?>
<?php if ( $mvweb_stack ) : ?>
</div>
<?php endif; ?>
