<?php
/**
 * The page of one catalogue item.
 *
 * The same for a WooCommerce product and an item of the theme's own
 * catalogue. The photo, the header, the summary, the purchase box and the
 * sections under the item are areas of the composition set in the Customizer
 * (inc/theme/layouts/product-*.php); every part is a file of
 * template-parts/product-{area}/. The look of the price and purchase block
 * chosen in "MVweb: Product" stands on the summary as data-view; the look
 * "purchase column" prints the purchase box in a column of its own, the look
 * "purchase bar" adds the bar at the bottom of a phone screen. The back button
 * stands before the breadcrumbs and goes back in the history of the browser
 * when the visitor came from this site.
 *
 * Arguments: id.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_id = isset( $args['id'] ) ? absint( $args['id'] ) : get_the_ID();

if ( 0 === $mvweb_id ) {
	return;
}

$mvweb_args = array(
	'id'    => $mvweb_id,
	'state' => new ArrayObject(
		array(
			'meta' => 0,
			'n'    => 0,
		)
	),
);

$mvweb_view     = mvweb_core_product_view();
$mvweb_apart    = 'column' === $mvweb_view && mvweb_core_layout_has( 'product-summary', 'purchase' );
$mvweb_sections = mvweb_core_product_sections( $mvweb_id );
$mvweb_labels   = array(
	'description' => __( 'Description', 'brand-market' ),
	'specs'       => '' !== mvweb_core_product_section_title( 'specs' ) ? mvweb_core_product_section_title( 'specs' ) : __( 'Specifications', 'brand-market' ),
	'reviews'     => __( 'Reviews', 'brand-market' ),
	'upsells'     => '' !== mvweb_core_product_section_title( 'upsells' ) ? mvweb_core_product_section_title( 'upsells' ) : __( 'Goods bought together', 'brand-market' ),
	'related'     => '' !== mvweb_core_product_section_title( 'related' ) ? mvweb_core_product_section_title( 'related' ) : __( 'Similar items', 'brand-market' ),
	'viewed'      => __( 'You viewed', 'brand-market' ),
);

if ( mvweb_core_is_woocommerce() ) {
	do_action( 'woocommerce_before_single_product' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
}
?>

<section class="mvweb-t-product-detail">
	<div class="mvweb-t-container">

		<?php
		$mvweb_back = mvweb_core_back_url();

		if ( '' === $mvweb_back ) {
			get_template_part( 'template-parts/crumbs' );
		} else {
			?>
			<div class="mvweb-t-product-top">
				<a class="mvweb-t-back" href="<?php echo esc_url( $mvweb_back ); ?>" data-back>
					<?php echo mvweb_theme_icon( 'arrow-left', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<?php esc_html_e( 'Back', 'brand-market' ); ?>
				</a>
				<?php get_template_part( 'template-parts/crumbs' ); ?>
			</div>
			<?php
		}
		?>

		<div class="mvweb-t-product-detail__grid" data-photo="<?php echo esc_attr( mvweb_core_product_photo() ); ?>">

			<?php
			get_template_part( 'template-parts/product-gallery', null, array( 'id' => $mvweb_id ) );
			?>

			<div class="mvweb-t-product-summary"<?php echo '' !== $mvweb_view ? ' data-view="' . esc_attr( $mvweb_view ) . '"' : ''; ?>>
				<?php
				if ( mvweb_core_is_woocommerce() ) {
					echo mvweb_theme_hooked( 'woocommerce_before_single_product_summary' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Blocks that other plugins print on the hook of WooCommerce.
				}
				?>
				<div class="mvweb-t-product-header">
					<?php
					mvweb_core_render_layout( 'product-header', $mvweb_args );

					if ( $mvweb_args['state']['meta'] ) {
						echo '</div>';
					}

					if ( mvweb_core_is_woocommerce() ) {
						echo mvweb_theme_hooked( 'woocommerce_product_meta_start' ) . mvweb_theme_hooked( 'woocommerce_product_meta_end' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Blocks that other plugins print on the hooks of WooCommerce.
					}
					?>
				</div>

				<?php
				if ( $mvweb_apart ) {
					ob_start();
					mvweb_core_render_layout( 'product-summary', array_merge( $mvweb_args, array( 'purchase_apart' => true ) ) );
					$mvweb_facts = trim( (string) ob_get_clean() );

					ob_start();
					get_template_part( 'template-parts/product-summary/purchase', null, $mvweb_args );
					$mvweb_card = trim( (string) ob_get_clean() );

					if ( '' !== $mvweb_facts && '' !== $mvweb_card ) {
						echo '<div class="mvweb-t-product-split"><div class="mvweb-t-product-split__facts">' . $mvweb_facts . '</div>' . $mvweb_card . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed and escaped by the parts of the areas.
					} else {
						echo $mvweb_facts . $mvweb_card; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed and escaped by the parts of the areas.
					}
				} else {
					mvweb_core_render_layout( 'product-summary', $mvweb_args );
				}
				?>

				<?php
				if ( mvweb_core_is_woocommerce() ) {
					/**
					 * The summary slot.
					 *
					 * @since 0.1.0
					 */
					do_action( 'woocommerce_single_product_summary' );
					do_action( 'woocommerce_share' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
				}
				?>
			</div>
		</div>
	</div>
</section>

<?php
if ( 'panel' === $mvweb_view && mvweb_core_layout_has( 'product-summary', 'purchase' ) && mvweb_core_layout_has( 'product-purchase', 'buy' ) ) {
	get_template_part( 'template-parts/product-buybar', null, array( 'id' => $mvweb_id ) );
}
?>

<?php if ( count( $mvweb_sections ) > 1 && mvweb_core_product_option( 'mvweb_product_nav' ) ) : ?>
	<nav class="mvweb-t-product-nav" aria-label="<?php esc_attr_e( 'Page sections', 'brand-market' ); ?>">
		<div class="mvweb-t-container mvweb-t-product-nav__row">
			<?php foreach ( $mvweb_sections as $mvweb_slug ) : ?>
				<?php
				$mvweb_rating = 'reviews' === $mvweb_slug ? mvweb_core_item_rating( $mvweb_id ) : array();
				?>
				<a class="mvweb-t-product-nav__link" href="<?php echo esc_url( '#' . $mvweb_slug ); ?>"><?php echo esc_html( $mvweb_labels[ $mvweb_slug ] ); ?><?php echo ! empty( $mvweb_rating ) ? ' <span class="mvweb-t-badge">' . (int) $mvweb_rating['count'] . '</span>' : ''; ?></a>
			<?php endforeach; ?>
		</div>
	</nav>
<?php endif; ?>

<?php
mvweb_core_render_layout( 'product-sections', $mvweb_args );

get_template_part( 'template-parts/product-sections/plugin-tabs', null, $mvweb_args );

if ( mvweb_core_is_woocommerce() ) {
	do_action( 'woocommerce_after_single_product_summary' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
}

mvweb_core_render_context_sections();

if ( mvweb_core_is_woocommerce() ) {
	do_action( 'woocommerce_after_single_product' ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
}
