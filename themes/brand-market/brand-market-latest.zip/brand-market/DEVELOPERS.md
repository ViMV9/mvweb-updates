# Brand Market — руководство разработчика

Документ для того, кто ставит тему на сайт и дорабатывает её под проект. Правило одно: **файлы темы не редактируются** — обновление перезапишет их вместе с правкой. Всё своё живёт в дочерней теме или в плагине сайта.

## Из чего собрана тема

| Слой | Где | Что |
|---|---|---|
| Ядро MVweb | `core/` | Типы записей, мета, настройки, блоки конструктора, каталог, услуги, работы, SEO, поведение на фронте. Общее для всех тем студии |
| Движок настроек | `inc/customizer/kit/` | Поля Customizer, вывод CSS, условная видимость |
| Тема | остальное | Шаблоны, стили, токены, иконки — вид |

`core/` и `inc/customizer/kit/` приходят копией из общих исходников студии и руками не правятся.

## Сначала — настройки, потом код

Прежде чем писать дочернюю тему, стоит открыть **Внешний вид → Настроить**: каталог, услуги, Главная, шапка и подвал, цвета и схемы, «Поделиться», блок автора настраиваются там.

Базы адресов (`/catalog/`, `/services/` и категории) после запуска **не менять**: адреса сменятся у всего каталога разом.

## Дочерняя тема

```css
/*
Theme Name: Brand Market Child
Template: brand-market
Version: 1.0.0
*/
```

```php
add_action(
	'wp_enqueue_scripts',
	function () {
		wp_enqueue_style( 'brand-market-child', get_stylesheet_uri(), array(), wp_get_theme()->get( 'Version' ) );
	},
	20
);
```

Стили темы подключаются на приоритете 10 (по ключам запроса). Файл дочерней темы должен встать после них, поэтому приоритет 20.

При первой активации дочерней темы настройки родителя копируются в неё, если своих нет. Иконки берутся из набора выбранного стиля («MVweb: Оформление → Иконки»). Дочерняя тема добавляет и заменяет иконки своими спрайтами `assets/icons/*.svg`: символ `mvweb-t-icon-{имя}` с тем же именем перекрывает иконку набора во всех стилях.

## Переопределение шаблонов

Любой шаблон дочерняя тема перекрывает копией по тому же пути:

| Путь | Что печатает |
|---|---|
| `single-mv_item.php`, `archive-mv_item.php`, `taxonomy-mv_item_cat.php` | Каталог своего типа записей |
| `single-mv_service.php`, `archive-mv_service.php`, `taxonomy-mv_service_cat.php` | Услуги |
| `single-mv_work.php`, `archive-mv_work.php`, `taxonomy-mv_work_type.php` | Работы |
| `woocommerce/*.php` | Каталог, корзина, оформление, кабинет на WooCommerce |
| `template-parts/sections/{тип}.php` | Блоки конструктора, файл на тип. Блок без файла редактору не показывается |
| `template-parts/{область}/{часть}.php` | Части страниц, карточек и виджетов («Состав»): одна часть — один файл |
| `template-parts/elements/` | Элементы зон шапки и подвала; `places.php` — адреса города в строке шапки, `store.php` — «Мой центр», `quick.php` — быстрые кнопки из меню нижней панели |
| `template-parts/bottom-nav.php` | Нижняя панель телефона: меню места `bottom-nav` |
| `template-parts/header/places.php` | Полоса «Адреса города» под шапкой: виды `line`, `cards`, `tabs` |
| `template-parts/popup.php`, `side-cart.php`, `cookie.php`, `toc.php` | Окно заявки, боковая корзина, уведомление о cookie, оглавление |
| `template-parts/topics.php` | Ряд «Темы дня» под шапкой: меню места `topics` чипами |
| `page-templates/*.php` | Шаблоны страниц: конструктор, избранное, сравнение, карта сайта |
| `template-parts/sitemap/{вид}.php` | Виды карты сайта: `columns`, `tree`, `index`, `cards`, `toc` |
| `header.php`, `footer.php`, `single.php`, `page.php`, `search.php`, `404.php` | Каркас |

Файлы `inc/` и `core/` копией не перекрываются — их логика меняется хуками или переопределением функции: все функции темы и ядра объявлены внутри `if ( ! function_exists( … ) )`, а файл `functions.php` дочерней темы загружается раньше родительского.

## Хуки

Ядро (`core/`). Колонка «Тема» — хук, на который подписана сама тема.

| Хук | Что меняет | Тема |
|---|---|---|
| `mvweb_core_loaded` (action) | Ядро загружено, аргумент — версия | |
| `mvweb_core_register_sections` (action) | Место регистрации своего типа блока | |
| `mvweb_core_customizer_register` (action) | После полей ядра в Customizer, аргумент `$kit` | |
| `mvweb_core_section_editable` | Показывать ли блок редактору — для блоков, шаблон которых отдаёт плагин | |
| `mvweb_core_pre_render_section` | Перехват печати блока | |
| `mvweb_core_section_presets` | Готовые наборы блоков | |
| `mvweb_core_section_post_types` | Типы записей с конструктором | |
| `mvweb_core_sections_limit` | Потолок блоков на странице, по умолчанию 40 | |
| `mvweb_core_section_views` | Названия видов блока | да |
| `mvweb_core_section_parts` | Части блока и элемента списка | да |
| `mvweb_core_layouts`, `mvweb_core_layout_order`, `mvweb_core_render_part` | Области «Состава», показанные части, перехват печати части | да (`layouts`, `render_part`) |
| `mvweb_core_zones`, `mvweb_core_zone_elements`, `mvweb_core_zone_hints`, `mvweb_core_render_element` | Зоны шапки и подвала, подсказки под ними | да (`zones`, `zone_elements`, `zone_hints`) |
| `mvweb_core_zone_default_order` | Порядок элементов зоны по умолчанию | да |
| `mvweb_core_style_map`, `mvweb_core_module_map` | Стили и JS-модули запроса | да |
| `mvweb_core_header_views` | Виды шапки: ключ — строчный slug, значение — название | да |
| `mvweb_core_customizer_fields`, `mvweb_core_customizer_groups`, `mvweb_core_customizer_texts`, `mvweb_core_customizer_rules` | Порядок полей в разделах Customizer, группы, подписи, условия показа | |
| `mvweb_core_palettes` | Пресеты палитры | да |
| `mvweb_core_widget_classes` | Классы виджетов по ролям | да |
| `mvweb_core_item_content`, `mvweb_core_item_specs`, `mvweb_core_properties`, `mvweb_core_catalog_filters`, `mvweb_core_catalog_orderings` | Каталог | |
| `mvweb_core_subcats_views` | Виды подкатегорий над списком товаров; без видов поля выбора в Customizer нет | да |
| `mvweb_core_product_views` | Виды блока покупки на странице товара | да |
| `mvweb_core_blog_views`, `mvweb_core_masonry_views`, `mvweb_core_home_modes`, `mvweb_core_blog_subcats_views`, `mvweb_core_callouts_sets`, `mvweb_core_flag_kinds` | Виды списка записей, кладки, главной, подрубрик, наборы врезок, пометки записей | |
| `mvweb_core_sitemap_types`, `mvweb_core_sitemap_views` | Разделы карты сайта (название, иконка, описание) и её виды | |
| `mvweb_core_schema` | Узел JSON-LD позиции или услуги; пустой массив отменяет печать | |
| `mvweb_core_markup_allowed`, `mvweb_core_markup_graph`, `mvweb_core_markup_plugins` | Нужна ли странице микроразметка, узлы графа, плагины с разметкой | |
| `mvweb_core_share_networks` | Сети «Поделиться» | |
| `mvweb_core_crumb_items` | Хлебные крошки | |
| `mvweb_core_reading_speed` | Слов в минуту для времени чтения | |

Тема:

| Хук | Что меняет |
|---|---|
| `mvweb_theme_header_class` | Классы шапки |

## Вывод плагинов на страницах заказа

Вывод хуков `woocommerce_thankyou`, `woocommerce_view_order` и `woocommerce_account_dashboard` тема собирает в буфер и печатает в обёртке `.mvweb-t-hooked`, без `.mvweb-t-prose`. На страницах «Заказ принят», «Оплата не прошла» и «Заказ» в кабинете блок стоит в колонке заказа перед частью «Кнопки», на главной кабинета — после её частей. Если в выводе нет текста (только `<script>` или пустые теги), обёртки нет.

`woocommerce_thankyou` срабатывает до печати страницы: то, что плагин меняет в заказе на этом хуке, уже видно в колонке заказа. Выбор между «Заказ принят» и «Оплата не прошла» тема делает до хука, по статусу `failed`.

Классы `.button` и `.button-secondary` на всём сайте выглядят как кнопки темы (`.mvweb-t-btn` и `.mvweb-t-btn--outline`). Свой вид плагин задаёт своими классами.

## Переводы

Строки темы — в домене `brand-market` (`languages/ru_RU.po`), строки ядра — в `mvweb-core` (`core/languages/`).
