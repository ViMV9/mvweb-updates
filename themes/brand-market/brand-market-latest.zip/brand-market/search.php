<?php
/**
 * Search results, grouped by what was found.
 *
 * With no type chosen every group shows its first entries and a link to the
 * rest; a chosen type is the main query itself, paged. When the search plugin
 * answers the main query, its whole ranked list is shown page by page, split
 * into the same groups. The groups are the layout "search.groups", what is
 * printed for a query that found nothing is "search.empty". The column of the
 * area "Search" stands beside the results while it has widgets.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_needle = get_search_query( false );
$mvweb_sets   = array(
	'products' => array(
		'label' => mvweb_core_item_label(),
		'types' => array( mvweb_core_is_woocommerce() ? 'product' : 'mv_item' ),
		'limit' => in_array( (string) get_theme_mod( 'mvweb_catalog_columns', '3' ), array( '4', '5' ), true ) ? (int) get_theme_mod( 'mvweb_catalog_columns', '3' ) : 3,
	),
	'services' => array(
		'label' => mvweb_core_service_label(),
		'types' => array( 'mv_service' ),
		'limit' => 3,
	),
	'works'    => array(
		'label' => mvweb_core_work_label(),
		'types' => array( 'mv_work' ),
		'limit' => 3,
	),
	'posts'    => array(
		'label' => __( 'Articles', 'brand-market' ),
		'types' => array( 'post' ),
		'limit' => 3,
	),
	'pages'    => array(
		'label' => __( 'Pages', 'brand-market' ),
		'types' => array( 'page' ),
		'limit' => 3,
	),
);

$mvweb_asked = get_query_var( 'post_type' );
$mvweb_asked = is_string( $mvweb_asked ) ? sanitize_key( $mvweb_asked ) : '';
$mvweb_smart = (bool) $GLOBALS['wp_query']->get( 'mvweb_ss' );
$mvweb_only  = '';
$mvweb_total = 0;
$mvweb_group = array();

if ( '' !== $mvweb_needle && $mvweb_smart ) {
	$mvweb_total = (int) $GLOBALS['wp_query']->found_posts;
	$mvweb_found = array();

	foreach ( $GLOBALS['wp_query']->posts as $mvweb_post ) {
		$mvweb_found[ get_post_type( $mvweb_post ) ][] = (int) ( $mvweb_post instanceof WP_Post ? $mvweb_post->ID : $mvweb_post );
	}

	foreach ( mvweb_core_layout_order( 'search.groups' ) as $mvweb_slug ) {
		if ( ! isset( $mvweb_sets[ $mvweb_slug ] ) || empty( $mvweb_found[ $mvweb_sets[ $mvweb_slug ]['types'][0] ] ) ) {
			continue;
		}

		$mvweb_ids                  = $mvweb_found[ $mvweb_sets[ $mvweb_slug ]['types'][0] ];
		$mvweb_group[ $mvweb_slug ] = array(
			'label' => $mvweb_sets[ $mvweb_slug ]['label'],
			'type'  => $mvweb_sets[ $mvweb_slug ]['types'][0],
			'query' => new WP_Query(
				array(
					'post__in'            => $mvweb_ids,
					'orderby'             => 'post__in',
					'post_type'           => $mvweb_sets[ $mvweb_slug ]['types'],
					'posts_per_page'      => count( $mvweb_ids ),
					'no_found_rows'       => true,
					'ignore_sticky_posts' => true,
				)
			),
			'count' => count( $mvweb_ids ),
			'limit' => count( $mvweb_ids ),
			'url'   => '',
		);
	}
} elseif ( '' !== $mvweb_needle ) {
	foreach ( mvweb_core_layout_order( 'search.groups' ) as $mvweb_slug ) {
		if ( ! isset( $mvweb_sets[ $mvweb_slug ] ) || ! post_type_exists( $mvweb_sets[ $mvweb_slug ]['types'][0] ) ) {
			continue;
		}

		$mvweb_set = $mvweb_sets[ $mvweb_slug ];

		if ( $mvweb_asked === $mvweb_set['types'][0] ) {
			$mvweb_only = $mvweb_slug;
			$mvweb_hit  = $GLOBALS['wp_query'];
		} else {
			$mvweb_hit = new WP_Query(
				array(
					's'                   => $mvweb_needle,
					'post_type'           => $mvweb_set['types'],
					'post_status'         => 'publish',
					'posts_per_page'      => $mvweb_set['limit'],
					'ignore_sticky_posts' => true,
				)
			);
		}

		if ( 0 === (int) $mvweb_hit->found_posts ) {
			continue;
		}

		$mvweb_total               += (int) $mvweb_hit->found_posts;
		$mvweb_group[ $mvweb_slug ] = array(
			'label' => $mvweb_set['label'],
			'type'  => $mvweb_set['types'][0],
			'query' => $mvweb_hit,
			'count' => (int) $mvweb_hit->found_posts,
			'limit' => $mvweb_set['limit'],
			'url'   => add_query_arg(
				array(
					's'         => rawurlencode( $mvweb_needle ),
					'post_type' => $mvweb_set['types'][0],
				),
				home_url( '/' )
			),
		);
	}
}

get_header();

$mvweb_lead = '';

if ( '' !== $mvweb_needle ) {
	$mvweb_lead = $mvweb_total > 0
		? sprintf(
			/* translators: 1: search query, 2: number of results. */
			_n( 'For “%1$s” found %2$s result', 'For “%1$s” found %2$s results', $mvweb_total, 'brand-market' ),
			$mvweb_needle,
			number_format_i18n( $mvweb_total )
		)
		: sprintf(
			/* translators: %s: search query. */
			__( 'Nothing found for “%s”', 'brand-market' ),
			$mvweb_needle
		);
}

$mvweb_area   = 'search' === mvweb_core_sidebar_area() ? 'search' : '';
$mvweb_aside  = '' !== $mvweb_area ? mvweb_core_sidebar_html( $mvweb_area ) : '';
$mvweb_filter = '' !== $mvweb_aside && mvweb_theme_search_has_filters();

if ( '' !== $mvweb_aside ) {
	get_template_part( 'template-parts/crumbs', null, array( 'wrap' => true ) );
}

ob_start();
get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'title' => __( 'Search results', 'brand-market' ),
		'lead'  => $mvweb_lead,
	)
);
$mvweb_head = (string) ob_get_clean();

if ( '' === $mvweb_aside ) {
	echo $mvweb_head; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template.
}
?>

<section class="<?php echo '' === $mvweb_aside ? 'mvweb-t-section mvweb-t-section--flush-top mvweb-t-search-page' : 'mvweb-t-catalog mvweb-t-search-page mvweb-t-search-page--aside' . ( $mvweb_filter ? ' mvweb-t-search-page--filter' : '' ); ?>">
	<div class="mvweb-t-container<?php echo '' === $mvweb_aside ? '' : esc_attr( ' mvweb-t-catalog__layout' . mvweb_theme_sidebar_side_class( $mvweb_area, 'mvweb-t-catalog__layout' ) ); ?>">
		<?php if ( '' !== $mvweb_aside ) : ?>
		<div class="mvweb-t-catalog__main">
			<?php echo $mvweb_head; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Printed by the part template. ?>
		<?php endif; ?>

		<?php if ( $mvweb_total > 0 ) : ?>

			<div class="mvweb-t-search-page__top">
				<?php
				get_template_part(
					'template-parts/search/toolbar',
					null,
					array(
						'filter' => $mvweb_filter,
						'smart'  => $mvweb_smart,
						'shop'   => isset( $mvweb_group['products'] ),
					)
				);
				?>
			</div>

			<?php if ( ! $mvweb_smart && ( count( $mvweb_group ) > 1 || '' !== $mvweb_only ) ) : ?>
				<div class="mvweb-t-search-bar">
					<form class="mvweb-t-tabsel" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" data-tab-select>
						<input type="hidden" name="s" value="<?php echo esc_attr( $mvweb_needle ); ?>">
						<label class="mvweb-t-tabsel__label" for="mvweb-t-search-type"><?php esc_html_e( 'Show', 'brand-market' ); ?></label>
						<select class="mvweb-t-tabsel__select" id="mvweb-t-search-type" name="post_type" aria-label="<?php esc_attr_e( 'Show', 'brand-market' ); ?>">
							<option value=""<?php selected( '', $mvweb_only ); ?>>
								<?php
								/* translators: %s: number of results. */
								echo esc_html( sprintf( __( 'All · %s', 'brand-market' ), number_format_i18n( $mvweb_total ) ) );
								?>
							</option>
							<?php foreach ( $mvweb_group as $mvweb_slug => $mvweb_item ) : ?>
								<option value="<?php echo esc_attr( $mvweb_item['type'] ); ?>"<?php selected( $mvweb_slug, $mvweb_only ); ?>><?php echo esc_html( $mvweb_item['label'] . ' · ' . number_format_i18n( $mvweb_item['count'] ) ); ?></option>
							<?php endforeach; ?>
						</select>
						<button class="screen-reader-text" type="submit"><?php esc_html_e( 'Show', 'brand-market' ); ?></button>
					</form>
				</div>
			<?php endif; ?>

			<?php
			mvweb_core_render_layout(
				'search.groups',
				array(
					'groups' => $mvweb_group,
					'only'   => $mvweb_only,
				)
			);

			if ( $mvweb_smart || '' !== $mvweb_only ) {
				mvweb_theme_pagination();
			}
			?>

		<?php else : ?>

			<div class="mvweb-t-empty mvweb-t-search-none">
				<?php mvweb_core_render_layout( 'search.empty' ); ?>
			</div>

			<?php get_template_part( 'template-parts/search/hits' ); ?>

		<?php endif; ?>

		<?php if ( '' !== $mvweb_aside ) : ?>
		</div>
			<?php
			get_template_part(
				'template-parts/sidebar',
				null,
				array(
					'area'  => $mvweb_area,
					'class' => 'mvweb-t-catalog__aside',
					'id'    => 'mvweb-t-search-aside',
				)
			);
			?>
		<?php endif; ?>
	</div>
</section>

<?php
wp_reset_postdata();

get_footer();
