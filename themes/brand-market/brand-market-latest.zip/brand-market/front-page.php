<?php
/**
 * The front of the site.
 *
 * Assembled from the same section types the page builder offers, with the order
 * and the values living in theme_mods. The heading of the first first-screen
 * section that prints one is the h1 (see mvweb_core_h1_tag()); a long-text
 * block with the h1 switch on takes it first (mvweb_core_h1_reserve()); when
 * no heading does, a hidden h1 stands in, so the page is never left without one.
 *
 * With nothing arranged yet the homepage falls through to the blog index, so a
 * fresh install shows the latest entries instead of an empty page. A look of
 * the homepage other than the blocks prints the feed of posts instead
 * (template-parts/home-stream.php).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rows = mvweb_core_request_sections();

if ( mvweb_core_home_stream_on() ) {
	get_template_part( 'template-parts/home-stream', null, array( 'rows' => $mvweb_rows ) );

	return;
}

if ( empty( $mvweb_rows ) ) {
	if ( 'page' === get_option( 'show_on_front' ) ) {
		get_template_part( 'page' );
	} else {
		get_template_part( 'home' );
	}

	return;
}

get_header();

if ( is_page() ) {
	while ( have_posts() ) {
		the_post();
	}
}

mvweb_core_h1_reserve( $mvweb_rows );

ob_start();
mvweb_core_render_sections( $mvweb_rows );
$mvweb_body = (string) ob_get_clean();

if ( ! mvweb_core_h1_given() ) {
	$mvweb_h1 = is_page() ? get_the_title() : get_bloginfo( 'name' );
	?>
	<h1 class="mvweb-t-visually-hidden"><?php echo esc_html( wp_strip_all_tags( $mvweb_h1 ) ); ?></h1>
	<?php
}

echo $mvweb_body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup of the section templates, escaped there.

get_footer();
