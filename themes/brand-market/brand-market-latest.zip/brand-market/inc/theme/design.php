<?php
/**
 * Palette presets and the names of the looks the theme draws for the product page and the subcategories.
 *
 * 'tokens' are printed for both schemes, 'dark' only under the dark one.
 * Text on the accent is always `accent-ink`, a link is `accent-link`.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_palettes' ) ) {
	/**
	 * Register the theme palettes.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $palettes Presets so far.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_palettes( $palettes ) {
		$palettes['yellow']   = array(
			'label'  => __( 'Yellow', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#ffd60a',
				'--mvweb-t-accent-hover' => '#e8c200',
				'--mvweb-t-accent-ink'   => '#1b1c1f',
				'--mvweb-t-accent-link'  => '#6b5700',
			),
			'dark'   => array(
				'--mvweb-t-accent-hover' => '#ffe047',
				'--mvweb-t-accent-link'  => '#ffd60a',
			),
		);
		$palettes['peach']    = array(
			'label'  => __( 'Peach', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#ffb48a',
				'--mvweb-t-accent-hover' => '#f79e6c',
				'--mvweb-t-accent-ink'   => '#1b1c1f',
				'--mvweb-t-accent-link'  => '#9a4a1a',
			),
			'dark'   => array(
				'--mvweb-t-accent-hover' => '#ffc4a3',
				'--mvweb-t-accent-link'  => '#ffb48a',
			),
		);
		$palettes['navy']     = array(
			'label'  => __( 'Navy', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#1f3a5f',
				'--mvweb-t-accent-hover' => '#162c49',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#1f3a5f',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#8db2e6',
				'--mvweb-t-accent-hover' => '#a9c5ee',
				'--mvweb-t-accent-ink'   => '#10141a',
				'--mvweb-t-accent-link'  => '#8db2e6',
			),
		);
		$palettes['emerald']  = array(
			'label'  => __( 'Emerald', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#0d6b4e',
				'--mvweb-t-accent-hover' => '#0a5840',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#0d6b4e',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#4cc9a0',
				'--mvweb-t-accent-hover' => '#6bd8b5',
				'--mvweb-t-accent-ink'   => '#0a1a14',
				'--mvweb-t-accent-link'  => '#4cc9a0',
			),
		);
		$palettes['burgundy'] = array(
			'label'  => __( 'Burgundy', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#8c1d3f',
				'--mvweb-t-accent-hover' => '#741633',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#8c1d3f',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#ec8aa5',
				'--mvweb-t-accent-hover' => '#f2a3b8',
				'--mvweb-t-accent-ink'   => '#1a0a10',
				'--mvweb-t-accent-link'  => '#ec8aa5',
			),
		);

		return $palettes;
	}
}
add_filter( 'mvweb_core_palettes', 'mvweb_theme_palettes' );

if ( ! function_exists( 'mvweb_theme_product_views' ) ) {
	/**
	 * Give the core the looks of the price and purchase block on the product page.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_product_views() {
		return array(
			'compact' => __( 'Compact: price, buttons and the main specifications in a column', 'brand-market' ),
			'tiers'   => __( 'Price steps: the retail and the wholesale price as tiles, the total and the way to the wholesale price', 'brand-market' ),
			'column'  => __( 'Purchase column: a narrow purchase card next to the benefits and the specifications', 'brand-market' ),
			'icons'   => __( 'Specifications with icons: the main specifications as tiles', 'brand-market' ),
			'panel'   => __( 'Purchase bar: on a phone the price and “Add to cart” stay at the bottom of the screen', 'brand-market' ),
		);
	}
}
add_filter( 'mvweb_core_product_views', 'mvweb_theme_product_views' );

if ( ! function_exists( 'mvweb_theme_subcats_views' ) ) {
	/**
	 * Give the core the looks of the subcategories above a catalogue listing.
	 *
	 * @since 1.0.1
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_subcats_views() {
		return array(
			'tiles'   => __( 'Tiles with a picture: every section at once', 'brand-market' ),
			'more'    => __( 'Small pills: the first sections and a “More” button', 'brand-market' ),
			'rail'    => __( 'Ribbon: one row that scrolls sideways, with an arrow', 'brand-market' ),
			'columns' => __( 'Columns of links: the first sections and “All sections”', 'brand-market' ),
			'button'  => __( '“Sections” button: the list opens on a click', 'brand-market' ),
		);
	}
}
add_filter( 'mvweb_core_subcats_views', 'mvweb_theme_subcats_views' );
