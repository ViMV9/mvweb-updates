<?php
/**
 * Palette presets and the names of the looks the theme draws for the product page and the subcategories.
 *
 * 'tokens' are printed for both schemes, 'dark' only under the dark one.
 * Text on the accent is always `accent-ink`, a link is `accent-link`.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_palettes' ) ) {
	/**
	 * Register the theme palettes.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $palettes Presets so far.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_palettes( $palettes ) {
		$palettes['yellow']   = array(
			'label'  => __( 'Yellow', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#ffd60a',
				'--mvweb-t-accent-hover' => '#e8c200',
				'--mvweb-t-accent-ink'   => '#1b1c1f',
				'--mvweb-t-accent-link'  => '#6b5700',
			),
			'dark'   => array(
				'--mvweb-t-accent-hover' => '#ffe047',
				'--mvweb-t-accent-link'  => '#ffd60a',
			),
		);
		$palettes['peach']    = array(
			'label'  => __( 'Peach', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#ffb48a',
				'--mvweb-t-accent-hover' => '#f79e6c',
				'--mvweb-t-accent-ink'   => '#1b1c1f',
				'--mvweb-t-accent-link'  => '#9a4a1a',
			),
			'dark'   => array(
				'--mvweb-t-accent-hover' => '#ffc4a3',
				'--mvweb-t-accent-link'  => '#ffb48a',
			),
		);
		$palettes['navy']     = array(
			'label'  => __( 'Navy', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#1f3a5f',
				'--mvweb-t-accent-hover' => '#162c49',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#1f3a5f',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#8db2e6',
				'--mvweb-t-accent-hover' => '#a9c5ee',
				'--mvweb-t-accent-ink'   => '#10141a',
				'--mvweb-t-accent-link'  => '#8db2e6',
			),
		);
		$palettes['emerald']  = array(
			'label'  => __( 'Emerald', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#0d6b4e',
				'--mvweb-t-accent-hover' => '#0a5840',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#0d6b4e',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#4cc9a0',
				'--mvweb-t-accent-hover' => '#6bd8b5',
				'--mvweb-t-accent-ink'   => '#0a1a14',
				'--mvweb-t-accent-link'  => '#4cc9a0',
			),
		);
		$palettes['burgundy'] = array(
			'label'  => __( 'Burgundy', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#8c1d3f',
				'--mvweb-t-accent-hover' => '#741633',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#8c1d3f',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#ec8aa5',
				'--mvweb-t-accent-hover' => '#f2a3b8',
				'--mvweb-t-accent-ink'   => '#1a0a10',
				'--mvweb-t-accent-link'  => '#ec8aa5',
			),
		);

		$palettes['ultramarine'] = array(
			'label'  => __( 'Ultramarine', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#2f54eb',
				'--mvweb-t-accent-hover' => '#1f3fc4',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#2342c9',
				'--mvweb-t-surface'      => '#f3f5fc',
				'--mvweb-t-surface-2'    => '#e5e9f7',
				'--mvweb-t-inverse-bg'   => '#111a3a',
				'--mvweb-t-footer-bg'    => '#0e1630',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#8aa2ff',
				'--mvweb-t-accent-hover' => '#a6b8ff',
				'--mvweb-t-accent-ink'   => '#0b1030',
				'--mvweb-t-accent-link'  => '#8aa2ff',
				'--mvweb-t-bg'           => '#0f1220',
				'--mvweb-t-surface'      => '#171b2c',
				'--mvweb-t-surface-2'    => '#21263a',
				'--mvweb-t-mega-bg'      => '#171b2c',
				'--mvweb-t-field-bg'     => '#171b2c',
				'--mvweb-t-inverse-bg'   => '#0a0c16',
				'--mvweb-t-footer-bg'    => '#0a0c16',
			),
		);
		$palettes['sky']         = array(
			'label'  => __( 'Sky', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#38bdf8',
				'--mvweb-t-accent-hover' => '#0ea5e9',
				'--mvweb-t-accent-ink'   => '#0b1b2b',
				'--mvweb-t-accent-link'  => '#0369a1',
				'--mvweb-t-surface'      => '#f1f8fc',
				'--mvweb-t-surface-2'    => '#e0eff8',
				'--mvweb-t-inverse-bg'   => '#0b2a3d',
				'--mvweb-t-footer-bg'    => '#082133',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#7dd3fc',
				'--mvweb-t-accent-hover' => '#a5e1fd',
				'--mvweb-t-accent-ink'   => '#06202e',
				'--mvweb-t-accent-link'  => '#7dd3fc',
				'--mvweb-t-bg'           => '#0d151b',
				'--mvweb-t-surface'      => '#142029',
				'--mvweb-t-surface-2'    => '#1d2b36',
				'--mvweb-t-mega-bg'      => '#142029',
				'--mvweb-t-field-bg'     => '#142029',
				'--mvweb-t-inverse-bg'   => '#081016',
				'--mvweb-t-footer-bg'    => '#081016',
			),
		);
		$palettes['indigo']      = array(
			'label'  => __( 'Indigo', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#4338ca',
				'--mvweb-t-accent-hover' => '#3730a3',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#4338ca',
				'--mvweb-t-surface'      => '#f4f4fb',
				'--mvweb-t-surface-2'    => '#e7e6f6',
				'--mvweb-t-inverse-bg'   => '#1e1b4b',
				'--mvweb-t-footer-bg'    => '#18153d',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#a5b4fc',
				'--mvweb-t-accent-hover' => '#c0cbfd',
				'--mvweb-t-accent-ink'   => '#14123a',
				'--mvweb-t-accent-link'  => '#a5b4fc',
				'--mvweb-t-bg'           => '#11111f',
				'--mvweb-t-surface'      => '#19192d',
				'--mvweb-t-surface-2'    => '#23233b',
				'--mvweb-t-mega-bg'      => '#19192d',
				'--mvweb-t-field-bg'     => '#19192d',
				'--mvweb-t-inverse-bg'   => '#0b0b15',
				'--mvweb-t-footer-bg'    => '#0b0b15',
			),
		);
		$palettes['teal']        = array(
			'label'  => __( 'Teal', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#0f766e',
				'--mvweb-t-accent-hover' => '#0b5f58',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#0f766e',
				'--mvweb-t-surface'      => '#eff7f6',
				'--mvweb-t-surface-2'    => '#dfefec',
				'--mvweb-t-inverse-bg'   => '#0b2e2b',
				'--mvweb-t-footer-bg'    => '#082522',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#5eead4',
				'--mvweb-t-accent-hover' => '#8ff1e1',
				'--mvweb-t-accent-ink'   => '#062a25',
				'--mvweb-t-accent-link'  => '#5eead4',
				'--mvweb-t-bg'           => '#0c1615',
				'--mvweb-t-surface'      => '#13201f',
				'--mvweb-t-surface-2'    => '#1c2c2a',
				'--mvweb-t-mega-bg'      => '#13201f',
				'--mvweb-t-field-bg'     => '#13201f',
				'--mvweb-t-inverse-bg'   => '#070e0d',
				'--mvweb-t-footer-bg'    => '#070e0d',
			),
		);
		$palettes['mint']        = array(
			'label'  => __( 'Mint', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#34d399',
				'--mvweb-t-accent-hover' => '#10b981',
				'--mvweb-t-accent-ink'   => '#052e1f',
				'--mvweb-t-accent-link'  => '#047857',
				'--mvweb-t-surface'      => '#f0faf5',
				'--mvweb-t-surface-2'    => '#ddf2e8',
				'--mvweb-t-inverse-bg'   => '#06281d',
				'--mvweb-t-footer-bg'    => '#052018',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#6ee7b7',
				'--mvweb-t-accent-hover' => '#9cefcd',
				'--mvweb-t-accent-ink'   => '#052e1f',
				'--mvweb-t-accent-link'  => '#6ee7b7',
				'--mvweb-t-bg'           => '#0c1612',
				'--mvweb-t-surface'      => '#13201a',
				'--mvweb-t-surface-2'    => '#1b2c24',
				'--mvweb-t-mega-bg'      => '#13201a',
				'--mvweb-t-field-bg'     => '#13201a',
				'--mvweb-t-inverse-bg'   => '#070e0b',
				'--mvweb-t-footer-bg'    => '#070e0b',
			),
		);
		$palettes['forest']      = array(
			'label'  => __( 'Forest', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#2f6b3a',
				'--mvweb-t-accent-hover' => '#24552d',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#2f6b3a',
				'--mvweb-t-surface'      => '#f3f7f2',
				'--mvweb-t-surface-2'    => '#e4ece2',
				'--mvweb-t-inverse-bg'   => '#14261a',
				'--mvweb-t-footer-bg'    => '#101f15',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#86c994',
				'--mvweb-t-accent-hover' => '#a5d8ae',
				'--mvweb-t-accent-ink'   => '#0d2112',
				'--mvweb-t-accent-link'  => '#86c994',
				'--mvweb-t-bg'           => '#101511',
				'--mvweb-t-surface'      => '#171f19',
				'--mvweb-t-surface-2'    => '#212b23',
				'--mvweb-t-mega-bg'      => '#171f19',
				'--mvweb-t-field-bg'     => '#171f19',
				'--mvweb-t-inverse-bg'   => '#0a0d0a',
				'--mvweb-t-footer-bg'    => '#0a0d0a',
			),
		);
		$palettes['red']         = array(
			'label'  => __( 'Red', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#d92d20',
				'--mvweb-t-accent-hover' => '#b42318',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#b42318',
				'--mvweb-t-surface'      => '#fbf4f3',
				'--mvweb-t-surface-2'    => '#f4e5e3',
				'--mvweb-t-inverse-bg'   => '#2a0f0d',
				'--mvweb-t-footer-bg'    => '#220b09',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#ff8a80',
				'--mvweb-t-accent-hover' => '#ffa89f',
				'--mvweb-t-accent-ink'   => '#2a0805',
				'--mvweb-t-accent-link'  => '#ff8a80',
				'--mvweb-t-bg'           => '#170f0e',
				'--mvweb-t-surface'      => '#221615',
				'--mvweb-t-surface-2'    => '#2e1f1d',
				'--mvweb-t-mega-bg'      => '#221615',
				'--mvweb-t-field-bg'     => '#221615',
				'--mvweb-t-inverse-bg'   => '#0e0908',
				'--mvweb-t-footer-bg'    => '#0e0908',
			),
		);
		$palettes['coral']       = array(
			'label'  => __( 'Coral', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#ff7a66',
				'--mvweb-t-accent-hover' => '#f2604a',
				'--mvweb-t-accent-ink'   => '#1b1c1f',
				'--mvweb-t-accent-link'  => '#b3361f',
				'--mvweb-t-surface'      => '#fff6f4',
				'--mvweb-t-surface-2'    => '#fbe7e2',
				'--mvweb-t-inverse-bg'   => '#2b1411',
				'--mvweb-t-footer-bg'    => '#22100d',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#ff9c8c',
				'--mvweb-t-accent-hover' => '#ffb6aa',
				'--mvweb-t-accent-ink'   => '#2b0d08',
				'--mvweb-t-accent-link'  => '#ff9c8c',
				'--mvweb-t-bg'           => '#17100f',
				'--mvweb-t-surface'      => '#221816',
				'--mvweb-t-surface-2'    => '#2e211e',
				'--mvweb-t-mega-bg'      => '#221816',
				'--mvweb-t-field-bg'     => '#221816',
				'--mvweb-t-inverse-bg'   => '#0e0a09',
				'--mvweb-t-footer-bg'    => '#0e0a09',
			),
		);
		$palettes['violet']      = array(
			'label'  => __( 'Violet', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#7c3aed',
				'--mvweb-t-accent-hover' => '#6d28d9',
				'--mvweb-t-accent-ink'   => '#ffffff',
				'--mvweb-t-accent-link'  => '#6d28d9',
				'--mvweb-t-surface'      => '#f7f4fd',
				'--mvweb-t-surface-2'    => '#ebe4f9',
				'--mvweb-t-inverse-bg'   => '#1f1235',
				'--mvweb-t-footer-bg'    => '#190e2c',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#c4a5ff',
				'--mvweb-t-accent-hover' => '#d6c0ff',
				'--mvweb-t-accent-ink'   => '#1d0d3a',
				'--mvweb-t-accent-link'  => '#c4a5ff',
				'--mvweb-t-bg'           => '#13101c',
				'--mvweb-t-surface'      => '#1c1728',
				'--mvweb-t-surface-2'    => '#272036',
				'--mvweb-t-mega-bg'      => '#1c1728',
				'--mvweb-t-field-bg'     => '#1c1728',
				'--mvweb-t-inverse-bg'   => '#0c0a12',
				'--mvweb-t-footer-bg'    => '#0c0a12',
			),
		);
		$palettes['lavender']    = array(
			'label'  => __( 'Lavender', 'brand-market' ),
			'tokens' => array(
				'--mvweb-t-accent'       => '#b9a3ff',
				'--mvweb-t-accent-hover' => '#a68cf7',
				'--mvweb-t-accent-ink'   => '#1b1c1f',
				'--mvweb-t-accent-link'  => '#5b3fc4',
				'--mvweb-t-surface'      => '#f7f5fe',
				'--mvweb-t-surface-2'    => '#ebe7fb',
				'--mvweb-t-inverse-bg'   => '#231a3d',
				'--mvweb-t-footer-bg'    => '#1c1532',
			),
			'dark'   => array(
				'--mvweb-t-accent'       => '#c9b8ff',
				'--mvweb-t-accent-hover' => '#dacfff',
				'--mvweb-t-accent-ink'   => '#1d1440',
				'--mvweb-t-accent-link'  => '#c9b8ff',
				'--mvweb-t-bg'           => '#121019',
				'--mvweb-t-surface'      => '#1b1825',
				'--mvweb-t-surface-2'    => '#252133',
				'--mvweb-t-mega-bg'      => '#1b1825',
				'--mvweb-t-field-bg'     => '#1b1825',
				'--mvweb-t-inverse-bg'   => '#0b0a10',
				'--mvweb-t-footer-bg'    => '#0b0a10',
			),
		);

		return $palettes;
	}
}
add_filter( 'mvweb_core_palettes', 'mvweb_theme_palettes' );

if ( ! function_exists( 'mvweb_theme_product_views' ) ) {
	/**
	 * Give the core the looks of the price and purchase block on the product page.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_product_views() {
		return array(
			'compact' => __( 'Compact: price, buttons and the main specifications in a column', 'brand-market' ),
			'tiers'   => __( 'Price steps: the retail and the wholesale price as tiles, the total and the way to the wholesale price', 'brand-market' ),
			'column'  => __( 'Purchase column: a narrow purchase card next to the benefits and the specifications', 'brand-market' ),
			'icons'   => __( 'Specifications with icons: the main specifications as tiles', 'brand-market' ),
			'panel'   => __( 'Purchase bar: on a phone the price and “Add to cart” stay at the bottom of the screen', 'brand-market' ),
		);
	}
}
add_filter( 'mvweb_core_product_views', 'mvweb_theme_product_views' );

if ( ! function_exists( 'mvweb_theme_subcats_views' ) ) {
	/**
	 * Give the core the looks of the subcategories above a catalogue listing.
	 *
	 * @since 1.0.1
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_subcats_views() {
		return array(
			'tiles'   => __( 'Tiles with a picture: every section at once', 'brand-market' ),
			'more'    => __( 'Small pills: the first sections and a “More” button', 'brand-market' ),
			'rail'    => __( 'Ribbon: one row that scrolls sideways, with an arrow', 'brand-market' ),
			'columns' => __( 'Columns of links: the first sections and “All sections”', 'brand-market' ),
			'button'  => __( '“Sections” button: the list opens on a click', 'brand-market' ),
		);
	}
}
add_filter( 'mvweb_core_subcats_views', 'mvweb_theme_subcats_views' );

if ( ! function_exists( 'mvweb_theme_colour_tones' ) ) {
	/**
	 * Add the colours of the palette the theme draws to the ready colours of the colour fields.
	 *
	 * @since 1.1.1
	 *
	 * @param array<string,string> $tones Key => name.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_colour_tones( $tones ) {
		$out = array();

		foreach ( $tones as $key => $name ) {
			$out[ $key ] = $name;

			if ( 'surface' === $key ) {
				$out['grey'] = __( 'Grey', 'brand-market' );
			} elseif ( 'accent' === $key ) {
				$out['deep']  = __( 'Deep accent', 'brand-market' );
				$out['muted'] = __( 'Dark grey', 'brand-market' );
				$out['ink']   = __( 'Text colour', 'brand-market' );
			}
		}

		return $out;
	}
}
add_filter( 'mvweb_core_colour_tones', 'mvweb_theme_colour_tones' );
