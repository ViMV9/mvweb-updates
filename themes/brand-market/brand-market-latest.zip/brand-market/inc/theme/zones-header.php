<?php
/**
 * The header zones: their names, hints and elements, and the default order of each of the three views.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_header_default_order' ) ) {
	/**
	 * The elements of the header zones in the order of the chosen view; without WooCommerce the account is left for the owner to add.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $order Element slugs.
	 * @param string   $zone  Zone slug.
	 *
	 * @return string[]
	 */
	function mvweb_theme_header_default_order( $order, $zone ) {
		$common = array(
			'header-topbar'          => array( 'city', 'notice', 'menu-top', 'scheme' ),
			'header-drawer-contacts' => array( 'phone', 'address', 'schedule' ),
			'header-drawer-nav'      => array( 'menu-primary' ),
			'header-drawer-foot'     => array( 'socials', 'scheme' ),
		);

		$views = array(
			'simple'   => array(
				'header-main'    => array( 'logo', 'search-form', 'actions' ),
				'header-actions' => array( 'phone', 'schedule', 'favorites', 'account', 'cart' ),
				'header-nav'     => array( 'catalog-button', 'menu-primary' ),
			),
			'extended' => array(
				'header-main'    => array( 'logo', 'actions' ),
				'header-actions' => array( 'address', 'phone', 'schedule' ),
				'header-nav'     => array( 'catalog-button', 'menu-primary', 'search-form', 'favorites', 'account', 'cart' ),
			),
			'compact'  => array(
				'header-main'    => array( 'logo', 'actions' ),
				'header-actions' => array( 'address', 'phone', 'schedule' ),
				'header-nav'     => array( 'catalog-button', 'menu-primary', 'search', 'favorites', 'account', 'cart' ),
			),
			'points'   => array(
				'header-main'    => array( 'logo', 'places', 'actions' ),
				'header-actions' => array( 'phone', 'cta' ),
				'header-nav'     => array( 'catalog-button', 'menu-primary', 'search', 'favorites', 'account', 'cart' ),
			),
			'store'    => array(
				'header-main'    => array( 'logo', 'store', 'actions' ),
				'header-actions' => array( 'phone', 'cta' ),
				'header-nav'     => array( 'menu-primary' ),
			),
			'retail'   => array(
				'header-main'    => array( 'logo', 'catalog-button', 'search-form', 'actions' ),
				'header-actions' => array( 'phone', 'cta' ),
				'header-nav'     => array( 'menu-primary' ),
			),
			'tabs'     => array(
				'header-main'    => array( 'logo', 'search-form', 'store', 'actions' ),
				'header-actions' => array( 'quick', 'search', 'phone' ),
				'header-nav'     => array(),
			),
			'facts'    => array(
				'header-main'    => array( 'logo', 'actions' ),
				'header-actions' => array( 'phone', 'phone-2', 'address', 'schedule' ),
				'header-nav'     => array( 'catalog-button', 'menu-primary' ),
			),
			'portal'   => array(
				'header-main'    => array( 'logo', 'city', 'portal-menu', 'search-form', 'actions' ),
				'header-actions' => array( 'menu-top', 'search', 'account' ),
				'header-nav'     => array(),
			),
		);

		foreach ( array( 'row', 'row-color', 'centered', 'capsule' ) as $one_row ) {
			$views[ $one_row ] = array(
				'header-main'    => array( 'logo', 'actions' ),
				'header-actions' => array( 'phone', 'cta' ),
				'header-nav'     => array( 'menu-primary' ),
			);
		}

		$view = (string) get_theme_mod( 'mvweb_header_layout', 'simple' );

		if ( 'portal' === $view ) {
			$common['header-topbar'] = array( 'notice', 'scheme' );
		}

		if ( isset( $common[ $zone ] ) ) {
			return $common[ $zone ];
		}

		$view  = isset( $views[ $view ] ) ? $view : 'simple';
		$order = isset( $views[ $view ][ $zone ] ) ? $views[ $view ][ $zone ] : $order;

		return function_exists( 'wc_get_page_permalink' ) ? $order : array_values( array_diff( $order, array( 'account' ) ) );
	}
}
add_filter( 'mvweb_core_zone_default_order', 'mvweb_theme_header_default_order', 10, 2 );

if ( ! function_exists( 'mvweb_theme_header_views' ) ) {
	/**
	 * The looks of the header of the theme: three shared ones, the addresses in the header row and four looks in one row with the menu.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $views Key => name.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_header_views( $views ) {
		return $views + array(
			'points'    => __( 'Addresses of the city in the header row', 'brand-market' ),
			'row'       => __( 'One row: logo, menu, phone and button', 'brand-market' ),
			'row-color' => __( 'One row on the accent colour', 'brand-market' ),
			'centered'  => __( 'One row, logo in the centre', 'brand-market' ),
			'capsule'   => __( 'One row as a capsule on a dark band', 'brand-market' ),
			'store'     => __( 'My service centre: the chosen address in the header row', 'brand-market' ),
			'retail'    => __( 'Three strips with a wide search in the middle', 'brand-market' ),
			'tabs'      => __( 'One row with quick buttons, the bottom bar on a phone', 'brand-market' ),
			'facts'     => __( 'Contacts in circles: phone, address and hours', 'brand-market' ),
			'portal'    => __( 'Portal: the menu as icons and the search on a coloured band', 'brand-market' ),
		);
	}
}
add_filter( 'mvweb_core_header_views', 'mvweb_theme_header_views' );

if ( ! function_exists( 'mvweb_theme_header_facts' ) ) {
	/**
	 * Whether the contacts of a header zone stand as icons in circles with a caption: the view "Contacts in circles", the other items of the header row.
	 *
	 * @since 0.1.0
	 *
	 * @param string $zone Zone slug.
	 *
	 * @return bool
	 */
	function mvweb_theme_header_facts( $zone ) {
		return 'header-actions' === $zone && 'facts' === mvweb_core_header_view();
	}
}

if ( ! function_exists( 'mvweb_theme_header_facts_fields' ) ) {
	/**
	 * The captions of the contacts in the view "Contacts in circles".
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $fields Fields of the Customizer.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_theme_header_facts_fields( $fields ) {
		$only = array(
			array(
				'setting'  => 'mvweb_header_layout',
				'operator' => '==',
				'value'    => 'facts',
			),
		);

		$fields[] = array(
			'type'        => 'text',
			'settings'    => 'mvweb_header_facts_phone',
			'section'     => 'mvweb_cz_header_blocks',
			'label'       => __( 'Caption under the phone', 'brand-market' ),
			'description' => __( 'For example “Call us”. A number with its own caption in the contacts shows that caption. Empty: no caption.', 'brand-market' ),
			'default'     => __( 'Call us', 'brand-market' ),
			'required'    => $only,
		);

		$fields[] = array(
			'type'        => 'text',
			'settings'    => 'mvweb_header_facts_address',
			'section'     => 'mvweb_cz_header_blocks',
			'label'       => __( 'Caption under the address', 'brand-market' ),
			'description' => __( 'For example “Entrance from the yard”. Empty: the city.', 'brand-market' ),
			'default'     => '',
			'required'    => $only,
		);

		$fields[] = array(
			'type'        => 'textarea',
			'settings'    => 'mvweb_cz_address_how',
			'section'     => 'mvweb_cz_profile_contacts',
			'label'       => __( 'How to find us', 'brand-market' ),
			'description' => __( 'For example “We are on the ground floor of the mall, the entrance is at the end of the building”. In the header “Contacts in circles” the button “More details” under the address opens it. Empty: no button.', 'brand-market' ),
			'default'     => '',
		);

		$fields[] = array(
			'type'        => 'text',
			'settings'    => 'mvweb_header_facts_hours',
			'section'     => 'mvweb_cz_header_blocks',
			'label'       => __( 'Caption under the opening hours', 'brand-market' ),
			'description' => __( 'Empty: the other rows of the hours, for example the days off.', 'brand-market' ),
			'default'     => '',
			'required'    => $only,
		);

		return $fields;
	}
}
add_filter( 'mvweb_cz_baseline_fields', 'mvweb_theme_header_facts_fields' );

if ( ! function_exists( 'mvweb_theme_header_facts_order' ) ) {
	/**
	 * Put the captions of the contacts right after the header view.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string[]> $fields Section id => control ids.
	 *
	 * @return array<string,string[]>
	 */
	function mvweb_theme_header_facts_order( $fields ) {
		$header = isset( $fields['mvweb_cz_header_blocks'] ) ? $fields['mvweb_cz_header_blocks'] : array();
		$header = array_values( array_diff( $header, array( 'mvweb_header_facts_phone', 'mvweb_header_facts_address', 'mvweb_header_facts_hours' ) ) );
		$at     = array_search( 'mvweb_header_layout', $header, true );

		array_splice( $header, false === $at ? 0 : $at + 1, 0, array( 'mvweb_header_facts_phone', 'mvweb_header_facts_address', 'mvweb_header_facts_hours' ) );
		$fields['mvweb_cz_header_blocks'] = $header;

		$contacts = isset( $fields['mvweb_cz_profile_contacts'] ) ? array_values( array_diff( $fields['mvweb_cz_profile_contacts'], array( 'mvweb_cz_address_how' ) ) ) : array();
		$at       = array_search( 'mvweb_cz_address', $contacts, true );

		array_splice( $contacts, false === $at ? count( $contacts ) : $at + 1, 0, array( 'mvweb_cz_address_how' ) );
		$fields['mvweb_cz_profile_contacts'] = $contacts;

		return $fields;
	}
}
add_filter( 'mvweb_core_customizer_fields', 'mvweb_theme_header_facts_order' );

if ( ! function_exists( 'mvweb_theme_header_zone_texts' ) ) {
	/**
	 * The name and the hint of every header zone, in words of the owner.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,string>> Zone slug => name and hint.
	 */
	function mvweb_theme_header_zone_texts() {
		return array(
			'header-topbar'          => array(
				'label' => __( 'Strip above the header', 'brand-market' ),
				'hint'  => __( 'The thin coloured strip at the very top of the page: announcement, city, extra menu, colour scheme switch. The tick hides the switch here only; to remove it from the whole site choose one scheme in “Design → Colours → Colour scheme”.', 'brand-market' ),
			),
			'header-main'            => array(
				'label' => __( 'Header row', 'brand-market' ),
				'hint'  => __( 'The white row with the logo. The logo always stands first; arrange the other parts: search and “Other items” (the icons and contacts on the right). How the logo looks is set in the section “Logo”.', 'brand-market' ),
			),
			'header-actions'         => array(
				'label' => __( 'Header row: other items', 'brand-market' ),
				'hint'  => __( 'What stands in the “Other items” part: icons, cart, phone, opening hours.', 'brand-market' ),
			),
			'header-nav'             => array(
				'label' => __( 'Main menu', 'brand-market' ),
				'hint'  => __( 'The strip under the header: the “Catalogue” button, the main menu, search and icons. “Search (line)” is a field, “Search (icon)” is a magnifier.', 'brand-market' ),
			),
			'header-drawer-contacts' => array(
				'label' => __( 'Mobile menu: contacts', 'brand-market' ),
				'hint'  => __( 'Phone, address, opening hours, messengers in the menu that opens on a phone. Above or below the menu items: see “Where the contacts stand”.', 'brand-market' ),
			),
			'header-drawer-nav'      => array(
				'label' => __( 'Mobile menu: sections', 'brand-market' ),
				'hint'  => __( 'The menus of the site in the mobile menu.', 'brand-market' ),
			),
			'header-drawer-foot'     => array(
				'label' => __( 'Mobile menu: bottom', 'brand-market' ),
				'hint'  => __( 'The bottom of the mobile menu: social networks and the colour scheme switch. The tick hides the switch here only; to remove it from the whole site choose one scheme in “Design → Colours → Colour scheme”.', 'brand-market' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_header_zone_labels' ) ) {
	/**
	 * The names of the header zones.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $zones Zone slug => label.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_header_zone_labels( $zones ) {
		foreach ( mvweb_theme_header_zone_texts() as $zone => $texts ) {
			if ( isset( $zones[ $zone ] ) ) {
				$zones[ $zone ] = $texts['label'];
			}
		}

		return $zones;
	}
}
add_filter( 'mvweb_core_zones', 'mvweb_theme_header_zone_labels', 20 );

if ( ! function_exists( 'mvweb_theme_header_zone_hints' ) ) {
	/**
	 * The hints under the header zones in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $hints Zone slug => hint.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_header_zone_hints( $hints ) {
		foreach ( mvweb_theme_header_zone_texts() as $zone => $texts ) {
			$hints[ $zone ] = $texts['hint'];
		}

		return $hints;
	}
}
add_filter( 'mvweb_core_zone_hints', 'mvweb_theme_header_zone_hints' );

if ( ! function_exists( 'mvweb_theme_header_zone_elements' ) ) {
	/**
	 * The elements of the header zones: three parts of the header row, the other items one by one, and plain names.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $elements Element slug => label.
	 * @param string               $zone     Zone slug.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_header_zone_elements( $elements, $zone ) {
		if ( 'header-main' === $zone ) {
			return array(
				'logo'           => __( 'Logo', 'brand-market' ),
				'catalog-button' => __( 'Catalogue button', 'brand-market' ),
				'search-form'    => __( 'Search', 'brand-market' ),
				'places'         => __( 'Addresses of the city', 'brand-market' ),
				'store'          => __( 'My service centre', 'brand-market' ),
				'city'           => __( 'City choice', 'brand-market' ),
				'portal-menu'    => __( 'Button of the menu with icons (header “Portal”)', 'brand-market' ),
				'actions'        => __( 'Other items', 'brand-market' ),
				'account'        => __( 'Account', 'brand-market' ),
				'cart'           => __( 'Cart', 'brand-market' ),
			);
		}

		if ( 'header-actions' === $zone ) {
			$elements += array(
				'phone-2'  => __( 'Phone 2', 'brand-market' ),
				'address'  => '',
				'quick'    => __( 'Quick buttons (the menu of the bottom bar)', 'brand-market' ),
				'menu-top' => '',
			);
		}

		unset( $elements['burger'], $elements['menu-button'], $elements['subscribe'] );

		$labels = array(
			'phone'       => __( 'Phone', 'brand-market' ),
			'address'     => __( 'Address', 'brand-market' ),
			'schedule'    => __( 'Opening hours', 'brand-market' ),
			'scheme'      => __( 'Light and dark scheme switch', 'brand-market' ),
			'menu-top'    => __( 'Top menu', 'brand-market' ),
			'cta'         => __( 'Request button', 'brand-market' ),
			'search'      => __( 'Search (icon)', 'brand-market' ),
			'search-form' => __( 'Search (line)', 'brand-market' ),
			'notice'      => __( 'Announcement (line of text)', 'brand-market' ),
		);

		return array_merge( $elements, array_intersect_key( $labels, $elements ) );
	}
}
add_filter( 'mvweb_core_zone_elements', 'mvweb_theme_header_zone_elements', 20, 2 );

if ( ! function_exists( 'mvweb_theme_header_row_compat' ) ) {
	/**
	 * A header row saved before it had the "Other items" part.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Saved order, a JSON list of element slugs.
	 *
	 * @return mixed
	 */
	function mvweb_theme_header_row_compat( $value ) {
		$mods = get_theme_mods();
		$main = isset( $mods['mvweb_zone_header_main'] ) ? json_decode( (string) $mods['mvweb_zone_header_main'], true ) : null;

		if ( ! empty( $mods['mvweb_header_row'] ) || ! is_array( $main ) || in_array( 'actions', $main, true ) ) {
			return $value;
		}

		$gone = array( 'contacts-block', 'phone', 'address', 'schedule', 'menu-primary' );

		if ( 'theme_mod_mvweb_zone_header_main' === current_filter() ) {
			$row = array();

			foreach ( $main as $slug ) {
				if ( ! in_array( $slug, $gone, true ) ) {
					$row[] = $slug;
				} elseif ( ! in_array( 'actions', $row, true ) ) {
					$row[] = 'actions';
				}
			}

			return wp_json_encode( in_array( 'actions', $row, true ) ? $row : array_merge( $row, array( 'actions' ) ) );
		}

		$items = json_decode( (string) $value, true );
		$moved = array_intersect( $main, array_slice( $gone, 0, 4 ) );

		if ( ! is_array( $items ) ) {
			$items = array_diff( mvweb_core_zone_default_order( 'header-actions' ), $moved ? array_slice( $gone, 0, 4 ) : array() );
		}

		$moved = array_diff( $moved, $items );

		return wp_json_encode( array_values( array_merge( $moved, $items ) ) );
	}
}
add_filter( 'theme_mod_mvweb_zone_header_main', 'mvweb_theme_header_row_compat' );
add_filter( 'theme_mod_mvweb_zone_header_actions', 'mvweb_theme_header_row_compat' );

if ( ! function_exists( 'mvweb_theme_header_contacts_split' ) ) {
	/**
	 * The block "Phones, addresses and hours" is gone: a saved order with it gets the address, the phone and the opening hours in its place.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Saved order, a JSON list of element slugs.
	 *
	 * @return mixed
	 */
	function mvweb_theme_header_contacts_split( $value ) {
		$items = is_string( $value ) ? json_decode( $value, true ) : null;

		if ( ! is_array( $items ) || ! in_array( 'contacts-block', $items, true ) ) {
			return $value;
		}

		$row = array();

		foreach ( array_filter( $items, 'is_string' ) as $slug ) {
			$row = array_merge( $row, 'contacts-block' === $slug ? array( 'address', 'phone', 'schedule' ) : array( $slug ) );
		}

		return wp_json_encode( array_values( array_unique( $row ) ) );
	}
}
add_filter( 'theme_mod_mvweb_zone_header_actions', 'mvweb_theme_header_contacts_split', 20 );

if ( ! function_exists( 'mvweb_theme_header_row_save' ) ) {
	/**
	 * When the Customizer opens, the header row read the new way is saved, so the owner can hide "Other items" and every element without the old order coming back.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_header_row_save() {
		if ( get_theme_mod( 'mvweb_header_row' ) ) {
			return;
		}

		$values = array(
			'mvweb_zone_header_main'    => get_theme_mod( 'mvweb_zone_header_main', '' ),
			'mvweb_zone_header_actions' => get_theme_mod( 'mvweb_zone_header_actions', '' ),
		);

		foreach ( array_filter( $values ) as $name => $value ) {
			set_theme_mod( $name, $value );
		}

		set_theme_mod( 'mvweb_header_row', 1 );
	}
}
add_action( 'customize_register', 'mvweb_theme_header_row_save', 1 );

if ( ! function_exists( 'mvweb_theme_print_phone_icon' ) ) {
	/**
	 * Print the colour of the phone icon for both schemes.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_print_phone_icon() {
		$color = mvweb_cz_sanitize_color( (string) get_theme_mod( 'mvweb_header_phone_icon_color', '' ) );

		if ( '' === $color || 'plate' !== get_theme_mod( 'mvweb_header_phone_icon', 'none' ) ) {
			return;
		}

		$dark = 0 === strpos( $color, '#' ) ? mvweb_core_readable_on( $color, mvweb_core_scheme_backgrounds()['dark'] ) : $color;

		printf( "<style id='mvweb-t-phone-icon'>:root{--mvweb-t-hc-icon:%s}[data-scheme=\"dark\"]{--mvweb-t-hc-icon:%s}</style>\n", esc_html( $color ), esc_html( $dark ) );
	}
}
add_action( 'wp_head', 'mvweb_theme_print_phone_icon', 22 );

if ( ! function_exists( 'mvweb_theme_notice_icon_field' ) ) {
	/**
	 * The icon before the text of the announcement over the header.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $fields Fields of the Customizer.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_theme_notice_icon_field( $fields ) {
		$fields[] = array(
			'type'     => 'select',
			'settings' => 'mvweb_notice_icon',
			'section'  => 'mvweb_cz_header_notice',
			'label'    => __( 'Icon before the announcement', 'brand-market' ),
			'default'  => 'truck-delivery',
			'choices'  => array( '' => __( 'No icon', 'brand-market' ) ) + mvweb_core_icon_choices(),
		);

		return $fields;
	}
}
add_filter( 'mvweb_cz_baseline_fields', 'mvweb_theme_notice_icon_field' );

if ( ! function_exists( 'mvweb_theme_notice_icon_order' ) ) {
	/**
	 * Put the icon of the announcement right after its text.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string[]> $fields Section id => control ids.
	 *
	 * @return array<string,string[]>
	 */
	function mvweb_theme_notice_icon_order( $fields ) {
		$notice = isset( $fields['mvweb_cz_header_notice'] ) ? $fields['mvweb_cz_header_notice'] : array();
		$at     = array_search( 'mvweb_notice_text', $notice, true );

		array_splice( $notice, false === $at ? 0 : $at + 1, 0, array( 'mvweb_notice_icon' ) );
		$fields['mvweb_cz_header_notice'] = $notice;

		return $fields;
	}
}
add_filter( 'mvweb_core_customizer_fields', 'mvweb_theme_notice_icon_order' );

if ( ! function_exists( 'mvweb_theme_cta_fields' ) ) {
	/**
	 * The look of the action button of the header: icon, fill and its place on a phone.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $fields Fields of the Customizer.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_theme_cta_fields( $fields ) {
		$fields[] = array(
			'type'     => 'select',
			'settings' => 'mvweb_cta_icon',
			'section'  => 'mvweb_cz_conversion_cta',
			'label'    => __( 'Icon on the button', 'brand-market' ),
			'default'  => '',
			'choices'  => array( '' => __( 'No icon', 'brand-market' ) ) + mvweb_core_icon_choices(),
		);
		$fields[] = array(
			'type'     => 'select',
			'settings' => 'mvweb_cta_look',
			'section'  => 'mvweb_cz_conversion_cta',
			'label'    => __( 'Look of the button', 'brand-market' ),
			'default'  => 'fill',
			'choices'  => array(
				'fill'    => __( 'Filled with the brand colour', 'brand-market' ),
				'outline' => __( 'Outline', 'brand-market' ),
			),
		);
		$fields[] = array(
			'type'        => 'select',
			'settings'    => 'mvweb_cta_phone',
			'section'     => 'mvweb_cz_conversion_cta',
			'label'       => __( 'On a phone', 'brand-market' ),
			'description' => __( 'In the header of a phone the button shows only its icon, a phone when no icon is chosen. In the menu of a phone the button stands when «Request button» is in «Mobile menu: contacts».', 'brand-market' ),
			'default'     => 'menu',
			'choices'     => array(
				'menu' => __( 'Only in the menu', 'brand-market' ),
				'bar'  => __( 'In the header, as an icon', 'brand-market' ),
			),
		);

		return $fields;
	}
}
add_filter( 'mvweb_cz_baseline_fields', 'mvweb_theme_cta_fields' );

if ( ! function_exists( 'mvweb_theme_cta_order' ) ) {
	/**
	 * Put the look of the action button right after its link.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string[]> $fields Section id => control ids.
	 *
	 * @return array<string,string[]>
	 */
	function mvweb_theme_cta_order( $fields ) {
		$cta = isset( $fields['mvweb_cz_conversion_cta'] ) ? $fields['mvweb_cz_conversion_cta'] : array();
		$at  = array_search( 'mvweb_cta_url', $cta, true );

		array_splice( $cta, false === $at ? 0 : $at + 1, 0, array( 'mvweb_cta_icon', 'mvweb_cta_look', 'mvweb_cta_phone' ) );
		$fields['mvweb_cz_conversion_cta'] = $cta;

		return $fields;
	}
}
add_filter( 'mvweb_core_customizer_fields', 'mvweb_theme_cta_order' );
