<?php
/**
 * Search field of the header and the search panel under it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_search_field' ) ) {
	/**
	 * The search field of the chosen engine.
	 *
	 * @since 0.1.0
	 *
	 * @param string $variant Where the field stands: '' for the main row, 'nav' for the menu row, 'pop' for the panel.
	 *
	 * @return string Escaped markup.
	 */
	function mvweb_theme_search_field( $variant = '' ) {
		if ( 'smart' === mvweb_core_search_engine() ) {
			return '<div class="mvweb-t-el-search-form mvweb-t-el-search-form--smart">' . preg_replace( '/\s?mvweb-ss--(?:icon|word)-(?:desktop|mobile)/', '', mvweb_ss_get_search_bar() ) . '</div>';
		}

		$id          = wp_unique_id( 'mvweb-t-search-' );
		$placeholder = trim( (string) get_theme_mod( 'mvweb_search_placeholder', '' ) );
		$class       = 'mvweb-t-el-search-form' . ( '' === $variant ? '' : ' mvweb-t-el-search-form--' . sanitize_html_class( $variant ) );

		ob_start();
		?>
		<form class="<?php echo esc_attr( $class ); ?>" role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<label class="screen-reader-text" for="<?php echo esc_attr( $id ); ?>"><?php esc_html_e( 'Search the site', 'brand-market' ); ?></label>
			<input class="mvweb-t-el-search-form__input" id="<?php echo esc_attr( $id ); ?>" type="search" name="s" value="<?php echo esc_attr( get_search_query( false ) ); ?>"<?php echo '' === $placeholder ? '' : ' placeholder="' . esc_attr( $placeholder ) . '"'; ?> autocomplete="off">
			<button class="mvweb-t-round mvweb-t-round--accent mvweb-t-el-search-form__submit" type="submit" title="<?php esc_attr_e( 'Search', 'brand-market' ); ?>">
				<?php echo mvweb_theme_icon( 'search', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
				<span class="screen-reader-text"><?php esc_html_e( 'Search', 'brand-market' ); ?></span>
			</button>
		</form>
		<?php
		return trim( (string) ob_get_clean() );
	}
}

if ( ! function_exists( 'mvweb_theme_search_per_page' ) ) {
	/**
	 * A page of the results of the search plugin holds as many entries as a page of the catalogue; a number set in the plugin wins.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Query being prepared.
	 *
	 * @return void
	 */
	function mvweb_theme_search_per_page( $query ) {
		if ( is_admin() || ! $query->is_main_query() || ! $query->is_search() || 'smart' !== mvweb_core_search_engine() ) {
			return;
		}

		$per_page = absint( mvweb_core_option( 'mvweb_items_per_page' ) );

		if ( $per_page > 0 ) {
			$query->set( 'posts_per_page', $per_page );
		}
	}
}
add_action( 'pre_get_posts', 'mvweb_theme_search_per_page', 10 );

if ( ! function_exists( 'mvweb_theme_search_types' ) ) {
	/**
	 * The post types of the groups the search page shows, in the layout "search.groups".
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_theme_search_types() {
		$types = array(
			'products' => mvweb_core_is_woocommerce() ? 'product' : 'mv_item',
			'services' => 'mv_service',
			'works'    => 'mv_work',
			'posts'    => 'post',
			'pages'    => 'page',
		);

		return array_values( array_intersect_key( $types, array_flip( mvweb_core_layout_order( 'search.groups' ) ) ) );
	}
}

if ( ! function_exists( 'mvweb_theme_search_shown_types' ) ) {
	/**
	 * The search plugin asks only for the types the page shows, so the number found and the pages match the cards.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Query being prepared.
	 *
	 * @return void
	 */
	function mvweb_theme_search_shown_types( $query ) {
		if ( is_admin() || ! $query->is_main_query() || ! $query->get( 'mvweb_ss' ) ) {
			return;
		}

		$types = array_values( array_intersect( (array) $query->get( 'post_type' ), mvweb_theme_search_types() ) );

		if ( empty( $types ) ) {
			$query->set( 'post__in', array( 0 ) );
			return;
		}

		$query->set( 'post_type', $types );
	}
}
add_action( 'pre_get_posts', 'mvweb_theme_search_shown_types', 21 );

if ( ! function_exists( 'mvweb_theme_search_has_filters' ) ) {
	/**
	 * Whether the area "Search" holds the filters of the search plugin, which a phone opens with the button «Filter».
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_theme_search_has_filters() {
		$widgets = wp_get_sidebars_widgets();
		$id      = mvweb_core_sidebar_id( 'search' );

		foreach ( isset( $widgets[ $id ] ) ? (array) $widgets[ $id ] : array() as $widget ) {
			if ( 0 === strpos( (string) $widget, 'mvweb_ss_facets_widget-' ) ) {
				return true;
			}
		}

		return false;
	}
}

if ( ! function_exists( 'mvweb_theme_search_modules' ) ) {
	/**
	 * The scripts of the bar of the catalogue on the search page: the sorting sends itself, the switch changes the look of the list.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules File names without extension.
	 *
	 * @return string[]
	 */
	function mvweb_theme_search_modules( $modules ) {
		if ( ! is_search() ) {
			return $modules;
		}

		$modules[] = 'filters';

		if ( mvweb_core_catalog_view_switch() ) {
			$modules[] = 'catalog-view';
		}

		return array_values( array_unique( $modules ) );
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_theme_search_modules', 20 );

if ( ! function_exists( 'mvweb_theme_search_panel' ) ) {
	/**
	 * The row that the magnifier opens under the header.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_search_panel() {
		if ( ! ( mvweb_core_zone_has( 'header-main', 'actions' ) && mvweb_core_zone_has( 'header-actions', 'search' ) ) && ! mvweb_core_zone_has( 'header-nav', 'search' ) ) {
			return;
		}
		?>
		<div class="mvweb-t-header__search-pop" id="mvweb-t-search-panel" data-search-panel hidden>
			<div class="mvweb-t-container mvweb-t-header__search-pop-row">
				<?php echo mvweb_theme_search_field( 'pop' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts, or by the renderer of the plugin. ?>
				<button class="mvweb-t-round" type="button" data-search-close title="<?php esc_attr_e( 'Close search', 'brand-market' ); ?>">
					<?php echo mvweb_theme_icon( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					<span class="screen-reader-text"><?php esc_html_e( 'Close search', 'brand-market' ); ?></span>
				</button>
			</div>
		</div>
		<?php
	}
}
