<?php
/**
 * Stylesheets of the theme for the keys the core asks for.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_enqueue_styles' ) ) {
	/**
	 * Enqueue assets/css/{key}.css of the theme for every key of the request, in order.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_enqueue_styles() {
		$previous = '';

		foreach ( mvweb_core_style_map() as $key ) {
			$file = '';

			foreach ( array( '.min.css', '.css' ) as $extension ) {
				if ( '' === $file && file_exists( get_template_directory() . '/assets/css/' . $key . $extension ) ) {
					$file = '/assets/css/' . $key . $extension;
				}
			}

			if ( '' === $file ) {
				continue;
			}

			$handle = 'mvweb-t-' . str_replace( '/', '-', $key );

			wp_enqueue_style(
				$handle,
				get_template_directory_uri() . $file,
				'' === $previous ? array() : array( $previous ),
				(string) filemtime( get_template_directory() . $file )
			);

			$previous = $handle;
		}
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_theme_enqueue_styles' );

if ( ! function_exists( 'mvweb_theme_style_map' ) ) {
	/**
	 * Add the sheets of the theme that the core does not know: the width of the content and the entrance animation.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Keys of the request.
	 *
	 * @return string[]
	 */
	function mvweb_theme_style_map( $styles ) {
		$at = array_search( 'base', $styles, true );
		$at = false === $at ? 0 : $at + 1;

		array_splice( $styles, $at, 0, array( 'wide' ) );

		if ( mvweb_core_motion_active() ) {
			array_splice( $styles, $at + 1, 0, array( 'motion' ) );
		}

		if ( is_search() ) {
			array_push( $styles, 'catalog', 'service', 'works', 'blog' );
		}

		$first = count( $styles );

		foreach ( $styles as $index => $style ) {
			if ( 0 === strpos( $style, 'sections/' ) ) {
				$first = $index;
				break;
			}
		}

		$types = mvweb_core_request_section_types();

		if ( ! in_array( 'catalog', $styles, true ) && array_intersect( array( 'products', 'promo-products' ), $types ) ) {
			array_splice( $styles, $first, 0, array( 'catalog' ) );
			++$first;
		}

		if ( is_page() || in_array( 'embed', $types, true ) ) {
			$styles[] = 'form';
		}

		if ( mvweb_core_is_product() && function_exists( 'mvweb_core_one_click' ) && mvweb_core_one_click() ) {
			$styles[] = 'modal';
		}

		if ( in_array( 'blog', $styles, true ) && ( is_home() || is_archive() ) && 'journal' === mvweb_core_blog_view() ) {
			$styles[] = 'sections/posts';
		}

		if ( in_array( 'subscribe', $types, true ) && ! in_array( 'widgets', $styles, true ) ) {
			array_splice( $styles, $first, 0, array( 'widgets' ) );
			++$first;
		}

		if ( array_intersect( array( 'content', 'seo-text' ), $types ) && ! in_array( 'article', $styles, true ) ) {
			array_splice( $styles, $first, 0, array( 'article' ) );
		}

		if ( class_exists( 'WooCommerce' ) ) {
			$content = is_singular() ? (string) get_post_field( 'post_content', get_queried_object_id() ) : '';

			if ( has_shortcode( $content, 'product_page' ) ) {
				array_push( $styles, 'form', 'product' );
			}

			foreach ( array( 'products', 'product_category', 'product_categories', 'recent_products', 'featured_products', 'sale_products', 'best_selling_products', 'top_rated_products', 'product_attribute', 'related_products', 'product_page' ) as $tag ) {
				if ( has_shortcode( $content, $tag ) ) {
					$styles[] = 'catalog';
					break;
				}
			}

			$styles[] = 'woo';
		}

		if ( mvweb_core_callouts_needed() ) {
			array_push( $styles, 'callouts', 'callouts-' . mvweb_core_callouts_set() );
		}

		if ( mvweb_core_stream_needed() ) {
			if ( mvweb_core_home_stream_on() ) {
				array_push( $styles, 'pagination', 'blog' );

				if ( 'side' === mvweb_core_home_mode() ) {
					$styles[] = 'widgets';
				}

				if ( 'top' !== mvweb_core_home_mode() || mvweb_core_home_page() > 1 ) {
					$styles = array_values(
						array_filter(
							$styles,
							static function ( $style ) {
								return 0 !== strpos( $style, 'sections/' );
							}
						)
					);
				}
			}

			$styles[] = 'stream';
		}

		$catalog = array_search( 'catalog', $styles, true );

		if ( false !== $catalog ) {
			array_splice( $styles, $catalog, 0, array( 'subcats' ) );
		} elseif ( array() !== mvweb_core_blog_subcats() ) {
			$styles[] = 'subcats';
		}

		return array_values( array_unique( $styles ) );
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_theme_style_map' );

if ( ! function_exists( 'mvweb_theme_module_map' ) ) {
	/**
	 * Add the modules of the core that the blocks of the theme lean on.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules File names without extension.
	 *
	 * @return string[]
	 */
	function mvweb_theme_module_map( $modules ) {
		if ( in_array( 'promo-products', mvweb_core_request_section_types(), true ) ) {
			$modules[] = 'showcase';
		}

		if ( class_exists( 'WooCommerce' ) && is_singular() && ! mvweb_core_is_product() && has_shortcode( (string) get_post_field( 'post_content', get_queried_object_id() ), 'product_page' ) ) {
			array_push( $modules, 'product-page', 'product-gallery' );

			if ( mvweb_core_one_click() ) {
				$modules[] = 'one-click';
			}
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_theme_module_map' );

if ( ! function_exists( 'mvweb_theme_preload_fonts' ) ) {
	/**
	 * Preload the two font files so the text does not jump when they arrive.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_preload_fonts() {
		foreach ( array( 'onest', 'golos-text' ) as $font ) {
			printf( "<link rel=\"preload\" href=\"%s\" as=\"font\" type=\"font/woff2\" crossorigin>\n", esc_url( get_template_directory_uri() . '/assets/fonts/' . $font . '.woff2' ) );
		}
	}
}
add_action( 'wp_head', 'mvweb_theme_preload_fonts', 1 );

if ( ! function_exists( 'mvweb_theme_enqueue_scripts' ) ) {
	/**
	 * Enqueue the script of the theme: the back link, the section selects, the subcategory strip and the sidebar height.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_enqueue_scripts() {
		$file = file_exists( get_template_directory() . '/assets/js/frame.min.js' ) ? '/assets/js/frame.min.js' : '/assets/js/frame.js';

		wp_enqueue_script(
			'mvweb-t-frame',
			get_template_directory_uri() . $file,
			array(),
			(string) filemtime( get_template_directory() . $file ),
			array(
				'in_footer' => true,
				'strategy'  => 'defer',
			)
		);
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_theme_enqueue_scripts' );
