<?php
/**
 * WooCommerce as the theme draws it. Loaded only with WooCommerce.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_woocommerce_body_class' ) ) {
	/**
	 * Tell WooCommerce the theme styles its buttons.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $classes Body classes.
	 *
	 * @return string[]
	 */
	function mvweb_theme_woocommerce_body_class( $classes ) {
		$classes[] = 'woocommerce-block-theme-has-button-styles';

		return $classes;
	}
}
add_filter( 'body_class', 'mvweb_theme_woocommerce_body_class' );

if ( ! function_exists( 'mvweb_theme_woocommerce_unhook' ) ) {
	/**
	 * Take the default loop output off its hooks.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_woocommerce_unhook() {
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_rating', 10 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_excerpt', 20 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
		remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_sharing', 50 );

		remove_action( 'woocommerce_before_shop_loop_item', 'woocommerce_template_loop_product_link_open', 10 );
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_product_link_close', 5 );
		remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
		remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_template_loop_product_thumbnail', 10 );
		remove_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
		remove_action( 'woocommerce_shop_loop_item_title', 'woocommerce_template_loop_product_title', 10 );
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_price', 10 );
		remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );

		remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
		remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );
		remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20 );
		remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
		remove_action( 'woocommerce_shop_loop_header', 'woocommerce_product_taxonomy_archive_header' );
		remove_action( 'woocommerce_archive_description', 'woocommerce_taxonomy_archive_description', 10 );
		remove_action( 'woocommerce_archive_description', 'woocommerce_product_archive_description', 10 );

		if ( isset( $GLOBALS['WC_Brands'] ) ) {
			remove_action( 'woocommerce_archive_description', array( $GLOBALS['WC_Brands'], 'brand_description' ) );
		}

		remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10 );
		remove_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_images', 20 );
		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_upsell_display', 15 );
		remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

		if ( isset( $GLOBALS['WC_Brands'] ) ) {
			remove_action( 'woocommerce_product_meta_end', array( $GLOBALS['WC_Brands'], 'show_brand' ) );
		}
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_woocommerce_unhook' );

if ( ! function_exists( 'mvweb_theme_woocommerce_archive_unhook' ) ) {
	/**
	 * On the shop and its taxonomies take off what the listing of the theme prints itself: the count, the order, the pages, the notices and the empty message; on a product page, the notices.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_woocommerce_archive_unhook() {
		if ( is_product() ) {
			remove_action( 'woocommerce_before_single_product', 'woocommerce_output_all_notices', 10 );
		}

		if ( ! mvweb_core_wc_archive() ) {
			return;
		}

		remove_action( 'woocommerce_before_shop_loop', 'woocommerce_output_all_notices', 10 );
		remove_action( 'woocommerce_before_shop_loop', 'woocommerce_result_count', 20 );
		remove_action( 'woocommerce_before_shop_loop', 'woocommerce_catalog_ordering', 30 );
		remove_action( 'woocommerce_no_products_found', 'wc_no_products_found' );
		remove_action( 'woocommerce_after_shop_loop', 'woocommerce_pagination', 10 );
	}
}
add_action( 'wp', 'mvweb_theme_woocommerce_archive_unhook' );

if ( ! function_exists( 'mvweb_theme_sale_flash' ) ) {
	/**
	 * Re-dress the sale marker in the card's own class.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_theme_sale_flash() {
		return '<span class="mvweb-t-product__badge">' . esc_html__( 'Sale', 'brand-market' ) . '</span>';
	}
}
add_filter( 'woocommerce_sale_flash', 'mvweb_theme_sale_flash' );

if ( ! function_exists( 'mvweb_theme_wc_price_html' ) ) {
	/**
	 * Wrap a price in the span the layout keeps on one line.
	 *
	 * @since 0.1.0
	 *
	 * @param string $html Price markup.
	 *
	 * @return string
	 */
	function mvweb_theme_wc_price_html( $html ) {
		if ( '' === trim( (string) $html ) ) {
			return $html;
		}

		return '<span class="mvweb-t-product__amount">' . $html . '</span>';
	}
}
add_filter( 'woocommerce_get_price_html', 'mvweb_theme_wc_price_html' );

if ( ! function_exists( 'mvweb_theme_add_to_cart_shortcode' ) ) {
	/**
	 * Drop the grey frame WooCommerce draws around [add_to_cart] unless the shortcode asks for its own style.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $out   Attributes in use.
	 * @param array<string,string> $pairs Default attributes.
	 * @param array<string,string> $atts  Attributes the shortcode was given.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_add_to_cart_shortcode( $out, $pairs, $atts ) {
		unset( $pairs );

		if ( ! isset( $atts['style'] ) ) {
			$out['style'] = '';
		}

		return $out;
	}
}
add_filter( 'shortcode_atts_product_add_to_cart', 'mvweb_theme_add_to_cart_shortcode', 10, 3 );
