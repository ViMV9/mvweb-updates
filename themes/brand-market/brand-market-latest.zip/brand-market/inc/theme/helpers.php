<?php
/**
 * Design helpers the templates of the theme call.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_header_class' ) ) {
	/**
	 * Class list for the header element.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_theme_header_class() {
		$classes = array( 'mvweb-t-header' );

		if ( is_singular( 'page' ) && has_post_thumbnail() ) {
			$classes[] = 'mvweb-t-header--overlay';
		}

		/**
		 * Filter the header class list.
		 *
		 * @since 0.1.0
		 *
		 * @param string[] $classes Class names.
		 */
		$classes = (array) apply_filters( 'mvweb_theme_header_class', $classes );

		return implode( ' ', array_filter( array_map( 'sanitize_html_class', $classes ) ) );
	}
}

if ( ! function_exists( 'mvweb_theme_pagination' ) ) {
	/**
	 * Print pagination in the theme's own markup.
	 *
	 * @since 0.1.0
	 *
	 * @param array $args Optional. Arguments passed to paginate_links(). The
	 *                    'type' key is ignored — this function needs an array.
	 *
	 * @return void
	 */
	function mvweb_theme_pagination( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'mid_size'  => 1,
				'end_size'  => 1,
				'prev_text' => mvweb_theme_icon( 'chevron-left', array( 'class' => 'mvweb-t-icon--sm' ) ) . '<span class="screen-reader-text">' . esc_html__( 'Previous page', 'brand-market' ) . '</span>',
				'next_text' => mvweb_theme_icon( 'chevron-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '<span class="screen-reader-text">' . esc_html__( 'Next page', 'brand-market' ) . '</span>',
			)
		);

		$args['type'] = 'array';

		$links = paginate_links( $args );

		if ( empty( $links ) ) {
			return;
		}

		$map = array(
			'class="prev page-numbers"' => 'class="mvweb-t-pagination__item" title="' . esc_attr__( 'Previous page', 'brand-market' ) . '"',
			'class="next page-numbers"' => 'class="mvweb-t-pagination__item" data-next title="' . esc_attr__( 'Next page', 'brand-market' ) . '"',
			'page-numbers dots'         => 'mvweb-t-pagination__item mvweb-t-pagination__item--dots',
			'page-numbers current'      => 'mvweb-t-pagination__item',
			'page-numbers'              => 'mvweb-t-pagination__item',
		);

		printf(
			'<nav class="mvweb-t-pagination" aria-label="%s">',
			esc_attr__( 'Pagination', 'brand-market' )
		);

		foreach ( $links as $link ) {
			echo str_replace( array_keys( $map ), array_values( $map ), $link ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup comes from paginate_links(), which escapes it.
		}

		echo '</nav>';
	}
}

if ( ! function_exists( 'mvweb_theme_logo' ) ) {
	/**
	 * Print the site logo: the uploaded image, or the site name as a wordmark.
	 *
	 * @since 0.1.0
	 *
	 * @param array $args Optional. 'class' — extra classes on the link,
	 *                    'tag' — 'a' (default) or 'span' for the drawer copy,
	 *                    'lazy' — true for copies below the first screen,
	 *                    'heading' — true when the logo is the h1 of the page:
	 *                    the name is the h1, a logo of a picture alone is wrapped in it.
	 *
	 * @return void
	 */
	function mvweb_theme_logo( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'class'   => '',
				'tag'     => 'a',
				'lazy'    => false,
				'heading' => false,
			)
		);

		$light = (int) get_theme_mod( 'custom_logo' );
		$dark  = (int) get_theme_mod( 'mvweb_logo_dark' );
		$light = wp_attachment_is_image( $light ) ? $light : 0;
		$dark  = wp_attachment_is_image( $dark ) ? $dark : 0;
		$sign  = ( $light || $dark ) && 'mark' === mvweb_cz_get( 'mvweb_logo_layout', 'image' );
		$alt   = $sign ? '' : get_bloginfo( 'name' );

		$tag        = 'span' === $args['tag'] ? 'span' : 'a';
		$class      = trim( 'mvweb-t-logo ' . ( $sign ? 'mvweb-t-logo--sign ' : '' ) . $args['class'] );
		$attributes = 'a' === $tag ? sprintf( ' href="%s" rel="home"', esc_url( home_url( '/' ) ) ) : '';
		$heading    = ! empty( $args['heading'] ) && 'a' === $tag;
		$wrap       = $heading && ( $light || $dark ) && ! $sign;

		if ( $wrap ) {
			echo '<h1 class="mvweb-t-logo-h1">';
		}

		printf( '<%1$s class="%2$s"%3$s>', esc_html( $tag ), esc_attr( $class ), $attributes ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Attributes escaped above.

		if ( $light && $dark && $light !== $dark ) {
			echo mvweb_theme_logo_image( $light, 'mvweb-t-logo__img mvweb-t-logo__img--light', $args['lazy'], $alt ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
			echo mvweb_theme_logo_image( $dark, 'mvweb-t-logo__img mvweb-t-logo__img--dark', $args['lazy'], $alt ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
		} elseif ( $light || $dark ) {
			echo mvweb_theme_logo_image( $light ? $light : $dark, 'mvweb-t-logo__img', $args['lazy'], $alt ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
		}

		if ( $sign ) {
			$name    = trim( (string) mvweb_cz_get( 'mvweb_logo_name', '' ) );
			$name    = '' !== $name ? $name : get_bloginfo( 'name' );
			$tagline = trim( (string) mvweb_cz_get( 'mvweb_logo_tagline', '' ) );

			printf( $heading ? '<div class="mvweb-t-logo__brand"><h1 class="mvweb-t-logo__name">%s</h1>' : '<span class="mvweb-t-logo__brand"><span class="mvweb-t-logo__name">%s</span>', esc_html( $name ) );

			if ( '' !== $tagline ) {
				printf( '<span class="mvweb-t-logo__tagline">%s</span>', esc_html( $tagline ) );
			}

			echo $heading ? '</div>' : '</span>';
		} elseif ( ! $light && ! $dark ) {
			$name  = get_bloginfo( 'name' );
			$words = preg_split( '/\s+/u', trim( $name ), 2, PREG_SPLIT_NO_EMPTY );
			$words = is_array( $words ) ? $words : array( $name );

			$mark = '';
			foreach ( $words as $word ) {
				$mark .= mb_substr( $word, 0, 1 );
			}

			printf( '<span class="mvweb-t-logo__mark" aria-hidden="true">%s</span>', esc_html( $mark ) );
			echo $heading ? '<h1 class="mvweb-t-logo__text">' : '<span class="mvweb-t-logo__text">';
			foreach ( $words as $word ) {
				printf( '<span>%s</span> ', esc_html( $word ) );
			}
			echo $heading ? '</h1>' : '</span>';
		}

		printf( '</%s>', esc_html( $tag ) );

		if ( $wrap ) {
			echo '</h1>';
		}
	}
}

if ( ! function_exists( 'mvweb_theme_logo_image' ) ) {
	/**
	 * One logo image, with a sizes value that matches how big it is shown.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $id      Attachment id.
	 * @param string $classes Class list.
	 * @param bool   $lazy    Whether the copy sits below the first screen.
	 * @param string $alt     Alternative text; empty when the name is printed
	 *                        next to the image.
	 *
	 * @return string
	 */
	function mvweb_theme_logo_image( $id, $classes, $lazy, $alt ) {
		$attr = array(
			'class'         => $classes,
			'alt'           => $alt,
			'loading'       => $lazy ? 'lazy' : false,
			'fetchpriority' => $lazy ? false : 'auto',
		);

		$image = wp_get_attachment_image_src( $id, 'full' );

		if ( $image && $image[2] > 0 ) {
			$ratio         = $image[1] / $image[2];
			$attr['sizes'] = sprintf(
				'(max-width: 1000px) %dpx, %dpx',
				ceil( (int) mvweb_cz_get( 'mvweb_logo_height_mobile', 40 ) * $ratio ),
				ceil( (int) mvweb_cz_get( 'mvweb_logo_height', 40 ) * $ratio )
			);
		}

		return wp_get_attachment_image( $id, 'full', false, $attr );
	}
}

if ( ! function_exists( 'mvweb_theme_drop_breadcrumbs_block_style' ) ) {
	/**
	 * Drop the stylesheet the breadcrumbs block enqueues when it renders.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_drop_breadcrumbs_block_style() {
		wp_deregister_style( 'wp-block-breadcrumbs' );
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_theme_drop_breadcrumbs_block_style', 20 );

if ( ! function_exists( 'mvweb_theme_card_group' ) ) {
	/**
	 * Open and close the groups of the body of a product card.
	 *
	 * @since 0.1.0
	 *
	 * @param array  $args  Arguments of the card, with its state.
	 * @param string $group Group the part belongs to: info or foot. Empty closes the open one.
	 *
	 * @return void
	 */
	function mvweb_theme_card_group( array $args, $group ) {
		if ( ! isset( $args['state'] ) || ! $args['state'] instanceof ArrayObject ) {
			return;
		}

		$open = (string) $args['state']['group'];

		if ( $open === $group ) {
			return;
		}

		if ( '' !== $open ) {
			echo '</div>';
		}

		if ( '' !== $group ) {
			echo '<div class="mvweb-t-card__' . esc_attr( $group ) . '">';
		}

		$args['state']['group'] = $group;
	}
}

if ( ! function_exists( 'mvweb_theme_showcase_arrows' ) ) {
	/**
	 * The previous and next buttons of a scrolling row, driven by showcase.js.
	 *
	 * @since 0.1.0
	 *
	 * @param array $args Optional. Keys: prev and next (labels), class (own class of a button, with a --prev / --next modifier), hide_prev (bool, the previous button starts hidden), small (bool, smaller icons).
	 *
	 * @return string Escaped markup of two buttons.
	 */
	function mvweb_theme_showcase_arrows( array $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'prev'      => __( 'Previous', 'brand-market' ),
				'next'      => __( 'Next', 'brand-market' ),
				'class'     => '',
				'hide_prev' => false,
				'small'     => false,
			)
		);
		$html = '';
		$icon = $args['small'] ? array( 'class' => 'mvweb-t-icon--sm' ) : array();

		foreach ( array( 'prev', 'next' ) as $way ) {
			$class = 'mvweb-t-round mvweb-t-round--line' . ( '' !== $args['class'] ? ' ' . $args['class'] . ' ' . $args['class'] . '--' . $way : '' );
			$label = (string) $args[ $way ];
			$html .= '<button class="' . esc_attr( $class ) . '" type="button" data-showcase-' . $way . ( 'prev' === $way && $args['hide_prev'] ? ' hidden' : '' ) . ' title="' . esc_attr( $label ) . '">' . mvweb_theme_icon( 'prev' === $way ? 'chevron-left' : 'chevron-right', $icon ) . '<span class="screen-reader-text">' . esc_html( $label ) . '</span></button>';
		}

		return $html;
	}
}

if ( ! function_exists( 'mvweb_theme_hooked' ) ) {
	/**
	 * Collect what other plugins print on a hook of WooCommerce.
	 *
	 * @since 1.0.1
	 *
	 * @param string $hook Hook of WooCommerce.
	 * @param mixed  ...$args Arguments of the hook.
	 *
	 * @return string
	 */
	function mvweb_theme_hooked( $hook, ...$args ) {
		ob_start();
		do_action( $hook, ...$args ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.DynamicHooknameFound -- Hooks of WooCommerce.
		$html = trim( (string) ob_get_clean() );

		if ( '' === trim( wp_strip_all_tags( $html ) ) ) {
			return $html;
		}

		return '<div class="mvweb-t-hooked">' . $html . '</div>';
	}
}

if ( ! function_exists( 'mvweb_theme_render_order_layout' ) ) {
	/**
	 * Print the parts of an order area with the blocks of other plugins before its buttons.
	 *
	 * @since 1.0.1
	 *
	 * @param string $area   Layout area.
	 * @param array  $args   Print arguments.
	 * @param string $hooked Output of mvweb_theme_hooked().
	 *
	 * @return void
	 */
	function mvweb_theme_render_order_layout( $area, array $args, $hooked ) {
		$hooked = (string) $hooked;
		$done   = '' === $hooked;
		$area   = mvweb_core_layout_area( $area );
		$print  = static function ( $handled, $part_area, $slug ) use ( $area, $hooked, &$done ) {
			if ( ! $done && $area === $part_area && 'actions' === $slug ) {
				echo $hooked; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Blocks that other plugins print on the hook of WooCommerce.
				$done = true;
			}

			return $handled;
		};

		add_filter( 'mvweb_core_render_part', $print, 10, 3 );
		mvweb_core_render_layout( $area, $args );
		remove_filter( 'mvweb_core_render_part', $print, 10 );

		if ( ! $done ) {
			echo $hooked; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Blocks that other plugins print on the hook of WooCommerce.
		}
	}
}

if ( ! function_exists( 'mvweb_theme_order_extras' ) ) {
	/**
	 * What WooCommerce prints around the order details table, which the theme draws its own way: the downloads and the blocks of other plugins.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Order $order Order.
	 *
	 * @return string
	 */
	function mvweb_theme_order_extras( $order ) {
		if ( ! $order instanceof WC_Order ) {
			return '';
		}

		$html = '';

		if ( apply_filters( 'woocommerce_order_downloads_table_show_downloads', $order->has_downloadable_item() && $order->is_download_permitted(), $order ) ) { // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
			ob_start();
			wc_get_template(
				'order/order-downloads.php',
				array(
					'downloads'  => $order->get_downloadable_items(),
					'show_title' => true,
				)
			);
			$html .= '<div class="mvweb-t-hooked">' . trim( (string) ob_get_clean() ) . '</div>';
		}

		foreach ( array( 'woocommerce_order_details_before_order_table', 'woocommerce_order_details_after_order_table', 'woocommerce_order_details_after_customer_details', 'woocommerce_after_order_details' ) as $hook ) {
			$html .= mvweb_theme_hooked( $hook, $order );
		}

		return $html;
	}
}
