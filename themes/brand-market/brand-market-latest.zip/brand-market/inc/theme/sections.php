<?php
/**
 * Blocks of the theme: the views, the parts and the shell every block template prints.
 *
 * Each file of inc/theme/blocks/ describes one block type and returns
 * views, parts and item_parts. The registry hands them to the core by its
 * filters; the templates read them back through mvweb_theme_block().
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_blocks' ) ) {
	/**
	 * Descriptions of the block types the theme draws.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>> Type => views, parts, item_parts.
	 */
	function mvweb_theme_blocks() {
		static $blocks = null;

		if ( null === $blocks ) {
			$blocks = array();

			foreach ( (array) glob( MVWEB_THEME_DIR . '/inc/theme/blocks/*.php' ) as $file ) {
				$description = require $file;

				if ( is_array( $description ) ) {
					$blocks[ basename( $file, '.php' ) ] = $description;
				}
			}
		}

		return $blocks;
	}
}

if ( ! function_exists( 'mvweb_theme_block_views' ) ) {
	/**
	 * Give the core the names of the views of a block type.
	 *
	 * @since 0.1.0
	 *
	 * @param array  $views Views so far.
	 * @param string $type  Block type.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_block_views( $views, $type ) {
		$blocks = mvweb_theme_blocks();

		if ( empty( $blocks[ $type ]['views'] ) ) {
			return $views;
		}

		foreach ( $blocks[ $type ]['views'] as $key => $view ) {
			$views[ (string) $key ] = $view['label'];
		}

		return $views;
	}
}
add_filter( 'mvweb_core_section_views', 'mvweb_theme_block_views', 10, 2 );

if ( ! function_exists( 'mvweb_theme_block_parts' ) ) {
	/**
	 * Give the core the parts of the block types and what works in some views only.
	 *
	 * @since 0.1.0
	 *
	 * @param array $table Type => parts, item_parts and only so far.
	 *
	 * @return array<string,array<string,array<string,string>>>
	 */
	function mvweb_theme_block_parts( $table ) {
		foreach ( mvweb_theme_blocks() as $type => $description ) {
			foreach ( array( 'parts', 'item_parts', 'only' ) as $key ) {
				if ( ! empty( $description[ $key ] ) ) {
					$table[ $type ][ $key ] = $description[ $key ];
				}
			}
		}

		return $table;
	}
}
add_filter( 'mvweb_core_section_parts', 'mvweb_theme_block_parts' );

if ( ! function_exists( 'mvweb_theme_block' ) ) {
	/**
	 * Everything a block template needs to know about the row it prints.
	 *
	 * @since 0.1.0
	 *
	 * @param string $type Block type.
	 * @param array  $args Arguments the core passes to the template.
	 *
	 * @return array{type:string,props:array,view:string,mod:string,motion:string,look:array,parts:string[],item_parts:string[]}
	 */
	function mvweb_theme_block( $type, array $args ) {
		$props       = isset( $args['props'] ) && is_array( $args['props'] ) ? $args['props'] : array();
		$description = mvweb_theme_blocks();
		$description = isset( $description[ $type ] ) ? $description[ $type ] : array();
		$views       = isset( $description['views'] ) ? $description['views'] : array();
		$view        = mvweb_core_view( $props );

		if ( ! isset( $views[ $view ] ) ) {
			$view = (string) array_key_first( $views );
		}

		$current = isset( $views[ $view ] ) ? $views[ $view ] : array();

		return array(
			'type'       => $type,
			'props'      => $props,
			'view'       => $view,
			'mod'        => isset( $current['class'] ) ? (string) $current['class'] : '',
			'motion'     => mvweb_core_motion( $props, isset( $current['motion'] ) ? (string) $current['motion'] : '' ),
			'look'       => mvweb_core_section_look( $props ),
			'parts'      => mvweb_core_parts( $props ),
			'item_parts' => mvweb_core_parts( $props, 'item_parts' ),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_cards_colours' ) ) {
	/**
	 * Own colours of the cards and the icons of a block with a background.
	 *
	 * @since 0.1.0
	 *
	 * @param array $block Result of mvweb_theme_block(); its style gets the colours.
	 *
	 * @return string Classes of the section, each after a space.
	 */
	function mvweb_theme_cards_colours( array &$block ) {
		if ( 'plain' === $block['look']['background'] ) {
			return '';
		}

		$classes = '';
		$names   = array(
			'cards' => array( 'cards', '--mvweb-t-cards-bg', '--mvweb-t-cards-ink' ),
			'icon'  => array( 'icons', '--mvweb-t-cards-icon', '--mvweb-t-cards-icon-ink' ),
		);

		foreach ( mvweb_core_cards_colours( $block['props'] ) as $what => $colour ) {
			$classes                .= ' mvweb-t-' . $block['type'] . '--own-' . $names[ $what ][0];
			$block['look']['style'] .= $names[ $what ][1] . ':' . $colour['bg'] . ';' . $names[ $what ][2] . ':' . $colour['ink'] . ';';
		}

		return $classes;
	}
}

if ( ! function_exists( 'mvweb_theme_section_open' ) ) {
	/**
	 * Print the opening tags of a block: the section and, unless the view is full-bleed, the container.
	 *
	 * @since 0.1.0
	 *
	 * @param array  $block     Result of mvweb_theme_block().
	 * @param bool   $container Whether the container opens with the section.
	 * @param string $extra     Extra classes of the section.
	 *
	 * @return void
	 */
	function mvweb_theme_section_open( array $block, $container = true, $extra = '' ) {
		$class = 'mvweb-t-section mvweb-t-' . $block['type'];

		if ( '' !== $block['mod'] ) {
			$class .= ' mvweb-t-' . $block['type'] . '--' . $block['mod'];
		}

		if ( '' !== $extra ) {
			$class .= ' ' . $extra;
		}

		foreach ( mvweb_core_part_colours( $block['props'] ) as $part => $colour ) {
			$class                  .= ' mvweb-t-section--own-' . $part;
			$block['look']['style'] .= '--mvweb-t-own-' . $part . ':' . $colour['bg'] . ';--mvweb-t-own-' . $part . '-ink:' . $colour['ink'] . ';';
		}

		$background = $block['look']['background'];
		?>
		<section class="<?php echo esc_attr( $class ); ?>"<?php echo 'plain' !== $background ? ' data-bg="' . esc_attr( $background ) . '"' : ''; ?><?php echo '' !== $block['motion'] ? ' data-motion="' . esc_attr( $block['motion'] ) . '"' : ''; ?><?php echo '' !== $block['look']['style'] ? ' style="' . esc_attr( $block['look']['style'] ) . '"' : ''; ?>>
		<?php if ( $container ) : ?>
			<div class="mvweb-t-container">
		<?php endif; ?>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_section_close' ) ) {
	/**
	 * Print the closing tags of a block.
	 *
	 * @since 0.1.0
	 *
	 * @param bool $container Whether the container was opened with the section.
	 *
	 * @return void
	 */
	function mvweb_theme_section_close( $container = true ) {
		if ( $container ) {
			echo '</div>';
		}

		echo '</section>';
	}
}

if ( ! function_exists( 'mvweb_theme_head' ) ) {
	/**
	 * Print the head of a block from the head parts that are switched on.
	 *
	 * @since 0.1.0
	 *
	 * @param array $block Result of mvweb_theme_block().
	 * @param array $slugs Head parts to print, in order.
	 * @param array $args  Optional. Keys: class (modifier of the head), rv (bool, texts appear with the block), side (string, ready markup printed after the text, e.g. arrows or a button), title_tag (string, h1 when the heading is the h1 of the page).
	 *
	 * @return bool Whether anything was printed.
	 */
	function mvweb_theme_head( array $block, array $slugs, array $args = array() ) {
		$props  = $block['props'];
		$text   = array();
		$more   = '';
		$rv     = ! empty( $args['rv'] ) && '' !== $block['motion'];
		$tag    = isset( $args['title_tag'] ) && 'h1' === $args['title_tag'] ? 'h1' : 'div';
		$side   = isset( $args['side'] ) ? trim( (string) $args['side'] ) : '';
		$fields = array(
			'kicker' => 'kicker',
			'title'  => 'title',
			'lead'   => 'text',
		);

		foreach ( $slugs as $slug ) {
			if ( isset( $fields[ $slug ] ) && ! empty( $props[ $fields[ $slug ] ] ) ) {
				$text[ $slug ] = (string) $props[ $fields[ $slug ] ];
			}
		}

		if ( in_array( 'more', $slugs, true ) && ! empty( $props['link_text'] ) && ! empty( $props['link_url'] ) ) {
			$more = '<a class="mvweb-t-section-head__more" href="' . esc_url( (string) $props['link_url'] ) . '">' . esc_html( (string) $props['link_text'] ) . '</a>';
		}

		if ( empty( $text ) && '' === $more && '' === $side ) {
			return false;
		}

		$class = trim( 'mvweb-t-section-head ' . ( isset( $args['class'] ) ? (string) $args['class'] : '' ) );
		?>
		<div class="<?php echo esc_attr( $class ); ?>">
			<?php if ( ! empty( $text ) ) : ?>
				<div class="mvweb-t-section-head__text"<?php echo $rv ? ' data-rv' : ''; ?>>
					<?php foreach ( $text as $slug => $value ) : ?>
						<?php if ( 'kicker' === $slug ) : ?>
							<p class="mvweb-t-section-head__kicker"><?php echo esc_html( $value ); ?></p>
						<?php elseif ( 'title' === $slug ) : ?>
							<<?php echo esc_attr( $tag ); ?> class="mvweb-t-section-head__title mvweb-t-h2"<?php echo 'div' === $tag ? ' role="heading" aria-level="2"' : ''; ?>><?php echo esc_html( $value ); ?></<?php echo esc_attr( $tag ); ?>>
						<?php else : ?>
							<p class="mvweb-t-section-head__lead"><?php echo esc_html( $value ); ?></p>
						<?php endif; ?>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
			<?php echo wp_kses_post( $more ); ?>
			<?php echo $side; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Markup built and escaped by the caller. ?>
		</div>
		<?php

		return true;
	}
}

if ( ! function_exists( 'mvweb_theme_render_parts' ) ) {
	/**
	 * Print the parts of a block in the order the editor set.
	 *
	 * @since 0.1.0
	 *
	 * @param array $block     Result of mvweb_theme_block().
	 * @param array $renderers Slug => callable( array $block ) that prints the part.
	 * @param array $head      Optional. Arguments of mvweb_theme_head().
	 *
	 * @return void
	 */
	function mvweb_theme_render_parts( array $block, array $renderers, array $head = array() ) {
		$pending = array();
		$side    = isset( $head['side'] ) ? (string) $head['side'] : '';

		foreach ( array_merge( $block['parts'], array( '' ) ) as $slug ) {
			if ( in_array( $slug, array( 'kicker', 'title', 'lead', 'more' ), true ) ) {
				$pending[] = $slug;
				continue;
			}

			if ( ! empty( $pending ) || ( '' === $slug && '' !== $side ) ) {
				mvweb_theme_head( $block, $pending, array_merge( $head, array( 'side' => $side ) ) );
				$pending = array();
				$side    = '';
			}

			if ( '' !== $slug && isset( $renderers[ $slug ] ) && is_callable( $renderers[ $slug ] ) ) {
				call_user_func( $renderers[ $slug ], $block );
			}
		}
	}
}

if ( ! function_exists( 'mvweb_theme_render_item_parts' ) ) {
	/**
	 * Print the parts of one item of a list in the order the editor set.
	 *
	 * @since 0.1.0
	 *
	 * @param array $block     Result of mvweb_theme_block().
	 * @param array $item      One row of the list.
	 * @param array $renderers Slug => callable( array $item, array $block ) that prints the part.
	 *
	 * @return void
	 */
	function mvweb_theme_render_item_parts( array $block, array $item, array $renderers ) {
		foreach ( $block['item_parts'] as $slug ) {
			if ( isset( $renderers[ $slug ] ) && is_callable( $renderers[ $slug ] ) ) {
				call_user_func( $renderers[ $slug ], $item, $block );
			}
		}
	}
}

if ( ! function_exists( 'mvweb_theme_markup_places' ) ) {
	/**
	 * Mark up the places of every city where the contacts block shows the tabs of the cities.
	 *
	 * @since 0.1.0
	 *
	 * @param array $places Places of the chosen city.
	 *
	 * @return array
	 */
	function mvweb_theme_markup_places( $places ) {
		foreach ( mvweb_core_request_sections() as $row ) {
			if ( is_array( $row ) && isset( $row['type'] ) && 'contacts' === $row['type'] && '5' === mvweb_core_view( isset( $row['props'] ) && is_array( $row['props'] ) ? $row['props'] : array() ) ) {
				return array_filter(
					mvweb_core_branches(),
					static function ( $branch ) {
						return '' !== $branch['key'];
					}
				);
			}
		}

		return $places;
	}
}
add_filter( 'mvweb_core_markup_places', 'mvweb_theme_markup_places' );
