<?php
/**
 * The strip "Addresses of the city" under the header: every place of the chosen city as a line, cards or tabs, with the status by its hours.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_places_status_support' ) ) {
	/**
	 * Let the core read the opening hours into the status "Open until …".
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_places_status_support() {
		add_theme_support( 'mvweb-branch-status' );
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_places_status_support' );

if ( ! function_exists( 'mvweb_theme_places_fields' ) ) {
	/**
	 * The settings of the strip in the section of the header.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $fields Fields of the Customizer.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_theme_places_fields( $fields ) {
		$fields[] = array(
			'type'        => 'radio',
			'settings'    => 'mvweb_places_view',
			'section'     => 'mvweb_cz_header_blocks',
			'label'       => __( 'Addresses of the city under the header', 'brand-market' ),
			'description' => __( 'A strip under the header with every address of the chosen city: hours, “Open until …” by the hours and the route. The addresses are those of the branches of the chosen city.', 'brand-market' ),
			'default'     => 'none',
			'choices'     => array(
				'none'  => __( 'Do not show', 'brand-market' ),
				'line'  => __( 'Line', 'brand-market' ),
				'cards' => __( 'Cards', 'brand-market' ),
				'tabs'  => __( 'Tabs', 'brand-market' ),
			),
		);

		$fields[] = array(
			'type'     => 'radio',
			'settings' => 'mvweb_places_where',
			'section'  => 'mvweb_cz_header_blocks',
			'label'    => __( 'Where the addresses of the city stand', 'brand-market' ),
			'default'  => 'all',
			'choices'  => array(
				'all'     => __( 'On every page', 'brand-market' ),
				'desktop' => __( 'On every page, computer only', 'brand-market' ),
				'home'    => __( 'On the home page and the pages with contacts', 'brand-market' ),
			),
		);

		$fields[] = array(
			'type'        => 'radio',
			'settings'    => 'mvweb_places_mobile',
			'section'     => 'mvweb_cz_header_blocks',
			'label'       => __( 'Addresses of the city on a phone', 'brand-market' ),
			'description' => __( 'How the strip shows several addresses on a phone. On a computer it keeps the look chosen above.', 'brand-market' ),
			'default'     => 'list',
			'choices'     => array(
				'list'    => __( 'List under a button', 'brand-market' ),
				'select'  => __( 'Choice of the address in a sheet', 'brand-market' ),
				'stepper' => __( 'One by one with arrows', 'brand-market' ),
				'open'    => __( 'The one open now and the others', 'brand-market' ),
			),
		);

		$fields[] = array(
			'type'        => 'toggle',
			'settings'    => 'mvweb_city_places',
			'section'     => 'mvweb_cz_header_blocks',
			'label'       => __( 'Addresses beside the city', 'brand-market' ),
			'description' => __( 'Beside the chosen city: the number of its addresses, or the name of the only one. The window of the city choice shows them with hours and the route.', 'brand-market' ),
			'default'     => false,
		);

		$fields[] = array(
			'type'        => 'toggle',
			'settings'    => 'mvweb_header_sticky',
			'section'     => 'mvweb_cz_header_blocks',
			'label'       => __( 'Header stays on top while scrolling on a phone', 'brand-market' ),
			'description' => __( 'On a phone the header stays at the top of the screen, and the strip with the addresses of the city under it scrolls away. On a computer and a tablet the header scrolls with the page.', 'brand-market' ),
			'default'     => false,
		);

		return $fields;
	}
}
add_filter( 'mvweb_cz_baseline_fields', 'mvweb_theme_places_fields' );

if ( ! function_exists( 'mvweb_theme_places_field_order' ) ) {
	/**
	 * Put the settings of the strip after the main menu of the header.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string[]> $fields Section id => control ids.
	 *
	 * @return array<string,string[]>
	 */
	function mvweb_theme_places_field_order( $fields ) {
		$header = isset( $fields['mvweb_cz_header_blocks'] ) ? $fields['mvweb_cz_header_blocks'] : array();
		$at     = array_search( 'mvweb_zone_header_nav', $header, true );
		$at     = false === $at ? count( $header ) : $at + 1;

		array_splice( $header, $at, 0, array( 'mvweb_places_view', 'mvweb_places_where', 'mvweb_places_mobile', 'mvweb_city_places', 'mvweb_header_sticky' ) );
		$fields['mvweb_cz_header_blocks'] = $header;

		return $fields;
	}
}
add_filter( 'mvweb_core_customizer_fields', 'mvweb_theme_places_field_order' );

if ( ! function_exists( 'mvweb_theme_places_view' ) ) {
	/**
	 * The look of the strip on this page, empty when the strip is off or stands elsewhere.
	 *
	 * @since 0.1.0
	 *
	 * @return string One of line, cards, tabs, or empty.
	 */
	function mvweb_theme_places_view() {
		$view  = (string) get_theme_mod( 'mvweb_places_view', 'none' );
		$where = (string) get_theme_mod( 'mvweb_places_where', 'all' );

		if ( ! in_array( $view, array( 'line', 'cards', 'tabs' ), true ) ) {
			return '';
		}

		if ( 'home' === $where && ! is_front_page() && ! array_intersect( array( 'contacts', 'branches' ), mvweb_core_request_section_types() ) ) {
			return '';
		}

		return $view;
	}
}

if ( ! function_exists( 'mvweb_theme_places_strip' ) ) {
	/**
	 * Print the strip under the header.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_places_strip() {
		$view = mvweb_theme_places_view();

		if ( '' === $view ) {
			return;
		}

		$places = mvweb_core_header_addresses( mvweb_core_contacts() );

		if ( empty( $places ) ) {
			return;
		}

		get_template_part(
			'template-parts/header/places',
			null,
			array(
				'view'    => $view,
				'places'  => $places,
				'desktop' => 'desktop' === get_theme_mod( 'mvweb_places_where', 'all' ),
				'mobile'  => in_array( get_theme_mod( 'mvweb_places_mobile', 'list' ), array( 'list', 'select', 'stepper', 'open' ), true ) ? get_theme_mod( 'mvweb_places_mobile', 'list' ) : 'list',
			)
		);
	}
}

if ( ! function_exists( 'mvweb_theme_places_modules' ) ) {
	/**
	 * Load the script of the status on the pages with the strip.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules File names without extension, from assets/js/.
	 *
	 * @return string[]
	 */
	function mvweb_theme_places_modules( $modules ) {
		if ( '' !== mvweb_theme_places_view() || mvweb_core_zone_has( 'header-main', 'places' ) || mvweb_core_zone_has( 'header-main', 'store' ) || ( get_theme_mod( 'mvweb_city_places', false ) && mvweb_core_has_city_choice() ) ) {
			$modules[] = 'branch-status';
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_theme_places_modules' );

if ( ! function_exists( 'mvweb_theme_place_name' ) ) {
	/**
	 * The name of a place: its title, else its street.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $place A place of the contacts.
	 *
	 * @return string
	 */
	function mvweb_theme_place_name( array $place ) {
		$title = trim( (string) $place['title'] );

		return '' !== $title ? $title : trim( (string) $place['address'] );
	}
}

if ( ! function_exists( 'mvweb_theme_place_status' ) ) {
	/**
	 * The empty status of a place the script fills from its hours: "Open until 20:00", or "until 20:00" when short.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $place A place of the contacts.
	 * @param bool                $short Whether the words are short.
	 *
	 * @return string Markup, empty when the hours cannot be read.
	 */
	function mvweb_theme_place_status( array $place, $short = false ) {
		$attrs = mvweb_core_branch_status_attrs( $place );

		if ( '' === $attrs ) {
			return '';
		}

		if ( $short && preg_match( '/data-branch-status="([^"]*)"/', $attrs, $match ) ) {
			$data         = json_decode( html_entity_decode( $match[1], ENT_QUOTES ), true );
			$data['text'] = array(
				/* translators: %s: closing time, for example 21:00. */
				'open'     => __( 'until %s', 'brand-market' ),
				'round'    => __( 'around the clock', 'brand-market' ),
				/* translators: %s: opening time, for example 8:00. */
				'today'    => __( 'opens at %s', 'brand-market' ),
				/* translators: %s: opening time, for example 8:00. */
				'tomorrow' => __( 'tomorrow from %s', 'brand-market' ),
				/* translators: 1: short name of the day, 2: opening time. */
				'later'    => __( '%1$s from %2$s', 'brand-market' ),
				'closed'   => __( 'closed', 'brand-market' ),
			);
			$attrs        = ' data-branch-status="' . esc_attr( (string) wp_json_encode( $data ) ) . '"';
		}

		return '<span class="mvweb-t-places__st"' . $attrs . ' hidden></span>';
	}
}

if ( ! function_exists( 'mvweb_theme_place_route' ) ) {
	/**
	 * The link "Route" of a place.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $place A place of the contacts.
	 *
	 * @return string Markup, empty without a link.
	 */
	function mvweb_theme_place_route( array $place ) {
		$url = '' !== $place['route_url'] ? $place['route_url'] : $place['map_link'];

		if ( '' === $url ) {
			return '';
		}

		return '<a class="mvweb-t-places__route" href="' . esc_url( $url ) . '" target="_blank" rel="noopener">' . esc_html__( 'Route', 'brand-market' ) . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>';
	}
}

if ( ! function_exists( 'mvweb_theme_places_pop' ) ) {
	/**
	 * The window with the list of places that a button opens.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $places Places of the contacts.
	 * @param string                         $id     Id of the window, the button points to it.
	 *
	 * @return string
	 */
	function mvweb_theme_places_pop( array $places, $id ) {
		return '<div class="mvweb-t-city__pop mvweb-t-hc__places-pop" id="' . esc_attr( $id ) . '" data-places-pop hidden>' . mvweb_theme_places_items( $places ) . '</div>';
	}
}

if ( ! function_exists( 'mvweb_theme_places_items' ) ) {
	/**
	 * The list of places with the address, how to find it, the hours, the status and the route.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $places Places of the contacts.
	 * @param bool                           $pick   Whether each place has the button that makes it the chosen one.
	 *
	 * @return string
	 */
	function mvweb_theme_places_items( array $places, $pick = false ) {
		$html = '<ul class="mvweb-t-hc__places-list">';

		foreach ( $places as $i => $place ) {
			$hours = mvweb_core_hours_line( $place['hours'] );
			$note  = trim( (string) $place['note'] );
			$html .= $pick ? '<li class="mvweb-t-hc__place" data-store-item="' . esc_attr( mvweb_theme_place_name( $place ) . ' ' . trim( (string) $place['address'] ) ) . '">' : '<li class="mvweb-t-hc__place">';
			$html .= '' !== trim( (string) $place['title'] ) ? '<b>' . esc_html( mvweb_theme_place_name( $place ) ) . '</b>' : '';
			$html .= '<span>' . esc_html( trim( (string) $place['address'] ) ) . '</span>';
			$html .= '' !== $note ? '<small>' . esc_html( $note ) . '</small>' : '';
			$html .= '' !== $hours ? '<small>' . esc_html( $hours ) . '</small>' : '';
			$html .= '<span class="mvweb-t-places__row">' . mvweb_theme_place_status( $place ) . mvweb_theme_place_route( $place ) . '</span>';

			if ( $pick ) {
				$html .= '<span class="mvweb-t-el-store__mine" data-store-mine' . ( $i ? ' hidden' : '' ) . '>' . mvweb_theme_icon( 'check', array( 'class' => 'mvweb-t-icon--sm' ) ) . esc_html__( 'Your service centre', 'brand-market' ) . '</span>';
				$html .= '<button class="mvweb-t-btn mvweb-t-btn--sm mvweb-t-btn--outline mvweb-t-el-store__pick" type="button" data-store-pick' . ( $i ? '' : ' hidden' ) . '>' . esc_html__( 'Choose this one', 'brand-market' ) . '</button>';
			}

			$html .= '</li>';
		}

		return $html . '</ul>';
	}
}

if ( ! function_exists( 'mvweb_theme_header_sticky_class' ) ) {
	/**
	 * Mark the header that stays on top while scrolling.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $classes Class names of the header.
	 *
	 * @return string[]
	 */
	function mvweb_theme_header_sticky_class( $classes ) {
		if ( get_theme_mod( 'mvweb_header_sticky', false ) ) {
			$classes[] = 'mvweb-t-header--sticky';
		}

		return $classes;
	}
}
add_filter( 'mvweb_theme_header_class', 'mvweb_theme_header_sticky_class' );
