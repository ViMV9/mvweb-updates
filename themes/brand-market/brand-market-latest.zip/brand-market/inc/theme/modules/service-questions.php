<?php
/**
 * Questions and answers on the pages of the services and of their sections.
 *
 * A visitor asks under a service or a section, the site answers. They are the
 * comments of WordPress, so moderation, Akismet and the answers from the admin
 * work as they do anywhere. A section is a term and a comment needs a post: the
 * questions of a section are kept on a hidden post of its own, made on the first
 * visit of the section while the questions are on, with no author so that no
 * visitor gets the rights of one; it goes with the section. A visitor gets a
 * letter when the site answers.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_questions_on' ) ) {
	/**
	 * Whether the services and the sections take questions.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_theme_questions_on() {
		return (bool) get_theme_mod( 'mvweb_service_questions', false );
	}
}

if ( ! function_exists( 'mvweb_theme_questions_types' ) ) {
	/**
	 * Post types whose comments are questions.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_theme_questions_types() {
		return array( 'mv_service', 'mv_service_ask' );
	}
}

if ( ! function_exists( 'mvweb_theme_questions_register' ) ) {
	/**
	 * Register the hidden post that keeps the questions of a section.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_questions_register() {
		register_post_type(
			'mv_service_ask',
			array(
				'labels'              => array(
					'name'          => __( 'Questions of the sections', 'brand-market' ),
					'singular_name' => __( 'Questions of a section', 'brand-market' ),
				),
				'public'              => false,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_ui'             => false,
				'show_in_rest'        => false,
				'rewrite'             => false,
				'query_var'           => false,
				'supports'            => array( 'title', 'comments' ),
			)
		);
	}
}
add_action( 'init', 'mvweb_theme_questions_register' );

if ( ! function_exists( 'mvweb_theme_questions_fields' ) ) {
	/**
	 * The switch of the questions in the section of the service page.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Customizer Kit.
	 *
	 * @return void
	 */
	function mvweb_theme_questions_fields( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'toggle',
					'settings'    => 'mvweb_service_questions',
					'section'     => 'mvweb_cz_services_page',
					'label'       => __( 'Questions and answers', 'brand-market' ),
					'description' => __( 'Visitors ask under every service and section, the answers come from Comments in the admin. The visitor gets a letter when the site answers. Settings → Discussion decide on moderation and on the letters to the admin.', 'brand-market' ),
					'default'     => false,
					'priority'    => 40,
				),
			)
		);
	}
}
add_action( 'mvweb_cz_register', 'mvweb_theme_questions_fields' );

if ( ! function_exists( 'mvweb_theme_questions_post' ) ) {
	/**
	 * The post that keeps the questions of the current page: the service itself, or the hidden post of the section, made when missing.
	 *
	 * @since 0.1.0
	 *
	 * @return int Zero when the page takes no questions.
	 */
	function mvweb_theme_questions_post() {
		if ( ! mvweb_theme_questions_on() ) {
			return 0;
		}

		if ( is_singular( 'mv_service' ) ) {
			return (int) get_queried_object_id();
		}

		if ( ! is_tax( 'mv_service_cat' ) ) {
			return 0;
		}

		$term  = get_queried_object();
		$found = get_posts(
			array(
				'post_type'        => 'mv_service_ask',
				'post_status'      => 'publish',
				'numberposts'      => 1,
				'fields'           => 'ids',
				'suppress_filters' => false,
				'meta_key'         => '_mvweb_term', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- One post per section, read once per page.
				'meta_value'       => $term->term_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- One post per section, read once per page.
			)
		);

		if ( ! empty( $found ) ) {
			return (int) $found[0];
		}

		$id = wp_insert_post(
			array(
				'post_type'      => 'mv_service_ask',
				'post_status'    => 'publish',
				'post_author'    => 0,
				'post_title'     => $term->name,
				'comment_status' => 'open',
				'ping_status'    => 'closed',
				'meta_input'     => array( '_mvweb_term' => $term->term_id ),
			)
		);

		return is_wp_error( $id ) ? 0 : (int) $id;
	}
}

if ( ! function_exists( 'mvweb_theme_questions_open' ) ) {
	/**
	 * Open the questions of the services and the sections by the switch, whatever each service keeps.
	 *
	 * @since 0.1.0
	 *
	 * @param bool $open    Whether the comments are open.
	 * @param int  $post_id Post ID.
	 *
	 * @return bool
	 */
	function mvweb_theme_questions_open( $open, $post_id ) {
		return in_array( get_post_type( $post_id ), mvweb_theme_questions_types(), true ) ? mvweb_theme_questions_on() : $open;
	}
}
add_filter( 'comments_open', 'mvweb_theme_questions_open', 10, 2 );

if ( ! function_exists( 'mvweb_theme_questions_link' ) ) {
	/**
	 * The address of the hidden post of a section is the address of the section: the return after a question, the links in the admin and in the letters.
	 *
	 * @since 0.1.0
	 *
	 * @param string  $url  Address.
	 * @param WP_Post $post Post.
	 *
	 * @return string
	 */
	function mvweb_theme_questions_link( $url, $post ) {
		if ( 'mv_service_ask' !== $post->post_type ) {
			return $url;
		}

		$term = get_term_link( absint( get_post_meta( $post->ID, '_mvweb_term', true ) ), 'mv_service_cat' );

		return is_string( $term ) ? $term : $url;
	}
}
add_filter( 'post_type_link', 'mvweb_theme_questions_link', 10, 2 );

if ( ! function_exists( 'mvweb_theme_questions_forget' ) ) {
	/**
	 * Remove the hidden post of a deleted section with its questions.
	 *
	 * @since 0.1.0
	 *
	 * @param int $term_id Term ID.
	 *
	 * @return void
	 */
	function mvweb_theme_questions_forget( $term_id ) {
		$found = get_posts(
			array(
				'post_type'   => 'mv_service_ask',
				'post_status' => 'any',
				'numberposts' => -1,
				'fields'      => 'ids',
				'meta_key'    => '_mvweb_term', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Runs once, when a section is deleted.
				'meta_value'  => (int) $term_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Runs once, when a section is deleted.
			)
		);

		foreach ( $found as $id ) {
			wp_delete_post( (int) $id, true );
		}
	}
}
add_action( 'delete_mv_service_cat', 'mvweb_theme_questions_forget' );

if ( ! function_exists( 'mvweb_theme_questions_staff' ) ) {
	/**
	 * Whether a comment is an answer of the site: written by a user who moderates the comments.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Comment $comment Comment.
	 *
	 * @return bool
	 */
	function mvweb_theme_questions_staff( $comment ) {
		return $comment->user_id > 0 && user_can( (int) $comment->user_id, 'moderate_comments' );
	}
}

if ( ! function_exists( 'mvweb_theme_questions_notify' ) ) {
	/**
	 * Write to the visitor when the site answers the question, once, when the answer is on the site.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Comment|int $comment Comment or its ID.
	 *
	 * @return void
	 */
	function mvweb_theme_questions_notify( $comment ) {
		$comment = get_comment( $comment );

		if ( ! $comment || '1' !== (string) $comment->comment_approved || 0 === (int) $comment->comment_parent ) {
			return;
		}

		if ( ! in_array( get_post_type( (int) $comment->comment_post_ID ), mvweb_theme_questions_types(), true ) || ! mvweb_theme_questions_staff( $comment ) ) {
			return;
		}

		$asked = get_comment( (int) $comment->comment_parent );

		if ( ! $asked || mvweb_theme_questions_staff( $asked ) || ! is_email( $asked->comment_author_email ) || get_comment_meta( (int) $comment->comment_ID, '_mvweb_notified', true ) ) {
			return;
		}

		$site = wp_specialchars_decode( (string) get_option( 'blogname' ), ENT_QUOTES );
		$body = array(
			/* translators: %s: name of the visitor. */
			sprintf( __( 'Hello, %s!', 'brand-market' ), $asked->comment_author ),
			'',
			__( 'Your question:', 'brand-market' ),
			wp_strip_all_tags( $asked->comment_content ),
			'',
			__( 'The answer:', 'brand-market' ),
			wp_strip_all_tags( $comment->comment_content ),
			'',
			/* translators: %s: address of the answer. */
			sprintf( __( 'The question and the answer on the site: %s', 'brand-market' ), get_comment_link( $comment ) ),
		);

		if ( wp_mail(
			$asked->comment_author_email,
			/* translators: %s: name of the site. */
			sprintf( __( 'An answer to your question on %s', 'brand-market' ), $site ),
			implode( "\n", $body )
		) ) {
			update_comment_meta( (int) $comment->comment_ID, '_mvweb_notified', 1 );
		}
	}
}
add_action(
	'comment_post',
	static function ( $id ) {
		mvweb_theme_questions_notify( (int) $id );
	}
);
add_action(
	'comment_unapproved_to_approved',
	static function ( $comment ) {
		mvweb_theme_questions_notify( $comment );
	}
);

if ( ! function_exists( 'mvweb_theme_questions_mark' ) ) {
	/**
	 * The mark of the site beside an answer: the site icon, else the first letter of its name.
	 *
	 * @since 0.1.0
	 *
	 * @return string Markup.
	 */
	function mvweb_theme_questions_mark() {
		$icon = get_site_icon_url( 80 );

		if ( '' !== $icon ) {
			return '<img src="' . esc_url( $icon ) . '" alt="" width="40" height="40" loading="lazy" decoding="async">';
		}

		return esc_html( mb_strtoupper( mvweb_core_initials( (string) get_option( 'blogname' ) ) ) );
	}
}
