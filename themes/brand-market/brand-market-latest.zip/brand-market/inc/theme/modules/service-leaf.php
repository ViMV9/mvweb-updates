<?php
/**
 * The services of a section without subsections: cards or one button, before or after its text, or where the shortcode stands.
 *
 * A section whose page prints the plain grid of its services shows them as
 * cards, page by page, or behind one button that unfolds all the cards, and
 * puts them before or after the text under the listing. Both are set for every
 * such section in the Customizer and may be set again in the section itself,
 * which wins. The [mvweb_services] shortcode in the text of the section prints
 * all its services where it stands, the way the section shows them; the page
 * then prints them nowhere else. A section printed whole has no page two.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_leaf_choices' ) ) {
	/**
	 * The choices of the look and of the place of the services, with the empty one of a section that follows the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @param string $kind Either view or place.
	 *
	 * @return array<string,string> Value => label.
	 */
	function mvweb_theme_leaf_choices( $kind ) {
		if ( 'place' === $kind ) {
			return array(
				'before' => __( 'Before the text of the section', 'brand-market' ),
				'after'  => __( 'After the text of the section', 'brand-market' ),
			);
		}

		return array(
			'cards'  => __( 'Cards, page by page', 'brand-market' ),
			'button' => __( 'One button that unfolds all the cards', 'brand-market' ),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_leaf_fields' ) ) {
	/**
	 * The look and the place of the services of a section without subsections, in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Customizer Kit.
	 *
	 * @return void
	 */
	function mvweb_theme_leaf_fields( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_service_leaf_view',
					'section'     => 'mvweb_cz_services_list',
					'label'       => __( 'Services of a section without subsections', 'brand-market' ),
					'description' => __( 'A long list of models reads better behind one button. A section may choose its own.', 'brand-market' ),
					'default'     => 'cards',
					'choices'     => mvweb_theme_leaf_choices( 'view' ),
				),
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_service_leaf_place',
					'section'     => 'mvweb_cz_services_list',
					'label'       => __( 'Where the services of such a section stand', 'brand-market' ),
					'description' => __( 'A section may choose its own. The [mvweb_services] shortcode in the text of a section puts them where it stands.', 'brand-market' ),
					'default'     => 'before',
					'choices'     => mvweb_theme_leaf_choices( 'place' ),
				),
			)
		);
	}
}
add_action( 'mvweb_cz_register', 'mvweb_theme_leaf_fields' );

if ( ! function_exists( 'mvweb_theme_leaf' ) ) {
	/**
	 * How a section shows its services: the own choice of the section, else the one of the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @param int $term_id Section id.
	 *
	 * @return array{view:string,place:string,code:bool} Code tells that the text of the section holds the shortcode.
	 */
	function mvweb_theme_leaf( $term_id ) {
		$out = array();

		foreach ( array(
			'view'  => 'cards',
			'place' => 'before',
		) as $kind => $fallback ) {
			$choices = mvweb_theme_leaf_choices( $kind );
			$value   = (string) get_term_meta( $term_id, 'mvweb_leaf_' . $kind, true );

			if ( ! isset( $choices[ $value ] ) ) {
				$value = (string) get_theme_mod( 'mvweb_service_leaf_' . $kind, $fallback );
			}

			$out[ $kind ] = isset( $choices[ $value ] ) ? $value : $fallback;
		}

		$out['code'] = has_shortcode( mvweb_core_term_text( $term_id ), 'mvweb_services' );

		return $out;
	}
}

if ( ! function_exists( 'mvweb_theme_leaf_list' ) ) {
	/**
	 * All the services of a section, as cards or behind one button.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Section.
	 * @param string  $view Either cards or button.
	 *
	 * @return string Markup, empty for a section without services.
	 */
	function mvweb_theme_leaf_list( $term, $view ) {
		$ids = mvweb_core_service_ids( $term->term_id, true );

		if ( empty( $ids ) ) {
			return '';
		}

		ob_start();

		foreach ( $ids as $id ) {
			get_template_part( 'template-parts/service/card', null, array( 'id' => $id ) );
		}

		$grid = '<div class="mvweb-t-catalog__grid mvweb-t-catalog__grid--services">' . ob_get_clean() . '</div>';

		if ( 'button' !== $view ) {
			return '<div class="mvweb-t-svc-leaf">' . $grid . '</div>';
		}

		return sprintf(
			'<details class="mvweb-t-svc-leaf mvweb-t-svc-leaf--button"><summary class="mvweb-t-btn mvweb-t-svc-leaf__open">%1$s<span class="mvweb-t-svc-leaf__count">%2$s</span>%3$s</summary>%4$s</details>',
			esc_html__( 'Show all services', 'brand-market' ),
			esc_html( number_format_i18n( count( $ids ) ) ),
			mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm' ) ),
			$grid
		);
	}
}

if ( ! function_exists( 'mvweb_theme_leaf_shortcode' ) ) {
	/**
	 * The [mvweb_services] shortcode: all the services of the section being shown, the way the section shows them.
	 *
	 * @since 0.1.0
	 *
	 * @return string Markup, empty outside a section of services and in a section with subsections, whose page prints its services by itself.
	 */
	function mvweb_theme_leaf_shortcode() {
		$term = get_queried_object();

		if ( ! is_tax( 'mv_service_cat' ) || ! $term instanceof WP_Term || null !== mvweb_core_service_level() ) {
			return '';
		}

		return mvweb_theme_leaf_list( $term, mvweb_theme_leaf( $term->term_id )['view'] );
	}
}
add_shortcode( 'mvweb_services', 'mvweb_theme_leaf_shortcode' );

if ( ! function_exists( 'mvweb_theme_leaf_redirect' ) ) {
	/**
	 * Send page two and on of a section printed whole, behind the button or by the shortcode, to page one.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_leaf_redirect() {
		if ( ! is_paged() || ! is_tax( 'mv_service_cat' ) || null !== mvweb_core_service_level() ) {
			return;
		}

		$id   = (int) get_queried_object_id();
		$leaf = mvweb_theme_leaf( $id );

		if ( 'button' !== $leaf['view'] && ! $leaf['code'] ) {
			return;
		}

		$url = get_term_link( $id, 'mv_service_cat' );

		if ( is_string( $url ) ) {
			wp_safe_redirect( $url, 301 );
			exit;
		}
	}
}
add_action( 'template_redirect', 'mvweb_theme_leaf_redirect' );

if ( ! function_exists( 'mvweb_theme_leaf_term_fields' ) ) {
	/**
	 * The own look and place of the services, on the form that edits a section, with the shortcode at hand.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term $term Term being edited.
	 *
	 * @return void
	 */
	function mvweb_theme_leaf_term_fields( $term ) {
		wp_nonce_field( 'mvweb_service_leaf', 'mvweb_service_leaf_nonce' );

		$labels = array(
			'view'  => __( 'Services of this section', 'brand-market' ),
			'place' => __( 'Where the services stand', 'brand-market' ),
		);

		foreach ( $labels as $kind => $label ) :
			$value = (string) get_term_meta( $term->term_id, 'mvweb_leaf_' . $kind, true );
			?>
			<tr class="form-field">
				<th scope="row"><label for="mvweb-leaf-<?php echo esc_attr( $kind ); ?>"><?php echo esc_html( $label ); ?></label></th>
				<td>
					<select id="mvweb-leaf-<?php echo esc_attr( $kind ); ?>" name="mvweb_leaf_<?php echo esc_attr( $kind ); ?>">
						<option value=""><?php esc_html_e( 'As set for every section', 'brand-market' ); ?></option>
						<?php foreach ( mvweb_theme_leaf_choices( $kind ) as $key => $choice ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>"<?php selected( $value, $key ); ?>><?php echo esc_html( $choice ); ?></option>
						<?php endforeach; ?>
					</select>
					<?php if ( 'place' === $kind ) : ?>
						<p class="description">
							<?php
							printf(
								/* translators: %s: the shortcode. */
								esc_html__( 'For a section without subsections. To put the services elsewhere in the text under the listing, for example after the second paragraph, write %s there on its own line: the services then stand only there.', 'brand-market' ),
								'<code>[mvweb_services]</code>'
							);
							?>
						</p>
					<?php endif; ?>
				</td>
			</tr>
			<?php
		endforeach;
	}
}
add_action( 'mv_service_cat_edit_form_fields', 'mvweb_theme_leaf_term_fields', 20 );

if ( ! function_exists( 'mvweb_theme_leaf_term_save' ) ) {
	/**
	 * Store the own look and place of the services of a section.
	 *
	 * @since 0.1.0
	 *
	 * @param int $term_id Term id.
	 *
	 * @return void
	 */
	function mvweb_theme_leaf_term_save( $term_id ) {
		if ( ! isset( $_POST['mvweb_service_leaf_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mvweb_service_leaf_nonce'] ) ), 'mvweb_service_leaf' ) || ! current_user_can( 'manage_categories' ) ) {
			return;
		}

		foreach ( array( 'view', 'place' ) as $kind ) {
			$value = isset( $_POST[ 'mvweb_leaf_' . $kind ] ) ? sanitize_key( wp_unslash( $_POST[ 'mvweb_leaf_' . $kind ] ) ) : '';

			if ( isset( mvweb_theme_leaf_choices( $kind )[ $value ] ) ) {
				update_term_meta( $term_id, 'mvweb_leaf_' . $kind, $value );
			} else {
				delete_term_meta( $term_id, 'mvweb_leaf_' . $kind );
			}
		}
	}
}
add_action( 'edited_mv_service_cat', 'mvweb_theme_leaf_term_save' );

if ( ! function_exists( 'mvweb_theme_service_hero_layout' ) ) {
	/**
	 * The number of services under the heading of a section starts switched off: the points stay.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $layouts Layouts by area.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_service_hero_layout( $layouts ) {
		if ( isset( $layouts['service-hero'] ) ) {
			$layouts['service-hero']['off'] = array_merge( isset( $layouts['service-hero']['off'] ) ? (array) $layouts['service-hero']['off'] : array(), array( 'count' ) );
		}

		return $layouts;
	}
}
add_filter( 'mvweb_core_layouts', 'mvweb_theme_service_hero_layout', 21 );
