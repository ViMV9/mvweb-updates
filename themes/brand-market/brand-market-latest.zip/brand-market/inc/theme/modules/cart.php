<?php
/**
 * The cart, the checkout, the order received page and the side cart as the theme draws them.
 *
 * WooCommerce prints these pages from its own templates; this module takes the
 * default output off its hooks, hands the cart and the checkout a page template
 * with a heading of their own and dresses the fields of the forms in the
 * classes of the theme. Loaded only with WooCommerce.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WooCommerce' ) ) {
	return;
}

if ( ! function_exists( 'mvweb_theme_cart_unhook' ) ) {
	/**
	 * Take the default output of the cart and the checkout off its hooks.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_cart_unhook() {
		remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cross_sell_display' );
		remove_action( 'woocommerce_cart_collaterals', 'woocommerce_cart_totals', 10 );
		remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_login_form', 10 );
		remove_action( 'woocommerce_before_checkout_form', 'woocommerce_checkout_coupon_form', 10 );
		remove_action( 'woocommerce_checkout_order_review', 'woocommerce_checkout_payment', 20 );
		remove_action( 'woocommerce_thankyou', 'woocommerce_order_details_table', 10 );
		remove_action( 'woocommerce_order_details_after_order_table', 'woocommerce_order_again_button' );
		remove_action( 'woocommerce_cart_is_empty', 'wc_empty_cart_message', 10 );

		if ( WC()->checkout() ) {
			remove_action( 'woocommerce_checkout_billing', array( WC()->checkout(), 'checkout_form_billing' ) );
			remove_action( 'woocommerce_checkout_shipping', array( WC()->checkout(), 'checkout_form_shipping' ) );
		}
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_cart_unhook', 20 );

if ( ! function_exists( 'mvweb_theme_shop_page_here' ) ) {
	/**
	 * Whether this request is a page of the cart, of the checkout or of the account.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_theme_shop_page_here() {
		return mvweb_core_cart_page_here() || mvweb_core_account_active();
	}
}

add_filter( 'woocommerce_enqueue_styles', '__return_empty_array' );

if ( ! function_exists( 'mvweb_theme_cart_plain_selects' ) ) {
	/**
	 * Keep the country and the region as plain selects, in the field classes of the theme.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_cart_plain_selects() {
		if ( mvweb_theme_shop_page_here() ) {
			wp_dequeue_script( 'selectWoo' );
			wp_dequeue_style( 'select2' );
		}
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_theme_cart_plain_selects', 100 );

if ( ! function_exists( 'mvweb_theme_cart_template' ) ) {
	/**
	 * Give the cart, the checkout and the account the template that draws their heading.
	 *
	 * @since 0.1.0
	 *
	 * @param string $template Template WordPress has chosen.
	 *
	 * @return string
	 */
	function mvweb_theme_cart_template( $template ) {
		if ( ! is_page() ) {
			return $template;
		}

		if ( mvweb_core_account_active() ) {
			$own = locate_template( 'woocommerce/account-page.php' );
		} elseif ( mvweb_core_cart_page_here() ) {
			$own = locate_template( 'woocommerce/page-order.php' );
		} else {
			return $template;
		}

		return '' === $own ? $template : $own;
	}
}
add_filter( 'template_include', 'mvweb_theme_cart_template', 99 );

if ( ! function_exists( 'mvweb_theme_cart_field_args' ) ) {
	/**
	 * Dress a field of a WooCommerce form of the cart, the checkout or the account in the classes of the theme.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $args  Arguments of the field.
	 * @param string              $key   Name of the field.
	 * @param mixed               $value Value of the field.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_theme_cart_field_args( $args, $key, $value ) {
		unset( $key, $value );

		$account = mvweb_core_account_active();

		if ( ! $account && ! mvweb_core_cart_page_here() ) {
			return $args;
		}

		$type = isset( $args['type'] ) ? (string) $args['type'] : 'text';

		if ( in_array( $type, array( 'checkbox', 'radio', 'hidden' ), true ) ) {
			return $args;
		}

		$own     = array_map( 'strval', (array) $args['class'] );
		$classes = array( 'mvweb-t-field' );

		if ( in_array( 'form-row-wide', $own, true ) || ( $account && ! array_intersect( array( 'form-row-first', 'form-row-last' ), $own ) ) ) {
			$classes[] = 'mvweb-t-field--wide';
		}

		$args['class']       = array_values( array_unique( array_merge( $own, $classes ) ) );
		$args['label_class'] = array_values( array_unique( array_merge( (array) $args['label_class'], array( 'mvweb-t-field__label' ) ) ) );
		$args['input_class'] = array_values( array_unique( array_merge( (array) $args['input_class'], array( 'mvweb-t-field__input' ) ) ) );

		if ( $account && ! empty( $args['required'] ) ) {
			$args['custom_attributes']             = (array) $args['custom_attributes'];
			$args['custom_attributes']['required'] = 'required';
		}

		return $args;
	}
}
add_filter( 'woocommerce_form_field_args', 'mvweb_theme_cart_field_args', 20, 3 );

if ( ! function_exists( 'mvweb_theme_checkout_fields' ) ) {
	/**
	 * Put the phone beside the e-mail, pair the address fields and say what the e-mail and the note are for.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,array<string,mixed>>> $fields Fields of the checkout.
	 *
	 * @return array<string,array<string,array<string,mixed>>>
	 */
	function mvweb_theme_checkout_fields( $fields ) {
		$runs = array(
			array( 'first_name', 'last_name' ),
			array( 'phone', 'email' ),
			array( 'address_2', 'city', 'state', 'postcode' ),
		);

		foreach ( array( 'billing', 'shipping' ) as $group ) {
			foreach ( $runs as $run ) {
				$here = array();

				foreach ( $run as $name ) {
					$key = $group . '_' . $name;

					if ( isset( $fields[ $group ][ $key ] ) && 'hidden' !== ( $fields[ $group ][ $key ]['type'] ?? '' ) ) {
						$here[] = $key;
					}
				}

				foreach ( $here as $index => $key ) {
					$side = 'form-row-wide';

					if ( 1 === $index % 2 ) {
						$side = 'form-row-last';
					} elseif ( $index + 1 < count( $here ) ) {
						$side = 'form-row-first';
					}

					$own = array_diff( (array) ( $fields[ $group ][ $key ]['class'] ?? array() ), array( 'form-row-first', 'form-row-last', 'form-row-wide' ) );

					$fields[ $group ][ $key ]['class'] = array_merge( array( $side ), $own );
				}
			}
		}

		if ( isset( $fields['billing']['billing_email'] ) ) {
			$fields['billing']['billing_email']['placeholder'] = __( 'We will send the confirmation and the receipt', 'brand-market' );
		}

		if ( isset( $fields['order']['order_comments'] ) ) {
			$fields['order']['order_comments']['label']       = __( 'Wishes for the order', 'brand-market' );
			$fields['order']['order_comments']['placeholder'] = __( 'For example, call an hour before delivery', 'brand-market' );
		}

		return $fields;
	}
}
add_filter( 'woocommerce_checkout_fields', 'mvweb_theme_checkout_fields', 20 );

if ( ! function_exists( 'mvweb_theme_order_hero' ) ) {
	/**
	 * The heading strip of the cart and of the checkout.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_order_hero() {
		if ( ! WC()->cart || is_wc_endpoint_url( 'order-received' ) || is_wc_endpoint_url( 'order-pay' ) ) {
			return;
		}

		$title = mvweb_core_alt_h1();
		$title = '' === $title ? get_the_title() : $title;
		$args  = array( 'title' => $title );

		if ( is_cart() ) {
			$args['meta'] = WC()->cart->is_empty() ? array() : mvweb_core_cart_hero_meta();
		} else {
			$meta = mvweb_core_layout_html( 'checkout.hero' );

			$args['after'] = '' === $meta ? '' : '<p class="mvweb-t-page-hero__meta">' . $meta . '</p>';
		}

		get_template_part( 'template-parts/page-hero', null, $args );
	}
}

if ( ! function_exists( 'mvweb_theme_status_hero' ) ) {
	/**
	 * The heading strip of the order received page and of the payment page.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $args Arguments.
	 *
	 * @return void
	 */
	function mvweb_theme_status_hero( array $args ) {
		$state = isset( $args['state'] ) && 'fail' === $args['state'] ? 'fail' : 'ok';
		$title = isset( $args['title'] ) ? (string) $args['title'] : '';
		$lead  = isset( $args['lead'] ) ? trim( (string) $args['lead'] ) : '';
		$icon  = 'fail' === $state ? 'alert-circle' : 'check';
		?>
		<section class="mvweb-t-page-hero mvweb-t-thanks__hero">
			<div class="mvweb-t-container">
				<?php if ( mvweb_core_layout_has( 'page-hero', 'crumbs' ) ) : ?>
					<?php get_template_part( 'template-parts/crumbs' ); ?>
				<?php endif; ?>
				<span class="mvweb-t-thanks__mark mvweb-t-thanks__mark--<?php echo esc_attr( $state ); ?>"><?php echo mvweb_theme_icon( $icon ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
				<h1 class="mvweb-t-page-hero__title"><?php echo esc_html( $title ); ?></h1>
				<?php if ( '' !== $lead ) : ?>
					<p class="mvweb-t-page-hero__lead"><?php echo wp_kses_post( $lead ); ?></p>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_shipping_choices_html' ) ) {
	/**
	 * The delivery methods of the step of the checkout.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_theme_shipping_choices_html() {
		ob_start();
		get_template_part( 'template-parts/checkout/shipping-choices' );

		return trim( (string) ob_get_clean() );
	}
}

if ( ! function_exists( 'mvweb_theme_shipping_choices_fragment' ) ) {
	/**
	 * Refresh the delivery methods together with the order review.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $fragments Selector => markup.
	 *
	 * @return array<string,string>
	 */
	function mvweb_theme_shipping_choices_fragment( $fragments ) {
		$fragments['.mvweb-t-shipping-choices'] = mvweb_theme_shipping_choices_html();

		return $fragments;
	}
}
add_filter( 'woocommerce_update_order_review_fragments', 'mvweb_theme_shipping_choices_fragment' );

if ( ! function_exists( 'mvweb_theme_cart_body_class' ) ) {
	/**
	 * Mark the pages of the order flow for the stylesheet.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $classes Body classes.
	 *
	 * @return string[]
	 */
	function mvweb_theme_cart_body_class( $classes ) {
		if ( mvweb_core_cart_page_here() ) {
			$classes[] = 'mvweb-t-order-page';
		}

		return $classes;
	}
}
add_filter( 'body_class', 'mvweb_theme_cart_body_class' );
