<?php
/**
 * The page of a service with benefits and tabs.
 *
 * A look of the service page chosen in the Customizer: a small photo beside the
 * short text and the benefits, the price with its note and two buttons under
 * them, then the tabs Description, Prices, Reviews and Contacts. The benefits,
 * the button, the note beside the price and the tabs are shared by every
 * service; a service fills its own prices, reviews or contacts to replace the
 * shared ones. The contacts are those of the site unless a service or the
 * Customizer gives its own.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_service_views' ) ) {
	/**
	 * Name the looks of the service page for the look field of the core.
	 *
	 * The settings of the look with tabs show only while it is chosen.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $areas Area => section, label, views, description, only.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_service_views( $areas ) {
		$only = array( 'mvweb_service_photo_ratio', 'mvweb_service_pros', 'mvweb_service_price_note_all', 'mvweb_service_btn_text', 'mvweb_service_btn_url', 'mvweb_service_tab_prices', 'mvweb_service_tab_reviews', 'mvweb_service_tab_contacts' );

		foreach ( array_keys( mvweb_theme_service_tab_keys() ) as $key ) {
			$only[] = 'mvweb_service_tab_' . $key . '_title';
		}

		$areas['service']['views']       = array(
			'photo' => __( 'Large photo above the text', 'brand-market' ),
			'tabs'  => __( 'Benefits and tabs', 'brand-market' ),
		);
		$areas['service']['description'] = __( 'With benefits and tabs: a small photo beside the text and the benefits, the price and the buttons on the first screen, the description, prices, reviews and contacts in tabs below.', 'brand-market' );
		$areas['service']['only']        = array_fill_keys( $only, array( 'tabs' ) );

		return $areas;
	}
}
add_filter( 'mvweb_core_area_views', 'mvweb_theme_service_views' );

if ( ! function_exists( 'mvweb_theme_service_view' ) ) {
	/**
	 * The look of the service page.
	 *
	 * @since 0.1.0
	 *
	 * @return string Either photo or tabs.
	 */
	function mvweb_theme_service_view() {
		return 'tabs' === mvweb_core_area_view( 'service' ) ? 'tabs' : 'photo';
	}
}

if ( ! function_exists( 'mvweb_theme_service_code' ) ) {
	/**
	 * Clean a block of code a user pasted: shortcodes, a widget, a map.
	 *
	 * Kept as typed for a user allowed to post any markup, else only what a post
	 * may hold.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string
	 */
	function mvweb_theme_service_code( $value ) {
		$value = trim( (string) $value );

		return current_user_can( 'unfiltered_html' ) ? $value : wp_kses_post( $value );
	}
}

if ( ! function_exists( 'mvweb_theme_service_tab_keys' ) ) {
	/**
	 * The tabs in their order, with the title each has unless renamed.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Key => default title.
	 */
	function mvweb_theme_service_tab_keys() {
		return array(
			'text'     => __( 'Description', 'brand-market' ),
			'prices'   => __( 'Prices', 'brand-market' ),
			'reviews'  => __( 'Reviews', 'brand-market' ),
			'contacts' => __( 'Contacts', 'brand-market' ),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_service_page_fields' ) ) {
	/**
	 * The settings of the look with tabs in the section of the service page.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Customizer Kit.
	 *
	 * @return void
	 */
	function mvweb_theme_service_page_fields( $kit ) {
		$section = 'mvweb_cz_services_page';
		$fields  = array(
			array(
				'type'        => 'select',
				'settings'    => 'mvweb_service_photo_ratio',
				'section'     => $section,
				'label'       => __( 'Photo format', 'brand-market' ),
				'description' => __( 'The frame of the photo beside the text. The photo stands inside it whole, never stretched and never above its own size; the free space stays empty. Square suits most photos, the portrait ones a phone or a tablet.', 'brand-market' ),
				'default'     => '1-1',
				'priority'    => 1,
				'choices'     => mvweb_theme_service_photo_ratios(),
			),
			array(
				'type'        => 'repeater',
				'settings'    => 'mvweb_service_pros',
				'section'     => $section,
				'label'       => __( 'Benefits', 'brand-market' ),
				'description' => __( 'The same on every service, beside the photo. Four short lines read best: fast repair, original parts, warranty, free diagnostics.', 'brand-market' ),
				'default'     => '[]',
				'priority'    => 2,
				'fields'      => array(
					'icon' => array(
						'type'    => 'select',
						'label'   => __( 'Icon', 'brand-market' ),
						'choices' => array( '' => __( 'No icon', 'brand-market' ) ) + mvweb_core_icon_choices(),
					),
					'text' => array(
						'type'    => 'text',
						'label'   => __( 'Text', 'brand-market' ),
						'choices' => array(),
					),
				),
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_service_price_note_all',
				'section'     => $section,
				'label'       => __( 'Note beside the price', 'brand-market' ),
				'description' => __( 'The same on every service, for example: the price after diagnostics. A service with its own note shows its own.', 'brand-market' ),
				'default'     => '',
				'priority'    => 3,
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_service_btn_text',
				'section'     => $section,
				'label'       => __( 'Text of the main button', 'brand-market' ),
				'description' => __( 'Empty takes the text of the button set in Conversion.', 'brand-market' ),
				'default'     => '',
				'priority'    => 4,
			),
			array(
				'type'        => 'url',
				'settings'    => 'mvweb_service_btn_url',
				'section'     => $section,
				'label'       => __( 'Where the main button leads', 'brand-market' ),
				'description' => __( 'A page, a messenger or #anchor. Empty leads to the form of the side card when it has one, else to the address set in Conversion.', 'brand-market' ),
				'default'     => '',
				'priority'    => 5,
			),
		);
		$priority = 6;

		foreach ( mvweb_theme_service_tab_keys() as $key => $title ) {
			$fields[] = array(
				'type'     => 'text',
				'settings' => 'mvweb_service_tab_' . $key . '_title',
				'section'  => $section,
				/* translators: %s: default name of the tab. */
				'label'    => sprintf( __( 'Name of the tab “%s”', 'brand-market' ), $title ),
				'default'  => $title,
				'priority' => $priority++,
			);
		}

		$fields[] = array(
			'type'              => 'textarea',
			'settings'          => 'mvweb_service_tab_prices',
			'section'           => $section,
			'label'             => __( 'Prices for every service', 'brand-market' ),
			'description'       => __( 'A shortcode of a price table or text. A service with its own prices shows its own. Empty: the tab shows only on the services that have their own.', 'brand-market' ),
			'default'           => '',
			'priority'          => $priority++,
			'sanitize_callback' => 'mvweb_theme_service_code',
		);
		$fields[] = array(
			'type'              => 'textarea',
			'settings'          => 'mvweb_service_tab_reviews',
			'section'           => $section,
			'label'             => __( 'Reviews for every service', 'brand-market' ),
			'description'       => __( 'The code of a reviews widget, for example of Yandex Maps, or a shortcode. A service with its own reviews shows its own.', 'brand-market' ),
			'default'           => '',
			'priority'          => $priority++,
			'sanitize_callback' => 'mvweb_theme_service_code',
		);
		$fields[] = array(
			'type'              => 'textarea',
			'settings'          => 'mvweb_service_tab_contacts',
			'section'           => $section,
			'label'             => __( 'Contacts for every service', 'brand-market' ),
			'description'       => __( 'Empty shows the contacts and the map of the site. A service with its own contacts shows its own.', 'brand-market' ),
			'default'           => '',
			'priority'          => $priority,
			'sanitize_callback' => 'mvweb_theme_service_code',
		);

		$kit->add_fields( $fields );
	}
}
add_action( 'mvweb_cz_register', 'mvweb_theme_service_page_fields' );

if ( ! function_exists( 'mvweb_theme_service_photo_ratios' ) ) {
	/**
	 * The formats of the frame of the photo in the look with tabs.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Key => label.
	 */
	function mvweb_theme_service_photo_ratios() {
		return array(
			'1-1'  => __( 'Square 1:1', 'brand-market' ),
			'4-3'  => __( 'Landscape 4:3', 'brand-market' ),
			'3-2'  => __( 'Landscape 3:2', 'brand-market' ),
			'16-9' => __( 'Wide 16:9', 'brand-market' ),
			'3-4'  => __( 'Portrait 3:4', 'brand-market' ),
			'2-3'  => __( 'Portrait 2:3', 'brand-market' ),
		);
	}
}

if ( ! function_exists( 'mvweb_theme_service_photo_ratio' ) ) {
	/**
	 * The format of the frame of the photo as a CSS ratio.
	 *
	 * @since 0.1.0
	 *
	 * @return string For example "4 / 3".
	 */
	function mvweb_theme_service_photo_ratio() {
		$key = (string) get_theme_mod( 'mvweb_service_photo_ratio', '1-1' );

		return str_replace( '-', ' / ', isset( mvweb_theme_service_photo_ratios()[ $key ] ) ? $key : '1-1' );
	}
}

if ( ! function_exists( 'mvweb_theme_service_pros' ) ) {
	/**
	 * The benefits to print.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array{icon:string,text:string}>
	 */
	function mvweb_theme_service_pros() {
		$rows = json_decode( (string) get_theme_mod( 'mvweb_service_pros', '[]' ), true );
		$out  = array();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$text = isset( $row['text'] ) ? trim( (string) $row['text'] ) : '';

			if ( '' !== $text ) {
				$out[] = array(
					'icon' => isset( $row['icon'] ) ? sanitize_key( $row['icon'] ) : '',
					'text' => $text,
				);
			}
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_theme_service_button' ) ) {
	/**
	 * The text and the address of the main button.
	 *
	 * @since 0.1.0
	 *
	 * @return array{text:string,url:string} Empty strings when nothing is set.
	 */
	function mvweb_theme_service_button() {
		$text = trim( (string) get_theme_mod( 'mvweb_service_btn_text', '' ) );
		$url  = trim( (string) get_theme_mod( 'mvweb_service_btn_url', '' ) );

		if ( '' === $text ) {
			$text = trim( (string) get_theme_mod( 'mvweb_cta_text', __( 'Request a quote', 'brand-market' ) ) );
		}

		if ( '' === $url ) {
			$form = '' !== trim( (string) mvweb_core_option( 'mvweb_service_form' ) ) && mvweb_core_layout_has( 'service-aside', 'form' );
			$url  = $form ? '#mvweb-t-service-form' : trim( (string) get_theme_mod( 'mvweb_cta_url', '' ) );
		}

		return array(
			'text' => '' === $url ? '' : $text,
			'url'  => '' === $text ? '' : $url,
		);
	}
}

if ( ! function_exists( 'mvweb_theme_service_price_note' ) ) {
	/**
	 * The note beside the price: the service's own, else the shared one.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Service id.
	 *
	 * @return string
	 */
	function mvweb_theme_service_price_note( $id ) {
		$own = mvweb_core_service_price_note( $id );

		return '' !== $own ? $own : trim( (string) get_theme_mod( 'mvweb_service_price_note_all', '' ) );
	}
}

if ( ! function_exists( 'mvweb_theme_service_tabs' ) ) {
	/**
	 * The tabs of a service that have something to show.
	 *
	 * Description is the text of the service. Prices, reviews and contacts are
	 * the service's own, else the shared ones; contacts with nothing set are
	 * those of the site.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Service id.
	 *
	 * @return array<string,array{title:string,html:string}> Key => tab.
	 */
	function mvweb_theme_service_tabs( $id ) {
		static $cache = array();

		if ( isset( $cache[ $id ] ) ) {
			return $cache[ $id ];
		}

		$tabs = array();

		foreach ( mvweb_theme_service_tab_keys() as $key => $default ) {
			$title = trim( (string) get_theme_mod( 'mvweb_service_tab_' . $key . '_title', $default ) );
			$title = '' === $title ? $default : $title;

			if ( 'text' === $key ) {
				ob_start();
				get_template_part( 'template-parts/service-main/story', null, array( 'id' => $id ) );
				$html = trim( (string) ob_get_clean() );
			} else {
				$code = trim( (string) get_post_meta( $id, '_mvweb_tab_' . $key, true ) );
				$code = '' !== $code ? $code : trim( (string) get_theme_mod( 'mvweb_service_tab_' . $key, '' ) );

				if ( '' !== $code ) {
					$html = '<div class="mvweb-t-prose" data-prose>' . do_shortcode( $code ) . '</div>';
				} elseif ( 'contacts' === $key ) {
					ob_start();
					get_template_part(
						'template-parts/sections/contacts',
						null,
						array(
							'props' => array(
								'view'       => '2',
								'motion'     => 'none',
								'parts'      => array( 'phone', 'email', 'address', 'hours', 'chats', 'map' ),
								'item_parts' => array( 'icon', 'label', 'value', 'note' ),
							),
						)
					);
					$html = trim( (string) ob_get_clean() );
				} else {
					$html = '';
				}
			}

			if ( '' !== $html ) {
				$tabs[ $key ] = array(
					'title' => $title,
					'html'  => $html,
				);
			}
		}

		$cache[ $id ] = $tabs;

		return $tabs;
	}
}

if ( ! function_exists( 'mvweb_theme_service_tab_box' ) ) {
	/**
	 * Hang the box of own tabs on the service screen while the look is on.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_service_tab_box() {
		if ( 'tabs' !== mvweb_theme_service_view() ) {
			return;
		}

		add_meta_box( 'mvweb-t-service-tabs', __( 'Tabs of this service', 'brand-market' ), 'mvweb_theme_service_tab_box_html', 'mv_service', 'normal', 'default' );
	}
}
add_action( 'add_meta_boxes_mv_service', 'mvweb_theme_service_tab_box' );

if ( ! function_exists( 'mvweb_theme_service_tab_box_html' ) ) {
	/**
	 * Print the box of own tabs.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Service.
	 *
	 * @return void
	 */
	function mvweb_theme_service_tab_box_html( $post ) {
		$keys = mvweb_theme_service_tab_keys();

		wp_nonce_field( 'mvweb_t_service_tabs', 'mvweb_t_service_tabs_nonce' );
		?>
		<p class="description"><?php esc_html_e( 'The tab Description shows the text of the service. Fill a field to replace what is set for every service in Appearance → Customize → MVweb: Services → Service page; leave it empty to keep that.', 'brand-market' ); ?></p>
		<?php foreach ( array( 'prices', 'reviews', 'contacts' ) as $key ) : ?>
			<p>
				<label for="mvweb-t-tab-<?php echo esc_attr( $key ); ?>"><strong><?php echo esc_html( $keys[ $key ] ); ?></strong></label>
				<textarea class="widefat code" rows="4" id="mvweb-t-tab-<?php echo esc_attr( $key ); ?>" name="mvweb_t_tab[<?php echo esc_attr( $key ); ?>]"><?php echo esc_textarea( (string) get_post_meta( $post->ID, '_mvweb_tab_' . $key, true ) ); ?></textarea>
			</p>
		<?php endforeach; ?>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_service_tab_save' ) ) {
	/**
	 * Save the own tabs of a service.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Service id.
	 *
	 * @return void
	 */
	function mvweb_theme_service_tab_save( $post_id ) {
		if ( ! isset( $_POST['mvweb_t_service_tabs_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mvweb_t_service_tabs_nonce'] ) ), 'mvweb_t_service_tabs' ) ) {
			return;
		}

		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$sent = isset( $_POST['mvweb_t_tab'] ) && is_array( $_POST['mvweb_t_tab'] ) ? wp_unslash( $_POST['mvweb_t_tab'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Each value is cleaned below by mvweb_theme_service_code().

		foreach ( array( 'prices', 'reviews', 'contacts' ) as $key ) {
			$value = isset( $sent[ $key ] ) ? mvweb_theme_service_code( $sent[ $key ] ) : '';

			if ( '' === $value ) {
				delete_post_meta( $post_id, '_mvweb_tab_' . $key );
			} else {
				update_post_meta( $post_id, '_mvweb_tab_' . $key, wp_slash( $value ) );
			}
		}
	}
}
add_action( 'save_post_mv_service', 'mvweb_theme_service_tab_save' );

if ( ! function_exists( 'mvweb_theme_service_assets' ) ) {
	/**
	 * The sheet of the contacts block and the tabs script on a service page with tabs.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $keys Style keys or module names.
	 *
	 * @return string[]
	 */
	function mvweb_theme_service_assets( $keys ) {
		if ( ! mvweb_core_is_service() || 'tabs' !== mvweb_theme_service_view() ) {
			return $keys;
		}

		$keys[] = 'mvweb_core_style_map' === current_filter() ? 'sections/contacts' : 'tabs';

		return $keys;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_theme_service_assets', 20 );
add_filter( 'mvweb_core_module_map', 'mvweb_theme_service_assets' );
