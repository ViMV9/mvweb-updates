<?php
/**
 * Ways to pay in the footer: logos of cards, quick payments and banks.
 *
 * One list in the footer section of the Customizer: a ready logo of the theme
 * or a picture of the owner, with its name, in the order of the rows. The row
 * of logos stands under the contacts, under the logo or in the bottom line.
 * At rest every logo takes the colour of the footer text through a mask of its
 * own shape, a hover shows the logo in colour.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_payment_presets' ) ) {
	/**
	 * The ready logos of the theme.
	 *
	 * A logo whose inner details are light or dark on a coloured shape has its
	 * own mask without those details, or the shape alone would stay at rest.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array{title:string,file:string,mask:string,ratio:float}> Slug => logo.
	 */
	function mvweb_theme_payment_presets() {
		$list = array(
			'mir'         => array( __( 'Mir cards', 'brand-market' ), 'mir.svg', '', 3.33 ),
			'visa'        => array( 'Visa', 'visa.svg', '', 3.08 ),
			'mastercard'  => array( 'Mastercard', 'mastercard.svg', '', 1.62 ),
			'maestro'     => array( 'Maestro', 'maestro.svg', '', 1.29 ),
			'unionpay'    => array( 'UnionPay', 'unionpay.svg', 'unionpay-mono.png', 1.6 ),
			'sbp'         => array( __( 'Faster Payments System', 'brand-market' ), 'sbp.svg', '', 1.99 ),
			'sberpay'     => array( 'SberPay', 'sberpay.png', 'sberpay-mono.png', 2.08 ),
			'tpay'        => array( 'T-Pay', 'tpay.svg', 'tpay-mono.png', 3.39 ),
			'yandexpay'   => array( __( 'Yandex Pay', 'brand-market' ), 'yandexpay.svg', 'yandexpay-mono.png', 2.97 ),
			'yoomoney'    => array( 'ЮMoney', 'yoomoney.png', '', 4.77 ),
			'belkart'     => array( __( 'Belkart', 'brand-market' ), 'belkart.svg', '', 4.54 ),
			'erip'        => array( __( 'ERIP', 'brand-market' ), 'erip.svg', '', 2.91 ),
			'sber'        => array( __( 'Sber', 'brand-market' ), 'sber.svg', '', 6.04 ),
			'tbank'       => array( __( 'T-Bank', 'brand-market' ), 'tbank.svg', 'tbank-mono.png', 2.79 ),
			'alfabank'    => array( __( 'Alfa-Bank', 'brand-market' ), 'alfabank.svg', '', 4.98 ),
			'vtb'         => array( __( 'VTB', 'brand-market' ), 'vtb.svg', '', 2.79 ),
			'belarusbank' => array( __( 'Belarusbank', 'brand-market' ), 'belarusbank.svg', '', 11.29 ),
			'priorbank'   => array( __( 'Priorbank', 'brand-market' ), 'priorbank.svg', '', 7.67 ),
			'split'       => array( __( 'Split', 'brand-market' ), 'split.svg', '', 4.06 ),
		);
		$out  = array();

		foreach ( $list as $slug => $logo ) {
			$out[ $slug ] = array(
				'title' => $logo[0],
				'file'  => $logo[1],
				'mask'  => '' !== $logo[2] ? $logo[2] : $logo[1],
				'ratio' => $logo[3],
			);
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_theme_payment_fields' ) ) {
	/**
	 * The ways to pay in the footer section.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Customizer Kit.
	 *
	 * @return void
	 */
	function mvweb_theme_payment_fields( $kit ) {
		$choices = array( 'own' => __( 'Own logo', 'brand-market' ) );

		foreach ( mvweb_theme_payment_presets() as $slug => $logo ) {
			$choices[ $slug ] = $logo['title'];
		}

		$kit->add_fields(
			array(
				array(
					'type'        => 'heading',
					'section'     => 'mvweb_cz_footer_blocks',
					'label'       => __( 'Ways to pay', 'brand-market' ),
					'priority'    => 44,
					'collapsible' => true,
					'collapsed'   => true,
				),
				array(
					'type'        => 'repeater',
					'settings'    => 'mvweb_footer_pay',
					'section'     => 'mvweb_cz_footer_blocks',
					'label'       => __( 'Logos', 'brand-market' ),
					'description' => __( 'Cards, quick payments and banks you accept. Pick a ready logo or “Own logo” and add its picture: SVG or PNG with a transparent background. The name shows on hover and is read by screen readers; a ready logo has its own name when the field is empty. Drag the rows to change the order.', 'brand-market' ),
					'default'     => '[]',
					'priority'    => 45,
					'fields'      => array(
						'logo'  => array(
							'type'    => 'select',
							'label'   => __( 'Logo', 'brand-market' ),
							'choices' => $choices,
						),
						'image' => array(
							'type'    => 'image',
							'label'   => __( 'Own picture', 'brand-market' ),
							'choices' => array(),
						),
						'title' => array(
							'type'    => 'text',
							'label'   => __( 'Logo name', 'brand-market' ),
							'choices' => array(),
						),
					),
				),
				array(
					'type'        => 'radio',
					'settings'    => 'mvweb_footer_pay_place',
					'section'     => 'mvweb_cz_footer_blocks',
					'label'       => __( 'Where the logos stand', 'brand-market' ),
					'description' => __( 'In the bottom line the logos follow the copyright.', 'brand-market' ),
					'default'     => 'contacts',
					'priority'    => 46,
					'choices'     => array(
						'contacts' => __( 'Under the contacts', 'brand-market' ),
						'brand'    => __( 'Under the logo', 'brand-market' ),
						'bottom'   => __( 'In the bottom line', 'brand-market' ),
					),
				),
				array(
					'type'        => 'text',
					'settings'    => 'mvweb_footer_pay_caption',
					'section'     => 'mvweb_cz_footer_blocks',
					'label'       => __( 'Caption over the logos', 'brand-market' ),
					'description' => __( 'Empty: no caption. The bottom line shows none.', 'brand-market' ),
					'default'     => __( 'We accept', 'brand-market' ),
					'priority'    => 47,
				),
			)
		);
	}
}
add_action( 'mvweb_cz_register', 'mvweb_theme_payment_fields' );

if ( ! function_exists( 'mvweb_theme_payment_logos' ) ) {
	/**
	 * The logos to print, in the order of the rows.
	 *
	 * A row of an own logo without a picture is left out. A picture from another
	 * host or without transparency turns grey at rest instead of taking a mask:
	 * a mask needs the file of the site and its transparent background.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array{src:string,mask:string,title:string,ratio:float}>
	 */
	function mvweb_theme_payment_logos() {
		$presets = mvweb_theme_payment_presets();
		$base    = MVWEB_THEME_URI . '/assets/img/payments/';
		$host    = wp_parse_url( home_url(), PHP_URL_HOST );
		$out     = array();

		foreach ( mvweb_cz_get_json( 'mvweb_footer_pay' ) as $row ) {
			$slug  = isset( $row['logo'] ) ? (string) $row['logo'] : '';
			$title = isset( $row['title'] ) ? trim( (string) $row['title'] ) : '';
			$image = isset( $row['image'] ) ? absint( $row['image'] ) : 0;

			if ( isset( $presets[ $slug ] ) ) {
				$logo  = $presets[ $slug ];
				$out[] = array(
					'src'   => $base . $logo['file'],
					'mask'  => $base . $logo['mask'],
					'title' => '' !== $title ? $title : $logo['title'],
					'ratio' => $logo['ratio'],
				);
				continue;
			}

			$src = $image > 0 && wp_attachment_is_image( $image ) ? wp_get_attachment_image_src( $image, 'medium' ) : false;

			if ( ! $src ) {
				continue;
			}

			$clear = in_array( get_post_mime_type( $image ), array( 'image/png', 'image/webp', 'image/gif', 'image/avif', 'image/svg+xml' ), true );
			$out[] = array(
				'src'   => $src[0],
				'mask'  => $clear && wp_parse_url( $src[0], PHP_URL_HOST ) === $host ? $src[0] : '',
				'title' => '' !== $title ? $title : get_the_title( $image ),
				'ratio' => $src[1] > 0 && $src[2] > 0 ? round( $src[1] / $src[2], 2 ) : 3.0,
			);
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_theme_payments' ) ) {
	/**
	 * Print the row of logos when the footer keeps it in this place.
	 *
	 * @since 0.1.0
	 *
	 * @param string $place Place: contacts, brand or bottom.
	 *
	 * @return void
	 */
	function mvweb_theme_payments( $place ) {
		if ( (string) mvweb_cz_get( 'mvweb_footer_pay_place', 'contacts' ) !== $place ) {
			return;
		}

		$logos = mvweb_theme_payment_logos();

		if ( empty( $logos ) ) {
			return;
		}

		$caption = 'bottom' === $place ? '' : trim( (string) mvweb_cz_get( 'mvweb_footer_pay_caption', __( 'We accept', 'brand-market' ) ) );
		$name    = '' !== $caption ? $caption : __( 'Ways to pay', 'brand-market' );
		?>
		<div class="mvweb-t-pay mvweb-t-pay--<?php echo esc_attr( $place ); ?>">
			<?php if ( '' !== $caption ) : ?>
				<p class="mvweb-t-pay__caption"><?php echo esc_html( $caption ); ?></p>
			<?php endif; ?>
			<ul class="mvweb-t-pay__list" aria-label="<?php echo esc_attr( $name ); ?>">
				<?php foreach ( $logos as $mvweb_logo ) : ?>
					<?php
					$mvweb_style = '--mvweb-t-pay-r:' . $mvweb_logo['ratio'] . ( '' !== $mvweb_logo['mask'] ? ";--mvweb-t-pay-logo:url('" . esc_url( $mvweb_logo['mask'] ) . "')" : '' );
					?>
					<li class="mvweb-t-pay__item<?php echo '' === $mvweb_logo['mask'] ? ' mvweb-t-pay__item--plain' : ''; ?>" style="<?php echo esc_attr( $mvweb_style ); ?>">
						<img class="mvweb-t-pay__img" src="<?php echo esc_url( $mvweb_logo['src'] ); ?>" alt="<?php echo esc_attr( $mvweb_logo['title'] ); ?>" title="<?php echo esc_attr( $mvweb_logo['title'] ); ?>" width="<?php echo (int) round( 26 * $mvweb_logo['ratio'] ); ?>" height="26" loading="lazy" decoding="async">
					</li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php
	}
}
