<?php
/**
 * The account of a customer as the theme draws it. Loaded only with WooCommerce.
 *
 * WooCommerce keeps the pages and the forms; this file takes over what they
 * print around them: the template of the page with its own head and breadcrumbs,
 * the navigation, the labels, the look of the fields and of the notices, and the
 * two fields the registration form of the design adds.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WooCommerce' ) ) {
	return;
}

if ( ! function_exists( 'mvweb_theme_account_unhook' ) ) {
	/**
	 * Take the defaults of WooCommerce off the hooks the design replaces.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_account_unhook() {
		remove_action( 'woocommerce_before_customer_login_form', 'woocommerce_output_all_notices', 10 );
		remove_action( 'woocommerce_before_lost_password_form', 'woocommerce_output_all_notices', 10 );
		remove_action( 'woocommerce_before_reset_password_form', 'woocommerce_output_all_notices', 10 );
		if ( is_wc_endpoint_url( 'view-order' ) ) {
			remove_action( 'woocommerce_view_order', 'woocommerce_order_details_table', 10 );
		}
		remove_action( 'woocommerce_register_form', 'wc_registration_privacy_policy_text', 20 );
		remove_action( 'woocommerce_available_downloads', 'woocommerce_order_downloads_table', 10 );
	}
}
add_action( 'wp', 'mvweb_theme_account_unhook' );

if ( ! function_exists( 'mvweb_theme_account_scripts' ) ) {
	/**
	 * Leave out the strength meter of WooCommerce on the account.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_account_scripts() {
		if ( ! mvweb_core_account_active() ) {
			return;
		}

		wp_dequeue_script( 'wc-password-strength-meter' );
		wp_dequeue_script( 'zxcvbn-async' );
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_theme_account_scripts', 100 );
