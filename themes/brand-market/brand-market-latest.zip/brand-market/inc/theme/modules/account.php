<?php
/**
 * The account of a customer as the theme draws it. Loaded only with WooCommerce.
 *
 * WooCommerce keeps the pages and the forms; this file takes over what they
 * print around them: the template of the page with its own head and breadcrumbs,
 * the navigation, the labels, the look of the fields and of the notices, and the
 * two fields the registration form of the design adds.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WooCommerce' ) ) {
	return;
}

if ( ! function_exists( 'mvweb_theme_account_unhook' ) ) {
	/**
	 * Take the defaults of WooCommerce off the hooks the design replaces.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_account_unhook() {
		remove_action( 'woocommerce_before_customer_login_form', 'woocommerce_output_all_notices', 10 );
		remove_action( 'woocommerce_before_lost_password_form', 'woocommerce_output_all_notices', 10 );
		remove_action( 'woocommerce_before_reset_password_form', 'woocommerce_output_all_notices', 10 );
		if ( is_wc_endpoint_url( 'view-order' ) ) {
			remove_action( 'woocommerce_view_order', 'woocommerce_order_details_table', 10 );
		}
		remove_action( 'woocommerce_register_form', 'wc_registration_privacy_policy_text', 20 );
		remove_action( 'woocommerce_available_downloads', 'woocommerce_order_downloads_table', 10 );
	}
}
add_action( 'wp', 'mvweb_theme_account_unhook' );

if ( ! function_exists( 'mvweb_theme_account_scripts' ) ) {
	/**
	 * Leave out the strength meter of WooCommerce on the account.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_account_scripts() {
		if ( ! mvweb_core_account_active() ) {
			return;
		}

		wp_dequeue_script( 'wc-password-strength-meter' );
		wp_dequeue_script( 'zxcvbn-async' );
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_theme_account_scripts', 100 );

if ( ! function_exists( 'mvweb_theme_cart_quiet_offered' ) ) {
	/**
	 * Whether the shop opens the side cart on adding an item, so a customer may turn it off.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_theme_cart_quiet_offered() {
		$mods = (array) get_theme_mods();

		return mvweb_core_cart_theme_ready() && 'counter' !== ( isset( $mods['mvweb_cart_add_action'] ) ? $mods['mvweb_cart_add_action'] : 'panel' );
	}
}

if ( ! function_exists( 'mvweb_theme_cart_quiet' ) ) {
	/**
	 * Whether the signed-in customer asked not to open the side cart on adding an item.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_theme_cart_quiet() {
		return is_user_logged_in() && (bool) get_user_meta( get_current_user_id(), '_mvweb_cart_quiet', true );
	}
}

if ( ! function_exists( 'mvweb_theme_cart_quiet_mode' ) ) {
	/**
	 * Only refresh the counter for a customer who turned the side cart off; the setting of the shop stays as it is.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value What happens on adding an item.
	 *
	 * @return mixed
	 */
	function mvweb_theme_cart_quiet_mode( $value ) {
		return ! is_admin() && ! is_customize_preview() && mvweb_theme_cart_quiet() ? 'counter' : $value;
	}
}
add_filter( 'theme_mod_mvweb_cart_add_action', 'mvweb_theme_cart_quiet_mode' );

if ( ! function_exists( 'mvweb_theme_cart_quiet_save' ) ) {
	/**
	 * Store the choice of the account form. WooCommerce checks the nonce and saves the account before this runs.
	 *
	 * @since 0.1.0
	 *
	 * @param int $user_id User id.
	 *
	 * @return void
	 */
	function mvweb_theme_cart_quiet_save( $user_id ) {
		if ( ! mvweb_theme_cart_quiet_offered() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- WooCommerce checks the nonce of the account form before the hook.
		if ( empty( $_POST['mvweb_cart_quiet'] ) ) {
			delete_user_meta( $user_id, '_mvweb_cart_quiet' );
		} else {
			update_user_meta( $user_id, '_mvweb_cart_quiet', 1 );
		}
	}
}
add_action( 'woocommerce_save_account_details', 'mvweb_theme_cart_quiet_save' );
