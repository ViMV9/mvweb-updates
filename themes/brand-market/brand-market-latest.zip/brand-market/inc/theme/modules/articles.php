<?php
/**
 * Article site: the looks of the widgets of the networks and of the author, the parts the post card gets switched off.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_widget_views' ) ) {
	/**
	 * Name the looks of the widgets of the networks and of the author; the first one is the default.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,string>> $views Looks so far.
	 *
	 * @return array<string,array<string,string>>
	 */
	function mvweb_theme_widget_views( $views ) {
		$views['subscribe'] = array(
			'chats' => __( 'Buttons of the networks', 'brand-market' ),
			'dark'  => __( 'Dark card with round buttons', 'brand-market' ),
			'rows'  => __( 'List of the networks', 'brand-market' ),
		);
		$views['author']    = array(
			'center' => __( 'Card in the centre', 'brand-market' ),
			'row'    => __( 'Photo on the left', 'brand-market' ),
		);

		return $views;
	}
}
add_filter( 'mvweb_core_widget_views', 'mvweb_theme_widget_views' );

if ( ! function_exists( 'mvweb_theme_article_layouts' ) ) {
	/**
	 * The author, the comments and the views of the post card start switched off; the subscription under the article is not drawn.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $layouts Layouts by area.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_theme_article_layouts( $layouts ) {
		if ( isset( $layouts['post-after']['parts'] ) ) {
			unset( $layouts['post-after']['parts']['subscribe'] );
		}

		if ( isset( $layouts['card-post'] ) ) {
			$layouts['card-post']['off'] = array_merge( isset( $layouts['card-post']['off'] ) ? (array) $layouts['card-post']['off'] : array(), array( 'author', 'comments', 'views' ) );
		}

		return $layouts;
	}
}
add_filter( 'mvweb_core_layouts', 'mvweb_theme_article_layouts', 21 );
