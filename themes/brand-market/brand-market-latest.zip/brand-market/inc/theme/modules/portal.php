<?php
/**
 * The header view "Portal": the menu as icons on a coloured band, the search and the quick cards under it.
 *
 * The home page shows the whole band. The other pages show the whole band,
 * the row of icons only, or the header row alone with the button "All
 * services", as the owner chooses. The submenu of an icon opens as a panel
 * over the width of the band or as a list under the icon.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_portal_mode' ) ) {
	/**
	 * What the band shows on this page.
	 *
	 * @since 0.1.0
	 *
	 * @return string full, icons, row; empty when the header is not the portal.
	 */
	function mvweb_theme_portal_mode() {
		if ( 'portal' !== mvweb_core_header_view() ) {
			return '';
		}

		$inner = (string) get_theme_mod( 'mvweb_header_portal_inner', 'icons' );

		if ( is_front_page() ) {
			return 'full';
		}

		return in_array( $inner, array( 'full', 'icons', 'row' ), true ) ? $inner : 'icons';
	}
}

if ( ! function_exists( 'mvweb_theme_portal_menu' ) ) {
	/**
	 * Register the place of the quick cards.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_portal_menu() {
		register_nav_menus( array( 'portal-cards' => __( 'Quick cards under the search of the header “Portal”, up to three', 'brand-market' ) ) );
	}
}
add_action( 'after_setup_theme', 'mvweb_theme_portal_menu', 20 );

if ( ! function_exists( 'mvweb_theme_portal_fields' ) ) {
	/**
	 * The settings of the view "Portal" in the section of the header.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $fields Fields of the Customizer.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_theme_portal_fields( $fields ) {
		$only = array(
			array(
				'setting'  => 'mvweb_header_layout',
				'operator' => '==',
				'value'    => 'portal',
			),
		);

		$fields[] = array(
			'type'        => 'radio',
			'settings'    => 'mvweb_header_portal_inner',
			'section'     => 'mvweb_cz_header_blocks',
			'label'       => __( 'The band on the other pages', 'brand-market' ),
			'description' => __( 'The home page always shows the whole band: icons, search and quick cards.', 'brand-market' ),
			'default'     => 'icons',
			'required'    => $only,
			'choices'     => array(
				'icons' => __( 'Row of icons only', 'brand-market' ),
				'row'   => __( 'No band: the button of the menu and the search in the header row', 'brand-market' ),
				'full'  => __( 'The whole band, as on the home page', 'brand-market' ),
			),
		);

		$fields[] = array(
			'type'        => 'radio',
			'settings'    => 'mvweb_header_portal_sub',
			'section'     => 'mvweb_cz_header_blocks',
			'label'       => __( 'Submenu of an icon', 'brand-market' ),
			'description' => __( 'The items under an icon in “Appearance → Menus”: the second level are the columns, the third the links.', 'brand-market' ),
			'default'     => 'panel',
			'required'    => $only,
			'choices'     => array(
				'panel' => __( 'Panel over the width of the band', 'brand-market' ),
				'list'  => __( 'List under the icon', 'brand-market' ),
			),
		);

		$fields[] = array(
			'type'        => 'toggle',
			'settings'    => 'mvweb_header_portal_fade',
			'section'     => 'mvweb_cz_header_blocks',
			'label'       => __( 'Smooth change of the colour of the band', 'brand-market' ),
			'description' => __( 'The colour of the band is the colour of the menu strip in “Design → Colours”.', 'brand-market' ),
			'default'     => true,
			'required'    => $only,
		);

		return $fields;
	}
}
add_filter( 'mvweb_cz_baseline_fields', 'mvweb_theme_portal_fields' );

if ( ! function_exists( 'mvweb_theme_portal_field_order' ) ) {
	/**
	 * Put the settings of the portal right after the header view.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string[]> $fields Section id => control ids.
	 *
	 * @return array<string,string[]>
	 */
	function mvweb_theme_portal_field_order( $fields ) {
		$own    = array( 'mvweb_header_portal_inner', 'mvweb_header_portal_sub', 'mvweb_header_portal_fade' );
		$header = isset( $fields['mvweb_cz_header_blocks'] ) ? array_values( array_diff( $fields['mvweb_cz_header_blocks'], $own ) ) : array();
		$at     = array_search( 'mvweb_header_layout', $header, true );

		array_splice( $header, false === $at ? 0 : $at + 1, 0, $own );
		$fields['mvweb_cz_header_blocks'] = $header;

		return $fields;
	}
}
add_filter( 'mvweb_core_customizer_fields', 'mvweb_theme_portal_field_order' );

if ( ! function_exists( 'mvweb_theme_portal_header_class' ) ) {
	/**
	 * The classes of the header that tell the stylesheet what the band shows.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $classes Class names.
	 *
	 * @return string[]
	 */
	function mvweb_theme_portal_header_class( $classes ) {
		$mode = mvweb_theme_portal_mode();

		if ( '' === $mode ) {
			return $classes;
		}

		$classes[] = 'mvweb-t-header--portal-' . $mode;
		$classes[] = 'list' === get_theme_mod( 'mvweb_header_portal_sub', 'panel' ) ? 'mvweb-t-header--portal-list' : 'mvweb-t-header--portal-panel';

		return $classes;
	}
}
add_filter( 'mvweb_theme_header_class', 'mvweb_theme_portal_header_class' );

if ( ! function_exists( 'mvweb_theme_portal_styles' ) ) {
	/**
	 * Add the stylesheet of the portal to the pages of the view.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Handles without the theme prefix.
	 *
	 * @return string[]
	 */
	function mvweb_theme_portal_styles( $styles ) {
		if ( 'portal' === mvweb_core_header_view() ) {
			$styles[] = 'portal';
		}

		return $styles;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_theme_portal_styles' );

if ( ! function_exists( 'mvweb_theme_portal_icon' ) ) {
	/**
	 * The icon of a menu item of the band; an item without one gets the grid.
	 *
	 * @since 0.1.0
	 *
	 * @param int $item_id Menu item id.
	 *
	 * @return string Escaped markup.
	 */
	function mvweb_theme_portal_icon( $item_id ) {
		$name = mvweb_core_menu_item_icon( $item_id );

		return mvweb_theme_icon( '' === $name ? 'layout-grid' : $name );
	}
}

if ( ! function_exists( 'mvweb_theme_portal_sub' ) ) {
	/**
	 * The submenu of an icon: the children with their own children are columns, the others one list of links before them.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,WP_Post[]> $tree Items grouped by parent.
	 * @param WP_Post              $top  The icon.
	 *
	 * @return void
	 */
	function mvweb_theme_portal_sub( array $tree, $top ) {
		$columns = array();
		$links   = array();

		foreach ( $tree[ $top->ID ] as $mvweb_child ) {
			if ( empty( $tree[ $mvweb_child->ID ] ) ) {
				$links[] = $mvweb_child;
			} else {
				$columns[] = $mvweb_child;
			}
		}
		?>
		<div class="mvweb-t-portal__sub" data-nav-sub>
			<div class="mvweb-t-portal__sub-head">
				<span class="mvweb-t-portal__sub-title"><?php echo esc_html( $top->title ); ?></span>
				<?php if ( mvweb_core_menu_url_is_real( $top->url ) ) : ?>
					<a class="mvweb-t-portal__sub-all" href="<?php echo esc_url( $top->url ); ?>">
						<?php esc_html_e( 'All of the section', 'brand-market' ); ?>
						<?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
					</a>
				<?php endif; ?>
			</div>

			<div class="mvweb-t-portal__cols">
				<?php if ( ! empty( $links ) ) : ?>
					<ul class="mvweb-t-portal__col mvweb-t-portal__col--links">
						<?php foreach ( $links as $mvweb_link ) : ?>
							<li><a class="mvweb-t-portal__sub-link" <?php echo mvweb_core_menu_href( $mvweb_link->url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped attributes. ?><?php echo mvweb_core_menu_current( $mvweb_link ) ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $mvweb_link->title ); ?></a></li>
						<?php endforeach; ?>
					</ul>
				<?php endif; ?>

				<?php foreach ( $columns as $mvweb_column ) : ?>
					<div class="mvweb-t-portal__col">
						<a class="mvweb-t-portal__col-title" <?php echo mvweb_core_menu_href( $mvweb_column->url, false ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped attributes. ?>><?php echo esc_html( $mvweb_column->title ); ?></a>
						<ul class="mvweb-t-portal__col-list">
							<?php foreach ( $tree[ $mvweb_column->ID ] as $mvweb_link ) : ?>
								<li><a class="mvweb-t-portal__sub-link" <?php echo mvweb_core_menu_href( $mvweb_link->url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped attributes. ?><?php echo mvweb_core_menu_current( $mvweb_link ) ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $mvweb_link->title ); ?></a></li>
							<?php endforeach; ?>
						</ul>
					</div>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_portal_band' ) ) {
	/**
	 * Print the band under the header row when this page shows it.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_portal_band() {
		$mode = mvweb_theme_portal_mode();

		if ( 'full' !== $mode && 'icons' !== $mode ) {
			return;
		}

		get_template_part( 'template-parts/header/portal', null, array( 'mode' => $mode ) );
	}
}
