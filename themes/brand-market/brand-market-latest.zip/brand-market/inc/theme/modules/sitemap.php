<?php
/**
 * Sitemap: the pieces of markup the looks of the map share.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_sitemap_link' ) ) {
	/**
	 * A name of the map as a link, or as plain text when it has no address.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $item  Name and url.
	 * @param string              $css Class of the link.
	 *
	 * @return string
	 */
	function mvweb_theme_sitemap_link( array $item, $css = '' ) {
		$attr = '' === $css ? '' : ' class="' . esc_attr( $css ) . '"';

		if ( empty( $item['url'] ) ) {
			return '<span' . $attr . '>' . esc_html( $item['name'] ) . '</span>';
		}

		return '<a' . $attr . ' href="' . esc_url( $item['url'] ) . '">' . esc_html( $item['name'] ) . '</a>';
	}
}

if ( ! function_exists( 'mvweb_theme_sitemap_count' ) ) {
	/**
	 * The number of entries beside a name, when the map shows the numbers.
	 *
	 * @since 0.1.0
	 *
	 * @param int $number Number.
	 *
	 * @return string
	 */
	function mvweb_theme_sitemap_count( $number ) {
		if ( (int) $number < 1 || ! mvweb_core_sitemap()['counts'] ) {
			return '';
		}

		return '<span class="mvweb-t-sitemap__n">' . esc_html( number_format_i18n( (int) $number ) ) . '</span>';
	}
}

if ( ! function_exists( 'mvweb_theme_sitemap_more' ) ) {
	/**
	 * The link to the rest of a section: «More: 12 items».
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $group Section with more and url_more.
	 *
	 * @return string Empty when nothing is left.
	 */
	function mvweb_theme_sitemap_more( array $group ) {
		if ( '' === $group['more'] || '' === $group['url_more'] ) {
			return '';
		}

		return '<a class="mvweb-t-sitemap__more" href="' . esc_url( $group['url_more'] ) . '">' . esc_html( $group['more'] ) . mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ) . '</a>';
	}
}

if ( ! function_exists( 'mvweb_theme_sitemap_icon' ) ) {
	/**
	 * The icon of a kind of the map in its coloured box.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $type Kind of the map.
	 *
	 * @return string
	 */
	function mvweb_theme_sitemap_icon( array $type ) {
		return '<span class="mvweb-t-sitemap__ico">' . mvweb_theme_icon( (string) $type['icon'] ) . '</span>';
	}
}

if ( ! function_exists( 'mvweb_theme_sitemap_title' ) ) {
	/**
	 * The name of a kind of the map: a link to its whole listing when it has one.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $type  Kind of the map.
	 * @param string              $css Class of the name.
	 *
	 * @return string
	 */
	function mvweb_theme_sitemap_title( array $type, $css ) {
		return mvweb_theme_sitemap_link(
			array(
				'name' => $type['label'],
				'url'  => $type['archive'] ? $type['archive']['url'] : '',
			),
			$css
		);
	}
}
