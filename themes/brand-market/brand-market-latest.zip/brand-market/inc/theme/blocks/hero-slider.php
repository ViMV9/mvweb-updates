<?php
/**
 * Block description: first screen as a slider of offers.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Fan of cards', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Photo with a plate', 'brand-market' ),
			'class'  => 'plate',
			'motion' => 'wipe',
		),
		'3' => array(
			'label'  => __( 'Showcase with mini cards', 'brand-market' ),
			'class'  => 'showcase',
			'motion' => 'slide',
		),
		'4' => array(
			'label'  => __( 'Item on a circle', 'brand-market' ),
			'class'  => 'circle',
			'motion' => 'scale',
		),
		'5' => array(
			'label'  => __( 'Running ribbon', 'brand-market' ),
			'class'  => 'ribbon',
			'motion' => 'blur',
		),
		'6' => array(
			'label'  => __( 'Photos only', 'brand-market' ),
			'class'  => 'photos',
			'motion' => 'fade',
		),
		'7' => array(
			'label'  => __( 'Photo with text and a button', 'brand-market' ),
			'class'  => 'poster',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'slide_effect'        => array( '6', '7' ),
		'plate_clear'         => array( '2' ),
		'slides.kicker'       => array( '1', '2', '3', '4', '5', '7' ),
		'slides.title'        => array( '1', '2', '3', '4', '5', '7' ),
		'slides.accent_word'  => array( '1', '2', '3', '4', '5' ),
		'slides.text'         => array( '1', '2', '3', '4', '5', '7' ),
		'slides.facts'        => array( '1', '3', '4' ),
		'slides.button_text'  => array( '1', '2', '3', '4', '5', '7' ),
		'slides.button_url'   => array( '1', '2', '3', '4', '5', '7' ),
		'slides.button_color' => array( '7' ),
		'slides.price_label'  => array( '1', '2', '3', '4', '5' ),
		'slides.price'        => array( '1', '2', '3', '4', '5' ),
		'slides.image_1'      => array( '1' ),
		'slides.image_2'      => array( '1', '3', '4' ),
		'slides.image_3'      => array( '1', '4' ),
		'slides.photo'        => array( '2', '6', '7' ),
		'slides.photo_focus'  => array( '2', '6', '7' ),
		'slides.link'         => array( '6' ),
		'slides.text_align'   => array( '7' ),
		'slides.overlay'      => array( '7' ),
		'slides.blur'         => array( '7' ),
		'slides.products'     => array( '3', '5' ),
		'item_parts.kicker'   => array( '1', '2', '3', '4', '5', '7' ),
		'item_parts.title'    => array( '1', '2', '3', '4', '5', '7' ),
		'item_parts.lead'     => array( '1', '2', '3', '4', '5', '7' ),
		'item_parts.facts'    => array( '1', '3', '4' ),
		'item_parts.actions'  => array( '1', '2', '3', '4', '5', '7' ),
		'item_parts.pics'     => array( '1', '2', '3', '4', '6', '7' ),
		'item_parts.products' => array( '3', '5' ),
	),
);
