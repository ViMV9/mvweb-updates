<?php
/**
 * Block description: what the company is good at.
 *
 * One view for now, cards; the key 2 is the one the cards had among the
 * former views, so the blocks set to it keep it and the others fall back to it.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'2' => array(
			'label'  => __( 'Cards', 'brand-market' ),
			'class'  => 'cards',
			'motion' => 'scale',
		),
	),
	'only'  => array(
		'image'          => array(),
		'image_side'     => array(),
		'image_size'     => array(),
		'parts.image'    => array(),
		'item_parts.num' => array(),
		'cards_icon_ink' => array( '2' ),
		'mobile'         => array( '2' ),
	),
);
