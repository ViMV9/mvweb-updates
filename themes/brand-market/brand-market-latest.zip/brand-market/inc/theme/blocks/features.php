<?php
/**
 * Block description: what the company is good at.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Lines and icons', 'brand-market' ),
			'class'  => 'plain',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Cards', 'brand-market' ),
			'class'  => 'cards',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Large numbers', 'brand-market' ),
			'class'  => 'numbered',
			'motion' => 'wipe',
		),
		'4' => array(
			'label'  => __( 'Strip of facts', 'brand-market' ),
			'class'  => 'strip',
			'motion' => 'slide',
		),
		'5' => array(
			'label'  => __( 'Heading on the left', 'brand-market' ),
			'class'  => 'aside',
			'motion' => 'blur',
		),
	),
	'only'  => array(
		'image'           => array( '1', '5' ),
		'blocks.icon'     => array( '1', '2', '4', '5' ),
		'blocks.text'     => array( '1', '2', '3', '5' ),
		'parts.image'     => array( '1', '5' ),
		'item_parts.icon' => array( '1', '2', '4', '5' ),
		'item_parts.num'  => array( '3' ),
		'item_parts.text' => array( '1', '2', '3', '5' ),
		'image_side'      => array( '5' ),
		'image_size'      => array( '1', '5' ),
		'cards_bg'        => array( '2' ),
		'cards_ink'       => array( '2' ),
		'cards_icon'      => array( '2' ),
	),
);
