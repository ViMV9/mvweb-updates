<?php
/**
 * Block description: two lists side by side.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Two cards', 'brand-market' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Large marks', 'brand-market' ),
			'class'  => 'marks',
			'motion' => 'slide',
		),
		'3' => array(
			'label'  => __( 'One card', 'brand-market' ),
			'class'  => 'split',
			'motion' => 'wipe',
		),
		'4' => array(
			'label'  => __( 'Table', 'brand-market' ),
			'class'  => 'table',
			'motion' => 'blur',
		),
		'5' => array(
			'label'  => __( 'Tabs', 'brand-market' ),
			'class'  => 'tabs',
			'motion' => 'scale',
		),
	),
	'only'  => array(
		'left_tab'         => array( '5' ),
		'right_tab'        => array( '5' ),
		'parts.divider'    => array( '3' ),
		'item_parts.count' => array( '2', '5' ),
	),
);
