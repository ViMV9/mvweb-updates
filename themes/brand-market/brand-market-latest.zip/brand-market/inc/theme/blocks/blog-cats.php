<?php
/**
 * Block description: the categories of the blog.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Category tiles', 'brand-market' ),
			'class'  => 'tiles',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Category bands with articles', 'brand-market' ),
			'class'  => 'strip',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Knowledge index: categories and subcategories', 'brand-market' ),
			'class'  => 'index',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Colour tiles with icons', 'brand-market' ),
			'class'  => 'color',
			'motion' => 'scale',
		),
		'5' => array(
			'label'  => __( 'Category and its top articles', 'brand-market' ),
			'class'  => 'top',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'posts'     => array( '2', '5' ),
		'top_label' => array( '5' ),
	),
);
