<?php
/**
 * Block description: figures the company stands on.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Row with dividers', 'brand-market' ),
			'class'  => 'line',
			'motion' => 'wipe',
		),
		'2' => array(
			'label'  => __( 'Accent panel', 'brand-market' ),
			'class'  => 'accent',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Cards with an icon', 'brand-market' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Heading on the left', 'brand-market' ),
			'class'  => 'split',
			'motion' => 'slide',
		),
		'5' => array(
			'label'  => __( 'Rings with figures', 'brand-market' ),
			'class'  => 'rings',
			'motion' => 'blur',
		),
	),
	'only'  => array(
		'items.icon'      => array( '3' ),
		'item_parts.icon' => array( '3' ),
	),
);
