<?php
/**
 * Block description: first screen.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Photo across the screen', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Text and photo slab', 'brand-market' ),
			'class'  => 'split',
			'motion' => 'slide',
		),
		'3' => array(
			'label'  => __( 'Centred, three frames', 'brand-market' ),
			'class'  => 'center',
			'motion' => 'scale',
		),
		'4' => array(
			'label'  => __( 'Card on the photo', 'brand-market' ),
			'class'  => 'card',
			'motion' => 'wipe',
		),
		'5' => array(
			'label'  => __( 'Large type and a running line', 'brand-market' ),
			'class'  => 'type',
			'motion' => 'blur',
		),
	),
	'only'  => array(
		'trust.image'      => array( '3' ),
		'parts.plate'      => array( '2' ),
		'item_parts.image' => array( '3' ),
		'image_side'       => array( '2' ),
		'image_size'       => array( '2' ),
		'image'            => array( '1', '2', '4' ),
		'video'            => array( '1' ),
		'slides'           => array( '1' ),
		'slide_effect'     => array( '1' ),
		'slide_interval'   => array( '1' ),
		'plate_title'      => array( '2' ),
		'plate_text'       => array( '2' ),
		'plate_icon'       => array( '2' ),
	),
);
