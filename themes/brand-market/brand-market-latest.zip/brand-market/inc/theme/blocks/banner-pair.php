<?php
/**
 * Block description: two promo banners side by side.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Coloured cards with pictures', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Photo banners', 'brand-market' ),
			'class'  => 'photo',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Large and small', 'brand-market' ),
			'class'  => 'asym',
			'motion' => 'slide',
		),
		'4' => array(
			'label'  => __( 'Large figure', 'brand-market' ),
			'class'  => 'number',
			'motion' => 'blur',
		),
		'5' => array(
			'label'  => __( 'Caption strip', 'brand-market' ),
			'class'  => 'strip',
			'motion' => 'wipe',
		),
	),
	'only'  => array(
		'banners.sticker'    => array( '1', '4', '5' ),
		'banners.ticker'     => array( '5' ),
		'item_parts.sticker' => array( '1', '4' ),
		'item_parts.ticker'  => array( '5' ),
	),
);
