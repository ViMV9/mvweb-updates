<?php
/**
 * Block description: questions and answers.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Heading on the left', 'brand-market' ),
			'class'  => 'side',
			'motion' => 'fade',
		),
		'2' => array(
			'label'  => __( 'Classic list', 'brand-market' ),
			'class'  => 'stack',
			'motion' => 'wipe',
		),
		'3' => array(
			'label'  => __( 'Two columns', 'brand-market' ),
			'class'  => 'cols',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Tiles with icons', 'brand-market' ),
			'class'  => 'tiles',
			'motion' => 'scale',
		),
		'5' => array(
			'label'  => __( 'Numbered list', 'brand-market' ),
			'class'  => 'num',
			'motion' => 'blur',
		),
		'6' => array(
			'label'  => __( 'Photo and questions', 'brand-market' ),
			'class'  => 'photo',
			'motion' => 'fade',
		),
	),
	'only'  => array(
		'image'            => array( '6' ),
		'image_side'       => array( '6' ),
		'image_size'       => array( '6' ),
		'items.icon'       => array( '4' ),
		'item_parts.badge' => array( '4' ),
		'item_parts.num'   => array( '5' ),
	),
);
