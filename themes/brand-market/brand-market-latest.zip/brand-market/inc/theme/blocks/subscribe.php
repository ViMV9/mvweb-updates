<?php
/**
 * Views of the block «Subscription»: the networks of the site; the theme draws no mailing form.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Accent card with the points', 'brand-market' ),
			'class'  => 'card',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Light card: the text and the networks', 'brand-market' ),
			'class'  => 'split',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Dark strip of the networks', 'brand-market' ),
			'class'  => 'strip',
			'motion' => 'slide',
		),
	),
	'only'  => array(
		'points'       => array( '1', '2' ),
		'parts.points' => array( '1', '2' ),
		'parts.form'   => array(),
	),
);
