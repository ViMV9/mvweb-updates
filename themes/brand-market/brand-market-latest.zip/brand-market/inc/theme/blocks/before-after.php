<?php
/**
 * Block description: before and after.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Classic slider', 'brand-market' ),
			'class'  => 'classic',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Two photos side by side', 'brand-market' ),
			'class'  => 'duo',
			'motion' => 'slide',
		),
		'3' => array(
			'label'  => __( 'Card with facts', 'brand-market' ),
			'class'  => 'card',
			'motion' => 'scale',
		),
		'4' => array(
			'label'  => __( 'Round lens', 'brand-market' ),
			'class'  => 'lens',
			'motion' => 'blur',
		),
		'5' => array(
			'label'  => __( 'Grid of small pairs', 'brand-market' ),
			'class'  => 'tiles',
			'motion' => 'wipe',
		),
	),
	'only'  => array(
		'pairs.facts'      => array( '3' ),
		'item_parts.facts' => array( '3' ),
	),
);
