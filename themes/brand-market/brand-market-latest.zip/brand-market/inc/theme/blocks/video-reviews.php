<?php
/**
 * Block description: video reviews.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Carousel of covers', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Wall of stories', 'brand-market' ),
			'class'  => 'wall',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Main video and a list', 'brand-market' ),
			'class'  => 'feature',
			'motion' => 'slide',
		),
		'4' => array(
			'label'  => __( 'Phone frames', 'brand-market' ),
			'class'  => 'phones',
			'motion' => 'blur',
		),
		'5' => array(
			'label'  => __( 'List with descriptions', 'brand-market' ),
			'class'  => 'list',
			'motion' => 'wipe',
		),
	),
	'only'  => array(
		'items.text'      => array( '5' ),
		'parts.nav'       => array( '1' ),
		'item_parts.text' => array( '5' ),
		'item_parts.cta'  => array( '5' ),
	),
);
