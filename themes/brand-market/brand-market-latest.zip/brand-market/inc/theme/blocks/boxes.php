<?php
/**
 * Block description: boxes on sale.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Cards; one box as a banner', 'brand-market' ),
			'class'  => 'cards',
			'motion' => 'rise',
		),
	),
);
