<?php
/**
 * Block description: written reviews with the ratings of review sites.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Row of cards', 'brand-market' ),
			'class'  => 'rail',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Large quote', 'brand-market' ),
			'class'  => 'quote',
			'motion' => 'wipe',
		),
		'3' => array(
			'label'  => __( 'Wall of reviews', 'brand-market' ),
			'class'  => 'wall',
			'motion' => 'scale',
		),
		'4' => array(
			'label'  => __( 'Review and list', 'brand-market' ),
			'class'  => 'split',
			'motion' => 'slide',
		),
		'5' => array(
			'label'  => __( 'Running strip', 'brand-market' ),
			'class'  => 'ticker',
			'motion' => 'blur',
		),
	),
	'only'  => array(
		'ratings_title' => array( '3' ),
		'parts.nav'     => array( '1' ),
	),
);
