<?php
/**
 * Block description: the branches of the chosen city.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Cards with a photo', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'List and map', 'brand-market' ),
			'class'  => 'map',
			'motion' => 'slide',
		),
		'3' => array(
			'label'  => __( 'Table of addresses', 'brand-market' ),
			'class'  => 'table',
			'motion' => 'wipe',
		),
		'4' => array(
			'label'  => __( 'Tabs of branches', 'brand-market' ),
			'class'  => 'tabs',
			'motion' => 'blur',
		),
		'5' => array(
			'label'  => __( 'Ribbon cards', 'brand-market' ),
			'class'  => 'ribbon',
			'motion' => 'scale',
		),
	),
	'only'  => array(
		'book_text'         => array( '1', '4' ),
		'status_text'       => array( '5' ),
		'parts.map'         => array( '2' ),
		'item_parts.icon'   => array( '5' ),
		'item_parts.index'  => array( '2' ),
		'item_parts.image'  => array( '1', '3', '4' ),
		'item_parts.status' => array( '5' ),
		'item_parts.book'   => array( '1', '4' ),
	),
);
