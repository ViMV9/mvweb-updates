<?php
/**
 * Block description: where to find us and whom to call.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Tiles above the map', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Map on the left', 'brand-market' ),
			'class'  => 'map-left',
			'motion' => 'slide',
		),
		'3' => array(
			'label'  => __( 'Map in the background', 'brand-market' ),
			'class'  => 'overlay',
			'motion' => 'scale',
		),
		'4' => array(
			'label'  => __( 'Large phone', 'brand-market' ),
			'class'  => 'type',
			'motion' => 'wipe',
		),
		'5' => array(
			'label'  => __( 'Tabs of cities', 'brand-market' ),
			'class'  => 'tabs',
			'motion' => 'blur',
		),
	),
	'only'  => array(
		'chats_title'     => array( '1', '5' ),
		'chats_lead'      => array( '1' ),
		'map_title'       => array( '1', '2', '3', '5' ),
		'map_text'        => array( '1', '2', '3' ),
		'map_button'      => array( '1', '2', '3', '5' ),
		'parts.map'       => array( '1', '2', '3', '5' ),
		'item_parts.icon' => array( '1', '2', '3' ),
	),
);
