<?php
/**
 * Block description: the authors of the blog.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Grid of cards', 'brand-market' ),
			'class'  => 'grid',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'List in rows', 'brand-market' ),
			'class'  => 'rows',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Editor-in-chief large and the others', 'brand-market' ),
			'class'  => 'chief',
			'motion' => 'rise',
		),
		'4' => array(
			'label'  => __( 'Groups', 'brand-market' ),
			'class'  => 'groups',
			'motion' => 'rise',
		),
		'5' => array(
			'label'  => __( 'Cards with the latest article', 'brand-market' ),
			'class'  => 'latest',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'chief_label' => array( '3' ),
		'letter'      => array( '3' ),
		'groups'      => array( '4' ),
		'ids'         => array( '1', '2', '3', '5' ),
		'count'       => array( '1', '2', '3', '5' ),
		'link_text'   => array(),
		'link_url'    => array(),
		'button_text' => array(),
		'button_url'  => array(),
		'facts'       => array(),
		'parts.more'  => array(),
	),
);
