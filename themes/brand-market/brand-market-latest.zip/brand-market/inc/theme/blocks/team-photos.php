<?php
/**
 * Block description: the team as a wall of photographs.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Mosaic with text', 'brand-market' ),
			'class'  => '',
			'motion' => 'scale',
		),
		'2' => array(
			'label'  => __( 'Square grid', 'brand-market' ),
			'class'  => 'grid',
			'motion' => 'rise',
		),
		'3' => array(
			'label'  => __( 'Tilted collage', 'brand-market' ),
			'class'  => 'collage',
			'motion' => 'blur',
		),
		'4' => array(
			'label'  => __( 'Panoramic strip', 'brand-market' ),
			'class'  => 'panorama',
			'motion' => 'wipe',
		),
		'5' => array(
			'label'  => __( 'Group photo with dots', 'brand-market' ),
			'class'  => 'group',
			'motion' => 'slide',
		),
	),
	'only'  => array(
		'photos.pin_x'      => array( '5' ),
		'photos.pin_y'      => array( '5' ),
		'parts.group_photo' => array( '5' ),
	),
);
