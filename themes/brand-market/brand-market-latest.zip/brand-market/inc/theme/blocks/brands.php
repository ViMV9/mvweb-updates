<?php
/**
 * Block description: a wall of brand logos.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Grid of tiles', 'brand-market' ),
			'class'  => 'grid',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Running line', 'brand-market' ),
			'class'  => 'run',
			'motion' => 'fade',
		),
	),
	'only'  => array(
		'cols'        => array( '1' ),
		'cols_mobile' => array( '1' ),
		'effect'      => array( '1' ),
		'run_effect'  => array( '2' ),
		'speed'       => array( '2' ),
	),
);
