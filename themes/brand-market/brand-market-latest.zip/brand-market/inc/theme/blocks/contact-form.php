<?php
/**
 * Block description: the request form.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1' => array(
			'label'  => __( 'Card', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2' => array(
			'label'  => __( 'Colour panel', 'brand-market' ),
			'class'  => 'panel',
			'motion' => 'scale',
		),
		'3' => array(
			'label'  => __( 'Single row', 'brand-market' ),
			'class'  => 'bar',
			'motion' => 'slide',
		),
		'4' => array(
			'label'  => __( 'Two steps', 'brand-market' ),
			'class'  => 'steps',
			'motion' => 'blur',
		),
		'5' => array(
			'label'  => __( 'Form on a photo', 'brand-market' ),
			'class'  => 'photo',
			'motion' => 'wipe',
		),
	),
	'only'  => array(
		'photo'       => array( '5' ),
		'parts.photo' => array( '5' ),
	),
);
