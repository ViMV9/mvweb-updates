<?php
/**
 * Block description: the latest posts of the blog.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'views' => array(
		'1'  => array(
			'label'  => __( 'Three cards', 'brand-market' ),
			'class'  => '',
			'motion' => 'rise',
		),
		'2'  => array(
			'label'  => __( 'Large and a list', 'brand-market' ),
			'class'  => 'feature',
			'motion' => 'scale',
		),
		'3'  => array(
			'label'  => __( 'Horizontal ribbon', 'brand-market' ),
			'class'  => 'ribbon',
			'motion' => 'slide',
		),
		'4'  => array(
			'label'  => __( 'Magazine grid', 'brand-market' ),
			'class'  => 'magazine',
			'motion' => 'blur',
		),
		'5'  => array(
			'label'  => __( 'List with dates', 'brand-market' ),
			'class'  => 'dates',
			'motion' => 'wipe',
		),
		'6'  => array(
			'label'  => __( 'Main story: cover with the text on the photo', 'brand-market' ),
			'class'  => 'cover',
			'motion' => 'scale',
		),
		'7'  => array(
			'label'  => __( 'Main story: photo and a column of text', 'brand-market' ),
			'class'  => 'split',
			'motion' => 'rise',
		),
		'8'  => array(
			'label'  => __( 'Main story: large headline without a photo', 'brand-market' ),
			'class'  => 'headline',
			'motion' => 'rise',
		),
		'9'  => array(
			'label'  => __( 'Main story and three under it', 'brand-market' ),
			'class'  => 'top',
			'motion' => 'rise',
		),
		'10' => array(
			'label'  => __( 'Main stories of the day', 'brand-market' ),
			'class'  => 'daily',
			'motion' => 'rise',
		),
		'11' => array(
			'label'  => __( 'Feed: compact list by days', 'brand-market' ),
			'class'  => 'wire',
			'motion' => 'rise',
		),
		'12' => array(
			'label'  => __( 'Feed: time line', 'brand-market' ),
			'class'  => 'line',
			'motion' => 'rise',
		),
		'13' => array(
			'label'  => __( 'Feed and the main stories', 'brand-market' ),
			'class'  => 'duo',
			'motion' => 'rise',
		),
		'14' => array(
			'label'  => __( 'Feed with pictures', 'brand-market' ),
			'class'  => 'thumbs',
			'motion' => 'rise',
		),
		'15' => array(
			'label'  => __( 'Main story and a narrow feed', 'brand-market' ),
			'class'  => 'rail',
			'motion' => 'rise',
		),
	),
	'only'  => array(
		'count' => array( '1', '2', '3', '4', '5', '11', '12', '13', '14', '15' ),
	),
);
