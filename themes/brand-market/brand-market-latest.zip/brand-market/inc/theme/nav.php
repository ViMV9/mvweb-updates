<?php
/**
 * The header as the theme draws it: menus, catalogue panel, contacts, announcement.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_menu_icon' ) ) {
	/**
	 * The icon of a menu item in its box, when the owner asked for icons.
	 *
	 * @since 0.1.0
	 *
	 * @param int    $item_id Menu item id.
	 * @param string $box_class Class of the box.
	 *
	 * @return string Escaped markup, empty when the item has no icon.
	 */
	function mvweb_theme_menu_icon( $item_id, $box_class ) {
		static $names = array();

		if ( ! get_theme_mod( 'mvweb_menu_icons', true ) ) {
			return '';
		}

		if ( ! isset( $names[ $item_id ] ) ) {
			$names[ $item_id ] = mvweb_core_menu_item_icon( $item_id );
		}

		if ( '' === $names[ $item_id ] ) {
			return '';
		}

		return '<span class="' . esc_attr( $box_class ) . '">' . mvweb_theme_icon( $names[ $item_id ] ) . '</span>';
	}
}

if ( ! function_exists( 'mvweb_theme_bar_sub' ) ) {
	/**
	 * A dropdown of the menu row: the children of an item, each opening its own list to the side.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,WP_Post[]> $tree   Items grouped by parent.
	 * @param int                  $parent_id Id of the parent item.
	 * @param bool                 $flyout Whether the list opens to the side of its parent.
	 *
	 * @return void
	 */
	function mvweb_theme_bar_sub( array $tree, $parent_id, $flyout = false ) {
		?>
		<ul class="mvweb-t-nav__sub<?php echo $flyout ? ' mvweb-t-nav__sub--flyout' : ''; ?>"<?php echo $flyout ? '' : ' data-nav-sub'; ?>>
			<?php foreach ( $tree[ $parent_id ] as $mvweb_item ) : ?>
				<?php $mvweb_has = ! empty( $tree[ $mvweb_item->ID ] ); ?>
				<li class="mvweb-t-nav__sub-item<?php echo $mvweb_has ? ' mvweb-t-nav__sub-item--sub' : ''; ?><?php echo esc_attr( mvweb_core_menu_classes( $mvweb_item ) ); ?>">
					<a class="mvweb-t-nav__sub-link" <?php echo $mvweb_has || mvweb_core_menu_url_is_real( $mvweb_item->url ) ? mvweb_core_menu_href( $mvweb_item->url ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped attributes. ?><?php echo mvweb_core_menu_current( $mvweb_item ) ? ' aria-current="page"' : ''; ?><?php echo $mvweb_has ? ' aria-haspopup="true"' : ''; ?>>
						<?php echo mvweb_theme_menu_icon( $mvweb_item->ID, 'mvweb-t-nav__icon-box' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
						<span class="mvweb-t-nav__sub-text"><?php echo esc_html( $mvweb_item->title ); ?></span>
						<?php if ( $mvweb_has ) : ?>
							<?php echo mvweb_theme_icon( 'chevron-right', array( 'class' => 'mvweb-t-icon--sm mvweb-t-nav__sub-arrow' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
						<?php endif; ?>
					</a>
					<?php
					if ( $mvweb_has ) {
						mvweb_theme_bar_sub( $tree, $mvweb_item->ID, true );
					}
					?>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_bar_nav' ) ) {
	/**
	 * The menu row: items, a dropdown under an item that has children, a list to the side under a child that has its own.
	 *
	 * @since 0.1.0
	 *
	 * @param string $location    Registered menu location.
	 * @param string $extra_class Class of the element that prints the menu.
	 *
	 * @return void
	 */
	function mvweb_theme_bar_nav( $location, $extra_class = '' ) {
		$tree = mvweb_core_menu_tree( $location );

		if ( empty( $tree[0] ) ) {
			return;
		}
		?>
		<nav class="<?php echo esc_attr( trim( 'mvweb-t-nav ' . $extra_class ) ); ?>" aria-label="<?php esc_attr_e( 'Primary menu', 'brand-market' ); ?>">
			<ul class="mvweb-t-nav__list">
				<?php foreach ( $tree[0] as $mvweb_top ) : ?>
					<?php $mvweb_has = ! empty( $tree[ $mvweb_top->ID ] ); ?>
					<li class="mvweb-t-nav__item<?php echo $mvweb_has ? ' mvweb-t-nav__item--sub' : ''; ?><?php echo esc_attr( mvweb_core_menu_classes( $mvweb_top ) ); ?>"<?php echo $mvweb_has ? ' data-nav-item' : ''; ?>>
						<a class="mvweb-t-nav__link" <?php echo $mvweb_has || mvweb_core_menu_url_is_real( $mvweb_top->url ) ? mvweb_core_menu_href( $mvweb_top->url ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped attributes. ?><?php echo mvweb_core_menu_current( $mvweb_top ) ? ' aria-current="page"' : ''; ?><?php echo $mvweb_has ? ' data-nav-link aria-haspopup="true" aria-expanded="false"' : ''; ?>>
							<?php echo mvweb_theme_menu_icon( $mvweb_top->ID, 'mvweb-t-nav__icon' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
							<?php echo esc_html( $mvweb_top->title ); ?>
							<?php if ( $mvweb_has ) : ?>
								<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-icon--sm mvweb-t-nav__arrow' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
							<?php endif; ?>
						</a>
						<?php
						if ( $mvweb_has ) {
							mvweb_theme_bar_sub( $tree, $mvweb_top->ID );
						}
						?>
					</li>
				<?php endforeach; ?>
			</ul>
		</nav>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_drawer_list' ) ) {
	/**
	 * A list of the mobile menu: an item with children folds into a disclosure the browser opens, closes and announces itself.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,WP_Post[]> $tree   Items grouped by parent.
	 * @param int                  $parent_id Id of the parent item.
	 * @param WP_Post|null         $lead   The parent, when it leads somewhere and takes the first line of its own list.
	 *
	 * @return void
	 */
	function mvweb_theme_drawer_list( array $tree, $parent_id, $lead = null ) {
		$mvweb_nested = null !== $lead || 0 !== $parent_id;
		$mvweb_link   = $mvweb_nested ? 'mvweb-t-drawer__sub-link' : 'mvweb-t-drawer__link';
		$mvweb_items  = $tree[ $parent_id ];
		?>
		<ul class="<?php echo $mvweb_nested ? 'mvweb-t-drawer__sub' : 'mvweb-t-drawer__list'; ?>">
			<?php if ( null !== $lead ) : ?>
				<li class="mvweb-t-drawer__item">
					<a class="<?php echo esc_attr( $mvweb_link ); ?>" href="<?php echo esc_url( $lead->url ); ?>"<?php echo mvweb_core_menu_current( $lead ) ? ' aria-current="page"' : ''; ?>><?php echo esc_html( $lead->title ); ?></a>
				</li>
			<?php endif; ?>
			<?php foreach ( $mvweb_items as $mvweb_item ) : ?>
				<?php
				$mvweb_kids = ! empty( $tree[ $mvweb_item->ID ] );
				$mvweb_icon = mvweb_theme_menu_icon( $mvweb_item->ID, 'mvweb-t-drawer__icon' );
				?>
				<li class="mvweb-t-drawer__item<?php echo esc_attr( mvweb_core_menu_classes( $mvweb_item ) ); ?>">
					<?php if ( ! $mvweb_kids ) : ?>
						<a class="<?php echo esc_attr( $mvweb_link ); ?>" <?php echo mvweb_core_menu_url_is_real( $mvweb_item->url ) ? mvweb_core_menu_href( $mvweb_item->url ) : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped attributes. ?><?php echo mvweb_core_menu_current( $mvweb_item ) ? ' aria-current="page"' : ''; ?>>
							<?php echo $mvweb_icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
							<?php echo esc_html( $mvweb_item->title ); ?>
						</a>
					<?php else : ?>
						<details class="mvweb-t-drawer__group">
							<summary class="<?php echo esc_attr( $mvweb_link ); ?>">
								<?php echo $mvweb_icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
								<span class="mvweb-t-drawer__text"><?php echo esc_html( $mvweb_item->title ); ?></span>
								<?php echo mvweb_theme_icon( 'chevron-down', array( 'class' => 'mvweb-t-drawer__arrow' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
							</summary>
							<?php mvweb_theme_drawer_list( $tree, $mvweb_item->ID, mvweb_core_menu_url_is_real( $mvweb_item->url ) ? $mvweb_item : null ); ?>
						</details>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_drawer_nav' ) ) {
	/**
	 * A menu location in the mobile menu.
	 *
	 * @since 0.1.0
	 *
	 * @param string $location Registered menu location.
	 *
	 * @return void
	 */
	function mvweb_theme_drawer_nav( $location ) {
		$tree = mvweb_core_menu_tree( $location );

		if ( ! empty( $tree[0] ) ) {
			mvweb_theme_drawer_list( $tree, 0 );
		}
	}
}

if ( ! function_exists( 'mvweb_theme_mega_preview' ) ) {
	/**
	 * The picture beside the columns of the catalogue panel.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_mega_preview() {
		$image = absint( get_theme_mod( 'mvweb_mega_preview_image', 0 ) );

		if ( ! wp_attachment_is_image( $image ) ) {
			return;
		}

		$caption = trim( (string) get_theme_mod( 'mvweb_mega_preview_caption', '' ) );
		$url     = trim( (string) get_theme_mod( 'mvweb_mega_preview_url', '' ) );
		$tag     = '' === $url ? 'div' : 'a';
		$alt     = '' === $caption ? mvweb_core_image_alt( $image, get_bloginfo( 'name' ) ) : '';
		?>
		<<?php echo esc_html( $tag ); ?> class="mvweb-t-mega__preview"<?php echo '' === $url ? '' : ' href="' . esc_url( $url ) . '"'; ?>>
			<?php
			echo wp_get_attachment_image( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
				$image,
				'mvweb_card',
				false,
				array(
					'alt'      => $alt,
					'loading'  => 'lazy',
					'decoding' => 'async',
				)
			);
			?>
			<?php if ( '' !== $caption ) : ?>
				<span class="mvweb-t-mega__preview-cap"><?php echo esc_html( $caption ); ?></span>
			<?php endif; ?>
		</<?php echo esc_html( $tag ); ?>>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_mega_panel' ) ) {
	/**
	 * The panel of the catalogue button: sections as tabs, subsections as columns, their own children as links.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,WP_Term[]> $tree  Categories grouped by parent.
	 * @param string               $label Caption of the button, the name of the list of tabs.
	 *
	 * @return void
	 */
	function mvweb_theme_mega_panel( array $tree, $label ) {
		$id     = 'mvweb-t-mega';
		$branch = array_values(
			array_filter(
				$tree[0],
				static function ( $term ) use ( $tree ) {
					return ! empty( $tree[ $term->term_id ] );
				}
			)
		);
		$first  = empty( $branch ) ? 0 : $branch[0]->term_id;
		?>
		<div class="mvweb-t-mega" id="<?php echo esc_attr( $id ); ?>" data-nav-sub>
			<div class="mvweb-t-container mvweb-t-mega__grid">
				<div class="mvweb-t-mega__tabs" role="tablist" aria-label="<?php echo esc_attr( $label ); ?>">
					<?php foreach ( $tree[0] as $mvweb_tab ) : ?>
						<?php $mvweb_branch = ! empty( $tree[ $mvweb_tab->term_id ] ); ?>
						<a
							class="mvweb-t-mega__tab" data-mega-tab
							id="<?php echo esc_attr( $id . '-tab-' . $mvweb_tab->term_id ); ?>"
							href="<?php echo esc_url( (string) get_term_link( $mvweb_tab ) ); ?>"
							role="tab"
							aria-selected="<?php echo $first === $mvweb_tab->term_id ? 'true' : 'false'; ?>"
							<?php if ( $mvweb_branch ) : ?>
								aria-controls="<?php echo esc_attr( $id . '-panel-' . $mvweb_tab->term_id ); ?>"
							<?php endif; ?>
						>
							<?php echo esc_html( $mvweb_tab->name ); ?>
							<?php
							if ( $mvweb_branch ) {
								echo mvweb_theme_icon( 'chevron-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
							}
							?>
						</a>
					<?php endforeach; ?>
				</div>

				<div class="mvweb-t-mega__panels">
					<?php foreach ( $branch as $mvweb_tab ) : ?>
						<div
							class="mvweb-t-mega__panel" data-mega-panel
							id="<?php echo esc_attr( $id . '-panel-' . $mvweb_tab->term_id ); ?>"
							role="tabpanel"
							aria-labelledby="<?php echo esc_attr( $id . '-tab-' . $mvweb_tab->term_id ); ?>"
							<?php echo $first === $mvweb_tab->term_id ? 'data-active' : ''; ?>
						>
							<div class="mvweb-t-mega__head">
								<span class="mvweb-t-mega__title"><?php echo esc_html( $mvweb_tab->name ); ?></span>
								<a class="mvweb-t-mega__all" href="<?php echo esc_url( (string) get_term_link( $mvweb_tab ) ); ?>">
									<?php esc_html_e( 'All items of the section', 'brand-market' ); ?>
									<?php echo mvweb_theme_icon( 'arrow-right', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
								</a>
							</div>

							<div class="mvweb-t-mega__tiles">
								<?php foreach ( $tree[ $mvweb_tab->term_id ] as $mvweb_column ) : ?>
									<?php $mvweb_image = absint( get_term_meta( $mvweb_column->term_id, 'thumbnail_id', true ) ); ?>
									<div class="mvweb-t-mega__tile">
										<a class="mvweb-t-mega__tile-link" href="<?php echo esc_url( (string) get_term_link( $mvweb_column ) ); ?>">
											<span class="mvweb-t-mega__tile-media">
												<?php
												if ( wp_attachment_is_image( $mvweb_image ) ) {
													echo wp_get_attachment_image(
														$mvweb_image,
														'thumbnail',
														false,
														array(
															'alt'      => '',
															'loading'  => 'lazy',
															'decoding' => 'async',
														)
													); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core escapes the tag.
												} else {
													echo mvweb_theme_icon( 'layout-grid' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup.
												}
												?>
											</span>
											<span class="mvweb-t-mega__tile-name"><?php echo esc_html( $mvweb_column->name ); ?></span>
										</a>
										<?php if ( ! empty( $tree[ $mvweb_column->term_id ] ) ) : ?>
											<ul class="mvweb-t-mega__col-list">
												<?php foreach ( $tree[ $mvweb_column->term_id ] as $mvweb_link ) : ?>
													<li><a href="<?php echo esc_url( (string) get_term_link( $mvweb_link ) ); ?>"><?php echo esc_html( $mvweb_link->name ); ?></a></li>
												<?php endforeach; ?>
											</ul>
										<?php endif; ?>
									</div>
								<?php endforeach; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>

				<?php mvweb_theme_mega_preview(); ?>
			</div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_theme_render_grouped_zone' ) ) {
	/**
	 * A bar zone in which the elements that stand side by side share one wrapper.
	 *
	 * @since 0.1.0
	 *
	 * @param string   $zone    Zone slug.
	 * @param string[] $grouped Slugs of the elements that share a wrapper.
	 * @param string   $wrapper Class of the wrapper.
	 *
	 * @return void
	 */
	function mvweb_theme_render_grouped_zone( $zone, array $grouped, $wrapper ) {
		$group = '';

		foreach ( mvweb_core_zone_order( $zone ) as $slug ) {
			$html = mvweb_core_element_html( $zone, $slug );

			if ( '' === $html ) {
				continue;
			}

			if ( in_array( $slug, $grouped, true ) ) {
				$group .= $html;

				continue;
			}

			if ( '' !== $group ) {
				echo '<div class="' . esc_attr( $wrapper ) . '">' . $group . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped element templates.
				$group = '';
			}

			echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by the element template.
		}

		if ( '' !== $group ) {
			echo '<div class="' . esc_attr( $wrapper ) . '">' . $group . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Assembled from the escaped element templates.
		}
	}
}

if ( ! function_exists( 'mvweb_theme_render_nav_zone' ) ) {
	/**
	 * The menu row: the icon buttons that stand side by side share one capsule.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_theme_render_nav_zone() {
		if ( 'compact' === get_theme_mod( 'mvweb_header_layout', 'simple' ) ) {
			get_template_part( 'template-parts/elements/menu-button' );
		}

		mvweb_theme_render_grouped_zone( 'header-nav', array( 'search', 'compare', 'favorites', 'account', 'cart' ), 'mvweb-t-header__pill' );
	}
}

if ( ! function_exists( 'mvweb_theme_zone_html' ) ) {
	/**
	 * A zone as a string, so the wrapper of an empty one can be left out.
	 *
	 * @since 0.1.0
	 *
	 * @param string $zone Zone slug.
	 *
	 * @return string
	 */
	function mvweb_theme_zone_html( $zone ) {
		ob_start();

		if ( 'header-nav' === $zone ) {
			mvweb_theme_render_nav_zone();
		} elseif ( 'header-main' === $zone ) {
			mvweb_theme_render_grouped_zone( 'header-main', array( 'account', 'cart' ), 'mvweb-t-header__tools' );
		} else {
			mvweb_core_render_zone( $zone );
		}

		return trim( (string) ob_get_clean() );
	}
}

