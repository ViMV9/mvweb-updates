<?php
/**
 * Icons: the icon helper over the icon styles of the core.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_theme_icon' ) ) {
	/**
	 * Build an inline icon reference.
	 *
	 * @since 0.1.0
	 *
	 * @param string $name Icon name without the "mvweb-t-icon-" prefix, e.g. phone.
	 * @param array  $args Optional. 'class' extra CSS classes, 'label' the accessible name; without it the icon is hidden from assistive technology.
	 *
	 * @return string Icon HTML.
	 */
	function mvweb_theme_icon( $name, $args = array() ) {
		$name = preg_replace( '/[^a-z0-9\-]/', '', strtolower( (string) $name ) );

		if ( '' === $name ) {
			return '';
		}

		$args = wp_parse_args(
			$args,
			array(
				'class' => '',
				'label' => '',
			)
		);

		$a11y = '' !== $args['label']
			? sprintf( ' role="img" aria-label="%s"', esc_attr( $args['label'] ) )
			: ' aria-hidden="true" focusable="false"';

		return mvweb_core_icon_symbol( $name ) . sprintf(
			'<svg class="%1$s"%2$s><use href="#mvweb-t-icon-%3$s"></use></svg>',
			esc_attr( trim( 'mvweb-t-icon ' . $args['class'] ) ),
			$a11y,
			esc_attr( $name )
		);
	}
}
