document.querySelectorAll("[data-qa]").forEach(function (box) {
	var respond = box.querySelector("#respond");
	var open = box.querySelector("[data-qa-open]");
	var show = box.querySelector("[data-qa-show]");
	var parent = box.querySelector("#comment_parent");
	var target = location.hash ? document.getElementById(location.hash.slice(1)) : null;

	var unfold = function () {
		if (respond) {
			respond.classList.remove("is-closed");
		}

		if (open) {
			open.hidden = true;
		}
	};

	var more = function () {
		box.querySelectorAll("[data-qa-more]").forEach(function (card) {
			card.hidden = false;
		});

		if (show) {
			show.remove();
		}
	};

	if (respond && open && parent && "0" === parent.value) {
		respond.classList.add("is-closed");
		open.hidden = false;
		open.addEventListener("click", function () {
			var field = respond.querySelector("textarea");

			unfold();

			if (field) {
				field.focus();
			}
		});
	}

	box.addEventListener("click", function (event) {
		if (event.target.closest(".comment-reply-link")) {
			unfold();
		}
	});

	if (show) {
		box.querySelectorAll("[data-qa-more]").forEach(function (card) {
			card.hidden = true;
		});
		show.hidden = false;
		show.addEventListener("click", more);
	}

	if (target && box.contains(target) && target.closest("[data-qa-more]")) {
		more();
		target.scrollIntoView();
	}
});
