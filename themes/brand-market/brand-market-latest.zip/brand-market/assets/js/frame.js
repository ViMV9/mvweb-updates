( function () {
	"use strict";

	const entry = history.length;

	document.addEventListener( "click", function ( event ) {
		const back = event.target.closest( "[data-back]" );
		let from = null;

		if ( ! back || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey ) {
			return;
		}

		try {
			from = new URL( document.referrer );
		} catch ( e ) {
			return;
		}

		if ( from.origin === location.origin && from.pathname !== location.pathname && history.length > 1 ) {
			event.preventDefault();
			history.go( Math.min( -1, entry - history.length - 1 ) );
		}
	} );

	document.querySelectorAll( "[data-nav-select]" ).forEach( function ( select ) {
		select.addEventListener( "change", function () {
			if ( select.value ) {
				location.assign( select.value );
			}
		} );
	} );

	document.querySelectorAll( "[data-tab-select]" ).forEach( function ( form ) {
		const select = form.querySelector( "select" );

		if ( select ) {
			select.addEventListener( "change", function () {
				form.requestSubmit();
			} );
		}
	} );

	document.querySelectorAll( "[data-subcats-more]" ).forEach( function ( button ) {
		button.addEventListener( "click", function () {
			const box = button.closest( "[data-subcats]" );
			const first = box.querySelector( "[data-extra]" );

			box.setAttribute( "data-open", "" );
			button.remove();

			if ( first ) {
				first.focus();
			}
		} );
	} );

	document.querySelectorAll( "[data-subcats-next]" ).forEach( function ( button ) {
		const track = button.parentElement.querySelector( "[data-subcats-track]" );

		if ( ! track ) {
			return;
		}

		function sync() {
			button.hidden = track.scrollLeft + track.clientWidth >= track.scrollWidth - 1;
		}

		button.addEventListener( "click", function () {
			track.scrollBy( { left: track.clientWidth * 0.75 } );
		} );
		track.addEventListener( "scroll", sync, { passive: true } );
		new ResizeObserver( sync ).observe( track );
	} );

	document.querySelectorAll( ".mvweb-t-sidebar" ).forEach( function ( aside ) {
		new ResizeObserver( function () {
			aside.style.setProperty( "--mvweb-t-aside-h", aside.offsetHeight + "px" );
		} ).observe( aside );
	} );
} )();
