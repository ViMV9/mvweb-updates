<?php
/**
 * The cart and the checkout pages: the heading strip, then what WooCommerce prints in the text of the page.
 *
 * The strip comes from the context (inc/theme/modules/cart.php): the cart and
 * the checkout have one, the empty cart, the order received page and the
 * payment page draw their own.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

while ( have_posts() ) :
	the_post();

	mvweb_theme_order_hero();

	ob_start();
	the_content();
	$mvweb_html = (string) ob_get_clean();

	if ( ( is_wc_endpoint_url( 'order-received' ) || is_wc_endpoint_url( 'order-pay' ) ) && false === strpos( $mvweb_html, 'mvweb-t-page-hero' ) ) {
		get_template_part(
			'template-parts/page-hero',
			null,
			array( 'title' => is_wc_endpoint_url( 'order-pay' ) ? __( 'Order payment', 'brand-market' ) : __( 'Order received', 'brand-market' ) )
		);
	}

	echo $mvweb_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- The page content, filtered by WordPress.
endwhile;

get_footer();
