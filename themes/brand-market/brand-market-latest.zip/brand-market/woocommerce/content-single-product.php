<?php
/**
 * A product shown by the [product_page] shortcode: the product page of the theme.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( post_password_required() ) {
	echo get_the_password_form(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Core's escaped form.
	return;
}

get_template_part( 'template-parts/catalog/single', null, array( 'id' => get_the_ID() ) );
