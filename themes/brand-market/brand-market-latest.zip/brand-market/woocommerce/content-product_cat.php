<?php // phpcs:ignore WordPress.Files.FileName.NotHyphenatedLowercase -- WooCommerce looks the template up by this name.
/**
 * A product category in a WooCommerce loop: photo, name and count.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! isset( $category ) || ! $category instanceof WP_Term ) {
	return;
}

$mvweb_thumb = absint( get_term_meta( $category->term_id, 'thumbnail_id', true ) );
?>
<a class="mvweb-t-wc-cat" href="<?php echo esc_url( get_term_link( $category, 'product_cat' ) ); ?>">
	<?php
	if ( $mvweb_thumb ) {
		echo wp_get_attachment_image( $mvweb_thumb, 'woocommerce_thumbnail', false, array( 'loading' => 'lazy' ) );
	} else {
		echo wc_placeholder_img( 'woocommerce_thumbnail' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WooCommerce's escaped image markup.
	}
	?>
	<span class="mvweb-t-wc-cat__name"><?php echo esc_html( $category->name ); ?></span>
	<?php if ( $category->count > 0 ) : ?>
		<span class="mvweb-t-wc-cat__count">
			<?php
			/* translators: %s: number of products. */
			echo esc_html( sprintf( _n( '%s product', '%s products', $category->count, 'brand-market' ), number_format_i18n( $category->count ) ) );
			?>
		</span>
	<?php endif; ?>
</a>
