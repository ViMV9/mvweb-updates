<?php
/**
 * Error notices: an alert with the icon, one for each message.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 8.6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! $notices ) {
	return;
}
?>
<ul class="mvweb-t-alert mvweb-t-alert--list woocommerce-error" role="alert">
	<?php foreach ( $notices as $mvweb_notice ) : ?>
		<li class="mvweb-t-alert__item"<?php echo wc_get_notice_data_attr( $mvweb_notice ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by WooCommerce. ?>>
			<?php echo mvweb_theme_icon( 'alert-circle', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
			<p><?php echo wc_kses_notice( $mvweb_notice['notice'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by WooCommerce. ?></p>
		</li>
	<?php endforeach; ?>
</ul>
