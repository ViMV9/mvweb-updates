<?php
/**
 * Receipt page of a payment method: the order facts and the form of the method.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 3.2.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<section class="mvweb-t-section mvweb-t-section--flush-top">
	<div class="mvweb-t-container woocommerce-order-receipt">
		<ul class="order_details">
			<li class="order">
				<?php esc_html_e( 'Order number', 'brand-market' ); ?>
				<strong><?php echo esc_html( $order->get_order_number() ); ?></strong>
			</li>
			<li class="date">
				<?php esc_html_e( 'Date', 'brand-market' ); ?>
				<strong><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></strong>
			</li>
			<li class="total">
				<?php esc_html_e( 'Total', 'brand-market' ); ?>
				<strong><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></strong>
			</li>
			<?php if ( $order->get_payment_method_title() ) : ?>
				<li class="method">
					<?php esc_html_e( 'Payment method', 'brand-market' ); ?>
					<strong><?php echo wp_kses_post( $order->get_payment_method_title() ); ?></strong>
				</li>
			<?php endif; ?>
		</ul>
		<?php do_action( 'woocommerce_receipt_' . $order->get_payment_method(), $order->get_id() ); ?>
	</div>
</section>
