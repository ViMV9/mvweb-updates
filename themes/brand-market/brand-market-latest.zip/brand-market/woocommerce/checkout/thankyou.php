<?php
/**
 * The order received page: what was ordered, where it goes, what comes next.
 *
 * A paid or accepted order gets the acknowledgement, a failed one gets the
 * way to pay again. The hooks other plugins print their own blocks on keep
 * firing.
 *
 * Arguments: order (WC_Order or false).
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 11.2.0
 */

defined( 'ABSPATH' ) || exit;

$mvweb_failed = $order && $order->has_status( 'failed' );
$mvweb_hooked = '';
?>
<div class="woocommerce-order">
	<?php
	if ( $order ) {
		do_action( 'woocommerce_before_thankyou', $order->get_id() );

		$mvweb_hooked = mvweb_theme_hooked( 'woocommerce_thankyou', $order->get_id() ) . mvweb_theme_order_extras( $order );
	}

	if ( $mvweb_failed ) {
		mvweb_theme_status_hero(
			array(
				'state' => 'fail',
				'title' => __( 'Payment failed', 'brand-market' ),
				'lead'  => (string) apply_filters( 'woocommerce_thankyou_order_failed_text', mvweb_core_pay_fail_lead( $order ), $order ), // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
			)
		);
		?>
		<section class="mvweb-t-section mvweb-t-section--flush-top">
			<div class="mvweb-t-container mvweb-t-thanks__fail">
				<?php
				mvweb_theme_render_order_layout(
					'pay-fail',
					array(
						'order'   => $order,
						'context' => 'received',
					),
					$mvweb_hooked
				);
				get_template_part( 'template-parts/thanks/page/pay', null, array( 'order' => $order ) );
				?>
			</div>
		</section>
		<?php
	} else {
		mvweb_theme_status_hero(
			array(
				'state' => 'ok',
				'title' => __( 'Order received', 'brand-market' ),
				'lead'  => (string) apply_filters( 'woocommerce_thankyou_order_received_text', esc_html( (string) mvweb_core_cart_option( 'mvweb_thanks_lead' ) ), $order ), // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce for other plugins.
			)
		);
		?>
		<section class="mvweb-t-section mvweb-t-section--flush-top">
			<div class="mvweb-t-container mvweb-t-order">
				<div class="mvweb-t-order__main">
					<?php if ( $order ) : ?>
						<dl class="mvweb-t-overview">
							<div><dt><?php esc_html_e( 'Order number', 'brand-market' ); ?></dt><dd>
								<?php
								/* translators: %s: number of the order. */
								echo esc_html( sprintf( __( 'No. %s', 'brand-market' ), $order->get_order_number() ) );
								?>
							</dd></div>
							<div><dt><?php esc_html_e( 'Date', 'brand-market' ); ?></dt><dd><?php echo esc_html( wc_format_datetime( $order->get_date_created() ) ); ?></dd></div>
							<div><dt><?php esc_html_e( 'Total', 'brand-market' ); ?></dt><dd><?php echo wp_kses_post( $order->get_formatted_order_total() ); ?></dd></div>
							<?php if ( '' !== mvweb_core_order_payment_line( $order ) ) : ?>
								<div><dt><?php esc_html_e( 'Payment', 'brand-market' ); ?></dt><dd><?php echo esc_html( mvweb_core_order_payment_line( $order ) ); ?></dd></div>
							<?php endif; ?>
						</dl>
						<?php mvweb_theme_render_order_layout( 'thanks.page', array( 'order' => $order ), $mvweb_hooked ); ?>
					<?php else : ?>
						<?php mvweb_core_render_layout( 'thanks.page', array( 'order' => false ) ); ?>
					<?php endif; ?>
				</div>
				<?php if ( $order ) : ?>
					<aside class="mvweb-t-summary mvweb-t-order__aside" aria-label="<?php esc_attr_e( 'Order items', 'brand-market' ); ?>">
						<div class="mvweb-t-summary__title mvweb-t-h2" role="heading" aria-level="2"><?php esc_html_e( 'Order items', 'brand-market' ); ?></div>
						<?php get_template_part( 'template-parts/order/summary', null, array( 'order' => $order ) ); ?>
					</aside>
				<?php endif; ?>
			</div>
		</section>
		<?php
	}
	?>
</div>
