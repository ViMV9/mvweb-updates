<?php
/**
 * Start of a WooCommerce product loop (shortcodes and plugins): the card grid of the theme.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 3.3.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="mvweb-t-grid mvweb-t-wc-loop" data-cols="<?php echo (int) wc_get_loop_prop( 'columns' ); ?>">
