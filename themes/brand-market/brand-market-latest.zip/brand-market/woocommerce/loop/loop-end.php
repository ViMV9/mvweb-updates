<?php
/**
 * End of a WooCommerce product loop.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</div>
