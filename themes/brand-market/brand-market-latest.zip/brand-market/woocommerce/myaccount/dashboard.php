<?php
/**
 * My Account dashboard: the greeting, then the tiles and the recent orders of the account-dashboard area.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 *
 * @version 4.4.0
 */

defined( 'ABSPATH' ) || exit;

$mvweb_name = '' !== trim( (string) $current_user->first_name ) ? $current_user->first_name : $current_user->display_name;
?>

<div class="mvweb-t-account__hello">
	<div class="mvweb-t-account__title mvweb-t-h2" role="heading" aria-level="2">
		<?php
		/* translators: %s: name of the customer. */
		echo esc_html( sprintf( __( 'Hello, %s', 'brand-market' ), $mvweb_name ) );
		?>
	</div>
	<p>
		<?php
		if ( '' !== (string) $current_user->user_email ) {
			printf(
				wp_kses(
					/* translators: 1: display name, 2: email, 3: log out address. */
					__( 'This is your account: orders, delivery addresses and account details. You are signed in as %1$s (%2$s). <a href="%3$s">Log out</a>', 'brand-market' ),
					array( 'a' => array( 'href' => array() ) )
				),
				esc_html( $current_user->display_name ),
				esc_html( $current_user->user_email ),
				esc_url( wc_logout_url() )
			);
		} else {
			printf(
				wp_kses(
					/* translators: 1: display name, 2: log out address. */
					__( 'This is your account: orders, delivery addresses and account details. You are signed in as %1$s. <a href="%2$s">Log out</a>', 'brand-market' ),
					array( 'a' => array( 'href' => array() ) )
				),
				esc_html( $current_user->display_name ),
				esc_url( wc_logout_url() )
			);
		}
		?>
	</p>
</div>

<?php
mvweb_core_render_layout( 'account-dashboard' );

echo mvweb_theme_hooked( 'woocommerce_account_dashboard' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Blocks that other plugins print on the hook of WooCommerce.
