<?php
/**
 * Sitemap for people: the page template «Sitemap», its settings, the mark «Do not show on the sitemap» and the data of the map.
 *
 * The keys of the looks are the same in every theme; a theme draws each look in template-parts/sitemap/{look}.php and may rename it through the filter of this file.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_sitemap_template' ) ) {
	/**
	 * The file of the page template of the sitemap.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_sitemap_template() {
		return 'page-templates/sitemap.php';
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_template_name' ) ) {
	/**
	 * The name of the page template of the sitemap in the site language.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $templates Template names keyed by file.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_sitemap_template_name( $templates ) {
		if ( isset( $templates[ mvweb_core_sitemap_template() ] ) ) {
			$templates[ mvweb_core_sitemap_template() ] = __( 'Sitemap', 'mvweb-core' );
		}

		return $templates;
	}
}
add_filter( 'theme_page_templates', 'mvweb_core_sitemap_template_name' );

if ( ! function_exists( 'mvweb_core_sitemap_page_ids' ) ) {
	/**
	 * The pages that use the template of the sitemap.
	 *
	 * @since 0.1.0
	 *
	 * @return int[]
	 */
	function mvweb_core_sitemap_page_ids() {
		static $ids = null;

		if ( null === $ids ) {
			$ids = array_map(
				'absint',
				get_posts(
					array(
						'post_type'        => 'page',
						'post_status'      => 'any',
						'fields'           => 'ids',
						'numberposts'      => 5,
						'meta_key'         => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- A handful of pages, looked up once per request.
						'meta_value'       => mvweb_core_sitemap_template(), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- A handful of pages, looked up once per request.
						'no_found_rows'    => true,
						'suppress_filters' => true,
					)
				)
			);
		}

		return $ids;
	}
}

if ( ! function_exists( 'mvweb_core_is_sitemap' ) ) {
	/**
	 * Whether the page being shown is the sitemap.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_is_sitemap() {
		return is_page_template( mvweb_core_sitemap_template() );
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_types' ) ) {
	/**
	 * The kinds of content the sitemap can show, those of the modules that are on.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>> Kind => its data.
	 */
	function mvweb_core_sitemap_types() {
		$list = array(
			'page' => array(
				'label'  => __( 'Pages', 'mvweb-core' ),
				'icon'   => 'home',
				'desc'   => __( 'About the company, terms and documents', 'mvweb-core' ),
				/* translators: %s: a number. */
				'units'  => _n_noop( '%s page', '%s pages', 'mvweb-core' ),
				'source' => 'pages',
			),
		);

		if ( post_type_exists( mvweb_core_post_type() ) && taxonomy_exists( mvweb_core_taxonomy() ) ) {
			$list['catalog'] = array(
				'label'     => __( 'Catalogue', 'mvweb-core' ),
				'icon'      => 'shopping-cart',
				'desc'      => __( 'Sections and items of the catalogue', 'mvweb-core' ),
				/* translators: %s: a number. */
				'units'     => _n_noop( '%s item', '%s items', 'mvweb-core' ),
				'source'    => 'terms',
				'post_type' => mvweb_core_post_type(),
				'taxonomy'  => mvweb_core_taxonomy(),
				'archive'   => array(
					'name' => __( 'Whole catalogue', 'mvweb-core' ),
					'url'  => mvweb_core_catalog_page_url(),
				),
			);
		}

		if ( post_type_exists( 'mv_service' ) && taxonomy_exists( 'mv_service_cat' ) ) {
			$list['service'] = array(
				'label'     => mvweb_core_service_label(),
				'icon'      => 'tools',
				'desc'      => __( 'Services by sections', 'mvweb-core' ),
				/* translators: %s: a number. */
				'units'     => _n_noop( '%s service', '%s services', 'mvweb-core' ),
				'source'    => 'terms',
				'post_type' => 'mv_service',
				'taxonomy'  => 'mv_service_cat',
				'archive'   => array(
					'name' => __( 'All services', 'mvweb-core' ),
					'url'  => mvweb_core_service_archive_url(),
				),
			);
		}

		$list['post'] = array(
			'label'     => __( 'Blog', 'mvweb-core' ),
			'icon'      => 'file-text',
			'desc'      => __( 'Articles by categories', 'mvweb-core' ),
			/* translators: %s: a number. */
			'units'     => _n_noop( '%s article', '%s articles', 'mvweb-core' ),
			'source'    => 'terms',
			'post_type' => 'post',
			'taxonomy'  => 'category',
			'archive'   => array(
				'name' => __( 'All articles', 'mvweb-core' ),
				'url'  => mvweb_core_blog_url(),
			),
		);

		if ( post_type_exists( 'mv_work' ) && taxonomy_exists( 'mv_work_type' ) ) {
			$list['work'] = array(
				'label'     => mvweb_core_work_label(),
				'icon'      => 'photo',
				'desc'      => __( 'Finished works by kinds', 'mvweb-core' ),
				/* translators: %s: a number. */
				'units'     => _n_noop( '%s work', '%s works', 'mvweb-core' ),
				'source'    => 'terms',
				'post_type' => 'mv_work',
				'taxonomy'  => 'mv_work_type',
				'archive'   => array(
					'name' => __( 'All works', 'mvweb-core' ),
					'url'  => (string) get_post_type_archive_link( 'mv_work' ),
				),
			);
		}

		if ( post_type_exists( 'mv_facet' ) ) {
			$list['facet'] = array(
				'label'     => __( 'Selections', 'mvweb-core' ),
				'icon'      => 'filter',
				'desc'      => __( 'Pages of the filters of the catalogue', 'mvweb-core' ),
				/* translators: %s: a number. */
				'units'     => _n_noop( '%s selection', '%s selections', 'mvweb-core' ),
				'source'    => 'facets',
				'post_type' => 'mv_facet',
			);
		}

		$list['tag'] = array(
			'label'    => __( 'Tags', 'mvweb-core' ),
			'icon'     => 'list',
			'desc'     => __( 'Topics of the articles', 'mvweb-core' ),
			/* translators: %s: a number. */
			'units'    => _n_noop( '%s tag', '%s tags', 'mvweb-core' ),
			'source'   => 'tags',
			'taxonomy' => 'post_tag',
		);

		$list['author'] = array(
			'label'  => __( 'Authors', 'mvweb-core' ),
			'icon'   => 'user',
			'desc'   => __( 'Who writes the articles', 'mvweb-core' ),
			/* translators: %s: a number. */
			'units'  => _n_noop( '%s author', '%s authors', 'mvweb-core' ),
			'source' => 'authors',
		);

		/**
		 * Filter the kinds of content of the sitemap: a theme renames them, changes their icons or descriptions.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,array<string,mixed>> $list
		 */
		return (array) apply_filters( 'mvweb_core_sitemap_types', $list );
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_views' ) ) {
	/**
	 * The looks of the sitemap.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Value => label.
	 */
	function mvweb_core_sitemap_views() {
		$list = array(
			'columns' => __( 'Columns of sections', 'mvweb-core' ),
			'tree'    => __( 'Tree: the sections open on a click', 'mvweb-core' ),
			'index'   => __( 'Index from A to Z', 'mvweb-core' ),
			'cards'   => __( 'Cards of the sections', 'mvweb-core' ),
			'toc'     => __( 'Contents with a search field', 'mvweb-core' ),
		);

		/**
		 * Filter the looks of the sitemap: key => label; a theme renames the looks it draws.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $list
		 */
		return (array) apply_filters( 'mvweb_core_sitemap_views', $list );
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_settings' ) ) {
	/**
	 * The settings of the sitemap: the kinds in their order, the look, the depth, the entries in a section and the numbers.
	 *
	 * @since 0.1.0
	 *
	 * @return array{types:string[],view:string,entries:bool,limit:int,counts:bool}
	 */
	function mvweb_core_sitemap_settings() {
		$known = array_keys( mvweb_core_sitemap_types() );
		$types = json_decode( (string) get_theme_mod( 'mvweb_sitemap_types', mvweb_core_sitemap_default_types() ), true );
		$view  = (string) get_theme_mod( 'mvweb_sitemap_view', 'tree' );
		$limit = absint( get_theme_mod( 'mvweb_sitemap_limit', '5' ) );
		$views = mvweb_core_sitemap_views();

		return array(
			'types'   => array_values( array_intersect( is_array( $types ) ? $types : array(), $known ) ),
			'view'    => isset( $views[ $view ] ) ? $view : (string) key( $views ),
			'entries' => 'sections' !== get_theme_mod( 'mvweb_sitemap_depth', 'entries' ),
			'limit'   => 0 === $limit ? 100 : min( 100, $limit ),
			'counts'  => (bool) get_theme_mod( 'mvweb_sitemap_counts', true ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_default_types' ) ) {
	/**
	 * The kinds a new sitemap shows, as the value of the setting.
	 *
	 * @since 0.1.0
	 *
	 * @return string JSON list.
	 */
	function mvweb_core_sitemap_default_types() {
		return (string) wp_json_encode( array_values( array_intersect( array( 'page', 'catalog', 'service', 'post', 'work' ), array_keys( mvweb_core_sitemap_types() ) ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_fields' ) ) {
	/**
	 * The fields of the section «Sitemap page».
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_sitemap_fields( $kit ) {
		$types = array();

		foreach ( mvweb_core_sitemap_types() as $key => $type ) {
			$types[ $key ] = (string) $type['label'];
		}

		$kit->add_fields(
			array(
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_sitemap_view',
					'section'     => 'mvweb_cz_inner_sitemap',
					'label'       => __( 'Look of the sitemap', 'mvweb-core' ),
					'description' => __( 'The map is drawn on a page with the template “Sitemap”: create a page and choose the template in its settings. Put a link to it into the footer menu.', 'mvweb-core' ),
					'default'     => 'tree',
					'choices'     => mvweb_core_sitemap_views(),
				),
				array(
					'type'        => 'sortable',
					'settings'    => 'mvweb_sitemap_types',
					'section'     => 'mvweb_cz_inner_sitemap',
					'label'       => __( 'What the map shows and in what order', 'mvweb-core' ),
					'description' => __( 'Drag to reorder. Untick to hide. The cart, the checkout, the account, the favourites, the comparison and the map itself are never shown.', 'mvweb-core' ),
					'default'     => mvweb_core_sitemap_default_types(),
					'choices'     => $types,
				),
				array(
					'type'     => 'radio',
					'settings' => 'mvweb_sitemap_depth',
					'section'  => 'mvweb_cz_inner_sitemap',
					'label'    => __( 'Depth', 'mvweb-core' ),
					'default'  => 'entries',
					'choices'  => array(
						'sections' => __( 'Sections only', 'mvweb-core' ),
						'entries'  => __( 'Sections and their entries', 'mvweb-core' ),
					),
				),
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_sitemap_limit',
					'section'     => 'mvweb_cz_inner_sitemap',
					'label'       => __( 'Entries in a section', 'mvweb-core' ),
					'description' => __( 'The rest is a link “More: N” to the page of the section. “All” stops at 100.', 'mvweb-core' ),
					'default'     => '5',
					'choices'     => array(
						'3'  => '3',
						'5'  => '5',
						'10' => '10',
						'0'  => __( 'All', 'mvweb-core' ),
					),
					'required'    => array(
						array(
							'setting'  => 'mvweb_sitemap_depth',
							'operator' => '==',
							'value'    => 'entries',
						),
					),
				),
				array(
					'type'     => 'toggle',
					'settings' => 'mvweb_sitemap_counts',
					'section'  => 'mvweb_cz_inner_sitemap',
					'label'    => __( 'Show the number of entries', 'mvweb-core' ),
					'default'  => true,
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_sitemap_fields' );

if ( ! function_exists( 'mvweb_core_sitemap_post_types' ) ) {
	/**
	 * The post types of the sitemap whose entries can be hidden from it.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_sitemap_post_types() {
		$list = array( 'page' );

		foreach ( mvweb_core_sitemap_types() as $type ) {
			if ( ! empty( $type['post_type'] ) ) {
				$list[] = (string) $type['post_type'];
			}
		}

		return array_values( array_unique( $list ) );
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_taxonomies' ) ) {
	/**
	 * The taxonomies of the sitemap whose terms can be hidden from it.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_sitemap_taxonomies() {
		$list = array();

		foreach ( mvweb_core_sitemap_types() as $type ) {
			if ( ! empty( $type['taxonomy'] ) ) {
				$list[] = (string) $type['taxonomy'];
			}
		}

		return array_values( array_unique( $list ) );
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_hide_box' ) ) {
	/**
	 * The box «Sitemap» beside the editor, when the site has a sitemap page.
	 *
	 * @since 0.1.0
	 *
	 * @param string $post_type Post type of the screen.
	 *
	 * @return void
	 */
	function mvweb_core_sitemap_hide_box( $post_type ) {
		if ( ! in_array( $post_type, mvweb_core_sitemap_post_types(), true ) || ! mvweb_core_sitemap_page_ids() ) {
			return;
		}

		add_meta_box(
			'mvweb-sitemap-hide',
			__( 'Sitemap', 'mvweb-core' ),
			static function ( $post ) {
				wp_nonce_field( 'mvweb_sitemap_hide', 'mvweb_sitemap_hide_nonce' );
				?>
				<label>
					<input type="checkbox" name="mvweb_sitemap_hide" value="1"<?php checked( (bool) get_post_meta( $post->ID, '_mvweb_sitemap_hide', true ) ); ?>>
					<?php esc_html_e( 'Do not show on the sitemap', 'mvweb-core' ); ?>
				</label>
				<?php if ( is_post_type_hierarchical( $post->post_type ) ) : ?>
					<p class="description"><?php esc_html_e( 'The page with its child pages.', 'mvweb-core' ); ?></p>
				<?php endif; ?>
				<?php
			},
			$post_type,
			'side',
			'low'
		);
	}
}
add_action( 'add_meta_boxes', 'mvweb_core_sitemap_hide_box' );

if ( ! function_exists( 'mvweb_core_sitemap_hide_save' ) ) {
	/**
	 * Save the mark «Do not show on the sitemap» of an entry.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Post id.
	 *
	 * @return void
	 */
	function mvweb_core_sitemap_hide_save( $post_id ) {
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST['mvweb_sitemap_hide_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mvweb_sitemap_hide_nonce'] ) ), 'mvweb_sitemap_hide' ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( isset( $_POST['mvweb_sitemap_hide'] ) ) {
			update_post_meta( $post_id, '_mvweb_sitemap_hide', 1 );
		} else {
			delete_post_meta( $post_id, '_mvweb_sitemap_hide' );
		}
	}
}
add_action( 'save_post', 'mvweb_core_sitemap_hide_save' );

if ( ! function_exists( 'mvweb_core_sitemap_term_fields' ) ) {
	/**
	 * The mark «Do not show on the sitemap» on the screens of the terms of the sitemap.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_sitemap_term_fields() {
		foreach ( mvweb_core_sitemap_taxonomies() as $taxonomy ) {
			add_action( $taxonomy . '_add_form_fields', 'mvweb_core_sitemap_term_field' );
			add_action( $taxonomy . '_edit_form_fields', 'mvweb_core_sitemap_term_field' );
			add_action( 'created_' . $taxonomy, 'mvweb_core_sitemap_term_save' );
			add_action( 'edited_' . $taxonomy, 'mvweb_core_sitemap_term_save' );
		}
	}
}
add_action( 'admin_init', 'mvweb_core_sitemap_term_fields' );

if ( ! function_exists( 'mvweb_core_sitemap_term_field' ) ) {
	/**
	 * The checkbox «Do not show on the sitemap» on the forms of a term.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Term|string $term The term on the edit form, the taxonomy on the add form.
	 *
	 * @return void
	 */
	function mvweb_core_sitemap_term_field( $term ) {
		if ( ! mvweb_core_sitemap_page_ids() ) {
			return;
		}

		$on    = $term instanceof WP_Term && (bool) get_term_meta( $term->term_id, '_mvweb_sitemap_hide', true );
		$label = __( 'Do not show on the sitemap', 'mvweb-core' );
		$hint  = __( 'The section with its subsections and entries.', 'mvweb-core' );

		if ( $term instanceof WP_Term ) {
			?>
			<tr class="form-field">
				<th scope="row"><?php esc_html_e( 'Sitemap', 'mvweb-core' ); ?></th>
				<td>
					<?php wp_nonce_field( 'mvweb_sitemap_hide', 'mvweb_sitemap_hide_nonce' ); ?>
					<label><input type="checkbox" name="mvweb_sitemap_hide" value="1"<?php checked( $on ); ?>> <?php echo esc_html( $label ); ?></label>
					<p class="description"><?php echo esc_html( $hint ); ?></p>
				</td>
			</tr>
			<?php
			return;
		}
		?>
		<div class="form-field">
			<?php wp_nonce_field( 'mvweb_sitemap_hide', 'mvweb_sitemap_hide_nonce' ); ?>
			<label><input type="checkbox" name="mvweb_sitemap_hide" value="1"> <?php echo esc_html( $label ); ?></label>
			<p><?php echo esc_html( $hint ); ?></p>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_term_save' ) ) {
	/**
	 * Save the mark «Do not show on the sitemap» of a term.
	 *
	 * @since 0.1.0
	 *
	 * @param int $term_id Term id.
	 *
	 * @return void
	 */
	function mvweb_core_sitemap_term_save( $term_id ) {
		if ( ! isset( $_POST['mvweb_sitemap_hide_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mvweb_sitemap_hide_nonce'] ) ), 'mvweb_sitemap_hide' ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_term', $term_id ) ) {
			return;
		}

		if ( isset( $_POST['mvweb_sitemap_hide'] ) ) {
			update_term_meta( $term_id, '_mvweb_sitemap_hide', 1 );
		} else {
			delete_term_meta( $term_id, '_mvweb_sitemap_hide' );
		}
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_skip' ) ) {
	/**
	 * The entries the sitemap never shows: the map itself, the service pages of the shop and of the lists, and the entries marked by hand.
	 *
	 * @since 0.1.0
	 *
	 * @return int[]
	 */
	function mvweb_core_sitemap_skip() {
		static $skip = null;

		if ( null !== $skip ) {
			return $skip;
		}

		$skip = mvweb_core_sitemap_page_ids();

		$skip[] = mvweb_core_favorites_page_id();

		if ( function_exists( 'mvweb_core_compare_page_id' ) ) {
			$skip[] = mvweb_core_compare_page_id();
		}

		if ( function_exists( 'wc_get_page_id' ) ) {
			foreach ( array( 'cart', 'checkout', 'myaccount' ) as $page ) {
				$skip[] = wc_get_page_id( $page );
			}
		}

		$marked = get_posts(
			array(
				'post_type'        => mvweb_core_sitemap_post_types(),
				'post_status'      => 'publish',
				'fields'           => 'ids',
				'numberposts'      => -1, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_numberposts -- Every marked entry, ids only.
				'meta_key'         => '_mvweb_sitemap_hide', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- The marked entries, once per view of the map.
				'no_found_rows'    => true,
				'suppress_filters' => true,
			)
		);

		$skip = array_values( array_filter( array_unique( array_map( 'intval', array_merge( $skip, $marked ) ) ), static fn( $id ) => $id > 0 ) );

		return $skip;
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_text' ) ) {
	/**
	 * A name as plain text: without tags and entities, ready to be escaped once more on output.
	 *
	 * @since 0.1.0
	 *
	 * @param string $text Name.
	 *
	 * @return string
	 */
	function mvweb_core_sitemap_text( $text ) {
		return trim( html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES, 'UTF-8' ) );
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_units' ) ) {
	/**
	 * A number with the word of a kind: «12 items».
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $type   Kind of the sitemap.
	 * @param int                 $number Number.
	 *
	 * @return string
	 */
	function mvweb_core_sitemap_units( array $type, $number ) {
		return sprintf( translate_nooped_plural( $type['units'], $number, 'mvweb-core' ), number_format_i18n( $number ) );
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_posts' ) ) {
	/**
	 * The entries of one term, or of the whole type without a term.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $type    Kind of the sitemap.
	 * @param int                 $term_id Term id; 0 for the whole type.
	 * @param int                 $limit   How many.
	 *
	 * @return array<int,array{name:string,url:string}>
	 */
	function mvweb_core_sitemap_posts( array $type, $term_id, $limit ) {
		$tax = array();

		if ( $term_id ) {
			$tax[] = array(
				'taxonomy'         => $type['taxonomy'],
				'terms'            => array( (int) $term_id ),
				'include_children' => false,
			);
		}

		if ( 'product' === $type['post_type'] && function_exists( 'wc_get_product_visibility_term_ids' ) ) {
			$hidden = wc_get_product_visibility_term_ids();

			if ( ! empty( $hidden['exclude-from-catalog'] ) ) {
				$tax[] = array(
					'taxonomy' => 'product_visibility',
					'terms'    => array( (int) $hidden['exclude-from-catalog'] ),
					'operator' => 'NOT IN',
				);
			}
		}

		$query = new WP_Query(
			array(
				'post_type'              => $type['post_type'],
				'post_status'            => 'publish',
				'posts_per_page'         => $limit,
				'post__not_in'           => mvweb_core_sitemap_skip(),
				'has_password'           => false,
				'tax_query'              => $tax, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- One term per section, limited.
				'orderby'                => 'post' === $type['post_type'] ? 'date' : array(
					'menu_order' => 'ASC',
					'title'      => 'ASC',
				),
				'order'                  => 'DESC',
				'ignore_sticky_posts'    => true,
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		$list = array();

		foreach ( $query->posts as $post ) {
			$name = mvweb_core_sitemap_text( get_the_title( $post ) );

			if ( '' !== $name ) {
				$list[] = array(
					'name' => $name,
					'url'  => (string) get_permalink( $post ),
				);
			}
		}

		return $list;
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_more' ) ) {
	/**
	 * The words of the link to the rest of a section: «More: 12 items».
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $type Kind of the sitemap.
	 * @param int                 $more How many are left.
	 *
	 * @return string Empty when nothing is left.
	 */
	function mvweb_core_sitemap_more( array $type, $more ) {
		/* translators: %s: a number with its word, «12 items». */
		return $more > 0 ? sprintf( __( 'More: %s', 'mvweb-core' ), mvweb_core_sitemap_units( $type, $more ) ) : '';
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_pages' ) ) {
	/**
	 * The tree of the pages: the top pages are the sections, a page with children is a subsection.
	 *
	 * @since 0.1.0
	 *
	 * @param bool $entries Whether to list the pages without children.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_sitemap_pages( $entries ) {
		$kids = array();

		foreach ( get_pages(
			array(
				'sort_column' => 'menu_order,post_title',
				'exclude'     => mvweb_core_sitemap_skip(),
			)
		) as $page ) {
			if ( '' === $page->post_password && '' !== mvweb_core_sitemap_text( $page->post_title ) ) {
				$kids[ (int) $page->post_parent ][] = $page;
			}
		}

		$node = static function ( $page ) use ( &$node, $kids, $entries ) {
			$group = array(
				'name'     => mvweb_core_sitemap_text( get_the_title( $page ) ),
				'url'      => (string) get_permalink( $page ),
				'total'    => 0,
				'items'    => array(),
				'more'     => '',
				'url_more' => '',
				'subs'     => array(),
			);

			foreach ( isset( $kids[ $page->ID ] ) ? $kids[ $page->ID ] : array() as $kid ) {
				++$group['total'];

				if ( isset( $kids[ $kid->ID ] ) ) {
					$sub             = $node( $kid );
					$group['total'] += $sub['total'];
					$group['subs'][] = $sub;
				} elseif ( $entries ) {
					$group['items'][] = array(
						'name' => mvweb_core_sitemap_text( get_the_title( $kid ) ),
						'url'  => (string) get_permalink( $kid ),
					);
				}
			}

			return $group;
		};

		return array_map( $node, isset( $kids[0] ) ? $kids[0] : array() );
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_terms' ) ) {
	/**
	 * The tree of the terms of a kind: the top terms are the sections; the entries are listed under the terms without children.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $type     Kind of the sitemap.
	 * @param array<string,mixed> $settings Settings of the sitemap.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_sitemap_terms( array $type, array $settings ) {
		$terms = get_terms(
			array(
				'taxonomy'   => $type['taxonomy'],
				'hide_empty' => true,
				'pad_counts' => true,
			)
		);

		if ( ! is_array( $terms ) ) {
			return array();
		}

		$kids = array();

		foreach ( $terms as $term ) {
			if ( ! get_term_meta( $term->term_id, '_mvweb_sitemap_hide', true ) ) {
				$kids[ (int) $term->parent ][] = $term;
			}
		}

		$node = static function ( $term ) use ( &$node, $kids, $type, $settings ) {
			$url   = get_term_link( $term );
			$group = array(
				'name'     => mvweb_core_sitemap_text( $term->name ),
				'url'      => is_wp_error( $url ) ? '' : $url,
				'total'    => (int) $term->count,
				'items'    => array(),
				'more'     => '',
				'url_more' => '',
				'subs'     => array_map( $node, isset( $kids[ $term->term_id ] ) ? $kids[ $term->term_id ] : array() ),
			);

			if ( $settings['entries'] && ! $group['subs'] ) {
				$group['items']    = mvweb_core_sitemap_posts( $type, $term->term_id, $settings['limit'] );
				$group['more']     = mvweb_core_sitemap_more( $type, (int) $term->count - count( $group['items'] ) );
				$group['url_more'] = $group['url'];
			}

			return $group;
		};

		return array_map( $node, isset( $kids[0] ) ? $kids[0] : array() );
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_facets' ) ) {
	/**
	 * The selections grouped by the section of the catalogue they filter.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_sitemap_facets() {
		$groups = array();

		foreach ( get_posts(
			array(
				'post_type'        => 'mv_facet',
				'post_status'      => 'publish',
				'numberposts'      => 100,
				'has_password'     => false,
				'post__not_in'     => mvweb_core_sitemap_skip(),
				'orderby'          => 'title',
				'order'            => 'ASC',
				'no_found_rows'    => true,
				'suppress_filters' => true,
			)
		) as $post ) {
			$term = get_term( absint( get_post_meta( $post->ID, '_mvweb_facet_term', true ) ), mvweb_core_taxonomy() );

			if ( ! $term instanceof WP_Term || get_term_meta( $term->term_id, '_mvweb_sitemap_hide', true ) ) {
				continue;
			}

			if ( ! isset( $groups[ $term->term_id ] ) ) {
				$url = get_term_link( $term );

				$groups[ $term->term_id ] = array(
					'name'     => mvweb_core_sitemap_text( $term->name ),
					'url'      => is_wp_error( $url ) ? '' : $url,
					'total'    => 0,
					'items'    => array(),
					'more'     => '',
					'url_more' => '',
					'subs'     => array(),
				);
			}

			++$groups[ $term->term_id ]['total'];

			$groups[ $term->term_id ]['items'][] = array(
				'name' => mvweb_core_sitemap_text( get_the_title( $post ) ),
				'url'  => (string) get_permalink( $post ),
			);
		}

		return array_values( $groups );
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_flat' ) ) {
	/**
	 * The plain lists of the sitemap: the tags and the authors of the blog, with their numbers.
	 *
	 * @since 0.1.0
	 *
	 * @param string $source Tags or authors.
	 *
	 * @return array<int,array{name:string,url:string,n:int}>
	 */
	function mvweb_core_sitemap_flat( $source ) {
		$list = array();

		if ( 'tags' === $source ) {
			$terms = get_terms(
				array(
					'taxonomy'   => 'post_tag',
					'hide_empty' => true,
					'orderby'    => 'count',
					'order'      => 'DESC',
					'number'     => 100,
				)
			);

			foreach ( is_array( $terms ) ? $terms : array() as $term ) {
				$url = get_term_link( $term );

				if ( ! is_wp_error( $url ) && ! get_term_meta( $term->term_id, '_mvweb_sitemap_hide', true ) ) {
					$list[] = array(
						'name' => mvweb_core_sitemap_text( $term->name ),
						'url'  => $url,
						'n'    => (int) $term->count,
					);
				}
			}

			return $list;
		}

		$users = get_users(
			array(
				'has_published_posts' => array( 'post' ),
				'orderby'             => 'post_count',
				'order'               => 'DESC',
				'number'              => 100,
				'fields'              => array( 'ID', 'display_name' ),
			)
		);

		$counts = $users ? count_many_users_posts( wp_list_pluck( $users, 'ID' ), 'post', true ) : array();

		foreach ( $users as $user ) {
			$list[] = array(
				'name' => mvweb_core_sitemap_text( $user->display_name ),
				'url'  => get_author_posts_url( (int) $user->ID ),
				'n'    => isset( $counts[ $user->ID ] ) ? (int) $counts[ $user->ID ] : 0,
			);
		}

		return $list;
	}
}

if ( ! function_exists( 'mvweb_core_sitemap' ) ) {
	/**
	 * The sitemap by the settings: the kinds in their order, each with its sections or its plain list, and the number of links; built once and stored until a post, a section, the settings or the addresses change.
	 *
	 * @since 0.1.0
	 *
	 * @return array{types:array<int,array<string,mixed>>,links:int,counts:bool,view:string,meta:string[]}
	 */
	function mvweb_core_sitemap() {
		static $map = null;

		if ( null !== $map ) {
			return $map;
		}

		$settings = mvweb_core_sitemap_settings();
		$hash     = md5( (string) wp_json_encode( array( $settings, get_locale(), wp_get_theme()->get( 'Version' ) ) ) );
		$cached   = get_option( 'mvweb_core_sitemap' );

		if ( is_array( $cached ) && isset( $cached['key'], $cached['map'] ) && $hash === $cached['key'] ) {
			$map = $cached['map'];

			return $map;
		}

		$types = mvweb_core_sitemap_types();
		$map   = array(
			'types'  => array(),
			'links'  => 0,
			'counts' => $settings['counts'],
			'view'   => $settings['view'],
			'meta'   => array(),
		);

		foreach ( $settings['types'] as $key ) {
			$type = $types[ $key ] + array(
				'key'      => $key,
				'archive'  => array(),
				'groups'   => array(),
				'items'    => array(),
				'more'     => '',
				'url_more' => '',
				'total'    => 0,
			);

			if ( empty( $type['archive']['url'] ) ) {
				$type['archive'] = array();
			}

			switch ( $type['source'] ) {
				case 'pages':
					$type['groups'] = mvweb_core_sitemap_pages( $settings['entries'] );

					foreach ( $type['groups'] as $group ) {
						$type['total'] += 1 + $group['total'];
					}
					break;

				case 'terms':
					$type['groups'] = mvweb_core_sitemap_terms( $type, $settings );
					$type['total']  = (int) wp_count_posts( $type['post_type'] )->publish;

					$shown = wp_count_terms(
						array(
							'taxonomy'   => $type['taxonomy'],
							'hide_empty' => true,
						)
					);

					if ( ! $type['groups'] && $settings['entries'] && ! $shown ) {
						$type['items']    = mvweb_core_sitemap_posts( $type, 0, $settings['limit'] );
						$type['more']     = mvweb_core_sitemap_more( $type, $type['total'] - count( $type['items'] ) );
						$type['url_more'] = isset( $type['archive']['url'] ) ? $type['archive']['url'] : '';
					}
					break;

				case 'facets':
					$type['groups'] = mvweb_core_sitemap_facets();

					foreach ( $type['groups'] as $group ) {
						$type['total'] += $group['total'];
					}
					break;

				default:
					$type['items'] = mvweb_core_sitemap_flat( (string) $type['source'] );
					$type['total'] = count( $type['items'] );
			}

			if ( ! $type['groups'] && ! $type['items'] ) {
				continue;
			}

			$type['total_text'] = mvweb_core_sitemap_units( $type, $type['total'] );
			$map['types'][]     = $type;
			$map['links']      += mvweb_core_sitemap_links( $type );
		}

		$sections = count( $map['types'] );

		$map['meta'] = array(
			/* translators: %s: number of the sections of the site on the map. */
			sprintf( _n( '%s section of the site', '%s sections of the site', $sections, 'mvweb-core' ), number_format_i18n( $sections ) ),
			/* translators: %s: number of the links on the map. */
			sprintf( _n( '%s link', '%s links', $map['links'], 'mvweb-core' ), number_format_i18n( $map['links'] ) ),
		);

		update_option(
			'mvweb_core_sitemap',
			array(
				'key' => $hash,
				'map' => $map,
			),
			false
		);

		return $map;
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_flush' ) ) {
	/**
	 * Drop the stored sitemap: a post, a section, a mark or the settings changed.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_sitemap_flush() {
		delete_option( 'mvweb_core_sitemap' );
	}
}

foreach ( array( 'save_post', 'deleted_post', 'created_term', 'edited_term', 'delete_term', 'set_object_terms', 'customize_save_after', 'switch_theme', 'activated_plugin', 'deactivated_plugin', 'update_option_permalink_structure' ) as $mvweb_core_sitemap_hook ) {
	add_action( $mvweb_core_sitemap_hook, 'mvweb_core_sitemap_flush' );
}

if ( ! function_exists( 'mvweb_core_sitemap_links' ) ) {
	/**
	 * The number of the links of a kind of the sitemap.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $type Kind of the sitemap.
	 *
	 * @return int
	 */
	function mvweb_core_sitemap_links( array $type ) {
		$walk = static function ( array $groups ) use ( &$walk ) {
			$links = 0;

			foreach ( $groups as $group ) {
				$links += ( '' !== $group['url'] ? 1 : 0 ) + count( $group['items'] ) + ( '' !== $group['more'] ? 1 : 0 ) + $walk( $group['subs'] );
			}

			return $links;
		};

		return ( $type['archive'] ? 1 : 0 ) + count( $type['items'] ) + ( '' !== $type['more'] ? 1 : 0 ) + $walk( $type['groups'] );
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_index' ) ) {
	/**
	 * The sitemap as an index: every link by the first letter of its name, with the place it comes from.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $map The sitemap.
	 *
	 * @return array{alphabet:string[],letters:array<string,array<int,array{name:string,url:string,from:string,n:int}>>}
	 */
	function mvweb_core_sitemap_index( array $map ) {
		$rows = array();
		$add  = static function ( $name, $url, $from, $n = 0 ) use ( &$rows ) {
			if ( '' !== $url && ! isset( $rows[ $url ] ) ) {
				$rows[ $url ] = array(
					'name' => $name,
					'url'  => $url,
					'from' => $from,
					'n'    => (int) $n,
				);
			}
		};

		foreach ( $map['types'] as $type ) {
			if ( $type['archive'] ) {
				$add( $type['label'], $type['archive']['url'], __( 'Section of the site', 'mvweb-core' ), $type['total'] );
			}

			foreach ( $type['items'] as $item ) {
				$add( $item['name'], $item['url'], $type['label'], isset( $item['n'] ) ? $item['n'] : 0 );
			}

			$walk = static function ( array $groups, $above ) use ( &$walk, $add, $type ) {
				foreach ( $groups as $group ) {
					$add( $group['name'], $group['url'], '' === $above ? $type['label'] : $type['label'] . ' · ' . $above, $group['total'] );

					foreach ( $group['items'] as $item ) {
						$add( $item['name'], $item['url'], $type['label'] . ' · ' . $group['name'] );
					}

					$walk( $group['subs'], $group['name'] );
				}
			};

			$walk( $type['groups'], '' );
		}

		$rows    = array_values( $rows );
		$collate = class_exists( 'Collator' ) ? new Collator( get_locale() ) : null;

		usort(
			$rows,
			static function ( $a, $b ) use ( $collate ) {
				return $collate ? (int) $collate->compare( $a['name'], $b['name'] ) : strcmp( mb_strtolower( $a['name'] ), mb_strtolower( $b['name'] ) );
			}
		);

		/* translators: The letters of the index of the sitemap, in the order of the alphabet of the site language, without the letters no word starts with. */
		$alphabet = preg_split( '//u', __( 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'mvweb-core' ), -1, PREG_SPLIT_NO_EMPTY );
		$letters  = array();

		foreach ( $rows as $row ) {
			$first = mb_strtoupper( mb_substr( (string) preg_replace( '/^[\s«"\'(]+/u', '', $row['name'] ), 0, 1 ) );
			$first = 'Ё' === $first ? 'Е' : $first;

			if ( in_array( $first, $alphabet, true ) ) {
				$key = $first;
			} elseif ( preg_match( '/^[A-Z]$/', $first ) ) {
				$key = 'A–Z';
			} else {
				$key = '0–9';
			}

			$letters[ $key ][] = $row;
		}

		$order = array_merge( $alphabet, array( 'A–Z', '0–9' ) );

		uksort(
			$letters,
			static function ( $a, $b ) use ( $order ) {
				return array_search( $a, $order, true ) <=> array_search( $b, $order, true );
			}
		);

		return array(
			'alphabet' => $alphabet,
			'letters'  => $letters,
		);
	}
}

if ( ! function_exists( 'mvweb_core_sitemap_styles' ) ) {
	/**
	 * The stylesheet of the sitemap on its page.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Keys of the request.
	 *
	 * @return string[]
	 */
	function mvweb_core_sitemap_styles( $styles ) {
		if ( mvweb_core_is_sitemap() ) {
			$styles[] = mvweb_core_sitemap()['types'] ? 'sitemap' : 'empty';
		}

		return $styles;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_core_sitemap_styles' );

if ( ! function_exists( 'mvweb_core_sitemap_script' ) ) {
	/**
	 * The script module of the sitemap: the buttons of the tree and the search of the contents.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules Script modules of the request.
	 *
	 * @return string[]
	 */
	function mvweb_core_sitemap_script( $modules ) {
		if ( mvweb_core_is_sitemap() && in_array( mvweb_core_sitemap_settings()['view'], array( 'tree', 'toc' ), true ) ) {
			$modules[] = 'sitemap';
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_core_sitemap_script' );
