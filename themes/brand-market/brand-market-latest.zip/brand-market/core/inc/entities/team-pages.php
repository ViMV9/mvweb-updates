<?php
/**
 * Pages of the doctors: the listing, a speciality and a doctor.
 *
 * It comes with add_theme_support( 'mvweb-team-pages' ) and the module Team
 * switched on. Then the team member becomes a doctor with a page of its own:
 * the type mv_person turns public, gets the speciality, the facts of a doctor
 * (practice since, degree, category, age of patients, price, branches,
 * education, certificates, services) and the data the theme prints. Without
 * the flag nothing here registers or prints anything. The markup of the pages,
 * their looks and the card stay in the theme.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_team_pages_on' ) ) {
	/**
	 * Whether the doctors have pages: the theme draws them and the module Team is on.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_team_pages_on() {
		return current_theme_supports( 'mvweb-team-pages' ) && mvweb_core_module( 'team' );
	}
}

if ( ! function_exists( 'mvweb_core_team_defaults' ) ) {
	/**
	 * Values of the settings of the doctors that nobody has changed.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_team_defaults() {
		return array(
			'mvweb_team_label'    => __( 'Doctors', 'mvweb-core' ),
			'mvweb_team_slug'     => 'doctors',
			'mvweb_team_per_page' => 12,
		);
	}
}

if ( ! function_exists( 'mvweb_core_team_option' ) ) {
	/**
	 * A setting of the doctors.
	 *
	 * @since 0.1.0
	 *
	 * @param string $key Setting name.
	 *
	 * @return mixed The saved value, the default while nothing is saved.
	 */
	function mvweb_core_team_option( $key ) {
		$defaults = mvweb_core_team_defaults();

		return get_theme_mod( $key, isset( $defaults[ $key ] ) ? $defaults[ $key ] : '' );
	}
}

if ( ! function_exists( 'mvweb_core_team_label' ) ) {
	/**
	 * The name of the section of the doctors in menus and headings.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_team_label() {
		$label = trim( (string) mvweb_core_team_option( 'mvweb_team_label' ) );

		return '' !== $label ? $label : (string) mvweb_core_team_defaults()['mvweb_team_label'];
	}
}

if ( ! function_exists( 'mvweb_core_team_slug' ) ) {
	/**
	 * The base of the addresses of the doctors.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_team_slug() {
		$slug = sanitize_title( (string) mvweb_core_team_option( 'mvweb_team_slug' ) );

		return '' !== $slug ? $slug : 'doctors';
	}
}

if ( ! function_exists( 'mvweb_core_is_doctors' ) ) {
	/**
	 * Whether the request is the listing of the doctors or of a speciality.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_is_doctors() {
		return mvweb_core_team_pages_on() && ( is_post_type_archive( 'mv_person' ) || is_tax( 'mv_speciality' ) );
	}
}

if ( ! function_exists( 'mvweb_core_is_doctor' ) ) {
	/**
	 * Whether the request is the page of a doctor.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_is_doctor() {
		return mvweb_core_team_pages_on() && is_singular( 'mv_person' );
	}
}

if ( ! function_exists( 'mvweb_core_team_register_taxonomy' ) ) {
	/**
	 * Register the specialities of the doctors.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_team_register_taxonomy() {
		if ( ! mvweb_core_team_pages_on() ) {
			return;
		}

		register_taxonomy(
			'mv_speciality',
			'mv_person',
			array(
				'labels'            => array(
					'name'          => __( 'Specialities', 'mvweb-core' ),
					'singular_name' => __( 'Speciality', 'mvweb-core' ),
					'add_new_item'  => __( 'Add speciality', 'mvweb-core' ),
					'edit_item'     => __( 'Edit speciality', 'mvweb-core' ),
					'search_items'  => __( 'Search specialities', 'mvweb-core' ),
					'not_found'     => __( 'No specialities yet', 'mvweb-core' ),
					'menu_name'     => __( 'Specialities', 'mvweb-core' ),
				),
				'hierarchical'      => true,
				'public'            => true,
				'show_in_rest'      => true,
				'show_admin_column' => true,
				'rewrite'           => array(
					'slug'         => mvweb_core_team_slug(),
					'with_front'   => false,
					'hierarchical' => true,
				),
			)
		);
	}
}
add_action( 'init', 'mvweb_core_team_register_taxonomy', 9 );

if ( ! function_exists( 'mvweb_core_team_post_type_args' ) ) {
	/**
	 * Make the team member a doctor with a page: public, with a listing, the text and the short text.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $args      Arguments of the type.
	 * @param string              $post_type Type name.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_team_post_type_args( $args, $post_type ) {
		if ( 'mv_person' !== $post_type || ! mvweb_core_team_pages_on() ) {
			return $args;
		}

		$name = mvweb_core_team_label();
		$base = mvweb_core_team_slug();

		$args['labels'] = array_merge(
			isset( $args['labels'] ) ? (array) $args['labels'] : array(),
			array(
				'name'               => $name,
				'singular_name'      => __( 'Doctor', 'mvweb-core' ),
				'add_new_item'       => __( 'Add doctor', 'mvweb-core' ),
				'edit_item'          => __( 'Edit doctor', 'mvweb-core' ),
				'new_item'           => __( 'New doctor', 'mvweb-core' ),
				'view_item'          => __( 'View doctor', 'mvweb-core' ),
				'search_items'       => __( 'Search doctors', 'mvweb-core' ),
				'not_found'          => __( 'No doctors yet', 'mvweb-core' ),
				'not_found_in_trash' => __( 'No doctors in the bin', 'mvweb-core' ),
				'all_items'          => $name,
				'menu_name'          => $name,
				'archives'           => $name,
			)
		);

		$args['description']         = __( 'Doctors with a page each: speciality, experience, price, branches, education and services.', 'mvweb-core' );
		$args['public']              = true;
		$args['publicly_queryable']  = true;
		$args['exclude_from_search'] = false;
		$args['show_in_nav_menus']   = true;
		$args['show_in_rest']        = false;
		$args['has_archive']         = $base;
		$args['query_var']           = true;
		$args['rewrite']             = array(
			'slug'       => $base . '/%mv_speciality%',
			'with_front' => false,
		);
		$args['supports']            = array( 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' );

		return $args;
	}
}
add_filter( 'register_post_type_args', 'mvweb_core_team_post_type_args', 10, 2 );

if ( ! function_exists( 'mvweb_core_team_nested_types' ) ) {
	/**
	 * The doctor lives under its speciality in the address, as a work lives under its kind.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $types Type => taxonomy.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_team_nested_types( $types ) {
		if ( mvweb_core_team_pages_on() ) {
			$types['mv_person'] = 'mv_speciality';
		}

		return $types;
	}
}
add_filter( 'mvweb_core_nested_types', 'mvweb_core_team_nested_types' );

if ( ! function_exists( 'mvweb_core_team_flush_rewrites' ) ) {
	/**
	 * Rebuild the address rules when the base of the doctors, or their being on, changed.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_team_flush_rewrites() {
		$fingerprint = mvweb_core_team_pages_on() ? md5( mvweb_core_team_slug() ) : '';

		if ( (string) get_option( 'mvweb_core_rewrites_team', '' ) === $fingerprint ) {
			return;
		}

		update_option( 'mvweb_core_rewrites_team', $fingerprint, true );

		flush_rewrite_rules( false );
	}
}
add_action( 'init', 'mvweb_core_team_flush_rewrites', 21 );

if ( ! function_exists( 'mvweb_core_team_sanitize_year' ) ) {
	/**
	 * The year a doctor began to practise, or 0 for anything that is not a year from 1950 to this one.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return int
	 */
	function mvweb_core_team_sanitize_year( $value ) {
		$year = absint( $value );

		return $year >= 1950 && $year <= (int) wp_date( 'Y' ) ? $year : 0;
	}
}

if ( ! function_exists( 'mvweb_core_team_sanitize_services' ) ) {
	/**
	 * The services of a doctor as they are stored: up to twelve ids of services, in the order given.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value List of ids, or a comma-separated string.
	 *
	 * @return string Comma-separated ids.
	 */
	function mvweb_core_team_sanitize_services( $value ) {
		$ids   = is_array( $value ) ? $value : explode( ',', (string) $value );
		$clean = array();

		foreach ( $ids as $id ) {
			$id = mvweb_core_sanitize_service_id( $id );

			if ( $id > 0 && ! in_array( $id, $clean, true ) ) {
				$clean[] = $id;
			}
		}

		return implode( ',', array_slice( $clean, 0, 12 ) );
	}
}

if ( ! function_exists( 'mvweb_core_team_meta' ) ) {
	/**
	 * The facts of a doctor kept in meta: key => type, sanitizer and whether one value or many.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array{type:string,sanitize:string,single:bool}>
	 */
	function mvweb_core_team_meta() {
		return array(
			'_mvweb_exp_since' => array(
				'type'     => 'integer',
				'sanitize' => 'mvweb_core_team_sanitize_year',
				'single'   => true,
			),
			'_mvweb_degree'    => array(
				'type'     => 'string',
				'sanitize' => 'sanitize_text_field',
				'single'   => true,
			),
			'_mvweb_category'  => array(
				'type'     => 'string',
				'sanitize' => 'sanitize_text_field',
				'single'   => true,
			),
			'_mvweb_age_from'  => array(
				'type'     => 'string',
				'sanitize' => 'sanitize_text_field',
				'single'   => true,
			),
			'_mvweb_price'     => array(
				'type'     => 'string',
				'sanitize' => 'sanitize_text_field',
				'single'   => true,
			),
			'_mvweb_branches'  => array(
				'type'     => 'integer',
				'sanitize' => 'absint',
				'single'   => false,
			),
			'_mvweb_education' => array(
				'type'     => 'string',
				'sanitize' => 'sanitize_textarea_field',
				'single'   => true,
			),
			'_mvweb_certs'     => array(
				'type'     => 'string',
				'sanitize' => 'sanitize_textarea_field',
				'single'   => true,
			),
			'_mvweb_services'  => array(
				'type'     => 'string',
				'sanitize' => 'mvweb_core_team_sanitize_services',
				'single'   => true,
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_team_register_meta' ) ) {
	/**
	 * Register the facts of a doctor with their types and cleaning.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_team_register_meta() {
		if ( ! mvweb_core_team_pages_on() ) {
			return;
		}

		foreach ( mvweb_core_team_meta() as $key => $meta ) {
			$args = array(
				'type'              => $meta['type'],
				'single'            => $meta['single'],
				'sanitize_callback' => $meta['sanitize'],
				'auth_callback'     => 'mvweb_core_post_meta_auth',
				'show_in_rest'      => false,
			);

			if ( $meta['single'] ) {
				$args['default'] = 'integer' === $meta['type'] ? 0 : '';
			}

			register_post_meta( 'mv_person', $key, $args );
		}
	}
}
add_action( 'init', 'mvweb_core_team_register_meta', 6 );

if ( ! function_exists( 'mvweb_core_team_age_months' ) ) {
	/**
	 * The age a doctor sees patients from, in months, read out of the line the owner typed.
	 *
	 * The line is read for a number followed by a unit: «мес» or «mon» count
	 * months, «год», «лет», «yea» and «yr» count years, so «6 лет», «от 3 месяцев»,
	 * «1,5 года» and «6+ лет» are read. A line without a number and a unit is not read.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $text The line, for example «6 лет».
	 *
	 * @return int|null Months; -1 when the line is not read; null for an empty line.
	 */
	function mvweb_core_team_age_months( $text ) {
		$text = trim( (string) $text );

		if ( '' === $text ) {
			return null;
		}

		if ( ! preg_match( '/(\d+(?:[.,]\d+)?)\+?\s*(мес|год|лет|mon|yea|yr)/iu', $text, $found ) ) {
			return -1;
		}

		$number = (float) str_replace( ',', '.', $found[1] );

		return (int) round( in_array( mb_strtolower( $found[2] ), array( 'мес', 'mon' ), true ) ? $number : $number * 12 );
	}
}

if ( ! function_exists( 'mvweb_core_team_price_number' ) ) {
	/**
	 * The first number of a price typed as a line, to sort the doctors by it.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $text The line, for example «2 800 ₽».
	 *
	 * @return int|null Null when the line holds no number.
	 */
	function mvweb_core_team_price_number( $text ) {
		if ( ! preg_match( '/\d+(?:[\s\x{00A0}\x{202F}]\d{3})*/u', (string) $text, $found ) ) {
			return null;
		}

		return (int) preg_replace( '/\D/', '', $found[0] );
	}
}

if ( ! function_exists( 'mvweb_core_team_derive' ) ) {
	/**
	 * Keep the numbers the listing filters and sorts by next to the lines they come from.
	 *
	 * @since 0.1.0
	 *
	 * @param int|int[] $meta_id  Id of the meta row; not used.
	 * @param int       $post_id  Post the meta belongs to.
	 * @param string    $meta_key Key that changed.
	 *
	 * @return void
	 */
	function mvweb_core_team_derive( $meta_id, $post_id, $meta_key ) {
		if ( ! in_array( $meta_key, array( '_mvweb_age_from', '_mvweb_price' ), true ) || ! mvweb_core_team_pages_on() || 'mv_person' !== get_post_type( $post_id ) ) {
			return;
		}

		$derived = array(
			'_mvweb_age_months' => mvweb_core_team_age_months( get_post_meta( $post_id, '_mvweb_age_from', true ) ),
			'_mvweb_price_num'  => mvweb_core_team_price_number( get_post_meta( $post_id, '_mvweb_price', true ) ),
		);

		foreach ( $derived as $key => $value ) {
			if ( null === $value ) {
				delete_post_meta( $post_id, $key );
			} else {
				update_post_meta( $post_id, $key, $value );
			}
		}
	}
}
add_action( 'added_post_meta', 'mvweb_core_team_derive', 10, 3 );
add_action( 'updated_post_meta', 'mvweb_core_team_derive', 10, 3 );
add_action( 'deleted_post_meta', 'mvweb_core_team_derive', 10, 3 );

if ( ! function_exists( 'mvweb_core_team_meta_boxes' ) ) {
	/**
	 * Add the box of the facts of a doctor to the screen of the doctor.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_team_meta_boxes() {
		if ( mvweb_core_team_pages_on() ) {
			add_meta_box( 'mvweb-core-doctor', __( 'Doctor', 'mvweb-core' ), 'mvweb_core_doctor_box', 'mv_person', 'normal', 'default' );
		}
	}
}
add_action( 'add_meta_boxes', 'mvweb_core_team_meta_boxes' );

if ( ! function_exists( 'mvweb_core_team_service_choices' ) ) {
	/**
	 * Published services a doctor can be linked to, by name.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,string> Id => title.
	 */
	function mvweb_core_team_service_choices() {
		$choices = array();

		foreach (
			get_posts(
				array(
					'post_type'      => 'mv_service',
					'post_status'    => 'publish',
					'posts_per_page' => 500, // phpcs:ignore WordPress.WP.PostsPerPage.posts_per_page_posts_per_page -- One box on one admin screen.
					'orderby'        => 'title',
					'order'          => 'ASC',
					'no_found_rows'  => true,
				)
			) as $service
		) {
			$choices[ $service->ID ] = get_the_title( $service );
		}

		return $choices;
	}
}

if ( ! function_exists( 'mvweb_core_doctor_box' ) ) {
	/**
	 * The fields of a doctor.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Post being edited.
	 *
	 * @return void
	 */
	function mvweb_core_doctor_box( $post ) {
		wp_nonce_field( 'mvweb_doctor', 'mvweb_doctor_nonce' );

		$value    = static function ( $key ) use ( $post ) {
			return (string) get_post_meta( $post->ID, $key, true );
		};
		$since    = mvweb_core_team_sanitize_year( $value( '_mvweb_exp_since' ) );
		$marked   = array_map( 'absint', get_post_meta( $post->ID, '_mvweb_branches', false ) );
		$chosen   = array_map( 'absint', array_filter( explode( ',', $value( '_mvweb_services' ) ) ) );
		$branches = mvweb_core_branches();
		$services = mvweb_core_team_service_choices();
		?>
		<table class="form-table" role="presentation">
			<tbody>
				<tr>
					<th scope="row"><label for="mvweb-core-exp-since"><?php esc_html_e( 'Practising since', 'mvweb-core' ); ?></label></th>
					<td>
						<input type="number" class="small-text" id="mvweb-core-exp-since" name="mvweb_exp_since" min="1950" max="<?php echo esc_attr( wp_date( 'Y' ) ); ?>" step="1" value="<?php echo esc_attr( $since ? (string) $since : '' ); ?>">
						<p class="description"><?php esc_html_e( 'The year. The page counts the years of experience from it.', 'mvweb-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="mvweb-core-degree"><?php esc_html_e( 'Degree or title', 'mvweb-core' ); ?></label></th>
					<td><input type="text" class="regular-text" id="mvweb-core-degree" name="mvweb_degree" value="<?php echo esc_attr( $value( '_mvweb_degree' ) ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="mvweb-core-category"><?php esc_html_e( 'Category', 'mvweb-core' ); ?></label></th>
					<td><input type="text" class="regular-text" id="mvweb-core-category" name="mvweb_category" value="<?php echo esc_attr( $value( '_mvweb_category' ) ); ?>"></td>
				</tr>
				<tr>
					<th scope="row"><label for="mvweb-core-age-from"><?php esc_html_e( 'Sees patients from', 'mvweb-core' ); ?></label></th>
					<td>
						<input type="text" class="regular-text" id="mvweb-core-age-from" name="mvweb_age_from" value="<?php echo esc_attr( $value( '_mvweb_age_from' ) ); ?>">
						<p class="description"><?php esc_html_e( 'A number with a unit: 6 years, 3 months. The listing sorts doctors into adults and children by it; empty means adults only.', 'mvweb-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="mvweb-core-doctor-price"><?php esc_html_e( 'Price of a visit', 'mvweb-core' ); ?></label></th>
					<td>
						<input type="text" class="regular-text" id="mvweb-core-doctor-price" name="mvweb_price" value="<?php echo esc_attr( $value( '_mvweb_price' ) ); ?>">
						<p class="description"><?php esc_html_e( 'Typed as it should read, for example 2 800 ₽. The first number sorts the listing by price.', 'mvweb-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Branches', 'mvweb-core' ); ?></th>
					<td>
						<?php if ( empty( $branches ) ) : ?>
							<p class="description"><?php esc_html_e( 'The list of branches is empty. Add branches in the Customizer, in the section Branches and cities.', 'mvweb-core' ); ?></p>
						<?php else : ?>
							<fieldset>
								<?php foreach ( $branches as $branch ) : ?>
									<label>
										<input type="checkbox" name="mvweb_branches[]" value="<?php echo absint( $branch['id'] ); ?>" <?php checked( in_array( (int) $branch['id'], $marked, true ) ); ?>>
										<?php echo esc_html( trim( $branch['title'] . ( '' !== $branch['address'] ? ', ' . $branch['address'] : '' ), ', ' ) ); ?>
									</label><br>
								<?php endforeach; ?>
							</fieldset>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="mvweb-core-education"><?php esc_html_e( 'Education and courses', 'mvweb-core' ); ?></label></th>
					<td>
						<textarea class="large-text" rows="5" id="mvweb-core-education" name="mvweb_education"><?php echo esc_textarea( $value( '_mvweb_education' ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One per line: years | name | place. For example: 2004–2010 | Pediatrics | First Medical University.', 'mvweb-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="mvweb-core-certs"><?php esc_html_e( 'Certificates', 'mvweb-core' ); ?></label></th>
					<td>
						<textarea class="large-text" rows="4" id="mvweb-core-certs" name="mvweb_certs"><?php echo esc_textarea( $value( '_mvweb_certs' ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'One per line: name | valid until. For example: Specialist certificate | 2029.', 'mvweb-core' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Services', 'mvweb-core' ); ?></th>
					<td>
						<?php if ( empty( $services ) ) : ?>
							<p class="description"><?php esc_html_e( 'There are no published services to choose from.', 'mvweb-core' ); ?></p>
						<?php else : ?>
							<fieldset style="max-height:220px;overflow:auto">
								<?php foreach ( $services as $service_id => $service_title ) : ?>
									<label>
										<input type="checkbox" name="mvweb_services[]" value="<?php echo absint( $service_id ); ?>" <?php checked( in_array( (int) $service_id, $chosen, true ) ); ?>>
										<?php echo esc_html( $service_title ); ?>
									</label><br>
								<?php endforeach; ?>
							</fieldset>
							<p class="description"><?php esc_html_e( 'Up to 12 services; the first twelve ticked are kept.', 'mvweb-core' ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
			</tbody>
		</table>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_doctor_save' ) ) {
	/**
	 * Store what the box of a doctor submitted.
	 *
	 * @since 0.1.0
	 *
	 * @param int     $post_id Post being saved.
	 * @param WP_Post $post    Post object.
	 *
	 * @return void
	 */
	function mvweb_core_doctor_save( $post_id, $post ) {
		if ( 'mv_person' !== $post->post_type || ! mvweb_core_team_pages_on() || wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST['mvweb_doctor_nonce'] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mvweb_doctor_nonce'] ) ), 'mvweb_doctor' ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$inputs = array(
			'_mvweb_exp_since' => 'mvweb_exp_since',
			'_mvweb_degree'    => 'mvweb_degree',
			'_mvweb_category'  => 'mvweb_category',
			'_mvweb_age_from'  => 'mvweb_age_from',
			'_mvweb_price'     => 'mvweb_price',
			'_mvweb_education' => 'mvweb_education',
			'_mvweb_certs'     => 'mvweb_certs',
		);
		$meta   = mvweb_core_team_meta();

		foreach ( $inputs as $key => $input ) {
			$raw   = isset( $_POST[ $input ] ) ? wp_unslash( $_POST[ $input ] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Cleaned by the callback the key is registered with, on the next line.
			$clean = call_user_func( $meta[ $key ]['sanitize'], $raw );

			if ( '' === $clean || 0 === $clean ) {
				delete_post_meta( $post_id, $key );
			} else {
				update_post_meta( $post_id, $key, $clean );
			}
		}

		$known    = wp_list_pluck( mvweb_core_branches(), 'id' );
		$branches = isset( $_POST['mvweb_branches'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['mvweb_branches'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Each value goes through absint().

		delete_post_meta( $post_id, '_mvweb_branches' );

		foreach ( array_unique( array_intersect( $branches, array_map( 'absint', $known ) ) ) as $branch ) {
			add_post_meta( $post_id, '_mvweb_branches', $branch );
		}

		$services = mvweb_core_team_sanitize_services( isset( $_POST['mvweb_services'] ) ? (array) wp_unslash( $_POST['mvweb_services'] ) : array() ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Each id is checked to be a service.

		if ( '' === $services ) {
			delete_post_meta( $post_id, '_mvweb_services' );
		} else {
			update_post_meta( $post_id, '_mvweb_services', $services );
		}
	}
}
add_action( 'save_post_mv_person', 'mvweb_core_doctor_save', 10, 2 );

if ( ! function_exists( 'mvweb_core_team_lines' ) ) {
	/**
	 * Split the lines of a field into cells at the bar.
	 *
	 * @since 0.1.0
	 *
	 * @param string $text  Text, one row to a line.
	 * @param int    $cells How many cells a row has.
	 *
	 * @return array<int,string[]> Rows of exactly that many cells, empty rows left out.
	 */
	function mvweb_core_team_lines( $text, $cells ) {
		$rows = array();

		foreach ( mvweb_core_text_lines( $text ) as $line ) {
			$row = array_pad( array_map( 'trim', explode( '|', $line, $cells ) ), $cells, '' );

			if ( '' !== implode( '', $row ) ) {
				$rows[] = $row;
			}
		}

		return $rows;
	}
}

if ( ! function_exists( 'mvweb_core_doctor' ) ) {
	/**
	 * Everything a template prints about a doctor.
	 *
	 * @since 0.1.0
	 *
	 * @param int  $id            Doctor id.
	 * @param bool $with_services Optional. False leaves the services out, for a card that does not print them.
	 *
	 * @return array<string,mixed> Empty when the id is not a doctor. Keys: id, name, url (empty while the pages are off), role, photo (attachment id), exp (years, 0 when unknown), exp_since, degree, category, age_from, price, branches (id, title, address, url), education (years, title, place), certs (title, term), services (id, title, url, price), booking, bio, specialities (terms).
	 */
	function mvweb_core_doctor( $id, $with_services = true ) {
		$id   = absint( $id );
		$post = $id ? get_post( $id ) : null;

		if ( ! $post instanceof WP_Post || 'mv_person' !== $post->post_type ) {
			return array();
		}

		$text  = static function ( $key ) use ( $id ) {
			return trim( (string) get_post_meta( $id, $key, true ) );
		};
		$since = mvweb_core_team_sanitize_year( $text( '_mvweb_exp_since' ) );

		$marked   = array_map( 'absint', get_post_meta( $id, '_mvweb_branches', false ) );
		$branches = array();

		foreach ( mvweb_core_branches() as $branch ) {
			if ( ! in_array( (int) $branch['id'], $marked, true ) ) {
				continue;
			}

			$row = array(
				'id'      => (int) $branch['id'],
				'title'   => (string) $branch['title'],
				'address' => (string) $branch['address'],
			);
			$url = '' !== (string) $branch['route_url'] ? (string) $branch['route_url'] : (string) $branch['map_link'];

			if ( '' !== $url ) {
				$row['url'] = $url;
			}

			$branches[] = $row;
		}

		$education = array();

		foreach ( mvweb_core_team_lines( $text( '_mvweb_education' ), 3 ) as $row ) {
			$education[] = array(
				'years' => $row[0],
				'title' => $row[1],
				'place' => $row[2],
			);
		}

		$certs = array();

		foreach ( mvweb_core_team_lines( $text( '_mvweb_certs' ), 2 ) as $row ) {
			$certs[] = array(
				'title' => $row[0],
				'term'  => $row[1],
			);
		}

		$services = array();

		if ( $with_services ) {
			$ids = array_slice( array_filter( array_map( 'absint', explode( ',', $text( '_mvweb_services' ) ) ) ), 0, 12 );

			foreach ( $ids as $service_id ) {
				$service = get_post( $service_id );

				if ( $service instanceof WP_Post && 'mv_service' === $service->post_type && 'publish' === $service->post_status ) {
					$services[] = array(
						'id'    => $service_id,
						'title' => get_the_title( $service ),
						'url'   => (string) get_permalink( $service ),
						'price' => mvweb_core_item_price_html( $service_id ),
					);
				}
			}
		}

		$terms = get_the_terms( $id, 'mv_speciality' );

		return array(
			'id'           => $id,
			'name'         => get_the_title( $post ),
			'url'          => mvweb_core_team_pages_on() ? (string) get_permalink( $post ) : '',
			'role'         => $text( '_mvweb_role' ),
			'photo'        => (int) get_post_thumbnail_id( $post ),
			'exp'          => $since ? max( 0, (int) wp_date( 'Y' ) - $since ) : 0,
			'exp_since'    => $since,
			'degree'       => $text( '_mvweb_degree' ),
			'category'     => $text( '_mvweb_category' ),
			'age_from'     => $text( '_mvweb_age_from' ),
			'price'        => $text( '_mvweb_price' ),
			'branches'     => $branches,
			'education'    => $education,
			'certs'        => $certs,
			'services'     => $services,
			'booking'      => $text( '_mvweb_booking_url' ),
			'bio'          => $text( '_mvweb_bio' ),
			'specialities' => is_array( $terms ) ? array_values( $terms ) : array(),
		);
	}
}

if ( ! function_exists( 'mvweb_core_team_person_extra' ) ) {
	/**
	 * What the card of a team member gets besides the role, the text and the booking address.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Team member id.
	 *
	 * @return array{id:int,page:string,exp:int,price:string,degree:string,category:string,age_from:string,branches:array} The page address is empty while the pages are off.
	 */
	function mvweb_core_team_person_extra( $id ) {
		$doctor = mvweb_core_team_pages_on() ? mvweb_core_doctor( $id, false ) : array();

		return array(
			'id'       => absint( $id ),
			'page'     => isset( $doctor['url'] ) ? $doctor['url'] : '',
			'exp'      => isset( $doctor['exp'] ) ? $doctor['exp'] : 0,
			'price'    => isset( $doctor['price'] ) ? $doctor['price'] : '',
			'degree'   => isset( $doctor['degree'] ) ? $doctor['degree'] : '',
			'category' => isset( $doctor['category'] ) ? $doctor['category'] : '',
			'age_from' => isset( $doctor['age_from'] ) ? $doctor['age_from'] : '',
			'branches' => isset( $doctor['branches'] ) ? $doctor['branches'] : array(),
		);
	}
}

if ( ! function_exists( 'mvweb_core_doctors_prime' ) ) {
	/**
	 * Load the posts, terms, meta and photos of a list of doctors, and their services, in one query each.
	 *
	 * @since 0.1.0
	 *
	 * @param int[] $ids Doctor ids.
	 *
	 * @return int[] The same ids, cleaned.
	 */
	function mvweb_core_doctors_prime( $ids ) {
		$ids = mvweb_core_prime_items( $ids );

		if ( count( $ids ) < 2 ) {
			return $ids;
		}

		$services = array();

		foreach ( $ids as $id ) {
			$services = array_merge( $services, array_slice( array_map( 'absint', explode( ',', (string) get_post_meta( $id, '_mvweb_services', true ) ) ), 0, 12 ) );
		}

		$services = array_values( array_unique( array_filter( $services ) ) );

		if ( $services ) {
			_prime_post_caches( $services, true, true );
		}

		return $ids;
	}
}

if ( ! function_exists( 'mvweb_core_doctors_orders' ) ) {
	/**
	 * The orders a list of doctors can take.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Value => label.
	 */
	function mvweb_core_doctors_orders() {
		return array(
			'menu_order' => __( 'As arranged', 'mvweb-core' ),
			'exp'        => __( 'By experience', 'mvweb-core' ),
			'price'      => __( 'By price, cheapest first', 'mvweb-core' ),
			'alpha'      => __( 'By name', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_doctors_audiences' ) ) {
	/**
	 * The kinds of patients a list of doctors can be narrowed to.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Value => label.
	 */
	function mvweb_core_doctors_audiences() {
		return array(
			'all'   => __( 'All patients', 'mvweb-core' ),
			'adult' => __( 'Adults', 'mvweb-core' ),
			'kids'  => __( 'Children', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_doctors_query_vars' ) ) {
	/**
	 * The query variables for a list of doctors.
	 *
	 * Adults are the doctors who see patients from 12 years or do not name an
	 * age. Children are the doctors who see patients from 17 years or younger.
	 * A doctor whose age line cannot be read is in both lists. The ages are
	 * kept in months in _mvweb_age_months (see mvweb_core_team_age_months()).
	 *
	 * @since 0.1.0
	 *
	 * @param array $args Optional. 'speciality' (term id), 'branch' (branch id), 'audience' (all, adult, kids), 'search' (part of the name), 'orderby' (menu_order, exp, price, alpha), 'count', 'paged'.
	 *
	 * @return array<string,mixed>
	 */
	function mvweb_core_doctors_query_vars( array $args ) {
		$vars = array(
			'tax_query'  => array(), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Filled only when the visitor asks for a speciality.
			'meta_query' => array(), // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Filled only when the visitor asks for a branch or an age.
		);

		if ( ! empty( $args['speciality'] ) ) {
			$vars['tax_query'][] = array(
				'taxonomy' => 'mv_speciality',
				'terms'    => absint( $args['speciality'] ),
			);
		}

		if ( ! empty( $args['branch'] ) ) {
			$vars['meta_query'][] = array(
				'key'   => '_mvweb_branches',
				'value' => absint( $args['branch'] ),
			);
		}

		$audience = isset( $args['audience'] ) ? (string) $args['audience'] : 'all';

		if ( 'adult' === $audience ) {
			$vars['meta_query'][] = array(
				'relation' => 'OR',
				array(
					'key'     => '_mvweb_age_months',
					'compare' => 'NOT EXISTS',
				),
				array(
					'key'   => '_mvweb_age_months',
					'value' => -1,
					'type'  => 'SIGNED',
				),
				array(
					'key'     => '_mvweb_age_months',
					'value'   => 144,
					'compare' => '>=',
					'type'    => 'SIGNED',
				),
			);
		} elseif ( 'kids' === $audience ) {
			$vars['meta_query'][] = array(
				'key'     => '_mvweb_age_months',
				'value'   => array( -1, 204 ),
				'compare' => 'BETWEEN',
				'type'    => 'SIGNED',
			);
		}

		$search = isset( $args['search'] ) ? trim( (string) $args['search'] ) : '';

		if ( '' !== $search ) {
			$vars['s']              = $search;
			$vars['search_columns'] = array( 'post_title' );
		}

		$order = isset( $args['orderby'] ) ? (string) $args['orderby'] : 'menu_order';

		if ( 'alpha' === $order ) {
			$vars['orderby'] = array( 'title' => 'ASC' );
		} else {
			$vars['orderby'] = array(
				'menu_order' => 'ASC',
				'title'      => 'ASC',
			);

			if ( in_array( $order, array( 'exp', 'price' ), true ) ) {
				$vars['mvweb_doctor_order'] = $order;
			}
		}

		return array_filter( $vars );
	}
}

if ( ! function_exists( 'mvweb_core_doctors' ) ) {
	/**
	 * Published doctors by the filters, in the chosen order.
	 *
	 * @since 0.1.0
	 *
	 * @param array $args Optional. 'speciality' (term id), 'branch' (branch id), 'audience' (all, adult, kids), 'search' (part of the name), 'orderby' (menu_order, exp, price, alpha), 'count' (0 for all), 'paged'.
	 *
	 * @return int[]
	 */
	function mvweb_core_doctors( array $args = array() ) {
		static $cache = array();

		$key = md5( (string) wp_json_encode( $args ) );

		if ( isset( $cache[ $key ] ) ) {
			return $cache[ $key ];
		}

		$count = isset( $args['count'] ) ? absint( $args['count'] ) : 0;
		$query = new WP_Query(
			array_merge(
				array(
					'post_type'      => 'mv_person',
					'post_status'    => 'publish',
					'posts_per_page' => $count > 0 ? $count : -1,
					'paged'          => isset( $args['paged'] ) ? max( 1, absint( $args['paged'] ) ) : 1,
					'fields'         => 'ids',
					'no_found_rows'  => true,
				),
				mvweb_core_doctors_query_vars( $args )
			)
		);

		$cache[ $key ] = mvweb_core_doctors_prime( array_map( 'absint', $query->posts ) );

		return $cache[ $key ];
	}
}

if ( ! function_exists( 'mvweb_core_doctors_request' ) ) {
	/**
	 * What the visitor asked in the address: the filters of the listing, cleaned.
	 *
	 * @since 0.1.0
	 *
	 * @return array{speciality:int,branch:int,audience:string,search:string,orderby:string}
	 */
	function mvweb_core_doctors_request() {
		$get = static function ( $key ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- The filters of a public listing change nothing.
			return isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ? sanitize_text_field( wp_unslash( (string) $_GET[ $key ] ) ) : '';
		};

		$speciality = 0;
		$slug       = sanitize_title( $get( 'speciality' ) );

		if ( '' !== $slug ) {
			$term       = get_term_by( 'slug', $slug, 'mv_speciality' );
			$speciality = $term instanceof WP_Term ? (int) $term->term_id : 0;
		}

		$branch   = absint( $get( 'branch' ) );
		$audience = sanitize_key( $get( 'audience' ) );
		$orderby  = sanitize_key( $get( 'sort' ) );

		return array(
			'speciality' => $speciality,
			'branch'     => in_array( $branch, array_map( 'absint', wp_list_pluck( mvweb_core_branches(), 'id' ) ), true ) ? $branch : 0,
			'audience'   => isset( mvweb_core_doctors_audiences()[ $audience ] ) ? $audience : 'all',
			'search'     => mb_substr( $get( 'find' ), 0, 80 ),
			'orderby'    => isset( mvweb_core_doctors_orders()[ $orderby ] ) ? $orderby : 'menu_order',
		);
	}
}

if ( ! function_exists( 'mvweb_core_doctors_filters' ) ) {
	/**
	 * What the form of the listing needs: the choices and the values now chosen.
	 *
	 * The form sends GET to 'action'. The names of the fields are speciality
	 * (slug of a speciality), branch (id of a branch), audience, find and sort.
	 *
	 * @since 0.1.0
	 *
	 * @return array{action:string,specialities:array,branches:array,audiences:array,orders:array,current:array,active:bool,names:array}
	 */
	function mvweb_core_doctors_filters() {
		$specialities = array();
		$terms        = get_terms(
			array(
				'taxonomy'   => 'mv_speciality',
				'hide_empty' => true,
				'pad_counts' => true,
				'orderby'    => 'name',
			)
		);

		foreach ( is_array( $terms ) ? $terms : array() as $term ) {
			$link = get_term_link( $term );

			$specialities[] = array(
				'id'    => (int) $term->term_id,
				'slug'  => $term->slug,
				'name'  => $term->name,
				'count' => (int) $term->count,
				'url'   => is_string( $link ) ? $link : '',
			);
		}

		$branches = array();

		foreach ( mvweb_core_branches() as $branch ) {
			$branches[] = array(
				'id'      => (int) $branch['id'],
				'title'   => (string) $branch['title'],
				'address' => (string) $branch['address'],
			);
		}

		$current = mvweb_core_doctors_request();

		if ( 0 === $current['speciality'] && is_tax( 'mv_speciality' ) ) {
			$current['speciality'] = (int) get_queried_object_id();
		}

		return array(
			'action'       => (string) get_post_type_archive_link( 'mv_person' ),
			'specialities' => $specialities,
			'branches'     => $branches,
			'audiences'    => mvweb_core_doctors_audiences(),
			'orders'       => mvweb_core_doctors_orders(),
			'current'      => $current,
			'active'       => $current['branch'] > 0 || 'all' !== $current['audience'] || '' !== $current['search'] || 'menu_order' !== $current['orderby'] || ( $current['speciality'] > 0 && ! is_tax( 'mv_speciality' ) ),
			'names'        => array(
				'speciality' => 'speciality',
				'branch'     => 'branch',
				'audience'   => 'audience',
				'search'     => 'find',
				'orderby'    => 'sort',
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_doctors_main_query' ) ) {
	/**
	 * The listing of the doctors: how many on a page, in what order, narrowed by the filters of the address.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Query $query Query being prepared.
	 *
	 * @return void
	 */
	function mvweb_core_doctors_main_query( $query ) {
		if ( is_admin() || ! $query->is_main_query() || ! current_theme_supports( 'mvweb-team-pages' ) ) {
			return;
		}

		if ( ! ( $query->is_post_type_archive( 'mv_person' ) || $query->is_tax( 'mv_speciality' ) ) || ! mvweb_core_team_pages_on() ) {
			return;
		}

		$query->set( 'posts_per_page', max( 1, absint( mvweb_core_team_option( 'mvweb_team_per_page' ) ) ) );

		foreach ( mvweb_core_doctors_query_vars( mvweb_core_doctors_request() ) as $name => $value ) {
			if ( in_array( $name, array( 'tax_query', 'meta_query' ), true ) ) {
				$value = array_merge( (array) $query->get( $name ), $value );
			}

			$query->set( $name, $value );
		}
	}
}
add_action( 'pre_get_posts', 'mvweb_core_doctors_main_query' );

if ( ! function_exists( 'mvweb_core_doctors_order_clauses' ) ) {
	/**
	 * Sort by a number kept in meta and put the doctors without one last.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $clauses SQL parts of the query.
	 * @param WP_Query             $query   Query being run.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_doctors_order_clauses( $clauses, $query ) {
		$order = $query->get( 'mvweb_doctor_order' );

		if ( ! in_array( $order, array( 'exp', 'price' ), true ) ) {
			return $clauses;
		}

		global $wpdb;

		$clauses['join']   .= $wpdb->prepare( " LEFT JOIN {$wpdb->postmeta} AS mvweb_doctor_sort ON ( mvweb_doctor_sort.post_id = {$wpdb->posts}.ID AND mvweb_doctor_sort.meta_key = %s )", 'exp' === $order ? '_mvweb_exp_since' : '_mvweb_price_num' ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Table names of $wpdb; the key is a placeholder.
		$clauses['orderby'] = "mvweb_doctor_sort.meta_value IS NULL ASC, CAST( mvweb_doctor_sort.meta_value AS SIGNED ) ASC, {$wpdb->posts}.menu_order ASC, {$wpdb->posts}.post_title ASC";

		return $clauses;
	}
}
add_filter( 'posts_clauses', 'mvweb_core_doctors_order_clauses', 10, 2 );

if ( ! function_exists( 'mvweb_core_doctors_loop_prime' ) ) {
	/**
	 * Load the photos and services of the doctors of a page in one query each before the cards are drawn.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post[] $posts Posts found.
	 * @param WP_Query  $query Query that found them.
	 *
	 * @return WP_Post[]
	 */
	function mvweb_core_doctors_loop_prime( $posts, $query ) {
		if ( $query->is_main_query() && current_theme_supports( 'mvweb-team-pages' ) && $posts && ( $query->is_post_type_archive( 'mv_person' ) || $query->is_tax( 'mv_speciality' ) ) ) {
			mvweb_core_doctors_prime( wp_list_pluck( $posts, 'ID' ) );
		}

		return $posts;
	}
}
add_filter( 'the_posts', 'mvweb_core_doctors_loop_prime', 10, 2 );

if ( ! function_exists( 'mvweb_core_team_tree' ) ) {
	/**
	 * The two sections of the doctors in the panel of the inner pages.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tree Panels with their sections.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_team_tree( $tree ) {
		if ( mvweb_core_team_pages_on() && isset( $tree['mvweb_cz_inner']['sections'] ) ) {
			$tree['mvweb_cz_inner']['sections']['mvweb_cz_team_list'] = __( 'Doctors: list', 'mvweb-core' );
			$tree['mvweb_cz_inner']['sections']['mvweb_cz_team_page'] = __( 'Doctors: doctor page', 'mvweb-core' );
		}

		return $tree;
	}
}
add_filter( 'mvweb_cz_baseline_tree', 'mvweb_core_team_tree', 101 );

if ( ! function_exists( 'mvweb_core_team_fields' ) ) {
	/**
	 * Fields of the section of the doctors.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_team_fields() {
		$defaults = mvweb_core_team_defaults();

		return array(
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_team_label',
				'section'     => 'mvweb_cz_team_list',
				'label'       => __( 'What the doctors are called', 'mvweb-core' ),
				'description' => __( 'In the admin menu and above the listing. Empty is "Doctors".', 'mvweb-core' ),
				'default'     => $defaults['mvweb_team_label'],
			),
			array(
				'type'        => 'text',
				'settings'    => 'mvweb_team_slug',
				'section'     => 'mvweb_cz_team_list',
				'label'       => __( 'Base of the addresses', 'mvweb-core' ),
				'description' => __( 'The listing lives at /base/, a speciality at /base/speciality/ and a doctor at /base/speciality/name/. Changing this on a live site breaks every address it already has.', 'mvweb-core' ),
				'default'     => $defaults['mvweb_team_slug'],
			),
			array(
				'type'        => 'number',
				'settings'    => 'mvweb_team_per_page',
				'section'     => 'mvweb_cz_team_list',
				'label'       => __( 'Doctors per page', 'mvweb-core' ),
				'default'     => $defaults['mvweb_team_per_page'],
				'input_attrs' => array(
					'min'  => 1,
					'max'  => 96,
					'step' => 1,
				),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_team_register_fields' ) ) {
	/**
	 * Hand the fields to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_team_register_fields( $kit ) {
		if ( mvweb_core_team_pages_on() ) {
			$kit->add_fields( mvweb_core_team_fields() );
		}
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_team_register_fields' );

if ( ! function_exists( 'mvweb_core_team_preview_pages' ) ) {
	/**
	 * Where the preview goes when a section of the doctors opens: the listing, the first doctor.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $pages Customizer section id => page address.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_team_preview_pages( $pages ) {
		if ( ! mvweb_core_team_pages_on() ) {
			return $pages;
		}

		$first = mvweb_core_doctors( array( 'count' => 1 ) );

		return array_merge(
			$pages,
			array_filter(
				array(
					'mvweb_cz_team_list' => (string) get_post_type_archive_link( 'mv_person' ),
					'mvweb_cz_team_page' => $first ? (string) get_permalink( $first[0] ) : '',
				)
			)
		);
	}
}
add_filter( 'mvweb_core_global_pages', 'mvweb_core_team_preview_pages', 20 );

if ( ! function_exists( 'mvweb_core_team_style_map' ) ) {
	/**
	 * The sheets of the pages of the doctors; the key doctors is the sheet of the theme on the listing, the theme adds its own key for the page of a doctor.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Handles without the theme prefix.
	 *
	 * @return string[]
	 */
	function mvweb_core_team_style_map( $styles ) {
		if ( mvweb_core_is_doctors() ) {
			array_push( $styles, 'page-hero', 'crumbs', 'pagination', 'form', 'doctors' );
		} elseif ( mvweb_core_is_doctor() ) {
			array_push( $styles, 'page-hero', 'crumbs', 'form' );
		}

		return $styles;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_core_team_style_map' );

if ( ! function_exists( 'mvweb_core_team_scripts' ) ) {
	/**
	 * The script of the theme for the pages of the doctors, if the theme has one: assets/js/doctors.js.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_team_scripts() {
		if ( ! mvweb_core_is_doctors() && ! mvweb_core_is_doctor() ) {
			return;
		}

		foreach ( array( 'assets/js/doctors.min.js', 'assets/js/doctors.js' ) as $file ) {
			$path = get_theme_file_path( $file );

			if ( file_exists( $path ) ) {
				wp_enqueue_script_module( '@mvweb-core/doctors', get_theme_file_uri( $file ), array(), (string) filemtime( $path ) );

				return;
			}
		}
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_core_team_scripts' );

if ( ! function_exists( 'mvweb_core_team_sitemap_types' ) ) {
	/**
	 * The doctors by specialities among the kinds of content of the sitemap.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $types Kind => its data.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_team_sitemap_types( $types ) {
		if ( mvweb_core_team_pages_on() && post_type_exists( 'mv_person' ) && taxonomy_exists( 'mv_speciality' ) ) {
			$types['doctor'] = array(
				'label'     => mvweb_core_team_label(),
				'icon'      => 'user',
				'desc'      => __( 'Doctors by specialities', 'mvweb-core' ),
				/* translators: %s: a number. */
				'units'     => _n_noop( '%s doctor', '%s doctors', 'mvweb-core' ),
				'source'    => 'terms',
				'post_type' => 'mv_person',
				'taxonomy'  => 'mv_speciality',
				'archive'   => array(
					'name' => __( 'All doctors', 'mvweb-core' ),
					'url'  => (string) get_post_type_archive_link( 'mv_person' ),
				),
			);
		}

		return $types;
	}
}
add_filter( 'mvweb_core_sitemap_types', 'mvweb_core_team_sitemap_types' );
