<?php
/**
 * The choice between the adult and the children's side of a clinic: an element of the header and its settings.
 *
 * It comes with add_theme_support( 'mvweb-audience' ). Two names, two links
 * and the side this site belongs to; the element shows only when the other
 * side has a link. The element stands in the top bar, the main row and the
 * menu of the phone; how it looks in each is the theme's. Out of the box the
 * element is in no zone: the owner or the theme puts it where it is wanted.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_audience_supported' ) ) {
	/**
	 * Whether the theme draws the choice of the side.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_audience_supported() {
		return current_theme_supports( 'mvweb-audience' );
	}
}

if ( ! function_exists( 'mvweb_core_audience_zones' ) ) {
	/**
	 * The zones that may carry the element.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_audience_zones() {
		return array( 'header-topbar', 'header-main', 'header-drawer-nav' );
	}
}

if ( ! function_exists( 'mvweb_core_audience_element' ) ) {
	/**
	 * The element among the elements of the zones.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $elements Element slug => label.
	 * @param string               $zone     Zone slug.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_audience_element( $elements, $zone ) {
		if ( mvweb_core_audience_supported() && in_array( $zone, mvweb_core_audience_zones(), true ) ) {
			$elements['audience'] = __( 'For adults / for children', 'mvweb-core' );
		}

		return $elements;
	}
}
add_filter( 'mvweb_core_zone_elements', 'mvweb_core_audience_element', 20, 2 );

if ( ! function_exists( 'mvweb_core_audience_default_order' ) ) {
	/**
	 * Leave the element out of the order a zone has until the owner saves one: it would stand in three zones at once.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $order Element slugs.
	 *
	 * @return string[]
	 */
	function mvweb_core_audience_default_order( $order ) {
		return array_values( array_diff( (array) $order, array( 'audience' ) ) );
	}
}
add_filter( 'mvweb_core_zone_default_order', 'mvweb_core_audience_default_order', 5 );

if ( ! function_exists( 'mvweb_core_audience' ) ) {
	/**
	 * The two sides, in the order adults first.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array{key:string,label:string,url:string,current:bool}> Empty when the theme has no choice of the side or the other side has no link.
	 */
	function mvweb_core_audience() {
		if ( ! mvweb_core_audience_supported() ) {
			return array();
		}

		$current = 'kids' === get_theme_mod( 'mvweb_audience_current', 'adult' ) ? 'kids' : 'adult';
		$names   = array(
			'adult' => __( 'For adults', 'mvweb-core' ),
			'kids'  => __( 'For children', 'mvweb-core' ),
		);
		$out     = array();

		foreach ( $names as $key => $name ) {
			$label = trim( (string) get_theme_mod( 'mvweb_audience_' . $key . '_label', '' ) );
			$url   = trim( (string) get_theme_mod( 'mvweb_audience_' . $key . '_url', '' ) );

			if ( $key === $current && '' === $url ) {
				$url = home_url( '/' );
			}

			if ( '' === $url ) {
				return array();
			}

			$out[] = array(
				'key'     => $key,
				'label'   => '' === $label ? $name : $label,
				'url'     => $url,
				'current' => $key === $current,
			);
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_core_audience_fields' ) ) {
	/**
	 * The names and the links of the two sides.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_audience_fields( $kit ) {
		if ( ! mvweb_core_audience_supported() ) {
			return;
		}

		$kit->add_fields(
			array(
				array(
					'type'        => 'radio',
					'settings'    => 'mvweb_audience_current',
					'section'     => 'mvweb_cz_header_blocks',
					'label'       => __( 'This site is for', 'mvweb-core' ),
					'description' => __( 'The side of the clinic this site belongs to; it is marked in the choice “For adults / for children”. Put the choice in a zone of the header above.', 'mvweb-core' ),
					'default'     => 'adult',
					'choices'     => array(
						'adult' => __( 'Adults', 'mvweb-core' ),
						'kids'  => __( 'Children', 'mvweb-core' ),
					),
				),
				array(
					'type'        => 'text',
					'settings'    => 'mvweb_audience_adult_label',
					'section'     => 'mvweb_cz_header_blocks',
					'label'       => __( 'Adults: name', 'mvweb-core' ),
					'description' => __( 'Empty — “For adults”.', 'mvweb-core' ),
					'default'     => '',
				),
				array(
					'type'        => 'url',
					'settings'    => 'mvweb_audience_adult_url',
					'section'     => 'mvweb_cz_header_blocks',
					'label'       => __( 'Adults: link', 'mvweb-core' ),
					'description' => __( 'The site or the section for adults. Empty on the adults\' own site: the home page.', 'mvweb-core' ),
					'default'     => '',
				),
				array(
					'type'        => 'text',
					'settings'    => 'mvweb_audience_kids_label',
					'section'     => 'mvweb_cz_header_blocks',
					'label'       => __( 'Children: name', 'mvweb-core' ),
					'description' => __( 'Empty — “For children”.', 'mvweb-core' ),
					'default'     => '',
				),
				array(
					'type'        => 'url',
					'settings'    => 'mvweb_audience_kids_url',
					'section'     => 'mvweb_cz_header_blocks',
					'label'       => __( 'Children: link', 'mvweb-core' ),
					'description' => __( 'The site or the section for children. Empty on the children\'s own site: the home page. While the other side has no link, the choice is not shown.', 'mvweb-core' ),
					'default'     => '',
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_audience_fields' );
