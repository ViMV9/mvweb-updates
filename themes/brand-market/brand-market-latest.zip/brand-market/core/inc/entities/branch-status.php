<?php
/**
 * The status of a branch by its opening hours: open until, closed until.
 *
 * It comes with add_theme_support( 'mvweb-branch-status' ). The hours stay the
 * free text of the branch list, one line for a group of days; the core reads
 * the usual forms of it («Mon–Fri | 8:00–21:00», «Sat | 9:00–18:00», «Daily |
 * 24/7», «Sun | closed», Russian or English days) into a week. A template puts
 * mvweb_core_branch_status_attrs() on the element of the status, and a script
 * writes the status into it by the time zone of the site. Hours the core
 * cannot read leave the element as the template printed it.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_hours_days' ) ) {
	/**
	 * The days of a line of the hours, 0 for Monday to 6 for Sunday.
	 *
	 * @since 0.1.0
	 *
	 * @param string $text The days as the editor wrote them; empty means every day.
	 *
	 * @return int[]|null Null when a word is not a day.
	 */
	function mvweb_core_hours_days( $text ) {
		$text = trim( mb_strtolower( (string) $text ) );

		if ( '' === $text || preg_match( '/^(ежедневно|каждый день|без выходных|daily|every day)$/u', $text ) ) {
			return range( 0, 6 );
		}

		$names = array(
			'пн'  => 0,
			'пон' => 0,
			'вт'  => 1,
			'ср'  => 2,
			'чт'  => 3,
			'чет' => 3,
			'пт'  => 4,
			'пят' => 4,
			'сб'  => 5,
			'суб' => 5,
			'вс'  => 6,
			'вос' => 6,
			'mo'  => 0,
			'tu'  => 1,
			'we'  => 2,
			'th'  => 3,
			'fr'  => 4,
			'sa'  => 5,
			'su'  => 6,
		);
		$day   = static function ( $word ) use ( $names ) {
			$word = trim( $word, " .\t" );

			foreach ( array( 3, 2 ) as $length ) {
				$start = mb_substr( $word, 0, $length );

				if ( isset( $names[ $start ] ) ) {
					return $names[ $start ];
				}
			}

			return null;
		};
		$days  = array();

		foreach ( preg_split( '/[,;]/u', $text ) as $piece ) {
			$ends = preg_split( '/\s*[-–—]\s*/u', trim( $piece ) );
			$from = $day( $ends[0] );
			$to   = isset( $ends[1] ) ? $day( $ends[1] ) : $from;

			if ( null === $from || null === $to || count( $ends ) > 2 ) {
				return null;
			}

			for ( $step = 0; $step < 7; $step++ ) {
				$days[] = ( $from + $step ) % 7;

				if ( ( $from + $step ) % 7 === $to ) {
					break;
				}
			}
		}

		return array_values( array_unique( $days ) );
	}
}

if ( ! function_exists( 'mvweb_core_hours_time' ) ) {
	/**
	 * The open intervals of a line of the hours, in minutes from midnight.
	 *
	 * @since 0.1.0
	 *
	 * @param string $text The hours as the editor wrote them.
	 *
	 * @return array<int,int[]>|null Pairs of opening and closing minutes, empty on a day off, null when the text is not hours.
	 */
	function mvweb_core_hours_time( $text ) {
		$text = trim( mb_strtolower( (string) $text ) );

		if ( preg_match( '/^(круглосуточно|24\/7|24 часа|around the clock|24 hours)$/u', $text ) ) {
			return array( array( 0, 1440 ) );
		}

		if ( preg_match( '/^(выходной|закрыто|closed|day off|[-–—])$/u', $text ) ) {
			return array();
		}

		if ( ! preg_match_all( '/(\d{1,2})[:.](\d{2})\s*[-–—]\s*(\d{1,2})[:.](\d{2})/u', $text, $found, PREG_SET_ORDER ) ) {
			return null;
		}

		$time = array();

		foreach ( $found as $match ) {
			$open  = (int) $match[1] * 60 + (int) $match[2];
			$close = (int) $match[3] * 60 + (int) $match[4];

			if ( $open > 1440 || $close > 1440 ) {
				return null;
			}

			$time[] = array( $open, $close > $open ? $close : $close + 1440 );
		}

		return $time;
	}
}

if ( ! function_exists( 'mvweb_core_hours_week' ) ) {
	/**
	 * The week of a branch from its lines of hours.
	 *
	 * @since 0.1.0
	 *
	 * @param array $hours Lines of the hours, each with days and time, as mvweb_core_branches() gives them.
	 *
	 * @return array<int,array<int,int[]>>|null Seven days from Monday, null when a line is not read.
	 */
	function mvweb_core_hours_week( array $hours ) {
		if ( empty( $hours ) ) {
			return null;
		}

		$week = array_fill( 0, 7, array() );

		foreach ( $hours as $line ) {
			$days = mvweb_core_hours_days( isset( $line['days'] ) ? $line['days'] : '' );
			$time = mvweb_core_hours_time( isset( $line['time'] ) ? $line['time'] : '' );

			if ( null === $days || null === $time ) {
				return null;
			}

			foreach ( $days as $index ) {
				$week[ $index ] = array_merge( $week[ $index ], $time );
			}
		}

		return $week;
	}
}

if ( ! function_exists( 'mvweb_core_branch_status_attrs' ) ) {
	/**
	 * The attribute that hands the week of a branch to the script of the status.
	 *
	 * @since 0.1.0
	 *
	 * @param array $branch A branch as mvweb_core_branches() gives it.
	 *
	 * @return string The attribute with a leading space, or an empty string without the support of the theme or readable hours.
	 */
	function mvweb_core_branch_status_attrs( array $branch ) {
		global $wp_locale;

		if ( ! current_theme_supports( 'mvweb-branch-status' ) ) {
			return '';
		}

		$week = mvweb_core_hours_week( isset( $branch['hours'] ) ? (array) $branch['hours'] : array() );

		if ( null === $week ) {
			return '';
		}

		$days = array();

		foreach ( array( 1, 2, 3, 4, 5, 6, 0 ) as $number ) {
			$days[] = $wp_locale->get_weekday_abbrev( $wp_locale->get_weekday( $number ) );
		}

		$data = array(
			'week'   => $week,
			'offset' => (int) ( wp_timezone()->getOffset( new DateTime( 'now' ) ) / 60 ),
			'days'   => $days,
			'text'   => array(
				/* translators: %s: closing time, for example 21:00. */
				'open'     => __( 'Open until %s', 'mvweb-core' ),
				'round'    => __( 'Open around the clock', 'mvweb-core' ),
				/* translators: %s: opening time, for example 8:00. */
				'today'    => __( 'Closed, opens at %s', 'mvweb-core' ),
				/* translators: %s: opening time, for example 8:00. */
				'tomorrow' => __( 'Closed, opens tomorrow at %s', 'mvweb-core' ),
				/* translators: 1: short name of the day, 2: opening time. */
				'later'    => __( 'Closed until %1$s, %2$s', 'mvweb-core' ),
				'closed'   => __( 'Closed', 'mvweb-core' ),
			),
		);

		return ' data-branch-status="' . esc_attr( (string) wp_json_encode( $data ) ) . '"';
	}
}

if ( ! function_exists( 'mvweb_core_branch_status_modules' ) ) {
	/**
	 * Add the script of the status to the pages with branches.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules File names without extension, from assets/js/.
	 *
	 * @return string[]
	 */
	function mvweb_core_branch_status_modules( $modules ) {
		if ( current_theme_supports( 'mvweb-branch-status' ) && in_array( 'branches', mvweb_core_request_section_types(), true ) ) {
			$modules[] = 'branch-status';
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_core_branch_status_modules' );
