<?php
/**
 * The price stack of a catalogue item: the savings by condition, the price after them, the monthly payment and the footnote.
 *
 * It comes with add_theme_support( 'mvweb-price-stack' ): the item screen gets
 * a box of its own and the theme draws the stack from
 * mvweb_core_item_price_stack(). The price itself stays in the Catalogue box;
 * the total is the price less the savings and is not stored.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_price_stack_supported' ) ) {
	/**
	 * Whether the theme draws the price stack.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_price_stack_supported() {
		return current_theme_supports( 'mvweb-price-stack' );
	}
}

if ( ! function_exists( 'mvweb_core_price_stack_meta' ) ) {
	/**
	 * The meta keys of the stack and how each is cleaned.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Key => sanitizer.
	 */
	function mvweb_core_price_stack_meta() {
		return array(
			'_mvweb_savings'       => 'mvweb_core_sanitize_savings',
			'_mvweb_payment'       => 'mvweb_core_sanitize_amount',
			'_mvweb_payment_terms' => 'sanitize_text_field',
			'_mvweb_price_note'    => 'sanitize_text_field',
		);
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_savings' ) ) {
	/**
	 * The savings as they are stored: a JSON list of name, amount and condition.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value: the typed lines or a list of rows.
	 *
	 * @return string JSON list of rows.
	 */
	function mvweb_core_sanitize_savings( $value ) {
		if ( is_string( $value ) && str_starts_with( ltrim( $value ), '[' ) ) {
			$decoded = json_decode( $value, true );
			$value   = is_array( $decoded ) ? $decoded : $value;
		}

		if ( is_array( $value ) ) {
			$lines = array();

			foreach ( $value as $row ) {
				if ( is_array( $row ) && isset( $row['label'], $row['amount'] ) ) {
					$lines[] = $row['label'] . '|' . $row['amount'] . '|' . ( $row['note'] ?? '' );
				}
			}
		} else {
			$lines = preg_split( '/\R/u', (string) $value );
		}

		$rows = array();

		foreach ( (array) $lines as $line ) {
			$parts  = array_map( 'trim', explode( '|', (string) $line, 3 ) );
			$label  = sanitize_text_field( $parts[0] );
			$amount = isset( $parts[1] ) ? mvweb_core_sanitize_amount( $parts[1] ) : '';

			if ( '' === $label || '' === $amount ) {
				continue;
			}

			$rows[] = array(
				'label'  => $label,
				'amount' => $amount,
				'note'   => isset( $parts[2] ) ? sanitize_text_field( $parts[2] ) : '',
			);
		}

		return empty( $rows ) ? '' : (string) wp_json_encode( $rows );
	}
}

if ( ! function_exists( 'mvweb_core_register_price_stack_meta' ) ) {
	/**
	 * Register the keys of the stack with their sanitizers.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_register_price_stack_meta() {
		if ( ! mvweb_core_price_stack_supported() ) {
			return;
		}

		foreach ( mvweb_core_price_stack_meta() as $key => $sanitizer ) {
			register_post_meta(
				'mv_item',
				$key,
				array(
					'type'              => 'string',
					'single'            => true,
					'sanitize_callback' => $sanitizer,
					'auth_callback'     => 'mvweb_core_post_meta_auth',
				)
			);
		}
	}
}
add_action( 'init', 'mvweb_core_register_price_stack_meta', 5 );

if ( ! function_exists( 'mvweb_core_price_stack_box' ) ) {
	/**
	 * Add the box of the stack to the item screen.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_price_stack_box() {
		if ( ! mvweb_core_price_stack_supported() || mvweb_core_is_woocommerce() ) {
			return;
		}

		add_meta_box( 'mvweb-core-price-stack', __( 'Savings and payment', 'mvweb-core' ), 'mvweb_core_price_stack_fields', 'mv_item', 'normal', 'high' );
	}
}
add_action( 'add_meta_boxes', 'mvweb_core_price_stack_box' );

if ( ! function_exists( 'mvweb_core_price_stack_fields' ) ) {
	/**
	 * The fields of the stack.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Post being edited.
	 *
	 * @return void
	 */
	function mvweb_core_price_stack_fields( $post ) {
		wp_nonce_field( 'mvweb_price_stack', 'mvweb_price_stack_nonce' );

		$lines = array();
		$rows  = json_decode( (string) get_post_meta( $post->ID, '_mvweb_savings', true ), true );

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$lines[] = trim( $row['label'] . ' | ' . $row['amount'] . ( '' !== $row['note'] ? ' | ' . $row['note'] : '' ) );
		}
		?>
		<div class="mvweb-core-fields">
			<p class="mvweb-core-field">
				<label for="mvweb-core-savings"><?php esc_html_e( 'Savings, one per line: name, amount and condition separated by a vertical bar.', 'mvweb-core' ); ?></label>
				<textarea class="widefat" id="mvweb-core-savings" name="mvweb_savings" rows="4" placeholder="<?php esc_attr_e( 'Trade-in | 150000 | when you hand in your car', 'mvweb-core' ); ?>"><?php echo esc_textarea( implode( "\n", $lines ) ); ?></textarea>
				<span class="description"><?php esc_html_e( 'The price after the savings is counted from the price in the Catalogue box.', 'mvweb-core' ); ?></span>
			</p>

			<p class="mvweb-core-field">
				<label for="mvweb-core-payment"><?php esc_html_e( 'Payment per month', 'mvweb-core' ); ?></label>
				<input class="widefat" type="text" inputmode="decimal" id="mvweb-core-payment" name="mvweb_payment" value="<?php echo esc_attr( (string) get_post_meta( $post->ID, '_mvweb_payment', true ) ); ?>">
			</p>

			<p class="mvweb-core-field">
				<label for="mvweb-core-payment-terms"><?php esc_html_e( 'Terms of the payment', 'mvweb-core' ); ?></label>
				<input class="widefat" type="text" id="mvweb-core-payment-terms" name="mvweb_payment_terms" value="<?php echo esc_attr( (string) get_post_meta( $post->ID, '_mvweb_payment_terms', true ) ); ?>" placeholder="<?php esc_attr_e( 'Down payment 20%, 5 years, rate from 9.9%', 'mvweb-core' ); ?>">
			</p>

			<p class="mvweb-core-field">
				<label for="mvweb-core-price-note"><?php esc_html_e( 'Footnote under the price', 'mvweb-core' ); ?></label>
				<input class="widefat" type="text" id="mvweb-core-price-note" name="mvweb_price_note" value="<?php echo esc_attr( (string) get_post_meta( $post->ID, '_mvweb_price_note', true ) ); ?>">
				<span class="description"><?php esc_html_e( 'Until when the offer holds and that it is not a public offer.', 'mvweb-core' ); ?></span>
			</p>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_save_price_stack' ) ) {
	/**
	 * Store what the box submitted.
	 *
	 * @since 0.1.0
	 *
	 * @param int     $post_id Post being saved.
	 * @param WP_Post $post    Post object.
	 *
	 * @return void
	 */
	function mvweb_core_save_price_stack( $post_id, $post ) {
		if ( 'mv_item' !== $post->post_type || wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified on the next line.
		if ( ! isset( $_POST['mvweb_price_stack_nonce'] ) ) {
			return;
		}

		check_admin_referer( 'mvweb_price_stack', 'mvweb_price_stack_nonce' );

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		foreach ( array_keys( mvweb_core_price_stack_meta() ) as $key ) {
			$input = 'mvweb_' . substr( $key, strlen( '_mvweb_' ) );

			if ( isset( $_POST[ $input ] ) ) {
				update_post_meta( $post_id, $key, $_POST[ $input ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- update_post_meta() unslashes and runs the callback the key is registered with.
			}
		}
	}
}
add_action( 'save_post', 'mvweb_core_save_price_stack', 10, 2 );

if ( ! function_exists( 'mvweb_core_item_price_stack' ) ) {
	/**
	 * Everything the stack of an item shows.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return array{price:float,savings:array<int,array{label:string,amount:float,note:string}>,saved:float,total:float,payment:float,terms:string,note:string} Zero price when the item has none.
	 */
	function mvweb_core_item_price_stack( $id ) {
		$id      = absint( $id );
		$price   = (float) get_post_meta( $id, '_mvweb_price', true );
		$rows    = json_decode( (string) get_post_meta( $id, '_mvweb_savings', true ), true );
		$savings = array();
		$saved   = 0.0;

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			if ( ! is_array( $row ) || ! isset( $row['label'], $row['amount'] ) ) {
				continue;
			}

			$amount    = (float) $row['amount'];
			$saved    += $amount;
			$savings[] = array(
				'label'  => (string) $row['label'],
				'amount' => $amount,
				'note'   => isset( $row['note'] ) ? (string) $row['note'] : '',
			);
		}

		return array(
			'price'   => $price,
			'savings' => $savings,
			'saved'   => $saved,
			'total'   => $price > 0 ? max( 0.0, $price - $saved ) : 0.0,
			'payment' => (float) get_post_meta( $id, '_mvweb_payment', true ),
			'terms'   => (string) get_post_meta( $id, '_mvweb_payment_terms', true ),
			'note'    => (string) get_post_meta( $id, '_mvweb_price_note', true ),
		);
	}
}
