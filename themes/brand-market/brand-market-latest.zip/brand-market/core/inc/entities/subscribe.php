<?php
/**
 * Subscription: the networks of the profile and one shortcode of a mailing plugin, the element of the header, the part under an article, the note about Meta.
 *
 * The data live here; the button, the window, the bell and the counter are the
 * look of the theme. It all comes with add_theme_support( 'mvweb-subscribe' );
 * the note about Meta beside the networks with add_theme_support( 'mvweb-social-meta-note' ).
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_subscribe_supported' ) ) {
	/**
	 * Whether the theme draws the subscription.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_subscribe_supported() {
		return current_theme_supports( 'mvweb-subscribe' );
	}
}

if ( ! function_exists( 'mvweb_core_sanitize_subscribe_shortcode' ) ) {
	/**
	 * Keep exactly one shortcode, without the closing tag and content.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Raw value.
	 *
	 * @return string Empty when the value is not one shortcode.
	 */
	function mvweb_core_sanitize_subscribe_shortcode( $value ) {
		$value = trim( (string) preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) $value ) ) );

		return 1 === preg_match( '/^\[[\w-]+[^\[\]]*\]$/', $value ) ? $value : '';
	}
}

if ( ! function_exists( 'mvweb_core_subscribe_shortcode' ) ) {
	/**
	 * The shortcode of the mailing form saved in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty when the theme has no subscription or there is no shortcode.
	 */
	function mvweb_core_subscribe_shortcode() {
		return mvweb_core_subscribe_supported() ? mvweb_core_sanitize_subscribe_shortcode( get_theme_mod( 'mvweb_subscribe_shortcode', '' ) ) : '';
	}
}

if ( ! function_exists( 'mvweb_core_subscribe_has_form' ) ) {
	/**
	 * Whether the mailing form can be shown: a shortcode is saved and its plugin is on.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_subscribe_has_form() {
		$shortcode = mvweb_core_subscribe_shortcode();

		return '' !== $shortcode && 1 === preg_match( '/^\[([\w-]+)/', $shortcode, $match ) && shortcode_exists( $match[1] );
	}
}

if ( ! function_exists( 'mvweb_core_subscribe_form' ) ) {
	/**
	 * The mailing form, once per page: the second call gets nothing, so the ids of the form do not repeat.
	 *
	 * @since 0.1.0
	 *
	 * @return string Markup of the plugin, or an empty string.
	 */
	function mvweb_core_subscribe_form() {
		static $done = false;

		if ( $done || ! mvweb_core_subscribe_has_form() ) {
			return '';
		}

		$done = true;

		return mvweb_core_form_shortcode( mvweb_core_subscribe_shortcode() );
	}
}

if ( ! function_exists( 'mvweb_core_social_meta_note' ) ) {
	/**
	 * The note under the networks when Instagram or Facebook is among them.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,string>>|null $socials Networks being shown; null for all of the profile.
	 *
	 * @return string Empty when the theme has no note, the owner cleared it or neither network is shown.
	 */
	function mvweb_core_social_meta_note( $socials = null ) {
		if ( ! current_theme_supports( 'mvweb-social-meta-note' ) ) {
			return '';
		}

		$socials = null === $socials ? mvweb_cz_profile_socials() : (array) $socials;

		if ( ! isset( $socials['instagram'] ) && ! isset( $socials['facebook'] ) ) {
			return '';
		}

		return trim( (string) get_theme_mod( 'mvweb_social_meta_note', mvweb_core_social_meta_default() ) );
	}
}

if ( ! function_exists( 'mvweb_core_social_meta_default' ) ) {
	/**
	 * The words of the note about Meta until the owner changes them.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_social_meta_default() {
		return __( '* Instagram and Facebook belong to Meta, whose activity is banned in Russia.', 'mvweb-core' );
	}
}

if ( ! function_exists( 'mvweb_core_subscribe' ) ) {
	/**
	 * What the button and the window of the subscription show.
	 *
	 * @since 0.1.0
	 *
	 * @return array{label:string,socials:array<string,array<string,string>>,form:bool,note:string} Empty when the theme has no subscription or there is nothing to follow.
	 */
	function mvweb_core_subscribe() {
		if ( ! mvweb_core_subscribe_supported() ) {
			return array();
		}

		$socials = mvweb_cz_profile_socials();
		$form    = mvweb_core_subscribe_has_form();

		if ( empty( $socials ) && ! $form ) {
			return array();
		}

		$label = trim( (string) get_theme_mod( 'mvweb_subscribe_label', '' ) );

		return array(
			'label'   => '' !== $label ? $label : __( 'Subscribe', 'mvweb-core' ),
			'socials' => $socials,
			'form'    => $form,
			'note'    => mvweb_core_social_meta_note( $socials ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_subscribe_element' ) ) {
	/**
	 * The button of the subscription among the elements of the header.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $elements Element slug => label.
	 * @param string               $zone     Zone slug.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_subscribe_element( $elements, $zone ) {
		if ( 'header-actions' === $zone && mvweb_core_subscribe_supported() ) {
			$elements['subscribe'] = __( 'Subscribe button', 'mvweb-core' );
		}

		return $elements;
	}
}
add_filter( 'mvweb_core_zone_elements', 'mvweb_core_subscribe_element', 20, 2 );

if ( ! function_exists( 'mvweb_core_subscribe_layout' ) ) {
	/**
	 * The subscription as a part under the text of an article, left out until the owner ticks it.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $layouts Area => definition.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_subscribe_layout( $layouts ) {
		if ( ! isset( $layouts['post-after']['parts'] ) || ! mvweb_core_subscribe_supported() ) {
			return $layouts;
		}

		$layouts['post-after']['parts']['subscribe'] = __( 'Subscription', 'mvweb-core' );
		$layouts['post-after']['off']                = array_merge( isset( $layouts['post-after']['off'] ) ? (array) $layouts['post-after']['off'] : array(), array( 'subscribe' ) );

		return $layouts;
	}
}
add_filter( 'mvweb_core_layouts', 'mvweb_core_subscribe_layout', 20 );

if ( ! function_exists( 'mvweb_core_subscribe_fields' ) ) {
	/**
	 * The shortcode of the mailing form and the caption of the button; the note about Meta beside the networks.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_subscribe_fields( $kit ) {
		$fields = array();

		if ( mvweb_core_subscribe_supported() ) {
			$fields[] = array(
				'type'              => 'text',
				'settings'          => 'mvweb_subscribe_shortcode',
				'section'           => 'mvweb_cz_conversion_subscribe',
				'label'             => __( 'Shortcode of the mailing form', 'mvweb-core' ),
				'description'       => __( 'One shortcode of the mailing plugin, for example [mailpoet_form id="1"]. Empty: no form, the social networks stay.', 'mvweb-core' ),
				'default'           => '',
				'sanitize_callback' => 'mvweb_core_sanitize_subscribe_shortcode',
			);
			$fields[] = array(
				'type'        => 'text',
				'settings'    => 'mvweb_subscribe_label',
				'section'     => 'mvweb_cz_conversion_subscribe',
				'label'       => __( 'Caption of the button', 'mvweb-core' ),
				'description' => __( 'Empty — “Subscribe”.', 'mvweb-core' ),
				'default'     => '',
			);
		}

		if ( current_theme_supports( 'mvweb-social-meta-note' ) ) {
			$fields[] = array(
				'type'        => 'textarea',
				'settings'    => 'mvweb_social_meta_note',
				'section'     => 'mvweb_cz_profile_socials',
				'label'       => __( 'Note about Instagram and Facebook', 'mvweb-core' ),
				'description' => __( 'Shown under the social networks when Instagram or Facebook is among them. Empty: no note.', 'mvweb-core' ),
				'default'     => mvweb_core_social_meta_default(),
			);
		}

		if ( ! empty( $fields ) ) {
			$kit->add_fields( $fields );
		}
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_subscribe_fields' );

if ( ! function_exists( 'mvweb_core_subscribe_widget' ) ) {
	/**
	 * The widget «Social networks and mailing», when the theme asks for it with add_theme_support( 'mvweb-widget-subscribe' ).
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $kinds Kinds by key.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_subscribe_widget( $kinds ) {
		if ( ! mvweb_core_subscribe_supported() || ! current_theme_supports( 'mvweb-widget-subscribe' ) ) {
			return $kinds;
		}

		$kinds['subscribe'] = array(
			'name'        => __( 'MVweb: Social networks and mailing', 'mvweb-core' ),
			'description' => __( 'The social networks of the site with the window of all of them, and the mailing form of the subscription.', 'mvweb-core' ),
			'template'    => 'subscribe',
			'data'        => 'mvweb_core_widget_subscribe',
			'ordered'     => true,
			'fields'      => array(
				'number' => mvweb_core_widget_number( 5, 1, 20, __( 'How many networks to show:', 'mvweb-core' ) ),
				'text'   => array(
					'type'    => 'textarea',
					'label'   => __( 'Text above the mailing form:', 'mvweb-core' ),
					'default' => '',
				),
			),
			'parts'       => array(
				'socials' => __( 'Social networks', 'mvweb-core' ),
				'mail'    => __( 'Mailing', 'mvweb-core' ),
			),
		);

		return $kinds;
	}
}
add_filter( 'mvweb_core_widget_kinds', 'mvweb_core_subscribe_widget' );

if ( ! function_exists( 'mvweb_core_widget_subscribe' ) ) {
	/**
	 * Data of the widget of the subscription: the networks and the mailing form, printed once per page.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $instance Saved values.
	 * @param string[]            $parts    Parts in print order.
	 *
	 * @return array<string,mixed>|null
	 */
	function mvweb_core_widget_subscribe( array $instance, array $parts ) {
		$subscribe = mvweb_core_subscribe();

		if ( empty( $subscribe ) ) {
			return null;
		}

		$socials = in_array( 'socials', $parts, true ) ? $subscribe['socials'] : array();
		$form    = in_array( 'mail', $parts, true ) && $subscribe['form'] ? mvweb_core_subscribe_form() : '';

		if ( empty( $socials ) && '' === $form ) {
			return null;
		}

		return array(
			'socials' => $socials,
			'max'     => absint( $instance['number'] ),
			'form'    => $form,
			'text'    => '' !== $form ? trim( (string) $instance['text'] ) : '',
		);
	}
}
