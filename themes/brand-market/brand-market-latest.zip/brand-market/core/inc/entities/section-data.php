<?php
/**
 * Data of the blocks that read posts, terms and meta: the template gets ready rows and prints them.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_product_ids' ) ) {
	/**
	 * The products a block shows, from its source field.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props Values of the block: source, count, items, category.
	 *
	 * @return int[]
	 */
	function mvweb_core_product_ids( array $props ) {
		$source = isset( $props['source'] ) ? (string) $props['source'] : 'featured';
		$count  = isset( $props['count'] ) ? absint( $props['count'] ) : 0;

		if ( 'category' !== $source ) {
			$rows = isset( $props['items'] ) && is_array( $props['items'] ) ? mvweb_core_visible_rows( $props['items'] ) : array();

			return mvweb_core_showcase_items( $source, $count, array_column( $rows, 'item' ) );
		}

		$args = array(
			'post_type'        => mvweb_core_post_type(),
			'post_status'      => 'publish',
			'numberposts'      => $count > 0 ? $count : 4,
			'fields'           => 'ids',
			'suppress_filters' => false,
			'orderby'          => array(
				'menu_order' => 'ASC',
				'date'       => 'DESC',
			),
		);
		$term = isset( $props['category'] ) ? absint( $props['category'] ) : 0;

		if ( $term > 0 ) {
			$args['tax_query'] = array_merge( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- The department is what the block is for.
				array(
					array(
						'taxonomy' => mvweb_core_taxonomy(),
						'field'    => 'term_id',
						'terms'    => array( $term ),
					),
				),
				mvweb_core_visibility_query()
			);
		}

		return array_values( array_filter( mvweb_core_prime_items( get_posts( $args ) ), 'mvweb_core_item_visible' ) );
	}
}

if ( ! function_exists( 'mvweb_core_departments' ) ) {
	/**
	 * The top level departments of a set of products.
	 *
	 * @since 0.1.0
	 *
	 * @param int[] $ids Product ids.
	 *
	 * @return array{by_item:array<int,string[]>,names:array<string,string>} Slugs of each product; slug => name in the order they first appear.
	 */
	function mvweb_core_departments( array $ids ) {
		$by_item  = array();
		$names    = array();
		$taxonomy = mvweb_core_taxonomy();

		foreach ( $ids as $id ) {
			$by_item[ $id ] = array();
			$terms          = get_the_terms( $id, $taxonomy );

			foreach ( is_array( $terms ) ? $terms : array() as $term ) {
				$ancestors = get_ancestors( $term->term_id, $taxonomy, 'taxonomy' );
				$top       = empty( $ancestors ) ? $term : get_term( (int) end( $ancestors ), $taxonomy );

				if ( $top instanceof WP_Term ) {
					$by_item[ $id ][ $top->slug ] = $top->slug;
					$names[ $top->slug ]          = $top->name;
				}
			}

			$by_item[ $id ] = array_values( $by_item[ $id ] );
		}

		return array(
			'by_item' => $by_item,
			'names'   => $names,
		);
	}
}

if ( ! function_exists( 'mvweb_core_form_shortcode' ) ) {
	/**
	 * Render a form shortcode, or nothing when the plugin that owns it is off.
	 *
	 * @since 0.1.0
	 *
	 * @param string $shortcode Shortcode as the editor entered it.
	 *
	 * @return string Markup of the plugin, or an empty string.
	 */
	function mvweb_core_form_shortcode( $shortcode ) {
		$shortcode = trim( (string) $shortcode );

		if ( '' === $shortcode || 1 !== preg_match( '/\[([\w-]+)/', $shortcode, $match ) || ! shortcode_exists( $match[1] ) ) {
			return '';
		}

		return trim( do_shortcode( $shortcode ) );
	}
}

if ( ! function_exists( 'mvweb_core_before_after_pairs' ) ) {
	/**
	 * The pairs of a block «Before and after»: from the works with both photos or from the rows of the block; a pair without two pictures is left out.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props Values of the block.
	 *
	 * @return array<int,array{before:int,after:int,title:string,text:string,facts:array<int,string[]>}>
	 */
	function mvweb_core_before_after_pairs( array $props ) {
		$pairs = array();

		if ( isset( $props['source'] ) && 'works' === $props['source'] ) {
			$query = array(
				'post_type'      => 'mv_work',
				'post_status'    => 'publish',
				'posts_per_page' => isset( $props['count'] ) ? max( 1, absint( $props['count'] ) ) : 2,
				'orderby'        => array(
					'menu_order' => 'ASC',
					'date'       => 'DESC',
				),
				'fields'         => 'ids',
				'no_found_rows'  => true,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- A handful of works on one page.
					array(
						'key'     => '_mvweb_before',
						'value'   => 0,
						'compare' => '>',
						'type'    => 'NUMERIC',
					),
					array(
						'key'     => '_mvweb_after',
						'value'   => 0,
						'compare' => '>',
						'type'    => 'NUMERIC',
					),
				),
			);

			if ( ! empty( $props['kind'] ) ) {
				$query['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- Same.
					array(
						'taxonomy' => 'mv_work_type',
						'terms'    => absint( $props['kind'] ),
					),
				);
			}

			foreach ( get_posts( $query ) as $work ) {
				$pairs[] = array(
					'before' => absint( get_post_meta( $work, '_mvweb_before', true ) ),
					'after'  => absint( get_post_meta( $work, '_mvweb_after', true ) ),
					'title'  => get_the_title( $work ),
					'text'   => (string) get_post_meta( $work, '_mvweb_result', true ),
					'facts'  => array_map(
						static function ( $fact ) {
							return array( $fact['label'], $fact['value'] );
						},
						array_filter(
							mvweb_core_work_facts( $work, 3 ),
							static function ( $fact ) {
								return '' !== $fact['label'];
							}
						)
					),
				);
			}
		} elseif ( isset( $props['pairs'] ) && is_array( $props['pairs'] ) ) {
			foreach ( mvweb_core_visible_rows( $props['pairs'] ) as $row ) {
				$facts = array();

				foreach ( mvweb_core_text_lines( (string) ( isset( $row['facts'] ) ? $row['facts'] : '' ) ) as $line ) {
					$cells = array_map( 'trim', explode( ':', $line, 2 ) );

					if ( 2 === count( $cells ) && '' !== $cells[0] && '' !== $cells[1] ) {
						$facts[] = $cells;
					}
				}

				$pairs[] = array(
					'before' => isset( $row['before'] ) ? absint( $row['before'] ) : 0,
					'after'  => isset( $row['after'] ) ? absint( $row['after'] ) : 0,
					'title'  => isset( $row['title'] ) ? (string) $row['title'] : '',
					'text'   => isset( $row['text'] ) ? (string) $row['text'] : '',
					'facts'  => array_slice( $facts, 0, 3 ),
				);
			}
		}

		return array_values(
			array_filter(
				$pairs,
				static function ( $pair ) {
					return wp_attachment_is_image( $pair['before'] ) && wp_attachment_is_image( $pair['after'] );
				}
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_categories_cards' ) ) {
	/**
	 * The cards of a block «Categories»: the rows of the block or the top categories of the catalogue or of the services, the first of them wide.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props Values of the block.
	 *
	 * @return array<int,array<string,mixed>> Title, url, text, note, image, image_2, icon, wide, bg, pattern.
	 */
	function mvweb_core_categories_cards( array $props ) {
		$source = isset( $props['source'] ) ? (string) $props['source'] : 'manual';
		$cards  = array();

		if ( 'manual' === $source ) {
			$rows = isset( $props['cards'] ) && is_array( $props['cards'] ) ? mvweb_core_visible_rows( $props['cards'] ) : array();

			foreach ( $rows as $row ) {
				$title = isset( $row['title'] ) ? trim( (string) $row['title'] ) : '';

				if ( '' === $title ) {
					continue;
				}

				$pattern = isset( $row['pattern'] ) ? (string) $row['pattern'] : '';
				$tile    = 'own' === $pattern && ! empty( $row['pattern_image'] ) ? (string) wp_get_attachment_image_url( absint( $row['pattern_image'] ), 'full' ) : '';

				$cards[] = array(
					'title'   => $title,
					'url'     => isset( $row['url'] ) ? (string) $row['url'] : '',
					'text'    => isset( $row['text'] ) ? trim( (string) $row['text'] ) : '',
					'note'    => isset( $row['note'] ) ? trim( (string) $row['note'] ) : '',
					'image'   => isset( $row['image'] ) ? absint( $row['image'] ) : 0,
					'image_2' => isset( $row['image_2'] ) ? absint( $row['image_2'] ) : 0,
					'icon'    => isset( $row['icon'] ) ? sanitize_key( (string) $row['icon'] ) : '',
					'wide'    => isset( $row['size'] ) && 'wide' === $row['size'],
					'bg'      => mvweb_core_colour_css( isset( $row['bg'] ) ? $row['bg'] : '' ),
					'pattern' => '' === $pattern || ( 'own' === $pattern && '' === $tile ) ? array() : array(
						'name'    => $pattern,
						'tile'    => $tile,
						'repeat'  => isset( $row['pattern_repeat'] ) ? (string) $row['pattern_repeat'] : 'repeat',
						'opacity' => isset( $row['pattern_opacity'] ) ? min( 100, max( 5, absint( $row['pattern_opacity'] ) ) ) : 15,
					),
				);
			}

			return $cards;
		}

		$service  = 'service_cat' === $source;
		$taxonomy = $service ? 'mv_service_cat' : mvweb_core_taxonomy();
		$terms    = taxonomy_exists( $taxonomy ) ? get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'parent'     => 0,
				'hide_empty' => true,
				'number'     => isset( $props['count'] ) ? max( 1, absint( $props['count'] ) ) : 6,
			)
		) : array();

		foreach ( is_array( $terms ) ? $terms : array() as $index => $term ) {
			$url = get_term_link( $term );

			if ( is_wp_error( $url ) ) {
				continue;
			}

			$total = (int) $term->count;

			$cards[] = array(
				'title'   => $term->name,
				'url'     => $url,
				'text'    => wp_trim_words( wp_strip_all_tags( $term->description ), 22 ),
				'note'    => $service
					? sprintf( /* translators: %s: number of services in the section. */ _n( '%s service', '%s services', $total, 'mvweb-core' ), number_format_i18n( $total ) )
					: sprintf( /* translators: %s: number of items in the category. */ _n( '%s item', '%s items', $total, 'mvweb-core' ), number_format_i18n( $total ) ),
				'image'   => absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) ),
				'image_2' => 0,
				'icon'    => '',
				'wide'    => 0 === $index,
				'bg'      => array(),
				'pattern' => array(),
			);
		}

		return $cards;
	}
}

if ( ! function_exists( 'mvweb_core_services_rows' ) ) {
	/**
	 * The rows of a block «Services»: its own rows, the services of a section or of the whole site, or the sections of the services.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props    Values of the block.
	 * @param bool  $expanded Optional. With the sections as the source: the services of each section instead of the sections themselves.
	 *
	 * @return array<int,array{title:string,text:string,price:string,url:string,icon:string,image:int,group:string,badge:string}> The price is markup.
	 */
	function mvweb_core_services_rows( array $props, $expanded = false ) {
		$source = isset( $props['source'] ) ? (string) $props['source'] : 'manual';
		$count  = isset( $props['count'] ) ? max( 1, absint( $props['count'] ) ) : 6;
		$rows   = array();

		$value = static function ( $row, $key ) {
			return isset( $row[ $key ] ) ? trim( (string) $row[ $key ] ) : '';
		};

		$of_post = static function ( $id, $group ) {
			return array(
				'title' => get_the_title( $id ),
				'text'  => trim( wp_strip_all_tags( mvweb_core_item_excerpt( $id ) ) ),
				'price' => mvweb_core_item_price_html( $id ),
				'url'   => (string) get_permalink( $id ),
				'icon'  => '',
				'image' => absint( get_post_thumbnail_id( $id ) ),
				'group' => $group,
				'badge' => '',
			);
		};

		if ( 'manual' === $source ) {
			$manual = isset( $props['items'] ) && is_array( $props['items'] ) ? mvweb_core_visible_rows( $props['items'] ) : array();

			foreach ( $manual as $row ) {
				if ( '' === $value( $row, 'title' ) ) {
					continue;
				}

				$rows[] = array(
					'title' => $value( $row, 'title' ),
					'text'  => $value( $row, 'text' ),
					'price' => esc_html( $value( $row, 'price' ) ),
					'url'   => $value( $row, 'url' ),
					'icon'  => $value( $row, 'icon' ),
					'image' => isset( $row['image'] ) ? absint( $row['image'] ) : 0,
					'group' => $value( $row, 'group' ),
					'badge' => $value( $row, 'badge' ),
				);
			}
		} elseif ( 'service' === $source ) {
			$section = isset( $props['section'] ) ? absint( $props['section'] ) : 0;
			$ids     = $section > 0
				? mvweb_core_service_ids( $section, true )
				: get_posts(
					array(
						'post_type'      => 'mv_service',
						'post_status'    => 'publish',
						'posts_per_page' => $count,
						'fields'         => 'ids',
						'no_found_rows'  => true,
						'orderby'        => array(
							'menu_order' => 'ASC',
							'date'       => 'DESC',
						),
					)
				);

			foreach ( array_slice( $ids, 0, $count ) as $id ) {
				$terms  = get_the_terms( $id, 'mv_service_cat' );
				$rows[] = $of_post( $id, is_array( $terms ) ? reset( $terms )->name : '' );
			}
		} elseif ( 'service_cat' === $source ) {
			foreach ( array_slice( mvweb_core_service_child_terms( 0 ), 0, $count ) as $term ) {
				if ( $expanded ) {
					foreach ( mvweb_core_service_ids( $term->term_id, true ) as $id ) {
						$rows[] = $of_post( $id, $term->name );
					}

					continue;
				}

				$link   = get_term_link( $term );
				$rows[] = array(
					'title' => $term->name,
					'text'  => wp_trim_words( wp_strip_all_tags( $term->description ), 20 ),
					'price' => '',
					'url'   => is_string( $link ) ? $link : '',
					'icon'  => '',
					'image' => absint( get_term_meta( $term->term_id, 'thumbnail_id', true ) ),
					'group' => '',
				);
			}
		}

		return $rows;
	}
}

if ( ! function_exists( 'mvweb_core_conditions_rows' ) ) {
	/**
	 * The directions of a block «What we treat»: its own rows or the sections of the services, each with its main services.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props    Values of the block.
	 * @param int   $services Optional. With the sections as the source: how many services to take for each. The rows of the list carry the services typed in them.
	 *
	 * @return array<int,array{icon:string,title:string,note:string,count:int,url:string,services:array<int,array{title:string,price:string,url:string}>}> The price is markup; count is the number of services of a section, 0 for a row of the list.
	 */
	function mvweb_core_conditions_rows( array $props, $services = 0 ) {
		$source = isset( $props['source'] ) ? (string) $props['source'] : 'manual';
		$rows   = array();

		$value = static function ( $row, $key ) {
			return isset( $row[ $key ] ) ? trim( (string) $row[ $key ] ) : '';
		};

		if ( 'service_cat' === $source ) {
			$count = isset( $props['count'] ) ? max( 1, absint( $props['count'] ) ) : 8;

			foreach ( array_slice( mvweb_core_service_child_terms( 0 ), 0, $count ) as $term ) {
				$link = get_term_link( $term );
				$ids  = mvweb_core_service_ids( $term->term_id, true );
				$list = array();

				foreach ( array_slice( $ids, 0, max( 0, absint( $services ) ) ) as $id ) {
					$list[] = array(
						'title' => get_the_title( $id ),
						'price' => mvweb_core_item_price_html( $id ),
						'url'   => (string) get_permalink( $id ),
					);
				}

				$rows[] = array(
					'icon'     => '',
					'title'    => $term->name,
					'note'     => '',
					'count'    => count( $ids ),
					'url'      => is_string( $link ) ? $link : '',
					'services' => $list,
				);
			}

			return $rows;
		}

		$manual = isset( $props['directions'] ) && is_array( $props['directions'] ) ? mvweb_core_visible_rows( $props['directions'] ) : array();

		foreach ( $manual as $row ) {
			if ( '' === $value( $row, 'title' ) ) {
				continue;
			}

			$list = array();

			foreach ( isset( $row['services'] ) && is_array( $row['services'] ) ? mvweb_core_visible_rows( $row['services'] ) : array() as $service ) {
				if ( '' !== $value( $service, 'title' ) ) {
					$list[] = array(
						'title' => $value( $service, 'title' ),
						'price' => esc_html( $value( $service, 'price' ) ),
						'url'   => $value( $service, 'url' ),
					);
				}
			}

			$rows[] = array(
				'icon'     => $value( $row, 'icon' ),
				'title'    => $value( $row, 'title' ),
				'note'     => $value( $row, 'note' ),
				'count'    => 0,
				'url'      => $value( $row, 'url' ),
				'services' => $list,
			);
		}

		return $rows;
	}
}

if ( ! function_exists( 'mvweb_core_conditions_situations' ) ) {
	/**
	 * The reasons to come of a block «What we treat»: groups with their links, empty ones left out.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props Values of the block.
	 *
	 * @return array<int,array{icon:string,title:string,links:array<int,array{title:string,url:string}>}>
	 */
	function mvweb_core_conditions_situations( array $props ) {
		$groups = array();

		foreach ( isset( $props['situations'] ) && is_array( $props['situations'] ) ? mvweb_core_visible_rows( $props['situations'] ) : array() as $group ) {
			$links = array();

			foreach ( isset( $group['links'] ) && is_array( $group['links'] ) ? mvweb_core_visible_rows( $group['links'] ) : array() as $link ) {
				if ( '' !== trim( (string) ( $link['title'] ?? '' ) ) ) {
					$links[] = array(
						'title' => trim( (string) $link['title'] ),
						'url'   => trim( (string) ( $link['url'] ?? '' ) ),
					);
				}
			}

			if ( $links ) {
				$groups[] = array(
					'icon'  => trim( (string) ( $group['icon'] ?? '' ) ),
					'title' => trim( (string) ( $group['title'] ?? '' ) ),
					'links' => $links,
				);
			}
		}

		return $groups;
	}
}

if ( ! function_exists( 'mvweb_core_person' ) ) {
	/**
	 * What a card of a team member shows besides the name and the photo: the role, the text about them, the address of the booking.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $person Team member.
	 *
	 * @return array{role:string,bio:string,url:string,id:int,page:string,exp:int,price:string,degree:string,category:string,age_from:string,branches:array} The booking address is url; the page of the doctor is page, empty while the pages of the doctors are off.
	 */
	function mvweb_core_person( $person ) {
		return array_merge(
			array(
				'role' => trim( (string) get_post_meta( $person->ID, '_mvweb_role', true ) ),
				'bio'  => trim( (string) get_post_meta( $person->ID, '_mvweb_bio', true ) ),
				'url'  => trim( (string) get_post_meta( $person->ID, '_mvweb_booking_url', true ) ),
			),
			function_exists( 'mvweb_core_team_person_extra' ) ? mvweb_core_team_person_extra( $person->ID ) : array()
		);
	}
}

if ( ! function_exists( 'mvweb_core_video_rows' ) ) {
	/**
	 * The videos of a block «Video reviews»: its own rows or the videos of the site; a video without an address is left out.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props Values of the block.
	 *
	 * @return array<int,array{title:string,image:int,url:string,time:string,note:string,text:string}>
	 */
	function mvweb_core_video_rows( array $props ) {
		$rows = array();

		if ( isset( $props['source'] ) && 'rows' === $props['source'] ) {
			foreach ( isset( $props['items'] ) && is_array( $props['items'] ) ? mvweb_core_visible_rows( $props['items'] ) : array() as $item ) {
				$rows[] = array(
					'title' => (string) $item['title'],
					'image' => (int) $item['image'],
					'url'   => (string) $item['video_url'],
					'time'  => (string) $item['duration'],
					'note'  => (string) $item['note'],
					'text'  => (string) $item['text'],
				);
			}
		} else {
			foreach ( mvweb_core_videos( isset( $props['count'] ) ? absint( $props['count'] ) : 0 ) as $video ) {
				$rows[] = array(
					'title' => get_the_title( $video ),
					'image' => (int) get_post_thumbnail_id( $video ),
					'url'   => (string) get_post_meta( $video->ID, '_mvweb_video_url', true ),
					'time'  => (string) get_post_meta( $video->ID, '_mvweb_video_duration', true ),
					'note'  => (string) get_post_meta( $video->ID, '_mvweb_video_note', true ),
					'text'  => (string) get_post_meta( $video->ID, '_mvweb_video_text', true ),
				);
			}
		}

		return array_values(
			array_filter(
				$rows,
				static function ( $row ) {
					return '' !== $row['url'];
				}
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_review_rows' ) ) {
	/**
	 * The reviews of a block «Reviews»: the reviews written in the works or the rows of the block; a review without text is left out.
	 *
	 * @since 0.1.0
	 *
	 * @param array $props Values of the block.
	 *
	 * @return array<int,array{name:string,text:string,source:string,stars:int,photo:int,doctor:string,video:string}>
	 */
	function mvweb_core_review_rows( array $props ) {
		$rows  = array();
		$stars = array(
			'five'  => 5,
			'four'  => 4,
			'three' => 3,
		);

		if ( isset( $props['source'] ) && 'works' === $props['source'] ) {
			$limit = isset( $props['works_count'] ) ? max( 1, absint( $props['works_count'] ) ) : 6;

			foreach ( mvweb_core_works( array( 'count' => 40 ) ) as $work ) {
				$text = trim( (string) get_post_meta( $work, '_mvweb_review', true ) );

				if ( '' === $text ) {
					continue;
				}

				$rows[] = array(
					'name'   => (string) get_post_meta( $work, '_mvweb_review_author', true ),
					'text'   => $text,
					'source' => get_the_title( $work ),
					'stars'  => 0,
					'photo'  => 0,
					'doctor' => '',
					'video'  => '',
				);

				if ( count( $rows ) >= $limit ) {
					break;
				}
			}
		} elseif ( isset( $props['items'] ) && is_array( $props['items'] ) ) {
			foreach ( mvweb_core_visible_rows( $props['items'] ) as $item ) {
				$item += array(
					'title'  => '',
					'text'   => '',
					'source' => '',
					'stars'  => '',
					'photo'  => 0,
					'doctor' => '',
					'video'  => '',
				);

				if ( '' === trim( (string) $item['text'] ) ) {
					continue;
				}

				$rows[] = array(
					'name'   => (string) $item['title'],
					'text'   => (string) $item['text'],
					'source' => (string) $item['source'],
					'stars'  => isset( $stars[ $item['stars'] ] ) ? $stars[ $item['stars'] ] : 0,
					'photo'  => (int) $item['photo'],
					'doctor' => trim( (string) $item['doctor'] ),
					'video'  => trim( (string) $item['video'] ),
				);
			}
		}

		return $rows;
	}
}
