<?php
/**
 * The preview of the Customizer: settings that only change an attribute of the root element apply without a reload, the frame of the page gets edit shortcuts.
 *
 * Both are the theme's choice: it names the settings and the attributes
 * through mvweb_core_preview_attrs and the markup of the frame through
 * mvweb_core_preview_partials; without them the preview is as before.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_preview_attrs' ) ) {
	/**
	 * Settings shown in the preview by an attribute of the root element.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Setting => attribute name.
	 */
	function mvweb_core_preview_attrs() {
		/**
		 * Filter the settings the preview applies to the root element without a reload: setting => attribute name (data-…).
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $attrs Setting => attribute.
		 */
		$raw = (array) apply_filters( 'mvweb_core_preview_attrs', array() );
		$out = array();

		foreach ( $raw as $setting => $attr ) {
			$attr = strtolower( (string) $attr );

			if ( 1 === preg_match( '/^data-[a-z0-9-]+$/', $attr ) ) {
				$out[ sanitize_key( (string) $setting ) ] = $attr;
			}
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_core_preview_partials' ) ) {
	/**
	 * Parts of the frame with an edit shortcut in the preview: part => selector of its markup in the theme, and the settings the shortcut opens.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array{selector:string,settings:string[]}>
	 */
	function mvweb_core_preview_partials() {
		$settings = array(
			'header'  => array( 'mvweb_header_layout', 'mvweb_zone_header_main', 'mvweb_zone_header_actions', 'mvweb_zone_header_nav', 'mvweb_zone_header_topbar' ),
			'notice'  => array( 'mvweb_view_notice', 'mvweb_notice_text', 'mvweb_notice_label', 'mvweb_notice_link_text', 'mvweb_notice_url', 'mvweb_notice_closable' ),
			'topics'  => array( 'mvweb_view_topics', 'mvweb_topics_all_url' ),
			'mega'    => array( 'mvweb_view_mega', 'mvweb_mega_preview_image', 'mvweb_mega_preview_caption', 'mvweb_mega_preview_url' ),
			'footer'  => array( 'mvweb_zone_footer_main', 'mvweb_zone_footer_bottom', 'mvweb_footer_tagline' ),
			'sidebar' => array( 'mvweb_view_sidebar', 'mvweb_sidebar_side_blog', 'mvweb_sidebar_side_page' ),
		);

		/**
		 * Filter the selectors of the frame parts in the markup of the theme: part (header, notice, topics, mega, footer, sidebar) => CSS selector.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $selectors Part => selector.
		 */
		$selectors = (array) apply_filters( 'mvweb_core_preview_partials', array() );
		$out       = array();

		foreach ( $settings as $part => $list ) {
			$selector = isset( $selectors[ $part ] ) ? trim( wp_strip_all_tags( (string) $selectors[ $part ] ) ) : '';

			if ( '' !== $selector ) {
				$out[ $part ] = array(
					'selector' => $selector,
					'settings' => $list,
				);
			}
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_core_preview_widgets_support' ) ) {
	/**
	 * Widgets refresh on their own in the preview of a theme that marks its frame for the preview.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_preview_widgets_support() {
		if ( ! empty( mvweb_core_preview_partials() ) ) {
			add_theme_support( 'customize-selective-refresh-widgets' );
		}
	}
}
add_action( 'after_setup_theme', 'mvweb_core_preview_widgets_support', 30 );

if ( ! function_exists( 'mvweb_core_preview_register' ) ) {
	/**
	 * The attribute settings change without a reload; the parts of the frame get their edit shortcuts.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer manager.
	 *
	 * @return void
	 */
	function mvweb_core_preview_register( $wp_customize ) {
		$attrs = mvweb_core_preview_attrs();

		foreach ( array_keys( $attrs ) as $id ) {
			$setting = $wp_customize->get_setting( $id );

			if ( $setting ) {
				$setting->transport = 'postMessage';
			}
		}

		if ( ! isset( $wp_customize->selective_refresh ) ) {
			return;
		}

		foreach ( mvweb_core_preview_partials() as $part => $data ) {
			$settings = array();

			foreach ( $data['settings'] as $id ) {
				if ( ! isset( $attrs[ $id ] ) && $wp_customize->get_setting( $id ) ) {
					$settings[] = $id;
				}
			}

			if ( empty( $settings ) ) {
				continue;
			}

			$wp_customize->selective_refresh->add_partial(
				'mvweb_core_frame_' . $part,
				array(
					'selector'            => $data['selector'],
					'settings'            => $settings,
					'render_callback'     => '__return_false',
					'container_inclusive' => true,
					'fallback_refresh'    => true,
				)
			);
		}
	}
}
add_action( 'customize_register', 'mvweb_core_preview_register', 50 );

if ( ! function_exists( 'mvweb_core_preview_script' ) ) {
	/**
	 * The script of the preview that writes the attribute settings onto the root element.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_preview_script() {
		global $wp_customize;

		$attrs = mvweb_core_preview_attrs();

		if ( empty( $attrs ) ) {
			return;
		}

		$list = array();

		foreach ( $attrs as $id => $attr ) {
			$control = $wp_customize instanceof WP_Customize_Manager ? $wp_customize->get_control( $id ) : null;

			$list[] = array(
				'setting' => $id,
				'attr'    => $attr,
				'values'  => $control && is_array( $control->choices ) ? array_map( 'strval', array_keys( $control->choices ) ) : array(),
			);
		}

		$script = mvweb_core_asset_path( '/admin/js/customizer-preview.js' );

		wp_enqueue_script( 'mvweb-core-customizer-preview', MVWEB_CORE_URI . $script, array( 'customize-preview' ), mvweb_core_asset_version( $script ), true );
		wp_localize_script( 'mvweb-core-customizer-preview', 'mvwebCorePreview', array( 'attrs' => $list ) );
	}
}
add_action( 'customize_preview_init', 'mvweb_core_preview_script' );
