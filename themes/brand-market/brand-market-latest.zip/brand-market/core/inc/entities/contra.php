<?php
/**
 * The notice about contraindications for the pages of a clinic: a switch, the words, the place.
 *
 * It comes with add_theme_support( 'mvweb-contra' ). The core keeps the words
 * and the place the owner chose; the theme prints the notice with
 * template-parts/contra.php where its footer has room for each place: a band
 * above the footer, a line in the footer or a card with the licence. Asking
 * for one place gets the notice only when the owner chose that place.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_contra_supported' ) ) {
	/**
	 * Whether the theme draws the notice.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_contra_supported() {
		return current_theme_supports( 'mvweb-contra' );
	}
}

if ( ! function_exists( 'mvweb_core_contra_places' ) ) {
	/**
	 * The places the owner can choose.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Place => label.
	 */
	function mvweb_core_contra_places() {
		return array(
			'band' => __( 'A band above the footer', 'mvweb-core' ),
			'line' => __( 'A line in the footer', 'mvweb-core' ),
			'card' => __( 'A card with the licence in the footer', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_contra_text_default' ) ) {
	/**
	 * The words of the notice until the owner changes them.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_contra_text_default() {
		return __( 'Contraindications apply. A consultation with a specialist is required.', 'mvweb-core' );
	}
}

if ( ! function_exists( 'mvweb_core_licence_row' ) ) {
	/**
	 * The first licence among the company details.
	 *
	 * @since 0.1.0
	 *
	 * @return array{label:string,value:string} Empty strings when there is none.
	 */
	function mvweb_core_licence_row() {
		$rows  = json_decode( (string) get_theme_mod( 'mvweb_cz_requisites', '' ), true );
		$types = mvweb_cz_requisite_types();

		foreach ( is_array( $rows ) ? $rows : array() as $row ) {
			$value = trim( (string) ( $row['value'] ?? '' ) );

			if ( 'license' === ( $row['type'] ?? '' ) && '' !== $value ) {
				$label = trim( (string) ( $row['label'] ?? '' ) );

				return array(
					'label' => '' === $label ? (string) $types['license'] : $label,
					'value' => $value,
				);
			}
		}

		return array(
			'label' => '',
			'value' => '',
		);
	}
}

if ( ! function_exists( 'mvweb_core_contra' ) ) {
	/**
	 * What the notice prints.
	 *
	 * @since 0.1.0
	 *
	 * @param string $place Optional. A place; the notice is returned only if the owner chose it.
	 *
	 * @return array{text:string,place:string,licence:array{label:string,value:string}} Empty when the theme has no notice, it is off, the words are empty or the place is another.
	 */
	function mvweb_core_contra( $place = '' ) {
		if ( ! mvweb_core_contra_supported() || ! get_theme_mod( 'mvweb_contra_on', false ) ) {
			return array();
		}

		$text   = trim( (string) get_theme_mod( 'mvweb_contra_text', mvweb_core_contra_text_default() ) );
		$chosen = (string) get_theme_mod( 'mvweb_contra_place', 'band' );
		$chosen = isset( mvweb_core_contra_places()[ $chosen ] ) ? $chosen : 'band';

		if ( '' === $text || ( '' !== $place && $chosen !== $place ) ) {
			return array();
		}

		return array(
			'text'    => $text,
			'place'   => $chosen,
			'licence' => 'card' === $chosen ? mvweb_core_licence_row() : array(
				'label' => '',
				'value' => '',
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_contra_fields' ) ) {
	/**
	 * The switch, the words and the place of the notice.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_contra_fields( $kit ) {
		if ( ! mvweb_core_contra_supported() ) {
			return;
		}

		$on = array(
			array(
				'setting'  => 'mvweb_contra_on',
				'operator' => '==',
				'value'    => true,
			),
		);

		$kit->add_fields(
			array(
				array(
					'type'        => 'toggle',
					'settings'    => 'mvweb_contra_on',
					'section'     => 'mvweb_cz_footer_blocks',
					'label'       => __( 'Notice about contraindications', 'mvweb-core' ),
					'description' => __( 'A line on every page. Whether the size and the place of the words meet the rules for the site of a medical organisation is for the clinic to decide.', 'mvweb-core' ),
					'default'     => false,
				),
				array(
					'type'     => 'textarea',
					'settings' => 'mvweb_contra_text',
					'section'  => 'mvweb_cz_footer_blocks',
					'label'    => __( 'Words of the notice', 'mvweb-core' ),
					'default'  => mvweb_core_contra_text_default(),
					'required' => $on,
				),
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_contra_place',
					'section'     => 'mvweb_cz_footer_blocks',
					'label'       => __( 'Place of the notice', 'mvweb-core' ),
					'description' => __( 'The card takes the licence from the company details: add a detail of the kind “Licence” in Contacts.', 'mvweb-core' ),
					'default'     => 'band',
					'choices'     => mvweb_core_contra_places(),
					'required'    => $on,
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_contra_fields' );
