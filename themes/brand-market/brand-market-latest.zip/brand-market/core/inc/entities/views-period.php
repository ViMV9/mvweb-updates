<?php
/**
 * Views by days: the table of the daily views of the posts and the most read posts of a period.
 *
 * Works when the theme asks for it with add_theme_support( 'mvweb-views-period' ) and the views are counted.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_views_db_version' ) ) {
	/**
	 * The version of the schema of the tables of the core.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_views_db_version() {
		return '1';
	}
}

if ( ! function_exists( 'mvweb_core_views_table' ) ) {
	/**
	 * The name of the table of the daily views.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_views_table() {
		global $wpdb;

		return $wpdb->prefix . 'mvweb_views';
	}
}

if ( ! function_exists( 'mvweb_core_views_period_on' ) ) {
	/**
	 * Whether the views are counted by days: the theme asks for it and the table is in place.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_views_period_on() {
		return current_theme_supports( 'mvweb-views-period' ) && mvweb_core_views_on() && mvweb_core_views_db_version() === (string) get_option( 'mvweb_core_db_version', '' );
	}
}

if ( ! function_exists( 'mvweb_core_views_periods' ) ) {
	/**
	 * The periods of the list «Most read».
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Key => label.
	 */
	function mvweb_core_views_periods() {
		return array(
			'today' => __( 'Today', 'mvweb-core' ),
			'week'  => __( 'Week', 'mvweb-core' ),
			'month' => __( 'Month', 'mvweb-core' ),
			'year'  => __( 'Year', 'mvweb-core' ),
			'all'   => __( 'All time', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_views_install' ) ) {
	/**
	 * Create or update the table of the daily views when the version of the schema changes, and plan its daily cleaning.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_views_install() {
		if ( ! current_theme_supports( 'mvweb-views-period' ) ) {
			return;
		}

		if ( mvweb_core_views_db_version() !== (string) get_option( 'mvweb_core_db_version', '' ) ) {
			global $wpdb;

			require_once ABSPATH . 'wp-admin/includes/upgrade.php';

			dbDelta(
				'CREATE TABLE ' . mvweb_core_views_table() . " (
post_id bigint(20) unsigned NOT NULL,
day date NOT NULL,
hits int(10) unsigned NOT NULL DEFAULT 0,
PRIMARY KEY  (post_id,day),
KEY day (day)
) {$wpdb->get_charset_collate()};"
			);

			if ( mvweb_core_views_table() === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( mvweb_core_views_table() ) ) ) ) { // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- One check that the table was created.
				update_option( 'mvweb_core_db_version', mvweb_core_views_db_version(), true );
			}
		}

		if ( ! wp_next_scheduled( 'mvweb_core_views_prune' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'mvweb_core_views_prune' );
		}
	}
}
add_action( 'admin_init', 'mvweb_core_views_install' );

if ( ! function_exists( 'mvweb_core_views_prune' ) ) {
	/**
	 * Delete the daily views older than 400 days.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_views_prune() {
		global $wpdb;

		if ( mvweb_core_views_db_version() !== (string) get_option( 'mvweb_core_db_version', '' ) ) {
			return;
		}

		$table = mvweb_core_views_table();

		$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE day < %s", wp_date( 'Y-m-d', time() - 400 * DAY_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Own table; its name is not user input.
	}
}
add_action( 'mvweb_core_views_prune', 'mvweb_core_views_prune' );

if ( ! function_exists( 'mvweb_core_views_day_add' ) ) {
	/**
	 * Add a view of a post to the views of today, by the time zone of the site.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Post id.
	 *
	 * @return void
	 */
	function mvweb_core_views_day_add( $post_id ) {
		global $wpdb;

		if ( ! mvweb_core_views_period_on() ) {
			return;
		}

		$table = mvweb_core_views_table();

		$wpdb->query( $wpdb->prepare( "INSERT INTO {$table} (post_id, day, hits) VALUES (%d, %s, 1) ON DUPLICATE KEY UPDATE hits = hits + 1", (int) $post_id, wp_date( 'Y-m-d' ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- One atomic step in an own table; its name is not user input.
	}
}

if ( ! function_exists( 'mvweb_core_views_period_ids' ) ) {
	/**
	 * The ids of the most read published posts of a period, the most read first; when the period has fewer posts than places, the rest come from the views of all time.
	 *
	 * @since 0.1.0
	 *
	 * @param string              $period today, week, month, year or all.
	 * @param array<string,mixed> $args   Optional. count: how many (5 by default); category: a category with its subcategories; exclude: post ids to leave out.
	 *
	 * @return int[]
	 */
	function mvweb_core_views_period_ids( $period, array $args = array() ) {
		global $wpdb;

		$count    = isset( $args['count'] ) ? max( 1, (int) $args['count'] ) : 5;
		$category = isset( $args['category'] ) ? absint( $args['category'] ) : 0;
		$exclude  = isset( $args['exclude'] ) ? array_values( array_filter( array_map( 'absint', (array) $args['exclude'] ) ) ) : array();
		$days     = array(
			'today' => 1,
			'week'  => 7,
			'month' => 30,
			'year'  => 365,
		);
		$ids      = array();

		if ( isset( $days[ $period ] ) && mvweb_core_views_period_on() ) {
			$limit = $count + count( $exclude );
			$from  = wp_date( 'Y-m-d', time() - ( $days[ $period ] - 1 ) * DAY_IN_SECONDS );
			$key   = 'mvweb_ids_' . md5( 'period|' . $period . '|' . $category . '|' . $limit . '|' . $from . '|' . get_locale() . '|' . mvweb_core_ids_generation() );
			$ids   = get_transient( $key );

			if ( ! is_array( $ids ) ) {
				$table = mvweb_core_views_table();
				$terms = '';

				if ( $category > 0 ) {
					$list  = array_merge( array( $category ), array_map( 'absint', (array) get_term_children( $category, 'category' ) ) );
					$terms = ' AND v.post_id IN ( SELECT tr.object_id FROM ' . $wpdb->term_relationships . ' tr INNER JOIN ' . $wpdb->term_taxonomy . " tt ON tt.term_taxonomy_id = tr.term_taxonomy_id WHERE tt.taxonomy = 'category' AND tt.term_id IN ( " . implode( ',', array_filter( $list ) ) . ' ) )';
				}

				$ids = array_map(
					'intval',
					(array) $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Cached above in a transient.
						$wpdb->prepare(
							"SELECT v.post_id FROM {$table} v INNER JOIN {$wpdb->posts} p ON p.ID = v.post_id AND p.post_type = 'post' AND p.post_status = 'publish' WHERE v.day >= %s{$terms} GROUP BY v.post_id ORDER BY SUM(v.hits) DESC, v.post_id DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- The table names come from $wpdb and the terms are integers.
							$from,
							$limit
						)
					)
				);

				set_transient( $key, $ids, 10 * MINUTE_IN_SECONDS );
			}

			$ids = array_slice( array_values( array_diff( array_map( 'intval', $ids ), $exclude ) ), 0, $count );
		}

		if ( count( $ids ) < $count ) {
			$skip = array_merge( $ids, $exclude );
			$more = mvweb_core_cached_ids(
				array_merge(
					array(
						'post_type'      => 'post',
						'post_status'    => 'publish',
						'cat'            => $category,
						'posts_per_page' => $count + count( $skip ),
					),
					mvweb_core_top_args( 'read' )
				)
			);

			$ids = array_merge( $ids, array_slice( array_values( array_diff( $more, $skip ) ), 0, $count - count( $ids ) ) );
		}

		return $ids;
	}
}
