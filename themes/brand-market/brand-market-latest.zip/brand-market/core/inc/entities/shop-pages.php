<?php
/**
 * Shop pages of WooCommerce: the cart, the checkout, the order and the account as data — titles, trails, the fields the owner hides or makes optional, the words for screen readers, the consent at registration.
 *
 * The markup of these pages is the theme's: it replaces the templates of WooCommerce and dresses the fields.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WooCommerce' ) ) {
	return;
}

if ( ! function_exists( 'mvweb_core_account_endpoint' ) ) {
	/**
	 * The endpoint of the account being shown.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty on the dashboard and on the page of sign in.
	 */
	function mvweb_core_account_endpoint() {
		return WC()->query ? (string) WC()->query->get_current_endpoint() : '';
	}
}

if ( ! function_exists( 'mvweb_core_account_labels' ) ) {
	/**
	 * The names of the sections of the account.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Endpoint => label.
	 */
	function mvweb_core_account_labels() {
		return array(
			'dashboard'       => __( 'Dashboard', 'mvweb-core' ),
			'orders'          => __( 'Orders', 'mvweb-core' ),
			'downloads'       => __( 'Downloads', 'mvweb-core' ),
			'edit-address'    => ! wc_ship_to_billing_address_only() && wc_shipping_enabled() ? __( 'Addresses', 'mvweb-core' ) : __( 'Address', 'mvweb-core' ),
			'edit-account'    => __( 'My details', 'mvweb-core' ),
			'customer-logout' => __( 'Log out', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_account_menu_items' ) ) {
	/**
	 * Name the sections of the navigation the way the design does.
	 *
	 * @since 0.1.0
	 *
	 * @param array $items Endpoint => label.
	 *
	 * @return array
	 */
	function mvweb_core_account_menu_items( $items ) {
		return array_merge( $items, array_intersect_key( mvweb_core_account_labels(), $items ) );
	}
}
add_filter( 'woocommerce_account_menu_items', 'mvweb_core_account_menu_items', 20 );

if ( ! function_exists( 'mvweb_core_account_icon' ) ) {
	/**
	 * The icon of a section of the account.
	 *
	 * @since 0.1.0
	 *
	 * @param string $endpoint Endpoint.
	 *
	 * @return string Icon name.
	 */
	function mvweb_core_account_icon( $endpoint ) {
		$icons = array(
			'dashboard'       => 'layout-grid',
			'orders'          => 'package',
			'downloads'       => 'download',
			'edit-address'    => 'map-pin',
			'edit-account'    => 'user',
			'payment-methods' => 'lock',
			'customer-logout' => 'door',
		);

		return isset( $icons[ $endpoint ] ) ? $icons[ $endpoint ] : 'layout-grid';
	}
}

if ( ! function_exists( 'mvweb_core_account_order_id' ) ) {
	/**
	 * The order the account shows, when the customer may see it.
	 *
	 * @since 0.1.0
	 *
	 * @return int Zero outside the page of an order or for an order that is not theirs.
	 */
	function mvweb_core_account_order_id() {
		global $wp;

		$id = isset( $wp->query_vars['view-order'] ) ? absint( $wp->query_vars['view-order'] ) : 0;

		return $id && current_user_can( 'view_order', $id ) ? $id : 0; // phpcs:ignore WordPress.WP.Capabilities.Unknown -- Capability of WooCommerce.
	}
}

if ( ! function_exists( 'mvweb_core_account_head' ) ) {
	/**
	 * What the head of the page of the account says: the heading, the text under it and the trail.
	 *
	 * @since 0.1.0
	 *
	 * @return array{title:string,lead:string,trail:array<int,array{label:string,url:string}>}
	 */
	function mvweb_core_account_head() {
		static $head = null;

		if ( null !== $head ) {
			return $head;
		}

		$endpoint = mvweb_core_account_endpoint();
		$labels   = mvweb_core_account_labels();
		$page     = wc_get_page_id( 'myaccount' );
		$account  = array(
			'label' => '' !== get_the_title( $page ) ? get_the_title( $page ) : $labels['dashboard'],
			'url'   => (string) get_permalink( $page ),
		);
		$register = 'yes' === get_option( 'woocommerce_enable_myaccount_registration' );
		$head     = array(
			'title' => $account['label'],
			'lead'  => '',
			'trail' => array(),
		);

		if ( 'lost-password' === $endpoint ) {
			$sign_in       = array(
				'label' => __( 'Login', 'mvweb-core' ),
				'url'   => $account['url'],
			);
			$head['title'] = __( 'Password reset', 'mvweb-core' );
			$head['trail'] = is_user_logged_in() ? array() : array( $sign_in );

			return $head;
		}

		if ( ! is_user_logged_in() ) {
			$head['title'] = $register ? __( 'Sign in and register', 'mvweb-core' ) : __( 'Login', 'mvweb-core' );
			$head['lead']  = $register ? __( 'Sign in to see your orders, or create an account in a minute.', 'mvweb-core' ) : __( 'Sign in to see your orders.', 'mvweb-core' );

			return $head;
		}

		if ( '' === $endpoint ) {
			return $head;
		}

		$head['trail'] = array( $account );
		$head['title'] = isset( $labels[ $endpoint ] ) ? $labels[ $endpoint ] : (string) WC()->query->get_endpoint_title( $endpoint );

		if ( 'view-order' === $endpoint ) {
			$order = wc_get_order( mvweb_core_account_order_id() );

			$head['trail'][] = array(
				'label' => $labels['orders'],
				'url'   => wc_get_account_endpoint_url( 'orders' ),
			);
			$head['title']   = $order ? sprintf(
				/* translators: %s: order number. */
				__( 'Order No. %s', 'mvweb-core' ),
				$order->get_order_number()
			) : $labels['orders'];
		}

		if ( 'edit-address' === $endpoint && empty( mvweb_core_account_address_type() ) ) {
			$head['lead'] = wp_strip_all_tags( (string) apply_filters( 'woocommerce_my_account_my_address_description', __( 'These addresses are filled in at the checkout.', 'mvweb-core' ) ) ); // phpcs:ignore WooCommerce.Commenting.CommentHooks.MissingHookComment -- Hook of WooCommerce.
		}

		return $head;
	}
}

if ( ! function_exists( 'mvweb_core_account_address_type' ) ) {
	/**
	 * The address being edited.
	 *
	 * @since 0.1.0
	 *
	 * @return string billing, shipping, or empty on the list of addresses.
	 */
	function mvweb_core_account_address_type() {
		global $wp;

		$type = isset( $wp->query_vars['edit-address'] ) ? sanitize_key( $wp->query_vars['edit-address'] ) : '';

		return in_array( $type, array( 'billing', 'shipping' ), true ) ? $type : '';
	}
}

if ( ! function_exists( 'mvweb_core_account_crumbs' ) ) {
	/**
	 * The breadcrumbs of the account: home, the account, the section.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $items Trail so far.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_account_crumbs( $items ) {
		if ( ! mvweb_core_account_active() || ! is_page() || empty( $items ) ) {
			return $items;
		}

		$head  = mvweb_core_account_head();
		$trail = array( reset( $items ) );

		foreach ( $head['trail'] as $crumb ) {
			$trail[] = $crumb;
		}

		$trail[] = array( 'label' => $head['title'] );

		return $trail;
	}
}
add_filter( 'mvweb_core_crumb_items', 'mvweb_core_account_crumbs' );

if ( ! function_exists( 'mvweb_core_account_notice_tags' ) ) {
	/**
	 * Let the notices keep the icon of the alert.
	 *
	 * @since 0.1.0
	 *
	 * @param array $tags Allowed tags.
	 *
	 * @return array
	 */
	function mvweb_core_account_notice_tags( $tags ) {
		$tags['svg']    = array(
			'class'       => array(),
			'aria-hidden' => array(),
			'focusable'   => array(),
			'role'        => array(),
			'style'       => array(),
			'xmlns'       => array(),
		);
		$tags['symbol'] = array(
			'id'      => array(),
			'viewbox' => array(),
		);
		$tags['path']   = array( 'd' => array() );
		$tags['use']    = array( 'href' => array() );

		return $tags;
	}
}
add_filter( 'woocommerce_kses_notice_allowed_tags', 'mvweb_core_account_notice_tags' );

if ( ! function_exists( 'mvweb_core_account_register_name' ) ) {
	/**
	 * Keep the name the registration form asked for.
	 *
	 * @since 0.1.0
	 *
	 * @param int $customer_id New customer.
	 *
	 * @return void
	 */
	function mvweb_core_account_register_name( $customer_id ) {
		if ( empty( $_POST['first_name'] ) || ! is_string( $_POST['first_name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked by WooCommerce before the customer is created.
			return;
		}

		$name = sanitize_text_field( wp_unslash( $_POST['first_name'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked by WooCommerce before the customer is created.

		if ( '' === $name ) {
			return;
		}

		wp_update_user(
			array(
				'ID'           => absint( $customer_id ),
				'first_name'   => $name,
				'display_name' => $name,
			)
		);
		update_user_meta( absint( $customer_id ), 'billing_first_name', $name );
	}
}
add_action( 'woocommerce_created_customer', 'mvweb_core_account_register_name' );

if ( ! function_exists( 'mvweb_core_account_register_consent' ) ) {
	/**
	 * Refuse a registration without the consent the form asks for.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Error $errors Errors so far.
	 *
	 * @return WP_Error
	 */
	function mvweb_core_account_register_consent( $errors ) {
		if ( empty( $_POST['agree'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Checked by WooCommerce before this filter runs.
			$errors->add( 'mvweb_consent', __( 'Please confirm your consent to the processing of personal data.', 'mvweb-core' ) );
		}

		return $errors;
	}
}
add_filter( 'woocommerce_process_registration_errors', 'mvweb_core_account_register_consent' );

if ( ! function_exists( 'mvweb_core_cart_crumbs' ) ) {
	/**
	 * The trail of the cart and of the checkout: the catalogue leads to the cart, the cart to the checkout.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array<string,mixed>> $items Trail items.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_cart_crumbs( $items ) {
		if ( ! mvweb_core_cart_page_here() || empty( $items ) ) {
			return $items;
		}

		$home = reset( $items );
		$cart = array(
			'label' => mvweb_core_cart_page_title( 'cart' ),
			'url'   => wc_get_cart_url(),
		);

		if ( is_cart() ) {
			$catalog = mvweb_core_catalog_page_url();
			$trail   = array( $home );

			if ( trailingslashit( $catalog ) !== trailingslashit( home_url( '/' ) ) ) {
				$trail[] = array(
					'label' => __( 'Catalog', 'mvweb-core' ),
					'url'   => $catalog,
				);
			}

			$trail[] = array( 'label' => $cart['label'] );

			return $trail;
		}

		if ( is_wc_endpoint_url( 'order-received' ) ) {
			return array( $home, array( 'label' => __( 'Order received', 'mvweb-core' ) ) );
		}

		if ( is_wc_endpoint_url( 'order-pay' ) ) {
			return array( $home, $cart, array( 'label' => __( 'Order payment', 'mvweb-core' ) ) );
		}

		return array( $home, $cart, array( 'label' => mvweb_core_cart_page_title( 'checkout' ) ) );
	}
}
add_filter( 'mvweb_core_crumb_items', 'mvweb_core_cart_crumbs', 20 );

if ( ! function_exists( 'mvweb_core_cart_page_title' ) ) {
	/**
	 * The title of the cart or of the checkout page.
	 *
	 * @since 0.1.0
	 *
	 * @param string $page cart or checkout.
	 *
	 * @return string
	 */
	function mvweb_core_cart_page_title( $page ) {
		$id    = wc_get_page_id( $page );
		$title = $id > 0 ? trim( (string) get_the_title( $id ) ) : '';

		if ( '' !== $title ) {
			return $title;
		}

		return 'cart' === $page ? __( 'Cart', 'mvweb-core' ) : __( 'Checkout', 'mvweb-core' );
	}
}

if ( ! function_exists( 'mvweb_core_checkout_error_label' ) ) {
	/**
	 * Name a field in a checkout error by its label alone: the buyer fills one address, «Billing» means nothing to them.
	 *
	 * @since 0.1.0
	 *
	 * @param string $translation Translated text.
	 * @param string $text        Original text.
	 * @param string $context     Context of the text.
	 * @param string $domain      Text domain.
	 *
	 * @return string
	 */
	function mvweb_core_checkout_error_label( $translation, $text, $context, $domain ) {
		return ( 'woocommerce' === $domain && 'checkout-validation' === $context && 'Billing %s' === $text ) ? '%s' : $translation;
	}
}
add_filter( 'gettext_with_context', 'mvweb_core_checkout_error_label', 10, 4 );

if ( ! function_exists( 'mvweb_core_checkout_field_names' ) ) {
	/**
	 * Fields of the checkout the owner can hide or make optional, beside the company, the second address line and the phone WooCommerce offers itself.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<int,mixed>> Label, choices and an optional description by field.
	 */
	function mvweb_core_checkout_field_names() {
		$all = array(
			'required' => __( 'Required', 'mvweb-core' ),
			'optional' => __( 'Optional', 'mvweb-core' ),
			'hidden'   => _x( 'Hidden', 'checkout field', 'mvweb-core' ),
		);

		return array(
			'last_name' => array( __( 'Last name field', 'mvweb-core' ), $all, __( 'Fields of the checkout form. «Required» leaves a field as WooCommerce and the delivery plugins set it. The settings apply to the addresses in the account too.', 'mvweb-core' ) ),
			'email'     => array( __( 'E-mail field', 'mvweb-core' ), array_slice( $all, 0, 2, true ), __( 'It cannot be hidden: without it the buyer gets no letter about the order.', 'mvweb-core' ) ),
			'address_1' => array( __( 'Street and house field', 'mvweb-core' ), $all ),
			'city'      => array( __( 'Town field', 'mvweb-core' ), $all ),
			'state'     => array( __( 'Region field', 'mvweb-core' ), $all ),
			'postcode'  => array( __( 'Postcode field', 'mvweb-core' ), $all ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_checkout_field_mode' ) ) {
	/**
	 * Whether a field of the checkout is required, optional or hidden.
	 *
	 * @since 0.1.0
	 *
	 * @param string $name Field name without the billing or shipping prefix.
	 *
	 * @return string
	 */
	function mvweb_core_checkout_field_mode( $name ) {
		$names = mvweb_core_checkout_field_names();
		$mode  = (string) get_theme_mod( 'mvweb_checkout_' . $name . '_field', 'required' );

		return isset( $names[ $name ][1][ $mode ] ) ? $mode : 'required';
	}
}

if ( ! function_exists( 'mvweb_core_address_fields' ) ) {
	/**
	 * Show the label of the second address line and make the chosen address fields optional or drop them.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $fields Default address fields.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_address_fields( $fields ) {
		if ( isset( $fields['address_2'] ) ) {
			$fields['address_2']['label']       = __( 'Flat, entrance, floor', 'mvweb-core' );
			$fields['address_2']['label_class'] = array_values( array_diff( (array) ( $fields['address_2']['label_class'] ?? array() ), array( 'screen-reader-text' ) ) );
			$fields['address_2']['placeholder'] = '';
		}

		foreach ( array_keys( mvweb_core_checkout_field_names() ) as $name ) {
			if ( ! isset( $fields[ $name ] ) ) {
				continue;
			}

			$mode = mvweb_core_checkout_field_mode( $name );

			if ( 'hidden' === $mode ) {
				unset( $fields[ $name ] );
			} elseif ( 'optional' === $mode ) {
				$fields[ $name ]['required'] = false;
			}
		}

		return $fields;
	}
}
add_filter( 'woocommerce_default_address_fields', 'mvweb_core_address_fields', 20 );

if ( ! function_exists( 'mvweb_core_billing_email_field' ) ) {
	/**
	 * Make the e-mail of the buyer optional when the owner chose so.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $fields Billing fields.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_billing_email_field( $fields ) {
		if ( isset( $fields['billing_email'] ) && 'optional' === mvweb_core_checkout_field_mode( 'email' ) ) {
			$fields['billing_email']['required'] = false;
		}

		return $fields;
	}
}
add_filter( 'woocommerce_billing_fields', 'mvweb_core_billing_email_field', 20 );

if ( ! function_exists( 'mvweb_core_checkout_field_controls' ) ) {
	/**
	 * Add the choice of the address and contact fields; the arrangement of the Customizer moves them, with the three of WooCommerce, to «Checkout and order» of the theme.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer.
	 *
	 * @return void
	 */
	function mvweb_core_checkout_field_controls( $wp_customize ) {
		if ( ! $wp_customize->get_section( 'woocommerce_checkout' ) ) {
			return;
		}

		$priority = 15;

		foreach ( mvweb_core_checkout_field_names() as $name => $field ) {
			$id      = 'mvweb_checkout_' . $name . '_field';
			$choices = $field[1];

			$wp_customize->add_setting(
				$id,
				array(
					'default'           => 'required',
					'capability'        => 'manage_woocommerce',
					'sanitize_callback' => static function ( $value ) use ( $choices ) {
						return is_string( $value ) && isset( $choices[ $value ] ) ? $value : 'required';
					},
				)
			);

			$wp_customize->add_control(
				$id,
				array(
					'label'       => $field[0],
					'description' => isset( $field[2] ) ? $field[2] : '',
					'section'     => 'woocommerce_checkout',
					'type'        => 'select',
					'choices'     => $choices,
					'priority'    => $priority++,
				)
			);
		}

		$own = array(
			'company'   => __( 'Company field', 'mvweb-core' ),
			'phone'     => __( 'Phone field', 'mvweb-core' ),
			'address_2' => __( 'Flat, entrance, floor field', 'mvweb-core' ),
		);

		foreach ( $own as $name => $label ) {
			$control = $wp_customize->get_control( 'woocommerce_checkout_' . $name . '_field' );

			if ( $control ) {
				$control->label   = $label;
				$control->choices = array(
					'required' => __( 'Required', 'mvweb-core' ),
					'optional' => __( 'Optional', 'mvweb-core' ),
					'hidden'   => _x( 'Hidden', 'checkout field', 'mvweb-core' ),
				);
			}
		}
	}
}
add_action( 'customize_register', 'mvweb_core_checkout_field_controls', 20 );

if ( ! function_exists( 'mvweb_core_checkout_preview' ) ) {
	/**
	 * Open the checkout in the Customizer preview when «Checkout and order» is expanded, as WooCommerce does for its own section.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_checkout_preview() {
		wp_add_inline_script(
			'customize-controls',
			'wp.customize.bind("ready",function(){var url=' . wp_json_encode( wc_get_checkout_url() ) . ';wp.customize.section("mvweb_cz_conversion_checkout",function(section){section.expanded.bind(function(open){if(open&&wp.customize.previewer.previewUrl()!==url){wp.customize.previewer.previewUrl.set(url);}});});});'
		);
	}
}
add_action( 'customize_controls_enqueue_scripts', 'mvweb_core_checkout_preview' );

if ( ! function_exists( 'mvweb_core_cart_positions' ) ) {
	/**
	 * How many different goods lie in the cart.
	 *
	 * @since 0.1.0
	 *
	 * @return int
	 */
	function mvweb_core_cart_positions() {
		return WC()->cart ? count( WC()->cart->get_cart() ) : 0;
	}
}

if ( ! function_exists( 'mvweb_core_cart_announce' ) ) {
	/**
	 * What a screen reader is told when the cart has changed.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_cart_announce() {
		$count = mvweb_core_cart_positions();

		if ( $count < 1 ) {
			return __( 'The cart is empty', 'mvweb-core' );
		}

		/* translators: 1: number of goods with the word, 2: sum. */
		return sprintf( __( 'In the cart: %1$s, %2$s', 'mvweb-core' ), mvweb_core_cart_count_label( $count ), html_entity_decode( wp_strip_all_tags( (string) WC()->cart->get_cart_subtotal() ), ENT_QUOTES, 'UTF-8' ) );
	}
}

if ( ! function_exists( 'mvweb_core_cart_count_label' ) ) {
	/**
	 * The number of goods in the cart as a phrase.
	 *
	 * @since 0.1.0
	 *
	 * @param int $count Number of pieces.
	 *
	 * @return string
	 */
	function mvweb_core_cart_count_label( $count ) {
		/* translators: %s: number of items in the cart. */
		return sprintf( _n( '%s item', '%s items', (int) $count, 'mvweb-core' ), number_format_i18n( (int) $count ) );
	}
}

if ( ! function_exists( 'mvweb_core_cart_hero_meta' ) ) {
	/**
	 * The facts under the heading of the cart, in the order of the composition.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_cart_hero_meta() {
		if ( ! WC()->cart ) {
			return array();
		}

		$facts = array();

		foreach ( mvweb_core_layout_order( 'cart.hero' ) as $slug ) {
			$text = 'count' === $slug
				? mvweb_core_cart_count_label( mvweb_core_cart_positions() )
				: ( 'shipping' === $slug ? mvweb_core_cart_ship_text( 'mvweb_cart_ship_text' ) : '' );

			if ( '' !== $text ) {
				$facts[] = $text;
			}
		}

		return $facts;
	}
}

if ( ! function_exists( 'mvweb_core_address_keys' ) ) {
	/**
	 * The billing fields that make up an address, the rest are contacts.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_address_keys() {
		return array( 'billing_country', 'billing_address_1', 'billing_address_2', 'billing_city', 'billing_state', 'billing_postcode' );
	}
}

if ( ! function_exists( 'mvweb_core_pay_fail_lead' ) ) {
	/**
	 * The text under the heading of a payment that did not go through.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Order $order Order.
	 *
	 * @return string
	 */
	function mvweb_core_pay_fail_lead( $order ) {
		/* translators: %s: number of the order. */
		$lead = sprintf( __( 'Order No. %s is created, but the payment did not complete. The money was not taken.', 'mvweb-core' ), $order->get_order_number() );
		$hold = 'yes' === get_option( 'woocommerce_manage_stock' ) ? absint( get_option( 'woocommerce_hold_stock_minutes' ) ) : 0;

		if ( $hold > 0 ) {
			/* translators: %s: how long the goods are held, like "24 hours". */
			$lead .= ' ' . sprintf( __( 'The goods are held for you for %s.', 'mvweb-core' ), human_time_diff( 0, $hold * MINUTE_IN_SECONDS ) );
		}

		return $lead;
	}
}

if ( ! function_exists( 'mvweb_core_order_payment_line' ) ) {
	/**
	 * How the order is paid and whether the money has come.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Order $order Order.
	 *
	 * @return string Empty for an order that needs no payment.
	 */
	function mvweb_core_order_payment_line( $order ) {
		$title = trim( wp_strip_all_tags( (string) $order->get_payment_method_title() ) );

		if ( '' === $title ) {
			return '';
		}

		if ( $order->get_date_paid() ) {
			return $title . ', ' . __( 'paid', 'mvweb-core' );
		}

		if ( $order->has_status( array( 'on-hold', 'pending' ) ) ) {
			return $title . ', ' . __( 'waiting for the payment', 'mvweb-core' );
		}

		return $title;
	}
}

if ( ! function_exists( 'mvweb_core_shipping_rates' ) ) {
	/**
	 * The delivery methods the customer can choose from, for every package of the cart.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array<string,mixed>> Each package: index, chosen (rate id), rates (id, method, label, cost, taxed).
	 */
	function mvweb_core_shipping_rates() {
		$packages = WC()->shipping() ? WC()->shipping()->get_packages() : array();
		$chosen   = (array) WC()->session->get( 'chosen_shipping_methods', array() );
		$result   = array();

		foreach ( $packages as $index => $package ) {
			if ( empty( $package['rates'] ) ) {
				continue;
			}

			$rates = array();

			foreach ( $package['rates'] as $rate ) {
				$rates[] = array(
					'id'     => $rate->get_id(),
					'method' => $rate->get_method_id(),
					'label'  => $rate->get_label(),
					'cost'   => (float) $rate->get_cost() + ( WC()->cart->display_prices_including_tax() ? array_sum( $rate->get_taxes() ) : 0 ),
					'rate'   => $rate,
				);
			}

			$result[] = array(
				'index'  => (int) $index,
				'chosen' => isset( $chosen[ $index ] ) ? (string) $chosen[ $index ] : '',
				'rates'  => $rates,
			);
		}

		return $result;
	}
}

if ( ! function_exists( 'mvweb_core_shop_columns' ) ) {
	/**
	 * Products in a row of the store lists: the column field of the theme, so WooCommerce hides its own columns and rows fields.
	 *
	 * @since 0.1.0
	 *
	 * @return int
	 */
	function mvweb_core_shop_columns() {
		$columns = (string) get_theme_mod( 'mvweb_catalog_columns', '3' );

		return in_array( $columns, array( '4', '5' ), true ) ? (int) $columns : 3;
	}
}
add_filter( 'loop_shop_columns', 'mvweb_core_shop_columns' );

if ( ! function_exists( 'mvweb_core_shop_per_page' ) ) {
	/**
	 * Products on one page of the shop and of every product category.
	 *
	 * @since 0.1.0
	 *
	 * @return int
	 */
	function mvweb_core_shop_per_page() {
		return max( 1, absint( mvweb_core_option( 'mvweb_items_per_page' ) ) );
	}
}
add_filter( 'loop_shop_per_page', 'mvweb_core_shop_per_page' );

if ( ! function_exists( 'mvweb_core_shop_per_page_control' ) ) {
	/**
	 * The field «Products per page» in the product list section.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer manager.
	 *
	 * @return void
	 */
	function mvweb_core_shop_per_page_control( $wp_customize ) {
		if ( ! $wp_customize->get_section( 'mvweb_cz_catalog_archive' ) ) {
			return;
		}

		$wp_customize->add_setting(
			'mvweb_items_per_page',
			array(
				'default'           => mvweb_core_catalog_defaults()['mvweb_items_per_page'],
				'capability'        => 'edit_theme_options',
				'sanitize_callback' => static function ( $value ) {
					return min( 96, max( 1, absint( $value ) ) );
				},
			)
		);

		$wp_customize->add_control(
			'mvweb_items_per_page',
			array(
				'label'       => __( 'Products per page', 'mvweb-core' ),
				'description' => __( 'In the shop and in every product category. The rest go to the next pages.', 'mvweb-core' ),
				'section'     => 'mvweb_cz_catalog_archive',
				'type'        => 'number',
				'input_attrs' => array(
					'min'  => 1,
					'max'  => 96,
					'step' => 1,
				),
			)
		);
	}
}
add_action( 'customize_register', 'mvweb_core_shop_per_page_control', 20 );
