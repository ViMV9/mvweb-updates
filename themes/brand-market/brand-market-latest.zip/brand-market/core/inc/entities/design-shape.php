<?php
/**
 * Corner radius of the whole site: one setting, four tokens.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_radius_choices' ) ) {
	/**
	 * The radii an owner can pick, in pixels.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_radius_choices() {
		return array(
			'0'  => __( 'Sharp corners', 'mvweb-core' ),
			'4'  => '4 px',
			'6'  => '6 px',
			'8'  => '8 px',
			'10' => '10 px',
			'16' => '16 px',
			'20' => '20 px',
		);
	}
}

if ( ! function_exists( 'mvweb_core_radius_default' ) ) {
	/**
	 * The radius a theme ships in its tokens, before the owner picks one.
	 *
	 * @since 0.1.0
	 *
	 * @return string One of the keys of mvweb_core_radius_choices().
	 */
	function mvweb_core_radius_default() {
		/**
		 * Filter the radius the theme stylesheet already carries.
		 *
		 * @since 0.1.0
		 *
		 * @param string $radius Key of mvweb_core_radius_choices(); 10 by default.
		 */
		$radius = (string) apply_filters( 'mvweb_core_radius_default', '10' );

		return isset( mvweb_core_radius_choices()[ $radius ] ) ? $radius : '10';
	}
}

if ( ! function_exists( 'mvweb_core_radius' ) ) {
	/**
	 * The radius picked for the site.
	 *
	 * @since 0.1.0
	 *
	 * @return string One of the keys of mvweb_core_radius_choices().
	 */
	function mvweb_core_radius() {
		$default = mvweb_core_radius_default();
		$radius  = (string) get_theme_mod( 'mvweb_radius', $default );

		return isset( mvweb_core_radius_choices()[ $radius ] ) ? $radius : $default;
	}
}

if ( ! function_exists( 'mvweb_core_radius_register_fields' ) ) {
	/**
	 * Hand the field to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_radius_register_fields( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'radio',
					'settings'    => 'mvweb_radius',
					'section'     => 'mvweb_cz_design_preset',
					'label'       => __( 'Corners', 'mvweb-core' ),
					'description' => __( 'One radius for buttons, fields, cards, windows and pictures. With sharp corners the round chips and counters turn sharp too.', 'mvweb-core' ),
					'default'     => mvweb_core_radius_default(),
					'choices'     => mvweb_core_radius_choices(),
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_radius_register_fields' );

if ( ! function_exists( 'mvweb_core_print_radius' ) ) {
	/**
	 * Print the radius tokens when the owner moved them off the default.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_print_radius() {
		$radius = mvweb_core_radius();

		if ( mvweb_core_radius_default() === $radius ) {
			return;
		}

		$px     = (int) $radius . 'px';
		$tokens = array(
			'sm'   => $px,
			'md'   => $px,
			'lg'   => $px,
			'full' => '0' === $radius ? '0' : '999px',
		);

		/**
		 * Filters the radius tokens printed for the chosen corners.
		 *
		 * A theme may spread one setting into a scale (small, middle, large) and keep
		 * round elements round with sharp corners. Each value is a CSS length.
		 *
		 * @since 0.1.0
		 *
		 * @param array  $tokens Keys sm, md, lg, full.
		 * @param string $radius Chosen key of mvweb_core_radius_choices().
		 */
		$tokens = (array) apply_filters( 'mvweb_core_radius_tokens', $tokens, $radius );
		$css    = array();

		foreach ( array(
			'sm'   => '--mvweb-t-radius-sm',
			'md'   => '--mvweb-t-radius',
			'lg'   => '--mvweb-t-radius-lg',
			'full' => '--mvweb-t-radius-full',
		) as $key => $token ) {
			$value = isset( $tokens[ $key ] ) ? (string) $tokens[ $key ] : '';

			if ( preg_match( '/^\d+(\.\d+)?(px|rem|em|%)?$/', $value ) ) {
				$css[] = $token . ':' . $value;
			}
		}

		if ( ! $css ) {
			return;
		}

		printf(
			"<style id='mvweb-core-radius'>:root{%s}</style>\n",
			implode( ';', $css ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Token names are fixed, values pass the length pattern above.
		);
	}
}
add_action( 'wp_head', 'mvweb_core_print_radius', 11 );
