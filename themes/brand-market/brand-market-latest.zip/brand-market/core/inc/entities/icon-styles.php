<?php
/**
 * Icon styles: one set of icon names, drawn in several styles the owner picks from.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_icon_styles' ) ) {
	/**
	 * The icon styles a site can use.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Style key => label.
	 */
	function mvweb_core_icon_styles() {
		$styles = array();

		if ( '' !== mvweb_core_icon_theme_sprite() ) {
			$styles['theme'] = __( 'Drawn for the theme', 'mvweb-core' );
		}

		return $styles + array(
			'tabler'           => __( 'Outline', 'mvweb-core' ),
			'lucide'           => __( 'Soft outline', 'mvweb-core' ),
			'iconoir'          => __( 'Thin outline', 'mvweb-core' ),
			'phosphor-light'   => _x( 'Light', 'icons', 'mvweb-core' ),
			'phosphor-bold'    => __( 'Bold', 'mvweb-core' ),
			'phosphor-fill'    => _x( 'Filled', 'icons', 'mvweb-core' ),
			'phosphor-duotone' => __( 'Two-tone', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_icon_theme_sprite' ) ) {
	/**
	 * The sprite the theme draws its icons in.
	 *
	 * @since 0.1.0
	 *
	 * @return string Path, or an empty string.
	 */
	function mvweb_core_icon_theme_sprite() {
		$path = get_template_directory() . '/assets/icons/sprite.svg';

		return is_readable( $path ) ? $path : '';
	}
}

if ( ! function_exists( 'mvweb_core_icon_style_default' ) ) {
	/**
	 * The style a site starts with.
	 *
	 * @since 0.1.0
	 *
	 * @return string Key of mvweb_core_icon_styles().
	 */
	function mvweb_core_icon_style_default() {
		/**
		 * Filters the icon style a site starts with.
		 *
		 * @since 0.1.0
		 *
		 * @param string $style Key of mvweb_core_icon_styles().
		 */
		$style  = (string) apply_filters( 'mvweb_core_icon_style_default', '' !== mvweb_core_icon_theme_sprite() ? 'theme' : 'tabler' );
		$styles = mvweb_core_icon_styles();

		return isset( $styles[ $style ] ) ? $style : 'tabler';
	}
}

if ( ! function_exists( 'mvweb_core_icon_style' ) ) {
	/**
	 * The style picked for the site.
	 *
	 * @since 0.1.0
	 *
	 * @return string Key of mvweb_core_icon_styles().
	 */
	function mvweb_core_icon_style() {
		$style  = (string) get_theme_mod( 'mvweb_icon_style', mvweb_core_icon_style_default() );
		$styles = mvweb_core_icon_styles();

		return isset( $styles[ $style ] ) ? $style : mvweb_core_icon_style_default();
	}
}

if ( ! function_exists( 'mvweb_core_icon_files' ) ) {
	/**
	 * The sprites the icons come from; a later file wins for the same name.
	 *
	 * @since 0.1.0
	 *
	 * @return string[] Paths.
	 */
	function mvweb_core_icon_files() {
		$style = mvweb_core_icon_style();
		$files = array( MVWEB_CORE_DIR . '/assets/icons/tabler.svg' );

		if ( 'theme' === $style ) {
			$files[] = mvweb_core_icon_theme_sprite();
		} elseif ( 'tabler' !== $style ) {
			$files[] = MVWEB_CORE_DIR . '/assets/icons/' . $style . '.svg';
		}

		$files[] = MVWEB_CORE_DIR . '/assets/icons/brands.svg';

		if ( get_stylesheet_directory() !== get_template_directory() ) {
			$files = array_merge( $files, (array) glob( get_stylesheet_directory() . '/assets/icons/*.svg' ) );
		}

		return $files;
	}
}

if ( ! function_exists( 'mvweb_core_icon_symbols' ) ) {
	/**
	 * Every symbol of the picked style, keyed by icon name.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Name => <symbol> markup.
	 */
	function mvweb_core_icon_symbols() {
		static $symbols = null;

		if ( null !== $symbols ) {
			return $symbols;
		}

		$symbols = array();

		foreach ( mvweb_core_icon_files() as $path ) {
			if ( is_readable( $path ) && preg_match_all( '#<symbol id="mvweb-t-icon-([a-z0-9-]+)".*?</symbol>#s', (string) file_get_contents( $path ), $found, PREG_SET_ORDER ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Local SVG shipped with the theme.
				foreach ( $found as $match ) {
					$symbols[ $match[1] ] = $match[0];
				}
			}
		}

		return $symbols;
	}
}

if ( ! function_exists( 'mvweb_core_icon_symbol' ) ) {
	/**
	 * The symbol of an icon, the first time the page asks for it.
	 *
	 * @since 0.1.0
	 *
	 * @param string $name Icon name.
	 *
	 * @return string A hidden <svg> with the symbol, or an empty string.
	 */
	function mvweb_core_icon_symbol( $name ) {
		static $printed = array();

		$symbols = mvweb_core_icon_symbols();

		if ( ! isset( $symbols[ $name ] ) || isset( $printed[ $name ] ) ) {
			return '';
		}

		$printed[ $name ] = true;

		return '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" style="display:none">' . $symbols[ $name ] . '</svg>';
	}
}

if ( ! function_exists( 'mvweb_core_icon_sprite' ) ) {
	/**
	 * Every symbol of the picked style in one hidden sprite.
	 *
	 * @since 0.1.0
	 *
	 * @return string
	 */
	function mvweb_core_icon_sprite() {
		return '<svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" style="display:none">' . implode( '', mvweb_core_icon_symbols() ) . '</svg>';
	}
}

if ( ! function_exists( 'mvweb_core_print_script_icons' ) ) {
	/**
	 * Print the icons the scripts of the core draw on their own.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_print_script_icons() {
		if ( ! current_theme_supports( 'mvweb-icons' ) ) {
			return;
		}

		foreach ( array( 'check' ) as $name ) {
			echo mvweb_core_icon_symbol( $name ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Trusted local SVG shipped with the theme.
		}
	}
}
add_action( 'wp_body_open', 'mvweb_core_print_script_icons' );

if ( ! function_exists( 'mvweb_core_icon_register_fields' ) ) {
	/**
	 * Hand the field to the Customizer Kit.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_icon_register_fields( $kit ) {
		if ( ! current_theme_supports( 'mvweb-icons' ) ) {
			return;
		}

		$kit->add_fields(
			array(
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_icon_style',
					'section'     => 'mvweb_cz_design_preset',
					'label'       => __( 'Icons', 'mvweb-core' ),
					'description' => __( 'The look of every icon of the site. Logos of social networks and messengers stay as they are.', 'mvweb-core' ),
					'default'     => mvweb_core_icon_style_default(),
					'choices'     => mvweb_core_icon_styles(),
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_icon_register_fields' );
