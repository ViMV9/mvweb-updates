<?php
/**
 * Boxes: a grouped product sold whole with a discount.
 *
 * The box is a grouped product of WooCommerce marked as a box. Its discount,
 * end and limit of purchases live in a hidden coupon of the cart type that the
 * core writes when the box is saved: WooCommerce counts the uses, holds them
 * while an order is paid, gives them back on a cancelled order and shows them
 * in the coupon reports. The coupon is applied when the box goes into the
 * cart and holds only while the whole box is there.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_is_box' ) ) {
	/**
	 * Whether a product is a box.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product|int|null $product Product or its id.
	 *
	 * @return bool
	 */
	function mvweb_core_is_box( $product ) {
		$product = is_numeric( $product ) ? wc_get_product( (int) $product ) : $product;

		return $product instanceof WC_Product && $product->is_type( 'grouped' ) && 'yes' === $product->get_meta( '_mvweb_box' );
	}
}

if ( ! function_exists( 'mvweb_core_box_coupon' ) ) {
	/**
	 * The coupon of a box.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Box.
	 *
	 * @return WC_Coupon|null
	 */
	function mvweb_core_box_coupon( $product ) {
		$id = absint( $product->get_meta( '_mvweb_box_coupon' ) );

		if ( 0 === $id || 'shop_coupon' !== get_post_type( $id ) ) {
			return null;
		}

		$coupon = new WC_Coupon( $id );

		return absint( $coupon->get_meta( '_mvweb_box' ) ) === $product->get_id() ? $coupon : null;
	}
}

if ( ! function_exists( 'mvweb_core_box_of_coupon' ) ) {
	/**
	 * The box a coupon belongs to.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Coupon $coupon Coupon.
	 *
	 * @return WC_Product|null
	 */
	function mvweb_core_box_of_coupon( $coupon ) {
		$id = absint( $coupon->get_meta( '_mvweb_box' ) );

		if ( 0 === $id ) {
			return null;
		}

		$product = wc_get_product( $id );

		return mvweb_core_is_box( $product ) ? $product : null;
	}
}

if ( ! function_exists( 'mvweb_core_box_items' ) ) {
	/**
	 * The products of a box that can be bought.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Box.
	 *
	 * @return WC_Product[]
	 */
	function mvweb_core_box_items( $product ) {
		$items = array();

		foreach ( $product->get_children() as $child ) {
			$item = wc_get_product( $child );

			if ( $item && $item->is_type( 'simple' ) && 'publish' === $item->get_status() ) {
				$items[] = $item;
			}
		}

		return $items;
	}
}

if ( ! function_exists( 'mvweb_core_box_sum' ) ) {
	/**
	 * What the products of a box cost one by one: at their regular prices, or at the prices they sell at now.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Box.
	 * @param bool       $now     Whether to take the price a product sells at now, a sale price included.
	 *
	 * @return float
	 */
	function mvweb_core_box_sum( $product, $now = false ) {
		$sum = 0.0;

		foreach ( mvweb_core_box_items( $product ) as $item ) {
			$price = $now || '' === (string) $item->get_regular_price() ? $item->get_price() : $item->get_regular_price();
			$sum  += (float) wc_get_price_to_display( $item, array( 'price' => $price ) );
		}

		return $sum;
	}
}

if ( ! function_exists( 'mvweb_core_box_discount' ) ) {
	/**
	 * The discount of a box in money: the sum as typed, or the share of the regular price of its products.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Box.
	 *
	 * @return float
	 */
	function mvweb_core_box_discount( $product ) {
		$amount = (float) mvweb_core_sanitize_amount( $product->get_meta( '_mvweb_box_amount' ) );

		if ( 'percent' === $product->get_meta( '_mvweb_box_type' ) ) {
			$amount = mvweb_core_box_sum( $product ) * min( 100, $amount ) / 100;
		}

		return round( max( 0, $amount ), wc_get_price_decimals() );
	}
}

if ( ! function_exists( 'mvweb_core_box_state' ) ) {
	/**
	 * What a box offers now.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product|int $product Box or its id.
	 *
	 * @return array{active:bool,reason:string,sum:float,discount:float,price:float,until:int,left:int|null,items:WC_Product[]}
	 */
	function mvweb_core_box_state( $product ) {
		$product = is_numeric( $product ) ? wc_get_product( (int) $product ) : $product;
		$state   = array(
			'active'   => false,
			'reason'   => 'off',
			'sum'      => 0.0,
			'discount' => 0.0,
			'price'    => 0.0,
			'until'    => 0,
			'left'     => null,
			'items'    => array(),
		);

		if ( ! mvweb_core_is_box( $product ) ) {
			return $state;
		}

		$state['items'] = mvweb_core_box_items( $product );
		$state['sum']   = mvweb_core_box_sum( $product );
		$state['price'] = $state['sum'];
		$coupon         = mvweb_core_box_coupon( $product );

		if ( ! $coupon || ! wc_coupons_enabled() || 'publish' !== get_post_status( $coupon->get_id() ) || 'publish' !== $product->get_status() ) {
			return $state;
		}

		$expires        = $coupon->get_date_expires();
		$state['until'] = $expires ? $expires->getTimestamp() : 0;

		if ( $coupon->get_usage_limit() > 0 ) {
			$state['left'] = max( 0, $coupon->get_usage_limit() - $coupon->get_usage_count() );
		}

		$state['reason'] = 'items';

		if ( count( $state['items'] ) < 2 || count( $state['items'] ) !== count( $product->get_children() ) ) {
			return $state;
		}

		foreach ( $state['items'] as $item ) {
			if ( mvweb_core_quantity_rules( $item->get_id() )['min'] > 1 ) {
				return $state;
			}
		}

		$state['reason'] = 'stock';

		foreach ( $state['items'] as $item ) {
			if ( ! $item->is_in_stock() || ! $item->is_purchasable() ) {
				return $state;
			}
		}

		$checks = array(
			'ended'     => $state['until'] && time() > $state['until'],
			'sold'      => 0 === $state['left'],
			'wholesale' => get_theme_mod( 'mvweb_wholesale', false ) && mvweb_core_is_wholesaler(),
		);

		foreach ( $checks as $reason => $failed ) {
			if ( $failed ) {
				$state['reason'] = $reason;

				return $state;
			}
		}

		$discount = mvweb_core_box_discount( $product );

		if ( $discount <= 0 || $discount >= $state['sum'] ) {
			$state['reason'] = 'price';

			return $state;
		}

		if ( mvweb_core_box_sum( $product, true ) <= $state['sum'] - $discount ) {
			$state['reason'] = 'sale';

			return $state;
		}

		$state['discount'] = $discount;
		$state['price']    = $state['sum'] - $discount;
		$state['active']   = true;
		$state['reason']   = '';

		return $state;
	}
}

if ( ! function_exists( 'mvweb_core_box_reason' ) ) {
	/**
	 * Why a box is not on sale, in words for the editor.
	 *
	 * @since 0.1.0
	 *
	 * @param string $reason Reason from mvweb_core_box_state().
	 *
	 * @return string
	 */
	function mvweb_core_box_reason( $reason ) {
		$texts = array(
			''          => __( 'On sale.', 'mvweb-core' ),
			'off'       => __( 'Not on sale: the box is not published, or coupons are off in WooCommerce.', 'mvweb-core' ),
			'items'     => __( 'Not on sale: a product of the box is gone, unpublished, not simple or sold from more than one piece.', 'mvweb-core' ),
			'stock'     => __( 'Not on sale: a product of the box is out of stock.', 'mvweb-core' ),
			'ended'     => __( 'Not on sale: the sale has ended.', 'mvweb-core' ),
			'sold'      => __( 'Not on sale: all the purchases are made.', 'mvweb-core' ),
			'price'     => __( 'Not on sale: the discount is zero, or not less than the price of the products.', 'mvweb-core' ),
			'sale'      => __( 'Not on sale: the products cost less on their own sale than in the box.', 'mvweb-core' ),
			'wholesale' => __( 'Not on sale for a wholesale customer.', 'mvweb-core' ),
		);

		return isset( $texts[ $reason ] ) ? $texts[ $reason ] : '';
	}
}

if ( ! function_exists( 'mvweb_core_boxes' ) ) {
	/**
	 * Boxes on sale now.
	 *
	 * @since 0.1.0
	 *
	 * @param int[] $ids   Boxes chosen by hand; empty for every box on sale.
	 * @param int   $limit How many at most.
	 *
	 * @return WC_Product[]
	 */
	function mvweb_core_boxes( array $ids = array(), $limit = 6 ) {
		$args = array(
			'type'       => 'grouped',
			'status'     => 'publish',
			'limit'      => empty( $ids ) ? 24 : count( $ids ),
			'meta_key'   => '_mvweb_box', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- A handful of grouped products.
			'meta_value' => 'yes', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- A handful of grouped products.
		);

		if ( ! empty( $ids ) ) {
			$args['include'] = array_map( 'absint', $ids );
			$args['orderby'] = 'post__in';
		}

		$boxes = array();

		foreach ( wc_get_products( $args ) as $product ) {
			if ( mvweb_core_box_state( $product )['active'] ) {
				$boxes[] = $product;
			}

			if ( count( $boxes ) >= $limit ) {
				break;
			}
		}

		return $boxes;
	}
}

if ( ! function_exists( 'mvweb_core_box_tab' ) ) {
	/**
	 * The Box tab in the product data, for grouped products.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<string,mixed>> $tabs Tabs.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_box_tab( $tabs ) {
		$tabs['mvweb_box'] = array(
			'label'    => _x( 'Box', 'set of products', 'mvweb-core' ),
			'target'   => 'mvweb_box_data',
			'class'    => array( 'show_if_grouped' ),
			'priority' => 25,
		);

		return $tabs;
	}
}

if ( ! function_exists( 'mvweb_core_box_panel' ) ) {
	/**
	 * The fields of the Box tab.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_box_panel() {
		global $product_object;

		$product = $product_object instanceof WC_Product ? $product_object : null;
		$coupon  = $product ? mvweb_core_box_coupon( $product ) : null;
		$until   = $coupon && $coupon->get_date_expires() ? $coupon->get_date_expires()->date_i18n( 'Y-m-d\TH:i' ) : '';
		?>
		<div id="mvweb_box_data" class="panel woocommerce_options_panel hidden">
			<div class="options_group">
				<?php
				woocommerce_wp_checkbox(
					array(
						'id'          => '_mvweb_box',
						'label'       => __( 'This is a box', 'mvweb-core' ),
						'description' => __( 'The products of Linked products, Grouped products are sold together with one button, with the discount below. Only simple products count.', 'mvweb-core' ),
					)
				);

				woocommerce_wp_select(
					array(
						'id'      => '_mvweb_box_type',
						'label'   => __( 'Discount in', 'mvweb-core' ),
						'options' => array(
							'sum'     => get_woocommerce_currency_symbol(),
							'percent' => '%',
						),
					)
				);

				woocommerce_wp_text_input(
					array(
						'id'          => '_mvweb_box_amount',
						'label'       => __( 'Discount on the box', 'mvweb-core' ),
						'data_type'   => 'price',
						'desc_tip'    => true,
						'description' => __( 'A sum off the whole box, or a share of the price of its products.', 'mvweb-core' ),
					)
				);
				?>
			</div>
			<div class="options_group">
				<?php
				woocommerce_wp_text_input(
					array(
						'id'          => '_mvweb_box_until',
						'label'       => __( 'Sale ends', 'mvweb-core' ),
						'type'        => 'datetime-local',
						'value'       => $until,
						'desc_tip'    => true,
						'description' => __( 'Date and time of the site. Empty: no end.', 'mvweb-core' ),
					)
				);

				woocommerce_wp_text_input(
					array(
						'id'                => '_mvweb_box_limit',
						'label'             => __( 'Purchases at most', 'mvweb-core' ),
						'type'              => 'number',
						'value'             => $coupon && $coupon->get_usage_limit() ? (string) $coupon->get_usage_limit() : '',
						'custom_attributes' => array(
							'min'  => '0',
							'step' => '1',
						),
						'desc_tip'          => true,
						'description'       => __( 'Orders with the box discount. A cancelled order gives its purchase back. Empty: no limit.', 'mvweb-core' ),
					)
				);

				if ( $coupon ) {
					printf(
						'<p class="form-field"><label>%1$s</label><span>%2$s</span></p>',
						esc_html__( 'Bought', 'mvweb-core' ),
						esc_html( (string) $coupon->get_usage_count() )
					);
				}

				if ( $product && mvweb_core_is_box( $product ) ) {
					printf(
						'<p class="form-field"><label>%1$s</label><span>%2$s</span></p>',
						esc_html__( 'Now', 'mvweb-core' ),
						esc_html( mvweb_core_box_reason( mvweb_core_box_state( $product )['reason'] ) )
					);
				}
				?>
			</div>
		</div>
		<?php
	}
}

if ( ! function_exists( 'mvweb_core_box_save' ) ) {
	/**
	 * Keep the fields of the Box tab.
	 *
	 * @since 0.1.0
	 *
	 * @param WC_Product $product Product being saved.
	 *
	 * @return void
	 */
	function mvweb_core_box_save( $product ) {
		if ( ! $product->is_type( 'grouped' ) ) {
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- WooCommerce checked the nonce of the product form.
		$box  = isset( $_POST['_mvweb_box'] );
		$type = isset( $_POST['_mvweb_box_type'] ) && 'percent' === $_POST['_mvweb_box_type'] ? 'percent' : 'sum';

		$product->update_meta_data( '_mvweb_box', $box ? 'yes' : 'no' );
		$product->update_meta_data( '_mvweb_box_type', $type );
		$product->update_meta_data( '_mvweb_box_amount', isset( $_POST['_mvweb_box_amount'] ) ? mvweb_core_sanitize_amount( wc_format_decimal( sanitize_text_field( wp_unslash( $_POST['_mvweb_box_amount'] ) ) ) ) : '' );
		$product->update_meta_data( '_mvweb_box_until', isset( $_POST['_mvweb_box_until'] ) ? sanitize_text_field( wp_unslash( $_POST['_mvweb_box_until'] ) ) : '' );
		$product->update_meta_data( '_mvweb_box_limit', isset( $_POST['_mvweb_box_limit'] ) ? absint( $_POST['_mvweb_box_limit'] ) : 0 );
		// phpcs:enable WordPress.Security.NonceVerification.Missing
	}
}

if ( ! function_exists( 'mvweb_core_box_sync' ) ) {
	/**
	 * Write the coupon of a box after the box is saved, and warn about products that cannot go in.
	 *
	 * @since 0.1.0
	 *
	 * @param int $post_id Product id.
	 *
	 * @return void
	 */
	function mvweb_core_box_sync( $post_id ) {
		$product = wc_get_product( $post_id );

		if ( ! $product ) {
			return;
		}

		$coupon = mvweb_core_box_coupon( $product );
		$box    = mvweb_core_is_box( $product );

		if ( ! $box ) {
			if ( $coupon && 'publish' === get_post_status( $coupon->get_id() ) ) {
				wp_update_post(
					array(
						'ID'          => $coupon->get_id(),
						'post_status' => 'draft',
					)
				);
			}

			return;
		}

		$items = mvweb_core_box_items( $product );

		foreach ( $product->get_children() as $child ) {
			$item = wc_get_product( $child );

			if ( ! $item || ! $item->is_type( 'simple' ) ) {
				/* translators: %s: product name. */
				WC_Admin_Meta_Boxes::add_error( sprintf( __( '%s is not a simple product and does not go into the box.', 'mvweb-core' ), $item ? $item->get_name() : '#' . $child ) );
			} elseif ( mvweb_core_quantity_rules( $child )['min'] > 1 ) {
				/* translators: %s: product name. */
				WC_Admin_Meta_Boxes::add_error( sprintf( __( '%s is sold from more than one piece: the box cannot add it.', 'mvweb-core' ), $item->get_name() ) );
			}
		}

		if ( count( $items ) < 2 ) {
			WC_Admin_Meta_Boxes::add_error( __( 'A box needs at least two simple products in Linked products, Grouped products.', 'mvweb-core' ) );
		} elseif ( mvweb_core_box_discount( $product ) >= mvweb_core_box_sum( $product ) ) {
			WC_Admin_Meta_Boxes::add_error( __( 'The discount is not less than the price of the products: the box is not on sale.', 'mvweb-core' ) );
		}

		$until   = (string) $product->get_meta( '_mvweb_box_until' );
		$expires = '' !== $until ? date_create_immutable( $until, wp_timezone() ) : false;

		if ( ! $coupon ) {
			$coupon = new WC_Coupon();
			$coupon->set_code( 'box-' . $product->get_id() );
		}

		$coupon->set_discount_type( 'fixed_cart' );
		$coupon->set_amount( 'percent' === $product->get_meta( '_mvweb_box_type' ) ? 0 : (float) $product->get_meta( '_mvweb_box_amount' ) );
		$coupon->set_product_ids(
			array_map(
				static function ( $item ) {
					return $item->get_id();
				},
				$items
			)
		);
		$coupon->set_individual_use( true );
		$coupon->set_usage_limit( absint( $product->get_meta( '_mvweb_box_limit' ) ) );
		$coupon->set_date_expires( $expires ? $expires->getTimestamp() : null );
		/* translators: %s: box name. */
		$coupon->set_description( sprintf( __( 'Discount of the box %s. Written by the box: change it there.', 'mvweb-core' ), $product->get_name() ) );
		$coupon->update_meta_data( '_mvweb_box', $product->get_id() );
		$coupon->save();

		if ( 'publish' !== get_post_status( $coupon->get_id() ) ) {
			wp_update_post(
				array(
					'ID'          => $coupon->get_id(),
					'post_status' => 'publish',
				)
			);
		}

		if ( absint( $product->get_meta( '_mvweb_box_coupon' ) ) !== $coupon->get_id() ) {
			update_post_meta( $product->get_id(), '_mvweb_box_coupon', $coupon->get_id() );
		}
	}
}

if ( ! function_exists( 'mvweb_core_box_coupon_amount' ) ) {
	/**
	 * The coupon of a box takes off what brings the products, at the prices they sell at now, down to the price of the box.
	 *
	 * @since 0.1.0
	 *
	 * @param float|string $amount Amount of the coupon.
	 * @param WC_Coupon    $coupon Coupon.
	 *
	 * @return float|string
	 */
	function mvweb_core_box_coupon_amount( $amount, $coupon ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return $amount;
		}

		$box = mvweb_core_box_of_coupon( $coupon );

		if ( ! $box ) {
			return $amount;
		}

		$discount = mvweb_core_box_discount( $box );

		if ( ! WC()->cart ) {
			return $discount;
		}

		return max( 0, round( mvweb_core_box_sum( $box, true ) - ( mvweb_core_box_sum( $box ) - $discount ), wc_get_price_decimals() ) );
	}
}

if ( ! function_exists( 'mvweb_core_box_coupon_valid' ) ) {
	/**
	 * The coupon of a box holds while the whole box is in the cart, for a retail customer at retail prices.
	 *
	 * @since 0.1.0
	 *
	 * @param bool         $valid     Valid so far.
	 * @param WC_Coupon    $coupon    Coupon.
	 * @param WC_Discounts $discounts Discounts of the cart.
	 *
	 * @throws Exception When the box discount does not hold; WooCommerce shows the message.
	 *
	 * @return bool
	 */
	function mvweb_core_box_coupon_valid( $valid, $coupon, $discounts ) {
		if ( ! $valid || ! $coupon->get_meta( '_mvweb_box' ) ) {
			return $valid;
		}

		$box = mvweb_core_box_of_coupon( $coupon );

		if ( ! $box ) {
			throw new Exception( esc_html__( 'The box is not on sale any more.', 'mvweb-core' ), 100 );
		}

		$object    = $discounts->get_object();
		$lines     = array();
		$wholesale = $object instanceof WC_Order ? (bool) get_user_meta( $object->get_customer_id(), 'mvweb_wholesale', true ) : mvweb_core_is_wholesaler();

		if ( get_theme_mod( 'mvweb_wholesale', false ) && $wholesale ) {
			throw new Exception( esc_html__( 'The box discount does not add to wholesale prices.', 'mvweb-core' ), 100 );
		}

		if ( $object instanceof WC_Cart ) {
			foreach ( $object->get_cart() as $line ) {
				$id           = absint( $line['product_id'] );
				$lines[ $id ] = ( isset( $lines[ $id ] ) ? $lines[ $id ] : 0 ) + (int) $line['quantity'];
			}
		} elseif ( $object instanceof WC_Order ) {
			foreach ( $object->get_items() as $line ) {
				$id           = absint( $line->get_product_id() );
				$lines[ $id ] = ( isset( $lines[ $id ] ) ? $lines[ $id ] : 0 ) + (int) $line->get_quantity();
			}
		}

		$state = mvweb_core_box_state( $box );

		if ( 'stock' === $state['reason'] ) {
			throw new Exception( esc_html__( 'A product of the box is out of stock: the box discount is off.', 'mvweb-core' ), 100 );
		}

		if ( ! $state['active'] ) {
			throw new Exception( esc_html__( 'The box is not on sale any more.', 'mvweb-core' ), 100 );
		}

		foreach ( $state['items'] as $item ) {
			if ( empty( $lines[ $item->get_id() ] ) ) {
				throw new Exception( esc_html__( 'The box discount holds while the whole box is in the cart.', 'mvweb-core' ), 100 );
			}

			if ( '' !== mvweb_core_tier_amount( $item->get_id(), $lines[ $item->get_id() ] ) ) {
				throw new Exception( esc_html__( 'The box discount does not add to the price for a quantity.', 'mvweb-core' ), 100 );
			}
		}

		return $valid;
	}
}

if ( ! function_exists( 'mvweb_core_box_coupon_items' ) ) {
	/**
	 * The discount of a box falls on the products of the box only.
	 *
	 * @since 0.1.0
	 *
	 * @param object[]  $items  Items the coupon applies to.
	 * @param WC_Coupon $coupon Coupon.
	 *
	 * @return object[]
	 */
	function mvweb_core_box_coupon_items( $items, $coupon ) {
		$box = mvweb_core_box_of_coupon( $coupon );

		if ( ! $box ) {
			return $items;
		}

		$ids = $box->get_children();

		return array_values(
			array_filter(
				$items,
				static function ( $item ) use ( $ids ) {
					return isset( $item->product ) && $item->product instanceof WC_Product && in_array( $item->product->get_id(), $ids, true );
				}
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_box_apply' ) ) {
	/**
	 * Apply the box discount once the last product of a box bought with its button is in the cart.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_box_apply() {
		static $tried = false;

		$box = isset( $_REQUEST['add-to-cart'] ) ? wc_get_product( absint( $_REQUEST['add-to-cart'] ) ) : null; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- The add to cart request of WooCommerce, which carries no nonce.

		if ( ! mvweb_core_is_box( $box ) || ! WC()->cart ) {
			return;
		}

		$coupon = mvweb_core_box_coupon( $box );

		if ( ! $coupon || WC()->cart->has_discount( $coupon->get_code() ) ) {
			return;
		}

		$in = array_map( 'absint', wp_list_pluck( WC()->cart->get_cart(), 'product_id' ) );

		foreach ( mvweb_core_box_items( $box ) as $item ) {
			if ( ! in_array( $item->get_id(), $in, true ) ) {
				return;
			}
		}

		if ( ! $tried && mvweb_core_box_state( $box )['active'] ) {
			$tried = true;
			WC()->cart->apply_coupon( $coupon->get_code() );
		}
	}
}

if ( ! function_exists( 'mvweb_core_box_coupon_label' ) ) {
	/**
	 * The name of the box instead of the code of its coupon.
	 *
	 * @since 0.1.0
	 *
	 * @param string    $label  Label.
	 * @param WC_Coupon $coupon Coupon.
	 *
	 * @return string
	 */
	function mvweb_core_box_coupon_label( $label, $coupon ) {
		$box = mvweb_core_box_of_coupon( $coupon );

		/* translators: %s: box name. */
		return $box ? sprintf( __( 'Box discount: %s', 'mvweb-core' ), $box->get_name() ) : $label;
	}
}

if ( ! function_exists( 'mvweb_core_box_coupon_message' ) ) {
	/**
	 * The notice when the box discount is applied.
	 *
	 * @since 0.1.0
	 *
	 * @param string    $message Message.
	 * @param int       $code    Message code.
	 * @param WC_Coupon $coupon  Coupon.
	 *
	 * @return string
	 */
	function mvweb_core_box_coupon_message( $message, $code, $coupon ) {
		$box = $coupon instanceof WC_Coupon ? mvweb_core_box_of_coupon( $coupon ) : null;

		if ( ! $box ) {
			return $message;
		}

		if ( WC_Coupon::WC_COUPON_SUCCESS === $code ) {
			/* translators: %s: box name. */
			return sprintf( __( 'The discount of the box %s is applied.', 'mvweb-core' ), $box->get_name() );
		}

		if ( WC_Coupon::WC_COUPON_REMOVED === $code ) {
			return __( 'The box discount is removed.', 'mvweb-core' );
		}

		return $message;
	}
}

if ( ! function_exists( 'mvweb_core_box_coupon_error' ) ) {
	/**
	 * The notice when the box discount falls off: without the code of the hidden coupon.
	 *
	 * @since 0.1.0
	 *
	 * @param string    $error  Message.
	 * @param int       $code   Error code.
	 * @param WC_Coupon $coupon Coupon.
	 *
	 * @return string
	 */
	function mvweb_core_box_coupon_error( $error, $code, $coupon ) {
		$box = $coupon instanceof WC_Coupon ? mvweb_core_box_of_coupon( $coupon ) : null;

		if ( ! $box || WC_Coupon::E_WC_COUPON_INVALID_REMOVED !== $code ) {
			return $error;
		}

		$reason = mvweb_core_box_state( $box )['reason'];

		if ( 'stock' === $reason ) {
			/* translators: %s: box name. */
			return sprintf( __( 'The discount of the box %s is removed: a product of the box is out of stock.', 'mvweb-core' ), $box->get_name() );
		}

		if ( in_array( $reason, array( 'ended', 'sold', 'off' ), true ) ) {
			/* translators: %s: box name. */
			return sprintf( __( 'The discount of the box %s is removed: the sale of the box is over.', 'mvweb-core' ), $box->get_name() );
		}

		/* translators: %s: box name. */
		return sprintf( __( 'The discount of the box %s is removed: the cart no longer holds the whole box.', 'mvweb-core' ), $box->get_name() );
	}
}

if ( ! function_exists( 'mvweb_core_box_keep_boxes' ) ) {
	/**
	 * Two boxes in one cart keep both discounts; a promo code still does not join them.
	 *
	 * @since 0.1.0
	 *
	 * @param string[]  $keep    Codes kept while an individual coupon is applied.
	 * @param WC_Coupon $coupon  Coupon being applied.
	 * @param string[]  $applied Codes applied before.
	 *
	 * @return string[]
	 */
	function mvweb_core_box_keep_boxes( $keep, $coupon, $applied ) {
		if ( ! mvweb_core_box_of_coupon( $coupon ) ) {
			return $keep;
		}

		foreach ( (array) $applied as $code ) {
			if ( mvweb_core_box_of_coupon( new WC_Coupon( $code ) ) ) {
				$keep[] = $code;
			}
		}

		return $keep;
	}
}

if ( ! function_exists( 'mvweb_core_box_join_box' ) ) {
	/**
	 * A box applied after another box joins it.
	 *
	 * @since 0.1.0
	 *
	 * @param bool      $join     Whether the coupon may join the individual one.
	 * @param WC_Coupon $coupon   Coupon being applied.
	 * @param WC_Coupon $applied  Individual coupon already applied.
	 *
	 * @return bool
	 */
	function mvweb_core_box_join_box( $join, $coupon, $applied ) {
		return $join || ( mvweb_core_box_of_coupon( $coupon ) && mvweb_core_box_of_coupon( $applied ) );
	}
}

if ( ! function_exists( 'mvweb_core_box_price_html' ) ) {
	/**
	 * The price of a box: what its products cost and, on sale, the price with the discount.
	 *
	 * @since 0.1.0
	 *
	 * @param string     $html    Price HTML.
	 * @param WC_Product $product Product.
	 *
	 * @return string
	 */
	function mvweb_core_box_price_html( $html, $product ) {
		if ( ! mvweb_core_is_box( $product ) ) {
			return $html;
		}

		$state = mvweb_core_box_state( $product );

		if ( $state['sum'] <= 0 ) {
			return $html;
		}

		return $state['active'] ? wc_format_sale_price( $state['sum'], $state['price'] ) : wc_price( $state['sum'] );
	}
}

if ( ! function_exists( 'mvweb_core_box_schema' ) ) {
	/**
	 * The offer of a box in the structured data of WooCommerce: one price, the one of the box.
	 *
	 * @since 0.1.0
	 *
	 * @param array      $markup  Product markup.
	 * @param WC_Product $product Product.
	 *
	 * @return array
	 */
	function mvweb_core_box_schema( $markup, $product ) {
		if ( ! mvweb_core_is_box( $product ) || empty( $markup['offers'][0] ) ) {
			return $markup;
		}

		$state = mvweb_core_box_state( $product );
		$offer = $markup['offers'][0];

		unset( $offer['lowPrice'], $offer['highPrice'], $offer['offerCount'], $offer['priceSpecification'] );

		$offer['@type'] = 'Offer';
		$offer['price'] = wc_format_decimal( $state['price'], wc_get_price_decimals() );

		if ( $state['active'] && $state['until'] ) {
			$offer['priceValidUntil'] = wp_date( 'Y-m-d', $state['until'] );
		}

		$markup['offers'] = array( $offer );

		return $markup;
	}
}

if ( ! function_exists( 'mvweb_core_box_template' ) ) {
	/**
	 * The form of a box: the template of the theme in place of the form of a grouped product, when the theme has one.
	 *
	 * @since 0.1.0
	 *
	 * @param string $template Template path.
	 * @param string $name     Template name.
	 *
	 * @return string
	 */
	function mvweb_core_box_template( $template, $name ) {
		if ( 'single-product/add-to-cart/grouped.php' !== $name || ! mvweb_core_is_box( isset( $GLOBALS['product'] ) ? $GLOBALS['product'] : null ) ) {
			return $template;
		}

		$own = locate_template( 'template-parts/box-buy.php' );

		return '' !== $own ? $own : $template;
	}
}

if ( mvweb_core_is_woocommerce() ) {
	add_filter( 'woocommerce_product_data_tabs', 'mvweb_core_box_tab' );
	add_action( 'woocommerce_product_data_panels', 'mvweb_core_box_panel' );
	add_action( 'woocommerce_admin_process_product_object', 'mvweb_core_box_save' );
	add_action( 'woocommerce_process_product_meta', 'mvweb_core_box_sync', 20 );
	add_filter( 'woocommerce_coupon_get_amount', 'mvweb_core_box_coupon_amount', 10, 2 );
	add_filter( 'woocommerce_coupon_is_valid', 'mvweb_core_box_coupon_valid', 10, 3 );
	add_filter( 'woocommerce_coupon_get_items_to_apply', 'mvweb_core_box_coupon_items', 10, 2 );
	add_action( 'woocommerce_add_to_cart', 'mvweb_core_box_apply', 20 );
	add_filter( 'woocommerce_cart_totals_coupon_label', 'mvweb_core_box_coupon_label', 10, 2 );
	add_filter( 'woocommerce_coupon_message', 'mvweb_core_box_coupon_message', 10, 3 );
	add_filter( 'woocommerce_coupon_error', 'mvweb_core_box_coupon_error', 10, 3 );
	add_filter( 'woocommerce_apply_individual_use_coupon', 'mvweb_core_box_keep_boxes', 10, 3 );
	add_filter( 'woocommerce_apply_with_individual_use_coupon', 'mvweb_core_box_join_box', 10, 3 );
	add_filter( 'woocommerce_get_price_html', 'mvweb_core_box_price_html', 20, 2 );
	add_filter( 'woocommerce_structured_data_product', 'mvweb_core_box_schema', 10, 2 );
	add_filter( 'wc_get_template', 'mvweb_core_box_template', 10, 2 );
}
