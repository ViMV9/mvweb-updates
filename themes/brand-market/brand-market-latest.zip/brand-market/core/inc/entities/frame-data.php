<?php
/**
 * Data of the frame of the site: the contacts and the addresses of the header, the announcement, the menu items, the catalogue tree, the zones, the prices of the purchase, the widget areas, the starter homepage.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_buy_data' ) ) {
	/**
	 * What the purchase block needs to count a total: the price, the price steps and the money format.
	 *
	 * @since 0.1.0
	 *
	 * @param int $id Item id.
	 *
	 * @return array<string,mixed> Empty outside the shop mode and for a product that cannot go to the cart as it is.
	 */
	function mvweb_core_buy_data( $id ) {
		$product = mvweb_core_shop_mode() ? mvweb_core_wc_item( $id ) : null;

		if ( ! $product || ! $product->is_type( 'simple' ) || ! $product->is_purchasable() || ! $product->is_in_stock() ) {
			return array();
		}

		$price = (float) wc_get_price_to_display( $product );

		if ( $price <= 0 ) {
			return array();
		}

		$tiers = array();

		foreach ( mvweb_core_tiers( $id ) as $from => $amount ) {
			if ( (float) $amount < $price ) {
				$tiers[ (int) $from ] = (float) $amount;
			}
		}

		return array(
			'price' => $price,
			'tiers' => $tiers,
			'min'   => max( 1, (int) $product->get_min_purchase_quantity(), mvweb_core_quantity_rules( $id )['min'] ),
			'money' => array(
				'decimals'  => wc_get_price_decimals(),
				'point'     => wc_get_price_decimal_separator(),
				'thousands' => wc_get_price_thousand_separator(),
				'format'    => html_entity_decode( sprintf( get_woocommerce_price_format(), get_woocommerce_currency_symbol(), '%s' ), ENT_QUOTES, 'UTF-8' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_buy_unit' ) ) {
	/**
	 * The price of one piece for a quantity.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $data     What mvweb_core_buy_data() returns.
	 * @param int                 $quantity Quantity.
	 *
	 * @return float
	 */
	function mvweb_core_buy_unit( array $data, $quantity ) {
		$unit = (float) $data['price'];

		foreach ( $data['tiers'] as $from => $amount ) {
			if ( $quantity >= $from ) {
				$unit = (float) $amount;
			}
		}

		return $unit;
	}
}

if ( ! function_exists( 'mvweb_core_back_url' ) ) {
	/**
	 * Where the back button of an item page leads without the browser history: the last link of the breadcrumbs.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty when the button is switched off.
	 */
	function mvweb_core_back_url() {
		if ( ! get_theme_mod( 'mvweb_product_back', true ) ) {
			return '';
		}

		$url = '';

		foreach ( mvweb_core_crumb_items() as $item ) {
			if ( ! empty( $item['url'] ) ) {
				$url = (string) $item['url'];
			}
		}

		return '' !== $url ? $url : home_url( '/' );
	}
}

if ( ! function_exists( 'mvweb_core_image_width' ) ) {
	/**
	 * Width of the original upload, so a small photo is not stretched past it.
	 *
	 * @since 1.0.1
	 *
	 * @param int $attachment_id Attachment ID.
	 *
	 * @return int Pixels, 0 when unknown.
	 */
	function mvweb_core_image_width( $attachment_id ) {
		$meta = wp_get_attachment_metadata( (int) $attachment_id );

		return is_array( $meta ) && ! empty( $meta['width'] ) ? (int) $meta['width'] : 0;
	}
}

if ( ! function_exists( 'mvweb_core_wc_archive' ) ) {
	/**
	 * Whether the listing is the shop or a product taxonomy of WooCommerce, where its hooks belong.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_wc_archive() {
		return function_exists( 'is_shop' ) && ( is_shop() || is_product_taxonomy() );
	}
}

if ( ! function_exists( 'mvweb_core_menu_current' ) ) {
	/**
	 * Whether a menu item leads to the page being shown.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $item Menu item.
	 *
	 * @return bool
	 */
	function mvweb_core_menu_current( $item ) {
		if ( 'post_type' === $item->type ) {
			return is_singular() && (int) get_queried_object_id() === (int) $item->object_id;
		}

		if ( 'taxonomy' === $item->type ) {
			return ( is_tax() || is_category() || is_tag() ) && (int) get_queried_object_id() === (int) $item->object_id;
		}

		if ( 'post_type_archive' === $item->type ) {
			return is_post_type_archive( $item->object );
		}

		if ( ! mvweb_core_menu_url_is_real( $item->url ) ) {
			return false;
		}

		$target = untrailingslashit( (string) strtok( $item->url, '?#' ) );
		$here   = untrailingslashit( home_url( (string) strtok( add_query_arg( array() ), '?' ) ) );

		return '' !== $target && $target === $here;
	}
}

if ( ! function_exists( 'mvweb_core_menu_classes' ) ) {
	/**
	 * The classes the owner typed into the "CSS classes" field of a menu item.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $item Menu item.
	 *
	 * @return string
	 */
	function mvweb_core_menu_classes( $item ) {
		$classes = implode( ' ', array_filter( array_map( 'sanitize_html_class', (array) $item->classes ) ) );

		return '' === $classes ? '' : ' ' . $classes;
	}
}

if ( ! function_exists( 'mvweb_core_catalog_tree' ) ) {
	/**
	 * The categories of the catalogue grouped by their parent.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,WP_Term[]> Terms with something in them, keyed by parent id, 0 for the top level.
	 */
	function mvweb_core_catalog_tree() {
		static $tree = null;

		if ( null !== $tree ) {
			return $tree;
		}

		$tree     = array();
		$taxonomy = mvweb_core_taxonomy();

		if ( ! taxonomy_exists( $taxonomy ) ) {
			return $tree;
		}

		$args = array(
			'taxonomy'   => $taxonomy,
			'hide_empty' => true,
		);

		if ( mvweb_core_is_woocommerce() ) {
			$args['exclude'] = array( absint( get_option( 'default_product_cat' ) ) );
		}

		$terms = get_terms( $args );

		if ( is_wp_error( $terms ) ) {
			return $tree;
		}

		foreach ( $terms as $term ) {
			$tree[ (int) $term->parent ][] = $term;
		}

		return $tree;
	}
}

if ( ! function_exists( 'mvweb_core_hours_line' ) ) {
	/**
	 * Opening hours as one line.
	 *
	 * @since 0.1.0
	 *
	 * @param array<int,array{days:string,time:string}> $hours Rows of the hours.
	 *
	 * @return string
	 */
	function mvweb_core_hours_line( array $hours ) {
		$parts = array();

		foreach ( $hours as $row ) {
			$parts[] = trim( $row['days'] . ' ' . $row['time'] );
		}

		return implode( ', ', array_filter( $parts ) );
	}
}

if ( ! function_exists( 'mvweb_core_address_text' ) ) {
	/**
	 * The city and the street of an address record.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $address Record of the contacts.
	 *
	 * @return string
	 */
	function mvweb_core_address_text( array $address ) {
		return implode( ', ', array_filter( array( trim( (string) $address['city'] ), trim( (string) $address['address'] ) ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_header_addresses' ) ) {
	/**
	 * The addresses of the chosen city that have something to print.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $contacts Contacts of the chosen city.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_header_addresses( array $contacts ) {
		return array_values(
			array_filter(
				$contacts['addresses'],
				static function ( $address ) {
					return '' !== mvweb_core_address_text( $address );
				}
			)
		);
	}
}

if ( ! function_exists( 'mvweb_core_topbar_has_others' ) ) {
	/**
	 * Whether the top bar carries anything besides the announcement.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_topbar_has_others() {
		foreach ( mvweb_core_zone_order( 'header-topbar' ) as $slug ) {
			if ( 'notice' === $slug ) {
				continue;
			}

			if ( 'city' === $slug && ! mvweb_core_has_city_choice() ) {
				continue;
			}

			if ( 'menu-top' === $slug && ! has_nav_menu( 'top' ) ) {
				continue;
			}

			return true;
		}

		return false;
	}
}

if ( ! function_exists( 'mvweb_core_notice' ) ) {
	/**
	 * The announcement of the top bar.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,mixed> Empty when there is nothing to announce or the bar does not carry it.
	 */
	function mvweb_core_notice() {
		$text = trim( (string) get_theme_mod( 'mvweb_notice_text', '' ) );

		if ( '' === $text || ! mvweb_core_zone_has( 'header-topbar', 'notice' ) ) {
			return array();
		}

		return array(
			'text'     => $text,
			'url'      => trim( (string) get_theme_mod( 'mvweb_notice_url', '' ) ),
			'link'     => trim( (string) get_theme_mod( 'mvweb_notice_link_text', '' ) ),
			'closable' => (bool) get_theme_mod( 'mvweb_notice_closable', true ),
			'key'      => 'mvweb-t-notice-' . substr( md5( $text ), 0, 8 ),
			'keep'     => mvweb_core_topbar_has_others(),
		);
	}
}

if ( ! function_exists( 'mvweb_core_element_html' ) ) {
	/**
	 * One element of a zone as a string, empty when it prints nothing.
	 *
	 * @since 0.1.0
	 *
	 * @param string $zone Zone slug.
	 * @param string $slug Element slug.
	 *
	 * @return string
	 */
	function mvweb_core_element_html( $zone, $slug ) {
		$safe = sanitize_key( $slug );
		$args = array(
			'zone'    => $zone,
			'context' => 'bar',
		);

		ob_start();

		if ( true !== apply_filters( 'mvweb_core_render_element', false, $zone, $slug, $args ) && 0 === validate_file( $safe ) ) {
			get_template_part( 'template-parts/elements/' . $safe, null, $args );
		}

		return trim( (string) ob_get_clean() );
	}
}

if ( ! function_exists( 'mvweb_core_zone_neighbour' ) ) {
	/**
	 * The element that stands next to another in a zone.
	 *
	 * @since 0.1.0
	 *
	 * @param string $zone   Zone slug.
	 * @param string $slug   Element slug.
	 * @param int    $offset 1 for the next one, -1 for the previous one.
	 *
	 * @return string Empty when there is none.
	 */
	function mvweb_core_zone_neighbour( $zone, $slug, $offset ) {
		$order = mvweb_core_zone_order( $zone );
		$at    = array_search( $slug, $order, true );

		if ( false === $at || ! isset( $order[ $at + $offset ] ) ) {
			return '';
		}

		return $order[ $at + $offset ];
	}
}

if ( ! function_exists( 'mvweb_core_phone_icon_field' ) ) {
	/**
	 * The colour field of the phone icon on the plate.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_phone_icon_field( $kit ) {
		$kit->add_fields(
			array(
				array(
					'type'        => 'color',
					'settings'    => 'mvweb_header_phone_icon_color',
					'section'     => 'mvweb_cz_header_blocks',
					'label'       => __( 'Colour of the phone icon', 'mvweb-core' ),
					'description' => __( 'Empty: the colour of the links. In the dark scheme the colour is lightened until it reads on the background.', 'mvweb-core' ),
					'default'     => '',
					'required'    => array(
						array(
							'setting'  => 'mvweb_header_phone_icon',
							'operator' => '==',
							'value'    => 'plate',
						),
					),
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_phone_icon_field' );

if ( ! function_exists( 'mvweb_core_seed_home' ) ) {
	/**
	 * Fill the homepage on first activation.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_seed_home() {
		$unset = '__mvweb_unset__';

		if ( get_theme_mod( 'mvweb_home_rows', $unset ) !== $unset ) {
			return;
		}

		$rows = array(
			array(
				'uid'   => wp_generate_uuid4(),
				'type'  => 'hero',
				'props' => array(
					'title'       => __( 'A heading that says what the company makes', 'mvweb-core' ),
					'button_text' => __( 'Request a quote', 'mvweb-core' ),
					'button_url'  => '#request',
					'features'    => array(
						array( 'text' => __( 'A promise the visitor cares about', 'mvweb-core' ) ),
						array( 'text' => __( 'A second promise', 'mvweb-core' ) ),
						array( 'text' => __( 'A third promise', 'mvweb-core' ) ),
					),
					'trust'       => array(
						array(
							'number' => '14',
							'text'   => __( 'years in the trade', 'mvweb-core' ),
						),
						array(
							'number' => '3000',
							'text'   => __( 'projects delivered', 'mvweb-core' ),
						),
					),
				),
			),
			array(
				'uid'   => wp_generate_uuid4(),
				'type'  => 'features',
				'props' => array(
					'title'  => __( 'What the company is good at', 'mvweb-core' ),
					'text'   => __( 'Two or three sentences about the approach.', 'mvweb-core' ),
					'blocks' => array(
						array(
							'icon'  => 'tools',
							'title' => __( 'The whole job, start to finish', 'mvweb-core' ),
							'text'  => __( "Design\nEngineering\nProduction\nInstallation", 'mvweb-core' ),
						),
						array(
							'icon'  => 'star',
							'title' => __( 'Quality', 'mvweb-core' ),
							'text'  => __( "What the materials are\nHow the work is checked", 'mvweb-core' ),
						),
						array(
							'icon'  => 'clock',
							'title' => __( 'Experience', 'mvweb-core' ),
							'text'  => __( "Since which year\nHow many people", 'mvweb-core' ),
						),
					),
				),
			),
			array(
				'uid'   => wp_generate_uuid4(),
				'type'  => 'banner',
				'props' => array(
					'title'       => __( 'A line that carries the offer', 'mvweb-core' ),
					'text'        => __( 'A short sentence under it.', 'mvweb-core' ),
					'button_text' => __( 'See the work', 'mvweb-core' ),
					'button_url'  => '#request',
				),
			),
		);

		set_theme_mod( 'mvweb_home_rows', wp_json_encode( $rows ) );
	}
}
add_action( 'after_switch_theme', 'mvweb_core_seed_home' );

if ( ! function_exists( 'mvweb_core_inherit_mods' ) ) {
	/**
	 * Hand the settings of the parent theme to a child theme activated for the first time.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_inherit_mods() {
		$child = 'theme_mods_' . get_stylesheet();

		if ( get_template() === get_stylesheet() || get_option( $child ) ) {
			return;
		}

		update_option( $child, get_option( 'theme_mods_' . get_template() ) );
	}
}
add_action( 'after_switch_theme', 'mvweb_core_inherit_mods', 5 );

if ( ! function_exists( 'mvweb_core_sidebar_html' ) ) {
	/**
	 * Markup of the widgets of an area, printed once per request.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area key.
	 *
	 * @return string Empty when the area has no widget or none of them prints anything.
	 */
	function mvweb_core_sidebar_html( $area ) {
		static $html = array();

		if ( isset( $html[ $area ] ) ) {
			return $html[ $area ];
		}

		$html[ $area ] = '';

		if ( 'none' !== mvweb_core_sidebar_side( $area ) && is_active_sidebar( mvweb_core_sidebar_id( $area ) ) ) {
			ob_start();
			dynamic_sidebar( mvweb_core_sidebar_id( $area ) );
			$html[ $area ] = trim( (string) ob_get_clean() );
		}

		return $html[ $area ];
	}
}

if ( ! function_exists( 'mvweb_core_sidebar_on' ) ) {
	/**
	 * Whether the column of an area has something to print and the request belongs to the area.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area key.
	 *
	 * @return bool
	 */
	function mvweb_core_sidebar_on( $area ) {
		return mvweb_core_sidebar_area() === $area && '' !== mvweb_core_sidebar_html( $area );
	}
}

if ( ! function_exists( 'mvweb_core_mega_models' ) ) {
	/**
	 * Where the mega menu takes its content: items — the fields «Mega menu» and «Picture» of a menu item; catalog — the panel of the catalogue sections under the catalogue button.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_mega_models() {
		$support = get_theme_support( 'mvweb-mega-menu' );

		if ( ! is_array( $support ) || ! isset( $support[0] ) || ! is_array( $support[0] ) ) {
			return array( 'items' );
		}

		return array_values( array_intersect( array( 'items', 'catalog' ), array_map( 'strval', $support[0] ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_menu_item_fields' ) ) {
	/**
	 * Keep the fields of a menu item only for a theme that draws the mega menu from the menu items.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_menu_item_fields() {
		if ( in_array( 'items', mvweb_core_mega_models(), true ) ) {
			return;
		}

		remove_action( 'wp_nav_menu_item_custom_fields', 'mvweb_core_menu_mega_field', 5 );
		remove_action( 'wp_nav_menu_item_custom_fields', 'mvweb_core_menu_image_field' );
		remove_action( 'wp_update_nav_menu_item', 'mvweb_core_menu_mega_save', 10 );
		remove_action( 'wp_update_nav_menu_item', 'mvweb_core_menu_image_save', 10 );
		remove_action( 'admin_enqueue_scripts', 'mvweb_core_menu_admin_assets' );
	}
}
add_action( 'after_setup_theme', 'mvweb_core_menu_item_fields', 20 );

if ( ! function_exists( 'mvweb_core_topics_menu' ) ) {
	/**
	 * Register the place of the menu «Topics of the day»: the theme shows it as a row of chips under the header.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_topics_menu() {
		register_nav_menus( array( 'topics' => __( 'Topics of the day, under the header', 'mvweb-core' ) ) );
	}
}
add_action( 'after_setup_theme', 'mvweb_core_topics_menu', 20 );

if ( ! function_exists( 'mvweb_core_account_link' ) ) {
	/**
	 * Where the element «Account» leads: the account of WooCommerce, or the profile and the login of WordPress without the shop.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Url and label; empty when there is nowhere to go.
	 */
	function mvweb_core_account_link() {
		if ( function_exists( 'wc_get_page_permalink' ) ) {
			$url = (string) wc_get_page_permalink( 'myaccount' );

			return '' === $url ? array() : array(
				'url'   => $url,
				'label' => __( 'Account', 'mvweb-core' ),
			);
		}

		if ( is_user_logged_in() ) {
			return array(
				'url'   => get_edit_profile_url(),
				'label' => __( 'Profile', 'mvweb-core' ),
			);
		}

		return array(
			'url'   => wp_login_url( add_query_arg( array() ) ),
			'label' => __( 'Log in', 'mvweb-core' ),
		);
	}
}

if ( ! function_exists( 'mvweb_core_map_image_control' ) ) {
	/**
	 * The picture of the map is chosen in the media library and kept as its id; the field of the Kit keeps its place, label and condition.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Customize_Manager $wp_customize Customizer.
	 *
	 * @return void
	 */
	function mvweb_core_map_image_control( $wp_customize ) {
		$control = $wp_customize->get_control( 'mvweb_cz_map_image' );
		$setting = $wp_customize->get_setting( 'mvweb_cz_map_image' );

		if ( ! $control || ! $setting || 'media' === $control->type ) {
			return;
		}

		$setting->sanitize_callback = 'absint';
		$wp_customize->remove_control( 'mvweb_cz_map_image' );
		$wp_customize->add_control(
			new WP_Customize_Media_Control(
				$wp_customize,
				'mvweb_cz_map_image',
				array(
					'section'         => $control->section,
					'label'           => $control->label,
					'description'     => $control->description,
					'priority'        => $control->priority,
					'active_callback' => $control->active_callback,
					'mime_type'       => 'image',
				)
			)
		);
	}
}
add_action( 'customize_register', 'mvweb_core_map_image_control', 100 );

if ( ! function_exists( 'mvweb_core_map_image_value' ) ) {
	/**
	 * A picture of the map saved as an address before it was kept as an id reads as its id; an address outside the media library stays as it is.
	 *
	 * @since 0.1.0
	 *
	 * @param mixed $value Stored value.
	 *
	 * @return mixed
	 */
	function mvweb_core_map_image_value( $value ) {
		static $ids = array();

		if ( ! is_string( $value ) || '' === $value || is_numeric( $value ) ) {
			return $value;
		}

		if ( ! isset( $ids[ $value ] ) ) {
			$ids[ $value ] = (int) attachment_url_to_postid( $value );
		}

		return $ids[ $value ] ? $ids[ $value ] : $value;
	}
}
add_filter( 'theme_mod_mvweb_cz_map_image', 'mvweb_core_map_image_value' );

if ( ! function_exists( 'mvweb_core_map_picture' ) ) {
	/**
	 * The picture of the map of the profile: the attachment and its address.
	 *
	 * @since 0.1.0
	 *
	 * @return array{id:int,url:string} Id 0 for an address outside the media library.
	 */
	function mvweb_core_map_picture() {
		$value = mvweb_cz_profile( 'map_image' );

		if ( is_numeric( $value ) && wp_attachment_is_image( (int) $value ) ) {
			return array(
				'id'  => (int) $value,
				'url' => (string) wp_get_attachment_url( (int) $value ),
			);
		}

		return array(
			'id'  => 0,
			'url' => is_numeric( $value ) ? '' : (string) $value,
		);
	}
}
