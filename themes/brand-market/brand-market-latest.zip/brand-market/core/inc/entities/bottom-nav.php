<?php
/**
 * The bottom menu of the phone: a place for the menu, the items for the template of the theme, the height for the page.
 *
 * It comes with add_theme_support( 'mvweb-bottom-nav' ). The items are a menu
 * the owner builds in Appearance → Menus, up to five of them; an item that
 * leads to #request opens the request window and is the main one. The bar
 * itself, its look and when it shows are the theme's: it draws
 * template-parts/bottom-nav.php, which the core calls at the end of the page.
 * A script writes the real height of the bar into --mvweb-t-bottom-nav-h
 * (0px while the bar is hidden), for the theme to keep the notice about
 * cookies and the button "up" above it and the end of the page clear of it.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_bottom_nav_supported' ) ) {
	/**
	 * Whether the theme draws the bottom menu.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_bottom_nav_supported() {
		return current_theme_supports( 'mvweb-bottom-nav' );
	}
}

if ( ! function_exists( 'mvweb_core_bottom_nav_menu' ) ) {
	/**
	 * Register the place of the bottom menu.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_bottom_nav_menu() {
		if ( mvweb_core_bottom_nav_supported() ) {
			register_nav_menus( array( 'bottom-nav' => __( 'Bottom bar on the phone, up to five items', 'mvweb-core' ) ) );
		}
	}
}
add_action( 'after_setup_theme', 'mvweb_core_bottom_nav_menu', 20 );

if ( ! function_exists( 'mvweb_core_bottom_nav' ) ) {
	/**
	 * The items of the bottom menu.
	 *
	 * @since 0.1.0
	 *
	 * @return array<int,array{title:string,url:string,icon:string,current:bool,main:bool,classes:string}> Empty when the theme has no bottom menu or the menu is empty.
	 */
	function mvweb_core_bottom_nav() {
		static $items = null;

		if ( null !== $items ) {
			return $items;
		}

		$items = array();

		if ( ! mvweb_core_bottom_nav_supported() || is_admin() ) {
			return $items;
		}

		$tree = mvweb_core_menu_tree( 'bottom-nav' );
		$main = false;

		foreach ( isset( $tree[0] ) ? array_slice( $tree[0], 0, 5 ) : array() as $item ) {
			$url = trim( (string) $item->url );

			if ( ! mvweb_core_menu_url_is_real( $url ) ) {
				continue;
			}

			$request = str_ends_with( $url, '#request' );
			$is_main = $request && ! $main;
			$main    = $main || $is_main;
			$items[] = array(
				'title'   => (string) $item->title,
				'url'     => $url,
				'icon'    => mvweb_core_menu_item_icon( $item->ID ),
				'current' => ! $request && mvweb_core_menu_current( $item ),
				'main'    => $is_main,
				'classes' => trim( mvweb_core_menu_classes( $item ) ),
			);
		}

		return $items;
	}
}

if ( ! function_exists( 'mvweb_core_bottom_nav_print' ) ) {
	/**
	 * Call the template of the theme with the items, at the end of the page.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_bottom_nav_print() {
		$items = mvweb_core_bottom_nav();

		if ( ! empty( $items ) ) {
			get_template_part( 'template-parts/bottom-nav', null, array( 'items' => $items ) );
		}
	}
}
add_action( 'wp_footer', 'mvweb_core_bottom_nav_print', 20 );

if ( ! function_exists( 'mvweb_core_bottom_nav_styles' ) ) {
	/**
	 * Add the stylesheet of the bar to the pages that carry it.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $styles Handles without the theme prefix.
	 *
	 * @return string[]
	 */
	function mvweb_core_bottom_nav_styles( $styles ) {
		if ( ! empty( mvweb_core_bottom_nav() ) ) {
			$styles[] = 'bottom-nav';
		}

		return $styles;
	}
}
add_filter( 'mvweb_core_style_map', 'mvweb_core_bottom_nav_styles' );

if ( ! function_exists( 'mvweb_core_bottom_nav_modules' ) ) {
	/**
	 * Add the script that measures the bar to the pages that carry it.
	 *
	 * @since 0.1.0
	 *
	 * @param string[] $modules File names without extension, from assets/js/.
	 *
	 * @return string[]
	 */
	function mvweb_core_bottom_nav_modules( $modules ) {
		if ( ! empty( mvweb_core_bottom_nav() ) ) {
			$modules[] = 'bottom-nav';
		}

		return $modules;
	}
}
add_filter( 'mvweb_core_module_map', 'mvweb_core_bottom_nav_modules' );
