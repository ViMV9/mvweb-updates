<?php
/**
 * The order of the sections of the catalogue, of the services and of the kinds of works: dragged in their list in the admin, kept in the term meta and followed wherever the core lists them by name.
 *
 * @package MVweb_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_term_order_taxonomies' ) ) {
	/**
	 * The taxonomies the owner orders by hand.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_term_order_taxonomies() {
		/**
		 * Filters the taxonomies whose terms are ordered by dragging.
		 *
		 * @since 0.1.0
		 *
		 * @param string[] $taxonomies Taxonomy names.
		 */
		return (array) apply_filters( 'mvweb_core_term_order_taxonomies', array( 'mv_item_cat', 'mv_service_cat', 'mv_work_type' ) );
	}
}

if ( ! function_exists( 'mvweb_core_term_order_clauses' ) ) {
	/**
	 * A list of an ordered taxonomy by name or by the order of making goes by the stored order first; terms never moved follow as before.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $clauses    Query clauses.
	 * @param string[]             $taxonomies Taxonomies of the query.
	 * @param array<string,mixed>  $args       Query arguments.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_term_order_clauses( $clauses, $taxonomies, $args ) {
		global $wpdb;

		if ( empty( $taxonomies ) || array_diff( (array) $taxonomies, mvweb_core_term_order_taxonomies() ) || ! in_array( $args['orderby'] ?? '', array( 'name', 'term_id' ), true ) || 0 !== strpos( (string) $clauses['orderby'], 'ORDER BY ' ) ) {
			return $clauses;
		}

		$clauses['join']   .= $wpdb->prepare( " LEFT JOIN {$wpdb->termmeta} AS mvweb_to ON ( t.term_id = mvweb_to.term_id AND mvweb_to.meta_key = %s )", 'mvweb_term_order' );
		$clauses['orderby'] = 'ORDER BY mvweb_to.meta_value IS NULL ASC, CAST( mvweb_to.meta_value AS SIGNED ) ASC, ' . substr( $clauses['orderby'], 9 );

		return $clauses;
	}
}
add_filter( 'terms_clauses', 'mvweb_core_term_order_clauses', 10, 3 );

if ( ! function_exists( 'mvweb_core_term_order_assets' ) ) {
	/**
	 * The dragging of the rows in the list of an ordered taxonomy.
	 *
	 * @since 0.1.0
	 *
	 * @param string $hook Current admin screen.
	 *
	 * @return void
	 */
	function mvweb_core_term_order_assets( $hook ) {
		$screen = get_current_screen();

		if ( 'edit-tags.php' !== $hook || ! $screen || ! in_array( $screen->taxonomy, mvweb_core_term_order_taxonomies(), true ) ) {
			return;
		}

		$relative = mvweb_core_asset_path( '/admin/js/term-order.js' );

		wp_enqueue_script( 'mvweb-core-term-order', MVWEB_CORE_URI . $relative, array( 'jquery-ui-sortable' ), mvweb_core_asset_version( $relative ), true );
		wp_localize_script(
			'mvweb-core-term-order',
			'mvwebCoreTermOrder',
			array(
				'taxonomy' => $screen->taxonomy,
				'nonce'    => wp_create_nonce( 'mvweb_term_order' ),
				'hint'     => __( 'Drag the rows to change the order on the site. A row moves among the sections of the same parent.', 'mvweb-core' ),
				'failed'   => __( 'The order was not saved. Reload the page and try again.', 'mvweb-core' ),
			)
		);
	}
}
add_action( 'admin_enqueue_scripts', 'mvweb_core_term_order_assets' );

if ( ! function_exists( 'mvweb_core_term_order_save' ) ) {
	/**
	 * Store the new order of the sections of one parent: the dragged rows take the places they held among all their siblings, so a list split into pages keeps the rest.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_term_order_save() {
		check_ajax_referer( 'mvweb_term_order' );

		$taxonomy = isset( $_POST['taxonomy'] ) ? sanitize_key( wp_unslash( $_POST['taxonomy'] ) ) : '';
		$object   = get_taxonomy( $taxonomy );
		$moved    = isset( $_POST['ids'] ) ? wp_parse_id_list( wp_unslash( $_POST['ids'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- wp_parse_id_list() keeps positive integers only.

		if ( ! $object || ! in_array( $taxonomy, mvweb_core_term_order_taxonomies(), true ) || ! current_user_can( $object->cap->edit_terms ) || empty( $moved ) ) {
			wp_send_json_error( null, 403 );
		}

		$first = get_term( $moved[0], $taxonomy );

		if ( ! $first instanceof WP_Term ) {
			wp_send_json_error( null, 400 );
		}

		$siblings = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'parent'     => (int) $first->parent,
				'hide_empty' => false,
				'fields'     => 'ids',
				'orderby'    => 'name',
			)
		);
		$siblings = is_array( $siblings ) ? array_map( 'intval', $siblings ) : array();
		$moved    = array_values( array_intersect( $moved, $siblings ) );
		$queue    = $moved;

		foreach ( $siblings as $index => $id ) {
			if ( in_array( $id, $moved, true ) ) {
				$siblings[ $index ] = array_shift( $queue );
			}
		}

		foreach ( $siblings as $index => $id ) {
			update_term_meta( $id, 'mvweb_term_order', $index + 1 );
		}

		wp_send_json_success();
	}
}
add_action( 'wp_ajax_mvweb_term_order', 'mvweb_core_term_order_save' );
