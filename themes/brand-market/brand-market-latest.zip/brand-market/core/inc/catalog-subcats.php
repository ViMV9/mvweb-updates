<?php
/**
 * The look of the subcategories above a catalogue listing and how many of them show at once.
 *
 * The names of the looks come from the theme through mvweb_core_subcats_views;
 * a theme that has none gets no choice and prints its one look.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_subcats_views' ) ) {
	/**
	 * The looks of the subcategories the theme draws.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Slug => name, the first is the default.
	 */
	function mvweb_core_subcats_views() {
		/**
		 * Filter the looks of the subcategories above a listing.
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,string> $views Slug => name.
		 */
		return (array) apply_filters( 'mvweb_core_subcats_views', array() );
	}
}

if ( ! function_exists( 'mvweb_core_subcats_view' ) ) {
	/**
	 * The look of the subcategories chosen in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty when the theme has no looks.
	 */
	function mvweb_core_subcats_view() {
		$views = mvweb_core_subcats_views();

		if ( empty( $views ) ) {
			return '';
		}

		$view = (string) get_theme_mod( 'mvweb_catalog_subcats_view', '' );

		return isset( $views[ $view ] ) ? $view : (string) array_key_first( $views );
	}
}

if ( ! function_exists( 'mvweb_core_subcats_limit' ) ) {
	/**
	 * How many subcategories show before the button that opens the rest.
	 *
	 * @since 0.1.0
	 *
	 * @return int From 1 to 48.
	 */
	function mvweb_core_subcats_limit() {
		return min( 48, max( 1, absint( get_theme_mod( 'mvweb_catalog_subcats_limit', 8 ) ) ) );
	}
}

if ( ! function_exists( 'mvweb_core_subcats_fields' ) ) {
	/**
	 * The look of the subcategories and the number shown at once, beside the switch of the tiles.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Customizer Kit.
	 *
	 * @return void
	 */
	function mvweb_core_subcats_fields( $kit ) {
		$views = mvweb_core_subcats_views();

		if ( empty( $views ) ) {
			return;
		}

		$on = array(
			array(
				'setting'  => 'mvweb_catalog_subcats',
				'operator' => '==',
				'value'    => true,
			),
		);

		$kit->add_fields(
			array(
				array(
					'type'        => 'radio',
					'settings'    => 'mvweb_catalog_subcats_view',
					'section'     => 'mvweb_cz_catalog_archive',
					'label'       => __( 'Look of the subcategories', 'mvweb-core' ),
					'description' => __( 'How the sections inside a category stand above its products on a computer. On a phone they are a list in the bar above the products.', 'mvweb-core' ),
					'default'     => (string) array_key_first( $views ),
					'choices'     => $views,
					'required'    => $on,
				),
				array(
					'type'        => 'number',
					'settings'    => 'mvweb_catalog_subcats_limit',
					'section'     => 'mvweb_cz_catalog_archive',
					'label'       => __( 'Subcategories shown at once', 'mvweb-core' ),
					'description' => __( 'The rest open with a button. Works in the looks with such a button.', 'mvweb-core' ),
					'default'     => 8,
					'input_attrs' => array(
						'min'  => 1,
						'max'  => 48,
						'step' => 1,
					),
					'required'    => $on,
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_subcats_fields' );
