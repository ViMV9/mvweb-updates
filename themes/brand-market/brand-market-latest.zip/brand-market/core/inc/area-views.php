<?php
/**
 * Looks of the areas of a page: the article, the category, the author, the page, the contacts, the search, the 404, the announcement, the topics of the day, the mega menu, the widget column, the services, the portfolio, the doctors, the comparison, the favourites and the catalogue listing.
 *
 * The theme names its looks through mvweb_core_area_views; an area without
 * looks gets no field and no attribute on the root element.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_area_views' ) ) {
	/**
	 * The areas with their Customizer section, label and the looks the theme draws.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array{section:string,label:string,description:string,views:array<string,string>,off:string,only:array<string,string[]>}> Area => definition.
	 */
	function mvweb_core_area_views() {
		$areas = array(
			'single'    => array(
				'section' => 'mvweb_cz_inner_single',
				'label'   => __( 'Look of the article', 'mvweb-core' ),
			),
			'category'  => array(
				'section' => 'mvweb_cz_inner_category',
				'label'   => __( 'Look of the category page', 'mvweb-core' ),
			),
			'author'    => array(
				'section' => 'mvweb_cz_inner_author',
				'label'   => __( 'Look of the author page', 'mvweb-core' ),
			),
			'page'      => array(
				'section' => 'mvweb_cz_inner_page',
				'label'   => __( 'Look of the page', 'mvweb-core' ),
			),
			'contacts'  => array(
				'section' => 'mvweb_cz_inner_contacts',
				'label'   => __( 'Look of the contacts page', 'mvweb-core' ),
			),
			'search'    => array(
				'section' => 'mvweb_cz_inner_search',
				'label'   => __( 'Look of the search results', 'mvweb-core' ),
			),
			'notfound'  => array(
				'section' => 'mvweb_cz_inner_404',
				'label'   => __( 'Look of the 404 page', 'mvweb-core' ),
			),
			'notice'    => array(
				'section' => 'mvweb_cz_header_notice',
				'label'   => __( 'Look of the announcement', 'mvweb-core' ),
			),
			'topics'    => array(
				'section' => 'mvweb_cz_header_topics',
				'label'   => __( 'Look of the topics of the day', 'mvweb-core' ),
				'off'     => __( 'Do not show', 'mvweb-core' ),
			),
			'mega'      => array(
				'section' => 'mvweb_cz_header_mega',
				'label'   => __( 'Look of the mega menu', 'mvweb-core' ),
			),
			'sidebar'   => array(
				'section' => 'mvweb_cz_inner_sidebar',
				'label'   => __( 'Look of the widget column', 'mvweb-core' ),
			),
			'service'   => array(
				'section' => 'mvweb_cz_services_page',
				'label'   => __( 'Look of the service page', 'mvweb-core' ),
			),
			'services'  => array(
				'section' => 'mvweb_cz_services_list',
				'label'   => __( 'Look of the services listing', 'mvweb-core' ),
			),
			'portfolio' => array(
				'section' => 'mvweb_cz_services_works',
				'label'   => __( 'Look of the portfolio', 'mvweb-core' ),
			),
			'work'      => array(
				'section' => 'mvweb_cz_services_work',
				'label'   => __( 'Look of the work page', 'mvweb-core' ),
			),
			'doctors'   => array(
				'section' => 'mvweb_cz_team_list',
				'label'   => __( 'Look of the doctors page', 'mvweb-core' ),
			),
			'doctor'    => array(
				'section' => 'mvweb_cz_team_page',
				'label'   => __( 'Look of the doctor page', 'mvweb-core' ),
			),
			'compare'   => array(
				'section' => 'mvweb_cz_catalog_lists',
				'label'   => __( 'Look of the comparison page', 'mvweb-core' ),
			),
			'favorites' => array(
				'section' => 'mvweb_cz_catalog_lists',
				'label'   => __( 'Look of the favourites page', 'mvweb-core' ),
			),
			'catalog'   => array(
				'section' => 'mvweb_cz_catalog_archive',
				'label'   => __( 'Look of the catalogue listing', 'mvweb-core' ),
			),
		);

		/**
		 * Filter the looks of the areas: the theme fills views (slug => name, the first is the default) and may add a description and only (setting => looks that show it).
		 *
		 * @since 0.1.0
		 *
		 * @param array<string,array<string,mixed>> $areas Area => section, label, views, description, only.
		 */
		$raw = (array) apply_filters( 'mvweb_core_area_views', $areas );
		$out = array();

		foreach ( $areas as $area => $base ) {
			$data  = isset( $raw[ $area ] ) && is_array( $raw[ $area ] ) ? $raw[ $area ] : array();
			$views = array();

			foreach ( (array) ( $data['views'] ?? array() ) as $slug => $name ) {
				$slug = sanitize_key( (string) $slug );

				if ( '' !== $slug && 'off' !== $slug && '' !== trim( (string) $name ) ) {
					$views[ $slug ] = (string) $name;
				}
			}

			$only = array();

			foreach ( (array) ( $data['only'] ?? array() ) as $setting => $slugs ) {
				$only[ sanitize_key( (string) $setting ) ] = array_values( array_intersect( array_map( 'strval', (array) $slugs ), array_keys( $views ) ) );
			}

			$out[ $area ] = array(
				'section'     => isset( $data['section'] ) ? sanitize_key( (string) $data['section'] ) : $base['section'],
				'label'       => isset( $data['label'] ) ? (string) $data['label'] : $base['label'],
				'description' => isset( $data['description'] ) ? (string) $data['description'] : '',
				'views'       => $views,
				'off'         => isset( $base['off'] ) ? $base['off'] : '',
				'only'        => $only,
			);
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_core_area_choices' ) ) {
	/**
	 * The values the look field of an area offers: the looks of the theme, and «Do not show» where the area can be off.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area key.
	 *
	 * @return array<string,string> Empty when the theme has no looks for the area.
	 */
	function mvweb_core_area_choices( $area ) {
		$areas = mvweb_core_area_views();

		if ( empty( $areas[ $area ]['views'] ) ) {
			return array();
		}

		$choices = $areas[ $area ]['views'];

		if ( '' !== $areas[ $area ]['off'] ) {
			$choices['off'] = $areas[ $area ]['off'];
		}

		return $choices;
	}
}

if ( ! function_exists( 'mvweb_core_area_view' ) ) {
	/**
	 * The look of an area chosen in the Customizer.
	 *
	 * @since 0.1.0
	 *
	 * @param string $area Area key.
	 *
	 * @return string Empty when the theme has no looks for the area; off when the owner switched the area off.
	 */
	function mvweb_core_area_view( $area ) {
		$choices = mvweb_core_area_choices( (string) $area );

		if ( empty( $choices ) ) {
			return '';
		}

		$view = (string) get_theme_mod( 'mvweb_view_' . $area, '' );

		return isset( $choices[ $view ] ) ? $view : (string) array_key_first( $choices );
	}
}

if ( ! function_exists( 'mvweb_core_area_html_settings' ) ) {
	/**
	 * The looks of the areas for the root element.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Attribute name => look.
	 */
	function mvweb_core_area_html_settings() {
		$out = array();

		foreach ( array_keys( mvweb_core_area_views() ) as $area ) {
			$view = mvweb_core_area_view( $area );

			if ( '' !== $view ) {
				$out[ 'data-view-' . $area ] = $view;
			}
		}

		return $out;
	}
}

if ( ! function_exists( 'mvweb_core_area_has_views' ) ) {
	/**
	 * Whether the theme draws looks for any area.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_area_has_views() {
		foreach ( mvweb_core_area_views() as $data ) {
			if ( ! empty( $data['views'] ) ) {
				return true;
			}
		}

		return false;
	}
}

if ( ! function_exists( 'mvweb_core_area_view_fields' ) ) {
	/**
	 * The look field of every area the theme draws, first in the section of the area.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_area_view_fields( $kit ) {
		$fields = array();

		foreach ( mvweb_core_area_views() as $area => $data ) {
			$choices = mvweb_core_area_choices( $area );

			if ( empty( $choices ) ) {
				continue;
			}

			$description = $data['description'];

			if ( '' === $description ) {
				/* translators: %s: name of the default look. */
				$description = sprintf( __( 'Default: %s. The fields below change with the look.', 'mvweb-core' ), reset( $choices ) );
			}

			$fields[] = array(
				'type'        => 'select',
				'settings'    => 'mvweb_view_' . $area,
				'section'     => $data['section'],
				'label'       => $data['label'],
				'description' => $description,
				'default'     => (string) array_key_first( $choices ),
				'choices'     => $choices,
				'priority'    => 0,
			);
		}

		if ( ! empty( $fields ) ) {
			$kit->add_fields( $fields );
		}
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_area_view_fields' );

if ( ! function_exists( 'mvweb_core_area_view_order' ) ) {
	/**
	 * Put the look field first in the section of its area.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string[]> $fields Section id => control ids.
	 *
	 * @return array<string,string[]>
	 */
	function mvweb_core_area_view_order( $fields ) {
		foreach ( mvweb_core_area_views() as $area => $data ) {
			if ( empty( $data['views'] ) ) {
				continue;
			}

			$list                       = isset( $fields[ $data['section'] ] ) ? (array) $fields[ $data['section'] ] : array();
			$fields[ $data['section'] ] = array_merge( array( 'mvweb_view_' . $area ), array_diff( $list, array( 'mvweb_view_' . $area ) ) );
		}

		return $fields;
	}
}
add_filter( 'mvweb_core_customizer_fields', 'mvweb_core_area_view_order', 20 );

if ( ! function_exists( 'mvweb_core_area_view_rules' ) ) {
	/**
	 * Fields shown only in some looks of their area, checked against the live value of the look.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,array<int,array<string,mixed>>> $rules Control id => conditions of the Kit.
	 *
	 * @return array<string,array<int,array<string,mixed>>>
	 */
	function mvweb_core_area_view_rules( $rules ) {
		foreach ( mvweb_core_area_views() as $area => $data ) {
			if ( empty( $data['views'] ) ) {
				continue;
			}

			foreach ( $data['only'] as $setting => $views ) {
				$rules[ $setting ]   = isset( $rules[ $setting ] ) ? (array) $rules[ $setting ] : array();
				$rules[ $setting ][] = array(
					'setting'  => 'mvweb_view_' . $area,
					'operator' => 'in',
					'value'    => $views,
				);
			}
		}

		if ( '' !== mvweb_core_area_view( 'topics' ) ) {
			$rules['mvweb_topics_all_url']   = isset( $rules['mvweb_topics_all_url'] ) ? (array) $rules['mvweb_topics_all_url'] : array();
			$rules['mvweb_topics_all_url'][] = array(
				'setting'  => 'mvweb_view_topics',
				'operator' => '!=',
				'value'    => 'off',
			);
		}

		return $rules;
	}
}
add_filter( 'mvweb_core_customizer_rules', 'mvweb_core_area_view_rules' );

if ( ! function_exists( 'mvweb_core_area_preview_pages' ) ) {
	/**
	 * Where the preview goes when a section of the pages opens: the latest article, the first category, its author, a search, a missing address, the sitemap, a page, the contacts.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,string> $pages Customizer section id => page address.
	 *
	 * @return array<string,string>
	 */
	function mvweb_core_area_preview_pages( $pages ) {
		if ( ! mvweb_core_area_has_views() ) {
			return $pages;
		}

		$latest = get_posts(
			array(
				'post_type'      => 'post',
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'no_found_rows'  => true,
			)
		);
		$latest = $latest ? $latest[0] : null;

		$categories = get_categories(
			array(
				'hide_empty' => true,
				'number'     => 1,
			)
		);

		$special  = array_filter( array( (int) get_option( 'page_on_front' ), (int) get_option( 'page_for_posts' ) ) );
		$page     = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'orderby'        => 'menu_order ID',
				'order'          => 'ASC',
				'fields'         => 'ids',
				'post__not_in'   => $special,
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- Runs once when the Customizer opens.
					'relation' => 'OR',
					array(
						'key'     => '_wp_page_template',
						'compare' => 'NOT EXISTS',
					),
					array(
						'key'   => '_wp_page_template',
						'value' => 'default',
					),
				),
			)
		);
		$contacts = get_posts(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_key'       => '_wp_page_template', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- Runs once when the Customizer opens.
				'meta_value'     => 'page-templates/contacts.php', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- Same.
			)
		);

		$post_types = array();

		foreach ( array( 'mv_service', 'mv_work' ) as $type ) {
			$ids = get_posts(
				array(
					'post_type'      => $type,
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'fields'         => 'ids',
					'no_found_rows'  => true,
				)
			);

			$post_types[ $type ] = array(
				'single'  => $ids ? (string) get_permalink( $ids[0] ) : '',
				'archive' => (string) get_post_type_archive_link( $type ),
			);
		}

		$lists = function_exists( 'mvweb_core_favorites_url' ) ? mvweb_core_favorites_url() : '';

		if ( '' === $lists && function_exists( 'mvweb_core_compare_url' ) ) {
			$lists = mvweb_core_compare_url();
		}

		$words = $latest ? preg_split( '/\s+/u', wp_strip_all_tags( get_the_title( $latest ) ), -1, PREG_SPLIT_NO_EMPTY ) : array();
		$found = array(
			'mvweb_cz_inner_single'   => $latest ? (string) get_permalink( $latest ) : '',
			'mvweb_cz_inner_archive'  => function_exists( 'mvweb_core_blog_url' ) ? mvweb_core_blog_url() : '',
			'mvweb_cz_inner_category' => $categories ? (string) get_category_link( $categories[0] ) : '',
			'mvweb_cz_inner_author'   => $latest ? (string) get_author_posts_url( (int) $latest->post_author ) : '',
			'mvweb_cz_inner_page'     => $page ? (string) get_permalink( $page[0] ) : '',
			'mvweb_cz_inner_contacts' => $contacts ? (string) get_permalink( $contacts[0] ) : '',
			'mvweb_cz_inner_search'   => add_query_arg( 's', rawurlencode( $words ? (string) $words[0] : 'a' ), home_url( '/' ) ),
			'mvweb_cz_inner_404'      => add_query_arg( 'p', PHP_INT_MAX, home_url( '/' ) ),
			'mvweb_cz_services_page'  => $post_types['mv_service']['single'],
			'mvweb_cz_services_list'  => $post_types['mv_service']['archive'],
			'mvweb_cz_services_work'  => $post_types['mv_work']['single'],
			'mvweb_cz_services_works' => $post_types['mv_work']['archive'],
			'mvweb_cz_catalog_lists'  => $lists,
		);

		if ( function_exists( 'mvweb_core_sitemap_page_ids' ) ) {
			foreach ( mvweb_core_sitemap_page_ids() as $id ) {
				if ( 'publish' === get_post_status( $id ) ) {
					$found['mvweb_cz_inner_sitemap'] = (string) get_permalink( $id );
					break;
				}
			}
		}

		return array_merge( $pages, array_filter( $found ) );
	}
}
add_filter( 'mvweb_core_global_pages', 'mvweb_core_area_preview_pages' );
