<?php
/**
 * Composition of the pages of the lists: the favourites and the comparison.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_lists_section = __( 'Favourites and comparison', 'mvweb-core' );

return array(
	'favorites'    => array(
		'label'         => __( 'Favourites page', 'mvweb-core' ),
		'description'   => __( 'Drag to reorder. Untick to hide. The number of items stands under the heading, the note for a guest above the tools.', 'mvweb-core' ),
		'panel'         => 'mvweb_cz_catalog',
		'section'       => 'mvweb_cz_catalog_lists',
		'section_title' => $mvweb_lists_section,
		'parts'         => array(
			'count' => _x( 'Number of items', 'shop list', 'mvweb-core' ),
			'note'  => __( 'Note for a guest', 'mvweb-core' ),
			'share' => __( 'Share the list', 'mvweb-core' ),
			'clear' => __( 'Clear the list', 'mvweb-core' ),
			'view'  => __( 'Cards or table', 'mvweb-core' ),
		),
	),
	'compare-bar'  => array(
		'label'         => __( 'Comparison: facts and tools', 'mvweb-core' ),
		'description'   => __( 'Drag to reorder. Untick to hide. The category choice shows only while items of more than one category are compared.', 'mvweb-core' ),
		'panel'         => 'mvweb_cz_catalog',
		'section'       => 'mvweb_cz_catalog_lists',
		'section_title' => $mvweb_lists_section,
		'parts'         => array(
			'meta'     => __( 'Facts under the heading', 'mvweb-core' ),
			'category' => __( 'Category choice', 'mvweb-core' ),
			'diff'     => __( 'Only differences switch', 'mvweb-core' ),
		),
	),
	'compare-rows' => array(
		'label'         => __( 'Comparison: rows of the table', 'mvweb-core' ),
		'description'   => __( 'Drag to reorder. Untick to hide. A row nobody has data for is not printed.', 'mvweb-core' ),
		'panel'         => 'mvweb_cz_catalog',
		'section'       => 'mvweb_cz_catalog_lists',
		'section_title' => $mvweb_lists_section,
		'parts'         => array(
			'wholesale' => __( 'Wholesale price', 'mvweb-core' ),
			'specs'     => __( 'Characteristics', 'mvweb-core' ),
			'sku'       => __( 'Article', 'mvweb-core' ),
			'stock'     => __( 'Availability', 'mvweb-core' ),
			'rating'    => __( 'Rating', 'mvweb-core' ),
		),
	),
);
