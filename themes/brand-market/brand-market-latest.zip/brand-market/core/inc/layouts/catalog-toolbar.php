<?php
/**
 * Composition of the bar above a listing: the count, the sorting, the look.
 *
 * The button that opens the filters on a narrow screen sits with the sorting
 * and shows whenever the listing has filters.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'catalog-toolbar' => array(
		'label'       => __( 'Bar of a listing', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The chosen filters show under the bar.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_archive',
		'parts'       => array(
			'count' => _x( 'Number of items', 'shop list', 'mvweb-core' ),
			'sort'  => __( 'Sorting', 'mvweb-core' ),
			'view'  => __( 'Cards or table', 'mvweb-core' ),
		),
	),
);
