<?php
/**
 * Composition areas: the page of a work.
 *
 * Four areas, one for each place of the page: the head, the side card, the
 * main column and the blocks under the page. The listing of the portfolio has
 * no area of its own: its parts stand in an order that carries meaning and are
 * switched by settings.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'work-head'   => array(
		'label'         => __( 'Work: head', 'mvweb-core' ),
		'description'   => __( 'Drag to reorder. Untick to hide. The heading is always shown: it is the heading of the page.', 'mvweb-core' ),
		'panel'         => 'mvweb_cz_services',
		'section'       => 'mvweb_cz_services_work',
		'section_title' => __( 'Work page', 'mvweb-core' ),
		'parts'         => array(
			'kind'    => __( 'Kind of work', 'mvweb-core' ),
			'title'   => __( 'Heading (always shown)', 'mvweb-core' ),
			'excerpt' => __( 'Short text', 'mvweb-core' ),
		),
		'keep'          => array( 'title' ),
	),
	'work-aside'  => array(
		'label'         => __( 'Work: side card', 'mvweb-core' ),
		'description'   => __( 'Drag to reorder. Untick to hide.', 'mvweb-core' ),
		'panel'         => 'mvweb_cz_services',
		'section'       => 'mvweb_cz_services_work',
		'section_title' => __( 'Work page', 'mvweb-core' ),
		'parts'         => array(
			'title'   => _x( 'Heading of the card', 'work page', 'mvweb-core' ),
			'facts'   => __( 'Facts', 'mvweb-core' ),
			'service' => __( 'Service of the work', 'mvweb-core' ),
			'cta'     => __( 'Request button', 'mvweb-core' ),
			'share'   => __( 'Share', 'mvweb-core' ),
		),
	),
	'work-main'   => array(
		'label'         => __( 'Work: main column', 'mvweb-core' ),
		'description'   => __( 'Drag to reorder. Untick to hide.', 'mvweb-core' ),
		'panel'         => 'mvweb_cz_services',
		'section'       => 'mvweb_cz_services_work',
		'section_title' => __( 'Work page', 'mvweb-core' ),
		'parts'         => array(
			'gallery' => __( 'Gallery', 'mvweb-core' ),
			'story'   => __( 'Task and result', 'mvweb-core' ),
			'body'    => __( 'Text of the work', 'mvweb-core' ),
			'review'  => __( 'Review of the client', 'mvweb-core' ),
		),
	),
	'work-blocks' => array(
		'label'         => __( 'Work: blocks under the page', 'mvweb-core' ),
		'description'   => __( 'Drag to reorder. Untick to hide.', 'mvweb-core' ),
		'panel'         => 'mvweb_cz_services',
		'section'       => 'mvweb_cz_services_work',
		'section_title' => __( 'Work page', 'mvweb-core' ),
		'parts'         => array(
			'before-after' => __( 'Before and after', 'mvweb-core' ),
			'related'      => __( 'Other works', 'mvweb-core' ),
		),
	),
);
