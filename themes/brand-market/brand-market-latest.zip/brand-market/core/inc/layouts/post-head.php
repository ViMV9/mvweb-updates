<?php
/**
 * Composition area: what follows the title of an entry.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'post-head' => array(
		'label'       => __( 'Under the title of a post', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The parts that stand after the cover go under it.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_single',
		'parts'       => array(
			'lead'   => __( 'Excerpt', 'mvweb-core' ),
			'byline' => __( 'Author with position', 'mvweb-core' ),
			'cover'  => __( 'Cover', 'mvweb-core' ),
		),
	),
);
