<?php
/**
 * Composition area: Section card: the picture, the name, the number of services and the link.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'card-service-section' => array(
		'label'       => __( 'Card of a section of services', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The picture stays on top of the card. The strip of subsections shows the picture, the name and the number only.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_list',
		'parts'       => array(
			'image' => __( 'Picture', 'mvweb-core' ),
			'title' => __( 'Name', 'mvweb-core' ),
			'count' => __( 'Number of services', 'mvweb-core' ),
			'more'  => __( 'Link', 'mvweb-core' ),
		),
	),
);
