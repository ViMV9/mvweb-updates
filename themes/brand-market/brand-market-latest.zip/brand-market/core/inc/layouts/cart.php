<?php
/**
 * Composition areas of the cart, the checkout, the order received page and the side cart.
 *
 * The steps of the checkout and the order total are not here: their order is
 * the order of the actions of the customer.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_panel   = 'mvweb_cz_conversion';
$mvweb_section = 'mvweb_cz_conversion_cart';
$mvweb_hint    = __( 'Drag to reorder. Untick to hide. A part with nothing to say is not printed.', 'mvweb-core' );

return array(
	'cart.hero'     => array(
		'label'       => __( 'Cart: facts under the heading', 'mvweb-core' ),
		'description' => $mvweb_hint,
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'count'    => __( 'Number of goods', 'mvweb-core' ),
			'shipping' => __( 'Free delivery', 'mvweb-core' ),
		),
	),
	'cart.page'     => array(
		'label'       => __( 'Cart: blocks of the page', 'mvweb-core' ),
		'description' => $mvweb_hint,
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'lines' => __( 'Lines and order total', 'mvweb-core' ),
			'cross' => __( 'Goods bought together', 'mvweb-core' ),
		),
	),
	'cart.tools'    => array(
		'label'       => __( 'Cart: tools under the lines', 'mvweb-core' ),
		'description' => $mvweb_hint,
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'coupon' => __( 'Promo code', 'mvweb-core' ),
			'links'  => __( 'Continue shopping and empty the cart', 'mvweb-core' ),
		),
	),
	'cart.aside'    => array(
		'label'       => __( 'Cart: under the order total', 'mvweb-core' ),
		'description' => $mvweb_hint,
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'notes' => __( 'Notes', 'mvweb-core' ),
		),
	),
	'cart-line'     => array(
		'label'       => __( 'Cart: a line', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The name and the price stay. The minimum line always stands under the quantity field.', 'mvweb-core' ),
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'brand' => __( 'Brand', 'mvweb-core' ),
			'title' => __( 'Name', 'mvweb-core' ),
			'meta'  => __( 'Article and stock', 'mvweb-core' ),
			'price' => __( 'Price', 'mvweb-core' ),
			'hint'  => __( 'Wholesale price hint', 'mvweb-core' ),
			'limit' => __( 'Minimum and step', 'mvweb-core' ),
		),
	),
	'checkout.hero' => array(
		'label'       => __( 'Checkout: facts under the heading', 'mvweb-core' ),
		'description' => $mvweb_hint,
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'secure' => __( 'Protected connection', 'mvweb-core' ),
			'login'  => __( 'Link for a returning customer', 'mvweb-core' ),
		),
	),
	'thanks.page'   => array(
		'label'       => __( 'Order received: blocks of the page', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The order number, the date, the total and the order items stay.', 'mvweb-core' ),
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'info'    => __( 'Delivery and recipient', 'mvweb-core' ),
			'pay'     => __( 'Instructions of the payment method', 'mvweb-core' ),
			'next'    => __( 'What happens next', 'mvweb-core' ),
			'actions' => __( 'Buttons', 'mvweb-core' ),
		),
	),
	'pay-fail'      => array(
		'label'       => __( 'Failed payment: blocks of the page', 'mvweb-core' ),
		'description' => $mvweb_hint,
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'actions' => __( 'Buttons', 'mvweb-core' ),
			'reasons' => __( 'Usual reasons and contacts', 'mvweb-core' ),
		),
	),
	'side-cart'     => array(
		'label'       => __( 'Side cart: parts', 'mvweb-core' ),
		'description' => $mvweb_hint,
		'panel'       => $mvweb_panel,
		'section'     => $mvweb_section,
		'parts'       => array(
			'ship' => __( 'Line about free delivery', 'mvweb-core' ),
		),
	),
);
