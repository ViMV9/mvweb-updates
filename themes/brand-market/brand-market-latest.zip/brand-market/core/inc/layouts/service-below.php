<?php
/**
 * Composition area: Blocks under the page of a service.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'service-below' => array(
		'label'       => __( 'Under the service page', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The blocks are those built in the page builder of the service.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_page',
		'parts'       => array(
			'sections' => __( 'Blocks of the service', 'mvweb-core' ),
			'works'    => __( 'Works on the service', 'mvweb-core' ),
			'related'  => __( 'Other services of the section', 'mvweb-core' ),
		),
	),
);
