<?php
/**
 * Composition areas: the account of a customer.
 *
 * Three areas, one for each page that holds parts in an order that carries no
 * fixed meaning: the dashboard under the greeting, the page of an order under
 * its overview, and the sign-in page. The forms of WooCommerce print their own
 * fields, so what moves here are the blocks of the page, not the fields.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'WooCommerce' ) ) {
	return array();
}

return array(
	'account-dashboard' => array(
		'label'         => __( 'Account: dashboard', 'mvweb-core' ),
		'description'   => __( 'Drag to reorder. Untick to hide. The greeting stays first.', 'mvweb-core' ),
		'panel'         => 'mvweb_cz_catalog',
		'section'       => 'mvweb_cz_catalog_account',
		'section_title' => __( 'Account', 'mvweb-core' ),
		'parts'         => array(
			'tiles'  => __( 'Tiles', 'mvweb-core' ),
			'recent' => __( 'Recent orders', 'mvweb-core' ),
		),
	),
	'account-order'     => array(
		'label'         => __( 'Account: page of an order', 'mvweb-core' ),
		'description'   => __( 'Drag to reorder. Untick to hide. The overview and the payment reminder stay on top.', 'mvweb-core' ),
		'panel'         => 'mvweb_cz_catalog',
		'section'       => 'mvweb_cz_catalog_account',
		'section_title' => __( 'Account', 'mvweb-core' ),
		'parts'         => array(
			'items'     => __( 'Contents and totals', 'mvweb-core' ),
			'addresses' => __( 'Delivery and contacts', 'mvweb-core' ),
			'timeline'  => __( 'History of the order', 'mvweb-core' ),
			'actions'   => __( 'Buttons', 'mvweb-core' ),
		),
	),
	'account-login'     => array(
		'label'         => __( 'Account: sign in page', 'mvweb-core' ),
		'description'   => __( 'Drag to reorder. Untick to hide. Registration also depends on the account settings of WooCommerce.', 'mvweb-core' ),
		'panel'         => 'mvweb_cz_catalog',
		'section'       => 'mvweb_cz_catalog_account',
		'section_title' => __( 'Account', 'mvweb-core' ),
		'parts'         => array(
			'login'    => __( 'Sign in', 'mvweb-core' ),
			'register' => __( 'Registration', 'mvweb-core' ),
			'perks'    => __( 'What an account gives', 'mvweb-core' ),
		),
	),
);
