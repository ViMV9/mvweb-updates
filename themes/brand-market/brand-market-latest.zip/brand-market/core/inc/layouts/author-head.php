<?php
/**
 * Composition area: the heading of the archive of an author.
 *
 * The part «Position» comes when the theme names it in
 * add_theme_support( 'mvweb-author-head', array( 'role' ) ).
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_core_author_head_support = get_theme_support( 'mvweb-author-head' );
$mvweb_core_author_head_wanted  = is_array( $mvweb_core_author_head_support ) && isset( $mvweb_core_author_head_support[0] ) ? array_map( 'strval', (array) $mvweb_core_author_head_support[0] ) : array();
$mvweb_core_author_head_extra   = array_intersect_key(
	array(
		'role' => __( 'Position', 'mvweb-core' ),
	),
	array_flip( $mvweb_core_author_head_wanted )
);

return array(
	'author-head' => array(
		'label'       => __( 'Heading of an author archive', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The picture stays on the left.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_archive',
		'off'         => array( 'socials' ),
		'parts'       => array(
			'avatar' => __( 'Picture', 'mvweb-core' ),
		) + $mvweb_core_author_head_extra + array(
			'lead'    => __( 'Description from the profile', 'mvweb-core' ),
			'count'   => __( 'Number of posts', 'mvweb-core' ),
			'since'   => __( 'With the site since', 'mvweb-core' ),
			'socials' => __( 'Links of the author', 'mvweb-core' ),
		),
	),
);
