<?php
/**
 * Composition area: the heading of the archive of an author.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'author-head' => array(
		'label'       => __( 'Heading of an author archive', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The picture stays on the left.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_archive',
		'off'         => array( 'socials' ),
		'parts'       => array(
			'avatar'  => __( 'Picture', 'mvweb-core' ),
			'lead'    => __( 'Description from the profile', 'mvweb-core' ),
			'count'   => __( 'Number of posts', 'mvweb-core' ),
			'since'   => __( 'With the site since', 'mvweb-core' ),
			'socials' => __( 'Links of the author', 'mvweb-core' ),
		),
	),
);
