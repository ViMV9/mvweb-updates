<?php
/**
 * Composition area: the card of a work.
 *
 * One composition for every card of a work: in the block, in the portfolio,
 * under a service and among the other works.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'card-work' => array(
		'label'       => __( 'Card of a work', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The picture stays where the view of the block puts it.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_works',
		'parts'       => array(
			'number' => __( 'Number in the ribbon view', 'mvweb-core' ),
			'kind'   => __( 'Kind of work', 'mvweb-core' ),
			'title'  => __( 'Name', 'mvweb-core' ),
			'facts'  => __( 'Facts', 'mvweb-core' ),
			'arrow'  => __( 'Arrow in the photo and list views', 'mvweb-core' ),
		),
	),
);
