<?php
/**
 * Composition area: Blocks of the services listing: the strip of subsections and the list itself.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'service-list' => array(
		'label'       => __( 'Services listing', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The text under the list follows the list.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_list',
		'parts'       => array(
			'subs' => __( 'Strip of subsections', 'mvweb-core' ),
			'list' => __( 'Services', 'mvweb-core' ),
		),
	),
);
