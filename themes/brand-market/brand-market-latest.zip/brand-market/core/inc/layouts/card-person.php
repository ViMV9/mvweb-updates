<?php
/**
 * Composition area: the card of a doctor.
 *
 * One composition for every card of a doctor in the listing. It exists only for
 * a theme that has add_theme_support( 'mvweb-team-pages' ) and the module Team on.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_team_pages_on' ) || ! mvweb_core_team_pages_on() ) {
	return array();
}

return array(
	'card-person' => array(
		'label'       => __( 'Card of a doctor', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The photo stays where the view of the listing puts it.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_team_list',
		'parts'       => array(
			'photo'  => __( 'Photo', 'mvweb-core' ),
			'role'   => __( 'Position', 'mvweb-core' ),
			'name'   => __( 'Name', 'mvweb-core' ),
			'note'   => __( 'Degree and category', 'mvweb-core' ),
			'exp'    => __( 'Experience', 'mvweb-core' ),
			'age'    => __( 'Age of patients', 'mvweb-core' ),
			'branch' => __( 'Branch', 'mvweb-core' ),
			'price'  => __( 'Price of a visit', 'mvweb-core' ),
			'book'   => __( 'Booking button', 'mvweb-core' ),
		),
	),
);
