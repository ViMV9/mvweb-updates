<?php
/**
 * Composition area: the block about the author under an entry.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'author-box' => array(
		'label'       => __( 'Author block', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The picture stays on the left.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_single',
		'parts'       => array(
			'avatar'  => __( 'Picture', 'mvweb-core' ),
			'bio'     => __( 'Description from the profile', 'mvweb-core' ),
			'more'    => __( 'Link to all posts of the author', 'mvweb-core' ),
			'socials' => __( 'Links of the author', 'mvweb-core' ),
		),
	),
);
