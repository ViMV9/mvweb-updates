<?php
/**
 * Composition area: Facts under the heading of a section of services.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'service-hero' => array(
		'label'       => __( 'Under the heading of a section', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The points are written in the section itself.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_list',
		'parts'       => array(
			'count'  => __( 'Number of services', 'mvweb-core' ),
			'points' => __( 'Points of the section', 'mvweb-core' ),
		),
	),
);
