<?php
/**
 * Composition area: the line above the title of an entry.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'post-meta' => array(
		'label'       => __( 'Line above the title of a post', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_single',
		'off'         => array( 'updated' ),
		'parts'       => array(
			'topic'   => _x( 'Category', 'blog post', 'mvweb-core' ),
			'time'    => __( 'Date', 'mvweb-core' ),
			'read'    => __( 'Reading time', 'mvweb-core' ),
			'updated' => __( 'Date of the last change', 'mvweb-core' ),
		),
	),
);
