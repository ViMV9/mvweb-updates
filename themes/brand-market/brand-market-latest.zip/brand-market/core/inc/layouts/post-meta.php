<?php
/**
 * Composition area: the line of the facts of an entry, above or under the title.
 *
 * The parts «Number of views» and «Number of comments» come when the theme names them in
 * add_theme_support( 'mvweb-post-meta', array( 'views', 'comments' ) ).
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_core_meta_support = get_theme_support( 'mvweb-post-meta' );
$mvweb_core_meta_wanted  = is_array( $mvweb_core_meta_support ) && isset( $mvweb_core_meta_support[0] ) ? array_map( 'strval', (array) $mvweb_core_meta_support[0] ) : array();
$mvweb_core_meta_extra   = array_intersect_key(
	array(
		'views'    => __( 'Number of views', 'mvweb-core' ),
		'comments' => __( 'Number of comments', 'mvweb-core' ),
	),
	array_flip( $mvweb_core_meta_wanted )
);

return array(
	'post-meta' => array(
		'label'       => empty( $mvweb_core_meta_extra ) ? __( 'Line above the title of a post', 'mvweb-core' ) : __( 'Facts of a post', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_single',
		'off'         => array( 'updated' ),
		'parts'       => array(
			'topic'   => _x( 'Category', 'blog post', 'mvweb-core' ),
			'time'    => __( 'Date', 'mvweb-core' ),
			'read'    => __( 'Reading time', 'mvweb-core' ),
			'updated' => __( 'Date of the last change', 'mvweb-core' ),
		) + $mvweb_core_meta_extra,
	),
);
