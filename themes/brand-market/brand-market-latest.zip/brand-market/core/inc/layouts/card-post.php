<?php
/**
 * Composition area: the card of a blog post.
 *
 * One card for the blog, the archives, the search and the blocks, so its parts
 * are set once for the site. The parts «Author», «Comments» and «Views» come when
 * the theme names them in add_theme_support( 'mvweb-card-post', array( 'author', 'comments', 'views' ) );
 * «Views» prints a number only while the views are counted.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_core_card_support = get_theme_support( 'mvweb-card-post' );
$mvweb_core_card_wanted  = is_array( $mvweb_core_card_support ) && isset( $mvweb_core_card_support[0] ) ? array_map( 'strval', (array) $mvweb_core_card_support[0] ) : array();
$mvweb_core_card_extra   = array_intersect_key(
	array(
		'author'   => __( 'Author', 'mvweb-core' ),
		'comments' => __( 'Number of comments', 'mvweb-core' ),
		'views'    => __( 'Number of views', 'mvweb-core' ),
	),
	array_flip( $mvweb_core_card_wanted )
);

return array(
	'card-post' => array(
		'label'   => __( 'Card of a post', 'mvweb-core' ),
		'panel'   => 'mvweb_cz_inner',
		'section' => 'mvweb_cz_inner_archive',
		'parts'   => array(
			'media' => __( 'Cover', 'mvweb-core' ),
			'topic' => _x( 'Category', 'blog post', 'mvweb-core' ),
			'date'  => __( 'Date', 'mvweb-core' ),
			'read'  => __( 'Reading time', 'mvweb-core' ),
			'title' => __( 'Title', 'mvweb-core' ),
			'lead'  => __( 'Excerpt', 'mvweb-core' ),
			'more'  => __( 'Read more', 'mvweb-core' ),
		) + $mvweb_core_card_extra,
	),
);
