<?php
/**
 * Composition area: the card of a blog post.
 *
 * One card for the blog, the archives, the search and the blocks, so its parts
 * are set once for the site.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'card-post' => array(
		'label'   => __( 'Card of a post', 'mvweb-core' ),
		'panel'   => 'mvweb_cz_inner',
		'section' => 'mvweb_cz_inner_archive',
		'parts'   => array(
			'media' => __( 'Cover', 'mvweb-core' ),
			'topic' => _x( 'Category', 'blog post', 'mvweb-core' ),
			'date'  => __( 'Date', 'mvweb-core' ),
			'read'  => __( 'Reading time', 'mvweb-core' ),
			'title' => __( 'Title', 'mvweb-core' ),
			'lead'  => __( 'Excerpt', 'mvweb-core' ),
			'more'  => __( 'Read more', 'mvweb-core' ),
		),
	),
);
