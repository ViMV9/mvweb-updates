<?php
/**
 * Composition of what stands under a listing: the text of the category and the blocks.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'listing-below' => array(
		'label'       => __( 'Under a listing', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The pages of the listing stay above.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_archive',
		'parts'       => array(
			'text'   => __( 'Text of the category', 'mvweb-core' ),
			'blocks' => __( 'Blocks', 'mvweb-core' ),
		),
	),
);
