<?php
/**
 * Composition area: Head of a section in the tree of services.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'tree-head' => array(
		'label'       => __( 'Head of a section in the tree', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The number of services also stands beside the subsections.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_list',
		'parts'       => array(
			'cover' => __( 'Cover', 'mvweb-core' ),
			'count' => __( 'Number of services', 'mvweb-core' ),
			'title' => __( 'Name', 'mvweb-core' ),
			'desc'  => __( 'Description', 'mvweb-core' ),
			'more'  => __( 'Link', 'mvweb-core' ),
		),
	),
);
