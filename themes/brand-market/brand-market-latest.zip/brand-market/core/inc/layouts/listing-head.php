<?php
/**
 * Composition of the head of a listing under the heading: the text and the chips.
 *
 * The chips are the filter pages of a category, or the values of a filter page.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'listing-head' => array(
		'label'       => __( 'Head of a listing', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The heading and the breadcrumbs are set with the head of a page.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_archive',
		'parts'       => array(
			'lead'  => __( 'Text under the heading', 'mvweb-core' ),
			'chips' => __( 'Chips of the filter pages', 'mvweb-core' ),
		),
	),
);
