<?php
/**
 * Composition area: Side card of the page of a service.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'service-aside' => array(
		'label'       => __( 'Side card of the service page', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_page',
		'parts'       => array(
			'title'      => __( 'Heading', 'mvweb-core' ),
			'price'      => __( 'Price', 'mvweb-core' ),
			'form'       => __( 'Form or button', 'mvweb-core' ),
			'phone'      => __( 'Phone', 'mvweb-core' ),
			'messengers' => __( 'Messengers', 'mvweb-core' ),
			'note'       => __( 'Note', 'mvweb-core' ),
			'share'      => __( 'Share buttons', 'mvweb-core' ),
		),
	),
);
