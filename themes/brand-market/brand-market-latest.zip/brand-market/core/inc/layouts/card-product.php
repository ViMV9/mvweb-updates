<?php
/**
 * Composition of the product card: which parts it shows and in what order.
 *
 * One composition for every place the card stands in: listings, blocks, the
 * favourites. The badges, the favourites button and the wholesale column
 * have no file of their own: they sit on the photo and beside the price,
 * so the card reads their switch and the order of the rest.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'card-product' => array(
		'label'       => __( 'Product card', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The badges and the favourites button stay on the photo, the wholesale price stays beside the price, the quantity stays before the button of a shop listing, the article and the stock show in the table view of a listing.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_archive',
		'parts'       => array(
			'badges'  => __( 'Badges on the photo', 'mvweb-core' ),
			'fav'     => __( 'Favourites button', 'mvweb-core' ),
			'compare' => __( 'Compare button', 'mvweb-core' ),
			'brand'   => __( 'Brand', 'mvweb-core' ),
			'rating'  => __( 'Rating', 'mvweb-core' ),
			'title'   => __( 'Name', 'mvweb-core' ),
			'meta'    => __( 'Article and stock', 'mvweb-core' ),
			'price'   => __( 'Price', 'mvweb-core' ),
			'opt'     => __( 'Wholesale price', 'mvweb-core' ),
			'qty'     => __( 'Quantity field', 'mvweb-core' ),
			'buy'     => __( 'Button', 'mvweb-core' ),
		),
	),
);
