<?php
/**
 * Composition area: what follows the text of an entry.
 *
 * The parts «Was the article helpful?» and «Article updated» come when the theme names them in
 * add_theme_support( 'mvweb-post-after', array( 'helpful', 'updated' ) ); «Article updated» stays off until the owner ticks it.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_core_after_support = get_theme_support( 'mvweb-post-after' );
$mvweb_core_after_wanted  = is_array( $mvweb_core_after_support ) && isset( $mvweb_core_after_support[0] ) ? array_map( 'strval', (array) $mvweb_core_after_support[0] ) : array();
$mvweb_core_after_extra   = array_intersect_key(
	array(
		'helpful' => __( 'Was the article helpful?', 'mvweb-core' ),
		'updated' => __( 'Article updated', 'mvweb-core' ),
	),
	array_flip( $mvweb_core_after_wanted )
);

return array(
	'post-after' => array(
		'label'       => __( 'Under the text of a post', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The author block also needs the tick box "Show the author block" below.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_single',
		'parts'       => array(
			'tags'   => __( 'Tags', 'mvweb-core' ),
			'share'  => __( 'Share buttons', 'mvweb-core' ),
			'author' => __( 'Author block', 'mvweb-core' ),
			'nav'    => __( 'Previous and next post', 'mvweb-core' ),
		) + $mvweb_core_after_extra,
		'off'         => array_values( array_intersect( array( 'updated' ), array_keys( $mvweb_core_after_extra ) ) ),
	),
);
