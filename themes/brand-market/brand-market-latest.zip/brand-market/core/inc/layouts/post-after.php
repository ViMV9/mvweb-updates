<?php
/**
 * Composition area: what follows the text of an entry.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'post-after' => array(
		'label'       => __( 'Under the text of a post', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The author block also needs the tick box "Show the author block" below.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_single',
		'parts'       => array(
			'tags'   => __( 'Tags', 'mvweb-core' ),
			'share'  => __( 'Share buttons', 'mvweb-core' ),
			'author' => __( 'Author block', 'mvweb-core' ),
			'nav'    => __( 'Previous and next post', 'mvweb-core' ),
		),
	),
);
