<?php
/**
 * Composition area: the header of an item page.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'product-header' => array(
		'label'       => __( 'Item header', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The name is always shown: it is the heading of the page.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_product',
		'parts'       => array(
			'brand'    => __( 'Brand', 'mvweb-core' ),
			'title'    => __( 'Name (always shown)', 'mvweb-core' ),
			'stock'    => __( 'Availability', 'mvweb-core' ),
			'sku'      => __( 'Article', 'mvweb-core' ),
			'category' => __( 'Categories', 'mvweb-core' ),
			'tags'     => __( 'Tags', 'mvweb-core' ),
			'rating'   => __( 'Rating', 'mvweb-core' ),
		),
		'keep'        => array( 'title' ),
	),
);
