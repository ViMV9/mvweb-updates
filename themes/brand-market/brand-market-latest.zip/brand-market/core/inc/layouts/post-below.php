<?php
/**
 * Composition area: the bands under an entry.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'post-below' => array(
		'label'       => __( 'Bands under a post', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. Comments are also switched off in Settings, Discussion.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_inner_single',
		'parts'       => array(
			'related'  => __( 'More posts', 'mvweb-core' ),
			'comments' => __( 'Comments', 'mvweb-core' ),
		),
	),
);
