<?php
/**
 * Composition areas: the pages of the doctors.
 *
 * Two areas: the listing and the page of a doctor. They exist only for a theme
 * that has add_theme_support( 'mvweb-team-pages' ) and the module Team on.
 * Reviews and articles of a doctor are not parts: the core keeps no reviews.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_team_pages_on' ) || ! mvweb_core_team_pages_on() ) {
	return array();
}

return array(
	'doctors' => array(
		'label'       => __( 'Doctors: listing', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_team_list',
		'parts'       => array(
			'filters'    => __( 'Filters', 'mvweb-core' ),
			'count'      => __( 'Number of doctors found', 'mvweb-core' ),
			'sort'       => __( 'Sort', 'mvweb-core' ),
			'list'       => __( 'Cards of doctors', 'mvweb-core' ),
			'pagination' => __( 'Pagination', 'mvweb-core' ),
		),
	),
	'doctor'  => array(
		'label'       => __( 'Doctor: page', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_inner',
		'section'     => 'mvweb_cz_team_page',
		'parts'       => array(
			'head'      => __( 'Head: photo, name, position', 'mvweb-core' ),
			'facts'     => __( 'Facts: experience, degree, category, age, price', 'mvweb-core' ),
			'about'     => __( 'About the doctor', 'mvweb-core' ),
			'education' => __( 'Education and courses', 'mvweb-core' ),
			'certs'     => __( 'Certificates', 'mvweb-core' ),
			'services'  => __( 'Services of the doctor', 'mvweb-core' ),
			'aside'     => __( 'Side card: price and booking', 'mvweb-core' ),
		),
	),
);
