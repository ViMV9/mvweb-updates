<?php
/**
 * Composition area: the photo of an item.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'product-media' => array(
		'label'       => __( 'Item photo', 'mvweb-core' ),
		'description' => __( 'Untick to hide. The big photo and the arrows stay; the badges and the strip of small photos can go.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_product',
		'parts'       => array(
			'badges' => __( 'Badges on the photo', 'mvweb-core' ),
			'thumbs' => __( 'Strip of small photos', 'mvweb-core' ),
		),
	),
);
