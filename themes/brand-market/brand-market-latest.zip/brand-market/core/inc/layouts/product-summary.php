<?php
/**
 * Composition area: the column beside the photo of an item.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'product-summary' => array(
		'label'       => __( 'Item summary', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The header stays first.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_product',
		'parts'       => array(
			'excerpt'  => __( 'Short description', 'mvweb-core' ),
			'switch'   => __( 'Links by the value of a property', 'mvweb-core' ),
			'purchase' => __( 'Purchase box', 'mvweb-core' ),
			'specs'    => __( 'Main specifications', 'mvweb-core' ),
			'share'    => __( 'Share buttons', 'mvweb-core' ),
		),
	),
);
