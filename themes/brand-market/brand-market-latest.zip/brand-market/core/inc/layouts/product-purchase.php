<?php
/**
 * Composition area: the purchase box of an item.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'product-purchase' => array(
		'label'       => __( 'Item purchase box', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. A part with nothing to say is not printed.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_product',
		'parts'       => array(
			'prices'    => __( 'Prices', 'mvweb-core' ),
			'tiers'     => __( 'Prices by quantity', 'mvweb-core' ),
			'total'     => __( 'Total for the quantity', 'mvweb-core' ),
			'buy'       => __( 'Buy or request buttons', 'mvweb-core' ),
			'compare'   => __( 'Compare button', 'mvweb-core' ),
			'note'      => __( 'Line under the buttons', 'mvweb-core' ),
			'markets'   => __( 'Marketplaces', 'mvweb-core' ),
			'benefits'  => _x( 'Benefits', 'product purchase', 'mvweb-core' ),
			'documents' => __( 'Documents', 'mvweb-core' ),
			'file'      => __( 'File link', 'mvweb-core' ),
		),
	),
);
