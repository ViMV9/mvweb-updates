<?php
/**
 * Composition area: Service card: the picture, the name, the line under it, the price and the link.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'card-service' => array(
		'label'       => __( 'Card of a service', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The picture stays on top of the card. The price and the link stand in one line under the rest.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_services',
		'section'     => 'mvweb_cz_services_list',
		'parts'       => array(
			'image'     => __( 'Picture', 'mvweb-core' ),
			'title'     => __( 'Name', 'mvweb-core' ),
			'advantage' => __( 'Line under the name', 'mvweb-core' ),
			'price'     => __( 'Price', 'mvweb-core' ),
			'more'      => __( 'Link', 'mvweb-core' ),
		),
	),
);
