<?php
/**
 * Composition area: the sections under an item.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'product-sections' => array(
		'label'       => __( 'Sections under the item', 'mvweb-core' ),
		'description' => __( 'Drag to reorder. Untick to hide. The links above the sections follow this order. A section with nothing to say is not printed.', 'mvweb-core' ),
		'panel'       => 'mvweb_cz_catalog',
		'section'     => 'mvweb_cz_catalog_product',
		'parts'       => array(
			'description' => __( 'Description', 'mvweb-core' ),
			'specs'       => __( 'Specifications', 'mvweb-core' ),
			'reviews'     => __( 'Reviews', 'mvweb-core' ),
			'upsells'     => __( 'Goods bought together', 'mvweb-core' ),
			'related'     => __( 'Similar items', 'mvweb-core' ),
		),
	),
);
