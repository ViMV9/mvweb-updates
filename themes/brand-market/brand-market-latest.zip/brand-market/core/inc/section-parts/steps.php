<?php
/**
 * Parts of a block type: how the work is done, step by step.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'title' => __( 'Heading', 'mvweb-core' ),
		'lead'  => __( 'Lead', 'mvweb-core' ),
		'list'  => __( 'Steps', 'mvweb-core' ),
	),
	'item_parts' => array(
		'image' => __( 'Photo', 'mvweb-core' ),
		'num'   => __( 'Number', 'mvweb-core' ),
		'title' => __( 'Heading', 'mvweb-core' ),
		'text'  => __( 'Text', 'mvweb-core' ),
	),
);
