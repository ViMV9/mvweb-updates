<?php
/**
 * Parts of a block type: where to find us and whom to call.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker'  => __( 'Line above the heading', 'mvweb-core' ),
		'title'   => __( 'Heading', 'mvweb-core' ),
		'lead'    => __( 'Lead', 'mvweb-core' ),
		'phone'   => __( 'Phone', 'mvweb-core' ),
		'email'   => __( 'E-mail', 'mvweb-core' ),
		'address' => __( 'Address', 'mvweb-core' ),
		'hours'   => __( 'Opening hours', 'mvweb-core' ),
		'chats'   => __( 'Messengers', 'mvweb-core' ),
		'map'     => __( 'Map', 'mvweb-core' ),
	),
	'item_parts' => array(
		'icon'  => __( 'Icon', 'mvweb-core' ),
		'label' => __( 'Caption', 'mvweb-core' ),
		'value' => __( 'Value', 'mvweb-core' ),
		'note'  => __( 'Note', 'mvweb-core' ),
	),
);
