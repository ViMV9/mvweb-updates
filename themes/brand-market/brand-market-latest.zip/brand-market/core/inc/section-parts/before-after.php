<?php
/**
 * Parts of a block type: before and after.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Text under the heading', 'mvweb-core' ),
		'list'   => __( 'Jobs', 'mvweb-core' ),
		'button' => __( 'Button', 'mvweb-core' ),
	),
	'item_parts' => array(
		'labels' => __( 'Marks on the photos', 'mvweb-core' ),
		'title'  => __( 'Caption', 'mvweb-core' ),
		'text'   => __( 'Description', 'mvweb-core' ),
		'facts'  => __( 'Facts (card view)', 'mvweb-core' ),
	),
);
