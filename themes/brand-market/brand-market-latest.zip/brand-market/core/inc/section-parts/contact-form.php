<?php
/**
 * Parts of a block type: the request form.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts' => array(
		'title' => __( 'Heading', 'mvweb-core' ),
		'lead'  => __( 'Lead', 'mvweb-core' ),
		'note'  => __( 'Note', 'mvweb-core' ),
		'photo' => __( 'Photo', 'mvweb-core' ),
	),
);
