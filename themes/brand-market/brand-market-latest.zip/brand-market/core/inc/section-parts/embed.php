<?php
/**
 * Parts of a block type: a widget of another plugin.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts' => array(
		'kicker' => __( 'Kicker', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Lead', 'mvweb-core' ),
		'ticker' => __( 'Ribbon', 'mvweb-core' ),
	),
);
