<?php
/**
 * Parts of a block type: photographs with captions.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Text under the heading', 'mvweb-core' ),
		'list'   => __( 'Photographs', 'mvweb-core' ),
		'thumbs' => __( 'Strip of thumbnails', 'mvweb-core' ),
	),
	'item_parts' => array(
		'caption' => __( 'Caption', 'mvweb-core' ),
	),
);
