<?php
/**
 * Parts of a block type: two lists side by side.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker'  => __( 'Kicker', 'mvweb-core' ),
		'title'   => __( 'Heading', 'mvweb-core' ),
		'lead'    => __( 'Lead', 'mvweb-core' ),
		'col_1'   => __( 'First list', 'mvweb-core' ),
		'divider' => __( 'Divider between the lists (one card)', 'mvweb-core' ),
		'col_2'   => __( 'Second list', 'mvweb-core' ),
	),
	'item_parts' => array(
		'mark'  => __( 'Mark before an item', 'mvweb-core' ),
		'count' => __( 'Number of items (large marks, tabs)', 'mvweb-core' ),
	),
);
