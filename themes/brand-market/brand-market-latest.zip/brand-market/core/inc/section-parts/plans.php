<?php
/**
 * Parts of a block type: plans side by side.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Lead', 'mvweb-core' ),
		'switch' => __( 'Monthly or yearly switch', 'mvweb-core' ),
		'list'   => __( 'Plans', 'mvweb-core' ),
	),
	'item_parts' => array(
		'badge'  => __( 'Badge', 'mvweb-core' ),
		'name'   => __( 'Name', 'mvweb-core' ),
		'text'   => __( 'Line under the name', 'mvweb-core' ),
		'price'  => __( 'Price', 'mvweb-core' ),
		'items'  => __( 'What is included', 'mvweb-core' ),
		'button' => __( 'Button', 'mvweb-core' ),
	),
);
