<?php
/**
 * Parts of a block type: a promo banner and a row of products of one department.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts' => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'desc'   => __( 'Text of the banner', 'mvweb-core' ),
		'chips'  => __( 'Links to subsections', 'mvweb-core' ),
		'button' => __( 'Button of the banner', 'mvweb-core' ),
		'pics'   => __( 'Pictures of the banner', 'mvweb-core' ),
		'cards'  => __( 'Row of products', 'mvweb-core' ),
		'arrows' => __( 'Arrows of the row', 'mvweb-core' ),
	),
);
