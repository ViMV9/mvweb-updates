<?php
/**
 * Parts of a block type: what the company is good at.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Kicker', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Lead', 'mvweb-core' ),
		'image'  => __( 'Picture', 'mvweb-core' ),
		'list'   => __( 'Blocks', 'mvweb-core' ),
	),
	'item_parts' => array(
		'icon'  => __( 'Icon', 'mvweb-core' ),
		'num'   => __( 'Number', 'mvweb-core' ),
		'title' => __( 'Heading', 'mvweb-core' ),
		'text'  => __( 'Text', 'mvweb-core' ),
	),
);
