<?php
/**
 * Parts of a block type: one work, wide.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts' => array(
		'gallery' => __( 'Pictures', 'mvweb-core' ),
		'eyebrow' => __( 'Line above the heading', 'mvweb-core' ),
		'name'    => __( 'Heading', 'mvweb-core' ),
		'text'    => __( 'Description', 'mvweb-core' ),
		'facts'   => __( 'Facts', 'mvweb-core' ),
		'prices'  => __( 'Prices', 'mvweb-core' ),
		'link'    => __( 'Link', 'mvweb-core' ),
	),
);
