<?php
/**
 * Parts of a block type: services of the company.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Kicker', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Lead', 'mvweb-core' ),
		'list'   => __( 'Services', 'mvweb-core' ),
		'foot'   => __( 'Link under the list', 'mvweb-core' ),
	),
	'item_parts' => array(
		'icon'  => __( 'Icon', 'mvweb-core' ),
		'image' => __( 'Picture', 'mvweb-core' ),
		'text'  => __( 'Short text', 'mvweb-core' ),
		'price' => __( 'Price', 'mvweb-core' ),
		'go'    => __( 'Arrow', 'mvweb-core' ),
	),
);
