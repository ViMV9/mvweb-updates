<?php
/**
 * Parts of a block type: video reviews.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Lead', 'mvweb-core' ),
		'nav'    => __( 'Arrows', 'mvweb-core' ),
		'list'   => __( 'Video reviews', 'mvweb-core' ),
	),
	'item_parts' => array(
		'duration' => __( 'Length', 'mvweb-core' ),
		'title'    => __( 'Title', 'mvweb-core' ),
		'note'     => __( 'Line under the title', 'mvweb-core' ),
		'text'     => __( 'Description', 'mvweb-core' ),
		'cta'      => __( 'Watch link', 'mvweb-core' ),
	),
);
