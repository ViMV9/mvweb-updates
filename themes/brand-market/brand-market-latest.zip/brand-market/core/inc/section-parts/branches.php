<?php
/**
 * Parts of a block type: the branches of the chosen city.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Lead', 'mvweb-core' ),
		'list'   => __( 'Branches', 'mvweb-core' ),
		'map'    => __( 'Map', 'mvweb-core' ),
	),
	'item_parts' => array(
		'icon'    => __( 'Icon', 'mvweb-core' ),
		'index'   => __( 'Number on the map', 'mvweb-core' ),
		'image'   => __( 'Photo', 'mvweb-core' ),
		'title'   => __( 'Name', 'mvweb-core' ),
		'address' => __( 'Address', 'mvweb-core' ),
		'status'  => __( 'Status', 'mvweb-core' ),
		'hours'   => __( 'Opening hours', 'mvweb-core' ),
		'phone'   => __( 'Phone', 'mvweb-core' ),
		'book'    => __( 'Booking button', 'mvweb-core' ),
		'route'   => __( 'Route button', 'mvweb-core' ),
	),
);
