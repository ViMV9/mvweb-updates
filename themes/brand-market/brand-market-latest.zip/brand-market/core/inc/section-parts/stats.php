<?php
/**
 * Parts of a block type: figures the company stands on.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'title' => __( 'Heading', 'mvweb-core' ),
		'lead'  => __( 'Lead', 'mvweb-core' ),
		'list'  => __( 'Figures', 'mvweb-core' ),
	),
	'item_parts' => array(
		'icon'   => __( 'Icon', 'mvweb-core' ),
		'number' => __( 'Figure', 'mvweb-core' ),
		'label'  => __( 'Caption', 'mvweb-core' ),
	),
);
