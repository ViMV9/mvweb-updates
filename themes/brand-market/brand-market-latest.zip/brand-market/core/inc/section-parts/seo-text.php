<?php
/**
 * Parts of a block type: long text for search.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts' => array(
		'kicker'  => __( 'Kicker', 'mvweb-core' ),
		'title'   => __( 'Heading', 'mvweb-core' ),
		'text'    => __( 'Text', 'mvweb-core' ),
		'spoiler' => __( 'Spoiler button', 'mvweb-core' ),
	),
);
