<?php
/**
 * Parts of a block type: written reviews with the ratings of review sites.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker'  => __( 'Line above the heading', 'mvweb-core' ),
		'title'   => __( 'Heading', 'mvweb-core' ),
		'lead'    => __( 'Lead', 'mvweb-core' ),
		'nav'     => __( 'Arrows', 'mvweb-core' ),
		'ratings' => __( 'Ratings of the sites', 'mvweb-core' ),
		'list'    => __( 'Reviews', 'mvweb-core' ),
	),
	'item_parts' => array(
		'stars'  => __( 'Stars', 'mvweb-core' ),
		'text'   => __( 'Review', 'mvweb-core' ),
		'photo'  => __( 'Photo', 'mvweb-core' ),
		'name'   => __( 'Name', 'mvweb-core' ),
		'source' => __( 'Source and date', 'mvweb-core' ),
	),
);
