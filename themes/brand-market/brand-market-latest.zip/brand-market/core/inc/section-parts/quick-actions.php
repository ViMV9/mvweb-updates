<?php
/**
 * Parts of a block type: quick actions.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Text under the heading', 'mvweb-core' ),
		'list'   => __( 'Actions', 'mvweb-core' ),
	),
	'item_parts' => array(
		'icon' => __( 'Icon', 'mvweb-core' ),
		'note' => __( 'Line under the name', 'mvweb-core' ),
		'go'   => __( 'Arrow', 'mvweb-core' ),
	),
);
