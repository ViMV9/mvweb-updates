<?php
/**
 * Parts of a block type: the latest posts of the blog.
 *
 * The parts «Subcategories» and «Search and frequent topics» come when the theme
 * names them in add_theme_support( 'mvweb-posts-parts', array( 'chips', 'hint' ) ).
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_core_posts_support = get_theme_support( 'mvweb-posts-parts' );
$mvweb_core_posts_wanted  = is_array( $mvweb_core_posts_support ) && isset( $mvweb_core_posts_support[0] ) ? array_map( 'strval', (array) $mvweb_core_posts_support[0] ) : array();
$mvweb_core_posts_extra   = array_intersect_key(
	array(
		'chips' => __( 'Subcategories', 'mvweb-core' ),
		'hint'  => __( 'Search and frequent topics', 'mvweb-core' ),
	),
	array_flip( $mvweb_core_posts_wanted )
);

return array(
	'parts' => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Text under the heading', 'mvweb-core' ),
	) + $mvweb_core_posts_extra + array(
		'more' => __( 'Link to all posts', 'mvweb-core' ),
		'list' => __( 'Posts', 'mvweb-core' ),
	),
);
