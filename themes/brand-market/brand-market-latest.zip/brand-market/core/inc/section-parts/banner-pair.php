<?php
/**
 * Parts of a block type: two promo banners side by side.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'title' => __( 'Heading', 'mvweb-core' ),
		'list'  => __( 'Banners', 'mvweb-core' ),
	),
	'item_parts' => array(
		'kicker'  => __( 'Line above the heading', 'mvweb-core' ),
		'title'   => __( 'Heading of the banner', 'mvweb-core' ),
		'text'    => __( 'Text', 'mvweb-core' ),
		'button'  => __( 'Button', 'mvweb-core' ),
		'pics'    => __( 'Pictures', 'mvweb-core' ),
		'sticker' => __( 'Sticker', 'mvweb-core' ),
		'ticker'  => __( 'Running line', 'mvweb-core' ),
	),
);
