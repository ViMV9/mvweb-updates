<?php
/**
 * Parts of a block type: first screen.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'title'    => __( 'Heading', 'mvweb-core' ),
		'features' => __( 'Short promises', 'mvweb-core' ),
		'button'   => __( 'Button', 'mvweb-core' ),
		'trust'    => __( 'Figures', 'mvweb-core' ),
		'plate'    => __( 'Plate on the photo', 'mvweb-core' ),
	),
	'item_parts' => array(
		'image'   => __( 'Frame', 'mvweb-core' ),
		'number'  => __( 'Figure', 'mvweb-core' ),
		'caption' => __( 'Caption', 'mvweb-core' ),
	),
);
