<?php
/**
 * Parts of a block type: products of the catalogue in cards.
 *
 * The composition of a card is one for the whole site and is set in the
 * Customizer, so the block lists only its own parts.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts' => array(
		'kicker'  => __( 'Line above the heading', 'mvweb-core' ),
		'title'   => __( 'Heading', 'mvweb-core' ),
		'lead'    => __( 'Lead', 'mvweb-core' ),
		'more'    => __( 'Link beside the heading', 'mvweb-core' ),
		'arrows'  => __( 'Arrows of the row', 'mvweb-core' ),
		'chips'   => __( 'Pills of departments', 'mvweb-core' ),
		'list'    => __( 'Cards', 'mvweb-core' ),
		'dots'    => __( 'Dots of the row', 'mvweb-core' ),
		'closing' => __( 'Closing block', 'mvweb-core' ),
	),
);
