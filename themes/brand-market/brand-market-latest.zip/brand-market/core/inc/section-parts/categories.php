<?php
/**
 * Parts of a block type: what the shop sells, in picture cards.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Text under the heading', 'mvweb-core' ),
		'more'   => __( 'Link to all', 'mvweb-core' ),
		'list'   => __( 'Cards', 'mvweb-core' ),
	),
	'item_parts' => array(
		'title' => __( 'Name', 'mvweb-core' ),
		'desc'  => __( 'Description', 'mvweb-core' ),
		'count' => __( 'Line under the name', 'mvweb-core' ),
		'image' => __( 'Picture', 'mvweb-core' ),
	),
);
