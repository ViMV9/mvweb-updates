<?php
/**
 * Parts of a block type: text block.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts' => array(
		'kicker'  => __( 'Kicker', 'mvweb-core' ),
		'title'   => __( 'Heading', 'mvweb-core' ),
		'text'    => __( 'Text', 'mvweb-core' ),
		'image'   => __( 'Picture', 'mvweb-core' ),
		'image_2' => __( 'Second picture', 'mvweb-core' ),
		'badge'   => __( 'Badge over the picture', 'mvweb-core' ),
		'quote'   => __( 'Quote', 'mvweb-core' ),
		'button'  => __( 'Button', 'mvweb-core' ),
	),
);
