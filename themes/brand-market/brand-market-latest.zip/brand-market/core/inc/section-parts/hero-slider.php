<?php
/**
 * Parts of a block type: first screen as a slider of offers.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'arrows' => __( 'Arrows', 'mvweb-core' ),
		'dots'   => __( 'Dots', 'mvweb-core' ),
		'pause'  => __( 'Pause button', 'mvweb-core' ),
	),
	'item_parts' => array(
		'kicker'   => __( 'Line above the heading', 'mvweb-core' ),
		'title'    => __( 'Heading', 'mvweb-core' ),
		'lead'     => __( 'Lead', 'mvweb-core' ),
		'facts'    => __( 'Facts', 'mvweb-core' ),
		'actions'  => __( 'Button and price', 'mvweb-core' ),
		'pics'     => __( 'Pictures', 'mvweb-core' ),
		'products' => __( 'Mini cards of items', 'mvweb-core' ),
	),
);
