<?php
/**
 * Parts of a block type: a call to action.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts' => array(
		'kicker' => __( 'Kicker', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Lead', 'mvweb-core' ),
		'button' => __( 'Button', 'mvweb-core' ),
		'phone'  => __( 'Phone', 'mvweb-core' ),
		'photo'  => __( 'Photo', 'mvweb-core' ),
		'ticker' => __( 'Ribbon', 'mvweb-core' ),
		'second' => __( 'Second half', 'mvweb-core' ),
	),
);
