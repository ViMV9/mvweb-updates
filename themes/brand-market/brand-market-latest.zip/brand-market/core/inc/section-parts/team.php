<?php
/**
 * Parts of a block type: the team.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Text under the heading', 'mvweb-core' ),
		'list'   => __( 'People', 'mvweb-core' ),
	),
	'item_parts' => array(
		'photo'  => __( 'Photo', 'mvweb-core' ),
		'role'   => __( 'Position', 'mvweb-core' ),
		'bio'    => __( 'About', 'mvweb-core' ),
		'button' => __( 'Booking button', 'mvweb-core' ),
	),
);
