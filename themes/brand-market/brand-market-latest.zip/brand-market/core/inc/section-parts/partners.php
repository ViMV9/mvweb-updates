<?php
/**
 * Parts of a block type: partners and documents.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Lead', 'mvweb-core' ),
		'badge'  => __( 'Sign beside the heading', 'mvweb-core' ),
		'list'   => __( 'List', 'mvweb-core' ),
	),
	'item_parts' => array(
		'image'    => __( 'Logo or preview', 'mvweb-core' ),
		'kind'     => __( 'File type and size', 'mvweb-core' ),
		'name'     => __( 'Name', 'mvweb-core' ),
		'arrow'    => __( 'Arrow', 'mvweb-core' ),
		'download' => __( 'Download button', 'mvweb-core' ),
		'note'     => __( 'Note', 'mvweb-core' ),
	),
);
