<?php
/**
 * Parts of a block type: subscription.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts' => array(
		'kicker'  => __( 'Kicker', 'mvweb-core' ),
		'title'   => __( 'Heading', 'mvweb-core' ),
		'lead'    => __( 'Lead', 'mvweb-core' ),
		'points'  => __( 'What the reader gets', 'mvweb-core' ),
		'socials' => __( 'Social networks', 'mvweb-core' ),
		'form'    => __( 'Mailing form', 'mvweb-core' ),
	),
);
