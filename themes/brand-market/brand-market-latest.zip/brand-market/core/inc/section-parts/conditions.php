<?php
/**
 * Parts of a block type: what we treat.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Text under the heading', 'mvweb-core' ),
		'search' => __( 'Search field', 'mvweb-core' ),
		'list'   => __( 'Directions and reasons', 'mvweb-core' ),
		'foot'   => __( 'Link under the list', 'mvweb-core' ),
	),
	'item_parts' => array(
		'icon'     => __( 'Icon', 'mvweb-core' ),
		'note'     => __( 'Line under the name', 'mvweb-core' ),
		'services' => __( 'Main services', 'mvweb-core' ),
		'price'    => __( 'Price of the service', 'mvweb-core' ),
	),
);
