<?php
/**
 * Parts of a block type: works from the portfolio.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts' => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Text under the heading', 'mvweb-core' ),
		'more'   => __( 'Link to all works', 'mvweb-core' ),
		'list'   => __( 'Cards of works', 'mvweb-core' ),
	),
);
