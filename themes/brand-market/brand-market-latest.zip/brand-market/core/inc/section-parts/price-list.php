<?php
/**
 * Parts of a block type: a price list.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Lead', 'mvweb-core' ),
		'list'   => __( 'Prices', 'mvweb-core' ),
		'footer' => __( 'Button and footnote', 'mvweb-core' ),
	),
	'item_parts' => array(
		'icon'    => __( 'Group icon', 'mvweb-core' ),
		'summary' => __( 'Line beside a folded group', 'mvweb-core' ),
		'note'    => __( 'Note under the name', 'mvweb-core' ),
	),
);
