<?php
/**
 * Parts of a block type: the team as a wall of photographs.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker'      => __( 'Line above the heading', 'mvweb-core' ),
		'title'       => __( 'Heading', 'mvweb-core' ),
		'lead'        => __( 'Lead', 'mvweb-core' ),
		'button'      => __( 'Button', 'mvweb-core' ),
		'wall'        => __( 'Photos', 'mvweb-core' ),
		'group_photo' => __( 'Group photo with dots', 'mvweb-core' ),
	),
	'item_parts' => array(
		'image' => __( 'Photo', 'mvweb-core' ),
		'name'  => __( 'Name', 'mvweb-core' ),
		'role'  => __( 'Role', 'mvweb-core' ),
	),
);
