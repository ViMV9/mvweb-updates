<?php
/**
 * Parts of a block type: wide banner.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts' => array(
		'tag'     => __( 'Label', 'mvweb-core' ),
		'title'   => __( 'Heading', 'mvweb-core' ),
		'lead'    => __( 'Lead', 'mvweb-core' ),
		'prices'  => __( 'Prices', 'mvweb-core' ),
		'button'  => __( 'Button', 'mvweb-core' ),
		'until'   => __( 'Last day of the offer', 'mvweb-core' ),
		'sale'    => __( 'Saving', 'mvweb-core' ),
		'sticker' => __( 'Sticker', 'mvweb-core' ),
		'reel'    => __( 'Running line', 'mvweb-core' ),
	),
);
