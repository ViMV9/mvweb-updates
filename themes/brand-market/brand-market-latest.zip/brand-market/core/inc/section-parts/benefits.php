<?php
/**
 * Parts of a block type: what a client gets.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'title'      => __( 'Heading', 'mvweb-core' ),
		'lead'       => __( 'Lead', 'mvweb-core' ),
		'media'      => __( 'Photo', 'mvweb-core' ),
		'card_icon'  => __( 'Card icon', 'mvweb-core' ),
		'card_title' => __( 'Card heading', 'mvweb-core' ),
		'list'       => __( 'Points', 'mvweb-core' ),
	),
	'item_parts' => array(
		'mark'   => __( 'Icon or number', 'mvweb-core' ),
		'name'   => __( 'Short name', 'mvweb-core' ),
		'text'   => __( 'Text', 'mvweb-core' ),
		'figure' => __( 'Figure', 'mvweb-core' ),
	),
);
