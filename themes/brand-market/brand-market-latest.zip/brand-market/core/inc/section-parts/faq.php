<?php
/**
 * Parts of a block type: questions and answers.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Kicker', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Lead', 'mvweb-core' ),
		'button' => __( 'Button', 'mvweb-core' ),
	),
	'item_parts' => array(
		'badge' => __( 'Icon in the tile', 'mvweb-core' ),
		'num'   => __( 'Number in the numbered list', 'mvweb-core' ),
	),
);
