<?php
/**
 * Parts of a block type: boxes on sale.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts'      => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Lead', 'mvweb-core' ),
		'list'   => __( 'Boxes', 'mvweb-core' ),
	),
	'item_parts' => array(
		'image'    => __( 'Picture', 'mvweb-core' ),
		'title'    => __( 'Name', 'mvweb-core' ),
		'text'     => __( 'Description', 'mvweb-core' ),
		'contents' => __( 'What is inside', 'mvweb-core' ),
		'price'    => __( 'Price', 'mvweb-core' ),
		'terms'    => __( 'Until when and how many left', 'mvweb-core' ),
		'button'   => __( 'Button', 'mvweb-core' ),
	),
);
