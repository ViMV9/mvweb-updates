<?php
/**
 * Parts of a block type: the categories of the blog.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'parts' => array(
		'kicker' => __( 'Line above the heading', 'mvweb-core' ),
		'title'  => __( 'Heading', 'mvweb-core' ),
		'lead'   => __( 'Text under the heading', 'mvweb-core' ),
		'more'   => __( 'Link to all posts', 'mvweb-core' ),
		'list'   => __( 'List of categories', 'mvweb-core' ),
	),
);
