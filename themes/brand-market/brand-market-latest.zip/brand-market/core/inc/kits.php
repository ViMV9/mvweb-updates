<?php
/**
 * UI Kit sets of the theme: the owner picks one in the Customizer, the core loads its file after the theme styles.
 *
 * @package MVweb_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_kits' ) ) {
	/**
	 * Sets the theme declares with add_theme_support( 'mvweb-kits', array( key => label ) ); the first one is the theme's own CSS.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,string> Key => label.
	 */
	function mvweb_core_kits() {
		$support = get_theme_support( 'mvweb-kits' );

		if ( ! is_array( $support ) || ! isset( $support[0] ) || ! is_array( $support[0] ) ) {
			return array();
		}

		$kits = array();
		foreach ( $support[0] as $key => $label ) {
			$key = sanitize_key( (string) $key );
			if ( '' !== $key ) {
				$kits[ $key ] = (string) $label;
			}
		}

		return $kits;
	}
}

if ( ! function_exists( 'mvweb_core_kit' ) ) {
	/**
	 * The set the owner picked, or the first one.
	 *
	 * @since 0.1.0
	 *
	 * @return string Empty when the theme has no sets.
	 */
	function mvweb_core_kit() {
		$kits = mvweb_core_kits();

		if ( ! $kits ) {
			return '';
		}

		$kit = (string) get_theme_mod( 'mvweb_kit', '' );

		return isset( $kits[ $kit ] ) ? $kit : (string) array_key_first( $kits );
	}
}

if ( ! function_exists( 'mvweb_core_kit_fields' ) ) {
	/**
	 * Add the set field to «MVweb: Design» when the theme has two sets or more.
	 *
	 * @since 0.1.0
	 *
	 * @param MVweb_Customizer_Kit $kit Kit instance.
	 *
	 * @return void
	 */
	function mvweb_core_kit_fields( $kit ) {
		$kits = mvweb_core_kits();

		if ( count( $kits ) < 2 ) {
			return;
		}

		$kit->add_fields(
			array(
				array(
					'type'        => 'select',
					'settings'    => 'mvweb_kit',
					'section'     => 'mvweb_cz_design_preset',
					'label'       => __( 'UI Kit', 'mvweb-core' ),
					'description' => __( 'Buttons, fields, cards and type of the whole site. The palette is chosen on top of any set.', 'mvweb-core' ),
					'default'     => (string) array_key_first( $kits ),
					'priority'    => 1,
					'choices'     => $kits,
				),
			)
		);
	}
}
add_action( 'mvweb_core_customizer_register', 'mvweb_core_kit_fields' );

if ( ! function_exists( 'mvweb_core_enqueue_kit' ) ) {
	/**
	 * Load assets/kits/{set}/kit.css of the picked set after the theme styles; the first set is the theme's own CSS and has no file.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_enqueue_kit() {
		$kit = mvweb_core_kit();

		if ( '' === $kit || array_key_first( mvweb_core_kits() ) === $kit ) {
			return;
		}

		foreach ( array( '.min.css', '.css' ) as $extension ) {
			$path = 'assets/kits/' . $kit . '/kit' . $extension;
			$file = get_theme_file_path( $path );

			if ( is_file( $file ) ) {
				wp_enqueue_style( 'mvweb-kit', get_theme_file_uri( $path ), array(), (string) filemtime( $file ) );
				return;
			}
		}
	}
}
add_action( 'wp_enqueue_scripts', 'mvweb_core_enqueue_kit', 20 );
