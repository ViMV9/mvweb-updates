<?php
/**
 * Section type: what the shop sells, in picture cards.
 *
 * Two ways to fill it. A hand-made list gives control over the order and lets
 * one card span the full width; product categories fill themselves, so a new
 * category shows up on the front without anyone remembering to add it here.
 * A journal takes the categories of its blog the same way. The look of the
 * cards is the view the theme draws, not a field of the block.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_core_sources = array( 'manual' => __( 'The list below', 'mvweb-core' ) );

if ( mvweb_core_module( 'catalog' ) ) {
	$mvweb_core_sources['product_cat'] = __( 'Product categories', 'mvweb-core' );
}

if ( mvweb_core_module( 'services' ) ) {
	$mvweb_core_sources['service_cat'] = __( 'Service sections', 'mvweb-core' );
}

if ( current_theme_supports( 'mvweb-categories-blog' ) ) {
	$mvweb_core_sources['blog_cat'] = __( 'Blog categories', 'mvweb-core' );
}

$mvweb_core_filled = array_values( array_diff( array_keys( $mvweb_core_sources ), array( 'manual' ) ) );

mvweb_core_register_section(
	'categories',
	array(
		'label'       => __( 'Product groups', 'mvweb-core' ),
		'description' => __( 'Cards leading to catalogue sections', 'mvweb-core' ),
		'category'    => 'catalog',
		'fields'      => array(
			'kicker'    => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'     => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'      => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'link_text' => array(
				'type'        => 'text',
				'label'       => __( 'Link to all', 'mvweb-core' ),
				'description' => __( 'Empty hides the link.', 'mvweb-core' ),
				'default'     => mvweb_core_module( 'catalog' ) ? __( 'All catalogue', 'mvweb-core' ) : __( 'All categories', 'mvweb-core' ),
			),
			'link_url'  => array(
				'type'        => 'url',
				'label'       => __( 'Where the link leads', 'mvweb-core' ),
				'description' => mvweb_core_module( 'catalog' ) ? __( 'Empty leads to the catalogue, or to the services for service sections.', 'mvweb-core' ) : __( 'Empty leads to the blog, or to the sitemap when the site has no blog page.', 'mvweb-core' ),
			),
			'source'    => array(
				'type'    => 'select',
				'label'   => __( 'What to show', 'mvweb-core' ),
				'choices' => $mvweb_core_sources,
				'default' => 'manual',
			),
			'count'     => array(
				'type'        => 'number',
				'label'       => __( 'How many categories', 'mvweb-core' ),
				'description' => __( 'Top level only. Used when the cards are filled in on their own.', 'mvweb-core' ),
				'default'     => 6,
				'min'         => 1,
				'max'         => 24,
				'show_when'   => array(
					'field' => 'source',
					'in'    => $mvweb_core_filled,
				),
			),
			'cards'     => array(
				'type'      => 'repeat',
				'label'     => __( 'Cards', 'mvweb-core' ),
				'max'       => 12,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'manual' ),
				),
				'fields'    => array(
					'image'           => array(
						'type'  => 'image',
						'label' => __( 'Picture', 'mvweb-core' ),
					),
					'image_2'         => array(
						'type'        => 'image',
						'label'       => __( 'Second picture', 'mvweb-core' ),
						'description' => __( 'Shown beside the first one on the full width card of the mosaic.', 'mvweb-core' ),
					),
					'icon'            => array(
						'type'        => 'icon',
						'label'       => __( 'Icon', 'mvweb-core' ),
						'description' => __( 'Name from the theme sprite. The views with icons show it instead of the picture.', 'mvweb-core' ),
						'on_demand'   => true,
					),
					'title'           => array(
						'type'  => 'text',
						'label' => __( 'Card heading', 'mvweb-core' ),
					),
					'text'            => array(
						'type'        => 'textarea',
						'label'       => __( 'Short description', 'mvweb-core' ),
						'description' => __( 'The full width card of the mosaic shows it.', 'mvweb-core' ),
					),
					'note'            => array(
						'type'        => 'text',
						'label'       => __( 'Line under the heading', 'mvweb-core' ),
						'description' => __( 'For example: 248 items. Cards filled in on their own count their items themselves.', 'mvweb-core' ),
					),
					'url'             => array(
						'type'  => 'url',
						'label' => __( 'Address', 'mvweb-core' ),
					),
					'size'            => array(
						'type'        => 'select',
						'label'       => __( 'Card size', 'mvweb-core' ),
						'description' => __( 'The mosaic gives a full width card twice the room.', 'mvweb-core' ),
						'default'     => 'normal',
						'choices'     => array(
							'normal' => __( 'Half the width', 'mvweb-core' ),
							'wide'   => __( 'Full width', 'mvweb-core' ),
						),
					),
					'bg'              => array(
						'type'        => 'color',
						'label'       => __( 'Background colour', 'mvweb-core' ),
						'description' => __( '“As the theme has it”: a full width card is dark, the others are white and soft accent in turn. The ready colours follow the palette and the dark scheme. The text turns black or white, whichever reads better.', 'mvweb-core' ),
					),
					'pattern'         => array(
						'type'        => 'select',
						'label'       => __( 'Pattern over the background', 'mvweb-core' ),
						'description' => __( 'Mosaic only. A ready pattern takes the colour of the card text, so it shows on light and dark cards alike.', 'mvweb-core' ),
						'default'     => '',
						'choices'     => array(
							''         => __( 'No pattern', 'mvweb-core' ),
							'dots'     => __( 'Polka dots', 'mvweb-core' ),
							'grid'     => __( 'Grid', 'mvweb-core' ),
							'lines'    => __( 'Diagonal lines', 'mvweb-core' ),
							'waves'    => __( 'Waves', 'mvweb-core' ),
							'zigzag'   => __( 'Zigzag', 'mvweb-core' ),
							'plus'     => __( 'Crosses', 'mvweb-core' ),
							'diamonds' => __( 'Diamonds', 'mvweb-core' ),
							'rings'    => __( 'Rings', 'mvweb-core' ),
							'floral'   => __( 'Floral ornament', 'mvweb-core' ),
							'vignette' => __( 'Vignette, soft edges', 'mvweb-core' ),
							'own'      => __( 'Own picture', 'mvweb-core' ),
						),
					),
					'pattern_image'   => array(
						'type'        => 'image',
						'label'       => __( 'Picture of the pattern', 'mvweb-core' ),
						'description' => __( 'A seamless tile in PNG, SVG or JPG; it keeps its own colours and shows at its own size.', 'mvweb-core' ),
						'show_when'   => array(
							'field' => 'pattern',
							'in'    => array( 'own' ),
						),
					),
					'pattern_repeat'  => array(
						'type'      => 'select',
						'label'     => __( 'How the pattern repeats', 'mvweb-core' ),
						'default'   => 'repeat',
						'choices'   => array(
							'repeat'    => __( 'Tiles over the whole card', 'mvweb-core' ),
							'repeat-x'  => __( 'A band across', 'mvweb-core' ),
							'repeat-y'  => __( 'A band down', 'mvweb-core' ),
							'no-repeat' => __( 'Once in the middle', 'mvweb-core' ),
							'cover'     => __( 'Stretched over the card', 'mvweb-core' ),
						),
						'show_when' => array(
							'field' => 'pattern',
							'in'    => array( 'dots', 'grid', 'lines', 'waves', 'zigzag', 'plus', 'diamonds', 'rings', 'floral', 'own' ),
						),
					),
					'pattern_opacity' => array(
						'type'        => 'number',
						'label'       => __( 'Visibility of the pattern, %', 'mvweb-core' ),
						'description' => __( '100 is the pattern at full strength, 10 is barely there.', 'mvweb-core' ),
						'default'     => 15,
						'min'         => 5,
						'max'         => 100,
						'show_when'   => array(
							'field' => 'pattern',
							'in'    => array( 'dots', 'grid', 'lines', 'waves', 'zigzag', 'plus', 'diamonds', 'rings', 'floral', 'vignette', 'own' ),
						),
					),
				),
			),
		),
	)
);

unset( $mvweb_core_sources, $mvweb_core_filled );
