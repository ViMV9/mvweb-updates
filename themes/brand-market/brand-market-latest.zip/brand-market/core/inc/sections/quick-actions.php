<?php
/**
 * Section type: quick actions.
 *
 * A few big ways to act right under the first screen: book, call a doctor to
 * the house, ask online. Each action has an icon, a name, a line under it and a
 * link; #request in the link opens the request window. The first action may
 * stand out. The look is a view of the theme.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'quick-actions',
	array(
		'label'       => __( 'Quick actions', 'mvweb-core' ),
		'description' => __( 'Big buttons with an icon: book, call, ask online', 'mvweb-core' ),
		'category'    => 'intro',
		'fields'      => mvweb_core_section_head_fields() + array(
			'highlight' => array(
				'type'        => 'toggle',
				'label'       => __( 'First action stands out', 'mvweb-core' ),
				'description' => __( 'The first row takes the colour of the accent; the view with one large action makes it the large one.', 'mvweb-core' ),
				'default'     => true,
			),
			'items'     => array(
				'type'        => 'repeat',
				'label'       => __( 'Actions', 'mvweb-core' ),
				'description' => __( 'A link to #request opens the request window.', 'mvweb-core' ),
				'max'         => 8,
				'fields'      => array(
					'icon'   => array(
						'type'        => 'icon',
						'label'       => __( 'Icon', 'mvweb-core' ),
						'description' => __( 'Name from the theme sprite, for example calendar or phone.', 'mvweb-core' ),
					),
					'title'  => array(
						'type'  => 'text',
						'label' => __( 'Name', 'mvweb-core' ),
					),
					'note'   => array(
						'type'        => 'text',
						'label'       => __( 'Line under the name', 'mvweb-core' ),
						'description' => __( 'Some views do not show it.', 'mvweb-core' ),
					),
					'button' => array(
						'type'        => 'text',
						'label'       => __( 'Button label', 'mvweb-core' ),
						'description' => __( 'The large action shows it on its button.', 'mvweb-core' ),
						'on_demand'   => true,
					),
					'url'    => array(
						'type'  => 'url',
						'label' => __( 'Link', 'mvweb-core' ),
					),
				),
			),
		),
	)
);
