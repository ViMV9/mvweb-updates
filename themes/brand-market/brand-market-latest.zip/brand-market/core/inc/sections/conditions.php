<?php
/**
 * Section type: what we treat.
 *
 * Directions of the clinic or body zones with a link, the number of services or
 * a line and, in some views, the main services with the price from; reasons to
 * come ("it hurts", "I want to improve") with links to the right place. The
 * directions are filled in by hand or taken from the sections of the services.
 * The look, and whether the directions, the reasons or a search is shown, is a
 * view of the theme.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'conditions',
	array(
		'label'       => __( 'What we treat', 'mvweb-core' ),
		'description' => __( 'Directions, reasons to come and body zones with links to the services', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => mvweb_core_section_head_fields() + array(
			'source'             => array(
				'type'    => 'select',
				'label'   => __( 'Directions', 'mvweb-core' ),
				'choices' => array(
					'manual'      => __( 'The list below', 'mvweb-core' ),
					'service_cat' => __( 'Service sections', 'mvweb-core' ),
				),
				'default' => 'manual',
			),
			'count'              => array(
				'type'        => 'number',
				'label'       => __( 'How many', 'mvweb-core' ),
				'description' => __( 'Sections of the services to show, with the number of their services.', 'mvweb-core' ),
				'default'     => 8,
				'min'         => 1,
				'max'         => 24,
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'service_cat' ),
				),
			),
			'directions'         => array(
				'type'        => 'repeat',
				'label'       => __( 'Directions or body zones', 'mvweb-core' ),
				'description' => __( 'The views with services under a direction, with zones or with a search take them from here.', 'mvweb-core' ),
				'max'         => 24,
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'manual' ),
				),
				'fields'      => array(
					'icon'     => array(
						'type'        => 'icon',
						'label'       => __( 'Icon', 'mvweb-core' ),
						'description' => __( 'Name from the theme sprite, for example tooth or joint.', 'mvweb-core' ),
					),
					'title'    => array(
						'type'  => 'text',
						'label' => __( 'Name', 'mvweb-core' ),
					),
					'note'     => array(
						'type'        => 'text',
						'label'       => __( 'Line under the name', 'mvweb-core' ),
						'description' => __( 'For example the number of services: 24 services.', 'mvweb-core' ),
					),
					'url'      => array(
						'type'  => 'url',
						'label' => __( 'Link', 'mvweb-core' ),
					),
					'services' => array(
						'type'        => 'repeat',
						'label'       => __( 'Main services', 'mvweb-core' ),
						'description' => __( 'Shown under the direction or beside the zone in the views that have room for them.', 'mvweb-core' ),
						'max'         => 12,
						'fields'      => array(
							'title' => array(
								'type'  => 'text',
								'label' => __( 'Service', 'mvweb-core' ),
							),
							'price' => array(
								'type'        => 'text',
								'label'       => __( 'Price', 'mvweb-core' ),
								'description' => __( 'The number with the unit, for example 3 000 ₽.', 'mvweb-core' ),
							),
							'url'   => array(
								'type'  => 'url',
								'label' => __( 'Link', 'mvweb-core' ),
							),
						),
					),
				),
			),
			'situations'         => array(
				'type'        => 'repeat',
				'label'       => __( 'Reasons to come', 'mvweb-core' ),
				'description' => __( 'Groups of short reasons, each with a link to the right service or doctor.', 'mvweb-core' ),
				'max'         => 6,
				'fields'      => array(
					'icon'  => array(
						'type'  => 'icon',
						'label' => __( 'Icon of the group', 'mvweb-core' ),
					),
					'title' => array(
						'type'        => 'text',
						'label'       => __( 'Group', 'mvweb-core' ),
						'description' => __( 'For example: It hurts or bothers.', 'mvweb-core' ),
					),
					'links' => array(
						'type'   => 'repeat',
						'label'  => __( 'Reasons', 'mvweb-core' ),
						'max'    => 16,
						'fields' => array(
							'title' => array(
								'type'  => 'text',
								'label' => __( 'Reason', 'mvweb-core' ),
							),
							'url'   => array(
								'type'  => 'url',
								'label' => __( 'Link', 'mvweb-core' ),
							),
						),
					),
				),
			),
			'search_placeholder' => array(
				'type'        => 'text',
				'label'       => __( 'Hint in the search field', 'mvweb-core' ),
				'description' => __( 'The view with a search by direction shows it.', 'mvweb-core' ),
				'default'     => __( 'Find a direction', 'mvweb-core' ),
			),
			'search_empty'       => array(
				'type'        => 'text',
				'label'       => __( 'Text when nothing is found', 'mvweb-core' ),
				'description' => __( 'The view with a search by direction shows it.', 'mvweb-core' ),
				'default'     => __( 'There is no such direction. Call us, the administrator will tell you which doctor to book.', 'mvweb-core' ),
			),
			'link_text'          => array(
				'type'    => 'text',
				'label'   => __( 'Link under the list', 'mvweb-core' ),
				'default' => __( 'All services', 'mvweb-core' ),
			),
			'link_url'           => array(
				'type'  => 'url',
				'label' => __( 'Where that link leads', 'mvweb-core' ),
			),
		),
	)
);
