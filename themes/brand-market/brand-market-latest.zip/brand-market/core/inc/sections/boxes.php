<?php
/**
 * Section type: boxes on sale.
 *
 * A box is a grouped product sold whole with a discount (inc/entities/boxes.php).
 * The block shows the boxes on sale now, chosen by hand or all of them; a box
 * whose sale ended, whose purchases ran out or whose product is out of stock
 * is left out. The theme draws one box as a banner and several as cards.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) || ! mvweb_core_is_woocommerce() ) {
	return;
}

mvweb_core_register_section(
	'boxes',
	array(
		'label'       => __( 'Boxes', 'mvweb-core' ),
		'description' => __( 'Sets of products with a discount on the whole box', 'mvweb-core' ),
		'category'    => 'catalog',
		'fields'      => array(
			'kicker' => array(
				'group' => __( 'Heading', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'  => array(
				'group' => __( 'Heading', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'   => array(
				'group' => __( 'Heading', 'mvweb-core' ),
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'source' => array(
				'group'   => __( 'Which boxes', 'mvweb-core' ),
				'type'    => 'select',
				'label'   => __( 'Which boxes', 'mvweb-core' ),
				'choices' => array(
					'all'    => __( 'Every box on sale', 'mvweb-core' ),
					'manual' => __( 'Chosen by hand', 'mvweb-core' ),
				),
				'default' => 'all',
			),
			'items'  => array(
				'group'       => __( 'Which boxes', 'mvweb-core' ),
				'type'        => 'repeat',
				'label'       => __( 'Boxes', 'mvweb-core' ),
				'description' => __( 'A box whose sale is over is not shown.', 'mvweb-core' ),
				'max'         => 6,
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'manual' ),
				),
				'fields'      => array(
					'item'        => array(
						'type'  => 'item',
						'label' => _x( 'Box', 'set of products', 'mvweb-core' ),
					),
					'badge'       => array(
						'type'        => 'select',
						'label'       => __( 'Discount badge', 'mvweb-core' ),
						'description' => __( 'On the edge of the box card. The badge shows the discount of the box as it is set: in per cent or as a sum. A box without a discount has no badge.', 'mvweb-core' ),
						'choices'     => mvweb_core_box_badge_places(),
						'default'     => '',
					),
					'badge_shape' => array(
						'type'      => 'select',
						'label'     => __( 'Badge shape', 'mvweb-core' ),
						'choices'   => mvweb_core_box_badge_shapes(),
						'default'   => 'pill',
						'show_when' => array(
							'field' => 'badge',
							'in'    => array( 'top-start', 'top-end', 'bottom-start', 'bottom-end' ),
						),
					),
					'badge_bg'    => array(
						'type'        => 'color',
						'alpha'       => true,
						'label'       => __( 'Badge colour', 'mvweb-core' ),
						'description' => __( '“As the theme has it” is the accent colour.', 'mvweb-core' ),
						'show_when'   => array(
							'field' => 'badge',
							'in'    => array( 'top-start', 'top-end', 'bottom-start', 'bottom-end' ),
						),
					),
					'badge_ink'   => array(
						'type'        => 'color',
						'label'       => __( 'Badge text colour', 'mvweb-core' ),
						'description' => __( 'Empty: black or white, whichever reads better.', 'mvweb-core' ),
						'show_when'   => array(
							'field' => 'badge',
							'in'    => array( 'top-start', 'top-end', 'bottom-start', 'bottom-end' ),
						),
					),
				),
			),
			'count'  => array(
				'group'     => __( 'Which boxes', 'mvweb-core' ),
				'type'      => 'number',
				'label'     => __( 'How many', 'mvweb-core' ),
				'default'   => 3,
				'min'       => 1,
				'max'       => 6,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'all' ),
				),
			),
			'button' => array(
				'group'       => __( 'Which boxes', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Button', 'mvweb-core' ),
				'placeholder' => __( 'Buy the box', 'mvweb-core' ),
			),
		),
	)
);
