<?php
/**
 * Section type: how the work is done, step by step.
 *
 * One list of steps; the view sets how it is drawn: cards with a photo, cards
 * with numbers, a timeline, stairs, large numbers in rows.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_core_register_section(
	'steps',
	array(
		'label'       => __( 'Stages', 'mvweb-core' ),
		'description' => __( 'Stages with photos or numbers', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => array(
			'kicker'       => array(
				'type'      => 'text',
				'label'     => __( 'Line above the heading', 'mvweb-core' ),
				'on_demand' => true,
			),
			'title'        => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'         => array(
				'type'  => 'textarea',
				'label' => __( 'Lead', 'mvweb-core' ),
			),
			'items'        => array(
				'type'   => 'repeat',
				'label'  => __( 'Steps', 'mvweb-core' ),
				'max'    => 8,
				'fields' => array(
					'image' => array(
						'type'        => 'image',
						'label'       => __( 'Photo', 'mvweb-core' ),
						'description' => __( 'The first view only.', 'mvweb-core' ),
					),
					'title' => array(
						'type'  => 'text',
						'label' => __( 'Step heading', 'mvweb-core' ),
					),
					'icon'  => array(
						'type'        => 'icon',
						'label'       => __( 'Icon', 'mvweb-core' ),
						'description' => __( 'Name from the theme sprite. Views with icons show it in place of the number.', 'mvweb-core' ),
						'on_demand'   => true,
					),
					'term'  => array(
						'type'        => 'text',
						'label'       => __( 'Duration', 'mvweb-core' ),
						'description' => __( 'For example: 40 minutes.', 'mvweb-core' ),
						'on_demand'   => true,
					),
					'text'  => array(
						'type'  => 'textarea',
						'label' => __( 'Text', 'mvweb-core' ),
					),
				),
			),
			'link_text'    => array(
				'type'      => 'text',
				'label'     => __( 'Link label', 'mvweb-core' ),
				'on_demand' => true,
			),
			'link_url'     => array(
				'type'      => 'url',
				'label'     => __( 'Link', 'mvweb-core' ),
				'on_demand' => true,
			),
			'number_color' => array(
				'type'        => 'color',
				'look'        => true,
				'label'       => __( 'Colour of the step numbers', 'mvweb-core' ),
				'description' => __( 'The plate under the number; the figure on it turns black or white, whichever reads better.', 'mvweb-core' ),
			),
		),
	)
);
