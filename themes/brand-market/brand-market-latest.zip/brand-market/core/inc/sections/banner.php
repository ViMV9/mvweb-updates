<?php
/**
 * Section type: wide banner with one link.
 *
 * Filled in with two prices and a closing date, the banner turns into an
 * offer: it shows the old price struck through and hides itself the day after
 * the date.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_banner_ad_fields' ) ) {
	/**
	 * Fields of the advertiser and of the token of the advertising, for a theme that prints the label.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>> Empty without the support of the theme.
	 */
	function mvweb_core_banner_ad_fields() {
		if ( ! current_theme_supports( 'mvweb-ad-label' ) ) {
			return array();
		}

		return array(
			'advertiser' => array(
				'group'       => __( 'Advertising', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Advertiser', 'mvweb-core' ),
				'description' => __( 'Name and tax number of the advertiser, as in the register of the advertising. Fill in for a banner that is advertising.', 'mvweb-core' ),
			),
			'erid'       => array(
				'group'       => __( 'Advertising', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Token of the advertising (erid)', 'mvweb-core' ),
				'description' => __( 'Given by the operator of the advertising data. Leave both fields empty for a banner that is not advertising.', 'mvweb-core' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_banner_second_button_fields' ) ) {
	/**
	 * Fields of a second button beside the first one, for a theme with a view that prints it.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>> Empty without the support of the theme.
	 */
	function mvweb_core_banner_second_button_fields() {
		if ( ! current_theme_supports( 'mvweb-banner-second-button' ) ) {
			return array();
		}

		return array(
			'button2_text' => array(
				'group' => __( 'Text and button', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Second button label', 'mvweb-core' ),
			),
			'button2_url'  => array(
				'group'       => __( 'Text and button', 'mvweb-core' ),
				'type'        => 'url',
				'label'       => __( 'Second button link', 'mvweb-core' ),
				'description' => __( 'Leave empty to hide the second button.', 'mvweb-core' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_ad_label' ) ) {
	/**
	 * The line that marks a banner as advertising: «Advertisement, advertiser …, erid …».
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $props Values of the block: advertiser, erid.
	 *
	 * @return string Plain text, to be escaped on output; empty while both fields are empty.
	 */
	function mvweb_core_ad_label( array $props ) {
		$advertiser = isset( $props['advertiser'] ) ? trim( sanitize_text_field( (string) $props['advertiser'] ) ) : '';
		$erid       = isset( $props['erid'] ) ? (string) preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $props['erid'] ) : '';
		$label      = array( __( 'Advertisement', 'mvweb-core' ) );

		if ( '' === $advertiser && '' === $erid ) {
			return '';
		}

		if ( '' !== $advertiser ) {
			$label[] = sprintf(
				/* translators: %s: name of the advertiser. */
				__( 'advertiser %s', 'mvweb-core' ),
				$advertiser
			);
		}

		if ( '' !== $erid ) {
			$label[] = sprintf(
				/* translators: %s: token of the advertising. */
				__( 'erid %s', 'mvweb-core' ),
				$erid
			);
		}

		return implode( ', ', $label );
	}
}

mvweb_core_register_section(
	'banner',
	array(
		'label'       => __( 'Wide banner', 'mvweb-core' ),
		'description' => __( 'A photo across the page with a line of text', 'mvweb-core' ),
		'category'    => 'intro',
		'fields'      => array(
			'image'       => array(
				'group'       => __( 'Picture', 'mvweb-core' ),
				'type'        => 'image',
				'label'       => __( 'Picture', 'mvweb-core' ),
				'description' => __( 'The background, or the picture beside the text where the view has one.', 'mvweb-core' ),
				'side'        => 'end',
				'default'     => 0,
			),
			'tag'         => array(
				'group'       => __( 'Text and button', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Label above the heading', 'mvweb-core' ),
				'description' => __( 'A short word in a pill, for example: New.', 'mvweb-core' ),
			),
			'title'       => array(
				'group' => __( 'Text and button', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'        => array(
				'group' => __( 'Text and button', 'mvweb-core' ),
				'type'  => 'textarea',
				'label' => __( 'Lead', 'mvweb-core' ),
			),
			'button_text' => array(
				'group' => __( 'Text and button', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Button label', 'mvweb-core' ),
			),
			'button_url'  => array(
				'group'       => __( 'Text and button', 'mvweb-core' ),
				'type'        => 'url',
				'label'       => __( 'Button link', 'mvweb-core' ),
				'description' => __( 'Leave empty to hide the button.', 'mvweb-core' ),
			),
		) + mvweb_core_banner_second_button_fields() + array(
			'price_new'    => array(
				'group' => __( 'Offer', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Price', 'mvweb-core' ),
			),
			'price_old'    => array(
				'group'       => __( 'Offer', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Old price, struck through', 'mvweb-core' ),
				'description' => __( 'The saving is counted from the two prices.', 'mvweb-core' ),
			),
			'until'        => array(
				'group'       => __( 'Offer', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Last day of the offer', 'mvweb-core' ),
				'description' => __( 'In the form 2026-10-31. The next day the banner hides itself.', 'mvweb-core' ),
			),
			'sale_label'   => array(
				'group'   => __( 'Offer', 'mvweb-core' ),
				'type'    => 'text',
				'label'   => __( 'Caption of the saving', 'mvweb-core' ),
				'default' => __( 'Saving on the offer', 'mvweb-core' ),
			),
			'sticker_num'  => array(
				'group'       => __( 'Sticker and running line', 'mvweb-core' ),
				'type'        => 'text',
				'label'       => __( 'Sticker, figure', 'mvweb-core' ),
				'description' => __( 'A round sticker on the picture, for example: 24. Empty hides it.', 'mvweb-core' ),
			),
			'sticker_text' => array(
				'group' => __( 'Sticker and running line', 'mvweb-core' ),
				'type'  => 'text',
				'label' => __( 'Sticker, caption', 'mvweb-core' ),
			),
			'ticker'       => array(
				'group'       => __( 'Sticker and running line', 'mvweb-core' ),
				'type'        => 'textarea',
				'label'       => __( 'Running line', 'mvweb-core' ),
				'description' => __( 'One item per line. Empty takes the heading, the prices and the last day of the offer.', 'mvweb-core' ),
			),
		) + mvweb_core_banner_ad_fields(),
	)
);
