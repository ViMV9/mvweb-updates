<?php
/**
 * Section type: first screen as a slider of offers.
 *
 * Every slide is a small offer of its own: a line above the heading, the
 * heading, a lead, a few facts, a button with a price, pictures that the
 * view lays out as it draws them, and a few items of the catalogue for the
 * views with mini cards. All slides sit in one cell of a grid, so the block
 * never changes height when the slide changes.
 *
 * The heading of a slide is the only one of the block. Which tag it takes is
 * the editor's call: the first screen of a shop usually needs an h1, a second
 * slider further down the page does not.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_hero_slider_posts_on' ) ) {
	/**
	 * Whether the slider may take its slides from the posts.
	 *
	 * @since 0.1.0
	 *
	 * @return bool
	 */
	function mvweb_core_hero_slider_posts_on() {
		return current_theme_supports( 'mvweb-hero-slider-posts' );
	}
}

if ( ! function_exists( 'mvweb_core_hero_slider_fields' ) ) {
	/**
	 * Fields of the slides taken from the posts and of the autoplay.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>> Empty while the theme has not asked for the posts.
	 */
	function mvweb_core_hero_slider_fields() {
		if ( ! mvweb_core_hero_slider_posts_on() ) {
			return array();
		}

		$when = array(
			'field' => 'source',
			'in'    => array( 'posts', 'mixed' ),
		);

		return array(
			'source'   => array(
				'type'    => 'select',
				'label'   => __( 'Where the slides come from', 'mvweb-core' ),
				'choices' => array(
					'manual' => __( 'Made by hand', 'mvweb-core' ),
					'posts'  => __( 'Taken from the posts', 'mvweb-core' ),
					'mixed'  => __( 'By hand first, then from the posts', 'mvweb-core' ),
				),
				'default' => 'manual',
			),
			'category' => array(
				'type'        => 'category',
				'label'       => __( 'Category of the posts', 'mvweb-core' ),
				'description' => __( 'Empty takes the latest posts of the whole blog.', 'mvweb-core' ),
				'default'     => 0,
				'show_when'   => $when,
			),
			'children' => array(
				'type'      => 'toggle',
				'label'     => __( 'With the posts of the subcategories', 'mvweb-core' ),
				'default'   => true,
				'show_when' => $when,
			),
			'pinned'   => array(
				'type'        => 'text',
				'label'       => __( 'Posts chosen by hand', 'mvweb-core' ),
				'description' => __( 'Numbers of the posts separated by commas, in the order of showing. They stand before the latest posts. The number is in the address of the post editor: post=123.', 'mvweb-core' ),
				'show_when'   => $when,
			),
			'count'    => array(
				'type'        => 'number',
				'label'       => __( 'How many slides in all', 'mvweb-core' ),
				'description' => __( 'The slides made by hand come first, the posts fill the rest.', 'mvweb-core' ),
				'min'         => 1,
				'max'         => 12,
				'default'     => 5,
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'mixed', 'posts' ),
				),
			),
			'autoplay' => array(
				'type'        => 'toggle',
				'label'       => __( 'Change the slides by themselves', 'mvweb-core' ),
				'description' => __( 'Off by default. Visitors who asked for less motion never get it.', 'mvweb-core' ),
				'default'     => false,
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_hero_slider_manual' ) ) {
	/**
	 * Whether the slides wait for the visitor: the template prints data-manual then.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $props Values of the block.
	 * @param string[]            $parts Parts of the block that are on.
	 *
	 * @return bool
	 */
	function mvweb_core_hero_slider_manual( array $props, array $parts ) {
		if ( mvweb_core_hero_slider_posts_on() ) {
			return empty( $props['autoplay'] );
		}

		return ! in_array( 'pause', $parts, true );
	}
}

if ( ! function_exists( 'mvweb_core_hero_slider_post_slide' ) ) {
	/**
	 * A slide made of a post: the category above the heading, the words before the colon in the accent, the minutes of reading as the fact, the thumbnail.
	 *
	 * @since 0.1.0
	 *
	 * @param WP_Post $post Post.
	 *
	 * @return array<string,mixed> The keys of a slide made by hand, with the post and its thumbnail (image).
	 */
	function mvweb_core_hero_slider_post_slide( $post ) {
		$title   = trim( str_replace( '*', '', wp_strip_all_tags( get_the_title( $post ) ) ) );
		$cut     = strpos( $title, ':' );
		$cats    = get_the_category( $post->ID );
		$minutes = mvweb_core_reading_minutes( $post->ID );
		$image   = (int) get_post_thumbnail_id( $post );
		$url     = (string) get_permalink( $post );

		return array(
			'post'        => (int) $post->ID,
			'kicker'      => $cats ? $cats[0]->name : '',
			'title'       => $title,
			'accent_word' => false !== $cut && $cut > 0 ? trim( substr( $title, 0, $cut ) ) : '',
			'text'        => wp_trim_words( wp_strip_all_tags( get_the_excerpt( $post ) ), 28 ),
			'facts'       => $minutes > 0 ? sprintf(
				/* translators: %s: number of minutes. */
				__( '%s min read', 'mvweb-core' ),
				number_format_i18n( $minutes )
			) : '',
			'button_text' => __( 'Read the post', 'mvweb-core' ),
			'button_url'  => $url,
			'link'        => $url,
			'image'       => $image,
			'photo'       => $image,
			'image_2'     => $image,
		);
	}
}

if ( ! function_exists( 'mvweb_core_hero_slider_slides' ) ) {
	/**
	 * The slides of the block in print order: made by hand first, then the pinned posts, then the latest posts of the category.
	 *
	 * @since 0.1.0
	 *
	 * @param array<string,mixed> $props Values of the block.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	function mvweb_core_hero_slider_slides( array $props ) {
		$rows   = isset( $props['slides'] ) && is_array( $props['slides'] ) ? mvweb_core_visible_rows( $props['slides'] ) : array();
		$source = isset( $props['source'] ) ? (string) $props['source'] : 'manual';

		if ( ! mvweb_core_hero_slider_posts_on() || ! in_array( $source, array( 'posts', 'mixed' ), true ) ) {
			return $rows;
		}

		$count = min( 12, max( 1, isset( $props['count'] ) ? absint( $props['count'] ) : 5 ) );
		$rows  = 'posts' === $source ? array() : array_slice( $rows, 0, $count );
		$need  = $count - count( $rows );

		if ( $need < 1 ) {
			return $rows;
		}

		$pinned   = array_values( array_filter( array_map( 'absint', wp_parse_id_list( isset( $props['pinned'] ) ? (string) $props['pinned'] : '' ) ) ) );
		$category = isset( $props['category'] ) ? absint( $props['category'] ) : 0;
		$exact    = $category > 0 && isset( $props['children'] ) && ! $props['children'];
		$posts    = array();
		$query    = empty( $pinned ) ? null : mvweb_core_posts_query(
			array(
				'source' => 'ids',
				'ids'    => implode( ',', $pinned ),
			),
			$need
		);

		if ( $query ) {
			$posts = $query->posts;
		}

		if ( count( $posts ) < $need ) {
			$query = mvweb_core_posts_query(
				array(
					'source'   => 'latest',
					'category' => $category,
				),
				$exact ? min( 40, $need * 4 ) : $need,
				$pinned
			);

			foreach ( $query ? $query->posts : array() as $post ) {
				if ( ! $exact || in_array( $category, array_map( 'absint', wp_get_post_categories( $post->ID ) ), true ) ) {
					$posts[] = $post;
				}
			}
		}

		foreach ( array_slice( $posts, 0, $need ) as $post ) {
			$rows[] = mvweb_core_hero_slider_post_slide( $post );
		}

		return $rows;
	}
}

mvweb_core_register_section(
	'hero-slider',
	array(
		'label'       => __( 'First screen: slider of offers', 'mvweb-core' ),
		'description' => __( 'Slides with a heading, facts, a button and pictures', 'mvweb-core' ),
		'category'    => 'intro',
		'fields'      => mvweb_core_hero_slider_fields() + array(
			'slide_interval' => array(
				'type'        => 'number',
				'label'       => __( 'Seconds per slide', 'mvweb-core' ),
				'description' => mvweb_core_hero_slider_posts_on() ? __( 'Used while the slides change by themselves.', 'mvweb-core' ) : __( 'Slides change by themselves only while the pause button is shown.', 'mvweb-core' ),
				'min'         => 3,
				'max'         => 30,
				'default'     => 6,
			),
			'slide_effect'   => array(
				'type'    => 'select',
				'label'   => __( 'How the slides change', 'mvweb-core' ),
				'choices' => array(
					'fade'  => __( 'Cross-fade', 'mvweb-core' ),
					'zoom'  => __( 'Cross-fade with a slow zoom', 'mvweb-core' ),
					'slide' => __( 'Slide in from the side', 'mvweb-core' ),
					'scale' => __( 'Settle in from close up', 'mvweb-core' ),
				),
				'default' => 'fade',
			),
			'slides'         => array(
				'type'      => 'repeat',
				'label'     => __( 'Slides', 'mvweb-core' ),
				'max'       => 6,
				'show_when' => mvweb_core_hero_slider_posts_on() ? array(
					'field' => 'source',
					'in'    => array( 'manual', 'mixed' ),
				) : array(),
				'fields'    => array(
					'kicker'       => array(
						'type'  => 'text',
						'label' => __( 'Line above the heading', 'mvweb-core' ),
					),
					'title'        => array(
						'type'        => 'text',
						'label'       => __( 'Heading', 'mvweb-core' ),
						'description' => __( 'Words between asterisks, *like this*, take the accent colour.', 'mvweb-core' ),
					),
					'accent_word'  => array(
						'type'        => 'text',
						'label'       => __( 'Word in the heading to highlight', 'mvweb-core' ),
						'description' => __( 'Written exactly as in the heading.', 'mvweb-core' ),
					),
					'text'         => array(
						'type'        => 'textarea',
						'label'       => __( 'Lead', 'mvweb-core' ),
						'description' => __( 'Words between asterisks, *like this*, take the accent colour.', 'mvweb-core' ),
					),
					'facts'        => array(
						'type'        => 'textarea',
						'label'       => __( 'Facts, one per line', 'mvweb-core' ),
						'description' => __( 'Up to four short lines shown as chips.', 'mvweb-core' ),
					),
					'button_text'  => array(
						'type'  => 'text',
						'label' => __( 'Button', 'mvweb-core' ),
					),
					'button_url'   => array(
						'type'  => 'url',
						'label' => __( 'Where the button leads', 'mvweb-core' ),
					),
					'button_color' => array(
						'type'        => 'color',
						'label'       => __( 'Button colour', 'mvweb-core' ),
						'description' => __( '“As the theme has it” keeps the colour of the theme buttons. The ready colours follow the palette and the dark scheme. The text on the button turns black or white, whichever reads better.', 'mvweb-core' ),
					),
					'price_label'  => array(
						'type'        => 'text',
						'label'       => __( 'Word before the price', 'mvweb-core' ),
						'description' => __( 'For example: from. Empty prints the price alone.', 'mvweb-core' ),
						'default'     => __( 'from', 'mvweb-core' ),
					),
					'price'        => array(
						'type'        => 'text',
						'label'       => __( 'Price beside the button', 'mvweb-core' ),
						'description' => __( 'For example: 990 ₽. The view with a circle puts it on the circle.', 'mvweb-core' ),
					),
					'image_1'      => array(
						'type'        => 'image',
						'label'       => __( 'Picture 1: on the left', 'mvweb-core' ),
						'description' => __( 'Used by the view with a fan of cards.', 'mvweb-core' ),
					),
					'image_2'      => array(
						'type'        => 'image',
						'label'       => __( 'Picture 2: the main one', 'mvweb-core' ),
						'description' => __( 'The middle of the fan, the item on the circle, the large picture of the showcase.', 'mvweb-core' ),
					),
					'image_3'      => array(
						'type'        => 'image',
						'label'       => __( 'Picture 3: on the right', 'mvweb-core' ),
						'description' => __( 'The right of the fan, the second item on the circle.', 'mvweb-core' ),
					),
					'photo'        => array(
						'type'        => 'image',
						'label'       => __( 'Wide photograph', 'mvweb-core' ),
						'description' => __( 'Fills the whole slide. Best size: 2560 × 1120 px (16:7), sharp on retina screens; webp or avif, up to 400 KB. A tablet and a phone show a narrower frame: keep the main subject in the middle across.', 'mvweb-core' ),
					),
					'photo_focus'  => array(
						'type'        => 'select',
						'label'       => __( 'Part of the photo kept in view', 'mvweb-core' ),
						'description' => __( 'The photo fills the slide and its edges are cut off. Choose which part stays.', 'mvweb-core' ),
						'choices'     => array(
							'top'    => __( 'Top', 'mvweb-core' ),
							'center' => __( 'Middle', 'mvweb-core' ),
							'bottom' => __( 'Bottom', 'mvweb-core' ),
						),
						'default'     => 'center',
					),
					'link'         => array(
						'type'        => 'url',
						'label'       => __( 'Link of the whole slide', 'mvweb-core' ),
						'description' => __( 'Empty leaves the slide without a link.', 'mvweb-core' ),
					),
					'text_align'   => array(
						'type'    => 'select',
						'label'   => __( 'Where the text stands', 'mvweb-core' ),
						'choices' => array(
							'start'  => __( 'Left', 'mvweb-core' ),
							'center' => __( 'In the middle', 'mvweb-core' ),
						),
						'default' => 'start',
					),
					'overlay'      => array(
						'type'        => 'number',
						'label'       => __( 'Darken the photo, %', 'mvweb-core' ),
						'description' => __( 'So that the text reads on a light photo. 0 leaves the photo as it is.', 'mvweb-core' ),
						'min'         => 0,
						'max'         => 80,
						'default'     => 40,
					),
					'blur'         => array(
						'type'        => 'number',
						'label'       => __( 'Blur the photo, px', 'mvweb-core' ),
						'description' => __( '0 keeps the photo sharp.', 'mvweb-core' ),
						'min'         => 0,
						'max'         => 10,
						'default'     => 0,
					),
					'products'     => array(
						'type'        => 'repeat',
						'label'       => __( 'Items shown as mini cards', 'mvweb-core' ),
						'description' => __( 'The showcase shows the first three, the ribbon up to six.', 'mvweb-core' ),
						'max'         => 6,
						'fields'      => array(
							'item' => array(
								'type'  => 'item',
								'label' => __( 'Item', 'mvweb-core' ),
							),
						),
					),
				),
			),
		),
	)
);
