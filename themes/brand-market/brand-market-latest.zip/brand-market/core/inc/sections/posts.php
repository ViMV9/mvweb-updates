<?php
/**
 * Section type: the latest posts of the blog.
 *
 * The cards are the blog's own, so a post looks the same on a landing page as
 * in its category, and the parts of the card are set once for the whole site.
 * The field «Period» comes with add_theme_support( 'mvweb-views-period' ); the field
 * «Second category» comes when the theme names it in the key "only" of the block.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_core_posts_layout = mvweb_core_section_layout( 'posts' );
$mvweb_core_posts_period = array();
$mvweb_core_posts_second = array();

if ( current_theme_supports( 'mvweb-views-period' ) ) {
	$mvweb_core_posts_period['period'] = array(
		'type'        => 'select',
		'label'       => __( 'Period', 'mvweb-core' ),
		'description' => __( 'Most read over this period. When the period has fewer articles than places, the most read of all time follow.', 'mvweb-core' ),
		'choices'     => mvweb_core_views_periods(),
		'default'     => 'month',
		'show_when'   => array(
			'field' => 'source',
			'in'    => array( 'read' ),
		),
	);
}

if ( isset( $mvweb_core_posts_layout['only']['category_2'] ) ) {
	$mvweb_core_posts_second['category_2'] = array(
		'type'      => 'category',
		'label'     => __( 'Second category', 'mvweb-core' ),
		'default'   => 0,
		'show_when' => array(
			'field' => 'source',
			'in'    => array( 'latest', 'popular', 'read' ),
		),
	);
}

mvweb_core_register_section(
	'posts',
	array(
		'label'       => __( 'Blog posts', 'mvweb-core' ),
		'description' => __( 'The latest posts, of the whole blog or of one category', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => array(
			'kicker' => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'  => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'   => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'source' => array(
				'type'        => 'select',
				'label'       => __( 'Which posts', 'mvweb-core' ),
				'description' => __( 'Most read: the views are counted after the switch in «Blog: article page» of the Customizer is on. Until then the latest come first.', 'mvweb-core' ),
				'choices'     => array(
					'latest'  => __( 'Latest', 'mvweb-core' ),
					'popular' => __( 'Most discussed', 'mvweb-core' ),
					'read'    => __( 'Most read', 'mvweb-core' ),
					'sticky'  => __( 'Pinned', 'mvweb-core' ),
					'tag'     => __( 'With a tag', 'mvweb-core' ),
					'ids'     => _x( 'Chosen by hand', 'posts source', 'mvweb-core' ),
				),
				'default'     => 'latest',
			),
		) + $mvweb_core_posts_period + array(
			'category' => array(
				'type'      => 'category',
				'label'     => __( 'Category', 'mvweb-core' ),
				'default'   => 0,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'latest', 'popular', 'read' ),
				),
			),
		) + $mvweb_core_posts_second + array(
			'tag'       => array(
				'type'      => 'category',
				'taxonomy'  => 'post_tag',
				'label'     => __( 'Tag', 'mvweb-core' ),
				'default'   => 0,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'tag' ),
				),
			),
			'ids'       => array(
				'type'        => 'text',
				'label'       => __( 'Posts chosen by hand', 'mvweb-core' ),
				'description' => __( 'Numbers of the posts separated by commas, in the order of showing. The number is in the address of the post editor: post=123.', 'mvweb-core' ),
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'ids' ),
				),
			),
			'count'     => array(
				'type'    => 'number',
				'label'   => __( 'How many posts', 'mvweb-core' ),
				'min'     => 1,
				'max'     => 20,
				'default' => 3,
			),
			'link_text' => array(
				'type'    => 'text',
				'label'   => __( 'Link to all posts', 'mvweb-core' ),
				'default' => __( 'All posts', 'mvweb-core' ),
			),
			'link_url'  => array(
				'type'        => 'url',
				'label'       => __( 'Where the link leads', 'mvweb-core' ),
				'description' => __( 'Empty leads to the category, or to the blog when no category is picked.', 'mvweb-core' ),
			),
		),
	)
);

unset( $mvweb_core_posts_layout, $mvweb_core_posts_period, $mvweb_core_posts_second );
