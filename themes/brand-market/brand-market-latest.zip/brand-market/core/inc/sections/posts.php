<?php
/**
 * Section types: the posts of the blog.
 *
 * The cards are the blog's own, so a post looks the same on a landing page as
 * in its category, and the parts of the card are set once for the whole site.
 * Besides the general type «Blog posts» there are four narrow ones, each with
 * its own looks and sources: the first screen, the latest posts, the most read
 * and discussed, the band of a category, the promo banner beside a row of posts.
 * The collections of posts are cards of hand-picked posts. A theme offers the ones it draws.
 * The field «Period» comes with add_theme_support( 'mvweb-views-period' ); the field
 * «Second category» and «Tab open first» come when the theme names them in the key "only" of the block.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_posts_types' ) ) {
	/**
	 * The section types that show the posts of the blog.
	 *
	 * @since 0.1.0
	 *
	 * @return string[]
	 */
	function mvweb_core_posts_types() {
		return array( 'posts', 'posts-lead', 'posts-latest', 'posts-top', 'posts-band', 'posts-promo' );
	}
}

if ( ! function_exists( 'mvweb_core_posts_promo_fields' ) ) {
	/**
	 * The fields of the promo banner with posts: the banner of a collection, then the posts of the row.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_posts_promo_fields() {
		$banner = __( 'Banner', 'mvweb-core' );
		$posts  = __( 'Posts', 'mvweb-core' );
		$fields = array(
			'kicker'      => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'       => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'        => array(
				'type'  => 'textarea',
				'label' => __( 'Text', 'mvweb-core' ),
			),
			'chips'       => array(
				'type'        => 'repeat',
				'label'       => __( 'Links to topics', 'mvweb-core' ),
				'description' => __( 'Short pills under the text.', 'mvweb-core' ),
				'fields'      => array(
					'text' => array(
						'type'  => 'text',
						'label' => __( 'Label', 'mvweb-core' ),
					),
					'url'  => array(
						'type'  => 'url',
						'label' => __( 'Link', 'mvweb-core' ),
					),
				),
			),
			'button_text' => array(
				'type'  => 'text',
				'label' => __( 'Button', 'mvweb-core' ),
			),
			'button_url'  => array(
				'type'        => 'url',
				'label'       => __( 'Where the button leads', 'mvweb-core' ),
				'description' => __( 'Empty leads to the category, or to the blog when no category is picked.', 'mvweb-core' ),
			),
			'image'       => array(
				'type'        => 'image',
				'label'       => __( 'Picture', 'mvweb-core' ),
				'description' => __( 'The main picture of the banner. The views with more pictures use the two below as well.', 'mvweb-core' ),
			),
			'image_2'     => array(
				'type'  => 'image',
				'label' => __( 'Second picture', 'mvweb-core' ),
			),
			'image_3'     => array(
				'type'  => 'image',
				'label' => __( 'Third picture', 'mvweb-core' ),
			),
		);

		foreach ( $fields as $key => $field ) {
			$fields[ $key ]['group'] = $banner;
		}

		$rest = array_diff_key(
			mvweb_core_posts_fields( 'posts-promo', array( 'latest', 'popular', 'read', 'sticky', 'tag', 'ids' ), 'latest' ),
			array_flip( array( 'kicker', 'title', 'text', 'link_text', 'link_url' ) )
		);

		$rest['count']['default'] = 6;
		$rest['count']['max']     = 12;

		foreach ( $rest as $key => $field ) {
			$rest[ $key ]['group'] = $posts;
		}

		return $fields + $rest;
	}
}

if ( ! function_exists( 'mvweb_core_posts_sets_fields' ) ) {
	/**
	 * The fields of the collections of posts: the heading of the block and the collections, each with its posts.
	 *
	 * @since 0.1.0
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_posts_sets_fields() {
		return array(
			'kicker'    => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'     => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'      => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'items'     => array(
				'type'   => 'repeat',
				'label'  => __( 'Collections', 'mvweb-core' ),
				'fields' => array(
					'title' => array(
						'type'  => 'text',
						'label' => __( 'Name', 'mvweb-core' ),
					),
					'text'  => array(
						'type'  => 'textarea',
						'label' => __( 'Description', 'mvweb-core' ),
					),
					'image' => array(
						'type'        => 'image',
						'label'       => __( 'Picture', 'mvweb-core' ),
						'description' => __( 'Empty: the picture of the first post.', 'mvweb-core' ),
					),
					'ids'   => array(
						'type'        => 'text',
						'label'       => __( 'Posts of the collection', 'mvweb-core' ),
						'description' => __( 'Numbers of the posts separated by commas, in the order of reading. The number is in the address of the post editor: post=123.', 'mvweb-core' ),
					),
					'url'   => array(
						'type'        => 'url',
						'label'       => __( 'Where the collection leads', 'mvweb-core' ),
						'description' => __( 'Empty leads to the first post.', 'mvweb-core' ),
					),
					'badge' => array(
						'type'        => 'text',
						'label'       => __( 'Badge', 'mvweb-core' ),
						'description' => __( 'A short word over the picture, for example “New”. Empty: no badge.', 'mvweb-core' ),
					),
				),
			),
			'button'    => array(
				'type'    => 'text',
				'label'   => __( 'Button', 'mvweb-core' ),
				'default' => __( 'Read the collection', 'mvweb-core' ),
			),
			'link_text' => array(
				'type'  => 'text',
				'label' => __( 'Link to all collections', 'mvweb-core' ),
			),
			'link_url'  => array(
				'type'  => 'url',
				'label' => __( 'Where the link leads', 'mvweb-core' ),
			),
		);
	}
}

if ( ! function_exists( 'mvweb_core_posts_fields' ) ) {
	/**
	 * The fields of a section type with posts of the blog.
	 *
	 * @since 0.1.0
	 *
	 * @param string   $type    Type slug.
	 * @param string[] $sources Sources the type offers: latest, popular, read, sticky, tag, ids.
	 * @param string   $initial Source picked by default.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	function mvweb_core_posts_fields( $type, array $sources, $initial ) {
		$layout  = mvweb_core_section_layout( $type );
		$choices = array_intersect_key(
			array(
				'latest'  => __( 'Latest', 'mvweb-core' ),
				'popular' => __( 'Most discussed', 'mvweb-core' ),
				'read'    => __( 'Most read', 'mvweb-core' ),
				'sticky'  => __( 'Pinned', 'mvweb-core' ),
				'tag'     => __( 'With a tag', 'mvweb-core' ),
				'ids'     => _x( 'Chosen by hand', 'posts source', 'mvweb-core' ),
			),
			array_flip( $sources )
		);
		$ranked  = array_values( array_intersect( array( 'latest', 'popular', 'read' ), $sources ) );
		$fields  = array(
			'kicker' => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'  => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'   => array(
				'type'  => 'textarea',
				'label' => __( 'Text under the heading', 'mvweb-core' ),
			),
			'source' => array(
				'type'        => 'select',
				'label'       => __( 'Which posts', 'mvweb-core' ),
				'description' => isset( $choices['read'] ) ? __( 'Most read: the views are counted after the switch in «Blog: article page» of the Customizer is on. Until then the latest come first.', 'mvweb-core' ) : '',
				'choices'     => $choices,
				'default'     => isset( $choices[ $initial ] ) ? $initial : (string) key( $choices ),
			),
		);

		if ( isset( $choices['read'] ) && current_theme_supports( 'mvweb-views-period' ) ) {
			$fields['period'] = array(
				'type'        => 'select',
				'label'       => __( 'Period', 'mvweb-core' ),
				'description' => __( 'Most read over this period. When the period has fewer articles than places, the most read of all time follow.', 'mvweb-core' ),
				'choices'     => mvweb_core_views_periods(),
				'default'     => 'month',
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'read' ),
				),
			);
		}

		if ( ! empty( $ranked ) ) {
			$fields['category'] = array(
				'type'      => 'category',
				'label'     => __( 'Category', 'mvweb-core' ),
				'default'   => 0,
				'show_when' => array(
					'field' => 'source',
					'in'    => $ranked,
				),
			);
		}

		if ( ! empty( $ranked ) && isset( $layout['only']['category_2'] ) ) {
			$fields['category_2'] = array(
				'type'      => 'category',
				'label'     => __( 'Second category', 'mvweb-core' ),
				'default'   => 0,
				'show_when' => array(
					'field' => 'source',
					'in'    => $ranked,
				),
			);
		}

		if ( isset( $layout['only']['tab'] ) ) {
			$fields['tab'] = array(
				'type'    => 'select',
				'label'   => __( 'Tab open first', 'mvweb-core' ),
				'choices' => array(
					'read'    => __( 'Most read', 'mvweb-core' ),
					'popular' => __( 'Most discussed', 'mvweb-core' ),
					'latest'  => __( 'Latest', 'mvweb-core' ),
				),
				'default' => 'read',
			);
		}

		if ( isset( $choices['tag'] ) ) {
			$fields['tag'] = array(
				'type'      => 'category',
				'taxonomy'  => 'post_tag',
				'label'     => __( 'Tag', 'mvweb-core' ),
				'default'   => 0,
				'show_when' => array(
					'field' => 'source',
					'in'    => array( 'tag' ),
				),
			);
		}

		if ( isset( $choices['ids'] ) ) {
			$fields['ids'] = array(
				'type'        => 'text',
				'label'       => __( 'Posts chosen by hand', 'mvweb-core' ),
				'description' => __( 'Numbers of the posts separated by commas, in the order of showing. The number is in the address of the post editor: post=123.', 'mvweb-core' ),
				'show_when'   => array(
					'field' => 'source',
					'in'    => array( 'ids' ),
				),
			);
		}

		return $fields + array(
			'count'     => array(
				'type'    => 'number',
				'label'   => __( 'How many posts', 'mvweb-core' ),
				'min'     => 1,
				'max'     => 20,
				'default' => 3,
			),
			'link_text' => array(
				'type'    => 'text',
				'label'   => __( 'Link to all posts', 'mvweb-core' ),
				'default' => __( 'All posts', 'mvweb-core' ),
			),
			'link_url'  => array(
				'type'        => 'url',
				'label'       => __( 'Where the link leads', 'mvweb-core' ),
				'description' => __( 'Empty leads to the category, or to the blog when no category is picked.', 'mvweb-core' ),
			),
		);
	}
}

$mvweb_core_posts_all = array( 'latest', 'popular', 'read', 'sticky', 'tag', 'ids' );

mvweb_core_register_section(
	'posts',
	array(
		'label'       => __( 'Blog posts', 'mvweb-core' ),
		'description' => __( 'The latest posts, of the whole blog or of one category', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => mvweb_core_posts_fields( 'posts', $mvweb_core_posts_all, 'latest' ),
	)
);

mvweb_core_register_section(
	'posts-lead',
	array(
		'label'       => __( 'First screen with posts', 'mvweb-core' ),
		'description' => __( 'The main story of the blog and the next ones', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => mvweb_core_posts_fields( 'posts-lead', $mvweb_core_posts_all, 'latest' ),
	)
);

mvweb_core_register_section(
	'posts-latest',
	array(
		'label'       => __( 'Latest posts', 'mvweb-core' ),
		'description' => __( 'The latest posts of the blog or of one category', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => mvweb_core_posts_fields( 'posts-latest', array( 'latest', 'sticky', 'tag', 'ids' ), 'latest' ),
	)
);

mvweb_core_register_section(
	'posts-top',
	array(
		'label'       => __( 'Most read and discussed', 'mvweb-core' ),
		'description' => __( 'The posts with the most views or comments', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => mvweb_core_posts_fields( 'posts-top', array( 'read', 'popular' ), 'read' ),
	)
);

mvweb_core_register_section(
	'posts-band',
	array(
		'label'       => __( 'Category band', 'mvweb-core' ),
		'description' => __( 'The posts of one category with its heading and subcategories', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => mvweb_core_posts_fields( 'posts-band', array( 'latest', 'popular', 'read' ), 'latest' ),
	)
);

mvweb_core_register_section(
	'posts-promo',
	array(
		'label'       => __( 'Promo banner with posts', 'mvweb-core' ),
		'description' => __( 'A banner of a collection beside a row of posts', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => mvweb_core_posts_promo_fields(),
	)
);

mvweb_core_register_section(
	'posts-sets',
	array(
		'label'       => __( 'Collections of posts', 'mvweb-core' ),
		'description' => __( 'Cards of collections: a picture, a name, the posts inside and a button', 'mvweb-core' ),
		'category'    => 'about',
		'fields'      => mvweb_core_posts_sets_fields(),
	)
);

unset( $mvweb_core_posts_all );
