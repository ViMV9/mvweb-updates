<?php
/**
 * Section type: a call to follow the site, with the social networks of the profile and the form of the mailing plugin.
 *
 * The networks come from Contacts → Social networks, the form from Conversion
 * → Subscription; the block has no copies of them. It comes with
 * add_theme_support( 'mvweb-subscribe' ).
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! current_theme_supports( 'mvweb-subscribe' ) ) {
	return;
}

mvweb_core_register_section(
	'subscribe',
	array(
		'label'       => __( 'Subscription', 'mvweb-core' ),
		'description' => __( 'Social networks of the site and the mailing form', 'mvweb-core' ),
		'category'    => 'contact',
		'fields'      => array(
			'kicker' => array(
				'type'  => 'text',
				'label' => __( 'Line above the heading', 'mvweb-core' ),
			),
			'title'  => array(
				'type'  => 'text',
				'label' => __( 'Heading', 'mvweb-core' ),
			),
			'text'   => array(
				'type'        => 'textarea',
				'label'       => __( 'Text under the heading', 'mvweb-core' ),
				'description' => __( 'The networks are set in Contacts → Social networks, the mailing form in Conversion → Subscription.', 'mvweb-core' ),
			),
			'points' => array(
				'type'        => 'textarea',
				'label'       => __( 'What the reader gets', 'mvweb-core' ),
				'description' => __( 'One point per line, for example «Five best articles of the week». Empty: no list.', 'mvweb-core' ),
			),
		),
	)
);
