<?php
/**
 * Ready-made set of sections: home page of a clinic.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter(
	'mvweb_core_section_presets',
	static function ( $presets ) {
		if ( ! current_theme_supports( 'mvweb-team-pages' ) ) {
			return $presets;
		}

		$request = '#request';

		$presets['clinic-home'] = array(
			'label'       => __( 'Clinic, home page', 'mvweb-core' ),
			'description' => __( 'First screen, quick actions, directions, services, doctors, figures, reviews, before and after, questions and a call to action', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'hero',
					'props' => array(
						'view'         => '1',
						'title'        => __( 'Doctors you can trust with the health of the whole family', 'mvweb-core' ),
						'lead'         => __( 'Forty specialists, tests and diagnostics in one place. Book online and we will confirm the time within 15 minutes.', 'mvweb-core' ),
						'features'     => array(
							array( 'text' => __( 'Rated 4.9 on the maps', 'mvweb-core' ) ),
							array( 'text' => __( 'Licensed by the Ministry of Health', 'mvweb-core' ) ),
						),
						'button_text'  => __( 'Book an appointment', 'mvweb-core' ),
						'button_url'   => $request,
						'button2_text' => __( 'Find a doctor', 'mvweb-core' ),
						'button2_url'  => '/doctors/',
						'trust'        => array(
							array(
								'number' => __( '15 years', 'mvweb-core' ),
								'text'   => __( 'looking after<br>our patients', 'mvweb-core' ),
							),
						),
						'plate_title'  => __( 'Online booking', 'mvweb-core' ),
						'plate_text'   => __( 'confirmed within 15 minutes', 'mvweb-core' ),
						'plate_icon'   => 'calendar-event',
					),
				),
				array(
					'type'  => 'quick-actions',
					'props' => array(
						'view'  => '1',
						'items' => array(
							array(
								'icon'  => 'calendar-event',
								'title' => __( 'Book an appointment', 'mvweb-core' ),
								'note'  => __( 'Online in one minute', 'mvweb-core' ),
								'url'   => $request,
							),
							array(
								'icon'  => 'home',
								'title' => __( 'Doctor at home', 'mvweb-core' ),
								'note'  => __( 'We arrive within 3 hours', 'mvweb-core' ),
								'url'   => '/services/',
							),
							array(
								'icon'  => 'headset',
								'title' => __( 'Online consultation', 'mvweb-core' ),
								'note'  => __( 'Video call with a doctor', 'mvweb-core' ),
								'url'   => '/services/',
							),
							array(
								'icon'  => 'thermo',
								'title' => __( 'Visit with a cold', 'mvweb-core' ),
								'note'  => __( 'A separate entrance from the yard', 'mvweb-core' ),
								'url'   => '/contacts/',
							),
						),
					),
				),
				array(
					'type'  => 'conditions',
					'props' => array(
						'view'       => '1',
						'kicker'     => __( 'Directions', 'mvweb-core' ),
						'title'      => __( 'What we treat', 'mvweb-core' ),
						'link_url'   => '/services/',
						'directions' => array(
							array(
								'icon'  => 'steth',
								'title' => __( 'Therapy', 'mvweb-core' ),
								'note'  => __( '24 services', 'mvweb-core' ),
								'url'   => '/services/',
							),
							array(
								'icon'  => 'tooth',
								'title' => __( 'Dentistry', 'mvweb-core' ),
								'note'  => __( '38 services', 'mvweb-core' ),
								'url'   => '/services/',
							),
							array(
								'icon'  => 'joint',
								'title' => __( 'Orthopaedics', 'mvweb-core' ),
								'note'  => __( '17 services', 'mvweb-core' ),
								'url'   => '/services/',
							),
							array(
								'icon'  => 'heart',
								'title' => __( 'Cardiology', 'mvweb-core' ),
								'note'  => __( '12 services', 'mvweb-core' ),
								'url'   => '/services/',
							),
							array(
								'icon'  => 'eye',
								'title' => __( 'Ophthalmology', 'mvweb-core' ),
								'note'  => __( '15 services', 'mvweb-core' ),
								'url'   => '/services/',
							),
							array(
								'icon'  => 'spine',
								'title' => __( 'Neurology', 'mvweb-core' ),
								'note'  => __( '11 services', 'mvweb-core' ),
								'url'   => '/services/',
							),
							array(
								'icon'  => 'lab',
								'title' => __( 'Tests', 'mvweb-core' ),
								'note'  => __( '420 tests', 'mvweb-core' ),
								'url'   => '/services/',
							),
							array(
								'icon'  => 'smile',
								'title' => __( 'Check-ups', 'mvweb-core' ),
								'note'  => __( '9 programmes', 'mvweb-core' ),
								'url'   => '/services/',
							),
						),
					),
				),
				array(
					'type'  => 'services',
					'props' => array(
						'view'       => '1',
						'background' => 'surface',
						'kicker'     => __( 'Services', 'mvweb-core' ),
						'title'      => __( 'Clinic services', 'mvweb-core' ),
						'text'       => __( 'Consultations, diagnostics and treatment in one building. The prices are on the site and in the contract.', 'mvweb-core' ),
						'link_url'   => '/services/',
						'items'      => array(
							array(
								'icon'  => 'steth',
								'title' => __( 'Therapist appointment', 'mvweb-core' ),
								'text'  => __( 'An examination, tests and a treatment plan in one visit.', 'mvweb-core' ),
								'price' => '2 500 ₽',
								'url'   => '/services/',
							),
							array(
								'icon'  => 'tooth',
								'title' => __( 'Dentistry', 'mvweb-core' ),
								'text'  => __( 'Treatment of caries, hygiene, implants and prosthetics.', 'mvweb-core' ),
								'price' => '3 200 ₽',
								'url'   => '/services/',
							),
							array(
								'icon'  => 'joint',
								'title' => __( 'Orthopaedics and traumatology', 'mvweb-core' ),
								'text'  => __( 'Joint pain, after-effects of injuries, choosing insoles.', 'mvweb-core' ),
								'price' => '2 900 ₽',
								'url'   => '/services/',
							),
							array(
								'icon'  => 'heart',
								'title' => __( 'Cardiology', 'mvweb-core' ),
								'text'  => __( 'ECG with a report, 24-hour monitoring and a cardiologist’s appointment.', 'mvweb-core' ),
								'price' => '3 100 ₽',
								'url'   => '/services/',
							),
							array(
								'icon'  => 'eye',
								'title' => __( 'Ophthalmology', 'mvweb-core' ),
								'text'  => __( 'Sight test, eye pressure, choosing glasses and lenses.', 'mvweb-core' ),
								'price' => '2 400 ₽',
								'url'   => '/services/',
							),
							array(
								'icon'  => 'lab',
								'title' => __( 'Tests', 'mvweb-core' ),
								'text'  => __( '420 tests in our own laboratory, results by the evening.', 'mvweb-core' ),
								'price' => '350 ₽',
								'url'   => '/services/',
							),
						),
					),
				),
				array(
					'type'  => 'team',
					'props' => array(
						'view'   => '1',
						'kicker' => __( 'Our doctors', 'mvweb-core' ),
						'title'  => __( 'Doctors families trust', 'mvweb-core' ),
						'text'   => __( 'They see adults and children, prescribe clear treatment and stay in touch after the appointment.', 'mvweb-core' ),
						'count'  => 4,
					),
				),
				array(
					'type'  => 'stats',
					'props' => array(
						'view'  => '1',
						'title' => __( 'The clinic in figures', 'mvweb-core' ),
						'text'  => __( 'We opened in 2011 as an office of a general practitioner; today it is a clinic with three departments.', 'mvweb-core' ),
						'items' => array(
							array(
								'number' => __( '15 years', 'mvweb-core' ),
								'label'  => __( 'in practice since 2011', 'mvweb-core' ),
							),
							array(
								'number' => '40',
								'label'  => __( 'doctors of 24 specialities', 'mvweb-core' ),
							),
							array(
								'number' => '120 000',
								'label'  => __( 'patients a year', 'mvweb-core' ),
							),
							array(
								'number' => '4,9',
								'label'  => __( 'average rating on the maps', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'reviews',
					'props' => array(
						'view'       => '1',
						'background' => 'surface',
						'kicker'     => __( 'Reviews', 'mvweb-core' ),
						'title'      => __( 'People trust us', 'mvweb-core' ),
						'source'     => 'own',
						'ratings'    => array(
							array(
								'title' => __( 'City maps', 'mvweb-core' ),
								'score' => '4,9',
								'note'  => __( 'Average rating on the maps', 'mvweb-core' ),
							),
							array(
								'title' => __( 'Organisation directory', 'mvweb-core' ),
								'score' => '4,8',
							),
							array(
								'title' => __( 'Doctors’ review site', 'mvweb-core' ),
								'score' => '4,9',
							),
						),
						'items'      => array(
							array(
								'title'  => __( 'Elena K.', 'mvweb-core' ),
								'text'   => __( 'I booked in the evening and was seen the next day. The doctor listened carefully and explained everything in simple words.', 'mvweb-core' ),
								'source' => __( 'City maps, 12 September', 'mvweb-core' ),
								'stars'  => 'five',
							),
							array(
								'title'  => __( 'Andrey P.', 'mvweb-core' ),
								'text'   => __( 'It is convenient that tests and ultrasound are in one place. The results came the same day, and the prices were as on the site.', 'mvweb-core' ),
								'source' => __( 'Doctors’ review site, 3 October', 'mvweb-core' ),
								'stars'  => 'five',
							),
							array(
								'title'  => __( 'Maria S.', 'mvweb-core' ),
								'text'   => __( 'We came with our son for a check-up before school. The doctor found a common language with him at once, and the certificate was ready the same day.', 'mvweb-core' ),
								'source' => __( 'Organisation directory, 21 September', 'mvweb-core' ),
								'stars'  => 'five',
							),
						),
					),
				),
				array(
					'type'  => 'before-after',
					'props' => array(
						'view'       => '1',
						'kicker'     => __( 'Before and after', 'mvweb-core' ),
						'title'      => __( 'Results of treatment', 'mvweb-core' ),
						'text'       => __( 'Real patients of the clinic; we publish the photos with their consent.', 'mvweb-core' ),
						'source'     => 'rows',
						'button_url' => '/works/',
						'pairs'      => array(
							array(
								'title' => __( 'Correcting a bite with braces', 'mvweb-core' ),
								'text'  => __( 'Crowded lower teeth and a deep bite. Ceramic braces on both jaws, no teeth removed.', 'mvweb-core' ),
								'facts' => implode(
									"\n",
									array(
										__( 'Duration: 1 year 8 months', 'mvweb-core' ),
										__( 'Visits: 14', 'mvweb-core' ),
										__( 'Cost: from 180 000 ₽', 'mvweb-core' ),
									)
								),
							),
							array(
								'title' => __( 'Veneers on six front teeth', 'mvweb-core' ),
								'text'  => __( 'Dark fillings and chips. Ceramic veneers, the shape was agreed on a mock-up before the work began.', 'mvweb-core' ),
								'facts' => implode(
									"\n",
									array(
										__( 'Duration: 3 weeks', 'mvweb-core' ),
										__( 'Visits: 4', 'mvweb-core' ),
										__( 'Cost: from 32 000 ₽ per tooth', 'mvweb-core' ),
									)
								),
							),
							array(
								'title' => __( 'Posture after a course of exercise therapy', 'mvweb-core' ),
								'text'  => __( 'A stoop and neck pain after office work. 12 exercise sessions and a massage of the collar zone.', 'mvweb-core' ),
								'facts' => implode(
									"\n",
									array(
										__( 'Duration: 6 weeks', 'mvweb-core' ),
										__( 'Sessions: 12', 'mvweb-core' ),
										__( 'Cost: from 18 000 ₽', 'mvweb-core' ),
									)
								),
							),
						),
					),
				),
				array(
					'type'  => 'faq',
					'props' => array(
						'view'       => '1',
						'background' => 'surface',
						'kicker'     => __( 'Questions and answers', 'mvweb-core' ),
						'title'      => __( 'Frequent questions from patients', 'mvweb-core' ),
						'items'      => array(
							array(
								'title'  => __( 'How to prepare for a blood test?', 'mvweb-core' ),
								'answer' => __( 'Give blood in the morning on an empty stomach: the last meal 8–12 hours before, plain water is allowed. A day before, avoid alcohol and workouts, and an hour before, smoking. If you take medicines, tell the nurse.', 'mvweb-core' ),
							),
							array(
								'title'  => __( 'May I bring a child without the parents?', 'mvweb-core' ),
								'answer' => __( 'Children under 15 are seen only with a legal representative. If a grandmother or a nanny brings the child, a notarised power of attorney from a parent is needed. From 15 years a teenager may come alone.', 'mvweb-core' ),
							),
							array(
								'title'  => __( 'How to get a certificate for a tax deduction?', 'mvweb-core' ),
								'answer' => __( 'Order a certificate of payment for medical services from the administrator or in your personal account. You will need the passport and the tax number of the person who paid. We prepare it within 5 working days.', 'mvweb-core' ),
							),
							array(
								'title'  => __( 'Do you accept voluntary health insurance?', 'mvweb-core' ),
								'answer' => __( 'Yes, we work with the major insurance companies. Call us before the visit: the administrator will check the programme and agree the letter of guarantee.', 'mvweb-core' ),
							),
							array(
								'title'  => __( 'How to cancel or move an appointment?', 'mvweb-core' ),
								'answer' => __( 'Call or write to a messenger no later than 2 hours before the appointment. If you booked online, cancel the visit by the link from the text message.', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'cta',
					'props' => array(
						'view'        => '1',
						'kicker'      => __( 'Choosing a doctor', 'mvweb-core' ),
						'title'       => __( 'Not sure which doctor to see?', 'mvweb-core' ),
						'text'        => __( 'Leave your phone number. The administrator will ask a couple of questions and choose a specialist.', 'mvweb-core' ),
						'button_text' => __( 'Call me back', 'mvweb-core' ),
						'button_url'  => $request,
					),
				),
			),
		);

		return $presets;
	}
);
