<?php
/**
 * Ready-made set of sections: prices and programmes of a clinic.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter(
	'mvweb_core_section_presets',
	static function ( $presets ) {
		if ( ! current_theme_supports( 'mvweb-team-pages' ) ) {
			return $presets;
		}

		$request = '#request';

		$presets['clinic-prices'] = array(
			'label'       => __( 'Clinic, prices and programmes', 'mvweb-core' ),
			'description' => __( 'A price list by directions, check-up programmes, annual care programmes, questions about payment and a call to action', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'price-list',
					'props' => array(
						'view'        => '1',
						'kicker'      => __( 'Prices', 'mvweb-core' ),
						'title'       => __( 'Service prices', 'mvweb-core' ),
						'rows'        => array(
							array(
								'icon'  => 'steth',
								'title' => __( 'Therapy', 'mvweb-core' ),
								'note'  => __( 'from 1 900 ₽', 'mvweb-core' ),
							),
							array(
								'title'   => __( 'First appointment with a therapist', 'mvweb-core' ),
								'note'    => __( 'An examination, prescriptions, a conclusion in hand', 'mvweb-core' ),
								'price_1' => '2 500 ₽',
							),
							array(
								'title'   => __( 'Repeat appointment within 14 days', 'mvweb-core' ),
								'price_1' => '1 900 ₽',
							),
							array(
								'title'   => __( 'Medical certificate for a swimming pool, a sports club or a spa treatment', 'mvweb-core' ),
								'note'    => __( 'Takes one working day', 'mvweb-core' ),
								'price_1' => __( 'from 3 200 ₽', 'mvweb-core' ),
							),
							array(
								'title'   => __( 'Doctor’s home visit', 'mvweb-core' ),
								'note'    => __( 'Within 3 hours', 'mvweb-core' ),
								'price_1' => __( 'from 4 500 ₽', 'mvweb-core' ),
							),
							array(
								'icon'  => 'tooth',
								'title' => __( 'Dentistry', 'mvweb-core' ),
								'note'  => __( 'from 1 800 ₽', 'mvweb-core' ),
							),
							array(
								'title'   => __( 'Consultation of a dentist', 'mvweb-core' ),
								'note'    => __( 'Free if you start the treatment', 'mvweb-core' ),
								'price_1' => '1 800 ₽',
							),
							array(
								'title'   => __( 'Professional oral hygiene', 'mvweb-core' ),
								'price_1' => '5 900 ₽',
							),
							array(
								'title'   => __( 'Treatment of caries with a light-cured composite filling', 'mvweb-core' ),
								'price_1' => __( 'from 6 200 ₽', 'mvweb-core' ),
							),
							array(
								'title'   => __( 'Implant, turnkey', 'mvweb-core' ),
								'price_1' => __( 'Price on request', 'mvweb-core' ),
							),
							array(
								'icon'  => 'joint',
								'title' => __( 'Orthopaedics', 'mvweb-core' ),
								'note'  => __( 'from 1 500 ₽', 'mvweb-core' ),
							),
							array(
								'title'   => __( 'Appointment with an orthopaedic traumatologist', 'mvweb-core' ),
								'price_1' => '3 000 ₽',
							),
							array(
								'title'   => __( 'Computer plantography', 'mvweb-core' ),
								'price_1' => '1 500 ₽',
							),
							array(
								'title'   => __( 'Individual insoles made from a cast of the foot', 'mvweb-core' ),
								'price_1' => __( 'from 6 900 ₽', 'mvweb-core' ),
							),
							array(
								'icon'  => 'lab',
								'title' => __( 'Tests', 'mvweb-core' ),
								'note'  => __( 'from 300 ₽', 'mvweb-core' ),
							),
							array(
								'title'   => __( 'Complete blood count with a differential', 'mvweb-core' ),
								'note'    => __( 'The result the next day', 'mvweb-core' ),
								'price_1' => '650 ₽',
							),
							array(
								'title'   => __( 'Blood chemistry, 12 indicators', 'mvweb-core' ),
								'price_1' => '2 700 ₽',
							),
							array(
								'title'   => __( 'Taking blood from a vein', 'mvweb-core' ),
								'price_1' => '300 ₽',
							),
						),
						'button_text' => __( 'Book an appointment', 'mvweb-core' ),
						'button_url'  => $request,
						'footnote'    => __( 'The price of an appointment does not change after you book.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'price-list',
					'props' => array(
						'view'        => '5',
						'background'  => 'surface',
						'kicker'      => __( 'Programmes', 'mvweb-core' ),
						'title'       => __( 'A check-up in one morning', 'mvweb-core' ),
						'rows'        => array(
							array(
								'icon'        => 'clock',
								'title'       => __( 'Basic', 'mvweb-core' ),
								'note'        => __( '1.5 hours', 'mvweb-core' ),
								'plan_price'  => '6 900 ₽',
								'includes'    => implode(
									"\n",
									array(
										__( 'Appointment with a therapist', 'mvweb-core' ),
										__( 'Complete and biochemical blood tests', 'mvweb-core' ),
										__( 'ECG with a report', 'mvweb-core' ),
									)
								),
								'button_text' => __( 'Choose', 'mvweb-core' ),
								'button_url'  => $request,
							),
							array(
								'icon'        => 'clock',
								'title'       => __( 'Extended', 'mvweb-core' ),
								'note'        => __( '3 hours', 'mvweb-core' ),
								'plan_price'  => '14 500 ₽',
								'badge'       => __( 'Chosen more often', 'mvweb-core' ),
								'includes'    => implode(
									"\n",
									array(
										__( 'Everything from the “Basic”', 'mvweb-core' ),
										__( 'Ultrasound of the abdomen and the thyroid gland', 'mvweb-core' ),
										__( 'Appointments with a cardiologist and a neurologist', 'mvweb-core' ),
										__( 'A conclusion and a plan for a year', 'mvweb-core' ),
									)
								),
								'button_text' => __( 'Choose', 'mvweb-core' ),
								'button_url'  => $request,
							),
							array(
								'icon'        => 'baby',
								'title'       => __( 'For a child', 'mvweb-core' ),
								'note'        => __( '3–17 years', 'mvweb-core' ),
								'plan_price'  => __( 'from 7 800 ₽', 'mvweb-core' ),
								'includes'    => implode(
									"\n",
									array(
										__( 'Appointments with a paediatrician and an orthopaedist', 'mvweb-core' ),
										__( 'Examination by a dentist', 'mvweb-core' ),
										__( 'Blood and urine tests', 'mvweb-core' ),
									)
								),
								'button_text' => __( 'Choose', 'mvweb-core' ),
								'button_url'  => $request,
							),
						),
						'button_text' => __( 'Get an estimate', 'mvweb-core' ),
						'button_url'  => $request,
						'footnote'    => __( 'A corporate check-up for employees: the set is made to the requirements of the company, we come to the office.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'plans',
					'props' => array(
						'view'   => '1',
						'kicker' => __( 'Annual care', 'mvweb-core' ),
						'title'  => __( 'Annual care programmes', 'mvweb-core' ),
						'text'   => __( 'The doctor knows your history, and the tests and appointments are already paid for.', 'mvweb-core' ),
						'plans'  => array(
							array(
								'title'       => __( 'Basic', 'mvweb-core' ),
								'text'        => __( 'Planned appointments and tests on a schedule', 'mvweb-core' ),
								'price'       => '39 000 ₽',
								'unit'        => __( '/ year', 'mvweb-core' ),
								'items'       => implode(
									"\n",
									array(
										__( '4 appointments with a therapist', 'mvweb-core' ),
										__( 'Tests twice a year', 'mvweb-core' ),
										__( 'ECG and chest X-ray', 'mvweb-core' ),
										'-' . __( 'Doctor’s home visit', 'mvweb-core' ),
										'-' . __( 'Personal doctor in a messenger', 'mvweb-core' ),
									)
								),
								'button_text' => __( 'Join the programme', 'mvweb-core' ),
								'button_url'  => $request,
							),
							array(
								'title'       => __( 'Optimal', 'mvweb-core' ),
								'badge'       => __( 'Chosen more often', 'mvweb-core' ),
								'text'        => __( 'Everything from the basic one and a doctor at home', 'mvweb-core' ),
								'price'       => '64 000 ₽',
								'unit'        => __( '/ year', 'mvweb-core' ),
								'items'       => implode(
									"\n",
									array(
										__( 'Unlimited appointments with a therapist', 'mvweb-core' ),
										__( 'Tests as the doctor prescribes', 'mvweb-core' ),
										__( 'ECG, ultrasound, chest X-ray', 'mvweb-core' ),
										__( '3 home visits of a doctor', 'mvweb-core' ),
										'-' . __( 'Personal doctor in a messenger', 'mvweb-core' ),
									)
								),
								'button_text' => __( 'Join the programme', 'mvweb-core' ),
								'button_url'  => $request,
							),
							array(
								'title'       => __( 'Personal', 'mvweb-core' ),
								'text'        => __( 'A personal doctor in touch every day', 'mvweb-core' ),
								'price'       => '98 000 ₽',
								'unit'        => __( '/ year', 'mvweb-core' ),
								'items'       => implode(
									"\n",
									array(
										__( 'Unlimited appointments with all doctors', 'mvweb-core' ),
										__( 'Tests as the doctor prescribes', 'mvweb-core' ),
										__( 'Any diagnostics', 'mvweb-core' ),
										__( 'Unlimited home visits', 'mvweb-core' ),
										__( 'Personal doctor in a messenger', 'mvweb-core' ),
									)
								),
								'button_text' => __( 'Join the programme', 'mvweb-core' ),
								'button_url'  => $request,
							),
						),
					),
				),
				array(
					'type'  => 'faq',
					'props' => array(
						'view'       => '1',
						'background' => 'surface',
						'kicker'     => __( 'Questions and answers', 'mvweb-core' ),
						'title'      => __( 'Questions about prices and payment', 'mvweb-core' ),
						'items'      => array(
							array(
								'title'  => __( 'Does the price change after I book?', 'mvweb-core' ),
								'answer' => __( 'No. The price of an appointment is fixed when you book and does not change.', 'mvweb-core' ),
							),
							array(
								'title'  => __( 'Which payment methods do you accept?', 'mvweb-core' ),
								'answer' => __( 'Bank cards, cash, a fast payment by QR code and a bank transfer for companies. We send the receipt by e-mail or in a text message.', 'mvweb-core' ),
							),
							array(
								'title'  => __( 'Can I pay in instalments?', 'mvweb-core' ),
								'answer' => __( 'Yes, the treatment can be paid in stages or in instalments.', 'mvweb-core' ),
							),
							array(
								'title'  => __( 'Do you accept voluntary health insurance?', 'mvweb-core' ),
								'answer' => __( 'Yes, we work with the major insurance companies. Call us before the visit: the administrator will check the programme and agree the letter of guarantee.', 'mvweb-core' ),
							),
							array(
								'title'  => __( 'How to get a certificate for a tax deduction?', 'mvweb-core' ),
								'answer' => __( 'Order a certificate of payment for medical services from the administrator or in your personal account. You will need the passport and the tax number of the person who paid. We prepare it within 5 working days.', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'cta',
					'props' => array(
						'view'        => '1',
						'kicker'      => __( 'Exact cost', 'mvweb-core' ),
						'title'       => __( 'Need an exact estimate?', 'mvweb-core' ),
						'text'        => __( 'Tell us what you need, and the administrator will calculate the cost before the visit.', 'mvweb-core' ),
						'button_text' => __( 'Call me back', 'mvweb-core' ),
						'button_url'  => $request,
					),
				),
			),
		);

		return $presets;
	}
);
