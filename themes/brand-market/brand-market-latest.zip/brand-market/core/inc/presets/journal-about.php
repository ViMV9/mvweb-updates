<?php
/**
 * Ready-made sets of sections of Journal: about the magazine.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter(
	'mvweb_core_section_presets',
	static function ( $presets ) {
		$presets['journal-about'] = array(
			'label'       => __( 'About the magazine', 'mvweb-core' ),
			'description' => __( 'How the magazine works, how we work, figures, authors, why readers trust us and a subscription', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'content',
					'props' => array(
						'view'   => '5',
						'kicker' => __( 'About the project', 'mvweb-core' ),
						'title'  => __( 'How the magazine works', 'mvweb-core' ),
						'text'   => __( '<p>We explain how to choose, set up and fix devices. We test the tips on our own devices.</p><p>Guides, comparisons and tips for those who would rather not dig into the settings alone.</p>', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'features',
					'props' => array(
						'view'   => '2',
						'title'  => __( 'How we work', 'mvweb-core' ),
						'blocks' => array(
							array(
								'icon'  => 'check',
								'title' => __( 'We test in practice', 'mvweb-core' ),
								'text'  => implode(
									"\n",
									array(
										__( 'We try every tip ourselves', 'mvweb-core' ),
										__( 'We say so if it did not work', 'mvweb-core' ),
									)
								),
							),
							array(
								'icon'  => 'history',
								'title' => __( 'We update the articles', 'mvweb-core' ),
								'text'  => implode(
									"\n",
									array(
										__( 'The date of the update is under the heading', 'mvweb-core' ),
										__( 'We remove what is out of date', 'mvweb-core' ),
									)
								),
							),
							array(
								'icon'  => 'eye',
								'title' => __( 'We write in plain words', 'mvweb-core' ),
								'text'  => implode(
									"\n",
									array(
										__( 'No jargon and no padding', 'mvweb-core' ),
										__( 'Terms are explained at once', 'mvweb-core' ),
									)
								),
							),
							array(
								'icon'  => 'message-circle',
								'title' => __( 'We answer the readers', 'mvweb-core' ),
								'text'  => implode(
									"\n",
									array(
										__( 'Questions become articles', 'mvweb-core' ),
										__( 'Mistakes are fixed within a week', 'mvweb-core' ),
									)
								),
							),
							array(
								'icon'  => 'checklist',
								'title' => __( 'We name the sources', 'mvweb-core' ),
								'text'  => implode(
									"\n",
									array(
										__( 'Links to the documents', 'mvweb-core' ),
										__( 'At the end of every article', 'mvweb-core' ),
									)
								),
							),
							array(
								'icon'  => 'info',
								'title' => __( 'We keep ads apart', 'mvweb-core' ),
								'text'  => implode(
									"\n",
									array(
										__( 'Advertising is labelled', 'mvweb-core' ),
										__( 'Reviews are not for sale', 'mvweb-core' ),
									)
								),
							),
						),
					),
				),
				array(
					'type'  => 'stats',
					'props' => array(
						'view'  => '1',
						'title' => __( 'The magazine in figures', 'mvweb-core' ),
						'text'  => __( 'We update the figures every quarter.', 'mvweb-core' ),
						'items' => array(
							array(
								'number' => '1 160',
								'label'  => __( 'articles in the base', 'mvweb-core' ),
							),
							array(
								'number' => __( '2.4 million', 'mvweb-core' ),
								'label'  => __( 'readers a month', 'mvweb-core' ),
							),
							array(
								'number' => '37',
								'label'  => __( 'devices tested in a year', 'mvweb-core' ),
							),
							array(
								'number' => __( '7 days', 'mvweb-core' ),
								'label'  => __( 'to update an article after a complaint', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'authors',
					'props' => array(
						'view'      => '1',
						'title'     => __( 'Who writes for you', 'mvweb-core' ),
						'text'      => __( 'Authors and experts of the editorial team', 'mvweb-core' ),
						'count'     => 4,
						'link_text' => __( 'The whole editorial team', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'benefits',
					'props' => array(
						'view'  => '4',
						'title' => __( 'Why readers trust us', 'mvweb-core' ),
						'items' => array(
							array(
								'icon'   => 'check',
								'title'  => __( 'Authors with experience', 'mvweb-core' ),
								'text'   => __( 'Written by those who work in their topic every day', 'mvweb-core' ),
								'figure' => __( '14 authors', 'mvweb-core' ),
								'group'  => __( 'Who writes', 'mvweb-core' ),
							),
							array(
								'icon'   => 'message-circle',
								'title'  => __( 'Checked by an expert', 'mvweb-core' ),
								'text'   => __( 'A specialist reads difficult topics before they are published', 'mvweb-core' ),
								'figure' => __( '6 experts', 'mvweb-core' ),
								'group'  => __( 'Who writes', 'mvweb-core' ),
							),
							array(
								'icon'   => 'history',
								'title'  => __( 'Fresh data', 'mvweb-core' ),
								'text'   => __( 'We update the articles when the rules and prices change', 'mvweb-core' ),
								'figure' => __( 'once a year', 'mvweb-core' ),
								'group'  => __( 'Our methods', 'mvweb-core' ),
							),
							array(
								'icon'   => 'checklist',
								'title'  => __( 'Sources', 'mvweb-core' ),
								'text'   => __( 'We refer to documents and studies', 'mvweb-core' ),
								'figure' => __( 'in every article', 'mvweb-core' ),
								'group'  => __( 'Our methods', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'subscribe',
					'props' => array(
						'view'  => '2',
						'title' => __( 'One letter a week, five useful articles', 'mvweb-core' ),
						'text'  => __( 'No ads and no spam. Unsubscribe in one click.', 'mvweb-core' ),
					),
				),
			),
		);

		return $presets;
	}
);
