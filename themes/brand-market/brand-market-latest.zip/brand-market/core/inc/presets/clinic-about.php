<?php
/**
 * Ready-made set of sections: page about a clinic.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter(
	'mvweb_core_section_presets',
	static function ( $presets ) {
		if ( ! current_theme_supports( 'mvweb-team-pages' ) ) {
			return $presets;
		}

		$request = '#request';

		$presets['clinic-about'] = array(
			'label'       => __( 'Clinic, about the clinic', 'mvweb-core' ),
			'description' => __( 'A text about the clinic with a quote, figures, advantages, doctors, licences and documents, branches and a call to action', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'content',
					'props' => array(
						'view'        => '2',
						'title'       => __( 'Doctors who agree between themselves', 'mvweb-core' ),
						'text'        => implode(
							'',
							array(
								'<p>' . esc_html__( 'In the clinic 40 doctors of 24 specialities see patients. If a second specialist is needed at the appointment, the therapist invites him to the room, and you do not have to book again.', 'mvweb-core' ) . '</p>',
								'<h3>' . esc_html__( 'What the first appointment includes', 'mvweb-core' ) . '</h3>',
								'<ul><li>' . esc_html__( 'An examination and a review of earlier tests', 'mvweb-core' ) . '</li><li>' . esc_html__( 'A plan of the examination with the prices before the treatment begins', 'mvweb-core' ) . '</li><li>' . esc_html__( 'A conclusion and prescriptions by e-mail the same day', 'mvweb-core' ) . '</li></ul>',
							)
						),
						'badge_icon'  => 'shield',
						'badge_title' => __( 'Since 2011', 'mvweb-core' ),
						'badge_text'  => __( '15 years looking after patients', 'mvweb-core' ),
						'quote'       => __( 'Every test must answer a question of the doctor. We do not order tests “just in case”.', 'mvweb-core' ),
						'quote_cite'  => __( 'Anna Smirnova, chief doctor', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'stats',
					'props' => array(
						'view'  => '1',
						'title' => __( 'The clinic in figures', 'mvweb-core' ),
						'text'  => __( 'We opened in 2011 as an office of a general practitioner; today it is a clinic with three departments.', 'mvweb-core' ),
						'items' => array(
							array(
								'number' => __( '15 years', 'mvweb-core' ),
								'label'  => __( 'in practice since 2011', 'mvweb-core' ),
							),
							array(
								'number' => '40',
								'label'  => __( 'doctors of 24 specialities', 'mvweb-core' ),
							),
							array(
								'number' => '120 000',
								'label'  => __( 'patients a year', 'mvweb-core' ),
							),
							array(
								'number' => '4,9',
								'label'  => __( 'average rating on the maps', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'features',
					'props' => array(
						'view'       => '1',
						'background' => 'surface',
						'kicker'     => __( 'Why us', 'mvweb-core' ),
						'title'      => __( 'A clinic where everything is settled in one visit', 'mvweb-core' ),
						'blocks'     => array(
							array(
								'icon'  => 'steth',
								'title' => __( '40 specialists', 'mvweb-core' ),
								'text'  => __( 'Therapists, narrow specialists and surgeons with 8 or more years of experience.', 'mvweb-core' ),
							),
							array(
								'icon'  => 'baby',
								'title' => __( 'Children and adults', 'mvweb-core' ),
								'text'  => __( 'Separate waiting areas and an entrance from the yard for patients with a cold.', 'mvweb-core' ),
							),
							array(
								'icon'  => 'file-text',
								'title' => __( 'Tests in a day', 'mvweb-core' ),
								'text'  => __( 'The results of most tests come to your personal account by the evening.', 'mvweb-core' ),
							),
							array(
								'icon'  => 'shield',
								'title' => __( 'Ministry of Health licence', 'mvweb-core' ),
								'text'  => __( 'For all kinds of care we provide. The documents are open on the site.', 'mvweb-core' ),
							),
							array(
								'icon'  => 'calendar-check',
								'title' => __( 'Seven days a week', 'mvweb-core' ),
								'text'  => __( 'Also on public holidays, on a shortened schedule.', 'mvweb-core' ),
							),
							array(
								'icon'  => 'lab',
								'title' => __( 'Our own laboratory', 'mvweb-core' ),
								'text'  => __( '420 tests without sending samples to outside laboratories.', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'team',
					'props' => array(
						'view'   => '1',
						'kicker' => __( 'Our doctors', 'mvweb-core' ),
						'title'  => __( 'Doctors families trust', 'mvweb-core' ),
						'text'   => __( 'They see adults and children, prescribe clear treatment and stay in touch after the appointment.', 'mvweb-core' ),
						'count'  => 4,
					),
				),
				array(
					'type'  => 'partners',
					'props' => array(
						'view'       => '4',
						'background' => 'surface',
						'kicker'     => __( 'Documents', 'mvweb-core' ),
						'title'      => __( 'Licences and documents of the clinic', 'mvweb-core' ),
						'text'       => __( 'The clinic works under an unlimited licence. The originals can be seen at the reception of any branch.', 'mvweb-core' ),
						'logos'      => array(
							array(
								'name' => __( 'Licence for medical activity', 'mvweb-core' ),
								'note' => __( 'Unlimited', 'mvweb-core' ),
							),
							array(
								'name' => __( 'Extract from the register of licences', 'mvweb-core' ),
								'note' => __( 'Renewed every quarter', 'mvweb-core' ),
							),
							array(
								'name' => __( 'Sanitary and epidemiological conclusion', 'mvweb-core' ),
								'note' => __( 'For the premises of every branch', 'mvweb-core' ),
							),
							array(
								'name' => __( 'Quality management certificate', 'mvweb-core' ),
								'note' => __( 'ISO 9001:2015', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'branches',
					'props' => array(
						'view'        => '1',
						'kicker'      => __( 'Branches', 'mvweb-core' ),
						'title'       => __( 'Clinics near you', 'mvweb-core' ),
						'text'        => __( 'Choose the nearest branch: each has its own hours, phones and booking.', 'mvweb-core' ),
						'status_text' => __( 'Open seven days a week', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'cta',
					'props' => array(
						'view'        => '1',
						'kicker'      => __( 'Choosing a doctor', 'mvweb-core' ),
						'title'       => __( 'Not sure which doctor to see?', 'mvweb-core' ),
						'text'        => __( 'Leave your phone number. The administrator will ask a couple of questions and choose a specialist.', 'mvweb-core' ),
						'button_text' => __( 'Call me back', 'mvweb-core' ),
						'button_url'  => $request,
					),
				),
			),
		);

		return $presets;
	}
);
