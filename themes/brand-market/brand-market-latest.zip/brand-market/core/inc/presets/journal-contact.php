<?php
/**
 * Ready-made sets of sections of Journal: getting in touch with the editors.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter(
	'mvweb_core_section_presets',
	static function ( $presets ) {
		$presets['journal-contact'] = array(
			'label'       => __( 'Get in touch', 'mvweb-core' ),
			'description' => __( 'Suggest a topic with a form (it shows once the shortcode of a form plugin is set), frequent questions and networks as tiles; the address and e-mail stay on the template «Contacts»', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'embed',
					'props' => array(
						'view'  => '2',
						'title' => __( 'Suggest a topic for an article', 'mvweb-core' ),
						'text'  => __( 'The most frequent questions of the readers become articles. We will write to you when the article comes out.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'faq',
					'props' => array(
						'view'       => '2',
						'kicker'     => __( 'Questions', 'mvweb-core' ),
						'title'      => __( 'Frequent questions', 'mvweb-core' ),
						'text'       => __( 'If there is no answer, write to the editors: we will look into the question in a new article.', 'mvweb-core' ),
						'open_first' => true,
						'items'      => array(
							array(
								'icon'   => 'info',
								'title'  => __( 'Do you repair devices?', 'mvweb-core' ),
								'answer' => __( 'No, we are an editorial team: we write guides and test tips. For repairs go to a service centre: our articles help to choose a reliable one.', 'mvweb-core' ),
							),
							array(
								'icon'   => 'message-circle',
								'title'  => __( 'How do you choose what to write about?', 'mvweb-core' ),
								'answer' => __( 'By the questions of the readers and by search queries. If you suggested the topic, the article will say so.', 'mvweb-core' ),
							),
							array(
								'icon'   => 'history',
								'title'  => __( 'Why does the article show an old interface?', 'mvweb-core' ),
								'answer' => __( 'Makers often change the menus. Write to us: we will update the article within a week and put a new date.', 'mvweb-core' ),
							),
							array(
								'icon'   => 'link',
								'title'  => __( 'May I reprint an article?', 'mvweb-core' ),
								'answer' => __( 'Yes, with a live link to the original. For a full reprint write to the editors.', 'mvweb-core' ),
							),
							array(
								'icon'   => 'alert',
								'title'  => __( 'Do you take money for reviews?', 'mvweb-core' ),
								'answer' => __( 'No. Advertising is labelled with the word «Advertising» and is never mixed with reviews.', 'mvweb-core' ),
							),
						),
					),
				),
				array(
					'type'  => 'subscribe',
					'props' => array(
						'view'  => '4',
						'title' => __( 'Read us where it suits you', 'mvweb-core' ),
						'text'  => __( 'New articles come out in every channel at once', 'mvweb-core' ),
					),
				),
			),
		);

		return $presets;
	}
);
