<?php
/**
 * Ready-made set of sections: contacts page of a clinic.
 *
 * @package MVweb_Theme_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_filter(
	'mvweb_core_section_presets',
	static function ( $presets ) {
		if ( ! current_theme_supports( 'mvweb-team-pages' ) ) {
			return $presets;
		}

		$presets['clinic-contacts'] = array(
			'label'       => __( 'Clinic, contacts', 'mvweb-core' ),
			'description' => __( 'Contacts, branches, a map and a request form (they show once the code of a map and the shortcode of a form are set) and frequent questions', 'mvweb-core' ),
			'rows'        => array(
				array(
					'type'  => 'contacts',
					'props' => array(
						'view'       => '4',
						'kicker'     => __( 'Contacts', 'mvweb-core' ),
						'title'      => __( 'How to reach us', 'mvweb-core' ),
						'text'       => __( 'Call, write to a messenger or come to any branch.', 'mvweb-core' ),
						'email_note' => __( 'We reply within a working day', 'mvweb-core' ),
						'map_title'  => __( 'Clinics on the map', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'branches',
					'props' => array(
						'view'        => '1',
						'background'  => 'surface',
						'kicker'      => __( 'Branches', 'mvweb-core' ),
						'title'       => __( 'Branches and how to get there', 'mvweb-core' ),
						'text'        => __( 'Choose the nearest branch: each has its own hours, phones and booking.', 'mvweb-core' ),
						'status_text' => __( 'Open seven days a week', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'embed',
					'props' => array(
						'view'   => '1',
						'kicker' => __( 'How to get there', 'mvweb-core' ),
						'title'  => __( 'Clinics on the map', 'mvweb-core' ),
						'text'   => __( 'Tap a pin to build a route.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'contact-form',
					'props' => array(
						'view'       => '1',
						'background' => 'surface',
						'title'      => __( 'Book an appointment', 'mvweb-core' ),
						'text'       => __( 'Leave your contacts, and the administrator will choose a doctor and a convenient time. The administrator’s advice is free.', 'mvweb-core' ),
						'note'       => __( 'We call back within 15 minutes during working hours.', 'mvweb-core' ),
					),
				),
				array(
					'type'  => 'faq',
					'props' => array(
						'view'   => '1',
						'kicker' => __( 'Questions and answers', 'mvweb-core' ),
						'title'  => __( 'Frequent questions', 'mvweb-core' ),
						'items'  => array(
							array(
								'title'  => __( 'Can I come without an appointment?', 'mvweb-core' ),
								'answer' => __( 'Yes, if a doctor has a free slot, the administrator will register you at the reception. It is faster to book online or by phone.', 'mvweb-core' ),
							),
							array(
								'title'  => __( 'How to cancel or move an appointment?', 'mvweb-core' ),
								'answer' => __( 'Call or write to a messenger no later than 2 hours before the appointment. If you booked online, cancel the visit by the link from the text message.', 'mvweb-core' ),
							),
							array(
								'title'  => __( 'May I bring a child without the parents?', 'mvweb-core' ),
								'answer' => __( 'Children under 15 are seen only with a legal representative. If a grandmother or a nanny brings the child, a notarised power of attorney from a parent is needed. From 15 years a teenager may come alone.', 'mvweb-core' ),
							),
							array(
								'title'  => __( 'Which payment methods do you accept?', 'mvweb-core' ),
								'answer' => __( 'Bank cards, cash, a fast payment by QR code and a bank transfer for companies. We send the receipt by e-mail or in a text message.', 'mvweb-core' ),
							),
							array(
								'title'  => __( 'Do you accept voluntary health insurance?', 'mvweb-core' ),
								'answer' => __( 'Yes, we work with the major insurance companies. Call us before the visit: the administrator will check the programme and agree the letter of guarantee.', 'mvweb-core' ),
							),
						),
					),
				),
			),
		);

		return $presets;
	}
);
