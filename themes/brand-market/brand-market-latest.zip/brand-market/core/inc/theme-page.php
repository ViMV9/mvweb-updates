<?php
/**
 * Page of the theme in the admin: the theme, its guide and the studio.
 *
 * @package MVweb_Core
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_core_theme_page_menu' ) ) {
	/**
	 * Add the page of the theme to the admin menu.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_theme_page_menu() {
		$theme = wp_get_theme( get_template() );

		add_menu_page(
			$theme->display( 'Name', false ),
			$theme->display( 'Name', false ),
			'edit_theme_options',
			get_template(),
			'mvweb_core_theme_page',
			'dashicons-admin-appearance',
			'99.4'
		);
	}
}
add_action( 'admin_menu', 'mvweb_core_theme_page_menu' );

if ( ! function_exists( 'mvweb_core_theme_page' ) ) {
	/**
	 * Print the page of the theme.
	 *
	 * @since 0.1.0
	 *
	 * @return void
	 */
	function mvweb_core_theme_page() {
		$theme = wp_get_theme( get_template() );
		$guide = file_exists( get_template_directory() . '/readme.html' ) ? get_template_directory_uri() . '/readme.html' : '';
		?>
		<div class="wrap">
			<h1><?php echo esc_html( $theme->display( 'Name', false ) . ' ' . $theme->get( 'Version' ) ); ?></h1>
			<p><?php echo esc_html( $theme->display( 'Description', false ) ); ?></p>

			<?php if ( '' !== $guide ) : ?>
				<div class="card">
					<h2 class="title"><?php esc_html_e( 'Setup guide', 'mvweb-core' ); ?></h2>
					<p><?php esc_html_e( 'Step by step: where each setting of the theme is and what it changes on the site.', 'mvweb-core' ); ?></p>
					<p><a class="button button-primary" href="<?php echo esc_url( $guide ); ?>" target="_blank" rel="noopener"><?php esc_html_e( 'Open the guide', 'mvweb-core' ); ?></a></p>
				</div>
			<?php endif; ?>

			<div class="card">
				<h2 class="title"><?php esc_html_e( 'MVweb studio', 'mvweb-core' ); ?></h2>
				<p><?php esc_html_e( 'MVweb makes websites, themes and plugins for WordPress.', 'mvweb-core' ); ?></p>
				<p><?php esc_html_e( 'Our plugins add what a site often needs: contact buttons, smart search, price import, image optimization and more.', 'mvweb-core' ); ?></p>
				<p>
					<a class="button button-primary" href="https://mvweb.ru/plugins/" target="_blank" rel="noopener"><?php esc_html_e( 'Studio plugins', 'mvweb-core' ); ?></a>
					<a class="button" href="https://mvweb.ru/" target="_blank" rel="noopener"><?php esc_html_e( 'Studio website', 'mvweb-core' ); ?></a>
				</p>
			</div>
		</div>
		<?php
	}
}
