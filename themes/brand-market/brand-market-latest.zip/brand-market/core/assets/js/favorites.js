const data = JSON.parse(
	document.getElementById( "wp-script-module-data-@mvweb-core/favorites" )?.textContent || "{}"
);

const KEY = "mvweb_favorites";

function readLocal() {
	try {
		const raw = JSON.parse( window.localStorage.getItem( KEY ) );

		return Array.isArray( raw ) ? raw.map( Number ).filter( Boolean ) : [];
	} catch ( error ) {
		return [];
	}
}

function writeLocal( ids ) {
	try {
		window.localStorage.setItem( KEY, JSON.stringify( ids ) );
	} catch ( error ) {
		return;
	}
}

function readShared() {
	const raw = new URLSearchParams( window.location.search ).get( "fav" );

	if ( raw === null ) {
		return null;
	}

	return raw.split( "," ).map( Number ).filter( function ( id ) {
		return Number.isInteger( id ) && id > 0;
	} ).slice( 0, 48 );
}

const shared = readShared();
let list = data.loggedIn ? ( data.stored || [] ).map( Number ) : readLocal();
let ticket = 0;

function send( path, body ) {
	return fetch( data.root + path, {
		method: "POST",
		keepalive: true,
		credentials: "same-origin",
		headers: {
			"Content-Type": "application/json",
			"X-WP-Nonce": data.nonce
		},
		body: JSON.stringify( body )
	} ).then( function ( response ) {
		return response.ok ? response.json() : Promise.reject( response.status );
	} );
}

function persist() {
	ticket += 1;

	if ( ! data.loggedIn ) {
		writeLocal( list );

		return Promise.resolve();
	}

	const mine = ticket;

	return send( "", { ids: list } ).then( function ( result ) {
		if ( mine === ticket ) {
			list = result.ids;
		}
	} );
}

function label( count ) {
	const rule = new Intl.PluralRules( document.documentElement.lang || "en" ).select( count );
	const forms = data.forms || {};
	const form = rule === "one" ? forms.one : ( rule === "few" ? forms.few : forms.many );

	return ( form || "%d" ).replace( "%d", String( count ) );
}

function say( text ) {
	document.querySelectorAll( "[data-fav-live]" ).forEach( function ( node ) {
		node.textContent = text;
	} );
}

function paint() {
	document.querySelectorAll( "[data-fav-count]" ).forEach( function ( node ) {
		node.textContent = String( list.length );
		node.hidden = list.length === 0;
	} );

	document.querySelectorAll( "[data-fav-toggle]" ).forEach( function ( button ) {
		const active = list.indexOf( Number( button.dataset.favToggle ) ) !== -1;

		button.setAttribute( "aria-pressed", String( active ) );
		button.title = active ? data.added : data.add;
		button.querySelectorAll( "[data-fav-label]" ).forEach( function ( label ) {
			label.textContent = button.title;
		} );
	} );
}

function toggle( button ) {
	const id = Number( button.dataset.favToggle );

	if ( ! id ) {
		return;
	}

	const before = list;
	const at = list.indexOf( id );
	const removed = at !== -1;

	list = removed ? list.slice( 0, at ).concat( list.slice( at + 1 ) ) : list.concat( id );

	if ( removed ) {
		drop( button );
	}

	paint();

	persist().then( paint ).catch( function () {
		list = before;
		paint();
		renderList();
	} );
}

function board() {
	return document.querySelector( "[data-fav-list]" );
}

function settle() {
	const box = board();

	if ( ! box ) {
		return;
	}

	const grid = box.querySelector( "[data-fav-grid]" );
	const empty = box.querySelector( "[data-fav-empty]" );
	const failed = box.querySelector( "[data-fav-error]" );
	const count = grid.children.length;
	const head = grid.previousElementSibling;

	grid.hidden = 0 === count;
	empty.hidden = 0 !== count;
	failed.hidden = true;

	if ( head && head.matches( "[aria-hidden='true']" ) ) {
		head.hidden = 0 === count;
	}

	box.querySelectorAll( "[data-fav-tools]" ).forEach( function ( node ) {
		node.hidden = 0 === count || shared !== null;
	} );

	box.querySelectorAll( "[data-fav-guest]" ).forEach( function ( node ) {
		node.hidden = data.loggedIn || 0 === count || shared !== null;
	} );

	box.querySelectorAll( "[data-fav-shared]" ).forEach( function ( node ) {
		node.hidden = shared === null;
	} );

	document.querySelectorAll( "[data-fav-total]" ).forEach( function ( node ) {
		node.textContent = 0 === count ? "" : label( count );
		node.hidden = 0 === count;
	} );
}

function drop( button ) {
	if ( shared !== null ) {
		return;
	}

	const card = button.closest( "[data-fav-grid] > *" );

	if ( ! card ) {
		return;
	}

	card.remove();
	settle();
}

function fill( grid, html ) {
	const parsed = new DOMParser().parseFromString( html, "text/html" );

	grid.replaceChildren.apply( grid, Array.prototype.slice.call( parsed.body.childNodes ) );
}

function renderList() {
	const box = board();

	if ( ! box ) {
		return;
	}

	const grid = box.querySelector( "[data-fav-grid]" );
	const ids = shared !== null ? shared : list;
	const mine = ticket;

	if ( ids.length === 0 ) {
		fill( grid, "" );
		settle();
		paint();

		return;
	}

	send( "/cards", { ids: ids } ).then( function ( result ) {
		if ( mine !== ticket ) {
			return;
		}

		if ( shared === null ) {
			list = result.ids;

			if ( ! data.loggedIn ) {
				writeLocal( list );
			}
		}

		fill( grid, result.html );
		settle();
		paint();
	} ).catch( function () {
		box.querySelector( "[data-fav-error]" ).hidden = false;
		box.querySelector( "[data-fav-empty]" ).hidden = true;
	} );
}

function shareUrl() {
	const url = new URL( window.location.href );

	url.hash = "";
	url.searchParams.set( "fav", list.join( "," ) );

	return url.toString().replace( /%2C/g, "," );
}

function flash( button, text ) {
	const node = button.querySelector( "[data-fav-share-label]" );

	say( text );

	if ( ! node ) {
		return;
	}

	const original = node.textContent;

	node.textContent = text;
	window.setTimeout( function () {
		node.textContent = original;
	}, 2200 );
}

function share( button ) {
	const url = shareUrl();
	const ask = function () {
		window.prompt( data.copyPrompt, url );
	};

	if ( window.navigator.clipboard && window.navigator.clipboard.writeText ) {
		window.navigator.clipboard.writeText( url ).then( function () {
			flash( button, data.copied );
		}, ask );
	} else {
		ask();
	}
}

function clear() {
	if ( list.length === 0 || ! window.confirm( data.clearAsk ) ) {
		return;
	}

	const before = list;
	const grid = board()?.querySelector( "[data-fav-grid]" );

	list = [];

	if ( grid ) {
		fill( grid, "" );
	}

	settle();
	paint();
	say( data.cleared );

	persist().then( paint ).catch( function () {
		list = before;
		paint();
		renderList();
	} );
}

function start() {
	document.addEventListener( "click", function ( event ) {
		const button = event.target.closest( "[data-fav-toggle]" );
		const sharing = event.target.closest( "[data-fav-share]" );
		const clearing = event.target.closest( "[data-fav-clear]" );

		if ( button ) {
			event.preventDefault();
			toggle( button );
		} else if ( sharing ) {
			event.preventDefault();
			share( sharing );
		} else if ( clearing ) {
			event.preventDefault();
			clear();
		}
	} );

	const local = readLocal();

	if ( data.loggedIn && local.length ) {
		send( "", { ids: local, merge: true } ).then( function ( result ) {
			list = result.ids;
			writeLocal( [] );
			paint();
			renderList();
		} ).catch( renderList );

		paint();

		return;
	}

	paint();
	renderList();
}

start();
