function bounds( input ) {
	const box = input.closest( "[data-qty]" );

	return {
		min: Number( input.dataset.qtyMin || box.dataset.min ) || 1,
		max: Number( input.dataset.qtyMax || box.dataset.max ) || 0,
		step: Number( input.dataset.qtyStep || box.dataset.step ) || 1
	};
}

function clampQuantity( input, value ) {
	const { min, max, step } = bounds( input );
	let next = Math.max( min, value );

	if ( step > 1 ) {
		next = min + Math.round( ( next - min ) / step ) * step;
	}

	return max > 0 ? Math.min( max, next ) : next;
}

function stepQuantity( event ) {
	const minus = event.target.closest( "[data-qty-minus]" );
	const button = minus || event.target.closest( "[data-qty-plus]" );
	const input = button?.closest( "[data-qty]" )?.querySelector( "[data-qty-input]" );

	if ( ! input ) {
		return;
	}

	const { min, step } = bounds( input );
	const current = parseInt( input.value, 10 ) || min;

	input.value = String( clampQuantity( input, current + ( minus ? -step : step ) ) );
	input.dispatchEvent( new Event( "change", { bubbles: true } ) );
}

function quantityEdges( input ) {
	const box = input.closest( "[data-qty]" );
	const { min, max } = bounds( input );
	const value = parseInt( input.value, 10 ) || 0;
	const minus = box.querySelector( "[data-qty-minus]" );
	const plus = box.querySelector( "[data-qty-plus]" );

	if ( minus ) {
		minus.disabled = value <= min;
	}

	if ( plus ) {
		plus.disabled = max > 0 && value >= max;
	}
}

function money( amount, format ) {
	const parts = amount.toFixed( format.decimals ).split( "." );
	const whole = parts[ 0 ].replace( /\B(?=(\d{3})+(?!\d))/g, format.thousands );

	return format.format.replace( "%s", parts[ 1 ] ? whole + format.point + parts[ 1 ] : whole );
}

function buyCount( input ) {
	const box = input.closest( "[data-buy]" );
	let data;

	if ( ! box ) {
		return;
	}

	try {
		data = JSON.parse( box.getAttribute( "data-buy" ) );
	} catch ( e ) {
		return;
	}

	const qty = Math.max( data.min, parseInt( input.value, 10 ) || data.min );
	const froms = Object.keys( data.tiers ).map( Number ).sort( ( a, b ) => a - b );
	const next = froms.find( ( from ) => from > qty );
	let unit = data.price;
	let step = data.min;

	froms.forEach( function ( from ) {
		if ( qty >= from ) {
			unit = data.tiers[ from ];
			step = from;
		}
	} );

	document.querySelectorAll( "[data-buy-sum]" ).forEach( function ( sum ) {
		sum.textContent = money( unit * qty, data.money );
	} );

	box.querySelectorAll( "[data-buy-total]" ).forEach( function ( total ) {
		const note = total.querySelector( "[data-buy-note]" );
		let text = "";

		if ( next ) {
			text = total.getAttribute( "data-left" ).replace( "%1$d", next - qty ).replace( "%3$s", money( data.tiers[ next ], data.money ) );
		} else if ( unit < data.price ) {
			text = total.getAttribute( "data-save" ).replace( "%s", money( ( data.price - unit ) * qty, data.money ) );
		}

		note.textContent = text;
		note.hidden = "" === text;
	} );

	box.querySelectorAll( "[data-tier-set]" ).forEach( function ( tile ) {
		tile.setAttribute( "aria-pressed", Number( tile.getAttribute( "data-tier-set" ) ) === step ? "true" : "false" );
	} );

	box.querySelectorAll( "[data-tier-bar]" ).forEach( function ( bar ) {
		bar.style.width = Math.min( 100, Math.round( qty / ( froms[ froms.length - 1 ] || qty ) * 100 ) ) + "%";
	} );
}

function syncQuantity( event ) {
	const input = event.target;

	if ( ! input.matches || ! input.matches( "[data-qty-input]" ) ) {
		return;
	}

	const value = parseInt( input.value, 10 );
	const add = input.closest( "[data-qty]" ).parentNode.querySelector( ".add_to_cart_button" );

	input.value = String( clampQuantity( input, Number.isNaN( value ) ? 1 : value ) );
	quantityEdges( input );
	buyCount( input );

	if ( ! add ) {
		return;
	}

	add.setAttribute( "data-quantity", input.value );

	if ( add.href ) {
		const link = new URL( add.href, location.href );

		link.searchParams.set( "quantity", input.value );
		add.href = link.toString();
	}
}

function typeQuantity( event ) {
	const input = event.target;

	if ( input.matches && input.matches( "[data-qty-input]" ) ) {
		quantityEdges( input );
		buyCount( input );
	}
}

function pickTier( event ) {
	const tile = event.target.closest( "[data-tier-set]" );
	const input = tile?.closest( "[data-buy]" )?.querySelector( "[data-qty-input]" );

	if ( ! input ) {
		return;
	}

	input.value = tile.getAttribute( "data-tier-set" );
	input.dispatchEvent( new Event( "change", { bubbles: true } ) );
}

function showVariation( event, variation ) {
	const sku = document.querySelector( "[data-sku-format]" );
	const img = document.querySelector( "[data-gallery-main]" );
	const zoom = img ? img.closest( "[data-gallery-zoom]" ) : null;
	const found = "found_variation" === event.type && variation;

	if ( sku ) {
		sku.dataset.skuFirst = sku.dataset.skuFirst || sku.textContent.trim();
		sku.textContent = found && variation.sku ? sku.dataset.skuFormat.split( "%s" ).join( variation.sku ) : sku.dataset.skuFirst;
	}

	if ( ! img ) {
		return;
	}

	const own = found && variation.image && variation.image.src;

	img.dataset.firstSrc ??= img.getAttribute( "src" ) || "";
	img.dataset.firstSrcset ??= img.getAttribute( "srcset" ) || "";
	img.dataset.firstWidth ??= img.style.getPropertyValue( "--mvweb-t-img-w" );
	img.dataset.firstZoom ??= zoom ? zoom.getAttribute( "href" ) : "";

	img.setAttribute( "src", own ? variation.image.src : img.dataset.firstSrc );
	img.setAttribute( "srcset", own ? variation.image.srcset || "" : img.dataset.firstSrcset );
	img.style.setProperty( "--mvweb-t-img-w", own ? "100%" : img.dataset.firstWidth || "100%" );

	if ( zoom ) {
		zoom.setAttribute( "href", own ? variation.image.full_src || variation.image.src : img.dataset.firstZoom );
	}
}

document.querySelectorAll( "[data-qty] [data-qty-input]" ).forEach( function ( input ) {
	quantityEdges( input );
	buyCount( input );
} );

document.addEventListener( "click", stepQuantity );
document.addEventListener( "click", pickTier );
document.addEventListener( "change", syncQuantity );
document.addEventListener( "input", typeQuantity );

if ( window.jQuery ) {
	window.jQuery( document.body ).on( "found_variation reset_data", ".variations_form", showVariation );
}
