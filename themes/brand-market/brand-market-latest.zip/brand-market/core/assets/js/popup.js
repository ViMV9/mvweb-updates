const modal = document.querySelector( "[data-request-modal]" );

function subject( opener ) {
	const named = opener && opener.getAttribute( "data-request" );
	const heading = document.querySelector( "main h1" );

	return named || ( heading ? heading.textContent.trim() : document.title );
}

function state( name ) {
	modal.querySelectorAll( "[data-view]" ).forEach( function ( view ) {
		const on = view.getAttribute( "data-view" ) === name;

		view.hidden = ! on;

		if ( on && view.hasAttribute( "data-title" ) ) {
			modal.setAttribute( "aria-labelledby", view.getAttribute( "data-title" ) );
		}
	} );

	modal.setAttribute( "data-state", name );
}

function open( opener ) {
	const name = subject( opener );
	const box = modal.querySelector( "[data-request-subject-box]" );
	const shown = modal.querySelector( "[data-request-subject]" );
	const own = opener ? opener.getAttribute( "data-request" ) || "" : "";

	modal.querySelectorAll( 'input[name="product"]' ).forEach( function ( input ) {
		input.value = name;
	} );

	if ( box && shown ) {
		shown.textContent = own;
		box.hidden = "" === own;
	}

	state( "form" );
	modal.showModal();
}

if ( modal && typeof modal.showModal === "function" ) {
	document.addEventListener( "click", function ( event ) {
		const link = event.target.closest( 'a[href$="#request"]' );

		if ( ! link ) {
			return;
		}

		const here = link.getAttribute( "href" ) === "#request" || ( link.origin === location.origin && link.pathname === location.pathname );

		if ( ! here ) {
			return;
		}

		event.preventDefault();
		open( link );
	} );

	modal.addEventListener( "click", function ( event ) {
		if ( event.target === modal || event.target.closest( "[data-request-close]" ) ) {
			modal.close();
		} else if ( event.target.closest( "[data-request-retry]" ) ) {
			state( "form" );
		}
	} );

	document.addEventListener( "wpcf7mailsent", function ( event ) {
		if ( modal.contains( event.target ) ) {
			state( "ok" );
		}
	} );

	document.addEventListener( "wpcf7mailfailed", function ( event ) {
		if ( modal.contains( event.target ) ) {
			state( "error" );
		}
	} );

	modal.addEventListener( "close", function () {
		state( "form" );
	} );

	if ( location.hash === "#request" ) {
		open( null );
		history.replaceState( null, "", location.pathname + location.search );
	}
}
