function clock(minutes) {
	const time = minutes % 1440;

	return Math.floor(time / 60) + ":" + String(time % 60).padStart(2, "0");
}

function status(data) {
	const now = new Date(Date.now() + data.offset * 60000);
	const today = (now.getUTCDay() + 6) % 7;
	const minute = now.getUTCHours() * 60 + now.getUTCMinutes();
	const yesterday = data.week[(today + 6) % 7].filter(function (pair) {
		return pair[1] > 1440 && minute < pair[1] - 1440;
	});

	if (yesterday.length) {
		return { open: true, text: data.text.open.replace("%s", clock(yesterday[0][1])) };
	}

	for (const pair of data.week[today]) {
		if (minute >= pair[0] && minute < pair[1]) {
			const round = data.week.every(function (day) {
				return day.some(function (span) {
					return 0 === span[0] && span[1] >= 1440;
				});
			});

			return { open: true, text: round ? data.text.round : data.text.open.replace("%s", clock(pair[1])) };
		}
	}

	for (let step = 0; step < 7; step++) {
		const day = (today + step) % 7;
		const next = data.week[day].filter(function (pair) {
			return 0 !== step || pair[0] > minute;
		}).sort(function (a, b) {
			return a[0] - b[0];
		})[0];

		if (next) {
			if (0 === step) {
				return { open: false, text: data.text.today.replace("%s", clock(next[0])) };
			}

			if (1 === step) {
				return { open: false, text: data.text.tomorrow.replace("%s", clock(next[0])) };
			}

			return { open: false, text: data.text.later.replace("%1$s", data.days[day]).replace("%2$s", clock(next[0])) };
		}
	}

	return { open: false, text: data.text.closed };
}

function paint() {
	document.querySelectorAll("[data-branch-status]").forEach(function (node) {
		let data;

		try {
			data = JSON.parse(node.getAttribute("data-branch-status"));
		} catch (error) {
			return;
		}

		const result = status(data);
		const label = node.querySelector("[data-branch-status-text]") || node;

		label.textContent = result.text;
		node.setAttribute("data-open", result.open ? "true" : "false");
		node.hidden = false;
	});
}

paint();
window.setInterval(paint, 60000);
