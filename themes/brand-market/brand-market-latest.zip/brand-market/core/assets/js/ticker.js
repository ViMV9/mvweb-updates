const query = window.matchMedia( "(prefers-reduced-motion: reduce)" );

function setup( root ) {
	const track = root.querySelector( "[data-ticker-track]" );
	const run = track && track.firstElementChild;
	const toggle = root.querySelector( "[data-ticker-toggle]" );
	let copy = null;
	let hovered = false;
	let focused = false;

	if ( ! track || ! run ) {
		return;
	}

	function draw() {
		const pinned = toggle && "true" === toggle.getAttribute( "aria-pressed" );

		if ( query.matches ) {
			root.setAttribute( "data-ticker-state", "static" );
		} else {
			root.setAttribute( "data-ticker-state", pinned || hovered || focused ? "paused" : "running" );
		}
	}

	function sync() {
		if ( query.matches && copy ) {
			copy.remove();
			copy = null;
		} else if ( ! query.matches && ! copy ) {
			copy = run.cloneNode( true );
			copy.setAttribute( "aria-hidden", "true" );
			copy.setAttribute( "inert", "" );
			copy.removeAttribute( "data-ticker-run" );
			copy.querySelectorAll( "[id]" ).forEach( function ( node ) {
				node.removeAttribute( "id" );
			} );
			track.appendChild( copy );
		}

		if ( toggle ) {
			toggle.hidden = query.matches;
		}

		draw();
	}

	if ( toggle ) {
		toggle.addEventListener( "click", function () {
			toggle.setAttribute( "aria-pressed", String( "true" !== toggle.getAttribute( "aria-pressed" ) ) );
			hovered = false;
			focused = false;
			draw();
		} );
	}

	root.addEventListener( "pointerenter", function ( event ) {
		hovered = "mouse" === event.pointerType;
		draw();
	} );

	root.addEventListener( "pointerleave", function () {
		hovered = false;
		draw();
	} );

	root.addEventListener( "focusin", function () {
		focused = true;
		draw();
	} );

	root.addEventListener( "focusout", function ( event ) {
		focused = root.contains( event.relatedTarget );
		draw();
	} );

	query.addEventListener( "change", sync );
	sync();
}

document.querySelectorAll( "[data-ticker]" ).forEach( setup );
