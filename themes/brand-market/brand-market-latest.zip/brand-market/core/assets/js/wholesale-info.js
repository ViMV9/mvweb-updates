const info = document.querySelector( "[data-wholesale-info]" );

if ( info && typeof info.showModal === "function" ) {
	document.addEventListener( "click", function ( event ) {
		if ( event.target.closest( "[data-wholesale-open]" ) ) {
			info.showModal();
		} else if ( event.target === info || event.target.closest( "[data-wholesale-close]" ) ) {
			info.close();
		}
	} );
}
