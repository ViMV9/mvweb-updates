const bar = document.querySelector( "[data-bottom-nav]" );

function measure() {
	document.documentElement.style.setProperty( "--mvweb-t-bottom-nav-h", bar.offsetHeight + "px" );
}

if ( bar ) {
	measure();

	if ( typeof ResizeObserver === "function" ) {
		new ResizeObserver( measure ).observe( bar );
	}
}
