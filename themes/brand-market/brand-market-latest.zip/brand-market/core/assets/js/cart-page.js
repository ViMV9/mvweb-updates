const jq = window.jQuery;
let timer = 0;

function update() {
	const button = document.querySelector( '.woocommerce-cart-form [name="update_cart"]' );

	if ( button ) {
		button.disabled = false;
		button.click();
	}
}

document.addEventListener( "change", function ( event ) {
	if ( ! event.target.matches || ! event.target.matches( ".woocommerce-cart-form .qty" ) ) {
		return;
	}

	window.clearTimeout( timer );
	timer = window.setTimeout( update, 600 );
} );

function heading() {
	const totals = document.querySelector( ".cart_totals[data-hero]" );
	const meta = document.querySelector( "[data-hero-meta]" );
	let facts = [];

	if ( ! totals ) {
		return;
	}

	try {
		facts = JSON.parse( totals.getAttribute( "data-hero" ) );
	} catch ( error ) {
		return;
	}

	if ( meta ) {
		meta.replaceChildren.apply(
			meta,
			facts.map( function ( text ) {
				const span = document.createElement( "span" );

				span.textContent = text;

				return span;
			} )
		);
	}

	document.querySelectorAll( "[data-cart-count]" ).forEach( function ( badge ) {
		const count = totals.getAttribute( "data-count" ) || "0";

		badge.textContent = "0" === count ? "" : count;
		badge.hidden = "0" === count;
	} );
}

if ( jq ) {
	jq( document.body ).on( "updated_wc_div updated_cart_totals", heading );

	jq( document.body ).on( "wc_cart_emptied", function () {
		const link = document.querySelector( ".woocommerce-message a.restore-item" );
		const note = link ? link.closest( ".woocommerce-message" ) : null;

		try {
			if ( note ) {
				window.sessionStorage.setItem( "mvweb-cart-undo", JSON.stringify( { text: note.textContent.replace( link.textContent, "" ).trim(), undo: link.textContent.trim(), href: link.href } ) );
			}
		} catch ( error ) {}

		window.location.reload();
	} );
}

( function () {
	let saved = null;

	try {
		saved = JSON.parse( window.sessionStorage.getItem( "mvweb-cart-undo" ) || "null" );
		window.sessionStorage.removeItem( "mvweb-cart-undo" );
	} catch ( error ) {
		return;
	}

	const wrap = document.querySelector( ".woocommerce-notices-wrapper" );

	if ( ! saved || ! wrap || new URL( saved.href, window.location.href ).origin !== window.location.origin ) {
		return;
	}

	const box = document.createElement( "div" );
	const text = document.createElement( "p" );
	const link = document.createElement( "a" );

	const svg = document.createElementNS( "http://www.w3.org/2000/svg", "svg" );
	const use = document.createElementNS( "http://www.w3.org/2000/svg", "use" );

	box.className = "mvweb-t-alert mvweb-t-alert--ok woocommerce-message";
	box.setAttribute( "role", "status" );
	svg.setAttribute( "class", "mvweb-t-icon mvweb-t-icon--sm" );
	svg.setAttribute( "aria-hidden", "true" );
	use.setAttribute( "href", "#mvweb-t-icon-check" );
	svg.append( use );
	box.append( svg );
	link.className = "restore-item";
	link.href = saved.href;
	link.textContent = saved.undo;
	text.append( saved.text + " ", link );
	box.append( text );
	wrap.prepend( box );
}() );
