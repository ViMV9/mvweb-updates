const panel = document.querySelector( "[data-filters]" );
const toggles = document.querySelectorAll( "[data-filters-toggle]" );

function setFilters( open ) {
	if ( ! panel ) {
		return;
	}

	panel.toggleAttribute( "data-open", open );
	toggles.forEach( function ( button ) {
		button.setAttribute( "aria-expanded", open ? "true" : "false" );
	} );
}

if ( panel ) {
	let opener = null;

	toggles.forEach( function ( button ) {
		button.addEventListener( "click", function () {
			const open = ! panel.hasAttribute( "data-open" );

			opener = open ? button : null;
			setFilters( open );

			if ( open ) {
				const close = panel.querySelector( "form [data-filters-close]" );

				if ( close && close.offsetParent !== null ) {
					close.focus();
				}
			}
		} );
	} );

	panel.querySelectorAll( "[data-filters-close]" ).forEach( function ( button ) {
		button.addEventListener( "click", function () {
			setFilters( false );

			if ( opener ) {
				opener.focus();
			}
		} );
	} );

	document.addEventListener( "keydown", function ( event ) {
		const form = panel.querySelector( "form" );

		if ( "Tab" === event.key && form && panel.hasAttribute( "data-open" ) && "fixed" === getComputedStyle( form ).position ) {
			const items = Array.from( form.querySelectorAll( "a[href], button, input:not([type=hidden]), select, textarea, summary" ) ).filter( function ( el ) {
				return ! el.disabled && el.getClientRects().length > 0;
			} );
			const first = items[ 0 ];
			const last = items[ items.length - 1 ];

			if ( first && ( ! form.contains( document.activeElement ) || ( event.shiftKey ? document.activeElement === first : document.activeElement === last ) ) ) {
				event.preventDefault();
				( event.shiftKey ? last : first ).focus();
			}
		}

		if ( "Escape" === event.key && panel.hasAttribute( "data-open" ) ) {
			setFilters( false );

			if ( opener ) {
				opener.focus();
			}
		}
	} );
}
