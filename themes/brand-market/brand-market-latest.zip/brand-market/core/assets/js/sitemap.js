(function () {
	"use strict";

	document.querySelectorAll("[data-sitemap-tree]").forEach(function (root) {
		var bar = root.querySelector("[data-sitemap-bar]");

		if (!bar) {
			return;
		}

		bar.hidden = false;
		bar.addEventListener("click", function (event) {
			var button = event.target.closest("[data-sitemap-all]");

			if (!button) {
				return;
			}

			root.querySelectorAll(".mvweb-t-sm-tree__node").forEach(function (node) {
				node.open = "open" === button.dataset.sitemapAll;
			});
		});
	});

	document.querySelectorAll("[data-sitemap-toc]").forEach(function (root) {
		var field = root.querySelector("[data-sitemap-search]");
		var input = root.querySelector("[data-sitemap-query]");
		var status = root.querySelector("[data-sitemap-status]");
		var rows = Array.prototype.slice.call(root.querySelectorAll("li[data-text]"));
		var names = Array.prototype.slice.call(root.querySelectorAll(".mvweb-t-sm-toc__name"));
		var chips = Array.prototype.slice.call(root.querySelectorAll("[data-sitemap-chip]"));

		if (!field || !input) {
			return;
		}

		names.forEach(function (node) {
			node.dataset.name = node.textContent;
		});

		function norm(text) {
			return text.toLowerCase().replace(/ё/g, "е");
		}

		function mark(node, query) {
			var text = node.dataset.name;
			var at = query ? norm(text).indexOf(query) : -1;
			var hit;

			if (at < 0) {
				node.textContent = text;
				return;
			}

			hit = document.createElement("mark");
			hit.textContent = text.slice(at, at + query.length);
			node.replaceChildren(text.slice(0, at), hit, text.slice(at + query.length));
		}

		function filter() {
			var query = norm(input.value.trim());
			var show = new Set();
			var count = 0;

			rows.forEach(function (row) {
				var up;

				if (query && (!row.dataset.text || row.dataset.text.indexOf(query) < 0)) {
					return;
				}

				if (query) {
					count++;
				}

				show.add(row);
				row.querySelectorAll("li").forEach(function (inner) {
					show.add(inner);
				});

				up = row.parentElement.closest("li");

				while (up && root.contains(up)) {
					show.add(up);
					up = up.parentElement.closest("li");
				}
			});

			rows.forEach(function (row) {
				row.hidden = !show.has(row);
			});

			names.forEach(function (node) {
				mark(node, query);
			});

			chips.forEach(function (chip) {
				var type = document.getElementById(chip.dataset.sitemapChip);

				chip.hidden = !type || type.hidden;
			});

			if (!status) {
				return;
			}

			if (!query) {
				status.textContent = "";
				return;
			}

			status.textContent = count ? status.dataset.found.replace("%s", String(count)) : status.dataset.none;
		}

		field.hidden = false;
		input.addEventListener("input", filter);
		input.addEventListener("keydown", function (event) {
			if ("Escape" === event.key) {
				input.value = "";
				filter();
			}
		});
	});
})();
