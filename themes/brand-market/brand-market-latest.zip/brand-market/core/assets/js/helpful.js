const data = JSON.parse(
	document.getElementById( "wp-script-module-data-@mvweb-core/helpful" )?.textContent || "{}"
);

const KEY = "mvweb_helpful";

function readVotes() {
	try {
		const raw = JSON.parse( window.localStorage.getItem( KEY ) );

		return raw && typeof raw === "object" && ! Array.isArray( raw ) ? raw : {};
	} catch ( error ) {
		return {};
	}
}

function writeVote( id, vote ) {
	const votes = readVotes();

	if ( vote ) {
		votes[ id ] = vote;
	} else {
		delete votes[ id ];
	}

	try {
		window.localStorage.setItem( KEY, JSON.stringify( votes ) );
	} catch ( error ) {
		return;
	}
}

function press( box, vote ) {
	box.querySelectorAll( "[data-helpful-vote]" ).forEach( function ( button ) {
		button.setAttribute( "aria-pressed", button.dataset.helpfulVote === vote ? "true" : "false" );
	} );
}

function say( box, text ) {
	const status = box.querySelector( "[data-helpful-status]" );

	if ( status ) {
		status.textContent = text || "";
	}
}

function thanks( counts ) {
	if ( ! counts || ! counts.total ) {
		return data.first;
	}

	return String( data.thanks || data.first )
		.replace( "%1$s", String( counts.share ) )
		.replace( "%2$s", new Intl.NumberFormat( document.documentElement.lang || undefined ).format( counts.total ) )
		.replace( "%%", "%" );
}

function setup( box ) {
	const id = parseInt( box.dataset.helpful, 10 );

	if ( ! id || ! data.url ) {
		return;
	}

	const before = readVotes()[ id ];
	let busy = false;

	if ( before === "yes" || before === "no" ) {
		press( box, before );
	}

	box.addEventListener( "click", function ( event ) {
		const button = event.target.closest( "[data-helpful-vote]" );

		if ( ! button || ! box.contains( button ) ) {
			return;
		}

		const vote = button.dataset.helpfulVote;

		if ( vote !== "yes" && vote !== "no" ) {
			return;
		}

		if ( readVotes()[ id ] ) {
			say( box, data.again );

			return;
		}

		if ( busy ) {
			return;
		}

		busy = true;
		writeVote( id, vote );
		press( box, vote );

		fetch( data.url, {
			method: "POST",
			keepalive: true,
			credentials: "omit",
			headers: { "Content-Type": "application/json" },
			body: JSON.stringify( { id: id, vote: vote } )
		} ).then( function ( response ) {
			return response.ok ? response.json() : Promise.reject( response.status );
		} ).then( function ( counts ) {
			say( box, thanks( counts ) );
		} ).catch( function () {
			writeVote( id, "" );
			press( box, "" );
			say( box, data.error );
		} ).finally( function () {
			busy = false;
		} );
	} );

	box.hidden = false;
}

document.querySelectorAll( "[data-helpful]" ).forEach( setup );
