const triggers = {};

function inside( popover ) {
	const active = document.activeElement;

	return ! active || active === document.body || popover.contains( active );
}

document.addEventListener( "click", function ( event ) {
	const trigger = event.target.closest( "[data-popover-trigger]" );

	if ( trigger ) {
		triggers[ trigger.getAttribute( "data-popover-trigger" ) ] = trigger;
	}
}, true );

document.querySelectorAll( "[data-popover]" ).forEach( function ( popover ) {
	popover.addEventListener( "toggle", function ( event ) {
		const trigger = triggers[ popover.id ];

		if ( "open" === event.newState ) {
			const close = popover.querySelector( "[data-popover-close]" );

			if ( close ) {
				close.focus();
			}
		} else if ( trigger && trigger.isConnected && inside( popover ) ) {
			trigger.focus();
		}
	} );

	popover.addEventListener( "keydown", function ( event ) {
		if ( "Escape" === event.key && "manual" === popover.getAttribute( "popover" ) ) {
			popover.hidePopover();
		}
	} );
} );
