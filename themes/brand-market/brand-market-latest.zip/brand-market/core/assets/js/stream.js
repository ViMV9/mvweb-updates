( function () {
	"use strict";

	function wall( list ) {
		if ( ! ( "ResizeObserver" in window ) || ( window.CSS && CSS.supports( "display", "grid-lanes" ) ) ) {
			return;
		}

		const size = function ( item ) {
			const gap = parseFloat( getComputedStyle( list ).getPropertyValue( "--mvweb-t-wall-gap" ) ) * parseFloat( getComputedStyle( document.documentElement ).fontSize ) || 0;

			item.style.gridRowEnd = "span " + Math.ceil( ( item.getBoundingClientRect().height + gap ) / 4 );
		};
		const watch = new ResizeObserver( function ( entries ) {
			window.requestAnimationFrame( function () {
				entries.forEach( function ( entry ) {
					size( entry.target );
				} );
			} );
		} );
		const add = function () {
			Array.prototype.forEach.call( list.children, function ( item ) {
				if ( ! item.hasAttribute( "data-sized" ) ) {
					item.setAttribute( "data-sized", "" );
					size( item );
					watch.observe( item );
				}
			} );
		};

		list.setAttribute( "data-ready", "" );
		add();
		list.addEventListener( "mvweb:stream", add );
	}

	function pageOf( url ) {
		const match = url.match( /\/page\/(\d+)/ ) || url.match( /[?&]paged?=(\d+)/ );

		return match ? match[ 1 ] : "";
	}

	function stream( box ) {
		const list = box.querySelector( "[data-list]" );

		if ( ! list || ! ( "IntersectionObserver" in window ) || ! window.fetch || ! window.DOMParser ) {
			return;
		}

		const auto = parseInt( box.dataset.auto || "0", 10 );
		const marks = [];
		const start = window.location.href;
		const status = document.createElement( "div" );
		const more = document.createElement( "div" );
		const button = document.createElement( "button" );
		const edge = document.createElement( "div" );
		let loads = 0;
		let busy = false;
		let failed = false;

		status.className = "screen-reader-text";
		status.setAttribute( "role", "status" );
		more.className = "mvweb-t-stream__more";
		more.hidden = true;
		button.type = "button";
		button.className = "mvweb-t-btn mvweb-t-btn--outline mvweb-t-stream__load";
		button.textContent = box.dataset.more || "";
		more.append( button );

		const pager = function () {
			return box.querySelector( ".mvweb-t-pagination" );
		};
		const next = function () {
			const nav = pager();

			return nav ? nav.querySelector( "[data-next]" ) : null;
		};

		edge.setAttribute( "aria-hidden", "true" );
		( pager() || list ).after( edge, more, status );

		const watch = new IntersectionObserver(
			function ( entries ) {
				if ( entries[ 0 ].isIntersecting ) {
					load( false );
				}
			},
			{ rootMargin: "99999px 0px 120px 0px" }
		);

		const settle = function () {
			if ( failed ) {
				watch.disconnect();
				more.hidden = true;

				return;
			}

			if ( ! next() ) {
				watch.disconnect();
				more.hidden = 0 === loads;
				button.hidden = true;

				if ( loads > 0 && ! more.querySelector( ".mvweb-t-stream__end" ) ) {
					const end = document.createElement( "p" );

					end.className = "mvweb-t-stream__end";
					end.textContent = box.dataset.end || "";
					more.prepend( end );
				}

				return;
			}

			if ( loads >= auto ) {
				watch.disconnect();
				more.hidden = false;

				return;
			}

			watch.unobserve( edge );
			watch.observe( edge );
		};

		const merge = function ( item, mark ) {
			const last = mark.previousElementSibling;

			if ( item.dataset.day && last && last.dataset.day === item.dataset.day ) {
				const into = last.querySelector( "ol, ul" );
				const from = item.querySelector( "ol, ul" );

				if ( into && from ) {
					Array.prototype.forEach.call( Array.from( from.children ), function ( row ) {
						into.append( row );
					} );

					return true;
				}
			}

			return false;
		};

		const load = function ( byButton ) {
			const link = next();

			if ( ! link || busy ) {
				return;
			}

			busy = true;
			list.setAttribute( "aria-busy", "true" );
			button.setAttribute( "aria-disabled", "true" );

			window
				.fetch( link.href, { credentials: "same-origin" } )
				.then( function ( response ) {
					if ( ! response.ok ) {
						throw new Error( String( response.status ) );
					}

					return response.text();
				} )
				.then( function ( html ) {
					const doc = new window.DOMParser().parseFromString( html, "text/html" );
					const fresh = doc.querySelector( '[data-stream="' + box.dataset.stream + '"]' );
					const items = fresh ? fresh.querySelector( "[data-list]" ) : null;

					if ( ! items ) {
						throw new Error( "list" );
					}

					const seen = new Set(
						Array.prototype.map.call( list.querySelectorAll( "[data-id]" ), function ( item ) {
							return item.dataset.id;
						} )
					);
					const page = pageOf( link.href );
					const mark = document.createElement( "a" );

					mark.className = "mvweb-t-stream__mark";
					mark.href = link.href;
					mark.textContent = ( box.dataset.page || "%s" ).replace( "%s", page );
					list.append( mark );
					marks.push( mark );

					Array.from( items.children ).forEach( function ( item, index ) {
						if ( item.dataset.id && seen.has( item.dataset.id ) ) {
							return;
						}

						item.querySelectorAll( "[data-id]" ).forEach( function ( row ) {
							if ( seen.has( row.dataset.id ) ) {
								row.remove();
							}
						} );

						if ( item.dataset.day && ! item.querySelector( "[data-id]" ) ) {
							return;
						}

						if ( 0 === index && merge( item, mark ) ) {
							return;
						}

						item.classList.add( "mvweb-t-stream__new" );
						list.append( item );
					} );

					const old = pager();
					const nav = fresh.querySelector( ".mvweb-t-pagination" );

					if ( old && nav ) {
						old.replaceWith( nav );
					} else if ( old ) {
						old.remove();
					}

					loads += 1;
					status.textContent = ( box.dataset.loaded || "%s" ).replace( "%s", page );
					list.dispatchEvent( new CustomEvent( "mvweb:stream" ) );

					if ( byButton ) {
						mark.focus();
					}
				} )
				.catch( function () {
					failed = true;
				} )
				.finally( function () {
					busy = false;
					list.removeAttribute( "aria-busy" );
					button.removeAttribute( "aria-disabled" );
					settle();
				} );
		};

		button.addEventListener( "click", function () {
			if ( "true" !== button.getAttribute( "aria-disabled" ) ) {
				load( true );
			}
		} );

		let frame = 0;

		window.addEventListener(
			"scroll",
			function () {
				if ( frame || ! marks.length ) {
					return;
				}

				frame = window.requestAnimationFrame( function () {
					let url = start;

					frame = 0;
					marks.forEach( function ( mark ) {
						if ( mark.getBoundingClientRect().top < window.innerHeight * 0.35 ) {
							url = mark.href;
						}
					} );

					if ( url !== window.location.href ) {
						window.history.replaceState( window.history.state, "", url );
					}
				} );
			},
			{ passive: true }
		);

		settle();
	}

	document.querySelectorAll( "[data-wall]" ).forEach( wall );
	document.querySelectorAll( "[data-stream]" ).forEach( stream );
} )();
