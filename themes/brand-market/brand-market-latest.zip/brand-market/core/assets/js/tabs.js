let counter = 0;

function own( root, selector ) {
	return Array.prototype.filter.call( root.querySelectorAll( selector ), function ( node ) {
		return node.closest( "[data-tabs]" ) === root;
	} );
}

function identify( node, prefix ) {
	if ( ! node.id ) {
		counter += 1;
		node.id = prefix + counter;
	}

	return node.id;
}

function setup( root ) {
	const tabs = own( root, "[data-tab]" );
	const panels = own( root, "[data-tabpanel]" );
	const list = own( root, '[role="tablist"]' )[ 0 ] || ( tabs[ 0 ] && tabs[ 0 ].parentElement );
	const pairs = [];

	tabs.forEach( function ( tab, index ) {
		const key = tab.getAttribute( "data-tab" );
		const panel = key
			? panels.filter( function ( node ) {
				return node.getAttribute( "data-tabpanel" ) === key;
			} )[ 0 ]
			: panels[ index ];

		if ( panel ) {
			pairs.push( { tab: tab, panel: panel } );
		}
	} );

	if ( ! list || pairs.length < 2 ) {
		return;
	}

	if ( ! list.hasAttribute( "role" ) ) {
		list.setAttribute( "role", "tablist" );
	}

	pairs.forEach( function ( pair ) {
		pair.tab.setAttribute( "role", "tab" );
		pair.tab.setAttribute( "aria-controls", identify( pair.panel, "mvweb-tabpanel-" ) );
		pair.panel.setAttribute( "role", "tabpanel" );
		pair.panel.setAttribute( "aria-labelledby", identify( pair.tab, "mvweb-tab-" ) );

		if ( ! pair.panel.querySelector( 'a[href], button, input, select, textarea, [tabindex]' ) ) {
			pair.panel.tabIndex = 0;
		}
	} );

	function select( tab ) {
		pairs.forEach( function ( pair ) {
			const on = pair.tab === tab;

			pair.tab.setAttribute( "aria-selected", String( on ) );
			pair.tab.tabIndex = on ? 0 : -1;
			pair.panel.hidden = ! on;
		} );
	}

	function usable() {
		return pairs.map( function ( pair ) {
			return pair.tab;
		} ).filter( function ( tab ) {
			return ! tab.hidden && ! tab.disabled;
		} );
	}

	const start = usable().filter( function ( tab ) {
		return "true" === tab.getAttribute( "aria-selected" );
	} )[ 0 ] || usable()[ 0 ];

	select( start );

	pairs.forEach( function ( pair ) {
		pair.tab.addEventListener( "click", function () {
			select( pair.tab );
		} );

		pair.tab.addEventListener( "keydown", function ( event ) {
			const vertical = "vertical" === list.getAttribute( "aria-orientation" );
			const rtl = "rtl" === getComputedStyle( list ).direction;
			const forward = vertical ? "ArrowDown" : rtl ? "ArrowLeft" : "ArrowRight";
			const back = vertical ? "ArrowUp" : rtl ? "ArrowRight" : "ArrowLeft";
			const open = usable();
			const at = open.indexOf( pair.tab );
			let target = null;

			if ( event.altKey || event.ctrlKey || event.metaKey || at < 0 ) {
				return;
			}

			if ( event.key === forward ) {
				target = open[ ( at + 1 ) % open.length ];
			} else if ( event.key === back ) {
				target = open[ ( at - 1 + open.length ) % open.length ];
			} else if ( "Home" === event.key ) {
				target = open[ 0 ];
			} else if ( "End" === event.key ) {
				target = open[ open.length - 1 ];
			}

			if ( target ) {
				event.preventDefault();
				select( target );
				target.focus();
			}
		} );
	} );
}

document.querySelectorAll( "[data-tabs]" ).forEach( setup );
