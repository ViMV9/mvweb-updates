document.querySelectorAll("[data-branch-frame]").forEach(function (frame) {
	const box = frame.closest("section") || document;
	const buttons = box.querySelectorAll("[data-branch-map]");

	buttons.forEach(function (button) {
		button.addEventListener("click", function () {
			frame.src = button.getAttribute("data-branch-map");
			buttons.forEach(function (other) {
				other.setAttribute("aria-pressed", other === button ? "true" : "false");
			});
		});
	});
});
