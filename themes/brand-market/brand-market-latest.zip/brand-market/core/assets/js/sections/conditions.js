function plain(text) {
	return text.toLowerCase().replace(/ё/g, "е").trim();
}

document.querySelectorAll("[data-conditions-query]").forEach(function (input) {
	const box = input.closest("[data-conditions-filter]") || input.closest("section") || document;
	const items = box.querySelectorAll("[data-conditions-item]");
	const groups = box.querySelectorAll("[data-conditions-group]");
	const empty = box.querySelector("[data-conditions-empty]");

	input.addEventListener("input", function () {
		const query = plain(input.value);
		let shown = 0;

		items.forEach(function (item) {
			const hit = "" === query || plain(item.textContent).includes(query);

			item.hidden = !hit;
			shown += hit ? 1 : 0;
		});
		groups.forEach(function (group) {
			group.hidden = !group.querySelector("[data-conditions-item]:not([hidden])");
		});

		if (empty) {
			empty.hidden = 0 !== shown;
		}
	});
});
