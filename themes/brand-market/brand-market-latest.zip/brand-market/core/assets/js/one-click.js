const dialog = document.querySelector( "[data-one-click]" );
const order = dialog ? dialog.querySelector( "[data-one-click-form]" ) : null;

function view( name ) {
	dialog.querySelectorAll( "[data-view]" ).forEach( function ( item ) {
		item.hidden = item.getAttribute( "data-view" ) !== name;
	} );
}

function fail( error, send, text ) {
	error.textContent = text;
	error.hidden = false;
	send.disabled = false;
}

if ( order && typeof dialog.showModal === "function" ) {
	const error = dialog.querySelector( "[data-one-click-error]" );
	const send = order.querySelector( '[type="submit"]' );

	document.addEventListener( "click", function ( event ) {
		if ( ! event.target.closest( "[data-one-click-open]" ) ) {
			return;
		}

		const qty = document.querySelector( 'form.cart [name="quantity"]' );
		const amount = qty ? Math.max( 1, parseInt( qty.value, 10 ) || 1 ) : 1;

		order.elements.quantity.value = amount;
		dialog.querySelector( "[data-one-click-qty]" ).textContent = amount;
		error.hidden = true;
		view( "form" );
		dialog.showModal();
	} );

	dialog.addEventListener( "click", function ( event ) {
		if ( event.target === dialog || event.target.closest( "[data-one-click-close]" ) ) {
			dialog.close();
		}
	} );

	order.addEventListener( "submit", function ( event ) {
		const headers = { "Content-Type": "application/json" };
		const nonce = order.getAttribute( "data-nonce" );

		event.preventDefault();
		error.hidden = true;
		send.disabled = true;

		if ( nonce ) {
			headers[ "X-WP-Nonce" ] = nonce;
		}

		fetch( order.getAttribute( "data-endpoint" ), {
			method: "POST",
			credentials: "same-origin",
			headers: headers,
			body: JSON.stringify( Object.fromEntries( new FormData( order ) ) )
		} ).then( function ( response ) {
			return response.json().then( function ( data ) {
				if ( ! response.ok ) {
					fail( error, send, data.message || error.getAttribute( "data-offline" ) );
					return;
				}

				dialog.querySelector( "[data-one-click-number]" ).textContent = data.number;
				order.reset();
				send.disabled = false;
				view( "ok" );
			} );
		} ).catch( function () {
			fail( error, send, error.getAttribute( "data-offline" ) );
		} );
	} );
}
