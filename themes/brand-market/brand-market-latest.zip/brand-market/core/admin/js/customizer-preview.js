( function ( api ) {
	"use strict";

	const data = window.mvwebCorePreview || {};

	function value( item, raw ) {
		let next = true === raw ? "on" : false === raw ? "off" : String( null === raw || undefined === raw ? "" : raw );

		if ( item.values && item.values.length && -1 === item.values.indexOf( next ) ) {
			next = item.values[ 0 ];
		}

		return next;
	}

	( data.attrs || [] ).forEach( function ( item ) {
		api( item.setting, function ( setting ) {
			setting.bind( function ( raw ) {
				const next = value( item, raw );

				if ( "" === next ) {
					document.documentElement.removeAttribute( item.attr );
					return;
				}

				document.documentElement.setAttribute( item.attr, next );
			} );
		} );
	} );
}( wp.customize ) );
