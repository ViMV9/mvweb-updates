jQuery(function ($) {
	"use strict";

	var data = window.mvwebCoreTermOrder;
	var list = $("#the-list");

	if (!data || !list.length || list.find("tr.no-items").length) {
		return;
	}

	var hint = $("<p>", { "class": "description" }).text(data.hint).insertBefore(list.closest("table"));
	var family = [];

	function level(row) {
		var match = row.className.match(/level-(\d+)/);

		return match ? Number(match[1]) : 0;
	}

	function parentOf(row) {
		return $("#inline_" + row.id.replace("tag-", "") + " .parent").text().trim() || "0";
	}

	function descendants(row) {
		var rows = [];
		var next = row.nextElementSibling;

		while (next && level(next) > level(row)) {
			rows.push(next);
			next = next.nextElementSibling;
		}

		return rows;
	}

	list.sortable({
		items: "> tr",
		axis: "y",
		cursor: "move",
		cancel: "a, input, button, label",
		start: function (event, ui) {
			family = $(descendants(ui.item[0])).detach();
		},
		stop: function (event, ui) {
			var row = ui.item[0];
			var parent = parentOf(row);
			var up = row.previousElementSibling;
			var after = row.nextElementSibling;

			while (up && level(up) >= level(row)) {
				up = up.previousElementSibling;
			}

			if ((up ? up.id.replace("tag-", "") : "0") !== parent || (after && level(after) > level(row))) {
				list.sortable("cancel");
				$(row).after(family);

				return;
			}

			$(row).after(family);

			var ids = list.children("tr").filter(function () {
				return level(this) === level(row) && parentOf(this) === parent;
			}).map(function () {
				return this.id.replace("tag-", "");
			}).get();

			$.post(window.ajaxurl, {
				action: "mvweb_term_order",
				_ajax_nonce: data.nonce,
				taxonomy: data.taxonomy,
				ids: ids.join(",")
			}).fail(function () {
				hint.addClass("notice notice-error").text(data.failed);
			});
		}
	});
});
