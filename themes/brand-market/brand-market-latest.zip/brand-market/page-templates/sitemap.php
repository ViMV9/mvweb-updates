<?php
/**
 * Template Name: Sitemap
 *
 * The map for people: every section of the site with its entries, in the look,
 * the kinds and the order set in the Customizer. Every link is in the markup.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_map   = mvweb_core_sitemap();
$mvweb_title = mvweb_core_alt_h1();

if ( '' === $mvweb_title ) {
	$mvweb_title = get_the_title();
}

get_header();

get_template_part(
	'template-parts/page-hero',
	null,
	array(
		'title'    => $mvweb_title,
		'lead'     => has_excerpt() ? get_the_excerpt() : '',
		'image_id' => get_post_thumbnail_id(),
		'meta'     => $mvweb_map['types'] ? $mvweb_map['meta'] : array(),
	)
);
?>

<section class="mvweb-t-section mvweb-t-section--flush-top">
	<div class="mvweb-t-container">
		<?php
		if ( $mvweb_map['types'] ) {
			get_template_part( 'template-parts/sitemap/' . $mvweb_map['view'], null, $mvweb_map );
		} else {
			get_template_part(
				'template-parts/empty',
				null,
				array(
					'icon'  => 'map',
					'title' => __( 'The map is empty for now', 'brand-market' ),
					'text'  => __( 'The sections of the site will appear here as soon as they have pages.', 'brand-market' ),
				)
			);
		}
		?>
	</div>
</section>

<?php
get_footer();
