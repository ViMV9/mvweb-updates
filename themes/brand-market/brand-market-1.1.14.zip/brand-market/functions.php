<?php
/**
 * Theme bootstrap.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'MVWEB_THEME_VERSION', '1.1.14' );
define( 'MVWEB_THEME_DIR', get_template_directory() );
define( 'MVWEB_THEME_URI', get_template_directory_uri() );

require_once MVWEB_THEME_DIR . '/core/bootstrap.php';
require_once MVWEB_THEME_DIR . '/inc/customizer/kit/bootstrap.php';

require_once MVWEB_THEME_DIR . '/inc/theme/design.php';
require_once MVWEB_THEME_DIR . '/inc/theme/setup.php';
require_once MVWEB_THEME_DIR . '/inc/theme/helpers.php';
require_once MVWEB_THEME_DIR . '/inc/theme/icons.php';
require_once MVWEB_THEME_DIR . '/inc/theme/nav.php';
require_once MVWEB_THEME_DIR . '/inc/theme/search.php';
require_once MVWEB_THEME_DIR . '/inc/theme/assets.php';
require_once MVWEB_THEME_DIR . '/inc/theme/sections.php';
require_once MVWEB_THEME_DIR . '/inc/theme/zones-header.php';
require_once MVWEB_THEME_DIR . '/inc/theme/places.php';
require_once MVWEB_THEME_DIR . '/inc/theme/zones-footer.php';
require_once MVWEB_THEME_DIR . '/inc/theme/updates.php';

if ( class_exists( 'WooCommerce' ) ) {
	require_once MVWEB_THEME_DIR . '/inc/theme/woocommerce.php';
}

foreach ( (array) glob( MVWEB_THEME_DIR . '/inc/theme/modules/*.php' ) as $mvweb_theme_module ) {
	require_once $mvweb_theme_module;
}
unset( $mvweb_theme_module );
