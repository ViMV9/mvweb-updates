<?php
/**
 * The band of the header "Portal": the primary menu as icons, and on the pages of the whole band the search and the quick cards.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_mode  = isset( $args['mode'] ) && 'full' === $args['mode'] ? 'full' : 'icons';
$mvweb_tree  = mvweb_core_menu_tree( 'primary' );
$mvweb_cards = array();

if ( 'full' === $mvweb_mode ) {
	$mvweb_quick = mvweb_core_menu_tree( 'portal-cards' );
	$mvweb_cards = empty( $mvweb_quick[0] ) ? array() : array_slice( $mvweb_quick[0], 0, 3 );
}

if ( empty( $mvweb_tree[0] ) && 'full' !== $mvweb_mode ) {
	return;
}

$mvweb_class = 'mvweb-t-portal mvweb-t-portal--' . $mvweb_mode . ( get_theme_mod( 'mvweb_header_portal_fade', true ) ? ' mvweb-t-portal--fade' : '' );
?>
<div class="<?php echo esc_attr( $mvweb_class ); ?>">
	<div class="mvweb-t-container">
		<div class="mvweb-t-portal__band">
			<?php if ( ! empty( $mvweb_tree[0] ) ) : ?>
				<nav class="mvweb-t-portal__nav" aria-label="<?php esc_attr_e( 'Sections', 'brand-market' ); ?>">
					<ul class="mvweb-t-portal__list">
						<?php foreach ( $mvweb_tree[0] as $mvweb_top ) : ?>
							<?php $mvweb_has = ! empty( $mvweb_tree[ $mvweb_top->ID ] ); ?>
							<li class="mvweb-t-portal__item<?php echo $mvweb_has ? ' mvweb-t-portal__item--sub' : ''; ?><?php echo esc_attr( mvweb_core_menu_classes( $mvweb_top ) ); ?>"<?php echo $mvweb_has ? ' data-nav-item' : ''; ?>>
								<a class="mvweb-t-portal__link" <?php echo mvweb_core_menu_href( $mvweb_top->url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped attributes. ?><?php echo mvweb_core_menu_current( $mvweb_top ) ? ' aria-current="page"' : ''; ?><?php echo $mvweb_has ? ' data-nav-link aria-haspopup="true" aria-expanded="false"' : ''; ?>>
									<span class="mvweb-t-portal__icon"><?php echo mvweb_theme_portal_icon( $mvweb_top->ID ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
									<span class="mvweb-t-portal__name"><?php echo esc_html( $mvweb_top->title ); ?></span>
								</a>
								<?php
								if ( $mvweb_has ) {
									mvweb_theme_portal_sub( $mvweb_tree, $mvweb_top );
								}
								?>
							</li>
						<?php endforeach; ?>
					</ul>
				</nav>
			<?php endif; ?>

			<?php if ( 'full' === $mvweb_mode ) : ?>
				<div class="mvweb-t-portal__find">
					<?php echo mvweb_theme_search_field( 'portal' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts, or by the renderer of the plugin. ?>

					<?php if ( ! empty( $mvweb_cards ) ) : ?>
						<ul class="mvweb-t-portal__cards">
							<?php foreach ( $mvweb_cards as $mvweb_card ) : ?>
								<?php $mvweb_note = trim( (string) $mvweb_card->description ); ?>
								<li>
									<a class="mvweb-t-portal__card" <?php echo mvweb_core_menu_href( $mvweb_card->url, false ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped attributes. ?>>
										<span class="mvweb-t-portal__card-icon"><?php echo mvweb_theme_portal_icon( $mvweb_card->ID ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?></span>
										<span class="mvweb-t-portal__card-text">
											<span class="mvweb-t-portal__card-title"><?php echo esc_html( $mvweb_card->title ); ?></span>
											<?php if ( '' !== $mvweb_note ) : ?>
												<span class="mvweb-t-portal__card-note"><?php echo esc_html( $mvweb_note ); ?></span>
											<?php endif; ?>
										</span>
										<?php echo mvweb_theme_icon( 'chevron-right', array( 'class' => 'mvweb-t-icon--sm mvweb-t-portal__card-go' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
									</a>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>
