<?php
/**
 * Zone element: Search field.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_zone = isset( $args['zone'] ) ? $args['zone'] : '';

if ( 'header-main' === $mvweb_zone && in_array( mvweb_theme_portal_mode(), array( 'full', 'icons' ), true ) ) {
	return;
}

echo mvweb_theme_search_field( 'header-nav' === $mvweb_zone ? 'nav' : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Built from escaped parts, or by the renderer of the plugin.
