<?php
/**
 * Zone element: the button of the menu with icons in the header "Portal", on the pages without the band.
 *
 * The panel is the panel of the catalogue button built from the primary menu:
 * the items are the tabs with their icons, their children the columns, and
 * the children of those the links.
 *
 * @package MVweb_Theme
 *
 * @since 0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( 'row' !== mvweb_theme_portal_mode() ) {
	return;
}

$mvweb_tree = mvweb_core_menu_tree( 'primary' );

if ( empty( $mvweb_tree[0] ) ) {
	return;
}

$mvweb_label = trim( (string) get_theme_mod( 'mvweb_catalog_button_label', '' ) );
$mvweb_label = '' === $mvweb_label ? __( 'All sections', 'brand-market' ) : $mvweb_label;
?>
<div class="mvweb-t-el-portal-menu mvweb-t-header__catalog-box" data-nav-item>
	<button class="mvweb-t-header__catalog" type="button" data-nav-link aria-haspopup="true" aria-expanded="false" aria-controls="mvweb-t-portal-mega">
		<?php echo mvweb_theme_icon( 'layout-grid', array( 'class' => 'mvweb-t-icon--sm' ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Helper returns escaped markup. ?>
		<?php echo esc_html( $mvweb_label ); ?>
	</button>
	<?php mvweb_theme_mega_panel( mvweb_theme_mega_items( $mvweb_tree ), $mvweb_label, 'mvweb-t-portal-mega' ); ?>
</div>
