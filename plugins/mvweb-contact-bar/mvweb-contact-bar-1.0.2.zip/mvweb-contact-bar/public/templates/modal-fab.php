<?php
/**
 * Custom modal template: FAB (Material Design FAB Rows).
 *
 * Available variables (set by MVweb_CB_Frontend::render_modals):
 *   $cb_contacts     — array of resolved contacts
 *   $cb_btn          — button config
 *   $cb_settings     — full plugin settings
 *   $cb_branches_map — branches keyed by id
 *   $cb_icon         — button icon HTML (SVG)
 *   $cb_nofollow     — bool, add rel="nofollow"
 *
 * @package MVweb_Contact_Bar
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

$type  = $cb_btn['type'] ?? 'custom';
$color = ! empty( $cb_btn['color'] ) ? $cb_btn['color'] : MVweb_CB_Icons::get_brand_color( $type );
?>
<div class="mvweb-cb-modal__branches mvweb-cb-fab-list">
	<?php foreach ( $cb_contacts as $contact ) :
		$branch    = $cb_branches_map[ $contact['branch_id'] ?? '' ] ?? array();
		$url       = $contact['url'] ?? '';
		$target    = '';
		$rel_parts = array();

		if ( ! str_starts_with( $url, 'tel:' ) && ! str_starts_with( $url, 'mailto:' ) ) {
			$target      = '_blank';
			$rel_parts[] = 'noopener';
			$rel_parts[] = 'noreferrer';
		}
		if ( $cb_nofollow ) {
			$rel_parts[] = 'nofollow';
		}
		$rel = implode( ' ', $rel_parts );
	?>
	<div class="mvweb-cb-fab-row">
		<span class="mvweb-cb-fab-row__fab" style="background-color:<?php echo esc_attr( $color ); ?>" aria-hidden="true">
			<?php echo $cb_icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		</span>

		<span class="mvweb-cb-fab-row__info">
			<?php if ( ! empty( $branch['address'] ) ) : ?>
				<span class="mvweb-cb-fab-row__addr"><?php echo esc_html( $branch['address'] ); ?></span>
			<?php elseif ( ! empty( $branch['name'] ) ) : ?>
				<span class="mvweb-cb-fab-row__addr"><?php echo esc_html( $branch['name'] ); ?></span>
			<?php endif; ?>
			<?php if ( ! empty( $branch['hours'] ) ) : ?>
				<span class="mvweb-cb-fab-row__hours"><?php echo esc_html( $branch['hours'] ); ?></span>
			<?php endif; ?>
		</span>

		<a class="mvweb-cb-fab-row__contact"
		   href="<?php echo esc_url( $url, MVweb_CB_Settings::URL_SCHEMES ); ?>"
		   <?php echo $target ? 'target="' . esc_attr( $target ) . '"' : ''; ?>
		   <?php echo $rel ? 'rel="' . esc_attr( $rel ) . '"' : ''; ?>
		   data-mvweb-cb-type="<?php echo esc_attr( $type ); ?>"
		   data-mvweb-cb-btn-id="<?php echo esc_attr( $cb_btn['id'] ); ?>"
		   data-mvweb-cb-branch-id="<?php echo esc_attr( $contact['branch_id'] ?? '' ); ?>">
			<?php echo $cb_icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<span><?php echo esc_html( $contact['display_text'] ?? '' ); ?></span>
		</a>
	</div>
	<?php endforeach; ?>
</div>
