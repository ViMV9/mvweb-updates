<?php
/**
 * Custom modal template: Timeline (Accent Strip).
 *
 * Available variables (set by MVweb_CB_Frontend::render_modals):
 *   $cb_contacts     — array of resolved contacts
 *   $cb_btn          — button config
 *   $cb_settings     — full plugin settings
 *   $cb_branches_map — branches keyed by id
 *   $cb_icon         — button icon HTML (SVG)
 *   $cb_nofollow     — bool, add rel="nofollow"
 *
 * @package MVweb_Contact_Bar
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

$type  = $cb_btn['type'] ?? 'custom';
$color = ! empty( $cb_btn['color'] ) ? $cb_btn['color'] : MVweb_CB_Icons::get_brand_color( $type );

$accent_colors = array( '#7c3aed', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444' );
$handle_color  = 'service' === ( $cb_settings['handle_color_mode'] ?? 'service' ) ? $color : 'inherit';
$i = 0;
?>
<div class="mvweb-cb-modal__branches mvweb-cb-modal__tl-list">
	<?php foreach ( $cb_contacts as $contact ) :
		$branch      = $cb_branches_map[ $contact['branch_id'] ?? '' ] ?? array();
		$url         = $contact['url'] ?? '';
		$target      = '';
		$rel_parts   = array();

		if ( ! str_starts_with( $url, 'tel:' ) && ! str_starts_with( $url, 'mailto:' ) ) {
			$target      = '_blank';
			$rel_parts[] = 'noopener';
			$rel_parts[] = 'noreferrer';
		}
		if ( $cb_nofollow ) {
			$rel_parts[] = 'nofollow';
		}
		$rel         = implode( ' ', $rel_parts );
		$accent      = $accent_colors[ $i % count( $accent_colors ) ];
		$i++;
	?>
	<div class="mvweb-cb-tl-item">
		<div class="mvweb-cb-tl-item__strip" style="background:<?php echo esc_attr( $accent ); ?>" aria-hidden="true"></div>
		<div class="mvweb-cb-tl-item__info">
			<?php if ( ! empty( $branch['address'] ) ) : ?>
				<span class="mvweb-cb-tl-item__addr"><?php echo esc_html( $branch['address'] ); ?></span>
			<?php elseif ( ! empty( $branch['name'] ) ) : ?>
				<span class="mvweb-cb-tl-item__addr"><?php echo esc_html( $branch['name'] ); ?></span>
			<?php endif; ?>

			<a class="mvweb-cb-tl-item__contact"
			   href="<?php echo esc_url( $url, MVweb_CB_Settings::URL_SCHEMES ); ?>"
			   style="color:<?php echo esc_attr( $handle_color ); ?>"
			   <?php echo $target ? 'target="' . esc_attr( $target ) . '"' : ''; ?>
			   <?php echo $rel ? 'rel="' . esc_attr( $rel ) . '"' : ''; ?>
			   data-mvweb-cb-type="<?php echo esc_attr( $type ); ?>"
			   data-mvweb-cb-btn-id="<?php echo esc_attr( $cb_btn['id'] ); ?>"
			   data-mvweb-cb-branch-id="<?php echo esc_attr( $contact['branch_id'] ?? '' ); ?>">
				<span class="mvweb-cb-tl-item__contact-icon" aria-hidden="true"><?php echo $cb_icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<span><?php echo esc_html( $contact['display_text'] ?? '' ); ?></span>
			</a>

			<?php if ( ! empty( $branch['hours'] ) ) : ?>
				<span class="mvweb-cb-tl-item__hours">
					<span class="mvweb-cb-tl-item__hours-icon" aria-hidden="true"><?php echo MVweb_CB_Icons::get_utility( 'clock' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<?php echo esc_html( $branch['hours'] ); ?>
				</span>
			<?php endif; ?>
		</div>
	</div>
	<?php endforeach; ?>
</div>
