/**
 * MVweb Contact Bar — Frontend JavaScript
 *
 * Vanilla JS (no jQuery). IIFE pattern.
 * Handles: panel visibility, scroll, delay, collapse, modals, analytics, a11y.
 *
 * @package MVweb_Contact_Bar
 * @since   1.0.0
 */

( function() {
	'use strict';

	/* =========================================================
	   CONFIG (from wp_localize_script)
	   ========================================================= */

	var cfg = window.mvwebCbConfig || {};

	var HIDE_ON_SCROLL     = !! cfg.hideOnScroll;
	var DELAY_SECONDS      = parseInt( cfg.delaySeconds, 10 )  || 0;
	var DELAY_SCROLL_PX    = parseInt( cfg.delayScrollPx, 10 ) || 0;
	var ENTRANCE_ANIMATION = cfg.entranceAnimation || 'slide_up';
	var ALLOW_COLLAPSE     = !! cfg.allowCollapse;
	var GA_ENABLED         = !! cfg.gaEnabled;
	var YM_ENABLED         = !! cfg.ymEnabled;
	var YM_COUNTER_ID      = parseInt( cfg.ymCounterId, 10 )   || 0;
	var REDUCED_MOTION     = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;
	var ANIM_DURATION      = REDUCED_MOTION ? 0 : 350;
	var I18N               = cfg.i18n || {};

	/* =========================================================
	   STATE
	   ========================================================= */

	var panel          = null;
	var isVisible      = false;
	var isCollapsed    = false;
	var activeModal    = null;
	var lastTrigger    = null;
	var lastScrollY    = 0;
	var rafScheduled   = false;
	var delayMet       = false;
	var hiddenByBottom = false;
	var BOTTOM_THRESHOLD = 50; // px from bottom to re-show bar.

	/* =========================================================
	   INIT
	   ========================================================= */

	function init() {
		panel = document.getElementById( 'mvweb-contact-bar' );
		if ( ! panel ) {
			return;
		}

		// Set entrance animation data attribute for CSS.
		panel.setAttribute( 'data-entrance', ENTRANCE_ANIMATION );

		// Start hidden — delay/scroll triggers reveal.
		panel.classList.add( 'mvweb-cb--hidden' );

		// Collapse: restore from localStorage.
		if ( ALLOW_COLLAPSE ) {
			initCollapse();
		}

		// Scroll behaviour: always listen (bottom-hide), optionally hide on scroll direction.
		lastScrollY = window.pageYOffset;
		document.addEventListener( 'scroll', onScroll, { passive: true } );

		// Delay logic.
		initDelay();

		// Event delegation.
		document.addEventListener( 'click', onDocumentClick );
		document.addEventListener( 'keydown', onDocumentKeydown );
	}

	/* =========================================================
	   PANEL VISIBILITY
	   ========================================================= */

	function showPanel() {
		if ( isVisible ) {
			return;
		}
		isVisible = true;

		panel.classList.add( 'mvweb-cb--animating' );
		panel.classList.remove( 'mvweb-cb--hidden' );

		setTimeout( function() {
			panel.classList.remove( 'mvweb-cb--animating' );
		}, ANIM_DURATION + 50 );
	}

	function hidePanel() {
		if ( ! isVisible ) {
			return;
		}
		isVisible = false;

		panel.classList.add( 'mvweb-cb--animating' );
		panel.classList.add( 'mvweb-cb--hidden' );

		setTimeout( function() {
			panel.classList.remove( 'mvweb-cb--animating' );
		}, ANIM_DURATION + 50 );
	}

	/* =========================================================
	   DELAY LOGIC
	   ========================================================= */

	function initDelay() {
		var timeReady   = DELAY_SECONDS   <= 0;
		var scrollReady = DELAY_SCROLL_PX <= 0;

		if ( timeReady && scrollReady ) {
			delayMet = true;
			showPanel();
			return;
		}

		function checkDelayMet() {
			if ( ( DELAY_SECONDS <= 0 || timeReady ) && ( DELAY_SCROLL_PX <= 0 || scrollReady ) ) {
				delayMet = true;
				showPanel();
			}
		}

		// Time delay.
		if ( DELAY_SECONDS > 0 ) {
			setTimeout( function() {
				timeReady = true;
				checkDelayMet();
			}, DELAY_SECONDS * 1000 );
		}

		// Scroll distance delay.
		if ( DELAY_SCROLL_PX > 0 ) {
			var scrollHandler = function() {
				if ( window.pageYOffset >= DELAY_SCROLL_PX ) {
					scrollReady = true;
					document.removeEventListener( 'scroll', scrollHandler );
					checkDelayMet();
				}
			};
			document.addEventListener( 'scroll', scrollHandler, { passive: true } );
		}
	}

	/* =========================================================
	   SCROLL BEHAVIOUR (rAF throttle — max 1x per frame)
	   ========================================================= */

	function onScroll() {
		if ( ! rafScheduled ) {
			rafScheduled = true;
			requestAnimationFrame( processScroll );
		}
	}

	function processScroll() {
		rafScheduled = false;

		if ( ! delayMet ) {
			return;
		}

		var currentY      = window.pageYOffset;
		var delta         = currentY - lastScrollY;
		var docHeight     = document.documentElement.scrollHeight;
		var viewportH     = window.innerHeight;
		var distFromBottom = docHeight - currentY - viewportH;

		lastScrollY = currentY;

		// Hide bar when user reaches page bottom.
		if ( distFromBottom <= 0 ) {
			if ( ! hiddenByBottom ) {
				hiddenByBottom = true;
				hidePanel();
			}
			return;
		}

		// Re-show bar when scrolled 50px up from bottom.
		if ( hiddenByBottom ) {
			if ( distFromBottom >= BOTTOM_THRESHOLD ) {
				hiddenByBottom = false;
				showPanel();
			}
			return;
		}

		// Normal scroll direction behaviour (optional).
		if ( HIDE_ON_SCROLL ) {
			if ( delta > 8 ) {
				hidePanel();
			} else if ( delta < -4 ) {
				showPanel();
			}
		}
	}

	/* =========================================================
	   COLLAPSE / EXPAND
	   ========================================================= */

	var STORAGE_KEY = 'mvweb_cb_collapsed';

	function initCollapse() {
		var stored = false;
		try {
			stored = localStorage.getItem( STORAGE_KEY ) === '1';
		} catch ( e ) {
			// localStorage blocked (Safari private mode, some incognito).
		}

		if ( stored ) {
			collapsePanel( false );
		}

		var toggleBtn = panel.querySelector( '.mvweb-cb__toggle' );
		if ( toggleBtn ) {
			toggleBtn.addEventListener( 'click', function() {
				if ( isCollapsed ) {
					expandPanel();
				} else {
					collapsePanel( true );
				}
			} );
		}
	}

	function collapsePanel( save ) {
		isCollapsed = true;
		panel.classList.add( 'mvweb-cb--collapsed' );

		var toggleBtn = panel.querySelector( '.mvweb-cb__toggle' );
		if ( toggleBtn ) {
			toggleBtn.setAttribute( 'aria-expanded', 'false' );
			toggleBtn.setAttribute( 'aria-label', I18N.expand || 'Expand contact bar' );
		}

		if ( save ) {
			try {
				localStorage.setItem( STORAGE_KEY, '1' );
			} catch ( e ) { /* noop */ }
		}
	}

	function expandPanel() {
		isCollapsed = false;
		panel.classList.remove( 'mvweb-cb--collapsed' );

		var toggleBtn = panel.querySelector( '.mvweb-cb__toggle' );
		if ( toggleBtn ) {
			toggleBtn.setAttribute( 'aria-expanded', 'true' );
			toggleBtn.setAttribute( 'aria-label', I18N.collapse || 'Collapse contact bar' );
		}

		try {
			localStorage.removeItem( STORAGE_KEY );
		} catch ( e ) { /* noop */ }
	}

	/* =========================================================
	   MODAL
	   ========================================================= */

	function openModal( btnId, triggerElement ) {
		var overlay = document.getElementById( 'mvweb-cb-modal-' + btnId );
		if ( ! overlay ) {
			return;
		}

		activeModal = overlay;
		lastTrigger = triggerElement;

		// Remove hidden, then animate on next frame.
		overlay.removeAttribute( 'hidden' );
		overlay.setAttribute( 'aria-hidden', 'false' );

		requestAnimationFrame( function() {
			overlay.classList.add( 'mvweb-cb-overlay--active' );
		} );

		// Scroll lock with scrollbar compensation.
		var scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
		document.body.style.paddingRight = scrollbarWidth + 'px';
		document.body.classList.add( 'mvweb-cb-scroll-lock' );

		// Focus close button after animation.
		var modal = overlay.querySelector( '.mvweb-cb-modal' );
		setTimeout( function() {
			var closeBtn = overlay.querySelector( '.mvweb-cb-modal__close' );
			if ( closeBtn ) {
				closeBtn.focus();
			} else if ( modal ) {
				modal.focus();
			}
		}, REDUCED_MOTION ? 0 : ANIM_DURATION );

		trackEvent( 'contact_bar_modal_open', { button: btnId, action: 'modal_open' } );
	}

	function closeModal() {
		if ( ! activeModal ) {
			return;
		}

		var overlay = activeModal;
		var modal   = overlay.querySelector( '.mvweb-cb-modal' );

		overlay.classList.remove( 'mvweb-cb-overlay--active' );
		overlay.classList.add( 'mvweb-cb-overlay--closing' );

		var done = false;

		function cleanup() {
			if ( done ) {
				return;
			}
			done = true;

			overlay.classList.remove( 'mvweb-cb-overlay--closing' );
			overlay.setAttribute( 'hidden', '' );
			overlay.setAttribute( 'aria-hidden', 'true' );

			document.body.style.paddingRight = '';
			document.body.classList.remove( 'mvweb-cb-scroll-lock' );

			activeModal = null;

			// Return focus to trigger button.
			if ( lastTrigger ) {
				lastTrigger.focus();
				lastTrigger = null;
			}
		}

		if ( REDUCED_MOTION ) {
			cleanup();
			return;
		}

		var timeout = setTimeout( cleanup, ANIM_DURATION + 100 );

		if ( modal ) {
			modal.addEventListener( 'transitionend', function handler( e ) {
				if ( e.target !== modal ) {
					return;
				}
				if ( e.propertyName !== 'opacity' && e.propertyName !== 'transform' ) {
					return;
				}
				clearTimeout( timeout );
				modal.removeEventListener( 'transitionend', handler );
				cleanup();
			} );
		}
	}

	/* =========================================================
	   FOCUS TRAP (for modals)
	   ========================================================= */

	var FOCUSABLE_SELECTOR =
		'a[href], button:not([disabled]), textarea:not([disabled]), ' +
		'input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';

	function getFocusableElements( container ) {
		return Array.prototype.slice.call(
			container.querySelectorAll( FOCUSABLE_SELECTOR )
		).filter( function( el ) {
			return el.offsetWidth > 0 && el.offsetHeight > 0;
		} );
	}

	function trapFocus( e, container ) {
		var focusable = getFocusableElements( container );
		if ( focusable.length === 0 ) {
			e.preventDefault();
			return;
		}

		var first = focusable[0];
		var last  = focusable[ focusable.length - 1 ];

		if ( e.shiftKey && document.activeElement === first ) {
			e.preventDefault();
			last.focus();
		} else if ( ! e.shiftKey && document.activeElement === last ) {
			e.preventDefault();
			first.focus();
		}
	}

	/* =========================================================
	   EVENT DELEGATION
	   ========================================================= */

	function onDocumentClick( e ) {
		// Modal trigger (panel button with data-mvweb-cb-modal).
		var modalTrigger = e.target.closest( '[data-mvweb-cb-modal]' );
		if ( modalTrigger ) {
			e.preventDefault();
			openModal( modalTrigger.getAttribute( 'data-mvweb-cb-modal' ), modalTrigger );
			return;
		}

		// Close (X button or backdrop).
		var closeTarget = e.target.closest( '[data-mvweb-cb-close]' );
		if ( closeTarget && activeModal ) {
			closeModal();
			return;
		}

		// Branch card click — track analytics.
		var branchCard = e.target.closest( '.mvweb-cb-branch' );
		if ( branchCard && activeModal ) {
			trackEvent( 'contact_bar_branch_select', {
				button: branchCard.getAttribute( 'data-mvweb-cb-btn-id' ) || '',
				type:   branchCard.getAttribute( 'data-mvweb-cb-type' ) || '',
				branch: branchCard.getAttribute( 'data-mvweb-cb-branch-id' ) || '',
				action: 'branch_select',
			} );
			// Let the <a> follow its href natively.
			return;
		}

		// Direct action button click (not modal trigger).
		var directBtn = e.target.closest( '.mvweb-cb__btn:not([data-mvweb-cb-modal])' );
		if ( directBtn ) {
			var btnType = directBtn.getAttribute( 'data-mvweb-cb-type' ) || '';
			trackEvent( 'contact_bar_click', { button: btnType, action: 'click' } );
			// Let the <a> follow its href natively.
		}
	}

	function onDocumentKeydown( e ) {
		if ( ! activeModal ) {
			return;
		}

		if ( e.key === 'Escape' ) {
			closeModal();
			return;
		}

		if ( e.key === 'Tab' ) {
			var modal = activeModal.querySelector( '.mvweb-cb-modal' );
			if ( modal ) {
				trapFocus( e, modal );
			}
		}
	}

	/* =========================================================
	   ANALYTICS
	   ========================================================= */

	function trackEvent( eventName, params ) {
		var button = params.button || '';
		var action = params.action || 'click';

		// Google Analytics (gtag).
		if ( GA_ENABLED && typeof window.gtag === 'function' ) {
			window.gtag( 'event', eventName, {
				event_category: 'Contact Bar',
				event_label:    button,
				event_action:   action,
			} );
		}

		// Yandex.Metrika.
		if ( YM_ENABLED && YM_COUNTER_ID && typeof window.ym === 'function' ) {
			window.ym( YM_COUNTER_ID, 'reachGoal', eventName, {
				button: button,
				action: action,
			} );
		}
	}

	/* =========================================================
	   BOOTSTRAP
	   ========================================================= */

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}

} )();
