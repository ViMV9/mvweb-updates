# MVweb Contact Bar

Fixed contact panel (float bar) in Liquid Glass style for WordPress.

## Description

Sticky contact bar at the bottom of the screen with quick action buttons: phone, messengers, social networks, email, and custom links.

**Two button modes:**
- **Direct action** — single contact: click goes straight to call/message
- **Modal window** — multiple contacts (branches): shows a selection dialog

## Requirements

- WordPress 6.4+
- PHP 8.0+

## Installation

1. Upload the `mvweb-contact-bar` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **MVweb Hub > Contact Bar** to configure

## Changelog

See [CHANGELOG.md](CHANGELOG.md)
