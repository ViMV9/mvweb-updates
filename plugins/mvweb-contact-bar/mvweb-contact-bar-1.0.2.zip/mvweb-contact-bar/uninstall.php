<?php
/**
 * Uninstall handler — removes all plugin data from database.
 *
 * @package MVweb_Contact_Bar
 * @since   1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }

// Single site.
delete_option( 'mvweb_cb_settings' );
delete_option( 'mvweb_cb_version' );

// Multisite support.
if ( is_multisite() ) {
	$sites = get_sites( array( 'fields' => 'ids' ) );
	foreach ( $sites as $site_id ) {
		switch_to_blog( $site_id );
		delete_option( 'mvweb_cb_settings' );
		delete_option( 'mvweb_cb_version' );
		restore_current_blog();
	}
}

wp_cache_flush();
