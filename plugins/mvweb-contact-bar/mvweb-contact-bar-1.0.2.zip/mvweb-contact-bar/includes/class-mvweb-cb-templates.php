<?php
/**
 * Registry of available modal templates.
 *
 * Stateless class — no instantiation needed.
 * Filterable via 'mvweb_cb_modal_templates' filter.
 *
 * @package MVweb_Contact_Bar
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class MVweb_CB_Templates {

	/**
	 * Get all registered modal templates (memoized).
	 *
	 * @since 1.1.0
	 * @return array<string, array> slug => definition
	 */
	public static function get_all(): array {
		static $cache = null;
		if ( null !== $cache ) {
			return $cache;
		}

		$built_in = array(
			'classic-glass' => array(
				'slug'                => 'classic-glass',
				'label'               => __( 'Classic Glass', 'mvweb-contact-bar' ),
				'custom_html'         => false,
				'supports_color_mode' => true,
			),
			'frosted-card' => array(
				'slug'                => 'frosted-card',
				'label'               => __( 'Frosted Card', 'mvweb-contact-bar' ),
				'custom_html'         => false,
				'supports_color_mode' => true,
			),
			'map-pin' => array(
				'slug'                => 'map-pin',
				'label'               => __( 'Map Pin', 'mvweb-contact-bar' ),
				'custom_html'         => false,
				'supports_color_mode' => true,
			),
			'dark-neon' => array(
				'slug'                => 'dark-neon',
				'label'               => __( 'Dark Neon', 'mvweb-contact-bar' ),
				'custom_html'         => false,
				'supports_color_mode' => false,
			),
			'soft-pastel' => array(
				'slug'                => 'soft-pastel',
				'label'               => __( 'Soft Pastel', 'mvweb-contact-bar' ),
				'custom_html'         => false,
				'supports_color_mode' => true,
			),
			'bubbles' => array(
				'slug'                => 'bubbles',
				'label'               => __( 'Bubbles', 'mvweb-contact-bar' ),
				'custom_html'         => false,
				'supports_color_mode' => true,
			),
			'neon-row' => array(
				'slug'                => 'neon-row',
				'label'               => __( 'Neon Row', 'mvweb-contact-bar' ),
				'custom_html'         => false,
				'supports_color_mode' => false,
			),
			'timeline' => array(
				'slug'                => 'timeline',
				'label'               => __( 'Timeline', 'mvweb-contact-bar' ),
				'custom_html'         => true,
				'supports_color_mode' => true,
			),
			'large-cta' => array(
				'slug'                => 'large-cta',
				'label'               => __( 'Large CTA', 'mvweb-contact-bar' ),
				'custom_html'         => false,
				'supports_color_mode' => true,
			),
			'spectrum' => array(
				'slug'                => 'spectrum',
				'label'               => __( 'Spectrum', 'mvweb-contact-bar' ),
				'custom_html'         => false,
				'supports_color_mode' => false,
			),
			'email-dark' => array(
				'slug'                => 'email-dark',
				'label'               => __( 'Email Dark', 'mvweb-contact-bar' ),
				'custom_html'         => false,
				'supports_color_mode' => false,
			),
			'fab' => array(
				'slug'                => 'fab',
				'label'               => __( 'FAB', 'mvweb-contact-bar' ),
				'custom_html'         => true,
				'supports_color_mode' => true,
			),
		);

		/**
		 * Filters the list of registered modal templates.
		 *
		 * @since 1.1.0
		 * @param array $templates slug => definition array.
		 */
		$cache = apply_filters( 'mvweb_cb_modal_templates', $built_in );
		return $cache;
	}

	/**
	 * Get single template definition by slug.
	 * Falls back to 'classic-glass'.
	 *
	 * @since 1.1.0
	 * @param string $slug Template slug.
	 * @return array
	 */
	public static function get( string $slug ): array {
		$all = self::get_all();
		return $all[ $slug ] ?? $all['classic-glass'];
	}

	/**
	 * Check whether a slug is registered.
	 *
	 * @since 1.1.0
	 * @param string $slug Template slug.
	 * @return bool
	 */
	public static function is_valid( string $slug ): bool {
		return array_key_exists( $slug, self::get_all() );
	}

	/**
	 * Get slug => label pairs for admin UI.
	 *
	 * @since 1.1.0
	 * @return array<string, string>
	 */
	public static function get_options(): array {
		return array_map(
			fn( $t ) => $t['label'],
			self::get_all()
		);
	}
}
