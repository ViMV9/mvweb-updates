/**
 * MVweb Contact Bar — Admin JavaScript.
 *
 * Tabs navigation, buttons CRUD, drag-and-drop sorting,
 * preset selection dialog, contacts repeater, AJAX save.
 *
 * Note: innerHTML usage is safe here — all HTML content comes from
 * server-side PHP templates (wp_localize_script) or hardcoded SVG icons,
 * never from user input.
 *
 * @package MVweb_Contact_Bar
 * @since   1.0.0
 */

( function() {
	'use strict';

	var config = window.mvwebCbAdmin || {};
	var ALLOWED_TABS = [ 'general', 'branches', 'buttons', 'help' ];

	/* ========================================================================
	   Tabs
	   ======================================================================== */

	function initTabs() {
		var tabs = document.querySelectorAll( '.mvweb-cb-tabs .nav-tab' );
		var contents = document.querySelectorAll( '.mvweb-tab-content' );

		if ( ! tabs.length ) {
			return;
		}

		tabs.forEach( function( tab ) {
			tab.addEventListener( 'click', function( e ) {
				e.preventDefault();
				var tabId = this.getAttribute( 'data-tab' );

				if ( ALLOWED_TABS.indexOf( tabId ) === -1 ) {
					return;
				}

				tabs.forEach( function( t ) {
					t.classList.remove( 'nav-tab-active' );
				} );
				this.classList.add( 'nav-tab-active' );

				contents.forEach( function( c ) {
					c.classList.remove( 'active' );
				} );
				var target = document.getElementById( tabId );
				if ( target ) {
					target.classList.add( 'active' );
				}

				if ( window.history && window.history.pushState ) {
					window.history.pushState( null, '', '#' + tabId );
				}
			} );
		} );

		// Restore from URL hash.
		var hash = window.location.hash.substring( 1 );
		if ( hash && ALLOWED_TABS.indexOf( hash ) !== -1 ) {
			var hashTab = document.querySelector( '.mvweb-cb-tabs .nav-tab[data-tab="' + hash + '"]' );
			if ( hashTab ) {
				hashTab.click();
			}
		}
	}

	/* ========================================================================
	   Toggles
	   ======================================================================== */

	function initToggles() {
		document.addEventListener( 'click', function( e ) {
			var toggle = e.target.closest( '.mvweb-toggle' );
			if ( ! toggle ) {
				return;
			}

			toggle.classList.toggle( 'active' );

			var isActive = toggle.classList.contains( 'active' );

			// Update associated hidden input — buttons.
			var btnItem = toggle.closest( '.mvweb-cb-button-item' );
			if ( btnItem ) {
				var activeInput = btnItem.querySelector( 'input[name$="[active]"]' );
				if ( activeInput ) {
					activeInput.value = isActive ? '1' : '0';
				}
				btnItem.classList.toggle( 'mvweb-cb-button-item--inactive', ! isActive );
				rebuildPreview();
			}

			// Update associated hidden input — branches.
			var branchItem = toggle.closest( '.mvweb-cb-branch-item' );
			if ( branchItem ) {
				var branchActiveInput = branchItem.querySelector( 'input[name$="[active]"]' );
				if ( branchActiveInput ) {
					branchActiveInput.value = isActive ? '1' : '0';
				}
				branchItem.classList.toggle( 'mvweb-cb-branch-item--inactive', ! isActive );
			}

			// General tab toggles — update hidden input by data-toggle name.
			var toggleName = toggle.getAttribute( 'data-toggle' );
			if ( toggleName ) {
				var hiddenInput = toggle.closest( '.mvweb-form-group' )
					? toggle.closest( '.mvweb-form-group' ).querySelector( 'input[name="' + toggleName + '"]' )
					: null;
				if ( hiddenInput ) {
					hiddenInput.value = isActive ? '1' : '0';
				}
			}

			// YM toggle — show/hide counter ID field.
			if ( toggleName === 'ym_enabled' ) {
				var counterGroup = document.getElementById( 'mvweb-cb-ym-counter-group' );
				if ( counterGroup ) {
					counterGroup.classList.toggle( 'mvweb-hidden', ! isActive );
				}
			}
		} );
	}

	/* ========================================================================
	   Buttons list — expand / collapse
	   ======================================================================== */

	function initExpandCollapse() {
		document.addEventListener( 'click', function( e ) {
			// Handle button expand/collapse.
			var expandBtn = e.target.closest( '.mvweb-cb-button-item__expand' );
			if ( expandBtn ) {
				var btnItem = expandBtn.closest( '.mvweb-cb-button-item' );
				if ( btnItem ) {
					var btnBody = btnItem.querySelector( '.mvweb-cb-button-item__body' );
					if ( btnBody ) {
						var isOpen = btnBody.style.display !== 'none';
						btnBody.style.display = isOpen ? 'none' : '';
						expandBtn.classList.toggle( 'dashicons-arrow-down-alt2', isOpen );
						expandBtn.classList.toggle( 'dashicons-arrow-up-alt2', ! isOpen );
					}
				}
				return;
			}

			// Handle branch expand/collapse.
			var branchExpandBtn = e.target.closest( '.mvweb-cb-branch-item__expand' );
			if ( branchExpandBtn ) {
				var branchItem = branchExpandBtn.closest( '.mvweb-cb-branch-item' );
				if ( branchItem ) {
					var branchBody = branchItem.querySelector( '.mvweb-cb-branch-item__body' );
					if ( branchBody ) {
						var brIsOpen = branchBody.style.display !== 'none';
						branchBody.style.display = brIsOpen ? 'none' : '';
						branchExpandBtn.classList.toggle( 'dashicons-arrow-down-alt2', brIsOpen );
						branchExpandBtn.classList.toggle( 'dashicons-arrow-up-alt2', ! brIsOpen );
					}
				}
			}
		} );
	}

	/* ========================================================================
	   Add button — preset dialog
	   ======================================================================== */

	function initAddButton() {
		var addBtn = document.getElementById( 'mvweb-cb-add-button' );
		var dialog = document.getElementById( 'mvweb-cb-preset-dialog' );

		if ( ! addBtn || ! dialog ) {
			return;
		}

		addBtn.addEventListener( 'click', function() {
			dialog.showModal();
		} );

		// Preset option click.
		dialog.addEventListener( 'click', function( e ) {
			var option = e.target.closest( '.mvweb-cb-preset-option' );
			if ( ! option ) {
				return;
			}

			var type  = option.getAttribute( 'data-type' );
			var color = option.getAttribute( 'data-color' );
			var label = option.getAttribute( 'data-label' );

			dialog.close();
			addButtonItem( type, color, label );
		} );

		// Close on backdrop click.
		dialog.addEventListener( 'click', function( e ) {
			if ( e.target === dialog ) {
				dialog.close();
			}
		} );
	}

	/**
	 * Add a new button item to the list.
	 *
	 * Uses server-side PHP templates via script[type="text/html"] elements.
	 * All icon HTML comes from wp_localize_script (trusted server data).
	 *
	 * @param {string} type  Preset type or 'custom'.
	 * @param {string} color Hex color.
	 * @param {string} label Display label.
	 */
	function addButtonItem( type, color, label ) {
		var list = document.getElementById( 'mvweb-cb-buttons-list' );
		if ( ! list ) {
			return;
		}

		// Remove empty state.
		var emptyState = document.getElementById( 'mvweb-cb-buttons-empty' );
		if ( emptyState ) {
			emptyState.remove();
		}

		var index = list.querySelectorAll( '.mvweb-cb-button-item' ).length;
		var btnId = 'btn_' + generateId();

		// Get SVG icon from config (server-generated, trusted).
		var iconHtml = '';
		if ( type !== 'custom' && config.presetIcons && config.presetIcons[ type ] ) {
			iconHtml = config.presetIcons[ type ];
		} else {
			iconHtml = '<span class="dashicons dashicons-admin-links"></span>';
		}

		// Use server-side PHP template.
		var tmpl = document.getElementById( 'tmpl-mvweb-cb-button-item' );
		if ( ! tmpl ) {
			return;
		}

		// Safe: template is from server-side PHP, values are either server
		// data (iconHtml from wp_localize_script) or sanitized below.
		var html = tmpl.textContent
			.replace( /\{\{data\.id\}\}/g, btnId )
			.replace( /\{\{data\.index\}\}/g, index )
			.replace( /\{\{data\.type\}\}/g, escAttr( type ) )
			.replace( /\{\{data\.color\}\}/g, escAttr( color ) )
			.replace( /\{\{data\.label\}\}/g, escHtml( label ) )
			.replace( /\{\{\{data\.iconHtml\}\}\}/g, iconHtml );

		var temp = document.createElement( 'div' );
		temp.innerHTML = html; // Safe: all data is from server-generated templates.
		var newItem = temp.firstElementChild;

		list.appendChild( newItem );

		// Set type in select.
		var typeSelect = newItem.querySelector( '.mvweb-cb-type-select' );
		if ( typeSelect ) {
			typeSelect.value = type;
		}

		// Show custom icon group if custom.
		if ( type === 'custom' ) {
			var customGroup = newItem.querySelector( '.mvweb-cb-custom-icon-group' );
			if ( customGroup ) {
				customGroup.style.display = '';
			}
		}

		// Expand the new item.
		var expandBtn = newItem.querySelector( '.mvweb-cb-button-item__expand' );
		if ( expandBtn ) {
			expandBtn.click();
		}

		// Re-index all buttons.
		reindexButtons();

		// Re-init sortable if available.
		initSortable();

		// Refresh live preview.
		rebuildPreview();
	}

	/* ========================================================================
	   Remove button
	   ======================================================================== */

	function initRemoveButton() {
		document.addEventListener( 'click', function( e ) {
			var removeBtn = e.target.closest( '.mvweb-cb-button-item__remove' );
			if ( ! removeBtn ) {
				return;
			}

			var item = removeBtn.closest( '.mvweb-cb-button-item' );
			if ( ! item ) {
				return;
			}

			if ( ! window.confirm( config.i18n && config.i18n.confirmRemoveButton
				? config.i18n.confirmRemoveButton
				: 'Remove this button?' ) ) {
				return;
			}

			item.remove();
			reindexButtons();

			// Show empty state if no buttons left.
			var list = document.getElementById( 'mvweb-cb-buttons-list' );
			if ( list && ! list.querySelectorAll( '.mvweb-cb-button-item' ).length ) {
				showEmptyState( list );
			}

			// Refresh live preview.
			rebuildPreview();
		} );
	}

	function showEmptyState( list ) {
		var empty = document.createElement( 'div' );
		empty.className = 'mvweb-empty';
		empty.id = 'mvweb-cb-buttons-empty';

		var iconDiv = document.createElement( 'div' );
		iconDiv.className = 'mvweb-empty__icon';
		var iconSpan = document.createElement( 'span' );
		iconSpan.className = 'dashicons dashicons-button';
		iconDiv.appendChild( iconSpan );

		var titleDiv = document.createElement( 'div' );
		titleDiv.className = 'mvweb-empty__title';
		titleDiv.textContent = config.i18n ? config.i18n.noButtons : 'No buttons yet';

		var textDiv = document.createElement( 'div' );
		textDiv.className = 'mvweb-empty__text';
		textDiv.textContent = config.i18n ? config.i18n.addFirst : 'Add your first button to get started.';

		empty.appendChild( iconDiv );
		empty.appendChild( titleDiv );
		empty.appendChild( textDiv );
		list.appendChild( empty );
	}

	/* ========================================================================
	   Contacts repeater
	   ======================================================================== */

	function initContactsRepeater() {
		// Add contact.
		document.addEventListener( 'click', function( e ) {
			var addBtn = e.target.closest( '.mvweb-cb-add-contact' );
			if ( ! addBtn ) {
				return;
			}

			var repeater = addBtn.closest( '.mvweb-cb-contacts-repeater' );
			if ( ! repeater ) {
				return;
			}

			var tbody = repeater.querySelector( 'tbody' );
			if ( ! tbody ) {
				return;
			}

			var btnIndex     = repeater.getAttribute( 'data-index' );
			var contactIndex = tbody.querySelectorAll( '.mvweb-cb-contact-row' ).length;

			var tmpl = document.getElementById( 'tmpl-mvweb-cb-contact-row' );
			if ( ! tmpl ) {
				return;
			}

			// Safe: template is server-generated PHP with no user data.
			var html = tmpl.textContent
				.replace( /\{\{data\.btnIndex\}\}/g, btnIndex )
				.replace( /\{\{data\.contactIndex\}\}/g, contactIndex );

			var temp = document.createElement( 'tbody' );
			temp.innerHTML = html; // Safe: server-generated template with sanitized indices.
			var newRow = temp.querySelector( 'tr' );
			if ( newRow ) {
				tbody.appendChild( newRow );
			}

			updateContactsCount( repeater );
		} );

		// Remove contact.
		document.addEventListener( 'click', function( e ) {
			var removeBtn = e.target.closest( '.mvweb-cb-remove-contact' );
			if ( ! removeBtn ) {
				return;
			}

			var row = removeBtn.closest( '.mvweb-cb-contact-row' );
			if ( ! row ) {
				return;
			}

			var repeater = removeBtn.closest( '.mvweb-cb-contacts-repeater' );
			row.remove();

			if ( repeater ) {
				reindexContacts( repeater );
				updateContactsCount( repeater );
			}
		} );
	}

	function reindexContacts( repeater ) {
		var btnIndex = repeater.getAttribute( 'data-index' );
		var rows = repeater.querySelectorAll( '.mvweb-cb-contact-row' );

		rows.forEach( function( row, ci ) {
			row.querySelectorAll( '[name]' ).forEach( function( el ) {
				var name = el.getAttribute( 'name' );
				// Replace contacts[X] with contacts[ci].
				name = name.replace(
					/\[contacts\]\[\d+\]/,
					'[contacts][' + ci + ']'
				);
				// Also ensure button index is correct.
				name = name.replace(
					/^buttons\[\d+\]/,
					'buttons[' + btnIndex + ']'
				);
				el.setAttribute( 'name', name );
			} );
		} );
	}

	/* ========================================================================
	   Contact row — branch autofill & override logic
	   ======================================================================== */

	/**
	 * Get branch default contact url/display_text by branch ID and button type.
	 *
	 * @param {string} branchId Branch ID.
	 * @param {string} btnType  Button type (phone, telegram, etc.).
	 * @returns {{ url: string, display_text: string }|null}
	 */
	function getBranchDefault( branchId, btnType ) {
		var branches = config.branches || [];
		for ( var i = 0; i < branches.length; i++ ) {
			if ( branches[ i ].id === branchId ) {
				var contacts = branches[ i ].contacts || [];
				for ( var j = 0; j < contacts.length; j++ ) {
					if ( contacts[ j ].type === btnType ) {
						return {
							url: contacts[ j ].url || '',
							display_text: contacts[ j ].display_text || ''
						};
					}
				}
				return null; // Branch found but no contact for this type.
			}
		}
		return null;
	}

	/**
	 * Mark contact row as overridden or not.
	 *
	 * @param {HTMLElement} row         Contact row element.
	 * @param {boolean}     isOverridden Whether to mark as overridden.
	 */
	function setContactOverridden( row, isOverridden ) {
		var overriddenInput = row.querySelector( '.mvweb-cb-contact-overridden' );
		if ( overriddenInput ) {
			overriddenInput.value = isOverridden ? '1' : '0';
		}
		row.classList.toggle( 'mvweb-cb-contact-row--overridden', isOverridden );

		// Show/hide reset button.
		var actionsCell = row.querySelector( '.mvweb-cb-contact-actions' );
		if ( ! actionsCell ) {
			return;
		}
		var resetBtn = actionsCell.querySelector( '.mvweb-cb-reset-contact' );
		if ( isOverridden && ! resetBtn ) {
			// Create reset button.
			resetBtn = document.createElement( 'button' );
			resetBtn.type = 'button';
			resetBtn.className = 'mvweb-btn mvweb-btn--sm mvweb-cb-reset-contact';
			resetBtn.title = config.i18n ? config.i18n.resetToDefault : 'Reset to branch default';
			var resetIcon = document.createElement( 'span' );
			resetIcon.className = 'dashicons dashicons-image-rotate';
			resetBtn.appendChild( resetIcon );
			// Insert before remove button.
			var removeBtn = actionsCell.querySelector( '.mvweb-cb-remove-contact' );
			actionsCell.insertBefore( resetBtn, removeBtn );
		} else if ( ! isOverridden && resetBtn ) {
			resetBtn.remove();
		}
	}

	function initContactBranchAutofill() {
		// Branch select change → autofill url/display_text if not overridden.
		document.addEventListener( 'change', function( e ) {
			var select = e.target.closest( '.mvweb-cb-contact-branch-select' );
			if ( ! select ) {
				return;
			}

			var row       = select.closest( '.mvweb-cb-contact-row' );
			var repeater  = select.closest( '.mvweb-cb-contacts-repeater' );
			if ( ! row || ! repeater ) {
				return;
			}

			var branchId  = select.value;
			var btnType   = repeater.getAttribute( 'data-btn-type' ) || '';
			var urlInput  = row.querySelector( '.mvweb-cb-contact-url' );
			var dtInput   = row.querySelector( '.mvweb-cb-contact-display-text' );
			var isOverridden = row.querySelector( '.mvweb-cb-contact-overridden' );

			if ( ! urlInput || ! dtInput ) {
				return;
			}

			// If not overridden or url is empty → autofill from branch.
			var overrideVal = isOverridden ? isOverridden.value : '0';
			if ( overrideVal !== '1' || ! urlInput.value ) {
				var defaults = branchId ? getBranchDefault( branchId, btnType ) : null;
				if ( defaults ) {
					urlInput.value = defaults.url;
					dtInput.value  = defaults.display_text;
					setContactOverridden( row, false );
				} else {
					// Clear if no default exists.
					if ( overrideVal !== '1' ) {
						urlInput.value = '';
						dtInput.value  = '';
					}
					setContactOverridden( row, false );
				}
			}
		} );

		// URL/display_text manual change → mark as overridden.
		document.addEventListener( 'input', function( e ) {
			var urlInput = e.target.closest( '.mvweb-cb-contact-url' );
			var dtInput  = e.target.closest( '.mvweb-cb-contact-display-text' );
			var target   = urlInput || dtInput;
			if ( ! target ) {
				return;
			}

			var row      = target.closest( '.mvweb-cb-contact-row' );
			var repeater = target.closest( '.mvweb-cb-contacts-repeater' );
			if ( ! row || ! repeater ) {
				return;
			}

			var branchSelect = row.querySelector( '.mvweb-cb-contact-branch-select' );
			var branchId     = branchSelect ? branchSelect.value : '';
			var btnType      = repeater.getAttribute( 'data-btn-type' ) || '';
			var defaults     = branchId ? getBranchDefault( branchId, btnType ) : null;
			var urlVal       = row.querySelector( '.mvweb-cb-contact-url' );
			var dtVal        = row.querySelector( '.mvweb-cb-contact-display-text' );

			// Determine if different from defaults.
			var isOverridden = false;
			if ( defaults ) {
				var currentUrl = urlVal ? urlVal.value : '';
				var currentDt  = dtVal ? dtVal.value : '';
				isOverridden = ( currentUrl !== '' && currentUrl !== defaults.url ) ||
				               ( currentDt !== '' && currentDt !== defaults.display_text );
			} else if ( urlVal && urlVal.value ) {
				// No branch defaults — any value counts as custom.
				isOverridden = true;
			}

			setContactOverridden( row, isOverridden );
		} );

		// Reset contact to branch default.
		document.addEventListener( 'click', function( e ) {
			var resetBtn = e.target.closest( '.mvweb-cb-reset-contact' );
			if ( ! resetBtn ) {
				return;
			}

			var row      = resetBtn.closest( '.mvweb-cb-contact-row' );
			var repeater = resetBtn.closest( '.mvweb-cb-contacts-repeater' );
			if ( ! row || ! repeater ) {
				return;
			}

			var branchSelect = row.querySelector( '.mvweb-cb-contact-branch-select' );
			var branchId     = branchSelect ? branchSelect.value : '';
			var btnType      = repeater.getAttribute( 'data-btn-type' ) || '';
			var defaults     = branchId ? getBranchDefault( branchId, btnType ) : null;

			var urlInput = row.querySelector( '.mvweb-cb-contact-url' );
			var dtInput  = row.querySelector( '.mvweb-cb-contact-display-text' );

			if ( defaults ) {
				if ( urlInput ) {
					urlInput.value = defaults.url;
				}
				if ( dtInput ) {
					dtInput.value = defaults.display_text;
				}
				setContactOverridden( row, false );
			}
		} );
	}

	function updateContactsCount( repeater ) {
		var item = repeater.closest( '.mvweb-cb-button-item' );
		if ( ! item ) {
			return;
		}

		var count   = repeater.querySelectorAll( '.mvweb-cb-contact-row' ).length;
		var counter = item.querySelector( '.mvweb-cb-button-item__contacts-count' );
		if ( counter && config.i18n ) {
			counter.textContent = count + ' ' + ( count === 1
				? ( config.i18n.contact || 'contact' )
				: ( config.i18n.contacts || 'contacts' ) );
		}
	}

	/* ========================================================================
	   Branch contacts repeater (default contacts by type in branch)
	   ======================================================================== */

	function initBranchContactsRepeater() {
		// Add branch contact type row.
		document.addEventListener( 'click', function( e ) {
			var addBtn = e.target.closest( '.mvweb-cb-add-branch-contact' );
			if ( ! addBtn ) {
				return;
			}

			var repeater = addBtn.closest( '.mvweb-cb-branch-contacts-repeater' );
			if ( ! repeater ) {
				return;
			}

			var tbody = repeater.querySelector( 'tbody' );
			if ( ! tbody ) {
				return;
			}

			var branchIndex  = repeater.getAttribute( 'data-index' );
			var contactIndex = tbody.querySelectorAll( '.mvweb-cb-branch-contact-row' ).length;

			var tmpl = document.getElementById( 'tmpl-mvweb-cb-branch-contact-row' );
			if ( ! tmpl ) {
				return;
			}

			var html = tmpl.textContent
				.replace( /\{\{data\.branchIndex\}\}/g, branchIndex )
				.replace( /\{\{data\.contactIndex\}\}/g, contactIndex );

			var temp = document.createElement( 'tbody' );
			temp.innerHTML = html;
			var newRow = temp.querySelector( 'tr' );
			if ( newRow ) {
				tbody.appendChild( newRow );
			}
		} );

		// Remove branch contact row.
		document.addEventListener( 'click', function( e ) {
			var removeBtn = e.target.closest( '.mvweb-cb-remove-branch-contact' );
			if ( ! removeBtn ) {
				return;
			}

			var row = removeBtn.closest( '.mvweb-cb-branch-contact-row' );
			if ( ! row ) {
				return;
			}

			var repeater = removeBtn.closest( '.mvweb-cb-branch-contacts-repeater' );
			row.remove();

			if ( repeater ) {
				reindexBranchContacts( repeater );
			}
		} );
	}

	function reindexBranchContacts( repeater ) {
		var branchIndex = repeater.getAttribute( 'data-index' );
		var rows = repeater.querySelectorAll( '.mvweb-cb-branch-contact-row' );

		rows.forEach( function( row, ci ) {
			row.querySelectorAll( '[name]' ).forEach( function( el ) {
				var name = el.getAttribute( 'name' );
				name = name.replace(
					/\[contacts\]\[\d+\]/,
					'[contacts][' + ci + ']'
				);
				name = name.replace(
					/^branches\[\d+\]/,
					'branches[' + branchIndex + ']'
				);
				el.setAttribute( 'name', name );
			} );
		} );
	}

		/* ========================================================================
	   Type change
	   ======================================================================== */

	function initTypeChange() {
		document.addEventListener( 'change', function( e ) {
			if ( ! e.target.classList.contains( 'mvweb-cb-type-select' ) ) {
				return;
			}

			var select = e.target;
			var item   = select.closest( '.mvweb-cb-button-item' );
			if ( ! item ) {
				return;
			}

			var newType  = select.value;
			var isCustom = newType === 'custom';

			// Update hidden type input.
			var typeHidden = item.querySelector( 'input[name$="[type]"]' );
			if ( typeHidden ) {
				typeHidden.value = newType;
			}

			// Update preview icon (safe: SVG from server config).
			var preview = item.querySelector( '.mvweb-cb-button-item__preview' );
			if ( preview ) {
				var newColor = getPresetColor( newType );
				preview.style.color = newColor;

				if ( ! isCustom && config.presetIcons && config.presetIcons[ newType ] ) {
					preview.innerHTML = config.presetIcons[ newType ]; // Safe: server-generated SVG.
				} else {
					preview.textContent = '';
					var dashicon = document.createElement( 'span' );
					dashicon.className = 'dashicons dashicons-admin-links';
					preview.appendChild( dashicon );
				}
			}

			// Update title.
			var titleEl = item.querySelector( '.mvweb-cb-button-item__title' );
			if ( titleEl ) {
				var newLabel = getPresetLabel( newType );
				titleEl.textContent = newLabel;
			}

			// Update color picker.
			var colorInput = item.querySelector( '.mvweb-cb-color-picker' );
			if ( colorInput ) {
				var brandColor = getPresetColor( newType );
				colorInput.value = brandColor;
				colorInput.setAttribute( 'data-default', brandColor );
			}

			// Show/hide custom icon group.
			var customGroup = item.querySelector( '.mvweb-cb-custom-icon-group' );
			if ( customGroup ) {
				customGroup.style.display = isCustom ? '' : 'none';
			}

			// Refresh live preview.
			rebuildPreview();
		} );
	}

	/* ========================================================================
	   Color reset
	   ======================================================================== */

	function initColorReset() {
		document.addEventListener( 'click', function( e ) {
			var resetBtn = e.target.closest( '.mvweb-cb-reset-color' );
			if ( ! resetBtn ) {
				return;
			}

			var colorInput = resetBtn.previousElementSibling;
			while ( colorInput && ! colorInput.classList.contains( 'mvweb-cb-color-picker' ) ) {
				colorInput = colorInput.previousElementSibling;
			}
			if ( ! colorInput ) {
				return;
			}

			var defaultColor = colorInput.getAttribute( 'data-default' );
			if ( defaultColor ) {
				colorInput.value = defaultColor;
			}

			// Update preview.
			var item = resetBtn.closest( '.mvweb-cb-button-item' );
			if ( item ) {
				var preview = item.querySelector( '.mvweb-cb-button-item__preview' );
				if ( preview ) {
					preview.style.color = defaultColor;
				}
			}
		} );
	}

	/* ========================================================================
	   Custom icon upload (WP Media)
	   ======================================================================== */

	function initMediaUpload() {
		var mediaFrame;

		document.addEventListener( 'click', function( e ) {
			var uploadBtn = e.target.closest( '.mvweb-cb-upload-icon' );
			if ( ! uploadBtn ) {
				return;
			}

			e.preventDefault();

			var uploadGroup = uploadBtn.closest( '.mvweb-cb-icon-upload' );
			if ( ! uploadGroup ) {
				return;
			}

			// Create media frame.
			if ( typeof wp === 'undefined' || typeof wp.media === 'undefined' ) {
				return;
			}

			mediaFrame = wp.media( {
				title: config.i18n ? config.i18n.selectIcon : 'Select Icon',
				button: {
					text: config.i18n ? config.i18n.useImage : 'Use this image'
				},
				multiple: false,
				library: {
					type: 'image'
				}
			} );

			mediaFrame.on( 'select', function() {
				var attachment = mediaFrame.state().get( 'selection' ).first().toJSON();
				var url = attachment.url;

				var urlInput = uploadGroup.querySelector( '.mvweb-cb-custom-icon-url' );
				var thumb    = uploadGroup.querySelector( '.mvweb-cb-custom-icon-thumb' );
				var removeIconBtn = uploadGroup.querySelector( '.mvweb-cb-remove-icon' );

				if ( urlInput ) {
					urlInput.value = url;
				}
				if ( thumb ) {
					thumb.src = url;
					thumb.style.display = '';
				}
				if ( removeIconBtn ) {
					removeIconBtn.style.display = '';
				}

				// Update header preview with img element.
				var item = uploadGroup.closest( '.mvweb-cb-button-item' );
				if ( item ) {
					var preview = item.querySelector( '.mvweb-cb-button-item__preview' );
					if ( preview ) {
						preview.textContent = '';
						var img = document.createElement( 'img' );
						img.src = url;
						img.alt = '';
						img.className = 'mvweb-cb-button-item__custom-icon-preview';
						preview.appendChild( img );
					}
				}
			} );

			mediaFrame.open();
		} );

		// Remove icon.
		document.addEventListener( 'click', function( e ) {
			var removeIconBtn = e.target.closest( '.mvweb-cb-remove-icon' );
			if ( ! removeIconBtn ) {
				return;
			}

			var uploadGroup = removeIconBtn.closest( '.mvweb-cb-icon-upload' );
			if ( ! uploadGroup ) {
				return;
			}

			var urlInput = uploadGroup.querySelector( '.mvweb-cb-custom-icon-url' );
			var thumb    = uploadGroup.querySelector( '.mvweb-cb-custom-icon-thumb' );

			if ( urlInput ) {
				urlInput.value = '';
			}
			if ( thumb ) {
				thumb.src = '';
				thumb.style.display = 'none';
			}
			removeIconBtn.style.display = 'none';

			// Reset header preview.
			var item = removeIconBtn.closest( '.mvweb-cb-button-item' );
			if ( item ) {
				var preview = item.querySelector( '.mvweb-cb-button-item__preview' );
				if ( preview ) {
					preview.textContent = '';
					var dashicon = document.createElement( 'span' );
					dashicon.className = 'dashicons dashicons-admin-links';
					preview.appendChild( dashicon );
				}
			}
		} );
	}

	/* ========================================================================
	   FontAwesome Icon Picker (custom type)
	   ======================================================================== */

	/**
	 * Apply selected FA icon to a button item.
	 *
	 * @param {Element} item    The .mvweb-cb-button-item element.
	 * @param {string}  slug    FA icon slug (e.g. "heart").
	 * @param {string}  svgHtml SVG markup from the FA picker dialog.
	 */
	function applyFaIcon( item, slug, svgHtml ) {
		var slugInput = item.querySelector( '.mvweb-cb-fa-icon-slug' );
		if ( slugInput ) {
			slugInput.value = slug;
		}

		// Update pick button content (safe: SVG from server-rendered dialog DOM).
		var pickBtn = item.querySelector( '.mvweb-cb-pick-fa-icon' );
		if ( pickBtn && svgHtml ) {
			pickBtn.textContent = '';
			var svgWrap = document.createElement( 'span' );
			svgWrap.className = 'mvweb-cb-fa-btn-icon';
			svgWrap.innerHTML = svgHtml; // Safe: SVG from server-rendered PHP template.
			pickBtn.appendChild( svgWrap );
			var nameSpan = document.createElement( 'span' );
			nameSpan.className = 'mvweb-cb-fa-icon-name';
			nameSpan.textContent = slug;
			pickBtn.appendChild( nameSpan );
		}

		// Show remove button.
		var removeBtn = item.querySelector( '.mvweb-cb-remove-fa-icon' );
		if ( removeBtn ) {
			removeBtn.style.display = '';
		} else {
			// Create remove button if not present (template items).
			var wrap = item.querySelector( '.mvweb-cb-fa-picker-wrap' );
			if ( wrap ) {
				var newRemove = document.createElement( 'button' );
				newRemove.type = 'button';
				newRemove.className = 'mvweb-btn mvweb-btn--sm mvweb-cb-remove-fa-icon';
				newRemove.innerHTML = '<span class="dashicons dashicons-no-alt"></span>'; // Safe: hardcoded HTML.
				wrap.insertBefore( newRemove, wrap.querySelector( '.mvweb-cb-icon-or' ) );
			}
		}

		// Update header preview (safe: SVG from server-rendered dialog DOM).
		var preview = item.querySelector( '.mvweb-cb-button-item__preview' );
		if ( preview && svgHtml ) {
			preview.innerHTML = svgHtml; // Safe: SVG from server-rendered PHP template.
		}

		// Clear custom image if any.
		var urlInput = item.querySelector( '.mvweb-cb-custom-icon-url' );
		if ( urlInput ) {
			urlInput.value = '';
		}
		var thumb = item.querySelector( '.mvweb-cb-custom-icon-thumb' );
		if ( thumb ) {
			thumb.src = '';
			thumb.style.display = 'none';
		}
		var removeIcon = item.querySelector( '.mvweb-cb-remove-custom-icon' );
		if ( removeIcon ) {
			removeIcon.style.display = 'none';
		}
	}

	function initFaPicker() {
		var dialog = document.getElementById( 'mvweb-cb-fa-dialog' );
		if ( ! dialog ) {
			return;
		}

		var activeItem = null;
		var searchInput = dialog.querySelector( '.mvweb-cb-fa-search' );
		var allOptions  = dialog.querySelectorAll( '.mvweb-cb-fa-option' );

		// Search filter.
		if ( searchInput ) {
			searchInput.addEventListener( 'input', function() {
				var query = this.value.toLowerCase().trim();
				allOptions.forEach( function( option ) {
					var slug = option.getAttribute( 'data-fa-slug' ) || '';
					option.style.display = slug.indexOf( query ) !== -1 ? '' : 'none';
				} );
			} );
		}

		// Open dialog.
		document.addEventListener( 'click', function( e ) {
			var pickBtn = e.target.closest( '.mvweb-cb-pick-fa-icon' );
			if ( ! pickBtn ) {
				return;
			}

			activeItem = pickBtn.closest( '.mvweb-cb-button-item' );
			if ( ! activeItem ) {
				return;
			}

			// Reset search on open.
			if ( searchInput ) {
				searchInput.value = '';
				allOptions.forEach( function( option ) {
					option.style.display = '';
				} );
			}

			dialog.showModal();

			// Focus search.
			if ( searchInput ) {
				searchInput.focus();
			}
		} );

		// Select FA icon — get SVG from clicked element.
		dialog.addEventListener( 'click', function( e ) {
			var option = e.target.closest( '.mvweb-cb-fa-option' );
			if ( ! option || ! activeItem ) {
				return;
			}

			var slug    = option.getAttribute( 'data-fa-slug' );
			var iconEl  = option.querySelector( '.mvweb-cb-fa-option__icon' );
			var svgHtml = iconEl ? iconEl.innerHTML.trim() : '';

			if ( ! slug || ! svgHtml ) {
				return;
			}

			applyFaIcon( activeItem, slug, svgHtml );
			dialog.close();
			activeItem = null;
		} );

		// Close dialog on backdrop click.
		dialog.addEventListener( 'click', function( e ) {
			if ( e.target === dialog ) {
				dialog.close();
				activeItem = null;
			}
		} );

		// Close on Escape.
		dialog.addEventListener( 'cancel', function() {
			activeItem = null;
		} );

		// Remove FA icon.
		document.addEventListener( 'click', function( e ) {
			var removeBtn = e.target.closest( '.mvweb-cb-remove-fa-icon' );
			if ( ! removeBtn ) {
				return;
			}

			var item = removeBtn.closest( '.mvweb-cb-button-item' );
			if ( ! item ) {
				return;
			}

			// Clear slug.
			var slugInput = item.querySelector( '.mvweb-cb-fa-icon-slug' );
			if ( slugInput ) {
				slugInput.value = '';
			}

			// Reset pick button.
			var pickBtn = item.querySelector( '.mvweb-cb-pick-fa-icon' );
			if ( pickBtn ) {
				pickBtn.textContent = '';
				var icon = document.createElement( 'span' );
				icon.className = 'dashicons dashicons-art';
				pickBtn.appendChild( icon );
				var text = document.createTextNode( ' ' + ( config.i18n && config.i18n.selectIcon ? config.i18n.selectIcon : 'Select Icon' ) );
				pickBtn.appendChild( text );
			}

			// Hide remove button.
			removeBtn.style.display = 'none';

			// Reset header preview.
			var preview = item.querySelector( '.mvweb-cb-button-item__preview' );
			if ( preview ) {
				preview.textContent = '';
				var dashicon = document.createElement( 'span' );
				dashicon.className = 'dashicons dashicons-admin-links';
				preview.appendChild( dashicon );
			}
		} );
	}

	/* ========================================================================
	   Drag-and-drop sorting (native HTML5)
	   ======================================================================== */

	var dragItem = null;

	function initSortable() {
		var list = document.getElementById( 'mvweb-cb-buttons-list' );
		if ( ! list ) {
			return;
		}

		var items = list.querySelectorAll( '.mvweb-cb-button-item' );

		items.forEach( function( item ) {
			// Only make draggable via handle.
			var handle = item.querySelector( '.mvweb-cb-button-item__handle' );
			if ( ! handle ) {
				return;
			}

			item.setAttribute( 'draggable', 'true' );

			handle.addEventListener( 'mousedown', function() {
				item.setAttribute( 'draggable', 'true' );
			} );

			item.addEventListener( 'dragstart', function( e ) {
				// Only allow drag from handle.
				if ( ! handle.matches( ':hover' ) ) {
					e.preventDefault();
					return;
				}
				dragItem = item;
				item.classList.add( 'mvweb-cb-button-item--dragging' );
				e.dataTransfer.effectAllowed = 'move';
			} );

			item.addEventListener( 'dragend', function() {
				item.classList.remove( 'mvweb-cb-button-item--dragging' );
				dragItem = null;
				// Remove all placeholders.
				list.querySelectorAll( '.mvweb-cb-button-item--drag-over' ).forEach( function( el ) {
					el.classList.remove( 'mvweb-cb-button-item--drag-over' );
				} );
				reindexButtons();
				saveSortOrder();
				rebuildPreview();
			} );

			item.addEventListener( 'dragover', function( e ) {
				e.preventDefault();
				e.dataTransfer.dropEffect = 'move';

				if ( ! dragItem || dragItem === item ) {
					return;
				}

				// Remove previous indicators.
				list.querySelectorAll( '.mvweb-cb-button-item--drag-over' ).forEach( function( el ) {
					el.classList.remove( 'mvweb-cb-button-item--drag-over' );
				} );
				item.classList.add( 'mvweb-cb-button-item--drag-over' );

				var rect = item.getBoundingClientRect();
				var mid  = rect.top + rect.height / 2;

				if ( e.clientY < mid ) {
					list.insertBefore( dragItem, item );
				} else {
					list.insertBefore( dragItem, item.nextSibling );
				}
			} );
		} );
	}

	function saveSortOrder() {
		var list = document.getElementById( 'mvweb-cb-buttons-list' );
		if ( ! list ) {
			return;
		}

		var order = [];
		list.querySelectorAll( '.mvweb-cb-button-item' ).forEach( function( item ) {
			var id = item.getAttribute( 'data-button-id' );
			if ( id ) {
				order.push( id );
			}
		} );

		if ( ! order.length ) {
			return;
		}

		var data = new FormData();
		data.append( 'action', 'mvweb_cb_sort_buttons' );
		data.append( 'nonce', config.nonces ? config.nonces.sortButtons : '' );
		order.forEach( function( id ) {
			data.append( 'order[]', id );
		} );

		fetch( config.ajaxUrl || window.ajaxurl, {
			method: 'POST',
			body: data,
			credentials: 'same-origin'
		} );
	}

	/* ========================================================================
	   Reindex buttons (update name attributes after add/remove/sort)
	   ======================================================================== */

	function reindexButtons() {
		var list = document.getElementById( 'mvweb-cb-buttons-list' );
		if ( ! list ) {
			return;
		}

		var items = list.querySelectorAll( '.mvweb-cb-button-item' );

		items.forEach( function( item, newIndex ) {
			item.setAttribute( 'data-index', newIndex );

			// Update all name attributes.
			item.querySelectorAll( '[name]' ).forEach( function( el ) {
				var name = el.getAttribute( 'name' );
				name = name.replace( /^buttons\[\d+\]/, 'buttons[' + newIndex + ']' );
				el.setAttribute( 'name', name );
			} );

			// Update data-toggle attributes.
			item.querySelectorAll( '[data-toggle]' ).forEach( function( el ) {
				var dt = el.getAttribute( 'data-toggle' );
				dt = dt.replace( /^buttons\[\d+\]/, 'buttons[' + newIndex + ']' );
				el.setAttribute( 'data-toggle', dt );
			} );

			// Update data-index on repeater elements.
			item.querySelectorAll( '.mvweb-cb-contacts-repeater' ).forEach( function( el ) {
				el.setAttribute( 'data-index', newIndex );
			} );
			item.querySelectorAll( '.mvweb-cb-add-contact' ).forEach( function( el ) {
				el.setAttribute( 'data-index', newIndex );
			} );
		} );
	}

	/* ========================================================================
	   Save general (AJAX)
	   ======================================================================== */

	function initSaveGeneral() {
		var form = document.getElementById( 'mvweb-cb-general-form' );
		if ( ! form ) {
			return;
		}

		form.addEventListener( 'submit', function( e ) {
			e.preventDefault();

			var formData = new FormData( form );
			formData.append( 'action', 'mvweb_cb_save_settings' );
			formData.append( 'nonce', config.nonces ? config.nonces.saveSettings : '' );
			formData.append( 'tab', 'general' );

			var submitBtn = form.querySelector( '.button-primary' );
			var spinner   = form.querySelector( '.mvweb-spinner' );

			if ( submitBtn ) {
				submitBtn.disabled = true;
			}
			if ( spinner ) {
				spinner.classList.add( 'is-active' );
			}

			fetch( config.ajaxUrl || window.ajaxurl, {
				method: 'POST',
				body: formData,
				credentials: 'same-origin'
			} )
				.then( function( response ) {
					return response.json();
				} )
				.then( function( data ) {
					if ( data.success ) {
						showNotice( 'success', data.data ? data.data.message : 'Settings saved.' );
					} else {
						showNotice( 'error', data.data ? data.data.message : 'Save failed.' );
					}
				} )
				.catch( function() {
					showNotice( 'error', 'Network error. Please try again.' );
				} )
				.finally( function() {
					if ( submitBtn ) {
						submitBtn.disabled = false;
					}
					if ( spinner ) {
						spinner.classList.remove( 'is-active' );
					}
				} );
		} );
	}

	/* ========================================================================
	   Save buttons (AJAX)
	   ======================================================================== */

	function initSaveButtons() {
		var form = document.getElementById( 'mvweb-cb-buttons-form' );
		if ( ! form ) {
			return;
		}

		form.addEventListener( 'submit', function( e ) {
			e.preventDefault();
			saveButtons();
		} );
	}

	function saveButtons() {
		var form = document.getElementById( 'mvweb-cb-buttons-form' );
		if ( ! form ) {
			return;
		}

		var formData = new FormData( form );
		formData.append( 'action', 'mvweb_cb_save_settings' );
		formData.append( 'nonce', config.nonces ? config.nonces.saveSettings : '' );
		formData.append( 'tab', 'buttons' );

		var submitBtn = form.querySelector( '.button-primary' );
		var spinner   = form.querySelector( '.mvweb-spinner' );

		if ( submitBtn ) {
			submitBtn.disabled = true;
		}
		if ( spinner ) {
			spinner.classList.add( 'is-active' );
		}

		fetch( config.ajaxUrl || window.ajaxurl, {
			method: 'POST',
			body: formData,
			credentials: 'same-origin'
		} )
			.then( function( response ) {
				return response.json();
			} )
			.then( function( data ) {
				if ( data.success ) {
					showNotice( 'success', data.data ? data.data.message : 'Settings saved.' );
				} else {
					showNotice( 'error', data.data ? data.data.message : 'Save failed.' );
				}
			} )
			.catch( function() {
				showNotice( 'error', 'Network error. Please try again.' );
			} )
			.finally( function() {
				if ( submitBtn ) {
					submitBtn.disabled = false;
				}
				if ( spinner ) {
					spinner.classList.remove( 'is-active' );
				}
			} );
	}

	/* ========================================================================
	   Notices
	   ======================================================================== */

	function showNotice( type, message ) {
		// Remove existing notices.
		document.querySelectorAll( '.mvweb-cb-admin-notice' ).forEach( function( n ) {
			n.remove();
		} );

		var notice = document.createElement( 'div' );
		notice.className = 'mvweb-notice mvweb-notice--' + type + ' mvweb-cb-admin-notice';
		notice.textContent = message;

		var wrap = document.querySelector( '.mvweb-cb-settings-wrap' );
		if ( wrap ) {
			var tabNav = wrap.querySelector( '.mvweb-cb-tabs' );
			if ( tabNav ) {
				tabNav.parentNode.insertBefore( notice, tabNav.nextSibling );
			} else {
				wrap.prepend( notice );
			}
		}

		// Auto-remove after 4s.
		setTimeout( function() {
			notice.remove();
		}, 4000 );
	}

	/* ========================================================================
	   Template Picker (Modal Template visual selector)
	   ======================================================================== */

	function initTemplatePicker() {
		var picker = document.querySelector( '.mvweb-cb-tpl-picker' );
		if ( ! picker ) {
			return;
		}

		var colorModeRow = document.getElementById( 'mvweb-cb-color-mode-row' );
		var templates    = config.modalTemplates || [];

		// Build lookup: slug → supportsColorMode.
		var tplMap = {};
		templates.forEach( function( t ) {
			tplMap[ t.slug ] = t.supportsColorMode;
		} );

		// CSS :has() polyfill — toggle --active class on radio change.
		picker.addEventListener( 'change', function( e ) {
			if ( e.target.type !== 'radio' || e.target.name !== 'modal_template' ) {
				return;
			}

			// Remove active from all items.
			picker.querySelectorAll( '.mvweb-cb-tpl-picker__item' ).forEach( function( item ) {
				item.classList.remove( 'mvweb-cb-tpl-picker__item--active' );
			} );

			// Add active to selected item.
			var activeItem = e.target.closest( '.mvweb-cb-tpl-picker__item' );
			if ( activeItem ) {
				activeItem.classList.add( 'mvweb-cb-tpl-picker__item--active' );
			}

			// Toggle Color Mode row visibility.
			var slug = e.target.value;
			if ( colorModeRow ) {
				var supports = tplMap[ slug ] !== undefined ? tplMap[ slug ] : true;
				colorModeRow.classList.toggle( 'mvweb-cb-color-mode-hidden', ! supports );
			}
		} );
	}

	/* ========================================================================
	   Helpers
	   ======================================================================== */

	function generateId() {
		return Math.random().toString( 36 ).substring( 2, 10 );
	}

	function escHtml( str ) {
		var div = document.createElement( 'div' );
		div.textContent = str;
		return div.innerHTML;
	}

	function escAttr( str ) {
		return String( str )
			.replace( /&/g, '&amp;' )
			.replace( /"/g, '&quot;' )
			.replace( /'/g, '&#39;' )
			.replace( /</g, '&lt;' )
			.replace( />/g, '&gt;' );
	}

	function getPresetColor( type ) {
		if ( config.presetColors && config.presetColors[ type ] ) {
			return config.presetColors[ type ];
		}
		return '#793ea4';
	}

	function getPresetLabel( type ) {
		if ( config.presetLabels && config.presetLabels[ type ] ) {
			return config.presetLabels[ type ];
		}
		return type;
	}

	/* ========================================================================
	   Branches — Add
	   ======================================================================== */

	function initAddBranch() {
		var addBtn = document.getElementById( 'mvweb-cb-add-branch' );
		if ( ! addBtn ) {
			return;
		}

		addBtn.addEventListener( 'click', function() {
			addBranchItem();
		} );
	}

	function addBranchItem() {
		var list = document.getElementById( 'mvweb-cb-branches-list' );
		if ( ! list ) {
			return;
		}

		// Remove empty state.
		var emptyState = document.getElementById( 'mvweb-cb-branches-empty' );
		if ( emptyState ) {
			emptyState.remove();
		}

		var index    = list.querySelectorAll( '.mvweb-cb-branch-item' ).length;
		var branchId = 'branch_' + generateId();

		var tmpl = document.getElementById( 'tmpl-mvweb-cb-branch-item' );
		if ( ! tmpl ) {
			return;
		}

		// Safe: template content comes from server-side PHP, no user input.
		var html = tmpl.textContent
			.replace( /\{\{data\.id\}\}/g, branchId )
			.replace( /\{\{data\.index\}\}/g, index );

		var temp = document.createElement( 'div' );
		// Safe: innerHTML populated from server-generated PHP template with sanitized indices only.
		temp.innerHTML = html;
		var newItem = temp.firstElementChild;

		list.appendChild( newItem );

		// Re-index all branches.
		reindexBranches();

		// Re-init sortable for branches.
		initBranchSortable();

		// Focus the name field.
		var nameInput = newItem.querySelector( '.mvweb-cb-branch-name' );
		if ( nameInput ) {
			nameInput.focus();
		}
	}

	/* ========================================================================
	   Branches — Remove
	   ======================================================================== */

	function initRemoveBranch() {
		document.addEventListener( 'click', function( e ) {
			var removeBtn = e.target.closest( '.mvweb-cb-branch-item__remove' );
			if ( ! removeBtn ) {
				return;
			}

			var item = removeBtn.closest( '.mvweb-cb-branch-item' );
			if ( ! item ) {
				return;
			}

			if ( ! window.confirm( config.i18n && config.i18n.confirmRemoveBranch
				? config.i18n.confirmRemoveBranch
				: 'Remove this branch? Contacts linked to this branch will also be removed.' ) ) {
				return;
			}

			item.remove();
			reindexBranches();

			// Show empty state if no branches left.
			var list = document.getElementById( 'mvweb-cb-branches-list' );
			if ( list && ! list.querySelectorAll( '.mvweb-cb-branch-item' ).length ) {
				showBranchEmptyState( list );
			}
		} );
	}

	function showBranchEmptyState( list ) {
		var empty = document.createElement( 'div' );
		empty.className = 'mvweb-empty';
		empty.id = 'mvweb-cb-branches-empty';

		var iconDiv = document.createElement( 'div' );
		iconDiv.className = 'mvweb-empty__icon';
		var iconSpan = document.createElement( 'span' );
		iconSpan.className = 'dashicons dashicons-location';
		iconDiv.appendChild( iconSpan );

		var titleDiv = document.createElement( 'div' );
		titleDiv.className = 'mvweb-empty__title';
		titleDiv.textContent = config.i18n ? config.i18n.noBranches : 'No branches yet';

		var textDiv = document.createElement( 'div' );
		textDiv.className = 'mvweb-empty__text';
		textDiv.textContent = config.i18n ? config.i18n.addFirstBranch : 'Add your first branch to get started.';

		empty.appendChild( iconDiv );
		empty.appendChild( titleDiv );
		empty.appendChild( textDiv );
		list.appendChild( empty );
	}

	/* ========================================================================
	   Branches — Live title update
	   ======================================================================== */

	function initBranchLiveTitle() {
		document.addEventListener( 'input', function( e ) {
			if ( ! e.target.classList.contains( 'mvweb-cb-branch-name' ) ) {
				return;
			}

			var item = e.target.closest( '.mvweb-cb-branch-item' );
			if ( ! item ) {
				return;
			}

			var titleEl = item.querySelector( '.mvweb-cb-branch-item__title' );
			if ( titleEl ) {
				titleEl.textContent = e.target.value || ( config.i18n ? config.i18n.newBranch : 'New Branch' );
			}
		} );

		document.addEventListener( 'input', function( e ) {
			if ( ! e.target.classList.contains( 'mvweb-cb-branch-address' ) ) {
				return;
			}

			var item = e.target.closest( '.mvweb-cb-branch-item' );
			if ( ! item ) {
				return;
			}

			var addrEl = item.querySelector( '.mvweb-cb-branch-item__address' );
			if ( addrEl ) {
				addrEl.textContent = e.target.value;
			} else if ( e.target.value ) {
				var header = item.querySelector( '.mvweb-cb-branch-item__header' );
				var actions = header ? header.querySelector( '.mvweb-cb-branch-item__actions' ) : null;
				if ( header && actions ) {
					var newAddr = document.createElement( 'span' );
					newAddr.className = 'mvweb-cb-branch-item__address';
					newAddr.textContent = e.target.value;
					header.insertBefore( newAddr, actions );
				}
			}
		} );
	}

	/* ========================================================================
	   Branches — Reindex
	   ======================================================================== */

	function reindexBranches() {
		var list = document.getElementById( 'mvweb-cb-branches-list' );
		if ( ! list ) {
			return;
		}

		var items = list.querySelectorAll( '.mvweb-cb-branch-item' );

		items.forEach( function( item, newIndex ) {
			item.setAttribute( 'data-index', newIndex );

			// Update all name attributes.
			item.querySelectorAll( '[name]' ).forEach( function( el ) {
				var name = el.getAttribute( 'name' );
				name = name.replace( /^branches\[\d+\]/, 'branches[' + newIndex + ']' );
				el.setAttribute( 'name', name );
			} );

			// Update data-toggle attributes.
			item.querySelectorAll( '[data-toggle]' ).forEach( function( el ) {
				var dt = el.getAttribute( 'data-toggle' );
				dt = dt.replace( /^branches\[\d+\]/, 'branches[' + newIndex + ']' );
				el.setAttribute( 'data-toggle', dt );
			} );

			// Update data-index on branch contacts repeater elements.
			item.querySelectorAll( '.mvweb-cb-branch-contacts-repeater' ).forEach( function( el ) {
				el.setAttribute( 'data-index', newIndex );
			} );
			item.querySelectorAll( '.mvweb-cb-add-branch-contact' ).forEach( function( el ) {
				el.setAttribute( 'data-index', newIndex );
			} );
		} );
	}

	/* ========================================================================
	   Branches — Drag-and-drop sorting
	   ======================================================================== */

	var dragBranch = null;

	function initBranchSortable() {
		var list = document.getElementById( 'mvweb-cb-branches-list' );
		if ( ! list ) {
			return;
		}

		var items = list.querySelectorAll( '.mvweb-cb-branch-item' );

		items.forEach( function( item ) {
			var handle = item.querySelector( '.mvweb-cb-branch-item__handle' );
			if ( ! handle ) {
				return;
			}

			item.setAttribute( 'draggable', 'true' );

			handle.addEventListener( 'mousedown', function() {
				item.setAttribute( 'draggable', 'true' );
			} );

			item.addEventListener( 'dragstart', function( e ) {
				if ( ! handle.matches( ':hover' ) ) {
					e.preventDefault();
					return;
				}
				dragBranch = item;
				item.classList.add( 'mvweb-cb-branch-item--dragging' );
				e.dataTransfer.effectAllowed = 'move';
			} );

			item.addEventListener( 'dragend', function() {
				item.classList.remove( 'mvweb-cb-branch-item--dragging' );
				dragBranch = null;
				list.querySelectorAll( '.mvweb-cb-branch-item--drag-over' ).forEach( function( el ) {
					el.classList.remove( 'mvweb-cb-branch-item--drag-over' );
				} );
				reindexBranches();
				saveBranchSortOrder();
			} );

			item.addEventListener( 'dragover', function( e ) {
				e.preventDefault();
				e.dataTransfer.dropEffect = 'move';

				if ( ! dragBranch || dragBranch === item ) {
					return;
				}

				list.querySelectorAll( '.mvweb-cb-branch-item--drag-over' ).forEach( function( el ) {
					el.classList.remove( 'mvweb-cb-branch-item--drag-over' );
				} );
				item.classList.add( 'mvweb-cb-branch-item--drag-over' );

				var rect = item.getBoundingClientRect();
				var mid  = rect.top + rect.height / 2;

				if ( e.clientY < mid ) {
					list.insertBefore( dragBranch, item );
				} else {
					list.insertBefore( dragBranch, item.nextSibling );
				}
			} );
		} );
	}

	function saveBranchSortOrder() {
		var list = document.getElementById( 'mvweb-cb-branches-list' );
		if ( ! list ) {
			return;
		}

		var order = [];
		list.querySelectorAll( '.mvweb-cb-branch-item' ).forEach( function( item ) {
			var id = item.getAttribute( 'data-branch-id' );
			if ( id ) {
				order.push( id );
			}
		} );

		if ( ! order.length ) {
			return;
		}

		var data = new FormData();
		data.append( 'action', 'mvweb_cb_sort_branches' );
		data.append( 'nonce', config.nonces ? config.nonces.sortBranches : '' );
		order.forEach( function( id ) {
			data.append( 'order[]', id );
		} );

		fetch( config.ajaxUrl || window.ajaxurl, {
			method: 'POST',
			body: data,
			credentials: 'same-origin'
		} );
	}

	/* ========================================================================
	   Branches — Save (AJAX)
	   ======================================================================== */

	function initSaveBranches() {
		var form = document.getElementById( 'mvweb-cb-branches-form' );
		if ( ! form ) {
			return;
		}

		form.addEventListener( 'submit', function( e ) {
			e.preventDefault();
			saveBranches();
		} );
	}

	function saveBranches() {
		var form = document.getElementById( 'mvweb-cb-branches-form' );
		if ( ! form ) {
			return;
		}

		var formData = new FormData( form );
		formData.append( 'action', 'mvweb_cb_save_settings' );
		formData.append( 'nonce', config.nonces ? config.nonces.saveSettings : '' );
		formData.append( 'tab', 'branches' );

		var submitBtn = form.querySelector( '.button-primary' );
		var spinner   = form.querySelector( '.mvweb-spinner' );

		if ( submitBtn ) {
			submitBtn.disabled = true;
		}
		if ( spinner ) {
			spinner.classList.add( 'is-active' );
		}

		fetch( config.ajaxUrl || window.ajaxurl, {
			method: 'POST',
			body: formData,
			credentials: 'same-origin'
		} )
			.then( function( response ) {
				return response.json();
			} )
			.then( function( data ) {
				if ( data.success ) {
					showNotice( 'success', data.data ? data.data.message : 'Settings saved.' );
				} else {
					showNotice( 'error', data.data ? data.data.message : 'Save failed.' );
				}
			} )
			.catch( function() {
				showNotice( 'error', 'Network error. Please try again.' );
			} )
			.finally( function() {
				if ( submitBtn ) {
					submitBtn.disabled = false;
				}
				if ( spinner ) {
					spinner.classList.remove( 'is-active' );
				}
			} );
	}

	/* ========================================================================
	   Reset settings (§9.3)
	   ======================================================================== */

	function initResetSettings() {
		var resetBtn  = document.getElementById( 'mvweb-cb-reset-settings' );
		var dialog    = document.getElementById( 'mvweb-cb-reset-dialog' );
		var confirmBtn = document.getElementById( 'mvweb-cb-confirm-reset' );

		if ( ! resetBtn || ! dialog || ! confirmBtn ) {
			return;
		}

		resetBtn.addEventListener( 'click', function() {
			dialog.showModal();
		} );

		// Close on backdrop click.
		dialog.addEventListener( 'click', function( e ) {
			if ( e.target === dialog ) {
				dialog.close();
			}
		} );

		confirmBtn.addEventListener( 'click', function() {
			dialog.close();

			var data = new FormData();
			data.append( 'action', 'mvweb_cb_reset_settings' );
			data.append( 'nonce', config.nonces ? config.nonces.resetSettings : '' );

			resetBtn.disabled = true;

			fetch( config.ajaxUrl || window.ajaxurl, {
				method: 'POST',
				body: data,
				credentials: 'same-origin'
			} )
				.then( function( response ) {
					return response.json();
				} )
				.then( function( result ) {
					if ( result.success ) {
						showNotice( 'success', result.data ? result.data.message : 'Settings reset.' );
						// Reload after brief delay to show fresh defaults.
						setTimeout( function() {
							window.location.reload();
						}, 800 );
					} else {
						showNotice( 'error', result.data ? result.data.message : 'Reset failed.' );
					}
				} )
				.catch( function() {
					showNotice( 'error', 'Network error. Please try again.' );
				} )
				.finally( function() {
					resetBtn.disabled = false;
				} );
		} );
	}

	/* ========================================================================
	   Live Preview (§9.2)
	   ======================================================================== */

	var previewDebounceTimer = null;

	function initLivePreview() {
		var bar = document.getElementById( 'mvweb-cb-preview-bar' );
		if ( ! bar ) {
			return;
		}

		// Instant update for selects/checkboxes/toggles.
		document.addEventListener( 'change', function( e ) {
			if ( isPreviewField( e.target ) ) {
				updatePreview();
			}
		} );

		// Debounced update for text/number inputs.
		document.addEventListener( 'input', function( e ) {
			if ( isPreviewField( e.target ) ) {
				clearTimeout( previewDebounceTimer );
				previewDebounceTimer = setTimeout( updatePreview, 250 );
			}
		} );

		// Update on toggle clicks (general tab toggles).
		document.addEventListener( 'click', function( e ) {
			var toggle = e.target.closest( '.mvweb-toggle' );
			if ( toggle && isPreviewField( toggle ) ) {
				// Small delay to let toggle state update first.
				setTimeout( updatePreview, 50 );
			}
		} );
	}

	function isPreviewField( el ) {
		// General tab fields affecting preview.
		var previewNames = [
			'theme', 'size', 'position', 'border_radius',
			'show_labels'
		];
		var name = el.getAttribute( 'name' ) || el.getAttribute( 'data-toggle' ) || '';
		return previewNames.indexOf( name ) !== -1;
	}

	function updatePreview() {
		var bar = document.getElementById( 'mvweb-cb-preview-bar' );
		if ( ! bar ) {
			return;
		}

		// Read current general settings from form.
		var form  = document.getElementById( 'mvweb-cb-general-form' );
		if ( ! form ) {
			return;
		}

		var theme  = getFieldValue( form, 'theme', 'light' );
		var size   = getFieldValue( form, 'size', 'm' );
		var radius = getFieldValue( form, 'border_radius', 'capsule' );
		var showLabels = getFieldValue( form, 'show_labels', '1' ) === '1';

		// Update bar classes.
		bar.className = 'mvweb-cb mvweb-cb--' + theme + ' mvweb-cb--' + size + ' mvweb-cb--' + radius;

		// Toggle labels visibility.
		var labels = bar.querySelectorAll( '.mvweb-cb__label' );
		labels.forEach( function( label ) {
			label.style.display = showLabels ? '' : 'none';
		} );
	}

	function getFieldValue( form, name, fallback ) {
		var el = form.querySelector( '[name="' + name + '"]' );
		if ( ! el ) {
			return fallback;
		}
		return el.value || fallback;
	}

	/**
	 * Rebuild the preview bar from current buttons form data.
	 *
	 * Called after buttons add/remove/reorder/type change.
	 *
	 * Note: innerHTML usage is safe here — icon SVG comes from
	 * config.previewIcons (server-generated via wp_localize_script).
	 * Custom icon URLs are escaped via escAttr(). No user-controlled
	 * HTML is ever injected.
	 */
	function rebuildPreview() {
		var bar = document.getElementById( 'mvweb-cb-preview-bar' );
		if ( ! bar ) {
			return;
		}

		var items = document.querySelectorAll( '#mvweb-cb-buttons-list .mvweb-cb-button-item' );

		// Clear bar content.
		while ( bar.firstChild ) {
			bar.removeChild( bar.firstChild );
		}

		if ( ! items.length ) {
			var empty = document.createElement( 'span' );
			empty.className = 'mvweb-cb-preview-empty';
			empty.textContent = config.i18n ? config.i18n.noButtons : 'Add buttons to see the preview';
			bar.appendChild( empty );
			return;
		}

		items.forEach( function( item ) {
			var activeInput = item.querySelector( 'input[name$="[active]"]' );
			if ( activeInput && activeInput.value === '0' ) {
				return; // Skip inactive.
			}

			var typeInput = item.querySelector( 'input[name$="[type]"]' );
			var type = typeInput ? typeInput.value : 'custom';

			var colorInput = item.querySelector( '.mvweb-cb-color-picker' );
			var color = colorInput ? colorInput.value : getPresetColor( type );

			var labelInput = item.querySelector( 'input[name$="[label]"]' );
			var label = labelInput && labelInput.value ? labelInput.value : getPresetLabel( type );

			// Get icon SVG from config (safe: server-generated via wp_localize_script).
			var iconEl;
			if ( type !== 'custom' && config.previewIcons && config.previewIcons[ type ] ) {
				iconEl = document.createElement( 'span' );
				iconEl.className = 'mvweb-cb__icon';
				iconEl.setAttribute( 'aria-hidden', 'true' );
				// Safe: SVG from server-generated wp_localize_script data, not user input.
				iconEl.innerHTML = config.previewIcons[ type ]; // eslint-disable-line no-unsanitized/property
			} else {
				iconEl = document.createElement( 'span' );
				iconEl.className = 'mvweb-cb__icon';
				iconEl.setAttribute( 'aria-hidden', 'true' );
				var customIconInput = item.querySelector( '.mvweb-cb-custom-icon-url' );
				if ( customIconInput && customIconInput.value ) {
					var img = document.createElement( 'img' );
					img.src = customIconInput.value;
					img.alt = '';
					iconEl.appendChild( img );
				} else {
					var dashicon = document.createElement( 'span' );
					dashicon.className = 'dashicons dashicons-admin-links';
					iconEl.appendChild( dashicon );
				}
			}

			// Create button element.
			var btn = document.createElement( 'span' );
			btn.className = 'mvweb-cb__btn mvweb-cb__btn--' + type;
			btn.style.cssText = '--mvweb-cb-btn-color:' + color;
			btn.appendChild( iconEl );

			// Check show_labels.
			var form = document.getElementById( 'mvweb-cb-general-form' );
			var showLabels = true;
			if ( form ) {
				showLabels = getFieldValue( form, 'show_labels', '1' ) === '1';
			}

			if ( showLabels ) {
				var labelSpan = document.createElement( 'span' );
				labelSpan.className = 'mvweb-cb__label';
				labelSpan.textContent = label;
				btn.appendChild( labelSpan );
			}

			bar.appendChild( btn );

			// Separator.
			var sepInput = item.querySelector( 'input[name$="[separator_after]"]' );
			if ( sepInput && sepInput.value === '1' ) {
				var sep = document.createElement( 'span' );
				sep.className = 'mvweb-cb__sep';
				sep.setAttribute( 'aria-hidden', 'true' );
				bar.appendChild( sep );
			}
		} );
	}

	/* ========================================================================
	   Init
	   ======================================================================== */

	function init() {
		initTabs();
		initToggles();
		initExpandCollapse();
		initAddButton();
		initRemoveButton();
		initContactsRepeater();
		initContactBranchAutofill();
		initTypeChange();
		initColorReset();
		initMediaUpload();
		initFaPicker();
		initSortable();
		initSaveGeneral();
		initSaveButtons();
		initAddBranch();
		initRemoveBranch();
		initBranchLiveTitle();
		initBranchSortable();
		initBranchContactsRepeater();
		initSaveBranches();
		initTemplatePicker();
		initResetSettings();
		initLivePreview();
	}

	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}

} )();
