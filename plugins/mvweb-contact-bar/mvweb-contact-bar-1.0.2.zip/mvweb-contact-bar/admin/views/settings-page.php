<?php
/**
 * Admin settings page with tab navigation.
 *
 * @package MVweb_Contact_Bar
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

$settings = MVweb_CB_Settings::get();

$tabs = array(
	'general'  => __( 'General', 'mvweb-contact-bar' ),
	'branches' => __( 'Branches', 'mvweb-contact-bar' ),
	'buttons'  => __( 'Buttons', 'mvweb-contact-bar' ),
	'help'     => __( 'Help', 'mvweb-contact-bar' ),
);
?>
<div class="wrap mvweb-settings mvweb-cb-settings-wrap">

	<h1><?php esc_html_e( 'MVweb Contact Bar', 'mvweb-contact-bar' ); ?></h1>

	<nav class="nav-tab-wrapper mvweb-cb-tabs">
		<?php
		$first = true;
		foreach ( $tabs as $tab_id => $tab_label ) :
			?>
			<a href="#<?php echo esc_attr( $tab_id ); ?>"
			   class="nav-tab<?php echo $first ? ' nav-tab-active' : ''; ?>"
			   data-tab="<?php echo esc_attr( $tab_id ); ?>">
				<?php echo esc_html( $tab_label ); ?>
			</a>
			<?php
			$first = false;
		endforeach;
		?>
	</nav>

	<!-- General Tab -->
	<div id="general" class="mvweb-tab-content active">
		<form id="mvweb-cb-general-form" method="post" action="#">
			<?php wp_nonce_field( 'mvweb_cb_save_settings', '_wpnonce', false ); ?>
			<?php include MVWEB_CB_PATH . 'admin/views/tab-general.php'; ?>

			<p class="submit mvweb-cb-save-area">
				<?php submit_button( __( 'Save Settings', 'mvweb-contact-bar' ), 'primary', 'submit', false ); ?>
				<span class="mvweb-spinner"></span>
				<button type="button" class="mvweb-btn mvweb-btn--danger mvweb-cb-reset-all"
						id="mvweb-cb-reset-settings">
					<?php esc_html_e( 'Reset All Settings', 'mvweb-contact-bar' ); ?>
				</button>
			</p>
		</form>
	</div>

	<!-- Branches Tab -->
	<div id="branches" class="mvweb-tab-content">
		<form id="mvweb-cb-branches-form" method="post" action="#">
			<?php wp_nonce_field( 'mvweb_cb_save_settings', '_wpnonce', false ); ?>
			<?php include MVWEB_CB_PATH . 'admin/views/tab-branches.php'; ?>

			<p class="submit mvweb-cb-save-area">
				<?php submit_button( __( 'Save Branches', 'mvweb-contact-bar' ), 'primary', 'submit', false ); ?>
				<span class="mvweb-spinner"></span>
			</p>
		</form>
	</div>

	<!-- Buttons Tab (inside form for AJAX save) -->
	<div id="buttons" class="mvweb-tab-content">
		<form id="mvweb-cb-buttons-form" method="post" action="#">
			<?php wp_nonce_field( 'mvweb_cb_save_settings', '_wpnonce', false ); ?>
			<?php include MVWEB_CB_PATH . 'admin/views/tab-buttons.php'; ?>

			<p class="submit mvweb-cb-save-area">
				<?php submit_button( __( 'Save Buttons', 'mvweb-contact-bar' ), 'primary', 'submit', false ); ?>
				<span class="mvweb-spinner"></span>
			</p>
		</form>
	</div>

	<!-- Help Tab -->
	<div id="help" class="mvweb-tab-content">
		<?php
		$help_file = MVWEB_CB_PATH . 'admin/views/tab-help.php';
		if ( file_exists( $help_file ) ) {
			include $help_file;
		} else {
			echo '<p>' . esc_html__( 'Help documentation coming soon.', 'mvweb-contact-bar' ) . '</p>';
		}
		?>
	</div>

</div>

<!-- Live Preview (§9.2) -->
<div class="mvweb-cb-preview-wrap" id="mvweb-cb-preview-wrap">
	<div class="mvweb-cb-preview-header">
		<span class="dashicons dashicons-visibility"></span>
		<?php esc_html_e( 'Preview', 'mvweb-contact-bar' ); ?>
	</div>
	<div class="mvweb-cb-preview-stage" id="mvweb-cb-preview-stage">
		<?php
		$preview_buttons = MVweb_CB_Settings::get_active_buttons( $settings );
		$p_theme  = in_array( $settings['theme'] ?? 'light', array( 'light', 'dark' ), true ) ? $settings['theme'] : 'light';
		$p_size   = in_array( $settings['size'] ?? 'm', array( 's', 'm', 'l' ), true ) ? $settings['size'] : 'm';
		$p_radius = in_array( $settings['border_radius'] ?? 'capsule', array( 'capsule', 'rounded', 'rect' ), true ) ? $settings['border_radius'] : 'capsule';

		$p_classes = 'mvweb-cb mvweb-cb--' . $p_theme . ' mvweb-cb--' . $p_size . ' mvweb-cb--' . $p_radius;
		?>
		<div class="<?php echo esc_attr( $p_classes ); ?>"
			 id="mvweb-cb-preview-bar"
			 style="position:static;transform:none;">
			<?php if ( ! empty( $preview_buttons ) ) : ?>
				<?php foreach ( $preview_buttons as $btn ) :
					$btn_type  = $btn['type'] ?? 'custom';
					$btn_color = ! empty( $btn['color'] ) ? $btn['color'] : MVweb_CB_Icons::get_brand_color( $btn_type );
					$btn_label = ! empty( $btn['label'] ) ? $btn['label'] : MVweb_CB_Icons::get_default_label( $btn_type );
					$btn_icon  = '';
					if ( 'custom' === $btn_type && ! empty( $btn['custom_icon'] ) ) {
						$btn_icon = '<img src="' . esc_url( $btn['custom_icon'] ) . '" alt="" />';
					} else {
						$btn_icon = MVweb_CB_Icons::get( $btn_type );
					}
					?>
					<span class="mvweb-cb__btn mvweb-cb__btn--<?php echo esc_attr( sanitize_html_class( $btn_type ) ); ?>"
						  style="--mvweb-cb-btn-color:<?php echo esc_attr( $btn_color ); ?>">
						<span class="mvweb-cb__icon" aria-hidden="true"><?php echo $btn_icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						<?php if ( ! empty( $settings['show_labels'] ) ) : ?>
							<span class="mvweb-cb__label"><?php echo esc_html( $btn_label ); ?></span>
						<?php endif; ?>
					</span>
					<?php if ( ! empty( $btn['separator_after'] ) ) : ?>
						<span class="mvweb-cb__sep" aria-hidden="true"></span>
					<?php endif; ?>
				<?php endforeach; ?>
			<?php else : ?>
				<span class="mvweb-cb-preview-empty">
					<?php esc_html_e( 'Add buttons to see the preview', 'mvweb-contact-bar' ); ?>
				</span>
			<?php endif; ?>
		</div>
	</div>
</div>

<!-- Reset confirmation dialog (§9.3) -->
<dialog id="mvweb-cb-reset-dialog" class="mvweb-dialog">
	<div class="mvweb-dialog__header"><?php esc_html_e( 'Reset Settings', 'mvweb-contact-bar' ); ?></div>
	<div class="mvweb-dialog__body">
		<p><?php esc_html_e( 'Are you sure you want to reset all settings to defaults? This will remove all your buttons, branches, and custom configuration. This action cannot be undone.', 'mvweb-contact-bar' ); ?></p>
	</div>
	<div class="mvweb-dialog__footer">
		<button type="button" class="mvweb-btn" onclick="this.closest('dialog').close()">
			<?php esc_html_e( 'Cancel', 'mvweb-contact-bar' ); ?>
		</button>
		<button type="button" class="mvweb-btn mvweb-btn--danger" id="mvweb-cb-confirm-reset">
			<?php esc_html_e( 'Reset All Settings', 'mvweb-contact-bar' ); ?>
		</button>
	</div>
</dialog>
