<?php
/**
 * Buttons tab — CRUD, drag-and-drop, preset selection, contacts repeater.
 *
 * Variables available from settings-page.php:
 *   $settings — full plugin settings array
 *   $presets  — array of preset types with metadata
 *   $branches — active branches for contact binding
 *
 * @package MVweb_Contact_Bar
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

$buttons  = $settings['buttons'] ?? array();
$branches = $settings['branches'] ?? array();

// Active branches for contacts repeater.
$active_branches = array_filter( $branches, fn( $b ) => ! empty( $b['active'] ) );

// Preset types with metadata.
$preset_types = array(
	'phone'     => __( 'Phone', 'mvweb-contact-bar' ),
	'email'     => __( 'Email', 'mvweb-contact-bar' ),
	'telegram'  => 'Telegram',
	'whatsapp'  => 'WhatsApp',
	'viber'     => 'Viber',
	'vk'        => 'VK',
	'ok'        => 'OK',
	'max'       => 'Max',
	'messenger' => 'Messenger',
	'instagram' => 'Instagram',
	'x'         => 'X',
	'linkedin'  => 'LinkedIn',
	'snapchat'  => 'Snapchat',
	'discord'   => 'Discord',
	'youtube'   => 'YouTube',
	'rutube'    => 'Rutube',
	'custom'    => __( 'Custom', 'mvweb-contact-bar' ),
);
?>

<div class="mvweb-cb-buttons-tab">

	<div class="mvweb-toolbar">
		<button type="button" class="mvweb-btn mvweb-btn--primary" id="mvweb-cb-add-button">
			<span class="dashicons dashicons-plus-alt2"></span>
			<?php esc_html_e( 'Add Button', 'mvweb-contact-bar' ); ?>
		</button>
		<span class="mvweb-help-text">
			<?php
			printf(
				/* translators: %1$d: min buttons, %2$d: max buttons */
				esc_html__( 'Recommended: %1$d–%2$d buttons. Drag to reorder.', 'mvweb-contact-bar' ),
				4,
				6
			);
			?>
		</span>
	</div>

	<?php if ( empty( $active_branches ) ) : ?>
		<div class="mvweb-notice mvweb-notice--warning">
			<?php esc_html_e( 'No active branches found. Please add branches in the Branches tab first.', 'mvweb-contact-bar' ); ?>
		</div>
	<?php endif; ?>

	<div class="mvweb-cb-buttons-list" id="mvweb-cb-buttons-list">
		<?php
		if ( ! empty( $buttons ) ) :
			foreach ( $buttons as $index => $btn ) :
				$btn_type  = $btn['type'] ?? 'custom';
				$btn_color = ! empty( $btn['color'] ) ? $btn['color'] : MVweb_CB_Icons::get_brand_color( $btn_type );
				$btn_label = ! empty( $btn['label'] ) ? $btn['label'] : MVweb_CB_Icons::get_default_label( $btn_type );
				$btn_id    = $btn['id'] ?? 'btn_' . $index;
				$is_custom = 'custom' === $btn_type;
				?>
				<div class="mvweb-cb-button-item<?php echo empty( $btn['active'] ) ? ' mvweb-cb-button-item--inactive' : ''; ?>"
					 data-button-id="<?php echo esc_attr( $btn_id ); ?>"
					 data-index="<?php echo esc_attr( $index ); ?>">

					<input type="hidden" name="buttons[<?php echo esc_attr( $index ); ?>][id]"
						   value="<?php echo esc_attr( $btn_id ); ?>">
					<input type="hidden" name="buttons[<?php echo esc_attr( $index ); ?>][type]"
						   value="<?php echo esc_attr( $btn_type ); ?>">

					<!-- Header (collapsed view) -->
					<div class="mvweb-cb-button-item__header">
						<span class="mvweb-cb-button-item__handle dashicons dashicons-menu"></span>

						<span class="mvweb-cb-button-item__preview" style="color: <?php echo esc_attr( $btn_color ); ?>">
							<?php
							if ( $is_custom && ! empty( $btn['custom_icon'] ) ) {
								echo '<img src="' . esc_url( $btn['custom_icon'] ) . '" alt="" class="mvweb-cb-button-item__custom-icon-preview">';
							} else {
								echo MVweb_CB_Icons::get( $btn_type ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Safe: hardcoded SVG.
							}
							?>
						</span>

						<span class="mvweb-cb-button-item__title">
							<?php echo esc_html( $btn_label ); ?>
							<?php if ( $is_custom ) : ?>
								<span class="mvweb-badge mvweb-badge--outline"><?php esc_html_e( 'Custom', 'mvweb-contact-bar' ); ?></span>
							<?php endif; ?>
						</span>

						<span class="mvweb-cb-button-item__contacts-count">
							<?php
							$contact_count = count( $btn['contacts'] ?? array() );
							printf(
								/* translators: %d: number of contacts */
								esc_html( _n( '%d contact', '%d contacts', $contact_count, 'mvweb-contact-bar' ) ),
								$contact_count
							);
							?>
						</span>

						<span class="mvweb-cb-button-item__actions">
							<label class="mvweb-toggle-label mvweb-cb-button-item__toggle-label">
								<span class="mvweb-toggle<?php echo ! empty( $btn['active'] ) ? ' active' : ''; ?>"
									  data-toggle="buttons[<?php echo esc_attr( $index ); ?>][active]"></span>
							</label>
							<button type="button" class="mvweb-cb-button-item__expand dashicons dashicons-arrow-down-alt2"
									aria-label="<?php esc_attr_e( 'Expand', 'mvweb-contact-bar' ); ?>"></button>
							<button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-cb-button-item__remove"
									aria-label="<?php esc_attr_e( 'Remove', 'mvweb-contact-bar' ); ?>">
								<span class="dashicons dashicons-trash"></span>
							</button>
						</span>
					</div>

					<input type="hidden" name="buttons[<?php echo esc_attr( $index ); ?>][active]"
						   value="<?php echo ! empty( $btn['active'] ) ? '1' : '0'; ?>">

					<!-- Body (expanded view) -->
					<div class="mvweb-cb-button-item__body" style="display: none;">

						<!-- Type selection (only for new or custom) -->
						<?php if ( $is_custom ) : ?>
						<div class="mvweb-form-group">
							<label class="mvweb-label"><?php esc_html_e( 'Button Type', 'mvweb-contact-bar' ); ?></label>
							<select class="mvweb-select mvweb-cb-type-select"
									name="buttons[<?php echo esc_attr( $index ); ?>][type]"
									data-index="<?php echo esc_attr( $index ); ?>">
								<?php foreach ( $preset_types as $ptype => $plabel ) : ?>
									<option value="<?php echo esc_attr( $ptype ); ?>"
										<?php selected( $btn_type, $ptype ); ?>>
										<?php echo esc_html( $plabel ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</div>
						<?php endif; ?>

						<!-- Label -->
						<div class="mvweb-form-group">
							<label class="mvweb-label"><?php esc_html_e( 'Label', 'mvweb-contact-bar' ); ?></label>
							<input type="text" class="regular-text"
								   name="buttons[<?php echo esc_attr( $index ); ?>][label]"
								   value="<?php echo esc_attr( $btn['label'] ?? '' ); ?>"
								   placeholder="<?php echo esc_attr( MVweb_CB_Icons::get_default_label( $btn_type ) ); ?>">
							<div class="mvweb-help-text"><?php esc_html_e( 'Leave empty to use preset default.', 'mvweb-contact-bar' ); ?></div>
						</div>

						<!-- Color -->
						<div class="mvweb-form-group">
							<label class="mvweb-label"><?php esc_html_e( 'Icon Color', 'mvweb-contact-bar' ); ?></label>
							<input type="color" class="mvweb-color mvweb-cb-color-picker"
								   name="buttons[<?php echo esc_attr( $index ); ?>][color]"
								   value="<?php echo esc_attr( $btn_color ); ?>"
								   data-default="<?php echo esc_attr( MVweb_CB_Icons::get_brand_color( $btn_type ) ); ?>">
							<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-cb-reset-color">
								<?php esc_html_e( 'Reset', 'mvweb-contact-bar' ); ?>
							</button>
							<div class="mvweb-help-text"><?php esc_html_e( 'Default is the brand color of the service.', 'mvweb-contact-bar' ); ?></div>
						</div>

						<!-- Custom icon (only for custom type) -->
						<div class="mvweb-form-group mvweb-cb-custom-icon-group" <?php echo $is_custom ? '' : 'style="display:none"'; ?>>
							<label class="mvweb-label"><?php esc_html_e( 'Custom Icon', 'mvweb-contact-bar' ); ?></label>

							<!-- FA icon picker -->
							<div class="mvweb-cb-fa-picker-wrap">
								<input type="hidden" class="mvweb-cb-fa-icon-slug"
									   name="buttons[<?php echo esc_attr( $index ); ?>][fa_icon]"
									   value="<?php echo esc_attr( $btn['fa_icon'] ?? '' ); ?>">
								<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-cb-pick-fa-icon">
									<?php
									if ( ! empty( $btn['fa_icon'] ) ) {
										echo MVweb_CB_Icons::get_fa( $btn['fa_icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Safe: hardcoded SVG.
										echo ' <span class="mvweb-cb-fa-icon-name">' . esc_html( $btn['fa_icon'] ) . '</span>';
									} else {
										esc_html_e( 'Choose Icon', 'mvweb-contact-bar' );
									}
									?>
								</button>
								<?php if ( ! empty( $btn['fa_icon'] ) ) : ?>
								<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-cb-remove-fa-icon">
									<?php esc_html_e( 'Remove', 'mvweb-contact-bar' ); ?>
								</button>
								<?php endif; ?>
							</div>

							<div class="mvweb-cb-icon-or"><?php esc_html_e( '— or upload custom image —', 'mvweb-contact-bar' ); ?></div>

							<div class="mvweb-cb-icon-upload">
								<input type="hidden" class="mvweb-cb-custom-icon-url"
									   name="buttons[<?php echo esc_attr( $index ); ?>][custom_icon]"
									   value="<?php echo esc_attr( $btn['custom_icon'] ?? '' ); ?>">
								<img class="mvweb-cb-custom-icon-thumb"
									 src="<?php echo esc_url( $btn['custom_icon'] ?? '' ); ?>"
									 alt=""
									 <?php echo empty( $btn['custom_icon'] ) ? 'style="display:none"' : ''; ?>>
								<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-cb-upload-icon">
									<?php esc_html_e( 'Upload Image', 'mvweb-contact-bar' ); ?>
								</button>
								<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-cb-remove-icon"
										<?php echo empty( $btn['custom_icon'] ) ? 'style="display:none"' : ''; ?>>
									<?php esc_html_e( 'Remove', 'mvweb-contact-bar' ); ?>
								</button>
							</div>
							<div class="mvweb-help-text"><?php esc_html_e( 'Choose a built-in icon or upload a custom image.', 'mvweb-contact-bar' ); ?></div>
						</div>

						<!-- Modal title override -->
						<div class="mvweb-form-group">
							<label class="mvweb-label"><?php esc_html_e( 'Modal Title', 'mvweb-contact-bar' ); ?></label>
							<input type="text" class="regular-text"
								   name="buttons[<?php echo esc_attr( $index ); ?>][modal_title]"
								   value="<?php echo esc_attr( $btn['modal_title'] ?? '' ); ?>"
								   placeholder="<?php echo esc_attr( MVweb_CB_Icons::get_modal_title( $btn_type ) ); ?>">
							<div class="mvweb-help-text"><?php esc_html_e( 'Override the auto-generated modal title.', 'mvweb-contact-bar' ); ?></div>
						</div>

						<!-- Modal description override -->
						<div class="mvweb-form-group">
							<label class="mvweb-label"><?php esc_html_e( 'Modal Description', 'mvweb-contact-bar' ); ?></label>
							<input type="text" class="regular-text"
								   name="buttons[<?php echo esc_attr( $index ); ?>][modal_description]"
								   value="<?php echo esc_attr( $btn['modal_description'] ?? '' ); ?>"
								   placeholder="<?php echo esc_attr( $settings['modal_description'] ?? '' ); ?>">
							<div class="mvweb-help-text"><?php esc_html_e( 'Overrides the global modal description for this button.', 'mvweb-contact-bar' ); ?></div>
						</div>

						<!-- Direct URL (bypasses branches/contacts) -->
						<div class="mvweb-form-group">
							<label class="mvweb-label"><?php esc_html_e( 'Direct URL', 'mvweb-contact-bar' ); ?></label>
							<input type="url" class="regular-text mvweb-cb-custom-url"
								   name="buttons[<?php echo esc_attr( $index ); ?>][custom_url]"
								   value="<?php echo esc_attr( $btn['custom_url'] ?? '' ); ?>"
								   placeholder="https://example.com">
							<div class="mvweb-help-text"><?php esc_html_e( 'If set, this button will link directly to this URL instead of opening a modal. Branches and contacts below will be ignored.', 'mvweb-contact-bar' ); ?></div>
						</div>

						<!-- Direct URL target -->
						<div class="mvweb-form-group">
							<label class="mvweb-label"><?php esc_html_e( 'Open Link In', 'mvweb-contact-bar' ); ?></label>
							<select name="buttons[<?php echo esc_attr( $index ); ?>][custom_url_target]" class="mvweb-select">
								<option value="_blank" <?php selected( $btn['custom_url_target'] ?? '_blank', '_blank' ); ?>><?php esc_html_e( 'New tab', 'mvweb-contact-bar' ); ?></option>
								<option value="_self" <?php selected( $btn['custom_url_target'] ?? '_blank', '_self' ); ?>><?php esc_html_e( 'Same tab', 'mvweb-contact-bar' ); ?></option>
							</select>
							<div class="mvweb-help-text"><?php esc_html_e( 'How the Direct URL link opens when clicked.', 'mvweb-contact-bar' ); ?></div>
						</div>

						<!-- Separator after -->
						<div class="mvweb-form-group">
							<label class="mvweb-checkbox">
								<input type="checkbox"
									   name="buttons[<?php echo esc_attr( $index ); ?>][separator_after]"
									   value="1"
									   <?php checked( ! empty( $btn['separator_after'] ) ); ?>>
								<?php esc_html_e( 'Add separator after this button', 'mvweb-contact-bar' ); ?>
							</label>
						</div>

						<!-- Contacts repeater -->
						<div class="mvweb-form-group">
							<label class="mvweb-label"><?php esc_html_e( 'Contacts by Branch', 'mvweb-contact-bar' ); ?></label>

							<?php if ( ! empty( $active_branches ) ) : ?>
							<div class="mvweb-cb-contacts-repeater" data-index="<?php echo esc_attr( $index ); ?>" data-btn-type="<?php echo esc_attr( $btn_type ); ?>">
								<table class="mvweb-table mvweb-table--bordered mvweb-cb-contacts-table">
									<thead>
										<tr>
											<th><?php esc_html_e( 'Branch', 'mvweb-contact-bar' ); ?></th>
											<th><?php esc_html_e( 'URL / Phone', 'mvweb-contact-bar' ); ?></th>
											<th><?php esc_html_e( 'Display Text', 'mvweb-contact-bar' ); ?></th>
											<th></th>
										</tr>
									</thead>
									<tbody>
										<?php
										$contacts = $btn['contacts'] ?? array();
										if ( ! empty( $contacts ) ) :
											foreach ( $contacts as $ci => $contact ) :
												$is_overridden = ! empty( $contact['overridden'] );
												?>
												<tr class="mvweb-cb-contact-row<?php echo $is_overridden ? ' mvweb-cb-contact-row--overridden' : ''; ?>">
													<td>
														<select class="mvweb-select mvweb-cb-contact-branch-select"
																name="buttons[<?php echo esc_attr( $index ); ?>][contacts][<?php echo esc_attr( $ci ); ?>][branch_id]">
															<option value=""><?php esc_html_e( '— Select branch —', 'mvweb-contact-bar' ); ?></option>
															<?php foreach ( $active_branches as $ab ) : ?>
																<option value="<?php echo esc_attr( $ab['id'] ); ?>"
																	<?php selected( $contact['branch_id'] ?? '', $ab['id'] ); ?>>
																	<?php echo esc_html( $ab['name'] ?? $ab['address'] ?? '' ); ?>
																</option>
															<?php endforeach; ?>
														</select>
													</td>
													<td>
														<input type="hidden"
															   class="mvweb-cb-contact-overridden"
															   name="buttons[<?php echo esc_attr( $index ); ?>][contacts][<?php echo esc_attr( $ci ); ?>][overridden]"
															   value="<?php echo $is_overridden ? '1' : '0'; ?>">
														<input type="text" class="regular-text mvweb-cb-contact-url"
															   name="buttons[<?php echo esc_attr( $index ); ?>][contacts][<?php echo esc_attr( $ci ); ?>][url]"
															   value="<?php echo esc_attr( $contact['url'] ?? '' ); ?>"
															   placeholder="<?php esc_attr_e( 'From branch default', 'mvweb-contact-bar' ); ?>">
													</td>
													<td>
														<input type="text" class="regular-text mvweb-cb-contact-display-text"
															   name="buttons[<?php echo esc_attr( $index ); ?>][contacts][<?php echo esc_attr( $ci ); ?>][display_text]"
															   value="<?php echo esc_attr( $contact['display_text'] ?? '' ); ?>"
															   placeholder="<?php esc_attr_e( 'From branch default', 'mvweb-contact-bar' ); ?>">
													</td>
													<td class="mvweb-cb-contact-actions">
														<?php if ( $is_overridden ) : ?>
															<button type="button"
																	class="mvweb-btn mvweb-btn--sm mvweb-cb-reset-contact"
																	title="<?php esc_attr_e( 'Reset to branch default', 'mvweb-contact-bar' ); ?>">
																<span class="dashicons dashicons-image-rotate"></span>
															</button>
														<?php endif; ?>
														<button type="button"
																class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-cb-remove-contact"
																aria-label="<?php esc_attr_e( 'Remove contact', 'mvweb-contact-bar' ); ?>">
															<span class="dashicons dashicons-no-alt"></span>
														</button>
													</td>
												</tr>
											<?php endforeach; ?>
										<?php endif; ?>
									</tbody>
								</table>

								<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-cb-add-contact"
										data-index="<?php echo esc_attr( $index ); ?>">
									<span class="dashicons dashicons-plus-alt2"></span>
									<?php esc_html_e( 'Add Contact', 'mvweb-contact-bar' ); ?>
								</button>
							</div>
							<?php else : ?>
								<div class="mvweb-help-text">
									<?php esc_html_e( 'Add branches in the Branches tab to configure contacts.', 'mvweb-contact-bar' ); ?>
								</div>
							<?php endif; ?>

							<div class="mvweb-help-text">
								<?php esc_html_e( '1 contact = direct action (link/call). 2+ contacts = modal window with branch selection.', 'mvweb-contact-bar' ); ?>
							</div>
						</div>

					</div><!-- /.mvweb-cb-button-item__body -->
				</div><!-- /.mvweb-cb-button-item -->
			<?php endforeach; ?>
		<?php else : ?>
			<div class="mvweb-empty" id="mvweb-cb-buttons-empty">
				<div class="mvweb-empty__icon">
					<span class="dashicons dashicons-button"></span>
				</div>
				<div class="mvweb-empty__title"><?php esc_html_e( 'No buttons yet', 'mvweb-contact-bar' ); ?></div>
				<div class="mvweb-empty__text"><?php esc_html_e( 'Add your first button to get started.', 'mvweb-contact-bar' ); ?></div>
			</div>
		<?php endif; ?>
	</div>

</div>

<!-- Template for new button item (used by JS) -->
<script type="text/html" id="tmpl-mvweb-cb-button-item">
<div class="mvweb-cb-button-item" data-button-id="{{data.id}}" data-index="{{data.index}}">

	<input type="hidden" name="buttons[{{data.index}}][id]" value="{{data.id}}">
	<input type="hidden" name="buttons[{{data.index}}][type]" value="{{data.type}}">

	<div class="mvweb-cb-button-item__header">
		<span class="mvweb-cb-button-item__handle dashicons dashicons-menu"></span>

		<span class="mvweb-cb-button-item__preview" style="color: {{data.color}}">
			{{{data.iconHtml}}}
		</span>

		<span class="mvweb-cb-button-item__title">
			{{data.label}}
		</span>

		<span class="mvweb-cb-button-item__contacts-count">
			<?php
			printf(
				/* translators: %d: number of contacts */
				esc_html__( '%d contacts', 'mvweb-contact-bar' ),
				0
			);
			?>
		</span>

		<span class="mvweb-cb-button-item__actions">
			<label class="mvweb-toggle-label mvweb-cb-button-item__toggle-label">
				<span class="mvweb-toggle active" data-toggle="buttons[{{data.index}}][active]"></span>
			</label>
			<button type="button" class="mvweb-cb-button-item__expand dashicons dashicons-arrow-down-alt2"
					aria-label="<?php esc_attr_e( 'Expand', 'mvweb-contact-bar' ); ?>"></button>
			<button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-cb-button-item__remove"
					aria-label="<?php esc_attr_e( 'Remove', 'mvweb-contact-bar' ); ?>">
				<span class="dashicons dashicons-trash"></span>
			</button>
		</span>
	</div>

	<input type="hidden" name="buttons[{{data.index}}][active]" value="1">

	<div class="mvweb-cb-button-item__body">

		<div class="mvweb-form-group">
			<label class="mvweb-label"><?php esc_html_e( 'Button Type', 'mvweb-contact-bar' ); ?></label>
			<select class="mvweb-select mvweb-cb-type-select"
					name="buttons[{{data.index}}][type]"
					data-index="{{data.index}}">
				<?php foreach ( $preset_types as $ptype => $plabel ) : ?>
					<option value="<?php echo esc_attr( $ptype ); ?>">
						<?php echo esc_html( $plabel ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label"><?php esc_html_e( 'Label', 'mvweb-contact-bar' ); ?></label>
			<input type="text" class="regular-text"
				   name="buttons[{{data.index}}][label]"
				   value=""
				   placeholder="">
			<div class="mvweb-help-text"><?php esc_html_e( 'Leave empty to use preset default.', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label"><?php esc_html_e( 'Icon Color', 'mvweb-contact-bar' ); ?></label>
			<input type="color" class="mvweb-color mvweb-cb-color-picker"
				   name="buttons[{{data.index}}][color]"
				   value="{{data.color}}"
				   data-default="{{data.color}}">
			<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-cb-reset-color">
				<?php esc_html_e( 'Reset', 'mvweb-contact-bar' ); ?>
			</button>
			<div class="mvweb-help-text"><?php esc_html_e( 'Default is the brand color of the service.', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group mvweb-cb-custom-icon-group" style="display:none">
			<label class="mvweb-label"><?php esc_html_e( 'Custom Icon', 'mvweb-contact-bar' ); ?></label>

			<!-- FA icon picker -->
			<div class="mvweb-cb-fa-picker-wrap">
				<input type="hidden" class="mvweb-cb-fa-icon-slug"
					   name="buttons[{{data.index}}][fa_icon]"
					   value="">
				<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-cb-pick-fa-icon">
					<?php esc_html_e( 'Choose Icon', 'mvweb-contact-bar' ); ?>
				</button>
			</div>

			<div class="mvweb-cb-icon-or"><?php esc_html_e( '— or upload custom image —', 'mvweb-contact-bar' ); ?></div>

			<div class="mvweb-cb-icon-upload">
				<input type="hidden" class="mvweb-cb-custom-icon-url"
					   name="buttons[{{data.index}}][custom_icon]"
					   value="">
				<img class="mvweb-cb-custom-icon-thumb" src="" alt="" style="display:none">
				<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-cb-upload-icon">
					<?php esc_html_e( 'Upload Image', 'mvweb-contact-bar' ); ?>
				</button>
				<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-cb-remove-icon" style="display:none">
					<?php esc_html_e( 'Remove', 'mvweb-contact-bar' ); ?>
				</button>
			</div>
			<div class="mvweb-help-text"><?php esc_html_e( 'Choose a built-in icon or upload a custom image.', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label"><?php esc_html_e( 'Modal Title', 'mvweb-contact-bar' ); ?></label>
			<input type="text" class="regular-text"
				   name="buttons[{{data.index}}][modal_title]"
				   value=""
				   placeholder="">
			<div class="mvweb-help-text"><?php esc_html_e( 'Override the auto-generated modal title.', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label"><?php esc_html_e( 'Modal Description', 'mvweb-contact-bar' ); ?></label>
			<input type="text" class="regular-text"
				   name="buttons[{{data.index}}][modal_description]"
				   value=""
				   placeholder="">
			<div class="mvweb-help-text"><?php esc_html_e( 'Overrides the global modal description for this button.', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label"><?php esc_html_e( 'Direct URL', 'mvweb-contact-bar' ); ?></label>
			<input type="url" class="regular-text mvweb-cb-custom-url"
				   name="buttons[{{data.index}}][custom_url]"
				   value=""
				   placeholder="https://example.com">
			<div class="mvweb-help-text"><?php esc_html_e( 'If set, this button will link directly to this URL instead of opening a modal. Branches and contacts below will be ignored.', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label"><?php esc_html_e( 'Open Link In', 'mvweb-contact-bar' ); ?></label>
			<select name="buttons[{{data.index}}][custom_url_target]" class="mvweb-select">
				<option value="_blank" selected><?php esc_html_e( 'New tab', 'mvweb-contact-bar' ); ?></option>
				<option value="_self"><?php esc_html_e( 'Same tab', 'mvweb-contact-bar' ); ?></option>
			</select>
			<div class="mvweb-help-text"><?php esc_html_e( 'How the Direct URL link opens when clicked.', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-checkbox">
				<input type="checkbox"
					   name="buttons[{{data.index}}][separator_after]"
					   value="1">
				<?php esc_html_e( 'Add separator after this button', 'mvweb-contact-bar' ); ?>
			</label>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label"><?php esc_html_e( 'Contacts by Branch', 'mvweb-contact-bar' ); ?></label>
			<div class="mvweb-cb-contacts-repeater" data-index="{{data.index}}" data-btn-type="{{data.type}}">
				<table class="mvweb-table mvweb-table--bordered mvweb-cb-contacts-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Branch', 'mvweb-contact-bar' ); ?></th>
							<th><?php esc_html_e( 'URL / Phone', 'mvweb-contact-bar' ); ?></th>
							<th><?php esc_html_e( 'Display Text', 'mvweb-contact-bar' ); ?></th>
							<th></th>
						</tr>
					</thead>
					<tbody></tbody>
				</table>
				<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-cb-add-contact"
						data-index="{{data.index}}">
					<span class="dashicons dashicons-plus-alt2"></span>
					<?php esc_html_e( 'Add Contact', 'mvweb-contact-bar' ); ?>
				</button>
			</div>
			<div class="mvweb-help-text">
				<?php esc_html_e( '1 contact = direct action (link/call). 2+ contacts = modal window with branch selection.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>

	</div>
</div>
</script>

<!-- Template for contact row -->
<script type="text/html" id="tmpl-mvweb-cb-contact-row">
<tr class="mvweb-cb-contact-row">
	<td>
		<select class="mvweb-select mvweb-cb-contact-branch-select"
				name="buttons[{{data.btnIndex}}][contacts][{{data.contactIndex}}][branch_id]">
			<option value=""><?php esc_html_e( '— Select branch —', 'mvweb-contact-bar' ); ?></option>
			<?php foreach ( $active_branches as $branch ) : ?>
				<option value="<?php echo esc_attr( $branch['id'] ); ?>">
					<?php echo esc_html( $branch['name'] ?? $branch['address'] ?? '' ); ?>
				</option>
			<?php endforeach; ?>
		</select>
	</td>
	<td>
		<input type="hidden"
			   class="mvweb-cb-contact-overridden"
			   name="buttons[{{data.btnIndex}}][contacts][{{data.contactIndex}}][overridden]"
			   value="0">
		<input type="text" class="regular-text mvweb-cb-contact-url"
			   name="buttons[{{data.btnIndex}}][contacts][{{data.contactIndex}}][url]"
			   value=""
			   placeholder="<?php esc_attr_e( 'From branch default', 'mvweb-contact-bar' ); ?>">
	</td>
	<td>
		<input type="text" class="regular-text mvweb-cb-contact-display-text"
			   name="buttons[{{data.btnIndex}}][contacts][{{data.contactIndex}}][display_text]"
			   value=""
			   placeholder="<?php esc_attr_e( 'From branch default', 'mvweb-contact-bar' ); ?>">
	</td>
	<td class="mvweb-cb-contact-actions">
		<button type="button"
				class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-cb-remove-contact"
				aria-label="<?php esc_attr_e( 'Remove contact', 'mvweb-contact-bar' ); ?>">
			<span class="dashicons dashicons-no-alt"></span>
		</button>
	</td>
</tr>
</script>

<!-- Preset selector dialog -->
<dialog id="mvweb-cb-preset-dialog" class="mvweb-dialog">
	<div class="mvweb-dialog__header"><?php esc_html_e( 'Choose Button Type', 'mvweb-contact-bar' ); ?></div>
	<div class="mvweb-dialog__body">
		<div class="mvweb-cb-preset-grid">
			<?php foreach ( $preset_types as $ptype => $plabel ) :
				$pcolor = MVweb_CB_Icons::get_brand_color( $ptype );
				?>
				<button type="button" class="mvweb-cb-preset-option"
						data-type="<?php echo esc_attr( $ptype ); ?>"
						data-color="<?php echo esc_attr( $pcolor ); ?>"
						data-label="<?php echo esc_attr( $plabel ); ?>">
					<span class="mvweb-cb-preset-option__icon" style="color: <?php echo esc_attr( $pcolor ); ?>">
						<?php
						if ( 'custom' === $ptype ) {
							echo '<span class="dashicons dashicons-admin-links"></span>';
						} else {
							echo MVweb_CB_Icons::get( $ptype ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						}
						?>
					</span>
					<span class="mvweb-cb-preset-option__label"><?php echo esc_html( $plabel ); ?></span>
				</button>
			<?php endforeach; ?>
		</div>
	</div>
	<div class="mvweb-dialog__footer">
		<button type="button" class="mvweb-btn" onclick="this.closest('dialog').close()">
			<?php esc_html_e( 'Cancel', 'mvweb-contact-bar' ); ?>
		</button>
	</div>
</dialog>

<!-- FA icon picker dialog -->
<dialog id="mvweb-cb-fa-dialog" class="mvweb-dialog mvweb-dialog--lg">
	<div class="mvweb-dialog__header"><?php esc_html_e( 'Choose Icon', 'mvweb-contact-bar' ); ?></div>
	<div class="mvweb-dialog__body">
		<input type="text" class="regular-text mvweb-cb-fa-search"
			   placeholder="<?php esc_attr_e( 'Search icons...', 'mvweb-contact-bar' ); ?>"
			   autocomplete="off">
		<div class="mvweb-cb-fa-grid">
			<?php foreach ( MVweb_CB_Icons::get_fa_list() as $fa_slug ) : ?>
				<button type="button" class="mvweb-cb-fa-option"
						data-fa-slug="<?php echo esc_attr( $fa_slug ); ?>"
						title="<?php echo esc_attr( $fa_slug ); ?>">
					<span class="mvweb-cb-fa-option__icon">
						<?php echo MVweb_CB_Icons::get_fa( $fa_slug ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Safe: file-based SVG. ?>
					</span>
					<span class="mvweb-cb-fa-option__label"><?php echo esc_html( $fa_slug ); ?></span>
				</button>
			<?php endforeach; ?>
		</div>
	</div>
	<div class="mvweb-dialog__footer">
		<button type="button" class="mvweb-btn" onclick="this.closest('dialog').close()">
			<?php esc_html_e( 'Cancel', 'mvweb-contact-bar' ); ?>
		</button>
	</div>
</dialog>
