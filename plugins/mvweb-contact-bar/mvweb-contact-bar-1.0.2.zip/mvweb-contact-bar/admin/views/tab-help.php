<?php
/**
 * Help tab — built-in documentation for administrators.
 *
 * @package MVweb_Contact_Bar
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }
?>

<div class="mvweb-help">

	<!-- Quick Start -->
	<div class="mvweb-help__section">
		<h3><?php esc_html_e( 'Quick Start', 'mvweb-contact-bar' ); ?></h3>
		<ol class="mvweb-help__steps">
			<li><?php esc_html_e( 'Go to the Branches tab and add your office locations (name, address, working hours).', 'mvweb-contact-bar' ); ?></li>
			<li><?php esc_html_e( 'Go to the Buttons tab and add contact buttons (Phone, Telegram, WhatsApp, etc.).', 'mvweb-contact-bar' ); ?></li>
			<li><?php esc_html_e( 'For each button, add contacts linked to your branches (URL/phone + display text).', 'mvweb-contact-bar' ); ?></li>
			<li><?php esc_html_e( 'Customize appearance and behaviour in the General tab (theme, size, position, animations).', 'mvweb-contact-bar' ); ?></li>
			<li><?php esc_html_e( 'Save settings and check your site — the contact bar appears at the bottom of the page.', 'mvweb-contact-bar' ); ?></li>
		</ol>
	</div>

	<!-- How It Works -->
	<div class="mvweb-help__section">
		<h3><?php esc_html_e( 'How It Works', 'mvweb-contact-bar' ); ?></h3>
		<p><?php esc_html_e( 'The contact bar is a fixed floating panel at the bottom of the screen with quick-access buttons for phone, messengers, social networks, and custom links.', 'mvweb-contact-bar' ); ?></p>
		<ul>
			<li><strong><?php esc_html_e( '1 contact', 'mvweb-contact-bar' ); ?></strong> — <?php esc_html_e( 'direct action (call, open messenger).', 'mvweb-contact-bar' ); ?></li>
			<li><strong><?php esc_html_e( '2+ contacts', 'mvweb-contact-bar' ); ?></strong> — <?php esc_html_e( 'modal window with branch selection.', 'mvweb-contact-bar' ); ?></li>
		</ul>
		<p><?php esc_html_e( 'Switching between modes is automatic based on the number of contacts per button.', 'mvweb-contact-bar' ); ?></p>
	</div>

	<!-- Features -->
	<div class="mvweb-help__section">
		<h3><?php esc_html_e( 'Features', 'mvweb-contact-bar' ); ?></h3>
		<table class="mvweb-table mvweb-table--striped">
			<tbody>
				<tr>
					<td><strong><?php esc_html_e( 'Themes', 'mvweb-contact-bar' ); ?></strong></td>
					<td><?php esc_html_e( 'Light Glass and Dark Glass for the bar. Glass, Classic White, and Dark for modals.', 'mvweb-contact-bar' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Sizes', 'mvweb-contact-bar' ); ?></strong></td>
					<td><?php esc_html_e( 'Small (S), Medium (M), Large (L) presets.', 'mvweb-contact-bar' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Position', 'mvweb-contact-bar' ); ?></strong></td>
					<td><?php esc_html_e( 'Center, Left, or Right with customizable offsets.', 'mvweb-contact-bar' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Devices', 'mvweb-contact-bar' ); ?></strong></td>
					<td><?php esc_html_e( 'Independent visibility control for desktop, tablet, and mobile.', 'mvweb-contact-bar' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Animations', 'mvweb-contact-bar' ); ?></strong></td>
					<td><?php esc_html_e( 'Entrance animation (slide up, fade, none) with optional appearance delay.', 'mvweb-contact-bar' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Scroll', 'mvweb-contact-bar' ); ?></strong></td>
					<td><?php esc_html_e( 'Hide the bar on scroll down, show on scroll up.', 'mvweb-contact-bar' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Collapse', 'mvweb-contact-bar' ); ?></strong></td>
					<td><?php esc_html_e( 'Visitors can collapse the bar to a mini-button. State is saved in localStorage.', 'mvweb-contact-bar' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Analytics', 'mvweb-contact-bar' ); ?></strong></td>
					<td><?php esc_html_e( 'Google Analytics (gtag) and Yandex.Metrika event tracking.', 'mvweb-contact-bar' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Custom CSS', 'mvweb-contact-bar' ); ?></strong></td>
					<td><?php esc_html_e( 'Override styles with your own CSS in the General tab.', 'mvweb-contact-bar' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Presets', 'mvweb-contact-bar' ); ?></strong></td>
					<td><?php esc_html_e( '19 built-in button presets with brand colors and SVG icons: Phone, Email, Telegram, WhatsApp, Viber, VK, OK, Max, Messenger, Instagram, X, LinkedIn, Skype, Snapchat, Discord, WeChat, LINE, KakaoTalk, Zalo.', 'mvweb-contact-bar' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>

	<!-- FAQ -->
	<div class="mvweb-help__section">
		<h3><?php esc_html_e( 'FAQ', 'mvweb-contact-bar' ); ?></h3>
		<div class="mvweb-help__faq">

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'The bar is not visible on the site', 'mvweb-contact-bar' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p><?php esc_html_e( 'Check these settings:', 'mvweb-contact-bar' ); ?></p>
					<ul>
						<li><?php esc_html_e( 'Make sure at least one device checkbox is enabled (desktop/tablet/mobile).', 'mvweb-contact-bar' ); ?></li>
						<li><?php esc_html_e( 'Verify you have at least one active button with contacts.', 'mvweb-contact-bar' ); ?></li>
						<li><?php esc_html_e( 'If using appearance delay, the bar may take a few seconds to appear.', 'mvweb-contact-bar' ); ?></li>
						<li><?php esc_html_e( 'Check if the z-index is high enough — another element may be covering the bar.', 'mvweb-contact-bar' ); ?></li>
					</ul>
				</div>
			</details>

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'How do I change button order?', 'mvweb-contact-bar' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p><?php esc_html_e( 'Drag buttons by the handle icon (three horizontal lines) on the left side of each button card in the Buttons tab.', 'mvweb-contact-bar' ); ?></p>
				</div>
			</details>

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'How do I add a custom button?', 'mvweb-contact-bar' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p><?php esc_html_e( 'Click "Add Button" and select "Custom" from the preset selector. You can then upload a custom icon from the media library and configure a direct URL.', 'mvweb-contact-bar' ); ?></p>
				</div>
			</details>

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'What happens when I delete a branch?', 'mvweb-contact-bar' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p><?php esc_html_e( 'All contacts linked to that branch are automatically removed from all buttons. If a button has no remaining contacts, it will be hidden from the bar.', 'mvweb-contact-bar' ); ?></p>
				</div>
			</details>

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'How does analytics tracking work?', 'mvweb-contact-bar' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p><?php esc_html_e( 'Enable tracking in the General tab. Google Analytics requires gtag.js to be loaded on your site. Yandex.Metrika requires the counter ID.', 'mvweb-contact-bar' ); ?></p>
					<p><?php esc_html_e( 'Events: contact_bar_click (direct action), contact_bar_modal_open (modal opened), contact_bar_branch_select (branch selected in modal).', 'mvweb-contact-bar' ); ?></p>
				</div>
			</details>

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'What is the "Deferred" loading mode?', 'mvweb-contact-bar' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p><?php esc_html_e( 'Deferred mode loads JavaScript with the defer attribute and inlines critical CSS to prevent a flash of unstyled content (FOUC). Use this for better performance scores.', 'mvweb-contact-bar' ); ?></p>
				</div>
			</details>

		</div>
	</div>

	<!-- Support -->
	<div class="mvweb-help__section">
		<h3><?php esc_html_e( 'Support', 'mvweb-contact-bar' ); ?></h3>
		<p>
			<?php
			echo wp_kses(
				sprintf(
					/* translators: %s: plugin URL */
					__( 'For support and documentation, visit %s', 'mvweb-contact-bar' ),
					'<a href="https://mvweb.ru/plugins/mvweb-contact-bar" target="_blank" rel="noopener noreferrer">mvweb.ru</a>'
				),
				array( 'a' => array( 'href' => true, 'target' => true, 'rel' => true ) )
			);
			?>
		</p>
		<p class="mvweb-help__version">
			<?php
			printf(
				/* translators: %s: plugin version */
				esc_html__( 'MVweb Contact Bar v%s', 'mvweb-contact-bar' ),
				esc_html( MVWEB_CB_VERSION )
			);
			?>
		</p>
	</div>

</div>
