# Changelog

All notable changes to MVweb Contact Bar will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.5] - 2026-06-03

### Added
- Smart contact input: branch and button contacts now accept a bare phone number or username and auto-expand to the correct link by button type (phone → `tel:`, WhatsApp → `wa.me`, Viber → `viber://`, Telegram → `t.me`, email → `mailto:`, social networks → their canonical profile URL). Full links and existing values are kept untouched.

### Changed
- Submit areas use the UI Kit `.mvweb-submit` component (with a `.mvweb-submit--cb` modifier for the reset button and inline spinner) instead of the custom `.mvweb-cb-save-area`
- Empty states (Buttons, Branches tabs) use semantic `<h3>` / `<p>` and inline SVG icons instead of `<div>` and Dashicons
- Save spinner visibility is controlled via `.mvweb-cb-spinner--active` (visibility) instead of the legacy `.is-active` display toggle
- Moved inline `max-width` styles on z-index and Yandex.Metrika counter inputs into dedicated CSS classes
- Contact input placeholders updated to reflect the new number/username-friendly format

### Fixed
- Custom buttons without an uploaded image no longer show a broken-image icon — a neutral link icon is used as the default
- Completed Russian translation: 20 previously untranslated admin strings (labels, placeholders, JS notices) are now localized
- Per-button contact URL/text now always takes priority over the branch default when filled in manually; an empty field cleanly falls back to the branch default (shown as a placeholder hint)

## [1.0.4] - 2026-05-26

### Changed
- Admin UI migrated to MVweb Admin UI Kit v2 (slate palette, Yoast-style sidebar + main layout) — settings page rebuilt around `.mvweb-sidebar` / `.mvweb-main`, tabs use `.mvweb-block` sections
- All tabs rebuilt under new component classes: `.mvweb-input` / `.mvweb-select` / `.mvweb-toggle` / `.mvweb-faq` / `.mvweb-steps` instead of legacy classes
- Bundled MVweb Hub menu (`includes/class-mvweb-menu.php`) updated to the latest shared version with brand logo support and About-page hero strip
- Bundled `images/mv-logo-violet.png` so the MVweb Hub can render the brand logo even if no other plugin provides it
- Code cleanup: removed redundant inline comments across PHP/JS/CSS per project style

## [1.0.3] - 2026-04-28

### Fixed
- Custom uploaded button icon no longer drifts out of the colored circle on sites whose theme sets default `img` margin/padding/max-width — icon rule is now scoped under `#mvweb-contact-bar` for higher specificity, explicitly resets margin/padding/border/max-* and adds `overflow: hidden` on the circle as a second-line guard

## [1.0.2] - 2026-04-28

### Fixed
- Custom uploaded button icon now fills the entire colored circle and centers correctly (previously rendered at the small built-in glyph size, leaving the user logo visually offset)

## [1.0.1] - 2026-02-23

### Added
- Direct URL field for buttons — link directly to external URLs bypassing branches/contacts modal

## [1.0.0] - 2026-02-23

### Added
- Float bar panel with Liquid Glass design (light/dark themes)
- 19 button presets with SVG icons (phone, email, messengers, social)
- Modal windows for branches with 12 visual templates
- Scroll hide/show with requestAnimationFrame throttle
- Entrance animations (slide up, fade, none)
- Collapse/expand with localStorage persistence
- Delay appearance (time + scroll distance)
- Device visibility control (desktop/tablet/mobile)
- Size presets (S/M/L) and border-radius presets
- Google Analytics + Yandex.Metrika event tracking
- Accessibility: ARIA labels, focus trap, keyboard navigation, prefers-reduced-motion
- Custom CSS field with XSS-safe sanitization
- URL allowlist for non-standard schemes (viber, skype, tg, etc.)
- Normal and deferred CSS/JS loading modes
- FontAwesome Solid icon picker (2000+ icons)
- Plugin infrastructure: entry point, settings, MVweb Hub integration
