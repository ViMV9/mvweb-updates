<?php
/**
 * Frontend renderer: panel HTML, modals, asset enqueue.
 *
 * @package MVweb_Contact_Bar
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class MVweb_CB_Frontend {

	/**
	 * Plugin settings.
	 *
	 * @var array
	 */
	private array $settings = array();

	/**
	 * Active buttons (filtered, sorted).
	 *
	 * @var array
	 */
	private array $buttons = array();

	/**
	 * Constructor — register frontend hooks.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_footer', array( $this, 'render' ), 99 );
	}

	/**
	 * Enqueue CSS and JS assets.
	 *
	 * @since 1.0.0
	 */
	public function enqueue_assets(): void {
		$settings = MVweb_CB_Settings::get();

		if ( empty( $settings['enabled'] ) ) {
			return;
		}

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_style(
			'mvweb-cb-public',
			MVWEB_CB_URL . 'public/css/contact-bar' . $suffix . '.css',
			array(),
			MVWEB_CB_VERSION
		);

		wp_enqueue_style(
			'mvweb-cb-modal-tpl',
			MVWEB_CB_URL . 'public/css/modal-templates' . $suffix . '.css',
			array( 'mvweb-cb-public' ),
			MVWEB_CB_VERSION
		);

		if ( ! empty( $settings['custom_css'] ) ) {
			wp_add_inline_style( 'mvweb-cb-public', $settings['custom_css'] );
		}

		if ( 'deferred' === ( $settings['loading_mode'] ?? 'normal' ) ) {
			wp_add_inline_style( 'mvweb-cb-public', $this->generate_critical_css( $settings ) );
		}

		wp_enqueue_script(
			'mvweb-cb-public',
			MVWEB_CB_URL . 'public/js/contact-bar' . $suffix . '.js',
			array(),
			MVWEB_CB_VERSION,
			'deferred' === ( $settings['loading_mode'] ?? 'normal' )
				? array( 'in_footer' => true, 'strategy' => 'defer' )
				: array( 'in_footer' => true )
		);

		wp_localize_script(
			'mvweb-cb-public',
			'mvwebCbConfig',
			array(
				'hideOnScroll'       => (bool) $settings['hide_on_scroll'],
				'delaySeconds'       => absint( $settings['delay_seconds'] ),
				'delayScrollPx'      => absint( $settings['delay_scroll_px'] ),
				'entranceAnimation'  => sanitize_key( $settings['entrance_animation'] ),
				'allowCollapse'      => (bool) $settings['allow_collapse'],
				'modalAnimation'     => sanitize_key( $settings['modal_animation'] ),
				'gaEnabled'          => (bool) $settings['ga_enabled'],
				'ymEnabled'          => (bool) $settings['ym_enabled'],
				'ymCounterId'        => absint( $settings['ym_counter_id'] ),
				'i18n'               => array(
					'collapse' => esc_js( __( 'Collapse contact bar', 'mvweb-contact-bar' ) ),
					'expand'   => esc_js( __( 'Expand contact bar', 'mvweb-contact-bar' ) ),
				),
			)
		);
	}

	/**
	 * Render contact bar HTML in wp_footer.
	 *
	 * @since 1.0.0
	 */
	public function render(): void {
		$this->settings = MVweb_CB_Settings::get();

		if ( empty( $this->settings['enabled'] ) ) {
			return;
		}

		$this->buttons = MVweb_CB_Settings::get_active_buttons( $this->settings );

		if ( empty( $this->buttons ) ) {
			return;
		}

		$this->render_panel();
		$this->render_modals();
	}

	/**
	 * Render the floating panel.
	 *
	 * @since 1.0.0
	 */
	private function render_panel(): void {
		$s = $this->settings;

		$theme    = in_array( $s['theme'], array( 'light', 'dark' ), true ) ? $s['theme'] : 'light';
		$size     = in_array( $s['size'], array( 's', 'm', 'l' ), true ) ? $s['size'] : 'm';
		$radius   = in_array( $s['border_radius'], array( 'capsule', 'rounded', 'rect' ), true )
			? $s['border_radius'] : 'capsule';
		$position = in_array( $s['position'], array( 'center', 'left', 'right' ), true )
			? $s['position'] : 'center';

		$classes = array(
			'mvweb-cb',
			'mvweb-cb--' . $theme,
			'mvweb-cb--' . $size,
			'mvweb-cb--' . $radius,
		);

		$z_index     = absint( $s['z_index'] ?: 9999 );
		$offset_b    = absint( $s['offset_bottom'] );
		$offset_side = absint( $s['offset_side'] );

		$style = sprintf(
			'--mvweb-cb-z-index:%d;--mvweb-cb-offset-bottom:%dpx;--mvweb-cb-offset-side:%dpx;',
			$z_index,
			$offset_b,
			$offset_side
		);

		$nofollow = ! empty( $s['nofollow'] );
		?>
		<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>"
			 id="mvweb-contact-bar"
			 style="<?php echo esc_attr( $style ); ?>"
			 data-position="<?php echo esc_attr( $position ); ?>"
			 data-show-desktop="<?php echo esc_attr( ! empty( $s['show_desktop'] ) ? '1' : '0' ); ?>"
			 data-show-tablet="<?php echo esc_attr( ! empty( $s['show_tablet'] ) ? '1' : '0' ); ?>"
			 data-show-mobile="<?php echo esc_attr( ! empty( $s['show_mobile'] ) ? '1' : '0' ); ?>"
			 role="region"
			 aria-label="<?php esc_attr_e( 'Contact bar', 'mvweb-contact-bar' ); ?>">

			<?php foreach ( $this->buttons as $btn ) : ?>
				<?php $this->render_button( $btn, $nofollow ); ?>
				<?php if ( ! empty( $btn['separator_after'] ) ) : ?>
					<span class="mvweb-cb__sep" aria-hidden="true"></span>
				<?php endif; ?>
			<?php endforeach; ?>

			<?php if ( ! empty( $s['allow_collapse'] ) ) : ?>
				<button class="mvweb-cb__toggle"
						type="button"
						aria-label="<?php esc_attr_e( 'Collapse contact bar', 'mvweb-contact-bar' ); ?>"
						aria-expanded="true">
					<?php echo MVweb_CB_Icons::get_utility( 'chevron' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Safe: hardcoded SVG from class. ?>
				</button>
			<?php endif; ?>

		</div>
		<?php
	}

	/**
	 * Render a single button (link or modal trigger).
	 *
	 * @param array $btn      Button config.
	 * @param bool  $nofollow Whether to add rel="nofollow".
	 * @since 1.0.0
	 */
	private function render_button( array $btn, bool $nofollow ): void {
		$active_contacts = MVweb_CB_Settings::get_active_contacts( $btn, $this->settings );
		$is_modal = count( $active_contacts ) > 1;

		$type  = $btn['type'] ?? 'custom';
		$color = ! empty( $btn['color'] ) ? $btn['color'] : MVweb_CB_Icons::get_brand_color( $type );
		$label = ! empty( $btn['label'] ) ? $btn['label'] : MVweb_CB_Icons::get_default_label( $type );

		$icon_html = '';
		if ( 'custom' === $type && ! empty( $btn['fa_icon'] ) ) {
			$icon_html = MVweb_CB_Icons::get_fa( $btn['fa_icon'] );
		} elseif ( 'custom' === $type && ! empty( $btn['custom_icon'] ) ) {
			$icon_html = '<img src="' . esc_url( $btn['custom_icon'] ) . '" alt="" loading="lazy" />';
		} else {
			$icon_html = MVweb_CB_Icons::get( $type );
		}

		$btn_classes = 'mvweb-cb__btn mvweb-cb__btn--' . sanitize_html_class( $type );
		$btn_style   = '--mvweb-cb-btn-color:' . esc_attr( $color );

		if ( $is_modal ) {
			$btn_id = 'mvweb-cb-btn-' . esc_attr( $btn['id'] );
			?>
			<button class="<?php echo esc_attr( $btn_classes ); ?>"
					id="<?php echo esc_attr( $btn_id ); ?>"
					type="button"
					style="<?php echo esc_attr( $btn_style ); ?>"
					data-mvweb-cb-modal="<?php echo esc_attr( $btn['id'] ); ?>"
					data-mvweb-cb-type="<?php echo esc_attr( $type ); ?>"
					aria-label="<?php echo esc_attr( $label ); ?>"
					aria-haspopup="dialog">
				<span class="mvweb-cb__icon" aria-hidden="true"><?php echo $icon_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Safe: SVG from Icons class or img with esc_url. ?></span>
				<?php if ( ! empty( $this->settings['show_labels'] ) ) : ?>
					<span class="mvweb-cb__label"><?php echo esc_html( $label ); ?></span>
				<?php endif; ?>
			</button>
			<?php
		} else {
			$url = ! empty( $active_contacts[0]['url'] ) ? $active_contacts[0]['url'] : '#';

			if ( ! empty( $btn['custom_url'] ) ) {
				$target = ( $btn['custom_url_target'] ?? '_blank' ) === '_self' ? '' : '_blank';
			} else {
				$target = $this->get_link_target( $url );
			}

			$rel = $this->build_rel( $target, $nofollow );
			?>
			<a class="<?php echo esc_attr( $btn_classes ); ?>"
			   href="<?php echo esc_url( $url, MVweb_CB_Settings::URL_SCHEMES ); ?>"
			   style="<?php echo esc_attr( $btn_style ); ?>"
			   data-mvweb-cb-type="<?php echo esc_attr( $type ); ?>"
			   <?php echo $target ? 'target="' . esc_attr( $target ) . '"' : ''; ?>
			   <?php echo $rel ? 'rel="' . esc_attr( $rel ) . '"' : ''; ?>
			   aria-label="<?php echo esc_attr( $label ); ?>">
				<span class="mvweb-cb__icon" aria-hidden="true"><?php echo $icon_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<?php if ( ! empty( $this->settings['show_labels'] ) ) : ?>
					<span class="mvweb-cb__label"><?php echo esc_html( $label ); ?></span>
				<?php endif; ?>
			</a>
			<?php
		}
	}

	/**
	 * Render modal windows for buttons with 2+ contacts.
	 *
	 * @since 1.0.0
	 * @since 1.1.0 Template system support.
	 */
	private function render_modals(): void {
		$s = $this->settings;

		$modal_tpl  = $s['modal_template'] ?? 'classic-glass';
		$tpl_def    = MVweb_CB_Templates::get( $modal_tpl );
		$color_mode = in_array( $s['modal_color_mode'] ?? 'light', array( 'light', 'dark' ), true )
			? ( $s['modal_color_mode'] ?? 'light' ) : 'light';

		$tpl_class   = 'mvweb-cb-modal--tpl-' . sanitize_html_class( $modal_tpl );
		$color_class = $tpl_def['supports_color_mode'] ? ' mvweb-cb-modal--' . $color_mode : '';

		$branches_map = array();
		foreach ( $s['branches'] ?? array() as $branch ) {
			$branches_map[ $branch['id'] ] = $branch;
		}

		$nofollow       = ! empty( $s['nofollow'] );
		$modal_animation = in_array( $s['modal_animation'] ?? '', array( 'slide_up', 'scale' ), true )
			? $s['modal_animation'] : 'slide_up';

		foreach ( $this->buttons as $btn ) {
			$contacts = MVweb_CB_Settings::get_active_contacts( $btn, $s );
			if ( count( $contacts ) < 2 ) {
				continue;
			}

			$type  = $btn['type'] ?? 'custom';
			$color = ! empty( $btn['color'] ) ? $btn['color'] : MVweb_CB_Icons::get_brand_color( $type );

			if ( 'custom' === $type && ! empty( $btn['fa_icon'] ) ) {
				$icon = MVweb_CB_Icons::get_fa( $btn['fa_icon'] );
			} else {
				$icon = MVweb_CB_Icons::get( $type );
			}

			$title = ! empty( $btn['modal_title'] )
				? $btn['modal_title']
				: MVweb_CB_Icons::get_modal_title( $type );

			$description = ! empty( $btn['modal_description'] )
				? $btn['modal_description']
				: ( $s['modal_description'] ?? '' );

			$layout = count( $contacts ) >= 4 ? 'list' : 'grid';

			$modal_id   = 'mvweb-cb-modal-' . esc_attr( $btn['id'] );
			$title_id   = 'mvweb-cb-modal-title-' . esc_attr( $btn['id'] );
			$trigger_id = 'mvweb-cb-btn-' . esc_attr( $btn['id'] );
			?>
			<div class="mvweb-cb-overlay"
				 id="<?php echo esc_attr( $modal_id ); ?>"
				 data-mvweb-cb-trigger="<?php echo esc_attr( $trigger_id ); ?>"
				 data-animation="<?php echo esc_attr( $modal_animation ); ?>"
				 role="dialog"
				 aria-modal="true"
				 aria-labelledby="<?php echo esc_attr( $title_id ); ?>"
				 aria-hidden="true"
				 hidden>

				<div class="mvweb-cb-overlay__backdrop" data-mvweb-cb-close></div>

				<div class="mvweb-cb-modal <?php echo esc_attr( $tpl_class . $color_class ); ?> mvweb-cb-modal--<?php echo esc_attr( $type ); ?>"
					 tabindex="-1">

					<button class="mvweb-cb-modal__close"
							type="button"
							data-mvweb-cb-close
							aria-label="<?php esc_attr_e( 'Close', 'mvweb-contact-bar' ); ?>">
						<?php echo MVweb_CB_Icons::get_utility( 'close' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</button>

					<div class="mvweb-cb-modal__head">
						<span class="mvweb-cb-modal__head-icon" style="background-color:<?php echo esc_attr( $color ); ?>" aria-hidden="true">
							<?php echo $icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</span>
						<h2 class="mvweb-cb-modal__title" id="<?php echo esc_attr( $title_id ); ?>">
							<?php echo esc_html( $title ); ?>
						</h2>
						<?php if ( ! empty( $description ) ) : ?>
							<p class="mvweb-cb-modal__sub"><?php echo esc_html( $description ); ?></p>
						<?php endif; ?>
					</div>

					<?php
					$builtin_custom_html = array( 'timeline', 'fab' );
					if ( ! empty( $tpl_def['custom_html'] ) && in_array( $modal_tpl, $builtin_custom_html, true ) ) {
						$tpl_file = MVWEB_CB_PATH . 'public/templates/modal-' . sanitize_key( $modal_tpl ) . '.php';
						if ( file_exists( $tpl_file ) ) {
							$cb_contacts     = $contacts;
							$cb_btn          = $btn;
							$cb_settings     = $s;
							$cb_branches_map = $branches_map;
							$cb_icon         = $icon;
							$cb_nofollow     = $nofollow;
							include $tpl_file;
						} else {
							$this->render_modal_branches( $contacts, $btn, $s, $branches_map, $icon, $nofollow );
						}
					} else {
						$this->render_modal_branches( $contacts, $btn, $s, $branches_map, $icon, $nofollow );
					}
					?>

				</div>
			</div>
			<?php
		}
	}

	/**
	 * Render standard modal branches block.
	 *
	 * @since 1.1.0
	 * @param array  $contacts     Resolved contacts.
	 * @param array  $btn          Button config.
	 * @param array  $s            Full settings.
	 * @param array  $branches_map Branch data keyed by id.
	 * @param string $icon         Button icon HTML.
	 * @param bool   $nofollow     Add nofollow.
	 */
	private function render_modal_branches(
		array $contacts,
		array $btn,
		array $s,
		array $branches_map,
		string $icon,
		bool $nofollow
	): void {
		$type   = $btn['type'] ?? 'custom';
		$color  = ! empty( $btn['color'] ) ? $btn['color'] : MVweb_CB_Icons::get_brand_color( $type );
		$layout = count( $contacts ) >= 4 ? 'list' : 'grid';
		?>
		<div class="mvweb-cb-modal__branches mvweb-cb-modal__branches--<?php echo esc_attr( $layout ); ?>">
			<?php foreach ( $contacts as $contact ) :
				$branch = $branches_map[ $contact['branch_id'] ?? '' ] ?? array();
				$url    = $contact['url'] ?? '';
				$target = $this->get_link_target( $url );
				$rel    = $this->build_rel( $target, $nofollow );
				$handle_color = 'service' === ( $s['handle_color_mode'] ?? 'service' ) ? $color : 'inherit';
				?>
				<a class="mvweb-cb-branch"
				   href="<?php echo esc_url( $url, MVweb_CB_Settings::URL_SCHEMES ); ?>"
				   <?php echo $target ? 'target="' . esc_attr( $target ) . '"' : ''; ?>
				   <?php echo $rel ? 'rel="' . esc_attr( $rel ) . '"' : ''; ?>
				   data-mvweb-cb-type="<?php echo esc_attr( $type ); ?>"
				   data-mvweb-cb-btn-id="<?php echo esc_attr( $btn['id'] ); ?>"
				   data-mvweb-cb-branch-id="<?php echo esc_attr( $contact['branch_id'] ?? '' ); ?>">

					<span class="mvweb-cb-branch__info">
						<?php if ( ! empty( $branch['address'] ) ) : ?>
							<span class="mvweb-cb-branch__addr">
								<span class="mvweb-cb-branch__icon" aria-hidden="true"><?php echo MVweb_CB_Icons::get_utility( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
								<?php echo esc_html( $branch['address'] ); ?>
							</span>
						<?php elseif ( ! empty( $branch['name'] ) ) : ?>
							<span class="mvweb-cb-branch__addr">
								<span class="mvweb-cb-branch__icon" aria-hidden="true"><?php echo MVweb_CB_Icons::get_utility( 'pin' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
								<?php echo esc_html( $branch['name'] ); ?>
							</span>
						<?php endif; ?>

						<span class="mvweb-cb-branch__handle" style="color:<?php echo esc_attr( $handle_color ); ?>">
							<span class="mvweb-cb-branch__handle-icon" aria-hidden="true"><?php echo $icon; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<?php echo esc_html( $contact['display_text'] ?? '' ); ?>
						</span>

						<?php if ( ! empty( $branch['hours'] ) ) : ?>
							<span class="mvweb-cb-branch__time">
								<span class="mvweb-cb-branch__time-icon" aria-hidden="true"><?php echo MVweb_CB_Icons::get_utility( 'clock' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
								<?php echo esc_html( $branch['hours'] ); ?>
							</span>
						<?php endif; ?>
					</span>

					<span class="mvweb-cb-branch__arrow" aria-hidden="true">&rarr;</span>
				</a>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/**
	 * Determine link target based on URL scheme.
	 *
	 * tel: and mailto: open natively (current tab).
	 * Everything else opens in a new tab.
	 *
	 * @param string $url URL to check.
	 * @return string '_blank' or empty string.
	 */
	private function get_link_target( string $url ): string {
		if ( str_starts_with( $url, 'tel:' ) || str_starts_with( $url, 'mailto:' ) ) {
			return '';
		}
		return '_blank';
	}

	/**
	 * Build rel attribute string.
	 *
	 * @param string $target   Link target (_blank or empty).
	 * @param bool   $nofollow Whether to add nofollow.
	 * @return string Rel attribute value.
	 */
	private function build_rel( string $target, bool $nofollow ): string {
		$parts = array();

		if ( '_blank' === $target ) {
			$parts[] = 'noopener';
			$parts[] = 'noreferrer';
		}

		if ( $nofollow ) {
			$parts[] = 'nofollow';
		}

		return implode( ' ', $parts );
	}

	/**
	 * Generate critical CSS for deferred loading mode.
	 *
	 * Prevents FOUC by positioning panel and hiding it until CSS loads.
	 *
	 * @param array $settings Plugin settings.
	 * @return string Critical CSS (~200-400 bytes).
	 */
	private function generate_critical_css( array $settings ): string {
		$z   = absint( $settings['z_index'] ?: 9999 );
		$bot = absint( $settings['offset_bottom'] );

		return sprintf(
			'.mvweb-cb{position:fixed;bottom:%dpx;z-index:%d;opacity:0;pointer-events:none}.mvweb-cb-overlay{display:none}',
			$bot,
			$z
		);
	}
}
