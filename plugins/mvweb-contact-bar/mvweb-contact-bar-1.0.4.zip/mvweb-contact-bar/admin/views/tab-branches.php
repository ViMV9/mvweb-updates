<?php
/**
 * Branches tab — CRUD, drag-and-drop sorting.
 *
 * Variables available from settings-page.php:
 *   $settings — full plugin settings array
 *
 * @package MVweb_Contact_Bar
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

$branches = $settings['branches'] ?? array();

// Preset types that can have branch-level defaults (no 'custom').
$branch_contact_types = array(
	'phone'     => __( 'Phone', 'mvweb-contact-bar' ),
	'email'     => __( 'Email', 'mvweb-contact-bar' ),
	'telegram'  => 'Telegram',
	'whatsapp'  => 'WhatsApp',
	'viber'     => 'Viber',
	'vk'        => 'VK',
	'ok'        => 'OK',
	'max'       => 'Max',
	'messenger' => 'Messenger',
	'instagram' => 'Instagram',
	'x'         => 'X',
	'linkedin'  => 'LinkedIn',
	'snapchat'  => 'Snapchat',
	'discord'   => 'Discord',
);
?>

<div class="mvweb-cb-branches-tab">

	<div class="mvweb-toolbar">
		<button type="button" class="mvweb-btn mvweb-btn--primary" id="mvweb-cb-add-branch">
			<span class="dashicons dashicons-plus-alt2"></span>
			<?php esc_html_e( 'Add Branch', 'mvweb-contact-bar' ); ?>
		</button>
		<span class="mvweb-help-text">
			<?php esc_html_e( 'Add your offices or branches. Drag to reorder.', 'mvweb-contact-bar' ); ?>
		</span>
	</div>

	<div class="mvweb-cb-branches-list" id="mvweb-cb-branches-list">
		<?php
		if ( ! empty( $branches ) ) :
			foreach ( $branches as $index => $branch ) :
				$branch_id   = $branch['id'] ?? 'branch_' . $index;
				$branch_name = $branch['name'] ?? '';
				$is_active   = ! empty( $branch['active'] );
				$bc_list     = $branch['contacts'] ?? array();
				?>
				<div class="mvweb-cb-branch-item<?php echo ! $is_active ? ' mvweb-cb-branch-item--inactive' : ''; ?>"
					 data-branch-id="<?php echo esc_attr( $branch_id ); ?>"
					 data-index="<?php echo esc_attr( $index ); ?>">

					<input type="hidden" name="branches[<?php echo esc_attr( $index ); ?>][id]"
						   value="<?php echo esc_attr( $branch_id ); ?>">

					<!-- Header (collapsed view) -->
					<div class="mvweb-cb-branch-item__header">
						<span class="mvweb-cb-branch-item__handle dashicons dashicons-menu"></span>

						<span class="mvweb-cb-branch-item__icon dashicons dashicons-location"></span>

						<span class="mvweb-cb-branch-item__title">
							<?php echo esc_html( $branch_name ?: __( 'New Branch', 'mvweb-contact-bar' ) ); ?>
						</span>

						<?php if ( ! empty( $branch['address'] ) ) : ?>
							<span class="mvweb-cb-branch-item__address">
								<?php echo esc_html( $branch['address'] ); ?>
							</span>
						<?php endif; ?>

						<span class="mvweb-cb-branch-item__actions">
							<label class="mvweb-toggle-label mvweb-cb-branch-item__toggle-label">
								<span class="mvweb-toggle<?php echo $is_active ? ' active' : ''; ?>"
									  data-toggle="branches[<?php echo esc_attr( $index ); ?>][active]"></span>
							</label>
							<button type="button" class="mvweb-cb-branch-item__expand dashicons dashicons-arrow-down-alt2"
									aria-label="<?php esc_attr_e( 'Expand', 'mvweb-contact-bar' ); ?>"></button>
							<button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-cb-branch-item__remove"
									aria-label="<?php esc_attr_e( 'Remove', 'mvweb-contact-bar' ); ?>">
								<span class="dashicons dashicons-trash"></span>
							</button>
						</span>
					</div>

					<input type="hidden" name="branches[<?php echo esc_attr( $index ); ?>][active]"
						   value="<?php echo $is_active ? '1' : '0'; ?>">

					<!-- Body (expanded view) -->
					<div class="mvweb-cb-branch-item__body" style="display: none;">

						<div class="mvweb-form-group">
							<label class="mvweb-label"><?php esc_html_e( 'Name', 'mvweb-contact-bar' ); ?> <span class="mvweb-required">*</span></label>
							<input type="text" class="mvweb-input mvweb-cb-branch-name"
								   name="branches[<?php echo esc_attr( $index ); ?>][name]"
								   value="<?php echo esc_attr( $branch['name'] ?? '' ); ?>"
								   placeholder="<?php esc_attr_e( 'e.g. Main Office', 'mvweb-contact-bar' ); ?>"
								   required>
						</div>

						<div class="mvweb-form-group">
							<label class="mvweb-label"><?php esc_html_e( 'Address', 'mvweb-contact-bar' ); ?> <span class="mvweb-required">*</span></label>
							<input type="text" class="mvweb-input mvweb-cb-branch-address"
								   name="branches[<?php echo esc_attr( $index ); ?>][address]"
								   value="<?php echo esc_attr( $branch['address'] ?? '' ); ?>"
								   placeholder="<?php esc_attr_e( 'e.g. 123 Main Street, City', 'mvweb-contact-bar' ); ?>"
								   required>
						</div>

						<div class="mvweb-form-group">
							<label class="mvweb-label"><?php esc_html_e( 'Working Hours', 'mvweb-contact-bar' ); ?></label>
							<input type="text" class="mvweb-input"
								   name="branches[<?php echo esc_attr( $index ); ?>][hours]"
								   value="<?php echo esc_attr( $branch['hours'] ?? '' ); ?>"
								   placeholder="<?php esc_attr_e( 'e.g. Mon-Fri 9:00-18:00', 'mvweb-contact-bar' ); ?>">
							<div class="mvweb-help-text"><?php esc_html_e( 'Optional. Free-form text displayed in modal cards.', 'mvweb-contact-bar' ); ?></div>
						</div>

						<!-- Default Contacts repeater -->
						<div class="mvweb-form-group">
							<label class="mvweb-label"><?php esc_html_e( 'Default Contacts', 'mvweb-contact-bar' ); ?></label>
							<div class="mvweb-help-text mvweb-cb-help-text--spaced">
								<?php esc_html_e( 'Set default URLs per service type. Buttons will use these unless overridden.', 'mvweb-contact-bar' ); ?>
							</div>

							<div class="mvweb-cb-branch-contacts-repeater" data-index="<?php echo esc_attr( $index ); ?>">
								<table class="mvweb-table mvweb-cb-branch-contacts-table">
									<thead>
										<tr>
											<th><?php esc_html_e( 'Type', 'mvweb-contact-bar' ); ?></th>
											<th><?php esc_html_e( 'URL / Phone', 'mvweb-contact-bar' ); ?></th>
											<th><?php esc_html_e( 'Display Text', 'mvweb-contact-bar' ); ?></th>
											<th></th>
										</tr>
									</thead>
									<tbody>
										<?php foreach ( $bc_list as $bci => $bc ) : ?>
											<tr class="mvweb-cb-branch-contact-row">
												<td>
													<select class="mvweb-select mvweb-cb-branch-contact-type"
															name="branches[<?php echo esc_attr( $index ); ?>][contacts][<?php echo esc_attr( $bci ); ?>][type]">
														<?php foreach ( $branch_contact_types as $bct => $bct_label ) : ?>
															<option value="<?php echo esc_attr( $bct ); ?>"
																<?php selected( $bc['type'] ?? '', $bct ); ?>>
																<?php echo esc_html( $bct_label ); ?>
															</option>
														<?php endforeach; ?>
													</select>
												</td>
												<td>
													<input type="text" class="mvweb-input"
														   name="branches[<?php echo esc_attr( $index ); ?>][contacts][<?php echo esc_attr( $bci ); ?>][url]"
														   value="<?php echo esc_attr( $bc['url'] ?? '' ); ?>"
														   placeholder="tel:+7... / https://t.me/...">
												</td>
												<td>
													<input type="text" class="mvweb-input"
														   name="branches[<?php echo esc_attr( $index ); ?>][contacts][<?php echo esc_attr( $bci ); ?>][display_text]"
														   value="<?php echo esc_attr( $bc['display_text'] ?? '' ); ?>"
														   placeholder="+7 (000) ... / @username">
												</td>
												<td>
													<button type="button"
															class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-cb-remove-branch-contact"
															aria-label="<?php esc_attr_e( 'Remove', 'mvweb-contact-bar' ); ?>">
														<span class="dashicons dashicons-no-alt"></span>
													</button>
												</td>
											</tr>
										<?php endforeach; ?>
									</tbody>
								</table>

								<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-cb-add-branch-contact"
										data-index="<?php echo esc_attr( $index ); ?>">
									<span class="dashicons dashicons-plus-alt2"></span>
									<?php esc_html_e( 'Add Contact Type', 'mvweb-contact-bar' ); ?>
								</button>
							</div>
						</div>

					</div><!-- /.mvweb-cb-branch-item__body -->
				</div><!-- /.mvweb-cb-branch-item -->
			<?php endforeach; ?>
		<?php else : ?>
			<div class="mvweb-empty" id="mvweb-cb-branches-empty">
				<div class="mvweb-empty__icon">
					<span class="dashicons dashicons-location"></span>
				</div>
				<div class="mvweb-empty__title"><?php esc_html_e( 'No branches yet', 'mvweb-contact-bar' ); ?></div>
				<div class="mvweb-empty__text"><?php esc_html_e( 'Add your first branch to get started. Branches are used for multi-location contact selection.', 'mvweb-contact-bar' ); ?></div>
			</div>
		<?php endif; ?>
	</div>

</div>

<!-- Template for new branch item (used by JS) -->
<script type="text/html" id="tmpl-mvweb-cb-branch-item">
<div class="mvweb-cb-branch-item" data-branch-id="{{data.id}}" data-index="{{data.index}}">

	<input type="hidden" name="branches[{{data.index}}][id]" value="{{data.id}}">

	<div class="mvweb-cb-branch-item__header">
		<span class="mvweb-cb-branch-item__handle dashicons dashicons-menu"></span>

		<span class="mvweb-cb-branch-item__icon dashicons dashicons-location"></span>

		<span class="mvweb-cb-branch-item__title">
			<?php esc_html_e( 'New Branch', 'mvweb-contact-bar' ); ?>
		</span>

		<span class="mvweb-cb-branch-item__actions">
			<label class="mvweb-toggle-label mvweb-cb-branch-item__toggle-label">
				<span class="mvweb-toggle active" data-toggle="branches[{{data.index}}][active]"></span>
			</label>
			<button type="button" class="mvweb-cb-branch-item__expand dashicons dashicons-arrow-up-alt2"
					aria-label="<?php esc_attr_e( 'Expand', 'mvweb-contact-bar' ); ?>"></button>
			<button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-cb-branch-item__remove"
					aria-label="<?php esc_attr_e( 'Remove', 'mvweb-contact-bar' ); ?>">
				<span class="dashicons dashicons-trash"></span>
			</button>
		</span>
	</div>

	<input type="hidden" name="branches[{{data.index}}][active]" value="1">

	<div class="mvweb-cb-branch-item__body">

		<div class="mvweb-form-group">
			<label class="mvweb-label"><?php esc_html_e( 'Name', 'mvweb-contact-bar' ); ?> <span class="mvweb-required">*</span></label>
			<input type="text" class="mvweb-input mvweb-cb-branch-name"
				   name="branches[{{data.index}}][name]"
				   value=""
				   placeholder="<?php esc_attr_e( 'e.g. Main Office', 'mvweb-contact-bar' ); ?>"
				   required>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label"><?php esc_html_e( 'Address', 'mvweb-contact-bar' ); ?> <span class="mvweb-required">*</span></label>
			<input type="text" class="mvweb-input mvweb-cb-branch-address"
				   name="branches[{{data.index}}][address]"
				   value=""
				   placeholder="<?php esc_attr_e( 'e.g. 123 Main Street, City', 'mvweb-contact-bar' ); ?>"
				   required>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label"><?php esc_html_e( 'Working Hours', 'mvweb-contact-bar' ); ?></label>
			<input type="text" class="mvweb-input"
				   name="branches[{{data.index}}][hours]"
				   value=""
				   placeholder="<?php esc_attr_e( 'e.g. Mon-Fri 9:00-18:00', 'mvweb-contact-bar' ); ?>">
			<div class="mvweb-help-text"><?php esc_html_e( 'Optional. Free-form text displayed in modal cards.', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label"><?php esc_html_e( 'Default Contacts', 'mvweb-contact-bar' ); ?></label>
			<div class="mvweb-help-text mvweb-cb-help-text--spaced">
				<?php esc_html_e( 'Set default URLs per service type. Buttons will use these unless overridden.', 'mvweb-contact-bar' ); ?>
			</div>
			<div class="mvweb-cb-branch-contacts-repeater" data-index="{{data.index}}">
				<table class="mvweb-table mvweb-cb-branch-contacts-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Type', 'mvweb-contact-bar' ); ?></th>
							<th><?php esc_html_e( 'URL / Phone', 'mvweb-contact-bar' ); ?></th>
							<th><?php esc_html_e( 'Display Text', 'mvweb-contact-bar' ); ?></th>
							<th></th>
						</tr>
					</thead>
					<tbody></tbody>
				</table>
				<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-cb-add-branch-contact"
						data-index="{{data.index}}">
					<span class="dashicons dashicons-plus-alt2"></span>
					<?php esc_html_e( 'Add Contact Type', 'mvweb-contact-bar' ); ?>
				</button>
			</div>
		</div>

	</div>
</div>
</script>

<!-- Template for branch contact row (used by JS) -->
<script type="text/html" id="tmpl-mvweb-cb-branch-contact-row">
<tr class="mvweb-cb-branch-contact-row">
	<td>
		<select class="mvweb-select mvweb-cb-branch-contact-type"
				name="branches[{{data.branchIndex}}][contacts][{{data.contactIndex}}][type]">
			<?php foreach ( $branch_contact_types as $bct => $bct_label ) : ?>
				<option value="<?php echo esc_attr( $bct ); ?>"><?php echo esc_html( $bct_label ); ?></option>
			<?php endforeach; ?>
		</select>
	</td>
	<td>
		<input type="text" class="mvweb-input"
			   name="branches[{{data.branchIndex}}][contacts][{{data.contactIndex}}][url]"
			   value=""
			   placeholder="tel:+7... / https://t.me/...">
	</td>
	<td>
		<input type="text" class="mvweb-input"
			   name="branches[{{data.branchIndex}}][contacts][{{data.contactIndex}}][display_text]"
			   value=""
			   placeholder="+7 (000) ... / @username">
	</td>
	<td>
		<button type="button"
				class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-cb-remove-branch-contact"
				aria-label="<?php esc_attr_e( 'Remove', 'mvweb-contact-bar' ); ?>">
			<span class="dashicons dashicons-no-alt"></span>
		</button>
	</td>
</tr>
</script>
