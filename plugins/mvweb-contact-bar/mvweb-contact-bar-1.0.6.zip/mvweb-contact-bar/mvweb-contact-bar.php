<?php
/**
 * Plugin Name:       MVweb Contact Bar
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-contact-bar
 * Description:       Fixed contact panel (float bar) in Liquid Glass style with phone, messengers, social links.
 * Version:           1.0.6
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-contact-bar
 * Domain Path:       /languages
 *
 * @package MVweb_Contact_Bar
 *
 * @since 1.0.0 Initial release.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( defined( 'MVWEB_CB_VERSION' ) ) { return; }

define( 'MVWEB_CB_VERSION',  '1.0.6' );
define( 'MVWEB_CB_PATH',     plugin_dir_path( __FILE__ ) );
define( 'MVWEB_CB_URL',      plugin_dir_url( __FILE__ ) );
define( 'MVWEB_CB_BASENAME', plugin_basename( __FILE__ ) );

$shared_path = dirname( dirname( MVWEB_CB_PATH ) ) . '/shared/';

if ( file_exists( MVWEB_CB_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_CB_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Always call get_instance() here — do NOT rely on call at end of class file.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

if ( file_exists( MVWEB_CB_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_CB_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}
if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-contact-bar' );
}

add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-contact-bar'] = array(
		'name'         => 'MVweb Contact Bar',
		'description'  => 'Fixed contact panel (float bar) in Liquid Glass style.',
		'url'          => 'https://mvweb.ru/plugins/mvweb-contact-bar',
		'settings_url' => 'admin.php?page=mvweb-contact-bar',
		'textdomain'   => 'mvweb-contact-bar',
	);
	return $plugins;
} );

/**
 * Translate plugin Name and Description on the Plugins screen.
 *
 * @param array $plugins All plugins data.
 * @return array
 */
function mvweb_cb_translate_plugin_meta( $plugins ) {
	$plugin_file = plugin_basename( __FILE__ );

	if ( isset( $plugins[ $plugin_file ] ) ) {
		if ( ! is_textdomain_loaded( 'mvweb-contact-bar' ) ) {
			load_plugin_textdomain(
				'mvweb-contact-bar',
				false,
				dirname( $plugin_file ) . '/languages/'
			);
		}

		$plugins[ $plugin_file ]['Name']        = __( 'MVweb Contact Bar', 'mvweb-contact-bar' );
		$plugins[ $plugin_file ]['Title']       = __( 'MVweb Contact Bar', 'mvweb-contact-bar' );
		$plugins[ $plugin_file ]['Description'] = __( 'Fixed contact panel (float bar) in Liquid Glass style with phone, messengers, social links.', 'mvweb-contact-bar' );
	}

	return $plugins;
}
add_filter( 'all_plugins', 'mvweb_cb_translate_plugin_meta' );

require_once MVWEB_CB_PATH . 'includes/class-mvweb-cb-settings.php';
require_once MVWEB_CB_PATH . 'includes/class-mvweb-cb-templates.php';
require_once MVWEB_CB_PATH . 'includes/class-mvweb-cb-icons.php';
require_once MVWEB_CB_PATH . 'includes/class-mvweb-cb-core.php';

register_activation_hook( __FILE__, array( 'MVweb_CB_Core', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'MVweb_CB_Core', 'deactivate' ));

MVweb_CB_Core::init();
