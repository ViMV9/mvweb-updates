<?php
/**
 * Core plugin class — orchestrates all components.
 *
 * Handles: textdomain loading, admin menu registration,
 * admin asset enqueue, activation/deactivation hooks routing.
 *
 * @package MVweb_Contact_Bar
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class MVweb_CB_Core {

	/**
	 * Boot the plugin.
	 *
	 * @since 1.0.0
	 */
	public static function init(): void {
		add_action( 'plugins_loaded', array( __CLASS__, 'load_textdomain' ) );
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'admin_enqueue' ) );

		if ( is_admin() ) {
			require_once MVWEB_CB_PATH . 'includes/class-mvweb-cb-admin.php';
			new MVweb_CB_Admin();
		}

		if ( ! is_admin() ) {
			require_once MVWEB_CB_PATH . 'includes/class-mvweb-cb-frontend.php';
			new MVweb_CB_Frontend();
		}
	}

	/**
	 * Load plugin textdomain.
	 *
	 * @since 1.0.0
	 */
	public static function load_textdomain(): void {
		load_plugin_textdomain(
			'mvweb-contact-bar',
			false,
			dirname( MVWEB_CB_BASENAME ) . '/languages/'
		);
	}

	/**
	 * Register admin submenu under MVweb Hub.
	 *
	 * @since 1.0.0
	 */
	public static function register_menu(): void {
		$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

		add_submenu_page(
			$parent_slug,
			__( 'Contact Bar', 'mvweb-contact-bar' ),
			__( 'Contact Bar', 'mvweb-contact-bar' ),
			'manage_options',
			'mvweb-contact-bar',
			array( __CLASS__, 'render_settings_page' )
		);
	}

	/**
	 * Render settings page.
	 *
	 * @since 1.0.0
	 */
	public static function render_settings_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		include MVWEB_CB_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Enqueue admin assets on plugin settings page only.
	 *
	 * @param string $hook Current admin page hook.
	 * @since 1.0.0
	 */
	public static function admin_enqueue( string $hook ): void {
		if ( false === strpos( $hook, 'mvweb-contact-bar' ) ) {
			return;
		}

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_media();

		wp_enqueue_style(
			'mvweb-cb-admin',
			MVWEB_CB_URL . 'admin/css/admin' . $suffix . '.css',
			array(),
			MVWEB_CB_VERSION
		);

		wp_enqueue_style(
			'mvweb-cb-plugin',
			MVWEB_CB_URL . 'admin/css/plugin' . $suffix . '.css',
			array( 'mvweb-cb-admin' ),
			MVWEB_CB_VERSION
		);

		wp_enqueue_script(
			'mvweb-cb-admin',
			MVWEB_CB_URL . 'admin/js/admin' . $suffix . '.js',
			array(),
			MVWEB_CB_VERSION,
			true
		);

		$settings   = MVweb_CB_Settings::get();
		$all_icons  = MVweb_CB_Icons::get_all();
		$all_colors = array();
		$all_labels = array();
		foreach ( array_keys( $all_icons ) as $type ) {
			$all_colors[ $type ] = MVweb_CB_Icons::get_brand_color( $type );
			$all_labels[ $type ] = MVweb_CB_Icons::get_default_label( $type );
		}
		$all_colors['custom'] = '#793ea4';
		$all_labels['custom'] = __( 'Custom', 'mvweb-contact-bar' );

		wp_localize_script(
			'mvweb-cb-admin',
			'mvwebCbAdmin',
			array(
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'nonces'       => array(
					'saveSettings'  => wp_create_nonce( 'mvweb_cb_save_settings' ),
					'sortButtons'   => wp_create_nonce( 'mvweb_cb_sort_buttons' ),
					'sortBranches'  => wp_create_nonce( 'mvweb_cb_sort_branches' ),
					'resetSettings' => wp_create_nonce( 'mvweb_cb_reset_settings' ),
				),
				'presetIcons'  => $all_icons,
				'presetColors' => $all_colors,
				'presetLabels' => $all_labels,
				'branches'       => array_values( $settings['branches'] ?? array() ),
				'modalTemplates' => array_values(
					array_map(
						fn( $t ) => array(
							'slug'              => $t['slug'],
							'label'             => $t['label'],
							'supportsColorMode' => $t['supports_color_mode'],
						),
						MVweb_CB_Templates::get_all()
					)
				),
				'i18n'           => array(
					'confirmRemoveButton'     => __( 'Remove this button?', 'mvweb-contact-bar' ),
					'noButtons'               => __( 'No buttons yet', 'mvweb-contact-bar' ),
					'addFirst'                => __( 'Add your first button to get started.', 'mvweb-contact-bar' ),
					'contact'                 => __( 'contact', 'mvweb-contact-bar' ),
					'contacts'                => __( 'contacts', 'mvweb-contact-bar' ),
					'selectIcon'              => __( 'Select Icon', 'mvweb-contact-bar' ),
					'useImage'                => __( 'Use this image', 'mvweb-contact-bar' ),
					'confirmRemoveBranch'     => __( 'Remove this branch? Contacts linked to this branch will also be removed.', 'mvweb-contact-bar' ),
					'noBranches'              => __( 'No branches yet', 'mvweb-contact-bar' ),
					'addFirstBranch'          => __( 'Add your first branch to get started.', 'mvweb-contact-bar' ),
					'newBranch'               => __( 'New Branch', 'mvweb-contact-bar' ),
					'resetSuccess'            => __( 'Settings reset to defaults.', 'mvweb-contact-bar' ),
					'overridden'              => __( 'Overridden', 'mvweb-contact-bar' ),
					'resetToDefault'          => __( 'Reset to branch default', 'mvweb-contact-bar' ),
					'noBranchDefault'         => __( 'No branch default for this type', 'mvweb-contact-bar' ),
					'selectBranchFirst'       => __( '— Select branch —', 'mvweb-contact-bar' ),
					'addBranchContact'        => __( 'Add Contact Type', 'mvweb-contact-bar' ),
					'confirmRemoveBranchContact' => __( 'Remove this contact type?', 'mvweb-contact-bar' ),
					'saveFailed'              => __( 'Save failed.', 'mvweb-contact-bar' ),
					'networkError'            => __( 'Network error. Please try again.', 'mvweb-contact-bar' ),
					'resetFailed'             => __( 'Reset failed.', 'mvweb-contact-bar' ),
					'fromBranchDefault'       => __( 'From branch default', 'mvweb-contact-bar' ),
				),
			)
		);
	}

	/**
	 * Activation hook — set default settings with sample data.
	 *
	 * @since 1.0.0
	 */
	public static function activate(): void {
		require_once MVWEB_CB_PATH . 'includes/class-mvweb-cb-settings.php';

		if ( false === get_option( MVweb_CB_Settings::OPTION_NAME ) ) {
			add_option(
				MVweb_CB_Settings::OPTION_NAME,
				MVweb_CB_Settings::get_sample_data(),
				'',
				'yes'
			);
		}

		update_option( 'mvweb_cb_version', MVWEB_CB_VERSION );
	}

	/**
	 * Deactivation hook — data preserved.
	 *
	 * @since 1.0.0
	 */
	public static function deactivate(): void {
	}
}
