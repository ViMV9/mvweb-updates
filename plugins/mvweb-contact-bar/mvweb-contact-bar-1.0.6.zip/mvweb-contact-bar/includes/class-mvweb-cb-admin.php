<?php
/**
 * Admin AJAX handlers: save settings, sort buttons/branches, reset.
 *
 * @package MVweb_Contact_Bar
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class MVweb_CB_Admin {

	/**
	 * Constructor — register AJAX hooks.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'wp_ajax_mvweb_cb_save_settings', array( $this, 'save_settings' ) );
		add_action( 'wp_ajax_mvweb_cb_sort_buttons', array( $this, 'sort_buttons' ) );
		add_action( 'wp_ajax_mvweb_cb_sort_branches', array( $this, 'sort_branches' ) );
		add_action( 'wp_ajax_mvweb_cb_reset_settings', array( $this, 'reset_settings' ) );
	}

	/**
	 * Save all settings from admin form.
	 *
	 * @since 1.0.0
	 */
	public function save_settings(): void {
		if ( ! check_ajax_referer( 'mvweb_cb_save_settings', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid security token.', 'mvweb-contact-bar' ) ) );
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mvweb-contact-bar' ) ) );
		}

		$settings = MVweb_CB_Settings::get();
		$tab      = sanitize_key( wp_unslash( $_POST['tab'] ?? '' ) );

		if ( 'general' === $tab ) {
			$settings = $this->sanitize_general_tab( $settings );
		} elseif ( 'buttons' === $tab ) {
			$settings = $this->sanitize_buttons_tab( $settings );
		} elseif ( 'branches' === $tab ) {
			$settings = $this->sanitize_branches_tab( $settings );
		}

		MVweb_CB_Settings::save( $settings );

		wp_send_json_success( array( 'message' => __( 'Settings saved.', 'mvweb-contact-bar' ) ) );
	}

	/**
	 * Sort buttons via drag-and-drop.
	 *
	 * @since 1.0.0
	 */
	public function sort_buttons(): void {
		if ( ! check_ajax_referer( 'mvweb_cb_sort_buttons', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid security token.', 'mvweb-contact-bar' ) ) );
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mvweb-contact-bar' ) ) );
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per-element below.
		$order = isset( $_POST['order'] ) ? (array) wp_unslash( $_POST['order'] ) : array();
		$order = array_map( 'sanitize_key', $order );

		$settings = MVweb_CB_Settings::get();
		$buttons  = $settings['buttons'] ?? array();

		$map = array();
		foreach ( $buttons as $btn ) {
			$map[ $btn['id'] ] = $btn;
		}

		$sorted = array();
		$i      = 0;
		foreach ( $order as $btn_id ) {
			if ( isset( $map[ $btn_id ] ) ) {
				$map[ $btn_id ]['order'] = $i;
				$sorted[]                = $map[ $btn_id ];
				$i++;
			}
		}

		foreach ( $map as $btn_id => $btn ) {
			if ( ! in_array( $btn_id, $order, true ) ) {
				$btn['order'] = $i;
				$sorted[]     = $btn;
				$i++;
			}
		}

		$settings['buttons'] = $sorted;
		MVweb_CB_Settings::save( $settings );

		wp_send_json_success();
	}

	/**
	 * Sort branches via drag-and-drop.
	 *
	 * @since 1.0.0
	 */
	public function sort_branches(): void {
		if ( ! check_ajax_referer( 'mvweb_cb_sort_branches', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid security token.', 'mvweb-contact-bar' ) ) );
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mvweb-contact-bar' ) ) );
		}

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per-element below.
		$order = isset( $_POST['order'] ) ? (array) wp_unslash( $_POST['order'] ) : array();
		$order = array_map( 'sanitize_key', $order );

		$settings = MVweb_CB_Settings::get();
		$branches = $settings['branches'] ?? array();

		$map = array();
		foreach ( $branches as $branch ) {
			$map[ $branch['id'] ] = $branch;
		}

		$sorted = array();
		$i      = 0;
		foreach ( $order as $branch_id ) {
			if ( isset( $map[ $branch_id ] ) ) {
				$map[ $branch_id ]['order'] = $i;
				$sorted[]                   = $map[ $branch_id ];
				$i++;
			}
		}

		foreach ( $map as $branch_id => $branch ) {
			if ( ! in_array( $branch_id, $order, true ) ) {
				$branch['order'] = $i;
				$sorted[]        = $branch;
				$i++;
			}
		}

		$settings['branches'] = $sorted;
		MVweb_CB_Settings::save( $settings );

		wp_send_json_success();
	}

	/**
	 * Reset all settings to defaults.
	 *
	 * @since 1.0.0
	 */
	public function reset_settings(): void {
		if ( ! check_ajax_referer( 'mvweb_cb_reset_settings', 'nonce', false ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid security token.', 'mvweb-contact-bar' ) ) );
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mvweb-contact-bar' ) ) );
		}

		MVweb_CB_Settings::save( MVweb_CB_Settings::get_defaults() );

		wp_send_json_success( array( 'message' => __( 'Settings reset to defaults.', 'mvweb-contact-bar' ) ) );
	}

	/**
	 * Sanitize general tab data from POST.
	 *
	 * @since 1.0.0
	 * @param array $settings Current settings.
	 * @return array Updated settings.
	 */
	private function sanitize_general_tab( array $settings ): array {
		$settings['enabled'] = ! empty( $_POST['enabled'] ) && '1' === wp_unslash( $_POST['enabled'] );

		$allowed_themes = array( 'light', 'dark' );
		$theme          = sanitize_key( wp_unslash( $_POST['theme'] ?? 'light' ) );
		$settings['theme'] = in_array( $theme, $allowed_themes, true ) ? $theme : 'light';

		$allowed_sizes = array( 's', 'm', 'l' );
		$size          = sanitize_key( wp_unslash( $_POST['size'] ?? 'm' ) );
		$settings['size'] = in_array( $size, $allowed_sizes, true ) ? $size : 'm';

		$allowed_positions = array( 'center', 'left', 'right' );
		$position          = sanitize_key( wp_unslash( $_POST['position'] ?? 'center' ) );
		$settings['position'] = in_array( $position, $allowed_positions, true ) ? $position : 'center';

		$allowed_radii = array( 'capsule', 'rounded', 'rect' );
		$radius        = sanitize_key( wp_unslash( $_POST['border_radius'] ?? 'capsule' ) );
		$settings['border_radius'] = in_array( $radius, $allowed_radii, true ) ? $radius : 'capsule';

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- integer cast via absint().
		$settings['offset_bottom'] = min( 200, max( 0, absint( wp_unslash( $_POST['offset_bottom'] ?? 20 ) ) ) );
		$settings['offset_side']   = min( 200, max( 0, absint( wp_unslash( $_POST['offset_side'] ?? 0 ) ) ) );
		$settings['z_index']       = max( 1, absint( wp_unslash( $_POST['z_index'] ?? 9999 ) ) );

		$settings['show_labels'] = ! empty( $_POST['show_labels'] ) && '1' === wp_unslash( $_POST['show_labels'] );

		$settings['show_desktop'] = ! empty( $_POST['show_desktop'] );
		$settings['show_tablet']  = ! empty( $_POST['show_tablet'] );
		$settings['show_mobile']  = ! empty( $_POST['show_mobile'] );

		$settings['hide_on_scroll'] = ! empty( $_POST['hide_on_scroll'] ) && '1' === wp_unslash( $_POST['hide_on_scroll'] );

		$allowed_animations = array( 'slide_up', 'fade', 'none' );
		$animation          = sanitize_key( wp_unslash( $_POST['entrance_animation'] ?? 'slide_up' ) );
		$settings['entrance_animation'] = in_array( $animation, $allowed_animations, true ) ? $animation : 'slide_up';

		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- integer cast via absint().
		$settings['delay_seconds']   = min( 10, max( 0, absint( wp_unslash( $_POST['delay_seconds'] ?? 0 ) ) ) );
		$settings['delay_scroll_px'] = min( 5000, max( 0, absint( wp_unslash( $_POST['delay_scroll_px'] ?? 0 ) ) ) );

		$settings['allow_collapse'] = ! empty( $_POST['allow_collapse'] ) && '1' === wp_unslash( $_POST['allow_collapse'] );

		$allowed_loading = array( 'normal', 'deferred' );
		$loading         = sanitize_key( wp_unslash( $_POST['loading_mode'] ?? 'normal' ) );
		$settings['loading_mode'] = in_array( $loading, $allowed_loading, true ) ? $loading : 'normal';

		$modal_tpl = sanitize_key( wp_unslash( $_POST['modal_template'] ?? 'classic-glass' ) );
		$settings['modal_template'] = MVweb_CB_Templates::is_valid( $modal_tpl )
			? $modal_tpl : 'classic-glass';

		$color_mode = sanitize_key( wp_unslash( $_POST['modal_color_mode'] ?? 'light' ) );
		$settings['modal_color_mode'] = in_array( $color_mode, array( 'light', 'dark' ), true )
			? $color_mode : 'light';

		$allowed_modal_anims = array( 'slide_up', 'scale' );
		$modal_anim          = sanitize_key( wp_unslash( $_POST['modal_animation'] ?? 'slide_up' ) );
		$settings['modal_animation'] = in_array( $modal_anim, $allowed_modal_anims, true ) ? $modal_anim : 'slide_up';

		$allowed_handle_modes = array( 'service', 'neutral' );
		$handle_mode          = sanitize_key( wp_unslash( $_POST['handle_color_mode'] ?? 'service' ) );
		$settings['handle_color_mode'] = in_array( $handle_mode, $allowed_handle_modes, true ) ? $handle_mode : 'service';

		$settings['modal_description'] = sanitize_text_field( wp_unslash( $_POST['modal_description'] ?? '' ) );

		$settings['nofollow'] = ! empty( $_POST['nofollow'] ) && '1' === wp_unslash( $_POST['nofollow'] );

		$settings['ga_enabled']    = ! empty( $_POST['ga_enabled'] ) && '1' === wp_unslash( $_POST['ga_enabled'] );
		$settings['ym_enabled']    = ! empty( $_POST['ym_enabled'] ) && '1' === wp_unslash( $_POST['ym_enabled'] );
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- integer cast via absint().
		$settings['ym_counter_id'] = absint( wp_unslash( $_POST['ym_counter_id'] ?? 0 ) );

		$settings['custom_css'] = MVweb_CB_Settings::sanitize_css( wp_unslash( $_POST['custom_css'] ?? '' ) );

		return $settings;
	}

	/**
	 * Sanitize branches tab data from POST.
	 *
	 * Orphaned contacts cleanup: when a branch is removed, its contacts
	 * are also removed from all buttons (TZ §13).
	 *
	 * @since 1.0.0
	 * @param array $settings Current settings.
	 * @return array Updated settings with sanitized branches.
	 */
	private function sanitize_branches_tab( array $settings ): array {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per-field below.
		$raw_branches = isset( $_POST['branches'] ) ? (array) wp_unslash( $_POST['branches'] ) : array();

		$branches   = array();
		$order      = 0;
		$branch_ids = array();

		$allowed_branch_contact_types = array(
			'phone', 'email', 'telegram', 'whatsapp', 'viber', 'vk', 'ok', 'max',
			'messenger', 'instagram', 'x', 'linkedin', 'snapchat',
			'discord', 'youtube', 'rutube',
		);

		foreach ( $raw_branches as $raw ) {
			if ( ! is_array( $raw ) ) {
				continue;
			}

			$branch_contacts = array();
			$raw_bc = isset( $raw['contacts'] ) && is_array( $raw['contacts'] ) ? $raw['contacts'] : array();
			foreach ( $raw_bc as $bc ) {
				if ( ! is_array( $bc ) ) {
					continue;
				}
				$bc_type = sanitize_key( $bc['type'] ?? '' );
				if ( ! in_array( $bc_type, $allowed_branch_contact_types, true ) ) {
					continue;
				}
				$bc_url = MVweb_CB_Settings::normalize_contact_url( $bc['url'] ?? '', $bc_type );
				if ( empty( $bc_url ) ) {
					continue;
				}
				$branch_contacts[] = array(
					'type'         => $bc_type,
					'url'          => $bc_url,
					'display_text' => sanitize_text_field( $bc['display_text'] ?? '' ),
				);
			}

			$branch = array(
				'id'       => sanitize_key( $raw['id'] ?? ( 'branch_' . wp_generate_password( 8, false ) ) ),
				'name'     => sanitize_text_field( $raw['name'] ?? '' ),
				'address'  => sanitize_text_field( $raw['address'] ?? '' ),
				'hours'    => sanitize_text_field( $raw['hours'] ?? '' ),
				'active'   => isset( $raw['active'] ) ? ! empty( $raw['active'] ) : true,
				'order'    => $order,
				'contacts' => $branch_contacts,
			);

			if ( empty( $branch['name'] ) ) {
				continue;
			}

			$branches[]   = $branch;
			$branch_ids[] = $branch['id'];
			$order++;
		}

		$settings['branches'] = $branches;

		if ( ! empty( $settings['buttons'] ) ) {
			foreach ( $settings['buttons'] as &$button ) {
				if ( empty( $button['contacts'] ) || ! is_array( $button['contacts'] ) ) {
					continue;
				}
				$button['contacts'] = array_values(
					array_filter(
						$button['contacts'],
						fn( $contact ) => in_array( $contact['branch_id'] ?? '', $branch_ids, true )
					)
				);
			}
			unset( $button );
		}

		return $settings;
	}

	/**
	 * Sanitize buttons tab data from POST.
	 *
	 * @since 1.0.0
	 * @param array $settings Current settings.
	 * @return array Updated settings with sanitized buttons.
	 */
	private function sanitize_buttons_tab( array $settings ): array {
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per-field below.
		$raw_buttons = isset( $_POST['buttons'] ) ? (array) wp_unslash( $_POST['buttons'] ) : array();

		$allowed_types = array_merge( array_keys( MVweb_CB_Icons::get_all() ), array( 'custom' ) );
		$allowed_fa    = MVweb_CB_Icons::get_fa_list();

		$buttons = array();
		$order   = 0;

		foreach ( $raw_buttons as $raw ) {
			if ( ! is_array( $raw ) ) {
				continue;
			}

			$raw_type = sanitize_key( $raw['type'] ?? 'custom' );
			$type     = in_array( $raw_type, $allowed_types, true ) ? $raw_type : 'custom';

			$raw_fa  = sanitize_key( $raw['fa_icon'] ?? '' );
			$fa_icon = in_array( $raw_fa, $allowed_fa, true ) ? $raw_fa : '';

			$btn = array(
				'id'                => sanitize_key( $raw['id'] ?? ( 'btn_' . wp_generate_password( 8, false ) ) ),
				'type'              => $type,
				'label'             => sanitize_text_field( $raw['label'] ?? '' ),
				'color'             => sanitize_hex_color( $raw['color'] ?? '' ) ?: '',
				'custom_icon'       => esc_url_raw( $raw['custom_icon'] ?? '', array( 'https', 'http' ) ),
				'fa_icon'           => $fa_icon,
				'custom_url'        => MVweb_CB_Settings::normalize_contact_url( $raw['custom_url'] ?? '', $type ),
				'custom_url_target' => in_array( sanitize_key( $raw['custom_url_target'] ?? '_blank' ), array( '_blank', '_self' ), true ) ? sanitize_key( $raw['custom_url_target'] ) : '_blank',
				'modal_title'       => sanitize_text_field( $raw['modal_title'] ?? '' ),
				'modal_description' => sanitize_text_field( $raw['modal_description'] ?? '' ),
				'separator_after'   => ! empty( $raw['separator_after'] ),
				'order'             => $order,
				'active'            => isset( $raw['active'] ) ? ! empty( $raw['active'] ) : true,
				'contacts'          => array(),
			);

			$raw_contacts = isset( $raw['contacts'] ) && is_array( $raw['contacts'] ) ? $raw['contacts'] : array();
			foreach ( $raw_contacts as $rc ) {
				if ( ! is_array( $rc ) ) {
					continue;
				}
				$overridden = ! empty( $rc['overridden'] );
				$contact    = array(
					'branch_id'    => sanitize_key( $rc['branch_id'] ?? '' ),
					'overridden'   => $overridden,
					'url'          => MVweb_CB_Settings::normalize_contact_url( $rc['url'] ?? '', $type ),
					'display_text' => sanitize_text_field( $rc['display_text'] ?? '' ),
				);
				if ( ! empty( $contact['branch_id'] ) ) {
					$btn['contacts'][] = $contact;
				}
			}

			$buttons[] = $btn;
			$order++;
		}

		$settings['buttons'] = $buttons;
		return $settings;
	}
}
