<?php
/**
 * Admin settings page — sidebar + main layout (MVweb UI Kit v2).
 *
 * @package MVweb_Contact_Bar
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = MVweb_CB_Settings::get();

$current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

$tabs = array(
	'general'  => array(
		'label' => __( 'General', 'mvweb-contact-bar' ),
		'icon'  => 'gear',
	),
	'branches' => array(
		'label' => __( 'Branches', 'mvweb-contact-bar' ),
		'icon'  => 'pin',
	),
	'buttons'  => array(
		'label' => __( 'Buttons', 'mvweb-contact-bar' ),
		'icon'  => 'grid',
	),
	'help'     => array(
		'label' => __( 'Help', 'mvweb-contact-bar' ),
		'icon'  => 'help',
	),
);

$icons = array(
	'gear' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
	'pin'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
	'grid' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
	'help' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);
?>
<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">CB</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Contact Bar', 'mvweb-contact-bar' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_CB_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $tabs as $tab_id => $tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $tab_id ); ?>"
						class="mvweb-nav__link <?php echo $current_tab === $tab_id ? 'mvweb-nav__link--active' : ''; ?>"
						data-tab="<?php echo esc_attr( $tab_id ); ?>">
						<?php echo $icons[ $tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php echo esc_html( $tab['label'] ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<div id="general" class="mvweb-tab-content <?php echo 'general' === $current_tab ? 'active' : ''; ?>">
			<form id="mvweb-cb-general-form" method="post" action="#">
				<?php wp_nonce_field( 'mvweb_cb_save_settings', '_wpnonce', false ); ?>
				<?php require MVWEB_CB_PATH . 'admin/views/tab-general.php'; ?>

				<div class="mvweb-submit mvweb-submit--cb">
					<button type="submit" class="mvweb-btn mvweb-btn--primary">
						<?php esc_html_e( 'Save Settings', 'mvweb-contact-bar' ); ?>
					</button>
					<span class="mvweb-spinner"></span>
					<button type="button" class="mvweb-btn mvweb-btn--danger mvweb-cb-reset-all"
							id="mvweb-cb-reset-settings">
						<?php esc_html_e( 'Reset All Settings', 'mvweb-contact-bar' ); ?>
					</button>
				</div>
			</form>
		</div>

		<div id="branches" class="mvweb-tab-content <?php echo 'branches' === $current_tab ? 'active' : ''; ?>">
			<form id="mvweb-cb-branches-form" method="post" action="#">
				<?php wp_nonce_field( 'mvweb_cb_save_settings', '_wpnonce', false ); ?>
				<?php require MVWEB_CB_PATH . 'admin/views/tab-branches.php'; ?>

				<div class="mvweb-submit mvweb-submit--cb">
					<button type="submit" class="mvweb-btn mvweb-btn--primary">
						<?php esc_html_e( 'Save Branches', 'mvweb-contact-bar' ); ?>
					</button>
					<span class="mvweb-spinner"></span>
				</div>
			</form>
		</div>

		<div id="buttons" class="mvweb-tab-content <?php echo 'buttons' === $current_tab ? 'active' : ''; ?>">
			<form id="mvweb-cb-buttons-form" method="post" action="#">
				<?php wp_nonce_field( 'mvweb_cb_save_settings', '_wpnonce', false ); ?>
				<?php require MVWEB_CB_PATH . 'admin/views/tab-buttons.php'; ?>

				<div class="mvweb-submit mvweb-submit--cb">
					<button type="submit" class="mvweb-btn mvweb-btn--primary">
						<?php esc_html_e( 'Save Buttons', 'mvweb-contact-bar' ); ?>
					</button>
					<span class="mvweb-spinner"></span>
				</div>
			</form>
		</div>

		<div id="help" class="mvweb-tab-content <?php echo 'help' === $current_tab ? 'active' : ''; ?>">
			<?php
			$help_file = MVWEB_CB_PATH . 'admin/views/tab-help.php';
			if ( file_exists( $help_file ) ) {
				require $help_file;
			} else {
				echo '<p>' . esc_html__( 'Help documentation coming soon.', 'mvweb-contact-bar' ) . '</p>';
			}
			?>
		</div>

	</main>
</div>

<dialog id="mvweb-cb-reset-dialog" class="mvweb-dialog">
	<div class="mvweb-dialog__head">
		<h3><?php esc_html_e( 'Reset Settings', 'mvweb-contact-bar' ); ?></h3>
	</div>
	<div class="mvweb-dialog__body">
		<p><?php esc_html_e( 'Are you sure you want to reset all settings to defaults? This will remove all your buttons, branches, and custom configuration. This action cannot be undone.', 'mvweb-contact-bar' ); ?></p>
	</div>
	<div class="mvweb-dialog__foot">
		<button type="button" class="mvweb-btn" onclick="this.closest('dialog').close()">
			<?php esc_html_e( 'Cancel', 'mvweb-contact-bar' ); ?>
		</button>
		<button type="button" class="mvweb-btn mvweb-btn--danger" id="mvweb-cb-confirm-reset">
			<?php esc_html_e( 'Reset All Settings', 'mvweb-contact-bar' ); ?>
		</button>
	</div>
</dialog>
