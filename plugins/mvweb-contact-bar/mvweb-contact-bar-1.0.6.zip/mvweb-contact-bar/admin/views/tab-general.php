<?php
/**
 * General tab — all global settings: appearance, behaviour, modal, analytics, CSS.
 *
 * @package MVweb_Contact_Bar
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }
?>

<div class="mvweb-cb-general-tab">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Status', 'mvweb-contact-bar' ); ?></div>
		</div>
		<div class="mvweb-form-group">
			<label class="mvweb-toggle-label">
				<span class="mvweb-toggle<?php echo ! empty( $settings['enabled'] ) ? ' active' : ''; ?>"
					  data-toggle="enabled"></span>
				<?php esc_html_e( 'Enable Contact Bar', 'mvweb-contact-bar' ); ?>
			</label>
			<input type="hidden" name="enabled" value="<?php echo ! empty( $settings['enabled'] ) ? '1' : '0'; ?>">
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Show or hide the contact bar on the frontend.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Appearance', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label" for="mvweb-cb-theme">
				<?php esc_html_e( 'Theme', 'mvweb-contact-bar' ); ?>
			</label>
			<select class="mvweb-select" id="mvweb-cb-theme" name="theme">
				<option value="light" <?php selected( $settings['theme'] ?? 'light', 'light' ); ?>>
					<?php esc_html_e( 'Light Glass', 'mvweb-contact-bar' ); ?>
				</option>
				<option value="dark" <?php selected( $settings['theme'] ?? 'light', 'dark' ); ?>>
					<?php esc_html_e( 'Dark Glass', 'mvweb-contact-bar' ); ?>
				</option>
			</select>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label" for="mvweb-cb-size">
				<?php esc_html_e( 'Size', 'mvweb-contact-bar' ); ?>
			</label>
			<select class="mvweb-select" id="mvweb-cb-size" name="size">
				<option value="s" <?php selected( $settings['size'] ?? 'm', 's' ); ?>>
					<?php esc_html_e( 'Small (S)', 'mvweb-contact-bar' ); ?>
				</option>
				<option value="m" <?php selected( $settings['size'] ?? 'm', 'm' ); ?>>
					<?php esc_html_e( 'Medium (M)', 'mvweb-contact-bar' ); ?>
				</option>
				<option value="l" <?php selected( $settings['size'] ?? 'm', 'l' ); ?>>
					<?php esc_html_e( 'Large (L)', 'mvweb-contact-bar' ); ?>
				</option>
			</select>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label" for="mvweb-cb-position">
				<?php esc_html_e( 'Position', 'mvweb-contact-bar' ); ?>
			</label>
			<select class="mvweb-select" id="mvweb-cb-position" name="position">
				<option value="center" <?php selected( $settings['position'] ?? 'center', 'center' ); ?>>
					<?php esc_html_e( 'Center', 'mvweb-contact-bar' ); ?>
				</option>
				<option value="left" <?php selected( $settings['position'] ?? 'center', 'left' ); ?>>
					<?php esc_html_e( 'Left', 'mvweb-contact-bar' ); ?>
				</option>
				<option value="right" <?php selected( $settings['position'] ?? 'center', 'right' ); ?>>
					<?php esc_html_e( 'Right', 'mvweb-contact-bar' ); ?>
				</option>
			</select>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label" for="mvweb-cb-border-radius">
				<?php esc_html_e( 'Border Radius', 'mvweb-contact-bar' ); ?>
			</label>
			<select class="mvweb-select" id="mvweb-cb-border-radius" name="border_radius">
				<option value="capsule" <?php selected( $settings['border_radius'] ?? 'capsule', 'capsule' ); ?>>
					<?php esc_html_e( 'Capsule (100px)', 'mvweb-contact-bar' ); ?>
				</option>
				<option value="rounded" <?php selected( $settings['border_radius'] ?? 'capsule', 'rounded' ); ?>>
					<?php esc_html_e( 'Rounded (16px)', 'mvweb-contact-bar' ); ?>
				</option>
				<option value="rect" <?php selected( $settings['border_radius'] ?? 'capsule', 'rect' ); ?>>
					<?php esc_html_e( 'Rectangle (4px)', 'mvweb-contact-bar' ); ?>
				</option>
			</select>
		</div>

		<div class="mvweb-form-group mvweb-cb-offsets-row">
			<label class="mvweb-label">
				<?php esc_html_e( 'Offsets (px)', 'mvweb-contact-bar' ); ?>
			</label>
			<div class="mvweb-cb-inline-fields">
				<label>
					<?php esc_html_e( 'Bottom', 'mvweb-contact-bar' ); ?>
					<input type="number" class="mvweb-input" name="offset_bottom"
						   value="<?php echo esc_attr( $settings['offset_bottom'] ?? 20 ); ?>"
						   min="0" max="200" step="1">
				</label>
				<label>
					<?php esc_html_e( 'Side', 'mvweb-contact-bar' ); ?>
					<input type="number" class="mvweb-input" name="offset_side"
						   value="<?php echo esc_attr( $settings['offset_side'] ?? 0 ); ?>"
						   min="0" max="200" step="1">
				</label>
			</div>
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Distance from bottom and left/right edges of the screen.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label" for="mvweb-cb-z-index">
				<?php esc_html_e( 'z-index', 'mvweb-contact-bar' ); ?>
			</label>
			<input type="number" class="mvweb-input mvweb-cb-zindex-input" id="mvweb-cb-z-index" name="z_index"
				   value="<?php echo esc_attr( $settings['z_index'] ?? 9999 ); ?>"
				   min="1" max="2147483647" step="1">
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Stack order. Increase if the bar is hidden behind other elements.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-toggle-label">
				<span class="mvweb-toggle<?php echo ! empty( $settings['show_labels'] ) ? ' active' : ''; ?>"
					  data-toggle="show_labels"></span>
				<?php esc_html_e( 'Show button labels', 'mvweb-contact-bar' ); ?>
			</label>
			<input type="hidden" name="show_labels" value="<?php echo ! empty( $settings['show_labels'] ) ? '1' : '0'; ?>">
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Display text labels under button icons.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Devices', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-check">
				<input type="checkbox" name="show_desktop" value="1"
					   <?php checked( ! empty( $settings['show_desktop'] ) ); ?>>
				<?php esc_html_e( 'Show on desktop (> 1024px)', 'mvweb-contact-bar' ); ?>
			</label>
		</div>
		<div class="mvweb-form-group">
			<label class="mvweb-check">
				<input type="checkbox" name="show_tablet" value="1"
					   <?php checked( ! empty( $settings['show_tablet'] ) ); ?>>
				<?php esc_html_e( 'Show on tablet (768–1024px)', 'mvweb-contact-bar' ); ?>
			</label>
		</div>
		<div class="mvweb-form-group">
			<label class="mvweb-check">
				<input type="checkbox" name="show_mobile" value="1"
					   <?php checked( ! empty( $settings['show_mobile'] ) ); ?>>
				<?php esc_html_e( 'Show on mobile (< 768px)', 'mvweb-contact-bar' ); ?>
			</label>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Behaviour', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-toggle-label">
				<span class="mvweb-toggle<?php echo ! empty( $settings['hide_on_scroll'] ) ? ' active' : ''; ?>"
					  data-toggle="hide_on_scroll"></span>
				<?php esc_html_e( 'Hide on scroll down', 'mvweb-contact-bar' ); ?>
			</label>
			<input type="hidden" name="hide_on_scroll" value="<?php echo ! empty( $settings['hide_on_scroll'] ) ? '1' : '0'; ?>">
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Hide the bar when scrolling down, show when scrolling up.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label" for="mvweb-cb-entrance-animation">
				<?php esc_html_e( 'Entrance Animation', 'mvweb-contact-bar' ); ?>
			</label>
			<select class="mvweb-select" id="mvweb-cb-entrance-animation" name="entrance_animation">
				<option value="slide_up" <?php selected( $settings['entrance_animation'] ?? 'slide_up', 'slide_up' ); ?>>
					<?php esc_html_e( 'Slide Up', 'mvweb-contact-bar' ); ?>
				</option>
				<option value="fade" <?php selected( $settings['entrance_animation'] ?? 'slide_up', 'fade' ); ?>>
					<?php esc_html_e( 'Fade In', 'mvweb-contact-bar' ); ?>
				</option>
				<option value="none" <?php selected( $settings['entrance_animation'] ?? 'slide_up', 'none' ); ?>>
					<?php esc_html_e( 'None', 'mvweb-contact-bar' ); ?>
				</option>
			</select>
		</div>

		<div class="mvweb-form-group mvweb-cb-delay-row">
			<label class="mvweb-label">
				<?php esc_html_e( 'Appearance Delay', 'mvweb-contact-bar' ); ?>
			</label>
			<div class="mvweb-cb-inline-fields">
				<label>
					<?php esc_html_e( 'Seconds', 'mvweb-contact-bar' ); ?>
					<input type="number" class="mvweb-input" name="delay_seconds"
						   value="<?php echo esc_attr( $settings['delay_seconds'] ?? 0 ); ?>"
						   min="0" max="10" step="1">
				</label>
				<label>
					<?php esc_html_e( 'Scroll (px)', 'mvweb-contact-bar' ); ?>
					<input type="number" class="mvweb-input" name="delay_scroll_px"
						   value="<?php echo esc_attr( $settings['delay_scroll_px'] ?? 0 ); ?>"
						   min="0" max="5000" step="10">
				</label>
			</div>
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Wait before showing the bar. Set both to 0 for no delay.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-toggle-label">
				<span class="mvweb-toggle<?php echo ! empty( $settings['allow_collapse'] ) ? ' active' : ''; ?>"
					  data-toggle="allow_collapse"></span>
				<?php esc_html_e( 'Allow collapse/expand', 'mvweb-contact-bar' ); ?>
			</label>
			<input type="hidden" name="allow_collapse" value="<?php echo ! empty( $settings['allow_collapse'] ) ? '1' : '0'; ?>">
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Show a toggle button that allows visitors to collapse the bar. State is remembered via localStorage.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label" for="mvweb-cb-loading-mode">
				<?php esc_html_e( 'CSS/JS Loading Mode', 'mvweb-contact-bar' ); ?>
			</label>
			<select class="mvweb-select" id="mvweb-cb-loading-mode" name="loading_mode">
				<option value="normal" <?php selected( $settings['loading_mode'] ?? 'normal', 'normal' ); ?>>
					<?php esc_html_e( 'Normal', 'mvweb-contact-bar' ); ?>
				</option>
				<option value="deferred" <?php selected( $settings['loading_mode'] ?? 'normal', 'deferred' ); ?>>
					<?php esc_html_e( 'Deferred (JS defer + critical CSS)', 'mvweb-contact-bar' ); ?>
				</option>
			</select>
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Deferred mode adds defer to JS and inlines critical CSS to prevent FOUC.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Modal Window', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label">
				<?php esc_html_e( 'Modal Template', 'mvweb-contact-bar' ); ?>
			</label>
			<div class="mvweb-cb-tpl-picker" role="radiogroup"
				 aria-label="<?php esc_attr_e( 'Modal template', 'mvweb-contact-bar' ); ?>">
				<?php foreach ( MVweb_CB_Templates::get_all() as $slug => $tpl ) :
					$active = ( ( $settings['modal_template'] ?? 'classic-glass' ) === $slug );
				?>
				<label class="mvweb-cb-tpl-picker__item<?php echo $active ? ' mvweb-cb-tpl-picker__item--active' : ''; ?>"
					   data-tpl="<?php echo esc_attr( $slug ); ?>">
					<input type="radio" name="modal_template" value="<?php echo esc_attr( $slug ); ?>"
						   class="screen-reader-text" <?php checked( $active ); ?>>
					<span class="mvweb-cb-tpl-picker__thumb" aria-hidden="true"></span>
					<span class="mvweb-cb-tpl-picker__name">
						<?php echo esc_html( $tpl['label'] ); ?>
					</span>
				</label>
				<?php endforeach; ?>
			</div>
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Visual style of the modal window.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>

		<?php
		$active_tpl      = MVweb_CB_Templates::get( $settings['modal_template'] ?? 'classic-glass' );
		$show_color_mode = ! empty( $active_tpl['supports_color_mode'] );
		?>
		<div class="mvweb-form-group<?php echo $show_color_mode ? '' : ' mvweb-cb-color-mode-hidden'; ?>"
			 id="mvweb-cb-color-mode-row">
			<label class="mvweb-label" for="mvweb-cb-color-mode">
				<?php esc_html_e( 'Color Mode', 'mvweb-contact-bar' ); ?>
			</label>
			<select class="mvweb-select" id="mvweb-cb-color-mode" name="modal_color_mode">
				<option value="light" <?php selected( $settings['modal_color_mode'] ?? 'light', 'light' ); ?>>
					<?php esc_html_e( 'Light', 'mvweb-contact-bar' ); ?>
				</option>
				<option value="dark" <?php selected( $settings['modal_color_mode'] ?? 'light', 'dark' ); ?>>
					<?php esc_html_e( 'Dark', 'mvweb-contact-bar' ); ?>
				</option>
			</select>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label" for="mvweb-cb-modal-animation">
				<?php esc_html_e( 'Modal Animation', 'mvweb-contact-bar' ); ?>
			</label>
			<select class="mvweb-select" id="mvweb-cb-modal-animation" name="modal_animation">
				<option value="slide_up" <?php selected( $settings['modal_animation'] ?? 'slide_up', 'slide_up' ); ?>>
					<?php esc_html_e( 'Slide Up + Fade', 'mvweb-contact-bar' ); ?>
				</option>
				<option value="scale" <?php selected( $settings['modal_animation'] ?? 'slide_up', 'scale' ); ?>>
					<?php esc_html_e( 'Scale + Fade', 'mvweb-contact-bar' ); ?>
				</option>
			</select>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label" for="mvweb-cb-handle-color-mode">
				<?php esc_html_e( 'Contact Color', 'mvweb-contact-bar' ); ?>
			</label>
			<select class="mvweb-select" id="mvweb-cb-handle-color-mode" name="handle_color_mode">
				<option value="service" <?php selected( $settings['handle_color_mode'] ?? 'service', 'service' ); ?>>
					<?php esc_html_e( 'Service brand color', 'mvweb-contact-bar' ); ?>
				</option>
				<option value="neutral" <?php selected( $settings['handle_color_mode'] ?? 'service', 'neutral' ); ?>>
					<?php esc_html_e( 'Neutral', 'mvweb-contact-bar' ); ?>
				</option>
			</select>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-label" for="mvweb-cb-modal-description">
				<?php esc_html_e( 'Modal Description', 'mvweb-contact-bar' ); ?>
			</label>
			<input type="text" class="mvweb-input" id="mvweb-cb-modal-description"
				   name="modal_description"
				   value="<?php echo esc_attr( $settings['modal_description'] ?? '' ); ?>"
				   placeholder="<?php esc_attr_e( 'Choose the nearest branch', 'mvweb-contact-bar' ); ?>">
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Default subtitle text for all modal windows. Can be overridden per button in the Buttons tab.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Links', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-toggle-label">
				<span class="mvweb-toggle<?php echo ! empty( $settings['nofollow'] ) ? ' active' : ''; ?>"
					  data-toggle="nofollow"></span>
				<?php esc_html_e( 'Add rel="nofollow" to links', 'mvweb-contact-bar' ); ?>
			</label>
			<input type="hidden" name="nofollow" value="<?php echo ! empty( $settings['nofollow'] ) ? '1' : '0'; ?>">
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Adds nofollow attribute to all external links for SEO control.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Analytics', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-toggle-label">
				<span class="mvweb-toggle<?php echo ! empty( $settings['ga_enabled'] ) ? ' active' : ''; ?>"
					  data-toggle="ga_enabled"></span>
				<?php esc_html_e( 'Google Analytics (gtag)', 'mvweb-contact-bar' ); ?>
			</label>
			<input type="hidden" name="ga_enabled" value="<?php echo ! empty( $settings['ga_enabled'] ) ? '1' : '0'; ?>">
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Send events to Google Analytics. Requires gtag.js to be loaded on the site.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>

		<div class="mvweb-form-group">
			<label class="mvweb-toggle-label">
				<span class="mvweb-toggle<?php echo ! empty( $settings['ym_enabled'] ) ? ' active' : ''; ?>"
					  data-toggle="ym_enabled"></span>
				<?php esc_html_e( 'Yandex.Metrika', 'mvweb-contact-bar' ); ?>
			</label>
			<input type="hidden" name="ym_enabled" value="<?php echo ! empty( $settings['ym_enabled'] ) ? '1' : '0'; ?>">
		</div>

		<div class="mvweb-form-group mvweb-cb-ym-counter-group<?php echo empty( $settings['ym_enabled'] ) ? ' mvweb-hidden' : ''; ?>"
			 id="mvweb-cb-ym-counter-group">
			<label class="mvweb-label" for="mvweb-cb-ym-counter-id">
				<?php esc_html_e( 'Yandex.Metrika Counter ID', 'mvweb-contact-bar' ); ?>
			</label>
			<input type="text" class="mvweb-input mvweb-cb-ym-counter-input" id="mvweb-cb-ym-counter-id"
				   name="ym_counter_id"
				   value="<?php echo esc_attr( $settings['ym_counter_id'] ?? '' ); ?>"
				   placeholder="<?php esc_attr_e( 'e.g. 12345678', 'mvweb-contact-bar' ); ?>"
				   inputmode="numeric"
				   pattern="[0-9]*">
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Your Yandex.Metrika counter number. Found in the Metrika dashboard.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Custom CSS', 'mvweb-contact-bar' ); ?></div>
		</div>

		<div class="mvweb-form-group">
			<textarea class="mvweb-textarea mvweb-cb-custom-css" name="custom_css"
					  rows="6"
					  placeholder=".mvweb-cb { /* your styles */ }"><?php echo esc_textarea( $settings['custom_css'] ?? '' ); ?></textarea>
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Add custom CSS to override the default bar and modal styles.', 'mvweb-contact-bar' ); ?>
			</div>
		</div>
	</div>

</div>
