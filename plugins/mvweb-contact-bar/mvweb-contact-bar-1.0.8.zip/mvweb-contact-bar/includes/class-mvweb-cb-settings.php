<?php
/**
 * Plugin settings: defaults, get, save, sanitization.
 *
 * All settings stored in a single wp_option: mvweb_cb_settings (autoload=yes).
 *
 * @package MVweb_Contact_Bar
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class MVweb_CB_Settings {

	/**
	 * Option name in wp_options table.
	 */
	const OPTION_NAME = 'mvweb_cb_settings';

	/**
	 * Allowed URL schemes for esc_url().
	 *
	 * @var array
	 */
	const URL_SCHEMES = array( 'https', 'http', 'tel', 'mailto', 'viber', 'tg', 'sms' );

	/**
	 * Get plugin settings merged with defaults.
	 *
	 * @return array Full settings array with all keys guaranteed.
	 */
	public static function get(): array {
		$saved    = get_option( self::OPTION_NAME, array() );
		$defaults = self::get_defaults();

		$merged = self::deep_merge( $defaults, is_array( $saved ) ? $saved : array() );

		if ( empty( $merged['modal_template'] ) && ! empty( $merged['modal_theme'] ) ) {
			$legacy_map = array(
				'glass' => 'classic-glass',
				'white' => 'frosted-card',
				'dark'  => 'dark-neon',
			);
			$merged['modal_template']   = $legacy_map[ $merged['modal_theme'] ] ?? 'classic-glass';
			$merged['modal_color_mode'] = ( 'dark' === $merged['modal_theme'] ) ? 'dark' : 'light';
		}

		return $merged;
	}

	/**
	 * Get clean default settings (empty branches and buttons).
	 *
	 * Used for merging with saved data and for reset_settings().
	 *
	 * @return array Defaults schema matching TZ section 16.
	 */
	public static function get_defaults(): array {
		return array(
			'enabled'            => true,
			'theme'              => 'light',
			'size'               => 'm',
			'position'           => 'center',
			'offset_bottom'      => 20,
			'offset_side'        => 0,
			'border_radius'      => 'capsule',
			'z_index'            => 9999,
			'show_labels'        => true,
			'show_desktop'       => true,
			'show_tablet'        => true,
			'show_mobile'        => true,

			'hide_on_scroll'     => false,
			'delay_seconds'      => 0,
			'delay_scroll_px'    => 0,
			'entrance_animation' => 'slide_up',
			'allow_collapse'     => false,
			'loading_mode'       => 'normal',

			'modal_theme'        => 'white',
			'modal_template'     => 'classic-glass',
			'modal_color_mode'   => 'light',
			'modal_animation'    => 'slide_up',
			'modal_description'  => '',
			'handle_color_mode'  => 'service',

			'ga_enabled'         => false,
			'ym_enabled'         => false,
			'ym_counter_id'      => '',

			'nofollow'           => false,

			'custom_css'         => '',

			'branches'           => array(),
			'buttons'            => array(),
		);
	}

	/**
	 * Get sample data for first-time plugin activation.
	 *
	 * Demo branches and buttons allow frontend to render without admin UI setup.
	 *
	 * @since 1.0.0
	 * @return array Defaults merged with sample branches and buttons.
	 */
	public static function get_sample_data(): array {
		$defaults = self::get_defaults();

		$defaults['branches'] = array(
			array(
				'id'       => 'branch_demo1',
				'name'     => 'Main Office',
				'address'  => '123 Main Street, City',
				'hours'    => 'Mon-Fri 9:00-18:00',
				'active'   => true,
				'order'    => 0,
				'contacts' => array(
					array(
						'type'         => 'phone',
						'url'          => 'tel:+70001234567',
						'display_text' => '+7 (000) 123-45-67',
					),
					array(
						'type'         => 'telegram',
						'url'          => 'https://t.me/mvweb',
						'display_text' => '@mvweb',
					),
					array(
						'type'         => 'whatsapp',
						'url'          => 'https://wa.me/70001234567',
						'display_text' => '+7 (000) 123-45-67',
					),
				),
			),
		);

		$defaults['buttons'] = array(
			array(
				'id'                => 'btn_demo_phone',
				'type'              => 'phone',
				'label'             => '',
				'color'             => '',
				'custom_icon'       => '',
				'custom_url'        => '',
				'custom_url_target' => '_blank',
				'modal_title'       => '',
				'modal_description' => '',
				'separator_after'   => false,
				'order'             => 0,
				'active'            => true,
				'contacts'          => array(
					array(
						'branch_id'    => 'branch_demo1',
						'overridden'   => false,
						'url'          => '',
						'display_text' => '',
					),
				),
			),
			array(
				'id'                => 'btn_demo_tg',
				'type'              => 'telegram',
				'label'             => '',
				'color'             => '',
				'custom_icon'       => '',
				'custom_url'        => '',
				'custom_url_target' => '_blank',
				'modal_title'       => '',
				'modal_description' => '',
				'separator_after'   => true,
				'order'             => 1,
				'active'            => true,
				'contacts'          => array(
					array(
						'branch_id'    => 'branch_demo1',
						'overridden'   => false,
						'url'          => '',
						'display_text' => '',
					),
				),
			),
			array(
				'id'                => 'btn_demo_wa',
				'type'              => 'whatsapp',
				'label'             => '',
				'color'             => '',
				'custom_icon'       => '',
				'custom_url'        => '',
				'custom_url_target' => '_blank',
				'modal_title'       => '',
				'modal_description' => '',
				'separator_after'   => false,
				'order'             => 2,
				'active'            => true,
				'contacts'          => array(
					array(
						'branch_id'    => 'branch_demo1',
						'overridden'   => false,
						'url'          => '',
						'display_text' => '',
					),
				),
			),
		);

		return $defaults;
	}

	/**
	 * Save settings to wp_options.
	 *
	 * @param array $settings Sanitized settings array.
	 * @return bool True on success.
	 */
	public static function save( array $settings ): bool {
		return update_option( self::OPTION_NAME, $settings, false );
	}

	/**
	 * Delete all plugin settings.
	 *
	 * @return void
	 */
	public static function delete(): void {
		delete_option( self::OPTION_NAME );
		delete_option( 'mvweb_cb_version' );
	}

	/**
	 * Get active buttons only, sorted by order.
	 *
	 * Filters out: inactive buttons, buttons with no active contacts.
	 *
	 * @param array $settings Full settings array.
	 * @return array Filtered and sorted buttons.
	 */
	public static function get_active_buttons( array $settings ): array {
		$active_branch_ids = array_column(
			array_filter( $settings['branches'] ?? array(), fn( $b ) => ! empty( $b['active'] ) ),
			'id'
		);

		$buttons = array_filter(
			$settings['buttons'] ?? array(),
			function ( $btn ) use ( $active_branch_ids ) {
				if ( empty( $btn['active'] ) ) {
					return false;
				}
				if ( ! empty( $btn['custom_url'] ) ) {
					return true;
				}
				$active_contacts = array_filter(
					$btn['contacts'] ?? array(),
					fn( $c ) => in_array( $c['branch_id'] ?? '', $active_branch_ids, true )
				);
				return count( $active_contacts ) > 0;
			}
		);

		usort( $buttons, fn( $a, $b ) => ( $a['order'] ?? 0 ) <=> ( $b['order'] ?? 0 ) );
		return array_values( $buttons );
	}

	/**
	 * Get active contacts for a button, resolving override vs branch defaults.
	 *
	 * If contact has overridden=true and non-empty url → use contact's own url/display_text.
	 * Otherwise → look up branch.contacts by button type and use those values.
	 *
	 * @param array $btn      Button config.
	 * @param array $settings Full settings.
	 * @return array Filtered contacts with resolved url/display_text.
	 */
	public static function get_active_contacts( array $btn, array $settings ): array {
		if ( ! empty( $btn['custom_url'] ) ) {
			return array(
				array(
					'branch_id'    => '',
					'url'          => $btn['custom_url'],
					'display_text' => $btn['label'] ?? '',
				),
			);
		}

		$branches_map = array();
		foreach ( $settings['branches'] ?? array() as $branch ) {
			if ( ! empty( $branch['active'] ) ) {
				$branches_map[ $branch['id'] ] = $branch;
			}
		}

		$btn_type = $btn['type'] ?? 'custom';
		$result   = array();

		foreach ( $btn['contacts'] ?? array() as $contact ) {
			$branch_id = $contact['branch_id'] ?? '';
			if ( ! isset( $branches_map[ $branch_id ] ) ) {
				continue;
			}

			$branch = $branches_map[ $branch_id ];

			if ( ! empty( $contact['url'] ) ) {
				// Manual per-button value always wins over the branch default.
				$url          = $contact['url'];
				$display_text = $contact['display_text'] ?? '';
			} else {
				// Fall back to the branch default for this button type.
				$url          = '';
				$display_text = '';
				foreach ( $branch['contacts'] ?? array() as $bc ) {
					if ( ( $bc['type'] ?? '' ) === $btn_type ) {
						$url          = $bc['url'] ?? '';
						$display_text = $bc['display_text'] ?? '';
						break;
					}
				}
			}

			if ( empty( $url ) ) {
				continue;
			}

			$result[] = array(
				'branch_id'    => $branch_id,
				'url'          => $url,
				'display_text' => $display_text,
			);
		}

		return $result;
	}

	/**
	 * Sanitize custom CSS.
	 *
	 * @param string $css Raw CSS.
	 * @return string Sanitized CSS.
	 */
	public static function sanitize_css( string $css ): string {
		$css = str_replace( "\0", '', $css );
		$css = wp_strip_all_tags( $css );
		$css = str_ireplace( '</style', '', $css );
		$css = preg_replace( '/@import\s+[^;]*;?/i', '', $css );
		$css = preg_replace( '/expression\s*\(/i', '', $css );
		$css = preg_replace( '/javascript\s*:/i', '', $css );
		$css = preg_replace( '/behavior\s*:/i', '', $css );
		$css = preg_replace( '/url\s*\(\s*["\']?(?!data:image\/)[^)]*\)/i', 'url()', $css );

		return trim( $css );
	}

	/**
	 * Normalize a raw contact value into a full URL based on the button type.
	 *
	 * Backward compatible: if the value already contains a scheme/protocol
	 * (tel:, mailto:, viber:, http(s)://, t.me/, wa.me/ …), it is returned
	 * untouched and only sanitized. Only "bare" input (a phone number or a
	 * username) is expanded into the canonical URL for the given type.
	 *
	 * @param string $value Raw user input.
	 * @param string $type  Button/contact type (phone, whatsapp, telegram, …).
	 * @return string Normalized + sanitized URL.
	 */
	public static function normalize_contact_url( string $value, string $type ): string {
		$value = trim( $value );

		if ( '' === $value ) {
			return '';
		}

		$phone_types = array( 'phone', 'whatsapp', 'viber', 'sms' );

		// Repair legacy/broken phone values that were wrongly stored as
		// "https://+375 (29) ..." (esc_url_raw prepends https:// to a bare
		// number). For phone-like types, re-derive from digits.
		if ( in_array( $type, $phone_types, true )
			&& preg_match( '#^https?://[\s()+\-0-9]+$#i', rawurldecode( $value ) ) ) {
			$value = rawurldecode( $value );
		} elseif (
			// Already a full URL or known scheme — keep as is (preserves existing data).
			preg_match( '#^(https?:|tel:|mailto:|sms:|viber:|tg:|//)#i', $value )
			|| false !== strpos( $value, '://' )
			|| false !== strpos( $value, 't.me/' )
			|| false !== strpos( $value, 'wa.me/' ) ) {
			return self::sanitize_url( $value );
		}

		// Bare input — expand by type.
		$digits = preg_replace( '/[^0-9]/', '', $value );
		$handle = ltrim( $value, '@/' );

		switch ( $type ) {
			case 'phone':
				$url = $digits ? 'tel:+' . $digits : '';
				break;
			case 'whatsapp':
				$url = $digits ? 'https://wa.me/' . $digits : '';
				break;
			case 'viber':
				$url = $digits ? 'viber://chat?number=+' . $digits : '';
				break;
			case 'sms':
				$url = $digits ? 'sms:+' . $digits : '';
				break;
			case 'email':
				$url = is_email( $value ) ? 'mailto:' . sanitize_email( $value ) : '';
				break;
			case 'telegram':
				$url = $handle ? 'https://t.me/' . $handle : '';
				break;
			case 'vk':
				$url = $handle ? 'https://vk.com/' . $handle : '';
				break;
			case 'ok':
				$url = $handle ? 'https://ok.ru/' . $handle : '';
				break;
			case 'instagram':
				$url = $handle ? 'https://instagram.com/' . $handle : '';
				break;
			case 'x':
				$url = $handle ? 'https://x.com/' . $handle : '';
				break;
			case 'linkedin':
				$url = $handle ? 'https://linkedin.com/in/' . $handle : '';
				break;
			case 'snapchat':
				$url = $handle ? 'https://snapchat.com/add/' . $handle : '';
				break;
			case 'discord':
				$url = $handle ? 'https://discord.gg/' . $handle : '';
				break;
			case 'youtube':
				$url = $handle ? 'https://youtube.com/@' . $handle : '';
				break;
			case 'rutube':
				$url = $handle ? 'https://rutube.ru/channel/' . $handle : '';
				break;
			case 'messenger':
				$url = $handle ? 'https://m.me/' . $handle : '';
				break;
			case 'max':
				$url = $handle ? 'https://max.ru/' . $handle : '';
				break;
			default:
				// Custom / unknown — only treat as a URL if it looks like a domain.
				$url = ( false !== strpos( $value, '.' ) ) ? 'https://' . $handle : '';
				break;
		}

		return self::sanitize_url( $url );
	}

	/**
	 * Sanitize URL with allowed non-standard schemes.
	 *
	 * @param string $url Raw URL.
	 * @return string Sanitized URL.
	 */
	public static function sanitize_url( string $url ): string {
		return esc_url_raw( $url, self::URL_SCHEMES );
	}

	/**
	 * Deep merge defaults with saved values.
	 *
	 * For indexed arrays (buttons, branches) — saved overrides entirely.
	 *
	 * @param array $base     Default values.
	 * @param array $override Saved values.
	 * @return array Merged result.
	 */
	private static function deep_merge( array $base, array $override ): array {
		foreach ( $override as $key => $value ) {
			if ( in_array( $key, array( 'buttons', 'branches' ), true ) ) {
				$base[ $key ] = $value;
			} elseif ( is_array( $value ) && isset( $base[ $key ] ) && is_array( $base[ $key ] ) ) {
				$base[ $key ] = self::deep_merge( $base[ $key ], $value );
			} else {
				$base[ $key ] = $value;
			}
		}
		return $base;
	}
}
