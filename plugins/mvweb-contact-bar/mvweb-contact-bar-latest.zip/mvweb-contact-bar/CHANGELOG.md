# Changelog

All notable changes to MVweb Contact Bar will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.0] - 2026-02-23

### Added
- Float bar panel with Liquid Glass design (light/dark themes)
- 19 button presets with SVG icons (phone, email, messengers, social)
- Modal windows for branches with 12 visual templates
- Scroll hide/show with requestAnimationFrame throttle
- Entrance animations (slide up, fade, none)
- Collapse/expand with localStorage persistence
- Delay appearance (time + scroll distance)
- Device visibility control (desktop/tablet/mobile)
- Size presets (S/M/L) and border-radius presets
- Google Analytics + Yandex.Metrika event tracking
- Accessibility: ARIA labels, focus trap, keyboard navigation, prefers-reduced-motion
- Custom CSS field with XSS-safe sanitization
- URL allowlist for non-standard schemes (viber, skype, tg, etc.)
- Normal and deferred CSS/JS loading modes
- FontAwesome Solid icon picker (2000+ icons)
- Plugin infrastructure: entry point, settings, MVweb Hub integration
