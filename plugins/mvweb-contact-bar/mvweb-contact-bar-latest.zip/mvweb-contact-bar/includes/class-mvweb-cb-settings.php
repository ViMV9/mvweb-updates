<?php
/**
 * Plugin settings: defaults, get, save, sanitization.
 *
 * All settings stored in a single wp_option: mvweb_cb_settings (autoload=yes).
 *
 * @package MVweb_Contact_Bar
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class MVweb_CB_Settings {

	/**
	 * Option name in wp_options table.
	 */
	const OPTION_NAME = 'mvweb_cb_settings';

	/**
	 * Allowed URL schemes for esc_url().
	 *
	 * @var array
	 */
	const URL_SCHEMES = array( 'https', 'http', 'tel', 'mailto', 'viber', 'tg', 'sms' );

	/**
	 * Get plugin settings merged with defaults.
	 *
	 * @return array Full settings array with all keys guaranteed.
	 */
	public static function get(): array {
		$saved    = get_option( self::OPTION_NAME, array() );
		$defaults = self::get_defaults();

		$merged = self::deep_merge( $defaults, is_array( $saved ) ? $saved : array() );

		// Migrate legacy modal_theme values (< 1.1.0 → 1.1.0).
		if ( empty( $merged['modal_template'] ) && ! empty( $merged['modal_theme'] ) ) {
			$legacy_map = array(
				'glass' => 'classic-glass',
				'white' => 'frosted-card',
				'dark'  => 'dark-neon',
			);
			$merged['modal_template']   = $legacy_map[ $merged['modal_theme'] ] ?? 'classic-glass';
			$merged['modal_color_mode'] = ( 'dark' === $merged['modal_theme'] ) ? 'dark' : 'light';
		}

		return $merged;
	}

	/**
	 * Get clean default settings (empty branches and buttons).
	 *
	 * Used for merging with saved data and for reset_settings().
	 *
	 * @return array Defaults schema matching TZ section 16.
	 */
	public static function get_defaults(): array {
		return array(
			// === General ===
			'enabled'            => true,
			'theme'              => 'light',       // 'light' | 'dark'
			'size'               => 'm',           // 's' | 'm' | 'l'
			'position'           => 'center',      // 'center' | 'left' | 'right'
			'offset_bottom'      => 20,            // px
			'offset_side'        => 0,             // px
			'border_radius'      => 'capsule',     // 'capsule' | 'rounded' | 'rect'
			'z_index'            => 9999,
			'show_labels'        => true,
			'show_desktop'       => true,
			'show_tablet'        => true,
			'show_mobile'        => true,

			// === Behaviour ===
			'hide_on_scroll'     => false,
			'delay_seconds'      => 0,
			'delay_scroll_px'    => 0,
			'entrance_animation' => 'slide_up',    // 'slide_up' | 'fade' | 'none'
			'allow_collapse'     => false,
			'loading_mode'       => 'normal',      // 'normal' | 'deferred'

			// === Modal ===
			'modal_theme'        => 'white',         // DEPRECATED — kept for backward compat.
			'modal_template'     => 'classic-glass', // Slug from MVweb_CB_Templates registry.
			'modal_color_mode'   => 'light',         // 'light' | 'dark'
			'modal_animation'    => 'slide_up',    // 'slide_up' | 'scale'
			'modal_description'  => '',
			'handle_color_mode'  => 'service',     // 'service' | 'neutral'

			// === Analytics ===
			'ga_enabled'         => false,
			'ym_enabled'         => false,
			'ym_counter_id'      => '',

			// === Links ===
			'nofollow'           => false,

			// === Custom CSS ===
			'custom_css'         => '',

			// === Branches ===
			'branches'           => array(),

			// === Buttons ===
			'buttons'            => array(),
		);
	}

	/**
	 * Get sample data for first-time plugin activation.
	 *
	 * Demo branches and buttons allow frontend to render without admin UI setup.
	 *
	 * @since 1.0.0
	 * @return array Defaults merged with sample branches and buttons.
	 */
	public static function get_sample_data(): array {
		$defaults = self::get_defaults();

		$defaults['branches'] = array(
			array(
				'id'       => 'branch_demo1',
				'name'     => 'Main Office',
				'address'  => '123 Main Street, City',
				'hours'    => 'Mon-Fri 9:00-18:00',
				'active'   => true,
				'order'    => 0,
				'contacts' => array(
					array(
						'type'         => 'phone',
						'url'          => 'tel:+70001234567',
						'display_text' => '+7 (000) 123-45-67',
					),
					array(
						'type'         => 'telegram',
						'url'          => 'https://t.me/mvweb',
						'display_text' => '@mvweb',
					),
					array(
						'type'         => 'whatsapp',
						'url'          => 'https://wa.me/70001234567',
						'display_text' => '+7 (000) 123-45-67',
					),
				),
			),
			array(
				'id'       => 'branch_demo2',
				'name'     => 'Second Office',
				'address'  => '456 Second Ave, City',
				'hours'    => 'Mon-Sat 10:00-20:00',
				'active'   => true,
				'order'    => 1,
				'contacts' => array(
					array(
						'type'         => 'phone',
						'url'          => 'tel:+70007654321',
						'display_text' => '+7 (000) 765-43-21',
					),
				),
			),
		);

		$defaults['buttons'] = array(
			array(
				'id'                => 'btn_demo_phone',
				'type'              => 'phone',
				'label'             => '',
				'color'             => '',
				'custom_icon'       => '',
				'custom_url'        => '',
				'modal_title'       => '',
				'modal_description' => '',
				'separator_after'   => false,
				'order'             => 0,
				'active'            => true,
				'contacts'          => array(
					array(
						'branch_id'    => 'branch_demo1',
						'overridden'   => false,
						'url'          => '',
						'display_text' => '',
					),
					array(
						'branch_id'    => 'branch_demo2',
						'overridden'   => false,
						'url'          => '',
						'display_text' => '',
					),
				),
			),
			array(
				'id'                => 'btn_demo_tg',
				'type'              => 'telegram',
				'label'             => '',
				'color'             => '',
				'custom_icon'       => '',
				'custom_url'        => '',
				'modal_title'       => '',
				'modal_description' => '',
				'separator_after'   => true,
				'order'             => 1,
				'active'            => true,
				'contacts'          => array(
					array(
						'branch_id'    => 'branch_demo1',
						'overridden'   => false,
						'url'          => '',
						'display_text' => '',
					),
				),
			),
			array(
				'id'                => 'btn_demo_wa',
				'type'              => 'whatsapp',
				'label'             => '',
				'color'             => '',
				'custom_icon'       => '',
				'custom_url'        => '',
				'modal_title'       => '',
				'modal_description' => '',
				'separator_after'   => false,
				'order'             => 2,
				'active'            => true,
				'contacts'          => array(
					array(
						'branch_id'    => 'branch_demo1',
						'overridden'   => false,
						'url'          => '',
						'display_text' => '',
					),
				),
			),
		);

		return $defaults;
	}

	/**
	 * Save settings to wp_options.
	 *
	 * @param array $settings Sanitized settings array.
	 * @return bool True on success.
	 */
	public static function save( array $settings ): bool {
		return update_option( self::OPTION_NAME, $settings, 'yes' );
	}

	/**
	 * Delete all plugin settings.
	 *
	 * @return void
	 */
	public static function delete(): void {
		delete_option( self::OPTION_NAME );
		delete_option( 'mvweb_cb_version' );
	}

	/**
	 * Get active buttons only, sorted by order.
	 *
	 * Filters out: inactive buttons, buttons with no active contacts.
	 *
	 * @param array $settings Full settings array.
	 * @return array Filtered and sorted buttons.
	 */
	public static function get_active_buttons( array $settings ): array {
		$active_branch_ids = array_column(
			array_filter( $settings['branches'] ?? array(), fn( $b ) => ! empty( $b['active'] ) ),
			'id'
		);

		$buttons = array_filter(
			$settings['buttons'] ?? array(),
			function ( $btn ) use ( $active_branch_ids ) {
				if ( empty( $btn['active'] ) ) {
					return false;
				}
				// Custom button with direct URL.
				if ( ! empty( $btn['custom_url'] ) ) {
					return true;
				}
				// Preset: at least 1 contact in active branch.
				$active_contacts = array_filter(
					$btn['contacts'] ?? array(),
					fn( $c ) => in_array( $c['branch_id'] ?? '', $active_branch_ids, true )
				);
				return count( $active_contacts ) > 0;
			}
		);

		usort( $buttons, fn( $a, $b ) => ( $a['order'] ?? 0 ) <=> ( $b['order'] ?? 0 ) );
		return array_values( $buttons );
	}

	/**
	 * Get active contacts for a button, resolving override vs branch defaults.
	 *
	 * If contact has overridden=true and non-empty url → use contact's own url/display_text.
	 * Otherwise → look up branch.contacts by button type and use those values.
	 *
	 * @param array $btn      Button config.
	 * @param array $settings Full settings.
	 * @return array Filtered contacts with resolved url/display_text.
	 */
	public static function get_active_contacts( array $btn, array $settings ): array {
		if ( ! empty( $btn['custom_url'] ) ) {
			return array(
				array(
					'branch_id'    => '',
					'url'          => $btn['custom_url'],
					'display_text' => $btn['label'] ?? '',
				),
			);
		}

		// Build branch map for quick lookup.
		$branches_map = array();
		foreach ( $settings['branches'] ?? array() as $branch ) {
			if ( ! empty( $branch['active'] ) ) {
				$branches_map[ $branch['id'] ] = $branch;
			}
		}

		$btn_type = $btn['type'] ?? 'custom';
		$result   = array();

		foreach ( $btn['contacts'] ?? array() as $contact ) {
			$branch_id = $contact['branch_id'] ?? '';
			if ( ! isset( $branches_map[ $branch_id ] ) ) {
				continue;
			}

			$branch = $branches_map[ $branch_id ];

			// Resolve url and display_text.
			if ( ! empty( $contact['overridden'] ) && ! empty( $contact['url'] ) ) {
				// Use override values from the button's contact.
				$url          = $contact['url'];
				$display_text = $contact['display_text'] ?? '';
			} else {
				// Fall back to branch default contact for this button type.
				$url          = '';
				$display_text = '';
				foreach ( $branch['contacts'] ?? array() as $bc ) {
					if ( ( $bc['type'] ?? '' ) === $btn_type ) {
						$url          = $bc['url'] ?? '';
						$display_text = $bc['display_text'] ?? '';
						break;
					}
				}
				// If branch has no default for this type and contact has its own url — use it.
				if ( empty( $url ) && ! empty( $contact['url'] ) ) {
					$url          = $contact['url'];
					$display_text = $contact['display_text'] ?? '';
				}
			}

			if ( empty( $url ) ) {
				continue;
			}

			$result[] = array(
				'branch_id'    => $branch_id,
				'url'          => $url,
				'display_text' => $display_text,
			);
		}

		return $result;
	}

	/**
	 * Sanitize custom CSS.
	 *
	 * @param string $css Raw CSS.
	 * @return string Sanitized CSS.
	 */
	public static function sanitize_css( string $css ): string {
		$css = str_replace( "\0", '', $css );
		$css = wp_strip_all_tags( $css );

		// Prevent breaking out of <style> tag.
		$css = str_ireplace( '</style', '', $css );

		// Remove dangerous patterns.
		$css = preg_replace( '/@import\s+[^;]*;?/i', '', $css );
		$css = preg_replace( '/expression\s*\(/i', '', $css );
		$css = preg_replace( '/javascript\s*:/i', '', $css );
		$css = preg_replace( '/behavior\s*:/i', '', $css );
		// Allow only data:image/ URIs, block everything else.
		$css = preg_replace( '/url\s*\(\s*["\']?(?!data:image\/)[^)]*\)/i', 'url()', $css );

		return trim( $css );
	}

	/**
	 * Sanitize URL with allowed non-standard schemes.
	 *
	 * @param string $url Raw URL.
	 * @return string Sanitized URL.
	 */
	public static function sanitize_url( string $url ): string {
		return esc_url_raw( $url, self::URL_SCHEMES );
	}

	/**
	 * Deep merge defaults with saved values.
	 *
	 * For indexed arrays (buttons, branches) — saved overrides entirely.
	 *
	 * @param array $base     Default values.
	 * @param array $override Saved values.
	 * @return array Merged result.
	 */
	private static function deep_merge( array $base, array $override ): array {
		foreach ( $override as $key => $value ) {
			if ( in_array( $key, array( 'buttons', 'branches' ), true ) ) {
				$base[ $key ] = $value;
			} elseif ( is_array( $value ) && isset( $base[ $key ] ) && is_array( $base[ $key ] ) ) {
				$base[ $key ] = self::deep_merge( $base[ $key ], $value );
			} else {
				$base[ $key ] = $value;
			}
		}
		return $base;
	}
}
