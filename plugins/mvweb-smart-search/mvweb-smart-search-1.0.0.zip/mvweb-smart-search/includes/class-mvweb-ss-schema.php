<?php
/**
 * Database schema for the search index.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Owns the {prefix}mvweb_ss_index table and its meta option.
 *
 * @since 1.0.0
 */
class MVweb_SS_Schema {

	const DB_VERSION = '3';

	const META_OPTION = 'mvweb_ss_index_meta';

	/**
	 * Fully-qualified index table name.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'mvweb_ss_index';
	}

	/**
	 * Fully-qualified search log table name.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function log_table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'mvweb_ss_log';
	}

	/**
	 * Create or update the index table via dbDelta.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function create(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table           = self::table_name();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table (
	id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
	term varchar(50) NOT NULL DEFAULT '',
	object_id bigint(20) unsigned NOT NULL DEFAULT 0,
	object_type varchar(20) NOT NULL DEFAULT '',
	source varchar(20) NOT NULL DEFAULT '',
	count int(10) unsigned NOT NULL DEFAULT 1,
	lang varchar(5) NOT NULL DEFAULT '',
	PRIMARY KEY  (id),
	KEY term (term,object_type),
	KEY object_id (object_id)
) $charset_collate;";

		dbDelta( $sql );

		$log_table = self::log_table_name();

		$log_sql = "CREATE TABLE $log_table (
	query_hash char(32) NOT NULL,
	query varchar(191) NOT NULL DEFAULT '',
	hits bigint(20) unsigned NOT NULL DEFAULT 0,
	results int(10) unsigned NOT NULL DEFAULT 0,
	clicks bigint(20) unsigned NOT NULL DEFAULT 0,
	updated datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
	PRIMARY KEY  (query_hash),
	KEY results (results)
) $charset_collate;";

		dbDelta( $log_sql );

		$meta                   = self::get_meta();
		$meta['schema_version'] = self::DB_VERSION;
		self::update_meta( $meta );
	}

	/**
	 * Run schema upgrade when the stored version is behind.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function maybe_upgrade(): void {
		$meta = self::get_meta();

		if ( isset( $meta['schema_version'] ) && self::DB_VERSION === $meta['schema_version'] ) {
			return;
		}

		self::create();
	}

	/**
	 * Read the index meta option.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function get_meta(): array {
		$meta = get_option( self::META_OPTION, array() );
		return is_array( $meta ) ? $meta : array();
	}

	/**
	 * Persist the index meta option without autoload.
	 *
	 * @since 1.0.0
	 * @param array $meta Meta payload.
	 * @return void
	 */
	public static function update_meta( array $meta ): void {
		update_option( self::META_OPTION, $meta, false );
	}

	/**
	 * Drop the table and remove the meta option.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function drop(): void {
		global $wpdb;

		$table     = self::table_name();
		$log_table = self::log_table_name();
		$wpdb->query( "DROP TABLE IF EXISTS `$table`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$wpdb->query( "DROP TABLE IF EXISTS `$log_table`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery

		delete_option( self::META_OPTION );
	}
}
