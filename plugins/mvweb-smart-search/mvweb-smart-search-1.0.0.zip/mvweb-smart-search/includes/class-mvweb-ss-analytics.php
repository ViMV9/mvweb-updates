<?php
/**
 * Search analytics: dashboard widget, log tables and CSV export.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Surfaces the aggregated search log: a "no results" dashboard widget, the
 * Analytics settings tab and a nonce-guarded CSV export / clear action.
 *
 * @since 1.0.0
 */
class MVweb_SS_Analytics {

	const EXPORT_ACTION = 'mvweb_ss_export_log';

	const CLEAR_ACTION = 'mvweb_ss_clear_log';

	/**
	 * Register analytics hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'add_dashboard_widget' ) );
		add_action( 'admin_post_' . self::EXPORT_ACTION, array( __CLASS__, 'export_log' ) );
		add_action( 'admin_post_' . self::CLEAR_ACTION, array( __CLASS__, 'clear_log' ) );
	}

	/**
	 * Register the "no results" dashboard widget.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function add_dashboard_widget(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		wp_add_dashboard_widget(
			'mvweb_ss_no_results',
			__( 'Smart Search — queries with no results', 'mvweb-smart-search' ),
			array( __CLASS__, 'render_dashboard_widget' )
		);
	}

	/**
	 * Render the dashboard widget contents.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_dashboard_widget(): void {
		$rows = self::no_result_queries( 10 );

		if ( empty( $rows ) ) {
			echo '<p>' . esc_html__( 'No queries without results yet.', 'mvweb-smart-search' ) . '</p>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>';
		echo '<th>' . esc_html__( 'Query', 'mvweb-smart-search' ) . '</th>';
		echo '<th>' . esc_html__( 'Hits', 'mvweb-smart-search' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $rows as $row ) {
			echo '<tr><td>' . esc_html( $row['query'] ) . '</td><td>' . esc_html( (string) $row['hits'] ) . '</td></tr>';
		}

		echo '</tbody></table>';

		printf(
			'<p><a href="%s">%s</a></p>',
			esc_url( admin_url( 'admin.php?page=' . MVweb_SS_Admin::PAGE_SLUG . '&tab=analytics' ) ),
			esc_html__( 'All analytics', 'mvweb-smart-search' )
		);
	}

	/**
	 * Top queries that returned no results.
	 *
	 * @since 1.0.0
	 * @param int $limit Max rows.
	 * @return array<int,array{query:string,hits:int,updated:string}>
	 */
	public static function no_result_queries( int $limit ): array {
		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$limit = max( 1, min( 200, $limit ) );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT query, hits, updated FROM `$table` WHERE results = 0 ORDER BY hits DESC, updated DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$limit
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Most frequent queries overall.
	 *
	 * @since 1.0.0
	 * @param int $limit Max rows.
	 * @return array<int,array{query:string,hits:int,results:int,clicks:int,updated:string}>
	 */
	public static function top_queries( int $limit ): array {
		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$limit = max( 1, min( 200, $limit ) );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT query, hits, results, clicks, updated FROM `$table` ORDER BY hits DESC, updated DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$limit
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Most frequent queries that returned results — for the front-end
	 * "popular searches" suggestions shown on an empty focus.
	 *
	 * @since 1.0.0
	 * @param int $limit Max rows.
	 * @return string[]
	 */
	public static function popular_queries( int $limit ): array {
		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$limit = max( 1, min( 50, $limit ) );

		$rows = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT query FROM `$table` WHERE results > 0 ORDER BY hits DESC, updated DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$limit
			)
		);

		return is_array( $rows ) ? array_map( 'strval', $rows ) : array();
	}

	/**
	 * Stream the full log as a CSV download.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function export_log(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mvweb-smart-search' ) );
		}

		check_admin_referer( self::EXPORT_ACTION );

		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$rows  = $wpdb->get_results( "SELECT query, hits, results, clicks, updated FROM `$table` ORDER BY hits DESC, updated DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=mvweb-search-log-' . gmdate( 'Y-m-d' ) . '.csv' );

		$output = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		if ( false === $output ) {
			exit;
		}

		fputcsv( $output, array( 'query', 'hits', 'results', 'clicks', 'updated' ) );

		foreach ( (array) $rows as $row ) {
			fputcsv(
				$output,
				array(
					self::csv_safe( $row['query'] ),
					(int) $row['hits'],
					(int) $row['results'],
					(int) $row['clicks'],
					self::csv_safe( $row['updated'] ),
				)
			);
		}

		fclose( $output ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		exit;
	}

	/**
	 * Empty the search log.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function clear_log(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mvweb-smart-search' ) );
		}

		check_admin_referer( self::CLEAR_ACTION );

		global $wpdb;

		$table  = MVweb_SS_Schema::log_table_name();
		$result = $wpdb->query( "DELETE FROM `$table`" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => MVweb_SS_Admin::PAGE_SLUG,
					'tab'     => 'analytics',
					'cleared' => false === $result ? '0' : '1',
				),
				admin_url( 'admin.php' )
			)
		);

		exit;
	}

	/**
	 * Prefix formula-triggering values so spreadsheets treat them as text.
	 *
	 * @since 1.0.0
	 * @param mixed $value Cell value.
	 * @return string
	 */
	private static function csv_safe( $value ): string {
		$value = (string) $value;

		if ( '' !== $value && in_array( $value[0], array( '=', '+', '-', '@' ), true ) ) {
			return "'" . $value;
		}

		return $value;
	}
}
