<?php
/**
 * Matching taxonomy terms (e.g. product categories) for the dropdown.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Finds public taxonomy terms whose name matches the query (morphology-aware)
 * and returns them as a separate "Categories" group above the results.
 *
 * @since 1.0.0
 */
class MVweb_SS_Categories {

	const LIMIT = 5;

	const CACHE_TTL = 300;

	/**
	 * Categories matching the query, best-coverage tier only.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @param int    $limit Max categories.
	 * @return array<int,array{name:string,url:string,count:int,context:string}>
	 */
	public static function search( string $query, int $limit = self::LIMIT ): array {
		if ( ! MVweb_SS_Settings::get( 'show_categories', true ) ) {
			return array();
		}

		$tokens = array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( $query ) ) );
		$tokens = array_values( array_unique( $tokens ) );

		if ( empty( $tokens ) ) {
			return array();
		}

		$taxonomies = self::taxonomies();

		if ( empty( $taxonomies ) ) {
			return array();
		}

		$version   = (int) get_option( 'mvweb_ss_cache_version', 1 );
		$cache_key = 'mvweb_ss_cat_' . md5( $version . '|' . implode( ',', $tokens ) . '|' . implode( ',', $taxonomies ) . '|' . $limit );
		$cached    = get_transient( $cache_key );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomies,
				'hide_empty' => true,
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			set_transient( $cache_key, array(), self::CACHE_TTL );
			return array();
		}

		$wanted = array_flip( $tokens );
		$scored = array();
		$best   = 0;

		foreach ( $terms as $term ) {
			$name_tokens = array_unique( array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( $term->name ) ) ) );
			$matched     = 0;

			foreach ( $name_tokens as $name_token ) {
				if ( isset( $wanted[ $name_token ] ) ) {
					++$matched;
				}
			}

			if ( $matched > 0 ) {
				$scored[] = array(
					'term'    => $term,
					'matched' => $matched,
				);
				$best     = max( $best, $matched );
			}
		}

		$out = array();

		foreach ( $scored as $entry ) {
			if ( $entry['matched'] < $best || count( $out ) >= $limit ) {
				continue;
			}

			$term = $entry['term'];
			$link = get_term_link( $term );

			if ( is_wp_error( $link ) ) {
				continue;
			}

			$out[] = array(
				'name'    => html_entity_decode( wp_strip_all_tags( $term->name ), ENT_QUOTES ),
				'url'     => esc_url_raw( (string) $link ),
				'count'   => (int) $term->count,
				'context' => self::context_label( $term ),
			);
		}

		set_transient( $cache_key, $out, self::CACHE_TTL );

		return $out;
	}

	/**
	 * Taxonomies searched for categories.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	private static function taxonomies(): array {
		$default = class_exists( 'WooCommerce' ) ? array( 'product_cat' ) : array( 'category' );

		/**
		 * Filter the taxonomies shown as categories in the dropdown.
		 *
		 * @since 1.0.0
		 * @param string[] $taxonomies Taxonomy slugs.
		 */
		$taxonomies = (array) apply_filters( 'mvweb_ss_category_taxonomies', $default );

		return array_values(
			array_filter(
				$taxonomies,
				static function ( $taxonomy ) {
					return taxonomy_exists( $taxonomy ) && is_taxonomy_viewable( $taxonomy );
				}
			)
		);
	}

	/**
	 * Sub-label for a term: its parent name, or the taxonomy label.
	 *
	 * @since 1.0.0
	 * @param WP_Term $term Term.
	 * @return string
	 */
	private static function context_label( $term ): string {
		if ( $term->parent > 0 ) {
			$parent = get_term( $term->parent, $term->taxonomy );

			if ( $parent instanceof WP_Term ) {
				return html_entity_decode( wp_strip_all_tags( $parent->name ), ENT_QUOTES );
			}
		}

		$taxonomy = get_taxonomy( $term->taxonomy );

		return $taxonomy ? (string) $taxonomy->labels->singular_name : '';
	}
}
