<?php
/**
 * Search query log (foundation for analytics).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Records aggregated search queries: how often each phrase is searched and
 * how many results it returned last time (drives "no results" reporting).
 *
 * @since 1.0.0
 */
class MVweb_SS_Log {

	const MAX_LENGTH = 191;

	/**
	 * Record one search.
	 *
	 * @since 1.0.0
	 * @param string $query   Raw user query.
	 * @param int    $results Result count for this query.
	 * @return void
	 */
	public static function record( string $query, int $results ): void {
		$query = trim( wp_strip_all_tags( $query ) );
		$query = mb_substr( $query, 0, self::MAX_LENGTH, 'UTF-8' );

		if ( '' === $query ) {
			return;
		}

		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$hash  = md5( mb_strtolower( $query, 'UTF-8' ) );

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				'INSERT INTO %i (query_hash, query, hits, results, updated) VALUES (%s, %s, 1, %d, %s)
				ON DUPLICATE KEY UPDATE hits = hits + 1, results = VALUES(results), updated = VALUES(updated)',
				$table,
				$hash,
				$query,
				max( 0, $results ),
				current_time( 'mysql' )
			)
		);
	}

	/**
	 * Record one click on a result for a query.
	 *
	 * Updates the existing log row (the query was logged as an impression when
	 * its dropdown was shown), so no phantom rows are created.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @return void
	 */
	public static function record_click( string $query ): void {
		$query = trim( wp_strip_all_tags( $query ) );
		$query = mb_substr( $query, 0, self::MAX_LENGTH, 'UTF-8' );

		if ( '' === $query ) {
			return;
		}

		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$hash  = md5( mb_strtolower( $query, 'UTF-8' ) );

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				'UPDATE %i SET clicks = clicks + 1 WHERE query_hash = %s',
				$table,
				$hash
			)
		);
	}
}
