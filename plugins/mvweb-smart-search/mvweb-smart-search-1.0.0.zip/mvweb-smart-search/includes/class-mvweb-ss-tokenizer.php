<?php
/**
 * Tokenizer: text → normalized, stemmed terms with counts.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Turns a chunk of text into an array of index terms (term => count).
 *
 * @since 1.0.0
 */
class MVweb_SS_Tokenizer {

	const MAX_TERM_LENGTH = 50;

	const MIN_TERM_LENGTH = 2;

	/**
	 * Russian stop words.
	 *
	 * @var string[]
	 */
	private static $stop_ru = array(
		'и',
		'в',
		'во',
		'не',
		'что',
		'он',
		'на',
		'я',
		'с',
		'со',
		'как',
		'а',
		'то',
		'все',
		'она',
		'так',
		'его',
		'но',
		'да',
		'ты',
		'к',
		'у',
		'же',
		'вы',
		'за',
		'бы',
		'по',
		'ее',
		'мне',
		'было',
		'вот',
		'от',
		'меня',
		'еще',
		'нет',
		'о',
		'из',
		'ему',
		'для',
		'ни',
		'до',
		'или',
		'при',
		'об',
		'этот',
		'эта',
		'это',
		'эти',
		'над',
		'под',
		'без',
		'уже',
		'ли',
		'бы',
	);

	/**
	 * English stop words.
	 *
	 * @var string[]
	 */
	private static $stop_en = array(
		'the',
		'a',
		'an',
		'and',
		'or',
		'of',
		'to',
		'in',
		'is',
		'it',
		'for',
		'on',
		'with',
		'as',
		'at',
		'by',
		'be',
		'this',
		'that',
		'are',
		'was',
		'from',
		'but',
		'not',
		'you',
		'your',
		'we',
	);

	/**
	 * Tokenize text into stemmed terms with occurrence counts.
	 *
	 * @since 1.0.0
	 * @param string $text Source text.
	 * @param string $lang Force language ('ru'|'en'); empty = auto per token.
	 * @return array<string,int> term => count.
	 */
	public static function tokenize( string $text, string $lang = '' ): array {
		$text = mb_strtolower( $text, 'UTF-8' );
		$text = str_replace( 'ё', 'е', $text );

		$raw = preg_split( '/[^\p{L}\p{N}\-]+/u', $text, -1, PREG_SPLIT_NO_EMPTY );

		if ( ! is_array( $raw ) ) {
			return array();
		}

		$terms = array();

		foreach ( $raw as $token ) {
			$token = trim( $token, '-' );

			if ( '' === $token ) {
				continue;
			}

			if ( false !== strpos( $token, '-' ) ) {
				self::add_term( $terms, $token );

				foreach ( explode( '-', $token ) as $part ) {
					self::consume( $terms, $part, $lang );
				}

				continue;
			}

			self::consume( $terms, $token, $lang );
		}

		return $terms;
	}

	/**
	 * Normalize, filter and stem a single token, then add it.
	 *
	 * @since 1.0.0
	 * @param array<string,int> $terms Accumulator (by reference).
	 * @param string            $token Raw token.
	 * @param string            $lang  Forced language or ''.
	 * @return void
	 */
	private static function consume( array &$terms, string $token, string $lang ): void {
		if ( mb_strlen( $token, 'UTF-8' ) < self::MIN_TERM_LENGTH ) {
			return;
		}

		if ( self::is_stop_word( $token ) ) {
			return;
		}

		if ( preg_match( '/\d/', $token ) ) {
			self::add_term( $terms, $token );
			return;
		}

		self::add_term( $terms, MVweb_SS_Stemmer::stem( $token, $lang ) );
	}

	/**
	 * Add a term to the accumulator, incrementing its count.
	 *
	 * @since 1.0.0
	 * @param array<string,int> $terms Accumulator (by reference).
	 * @param string            $term  Final term.
	 * @return void
	 */
	private static function add_term( array &$terms, string $term ): void {
		$term = mb_substr( $term, 0, self::MAX_TERM_LENGTH, 'UTF-8' );

		if ( mb_strlen( $term, 'UTF-8' ) < self::MIN_TERM_LENGTH ) {
			return;
		}

		$terms[ $term ] = isset( $terms[ $term ] ) ? $terms[ $term ] + 1 : 1;
	}

	/**
	 * Custom stop words from settings, cached per request.
	 *
	 * @var string[]|null
	 */
	private static $extra_stop = null;

	/**
	 * Whether a token is a stop word in either supported language or the
	 * admin-defined custom list.
	 *
	 * @since 1.0.0
	 * @param string $token Token.
	 * @return bool
	 */
	private static function is_stop_word( string $token ): bool {
		if ( in_array( $token, self::$stop_ru, true ) || in_array( $token, self::$stop_en, true ) ) {
			return true;
		}

		if ( null === self::$extra_stop ) {
			self::$extra_stop = class_exists( 'MVweb_SS_Settings' ) ? MVweb_SS_Settings::custom_stopwords() : array();
		}

		return in_array( $token, self::$extra_stop, true );
	}
}
