<?php
/**
 * Background full reindex (batched, cursor-based, lock-guarded).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Rebuilds the whole index in ascending-ID batches without a search gap
 * (each object is upserted individually via the indexer).
 *
 * @since 1.0.0
 */
class MVweb_SS_Reindex {

	const HOOK = 'mvweb_ss_reindex_batch';

	const STATE_OPTION = 'mvweb_ss_reindex_state';

	const LOCK_TRANSIENT = 'mvweb_ss_reindex_lock';

	const BATCH = 50;

	const LOCK_TTL = 900;

	const NONCE = 'mvweb_ss_admin';

	/**
	 * Register the batch worker, AJAX endpoints and WP-CLI command.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_action( self::HOOK, array( __CLASS__, 'run_batch' ) );
		add_action( 'wp_ajax_mvweb_ss_reindex_start', array( __CLASS__, 'ajax_start' ) );
		add_action( 'wp_ajax_mvweb_ss_reindex_status', array( __CLASS__, 'ajax_status' ) );

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'mvweb-ss reindex', array( __CLASS__, 'cli_reindex' ) );
		}
	}

	/**
	 * Begin a full reindex.
	 *
	 * @since 1.0.0
	 * @param bool $async Schedule background batches (true) or just prime state.
	 * @return bool False if a reindex is already running.
	 */
	public static function start( bool $async = true ): bool {
		if ( self::is_running() ) {
			return false;
		}

		global $wpdb;

		set_transient( self::LOCK_TRANSIENT, time(), self::LOCK_TTL );

		$types = MVweb_SS_Indexer::get_indexed_post_types();
		$in    = implode( ',', array_fill( 0, count( $types ), '%s' ) );

		$max_id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(ID) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ($in)", $types ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders
		$total  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(ID) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ($in)", $types ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		update_option(
			self::STATE_OPTION,
			array(
				'max_id'    => $max_id,
				'cursor'    => 0,
				'total'     => $total,
				'processed' => 0,
			),
			false
		);

		if ( $async ) {
			self::schedule();
		}

		return true;
	}

	/**
	 * Process a single batch. Returns 'running', 'done' or 'idle'.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function process_batch(): string {
		global $wpdb;

		$state = get_option( self::STATE_OPTION );

		if ( ! is_array( $state ) ) {
			return 'idle';
		}

		$types = MVweb_SS_Indexer::get_indexed_post_types();
		$in    = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$args  = array_merge( $types, array( (int) $state['cursor'], (int) $state['max_id'], self::BATCH ) );

		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ($in) AND ID > %d AND ID <= %d ORDER BY ID ASC LIMIT %d", $args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( empty( $ids ) ) {
			self::finish( (int) $state['processed'] );
			return 'done';
		}

		foreach ( $ids as $id ) {
			MVweb_SS_Indexer::index_object( (int) $id );
			$state['cursor'] = (int) $id;
			++$state['processed'];
		}

		update_option( self::STATE_OPTION, $state, false );

		if ( (int) $state['cursor'] >= (int) $state['max_id'] ) {
			self::finish( (int) $state['processed'] );
			return 'done';
		}

		set_transient( self::LOCK_TRANSIENT, time(), self::LOCK_TTL );

		return 'running';
	}

	/**
	 * Async batch worker: process one batch, reschedule if more remain.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function run_batch(): void {
		if ( 'running' === self::process_batch() ) {
			self::schedule();
		}
	}

	/**
	 * Schedule the next batch via Action Scheduler or WP-Cron.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function schedule(): void {
		if ( function_exists( 'as_enqueue_async_action' ) && function_exists( 'as_next_scheduled_action' ) ) {
			if ( false === as_next_scheduled_action( self::HOOK ) ) {
				as_enqueue_async_action( self::HOOK, array(), 'mvweb-ss' );
			}
			return;
		}

		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_single_event( time() + 1, self::HOOK );
		}
	}

	/**
	 * Finalize a completed reindex.
	 *
	 * @since 1.0.0
	 * @param int $processed Objects processed.
	 * @return void
	 */
	private static function finish( int $processed ): void {
		$meta                 = MVweb_SS_Schema::get_meta();
		$meta['last_reindex'] = time();
		$meta['indexed']      = $processed;
		MVweb_SS_Schema::update_meta( $meta );

		delete_option( self::STATE_OPTION );
		delete_transient( self::LOCK_TRANSIENT );

		MVweb_SS_Rest::flush_cache();
	}

	/**
	 * Cancel a running reindex.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function cancel(): void {
		delete_option( self::STATE_OPTION );
		delete_transient( self::LOCK_TRANSIENT );
	}

	/**
	 * Whether a reindex is currently locked/running.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function is_running(): bool {
		return (bool) get_transient( self::LOCK_TRANSIENT );
	}

	/**
	 * Current progress snapshot for the admin UI.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function get_progress(): array {
		$state = get_option( self::STATE_OPTION );
		$meta  = MVweb_SS_Schema::get_meta();

		return array(
			'running'      => self::is_running(),
			'total'        => is_array( $state ) ? (int) $state['total'] : 0,
			'processed'    => is_array( $state ) ? (int) $state['processed'] : 0,
			'last_reindex' => isset( $meta['last_reindex'] ) ? (int) $meta['last_reindex'] : 0,
			'indexed'      => isset( $meta['indexed'] ) ? (int) $meta['indexed'] : 0,
		);
	}

	/**
	 * AJAX: start a reindex.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_start(): void {
		self::verify_admin_request();

		$started = self::start( true );

		wp_send_json_success(
			array_merge( self::get_progress(), array( 'started' => $started ) )
		);
	}

	/**
	 * AJAX: poll reindex progress.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_status(): void {
		self::verify_admin_request();

		wp_send_json_success( self::get_progress() );
	}

	/**
	 * Shared nonce + capability check for admin AJAX endpoints.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function verify_admin_request(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mvweb-smart-search' ) ), 403 );
		}

		check_ajax_referer( self::NONCE, 'nonce' );
	}

	/**
	 * WP-CLI: rebuild the whole index synchronously.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-ss reindex
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function cli_reindex(): void {
		self::cancel();

		if ( ! self::start( false ) ) {
			\WP_CLI::error( 'Could not start: a reindex is already running.' );
			return;
		}

		do {
			$status = self::process_batch();
		} while ( 'running' === $status );

		$progress = self::get_progress();
		\WP_CLI::success( sprintf( 'Reindex complete: %d objects.', (int) $progress['indexed'] ) );
	}
}
