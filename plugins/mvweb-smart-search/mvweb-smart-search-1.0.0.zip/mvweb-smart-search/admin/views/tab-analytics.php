<?php
/**
 * Analytics settings tab (search log: no-result and top queries + export).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$no_results = MVweb_SS_Analytics::no_result_queries( 20 );
$top        = MVweb_SS_Analytics::top_queries( 20 );

$export_url = wp_nonce_url( admin_url( 'admin-post.php?action=' . MVweb_SS_Analytics::EXPORT_ACTION ), MVweb_SS_Analytics::EXPORT_ACTION );
$clear_url  = wp_nonce_url( admin_url( 'admin-post.php?action=' . MVweb_SS_Analytics::CLEAR_ACTION ), MVweb_SS_Analytics::CLEAR_ACTION );

if ( isset( $_GET['cleared'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only notice flag.
	if ( '0' === sanitize_key( wp_unslash( $_GET['cleared'] ) ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<div class="mvweb-alert mvweb-alert--error"><?php esc_html_e( 'Could not clear the log.', 'mvweb-smart-search' ); ?></div>
	<?php else : ?>
		<div class="mvweb-alert mvweb-alert--success"><?php esc_html_e( 'Search log cleared.', 'mvweb-smart-search' ); ?></div>
	<?php endif; ?>
<?php endif; ?>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Queries with no results', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'What people search for but don\'t find — growth opportunities for content and products.', 'mvweb-smart-search' ); ?></p>

	<?php if ( empty( $no_results ) ) : ?>
		<p class="mvweb-empty"><?php esc_html_e( 'No queries without results yet.', 'mvweb-smart-search' ); ?></p>
	<?php else : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Query', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Times searched', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Last seen', 'mvweb-smart-search' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $no_results as $row ) : ?>
						<tr>
							<td><?php echo esc_html( $row['query'] ); ?></td>
							<td><?php echo esc_html( (string) $row['hits'] ); ?></td>
							<td><?php echo esc_html( $row['updated'] ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Top queries', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'The most popular search phrases, how many results they returned and how often a result was clicked (click-through rate).', 'mvweb-smart-search' ); ?></p>

	<?php if ( empty( $top ) ) : ?>
		<p class="mvweb-empty"><?php esc_html_e( 'The log is empty.', 'mvweb-smart-search' ); ?></p>
	<?php else : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Query', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Times searched', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Results', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Clicks', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'CTR', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Last seen', 'mvweb-smart-search' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach ( $top as $row ) :
						$mvweb_ss_hits   = (int) $row['hits'];
						$mvweb_ss_clicks = (int) $row['clicks'];
						$mvweb_ss_ctr    = $mvweb_ss_hits > 0 ? round( $mvweb_ss_clicks / $mvweb_ss_hits * 100 ) . '%' : '—';
						?>
						<tr>
							<td><?php echo esc_html( $row['query'] ); ?></td>
							<td><?php echo esc_html( (string) $mvweb_ss_hits ); ?></td>
							<td><?php echo esc_html( (string) $row['results'] ); ?></td>
							<td><?php echo esc_html( (string) $mvweb_ss_clicks ); ?></td>
							<td><?php echo esc_html( $mvweb_ss_ctr ); ?></td>
							<td><?php echo esc_html( $row['updated'] ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>

	<div class="mvweb-toolbar">
		<a class="mvweb-btn" href="<?php echo esc_url( $export_url ); ?>"><?php esc_html_e( 'Export to CSV', 'mvweb-smart-search' ); ?></a>
		<a class="mvweb-btn mvweb-btn--ghost mvweb-ss-confirm" data-confirm="<?php esc_attr_e( 'Clear the entire search log?', 'mvweb-smart-search' ); ?>" href="<?php echo esc_url( $clear_url ); ?>"><?php esc_html_e( 'Clear log', 'mvweb-smart-search' ); ?></a>
	</div>
</section>
