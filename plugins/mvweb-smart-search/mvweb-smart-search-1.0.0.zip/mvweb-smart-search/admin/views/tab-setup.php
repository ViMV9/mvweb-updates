<?php
/**
 * Getting started tab (status + how to place the search).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings    = MVweb_SS_Settings::all();
$progress    = MVweb_SS_Reindex::get_progress();
$indexed     = (int) $progress['indexed'];
$auto        = ! empty( $settings['auto_replace'] );
$fuzzy       = ! empty( $settings['fuzzy'] );
$search_mode = ( isset( $settings['mode'] ) && 'or' === $settings['mode'] ) ? 'OR' : 'AND';
?>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Status', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Current state of search on your site.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-metrics">
		<div class="mvweb-metric">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Items in index', 'mvweb-smart-search' ); ?></div>
			<div class="mvweb-metric__value"><?php echo esc_html( number_format_i18n( $indexed ) ); ?></div>
		</div>
		<div class="mvweb-metric">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Theme form replacement', 'mvweb-smart-search' ); ?></div>
			<div class="mvweb-metric__value"><?php echo $auto ? esc_html__( 'On', 'mvweb-smart-search' ) : esc_html__( 'Off', 'mvweb-smart-search' ); ?></div>
		</div>
		<div class="mvweb-metric">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Search logic', 'mvweb-smart-search' ); ?></div>
			<div class="mvweb-metric__value"><?php echo esc_html( $search_mode ); ?></div>
		</div>
		<div class="mvweb-metric">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Typo correction (fuzzy)', 'mvweb-smart-search' ); ?></div>
			<div class="mvweb-metric__value"><?php echo $fuzzy ? esc_html__( 'On', 'mvweb-smart-search' ) : esc_html__( 'Off', 'mvweb-smart-search' ); ?></div>
		</div>
	</div>

	<?php if ( 0 === $indexed ) : ?>
		<div class="mvweb-alert mvweb-alert--warning"><?php esc_html_e( 'The index is empty — open the "Index" tab and run "Reindex everything" so search can return results.', 'mvweb-smart-search' ); ?></div>
	<?php else : ?>
		<div class="mvweb-alert mvweb-alert--success"><?php esc_html_e( 'Search is active. Add a search bar to your site using one of the methods below.', 'mvweb-smart-search' ); ?></div>
	<?php endif; ?>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'How to add search to your site', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Any of these methods work — pick whichever fits your setup.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Theme search form', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<?php if ( $auto ) : ?>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Automatic replacement is on — your theme\'s search box already uses this plugin. Nothing else to do.', 'mvweb-smart-search' ); ?></p>
			<?php else : ?>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Automatic replacement is off. Turn it on in the "General" tab, or use one of the methods below.', 'mvweb-smart-search' ); ?></p>
			<?php endif; ?>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Shortcode', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<pre class="mvweb-codeblock"><code>[mvweb_ss]</code></pre>
			<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-ss-copy" data-copy="[mvweb_ss]" data-copied="<?php esc_attr_e( 'Copied!', 'mvweb-smart-search' ); ?>"><?php esc_html_e( 'Copy', 'mvweb-smart-search' ); ?></button>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Paste into any post, page, or a text widget.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Editor block', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'In the block editor, add the "MVweb Smart Search" block where you want the search bar.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'PHP in a template', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<pre class="mvweb-codeblock"><code>&lt;?php mvweb_ss_search_bar(); ?&gt;</code></pre>
			<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-ss-copy" data-copy="<?php echo esc_attr( '<?php mvweb_ss_search_bar(); ?>' ); ?>" data-copied="<?php esc_attr_e( 'Copied!', 'mvweb-smart-search' ); ?>"><?php esc_html_e( 'Copy', 'mvweb-smart-search' ); ?></button>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'For theme developers — place it anywhere in a template file.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>
