<?php
/**
 * Appearance settings tab (accent, placeholder, result fields, dropdown, texts).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = MVweb_SS_Settings::all();
$option   = MVweb_SS_Settings::OPTION;
?>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Search bar', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Look of the search field and the live dropdown.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-accent"><?php esc_html_e( 'Accent color', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="color" id="mvweb-ss-accent" class="mvweb-ss-color" name="<?php echo esc_attr( $option ); ?>[accent_color]" value="<?php echo esc_attr( $settings['accent_color'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Used for the button, focus ring, prices and links in the dropdown.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-placeholder"><?php esc_html_e( 'Placeholder text', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb-ss-placeholder" class="mvweb-input" name="<?php echo esc_attr( $option ); ?>[placeholder]" value="<?php echo esc_attr( $settings['placeholder'] ); ?>" placeholder="<?php esc_attr_e( 'Search the site…', 'mvweb-smart-search' ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Shown inside the empty search field. Leave blank for the default.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Bar style', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Size, shape, colors and submit button of the search bar.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-bar-size"><?php esc_html_e( 'Size', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-ss-bar-size" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[bar_size]">
				<option value="s" <?php selected( $settings['bar_size'], 's' ); ?>><?php esc_html_e( 'Small', 'mvweb-smart-search' ); ?></option>
				<option value="m" <?php selected( $settings['bar_size'], 'm' ); ?>><?php esc_html_e( 'Medium', 'mvweb-smart-search' ); ?></option>
				<option value="l" <?php selected( $settings['bar_size'], 'l' ); ?>><?php esc_html_e( 'Large', 'mvweb-smart-search' ); ?></option>
			</select>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-bar-radius"><?php esc_html_e( 'Corners', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-ss-bar-radius" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[bar_radius]">
				<option value="square" <?php selected( $settings['bar_radius'], 'square' ); ?>><?php esc_html_e( 'Square', 'mvweb-smart-search' ); ?></option>
				<option value="rounded" <?php selected( $settings['bar_radius'], 'rounded' ); ?>><?php esc_html_e( 'Rounded', 'mvweb-smart-search' ); ?></option>
				<option value="pill" <?php selected( $settings['bar_radius'], 'pill' ); ?>><?php esc_html_e( 'Pill', 'mvweb-smart-search' ); ?></option>
			</select>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-bar-maxwidth"><?php esc_html_e( 'Bar width', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-bar-maxwidth" class="mvweb-input" min="200" max="1200" step="10" name="<?php echo esc_attr( $option ); ?>[bar_max_width]" value="<?php echo esc_attr( (string) (int) $settings['bar_max_width'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Maximum width of the bar in pixels.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-submit-style"><?php esc_html_e( 'Submit button', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-ss-submit-style" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[submit_style]">
				<option value="icon" <?php selected( $settings['submit_style'], 'icon' ); ?>><?php esc_html_e( 'Magnifier icon', 'mvweb-smart-search' ); ?></option>
				<option value="text" <?php selected( $settings['submit_style'], 'text' ); ?>><?php esc_html_e( 'Text', 'mvweb-smart-search' ); ?></option>
				<option value="hidden" <?php selected( $settings['submit_style'], 'hidden' ); ?>><?php esc_html_e( 'Hidden', 'mvweb-smart-search' ); ?></option>
			</select>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-submit-text"><?php esc_html_e( 'Button text', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb-ss-submit-text" class="mvweb-input" name="<?php echo esc_attr( $option ); ?>[submit_text]" value="<?php echo esc_attr( $settings['submit_text'] ); ?>" placeholder="<?php esc_attr_e( 'Find', 'mvweb-smart-search' ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Shown when the submit button is set to “Text”.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-input-icon"><?php esc_html_e( 'Magnifier inside the field', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-input-icon" name="<?php echo esc_attr( $option ); ?>[input_icon]" value="1" <?php checked( ! empty( $settings['input_icon'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-border-color"><?php esc_html_e( 'Border color', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="color" id="mvweb-ss-border-color" class="mvweb-ss-color" name="<?php echo esc_attr( $option ); ?>[bar_border_color]" value="<?php echo esc_attr( '' !== $settings['bar_border_color'] ? $settings['bar_border_color'] : '#c9ced6' ); ?>">
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-bg-color"><?php esc_html_e( 'Field background', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="color" id="mvweb-ss-bg-color" class="mvweb-ss-color" name="<?php echo esc_attr( $option ); ?>[bar_bg_color]" value="<?php echo esc_attr( '' !== $settings['bar_bg_color'] ? $settings['bar_bg_color'] : '#ffffff' ); ?>">
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-text-color"><?php esc_html_e( 'Text color', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="color" id="mvweb-ss-text-color" class="mvweb-ss-color" name="<?php echo esc_attr( $option ); ?>[bar_text_color]" value="<?php echo esc_attr( '' !== $settings['bar_text_color'] ? $settings['bar_text_color'] : '#333333' ); ?>">
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Display mode', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Show the full bar or a magnifier icon that expands on click — set separately for desktop and mobile.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-display-desktop"><?php esc_html_e( 'Desktop', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-ss-display-desktop" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[display_desktop]">
				<option value="bar" <?php selected( $settings['display_desktop'], 'bar' ); ?>><?php esc_html_e( 'Search bar', 'mvweb-smart-search' ); ?></option>
				<option value="icon" <?php selected( $settings['display_desktop'], 'icon' ); ?>><?php esc_html_e( 'Icon (expands)', 'mvweb-smart-search' ); ?></option>
			</select>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-display-mobile"><?php esc_html_e( 'Mobile', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-ss-display-mobile" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[display_mobile]">
				<option value="bar" <?php selected( $settings['display_mobile'], 'bar' ); ?>><?php esc_html_e( 'Search bar', 'mvweb-smart-search' ); ?></option>
				<option value="icon" <?php selected( $settings['display_mobile'], 'icon' ); ?>><?php esc_html_e( 'Icon (expands)', 'mvweb-smart-search' ); ?></option>
			</select>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Placement', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Add the search bar to a navigation menu. For sidebars, use the “MVweb Smart Search” widget or the search block; anywhere on a page, the [mvweb_ss] shortcode.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-menu-location"><?php esc_html_e( 'Show in menu', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<?php $mvweb_ss_locations = get_registered_nav_menus(); ?>
			<select id="mvweb-ss-menu-location" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[menu_location]">
				<option value=""><?php esc_html_e( '— None —', 'mvweb-smart-search' ); ?></option>
				<?php foreach ( $mvweb_ss_locations as $mvweb_ss_loc => $mvweb_ss_label ) : ?>
					<option value="<?php echo esc_attr( $mvweb_ss_loc ); ?>" <?php selected( $settings['menu_location'], $mvweb_ss_loc ); ?>><?php echo esc_html( $mvweb_ss_label ); ?></option>
				<?php endforeach; ?>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Adds the search bar as an item in the chosen classic menu location. Block themes: add the Search block inside the Navigation block in the editor.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Category filter', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Show a category dropdown next to the field so visitors can narrow the search to one product (or content) category before searching.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-cat-selector"><?php esc_html_e( 'Category selector', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-cat-selector" name="<?php echo esc_attr( $option ); ?>[cat_selector]" value="1" <?php checked( ! empty( $settings['cat_selector'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-cat-taxonomy"><?php esc_html_e( 'Category taxonomy', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<?php $mvweb_ss_taxes = get_taxonomies( array( 'public' => true ), 'objects' ); ?>
			<select id="mvweb-ss-cat-taxonomy" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[cat_taxonomy]">
				<?php foreach ( $mvweb_ss_taxes as $mvweb_ss_tax ) : ?>
					<?php
					if ( ! $mvweb_ss_tax->hierarchical ) {
						continue; }
					?>
					<option value="<?php echo esc_attr( $mvweb_ss_tax->name ); ?>" <?php selected( $settings['cat_taxonomy'], $mvweb_ss_tax->name ); ?>><?php echo esc_html( $mvweb_ss_tax->labels->singular_name . ' (' . $mvweb_ss_tax->name . ')' ); ?></option>
				<?php endforeach; ?>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Which taxonomy the dropdown lists. Defaults to product categories when WooCommerce is active. The search is limited to the chosen term and its sub-terms.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Dropdown results', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'What each result shows in the live dropdown.', 'mvweb-smart-search' ); ?></p>

	<?php
	$toggles = array(
		'show_image'       => __( 'Thumbnail', 'mvweb-smart-search' ),
		'show_price'       => __( 'Price', 'mvweb-smart-search' ),
		'show_stock'       => __( 'Stock status', 'mvweb-smart-search' ),
		'show_excerpt'     => __( 'Short description', 'mvweb-smart-search' ),
		'show_categories'  => __( 'Matching categories', 'mvweb-smart-search' ),
		'filter_tabs'      => __( 'Filter tabs (All / Products / …)', 'mvweb-smart-search' ),
		'search_history'   => __( 'Recent searches', 'mvweb-smart-search' ),
		'popular_searches' => __( 'Popular searches', 'mvweb-smart-search' ),
	);
	foreach ( $toggles as $key => $label ) :
		?>
		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-ss-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox" id="mvweb-ss-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $option ); ?>[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( ! empty( $settings[ $key ] ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
			</div>
		</div>
	<?php endforeach; ?>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-popular-limit"><?php esc_html_e( 'Popular searches count', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-popular-limit" class="mvweb-input" min="1" max="20" step="1" name="<?php echo esc_attr( $option ); ?>[popular_limit]" value="<?php echo esc_attr( (string) (int) $settings['popular_limit'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'How many popular queries to suggest when the empty field is focused. Built from the most-searched phrases that returned results.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-layout"><?php esc_html_e( 'Results layout', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-ss-layout" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[layout]">
				<option value="list" <?php selected( $settings['layout'], 'list' ); ?>><?php esc_html_e( 'List (rows)', 'mvweb-smart-search' ); ?></option>
				<option value="grid" <?php selected( $settings['layout'], 'grid' ); ?>><?php esc_html_e( 'Grid (cards)', 'mvweb-smart-search' ); ?></option>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'How results are arranged in the dropdown.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-details-panel"><?php esc_html_e( 'Details panel', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-details-panel" name="<?php echo esc_attr( $option ); ?>[details_panel]" value="1" <?php checked( ! empty( $settings['details_panel'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Show an expanded preview of the highlighted result on the right (desktop).', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-panel-width"><?php esc_html_e( 'Dropdown width', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-panel-width" class="mvweb-input" min="320" max="1200" step="20" name="<?php echo esc_attr( $option ); ?>[panel_width]" value="<?php echo esc_attr( (string) (int) $settings['panel_width'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Width of the dropdown in pixels (desktop). It never exceeds the viewport.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Mobile and labels', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Mobile behavior and custom wording.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-mobile-overlay"><?php esc_html_e( 'Full-screen search on mobile', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-mobile-overlay" name="<?php echo esc_attr( $option ); ?>[mobile_overlay]" value="1" <?php checked( ! empty( $settings['mobile_overlay'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'On phones, the dropdown opens as a full-screen overlay. Off keeps it as an inline dropdown.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-text-empty"><?php esc_html_e( '"Nothing found" text', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb-ss-text-empty" class="mvweb-input" name="<?php echo esc_attr( $option ); ?>[text_no_results]" value="<?php echo esc_attr( $settings['text_no_results'] ); ?>" placeholder="<?php esc_attr_e( 'Nothing found', 'mvweb-smart-search' ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Shown when a query returns no results. Leave blank for the default.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-text-all"><?php esc_html_e( '"Show all results" text', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb-ss-text-all" class="mvweb-input" name="<?php echo esc_attr( $option ); ?>[text_see_all]" value="<?php echo esc_attr( $settings['text_see_all'] ); ?>" placeholder="<?php esc_attr_e( 'Show all results', 'mvweb-smart-search' ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Label of the link to the full results page. Leave blank for the default.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>
