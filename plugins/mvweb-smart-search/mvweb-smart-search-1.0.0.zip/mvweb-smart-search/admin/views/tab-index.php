<?php
/**
 * Index management tab (reindex + status).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$progress     = MVweb_SS_Reindex::get_progress();
$last_reindex = (int) $progress['last_reindex'];
$export_url   = wp_nonce_url( admin_url( 'admin-post.php?action=' . MVweb_SS_Admin::EXPORT_ACTION ), MVweb_SS_Admin::EXPORT_ACTION );
?>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Index', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'The index updates automatically as content changes. A full reindex is needed after changing coverage settings or on first install.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Items in index', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<strong><?php echo esc_html( (string) (int) $progress['indexed'] ); ?></strong>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Last reindex', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<span>
				<?php
				echo $last_reindex
					? esc_html( wp_date( 'Y-m-d H:i', $last_reindex ) )
					: esc_html__( 'never run', 'mvweb-smart-search' );
				?>
			</span>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Full reindex', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<button type="button" id="mvweb-ss-reindex" class="mvweb-btn mvweb-btn--primary"><?php esc_html_e( 'Reindex everything', 'mvweb-smart-search' ); ?></button>
			<p id="mvweb-ss-reindex-status" class="mvweb-form-row__desc" aria-live="polite"></p>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Export and import settings', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Move configuration between sites. Importing replaces the current settings.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Export', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<a class="mvweb-btn" href="<?php echo esc_url( $export_url ); ?>"><?php esc_html_e( 'Export to JSON', 'mvweb-smart-search' ); ?></a>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-import-data"><?php esc_html_e( 'Import', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="mvweb-ss-import-data" class="mvweb-textarea" rows="4" placeholder="<?php esc_attr_e( 'Paste the settings JSON…', 'mvweb-smart-search' ); ?>"></textarea>
			<button type="button" id="mvweb-ss-import" class="mvweb-btn"><?php esc_html_e( 'Import', 'mvweb-smart-search' ); ?></button>
			<p id="mvweb-ss-import-status" class="mvweb-form-row__desc" aria-live="polite"></p>
		</div>
	</div>
</section>
