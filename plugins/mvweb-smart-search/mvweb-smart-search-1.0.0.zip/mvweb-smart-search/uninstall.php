<?php
/**
 * Uninstall MVweb Smart Search
 *
 * Fired when the plugin is uninstalled.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

require_once __DIR__ . '/includes/class-mvweb-ss-schema.php';

// Plugin options (index meta + table are handled by MVweb_SS_Schema::drop()).
$options = array(
	'mvweb_ss_settings',
	'mvweb_ss_dict_packs',
	'mvweb_ss_reindex_state',
	'mvweb_ss_cache_version',
);

/**
 * Remove plugin data for a single site.
 *
 * @param array $options Option names to delete.
 * @return void
 */
function mvweb_ss_uninstall_site( array $options ) {
	foreach ( $options as $option ) {
		delete_option( $option );
	}

	delete_transient( 'mvweb_ss_dict_manifest' );
	delete_transient( 'mvweb_ss_reindex_lock' );

	MVweb_SS_Schema::drop();
}

mvweb_ss_uninstall_site( $options );

// For multisite, clean up all sites.
if ( is_multisite() ) {
	$sites = get_sites();
	foreach ( $sites as $site ) {
		switch_to_blog( $site->blog_id );
		mvweb_ss_uninstall_site( $options );
		restore_current_blog();
	}
}

// Clear any cached data.
wp_cache_flush();
