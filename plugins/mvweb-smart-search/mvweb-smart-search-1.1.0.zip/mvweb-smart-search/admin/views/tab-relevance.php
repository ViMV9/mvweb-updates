<?php
/**
 * Relevance settings tab (weights, synonyms, stop words, exclude, pinning).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = MVweb_SS_Settings::all();
$option   = MVweb_SS_Settings::OPTION;
$defaults = MVweb_SS_Query::default_weights();
$weights  = wp_parse_args( (array) $settings['weights'], $defaults );

// One-click seed coming from an Analytics-tab action link: pre-fill a starter
// line in the matching textarea. Read-only prefill (nothing is saved until the
// admin reviews it and submits the Settings form, which carries its own nonce).
// phpcs:disable WordPress.Security.NonceVerification.Recommended
$seed_q    = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
$seed_type = isset( $_GET['seed'] ) ? sanitize_key( wp_unslash( $_GET['seed'] ) ) : '';
// phpcs:enable WordPress.Security.NonceVerification.Recommended

$seed_syn = ( '' !== $seed_q && 'synonym' === $seed_type ) ? $seed_q . ", \n" : '';
$seed_red = ( '' !== $seed_q && 'redirect' === $seed_type ) ? $seed_q . ' => ' . "\n" : '';
$seed_pin = ( '' !== $seed_q && 'pin' === $seed_type ) ? $seed_q . ' => ' . "\n" : '';

$labels = array(
	'title'         => __( 'Title', 'mvweb-smart-search' ),
	'sku'           => __( 'SKU', 'mvweb-smart-search' ),
	'variation_sku' => __( 'Variation SKU', 'mvweb-smart-search' ),
	'gtin'          => __( 'GTIN / UPC / EAN', 'mvweb-smart-search' ),
	'attr'          => __( 'Attributes', 'mvweb-smart-search' ),
	'brand'         => __( 'Brand', 'mvweb-smart-search' ),
	'content'       => __( 'Content', 'mvweb-smart-search' ),
	'excerpt'       => __( 'Excerpt', 'mvweb-smart-search' ),
	'tax'           => __( 'Categories and tags', 'mvweb-smart-search' ),
	'cf'            => __( 'Custom fields', 'mvweb-smart-search' ),
);
?>

<?php if ( '' !== $seed_syn || '' !== $seed_red || '' !== $seed_pin ) : ?>
	<div class="mvweb-alert mvweb-alert--info">
		<?php
		printf(
			/* translators: %s: search query. */
			esc_html__( 'A starter line for "%s" was added below — complete it and click Save changes.', 'mvweb-smart-search' ),
			esc_html( $seed_q )
		);
		?>
	</div>
<?php endif; ?>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Field weights', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'How much a match in each field pushes a result up. Higher = more important; 0 = ignore this field.', 'mvweb-smart-search' ); ?></p>

	<?php foreach ( $defaults as $source => $default ) : ?>
		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-ss-weight-<?php echo esc_attr( $source ); ?>">
				<?php echo esc_html( isset( $labels[ $source ] ) ? $labels[ $source ] : $source ); ?>
			</label>
			<div class="mvweb-form-row__field mvweb-ss-slider">
				<input
					type="range"
					min="0"
					max="100"
					id="mvweb-ss-weight-<?php echo esc_attr( $source ); ?>"
					class="mvweb-ss-range"
					data-output="mvweb-ss-weight-<?php echo esc_attr( $source ); ?>-val"
					name="<?php echo esc_attr( $option ); ?>[weights][<?php echo esc_attr( $source ); ?>]"
					value="<?php echo esc_attr( (string) $weights[ $source ] ); ?>">
				<output id="mvweb-ss-weight-<?php echo esc_attr( $source ); ?>-val" class="mvweb-ss-range-val"><?php echo esc_html( (string) $weights[ $source ] ); ?></output>
			</div>
		</div>
	<?php endforeach; ?>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Learn from clicks', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Gently float the results shoppers actually click for a query. It only nudges results that already match and never reorders a fresh catalog, so leave it off until you have collected some search traffic.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-click-boost"><?php esc_html_e( 'Click-based boost', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-click-boost" name="<?php echo esc_attr( $option ); ?>[click_boost]" value="1" <?php checked( ! empty( $settings['click_boost'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Off by default. Turn on once the search log has enough clicks to learn from.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-click-boost-strength"><?php esc_html_e( 'Boost strength', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-ss-slider">
				<input
					type="range"
					min="0"
					max="100"
					id="mvweb-ss-click-boost-strength"
					class="mvweb-ss-range"
					data-output="mvweb-ss-click-boost-strength-val"
					name="<?php echo esc_attr( $option ); ?>[click_boost_strength]"
					value="<?php echo esc_attr( (string) $settings['click_boost_strength'] ); ?>">
				<output id="mvweb-ss-click-boost-strength-val" class="mvweb-ss-range-val"><?php echo esc_html( (string) $settings['click_boost_strength'] ); ?></output>
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( '0 = no effect, 100 = strongest. The boost is capped so a popular result can never jump above better-matching ones.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Ready-made dictionaries', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Curated synonym packs by MVweb. Install to improve matching for brands, electronics parts and adhesives — updating is one click. Your own synonyms below stay untouched.', 'mvweb-smart-search' ); ?></p>

	<?php $mvweb_ss_packs = MVweb_SS_Dictionaries::available(); ?>

	<?php if ( empty( $mvweb_ss_packs ) ) : ?>
		<div class="mvweb-alert mvweb-alert--info"><?php esc_html_e( 'The dictionary list is unavailable right now. Try again later.', 'mvweb-smart-search' ); ?></div>
	<?php else : ?>
		<div class="mvweb-ss-dicts">
			<?php foreach ( $mvweb_ss_packs as $mvweb_ss_pack ) : ?>
				<div class="mvweb-ss-dict">
					<div class="mvweb-ss-dict__info">
						<div class="mvweb-ss-dict__title">
							<strong><?php echo esc_html( $mvweb_ss_pack['name'] ); ?></strong>
							<?php if ( '' !== $mvweb_ss_pack['installed'] ) : ?>
								<span class="mvweb-badge"><?php echo esc_html( 'v' . $mvweb_ss_pack['installed'] ); ?></span>
							<?php endif; ?>
							<?php if ( $mvweb_ss_pack['update'] ) : ?>
								<span class="mvweb-badge mvweb-badge--warning"><?php esc_html_e( 'Update available', 'mvweb-smart-search' ); ?></span>
							<?php endif; ?>
						</div>
						<?php if ( '' !== $mvweb_ss_pack['description'] ) : ?>
							<span class="mvweb-block__sub"><?php echo esc_html( $mvweb_ss_pack['description'] ); ?></span>
						<?php endif; ?>
					</div>
					<div class="mvweb-ss-dict__actions">
						<button type="button" class="mvweb-btn mvweb-btn--primary mvweb-ss-dict-action" data-action="install" data-slug="<?php echo esc_attr( $mvweb_ss_pack['slug'] ); ?>">
							<?php echo '' === $mvweb_ss_pack['installed'] ? esc_html__( 'Install', 'mvweb-smart-search' ) : esc_html__( 'Update', 'mvweb-smart-search' ); ?>
						</button>
						<?php if ( '' !== $mvweb_ss_pack['installed'] ) : ?>
							<button type="button" class="mvweb-btn mvweb-ss-dict-action" data-action="remove" data-slug="<?php echo esc_attr( $mvweb_ss_pack['slug'] ); ?>">
								<?php esc_html_e( 'Remove', 'mvweb-smart-search' ); ?>
							</button>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<p id="mvweb-ss-dict-status" class="mvweb-block__sub" aria-live="polite"></p>
	<?php endif; ?>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Synonyms', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'A group of equivalent words on one line, comma-separated. Searching for any word in the group matches all of them. Multi-word entries work too. Example: phone, smartphone, mobile.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-synonyms"><?php esc_html_e( 'Synonym groups', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="mvweb-ss-synonyms" class="mvweb-textarea" rows="4" name="<?php echo esc_attr( $option ); ?>[synonyms]" placeholder="phone, smartphone, mobile&#10;jacket, windbreaker"><?php echo esc_textarea( $seed_syn . (string) $settings['synonyms'] ); ?></textarea>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Stop words', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Words ignored in the query and during indexing, one per line. Common prepositions and conjunctions are already included.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-stopwords"><?php esc_html_e( 'Stop words', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="mvweb-ss-stopwords" class="mvweb-textarea" rows="4" name="<?php echo esc_attr( $option ); ?>[stopwords]" placeholder="buy&#10;price"><?php echo esc_textarea( (string) $settings['stopwords'] ); ?></textarea>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Exclude from search', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'IDs of posts or products that should not appear in results. Comma-separated or one per line.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-exclude"><?php esc_html_e( 'Excluded IDs', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="mvweb-ss-exclude" class="mvweb-textarea" rows="3" name="<?php echo esc_attr( $option ); ?>[exclude_ids]" placeholder="128, 340"><?php echo esc_textarea( implode( ', ', (array) $settings['exclude_ids'] ) ); ?></textarea>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Pinned results', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Move specific items to the top of results for an exact query. Line format: query => ID, ID. Example: iphone => 512, 530.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-pins"><?php esc_html_e( 'Pinning rules', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="mvweb-ss-pins" class="mvweb-textarea" rows="4" name="<?php echo esc_attr( $option ); ?>[pins]" placeholder="iphone => 512, 530&#10;laptop => 741"><?php echo esc_textarea( $seed_pin . (string) $settings['pins'] ); ?></textarea>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Search redirects', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Send an exact query straight to a URL instead of the results page. Line format: query => URL. Example: contacts => /contact-us/.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-redirects"><?php esc_html_e( 'Redirect rules', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="mvweb-ss-redirects" class="mvweb-textarea" rows="4" name="<?php echo esc_attr( $option ); ?>[redirects]" placeholder="contacts =&gt; /contact-us/&#10;sale =&gt; /shop/?on_sale=1"><?php echo esc_textarea( $seed_red . (string) $settings['redirects'] ); ?></textarea>
		</div>
	</div>
</section>
