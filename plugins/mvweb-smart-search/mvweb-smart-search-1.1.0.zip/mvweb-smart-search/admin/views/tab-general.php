<?php
/**
 * General settings tab.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = MVweb_SS_Settings::all();
$option   = MVweb_SS_Settings::OPTION;
?>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Search', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'How the plugin processes search queries.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-strictness"><?php esc_html_e( 'Search strictness', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-ss-strictness" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[strictness]">
				<option value="strict" <?php selected( $settings['strictness'], 'strict' ); ?>><?php esc_html_e( 'Strict — all words must match', 'mvweb-smart-search' ); ?></option>
				<option value="balanced" <?php selected( $settings['strictness'], 'balanced' ); ?>><?php esc_html_e( 'Balanced — most words must match', 'mvweb-smart-search' ); ?></option>
				<option value="loose" <?php selected( $settings['strictness'], 'loose' ); ?>><?php esc_html_e( 'Loose — any word may match', 'mvweb-smart-search' ); ?></option>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'How many of the query words a result must contain. Balanced keeps results that share most of the words and drops loose one- or two-word coincidences; Strict requires every word; Loose accepts any single word.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Typo correction (fuzzy)', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" name="<?php echo esc_attr( $option ); ?>[fuzzy]" value="1" <?php checked( ! empty( $settings['fuzzy'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'When a query returns almost nothing, the plugin also matches close spellings (e.g. iphon → iphone).', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Automatically replace the theme\'s search form', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" name="<?php echo esc_attr( $option ); ?>[auto_replace]" value="1" <?php checked( ! empty( $settings['auto_replace'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Your theme\'s search box starts using this plugin — no code changes needed.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>

<?php if ( class_exists( 'WooCommerce' ) ) : ?>
<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'WooCommerce', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Search behavior for shop products.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-stock"><?php esc_html_e( 'Out-of-stock products', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-ss-stock" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[stock]">
				<option value="show" <?php selected( $settings['stock'], 'show' ); ?>><?php esc_html_e( 'Show as usual', 'mvweb-smart-search' ); ?></option>
				<option value="demote" <?php selected( $settings['stock'], 'demote' ); ?>><?php esc_html_e( 'Demote to the end of results', 'mvweb-smart-search' ); ?></option>
				<option value="hide" <?php selected( $settings['stock'], 'hide' ); ?>><?php esc_html_e( 'Hide from results', 'mvweb-smart-search' ); ?></option>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'What to do with products that are out of stock in search results.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Show "Add to cart" button in the dropdown', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" name="<?php echo esc_attr( $option ); ?>[add_to_cart]" value="1" <?php checked( ! empty( $settings['add_to_cart'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Adds a buy button to each product in the live suggestions dropdown.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>
<?php endif; ?>
