<?php
/**
 * REST endpoint powering the live search dropdown.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Read-only search endpoint with input limits, IP rate-limiting and a
 * versioned result cache.
 *
 * @since 1.0.0
 */
class MVweb_SS_Rest {

	const NAMESPACE = 'mvweb-ss/v1';

	const ROUTE = '/search';

	const CLICK_ROUTE = '/click';

	const MIN_QUERY = 1;

	const MAX_QUERY = 100;

	const DEFAULT_LIMIT = 10;

	const RATE_LIMIT = 30;

	const RATE_WINDOW = 10;

	const CACHE_TTL = 300;

	const VERSION_OPTION = 'mvweb_ss_cache_version';

	/**
	 * Register the REST route.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
	}

	/**
	 * Declare the search route.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_routes(): void {
		register_rest_route(
			self::NAMESPACE,
			self::ROUTE,
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'handle' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'q'     => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'limit' => array(
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					),
					'types' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'cat'   => array(
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			self::CLICK_ROUTE,
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'handle_click' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'q'  => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'id' => array(
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					),
				),
			)
		);
	}

	/**
	 * Handle a search request.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function handle( WP_REST_Request $request ) {
		$query  = sanitize_text_field( (string) $request->get_param( 'q' ) );
		$length = mb_strlen( $query, 'UTF-8' );

		if ( $length < self::MIN_QUERY || $length > self::MAX_QUERY ) {
			return new WP_REST_Response(
				array(
					'query'      => $query,
					'count'      => 0,
					'corrected'  => '',
					'categories' => array(),
					'results'    => array(),
				)
			);
		}

		if ( ! self::within_rate_limit() ) {
			return new WP_Error(
				'mvweb_ss_rate_limited',
				__( 'Too many requests.', 'mvweb-smart-search' ),
				array( 'status' => 429 )
			);
		}

		$limit = (int) $request->get_param( 'limit' );
		$limit = $limit > 0 ? $limit : self::DEFAULT_LIMIT;

		$types = MVweb_SS_Indexer::sanitize_types_csv( (string) $request->get_param( 'types' ) );
		$cat   = (int) $request->get_param( 'cat' );

		$cache_key = self::cache_key( $query, $limit, $types, $cat );
		$cached    = get_transient( $cache_key );

		if ( is_array( $cached ) ) {
			MVweb_SS_Log::record( $query, isset( $cached['count'] ) ? (int) $cached['count'] : 0 );
			return new WP_REST_Response( $cached );
		}

		// Fetch each content type separately so every group (e.g. products) is
		// represented, instead of one flat top-N where one type crowds out the rest.
		$scope = empty( $types ) ? MVweb_SS_Indexer::get_indexed_post_types() : $types;
		$per   = (int) MVweb_SS_Settings::get( 'per_group_limit', 0 );
		$per   = $per > 0 ? $per : $limit;

		// A chosen category scopes the search to its term (and descendants) and
		// to the post types that taxonomy applies to.
		$taxonomy = '';
		$term_ids = array();

		if ( $cat > 0 && MVweb_SS_Settings::get( 'cat_selector', false ) ) {
			$taxonomy = (string) MVweb_SS_Settings::get( 'cat_taxonomy', '' );
			$term_ids = MVweb_SS_Query::term_and_children( $cat, $taxonomy );

			if ( ! empty( $term_ids ) ) {
				$tax       = get_taxonomy( $taxonomy );
				$tax_types = $tax ? (array) $tax->object_type : array();
				$scope     = array_values( array_intersect( $scope, $tax_types ) );
			} else {
				$taxonomy = '';
			}
		}

		$rows       = array();
		$correction = '';

		foreach ( $scope as $type ) {
			$args = array(
				'limit'      => $per,
				'post_types' => array( $type ),
			);

			if ( ! empty( $term_ids ) ) {
				$args['term_ids'] = $term_ids;
				$args['taxonomy'] = $taxonomy;
			}

			$part = MVweb_SS_Query::search( $query, $args );

			if ( '' === $correction ) {
				$correction = MVweb_SS_Query::last_correction();
			}

			foreach ( $part as $row ) {
				$rows[] = $row;
			}
		}

		$results = array_map( array( __CLASS__, 'format_result' ), $rows );

		// Categories/brands match on the positive words only: a Boolean NOT term
		// ("xiaomi -аккумулятор") must not surface the very category it excludes.
		list( $cat_query ) = MVweb_SS_Query::split_negatives( $query );

		$payload = array(
			'query'      => $query,
			'count'      => count( $results ),
			'corrected'  => $correction,
			'categories' => empty( $term_ids ) ? MVweb_SS_Categories::search( $cat_query ) : array(),
			'brands'     => empty( $term_ids ) ? MVweb_SS_Categories::brands( $cat_query ) : array(),
			'results'    => $results,
		);

		set_transient( $cache_key, $payload, self::CACHE_TTL );

		MVweb_SS_Log::record( $query, count( $results ) );

		return new WP_REST_Response( $payload );
	}

	/**
	 * Record a click on a dropdown result (fired via navigator.sendBeacon).
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function handle_click( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::within_rate_limit( 'c' ) ) {
			return new WP_REST_Response( null, 429 );
		}

		$query  = sanitize_text_field( (string) $request->get_param( 'q' ) );
		$length = mb_strlen( $query, 'UTF-8' );

		if ( $length >= self::MIN_QUERY && $length <= self::MAX_QUERY ) {
			MVweb_SS_Log::record_click( $query );

			$id = (int) $request->get_param( 'id' );

			if ( $id > 0 ) {
				MVweb_SS_Log::record_result_click( $query, $id );
			}
		}

		return new WP_REST_Response( null, 204 );
	}

	/**
	 * Shape a single result for the dropdown (WooCommerce data via WC API).
	 *
	 * @since 1.0.0
	 * @param array $result { object_id, object_type, score }.
	 * @return array
	 */
	private static function format_result( array $result ): array {
		$id   = (int) $result['object_id'];
		$type = (string) $result['object_type'];

		$out = array(
			'id'        => $id,
			'type'      => $type,
			'title'     => html_entity_decode( wp_strip_all_tags( get_the_title( $id ) ), ENT_QUOTES ),
			'url'       => esc_url_raw( (string) get_permalink( $id ) ),
			'thumbnail' => esc_url_raw( (string) get_the_post_thumbnail_url( $id, 'thumbnail' ) ),
			'image'     => esc_url_raw( (string) get_the_post_thumbnail_url( $id, 'medium' ) ),
			'excerpt'   => self::excerpt( $id ),
		);

		if ( 'product' === $type && function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $id );

			if ( $product ) {
				$price_html      = preg_replace( '/<span class="screen-reader-text">.*?<\/span>/is', '', (string) $product->get_price_html() );
				$out['price']    = html_entity_decode( trim( wp_strip_all_tags( (string) $price_html ) ), ENT_QUOTES );
				$out['sku']      = $product->get_sku();
				$out['in_stock'] = $product->is_in_stock();

				if ( MVweb_SS_Settings::get( 'add_to_cart', true ) && $product->is_purchasable() && $product->is_in_stock() ) {
					$out['add'] = array(
						'url'   => esc_url_raw( (string) $product->add_to_cart_url() ),
						'label' => (string) $product->add_to_cart_text(),
						'ajax'  => (bool) $product->supports( 'ajax_add_to_cart' ),
					);
				}

				if ( '' === $out['thumbnail'] ) {
					$out['thumbnail'] = esc_url_raw( (string) wp_get_attachment_image_url( $product->get_image_id(), 'thumbnail' ) );
				}

				if ( '' === $out['image'] ) {
					$out['image'] = esc_url_raw( (string) wp_get_attachment_image_url( $product->get_image_id(), 'medium' ) );
				}
			}
		}

		return $out;
	}

	/**
	 * Short plain-text excerpt for the details panel.
	 *
	 * @since 1.0.0
	 * @param int $id Object ID.
	 * @return string
	 */
	private static function excerpt( int $id ): string {
		$post = get_post( $id );

		if ( ! $post instanceof WP_Post ) {
			return '';
		}

		$text = has_excerpt( $id ) ? $post->post_excerpt : $post->post_content;
		$text = wp_strip_all_tags( strip_shortcodes( (string) $text ) );

		return wp_trim_words( $text, 20, '…' );
	}

	/**
	 * Enforce a per-IP request rate limit.
	 *
	 * @since 1.0.0
	 * @param string $bucket Separate budget per endpoint ('q' search, 'c' click).
	 * @return bool True if the request may proceed.
	 */
	private static function within_rate_limit( string $bucket = 'q' ): bool {
		$ip = isset( $_SERVER['REMOTE_ADDR'] )
			? filter_var( wp_unslash( $_SERVER['REMOTE_ADDR'] ), FILTER_VALIDATE_IP )
			: false;

		if ( false === $ip ) {
			return true;
		}

		$key   = 'mvweb_ss_rl_' . $bucket . '_' . md5( (string) $ip );
		$count = (int) get_transient( $key );

		if ( $count >= self::RATE_LIMIT ) {
			return false;
		}

		set_transient( $key, $count + 1, self::RATE_WINDOW );

		return true;
	}

	/**
	 * Build a version-namespaced cache key.
	 *
	 * @since 1.0.0
	 * @param string   $query Query.
	 * @param int      $limit Limit.
	 * @param string[] $types Post-type scope.
	 * @param int      $cat   Selected category term ID (0 for none).
	 * @return string
	 */
	private static function cache_key( string $query, int $limit, array $types = array(), int $cat = 0 ): string {
		return 'mvweb_ss_q_' . self::cache_version() . '_' . md5( $query . '|' . $limit . '|' . implode( ',', $types ) . '|' . $cat );
	}

	/**
	 * Current cache version.
	 *
	 * @since 1.0.0
	 * @return int
	 */
	private static function cache_version(): int {
		return (int) get_option( self::VERSION_OPTION, 1 );
	}

	/**
	 * Invalidate all cached results by bumping the version.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function flush_cache(): void {
		update_option( self::VERSION_OPTION, self::cache_version() + 1, false );
	}
}
