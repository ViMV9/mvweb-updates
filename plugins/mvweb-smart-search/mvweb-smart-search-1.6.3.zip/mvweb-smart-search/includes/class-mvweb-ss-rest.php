<?php
/**
 * REST endpoint powering the live search dropdown.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Read-only search endpoint with input limits, IP rate-limiting and a
 * versioned result cache.
 *
 * @since 1.0.0
 */
class MVweb_SS_Rest {

	const NAMESPACE = 'mvweb-ss/v1';

	const ROUTE = '/search';

	const CLICK_ROUTE = '/click';

	const CATS_ROUTE = '/categories';

	const MIN_QUERY = 1;

	const MAX_QUERY = 100;

	const DEFAULT_LIMIT = 10;

	const MAX_LIMIT = 50;

	const RATE_LIMIT = 30;

	const RATE_WINDOW = 10;

	const CACHE_TTL = 300;

	const CATS_TTL = DAY_IN_SECONDS;

	const CATS_MAX_AGE = 300;

	const VERSION_OPTION = 'mvweb_ss_cache_version';

	/**
	 * Register the REST route.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );

		// The category list is served from the same versioned cache as the results,
		// so renaming, adding or removing a term has to bump that version — nothing
		// else in the plugin watches terms.
		add_action( 'created_term', array( __CLASS__, 'flush_cache' ) );
		add_action( 'edited_term', array( __CLASS__, 'flush_cache' ) );
		add_action( 'delete_term', array( __CLASS__, 'flush_cache' ) );
	}

	/**
	 * Declare the search route.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_routes(): void {
		register_rest_route(
			self::NAMESPACE,
			self::ROUTE,
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'handle' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'q'     => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'limit' => array(
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					),
					'types' => array(
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'cat'   => array(
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			self::CLICK_ROUTE,
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'handle_click' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'q'  => array(
						'required'          => true,
						'type'              => 'string',
						'sanitize_callback' => 'sanitize_text_field',
					),
					'id' => array(
						'type'              => 'integer',
						'sanitize_callback' => 'absint',
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			self::CATS_ROUTE,
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'handle_categories' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * The category tree behind the pre-search selector.
	 *
	 * The selector used to carry the whole tree inside every search form, on every
	 * page: on a catalogue of a few hundred categories that is tens of kilobytes of
	 * HTML and hundreds of DOM nodes per view, re-rendered per form. Here it costs
	 * one cacheable request per visitor instead.
	 *
	 * Deliberately not rate-limited: one request per page load, cached both sides,
	 * and the same public tree a shop's category menu already shows — while a whole
	 * office behind one NAT address would trip the shared budget and be left with an
	 * empty selector.
	 *
	 * @since 1.6.0
	 * @return WP_REST_Response
	 */
	public static function handle_categories(): WP_REST_Response {
		$response = new WP_REST_Response( array() );
		$response->header( 'Cache-Control', 'public, max-age=' . self::CATS_MAX_AGE );

		if ( ! MVweb_SS_Settings::get( 'cat_selector', false ) ) {
			return $response;
		}

		$taxonomy = (string) MVweb_SS_Settings::get( 'cat_taxonomy', '' );

		if ( ! taxonomy_exists( $taxonomy ) ) {
			return $response;
		}

		// Polylang and WPML hand each language its own tree, so the cache is keyed by
		// language the way the results cache is — otherwise the second locale is
		// served the first one's categories.
		$lang = class_exists( 'MVweb_SS_I18n' ) ? MVweb_SS_I18n::current_language() : '';
		$key  = 'mvweb_ss_cats_' . self::cache_version() . '_' . md5( $taxonomy . '|' . $lang );

		$cached = get_transient( $key );

		if ( is_array( $cached ) ) {
			$response->set_data( $cached );
			return $response;
		}

		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => true,
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return $response;
		}

		$items = self::category_items( $terms );

		set_transient( $key, $items, self::CATS_TTL );

		$response->set_data( $items );

		return $response;
	}

	/**
	 * Flatten a term list into the order and depth a hierarchical dropdown shows.
	 *
	 * @since 1.6.0
	 * @param WP_Term[] $terms Terms, already sorted by name.
	 * @return array[] { id, name, depth }
	 */
	private static function category_items( array $terms ): array {
		$children = array();

		foreach ( $terms as $term ) {
			$children[ (int) $term->parent ][] = $term;
		}

		$items = array();
		$seen  = array();

		self::collect_categories( $children, 0, 0, $items, $seen );

		// A term whose parent is missing from the list would never be reached by the
		// walk above and would silently disappear from the selector. Anything left
		// over joins the end at the top level instead.
		foreach ( $terms as $term ) {
			if ( ! isset( $seen[ (int) $term->term_id ] ) ) {
				$items[] = array(
					'id'    => (int) $term->term_id,
					'name'  => $term->name,
					'depth' => 0,
				);
			}
		}

		return $items;
	}

	/**
	 * Append one level of the tree and recurse into its children.
	 *
	 * @since 1.6.0
	 * @param array $children  Terms grouped by parent ID.
	 * @param int   $parent_id Parent term ID.
	 * @param int   $depth     Current depth.
	 * @param array $items     Collected items, by reference.
	 * @param array $seen      Emitted term IDs, by reference.
	 * @return void
	 */
	private static function collect_categories( array $children, int $parent_id, int $depth, array &$items, array &$seen ): void {
		if ( ! isset( $children[ $parent_id ] ) ) {
			return;
		}

		foreach ( $children[ $parent_id ] as $term ) {
			$id = (int) $term->term_id;

			if ( isset( $seen[ $id ] ) ) {
				continue;
			}

			$seen[ $id ] = true;

			$items[] = array(
				'id'    => $id,
				'name'  => $term->name,
				'depth' => $depth,
			);

			self::collect_categories( $children, $id, $depth + 1, $items, $seen );
		}
	}

	/**
	 * Handle a search request.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function handle( WP_REST_Request $request ) {
		$query  = sanitize_text_field( (string) $request->get_param( 'q' ) );
		$length = mb_strlen( $query, 'UTF-8' );

		if ( $length < self::MIN_QUERY || $length > self::MAX_QUERY ) {
			return new WP_REST_Response(
				array(
					'query'      => $query,
					'count'      => 0,
					'corrected'  => '',
					'categories' => array(),
					'results'    => array(),
				)
			);
		}

		if ( ! self::within_rate_limit() ) {
			return new WP_Error(
				'mvweb_ss_rate_limited',
				__( 'Too many requests.', 'mvweb-smart-search' ),
				array( 'status' => 429 )
			);
		}

		// This public, unauthenticated endpoint feeds the live dropdown, so the
		// per-request cost is capped here independently of the query engine's
		// MAX_LIMIT (raised to 1000 for the paginated results page): a dropdown
		// never needs more than a few dozen suggestions, and an arbitrary large
		// ?limit must not blow up the aggregation nor spawn uncacheable keys.
		$limit = (int) $request->get_param( 'limit' );
		$limit = $limit > 0 ? min( $limit, self::MAX_LIMIT ) : self::DEFAULT_LIMIT;

		$types = MVweb_SS_Indexer::sanitize_types_csv( (string) $request->get_param( 'types' ) );
		$cat   = (int) $request->get_param( 'cat' );

		$cache_key = self::cache_key( $query, $limit, $types, $cat );
		$cached    = get_transient( $cache_key );

		if ( is_array( $cached ) ) {
			MVweb_SS_Log::record( $query, isset( $cached['count'] ) ? (int) $cached['count'] : 0 );
			return new WP_REST_Response( $cached );
		}

		// Fetch each content type separately so every group (e.g. products) is
		// represented, instead of one flat top-N where one type crowds out the rest.
		$scope = empty( $types ) ? MVweb_SS_Indexer::get_indexed_post_types() : $types;
		$per   = (int) MVweb_SS_Settings::get( 'per_group_limit', 0 );
		$per   = $per > 0 ? $per : $limit;

		// A chosen category scopes the search to its term (and descendants) and
		// to the post types that taxonomy applies to.
		$taxonomy = '';
		$term_ids = array();

		if ( $cat > 0 && MVweb_SS_Settings::get( 'cat_selector', false ) ) {
			$taxonomy = (string) MVweb_SS_Settings::get( 'cat_taxonomy', '' );
			$term_ids = MVweb_SS_Query::term_and_children( $cat, $taxonomy );

			if ( ! empty( $term_ids ) ) {
				$tax       = get_taxonomy( $taxonomy );
				$tax_types = $tax ? (array) $tax->object_type : array();
				$scope     = array_values( array_intersect( $scope, $tax_types ) );
			} else {
				$taxonomy = '';
			}
		}

		$rows       = array();
		$correction = '';
		$rescue     = '';

		foreach ( $scope as $type ) {
			$args = array(
				'limit'      => $per,
				'post_types' => array( $type ),
				'prefix'     => true,
			);

			if ( ! empty( $term_ids ) ) {
				$args['term_ids'] = $term_ids;
				$args['taxonomy'] = $taxonomy;
			}

			$part = MVweb_SS_Query::search( $query, $args );

			// Capture the display correction and the rescue reason on independent
			// sentinels: a fuzzy rescue can set the reason while derive_correction()
			// returns '' (the corrected phrase equals the original), so a shared
			// '' === $correction gate would let a later type overwrite a real rescue
			// with an empty one and lose the tally.
			if ( '' === $correction ) {
				$correction = MVweb_SS_Query::last_correction();
			}

			if ( '' === $rescue ) {
				$rescue = MVweb_SS_Query::last_rescue();
			}

			foreach ( $part as $row ) {
				$rows[] = $row;
			}
		}

		$results = self::format_all( $rows );

		// Category/brand groups count only products that satisfy the same query
		// (strictness, synonyms and Boolean NOT included), so a "-word" never
		// surfaces the very category it excludes.
		// The two settings behind these groups are the dropdown's own (Coverage →
		// Matching categories / Matching brands), so they are read here rather than
		// inside the matcher, which the results-page filter panel shares.
		$want_cats   = empty( $term_ids ) && MVweb_SS_Settings::get( 'show_categories', true );
		$want_brands = empty( $term_ids ) && MVweb_SS_Settings::get( 'show_brands', true );

		$categories = $want_cats ? MVweb_SS_Categories::search( $query ) : array();
		$brands     = $want_brands ? MVweb_SS_Categories::brands( $query ) : array();

		// Real match count, logged before any fallback so zero-result analytics
		// (and future synonym mining) still see the query as unmatched.
		$match_count = count( $results );
		$fallback    = '';

		// Zero-result fallback (P1.7): nothing matched at all — offer best-sellers so
		// the shopper sees products instead of an empty dropdown. Products only.
		if ( 0 === $match_count && empty( $categories ) && empty( $brands )
			&& MVweb_SS_Settings::get( 'zero_fallback_bestsellers', true ) ) {
			$best = MVweb_SS_Query::bestsellers( $scope, $per );

			if ( ! empty( $best ) ) {
				$results  = self::format_all( $best );
				$fallback = 'bestsellers';
			}
		}

		$payload = array(
			'query'      => $query,
			'count'      => $match_count,
			'corrected'  => $correction,
			'categories' => $categories,
			'brands'     => $brands,
			'results'    => $results,
			'fallback'   => $fallback,
		);

		set_transient( $cache_key, $payload, self::CACHE_TTL );

		MVweb_SS_Log::record( $query, $match_count );

		// A non-empty correction that actually produced matches means the query
		// was rescued from a dead end — tally it as moat proof (F.4). On the miss
		// path only, so a repeated keystroke within the cache window counts once.
		if ( '' !== $rescue && $match_count > 0 ) {
			MVweb_SS_Log::record_rescue( $rescue );
		}

		return new WP_REST_Response( $payload );
	}

	/**
	 * Record a click on a dropdown result (fired via navigator.sendBeacon).
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request Request.
	 * @return WP_REST_Response
	 */
	public static function handle_click( WP_REST_Request $request ): WP_REST_Response {
		if ( ! self::within_rate_limit( 'c' ) ) {
			return new WP_REST_Response( null, 429 );
		}

		$query  = sanitize_text_field( (string) $request->get_param( 'q' ) );
		$length = mb_strlen( $query, 'UTF-8' );

		if ( $length >= self::MIN_QUERY && $length <= self::MAX_QUERY ) {
			MVweb_SS_Log::record_click( $query );

			$id = (int) $request->get_param( 'id' );

			if ( $id > 0 ) {
				MVweb_SS_Log::record_result_click( $query, $id );
			}
		}

		return new WP_REST_Response( null, 204 );
	}

	/**
	 * Shape a whole result set, priming the post cache once for all of it.
	 *
	 * Every row makes format_result() read a title, a permalink, a thumbnail and a
	 * product; without the prime each of those starts from an uncached post, which
	 * on a transient miss is two queries per row. One fetch up front covers all.
	 *
	 * @since 1.6.0
	 * @param array $rows Ranked rows.
	 * @return array
	 */
	private static function format_all( array $rows ): array {
		$ids = array();

		foreach ( $rows as $row ) {
			$ids[] = (int) $row['object_id'];
		}

		if ( ! empty( $ids ) ) {
			_prime_post_caches( $ids, false, true );
		}

		return array_map( array( __CLASS__, 'format_result' ), $rows );
	}

	/**
	 * Shape a single result for the dropdown (WooCommerce data via WC API).
	 *
	 * @since 1.0.0
	 * @param array $result { object_id, object_type, score }.
	 * @return array
	 */
	private static function format_result( array $result ): array {
		$id   = (int) $result['object_id'];
		$type = (string) $result['object_type'];

		$out = array(
			'id'        => $id,
			'type'      => $type,
			'title'     => html_entity_decode( wp_strip_all_tags( get_the_title( $id ) ), ENT_QUOTES ),
			'url'       => esc_url_raw( (string) get_permalink( $id ) ),
			'thumbnail' => esc_url_raw( (string) get_the_post_thumbnail_url( $id, 'thumbnail' ) ),
			'image'     => esc_url_raw( (string) get_the_post_thumbnail_url( $id, 'medium' ) ),
			'excerpt'   => self::excerpt( $id ),
		);

		if ( 'product' === $type && function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $id );

			if ( $product ) {
				$price_html      = preg_replace( '/<span class="screen-reader-text">.*?<\/span>/is', '', (string) $product->get_price_html() );
				$out['price']    = html_entity_decode( trim( wp_strip_all_tags( (string) $price_html ) ), ENT_QUOTES );
				$out['sku']      = $product->get_sku();
				$out['in_stock'] = $product->is_in_stock();

				if ( MVweb_SS_Settings::get( 'add_to_cart', true ) && $product->is_purchasable() && $product->is_in_stock() ) {
					$out['add'] = array(
						'url'   => esc_url_raw( (string) $product->add_to_cart_url() ),
						'label' => (string) $product->add_to_cart_text(),
						'ajax'  => (bool) $product->supports( 'ajax_add_to_cart' ),
					);
				}

				if ( '' === $out['thumbnail'] ) {
					$out['thumbnail'] = esc_url_raw( (string) wp_get_attachment_image_url( $product->get_image_id(), 'thumbnail' ) );
				}

				if ( '' === $out['image'] ) {
					$out['image'] = esc_url_raw( (string) wp_get_attachment_image_url( $product->get_image_id(), 'medium' ) );
				}
			}
		}

		return $out;
	}

	/**
	 * Short plain-text excerpt for the details panel.
	 *
	 * @since 1.0.0
	 * @param int $id Object ID.
	 * @return string
	 */
	private static function excerpt( int $id ): string {
		$post = get_post( $id );

		if ( ! $post instanceof WP_Post ) {
			return '';
		}

		$text = has_excerpt( $id ) ? $post->post_excerpt : $post->post_content;
		$text = wp_strip_all_tags( strip_shortcodes( (string) $text ) );

		return wp_trim_words( $text, 20, '…' );
	}

	/**
	 * Enforce a per-IP request rate limit.
	 *
	 * @since 1.0.0
	 * @param string $bucket Separate budget per endpoint ('q' search, 'c' click).
	 * @return bool True if the request may proceed.
	 */
	private static function within_rate_limit( string $bucket = 'q' ): bool {
		$ip = isset( $_SERVER['REMOTE_ADDR'] )
			? filter_var( wp_unslash( $_SERVER['REMOTE_ADDR'] ), FILTER_VALIDATE_IP )
			: false;

		if ( false === $ip ) {
			return true;
		}

		$key   = 'mvweb_ss_rl_' . $bucket . '_' . md5( (string) $ip );
		$count = (int) get_transient( $key );

		if ( $count >= self::RATE_LIMIT ) {
			return false;
		}

		set_transient( $key, $count + 1, self::RATE_WINDOW );

		return true;
	}

	/**
	 * Build a version-namespaced cache key.
	 *
	 * @since 1.0.0
	 * @param string   $query Query.
	 * @param int      $limit Limit.
	 * @param string[] $types Post-type scope.
	 * @param int      $cat   Selected category term ID (0 for none).
	 * @return string
	 */
	private static function cache_key( string $query, int $limit, array $types = array(), int $cat = 0 ): string {
		// The language filter (Polylang / WPML) runs on the results after the query,
		// so it must be part of the key: without it the second locale is served the
		// first one's suggestions for as long as the entry lives. Empty on a
		// single-language site, where the key is unchanged.
		$lang = class_exists( 'MVweb_SS_I18n' ) ? MVweb_SS_I18n::current_language() : '';

		return 'mvweb_ss_q_' . self::cache_version() . '_' . md5( $query . '|' . $limit . '|' . implode( ',', $types ) . '|' . $cat . '|' . $lang );
	}

	/**
	 * Current cache version.
	 *
	 * @since 1.0.0
	 * @return int
	 */
	private static function cache_version(): int {
		return (int) get_option( self::VERSION_OPTION, 1 );
	}

	/**
	 * Per-request guard so a bulk operation (import, batch reindex) touching many
	 * posts bumps the cache version once at shutdown, not once per save (R.4).
	 *
	 * @var bool
	 */
	private static $flush_pending = false;

	/**
	 * Invalidate all cached results by bumping the version — coalesced to one bump
	 * per request, so N saves in a bulk import cost one option write, not N. Query-
	 * keyed transients orphan and expire on their own short TTL.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function flush_cache(): void {
		if ( self::$flush_pending ) {
			return;
		}

		self::$flush_pending = true;

		add_action( 'shutdown', array( __CLASS__, 'commit_flush' ) );
	}

	/**
	 * Apply the deferred cache-version bump registered by flush_cache().
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function commit_flush(): void {
		if ( ! self::$flush_pending ) {
			return;
		}

		self::$flush_pending = false;
		update_option( self::VERSION_OPTION, self::cache_version() + 1, false );
	}
}
