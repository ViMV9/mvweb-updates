/**
 * Admin JavaScript for MVweb Smart Search.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		initTabs();
		initReindex();
		initConfirm();
		initProfiles();
		initSettingsIO();
		initDictionaries();
		initCopy();
		initRangeOutputs();
	} );

	/**
	 * Two-way binding between each range slider and its number input, so the
	 * value can be dragged or typed. The range carries the field name, so the
	 * typed number is mirrored onto it and submitted with the form.
	 */
	function initRangeOutputs() {
		var ranges = document.querySelectorAll( '.mvweb-ss-range[data-output]' );

		Array.prototype.forEach.call( ranges, function ( range ) {
			var number = document.getElementById( range.getAttribute( 'data-output' ) );

			if ( ! number ) {
				return;
			}

			var min = parseFloat( range.min );
			var max = parseFloat( range.max );

			range.addEventListener( 'input', function () {
				number.value = range.value;
			} );

			number.addEventListener( 'input', function () {
				var value = parseFloat( number.value );

				if ( isNaN( value ) ) {
					return;
				}

				if ( ! isNaN( min ) && value < min ) {
					value = min;
				}

				if ( ! isNaN( max ) && value > max ) {
					value = max;
				}

				range.value = value;
			} );

			// On blur, snap the field back to the clamped, submitted value (so a
			// typed 999 or an emptied field shows what the form will actually save).
			number.addEventListener( 'blur', function () {
				number.value = range.value;
			} );
		} );
	}

	/**
	 * Install / update / remove ready-made dictionary packs via AJAX.
	 */
	function initDictionaries() {
		if ( typeof window.mvwebSSAdmin === 'undefined' ) {
			return;
		}

		var cfg = window.mvwebSSAdmin;
		var status = document.getElementById( 'mvweb-ss-dict-status' );

		if ( ! status ) {
			return;
		}

		var refresh = document.getElementById( 'mvweb-ss-dict-refresh' );

		if ( refresh ) {
			refresh.addEventListener( 'click', function () {
				refresh.disabled = true;
				status.textContent = cfg.i18n.dictChecking;

				var refreshBody = new URLSearchParams();
				refreshBody.append( 'action', 'mvweb_ss_refresh_dictionaries' );
				refreshBody.append( 'nonce', cfg.dictNonce );

				fetch( cfg.ajaxUrl, {
					method: 'POST',
					credentials: 'same-origin',
					headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
					body: refreshBody.toString(),
				} ).then( function ( res ) {
					return res.json();
				} ).then( function ( res ) {
					if ( res && res.success ) {
						status.textContent = cfg.i18n.dictChecked;
						window.location.reload();
					} else {
						refresh.disabled = false;
						status.textContent = ( res && res.data && res.data.message ) ? res.data.message : cfg.i18n.dictError;
					}
				} ).catch( function () {
					refresh.disabled = false;
					status.textContent = cfg.i18n.dictError;
				} );
			} );
		}

		document.addEventListener( 'click', function ( event ) {
			var button = event.target.closest( '.mvweb-ss-dict-action' );

			if ( ! button ) {
				return;
			}

			var row = button.closest( '.mvweb-ss-dict' );
			var slug = row ? row.getAttribute( 'data-slug' ) : '';

			if ( ! slug ) {
				return;
			}

			var remove = 'remove' === button.getAttribute( 'data-action' );
			var buttons = row.querySelectorAll( '.mvweb-ss-dict-action' );

			buttons.forEach( function ( item ) {
				item.disabled = true;
			} );
			status.textContent = remove ? cfg.i18n.dictRemoving : cfg.i18n.dictInstalling;

			var body = new URLSearchParams();
			body.append( 'action', remove ? 'mvweb_ss_remove_dictionary' : 'mvweb_ss_install_dictionary' );
			body.append( 'nonce', cfg.dictNonce );
			body.append( 'slug', slug );

			fetch( cfg.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body.toString(),
			} ).then( function ( res ) {
				return res.json();
			} ).then( function ( res ) {
				if ( res && res.success ) {
					renderDictRow( row, remove ? '' : ( res.data && res.data.version ? String( res.data.version ) : '' ) );
					status.textContent = remove ? cfg.i18n.dictRemoved : cfg.i18n.dictInstalled;
				} else {
					buttons.forEach( function ( item ) {
						item.disabled = false;
					} );
					status.textContent = ( res && res.data && res.data.message ) ? res.data.message : cfg.i18n.dictError;
				}
			} ).catch( function () {
				buttons.forEach( function ( item ) {
					item.disabled = false;
				} );
				status.textContent = cfg.i18n.dictError;
			} );
		} );
	}

	/**
	 * Rebuild a dictionary row's badges and action buttons in place after an
	 * install/remove, so the panel updates without a full page reload.
	 *
	 * @param {HTMLElement} row     The .mvweb-ss-dict container.
	 * @param {string}      version Installed version, or '' when removed.
	 */
	function renderDictRow( row, version ) {
		var cfg = window.mvwebSSAdmin;
		var badge = row.querySelector( '.mvweb-ss-dict__version' );
		var updateBadge = row.querySelector( '.mvweb-ss-dict__update-badge' );
		var actions = row.querySelector( '.mvweb-ss-dict__actions' );

		row.setAttribute( 'data-installed', version );

		if ( badge ) {
			badge.textContent = version ? 'v' + version : '';
			badge.hidden = ! version;
		}

		if ( updateBadge ) {
			updateBadge.hidden = true;
		}

		if ( ! actions ) {
			return;
		}

		actions.textContent = '';

		if ( ! version ) {
			actions.appendChild( makeDictButton( 'install', cfg.i18n.dictLabelInstall, true ) );
			return;
		}

		var state = document.createElement( 'span' );
		state.className = 'mvweb-ss-dict__state';
		state.textContent = cfg.i18n.dictLabelInstalled;
		actions.appendChild( state );
		actions.appendChild( makeDictButton( 'remove', cfg.i18n.dictLabelRemove, false ) );
	}

	/**
	 * Create a dictionary action button.
	 *
	 * @param {string}  action  data-action value.
	 * @param {string}  label   Visible label.
	 * @param {boolean} primary Whether to style it as the primary button.
	 * @return {HTMLButtonElement} The button element.
	 */
	function makeDictButton( action, label, primary ) {
		var button = document.createElement( 'button' );
		button.type = 'button';
		button.className = 'mvweb-btn mvweb-ss-dict-action' + ( primary ? ' mvweb-btn--primary' : '' );
		button.setAttribute( 'data-action', action );
		button.textContent = label;

		return button;
	}

	/**
	 * Copy-to-clipboard buttons (.mvweb-ss-copy[data-copy]).
	 */
	function initCopy() {
		document.addEventListener( 'click', function ( event ) {
			var button = event.target.closest( '.mvweb-ss-copy' );

			if ( ! button ) {
				return;
			}

			copyText( button.getAttribute( 'data-copy' ) || '', button );
		} );
	}

	/**
	 * Briefly show the "copied" label, then restore the original.
	 * Re-entrant: captures the real original once and resets the timer on repeat clicks.
	 */
	function flashCopied( button ) {
		var copied = button.getAttribute( 'data-copied' );

		if ( ! copied ) {
			return;
		}

		if ( button.mvwebCopyTimer ) {
			clearTimeout( button.mvwebCopyTimer );
		} else {
			button.mvwebCopyOriginal = button.textContent;
			button.textContent = copied;
		}

		button.mvwebCopyTimer = setTimeout( function () {
			button.textContent = button.mvwebCopyOriginal;
			button.mvwebCopyTimer = null;
		}, 1500 );
	}

	/**
	 * Legacy copy via a hidden textarea. Returns whether the copy succeeded.
	 */
	function legacyCopy( text ) {
		var field = document.createElement( 'textarea' );
		field.value = text;
		field.setAttribute( 'readonly', '' );
		field.style.position = 'absolute';
		field.style.left = '-9999px';
		document.body.appendChild( field );
		field.select();

		var ok = false;
		try {
			ok = document.execCommand( 'copy' );
		} catch ( e ) {}

		document.body.removeChild( field );
		return ok;
	}

	/**
	 * Copy text to the clipboard, falling back to the legacy path, and only
	 * confirm to the user when the copy actually succeeded.
	 */
	function copyText( text, button ) {
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( text ).then( function () {
				flashCopied( button );
			} ).catch( function () {
				if ( legacyCopy( text ) ) {
					flashCopied( button );
				}
			} );
		} else if ( legacyCopy( text ) ) {
			flashCopied( button );
		}
	}

	/**
	 * Quick-setup profile: describe the selected profile and apply it via AJAX.
	 */
	function initProfiles() {
		if ( typeof window.mvwebSSAdmin === 'undefined' ) {
			return;
		}

		var cfg = window.mvwebSSAdmin;
		var select = document.getElementById( 'mvweb-ss-profile' );
		var desc = document.getElementById( 'mvweb-ss-profile-desc' );
		var apply = document.getElementById( 'mvweb-ss-profile-apply' );
		var status = document.getElementById( 'mvweb-ss-profile-status' );

		if ( ! select || ! apply ) {
			return;
		}

		if ( desc ) {
			select.addEventListener( 'change', function () {
				var opt = select.options[ select.selectedIndex ];
				desc.textContent = opt ? ( opt.getAttribute( 'data-desc' ) || '' ) : '';
			} );
		}

		apply.addEventListener( 'click', function () {
			if ( ! window.confirm( cfg.i18n.profileConfirm ) ) {
				return;
			}

			apply.disabled = true;

			if ( status ) {
				status.textContent = '';
			}

			var body = new URLSearchParams();
			body.append( 'action', 'mvweb_ss_apply_profile' );
			body.append( 'nonce', cfg.nonce );
			body.append( 'profile', select.value );

			fetch( cfg.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body.toString(),
			} ).then( function ( res ) {
				return res.json();
			} ).then( function ( res ) {
				if ( res && res.success ) {
					if ( status ) {
						status.textContent = cfg.i18n.profileApplied;
					}
					window.location.reload();
				} else {
					apply.disabled = false;
					if ( status ) {
						status.textContent = cfg.i18n.profileError;
					}
				}
			} ).catch( function () {
				apply.disabled = false;
				if ( status ) {
					status.textContent = cfg.i18n.profileError;
				}
			} );
		} );
	}

	/**
	 * Import settings from pasted JSON via AJAX.
	 */
	function initSettingsIO() {
		if ( typeof window.mvwebSSAdmin === 'undefined' ) {
			return;
		}

		var cfg = window.mvwebSSAdmin;
		var button = document.getElementById( 'mvweb-ss-import' );
		var input = document.getElementById( 'mvweb-ss-import-data' );
		var status = document.getElementById( 'mvweb-ss-import-status' );

		if ( ! button || ! input || ! status ) {
			return;
		}

		button.addEventListener( 'click', function () {
			var data = input.value.trim();

			if ( ! data ) {
				status.textContent = cfg.i18n.importEmpty;
				return;
			}

			button.disabled = true;

			var body = new URLSearchParams();
			body.append( 'action', 'mvweb_ss_import_settings' );
			body.append( 'nonce', cfg.nonce );
			body.append( 'data', data );

			fetch( cfg.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body.toString(),
			} ).then( function ( res ) {
				return res.json();
			} ).then( function ( res ) {
				if ( res && res.success ) {
					status.textContent = cfg.i18n.importOk;
					window.location.reload();
				} else {
					button.disabled = false;
					status.textContent = cfg.i18n.importError;
				}
			} ).catch( function () {
				button.disabled = false;
				status.textContent = cfg.i18n.importError;
			} );
		} );
	}

	/**
	 * Ask for confirmation before following a destructive link.
	 */
	function initConfirm() {
		document.addEventListener( 'click', function ( event ) {
			var link = event.target.closest( '.mvweb-ss-confirm' );

			if ( link && ! window.confirm( link.getAttribute( 'data-confirm' ) || '' ) ) {
				event.preventDefault();
			}
		} );
	}

	/**
	 * Sidebar tab navigation (UI Kit).
	 */
	function initTabs() {
		var links = document.querySelectorAll( '.mvweb-nav__link' );
		var panels = document.querySelectorAll( '.mvweb-tab-content' );

		if ( ! links.length || ! panels.length ) {
			return;
		}

		Array.prototype.forEach.call( links, function ( link ) {
			link.addEventListener( 'click', function ( event ) {
				event.preventDefault();
				var target = link.getAttribute( 'data-tab' );

				Array.prototype.forEach.call( links, function ( l ) {
					l.classList.remove( 'mvweb-nav__link--active' );
				} );
				Array.prototype.forEach.call( panels, function ( p ) {
					p.classList.remove( 'active' );
				} );

				link.classList.add( 'mvweb-nav__link--active' );
				var panel = document.getElementById( target );
				if ( panel ) {
					panel.classList.add( 'active' );
				}
			} );
		} );
	}

	/**
	 * Reindex button + progress polling.
	 */
	function initReindex() {
		if ( typeof window.mvwebSSAdmin === 'undefined' ) {
			return;
		}

		var cfg = window.mvwebSSAdmin;
		var button = document.getElementById( 'mvweb-ss-reindex' );
		var status = document.getElementById( 'mvweb-ss-reindex-status' );

		if ( ! button || ! status ) {
			return;
		}

		var running = false;

		function post( action ) {
			var body = new URLSearchParams();
			body.append( 'action', action );
			body.append( 'nonce', cfg.nonce );

			return fetch( cfg.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body.toString(),
			} ).then( function ( res ) {
				return res.json();
			} );
		}

		function updateCount( data ) {
			var el = document.getElementById( 'mvweb-ss-index-count' );
			if ( el && data && typeof data.in_index !== 'undefined' ) {
				el.textContent = data.in_index;
			}
		}

		function drawRunning( data ) {
			updateCount( data );
			status.textContent = cfg.i18n.running.replace( '%1$s', data.processed ).replace( '%2$s', data.total );
		}

		function finish( data ) {
			running = false;
			button.disabled = false;
			updateCount( data );
			status.textContent = cfg.i18n.done.replace( '%s', ( data && typeof data.in_index !== 'undefined' ) ? data.in_index : '' );
		}

		function fail() {
			running = false;
			button.disabled = false;
			status.textContent = cfg.i18n.error;
		}

		// Drive the reindex one batch at a time from the browser so it never
		// stalls waiting on WP-Cron and never runs more than one batch at once.
		function step() {
			post( 'mvweb_ss_reindex_step' ).then( function ( res ) {
				if ( ! res || ! res.success ) {
					fail();
					return;
				}
				if ( res.data.status === 'running' ) {
					drawRunning( res.data );
					step();
				} else {
					finish( res.data );
				}
			} ).catch( fail );
		}

		button.addEventListener( 'click', function () {
			if ( running ) {
				return;
			}
			running = true;
			button.disabled = true;
			status.textContent = cfg.i18n.starting;

			post( 'mvweb_ss_reindex_start' ).then( function ( res ) {
				if ( ! res || ! res.success ) {
					fail();
					return;
				}
				// started === false means a run is already going — the one primed
				// right after a schema upgrade, or another tab. The server hands
				// that run over rather than refusing it, and ajax_start claims the
				// browser lease either way, so the cron drain steps aside and this
				// tab finishes what is already in flight. Bailing out here instead
				// printed one snapshot of the count and stopped: the work carried
				// on in the background while the screen sat frozen, and only a
				// reload showed it had moved.
				drawRunning( res.data );
				step();
			} ).catch( fail );
		} );
	}
} )();
