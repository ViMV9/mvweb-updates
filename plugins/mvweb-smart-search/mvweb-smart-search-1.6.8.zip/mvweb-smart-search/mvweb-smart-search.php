<?php
/**
 * Plugin Name:       MVweb Smart Search
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-smart-search
 * Description:       Единый поиск по сайту (товары WooCommerce + записи + страницы + CPT) со своим индексом и русской морфологией, AJAX-выпадашкой с картинкой/ценой/наличием. Free, всё-в-одном.
 * Version:           1.6.8
 * Requires at least: 6.4
 * Tested up to:      7.1
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-smart-search
 * Domain Path:       /languages
 *
 * @package mvweb_ss
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_SS_VERSION' ) ) {
	return;
}

define( 'MVWEB_SS_VERSION', '1.6.8' );
define( 'MVWEB_SS_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_SS_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_SS_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_SS_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_SS_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_SS_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_SS_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_SS_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-smart-search' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter(
	'mvweb_registered_plugins',
	function ( $plugins ) {
		$plugins['mvweb-smart-search'] = array(
			'name'         => 'MVweb Smart Search',
			'description'  => __( 'All-in-one site search (WooCommerce products + posts + pages + custom post types) with its own index and Russian morphology, and an AJAX dropdown with image/price/stock. Free.', 'mvweb-smart-search' ),
			'url'          => 'https://mvweb.ru/plugins/mvweb-smart-search',
			'settings_url' => 'admin.php?page=mvweb-smart-search',
			'textdomain'   => 'mvweb-smart-search',
		);
		return $plugins;
	}
);

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_ss_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-smart-search',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_ss_load_textdomain' );

// ───────────────────────────────────────────────
// Plugin classes
// ───────────────────────────────────────────────
require_once MVWEB_SS_PATH . 'includes/helpers.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-settings.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-profiles.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-schema.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-log.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-stemmer.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-tokenizer.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-indexer.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-editor.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-sync.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-catchup.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-reindex.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-fuzzy.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-dictionaries.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-query.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-categories.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-rest.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-search.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-frontend.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-facets.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-facets-widget.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-nav.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-widget.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-analytics.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-revenue.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-digest.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-i18n.php';
require_once MVWEB_SS_PATH . 'includes/class-mvweb-ss-cli.php';
require_once MVWEB_SS_PATH . 'admin/class-mvweb-ss-admin.php';

// Create the index table on activation and run any pending migration; keep the
// schema current on upgrades. Activation goes through maybe_upgrade() (not create()
// directly) so a reactivation on an older table still runs the dedup/keys migration
// instead of letting dbDelta silently skip the UNIQUE key on duplicate rows.
register_activation_hook( __FILE__, array( 'MVweb_SS_Schema', 'maybe_upgrade' ) );
add_action( 'admin_init', array( 'MVweb_SS_Schema', 'maybe_upgrade' ) );

// Per-post "exclude from search" checkbox in the editor.
MVweb_SS_Editor::register();

// Keep the index in sync with content edits.
MVweb_SS_Sync::register();

// Incremental watermark catch-up: safety net for imports that bypass hooks.
MVweb_SS_Catchup::register();
register_deactivation_hook( __FILE__, array( 'MVweb_SS_Catchup', 'unschedule' ) );

// Daily rotation of the search log and click tables.
MVweb_SS_Log::register();
register_deactivation_hook( __FILE__, array( 'MVweb_SS_Log', 'unschedule' ) );

// Background full reindex (batches, WP-CLI, AJAX).
MVweb_SS_Reindex::register();
register_deactivation_hook( __FILE__, array( 'MVweb_SS_Reindex', 'unschedule_all' ) );

// Ready-made synonym dictionaries (install/update from GitHub).
MVweb_SS_Dictionaries::register();

// Live search REST endpoint.
MVweb_SS_Rest::register();

// Front-end: main-query interception + search bar / dropdown.
MVweb_SS_Search::register();
MVweb_SS_Frontend::register();

// Results-page facets (P2.1): category/brand/price filters via shortcode + widget.
MVweb_SS_Facets::register();

// Classic-menu integration: draggable search item in the menu editor.
MVweb_SS_Nav::register();

// Classic sidebar widget.
MVweb_SS_Widget::register();

// Search analytics: dashboard widget + log export.
MVweb_SS_Analytics::register();

// WooCommerce revenue-per-query attribution (opt-in).
MVweb_SS_Revenue::register();

// Weekly search digest email (opt-in, wp-cron).
MVweb_SS_Digest::register();
register_deactivation_hook( __FILE__, array( 'MVweb_SS_Digest', 'unschedule' ) );

// Multilingual result filtering (Polylang / WPML).
MVweb_SS_I18n::register();

// Auxiliary WP-CLI commands.
MVweb_SS_CLI::register();

// Admin settings page.
MVweb_SS_Admin::register();
