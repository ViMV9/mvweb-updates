<?php
/**
 * Tokenizer: text → normalized, stemmed terms with counts.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Turns a chunk of text into an array of index terms (term => count).
 *
 * @since 1.0.0
 */
class MVweb_SS_Tokenizer {

	const MAX_TERM_LENGTH = 50;

	const MIN_TERM_LENGTH = 2;

	/**
	 * How many letter/digit runs a glued token may hold and still be split.
	 *
	 * A model code is a handful of runs: "gtx1660ti" is three, "BL-58DT" three,
	 * "G975F" three, "125x66x3" five. A machine identifier is far longer — a
	 * MongoDB ObjectId such as "683ec6c16ede0cd1bc9bbc5d" comes apart into twelve,
	 * and every digit run among them ("16", "13", "683") lands in the index as a
	 * term of its own, where it reads exactly like a model number. Measured on a
	 * 13k-product B2B catalogue: 13 096 of 13 129 supplier SKUs split into more
	 * than four runs (median eleven), against 275 title tokens out of 19 984 —
	 * so the cut separates identifiers from real model codes.
	 */
	const MAX_MODEL_PARTS = 4;

	/**
	 * Russian stop words.
	 *
	 * @var string[]
	 */
	private static $stop_ru = array(
		'и',
		'в',
		'во',
		'не',
		'что',
		'он',
		'на',
		'я',
		'с',
		'со',
		'как',
		'а',
		'то',
		'все',
		'она',
		'так',
		'его',
		'но',
		'да',
		'ты',
		'к',
		'у',
		'же',
		'вы',
		'за',
		'бы',
		'по',
		'ее',
		'мне',
		'было',
		'вот',
		'от',
		'меня',
		'еще',
		'нет',
		'о',
		'из',
		'ему',
		'для',
		'ни',
		'до',
		'или',
		'при',
		'об',
		'этот',
		'эта',
		'это',
		'эти',
		'над',
		'под',
		'без',
		'уже',
		'ли',
		'бы',
	);

	/**
	 * English stop words.
	 *
	 * @var string[]
	 */
	private static $stop_en = array(
		'the',
		'a',
		'an',
		'and',
		'or',
		'of',
		'to',
		'in',
		'is',
		'it',
		'for',
		'on',
		'with',
		'as',
		'at',
		'by',
		'be',
		'this',
		'that',
		'are',
		'was',
		'from',
		'but',
		'not',
		'you',
		'your',
		'we',
		'i',
		'he',
		'she',
		'they',
		'them',
		'his',
		'her',
		'its',
		'our',
		'their',
		'my',
		'me',
		'us',
		'who',
		'whom',
		'which',
		'what',
		'these',
		'those',
		'some',
		'any',
		'all',
		'each',
		'every',
		'both',
		'either',
		'neither',
		'nor',
		'am',
		'been',
		'being',
		'were',
		'has',
		'have',
		'had',
		'do',
		'does',
		'did',
		'will',
		'would',
		'can',
		'could',
		'should',
		'may',
		'might',
		'must',
		'shall',
		'if',
		'then',
		'when',
		'while',
		'because',
		'than',
		'too',
		'very',
		'just',
		'also',
		'about',
		'into',
		'onto',
		'through',
		'during',
		'before',
		'after',
		'between',
		'against',
		'without',
		'within',
		'there',
		'here',
		'such',
		'own',
		'same',
		'other',
	);

	/**
	 * Tokenize text into stemmed terms with occurrence counts.
	 *
	 * @since 1.0.0
	 * @param string $text      Source text.
	 * @param string $lang      Force language ('ru'|'en'); empty = auto per token.
	 * @param int    $max_parts Skip the glued-model split for a token of more than this
	 *                          many letter/digit runs; 0 = split whatever comes.
	 * @return array<string,int> term => count.
	 */
	public static function tokenize( string $text, string $lang = '', int $max_parts = 0 ): array {
		$text = mb_strtolower( $text, 'UTF-8' );
		$text = str_replace( 'ё', 'е', $text );
		$text = self::expand_plus( $text );

		$raw = preg_split( '/[^\p{L}\p{N}\-]+/u', $text, -1, PREG_SPLIT_NO_EMPTY );

		if ( ! is_array( $raw ) ) {
			return array();
		}

		$terms = array();

		foreach ( $raw as $token ) {
			$token = trim( $token, '-' );

			if ( '' === $token ) {
				continue;
			}

			$token = self::normalize_homoglyphs( $token );

			if ( false !== strpos( $token, '-' ) ) {
				self::add_term( $terms, $token );

				// A hyphenated identifier is one token for the run budget: its parts
				// are counted together, so "PWS-LP-ASS-19V342A40" is not waved through
				// on the strength of each hyphen-separated piece being short.
				$hyphen_parts = self::model_parts( $token );

				foreach ( explode( '-', $token ) as $part ) {
					self::consume( $terms, $part, $lang, ( $max_parts > 0 && $hyphen_parts > $max_parts ) ? 1 : $max_parts );
				}

				continue;
			}

			self::consume( $terms, $token, $lang, $max_parts );
		}

		return $terms;
	}

	/**
	 * Count the words a user actually typed, before digit-unit or hyphen-compound
	 * expansion inflates the term list.
	 *
	 * The strictness floor (see MVweb_SS_Query::min_match) must key on how many
	 * words the shopper wrote, not on how many index terms tokenize() derives from
	 * them: a single glued token like "4000mah" yields three terms (4000mah, 4000,
	 * mah), and counting those as three required words would turn one word into an
	 * AND across all three — the opposite of the recall boost the split is for.
	 *
	 * @since 1.1.0
	 * @param string $text Source text.
	 * @return int Number of stop-word-filtered words of at least MIN_TERM_LENGTH.
	 */
	public static function word_count( string $text ): int {
		$text = mb_strtolower( $text, 'UTF-8' );
		$text = str_replace( 'ё', 'е', $text );
		$text = self::expand_plus( $text );

		$raw = preg_split( '/[^\p{L}\p{N}\-]+/u', $text, -1, PREG_SPLIT_NO_EMPTY );

		if ( ! is_array( $raw ) ) {
			return 0;
		}

		$count = 0;

		foreach ( $raw as $token ) {
			$token = trim( $token, '-' );

			if ( '' === $token ) {
				continue;
			}

			// Mirror tokenize(): unify mixed-script letters before the stop-word
			// test, so a homoglyph spelling of a stop word ("нeт") is counted the
			// same way consume() treats it — dropped, not counted as a word.
			$token = self::normalize_homoglyphs( $token );

			if ( ! self::passes_length( $token ) || self::is_stop_word( $token ) ) {
				continue;
			}

			++$count;
		}

		return $count;
	}

	/**
	 * Tokenize the query keeping the terms of each written word together.
	 *
	 * A flat term list loses the fact that "a515" produced both "a515" and "515",
	 * or that "4000mah" produced three terms. Coverage groups
	 * must not treat those as separate concepts: a word and everything derived
	 * from it is one thing the shopper asked for, exactly as word_count() already
	 * counts it. Returns one list of terms per word, in the order they were typed.
	 *
	 * A word that yields no indexable term is dropped, so the number of lists can
	 * be lower than word_count(): besides stop words and short words, which both
	 * count the same way, a word can also stem below the minimum length ("ось" →
	 * "о"). Callers must therefore keep capping a strictness floor derived from
	 * word_count() at the number of groups, as run() and term_match_counts() do.
	 *
	 * @since 1.5.5
	 * @param string $text      Source text.
	 * @param string $lang      Force language ('ru'|'en'); empty = auto per token.
	 * @param int    $max_parts Run budget for the glued-model split; 0 = no cap.
	 * @return array<int,string[]> One list of terms per word.
	 */
	public static function tokenize_words( string $text, string $lang = '', int $max_parts = 0 ): array {
		$raw = preg_split( '/[^\p{L}\p{N}\-]+/u', self::expand_plus( $text ), -1, PREG_SPLIT_NO_EMPTY );

		if ( ! is_array( $raw ) ) {
			return array();
		}

		$words = array();

		foreach ( $raw as $word ) {
			$terms = array_map( 'strval', array_keys( self::tokenize( $word, $lang, $max_parts ) ) );

			if ( ! empty( $terms ) ) {
				$words[] = $terms;
			}
		}

		return $words;
	}

	/**
	 * Rewrite the plus sign that names a model variant as the word it stands for.
	 *
	 * The sign is neither a letter nor a digit, so the split above drops it and a
	 * catalogue writing "Realme 12+" indexed exactly the terms one writing "Realme
	 * 12" does. Coverage could then never tell the two apart, and the asymmetry ran
	 * the wrong way: a title spelling Plus as a word for some other phone covered
	 * the concept the shopper asked for, while the actual Plus did not — measured
	 * on a parts shop, a battery for another brand carrying "6 Plus" in its title
	 * tied on coverage with the batteries for the phone that was actually named.
	 *
	 * What may stand before the sign is a digit or one of the model modifiers, and
	 * what may follow it is neither a letter nor a digit — the same boundaries the
	 * variant rule reads it by, so both sides of the search see the same sign, and
	 * part numbers ("68+E", "HB444199EBC+") keep theirs. A spaced "+" is left alone:
	 * in a title it lists what else is in the box ("Realme 9 Pro + OCA").
	 *
	 * @since 1.6.7
	 * @param string $text Raw text.
	 * @return string
	 */
	private static function expand_plus( string $text ): string {
		if ( false === strpos( $text, '+' ) ) {
			return $text;
		}

		$text = (string) preg_replace( '/(\d)\+(?![\p{L}\d])/u', '$1 plus', $text );

		if ( ! class_exists( 'MVweb_SS_Query' ) ) {
			return $text;
		}

		$alt = array();

		foreach ( array_keys( MVweb_SS_Query::qualifier_map() ) as $spelling ) {
			$alt[] = preg_quote( (string) $spelling, '/' );
		}

		if ( empty( $alt ) ) {
			return $text;
		}

		return (string) preg_replace( '/(?<![\p{L}\d])(' . implode( '|', $alt ) . ')\+(?![\p{L}\d])/iu', '$1 plus', $text );
	}

	/**
	 * Normalize, filter and stem a single token, then add it.
	 *
	 * @since 1.0.0
	 * @param array<string,int> $terms     Accumulator (by reference).
	 * @param string            $token     Raw token.
	 * @param string            $lang      Forced language or ''.
	 * @param int               $max_parts Run budget for the glued-model split; 0 = no cap.
	 * @return void
	 */
	private static function consume( array &$terms, string $token, string $lang, int $max_parts = 0 ): void {
		if ( ! self::passes_length( $token ) ) {
			return;
		}

		if ( self::is_stop_word( $token ) ) {
			return;
		}

		if ( preg_match( '/\d/', $token ) ) {
			self::add_term( $terms, $token );
			self::split_model( $terms, $token, $max_parts );
			return;
		}

		self::add_term( $terms, MVweb_SS_Stemmer::stem( $token, $lang ) );
	}

	/**
	 * Split a glued model / number+unit token into its letter and digit runs so
	 * it is searchable by any part.
	 *
	 * "150мм" also yields "150" and "мм" (query "труба 150" finds "труба 150мм"
	 * and back); "gtx1660" yields "gtx" and "1660"; "gtx1660ti" yields "gtx",
	 * "1660" and "ti". Every maximal run of letters or digits becomes a term, the
	 * whole glued token is already kept by the caller. Applied identically at
	 * index and query time. Gated by the normalize_models setting so catalogs
	 * where such codes are noise (apparel sizing) can turn it off.
	 *
	 * @since 1.1.0
	 * @param array<string,int> $terms     Accumulator (by reference).
	 * @param string            $token     Token containing at least one digit.
	 * @param int               $max_parts Skip the split past this many runs; 0 = no cap.
	 * @return void
	 */
	private static function split_model( array &$terms, string $token, int $max_parts = 0 ): void {
		if ( ! self::normalize_models() ) {
			return;
		}

		if ( ! preg_match_all( '/\p{L}+|\d+/u', $token, $m ) || count( $m[0] ) < 2 ) {
			return;
		}

		// Past the budget the token is an identifier, not a model: splitting it
		// would scatter its digits through the index as bogus model numbers. The
		// whole token is already kept by the caller, so an exact lookup still works.
		if ( $max_parts > 0 && count( $m[0] ) > $max_parts ) {
			return;
		}

		foreach ( $m[0] as $run ) {
			self::add_term( $terms, $run );
		}
	}

	/**
	 * Number of letter/digit runs a token comes apart into.
	 *
	 * @since 1.5.8
	 * @param string $token Token.
	 * @return int
	 */
	public static function model_parts( string $token ): int {
		return preg_match_all( '/\p{L}+|\d+/u', $token, $m ) ? count( $m[0] ) : 0;
	}

	/**
	 * Whether glued model / unit tokens are split into runs, cached per request.
	 *
	 * @var bool|null
	 */
	private static $normalize_models = null;

	/**
	 * Read the model-normalization setting once per request.
	 *
	 * @since 1.2.0
	 * @return bool
	 */
	private static function normalize_models(): bool {
		if ( null === self::$normalize_models ) {
			self::$normalize_models = ! class_exists( 'MVweb_SS_Settings' ) || (bool) MVweb_SS_Settings::get( 'normalize_models', true );
		}

		return self::$normalize_models;
	}

	/**
	 * Unify visually identical Latin/Cyrillic letters inside a mixed token.
	 *
	 * Only tokens that actually mix scripts are touched: the minority-script
	 * confusable letters (a/а, e/е, o/о, c/с, p/р, x/х, y/у) are converted to the
	 * majority script (ties go to Cyrillic, RU-first) so an accidental Latin "o"
	 * in a Russian word — or the reverse — still matches. Applied identically at
	 * index and query time, so both sides converge on the same term.
	 *
	 * @since 1.1.0
	 * @param string $token Lowercased token.
	 * @return string
	 */
	private static function normalize_homoglyphs( string $token ): string {
		static $lat_to_cyr = array(
			'a' => 'а',
			'e' => 'е',
			'o' => 'о',
			'c' => 'с',
			'p' => 'р',
			'x' => 'х',
			'y' => 'у',
		);
		static $cyr_to_lat = null;

		if ( null === $cyr_to_lat ) {
			$cyr_to_lat = array_flip( $lat_to_cyr );
		}

		$cyr = preg_match_all( '/\p{Cyrillic}/u', $token );
		$lat = preg_match_all( '/[a-z]/', $token );

		if ( $cyr < 1 || $lat < 1 ) {
			return $token;
		}

		return $cyr >= $lat ? strtr( $token, $lat_to_cyr ) : strtr( $token, $cyr_to_lat );
	}

	/**
	 * Add a term to the accumulator, incrementing its count.
	 *
	 * @since 1.0.0
	 * @param array<string,int> $terms Accumulator (by reference).
	 * @param string            $term  Final term.
	 * @return void
	 */
	private static function add_term( array &$terms, string $term ): void {
		$term = mb_substr( $term, 0, self::MAX_TERM_LENGTH, 'UTF-8' );

		if ( ! self::passes_length( $term ) ) {
			return;
		}

		$terms[ $term ] = isset( $terms[ $term ] ) ? $terms[ $term ] + 1 : 1;
	}

	/**
	 * Whether a token is long enough to index. Two characters always qualify; a
	 * single character qualifies only when it is a digit and single-character
	 * indexing is enabled, so a model or size number ("iphone 5", "5g") stays
	 * searchable without letting stray one-letter noise into the index (P0.5).
	 *
	 * @since 1.2.0
	 * @param string $token Token.
	 * @return bool
	 */
	private static function passes_length( string $token ): bool {
		$len = mb_strlen( $token, 'UTF-8' );

		if ( $len >= self::MIN_TERM_LENGTH ) {
			return true;
		}

		return 1 === $len && (bool) preg_match( '/^\d$/', $token ) && self::allow_single_char();
	}

	/**
	 * Whether single-character (digit) tokens are indexed, cached per request.
	 *
	 * @var bool|null
	 */
	private static $single_char = null;

	/**
	 * Read the single-character indexing setting once per request.
	 *
	 * @since 1.2.0
	 * @return bool
	 */
	private static function allow_single_char(): bool {
		if ( null === self::$single_char ) {
			self::$single_char = ! class_exists( 'MVweb_SS_Settings' ) || (bool) MVweb_SS_Settings::get( 'index_single_char_models', true );
		}

		return self::$single_char;
	}

	/**
	 * Custom stop words from settings, cached per request.
	 *
	 * @var string[]|null
	 */
	private static $extra_stop = null;

	/**
	 * Whether a token is a stop word in either supported language or the
	 * admin-defined custom list.
	 *
	 * @since 1.0.0
	 * @param string $token Token.
	 * @return bool
	 */
	private static function is_stop_word( string $token ): bool {
		if ( in_array( $token, self::$stop_ru, true ) || in_array( $token, self::$stop_en, true ) ) {
			return true;
		}

		if ( null === self::$extra_stop ) {
			self::$extra_stop = class_exists( 'MVweb_SS_Settings' ) ? MVweb_SS_Settings::custom_stopwords() : array();
		}

		return in_array( $token, self::$extra_stop, true );
	}
}
