<?php
/**
 * Database schema for the search index.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Owns the {prefix}mvweb_ss_index table and its meta option.
 *
 * @since 1.0.0
 */
class MVweb_SS_Schema {

	const DB_VERSION = '8';

	const META_OPTION = 'mvweb_ss_index_meta';

	/**
	 * Fully-qualified index table name.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'mvweb_ss_index';
	}

	/**
	 * Fully-qualified search log table name.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function log_table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'mvweb_ss_log';
	}

	/**
	 * Fully-qualified per-result click table name (self-learning boost).
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function clicks_table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'mvweb_ss_clicks';
	}

	/**
	 * Fully-qualified search revenue-attribution table name.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function revenue_table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'mvweb_ss_revenue';
	}

	/**
	 * Fully-qualified term document-frequency table name (IDF ranking).
	 *
	 * @since 1.2.0
	 * @return string
	 */
	public static function terms_table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'mvweb_ss_terms';
	}

	/**
	 * Fully-qualified per-field document-length table name (BM25 length norm).
	 *
	 * @since 1.2.0
	 * @return string
	 */
	public static function doclen_table_name(): string {
		global $wpdb;
		return $wpdb->prefix . 'mvweb_ss_doclen';
	}

	/**
	 * Create or update the index table via dbDelta.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function create(): void {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table           = self::table_name();
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $table (
	id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
	term varchar(50) NOT NULL DEFAULT '',
	object_id bigint(20) unsigned NOT NULL DEFAULT 0,
	object_type varchar(20) NOT NULL DEFAULT '',
	source varchar(20) NOT NULL DEFAULT '',
	count int(10) unsigned NOT NULL DEFAULT 1,
	lang varchar(5) NOT NULL DEFAULT '',
	PRIMARY KEY  (id),
	UNIQUE KEY uniq_row (object_id,term,source,lang),
	KEY term_cov (term,object_type,source,count),
	KEY object_id (object_id)
) $charset_collate;";

		dbDelta( $sql );

		$log_table = self::log_table_name();

		$log_sql = "CREATE TABLE $log_table (
	query_hash char(32) NOT NULL,
	query varchar(191) NOT NULL DEFAULT '',
	hits bigint(20) unsigned NOT NULL DEFAULT 0,
	results int(10) unsigned NOT NULL DEFAULT 0,
	clicks bigint(20) unsigned NOT NULL DEFAULT 0,
	updated datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
	PRIMARY KEY  (query_hash),
	KEY results (results)
) $charset_collate;";

		dbDelta( $log_sql );

		$clicks_table = self::clicks_table_name();

		$clicks_sql = "CREATE TABLE $clicks_table (
	query_hash char(32) NOT NULL,
	object_id bigint(20) unsigned NOT NULL DEFAULT 0,
	clicks bigint(20) unsigned NOT NULL DEFAULT 0,
	PRIMARY KEY  (query_hash,object_id)
) $charset_collate;";

		dbDelta( $clicks_sql );

		$revenue_table = self::revenue_table_name();

		$revenue_sql = "CREATE TABLE $revenue_table (
	query_hash char(32) NOT NULL,
	query varchar(191) NOT NULL DEFAULT '',
	carts bigint(20) unsigned NOT NULL DEFAULT 0,
	orders bigint(20) unsigned NOT NULL DEFAULT 0,
	revenue decimal(18,2) NOT NULL DEFAULT 0.00,
	updated datetime NOT NULL DEFAULT '1970-01-01 00:00:00',
	PRIMARY KEY  (query_hash),
	KEY revenue (revenue)
) $charset_collate;";

		dbDelta( $revenue_sql );

		$terms_table = self::terms_table_name();

		$terms_sql = "CREATE TABLE $terms_table (
	term varchar(50) NOT NULL DEFAULT '',
	df bigint(20) unsigned NOT NULL DEFAULT 0,
	PRIMARY KEY  (term)
) $charset_collate;";

		dbDelta( $terms_sql );

		$doclen_table = self::doclen_table_name();

		$doclen_sql = "CREATE TABLE $doclen_table (
	object_id bigint(20) unsigned NOT NULL DEFAULT 0,
	source varchar(20) NOT NULL DEFAULT '',
	len int(10) unsigned NOT NULL DEFAULT 0,
	PRIMARY KEY  (object_id,source)
) $charset_collate;";

		dbDelta( $doclen_sql );

		$meta                   = self::get_meta();
		$meta['schema_version'] = self::DB_VERSION;
		self::update_meta( $meta );
	}

	/**
	 * Run schema upgrade when the stored version is behind.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function maybe_upgrade(): void {
		$meta   = self::get_meta();
		$stored = isset( $meta['schema_version'] ) ? (string) $meta['schema_version'] : '';

		if ( self::DB_VERSION === $stored ) {
			return;
		}

		// The v7 index layout adds a unique-row key and a covering key. The index is
		// derived data — fully rebuilt from posts — so rather than deduplicate and
		// rewrite a large live table in place (slow, and it holds a table lock long
		// enough to take the site down), drop the derived tables and let create()
		// rebuild them empty: a fresh table gets the new keys instantly. A background
		// reindex then refills them in batches without blocking the site. Search is
		// briefly incomplete during the rebuild, but the site stays up.
		$rebuild = ( '' !== $stored && version_compare( $stored, '7', '<' ) );

		// The v8 index holds the same columns and keys, only more terms: the plus
		// sign of a model variant is now a term of its own. Nothing to drop, then —
		// the tables stay, search keeps answering from the terms already in them,
		// and a background reindex rewrites each object in place until every "12+"
		// carries its Plus. An install that never re-saves its catalogue would
		// otherwise keep answering the old way forever.
		$refill = ( '' !== $stored && ! $rebuild && version_compare( $stored, '8', '<' ) );

		if ( $rebuild ) {
			self::reset_derived_tables();
		}

		self::create();

		if ( $rebuild || $refill ) {
			MVweb_SS_Reindex::start_background();
		}
	}

	/**
	 * Drop the tables that are rebuilt from posts (the index and its IDF statistics),
	 * leaving the user-data tables (search log, clicks, revenue) untouched. create()
	 * recreates them empty with the current schema; the background reindex refills them.
	 *
	 * @since 1.5.0
	 * @return void
	 */
	private static function reset_derived_tables(): void {
		global $wpdb;

		foreach ( array( self::table_name(), self::terms_table_name(), self::doclen_table_name() ) as $table ) {
			$wpdb->query( "DROP TABLE IF EXISTS `$table`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		}
	}

	/**
	 * Read the index meta option.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function get_meta(): array {
		$meta = get_option( self::META_OPTION, array() );
		return is_array( $meta ) ? $meta : array();
	}

	/**
	 * Persist the index meta option without autoload.
	 *
	 * @since 1.0.0
	 * @param array $meta Meta payload.
	 * @return void
	 */
	public static function update_meta( array $meta ): void {
		update_option( self::META_OPTION, $meta, false );
	}

	/**
	 * Drop the table and remove the meta option.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function drop(): void {
		global $wpdb;

		$table         = self::table_name();
		$log_table     = self::log_table_name();
		$clicks_table  = self::clicks_table_name();
		$revenue_table = self::revenue_table_name();
		$terms_table   = self::terms_table_name();
		$doclen_table  = self::doclen_table_name();
		$wpdb->query( "DROP TABLE IF EXISTS `$table`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$wpdb->query( "DROP TABLE IF EXISTS `$log_table`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$wpdb->query( "DROP TABLE IF EXISTS `$clicks_table`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$wpdb->query( "DROP TABLE IF EXISTS `$revenue_table`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$wpdb->query( "DROP TABLE IF EXISTS `$terms_table`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$wpdb->query( "DROP TABLE IF EXISTS `$doclen_table`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery

		delete_option( self::META_OPTION );
	}
}
