<?php
/**
 * Search query engine: ranks index rows for a user query.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Turns a query string into a ranked list of matching objects.
 *
 * @since 1.0.0
 */
class MVweb_SS_Query {

	const MAX_LIMIT = 100;

	const DEFAULT_LIMIT = 20;

	const FUZZY_THRESHOLD = 3;

	const BM25_K1 = 1.2;

	/**
	 * Corrected query phrase from the last fuzzy fallback, or empty string.
	 *
	 * @var string
	 */
	private static $correction = '';

	/**
	 * Default per-source relevance weights.
	 *
	 * @var array<string,int>
	 */
	private static $weights = array(
		'title'         => 10,
		'sku'           => 10,
		'variation_sku' => 10,
		'gtin'          => 10,
		'attr'          => 7,
		'brand'         => 7,
		'content'       => 5,
		'excerpt'       => 5,
		'tax'           => 3,
		'cf'            => 3,
	);

	/**
	 * Default per-source relevance weights.
	 *
	 * @since 1.0.0
	 * @return array<string,int>
	 */
	public static function default_weights(): array {
		return self::$weights;
	}

	/**
	 * Corrected query phrase produced by the last fuzzy fallback.
	 *
	 * @since 1.0.0
	 * @return string Empty string when the last search needed no correction.
	 */
	public static function last_correction(): string {
		return self::$correction;
	}

	/**
	 * Search the index.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @param array  $args  { Optional.
	 *     @type int      $limit      Max results (capped at MAX_LIMIT).
	 *     @type string   $strictness 'loose', 'balanced' (default) or 'strict'.
	 *     @type string[] $post_types Restrict to these types.
	 * }
	 * @return array<int,array{object_id:int,object_type:string,score:float}>
	 */
	public static function search( string $query, array $args = array() ): array {
		self::$correction = '';

		// A leading "-word" excludes results containing that word (Boolean NOT).
		list( $clean_query, $neg_terms ) = self::split_negatives( $query );

		// Budget parsed from the query ("до 5000", "от 1000", "5000-10000") becomes a
		// price filter, and the matched phrase is stripped from the searchable text.
		$price_min = null;
		$price_max = null;

		if ( MVweb_SS_Settings::get( 'parse_price_intent', true ) && class_exists( 'WooCommerce' ) ) {
			list( $clean_query, $price_min, $price_max ) = self::parse_price_intent( $clean_query );
		}

		$terms = array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( $clean_query ) ) );

		if ( empty( $terms ) ) {
			return array();
		}

		$limit = isset( $args['limit'] ) ? (int) $args['limit'] : self::DEFAULT_LIMIT;
		$limit = max( 1, min( $limit, self::MAX_LIMIT ) );

		$strictness = isset( $args['strictness'] )
			? (string) $args['strictness']
			: (string) MVweb_SS_Settings::get( 'strictness', 'balanced' );

		$min_match = self::min_match( $strictness, MVweb_SS_Tokenizer::word_count( $clean_query ) );

		$types = isset( $args['post_types'] ) && is_array( $args['post_types'] ) && ! empty( $args['post_types'] )
			? array_values( $args['post_types'] )
			: MVweb_SS_Indexer::get_indexed_post_types();

		$term_ids = isset( $args['term_ids'] ) && is_array( $args['term_ids'] )
			? array_values( array_filter( array_map( 'intval', $args['term_ids'] ) ) )
			: array();

		$taxonomy = isset( $args['taxonomy'] ) ? (string) $args['taxonomy'] : '';

		// Self-learning click-boost keys on the raw query the shopper typed; the
		// same hash covers the layout-swap and fuzzy retries (clicks were logged
		// under that original wording). Empty unless the boost is enabled.
		$query_hash = MVweb_SS_Settings::get( 'click_boost', false ) ? MVweb_SS_Log::hash( $query ) : '';

		// Fold synonyms into the primary run so coverage-first ranking floats the
		// results that also match a synonym, while the strictness floor stays tied
		// to the number of original query words (a synonym does not raise the bar).
		// The trailing word is passed as a prefix so a synonym still fires while it
		// is being typed ("iphone 14 батаре" reaches the "аккумулятор" synonym).
		// Cross-script transliteration folds "samsung"↔"самсунг" so a query in one
		// script reaches products written in the other. Query-time only (never
		// emitted into the index), attached to the source word's coverage group.
		$translit = MVweb_SS_Settings::get( 'translit_cross_script', true );

		$partial = MVweb_SS_Settings::get( 'synonym_prefix', true ) ? self::trailing_stem( $clean_query ) : '';
		$groups  = self::expand_groups( $terms, $partial, $translit );

		$results = self::run( $groups, $types, $min_match, $limit, $term_ids, $taxonomy, $neg_terms, $query_hash, $price_min, $price_max );

		// If a price filter emptied the results, drop it and keep the text matches
		// rather than showing nothing (a wrong parse must not swallow the query).
		if ( empty( $results ) && ( null !== $price_min || null !== $price_max ) ) {
			$price_min = null;
			$price_max = null;
			$results   = self::run( $groups, $types, $min_match, $limit, $term_ids, $taxonomy, $neg_terms, $query_hash );
		}

		$threshold = (int) apply_filters( 'mvweb_ss_fuzzy_threshold', self::FUZZY_THRESHOLD );

		if ( MVweb_SS_Settings::get( 'fuzzy', true ) && count( $results ) < $threshold ) {
			// Wrong keyboard-layout recovery: a query typed in the other layout
			// ("ghbdtn" instead of "привет") is swapped and retried; adopted only
			// when it actually finds more than the original.
			$swapped = self::swap_layout( $clean_query );

			if ( '' !== $swapped ) {
				$swap_terms = array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( $swapped ) ) );

				if ( ! empty( $swap_terms ) ) {
					$swap_match   = self::min_match( $strictness, MVweb_SS_Tokenizer::word_count( $swapped ) );
					$swap_results = self::run( self::expand_groups( $swap_terms, '', $translit ), $types, $swap_match, $limit, $term_ids, $taxonomy, $neg_terms, $query_hash, $price_min, $price_max );

					if ( count( $swap_results ) > count( $results ) ) {
						$results          = $swap_results;
						self::$correction = trim( $swapped );
					}
				}
			}

			// Typo tolerance: still scarce after the layout swap, widen with fuzzy candidates.
			if ( count( $results ) < $threshold ) {
				$fuzzy_groups = self::groups_with_fuzzy( $terms );

				if ( self::group_term_count( $fuzzy_groups ) > count( $terms ) ) {
					$fuzzy = self::run( $fuzzy_groups, $types, $min_match, $limit, $term_ids, $taxonomy, $neg_terms, $query_hash, $price_min, $price_max );

					if ( count( $fuzzy ) > count( $results ) ) {
						$results          = $fuzzy;
						self::$correction = self::derive_correction( $clean_query, $fuzzy );
					}
				}
			}
		}

		// Exact-match boost: a result whose title or SKU is exactly the query jumps
		// to the top, above a merely high-scoring partial match (P0.3).
		$results = self::promote_exact( $clean_query, $results );

		$pins = MVweb_SS_Settings::pins_for( $query );

		if ( ! empty( $pins ) ) {
			$results = self::apply_pins( $pins, $types, $results, $limit, $term_ids, $taxonomy );
		}

		/**
		 * Filter the final ranked results (used for language filtering and integrations).
		 *
		 * @since 1.0.0
		 * @param array  $results Ranked results.
		 * @param string $query   Raw user query.
		 * @param array  $types   Post types searched.
		 */
		return (array) apply_filters( 'mvweb_ss_results', $results, $query, $types );
	}

	/**
	 * Expand query terms into coverage groups: each original word seeds a group,
	 * and its synonyms, transliterations and (later) fuzzy variants join that same
	 * group. Grouping is what keeps coverage honest — a word and its synonym count
	 * as one covered concept, not two, so "батарея"+"аккумулятор" no longer
	 * out-covers a genuine two-word match (P0.2).
	 *
	 * A synonym rule fires when ALL of its pattern stems are present among the
	 * query terms (order-independent); its additions attach to the group of the
	 * pattern's anchor word. The trailing, still-being-typed word may match a
	 * pattern stem by prefix so a synonym fires before the word is finished.
	 *
	 * @since 1.2.0
	 * @param string[] $terms    Original query terms.
	 * @param string   $partial  Stem of the still-being-typed trailing word, or ''.
	 * @param bool     $translit Whether to add cross-script transliterations.
	 * @return array<int,string[]> Coverage groups (each a list of terms).
	 */
	private static function expand_groups( array $terms, string $partial = '', bool $translit = false ): array {
		$groups = array();
		$index  = array();

		foreach ( $terms as $term ) {
			if ( ! isset( $index[ $term ] ) ) {
				$index[ $term ] = count( $groups );
				$groups[]       = array( $term );
			}
		}

		if ( empty( $groups ) ) {
			return array();
		}

		if ( $translit ) {
			foreach ( $terms as $term ) {
				foreach ( self::transliterations( $term ) as $variant ) {
					self::attach( $groups, $index, $index[ $term ], $variant );
				}
			}
		}

		$rules = MVweb_SS_Settings::synonym_map();

		if ( ! empty( $rules ) ) {
			$term_set = array_flip( $terms );

			foreach ( $rules as $rule ) {
				$used_prefix = false;
				$anchor      = null;

				foreach ( $rule['pattern'] as $stem ) {
					$stem = (string) $stem;

					if ( isset( $term_set[ $stem ] ) ) {
						if ( null === $anchor ) {
							$anchor = $stem;
						}
						continue;
					}

					if ( '' !== $partial && ! $used_prefix && 0 === mb_strpos( $stem, $partial, 0, 'UTF-8' ) ) {
						$used_prefix = true;

						if ( null === $anchor && isset( $index[ $partial ] ) ) {
							$anchor = $partial;
						}

						continue;
					}

					continue 2;
				}

				if ( null === $anchor || ! isset( $index[ $anchor ] ) ) {
					$anchor = $terms[0];
				}

				foreach ( $rule['add'] as $add ) {
					self::attach( $groups, $index, $index[ $anchor ], (string) $add );
				}
			}
		}

		return $groups;
	}

	/**
	 * Attach a term to an existing coverage group unless it is already placed.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups Coverage groups (by reference).
	 * @param array<string,int>   $index  term => group index (by reference).
	 * @param int                 $gi     Target group index.
	 * @param string              $term   Term to attach.
	 * @return void
	 */
	private static function attach( array &$groups, array &$index, int $gi, string $term ): void {
		if ( '' === $term || isset( $index[ $term ] ) ) {
			return;
		}

		$index[ $term ]  = $gi;
		$groups[ $gi ][] = $term;
	}

	/**
	 * Build coverage groups where each fuzzy candidate joins its source term's
	 * group, so typo variants never inflate coverage either.
	 *
	 * @since 1.2.0
	 * @param string[] $terms Original query terms.
	 * @return array<int,string[]>
	 */
	private static function groups_with_fuzzy( array $terms ): array {
		$groups = self::expand_groups( $terms );

		$index = array();
		foreach ( $groups as $gi => $group ) {
			foreach ( $group as $term ) {
				$index[ $term ] = $gi;
			}
		}

		foreach ( $terms as $term ) {
			if ( mb_strlen( $term, 'UTF-8' ) < MVweb_SS_Fuzzy::MIN_LENGTH || ! isset( $index[ $term ] ) ) {
				continue;
			}

			foreach ( MVweb_SS_Fuzzy::candidates( $term ) as $candidate ) {
				self::attach( $groups, $index, $index[ $term ], (string) $candidate );
			}
		}

		return $groups;
	}

	/**
	 * Flatten coverage groups to a unique term list (WHERE i.term IN order).
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups Coverage groups.
	 * @return string[]
	 */
	private static function flatten_groups( array $groups ): array {
		$out = array();

		foreach ( $groups as $group ) {
			foreach ( $group as $term ) {
				$out[] = (string) $term;
			}
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Total number of distinct terms across all coverage groups.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups Coverage groups.
	 * @return int
	 */
	private static function group_term_count( array $groups ): int {
		return count( self::flatten_groups( $groups ) );
	}

	/**
	 * Cross-script phonetic variants of a single-script term, stemmed the same way
	 * the index stored its terms. A Cyrillic word yields its Latin spelling and a
	 * Latin word its Cyrillic one ("samsung"↔"самсунг"), so a query reaches
	 * products written in the other script. Best-effort — exact brand spellings
	 * the phonetic map misses ("айфон", "сяоми") belong in the synonym dictionary.
	 *
	 * @since 1.2.0
	 * @param string $term Query term (already stemmed).
	 * @return string[] Stemmed variant terms (may be empty).
	 */
	private static function transliterations( string $term ): array {
		if ( mb_strlen( $term, 'UTF-8' ) < 3 ) {
			return array();
		}

		$has_cyr = (bool) preg_match( '/\p{Cyrillic}/u', $term );
		$has_lat = (bool) preg_match( '/[a-z]/', $term );

		if ( $has_cyr === $has_lat ) {
			return array();
		}

		$raw = $has_cyr ? self::cyr_to_lat( $term ) : self::lat_to_cyr( $term );

		if ( '' === $raw || $raw === $term ) {
			return array();
		}

		return array_values(
			array_filter(
				array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( $raw ) ) ),
				static function ( $variant ) use ( $term ) {
					return '' !== $variant && $variant !== $term;
				}
			)
		);
	}

	/**
	 * Transliterate Cyrillic to Latin (phonetic, GOST-ish digraphs).
	 *
	 * @since 1.2.0
	 * @param string $term Cyrillic term.
	 * @return string
	 */
	private static function cyr_to_lat( string $term ): string {
		static $map = array(
			'а' => 'a',
			'б' => 'b',
			'в' => 'v',
			'г' => 'g',
			'д' => 'd',
			'е' => 'e',
			'ж' => 'zh',
			'з' => 'z',
			'и' => 'i',
			'й' => 'y',
			'к' => 'k',
			'л' => 'l',
			'м' => 'm',
			'н' => 'n',
			'о' => 'o',
			'п' => 'p',
			'р' => 'r',
			'с' => 's',
			'т' => 't',
			'у' => 'u',
			'ф' => 'f',
			'х' => 'kh',
			'ц' => 'ts',
			'ч' => 'ch',
			'ш' => 'sh',
			'щ' => 'shch',
			'ъ' => '',
			'ы' => 'y',
			'ь' => '',
			'э' => 'e',
			'ю' => 'yu',
			'я' => 'ya',
		);

		return strtr( $term, $map );
	}

	/**
	 * Transliterate Latin to Cyrillic (phonetic). strtr() replaces the longest key
	 * first, so digraphs (sh, ch, …) win over their single letters.
	 *
	 * @since 1.2.0
	 * @param string $term Latin term.
	 * @return string
	 */
	private static function lat_to_cyr( string $term ): string {
		static $map = array(
			'shch' => 'щ',
			'sch'  => 'щ',
			'sh'   => 'ш',
			'ch'   => 'ч',
			'zh'   => 'ж',
			'kh'   => 'х',
			'ts'   => 'ц',
			'yu'   => 'ю',
			'ya'   => 'я',
			'yo'   => 'е',
			'a'    => 'а',
			'b'    => 'б',
			'c'    => 'к',
			'd'    => 'д',
			'e'    => 'е',
			'f'    => 'ф',
			'g'    => 'г',
			'h'    => 'х',
			'i'    => 'и',
			'j'    => 'дж',
			'k'    => 'к',
			'l'    => 'л',
			'm'    => 'м',
			'n'    => 'н',
			'o'    => 'о',
			'p'    => 'п',
			'q'    => 'к',
			'r'    => 'р',
			's'    => 'с',
			't'    => 'т',
			'u'    => 'у',
			'v'    => 'в',
			'w'    => 'в',
			'x'    => 'кс',
			'y'    => 'й',
			'z'    => 'з',
		);

		return strtr( $term, $map );
	}

	/**
	 * Stem of the last, still-being-typed word of a query (for prefix synonyms).
	 *
	 * @since 1.2.0
	 * @param string $clean_query Query with negations removed.
	 * @return string Stem of the trailing word, or '' when too short/absent.
	 */
	private static function trailing_stem( string $clean_query ): string {
		$words = preg_split( '/\s+/u', trim( $clean_query ) );

		if ( empty( $words ) ) {
			return '';
		}

		$stems = array_keys( MVweb_SS_Tokenizer::tokenize( (string) end( $words ) ) );

		if ( empty( $stems ) ) {
			return '';
		}

		$last = (string) end( $stems );

		return mb_strlen( $last, 'UTF-8' ) >= 3 ? $last : '';
	}

	/**
	 * Prepend admin-pinned, still-public results to the top.
	 *
	 * @since 1.0.0
	 * @param int[]    $pin_ids  Pinned object IDs (in order).
	 * @param string[] $types    Post types in scope for this search.
	 * @param array    $results  Ranked results.
	 * @param int      $limit    Max rows.
	 * @param int[]    $term_ids Active category term IDs, or empty.
	 * @param string   $taxonomy Taxonomy of the term IDs.
	 * @return array
	 */
	private static function apply_pins( array $pin_ids, array $types, array $results, int $limit, array $term_ids = array(), string $taxonomy = '' ): array {
		$exclude = MVweb_SS_Settings::excluded_ids();
		$scoped  = ! empty( $term_ids ) && '' !== $taxonomy;
		$pinned  = array();

		foreach ( $pin_ids as $id ) {
			if ( in_array( (int) $id, $exclude, true ) ) {
				continue;
			}

			if ( $scoped && ! has_term( $term_ids, $taxonomy, (int) $id ) ) {
				continue;
			}

			$post = get_post( $id );

			if ( $post instanceof WP_Post
				&& 'publish' === $post->post_status
				&& '' === (string) $post->post_password
				&& in_array( $post->post_type, $types, true ) ) {
				$pinned[] = array(
					'object_id'   => (int) $id,
					'object_type' => $post->post_type,
					'score'       => (float) PHP_INT_MAX,
				);
			}
		}

		if ( empty( $pinned ) ) {
			return $results;
		}

		$ids  = array_column( $pinned, 'object_id' );
		$rest = array_filter(
			$results,
			static function ( $row ) use ( $ids ) {
				return ! in_array( $row['object_id'], $ids, true );
			}
		);

		return array_slice( array_merge( $pinned, array_values( $rest ) ), 0, $limit );
	}

	/**
	 * Move results whose title or SKU is exactly the query to the very top.
	 *
	 * An exact title/SKU match always carries full coverage, so promoting it never
	 * lifts a lower-coverage item above a higher-coverage one — it only settles
	 * ties in favour of the literal match the shopper almost certainly wants.
	 *
	 * @since 1.2.0
	 * @param string $query   Cleaned query.
	 * @param array  $results Ranked results.
	 * @return array
	 */
	private static function promote_exact( string $query, array $results ): array {
		$boost = (float) MVweb_SS_Settings::get( 'exact_match_boost', 5.0 );

		if ( $boost <= 1 || empty( $results ) ) {
			return $results;
		}

		$key = self::normalize_exact( $query );

		if ( '' === $key ) {
			return $results;
		}

		$exact = array();
		$rest  = array();

		foreach ( $results as $row ) {
			if ( self::is_exact_match( (int) $row['object_id'], $key ) ) {
				$exact[] = $row;
			} else {
				$rest[] = $row;
			}
		}

		return empty( $exact ) ? $results : array_merge( $exact, $rest );
	}

	/**
	 * Whether an object's title or (product) SKU equals the normalized query.
	 *
	 * @since 1.2.0
	 * @param int    $object_id Object ID.
	 * @param string $key       Normalized query.
	 * @return bool
	 */
	private static function is_exact_match( int $object_id, string $key ): bool {
		if ( self::normalize_exact( (string) get_the_title( $object_id ) ) === $key ) {
			return true;
		}

		if ( function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $object_id );

			if ( $product && '' !== $product->get_sku() && self::normalize_exact( (string) $product->get_sku() ) === $key ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Normalize a string for exact comparison: lowercase, ё→е, alphanumerics only,
	 * single-spaced.
	 *
	 * @since 1.2.0
	 * @param string $text Input.
	 * @return string
	 */
	private static function normalize_exact( string $text ): string {
		$text = str_replace( 'ё', 'е', mb_strtolower( trim( $text ), 'UTF-8' ) );
		$text = (string) preg_replace( '/[^\p{L}\p{N}]+/u', ' ', $text );

		return trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
	}

	/**
	 * Split a raw query into its positive text and negated stems.
	 *
	 * A whitespace-delimited word starting with "-" ("iphone -чехол") is a
	 * Boolean NOT: the word is removed from the searchable text and its stems
	 * are returned so the ranking query can exclude any object carrying them.
	 * A "-" inside a word ("телефон-раскладушка") is a compound, not a negation.
	 *
	 * @since 1.1.0
	 * @param string $query Raw user query.
	 * @return array{0:string,1:string[]} Cleaned query, then negated stems.
	 */
	public static function split_negatives( string $query ): array {
		$neg_words = array();

		$clean = (string) preg_replace_callback(
			'/(?:^|\s)-(\S+)/u',
			static function ( $m ) use ( &$neg_words ) {
				$neg_words[] = $m[1];
				return ' ';
			},
			$query
		);

		$neg_terms = array();

		foreach ( $neg_words as $word ) {
			foreach ( array_keys( MVweb_SS_Tokenizer::tokenize( $word ) ) as $stem ) {
				$neg_terms[] = (string) $stem;
			}
		}

		return array( trim( $clean ), array_values( array_unique( $neg_terms ) ) );
	}

	/**
	 * Parse a price budget out of the query and strip the matched phrase.
	 *
	 * Understands "до N"/"under N" (max), "от N"/"from N" (min), "от N до M" and a
	 * bare "N-M" range (both at least three digits, so model numbers like "11-13"
	 * are left alone), plus common currency words. A wrong parse can never hide
	 * results — the caller drops the filter and retries when it empties the list.
	 *
	 * @since 1.2.0
	 * @param string $query Cleaned query.
	 * @return array{0:string,1:float|null,2:float|null} Query without the price phrase, min, max.
	 */
	private static function parse_price_intent( string $query ): array {
		$min = null;
		$max = null;
		$q   = ' ' . mb_strtolower( $query, 'UTF-8' ) . ' ';

		if ( preg_match( '/\bот\s+(\d+)\s+до\s+(\d+)\b/u', $q, $m ) ) {
			$min = (float) $m[1];
			$max = (float) $m[2];
			$q   = str_replace( $m[0], ' ', $q );
		} elseif ( preg_match( '/(?<!\d)(\d{3,})\s*[-–—]\s*(\d{3,})(?!\d)/u', $q, $m ) ) {
			$min = (float) $m[1];
			$max = (float) $m[2];
			$q   = str_replace( $m[0], ' ', $q );
		}

		if ( null === $max && preg_match( '/\b(?:до|дешевле|под|under|below)\s+(\d+)\b/u', $q, $m ) ) {
			$max = (float) $m[1];
			$q   = str_replace( $m[0], ' ', $q );
		}

		if ( null === $min && preg_match( '/\b(?:от|дороже|from|over|above)\s+(\d+)\b/u', $q, $m ) ) {
			$min = (float) $m[1];
			$q   = str_replace( $m[0], ' ', $q );
		}

		$q = (string) preg_replace( '/\b(?:руб(?:лей|ля)?|₽|rub|usd)\b/u', ' ', $q );
		$q = trim( (string) preg_replace( '/\s+/u', ' ', $q ) );

		return array( '' === $q ? $query : $q, $min, $max );
	}

	/**
	 * Re-map a query typed in the wrong keyboard layout to the other one.
	 *
	 * Swaps characters between the Russian ЙЦУКЕН and the English QWERTY layouts
	 * by physical key, so "ghbdtn" becomes "привет" (and the reverse). Returns an
	 * empty string when nothing changed, letting the caller skip a pointless
	 * re-search. The slash and backtick keys are left out (their letters ./ё
	 * collide or are stemmer-normalized), so the map stays unambiguous.
	 *
	 * @since 1.1.0
	 * @param string $query Raw user query.
	 * @return string Swapped query, or '' when unchanged.
	 */
	private static function swap_layout( string $query ): string {
		$lower = mb_strtolower( trim( $query ), 'UTF-8' );

		if ( '' === $lower ) {
			return '';
		}

		$swapped = strtr( $lower, self::layout_map() );

		return $swapped === $lower ? '' : $swapped;
	}

	/**
	 * Bidirectional QWERTY↔ЙЦУКЕН character map keyed by physical key.
	 *
	 * @since 1.1.0
	 * @return array<string,string>
	 */
	private static function layout_map(): array {
		static $map = null;

		if ( null !== $map ) {
			return $map;
		}

		$en = str_split( 'qwertyuiop[]asdfghjkl;\'zxcvbnm,.' );
		$ru = mb_str_split( 'йцукенгшщзхъфывапролджэячсмитьбю', 1, 'UTF-8' );

		$map = array();

		foreach ( $en as $i => $ch ) {
			$map[ $ch ]       = $ru[ $i ];
			$map[ $ru[ $i ] ] = $ch;
		}

		return $map;
	}

	/**
	 * Build a human-readable "did you mean" phrase from the top fuzzy match.
	 *
	 * Uses real words from the best result's title (not stemmed index terms),
	 * replacing each raw query word with the closest title word within edit
	 * distance 2. Returns an empty string when nothing changed.
	 *
	 * @since 1.0.0
	 * @param string $query   Raw user query.
	 * @param array  $results Fuzzy result set (best first).
	 * @return string
	 */
	private static function derive_correction( string $query, array $results ): string {
		if ( empty( $results ) ) {
			return '';
		}

		$raw_words = preg_split( '/\s+/u', trim( $query ), -1, PREG_SPLIT_NO_EMPTY );

		if ( empty( $raw_words ) ) {
			return '';
		}

		$title       = wp_strip_all_tags( (string) get_the_title( (int) $results[0]['object_id'] ) );
		$title_words = preg_split( '/\s+/u', $title, -1, PREG_SPLIT_NO_EMPTY );

		if ( empty( $title_words ) ) {
			return '';
		}

		$out = array();

		foreach ( (array) $raw_words as $word ) {
			$word_lc = mb_strtolower( (string) $word, 'UTF-8' );
			$len     = mb_strlen( $word_lc, 'UTF-8' );
			$best    = (string) $word;
			$best_d  = PHP_INT_MAX;

			foreach ( (array) $title_words as $candidate ) {
				$candidate = (string) $candidate;

				if ( abs( mb_strlen( $candidate, 'UTF-8' ) - $len ) > 2 ) {
					continue;
				}

				$distance = MVweb_SS_Fuzzy::distance( $word_lc, mb_strtolower( $candidate, 'UTF-8' ) );

				if ( $distance < $best_d ) {
					$best_d = $distance;
					$best   = $candidate;
				}
			}

			$out[] = ( $best_d > 0 && $best_d <= 2 ) ? $best : (string) $word;
		}

		$corrected = implode( ' ', $out );
		$original  = (string) preg_replace( '/\s+/u', ' ', trim( $query ) );

		return mb_strtolower( $corrected, 'UTF-8' ) === mb_strtolower( $original, 'UTF-8' ) ? '' : $corrected;
	}

	/**
	 * Run the ranking query for a set of coverage groups.
	 *
	 * Each group is one covered concept (a word plus its synonyms/transliterations/
	 * fuzzy variants); coverage counts distinct groups, not raw terms, so a word and
	 * its synonym never double-count (P0.2). When enabled, each term's contribution
	 * is scaled by its inverse document frequency, so a common word pulls far less
	 * weight than a rare, discriminating one (P0.1).
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups    Non-empty coverage groups.
	 * @param string[]            $types     Post types to search.
	 * @param int                 $min_match Minimum number of distinct groups an object must match (1 = OR, N = AND).
	 * @param int                 $limit     Max rows.
	 * @param int[]               $term_ids  Restrict to objects in these taxonomy term IDs.
	 * @param string              $taxonomy  Taxonomy the term IDs belong to (required with $term_ids).
	 * @param string[]            $exclude_terms Stems whose presence disqualifies an object (Boolean NOT).
	 * @param string              $query_hash    Raw-query hash for the self-learning click-boost ('' = off).
	 * @return array<int,array{object_id:int,object_type:string,score:float}>
	 */
	private static function run( array $groups, array $types, int $min_match, int $limit, array $term_ids = array(), string $taxonomy = '', array $exclude_terms = array(), string $query_hash = '', ?float $price_min = null, ?float $price_max = null ): array {
		global $wpdb;

		$terms = self::flatten_groups( $groups );

		if ( empty( $terms ) || empty( $types ) ) {
			return array();
		}

		$pml_joined = false;

		$table = MVweb_SS_Schema::table_name();

		$coverage = self::coverage_case_sql( $groups );

		$use_idf   = (bool) MVweb_SS_Settings::get( 'ranking_use_idf', true );
		$idf_join  = '';
		$score_sum = self::weight_case();

		if ( $use_idf ) {
			$terms_table = MVweb_SS_Schema::terms_table_name();
			$n           = self::doc_count();
			$idf_join    = "LEFT JOIN `$terms_table` t ON t.term = i.term";
			$idf         = "LN( 1 + ( $n - LEAST( COALESCE( t.df, 0 ), $n ) + 0.5 ) / ( COALESCE( t.df, 0 ) + 0.5 ) )";
			$score_sum   = '( ' . $idf . ' ) * ( ' . $score_sum . ' )';
		}

		$in_terms = implode( ',', array_fill( 0, count( $terms ), '%s' ) );
		$in_types = implode( ',', array_fill( 0, count( $types ), '%s' ) );

		$tax_sql   = '';
		$tax_valid = ! empty( $term_ids ) && '' !== $taxonomy;

		if ( $tax_valid ) {
			$in_tids = implode( ',', array_fill( 0, count( $term_ids ), '%d' ) );
			$tax_sql = "AND i.object_id IN (
				SELECT tr.object_id FROM {$wpdb->term_relationships} tr
				INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
				WHERE tt.taxonomy = %s AND tt.term_id IN ($in_tids)
			)";
		}

		$stock        = self::stock_mode();
		$stock_active = ( 'show' !== $stock ) && class_exists( 'WooCommerce' );

		$join         = '';
		$stock_select = '';
		$order_prefix = '';
		$having_parts = array();

		if ( $min_match > 1 ) {
			$having_parts[] = 'matched >= %d';
		}

		if ( $stock_active ) {
			$join         = "LEFT JOIN {$wpdb->postmeta} sm ON sm.post_id = i.object_id AND sm.meta_key = '_stock_status'";
			$stock_select = ', MAX( CASE WHEN sm.meta_value = \'outofstock\' THEN 1 ELSE 0 END ) AS out_of_stock';

			if ( 'hide' === $stock ) {
				$having_parts[] = 'out_of_stock = 0';
			} else {
				$order_prefix = 'out_of_stock ASC, ';
			}
		}

		// Price-intent filter: keep only products whose price range overlaps the
		// budget parsed from the query ("до 5000", "от 1000", "5000-10000"). Values
		// are floats, formatted inline (no placeholders). Non-products have no
		// lookup row, so a price filter naturally drops them from a shop query.
		if ( class_exists( 'WooCommerce' ) && ( null !== $price_min || null !== $price_max ) ) {
			$lookup     = $wpdb->prefix . 'wc_product_meta_lookup';
			$idf_join  .= " LEFT JOIN `$lookup` pml ON pml.product_id = i.object_id";
			$pml_joined = true;

			if ( null !== $price_min ) {
				$having_parts[] = 'MAX( COALESCE( pml.max_price, 0 ) ) >= ' . number_format( (float) $price_min, 2, '.', '' );
			}

			if ( null !== $price_max ) {
				$having_parts[] = 'MAX( COALESCE( pml.min_price, pml.max_price ) ) <= ' . number_format( (float) $price_max, 2, '.', '' );
			}
		}

		$having = empty( $having_parts ) ? '' : 'HAVING ' . implode( ' AND ', $having_parts );

		$exclude  = MVweb_SS_Settings::excluded_ids();
		$excl_sql = '';

		if ( ! empty( $exclude ) ) {
			$in_excl  = implode( ',', array_fill( 0, count( $exclude ), '%d' ) );
			$excl_sql = "AND i.object_id NOT IN ($in_excl)";
		}

		$neg_sql = '';

		if ( ! empty( $exclude_terms ) ) {
			$in_neg  = implode( ',', array_fill( 0, count( $exclude_terms ), '%s' ) );
			$neg_sql = "AND i.object_id NOT IN ( SELECT object_id FROM `$table` WHERE term IN ($in_neg) )";
		}

		// Self-learning click-boost: multiply the score by a log-damped, capped
		// factor of how often this result was clicked for this exact query. The
		// factor is 1.0 with no clicks, so it never crosses the coverage tier and
		// never reorders cold-start catalogs.
		// Ranking multipliers are applied in ORDER BY as raw expressions, never via
		// the SUM() alias: MySQL rejects an aggregate alias (`score`) used inside any
		// ORDER BY arithmetic, but raw aggregate functions (SUM, MAX) are allowed
		// there. So the ORDER BY repeats the score expression and multiplies the
		// capped click/bestseller factors onto it directly.
		$boost_join = '';
		$order_expr = 'SUM( ' . $score_sum . ' )';

		if ( '' !== $query_hash ) {
			$clicks_table = MVweb_SS_Schema::clicks_table_name();
			$strength     = (int) MVweb_SS_Settings::get( 'click_boost_strength', 30 );
			$alpha        = number_format( max( 0, min( 100, $strength ) ) / 100, 3, '.', '' );
			$cap          = '2.0';

			$boost_join  = "LEFT JOIN `$clicks_table` cb ON cb.object_id = i.object_id AND cb.query_hash = %s";
			$order_expr .= " * ( 1 + LEAST( $alpha * LN( 1 + MAX( COALESCE( cb.clicks, 0 ) ) ), $cap ) )";
		}

		// Bestseller signal: a log-damped, capped multiplier on total_sales pulled
		// straight from wc_product_meta_lookup (no aggregation). A cold product
		// scores ×1, so this stays strictly below the coverage tier and never
		// reshuffles a catalog with no sales history. Non-products have no lookup
		// row, so their factor is ×1 too. All literals inline — no placeholders.
		$pop_strength = (int) MVweb_SS_Settings::get( 'boost_popularity', 20 );

		if ( $pop_strength > 0 && class_exists( 'WooCommerce' ) ) {
			$beta    = number_format( max( 0, min( 100, $pop_strength ) ) / 100, 3, '.', '' );
			$pop_cap = '1.0';

			if ( ! $pml_joined ) {
				$lookup     = $wpdb->prefix . 'wc_product_meta_lookup';
				$idf_join  .= " LEFT JOIN `$lookup` pml ON pml.product_id = i.object_id";
				$pml_joined = true;
			}

			$order_expr .= " * ( 1 + LEAST( $beta * LN( 1 + MAX( COALESCE( pml.total_sales, 0 ) ) ), $pop_cap ) )";
		}

		$boost_order = '( ' . $order_expr . ' ) DESC';

		$sql = 'SELECT i.object_id, i.object_type, SUM( ' . $score_sum . " ) AS score, $coverage AS matched{$stock_select}
			FROM `$table` i
			$join
			$idf_join
			$boost_join
			WHERE i.term IN ($in_terms)
				AND i.object_id IN (
					SELECT ID FROM {$wpdb->posts}
					WHERE post_status = 'publish' AND post_password = '' AND post_type IN ($in_types)
				)
				$excl_sql
				$neg_sql
				$tax_sql
			GROUP BY i.object_id, i.object_type
			$having
			ORDER BY {$order_prefix}matched DESC, {$boost_order}, i.object_id DESC
			LIMIT %d";

		// Placeholder order mirrors the SQL string top-to-bottom: the coverage CASE
		// (SELECT) lists every term first, then the click-boost JOIN hash, then the
		// WHERE term/type lists and the remaining filters.
		$values = $terms;

		if ( '' !== $query_hash ) {
			$values[] = $query_hash;
		}

		$values = array_merge( $values, $terms, $types );

		if ( ! empty( $exclude ) ) {
			$values = array_merge( $values, $exclude );
		}

		if ( ! empty( $exclude_terms ) ) {
			$values = array_merge( $values, $exclude_terms );
		}

		if ( $tax_valid ) {
			$values[] = $taxonomy;
			$values   = array_merge( $values, $term_ids );
		}

		if ( $min_match > 1 ) {
			$values[] = min( $min_match, count( $groups ) );
		}

		$values[] = $limit;

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( ! is_array( $rows ) ) {
			return array();
		}

		return array_map(
			static function ( $row ) {
				return array(
					'object_id'   => (int) $row->object_id,
					'object_type' => (string) $row->object_type,
					'score'       => (float) $row->score,
					'matched'     => isset( $row->matched ) ? (int) $row->matched : 0,
				);
			},
			$rows
		);
	}

	/**
	 * Convenience: return only the ordered object IDs.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @param array  $args  See search().
	 * @return int[]
	 */
	public static function search_ids( string $query, array $args = array() ): array {
		return array_map(
			static function ( $result ) {
				return $result['object_id'];
			},
			self::search( $query, $args )
		);
	}

	/**
	 * Count matching objects per taxonomy term for the dropdown category groups.
	 *
	 * Instead of matching term names, this counts how many objects that actually
	 * satisfy the query (same strictness floor, synonyms and Boolean NOT as the
	 * result list) fall into each term. A term the query does not reach never
	 * appears, and its number is the matching count — not the term's total size.
	 *
	 * @since 1.1.2
	 * @param string   $query      Raw user query.
	 * @param string[] $taxonomies Taxonomies to aggregate over.
	 * @param int      $limit      Max terms, ordered by matching count.
	 * @return array<int,array{term_id:int,taxonomy:string,count:int}>
	 */
	public static function term_match_counts( string $query, array $taxonomies, int $limit ): array {
		global $wpdb;

		$taxonomies = array_values( array_unique( array_filter( array_map( 'strval', $taxonomies ) ) ) );

		if ( empty( $taxonomies ) || $limit < 1 ) {
			return array();
		}

		list( $clean_query, $neg_terms ) = self::split_negatives( $query );

		$terms = array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( $clean_query ) ) );

		if ( empty( $terms ) ) {
			return array();
		}

		$strictness   = (string) MVweb_SS_Settings::get( 'strictness', 'balanced' );
		$min_match    = self::min_match( $strictness, MVweb_SS_Tokenizer::word_count( $clean_query ) );
		$groups       = self::expand_groups( $terms, '', (bool) MVweb_SS_Settings::get( 'translit_cross_script', true ) );
		$search_terms = self::flatten_groups( $groups );
		$need         = (int) min( $min_match, count( $groups ) );

		$table   = MVweb_SS_Schema::table_name();
		$exclude = MVweb_SS_Settings::excluded_ids();

		$in_terms = implode( ',', array_fill( 0, count( $search_terms ), '%s' ) );
		$in_taxes = implode( ',', array_fill( 0, count( $taxonomies ), '%s' ) );

		$excl_sql = '';
		if ( ! empty( $exclude ) ) {
			$in_excl  = implode( ',', array_fill( 0, count( $exclude ), '%d' ) );
			$excl_sql = "AND i.object_id NOT IN ($in_excl)";
		}

		$neg_sql = '';
		if ( ! empty( $neg_terms ) ) {
			$in_neg  = implode( ',', array_fill( 0, count( $neg_terms ), '%s' ) );
			$neg_sql = "AND i.object_id NOT IN ( SELECT object_id FROM `$table` WHERE term IN ($in_neg) )";
		}

		$having = $need > 1 ? 'HAVING ' . self::coverage_case_sql( $groups ) . ' >= %d' : '';

		$sql = "SELECT tt.term_id AS term_id, tt.taxonomy AS taxonomy, COUNT( DISTINCT m.object_id ) AS cnt
			FROM {$wpdb->term_taxonomy} tt
			INNER JOIN {$wpdb->term_relationships} tr ON tr.term_taxonomy_id = tt.term_taxonomy_id
			INNER JOIN (
				SELECT i.object_id
				FROM `$table` i
				WHERE i.term IN ($in_terms)
					AND i.object_id IN (
						SELECT ID FROM {$wpdb->posts}
						WHERE post_status = 'publish' AND post_password = ''
					)
					$excl_sql
					$neg_sql
				GROUP BY i.object_id
				$having
			) m ON m.object_id = tr.object_id
			WHERE tt.taxonomy IN ($in_taxes)
			GROUP BY tt.term_id, tt.taxonomy
			ORDER BY cnt DESC, tt.term_id ASC
			LIMIT %d";

		$values = $search_terms;

		if ( ! empty( $exclude ) ) {
			$values = array_merge( $values, $exclude );
		}

		if ( ! empty( $neg_terms ) ) {
			$values = array_merge( $values, $neg_terms );
		}

		if ( $need > 1 ) {
			// The HAVING coverage CASE lists every term again, then the floor value.
			$values   = array_merge( $values, $search_terms );
			$values[] = $need;
		}

		$values   = array_merge( $values, $taxonomies );
		$values[] = $limit;

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( ! is_array( $rows ) ) {
			return array();
		}

		return array_map(
			static function ( $row ) {
				return array(
					'term_id'  => (int) $row->term_id,
					'taxonomy' => (string) $row->taxonomy,
					'count'    => (int) $row->cnt,
				);
			},
			$rows
		);
	}

	/**
	 * A term ID plus all of its descendant term IDs in a taxonomy.
	 *
	 * @since 1.0.0
	 * @param int    $term_id  Selected term ID.
	 * @param string $taxonomy Taxonomy slug.
	 * @return int[] Empty when the term or taxonomy is invalid.
	 */
	public static function term_and_children( int $term_id, string $taxonomy ): array {
		if ( $term_id <= 0 || '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
			return array();
		}

		if ( ! get_term( $term_id, $taxonomy ) instanceof WP_Term ) {
			return array();
		}

		$ids      = array( $term_id );
		$children = get_term_children( $term_id, $taxonomy );

		if ( is_array( $children ) ) {
			foreach ( $children as $child ) {
				$ids[] = (int) $child;
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Minimum number of query terms an object must match for the chosen strictness.
	 *
	 * Strict = all terms (AND); loose = any single term (OR); balanced = most
	 * of the terms (a coverage floor), which drops results that only share a
	 * word or two with a multi-word query.
	 *
	 * @since 1.0.4
	 * @param string $strictness 'loose', 'balanced' or 'strict'.
	 * @param int    $count      Number of query terms.
	 * @return int Floor between 1 and $count.
	 */
	private static function min_match( string $strictness, int $count ): int {
		if ( $count <= 1 ) {
			return 1;
		}

		switch ( $strictness ) {
			case 'strict':
				return $count;
			case 'loose':
				return 1;
			default:
				return (int) min( $count, max( 1, (int) ceil( $count * 0.7 ) ) );
		}
	}

	/**
	 * Resolve the out-of-stock handling mode.
	 *
	 * @since 1.0.0
	 * @return string 'show', 'hide' or 'demote'.
	 */
	private static function stock_mode(): string {
		$mode = (string) MVweb_SS_Settings::get( 'stock', 'show' );

		return in_array( $mode, array( 'hide', 'demote' ), true ) ? $mode : 'show';
	}

	/**
	 * SQL expression counting how many distinct coverage GROUPS an object matched,
	 * used both to order results and to enforce the strictness floor (HAVING).
	 *
	 * Each query term maps to its group's index; COUNT(DISTINCT group_index) then
	 * counts covered concepts, so a word and its synonym or transliteration score
	 * one coverage point, not two (P0.2). Term strings are bound as prepared
	 * placeholders (%s) in caller order; group indices are trusted integers.
	 *
	 * With the "match in product data, not description" option on, coverage counts
	 * only when the term appears in an identifying field (title, SKU, attributes,
	 * brand, categories, custom fields), never the marketing description — where a
	 * model number or a part word appears incidentally and would otherwise let an
	 * unrelated product satisfy an all-words query. The description still feeds the
	 * score, it just no longer alone clears the floor.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups Coverage groups (in flatten order).
	 * @return string
	 */
	private static function coverage_case_sql( array $groups ): string {
		$cases = '';

		foreach ( $groups as $gi => $group ) {
			$cases .= str_repeat( ' WHEN %s THEN ' . (int) $gi, count( $group ) );
		}

		$inner = 'CASE i.term' . $cases . ' END';

		if ( ! MVweb_SS_Settings::get( 'title_coverage', false ) ) {
			return "COUNT( DISTINCT $inner )";
		}

		return "COUNT( DISTINCT CASE WHEN i.source NOT IN ( 'content', 'excerpt' ) THEN ( $inner ) END )";
	}

	/**
	 * Total indexed document count for IDF, cached per request.
	 *
	 * @since 1.2.0
	 * @return int At least 1.
	 */
	private static function doc_count(): int {
		static $n = null;

		if ( null !== $n ) {
			return $n;
		}

		$meta = MVweb_SS_Schema::get_meta();
		$n    = isset( $meta['doc_count'] ) ? (int) $meta['doc_count'] : 0;

		if ( $n <= 0 ) {
			$n = MVweb_SS_Indexer::count_objects();
		}

		$n = max( 1, $n );

		return $n;
	}

	/**
	 * BM25-style term-frequency saturation as an SQL sub-expression.
	 *
	 * Replaces the raw term frequency (`i.count`) with tf·(k1+1)/(tf+k1) so a
	 * word repeated many times in one long field (keyword stuffing) can no
	 * longer outweigh a clean title match. tf = 1 yields 1.0, matching the old
	 * linear score for the common single-occurrence case. Float literals are
	 * formatted with an explicit dot (locale-independent).
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private static function tf_saturation(): string {
		$num = number_format( self::BM25_K1 + 1, 1, '.', '' );
		$den = number_format( self::BM25_K1, 1, '.', '' );

		return '( i.count * ' . $num . ' / ( i.count + ' . $den . ' ) )';
	}

	/**
	 * Build the SQL CASE expression that applies per-source weights.
	 *
	 * Source keys and weights are trusted plugin constants, sanitized before
	 * inlining (no user input reaches this expression). Term frequency is
	 * saturated (see tf_saturation()) so repetition has diminishing returns.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function weight_case(): string {
		$weights = wp_parse_args( (array) MVweb_SS_Settings::get( 'weights', array() ), self::$weights );
		$weights = apply_filters( 'mvweb_ss_field_weights', $weights );

		if ( ! is_array( $weights ) || empty( $weights ) ) {
			$weights = self::$weights;
		}

		$tf    = self::tf_saturation();
		$parts = array();

		foreach ( $weights as $source => $weight ) {
			$source  = preg_replace( '/[^a-z_]/', '', (string) $source );
			$parts[] = "WHEN '" . $source . "' THEN " . (int) $weight . ' * ' . $tf;
		}

		return 'CASE i.source ' . implode( ' ', $parts ) . ' ELSE ' . $tf . ' END';
	}
}
