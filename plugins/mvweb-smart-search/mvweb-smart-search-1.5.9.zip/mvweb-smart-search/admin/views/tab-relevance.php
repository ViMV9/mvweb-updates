<?php
/**
 * Relevance settings tab (weights, synonyms, stop words, exclude, pinning).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = MVweb_SS_Settings::all();
$option   = MVweb_SS_Settings::OPTION;
$defaults = MVweb_SS_Query::default_weights();
$weights  = wp_parse_args( (array) $settings['weights'], $defaults );

// One-click seed coming from an Analytics-tab action link: pre-fill a starter
// line in the matching textarea. Read-only prefill (nothing is saved until the
// admin reviews it and submits the Settings form, which carries its own nonce).
// phpcs:disable WordPress.Security.NonceVerification.Recommended
$seed_q    = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
$seed_q2   = isset( $_GET['q2'] ) ? sanitize_text_field( wp_unslash( $_GET['q2'] ) ) : '';
$seed_type = isset( $_GET['seed'] ) ? sanitize_key( wp_unslash( $_GET['seed'] ) ) : '';
// phpcs:enable WordPress.Security.NonceVerification.Recommended

// A closest-match hint from the no-result inbox arrives as q2 and seeds a ready pair.
$seed_syn = ( '' !== $seed_q && 'synonym' === $seed_type )
	? $seed_q . ( '' !== $seed_q2 ? ', ' . $seed_q2 : ', ' ) . "\n"
	: '';
$seed_red = ( '' !== $seed_q && 'redirect' === $seed_type ) ? $seed_q . ' => ' . "\n" : '';
$seed_pin = ( '' !== $seed_q && 'pin' === $seed_type ) ? $seed_q . ' => ' . "\n" : '';

$labels = array(
	'title'         => __( 'Title', 'mvweb-smart-search' ),
	'sku'           => __( 'SKU', 'mvweb-smart-search' ),
	'variation_sku' => __( 'Variation SKU', 'mvweb-smart-search' ),
	'gtin'          => __( 'GTIN / UPC / EAN', 'mvweb-smart-search' ),
	'attr'          => __( 'Attributes', 'mvweb-smart-search' ),
	'brand'         => __( 'Brand', 'mvweb-smart-search' ),
	'content'       => __( 'Content', 'mvweb-smart-search' ),
	'excerpt'       => __( 'Excerpt', 'mvweb-smart-search' ),
	'tax'           => __( 'Categories and tags', 'mvweb-smart-search' ),
	'cf'            => __( 'Custom fields', 'mvweb-smart-search' ),
);
?>

<?php if ( '' !== $seed_syn || '' !== $seed_red || '' !== $seed_pin ) : ?>
	<div class="mvweb-alert mvweb-alert--info">
		<?php
		printf(
			/* translators: %s: search query. */
			esc_html__( 'A starter line for "%s" was added below — complete it and click Save changes.', 'mvweb-smart-search' ),
			esc_html( $seed_q )
		);
		?>
	</div>
<?php endif; ?>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Field weights', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'How much a match in each field pushes a result up. Higher = more important; 0 = ignore this field.', 'mvweb-smart-search' ); ?></p>

	<?php foreach ( $defaults as $source => $default ) : ?>
		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-ss-weight-<?php echo esc_attr( $source ); ?>">
				<?php echo esc_html( isset( $labels[ $source ] ) ? $labels[ $source ] : $source ); ?>
			</label>
			<div class="mvweb-form-row__field mvweb-ss-slider">
				<input
					type="range"
					min="0"
					max="100"
					id="mvweb-ss-weight-<?php echo esc_attr( $source ); ?>"
					class="mvweb-ss-range"
					data-output="mvweb-ss-weight-<?php echo esc_attr( $source ); ?>-val"
					name="<?php echo esc_attr( $option ); ?>[weights][<?php echo esc_attr( $source ); ?>]"
					value="<?php echo esc_attr( (string) $weights[ $source ] ); ?>">
				<input
					type="number"
					min="0"
					max="100"
					step="1"
					id="mvweb-ss-weight-<?php echo esc_attr( $source ); ?>-val"
					class="mvweb-input mvweb-ss-range-num"
					aria-label="<?php echo esc_attr( isset( $labels[ $source ] ) ? $labels[ $source ] : $source ); ?>"
					value="<?php echo esc_attr( (string) $weights[ $source ] ); ?>">
			</div>
		</div>
	<?php endforeach; ?>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Ranking signals', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'How results are ordered beyond a plain field match. The recommended defaults suit most shops.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-idf"><?php esc_html_e( 'Weight rare, distinctive words', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-idf" name="<?php echo esc_attr( $option ); ?>[ranking_use_idf]" value="1" <?php checked( ! empty( $settings['ranking_use_idf'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'A rare word (a model, a part) counts for more than a word that appears in almost every product, so a common word can no longer drag unrelated items to the top. Recommended.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-doclen"><?php esc_html_e( 'Normalize by field length', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-doclen" name="<?php echo esc_attr( $option ); ?>[ranking_doclen]" value="1" <?php checked( ! empty( $settings['ranking_doclen'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'A matching word in a long description counts for less than the same word in a short title, so a full product (a phone whose specs mention "battery") no longer outranks the actual part ("Battery for …"). On by default — run a full reindex once so the field-length data it needs is available.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-exact"><?php esc_html_e( 'Exact title / SKU match boost', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-ss-slider">
				<input type="range" min="1" max="20" step="0.5" id="mvweb-ss-exact" class="mvweb-ss-range" data-output="mvweb-ss-exact-val" name="<?php echo esc_attr( $option ); ?>[exact_match_boost]" value="<?php echo esc_attr( (string) $settings['exact_match_boost'] ); ?>">
				<input type="number" min="1" max="20" step="0.5" id="mvweb-ss-exact-val" class="mvweb-input mvweb-ss-range-num" aria-label="<?php esc_attr_e( 'Exact match boost', 'mvweb-smart-search' ); ?>" value="<?php echo esc_attr( (string) $settings['exact_match_boost'] ); ?>">
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'A product whose name or SKU is exactly the query jumps to the top. 1 = off.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-proximity"><?php esc_html_e( 'Phrase proximity', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-proximity" name="<?php echo esc_attr( $option ); ?>[boost_proximity]" value="1" <?php checked( ! empty( $settings['boost_proximity'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Among equally relevant matches, prefers a title that contains the words as a phrase or in order over one where they are scattered. Off by default — enable and compare on your catalog.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-head"><?php esc_html_e( 'Product type first', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-head" name="<?php echo esc_attr( $option ); ?>[boost_head]" value="1" <?php checked( ! empty( $settings['boost_head'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Among equally relevant matches, prefers a product whose title STARTS with what was searched for. A search for "battery" then ranks "Battery iPhone 13" above "Battery adhesive iPhone 13". Synonyms count, so "screen" also recognizes a title starting with "LCD". Suits catalogs named "type first, model after"; if your titles start with a brand or an article number, nothing changes. Off by default.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<?php if ( class_exists( 'WooCommerce' ) ) : ?>
	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-pop"><?php esc_html_e( 'Bestseller boost', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-ss-slider">
				<input type="range" min="0" max="100" step="1" id="mvweb-ss-pop" class="mvweb-ss-range" data-output="mvweb-ss-pop-val" name="<?php echo esc_attr( $option ); ?>[boost_popularity]" value="<?php echo esc_attr( (string) $settings['boost_popularity'] ); ?>">
				<input type="number" min="0" max="100" step="1" id="mvweb-ss-pop-val" class="mvweb-input mvweb-ss-range-num" aria-label="<?php esc_attr_e( 'Bestseller boost', 'mvweb-smart-search' ); ?>" value="<?php echo esc_attr( (string) $settings['boost_popularity'] ); ?>">
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Gently lifts better-selling products among equally relevant matches. Capped, so it never outranks a clearly better match. 0 = off.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-zero-fallback"><?php esc_html_e( 'Show bestsellers on no results', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-zero-fallback" name="<?php echo esc_attr( $option ); ?>[zero_fallback_bestsellers]" value="1" <?php checked( ! empty( $settings['zero_fallback_bestsellers'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'When a query matches nothing, the dropdown offers best-selling products instead of an empty result, so the shopper keeps a way forward. Recommended.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
	<?php endif; ?>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Russian out of the box', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Matching helpers tuned for Russian-language shops. All on by default.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Built-in synonyms and brand spellings', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" name="<?php echo esc_attr( $option ); ?>[default_synonyms]" value="1" <?php checked( ! empty( $settings['default_synonyms'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Common equivalences (батарея / аккумулятор / АКБ, дисплей / экран) and brand spellings (айфон / iPhone, сяоми / Xiaomi) work with no setup. Each group only fires when the query uses one of its words, so it never affects an unrelated catalog. Your own synonyms below are added on top.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Cross-script transliteration', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" name="<?php echo esc_attr( $option ); ?>[translit_cross_script]" value="1" <?php checked( ! empty( $settings['translit_cross_script'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'A query typed in one script reaches products written in the other (samsung ↔ самсунг). Query-side only — the index is not enlarged.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Index single-character models', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" name="<?php echo esc_attr( $option ); ?>[index_single_char_models]" value="1" <?php checked( ! empty( $settings['index_single_char_models'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Keeps a lone digit searchable (e.g. the "5" in "iPhone 5"), which a two-character minimum would otherwise drop. Reindex after changing.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Split model codes', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" name="<?php echo esc_attr( $option ); ?>[normalize_models]" value="1" <?php checked( ! empty( $settings['normalize_models'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Makes a glued code searchable by any part: "gtx1660" also matches "gtx" and "1660", "4000mah" matches "4000" and "mah". Useful for electronics and parts; turn off for catalogs where size codes are noise (apparel). Reindex after changing.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Model number is mandatory', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" name="<?php echo esc_attr( $option ); ?>[model_required]" value="1" <?php checked( ! empty( $settings['model_required'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'A word carrying a digit has to match — the strictness setting cannot trade it away. Without it "iphone 16 pro max lcd" answers with iPhone 13 screens, because the other four words already clear the floor. A glued code is looked for whole first ("g980" reaches "g980f"); only if nothing carries it whole does it fall back to its parts, and then all of them are required, so "note13" means note and 13 rather than note or 13. Turn off for catalogs where neighbouring models are a welcome suggestion.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Keep only the named product type', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" name="<?php echo esc_attr( $option ); ?>[type_filter]" value="1" <?php checked( ! empty( $settings['type_filter'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'When a query names what the product is — “display”, “battery”, “case” — results that merely fit the same device are dropped. A parts catalogue writes what a product is first and what it fits second, so the first word of the title answers it: a search for a display stops returning flex cables and SIM trays for that phone, and “display frame” no longer counts as a display. Applies only when some result does lead with a word from the query, and stands down when it would leave the page nearly empty, so a catalogue writing “iPhone 14 display” instead keeps working.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Learn from clicks', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Gently float the results shoppers actually click for a query. It only nudges results that already match and never reorders a fresh catalog, so leave it off until you have collected some search traffic.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-click-boost"><?php esc_html_e( 'Click-based boost', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-click-boost" name="<?php echo esc_attr( $option ); ?>[click_boost]" value="1" <?php checked( ! empty( $settings['click_boost'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Off by default. Turn on once the search log has enough clicks to learn from.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-click-boost-strength"><?php esc_html_e( 'Boost strength', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-ss-slider">
				<input
					type="range"
					min="0"
					max="100"
					id="mvweb-ss-click-boost-strength"
					class="mvweb-ss-range"
					data-output="mvweb-ss-click-boost-strength-val"
					name="<?php echo esc_attr( $option ); ?>[click_boost_strength]"
					value="<?php echo esc_attr( (string) $settings['click_boost_strength'] ); ?>">
				<input
					type="number"
					min="0"
					max="100"
					step="1"
					id="mvweb-ss-click-boost-strength-val"
					class="mvweb-input mvweb-ss-range-num"
					aria-label="<?php esc_attr_e( 'Boost strength', 'mvweb-smart-search' ); ?>"
					value="<?php echo esc_attr( (string) $settings['click_boost_strength'] ); ?>">
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( '0 = no effect, 100 = strongest. The boost is capped so a popular result can never jump above better-matching ones.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Ready-made dictionaries', 'mvweb-smart-search' ); ?></h2>
		<button type="button" class="mvweb-btn" id="mvweb-ss-dict-refresh"><?php esc_html_e( 'Check for updates', 'mvweb-smart-search' ); ?></button>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Curated synonym packs by MVweb. Install to improve matching for brands, electronics parts and adhesives — updating is one click. Your own synonyms below stay untouched. The list refreshes twice a day on its own; "Check for updates" asks for it right away and reloads the page, so save your changes first.', 'mvweb-smart-search' ); ?></p>

	<?php $mvweb_ss_packs = MVweb_SS_Dictionaries::available(); ?>

	<?php if ( empty( $mvweb_ss_packs ) ) : ?>
		<div class="mvweb-alert mvweb-alert--info"><?php esc_html_e( 'The dictionary list is unavailable right now. Try again later.', 'mvweb-smart-search' ); ?></div>
	<?php else : ?>
		<div class="mvweb-ss-dicts">
			<?php foreach ( $mvweb_ss_packs as $mvweb_ss_pack ) : ?>
				<?php $mvweb_ss_is_installed = '' !== $mvweb_ss_pack['installed']; ?>
				<div class="mvweb-ss-dict" data-slug="<?php echo esc_attr( $mvweb_ss_pack['slug'] ); ?>" data-installed="<?php echo esc_attr( $mvweb_ss_pack['installed'] ); ?>">
					<div class="mvweb-ss-dict__info">
						<div class="mvweb-ss-dict__title">
							<strong><?php echo esc_html( $mvweb_ss_pack['name'] ); ?></strong>
							<span class="mvweb-badge mvweb-ss-dict__version"<?php echo $mvweb_ss_is_installed ? '' : ' hidden'; ?>><?php echo esc_html( $mvweb_ss_is_installed ? 'v' . $mvweb_ss_pack['installed'] : '' ); ?></span>
							<span class="mvweb-badge mvweb-badge--warning mvweb-ss-dict__update-badge"<?php echo $mvweb_ss_pack['update'] ? '' : ' hidden'; ?>><?php esc_html_e( 'Update available', 'mvweb-smart-search' ); ?></span>
						</div>
						<?php if ( '' !== $mvweb_ss_pack['description'] ) : ?>
							<span class="mvweb-block__sub"><?php echo esc_html( $mvweb_ss_pack['description'] ); ?></span>
						<?php endif; ?>
					</div>
					<div class="mvweb-ss-dict__actions">
						<?php if ( ! $mvweb_ss_is_installed ) : ?>
							<button type="button" class="mvweb-btn mvweb-btn--primary mvweb-ss-dict-action" data-action="install"><?php esc_html_e( 'Install', 'mvweb-smart-search' ); ?></button>
						<?php elseif ( $mvweb_ss_pack['update'] ) : ?>
							<button type="button" class="mvweb-btn mvweb-btn--primary mvweb-ss-dict-action" data-action="install"><?php esc_html_e( 'Update', 'mvweb-smart-search' ); ?></button>
							<button type="button" class="mvweb-btn mvweb-ss-dict-action" data-action="remove"><?php esc_html_e( 'Remove', 'mvweb-smart-search' ); ?></button>
						<?php else : ?>
							<span class="mvweb-ss-dict__state"><?php esc_html_e( 'Installed', 'mvweb-smart-search' ); ?></span>
							<button type="button" class="mvweb-btn mvweb-ss-dict-action" data-action="remove"><?php esc_html_e( 'Remove', 'mvweb-smart-search' ); ?></button>
						<?php endif; ?>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<p id="mvweb-ss-dict-status" class="mvweb-block__sub" aria-live="polite"></p>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Synonyms', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'A group of equivalent words on one line, comma-separated. Searching for any word in the group matches all of them. Multi-word entries work too. Example: phone, smartphone, mobile.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-synonyms"><?php esc_html_e( 'Synonym groups', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="mvweb-ss-synonyms" class="mvweb-textarea" rows="4" name="<?php echo esc_attr( $option ); ?>[synonyms]" placeholder="phone, smartphone, mobile&#10;jacket, windbreaker"><?php echo esc_textarea( $seed_syn . (string) $settings['synonyms'] ); ?></textarea>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Stop words', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Words ignored in the query and during indexing, one per line. Common prepositions and conjunctions are already included.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-stopwords"><?php esc_html_e( 'Stop words', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="mvweb-ss-stopwords" class="mvweb-textarea" rows="4" name="<?php echo esc_attr( $option ); ?>[stopwords]" placeholder="buy&#10;price"><?php echo esc_textarea( (string) $settings['stopwords'] ); ?></textarea>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Exclude from search', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'IDs of posts or products that should not appear in results. Comma-separated or one per line.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-exclude"><?php esc_html_e( 'Excluded IDs', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="mvweb-ss-exclude" class="mvweb-textarea" rows="3" name="<?php echo esc_attr( $option ); ?>[exclude_ids]" placeholder="128, 340"><?php echo esc_textarea( implode( ', ', (array) $settings['exclude_ids'] ) ); ?></textarea>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Pinned results', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Move specific items to the top of results for an exact query. Line format: query => ID, ID. Example: iphone => 512, 530.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-pins"><?php esc_html_e( 'Pinning rules', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="mvweb-ss-pins" class="mvweb-textarea" rows="4" name="<?php echo esc_attr( $option ); ?>[pins]" placeholder="iphone => 512, 530&#10;laptop => 741"><?php echo esc_textarea( $seed_pin . (string) $settings['pins'] ); ?></textarea>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Search redirects', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Send an exact query straight to a URL instead of the results page. Line format: query => URL. Example: contacts => /contact-us/.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-redirects"><?php esc_html_e( 'Redirect rules', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="mvweb-ss-redirects" class="mvweb-textarea" rows="4" name="<?php echo esc_attr( $option ); ?>[redirects]" placeholder="contacts =&gt; /contact-us/&#10;sale =&gt; /shop/?on_sale=1"><?php echo esc_textarea( $seed_red . (string) $settings['redirects'] ); ?></textarea>
		</div>
	</div>
</section>
