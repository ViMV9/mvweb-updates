<?php
/**
 * Background full reindex (batched, cursor-based, lock-guarded).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Rebuilds the whole index in ascending-ID batches without a search gap
 * (each object is upserted individually via the indexer).
 *
 * @since 1.0.0
 */
class MVweb_SS_Reindex {

	const STATE_OPTION = 'mvweb_ss_reindex_state';

	const LOCK_TRANSIENT = 'mvweb_ss_reindex_lock';

	const BATCH = 50;

	const LOCK_TTL = 900;

	const NONCE = 'mvweb_ss_admin';

	const CRON_EVENT = 'mvweb_ss_scheduled_reindex';

	const DRAIN_EVENT = 'mvweb_ss_reindex_drain';

	const DRAIN_BUDGET = 20.0;

	const BROWSER_LEASE = 'mvweb_ss_reindex_browser';

	const BROWSER_LEASE_TTL = 30;

	/**
	 * Register the reindex AJAX endpoints, WP-CLI command and scheduled reindex.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'wp_ajax_mvweb_ss_reindex_start', array( __CLASS__, 'ajax_start' ) );
		add_action( 'wp_ajax_mvweb_ss_reindex_step', array( __CLASS__, 'ajax_step' ) );
		add_action( 'wp_ajax_mvweb_ss_reindex_status', array( __CLASS__, 'ajax_status' ) );

		add_filter( 'cron_schedules', array( __CLASS__, 'cron_schedules' ) );
		add_action( 'init', array( __CLASS__, 'sync_schedule' ) );
		add_action( 'update_option_' . MVweb_SS_Settings::OPTION, array( __CLASS__, 'sync_schedule' ) );
		add_action( self::CRON_EVENT, array( __CLASS__, 'cron_full_reindex' ) );
		add_action( self::DRAIN_EVENT, array( __CLASS__, 'cron_drain' ) );

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			\WP_CLI::add_command( 'mvweb-ss reindex', array( __CLASS__, 'cli_reindex' ) );
		}
	}

	/**
	 * Add the weekly / monthly recurrences the scheduled reindex offers (WordPress
	 * ships only hourly / twicedaily / daily).
	 *
	 * @since 1.2.0
	 * @param array<string,array{interval:int,display:string}> $schedules Existing schedules.
	 * @return array<string,array{interval:int,display:string}>
	 */
	public static function cron_schedules( $schedules ) {
		if ( ! isset( $schedules['weekly'] ) ) {
			$schedules['weekly'] = array(
				'interval' => WEEK_IN_SECONDS,
				'display'  => __( 'Once a week', 'mvweb-smart-search' ),
			);
		}

		if ( ! isset( $schedules['mvweb_ss_monthly'] ) ) {
			$schedules['mvweb_ss_monthly'] = array(
				'interval' => MONTH_IN_SECONDS,
				'display'  => __( 'Once a month', 'mvweb-smart-search' ),
			);
		}

		return $schedules;
	}

	/**
	 * Schedule, reschedule or clear the recurring full reindex to match settings.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function sync_schedule(): void {
		$interval = (string) MVweb_SS_Settings::get( 'scheduled_reindex', 'off' );
		$map      = array(
			'weekly'  => 'weekly',
			'monthly' => 'mvweb_ss_monthly',
		);
		$current  = wp_get_schedule( self::CRON_EVENT );

		if ( ! isset( $map[ $interval ] ) ) {
			if ( $current ) {
				self::clear_event( self::CRON_EVENT );
			}
			return;
		}

		$recurrence = $map[ $interval ];

		if ( $current && $current !== $recurrence ) {
			self::clear_event( self::CRON_EVENT );
			$current = false;
		}

		if ( ! $current ) {
			wp_schedule_event( time() + DAY_IN_SECONDS, $recurrence, self::CRON_EVENT );
		}
	}

	/**
	 * Remove every instance of a scheduled event.
	 *
	 * @since 1.2.0
	 * @param string $hook Event hook.
	 * @return void
	 */
	private static function clear_event( string $hook ): void {
		$timestamp = wp_next_scheduled( $hook );

		while ( $timestamp ) {
			wp_unschedule_event( $timestamp, $hook );
			$timestamp = wp_next_scheduled( $hook );
		}
	}

	/**
	 * Clear both the recurring reindex and any pending drain (deactivation/uninstall).
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function unschedule_all(): void {
		self::clear_event( self::CRON_EVENT );
		self::clear_event( self::DRAIN_EVENT );
	}

	/**
	 * Recurring trigger: prime a full reindex and hand it to the drain loop.
	 *
	 * Skips silently if a reindex (manual or a previous scheduled one) is still
	 * running, so overlapping runs never pile up.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function cron_full_reindex(): void {
		if ( 'off' === (string) MVweb_SS_Settings::get( 'scheduled_reindex', 'off' ) ) {
			return;
		}

		if ( ! self::start() ) {
			return;
		}

		self::cron_drain();
	}

	/**
	 * Drain reindex batches under a time budget, then reschedule itself a minute
	 * out until the run finishes — keeping each cron tick short on a large catalog.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function cron_drain(): void {
		if ( ! self::is_running() ) {
			return;
		}

		// Yield to an admin who is actively driving the reindex from the browser
		// (each ajax_step renews a short lease). Two drainers sharing one cursor
		// double the work and make the browser loop stall on lock contention, so
		// only one drives at a time: the browser while its tab is open, the cron
		// once the lease lapses (tab closed / navigated away).
		if ( get_transient( self::BROWSER_LEASE ) ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, self::DRAIN_EVENT );
			return;
		}

		$started = microtime( true );

		do {
			$status = self::process_batch();
		} while ( 'running' === $status && ( microtime( true ) - $started ) < self::DRAIN_BUDGET );

		if ( 'running' === $status ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, self::DRAIN_EVENT );
		}
	}

	/**
	 * Begin a full reindex by priming the cursor state. Batches are then
	 * processed one at a time via process_batch() (browser loop or WP-CLI).
	 *
	 * @since 1.0.0
	 * @return bool False if a reindex is already running.
	 */
	public static function start(): bool {
		if ( self::is_running() ) {
			return false;
		}

		global $wpdb;

		set_transient( self::LOCK_TRANSIENT, time(), self::LOCK_TTL );

		$types = MVweb_SS_Indexer::get_indexed_post_types();
		$in    = implode( ',', array_fill( 0, count( $types ), '%s' ) );

		$max_id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(ID) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ($in)", $types ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders
		$total  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(ID) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ($in)", $types ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		update_option(
			self::STATE_OPTION,
			array(
				'max_id'    => $max_id,
				'cursor'    => 0,
				'total'     => $total,
				'processed' => 0,
			),
			false
		);

		return true;
	}

	/**
	 * Start a full reindex in the background: prime the cursor, then hand the batches
	 * to the self-draining cron loop. Non-blocking — the caller returns at once, and
	 * the drain runs on the next cron tick. No-op if a reindex is already running.
	 *
	 * @since 1.5.0
	 * @return void
	 */
	public static function start_background(): void {
		if ( self::start() ) {
			wp_schedule_single_event( time(), self::DRAIN_EVENT );
		}
	}

	/**
	 * Process a single batch. Returns 'running', 'done' or 'idle'.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function process_batch(): string {
		global $wpdb;

		$state = get_option( self::STATE_OPTION );

		if ( ! is_array( $state ) ) {
			return 'idle';
		}

		// A bulk pass defers per-object df deltas; rebuild_stats() recomputes them
		// in one GROUP BY at the end. This static resets each request, so set it on
		// every batch (the browser loop runs each batch in a fresh request).
		MVweb_SS_Indexer::defer_stats( true );

		$types = MVweb_SS_Indexer::get_indexed_post_types();
		$in    = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		$args  = array_merge( $types, array( (int) $state['cursor'], (int) $state['max_id'], self::BATCH ) );

		$ids = $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ($in) AND ID > %d AND ID <= %d ORDER BY ID ASC LIMIT %d", $args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( empty( $ids ) ) {
			self::finish();
			return 'done';
		}

		foreach ( $ids as $id ) {
			MVweb_SS_Indexer::index_object( (int) $id );
			$state['cursor'] = (int) $id;
			++$state['processed'];
		}

		update_option( self::STATE_OPTION, $state, false );

		if ( (int) $state['cursor'] >= (int) $state['max_id'] ) {
			self::finish();
			return 'done';
		}

		set_transient( self::LOCK_TRANSIENT, time(), self::LOCK_TTL );

		return 'running';
	}

	/**
	 * Finalize a completed reindex.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function finish(): void {
		// Deferred df deltas are recomputed here in one pass over the finished index.
		MVweb_SS_Indexer::rebuild_stats();

		// Clear the defer flag so a later single edit in the SAME process (WP-CLI
		// runs every batch in one process) resumes incremental df maintenance.
		MVweb_SS_Indexer::defer_stats( false );

		// What the admin screen shows is how many objects the index holds, not how
		// many IDs the run walked over: an object excluded from search (per-post
		// checkbox, password, WooCommerce visibility) is scanned and then removed,
		// and counting it would overstate the index by the number of exclusions.
		$meta                 = MVweb_SS_Schema::get_meta();
		$meta['last_reindex'] = time();
		$meta['indexed']      = MVweb_SS_Indexer::count_objects();
		MVweb_SS_Schema::update_meta( $meta );

		delete_option( self::STATE_OPTION );
		delete_transient( self::LOCK_TRANSIENT );
		delete_transient( self::BROWSER_LEASE );

		MVweb_SS_Rest::flush_cache();
	}

	/**
	 * Cancel a running reindex.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function cancel(): void {
		MVweb_SS_Indexer::defer_stats( false );
		delete_option( self::STATE_OPTION );
		delete_transient( self::LOCK_TRANSIENT );
		delete_transient( self::BROWSER_LEASE );
	}

	/**
	 * Whether a reindex is currently locked/running.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function is_running(): bool {
		return (bool) get_transient( self::LOCK_TRANSIENT );
	}

	/**
	 * Current progress snapshot for the admin UI.
	 *
	 * @since 1.0.0
	 * @param bool $with_count Include the live index count (a COUNT DISTINCT
	 *                         over the index table). Skipped mid-run so the
	 *                         browser-driven loop doesn't scan the table on
	 *                         every batch — the running UI shows processed/total.
	 * @return array
	 */
	public static function get_progress( bool $with_count = true ): array {
		$state = get_option( self::STATE_OPTION );
		$meta  = MVweb_SS_Schema::get_meta();

		$progress = array(
			'running'      => self::is_running(),
			'total'        => is_array( $state ) ? (int) $state['total'] : 0,
			'processed'    => is_array( $state ) ? (int) $state['processed'] : 0,
			'last_reindex' => isset( $meta['last_reindex'] ) ? (int) $meta['last_reindex'] : 0,
			'indexed'      => isset( $meta['indexed'] ) ? (int) $meta['indexed'] : 0,
		);

		if ( $with_count ) {
			$progress['in_index'] = MVweb_SS_Indexer::count_objects();
		}

		return $progress;
	}

	/**
	 * AJAX: start a reindex.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_start(): void {
		self::verify_admin_request();

		// Prime the state only; the browser drives batches via ajax_step. This
		// keeps progress moving on hosts where WP-Cron/Action Scheduler is not
		// triggered reliably, and throttles work to one batch per request. start()
		// returns false when a background reindex is already running (e.g. the one
		// primed right after a schema upgrade) — the browser then simply adopts
		// that run and drives it to completion via ajax_step.
		$started = self::start();

		// Claim the browser lease so the cron drain yields and does not double-drive.
		set_transient( self::BROWSER_LEASE, time(), self::BROWSER_LEASE_TTL );

		// Safety net for a run the browser abandons (tab closed mid-way): the drain
		// yields while the lease is alive, so this changes nothing for a run that
		// finishes in the tab, but a stalled one is picked up instead of leaving the
		// index written and its statistics never rebuilt.
		if ( ! wp_next_scheduled( self::DRAIN_EVENT ) ) {
			wp_schedule_single_event( time() + MINUTE_IN_SECONDS, self::DRAIN_EVENT );
		}

		wp_send_json_success(
			array_merge( self::get_progress(), array( 'started' => $started ) )
		);
	}

	/**
	 * AJAX: process one batch (browser-driven reindex loop).
	 *
	 * @since 1.0.3
	 * @return void
	 */
	public static function ajax_step(): void {
		self::verify_admin_request();

		// Renew the browser lease so the cron drain keeps yielding while this tab
		// drives the loop; it lapses shortly after the tab stops stepping.
		set_transient( self::BROWSER_LEASE, time(), self::BROWSER_LEASE_TTL );

		$status = self::process_batch();

		// Compute the live count only when the run stops (done/idle), not on
		// every batch — the running UI reports progress via processed/total.
		wp_send_json_success(
			array_merge( self::get_progress( 'running' !== $status ), array( 'status' => $status ) )
		);
	}

	/**
	 * AJAX: poll reindex progress.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_status(): void {
		self::verify_admin_request();

		wp_send_json_success( self::get_progress() );
	}

	/**
	 * Shared nonce + capability check for admin AJAX endpoints.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function verify_admin_request(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mvweb-smart-search' ) ), 403 );
		}

		check_ajax_referer( self::NONCE, 'nonce' );
	}

	/**
	 * WP-CLI: rebuild the whole index synchronously.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-ss reindex
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function cli_reindex(): void {
		self::cancel();

		if ( ! self::start() ) {
			\WP_CLI::error( 'Could not start: a reindex is already running.' );
			return;
		}

		do {
			$status = self::process_batch();
		} while ( 'running' === $status );

		$progress = self::get_progress();
		\WP_CLI::success( sprintf( 'Reindex complete: %d objects.', (int) $progress['indexed'] ) );
	}
}
