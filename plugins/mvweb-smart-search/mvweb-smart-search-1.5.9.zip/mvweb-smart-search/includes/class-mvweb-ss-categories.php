<?php
/**
 * Matching taxonomy terms (e.g. product categories) for the dropdown.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Finds public taxonomy terms whose name matches the query (morphology-aware)
 * and returns them as a separate "Categories" group above the results.
 *
 * @since 1.0.0
 */
class MVweb_SS_Categories {

	const LIMIT = 5;

	const CACHE_TTL = 300;

	/**
	 * Categories with products matching the query, most matches first.
	 *
	 * Whether a group is wanted at all is the caller's business: the dropdown
	 * reads its own "Matching categories" setting, the results-page panel reads
	 * which filters it was told to show. Deciding that here would tie the two
	 * screens together, and turning the group off in the dropdown would silently
	 * take the filter off the results page with it.
	 *
	 * @since 1.0.0
	 * @param string     $query      Raw user query.
	 * @param int        $limit      Max categories (0 = the configured default).
	 * @param int[]|null $object_ids Count within this result pool instead of re-running
	 *                               the search (results-page facets). Null = no pool;
	 *                               an empty array is a pool that matched nothing.
	 * @return array<int,array{name:string,url:string,term_id:int,taxonomy:string,count:int,context:string}>
	 */
	public static function search( string $query, int $limit = 0, ?array $object_ids = null ): array {
		return self::match_terms( $query, self::taxonomies(), self::resolve_limit( $limit ), $object_ids );
	}

	/**
	 * Brand terms with products matching the query, as a separate dropdown group.
	 *
	 * Gated by the caller, like search() above.
	 *
	 * @since 1.1.0
	 * @param string     $query      Raw user query.
	 * @param int        $limit      Max brands (0 = the configured default).
	 * @param int[]|null $object_ids Count within this result pool instead of re-running
	 *                               the search (results-page facets). Null = no pool;
	 *                               an empty array is a pool that matched nothing.
	 * @return array<int,array{name:string,url:string,term_id:int,taxonomy:string,count:int,context:string}>
	 */
	public static function brands( string $query, int $limit = 0, ?array $object_ids = null ): array {
		return self::match_terms( $query, self::brand_taxonomies(), self::resolve_limit( $limit ), $object_ids );
	}

	/**
	 * Resolve the max number of terms per group from the caller or the setting.
	 *
	 * @since 1.1.2
	 * @param int $limit Explicit limit, or 0 to use the configured maximum.
	 * @return int
	 */
	private static function resolve_limit( int $limit ): int {
		if ( $limit > 0 ) {
			return $limit;
		}

		$configured = (int) MVweb_SS_Settings::get( 'cat_limit', self::LIMIT );

		return $configured > 0 ? $configured : self::LIMIT;
	}

	/**
	 * Terms of the given taxonomies that hold products matching the query.
	 *
	 * @since 1.1.0
	 * @param string     $query      Raw user query.
	 * @param string[]   $taxonomies Taxonomies to search.
	 * @param int        $limit      Max terms.
	 * @param int[]|null $object_ids Count within this pool instead of re-running the
	 *                               search. Null = no pool; empty array = empty pool.
	 * @return array<int,array{name:string,url:string,term_id:int,taxonomy:string,count:int,context:string}>
	 */
	private static function match_terms( string $query, array $taxonomies, int $limit, ?array $object_ids = null ): array {
		if ( empty( $taxonomies ) ) {
			return array();
		}

		$version    = (int) get_option( 'mvweb_ss_cache_version', 1 );
		$strictness = (string) MVweb_SS_Settings::get( 'strictness', 'balanced' );
		$normalized = mb_strtolower( trim( $query ), 'UTF-8' );
		// Sorted, so a re-ordered pool (the shopper switched the sort) reuses the
		// same cached counts instead of seeding a second transient. A pool that
		// matched nothing is still a pool — it keys as "empty", never as "absent",
		// or the counters would fall back to the query and contradict the page.
		$sorted = null === $object_ids ? null : array_map( 'intval', $object_ids );

		if ( is_array( $sorted ) ) {
			sort( $sorted );
		}

		$pool      = null === $sorted ? '' : 'pool:' . md5( implode( ',', $sorted ) );
		$cache_key = 'mvweb_ss_cat_' . md5( $version . '|' . $normalized . '|' . implode( ',', $taxonomies ) . '|' . $limit . '|' . $strictness . '|' . $pool );
		$cached    = get_transient( $cache_key );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		$counts = null === $object_ids
			? MVweb_SS_Query::term_match_counts( $query, $taxonomies, $limit )
			: MVweb_SS_Query::term_counts_for_ids( $object_ids, $taxonomies, $limit );

		$out = array();

		foreach ( $counts as $entry ) {
			$term = get_term( $entry['term_id'], $entry['taxonomy'] );

			if ( ! $term instanceof WP_Term ) {
				continue;
			}

			$link = get_term_link( $term );

			if ( is_wp_error( $link ) ) {
				continue;
			}

			$out[] = array(
				'name'     => html_entity_decode( wp_strip_all_tags( $term->name ), ENT_QUOTES ),
				'url'      => esc_url_raw( (string) $link ),
				'term_id'  => (int) $entry['term_id'],
				'taxonomy' => (string) $entry['taxonomy'],
				'count'    => (int) $entry['count'],
				'context'  => self::context_label( $term ),
			);
		}

		set_transient( $cache_key, $out, self::CACHE_TTL );

		return $out;
	}

	/**
	 * Taxonomies searched for categories.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	private static function taxonomies(): array {
		$default = class_exists( 'WooCommerce' ) ? array( 'product_cat' ) : array( 'category' );

		/**
		 * Filter the taxonomies shown as categories in the dropdown.
		 *
		 * @since 1.0.0
		 * @param string[] $taxonomies Taxonomy slugs.
		 */
		$taxonomies = (array) apply_filters( 'mvweb_ss_category_taxonomies', $default );

		return array_values(
			array_filter(
				$taxonomies,
				static function ( $taxonomy ) {
					return taxonomy_exists( $taxonomy ) && is_taxonomy_viewable( $taxonomy );
				}
			)
		);
	}

	/**
	 * Brand taxonomies searched for the Brands group (shared with the indexer).
	 *
	 * @since 1.1.0
	 * @return string[]
	 */
	private static function brand_taxonomies(): array {
		/** This filter is documented in includes/class-mvweb-ss-indexer.php */
		$taxonomies = (array) apply_filters(
			'mvweb_ss_brand_taxonomies',
			array( 'product_brand', 'pwb-brand', 'yith_product_brand', 'berocket_brand' )
		);

		return array_values(
			array_filter(
				$taxonomies,
				static function ( $taxonomy ) {
					return taxonomy_exists( $taxonomy ) && is_taxonomy_viewable( $taxonomy );
				}
			)
		);
	}

	/**
	 * Primary (first available) category taxonomy for the results-page facet.
	 *
	 * @since 1.2.0
	 * @return string Taxonomy slug, or '' when none is registered.
	 */
	public static function facet_category_taxonomy(): string {
		$taxes = self::taxonomies();

		return empty( $taxes ) ? '' : (string) reset( $taxes );
	}

	/**
	 * Primary (first available) brand taxonomy for the results-page facet.
	 *
	 * @since 1.2.0
	 * @return string Taxonomy slug, or '' when none is registered.
	 */
	public static function facet_brand_taxonomy(): string {
		$taxes = self::brand_taxonomies();

		return empty( $taxes ) ? '' : (string) reset( $taxes );
	}

	/**
	 * Sub-label for a term: its parent name, or the taxonomy label.
	 *
	 * @since 1.0.0
	 * @param WP_Term $term Term.
	 * @return string
	 */
	private static function context_label( $term ): string {
		if ( $term->parent > 0 ) {
			$parent = get_term( $term->parent, $term->taxonomy );

			if ( $parent instanceof WP_Term ) {
				return html_entity_decode( wp_strip_all_tags( $parent->name ), ENT_QUOTES );
			}
		}

		$taxonomy = get_taxonomy( $term->taxonomy );

		return $taxonomy ? (string) $taxonomy->labels->singular_name : '';
	}
}
