<?php
/**
 * Results-page facets: category, brand and price filters (P2.1).
 *
 * @package mvweb_ss
 * @since   1.2.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the results-page facet panel and wires it to a shortcode and a
 * classic widget. Counts reuse the morphology-aware term matcher, so each value
 * shows how many of the query's matches fall into it; selecting facets narrows
 * the intercepted results through native WP_Query filters (see MVweb_SS_Search).
 *
 * @since 1.2.0
 */
class MVweb_SS_Facets {

	const LIMIT = 10;

	const GROUPS = array( 'cats', 'brands', 'price' );

	const DEPTH_FETCH = 4;

	const DEPTH_FLOOR = 40;

	/**
	 * Register the shortcode and widget.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function register(): void {
		add_shortcode( 'mvweb_ss_facets', array( __CLASS__, 'shortcode' ) );
		add_action( 'widgets_init', array( __CLASS__, 'register_widget' ) );
	}

	/**
	 * Register the classic sidebar widget.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function register_widget(): void {
		register_widget( 'MVweb_SS_Facets_Widget' );
	}

	/**
	 * `[mvweb_ss_facets]` shortcode handler.
	 *
	 * @since 1.2.0
	 * @return string
	 */
	public static function shortcode(): string {
		return self::render();
	}

	/**
	 * Max terms shown per facet, from the setting (clamped).
	 *
	 * @since 1.2.0
	 * @return int
	 */
	private static function facet_limit(): int {
		$limit = (int) MVweb_SS_Settings::get( 'facet_limit', self::LIMIT );

		return max( 1, min( 30, $limit ) );
	}

	/**
	 * Filters the panel is allowed to show, in panel order.
	 *
	 * A shop that files everything under one category, or one whose brands are
	 * not a taxonomy, gets a panel of dead weight from those groups; the setting
	 * lets the owner keep only the filters that mean something on their catalogue.
	 * An unsaved option (installs from before the setting existed) reads as all
	 * three, so nothing disappears on update.
	 *
	 * @since 1.5.9
	 * @return string[]
	 */
	public static function shown_groups(): array {
		$saved = MVweb_SS_Settings::get( 'facets', self::GROUPS );

		if ( ! is_array( $saved ) ) {
			return self::GROUPS;
		}

		return array_values( array_intersect( self::GROUPS, array_map( 'strval', $saved ) ) );
	}

	/**
	 * Whether one filter group is turned on.
	 *
	 * @since 1.5.9
	 * @param string $group One of self::GROUPS.
	 * @return bool
	 */
	private static function shows( string $group ): bool {
		return in_array( $group, self::shown_groups(), true );
	}

	/**
	 * Heading for one filter group: the owner's wording when set, the plugin's
	 * own otherwise. A shop calls its categories sections, ranges or series, and
	 * the panel should say what the shop says.
	 *
	 * @since 1.5.9
	 * @param string $group    One of self::GROUPS.
	 * @param string $fallback Built-in heading, already translated.
	 * @return string
	 */
	private static function label( string $group, string $fallback ): string {
		$custom = trim( (string) MVweb_SS_Settings::get( 'facet_label_' . $group, '' ) );

		return '' !== $custom ? $custom : $fallback;
	}

	/**
	 * Render the facet panel, or an empty string when it should not show (not a
	 * results page, facets disabled, empty query, or nothing to filter by).
	 *
	 * @since 1.2.0
	 * @return string
	 */
	public static function render(): string {
		if ( ! is_search() || ! MVweb_SS_Settings::get( 'results_facets', true ) ) {
			return '';
		}

		$query = trim( (string) get_search_query( false ) );

		if ( '' === $query || ! class_exists( 'MVweb_SS_Categories' ) ) {
			return '';
		}

		// Count inside the pool the page is showing, not by re-running the search:
		// the number next to a facet is then exactly what ticking it leaves.
		$pool = MVweb_SS_Search::pool_ids();

		// Ask for more than the panel shows: the ancestors dropped below are counted
		// among them, and without the headroom a deep catalogue would answer with
		// three or four values where ten were asked for. The floor matters as much
		// as the multiplier — a shop showing one value would otherwise judge "has a
		// child" against four candidates and keep a parent whose children simply
		// did not fit in the window.
		$limit  = self::facet_limit();
		$fetch  = max( $limit * self::DEPTH_FETCH, self::DEPTH_FLOOR );
		$cats   = self::shows( 'cats' ) ? self::leaves( MVweb_SS_Categories::search( $query, $fetch, $pool ), $limit ) : array();
		$brands = self::shows( 'brands' ) ? self::leaves( MVweb_SS_Categories::brands( $query, $fetch, $pool ), $limit ) : array();

		// A turned-off group costs nothing: neither its terms nor the price range
		// are queried at all.
		$bounds    = ( self::shows( 'price' ) && class_exists( 'WooCommerce' ) ) ? MVweb_SS_Query::price_bounds( $pool ) : array();
		$has_price = ! empty( $bounds );

		$sel_cats   = array_flip( MVweb_SS_Search::selected_facet_cats() );
		$sel_brands = array_flip( MVweb_SS_Search::selected_facet_brands() );
		$price      = MVweb_SS_Search::selected_price();

		// The category chosen before the search (scope selector or dropdown chip)
		// narrows the results just as a facet does, so it belongs in the panel as a
		// ticked value — otherwise the shopper sees a full-looking result list with
		// no sign of what it is limited to, and no way to lift the limit.
		$scope       = MVweb_SS_Search::scope_category();
		$scope_in    = self::scope_group( $scope );
		$scope_label = '';

		// Turning a group off hides its ticked scope value with it, so the scope
		// travels as a hidden field instead ($scope_box empty => preserved_hidden
		// carries it). Without that, applying a filter would silently widen the
		// search back to the whole catalogue. "Reset" still lifts it, because
		// $active is read from the real scope, not from the box.
		$scope_box = ( '' === $scope_in || 'own' === $scope_in || self::shows( $scope_in ) ) ? $scope_in : '';

		if ( 'cats' === $scope_box ) {
			$cats = self::without_term( $cats, $scope['term_id'] );
		} elseif ( 'brands' === $scope_box ) {
			$brands = self::without_term( $brands, $scope['term_id'] );
		} elseif ( 'own' === $scope_box ) {
			$taxonomy    = get_taxonomy( $scope['taxonomy'] );
			$scope_label = $taxonomy instanceof WP_Taxonomy ? (string) $taxonomy->labels->singular_name : $scope['taxonomy'];
		}

		$active = ! empty( $sel_cats ) || ! empty( $sel_brands ) || null !== $price['min'] || null !== $price['max'] || '' !== $scope_in;

		// Nothing to filter by hides the panel — unless a filter is already on, in
		// which case hiding it would take the "Reset" link away with it and leave
		// the shopper stuck on an empty result.
		if ( empty( $cats ) && empty( $brands ) && ! $has_price && ! $active ) {
			return '';
		}

		ob_start();
		?>
		<form role="search" method="get" class="mvweb-ss-facets" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<input type="hidden" name="s" value="<?php echo esc_attr( get_search_query() ); ?>">
			<?php foreach ( self::preserved_hidden( '' === $scope_box ) as $name => $value ) : ?>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>">
			<?php endforeach; ?>

			<?php if ( ! empty( $cats ) || 'cats' === $scope_box ) : ?>
				<fieldset class="mvweb-ss-facets__group">
					<legend class="mvweb-ss-facets__legend"><?php echo esc_html( self::label( 'cats', __( 'Categories', 'mvweb-smart-search' ) ) ); ?></legend>
					<?php
					if ( 'cats' === $scope_box ) {
						echo self::scope_option( $scope, count( $pool ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with escaping below.
					}
					echo self::options( $cats, 'mvweb_ss_fcat', $sel_cats ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with escaping below.
					?>
				</fieldset>
			<?php endif; ?>

			<?php if ( ! empty( $brands ) || 'brands' === $scope_box ) : ?>
				<fieldset class="mvweb-ss-facets__group">
					<legend class="mvweb-ss-facets__legend"><?php echo esc_html( self::label( 'brands', __( 'Brands', 'mvweb-smart-search' ) ) ); ?></legend>
					<?php
					if ( 'brands' === $scope_box ) {
						echo self::scope_option( $scope, count( $pool ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with escaping below.
					}
					echo self::options( $brands, 'mvweb_ss_fbrand', $sel_brands ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with escaping below.
					?>
				</fieldset>
			<?php endif; ?>

			<?php if ( 'own' === $scope_box ) : ?>
				<fieldset class="mvweb-ss-facets__group">
					<legend class="mvweb-ss-facets__legend"><?php echo esc_html( $scope_label ); ?></legend>
					<?php echo self::scope_option( $scope, count( $pool ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with escaping below. ?>
				</fieldset>
			<?php endif; ?>

			<?php if ( $has_price ) : ?>
				<fieldset class="mvweb-ss-facets__group mvweb-ss-facets__group--price">
					<legend class="mvweb-ss-facets__legend"><?php echo esc_html( self::label( 'price', __( 'Price', 'mvweb-smart-search' ) ) ); ?></legend>
					<div class="mvweb-ss-facets__price">
						<input type="number" inputmode="numeric" min="0" step="any" class="mvweb-ss-facets__price-input"
							name="mvweb_ss_pmin" value="<?php echo esc_attr( null !== $price['min'] ? (string) $price['min'] : '' ); ?>"
							placeholder="<?php echo esc_attr( (string) (int) floor( $bounds['min'] ) ); ?>"
							aria-label="<?php esc_attr_e( 'Minimum price', 'mvweb-smart-search' ); ?>">
						<span class="mvweb-ss-facets__price-sep">&ndash;</span>
						<input type="number" inputmode="numeric" min="0" step="any" class="mvweb-ss-facets__price-input"
							name="mvweb_ss_pmax" value="<?php echo esc_attr( null !== $price['max'] ? (string) $price['max'] : '' ); ?>"
							placeholder="<?php echo esc_attr( (string) (int) ceil( $bounds['max'] ) ); ?>"
							aria-label="<?php esc_attr_e( 'Maximum price', 'mvweb-smart-search' ); ?>">
					</div>
				</fieldset>
			<?php endif; ?>

			<div class="mvweb-ss-facets__actions">
				<button type="submit" class="mvweb-ss-facets__apply"><?php esc_html_e( 'Apply filters', 'mvweb-smart-search' ); ?></button>
				<?php if ( $active ) : ?>
					<a class="mvweb-ss-facets__reset" href="<?php echo esc_url( self::reset_url() ); ?>"><?php esc_html_e( 'Reset', 'mvweb-smart-search' ); ?></a>
				<?php endif; ?>
			</div>
		</form>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Which group of the panel the pre-search category is shown in.
	 *
	 * @since 1.5.7
	 * @param array{term_id:int,taxonomy:string} $scope Pre-search category.
	 * @return string 'cats', 'brands', 'own' (a group of its own), or '' when
	 *                nothing was chosen before the search.
	 */
	private static function scope_group( array $scope ): string {
		if ( $scope['term_id'] <= 0 ) {
			return '';
		}

		if ( MVweb_SS_Categories::facet_category_taxonomy() === $scope['taxonomy'] ) {
			return 'cats';
		}

		if ( MVweb_SS_Categories::facet_brand_taxonomy() === $scope['taxonomy'] ) {
			return 'brands';
		}

		// The search bar's selector can be pointed at any hierarchical taxonomy
		// (Appearance → Category taxonomy), which belongs to neither facet group.
		// It gets a group of its own rather than none, so a narrowing that is
		// already applied is never invisible.
		return 'own';
	}

	/**
	 * Keep the deepest categories the query reached, dropping every value that has
	 * a descendant in the same list.
	 *
	 * A term's count already includes everything filed under it, so a parent shown
	 * beside its children repeats them: on a parts catalogue "Запчасти 971",
	 * "Дисплей 501" and "iPhone 91" are the same products three times, and the
	 * shopper cannot tell one level from another in a flat list. Ticking the child
	 * is what actually narrows the results, so the child is what the panel offers.
	 * A parent whose children the query did not reach keeps its place — it is a
	 * leaf as far as this result set is concerned.
	 *
	 * @since 1.5.10
	 * @param array<int,array<string,mixed>> $terms Terms from MVweb_SS_Categories.
	 * @param int                            $limit How many values the panel shows.
	 * @return array<int,array<string,mixed>>
	 */
	private static function leaves( array $terms, int $limit ): array {
		$has_child = array();

		foreach ( $terms as $term ) {
			$taxonomy = (string) $term['taxonomy'];

			foreach ( get_ancestors( (int) $term['term_id'], $taxonomy, 'taxonomy' ) as $ancestor ) {
				$has_child[ $taxonomy . '|' . (int) $ancestor ] = true;
			}
		}

		$out = array();

		foreach ( $terms as $term ) {
			if ( isset( $has_child[ (string) $term['taxonomy'] . '|' . (int) $term['term_id'] ] ) ) {
				continue;
			}

			$out[] = $term;

			if ( count( $out ) >= $limit ) {
				break;
			}
		}

		return $out;
	}

	/**
	 * Drop one term from a facet's value list, so the pre-search category is not
	 * offered twice — once ticked, once as a plain value.
	 *
	 * @since 1.5.7
	 * @param array<int,array<string,mixed>> $terms   Terms from MVweb_SS_Categories.
	 * @param int                            $term_id Term to remove.
	 * @return array<int,array<string,mixed>>
	 */
	private static function without_term( array $terms, int $term_id ): array {
		return array_values(
			array_filter(
				$terms,
				static function ( $term ) use ( $term_id ) {
					return (int) $term['term_id'] !== $term_id;
				}
			)
		);
	}

	/**
	 * The pre-search category as a ticked facet value (already fully escaped).
	 *
	 * It carries `mvweb_ss_cat`, not the facet parameter: the scope narrows the
	 * search itself, before the ranked pool is cut to the results ceiling, while
	 * a facet filters that pool afterwards — moving it into the facet would drop
	 * every match beyond the ceiling. Unticking it removes the parameter, which
	 * is what lifts the limit. Its taxonomy rides along, so a brand chip from the
	 * live dropdown still resolves after the form is submitted.
	 *
	 * @since 1.5.7
	 * @param array{term_id:int,taxonomy:string} $scope Pre-search category.
	 * @param int                                $count Size of the pool it produced.
	 * @return string
	 */
	private static function scope_option( array $scope, int $count ): string {
		$term = get_term( $scope['term_id'], $scope['taxonomy'] );

		if ( ! $term instanceof WP_Term ) {
			return '';
		}

		$name = html_entity_decode( wp_strip_all_tags( $term->name ), ENT_QUOTES );

		// Same two-line shape as a plain value, so the ticked scope does not sit in
		// the list with its count adrift while every row below has it flush right.
		$context = MVweb_SS_Categories::context_label( $term );

		return '<label class="mvweb-ss-facets__opt">'
			. '<input type="checkbox" name="mvweb_ss_cat" value="' . esc_attr( (string) $scope['term_id'] ) . '" checked>'
			. '<span class="mvweb-ss-facets__opt-text">'
			. '<span class="mvweb-ss-facets__opt-name">' . esc_html( $name ) . '</span>'
			. ( '' !== $context ? '<span class="mvweb-ss-facets__opt-context">' . esc_html( $context ) . '</span>' : '' )
			. '</span>'
			. '<span class="mvweb-ss-facets__opt-count">' . esc_html( (string) $count ) . '</span>'
			. '</label>'
			. '<input type="hidden" name="mvweb_ss_tax" value="' . esc_attr( $scope['taxonomy'] ) . '">';
	}

	/**
	 * Build the checkbox list for one facet (already fully escaped).
	 *
	 * @since 1.2.0
	 * @param array<int,array<string,mixed>> $terms    Terms from MVweb_SS_Categories.
	 * @param string                         $field    Checkbox field name (array).
	 * @param array<int,int>                 $selected term_id => position for checked state.
	 * @return string
	 */
	private static function options( array $terms, string $field, array $selected ): string {
		$out = '';

		foreach ( $terms as $term ) {
			$id      = (int) $term['term_id'];
			$checked = isset( $selected[ $id ] ) ? ' checked' : '';

			// Where the category sits, so two branches ending in the same word — a
			// brand under displays and the same brand under touchscreens — are told
			// apart. The matcher already carries it; the live dropdown shows it too.
			$context = isset( $term['context'] ) ? trim( (string) $term['context'] ) : '';

			$out .= '<label class="mvweb-ss-facets__opt">'
				. '<input type="checkbox" name="' . esc_attr( $field ) . '[]" value="' . esc_attr( (string) $id ) . '"' . $checked . '>'
				. '<span class="mvweb-ss-facets__opt-text">'
				. '<span class="mvweb-ss-facets__opt-name">' . esc_html( (string) $term['name'] ) . '</span>'
				. ( '' !== $context ? '<span class="mvweb-ss-facets__opt-context">' . esc_html( $context ) . '</span>' : '' )
				. '</span>'
				. '<span class="mvweb-ss-facets__opt-count">' . esc_html( (string) (int) $term['count'] ) . '</span>'
				. '</label>';
		}

		return $out;
	}

	/**
	 * Non-facet search parameters to carry through the form so applying a facet
	 * keeps the query, its type scope, category scope and sort order.
	 *
	 * @since 1.2.0
	 * @param bool $keep_cat Carry the category scope. False when the panel shows
	 *                       it as a ticked value (the checkbox carries it then,
	 *                       so a hidden copy would make it impossible to untick)
	 *                       and in the reset URL, which clears it.
	 * @return array<string,string>
	 */
	private static function preserved_hidden( bool $keep_cat = true ): array {
		$out = array();

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only public params, like `s`.
		if ( isset( $_GET['mvweb_ss_types'] ) ) {
			$types = sanitize_text_field( wp_unslash( $_GET['mvweb_ss_types'] ) );
			if ( '' !== $types ) {
				$out['mvweb_ss_types'] = $types;
			}
		}

		if ( $keep_cat && isset( $_GET['mvweb_ss_cat'] ) ) {
			$cat = absint( wp_unslash( $_GET['mvweb_ss_cat'] ) );
			if ( $cat > 0 ) {
				$out['mvweb_ss_cat'] = (string) $cat;

				// The category scope carries its taxonomy from the live dropdown; without
				// it the scope silently resolves to nothing after a facet submit/reset.
				if ( isset( $_GET['mvweb_ss_tax'] ) ) {
					$tax = sanitize_key( wp_unslash( $_GET['mvweb_ss_tax'] ) );
					if ( '' !== $tax && taxonomy_exists( $tax ) ) {
						$out['mvweb_ss_tax'] = $tax;
					}
				}
			}
		}

		$sort = MVweb_SS_Search::requested_sort();
		if ( '' !== $sort ) {
			$out['mvweb_ss_sort'] = $sort;
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		return $out;
	}

	/**
	 * URL that clears every filter shown in the panel — facets and the
	 * pre-search category alike — keeping the query, its type scope and sort.
	 *
	 * @since 1.2.0
	 * @return string
	 */
	private static function reset_url(): string {
		$args = array( 's' => get_search_query() );

		foreach ( self::preserved_hidden( false ) as $name => $value ) {
			$args[ $name ] = $value;
		}

		return add_query_arg( array_map( 'rawurlencode', $args ), home_url( '/' ) );
	}
}
