<?php
/**
 * Index management tab (reindex + status).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings     = MVweb_SS_Settings::all();
$option       = MVweb_SS_Settings::OPTION;
$progress     = MVweb_SS_Reindex::get_progress();
$last_reindex = (int) $progress['last_reindex'];
$export_url   = wp_nonce_url( admin_url( 'admin-post.php?action=' . MVweb_SS_Admin::EXPORT_ACTION ), MVweb_SS_Admin::EXPORT_ACTION );

$in_index = (int) $progress['in_index'];
$expected = MVweb_SS_Indexer::count_indexable();

// Drift is read in both directions. Too few is content that never reached the
// index; too many is content that left the site around the sync hooks and whose
// rows nothing collected — a direct SQL delete, a restored dump, an importer
// emptying a catalogue by query. Exclusions keep a healthy index a little under
// the published count and can never push it over, so any excess is stale.
$index_short = $expected > 0 && ( 0 === $in_index || $in_index < (int) floor( $expected * 0.5 ) );
$index_stale = $in_index > $expected;
?>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Index', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'The index updates automatically as content changes. A full reindex is needed after changing coverage settings or on first install.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Items in index', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<strong id="mvweb-ss-index-count"><?php echo esc_html( (string) (int) $progress['in_index'] ); ?></strong>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Last reindex', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<span>
				<?php
				echo $last_reindex
					? esc_html( wp_date( 'Y-m-d H:i', $last_reindex ) )
					: esc_html__( 'never run', 'mvweb-smart-search' );
				?>
			</span>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Last auto-maintenance run', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<span>
				<?php
				$catchup_on   = (bool) MVweb_SS_Settings::get( 'reindex_catchup', true );
				$catchup_last = MVweb_SS_Catchup::last_run();
				if ( ! $catchup_on ) {
					esc_html_e( 'disabled', 'mvweb-smart-search' );
				} elseif ( $catchup_last ) {
					printf(
						/* translators: 1: date and time, 2: human-readable elapsed time, e.g. "12 minutes". */
						esc_html__( '%1$s (%2$s ago)', 'mvweb-smart-search' ),
						esc_html( wp_date( 'Y-m-d H:i', $catchup_last ) ),
						esc_html( human_time_diff( $catchup_last ) )
					);
				} else {
					esc_html_e( 'not yet — waiting for the first scheduled pass', 'mvweb-smart-search' );
				}
				?>
			</span>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Confirms the scheduled index maintenance is running. This is the incremental catch-up, separate from the full reindex above.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Publishable objects', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<span><?php echo esc_html( (string) $expected ); ?></span>
			<?php if ( $index_short ) : ?>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'The index holds far fewer items than the site has published. This usually means content was imported in a way that skipped indexing. Run a full reindex to bring it back in sync.', 'mvweb-smart-search' ); ?></p>
			<?php elseif ( $index_stale ) : ?>
				<p class="mvweb-form-row__desc">
					<?php
					printf(
						/* translators: %d: number of stale items held in the index. */
						esc_html__( 'The index holds %d more items than the site has published. These are left over from content deleted in a way that skipped the index — a direct database change, a restored dump, an importer that empties a catalogue. They never appear in results, but they take up space and skew word weighting. A full reindex clears them.', 'mvweb-smart-search' ),
						(int) ( $in_index - $expected )
					);
					?>
				</p>
			<?php endif; ?>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Full reindex', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<button type="button" id="mvweb-ss-reindex" class="mvweb-btn mvweb-btn--primary"><?php esc_html_e( 'Reindex everything', 'mvweb-smart-search' ); ?></button>
			<p id="mvweb-ss-reindex-status" class="mvweb-form-row__desc" aria-live="polite"></p>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Automatic maintenance', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'A safety net that keeps the index current even when content is imported in ways that skip the normal save hooks.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Catch up on missed changes', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" name="<?php echo esc_attr( $option ); ?>[reindex_catchup]" value="1" <?php checked( ! empty( $settings['reindex_catchup'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'A scheduled task re-indexes any object modified since the last pass, catching bulk imports and tools that bypass the usual hooks. Incremental and lightweight — never a full rebuild.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-catchup-interval"><?php esc_html_e( 'How often', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-ss-catchup-interval" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[catchup_interval]">
				<option value="hourly" <?php selected( $settings['catchup_interval'], 'hourly' ); ?>><?php esc_html_e( 'Every hour', 'mvweb-smart-search' ); ?></option>
				<option value="twicedaily" <?php selected( $settings['catchup_interval'], 'twicedaily' ); ?>><?php esc_html_e( 'Twice a day', 'mvweb-smart-search' ); ?></option>
				<option value="daily" <?php selected( $settings['catchup_interval'], 'daily' ); ?>><?php esc_html_e( 'Once a day', 'mvweb-smart-search' ); ?></option>
			</select>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-scheduled-reindex"><?php esc_html_e( 'Scheduled full rebuild', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-ss-scheduled-reindex" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[scheduled_reindex]">
				<option value="off" <?php selected( $settings['scheduled_reindex'], 'off' ); ?>><?php esc_html_e( 'Off', 'mvweb-smart-search' ); ?></option>
				<option value="weekly" <?php selected( $settings['scheduled_reindex'], 'weekly' ); ?>><?php esc_html_e( 'Once a week', 'mvweb-smart-search' ); ?></option>
				<option value="monthly" <?php selected( $settings['scheduled_reindex'], 'monthly' ); ?>><?php esc_html_e( 'Once a month', 'mvweb-smart-search' ); ?></option>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'A heavy safety net that rebuilds the whole index on a schedule, for catalogs where content is overwritten without changing its modified date (which the hourly catch-up relies on). Off by default; leave it off unless you see the index drift out of sync. Runs in small background batches so a large catalog never rebuilds in one go.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-log-retention"><?php esc_html_e( 'Keep search statistics for', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-log-retention" class="mvweb-input" name="<?php echo esc_attr( $option ); ?>[log_retention_days]" value="<?php echo esc_attr( (string) (int) $settings['log_retention_days'] ); ?>" min="0" max="3650" step="1">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'A daily cleanup drops search-log and click rows untouched for this many days, so the analytics tables do not grow without bound. Actively searched phrases stay (their timestamp refreshes on every search). Set to 0 to keep everything forever.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Export and import settings', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Move configuration between sites. Importing replaces the current settings.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Export', 'mvweb-smart-search' ); ?></span>
		<div class="mvweb-form-row__field">
			<a class="mvweb-btn" href="<?php echo esc_url( $export_url ); ?>"><?php esc_html_e( 'Export to JSON', 'mvweb-smart-search' ); ?></a>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-import-data"><?php esc_html_e( 'Import', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="mvweb-ss-import-data" class="mvweb-textarea" rows="4" placeholder="<?php esc_attr_e( 'Paste the settings JSON…', 'mvweb-smart-search' ); ?>"></textarea>
			<button type="button" id="mvweb-ss-import" class="mvweb-btn"><?php esc_html_e( 'Import', 'mvweb-smart-search' ); ?></button>
			<p id="mvweb-ss-import-status" class="mvweb-form-row__desc" aria-live="polite"></p>
		</div>
	</div>
</section>
