<?php
/**
 * Behavior settings tab (dropdown timing, limits, highlighting, results page).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = MVweb_SS_Settings::all();
$option   = MVweb_SS_Settings::OPTION;
?>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Live dropdown', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'When suggestions appear and how many are shown.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-min-chars"><?php esc_html_e( 'Minimum characters', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-min-chars" class="mvweb-input" min="1" max="10" step="1" name="<?php echo esc_attr( $option ); ?>[min_chars]" value="<?php echo esc_attr( (string) (int) $settings['min_chars'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'How many characters the visitor must type before suggestions start loading.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-debounce"><?php esc_html_e( 'Typing delay (ms)', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-debounce" class="mvweb-input" min="0" max="2000" step="50" name="<?php echo esc_attr( $option ); ?>[debounce_ms]" value="<?php echo esc_attr( (string) (int) $settings['debounce_ms'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'The pause after the last keystroke before a request is sent. Higher values mean fewer requests.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-sugg-limit"><?php esc_html_e( 'Total suggestions', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-sugg-limit" class="mvweb-input" min="1" max="50" step="1" name="<?php echo esc_attr( $option ); ?>[sugg_limit]" value="<?php echo esc_attr( (string) (int) $settings['sugg_limit'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Maximum number of results shown in the dropdown across all groups.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-per-group"><?php esc_html_e( 'Per-group limit', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-per-group" class="mvweb-input" min="0" max="50" step="1" name="<?php echo esc_attr( $option ); ?>[per_group_limit]" value="<?php echo esc_attr( (string) (int) $settings['per_group_limit'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Maximum results per group (Products, Posts, Pages…). Set to 0 for no per-group limit.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Matching and hints', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'How matches are shown and how typo corrections are announced.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-highlight"><?php esc_html_e( 'Highlight matches', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-highlight" name="<?php echo esc_attr( $option ); ?>[highlight]" value="1" <?php checked( ! empty( $settings['highlight'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Emphasize the matched part of each result title with the accent color.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-fuzzy-notice"><?php esc_html_e( 'Typo-correction hint', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-ss-fuzzy-notice" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[fuzzy_notice]">
				<option value="silent" <?php selected( $settings['fuzzy_notice'], 'silent' ); ?>><?php esc_html_e( 'Silent — no hint', 'mvweb-smart-search' ); ?></option>
				<option value="showing" <?php selected( $settings['fuzzy_notice'], 'showing' ); ?>><?php esc_html_e( '"Showing results for…"', 'mvweb-smart-search' ); ?></option>
				<option value="suggest" <?php selected( $settings['fuzzy_notice'], 'suggest' ); ?>><?php esc_html_e( '"Did you mean…?" (clickable)', 'mvweb-smart-search' ); ?></option>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'When a typo is auto-corrected, optionally show a note with the corrected phrase.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-group-order"><?php esc_html_e( 'Group order', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-ss-group-order" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[group_order]">
				<option value="products" <?php selected( $settings['group_order'], 'products' ); ?>><?php esc_html_e( 'Products first', 'mvweb-smart-search' ); ?></option>
				<option value="content" <?php selected( $settings['group_order'], 'content' ); ?>><?php esc_html_e( 'Posts and pages first', 'mvweb-smart-search' ); ?></option>
				<option value="pages" <?php selected( $settings['group_order'], 'pages' ); ?>><?php esc_html_e( 'Pages first', 'mvweb-smart-search' ); ?></option>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Order of result groups in the dropdown. Any other content types follow after.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Results page', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'The full search results page (when a visitor submits the form).', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-results-per-page"><?php esc_html_e( 'Results per page', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-results-per-page" class="mvweb-input" min="0" max="100" step="1" name="<?php echo esc_attr( $option ); ?>[results_per_page]" value="<?php echo esc_attr( (string) (int) $settings['results_per_page'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Number of results on the search results page. Set to 0 to use the theme default.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-results-max"><?php esc_html_e( 'Results ceiling', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-results-max" class="mvweb-input" min="20" max="1000" step="10" name="<?php echo esc_attr( $option ); ?>[results_max]" value="<?php echo esc_attr( (string) (int) $settings['results_max'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Maximum ranked results paginated across the results pages. A broad query is no longer cut off at 100. Higher values page deeper at a small cost per search.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-results-facets"><?php esc_html_e( 'Result filters (facets)', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-results-facets" name="<?php echo esc_attr( $option ); ?>[results_facets]" value="1" <?php checked( ! empty( $settings['results_facets'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'The filter panel on the results page. Add the "MVweb Search Filters" widget to a sidebar, or place the [mvweb_ss_facets] shortcode. Which filters it shows is set below.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<?php
	$facet_groups = array(
		'cats'   => array(
			'row'     => __( 'Categories filter', 'mvweb-smart-search' ),
			'default' => __( 'Categories', 'mvweb-smart-search' ),
			'desc'    => __( 'Product (or content) categories the query matched, with a count each.', 'mvweb-smart-search' ),
		),
		'brands' => array(
			'row'     => __( 'Brands filter', 'mvweb-smart-search' ),
			'default' => __( 'Brands', 'mvweb-smart-search' ),
			'desc'    => __( 'Matched brands, from the brand taxonomy. Nothing shows when the shop has none.', 'mvweb-smart-search' ),
		),
		'price'  => array(
			'row'     => __( 'Price filter', 'mvweb-smart-search' ),
			'default' => __( 'Price', 'mvweb-smart-search' ),
			'desc'    => __( 'A minimum and maximum price box (WooCommerce only).', 'mvweb-smart-search' ),
		),
	);

	$facets_on = is_array( $settings['facets'] ) ? $settings['facets'] : array();
	?>

	<?php foreach ( $facet_groups as $facet_key => $facet ) : ?>
		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-ss-facet-<?php echo esc_attr( $facet_key ); ?>"><?php echo esc_html( $facet['row'] ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row mvweb-ss-facet-row">
					<label class="mvweb-toggle">
						<input type="checkbox" id="mvweb-ss-facet-<?php echo esc_attr( $facet_key ); ?>" name="<?php echo esc_attr( $option ); ?>[facets][]" value="<?php echo esc_attr( $facet_key ); ?>" <?php checked( in_array( $facet_key, $facets_on, true ) ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<input type="text" id="mvweb-ss-facet-label-<?php echo esc_attr( $facet_key ); ?>" class="mvweb-input"
						name="<?php echo esc_attr( $option ); ?>[facet_label_<?php echo esc_attr( $facet_key ); ?>]"
						value="<?php echo esc_attr( (string) $settings[ 'facet_label_' . $facet_key ] ); ?>"
						aria-label="<?php esc_attr_e( 'Filter heading', 'mvweb-smart-search' ); ?>"
						placeholder="<?php echo esc_attr( $facet['default'] ); ?>">
				</div>
				<p class="mvweb-form-row__desc"><?php echo esc_html( $facet['desc'] ); ?> <?php esc_html_e( 'The field sets the heading shown above this filter — leave it empty for the default.', 'mvweb-smart-search' ); ?></p>
			</div>
		</div>
	<?php endforeach; ?>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-facet-limit"><?php esc_html_e( 'Values per filter', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-facet-limit" class="mvweb-input" min="1" max="30" step="1" name="<?php echo esc_attr( $option ); ?>[facet_limit]" value="<?php echo esc_attr( (string) (int) $settings['facet_limit'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'How many categories and brands to list in each filter (most matches first).', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>
