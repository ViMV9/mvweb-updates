<?php
/**
 * Multilingual integration (Polylang / WPML).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Restricts search results to the current language when Polylang or WPML is
 * active. A no-op on monolingual sites.
 *
 * @since 1.0.0
 */
class MVweb_SS_I18n {

	/**
	 * Register the results filter.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_filter( 'mvweb_ss_results', array( __CLASS__, 'filter_by_language' ) );
	}

	/**
	 * Drop results that are not in the current site language.
	 *
	 * @since 1.0.0
	 * @param array $results Ranked results.
	 * @return array
	 */
	public static function filter_by_language( array $results ): array {
		$current = self::current_language();

		if ( '' === $current ) {
			return $results;
		}

		return array_values(
			array_filter(
				$results,
				static function ( $row ) use ( $current ) {
					$lang = self::post_language( (int) $row['object_id'] );

					return '' === $lang || $lang === $current;
				}
			)
		);
	}

	/**
	 * Current language slug, or '' when no multilingual plugin is active.
	 *
	 * Public because anything caching a result set must key on it: the language
	 * filter runs after the query, so two locales sharing a cache entry would
	 * share each other's results.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function current_language(): string {
		if ( function_exists( 'pll_current_language' ) ) {
			$slug = pll_current_language( 'slug' );

			return is_string( $slug ) ? $slug : '';
		}

		if ( defined( 'ICL_LANGUAGE_CODE' ) ) {
			return (string) ICL_LANGUAGE_CODE;
		}

		return '';
	}

	/**
	 * Language slug of a post, or '' when unknown.
	 *
	 * @since 1.0.0
	 * @param int $id Post ID.
	 * @return string
	 */
	private static function post_language( int $id ): string {
		if ( function_exists( 'pll_get_post_language' ) ) {
			$slug = pll_get_post_language( $id, 'slug' );

			return is_string( $slug ) ? $slug : '';
		}

		if ( defined( 'ICL_LANGUAGE_CODE' ) ) {
			$details = apply_filters( 'wpml_post_language_details', null, $id );

			return ( is_array( $details ) && ! empty( $details['language_code'] ) ) ? (string) $details['language_code'] : '';
		}

		return '';
	}
}
