<?php
/**
 * Ready-made synonym dictionaries fetched from the MVweb GitHub repo.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Installs and updates curated synonym packs by pulling versioned JSON from a
 * pinned public repository, then feeds their groups into the synonym engine.
 *
 * @since 1.0.0
 */
class MVweb_SS_Dictionaries {

	const OPTION = 'mvweb_ss_dict_packs';

	const MANIFEST_TRANSIENT = 'mvweb_ss_dict_manifest';

	const NONCE = 'mvweb_ss_dict';

	const REPO_BASE = 'https://raw.githubusercontent.com/ViMV9/mvweb-search-dictionaries/main/';

	const MAX_BODY = 512000;

	const MAX_GROUPS = 500;

	const MAX_ENTRIES = 20;

	const MAX_TERM_LENGTH = 100;

	/**
	 * Register the install/remove/refresh AJAX endpoints.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'wp_ajax_mvweb_ss_install_dictionary', array( __CLASS__, 'ajax_install' ) );
		add_action( 'wp_ajax_mvweb_ss_remove_dictionary', array( __CLASS__, 'ajax_remove' ) );
		add_action( 'wp_ajax_mvweb_ss_refresh_dictionaries', array( __CLASS__, 'ajax_refresh' ) );
	}

	/**
	 * Installed packs, keyed by slug.
	 *
	 * @since 1.0.0
	 * @return array<string,array>
	 */
	public static function installed(): array {
		$data = get_option( self::OPTION, array() );

		return is_array( $data ) ? $data : array();
	}

	/**
	 * Synonym groups from every enabled installed pack.
	 *
	 * @since 1.0.0
	 * @return array<int,string[]>
	 */
	public static function active_groups(): array {
		$groups = array();

		foreach ( self::installed() as $pack ) {
			if ( ! is_array( $pack ) || ( array_key_exists( 'enabled', $pack ) && ! $pack['enabled'] ) ) {
				continue;
			}

			if ( empty( $pack['groups'] ) || ! is_array( $pack['groups'] ) ) {
				continue;
			}

			foreach ( $pack['groups'] as $group ) {
				if ( is_array( $group ) ) {
					$groups[] = array_map( 'strval', $group );
				}
			}
		}

		return $groups;
	}

	/**
	 * Remote manifest (index.json), cached for 12 hours.
	 *
	 * @since 1.0.0
	 * @return array Manifest data, or an empty pack list on failure.
	 */
	public static function manifest(): array {
		$cached = get_transient( self::MANIFEST_TRANSIENT );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		$data = self::fetch_json( 'index.json' );

		if ( is_wp_error( $data ) || empty( $data['packs'] ) || ! is_array( $data['packs'] ) ) {
			$empty = array( 'packs' => array() );
			set_transient( self::MANIFEST_TRANSIENT, $empty, 10 * MINUTE_IN_SECONDS );

			return $empty;
		}

		set_transient( self::MANIFEST_TRANSIENT, $data, 12 * HOUR_IN_SECONDS );

		return $data;
	}

	/**
	 * Slugs advertised by the remote manifest (sanitized).
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	private static function manifest_slugs(): array {
		$slugs    = array();
		$manifest = self::manifest();
		$packs    = ! empty( $manifest['packs'] ) && is_array( $manifest['packs'] ) ? $manifest['packs'] : array();

		foreach ( $packs as $pack ) {
			if ( ! empty( $pack['slug'] ) && is_string( $pack['slug'] ) ) {
				$slug = sanitize_key( $pack['slug'] );

				if ( '' !== $slug ) {
					$slugs[] = $slug;
				}
			}
		}

		return $slugs;
	}

	/**
	 * Packs available for the admin UI: remote metadata merged with local state.
	 *
	 * @since 1.0.0
	 * @return array<int,array>
	 */
	public static function available(): array {
		$manifest  = self::manifest();
		$remote    = ! empty( $manifest['packs'] ) && is_array( $manifest['packs'] ) ? $manifest['packs'] : array();
		$installed = self::installed();
		$out       = array();

		foreach ( $remote as $pack ) {
			if ( empty( $pack['slug'] ) || ! is_string( $pack['slug'] ) ) {
				continue;
			}

			$slug = sanitize_key( $pack['slug'] );

			if ( '' === $slug ) {
				continue;
			}

			$local          = isset( $installed[ $slug ] ) && is_array( $installed[ $slug ] ) ? $installed[ $slug ] : null;
			$remote_version = isset( $pack['version'] ) ? (string) $pack['version'] : '';
			$local_version  = $local && isset( $local['version'] ) ? (string) $local['version'] : '';

			$out[] = array(
				'slug'        => $slug,
				'name'        => isset( $pack['name'] ) ? (string) $pack['name'] : $slug,
				'description' => isset( $pack['description'] ) ? (string) $pack['description'] : '',
				'remote'      => $remote_version,
				'installed'   => $local_version,
				'update'      => '' !== $local_version && '' !== $remote_version && version_compare( $local_version, $remote_version, '<' ),
			);
		}

		return $out;
	}

	/**
	 * Install (or update) a pack by slug.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_install(): void {
		self::verify_request();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce is verified in verify_request() above.
		$slug = isset( $_POST['slug'] ) ? sanitize_key( wp_unslash( $_POST['slug'] ) ) : '';

		if ( '' === $slug || ! in_array( $slug, self::manifest_slugs(), true ) ) {
			wp_send_json_error( array( 'message' => __( 'Unknown dictionary.', 'mvweb-smart-search' ) ), 400 );
		}

		$data = self::fetch_json( 'packs/' . $slug . '.json' );

		if ( is_wp_error( $data ) ) {
			wp_send_json_error( array( 'message' => $data->get_error_message() ) );
		}

		$pack = self::sanitize_pack( (array) $data, $slug );

		if ( is_wp_error( $pack ) ) {
			wp_send_json_error( array( 'message' => $pack->get_error_message() ) );
		}

		$installed          = self::installed();
		$installed[ $slug ] = $pack;
		update_option( self::OPTION, $installed, false );

		self::flush();

		wp_send_json_success(
			array(
				'slug'    => $slug,
				'version' => $pack['version'],
				'groups'  => count( $pack['groups'] ),
			)
		);
	}

	/**
	 * Drop the cached pack list and re-read it from the repository.
	 *
	 * The list is cached for half a day, so a freshly published pack or version
	 * stays invisible until that expires — with no way to ask for it from the
	 * screen. This is that way: it only clears the cache, never touching an
	 * installed pack, so the worst case is one wasted request.
	 *
	 * @since 1.5.4
	 * @return void
	 */
	public static function ajax_refresh(): void {
		self::verify_request();

		delete_transient( self::MANIFEST_TRANSIENT );

		// Re-read the list here rather than on the reload: a repository that is
		// down surfaces as an error under the button, not as a page that comes
		// back with an empty list and no explanation.
		self::manifest();

		wp_send_json_success();
	}

	/**
	 * Remove an installed pack.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_remove(): void {
		self::verify_request();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce is verified in verify_request() above.
		$slug      = isset( $_POST['slug'] ) ? sanitize_key( wp_unslash( $_POST['slug'] ) ) : '';
		$installed = self::installed();

		if ( isset( $installed[ $slug ] ) ) {
			unset( $installed[ $slug ] );
			update_option( self::OPTION, $installed, false );
			self::flush();
		}

		wp_send_json_success( array( 'slug' => $slug ) );
	}

	/**
	 * Capability + nonce gate for admin AJAX (capability first, per WP guidance).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function verify_request(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mvweb-smart-search' ) ), 403 );
		}

		check_ajax_referer( self::NONCE, 'nonce' );
	}

	/**
	 * Fetch and decode JSON from the pinned repository.
	 *
	 * @since 1.0.0
	 * @param string $relative Path under REPO_BASE (already trusted, slug pre-validated).
	 * @return array|WP_Error Decoded array, or error.
	 */
	private static function fetch_json( string $relative ) {
		$response = wp_remote_get(
			self::REPO_BASE . ltrim( $relative, '/' ),
			array(
				'timeout'             => 10,
				'redirection'         => 2,
				'limit_response_size' => self::MAX_BODY,
				'reject_unsafe_urls'  => true,
				'user-agent'          => 'MVweb Smart Search/' . MVWEB_SS_VERSION,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );

		if ( 200 !== $code ) {
			/* translators: %d: HTTP status code. */
			return new WP_Error( 'mvweb_ss_http', sprintf( __( 'Download failed (HTTP %d).', 'mvweb-smart-search' ), $code ) );
		}

		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true, 8 );

		if ( JSON_ERROR_NONE !== json_last_error() || ! is_array( $data ) ) {
			return new WP_Error( 'mvweb_ss_json', __( 'Invalid dictionary format.', 'mvweb-smart-search' ) );
		}

		return $data;
	}

	/**
	 * Validate and sanitize a decoded pack into the stored shape (strings only).
	 *
	 * @since 1.0.0
	 * @param array  $data Decoded pack.
	 * @param string $slug Requested slug (must match the body).
	 * @return array|WP_Error Clean pack, or error.
	 */
	private static function sanitize_pack( array $data, string $slug ) {
		if ( empty( $data['slug'] ) || ! is_string( $data['slug'] ) || sanitize_key( $data['slug'] ) !== $slug ) {
			return new WP_Error( 'mvweb_ss_slug', __( 'Dictionary identity mismatch.', 'mvweb-smart-search' ) );
		}

		if ( empty( $data['groups'] ) || ! is_array( $data['groups'] ) ) {
			return new WP_Error( 'mvweb_ss_groups', __( 'Dictionary has no groups.', 'mvweb-smart-search' ) );
		}

		$groups = array();

		foreach ( array_slice( $data['groups'], 0, self::MAX_GROUPS ) as $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}

			$entries = array();

			foreach ( array_slice( $group, 0, self::MAX_ENTRIES ) as $term ) {
				if ( ! is_scalar( $term ) ) {
					continue;
				}

				$term = str_replace( 'ё', 'е', mb_strtolower( trim( sanitize_text_field( (string) $term ) ), 'UTF-8' ) );

				if ( '' !== $term && mb_strlen( $term, 'UTF-8' ) <= self::MAX_TERM_LENGTH ) {
					$entries[] = $term;
				}
			}

			$entries = array_values( array_unique( $entries ) );

			if ( count( $entries ) >= 2 ) {
				$groups[] = $entries;
			}
		}

		if ( empty( $groups ) ) {
			return new WP_Error( 'mvweb_ss_empty', __( 'Dictionary has no valid groups.', 'mvweb-smart-search' ) );
		}

		return array(
			'slug'    => $slug,
			'name'    => isset( $data['name'] ) && is_string( $data['name'] ) ? sanitize_text_field( $data['name'] ) : $slug,
			'version' => isset( $data['version'] ) && is_string( $data['version'] ) ? sanitize_text_field( $data['version'] ) : '',
			'enabled' => true,
			'groups'  => $groups,
		);
	}

	/**
	 * Invalidate the search result cache after a dictionary change.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function flush(): void {
		if ( class_exists( 'MVweb_SS_Rest' ) ) {
			MVweb_SS_Rest::flush_cache();
		}
	}
}
