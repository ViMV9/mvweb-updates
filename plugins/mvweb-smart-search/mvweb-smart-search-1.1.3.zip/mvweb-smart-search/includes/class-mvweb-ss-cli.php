<?php
/**
 * WP-CLI commands (stats, search, clear-log). Reindex lives in the reindex class.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers auxiliary `wp mvweb-ss` subcommands for diagnostics and maintenance.
 *
 * @since 1.0.0
 */
class MVweb_SS_CLI {

	/**
	 * Register the CLI commands.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		if ( ! ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return;
		}

		\WP_CLI::add_command( 'mvweb-ss stats', array( __CLASS__, 'stats' ) );
		\WP_CLI::add_command( 'mvweb-ss search', array( __CLASS__, 'search' ) );
		\WP_CLI::add_command( 'mvweb-ss clear-log', array( __CLASS__, 'clear_log' ) );
	}

	/**
	 * Show index and log statistics.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-ss stats
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function stats(): void {
		global $wpdb;

		$index = MVweb_SS_Schema::table_name();
		$log   = MVweb_SS_Schema::log_table_name();

		$rows    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$index`" ); // phpcs:ignore WordPress.DB
		$objects = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT object_id) FROM `$index`" ); // phpcs:ignore WordPress.DB
		$logged  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$log`" ); // phpcs:ignore WordPress.DB
		$zero    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$log` WHERE results = 0" ); // phpcs:ignore WordPress.DB
		$meta    = MVweb_SS_Schema::get_meta();

		\WP_CLI::log( sprintf( 'Index rows:      %d', $rows ) );
		\WP_CLI::log( sprintf( 'Indexed objects: %d', $objects ) );
		\WP_CLI::log( sprintf( 'Logged queries:  %d (no-result: %d)', $logged, $zero ) );
		\WP_CLI::log( sprintf( 'Last reindex:    %s', isset( $meta['last_reindex'] ) ? gmdate( 'Y-m-d H:i', (int) $meta['last_reindex'] ) : 'never' ) );
	}

	/**
	 * Run a search from the command line.
	 *
	 * ## OPTIONS
	 *
	 * <query>
	 * : The search phrase.
	 *
	 * [--limit=<number>]
	 * : Maximum results. Default 10.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-ss search "герметик"
	 *     wp mvweb-ss search "клей" --limit=5
	 *
	 * @since 1.0.0
	 * @param array $args       Positional args.
	 * @param array $assoc_args Named args.
	 * @return void
	 */
	public static function search( array $args, array $assoc_args ): void {
		$query = isset( $args[0] ) ? (string) $args[0] : '';

		if ( '' === $query ) {
			\WP_CLI::error( 'Provide a query, e.g. wp mvweb-ss search "phrase".' );
			return;
		}

		$limit   = isset( $assoc_args['limit'] ) ? max( 1, (int) $assoc_args['limit'] ) : 10;
		$results = MVweb_SS_Query::search( $query, array( 'limit' => $limit ) );

		if ( empty( $results ) ) {
			\WP_CLI::success( 'No results.' );
			return;
		}

		$table = array();

		foreach ( $results as $row ) {
			$table[] = array(
				'id'    => (int) $row['object_id'],
				'type'  => (string) $row['object_type'],
				'score' => (float) $row['score'],
				'title' => (string) get_the_title( (int) $row['object_id'] ),
			);
		}

		\WP_CLI\Utils\format_items( 'table', $table, array( 'id', 'type', 'score', 'title' ) );
	}

	/**
	 * Empty the search query log.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-ss clear-log
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function clear_log(): void {
		global $wpdb;

		$log = MVweb_SS_Schema::log_table_name();
		$wpdb->query( "DELETE FROM `$log`" ); // phpcs:ignore WordPress.DB

		\WP_CLI::success( 'Search log cleared.' );
	}
}
