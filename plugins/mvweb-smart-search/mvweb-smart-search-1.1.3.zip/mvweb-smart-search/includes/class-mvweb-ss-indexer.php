<?php
/**
 * Indexer: writes an object's terms into the search index.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds and stores index rows for a single post/product/CPT object.
 *
 * @since 1.0.0
 */
class MVweb_SS_Indexer {

	const BATCH_ROWS = 200;

	/**
	 * Index (or re-index) a single object by ID.
	 *
	 * Not-indexable objects (draft, trashed, password-protected, wrong type)
	 * are removed from the index instead.
	 *
	 * @since 1.0.0
	 * @param int $object_id Post/product ID.
	 * @return void
	 */
	public static function index_object( int $object_id ): void {
		$post = get_post( $object_id );

		if ( ! $post instanceof WP_Post || ! self::is_indexable( $post ) ) {
			self::remove_object( $object_id );
			return;
		}

		self::write( $post->ID, $post->post_type, self::collect_sources( $post ) );
	}

	/**
	 * Remove all index rows for an object.
	 *
	 * @since 1.0.0
	 * @param int $object_id Object ID.
	 * @return void
	 */
	public static function remove_object( int $object_id ): void {
		global $wpdb;

		$table = MVweb_SS_Schema::table_name();
		$wpdb->query( $wpdb->prepare( "DELETE FROM `$table` WHERE object_id = %d", $object_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Number of distinct objects currently in the index (live count).
	 *
	 * The table holds one row per term, so distinct object_id is the real
	 * "items in index" figure.
	 *
	 * @since 1.0.3
	 * @return int
	 */
	public static function count_objects(): int {
		global $wpdb;

		$table = MVweb_SS_Schema::table_name();

		return (int) $wpdb->get_var( "SELECT COUNT(DISTINCT object_id) FROM `$table`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Post types eligible for indexing.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	public static function get_indexed_post_types(): array {
		$defaults = array( 'post', 'page' );

		if ( class_exists( 'WooCommerce' ) ) {
			$defaults[] = 'product';
		}

		$types = array_values( array_filter( array_unique( array_map( 'strval', (array) MVweb_SS_Settings::get( 'post_types', $defaults ) ) ) ) );

		if ( empty( $types ) ) {
			$types = $defaults;
		}

		$filtered = array_values( array_filter( array_unique( array_map( 'strval', (array) apply_filters( 'mvweb_ss_indexed_post_types', $types ) ) ) ) );

		return empty( $filtered ) ? $defaults : $filtered;
	}

	/**
	 * Validate a comma-separated post-type scope against the indexed set.
	 *
	 * @since 1.0.0
	 * @param string $csv Comma-separated post types.
	 * @return string[] Valid, unique types (empty means "all indexed types").
	 */
	public static function sanitize_types_csv( string $csv ): array {
		if ( '' === trim( $csv ) ) {
			return array();
		}

		$allowed = self::get_indexed_post_types();
		$picked  = array();

		foreach ( explode( ',', $csv ) as $type ) {
			$type = sanitize_key( trim( $type ) );

			if ( '' !== $type && in_array( $type, $allowed, true ) ) {
				$picked[] = $type;
			}
		}

		return array_values( array_unique( $picked ) );
	}

	/**
	 * Whether a post is eligible for the public index.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Post object.
	 * @return bool
	 */
	private static function is_indexable( WP_Post $post ): bool {
		if ( ! in_array( $post->post_type, self::get_indexed_post_types(), true ) ) {
			return false;
		}

		if ( 'publish' !== $post->post_status ) {
			return false;
		}

		if ( '' !== (string) $post->post_password ) {
			return false;
		}

		if ( class_exists( 'MVweb_SS_Editor' ) && MVweb_SS_Editor::is_excluded( $post->ID ) ) {
			return false;
		}

		if ( 'product' === $post->post_type
			&& class_exists( 'WooCommerce' )
			&& has_term( 'exclude-from-search', 'product_visibility', $post->ID ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Collect indexable text grouped by source.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Post object.
	 * @return array<string,string> source => text.
	 */
	private static function collect_sources( WP_Post $post ): array {
		$sources = array(
			'title'   => (string) $post->post_title,
			'content' => wp_strip_all_tags( strip_shortcodes( (string) $post->post_content ) ),
			'excerpt' => (string) $post->post_excerpt,
			'tax'     => self::collect_taxonomies( $post ),
		);

		$cf = self::collect_custom_fields( $post->ID );

		if ( '' !== $cf ) {
			$sources['cf'] = $cf;
		}

		if ( 'product' === $post->post_type && class_exists( 'WooCommerce' ) ) {
			$sources = array_merge( $sources, self::collect_woo( $post->ID ) );
		}

		return array_filter(
			$sources,
			static function ( $text ) {
				return is_string( $text ) && '' !== trim( $text );
			}
		);
	}

	/**
	 * Collect public taxonomy term names (product attributes handled separately).
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Post object.
	 * @return string
	 */
	private static function collect_taxonomies( WP_Post $post ): string {
		$names = array();

		foreach ( get_object_taxonomies( $post->post_type ) as $taxonomy ) {
			if ( 0 === strpos( $taxonomy, 'pa_' ) ) {
				continue;
			}

			if ( ! is_taxonomy_viewable( $taxonomy ) ) {
				continue;
			}

			$terms = get_the_terms( $post->ID, $taxonomy );

			if ( is_array( $terms ) ) {
				foreach ( $terms as $term ) {
					$names[] = $term->name;
				}
			}
		}

		return implode( ' ', $names );
	}

	/**
	 * Collect whitelisted custom field values (protected meta never indexed).
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return string
	 */
	private static function collect_custom_fields( int $post_id ): string {
		$whitelist = (array) MVweb_SS_Settings::get( 'cf_whitelist', array() );

		if ( empty( $whitelist ) ) {
			return '';
		}

		$values = array();

		foreach ( $whitelist as $key ) {
			$key = (string) $key;

			if ( '' === $key || '_' === $key[0] ) {
				continue;
			}

			foreach ( get_post_meta( $post_id, $key, false ) as $value ) {
				if ( is_scalar( $value ) ) {
					$values[] = (string) $value;
				}
			}
		}

		return implode( ' ', $values );
	}

	/**
	 * Collect WooCommerce-specific text (SKU, attributes, variation SKUs).
	 *
	 * @since 1.0.0
	 * @param int $product_id Product ID.
	 * @return array<string,string>
	 */
	private static function collect_woo( int $product_id ): array {
		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return array();
		}

		$out = array();

		$sku = $product->get_sku();

		if ( '' !== $sku ) {
			$out['sku'] = self::sku_forms( $sku );
		}

		$gtin = self::product_gtin( $product );

		if ( '' !== $gtin ) {
			$out['gtin'] = $gtin;
		}

		$brands = self::product_brands( $product_id );

		if ( '' !== $brands ) {
			$out['brand'] = $brands;
		}

		$attr_values = array();

		foreach ( $product->get_attributes() as $attribute ) {
			if ( $attribute->is_taxonomy() ) {
				$attr_values = array_merge(
					$attr_values,
					wc_get_product_terms( $product_id, $attribute->get_name(), array( 'fields' => 'names' ) )
				);
			} else {
				$attr_values = array_merge( $attr_values, $attribute->get_options() );
			}
		}

		if ( ! empty( $attr_values ) ) {
			$out['attr'] = implode( ' ', $attr_values );
		}

		if ( $product->is_type( 'variable' ) ) {
			$variation_skus = array();

			foreach ( $product->get_children() as $variation_id ) {
				$variation = wc_get_product( $variation_id );

				if ( $variation && '' !== $variation->get_sku() ) {
					$variation_skus[] = self::sku_forms( $variation->get_sku() );
				}
			}

			if ( ! empty( $variation_skus ) ) {
				$out['variation_sku'] = implode( ' ', $variation_skus );
			}
		}

		return $out;
	}

	/**
	 * Both the raw SKU and its punctuation-stripped form as one string.
	 *
	 * A SKU like "123456-123" is indexed as-is (so its parts stay searchable)
	 * and also collapsed to "123456123", so a shopper who types the digits
	 * without the dash still finds the product. Identical forms are not doubled.
	 *
	 * @since 1.1.0
	 * @param string $sku Raw SKU.
	 * @return string
	 */
	private static function sku_forms( string $sku ): string {
		$collapsed = (string) preg_replace( '/[^\p{L}\p{N}]+/u', '', $sku );

		return ( '' !== $collapsed && $collapsed !== $sku ) ? $sku . ' ' . $collapsed : $sku;
	}

	/**
	 * Product GTIN/UPC/EAN (native WooCommerce field, meta fallback).
	 *
	 * @since 1.0.0
	 * @param WC_Product $product Product.
	 * @return string
	 */
	private static function product_gtin( $product ): string {
		if ( method_exists( $product, 'get_global_unique_id' ) ) {
			$gtin = (string) $product->get_global_unique_id();

			if ( '' !== $gtin ) {
				return $gtin;
			}
		}

		return (string) get_post_meta( $product->get_id(), '_global_unique_id', true );
	}

	/**
	 * Product brand names from the common brand taxonomies.
	 *
	 * @since 1.0.0
	 * @param int $product_id Product ID.
	 * @return string
	 */
	private static function product_brands( int $product_id ): string {
		$names = array();

		/**
		 * Filter the taxonomies treated as product brands.
		 *
		 * @since 1.0.0
		 * @param string[] $taxonomies Brand taxonomy slugs.
		 */
		$taxonomies = (array) apply_filters(
			'mvweb_ss_brand_taxonomies',
			array( 'product_brand', 'pwb-brand', 'yith_product_brand', 'berocket_brand' )
		);

		foreach ( $taxonomies as $taxonomy ) {
			if ( ! taxonomy_exists( $taxonomy ) ) {
				continue;
			}

			$terms = wp_get_post_terms( $product_id, $taxonomy, array( 'fields' => 'names' ) );

			if ( ! is_wp_error( $terms ) ) {
				$names = array_merge( $names, $terms );
			}
		}

		return implode( ' ', array_values( array_unique( $names ) ) );
	}

	/**
	 * Replace the object's index rows with freshly tokenized terms.
	 *
	 * @since 1.0.0
	 * @param int                  $object_id   Object ID.
	 * @param string               $object_type Post type.
	 * @param array<string,string> $sources     source => text.
	 * @return void
	 */
	private static function write( int $object_id, string $object_type, array $sources ): void {
		$table = MVweb_SS_Schema::table_name();
		$lang  = substr( get_locale(), 0, 2 );

		self::remove_object( $object_id );

		$placeholders = array();
		$values       = array();

		foreach ( $sources as $source => $text ) {
			foreach ( MVweb_SS_Tokenizer::tokenize( (string) $text ) as $term => $count ) {
				$placeholders[] = '(%d,%s,%s,%s,%d,%s)';
				array_push( $values, $object_id, $term, $object_type, (string) $source, $count, $lang );

				if ( count( $placeholders ) >= self::BATCH_ROWS ) {
					self::flush( $table, $placeholders, $values );
					$placeholders = array();
					$values       = array();
				}
			}
		}

		if ( ! empty( $placeholders ) ) {
			self::flush( $table, $placeholders, $values );
		}
	}

	/**
	 * Execute one batched INSERT.
	 *
	 * @since 1.0.0
	 * @param string   $table        Table name.
	 * @param string[] $placeholders Row placeholder groups.
	 * @param array    $values       Flat prepared values.
	 * @return void
	 */
	private static function flush( string $table, array $placeholders, array $values ): void {
		global $wpdb;

		$sql = "INSERT INTO `$table` (object_id, term, object_type, source, count, lang) VALUES " . implode( ',', $placeholders );
		$wpdb->query( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
	}
}
