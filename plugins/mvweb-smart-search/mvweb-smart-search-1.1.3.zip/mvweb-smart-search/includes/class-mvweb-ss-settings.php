<?php
/**
 * Central read access to plugin settings.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Single source of truth for the `mvweb_ss_settings` option.
 *
 * @since 1.0.0
 */
class MVweb_SS_Settings {

	const OPTION = 'mvweb_ss_settings';

	/**
	 * Default settings.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function defaults(): array {
		$types = array( 'post', 'page' );

		if ( class_exists( 'WooCommerce' ) ) {
			$types[] = 'product';
		}

		return array(
			'post_types'           => $types,
			'cf_whitelist'         => array(),
			'fuzzy'                => true,
			'strictness'           => 'balanced',
			'title_coverage'       => false,
			'click_boost'          => false,
			'click_boost_strength' => 30,
			'weekly_digest'        => false,
			'digest_email'         => '',
			'revenue_tracking'     => false,
			'auto_replace'         => true,
			'stock'                => 'show',
			'add_to_cart'          => true,
			'weights'              => array(),
			'synonyms'             => '',
			'stopwords'            => '',
			'exclude_ids'          => array(),
			'pins'                 => '',
			'redirects'            => '',
			'accent_color'         => '#793ea4',
			'placeholder'          => '',
			'text_no_results'      => '',
			'zero_cta_text'        => '',
			'zero_cta_url'         => '',
			'text_see_all'         => '',
			'panel_width'          => 640,
			'show_image'           => true,
			'show_price'           => true,
			'show_stock'           => true,
			'show_excerpt'         => true,
			'show_categories'      => true,
			'show_brands'          => true,
			'cat_limit'            => 5,
			'filter_tabs'          => true,
			'details_panel'        => true,
			'mobile_overlay'       => true,
			'min_chars'            => 2,
			'debounce_ms'          => 200,
			'sugg_limit'           => 10,
			'per_group_limit'      => 0,
			'highlight'            => true,
			'fuzzy_notice'         => 'silent',
			'group_order'          => 'products',
			'results_per_page'     => 0,
			'layout'               => 'list',
			'search_history'       => true,
			'popular_searches'     => true,
			'popular_limit'        => 6,
			'cat_selector'         => false,
			'cat_taxonomy'         => class_exists( 'WooCommerce' ) ? 'product_cat' : 'category',
			'bar_size'             => 'm',
			'bar_radius'           => 'rounded',
			'bar_border_color'     => '',
			'bar_bg_color'         => '',
			'bar_text_color'       => '',
			'bar_max_width'        => 520,
			'bar_height'           => 0,
			'bar_font_size'        => 0,
			'text_weight'          => 'normal',
			'submit_style'         => 'icon',
			'submit_text'          => '',
			'input_icon'           => false,
			'icon_plain'           => false,
			'icon_color'           => '',
			'display_desktop'      => 'bar',
			'display_mobile'       => 'bar',
			'link_text'            => '',
		);
	}

	/**
	 * Custom stop words (lowercased, ё→е), merged into the tokenizer.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	public static function custom_stopwords(): array {
		$out = array();

		foreach ( preg_split( '/[\r\n]+/', (string) self::get( 'stopwords', '' ) ) as $line ) {
			$word = str_replace( 'ё', 'е', mb_strtolower( trim( (string) $line ), 'UTF-8' ) );

			if ( '' !== $word ) {
				$out[] = $word;
			}
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Synonym rules from the local textarea and installed dictionary packs.
	 *
	 * Each rule matches when the query contains ALL of its pattern stems
	 * (order-independent) and then contributes the stems of every other
	 * entry in the same group. Multi-word entries ("жидкие гвозди") are
	 * tokenized with the same stemmer the index uses, so phrases match.
	 *
	 * @since 1.0.0
	 * @return array<int,array{pattern:string[],add:string[]}>
	 */
	public static function synonym_map(): array {
		$groups = self::local_synonym_groups();

		if ( class_exists( 'MVweb_SS_Dictionaries' ) ) {
			$groups = array_merge( $groups, MVweb_SS_Dictionaries::active_groups() );
		}

		return self::build_rules_from_groups( $groups );
	}

	/**
	 * Parse the local synonyms textarea into groups of interchangeable entries.
	 *
	 * @since 1.0.0
	 * @return array<int,string[]> Each group is a list of raw phrase strings.
	 */
	private static function local_synonym_groups(): array {
		$groups = array();

		foreach ( preg_split( '/[\r\n]+/', (string) self::get( 'synonyms', '' ) ) as $line ) {
			$entries = array();

			foreach ( explode( ',', (string) $line ) as $phrase ) {
				$phrase = trim( (string) $phrase );

				if ( '' !== $phrase ) {
					$entries[] = $phrase;
				}
			}

			$entries = array_values( array_unique( $entries ) );

			if ( count( $entries ) >= 2 ) {
				$groups[] = $entries;
			}
		}

		return $groups;
	}

	/**
	 * Turn interchangeable-entry groups into phrase-aware synonym rules.
	 *
	 * @since 1.0.0
	 * @param array<int,string[]> $groups Groups of raw phrase strings.
	 * @return array<int,array{pattern:string[],add:string[]}>
	 */
	private static function build_rules_from_groups( array $groups ): array {
		$rules = array();

		foreach ( $groups as $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}

			$variants = array();

			foreach ( $group as $phrase ) {
				$stems = array_values( array_keys( MVweb_SS_Tokenizer::tokenize( (string) $phrase ) ) );

				if ( ! empty( $stems ) ) {
					$variants[] = $stems;
				}
			}

			if ( count( $variants ) < 2 ) {
				continue;
			}

			foreach ( $variants as $i => $pattern ) {
				$add = array();

				foreach ( $variants as $j => $other ) {
					if ( $i !== $j ) {
						$add = array_merge( $add, $other );
					}
				}

				$rules[] = array(
					'pattern' => $pattern,
					'add'     => array_values( array_unique( $add ) ),
				);
			}
		}

		return $rules;
	}

	/**
	 * Object IDs excluded from search results.
	 *
	 * @since 1.0.0
	 * @return int[]
	 */
	public static function excluded_ids(): array {
		$out = array();

		foreach ( (array) self::get( 'exclude_ids', array() ) as $id ) {
			$id = (int) $id;

			if ( $id > 0 ) {
				$out[] = $id;
			}
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Pinned object IDs for a normalized query, or an empty array.
	 *
	 * Each line: `query => id, id`. Match is on the normalized whole query.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @return int[]
	 */
	public static function pins_for( string $query ): array {
		$key = self::normalize_query( $query );

		if ( '' === $key ) {
			return array();
		}

		foreach ( preg_split( '/[\r\n]+/', (string) self::get( 'pins', '' ) ) as $line ) {
			$parts = explode( '=>', (string) $line, 2 );

			if ( count( $parts ) < 2 || self::normalize_query( $parts[0] ) !== $key ) {
				continue;
			}

			$ids = array();

			foreach ( explode( ',', $parts[1] ) as $id ) {
				$id = (int) trim( $id );

				if ( $id > 0 ) {
					$ids[] = $id;
				}
			}

			return array_values( array_unique( $ids ) );
		}

		return array();
	}

	/**
	 * Redirect URL configured for an exact query, or an empty string.
	 *
	 * Each line: `query => https://example.com/target`.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @return string
	 */
	public static function redirect_for( string $query ): string {
		$key = self::normalize_query( $query );

		if ( '' === $key ) {
			return '';
		}

		foreach ( preg_split( '/[\r\n]+/', (string) self::get( 'redirects', '' ) ) as $line ) {
			$parts = explode( '=>', (string) $line, 2 );

			if ( count( $parts ) < 2 || self::normalize_query( $parts[0] ) !== $key ) {
				continue;
			}

			$url = esc_url_raw( trim( $parts[1] ) );

			if ( '' !== $url ) {
				return $url;
			}
		}

		return '';
	}

	/**
	 * Normalize a query string for pin matching.
	 *
	 * @since 1.0.0
	 * @param string $query Query.
	 * @return string
	 */
	private static function normalize_query( string $query ): string {
		$query = str_replace( 'ё', 'е', mb_strtolower( trim( $query ), 'UTF-8' ) );

		return (string) preg_replace( '/\s+/u', ' ', $query );
	}

	/**
	 * All settings merged with defaults.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function all(): array {
		$saved = get_option( self::OPTION, array() );

		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	/**
	 * A single setting value.
	 *
	 * @since 1.0.0
	 * @param string $key      Setting key.
	 * @param mixed  $fallback Fallback value when the key is unset.
	 * @return mixed
	 */
	public static function get( string $key, $fallback = null ) {
		$all = self::all();

		return array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
	}
}
