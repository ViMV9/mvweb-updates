<?php
/**
 * Main-query search interception.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Replaces the default WordPress search on the front-end results page with
 * index-ranked results, leaving the admin search untouched.
 *
 * @since 1.0.0
 */
class MVweb_SS_Search {

	const MAIN_LIMIT = 100;

	/**
	 * Register interception hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_redirect' ), 5 );
		add_action( 'pre_get_posts', array( __CLASS__, 'intercept' ), 20 );
		add_filter( 'posts_search', array( __CLASS__, 'blank_default_search' ), 10, 2 );
	}

	/**
	 * Redirect a matching search to its configured target before rendering.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function maybe_redirect(): void {
		if ( is_admin() || ! is_search() ) {
			return;
		}

		$term = trim( (string) get_search_query( false ) );

		if ( '' === $term ) {
			return;
		}

		$url = MVweb_SS_Settings::redirect_for( $term );

		if ( '' !== $url ) {
			wp_redirect( $url ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- admin-configured trusted target, query must match exactly.
			exit;
		}
	}

	/**
	 * Rewrite the front-end main search query to use the index.
	 *
	 * @since 1.0.0
	 * @param WP_Query $query Query.
	 * @return void
	 */
	public static function intercept( $query ): void {
		if ( is_admin() || ! $query instanceof WP_Query || ! $query->is_main_query() || ! $query->is_search() ) {
			return;
		}

		$term = trim( (string) $query->get( 's' ) );

		if ( '' === $term ) {
			return;
		}

		$scope = self::scoped_types();
		$types = empty( $scope ) ? MVweb_SS_Indexer::get_indexed_post_types() : $scope;
		$args  = array( 'limit' => self::MAIN_LIMIT );

		if ( ! empty( $scope ) ) {
			$args['post_types'] = $scope;
		}

		$category = self::scoped_category();

		if ( ! empty( $category['term_ids'] ) ) {
			$args['term_ids'] = $category['term_ids'];
			$args['taxonomy'] = $category['taxonomy'];
		}

		$ids = MVweb_SS_Query::search_ids( $term, $args );

		MVweb_SS_Log::record( $term, count( $ids ) );

		$query->set( 'mvweb_ss', true );
		$query->set( 'post_type', $types );
		$query->set( 'post__in', empty( $ids ) ? array( 0 ) : $ids );
		$query->set( 'orderby', 'post__in' );
		$query->set( 'ignore_sticky_posts', true );

		$per_page = (int) MVweb_SS_Settings::get( 'results_per_page', 0 );

		if ( $per_page > 0 ) {
			$query->set( 'posts_per_page', min( self::MAIN_LIMIT, $per_page ) );
		}
	}

	/**
	 * Post-type scope requested by a scoped search form, validated.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	private static function scoped_types(): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only public search scope, like the `s` query var.
		if ( ! isset( $_GET['mvweb_ss_types'] ) ) {
			return array();
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$raw = sanitize_text_field( wp_unslash( $_GET['mvweb_ss_types'] ) );

		return MVweb_SS_Indexer::sanitize_types_csv( $raw );
	}

	/**
	 * Category filter requested by the search form, resolved to term IDs.
	 *
	 * @since 1.0.0
	 * @return array{term_ids:int[],taxonomy:string}
	 */
	private static function scoped_category(): array {
		$empty = array(
			'term_ids' => array(),
			'taxonomy' => '',
		);

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only public search scope, like the `s` query var.
		if ( ! isset( $_GET['mvweb_ss_cat'] ) || ! MVweb_SS_Settings::get( 'cat_selector', false ) ) {
			return $empty;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$cat = absint( wp_unslash( $_GET['mvweb_ss_cat'] ) );

		if ( $cat <= 0 ) {
			return $empty;
		}

		$taxonomy = (string) MVweb_SS_Settings::get( 'cat_taxonomy', '' );
		$term_ids = MVweb_SS_Query::term_and_children( $cat, $taxonomy );

		return empty( $term_ids ) ? $empty : array(
			'term_ids' => $term_ids,
			'taxonomy' => $taxonomy,
		);
	}

	/**
	 * Remove the default LIKE search clause for our intercepted query.
	 *
	 * @since 1.0.0
	 * @param string   $search Search SQL.
	 * @param WP_Query $query  Query.
	 * @return string
	 */
	public static function blank_default_search( $search, $query ) {
		if ( $query instanceof WP_Query && $query->get( 'mvweb_ss' ) ) {
			return '';
		}

		return $search;
	}
}
