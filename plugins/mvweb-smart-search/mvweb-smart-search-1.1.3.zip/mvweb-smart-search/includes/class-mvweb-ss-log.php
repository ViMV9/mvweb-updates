<?php
/**
 * Search query log (foundation for analytics).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Records aggregated search queries: how often each phrase is searched and
 * how many results it returned last time (drives "no results" reporting).
 *
 * @since 1.0.0
 */
class MVweb_SS_Log {

	const MAX_LENGTH = 191;

	/**
	 * Canonical hash of a query, shared by logging and click-boost lookups.
	 *
	 * @since 1.1.0
	 * @param string $query Raw query.
	 * @return string 32-char md5, or '' for an empty query.
	 */
	public static function hash( string $query ): string {
		$query = trim( wp_strip_all_tags( $query ) );
		$query = mb_substr( $query, 0, self::MAX_LENGTH, 'UTF-8' );

		return '' === $query ? '' : md5( mb_strtolower( $query, 'UTF-8' ) );
	}

	/**
	 * Record one search.
	 *
	 * @since 1.0.0
	 * @param string $query   Raw user query.
	 * @param int    $results Result count for this query.
	 * @return void
	 */
	public static function record( string $query, int $results ): void {
		$query = trim( wp_strip_all_tags( $query ) );
		$query = mb_substr( $query, 0, self::MAX_LENGTH, 'UTF-8' );

		if ( '' === $query ) {
			return;
		}

		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$hash  = self::hash( $query );

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				'INSERT INTO %i (query_hash, query, hits, results, updated) VALUES (%s, %s, 1, %d, %s)
				ON DUPLICATE KEY UPDATE hits = hits + 1, results = VALUES(results), updated = VALUES(updated)',
				$table,
				$hash,
				$query,
				max( 0, $results ),
				current_time( 'mysql' )
			)
		);
	}

	/**
	 * Record one click on a result for a query.
	 *
	 * Updates the existing log row (the query was logged as an impression when
	 * its dropdown was shown), so no phantom rows are created.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @return void
	 */
	public static function record_click( string $query ): void {
		$hash = self::hash( $query );

		if ( '' === $hash ) {
			return;
		}

		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				'UPDATE %i SET clicks = clicks + 1 WHERE query_hash = %s',
				$table,
				$hash
			)
		);
	}

	/**
	 * Record a click on a specific result for a query (self-learning boost).
	 *
	 * Accumulates per (query, result) so the ranking can gently float results
	 * that shoppers actually pick for that query. Kept separate from the
	 * per-query click tally used for CTR.
	 *
	 * @since 1.1.0
	 * @param string $query     Raw user query.
	 * @param int    $object_id Clicked object ID.
	 * @return void
	 */
	public static function record_result_click( string $query, int $object_id ): void {
		$hash = self::hash( $query );

		if ( '' === $hash || $object_id <= 0 ) {
			return;
		}

		global $wpdb;

		$table = MVweb_SS_Schema::clicks_table_name();

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				'INSERT INTO %i (query_hash, object_id, clicks) VALUES (%s, %d, 1)
				ON DUPLICATE KEY UPDATE clicks = clicks + 1',
				$table,
				$hash,
				$object_id
			)
		);
	}
}
