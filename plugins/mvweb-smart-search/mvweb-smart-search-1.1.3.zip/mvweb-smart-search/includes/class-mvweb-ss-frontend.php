<?php
/**
 * Front-end presentation: search form, shortcode, block, form replacement.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the search bar (one markup source shared by shortcode, block and
 * theme form replacement) and enqueues the live-dropdown assets.
 *
 * @since 1.0.0
 */
class MVweb_SS_Frontend {

	/**
	 * Register front-end hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_shortcode( 'mvweb_ss', array( __CLASS__, 'shortcode' ) );
		add_action( 'init', array( __CLASS__, 'register_block' ) );
		add_filter( 'get_search_form', array( __CLASS__, 'replace_get_search_form' ), 20 );
		add_filter( 'render_block_core/search', array( __CLASS__, 'replace_core_search' ), 10, 2 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'update_option_' . MVweb_SS_Settings::OPTION, array( __CLASS__, 'flush_popular' ) );
	}

	/**
	 * Popular queries (results > 0) for the empty-focus suggestions, cached
	 * for an hour so it costs one query per hour, not one per page view.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	private static function popular_queries(): array {
		if ( ! MVweb_SS_Settings::get( 'popular_searches', true ) ) {
			return array();
		}

		$cached = get_transient( 'mvweb_ss_popular' );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		$limit = max( 1, min( 20, (int) MVweb_SS_Settings::get( 'popular_limit', 6 ) ) );
		$rows  = MVweb_SS_Analytics::popular_queries( $limit );

		set_transient( 'mvweb_ss_popular', $rows, HOUR_IN_SECONDS );

		return $rows;
	}

	/**
	 * Drop the popular-queries cache when settings change (limit/toggle).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function flush_popular(): void {
		delete_transient( 'mvweb_ss_popular' );
	}

	/**
	 * Single source of the search-bar markup.
	 *
	 * @since 1.0.0
	 * @param array $args Optional overrides (placeholder).
	 * @return string
	 */
	public static function render_form( array $args = array() ): string {
		if ( isset( $args['placeholder'] ) && '' !== $args['placeholder'] ) {
			$placeholder = (string) $args['placeholder'];
		} else {
			$custom      = (string) MVweb_SS_Settings::get( 'placeholder', '' );
			$placeholder = '' !== $custom ? $custom : __( 'Search the site…', 'mvweb-smart-search' );
		}

		$accent = isset( $args['accent'] ) ? sanitize_hex_color( (string) $args['accent'] ) : '';
		$scope  = isset( $args['types'] ) ? implode( ',', MVweb_SS_Indexer::sanitize_types_csv( (string) $args['types'] ) ) : '';

		$classes     = self::form_classes();
		$submit_text = (string) MVweb_SS_Settings::get( 'submit_text', '' );
		$submit_text = '' !== $submit_text ? $submit_text : __( 'Find', 'mvweb-smart-search' );
		$link_text   = (string) MVweb_SS_Settings::get( 'link_text', '' );
		$link_text   = '' !== $link_text ? $link_text : __( 'Search', 'mvweb-smart-search' );
		$selector    = self::category_selector();

		ob_start();
		?>
		<form role="search" method="get" class="<?php echo esc_attr( $classes ); ?>" action="<?php echo esc_url( home_url( '/' ) ); ?>"
			<?php
			if ( $accent ) :
				?>
				style="--mvweb-ss-accent:<?php echo esc_attr( $accent ); ?>"<?php endif; ?>
			<?php
			if ( '' !== $scope ) :
				?>
				data-types="<?php echo esc_attr( $scope ); ?>"<?php endif; ?>>
			<?php
			// wp_dropdown_categories() returns an escaped <select>; nothing user-controlled is echoed.
			echo $selector; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?>
			<input
				type="search"
				name="s"
				class="mvweb-ss__input"
				autocomplete="off"
				placeholder="<?php echo esc_attr( $placeholder ); ?>"
				value="<?php echo esc_attr( get_search_query() ); ?>"
				aria-label="<?php esc_attr_e( 'Search the site', 'mvweb-smart-search' ); ?>">
			<button type="button" class="mvweb-ss__clear" aria-label="<?php esc_attr_e( 'Clear search', 'mvweb-smart-search' ); ?>" hidden></button>
			<button type="submit" class="mvweb-ss__submit" aria-label="<?php esc_attr_e( 'Find', 'mvweb-smart-search' ); ?>">
				<span class="mvweb-ss__submit-icon" aria-hidden="true"></span>
				<span class="mvweb-ss__submit-text"><?php echo esc_html( $submit_text ); ?></span>
				<span class="mvweb-ss__word"><?php echo esc_html( $link_text ); ?></span>
			</button>
			<?php if ( '' !== $scope ) : ?>
				<input type="hidden" name="mvweb_ss_types" value="<?php echo esc_attr( $scope ); ?>">
			<?php endif; ?>
			<div class="mvweb-ss__panel" hidden></div>
		</form>
		<?php
		return trim( (string) ob_get_clean() );
	}

	/**
	 * Modifier classes for the form from appearance settings.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function form_classes(): string {
		$classes = array( 'mvweb-ss' );

		switch ( (string) MVweb_SS_Settings::get( 'submit_style', 'icon' ) ) {
			case 'text':
				$classes[] = 'mvweb-ss--submit-text';
				break;
			case 'hidden':
				$classes[] = 'mvweb-ss--submit-hidden';
				break;
		}

		if ( MVweb_SS_Settings::get( 'input_icon', false ) ) {
			$classes[] = 'mvweb-ss--icon-inside';
		}

		if ( MVweb_SS_Settings::get( 'icon_plain', false ) ) {
			$classes[] = 'mvweb-ss--icon-plain';
		}

		switch ( (string) MVweb_SS_Settings::get( 'display_desktop', 'bar' ) ) {
			case 'icon':
				$classes[] = 'mvweb-ss--icon-desktop';
				break;
			case 'word':
				$classes[] = 'mvweb-ss--word-desktop';
				break;
		}

		switch ( (string) MVweb_SS_Settings::get( 'display_mobile', 'bar' ) ) {
			case 'icon':
				$classes[] = 'mvweb-ss--icon-mobile';
				break;
			case 'word':
				$classes[] = 'mvweb-ss--word-mobile';
				break;
		}

		return implode( ' ', $classes );
	}

	/**
	 * Pre-search category selector (a hierarchical taxonomy dropdown) or an
	 * empty string when disabled or the taxonomy is invalid.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function category_selector(): string {
		if ( ! MVweb_SS_Settings::get( 'cat_selector', false ) ) {
			return '';
		}

		$taxonomy = (string) MVweb_SS_Settings::get( 'cat_taxonomy', 'category' );

		if ( ! taxonomy_exists( $taxonomy ) ) {
			return '';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only public search scope, like the `s` query var.
		$selected = isset( $_GET['mvweb_ss_cat'] ) ? absint( wp_unslash( $_GET['mvweb_ss_cat'] ) ) : 0;

		$dropdown = wp_dropdown_categories(
			array(
				'echo'            => 0,
				'taxonomy'        => $taxonomy,
				'hierarchical'    => 1,
				'hide_empty'      => 1,
				'value_field'     => 'term_id',
				'orderby'         => 'name',
				'show_option_all' => __( 'All categories', 'mvweb-smart-search' ),
				'name'            => 'mvweb_ss_cat',
				'id'              => wp_unique_id( 'mvweb-ss-cat-' ),
				'class'           => 'mvweb-ss__scope',
				'selected'        => $selected,
			)
		);

		return is_string( $dropdown ) ? $dropdown : '';
	}

	/**
	 * Inline CSS custom properties driving the search-bar look.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function bar_style_vars(): string {
		$accent = sanitize_hex_color( (string) MVweb_SS_Settings::get( 'accent_color', '#793ea4' ) );
		$accent = $accent ? $accent : '#793ea4';
		$width  = max( 320, min( 1200, (int) MVweb_SS_Settings::get( 'panel_width', 640 ) ) );

		$sizes = array(
			's' => array( 7, 11, 13, 40 ),
			'm' => array( 10, 14, 15, 46 ),
			'l' => array( 13, 17, 17, 52 ),
		);
		$size  = (string) MVweb_SS_Settings::get( 'bar_size', 'm' );
		$size  = isset( $sizes[ $size ] ) ? $sizes[ $size ] : $sizes['m'];

		$radii  = array(
			'square'  => '0',
			'rounded' => '8px',
			'pill'    => '999px',
		);
		$radius = (string) MVweb_SS_Settings::get( 'bar_radius', 'rounded' );
		$radius = isset( $radii[ $radius ] ) ? $radii[ $radius ] : $radii['rounded'];

		$maxw = max( 200, min( 1200, (int) MVweb_SS_Settings::get( 'bar_max_width', 520 ) ) );

		$font   = (int) MVweb_SS_Settings::get( 'bar_font_size', 0 );
		$font   = $font > 0 ? $font : $size[2];
		$height = (int) MVweb_SS_Settings::get( 'bar_height', 0 );

		$weights = array(
			'normal' => 400,
			'medium' => 500,
			'bold'   => 700,
		);
		$weight  = (string) MVweb_SS_Settings::get( 'text_weight', 'normal' );
		$weight  = isset( $weights[ $weight ] ) ? $weights[ $weight ] : 400;

		$vars  = '--mvweb-ss-accent:' . $accent;
		$vars .= ';--mvweb-ss-panel-width:' . $width . 'px';
		$vars .= ';--mvweb-ss-radius:' . $radius;
		$vars .= ';--mvweb-ss-max-width:' . $maxw . 'px';
		$vars .= ';--mvweb-ss-pad-y:' . $size[0] . 'px';
		$vars .= ';--mvweb-ss-pad-x:' . $size[1] . 'px';
		$vars .= ';--mvweb-ss-font-size:' . $font . 'px';
		$vars .= ';--mvweb-ss-weight:' . $weight;
		$vars .= ';--mvweb-ss-submit-w:' . $size[3] . 'px';

		if ( $height > 0 ) {
			$vars .= ';--mvweb-ss-height:' . $height . 'px';
		}

		$border = sanitize_hex_color( (string) MVweb_SS_Settings::get( 'bar_border_color', '' ) );
		if ( $border ) {
			$vars .= ';--mvweb-ss-border:' . $border;
		}

		$field_bg = sanitize_hex_color( (string) MVweb_SS_Settings::get( 'bar_bg_color', '' ) );
		if ( $field_bg ) {
			$vars .= ';--mvweb-ss-field-bg:' . $field_bg;
		}

		$text = sanitize_hex_color( (string) MVweb_SS_Settings::get( 'bar_text_color', '' ) );
		if ( $text ) {
			$vars .= ';--mvweb-ss-text:' . $text;
		}

		$icon = sanitize_hex_color( (string) MVweb_SS_Settings::get( 'icon_color', '' ) );
		if ( $icon ) {
			$vars .= ';--mvweb-ss-icon:' . $icon;
		}

		return $vars;
	}

	/**
	 * Shortcode handler.
	 *
	 * @since 1.0.0
	 * @param array|string $atts Attributes.
	 * @return string
	 */
	public static function shortcode( $atts ): string {
		return self::render_form( is_array( $atts ) ? $atts : array() );
	}

	/**
	 * Register the dynamic search block.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_block(): void {
		if ( ! function_exists( 'register_block_type' ) ) {
			return;
		}

		wp_register_script(
			'mvweb-ss-block',
			MVWEB_SS_URL . 'blocks/search/index.js',
			array( 'wp-blocks', 'wp-element', 'wp-server-side-render', 'wp-i18n' ),
			mvweb_ss_asset_ver( 'blocks/search/index.js' ),
			true
		);

		wp_set_script_translations( 'mvweb-ss-block', 'mvweb-smart-search', MVWEB_SS_PATH . 'languages' );

		register_block_type(
			'mvweb-ss/search',
			array(
				'api_version'     => 3,
				'editor_script'   => 'mvweb-ss-block',
				'render_callback' => array( __CLASS__, 'render_block' ),
			)
		);
	}

	/**
	 * Block render callback.
	 *
	 * @since 1.0.0
	 * @param array $attributes Block attributes.
	 * @return string
	 */
	public static function render_block( $attributes ): string {
		return self::render_form( is_array( $attributes ) ? $attributes : array() );
	}

	/**
	 * Replace the classic theme search form.
	 *
	 * @since 1.0.0
	 * @param string $form Original form markup.
	 * @return string
	 */
	public static function replace_get_search_form( $form ): string {
		if ( is_admin() || ! MVweb_SS_Settings::get( 'auto_replace', true ) ) {
			return (string) $form;
		}

		return self::render_form();
	}

	/**
	 * Replace the core/search block on block themes.
	 *
	 * @since 1.0.0
	 * @param string $content Rendered block HTML.
	 * @param array  $block   Parsed block.
	 * @return string
	 */
	public static function replace_core_search( $content, $block ): string {
		unset( $block );

		if ( ! is_admin() && MVweb_SS_Settings::get( 'auto_replace', true ) ) {
			return self::render_form();
		}

		return (string) $content;
	}

	/**
	 * Preferred result-group ordering as a list of type slugs.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	private static function group_order_slugs(): array {
		switch ( (string) MVweb_SS_Settings::get( 'group_order', 'products' ) ) {
			case 'content':
				return array( 'post', 'page', 'product' );
			case 'pages':
				return array( 'page', 'post', 'product' );
			default:
				return array( 'product', 'post', 'page' );
		}
	}

	/**
	 * Enqueue dropdown assets on the front-end.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function enqueue(): void {
		if ( is_admin() ) {
			return;
		}

		wp_enqueue_style( 'mvweb-ss', MVWEB_SS_URL . 'public/css/public.css', array(), mvweb_ss_asset_ver( 'public/css/public.css' ) );
		wp_enqueue_script( 'mvweb-ss', MVWEB_SS_URL . 'public/js/public.js', array(), mvweb_ss_asset_ver( 'public/js/public.js' ), true );

		wp_add_inline_style( 'mvweb-ss', '.mvweb-ss{' . self::bar_style_vars() . '}' );

		if ( class_exists( 'WooCommerce' ) && MVweb_SS_Settings::get( 'add_to_cart', true ) ) {
			wp_enqueue_script( 'wc-add-to-cart' );
		}

		$no_results = (string) MVweb_SS_Settings::get( 'text_no_results', '' );
		$see_all    = (string) MVweb_SS_Settings::get( 'text_see_all', '' );

		wp_localize_script(
			'mvweb-ss',
			'mvwebSS',
			array(
				'rest'        => esc_url_raw( rest_url( MVweb_SS_Rest::NAMESPACE . MVweb_SS_Rest::ROUTE ) ),
				'click'       => esc_url_raw( rest_url( MVweb_SS_Rest::NAMESPACE . MVweb_SS_Rest::CLICK_ROUTE ) ),
				'minChars'    => max( 1, (int) MVweb_SS_Settings::get( 'min_chars', 2 ) ),
				'debounce'    => max( 0, (int) MVweb_SS_Settings::get( 'debounce_ms', 200 ) ),
				'limit'       => max( 1, (int) MVweb_SS_Settings::get( 'sugg_limit', 10 ) ),
				'perGroup'    => max( 0, (int) MVweb_SS_Settings::get( 'per_group_limit', 0 ) ),
				'filterTabs'  => (bool) MVweb_SS_Settings::get( 'filter_tabs', true ),
				'layout'      => 'grid' === MVweb_SS_Settings::get( 'layout', 'list' ) ? 'grid' : 'list',
				'history'     => (bool) MVweb_SS_Settings::get( 'search_history', true ),
				'popular'     => self::popular_queries(),
				'highlight'   => (bool) MVweb_SS_Settings::get( 'highlight', true ),
				'fuzzyNotice' => (string) MVweb_SS_Settings::get( 'fuzzy_notice', 'silent' ),
				'groupOrder'  => self::group_order_slugs(),
				'show'        => array(
					'image'   => (bool) MVweb_SS_Settings::get( 'show_image', true ),
					'price'   => (bool) MVweb_SS_Settings::get( 'show_price', true ),
					'stock'   => (bool) MVweb_SS_Settings::get( 'show_stock', true ),
					'excerpt' => (bool) MVweb_SS_Settings::get( 'show_excerpt', true ),
				),
				'panel'       => array(
					'details' => (bool) MVweb_SS_Settings::get( 'details_panel', true ),
					'overlay' => (bool) MVweb_SS_Settings::get( 'mobile_overlay', true ),
				),
				'zeroCta'     => array(
					'text' => (string) MVweb_SS_Settings::get( 'zero_cta_text', '' ),
					'url'  => esc_url_raw( (string) MVweb_SS_Settings::get( 'zero_cta_url', '' ) ),
				),
				'revenue'     => MVweb_SS_Revenue::is_active(),
				'i18n'        => array(
					'nothing'    => '' !== $no_results ? $no_results : __( 'Nothing found', 'mvweb-smart-search' ),
					'all'        => '' !== $see_all ? $see_all : __( 'Show all results', 'mvweb-smart-search' ),
					'allTab'     => __( 'All', 'mvweb-smart-search' ),
					'recent'     => __( 'Recent searches', 'mvweb-smart-search' ),
					'popular'    => __( 'Popular searches', 'mvweb-smart-search' ),
					'clear'      => __( 'Clear', 'mvweb-smart-search' ),
					'categories' => __( 'Categories', 'mvweb-smart-search' ),
					'brands'     => __( 'Brands', 'mvweb-smart-search' ),
					'products'   => __( 'Products', 'mvweb-smart-search' ),
					'posts'      => __( 'Posts', 'mvweb-smart-search' ),
					'pages'      => __( 'Pages', 'mvweb-smart-search' ),
					'other'      => __( 'Other', 'mvweb-smart-search' ),
					'inStock'    => __( 'In stock', 'mvweb-smart-search' ),
					'outStock'   => __( 'Out of stock', 'mvweb-smart-search' ),
					'view'       => __( 'View', 'mvweb-smart-search' ),
					'close'      => __( 'Close', 'mvweb-smart-search' ),
					/* translators: %s: corrected search phrase. */
					'showingFor' => __( 'Showing results for %s', 'mvweb-smart-search' ),
					/* translators: %s: suggested search phrase. */
					'didYouMean' => __( 'Did you mean %s?', 'mvweb-smart-search' ),
				),
			)
		);
	}
}
