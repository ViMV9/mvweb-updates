<?php
/**
 * Coverage settings tab (post types + custom fields).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = MVweb_SS_Settings::all();
$option   = MVweb_SS_Settings::OPTION;
$selected = (array) $settings['post_types'];
$types    = get_post_types(
	array(
		'public'              => true,
		'exclude_from_search' => false,
	),
	'objects'
);
?>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'What to index', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Content types included in search.', 'mvweb-smart-search' ); ?></p>

	<?php foreach ( $types as $ptype ) : ?>
		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php echo esc_html( $ptype->labels->name ); ?> <code><?php echo esc_html( $ptype->name ); ?></code></span>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox" name="<?php echo esc_attr( $option ); ?>[post_types][]" value="<?php echo esc_attr( $ptype->name ); ?>" <?php checked( in_array( $ptype->name, $selected, true ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
			</div>
		</div>
	<?php endforeach; ?>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Categories in results', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Show matching product (or content) categories as a separate group at the top of the live dropdown, linking to the category archive.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-show_categories"><?php esc_html_e( 'Matching categories', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-show_categories" name="<?php echo esc_attr( $option ); ?>[show_categories]" value="1" <?php checked( ! empty( $settings['show_categories'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-show_brands"><?php esc_html_e( 'Matching brands', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-show_brands" name="<?php echo esc_attr( $option ); ?>[show_brands]" value="1" <?php checked( ! empty( $settings['show_brands'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Show matching product brands as their own group, linking to the brand archive (requires a brand taxonomy plugin).', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-cat-limit"><?php esc_html_e( 'Max categories / brands', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-cat-limit" class="mvweb-input" min="1" max="20" step="1" name="<?php echo esc_attr( $option ); ?>[cat_limit]" value="<?php echo esc_attr( (string) (int) $settings['cat_limit'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'How many terms to list in each of the Category and Brand groups. Keep it low so the groups do not push the product results out of view.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Custom fields', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Meta field keys to index, one per line. Internal fields starting with "_" are not indexed.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-cf"><?php esc_html_e( 'Field keys', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="mvweb-ss-cf" class="mvweb-textarea" rows="4" name="<?php echo esc_attr( $option ); ?>[cf_whitelist]" placeholder="my_field&#10;another_field"><?php echo esc_textarea( implode( "\n", (array) $settings['cf_whitelist'] ) ); ?></textarea>
		</div>
	</div>
</section>
