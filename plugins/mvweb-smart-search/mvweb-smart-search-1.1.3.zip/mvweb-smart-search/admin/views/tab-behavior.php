<?php
/**
 * Behavior settings tab (dropdown timing, limits, highlighting, results page).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = MVweb_SS_Settings::all();
$option   = MVweb_SS_Settings::OPTION;
?>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Live dropdown', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'When suggestions appear and how many are shown.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-min-chars"><?php esc_html_e( 'Minimum characters', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-min-chars" class="mvweb-input" min="1" max="10" step="1" name="<?php echo esc_attr( $option ); ?>[min_chars]" value="<?php echo esc_attr( (string) (int) $settings['min_chars'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'How many characters the visitor must type before suggestions start loading.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-debounce"><?php esc_html_e( 'Typing delay (ms)', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-debounce" class="mvweb-input" min="0" max="2000" step="50" name="<?php echo esc_attr( $option ); ?>[debounce_ms]" value="<?php echo esc_attr( (string) (int) $settings['debounce_ms'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'The pause after the last keystroke before a request is sent. Higher values mean fewer requests.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-sugg-limit"><?php esc_html_e( 'Total suggestions', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-sugg-limit" class="mvweb-input" min="1" max="50" step="1" name="<?php echo esc_attr( $option ); ?>[sugg_limit]" value="<?php echo esc_attr( (string) (int) $settings['sugg_limit'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Maximum number of results shown in the dropdown across all groups.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-per-group"><?php esc_html_e( 'Per-group limit', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-per-group" class="mvweb-input" min="0" max="50" step="1" name="<?php echo esc_attr( $option ); ?>[per_group_limit]" value="<?php echo esc_attr( (string) (int) $settings['per_group_limit'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Maximum results per group (Products, Posts, Pages…). Set to 0 for no per-group limit.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Matching and hints', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'How matches are shown and how typo corrections are announced.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-highlight"><?php esc_html_e( 'Highlight matches', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-highlight" name="<?php echo esc_attr( $option ); ?>[highlight]" value="1" <?php checked( ! empty( $settings['highlight'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Emphasize the matched part of each result title with the accent color.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-fuzzy-notice"><?php esc_html_e( 'Typo-correction hint', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-ss-fuzzy-notice" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[fuzzy_notice]">
				<option value="silent" <?php selected( $settings['fuzzy_notice'], 'silent' ); ?>><?php esc_html_e( 'Silent — no hint', 'mvweb-smart-search' ); ?></option>
				<option value="showing" <?php selected( $settings['fuzzy_notice'], 'showing' ); ?>><?php esc_html_e( '"Showing results for…"', 'mvweb-smart-search' ); ?></option>
				<option value="suggest" <?php selected( $settings['fuzzy_notice'], 'suggest' ); ?>><?php esc_html_e( '"Did you mean…?" (clickable)', 'mvweb-smart-search' ); ?></option>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'When a typo is auto-corrected, optionally show a note with the corrected phrase.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-group-order"><?php esc_html_e( 'Group order', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-ss-group-order" class="mvweb-select" name="<?php echo esc_attr( $option ); ?>[group_order]">
				<option value="products" <?php selected( $settings['group_order'], 'products' ); ?>><?php esc_html_e( 'Products first', 'mvweb-smart-search' ); ?></option>
				<option value="content" <?php selected( $settings['group_order'], 'content' ); ?>><?php esc_html_e( 'Posts and pages first', 'mvweb-smart-search' ); ?></option>
				<option value="pages" <?php selected( $settings['group_order'], 'pages' ); ?>><?php esc_html_e( 'Pages first', 'mvweb-smart-search' ); ?></option>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Order of result groups in the dropdown. Any other content types follow after.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Results page', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'The full search results page (when a visitor submits the form).', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-results-per-page"><?php esc_html_e( 'Results per page', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb-ss-results-per-page" class="mvweb-input" min="0" max="100" step="1" name="<?php echo esc_attr( $option ); ?>[results_per_page]" value="<?php echo esc_attr( (string) (int) $settings['results_per_page'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Number of results on the search results page. Set to 0 to use the theme default.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>
