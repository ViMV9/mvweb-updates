<?php
/**
 * Analytics settings tab (search log: no-result and top queries + export).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$no_results = MVweb_SS_Analytics::no_result_queries_clustered( 20 );
$top        = MVweb_SS_Analytics::top_queries_clustered( 20 );

$settings = MVweb_SS_Settings::all();
$option   = MVweb_SS_Settings::OPTION;

$export_url = wp_nonce_url( admin_url( 'admin-post.php?action=' . MVweb_SS_Analytics::EXPORT_ACTION ), MVweb_SS_Analytics::EXPORT_ACTION );
$clear_url  = wp_nonce_url( admin_url( 'admin-post.php?action=' . MVweb_SS_Analytics::CLEAR_ACTION ), MVweb_SS_Analytics::CLEAR_ACTION );

/**
 * One-click merchandising links that jump to the Relevance tab with a starter
 * line for this query pre-filled (synonym / redirect / pin).
 *
 * @param string $query Query to seed.
 * @return string HTML of the action buttons.
 */
$mvweb_ss_actions = static function ( $query ) {
	$base    = admin_url( 'admin.php' );
	$seeds   = array(
		'synonym'  => __( 'Synonym', 'mvweb-smart-search' ),
		'redirect' => __( 'Redirect', 'mvweb-smart-search' ),
		'pin'      => __( 'Pin', 'mvweb-smart-search' ),
	);
	$buttons = array();

	foreach ( $seeds as $seed => $label ) {
		$url       = add_query_arg(
			array(
				'page' => MVweb_SS_Admin::PAGE_SLUG,
				'tab'  => 'relevance',
				'seed' => $seed,
				'q'    => rawurlencode( $query ),
			),
			$base
		);
		$buttons[] = '<a class="mvweb-btn mvweb-btn--ghost" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
	}

	return '<span class="mvweb-ss-row-actions">' . implode( ' ', $buttons ) . '</span>';
};

if ( isset( $_GET['cleared'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only notice flag.
	if ( '0' === sanitize_key( wp_unslash( $_GET['cleared'] ) ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<div class="mvweb-alert mvweb-alert--error"><?php esc_html_e( 'Could not clear the log.', 'mvweb-smart-search' ); ?></div>
	<?php else : ?>
		<div class="mvweb-alert mvweb-alert--success"><?php esc_html_e( 'Search log cleared.', 'mvweb-smart-search' ); ?></div>
	<?php endif; ?>
<?php endif; ?>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Queries with no results', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'What people search for but don\'t find — growth opportunities for content and products. Similar wordings (grammatical cases, spelling) are grouped into one row.', 'mvweb-smart-search' ); ?></p>

	<?php if ( empty( $no_results ) ) : ?>
		<p class="mvweb-empty"><?php esc_html_e( 'No queries without results yet.', 'mvweb-smart-search' ); ?></p>
	<?php else : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Query', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Times searched', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Forms', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Last seen', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'mvweb-smart-search' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $no_results as $row ) : ?>
						<tr>
							<td><?php echo esc_html( $row['query'] ); ?></td>
							<td><?php echo esc_html( (string) $row['hits'] ); ?></td>
							<td><?php echo esc_html( (string) $row['variants'] ); ?></td>
							<td><?php echo esc_html( $row['updated'] ); ?></td>
							<td><?php echo $mvweb_ss_actions( $row['query'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from esc_url()/esc_html(). ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Top queries', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'The most popular search phrases, how many results they returned and how often a result was clicked (click-through rate). Similar wordings are grouped into one row.', 'mvweb-smart-search' ); ?></p>

	<?php if ( empty( $top ) ) : ?>
		<p class="mvweb-empty"><?php esc_html_e( 'The log is empty.', 'mvweb-smart-search' ); ?></p>
	<?php else : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Query', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Times searched', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Forms', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Results', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Clicks', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'CTR', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Last seen', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'mvweb-smart-search' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach ( $top as $row ) :
						$mvweb_ss_hits   = (int) $row['hits'];
						$mvweb_ss_clicks = (int) $row['clicks'];
						$mvweb_ss_ctr    = $mvweb_ss_hits > 0 ? round( $mvweb_ss_clicks / $mvweb_ss_hits * 100 ) . '%' : '—';
						?>
						<tr>
							<td><?php echo esc_html( $row['query'] ); ?></td>
							<td><?php echo esc_html( (string) $mvweb_ss_hits ); ?></td>
							<td><?php echo esc_html( (string) $row['variants'] ); ?></td>
							<td><?php echo esc_html( (string) $row['results'] ); ?></td>
							<td><?php echo esc_html( (string) $mvweb_ss_clicks ); ?></td>
							<td><?php echo esc_html( $mvweb_ss_ctr ); ?></td>
							<td><?php echo esc_html( $row['updated'] ); ?></td>
							<td><?php echo $mvweb_ss_actions( $row['query'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from esc_url()/esc_html(). ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>

	<div class="mvweb-toolbar">
		<a class="mvweb-btn" href="<?php echo esc_url( $export_url ); ?>"><?php esc_html_e( 'Export to CSV', 'mvweb-smart-search' ); ?></a>
		<a class="mvweb-btn mvweb-btn--ghost mvweb-ss-confirm" data-confirm="<?php esc_attr_e( 'Clear the entire search log?', 'mvweb-smart-search' ); ?>" href="<?php echo esc_url( $clear_url ); ?>"><?php esc_html_e( 'Clear log', 'mvweb-smart-search' ); ?></a>
	</div>
</section>

<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Weekly email digest', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Email a short weekly summary of the top and no-result searches, so the insights above reach you without opening this page.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-weekly-digest"><?php esc_html_e( 'Send weekly digest', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-weekly-digest" name="<?php echo esc_attr( $option ); ?>[weekly_digest]" value="1" <?php checked( ! empty( $settings['weekly_digest'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Off by default. Uses WordPress cron, so it fires on the next visit after each week.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-digest-email"><?php esc_html_e( 'Send to', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="email" id="mvweb-ss-digest-email" class="mvweb-input" name="<?php echo esc_attr( $option ); ?>[digest_email]" value="<?php echo esc_attr( $settings['digest_email'] ); ?>" placeholder="<?php echo esc_attr( (string) get_option( 'admin_email' ) ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Leave blank to use the site admin email.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>
</section>

<?php if ( class_exists( 'WooCommerce' ) ) : ?>
<section class="mvweb-block">
	<div class="mvweb-block__head">
		<h2 class="mvweb-block__title"><?php esc_html_e( 'Revenue by search', 'mvweb-smart-search' ); ?></h2>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Which searches lead to sales. Orders are attributed to the shopper\'s last search before checkout (last-search-touch) — a useful signal, not exact accounting.', 'mvweb-smart-search' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-ss-revenue-tracking"><?php esc_html_e( 'Track search revenue', 'mvweb-smart-search' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox" id="mvweb-ss-revenue-tracking" name="<?php echo esc_attr( $option ); ?>[revenue_tracking]" value="1" <?php checked( ! empty( $settings['revenue_tracking'] ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Off by default. Stores a short-lived cookie with the last search to link it to cart adds and orders.', 'mvweb-smart-search' ); ?></p>
		</div>
	</div>

	<?php $mvweb_ss_revenue = MVweb_SS_Revenue::by_query( 20 ); ?>

	<?php if ( ! empty( $mvweb_ss_revenue ) ) : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Query', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Searches', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Cart adds', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Orders', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Revenue', 'mvweb-smart-search' ); ?></th>
						<th><?php esc_html_e( 'Conversion', 'mvweb-smart-search' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach ( $mvweb_ss_revenue as $row ) :
						$mvweb_ss_conv = $row['hits'] > 0 ? round( $row['orders'] / $row['hits'] * 100, 1 ) . '%' : '—';
						?>
						<tr>
							<td><?php echo esc_html( $row['query'] ); ?></td>
							<td><?php echo esc_html( (string) $row['hits'] ); ?></td>
							<td><?php echo esc_html( (string) $row['carts'] ); ?></td>
							<td><?php echo esc_html( (string) $row['orders'] ); ?></td>
							<td><?php echo wp_kses_post( wc_price( $row['revenue'] ) ); ?></td>
							<td><?php echo esc_html( $mvweb_ss_conv ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php elseif ( ! empty( $settings['revenue_tracking'] ) ) : ?>
		<p class="mvweb-empty"><?php esc_html_e( 'No attributed sales yet. Data appears once shoppers search and then order.', 'mvweb-smart-search' ); ?></p>
	<?php endif; ?>
</section>
<?php endif; ?>
