<?php
/**
 * Search analytics: dashboard widget, log tables and CSV export.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Surfaces the aggregated search log: a "no results" dashboard widget, the
 * Analytics settings tab and a nonce-guarded CSV export / clear action.
 *
 * @since 1.0.0
 */
class MVweb_SS_Analytics {

	const EXPORT_ACTION = 'mvweb_ss_export_log';

	const CLEAR_ACTION = 'mvweb_ss_clear_log';

	// How deep the popular-query list reads before it is cut to the size asked
	// for. The surplus is what lets a half-written word be recognised: the word
	// it grows into has to be in the same slice. Not a setting — a shop owner
	// has no way to choose it, and the cost of the depth is a tenth of a
	// millisecond either way.
	const STUB_SCAN = 100;

	/**
	 * Register analytics hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'add_dashboard_widget' ) );
		add_action( 'admin_post_' . self::EXPORT_ACTION, array( __CLASS__, 'export_log' ) );
		add_action( 'admin_post_' . self::CLEAR_ACTION, array( __CLASS__, 'clear_log' ) );
	}

	/**
	 * Register the "no results" dashboard widget.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function add_dashboard_widget(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		wp_add_dashboard_widget(
			'mvweb_ss_no_results',
			__( 'Smart Search — queries with no results', 'mvweb-smart-search' ),
			array( __CLASS__, 'render_dashboard_widget' )
		);
	}

	/**
	 * Render the dashboard widget contents.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_dashboard_widget(): void {
		$rows = self::no_result_queries( 10 );

		if ( empty( $rows ) ) {
			echo '<p>' . esc_html__( 'No queries without results yet.', 'mvweb-smart-search' ) . '</p>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>';
		echo '<th>' . esc_html__( 'Query', 'mvweb-smart-search' ) . '</th>';
		echo '<th>' . esc_html__( 'Hits', 'mvweb-smart-search' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $rows as $row ) {
			echo '<tr><td>' . esc_html( $row['query'] ) . '</td><td>' . esc_html( (string) $row['hits'] ) . '</td></tr>';
		}

		echo '</tbody></table>';

		printf(
			'<p><a href="%s">%s</a></p>',
			esc_url( admin_url( 'admin.php?page=' . MVweb_SS_Admin::PAGE_SLUG . '&tab=analytics' ) ),
			esc_html__( 'All analytics', 'mvweb-smart-search' )
		);
	}

	/**
	 * Top queries that returned no results.
	 *
	 * @since 1.0.0
	 * @param int $limit Max rows.
	 * @return array<int,array{query:string,hits:int,updated:string}>
	 */
	public static function no_result_queries( int $limit ): array {
		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$limit = max( 1, min( 200, $limit ) );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT query, hits, updated FROM `$table` WHERE results = 0 ORDER BY hits DESC, updated DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$limit
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Most frequent queries overall.
	 *
	 * @since 1.0.0
	 * @param int $limit Max rows.
	 * @return array<int,array{query:string,hits:int,results:int,clicks:int,updated:string}>
	 */
	public static function top_queries( int $limit ): array {
		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$limit = max( 1, min( 200, $limit ) );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT query, hits, results, clicks, updated FROM `$table` ORDER BY hits DESC, updated DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$limit
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Most frequent queries that returned results — for the front-end
	 * "popular searches" suggestions shown on an empty focus.
	 *
	 * The log holds a row per distinct query text, and that includes every
	 * prefix a shopper types on the way to a word, so half-written words collect
	 * hits beside real queries and surface as suggestions. They are dropped here
	 * rather than kept out of the log: the log is the record of what was typed,
	 * and the zero-result analytics need those rows to spot a word the catalogue
	 * is missing. See drop_stubs() for what counts as half-written.
	 *
	 * @since 1.0.0
	 * @param int $limit Max rows.
	 * @return string[]
	 */
	public static function popular_queries( int $limit ): array {
		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$limit = max( 1, min( 50, $limit ) );

		// A half-written word is always less popular than the word it is growing
		// towards, so the row that unmasks it is already above it in this very
		// ordering: one wider slice carries both, and no second query is needed.
		// Measured on a 553-row log: 1.20 ms at the display size against 1.34 ms
		// here, the same plan either way, once an hour behind the caller's cache.
		$rows = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT query FROM `$table` WHERE results > 0 ORDER BY hits DESC, updated DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				self::STUB_SCAN
			)
		);

		if ( ! is_array( $rows ) ) {
			return array();
		}

		return array_slice( self::drop_stubs( array_map( 'strval', $rows ) ), 0, $limit );
	}

	/**
	 * Drop the queries that are a word someone was still typing.
	 *
	 * A row is dropped when a more popular row starts with it and the next
	 * character there is a letter — "ipho" under "iphone", a word cut mid-way.
	 * Anything else ends the word and the longer row is simply a different
	 * query: a space ("чехол" under "чехол iphone"), punctuation ("чехол" under
	 * "чехол-книжка"), and a digit, which is the case worth naming — model
	 * numbers grow by digits, so "a51" under "a515" is two real models of one
	 * line and hiding the shorter would hide a product the shop sells.
	 *
	 * Testing for a letter rather than against a space is what makes the rest of
	 * that list hold: a hyphen, a comma, a tab and a non-breaking space all sit
	 * inside a query the shopper finished typing, and reading them as mid-word
	 * dropped the very word they follow.
	 *
	 * Two limits, both deliberate. A word form built by adding letters is
	 * indistinguishable from a truncation by shape alone, so "камин" goes under
	 * "камины" if the plural is the more popular of the two. And a number
	 * abandoned mid-way ("iPhone 1") is kept by the digit rule above. Both leave
	 * an extra suggestion; the alternative loses a real one.
	 *
	 * Popularity is read as ordering, not as a ratio. A ratio has to be tuned to
	 * how much traffic a shop gets, and the shops running this plugin differ by
	 * orders of magnitude; being cut mid-word does not. Two rows on the same
	 * hit count are ordered by the log's own tie-break and may fall either way —
	 * the outcome then is the list as it was before this filter existed.
	 *
	 * @since 1.6.5
	 * @param string[] $rows Logged queries ordered by hits, most popular first.
	 * @return string[]
	 */
	private static function drop_stubs( array $rows ): array {
		$kept  = array();
		$plain = array();

		foreach ( $rows as $query ) {
			$lower = mb_strtolower( trim( (string) $query ), 'UTF-8' );

			if ( '' === $lower ) {
				continue;
			}

			$length = mb_strlen( $lower, 'UTF-8' );
			$stub   = false;

			// Only rows already passed are compared against: they are the more
			// popular ones, and a stub can only hide under a more popular row.
			// The log keys a row on the lower-cased text, so no two rows here are
			// the same word in another case, and a row that starts with this one
			// without being it is strictly longer — the character after the
			// prefix always exists.
			foreach ( $plain as $longer ) {
				if ( 0 !== mb_strpos( $longer, $lower, 0, 'UTF-8' ) ) {
					continue;
				}

				if ( preg_match( '/\p{L}/u', mb_substr( $longer, $length, 1, 'UTF-8' ) ) ) {
					$stub = true;
					break;
				}
			}

			if ( $stub ) {
				continue;
			}

			$plain[] = $lower;
			$kept[]  = (string) $query;
		}

		return $kept;
	}

	/**
	 * No-result queries annotated with the closest successful query, if any (P2.3).
	 *
	 * The search log is aggregated per query (no per-visitor session trail), so a
	 * true "typed A, found nothing, then typed B" pair cannot be mined. Instead this
	 * pairs each frequent no-result query with the most similar *successful* query
	 * by token overlap / string similarity — a human-gated hint the owner can turn
	 * into a synonym with one click. Nothing is applied automatically.
	 *
	 * @since 1.2.0
	 * @param int $limit Max no-result rows.
	 * @return array<int,array<string,mixed>> Clustered rows, each with a 'suggestion' key ('' when none).
	 */
	public static function no_result_suggestions( int $limit ): array {
		$rows = self::no_result_queries_clustered( $limit );

		if ( empty( $rows ) ) {
			return $rows;
		}

		$pool = self::popular_queries( 50 );

		foreach ( $rows as $i => $row ) {
			$rows[ $i ]['suggestion'] = self::closest_query( (string) $row['query'], $pool );
		}

		return $rows;
	}

	/**
	 * Closest successful query to a no-result one, or '' when nothing is close.
	 *
	 * Scores each candidate by the greater of token-overlap (Jaccard on words ≥2
	 * chars) and normalized string similarity, so both word-order/transliteration
	 * near-misses and typos surface. A conservative floor avoids noisy hints.
	 *
	 * @since 1.2.0
	 * @param string   $query Raw no-result query.
	 * @param string[] $pool  Candidate successful queries.
	 * @return string
	 */
	private static function closest_query( string $query, array $pool ): string {
		$q = mb_strtolower( trim( $query ), 'UTF-8' );

		if ( '' === $q ) {
			return '';
		}

		$q_tokens   = self::sig_tokens( $q );
		$best       = '';
		$best_score = 0.0;

		foreach ( $pool as $cand ) {
			$c = mb_strtolower( trim( (string) $cand ), 'UTF-8' );

			if ( '' === $c || $c === $q ) {
				continue;
			}

			$c_tokens = self::sig_tokens( $c );
			$union    = array_unique( array_merge( $q_tokens, $c_tokens ) );
			$jaccard  = ! empty( $union ) ? count( array_intersect( $q_tokens, $c_tokens ) ) / count( $union ) : 0.0;

			$percent = 0.0;
			similar_text( $q, $c, $percent );

			$score = max( $jaccard, $percent / 100 );

			if ( $score > $best_score ) {
				$best_score = $score;
				$best       = (string) $cand;
			}
		}

		return $best_score >= 0.5 ? $best : '';
	}

	/**
	 * Significant words of a query (lower-cased, length ≥ 2), for overlap scoring.
	 *
	 * @since 1.2.0
	 * @param string $query Lower-cased query.
	 * @return string[]
	 */
	private static function sig_tokens( string $query ): array {
		$parts = preg_split( '/\s+/u', $query );

		return array_values(
			array_filter(
				(array) $parts,
				static function ( $token ) {
					return mb_strlen( (string) $token, 'UTF-8' ) >= 2;
				}
			)
		);
	}

	/**
	 * Morphology key that folds Russian case forms of a query into one bucket.
	 *
	 * Reuses the index stemmer, so "камин", "камина" and "каминов" share a key
	 * and stop scattering the analytics across grammatical cases. Word order is
	 * ignored (stems are sorted).
	 *
	 * @since 1.1.0
	 * @param string $query Raw query.
	 * @return string
	 */
	public static function cluster_key( string $query ): string {
		$stems = array_keys( MVweb_SS_Tokenizer::tokenize( $query ) );
		sort( $stems );

		return implode( ' ', $stems );
	}

	/**
	 * Collapse rows sharing a morphology key, summing hits and clicks.
	 *
	 * The most-searched raw wording becomes the cluster label; `variants` counts
	 * how many spellings/cases folded in. Rows that tokenize to nothing (pure
	 * punctuation/numbers) fall back to their lowercased text so they still show.
	 *
	 * @since 1.1.0
	 * @param array<int,array<string,mixed>> $rows Log rows.
	 * @return array<int,array{query:string,hits:int,results:int,clicks:int,variants:int,updated:string}>
	 */
	private static function cluster( array $rows ): array {
		$clusters = array();

		foreach ( $rows as $row ) {
			$key = self::cluster_key( (string) $row['query'] );

			if ( '' === $key ) {
				$key = '~' . mb_strtolower( trim( (string) $row['query'] ), 'UTF-8' );
			}

			if ( ! isset( $clusters[ $key ] ) ) {
				$clusters[ $key ] = array(
					'query'    => (string) $row['query'],
					'hits'     => 0,
					'results'  => (int) ( $row['results'] ?? 0 ),
					'clicks'   => 0,
					'variants' => 0,
					'updated'  => (string) ( $row['updated'] ?? '' ),
					'_top'     => -1,
				);
			}

			$cluster = &$clusters[ $key ];

			$cluster['hits']   += (int) $row['hits'];
			$cluster['clicks'] += (int) ( $row['clicks'] ?? 0 );
			++$cluster['variants'];

			if ( (int) $row['hits'] > $cluster['_top'] ) {
				$cluster['_top']    = (int) $row['hits'];
				$cluster['query']   = (string) $row['query'];
				$cluster['results'] = (int) ( $row['results'] ?? 0 );
			}

			if ( (string) ( $row['updated'] ?? '' ) > $cluster['updated'] ) {
				$cluster['updated'] = (string) $row['updated'];
			}

			unset( $cluster );
		}

		foreach ( $clusters as &$cluster ) {
			unset( $cluster['_top'] );
		}

		unset( $cluster );

		return array_values( $clusters );
	}

	/**
	 * Top no-result queries, clustered by morphology.
	 *
	 * @since 1.1.0
	 * @param int $limit Max clusters.
	 * @return array<int,array<string,mixed>>
	 */
	public static function no_result_queries_clustered( int $limit ): array {
		$clusters = self::cluster( self::no_result_queries( 500 ) );

		usort(
			$clusters,
			static function ( $a, $b ) {
				return $b['hits'] <=> $a['hits'];
			}
		);

		return array_slice( $clusters, 0, max( 1, $limit ) );
	}

	/**
	 * Top queries overall, clustered by morphology.
	 *
	 * @since 1.1.0
	 * @param int $limit Max clusters.
	 * @return array<int,array<string,mixed>>
	 */
	public static function top_queries_clustered( int $limit ): array {
		$clusters = self::cluster( self::top_queries( 500 ) );

		usort(
			$clusters,
			static function ( $a, $b ) {
				return $b['hits'] <=> $a['hits'];
			}
		);

		return array_slice( $clusters, 0, max( 1, $limit ) );
	}

	/**
	 * Stream the full log as a CSV download.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function export_log(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mvweb-smart-search' ) );
		}

		check_admin_referer( self::EXPORT_ACTION );

		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$rows  = $wpdb->get_results( "SELECT query, hits, results, clicks, updated FROM `$table` ORDER BY hits DESC, updated DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=mvweb-search-log-' . gmdate( 'Y-m-d' ) . '.csv' );

		$output = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		if ( false === $output ) {
			exit;
		}

		fputcsv( $output, array( 'query', 'hits', 'results', 'clicks', 'updated' ) );

		foreach ( (array) $rows as $row ) {
			fputcsv(
				$output,
				array(
					self::csv_safe( $row['query'] ),
					(int) $row['hits'],
					(int) $row['results'],
					(int) $row['clicks'],
					self::csv_safe( $row['updated'] ),
				)
			);
		}

		fclose( $output ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		exit;
	}

	/**
	 * Empty the search log.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function clear_log(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mvweb-smart-search' ) );
		}

		check_admin_referer( self::CLEAR_ACTION );

		global $wpdb;

		$table  = MVweb_SS_Schema::log_table_name();
		$result = $wpdb->query( "DELETE FROM `$table`" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// Clearing the log also resets the rescued-search tallies it summarizes.
		delete_option( MVweb_SS_Log::RESCUE_OPTION );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => MVweb_SS_Admin::PAGE_SLUG,
					'tab'     => 'analytics',
					'cleared' => false === $result ? '0' : '1',
				),
				admin_url( 'admin.php' )
			)
		);

		exit;
	}

	/**
	 * Prefix formula-triggering values so spreadsheets treat them as text.
	 *
	 * @since 1.0.0
	 * @param mixed $value Cell value.
	 * @return string
	 */
	private static function csv_safe( $value ): string {
		$value = (string) $value;

		if ( '' !== $value && in_array( $value[0], array( '=', '+', '-', '@' ), true ) ) {
			return "'" . $value;
		}

		return $value;
	}
}
