<?php
/**
 * Search query engine: ranks index rows for a user query.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Turns a query string into a ranked list of matching objects.
 *
 * @since 1.0.0
 */
class MVweb_SS_Query {

	const MAX_LIMIT = 1000;

	const DEFAULT_LIMIT = 20;

	/**
	 * Head slice the PHP refinement passes (exact-match promotion, phrase
	 * proximity, product-type) scan. Bounds their cost so a large results-page pool never
	 * multiplies per-row title/product loads: an exact or phrase match carries
	 * full coverage and by the SQL order almost always ranks inside this head, so
	 * the rare miss (100+ equally-covered, higher-boosted rivals ahead of it) only
	 * forgoes its exact-match promotion — it never drops out of the results. The
	 * tail keeps its relevance order untouched.
	 */
	const REFINE_SCAN_CAP = 100;

	const FUZZY_THRESHOLD = 3;

	const BM25_K1 = 1.2;

	const BM25_B_TITLE = 0.3;

	const BM25_B_CONTENT = 0.75;

	/**
	 * Minimum trailing-word length before prefix (search-as-you-type) expansion
	 * fires, and the cap on index terms pulled per prefix. A 1-2 char prefix like
	 * "с%" would match a huge slice of the vocabulary, so both bounds are required.
	 */
	const PREFIX_MIN_LEN = 3;

	const PREFIX_CAP = 20;

	/**
	 * Cap on index terms pulled when checking whether the catalogue carries a
	 * model token whole ("g980" reaching "g980f"). A model prefix is far more
	 * selective than a word prefix, so a small cap is enough to tell "somebody
	 * has it" from "nobody does" — which is the only question being asked.
	 */
	const MODEL_PREFIX_LIMIT = 30;

	/**
	 * How few results a pass may return before the floor is allowed to drop.
	 *
	 * The search starts by demanding every word and only loosens when that
	 * demand leaves the shopper with nothing to look at — relaxation is a last
	 * resort, not the starting position.
	 * Deliberately tiny: on a parts catalogue a two-word answer to "lcd g980
	 * s20" is the right answer, not a shortage. Measured on a 13k-product
	 * catalogue over 15 cases with a written-down ground truth, relaxing below
	 * 3 results cost accuracy — F1 0.81 at a threshold of 1-2 against 0.70 at 8.
	 *
	 * One, not two, because a pair is already an answer. At two, a query the
	 * catalogue answers with exactly two products relaxed anyway and buried them:
	 * "realme 12 плюс акб" put its two Realme batteries on top and then added six
	 * for other brands, which had dropped the brand word and kept the rest. The
	 * brand is not a preference on a parts catalogue — a battery for another
	 * phone does not fit. Measured against a shop's log, the 120 most searched
	 * phrases: two change, that one and a pasted product title that loses a
	 * single near miss.
	 */
	const RELAX_BELOW = 1;

	/**
	 * Words that name a different device when appended to a model number.
	 *
	 * "M3" and "M3 Pro", "13" and "13 mini" are separate phones whose parts do
	 * not interchange, so the modifier belongs to the model, not to the shopper's
	 * wishes. None of them carries a digit, which is why the model discipline
	 * cannot recognise them on its own. Extend per catalogue through the
	 * mvweb_ss_model_qualifiers filter.
	 */
	const MODEL_QUALIFIERS = array( 'pro', 'max', 'plus', 'ultra', 'lite', 'mini', 'neo', 'air', 'fe', 'se' );

	/**
	 * Cyrillic spellings of the modifiers above, mapped onto their canon.
	 *
	 * A shopper types "13 про макс" as readily as "13 pro max", and the variant
	 * order rule has to read both. Only that rule: the model discipline stays
	 * latin on purpose, because "макс" transliterates to "maks", a term no
	 * catalogue carries — pinning it as required would empty the results.
	 */
	const MODEL_QUALIFIER_ALIASES = array(
		'про'    => 'pro',
		'макс'   => 'max',
		'плюс'   => 'plus',
		'ультра' => 'ultra',
		'лайт'   => 'lite',
		'мини'   => 'mini',
		'нео'    => 'neo',
		'эйр'    => 'air',
	);

	/**
	 * How many leading words of a title are searched for its head noun before
	 * giving up. Enough for "Защитное стекло полноэкранное", short enough that
	 * the device name never enters the window.
	 */
	const TYPE_HEAD_WINDOW = 3;

	/**
	 * How many of a category's matching products are read back to decide whether
	 * the category holds the part the shopper named. They arrive best-coverage
	 * first, so a category that carries the part at all shows it here.
	 */
	const TYPE_SAMPLE = 12;

	/**
	 * How many times the requested number of categories is pulled before the
	 * type filter runs, so that dropping a category promotes the next one that
	 * does carry the part instead of leaving an empty slot.
	 */
	const TYPE_TERM_OVERSCAN = 3;

	/**
	 * Ceiling on the categories pulled for that overscan. The shown number is an
	 * admin setting that reaches 20, and three times it would put 720 titles
	 * through the post cache for one dropdown.
	 */
	const TYPE_TERM_MAX = 30;

	/**
	 * Corrected query phrase from the last fuzzy fallback, or empty string.
	 *
	 * @var string
	 */
	private static $correction = '';

	/**
	 * Which mechanism rescued the last search: 'layout', 'typo' or '' (none).
	 *
	 * @var string
	 */
	private static $rescue = '';

	/**
	 * Whether the last search named a model or part number the catalogue does not
	 * carry, and therefore answered with nothing.
	 *
	 * @var bool
	 */
	private static $unmatched_model = false;

	/**
	 * Default per-source relevance weights.
	 *
	 * @var array<string,int>
	 */
	private static $weights = array(
		'title'         => 10,
		'sku'           => 10,
		'variation_sku' => 10,
		'gtin'          => 10,
		'brand'         => 7,
		'attr'          => 4,
		'excerpt'       => 4,
		'content'       => 3,
		'tax'           => 2,
		'cf'            => 2,
	);

	/**
	 * Default per-source relevance weights.
	 *
	 * @since 1.0.0
	 * @return array<string,int>
	 */
	public static function default_weights(): array {
		return self::$weights;
	}

	/**
	 * Which mechanism rescued the last search (analytics moat proof).
	 *
	 * @since 1.2.0
	 * @return string 'layout', 'typo', or '' when no correction was needed.
	 */
	public static function last_rescue(): string {
		return self::$rescue;
	}

	/**
	 * Corrected query phrase produced by the last fuzzy fallback.
	 *
	 * @since 1.0.0
	 * @return string Empty string when the last search needed no correction.
	 */
	public static function last_correction(): string {
		return self::$correction;
	}

	/**
	 * Whether the last search named a number the catalogue does not carry.
	 *
	 * A surface reads this to say so plainly instead of filling the gap: the
	 * shopper typed a part number, and anything else on the screen is a different
	 * part they cannot tell apart from the listing.
	 *
	 * @since 1.6.4
	 * @return bool
	 */
	public static function unmatched_model(): bool {
		return self::$unmatched_model;
	}

	/**
	 * Best-selling products, used as a zero-result fallback so a shopper facing an
	 * unmatched query still sees products instead of a dead end (P1.7). Ordered by
	 * lifetime sales from the WooCommerce product lookup table, in-stock first.
	 *
	 * @since 1.2.0
	 * @param string[] $types Post types in scope; returns empty unless 'product' is allowed.
	 * @param int      $limit Maximum rows.
	 * @return array<int,array<string,int|string>> Rows shaped like run() output (object_id/object_type).
	 */
	public static function bestsellers( array $types, int $limit ): array {
		global $wpdb;

		if ( ! class_exists( 'WooCommerce' ) || ! in_array( 'product', $types, true ) ) {
			return array();
		}

		$limit  = max( 1, min( $limit, self::MAX_LIMIT ) );
		$lookup = $wpdb->prefix . 'wc_product_meta_lookup';

		// Mirror the visibility filters run() applies: never surface a password-protected
		// product, nor one the admin excluded from search, in the zero-result fallback.
		$exclude  = MVweb_SS_Settings::excluded_ids();
		$excl_sql = '';
		$values   = array();

		if ( ! empty( $exclude ) ) {
			$excl_sql = 'AND p.ID NOT IN ( ' . implode( ',', array_fill( 0, count( $exclude ), '%d' ) ) . ' )';
			$values   = $exclude;
		}

		$values[] = $limit;

		$sql = "SELECT pml.product_id
			FROM {$lookup} AS pml
			INNER JOIN {$wpdb->posts} AS p ON p.ID = pml.product_id
			WHERE p.post_type = 'product' AND p.post_status = 'publish' AND p.post_password = ''
			$excl_sql
			ORDER BY ( pml.stock_status = 'instock' ) DESC, pml.total_sales DESC, pml.product_id DESC
			LIMIT %d";

		$ids = $wpdb->get_col( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		$rows = array();

		foreach ( (array) $ids as $id ) {
			$rows[] = array(
				'object_id'   => (int) $id,
				'object_type' => 'product',
			);
		}

		return $rows;
	}

	/**
	 * Re-order a ranked ID list by a shopper-chosen sort (P2.2), keeping relevance
	 * as the default (empty $sort returns the list untouched). Price/rating/sales
	 * come from the WooCommerce lookup table; "newest" from post_date. Non-products
	 * (no lookup row) sort last so a mixed result set is preserved, not truncated.
	 *
	 * @since 1.2.0
	 * @param int[]  $ids  Relevance-ordered object IDs.
	 * @param string $sort One of price_asc|price_desc|rating|popularity|newest, or ''.
	 * @return int[] Re-ordered IDs (relevance order when $sort is empty/unknown).
	 */
	public static function sort_ids( array $ids, string $sort ): array {
		global $wpdb;

		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );

		if ( empty( $ids ) || '' === $sort ) {
			return $ids;
		}

		$in = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		if ( 'newest' === $sort ) {
			$sql    = "SELECT ID FROM {$wpdb->posts} WHERE ID IN ($in) ORDER BY post_date DESC, ID DESC";
			$sorted = $wpdb->get_col( $wpdb->prepare( $sql, $ids ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders
		} else {
			$columns = array(
				'price_asc'  => 'pml.min_price ASC',
				'price_desc' => 'pml.min_price DESC',
				'rating'     => 'pml.average_rating DESC',
				'popularity' => 'pml.total_sales DESC',
			);

			if ( ! isset( $columns[ $sort ] ) || ! class_exists( 'WooCommerce' ) ) {
				return $ids;
			}

			$lookup  = $wpdb->prefix . 'wc_product_meta_lookup';
			$orderby = $columns[ $sort ];
			$sql     = "SELECT p.ID FROM {$wpdb->posts} p
				LEFT JOIN `$lookup` pml ON pml.product_id = p.ID
				WHERE p.ID IN ($in)
				ORDER BY ( pml.product_id IS NULL ), $orderby, p.ID DESC";
			$sorted  = $wpdb->get_col( $wpdb->prepare( $sql, $ids ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders
		}

		$sorted = array_values( array_filter( array_map( 'intval', (array) $sorted ) ) );

		return ! empty( $sorted ) ? $sorted : $ids;
	}

	/**
	 * Phrase-proximity re-rank (P1.3). Within each coverage tier, promote titles
	 * that contain the query as an exact phrase (prox 2) or with the words in order
	 * (prox 1) over titles where the words are merely scattered (prox 0). A stable
	 * sort keyed on (coverage, proximity, original position) preserves the existing
	 * relevance/sales order for equal proximity, so ordering shifts only when the
	 * phrase signal genuinely differs.
	 *
	 * @since 1.2.0
	 * @param string $query   Cleaned query phrase.
	 * @param array  $results Ranked results from run().
	 * @return array Re-ranked results.
	 */
	private static function proximity_rerank( string $query, array $results ): array {
		if ( count( $results ) < 2 ) {
			return $results;
		}

		$words = array_values( array_filter( (array) preg_split( '/\s+/u', mb_strtolower( trim( $query ), 'UTF-8' ) ), 'strlen' ) );

		if ( count( $words ) < 2 ) {
			return $results;
		}

		// Bound the per-row title loads to the head slice; the tail keeps its SQL
		// relevance order (a phrase match ranks inside the head by coverage anyway).
		$tail    = array_slice( $results, self::REFINE_SCAN_CAP );
		$results = array_slice( $results, 0, self::REFINE_SCAN_CAP );

		$phrase = implode( ' ', $words );

		foreach ( $results as $i => $row ) {
			$title = mb_strtolower( wp_strip_all_tags( (string) get_the_title( (int) $row['object_id'] ) ), 'UTF-8' );
			$title = (string) preg_replace( '/\s+/u', ' ', $title );

			if ( false !== mb_strpos( $title, $phrase, 0, 'UTF-8' ) ) {
				$prox = 2;
			} elseif ( self::words_in_order( $title, $words ) ) {
				$prox = 1;
			} else {
				$prox = 0;
			}

			$results[ $i ]['proximity'] = $prox;
			$results[ $i ]['_pos']      = $i;
		}

		usort(
			$results,
			static function ( $a, $b ) {
				$stock = self::stock_flag( $a ) <=> self::stock_flag( $b );

				if ( 0 !== $stock ) {
					return $stock;
				}

				if ( $a['matched'] !== $b['matched'] ) {
					return $b['matched'] <=> $a['matched'];
				}

				if ( $a['proximity'] !== $b['proximity'] ) {
					return $b['proximity'] <=> $a['proximity'];
				}

				return $a['_pos'] <=> $b['_pos'];
			}
		);

		foreach ( $results as $i => $row ) {
			unset( $results[ $i ]['_pos'], $results[ $i ]['proximity'] );
		}

		return array_merge( $results, $tail );
	}

	/**
	 * Product-type re-rank. Within each coverage tier, promote a title whose FIRST
	 * word is what the shopper asked for over one that merely mentions it.
	 *
	 * Catalogs name the thing first and qualify it after: "Дисплей iPhone 13" is a
	 * screen, "Проклейка дисплея iPhone 13" is an adhesive for one. Both match the
	 * same words, so plain relevance can rank the accessory above the part — and
	 * usually does, because the accessory is the only place the shopper's own word
	 * appears verbatim, which makes that word rare and therefore heavy.
	 *
	 * Comparison is on stems from the coverage groups, so a synonym counts: a query
	 * for "дисплей" recognizes a title that opens with "LCD". Titles that open with
	 * a brand or an article number simply never earn the flag, and a catalog named
	 * that way keeps its existing order.
	 *
	 * @since 1.5.3
	 * @param array<int,string[]> $groups  Coverage groups behind the current result set.
	 * @param array               $results Ranked results from run().
	 * @return array Re-ranked results.
	 */
	private static function head_rerank( array $groups, array $results ): array {
		if ( count( $results ) < 2 ) {
			return $results;
		}

		$stems = array_flip( self::flatten_groups( $groups ) );

		if ( empty( $stems ) ) {
			return $results;
		}

		// Bound the per-row title loads the same way the proximity pass does; the
		// tail keeps its SQL relevance order.
		$tail    = array_slice( $results, self::REFINE_SCAN_CAP );
		$results = array_slice( $results, 0, self::REFINE_SCAN_CAP );

		foreach ( $results as $i => $row ) {
			$title = wp_strip_all_tags( (string) get_the_title( (int) $row['object_id'] ) );
			$head  = array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( $title ) ) );

			$results[ $i ]['_head'] = ( isset( $head[0] ) && isset( $stems[ $head[0] ] ) ) ? 1 : 0;
			$results[ $i ]['_pos']  = $i;
		}

		usort(
			$results,
			static function ( $a, $b ) {
				$stock = self::stock_flag( $a ) <=> self::stock_flag( $b );

				if ( 0 !== $stock ) {
					return $stock;
				}

				if ( (int) $a['matched'] !== (int) $b['matched'] ) {
					return (int) $b['matched'] <=> (int) $a['matched'];
				}

				if ( $a['_head'] !== $b['_head'] ) {
					return $b['_head'] <=> $a['_head'];
				}

				return $a['_pos'] <=> $b['_pos'];
			}
		);

		foreach ( $results as $i => $row ) {
			unset( $results[ $i ]['_head'], $results[ $i ]['_pos'] );
		}

		return array_merge( $results, $tail );
	}

	/**
	 * Model-variant re-rank. Within each coverage tier, float the plain model
	 * above its qualified siblings — unless the shopper named the qualifier.
	 *
	 * "акб iPhone 13" matches the batteries of four different phones: the 13, the
	 * 13 mini, the 13 Pro and the 13 Pro Max. The model discipline pins the "13"
	 * and stops there, so all four land in one coverage tier and the order inside
	 * it falls to relevance and sales — which mixes them. A shopper who wanted a
	 * Pro would have typed Pro, so a title carrying a modifier the query never
	 * asked for is answering a narrower question than the one asked.
	 *
	 * The pass reorders, never filters: a qualified part stays on the page, just
	 * below the plain one. A query naming no model is left alone entirely.
	 *
	 * @since 1.6.1
	 * @param string $query   Cleaned query phrase.
	 * @param array  $results Ranked results from run().
	 * @return array Re-ranked results.
	 */
	private static function variant_rerank( string $query, array $results ): array {
		if ( count( $results ) < 2 ) {
			return $results;
		}

		$map    = self::qualifier_map();
		$models = array();
		$wanted = array();

		foreach ( self::variant_words( $query, $map, true ) as $word ) {
			if ( isset( $map[ $word ] ) ) {
				$wanted[] = $map[ $word ];
				continue;
			}

			if ( preg_match( '/\d/', $word ) ) {
				$models[] = $word;
			}
		}

		$models = array_values( array_unique( $models ) );

		if ( empty( $models ) ) {
			return $results;
		}

		$wanted = array_values( array_unique( $wanted ) );

		// Bound the per-row title loads to the head slice the same way the passes
		// above do; the tail keeps its SQL relevance order.
		$tail    = array_slice( $results, self::REFINE_SCAN_CAP );
		$results = array_slice( $results, 0, self::REFINE_SCAN_CAP );

		// type_filter() normally warms the post cache, but it is switchable and
		// this pass is not — without priming, a site running with it off would pay
		// a hundred separate post loads here.
		$ids = array();

		foreach ( $results as $row ) {
			$ids[] = (int) $row['object_id'];
		}

		_prime_post_caches( $ids, false, false );

		foreach ( $results as $i => $row ) {
			// The raw title, the same string the index was built from:
			// get_the_title() runs a Russian locale's quotes and dashes into HTML
			// entities, whose digits would read as model numbers here.
			$title = wp_strip_all_tags( (string) get_post_field( 'post_title', (int) $row['object_id'], 'raw' ) );

			$results[ $i ]['_variant'] = self::variant_penalty( self::variant_words( $title, $map ), $models, $wanted, $map );
			$results[ $i ]['_pos']     = $i;
		}

		usort(
			$results,
			static function ( $a, $b ) {
				$stock = self::stock_flag( $a ) <=> self::stock_flag( $b );

				if ( 0 !== $stock ) {
					return $stock;
				}

				if ( (int) $a['matched'] !== (int) $b['matched'] ) {
					return (int) $b['matched'] <=> (int) $a['matched'];
				}

				if ( $a['_variant'] !== $b['_variant'] ) {
					return $a['_variant'] <=> $b['_variant'];
				}

				return $a['_pos'] <=> $b['_pos'];
			}
		);

		foreach ( $results as $i => $row ) {
			unset( $results[ $i ]['_variant'], $results[ $i ]['_pos'] );
		}

		return array_merge( $results, $tail );
	}

	/**
	 * Words of a title or a query, with the spellings that hide a modifier inside
	 * the model number pulled apart.
	 *
	 * Catalogues glue the modifier to the number ("S20FE", "S20Plus/G985F") and
	 * write Plus as a sign — on the number ("J6+ (2018)") or on the modifier that
	 * follows it ("Redmi Note 12 Pro+") — and a modifier the rule cannot see is a
	 * modifier it cannot charge for. Works on the raw text rather than on stems:
	 * the stemmer folds these away.
	 *
	 * What may stand before the sign is deliberately narrow — a digit, or one of
	 * the known modifiers — and what may follow it even narrower: a letter or a
	 * digit behind the sign means it belongs to a code, which is what keeps
	 * "68+E" and "HB444199EBC+ (Honor 4C)" out of the rule.
	 *
	 * $loose additionally allows spaces before the sign, and is for queries only.
	 * A shopper writes "realme 12 pro +" meaning the Pro+, while a title writes
	 * " + " to list what else is in the box ("Realme 9 Pro + OCA") — reading that
	 * as a Plus would rename the product into a variant it is not.
	 *
	 * @since 1.6.1
	 * @param string               $text  Raw title or query.
	 * @param array<string,string> $map   Modifier spelling => canon.
	 * @param bool                 $loose Read a spaced "+" as the sign (queries).
	 * @return string[]
	 */
	private static function variant_words( string $text, array $map, bool $loose = false ): array {
		$text = mb_strtolower( $text, 'UTF-8' );
		$gap  = $loose ? '\s*' : '';

		// An empty map would build the alternation `(\d)()`, which matches after
		// every digit and would tear "3.0" into "3 .0".
		if ( ! empty( $map ) ) {
			$alt = array();

			foreach ( array_keys( $map ) as $spelling ) {
				$alt[] = preg_quote( (string) $spelling, '/' );
			}

			$alt = implode( '|', $alt );

			// Ungluing runs first: it turns "S20FE+" into "s20 fe+" and so hands
			// the sign to the rule below, which needs the modifier as its own word.
			$text = (string) preg_replace( '/(\d)(' . $alt . ')(?![\p{L}\d])/u', '$1 $2', $text );
			$text = (string) preg_replace( '/(?<![\p{L}\d])(' . $alt . ')' . $gap . '\+(?![\p{L}\d])/u', '$1 plus', $text );
		}

		$text = (string) preg_replace( '/(\d)' . $gap . '\+(?![\p{L}\d])/u', '$1 plus', $text );

		$words = preg_split( '/[^\p{L}\p{N}]+/u', $text, -1, PREG_SPLIT_NO_EMPTY );

		return is_array( $words ) ? $words : array();
	}

	/**
	 * How far a title's model naming sits from the one the query asked for.
	 *
	 * Counted per model word and summed: a query naming a model and a year
	 * ("j6 2018") must not have the year — which nothing follows — cancel the
	 * charge earned by the model. Within one model word the best occurrence wins,
	 * which is what keeps "Camera iPhone 13/13 mini" a plain-13 part.
	 *
	 * Symmetric on purpose: a modifier standing in the title unasked and a
	 * modifier asked for but missing from the title are both a mismatch. Only the
	 * second half ever fires in practice — a modifier named in the query is
	 * normally pinned as required and the mismatched titles never reach here —
	 * but it is exactly what a cyrillic "мини" needs, since the model discipline
	 * cannot pin that spelling.
	 *
	 * @since 1.6.1
	 * @param string[]             $words  Title words from variant_words().
	 * @param string[]             $models Model words of the query.
	 * @param string[]             $wanted Canonical modifiers the query named.
	 * @param array<string,string> $map    Modifier spelling => canon.
	 * @return int
	 */
	private static function variant_penalty( array $words, array $models, array $wanted, array $map ): int {
		$count = count( $words );
		$total = 0;

		foreach ( $models as $model ) {
			$best = null;

			foreach ( $words as $i => $word ) {
				if ( $word !== $model ) {
					continue;
				}

				$extra = 0;
				$found = array();

				for ( $j = $i + 1; $j < $count; $j++ ) {
					if ( ! isset( $map[ $words[ $j ] ] ) ) {
						break;
					}

					if ( in_array( $map[ $words[ $j ] ], $wanted, true ) ) {
						$found[] = $map[ $words[ $j ] ];
					} else {
						++$extra;
					}
				}

				$extra += count( array_diff( $wanted, $found ) );
				$best   = ( null === $best ) ? $extra : min( $best, $extra );
			}

			// A model the title never spells out is charged for every modifier the
			// query named, exactly as a title that does spell it out but carries
			// none of them. Charging nothing put it *above* the real thing: on a
			// parts shop "realme 12 pro+" ranked a connector for the Realme 3 and 5
			// — which owes its match to a "C12" elsewhere in its title — over the
			// Realme 12 Pro parts, because those were charged for the missing Plus
			// and it was charged for nothing at all.
			$total += ( null === $best ) ? count( $wanted ) : $best;
		}

		return $total;
	}

	/**
	 * Out-of-stock flag of a result row, 0 when the column was never selected.
	 *
	 * Demotion is applied to the rows the query returns (see run()), so every PHP
	 * pass that reshuffles a tier has to carry the same key first or it hands a
	 * sold-out product a place the ranking had taken from it.
	 *
	 * @since 1.6.1
	 * @param array $row Result row.
	 * @return int
	 */
	private static function stock_flag( array $row ): int {
		return isset( $row['out_of_stock'] ) ? (int) $row['out_of_stock'] : 0;
	}

	/**
	 * True when every word appears in $haystack in the given order (not necessarily
	 * adjacent). Multibyte-safe; O(title length).
	 *
	 * @since 1.2.0
	 * @param string   $haystack Lower-cased text to scan.
	 * @param string[] $words    Query words in order.
	 * @return bool
	 */
	private static function words_in_order( string $haystack, array $words ): bool {
		$offset = 0;

		foreach ( $words as $word ) {
			$pos = mb_strpos( $haystack, $word, $offset, 'UTF-8' );

			if ( false === $pos ) {
				return false;
			}

			$offset = $pos + mb_strlen( $word, 'UTF-8' );
		}

		return true;
	}

	/**
	 * Search the index.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @param array  $args  { Optional.
	 *     @type int      $limit      Max results (capped at MAX_LIMIT).
	 *     @type string   $strictness 'loose', 'balanced' (default) or 'strict'.
	 *     @type string[] $post_types Restrict to these types.
	 * }
	 * @return array<int,array{object_id:int,object_type:string,score:float}>
	 */
	public static function search( string $query, array $args = array() ): array {
		self::$correction      = '';
		self::$rescue          = '';
		self::$unmatched_model = false;

		// A leading "-word" excludes results containing that word (Boolean NOT).
		list( $clean_query, $neg_terms ) = self::split_negatives( $query );

		$words = MVweb_SS_Tokenizer::tokenize_words( $clean_query, '', self::query_parts_budget() );

		if ( empty( $words ) ) {
			return array();
		}

		// Model discipline: a word carrying a digit is the one thing that tells two
		// otherwise identical parts apart, so it is resolved against the catalogue
		// and pinned as required. See model_words().
		list( $words, $required_terms ) = self::model_words( $words, ! empty( $args['prefix'] ) );

		$limit = isset( $args['limit'] ) ? (int) $args['limit'] : self::DEFAULT_LIMIT;
		$limit = max( 1, min( $limit, self::MAX_LIMIT ) );

		// A caller asking for a handful is naming a display size, not a ranking one.
		// The refinement passes below only reorder the rows they are handed, so a
		// pool cut to ten hands them ten rows already in relevance order and the
		// plain model they would have floated never enters it. Measured on a live
		// 13k-product catalogue: "акб iPhone 13" opens with nine base models when
		// the pool is fifty and with three when it is ten — the same query, the same
		// rule, a pool too small to rank inside. So the head is scanned to the bound
		// those passes are capped at anyway and cut to the caller's size once they
		// have all had it.
		$scan = max( $limit, self::REFINE_SCAN_CAP );

		$strictness = isset( $args['strictness'] )
			? (string) $args['strictness']
			: (string) MVweb_SS_Settings::get( 'strictness', 'balanced' );

		$min_match = self::min_match( $strictness, MVweb_SS_Tokenizer::word_count( $clean_query ) );

		$types = isset( $args['post_types'] ) && is_array( $args['post_types'] ) && ! empty( $args['post_types'] )
			? array_values( $args['post_types'] )
			: MVweb_SS_Indexer::get_indexed_post_types();

		$term_ids = isset( $args['term_ids'] ) && is_array( $args['term_ids'] )
			? array_values( array_filter( array_map( 'intval', $args['term_ids'] ) ) )
			: array();

		$taxonomy = isset( $args['taxonomy'] ) ? (string) $args['taxonomy'] : '';

		// Self-learning click-boost keys on the raw query the shopper typed; the
		// same hash covers the layout-swap and fuzzy retries (clicks were logged
		// under that original wording). Empty unless the boost is enabled.
		$query_hash = MVweb_SS_Settings::get( 'click_boost', false ) ? MVweb_SS_Log::hash( $query ) : '';

		// Fold synonyms into the primary run so coverage-first ranking floats the
		// results that also match a synonym, while the strictness floor stays tied
		// to the number of original query words (a synonym does not raise the bar).
		// The trailing word is passed as a prefix so a synonym still fires while it
		// is being typed ("iphone 14 батаре" reaches the "аккумулятор" synonym).
		// Cross-script transliteration folds "samsung"↔"самсунг" so a query in one
		// script reaches products written in the other. Query-time only (never
		// emitted into the index), attached to the source word's coverage group.
		$translit = MVweb_SS_Settings::get( 'translit_cross_script', true );

		$partial = MVweb_SS_Settings::get( 'synonym_prefix', true ) ? self::trailing_stem( $clean_query ) : '';
		$groups  = self::expand_groups( $words, $partial, $translit );

		// Search-as-you-type (P1.5): in the live dropdown, fold index terms that start
		// with the trailing word into its coverage group, so a half-typed word ("самс")
		// already reaches "самсунг" before the whole word is stemmed. Gated to a minimum
		// length and a capped term count (a 1-2 char prefix would blow up the candidate
		// pool) and attached to a single group so coverage stays honest. Dropdown only —
		// on the results page the trailing word is complete, so prefix noise is unwanted.
		if ( ! empty( $args['prefix'] ) && MVweb_SS_Settings::get( 'prefix_last_word', true ) ) {
			self::attach_prefix_terms( $groups, $words, $translit );
		}

		$required = self::required_groups( $groups, $required_terms );

		$results = self::adaptive_run( $groups, $types, $min_match, $scan, $term_ids, $taxonomy, $neg_terms, $query_hash, $required );

		// Groups behind the current result set: a layout-swap or fuzzy rescue below
		// replaces the results, and the product-type re-rank must compare against
		// the stems that actually produced them.
		$rank_groups = $groups;

		$threshold = (int) apply_filters( 'mvweb_ss_fuzzy_threshold', self::FUZZY_THRESHOLD );

		// Aggressive typo tolerance (P2.5, default-off): run the layout-swap and
		// fuzzy stages on every query, not only when the exact pass came up short.
		// Each stage still adopts its result only when it finds strictly more, so
		// a clean result set is never replaced by a noisier fuzzy one. Off by
		// default — it widens the candidate scan, so enable and compare on the
		// catalog. First-letter typos remain the job of the opt-in deletes table.
		$aggressive = (bool) MVweb_SS_Settings::get( 'fuzzy_aggressive', false );

		// Both rescues rewrite the query — the layout one wholesale, the typo one
		// word by word — and both adopt the rewrite when it returns more rows. A
		// rewritten query almost always does. That trade is fair for a query made
		// of ordinary words, and wrong for one naming a model or a part number: a
		// short code answers with one product, and six neighbouring codes outnumber
		// it every time, so the shopper is handed a battery for a different phone
		// under a "showing results for BN52" banner. While such a query has found
		// something, there is nothing to rescue.
		$named_model = self::has_model_term( $words );

		if ( MVweb_SS_Settings::get( 'fuzzy', true )
			&& ( empty( $results ) || ! $named_model )
			&& ( $aggressive || count( $results ) < $threshold ) ) {
			// Wrong keyboard-layout recovery: a query typed in the other layout
			// ("ghbdtn" instead of "привет") is swapped and retried; adopted only
			// when it actually finds more than the original.
			$swapped = self::swap_layout( $clean_query );

			if ( '' !== $swapped ) {
				$swap_words = MVweb_SS_Tokenizer::tokenize_words( $swapped, '', self::query_parts_budget() );

				if ( ! empty( $swap_words ) ) {
					$swap_match = self::min_match( $strictness, MVweb_SS_Tokenizer::word_count( $swapped ) );

					list( $swap_words, $swap_required ) = self::model_words( $swap_words, ! empty( $args['prefix'] ) );

					$swap_groups  = self::expand_groups( $swap_words, '', $translit );
					$swap_results = self::adaptive_run( $swap_groups, $types, $swap_match, $scan, $term_ids, $taxonomy, $neg_terms, $query_hash, self::required_groups( $swap_groups, $swap_required ) );

					if ( count( $swap_results ) > count( $results ) ) {
						$results          = $swap_results;
						$rank_groups      = $swap_groups;
						self::$correction = trim( $swapped );
						self::$rescue     = 'layout';
					}
				}
			}

			// Typo tolerance: still scarce after the layout swap, widen with fuzzy candidates.
			if ( $aggressive || count( $results ) < $threshold ) {
				$fuzzy_groups = self::groups_with_fuzzy( $words, $required_terms );

				if ( self::group_term_count( $fuzzy_groups ) > self::group_term_count( $words ) ) {
					$fuzzy = self::adaptive_run( $fuzzy_groups, $types, $min_match, $scan, $term_ids, $taxonomy, $neg_terms, $query_hash, self::required_groups( $fuzzy_groups, $required_terms ) );

					if ( count( $fuzzy ) > count( $results ) ) {
						$results          = $fuzzy;
						$rank_groups      = $fuzzy_groups;
						self::$correction = self::derive_correction( $clean_query, $fuzzy );
						self::$rescue     = 'typo';
					}
				}
			}
		}

		// Zero-result ladder (P1.7): a pass that found nothing steps its floor down
		// one rung at a time and stops at the first rung that returns something, so
		// a dead end becomes the strictest non-empty answer rather than a plain OR.
		// Dropping straight to 1 was measurably worse: on a 13k-product catalogue
		// the strict setting turned "iPhone 16 po max lcd" into 500 rows, 294 of
		// them without a 16 anywhere, because one unmatchable word ("po", too short
		// for a fuzzy variant) made the AND pass empty and the retry took the floor
		// off entirely. Required groups survive the descent — the model number is
		// the point of the query, not a preference — and nothing below lets them
		// go: a number the catalogue does not carry ends the search (see below).
		if ( empty( $results ) && $min_match > 1 ) {
			$rungs = self::run( $groups, $types, 1, $scan, $term_ids, $taxonomy, $neg_terms, $query_hash, $required );

			for ( $floor = $min_match - 1; $floor >= 1 && empty( $results ); $floor-- ) {
				$results = self::rung( $rungs, $floor, count( $groups ) );
			}
		}

		// A number the catalogue does not carry ends the search. The pass used to
		// release it and answer with whatever the remaining words matched, on the
		// reasoning that products beat a dead end — but a part number is the one
		// word that is not a preference: it names the device the part has to fit,
		// and a listing gives the shopper no way to tell that the parts on screen
		// fit a different one. On a parts catalogue that is the common case, not the
		// corner: measured on a 12 460-product shop, an unstocked code answered with
		// ten unrelated parts and no sign that the code was never found. So the
		// surface is told what happened and says so.
		if ( empty( $results ) && ! empty( $required ) ) {
			self::$unmatched_model = true;
		}

		// Keep the part the shopper named, drop the parts that merely fit the
		// same phone. Runs on the groups that produced the current set, so a
		// layout-swap or typo rescue is judged by its own words.
		$results = self::type_filter( $rank_groups, $results );

		// Phrase-proximity re-rank (P1.3, opt-in): within each coverage tier, float
		// titles that contain the query as a phrase / in order above scattered-word
		// titles. Runs before the exact boost so an exact title still wins the top.
		if ( MVweb_SS_Settings::get( 'boost_proximity', false ) ) {
			$results = self::proximity_rerank( $clean_query, $results );
		}

		// Model-variant re-rank: within each coverage tier, float the plain model
		// above the siblings whose modifiers the query never named. Runs before
		// the product-type pass, so what the product *is* stays the stronger
		// signal than which of its model's variants it fits.
		if ( MVweb_SS_Settings::get( 'variant_order', true ) ) {
			$results = self::variant_rerank( $clean_query, $results );
		}

		// Product-type re-rank (opt-in): within each coverage tier, float the
		// part the shopper named above accessories that merely mention it. Runs
		// after proximity so the phrase signal orders the ties inside each tier.
		if ( MVweb_SS_Settings::get( 'boost_head', false ) ) {
			$results = self::head_rerank( $rank_groups, $results );
		}

		// Exact-match boost: a result whose title or SKU is exactly the query jumps
		// to the top, above a merely high-scoring partial match (P0.3).
		$results = self::promote_exact( $clean_query, $results );

		// Every pass has now had the whole scanned head, so it is cut to the size
		// the caller asked for. Pins are applied after the cut and fetch their own
		// rows, so a pinned product still reaches the top of a short list.
		if ( count( $results ) > $limit ) {
			$results = array_slice( $results, 0, $limit );
		}

		$pins = MVweb_SS_Settings::pins_for( $query );

		if ( ! empty( $pins ) ) {
			$results = self::apply_pins( $pins, $types, $results, $limit, $term_ids, $taxonomy );
		}

		/**
		 * Filter the final ranked results (used for language filtering and integrations).
		 *
		 * @since 1.0.0
		 * @param array  $results Ranked results.
		 * @param string $query   Raw user query.
		 * @param array  $types   Post types searched.
		 */
		return (array) apply_filters( 'mvweb_ss_results', $results, $query, $types );
	}

	/**
	 * Run the search demanding every word, and loosen only if that leaves
	 * nothing to look at.
	 *
	 * The floor used to be decided before the query ran: "balanced" meant a
	 * third of the words could be dropped, always, whether or not the strict
	 * reading had plenty of answers. On a parts catalogue that is what turns
	 * "iPhone 16 pro lcd" into 130 results — flex cables, glasses and SIM trays
	 * clear three words out of four and the one word naming the part is the one
	 * dropped. Measured against a written-down ground truth over 15 cases:
	 * precision 7% that way, 82% when every word is demanded, with recall
	 * unchanged at 100% either way.
	 *
	 * So the pass starts at full coverage and steps down one rung at a time,
	 * stopping as soon as a rung returns more than RELAX_BELOW rows. The
	 * strictness setting is the bottom of that descent, not its start: "strict"
	 * forbids the descent, "balanced" allows a third of the words, "loose" all
	 * the way to one. Nothing gets looser than before — only stricter when the
	 * catalogue can afford it.
	 *
	 * @since 1.5.9
	 * @param array<int,string[]> $groups        Coverage groups.
	 * @param string[]            $types         Post types.
	 * @param int                 $floor         Lowest coverage the strictness setting permits.
	 * @param int                 $limit         Max rows.
	 * @param int[]               $term_ids      Taxonomy filter.
	 * @param string              $taxonomy      Taxonomy of those terms.
	 * @param string[]            $exclude_terms Boolean NOT stems.
	 * @param string              $query_hash    Click-boost hash.
	 * @param int[]               $required      Groups that must match.
	 * @return array<int,array{object_id:int,object_type:string,score:float}>
	 */
	private static function adaptive_run( array $groups, array $types, int $floor, int $limit, array $term_ids, string $taxonomy, array $exclude_terms, string $query_hash, array $required ): array {
		$ceiling = count( $groups );
		$floor   = max( 1, min( $floor, $ceiling ) );

		/**
		 * Filter how few results a pass may return before the floor drops.
		 *
		 * @since 1.5.9
		 * @param int $threshold Result count at or below which the search loosens.
		 */
		$relax = (int) apply_filters( 'mvweb_ss_relax_below', self::RELAX_BELOW );

		// The rungs of the descent are one query, not many. Every one of them runs
		// the same statement — same terms, same joins, same scoring, same ORDER BY,
		// same LIMIT — and differs only in the `matched >= N` its HAVING demands.
		// Since the sort leads with coverage, the rows of a strict rung are the head
		// of the loose one, so a single pass at the floor carries every rung above
		// it and the descent becomes a filter on a column the rows already carry.
		// Measured on a 12 460 product catalogue: a nine-word query ran the same
		// 1 300 ms statement three times, and a twelve-word one sixteen times.
		$rows = self::run( $groups, $types, $floor, $limit, $term_ids, $taxonomy, $exclude_terms, $query_hash, $required );

		for ( $need = $ceiling; $need > $floor; $need-- ) {
			$results = self::rung( $rows, $need, $ceiling );

			if ( count( $results ) > $relax ) {
				return $results;
			}
		}

		return $rows;
	}

	/**
	 * The rows of a floor pass that also clear a stricter coverage rung.
	 *
	 * Mirrors run()'s own HAVING: the clause is emitted only above one, and the
	 * coverage it demands is capped at the number of groups — a word that yields
	 * no indexable term leaves fewer groups than the strictness floor counted.
	 *
	 * @since 1.6.4
	 * @param array $rows    Rows of the floor pass.
	 * @param int   $need    Coverage demanded.
	 * @param int   $ceiling Number of coverage groups.
	 * @return array
	 */
	private static function rung( array $rows, int $need, int $ceiling ): array {
		if ( $need <= 1 ) {
			return $rows;
		}

		$need = min( $need, $ceiling );

		return array_values(
			array_filter(
				$rows,
				static function ( $row ) use ( $need ) {
					return $row['matched'] >= $need;
				}
			)
		);
	}

	/**
	 * Keep only the products that are the thing the shopper named.
	 *
	 * A part catalogue names a product by what it is and then what it fits:
	 * "LCD iPhone 16 Pro", "Шлейф для iPhone 16 Pro". Every word of "iPhone 16
	 * pro lcd" is present in both, so demanding all of them still leaves the
	 * flex cable in — and worse, "Рамка дисплея" carries the word display while
	 * being a frame, not a display. Comparing the head of the title against the
	 * query answers both: the frame's head is "рамка", the cable's is "шлейф",
	 * and neither is a word the shopper typed.
	 *
	 * Applied only when some result does lead with a queried word, so a query
	 * naming no part type ("iPhone 16 Pro Max") is untouched, and skipped when
	 * it would leave too little — a catalogue writing "iPhone 14 дисплей"
	 * instead keeps working. Measured on 15 ground-truth cases: F1 0.81 → 0.86,
	 * with precision reaching 100% on the queries that name a part.
	 *
	 * @since 1.5.9
	 * @param array<int,string[]> $groups  Coverage groups behind the results.
	 * @param array               $results Ranked results.
	 * @return array
	 */
	private static function type_filter( array $groups, array $results ): array {
		if ( count( $results ) < 2 || ! MVweb_SS_Settings::get( 'type_filter', true ) ) {
			return $results;
		}

		$stems = array_flip( self::flatten_groups( $groups ) );

		if ( empty( $stems ) ) {
			return $results;
		}

		// One query for every title instead of one per row: get_the_title()
		// reads the post cache, and priming it is what keeps this affordable
		// over a thousand-row pool.
		$ids = array();

		foreach ( $results as $row ) {
			$ids[] = (int) $row['object_id'];
		}

		_prime_post_caches( $ids, false, false );

		$kept = array();

		foreach ( $results as $row ) {
			foreach ( self::title_type_stems( (int) $row['object_id'] ) as $stem ) {
				if ( isset( $stems[ $stem ] ) ) {
					$kept[] = $row;
					break;
				}
			}
		}

		// Nothing matched: the catalogue words its titles the other way round
		// ("iPhone 14 дисплей"), so the rule does not apply here — leave the
		// results as they were rather than emptying the page.
		return empty( $kept ) ? $results : $kept;
	}

	/**
	 * The words that say what a product *is* — the head noun and the adjectives
	 * standing in front of it.
	 *
	 * Reading the first word alone is not enough: a Russian parts catalogue
	 * writes "Защитное стекло" as often as "Стекло защитное", and the first word
	 * there is an adjective. Leading adjectives are therefore skipped on the way
	 * to the noun, so both spellings resolve to "стекло". The window stops well
	 * before the device name, which keeps "Рамка дисплея" resolving to "рамка" —
	 * a frame is not a display, however prominently it says display.
	 *
	 * They are returned beside the noun rather than thrown away, because a
	 * shopper names a part by whichever of the two is the distinguishing one.
	 * "Защитное note 13 pro 4g" never says "стекло" — the adjective alone is the
	 * part, and the noun is the part of the phrase left unsaid. Keying only on
	 * the noun left that query with no type at all, so the rule stood down and
	 * answered a request for a screen protector with flex cables and SIM trays
	 * for the right phone.
	 *
	 * @since 1.5.9
	 * @param int $object_id Product ID.
	 * @return string[] Stems of the leading adjectives and the head noun.
	 */
	private static function title_type_stems( int $object_id ): array {
		$title = wp_strip_all_tags( (string) get_the_title( $object_id ) );
		$words = preg_split( '/[^\p{L}\p{N}\-]+/u', mb_strtolower( $title, 'UTF-8' ), -1, PREG_SPLIT_NO_EMPTY );

		if ( ! is_array( $words ) ) {
			return array();
		}

		$seen = 0;
		$type = array();

		foreach ( $words as $word ) {
			if ( $seen >= self::TYPE_HEAD_WINDOW ) {
				break;
			}

			$stems = array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( (string) $word ) ) );

			if ( empty( $stems ) ) {
				continue;
			}

			++$seen;
			$type[] = $stems[0];

			// Russian adjective endings: a leading modifier, not the noun.
			if ( preg_match( '/(ое|ый|ой|ая|ые|ий|яя|ее|ого|ому|ым|ых)$/u', (string) $word ) ) {
				continue;
			}

			return $type;
		}

		return array();
	}

	/**
	 * Glued-model run budget applied to the query side.
	 *
	 * Mirrors what the indexer does to identifier fields: a shopper who pastes a
	 * supplier SKU must not have it torn into digit runs that then match every
	 * unrelated product carrying those digits in its name.
	 *
	 * @since 1.5.8
	 * @return int
	 */
	private static function query_parts_budget(): int {
		return (int) apply_filters( 'mvweb_ss_model_parts_budget', MVweb_SS_Tokenizer::MAX_MODEL_PARTS, 'query' );
	}

	/**
	 * Resolve the digit-bearing words of a query against the catalogue and mark
	 * them required.
	 *
	 * The number is what separates two otherwise identical parts, and treating it
	 * as one optional concept among many is what lets "iphone 16 pro max lcd"
	 * answer with an iPhone 13 screen: the other four words already clear the
	 * strictness floor. Worse, a glued model arrives as a bag of alternatives —
	 * "note13" expands to note13/note/13, any one of which satisfies the group —
	 * so "Redmi Note 8" counts as a full match. Measured on a 13k-product
	 * catalogue: "note13" returned 1000 rows of which 89 were a Note 13, "8s"
	 * returned 1000 of which 23 were an 8S.
	 *
	 * So a glued model is first looked for whole — the catalogue is asked whether
	 * any term starts with it, which also reaches "g980f" from "g980". Whole hits
	 * become the group, and its parts are dropped. Only when nothing carries the
	 * model whole does it fall back to the parts, and then every part becomes its
	 * own required group, so "note13" means note AND 13 rather than note OR 13.
	 *
	 * The last word is exempt while the shopper is still typing it: a half-written
	 * number is not a requirement, it is a keystroke. Demanding it turns "мвфон 1"
	 * into a hunt for the digit 1 — measured on the sandbox catalogue, the four
	 * phones the shopper was reaching for gave way to two unrelated products whose
	 * names happen to carry a 1. The dropdown already treats that word as a prefix
	 * rather than a word for the same reason. A model nobody carries is narrowed to
	 * itself either way — its own fragments left in the group would let a bare digit
	 * pass for it — and only the pinning is skipped while the word is being typed.
	 *
	 * A model modifier following the number (MODEL_QUALIFIERS: "pro", "max", …) is
	 * pinned with it, since an M3 and an M3 Pro are different devices whose parts do
	 * not interchange. Only a word directly behind a model counts, so "чехол pro"
	 * pins nothing, while a run of them ("13 pro max") is pinned whole.
	 *
	 * @since 1.5.8
	 * @param array<int,string[]> $words  Query terms grouped by written word.
	 * @param bool                $typing Whether the last word is still being typed.
	 * @return array{0:array<int,string[]>,1:string[]} Rewritten words, and one representative
	 *                                                 term per required group.
	 */
	private static function model_words( array $words, bool $typing = false ): array {
		if ( ! MVweb_SS_Settings::get( 'model_required', true ) ) {
			return array( $words, array() );
		}

		$out      = array();
		$required = array();
		$last     = count( $words ) - 1;
		$after    = false;

		foreach ( $words as $wi => $word ) {
			// The word under the cursor is a keystroke, not a requirement — unless
			// the catalogue carries nothing that even begins with it. A half-written
			// number is on its way to something ("rmx352" reaches rmx3521), and the
			// exemption is what keeps the dropdown from emptying out mid-word; a
			// number no term starts with is on its way nowhere, and leaving it
			// unpinned answers a part number with parts for other devices. The
			// prefix lookup is the one already made to resolve the model, so this
			// costs no extra query.
			$whole = self::glued_model( $word );
			$pin   = ! ( $typing && $wi === $last )
				|| ( '' !== $whole && empty( self::catalog_prefix_terms( $whole ) ) );

			// A modifier trailing a model is part of the device's name, not a
			// preference: an M3 and an M3 Pro are different phones and their screens
			// do not interchange. It carries no digit, so the model discipline below
			// never reaches it and the strictness floor drops this word first —
			// exactly the one that decides which phone the shopper meant.
			if ( $after && self::is_qualifier( $word ) ) {
				$out[] = $word;

				if ( $pin ) {
					$required[] = $word[0];
				}

				continue;
			}

			$after = false;

			if ( '' === $whole ) {
				$digits = self::digit_terms( $word );

				// A bare number ("16", "11") is already one group; pin it as required.
				if ( ! empty( $digits ) ) {
					$after = true;

					if ( $pin ) {
						$required[] = $digits[0];
					}
				}

				$out[] = $word;
				continue;
			}

			$after   = true;
			$catalog = self::catalog_prefix_terms( $whole );

			if ( ! empty( $catalog ) ) {
				$out[] = array_values( array_unique( array_merge( array( $whole ), $catalog ) ) );

				if ( $pin ) {
					$required[] = $whole;
				}

				continue;
			}

			// Nobody carries the model whole: split it into parts. While the word is
			// still being typed the parts stay one group — splitting a half-written
			// code into separate concepts would demand more of it, not less.
			$parts = self::model_part_terms( $whole );

			// A model nobody carries — whole or in parts — is matched by itself alone,
			// never by a scrap of itself. Its own fragments left beside it are what let
			// a bare digit stand in for it: a query typed in the wrong layout ("bn5p" →
			// "ит5з") falls apart into "ит" and "5", and that "5" matches half the
			// catalogue, which is enough to outnumber the right answer and replace it.
			// The word under the cursor is narrowed the same way but stays unpinned: a
			// half-typed code is still a keystroke, and reaching the codes it is
			// growing towards is the prefix expansion's job, not a fragment's.
			if ( count( $parts ) < 2 ) {
				$out[] = array( $whole );

				if ( $pin ) {
					$required[] = $whole;
				}

				continue;
			}

			if ( ! $pin ) {
				$out[] = $word;
				continue;
			}

			foreach ( $parts as $part ) {
				$out[]      = array( $part );
				$required[] = $part;
			}
		}

		return array( $out, array_values( array_unique( $required ) ) );
	}

	/**
	 * Whether the query names a model or a part number.
	 *
	 * Read from the written words rather than from the required list: in the
	 * dropdown the word under the cursor is deliberately left unpinned, and a
	 * one-word part number is exactly that word.
	 *
	 * @since 1.6.0
	 * @param array<int,string[]> $words Query terms grouped by written word.
	 * @return bool
	 */
	private static function has_model_term( array $words ): bool {
		foreach ( $words as $word ) {
			foreach ( $word as $term ) {
				if ( preg_match( '/\d/', (string) $term ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Whether a written word is a model modifier following a model number.
	 *
	 * The list is deliberately short and latin: these are the words phone makers
	 * append to a model to name a different device. A modifier carrying a digit
	 * ("5g") needs no entry — the model discipline already pins anything with a
	 * number in it.
	 *
	 * @since 1.6.0
	 * @param string[] $word Terms derived from one written word.
	 * @return bool
	 */
	private static function is_qualifier( array $word ): bool {
		if ( 1 !== count( $word ) ) {
			return false;
		}

		/**
		 * Filter the model modifiers treated as part of a device's name.
		 *
		 * @since 1.6.0
		 * @param string[] $qualifiers Lowercase stems.
		 */
		$qualifiers = (array) apply_filters( 'mvweb_ss_model_qualifiers', self::MODEL_QUALIFIERS );

		return in_array( $word[0], $qualifiers, true );
	}

	/**
	 * Every spelling of a model modifier mapped onto its canon.
	 *
	 * Built from the filtered qualifier list, so a catalogue that adds "turbo"
	 * gets it in the variant order too, plus the cyrillic aliases of whichever
	 * canons survived the filter — an alias whose canon was removed is dropped
	 * with it.
	 *
	 * @since 1.6.1
	 * @return array<string,string> Spelling => canon, all lowercase.
	 */
	public static function qualifier_map(): array {
		$map = array();

		foreach ( (array) apply_filters( 'mvweb_ss_model_qualifiers', self::MODEL_QUALIFIERS ) as $canon ) {
			$canon = mb_strtolower( trim( (string) $canon ), 'UTF-8' );

			if ( '' !== $canon ) {
				$map[ $canon ] = $canon;
			}
		}

		foreach ( self::MODEL_QUALIFIER_ALIASES as $alias => $canon ) {
			if ( isset( $map[ $canon ] ) ) {
				$map[ $alias ] = $canon;
			}
		}

		return $map;
	}

	/**
	 * The glued model term of a word (letters and digits in one token), or ''.
	 *
	 * @since 1.5.8
	 * @param string[] $word Terms derived from one written word.
	 * @return string
	 */
	private static function glued_model( array $word ): string {
		$best = '';

		foreach ( $word as $term ) {
			if ( ! preg_match( '/\d/', $term ) || ! preg_match( '/\p{L}/u', $term ) ) {
				continue;
			}

			if ( MVweb_SS_Tokenizer::model_parts( $term ) < 2 ) {
				continue;
			}

			if ( mb_strlen( $term, 'UTF-8' ) > mb_strlen( $best, 'UTF-8' ) ) {
				$best = $term;
			}
		}

		return $best;
	}

	/**
	 * Terms of a word that are pure digits.
	 *
	 * @since 1.5.8
	 * @param string[] $word Terms derived from one written word.
	 * @return string[]
	 */
	private static function digit_terms( array $word ): array {
		return array_values(
			array_filter(
				$word,
				static function ( $term ) {
					return (bool) preg_match( '/^\d+$/', (string) $term );
				}
			)
		);
	}

	/**
	 * Indexable letter/digit runs of a glued model token.
	 *
	 * @since 1.5.8
	 * @param string $model Glued model token.
	 * @return string[]
	 */
	private static function model_part_terms( string $model ): array {
		if ( ! preg_match_all( '/\p{L}+|\d+/u', $model, $m ) ) {
			return array();
		}

		$parts = array();

		foreach ( $m[0] as $run ) {
			$run = (string) $run;

			if ( mb_strlen( $run, 'UTF-8' ) < MVweb_SS_Tokenizer::MIN_TERM_LENGTH ) {
				continue;
			}

			$parts[ $run ] = true;
		}

		// strval() because PHP turns a numeric array key into an int, and a term
		// that arrives as int 13 no longer matches the string "13" the groups hold.
		return array_map( 'strval', array_keys( $parts ) );
	}

	/**
	 * Index terms starting with a model token, capped and cached.
	 *
	 * A prefix rather than an equality test so a query for "g980" still reaches
	 * the catalogue's "g980f", the way a shopper who drops the trailing revision
	 * letter expects.
	 *
	 * @since 1.5.8
	 * @param string $model Glued model token.
	 * @return string[]
	 */
	private static function catalog_prefix_terms( string $model ): array {
		global $wpdb;

		static $memo = array();

		if ( isset( $memo[ $model ] ) ) {
			return $memo[ $model ];
		}

		$cache_key = 'model_prefix_' . md5( $model );
		$cached    = wp_cache_get( $cache_key, 'mvweb_ss' );

		if ( is_array( $cached ) ) {
			$memo[ $model ] = $cached;
			return $cached;
		}

		$table = MVweb_SS_Schema::table_name();

		$terms = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT DISTINCT term FROM `$table` WHERE term LIKE %s LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$wpdb->esc_like( $model ) . '%',
				self::MODEL_PREFIX_LIMIT
			)
		);

		$terms = is_array( $terms ) ? array_map( 'strval', $terms ) : array();

		wp_cache_set( $cache_key, $terms, 'mvweb_ss', MINUTE_IN_SECONDS * 10 );

		$memo[ $model ] = $terms;

		return $terms;
	}

	/**
	 * Map required representative terms onto the coverage groups holding them.
	 *
	 * @since 1.5.8
	 * @param array<int,string[]> $groups Coverage groups.
	 * @param string[]            $terms  Representative terms of the required groups.
	 * @return int[] Group indexes that must be matched.
	 */
	private static function required_groups( array $groups, array $terms ): array {
		if ( empty( $terms ) ) {
			return array();
		}

		$required = array();
		$wanted   = array_flip( array_map( 'strval', $terms ) );

		foreach ( $groups as $gi => $group ) {
			foreach ( $group as $term ) {
				// Compared as strings on both sides: a numeric term travels through
				// array keys in places and comes back as an int, and a strict match
				// against the string would silently drop the requirement.
				if ( isset( $wanted[ (string) $term ] ) ) {
					$required[ $gi ] = true;
					break;
				}
			}
		}

		return array_keys( $required );
	}

	/**
	 * Expand query terms into coverage groups: each original word seeds a group,
	 * and its synonyms, transliterations and (later) fuzzy variants join that same
	 * group. Grouping is what keeps coverage honest — a word and its synonym count
	 * as one covered concept, not two, so "батарея"+"аккумулятор" no longer
	 * out-covers a genuine two-word match (P0.2).
	 *
	 * A synonym rule fires when ALL of its pattern stems are present among the
	 * query terms (order-independent); its additions attach to the group of the
	 * pattern's anchor word. The trailing, still-being-typed word may match a
	 * pattern stem by prefix so a synonym fires before the word is finished.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $words    Query terms grouped by the word they came from.
	 * @param string              $partial  Stem of the still-being-typed trailing word, or ''.
	 * @param bool                $translit Whether to add cross-script transliterations.
	 * @return array<int,string[]> Coverage groups (each a list of terms).
	 */
	private static function expand_groups( array $words, string $partial = '', bool $translit = false ): array {
		// Memoize per request: expand_groups() is called on the primary run, the
		// layout-swap retry, the fuzzy retry and in term_match_counts(), often with
		// the same terms. The key must include $partial and $translit — the fuzzy
		// path calls with $partial='' and $translit=false regardless of the setting,
		// so a terms-only key would hand back the wrong (cross-script) expansion.
		static $memo = array();

		$terms = self::flatten_groups( $words );

		// The key keeps the word boundaries, not just the flat term list: since
		// model_words() may hand one written word over as several ("note13" → note
		// + 13), the same terms can arrive as one group or as two, and those are
		// different expansions. A flat key served the first shape to the second
		// caller — measured: "мвноут 13" came back with the groups built for
		// "мвноут13", losing its required number along the way.
		$shape = array();

		foreach ( $words as $word ) {
			$shape[] = implode( "\0", (array) $word );
		}

		$memo_key = md5( implode( "\1", $shape ) . '|' . $partial . '|' . ( $translit ? '1' : '0' ) );

		if ( isset( $memo[ $memo_key ] ) ) {
			return $memo[ $memo_key ];
		}

		$groups = array();
		$index  = array();

		// One written word = one coverage group, however many index terms it split
		// into. "a515" contributes both "a515" and "515" to the same group, so the
		// glued code stays one concept instead of two the shopper never typed.
		foreach ( $words as $word ) {
			$gi = count( $groups );

			foreach ( $word as $term ) {
				if ( isset( $index[ $term ] ) ) {
					continue;
				}

				if ( ! isset( $groups[ $gi ] ) ) {
					$groups[ $gi ] = array();
				}

				$index[ $term ]  = $gi;
				$groups[ $gi ][] = $term;
			}
		}

		if ( empty( $groups ) ) {
			$memo[ $memo_key ] = array();
			return array();
		}

		if ( $translit ) {
			foreach ( $terms as $term ) {
				foreach ( self::transliterations( $term ) as $variant ) {
					self::attach( $groups, $index, $index[ $term ], $variant );
				}
			}
		}

		$rules = MVweb_SS_Settings::synonym_map();

		if ( ! empty( $rules ) ) {
			$term_set = array_flip( $terms );

			foreach ( $rules as $rule ) {
				$used_prefix = false;
				$anchor      = null;

				foreach ( $rule['pattern'] as $stem ) {
					$stem = (string) $stem;

					if ( isset( $term_set[ $stem ] ) ) {
						if ( null === $anchor ) {
							$anchor = $stem;
						}
						continue;
					}

					if ( '' !== $partial && ! $used_prefix && 0 === mb_strpos( $stem, $partial, 0, 'UTF-8' ) ) {
						$used_prefix = true;

						if ( null === $anchor && isset( $index[ $partial ] ) ) {
							$anchor = $partial;
						}

						continue;
					}

					continue 2;
				}

				if ( null === $anchor || ! isset( $index[ $anchor ] ) ) {
					$anchor = $terms[0];
				}

				foreach ( $rule['add'] as $add ) {
					self::attach( $groups, $index, $index[ $anchor ], (string) $add );
				}
			}
		}

		$memo[ $memo_key ] = $groups;

		return $groups;
	}

	/**
	 * Attach a term to an existing coverage group unless it is already placed.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups Coverage groups (by reference).
	 * @param array<string,int>   $index  term => group index (by reference).
	 * @param int                 $gi     Target group index.
	 * @param string              $term   Term to attach.
	 * @return void
	 */
	private static function attach( array &$groups, array &$index, int $gi, string $term ): void {
		if ( '' === $term || isset( $index[ $term ] ) ) {
			return;
		}

		$index[ $term ]  = $gi;
		$groups[ $gi ][] = $term;
	}

	/**
	 * Attach index terms that start with the trailing query word to that word's
	 * coverage group (P1.5 search-as-you-type). The trailing word is the last of
	 * $terms; its group gets every stored term matching "trailing%" (and the same
	 * for the trailing word's transliteration), capped and length-gated. Because
	 * the additions join one existing group, they lift matching products without
	 * inflating coverage — exactly like a synonym.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups   Coverage groups (by reference).
	 * @param array<int,string[]> $words    Query terms grouped by word (order preserved).
	 * @param bool                $translit Whether to prefix-match the transliteration too.
	 * @return void
	 */
	private static function attach_prefix_terms( array &$groups, array $words, bool $translit ): void {
		if ( empty( $words ) ) {
			return;
		}

		// Anchor on the trailing word itself, not on the last term it split into:
		// a model code ("a515") ends on its bare number, and prefixing that pulls
		// unrelated numbers ("51549788") while never reaching "a515f".
		$last = (array) end( $words );

		$anchor = (string) reset( $last );

		if ( mb_strlen( $anchor, 'UTF-8' ) < self::PREFIX_MIN_LEN ) {
			return;
		}

		$gi = null;

		foreach ( $groups as $i => $group ) {
			if ( in_array( $anchor, $group, true ) ) {
				$gi = $i;
				break;
			}
		}

		if ( null === $gi ) {
			return;
		}

		$placed = array();
		foreach ( $groups as $group ) {
			foreach ( $group as $term ) {
				$placed[ $term ] = true;
			}
		}

		foreach ( self::prefix_terms( $anchor, $translit ) as $term ) {
			if ( isset( $placed[ $term ] ) ) {
				continue;
			}

			$groups[ $gi ][] = $term;
			$placed[ $term ] = true;
		}
	}

	/**
	 * Distinct index terms starting with the given stem (and, optionally, its
	 * transliteration), capped per prefix. The BTREE index on `term` makes the
	 * `LIKE 'stem%'` lookup a range scan; the length gate and cap keep a broad
	 * prefix from pulling a huge vocabulary slice.
	 *
	 * @since 1.2.0
	 * @param string $stem     Trailing word stem (already length-checked by caller).
	 * @param bool   $translit Whether to also prefix-match the transliteration.
	 * @return string[] Matching index terms (may be empty).
	 */
	private static function prefix_terms( string $stem, bool $translit ): array {
		global $wpdb;

		// The dropdown calls search() once per post type in scope; the prefix lookup
		// depends only on the stem, so memoize it per request to avoid repeating the
		// same LIKE scans for each type.
		static $memo = array();

		$cache_key = $stem . '|' . ( $translit ? '1' : '0' );

		if ( isset( $memo[ $cache_key ] ) ) {
			return $memo[ $cache_key ];
		}

		$prefixes = array( $stem );

		if ( $translit ) {
			foreach ( self::transliterations( $stem ) as $variant ) {
				$prefixes[] = $variant;
			}
		}

		// A model code transliterates to its bare number ("a515" → "515"), and
		// prefixing that pulls every unrelated code that happens to start with the
		// same digits. Digits-only prefixes are kept only when the shopper is in
		// fact typing a number ("150" reaching "150мм").
		$numeric = ctype_digit( $stem );

		$prefixes = array_values(
			array_filter(
				array_unique( $prefixes ),
				static function ( $prefix ) use ( $numeric ) {
					if ( ! $numeric && ctype_digit( (string) $prefix ) ) {
						return false;
					}

					return mb_strlen( (string) $prefix, 'UTF-8' ) >= self::PREFIX_MIN_LEN;
				}
			)
		);

		if ( empty( $prefixes ) ) {
			$memo[ $cache_key ] = array();
			return array();
		}

		$table = MVweb_SS_Schema::table_name();
		$out   = array();

		foreach ( $prefixes as $prefix ) {
			$like = $wpdb->esc_like( (string) $prefix ) . '%';
			$sql  = "SELECT DISTINCT term FROM `$table` WHERE term LIKE %s LIMIT %d";
			$rows = $wpdb->get_col( $wpdb->prepare( $sql, $like, self::PREFIX_CAP ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery

			foreach ( (array) $rows as $term ) {
				$out[] = (string) $term;
			}
		}

		$memo[ $cache_key ] = array_values( array_unique( $out ) );

		return $memo[ $cache_key ];
	}

	/**
	 * Build coverage groups where each fuzzy candidate joins its source term's
	 * group, so typo variants never inflate coverage either.
	 *
	 * A required group is left alone: model numbers sit one edit apart from each
	 * other ("16" and "15", "a51" and "a52"), so a typo variant there would quietly
	 * answer with the neighbouring model — the exact confusion the requirement
	 * exists to prevent. A misspelt model is better served by finding nothing and
	 * saying so than by finding the wrong part.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $words    Query terms grouped by word.
	 * @param string[]            $required Representative terms of groups to leave unexpanded.
	 * @return array<int,string[]>
	 */
	private static function groups_with_fuzzy( array $words, array $required = array() ): array {
		$groups = self::expand_groups( $words );
		$terms  = self::flatten_groups( $words );
		$pinned = array_flip( self::required_groups( $groups, $required ) );

		$index = array();
		foreach ( $groups as $gi => $group ) {
			foreach ( $group as $term ) {
				$index[ $term ] = $gi;
			}
		}

		foreach ( $terms as $term ) {
			if ( mb_strlen( $term, 'UTF-8' ) < MVweb_SS_Fuzzy::MIN_LENGTH || ! isset( $index[ $term ] ) ) {
				continue;
			}

			if ( isset( $pinned[ $index[ $term ] ] ) ) {
				continue;
			}

			foreach ( MVweb_SS_Fuzzy::candidates( $term ) as $candidate ) {
				self::attach( $groups, $index, $index[ $term ], (string) $candidate );
			}
		}

		return $groups;
	}

	/**
	 * Flatten coverage groups to a unique term list (WHERE i.term IN order).
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups Coverage groups.
	 * @return string[]
	 */
	private static function flatten_groups( array $groups ): array {
		$out = array();

		foreach ( $groups as $group ) {
			foreach ( $group as $term ) {
				$out[] = (string) $term;
			}
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Total number of distinct terms across all coverage groups.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups Coverage groups.
	 * @return int
	 */
	private static function group_term_count( array $groups ): int {
		return count( self::flatten_groups( $groups ) );
	}

	/**
	 * Cross-script phonetic variants of a single-script term, stemmed the same way
	 * the index stored its terms. A Cyrillic word yields its Latin spelling and a
	 * Latin word its Cyrillic one ("samsung"↔"самсунг"), so a query reaches
	 * products written in the other script. Best-effort — exact brand spellings
	 * the phonetic map misses ("айфон", "сяоми") belong in the synonym dictionary.
	 *
	 * @since 1.2.0
	 * @param string $term Query term (already stemmed).
	 * @return string[] Stemmed variant terms (may be empty).
	 */
	private static function transliterations( string $term ): array {
		if ( mb_strlen( $term, 'UTF-8' ) < 3 ) {
			return array();
		}

		$has_cyr = (bool) preg_match( '/\p{Cyrillic}/u', $term );
		$has_lat = (bool) preg_match( '/[a-z]/', $term );

		if ( $has_cyr === $has_lat ) {
			return array();
		}

		$raw = $has_cyr ? self::cyr_to_lat( $term ) : self::lat_to_cyr( $term );

		if ( '' === $raw || $raw === $term ) {
			return array();
		}

		// Transliterated whole, never split into runs. A transliteration is the same
		// word in the other alphabet, so its runs would only duplicate the ones the
		// original word already contributed — while quietly re-adding a bare number
		// to a group that model_words() deliberately narrowed to the whole code,
		// which is enough to let a different model satisfy the requirement.
		return array_values(
			array_filter(
				array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( $raw, '', 1 ) ) ),
				static function ( $variant ) use ( $term ) {
					return '' !== $variant && $variant !== $term;
				}
			)
		);
	}

	/**
	 * Transliterate Cyrillic to Latin (phonetic, GOST-ish digraphs).
	 *
	 * @since 1.2.0
	 * @param string $term Cyrillic term.
	 * @return string
	 */
	private static function cyr_to_lat( string $term ): string {
		static $map = array(
			'а' => 'a',
			'б' => 'b',
			'в' => 'v',
			'г' => 'g',
			'д' => 'd',
			'е' => 'e',
			'ж' => 'zh',
			'з' => 'z',
			'и' => 'i',
			'й' => 'y',
			'к' => 'k',
			'л' => 'l',
			'м' => 'm',
			'н' => 'n',
			'о' => 'o',
			'п' => 'p',
			'р' => 'r',
			'с' => 's',
			'т' => 't',
			'у' => 'u',
			'ф' => 'f',
			'х' => 'kh',
			'ц' => 'ts',
			'ч' => 'ch',
			'ш' => 'sh',
			'щ' => 'shch',
			'ъ' => '',
			'ы' => 'y',
			'ь' => '',
			'э' => 'e',
			'ю' => 'yu',
			'я' => 'ya',
		);

		return strtr( $term, $map );
	}

	/**
	 * Transliterate Latin to Cyrillic (phonetic). strtr() replaces the longest key
	 * first, so digraphs (sh, ch, …) win over their single letters.
	 *
	 * @since 1.2.0
	 * @param string $term Latin term.
	 * @return string
	 */
	private static function lat_to_cyr( string $term ): string {
		static $map = array(
			'shch' => 'щ',
			'sch'  => 'щ',
			'sh'   => 'ш',
			'ch'   => 'ч',
			'zh'   => 'ж',
			'kh'   => 'х',
			'ts'   => 'ц',
			'yu'   => 'ю',
			'ya'   => 'я',
			'yo'   => 'е',
			'a'    => 'а',
			'b'    => 'б',
			'c'    => 'к',
			'd'    => 'д',
			'e'    => 'е',
			'f'    => 'ф',
			'g'    => 'г',
			'h'    => 'х',
			'i'    => 'и',
			'j'    => 'дж',
			'k'    => 'к',
			'l'    => 'л',
			'm'    => 'м',
			'n'    => 'н',
			'o'    => 'о',
			'p'    => 'п',
			'q'    => 'к',
			'r'    => 'р',
			's'    => 'с',
			't'    => 'т',
			'u'    => 'у',
			'v'    => 'в',
			'w'    => 'в',
			'x'    => 'кс',
			'y'    => 'й',
			'z'    => 'з',
		);

		return strtr( $term, $map );
	}

	/**
	 * Stem of the last, still-being-typed word of a query (for prefix synonyms).
	 *
	 * @since 1.2.0
	 * @param string $clean_query Query with negations removed.
	 * @return string Stem of the trailing word, or '' when too short/absent.
	 */
	private static function trailing_stem( string $clean_query ): string {
		$words = preg_split( '/\s+/u', trim( $clean_query ) );

		if ( empty( $words ) ) {
			return '';
		}

		$stems = array_keys( MVweb_SS_Tokenizer::tokenize( (string) end( $words ) ) );

		if ( empty( $stems ) ) {
			return '';
		}

		$last = (string) end( $stems );

		return mb_strlen( $last, 'UTF-8' ) >= 3 ? $last : '';
	}

	/**
	 * Prepend admin-pinned, still-public results to the top.
	 *
	 * @since 1.0.0
	 * @param int[]    $pin_ids  Pinned object IDs (in order).
	 * @param string[] $types    Post types in scope for this search.
	 * @param array    $results  Ranked results.
	 * @param int      $limit    Max rows.
	 * @param int[]    $term_ids Active category term IDs, or empty.
	 * @param string   $taxonomy Taxonomy of the term IDs.
	 * @return array
	 */
	private static function apply_pins( array $pin_ids, array $types, array $results, int $limit, array $term_ids = array(), string $taxonomy = '' ): array {
		$exclude = MVweb_SS_Settings::excluded_ids();
		$scoped  = ! empty( $term_ids ) && '' !== $taxonomy;
		$pinned  = array();

		foreach ( $pin_ids as $id ) {
			if ( in_array( (int) $id, $exclude, true ) ) {
				continue;
			}

			if ( $scoped && ! has_term( $term_ids, $taxonomy, (int) $id ) ) {
				continue;
			}

			$post = get_post( $id );

			if ( $post instanceof WP_Post
				&& 'publish' === $post->post_status
				&& '' === (string) $post->post_password
				&& in_array( $post->post_type, $types, true ) ) {
				$pinned[] = array(
					'object_id'   => (int) $id,
					'object_type' => $post->post_type,
					'score'       => (float) PHP_INT_MAX,
				);
			}
		}

		if ( empty( $pinned ) ) {
			return $results;
		}

		$ids  = array_column( $pinned, 'object_id' );
		$rest = array_filter(
			$results,
			static function ( $row ) use ( $ids ) {
				return ! in_array( $row['object_id'], $ids, true );
			}
		);

		return array_slice( array_merge( $pinned, array_values( $rest ) ), 0, $limit );
	}

	/**
	 * Move results whose title or SKU is exactly the query to the very top.
	 *
	 * An exact title/SKU match always carries full coverage, so promoting it never
	 * lifts a lower-coverage item above a higher-coverage one — it only settles
	 * ties in favour of the literal match the shopper almost certainly wants.
	 *
	 * @since 1.2.0
	 * @param string $query   Cleaned query.
	 * @param array  $results Ranked results.
	 * @return array
	 */
	private static function promote_exact( string $query, array $results ): array {
		$boost = (float) MVweb_SS_Settings::get( 'exact_match_boost', 5.0 );

		if ( $boost <= 1 || empty( $results ) ) {
			return $results;
		}

		$key = self::normalize_exact( $query );

		if ( '' === $key ) {
			return $results;
		}

		// Scan only the head slice: is_exact_match() reads a title and a SKU per row,
		// so an unbounded scan would multiply reads on a large results-page pool. An
		// exact title/SKU match carries full coverage and always ranks inside the
		// head, so nothing real is lost.
		$scan = min( count( $results ), self::REFINE_SCAN_CAP );

		$head = array();

		foreach ( array_slice( $results, 0, $scan ) as $row ) {
			$head[] = (int) $row['object_id'];
		}

		// Two queries for the whole head instead of a product object per row, and
		// usually one: type_filter() has normally warmed the post cache already, so
		// only the meta is left to fetch.
		_prime_post_caches( $head, false, true );

		$exact = array();
		$rest  = array();

		foreach ( $results as $i => $row ) {
			if ( $i < $scan && self::is_exact_match( (int) $row['object_id'], (string) $row['object_type'], $key ) ) {
				$exact[] = $row;
			} else {
				$rest[] = $row;
			}
		}

		return empty( $exact ) ? $results : array_merge( $exact, $rest );
	}

	/**
	 * Whether an object's title or (product) SKU equals the normalized query.
	 *
	 * @since 1.2.0
	 * @param int    $object_id   Object ID.
	 * @param string $object_type Indexed object type.
	 * @param string $key         Normalized query.
	 * @return bool
	 */
	private static function is_exact_match( int $object_id, string $object_type, string $key ): bool {
		// Compared against the very string the index was built from. get_the_title()
		// runs the title through wptexturize/convert_chars, which in a Russian locale
		// turns quotes and dashes into HTML entities; normalization then keeps the
		// digits out of those entities, so such a title could never match exactly.
		if ( self::normalize_exact( (string) get_post_field( 'post_title', $object_id, 'raw' ) ) === $key ) {
			return true;
		}

		// The SKU is read from the very meta WooCommerce's own data store reads it
		// from. A variation is the exception: an empty SKU there is inherited from
		// the parent, and only the product object knows that.
		if ( 'product' === $object_type ) {
			$sku = (string) get_post_meta( $object_id, '_sku', true );

			return '' !== $sku && self::normalize_exact( $sku ) === $key;
		}

		if ( 'product_variation' === $object_type && function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $object_id );
			$sku     = $product ? (string) $product->get_sku() : '';

			return '' !== $sku && self::normalize_exact( $sku ) === $key;
		}

		return false;
	}

	/**
	 * Normalize a string for exact comparison: lowercase, ё→е, alphanumerics only,
	 * single-spaced.
	 *
	 * @since 1.2.0
	 * @param string $text Input.
	 * @return string
	 */
	private static function normalize_exact( string $text ): string {
		$text = str_replace( 'ё', 'е', mb_strtolower( trim( $text ), 'UTF-8' ) );
		$text = (string) preg_replace( '/[^\p{L}\p{N}]+/u', ' ', $text );

		return trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
	}

	/**
	 * Split a raw query into its positive text and negated stems.
	 *
	 * A whitespace-delimited word starting with "-" ("iphone -чехол") is a
	 * Boolean NOT: the word is removed from the searchable text and its stems
	 * are returned so the ranking query can exclude any object carrying them.
	 * A "-" inside a word ("телефон-раскладушка") is a compound, not a negation.
	 *
	 * @since 1.1.0
	 * @param string $query Raw user query.
	 * @return array{0:string,1:string[]} Cleaned query, then negated stems.
	 */
	public static function split_negatives( string $query ): array {
		$neg_words = array();

		$clean = (string) preg_replace_callback(
			'/(?:^|\s)-(\S+)/u',
			static function ( $m ) use ( &$neg_words ) {
				$neg_words[] = $m[1];
				return ' ';
			},
			$query
		);

		$neg_terms = array();

		foreach ( $neg_words as $word ) {
			foreach ( array_keys( MVweb_SS_Tokenizer::tokenize( $word ) ) as $stem ) {
				$neg_terms[] = (string) $stem;
			}
		}

		return array( trim( $clean ), array_values( array_unique( $neg_terms ) ) );
	}

	/**
	 * Re-map a query typed in the wrong keyboard layout to the other one.
	 *
	 * Swaps characters between the Russian ЙЦУКЕН and the English QWERTY layouts
	 * by physical key, so "ghbdtn" becomes "привет" (and the reverse). Returns an
	 * empty string when nothing changed, letting the caller skip a pointless
	 * re-search. The slash and backtick keys are left out (their letters ./ё
	 * collide or are stemmer-normalized), so the map stays unambiguous.
	 *
	 * @since 1.1.0
	 * @param string $query Raw user query.
	 * @return string Swapped query, or '' when unchanged.
	 */
	private static function swap_layout( string $query ): string {
		$lower = mb_strtolower( trim( $query ), 'UTF-8' );

		if ( '' === $lower ) {
			return '';
		}

		$swapped = strtr( $lower, self::layout_map() );

		return $swapped === $lower ? '' : $swapped;
	}

	/**
	 * Bidirectional QWERTY↔ЙЦУКЕН character map keyed by physical key.
	 *
	 * @since 1.1.0
	 * @return array<string,string>
	 */
	private static function layout_map(): array {
		static $map = null;

		if ( null !== $map ) {
			return $map;
		}

		$en = str_split( 'qwertyuiop[]asdfghjkl;\'zxcvbnm,.' );
		$ru = mb_str_split( 'йцукенгшщзхъфывапролджэячсмитьбю', 1, 'UTF-8' );

		$map = array();

		foreach ( $en as $i => $ch ) {
			$map[ $ch ]       = $ru[ $i ];
			$map[ $ru[ $i ] ] = $ch;
		}

		return $map;
	}

	/**
	 * Build a human-readable "did you mean" phrase from the top fuzzy match.
	 *
	 * Uses real words from the best result's title (not stemmed index terms),
	 * replacing each raw query word with the closest title word within edit
	 * distance 2. Returns an empty string when nothing changed.
	 *
	 * @since 1.0.0
	 * @param string $query   Raw user query.
	 * @param array  $results Fuzzy result set (best first).
	 * @return string
	 */
	private static function derive_correction( string $query, array $results ): string {
		if ( empty( $results ) ) {
			return '';
		}

		$raw_words = preg_split( '/\s+/u', trim( $query ), -1, PREG_SPLIT_NO_EMPTY );

		if ( empty( $raw_words ) ) {
			return '';
		}

		$title       = wp_strip_all_tags( (string) get_the_title( (int) $results[0]['object_id'] ) );
		$title_words = preg_split( '/\s+/u', $title, -1, PREG_SPLIT_NO_EMPTY );

		if ( empty( $title_words ) ) {
			return '';
		}

		$out = array();

		foreach ( (array) $raw_words as $word ) {
			$word_lc = mb_strtolower( (string) $word, 'UTF-8' );
			$len     = mb_strlen( $word_lc, 'UTF-8' );
			$best    = (string) $word;
			$best_d  = PHP_INT_MAX;

			foreach ( (array) $title_words as $candidate ) {
				$candidate = (string) $candidate;

				if ( abs( mb_strlen( $candidate, 'UTF-8' ) - $len ) > 2 ) {
					continue;
				}

				$distance = MVweb_SS_Fuzzy::distance( $word_lc, mb_strtolower( $candidate, 'UTF-8' ) );

				if ( $distance < $best_d ) {
					$best_d = $distance;
					$best   = $candidate;
				}
			}

			$out[] = ( $best_d > 0 && $best_d <= 2 ) ? $best : (string) $word;
		}

		$corrected = implode( ' ', $out );
		$original  = (string) preg_replace( '/\s+/u', ' ', trim( $query ) );

		return mb_strtolower( $corrected, 'UTF-8' ) === mb_strtolower( $original, 'UTF-8' ) ? '' : $corrected;
	}

	/**
	 * Run the ranking query for a set of coverage groups.
	 *
	 * Each group is one covered concept (a word plus its synonyms/transliterations/
	 * fuzzy variants); coverage counts distinct groups, not raw terms, so a word and
	 * its synonym never double-count (P0.2). When enabled, each term's contribution
	 * is scaled by its inverse document frequency, so a common word pulls far less
	 * weight than a rare, discriminating one (P0.1).
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups    Non-empty coverage groups.
	 * @param string[]            $types     Post types to search.
	 * @param int                 $min_match Minimum number of distinct groups an object must match (1 = OR, N = AND).
	 * @param int                 $limit     Max rows.
	 * @param int[]               $term_ids  Restrict to objects in these taxonomy term IDs.
	 * @param string              $taxonomy  Taxonomy the term IDs belong to (required with $term_ids).
	 * @param string[]            $exclude_terms Stems whose presence disqualifies an object (Boolean NOT).
	 * @param string              $query_hash    Raw-query hash for the self-learning click-boost ('' = off).
	 * @param int[]               $required      Group indexes an object must match on top of the floor.
	 * @return array<int,array{object_id:int,object_type:string,score:float}>
	 */
	private static function run( array $groups, array $types, int $min_match, int $limit, array $term_ids = array(), string $taxonomy = '', array $exclude_terms = array(), string $query_hash = '', array $required = array() ): array {
		global $wpdb;

		$terms = self::flatten_groups( $groups );

		if ( empty( $terms ) || empty( $types ) ) {
			return array();
		}

		$pml_joined = false;

		$table = MVweb_SS_Schema::table_name();

		$coverage        = self::coverage_case_sql( $groups );
		$coverage_source = self::coverage_source_sql();

		// Field-length normalization (P1.2, default-off): divide each match's
		// contribution by a BM25 fieldnorm so a term buried in a long field (a
		// smartphone's spec description) counts far less than the same term as a
		// short part title. Chosen before the IDF wrap so IDF multiplies the
		// normalized base; the doclen JOIN is appended after, so it composes with
		// the IDF join instead of overwriting it.
		$use_doclen = (bool) MVweb_SS_Settings::get( 'ranking_doclen', true );

		$use_idf   = (bool) MVweb_SS_Settings::get( 'ranking_use_idf', true );
		$idf_join  = '';
		$score_sum = $use_doclen ? self::weight_case_doclen() : self::weight_case();

		if ( $use_idf ) {
			$terms_table = MVweb_SS_Schema::terms_table_name();
			$n           = self::doc_count();
			$idf_join    = "LEFT JOIN `$terms_table` t ON t.term = i.term";
			$idf         = "LN( 1 + ( $n - LEAST( COALESCE( t.df, 0 ), $n ) + 0.5 ) / ( COALESCE( t.df, 0 ) + 0.5 ) )";
			$score_sum   = '( ' . $idf . ' ) * ( ' . $score_sum . ' )';
		}

		if ( $use_doclen ) {
			$doclen_table = MVweb_SS_Schema::doclen_table_name();
			$idf_join    .= " LEFT JOIN `$doclen_table` dl ON dl.object_id = i.object_id AND dl.source = i.source";
		}

		$in_terms = implode( ',', array_fill( 0, count( $terms ), '%s' ) );
		$in_types = implode( ',', array_fill( 0, count( $types ), '%s' ) );

		$tax_sql   = '';
		$tax_valid = ! empty( $term_ids ) && '' !== $taxonomy;

		if ( $tax_valid ) {
			$in_tids = implode( ',', array_fill( 0, count( $term_ids ), '%d' ) );
			$tax_sql = "AND i.object_id IN (
				SELECT tr.object_id FROM {$wpdb->term_relationships} tr
				INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
				WHERE tt.taxonomy = %s AND tt.term_id IN ($in_tids)
			)";
		}

		$stock        = self::stock_mode();
		$stock_active = ( 'show' !== $stock ) && class_exists( 'WooCommerce' );

		$stock_select = '';
		$having_parts = array();

		if ( $min_match > 1 ) {
			$having_parts[] = 'matched >= %d';
		}

		// Required groups: concepts the floor is not allowed to trade away (the
		// model number). Each becomes its own aggregate flag next to the coverage
		// count, so HAVING can demand it outright rather than hoping the ranking
		// floats it up. Terms are bound; group indexes are trusted integers.
		//
		// The same demand is also stated in WHERE as a semi-join, because HAVING
		// only reads a figure the aggregation has already paid for: without it the
		// query scores every object sharing any word with the query and throws the
		// result away. A model number is the narrowest thing a shopper types, so
		// filtering on it first is what makes the pass cheap. Measured on a 12 460
		// product catalogue: "шлейф … samsung galaxy a52 …" scanned 9 021 objects
		// and took 671 ms, and 65 objects and 111 ms with the semi-join.
		$required_select = '';
		$required_sql    = '';
		$required_terms  = array();
		$semi_terms      = array();

		foreach ( $required as $gi ) {
			$gi = (int) $gi;

			if ( ! isset( $groups[ $gi ] ) || empty( $groups[ $gi ] ) ) {
				continue;
			}

			$in_req           = implode( ',', array_fill( 0, count( $groups[ $gi ] ), '%s' ) );
			$required_select .= ", MAX( CASE WHEN i.term IN ($in_req)$coverage_source THEN 1 ELSE 0 END ) AS req_$gi";
			$having_parts[]   = "req_$gi = 1";
			$required_terms   = array_merge( $required_terms, array_values( $groups[ $gi ] ) );
			$required_sql    .= " AND i.object_id IN ( SELECT object_id FROM `$table` WHERE term IN ($in_req)"
				. str_replace( 'i.source', 'source', $coverage_source ) . ' )';
			$semi_terms       = array_merge( $semi_terms, array_values( $groups[ $gi ] ) );
		}

		// Stock comes from WooCommerce's own lookup table, which carries the same
		// value the meta does but on a primary key. Joining wp_postmeta for it costs
		// a scan of ~17 meta rows per candidate (the post_id index carries no
		// meta_key), and the alias is read exactly once. The join is made here rather
		// than borrowed from the bestseller and tie-break blocks below: those are
		// conditional, and a reference to someone else's alias would one day leave
		// the query without the column.
		if ( $stock_active ) {
			if ( ! $pml_joined ) {
				$lookup     = $wpdb->prefix . 'wc_product_meta_lookup';
				$idf_join  .= " LEFT JOIN `$lookup` pml ON pml.product_id = i.object_id";
				$pml_joined = true;
			}

			$stock_select = ', MAX( CASE WHEN pml.stock_status = \'outofstock\' THEN 1 ELSE 0 END ) AS out_of_stock';

			if ( 'hide' === $stock ) {
				$having_parts[] = 'out_of_stock = 0';
			}
		}

		$having = empty( $having_parts ) ? '' : 'HAVING ' . implode( ' AND ', $having_parts );

		$exclude  = MVweb_SS_Settings::excluded_ids();
		$excl_sql = '';

		if ( ! empty( $exclude ) ) {
			$in_excl  = implode( ',', array_fill( 0, count( $exclude ), '%d' ) );
			$excl_sql = "AND i.object_id NOT IN ($in_excl)";
		}

		$neg_sql = '';

		if ( ! empty( $exclude_terms ) ) {
			$in_neg  = implode( ',', array_fill( 0, count( $exclude_terms ), '%s' ) );
			$neg_sql = "AND i.object_id NOT IN ( SELECT object_id FROM `$table` WHERE term IN ($in_neg) )";
		}

		// Self-learning click-boost: multiply the score by a log-damped, capped
		// factor of how often this result was clicked for this exact query. The
		// factor is 1.0 with no clicks, so it never crosses the coverage tier and
		// never reorders cold-start catalogs.
		// Ranking multipliers are applied in ORDER BY as raw expressions, never via
		// the SUM() alias: MySQL rejects an aggregate alias (`score`) used inside any
		// ORDER BY arithmetic, but raw aggregate functions (SUM, MAX) are allowed
		// there. So the ORDER BY repeats the score expression and multiplies the
		// capped click/bestseller factors onto it directly.
		// The join is skipped when this query has never been clicked, which on a
		// young catalogue is nearly every query: with no row to find, the factor is
		// LEAST( alpha * LN( 1 ), cap ) = 0 and the multiplier is exactly 1.0, so
		// the outcome is identical either way — but the join still costs a lookup
		// per candidate row. Measured on a 12 460 product catalogue: 572 ms with
		// the join against 455 ms without, on a clicks table holding seven rows.
		// The probe reads the primary key's leading column, so it is free.
		$boost_join = '';
		$order_expr = 'SUM( ' . $score_sum . ' )';

		if ( '' !== $query_hash ) {
			$clicks_table = MVweb_SS_Schema::clicks_table_name();

			// One search runs this method up to four times (the descent, the two
			// rescues, the zero ladder) and the dropdown runs the search once per
			// post type, all under the one hash the shopper's query
			// produced. Nothing writes to the clicks table while a search is running
			// — that happens in the click endpoint — so the answer holds for the
			// request.
			static $probe = array();

			if ( ! isset( $probe[ $query_hash ] ) ) {
				$probe[ $query_hash ] = (bool) $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM `$clicks_table` WHERE query_hash = %s LIMIT 1", $query_hash ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
			}

			if ( $probe[ $query_hash ] ) {
				$strength = (int) MVweb_SS_Settings::get( 'click_boost_strength', 30 );
				$alpha    = number_format( max( 0, min( 100, $strength ) ) / 100, 3, '.', '' );
				$cap      = '2.0';

				$boost_join  = "LEFT JOIN `$clicks_table` cb ON cb.object_id = i.object_id AND cb.query_hash = %s";
				$order_expr .= " * ( 1 + LEAST( $alpha * LN( 1 + MAX( COALESCE( cb.clicks, 0 ) ) ), $cap ) )";
			} else {
				$query_hash = '';
			}
		}

		// Bestseller signal: a log-damped, capped multiplier on total_sales pulled
		// straight from wc_product_meta_lookup (no aggregation). A cold product
		// scores ×1, so this stays strictly below the coverage tier and never
		// reshuffles a catalog with no sales history. Non-products have no lookup
		// row, so their factor is ×1 too. All literals inline — no placeholders.
		$pop_strength = (int) MVweb_SS_Settings::get( 'boost_popularity', 20 );

		if ( $pop_strength > 0 && class_exists( 'WooCommerce' ) ) {
			$beta    = number_format( max( 0, min( 100, $pop_strength ) ) / 100, 3, '.', '' );
			$pop_cap = '1.0';

			if ( ! $pml_joined ) {
				$lookup     = $wpdb->prefix . 'wc_product_meta_lookup';
				$idf_join  .= " LEFT JOIN `$lookup` pml ON pml.product_id = i.object_id";
				$pml_joined = true;
			}

			$order_expr .= " * ( 1 + LEAST( $beta * LN( 1 + MAX( COALESCE( pml.total_sales, 0 ) ) ), $pop_cap ) )";
		}

		// Sort on the relevance figure rounded to six decimals, not the raw sum. The
		// score is a SUM() of floating-point IDF terms, and floating-point addition is
		// not associative: the same object summed in a different row order comes out
		// different in the last bits (measured spread: 9e-16 on scores around 60). That
		// noise is invisible to a reader but decides the ORDER BY, so two products with
		// an equal score could swap places — and swap in or out of the LIMIT window —
		// whenever the query plan or the row order changed. Rounding well below any
		// meaningful score difference makes the tie-break tail below (sales, rating,
		// object_id) the thing that actually decides ties, which is what it is for.
		$boost_order = 'ROUND( ' . $order_expr . ', 6 ) DESC';

		// Deterministic tie-break tail (P1.6): when two rows share the same coverage
		// and the same boosted relevance, order them by a stable cascade — sales,
		// then rating — so one query always yields one ordering (matters for QA and
		// support). Products only; raw aggregates are allowed in ORDER BY. The final
		// i.object_id DESC stays the always-unique key.
		$tie_break = '';

		if ( class_exists( 'WooCommerce' ) ) {
			if ( ! $pml_joined ) {
				$lookup     = $wpdb->prefix . 'wc_product_meta_lookup';
				$idf_join  .= " LEFT JOIN `$lookup` pml ON pml.product_id = i.object_id";
				$pml_joined = true;
			}

			$tie_break = ', MAX( COALESCE( pml.total_sales, 0 ) ) DESC, MAX( COALESCE( pml.average_rating, 0 ) ) DESC';
		}

		// The publish/visibility filter is a join, not an `object_id IN (SELECT ...)`
		// subquery: MySQL 5.7 materializes such a subquery and then picks wp_posts as
		// the driving table, scanning the whole posts table on every keystroke. Joining
		// on the primary key cannot duplicate rows (ID is unique), so the result is
		// identical — but STRAIGHT_JOIN is still required to get the good plan, because
		// the optimizer picks the same posts-first order for a plain join. With it the
		// index table leads through the term key and each post is fetched by primary
		// key. Measured on a 13k-product catalog: ~590 ms before, ~155 ms after, same
		// rows. Every other join here is a LEFT JOIN hanging off `i`, so pinning the
		// order costs nothing. STRAIGHT_JOIN rather than FORCE INDEX on purpose: a
		// forced index name that a site's table happens to lack is a fatal SQL error,
		// while this is plain syntax.
		$sql = 'SELECT STRAIGHT_JOIN i.object_id, i.object_type, SUM( ' . $score_sum . " ) AS score, $coverage AS matched{$required_select}{$stock_select}
			FROM `$table` i
			INNER JOIN {$wpdb->posts} p ON p.ID = i.object_id
			$idf_join
			$boost_join
			WHERE i.term IN ($in_terms)
				AND p.post_status = 'publish' AND p.post_password = '' AND p.post_type IN ($in_types)
				$excl_sql
				$neg_sql
				$required_sql
				$tax_sql
			GROUP BY i.object_id, i.object_type
			$having
			ORDER BY matched DESC, {$boost_order}{$tie_break}, i.object_id DESC
			LIMIT %d";

		// Placeholder order mirrors the SQL string top-to-bottom: the coverage CASE
		// (SELECT) lists every term first, then each required group's term list,
		// then the click-boost JOIN hash, then the WHERE term/type lists and the
		// remaining filters.
		$values = $terms;

		if ( ! empty( $required_terms ) ) {
			$values = array_merge( $values, $required_terms );
		}

		if ( '' !== $query_hash ) {
			$values[] = $query_hash;
		}

		$values = array_merge( $values, $terms, $types );

		if ( ! empty( $exclude ) ) {
			$values = array_merge( $values, $exclude );
		}

		if ( ! empty( $exclude_terms ) ) {
			$values = array_merge( $values, $exclude_terms );
		}

		if ( ! empty( $semi_terms ) ) {
			$values = array_merge( $values, $semi_terms );
		}

		if ( $tax_valid ) {
			$values[] = $taxonomy;
			$values   = array_merge( $values, $term_ids );
		}

		if ( $min_match > 1 ) {
			$values[] = min( $min_match, count( $groups ) );
		}

		$values[] = $limit;

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( ! is_array( $rows ) ) {
			return array();
		}

		$results = array_map(
			static function ( $row ) {
				return array(
					'object_id'    => (int) $row->object_id,
					'object_type'  => (string) $row->object_type,
					'score'        => (float) $row->score,
					'matched'      => isset( $row->matched ) ? (int) $row->matched : 0,
					// Carried out of the query so the PHP passes can keep the
					// order it decided: the column is selected only in the
					// "demote" and "hide" stock modes, and is 0 otherwise.
					'out_of_stock' => isset( $row->out_of_stock ) ? (int) $row->out_of_stock : 0,
				);
			},
			$rows
		);

		// Sold-out demotion is applied here, not as the leading ORDER BY key it
		// used to be. Sorting on it in SQL decides which rows survive the LIMIT
		// before relevance is consulted, so a catalogue with plenty of stocked
		// partial matches could fill the whole window with them and drop the exact
		// match the shopper typed simply because it was sold out. Ranking first and
		// demoting after keeps the window relevant, leaves the delivered order
		// unchanged, and — because coverage now leads the SQL sort — lets one pass
		// stand in for the whole coverage descent (see adaptive_run()).
		if ( 'demote' === $stock && $stock_active ) {
			usort(
				$results,
				static function ( $a, $b ) {
					return self::stock_flag( $a ) <=> self::stock_flag( $b );
				}
			);
		}

		return $results;
	}

	/**
	 * Convenience: return only the ordered object IDs.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @param array  $args  See search().
	 * @return int[]
	 */
	public static function search_ids( string $query, array $args = array() ): array {
		return array_map(
			static function ( $result ) {
				return $result['object_id'];
			},
			self::search( $query, $args )
		);
	}

	/**
	 * Count matching objects per taxonomy term for the dropdown category groups.
	 *
	 * Instead of matching term names, this counts how many objects that actually
	 * satisfy the query (same strictness floor, synonyms and Boolean NOT as the
	 * result list) fall into each term. A term the query does not reach never
	 * appears, and its number is the matching count — not the term's total size.
	 * The floor is the one the result list uses, so the badge and the page agree;
	 * how much of the query a term's best product covers only orders the list.
	 * The results-page facets count their own pool instead — see
	 * term_counts_for_ids().
	 *
	 * @since 1.1.2
	 * @param string   $query      Raw user query.
	 * @param string[] $taxonomies Taxonomies to aggregate over.
	 * @param int      $limit      Max terms, ordered by matching count.
	 * @return array<int,array{term_id:int,taxonomy:string,count:int}>
	 */
	public static function term_match_counts( string $query, array $taxonomies, int $limit ): array {
		global $wpdb;

		$taxonomies = array_values( array_unique( array_filter( array_map( 'strval', $taxonomies ) ) ) );

		if ( empty( $taxonomies ) || $limit < 1 ) {
			return array();
		}

		list( $clean_query, $neg_terms ) = self::split_negatives( $query );

		$words = MVweb_SS_Tokenizer::tokenize_words( $clean_query, '', self::query_parts_budget() );

		if ( empty( $words ) ) {
			return array();
		}

		// Same model discipline as the result list, or the badge would promise a
		// category the click cannot deliver.
		list( $words, $required_terms ) = self::model_words( $words, true );

		// The same trailing-word prefix the result list expands on: a synonym rule
		// that fires while the word is still being typed ("чех" → чехол/бампер/
		// кейс) widens the results, and a count taken without it would promise far
		// less than a click delivers — most of a live search happens mid-word.
		$partial = MVweb_SS_Settings::get( 'synonym_prefix', true ) ? self::trailing_stem( $clean_query ) : '';

		$strictness   = (string) MVweb_SS_Settings::get( 'strictness', 'balanced' );
		$min_match    = self::min_match( $strictness, MVweb_SS_Tokenizer::word_count( $clean_query ) );
		$groups       = self::expand_groups( $words, $partial, (bool) MVweb_SS_Settings::get( 'translit_cross_script', true ) );
		$search_terms = self::flatten_groups( $groups );
		$need         = (int) min( $min_match, count( $groups ) );

		$table   = MVweb_SS_Schema::table_name();
		$exclude = MVweb_SS_Settings::excluded_ids();

		$in_terms = implode( ',', array_fill( 0, count( $search_terms ), '%s' ) );
		$in_taxes = implode( ',', array_fill( 0, count( $taxonomies ), '%s' ) );

		$excl_sql = '';
		if ( ! empty( $exclude ) ) {
			$in_excl  = implode( ',', array_fill( 0, count( $exclude ), '%d' ) );
			$excl_sql = "AND i.object_id NOT IN ($in_excl)";
		}

		$neg_sql = '';
		if ( ! empty( $neg_terms ) ) {
			$in_neg  = implode( ',', array_fill( 0, count( $neg_terms ), '%s' ) );
			$neg_sql = "AND i.object_id NOT IN ( SELECT object_id FROM `$table` WHERE term IN ($in_neg) )";
		}

		// The badge follows the same stock rule as the result list: out-of-stock
		// products are dropped only when the store hides them ('hide' mode), so the
		// number matches what a click into the category actually shows. Source is the
		// same WooCommerce lookup table the result list reads, or the two would
		// disagree. Non-products hold no row there, so the filter only trims WC
		// products.
		$stock_sql = '';
		if ( class_exists( 'WooCommerce' ) && 'hide' === self::stock_mode() ) {
			$stock_sql = "AND i.object_id NOT IN (
				SELECT product_id FROM {$wpdb->prefix}wc_product_meta_lookup
				WHERE stock_status = 'outofstock'
			)";
		}

		// Match strength orders the badges, it does not filter them. The floor stays
		// the one the result list uses, so the number under a category is the number
		// a click on it opens; the category whose best product covers the most query
		// concepts still comes first. A query like "iphone 12 pro battery" therefore
		// leads with the battery category, while the phone cases that only match the
		// model words stay in the list — with an honest count — instead of vanishing.
		$multi     = count( $groups ) > 1;
		$cov_case  = $multi ? self::coverage_case_sql( $groups ) : '';
		$cov_col   = $multi ? ', ' . $cov_case . ' AS cov' : '';
		$cov_order = $multi ? 'MAX( m.cov ) DESC, ' : '';

		$required        = self::required_groups( $groups, $required_terms );
		$coverage_source = self::coverage_source_sql();
		$req_col         = '';
		$req_having      = array();
		$req_values      = array();

		foreach ( $required as $gi ) {
			$gi = (int) $gi;

			if ( ! isset( $groups[ $gi ] ) || empty( $groups[ $gi ] ) ) {
				continue;
			}

			$in_req       = implode( ',', array_fill( 0, count( $groups[ $gi ] ), '%s' ) );
			$req_col     .= ", MAX( CASE WHEN i.term IN ($in_req)$coverage_source THEN 1 ELSE 0 END ) AS req_$gi";
			$req_having[] = "req_$gi = 1";
			$req_values   = array_merge( $req_values, array_values( $groups[ $gi ] ) );
		}

		$having_parts = array();

		if ( $need > 1 ) {
			$having_parts[] = $cov_case . ' >= %d';
		}

		$having_parts = array_merge( $having_parts, $req_having );
		$having       = empty( $having_parts ) ? '' : 'HAVING ' . implode( ' AND ', $having_parts );

		$type_gate  = (bool) MVweb_SS_Settings::get( 'type_filter', true );
		$sample_col = '';
		$sql_limit  = $limit;

		if ( $type_gate ) {
			$sample_order = $multi ? ' ORDER BY m.cov DESC' : '';
			$sample_col   = ", SUBSTRING_INDEX( GROUP_CONCAT( m.object_id$sample_order ), ',', " . (int) self::TYPE_SAMPLE . ' ) AS sample';
			$sql_limit    = max( $limit, min( (int) self::TYPE_TERM_MAX, $limit * (int) self::TYPE_TERM_OVERSCAN ) );
		}

		$sql = "SELECT tt.term_id AS term_id, tt.taxonomy AS taxonomy, COUNT( DISTINCT m.object_id ) AS cnt$sample_col
			FROM {$wpdb->term_taxonomy} tt
			INNER JOIN {$wpdb->term_relationships} tr ON tr.term_taxonomy_id = tt.term_taxonomy_id
			INNER JOIN (
				SELECT STRAIGHT_JOIN i.object_id$cov_col$req_col
				FROM `$table` i
				INNER JOIN {$wpdb->posts} p ON p.ID = i.object_id
				WHERE i.term IN ($in_terms)
					AND p.post_status = 'publish' AND p.post_password = ''
					$excl_sql
					$neg_sql
					$stock_sql
				GROUP BY i.object_id
				$having
			) m ON m.object_id = tr.object_id
			WHERE tt.taxonomy IN ($in_taxes)
			GROUP BY tt.term_id, tt.taxonomy
			ORDER BY {$cov_order}cnt DESC, tt.term_id ASC
			LIMIT %d";

		// Placeholders in statement order: the coverage CASE in SELECT, each required
		// group's term list, the term list in WHERE, then the exclusions, then the
		// HAVING CASE and its floor.
		$values = $multi ? array_merge( $search_terms, $req_values, $search_terms ) : array_merge( $req_values, $search_terms );

		if ( ! empty( $exclude ) ) {
			$values = array_merge( $values, $exclude );
		}

		if ( ! empty( $neg_terms ) ) {
			$values = array_merge( $values, $neg_terms );
		}

		if ( $need > 1 ) {
			// The HAVING coverage CASE lists every term again, then the floor value.
			$values   = array_merge( $values, $search_terms );
			$values[] = $need;
		}

		$values   = array_merge( $values, $taxonomies );
		$values[] = $sql_limit;

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( ! is_array( $rows ) ) {
			return array();
		}

		if ( $type_gate ) {
			$rows = array_slice( self::type_filter_terms( $groups, $rows ), 0, $limit );
		}

		return array_map(
			static function ( $row ) {
				return array(
					'term_id'  => (int) $row->term_id,
					'taxonomy' => (string) $row->taxonomy,
					'count'    => (int) $row->cnt,
				);
			},
			$rows
		);
	}

	/**
	 * Keep only the categories that hold the thing the shopper named.
	 *
	 * The result list already drops a flex cable from a search for a screen
	 * (type_filter()), but the category badges were counted straight from the
	 * strictness floor, so a query naming a part still offered every category the
	 * device words reach: "iPhone 13 pro lcd" led with back covers, cases and
	 * screen protectors above the two display categories. The number under each
	 * one stays what it was — it is the count a click opens — and only the
	 * categories that carry no product of the named type drop out.
	 *
	 * Falls back to the unfiltered list when nothing survives, for the same reason
	 * type_filter() does: a catalogue that writes "iPhone 14 дисплей" names the
	 * device first, and the rule does not apply to it.
	 *
	 * @since 1.6.11
	 * @param array<int,string[]> $groups Coverage groups behind the counts.
	 * @param object[]            $rows   Rows from term_match_counts().
	 * @return object[]
	 */
	private static function type_filter_terms( array $groups, array $rows ): array {
		if ( count( $rows ) < 2 ) {
			return $rows;
		}

		$stems = array_flip( self::flatten_groups( $groups ) );

		if ( empty( $stems ) ) {
			return $rows;
		}

		$ids = array();

		foreach ( $rows as $row ) {
			foreach ( self::term_sample_ids( $row ) as $id ) {
				$ids[] = $id;
			}
		}

		if ( empty( $ids ) ) {
			return $rows;
		}

		_prime_post_caches( array_values( array_unique( $ids ) ), false, false );

		$kept = array();

		foreach ( $rows as $row ) {
			foreach ( self::term_sample_ids( $row ) as $id ) {
				foreach ( self::title_type_stems( $id ) as $stem ) {
					if ( isset( $stems[ $stem ] ) ) {
						$kept[] = $row;
						continue 3;
					}
				}
			}
		}

		return empty( $kept ) ? $rows : $kept;
	}

	/**
	 * The sampled product IDs carried by a term row, as integers.
	 *
	 * @since 1.6.11
	 * @param object $row Row from term_match_counts().
	 * @return int[]
	 */
	private static function term_sample_ids( $row ): array {
		if ( ! isset( $row->sample ) || '' === (string) $row->sample ) {
			return array();
		}

		return array_values( array_filter( array_map( 'intval', explode( ',', (string) $row->sample ) ) ) );
	}

	/**
	 * Term counts over an existing result pool, most matches first.
	 *
	 * The results-page facets count what the page is actually showing instead of
	 * re-running the search: the pool has already passed the strictness floor, the
	 * post-type scope, the results ceiling, any fuzzy rescue and the multilingual
	 * filter, so the number next to a facet is the number ticking it leaves. A
	 * product in a child term also counts for its ancestors, because the facet
	 * filters with include_children.
	 *
	 * @since 1.5.5
	 * @param int[]    $object_ids Ranked pool of object IDs.
	 * @param string[] $taxonomies Taxonomies to aggregate over.
	 * @param int      $limit      Max terms, ordered by count.
	 * @return array<int,array{term_id:int,taxonomy:string,count:int}>
	 */
	public static function term_counts_for_ids( array $object_ids, array $taxonomies, int $limit ): array {
		global $wpdb;

		$object_ids = array_values( array_unique( array_filter( array_map( 'intval', $object_ids ) ) ) );
		$taxonomies = array_values( array_unique( array_filter( array_map( 'strval', $taxonomies ) ) ) );

		if ( empty( $object_ids ) || empty( $taxonomies ) || $limit < 1 ) {
			return array();
		}

		$in_ids   = implode( ',', array_fill( 0, count( $object_ids ), '%d' ) );
		$in_taxes = implode( ',', array_fill( 0, count( $taxonomies ), '%s' ) );

		$sql = "SELECT tt.term_id AS term_id, tt.taxonomy AS taxonomy, tr.object_id AS object_id
			FROM {$wpdb->term_relationships} tr
			INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
			WHERE tr.object_id IN ($in_ids) AND tt.taxonomy IN ($in_taxes)";

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $object_ids, $taxonomies ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( ! is_array( $rows ) ) {
			return array();
		}

		// Object sets per term, so a product counted for both a child and its parent
		// is counted once in each — never twice in the parent. Ancestors are looked
		// up once per term, not once per row: one category covers hundreds of rows.
		$sets      = array();
		$ancestors = array();

		foreach ( $rows as $row ) {
			$term_id  = (int) $row->term_id;
			$taxonomy = (string) $row->taxonomy;
			$object   = (int) $row->object_id;
			$key      = $taxonomy . '|' . $term_id;

			$sets[ $key ][ $object ] = true;

			if ( ! isset( $ancestors[ $key ] ) ) {
				$ancestors[ $key ] = array_map( 'intval', get_ancestors( $term_id, $taxonomy, 'taxonomy' ) );
			}

			foreach ( $ancestors[ $key ] as $ancestor ) {
				$sets[ $taxonomy . '|' . $ancestor ][ $object ] = true;
			}
		}

		$out = array();

		foreach ( $sets as $key => $objects ) {
			list( $taxonomy, $term_id ) = explode( '|', $key, 2 );

			$out[] = array(
				'term_id'  => (int) $term_id,
				'taxonomy' => (string) $taxonomy,
				'count'    => count( $objects ),
			);
		}

		usort(
			$out,
			static function ( $a, $b ) {
				return $a['count'] === $b['count']
					? $a['term_id'] <=> $b['term_id']
					: $b['count'] <=> $a['count'];
			}
		);

		return array_slice( $out, 0, $limit );
	}

	/**
	 * Lowest and highest product price across a set of object IDs, read from the
	 * WooCommerce lookup table. Used to hint the price facet's range (P2.1). Returns
	 * an empty array when WooCommerce is inactive or no priced product is present.
	 *
	 * @since 1.2.0
	 * @param int[] $ids Object IDs (the current ranked pool).
	 * @return array{min:float,max:float}|array{}
	 */
	public static function price_bounds( array $ids ): array {
		global $wpdb;

		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );

		if ( empty( $ids ) || ! class_exists( 'WooCommerce' ) ) {
			return array();
		}

		$lookup = $wpdb->prefix . 'wc_product_meta_lookup';
		$in     = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		$sql = "SELECT MIN( min_price ) AS lo, MAX( max_price ) AS hi
			FROM `$lookup`
			WHERE product_id IN ($in) AND min_price IS NOT NULL";

		$row = $wpdb->get_row( $wpdb->prepare( $sql, $ids ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( ! $row || null === $row->lo || null === $row->hi ) {
			return array();
		}

		return array(
			'min' => (float) $row->lo,
			'max' => (float) $row->hi,
		);
	}

	/**
	 * Keep only the object IDs whose product price range overlaps the given
	 * bounds, preserving the input (relevance) order. Reads min_price/max_price
	 * from the WooCommerce lookup table, matching the same overlap rule the
	 * in-query price-intent filter uses (max_price >= min AND min_price <= max),
	 * so the price facet and the "до N" query filter agree — including on variable
	 * products, whose range the lookup captures but a single `_price` meta does not.
	 *
	 * @since 1.2.0
	 * @param int[]      $ids Object IDs (ranked order).
	 * @param float|null $min Lower bound, or null.
	 * @param float|null $max Upper bound, or null.
	 * @return int[] Filtered IDs in the original order (unchanged when no bound/WooCommerce).
	 */
	public static function filter_ids_by_price( array $ids, ?float $min, ?float $max ): array {
		global $wpdb;

		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );

		if ( empty( $ids ) || ( null === $min && null === $max ) || ! class_exists( 'WooCommerce' ) ) {
			return $ids;
		}

		$lookup = $wpdb->prefix . 'wc_product_meta_lookup';
		$in     = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$cond   = array();

		if ( null !== $min ) {
			$cond[] = 'max_price >= ' . number_format( (float) $min, 2, '.', '' );
		}

		if ( null !== $max ) {
			$cond[] = 'min_price <= ' . number_format( (float) $max, 2, '.', '' );
		}

		$cond_sql = implode( ' AND ', $cond );

		$sql  = "SELECT product_id FROM `$lookup` WHERE product_id IN ($in) AND $cond_sql";
		$kept = $wpdb->get_col( $wpdb->prepare( $sql, $ids ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		$keep = array_flip( array_map( 'intval', (array) $kept ) );

		return array_values(
			array_filter(
				$ids,
				static function ( $id ) use ( $keep ) {
					return isset( $keep[ $id ] );
				}
			)
		);
	}

	/**
	 * A term ID plus all of its descendant term IDs in a taxonomy.
	 *
	 * @since 1.0.0
	 * @param int    $term_id  Selected term ID.
	 * @param string $taxonomy Taxonomy slug.
	 * @return int[] Empty when the term or taxonomy is invalid.
	 */
	public static function term_and_children( int $term_id, string $taxonomy ): array {
		if ( $term_id <= 0 || '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
			return array();
		}

		if ( ! get_term( $term_id, $taxonomy ) instanceof WP_Term ) {
			return array();
		}

		$ids      = array( $term_id );
		$children = get_term_children( $term_id, $taxonomy );

		if ( is_array( $children ) ) {
			foreach ( $children as $child ) {
				$ids[] = (int) $child;
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Minimum number of query terms an object must match for the chosen strictness.
	 *
	 * Strict = all terms (AND); loose = any single term (OR); balanced = most
	 * of the terms (a coverage floor), which drops results that only share a
	 * word or two with a multi-word query.
	 *
	 * @since 1.0.4
	 * @param string $strictness 'loose', 'balanced' or 'strict'.
	 * @param int    $count      Number of query terms.
	 * @return int Floor between 1 and $count.
	 */
	private static function min_match( string $strictness, int $count ): int {
		if ( $count <= 1 ) {
			return 1;
		}

		switch ( $strictness ) {
			case 'strict':
				return $count;
			case 'loose':
				return 1;
			default:
				return (int) max( 1, $count - (int) floor( $count / 3 ) );
		}
	}

	/**
	 * Resolve the out-of-stock handling mode.
	 *
	 * @since 1.0.0
	 * @return string 'show', 'hide' or 'demote'.
	 */
	private static function stock_mode(): string {
		$mode = (string) MVweb_SS_Settings::get( 'stock', 'show' );

		return in_array( $mode, array( 'hide', 'demote' ), true ) ? $mode : 'show';
	}

	/**
	 * SQL expression counting how many distinct coverage GROUPS an object matched,
	 * used both to order results and to enforce the strictness floor (HAVING).
	 *
	 * Each query term maps to its group's index; COUNT(DISTINCT group_index) then
	 * counts covered concepts, so a word and its synonym or transliteration score
	 * one coverage point, not two (P0.2). Term strings are bound as prepared
	 * placeholders (%s) in caller order; group indices are trusted integers.
	 *
	 * With the "match in product data, not description" option on, coverage counts
	 * only when the term appears in an identifying field (title, SKU, attributes,
	 * brand, categories, custom fields), never the marketing description — where a
	 * model number or a part word appears incidentally and would otherwise let an
	 * unrelated product satisfy an all-words query. The description still feeds the
	 * score, it just no longer alone clears the floor.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups Coverage groups (in flatten order).
	 * @return string
	 */
	private static function coverage_case_sql( array $groups ): string {
		$cases = '';

		foreach ( $groups as $gi => $group ) {
			$cases .= str_repeat( ' WHEN %s THEN ' . (int) $gi, count( $group ) );
		}

		$inner = 'CASE i.term' . $cases . ' END';

		if ( ! MVweb_SS_Settings::get( 'title_coverage', false ) ) {
			return "COUNT( DISTINCT $inner )";
		}

		return "COUNT( DISTINCT CASE WHEN i.source NOT IN ( 'content', 'excerpt' ) THEN ( $inner ) END )";
	}

	/**
	 * The source restriction coverage counts under, as a SQL fragment to append to
	 * a WHEN clause ('' when prose counts too).
	 *
	 * Kept next to coverage_case_sql() so a required group is judged by exactly the
	 * same rule as the coverage it sits beside: a model number mentioned only in a
	 * description cannot satisfy a requirement that the title-coverage setting has
	 * already excluded from counting.
	 *
	 * @since 1.5.8
	 * @return string
	 */
	private static function coverage_source_sql(): string {
		return MVweb_SS_Settings::get( 'title_coverage', false )
			? " AND i.source NOT IN ( 'content', 'excerpt' )"
			: '';
	}

	/**
	 * Total indexed document count for IDF, cached per request.
	 *
	 * @since 1.2.0
	 * @return int At least 1.
	 */
	private static function doc_count(): int {
		static $n = null;

		if ( null !== $n ) {
			return $n;
		}

		$meta = MVweb_SS_Schema::get_meta();
		$n    = isset( $meta['doc_count'] ) ? (int) $meta['doc_count'] : 0;

		if ( $n <= 0 ) {
			$n = MVweb_SS_Indexer::count_objects();
		}

		$n = max( 1, $n );

		return $n;
	}

	/**
	 * BM25-style term-frequency saturation as an SQL sub-expression.
	 *
	 * Replaces the raw term frequency (`i.count`) with tf·(k1+1)/(tf+k1) so a
	 * word repeated many times in one long field (keyword stuffing) can no
	 * longer outweigh a clean title match. tf = 1 yields 1.0, matching the old
	 * linear score for the common single-occurrence case. Float literals are
	 * formatted with an explicit dot (locale-independent).
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private static function tf_saturation(): string {
		$num = number_format( self::BM25_K1 + 1, 1, '.', '' );
		$den = number_format( self::BM25_K1, 1, '.', '' );

		return '( i.count * ' . $num . ' / ( i.count + ' . $den . ' ) )';
	}

	/**
	 * Build the SQL CASE expression that applies per-source weights.
	 *
	 * Source keys and weights are trusted plugin constants, sanitized before
	 * inlining (no user input reaches this expression). Term frequency is
	 * saturated (see tf_saturation()) so repetition has diminishing returns.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function weight_case(): string {
		$weights = wp_parse_args( (array) MVweb_SS_Settings::get( 'weights', array() ), self::$weights );
		$weights = apply_filters( 'mvweb_ss_field_weights', $weights );

		if ( ! is_array( $weights ) || empty( $weights ) ) {
			$weights = self::$weights;
		}

		$tf    = self::tf_saturation();
		$parts = array();

		foreach ( $weights as $source => $weight ) {
			$source  = preg_replace( '/[^a-z_]/', '', (string) $source );
			$parts[] = "WHEN '" . $source . "' THEN " . (int) $weight . ' * ' . $tf;
		}

		return 'CASE i.source ' . implode( ' ', $parts ) . ' ELSE ' . $tf . ' END';
	}

	/**
	 * Per-source weight CASE with BM25 field-length normalization (P1.2).
	 *
	 * Same as weight_case(), but each source's contribution is divided by its
	 * fieldnorm ((1-b) + b·len/avgdl): a term in a field longer than average is
	 * down-weighted, a term in a short field keeps its full weight. avgdl per
	 * source comes from the index meta (rebuilt on reindex); b is lighter for
	 * short structured fields (title, sku, brand) than for free text (content,
	 * excerpt), matching how much their length actually varies. A source without
	 * an avgdl, or a row without a doclen entry, falls back to no normalization
	 * (fieldnorm 1), so the mode degrades to the plain weighted score rather than
	 * dividing by zero. Values are trusted constants/meta, inlined as floats.
	 *
	 * @since 1.2.0
	 * @return string
	 */
	private static function weight_case_doclen(): string {
		$weights = wp_parse_args( (array) MVweb_SS_Settings::get( 'weights', array() ), self::$weights );
		$weights = apply_filters( 'mvweb_ss_field_weights', $weights );

		if ( ! is_array( $weights ) || empty( $weights ) ) {
			$weights = self::$weights;
		}

		$meta  = MVweb_SS_Schema::get_meta();
		$avgdl = isset( $meta['avgdl'] ) && is_array( $meta['avgdl'] ) ? $meta['avgdl'] : array();
		$long  = array( 'content', 'excerpt', 'tax', 'cf' );

		$tf    = self::tf_saturation();
		$parts = array();

		foreach ( $weights as $source => $weight ) {
			$source = preg_replace( '/[^a-z_]/', '', (string) $source );
			$weight = (int) $weight;
			$avg    = isset( $avgdl[ $source ] ) ? (float) $avgdl[ $source ] : 0.0;

			if ( $avg > 0 ) {
				$b       = in_array( $source, $long, true ) ? self::BM25_B_CONTENT : self::BM25_B_TITLE;
				$one_b   = number_format( 1 - $b, 3, '.', '' );
				$bf      = number_format( $b, 3, '.', '' );
				$avgf    = number_format( $avg, 3, '.', '' );
				$norm    = '( ' . $one_b . ' + ' . $bf . ' * COALESCE( dl.len, ' . $avgf . ' ) / ' . $avgf . ' )';
				$parts[] = "WHEN '" . $source . "' THEN " . $weight . ' * ' . $tf . ' / ' . $norm;
			} else {
				$parts[] = "WHEN '" . $source . "' THEN " . $weight . ' * ' . $tf;
			}
		}

		return 'CASE i.source ' . implode( ' ', $parts ) . ' ELSE ' . $tf . ' END';
	}
}
