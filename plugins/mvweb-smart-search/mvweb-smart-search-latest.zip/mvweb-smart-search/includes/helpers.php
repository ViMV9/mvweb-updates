<?php
/**
 * Helper functions for MVweb Smart Search.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_ss_asset_ver' ) ) {
	/**
	 * Cache-busting version for a bundled asset: its file modification time,
	 * falling back to the plugin version. Keeps browsers in sync after every
	 * deploy without bumping the plugin version.
	 *
	 * @since 1.0.0
	 * @param string $relative Path relative to the plugin root (e.g. 'public/css/public.css').
	 * @return string
	 */
	function mvweb_ss_asset_ver( string $relative ): string {
		$file = MVWEB_SS_PATH . ltrim( $relative, '/' );
		$time = is_readable( $file ) ? filemtime( $file ) : false;

		return false !== $time ? (string) $time : MVWEB_SS_VERSION;
	}
}

if ( ! function_exists( 'mvweb_ss_type_order' ) ) {
	/**
	 * Indexed post types in the order set on the Behavior tab, for themes that
	 * group the results page themselves.
	 *
	 * @since 1.6.22
	 * @return string[]
	 */
	function mvweb_ss_type_order(): array {
		return class_exists( 'MVweb_SS_Settings' ) ? MVweb_SS_Settings::type_order() : array();
	}
}

if ( ! function_exists( 'mvweb_ss_get_search_bar' ) ) {
	/**
	 * Return the Smart Search bar markup for use in themes and page builders.
	 *
	 * @since 1.0.0
	 * @param array $args Optional overrides (e.g. 'placeholder').
	 * @return string
	 */
	function mvweb_ss_get_search_bar( array $args = array() ): string {
		return class_exists( 'MVweb_SS_Frontend' ) ? MVweb_SS_Frontend::render_form( $args ) : '';
	}
}

if ( ! function_exists( 'mvweb_ss_search_bar' ) ) {
	/**
	 * Echo the Smart Search bar (template tag).
	 *
	 * @since 1.0.0
	 * @param array $args Optional overrides.
	 * @return void
	 */
	function mvweb_ss_search_bar( array $args = array() ): void {
		echo mvweb_ss_get_search_bar( $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render_form returns pre-escaped markup.
	}
}
