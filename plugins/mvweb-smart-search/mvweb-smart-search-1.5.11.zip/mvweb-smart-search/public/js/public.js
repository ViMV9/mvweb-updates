/**
 * Public (frontend) JavaScript for MVweb Smart Search.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

( function () {
	'use strict';

	if ( typeof window.mvwebSS === 'undefined' ) {
		return;
	}

	var cfg = window.mvwebSS;
	var show = cfg.show || { image: true, price: true, stock: true, excerpt: true };
	var panelCfg = cfg.panel || { details: true, overlay: true };
	var GROUP_ORDER = ( cfg.groupOrder && cfg.groupOrder.length ) ? cfg.groupOrder : [ 'product', 'post', 'page' ];
	var DEBOUNCE = ( cfg.debounce != null ) ? cfg.debounce : 200;
	var isMobile = window.matchMedia( '(max-width: 782px)' );
	var uid = 0;
	// Reference count of open mobile overlays across every search form on the page,
	// so the body scroll lock is only released once the last overlay closes.
	var openOverlays = 0;

	function queryWords( q ) {
		if ( ! q ) {
			return [];
		}
		return q.toLowerCase().split( /\s+/ ).filter( function ( w ) {
			return w.length >= 2;
		} );
	}

	function highlightInto( node, text, words ) {
		node.textContent = '';
		text = text || '';

		if ( ! cfg.highlight || ! words || ! words.length ) {
			node.textContent = text;
			return;
		}

		var lower = text.toLowerCase();
		var i = 0;

		while ( i < text.length ) {
			var at = -1;
			var matchLen = 0;

			for ( var w = 0; w < words.length; w++ ) {
				var idx = words[ w ] ? lower.indexOf( words[ w ], i ) : -1;
				if ( idx !== -1 && ( at === -1 || idx < at || ( idx === at && words[ w ].length > matchLen ) ) ) {
					at = idx;
					matchLen = words[ w ].length;
				}
			}

			if ( at === -1 ) {
				node.appendChild( document.createTextNode( text.slice( i ) ) );
				break;
			}

			if ( at > i ) {
				node.appendChild( document.createTextNode( text.slice( i, at ) ) );
			}

			var mark = document.createElement( 'mark' );
			mark.className = 'mvweb-ss__mark';
			mark.textContent = text.slice( at, at + matchLen );
			node.appendChild( mark );
			i = at + matchLen;
		}
	}

	function debounce( fn, wait ) {
		var t;
		return function () {
			var ctx = this;
			var args = arguments;
			clearTimeout( t );
			t = setTimeout( function () {
				fn.apply( ctx, args );
			}, wait );
		};
	}

	function groupLabel( type ) {
		if ( type === 'product' ) {
			return cfg.i18n.products;
		}
		if ( type === 'post' ) {
			return cfg.i18n.posts;
		}
		if ( type === 'page' ) {
			return cfg.i18n.pages;
		}
		return cfg.i18n.other;
	}

	function el( tag, className, text ) {
		var node = document.createElement( tag );
		if ( className ) {
			node.className = className;
		}
		if ( text != null ) {
			node.textContent = text;
		}
		return node;
	}

	var HISTORY_KEY = 'mvweb_ss_history';
	var HISTORY_MAX = 6;

	function loadHistory() {
		try {
			var v = JSON.parse( window.localStorage.getItem( HISTORY_KEY ) || '[]' );
			return Array.isArray( v ) ? v : [];
		} catch ( e ) {
			return [];
		}
	}

	function saveQuery( q ) {
		q = ( q || '' ).trim();
		if ( q.length < 2 || ! cfg.history ) {
			return;
		}
		try {
			var h = loadHistory().filter( function ( x ) {
				return x.toLowerCase() !== q.toLowerCase();
			} );
			h.unshift( q );
			window.localStorage.setItem( HISTORY_KEY, JSON.stringify( h.slice( 0, HISTORY_MAX ) ) );
		} catch ( e ) {}
	}

	function clearHistory() {
		try {
			window.localStorage.removeItem( HISTORY_KEY );
		} catch ( e ) {}
	}

	function attach( form ) {
		var input = form.querySelector( '.mvweb-ss__input' );
		var panel = form.querySelector( '.mvweb-ss__panel' );

		if ( ! input || ! panel ) {
			return;
		}

		// ARIA combobox wiring: the input owns the popup and points at the active
		// option via aria-activedescendant, since focus stays in the field.
		if ( ! panel.id ) {
			panel.id = 'mvweb-ss-panel-' + ( ++uid );
		}
		input.setAttribute( 'role', 'combobox' );
		input.setAttribute( 'aria-autocomplete', 'list' );
		input.setAttribute( 'aria-haspopup', 'listbox' );
		input.setAttribute( 'aria-expanded', 'false' );
		input.setAttribute( 'aria-controls', panel.id );

		// Screen-reader status line + in-field loading spinner, created here so
		// existing installs gain them without a markup change.
		var status = el( 'span', 'mvweb-ss__status' );
		status.setAttribute( 'role', 'status' );
		status.setAttribute( 'aria-live', 'polite' );
		form.appendChild( status );

		var spinner = el( 'span', 'mvweb-ss__spinner' );
		spinner.setAttribute( 'aria-hidden', 'true' );
		form.appendChild( spinner );

		var reqId = 0;

		function announce( msg ) {
			status.textContent = msg || '';
		}

		var controller = null;
		var items = [];
		var active = -1;
		var details = null;
		var words = [];
		var scope = form.getAttribute( 'data-types' ) || '';
		var scopeSelect = form.querySelector( '.mvweb-ss__scope' );
		var clearBtn = form.querySelector( '.mvweb-ss__clear' );
		var lastQuery = '';

		function toggleClear() {
			if ( clearBtn ) {
				clearBtn.hidden = input.value.length === 0;
			}
		}

		function catValue() {
			return scopeSelect ? ( parseInt( scopeSelect.value, 10 ) || 0 ) : 0;
		}

		function sendClick( id ) {
			if ( ! cfg.click || ! lastQuery || ! ( 'sendBeacon' in navigator ) ) {
				return;
			}
			try {
				var url = cfg.click + '?q=' + encodeURIComponent( lastQuery );
				if ( id ) {
					url += '&id=' + encodeURIComponent( id );
				}
				navigator.sendBeacon( url );
			} catch ( e ) {}
		}

		if ( ! panelCfg.overlay ) {
			form.classList.add( 'mvweb-ss--no-overlay' );
		}

		var submit = form.querySelector( '.mvweb-ss__submit' );

		function collapsedModeActive() {
			var desktopCollapse = form.classList.contains( 'mvweb-ss--icon-desktop' ) || form.classList.contains( 'mvweb-ss--word-desktop' );
			var mobileCollapse = form.classList.contains( 'mvweb-ss--icon-mobile' ) || form.classList.contains( 'mvweb-ss--word-mobile' );
			return ( desktopCollapse && ! isMobile.matches ) || ( mobileCollapse && isMobile.matches );
		}

		function syncIconMode() {
			if ( collapsedModeActive() ) {
				form.classList.add( 'mvweb-ss--icon-collapsed' );
			} else {
				form.classList.remove( 'mvweb-ss--icon-collapsed' );
				form.classList.remove( 'is-expanded' );
			}
		}

		syncIconMode();
		isMobile.addEventListener( 'change', function () {
			// Crossing the breakpoint with the mobile overlay open would otherwise
			// leave the body scroll-locked and the overlay class stuck. Close only a
			// real overlay; the desktop inline panel (no overlay-on class) is left be.
			if ( form.classList.contains( 'mvweb-ss--overlay-on' ) ) {
				close();
			}
			syncIconMode();
		} );

		if ( submit ) {
			submit.addEventListener( 'click', function ( e ) {
				if ( form.classList.contains( 'mvweb-ss--icon-collapsed' ) && ! form.classList.contains( 'is-expanded' ) ) {
					e.preventDefault();
					form.classList.add( 'is-expanded' );
					input.focus();
					if ( panelCfg.overlay && isMobile.matches ) {
						showEmpty();
					}
				}
			} );
		}

		// Tracks whether THIS form currently holds an overlay lock, so repeated
		// open()/close() calls (open fires on every keystroke render, close from
		// several sources) never over- or under-count the shared lock counter.
		var overlayHeld = false;

		function open() {
			panel.hidden = false;
			input.setAttribute( 'aria-expanded', 'true' );
			if ( panelCfg.overlay && isMobile.matches ) {
				form.classList.add( 'mvweb-ss--overlay-on' );
				if ( ! overlayHeld ) {
					overlayHeld = true;
					openOverlays++;
					document.body.classList.add( 'mvweb-ss-lock' );
				}
			}
		}

		function close() {
			panel.hidden = true;
			input.setAttribute( 'aria-expanded', 'false' );
			input.removeAttribute( 'aria-activedescendant' );
			form.classList.remove( 'mvweb-ss--overlay-on' );
			if ( overlayHeld ) {
				overlayHeld = false;
				openOverlays = Math.max( 0, openOverlays - 1 );
				if ( 0 === openOverlays ) {
					document.body.classList.remove( 'mvweb-ss-lock' );
				}
			}
		}

		// Close the dropdown and, in collapsed (icon/word) mode, fold the field
		// back to its trigger so the mobile full-screen overlay dismisses fully.
		function collapse() {
			close();
			form.classList.remove( 'is-expanded' );
		}

		// Prepend the close button to the panel (shown as the overlay header on
		// mobile). Used by both the results view and the empty-focus suggestions.
		function addCloseButton() {
			var closeBtn = el( 'button', 'mvweb-ss__close', cfg.i18n.close );
			closeBtn.type = 'button';
			closeBtn.addEventListener( 'click', collapse );
			panel.appendChild( closeBtn );
		}

		function overlayActive() {
			return panelCfg.overlay && isMobile.matches && form.classList.contains( 'is-expanded' );
		}

		function updateDetails( data ) {
			if ( ! details || ! data ) {
				return;
			}
			details.textContent = '';

			if ( show.image && data.image ) {
				var img = el( 'img', 'mvweb-ss__details-img' );
				img.src = data.image;
				img.alt = '';
				details.appendChild( img );
			}

			details.appendChild( el( 'div', 'mvweb-ss__details-title', data.title || '' ) );

			if ( show.price && data.price ) {
				details.appendChild( el( 'div', 'mvweb-ss__details-price', data.price ) );
			}

			if ( show.stock && typeof data.in_stock !== 'undefined' ) {
				details.appendChild( el(
					'div',
					'mvweb-ss__details-stock ' + ( data.in_stock ? 'is-in' : 'is-out' ),
					data.in_stock ? cfg.i18n.inStock : cfg.i18n.outStock
				) );
			}

			if ( show.excerpt && data.excerpt ) {
				details.appendChild( el( 'div', 'mvweb-ss__details-excerpt', data.excerpt ) );
			}

			var actions = el( 'div', 'mvweb-ss__details-actions' );

			var view = el( 'a', 'mvweb-ss__details-view', cfg.i18n.view );
			view.href = data.url || '#';
			actions.appendChild( view );

			if ( data.add && data.add.url ) {
				var cart = el( 'a', 'mvweb-ss__details-cart', data.add.label || '' );
				cart.href = data.add.url;
				cart.rel = 'nofollow';
				if ( data.add.ajax ) {
					cart.className += ' add_to_cart_button ajax_add_to_cart';
					cart.setAttribute( 'data-product_id', data.id );
					cart.setAttribute( 'data-quantity', '1' );
				}
				actions.appendChild( cart );
			}

			details.appendChild( actions );
		}

		function setActive( i ) {
			if ( items[ active ] ) {
				items[ active ].classList.remove( 'is-active' );
				items[ active ].setAttribute( 'aria-selected', 'false' );
			}
			active = i;
			if ( items[ active ] ) {
				items[ active ].classList.add( 'is-active' );
				items[ active ].setAttribute( 'aria-selected', 'true' );
				input.setAttribute( 'aria-activedescendant', items[ active ].id );
				items[ active ].scrollIntoView( { block: 'nearest' } );
				updateDetails( items[ active ]._data );
			} else {
				input.removeAttribute( 'aria-activedescendant' );
			}
		}

		function nextVisible( from, dir ) {
			var n = items.length;
			for ( var k = 1; k <= n; k++ ) {
				var i = ( ( from + dir * k ) % n + n ) % n;
				if ( ! items[ i ]._section || ! items[ i ]._section.hidden ) {
					return i;
				}
			}
			return from;
		}

		function makeItem( result ) {
			var a = el( 'a', 'mvweb-ss__item' );
			a.href = result.url || '#';
			a.id = 'mvweb-ss-opt-' + ( ++uid );
			a.setAttribute( 'role', 'option' );
			a.setAttribute( 'aria-selected', 'false' );
			a._data = result;

			if ( show.image ) {
				if ( result.thumbnail ) {
					var img = el( 'img', 'mvweb-ss__thumb' );
					img.src = result.thumbnail;
					img.alt = '';
					img.loading = 'lazy';
					a.appendChild( img );
				} else {
					a.appendChild( el( 'span', 'mvweb-ss__thumb mvweb-ss__thumb--empty' ) );
				}
			}

			var body = el( 'span', 'mvweb-ss__item-body' );
			var titleSpan = el( 'span', 'mvweb-ss__item-title' );
			highlightInto( titleSpan, result.title || '', words );
			body.appendChild( titleSpan );
			if ( show.price && result.price ) {
				body.appendChild( el( 'span', 'mvweb-ss__item-price', result.price ) );
			}
			a.appendChild( body );

			var idx = items.length;
			a.addEventListener( 'mouseenter', function () {
				setActive( idx );
			} );
			a.addEventListener( 'click', function () {
				saveQuery( input.value );
				sendClick( result.id );
			} );

			items.push( a );
			return a;
		}

		function resultsUrl() {
			var action = form.getAttribute( 'action' ) || '';
			var sep = action.indexOf( '?' ) === -1 ? '?' : '&';
			return action + sep + 's=' + encodeURIComponent( input.value.trim() ) +
				( scope ? '&mvweb_ss_types=' + encodeURIComponent( scope ) : '' );
		}

		function narrowUrl( termId, taxonomy ) {
			return resultsUrl() +
				'&mvweb_ss_cat=' + encodeURIComponent( termId ) +
				'&mvweb_ss_tax=' + encodeURIComponent( taxonomy );
		}

		function makeCategory( c ) {
			var a = el( 'a', 'mvweb-ss__cat' );
			a.href = c.term_id ? narrowUrl( c.term_id, c.taxonomy || '' ) : ( c.url || '#' );
			// Give category/brand chips an id and a place in items[] so the arrow keys
			// and aria-activedescendant reach them, matching their role="option".
			a.id = 'mvweb-ss-opt-' + ( ++uid );
			a.setAttribute( 'role', 'option' );
			a.setAttribute( 'aria-selected', 'false' );

			var body = el( 'span', 'mvweb-ss__cat-body' );
			var name = el( 'span', 'mvweb-ss__cat-name' );
			highlightInto( name, c.name || '', words );
			body.appendChild( name );

			if ( c.context ) {
				body.appendChild( el( 'span', 'mvweb-ss__cat-context', c.context ) );
			}

			a.appendChild( body );

			if ( c.count ) {
				a.appendChild( el( 'span', 'mvweb-ss__cat-count', String( c.count ) ) );
			}

			var idx = items.length;
			a.addEventListener( 'mouseenter', function () {
				setActive( idx );
			} );
			a.addEventListener( 'click', function () {
				saveQuery( input.value );
				sendClick();
			} );

			items.push( a );
			return a;
		}

		function makeTabs( sections ) {
			var bar = el( 'div', 'mvweb-ss__tabs' );
			var tabEls = [];

			function activate( key, btn ) {
				tabEls.forEach( function ( t ) {
					t.classList.remove( 'is-active' );
				} );
				btn.classList.add( 'is-active' );
				sections.forEach( function ( s ) {
					s.el.hidden = null !== key && s.key !== key;
				} );
				// If the highlighted option now sits in a hidden section, drop the
				// selection so aria-activedescendant never points at a hidden node.
				if ( items[ active ] && items[ active ]._section && items[ active ]._section.hidden ) {
					setActive( -1 );
				}
			}

			function tab( label, key ) {
				var b = el( 'button', 'mvweb-ss__tab', label );
				b.type = 'button';
				b.addEventListener( 'click', function () {
					activate( key, b );
				} );
				tabEls.push( b );
				bar.appendChild( b );
				return b;
			}

			tab( cfg.i18n.allTab || 'All', null ).classList.add( 'is-active' );
			sections.forEach( function ( s ) {
				tab( s.label, s.key );
			} );

			return bar;
		}

		function render( data ) {
			panel.textContent = '';
			items = [];
			active = -1;
			input.removeAttribute( 'aria-activedescendant' );
			details = null;
			words = queryWords( data.query );
			lastQuery = data.query || '';

			if ( cfg.revenue && lastQuery ) {
				try {
					document.cookie = 'mvweb_ss_lq=' + encodeURIComponent( lastQuery ) + ';path=/;max-age=1800;samesite=lax';
				} catch ( e ) {}
			}

			addCloseButton();

			if ( data.fallback === 'bestsellers' && cfg.i18n.zeroFallback ) {
				panel.appendChild( el( 'div', 'mvweb-ss__correction', cfg.i18n.zeroFallback ) );
			}

			if ( data.corrected && cfg.fuzzyNotice && cfg.fuzzyNotice !== 'silent' ) {
				var notice = el( 'div', 'mvweb-ss__correction' );
				var action = form.getAttribute( 'action' ) || '';

				if ( cfg.fuzzyNotice === 'suggest' ) {
					var parts = ( cfg.i18n.didYouMean || 'Did you mean %s?' ).split( '%s' );
					var link = el( 'a', 'mvweb-ss__correction-link', data.corrected );
					link.href = action + ( action.indexOf( '?' ) === -1 ? '?' : '&' ) + 's=' + encodeURIComponent( data.corrected );
					notice.appendChild( document.createTextNode( parts[ 0 ] ) );
					notice.appendChild( link );
					if ( parts.length > 1 ) {
						notice.appendChild( document.createTextNode( parts[ 1 ] ) );
					}
				} else {
					notice.textContent = ( cfg.i18n.showingFor || 'Showing results for %s' ).replace( '%s', data.corrected );
				}

				panel.appendChild( notice );
			}

			var cats = data.categories || [];
			var brands = data.brands || [];
			var results = data.results || [];

			if ( ! cats.length && ! brands.length && ! results.length ) {
				panel.appendChild( el( 'div', 'mvweb-ss__empty', cfg.i18n.nothing ) );
				if ( cfg.zeroCta && cfg.zeroCta.text && cfg.zeroCta.url ) {
					var cta = el( 'a', 'mvweb-ss__cta', cfg.zeroCta.text );
					cta.href = cfg.zeroCta.url;
					panel.appendChild( cta );
				}
				announce( cfg.i18n.nothing );
				open();
				return;
			}

			var layout = el( 'div', 'mvweb-ss__layout' );
			var list = el( 'div', 'mvweb-ss__list' + ( 'grid' === cfg.layout ? ' mvweb-ss__list--grid' : '' ) );
			list.setAttribute( 'role', 'listbox' );
			list.setAttribute( 'aria-label', input.getAttribute( 'aria-label' ) || 'Search results' );
			details = ( panelCfg.details && results.length ) ? el( 'div', 'mvweb-ss__details' ) : null;

			var sections = [];

			function addSection( key, label, rows, isCat ) {
				var sec = el( 'div', 'mvweb-ss__section' );
				sec.setAttribute( 'data-type', key );
				sec.setAttribute( 'role', 'group' );
				sec.setAttribute( 'aria-label', label );
				sec.appendChild( el( 'div', 'mvweb-ss__group', label ) );
				rows.forEach( function ( r ) {
					var node = isCat ? makeCategory( r ) : makeItem( r );
					node._section = sec;
					sec.appendChild( node );
				} );
				list.appendChild( sec );
				sections.push( { key: key, label: label, el: sec } );
			}

			if ( cats.length ) {
				addSection( 'category', cfg.i18n.categories, cats, true );
			}

			if ( brands.length ) {
				addSection( 'brand', cfg.i18n.brands, brands, true );
			}

			var groups = {};
			results.forEach( function ( r ) {
				var key = r.type || 'other';
				( groups[ key ] = groups[ key ] || [] ).push( r );
			} );

			var order = GROUP_ORDER.filter( function ( t ) {
				return groups[ t ];
			} );
			Object.keys( groups ).forEach( function ( t ) {
				if ( order.indexOf( t ) === -1 ) {
					order.push( t );
				}
			} );

			order.forEach( function ( type ) {
				var rows = ( cfg.perGroup > 0 ) ? groups[ type ].slice( 0, cfg.perGroup ) : groups[ type ];
				addSection( type, groupLabel( type ), rows, false );
			} );

			if ( cfg.filterTabs && sections.length >= 2 ) {
				panel.appendChild( makeTabs( sections ) );
			}

			layout.appendChild( list );
			if ( details ) {
				layout.appendChild( details );
			}
			panel.appendChild( layout );

			var all = el( 'a', 'mvweb-ss__all', cfg.i18n.all );
			all.href = resultsUrl() + ( catValue() ? '&mvweb_ss_cat=' + catValue() : '' );
			panel.appendChild( all );

			for ( var di = 0; di < items.length; di++ ) {
				if ( items[ di ]._data ) {
					updateDetails( items[ di ]._data );
					break;
				}
			}

			if ( data.fallback === 'bestsellers' ) {
				announce( cfg.i18n.zeroFallback || '' );
			} else {
				// Count what was actually rendered and can be navigated (categories,
				// brands and the possibly per-group-capped results), not the full
				// pre-slice result total, so the screen-reader figure matches the DOM.
				announce( ( cfg.i18n.found || '%d' ).replace( '%d', items.length ) );
			}

			open();
		}

		function queryChip( q ) {
			var b = el( 'button', 'mvweb-ss__suggest-item', q );
			b.type = 'button';
			b.addEventListener( 'click', function () {
				input.value = q;
				input.focus();
				input.dispatchEvent( new Event( 'input', { bubbles: true } ) );
			} );
			return b;
		}

		function showEmpty() {
			var hist = cfg.history ? loadHistory() : [];
			var popular = ( cfg.popular && cfg.popular.length ) ? cfg.popular : [];

			if ( ! hist.length && ! popular.length && ! overlayActive() ) {
				close();
				panel.textContent = '';
				return;
			}

			panel.textContent = '';
			items = [];
			active = -1;
			input.removeAttribute( 'aria-activedescendant' );

			addCloseButton();

			if ( hist.length ) {
				var head = el( 'div', 'mvweb-ss__suggest-head' );
				head.appendChild( el( 'span', 'mvweb-ss__group', cfg.i18n.recent ) );

				var clear = el( 'button', 'mvweb-ss__history-clear', cfg.i18n.clear );
				clear.type = 'button';
				clear.addEventListener( 'click', function () {
					clearHistory();
					close();
					showEmpty();
				} );
				head.appendChild( clear );
				panel.appendChild( head );

				hist.forEach( function ( q ) {
					panel.appendChild( queryChip( q ) );
				} );
			}

			if ( popular.length ) {
				var popHead = el( 'div', 'mvweb-ss__suggest-head' );
				popHead.appendChild( el( 'span', 'mvweb-ss__group', cfg.i18n.popular ) );
				panel.appendChild( popHead );

				popular.forEach( function ( q ) {
					panel.appendChild( queryChip( q ) );
				} );
			}

			open();
		}

		function showError() {
			panel.textContent = '';
			items = [];
			active = -1;
			input.removeAttribute( 'aria-activedescendant' );

			var msg = el( 'div', 'mvweb-ss__error', cfg.i18n.error || 'Could not load results, please try again.' );
			msg.setAttribute( 'role', 'alert' );
			panel.appendChild( msg );

			announce( cfg.i18n.error || '' );
			open();
		}

		var run = debounce( function () {
			var q = input.value.trim();

			if ( q.length < cfg.minChars ) {
				// Cancel any in-flight request and bump the id so a late response for
				// the just-cleared query can't re-open the panel over an empty field.
				if ( controller ) {
					controller.abort();
				}
				reqId++;
				form.classList.remove( 'is-loading' );
				if ( ! q ) {
					showEmpty();
				} else {
					close();
					panel.textContent = '';
				}
				return;
			}

			if ( controller ) {
				controller.abort();
			}
			controller = ( 'AbortController' in window ) ? new AbortController() : null;

			var myId = ++reqId;
			form.classList.add( 'is-loading' );
			announce( cfg.i18n.searching || '' );

			fetch( cfg.rest + '?q=' + encodeURIComponent( q ) + ( cfg.limit ? '&limit=' + cfg.limit : '' ) + ( scope ? '&types=' + encodeURIComponent( scope ) : '' ) + ( catValue() ? '&cat=' + catValue() : '' ), {
				signal: controller ? controller.signal : undefined,
				headers: { Accept: 'application/json' },
			} )
				.then( function ( res ) {
					return res.ok ? res.json() : null;
				} )
				.then( function ( data ) {
					if ( myId !== reqId ) {
						return;
					}
					if ( data ) {
						render( data );
					} else {
						// res.ok was false (4xx/5xx) — surface it instead of a silent
						// empty panel and a stuck spinner.
						showError();
					}
				} )
				.catch( function ( err ) {
					if ( err && 'AbortError' === err.name ) {
						return;
					}
					if ( myId === reqId ) {
						showError();
					}
				} )
				.then( function () {
					if ( myId === reqId ) {
						form.classList.remove( 'is-loading' );
					}
				} );
		}, DEBOUNCE );

		input.addEventListener( 'input', run );
		input.addEventListener( 'input', toggleClear );
		toggleClear();

		if ( clearBtn ) {
			clearBtn.addEventListener( 'click', function () {
				input.value = '';
				toggleClear();
				input.focus();
				input.dispatchEvent( new Event( 'input', { bubbles: true } ) );
			} );
		}

		if ( scopeSelect ) {
			scopeSelect.addEventListener( 'change', function () {
				if ( input.value.trim().length >= cfg.minChars ) {
					run();
				}
			} );
		}

		input.addEventListener( 'focus', function () {
			var q = input.value.trim();
			if ( ! q ) {
				showEmpty();
			} else if ( q.length >= cfg.minChars && panel.children.length ) {
				open();
			}
		} );

		form.addEventListener( 'submit', function () {
			saveQuery( input.value );
		} );

		input.addEventListener( 'keydown', function ( e ) {
			if ( e.key === 'Escape' ) {
				collapse();
				return;
			}
			if ( panel.hidden || ! items.length ) {
				return;
			}
			if ( e.key === 'ArrowDown' ) {
				e.preventDefault();
				setActive( nextVisible( active, 1 ) );
			} else if ( e.key === 'ArrowUp' ) {
				e.preventDefault();
				setActive( nextVisible( active < 0 ? 0 : active, -1 ) );
			} else if ( e.key === 'Enter' && active >= 0 && items[ active ] ) {
				e.preventDefault();
				saveQuery( input.value );
				sendClick( items[ active ]._data && items[ active ]._data.id );
				window.location = items[ active ].href;
			}
		} );

		document.addEventListener( 'click', function ( e ) {
			if ( ! form.contains( e.target ) ) {
				close();
				if ( form.classList.contains( 'mvweb-ss--icon-collapsed' ) && ! input.value.trim() ) {
					form.classList.remove( 'is-expanded' );
				}
			}
		} );

		// Keyboard exit: tabbing out of the widget closes the panel (and releases the
		// mobile scroll lock). The relatedTarget !== null guard is required — the DOM
		// returns null when focus goes nowhere (a click on a non-focusable element),
		// and Node.contains(null) is false, which would otherwise close the panel
		// prematurely; that path is left to the document click handler above.
		form.addEventListener( 'focusout', function ( e ) {
			if ( null !== e.relatedTarget && ! form.contains( e.relatedTarget ) ) {
				close();
			}
		} );
	}

	document.addEventListener( 'DOMContentLoaded', function () {
		var forms = document.querySelectorAll( '.mvweb-ss' );
		Array.prototype.forEach.call( forms, attach );

		// Facet panel: the "?" beside a category opens its full path. The panel is
		// server-rendered, so one delegated listener covers every row of every copy
		// on the page. Clicks are cancelled because each row is a <label> — without
		// that, reading a path would tick the filter it belongs to. An open path
		// covers the row below it, so a click on the path itself only closes it:
		// the second click then reaches whatever it was covering.
		document.addEventListener( 'click', function ( e ) {
			if ( ! e.target.closest ) {
				return;
			}

			var inside = e.target.closest( '.mvweb-ss-facets__chain' );

			if ( inside ) {
				e.preventDefault();
			}

			var btn = inside ? null : e.target.closest( '.mvweb-ss-facets__chain-btn' );
			var open = document.querySelectorAll( '.mvweb-ss-facets__chain-btn[aria-expanded="true"]' );

			Array.prototype.forEach.call( open, function ( other ) {
				if ( other !== btn ) {
					other.setAttribute( 'aria-expanded', 'false' );
				}
			} );

			if ( btn ) {
				e.preventDefault();
				btn.setAttribute( 'aria-expanded', btn.getAttribute( 'aria-expanded' ) === 'true' ? 'false' : 'true' );
			}
		} );

		// Results-page sort control: submit on change (no-JS falls back to a button).
		var sorts = document.querySelectorAll( '.mvweb-ss-sort__select' );
		Array.prototype.forEach.call( sorts, function ( sel ) {
			sel.addEventListener( 'change', function () {
				if ( sel.form ) {
					sel.form.submit();
				}
			} );
		} );
	} );
} )();
