<?php
/**
 * Search query engine: ranks index rows for a user query.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Turns a query string into a ranked list of matching objects.
 *
 * @since 1.0.0
 */
class MVweb_SS_Query {

	const MAX_LIMIT = 1000;

	const DEFAULT_LIMIT = 20;

	/**
	 * Head slice the PHP refinement passes (exact-match promotion, phrase
	 * proximity, product-type) scan. Bounds their cost so a large results-page pool never
	 * multiplies per-row title/product loads: an exact or phrase match carries
	 * full coverage and by the SQL order almost always ranks inside this head, so
	 * the rare miss (100+ equally-covered, higher-boosted rivals ahead of it) only
	 * forgoes its exact-match promotion — it never drops out of the results. The
	 * tail keeps its relevance order untouched.
	 */
	const REFINE_SCAN_CAP = 100;

	const FUZZY_THRESHOLD = 3;

	const BM25_K1 = 1.2;

	const BM25_B_TITLE = 0.3;

	const BM25_B_CONTENT = 0.75;

	/**
	 * Minimum trailing-word length before prefix (search-as-you-type) expansion
	 * fires, and the cap on index terms pulled per prefix. A 1-2 char prefix like
	 * "с%" would match a huge slice of the vocabulary, so both bounds are required.
	 */
	const PREFIX_MIN_LEN = 3;

	const PREFIX_CAP = 20;

	/**
	 * Corrected query phrase from the last fuzzy fallback, or empty string.
	 *
	 * @var string
	 */
	private static $correction = '';

	/**
	 * Which mechanism rescued the last search: 'layout', 'typo' or '' (none).
	 *
	 * @var string
	 */
	private static $rescue = '';

	/**
	 * Default per-source relevance weights.
	 *
	 * @var array<string,int>
	 */
	private static $weights = array(
		'title'         => 10,
		'sku'           => 10,
		'variation_sku' => 10,
		'gtin'          => 10,
		'brand'         => 7,
		'attr'          => 4,
		'excerpt'       => 4,
		'content'       => 3,
		'tax'           => 2,
		'cf'            => 2,
	);

	/**
	 * Default per-source relevance weights.
	 *
	 * @since 1.0.0
	 * @return array<string,int>
	 */
	public static function default_weights(): array {
		return self::$weights;
	}

	/**
	 * Which mechanism rescued the last search (analytics moat proof).
	 *
	 * @since 1.2.0
	 * @return string 'layout', 'typo', or '' when no correction was needed.
	 */
	public static function last_rescue(): string {
		return self::$rescue;
	}

	/**
	 * Corrected query phrase produced by the last fuzzy fallback.
	 *
	 * @since 1.0.0
	 * @return string Empty string when the last search needed no correction.
	 */
	public static function last_correction(): string {
		return self::$correction;
	}

	/**
	 * Best-selling products, used as a zero-result fallback so a shopper facing an
	 * unmatched query still sees products instead of a dead end (P1.7). Ordered by
	 * lifetime sales from the WooCommerce product lookup table, in-stock first.
	 *
	 * @since 1.2.0
	 * @param string[] $types Post types in scope; returns empty unless 'product' is allowed.
	 * @param int      $limit Maximum rows.
	 * @return array<int,array<string,int|string>> Rows shaped like run() output (object_id/object_type).
	 */
	public static function bestsellers( array $types, int $limit ): array {
		global $wpdb;

		if ( ! class_exists( 'WooCommerce' ) || ! in_array( 'product', $types, true ) ) {
			return array();
		}

		$limit  = max( 1, min( $limit, self::MAX_LIMIT ) );
		$lookup = $wpdb->prefix . 'wc_product_meta_lookup';

		// Mirror the visibility filters run() applies: never surface a password-protected
		// product, nor one the admin excluded from search, in the zero-result fallback.
		$exclude  = MVweb_SS_Settings::excluded_ids();
		$excl_sql = '';
		$values   = array();

		if ( ! empty( $exclude ) ) {
			$excl_sql = 'AND p.ID NOT IN ( ' . implode( ',', array_fill( 0, count( $exclude ), '%d' ) ) . ' )';
			$values   = $exclude;
		}

		$values[] = $limit;

		$sql = "SELECT pml.product_id
			FROM {$lookup} AS pml
			INNER JOIN {$wpdb->posts} AS p ON p.ID = pml.product_id
			WHERE p.post_type = 'product' AND p.post_status = 'publish' AND p.post_password = ''
			$excl_sql
			ORDER BY ( pml.stock_status = 'instock' ) DESC, pml.total_sales DESC, pml.product_id DESC
			LIMIT %d";

		$ids = $wpdb->get_col( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		$rows = array();

		foreach ( (array) $ids as $id ) {
			$rows[] = array(
				'object_id'   => (int) $id,
				'object_type' => 'product',
			);
		}

		return $rows;
	}

	/**
	 * Re-order a ranked ID list by a shopper-chosen sort (P2.2), keeping relevance
	 * as the default (empty $sort returns the list untouched). Price/rating/sales
	 * come from the WooCommerce lookup table; "newest" from post_date. Non-products
	 * (no lookup row) sort last so a mixed result set is preserved, not truncated.
	 *
	 * @since 1.2.0
	 * @param int[]  $ids  Relevance-ordered object IDs.
	 * @param string $sort One of price_asc|price_desc|rating|popularity|newest, or ''.
	 * @return int[] Re-ordered IDs (relevance order when $sort is empty/unknown).
	 */
	public static function sort_ids( array $ids, string $sort ): array {
		global $wpdb;

		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );

		if ( empty( $ids ) || '' === $sort ) {
			return $ids;
		}

		$in = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		if ( 'newest' === $sort ) {
			$sql    = "SELECT ID FROM {$wpdb->posts} WHERE ID IN ($in) ORDER BY post_date DESC, ID DESC";
			$sorted = $wpdb->get_col( $wpdb->prepare( $sql, $ids ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders
		} else {
			$columns = array(
				'price_asc'  => 'pml.min_price ASC',
				'price_desc' => 'pml.min_price DESC',
				'rating'     => 'pml.average_rating DESC',
				'popularity' => 'pml.total_sales DESC',
			);

			if ( ! isset( $columns[ $sort ] ) || ! class_exists( 'WooCommerce' ) ) {
				return $ids;
			}

			$lookup  = $wpdb->prefix . 'wc_product_meta_lookup';
			$orderby = $columns[ $sort ];
			$sql     = "SELECT p.ID FROM {$wpdb->posts} p
				LEFT JOIN `$lookup` pml ON pml.product_id = p.ID
				WHERE p.ID IN ($in)
				ORDER BY ( pml.product_id IS NULL ), $orderby, p.ID DESC";
			$sorted  = $wpdb->get_col( $wpdb->prepare( $sql, $ids ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders
		}

		$sorted = array_values( array_filter( array_map( 'intval', (array) $sorted ) ) );

		return ! empty( $sorted ) ? $sorted : $ids;
	}

	/**
	 * Phrase-proximity re-rank (P1.3). Within each coverage tier, promote titles
	 * that contain the query as an exact phrase (prox 2) or with the words in order
	 * (prox 1) over titles where the words are merely scattered (prox 0). A stable
	 * sort keyed on (coverage, proximity, original position) preserves the existing
	 * relevance/sales order for equal proximity, so ordering shifts only when the
	 * phrase signal genuinely differs.
	 *
	 * @since 1.2.0
	 * @param string $query   Cleaned query phrase.
	 * @param array  $results Ranked results from run().
	 * @return array Re-ranked results.
	 */
	private static function proximity_rerank( string $query, array $results ): array {
		if ( count( $results ) < 2 ) {
			return $results;
		}

		$words = array_values( array_filter( (array) preg_split( '/\s+/u', mb_strtolower( trim( $query ), 'UTF-8' ) ), 'strlen' ) );

		if ( count( $words ) < 2 ) {
			return $results;
		}

		// Bound the per-row title loads to the head slice; the tail keeps its SQL
		// relevance order (a phrase match ranks inside the head by coverage anyway).
		$tail    = array_slice( $results, self::REFINE_SCAN_CAP );
		$results = array_slice( $results, 0, self::REFINE_SCAN_CAP );

		$phrase = implode( ' ', $words );

		foreach ( $results as $i => $row ) {
			$title = mb_strtolower( wp_strip_all_tags( (string) get_the_title( (int) $row['object_id'] ) ), 'UTF-8' );
			$title = (string) preg_replace( '/\s+/u', ' ', $title );

			if ( false !== mb_strpos( $title, $phrase, 0, 'UTF-8' ) ) {
				$prox = 2;
			} elseif ( self::words_in_order( $title, $words ) ) {
				$prox = 1;
			} else {
				$prox = 0;
			}

			$results[ $i ]['proximity'] = $prox;
			$results[ $i ]['_pos']      = $i;
		}

		usort(
			$results,
			static function ( $a, $b ) {
				if ( $a['matched'] !== $b['matched'] ) {
					return $b['matched'] <=> $a['matched'];
				}

				if ( $a['proximity'] !== $b['proximity'] ) {
					return $b['proximity'] <=> $a['proximity'];
				}

				return $a['_pos'] <=> $b['_pos'];
			}
		);

		foreach ( $results as $i => $row ) {
			unset( $results[ $i ]['_pos'], $results[ $i ]['proximity'] );
		}

		return array_merge( $results, $tail );
	}

	/**
	 * Product-type re-rank. Within each coverage tier, promote a title whose FIRST
	 * word is what the shopper asked for over one that merely mentions it.
	 *
	 * Catalogs name the thing first and qualify it after: "Дисплей iPhone 13" is a
	 * screen, "Проклейка дисплея iPhone 13" is an adhesive for one. Both match the
	 * same words, so plain relevance can rank the accessory above the part — and
	 * usually does, because the accessory is the only place the shopper's own word
	 * appears verbatim, which makes that word rare and therefore heavy.
	 *
	 * Comparison is on stems from the coverage groups, so a synonym counts: a query
	 * for "дисплей" recognizes a title that opens with "LCD". Titles that open with
	 * a brand or an article number simply never earn the flag, and a catalog named
	 * that way keeps its existing order.
	 *
	 * @since 1.5.3
	 * @param array<int,string[]> $groups  Coverage groups behind the current result set.
	 * @param array               $results Ranked results from run().
	 * @return array Re-ranked results.
	 */
	private static function head_rerank( array $groups, array $results ): array {
		if ( count( $results ) < 2 ) {
			return $results;
		}

		$stems = array_flip( self::flatten_groups( $groups ) );

		if ( empty( $stems ) ) {
			return $results;
		}

		// Bound the per-row title loads the same way the proximity pass does; the
		// tail keeps its SQL relevance order.
		$tail    = array_slice( $results, self::REFINE_SCAN_CAP );
		$results = array_slice( $results, 0, self::REFINE_SCAN_CAP );

		foreach ( $results as $i => $row ) {
			$title = wp_strip_all_tags( (string) get_the_title( (int) $row['object_id'] ) );
			$head  = array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( $title ) ) );

			$results[ $i ]['_head'] = ( isset( $head[0] ) && isset( $stems[ $head[0] ] ) ) ? 1 : 0;
			$results[ $i ]['_pos']  = $i;
		}

		usort(
			$results,
			static function ( $a, $b ) {
				if ( (int) $a['matched'] !== (int) $b['matched'] ) {
					return (int) $b['matched'] <=> (int) $a['matched'];
				}

				if ( $a['_head'] !== $b['_head'] ) {
					return $b['_head'] <=> $a['_head'];
				}

				return $a['_pos'] <=> $b['_pos'];
			}
		);

		foreach ( $results as $i => $row ) {
			unset( $results[ $i ]['_head'], $results[ $i ]['_pos'] );
		}

		return array_merge( $results, $tail );
	}

	/**
	 * True when every word appears in $haystack in the given order (not necessarily
	 * adjacent). Multibyte-safe; O(title length).
	 *
	 * @since 1.2.0
	 * @param string   $haystack Lower-cased text to scan.
	 * @param string[] $words    Query words in order.
	 * @return bool
	 */
	private static function words_in_order( string $haystack, array $words ): bool {
		$offset = 0;

		foreach ( $words as $word ) {
			$pos = mb_strpos( $haystack, $word, $offset, 'UTF-8' );

			if ( false === $pos ) {
				return false;
			}

			$offset = $pos + mb_strlen( $word, 'UTF-8' );
		}

		return true;
	}

	/**
	 * Search the index.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @param array  $args  { Optional.
	 *     @type int      $limit      Max results (capped at MAX_LIMIT).
	 *     @type string   $strictness 'loose', 'balanced' (default) or 'strict'.
	 *     @type string[] $post_types Restrict to these types.
	 * }
	 * @return array<int,array{object_id:int,object_type:string,score:float}>
	 */
	public static function search( string $query, array $args = array() ): array {
		self::$correction = '';
		self::$rescue     = '';

		// A leading "-word" excludes results containing that word (Boolean NOT).
		list( $clean_query, $neg_terms ) = self::split_negatives( $query );

		$words = MVweb_SS_Tokenizer::tokenize_words( $clean_query );

		if ( empty( $words ) ) {
			return array();
		}

		$limit = isset( $args['limit'] ) ? (int) $args['limit'] : self::DEFAULT_LIMIT;
		$limit = max( 1, min( $limit, self::MAX_LIMIT ) );

		$strictness = isset( $args['strictness'] )
			? (string) $args['strictness']
			: (string) MVweb_SS_Settings::get( 'strictness', 'balanced' );

		$min_match = self::min_match( $strictness, MVweb_SS_Tokenizer::word_count( $clean_query ) );

		$types = isset( $args['post_types'] ) && is_array( $args['post_types'] ) && ! empty( $args['post_types'] )
			? array_values( $args['post_types'] )
			: MVweb_SS_Indexer::get_indexed_post_types();

		$term_ids = isset( $args['term_ids'] ) && is_array( $args['term_ids'] )
			? array_values( array_filter( array_map( 'intval', $args['term_ids'] ) ) )
			: array();

		$taxonomy = isset( $args['taxonomy'] ) ? (string) $args['taxonomy'] : '';

		// Self-learning click-boost keys on the raw query the shopper typed; the
		// same hash covers the layout-swap and fuzzy retries (clicks were logged
		// under that original wording). Empty unless the boost is enabled.
		$query_hash = MVweb_SS_Settings::get( 'click_boost', false ) ? MVweb_SS_Log::hash( $query ) : '';

		// Fold synonyms into the primary run so coverage-first ranking floats the
		// results that also match a synonym, while the strictness floor stays tied
		// to the number of original query words (a synonym does not raise the bar).
		// The trailing word is passed as a prefix so a synonym still fires while it
		// is being typed ("iphone 14 батаре" reaches the "аккумулятор" synonym).
		// Cross-script transliteration folds "samsung"↔"самсунг" so a query in one
		// script reaches products written in the other. Query-time only (never
		// emitted into the index), attached to the source word's coverage group.
		$translit = MVweb_SS_Settings::get( 'translit_cross_script', true );

		$partial = MVweb_SS_Settings::get( 'synonym_prefix', true ) ? self::trailing_stem( $clean_query ) : '';
		$groups  = self::expand_groups( $words, $partial, $translit );

		// Search-as-you-type (P1.5): in the live dropdown, fold index terms that start
		// with the trailing word into its coverage group, so a half-typed word ("самс")
		// already reaches "самсунг" before the whole word is stemmed. Gated to a minimum
		// length and a capped term count (a 1-2 char prefix would blow up the candidate
		// pool) and attached to a single group so coverage stays honest. Dropdown only —
		// on the results page the trailing word is complete, so prefix noise is unwanted.
		if ( ! empty( $args['prefix'] ) && MVweb_SS_Settings::get( 'prefix_last_word', true ) ) {
			self::attach_prefix_terms( $groups, $words, $translit );
		}

		$results = self::run( $groups, $types, $min_match, $limit, $term_ids, $taxonomy, $neg_terms, $query_hash );

		// Groups behind the current result set: a layout-swap or fuzzy rescue below
		// replaces the results, and the product-type re-rank must compare against
		// the stems that actually produced them.
		$rank_groups = $groups;

		$threshold = (int) apply_filters( 'mvweb_ss_fuzzy_threshold', self::FUZZY_THRESHOLD );

		// Aggressive typo tolerance (P2.5, default-off): run the layout-swap and
		// fuzzy stages on every query, not only when the exact pass came up short.
		// Each stage still adopts its result only when it finds strictly more, so
		// a clean result set is never replaced by a noisier fuzzy one. Off by
		// default — it widens the candidate scan, so enable and compare on the
		// catalog. First-letter typos remain the job of the opt-in deletes table.
		$aggressive = (bool) MVweb_SS_Settings::get( 'fuzzy_aggressive', false );

		if ( MVweb_SS_Settings::get( 'fuzzy', true ) && ( $aggressive || count( $results ) < $threshold ) ) {
			// Wrong keyboard-layout recovery: a query typed in the other layout
			// ("ghbdtn" instead of "привет") is swapped and retried; adopted only
			// when it actually finds more than the original.
			$swapped = self::swap_layout( $clean_query );

			if ( '' !== $swapped ) {
				$swap_words = MVweb_SS_Tokenizer::tokenize_words( $swapped );

				if ( ! empty( $swap_words ) ) {
					$swap_match   = self::min_match( $strictness, MVweb_SS_Tokenizer::word_count( $swapped ) );
					$swap_groups  = self::expand_groups( $swap_words, '', $translit );
					$swap_results = self::run( $swap_groups, $types, $swap_match, $limit, $term_ids, $taxonomy, $neg_terms, $query_hash );

					if ( count( $swap_results ) > count( $results ) ) {
						$results          = $swap_results;
						$rank_groups      = $swap_groups;
						self::$correction = trim( $swapped );
						self::$rescue     = 'layout';
					}
				}
			}

			// Typo tolerance: still scarce after the layout swap, widen with fuzzy candidates.
			if ( $aggressive || count( $results ) < $threshold ) {
				$fuzzy_groups = self::groups_with_fuzzy( $words );

				if ( self::group_term_count( $fuzzy_groups ) > self::group_term_count( $words ) ) {
					$fuzzy = self::run( $fuzzy_groups, $types, $min_match, $limit, $term_ids, $taxonomy, $neg_terms, $query_hash );

					if ( count( $fuzzy ) > count( $results ) ) {
						$results          = $fuzzy;
						$rank_groups      = $fuzzy_groups;
						self::$correction = self::derive_correction( $clean_query, $fuzzy );
						self::$rescue     = 'typo';
					}
				}
			}
		}

		// Zero-result ladder (P1.7): a strict pass (AND across words) that found
		// nothing is retried once at the loosest floor (OR) so a partial match
		// surfaces instead of a dead end. Fires only when the strict pass was empty.
		if ( empty( $results ) && $min_match > 1 ) {
			$results = self::run( $groups, $types, 1, $limit, $term_ids, $taxonomy, $neg_terms, $query_hash );
		}

		// Phrase-proximity re-rank (P1.3, opt-in): within each coverage tier, float
		// titles that contain the query as a phrase / in order above scattered-word
		// titles. Runs before the exact boost so an exact title still wins the top.
		if ( MVweb_SS_Settings::get( 'boost_proximity', false ) ) {
			$results = self::proximity_rerank( $clean_query, $results );
		}

		// Product-type re-rank (opt-in): within each coverage tier, float the
		// part the shopper named above accessories that merely mention it. Runs
		// after proximity so the phrase signal orders the ties inside each tier.
		if ( MVweb_SS_Settings::get( 'boost_head', false ) ) {
			$results = self::head_rerank( $rank_groups, $results );
		}

		// Exact-match boost: a result whose title or SKU is exactly the query jumps
		// to the top, above a merely high-scoring partial match (P0.3).
		$results = self::promote_exact( $clean_query, $results );

		$pins = MVweb_SS_Settings::pins_for( $query );

		if ( ! empty( $pins ) ) {
			$results = self::apply_pins( $pins, $types, $results, $limit, $term_ids, $taxonomy );
		}

		/**
		 * Filter the final ranked results (used for language filtering and integrations).
		 *
		 * @since 1.0.0
		 * @param array  $results Ranked results.
		 * @param string $query   Raw user query.
		 * @param array  $types   Post types searched.
		 */
		return (array) apply_filters( 'mvweb_ss_results', $results, $query, $types );
	}

	/**
	 * Expand query terms into coverage groups: each original word seeds a group,
	 * and its synonyms, transliterations and (later) fuzzy variants join that same
	 * group. Grouping is what keeps coverage honest — a word and its synonym count
	 * as one covered concept, not two, so "батарея"+"аккумулятор" no longer
	 * out-covers a genuine two-word match (P0.2).
	 *
	 * A synonym rule fires when ALL of its pattern stems are present among the
	 * query terms (order-independent); its additions attach to the group of the
	 * pattern's anchor word. The trailing, still-being-typed word may match a
	 * pattern stem by prefix so a synonym fires before the word is finished.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $words    Query terms grouped by the word they came from.
	 * @param string              $partial  Stem of the still-being-typed trailing word, or ''.
	 * @param bool                $translit Whether to add cross-script transliterations.
	 * @return array<int,string[]> Coverage groups (each a list of terms).
	 */
	private static function expand_groups( array $words, string $partial = '', bool $translit = false ): array {
		// Memoize per request: expand_groups() is called on the primary run, the
		// layout-swap retry, the fuzzy retry and in term_match_counts(), often with
		// the same terms. The key must include $partial and $translit — the fuzzy
		// path calls with $partial='' and $translit=false regardless of the setting,
		// so a terms-only key would hand back the wrong (cross-script) expansion.
		static $memo = array();

		$terms = self::flatten_groups( $words );

		$memo_key = md5( implode( "\0", $terms ) . '|' . $partial . '|' . ( $translit ? '1' : '0' ) );

		if ( isset( $memo[ $memo_key ] ) ) {
			return $memo[ $memo_key ];
		}

		$groups = array();
		$index  = array();

		// One written word = one coverage group, however many index terms it split
		// into. "a515" contributes both "a515" and "515" to the same group, so the
		// glued code stays one concept instead of two the shopper never typed.
		foreach ( $words as $word ) {
			$gi = count( $groups );

			foreach ( $word as $term ) {
				if ( isset( $index[ $term ] ) ) {
					continue;
				}

				if ( ! isset( $groups[ $gi ] ) ) {
					$groups[ $gi ] = array();
				}

				$index[ $term ]  = $gi;
				$groups[ $gi ][] = $term;
			}
		}

		if ( empty( $groups ) ) {
			$memo[ $memo_key ] = array();
			return array();
		}

		if ( $translit ) {
			foreach ( $terms as $term ) {
				foreach ( self::transliterations( $term ) as $variant ) {
					self::attach( $groups, $index, $index[ $term ], $variant );
				}
			}
		}

		$rules = MVweb_SS_Settings::synonym_map();

		if ( ! empty( $rules ) ) {
			$term_set = array_flip( $terms );

			foreach ( $rules as $rule ) {
				$used_prefix = false;
				$anchor      = null;

				foreach ( $rule['pattern'] as $stem ) {
					$stem = (string) $stem;

					if ( isset( $term_set[ $stem ] ) ) {
						if ( null === $anchor ) {
							$anchor = $stem;
						}
						continue;
					}

					if ( '' !== $partial && ! $used_prefix && 0 === mb_strpos( $stem, $partial, 0, 'UTF-8' ) ) {
						$used_prefix = true;

						if ( null === $anchor && isset( $index[ $partial ] ) ) {
							$anchor = $partial;
						}

						continue;
					}

					continue 2;
				}

				if ( null === $anchor || ! isset( $index[ $anchor ] ) ) {
					$anchor = $terms[0];
				}

				foreach ( $rule['add'] as $add ) {
					self::attach( $groups, $index, $index[ $anchor ], (string) $add );
				}
			}
		}

		$memo[ $memo_key ] = $groups;

		return $groups;
	}

	/**
	 * Attach a term to an existing coverage group unless it is already placed.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups Coverage groups (by reference).
	 * @param array<string,int>   $index  term => group index (by reference).
	 * @param int                 $gi     Target group index.
	 * @param string              $term   Term to attach.
	 * @return void
	 */
	private static function attach( array &$groups, array &$index, int $gi, string $term ): void {
		if ( '' === $term || isset( $index[ $term ] ) ) {
			return;
		}

		$index[ $term ]  = $gi;
		$groups[ $gi ][] = $term;
	}

	/**
	 * Attach index terms that start with the trailing query word to that word's
	 * coverage group (P1.5 search-as-you-type). The trailing word is the last of
	 * $terms; its group gets every stored term matching "trailing%" (and the same
	 * for the trailing word's transliteration), capped and length-gated. Because
	 * the additions join one existing group, they lift matching products without
	 * inflating coverage — exactly like a synonym.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups   Coverage groups (by reference).
	 * @param array<int,string[]> $words    Query terms grouped by word (order preserved).
	 * @param bool                $translit Whether to prefix-match the transliteration too.
	 * @return void
	 */
	private static function attach_prefix_terms( array &$groups, array $words, bool $translit ): void {
		if ( empty( $words ) ) {
			return;
		}

		// Anchor on the trailing word itself, not on the last term it split into:
		// a model code ("a515") ends on its bare number, and prefixing that pulls
		// unrelated numbers ("51549788") while never reaching "a515f".
		$last = (array) end( $words );

		$anchor = (string) reset( $last );

		if ( mb_strlen( $anchor, 'UTF-8' ) < self::PREFIX_MIN_LEN ) {
			return;
		}

		$gi = null;

		foreach ( $groups as $i => $group ) {
			if ( in_array( $anchor, $group, true ) ) {
				$gi = $i;
				break;
			}
		}

		if ( null === $gi ) {
			return;
		}

		$placed = array();
		foreach ( $groups as $group ) {
			foreach ( $group as $term ) {
				$placed[ $term ] = true;
			}
		}

		foreach ( self::prefix_terms( $anchor, $translit ) as $term ) {
			if ( isset( $placed[ $term ] ) ) {
				continue;
			}

			$groups[ $gi ][] = $term;
			$placed[ $term ] = true;
		}
	}

	/**
	 * Distinct index terms starting with the given stem (and, optionally, its
	 * transliteration), capped per prefix. The BTREE index on `term` makes the
	 * `LIKE 'stem%'` lookup a range scan; the length gate and cap keep a broad
	 * prefix from pulling a huge vocabulary slice.
	 *
	 * @since 1.2.0
	 * @param string $stem     Trailing word stem (already length-checked by caller).
	 * @param bool   $translit Whether to also prefix-match the transliteration.
	 * @return string[] Matching index terms (may be empty).
	 */
	private static function prefix_terms( string $stem, bool $translit ): array {
		global $wpdb;

		// The dropdown calls search() once per post type in scope; the prefix lookup
		// depends only on the stem, so memoize it per request to avoid repeating the
		// same LIKE scans for each type.
		static $memo = array();

		$cache_key = $stem . '|' . ( $translit ? '1' : '0' );

		if ( isset( $memo[ $cache_key ] ) ) {
			return $memo[ $cache_key ];
		}

		$prefixes = array( $stem );

		if ( $translit ) {
			foreach ( self::transliterations( $stem ) as $variant ) {
				$prefixes[] = $variant;
			}
		}

		// A model code transliterates to its bare number ("a515" → "515"), and
		// prefixing that pulls every unrelated code that happens to start with the
		// same digits. Digits-only prefixes are kept only when the shopper is in
		// fact typing a number ("150" reaching "150мм").
		$numeric = ctype_digit( $stem );

		$prefixes = array_values(
			array_filter(
				array_unique( $prefixes ),
				static function ( $prefix ) use ( $numeric ) {
					if ( ! $numeric && ctype_digit( (string) $prefix ) ) {
						return false;
					}

					return mb_strlen( (string) $prefix, 'UTF-8' ) >= self::PREFIX_MIN_LEN;
				}
			)
		);

		if ( empty( $prefixes ) ) {
			$memo[ $cache_key ] = array();
			return array();
		}

		$table = MVweb_SS_Schema::table_name();
		$out   = array();

		foreach ( $prefixes as $prefix ) {
			$like = $wpdb->esc_like( (string) $prefix ) . '%';
			$sql  = "SELECT DISTINCT term FROM `$table` WHERE term LIKE %s LIMIT %d";
			$rows = $wpdb->get_col( $wpdb->prepare( $sql, $like, self::PREFIX_CAP ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery

			foreach ( (array) $rows as $term ) {
				$out[] = (string) $term;
			}
		}

		$memo[ $cache_key ] = array_values( array_unique( $out ) );

		return $memo[ $cache_key ];
	}

	/**
	 * Build coverage groups where each fuzzy candidate joins its source term's
	 * group, so typo variants never inflate coverage either.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $words Query terms grouped by word.
	 * @return array<int,string[]>
	 */
	private static function groups_with_fuzzy( array $words ): array {
		$groups = self::expand_groups( $words );
		$terms  = self::flatten_groups( $words );

		$index = array();
		foreach ( $groups as $gi => $group ) {
			foreach ( $group as $term ) {
				$index[ $term ] = $gi;
			}
		}

		foreach ( $terms as $term ) {
			if ( mb_strlen( $term, 'UTF-8' ) < MVweb_SS_Fuzzy::MIN_LENGTH || ! isset( $index[ $term ] ) ) {
				continue;
			}

			foreach ( MVweb_SS_Fuzzy::candidates( $term ) as $candidate ) {
				self::attach( $groups, $index, $index[ $term ], (string) $candidate );
			}
		}

		return $groups;
	}

	/**
	 * Flatten coverage groups to a unique term list (WHERE i.term IN order).
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups Coverage groups.
	 * @return string[]
	 */
	private static function flatten_groups( array $groups ): array {
		$out = array();

		foreach ( $groups as $group ) {
			foreach ( $group as $term ) {
				$out[] = (string) $term;
			}
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Total number of distinct terms across all coverage groups.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups Coverage groups.
	 * @return int
	 */
	private static function group_term_count( array $groups ): int {
		return count( self::flatten_groups( $groups ) );
	}

	/**
	 * Cross-script phonetic variants of a single-script term, stemmed the same way
	 * the index stored its terms. A Cyrillic word yields its Latin spelling and a
	 * Latin word its Cyrillic one ("samsung"↔"самсунг"), so a query reaches
	 * products written in the other script. Best-effort — exact brand spellings
	 * the phonetic map misses ("айфон", "сяоми") belong in the synonym dictionary.
	 *
	 * @since 1.2.0
	 * @param string $term Query term (already stemmed).
	 * @return string[] Stemmed variant terms (may be empty).
	 */
	private static function transliterations( string $term ): array {
		if ( mb_strlen( $term, 'UTF-8' ) < 3 ) {
			return array();
		}

		$has_cyr = (bool) preg_match( '/\p{Cyrillic}/u', $term );
		$has_lat = (bool) preg_match( '/[a-z]/', $term );

		if ( $has_cyr === $has_lat ) {
			return array();
		}

		$raw = $has_cyr ? self::cyr_to_lat( $term ) : self::lat_to_cyr( $term );

		if ( '' === $raw || $raw === $term ) {
			return array();
		}

		return array_values(
			array_filter(
				array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( $raw ) ) ),
				static function ( $variant ) use ( $term ) {
					return '' !== $variant && $variant !== $term;
				}
			)
		);
	}

	/**
	 * Transliterate Cyrillic to Latin (phonetic, GOST-ish digraphs).
	 *
	 * @since 1.2.0
	 * @param string $term Cyrillic term.
	 * @return string
	 */
	private static function cyr_to_lat( string $term ): string {
		static $map = array(
			'а' => 'a',
			'б' => 'b',
			'в' => 'v',
			'г' => 'g',
			'д' => 'd',
			'е' => 'e',
			'ж' => 'zh',
			'з' => 'z',
			'и' => 'i',
			'й' => 'y',
			'к' => 'k',
			'л' => 'l',
			'м' => 'm',
			'н' => 'n',
			'о' => 'o',
			'п' => 'p',
			'р' => 'r',
			'с' => 's',
			'т' => 't',
			'у' => 'u',
			'ф' => 'f',
			'х' => 'kh',
			'ц' => 'ts',
			'ч' => 'ch',
			'ш' => 'sh',
			'щ' => 'shch',
			'ъ' => '',
			'ы' => 'y',
			'ь' => '',
			'э' => 'e',
			'ю' => 'yu',
			'я' => 'ya',
		);

		return strtr( $term, $map );
	}

	/**
	 * Transliterate Latin to Cyrillic (phonetic). strtr() replaces the longest key
	 * first, so digraphs (sh, ch, …) win over their single letters.
	 *
	 * @since 1.2.0
	 * @param string $term Latin term.
	 * @return string
	 */
	private static function lat_to_cyr( string $term ): string {
		static $map = array(
			'shch' => 'щ',
			'sch'  => 'щ',
			'sh'   => 'ш',
			'ch'   => 'ч',
			'zh'   => 'ж',
			'kh'   => 'х',
			'ts'   => 'ц',
			'yu'   => 'ю',
			'ya'   => 'я',
			'yo'   => 'е',
			'a'    => 'а',
			'b'    => 'б',
			'c'    => 'к',
			'd'    => 'д',
			'e'    => 'е',
			'f'    => 'ф',
			'g'    => 'г',
			'h'    => 'х',
			'i'    => 'и',
			'j'    => 'дж',
			'k'    => 'к',
			'l'    => 'л',
			'm'    => 'м',
			'n'    => 'н',
			'o'    => 'о',
			'p'    => 'п',
			'q'    => 'к',
			'r'    => 'р',
			's'    => 'с',
			't'    => 'т',
			'u'    => 'у',
			'v'    => 'в',
			'w'    => 'в',
			'x'    => 'кс',
			'y'    => 'й',
			'z'    => 'з',
		);

		return strtr( $term, $map );
	}

	/**
	 * Stem of the last, still-being-typed word of a query (for prefix synonyms).
	 *
	 * @since 1.2.0
	 * @param string $clean_query Query with negations removed.
	 * @return string Stem of the trailing word, or '' when too short/absent.
	 */
	private static function trailing_stem( string $clean_query ): string {
		$words = preg_split( '/\s+/u', trim( $clean_query ) );

		if ( empty( $words ) ) {
			return '';
		}

		$stems = array_keys( MVweb_SS_Tokenizer::tokenize( (string) end( $words ) ) );

		if ( empty( $stems ) ) {
			return '';
		}

		$last = (string) end( $stems );

		return mb_strlen( $last, 'UTF-8' ) >= 3 ? $last : '';
	}

	/**
	 * Prepend admin-pinned, still-public results to the top.
	 *
	 * @since 1.0.0
	 * @param int[]    $pin_ids  Pinned object IDs (in order).
	 * @param string[] $types    Post types in scope for this search.
	 * @param array    $results  Ranked results.
	 * @param int      $limit    Max rows.
	 * @param int[]    $term_ids Active category term IDs, or empty.
	 * @param string   $taxonomy Taxonomy of the term IDs.
	 * @return array
	 */
	private static function apply_pins( array $pin_ids, array $types, array $results, int $limit, array $term_ids = array(), string $taxonomy = '' ): array {
		$exclude = MVweb_SS_Settings::excluded_ids();
		$scoped  = ! empty( $term_ids ) && '' !== $taxonomy;
		$pinned  = array();

		foreach ( $pin_ids as $id ) {
			if ( in_array( (int) $id, $exclude, true ) ) {
				continue;
			}

			if ( $scoped && ! has_term( $term_ids, $taxonomy, (int) $id ) ) {
				continue;
			}

			$post = get_post( $id );

			if ( $post instanceof WP_Post
				&& 'publish' === $post->post_status
				&& '' === (string) $post->post_password
				&& in_array( $post->post_type, $types, true ) ) {
				$pinned[] = array(
					'object_id'   => (int) $id,
					'object_type' => $post->post_type,
					'score'       => (float) PHP_INT_MAX,
				);
			}
		}

		if ( empty( $pinned ) ) {
			return $results;
		}

		$ids  = array_column( $pinned, 'object_id' );
		$rest = array_filter(
			$results,
			static function ( $row ) use ( $ids ) {
				return ! in_array( $row['object_id'], $ids, true );
			}
		);

		return array_slice( array_merge( $pinned, array_values( $rest ) ), 0, $limit );
	}

	/**
	 * Move results whose title or SKU is exactly the query to the very top.
	 *
	 * An exact title/SKU match always carries full coverage, so promoting it never
	 * lifts a lower-coverage item above a higher-coverage one — it only settles
	 * ties in favour of the literal match the shopper almost certainly wants.
	 *
	 * @since 1.2.0
	 * @param string $query   Cleaned query.
	 * @param array  $results Ranked results.
	 * @return array
	 */
	private static function promote_exact( string $query, array $results ): array {
		$boost = (float) MVweb_SS_Settings::get( 'exact_match_boost', 5.0 );

		if ( $boost <= 1 || empty( $results ) ) {
			return $results;
		}

		$key = self::normalize_exact( $query );

		if ( '' === $key ) {
			return $results;
		}

		// Scan only the head slice: is_exact_match() loads a title (and product for
		// the SKU check) per row, so an unbounded scan would multiply loads on a
		// large results-page pool. An exact title/SKU match carries full coverage
		// and always ranks inside the head, so nothing real is lost.
		$scan = min( count( $results ), self::REFINE_SCAN_CAP );

		$exact = array();
		$rest  = array();

		foreach ( $results as $i => $row ) {
			if ( $i < $scan && self::is_exact_match( (int) $row['object_id'], $key ) ) {
				$exact[] = $row;
			} else {
				$rest[] = $row;
			}
		}

		return empty( $exact ) ? $results : array_merge( $exact, $rest );
	}

	/**
	 * Whether an object's title or (product) SKU equals the normalized query.
	 *
	 * @since 1.2.0
	 * @param int    $object_id Object ID.
	 * @param string $key       Normalized query.
	 * @return bool
	 */
	private static function is_exact_match( int $object_id, string $key ): bool {
		if ( self::normalize_exact( (string) get_the_title( $object_id ) ) === $key ) {
			return true;
		}

		if ( function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( $object_id );

			if ( $product && '' !== $product->get_sku() && self::normalize_exact( (string) $product->get_sku() ) === $key ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Normalize a string for exact comparison: lowercase, ё→е, alphanumerics only,
	 * single-spaced.
	 *
	 * @since 1.2.0
	 * @param string $text Input.
	 * @return string
	 */
	private static function normalize_exact( string $text ): string {
		$text = str_replace( 'ё', 'е', mb_strtolower( trim( $text ), 'UTF-8' ) );
		$text = (string) preg_replace( '/[^\p{L}\p{N}]+/u', ' ', $text );

		return trim( (string) preg_replace( '/\s+/u', ' ', $text ) );
	}

	/**
	 * Split a raw query into its positive text and negated stems.
	 *
	 * A whitespace-delimited word starting with "-" ("iphone -чехол") is a
	 * Boolean NOT: the word is removed from the searchable text and its stems
	 * are returned so the ranking query can exclude any object carrying them.
	 * A "-" inside a word ("телефон-раскладушка") is a compound, not a negation.
	 *
	 * @since 1.1.0
	 * @param string $query Raw user query.
	 * @return array{0:string,1:string[]} Cleaned query, then negated stems.
	 */
	public static function split_negatives( string $query ): array {
		$neg_words = array();

		$clean = (string) preg_replace_callback(
			'/(?:^|\s)-(\S+)/u',
			static function ( $m ) use ( &$neg_words ) {
				$neg_words[] = $m[1];
				return ' ';
			},
			$query
		);

		$neg_terms = array();

		foreach ( $neg_words as $word ) {
			foreach ( array_keys( MVweb_SS_Tokenizer::tokenize( $word ) ) as $stem ) {
				$neg_terms[] = (string) $stem;
			}
		}

		return array( trim( $clean ), array_values( array_unique( $neg_terms ) ) );
	}

	/**
	 * Re-map a query typed in the wrong keyboard layout to the other one.
	 *
	 * Swaps characters between the Russian ЙЦУКЕН and the English QWERTY layouts
	 * by physical key, so "ghbdtn" becomes "привет" (and the reverse). Returns an
	 * empty string when nothing changed, letting the caller skip a pointless
	 * re-search. The slash and backtick keys are left out (their letters ./ё
	 * collide or are stemmer-normalized), so the map stays unambiguous.
	 *
	 * @since 1.1.0
	 * @param string $query Raw user query.
	 * @return string Swapped query, or '' when unchanged.
	 */
	private static function swap_layout( string $query ): string {
		$lower = mb_strtolower( trim( $query ), 'UTF-8' );

		if ( '' === $lower ) {
			return '';
		}

		$swapped = strtr( $lower, self::layout_map() );

		return $swapped === $lower ? '' : $swapped;
	}

	/**
	 * Bidirectional QWERTY↔ЙЦУКЕН character map keyed by physical key.
	 *
	 * @since 1.1.0
	 * @return array<string,string>
	 */
	private static function layout_map(): array {
		static $map = null;

		if ( null !== $map ) {
			return $map;
		}

		$en = str_split( 'qwertyuiop[]asdfghjkl;\'zxcvbnm,.' );
		$ru = mb_str_split( 'йцукенгшщзхъфывапролджэячсмитьбю', 1, 'UTF-8' );

		$map = array();

		foreach ( $en as $i => $ch ) {
			$map[ $ch ]       = $ru[ $i ];
			$map[ $ru[ $i ] ] = $ch;
		}

		return $map;
	}

	/**
	 * Build a human-readable "did you mean" phrase from the top fuzzy match.
	 *
	 * Uses real words from the best result's title (not stemmed index terms),
	 * replacing each raw query word with the closest title word within edit
	 * distance 2. Returns an empty string when nothing changed.
	 *
	 * @since 1.0.0
	 * @param string $query   Raw user query.
	 * @param array  $results Fuzzy result set (best first).
	 * @return string
	 */
	private static function derive_correction( string $query, array $results ): string {
		if ( empty( $results ) ) {
			return '';
		}

		$raw_words = preg_split( '/\s+/u', trim( $query ), -1, PREG_SPLIT_NO_EMPTY );

		if ( empty( $raw_words ) ) {
			return '';
		}

		$title       = wp_strip_all_tags( (string) get_the_title( (int) $results[0]['object_id'] ) );
		$title_words = preg_split( '/\s+/u', $title, -1, PREG_SPLIT_NO_EMPTY );

		if ( empty( $title_words ) ) {
			return '';
		}

		$out = array();

		foreach ( (array) $raw_words as $word ) {
			$word_lc = mb_strtolower( (string) $word, 'UTF-8' );
			$len     = mb_strlen( $word_lc, 'UTF-8' );
			$best    = (string) $word;
			$best_d  = PHP_INT_MAX;

			foreach ( (array) $title_words as $candidate ) {
				$candidate = (string) $candidate;

				if ( abs( mb_strlen( $candidate, 'UTF-8' ) - $len ) > 2 ) {
					continue;
				}

				$distance = MVweb_SS_Fuzzy::distance( $word_lc, mb_strtolower( $candidate, 'UTF-8' ) );

				if ( $distance < $best_d ) {
					$best_d = $distance;
					$best   = $candidate;
				}
			}

			$out[] = ( $best_d > 0 && $best_d <= 2 ) ? $best : (string) $word;
		}

		$corrected = implode( ' ', $out );
		$original  = (string) preg_replace( '/\s+/u', ' ', trim( $query ) );

		return mb_strtolower( $corrected, 'UTF-8' ) === mb_strtolower( $original, 'UTF-8' ) ? '' : $corrected;
	}

	/**
	 * Run the ranking query for a set of coverage groups.
	 *
	 * Each group is one covered concept (a word plus its synonyms/transliterations/
	 * fuzzy variants); coverage counts distinct groups, not raw terms, so a word and
	 * its synonym never double-count (P0.2). When enabled, each term's contribution
	 * is scaled by its inverse document frequency, so a common word pulls far less
	 * weight than a rare, discriminating one (P0.1).
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups    Non-empty coverage groups.
	 * @param string[]            $types     Post types to search.
	 * @param int                 $min_match Minimum number of distinct groups an object must match (1 = OR, N = AND).
	 * @param int                 $limit     Max rows.
	 * @param int[]               $term_ids  Restrict to objects in these taxonomy term IDs.
	 * @param string              $taxonomy  Taxonomy the term IDs belong to (required with $term_ids).
	 * @param string[]            $exclude_terms Stems whose presence disqualifies an object (Boolean NOT).
	 * @param string              $query_hash    Raw-query hash for the self-learning click-boost ('' = off).
	 * @return array<int,array{object_id:int,object_type:string,score:float}>
	 */
	private static function run( array $groups, array $types, int $min_match, int $limit, array $term_ids = array(), string $taxonomy = '', array $exclude_terms = array(), string $query_hash = '' ): array {
		global $wpdb;

		$terms = self::flatten_groups( $groups );

		if ( empty( $terms ) || empty( $types ) ) {
			return array();
		}

		$pml_joined = false;

		$table = MVweb_SS_Schema::table_name();

		$coverage = self::coverage_case_sql( $groups );

		// Field-length normalization (P1.2, default-off): divide each match's
		// contribution by a BM25 fieldnorm so a term buried in a long field (a
		// smartphone's spec description) counts far less than the same term as a
		// short part title. Chosen before the IDF wrap so IDF multiplies the
		// normalized base; the doclen JOIN is appended after, so it composes with
		// the IDF join instead of overwriting it.
		$use_doclen = (bool) MVweb_SS_Settings::get( 'ranking_doclen', true );

		$use_idf   = (bool) MVweb_SS_Settings::get( 'ranking_use_idf', true );
		$idf_join  = '';
		$score_sum = $use_doclen ? self::weight_case_doclen() : self::weight_case();

		if ( $use_idf ) {
			$terms_table = MVweb_SS_Schema::terms_table_name();
			$n           = self::doc_count();
			$idf_join    = "LEFT JOIN `$terms_table` t ON t.term = i.term";
			$idf         = "LN( 1 + ( $n - LEAST( COALESCE( t.df, 0 ), $n ) + 0.5 ) / ( COALESCE( t.df, 0 ) + 0.5 ) )";
			$score_sum   = '( ' . $idf . ' ) * ( ' . $score_sum . ' )';
		}

		if ( $use_doclen ) {
			$doclen_table = MVweb_SS_Schema::doclen_table_name();
			$idf_join    .= " LEFT JOIN `$doclen_table` dl ON dl.object_id = i.object_id AND dl.source = i.source";
		}

		$in_terms = implode( ',', array_fill( 0, count( $terms ), '%s' ) );
		$in_types = implode( ',', array_fill( 0, count( $types ), '%s' ) );

		$tax_sql   = '';
		$tax_valid = ! empty( $term_ids ) && '' !== $taxonomy;

		if ( $tax_valid ) {
			$in_tids = implode( ',', array_fill( 0, count( $term_ids ), '%d' ) );
			$tax_sql = "AND i.object_id IN (
				SELECT tr.object_id FROM {$wpdb->term_relationships} tr
				INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
				WHERE tt.taxonomy = %s AND tt.term_id IN ($in_tids)
			)";
		}

		$stock        = self::stock_mode();
		$stock_active = ( 'show' !== $stock ) && class_exists( 'WooCommerce' );

		$join         = '';
		$stock_select = '';
		$order_prefix = '';
		$having_parts = array();

		if ( $min_match > 1 ) {
			$having_parts[] = 'matched >= %d';
		}

		if ( $stock_active ) {
			$join         = "LEFT JOIN {$wpdb->postmeta} sm ON sm.post_id = i.object_id AND sm.meta_key = '_stock_status'";
			$stock_select = ', MAX( CASE WHEN sm.meta_value = \'outofstock\' THEN 1 ELSE 0 END ) AS out_of_stock';

			if ( 'hide' === $stock ) {
				$having_parts[] = 'out_of_stock = 0';
			} else {
				$order_prefix = 'out_of_stock ASC, ';
			}
		}

		$having = empty( $having_parts ) ? '' : 'HAVING ' . implode( ' AND ', $having_parts );

		$exclude  = MVweb_SS_Settings::excluded_ids();
		$excl_sql = '';

		if ( ! empty( $exclude ) ) {
			$in_excl  = implode( ',', array_fill( 0, count( $exclude ), '%d' ) );
			$excl_sql = "AND i.object_id NOT IN ($in_excl)";
		}

		$neg_sql = '';

		if ( ! empty( $exclude_terms ) ) {
			$in_neg  = implode( ',', array_fill( 0, count( $exclude_terms ), '%s' ) );
			$neg_sql = "AND i.object_id NOT IN ( SELECT object_id FROM `$table` WHERE term IN ($in_neg) )";
		}

		// Self-learning click-boost: multiply the score by a log-damped, capped
		// factor of how often this result was clicked for this exact query. The
		// factor is 1.0 with no clicks, so it never crosses the coverage tier and
		// never reorders cold-start catalogs.
		// Ranking multipliers are applied in ORDER BY as raw expressions, never via
		// the SUM() alias: MySQL rejects an aggregate alias (`score`) used inside any
		// ORDER BY arithmetic, but raw aggregate functions (SUM, MAX) are allowed
		// there. So the ORDER BY repeats the score expression and multiplies the
		// capped click/bestseller factors onto it directly.
		$boost_join = '';
		$order_expr = 'SUM( ' . $score_sum . ' )';

		if ( '' !== $query_hash ) {
			$clicks_table = MVweb_SS_Schema::clicks_table_name();
			$strength     = (int) MVweb_SS_Settings::get( 'click_boost_strength', 30 );
			$alpha        = number_format( max( 0, min( 100, $strength ) ) / 100, 3, '.', '' );
			$cap          = '2.0';

			$boost_join  = "LEFT JOIN `$clicks_table` cb ON cb.object_id = i.object_id AND cb.query_hash = %s";
			$order_expr .= " * ( 1 + LEAST( $alpha * LN( 1 + MAX( COALESCE( cb.clicks, 0 ) ) ), $cap ) )";
		}

		// Bestseller signal: a log-damped, capped multiplier on total_sales pulled
		// straight from wc_product_meta_lookup (no aggregation). A cold product
		// scores ×1, so this stays strictly below the coverage tier and never
		// reshuffles a catalog with no sales history. Non-products have no lookup
		// row, so their factor is ×1 too. All literals inline — no placeholders.
		$pop_strength = (int) MVweb_SS_Settings::get( 'boost_popularity', 20 );

		if ( $pop_strength > 0 && class_exists( 'WooCommerce' ) ) {
			$beta    = number_format( max( 0, min( 100, $pop_strength ) ) / 100, 3, '.', '' );
			$pop_cap = '1.0';

			if ( ! $pml_joined ) {
				$lookup     = $wpdb->prefix . 'wc_product_meta_lookup';
				$idf_join  .= " LEFT JOIN `$lookup` pml ON pml.product_id = i.object_id";
				$pml_joined = true;
			}

			$order_expr .= " * ( 1 + LEAST( $beta * LN( 1 + MAX( COALESCE( pml.total_sales, 0 ) ) ), $pop_cap ) )";
		}

		// Sort on the relevance figure rounded to six decimals, not the raw sum. The
		// score is a SUM() of floating-point IDF terms, and floating-point addition is
		// not associative: the same object summed in a different row order comes out
		// different in the last bits (measured spread: 9e-16 on scores around 60). That
		// noise is invisible to a reader but decides the ORDER BY, so two products with
		// an equal score could swap places — and swap in or out of the LIMIT window —
		// whenever the query plan or the row order changed. Rounding well below any
		// meaningful score difference makes the tie-break tail below (sales, rating,
		// object_id) the thing that actually decides ties, which is what it is for.
		$boost_order = 'ROUND( ' . $order_expr . ', 6 ) DESC';

		// Deterministic tie-break tail (P1.6): when two rows share the same coverage
		// and the same boosted relevance, order them by a stable cascade — sales,
		// then rating — so one query always yields one ordering (matters for QA and
		// support). Products only; raw aggregates are allowed in ORDER BY. The final
		// i.object_id DESC stays the always-unique key.
		$tie_break = '';

		if ( class_exists( 'WooCommerce' ) ) {
			if ( ! $pml_joined ) {
				$lookup     = $wpdb->prefix . 'wc_product_meta_lookup';
				$idf_join  .= " LEFT JOIN `$lookup` pml ON pml.product_id = i.object_id";
				$pml_joined = true;
			}

			$tie_break = ', MAX( COALESCE( pml.total_sales, 0 ) ) DESC, MAX( COALESCE( pml.average_rating, 0 ) ) DESC';
		}

		// The publish/visibility filter is a join, not an `object_id IN (SELECT ...)`
		// subquery: MySQL 5.7 materializes such a subquery and then picks wp_posts as
		// the driving table, scanning the whole posts table on every keystroke. Joining
		// on the primary key cannot duplicate rows (ID is unique), so the result is
		// identical — but STRAIGHT_JOIN is still required to get the good plan, because
		// the optimizer picks the same posts-first order for a plain join. With it the
		// index table leads through the term key and each post is fetched by primary
		// key. Measured on a 13k-product catalog: ~590 ms before, ~155 ms after, same
		// rows. Every other join here is a LEFT JOIN hanging off `i`, so pinning the
		// order costs nothing. STRAIGHT_JOIN rather than FORCE INDEX on purpose: a
		// forced index name that a site's table happens to lack is a fatal SQL error,
		// while this is plain syntax.
		$sql = 'SELECT STRAIGHT_JOIN i.object_id, i.object_type, SUM( ' . $score_sum . " ) AS score, $coverage AS matched{$stock_select}
			FROM `$table` i
			INNER JOIN {$wpdb->posts} p ON p.ID = i.object_id
			$join
			$idf_join
			$boost_join
			WHERE i.term IN ($in_terms)
				AND p.post_status = 'publish' AND p.post_password = '' AND p.post_type IN ($in_types)
				$excl_sql
				$neg_sql
				$tax_sql
			GROUP BY i.object_id, i.object_type
			$having
			ORDER BY {$order_prefix}matched DESC, {$boost_order}{$tie_break}, i.object_id DESC
			LIMIT %d";

		// Placeholder order mirrors the SQL string top-to-bottom: the coverage CASE
		// (SELECT) lists every term first, then the click-boost JOIN hash, then the
		// WHERE term/type lists and the remaining filters.
		$values = $terms;

		if ( '' !== $query_hash ) {
			$values[] = $query_hash;
		}

		$values = array_merge( $values, $terms, $types );

		if ( ! empty( $exclude ) ) {
			$values = array_merge( $values, $exclude );
		}

		if ( ! empty( $exclude_terms ) ) {
			$values = array_merge( $values, $exclude_terms );
		}

		if ( $tax_valid ) {
			$values[] = $taxonomy;
			$values   = array_merge( $values, $term_ids );
		}

		if ( $min_match > 1 ) {
			$values[] = min( $min_match, count( $groups ) );
		}

		$values[] = $limit;

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( ! is_array( $rows ) ) {
			return array();
		}

		return array_map(
			static function ( $row ) {
				return array(
					'object_id'   => (int) $row->object_id,
					'object_type' => (string) $row->object_type,
					'score'       => (float) $row->score,
					'matched'     => isset( $row->matched ) ? (int) $row->matched : 0,
				);
			},
			$rows
		);
	}

	/**
	 * Convenience: return only the ordered object IDs.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @param array  $args  See search().
	 * @return int[]
	 */
	public static function search_ids( string $query, array $args = array() ): array {
		return array_map(
			static function ( $result ) {
				return $result['object_id'];
			},
			self::search( $query, $args )
		);
	}

	/**
	 * Count matching objects per taxonomy term for the dropdown category groups.
	 *
	 * Instead of matching term names, this counts how many objects that actually
	 * satisfy the query (same strictness floor, synonyms and Boolean NOT as the
	 * result list) fall into each term. A term the query does not reach never
	 * appears, and its number is the matching count — not the term's total size.
	 * The floor is the one the result list uses, so the badge and the page agree;
	 * how much of the query a term's best product covers only orders the list.
	 * The results-page facets count their own pool instead — see
	 * term_counts_for_ids().
	 *
	 * @since 1.1.2
	 * @param string   $query      Raw user query.
	 * @param string[] $taxonomies Taxonomies to aggregate over.
	 * @param int      $limit      Max terms, ordered by matching count.
	 * @return array<int,array{term_id:int,taxonomy:string,count:int}>
	 */
	public static function term_match_counts( string $query, array $taxonomies, int $limit ): array {
		global $wpdb;

		$taxonomies = array_values( array_unique( array_filter( array_map( 'strval', $taxonomies ) ) ) );

		if ( empty( $taxonomies ) || $limit < 1 ) {
			return array();
		}

		list( $clean_query, $neg_terms ) = self::split_negatives( $query );

		$words = MVweb_SS_Tokenizer::tokenize_words( $clean_query );

		if ( empty( $words ) ) {
			return array();
		}

		// The same trailing-word prefix the result list expands on: a synonym rule
		// that fires while the word is still being typed ("чех" → чехол/бампер/
		// кейс) widens the results, and a count taken without it would promise far
		// less than a click delivers — most of a live search happens mid-word.
		$partial = MVweb_SS_Settings::get( 'synonym_prefix', true ) ? self::trailing_stem( $clean_query ) : '';

		$strictness   = (string) MVweb_SS_Settings::get( 'strictness', 'balanced' );
		$min_match    = self::min_match( $strictness, MVweb_SS_Tokenizer::word_count( $clean_query ) );
		$groups       = self::expand_groups( $words, $partial, (bool) MVweb_SS_Settings::get( 'translit_cross_script', true ) );
		$search_terms = self::flatten_groups( $groups );
		$need         = (int) min( $min_match, count( $groups ) );

		$table   = MVweb_SS_Schema::table_name();
		$exclude = MVweb_SS_Settings::excluded_ids();

		$in_terms = implode( ',', array_fill( 0, count( $search_terms ), '%s' ) );
		$in_taxes = implode( ',', array_fill( 0, count( $taxonomies ), '%s' ) );

		$excl_sql = '';
		if ( ! empty( $exclude ) ) {
			$in_excl  = implode( ',', array_fill( 0, count( $exclude ), '%d' ) );
			$excl_sql = "AND i.object_id NOT IN ($in_excl)";
		}

		$neg_sql = '';
		if ( ! empty( $neg_terms ) ) {
			$in_neg  = implode( ',', array_fill( 0, count( $neg_terms ), '%s' ) );
			$neg_sql = "AND i.object_id NOT IN ( SELECT object_id FROM `$table` WHERE term IN ($in_neg) )";
		}

		// The badge follows the same stock rule as the result list: out-of-stock
		// products are dropped only when the store hides them ('hide' mode), so the
		// number matches what a click into the category actually shows. Non-products
		// keep no _stock_status meta, so the NOT IN filter only trims WC products.
		$stock_sql = '';
		if ( class_exists( 'WooCommerce' ) && 'hide' === self::stock_mode() ) {
			$stock_sql = "AND i.object_id NOT IN (
				SELECT post_id FROM {$wpdb->postmeta}
				WHERE meta_key = '_stock_status' AND meta_value = 'outofstock'
			)";
		}

		// Match strength orders the badges, it does not filter them. The floor stays
		// the one the result list uses, so the number under a category is the number
		// a click on it opens; the category whose best product covers the most query
		// concepts still comes first. A query like "iphone 12 pro battery" therefore
		// leads with the battery category, while the phone cases that only match the
		// model words stay in the list — with an honest count — instead of vanishing.
		$multi     = count( $groups ) > 1;
		$cov_case  = $multi ? self::coverage_case_sql( $groups ) : '';
		$cov_col   = $multi ? ', ' . $cov_case . ' AS cov' : '';
		$cov_order = $multi ? 'MAX( m.cov ) DESC, ' : '';

		$having = $need > 1 ? 'HAVING ' . $cov_case . ' >= %d' : '';

		$sql = "SELECT tt.term_id AS term_id, tt.taxonomy AS taxonomy, COUNT( DISTINCT m.object_id ) AS cnt
			FROM {$wpdb->term_taxonomy} tt
			INNER JOIN {$wpdb->term_relationships} tr ON tr.term_taxonomy_id = tt.term_taxonomy_id
			INNER JOIN (
				SELECT STRAIGHT_JOIN i.object_id$cov_col
				FROM `$table` i
				INNER JOIN {$wpdb->posts} p ON p.ID = i.object_id
				WHERE i.term IN ($in_terms)
					AND p.post_status = 'publish' AND p.post_password = ''
					$excl_sql
					$neg_sql
					$stock_sql
				GROUP BY i.object_id
				$having
			) m ON m.object_id = tr.object_id
			WHERE tt.taxonomy IN ($in_taxes)
			GROUP BY tt.term_id, tt.taxonomy
			ORDER BY {$cov_order}cnt DESC, tt.term_id ASC
			LIMIT %d";

		// Placeholders in statement order: the coverage CASE in SELECT, the term
		// list in WHERE, then the exclusions, then the HAVING CASE and its floor.
		$values = $multi ? array_merge( $search_terms, $search_terms ) : $search_terms;

		if ( ! empty( $exclude ) ) {
			$values = array_merge( $values, $exclude );
		}

		if ( ! empty( $neg_terms ) ) {
			$values = array_merge( $values, $neg_terms );
		}

		if ( $need > 1 ) {
			// The HAVING coverage CASE lists every term again, then the floor value.
			$values   = array_merge( $values, $search_terms );
			$values[] = $need;
		}

		$values   = array_merge( $values, $taxonomies );
		$values[] = $limit;

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( ! is_array( $rows ) ) {
			return array();
		}

		return array_map(
			static function ( $row ) {
				return array(
					'term_id'  => (int) $row->term_id,
					'taxonomy' => (string) $row->taxonomy,
					'count'    => (int) $row->cnt,
				);
			},
			$rows
		);
	}

	/**
	 * Term counts over an existing result pool, most matches first.
	 *
	 * The results-page facets count what the page is actually showing instead of
	 * re-running the search: the pool has already passed the strictness floor, the
	 * post-type scope, the results ceiling, any fuzzy rescue and the multilingual
	 * filter, so the number next to a facet is the number ticking it leaves. A
	 * product in a child term also counts for its ancestors, because the facet
	 * filters with include_children.
	 *
	 * @since 1.5.5
	 * @param int[]    $object_ids Ranked pool of object IDs.
	 * @param string[] $taxonomies Taxonomies to aggregate over.
	 * @param int      $limit      Max terms, ordered by count.
	 * @return array<int,array{term_id:int,taxonomy:string,count:int}>
	 */
	public static function term_counts_for_ids( array $object_ids, array $taxonomies, int $limit ): array {
		global $wpdb;

		$object_ids = array_values( array_unique( array_filter( array_map( 'intval', $object_ids ) ) ) );
		$taxonomies = array_values( array_unique( array_filter( array_map( 'strval', $taxonomies ) ) ) );

		if ( empty( $object_ids ) || empty( $taxonomies ) || $limit < 1 ) {
			return array();
		}

		$in_ids   = implode( ',', array_fill( 0, count( $object_ids ), '%d' ) );
		$in_taxes = implode( ',', array_fill( 0, count( $taxonomies ), '%s' ) );

		$sql = "SELECT tt.term_id AS term_id, tt.taxonomy AS taxonomy, tr.object_id AS object_id
			FROM {$wpdb->term_relationships} tr
			INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
			WHERE tr.object_id IN ($in_ids) AND tt.taxonomy IN ($in_taxes)";

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, array_merge( $object_ids, $taxonomies ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( ! is_array( $rows ) ) {
			return array();
		}

		// Object sets per term, so a product counted for both a child and its parent
		// is counted once in each — never twice in the parent. Ancestors are looked
		// up once per term, not once per row: one category covers hundreds of rows.
		$sets      = array();
		$ancestors = array();

		foreach ( $rows as $row ) {
			$term_id  = (int) $row->term_id;
			$taxonomy = (string) $row->taxonomy;
			$object   = (int) $row->object_id;
			$key      = $taxonomy . '|' . $term_id;

			$sets[ $key ][ $object ] = true;

			if ( ! isset( $ancestors[ $key ] ) ) {
				$ancestors[ $key ] = array_map( 'intval', get_ancestors( $term_id, $taxonomy, 'taxonomy' ) );
			}

			foreach ( $ancestors[ $key ] as $ancestor ) {
				$sets[ $taxonomy . '|' . $ancestor ][ $object ] = true;
			}
		}

		$out = array();

		foreach ( $sets as $key => $objects ) {
			list( $taxonomy, $term_id ) = explode( '|', $key, 2 );

			$out[] = array(
				'term_id'  => (int) $term_id,
				'taxonomy' => (string) $taxonomy,
				'count'    => count( $objects ),
			);
		}

		usort(
			$out,
			static function ( $a, $b ) {
				return $a['count'] === $b['count']
					? $a['term_id'] <=> $b['term_id']
					: $b['count'] <=> $a['count'];
			}
		);

		return array_slice( $out, 0, $limit );
	}

	/**
	 * Lowest and highest product price across a set of object IDs, read from the
	 * WooCommerce lookup table. Used to hint the price facet's range (P2.1). Returns
	 * an empty array when WooCommerce is inactive or no priced product is present.
	 *
	 * @since 1.2.0
	 * @param int[] $ids Object IDs (the current ranked pool).
	 * @return array{min:float,max:float}|array{}
	 */
	public static function price_bounds( array $ids ): array {
		global $wpdb;

		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );

		if ( empty( $ids ) || ! class_exists( 'WooCommerce' ) ) {
			return array();
		}

		$lookup = $wpdb->prefix . 'wc_product_meta_lookup';
		$in     = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		$sql = "SELECT MIN( min_price ) AS lo, MAX( max_price ) AS hi
			FROM `$lookup`
			WHERE product_id IN ($in) AND min_price IS NOT NULL";

		$row = $wpdb->get_row( $wpdb->prepare( $sql, $ids ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( ! $row || null === $row->lo || null === $row->hi ) {
			return array();
		}

		return array(
			'min' => (float) $row->lo,
			'max' => (float) $row->hi,
		);
	}

	/**
	 * Keep only the object IDs whose product price range overlaps the given
	 * bounds, preserving the input (relevance) order. Reads min_price/max_price
	 * from the WooCommerce lookup table, matching the same overlap rule the
	 * in-query price-intent filter uses (max_price >= min AND min_price <= max),
	 * so the price facet and the "до N" query filter agree — including on variable
	 * products, whose range the lookup captures but a single `_price` meta does not.
	 *
	 * @since 1.2.0
	 * @param int[]      $ids Object IDs (ranked order).
	 * @param float|null $min Lower bound, or null.
	 * @param float|null $max Upper bound, or null.
	 * @return int[] Filtered IDs in the original order (unchanged when no bound/WooCommerce).
	 */
	public static function filter_ids_by_price( array $ids, ?float $min, ?float $max ): array {
		global $wpdb;

		$ids = array_values( array_filter( array_map( 'intval', $ids ) ) );

		if ( empty( $ids ) || ( null === $min && null === $max ) || ! class_exists( 'WooCommerce' ) ) {
			return $ids;
		}

		$lookup = $wpdb->prefix . 'wc_product_meta_lookup';
		$in     = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$cond   = array();

		if ( null !== $min ) {
			$cond[] = 'max_price >= ' . number_format( (float) $min, 2, '.', '' );
		}

		if ( null !== $max ) {
			$cond[] = 'min_price <= ' . number_format( (float) $max, 2, '.', '' );
		}

		$cond_sql = implode( ' AND ', $cond );

		$sql  = "SELECT product_id FROM `$lookup` WHERE product_id IN ($in) AND $cond_sql";
		$kept = $wpdb->get_col( $wpdb->prepare( $sql, $ids ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		$keep = array_flip( array_map( 'intval', (array) $kept ) );

		return array_values(
			array_filter(
				$ids,
				static function ( $id ) use ( $keep ) {
					return isset( $keep[ $id ] );
				}
			)
		);
	}

	/**
	 * A term ID plus all of its descendant term IDs in a taxonomy.
	 *
	 * @since 1.0.0
	 * @param int    $term_id  Selected term ID.
	 * @param string $taxonomy Taxonomy slug.
	 * @return int[] Empty when the term or taxonomy is invalid.
	 */
	public static function term_and_children( int $term_id, string $taxonomy ): array {
		if ( $term_id <= 0 || '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
			return array();
		}

		if ( ! get_term( $term_id, $taxonomy ) instanceof WP_Term ) {
			return array();
		}

		$ids      = array( $term_id );
		$children = get_term_children( $term_id, $taxonomy );

		if ( is_array( $children ) ) {
			foreach ( $children as $child ) {
				$ids[] = (int) $child;
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Minimum number of query terms an object must match for the chosen strictness.
	 *
	 * Strict = all terms (AND); loose = any single term (OR); balanced = most
	 * of the terms (a coverage floor), which drops results that only share a
	 * word or two with a multi-word query.
	 *
	 * @since 1.0.4
	 * @param string $strictness 'loose', 'balanced' or 'strict'.
	 * @param int    $count      Number of query terms.
	 * @return int Floor between 1 and $count.
	 */
	private static function min_match( string $strictness, int $count ): int {
		if ( $count <= 1 ) {
			return 1;
		}

		switch ( $strictness ) {
			case 'strict':
				return $count;
			case 'loose':
				return 1;
			default:
				return (int) max( 1, $count - (int) floor( $count / 3 ) );
		}
	}

	/**
	 * Resolve the out-of-stock handling mode.
	 *
	 * @since 1.0.0
	 * @return string 'show', 'hide' or 'demote'.
	 */
	private static function stock_mode(): string {
		$mode = (string) MVweb_SS_Settings::get( 'stock', 'show' );

		return in_array( $mode, array( 'hide', 'demote' ), true ) ? $mode : 'show';
	}

	/**
	 * SQL expression counting how many distinct coverage GROUPS an object matched,
	 * used both to order results and to enforce the strictness floor (HAVING).
	 *
	 * Each query term maps to its group's index; COUNT(DISTINCT group_index) then
	 * counts covered concepts, so a word and its synonym or transliteration score
	 * one coverage point, not two (P0.2). Term strings are bound as prepared
	 * placeholders (%s) in caller order; group indices are trusted integers.
	 *
	 * With the "match in product data, not description" option on, coverage counts
	 * only when the term appears in an identifying field (title, SKU, attributes,
	 * brand, categories, custom fields), never the marketing description — where a
	 * model number or a part word appears incidentally and would otherwise let an
	 * unrelated product satisfy an all-words query. The description still feeds the
	 * score, it just no longer alone clears the floor.
	 *
	 * @since 1.2.0
	 * @param array<int,string[]> $groups Coverage groups (in flatten order).
	 * @return string
	 */
	private static function coverage_case_sql( array $groups ): string {
		$cases = '';

		foreach ( $groups as $gi => $group ) {
			$cases .= str_repeat( ' WHEN %s THEN ' . (int) $gi, count( $group ) );
		}

		$inner = 'CASE i.term' . $cases . ' END';

		if ( ! MVweb_SS_Settings::get( 'title_coverage', false ) ) {
			return "COUNT( DISTINCT $inner )";
		}

		return "COUNT( DISTINCT CASE WHEN i.source NOT IN ( 'content', 'excerpt' ) THEN ( $inner ) END )";
	}

	/**
	 * Total indexed document count for IDF, cached per request.
	 *
	 * @since 1.2.0
	 * @return int At least 1.
	 */
	private static function doc_count(): int {
		static $n = null;

		if ( null !== $n ) {
			return $n;
		}

		$meta = MVweb_SS_Schema::get_meta();
		$n    = isset( $meta['doc_count'] ) ? (int) $meta['doc_count'] : 0;

		if ( $n <= 0 ) {
			$n = MVweb_SS_Indexer::count_objects();
		}

		$n = max( 1, $n );

		return $n;
	}

	/**
	 * BM25-style term-frequency saturation as an SQL sub-expression.
	 *
	 * Replaces the raw term frequency (`i.count`) with tf·(k1+1)/(tf+k1) so a
	 * word repeated many times in one long field (keyword stuffing) can no
	 * longer outweigh a clean title match. tf = 1 yields 1.0, matching the old
	 * linear score for the common single-occurrence case. Float literals are
	 * formatted with an explicit dot (locale-independent).
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private static function tf_saturation(): string {
		$num = number_format( self::BM25_K1 + 1, 1, '.', '' );
		$den = number_format( self::BM25_K1, 1, '.', '' );

		return '( i.count * ' . $num . ' / ( i.count + ' . $den . ' ) )';
	}

	/**
	 * Build the SQL CASE expression that applies per-source weights.
	 *
	 * Source keys and weights are trusted plugin constants, sanitized before
	 * inlining (no user input reaches this expression). Term frequency is
	 * saturated (see tf_saturation()) so repetition has diminishing returns.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function weight_case(): string {
		$weights = wp_parse_args( (array) MVweb_SS_Settings::get( 'weights', array() ), self::$weights );
		$weights = apply_filters( 'mvweb_ss_field_weights', $weights );

		if ( ! is_array( $weights ) || empty( $weights ) ) {
			$weights = self::$weights;
		}

		$tf    = self::tf_saturation();
		$parts = array();

		foreach ( $weights as $source => $weight ) {
			$source  = preg_replace( '/[^a-z_]/', '', (string) $source );
			$parts[] = "WHEN '" . $source . "' THEN " . (int) $weight . ' * ' . $tf;
		}

		return 'CASE i.source ' . implode( ' ', $parts ) . ' ELSE ' . $tf . ' END';
	}

	/**
	 * Per-source weight CASE with BM25 field-length normalization (P1.2).
	 *
	 * Same as weight_case(), but each source's contribution is divided by its
	 * fieldnorm ((1-b) + b·len/avgdl): a term in a field longer than average is
	 * down-weighted, a term in a short field keeps its full weight. avgdl per
	 * source comes from the index meta (rebuilt on reindex); b is lighter for
	 * short structured fields (title, sku, brand) than for free text (content,
	 * excerpt), matching how much their length actually varies. A source without
	 * an avgdl, or a row without a doclen entry, falls back to no normalization
	 * (fieldnorm 1), so the mode degrades to the plain weighted score rather than
	 * dividing by zero. Values are trusted constants/meta, inlined as floats.
	 *
	 * @since 1.2.0
	 * @return string
	 */
	private static function weight_case_doclen(): string {
		$weights = wp_parse_args( (array) MVweb_SS_Settings::get( 'weights', array() ), self::$weights );
		$weights = apply_filters( 'mvweb_ss_field_weights', $weights );

		if ( ! is_array( $weights ) || empty( $weights ) ) {
			$weights = self::$weights;
		}

		$meta  = MVweb_SS_Schema::get_meta();
		$avgdl = isset( $meta['avgdl'] ) && is_array( $meta['avgdl'] ) ? $meta['avgdl'] : array();
		$long  = array( 'content', 'excerpt', 'tax', 'cf' );

		$tf    = self::tf_saturation();
		$parts = array();

		foreach ( $weights as $source => $weight ) {
			$source = preg_replace( '/[^a-z_]/', '', (string) $source );
			$weight = (int) $weight;
			$avg    = isset( $avgdl[ $source ] ) ? (float) $avgdl[ $source ] : 0.0;

			if ( $avg > 0 ) {
				$b       = in_array( $source, $long, true ) ? self::BM25_B_CONTENT : self::BM25_B_TITLE;
				$one_b   = number_format( 1 - $b, 3, '.', '' );
				$bf      = number_format( $b, 3, '.', '' );
				$avgf    = number_format( $avg, 3, '.', '' );
				$norm    = '( ' . $one_b . ' + ' . $bf . ' * COALESCE( dl.len, ' . $avgf . ' ) / ' . $avgf . ' )';
				$parts[] = "WHEN '" . $source . "' THEN " . $weight . ' * ' . $tf . ' / ' . $norm;
			} else {
				$parts[] = "WHEN '" . $source . "' THEN " . $weight . ' * ' . $tf;
			}
		}

		return 'CASE i.source ' . implode( ' ', $parts ) . ' ELSE ' . $tf . ' END';
	}
}
