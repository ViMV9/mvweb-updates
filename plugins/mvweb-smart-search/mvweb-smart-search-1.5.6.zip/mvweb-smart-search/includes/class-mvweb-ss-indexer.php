<?php
/**
 * Indexer: writes an object's terms into the search index.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds and stores index rows for a single post/product/CPT object.
 *
 * @since 1.0.0
 */
class MVweb_SS_Indexer {

	const BATCH_ROWS = 200;

	/**
	 * When true, per-object document-frequency deltas are skipped: a bulk pass
	 * (full reindex) rebuilds the whole terms table once at the end instead of
	 * churning df on every object.
	 *
	 * @var bool
	 */
	private static $defer_stats = false;

	/**
	 * Toggle deferred df maintenance for a bulk pass.
	 *
	 * @since 1.2.0
	 * @param bool $on Whether to defer df deltas.
	 * @return void
	 */
	public static function defer_stats( bool $on ): void {
		self::$defer_stats = $on;
	}

	/**
	 * Index (or re-index) a single object by ID.
	 *
	 * Not-indexable objects (draft, trashed, password-protected, wrong type)
	 * are removed from the index instead.
	 *
	 * @since 1.0.0
	 * @param int $object_id Post/product ID.
	 * @return void
	 */
	public static function index_object( int $object_id ): void {
		$post = get_post( $object_id );

		if ( ! $post instanceof WP_Post || ! self::is_indexable( $post ) ) {
			self::remove_object( $object_id );
			return;
		}

		self::with_object_lock(
			$post->ID,
			static function () use ( $post ) {
				self::write( $post->ID, $post->post_type, self::collect_sources( $post ) );
			}
		);
	}

	/**
	 * Serialize a single object's index write behind a MySQL advisory lock.
	 *
	 * The read-delete-insert in write()/remove_object() is not atomic, and the
	 * same object can be written concurrently from the save_post hook, the cron
	 * catch-up and a manual reindex. Without serialization two writers apply the
	 * same df/doc_count delta from an identical stale snapshot, silently doubling
	 * the IDF statistics. GET_LOCK with a zero timeout keeps the write single-
	 * file per object.
	 *
	 * GET_LOCK returns 1 when acquired, 0 when another connection holds it, and
	 * NULL when the server cannot provide user-level locks at all (clustered
	 * MySQL such as Galera / Percona XtraDB Cluster, and some managed/proxied
	 * setups). The two failure values need opposite handling: on 0 the write is
	 * skipped because the holder is another writer that will produce the correct
	 * row; on NULL there is no holder and no lock service, so the write must run
	 * unlocked rather than be dropped — otherwise every index write silently
	 * no-ops and the index stays empty on those hosts. Concurrent unlocked writes
	 * stay safe: the row upsert is idempotent under the unique key, and the df
	 * statistics are recomputed wholesale by rebuild_stats() after a full reindex.
	 *
	 * @since 1.5.0
	 * @param int      $object_id Object ID.
	 * @param callable $fn        Critical section to run under the lock.
	 * @return void
	 */
	private static function with_object_lock( int $object_id, callable $fn ): void {
		global $wpdb;

		$key  = 'mvweb_ss_idx_' . $object_id;
		$lock = $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, %d)', $key, 0 ) );

		if ( null === $lock ) {
			$fn();
			return;
		}

		if ( 1 !== (int) $lock ) {
			return;
		}

		try {
			$fn();
		} finally {
			$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $key ) );
		}
	}

	/**
	 * Remove all index rows for an object.
	 *
	 * @since 1.0.0
	 * @param int $object_id Object ID.
	 * @return void
	 */
	public static function remove_object( int $object_id ): void {
		self::with_object_lock(
			$object_id,
			static function () use ( $object_id ) {
				$old = self::object_terms( $object_id );

				self::clear_rows( $object_id );

				if ( ! self::$defer_stats ) {
					self::apply_df_delta( $old, array() );
					self::nudge_doc_count( $old, array() );
				}
			}
		);
	}

	/**
	 * Distinct index terms currently stored for an object.
	 *
	 * @since 1.2.0
	 * @param int $object_id Object ID.
	 * @return string[]
	 */
	private static function object_terms( int $object_id ): array {
		global $wpdb;

		$table = MVweb_SS_Schema::table_name();

		return array_map( 'strval', (array) $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT term FROM `$table` WHERE object_id = %d", $object_id ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Delete an object's index and document-length rows (no stats accounting).
	 *
	 * @since 1.2.0
	 * @param int $object_id Object ID.
	 * @return void
	 */
	private static function clear_rows( int $object_id ): void {
		global $wpdb;

		$table  = MVweb_SS_Schema::table_name();
		$doclen = MVweb_SS_Schema::doclen_table_name();
		$wpdb->query( $wpdb->prepare( "DELETE FROM `$table` WHERE object_id = %d", $object_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$wpdb->query( $wpdb->prepare( "DELETE FROM `$doclen` WHERE object_id = %d", $object_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Number of distinct objects currently in the index (live count).
	 *
	 * The table holds one row per term, so distinct object_id is the real
	 * "items in index" figure.
	 *
	 * @since 1.0.3
	 * @return int
	 */
	public static function count_objects(): int {
		global $wpdb;

		$table = MVweb_SS_Schema::table_name();

		return (int) $wpdb->get_var( "SELECT COUNT(DISTINCT object_id) FROM `$table`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Number of published objects of the indexed types (drift indicator).
	 *
	 * An upper bound on what the index should hold: exclusions (password, opt-out,
	 * exclude-from-search) legitimately keep it a little below this, so callers
	 * treat a small gap as normal and only flag an empty index or a large gap.
	 *
	 * @since 1.2.0
	 * @return int
	 */
	public static function count_indexable(): int {
		global $wpdb;

		$types = self::get_indexed_post_types();
		$in    = implode( ',', array_fill( 0, count( $types ), '%s' ) );

		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(ID) FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ($in)", $types ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQLPlaceholders
	}

	/**
	 * Post types eligible for indexing.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	public static function get_indexed_post_types(): array {
		$defaults = array( 'post', 'page' );

		if ( class_exists( 'WooCommerce' ) ) {
			$defaults[] = 'product';
		}

		$types = array_values( array_filter( array_unique( array_map( 'strval', (array) MVweb_SS_Settings::get( 'post_types', $defaults ) ) ) ) );

		if ( empty( $types ) ) {
			$types = $defaults;
		}

		$filtered = array_values( array_filter( array_unique( array_map( 'strval', (array) apply_filters( 'mvweb_ss_indexed_post_types', $types ) ) ) ) );

		return empty( $filtered ) ? $defaults : $filtered;
	}

	/**
	 * Validate a comma-separated post-type scope against the indexed set.
	 *
	 * @since 1.0.0
	 * @param string $csv Comma-separated post types.
	 * @return string[] Valid, unique types (empty means "all indexed types").
	 */
	public static function sanitize_types_csv( string $csv ): array {
		if ( '' === trim( $csv ) ) {
			return array();
		}

		$allowed = self::get_indexed_post_types();
		$picked  = array();

		foreach ( explode( ',', $csv ) as $type ) {
			$type = sanitize_key( trim( $type ) );

			if ( '' !== $type && in_array( $type, $allowed, true ) ) {
				$picked[] = $type;
			}
		}

		return array_values( array_unique( $picked ) );
	}

	/**
	 * Whether a post is eligible for the public index.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Post object.
	 * @return bool
	 */
	private static function is_indexable( WP_Post $post ): bool {
		if ( ! in_array( $post->post_type, self::get_indexed_post_types(), true ) ) {
			return false;
		}

		if ( 'publish' !== $post->post_status ) {
			return false;
		}

		if ( '' !== (string) $post->post_password ) {
			return false;
		}

		if ( class_exists( 'MVweb_SS_Editor' ) && MVweb_SS_Editor::is_excluded( $post->ID ) ) {
			return false;
		}

		if ( 'product' === $post->post_type
			&& class_exists( 'WooCommerce' )
			&& has_term( 'exclude-from-search', 'product_visibility', $post->ID ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Collect indexable text grouped by source.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Post object.
	 * @return array<string,string> source => text.
	 */
	private static function collect_sources( WP_Post $post ): array {
		$sources = array(
			'title'   => (string) $post->post_title,
			'content' => self::content_text( (string) $post->post_content ),
			'excerpt' => (string) $post->post_excerpt,
			'tax'     => self::collect_taxonomies( $post ),
		);

		$cf = self::collect_custom_fields( $post->ID );

		if ( '' !== $cf ) {
			$sources['cf'] = $cf;
		}

		if ( 'product' === $post->post_type && class_exists( 'WooCommerce' ) ) {
			$sources = array_merge( $sources, self::collect_woo( $post->ID ) );
		}

		return array_filter(
			$sources,
			static function ( $text ) {
				return is_string( $text ) && '' !== trim( $text );
			}
		);
	}

	/**
	 * Reduce post content to plain indexable text.
	 *
	 * By default shortcodes are removed (the text a builder wraps in shortcodes
	 * is not indexed). With the index_shortcodes setting on (P2.6, default-off),
	 * shortcodes are expanded first so text built with WPBakery, Divi and other
	 * shortcode-based builders becomes searchable. Expansion is slower and can
	 * have side effects, so it runs only here, inside the background reindex,
	 * never on the search request.
	 *
	 * @since 1.2.0
	 * @param string $raw Raw post content.
	 * @return string
	 */
	private static function content_text( string $raw ): string {
		if ( '' === trim( $raw ) ) {
			return '';
		}

		$raw = MVweb_SS_Settings::get( 'index_shortcodes', false )
			? do_shortcode( $raw )
			: strip_shortcodes( $raw );

		return wp_strip_all_tags( $raw );
	}

	/**
	 * Collect public taxonomy term names (product attributes handled separately).
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Post object.
	 * @return string
	 */
	private static function collect_taxonomies( WP_Post $post ): string {
		$names = array();

		foreach ( get_object_taxonomies( $post->post_type ) as $taxonomy ) {
			if ( 0 === strpos( $taxonomy, 'pa_' ) ) {
				continue;
			}

			if ( ! is_taxonomy_viewable( $taxonomy ) ) {
				continue;
			}

			$terms = get_the_terms( $post->ID, $taxonomy );

			if ( is_array( $terms ) ) {
				foreach ( $terms as $term ) {
					$names[] = $term->name;
				}
			}
		}

		return implode( ' ', $names );
	}

	/**
	 * Collect whitelisted custom field values (protected meta never indexed).
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return string
	 */
	private static function collect_custom_fields( int $post_id ): string {
		$whitelist = (array) MVweb_SS_Settings::get( 'cf_whitelist', array() );

		if ( empty( $whitelist ) ) {
			return '';
		}

		$values = array();

		foreach ( $whitelist as $key ) {
			$key = (string) $key;

			if ( '' === $key || '_' === $key[0] ) {
				continue;
			}

			foreach ( get_post_meta( $post_id, $key, false ) as $value ) {
				if ( is_scalar( $value ) ) {
					$values[] = (string) $value;
				}
			}
		}

		return implode( ' ', $values );
	}

	/**
	 * Collect WooCommerce-specific text (SKU, attributes, variation SKUs).
	 *
	 * @since 1.0.0
	 * @param int $product_id Product ID.
	 * @return array<string,string>
	 */
	private static function collect_woo( int $product_id ): array {
		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return array();
		}

		$out = array();

		$sku = $product->get_sku();

		if ( '' !== $sku ) {
			$out['sku'] = self::sku_forms( $sku );
		}

		$gtin = self::product_gtin( $product );

		if ( '' !== $gtin ) {
			$out['gtin'] = $gtin;
		}

		$brands = self::product_brands( $product_id );

		if ( '' !== $brands ) {
			$out['brand'] = $brands;
		}

		$attr_values = array();

		foreach ( $product->get_attributes() as $attribute ) {
			if ( $attribute->is_taxonomy() ) {
				$attr_values = array_merge(
					$attr_values,
					wc_get_product_terms( $product_id, $attribute->get_name(), array( 'fields' => 'names' ) )
				);
			} else {
				$attr_values = array_merge( $attr_values, $attribute->get_options() );
			}
		}

		if ( ! empty( $attr_values ) ) {
			$out['attr'] = implode( ' ', $attr_values );
		}

		if ( $product->is_type( 'variable' ) ) {
			$variation_skus = array();

			foreach ( $product->get_children() as $variation_id ) {
				$variation = wc_get_product( $variation_id );

				if ( $variation && '' !== $variation->get_sku() ) {
					$variation_skus[] = self::sku_forms( $variation->get_sku() );
				}
			}

			if ( ! empty( $variation_skus ) ) {
				$out['variation_sku'] = implode( ' ', $variation_skus );
			}
		}

		return $out;
	}

	/**
	 * Both the raw SKU and its punctuation-stripped form as one string.
	 *
	 * A SKU like "123456-123" is indexed as-is (so its parts stay searchable)
	 * and also collapsed to "123456123", so a shopper who types the digits
	 * without the dash still finds the product. Identical forms are not doubled.
	 *
	 * @since 1.1.0
	 * @param string $sku Raw SKU.
	 * @return string
	 */
	private static function sku_forms( string $sku ): string {
		$collapsed = (string) preg_replace( '/[^\p{L}\p{N}]+/u', '', $sku );

		return ( '' !== $collapsed && $collapsed !== $sku ) ? $sku . ' ' . $collapsed : $sku;
	}

	/**
	 * Product GTIN/UPC/EAN (native WooCommerce field, meta fallback).
	 *
	 * @since 1.0.0
	 * @param WC_Product $product Product.
	 * @return string
	 */
	private static function product_gtin( $product ): string {
		if ( method_exists( $product, 'get_global_unique_id' ) ) {
			$gtin = (string) $product->get_global_unique_id();

			if ( '' !== $gtin ) {
				return $gtin;
			}
		}

		return (string) get_post_meta( $product->get_id(), '_global_unique_id', true );
	}

	/**
	 * Product brand names from the common brand taxonomies.
	 *
	 * @since 1.0.0
	 * @param int $product_id Product ID.
	 * @return string
	 */
	private static function product_brands( int $product_id ): string {
		$names = array();

		/**
		 * Filter the taxonomies treated as product brands.
		 *
		 * @since 1.0.0
		 * @param string[] $taxonomies Brand taxonomy slugs.
		 */
		$taxonomies = (array) apply_filters(
			'mvweb_ss_brand_taxonomies',
			array( 'product_brand', 'pwb-brand', 'yith_product_brand', 'berocket_brand' )
		);

		foreach ( $taxonomies as $taxonomy ) {
			if ( ! taxonomy_exists( $taxonomy ) ) {
				continue;
			}

			$terms = wp_get_post_terms( $product_id, $taxonomy, array( 'fields' => 'names' ) );

			if ( ! is_wp_error( $terms ) ) {
				$names = array_merge( $names, $terms );
			}
		}

		return implode( ' ', array_values( array_unique( $names ) ) );
	}

	/**
	 * Replace the object's index rows with freshly tokenized terms.
	 *
	 * @since 1.0.0
	 * @param int                  $object_id   Object ID.
	 * @param string               $object_type Post type.
	 * @param array<string,string> $sources     source => text.
	 * @return void
	 */
	private static function write( int $object_id, string $object_type, array $sources ): void {
		$table = MVweb_SS_Schema::table_name();
		$lang  = substr( get_locale(), 0, 2 );

		$old = self::object_terms( $object_id );

		self::clear_rows( $object_id );

		$placeholders = array();
		$values       = array();
		$doclen       = array();
		$new_terms    = array();

		foreach ( $sources as $source => $text ) {
			$field_len = 0;

			foreach ( MVweb_SS_Tokenizer::tokenize( (string) $text ) as $term => $count ) {
				$placeholders[] = '(%d,%s,%s,%s,%d,%s)';
				array_push( $values, $object_id, $term, $object_type, (string) $source, $count, $lang );

				$new_terms[ $term ] = true;
				$field_len         += (int) $count;

				if ( count( $placeholders ) >= self::BATCH_ROWS ) {
					self::flush( $table, $placeholders, $values );
					$placeholders = array();
					$values       = array();
				}
			}

			if ( $field_len > 0 ) {
				$doclen[ (string) $source ] = $field_len;
			}
		}

		if ( ! empty( $placeholders ) ) {
			self::flush( $table, $placeholders, $values );
		}

		self::write_doclen( $object_id, $doclen );

		if ( ! self::$defer_stats ) {
			// strval: a purely numeric term ("1660") is an int array key; keep the
			// set string-typed to match $old and the rest of the codebase.
			$new = array_map( 'strval', array_keys( $new_terms ) );
			self::apply_df_delta( $old, $new );
			self::nudge_doc_count( $old, $new );
		}
	}

	/**
	 * Replace an object's per-field document lengths (token counts).
	 *
	 * @since 1.2.0
	 * @param int                $object_id Object ID.
	 * @param array<string,int>  $doclen    source => token length.
	 * @return void
	 */
	private static function write_doclen( int $object_id, array $doclen ): void {
		if ( empty( $doclen ) ) {
			return;
		}

		global $wpdb;

		$table        = MVweb_SS_Schema::doclen_table_name();
		$placeholders = array();
		$values       = array();

		foreach ( $doclen as $source => $len ) {
			$placeholders[] = '(%d,%s,%d)';
			array_push( $values, $object_id, (string) $source, (int) $len );
		}

		$sql = "INSERT INTO `$table` (object_id, source, len) VALUES " . implode( ',', $placeholders );
		$wpdb->query( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Apply document-frequency deltas for the terms that entered or left an object.
	 *
	 * Terms present in the new set but not the old gain one document; terms in the
	 * old set but not the new lose one. Unchanged terms are untouched, so a routine
	 * edit costs only the difference — never a full recount (see rebuild_stats()).
	 *
	 * @since 1.2.0
	 * @param string[] $old Distinct terms before the write.
	 * @param string[] $new Distinct terms after the write.
	 * @return void
	 */
	private static function apply_df_delta( array $old, array $new ): void {
		global $wpdb;

		$old_set = array_flip( $old );
		$new_set = array_flip( $new );

		$added   = array_keys( array_diff_key( $new_set, $old_set ) );
		$removed = array_keys( array_diff_key( $old_set, $new_set ) );

		$table = MVweb_SS_Schema::terms_table_name();

		if ( ! empty( $added ) ) {
			$placeholders = implode( ',', array_fill( 0, count( $added ), '(%s,1)' ) );
			$sql          = "INSERT INTO `$table` (term, df) VALUES $placeholders ON DUPLICATE KEY UPDATE df = df + 1";
			$wpdb->query( $wpdb->prepare( $sql, $added ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders
		}

		if ( ! empty( $removed ) ) {
			$in  = implode( ',', array_fill( 0, count( $removed ), '%s' ) );
			$sql = "UPDATE `$table` SET df = GREATEST( 0, df - 1 ) WHERE term IN ($in)";
			$wpdb->query( $wpdb->prepare( $sql, $removed ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders
		}
	}

	/**
	 * Keep the stored document count in step when an object enters or leaves the
	 * index (an object with no terms before and some after is a new document).
	 *
	 * @since 1.2.0
	 * @param string[] $old Distinct terms before the write.
	 * @param string[] $new Distinct terms after the write.
	 * @return void
	 */
	private static function nudge_doc_count( array $old, array $new ): void {
		$was = ! empty( $old );
		$is  = ! empty( $new );

		if ( $was === $is ) {
			return;
		}

		$meta               = MVweb_SS_Schema::get_meta();
		$count              = isset( $meta['doc_count'] ) ? (int) $meta['doc_count'] : 0;
		$meta['doc_count']  = max( 0, $count + ( $is ? 1 : -1 ) );
		MVweb_SS_Schema::update_meta( $meta );
	}

	/**
	 * Rebuild the term-frequency and length statistics from the index in one pass.
	 *
	 * Called once at the end of a full reindex, where per-object df deltas were
	 * deferred: a single GROUP BY is far cheaper than churning df for every object.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function rebuild_stats(): void {
		global $wpdb;

		$index   = MVweb_SS_Schema::table_name();
		$terms   = MVweb_SS_Schema::terms_table_name();
		$doclen  = MVweb_SS_Schema::doclen_table_name();

		$wpdb->query( "TRUNCATE TABLE `$terms`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$wpdb->query( "INSERT INTO `$terms` (term, df) SELECT term, COUNT( DISTINCT object_id ) FROM `$index` GROUP BY term" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery

		$avg = array();

		foreach ( (array) $wpdb->get_results( "SELECT source, AVG( len ) AS avg_len FROM `$doclen` GROUP BY source" ) as $row ) { // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$avg[ (string) $row->source ] = round( (float) $row->avg_len, 3 );
		}

		$meta              = MVweb_SS_Schema::get_meta();
		$meta['avgdl']     = $avg;
		$meta['doc_count'] = (int) $wpdb->get_var( "SELECT COUNT( DISTINCT object_id ) FROM `$index`" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		MVweb_SS_Schema::update_meta( $meta );
	}

	/**
	 * Execute one batched INSERT.
	 *
	 * @since 1.0.0
	 * @param string   $table        Table name.
	 * @param string[] $placeholders Row placeholder groups.
	 * @param array    $values       Flat prepared values.
	 * @return void
	 */
	private static function flush( string $table, array $placeholders, array $values ): void {
		global $wpdb;

		$sql = "INSERT INTO `$table` (object_id, term, object_type, source, count, lang) VALUES " . implode( ',', $placeholders ) . ' ON DUPLICATE KEY UPDATE count = VALUES(count), object_type = VALUES(object_type)';
		$wpdb->query( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
	}
}
