<?php
/**
 * Main-query search interception.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Replaces the default WordPress search on the front-end results page with
 * index-ranked results, leaving the admin search untouched.
 *
 * @since 1.0.0
 */
class MVweb_SS_Search {

	const MAIN_LIMIT = 300;

	/**
	 * Ranked pool IDs from the last intercepted search, reused by the facet block
	 * to derive the price range without re-running the query.
	 *
	 * @var int[]
	 */
	private static $pool_ids = array();

	/**
	 * Ranked pool IDs from the current results-page search (P2.1 facets).
	 *
	 * @since 1.2.0
	 * @return int[]
	 */
	public static function pool_ids(): array {
		return self::$pool_ids;
	}

	/**
	 * Total ranked results the results page pulls and paginates over (P1.8). The
	 * admin caps this "results ceiling"; WordPress then paginates the post__in
	 * list natively, so a broad query is no longer truncated at a hard 100.
	 *
	 * @since 1.2.0
	 * @return int Between 20 and 1000.
	 */
	public static function results_max(): int {
		$max = (int) MVweb_SS_Settings::get( 'results_max', self::MAIN_LIMIT );

		// Never exceed the query engine's absolute cap, or the extra would be
		// silently truncated by MVweb_SS_Query::search().
		return max( 20, min( MVweb_SS_Query::MAX_LIMIT, $max ) );
	}

	/**
	 * Register interception hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'template_redirect', array( __CLASS__, 'maybe_redirect' ), 5 );
		add_action( 'pre_get_posts', array( __CLASS__, 'intercept' ), 20 );
		add_filter( 'posts_search', array( __CLASS__, 'blank_default_search' ), 10, 2 );
	}

	/**
	 * Redirect a matching search to its configured target before rendering.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function maybe_redirect(): void {
		if ( is_admin() || ! is_search() ) {
			return;
		}

		$term = trim( (string) get_search_query( false ) );

		if ( '' === $term ) {
			return;
		}

		$url = MVweb_SS_Settings::redirect_for( $term );

		if ( '' !== $url ) {
			wp_redirect( $url ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- admin-configured trusted target, query must match exactly.
			exit;
		}
	}

	/**
	 * Rewrite the front-end main search query to use the index.
	 *
	 * @since 1.0.0
	 * @param WP_Query $query Query.
	 * @return void
	 */
	public static function intercept( $query ): void {
		if ( is_admin() || ! $query instanceof WP_Query || ! $query->is_main_query() || ! $query->is_search() ) {
			return;
		}

		$term = trim( (string) $query->get( 's' ) );

		if ( '' === $term ) {
			return;
		}

		$scope = self::scoped_types();
		$types = empty( $scope ) ? MVweb_SS_Indexer::get_indexed_post_types() : $scope;
		$args  = array( 'limit' => self::results_max() );

		if ( ! empty( $scope ) ) {
			$args['post_types'] = $scope;
		}

		$category = self::scoped_category();

		if ( ! empty( $category['term_ids'] ) ) {
			$args['term_ids'] = $category['term_ids'];
			$args['taxonomy'] = $category['taxonomy'];
		}

		$ids = MVweb_SS_Query::search_ids( $term, $args );

		MVweb_SS_Log::record( $term, count( $ids ) );

		// Shopper-chosen sort (P2.2): re-order the relevance list by price/rating/
		// popularity/newest when requested; the empty default keeps relevance.
		$sort = self::requested_sort();

		if ( '' !== $sort && ! empty( $ids ) ) {
			$ids = MVweb_SS_Query::sort_ids( $ids, $sort );
		}

		// P2.1 price facet: narrow the ranked pool to the selected price range using
		// wc_product_meta_lookup (the same overlap source as the "до N" query filter),
		// preserving order. Category/brand facets are applied below as a tax_query.
		if ( ! empty( $ids ) ) {
			$price = self::selected_price();

			if ( null !== $price['min'] || null !== $price['max'] ) {
				$ids = MVweb_SS_Query::filter_ids_by_price( $ids, $price['min'], $price['max'] );
			}
		}

		// The facet counters read this pool, so it is taken after the price filter
		// has narrowed it — otherwise a category would promise more than ticking it
		// leaves, and the counts would not change with the chosen price range.
		self::$pool_ids = $ids;

		$query->set( 'mvweb_ss', true );
		$query->set( 'post_type', $types );
		$query->set( 'post__in', empty( $ids ) ? array( 0 ) : $ids );
		$query->set( 'orderby', 'post__in' );
		$query->set( 'ignore_sticky_posts', true );

		// P2.1 category/brand facets: WordPress intersects this tax_query with the
		// post__in pool and paginates the remainder natively, so relevance order and
		// pagination are preserved.
		if ( ! empty( $ids ) ) {
			$tax_query = self::facet_tax_query();

			if ( ! empty( $tax_query ) ) {
				$query->set( 'tax_query', $tax_query );
			}
		}

		// P1.8: paginate the ranked post__in list natively. A configured page size
		// wins; otherwise the site's Reading setting applies. WordPress derives the
		// page count from the full post__in list, so pages beyond the first now hold
		// the rest of the ranked pool instead of being truncated at a hard cap.
		$per_page = (int) MVweb_SS_Settings::get( 'results_per_page', 0 );

		if ( $per_page > 0 ) {
			$query->set( 'posts_per_page', $per_page );
		}
	}

	/**
	 * Sort options offered on the results page: value => translated label. Relevance
	 * (empty value) is the default and always first.
	 *
	 * @since 1.2.0
	 * @return array<string,string>
	 */
	public static function sort_options(): array {
		$options = array( '' => __( 'Relevance', 'mvweb-smart-search' ) );

		if ( class_exists( 'WooCommerce' ) ) {
			$options['popularity'] = __( 'Popularity', 'mvweb-smart-search' );
			$options['rating']     = __( 'Rating', 'mvweb-smart-search' );
			$options['price_asc']  = __( 'Price: low to high', 'mvweb-smart-search' );
			$options['price_desc'] = __( 'Price: high to low', 'mvweb-smart-search' );
		}

		$options['newest'] = __( 'Newest', 'mvweb-smart-search' );

		return $options;
	}

	/**
	 * Sort key requested on the results page, validated against sort_options().
	 *
	 * @since 1.2.0
	 * @return string One of the sort keys, or '' for relevance.
	 */
	public static function requested_sort(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only public sort, like the `s` query var.
		if ( ! isset( $_GET['mvweb_ss_sort'] ) ) {
			return '';
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$sort = sanitize_key( wp_unslash( $_GET['mvweb_ss_sort'] ) );

		return isset( self::sort_options()[ $sort ] ) ? $sort : '';
	}

	/**
	 * Category term IDs selected in the results-page facet (P2.1), sanitized.
	 *
	 * @since 1.2.0
	 * @return int[]
	 */
	public static function selected_facet_cats(): array {
		return self::facet_term_ids( 'mvweb_ss_fcat' );
	}

	/**
	 * Brand term IDs selected in the results-page facet (P2.1), sanitized.
	 *
	 * @since 1.2.0
	 * @return int[]
	 */
	public static function selected_facet_brands(): array {
		return self::facet_term_ids( 'mvweb_ss_fbrand' );
	}

	/**
	 * Read a facet's selected term IDs from the query string, sanitized to a
	 * unique list of positive integers.
	 *
	 * @since 1.2.0
	 * @param string $param GET parameter name.
	 * @return int[]
	 */
	private static function facet_term_ids( string $param ): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only public facet, like the `s` query var.
		if ( ! isset( $_GET[ $param ] ) ) {
			return array();
		}

		// absint() sanitizes every value; a read-only public facet needs no nonce.
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$ids = array_map( 'absint', (array) wp_unslash( $_GET[ $param ] ) );

		return array_values( array_unique( array_filter( $ids ) ) );
	}

	/**
	 * Price bounds selected in the results-page facet (P2.1). Either end may be
	 * null when the shopper left it blank; a reversed pair is swapped.
	 *
	 * @since 1.2.0
	 * @return array{min:float|null,max:float|null}
	 */
	public static function selected_price(): array {
		// Read-only public facet (like `s`): no nonce; the (float) cast sanitizes.
		// phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$min = isset( $_GET['mvweb_ss_pmin'] ) && '' !== $_GET['mvweb_ss_pmin'] ? (float) wp_unslash( $_GET['mvweb_ss_pmin'] ) : null;
		$max = isset( $_GET['mvweb_ss_pmax'] ) && '' !== $_GET['mvweb_ss_pmax'] ? (float) wp_unslash( $_GET['mvweb_ss_pmax'] ) : null;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

		if ( null !== $min && $min < 0 ) {
			$min = null;
		}

		if ( null !== $max && $max < 0 ) {
			$max = null;
		}

		if ( null !== $min && null !== $max && $min > $max ) {
			$tmp = $min;
			$min = $max;
			$max = $tmp;
		}

		return array(
			'min' => $min,
			'max' => $max,
		);
	}

	/**
	 * Build the tax_query that narrows the intercepted results to the selected
	 * category/brand facets. Applied on top of the ranked post__in, so WordPress
	 * intersects and paginates natively (P2.1). The price facet is handled by
	 * narrowing the ID pool (see intercept()), which keeps it on the same
	 * wc_product_meta_lookup source as the rest of the plugin's price logic.
	 *
	 * @since 1.2.0
	 * @return array Tax query clauses (empty when no category/brand facet is active).
	 */
	private static function facet_tax_query(): array {
		$tax = array();

		$cats = self::selected_facet_cats();

		if ( ! empty( $cats ) && class_exists( 'MVweb_SS_Categories' ) ) {
			$taxonomy = MVweb_SS_Categories::facet_category_taxonomy();

			if ( '' !== $taxonomy ) {
				$tax[] = array(
					'taxonomy'         => $taxonomy,
					'field'            => 'term_id',
					'terms'            => $cats,
					'include_children' => true,
				);
			}
		}

		$brands = self::selected_facet_brands();

		if ( ! empty( $brands ) && class_exists( 'MVweb_SS_Categories' ) ) {
			$taxonomy = MVweb_SS_Categories::facet_brand_taxonomy();

			if ( '' !== $taxonomy ) {
				$tax[] = array(
					'taxonomy' => $taxonomy,
					'field'    => 'term_id',
					'terms'    => $brands,
				);
			}
		}

		if ( count( $tax ) > 1 ) {
			$tax = array_merge( array( 'relation' => 'AND' ), $tax );
		}

		return $tax;
	}

	/**
	 * Post-type scope requested by a scoped search form, validated.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	private static function scoped_types(): array {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only public search scope, like the `s` query var.
		if ( ! isset( $_GET['mvweb_ss_types'] ) ) {
			return array();
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$raw = sanitize_text_field( wp_unslash( $_GET['mvweb_ss_types'] ) );

		return MVweb_SS_Indexer::sanitize_types_csv( $raw );
	}

	/**
	 * Category filter requested by the search form, resolved to term IDs.
	 *
	 * @since 1.0.0
	 * @return array{term_ids:int[],taxonomy:string}
	 */
	private static function scoped_category(): array {
		$empty = array(
			'term_ids' => array(),
			'taxonomy' => '',
		);

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only public search scope, like the `s` query var.
		if ( ! isset( $_GET['mvweb_ss_cat'] ) ) {
			return $empty;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$cat = absint( wp_unslash( $_GET['mvweb_ss_cat'] ) );

		if ( $cat <= 0 ) {
			return $empty;
		}

		$taxonomy = self::scoped_taxonomy();

		if ( '' === $taxonomy ) {
			return $empty;
		}

		$term_ids = MVweb_SS_Query::term_and_children( $cat, $taxonomy );

		return empty( $term_ids ) ? $empty : array(
			'term_ids' => $term_ids,
			'taxonomy' => $taxonomy,
		);
	}

	/**
	 * Taxonomy the category filter belongs to.
	 *
	 * A category chosen from the live dropdown carries its own taxonomy in the
	 * URL; a scope selector on the form uses the single configured taxonomy.
	 *
	 * @since 1.2.0
	 * @return string Validated, viewable taxonomy slug, or empty.
	 */
	private static function scoped_taxonomy(): string {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only public search scope, like the `s` query var.
		if ( isset( $_GET['mvweb_ss_tax'] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$tax = sanitize_key( wp_unslash( $_GET['mvweb_ss_tax'] ) );

			return ( '' !== $tax && taxonomy_exists( $tax ) && is_taxonomy_viewable( $tax ) ) ? $tax : '';
		}

		if ( MVweb_SS_Settings::get( 'cat_selector', false ) ) {
			return (string) MVweb_SS_Settings::get( 'cat_taxonomy', '' );
		}

		return '';
	}

	/**
	 * Remove the default LIKE search clause for our intercepted query.
	 *
	 * @since 1.0.0
	 * @param string   $search Search SQL.
	 * @param WP_Query $query  Query.
	 * @return string
	 */
	public static function blank_default_search( $search, $query ) {
		if ( $query instanceof WP_Query && $query->get( 'mvweb_ss' ) ) {
			return '';
		}

		return $search;
	}
}
