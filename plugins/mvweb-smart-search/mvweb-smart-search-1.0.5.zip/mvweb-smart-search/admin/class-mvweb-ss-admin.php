<?php
/**
 * Admin settings page and Settings API wiring.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the settings page under the MVweb hub and persists options.
 *
 * @since 1.0.0
 */
class MVweb_SS_Admin {

	const PAGE_SLUG = 'mvweb-smart-search';

	const GROUP = 'mvweb_ss_group';

	const EXPORT_ACTION = 'mvweb_ss_export_settings';

	/**
	 * Register admin hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'admin_menu', array( __CLASS__, 'add_page' ), 11 );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'update_option_' . MVweb_SS_Settings::OPTION, array( 'MVweb_SS_Rest', 'flush_cache' ) );
		add_action( 'admin_post_' . self::EXPORT_ACTION, array( __CLASS__, 'export_settings' ) );
		add_action( 'wp_ajax_mvweb_ss_import_settings', array( __CLASS__, 'ajax_import_settings' ) );
	}

	/**
	 * Add the settings page under the MVweb hub.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function add_page(): void {
		add_submenu_page(
			'mvweb-hub',
			__( 'MVweb Smart Search', 'mvweb-smart-search' ),
			__( 'Smart Search', 'mvweb-smart-search' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Register the settings option and its sanitizer.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_settings(): void {
		register_setting(
			self::GROUP,
			MVweb_SS_Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
			)
		);
	}

	/**
	 * Sanitize submitted settings.
	 *
	 * @since 1.0.0
	 * @param mixed $input Raw submitted value.
	 * @return array
	 */
	public static function sanitize( $input ): array {
		$input    = is_array( $input ) ? $input : array();
		$defaults = MVweb_SS_Settings::defaults();
		$current  = MVweb_SS_Settings::all();

		$public = get_post_types( array( 'public' => true ), 'names' );

		$types = array();
		if ( isset( $input['post_types'] ) && is_array( $input['post_types'] ) ) {
			foreach ( $input['post_types'] as $type ) {
				$type = sanitize_key( $type );
				if ( isset( $public[ $type ] ) ) {
					$types[] = $type;
				}
			}
		}

		$whitelist = array();
		if ( isset( $input['cf_whitelist'] ) && is_scalar( $input['cf_whitelist'] ) ) {
			$lines = preg_split( '/[\r\n]+/', (string) $input['cf_whitelist'] );
			foreach ( (array) $lines as $line ) {
				$key = sanitize_key( trim( $line ) );
				if ( '' !== $key && '_' !== $key[0] ) {
					$whitelist[] = $key;
				}
			}
		}

		if ( class_exists( 'WooCommerce' ) ) {
			$stock = ( isset( $input['stock'] ) && in_array( $input['stock'], array( 'show', 'hide', 'demote' ), true ) ) ? $input['stock'] : 'show';
			$cart  = ! empty( $input['add_to_cart'] );
		} else {
			$stock = (string) $current['stock'];
			$cart  = ! empty( $current['add_to_cart'] );
		}

		$weights = array();
		if ( isset( $input['weights'] ) && is_array( $input['weights'] ) ) {
			foreach ( MVweb_SS_Query::default_weights() as $source => $default ) {
				if ( isset( $input['weights'][ $source ] ) && '' !== $input['weights'][ $source ] ) {
					$weights[ $source ] = min( 100, max( 0, absint( $input['weights'][ $source ] ) ) );
				}
			}
		}

		$exclude = array();
		if ( isset( $input['exclude_ids'] ) && is_scalar( $input['exclude_ids'] ) ) {
			foreach ( preg_split( '/[^0-9]+/', (string) $input['exclude_ids'] ) as $id ) {
				$id = (int) $id;
				if ( $id > 0 ) {
					$exclude[] = $id;
				}
			}
		}

		$accent = isset( $input['accent_color'] ) ? sanitize_hex_color( (string) $input['accent_color'] ) : '';

		return array(
			'post_types'       => ! empty( $types ) ? array_values( array_unique( $types ) ) : $defaults['post_types'],
			'cf_whitelist'     => array_values( array_unique( $whitelist ) ),
			'fuzzy'            => ! empty( $input['fuzzy'] ),
			'strictness'       => ( isset( $input['strictness'] ) && in_array( $input['strictness'], array( 'loose', 'balanced', 'strict' ), true ) ) ? $input['strictness'] : 'balanced',
			'auto_replace'     => ! empty( $input['auto_replace'] ),
			'stock'            => $stock,
			'add_to_cart'      => $cart,
			'weights'          => $weights,
			'synonyms'         => ( isset( $input['synonyms'] ) && is_scalar( $input['synonyms'] ) ) ? sanitize_textarea_field( (string) $input['synonyms'] ) : '',
			'stopwords'        => ( isset( $input['stopwords'] ) && is_scalar( $input['stopwords'] ) ) ? sanitize_textarea_field( (string) $input['stopwords'] ) : '',
			'exclude_ids'      => array_values( array_unique( $exclude ) ),
			'pins'             => ( isset( $input['pins'] ) && is_scalar( $input['pins'] ) ) ? sanitize_textarea_field( (string) $input['pins'] ) : '',
			'redirects'        => ( isset( $input['redirects'] ) && is_scalar( $input['redirects'] ) ) ? sanitize_textarea_field( (string) $input['redirects'] ) : '',
			'accent_color'     => $accent ? $accent : $defaults['accent_color'],
			'placeholder'      => ( isset( $input['placeholder'] ) && is_scalar( $input['placeholder'] ) ) ? sanitize_text_field( (string) $input['placeholder'] ) : '',
			'text_no_results'  => ( isset( $input['text_no_results'] ) && is_scalar( $input['text_no_results'] ) ) ? sanitize_text_field( (string) $input['text_no_results'] ) : '',
			'text_see_all'     => ( isset( $input['text_see_all'] ) && is_scalar( $input['text_see_all'] ) ) ? sanitize_text_field( (string) $input['text_see_all'] ) : '',
			'panel_width'      => isset( $input['panel_width'] ) ? min( 1200, max( 320, absint( $input['panel_width'] ) ) ) : $defaults['panel_width'],
			'show_image'       => ! empty( $input['show_image'] ),
			'show_price'       => ! empty( $input['show_price'] ),
			'show_stock'       => ! empty( $input['show_stock'] ),
			'show_excerpt'     => ! empty( $input['show_excerpt'] ),
			'show_categories'  => ! empty( $input['show_categories'] ),
			'filter_tabs'      => ! empty( $input['filter_tabs'] ),
			'details_panel'    => ! empty( $input['details_panel'] ),
			'mobile_overlay'   => ! empty( $input['mobile_overlay'] ),
			'min_chars'        => isset( $input['min_chars'] ) ? min( 10, max( 1, absint( $input['min_chars'] ) ) ) : $defaults['min_chars'],
			'debounce_ms'      => isset( $input['debounce_ms'] ) ? min( 2000, max( 0, absint( $input['debounce_ms'] ) ) ) : $defaults['debounce_ms'],
			'sugg_limit'       => isset( $input['sugg_limit'] ) ? min( 50, max( 1, absint( $input['sugg_limit'] ) ) ) : $defaults['sugg_limit'],
			'per_group_limit'  => isset( $input['per_group_limit'] ) ? min( 50, max( 0, absint( $input['per_group_limit'] ) ) ) : $defaults['per_group_limit'],
			'highlight'        => ! empty( $input['highlight'] ),
			'fuzzy_notice'     => ( isset( $input['fuzzy_notice'] ) && in_array( $input['fuzzy_notice'], array( 'silent', 'showing', 'suggest' ), true ) ) ? $input['fuzzy_notice'] : 'silent',
			'group_order'      => ( isset( $input['group_order'] ) && in_array( $input['group_order'], array( 'products', 'content', 'pages' ), true ) ) ? $input['group_order'] : 'products',
			'results_per_page' => isset( $input['results_per_page'] ) ? min( 100, max( 0, absint( $input['results_per_page'] ) ) ) : $defaults['results_per_page'],
			'layout'           => ( isset( $input['layout'] ) && in_array( $input['layout'], array( 'list', 'grid' ), true ) ) ? $input['layout'] : 'list',
			'search_history'   => ! empty( $input['search_history'] ),
			'popular_searches' => ! empty( $input['popular_searches'] ),
			'popular_limit'    => isset( $input['popular_limit'] ) ? min( 20, max( 1, absint( $input['popular_limit'] ) ) ) : $defaults['popular_limit'],
			'cat_selector'     => ! empty( $input['cat_selector'] ),
			'cat_taxonomy'     => ( isset( $input['cat_taxonomy'] ) && taxonomy_exists( sanitize_key( (string) $input['cat_taxonomy'] ) ) ) ? sanitize_key( (string) $input['cat_taxonomy'] ) : $defaults['cat_taxonomy'],
			'bar_size'         => ( isset( $input['bar_size'] ) && in_array( $input['bar_size'], array( 's', 'm', 'l' ), true ) ) ? $input['bar_size'] : 'm',
			'bar_radius'       => ( isset( $input['bar_radius'] ) && in_array( $input['bar_radius'], array( 'square', 'rounded', 'pill' ), true ) ) ? $input['bar_radius'] : 'rounded',
			'bar_border_color' => isset( $input['bar_border_color'] ) ? (string) sanitize_hex_color( (string) $input['bar_border_color'] ) : '',
			'bar_bg_color'     => isset( $input['bar_bg_color'] ) ? (string) sanitize_hex_color( (string) $input['bar_bg_color'] ) : '',
			'bar_text_color'   => isset( $input['bar_text_color'] ) ? (string) sanitize_hex_color( (string) $input['bar_text_color'] ) : '',
			'bar_max_width'    => isset( $input['bar_max_width'] ) ? min( 1200, max( 200, absint( $input['bar_max_width'] ) ) ) : $defaults['bar_max_width'],
			'bar_height'       => ( isset( $input['bar_height'] ) && absint( $input['bar_height'] ) > 0 ) ? min( 100, max( 28, absint( $input['bar_height'] ) ) ) : 0,
			'bar_font_size'    => ( isset( $input['bar_font_size'] ) && absint( $input['bar_font_size'] ) > 0 ) ? min( 32, max( 10, absint( $input['bar_font_size'] ) ) ) : 0,
			'text_weight'      => ( isset( $input['text_weight'] ) && in_array( $input['text_weight'], array( 'normal', 'medium', 'bold' ), true ) ) ? $input['text_weight'] : 'normal',
			'submit_style'     => ( isset( $input['submit_style'] ) && in_array( $input['submit_style'], array( 'icon', 'text', 'hidden' ), true ) ) ? $input['submit_style'] : 'icon',
			'submit_text'      => ( isset( $input['submit_text'] ) && is_scalar( $input['submit_text'] ) ) ? sanitize_text_field( (string) $input['submit_text'] ) : '',
			'input_icon'       => ! empty( $input['input_icon'] ),
			'icon_plain'       => ! empty( $input['icon_plain'] ),
			'icon_color'       => isset( $input['icon_color'] ) ? (string) sanitize_hex_color( (string) $input['icon_color'] ) : '',
			'display_desktop'  => ( isset( $input['display_desktop'] ) && in_array( $input['display_desktop'], array( 'bar', 'icon', 'word' ), true ) ) ? $input['display_desktop'] : 'bar',
			'display_mobile'   => ( isset( $input['display_mobile'] ) && in_array( $input['display_mobile'], array( 'bar', 'icon', 'word' ), true ) ) ? $input['display_mobile'] : 'bar',
			'link_text'        => ( isset( $input['link_text'] ) && is_scalar( $input['link_text'] ) ) ? sanitize_text_field( (string) $input['link_text'] ) : '',
		);
	}

	/**
	 * Render the settings page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		require MVWEB_SS_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Enqueue admin assets on the plugin page only.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue( $hook ): void {
		if ( false === strpos( (string) $hook, self::PAGE_SLUG ) ) {
			return;
		}

		wp_enqueue_style( 'mvweb-ss-admin', MVWEB_SS_URL . 'admin/css/admin.css', array(), mvweb_ss_asset_ver( 'admin/css/admin.css' ) );
		wp_enqueue_style( 'mvweb-ss-plugin', MVWEB_SS_URL . 'admin/css/plugin.css', array( 'mvweb-ss-admin' ), mvweb_ss_asset_ver( 'admin/css/plugin.css' ) );
		wp_enqueue_script( 'mvweb-ss-admin', MVWEB_SS_URL . 'admin/js/admin.js', array(), mvweb_ss_asset_ver( 'admin/js/admin.js' ), true );

		wp_localize_script(
			'mvweb-ss-admin',
			'mvwebSSAdmin',
			array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'nonce'     => wp_create_nonce( MVweb_SS_Reindex::NONCE ),
				'dictNonce' => wp_create_nonce( MVweb_SS_Dictionaries::NONCE ),
				'i18n'      => array(
					'starting'       => __( 'Starting…', 'mvweb-smart-search' ),
					/* translators: 1: number of objects processed so far, 2: total number of objects */
					'running'        => __( 'Reindexing: %1$s of %2$s', 'mvweb-smart-search' ),
					/* translators: %s: number of objects indexed */
					'done'           => __( 'Done. Objects indexed: %s', 'mvweb-smart-search' ),
					'error'          => __( 'Error. Please try again.', 'mvweb-smart-search' ),
					'importEmpty'    => __( 'Paste the settings JSON.', 'mvweb-smart-search' ),
					'importOk'       => __( 'Settings imported. Reloading…', 'mvweb-smart-search' ),
					'importError'    => __( 'Import failed: check the JSON.', 'mvweb-smart-search' ),
					'dictInstalling' => __( 'Installing…', 'mvweb-smart-search' ),
					'dictRemoving'   => __( 'Removing…', 'mvweb-smart-search' ),
					'dictDone'       => __( 'Done. Reloading…', 'mvweb-smart-search' ),
					'dictError'      => __( 'Something went wrong. Try again.', 'mvweb-smart-search' ),
				),
			)
		);
	}

	/**
	 * Download the current settings as a JSON file.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function export_settings(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mvweb-smart-search' ) );
		}

		check_admin_referer( self::EXPORT_ACTION );

		$json = wp_json_encode( MVweb_SS_Settings::all(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=mvweb-smart-search-settings-' . gmdate( 'Y-m-d' ) . '.json' );

		echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON download, not HTML.

		exit;
	}

	/**
	 * Import settings from pasted JSON (validated through the sanitizer).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_import_settings(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mvweb-smart-search' ) ), 403 );
		}

		check_ajax_referer( MVweb_SS_Reindex::NONCE, 'nonce' );

		$raw     = isset( $_POST['data'] ) ? wp_unslash( $_POST['data'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- decoded as JSON then run through sanitize().
		$decoded = json_decode( (string) $raw, true );

		if ( ! is_array( $decoded ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid JSON.', 'mvweb-smart-search' ) ) );
		}

		update_option( MVweb_SS_Settings::OPTION, self::sanitize( $decoded ) );

		wp_send_json_success( array( 'message' => __( 'Settings imported.', 'mvweb-smart-search' ) ) );
	}
}
