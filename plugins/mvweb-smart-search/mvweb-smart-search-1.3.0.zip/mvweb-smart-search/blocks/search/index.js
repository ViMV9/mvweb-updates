( function ( blocks, element, serverSideRender, i18n ) {
	blocks.registerBlockType( 'mvweb-ss/search', {
		apiVersion: 3,
		title: i18n.__( 'MVweb Smart Search', 'mvweb-smart-search' ),
		description: i18n.__( 'Live site search with Russian morphology.', 'mvweb-smart-search' ),
		icon: 'search',
		category: 'widgets',
		supports: { html: false },
		edit: function () {
			return element.createElement( serverSideRender, { block: 'mvweb-ss/search' } );
		},
		save: function () {
			return null;
		},
	} );
} )( window.wp.blocks, window.wp.element, window.wp.serverSideRender, window.wp.i18n );
