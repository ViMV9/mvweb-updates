<?php
/**
 * Admin settings page template (MVweb Admin UI Kit — sidebar layout).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'setup'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.

$mvweb_ss_tabs = array(
	'setup'      => array(
		'label' => __( 'Getting started', 'mvweb-smart-search' ),
		'icon'  => 'rocket',
	),
	'general'    => array(
		'label' => __( 'General', 'mvweb-smart-search' ),
		'icon'  => 'sliders',
	),
	'appearance' => array(
		'label' => __( 'Appearance', 'mvweb-smart-search' ),
		'icon'  => 'palette',
	),
	'behavior'   => array(
		'label' => __( 'Behavior', 'mvweb-smart-search' ),
		'icon'  => 'bolt',
	),
	'coverage'   => array(
		'label' => __( 'Coverage', 'mvweb-smart-search' ),
		'icon'  => 'grid',
	),
	'relevance'  => array(
		'label' => __( 'Relevance', 'mvweb-smart-search' ),
		'icon'  => 'gear',
	),
	'analytics'  => array(
		'label' => __( 'Analytics', 'mvweb-smart-search' ),
		'icon'  => 'chart',
	),
	'index'      => array(
		'label' => __( 'Index', 'mvweb-smart-search' ),
		'icon'  => 'database',
	),
	'help'       => array(
		'label' => __( 'Help', 'mvweb-smart-search' ),
		'icon'  => 'help',
	),
);

$icons = array(
	'rocket'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="M12 15l-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/></svg>',
	'sliders'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>',
	'database' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/></svg>',
	'palette'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/></svg>',
	'bolt'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>',
	'grid'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
	'gear'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
	'help'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
	'chart'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="21" x2="21" y2="21"/><rect x="5" y="11" width="4" height="7" rx="1"/><rect x="11" y="6" width="4" height="12" rx="1"/><rect x="17" y="14" width="4" height="4" rx="1"/></svg>',
);
?>

<div class="wrap mvweb-settings">

	<h1 class="screen-reader-text"><?php esc_html_e( 'MVweb Smart Search', 'mvweb-smart-search' ); ?></h1>
	<hr class="wp-header-end">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">SS</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Smart Search', 'mvweb-smart-search' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_SS_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $mvweb_ss_tabs as $tab_id => $mvweb_ss_tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $tab_id ); ?>"
						class="mvweb-nav__link <?php echo $current_tab === $tab_id ? 'mvweb-nav__link--active' : ''; ?>"
						data-tab="<?php echo esc_attr( $tab_id ); ?>">
						<?php echo $icons[ $mvweb_ss_tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG. ?>
						<?php echo esc_html( $mvweb_ss_tab['label'] ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php settings_errors(); ?>

		<form method="post" action="options.php">
			<?php settings_fields( MVweb_SS_Admin::GROUP ); ?>

			<div id="setup" class="mvweb-tab-content <?php echo 'setup' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_SS_PATH . 'admin/views/tab-setup.php'; ?>
			</div>

			<div id="general" class="mvweb-tab-content <?php echo 'general' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_SS_PATH . 'admin/views/tab-general.php'; ?>
			</div>

			<div id="appearance" class="mvweb-tab-content <?php echo 'appearance' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_SS_PATH . 'admin/views/tab-appearance.php'; ?>
			</div>

			<div id="behavior" class="mvweb-tab-content <?php echo 'behavior' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_SS_PATH . 'admin/views/tab-behavior.php'; ?>
			</div>

			<div id="coverage" class="mvweb-tab-content <?php echo 'coverage' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_SS_PATH . 'admin/views/tab-coverage.php'; ?>
			</div>

			<div id="relevance" class="mvweb-tab-content <?php echo 'relevance' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_SS_PATH . 'admin/views/tab-relevance.php'; ?>
			</div>

			<div id="analytics" class="mvweb-tab-content <?php echo 'analytics' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_SS_PATH . 'admin/views/tab-analytics.php'; ?>
			</div>

			<div id="index" class="mvweb-tab-content <?php echo 'index' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_SS_PATH . 'admin/views/tab-index.php'; ?>
			</div>

			<div id="help" class="mvweb-tab-content <?php echo 'help' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_SS_PATH . 'admin/views/tab-help.php'; ?>
			</div>

			<div class="mvweb-submit">
				<button type="submit" name="submit" class="mvweb-btn mvweb-btn--primary"><?php esc_html_e( 'Save Changes', 'mvweb-smart-search' ); ?></button>
			</div>
		</form>

	</main>
</div>
