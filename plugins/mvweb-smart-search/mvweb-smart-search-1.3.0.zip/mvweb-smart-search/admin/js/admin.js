/**
 * Admin JavaScript for MVweb Smart Search.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		initTabs();
		initReindex();
		initConfirm();
		initSettingsIO();
		initDictionaries();
		initCopy();
		initRangeOutputs();
	} );

	/**
	 * Two-way binding between each range slider and its number input, so the
	 * value can be dragged or typed. The range carries the field name, so the
	 * typed number is mirrored onto it and submitted with the form.
	 */
	function initRangeOutputs() {
		var ranges = document.querySelectorAll( '.mvweb-ss-range[data-output]' );

		Array.prototype.forEach.call( ranges, function ( range ) {
			var number = document.getElementById( range.getAttribute( 'data-output' ) );

			if ( ! number ) {
				return;
			}

			var min = parseFloat( range.min );
			var max = parseFloat( range.max );

			range.addEventListener( 'input', function () {
				number.value = range.value;
			} );

			number.addEventListener( 'input', function () {
				var value = parseFloat( number.value );

				if ( isNaN( value ) ) {
					return;
				}

				if ( ! isNaN( min ) && value < min ) {
					value = min;
				}

				if ( ! isNaN( max ) && value > max ) {
					value = max;
				}

				range.value = value;
			} );

			// On blur, snap the field back to the clamped, submitted value (so a
			// typed 999 or an emptied field shows what the form will actually save).
			number.addEventListener( 'blur', function () {
				number.value = range.value;
			} );
		} );
	}

	/**
	 * Install / update / remove ready-made dictionary packs via AJAX.
	 */
	function initDictionaries() {
		if ( typeof window.mvwebSSAdmin === 'undefined' ) {
			return;
		}

		var cfg = window.mvwebSSAdmin;
		var status = document.getElementById( 'mvweb-ss-dict-status' );

		if ( ! status ) {
			return;
		}

		document.addEventListener( 'click', function ( event ) {
			var button = event.target.closest( '.mvweb-ss-dict-action' );

			if ( ! button ) {
				return;
			}

			var remove = 'remove' === button.getAttribute( 'data-action' );
			var slug = button.getAttribute( 'data-slug' );

			if ( ! slug ) {
				return;
			}

			button.disabled = true;
			status.textContent = remove ? cfg.i18n.dictRemoving : cfg.i18n.dictInstalling;

			var body = new URLSearchParams();
			body.append( 'action', remove ? 'mvweb_ss_remove_dictionary' : 'mvweb_ss_install_dictionary' );
			body.append( 'nonce', cfg.dictNonce );
			body.append( 'slug', slug );

			fetch( cfg.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body.toString(),
			} ).then( function ( res ) {
				return res.json();
			} ).then( function ( res ) {
				if ( res && res.success ) {
					status.textContent = cfg.i18n.dictDone;
					window.location.reload();
				} else {
					button.disabled = false;
					status.textContent = ( res && res.data && res.data.message ) ? res.data.message : cfg.i18n.dictError;
				}
			} ).catch( function () {
				button.disabled = false;
				status.textContent = cfg.i18n.dictError;
			} );
		} );
	}

	/**
	 * Copy-to-clipboard buttons (.mvweb-ss-copy[data-copy]).
	 */
	function initCopy() {
		document.addEventListener( 'click', function ( event ) {
			var button = event.target.closest( '.mvweb-ss-copy' );

			if ( ! button ) {
				return;
			}

			copyText( button.getAttribute( 'data-copy' ) || '', button );
		} );
	}

	/**
	 * Briefly show the "copied" label, then restore the original.
	 * Re-entrant: captures the real original once and resets the timer on repeat clicks.
	 */
	function flashCopied( button ) {
		var copied = button.getAttribute( 'data-copied' );

		if ( ! copied ) {
			return;
		}

		if ( button.mvwebCopyTimer ) {
			clearTimeout( button.mvwebCopyTimer );
		} else {
			button.mvwebCopyOriginal = button.textContent;
			button.textContent = copied;
		}

		button.mvwebCopyTimer = setTimeout( function () {
			button.textContent = button.mvwebCopyOriginal;
			button.mvwebCopyTimer = null;
		}, 1500 );
	}

	/**
	 * Legacy copy via a hidden textarea. Returns whether the copy succeeded.
	 */
	function legacyCopy( text ) {
		var field = document.createElement( 'textarea' );
		field.value = text;
		field.setAttribute( 'readonly', '' );
		field.style.position = 'absolute';
		field.style.left = '-9999px';
		document.body.appendChild( field );
		field.select();

		var ok = false;
		try {
			ok = document.execCommand( 'copy' );
		} catch ( e ) {}

		document.body.removeChild( field );
		return ok;
	}

	/**
	 * Copy text to the clipboard, falling back to the legacy path, and only
	 * confirm to the user when the copy actually succeeded.
	 */
	function copyText( text, button ) {
		if ( navigator.clipboard && navigator.clipboard.writeText ) {
			navigator.clipboard.writeText( text ).then( function () {
				flashCopied( button );
			} ).catch( function () {
				if ( legacyCopy( text ) ) {
					flashCopied( button );
				}
			} );
		} else if ( legacyCopy( text ) ) {
			flashCopied( button );
		}
	}

	/**
	 * Import settings from pasted JSON via AJAX.
	 */
	function initSettingsIO() {
		if ( typeof window.mvwebSSAdmin === 'undefined' ) {
			return;
		}

		var cfg = window.mvwebSSAdmin;
		var button = document.getElementById( 'mvweb-ss-import' );
		var input = document.getElementById( 'mvweb-ss-import-data' );
		var status = document.getElementById( 'mvweb-ss-import-status' );

		if ( ! button || ! input || ! status ) {
			return;
		}

		button.addEventListener( 'click', function () {
			var data = input.value.trim();

			if ( ! data ) {
				status.textContent = cfg.i18n.importEmpty;
				return;
			}

			button.disabled = true;

			var body = new URLSearchParams();
			body.append( 'action', 'mvweb_ss_import_settings' );
			body.append( 'nonce', cfg.nonce );
			body.append( 'data', data );

			fetch( cfg.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body.toString(),
			} ).then( function ( res ) {
				return res.json();
			} ).then( function ( res ) {
				if ( res && res.success ) {
					status.textContent = cfg.i18n.importOk;
					window.location.reload();
				} else {
					button.disabled = false;
					status.textContent = cfg.i18n.importError;
				}
			} ).catch( function () {
				button.disabled = false;
				status.textContent = cfg.i18n.importError;
			} );
		} );
	}

	/**
	 * Ask for confirmation before following a destructive link.
	 */
	function initConfirm() {
		document.addEventListener( 'click', function ( event ) {
			var link = event.target.closest( '.mvweb-ss-confirm' );

			if ( link && ! window.confirm( link.getAttribute( 'data-confirm' ) || '' ) ) {
				event.preventDefault();
			}
		} );
	}

	/**
	 * Sidebar tab navigation (UI Kit).
	 */
	function initTabs() {
		var links = document.querySelectorAll( '.mvweb-nav__link' );
		var panels = document.querySelectorAll( '.mvweb-tab-content' );

		if ( ! links.length || ! panels.length ) {
			return;
		}

		Array.prototype.forEach.call( links, function ( link ) {
			link.addEventListener( 'click', function ( event ) {
				event.preventDefault();
				var target = link.getAttribute( 'data-tab' );

				Array.prototype.forEach.call( links, function ( l ) {
					l.classList.remove( 'mvweb-nav__link--active' );
				} );
				Array.prototype.forEach.call( panels, function ( p ) {
					p.classList.remove( 'active' );
				} );

				link.classList.add( 'mvweb-nav__link--active' );
				var panel = document.getElementById( target );
				if ( panel ) {
					panel.classList.add( 'active' );
				}
			} );
		} );
	}

	/**
	 * Reindex button + progress polling.
	 */
	function initReindex() {
		if ( typeof window.mvwebSSAdmin === 'undefined' ) {
			return;
		}

		var cfg = window.mvwebSSAdmin;
		var button = document.getElementById( 'mvweb-ss-reindex' );
		var status = document.getElementById( 'mvweb-ss-reindex-status' );

		if ( ! button || ! status ) {
			return;
		}

		var running = false;

		function post( action ) {
			var body = new URLSearchParams();
			body.append( 'action', action );
			body.append( 'nonce', cfg.nonce );

			return fetch( cfg.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body.toString(),
			} ).then( function ( res ) {
				return res.json();
			} );
		}

		function updateCount( data ) {
			var el = document.getElementById( 'mvweb-ss-index-count' );
			if ( el && data && typeof data.in_index !== 'undefined' ) {
				el.textContent = data.in_index;
			}
		}

		function drawRunning( data ) {
			updateCount( data );
			status.textContent = cfg.i18n.running.replace( '%1$s', data.processed ).replace( '%2$s', data.total );
		}

		function finish( data ) {
			running = false;
			button.disabled = false;
			updateCount( data );
			status.textContent = cfg.i18n.done.replace( '%s', ( data && typeof data.in_index !== 'undefined' ) ? data.in_index : '' );
		}

		function fail() {
			running = false;
			button.disabled = false;
			status.textContent = cfg.i18n.error;
		}

		// Drive the reindex one batch at a time from the browser so it never
		// stalls waiting on WP-Cron and never runs more than one batch at once.
		function step() {
			post( 'mvweb_ss_reindex_step' ).then( function ( res ) {
				if ( ! res || ! res.success ) {
					fail();
					return;
				}
				if ( res.data.status === 'running' ) {
					drawRunning( res.data );
					step();
				} else {
					finish( res.data );
				}
			} ).catch( fail );
		}

		button.addEventListener( 'click', function () {
			if ( running ) {
				return;
			}
			running = true;
			button.disabled = true;
			status.textContent = cfg.i18n.starting;

			post( 'mvweb_ss_reindex_start' ).then( function ( res ) {
				if ( ! res || ! res.success ) {
					fail();
					return;
				}
				// started === false means a reindex is already running (e.g.
				// another tab) — don't drive a second loop over the same state.
				if ( res.data && res.data.started === false ) {
					running = false;
					button.disabled = false;
					status.textContent = cfg.i18n.running.replace( '%1$s', res.data.processed ).replace( '%2$s', res.data.total );
					return;
				}
				updateCount( res.data );
				step();
			} ).catch( fail );
		} );
	}
} )();
