<?php
/**
 * Classic sidebar widget wrapping the smart search form.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Provides the search form to classic widget areas (and, via the core
 * legacy-widget wrapper, the block-based widgets screen).
 *
 * @since 1.0.0
 */
class MVweb_SS_Widget extends WP_Widget {

	/**
	 * Define the widget.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		parent::__construct(
			'mvweb_ss_widget',
			__( 'MVweb Smart Search', 'mvweb-smart-search' ),
			array(
				'description'                 => __( 'Live site search with Russian morphology.', 'mvweb-smart-search' ),
				'customize_selective_refresh' => true,
			)
		);
	}

	/**
	 * Hook the widget registration.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'widgets_init', array( __CLASS__, 'register_self' ) );
	}

	/**
	 * Register the widget class with WordPress.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_self(): void {
		register_widget( __CLASS__ );
	}

	/**
	 * Front-end output.
	 *
	 * @since 1.0.0
	 * @param array $args     Sidebar wrapper markup.
	 * @param array $instance Saved widget settings.
	 * @return void
	 */
	public function widget( $args, $instance ) {
		$title = apply_filters( 'widget_title', isset( $instance['title'] ) ? $instance['title'] : '', $instance, $this->id_base );

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- theme-provided wrapper markup.

		if ( '' !== (string) $title ) {
			echo $args['before_title'] . esc_html( $title ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- theme wrappers; title escaped.
		}

		$form = MVweb_SS_Frontend::render_form(
			array(
				'placeholder' => isset( $instance['placeholder'] ) ? $instance['placeholder'] : '',
				'accent'      => isset( $instance['accent'] ) ? $instance['accent'] : '',
				'types'       => isset( $instance['types'] ) ? $instance['types'] : '',
			)
		);

		echo $form; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render_form returns escaped markup.

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- theme-provided wrapper markup.
	}

	/**
	 * Settings form shown in wp-admin.
	 *
	 * @since 1.0.0
	 * @param array $instance Current settings.
	 * @return void
	 */
	public function form( $instance ) {
		$title       = isset( $instance['title'] ) ? (string) $instance['title'] : '';
		$placeholder = isset( $instance['placeholder'] ) ? (string) $instance['placeholder'] : '';
		$accent      = isset( $instance['accent'] ) && '' !== $instance['accent'] ? (string) $instance['accent'] : '#793ea4';
		$types       = isset( $instance['types'] ) ? (string) $instance['types'] : '';
		$selected    = array_flip( array_filter( array_map( 'trim', explode( ',', $types ) ) ) );
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'mvweb-smart-search' ); ?></label>
			<input class="widefat" type="text" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'placeholder' ) ); ?>"><?php esc_html_e( 'Placeholder:', 'mvweb-smart-search' ); ?></label>
			<input class="widefat" type="text" id="<?php echo esc_attr( $this->get_field_id( 'placeholder' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'placeholder' ) ); ?>" value="<?php echo esc_attr( $placeholder ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'accent' ) ); ?>"><?php esc_html_e( 'Accent color:', 'mvweb-smart-search' ); ?></label>
			<input type="color" id="<?php echo esc_attr( $this->get_field_id( 'accent' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'accent' ) ); ?>" value="<?php echo esc_attr( $accent ); ?>">
		</p>
		<p style="margin-bottom:4px"><?php esc_html_e( 'Search only these types (leave all off for everything):', 'mvweb-smart-search' ); ?></p>
		<?php foreach ( MVweb_SS_Indexer::get_indexed_post_types() as $type ) : ?>
			<p style="margin:0 0 4px">
				<label>
					<input type="checkbox" name="<?php echo esc_attr( $this->get_field_name( 'types' ) ); ?>[]" value="<?php echo esc_attr( $type ); ?>" <?php checked( isset( $selected[ $type ] ) ); ?>>
					<?php echo esc_html( $type ); ?>
				</label>
			</p>
		<?php endforeach; ?>
		<?php
	}

	/**
	 * Sanitize and persist settings.
	 *
	 * @since 1.0.0
	 * @param array $new_instance Submitted values.
	 * @param array $old_instance Previous values.
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		$raw   = isset( $new_instance['types'] ) ? (array) $new_instance['types'] : array();
		$types = implode( ',', MVweb_SS_Indexer::sanitize_types_csv( implode( ',', array_map( 'strval', $raw ) ) ) );

		return array(
			'title'       => isset( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '',
			'placeholder' => isset( $new_instance['placeholder'] ) ? sanitize_text_field( $new_instance['placeholder'] ) : '',
			'accent'      => isset( $new_instance['accent'] ) ? (string) sanitize_hex_color( $new_instance['accent'] ) : '',
			'types'       => $types,
		);
	}
}
