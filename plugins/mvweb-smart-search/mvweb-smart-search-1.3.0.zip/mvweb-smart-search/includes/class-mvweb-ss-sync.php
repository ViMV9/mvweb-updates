<?php
/**
 * Incremental index synchronization on content changes.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Keeps the search index in sync with post/product edits, guarding against
 * hook recursion and needless work on autosaves/revisions.
 *
 * @since 1.0.0
 */
class MVweb_SS_Sync {

	/**
	 * Re-entrancy guard: true while an index write is in progress.
	 *
	 * @var bool
	 */
	private static $busy = false;

	/**
	 * Object IDs already synced during this request (dedupes save_post +
	 * transition_post_status firing for the same edit).
	 *
	 * @var array<int,bool>
	 */
	private static $synced = array();

	/**
	 * Register synchronization hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'save_post', array( __CLASS__, 'on_save' ), 20 );
		add_action( 'transition_post_status', array( __CLASS__, 'on_transition' ), 20, 3 );
		add_action( 'wp_trash_post', array( __CLASS__, 'on_remove' ) );
		add_action( 'untrashed_post', array( __CLASS__, 'on_reindex' ) );
		add_action( 'deleted_post', array( __CLASS__, 'on_remove' ) );

		add_action( 'woocommerce_new_product', array( __CLASS__, 'on_reindex' ) );
		add_action( 'woocommerce_update_product', array( __CLASS__, 'on_reindex' ) );
		add_action( 'woocommerce_update_product_variation', array( __CLASS__, 'on_variation' ) );

		add_action( 'mvweb_pi_product_created', array( __CLASS__, 'on_import' ) );
		add_action( 'mvweb_pi_product_updated', array( __CLASS__, 'on_import' ) );

		// Completion hooks of popular importers that write product data after the
		// standard save flow (so save_post indexed a bare object) or defer the
		// usual hooks entirely. Each fires once the object is complete.
		add_action( 'pmxi_saved_post', array( __CLASS__, 'on_import' ) );
		add_action( 'woocommerce_product_import_inserted_product_object', array( __CLASS__, 'on_import_object' ) );

		// Public integration point: a third-party importer can register its own
		// completion hook (one that passes the object ID first) without editing core.
		foreach ( (array) apply_filters( 'mvweb_ss_reindex_hooks', array() ) as $hook ) {
			if ( is_string( $hook ) && '' !== $hook ) {
				add_action( $hook, array( __CLASS__, 'on_import' ) );
			}
		}
	}

	/**
	 * Handle save_post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function on_save( $post_id ): void {
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		self::sync( (int) $post_id );
	}

	/**
	 * Handle status transitions (covers scheduled publish, quick edit, trash).
	 *
	 * @since 1.0.0
	 * @param string  $new_status New status.
	 * @param string  $old_status Old status.
	 * @param WP_Post $post       Post object.
	 * @return void
	 */
	public static function on_transition( $new_status, $old_status, $post ): void {
		if ( $post instanceof WP_Post ) {
			self::sync( (int) $post->ID );
		}
	}

	/**
	 * Reindex a single object (create/update/untrash).
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function on_reindex( $post_id ): void {
		self::sync( (int) $post_id );
	}

	/**
	 * Re-index a product once MVweb Price Importer finished writing it.
	 *
	 * The importer bypasses WC_Product::save() and writes the product type, SKU,
	 * categories and attributes with direct meta/term calls after wp_insert_post(),
	 * so the save_post pass indexed a bare product (wc_get_product() returned false
	 * at that point). These completion actions fire once the product is complete;
	 * clearing the per-request dedup guard lets this pass replace the bare index.
	 *
	 * @since 1.1.0
	 * @param int $post_id Product ID.
	 * @return void
	 */
	public static function on_import( $post_id ): void {
		unset( self::$synced[ (int) $post_id ] );
		self::sync( (int) $post_id );
	}

	/**
	 * Re-index after the native WooCommerce CSV importer inserted a product.
	 *
	 * That hook passes the WC_Product object, not an ID, so unwrap it and route
	 * through the same completion path as the other importers.
	 *
	 * @since 1.2.0
	 * @param mixed $object Imported product object.
	 * @return void
	 */
	public static function on_import_object( $object ): void {
		if ( is_object( $object ) && method_exists( $object, 'get_id' ) ) {
			self::on_import( (int) $object->get_id() );
		}
	}

	/**
	 * A product variation changed — reindex its parent product.
	 *
	 * @since 1.0.0
	 * @param int $variation_id Variation ID.
	 * @return void
	 */
	public static function on_variation( $variation_id ): void {
		$parent_id = (int) wp_get_post_parent_id( (int) $variation_id );

		if ( $parent_id > 0 ) {
			self::sync( $parent_id );
		}
	}

	/**
	 * Remove an object from the index (trash/delete).
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function on_remove( $post_id ): void {
		if ( self::$busy ) {
			return;
		}

		MVweb_SS_Indexer::remove_object( (int) $post_id );
	}

	/**
	 * Index an object, guarded against re-entrancy and non-indexed types.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	private static function sync( int $post_id ): void {
		if ( self::$busy || $post_id <= 0 ) {
			return;
		}

		if ( ! in_array( get_post_type( $post_id ), MVweb_SS_Indexer::get_indexed_post_types(), true ) ) {
			return;
		}

		if ( isset( self::$synced[ $post_id ] ) ) {
			return;
		}

		self::$synced[ $post_id ] = true;
		self::$busy               = true;

		try {
			MVweb_SS_Indexer::index_object( $post_id );
			MVweb_SS_Rest::flush_cache();
		} finally {
			self::$busy = false;
		}
	}
}
