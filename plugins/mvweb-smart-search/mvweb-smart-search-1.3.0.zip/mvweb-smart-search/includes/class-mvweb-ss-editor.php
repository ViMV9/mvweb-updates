<?php
/**
 * Per-post "exclude from search" control in the editor.
 *
 * @package mvweb_ss
 * @since   1.1.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds a checkbox to the post editor that keeps a single entry out of the
 * search index, stored as the `_mvweb_ss_exclude` post meta. The incremental
 * Sync re-indexes the post on save, so unchecking it restores the entry.
 *
 * @since 1.1.0
 */
class MVweb_SS_Editor {

	const META_KEY = '_mvweb_ss_exclude';

	const NONCE = 'mvweb_ss_editor';

	/**
	 * Register editor hooks.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'add_meta_boxes', array( __CLASS__, 'add_meta_box' ) );
		add_action( 'save_post', array( __CLASS__, 'save' ), 10 );
	}

	/**
	 * Whether a single post is flagged to stay out of the index.
	 *
	 * @since 1.1.0
	 * @param int $post_id Post ID.
	 * @return bool
	 */
	public static function is_excluded( int $post_id ): bool {
		return '1' === (string) get_post_meta( $post_id, self::META_KEY, true );
	}

	/**
	 * Register the meta box on every indexed post type.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function add_meta_box(): void {
		foreach ( MVweb_SS_Indexer::get_indexed_post_types() as $type ) {
			add_meta_box(
				'mvweb-ss-exclude',
				__( 'Smart Search', 'mvweb-smart-search' ),
				array( __CLASS__, 'render' ),
				$type,
				'side',
				'default'
			);
		}
	}

	/**
	 * Render the checkbox.
	 *
	 * @since 1.1.0
	 * @param WP_Post $post Post being edited.
	 * @return void
	 */
	public static function render( $post ): void {
		wp_nonce_field( self::NONCE, self::NONCE );
		?>
		<p>
			<label>
				<input type="checkbox" name="mvweb_ss_exclude" value="1" <?php checked( self::is_excluded( (int) $post->ID ) ); ?> />
				<?php esc_html_e( 'Exclude from search results', 'mvweb-smart-search' ); ?>
			</label>
		</p>
		<?php
	}

	/**
	 * Persist the checkbox; Sync (save_post priority 20) reindexes afterwards.
	 *
	 * @since 1.1.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function save( $post_id ): void {
		if ( ! isset( $_POST[ self::NONCE ] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST[ self::NONCE ] ) ), self::NONCE ) ) {
			return;
		}

		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( isset( $_POST['mvweb_ss_exclude'] ) ) {
			update_post_meta( $post_id, self::META_KEY, '1' );
		} else {
			delete_post_meta( $post_id, self::META_KEY );
		}
	}
}
