<?php
/**
 * Navigation-menu integration: a draggable "Search" item added from the
 * Appearance → Menus editor, rendered as the live search bar on the front-end.
 *
 * @package mvweb_ss
 * @since   1.1.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds a metabox to the classic menu editor whose item, once dropped anywhere
 * in a menu, is replaced on the front-end by MVweb_SS_Frontend::render_form().
 *
 * Classic menus only. Block themes render navigation through the core/navigation
 * block, where the search goes in as a core/search block (handled elsewhere).
 *
 * @since 1.1.0
 */
class MVweb_SS_Nav {

	/**
	 * CSS class attached to the menu item and stored in `_menu_item_classes`,
	 * used to detect our item on the front-end. A class is used instead of a
	 * custom `menu-item-object` because core forces the object to `custom` for
	 * custom-link items, whereas it leaves the classes untouched.
	 *
	 * @since 1.1.0
	 * @var string
	 */
	const MENU_CLASS = 'mvweb-ss-menu-item';

	/**
	 * Register hooks.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'load-nav-menus.php', array( __CLASS__, 'add_meta_box' ) );
		add_filter( 'walker_nav_menu_start_el', array( __CLASS__, 'render_item' ), 10, 4 );
	}

	/**
	 * Register the menu-editor metabox.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function add_meta_box(): void {
		add_meta_box(
			'mvweb-ss-nav',
			__( 'MVweb Search', 'mvweb-smart-search' ),
			array( __CLASS__, 'meta_box' ),
			'nav-menus',
			'side',
			'low'
		);
	}

	/**
	 * Metabox body: a single checklist item plus the core "Add to Menu" button.
	 *
	 * Mirrors the markup of the core post-type metabox so the built-in
	 * nav-menu.js handler creates the item — no custom AJAX needed. The item is
	 * a custom link carrying our MENU_CLASS marker.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function meta_box(): void {
		?>
		<div id="mvweb-ss-nav-metabox" class="posttypediv">
			<div class="tabs-panel tabs-panel-active">
				<ul class="categorychecklist form-no-clear">
					<li>
						<label class="menu-item-title">
							<input type="checkbox" class="menu-item-checkbox" name="menu-item[-1][menu-item-object-id]" value="-1"> <?php esc_html_e( 'Search', 'mvweb-smart-search' ); ?>
						</label>
						<input type="hidden" class="menu-item-type" name="menu-item[-1][menu-item-type]" value="custom">
						<input type="hidden" class="menu-item-title" name="menu-item[-1][menu-item-title]" value="<?php esc_attr_e( 'Search', 'mvweb-smart-search' ); ?>">
						<input type="hidden" class="menu-item-url" name="menu-item[-1][menu-item-url]" value="#mvweb-ss">
						<input type="hidden" class="menu-item-classes" name="menu-item[-1][menu-item-classes]" value="<?php echo esc_attr( self::MENU_CLASS ); ?>">
					</li>
				</ul>
			</div>
			<p class="button-controls wp-clearfix">
				<span class="add-to-menu">
					<input type="submit" class="button submit-add-to-menu right" value="<?php esc_attr_e( 'Add to Menu', 'mvweb-smart-search' ); ?>" name="add-mvweb-ss-menu-item" id="submit-mvweb-ss-nav-metabox">
					<span class="spinner"></span>
				</span>
			</p>
		</div>
		<?php
	}

	/**
	 * Replace our menu item's link with the live search bar on the front-end.
	 *
	 * @since 1.1.0
	 * @param string   $item_output The menu item's starting HTML.
	 * @param object   $item        Menu item data (WP_Post or stdClass).
	 * @param int      $depth       Depth of the menu item.
	 * @param stdClass $args        wp_nav_menu arguments.
	 * @return string
	 */
	public static function render_item( $item_output, $item, $depth, $args ): string {
		unset( $depth, $args );

		if ( is_object( $item ) && ! empty( $item->classes ) && is_array( $item->classes ) && in_array( self::MENU_CLASS, $item->classes, true ) ) {
			return MVweb_SS_Frontend::render_form();
		}

		return (string) $item_output;
	}
}
