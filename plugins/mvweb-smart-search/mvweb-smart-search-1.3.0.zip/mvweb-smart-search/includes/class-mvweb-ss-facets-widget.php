<?php
/**
 * Classic sidebar widget wrapping the results-page facet panel (P2.1).
 *
 * @package mvweb_ss
 * @since   1.2.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shows the category/brand/price facet panel in a classic widget area. Renders
 * only on a search results page; everywhere else it outputs nothing.
 *
 * @since 1.2.0
 */
class MVweb_SS_Facets_Widget extends WP_Widget {

	/**
	 * Define the widget.
	 *
	 * @since 1.2.0
	 */
	public function __construct() {
		parent::__construct(
			'mvweb_ss_facets_widget',
			__( 'MVweb Search Filters', 'mvweb-smart-search' ),
			array(
				'description' => __( 'Category, brand and price filters shown on the search results page.', 'mvweb-smart-search' ),
			)
		);
	}

	/**
	 * Front-end output (only renders on a search results page).
	 *
	 * @since 1.2.0
	 * @param array $args     Sidebar wrapper markup.
	 * @param array $instance Saved widget settings.
	 * @return void
	 */
	public function widget( $args, $instance ) {
		$panel = MVweb_SS_Facets::render();

		if ( '' === $panel ) {
			return;
		}

		$title = apply_filters( 'widget_title', isset( $instance['title'] ) ? $instance['title'] : '', $instance, $this->id_base );

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- theme-provided wrapper markup.

		if ( '' !== (string) $title ) {
			echo $args['before_title'] . esc_html( $title ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- theme wrappers; title escaped.
		}

		echo $panel; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- render() returns escaped markup.

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- theme-provided wrapper markup.
	}

	/**
	 * Settings form shown in wp-admin.
	 *
	 * @since 1.2.0
	 * @param array $instance Current settings.
	 * @return void
	 */
	public function form( $instance ) {
		$title = isset( $instance['title'] ) ? (string) $instance['title'] : __( 'Filters', 'mvweb-smart-search' );
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'mvweb-smart-search' ); ?></label>
			<input class="widefat" type="text" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p class="description"><?php esc_html_e( 'Shows only on the search results page.', 'mvweb-smart-search' ); ?></p>
		<?php
	}

	/**
	 * Sanitize and persist settings.
	 *
	 * @since 1.2.0
	 * @param array $new_instance Submitted values.
	 * @param array $old_instance Previous values.
	 * @return array
	 */
	public function update( $new_instance, $old_instance ) {
		return array(
			'title' => isset( $new_instance['title'] ) ? sanitize_text_field( $new_instance['title'] ) : '',
		);
	}
}
