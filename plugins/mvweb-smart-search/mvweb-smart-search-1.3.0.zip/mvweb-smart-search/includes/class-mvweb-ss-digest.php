<?php
/**
 * Weekly search digest email.
 *
 * @package mvweb_ss
 * @since   1.1.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sends the site owner a weekly summary of top and no-result searches, so the
 * plugin's insights stay top-of-mind. Off by default; opt-in per site.
 *
 * @since 1.1.0
 */
class MVweb_SS_Digest {

	const EVENT = 'mvweb_ss_weekly_digest';

	/**
	 * Register cron and scheduling hooks.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'init', array( __CLASS__, 'sync_schedule' ) );
		add_action( self::EVENT, array( __CLASS__, 'send' ) );
		add_action( 'update_option_' . MVweb_SS_Settings::OPTION, array( __CLASS__, 'sync_schedule' ) );
	}

	/**
	 * Schedule or clear the weekly event to match the current setting.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function sync_schedule(): void {
		$enabled   = (bool) MVweb_SS_Settings::get( 'weekly_digest', false );
		$scheduled = wp_next_scheduled( self::EVENT );

		if ( $enabled && ! $scheduled ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'weekly', self::EVENT );
		} elseif ( ! $enabled && $scheduled ) {
			wp_unschedule_event( $scheduled, self::EVENT );
		}
	}

	/**
	 * Remove the scheduled event (deactivation/uninstall).
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function unschedule(): void {
		$timestamp = wp_next_scheduled( self::EVENT );

		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::EVENT );
		}
	}

	/**
	 * Build and send the digest email.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function send(): void {
		if ( ! MVweb_SS_Settings::get( 'weekly_digest', false ) ) {
			return;
		}

		$to = sanitize_email( (string) MVweb_SS_Settings::get( 'digest_email', '' ) );

		if ( ! is_email( $to ) ) {
			$to = (string) get_option( 'admin_email' );
		}

		if ( ! is_email( $to ) ) {
			return;
		}

		$top  = MVweb_SS_Analytics::top_queries_clustered( 10 );
		$zero = MVweb_SS_Analytics::no_result_queries_clustered( 10 );

		if ( empty( $top ) && empty( $zero ) ) {
			return;
		}

		$site = wp_specialchars_decode( (string) get_option( 'blogname' ), ENT_QUOTES );

		/* translators: %s: site name. */
		$subject = sprintf( __( '[%s] Weekly search digest', 'mvweb-smart-search' ), $site );

		$lines   = array();
		$lines[] = __( 'Top searches this week:', 'mvweb-smart-search' );
		$lines   = array_merge( $lines, self::format_rows( $top ) );
		$lines[] = '';
		$lines[] = __( 'Searches with no results (content and product gaps):', 'mvweb-smart-search' );
		$lines   = array_merge( $lines, self::format_rows( $zero ) );
		$lines[] = '';
		$lines[] = admin_url( 'admin.php?page=' . MVweb_SS_Admin::PAGE_SLUG . '&tab=analytics' );

		wp_mail( $to, $subject, implode( "\n", $lines ) );
	}

	/**
	 * Format cluster rows as "  query — hits" lines.
	 *
	 * @since 1.1.0
	 * @param array<int,array<string,mixed>> $rows Cluster rows.
	 * @return string[]
	 */
	private static function format_rows( array $rows ): array {
		if ( empty( $rows ) ) {
			return array( '  ' . __( '(none)', 'mvweb-smart-search' ) );
		}

		$out = array();

		foreach ( $rows as $row ) {
			$out[] = sprintf( '  %s — %d', (string) $row['query'], (int) $row['hits'] );
		}

		return $out;
	}
}
