<?php
/**
 * WP-CLI commands (stats, search, clear-log). Reindex lives in the reindex class.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers auxiliary `wp mvweb-ss` subcommands for diagnostics and maintenance.
 *
 * @since 1.0.0
 */
class MVweb_SS_CLI {

	/**
	 * Register the CLI commands.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		if ( ! ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return;
		}

		\WP_CLI::add_command( 'mvweb-ss stats', array( __CLASS__, 'stats' ) );
		\WP_CLI::add_command( 'mvweb-ss search', array( __CLASS__, 'search' ) );
		\WP_CLI::add_command( 'mvweb-ss clear-log', array( __CLASS__, 'clear_log' ) );
		\WP_CLI::add_command( 'mvweb-ss eval', array( __CLASS__, 'eval_set' ) );
		\WP_CLI::add_command( 'mvweb-ss eval-seed', array( __CLASS__, 'eval_seed' ) );
	}

	/**
	 * Run a regression eval set and diff it against a saved baseline.
	 *
	 * The file is a JSON array of entries — a plain query string, or an object
	 * `{"query": "...", "expected": [id, id]}`. With --save the current top-N IDs
	 * are written back as each entry's `expected` (the baseline). Without it, the
	 * current results are compared to that baseline and per-query overlap plus a
	 * summary are printed, so a ranking change can be told apart from a regression
	 * before it ships.
	 *
	 * ## OPTIONS
	 *
	 * <file>
	 * : Path to the eval-set JSON file.
	 *
	 * [--save]
	 * : Record the current top-N as the baseline instead of comparing.
	 *
	 * [--limit=<number>]
	 * : Top-N depth to capture/compare. Default 10.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-ss eval eval-set.json --save
	 *     wp mvweb-ss eval eval-set.json
	 *
	 * @since 1.2.0
	 * @param array $args       Positional args.
	 * @param array $assoc_args Named args.
	 * @return void
	 */
	public static function eval_set( array $args, array $assoc_args ): void {
		$file = isset( $args[0] ) ? (string) $args[0] : '';

		if ( '' === $file || ! is_readable( $file ) ) {
			\WP_CLI::error( 'Provide a readable eval-set JSON file.' );
			return;
		}

		$data = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

		if ( ! is_array( $data ) ) {
			\WP_CLI::error( 'Eval file is not a JSON array.' );
			return;
		}

		$limit = isset( $assoc_args['limit'] ) ? max( 1, (int) $assoc_args['limit'] ) : 10;
		$save  = isset( $assoc_args['save'] );

		$out       = array();
		$table     = array();
		$overlaps  = array();
		$regressed = 0;

		foreach ( $data as $entry ) {
			$query    = is_array( $entry ) ? (string) ( $entry['query'] ?? '' ) : (string) $entry;
			$expected = is_array( $entry ) && isset( $entry['expected'] ) ? array_map( 'intval', (array) $entry['expected'] ) : array();

			if ( '' === $query ) {
				continue;
			}

			$current = array_slice( MVweb_SS_Query::search_ids( $query, array( 'limit' => $limit ) ), 0, $limit );

			if ( $save ) {
				$out[] = array(
					'query'    => $query,
					'expected' => $current,
				);
				continue;
			}

			$hits    = array_values( array_intersect( $expected, $current ) );
			$missing = array_values( array_diff( $expected, $current ) );
			$overlap = empty( $expected ) ? 1.0 : count( $hits ) / count( $expected );

			$overlaps[] = $overlap;

			if ( ! empty( $missing ) ) {
				++$regressed;
			}

			$table[] = array(
				'query'   => $query,
				'overlap' => round( $overlap * 100 ) . '%',
				'top1'    => (int) ( $current[0] ?? 0 ),
				'dropped' => implode( ',', $missing ),
			);
		}

		if ( $save ) {
			file_put_contents( $file, (string) wp_json_encode( $out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			\WP_CLI::success( sprintf( 'Baseline saved: %d queries, top-%d each.', count( $out ), $limit ) );
			return;
		}

		\WP_CLI\Utils\format_items( 'table', $table, array( 'query', 'overlap', 'top1', 'dropped' ) );

		$avg = empty( $overlaps ) ? 0 : array_sum( $overlaps ) / count( $overlaps );
		\WP_CLI::log( sprintf( 'Average overlap: %d%% · queries with drops: %d/%d', (int) round( $avg * 100 ), $regressed, count( $table ) ) );

		if ( $regressed > 0 ) {
			\WP_CLI::warning( 'Some expected results dropped out of the top-N — review before shipping the ranking change.' );
		} else {
			\WP_CLI::success( 'No regressions against the baseline.' );
		}
	}

	/**
	 * Bootstrap a regression eval-set from the real search log (E.1/E.2).
	 *
	 * Pulls the most-searched queries that currently return results and snapshots
	 * their present top-N as the baseline, writing a ready eval file. Curate it,
	 * then re-run `wp mvweb-ss eval <file>` after a ranking change to see what
	 * dropped. Turns already-collected analytics into a starter set with no manual
	 * query typing — the missing half of the eval workflow.
	 *
	 * ## OPTIONS
	 *
	 * <file>
	 * : Path to write the eval-set JSON file (overwritten).
	 *
	 * [--top=<count>]
	 * : How many top logged queries to include (max 50). Default 40.
	 *
	 * [--limit=<n>]
	 * : Top-N results captured as the baseline per query. Default 10.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-ss eval-seed eval-set.json
	 *     wp mvweb-ss eval-seed eval-set.json --top=50 --limit=15
	 *
	 * @since 1.2.0
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Associative arguments.
	 * @return void
	 */
	public static function eval_seed( array $args, array $assoc_args ): void {
		$file = isset( $args[0] ) ? (string) $args[0] : '';

		if ( '' === $file ) {
			\WP_CLI::error( 'Provide a path to write the eval-set JSON file.' );
			return;
		}

		$top   = isset( $assoc_args['top'] ) ? max( 1, (int) $assoc_args['top'] ) : 40;
		$limit = isset( $assoc_args['limit'] ) ? max( 1, (int) $assoc_args['limit'] ) : 10;

		$queries = MVweb_SS_Analytics::popular_queries( $top );

		if ( empty( $queries ) ) {
			\WP_CLI::error( 'No successful queries in the search log yet — seed once the log has real queries, or write the eval file by hand.' );
			return;
		}

		$out = array();

		foreach ( $queries as $query ) {
			$ids = array_slice( MVweb_SS_Query::search_ids( $query, array( 'limit' => $limit ) ), 0, $limit );

			$out[] = array(
				'query'    => $query,
				'expected' => $ids,
			);
		}

		$written = file_put_contents( $file, (string) wp_json_encode( $out, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents

		if ( false === $written ) {
			\WP_CLI::error( sprintf( 'Could not write to %s — check the path and permissions.', $file ) );
			return;
		}

		\WP_CLI::success(
			sprintf(
				'Seeded %d queries into %s (top-%d baseline). Review it, then run `wp mvweb-ss eval %s` after a ranking change to catch regressions.',
				count( $out ),
				$file,
				$limit,
				$file
			)
		);
	}

	/**
	 * Show index and log statistics.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-ss stats
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function stats(): void {
		global $wpdb;

		$index = MVweb_SS_Schema::table_name();
		$log   = MVweb_SS_Schema::log_table_name();

		$rows    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$index`" ); // phpcs:ignore WordPress.DB
		$objects = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT object_id) FROM `$index`" ); // phpcs:ignore WordPress.DB
		$logged  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$log`" ); // phpcs:ignore WordPress.DB
		$zero    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$log` WHERE results = 0" ); // phpcs:ignore WordPress.DB
		$meta    = MVweb_SS_Schema::get_meta();

		\WP_CLI::log( sprintf( 'Index rows:      %d', $rows ) );
		\WP_CLI::log( sprintf( 'Indexed objects: %d', $objects ) );
		\WP_CLI::log( sprintf( 'Logged queries:  %d (no-result: %d)', $logged, $zero ) );
		\WP_CLI::log( sprintf( 'Last reindex:    %s', isset( $meta['last_reindex'] ) ? gmdate( 'Y-m-d H:i', (int) $meta['last_reindex'] ) : 'never' ) );
	}

	/**
	 * Run a search from the command line.
	 *
	 * ## OPTIONS
	 *
	 * <query>
	 * : The search phrase.
	 *
	 * [--limit=<number>]
	 * : Maximum results. Default 10.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-ss search "герметик"
	 *     wp mvweb-ss search "клей" --limit=5
	 *
	 * @since 1.0.0
	 * @param array $args       Positional args.
	 * @param array $assoc_args Named args.
	 * @return void
	 */
	public static function search( array $args, array $assoc_args ): void {
		$query = isset( $args[0] ) ? (string) $args[0] : '';

		if ( '' === $query ) {
			\WP_CLI::error( 'Provide a query, e.g. wp mvweb-ss search "phrase".' );
			return;
		}

		$limit   = isset( $assoc_args['limit'] ) ? max( 1, (int) $assoc_args['limit'] ) : 10;
		$results = MVweb_SS_Query::search( $query, array( 'limit' => $limit ) );

		if ( empty( $results ) ) {
			\WP_CLI::success( 'No results.' );
			return;
		}

		$table = array();

		foreach ( $results as $row ) {
			$table[] = array(
				'id'    => (int) $row['object_id'],
				'type'  => (string) $row['object_type'],
				'score' => (float) $row['score'],
				'title' => (string) get_the_title( (int) $row['object_id'] ),
			);
		}

		\WP_CLI\Utils\format_items( 'table', $table, array( 'id', 'type', 'score', 'title' ) );
	}

	/**
	 * Empty the search query log.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-ss clear-log
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function clear_log(): void {
		global $wpdb;

		$log = MVweb_SS_Schema::log_table_name();
		$wpdb->query( "DELETE FROM `$log`" ); // phpcs:ignore WordPress.DB

		\WP_CLI::success( 'Search log cleared.' );
	}
}
