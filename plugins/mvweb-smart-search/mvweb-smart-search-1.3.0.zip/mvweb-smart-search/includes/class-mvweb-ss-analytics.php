<?php
/**
 * Search analytics: dashboard widget, log tables and CSV export.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Surfaces the aggregated search log: a "no results" dashboard widget, the
 * Analytics settings tab and a nonce-guarded CSV export / clear action.
 *
 * @since 1.0.0
 */
class MVweb_SS_Analytics {

	const EXPORT_ACTION = 'mvweb_ss_export_log';

	const CLEAR_ACTION = 'mvweb_ss_clear_log';

	/**
	 * Register analytics hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'add_dashboard_widget' ) );
		add_action( 'admin_post_' . self::EXPORT_ACTION, array( __CLASS__, 'export_log' ) );
		add_action( 'admin_post_' . self::CLEAR_ACTION, array( __CLASS__, 'clear_log' ) );
	}

	/**
	 * Register the "no results" dashboard widget.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function add_dashboard_widget(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		wp_add_dashboard_widget(
			'mvweb_ss_no_results',
			__( 'Smart Search — queries with no results', 'mvweb-smart-search' ),
			array( __CLASS__, 'render_dashboard_widget' )
		);
	}

	/**
	 * Render the dashboard widget contents.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_dashboard_widget(): void {
		$rows = self::no_result_queries( 10 );

		if ( empty( $rows ) ) {
			echo '<p>' . esc_html__( 'No queries without results yet.', 'mvweb-smart-search' ) . '</p>';
			return;
		}

		echo '<table class="widefat striped"><thead><tr>';
		echo '<th>' . esc_html__( 'Query', 'mvweb-smart-search' ) . '</th>';
		echo '<th>' . esc_html__( 'Hits', 'mvweb-smart-search' ) . '</th>';
		echo '</tr></thead><tbody>';

		foreach ( $rows as $row ) {
			echo '<tr><td>' . esc_html( $row['query'] ) . '</td><td>' . esc_html( (string) $row['hits'] ) . '</td></tr>';
		}

		echo '</tbody></table>';

		printf(
			'<p><a href="%s">%s</a></p>',
			esc_url( admin_url( 'admin.php?page=' . MVweb_SS_Admin::PAGE_SLUG . '&tab=analytics' ) ),
			esc_html__( 'All analytics', 'mvweb-smart-search' )
		);
	}

	/**
	 * Top queries that returned no results.
	 *
	 * @since 1.0.0
	 * @param int $limit Max rows.
	 * @return array<int,array{query:string,hits:int,updated:string}>
	 */
	public static function no_result_queries( int $limit ): array {
		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$limit = max( 1, min( 200, $limit ) );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT query, hits, updated FROM `$table` WHERE results = 0 ORDER BY hits DESC, updated DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$limit
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Most frequent queries overall.
	 *
	 * @since 1.0.0
	 * @param int $limit Max rows.
	 * @return array<int,array{query:string,hits:int,results:int,clicks:int,updated:string}>
	 */
	public static function top_queries( int $limit ): array {
		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$limit = max( 1, min( 200, $limit ) );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT query, hits, results, clicks, updated FROM `$table` ORDER BY hits DESC, updated DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$limit
			),
			ARRAY_A
		);

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Most frequent queries that returned results — for the front-end
	 * "popular searches" suggestions shown on an empty focus.
	 *
	 * @since 1.0.0
	 * @param int $limit Max rows.
	 * @return string[]
	 */
	public static function popular_queries( int $limit ): array {
		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$limit = max( 1, min( 50, $limit ) );

		$rows = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT query FROM `$table` WHERE results > 0 ORDER BY hits DESC, updated DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$limit
			)
		);

		return is_array( $rows ) ? array_map( 'strval', $rows ) : array();
	}

	/**
	 * No-result queries annotated with the closest successful query, if any (P2.3).
	 *
	 * The search log is aggregated per query (no per-visitor session trail), so a
	 * true "typed A, found nothing, then typed B" pair cannot be mined. Instead this
	 * pairs each frequent no-result query with the most similar *successful* query
	 * by token overlap / string similarity — a human-gated hint the owner can turn
	 * into a synonym with one click. Nothing is applied automatically.
	 *
	 * @since 1.2.0
	 * @param int $limit Max no-result rows.
	 * @return array<int,array<string,mixed>> Clustered rows, each with a 'suggestion' key ('' when none).
	 */
	public static function no_result_suggestions( int $limit ): array {
		$rows = self::no_result_queries_clustered( $limit );

		if ( empty( $rows ) ) {
			return $rows;
		}

		$pool = self::popular_queries( 50 );

		foreach ( $rows as $i => $row ) {
			$rows[ $i ]['suggestion'] = self::closest_query( (string) $row['query'], $pool );
		}

		return $rows;
	}

	/**
	 * Closest successful query to a no-result one, or '' when nothing is close.
	 *
	 * Scores each candidate by the greater of token-overlap (Jaccard on words ≥2
	 * chars) and normalized string similarity, so both word-order/transliteration
	 * near-misses and typos surface. A conservative floor avoids noisy hints.
	 *
	 * @since 1.2.0
	 * @param string   $query Raw no-result query.
	 * @param string[] $pool  Candidate successful queries.
	 * @return string
	 */
	private static function closest_query( string $query, array $pool ): string {
		$q = mb_strtolower( trim( $query ), 'UTF-8' );

		if ( '' === $q ) {
			return '';
		}

		$q_tokens   = self::sig_tokens( $q );
		$best       = '';
		$best_score = 0.0;

		foreach ( $pool as $cand ) {
			$c = mb_strtolower( trim( (string) $cand ), 'UTF-8' );

			if ( '' === $c || $c === $q ) {
				continue;
			}

			$c_tokens = self::sig_tokens( $c );
			$union    = array_unique( array_merge( $q_tokens, $c_tokens ) );
			$jaccard  = ! empty( $union ) ? count( array_intersect( $q_tokens, $c_tokens ) ) / count( $union ) : 0.0;

			$percent = 0.0;
			similar_text( $q, $c, $percent );

			$score = max( $jaccard, $percent / 100 );

			if ( $score > $best_score ) {
				$best_score = $score;
				$best       = (string) $cand;
			}
		}

		return $best_score >= 0.5 ? $best : '';
	}

	/**
	 * Significant words of a query (lower-cased, length ≥ 2), for overlap scoring.
	 *
	 * @since 1.2.0
	 * @param string $query Lower-cased query.
	 * @return string[]
	 */
	private static function sig_tokens( string $query ): array {
		$parts = preg_split( '/\s+/u', $query );

		return array_values(
			array_filter(
				(array) $parts,
				static function ( $token ) {
					return mb_strlen( (string) $token, 'UTF-8' ) >= 2;
				}
			)
		);
	}

	/**
	 * Morphology key that folds Russian case forms of a query into one bucket.
	 *
	 * Reuses the index stemmer, so "камин", "камина" and "каминов" share a key
	 * and stop scattering the analytics across grammatical cases. Word order is
	 * ignored (stems are sorted).
	 *
	 * @since 1.1.0
	 * @param string $query Raw query.
	 * @return string
	 */
	public static function cluster_key( string $query ): string {
		$stems = array_keys( MVweb_SS_Tokenizer::tokenize( $query ) );
		sort( $stems );

		return implode( ' ', $stems );
	}

	/**
	 * Collapse rows sharing a morphology key, summing hits and clicks.
	 *
	 * The most-searched raw wording becomes the cluster label; `variants` counts
	 * how many spellings/cases folded in. Rows that tokenize to nothing (pure
	 * punctuation/numbers) fall back to their lowercased text so they still show.
	 *
	 * @since 1.1.0
	 * @param array<int,array<string,mixed>> $rows Log rows.
	 * @return array<int,array{query:string,hits:int,results:int,clicks:int,variants:int,updated:string}>
	 */
	private static function cluster( array $rows ): array {
		$clusters = array();

		foreach ( $rows as $row ) {
			$key = self::cluster_key( (string) $row['query'] );

			if ( '' === $key ) {
				$key = '~' . mb_strtolower( trim( (string) $row['query'] ), 'UTF-8' );
			}

			if ( ! isset( $clusters[ $key ] ) ) {
				$clusters[ $key ] = array(
					'query'    => (string) $row['query'],
					'hits'     => 0,
					'results'  => (int) ( $row['results'] ?? 0 ),
					'clicks'   => 0,
					'variants' => 0,
					'updated'  => (string) ( $row['updated'] ?? '' ),
					'_top'     => -1,
				);
			}

			$cluster = &$clusters[ $key ];

			$cluster['hits']   += (int) $row['hits'];
			$cluster['clicks'] += (int) ( $row['clicks'] ?? 0 );
			++$cluster['variants'];

			if ( (int) $row['hits'] > $cluster['_top'] ) {
				$cluster['_top']    = (int) $row['hits'];
				$cluster['query']   = (string) $row['query'];
				$cluster['results'] = (int) ( $row['results'] ?? 0 );
			}

			if ( (string) ( $row['updated'] ?? '' ) > $cluster['updated'] ) {
				$cluster['updated'] = (string) $row['updated'];
			}

			unset( $cluster );
		}

		foreach ( $clusters as &$cluster ) {
			unset( $cluster['_top'] );
		}

		unset( $cluster );

		return array_values( $clusters );
	}

	/**
	 * Top no-result queries, clustered by morphology.
	 *
	 * @since 1.1.0
	 * @param int $limit Max clusters.
	 * @return array<int,array<string,mixed>>
	 */
	public static function no_result_queries_clustered( int $limit ): array {
		$clusters = self::cluster( self::no_result_queries( 500 ) );

		usort(
			$clusters,
			static function ( $a, $b ) {
				return $b['hits'] <=> $a['hits'];
			}
		);

		return array_slice( $clusters, 0, max( 1, $limit ) );
	}

	/**
	 * Top queries overall, clustered by morphology.
	 *
	 * @since 1.1.0
	 * @param int $limit Max clusters.
	 * @return array<int,array<string,mixed>>
	 */
	public static function top_queries_clustered( int $limit ): array {
		$clusters = self::cluster( self::top_queries( 500 ) );

		usort(
			$clusters,
			static function ( $a, $b ) {
				return $b['hits'] <=> $a['hits'];
			}
		);

		return array_slice( $clusters, 0, max( 1, $limit ) );
	}

	/**
	 * Stream the full log as a CSV download.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function export_log(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mvweb-smart-search' ) );
		}

		check_admin_referer( self::EXPORT_ACTION );

		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$rows  = $wpdb->get_results( "SELECT query, hits, results, clicks, updated FROM `$table` ORDER BY hits DESC, updated DESC", ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=mvweb-search-log-' . gmdate( 'Y-m-d' ) . '.csv' );

		$output = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen

		if ( false === $output ) {
			exit;
		}

		fputcsv( $output, array( 'query', 'hits', 'results', 'clicks', 'updated' ) );

		foreach ( (array) $rows as $row ) {
			fputcsv(
				$output,
				array(
					self::csv_safe( $row['query'] ),
					(int) $row['hits'],
					(int) $row['results'],
					(int) $row['clicks'],
					self::csv_safe( $row['updated'] ),
				)
			);
		}

		fclose( $output ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		exit;
	}

	/**
	 * Empty the search log.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function clear_log(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'Insufficient permissions.', 'mvweb-smart-search' ) );
		}

		check_admin_referer( self::CLEAR_ACTION );

		global $wpdb;

		$table  = MVweb_SS_Schema::log_table_name();
		$result = $wpdb->query( "DELETE FROM `$table`" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		// Clearing the log also resets the rescued-search tallies it summarizes.
		delete_option( MVweb_SS_Log::RESCUE_OPTION );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'    => MVweb_SS_Admin::PAGE_SLUG,
					'tab'     => 'analytics',
					'cleared' => false === $result ? '0' : '1',
				),
				admin_url( 'admin.php' )
			)
		);

		exit;
	}

	/**
	 * Prefix formula-triggering values so spreadsheets treat them as text.
	 *
	 * @since 1.0.0
	 * @param mixed $value Cell value.
	 * @return string
	 */
	private static function csv_safe( $value ): string {
		$value = (string) $value;

		if ( '' !== $value && in_array( $value[0], array( '=', '+', '-', '@' ), true ) ) {
			return "'" . $value;
		}

		return $value;
	}
}
