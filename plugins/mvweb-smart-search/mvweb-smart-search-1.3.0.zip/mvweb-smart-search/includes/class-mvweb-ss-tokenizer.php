<?php
/**
 * Tokenizer: text → normalized, stemmed terms with counts.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Turns a chunk of text into an array of index terms (term => count).
 *
 * @since 1.0.0
 */
class MVweb_SS_Tokenizer {

	const MAX_TERM_LENGTH = 50;

	const MIN_TERM_LENGTH = 2;

	/**
	 * Russian stop words.
	 *
	 * @var string[]
	 */
	private static $stop_ru = array(
		'и',
		'в',
		'во',
		'не',
		'что',
		'он',
		'на',
		'я',
		'с',
		'со',
		'как',
		'а',
		'то',
		'все',
		'она',
		'так',
		'его',
		'но',
		'да',
		'ты',
		'к',
		'у',
		'же',
		'вы',
		'за',
		'бы',
		'по',
		'ее',
		'мне',
		'было',
		'вот',
		'от',
		'меня',
		'еще',
		'нет',
		'о',
		'из',
		'ему',
		'для',
		'ни',
		'до',
		'или',
		'при',
		'об',
		'этот',
		'эта',
		'это',
		'эти',
		'над',
		'под',
		'без',
		'уже',
		'ли',
		'бы',
	);

	/**
	 * English stop words.
	 *
	 * @var string[]
	 */
	private static $stop_en = array(
		'the',
		'a',
		'an',
		'and',
		'or',
		'of',
		'to',
		'in',
		'is',
		'it',
		'for',
		'on',
		'with',
		'as',
		'at',
		'by',
		'be',
		'this',
		'that',
		'are',
		'was',
		'from',
		'but',
		'not',
		'you',
		'your',
		'we',
	);

	/**
	 * Tokenize text into stemmed terms with occurrence counts.
	 *
	 * @since 1.0.0
	 * @param string $text Source text.
	 * @param string $lang Force language ('ru'|'en'); empty = auto per token.
	 * @return array<string,int> term => count.
	 */
	public static function tokenize( string $text, string $lang = '' ): array {
		$text = mb_strtolower( $text, 'UTF-8' );
		$text = str_replace( 'ё', 'е', $text );

		$raw = preg_split( '/[^\p{L}\p{N}\-]+/u', $text, -1, PREG_SPLIT_NO_EMPTY );

		if ( ! is_array( $raw ) ) {
			return array();
		}

		$terms = array();

		foreach ( $raw as $token ) {
			$token = trim( $token, '-' );

			if ( '' === $token ) {
				continue;
			}

			$token = self::normalize_homoglyphs( $token );

			if ( false !== strpos( $token, '-' ) ) {
				self::add_term( $terms, $token );

				foreach ( explode( '-', $token ) as $part ) {
					self::consume( $terms, $part, $lang );
				}

				continue;
			}

			self::consume( $terms, $token, $lang );
		}

		return $terms;
	}

	/**
	 * Count the words a user actually typed, before digit-unit or hyphen-compound
	 * expansion inflates the term list.
	 *
	 * The strictness floor (see MVweb_SS_Query::min_match) must key on how many
	 * words the shopper wrote, not on how many index terms tokenize() derives from
	 * them: a single glued token like "4000mah" yields three terms (4000mah, 4000,
	 * mah), and counting those as three required words would turn one word into an
	 * AND across all three — the opposite of the recall boost the split is for.
	 *
	 * @since 1.1.0
	 * @param string $text Source text.
	 * @return int Number of stop-word-filtered words of at least MIN_TERM_LENGTH.
	 */
	public static function word_count( string $text ): int {
		$text = mb_strtolower( $text, 'UTF-8' );
		$text = str_replace( 'ё', 'е', $text );

		$raw = preg_split( '/[^\p{L}\p{N}\-]+/u', $text, -1, PREG_SPLIT_NO_EMPTY );

		if ( ! is_array( $raw ) ) {
			return 0;
		}

		$count = 0;

		foreach ( $raw as $token ) {
			$token = trim( $token, '-' );

			if ( '' === $token ) {
				continue;
			}

			// Mirror tokenize(): unify mixed-script letters before the stop-word
			// test, so a homoglyph spelling of a stop word ("нeт") is counted the
			// same way consume() treats it — dropped, not counted as a word.
			$token = self::normalize_homoglyphs( $token );

			if ( ! self::passes_length( $token ) || self::is_stop_word( $token ) ) {
				continue;
			}

			++$count;
		}

		return $count;
	}

	/**
	 * Normalize, filter and stem a single token, then add it.
	 *
	 * @since 1.0.0
	 * @param array<string,int> $terms Accumulator (by reference).
	 * @param string            $token Raw token.
	 * @param string            $lang  Forced language or ''.
	 * @return void
	 */
	private static function consume( array &$terms, string $token, string $lang ): void {
		if ( ! self::passes_length( $token ) ) {
			return;
		}

		if ( self::is_stop_word( $token ) ) {
			return;
		}

		if ( preg_match( '/\d/', $token ) ) {
			self::add_term( $terms, $token );
			self::split_model( $terms, $token );
			return;
		}

		self::add_term( $terms, MVweb_SS_Stemmer::stem( $token, $lang ) );
	}

	/**
	 * Split a glued model / number+unit token into its letter and digit runs so
	 * it is searchable by any part.
	 *
	 * "150мм" also yields "150" and "мм" (query "труба 150" finds "труба 150мм"
	 * and back); "gtx1660" yields "gtx" and "1660"; "gtx1660ti" yields "gtx",
	 * "1660" and "ti". Every maximal run of letters or digits becomes a term, the
	 * whole glued token is already kept by the caller. Applied identically at
	 * index and query time. Gated by the normalize_models setting so catalogs
	 * where such codes are noise (apparel sizing) can turn it off.
	 *
	 * @since 1.1.0
	 * @param array<string,int> $terms Accumulator (by reference).
	 * @param string            $token Token containing at least one digit.
	 * @return void
	 */
	private static function split_model( array &$terms, string $token ): void {
		if ( ! self::normalize_models() ) {
			return;
		}

		if ( ! preg_match_all( '/\p{L}+|\d+/u', $token, $m ) || count( $m[0] ) < 2 ) {
			return;
		}

		foreach ( $m[0] as $run ) {
			self::add_term( $terms, $run );
		}
	}

	/**
	 * Whether glued model / unit tokens are split into runs, cached per request.
	 *
	 * @var bool|null
	 */
	private static $normalize_models = null;

	/**
	 * Read the model-normalization setting once per request.
	 *
	 * @since 1.2.0
	 * @return bool
	 */
	private static function normalize_models(): bool {
		if ( null === self::$normalize_models ) {
			self::$normalize_models = ! class_exists( 'MVweb_SS_Settings' ) || (bool) MVweb_SS_Settings::get( 'normalize_models', true );
		}

		return self::$normalize_models;
	}

	/**
	 * Unify visually identical Latin/Cyrillic letters inside a mixed token.
	 *
	 * Only tokens that actually mix scripts are touched: the minority-script
	 * confusable letters (a/а, e/е, o/о, c/с, p/р, x/х, y/у) are converted to the
	 * majority script (ties go to Cyrillic, RU-first) so an accidental Latin "o"
	 * in a Russian word — or the reverse — still matches. Applied identically at
	 * index and query time, so both sides converge on the same term.
	 *
	 * @since 1.1.0
	 * @param string $token Lowercased token.
	 * @return string
	 */
	private static function normalize_homoglyphs( string $token ): string {
		static $lat_to_cyr = array(
			'a' => 'а',
			'e' => 'е',
			'o' => 'о',
			'c' => 'с',
			'p' => 'р',
			'x' => 'х',
			'y' => 'у',
		);
		static $cyr_to_lat = null;

		if ( null === $cyr_to_lat ) {
			$cyr_to_lat = array_flip( $lat_to_cyr );
		}

		$cyr = preg_match_all( '/\p{Cyrillic}/u', $token );
		$lat = preg_match_all( '/[a-z]/', $token );

		if ( $cyr < 1 || $lat < 1 ) {
			return $token;
		}

		return $cyr >= $lat ? strtr( $token, $lat_to_cyr ) : strtr( $token, $cyr_to_lat );
	}

	/**
	 * Add a term to the accumulator, incrementing its count.
	 *
	 * @since 1.0.0
	 * @param array<string,int> $terms Accumulator (by reference).
	 * @param string            $term  Final term.
	 * @return void
	 */
	private static function add_term( array &$terms, string $term ): void {
		$term = mb_substr( $term, 0, self::MAX_TERM_LENGTH, 'UTF-8' );

		if ( ! self::passes_length( $term ) ) {
			return;
		}

		$terms[ $term ] = isset( $terms[ $term ] ) ? $terms[ $term ] + 1 : 1;
	}

	/**
	 * Whether a token is long enough to index. Two characters always qualify; a
	 * single character qualifies only when it is a digit and single-character
	 * indexing is enabled, so a model or size number ("iphone 5", "5g") stays
	 * searchable without letting stray one-letter noise into the index (P0.5).
	 *
	 * @since 1.2.0
	 * @param string $token Token.
	 * @return bool
	 */
	private static function passes_length( string $token ): bool {
		$len = mb_strlen( $token, 'UTF-8' );

		if ( $len >= self::MIN_TERM_LENGTH ) {
			return true;
		}

		return 1 === $len && (bool) preg_match( '/^\d$/', $token ) && self::allow_single_char();
	}

	/**
	 * Whether single-character (digit) tokens are indexed, cached per request.
	 *
	 * @var bool|null
	 */
	private static $single_char = null;

	/**
	 * Read the single-character indexing setting once per request.
	 *
	 * @since 1.2.0
	 * @return bool
	 */
	private static function allow_single_char(): bool {
		if ( null === self::$single_char ) {
			self::$single_char = ! class_exists( 'MVweb_SS_Settings' ) || (bool) MVweb_SS_Settings::get( 'index_single_char_models', true );
		}

		return self::$single_char;
	}

	/**
	 * Custom stop words from settings, cached per request.
	 *
	 * @var string[]|null
	 */
	private static $extra_stop = null;

	/**
	 * Whether a token is a stop word in either supported language or the
	 * admin-defined custom list.
	 *
	 * @since 1.0.0
	 * @param string $token Token.
	 * @return bool
	 */
	private static function is_stop_word( string $token ): bool {
		if ( in_array( $token, self::$stop_ru, true ) || in_array( $token, self::$stop_en, true ) ) {
			return true;
		}

		if ( null === self::$extra_stop ) {
			self::$extra_stop = class_exists( 'MVweb_SS_Settings' ) ? MVweb_SS_Settings::custom_stopwords() : array();
		}

		return in_array( $token, self::$extra_stop, true );
	}
}
