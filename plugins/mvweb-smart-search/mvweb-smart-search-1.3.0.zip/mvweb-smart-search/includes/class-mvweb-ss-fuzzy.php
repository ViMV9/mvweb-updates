<?php
/**
 * Fuzzy term expansion (typo tolerance) with strict candidate limits.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Finds index terms within a small edit distance of a query term, using a
 * cheap SQL prefilter (first letter + length window) so the whole dictionary
 * is never scanned.
 *
 * @since 1.0.0
 */
class MVweb_SS_Fuzzy {

	const MIN_LENGTH = 3;

	const MAX_CANDIDATES = 500;

	const MAX_RETURN = 5;

	const CACHE_TTL = 43200;

	/**
	 * Candidate index terms close to a (possibly misspelled) query term.
	 *
	 * @since 1.0.0
	 * @param string $term Query term.
	 * @return string[]
	 */
	public static function candidates( string $term ): array {
		$length = mb_strlen( $term, 'UTF-8' );

		if ( $length < self::MIN_LENGTH ) {
			return array();
		}

		$cache_key = 'mvweb_ss_fz_' . md5( $term );
		$cached    = get_transient( $cache_key );

		if ( is_array( $cached ) ) {
			return $cached;
		}

		global $wpdb;

		$table = MVweb_SS_Schema::table_name();
		$like  = $wpdb->esc_like( mb_substr( $term, 0, 1, 'UTF-8' ) ) . '%';

		$rows = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT DISTINCT term FROM `$table` WHERE term LIKE %s AND CHAR_LENGTH( term ) BETWEEN %d AND %d LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$like,
				max( 1, $length - 2 ),
				$length + 2,
				self::MAX_CANDIDATES
			)
		);

		$max_distance = $length <= 5 ? 1 : 2;
		$out          = array();

		foreach ( (array) $rows as $candidate ) {
			if ( $candidate === $term ) {
				continue;
			}

			if ( self::distance( $term, (string) $candidate ) <= $max_distance ) {
				$out[] = (string) $candidate;
			}

			if ( count( $out ) >= self::MAX_RETURN ) {
				break;
			}
		}

		set_transient( $cache_key, $out, self::CACHE_TTL );

		return $out;
	}

	/**
	 * Multibyte-safe Levenshtein distance.
	 *
	 * @since 1.0.0
	 * @param string $a First string.
	 * @param string $b Second string.
	 * @return int
	 */
	public static function distance( string $a, string $b ): int {
		$a  = self::chars( $a );
		$b  = self::chars( $b );
		$la = count( $a );
		$lb = count( $b );

		if ( 0 === $la ) {
			return $lb;
		}

		if ( 0 === $lb ) {
			return $la;
		}

		$prev = range( 0, $lb );

		for ( $i = 1; $i <= $la; $i++ ) {
			$curr = array( $i );

			for ( $j = 1; $j <= $lb; $j++ ) {
				$cost       = $a[ $i - 1 ] === $b[ $j - 1 ] ? 0 : 1;
				$curr[ $j ] = min( $prev[ $j ] + 1, $curr[ $j - 1 ] + 1, $prev[ $j - 1 ] + $cost );
			}

			$prev = $curr;
		}

		return (int) $prev[ $lb ];
	}

	/**
	 * Split a UTF-8 string into an array of characters.
	 *
	 * @since 1.0.0
	 * @param string $text Input.
	 * @return string[]
	 */
	private static function chars( string $text ): array {
		$chars = preg_split( '//u', $text, -1, PREG_SPLIT_NO_EMPTY );

		return is_array( $chars ) ? $chars : array();
	}
}
