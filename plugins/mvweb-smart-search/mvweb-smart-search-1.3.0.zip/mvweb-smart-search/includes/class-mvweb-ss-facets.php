<?php
/**
 * Results-page facets: category, brand and price filters (P2.1).
 *
 * @package mvweb_ss
 * @since   1.2.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the results-page facet panel and wires it to a shortcode and a
 * classic widget. Counts reuse the morphology-aware term matcher, so each value
 * shows how many of the query's matches fall into it; selecting facets narrows
 * the intercepted results through native WP_Query filters (see MVweb_SS_Search).
 *
 * @since 1.2.0
 */
class MVweb_SS_Facets {

	const LIMIT = 10;

	/**
	 * Register the shortcode and widget.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function register(): void {
		add_shortcode( 'mvweb_ss_facets', array( __CLASS__, 'shortcode' ) );
		add_action( 'widgets_init', array( __CLASS__, 'register_widget' ) );
	}

	/**
	 * Register the classic sidebar widget.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function register_widget(): void {
		register_widget( 'MVweb_SS_Facets_Widget' );
	}

	/**
	 * `[mvweb_ss_facets]` shortcode handler.
	 *
	 * @since 1.2.0
	 * @return string
	 */
	public static function shortcode(): string {
		return self::render();
	}

	/**
	 * Max terms shown per facet, from the setting (clamped).
	 *
	 * @since 1.2.0
	 * @return int
	 */
	private static function facet_limit(): int {
		$limit = (int) MVweb_SS_Settings::get( 'facet_limit', self::LIMIT );

		return max( 1, min( 30, $limit ) );
	}

	/**
	 * Render the facet panel, or an empty string when it should not show (not a
	 * results page, facets disabled, empty query, or nothing to filter by).
	 *
	 * @since 1.2.0
	 * @return string
	 */
	public static function render(): string {
		if ( ! is_search() || ! MVweb_SS_Settings::get( 'results_facets', true ) ) {
			return '';
		}

		$query = trim( (string) get_search_query( false ) );

		if ( '' === $query || ! class_exists( 'MVweb_SS_Categories' ) ) {
			return '';
		}

		$limit  = self::facet_limit();
		$cats   = MVweb_SS_Categories::search( $query, $limit );
		$brands = MVweb_SS_Categories::brands( $query, $limit );

		$bounds    = MVweb_SS_Query::price_bounds( MVweb_SS_Search::pool_ids() );
		$has_price = class_exists( 'WooCommerce' ) && ! empty( $bounds );

		if ( empty( $cats ) && empty( $brands ) && ! $has_price ) {
			return '';
		}

		$sel_cats   = array_flip( MVweb_SS_Search::selected_facet_cats() );
		$sel_brands = array_flip( MVweb_SS_Search::selected_facet_brands() );
		$price      = MVweb_SS_Search::selected_price();

		$active = ! empty( $sel_cats ) || ! empty( $sel_brands ) || null !== $price['min'] || null !== $price['max'];

		ob_start();
		?>
		<form role="search" method="get" class="mvweb-ss-facets" action="<?php echo esc_url( home_url( '/' ) ); ?>">
			<input type="hidden" name="s" value="<?php echo esc_attr( get_search_query() ); ?>">
			<?php foreach ( self::preserved_hidden() as $name => $value ) : ?>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $value ); ?>">
			<?php endforeach; ?>

			<?php if ( ! empty( $cats ) ) : ?>
				<fieldset class="mvweb-ss-facets__group">
					<legend class="mvweb-ss-facets__legend"><?php esc_html_e( 'Categories', 'mvweb-smart-search' ); ?></legend>
					<?php echo self::options( $cats, 'mvweb_ss_fcat', $sel_cats ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with escaping below. ?>
				</fieldset>
			<?php endif; ?>

			<?php if ( ! empty( $brands ) ) : ?>
				<fieldset class="mvweb-ss-facets__group">
					<legend class="mvweb-ss-facets__legend"><?php esc_html_e( 'Brands', 'mvweb-smart-search' ); ?></legend>
					<?php echo self::options( $brands, 'mvweb_ss_fbrand', $sel_brands ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built with escaping below. ?>
				</fieldset>
			<?php endif; ?>

			<?php if ( $has_price ) : ?>
				<fieldset class="mvweb-ss-facets__group mvweb-ss-facets__group--price">
					<legend class="mvweb-ss-facets__legend"><?php esc_html_e( 'Price', 'mvweb-smart-search' ); ?></legend>
					<div class="mvweb-ss-facets__price">
						<input type="number" inputmode="numeric" min="0" step="any" class="mvweb-ss-facets__price-input"
							name="mvweb_ss_pmin" value="<?php echo esc_attr( null !== $price['min'] ? (string) $price['min'] : '' ); ?>"
							placeholder="<?php echo esc_attr( (string) (int) floor( $bounds['min'] ) ); ?>"
							aria-label="<?php esc_attr_e( 'Minimum price', 'mvweb-smart-search' ); ?>">
						<span class="mvweb-ss-facets__price-sep">&ndash;</span>
						<input type="number" inputmode="numeric" min="0" step="any" class="mvweb-ss-facets__price-input"
							name="mvweb_ss_pmax" value="<?php echo esc_attr( null !== $price['max'] ? (string) $price['max'] : '' ); ?>"
							placeholder="<?php echo esc_attr( (string) (int) ceil( $bounds['max'] ) ); ?>"
							aria-label="<?php esc_attr_e( 'Maximum price', 'mvweb-smart-search' ); ?>">
					</div>
				</fieldset>
			<?php endif; ?>

			<div class="mvweb-ss-facets__actions">
				<button type="submit" class="mvweb-ss-facets__apply"><?php esc_html_e( 'Apply filters', 'mvweb-smart-search' ); ?></button>
				<?php if ( $active ) : ?>
					<a class="mvweb-ss-facets__reset" href="<?php echo esc_url( self::reset_url() ); ?>"><?php esc_html_e( 'Reset', 'mvweb-smart-search' ); ?></a>
				<?php endif; ?>
			</div>
		</form>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Build the checkbox list for one facet (already fully escaped).
	 *
	 * @since 1.2.0
	 * @param array<int,array<string,mixed>> $terms    Terms from MVweb_SS_Categories.
	 * @param string                         $field    Checkbox field name (array).
	 * @param array<int,int>                 $selected term_id => position for checked state.
	 * @return string
	 */
	private static function options( array $terms, string $field, array $selected ): string {
		$out = '';

		foreach ( $terms as $term ) {
			$id      = (int) $term['term_id'];
			$checked = isset( $selected[ $id ] ) ? ' checked' : '';

			$out .= '<label class="mvweb-ss-facets__opt">'
				. '<input type="checkbox" name="' . esc_attr( $field ) . '[]" value="' . esc_attr( (string) $id ) . '"' . $checked . '>'
				. '<span class="mvweb-ss-facets__opt-name">' . esc_html( (string) $term['name'] ) . '</span>'
				. '<span class="mvweb-ss-facets__opt-count">' . esc_html( (string) (int) $term['count'] ) . '</span>'
				. '</label>';
		}

		return $out;
	}

	/**
	 * Non-facet search parameters to carry through the form so applying a facet
	 * keeps the query, its type scope, category scope and sort order.
	 *
	 * @since 1.2.0
	 * @return array<string,string>
	 */
	private static function preserved_hidden(): array {
		$out = array();

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only public params, like `s`.
		if ( isset( $_GET['mvweb_ss_types'] ) ) {
			$types = sanitize_text_field( wp_unslash( $_GET['mvweb_ss_types'] ) );
			if ( '' !== $types ) {
				$out['mvweb_ss_types'] = $types;
			}
		}

		if ( isset( $_GET['mvweb_ss_cat'] ) ) {
			$cat = absint( wp_unslash( $_GET['mvweb_ss_cat'] ) );
			if ( $cat > 0 ) {
				$out['mvweb_ss_cat'] = (string) $cat;

				// The category scope carries its taxonomy from the live dropdown; without
				// it the scope silently resolves to nothing after a facet submit/reset.
				if ( isset( $_GET['mvweb_ss_tax'] ) ) {
					$tax = sanitize_key( wp_unslash( $_GET['mvweb_ss_tax'] ) );
					if ( '' !== $tax && taxonomy_exists( $tax ) ) {
						$out['mvweb_ss_tax'] = $tax;
					}
				}
			}
		}

		$sort = MVweb_SS_Search::requested_sort();
		if ( '' !== $sort ) {
			$out['mvweb_ss_sort'] = $sort;
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		return $out;
	}

	/**
	 * URL that clears every facet but keeps the query and its non-facet scope.
	 *
	 * @since 1.2.0
	 * @return string
	 */
	private static function reset_url(): string {
		$args = array( 's' => get_search_query() );

		foreach ( self::preserved_hidden() as $name => $value ) {
			$args[ $name ] = $value;
		}

		return add_query_arg( array_map( 'rawurlencode', $args ), home_url( '/' ) );
	}
}
