<?php
/**
 * Stemmer wrapper around the vendored wamania/php-stemmer (RU + EN).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reduces words to their stem, picking the language by script.
 *
 * @since 1.0.0
 */
class MVweb_SS_Stemmer {

	/**
	 * Cached stemmer instances keyed by language code.
	 *
	 * @var array<string,object>
	 */
	private static $instances = array();

	/**
	 * Whether the vendored library files have been loaded.
	 *
	 * @var bool
	 */
	private static $loaded = false;

	/**
	 * Reduce a single word to its stem.
	 *
	 * @since 1.0.0
	 * @param string $word Word to stem.
	 * @param string $lang Force language ('ru'|'en'); empty = auto-detect.
	 * @return string
	 */
	public static function stem( string $word, string $lang = '' ): string {
		$word = mb_strtolower( $word, 'UTF-8' );

		if ( mb_strlen( $word, 'UTF-8' ) < 3 ) {
			return $word;
		}

		if ( '' === $lang ) {
			$lang = self::detect( $word );
		}

		if ( '' === $lang ) {
			return $word;
		}

		$stemmer = self::get_instance( $lang );

		if ( null === $stemmer ) {
			return $word;
		}

		try {
			$stem = $stemmer->stem( $word );
		} catch ( \Throwable $e ) {
			return $word;
		}

		return is_string( $stem ) && '' !== $stem ? $stem : $word;
	}

	/**
	 * Detect language by the first alphabetic character's script.
	 *
	 * @since 1.0.0
	 * @param string $word Word.
	 * @return string 'ru' | 'en' | '' (unknown).
	 */
	public static function detect( string $word ): string {
		if ( preg_match( '/\p{Cyrillic}/u', $word ) ) {
			return 'ru';
		}

		if ( preg_match( '/[a-z]/i', $word ) ) {
			return 'en';
		}

		return '';
	}

	/**
	 * Get (and cache) a stemmer instance for a language.
	 *
	 * @since 1.0.0
	 * @param string $lang Language code.
	 * @return object|null
	 */
	private static function get_instance( string $lang ) {
		if ( isset( self::$instances[ $lang ] ) ) {
			return self::$instances[ $lang ];
		}

		self::load_library();

		$class = 'ru' === $lang
			? '\\Wamania\\Snowball\\Stemmer\\Russian'
			: ( 'en' === $lang ? '\\Wamania\\Snowball\\Stemmer\\English' : '' );

		if ( '' === $class || ! class_exists( $class ) ) {
			return null;
		}

		self::$instances[ $lang ] = new $class();

		return self::$instances[ $lang ];
	}

	/**
	 * Lazy-require the vendored library on first use.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function load_library(): void {
		if ( self::$loaded ) {
			return;
		}

		$base = MVWEB_SS_PATH . 'includes/vendor/wamania-snowball/';

		require_once $base . 'stringhelper-shim.php';
		require_once $base . 'Stemmer/Stemmer.php';
		require_once $base . 'Stemmer/Stem.php';
		require_once $base . 'Stemmer/Russian.php';
		require_once $base . 'Stemmer/English.php';

		self::$loaded = true;
	}
}
