<?php
/**
 * Search query log (foundation for analytics).
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Records aggregated search queries: how often each phrase is searched and
 * how many results it returned last time (drives "no results" reporting).
 *
 * @since 1.0.0
 */
class MVweb_SS_Log {

	const MAX_LENGTH = 191;

	const RESCUE_OPTION = 'mvweb_ss_rescue_stats';

	/**
	 * Canonical hash of a query, shared by logging and click-boost lookups.
	 *
	 * @since 1.1.0
	 * @param string $query Raw query.
	 * @return string 32-char md5, or '' for an empty query.
	 */
	public static function hash( string $query ): string {
		$query = trim( wp_strip_all_tags( $query ) );
		$query = mb_substr( $query, 0, self::MAX_LENGTH, 'UTF-8' );

		return '' === $query ? '' : md5( mb_strtolower( $query, 'UTF-8' ) );
	}

	/**
	 * Record one search.
	 *
	 * @since 1.0.0
	 * @param string $query   Raw user query.
	 * @param int    $results Result count for this query.
	 * @return void
	 */
	public static function record( string $query, int $results ): void {
		$query = trim( wp_strip_all_tags( $query ) );
		$query = mb_substr( $query, 0, self::MAX_LENGTH, 'UTF-8' );

		if ( '' === $query ) {
			return;
		}

		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();
		$hash  = self::hash( $query );

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				'INSERT INTO %i (query_hash, query, hits, results, updated) VALUES (%s, %s, 1, %d, %s)
				ON DUPLICATE KEY UPDATE hits = hits + 1, results = VALUES(results), updated = VALUES(updated)',
				$table,
				$hash,
				$query,
				max( 0, $results ),
				current_time( 'mysql' )
			)
		);
	}

	/**
	 * Tally one search that a correction mechanism rescued from a dead end.
	 *
	 * Keeps a small running count per mechanism (an aggregate option, not a row
	 * per event), so the admin can see how many searches the Russian-language
	 * recovery layers saved — the visible proof of the moat (F.4). Called only on
	 * a live-search cache miss, so a repeated keystroke of the same typo does not
	 * inflate the count within the cache window.
	 *
	 * @since 1.2.0
	 * @param string $reason Mechanism key ('layout' or 'typo').
	 * @return void
	 */
	public static function record_rescue( string $reason ): void {
		if ( 'layout' !== $reason && 'typo' !== $reason ) {
			return;
		}

		$stats = get_option( self::RESCUE_OPTION, array() );

		if ( ! is_array( $stats ) ) {
			$stats = array();
		}

		$stats[ $reason ] = isset( $stats[ $reason ] ) ? (int) $stats[ $reason ] + 1 : 1;

		update_option( self::RESCUE_OPTION, $stats, false );
	}

	/**
	 * Rescued-search tallies per mechanism.
	 *
	 * @since 1.2.0
	 * @return array<string,int> reason => count.
	 */
	public static function rescue_stats(): array {
		$stats = get_option( self::RESCUE_OPTION, array() );

		return is_array( $stats ) ? array_map( 'intval', $stats ) : array();
	}

	/**
	 * Record one click on a result for a query.
	 *
	 * Updates the existing log row (the query was logged as an impression when
	 * its dropdown was shown), so no phantom rows are created.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @return void
	 */
	public static function record_click( string $query ): void {
		$hash = self::hash( $query );

		if ( '' === $hash ) {
			return;
		}

		global $wpdb;

		$table = MVweb_SS_Schema::log_table_name();

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				'UPDATE %i SET clicks = clicks + 1 WHERE query_hash = %s',
				$table,
				$hash
			)
		);
	}

	/**
	 * Record a click on a specific result for a query (self-learning boost).
	 *
	 * Accumulates per (query, result) so the ranking can gently float results
	 * that shoppers actually pick for that query. Kept separate from the
	 * per-query click tally used for CTR.
	 *
	 * @since 1.1.0
	 * @param string $query     Raw user query.
	 * @param int    $object_id Clicked object ID.
	 * @return void
	 */
	public static function record_result_click( string $query, int $object_id ): void {
		$hash = self::hash( $query );

		if ( '' === $hash || $object_id <= 0 ) {
			return;
		}

		global $wpdb;

		$table = MVweb_SS_Schema::clicks_table_name();

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				'INSERT INTO %i (query_hash, object_id, clicks) VALUES (%s, %d, 1)
				ON DUPLICATE KEY UPDATE clicks = clicks + 1',
				$table,
				$hash,
				$object_id
			)
		);
	}
}
