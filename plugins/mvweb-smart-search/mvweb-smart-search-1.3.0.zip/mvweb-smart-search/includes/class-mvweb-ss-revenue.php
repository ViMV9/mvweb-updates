<?php
/**
 * WooCommerce revenue-per-query attribution.
 *
 * @package mvweb_ss
 * @since   1.1.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Attributes WooCommerce cart adds and orders to the visitor's most recent
 * search (last-search-touch model), so the owner can see which queries earn
 * money. Opt-in; the attribution is deliberately approximate, not exact.
 *
 * @since 1.1.0
 */
class MVweb_SS_Revenue {

	const COOKIE = 'mvweb_ss_lq';

	const ATTR_META = '_mvweb_ss_attributed';

	/**
	 * Register WooCommerce hooks when tracking is enabled.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function register(): void {
		if ( ! class_exists( 'WooCommerce' ) || ! MVweb_SS_Settings::get( 'revenue_tracking', false ) ) {
			return;
		}

		add_action( 'woocommerce_add_to_cart', array( __CLASS__, 'on_add_to_cart' ) );
		add_action( 'woocommerce_checkout_order_processed', array( __CLASS__, 'on_order' ) );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( __CLASS__, 'on_order_object' ) );
	}

	/**
	 * Whether revenue tracking is active (WooCommerce present + setting on).
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function is_active(): bool {
		return class_exists( 'WooCommerce' ) && (bool) MVweb_SS_Settings::get( 'revenue_tracking', false );
	}

	/**
	 * The visitor's last search query from the attribution cookie.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private static function cookie_query(): string {
		if ( empty( $_COOKIE[ self::COOKIE ] ) ) {
			return '';
		}

		$query = sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE ] ) );

		return trim( mb_substr( $query, 0, 191, 'UTF-8' ) );
	}

	/**
	 * Count a cart add against the last search.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function on_add_to_cart(): void {
		$query = self::cookie_query();

		if ( '' !== $query ) {
			self::record_cart( $query );
		}
	}

	/**
	 * Attribute a classic-checkout order (fires with the order ID).
	 *
	 * @since 1.1.0
	 * @param int $order_id Order ID.
	 * @return void
	 */
	public static function on_order( $order_id ): void {
		$order = wc_get_order( (int) $order_id );

		if ( $order ) {
			self::attribute( $order );
		}
	}

	/**
	 * Attribute a Store-API (block checkout) order (fires with the order object).
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order object.
	 * @return void
	 */
	public static function on_order_object( $order ): void {
		if ( $order instanceof WC_Order ) {
			self::attribute( $order );
		}
	}

	/**
	 * Record one order's total against the last search, guarding double counts.
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order.
	 * @return void
	 */
	private static function attribute( $order ): void {
		if ( '' !== (string) $order->get_meta( self::ATTR_META ) ) {
			return;
		}

		$query = self::cookie_query();

		if ( '' === $query ) {
			return;
		}

		$order->update_meta_data( self::ATTR_META, '1' );
		$order->save();

		self::record_order( $query, (float) $order->get_total() );
	}

	/**
	 * Increment the cart-add counter for a query.
	 *
	 * @since 1.1.0
	 * @param string $query Query.
	 * @return void
	 */
	private static function record_cart( string $query ): void {
		global $wpdb;

		$hash = MVweb_SS_Log::hash( $query );

		if ( '' === $hash ) {
			return;
		}

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				'INSERT INTO %i (query_hash, query, carts, updated) VALUES (%s, %s, 1, %s)
				ON DUPLICATE KEY UPDATE carts = carts + 1, query = VALUES(query), updated = VALUES(updated)',
				MVweb_SS_Schema::revenue_table_name(),
				$hash,
				mb_substr( $query, 0, 191, 'UTF-8' ),
				current_time( 'mysql' )
			)
		);
	}

	/**
	 * Add one order and its total to a query's revenue.
	 *
	 * @since 1.1.0
	 * @param string $query Query.
	 * @param float  $total Order total.
	 * @return void
	 */
	private static function record_order( string $query, float $total ): void {
		global $wpdb;

		$hash = MVweb_SS_Log::hash( $query );

		if ( '' === $hash ) {
			return;
		}

		$wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				'INSERT INTO %i (query_hash, query, orders, revenue, updated) VALUES (%s, %s, 1, %f, %s)
				ON DUPLICATE KEY UPDATE orders = orders + 1, revenue = revenue + VALUES(revenue), query = VALUES(query), updated = VALUES(updated)',
				MVweb_SS_Schema::revenue_table_name(),
				$hash,
				mb_substr( $query, 0, 191, 'UTF-8' ),
				max( 0, $total ),
				current_time( 'mysql' )
			)
		);
	}

	/**
	 * Revenue attribution joined with search frequency, best earners first.
	 *
	 * @since 1.1.0
	 * @param int $limit Max rows.
	 * @return array<int,array{query:string,carts:int,orders:int,revenue:float,hits:int}>
	 */
	public static function by_query( int $limit ): array {
		global $wpdb;

		$revenue = MVweb_SS_Schema::revenue_table_name();
		$log     = MVweb_SS_Schema::log_table_name();
		$limit   = max( 1, min( 200, $limit ) );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				'SELECT r.query, r.carts, r.orders, r.revenue, COALESCE( l.hits, 0 ) AS hits
				FROM %i r
				LEFT JOIN %i l ON l.query_hash = r.query_hash
				WHERE r.orders > 0 OR r.carts > 0
				ORDER BY r.revenue DESC, r.orders DESC LIMIT %d',
				$revenue,
				$log,
				$limit
			),
			ARRAY_A
		);

		if ( ! is_array( $rows ) ) {
			return array();
		}

		return array_map(
			static function ( $row ) {
				return array(
					'query'   => (string) $row['query'],
					'carts'   => (int) $row['carts'],
					'orders'  => (int) $row['orders'],
					'revenue' => (float) $row['revenue'],
					'hits'    => (int) $row['hits'],
				);
			},
			$rows
		);
	}
}
