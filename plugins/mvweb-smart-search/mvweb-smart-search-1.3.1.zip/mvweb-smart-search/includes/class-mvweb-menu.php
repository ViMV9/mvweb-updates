<?php
/**
 * MVweb Plugins Menu Registration
 *
 * Handles the registration of the main MVweb Plugins menu
 * that all MVweb plugins use as their parent menu.
 *
 * This file should be included in each MVweb plugin's includes/ folder.
 *
 * Newest-wins loader: every installed plugin bundles its own copy of this
 * file, and copies drift in version. The old guard (`class_exists` → return)
 * let whichever plugin loaded FIRST (alphabetically — mvweb-build-calc) win,
 * even when it shipped an older class missing newer methods/catalog. This
 * two-phase loader instead picks the copy with the HIGHEST version:
 *
 *   Phase 1 (this require): register self as a candidate in a global, keyed by
 *   version, then bail WITHOUT declaring the class. A single boot callback is
 *   scheduled on plugins_loaded:0.
 *   Phase 2 (boot callback): require the winning file with MVWEB_MENU_DECLARING
 *   set, which falls through to the class declaration below, then boots it.
 *
 * Degradation: if a plugin still bundles a pre-2.5.0 copy (no phase logic) and
 * loads first, it declares the class synchronously and wins — same as before,
 * never worse. Full newest-wins requires every installed plugin to carry 2.5.0+
 * (mvweb-build-calc first, since it loads earliest).
 *
 * @package MVweb\Shared
 * @since   1.0.0
 * @version 2.6.1
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Version of THIS copy of the file. A plain local var (not a constant) so every
// bundled copy can compare its own version against the others without clashing.
$mvweb_menu_this_version = '2.6.1';
$mvweb_menu_this_file    = __FILE__;

// ─────────────────────────────────────────────────────────────────────────────
// PHASE 2 — class declaration. Reached only via the boot callback's require,
// which defines MVWEB_MENU_DECLARING first. A normal plugin require never gets
// here (Phase 1 returns below).
// ─────────────────────────────────────────────────────────────────────────────
if ( ! defined( 'MVWEB_MENU_DECLARING' ) ) {

	// ── PHASE 1 — register this copy as a candidate, schedule the boot once. ──

	// Record the file version so the CSS cache-buster keeps working. Only the
	// first copy to load defines it; harmless if it's not the newest, it's a
	// fallback string only (see find_admin_css_source()).
	if ( ! defined( 'MVWEB_MENU_VERSION' ) ) {
		define( 'MVWEB_MENU_VERSION', $mvweb_menu_this_version );
	}

	// Keep the highest-versioned candidate seen so far.
	if (
		empty( $GLOBALS['mvweb_menu_best'] )
		|| version_compare( $mvweb_menu_this_version, $GLOBALS['mvweb_menu_best']['version'], '>' )
	) {
		$GLOBALS['mvweb_menu_best'] = array(
			'version' => $mvweb_menu_this_version,
			'file'    => $mvweb_menu_this_file,
		);
	}

	// Schedule the declaration of the winning copy exactly once. plugins_loaded
	// fires after every active plugin's main file has run its require, so by then
	// every bundled copy has registered. Priority 0 keeps the class ready well
	// before admin_menu / admin_enqueue_scripts, which the constructor hooks.
	if ( ! defined( 'MVWEB_MENU_BOOT_SCHEDULED' ) ) {
		define( 'MVWEB_MENU_BOOT_SCHEDULED', true );
		add_action(
			'plugins_loaded',
			static function () {
				// A pre-2.5.0 copy may have declared the class synchronously and
				// won. Nothing to choose then — just boot whatever exists.
				if ( class_exists( 'MVweb_Menu' ) ) {
					MVweb_Menu::get_instance();
					return;
				}
				if ( empty( $GLOBALS['mvweb_menu_best']['file'] ) ) {
					return;
				}
				define( 'MVWEB_MENU_DECLARING', true );
				require $GLOBALS['mvweb_menu_best']['file'];
				if ( class_exists( 'MVweb_Menu' ) ) {
					MVweb_Menu::get_instance();
				}
			},
			0
		);
	}

	return;
}

/**
 * Class MVweb_Menu
 *
 * Handles the main MVweb Plugins menu registration.
 *
 * The class_exists() guard is what makes Phase 1 above effective. PHP binds a
 * top-level class at compile time, so the declaration used to take effect the
 * moment ANY copy of this file was required — before the `return` in Phase 1
 * could stop it, which handed the hub to whichever plugin loaded first instead
 * of the newest copy. Wrapping the declaration in a condition defers it to run
 * time, so only the copy required by the Phase 2 callback declares the class.
 * The guard also keeps a fatal redeclare away while older copies are still in
 * circulation on a site.
 *
 * @since 1.0.0
 */
if ( ! class_exists( 'MVweb_Menu', false ) ) :
class MVweb_Menu {

	/**
	 * Menu slug for new format plugins.
	 *
	 * Using a unique slug to avoid conflicts with old plugins.
	 *
	 * @var string
	 */
	const MENU_SLUG = 'mvweb-hub';

	/**
	 * Catalog version — bump on every catalog change (see CATALOG below).
	 *
	 * Each plugin bundles its own copy of this class with a possibly different
	 * catalog. The hub collects the catalog from every installed plugin via the
	 * 'mvweb_plugin_catalog' filter and keeps the one with the highest version.
	 * So the freshest published list always wins, regardless of which plugin's
	 * copy of MVweb_Menu happened to load first.
	 *
	 * @since 2.3.0
	 * @var string
	 */
	const CATALOG_VERSION = '2026.08.09';

	/**
	 * Static catalog of all published MVweb plugins (available for download).
	 *
	 * Generated from the ViMV9/mvweb-updates repository by
	 * shared/tools/build-catalog.php (run on every /wp:master release).
	 * Do NOT hand-edit — re-run the generator instead.
	 *
	 * @since 2.3.0
	 * @var array<int, array<string, string>>
	 */
	const CATALOG = array(
		array(
			'slug'         => 'mvweb-build-calc',
			'name'         => 'MVweb Build Calc',
			'description'  => 'Construction calculator library for WordPress. Calculators are rendered via the [mvweb_calc id="..."] shortcode.',
			'version'      => '1.1.1',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-build-calc',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-build-calc/mvweb-build-calc-latest.zip',
		),
		array(
			'slug'         => 'mvweb-child-pages',
			'name'         => 'MVweb Child Pages',
			'description'  => 'Display child pages as a styled list using a shortcode.',
			'version'      => '1.1.0',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-child-pages',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-child-pages/mvweb-child-pages-latest.zip',
		),
		array(
			'slug'         => 'mvweb-contact-bar',
			'name'         => 'MVweb Contact Bar',
			'description'  => 'Fixed contact panel (float bar) in Liquid Glass style with phone, messengers, social links.',
			'version'      => '1.0.7',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-contact-bar',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-contact-bar/mvweb-contact-bar-latest.zip',
		),
		array(
			'slug'         => 'mvweb-custom-functions',
			'name'         => 'MVweb Custom Functions',
			'description'  => 'Execute custom PHP code from WordPress admin.',
			'version'      => '1.0.2',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-custom-functions',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-custom-functions/mvweb-custom-functions-latest.zip',
		),
		array(
			'slug'         => 'mvweb-data-export',
			'name'         => 'MVweb Data Export',
			'description'  => 'Export posts, pages, CPT and WooCommerce products to CSV/TXT.',
			'version'      => '1.0.7',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-data-export',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-data-export/mvweb-data-export-latest.zip',
		),
		array(
			'slug'         => 'mvweb-faq',
			'name'         => 'MVweb FAQ',
			'description'  => 'Блоки «вопрос-ответ» (FAQ) с микроразметкой Schema.org. Вставка через кнопку в классическом редакторе.',
			'version'      => '1.0.3',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-faq',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-faq/mvweb-faq-latest.zip',
		),
		array(
			'slug'         => 'mvweb-fireplace-calc',
			'name'         => 'MVweb Fireplace Calc',
			'description'  => 'Fireplace, stove, chimney and barbecue calculator library for WordPress. Calculators are rendered via the [mvweb_fcalc id="..."] shortcode.',
			'version'      => '1.0.0',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-fireplace-calc',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-fireplace-calc/mvweb-fireplace-calc-latest.zip',
		),
		array(
			'slug'         => 'mvweb-gallery-wall',
			'name'         => 'MVweb Gallery Wall',
			'description'  => 'Customizable photo gallery with grid, masonry, justified, ticker layouts and built-in lightbox.',
			'version'      => '1.0.3',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-gallery-wall',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-gallery-wall/mvweb-gallery-wall-latest.zip',
		),
		array(
			'slug'         => 'mvweb-local-business',
			'name'         => 'MVweb Local Business',
			'description'  => 'LocalBusiness (Schema.org) markup for Google and Yandex: NAP entry form, opening hours, duplicate-free integration into the Yoast/Rank Math graph, and a homepage scanner.',
			'version'      => '1.0.4',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-local-business',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-local-business/mvweb-local-business-latest.zip',
		),
		array(
			'slug'         => 'mvweb-object-map',
			'name'         => 'MVweb Object Map',
			'description'  => 'Show catalog objects on an interactive Yandex map — a non-public custom post type with coordinates, photos, contacts and custom specs, output via the [mvweb_map] shortcode.',
			'version'      => '1.0.6',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-object-map',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-object-map/mvweb-object-map-latest.zip',
		),
		array(
			'slug'         => 'mvweb-pop-up',
			'name'         => 'MVweb Pop-Up',
			'description'  => 'Simple and accessible popup plugin with shortcode trigger.',
			'version'      => '1.0.7',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-pop-up',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-pop-up/mvweb-pop-up-latest.zip',
		),
		array(
			'slug'         => 'mvweb-price-importer',
			'name'         => 'MVweb Price Importer',
			'description'  => 'Automatic import of products from external price lists into WooCommerce.',
			'version'      => '1.0.26',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-price-importer',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-price-importer/mvweb-price-importer-latest.zip',
		),
		array(
			'slug'         => 'mvweb-price-table',
			'name'         => 'MVweb Price Table',
			'description'  => 'Price table with Google Sheets integration for repair services.',
			'version'      => '1.1.15',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-price-table',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-price-table/mvweb-price-table-latest.zip',
		),
		array(
			'slug'         => 'mvweb-reg-domain-filter',
			'name'         => 'MVweb Registration Domain Filter',
			'description'  => 'Restricts new user registration to e-mail addresses in an allowed list of domain zones (e.g. .ru, .рф).',
			'version'      => '1.0.1',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-reg-domain-filter',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-reg-domain-filter/mvweb-reg-domain-filter-latest.zip',
		),
		array(
			'slug'         => 'mvweb-sealant-calc',
			'name'         => 'MVweb Sealant Calc',
			'description'  => 'Калькулятор расхода герметика и клея с расчётом по геометрии шва, рекомендациями по фасовке и интеграцией с WooCommerce.',
			'version'      => '1.0.1',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-sealant-calc',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-sealant-calc/mvweb-sealant-calc-latest.zip',
		),
		array(
			'slug'         => 'mvweb-site-optimizer',
			'name'         => 'MVweb Site Optimizer',
			'description'  => 'Модульный оптимизатор WordPress: чистка <head>, безопасность, SEO-фиксы, performance.',
			'version'      => '1.0.7',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-site-optimizer',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-site-optimizer/mvweb-site-optimizer-latest.zip',
		),
		array(
			'slug'         => 'mvweb-smart-links',
			'name'         => 'MVweb Smart Links',
			'description'  => 'Semi-automatic internal interlinking for content sites: contextual links, related posts, pillar clusters and reports.',
			'version'      => '1.0.1',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-smart-links',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-smart-links/mvweb-smart-links-latest.zip',
		),
		array(
			'slug'         => 'mvweb-smart-search',
			'name'         => 'MVweb Smart Search',
			'description'  => 'Единый поиск по сайту (товары WooCommerce + записи + страницы + CPT) со своим индексом и русской морфологией, AJAX-выпадашкой с картинкой/ценой/наличием. Free, всё-в-одном.',
			'version'      => '1.3.0',
			'homepage'     => 'https://mvweb.ru/plugins/mvweb-smart-search',
			'download_url' => 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main/plugins/mvweb-smart-search/mvweb-smart-search-latest.zip',
		),
	);

	/**
	 * AJAX action name for installing a plugin from the catalog.
	 *
	 * @since 2.3.0
	 * @var string
	 */
	const AJAX_INSTALL_ACTION = 'mvweb_install_plugin';

	/**
	 * Menu capability.
	 *
	 * @var string
	 */
	const CAPABILITY = 'manage_options';

	/**
	 * Menu position.
	 *
	 * Placed at the bottom of the menu after all standard WordPress items.
	 * String type prevents PHP from casting to int (avoids collisions).
	 *
	 * @var string
	 */
	const POSITION = '99.5';

	/**
	 * Hub textdomain — owns the hub's own strings, independent of any plugin.
	 *
	 * @since 2.3.0
	 * @var string
	 */
	const TEXTDOMAIN = 'mvweb-hub';

	/**
	 * Instance of this class.
	 *
	 * @var MVweb_Menu
	 */
	private static $instance = null;

	/**
	 * Textdomain of the first plugin that loaded this class.
	 *
	 * @var string
	 */
	private $textdomain = 'mvweb';

	/**
	 * Flag to track if menu was registered by this class.
	 *
	 * @var bool
	 */
	private static $menu_registered = false;

	/**
	 * Cache of registered plugins collected via filter.
	 *
	 * @since 2.0.0
	 * @var array|null
	 */
	private $registered_plugins = null;

	/**
	 * Get singleton instance.
	 *
	 * @since 1.0.0
	 * @return MVweb_Menu
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		// The hub owns its own textdomain so its strings never depend on which
		// plugin happened to load first. A dedicated 'mvweb-hub' domain with its
		// own bundled .mo keeps the hub translated for any combination of
		// installed plugins.
		$this->textdomain = self::TEXTDOMAIN;
		$this->load_hub_textdomain();

		// Publish this copy's bundled catalog so the hub can pick the newest one
		// across all installed plugins (see get_catalog()).
		add_filter( 'mvweb_plugin_catalog', array( $this, 'contribute_catalog' ) );

		// Register menu at priority 9 (standard recommended practice).
		add_action( 'admin_menu', array( $this, 'register_menu' ), 9 );

		// Sort hub submenu items alphabetically after every plugin has registered
		// its own item. Late priority (999) guarantees all add_submenu_page() calls
		// have already run.
		add_action( 'admin_menu', array( $this, 'sort_submenu' ), 999 );

		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_styles' ) );

		// AJAX endpoint for installing a catalog plugin from the hub.
		add_action( 'wp_ajax_' . self::AJAX_INSTALL_ACTION, array( $this, 'ajax_install_plugin' ) );
	}

	/**
	 * Contribute this copy's bundled catalog to the shared filter.
	 *
	 * Every installed plugin ships a copy of this class. Each one offers its
	 * catalog tagged with CATALOG_VERSION; get_catalog() keeps the newest.
	 *
	 * @since 2.3.0
	 * @param array $catalogs Catalogs collected so far.
	 * @return array
	 */
	public function contribute_catalog( $catalogs ) {
		$catalogs[] = array(
			'version' => self::CATALOG_VERSION,
			'plugins' => self::CATALOG,
		);
		return $catalogs;
	}

	/**
	 * Get the freshest plugin catalog across all installed MVweb plugins.
	 *
	 * Collects every plugin's bundled catalog via the 'mvweb_plugin_catalog'
	 * filter and returns the one with the highest CATALOG_VERSION. This is the
	 * versioning the hub needs: the newest published list wins even when an
	 * older plugin's MVweb_Menu copy loaded first.
	 *
	 * @since 2.3.0
	 * @return array<int, array<string, string>> Catalog rows, indexed by slug.
	 */
	private function get_catalog() {
		$catalogs = apply_filters( 'mvweb_plugin_catalog', array() );

		$best         = null;
		$best_version = '';
		foreach ( (array) $catalogs as $candidate ) {
			if ( empty( $candidate['plugins'] ) ) {
				continue;
			}
			$ver = isset( $candidate['version'] ) ? (string) $candidate['version'] : '0';
			if ( null === $best || version_compare( $ver, $best_version, '>' ) ) {
				$best         = $candidate['plugins'];
				$best_version = $ver;
			}
		}

		if ( null === $best ) {
			$best = self::CATALOG;
		}

		// Re-key by slug for easy diffing against installed plugins.
		$indexed = array();
		foreach ( $best as $row ) {
			if ( ! empty( $row['slug'] ) ) {
				$indexed[ $row['slug'] ] = $row;
			}
		}
		return $indexed;
	}

	/**
	 * Prevent cloning of the singleton instance.
	 *
	 * @since 2.2.0
	 * @return void
	 */
	private function __clone() {}

	/**
	 * Prevent unserialization of the singleton instance.
	 *
	 * @since 2.2.0
	 * @return void
	 * @throws \Exception Always, to prevent unserialization.
	 */
	public function __wakeup() {
		throw new \Exception( 'Cannot unserialize singleton MVweb_Menu.' );
	}

	/**
	 * Load the hub's own translation catalogue.
	 *
	 * The .mo ships in every plugin at includes/languages/mvweb-hub-{locale}.mo.
	 * The two-phase loader picks the HIGHEST-versioned copy of this class to run,
	 * and that winning copy may live in a plugin that does NOT bundle the .mo
	 * (older plugins predate the bundled-translation rule) — its own __DIR__ then
	 * has no file and the hub falls back to English. So we scan EVERY installed
	 * MVweb plugin for the .mo, exactly like find_admin_css_source()/find_logo_url(),
	 * and use the first one found. As long as any active MVweb plugin bundles the
	 * translation, the hub is localised regardless of which copy won the load.
	 *
	 * Loaded once — repeated calls from multiple plugins' copies are a cheap
	 * no-op once the domain is in memory.
	 *
	 * @since 2.3.0
	 * @return void
	 */
	private function load_hub_textdomain() {
		if ( is_textdomain_loaded( self::TEXTDOMAIN ) ) {
			return;
		}

		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		$rel    = 'includes/languages/' . self::TEXTDOMAIN . '-' . $locale . '.mo';

		// Prefer a copy bundled inside any installed MVweb plugin.
		foreach ( array_keys( $this->get_registered_plugins() ) as $slug ) {
			$path = WP_PLUGIN_DIR . '/' . $slug . '/' . $rel;
			if ( file_exists( $path ) ) {
				load_textdomain( self::TEXTDOMAIN, $path );
				return;
			}
		}

		// Fallback: next to this class (shared/languages in dev).
		$mofile = trailingslashit( __DIR__ ) . 'languages/' . self::TEXTDOMAIN . '-' . $locale . '.mo';
		if ( file_exists( $mofile ) ) {
			load_textdomain( self::TEXTDOMAIN, $mofile );
		}
	}

	/**
	 * Get plugins registered via 'mvweb_registered_plugins' filter.
	 *
	 * Each plugin registers itself with add_filter in its entry point.
	 * Results are cached after the first call.
	 *
	 * @since 2.0.0
	 * @return array Associative array keyed by plugin slug.
	 */
	private function get_registered_plugins() {
		if ( null === $this->registered_plugins ) {
			$plugins = apply_filters( 'mvweb_registered_plugins', array() );

			// Ensure indexed by slug.
			$indexed = array();
			foreach ( $plugins as $key => $plugin ) {
				if ( is_string( $key ) && ! empty( $plugin['name'] ) ) {
					$indexed[ $key ] = $plugin;
				}
			}

			$this->registered_plugins = $indexed;
		}

		return $this->registered_plugins;
	}

	/**
	 * Register the main MVweb Plugins menu.
	 *
	 * Uses unique slug 'mvweb-hub' to avoid conflicts with old plugins
	 * that may use 'mvweb-plugins' slug.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register_menu() {
		// Only register once.
		if ( self::$menu_registered ) {
			return;
		}

		// Check if menu already registered by another instance.
		if ( ! empty( $GLOBALS['admin_page_hooks'][ self::MENU_SLUG ] ) ) {
			self::$menu_registered = true;
			return;
		}

		// Register top-level menu.
		add_menu_page(
			__( 'MVweb Hub', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			__( 'MVweb Hub', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			self::CAPABILITY,
			self::MENU_SLUG,
			array( $this, 'render_about_page' ),
			$this->get_menu_icon(),
			self::POSITION
		);

		// Add main submenu (replaces default submenu).
		add_submenu_page(
			self::MENU_SLUG,
			__( 'MVweb Plugins', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			__( 'All Plugins', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			self::CAPABILITY,
			self::MENU_SLUG,
			array( $this, 'render_about_page' )
		);

		self::$menu_registered = true;
	}

	/**
	 * Sort the hub's submenu items alphabetically by visible title.
	 *
	 * Each MVweb plugin registers its own submenu item via add_submenu_page(),
	 * so the natural order is "whichever plugin loaded first". This reorders
	 * them by their displayed menu title (locale-aware), while keeping the
	 * hub's own "All Plugins" entry pinned to the top.
	 *
	 * Runs on admin_menu at priority 999, after every plugin has registered.
	 *
	 * @since 2.4.0
	 * @return void
	 */
	public function sort_submenu() {
		if ( empty( $GLOBALS['submenu'][ self::MENU_SLUG ] ) || ! is_array( $GLOBALS['submenu'][ self::MENU_SLUG ] ) ) {
			return;
		}

		$items = $GLOBALS['submenu'][ self::MENU_SLUG ];

		usort(
			$items,
			function ( $a, $b ) {
				// Pin the hub's own "All Plugins" page (slug === MENU_SLUG) first.
				$a_is_hub = isset( $a[2] ) && self::MENU_SLUG === $a[2];
				$b_is_hub = isset( $b[2] ) && self::MENU_SLUG === $b[2];
				if ( $a_is_hub !== $b_is_hub ) {
					return $a_is_hub ? -1 : 1;
				}

				// Compare by visible title; strip any HTML (counters/badges).
				$a_title = isset( $a[0] ) ? wp_strip_all_tags( $a[0] ) : '';
				$b_title = isset( $b[0] ) ? wp_strip_all_tags( $b[0] ) : '';

				if ( function_exists( 'mb_strtolower' ) ) {
					$a_title = mb_strtolower( $a_title, 'UTF-8' );
					$b_title = mb_strtolower( $b_title, 'UTF-8' );
				}

				return strcoll( $a_title, $b_title );
			}
		);

		// Re-index so WordPress reads a clean, ordered list. WordPress exposes no
		// API to reorder a submenu, so writing the global back is the only way.
		// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited
		$GLOBALS['submenu'][ self::MENU_SLUG ] = array_values( $items );
	}

	/**
	 * Get menu icon.
	 *
	 * @since 1.0.0
	 * @return string Base64 encoded SVG icon or dashicon.
	 */
	private function get_menu_icon() {
		return 'dashicons-admin-generic';
	}

	/**
	 * Render the About MVweb page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function render_about_page() {
		$installed_plugins  = $this->get_mvweb_plugins();
		$registered_plugins = $this->get_registered_plugins();
		$catalog            = $this->get_catalog();
		$td                 = $this->textdomain;

		// All MVweb plugin slugs physically present on the site (installed),
		// whether registered via the filter or not — so the catalog never
		// promotes something already on disk.
		$present_slugs = array();
		foreach ( array_keys( $this->get_all_installed_slugs() ) as $slug ) {
			$present_slugs[ $slug ] = true;
		}
		$available = array_diff_key( $catalog, $present_slugs );
		?>
		<?php $logo_url = $this->find_logo_url(); ?>
		<div class="wrap mvweb-hub mvweb-settings">

			<div class="mvweb-hero">
				<?php if ( $logo_url ) : ?>
					<img class="mvweb-hero__logo-img" src="<?php echo esc_url( $logo_url ); ?>" alt="MVweb" width="64" height="64" />
				<?php else : ?>
					<div class="mvweb-hero__logo">MV</div>
				<?php endif; ?>
				<div>
					<h1 class="mvweb-hero__title"><?php esc_html_e( 'MVweb Plugins', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></h1>
					<p class="mvweb-hero__desc">
						<?php esc_html_e( 'MVweb is a web development studio specializing in WordPress plugins and themes. We create high-quality, secure, and well-documented solutions for WordPress.', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
					</p>
				</div>
				<div>
					<a href="https://mvweb.ru" target="_blank" rel="noopener noreferrer" class="mvweb-btn mvweb-btn--primary">
						<?php esc_html_e( 'Visit our website', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?> &rarr;
					</a>
				</div>
			</div>

			<?php if ( ! empty( $installed_plugins ) ) : ?>
				<div class="mvweb-section-title">
					<h2><?php esc_html_e( 'Installed plugins', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></h2>
					<span class="mvweb-section-title__count"><?php echo esc_html( count( $installed_plugins ) ); ?></span>
				</div>

				<div class="mvweb-plugins-grid">
					<?php foreach ( $installed_plugins as $plugin_file => $plugin ) : ?>
						<?php
						$is_active    = is_plugin_active( $plugin_file );
						$plugin_slug  = dirname( $plugin_file );
						$plugin_info  = isset( $registered_plugins[ $plugin_slug ] ) ? $registered_plugins[ $plugin_slug ] : array();
						$settings_url = ! empty( $plugin_info['settings_url'] )
							? admin_url( $plugin_info['settings_url'] )
							: null;
						$icon         = $this->get_plugin_icon_label( $plugin_slug, $plugin['Name'] );
						?>
						<div class="mvweb-card <?php echo $is_active ? '' : 'mvweb-card--inactive'; ?>">
							<div class="mvweb-plugin-card__head">
								<div class="mvweb-plugin-card__id">
									<div class="mvweb-plugin-card__icon"><?php echo esc_html( $icon ); ?></div>
									<div>
										<h3 class="mvweb-plugin-card__title"><?php echo esc_html( $plugin['Name'] ); ?></h3>
										<p class="mvweb-plugin-card__version">v<?php echo esc_html( $plugin['Version'] ); ?></p>
									</div>
								</div>
								<span class="mvweb-badge <?php echo $is_active ? 'mvweb-badge--success' : 'mvweb-badge--plain'; ?>">
									<?php echo $is_active ? esc_html__( 'active', $td ) : esc_html__( 'inactive', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
								</span>
							</div>
							<p class="mvweb-plugin-card__desc"><?php echo esc_html( $plugin['Description'] ); ?></p>
							<div class="mvweb-plugin-card__actions">
								<?php if ( $is_active && $settings_url ) : ?>
									<a href="<?php echo esc_url( $settings_url ); ?>" class="mvweb-btn mvweb-btn--primary mvweb-btn--sm">
										<?php esc_html_e( 'Settings', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								<?php elseif ( ! $is_active ) : ?>
									<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'plugins.php?action=activate&plugin=' . rawurlencode( $plugin_file ) ), 'activate-plugin_' . $plugin_file ) ); ?>" class="mvweb-btn mvweb-btn--primary mvweb-btn--sm">
										<?php esc_html_e( 'Activate', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								<?php endif; ?>
								<?php if ( ! empty( $plugin['PluginURI'] ) ) : ?>
									<a href="<?php echo esc_url( $plugin['PluginURI'] ); ?>" target="_blank" rel="noopener noreferrer" class="mvweb-btn mvweb-btn--sm">
										<?php esc_html_e( 'Docs', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								<?php endif; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php else : ?>
				<div class="mvweb-empty">
					<p><?php esc_html_e( 'No MVweb plugins installed yet.', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></p>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $available ) ) : ?>
				<div class="mvweb-section-title">
					<h2><?php esc_html_e( 'Available plugins', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></h2>
					<span class="mvweb-section-title__count"><?php echo esc_html( count( $available ) ); ?></span>
				</div>
				<div class="mvweb-plugins-grid">
					<?php foreach ( $available as $slug => $plugin_info ) : ?>
						<?php
						$icon         = $this->get_plugin_icon_label( $slug, $plugin_info['name'] );
						$can_install  = ! empty( $plugin_info['download_url'] ) && current_user_can( 'install_plugins' );
						$version      = ! empty( $plugin_info['version'] ) ? $plugin_info['version'] : '';
						$homepage_url = ! empty( $plugin_info['homepage'] ) ? $plugin_info['homepage'] : '';
						?>
						<div class="mvweb-card mvweb-card--available" data-mvweb-slug="<?php echo esc_attr( $slug ); ?>">
							<div class="mvweb-plugin-card__head">
								<div class="mvweb-plugin-card__id">
									<div class="mvweb-plugin-card__icon"><?php echo esc_html( $icon ); ?></div>
									<div>
										<h3 class="mvweb-plugin-card__title"><?php echo esc_html( $plugin_info['name'] ); ?></h3>
										<?php if ( '' !== $version ) : ?>
											<p class="mvweb-plugin-card__version">v<?php echo esc_html( $version ); ?></p>
										<?php endif; ?>
									</div>
								</div>
								<span class="mvweb-badge mvweb-badge--warning">
									<?php esc_html_e( 'not installed', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
								</span>
							</div>
							<p class="mvweb-plugin-card__desc"><?php echo esc_html( $plugin_info['description'] ); ?></p>
							<div class="mvweb-plugin-card__actions">
								<?php if ( $can_install ) : ?>
									<button type="button"
										class="mvweb-btn mvweb-btn--primary mvweb-btn--sm mvweb-install-btn"
										data-slug="<?php echo esc_attr( $slug ); ?>"
										data-download="<?php echo esc_url( $plugin_info['download_url'] ); ?>">
										<?php esc_html_e( 'Install', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</button>
								<?php endif; ?>
								<?php if ( '' !== $homepage_url ) : ?>
									<a href="<?php echo esc_url( $homepage_url ); ?>" target="_blank" rel="noopener noreferrer" class="mvweb-btn mvweb-btn--sm">
										<?php esc_html_e( 'Learn More', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								<?php endif; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
		$this->print_install_script();
	}

	/**
	 * Build a short 2-letter icon label from plugin slug (mvweb-build-calc → BC).
	 *
	 * @since 2.2.0
	 * @param string $slug Plugin directory slug.
	 * @param string $name Plugin display name (fallback).
	 * @return string Two-letter uppercase label.
	 */
	private function get_plugin_icon_label( $slug, $name = '' ) {
		$slug  = preg_replace( '/^mvweb-/', '', (string) $slug );
		$parts = preg_split( '/[-_\s]+/', $slug );
		if ( ! empty( $parts ) ) {
			if ( count( $parts ) === 1 && strlen( $parts[0] ) >= 2 ) {
				return strtoupper( substr( $parts[0], 0, 2 ) );
			}
			if ( count( $parts ) >= 2 ) {
				return strtoupper( substr( $parts[0], 0, 1 ) . substr( $parts[1], 0, 1 ) );
			}
		}
		return strtoupper( substr( preg_replace( '/[^A-Za-z]/', '', $name ), 0, 2 ) );
	}

	/**
	 * Get list of installed MVweb plugins.
	 *
	 * Only returns plugins registered via 'mvweb_registered_plugins' filter.
	 *
	 * @since 1.0.0
	 * @return array List of MVweb plugins.
	 */
	private function get_mvweb_plugins() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$all_plugins   = get_plugins();
		$mvweb_plugins = array();
		$allowed_slugs = array_keys( $this->get_registered_plugins() );

		foreach ( $all_plugins as $plugin_file => $plugin_data ) {
			$plugin_slug = dirname( $plugin_file );

			if ( in_array( $plugin_slug, $allowed_slugs, true ) ) {
				$mvweb_plugins[ $plugin_file ] = $plugin_data;
			}
		}

		/**
		 * Translate plugin headers (Name, Description) for each plugin.
		 *
		 * WordPress get_plugins() caches data WITHOUT translations ($translate = false).
		 * We must explicitly call _get_plugin_data_markup_translate() to get
		 * translated headers, just like get_plugin_data() does with $translate = true.
		 */
		if ( function_exists( '_get_plugin_data_markup_translate' ) ) {
			foreach ( $mvweb_plugins as $plugin_file => $plugin_data ) {
				$mvweb_plugins[ $plugin_file ] = _get_plugin_data_markup_translate(
					WP_PLUGIN_DIR . '/' . $plugin_file,
					$plugin_data,
					false,
					true
				);
			}
		}

		return $mvweb_plugins;
	}

	/**
	 * Enqueue admin styles for MVweb Hub page.
	 *
	 * Loads admin.css from the first installed and active MVweb plugin. Copies do
	 * drift — each plugin gets the current UI Kit only when it is released — so
	 * which generation of the Kit lands here depends on plugin load order. The hub
	 * markup therefore carries .mvweb-settings, the Kit's documented activator:
	 * newer Kits scope their element resets to it, older ones apply them globally,
	 * and the page renders the same either way.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_styles( $hook ) {
		if ( 'toplevel_page_' . self::MENU_SLUG !== $hook ) {
			return;
		}

		$source = $this->find_admin_css_source();
		if ( null === $source ) {
			return;
		}

		wp_enqueue_style(
			'mvweb-hub-ui-kit',
			$source['url'],
			array(),
			$source['ver']
		);

		wp_add_inline_style(
			'mvweb-hub-ui-kit',
			'.mvweb-hero__logo-img{width:64px;height:64px;border-radius:var(--radius-2xl);display:block;flex-shrink:0;}'
		);
	}

	/**
	 * Locate mv-logo-violet.png from any installed MVweb plugin.
	 *
	 * Falls back to the textual "MV" placeholder if no plugin bundles it.
	 *
	 * @since 2.2.0
	 * @return string|null Logo URL or null if not found.
	 */
	private function find_logo_url() {
		foreach ( array_keys( $this->get_registered_plugins() ) as $slug ) {
			$path = WP_PLUGIN_DIR . '/' . $slug . '/images/mv-logo-violet.png';
			if ( file_exists( $path ) ) {
				return plugins_url( $slug . '/images/mv-logo-violet.png' );
			}
		}
		return null;
	}

	/**
	 * Locate admin.css from any installed MVweb plugin.
	 *
	 * @since 2.2.0
	 * @return array|null { url, ver } or null if not found.
	 */
	private function find_admin_css_source() {
		$candidates = array( 'admin/css/admin.min.css', 'admin/css/admin.css' );

		foreach ( array_keys( $this->get_registered_plugins() ) as $slug ) {
			foreach ( $candidates as $rel ) {
				$path = WP_PLUGIN_DIR . '/' . $slug . '/' . $rel;
				if ( file_exists( $path ) ) {
					$mtime = filemtime( $path );
					return array(
						'url' => plugins_url( $slug . '/' . $rel ),
						'ver' => $mtime ? (string) $mtime : MVWEB_MENU_VERSION,
					);
				}
			}
		}

		return null;
	}

	/**
	 * Get slugs of every MVweb plugin physically present on the site.
	 *
	 * Unlike get_mvweb_plugins() (which only returns plugins registered via the
	 * filter), this scans all installed plugins and matches catalog slugs, so a
	 * plugin that is on disk but inactive still counts as "installed" and won't
	 * be promoted in the available section.
	 *
	 * @since 2.3.0
	 * @return array<string, true> Map of slug => true.
	 */
	private function get_all_installed_slugs() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$slugs = array();
		foreach ( array_keys( get_plugins() ) as $plugin_file ) {
			$slugs[ dirname( $plugin_file ) ] = true;
		}
		return $slugs;
	}

	/**
	 * Print the inline JS that drives the catalog "Install" buttons.
	 *
	 * Vanilla JS, no dependencies. Posts to admin-ajax with a nonce, then
	 * reloads on success so the plugin moves to the installed section.
	 *
	 * @since 2.3.0
	 * @return void
	 */
	private function print_install_script() {
		$nonce      = wp_create_nonce( self::AJAX_INSTALL_ACTION );
		$ajax_url   = admin_url( 'admin-ajax.php' );
		$action     = self::AJAX_INSTALL_ACTION;
		$installing = esc_js( __( 'Installing…', $this->textdomain ) ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
		$failed     = esc_js( __( 'Install failed', $this->textdomain ) ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
		?>
		<script>
		( function () {
			var ajaxUrl = <?php echo wp_json_encode( $ajax_url ); ?>;
			var action  = <?php echo wp_json_encode( $action ); ?>;
			var nonce   = <?php echo wp_json_encode( $nonce ); ?>;
			var lblBusy = <?php echo wp_json_encode( $installing ); ?>;
			var lblFail = <?php echo wp_json_encode( $failed ); ?>;

			document.querySelectorAll( '.mvweb-install-btn' ).forEach( function ( btn ) {
				btn.addEventListener( 'click', function () {
					if ( btn.disabled ) {
						return;
					}
					var original = btn.textContent;
					btn.disabled = true;
					btn.textContent = lblBusy;

					var body = new URLSearchParams();
					body.append( 'action', action );
					body.append( 'nonce', nonce );
					body.append( 'slug', btn.getAttribute( 'data-slug' ) );
					body.append( 'download_url', btn.getAttribute( 'data-download' ) );

					fetch( ajaxUrl, {
						method: 'POST',
						credentials: 'same-origin',
						headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
						body: body.toString()
					} ).then( function ( r ) {
						return r.json();
					} ).then( function ( res ) {
						if ( res && res.success ) {
							window.location.reload();
						} else {
							btn.disabled = false;
							btn.textContent = ( res && res.data && res.data.message ) ? res.data.message : lblFail;
						}
					} ).catch( function () {
						btn.disabled = false;
						btn.textContent = lblFail;
					} );
				} );
			} );
		}() );
		</script>
		<?php
	}

	/**
	 * AJAX handler: install (and activate) a catalog plugin from its ZIP.
	 *
	 * Uses the native Plugin_Upgrader so the download, unzip, and install go
	 * through WordPress' own vetted pipeline. The download URL is validated
	 * against the catalog to prevent installing arbitrary ZIPs.
	 *
	 * @since 2.3.0
	 * @return void
	 */
	public function ajax_install_plugin() {
		check_ajax_referer( self::AJAX_INSTALL_ACTION, 'nonce' );

		if ( ! current_user_can( 'install_plugins' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', $this->textdomain ) ) ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
		}

		$slug = isset( $_POST['slug'] ) ? sanitize_key( wp_unslash( $_POST['slug'] ) ) : '';
		if ( '' === $slug ) {
			wp_send_json_error( array( 'message' => __( 'Missing plugin slug.', $this->textdomain ) ) ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
		}

		// Resolve the download URL from the catalog (not from the request) so an
		// attacker cannot point the installer at an arbitrary ZIP.
		$catalog = $this->get_catalog();
		if ( empty( $catalog[ $slug ]['download_url'] ) ) {
			wp_send_json_error( array( 'message' => __( 'Plugin not found in catalog.', $this->textdomain ) ) ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
		}
		$download_url = $catalog[ $slug ]['download_url'];

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/misc.php';
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
		require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		$skin     = new WP_Ajax_Upgrader_Skin();
		$upgrader = new Plugin_Upgrader( $skin );
		$result   = $upgrader->install( $download_url );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}
		if ( is_wp_error( $skin->result ) ) {
			wp_send_json_error( array( 'message' => $skin->result->get_error_message() ) );
		}
		if ( false === $result ) {
			$errors = $skin->get_errors();
			$msg    = is_wp_error( $errors ) && $errors->has_errors()
				? $errors->get_error_message()
				: __( 'Installation failed.', $this->textdomain ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			wp_send_json_error( array( 'message' => $msg ) );
		}

		// Activate the freshly installed plugin.
		$plugin_file = $upgrader->plugin_info();
		if ( $plugin_file ) {
			$activated = activate_plugin( $plugin_file );
			if ( is_wp_error( $activated ) ) {
				// Installed but not activated — still a success for the catalog.
				wp_send_json_success(
					array(
						'message'   => __( 'Installed (activate manually).', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
						'activated' => false,
					)
				);
			}
		}

		wp_send_json_success(
			array(
				'message'   => __( 'Installed.', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
				'activated' => true,
			)
		);
	}

	/**
	 * Get menu slug.
	 *
	 * @since 1.0.0
	 * @return string Menu slug.
	 */
	public static function get_menu_slug() {
		return self::MENU_SLUG;
	}
}
endif;

// The singleton is booted by the Phase 2 callback (see the loader at the top of
// this file) right after this winning copy is required, so no get_instance()
// call belongs here — adding one would only run during that same require.
