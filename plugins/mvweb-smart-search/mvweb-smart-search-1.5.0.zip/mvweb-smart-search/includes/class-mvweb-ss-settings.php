<?php
/**
 * Central read access to plugin settings.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Single source of truth for the `mvweb_ss_settings` option.
 *
 * @since 1.0.0
 */
class MVweb_SS_Settings {

	const OPTION = 'mvweb_ss_settings';

	/**
	 * Default settings.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function defaults(): array {
		$types = array( 'post', 'page' );

		if ( class_exists( 'WooCommerce' ) ) {
			$types[] = 'product';
		}

		return array(
			'post_types'                => $types,
			'cf_whitelist'              => array(),
			'fuzzy'                     => true,
			'fuzzy_aggressive'          => false,
			'synonym_prefix'            => true,
			'prefix_last_word'          => true,
			'strictness'                => 'balanced',
			'title_coverage'            => false,
			'ranking_use_idf'           => true,
			'ranking_doclen'            => true,
			'exact_match_boost'         => 5.0,
			'boost_popularity'          => 20,
			'zero_fallback_bestsellers' => true,
			'boost_proximity'           => false,
			'translit_cross_script'     => true,
			'index_single_char_models'  => true,
			'normalize_models'          => true,
			'index_shortcodes'          => false,
			'default_synonyms'          => true,
			'click_boost'               => false,
			'click_boost_strength'      => 30,
			'weekly_digest'             => false,
			'digest_email'              => '',
			'revenue_tracking'          => false,
			'reindex_catchup'           => true,
			'catchup_interval'          => 'daily',
			'log_retention_days'        => 90,
			'scheduled_reindex'         => 'off',
			'auto_replace'              => true,
			'stock'                     => 'show',
			'add_to_cart'               => true,
			'weights'                   => array(),
			'synonyms'                  => '',
			'stopwords'                 => '',
			'exclude_ids'               => array(),
			'pins'                      => '',
			'redirects'                 => '',
			'accent_color'              => '#793ea4',
			'placeholder'               => '',
			'text_no_results'           => '',
			'zero_cta_text'             => '',
			'zero_cta_url'              => '',
			'text_see_all'              => '',
			'panel_width'               => 640,
			'show_image'                => true,
			'show_price'                => true,
			'show_stock'                => true,
			'show_excerpt'              => true,
			'show_categories'           => true,
			'show_brands'               => true,
			'cat_limit'                 => 5,
			'filter_tabs'               => true,
			'details_panel'             => true,
			'mobile_overlay'            => true,
			'min_chars'                 => 2,
			'debounce_ms'               => 200,
			'sugg_limit'                => 10,
			'per_group_limit'           => 0,
			'highlight'                 => true,
			'fuzzy_notice'              => 'suggest',
			'group_order'               => 'products',
			'results_per_page'          => 0,
			'results_max'               => 300,
			'results_facets'            => true,
			'facet_limit'               => 10,
			'layout'                    => 'list',
			'search_history'            => true,
			'popular_searches'          => true,
			'popular_limit'             => 6,
			'cat_selector'              => false,
			'cat_taxonomy'              => class_exists( 'WooCommerce' ) ? 'product_cat' : 'category',
			'bar_size'                  => 'm',
			'bar_radius'                => 'rounded',
			'bar_border_color'          => '',
			'bar_bg_color'              => '',
			'bar_text_color'            => '',
			'bar_max_width'             => 520,
			'bar_height'                => 0,
			'bar_font_size'             => 0,
			'text_weight'               => 'normal',
			'submit_style'              => 'icon',
			'submit_text'               => '',
			'submit_bg_color'           => '',
			'submit_icon_color'         => '',
			'input_icon'                => false,
			'icon_plain'                => false,
			'icon_color'                => '',
			'display_desktop'           => 'bar',
			'display_mobile'            => 'bar',
			'link_text'                 => '',
		);
	}

	/**
	 * Custom stop words (lowercased, ё→е), merged into the tokenizer.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	public static function custom_stopwords(): array {
		$out = array();

		foreach ( preg_split( '/[\r\n]+/', (string) self::get( 'stopwords', '' ) ) as $line ) {
			$word = str_replace( 'ё', 'е', mb_strtolower( trim( (string) $line ), 'UTF-8' ) );

			if ( '' !== $word ) {
				$out[] = $word;
			}
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Synonym rules from the local textarea and installed dictionary packs.
	 *
	 * Each rule matches when the query contains ALL of its pattern stems
	 * (order-independent) and then contributes the stems of every other
	 * entry in the same group. Multi-word entries ("жидкие гвозди") are
	 * tokenized with the same stemmer the index uses, so phrases match.
	 *
	 * @since 1.0.0
	 * @return array<int,array{pattern:string[],add:string[]}>
	 */
	public static function synonym_map(): array {
		// The rules are constant within a request (settings do not change mid-search),
		// yet expand_groups() asks for them on every run/retry/facet pass. Assembling
		// and tokenizing ~30 built-in groups plus user and dictionary groups each time
		// is pure waste, so build once per request.
		static $map = null;

		if ( null !== $map ) {
			return $map;
		}

		$groups = self::local_synonym_groups();

		if ( self::get( 'default_synonyms', true ) ) {
			$groups = array_merge( $groups, self::default_synonym_groups() );
		}

		if ( class_exists( 'MVweb_SS_Dictionaries' ) ) {
			$groups = array_merge( $groups, MVweb_SS_Dictionaries::active_groups() );
		}

		$map = self::build_rules_from_groups( $groups );

		return $map;
	}

	/**
	 * Bundled default synonym and transliteration-exception groups, so common
	 * Russian e-commerce equivalences and brand spellings work out of the box with
	 * no download (the flagship "understands Russian from the box"). Each group
	 * only fires when the query contains one of its words, so groups for a niche a
	 * shop does not sell simply never activate. Owners disable it with one setting.
	 *
	 * @since 1.2.0
	 * @return array<int,string[]>
	 */
	public static function default_synonym_groups(): array {
		$groups = array(
			// Phonetic brand spellings the plain transliterator cannot reach.
			array( 'айфон', 'iphone' ),
			array( 'айпад', 'ipad' ),
			array( 'эпл', 'apple' ),
			array( 'самсунг', 'samsung' ),
			array( 'сяоми', 'ксиоми', 'ксяоми', 'xiaomi' ),
			array( 'редми', 'redmi' ),
			array( 'поко', 'poco' ),
			array( 'реалми', 'realme' ),
			array( 'хуавей', 'хуавэй', 'huawei' ),
			array( 'хонор', 'honor' ),
			array( 'оппо', 'oppo' ),
			array( 'виво', 'vivo' ),
			array( 'нокиа', 'nokia' ),
			array( 'техно', 'tecno' ),
			array( 'асус', 'asus' ),
			array( 'леново', 'lenovo' ),
			// Common part / accessory equivalences.
			array( 'аккумулятор', 'батарея', 'акб', 'батарейка' ),
			array( 'дисплей', 'экран', 'матрица' ),
			array( 'стекло', 'защитное стекло', 'бронестекло' ),
			array( 'чехол', 'бампер', 'накладка', 'кейс' ),
			array( 'зарядка', 'зарядное устройство', 'зарядник', 'блок питания' ),
			array( 'кабель', 'провод', 'шнур' ),
			array( 'наушники', 'гарнитура', 'хендсфри' ),
			array( 'повербанк', 'внешний аккумулятор', 'пауэрбанк' ),
			array( 'флешка', 'usb накопитель', 'флеш накопитель' ),
			array( 'ноутбук', 'ноут', 'лэптоп' ),
			array( 'смартфон', 'телефон', 'мобильный телефон' ),
			array( 'планшет', 'таблет' ),
			array( 'часы', 'смарт часы', 'умные часы' ),
		);

		/**
		 * Filter the bundled default synonym groups.
		 *
		 * @since 1.2.0
		 * @param array<int,string[]> $groups Default groups.
		 */
		return (array) apply_filters( 'mvweb_ss_default_synonym_groups', $groups );
	}

	/**
	 * Parse the local synonyms textarea into groups of interchangeable entries.
	 *
	 * @since 1.0.0
	 * @return array<int,string[]> Each group is a list of raw phrase strings.
	 */
	private static function local_synonym_groups(): array {
		$groups = array();

		foreach ( preg_split( '/[\r\n]+/', (string) self::get( 'synonyms', '' ) ) as $line ) {
			$entries = array();

			foreach ( explode( ',', (string) $line ) as $phrase ) {
				$phrase = trim( (string) $phrase );

				if ( '' !== $phrase ) {
					$entries[] = $phrase;
				}
			}

			$entries = array_values( array_unique( $entries ) );

			if ( count( $entries ) >= 2 ) {
				$groups[] = $entries;
			}
		}

		return $groups;
	}

	/**
	 * Turn interchangeable-entry groups into phrase-aware synonym rules.
	 *
	 * @since 1.0.0
	 * @param array<int,string[]> $groups Groups of raw phrase strings.
	 * @return array<int,array{pattern:string[],add:string[]}>
	 */
	private static function build_rules_from_groups( array $groups ): array {
		$rules = array();

		foreach ( $groups as $group ) {
			if ( ! is_array( $group ) ) {
				continue;
			}

			$variants = array();

			foreach ( $group as $phrase ) {
				// Cast to string: a purely numeric stem ("1660") would otherwise be
				// an int array key, and downstream mb_* calls require strings.
				$stems = array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( (string) $phrase ) ) );

				if ( ! empty( $stems ) ) {
					$variants[] = $stems;
				}
			}

			if ( count( $variants ) < 2 ) {
				continue;
			}

			foreach ( $variants as $i => $pattern ) {
				$add = array();

				foreach ( $variants as $j => $other ) {
					if ( $i !== $j ) {
						$add = array_merge( $add, $other );
					}
				}

				$rules[] = array(
					'pattern' => $pattern,
					'add'     => array_values( array_unique( $add ) ),
				);
			}
		}

		return $rules;
	}

	/**
	 * Object IDs excluded from search results.
	 *
	 * @since 1.0.0
	 * @return int[]
	 */
	public static function excluded_ids(): array {
		$out = array();

		foreach ( (array) self::get( 'exclude_ids', array() ) as $id ) {
			$id = (int) $id;

			if ( $id > 0 ) {
				$out[] = $id;
			}
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Pinned object IDs for a normalized query, or an empty array.
	 *
	 * Each line: `query => id, id`. Match is on the normalized whole query.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @return int[]
	 */
	public static function pins_for( string $query ): array {
		$key = self::normalize_query( $query );

		if ( '' === $key ) {
			return array();
		}

		foreach ( preg_split( '/[\r\n]+/', (string) self::get( 'pins', '' ) ) as $line ) {
			$parts = explode( '=>', (string) $line, 2 );

			if ( count( $parts ) < 2 || self::normalize_query( $parts[0] ) !== $key ) {
				continue;
			}

			$ids = array();

			foreach ( explode( ',', $parts[1] ) as $id ) {
				$id = (int) trim( $id );

				if ( $id > 0 ) {
					$ids[] = $id;
				}
			}

			return array_values( array_unique( $ids ) );
		}

		return array();
	}

	/**
	 * Redirect URL configured for an exact query, or an empty string.
	 *
	 * Each line: `query => https://example.com/target`.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @return string
	 */
	public static function redirect_for( string $query ): string {
		$key = self::normalize_query( $query );

		if ( '' === $key ) {
			return '';
		}

		foreach ( preg_split( '/[\r\n]+/', (string) self::get( 'redirects', '' ) ) as $line ) {
			$parts = explode( '=>', (string) $line, 2 );

			if ( count( $parts ) < 2 || self::normalize_query( $parts[0] ) !== $key ) {
				continue;
			}

			$url = esc_url_raw( trim( $parts[1] ) );

			if ( '' !== $url ) {
				return $url;
			}
		}

		return '';
	}

	/**
	 * Normalize a query string for pin matching.
	 *
	 * @since 1.0.0
	 * @param string $query Query.
	 * @return string
	 */
	private static function normalize_query( string $query ): string {
		$query = str_replace( 'ё', 'е', mb_strtolower( trim( $query ), 'UTF-8' ) );

		return (string) preg_replace( '/\s+/u', ' ', $query );
	}

	/**
	 * All settings merged with defaults.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function all(): array {
		$saved = get_option( self::OPTION, array() );

		return wp_parse_args( is_array( $saved ) ? $saved : array(), self::defaults() );
	}

	/**
	 * A single setting value.
	 *
	 * @since 1.0.0
	 * @param string $key      Setting key.
	 * @param mixed  $fallback Fallback value when the key is unset.
	 * @return mixed
	 */
	public static function get( string $key, $fallback = null ) {
		$all = self::all();

		return array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
	}
}
