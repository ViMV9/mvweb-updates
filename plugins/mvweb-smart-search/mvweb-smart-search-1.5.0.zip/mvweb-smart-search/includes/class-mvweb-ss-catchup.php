<?php
/**
 * Incremental watermark catch-up: a universal safety net that re-indexes any
 * object changed since the last pass, regardless of how it was written.
 *
 * @package mvweb_ss
 * @since   1.2.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A WP-Cron pass that sweeps objects whose post_modified_gmt moved past a stored
 * watermark and re-indexes only those. Catches bulk imports and tools that bypass
 * the standard save/WooCommerce hooks (which MVweb_SS_Sync relies on) as long as
 * they touch post_modified. Incremental and cheap — never a full rebuild.
 *
 * @since 1.2.0
 */
class MVweb_SS_Catchup {

	const EVENT = 'mvweb_ss_catchup';

	const WATERMARK_OPTION = 'mvweb_ss_last_catchup';

	const WATERMARK_ID_OPTION = 'mvweb_ss_last_catchup_id';

	const LAST_RUN_OPTION = 'mvweb_ss_last_catchup_run';

	const BATCH = 200;

	const TIME_BUDGET = 20.0;

	/**
	 * Register cron and scheduling hooks.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function register(): void {
		add_action( 'init', array( __CLASS__, 'sync_schedule' ) );
		add_action( self::EVENT, array( __CLASS__, 'run' ) );
		add_action( 'update_option_' . MVweb_SS_Settings::OPTION, array( __CLASS__, 'sync_schedule' ) );
	}

	/**
	 * Schedule, reschedule or clear the recurring event to match the setting and
	 * the chosen interval.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function sync_schedule(): void {
		$enabled  = (bool) MVweb_SS_Settings::get( 'reindex_catchup', true );
		$interval = self::interval();
		$current  = wp_get_schedule( self::EVENT );

		if ( ! $enabled ) {
			if ( $current ) {
				self::unschedule();
			}
			return;
		}

		// Reschedule when the interval changed, otherwise leave the run alone.
		if ( $current && $current !== $interval ) {
			self::unschedule();
			$current = false;
		}

		if ( ! $current ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, $interval, self::EVENT );
		}
	}

	/**
	 * Remove the scheduled event (deactivation/uninstall).
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function unschedule(): void {
		$timestamp = wp_next_scheduled( self::EVENT );

		while ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::EVENT );
			$timestamp = wp_next_scheduled( self::EVENT );
		}
	}

	/**
	 * Sweep everything modified since the watermark and re-index it.
	 *
	 * The first run only records a baseline (the initial full index is the
	 * reindex button's job, not this net's). Objects that are no longer indexable
	 * — unpublished, excluded — are removed by the indexer, so a status change
	 * reflected in post_modified self-heals here too.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function run(): void {
		if ( ! MVweb_SS_Settings::get( 'reindex_catchup', true ) ) {
			return;
		}

		// Stamp the wall-clock time of every pass. Unlike the watermark (which
		// tracks how far the sweep has processed and can lag or jump), this is a
		// plain "the job fired at" marker — the admin uses it to confirm cron is
		// actually running the maintenance.
		update_option( self::LAST_RUN_OPTION, time(), false );

		$watermark = (string) get_option( self::WATERMARK_OPTION, '' );

		if ( '' === $watermark ) {
			self::set_cursor( current_time( 'mysql', true ), 0 );
			return;
		}

		$last_id = (int) get_option( self::WATERMARK_ID_OPTION, 0 );

		global $wpdb;

		$types = MVweb_SS_Indexer::get_indexed_post_types();
		$in    = implode( ',', array_fill( 0, count( $types ), '%s' ) );
		// Keyset cursor on (post_modified_gmt, ID): a strict timestamp-only cursor
		// would lose the tail when more than BATCH rows share the same second (a
		// bulk import stamping NOW() in one UPDATE — exactly this net's job), since
		// the next pass's `> ts` skips the rest of that second. The ID tie-break
		// resumes precisely where the batch stopped.
		$args = array_merge( $types, array( $watermark, $watermark, $last_id, self::BATCH ) );

		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_modified_gmt FROM {$wpdb->posts} WHERE post_type IN ($in) AND ( post_modified_gmt > %s OR ( post_modified_gmt = %s AND ID > %d ) ) ORDER BY post_modified_gmt ASC, ID ASC LIMIT %d", $args ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( empty( $rows ) ) {
			// Leave the cursor on the last processed (timestamp, ID). Advancing it to
			// now() would open a race: an external write stamped in the gap between the
			// SELECT above and the cursor update would fall below the new watermark and
			// be missed. Re-scanning the (empty) tail next tick is cheap.
			return;
		}

		$started  = microtime( true );
		$last_ts  = $watermark;
		$last_row = $last_id;

		foreach ( $rows as $row ) {
			MVweb_SS_Indexer::index_object( (int) $row->ID );
			$last_ts  = (string) $row->post_modified_gmt;
			$last_row = (int) $row->ID;

			if ( ( microtime( true ) - $started ) >= self::TIME_BUDGET ) {
				break;
			}
		}

		// The last processed (timestamp, ID) becomes the cursor; any tail beyond the
		// batch or the time budget is picked up on the next tick from exactly here.
		self::set_cursor( $last_ts, $last_row );

		MVweb_SS_Rest::flush_cache();
	}

	/**
	 * Persist the keyset cursor (timestamp + last object ID).
	 *
	 * @since 1.2.0
	 * @param string $timestamp GMT datetime.
	 * @param int    $object_id Last processed object ID at that timestamp.
	 * @return void
	 */
	private static function set_cursor( string $timestamp, int $object_id ): void {
		update_option( self::WATERMARK_OPTION, $timestamp, false );
		update_option( self::WATERMARK_ID_OPTION, $object_id, false );
	}

	/**
	 * Wall-clock time of the last maintenance pass, as a Unix timestamp.
	 *
	 * @since 1.4.6
	 * @return int Timestamp, or 0 if the sweep has never run.
	 */
	public static function last_run(): int {
		return (int) get_option( self::LAST_RUN_OPTION, 0 );
	}

	/**
	 * The recurrence name for the catch-up sweep, restricted to native schedules.
	 *
	 * @since 1.2.0
	 * @return string
	 */
	private static function interval(): string {
		$interval = (string) MVweb_SS_Settings::get( 'catchup_interval', 'daily' );

		return in_array( $interval, array( 'hourly', 'twicedaily', 'daily' ), true ) ? $interval : 'daily';
	}
}
