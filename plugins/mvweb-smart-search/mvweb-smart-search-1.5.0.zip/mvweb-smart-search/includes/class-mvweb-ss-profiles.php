<?php
/**
 * Catalog profiles: one-click presets that pre-fill the handful of settings
 * that actually depend on the store type, plus a small starter synonym set.
 *
 * @package mvweb_ss
 * @since   1.3.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registry of ready-made setup profiles.
 *
 * @since 1.3.0
 */
class MVweb_SS_Profiles {

	/**
	 * All available profiles keyed by id.
	 *
	 * Each entry: label, desc, settings (option overrides merged over current
	 * settings) and synonyms (starter groups appended to the owner's own list,
	 * one group per line — never overwriting what is already there).
	 *
	 * @since 1.3.0
	 * @return array<string,array{label:string,desc:string,settings:array<string,mixed>,synonyms:string}>
	 */
	public static function all(): array {
		$shop = array(
			'normalize_models' => true,
			'group_order'      => 'products',
			'boost_popularity' => 20,
			'ranking_doclen'   => true,
			'strictness'       => 'balanced',
		);

		return array(
			'electronics' => array(
				'label'    => __( 'Electronics & spare parts', 'mvweb-smart-search' ),
				'desc'     => __( 'Phones, gadgets, components. Model codes are split so a shopper who types part of a code still finds the item.', 'mvweb-smart-search' ),
				'settings' => $shop,
				'synonyms' => "зарядка, зарядное устройство, сзу, адаптер питания\nповербанк, внешний аккумулятор, пауэрбанк\nпереходник, адаптер, конвертер",
			),
			'auto' => array(
				'label'    => __( 'Auto parts & accessories', 'mvweb-smart-search' ),
				'desc'     => __( 'Car parts and accessories. Article and OEM codes are split, and common auto terms are treated as equivalent.', 'mvweb-smart-search' ),
				'settings' => $shop,
				'synonyms' => "колодки, тормозные колодки\nамортизатор, стойка, амортизаторная стойка\nсвеча, свеча зажигания\nмасляный фильтр, фильтр масляный\nщётки стеклоочистителя, дворники\nантифриз, охлаждающая жидкость, тосол",
			),
			'construction' => array(
				'label'    => __( 'Construction & adhesives', 'mvweb-smart-search' ),
				'desc'     => __( 'Building materials, sealants and glues. Volume and size codes are split, and common trade terms are treated as equivalent.', 'mvweb-smart-search' ),
				'settings' => $shop,
				'synonyms' => "герметик, силикон, силиконовый герметик\nмонтажная пена, пена монтажная\nгрунтовка, грунт, праймер\nшпаклёвка, шпатлёвка\nсаморез, шуруп\nдюбель, дюбель-гвоздь",
			),
			'apparel' => array(
				'label'    => __( 'Clothing & footwear', 'mvweb-smart-search' ),
				'desc'     => __( 'Fashion and shoes. Model-code splitting is off, since size codes are noise here, and common wardrobe terms are treated as equivalent.', 'mvweb-smart-search' ),
				'settings' => array_merge( $shop, array( 'normalize_models' => false ) ),
				'synonyms' => "кроссовки, кеды\nкуртка, ветровка\nтолстовка, худи, свитшот\nфутболка, майка\nджинсы, брюки",
			),
			'universal' => array(
				'label'    => __( 'General store', 'mvweb-smart-search' ),
				'desc'     => __( 'A mixed catalog. Balanced defaults that work well across most product types.', 'mvweb-smart-search' ),
				'settings' => $shop,
				'synonyms' => '',
			),
			'content' => array(
				'label'    => __( 'Content site / blog', 'mvweb-smart-search' ),
				'desc'     => __( 'Posts and pages first, no product-specific boosting. Best when search is mostly about articles rather than products.', 'mvweb-smart-search' ),
				'settings' => array_merge(
					$shop,
					array(
						'normalize_models' => false,
						'group_order'      => 'content',
						'boost_popularity' => 0,
					)
				),
				'synonyms' => '',
			),
		);
	}

	/**
	 * Fetch a single profile by id.
	 *
	 * @since 1.3.0
	 * @param string $id Profile id.
	 * @return array<string,mixed>|null
	 */
	public static function get( string $id ) {
		$all = self::all();

		return isset( $all[ $id ] ) ? $all[ $id ] : null;
	}

	/**
	 * Append starter synonym groups to the owner's existing list without
	 * overwriting or duplicating lines (case-insensitive, order preserved).
	 *
	 * @since 1.3.0
	 * @param string $existing Current synonyms textarea value.
	 * @param string $seed     Starter groups to add, one per line.
	 * @return string Combined synonyms value.
	 */
	public static function merge_synonyms( string $existing, string $seed ): string {
		$lines = array();
		$seen  = array();

		foreach ( array_merge(
			preg_split( '/[\r\n]+/', $existing ) ?: array(),
			preg_split( '/[\r\n]+/', $seed ) ?: array()
		) as $line ) {
			$line = trim( (string) $line );

			if ( '' === $line ) {
				continue;
			}

			$key = mb_strtolower( $line, 'UTF-8' );

			if ( isset( $seen[ $key ] ) ) {
				continue;
			}

			$seen[ $key ] = true;
			$lines[]      = $line;
		}

		return implode( "\n", $lines );
	}
}
