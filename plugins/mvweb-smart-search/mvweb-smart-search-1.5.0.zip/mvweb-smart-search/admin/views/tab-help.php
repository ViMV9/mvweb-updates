<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-smart-search' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Choose coverage', 'mvweb-smart-search' ); ?></strong>
			<p><?php esc_html_e( 'On the "Coverage" tab, select the content types to search: products, posts, pages, custom post types.', 'mvweb-smart-search' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Build the index', 'mvweb-smart-search' ); ?></strong>
			<p><?php esc_html_e( 'On the "Index" tab, click "Reindex everything". After that the index updates automatically as content changes.', 'mvweb-smart-search' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Place the search', 'mvweb-smart-search' ); ?></strong>
			<p><?php esc_html_e( 'The theme search form is replaced automatically. The [mvweb_ss] shortcode and the "MVweb Smart Search" block are also available in the editor.', 'mvweb-smart-search' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Features', 'mvweb-smart-search' ); ?></div>
	</div>
	<p><?php esc_html_e( 'All-in-one search across WooCommerce products, posts, pages, and custom post types with Russian morphology: different word forms match the same result. The live dropdown shows a thumbnail, price, and stock status. Typos are corrected automatically.', 'mvweb-smart-search' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Privacy and independence', 'mvweb-smart-search' ); ?></div>
	</div>
	<p><?php esc_html_e( 'Everything runs on your own server. The plugin builds its own index in your database and makes no external calls: no accounts, no API keys, no per-search credits, no data sent to a third party. That keeps search fast, free of usage limits, and compliant with local data-protection rules (152-FZ / GDPR) by design.', 'mvweb-smart-search' ); ?></p>
	<p><?php esc_html_e( 'It is all-in-one: morphological search, typo and keyboard-layout correction, synonyms, merchandising, WooCommerce depth and analytics are included, not sold as separate paid extensions.', 'mvweb-smart-search' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-smart-search' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Search doesn\'t find a new product — what to do?', 'mvweb-smart-search' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'The index updates when a product is saved. If content was imported outside the editor, run a full reindex on the "Index" tab or with the wp mvweb-ss reindex command.', 'mvweb-smart-search' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'What is the difference between "All words" and "Any word" modes?', 'mvweb-smart-search' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( '"All words" (AND) shows results containing every word of the query — more precise. "Any word" (OR) shows results containing at least one — broader coverage.', 'mvweb-smart-search' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Do drafts and hidden products appear in search?', 'mvweb-smart-search' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'No. Only published, password-free content is indexed; products hidden from the catalog do not appear in public results.', 'mvweb-smart-search' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can shoppers sort the search results?', 'mvweb-smart-search' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Yes. Place the [mvweb_ss_sort] shortcode on your search results template (above the results loop) to show a Relevance / Popularity / Rating / Price / Newest selector. Relevance is the default; the chosen order is carried in the page URL.', 'mvweb-smart-search' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can shoppers filter the search results (facets)?', 'mvweb-smart-search' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Yes. Add the "MVweb Search Filters" widget to a sidebar, or place the [mvweb_ss_facets] shortcode on your search results template. It shows the categories and brands the query matches (with a count each) and a price range; selecting them narrows the results. Turn it on and set how many values to list on the Behavior tab.', 'mvweb-smart-search' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Is the live-search endpoint protected from abuse?', 'mvweb-smart-search' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Yes — the endpoint rate-limits requests per IP address out of the box. A per-IP limit cannot stop a distributed flood from many addresses, which is a job for the infrastructure layer: on a busy public store, put a CDN or WAF (such as Cloudflare) in front of the site to absorb that kind of traffic.', 'mvweb-smart-search' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-smart-search' ); ?></div>
	</div>
	<p>
		<?php
		printf(
			/* translators: %s: MVweb plugin URL */
			esc_html__( 'Need help? Documentation and support are available at %s.', 'mvweb-smart-search' ),
			'<a href="https://mvweb.ru/plugins/mvweb-smart-search" target="_blank" rel="noopener">mvweb.ru</a>'
		);
		?>
	</p>
</div>
