<?php
/**
 * Search query engine: ranks index rows for a user query.
 *
 * @package mvweb_ss
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Turns a query string into a ranked list of matching objects.
 *
 * @since 1.0.0
 */
class MVweb_SS_Query {

	const MAX_LIMIT = 100;

	const DEFAULT_LIMIT = 20;

	const FUZZY_THRESHOLD = 3;

	const BM25_K1 = 1.2;

	/**
	 * Corrected query phrase from the last fuzzy fallback, or empty string.
	 *
	 * @var string
	 */
	private static $correction = '';

	/**
	 * Default per-source relevance weights.
	 *
	 * @var array<string,int>
	 */
	private static $weights = array(
		'title'         => 10,
		'sku'           => 10,
		'variation_sku' => 10,
		'gtin'          => 10,
		'attr'          => 7,
		'brand'         => 7,
		'content'       => 5,
		'excerpt'       => 5,
		'tax'           => 3,
		'cf'            => 3,
	);

	/**
	 * Default per-source relevance weights.
	 *
	 * @since 1.0.0
	 * @return array<string,int>
	 */
	public static function default_weights(): array {
		return self::$weights;
	}

	/**
	 * Corrected query phrase produced by the last fuzzy fallback.
	 *
	 * @since 1.0.0
	 * @return string Empty string when the last search needed no correction.
	 */
	public static function last_correction(): string {
		return self::$correction;
	}

	/**
	 * Search the index.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @param array  $args  { Optional.
	 *     @type int      $limit      Max results (capped at MAX_LIMIT).
	 *     @type string   $strictness 'loose', 'balanced' (default) or 'strict'.
	 *     @type string[] $post_types Restrict to these types.
	 * }
	 * @return array<int,array{object_id:int,object_type:string,score:float}>
	 */
	public static function search( string $query, array $args = array() ): array {
		self::$correction = '';

		// A leading "-word" excludes results containing that word (Boolean NOT).
		list( $clean_query, $neg_terms ) = self::split_negatives( $query );

		$terms = array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( $clean_query ) ) );

		if ( empty( $terms ) ) {
			return array();
		}

		$limit = isset( $args['limit'] ) ? (int) $args['limit'] : self::DEFAULT_LIMIT;
		$limit = max( 1, min( $limit, self::MAX_LIMIT ) );

		$strictness = isset( $args['strictness'] )
			? (string) $args['strictness']
			: (string) MVweb_SS_Settings::get( 'strictness', 'balanced' );

		$min_match = self::min_match( $strictness, MVweb_SS_Tokenizer::word_count( $clean_query ) );

		$types = isset( $args['post_types'] ) && is_array( $args['post_types'] ) && ! empty( $args['post_types'] )
			? array_values( $args['post_types'] )
			: MVweb_SS_Indexer::get_indexed_post_types();

		$term_ids = isset( $args['term_ids'] ) && is_array( $args['term_ids'] )
			? array_values( array_filter( array_map( 'intval', $args['term_ids'] ) ) )
			: array();

		$taxonomy = isset( $args['taxonomy'] ) ? (string) $args['taxonomy'] : '';

		// Self-learning click-boost keys on the raw query the shopper typed; the
		// same hash covers the layout-swap and fuzzy retries (clicks were logged
		// under that original wording). Empty unless the boost is enabled.
		$query_hash = MVweb_SS_Settings::get( 'click_boost', false ) ? MVweb_SS_Log::hash( $query ) : '';

		// Fold synonyms into the primary run so coverage-first ranking floats the
		// results that also match a synonym, while the strictness floor stays tied
		// to the number of original query words (a synonym does not raise the bar).
		$search_terms = self::expand_synonyms( $terms );

		$results = self::run( $search_terms, $types, $min_match, $limit, $term_ids, $taxonomy, $neg_terms, $query_hash );

		$threshold = (int) apply_filters( 'mvweb_ss_fuzzy_threshold', self::FUZZY_THRESHOLD );

		if ( MVweb_SS_Settings::get( 'fuzzy', true ) && count( $results ) < $threshold ) {
			// Wrong keyboard-layout recovery: a query typed in the other layout
			// ("ghbdtn" instead of "привет") is swapped and retried; adopted only
			// when it actually finds more than the original.
			$swapped = self::swap_layout( $clean_query );

			if ( '' !== $swapped ) {
				$swap_terms = array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( $swapped ) ) );

				if ( ! empty( $swap_terms ) ) {
					$swap_match   = self::min_match( $strictness, MVweb_SS_Tokenizer::word_count( $swapped ) );
					$swap_results = self::run( self::expand_synonyms( $swap_terms ), $types, $swap_match, $limit, $term_ids, $taxonomy, $neg_terms, $query_hash );

					if ( count( $swap_results ) > count( $results ) ) {
						$results          = $swap_results;
						self::$correction = trim( $swapped );
					}
				}
			}

			// Typo tolerance: still scarce after the layout swap, widen with fuzzy candidates.
			if ( count( $results ) < $threshold ) {
				$expanded = self::expand_fuzzy( $terms );

				if ( count( $expanded ) > count( $terms ) ) {
					$fuzzy = self::run( $expanded, $types, $min_match, $limit, $term_ids, $taxonomy, $neg_terms, $query_hash );

					if ( count( $fuzzy ) > count( $results ) ) {
						$results          = $fuzzy;
						self::$correction = self::derive_correction( $clean_query, $fuzzy );
					}
				}
			}
		}

		$pins = MVweb_SS_Settings::pins_for( $query );

		if ( ! empty( $pins ) ) {
			$results = self::apply_pins( $pins, $types, $results, $limit, $term_ids, $taxonomy );
		}

		/**
		 * Filter the final ranked results (used for language filtering and integrations).
		 *
		 * @since 1.0.0
		 * @param array  $results Ranked results.
		 * @param string $query   Raw user query.
		 * @param array  $types   Post types searched.
		 */
		return (array) apply_filters( 'mvweb_ss_results', $results, $query, $types );
	}

	/**
	 * Expand query terms with configured synonyms (phrase-aware).
	 *
	 * A rule fires when ALL of its pattern stems are present among the query
	 * terms (order-independent), then contributes the stems of the other
	 * entries in its group. Single-word entries are the degenerate case.
	 *
	 * @since 1.0.0
	 * @param string[] $terms Original query terms.
	 * @return string[] Original terms plus synonym equivalents.
	 */
	private static function expand_synonyms( array $terms ): array {
		$rules = MVweb_SS_Settings::synonym_map();

		if ( empty( $rules ) ) {
			return $terms;
		}

		$term_set = array_flip( $terms );
		$expanded = $terms;

		foreach ( $rules as $rule ) {
			foreach ( $rule['pattern'] as $stem ) {
				if ( ! isset( $term_set[ $stem ] ) ) {
					continue 2;
				}
			}

			$expanded = array_merge( $expanded, $rule['add'] );
		}

		return array_values( array_unique( $expanded ) );
	}

	/**
	 * Prepend admin-pinned, still-public results to the top.
	 *
	 * @since 1.0.0
	 * @param int[]    $pin_ids  Pinned object IDs (in order).
	 * @param string[] $types    Post types in scope for this search.
	 * @param array    $results  Ranked results.
	 * @param int      $limit    Max rows.
	 * @param int[]    $term_ids Active category term IDs, or empty.
	 * @param string   $taxonomy Taxonomy of the term IDs.
	 * @return array
	 */
	private static function apply_pins( array $pin_ids, array $types, array $results, int $limit, array $term_ids = array(), string $taxonomy = '' ): array {
		$exclude = MVweb_SS_Settings::excluded_ids();
		$scoped  = ! empty( $term_ids ) && '' !== $taxonomy;
		$pinned  = array();

		foreach ( $pin_ids as $id ) {
			if ( in_array( (int) $id, $exclude, true ) ) {
				continue;
			}

			if ( $scoped && ! has_term( $term_ids, $taxonomy, (int) $id ) ) {
				continue;
			}

			$post = get_post( $id );

			if ( $post instanceof WP_Post
				&& 'publish' === $post->post_status
				&& '' === (string) $post->post_password
				&& in_array( $post->post_type, $types, true ) ) {
				$pinned[] = array(
					'object_id'   => (int) $id,
					'object_type' => $post->post_type,
					'score'       => (float) PHP_INT_MAX,
				);
			}
		}

		if ( empty( $pinned ) ) {
			return $results;
		}

		$ids  = array_column( $pinned, 'object_id' );
		$rest = array_filter(
			$results,
			static function ( $row ) use ( $ids ) {
				return ! in_array( $row['object_id'], $ids, true );
			}
		);

		return array_slice( array_merge( $pinned, array_values( $rest ) ), 0, $limit );
	}

	/**
	 * Add fuzzy candidate terms for each query term long enough to qualify.
	 *
	 * @since 1.0.0
	 * @param string[] $terms Original query terms.
	 * @return string[] Original terms plus fuzzy candidates.
	 */
	private static function expand_fuzzy( array $terms ): array {
		$expanded = $terms;

		foreach ( $terms as $term ) {
			if ( mb_strlen( $term, 'UTF-8' ) < MVweb_SS_Fuzzy::MIN_LENGTH ) {
				continue;
			}

			$expanded = array_merge( $expanded, MVweb_SS_Fuzzy::candidates( $term ) );
		}

		return array_values( array_unique( $expanded ) );
	}

	/**
	 * Split a raw query into its positive text and negated stems.
	 *
	 * A whitespace-delimited word starting with "-" ("iphone -чехол") is a
	 * Boolean NOT: the word is removed from the searchable text and its stems
	 * are returned so the ranking query can exclude any object carrying them.
	 * A "-" inside a word ("телефон-раскладушка") is a compound, not a negation.
	 *
	 * @since 1.1.0
	 * @param string $query Raw user query.
	 * @return array{0:string,1:string[]} Cleaned query, then negated stems.
	 */
	public static function split_negatives( string $query ): array {
		$neg_words = array();

		$clean = (string) preg_replace_callback(
			'/(?:^|\s)-(\S+)/u',
			static function ( $m ) use ( &$neg_words ) {
				$neg_words[] = $m[1];
				return ' ';
			},
			$query
		);

		$neg_terms = array();

		foreach ( $neg_words as $word ) {
			foreach ( array_keys( MVweb_SS_Tokenizer::tokenize( $word ) ) as $stem ) {
				$neg_terms[] = (string) $stem;
			}
		}

		return array( trim( $clean ), array_values( array_unique( $neg_terms ) ) );
	}

	/**
	 * Re-map a query typed in the wrong keyboard layout to the other one.
	 *
	 * Swaps characters between the Russian ЙЦУКЕН and the English QWERTY layouts
	 * by physical key, so "ghbdtn" becomes "привет" (and the reverse). Returns an
	 * empty string when nothing changed, letting the caller skip a pointless
	 * re-search. The slash and backtick keys are left out (their letters ./ё
	 * collide or are stemmer-normalized), so the map stays unambiguous.
	 *
	 * @since 1.1.0
	 * @param string $query Raw user query.
	 * @return string Swapped query, or '' when unchanged.
	 */
	private static function swap_layout( string $query ): string {
		$lower = mb_strtolower( trim( $query ), 'UTF-8' );

		if ( '' === $lower ) {
			return '';
		}

		$swapped = strtr( $lower, self::layout_map() );

		return $swapped === $lower ? '' : $swapped;
	}

	/**
	 * Bidirectional QWERTY↔ЙЦУКЕН character map keyed by physical key.
	 *
	 * @since 1.1.0
	 * @return array<string,string>
	 */
	private static function layout_map(): array {
		static $map = null;

		if ( null !== $map ) {
			return $map;
		}

		$en = str_split( 'qwertyuiop[]asdfghjkl;\'zxcvbnm,.' );
		$ru = mb_str_split( 'йцукенгшщзхъфывапролджэячсмитьбю', 1, 'UTF-8' );

		$map = array();

		foreach ( $en as $i => $ch ) {
			$map[ $ch ]       = $ru[ $i ];
			$map[ $ru[ $i ] ] = $ch;
		}

		return $map;
	}

	/**
	 * Build a human-readable "did you mean" phrase from the top fuzzy match.
	 *
	 * Uses real words from the best result's title (not stemmed index terms),
	 * replacing each raw query word with the closest title word within edit
	 * distance 2. Returns an empty string when nothing changed.
	 *
	 * @since 1.0.0
	 * @param string $query   Raw user query.
	 * @param array  $results Fuzzy result set (best first).
	 * @return string
	 */
	private static function derive_correction( string $query, array $results ): string {
		if ( empty( $results ) ) {
			return '';
		}

		$raw_words = preg_split( '/\s+/u', trim( $query ), -1, PREG_SPLIT_NO_EMPTY );

		if ( empty( $raw_words ) ) {
			return '';
		}

		$title       = wp_strip_all_tags( (string) get_the_title( (int) $results[0]['object_id'] ) );
		$title_words = preg_split( '/\s+/u', $title, -1, PREG_SPLIT_NO_EMPTY );

		if ( empty( $title_words ) ) {
			return '';
		}

		$out = array();

		foreach ( (array) $raw_words as $word ) {
			$word_lc = mb_strtolower( (string) $word, 'UTF-8' );
			$len     = mb_strlen( $word_lc, 'UTF-8' );
			$best    = (string) $word;
			$best_d  = PHP_INT_MAX;

			foreach ( (array) $title_words as $candidate ) {
				$candidate = (string) $candidate;

				if ( abs( mb_strlen( $candidate, 'UTF-8' ) - $len ) > 2 ) {
					continue;
				}

				$distance = MVweb_SS_Fuzzy::distance( $word_lc, mb_strtolower( $candidate, 'UTF-8' ) );

				if ( $distance < $best_d ) {
					$best_d = $distance;
					$best   = $candidate;
				}
			}

			$out[] = ( $best_d > 0 && $best_d <= 2 ) ? $best : (string) $word;
		}

		$corrected = implode( ' ', $out );
		$original  = (string) preg_replace( '/\s+/u', ' ', trim( $query ) );

		return mb_strtolower( $corrected, 'UTF-8' ) === mb_strtolower( $original, 'UTF-8' ) ? '' : $corrected;
	}

	/**
	 * Run the ranking query for a set of terms.
	 *
	 * @since 1.0.0
	 * @param string[] $terms     Non-empty term list.
	 * @param string[] $types     Post types to search.
	 * @param int      $min_match Minimum number of distinct query terms an object must match (1 = OR, N = AND).
	 * @param int      $limit     Max rows.
	 * @param int[]    $term_ids  Restrict to objects in these taxonomy term IDs.
	 * @param string   $taxonomy  Taxonomy the term IDs belong to (required with $term_ids).
	 * @param string[] $exclude_terms Stems whose presence disqualifies an object (Boolean NOT).
	 * @param string   $query_hash    Raw-query hash for the self-learning click-boost ('' = off).
	 * @return array<int,array{object_id:int,object_type:string,score:float}>
	 */
	private static function run( array $terms, array $types, int $min_match, int $limit, array $term_ids = array(), string $taxonomy = '', array $exclude_terms = array(), string $query_hash = '' ): array {
		global $wpdb;

		if ( empty( $terms ) || empty( $types ) ) {
			return array();
		}

		$table = MVweb_SS_Schema::table_name();

		$in_terms = implode( ',', array_fill( 0, count( $terms ), '%s' ) );
		$in_types = implode( ',', array_fill( 0, count( $types ), '%s' ) );

		$tax_sql   = '';
		$tax_valid = ! empty( $term_ids ) && '' !== $taxonomy;

		if ( $tax_valid ) {
			$in_tids = implode( ',', array_fill( 0, count( $term_ids ), '%d' ) );
			$tax_sql = "AND i.object_id IN (
				SELECT tr.object_id FROM {$wpdb->term_relationships} tr
				INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_taxonomy_id = tr.term_taxonomy_id
				WHERE tt.taxonomy = %s AND tt.term_id IN ($in_tids)
			)";
		}

		$stock        = self::stock_mode();
		$stock_active = ( 'show' !== $stock ) && class_exists( 'WooCommerce' );

		$join         = '';
		$stock_select = '';
		$order_prefix = '';
		$having_parts = array();

		if ( $min_match > 1 ) {
			$having_parts[] = 'matched >= %d';
		}

		if ( $stock_active ) {
			$join         = "LEFT JOIN {$wpdb->postmeta} sm ON sm.post_id = i.object_id AND sm.meta_key = '_stock_status'";
			$stock_select = ', MAX( CASE WHEN sm.meta_value = \'outofstock\' THEN 1 ELSE 0 END ) AS out_of_stock';

			if ( 'hide' === $stock ) {
				$having_parts[] = 'out_of_stock = 0';
			} else {
				$order_prefix = 'out_of_stock ASC, ';
			}
		}

		$having = empty( $having_parts ) ? '' : 'HAVING ' . implode( ' AND ', $having_parts );

		$exclude  = MVweb_SS_Settings::excluded_ids();
		$excl_sql = '';

		if ( ! empty( $exclude ) ) {
			$in_excl  = implode( ',', array_fill( 0, count( $exclude ), '%d' ) );
			$excl_sql = "AND i.object_id NOT IN ($in_excl)";
		}

		$neg_sql = '';

		if ( ! empty( $exclude_terms ) ) {
			$in_neg  = implode( ',', array_fill( 0, count( $exclude_terms ), '%s' ) );
			$neg_sql = "AND i.object_id NOT IN ( SELECT object_id FROM `$table` WHERE term IN ($in_neg) )";
		}

		// Self-learning click-boost: multiply the score by a log-damped, capped
		// factor of how often this result was clicked for this exact query. The
		// factor is 1.0 with no clicks, so it never crosses the coverage tier and
		// never reorders cold-start catalogs.
		$boost_join   = '';
		$boost_select = '';
		$boost_order  = 'score DESC';

		if ( '' !== $query_hash ) {
			$clicks_table = MVweb_SS_Schema::clicks_table_name();
			$strength     = (int) MVweb_SS_Settings::get( 'click_boost_strength', 30 );
			$alpha        = number_format( max( 0, min( 100, $strength ) ) / 100, 3, '.', '' );
			$cap          = '2.0';

			$boost_join   = "LEFT JOIN `$clicks_table` cb ON cb.object_id = i.object_id AND cb.query_hash = %s";
			$boost_select = ', MAX( COALESCE( cb.clicks, 0 ) ) AS click_hits';
			$boost_order  = "( score * ( 1 + LEAST( $alpha * LN( 1 + MAX( COALESCE( cb.clicks, 0 ) ) ), $cap ) ) ) DESC";
		}

		$sql = 'SELECT i.object_id, i.object_type, SUM( ' . self::weight_case() . " ) AS score, COUNT( DISTINCT i.term ) AS matched{$stock_select}{$boost_select}
			FROM `$table` i
			$join
			$boost_join
			WHERE i.term IN ($in_terms)
				AND i.object_id IN (
					SELECT ID FROM {$wpdb->posts}
					WHERE post_status = 'publish' AND post_password = '' AND post_type IN ($in_types)
				)
				$excl_sql
				$neg_sql
				$tax_sql
			GROUP BY i.object_id, i.object_type
			$having
			ORDER BY {$order_prefix}matched DESC, {$boost_order}, i.object_id DESC
			LIMIT %d";

		$values = array();

		if ( '' !== $query_hash ) {
			$values[] = $query_hash;
		}

		$values = array_merge( $values, $terms, $types );

		if ( ! empty( $exclude ) ) {
			$values = array_merge( $values, $exclude );
		}

		if ( ! empty( $exclude_terms ) ) {
			$values = array_merge( $values, $exclude_terms );
		}

		if ( $tax_valid ) {
			$values[] = $taxonomy;
			$values   = array_merge( $values, $term_ids );
		}

		if ( $min_match > 1 ) {
			$values[] = min( $min_match, count( $terms ) );
		}

		$values[] = $limit;

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( ! is_array( $rows ) ) {
			return array();
		}

		return array_map(
			static function ( $row ) {
				return array(
					'object_id'   => (int) $row->object_id,
					'object_type' => (string) $row->object_type,
					'score'       => (float) $row->score,
				);
			},
			$rows
		);
	}

	/**
	 * Convenience: return only the ordered object IDs.
	 *
	 * @since 1.0.0
	 * @param string $query Raw user query.
	 * @param array  $args  See search().
	 * @return int[]
	 */
	public static function search_ids( string $query, array $args = array() ): array {
		return array_map(
			static function ( $result ) {
				return $result['object_id'];
			},
			self::search( $query, $args )
		);
	}

	/**
	 * Count matching objects per taxonomy term for the dropdown category groups.
	 *
	 * Instead of matching term names, this counts how many objects that actually
	 * satisfy the query (same strictness floor, synonyms and Boolean NOT as the
	 * result list) fall into each term. A term the query does not reach never
	 * appears, and its number is the matching count — not the term's total size.
	 *
	 * @since 1.1.2
	 * @param string   $query      Raw user query.
	 * @param string[] $taxonomies Taxonomies to aggregate over.
	 * @param int      $limit      Max terms, ordered by matching count.
	 * @return array<int,array{term_id:int,taxonomy:string,count:int}>
	 */
	public static function term_match_counts( string $query, array $taxonomies, int $limit ): array {
		global $wpdb;

		$taxonomies = array_values( array_unique( array_filter( array_map( 'strval', $taxonomies ) ) ) );

		if ( empty( $taxonomies ) || $limit < 1 ) {
			return array();
		}

		list( $clean_query, $neg_terms ) = self::split_negatives( $query );

		$terms = array_map( 'strval', array_keys( MVweb_SS_Tokenizer::tokenize( $clean_query ) ) );

		if ( empty( $terms ) ) {
			return array();
		}

		$strictness   = (string) MVweb_SS_Settings::get( 'strictness', 'balanced' );
		$min_match    = self::min_match( $strictness, MVweb_SS_Tokenizer::word_count( $clean_query ) );
		$search_terms = self::expand_synonyms( $terms );
		$need         = (int) min( $min_match, count( $search_terms ) );

		$table   = MVweb_SS_Schema::table_name();
		$exclude = MVweb_SS_Settings::excluded_ids();

		$in_terms = implode( ',', array_fill( 0, count( $search_terms ), '%s' ) );
		$in_taxes = implode( ',', array_fill( 0, count( $taxonomies ), '%s' ) );

		$excl_sql = '';
		if ( ! empty( $exclude ) ) {
			$in_excl  = implode( ',', array_fill( 0, count( $exclude ), '%d' ) );
			$excl_sql = "AND i.object_id NOT IN ($in_excl)";
		}

		$neg_sql = '';
		if ( ! empty( $neg_terms ) ) {
			$in_neg  = implode( ',', array_fill( 0, count( $neg_terms ), '%s' ) );
			$neg_sql = "AND i.object_id NOT IN ( SELECT object_id FROM `$table` WHERE term IN ($in_neg) )";
		}

		$having = $need > 1 ? 'HAVING COUNT( DISTINCT i.term ) >= %d' : '';

		$sql = "SELECT tt.term_id AS term_id, tt.taxonomy AS taxonomy, COUNT( DISTINCT m.object_id ) AS cnt
			FROM {$wpdb->term_taxonomy} tt
			INNER JOIN {$wpdb->term_relationships} tr ON tr.term_taxonomy_id = tt.term_taxonomy_id
			INNER JOIN (
				SELECT i.object_id
				FROM `$table` i
				WHERE i.term IN ($in_terms)
					AND i.object_id IN (
						SELECT ID FROM {$wpdb->posts}
						WHERE post_status = 'publish' AND post_password = ''
					)
					$excl_sql
					$neg_sql
				GROUP BY i.object_id
				$having
			) m ON m.object_id = tr.object_id
			WHERE tt.taxonomy IN ($in_taxes)
			GROUP BY tt.term_id, tt.taxonomy
			ORDER BY cnt DESC, tt.term_id ASC
			LIMIT %d";

		$values = $search_terms;

		if ( ! empty( $exclude ) ) {
			$values = array_merge( $values, $exclude );
		}

		if ( ! empty( $neg_terms ) ) {
			$values = array_merge( $values, $neg_terms );
		}

		if ( $need > 1 ) {
			$values[] = $need;
		}

		$values   = array_merge( $values, $taxonomies );
		$values[] = $limit;

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $values ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders

		if ( ! is_array( $rows ) ) {
			return array();
		}

		return array_map(
			static function ( $row ) {
				return array(
					'term_id'  => (int) $row->term_id,
					'taxonomy' => (string) $row->taxonomy,
					'count'    => (int) $row->cnt,
				);
			},
			$rows
		);
	}

	/**
	 * A term ID plus all of its descendant term IDs in a taxonomy.
	 *
	 * @since 1.0.0
	 * @param int    $term_id  Selected term ID.
	 * @param string $taxonomy Taxonomy slug.
	 * @return int[] Empty when the term or taxonomy is invalid.
	 */
	public static function term_and_children( int $term_id, string $taxonomy ): array {
		if ( $term_id <= 0 || '' === $taxonomy || ! taxonomy_exists( $taxonomy ) ) {
			return array();
		}

		if ( ! get_term( $term_id, $taxonomy ) instanceof WP_Term ) {
			return array();
		}

		$ids      = array( $term_id );
		$children = get_term_children( $term_id, $taxonomy );

		if ( is_array( $children ) ) {
			foreach ( $children as $child ) {
				$ids[] = (int) $child;
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Minimum number of query terms an object must match for the chosen strictness.
	 *
	 * Strict = all terms (AND); loose = any single term (OR); balanced = most
	 * of the terms (a coverage floor), which drops results that only share a
	 * word or two with a multi-word query.
	 *
	 * @since 1.0.4
	 * @param string $strictness 'loose', 'balanced' or 'strict'.
	 * @param int    $count      Number of query terms.
	 * @return int Floor between 1 and $count.
	 */
	private static function min_match( string $strictness, int $count ): int {
		if ( $count <= 1 ) {
			return 1;
		}

		switch ( $strictness ) {
			case 'strict':
				return $count;
			case 'loose':
				return 1;
			default:
				return (int) min( $count, max( 1, (int) ceil( $count * 0.7 ) ) );
		}
	}

	/**
	 * Resolve the out-of-stock handling mode.
	 *
	 * @since 1.0.0
	 * @return string 'show', 'hide' or 'demote'.
	 */
	private static function stock_mode(): string {
		$mode = (string) MVweb_SS_Settings::get( 'stock', 'show' );

		return in_array( $mode, array( 'hide', 'demote' ), true ) ? $mode : 'show';
	}

	/**
	 * BM25-style term-frequency saturation as an SQL sub-expression.
	 *
	 * Replaces the raw term frequency (`i.count`) with tf·(k1+1)/(tf+k1) so a
	 * word repeated many times in one long field (keyword stuffing) can no
	 * longer outweigh a clean title match. tf = 1 yields 1.0, matching the old
	 * linear score for the common single-occurrence case. Float literals are
	 * formatted with an explicit dot (locale-independent).
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private static function tf_saturation(): string {
		$num = number_format( self::BM25_K1 + 1, 1, '.', '' );
		$den = number_format( self::BM25_K1, 1, '.', '' );

		return '( i.count * ' . $num . ' / ( i.count + ' . $den . ' ) )';
	}

	/**
	 * Build the SQL CASE expression that applies per-source weights.
	 *
	 * Source keys and weights are trusted plugin constants, sanitized before
	 * inlining (no user input reaches this expression). Term frequency is
	 * saturated (see tf_saturation()) so repetition has diminishing returns.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function weight_case(): string {
		$weights = wp_parse_args( (array) MVweb_SS_Settings::get( 'weights', array() ), self::$weights );
		$weights = apply_filters( 'mvweb_ss_field_weights', $weights );

		if ( ! is_array( $weights ) || empty( $weights ) ) {
			$weights = self::$weights;
		}

		$tf    = self::tf_saturation();
		$parts = array();

		foreach ( $weights as $source => $weight ) {
			$source  = preg_replace( '/[^a-z_]/', '', (string) $source );
			$parts[] = "WHEN '" . $source . "' THEN " . (int) $weight . ' * ' . $tf;
		}

		return 'CASE i.source ' . implode( ' ', $parts ) . ' ELSE ' . $tf . ' END';
	}
}
