/**
 * Admin JavaScript for MVweb Reviews.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

(function () {
	'use strict';

	var data = window.mvwebRvAdmin || {};
	var formlessTabs = ['import', 'help'];

	document.addEventListener('DOMContentLoaded', function () {
		initTabs();
		initGallery();
		initSchemaTypePreset();
	});

	/**
	 * Initialize tab navigation on the settings page.
	 */
	function initTabs() {
		var links = document.querySelectorAll('.mvweb-nav__link');
		var panels = document.querySelectorAll('.mvweb-tab-content');
		var submit = document.querySelector('.mvweb-submit');

		if (!links.length || !panels.length) {
			return;
		}

		function syncSubmit(target) {
			if (submit) {
				submit.style.display = formlessTabs.indexOf(target) === -1 ? '' : 'none';
			}
		}

		links.forEach(function (link) {
			link.addEventListener('click', function (event) {
				event.preventDefault();

				var target = link.getAttribute('data-tab') || link.getAttribute('href').replace('#', '');
				var panel = document.getElementById(target);

				if (!panel) {
					return;
				}

				links.forEach(function (l) { l.classList.remove('mvweb-nav__link--active'); });
				panels.forEach(function (p) { p.classList.remove('active'); });

				link.classList.add('mvweb-nav__link--active');
				panel.classList.add('active');
				syncSubmit(target);

				if (window.history && window.history.replaceState) {
					var url = new URL(window.location.href);

					url.searchParams.set('tab', target);
					window.history.replaceState({}, '', url.toString());
				}
			});
		});

		var active = document.querySelector('.mvweb-nav__link--active');

		syncSubmit(active ? active.getAttribute('data-tab') : 'general');
	}

	/**
	 * Media library picker for review work photos.
	 */
	function initGallery() {
		var box = document.querySelector('[data-gallery]');

		if (!box || !window.wp || !window.wp.media) {
			return;
		}

		var field = box.querySelector('input[type="hidden"]');
		var items = box.querySelector('[data-gallery-items]');
		var addButton = box.querySelector('[data-gallery-add]');
		var frame = null;

		function syncField() {
			var ids = Array.prototype.map.call(items.children, function (item) {
				return item.getAttribute('data-id');
			});

			field.value = ids.join(',');
		}

		function bindRemove(item) {
			var button = item.querySelector('.mvweb-rv-gallery__remove');

			if (!button) {
				return;
			}

			button.addEventListener('click', function () {
				item.remove();
				syncField();
			});
		}

		Array.prototype.forEach.call(items.children, bindRemove);

		if (!addButton) {
			return;
		}

		addButton.addEventListener('click', function (event) {
			event.preventDefault();

			if (!frame) {
				frame = window.wp.media({
					title: data.mediaTitle || 'Select images',
					button: { text: data.mediaButton || 'Add' },
					library: { type: 'image' },
					multiple: true
				});

				frame.on('select', function () {
					frame.state().get('selection').forEach(function (attachment) {
						var model = attachment.toJSON();

						if (items.querySelector('[data-id="' + model.id + '"]')) {
							return;
						}

						var item = document.createElement('span');

						item.className = 'mvweb-rv-gallery__item';
						item.setAttribute('data-id', model.id);

						var image = document.createElement('img');

						image.src = model.sizes && model.sizes.thumbnail ? model.sizes.thumbnail.url : model.url;
						image.alt = '';
						image.width = 80;
						image.height = 80;

						var remove = document.createElement('button');

						remove.type = 'button';
						remove.className = 'mvweb-rv-gallery__remove';
						remove.setAttribute('aria-label', data.removeLabel || 'Remove');
						remove.textContent = '×';

						item.appendChild(image);
						item.appendChild(remove);
						items.appendChild(item);

						bindRemove(item);
					});

					syncField();
				});
			}

			frame.open();
		});
	}

	/**
	 * Sync the schema type preset dropdown with its hidden text field.
	 */
	function initSchemaTypePreset() {
		var select = document.querySelector('[data-schema-type-preset]');
		var input = document.querySelector('[data-schema-type-custom]');

		if (!select || !input) {
			return;
		}

		select.addEventListener('change', function () {
			if ('' === select.value) {
				input.hidden = false;
				input.value = '';
				input.focus();
				return;
			}

			input.hidden = true;
			input.value = select.value;
		});
	}
})();
