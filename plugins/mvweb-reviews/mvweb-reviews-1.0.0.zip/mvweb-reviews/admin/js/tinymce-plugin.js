/**
 * Classic editor toolbar button that inserts the reviews shortcode.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

(function () {
	'use strict';

	if (!window.tinymce) {
		return;
	}

	function listboxValues(strings, fallback) {
		var source = strings || fallback;

		return Object.keys(fallback).map(function (value) {
			return { text: source[value] || fallback[value], value: value };
		});
	}

	window.tinymce.PluginManager.add('mvweb_rv', function (editor) {
		var data = window.mvwebRvAdmin || {};
		var strings = data.shortcodeBuilder || {};
		var fallbackLayouts = { grid: 'Cards grid', carousel: 'Carousel', list: 'Single column list', accordion: 'Compact accordion' };
		var fallbackOrders = { date: 'Newest first', rating: 'Highest rating first', rand: 'Random', menu_order: 'Manual order' };

		editor.addButton('mvweb_rv_button', {
			title: strings.title || 'MVweb Reviews',
			icon: 'dashicon dashicons-format-status',
			onclick: function () {
				editor.windowManager.open({
					title: strings.title || 'MVweb Reviews',
					body: [
						{
							type: 'listbox',
							name: 'layout',
							label: strings.layoutLabel || 'Layout',
							values: listboxValues(strings.layouts, fallbackLayouts)
						},
						{ type: 'textbox', name: 'group', label: strings.groupLabel || 'Group slug' },
						{ type: 'textbox', name: 'limit', label: strings.limitLabel || 'Limit' },
						{
							type: 'listbox',
							name: 'order',
							label: strings.orderLabel || 'Order',
							values: listboxValues(strings.orders, fallbackOrders)
						}
					],
					onsubmit: function (event) {
						var parts = ['mvweb_reviews'];

						if (event.data.layout) {
							parts.push('layout="' + event.data.layout + '"');
						}

						if (event.data.group) {
							parts.push('group="' + event.data.group.replace(/"/g, '') + '"');
						}

						if (event.data.limit) {
							parts.push('limit="' + parseInt(event.data.limit, 10) + '"');
						}

						if (event.data.order) {
							parts.push('order="' + event.data.order + '"');
						}

						editor.insertContent('[' + parts.join(' ') + ']');
					}
				});
			}
		});
	});
})();
