<?php
/**
 * License status and fallback key field.
 *
 * Included both on the Help tab and on the license-blocked screen.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rv_license_state    = MVweb_License::get_state();
$mvweb_rv_license_verdict  = MVweb_License::verdict_code();
$mvweb_rv_license_key_set  = '' !== MVweb_License::get_key();
$mvweb_rv_license_from_cfg = MVweb_License::has_config_key();

if ( ! $mvweb_rv_license_key_set ) {
	$mvweb_rv_license_badge = 'mvweb-badge--plain';
	$mvweb_rv_license_label = __( 'No key set', 'mvweb-reviews' );
} elseif ( in_array( $mvweb_rv_license_verdict, MVweb_License::BLOCKING_CODES, true ) ) {
	$mvweb_rv_license_badge = 'mvweb-badge--error';
	$mvweb_rv_license_label = sprintf(
		/* translators: %s: verdict code returned by the update server (revoked, domain_mismatch). */
		__( 'Rejected: %s', 'mvweb-reviews' ),
		$mvweb_rv_license_verdict
	);
} elseif ( '' === $mvweb_rv_license_state['checked_at'] ) {
	$mvweb_rv_license_badge = 'mvweb-badge--plain';
	$mvweb_rv_license_label = __( 'Not confirmed yet', 'mvweb-reviews' );
} elseif ( MVweb_License::is_stale() ) {
	$mvweb_rv_license_badge = 'mvweb-badge--warning';
	$mvweb_rv_license_label = sprintf(
		/* translators: %s: date of the last confirmed check. */
		__( 'Not confirmed since %s', 'mvweb-reviews' ),
		date_i18n( (string) get_option( 'date_format' ), (int) strtotime( $mvweb_rv_license_state['last_ok_at'] . ' UTC' ) )
	);
} elseif ( in_array( $mvweb_rv_license_verdict, array( 'expired', 'missing' ), true ) ) {
	$mvweb_rv_license_badge = 'mvweb-badge--warning';
	$mvweb_rv_license_label = __( 'Updates unavailable', 'mvweb-reviews' );
} else {
	$mvweb_rv_license_badge = 'mvweb-badge--success';
	$mvweb_rv_license_label = __( 'Active', 'mvweb-reviews' );
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'License', 'mvweb-reviews' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label"><?php esc_html_e( 'Status', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<span class="mvweb-badge <?php echo esc_attr( $mvweb_rv_license_badge ); ?>"><?php echo esc_html( $mvweb_rv_license_label ); ?></span>
			<?php if ( '' !== $mvweb_rv_license_state['checked_at'] ) : ?>
				<p class="mvweb-form-row__desc">
					<?php
					printf(
						/* translators: %s: last verified check date and time (site GMT). */
						esc_html__( 'Last checked %s.', 'mvweb-reviews' ),
						esc_html( $mvweb_rv_license_state['checked_at'] )
					);
					?>
				</p>
			<?php endif; ?>
		</div>
	</div>

	<?php if ( $mvweb_rv_license_from_cfg ) : ?>
		<p class="mvweb-form-row__desc"><?php esc_html_e( 'Set through the MVWEB_LICENSE_KEY constant in wp-config.php.', 'mvweb-reviews' ); ?></p>
	<?php else : ?>
		<form method="post" action="">
			<?php wp_nonce_field( 'mvweb_rv_license', 'mvweb_rv_license_nonce' ); ?>

			<div class="mvweb-form-row">
				<label for="mvweb_rv_license_key" class="mvweb-form-row__label"><?php esc_html_e( 'License key', 'mvweb-reviews' ); ?></label>
				<div class="mvweb-form-row__field">
					<input type="text" id="mvweb_rv_license_key" name="mvweb_rv_license_key" class="mvweb-input"
						value="<?php echo esc_attr( (string) get_option( MVweb_License::KEY_OPTION, '' ) ); ?>" autocomplete="off">
					<p class="mvweb-form-row__desc"><?php esc_html_e( 'Fallback only — on client sites the key belongs in wp-config.php, not here.', 'mvweb-reviews' ); ?></p>
				</div>
			</div>

			<button type="submit" name="mvweb_rv_license_save" class="mvweb-btn"><?php esc_html_e( 'Save key', 'mvweb-reviews' ); ?></button>
		</form>
	<?php endif; ?>
</div>
