<?php
/**
 * Help tab.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-reviews' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><?php esc_html_e( 'Add reviews under Reviews → Add review, or import them on the Import tab.', 'mvweb-reviews' ); ?></li>
		<li><?php esc_html_e( 'Group them if the site needs separate sets, for example by service.', 'mvweb-reviews' ); ?></li>
		<li><?php esc_html_e( 'Place [mvweb_reviews] on a page and add [mvweb_review_form] where visitors should be able to write.', 'mvweb-reviews' ); ?></li>
		<li><?php esc_html_e( 'Approve incoming reviews: they appear as Pending and are published with one click.', 'mvweb-reviews' ); ?></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Shortcode attributes', 'mvweb-reviews' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Every attribute overrides the matching setting for that block only.', 'mvweb-reviews' ); ?></p>

	<div class="mvweb-codeblock">
		<code>[mvweb_reviews layout="grid" group="kaminy" limit="6" order="date" rating_min="4"]</code>
	</div>

	<div class="mvweb-table-wrap">
		<table class="mvweb-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Attribute', 'mvweb-reviews' ); ?></th>
					<th><?php esc_html_e( 'Values', 'mvweb-reviews' ); ?></th>
					<th><?php esc_html_e( 'Meaning', 'mvweb-reviews' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><code>layout</code></td>
					<td>grid, carousel, list, accordion</td>
					<td><?php esc_html_e( 'How reviews are arranged.', 'mvweb-reviews' ); ?></td>
				</tr>
				<tr>
					<td><code>group</code></td>
					<td><?php esc_html_e( 'group slugs, comma separated', 'mvweb-reviews' ); ?></td>
					<td><?php esc_html_e( 'Show only reviews from these groups.', 'mvweb-reviews' ); ?></td>
				</tr>
				<tr>
					<td><code>limit</code></td>
					<td>1–100</td>
					<td><?php esc_html_e( 'Reviews shown before “Show more”.', 'mvweb-reviews' ); ?></td>
				</tr>
				<tr>
					<td><code>order</code></td>
					<td>date, rating, rand, menu_order</td>
					<td><?php esc_html_e( 'Sort order; pinned reviews stay first.', 'mvweb-reviews' ); ?></td>
				</tr>
				<tr>
					<td><code>rating_min</code></td>
					<td>0–10</td>
					<td><?php esc_html_e( 'Hide reviews below this rating.', 'mvweb-reviews' ); ?></td>
				</tr>
				<tr>
					<td><code>card_min</code></td>
					<td>180–640</td>
					<td><?php esc_html_e( 'Minimum card width in pixels; columns follow from it.', 'mvweb-reviews' ); ?></td>
				</tr>
				<tr>
					<td><code>clamp_lines</code></td>
					<td>2–40</td>
					<td><?php esc_html_e( 'Text lines before the review is collapsed.', 'mvweb-reviews' ); ?></td>
				</tr>
				<tr>
					<td><code>show_rating</code>, <code>show_photo</code>, <code>show_date</code>, <code>show_city</code>, <code>show_order</code>, <code>show_summary</code></td>
					<td>0, 1</td>
					<td><?php esc_html_e( 'Toggle single card elements.', 'mvweb-reviews' ); ?></td>
				</tr>
				<tr>
					<td><code>bg</code>, <code>border</code>, <code>radius</code>, <code>class</code></td>
					<td><?php esc_html_e( 'hex colour, number, css class', 'mvweb-reviews' ); ?></td>
					<td><?php esc_html_e( 'Appearance of this block only.', 'mvweb-reviews' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>

	<div class="mvweb-codeblock">
		<code>[mvweb_review_form group="kaminy" title="Leave a review"]</code>
	</div>

	<div class="mvweb-codeblock">
		<code>&lt;?php echo do_shortcode( '[mvweb_reviews layout="carousel"]' ); ?&gt;</code>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Questions', 'mvweb-reviews' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Will the markup give star snippets in search?', 'mvweb-reviews' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'No. Google excludes reviews a company publishes about itself, and Yandex does not use review markup at all — its rating comes from Yandex Business. The markup describes the entity for AI search, nothing more.', 'mvweb-reviews' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can reviews be pulled from Yandex Maps automatically?', 'mvweb-reviews' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'There is no public API for them, and copying map data automatically is against the terms of use. The Import tab takes the text you copy yourself and turns it into reviews.', 'mvweb-reviews' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Why do cards look the same height with reviews of different length?', 'mvweb-reviews' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'The whole text stays in the HTML, but it is visually clamped to the number of lines set on the Appearance tab and expands on click. Layout stays even whether there are three reviews or three hundred.', 'mvweb-reviews' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Who can approve reviews?', 'mvweb-reviews' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Administrators and editors. Plugin settings stay available to administrators only.', 'mvweb-reviews' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Do reviews have their own pages?', 'mvweb-reviews' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'No. The post type is not public, so no thin pages enter the index. Reviews appear only where the shortcode is placed.', 'mvweb-reviews' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-reviews' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php
		printf(
			/* translators: %s: plugin version. */
			esc_html__( 'MVweb Reviews %s — mvweb.ru', 'mvweb-reviews' ),
			esc_html( MVWEB_RV_VERSION )
		);
		?>
	</p>
</div>

<?php if ( class_exists( 'MVweb_License' ) ) : ?>
	<?php require MVWEB_RV_PATH . 'admin/views/partial-license.php'; ?>
<?php endif; ?>
