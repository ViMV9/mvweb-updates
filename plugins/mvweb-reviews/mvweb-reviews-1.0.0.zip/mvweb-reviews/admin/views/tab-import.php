<?php
/**
 * Import and export tab.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rv_msg  = isset( $_GET['mvweb_rv_msg'] ) ? sanitize_key( wp_unslash( $_GET['mvweb_rv_msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only status flag.
$mvweb_rv_done = isset( $_GET['mvweb_rv_done'] ) ? absint( wp_unslash( $_GET['mvweb_rv_done'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only status flag.
?>

<?php if ( 'imported' === $mvweb_rv_msg ) : ?>
	<div class="mvweb-alert mvweb-alert--success">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
		<div class="mvweb-alert__body">
			<p>
				<?php
				printf(
					/* translators: %d: number of created reviews. */
					esc_html( _n( '%d review created and placed in the moderation queue.', '%d reviews created and placed in the moderation queue.', $mvweb_rv_done, 'mvweb-reviews' ) ),
					(int) $mvweb_rv_done
				);
				?>
			</p>
		</div>
	</div>
<?php elseif ( 'csv_error' === $mvweb_rv_msg ) : ?>
	<div class="mvweb-alert mvweb-alert--error">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
		<div class="mvweb-alert__body">
			<p><?php esc_html_e( 'The CSV file could not be read. Check the delimiter, the header row and the file size.', 'mvweb-reviews' ); ?></p>
		</div>
	</div>
<?php endif; ?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Paste reviews from a map service', 'mvweb-reviews' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Copy the reviews from the company page and paste them here. The plugin never requests anything from Yandex or Google — this keeps the transfer within their terms of use.', 'mvweb-reviews' ); ?></p>

	<div class="mvweb-alert mvweb-alert--info">
		<p><?php esc_html_e( 'Expected format: reviews separated by an empty line. The first line of each block is the author name, a line with stars or “Оценка 5” becomes the rating, a line with a date becomes the publication date, everything else is the review text.', 'mvweb-reviews' ); ?></p>
	</div>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wp_nonce_field( 'mvweb_rv_import_paste' ); ?>
		<input type="hidden" name="action" value="mvweb_rv_import_paste">

		<div class="mvweb-form-row">
			<label for="mvweb_rv_paste" class="mvweb-form-row__label"><?php esc_html_e( 'Pasted text', 'mvweb-reviews' ); ?></label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb_rv_paste" name="mvweb_rv_paste" class="mvweb-textarea" rows="10"></textarea>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_rv_paste_source" class="mvweb-form-row__label"><?php esc_html_e( 'Source', 'mvweb-reviews' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_rv_paste_source" name="mvweb_rv_paste_source" class="mvweb-select">
					<option value="yandex"><?php esc_html_e( 'Yandex Maps', 'mvweb-reviews' ); ?></option>
					<option value="google"><?php esc_html_e( 'Google', 'mvweb-reviews' ); ?></option>
					<option value="manual"><?php esc_html_e( 'Added by admin', 'mvweb-reviews' ); ?></option>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_rv_paste_url" class="mvweb-form-row__label"><?php esc_html_e( 'Source URL', 'mvweb-reviews' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="url" id="mvweb_rv_paste_url" name="mvweb_rv_paste_url" class="mvweb-input" placeholder="https://yandex.ru/maps/org/…">
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Shown under imported reviews as a link to the original page.', 'mvweb-reviews' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_rv_paste_group" class="mvweb-form-row__label"><?php esc_html_e( 'Add to group', 'mvweb-reviews' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb_rv_paste_group" name="mvweb_rv_paste_group" class="mvweb-input" placeholder="<?php esc_attr_e( 'group-one, group-two', 'mvweb-reviews' ); ?>">
			</div>
		</div>

		<div class="mvweb-submit">
			<button type="submit" class="mvweb-btn mvweb-btn--primary"><?php esc_html_e( 'Parse and create', 'mvweb-reviews' ); ?></button>
		</div>
	</form>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'CSV', 'mvweb-reviews' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Semicolon delimited, UTF-8. Header row: name;date;rating;city;order;text;source;source_url;reply', 'mvweb-reviews' ); ?></p>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
		<?php wp_nonce_field( 'mvweb_rv_import_csv' ); ?>
		<input type="hidden" name="action" value="mvweb_rv_import_csv">

		<div class="mvweb-form-row">
			<label for="mvweb_rv_csv" class="mvweb-form-row__label"><?php esc_html_e( 'CSV file', 'mvweb-reviews' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="file" id="mvweb_rv_csv" name="mvweb_rv_csv" class="mvweb-file" accept=".csv" required>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_rv_csv_group" class="mvweb-form-row__label"><?php esc_html_e( 'Add to group', 'mvweb-reviews' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb_rv_csv_group" name="mvweb_rv_csv_group" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-submit">
			<button type="submit" class="mvweb-btn mvweb-btn--primary"><?php esc_html_e( 'Import CSV', 'mvweb-reviews' ); ?></button>
		</div>
	</form>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wp_nonce_field( 'mvweb_rv_export_csv' ); ?>
		<input type="hidden" name="action" value="mvweb_rv_export_csv">

		<div class="mvweb-submit">
			<button type="submit" class="mvweb-btn"><?php esc_html_e( 'Export all reviews', 'mvweb-reviews' ); ?></button>
		</div>
	</form>
</div>
