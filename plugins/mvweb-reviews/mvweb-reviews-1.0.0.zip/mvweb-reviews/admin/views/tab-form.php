<?php
/**
 * Visitor form settings tab.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rv_settings = mvweb_rv_get_settings();
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Review form', 'mvweb-reviews' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Placed with the [mvweb_review_form] shortcode. Every submission waits for moderation.', 'mvweb-reviews' ); ?></p>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_form_enabled" class="mvweb-form-row__label"><?php esc_html_e( 'Enable the form', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" id="mvweb_rv_form_enabled" name="mvweb_rv_form_enabled" value="1"
						<?php checked( (int) $mvweb_rv_settings['form_enabled'], 1 ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Visitors can submit their own reviews', 'mvweb-reviews' ); ?></span>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_form_contact" class="mvweb-form-row__label"><?php esc_html_e( 'Ask for a contact', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" id="mvweb_rv_form_contact" name="mvweb_rv_form_contact" value="1"
						<?php checked( (int) $mvweb_rv_settings['form_contact'], 1 ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Email or phone, stored with the review and never published', 'mvweb-reviews' ); ?></span>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_form_photo" class="mvweb-form-row__label"><?php esc_html_e( 'Allow a photo upload', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" id="mvweb_rv_form_photo" name="mvweb_rv_form_photo" value="1"
						<?php checked( (int) $mvweb_rv_settings['form_photo'], 1 ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'JPEG, PNG or WebP up to 3 MB', 'mvweb-reviews' ); ?></span>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_form_consent" class="mvweb-form-row__label"><?php esc_html_e( 'Consent checkbox', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" id="mvweb_rv_form_consent" name="mvweb_rv_form_consent" value="1"
						<?php checked( (int) $mvweb_rv_settings['form_consent'], 1 ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Required to submit; the moment of consent is stored with the review', 'mvweb-reviews' ); ?></span>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_consent_url" class="mvweb-form-row__label"><?php esc_html_e( 'Privacy policy URL', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="url" id="mvweb_rv_consent_url" name="mvweb_rv_consent_url" class="mvweb-input"
				value="<?php echo esc_attr( (string) $mvweb_rv_settings['consent_url'] ); ?>">
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Spam protection', 'mvweb-reviews' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'A hidden field, a minimum fill time and a per-IP limit. No captcha, no external services.', 'mvweb-reviews' ); ?></p>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_min_fill_time" class="mvweb-form-row__label"><?php esc_html_e( 'Minimum fill time, seconds', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_rv_min_fill_time" name="mvweb_rv_min_fill_time" class="mvweb-input" min="0" max="120"
				value="<?php echo esc_attr( (string) $mvweb_rv_settings['min_fill_time'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Submissions faster than this are rejected as automated.', 'mvweb-reviews' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_ip_limit" class="mvweb-form-row__label"><?php esc_html_e( 'Submissions per IP a day', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_rv_ip_limit" name="mvweb_rv_ip_limit" class="mvweb-input" min="0" max="50"
				value="<?php echo esc_attr( (string) $mvweb_rv_settings['ip_limit'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Zero removes the limit.', 'mvweb-reviews' ); ?></p>
		</div>
	</div>
</div>
