<?php
/**
 * General settings tab.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rv_settings = mvweb_rv_get_settings();
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Default output', 'mvweb-reviews' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Used when the shortcode has no attribute of its own.', 'mvweb-reviews' ); ?></p>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_layout" class="mvweb-form-row__label"><?php esc_html_e( 'Layout', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_rv_layout" name="mvweb_rv_layout" class="mvweb-select">
				<?php foreach ( mvweb_rv_layouts() as $mvweb_rv_key => $mvweb_rv_label ) : ?>
					<option value="<?php echo esc_attr( $mvweb_rv_key ); ?>" <?php selected( $mvweb_rv_settings['layout'], $mvweb_rv_key ); ?>>
						<?php echo esc_html( $mvweb_rv_label ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_order" class="mvweb-form-row__label"><?php esc_html_e( 'Order', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_rv_order" name="mvweb_rv_order" class="mvweb-select">
				<?php foreach ( mvweb_rv_orders() as $mvweb_rv_key => $mvweb_rv_label ) : ?>
					<option value="<?php echo esc_attr( $mvweb_rv_key ); ?>" <?php selected( $mvweb_rv_settings['order'], $mvweb_rv_key ); ?>>
						<?php echo esc_html( $mvweb_rv_label ); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Pinned reviews always come first, except in random order.', 'mvweb-reviews' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_limit" class="mvweb-form-row__label"><?php esc_html_e( 'Reviews per block', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_rv_limit" name="mvweb_rv_limit" class="mvweb-input" min="1" max="100"
				value="<?php echo esc_attr( (string) $mvweb_rv_settings['limit'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'The rest is loaded by the “Show more” button.', 'mvweb-reviews' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_scale" class="mvweb-form-row__label"><?php esc_html_e( 'Rating scale', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_rv_scale" name="mvweb_rv_scale" class="mvweb-select">
				<option value="5" <?php selected( (int) $mvweb_rv_settings['scale'], 5 ); ?>><?php esc_html_e( '5 stars', 'mvweb-reviews' ); ?></option>
				<option value="10" <?php selected( (int) $mvweb_rv_settings['scale'], 10 ); ?>><?php esc_html_e( '10 points', 'mvweb-reviews' ); ?></option>
			</select>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Card contents', 'mvweb-reviews' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Every switch can be overridden per shortcode.', 'mvweb-reviews' ); ?></p>

	<?php
	$mvweb_rv_toggles = array(
		'show_rating'  => __( 'Show rating stars', 'mvweb-reviews' ),
		'show_photo'   => __( 'Show author photo', 'mvweb-reviews' ),
		'show_date'    => __( 'Show review date', 'mvweb-reviews' ),
		'show_city'    => __( 'Show city', 'mvweb-reviews' ),
		'show_order'   => __( 'Show ordered service', 'mvweb-reviews' ),
		'show_summary' => __( 'Show summary rating block', 'mvweb-reviews' ),
	);

	foreach ( $mvweb_rv_toggles as $mvweb_rv_key => $mvweb_rv_label ) :
		?>
		<div class="mvweb-form-row">
			<label for="mvweb_rv_<?php echo esc_attr( $mvweb_rv_key ); ?>" class="mvweb-form-row__label"><?php echo esc_html( $mvweb_rv_label ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_rv_<?php echo esc_attr( $mvweb_rv_key ); ?>"
							name="mvweb_rv_<?php echo esc_attr( $mvweb_rv_key ); ?>"
							value="1"
							<?php checked( (int) $mvweb_rv_settings[ $mvweb_rv_key ], 1 ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
				</div>
			</div>
		</div>
	<?php endforeach; ?>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Performance', 'mvweb-reviews' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_cache_enabled" class="mvweb-form-row__label"><?php esc_html_e( 'Cache rendered blocks', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" id="mvweb_rv_cache_enabled" name="mvweb_rv_cache_enabled" value="1"
						<?php checked( (int) $mvweb_rv_settings['cache_enabled'], 1 ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Cleared automatically when a review or a setting changes.', 'mvweb-reviews' ); ?></span>
			</div>
		</div>
	</div>
</div>
