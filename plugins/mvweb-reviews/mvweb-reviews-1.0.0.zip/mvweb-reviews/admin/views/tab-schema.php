<?php
/**
 * Structured data settings tab.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rv_settings = mvweb_rv_get_settings();
$mvweb_rv_seo      = defined( 'WPSEO_VERSION' ) ? 'Yoast SEO' : ( defined( 'RANK_MATH_VERSION' ) ? 'Rank Math' : '' );
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'JSON-LD markup', 'mvweb-reviews' ); ?></div>
	</div>

	<div class="mvweb-alert mvweb-alert--info">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
		<div class="mvweb-alert__body">
			<p class="mvweb-alert__title"><?php esc_html_e( 'What this markup does and does not do', 'mvweb-reviews' ); ?></p>
			<p><?php esc_html_e( 'Google does not show star snippets for reviews a company publishes about itself on its own site (the self-serving rule), and the Service type is not supported for review snippets at all. Yandex does not list Review or AggregateRating among the supported schemas; the rating in its snippet comes from Yandex Business.', 'mvweb-reviews' ); ?></p>
			<p><?php esc_html_e( 'The markup is still worth having: it describes the entity for AI search and other consumers. Do not expect stars in search results from it.', 'mvweb-reviews' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_schema_enabled" class="mvweb-form-row__label"><?php esc_html_e( 'Output JSON-LD', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" id="mvweb_rv_schema_enabled" name="mvweb_rv_schema_enabled" value="1"
						<?php checked( (int) $mvweb_rv_settings['schema_enabled'], 1 ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'One block per page, for the reviews actually rendered on it', 'mvweb-reviews' ); ?></span>
			</div>
		</div>
	</div>

	<?php
	$mvweb_rv_schema_types = mvweb_rv_schema_types();
	$mvweb_rv_is_preset    = array_key_exists( $mvweb_rv_settings['schema_type'], $mvweb_rv_schema_types );
	?>
	<div class="mvweb-form-row">
		<label for="mvweb_rv_schema_type_preset" class="mvweb-form-row__label"><?php esc_html_e( 'Reviewed entity type', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_rv_schema_type_preset" class="mvweb-select" data-schema-type-preset>
				<?php foreach ( $mvweb_rv_schema_types as $mvweb_rv_type => $mvweb_rv_type_label ) : ?>
					<option value="<?php echo esc_attr( $mvweb_rv_type ); ?>" <?php selected( $mvweb_rv_settings['schema_type'], $mvweb_rv_type ); ?>>
						<?php echo esc_html( $mvweb_rv_type_label ); ?>
					</option>
				<?php endforeach; ?>
				<option value="" <?php selected( $mvweb_rv_is_preset, false ); ?>><?php esc_html_e( 'Other — enter a schema.org type manually', 'mvweb-reviews' ); ?></option>
			</select>
			<input type="text" id="mvweb_rv_schema_type" name="mvweb_rv_schema_type" class="mvweb-input" data-schema-type-custom
				value="<?php echo esc_attr( (string) $mvweb_rv_settings['schema_type'] ); ?>"
				<?php echo $mvweb_rv_is_preset ? 'hidden' : ''; ?>>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'The schema.org type of the reviewed business. Pick the closest match, or “Other” to enter one manually.', 'mvweb-reviews' ); ?>
			</p>
		</div>
	</div>

	<?php if ( '' !== $mvweb_rv_seo ) : ?>
		<div class="mvweb-alert mvweb-alert--success">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
			<div class="mvweb-alert__body">
				<p>
					<?php
					printf(
						/* translators: %s: SEO plugin name. */
						esc_html__( '%s is active: reviews are attached to the organization node it already outputs, so the entity is not duplicated.', 'mvweb-reviews' ),
						esc_html( $mvweb_rv_seo )
					);
					?>
				</p>
			</div>
		</div>
	<?php else : ?>
		<div class="mvweb-alert mvweb-alert--warning">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
			<div class="mvweb-alert__body">
				<p><?php esc_html_e( 'No supported SEO plugin found. The plugin outputs its own organization node with the name and URL of this site.', 'mvweb-reviews' ); ?></p>
			</div>
		</div>
	<?php endif; ?>
</div>
