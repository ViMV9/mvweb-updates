<?php
/**
 * Rendered instead of the settings page while the license verdict blocks it.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="wrap mvweb-settings">

	<?php settings_errors( 'mvweb_rv' ); ?>

	<div class="mvweb-empty">
		<div class="mvweb-empty__icon">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
		</div>
		<h3 class="mvweb-empty__title"><?php esc_html_e( 'Settings unavailable for this site', 'mvweb-reviews' ); ?></h3>
		<p class="mvweb-empty__text"><?php esc_html_e( 'The license for this domain is not active. Reviews already published on the site keep working as before — contact MVweb to restore access to settings and import.', 'mvweb-reviews' ); ?></p>
	</div>

	<?php require MVWEB_RV_PATH . 'admin/views/partial-license.php'; ?>

</div>
