<?php
/**
 * Admin settings page template.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 * Reference: docs/ui-kit-reference.html
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rv_current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.

$mvweb_rv_tabs = array(
	'general' => array(
		'label' => __( 'General', 'mvweb-reviews' ),
		'count' => MVweb_RV_CPT::pending_count() > 0 ? MVweb_RV_CPT::pending_count() : null,
		'icon'  => 'grid',
	),
	'design'  => array(
		'label' => __( 'Appearance', 'mvweb-reviews' ),
		'count' => null,
		'icon'  => 'palette',
	),
	'form'    => array(
		'label' => __( 'Form', 'mvweb-reviews' ),
		'count' => null,
		'icon'  => 'gear',
	),
	'schema'  => array(
		'label' => __( 'Markup', 'mvweb-reviews' ),
		'count' => null,
		'icon'  => 'code',
	),
	'import'  => array(
		'label' => __( 'Import', 'mvweb-reviews' ),
		'count' => null,
		'icon'  => 'import',
	),
	'help'    => array(
		'label' => __( 'Help', 'mvweb-reviews' ),
		'count' => null,
		'icon'  => 'help',
	),
);

$mvweb_rv_icons = array(
	'grid'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
	'palette' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="13.5" cy="6.5" r=".5"/><circle cx="17.5" cy="10.5" r=".5"/><circle cx="8.5" cy="7.5" r=".5"/><circle cx="6.5" cy="12.5" r=".5"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 12 2z"/></svg>',
	'gear'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
	'code'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
	'import'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
	'help'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">RV</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Reviews', 'mvweb-reviews' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_RV_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $mvweb_rv_tabs as $mvweb_rv_tab_id => $mvweb_rv_tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $mvweb_rv_tab_id ); ?>"
						class="mvweb-nav__link <?php echo $mvweb_rv_current_tab === $mvweb_rv_tab_id ? 'mvweb-nav__link--active' : ''; ?>"
						data-tab="<?php echo esc_attr( $mvweb_rv_tab_id ); ?>">
						<?php echo $mvweb_rv_icons[ $mvweb_rv_tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $mvweb_rv_tab['label'] ); ?>
						<?php if ( null !== $mvweb_rv_tab['count'] ) : ?>
							<span class="mvweb-nav__badge"><?php echo esc_html( (string) $mvweb_rv_tab['count'] ); ?></span>
						<?php endif; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php settings_errors( 'mvweb_rv' ); ?>

		<form method="post" action="">
			<?php wp_nonce_field( 'mvweb_rv_settings', 'mvweb_rv_nonce' ); ?>

			<div id="general" class="mvweb-tab-content <?php echo 'general' === $mvweb_rv_current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_RV_PATH . 'admin/views/tab-general.php'; ?>
			</div>

			<div id="design" class="mvweb-tab-content <?php echo 'design' === $mvweb_rv_current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_RV_PATH . 'admin/views/tab-design.php'; ?>
			</div>

			<div id="form" class="mvweb-tab-content <?php echo 'form' === $mvweb_rv_current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_RV_PATH . 'admin/views/tab-form.php'; ?>
			</div>

			<div id="schema" class="mvweb-tab-content <?php echo 'schema' === $mvweb_rv_current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_RV_PATH . 'admin/views/tab-schema.php'; ?>
			</div>

			<div class="mvweb-submit">
				<button type="submit" name="mvweb_rv_save" class="mvweb-btn mvweb-btn--primary">
					<?php esc_html_e( 'Save Changes', 'mvweb-reviews' ); ?>
				</button>
				<span class="mvweb-submit__hint"><kbd>⌘ S</kbd></span>
			</div>
		</form>

		<div id="import" class="mvweb-tab-content <?php echo 'import' === $mvweb_rv_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_RV_PATH . 'admin/views/tab-import.php'; ?>
		</div>

		<div id="help" class="mvweb-tab-content <?php echo 'help' === $mvweb_rv_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_RV_PATH . 'admin/views/tab-help.php'; ?>
		</div>

	</main>
</div>
