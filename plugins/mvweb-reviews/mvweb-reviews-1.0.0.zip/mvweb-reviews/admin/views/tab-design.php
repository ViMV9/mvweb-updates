<?php
/**
 * Appearance settings tab.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_rv_settings = mvweb_rv_get_settings();
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Cards', 'mvweb-reviews' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Font and text colour are inherited from the theme. Only the card frame is styled here.', 'mvweb-reviews' ); ?></p>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_card_min" class="mvweb-form-row__label"><?php esc_html_e( 'Minimum card width, px', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_rv_card_min" name="mvweb_rv_card_min" class="mvweb-input" min="180" max="640" step="10"
				value="<?php echo esc_attr( (string) $mvweb_rv_settings['card_min'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Columns are calculated automatically from this width and the space the block occupies.', 'mvweb-reviews' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_clamp_lines" class="mvweb-form-row__label"><?php esc_html_e( 'Text lines before clamping', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_rv_clamp_lines" name="mvweb_rv_clamp_lines" class="mvweb-input" min="2" max="40"
				value="<?php echo esc_attr( (string) $mvweb_rv_settings['clamp_lines'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Longer reviews are collapsed and expanded by the “Read in full” button, so cards keep the same height.', 'mvweb-reviews' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_radius" class="mvweb-form-row__label"><?php esc_html_e( 'Corner radius, px', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_rv_radius" name="mvweb_rv_radius" class="mvweb-input" min="0" max="40"
				value="<?php echo esc_attr( (string) $mvweb_rv_settings['radius'] ); ?>">
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_bg" class="mvweb-form-row__label"><?php esc_html_e( 'Card background', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_rv_bg" name="mvweb_rv_bg" class="mvweb-input" placeholder="#ffffff"
				value="<?php echo esc_attr( (string) $mvweb_rv_settings['bg'] ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Leave empty to inherit the theme background.', 'mvweb-reviews' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_border" class="mvweb-form-row__label"><?php esc_html_e( 'Border colour', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_rv_border" name="mvweb_rv_border" class="mvweb-input" placeholder="#e5e7eb"
				value="<?php echo esc_attr( (string) $mvweb_rv_settings['border'] ); ?>">
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_rv_star_color" class="mvweb-form-row__label"><?php esc_html_e( 'Star colour', 'mvweb-reviews' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_rv_star_color" name="mvweb_rv_star_color" class="mvweb-input" placeholder="#f7c917"
				value="<?php echo esc_attr( (string) $mvweb_rv_settings['star_color'] ); ?>">
		</div>
	</div>
</div>
