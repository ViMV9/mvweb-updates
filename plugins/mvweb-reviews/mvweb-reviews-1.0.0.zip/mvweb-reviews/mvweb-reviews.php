<?php
/**
 * Plugin Name:       MVweb Reviews
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-reviews
 * Description:       Client reviews with moderation, four shortcode layouts and JSON-LD markup.
 * Version:           1.0.0
 * Requires at least: 7.0
 * Tested up to:      7.1
 * Requires PHP:      8.2
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-reviews
 * Domain Path:       /languages
 *
 * @package mvweb_rv
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_RV_VERSION' ) ) {
	return;
}

define( 'MVWEB_RV_VERSION', '1.0.0' );
define( 'MVWEB_RV_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_RV_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_RV_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_RV_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_RV_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_RV_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_RV_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_RV_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

$mvweb_rv_updater = null;

if ( class_exists( 'MVweb_Updater' ) ) {
	$mvweb_rv_updater = MVweb_Updater::create( __FILE__, 'mvweb-reviews' );
}

// Load MVweb License.
if ( file_exists( MVWEB_RV_PATH . 'includes/class-mvweb-license.php' ) ) {
	require_once MVWEB_RV_PATH . 'includes/class-mvweb-license.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-license.php' ) ) {
	require_once $shared_path . 'class-mvweb-license.php';
}

if ( class_exists( 'MVweb_License' ) ) {
	MVweb_License::init( 'mvweb-reviews', $mvweb_rv_updater );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter(
	'mvweb_registered_plugins',
	function ( $plugins ) {
		$plugins['mvweb-reviews'] = array(
			'name'         => 'MVweb Reviews',
			'description'  => __( 'Client reviews with moderation, four shortcode layouts and JSON-LD markup.', 'mvweb-reviews' ),
			'url'          => 'https://mvweb.ru/plugins/mvweb-reviews',
			'settings_url' => 'admin.php?page=mvweb-reviews',
			'textdomain'   => 'mvweb-reviews',
		);
		return $plugins;
	}
);

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_rv_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-reviews',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_rv_load_textdomain' );

require_once MVWEB_RV_PATH . 'includes/helpers.php';
require_once MVWEB_RV_PATH . 'includes/class-mvweb-rv-cpt.php';
require_once MVWEB_RV_PATH . 'includes/class-mvweb-rv-metabox.php';
require_once MVWEB_RV_PATH . 'includes/class-mvweb-rv-query.php';
require_once MVWEB_RV_PATH . 'includes/class-mvweb-rv-render.php';
require_once MVWEB_RV_PATH . 'includes/class-mvweb-rv-shortcode.php';
require_once MVWEB_RV_PATH . 'includes/class-mvweb-rv-form.php';
require_once MVWEB_RV_PATH . 'includes/class-mvweb-rv-ajax.php';
require_once MVWEB_RV_PATH . 'includes/class-mvweb-rv-schema.php';
require_once MVWEB_RV_PATH . 'includes/class-mvweb-rv-import.php';
require_once MVWEB_RV_PATH . 'includes/class-mvweb-rv-admin.php';

MVweb_RV_CPT::init();
MVweb_RV_Metabox::init();
MVweb_RV_Shortcode::init();
MVweb_RV_Form::init();
MVweb_RV_Ajax::init();
MVweb_RV_Schema::init();
MVweb_RV_Import::init();
MVweb_RV_Admin::init();

register_activation_hook( __FILE__, array( 'MVweb_RV_CPT', 'activate' ) );
