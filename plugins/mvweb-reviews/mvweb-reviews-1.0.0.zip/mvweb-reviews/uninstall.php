<?php
/**
 * Uninstall MVweb Reviews
 *
 * Fired when the plugin is uninstalled.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Remove plugin data from the current site.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_rv_uninstall_site() {
	global $wpdb;

	delete_option( 'mvweb_rv_settings' );
	delete_option( 'mvweb_rv_cache_version' );

	$reviews = get_posts(
		array(
			'post_type'      => 'mvweb_review',
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		)
	);

	foreach ( $reviews as $review_id ) {
		$attachments = get_children(
			array(
				'post_parent' => (int) $review_id,
				'post_type'   => 'attachment',
				'fields'      => 'ids',
			)
		);

		foreach ( (array) $attachments as $attachment_id ) {
			wp_delete_attachment( (int) $attachment_id, true );
		}

		wp_delete_post( (int) $review_id, true );
	}

	$terms = get_terms(
		array(
			'taxonomy'   => 'mvweb_review_group',
			'hide_empty' => false,
			'fields'     => 'ids',
		)
	);

	if ( ! is_wp_error( $terms ) ) {
		foreach ( $terms as $term_id ) {
			wp_delete_term( (int) $term_id, 'mvweb_review_group' );
		}
	}

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- transient keys are not enumerable through the options API.
	$transients = $wpdb->get_col(
		$wpdb->prepare(
			"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
			$wpdb->esc_like( '_transient_mvweb_rv_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_mvweb_rv_' ) . '%'
		)
	);

	foreach ( (array) $transients as $option_name ) {
		delete_option( (string) $option_name );
	}
}

if ( is_multisite() ) {
	foreach ( get_sites( array( 'fields' => 'ids' ) ) as $mvweb_rv_site_id ) {
		switch_to_blog( (int) $mvweb_rv_site_id );
		mvweb_rv_uninstall_site();
		restore_current_blog();
	}
} else {
	mvweb_rv_uninstall_site();
}

wp_cache_flush();
