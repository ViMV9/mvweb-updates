/**
 * MVweb Reviews — front-end behaviour.
 *
 * Clamping with expand, carousel on CSS scroll-snap, lightbox and "Show more".
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

( function () {
	'use strict';

	var data = window.mvwebRvData || { ajaxUrl: '', i18n: {} };
	var i18n = data.i18n || {};

	function clampCard( card ) {
		var text = card.querySelector( '[data-text]' );
		var toggle = card.querySelector( '[data-toggle]' );

		if ( ! text || ! toggle ) {
			return;
		}

		text.classList.add( 'mvwebRv__text--clamped' );

		if ( text.scrollHeight - text.clientHeight < 4 ) {
			text.classList.remove( 'mvwebRv__text--clamped' );
			toggle.hidden = true;
			return;
		}

		toggle.hidden = false;
		toggle.textContent = i18n.readFull || 'Read in full';

		toggle.addEventListener( 'click', function () {
			var clamped = text.classList.toggle( 'mvwebRv__text--clamped' );

			toggle.textContent = clamped
				? ( i18n.readFull || 'Read in full' )
				: ( i18n.collapse || 'Collapse' );
		} );
	}

	function initClamps( root ) {
		root.querySelectorAll( '.mvwebRv__card' ).forEach( clampCard );
	}

	function initCarousel( block ) {
		var track = block.querySelector( '[data-track]' );
		var dotsBox = block.querySelector( '[data-dots]' );
		var prev = block.querySelector( '.mvwebRv__nav--prev' );
		var next = block.querySelector( '.mvwebRv__nav--next' );

		if ( ! track ) {
			return;
		}

		var cards = Array.prototype.slice.call( track.children );

		function step() {
			return cards.length ? cards[ 0 ].offsetWidth + 20 : track.clientWidth;
		}

		function syncState() {
			var index = Math.round( track.scrollLeft / step() );
			var maxScroll = track.scrollWidth - track.clientWidth - 2;

			if ( prev ) {
				prev.disabled = track.scrollLeft <= 2;
			}

			if ( next ) {
				next.disabled = track.scrollLeft >= maxScroll;
			}

			if ( dotsBox ) {
				Array.prototype.forEach.call( dotsBox.children, function ( dot, i ) {
					dot.classList.toggle( 'mvwebRv__dot--active', i === index );
				} );
			}
		}

		if ( dotsBox ) {
			cards.forEach( function ( card, index ) {
				var dot = document.createElement( 'button' );

				dot.type = 'button';
				dot.className = 'mvwebRv__dot';
				dot.setAttribute( 'aria-label', String( index + 1 ) );
				dot.addEventListener( 'click', function () {
					track.scrollTo( { left: index * step(), behavior: 'smooth' } );
				} );

				dotsBox.appendChild( dot );
			} );
		}

		if ( prev ) {
			prev.addEventListener( 'click', function () {
				track.scrollBy( { left: -step(), behavior: 'smooth' } );
			} );
		}

		if ( next ) {
			next.addEventListener( 'click', function () {
				track.scrollBy( { left: step(), behavior: 'smooth' } );
			} );
		}

		track.addEventListener( 'scroll', function () {
			window.clearTimeout( track.mvwebRvTimer );
			track.mvwebRvTimer = window.setTimeout( syncState, 80 );
		} );

		syncState();
	}

	function lightbox() {
		var dialog = document.querySelector( '.mvwebRvLightbox' );

		if ( dialog ) {
			return dialog;
		}

		dialog = document.createElement( 'dialog' );
		dialog.className = 'mvwebRvLightbox';

		var close = document.createElement( 'button' );

		close.type = 'button';
		close.className = 'mvwebRvLightbox__close';
		close.setAttribute( 'aria-label', i18n.closeText || 'Close' );
		close.textContent = '×';

		var image = document.createElement( 'img' );

		image.alt = '';

		dialog.appendChild( close );
		dialog.appendChild( image );

		dialog.addEventListener( 'click', function ( event ) {
			if ( event.target === dialog || event.target === close ) {
				dialog.close();
			}
		} );

		document.body.appendChild( dialog );

		return dialog;
	}

	function initLightbox( root ) {
		root.querySelectorAll( '[data-lightbox]' ).forEach( function ( button ) {
			if ( button.dataset.mvwebRvBound ) {
				return;
			}

			button.dataset.mvwebRvBound = '1';

			button.addEventListener( 'click', function () {
				var dialog = lightbox();
				var image = dialog.querySelector( 'img' );

				image.src = button.getAttribute( 'data-lightbox' );

				if ( typeof dialog.showModal === 'function' ) {
					dialog.showModal();
				}
			} );
		} );
	}

	function appendCards( html, items ) {
		var parsed = new DOMParser().parseFromString( html, 'text/html' );
		var nodes = Array.prototype.slice.call( parsed.body.children );

		nodes.forEach( function ( node ) {
			var added = items.appendChild( document.importNode( node, true ) );

			if ( added.classList.contains( 'mvwebRv__card' ) ) {
				clampCard( added );
			}
		} );

		initLightbox( items );
	}

	function initMore( block ) {
		var button = block.querySelector( '[data-more]' );
		var items = block.querySelector( '[data-items]' );

		if ( ! button || ! items ) {
			return;
		}

		var label = button.textContent;

		button.addEventListener( 'click', function () {
			var body = new FormData();

			body.append( 'action', 'mvweb_rv_more' );
			body.append( 'nonce', button.getAttribute( 'data-nonce' ) );
			body.append( 'args', button.getAttribute( 'data-args' ) );
			body.append( 'offset', button.getAttribute( 'data-offset' ) );

			button.disabled = true;
			button.textContent = i18n.loading || 'Loading…';

			fetch( data.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body } )
				.then( function ( response ) {
					return response.json();
				} )
				.then( function ( result ) {
					if ( ! result || ! result.success ) {
						button.remove();
						return;
					}

					appendCards( result.data.html, items );

					if ( result.data.done ) {
						button.remove();
						return;
					}

					button.setAttribute( 'data-offset', result.data.offset );
					button.disabled = false;
					button.textContent = label;
				} )
				.catch( function () {
					button.disabled = false;
					button.textContent = label;
				} );
		} );
	}

	function init() {
		document.querySelectorAll( '.mvwebRv' ).forEach( function ( block ) {
			initClamps( block );
			initLightbox( block );
			initMore( block );

			if ( block.classList.contains( 'mvwebRv--carousel' ) ) {
				initCarousel( block );
			}
		} );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}() );
