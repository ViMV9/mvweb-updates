<?php
/**
 * Review post type, taxonomy, meta and admin list table.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the review content model.
 *
 * @since 1.0.0
 */
class MVweb_RV_CPT {

	public const POST_TYPE = 'mvweb_review';

	public const TAXONOMY = 'mvweb_review_group';

	/**
	 * Hook the content model into WordPress.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_filter( 'manage_' . self::POST_TYPE . '_posts_columns', array( __CLASS__, 'columns' ) );
		add_action( 'manage_' . self::POST_TYPE . '_posts_custom_column', array( __CLASS__, 'column_content' ), 10, 2 );
		add_filter( 'manage_edit-' . self::POST_TYPE . '_sortable_columns', array( __CLASS__, 'sortable_columns' ) );
		add_action( 'pre_get_posts', array( __CLASS__, 'sort_by_rating' ) );
		add_filter( 'bulk_actions-edit-' . self::POST_TYPE, array( __CLASS__, 'bulk_actions' ) );
		add_filter( 'handle_bulk_actions-edit-' . self::POST_TYPE, array( __CLASS__, 'handle_bulk_actions' ), 10, 3 );
		add_filter( 'display_post_states', array( __CLASS__, 'post_states' ), 10, 2 );
		add_action( 'admin_menu', array( __CLASS__, 'pending_badge' ), 999 );
		add_action( 'save_post_' . self::POST_TYPE, array( __CLASS__, 'on_save' ), 20 );
		add_action( 'deleted_post', array( __CLASS__, 'on_delete' ), 10, 2 );
		add_action( 'transition_post_status', array( __CLASS__, 'on_status_change' ), 10, 3 );
	}

	/**
	 * Flush rewrite rules on activation.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function activate(): void {
		self::register();
		flush_rewrite_rules();
	}

	/**
	 * Register post type, taxonomy and meta.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		register_post_type(
			self::POST_TYPE,
			array(
				'labels'              => array(
					'name'               => __( 'Reviews', 'mvweb-reviews' ),
					'singular_name'      => __( 'Review', 'mvweb-reviews' ),
					'add_new'            => __( 'Add review', 'mvweb-reviews' ),
					'add_new_item'       => __( 'Add review', 'mvweb-reviews' ),
					'edit_item'          => __( 'Edit review', 'mvweb-reviews' ),
					'new_item'           => __( 'New review', 'mvweb-reviews' ),
					'view_item'          => __( 'View review', 'mvweb-reviews' ),
					'search_items'       => __( 'Search reviews', 'mvweb-reviews' ),
					'not_found'          => __( 'No reviews found', 'mvweb-reviews' ),
					'not_found_in_trash' => __( 'No reviews in trash', 'mvweb-reviews' ),
					'all_items'          => __( 'All reviews', 'mvweb-reviews' ),
					'menu_name'          => __( 'Reviews', 'mvweb-reviews' ),
				),
				'public'              => false,
				'publicly_queryable'  => false,
				'exclude_from_search' => true,
				'show_ui'             => true,
				'show_in_menu'        => true,
				'show_in_nav_menus'   => false,
				'show_in_rest'        => false,
				'has_archive'         => false,
				'rewrite'             => false,
				'query_var'           => false,
				'menu_icon'           => 'dashicons-format-status',
				'menu_position'       => 25,
				'capability_type'     => 'post',
				'map_meta_cap'        => true,
				'supports'            => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
			)
		);

		register_taxonomy(
			self::TAXONOMY,
			self::POST_TYPE,
			array(
				'labels'            => array(
					'name'          => __( 'Review groups', 'mvweb-reviews' ),
					'singular_name' => __( 'Review group', 'mvweb-reviews' ),
					'add_new_item'  => __( 'Add group', 'mvweb-reviews' ),
					'edit_item'     => __( 'Edit group', 'mvweb-reviews' ),
					'search_items'  => __( 'Search groups', 'mvweb-reviews' ),
					'all_items'     => __( 'All groups', 'mvweb-reviews' ),
					'menu_name'     => __( 'Groups', 'mvweb-reviews' ),
				),
				'public'            => false,
				'show_ui'           => true,
				'show_admin_column' => true,
				'show_in_rest'      => false,
				'hierarchical'      => false,
				'rewrite'           => false,
				'query_var'         => false,
			)
		);

		foreach ( self::meta_fields() as $key => $args ) {
			register_post_meta(
				self::POST_TYPE,
				$key,
				array(
					'type'              => $args['type'],
					'single'            => true,
					'show_in_rest'      => false,
					'sanitize_callback' => $args['sanitize'],
					'auth_callback'     => static function (): bool {
						return current_user_can( mvweb_rv_moderate_cap() );
					},
				)
			);
		}
	}

	/**
	 * Meta field map: type and sanitizer per key.
	 *
	 * @since 1.0.0
	 * @return array<string, array{type: string, sanitize: callable}>
	 */
	public static function meta_fields(): array {
		return array(
			'_mvweb_rv_rating'     => array(
				'type'     => 'integer',
				'sanitize' => static function ( $value ): int {
					$value = (int) $value;

					return ( $value >= 0 && $value <= 10 ) ? $value : 0;
				},
			),
			'_mvweb_rv_city'       => array(
				'type'     => 'string',
				'sanitize' => 'sanitize_text_field',
			),
			'_mvweb_rv_order'      => array(
				'type'     => 'string',
				'sanitize' => 'sanitize_text_field',
			),
			'_mvweb_rv_gallery'    => array(
				'type'     => 'string',
				'sanitize' => static function ( $value ): string {
					$ids = array_filter( array_map( 'absint', explode( ',', (string) $value ) ) );

					return implode( ',', $ids );
				},
			),
			'_mvweb_rv_reply'      => array(
				'type'     => 'string',
				'sanitize' => 'wp_kses_post',
			),
			'_mvweb_rv_pinned'     => array(
				'type'     => 'integer',
				'sanitize' => static function ( $value ): int {
					return $value ? 1 : 0;
				},
			),
			'_mvweb_rv_source'     => array(
				'type'     => 'string',
				'sanitize' => static function ( $value ): string {
					$value = sanitize_key( (string) $value );

					return array_key_exists( $value, mvweb_rv_sources() ) ? $value : 'manual';
				},
			),
			'_mvweb_rv_source_url' => array(
				'type'     => 'string',
				'sanitize' => 'esc_url_raw',
			),
			'_mvweb_rv_contact'    => array(
				'type'     => 'string',
				'sanitize' => 'sanitize_text_field',
			),
			'_mvweb_rv_consent'    => array(
				'type'     => 'string',
				'sanitize' => 'sanitize_text_field',
			),
		);
	}

	/**
	 * Admin list columns.
	 *
	 * @since 1.0.0
	 * @param array<string, string> $columns Existing columns.
	 * @return array<string, string>
	 */
	public static function columns( array $columns ): array {
		$new = array();

		foreach ( $columns as $key => $label ) {
			if ( 'title' === $key ) {
				$new['mvweb_rv_photo'] = __( 'Photo', 'mvweb-reviews' );
				$new['title']          = __( 'Author', 'mvweb-reviews' );
				$new['mvweb_rv_text']  = __( 'Review', 'mvweb-reviews' );
				continue;
			}

			if ( 'date' === $key ) {
				$new['mvweb_rv_rating'] = __( 'Rating', 'mvweb-reviews' );
				$new['mvweb_rv_source'] = __( 'Source', 'mvweb-reviews' );
			}

			$new[ $key ] = $label;
		}

		return $new;
	}

	/**
	 * Render custom column content.
	 *
	 * @since 1.0.0
	 * @param string $column  Column key.
	 * @param int    $post_id Review ID.
	 * @return void
	 */
	public static function column_content( $column, $post_id ): void {
		$post_id = (int) $post_id;

		switch ( $column ) {
			case 'mvweb_rv_photo':
				if ( has_post_thumbnail( $post_id ) ) {
					echo get_the_post_thumbnail( $post_id, array( 40, 40 ), array( 'style' => 'border-radius:50%;object-fit:cover;' ) );
					break;
				}

				printf(
					'<span class="mvweb-rv-initials-admin">%s</span>',
					esc_html( mvweb_rv_initials( (string) get_the_title( $post_id ) ) )
				);
				break;

			case 'mvweb_rv_text':
				echo esc_html( wp_trim_words( wp_strip_all_tags( (string) get_post_field( 'post_content', $post_id ) ), 18 ) );
				break;

			case 'mvweb_rv_rating':
				$rating = (int) get_post_meta( $post_id, '_mvweb_rv_rating', true );

				echo $rating > 0
					? esc_html( str_repeat( '★', $rating ) )
					: '<span aria-hidden="true">—</span>';
				break;

			case 'mvweb_rv_source':
				$source  = (string) get_post_meta( $post_id, '_mvweb_rv_source', true );
				$sources = mvweb_rv_sources();

				echo esc_html( $sources[ $source ] ?? $sources['manual'] );
				break;
		}
	}

	/**
	 * Allow sorting by rating.
	 *
	 * @since 1.0.0
	 * @param array<string, string> $columns Sortable columns.
	 * @return array<string, string>
	 */
	public static function sortable_columns( array $columns ): array {
		$columns['mvweb_rv_rating'] = 'mvweb_rv_rating';

		return $columns;
	}

	/**
	 * Apply rating ordering in the admin list.
	 *
	 * @since 1.0.0
	 * @param WP_Query $query Current query.
	 * @return void
	 */
	public static function sort_by_rating( $query ): void {
		if ( ! is_admin() || ! $query->is_main_query() || 'mvweb_rv_rating' !== $query->get( 'orderby' ) ) {
			return;
		}

		$query->set( 'meta_key', '_mvweb_rv_rating' );
		$query->set( 'orderby', 'meta_value_num' );
	}

	/**
	 * Register bulk actions.
	 *
	 * @since 1.0.0
	 * @param array<string, string> $actions Existing actions.
	 * @return array<string, string>
	 */
	public static function bulk_actions( array $actions ): array {
		$actions['mvweb_rv_approve'] = __( 'Approve', 'mvweb-reviews' );
		$actions['mvweb_rv_pin']     = __( 'Pin to top', 'mvweb-reviews' );
		$actions['mvweb_rv_unpin']   = __( 'Unpin', 'mvweb-reviews' );

		return $actions;
	}

	/**
	 * Process bulk actions.
	 *
	 * @since 1.0.0
	 * @param string     $redirect Redirect URL.
	 * @param string     $action   Action name.
	 * @param array<int> $post_ids Selected reviews.
	 * @return string
	 */
	public static function handle_bulk_actions( $redirect, $action, $post_ids ): string {
		if ( ! in_array( $action, array( 'mvweb_rv_approve', 'mvweb_rv_pin', 'mvweb_rv_unpin' ), true ) ) {
			return $redirect;
		}

		$done = 0;

		foreach ( (array) $post_ids as $post_id ) {
			$post_id = (int) $post_id;

			if ( ! current_user_can( mvweb_rv_moderate_cap() ) || ! current_user_can( 'edit_post', $post_id ) ) {
				continue;
			}

			if ( 'mvweb_rv_approve' === $action ) {
				wp_update_post(
					array(
						'ID'          => $post_id,
						'post_status' => 'publish',
					)
				);
			} else {
				update_post_meta( $post_id, '_mvweb_rv_pinned', 'mvweb_rv_pin' === $action ? 1 : 0 );
			}

			++$done;
		}

		mvweb_rv_flush_cache();

		return add_query_arg( 'mvweb_rv_done', $done, $redirect );
	}

	/**
	 * Mark pinned reviews in the list table.
	 *
	 * @since 1.0.0
	 * @param array<string, string> $states Post states.
	 * @param WP_Post               $post   Current post.
	 * @return array<string, string>
	 */
	public static function post_states( $states, $post ): array {
		if ( self::POST_TYPE === $post->post_type && get_post_meta( $post->ID, '_mvweb_rv_pinned', true ) ) {
			$states['mvweb_rv_pinned'] = __( 'Pinned', 'mvweb-reviews' );
		}

		return $states;
	}

	/**
	 * Count of reviews awaiting moderation.
	 *
	 * @since 1.0.0
	 * @return int
	 */
	public static function pending_count(): int {
		$count = get_transient( 'mvweb_rv_pending_count' );

		if ( false === $count ) {
			$counts = wp_count_posts( self::POST_TYPE );
			$count  = isset( $counts->pending ) ? (int) $counts->pending : 0;

			set_transient( 'mvweb_rv_pending_count', $count, HOUR_IN_SECONDS );
		}

		return (int) $count;
	}

	/**
	 * Add the pending counter bubble to the menu item.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function pending_badge(): void {
		global $menu;

		$count = self::pending_count();

		if ( $count < 1 || ! is_array( $menu ) ) {
			return;
		}

		$slug = 'edit.php?post_type=' . self::POST_TYPE;

		foreach ( $menu as $index => $item ) {
			if ( isset( $item[2] ) && $slug === $item[2] ) {
				// phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- the pending bubble is added the way core does it for comments.
				$menu[ $index ][0] .= sprintf(
					' <span class="awaiting-mod"><span class="pending-count">%d</span></span>',
					$count
				);
				break;
			}
		}
	}

	/**
	 * Keep sorting meta present and drop caches when a review changes.
	 *
	 * Ordering joins on `_mvweb_rv_pinned` and `_mvweb_rv_rating`, so a review
	 * saved by any other code path must still carry both keys.
	 *
	 * @since 1.0.0
	 * @param int $post_id Saved review ID.
	 * @return void
	 */
	public static function on_save( $post_id ): void {
		$post_id = (int) $post_id;

		foreach ( array( '_mvweb_rv_pinned', '_mvweb_rv_rating' ) as $key ) {
			if ( '' === (string) get_post_meta( $post_id, $key, true ) ) {
				update_post_meta( $post_id, $key, 0 );
			}
		}

		mvweb_rv_flush_cache();
	}

	/**
	 * Drop caches when a review is deleted.
	 *
	 * @since 1.0.0
	 * @param int          $post_id Deleted post ID.
	 * @param WP_Post|null $post    Deleted post object.
	 * @return void
	 */
	public static function on_delete( $post_id, $post = null ): void {
		if ( $post instanceof WP_Post && self::POST_TYPE !== $post->post_type ) {
			return;
		}

		mvweb_rv_flush_cache();
	}

	/**
	 * Drop caches on status transitions.
	 *
	 * @since 1.0.0
	 * @param string  $new_status New status.
	 * @param string  $old_status Old status.
	 * @param WP_Post $post       Affected post.
	 * @return void
	 */
	public static function on_status_change( $new_status, $old_status, $post ): void {
		if ( self::POST_TYPE === $post->post_type && $new_status !== $old_status ) {
			mvweb_rv_flush_cache();
		}
	}
}
