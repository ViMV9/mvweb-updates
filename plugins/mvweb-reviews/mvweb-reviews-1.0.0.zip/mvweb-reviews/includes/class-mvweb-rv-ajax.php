<?php
/**
 * AJAX handler for the "Show more" button.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads the next portion of reviews.
 *
 * @since 1.0.0
 */
class MVweb_RV_Ajax {

	/**
	 * Hook the AJAX endpoints.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'wp_ajax_mvweb_rv_more', array( __CLASS__, 'more' ) );
		add_action( 'wp_ajax_nopriv_mvweb_rv_more', array( __CLASS__, 'more' ) );
	}

	/**
	 * Return the next batch of review cards.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function more(): void {
		check_ajax_referer( 'mvweb_rv_more', 'nonce' );

		$raw = isset( $_POST['args'] ) ? wp_unslash( $_POST['args'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- normalized below.
		$raw = is_string( $raw ) ? json_decode( $raw, true ) : array();
		$raw = is_array( $raw ) ? $raw : array();

		$args           = MVweb_RV_Shortcode::normalize( $raw );
		$args['offset'] = isset( $_POST['offset'] ) ? absint( wp_unslash( $_POST['offset'] ) ) : 0;

		$query = MVweb_RV_Query::get( $args );

		if ( ! $query->have_posts() ) {
			wp_send_json_success(
				array(
					'html' => '',
					'done' => true,
				)
			);
		}

		$ids = array_map( 'intval', wp_list_pluck( $query->posts, 'ID' ) );

		MVweb_RV_Render::track( $ids );

		$next = $args['offset'] + count( $ids );

		wp_send_json_success(
			array(
				'html'   => MVweb_RV_Render::items( $ids, $args ),
				'offset' => $next,
				'done'   => $next >= (int) $query->found_posts,
			)
		);
	}
}
