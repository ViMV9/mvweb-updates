<?php
/**
 * Visitor review form and submission handling.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders the form and stores submitted reviews for moderation.
 *
 * @since 1.0.0
 */
class MVweb_RV_Form {

	private const MAX_PHOTO_BYTES = 3145728;

	/**
	 * Hook the submission handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'template_redirect', array( __CLASS__, 'handle' ) );
		add_action( 'before_delete_post', array( __CLASS__, 'delete_attachments' ) );
	}

	/**
	 * Render the [mvweb_review_form] shortcode.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed>|string $atts Shortcode attributes.
	 * @return string
	 */
	public static function shortcode( $atts ): string {
		if ( ! mvweb_rv_get_settings( 'form_enabled' ) ) {
			return '';
		}

		$atts = shortcode_atts(
			array(
				'group' => '',
				'title' => __( 'Leave a review', 'mvweb-reviews' ),
			),
			is_array( $atts ) ? $atts : array(),
			'mvweb_review_form'
		);

		MVweb_RV_Shortcode::enqueue();

		$settings = mvweb_rv_get_settings();
		$scale    = 10 === (int) $settings['scale'] ? 10 : 5;
		$status   = isset( $_GET['mvweb_rv_sent'] ) ? sanitize_key( wp_unslash( $_GET['mvweb_rv_sent'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only status flag.

		ob_start();
		?>
		<div class="mvwebRvForm">
			<?php if ( 'ok' === $status ) : ?>
				<p class="mvwebRvForm__notice mvwebRvForm__notice--ok" role="status">
					<?php esc_html_e( 'Thank you! Your review has been sent for moderation.', 'mvweb-reviews' ); ?>
				</p>
			<?php elseif ( '' !== $status ) : ?>
				<p class="mvwebRvForm__notice mvwebRvForm__notice--error" role="alert">
					<?php echo esc_html( self::error_message( $status ) ); ?>
				</p>
			<?php endif; ?>

			<form class="mvwebRvForm__form" method="post" enctype="multipart/form-data" action="<?php echo esc_url( get_permalink() ); ?>">
				<?php wp_nonce_field( 'mvweb_rv_submit', 'mvweb_rv_nonce' ); ?>
				<input type="hidden" name="mvweb_rv_action" value="submit">
				<input type="hidden" name="mvweb_rv_group" value="<?php echo esc_attr( (string) $atts['group'] ); ?>">
				<input type="hidden" name="mvweb_rv_time" value="<?php echo esc_attr( (string) time() ); ?>">

				<p class="mvwebRvForm__hp" aria-hidden="true">
					<label for="mvwebRvWebsite"><?php esc_html_e( 'Website', 'mvweb-reviews' ); ?></label>
					<input type="text" id="mvwebRvWebsite" name="mvweb_rv_website" tabindex="-1" autocomplete="off" value="">
				</p>

				<?php if ( '' !== (string) $atts['title'] ) : ?>
					<p class="mvwebRvForm__title"><?php echo esc_html( (string) $atts['title'] ); ?></p>
				<?php endif; ?>

				<p class="mvwebRvForm__row">
					<label for="mvwebRvName"><?php esc_html_e( 'Your name', 'mvweb-reviews' ); ?> <span aria-hidden="true">*</span></label>
					<input type="text" id="mvwebRvName" name="mvweb_rv_name" required maxlength="100">
				</p>

				<p class="mvwebRvForm__row">
					<label for="mvwebRvText"><?php esc_html_e( 'Your review', 'mvweb-reviews' ); ?> <span aria-hidden="true">*</span></label>
					<textarea id="mvwebRvText" name="mvweb_rv_text" rows="5" required maxlength="4000"></textarea>
				</p>

				<p class="mvwebRvForm__row">
					<label for="mvwebRvRating"><?php esc_html_e( 'Rating', 'mvweb-reviews' ); ?></label>
					<select id="mvwebRvRating" name="mvweb_rv_rating">
						<option value="0"><?php esc_html_e( '— no rating —', 'mvweb-reviews' ); ?></option>
						<?php for ( $i = $scale; $i >= 1; $i-- ) : ?>
							<option value="<?php echo esc_attr( (string) $i ); ?>"><?php echo esc_html( str_repeat( '★', $i ) ); ?></option>
						<?php endfor; ?>
					</select>
				</p>

				<?php if ( $settings['form_contact'] ) : ?>
					<p class="mvwebRvForm__row">
						<label for="mvwebRvContact"><?php esc_html_e( 'Email or phone', 'mvweb-reviews' ); ?></label>
						<input type="text" id="mvwebRvContact" name="mvweb_rv_contact" maxlength="100">
						<span class="mvwebRvForm__hint"><?php esc_html_e( 'Never published, used only to contact you.', 'mvweb-reviews' ); ?></span>
					</p>
				<?php endif; ?>

				<?php if ( $settings['form_photo'] ) : ?>
					<p class="mvwebRvForm__row">
						<label for="mvwebRvPhoto"><?php esc_html_e( 'Your photo', 'mvweb-reviews' ); ?></label>
						<input type="file" id="mvwebRvPhoto" name="mvweb_rv_photo" accept="image/jpeg,image/png,image/webp">
					</p>
				<?php endif; ?>

				<?php if ( $settings['form_consent'] ) : ?>
					<p class="mvwebRvForm__row mvwebRvForm__row--consent">
						<label>
							<input type="checkbox" name="mvweb_rv_consent" value="1" required>
							<?php
							$consent_url = (string) $settings['consent_url'];

							if ( '' !== $consent_url ) {
								printf(
									/* translators: %s: privacy policy link. */
									esc_html__( 'I agree to the processing of my personal data (%s)', 'mvweb-reviews' ),
									'<a href="' . esc_url( $consent_url ) . '" target="_blank" rel="noopener">' . esc_html__( 'privacy policy', 'mvweb-reviews' ) . '</a>'
								);
							} else {
								esc_html_e( 'I agree to the processing of my personal data', 'mvweb-reviews' );
							}
							?>
						</label>
					</p>
				<?php endif; ?>

				<p class="mvwebRvForm__submit">
					<button type="submit"><?php esc_html_e( 'Send review', 'mvweb-reviews' ); ?></button>
				</p>
			</form>
		</div>
		<?php
		return trim( (string) ob_get_clean() );
	}

	/**
	 * Handle a submitted review.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function handle(): void {
		if ( ! isset( $_POST['mvweb_rv_action'] ) || 'submit' !== $_POST['mvweb_rv_action'] ) {
			return;
		}

		if ( ! mvweb_rv_get_settings( 'form_enabled' ) ) {
			return;
		}

		$nonce = isset( $_POST['mvweb_rv_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_rv_nonce'] ) ) : '';

		if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'mvweb_rv_submit' ) ) {
			self::redirect( 'nonce' );
		}

		$honeypot = isset( $_POST['mvweb_rv_website'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['mvweb_rv_website'] ) ) ) : '';
		$started  = isset( $_POST['mvweb_rv_time'] ) ? absint( wp_unslash( $_POST['mvweb_rv_time'] ) ) : 0;
		$elapsed  = time() - $started;
		$min_time = (int) mvweb_rv_get_settings( 'min_fill_time', 5 );

		if ( '' !== $honeypot || $started < 1 || $elapsed < $min_time ) {
			self::redirect( 'spam' );
		}

		if ( ! self::within_ip_limit() ) {
			self::redirect( 'limit' );
		}

		$name = isset( $_POST['mvweb_rv_name'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_rv_name'] ) ) : '';
		$text = isset( $_POST['mvweb_rv_text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['mvweb_rv_text'] ) ) : '';

		if ( '' === $name || '' === trim( $text ) ) {
			self::redirect( 'empty' );
		}

		$settings = mvweb_rv_get_settings();

		if ( $settings['form_consent'] && empty( $_POST['mvweb_rv_consent'] ) ) {
			self::redirect( 'consent' );
		}

		$rating  = isset( $_POST['mvweb_rv_rating'] ) ? absint( wp_unslash( $_POST['mvweb_rv_rating'] ) ) : 0;
		$scale   = 10 === (int) $settings['scale'] ? 10 : 5;
		$rating  = ( $rating >= 1 && $rating <= $scale ) ? $rating : 0;
		$contact = isset( $_POST['mvweb_rv_contact'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_rv_contact'] ) ) : '';
		$group   = isset( $_POST['mvweb_rv_group'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_rv_group'] ) ) : '';

		$post_id = wp_insert_post(
			array(
				'post_type'    => MVweb_RV_CPT::POST_TYPE,
				'post_status'  => 'pending',
				'post_title'   => wp_trim_words( $name, 10, '' ),
				'post_content' => $text,
			),
			true
		);

		if ( is_wp_error( $post_id ) ) {
			self::redirect( 'failed' );
		}

		$post_id = (int) $post_id;

		update_post_meta( $post_id, '_mvweb_rv_rating', $rating );
		update_post_meta( $post_id, '_mvweb_rv_source', 'site_form' );
		update_post_meta( $post_id, '_mvweb_rv_pinned', 0 );

		if ( '' !== $contact ) {
			update_post_meta( $post_id, '_mvweb_rv_contact', $contact );
		}

		if ( $settings['form_consent'] ) {
			update_post_meta( $post_id, '_mvweb_rv_consent', current_time( 'mysql' ) );
		}

		self::assign_existing_groups( $post_id, $group );

		if ( $settings['form_photo'] ) {
			self::attach_photo( $post_id );
		}

		self::mark_ip();
		delete_transient( 'mvweb_rv_pending_count' );

		self::redirect( 'ok' );
	}

	/**
	 * Attach the review to groups that already exist.
	 *
	 * Visitors must not be able to create new terms through the form, so unknown
	 * slugs are dropped instead of being registered.
	 *
	 * @since 1.0.0
	 * @param int    $post_id Review ID.
	 * @param string $group   Comma separated group slugs from the shortcode.
	 * @return void
	 */
	private static function assign_existing_groups( int $post_id, string $group ): void {
		if ( '' === $group ) {
			return;
		}

		$term_ids = array();

		foreach ( explode( ',', $group ) as $slug ) {
			$term = get_term_by( 'slug', sanitize_title( trim( $slug ) ), MVweb_RV_CPT::TAXONOMY );

			if ( $term instanceof WP_Term ) {
				$term_ids[] = (int) $term->term_id;
			}
		}

		if ( ! empty( $term_ids ) ) {
			wp_set_object_terms( $post_id, $term_ids, MVweb_RV_CPT::TAXONOMY );
		}
	}

	/**
	 * Store the uploaded author photo as the review thumbnail.
	 *
	 * @since 1.0.0
	 * @param int $post_id Review ID.
	 * @return void
	 */
	private static function attach_photo( int $post_id ): void {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified in self::handle().
		if ( empty( $_FILES['mvweb_rv_photo']['name'] ) ) {
			return;
		}

		$file = array_map( 'strval', wp_unslash( $_FILES['mvweb_rv_photo'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- individual values validated below.
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( ! isset( $file['error'], $file['size'], $file['tmp_name'], $file['name'] ) ) {
			return;
		}

		if ( UPLOAD_ERR_OK !== (int) $file['error'] || (int) $file['size'] > self::MAX_PHOTO_BYTES ) {
			return;
		}

		if ( ! is_uploaded_file( $file['tmp_name'] ) ) {
			return;
		}

		$checked = wp_check_filetype_and_ext( $file['tmp_name'], sanitize_file_name( $file['name'] ) );

		if ( ! in_array( (string) $checked['type'], array( 'image/jpeg', 'image/png', 'image/webp' ), true ) ) {
			return;
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$attachment_id = media_handle_upload(
			'mvweb_rv_photo',
			$post_id,
			array(),
			array(
				'test_form' => false,
				'mimes'     => array(
					'jpg|jpeg' => 'image/jpeg',
					'png'      => 'image/png',
					'webp'     => 'image/webp',
				),
			)
		);

		if ( ! is_wp_error( $attachment_id ) ) {
			set_post_thumbnail( $post_id, (int) $attachment_id );
		}
	}

	/**
	 * Remove attachments belonging to a deleted review.
	 *
	 * @since 1.0.0
	 * @param int $post_id Deleted post ID.
	 * @return void
	 */
	public static function delete_attachments( $post_id ): void {
		$post_id = (int) $post_id;

		if ( MVweb_RV_CPT::POST_TYPE !== get_post_type( $post_id ) ) {
			return;
		}

		$attachments = get_children(
			array(
				'post_parent' => $post_id,
				'post_type'   => 'attachment',
				'fields'      => 'ids',
			)
		);

		foreach ( (array) $attachments as $attachment_id ) {
			wp_delete_attachment( (int) $attachment_id, true );
		}
	}

	/**
	 * Whether the current IP is still under the submission limit.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	private static function within_ip_limit(): bool {
		$limit = (int) mvweb_rv_get_settings( 'ip_limit', 3 );

		if ( $limit < 1 ) {
			return true;
		}

		return (int) get_transient( self::ip_key() ) < $limit;
	}

	/**
	 * Increase the submission counter for the current IP.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function mark_ip(): void {
		$key   = self::ip_key();
		$count = (int) get_transient( $key );

		set_transient( $key, $count + 1, DAY_IN_SECONDS );
	}

	/**
	 * Transient key for the current visitor IP.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function ip_key(): string {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '0';

		return 'mvweb_rv_ip_' . md5( $ip );
	}

	/**
	 * Human readable error text.
	 *
	 * @since 1.0.0
	 * @param string $code Error code.
	 * @return string
	 */
	private static function error_message( string $code ): string {
		$messages = array(
			'nonce'   => __( 'The form has expired. Please reload the page and try again.', 'mvweb-reviews' ),
			'spam'    => __( 'The form was submitted too quickly. Please try again.', 'mvweb-reviews' ),
			'limit'   => __( 'You have already sent several reviews today. Please try again later.', 'mvweb-reviews' ),
			'empty'   => __( 'Please fill in your name and review text.', 'mvweb-reviews' ),
			'consent' => __( 'Please confirm the consent to personal data processing.', 'mvweb-reviews' ),
			'failed'  => __( 'The review could not be saved. Please try again later.', 'mvweb-reviews' ),
		);

		return $messages[ $code ] ?? $messages['failed'];
	}

	/**
	 * Redirect back with a status flag.
	 *
	 * @since 1.0.0
	 * @param string $status Status code.
	 * @return void
	 */
	private static function redirect( string $status ): void {
		$url = wp_get_referer();
		$url = $url ? $url : home_url( '/' );

		wp_safe_redirect( add_query_arg( 'mvweb_rv_sent', $status, remove_query_arg( 'mvweb_rv_sent', $url ) ) . '#mvwebRvForm' );
		exit;
	}
}
