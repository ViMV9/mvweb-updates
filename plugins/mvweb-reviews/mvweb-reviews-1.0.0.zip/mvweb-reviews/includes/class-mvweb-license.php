<?php
/**
 * MVweb License Client
 *
 * Reads the signed license verdict piggybacked on the plugin-update-checker
 * metadata response and exposes it as a blocked/not-blocked flag. Designed to
 * be bundled per-package like class-mvweb-menu.php and class-mvweb-updater.php,
 * so the class name carries no plugin prefix.
 *
 * @package MVweb\Shared
 * @since   1.0.0
 * @version 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( class_exists( 'MVweb_License' ) ) {
	return;
}

define( 'MVWEB_LICENSE_VERSION', '1.0.0' );

/**
 * Class MVweb_License
 *
 * Fail-open by construction: every read defaults to "not blocked", and a
 * verdict is only ever stored after its Ed25519 signature checks out.
 *
 * @since 1.0.0
 */
class MVweb_License {

	/**
	 * Ed25519 public key (raw 32 bytes, base64) for verifying the license
	 * verdict signed by the update gateway.
	 *
	 * Production key of the update gateway at mvweb-updates.mvweb.workers.dev.
	 * Its secret half lives only in that worker's secrets.
	 *
	 * @var string
	 */
	const PUBLIC_KEY_B64 = 'QgUKzJO2Effh65FAMBMVkmgACiZYJgmfJ4UAYy4MTvI=';

	/**
	 * Update gateway that serves metadata and signs the verdict.
	 *
	 * @var string
	 */
	const GATEWAY_URL = 'https://mvweb-updates.mvweb.workers.dev';

	/**
	 * Option holding the last verified verdict. autoload=false: read only on
	 * plugin admin screens and update checks, never on the front end.
	 *
	 * @var string
	 */
	const STATE_OPTION = 'mvweb_license_state';

	/**
	 * Option holding the fallback license key (wp-config's MVWEB_LICENSE_KEY
	 * constant takes precedence — see get_key()). autoload=false.
	 *
	 * @var string
	 */
	const KEY_OPTION = 'mvweb_license_key';

	/**
	 * Verdict codes that block admin-only actions. Every other code —
	 * including expired, missing, an empty code, or no verdict at all —
	 * leaves the plugin unrestricted.
	 *
	 * @var array<int, string>
	 */
	const BLOCKING_CODES = array( 'revoked', 'domain_mismatch' );

	/**
	 * Days without a successful verdict after which the cached one is reported
	 * as stale. The update checker runs twice a day, so three days means six
	 * missed checks in a row — past any transient network trouble.
	 *
	 * @var int
	 */
	const STALE_AFTER_DAYS = 3;

	/**
	 * Plugin slugs already wired to the update-checker filters, so a second
	 * MVweb_License::init() call for the same slug (e.g. a stray double
	 * bootstrap) does not register duplicate filters.
	 *
	 * @since 1.0.0
	 * @var array<int, string>
	 */
	private static array $wired_slugs = array();

	/**
	 * Hook into a package's plugin-update-checker instance.
	 *
	 * Filters are added by name rather than through the checker object, so
	 * this does not depend on which copy of MVweb_Updater loaded first.
	 *
	 * @since 1.0.0
	 * @param string $plugin_slug Slug the update checker was built with (e.g. 'mvweb-reviews').
	 * @param mixed  $updater     MVweb_Updater instance, so its checker can be pointed at the gateway.
	 * @return void
	 */
	public static function init( string $plugin_slug, $updater = null ): void {
		if ( '' === $plugin_slug || in_array( $plugin_slug, self::$wired_slugs, true ) ) {
			return;
		}

		self::$wired_slugs[] = $plugin_slug;

		add_filter( "puc_request_info_options-{$plugin_slug}", array( __CLASS__, 'add_headers' ) );
		add_filter( "puc_request_metadata_http_result-{$plugin_slug}", array( __CLASS__, 'read_verdict' ) );

		self::point_at_gateway( $plugin_slug, $updater );
	}

	/**
	 * Send this package's metadata request to the gateway.
	 *
	 * Every plugin bundles its own copy of MVweb_Updater and the first one
	 * loaded declares the class for the whole site, so a package cannot rely on
	 * its own copy holding the gateway address: on a site with several MVweb
	 * plugins the winning copy is usually somebody else's, still pointing at
	 * the old public server. Setting the URL on the checker instance instead
	 * makes this independent of which copy won — and of the fleet-wide
	 * migration, which lands package by package.
	 *
	 * @since 1.0.0
	 * @param string $plugin_slug Slug the update checker was built with.
	 * @param mixed  $updater     MVweb_Updater instance, or null to skip.
	 * @return void
	 */
	private static function point_at_gateway( string $plugin_slug, $updater ): void {
		if ( ! is_object( $updater ) || ! method_exists( $updater, 'get_update_checker' ) ) {
			return;
		}

		$checker = $updater->get_update_checker();

		if ( ! is_object( $checker ) || ! property_exists( $checker, 'metadataUrl' ) ) {
			return;
		}

		// phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- property name belongs to the plugin-update-checker library.
		$checker->metadataUrl = add_query_arg(
			array(
				'slug' => $plugin_slug,
				'type' => 'plugin',
			),
			self::GATEWAY_URL . '/v1/info'
		);
	}

	/**
	 * Add the license and domain headers to the update-checker's metadata request.
	 *
	 * Headers only — never appended to the query string, which the library
	 * echoes into its own error hooks and debug log.
	 *
	 * @since 1.0.0
	 * @param mixed $options wp_remote_get() options being filtered by the update checker.
	 * @return mixed
	 */
	public static function add_headers( $options ) {
		if ( ! is_array( $options ) ) {
			$options = array();
		}

		if ( ! isset( $options['headers'] ) || ! is_array( $options['headers'] ) ) {
			$options['headers'] = array();
		}

		$key = self::get_key();

		if ( '' !== $key ) {
			$options['headers']['X-MVweb-License'] = $key;
		}

		$domain = (string) wp_parse_url( home_url(), PHP_URL_HOST );

		if ( '' !== $domain ) {
			$options['headers']['X-MVweb-Domain'] = $domain;
		}

		return $options;
	}

	/**
	 * Read the license verdict out of the metadata HTTP response, if present.
	 *
	 * Returns $result unchanged either way — the update checker keeps parsing
	 * it as plain update metadata; our fields are simply additional JSON keys
	 * it never looks at.
	 *
	 * @since 1.0.0
	 * @param mixed $result wp_remote_get() result being filtered by the update checker.
	 * @return mixed
	 */
	public static function read_verdict( $result ) {
		if ( ! is_array( $result ) || ! isset( $result['body'] ) || ! is_string( $result['body'] ) || '' === $result['body'] ) {
			return $result;
		}

		$data = json_decode( $result['body'], true );

		if ( ! is_array( $data ) || ! isset( $data['license'] ) || ! is_array( $data['license'] ) ) {
			return $result;
		}

		$signature = isset( $data['license_sig'] ) && is_string( $data['license_sig'] ) ? $data['license_sig'] : '';

		self::store_state( $data['license'], $signature );

		return $result;
	}

	/**
	 * Read the license key: wp-config constant first, option fallback.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function get_key(): string {
		if ( self::has_config_key() ) {
			return MVWEB_LICENSE_KEY;
		}

		return (string) get_option( self::KEY_OPTION, '' );
	}

	/**
	 * Whether the key comes from wp-config rather than the option.
	 *
	 * Screens use this to hide the fallback field. It repeats get_key()'s own
	 * test on purpose: a constant defined as anything but a non-empty string
	 * (an unquoted number, say) is not a key there, and must not read as one
	 * here either — otherwise the field hides while no key is actually sent.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function has_config_key(): bool {
		return defined( 'MVWEB_LICENSE_KEY' ) && is_string( MVWEB_LICENSE_KEY ) && '' !== MVWEB_LICENSE_KEY;
	}

	/**
	 * Whether the cached verdict has gone unconfirmed for too long.
	 *
	 * False while no verdict has ever been confirmed — an install that never
	 * reached the server is "not confirmed yet", not "stale".
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function is_stale(): bool {
		$last_ok = self::get_state()['last_ok_at'];

		if ( '' === $last_ok ) {
			return false;
		}

		$timestamp = strtotime( $last_ok . ' UTC' );

		if ( false === $timestamp ) {
			return false;
		}

		return ( time() - $timestamp ) > ( self::STALE_AFTER_DAYS * DAY_IN_SECONDS );
	}

	/**
	 * Save the fallback license key. Only meaningful when MVWEB_LICENSE_KEY is
	 * not defined — get_key() ignores the option otherwise.
	 *
	 * @since 1.0.0
	 * @param string $key Raw license key.
	 * @return void
	 */
	public static function save_key( string $key ): void {
		update_option( self::KEY_OPTION, sanitize_text_field( $key ), false );
	}

	/**
	 * Current cached verdict, merged with defaults so every key is always set.
	 *
	 * @since 1.0.0
	 * @return array{status: string, code: string, checked_at: string, last_ok_at: string}
	 */
	public static function get_state(): array {
		$state = get_option( self::STATE_OPTION, array() );

		return is_array( $state ) ? array_merge( self::default_state(), $state ) : self::default_state();
	}

	/**
	 * Whether admin-only actions should be blocked right now.
	 *
	 * True only for a verdict that was actually verified: store_state() never
	 * writes a blocking code without a valid signature, so this needs no
	 * re-verification of its own.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function is_blocked(): bool {
		return in_array( self::verdict_code(), self::BLOCKING_CODES, true );
	}

	/**
	 * The verdict in one word, whichever field the gateway filled in.
	 *
	 * The gateway states the reason in "code" for some verdicts (revoked,
	 * domain_mismatch, expired) and only in "status" for others (missing),
	 * so reading a single field would silently miss half of them.
	 *
	 * @since 1.0.0
	 * @return string Empty while no verdict has been verified.
	 */
	public static function verdict_code(): string {
		$state = self::get_state();

		return '' !== $state['code'] ? $state['code'] : $state['status'];
	}

	/**
	 * Verify and persist a license verdict.
	 *
	 * Silently does nothing when the signature does not check out — including
	 * when sodium is unavailable. That is the point: an unverifiable verdict
	 * must never change plugin behaviour.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $license       The response's "license" object.
	 * @param string               $signature_b64 The response's "license_sig", base64.
	 * @return void
	 */
	public static function store_state( array $license, string $signature_b64 = '' ): void {
		if ( ! self::signature_valid( $license, $signature_b64 ) ) {
			return;
		}

		$state = self::get_state();
		$now   = current_time( 'mysql', true );

		$state['status']     = isset( $license['status'] ) ? sanitize_key( (string) $license['status'] ) : '';
		$state['code']       = isset( $license['code'] ) ? sanitize_key( (string) $license['code'] ) : '';
		$state['checked_at'] = $now;

		$verdict = '' !== $state['code'] ? $state['code'] : $state['status'];

		if ( ! in_array( $verdict, self::BLOCKING_CODES, true ) ) {
			$state['last_ok_at'] = $now;
		}

		update_option( self::STATE_OPTION, $state, false );
	}

	/**
	 * Default verdict shape, used until the first successful verified check.
	 *
	 * @since 1.0.0
	 * @return array{status: string, code: string, checked_at: string, last_ok_at: string}
	 */
	private static function default_state(): array {
		return array(
			'status'     => '',
			'code'       => '',
			'checked_at' => '',
			'last_ok_at' => '',
		);
	}

	/**
	 * Verify the Ed25519 signature over the license object.
	 *
	 * Canonical form is the server's own JSON.stringify() output: key order as
	 * sent, no whitespace, slashes and non-ASCII left unescaped. PHP escapes
	 * both by default, so the flags below are what make a signature produced by
	 * the gateway verifiable here at all — without them any domain holding a
	 * slash or a non-ASCII character (a .рф name, say) would never validate.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $license       The response's "license" object.
	 * @param string               $signature_b64 The response's "license_sig", base64.
	 * @return bool
	 */
	private static function signature_valid( array $license, string $signature_b64 ): bool {
		if ( '' === $signature_b64 || ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			return false;
		}

		$signature  = base64_decode( $signature_b64, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- decoding an Ed25519 signature, not obfuscation.
		$public_key = base64_decode( self::PUBLIC_KEY_B64, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- decoding an Ed25519 public key, not obfuscation.

		if ( false === $signature || false === $public_key ) {
			return false;
		}

		$payload = wp_json_encode( $license, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

		if ( false === $payload ) {
			return false;
		}

		try {
			return sodium_crypto_sign_verify_detached( $signature, $payload, $public_key );
		} catch ( \SodiumException $e ) {
			return false;
		}
	}
}
