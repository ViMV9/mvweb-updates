<?php
/**
 * Review details meta box.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renders and saves the review fields.
 *
 * @since 1.0.0
 */
class MVweb_RV_Metabox {

	private const NONCE = 'mvweb_rv_meta_nonce';

	/**
	 * Hook the meta box.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'add_meta_boxes', array( __CLASS__, 'register' ) );
		add_action( 'save_post_' . MVweb_RV_CPT::POST_TYPE, array( __CLASS__, 'save' ) );
	}

	/**
	 * Register the meta box.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_meta_box(
			'mvweb_rv_details',
			__( 'Review details', 'mvweb-reviews' ),
			array( __CLASS__, 'render' ),
			MVweb_RV_CPT::POST_TYPE,
			'normal',
			'high'
		);
	}

	/**
	 * Render the fields.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Current review.
	 * @return void
	 */
	public static function render( $post ): void {
		wp_nonce_field( 'mvweb_rv_save_meta', self::NONCE );

		$rating     = (int) get_post_meta( $post->ID, '_mvweb_rv_rating', true );
		$city       = (string) get_post_meta( $post->ID, '_mvweb_rv_city', true );
		$order      = (string) get_post_meta( $post->ID, '_mvweb_rv_order', true );
		$gallery    = (string) get_post_meta( $post->ID, '_mvweb_rv_gallery', true );
		$reply      = (string) get_post_meta( $post->ID, '_mvweb_rv_reply', true );
		$pinned     = (int) get_post_meta( $post->ID, '_mvweb_rv_pinned', true );
		$source     = (string) get_post_meta( $post->ID, '_mvweb_rv_source', true );
		$source_url = (string) get_post_meta( $post->ID, '_mvweb_rv_source_url', true );
		$contact    = (string) get_post_meta( $post->ID, '_mvweb_rv_contact', true );
		$consent    = (string) get_post_meta( $post->ID, '_mvweb_rv_consent', true );
		$scale      = (int) mvweb_rv_get_settings( 'scale', 5 );
		$source     = '' !== $source ? $source : 'manual';
		?>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><label for="mvweb_rv_rating"><?php esc_html_e( 'Rating', 'mvweb-reviews' ); ?></label></th>
				<td>
					<select id="mvweb_rv_rating" name="mvweb_rv_rating">
						<option value="0" <?php selected( $rating, 0 ); ?>><?php esc_html_e( '— no rating —', 'mvweb-reviews' ); ?></option>
						<?php for ( $i = $scale; $i >= 1; $i-- ) : ?>
							<option value="<?php echo esc_attr( (string) $i ); ?>" <?php selected( $rating, $i ); ?>>
								<?php echo esc_html( str_repeat( '★', $i ) . ' (' . $i . ')' ); ?>
							</option>
						<?php endfor; ?>
					</select>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="mvweb_rv_city"><?php esc_html_e( 'City', 'mvweb-reviews' ); ?></label></th>
				<td><input type="text" id="mvweb_rv_city" name="mvweb_rv_city" class="regular-text" value="<?php echo esc_attr( $city ); ?>"></td>
			</tr>
			<tr>
				<th scope="row"><label for="mvweb_rv_order"><?php esc_html_e( 'Ordered service', 'mvweb-reviews' ); ?></label></th>
				<td><input type="text" id="mvweb_rv_order" name="mvweb_rv_order" class="regular-text" value="<?php echo esc_attr( $order ); ?>"></td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Work photos', 'mvweb-reviews' ); ?></th>
				<td>
					<div class="mvweb-rv-gallery" data-gallery>
						<input type="hidden" id="mvweb_rv_gallery" name="mvweb_rv_gallery" value="<?php echo esc_attr( $gallery ); ?>">
						<div class="mvweb-rv-gallery__items" data-gallery-items>
							<?php foreach ( array_filter( array_map( 'absint', explode( ',', $gallery ) ) ) as $attachment_id ) : ?>
								<span class="mvweb-rv-gallery__item" data-id="<?php echo esc_attr( (string) $attachment_id ); ?>">
									<?php echo wp_get_attachment_image( $attachment_id, array( 80, 80 ) ); ?>
									<button type="button" class="mvweb-rv-gallery__remove" aria-label="<?php esc_attr_e( 'Remove image', 'mvweb-reviews' ); ?>">&times;</button>
								</span>
							<?php endforeach; ?>
						</div>
						<button type="button" class="button" data-gallery-add><?php esc_html_e( 'Add images', 'mvweb-reviews' ); ?></button>
					</div>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="mvweb_rv_reply"><?php esc_html_e( 'Company reply', 'mvweb-reviews' ); ?></label></th>
				<td>
					<textarea id="mvweb_rv_reply" name="mvweb_rv_reply" class="large-text" rows="3"><?php echo esc_textarea( $reply ); ?></textarea>
				</td>
			</tr>
			<tr>
				<th scope="row"><?php esc_html_e( 'Pin to top', 'mvweb-reviews' ); ?></th>
				<td>
					<label>
						<input type="checkbox" name="mvweb_rv_pinned" value="1" <?php checked( $pinned, 1 ); ?>>
						<?php esc_html_e( 'Always show this review first', 'mvweb-reviews' ); ?>
					</label>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="mvweb_rv_source"><?php esc_html_e( 'Source', 'mvweb-reviews' ); ?></label></th>
				<td>
					<select id="mvweb_rv_source" name="mvweb_rv_source">
						<?php foreach ( mvweb_rv_sources() as $key => $label ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $source, $key ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
					<p class="description"><?php esc_html_e( 'Imported reviews keep the original publication date and a link to the source.', 'mvweb-reviews' ); ?></p>
				</td>
			</tr>
			<tr>
				<th scope="row"><label for="mvweb_rv_source_url"><?php esc_html_e( 'Source URL', 'mvweb-reviews' ); ?></label></th>
				<td><input type="url" id="mvweb_rv_source_url" name="mvweb_rv_source_url" class="regular-text" value="<?php echo esc_attr( $source_url ); ?>"></td>
			</tr>
			<?php if ( '' !== $contact || '' !== $consent ) : ?>
				<tr>
					<th scope="row"><?php esc_html_e( 'Submitted data', 'mvweb-reviews' ); ?></th>
					<td>
						<?php if ( '' !== $contact ) : ?>
							<p><strong><?php esc_html_e( 'Contact:', 'mvweb-reviews' ); ?></strong> <?php echo esc_html( $contact ); ?>
								<em><?php esc_html_e( '(never shown on the site)', 'mvweb-reviews' ); ?></em></p>
						<?php endif; ?>
						<?php if ( '' !== $consent ) : ?>
							<p><strong><?php esc_html_e( 'Consent given:', 'mvweb-reviews' ); ?></strong> <?php echo esc_html( $consent ); ?></p>
						<?php endif; ?>
					</td>
				</tr>
			<?php endif; ?>
		</table>
		<?php
	}

	/**
	 * Persist submitted fields.
	 *
	 * @since 1.0.0
	 * @param int $post_id Review ID.
	 * @return void
	 */
	public static function save( $post_id ): void {
		$post_id = (int) $post_id;

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( wp_is_post_revision( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$nonce = isset( $_POST[ self::NONCE ] ) ? sanitize_text_field( wp_unslash( $_POST[ self::NONCE ] ) ) : '';

		if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'mvweb_rv_save_meta' ) ) {
			return;
		}

		$fields = array(
			'_mvweb_rv_rating'     => isset( $_POST['mvweb_rv_rating'] ) ? absint( wp_unslash( $_POST['mvweb_rv_rating'] ) ) : 0,
			'_mvweb_rv_city'       => isset( $_POST['mvweb_rv_city'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_rv_city'] ) ) : '',
			'_mvweb_rv_order'      => isset( $_POST['mvweb_rv_order'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_rv_order'] ) ) : '',
			'_mvweb_rv_gallery'    => isset( $_POST['mvweb_rv_gallery'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_rv_gallery'] ) ) : '',
			'_mvweb_rv_reply'      => isset( $_POST['mvweb_rv_reply'] ) ? wp_kses_post( wp_unslash( $_POST['mvweb_rv_reply'] ) ) : '',
			'_mvweb_rv_pinned'     => isset( $_POST['mvweb_rv_pinned'] ) ? 1 : 0,
			'_mvweb_rv_source'     => isset( $_POST['mvweb_rv_source'] ) ? sanitize_key( wp_unslash( $_POST['mvweb_rv_source'] ) ) : 'manual',
			'_mvweb_rv_source_url' => isset( $_POST['mvweb_rv_source_url'] ) ? esc_url_raw( wp_unslash( $_POST['mvweb_rv_source_url'] ) ) : '',
		);

		$meta_fields = MVweb_RV_CPT::meta_fields();

		foreach ( $fields as $key => $value ) {
			$value = call_user_func( $meta_fields[ $key ]['sanitize'], $value );

			update_post_meta( $post_id, $key, $value );
		}
	}
}
