<?php
/**
 * Shortcodes and front-end assets.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers [mvweb_reviews] and [mvweb_review_form].
 *
 * @since 1.0.0
 */
class MVweb_RV_Shortcode {

	/**
	 * Hook shortcodes and assets.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
		add_shortcode( 'mvweb_reviews', array( __CLASS__, 'reviews' ) );
		add_shortcode( 'mvweb_review_form', array( 'MVweb_RV_Form', 'shortcode' ) );
	}

	/**
	 * Cache-busting version for a bundled asset: its mtime, so a hotfix
	 * shipped without a version bump still reaches visitors.
	 *
	 * @since 1.0.0
	 * @param string $relative_path Asset path relative to the plugin root.
	 * @return string
	 */
	private static function asset_version( string $relative_path ): string {
		$path = MVWEB_RV_PATH . $relative_path;

		return file_exists( $path ) ? (string) filemtime( $path ) : MVWEB_RV_VERSION;
	}

	/**
	 * Register the front-end stylesheet and script.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_assets(): void {
		$suffix = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';
		$style  = 'public/css/public' . $suffix . '.css';
		$script = 'public/js/public' . $suffix . '.js';

		wp_register_style(
			'mvweb-rv',
			MVWEB_RV_URL . $style,
			array(),
			self::asset_version( $style )
		);

		wp_register_script(
			'mvweb-rv',
			MVWEB_RV_URL . $script,
			array(),
			self::asset_version( $script ),
			true
		);

		wp_localize_script(
			'mvweb-rv',
			'mvwebRvData',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'i18n'    => array(
					'readFull'  => __( 'Read in full', 'mvweb-reviews' ),
					'collapse'  => __( 'Collapse', 'mvweb-reviews' ),
					'loading'   => __( 'Loading…', 'mvweb-reviews' ),
					'closeText' => __( 'Close', 'mvweb-reviews' ),
				),
			)
		);
	}

	/**
	 * Enqueue assets for a rendered block.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function enqueue(): void {
		wp_enqueue_style( 'mvweb-rv' );
		wp_enqueue_script( 'mvweb-rv' );
	}

	/**
	 * Normalize shortcode attributes against saved settings.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed>|string $atts Raw attributes.
	 * @return array<string, mixed>
	 */
	public static function normalize( $atts ): array {
		$settings = mvweb_rv_get_settings();

		$atts = shortcode_atts(
			array(
				'layout'       => $settings['layout'],
				'group'        => '',
				'limit'        => $settings['limit'],
				'offset'       => 0,
				'rating_min'   => 0,
				'order'        => $settings['order'],
				'show_rating'  => $settings['show_rating'],
				'show_photo'   => $settings['show_photo'],
				'show_date'    => $settings['show_date'],
				'show_city'    => $settings['show_city'],
				'show_order'   => $settings['show_order'],
				'show_summary' => $settings['show_summary'],
				'card_min'     => $settings['card_min'],
				'clamp_lines'  => $settings['clamp_lines'],
				'bg'           => $settings['bg'],
				'border'       => $settings['border'],
				'radius'       => $settings['radius'],
				'class'        => '',
			),
			is_array( $atts ) ? $atts : array(),
			'mvweb_reviews'
		);

		$layout = sanitize_key( (string) $atts['layout'] );
		$order  = sanitize_key( (string) $atts['order'] );

		return array(
			'layout'       => array_key_exists( $layout, mvweb_rv_layouts() ) ? $layout : 'grid',
			'group'        => sanitize_text_field( (string) $atts['group'] ),
			'limit'        => max( 1, min( 100, (int) $atts['limit'] ) ),
			'offset'       => max( 0, (int) $atts['offset'] ),
			'rating_min'   => max( 0, min( 10, (int) $atts['rating_min'] ) ),
			'order'        => array_key_exists( $order, mvweb_rv_orders() ) ? $order : 'date',
			'show_rating'  => (int) wp_validate_boolean( $atts['show_rating'] ),
			'show_photo'   => (int) wp_validate_boolean( $atts['show_photo'] ),
			'show_date'    => (int) wp_validate_boolean( $atts['show_date'] ),
			'show_city'    => (int) wp_validate_boolean( $atts['show_city'] ),
			'show_order'   => (int) wp_validate_boolean( $atts['show_order'] ),
			'show_summary' => (int) wp_validate_boolean( $atts['show_summary'] ),
			'card_min'     => max( 180, min( 640, (int) $atts['card_min'] ) ),
			'clamp_lines'  => max( 2, min( 40, (int) $atts['clamp_lines'] ) ),
			'bg'           => (string) sanitize_hex_color( (string) $atts['bg'] ),
			'border'       => (string) sanitize_hex_color( (string) $atts['border'] ),
			'radius'       => max( 0, min( 40, (int) $atts['radius'] ) ),
			'star_color'   => (string) sanitize_hex_color( (string) $settings['star_color'] ),
			'scale'        => 10 === (int) $settings['scale'] ? 10 : 5,
			'class'        => sanitize_text_field( (string) $atts['class'] ),
		);
	}

	/**
	 * Render the [mvweb_reviews] shortcode.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed>|string $atts Shortcode attributes.
	 * @return string
	 */
	public static function reviews( $atts ): string {
		$args = self::normalize( $atts );

		self::enqueue();

		if ( ! mvweb_rv_get_settings( 'cache_enabled' ) ) {
			return MVweb_RV_Render::block( $args );
		}

		$key    = 'mvweb_rv_html_' . mvweb_rv_cache_version() . '_' . md5( (string) wp_json_encode( $args ) );
		$cached = get_transient( $key );

		if ( is_array( $cached ) && isset( $cached['html'], $cached['ids'] ) ) {
			MVweb_RV_Render::track( (array) $cached['ids'] );

			if ( ! empty( $cached['summary'] ) ) {
				MVweb_RV_Render::mark_summary_shown();
			}

			return (string) $cached['html'];
		}

		$html = MVweb_RV_Render::block( $args );

		if ( 'rand' !== $args['order'] ) {
			set_transient(
				$key,
				array(
					'html'    => $html,
					'ids'     => MVweb_RV_Render::last_ids(),
					'summary' => MVweb_RV_Render::last_summary(),
				),
				DAY_IN_SECONDS
			);
		}

		return $html;
	}
}
