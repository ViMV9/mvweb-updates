<?php
/**
 * Front-end rendering of review blocks.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds the HTML for every layout.
 *
 * @since 1.0.0
 */
class MVweb_RV_Render {

	/**
	 * Review IDs rendered during this request.
	 *
	 * @since 1.0.0
	 * @var array<int>
	 */
	private static array $rendered = array();

	/**
	 * Review IDs of the block rendered last.
	 *
	 * @since 1.0.0
	 * @var array<int>
	 */
	private static array $last = array();

	/**
	 * IDs rendered so far, used by the schema generator.
	 *
	 * @since 1.0.0
	 * @return array<int>
	 */
	public static function rendered_ids(): array {
		return array_values( array_unique( self::$rendered ) );
	}

	/**
	 * Whether a visible summary rating block was printed on this page.
	 *
	 * @since 1.0.0
	 * @var bool
	 */
	private static bool $summary_shown = false;

	/**
	 * Whether the block rendered last printed a summary.
	 *
	 * @since 1.0.0
	 * @var bool
	 */
	private static bool $last_summary = false;

	/**
	 * IDs of the most recently rendered block.
	 *
	 * @since 1.0.0
	 * @return array<int>
	 */
	public static function last_ids(): array {
		return self::$last;
	}

	/**
	 * Whether the page shows a summary rating the markup may repeat.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function summary_shown(): bool {
		return self::$summary_shown;
	}

	/**
	 * Whether the block rendered last printed a summary, for the cache entry.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function last_summary(): bool {
		return self::$last_summary;
	}

	/**
	 * Remember that a cached block already contained a summary.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function mark_summary_shown(): void {
		self::$summary_shown = true;
	}

	/**
	 * Render a full review block.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $args Normalized attributes.
	 * @return string
	 */
	public static function block( array $args ): string {
		self::$last         = array();
		self::$last_summary = false;

		$query = MVweb_RV_Query::get( $args );

		if ( ! $query->have_posts() ) {
			return '';
		}

		$ids = wp_list_pluck( $query->posts, 'ID' );
		$ids = array_map( 'intval', $ids );

		self::$rendered = array_merge( self::$rendered, $ids );
		self::$last     = $ids;

		$layout    = (string) $args['layout'];
		$total     = (int) $query->found_posts;
		$shown     = count( $ids ) + (int) $args['offset'];
		$aggregate = MVweb_RV_Query::aggregate( $ids );

		if ( $args['show_summary'] && $aggregate['count'] > 0 ) {
			self::$summary_shown = true;
			self::$last_summary  = true;
		}

		$classes = array( 'mvwebRv', 'mvwebRv--' . $layout );

		if ( '' !== (string) $args['class'] ) {
			$classes[] = sanitize_html_class( (string) $args['class'] );
		}

		ob_start();
		?>
		<div class="<?php echo esc_attr( implode( ' ', $classes ) ); ?>" style="<?php echo esc_attr( self::style_vars( $args ) ); ?>">
			<?php if ( $args['show_summary'] && $aggregate['count'] > 0 ) : ?>
				<?php echo self::summary( $aggregate, $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?>
			<?php endif; ?>

			<?php if ( 'carousel' === $layout ) : ?>
				<div class="mvwebRv__viewport">
					<button type="button" class="mvwebRv__nav mvwebRv__nav--prev" aria-label="<?php esc_attr_e( 'Previous review', 'mvweb-reviews' ); ?>">&#8249;</button>
					<div class="mvwebRv__items" data-track>
						<?php echo self::items( $ids, $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?>
					</div>
					<button type="button" class="mvwebRv__nav mvwebRv__nav--next" aria-label="<?php esc_attr_e( 'Next review', 'mvweb-reviews' ); ?>">&#8250;</button>
				</div>
				<div class="mvwebRv__dots" data-dots></div>
			<?php else : ?>
				<div class="mvwebRv__items" data-items>
					<?php echo self::items( $ids, $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?>
				</div>
			<?php endif; ?>

			<?php if ( 'carousel' !== $layout && 'rand' !== $args['order'] && $shown < $total ) : ?>
				<div class="mvwebRv__more">
					<button type="button"
						class="mvwebRv__moreBtn"
						data-more
						data-args="<?php echo esc_attr( (string) wp_json_encode( $args ) ); ?>"
						data-offset="<?php echo esc_attr( (string) $shown ); ?>"
						data-nonce="<?php echo esc_attr( wp_create_nonce( 'mvweb_rv_more' ) ); ?>">
						<?php esc_html_e( 'Show more', 'mvweb-reviews' ); ?>
					</button>
				</div>
			<?php endif; ?>
		</div>
		<?php
		wp_reset_postdata();

		return trim( (string) ob_get_clean() );
	}

	/**
	 * Render review items only.
	 *
	 * @since 1.0.0
	 * @param array<int>           $ids  Review IDs.
	 * @param array<string, mixed> $args Normalized attributes.
	 * @return string
	 */
	public static function items( array $ids, array $args ): string {
		$html = '';

		foreach ( $ids as $post_id ) {
			$html .= 'accordion' === $args['layout']
				? self::accordion_item( (int) $post_id, $args )
				: self::card( (int) $post_id, $args );
		}

		return $html;
	}

	/**
	 * Track IDs loaded over AJAX.
	 *
	 * @since 1.0.0
	 * @param array<int> $ids Review IDs.
	 * @return void
	 */
	public static function track( array $ids ): void {
		self::$rendered = array_merge( self::$rendered, array_map( 'intval', $ids ) );
	}

	/**
	 * Inline CSS custom properties for the block.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $args Normalized attributes.
	 * @return string
	 */
	private static function style_vars( array $args ): string {
		$vars = array(
			'--mvwebRvCardMin' => (int) $args['card_min'] . 'px',
			'--mvwebRvClamp'   => (string) (int) $args['clamp_lines'],
			'--mvwebRvRadius'  => (int) $args['radius'] . 'px',
			'--mvwebRvStar'    => (string) $args['star_color'],
		);

		if ( '' !== (string) $args['bg'] ) {
			$vars['--mvwebRvBg'] = (string) $args['bg'];
		}

		if ( '' !== (string) $args['border'] ) {
			$vars['--mvwebRvBorder'] = (string) $args['border'];
		}

		$style = '';

		foreach ( $vars as $name => $value ) {
			$style .= $name . ':' . $value . ';';
		}

		return $style;
	}

	/**
	 * Aggregate rating block.
	 *
	 * @since 1.0.0
	 * @param array{value: float, count: int} $aggregate Aggregated rating.
	 * @param array<string, mixed>            $args      Normalized attributes.
	 * @return string
	 */
	private static function summary( array $aggregate, array $args ): string {
		$scale = (int) $args['scale'];

		ob_start();
		?>
		<div class="mvwebRv__summary">
			<span class="mvwebRv__summaryValue"><?php echo esc_html( mvweb_rv_format_rating( $aggregate['value'] ) ); ?></span>
			<span class="mvwebRv__summaryScale"><?php echo esc_html( sprintf( /* translators: %d: rating scale maximum. */ __( 'out of %d', 'mvweb-reviews' ), $scale ) ); ?></span>
			<span class="mvwebRv__stars" aria-hidden="true"><?php echo self::stars( (int) round( $aggregate['value'] ), $scale ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?></span>
			<span class="mvwebRv__summaryCount">
				<?php
				printf(
					esc_html(
						/* translators: %s: number of reviews. */
						_n( '%s review', '%s reviews', $aggregate['count'], 'mvweb-reviews' )
					),
					esc_html( number_format_i18n( $aggregate['count'] ) )
				);
				?>
			</span>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Star row markup.
	 *
	 * @since 1.0.0
	 * @param int $rating Rating value.
	 * @param int $scale  Maximum rating.
	 * @return string
	 */
	private static function stars( int $rating, int $scale ): string {
		$html = '';

		for ( $i = 1; $i <= $scale; $i++ ) {
			$class = $i <= $rating ? 'mvwebRv__star mvwebRv__star--on' : 'mvwebRv__star';
			$html .= '<span class="' . esc_attr( $class ) . '">★</span>';
		}

		return $html;
	}

	/**
	 * Author avatar or initials placeholder.
	 *
	 * @since 1.0.0
	 * @param int    $post_id Review ID.
	 * @param string $name    Author name.
	 * @return string
	 */
	private static function avatar( int $post_id, string $name ): string {
		if ( has_post_thumbnail( $post_id ) ) {
			return get_the_post_thumbnail(
				$post_id,
				'thumbnail',
				array(
					'class'   => 'mvwebRv__photo',
					'alt'     => $name,
					'loading' => 'lazy',
				)
			);
		}

		return '<span class="mvwebRv__photo mvwebRv__photo--initials" aria-hidden="true">' . esc_html( mvweb_rv_initials( $name ) ) . '</span>';
	}

	/**
	 * Meta line under the author name.
	 *
	 * @since 1.0.0
	 * @param int                  $post_id Review ID.
	 * @param array<string, mixed> $args    Normalized attributes.
	 * @return string
	 */
	private static function meta_line( int $post_id, array $args ): string {
		$parts = array();

		if ( $args['show_city'] ) {
			$city = (string) get_post_meta( $post_id, '_mvweb_rv_city', true );

			if ( '' !== $city ) {
				$parts[] = esc_html( $city );
			}
		}

		if ( $args['show_date'] ) {
			$parts[] = '<time datetime="' . esc_attr( (string) get_the_date( 'c', $post_id ) ) . '">' . esc_html( (string) get_the_date( '', $post_id ) ) . '</time>';
		}

		if ( empty( $parts ) ) {
			return '';
		}

		return '<div class="mvwebRv__metaLine">' . implode( '<span class="mvwebRv__sep">·</span>', $parts ) . '</div>';
	}

	/**
	 * Review text with clamp and toggle.
	 *
	 * @since 1.0.0
	 * @param int $post_id Review ID.
	 * @return string
	 */
	private static function text( int $post_id ): string {
		$content = (string) get_post_field( 'post_content', $post_id );
		$content = wpautop( wp_kses_post( $content ) );

		return '<div class="mvwebRv__text" data-text>' . $content . '</div>'
			. '<button type="button" class="mvwebRv__toggle" data-toggle hidden>' . esc_html__( 'Read in full', 'mvweb-reviews' ) . '</button>';
	}

	/**
	 * Work photos gallery.
	 *
	 * @since 1.0.0
	 * @param int $post_id Review ID.
	 * @return string
	 */
	private static function gallery( int $post_id ): string {
		$raw = (string) get_post_meta( $post_id, '_mvweb_rv_gallery', true );
		$ids = array_filter( array_map( 'absint', explode( ',', $raw ) ) );

		if ( empty( $ids ) ) {
			return '';
		}

		$html = '<div class="mvwebRv__gallery">';

		foreach ( $ids as $attachment_id ) {
			$full  = wp_get_attachment_image_url( $attachment_id, 'large' );
			$thumb = wp_get_attachment_image( $attachment_id, 'thumbnail', false, array( 'loading' => 'lazy' ) );

			if ( ! $full || ! $thumb ) {
				continue;
			}

			$html .= '<button type="button" class="mvwebRv__thumb" data-lightbox="' . esc_url( $full ) . '">' . $thumb . '</button>';
		}

		return $html . '</div>';
	}

	/**
	 * Company reply block.
	 *
	 * @since 1.0.0
	 * @param int $post_id Review ID.
	 * @return string
	 */
	private static function reply( int $post_id ): string {
		$reply = (string) get_post_meta( $post_id, '_mvweb_rv_reply', true );

		if ( '' === trim( $reply ) ) {
			return '';
		}

		return '<div class="mvwebRv__reply">'
			. '<span class="mvwebRv__replyLabel">' . esc_html__( 'Company reply', 'mvweb-reviews' ) . '</span>'
			. wpautop( wp_kses_post( $reply ) )
			. '</div>';
	}

	/**
	 * Source badge with an optional link.
	 *
	 * @since 1.0.0
	 * @param int $post_id Review ID.
	 * @return string
	 */
	private static function source( int $post_id ): string {
		$source = (string) get_post_meta( $post_id, '_mvweb_rv_source', true );

		if ( '' === $source || in_array( $source, array( 'manual', 'site_form' ), true ) ) {
			return '';
		}

		$labels = mvweb_rv_sources();
		$label  = $labels[ $source ] ?? $source;
		$url    = (string) get_post_meta( $post_id, '_mvweb_rv_source_url', true );
		$text   = sprintf( /* translators: %s: source name. */ esc_html__( 'Source: %s', 'mvweb-reviews' ), $label );

		if ( '' !== $url ) {
			return '<a class="mvwebRv__source" href="' . esc_url( $url ) . '" rel="nofollow noopener" target="_blank">' . esc_html( $text ) . '</a>';
		}

		return '<span class="mvwebRv__source">' . esc_html( $text ) . '</span>';
	}

	/**
	 * Card markup for grid, carousel and list layouts.
	 *
	 * @since 1.0.0
	 * @param int                  $post_id Review ID.
	 * @param array<string, mixed> $args    Normalized attributes.
	 * @return string
	 */
	private static function card( int $post_id, array $args ): string {
		$name   = (string) get_the_title( $post_id );
		$rating = (int) get_post_meta( $post_id, '_mvweb_rv_rating', true );
		$order  = (string) get_post_meta( $post_id, '_mvweb_rv_order', true );

		ob_start();
		?>
		<article class="mvwebRv__card">
			<header class="mvwebRv__head">
				<?php if ( $args['show_photo'] ) : ?>
					<?php echo self::avatar( $post_id, $name ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?>
				<?php endif; ?>
				<div class="mvwebRv__author">
					<span class="mvwebRv__name"><?php echo esc_html( $name ); ?></span>
					<?php echo self::meta_line( $post_id, $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?>
				</div>
				<?php if ( $args['show_rating'] && $rating > 0 ) : ?>
					<span class="mvwebRv__stars" aria-label="<?php echo esc_attr( sprintf( /* translators: 1: rating, 2: scale. */ __( 'Rated %1$d out of %2$d', 'mvweb-reviews' ), $rating, (int) $args['scale'] ) ); ?>">
						<?php echo self::stars( $rating, (int) $args['scale'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?>
					</span>
				<?php endif; ?>
			</header>

			<?php if ( $args['show_order'] && '' !== $order ) : ?>
				<div class="mvwebRv__order"><?php echo esc_html( $order ); ?></div>
			<?php endif; ?>

			<?php
			echo self::text( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
			echo self::gallery( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
			echo self::reply( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
			echo self::source( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
			?>
		</article>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Accordion item markup.
	 *
	 * @since 1.0.0
	 * @param int                  $post_id Review ID.
	 * @param array<string, mixed> $args    Normalized attributes.
	 * @return string
	 */
	private static function accordion_item( int $post_id, array $args ): string {
		$name   = (string) get_the_title( $post_id );
		$rating = (int) get_post_meta( $post_id, '_mvweb_rv_rating', true );

		ob_start();
		?>
		<details class="mvwebRv__item">
			<summary class="mvwebRv__summaryRow">
				<?php if ( $args['show_photo'] ) : ?>
					<?php echo self::avatar( $post_id, $name ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?>
				<?php endif; ?>
				<span class="mvwebRv__name"><?php echo esc_html( $name ); ?></span>
				<?php if ( $args['show_rating'] && $rating > 0 ) : ?>
					<span class="mvwebRv__stars"><?php echo self::stars( $rating, (int) $args['scale'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?></span>
				<?php endif; ?>
			</summary>
			<div class="mvwebRv__body">
				<?php echo self::meta_line( $post_id, $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?>
				<div class="mvwebRv__text"><?php echo wpautop( wp_kses_post( (string) get_post_field( 'post_content', $post_id ) ) ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- kses applied. ?></div>
				<?php
				echo self::gallery( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
				echo self::reply( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
				echo self::source( $post_id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside.
				?>
			</div>
		</details>
		<?php
		return (string) ob_get_clean();
	}
}
