<?php
/**
 * Helper functions for MVweb Reviews.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default plugin settings.
 *
 * @since 1.0.0
 * @return array<string, mixed>
 */
function mvweb_rv_default_settings(): array {
	return array(
		'layout'         => 'grid',
		'limit'          => 6,
		'order'          => 'date',
		'scale'          => 5,
		'show_rating'    => 1,
		'show_photo'     => 1,
		'show_date'      => 1,
		'show_city'      => 1,
		'show_order'     => 1,
		'show_summary'   => 1,
		'card_min'       => 300,
		'clamp_lines'    => 6,
		'bg'             => '',
		'border'         => '',
		'radius'         => 12,
		'star_color'     => '#f7c917',
		'form_enabled'   => 1,
		'form_contact'   => 1,
		'form_photo'     => 1,
		'form_consent'   => 1,
		'consent_url'    => '',
		'min_fill_time'  => 5,
		'ip_limit'       => 3,
		'schema_enabled' => 1,
		'schema_type'    => 'LocalBusiness',
		'cache_enabled'  => 1,
	);
}

/**
 * Get plugin settings merged with defaults.
 *
 * @since 1.0.0
 * @param string|null $key      Optional setting key.
 * @param mixed       $fallback Value returned when the key is missing.
 * @return mixed
 */
function mvweb_rv_get_settings( ?string $key = null, $fallback = null ) {
	$settings = get_option( 'mvweb_rv_settings', array() );
	$settings = is_array( $settings ) ? $settings : array();
	$settings = array_merge( mvweb_rv_default_settings(), $settings );

	if ( null === $key ) {
		return $settings;
	}

	return $settings[ $key ] ?? $fallback;
}

/**
 * Available layouts.
 *
 * @since 1.0.0
 * @return array<string, string>
 */
function mvweb_rv_layouts(): array {
	return array(
		'grid'      => __( 'Cards grid', 'mvweb-reviews' ),
		'carousel'  => __( 'Carousel', 'mvweb-reviews' ),
		'list'      => __( 'Single column list', 'mvweb-reviews' ),
		'accordion' => __( 'Compact accordion', 'mvweb-reviews' ),
	);
}

/**
 * Available review sources.
 *
 * @since 1.0.0
 * @return array<string, string>
 */
function mvweb_rv_sources(): array {
	return array(
		'manual'    => __( 'Added by admin', 'mvweb-reviews' ),
		'site_form' => __( 'Site form', 'mvweb-reviews' ),
		'yandex'    => __( 'Yandex Maps', 'mvweb-reviews' ),
		'google'    => __( 'Google', 'mvweb-reviews' ),
	);
}

/**
 * Curated schema.org business types offered as presets for the JSON-LD tab.
 *
 * Real schema.org subtypes of LocalBusiness (verified against schema.org's
 * HomeAndConstructionBusiness, AutomotiveBusiness and Store type pages), picked
 * for the verticals MVweb builds sites for: construction/home services,
 * automotive repair and electronics/phone retail. "Other" stays free text.
 *
 * @since 1.0.0
 * @return array<string, string>
 */
function mvweb_rv_schema_types(): array {
	return array(
		'LocalBusiness'               => __( 'LocalBusiness — universal type, fits any business', 'mvweb-reviews' ),
		'HomeAndConstructionBusiness' => __( 'HomeAndConstructionBusiness — building, renovation, maintenance', 'mvweb-reviews' ),
		'GeneralContractor'           => __( 'GeneralContractor — general construction contractor', 'mvweb-reviews' ),
		'Electrician'                 => __( 'Electrician — electrical work', 'mvweb-reviews' ),
		'Plumber'                     => __( 'Plumber — plumbing work', 'mvweb-reviews' ),
		'HVACBusiness'                => __( 'HVACBusiness — heating, ventilation, air conditioning', 'mvweb-reviews' ),
		'RoofingContractor'           => __( 'RoofingContractor — roofing work', 'mvweb-reviews' ),
		'HousePainter'                => __( 'HousePainter — painting work', 'mvweb-reviews' ),
		'Locksmith'                   => __( 'Locksmith — locksmith services', 'mvweb-reviews' ),
		'MovingCompany'               => __( 'MovingCompany — moving and relocation', 'mvweb-reviews' ),
		'AutomotiveBusiness'          => __( 'AutomotiveBusiness — general automotive business', 'mvweb-reviews' ),
		'AutoRepair'                  => __( 'AutoRepair — car repair shop', 'mvweb-reviews' ),
		'AutoBodyShop'                => __( 'AutoBodyShop — auto body repair', 'mvweb-reviews' ),
		'Store'                       => __( 'Store — general retail store', 'mvweb-reviews' ),
		'ElectronicsStore'            => __( 'ElectronicsStore — electronics retail', 'mvweb-reviews' ),
		'MobilePhoneStore'            => __( 'MobilePhoneStore — mobile phone sales and service', 'mvweb-reviews' ),
		'ProfessionalService'         => __( 'ProfessionalService — professional and consulting services', 'mvweb-reviews' ),
	);
}

/**
 * Available ordering modes.
 *
 * @since 1.0.0
 * @return array<string, string>
 */
function mvweb_rv_orders(): array {
	return array(
		'date'       => __( 'Newest first', 'mvweb-reviews' ),
		'rating'     => __( 'Highest rating first', 'mvweb-reviews' ),
		'rand'       => __( 'Random', 'mvweb-reviews' ),
		'menu_order' => __( 'Manual order', 'mvweb-reviews' ),
	);
}

/**
 * Build initials for the avatar placeholder.
 *
 * @since 1.0.0
 * @param string $name Author name.
 * @return string
 */
function mvweb_rv_initials( string $name ): string {
	$parts    = preg_split( '/\s+/u', trim( $name ) );
	$parts    = is_array( $parts ) ? $parts : array();
	$initials = '';

	foreach ( array_slice( $parts, 0, 2 ) as $part ) {
		$first = mb_substr( $part, 0, 1, 'UTF-8' );

		if ( '' !== $first ) {
			$initials .= mb_strtoupper( $first, 'UTF-8' );
		}
	}

	return '' !== $initials ? $initials : '—';
}

/**
 * Capability required to moderate reviews.
 *
 * @since 1.0.0
 * @return string
 */
function mvweb_rv_moderate_cap(): string {
	return (string) apply_filters( 'mvweb_rv_moderate_cap', 'edit_posts' );
}

/**
 * Format a rating value for output.
 *
 * @since 1.0.0
 * @param float $rating Rating value.
 * @return string
 */
function mvweb_rv_format_rating( float $rating ): string {
	$decimals = ( floor( $rating ) === $rating ) ? 0 : 1;

	return number_format_i18n( round( $rating, 1 ), $decimals );
}

/**
 * Current cache generation, part of every cached fragment key.
 *
 * @since 1.0.0
 * @return int
 */
function mvweb_rv_cache_version(): int {
	return max( 1, (int) get_option( 'mvweb_rv_cache_version', 1 ) );
}

/**
 * Invalidate every cached shortcode fragment.
 *
 * The generation counter is bumped instead of deleting transients one by one:
 * with a persistent object cache transients never reach the options table, so
 * they cannot be enumerated there. Stale entries expire on their own.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_rv_flush_cache(): void {
	update_option( 'mvweb_rv_cache_version', mvweb_rv_cache_version() + 1, false );
	delete_transient( 'mvweb_rv_pending_count' );
}
