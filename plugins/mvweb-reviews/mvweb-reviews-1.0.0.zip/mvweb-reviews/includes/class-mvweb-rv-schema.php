<?php
/**
 * JSON-LD output for rendered reviews.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Emits Review and AggregateRating data once per request.
 *
 * @since 1.0.0
 */
class MVweb_RV_Schema {

	/**
	 * Hook the footer output.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'wp_footer', array( __CLASS__, 'output' ), 20 );
	}

	/**
	 * Print the JSON-LD block for reviews rendered on this page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function output(): void {
		if ( ! mvweb_rv_get_settings( 'schema_enabled' ) || is_admin() ) {
			return;
		}

		$ids = MVweb_RV_Render::rendered_ids();

		if ( empty( $ids ) ) {
			return;
		}

		$reviews = array();

		foreach ( $ids as $post_id ) {
			$review = self::review_node( (int) $post_id );

			if ( ! empty( $review ) ) {
				$reviews[] = $review;
			}
		}

		if ( empty( $reviews ) ) {
			return;
		}

		$node = array(
			'@type' => self::entity_type(),
			'@id'   => self::entity_id(),
		);

		if ( ! self::seo_plugin_active() ) {
			$node['name'] = get_bloginfo( 'name' );
			$node['url']  = home_url( '/' );
		}

		$aggregate = MVweb_RV_Query::aggregate( $ids );

		if ( $aggregate['count'] > 0 && MVweb_RV_Render::summary_shown() ) {
			$node['aggregateRating'] = array(
				'@type'       => 'AggregateRating',
				'ratingValue' => round( $aggregate['value'], 1 ),
				'reviewCount' => $aggregate['count'],
				'bestRating'  => (int) mvweb_rv_get_settings( 'scale', 5 ),
				'worstRating' => 1,
			);
		}

		$node['review'] = $reviews;

		/**
		 * Filter the schema node before output.
		 *
		 * @since 1.0.0
		 * @param array<string, mixed> $node Schema node.
		 * @param array<int>           $ids  Rendered review IDs.
		 */
		$node = apply_filters( 'mvweb_rv_schema_node', $node, $ids );

		$graph = array(
			'@context' => 'https://schema.org',
			'@graph'   => array( $node ),
		);

		printf(
			'<script type="application/ld+json">%s</script>',
			wp_json_encode( $graph, JSON_UNESCAPED_UNICODE ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON encoded, slashes stay escaped so the script tag cannot be broken.
		);
	}

	/**
	 * Build a single Review node.
	 *
	 * @since 1.0.0
	 * @param int $post_id Review ID.
	 * @return array<string, mixed>
	 */
	private static function review_node( int $post_id ): array {
		$body = wp_strip_all_tags( (string) get_post_field( 'post_content', $post_id ) );
		$name = (string) get_the_title( $post_id );

		if ( '' === trim( $body ) || '' === trim( $name ) ) {
			return array();
		}

		$node = array(
			'@type'         => 'Review',
			'author'        => array(
				'@type' => 'Person',
				'name'  => $name,
			),
			'datePublished' => (string) get_the_date( 'c', $post_id ),
			'reviewBody'    => $body,
		);

		$rating = (int) get_post_meta( $post_id, '_mvweb_rv_rating', true );

		if ( $rating > 0 ) {
			$node['reviewRating'] = array(
				'@type'       => 'Rating',
				'ratingValue' => $rating,
				'bestRating'  => (int) mvweb_rv_get_settings( 'scale', 5 ),
				'worstRating' => 1,
			);
		}

		return $node;
	}

	/**
	 * Schema type for the reviewed entity.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function entity_type(): string {
		$type = (string) mvweb_rv_get_settings( 'schema_type', 'LocalBusiness' );

		return preg_match( '/^[A-Za-z]+$/', $type ) ? $type : 'LocalBusiness';
	}

	/**
	 * The @id of the organization node other SEO plugins already emit.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function entity_id(): string {
		/**
		 * Filter the reviewed entity @id.
		 *
		 * @since 1.0.0
		 * @param string $id Entity identifier.
		 */
		return (string) apply_filters( 'mvweb_rv_schema_entity_id', home_url( '/#organization' ) );
	}

	/**
	 * Whether Yoast SEO or Rank Math builds the schema graph.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	private static function seo_plugin_active(): bool {
		return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' );
	}
}
