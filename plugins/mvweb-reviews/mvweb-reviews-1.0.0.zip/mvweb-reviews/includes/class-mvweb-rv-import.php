<?php
/**
 * CSV import/export and clipboard import from map services.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bulk review transfer tools.
 *
 * @since 1.0.0
 */
class MVweb_RV_Import {

	private const CSV_COLUMNS = array( 'name', 'date', 'rating', 'city', 'order', 'text', 'source', 'source_url', 'reply' );

	private const MAX_CSV_BYTES = 2097152;

	/**
	 * Hook the admin-post endpoints.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'admin_post_mvweb_rv_import_paste', array( __CLASS__, 'import_paste' ) );
		add_action( 'admin_post_mvweb_rv_import_csv', array( __CLASS__, 'import_csv' ) );
		add_action( 'admin_post_mvweb_rv_export_csv', array( __CLASS__, 'export_csv' ) );
	}

	/**
	 * Create reviews from text pasted out of a map service.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function import_paste(): void {
		self::guard( 'mvweb_rv_import_paste' );
		self::guard_license();

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified in self::guard().
		$raw    = isset( $_POST['mvweb_rv_paste'] ) ? (string) wp_unslash( $_POST['mvweb_rv_paste'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized per field in the parser.
		$source = isset( $_POST['mvweb_rv_paste_source'] ) ? sanitize_key( wp_unslash( $_POST['mvweb_rv_paste_source'] ) ) : 'yandex';
		$group  = isset( $_POST['mvweb_rv_paste_group'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_rv_paste_group'] ) ) : '';
		$url    = isset( $_POST['mvweb_rv_paste_url'] ) ? esc_url_raw( wp_unslash( $_POST['mvweb_rv_paste_url'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		$created = 0;

		foreach ( self::parse_paste( $raw ) as $item ) {
			$item['source']     = array_key_exists( $source, mvweb_rv_sources() ) ? $source : 'yandex';
			$item['source_url'] = $url;

			if ( self::insert( $item, $group ) > 0 ) {
				++$created;
			}
		}

		self::finish( 'imported', $created );
	}

	/**
	 * Split pasted text into review records.
	 *
	 * @since 1.0.0
	 * @param string $raw Pasted text.
	 * @return array<int, array<string, mixed>>
	 */
	public static function parse_paste( string $raw ): array {
		$raw    = str_replace( array( "\r\n", "\r" ), "\n", $raw );
		$blocks = preg_split( '/\n{2,}/u', trim( $raw ) );
		$blocks = is_array( $blocks ) ? $blocks : array();
		$items  = array();

		foreach ( $blocks as $block ) {
			$lines = array_values( array_filter( array_map( 'trim', explode( "\n", $block ) ), static fn( $line ) => '' !== $line ) );

			if ( count( $lines ) < 2 ) {
				continue;
			}

			$name   = array_shift( $lines );
			$rating = 0;
			$date   = '';
			$text   = array();

			foreach ( $lines as $line ) {
				$stars = self::parse_rating( $line );

				if ( $stars > 0 && 0 === $rating ) {
					$rating = $stars;
					continue;
				}

				$parsed = self::parse_date( $line );

				if ( '' !== $parsed && '' === $date ) {
					$date = $parsed;
					continue;
				}

				$text[] = $line;
			}

			$body = trim( implode( "\n\n", $text ) );

			if ( '' === $body ) {
				continue;
			}

			$items[] = array(
				'name'   => sanitize_text_field( $name ),
				'date'   => $date,
				'rating' => $rating,
				'text'   => $body,
			);
		}

		return $items;
	}

	/**
	 * Read a rating value from a line.
	 *
	 * @since 1.0.0
	 * @param string $line Source line.
	 * @return int
	 */
	private static function parse_rating( string $line ): int {
		$stars = mb_substr_count( $line, '★' );

		if ( $stars > 0 && $stars <= 10 ) {
			return $stars;
		}

		if ( preg_match( '/^(?:оценка|rating)\D{0,3}(\d{1,2})/iu', $line, $matches ) ) {
			$value = (int) $matches[1];

			return ( $value >= 1 && $value <= 10 ) ? $value : 0;
		}

		if ( preg_match( '/^(\d{1,2})\s*(?:из|\/|of)\s*(?:5|10)$/iu', $line, $matches ) ) {
			return (int) $matches[1];
		}

		return 0;
	}

	/**
	 * Read a date from a line written in Russian or ISO format.
	 *
	 * @since 1.0.0
	 * @param string $line Source line.
	 * @return string Date in Y-m-d H:i:s or an empty string.
	 */
	private static function parse_date( string $line ): string {
		$months = array(
			'янв' => '01',
			'фев' => '02',
			'мар' => '03',
			'апр' => '04',
			'мая' => '05',
			'май' => '05',
			'июн' => '06',
			'июл' => '07',
			'авг' => '08',
			'сен' => '09',
			'окт' => '10',
			'ноя' => '11',
			'дек' => '12',
		);

		if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})/', trim( $line ), $iso ) ) {
			return $iso[1] . '-' . $iso[2] . '-' . $iso[3] . ' 12:00:00';
		}

		if ( ! preg_match( '/(\d{1,2})\s+([а-яё]{3,8})\.?\s*(\d{4})?/iu', $line, $matches ) ) {
			return '';
		}

		$key = mb_strtolower( mb_substr( $matches[2], 0, 3, 'UTF-8' ), 'UTF-8' );

		if ( ! isset( $months[ $key ] ) ) {
			return '';
		}

		$year = isset( $matches[3] ) && '' !== $matches[3] ? (int) $matches[3] : (int) current_time( 'Y' );

		return sprintf( '%04d-%s-%02d 12:00:00', $year, $months[ $key ], (int) $matches[1] );
	}

	/**
	 * Import reviews from an uploaded CSV file.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function import_csv(): void {
		self::guard( 'mvweb_rv_import_csv' );
		self::guard_license();

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce verified in self::guard().
		$upload = isset( $_FILES['mvweb_rv_csv'] ) ? array_map( 'strval', wp_unslash( $_FILES['mvweb_rv_csv'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- individual values validated below.
		$group  = isset( $_POST['mvweb_rv_csv_group'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_rv_csv_group'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( ! isset( $upload['tmp_name'], $upload['error'], $upload['size'], $upload['name'] ) ) {
			self::finish( 'csv_error', 0 );
		}

		if ( UPLOAD_ERR_OK !== (int) $upload['error'] || (int) $upload['size'] > self::MAX_CSV_BYTES ) {
			self::finish( 'csv_error', 0 );
		}

		$tmp_name = sanitize_text_field( $upload['tmp_name'] );
		$original = sanitize_file_name( $upload['name'] );

		if ( 'csv' !== strtolower( (string) pathinfo( $original, PATHINFO_EXTENSION ) ) || ! is_uploaded_file( $tmp_name ) ) {
			self::finish( 'csv_error', 0 );
		}

		$checked = wp_check_filetype_and_ext( $tmp_name, $original, array( 'csv' => 'text/csv' ) );

		if ( 'csv' !== $checked['ext'] ) {
			self::finish( 'csv_error', 0 );
		}

		// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- fgetcsv needs a stream handle, WP_Filesystem has no CSV reader.
		$handle = fopen( $tmp_name, 'r' );

		if ( ! $handle ) {
			self::finish( 'csv_error', 0 );
		}

		$header  = fgetcsv( $handle, 0, ';' );
		$header  = is_array( $header ) ? array_map( static fn( $value ) => sanitize_key( trim( (string) $value ) ), $header ) : array();
		$created = 0;

		if ( ! in_array( 'name', $header, true ) || ! in_array( 'text', $header, true ) ) {
			fclose( $handle );
			self::finish( 'csv_error', 0 );
		}

		$row = fgetcsv( $handle, 0, ';' );

		while ( false !== $row ) {
			if ( is_array( $row ) ) {
				$item = array();

				foreach ( $header as $index => $column ) {
					if ( in_array( $column, self::CSV_COLUMNS, true ) ) {
						$item[ $column ] = isset( $row[ $index ] ) ? (string) $row[ $index ] : '';
					}
				}

				if ( self::insert( $item, $group ) > 0 ) {
					++$created;
				}
			}

			$row = fgetcsv( $handle, 0, ';' );
		}

		fclose( $handle );
		// phpcs:enable WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		self::finish( 'imported', $created );
	}

	/**
	 * Stream every review as CSV.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function export_csv(): void {
		self::guard( 'mvweb_rv_export_csv' );

		$reviews = get_posts(
			array(
				'post_type'      => MVweb_RV_CPT::POST_TYPE,
				'post_status'    => array( 'publish', 'pending', 'draft' ),
				'posts_per_page' => -1,
				'orderby'        => 'date',
				'order'          => 'DESC',
			)
		);

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=mvweb-reviews-' . gmdate( 'Y-m-d' ) . '.csv' );

		// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.WP.AlternativeFunctions.file_system_operations_fwrite, WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- streaming a download to php://output, WP_Filesystem cannot do that.
		$output = fopen( 'php://output', 'w' );

		fwrite( $output, "\xEF\xBB\xBF" );
		fputcsv( $output, self::CSV_COLUMNS, ';' );

		foreach ( $reviews as $review ) {
			fputcsv(
				$output,
				array_map(
					array( __CLASS__, 'escape_csv_value' ),
					array(
						$review->post_title,
						(string) get_the_date( 'Y-m-d', $review ),
						(string) get_post_meta( $review->ID, '_mvweb_rv_rating', true ),
						(string) get_post_meta( $review->ID, '_mvweb_rv_city', true ),
						(string) get_post_meta( $review->ID, '_mvweb_rv_order', true ),
						$review->post_content,
						(string) get_post_meta( $review->ID, '_mvweb_rv_source', true ),
						(string) get_post_meta( $review->ID, '_mvweb_rv_source_url', true ),
						(string) get_post_meta( $review->ID, '_mvweb_rv_reply', true ),
					)
				),
				';'
			);
		}

		fclose( $output );
		// phpcs:enable WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.WP.AlternativeFunctions.file_system_operations_fwrite, WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		exit;
	}

	/**
	 * Neutralize spreadsheet formulas in exported values.
	 *
	 * @since 1.0.0
	 * @param string $value Cell value.
	 * @return string
	 */
	private static function escape_csv_value( string $value ): string {
		return ( '' !== $value && 1 === preg_match( '/^[=+\-@\t\r]/', $value ) ) ? "'" . $value : $value;
	}

	/**
	 * Create one pending review out of a parsed record.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $item  Parsed record.
	 * @param string               $group Optional group slugs.
	 * @return int New review ID or zero.
	 */
	private static function insert( array $item, string $group ): int {
		$name = sanitize_text_field( (string) ( $item['name'] ?? '' ) );
		$text = wp_kses_post( (string) ( $item['text'] ?? '' ) );

		if ( '' === $name || '' === trim( wp_strip_all_tags( $text ) ) ) {
			return 0;
		}

		$postarr = array(
			'post_type'    => MVweb_RV_CPT::POST_TYPE,
			'post_status'  => 'pending',
			'post_title'   => $name,
			'post_content' => $text,
		);

		$date = (string) ( $item['date'] ?? '' );

		if ( '' !== $date && false !== strtotime( $date ) ) {
			$postarr['post_date']     = gmdate( 'Y-m-d H:i:s', (int) strtotime( $date ) );
			$postarr['post_date_gmt'] = get_gmt_from_date( $postarr['post_date'] );
		}

		$post_id = wp_insert_post( $postarr, true );

		if ( is_wp_error( $post_id ) ) {
			return 0;
		}

		$post_id = (int) $post_id;
		$rating  = (int) ( $item['rating'] ?? 0 );
		$source  = sanitize_key( (string) ( $item['source'] ?? 'manual' ) );

		update_post_meta( $post_id, '_mvweb_rv_rating', ( $rating >= 1 && $rating <= 10 ) ? $rating : 0 );
		update_post_meta( $post_id, '_mvweb_rv_pinned', 0 );
		update_post_meta( $post_id, '_mvweb_rv_source', array_key_exists( $source, mvweb_rv_sources() ) ? $source : 'manual' );

		foreach ( array( 'city', 'order', 'reply', 'source_url' ) as $key ) {
			$value = (string) ( $item[ $key ] ?? '' );

			if ( '' === $value ) {
				continue;
			}

			$meta_key = '_mvweb_rv_' . $key;
			$value    = 'source_url' === $key ? esc_url_raw( $value ) : sanitize_text_field( $value );

			update_post_meta( $post_id, $meta_key, $value );
		}

		if ( '' !== $group ) {
			wp_set_object_terms( $post_id, array_map( 'trim', explode( ',', $group ) ), MVweb_RV_CPT::TAXONOMY );
		}

		return $post_id;
	}

	/**
	 * Verify capability and nonce.
	 *
	 * @since 1.0.0
	 * @param string $action Nonce action.
	 * @return void
	 */
	private static function guard( string $action ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to manage reviews.', 'mvweb-reviews' ), '', array( 'response' => 403 ) );
		}

		check_admin_referer( $action );
	}

	/**
	 * Block creating new reviews when the license verdict is negative.
	 *
	 * Only import — CSV export and everything on the front end stay open, see
	 * docs/plans/mvweb-reviews-license-client.md.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function guard_license(): void {
		if ( ! class_exists( 'MVweb_License' ) || ! MVweb_License::is_blocked() ) {
			return;
		}

		self::finish( 'license_blocked', 0 );
	}

	/**
	 * Redirect back to the import tab with a result flag.
	 *
	 * @since 1.0.0
	 * @param string $status Result code.
	 * @param int    $count  Number of created reviews.
	 * @return void
	 */
	private static function finish( string $status, int $count ): void {
		mvweb_rv_flush_cache();

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'          => 'mvweb-reviews',
					'tab'           => 'import',
					'mvweb_rv_msg'  => $status,
					'mvweb_rv_done' => $count,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
}
