<?php
/**
 * Admin settings screen and assets.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings page, editor button and admin assets.
 *
 * @since 1.0.0
 */
class MVweb_RV_Admin {

	/**
	 * Settings page hook suffix.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	private static string $hook_suffix = '';

	/**
	 * Hook the admin screens.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'save_settings' ) );
		add_action( 'admin_init', array( __CLASS__, 'save_license_key' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_filter( 'mce_external_plugins', array( __CLASS__, 'mce_plugin' ) );
		add_filter( 'mce_buttons', array( __CLASS__, 'mce_button' ) );
	}

	/**
	 * Register the settings page under MVweb Hub.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_menu(): void {
		self::$hook_suffix = (string) add_submenu_page(
			MVweb_Menu::get_menu_slug(),
			__( 'Reviews', 'mvweb-reviews' ),
			__( 'Reviews', 'mvweb-reviews' ),
			'manage_options',
			'mvweb-reviews',
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Render the settings page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You are not allowed to access this page.', 'mvweb-reviews' ) );
		}

		if ( class_exists( 'MVweb_License' ) && MVweb_License::is_blocked() ) {
			require MVWEB_RV_PATH . 'admin/views/license-blocked.php';
			return;
		}

		require MVWEB_RV_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Persist the fallback license key field.
	 *
	 * No-op when MVweb_License is not bundled, or when the site sets the key
	 * through the MVWEB_LICENSE_KEY wp-config constant instead.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function save_license_key(): void {
		if ( ! isset( $_POST['mvweb_rv_license_save'] ) || ! class_exists( 'MVweb_License' ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$nonce = isset( $_POST['mvweb_rv_license_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_rv_license_nonce'] ) ) : '';

		if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'mvweb_rv_license' ) ) {
			return;
		}

		$key = isset( $_POST['mvweb_rv_license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_rv_license_key'] ) ) : '';

		MVweb_License::save_key( $key );

		add_settings_error( 'mvweb_rv', 'mvweb_rv_license_saved', __( 'License key saved.', 'mvweb-reviews' ), 'success' );
	}

	/**
	 * Persist submitted settings.
	 *
	 * Refuses to save while the license verdict is blocking: render_page()
	 * hides the form, but a nonce issued before the verdict arrived stays
	 * valid for a day, so the handler is closed as well as the screen.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function save_settings(): void {
		if ( ! isset( $_POST['mvweb_rv_save'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( class_exists( 'MVweb_License' ) && MVweb_License::is_blocked() ) {
			return;
		}

		$nonce = isset( $_POST['mvweb_rv_nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['mvweb_rv_nonce'] ) ) : '';

		if ( '' === $nonce || ! wp_verify_nonce( $nonce, 'mvweb_rv_settings' ) ) {
			return;
		}

		$defaults = mvweb_rv_default_settings();
		$saved    = mvweb_rv_get_settings();
		$posted   = array();

		foreach ( $defaults as $key => $default ) {
			$field = 'mvweb_rv_' . $key;

			if ( ! isset( $_POST[ $field ] ) ) {
				$posted[ $key ] = in_array( $key, self::toggle_keys(), true ) ? 0 : $saved[ $key ];
				continue;
			}

			$value = wp_unslash( $_POST[ $field ] ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized below.

			$posted[ $key ] = self::sanitize_setting( $key, $value, $saved[ $key ] );
		}

		update_option( 'mvweb_rv_settings', $posted );
		mvweb_rv_flush_cache();

		add_settings_error( 'mvweb_rv', 'mvweb_rv_saved', __( 'Settings saved.', 'mvweb-reviews' ), 'success' );
	}

	/**
	 * Settings stored as on/off toggles.
	 *
	 * @since 1.0.0
	 * @return array<int, string>
	 */
	private static function toggle_keys(): array {
		return array(
			'show_rating',
			'show_photo',
			'show_date',
			'show_city',
			'show_order',
			'show_summary',
			'form_enabled',
			'form_contact',
			'form_photo',
			'form_consent',
			'schema_enabled',
			'cache_enabled',
		);
	}

	/**
	 * Sanitize a single setting value.
	 *
	 * @since 1.0.0
	 * @param string $key      Setting key.
	 * @param mixed  $value    Raw value.
	 * @param mixed  $fallback Value used when the input is invalid.
	 * @return mixed
	 */
	private static function sanitize_setting( string $key, $value, $fallback ) {
		switch ( $key ) {
			case 'layout':
				$value = sanitize_key( (string) $value );

				return array_key_exists( $value, mvweb_rv_layouts() ) ? $value : $fallback;

			case 'order':
				$value = sanitize_key( (string) $value );

				return array_key_exists( $value, mvweb_rv_orders() ) ? $value : $fallback;

			case 'scale':
				return 10 === (int) $value ? 10 : 5;

			case 'limit':
				return max( 1, min( 100, (int) $value ) );

			case 'card_min':
				return max( 180, min( 640, (int) $value ) );

			case 'clamp_lines':
				return max( 2, min( 40, (int) $value ) );

			case 'radius':
				return max( 0, min( 40, (int) $value ) );

			case 'min_fill_time':
				return max( 0, min( 120, (int) $value ) );

			case 'ip_limit':
				return max( 0, min( 50, (int) $value ) );

			case 'bg':
			case 'border':
			case 'star_color':
				return (string) sanitize_hex_color( (string) $value );

			case 'consent_url':
				return esc_url_raw( (string) $value );

			case 'schema_type':
				$value = sanitize_text_field( (string) $value );

				return preg_match( '/^[A-Za-z]+$/', $value ) ? $value : $fallback;

			default:
				return in_array( $key, self::toggle_keys(), true ) ? 1 : sanitize_text_field( (string) $value );
		}
	}

	/**
	 * Enqueue admin assets on plugin screens.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ): void {
		$screen    = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		$is_review = $screen && MVweb_RV_CPT::POST_TYPE === $screen->post_type;

		if ( self::$hook_suffix !== $hook && ! $is_review ) {
			return;
		}

		$admin_css  = MVWEB_RV_PATH . 'admin/css/admin.min.css';
		$plugin_css = MVWEB_RV_PATH . 'admin/css/plugin.min.css';
		$admin_js   = MVWEB_RV_PATH . 'admin/js/admin.min.js';

		if ( self::$hook_suffix === $hook ) {
			wp_enqueue_style(
				'mvweb-rv-admin',
				MVWEB_RV_URL . 'admin/css/admin.min.css',
				array(),
				file_exists( $admin_css ) ? (string) filemtime( $admin_css ) : MVWEB_RV_VERSION
			);
		}

		wp_enqueue_style(
			'mvweb-rv-plugin',
			MVWEB_RV_URL . 'admin/css/plugin.min.css',
			self::$hook_suffix === $hook ? array( 'mvweb-rv-admin' ) : array(),
			file_exists( $plugin_css ) ? (string) filemtime( $plugin_css ) : MVWEB_RV_VERSION
		);

		wp_enqueue_media();

		wp_enqueue_script(
			'mvweb-rv-admin',
			MVWEB_RV_URL . 'admin/js/admin.min.js',
			array( 'jquery' ),
			file_exists( $admin_js ) ? (string) filemtime( $admin_js ) : MVWEB_RV_VERSION,
			true
		);

		wp_localize_script(
			'mvweb-rv-admin',
			'mvwebRvAdmin',
			array(
				'mediaTitle'       => __( 'Select work photos', 'mvweb-reviews' ),
				'mediaButton'      => __( 'Add to review', 'mvweb-reviews' ),
				'removeLabel'      => __( 'Remove image', 'mvweb-reviews' ),
				'shortcodeBuilder' => array(
					'title'       => __( 'MVweb Reviews', 'mvweb-reviews' ),
					'layoutLabel' => __( 'Layout', 'mvweb-reviews' ),
					'layouts'     => mvweb_rv_layouts(),
					'groupLabel'  => __( 'Group slug', 'mvweb-reviews' ),
					'limitLabel'  => __( 'Limit', 'mvweb-reviews' ),
					'orderLabel'  => __( 'Order', 'mvweb-reviews' ),
					'orders'      => mvweb_rv_orders(),
				),
			)
		);
	}

	/**
	 * Register the TinyMCE shortcode button plugin.
	 *
	 * @since 1.0.0
	 * @param array<string, string> $plugins Registered MCE plugins.
	 * @return array<string, string>
	 */
	public static function mce_plugin( $plugins ): array {
		$plugins['mvweb_rv'] = MVWEB_RV_URL . 'admin/js/tinymce-plugin.min.js';

		return $plugins;
	}

	/**
	 * Add the shortcode button to the editor toolbar.
	 *
	 * @since 1.0.0
	 * @param array<int, string> $buttons Toolbar buttons.
	 * @return array<int, string>
	 */
	public static function mce_button( $buttons ): array {
		$buttons[] = 'mvweb_rv_button';

		return $buttons;
	}
}
