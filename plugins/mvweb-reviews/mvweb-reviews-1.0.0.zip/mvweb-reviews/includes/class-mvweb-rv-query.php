<?php
/**
 * Review queries and rating aggregation.
 *
 * @package mvweb_rv
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds review queries for the front end.
 *
 * @since 1.0.0
 */
class MVweb_RV_Query {

	/**
	 * Fetch published reviews.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $args Shortcode attributes.
	 * @return WP_Query
	 */
	public static function get( array $args ): WP_Query {
		$query_args = array(
			'post_type'           => MVweb_RV_CPT::POST_TYPE,
			'post_status'         => 'publish',
			'posts_per_page'      => (int) $args['limit'],
			'offset'              => (int) ( $args['offset'] ?? 0 ),
			'ignore_sticky_posts' => true,
			'no_found_rows'       => false,
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- pinned ordering and rating filter need meta; results are cached in a transient.
			'meta_query'          => array(
				'pinned' => array(
					'key'     => '_mvweb_rv_pinned',
					'compare' => 'EXISTS',
					'type'    => 'NUMERIC',
				),
				'rating' => array(
					'key'     => '_mvweb_rv_rating',
					'compare' => 'EXISTS',
					'type'    => 'NUMERIC',
				),
			),
		);

		if ( '' !== (string) $args['group'] ) {
			// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- group filtering is the point of the attribute; results are cached in a transient.
			$query_args['tax_query'] = array(
				array(
					'taxonomy' => MVweb_RV_CPT::TAXONOMY,
					'field'    => 'slug',
					'terms'    => array_map( 'sanitize_title', array_map( 'trim', explode( ',', (string) $args['group'] ) ) ),
				),
			);
		}

		if ( (int) $args['rating_min'] > 0 ) {
			$query_args['meta_query']['rating']['value']   = (int) $args['rating_min'];
			$query_args['meta_query']['rating']['compare'] = '>=';
		}

		switch ( (string) $args['order'] ) {
			case 'rating':
				$query_args['orderby'] = array(
					'pinned' => 'DESC',
					'rating' => 'DESC',
					'date'   => 'DESC',
				);
				break;

			case 'rand':
				$query_args['orderby'] = 'rand';
				break;

			case 'menu_order':
				$query_args['orderby'] = array(
					'pinned'     => 'DESC',
					'menu_order' => 'ASC',
					'date'       => 'DESC',
				);
				break;

			default:
				$query_args['orderby'] = array(
					'pinned' => 'DESC',
					'date'   => 'DESC',
				);
		}

		/**
		 * Filter the review query arguments.
		 *
		 * @since 1.0.0
		 * @param array<string, mixed> $query_args Query arguments.
		 * @param array<string, mixed> $args       Shortcode attributes.
		 */
		$query_args = apply_filters( 'mvweb_rv_query_args', $query_args, $args );

		return new WP_Query( $query_args );
	}

	/**
	 * Aggregate rating over the given reviews.
	 *
	 * @since 1.0.0
	 * @param array<int> $post_ids Review IDs shown on the page.
	 * @return array{value: float, count: int}
	 */
	public static function aggregate( array $post_ids ): array {
		$sum   = 0;
		$count = 0;

		foreach ( $post_ids as $post_id ) {
			$rating = (int) get_post_meta( (int) $post_id, '_mvweb_rv_rating', true );

			if ( $rating > 0 ) {
				$sum += $rating;
				++$count;
			}
		}

		return array(
			'value' => $count > 0 ? $sum / $count : 0.0,
			'count' => $count,
		);
	}
}
