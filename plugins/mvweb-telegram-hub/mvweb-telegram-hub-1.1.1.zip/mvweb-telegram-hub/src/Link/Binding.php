<?php
/**
 * Links a customer's Telegram chat to their orders.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Link;

use MVweb\Telegram\Hub\Frontend\Account;
use MVweb\Telegram\Hub\Settings;
use WC_Order;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Everything the connect flow needs: the deep link, the claim, the lookup.
 *
 * Nothing is stored while a link is pending. The ?start= payload carries its
 * own signature, so the site has no code to keep, no expiry to police and no
 * race between two updates arriving with the same code. A link therefore also
 * survives page caching: rendering it writes nothing.
 *
 * Two kinds of payload:
 *
 *     o<order_id>-<signature>   one order — the only thing a guest has
 *     u<user_id>-<signature>    the account — every order, present and future
 *
 * The signature is keyed on wp_salt(), so rotating the site salts invalidates
 * links that are already on screen. That costs a page reload and nothing else:
 * bindings that were already made are stored values and are unaffected.
 *
 * @since 1.1.0
 */
final class Binding {

	/**
	 * Order meta holding the chat that follows this one order.
	 *
	 * Written through the order CRUD, so it lands in the right table with HPOS
	 * on or off.
	 *
	 * @var string
	 */
	public const ORDER_META = '_mvweb_tg_chat_id';

	/**
	 * User option holding the chat that follows every order of an account.
	 *
	 * A user option, not user meta: wp_usermeta is shared across a multisite
	 * network, and a bare meta key would carry the binding to every site in it.
	 *
	 * @var string
	 */
	public const USER_OPTION = 'mvweb_tg_chat_id';

	/**
	 * How long one target is spared a repeat "you have been connected" email.
	 *
	 * @var int
	 */
	private const WARNING_INTERVAL = 6 * HOUR_IN_SECONDS;

	/**
	 * Orders touched by a single /stop.
	 *
	 * An account binding covers every order at once, so per-order rows are the
	 * rare case and this ceiling is never reached in practice. It is here so a
	 * webhook request cannot turn into a thousand order writes.
	 *
	 * @var int
	 */
	private const UNBIND_LIMIT = 100;

	/**
	 * Deep link that binds one order.
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order object.
	 * @return string Empty string when no bot is connected.
	 */
	public static function order_link( WC_Order $order ) {
		return self::link( 'o' . $order->get_id() . '-' . self::sign( self::order_data( $order ) ) );
	}

	/**
	 * Deep link that binds a whole account.
	 *
	 * @since 1.1.0
	 * @param int $user_id User id.
	 * @return string Empty string when no bot is connected.
	 */
	public static function account_link( $user_id ) {
		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return '';
		}

		return self::link( 'u' . $user_id . '-' . self::sign( self::user_data( $user_id ) ) );
	}

	/**
	 * Act on a /start payload that arrived through the webhook.
	 *
	 * @since 1.1.0
	 * @param string $payload Text after "/start".
	 * @param string $chat_id Chat the command came from.
	 * @return string Reply for the bot to send. Never empty.
	 */
	public static function claim( $payload, $chat_id ) {
		$payload = trim( (string) $payload );
		$chat_id = trim( (string) $chat_id );

		if ( '' === $chat_id || ! preg_match( '/^([ou])(\d{1,12})-([0-9a-f]{16})$/', $payload, $parts ) ) {
			return self::unknown_link_reply();
		}

		return 'o' === $parts[1]
			? self::claim_order( (int) $parts[2], $parts[3], $chat_id )
			: self::claim_account( (int) $parts[2], $parts[3], $chat_id );
	}

	/**
	 * Chat that should hear about this order, or an empty string.
	 *
	 * The order's own binding wins over the account one: a single order handed
	 * to a colleague stays with that colleague even for a registered customer.
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order object.
	 * @return string
	 */
	public static function for_order( WC_Order $order ) {
		$chat_id = (string) $order->get_meta( self::ORDER_META );

		if ( '' !== $chat_id ) {
			return $chat_id;
		}

		return self::of_user( $order->get_customer_id() );
	}

	/**
	 * Chat bound to an account, or an empty string.
	 *
	 * @since 1.1.0
	 * @param int $user_id User id. Zero for a guest.
	 * @return string
	 */
	public static function of_user( $user_id ) {
		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return '';
		}

		return (string) get_user_option( self::USER_OPTION, $user_id );
	}

	/**
	 * Drop every binding that points at one chat.
	 *
	 * Used by /stop and by a blocked bot alike, so the two paths cannot drift
	 * apart.
	 *
	 * @since 1.1.0
	 * @param string $chat_id Chat identifier.
	 * @return int Number of bindings removed.
	 */
	public static function unbind_chat( $chat_id ) {
		$chat_id = trim( (string) $chat_id );

		if ( '' === $chat_id ) {
			return 0;
		}

		$removed = 0;

		foreach ( self::users_bound_to( $chat_id ) as $user_id ) {
			delete_user_option( $user_id, self::USER_OPTION );
			++$removed;
		}

		foreach ( self::orders_bound_to( $chat_id ) as $order_id ) {
			$order = wc_get_order( $order_id );

			if ( ! $order ) {
				continue;
			}

			$order->delete_meta_data( self::ORDER_META );
			$order->save();
			++$removed;
		}

		return $removed;
	}

	/**
	 * Forget the chat bound to one order.
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order object.
	 * @return void
	 */
	public static function unbind_order( WC_Order $order ) {
		$order->delete_meta_data( self::ORDER_META );
		$order->save();
	}

	/**
	 * Forget the chat bound to one account.
	 *
	 * @since 1.1.0
	 * @param int $user_id User id.
	 * @return void
	 */
	public static function unbind_user( $user_id ) {
		$user_id = absint( $user_id );

		if ( $user_id ) {
			delete_user_option( $user_id, self::USER_OPTION );
		}
	}

	/**
	 * Whether this order may be offered a connect button at all.
	 *
	 * Without a billing address there is nowhere to send the "you have been
	 * connected" warning, and WooCommerce itself stops asking such an order for
	 * email verification — so the order key becomes a permanent bearer token.
	 * Both safeguards fail on the same orders, so the button does not appear on
	 * them.
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order object.
	 * @return bool
	 */
	public static function order_can_bind( WC_Order $order ) {
		return '' !== trim( (string) $order->get_billing_email() );
	}

	/**
	 * Whether the current visitor may connect or disconnect this order.
	 *
	 * The same two proofs WooCommerce itself accepts: being the logged-in owner
	 * of the order, or holding its key.
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order object.
	 * @param string   $key   Order key supplied with the request, if any.
	 * @return bool
	 */
	public static function can_manage_order( WC_Order $order, $key = '' ) {
		$customer_id = $order->get_customer_id();

		if ( $customer_id && get_current_user_id() === $customer_id ) {
			return true;
		}

		$key = (string) $key;

		return '' !== $key && hash_equals( (string) $order->get_order_key(), $key );
	}

	/**
	 * Bind one order.
	 *
	 * @since 1.1.0
	 * @param int    $order_id  Order id from the payload.
	 * @param string $signature Signature from the payload.
	 * @param string $chat_id   Chat to bind.
	 * @return string Reply for the bot.
	 */
	private static function claim_order( $order_id, $signature, $chat_id ) {
		$order = wc_get_order( $order_id );

		if ( ! $order instanceof WC_Order || ! hash_equals( self::sign( self::order_data( $order ) ), $signature ) ) {
			return self::unknown_link_reply();
		}

		if ( ! self::order_can_bind( $order ) ) {
			return self::unknown_link_reply();
		}

		$current = (string) $order->get_meta( self::ORDER_META );

		if ( $current === $chat_id ) {
			return __( 'This order is already connected here.', 'mvweb-telegram-hub' );
		}

		if ( '' !== $current ) {
			return __( 'This order is already receiving notifications in another Telegram account. Disconnect it there first, on the order page in the shop.', 'mvweb-telegram-hub' );
		}

		$order->update_meta_data( self::ORDER_META, $chat_id );
		$order->save();

		self::warn_owner(
			'o' . $order->get_id(),
			$order->get_billing_email(),
			$order->get_checkout_order_received_url(),
			sprintf(
				/* translators: %s: order number. */
				__( 'Telegram notifications have been switched on for order %s.', 'mvweb-telegram-hub' ),
				$order->get_order_number()
			)
		);

		return sprintf(
			/* translators: %s: order number. */
			__( 'Done. Updates on order %s will arrive here. Send /stop to turn them off.', 'mvweb-telegram-hub' ),
			$order->get_order_number()
		);
	}

	/**
	 * Bind a whole account.
	 *
	 * @since 1.1.0
	 * @param int    $user_id   User id from the payload.
	 * @param string $signature Signature from the payload.
	 * @param string $chat_id   Chat to bind.
	 * @return string Reply for the bot.
	 */
	private static function claim_account( $user_id, $signature, $chat_id ) {
		$user = get_userdata( $user_id );

		if ( ! $user || ! hash_equals( self::sign( self::user_data( $user_id ) ), $signature ) ) {
			return self::unknown_link_reply();
		}

		$current = self::of_user( $user_id );

		if ( $current === $chat_id ) {
			return __( 'This account is already connected here.', 'mvweb-telegram-hub' );
		}

		if ( '' !== $current ) {
			return __( 'This account is already receiving notifications in another Telegram account. Disconnect it there first, in your account on the site.', 'mvweb-telegram-hub' );
		}

		update_user_option( $user_id, self::USER_OPTION, $chat_id );

		self::warn_owner(
			'u' . $user_id,
			$user->user_email,
			Account::url(),
			__( 'Telegram notifications have been switched on for your account.', 'mvweb-telegram-hub' )
		);

		return __( 'Done. Updates on your orders will arrive here, including future ones. Send /stop to turn them off.', 'mvweb-telegram-hub' );
	}

	/**
	 * Tell the address on file that a Telegram account was attached.
	 *
	 * A deep link carries no proof of who clicked it, so nothing stops someone
	 * from handing their own link to the customer and collecting that
	 * customer's order updates. This mail is what makes that visible: it goes
	 * to the address the order was placed with, never to whoever pressed Start.
	 *
	 * @since 1.1.0
	 * @param string $target  Stable key of what was bound, for the repeat guard.
	 * @param string $email   Address on file.
	 * @param string $url     Page where the binding can be undone.
	 * @param string $subject What happened, in one sentence.
	 * @return void
	 */
	private static function warn_owner( $target, $email, $url, $subject ) {
		$email = sanitize_email( (string) $email );

		if ( ! is_email( $email ) ) {
			return;
		}

		$guard = 'mvweb_tg_warned_' . md5( $target . '|' . $email );

		if ( get_transient( $guard ) ) {
			return;
		}

		set_transient( $guard, 1, self::WARNING_INTERVAL );

		$body = implode(
			"\n\n",
			array(
				$subject,
				__( 'If that was not you, open the page below and press “Disconnect”.', 'mvweb-telegram-hub' ),
				$url,
			)
		);

		wp_mail(
			$email,
			sprintf(
				/* translators: %s: site title. */
				__( '[%s] Telegram notifications connected', 'mvweb-telegram-hub' ),
				wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES )
			),
			$body
		);
	}

	/**
	 * Orders bound to a chat.
	 *
	 * Queried with the meta_key and meta_value shortcuts rather than with a
	 * meta_query: the classic post-based order store drops meta_query on the
	 * floor, while both stores understand the shortcut arguments.
	 *
	 * @since 1.1.0
	 * @param string $chat_id Chat identifier.
	 * @return int[]
	 */
	private static function orders_bound_to( $chat_id ) {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return array();
		}

		$ids = wc_get_orders(
			array(
				'limit'      => self::UNBIND_LIMIT,
				'meta_key'   => self::ORDER_META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- indexed by WooCommerce in both order stores.
				'meta_value' => $chat_id,         // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- see above.
				'return'     => 'ids',
			)
		);

		return is_array( $ids ) ? array_map( 'absint', $ids ) : array();
	}

	/**
	 * Accounts bound to a chat.
	 *
	 * The lookup has to carry the blog prefix by hand: update_user_option()
	 * adds it when writing, and get_users() sees the raw meta key.
	 *
	 * @since 1.1.0
	 * @param string $chat_id Chat identifier.
	 * @return int[]
	 */
	private static function users_bound_to( $chat_id ) {
		global $wpdb;

		$ids = get_users(
			array(
				'meta_key'   => $wpdb->get_blog_prefix() . self::USER_OPTION, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- bounded by number, indexed by meta_key.
				'meta_value' => $chat_id,                                     // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- see above.
				'number'     => self::UNBIND_LIMIT,
				'fields'     => 'ID',
			)
		);

		return is_array( $ids ) ? array_map( 'absint', $ids ) : array();
	}

	/**
	 * Build the t.me address for a payload.
	 *
	 * @since 1.1.0
	 * @param string $payload Signed payload.
	 * @return string Empty string when the bot username is unknown.
	 */
	private static function link( $payload ) {
		$bot = Settings::bot_username();

		if ( '' === $bot ) {
			return '';
		}

		return 'https://t.me/' . rawurlencode( $bot ) . '?start=' . rawurlencode( $payload );
	}

	/**
	 * Signed string for an order.
	 *
	 * The order key is part of it, so a link stops working if the key is ever
	 * regenerated, and the order id alone is not enough to forge one.
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order object.
	 * @return string
	 */
	private static function order_data( WC_Order $order ) {
		return 'tgo|' . $order->get_id() . '|' . $order->get_order_key();
	}

	/**
	 * Signed string for an account.
	 *
	 * @since 1.1.0
	 * @param int $user_id User id.
	 * @return string
	 */
	private static function user_data( $user_id ) {
		return 'tgu|' . absint( $user_id );
	}

	/**
	 * Truncated HMAC over the site salt.
	 *
	 * Sixteen hex characters is 64 bits — far past guessing for a value that is
	 * checked against one specific order — and keeps the whole payload well
	 * inside the 64 characters Telegram allows after ?start=.
	 *
	 * @since 1.1.0
	 * @param string $data Value to sign.
	 * @return string
	 */
	private static function sign( $data ) {
		return substr( hash_hmac( 'sha256', $data, wp_salt( 'auth' ) ), 0, 16 );
	}

	/**
	 * One answer for every reason a link did not work.
	 *
	 * A bad signature, a deleted order and an order with no email address are
	 * told apart deliberately vaguely: the bot is talking to whoever pressed
	 * Start, and that is not necessarily the customer.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private static function unknown_link_reply() {
		return __( 'This link is not valid. Open your order in the shop and press “Connect Telegram” there to get a fresh one.', 'mvweb-telegram-hub' );
	}
}
