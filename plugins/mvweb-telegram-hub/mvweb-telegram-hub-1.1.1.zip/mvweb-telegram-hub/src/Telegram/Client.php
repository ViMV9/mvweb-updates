<?php
/**
 * Telegram Bot API client.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Telegram;

use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Thin wrapper over the Bot API.
 *
 * Every call returns the same normalised array so callers never have to know
 * whether the failure came from the HTTP layer or from Telegram itself:
 *
 *     array(
 *         'ok'          => bool,
 *         'result'      => array,
 *         'error_code'  => int,
 *         'description' => string,
 *         'retry_after' => int|null,
 *         'retryable'   => bool,
 *     )
 *
 * @since 1.0.0
 */
final class Client {

	/**
	 * Request timeout in seconds.
	 *
	 * @var int
	 */
	private const TIMEOUT = 15;

	/**
	 * Bot token used for this instance.
	 *
	 * @var string
	 */
	private $token;

	/**
	 * API base URL without a trailing slash.
	 *
	 * @var string
	 */
	private $api_base;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 * @param string|null $token    Bot token. Defaults to the configured one.
	 * @param string|null $api_base API base URL. Defaults to the configured one.
	 */
	public function __construct( $token = null, $api_base = null ) {
		$this->token    = null === $token ? Settings::token() : (string) $token;
		$this->api_base = null === $api_base ? Settings::api_base() : untrailingslashit( (string) $api_base );
	}

	/**
	 * Call a Bot API method.
	 *
	 * @since 1.0.0
	 * @param string $method Bot API method name, e.g. 'sendMessage'.
	 * @param array  $params Request parameters.
	 * @return array Normalised response.
	 */
	public function request( $method, array $params = array() ) {
		if ( '' === $this->token ) {
			return $this->failure(
				0,
				__( 'Bot token is not set.', 'mvweb-telegram-hub' ),
				false
			);
		}

		$url = sprintf( '%s/bot%s/%s', $this->api_base, $this->token, $method );

		/*
		 * Safe variant on purpose: the API host is operator-editable, and the
		 * token travels inside the URL. wp_safe_remote_post() runs the address
		 * through wp_http_validate_url(), which refuses loopback and private
		 * ranges — so a mistyped or hostile host cannot turn this into a request
		 * against the server's own network. A genuinely internal proxy is still
		 * reachable through the WP_ACCESSIBLE_HOSTS constant.
		 */
		$response = wp_safe_remote_post(
			$url,
			array(
				'timeout' => self::TIMEOUT,
				'body'    => $params,
			)
		);

		if ( is_wp_error( $response ) ) {
			// Network-level failure: worth another attempt later.
			return $this->failure( 0, $response->get_error_message(), true );
		}

		$status = (int) wp_remote_retrieve_response_code( $response );
		$body   = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $body ) ) {
			return $this->failure(
				$status,
				__( 'Telegram returned a malformed response.', 'mvweb-telegram-hub' ),
				$status >= 500
			);
		}

		if ( ! empty( $body['ok'] ) ) {
			return array(
				'ok'          => true,
				'result'      => isset( $body['result'] ) ? (array) $body['result'] : array(),
				'error_code'  => 0,
				'description' => '',
				'retry_after' => null,
				'retryable'   => false,
			);
		}

		$error_code  = isset( $body['error_code'] ) ? (int) $body['error_code'] : $status;
		$description = isset( $body['description'] ) ? (string) $body['description'] : '';
		$retry_after = isset( $body['parameters']['retry_after'] ) ? (int) $body['parameters']['retry_after'] : null;

		return $this->failure( $error_code, $description, self::is_retryable( $error_code ), $retry_after );
	}

	/**
	 * Send a text message.
	 *
	 * Link previews are described by link_preview_options, which replaced
	 * disable_web_page_preview in Bot API 7.0 — the old field is gone from the
	 * documentation entirely, and Telegram ignores parameters it does not know,
	 * so sending it did nothing at all. Previews stay off unless the caller
	 * asks for one, which is how a post carries its picture: a preview of the
	 * thumbnail leaves all 4096 characters for the text, where a photo caption
	 * would leave 1024.
	 *
	 * @since 1.0.0
	 * @since 1.1.0 Takes preview options and a button.
	 * @param string $chat_id Chat identifier or @channelusername.
	 * @param string $text    Message text in Telegram HTML.
	 * @param array  $preview LinkPreviewOptions fields. Empty means no preview.
	 * @param array  $button  Link button under the message: text and url. Empty means none.
	 * @return array Normalised response.
	 */
	public function send_message( $chat_id, $text, array $preview = array(), array $button = array() ) {
		return $this->request(
			'sendMessage',
			array(
				'chat_id'              => $chat_id,
				'text'                 => $text,
				'parse_mode'           => 'HTML',
				'link_preview_options' => wp_json_encode(
					$preview ? $preview : array( 'is_disabled' => true )
				),
			) + self::keyboard( $button )
		);
	}

	/**
	 * Send a photo with a caption.
	 *
	 * The photo travels as a URL, not as a file: the request body is
	 * form-encoded by WordPress, and multipart would have to be assembled by
	 * hand. Telegram fetches the address itself, which also means it has to be
	 * reachable from outside — a staging site behind basic auth cannot use
	 * this mode.
	 *
	 * @since 1.1.0
	 * @param string $chat_id Chat identifier or @channelusername.
	 * @param string $photo   Public address of the image.
	 * @param string $caption Caption in Telegram HTML, at most 1024 characters.
	 * @param array  $button  Link button under the photo: text and url. Empty means none.
	 * @return array Normalised response.
	 */
	public function send_photo( $chat_id, $photo, $caption, array $button = array() ) {
		return $this->request(
			'sendPhoto',
			array(
				'chat_id'    => $chat_id,
				'photo'      => (string) $photo,
				'caption'    => (string) $caption,
				'parse_mode' => 'HTML',
			) + self::keyboard( $button )
		);
	}

	/**
	 * A one-button inline keyboard, as request parameters.
	 *
	 * @since 1.1.0
	 * @param array $button Text and url of the button.
	 * @return array Empty when either part is missing.
	 */
	private static function keyboard( array $button ) {
		$text = isset( $button['text'] ) ? trim( (string) $button['text'] ) : '';
		$url  = isset( $button['url'] ) ? (string) $button['url'] : '';

		if ( '' === $text || ! preg_match( '#^https?://#i', $url ) ) {
			return array();
		}

		return array(
			'reply_markup' => wp_json_encode(
				array(
					'inline_keyboard' => array(
						array(
							array(
								'text' => $text,
								'url'  => $url,
							),
						),
					),
				)
			),
		);
	}

	/**
	 * Fetch the bot's own profile.
	 *
	 * @since 1.0.0
	 * @return array Normalised response.
	 */
	public function get_me() {
		return $this->request( 'getMe' );
	}

	/**
	 * Fetch information about a chat.
	 *
	 * @since 1.0.0
	 * @param string $chat_id Chat identifier or @channelusername.
	 * @return array Normalised response.
	 */
	public function get_chat( $chat_id ) {
		return $this->request( 'getChat', array( 'chat_id' => $chat_id ) );
	}

	/**
	 * Recent updates the bot received.
	 *
	 * Called without an offset on purpose: acknowledging the updates would drop
	 * them from Telegram's queue, and the operator may well press the button
	 * twice. Telegram keeps them for 24 hours either way.
	 *
	 * @since 1.0.0
	 * @return array Normalised response.
	 */
	public function get_updates() {
		return $this->request( 'getUpdates', array( 'limit' => 100 ) );
	}

	/**
	 * Whether a webhook is registered for this bot.
	 *
	 * A webhook and getUpdates are mutually exclusive, so this tells the
	 * operator why chat discovery came back empty.
	 *
	 * @since 1.0.0
	 * @return array Normalised response.
	 */
	public function get_webhook_info() {
		return $this->request( 'getWebhookInfo' );
	}

	/**
	 * Point Telegram at an address of ours.
	 *
	 * The list of update types travels as a JSON string, not as an array: the
	 * request body is form-encoded by WordPress, and an array would arrive as
	 * allowed_updates[0]=… — which Telegram does not read as a list.
	 *
	 * @since 1.1.0
	 * @param string   $url      Public https address of the webhook.
	 * @param string   $secret   Value Telegram echoes back in a header.
	 * @param string[] $updates  Update types we want to receive.
	 * @return array Normalised response.
	 */
	public function set_webhook( $url, $secret, array $updates ) {
		return $this->request(
			'setWebhook',
			array(
				'url'                  => (string) $url,
				'secret_token'         => (string) $secret,
				'allowed_updates'      => wp_json_encode( array_values( $updates ) ),
				'drop_pending_updates' => 'true',
				'max_connections'      => 10,
			)
		);
	}

	/**
	 * Stop Telegram from posting updates to us.
	 *
	 * @since 1.1.0
	 * @return array Normalised response.
	 */
	public function delete_webhook() {
		return $this->request( 'deleteWebhook', array( 'drop_pending_updates' => 'true' ) );
	}

	/**
	 * Whether an error code is worth retrying.
	 *
	 * 400 and 403 mean a wrong chat id, a bot removed from the group or a user
	 * who blocked it. None of that heals on its own, so retrying only burns
	 * rate limits.
	 *
	 * @since 1.0.0
	 * @param int $error_code Telegram or HTTP status code.
	 * @return bool
	 */
	public static function is_retryable( $error_code ) {
		if ( 429 === $error_code ) {
			return true;
		}
		return $error_code >= 500;
	}

	/**
	 * Build a failure response.
	 *
	 * @since 1.0.0
	 * @param int      $code        Error code.
	 * @param string   $description Human-readable description.
	 * @param bool     $retryable   Whether another attempt makes sense.
	 * @param int|null $retry_after Seconds requested by Telegram, if any.
	 * @return array
	 */
	private function failure( $code, $description, $retryable, $retry_after = null ) {
		return array(
			'ok'          => false,
			'result'      => array(),
			'error_code'  => (int) $code,
			'description' => (string) $description,
			'retry_after' => $retry_after,
			'retryable'   => (bool) $retryable,
		);
	}
}
