<?php
/**
 * Macro substitution for editable message templates.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Telegram;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Turns a template and a set of values into a message.
 *
 * Lifted out of the order macros when a second template appeared. The rule it
 * carries is the interesting part: a line whose macros all came out empty is
 * dropped whole, so an order with no phone number does not arrive with a
 * dangling "Phone:" and a post with no excerpt leaves no blank gap. A line
 * that carries no known macro is static text somebody wrote on purpose and
 * always survives.
 *
 * @since 1.1.0
 */
final class Template {

	/**
	 * Render a template against a set of values.
	 *
	 * @since 1.1.0
	 * @param array  $values   Macro name mapped to its value, already escaped.
	 * @param string $template Raw template.
	 * @return string
	 */
	public static function render( array $values, $template ) {
		$lines = preg_split( '/\R/u', (string) $template );
		$map   = self::replacements( $values );
		$kept  = array();

		foreach ( (array) $lines as $line ) {
			if ( ! self::line_has_content( $line, $values ) ) {
				continue;
			}

			$kept[] = strtr( $line, $map );
		}

		return Formatter::tidy( implode( "\n", $kept ) );
	}

	/**
	 * Whether a template line still says something once macros are resolved.
	 *
	 * @since 1.1.0
	 * @param string $line   Raw template line.
	 * @param array  $values Macro values.
	 * @return bool
	 */
	private static function line_has_content( $line, array $values ) {
		if ( ! preg_match_all( '/\{([a-z_]+)\}/', $line, $matches ) ) {
			return true;
		}

		$known = array_intersect( $matches[1], array_keys( $values ) );

		if ( ! $known ) {
			return true;
		}

		foreach ( $known as $macro ) {
			if ( '' !== $values[ $macro ] ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Build the strtr() map for macro substitution.
	 *
	 * @since 1.1.0
	 * @param array $values Macro values.
	 * @return array<string, string>
	 */
	private static function replacements( array $values ) {
		$map = array();

		foreach ( $values as $macro => $value ) {
			$map[ '{' . $macro . '}' ] = $value;
		}

		return $map;
	}
}
