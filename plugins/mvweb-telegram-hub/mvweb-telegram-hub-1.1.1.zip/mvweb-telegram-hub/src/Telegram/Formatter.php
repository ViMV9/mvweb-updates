<?php
/**
 * Message formatting helpers for Telegram HTML.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Telegram;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Escapes, sanitises and truncates Telegram HTML messages.
 *
 * @since 1.0.0
 */
final class Formatter {

	/**
	 * Hard limit Telegram enforces on a message.
	 *
	 * @var int
	 */
	public const HARD_LIMIT = 4096;

	/**
	 * Length we truncate to, leaving room for the ellipsis and the order link.
	 *
	 * @var int
	 */
	public const SAFE_LIMIT = 4000;

	/**
	 * Length a caption is truncated to, leaving room for the ellipsis and link.
	 *
	 * @var int
	 */
	public const CAPTION_LIMIT = 950;

	/**
	 * Tags Telegram understands in HTML parse mode.
	 *
	 * Used as the wp_kses whitelist for the user-editable template and for the
	 * converter that turns post content into a message. Anything outside this
	 * list makes the API reject the whole message rather than ignore the tag.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function allowed_tags() {
		return array(
			'b'          => array(),
			'strong'     => array(),
			'i'          => array(),
			'em'         => array(),
			'u'          => array(),
			'ins'        => array(),
			's'          => array(),
			'strike'     => array(),
			'del'        => array(),
			'code'       => array(),
			'pre'        => array(),
			'blockquote' => array(),
			'a'          => array( 'href' => array() ),
		);
	}

	/**
	 * Escape a macro value for Telegram HTML.
	 *
	 * Telegram only requires &, < and > to be escaped. Product titles routinely
	 * contain those characters, and an unescaped one makes the API reject the
	 * whole message with a 400.
	 *
	 * @since 1.0.0
	 * @param string $value Raw value.
	 * @return string
	 */
	public static function escape( $value ) {
		return str_replace(
			array( '&', '<', '>' ),
			array( '&amp;', '&lt;', '&gt;' ),
			(string) $value
		);
	}

	/**
	 * Tidy up the whitespace of a rendered message.
	 *
	 * Dropping lines whose macros came out empty is the caller's job — only it
	 * knows which macros a line carried. Judging that here, on the rendered
	 * text, would also delete honest headings such as "<b>Items:</b>".
	 *
	 * @since 1.0.0
	 * @param string $text Message after macro substitution.
	 * @return string
	 */
	public static function tidy( $text ) {
		$text  = self::utf8( $text );
		$lines = preg_split( '/\R/u', $text );
		$kept  = array();

		foreach ( (array) $lines as $line ) {
			$kept[] = rtrim( $line );
		}

		$text = implode( "\n", $kept );

		// Never leave more than one blank line in a row.
		$text = preg_replace( "/\n{3,}/u", "\n\n", $text );

		return trim( (string) $text );
	}

	/**
	 * Truncate a Telegram HTML message without breaking its markup.
	 *
	 * Cutting mid-tag or leaving a tag unclosed makes Telegram reject the
	 * message outright, so the whole notification would be lost — worse than a
	 * shortened one. This walks tags and text separately, cuts inside text only
	 * and closes whatever is still open.
	 *
	 * @since 1.0.0
	 * @param string $html   Message in Telegram HTML.
	 * @param int    $limit  Maximum visible length.
	 * @param string $suffix Appended when the message was cut.
	 * @return string
	 */
	public static function truncate( $html, $limit = self::SAFE_LIMIT, $suffix = '…' ) {
		$html  = self::utf8( $html );
		$limit = (int) $limit;

		if ( self::length( wp_strip_all_tags( $html ) ) <= $limit ) {
			return $html;
		}

		$tokens = preg_split( '/(<[^>]*>)/u', $html, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		$out    = '';
		$stack  = array();
		$used   = 0;
		$cut    = false;

		foreach ( (array) $tokens as $token ) {
			if ( '<' === substr( $token, 0, 1 ) ) {
				$out .= $token;

				if ( preg_match( '#^</\s*([a-z]+)#i', $token, $m ) ) {
					self::close( $stack, strtolower( $m[1] ) );
				} elseif ( preg_match( '#^<\s*([a-z]+)#i', $token, $m ) ) {
					$stack[] = strtolower( $m[1] );
				}

				continue;
			}

			$length = self::length( $token );

			if ( $used + $length <= $limit ) {
				$out  .= $token;
				$used += $length;
				continue;
			}

			$out .= self::at_word( $token, self::cut( $token, $limit - $used ) );
			$cut  = true;
			break;
		}

		if ( $cut ) {
			// The cut can land inside an escaped entity. A bare "&" or a stub
			// like "&am" is invalid Telegram HTML and gets the whole message
			// rejected with a 400, so the fragment goes.
			$out = preg_replace( '/&[#a-zA-Z0-9]{0,9}$/', '', rtrim( $out ) );
			$out = rtrim( (string) $out ) . $suffix;
		}

		// Close whatever the cut left open, innermost first.
		foreach ( array_reverse( $stack ) as $tag ) {
			$out .= '</' . $tag . '>';
		}

		return $out;
	}

	/**
	 * Length as Telegram counts it.
	 *
	 * Telegram measures a message in UTF-16 code units, not in characters:
	 * everything outside the basic plane — every emoji — costs two. Counting
	 * characters lets an emoji-heavy post sail past a 4000 check and arrive at
	 * the API as 8000, where it is refused outright.
	 *
	 * @since 1.1.0
	 * @param string $text Text to measure.
	 * @return int
	 */
	public static function length( $text ) {
		$text = (string) $text;

		if ( ! function_exists( 'mb_convert_encoding' ) ) {
			return mb_strlen( $text );
		}

		return (int) ( strlen( (string) mb_convert_encoding( $text, 'UTF-16LE', 'UTF-8' ) ) / 2 );
	}

	/**
	 * Take the innermost open tag of this name off the stack.
	 *
	 * Innermost, not the first one found. On a stack of b, pre, b a closing
	 * </b> used to remove the outer one, and the tail then closed the message
	 * as </b></pre> instead of </pre></b> — crossed tags, which Telegram
	 * refuses with a 400 and the whole notification is lost.
	 *
	 * @since 1.1.0
	 * @param array  $stack Open tags, outermost first. Modified in place.
	 * @param string $name  Tag being closed.
	 * @return void
	 */
	private static function close( array &$stack, $name ) {
		for ( $i = count( $stack ) - 1; $i >= 0; $i-- ) {
			if ( $stack[ $i ] === $name ) {
				array_splice( $stack, $i, 1 );
				return;
			}
		}
	}

	/**
	 * As much of a piece of text as fits a budget of UTF-16 units.
	 *
	 * @since 1.1.0
	 * @param string $text   Text to cut.
	 * @param int    $budget Units available.
	 * @return string
	 */
	private static function cut( $text, $budget ) {
		$budget = max( 0, (int) $budget );

		// A character is never fewer than one unit, so the character count is a
		// safe upper bound to start from.
		$piece = mb_substr( $text, 0, $budget );
		$over  = self::length( $piece ) - $budget;

		// Every character over the budget is worth at least one unit and at most
		// two, so half the excess is a safe step. On text with no emoji in it the
		// loop does not run at all.
		while ( '' !== $piece && $over > 0 ) {
			$piece = mb_substr( $piece, 0, max( 0, mb_strlen( $piece ) - (int) ceil( $over / 2 ) ) );
			$over  = self::length( $piece ) - $budget;
		}

		return $piece;
	}

	/**
	 * A cut piece of text, moved back to the end of its last whole word.
	 *
	 * A teaser that stops at "заме…" reads as a mistake. When the cut lands
	 * inside a word the piece goes back to the last space; a piece with no
	 * space in it at all keeps the hard cut, since the alternative is nothing.
	 * A list bullet left with no item after it goes too.
	 *
	 * @since 1.1.0
	 * @param string $text  Whole text the piece was cut from.
	 * @param string $piece Its beginning, as cut to the budget.
	 * @return string
	 */
	private static function at_word( $text, $piece ) {
		$next = mb_substr( $text, mb_strlen( $piece ), 1 );

		if ( '' === $next || preg_match( '/^\s$/u', $next ) ) {
			return $piece;
		}

		$whole = (string) preg_replace( '/\S+\z/u', '', $piece );
		$whole = (string) preg_replace( '/\s*•\s*\z/u', '', $whole );

		return '' !== trim( $whole ) ? $whole : $piece;
	}

	/**
	 * Text with any broken UTF-8 taken out of it.
	 *
	 * Every pattern here carries the /u modifier, and one stray byte makes PCRE
	 * return null for the lot. That turned a post with a single bad character
	 * into an empty message, which the queue then dropped without a word in the
	 * log. Core has the answer already.
	 *
	 * @since 1.1.0
	 * @param string $text Text of unknown provenance.
	 * @return string
	 */
	private static function utf8( $text ) {
		return (string) wp_check_invalid_utf8( (string) $text, true );
	}
}
