<?php
/**
 * Incoming Telegram updates.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Rest;

use MVweb\Telegram\Hub\Link\Binding;
use MVweb\Telegram\Hub\Settings;
use MVweb\Telegram\Hub\Telegram\Client;
use MVweb\Telegram\Hub\Telegram\Formatter;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The one address Telegram is allowed to post to.
 *
 * A bot cannot write to somebody who has not started a chat with it, so the
 * only way to learn a customer's chat id is to let them press Start and hear
 * about it. That means accepting an unauthenticated POST from the internet,
 * and the whole design of this class is about making that boring:
 *
 *   - the route does not exist until a secret has been generated;
 *   - the secret is compared inside permission_callback, before any work;
 *   - the update body is parsed by hand, never through the route's args —
 *     WordPress validates args before permission_callback, so a malformed
 *     body would be answered 400 without the secret ever being checked, and
 *     Telegram would retry that for a day;
 *   - every path answers 200, including the ones that threw.
 *
 * @since 1.1.0
 */
final class Webhook {

	/**
	 * REST namespace.
	 *
	 * Specific to this plugin rather than a shared "mvweb/v1": one entry in a
	 * security plugin's REST allow-list should open this endpoint, not every
	 * endpoint the studio ever ships.
	 *
	 * @var string
	 */
	public const REST_NAMESPACE = 'mvweb-telegram-hub/v1';

	/**
	 * Route inside the namespace.
	 *
	 * @var string
	 */
	public const ROUTE = '/webhook';

	/**
	 * Option holding the shared secret.
	 *
	 * Its own option, outside the settings array: that array is autoloaded on
	 * every request and travels through a sanitiser that is fed by a form. A
	 * machine-generated secret has no business in any of that, and keeping it
	 * out is also what makes it impossible to render into the page by mistake.
	 *
	 * @var string
	 */
	public const SECRET_OPTION = 'mvweb_tg_webhook_secret';

	/**
	 * Header Telegram echoes the secret back in.
	 *
	 * @var string
	 */
	private const SECRET_HEADER = 'X-Telegram-Bot-Api-Secret-Token';

	/**
	 * Update types worth receiving.
	 *
	 * The membership one is what arrives when somebody blocks the bot — the
	 * only push notice that a binding has gone dead.
	 *
	 * @var string[]
	 */
	private const UPDATES = array( 'message', 'my_chat_member' );

	/**
	 * Transient caching getWebhookInfo for the settings screen.
	 *
	 * @var string
	 */
	private const INFO_TRANSIENT = 'mvweb_tg_webhook_info';

	/**
	 * Hook the route.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function register() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Declare the route, but only once there is a secret to check against.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function register_routes() {
		if ( '' === self::secret() ) {
			return;
		}

		register_rest_route(
			self::REST_NAMESPACE,
			self::ROUTE,
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle' ),
				'permission_callback' => array( $this, 'check_secret' ),
				'args'                => array(),
				'show_in_index'       => false,
			)
		);
	}

	/**
	 * Compare the secret Telegram sent with the one we stored.
	 *
	 * Called twice per successful request — once by the dispatcher and once by
	 * rest_send_allow_header — so it does nothing but compare.
	 *
	 * @since 1.1.0
	 * @param WP_REST_Request $request Incoming request.
	 * @return true|WP_Error
	 */
	public function check_secret( $request ) {
		$refused = new WP_Error(
			'mvweb_tg_bad_secret',
			__( 'Wrong or missing webhook secret.', 'mvweb-telegram-hub' ),
			array( 'status' => 403 )
		);

		try {
			$stored = self::secret();

			// hash_equals( '', '' ) is true, which would leave the route wide
			// open in exactly the window before the operator switches it on.
			if ( '' === $stored ) {
				return $refused;
			}

			// get_header() returns null when the header is absent, and
			// hash_equals() rejects null with a TypeError rather than false.
			$sent = (string) $request->get_header( self::SECRET_HEADER );

			return hash_equals( $stored, $sent ) ? true : $refused;
		} catch ( \Throwable $e ) {
			return $refused;
		}
	}

	/**
	 * Take one update and always answer 200.
	 *
	 * Anything other than a 2xx makes Telegram repeat the delivery for hours,
	 * so a bug here would turn into a flood. The REST server does not catch
	 * throwables from a callback, hence the guard.
	 *
	 * @since 1.1.0
	 * @param WP_REST_Request $request Incoming request.
	 * @return WP_REST_Response
	 */
	public function handle( $request ) {
		try {
			$this->process( $request->get_json_params() );
		} catch ( \Throwable $e ) {
			// Nothing to report to Telegram: it is not the one that can fix it.
			unset( $e );
		}

		return new WP_REST_Response( null, 200 );
	}

	/**
	 * Public address of the endpoint.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function url() {
		return rest_url( self::REST_NAMESPACE . self::ROUTE );
	}

	/**
	 * The stored secret, or an empty string.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function secret() {
		return (string) get_option( self::SECRET_OPTION, '' );
	}

	/**
	 * Whether the plugin currently accepts commands.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function is_enabled() {
		return '' !== self::secret();
	}

	/**
	 * Register the webhook with Telegram.
	 *
	 * The secret is written only after Telegram has accepted it: Telegram
	 * sends back whatever it was given at setWebhook time, so storing a value
	 * the API never received would reject every real update from then on, in
	 * silence.
	 *
	 * @since 1.1.0
	 * @return array {
	 *     Outcome.
	 *
	 *     @type bool   $ok      Whether the webhook is now registered.
	 *     @type string $message Sentence for the operator.
	 * }
	 */
	public static function enable() {
		if ( ! Settings::has_token() ) {
			return self::result( false, __( 'Connect a bot first: without a token there is nothing to register.', 'mvweb-telegram-hub' ) );
		}

		$url = self::url();

		if ( 0 !== strpos( $url, 'https://' ) ) {
			return self::result(
				false,
				sprintf(
					/* translators: %s: address the site would have registered. */
					__( 'Telegram only accepts an https address, and this site reports %s. Fix the site address in Settings → General first.', 'mvweb-telegram-hub' ),
					$url
				)
			);
		}

		$client = new Client();

		/*
		 * Ask who the token belongs to and remember it. The storefront builds
		 * its deep link out of the bot username and never calls Telegram itself
		 * — a fifteen-second timeout on a shop page is not an option — so if the
		 * name is not on file the connect button silently never appears. It is
		 * written when a token is saved through the form, which leaves out two
		 * ordinary cases: a token defined in wp-config, where the field is
		 * disabled and never posted, and a shop upgrading from a version that
		 * did not store it. Switching commands on is the one step this feature
		 * cannot skip, so it is the place to close both.
		 */
		$me = $client->get_me();

		if ( empty( $me['ok'] ) || empty( $me['result']['username'] ) ) {
			return self::result(
				false,
				sprintf(
					/* translators: %s: error description from Telegram. */
					__( 'Telegram did not accept the token: %s', 'mvweb-telegram-hub' ),
					isset( $me['description'] ) && '' !== $me['description']
						? $me['description']
						: __( 'no response', 'mvweb-telegram-hub' )
				)
			);
		}

		Settings::remember_bot(
			array(
				'id'       => isset( $me['result']['id'] ) ? (int) $me['result']['id'] : 0,
				'username' => (string) $me['result']['username'],
			)
		);

		$info = $client->get_webhook_info();

		// One bot serves one address. Registering ours over somebody else's
		// would quietly steal their updates, and nothing anywhere would say so
		// — which is also why a failed check is a refusal and not a shrug.
		if ( empty( $info['ok'] ) ) {
			return self::result( false, __( 'Could not ask Telegram whether this bot is already in use somewhere else. Nothing was changed — try again in a minute.', 'mvweb-telegram-hub' ) );
		}

		if ( ! empty( $info['result']['url'] ) && $info['result']['url'] !== $url ) {
			return self::result( false, __( 'This bot already delivers its updates to another address, so it is in use by another site or service. Create a separate bot for this site.', 'mvweb-telegram-hub' ) );
		}

		$secret   = self::generate_secret();
		$response = $client->set_webhook( $url, $secret, self::UPDATES );

		if ( empty( $response['ok'] ) ) {
			return self::result(
				false,
				sprintf(
					/* translators: %s: error description from Telegram. */
					__( 'Telegram refused to register the address: %s', 'mvweb-telegram-hub' ),
					isset( $response['description'] ) && '' !== $response['description']
						? $response['description']
						: __( 'no response', 'mvweb-telegram-hub' )
				)
			);
		}

		update_option( self::SECRET_OPTION, $secret, false );
		delete_transient( self::INFO_TRANSIENT );

		return self::result( true, __( 'Telegram will now deliver commands to this site.', 'mvweb-telegram-hub' ) );
	}

	/**
	 * Unregister the webhook.
	 *
	 * The local secret goes even if the API call failed: leaving it behind
	 * would keep an endpoint alive that the operator has switched off.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function disable() {
		if ( Settings::has_token() ) {
			( new Client() )->delete_webhook();
		}

		delete_option( self::SECRET_OPTION );
		delete_transient( self::INFO_TRANSIENT );
	}

	/**
	 * What Telegram says about the current webhook, cached.
	 *
	 * "We could not ask" is reported separately from "we asked and all is
	 * well". Both used to come back as an empty array, which turned the one
	 * failure this feature cannot otherwise notice — Telegram unable to reach
	 * the site — into a green tick.
	 *
	 * @since 1.1.0
	 * @return array {
	 *     Cached state.
	 *
	 *     @type bool  $ok     Whether Telegram answered at all.
	 *     @type array $result Result part of getWebhookInfo, empty on failure.
	 * }
	 */
	public static function info() {
		$cached = get_transient( self::INFO_TRANSIENT );

		if ( is_array( $cached ) && isset( $cached['ok'] ) ) {
			return $cached;
		}

		if ( ! Settings::has_token() ) {
			return array(
				'ok'     => false,
				'result' => array(),
			);
		}

		$response = ( new Client() )->get_webhook_info();

		$state = array(
			'ok'     => ! empty( $response['ok'] ),
			'result' => ! empty( $response['ok'] ) && is_array( $response['result'] ) ? $response['result'] : array(),
		);

		set_transient( self::INFO_TRANSIENT, $state, 5 * MINUTE_IN_SECONDS );

		return $state;
	}

	/**
	 * Act on one decoded update.
	 *
	 * Every level is checked before it is read: message, my_chat_member and
	 * callback_query have different shapes, and Telegram adds new ones without
	 * asking.
	 *
	 * @since 1.1.0
	 * @param mixed $update Decoded JSON body. Null when the body was not JSON.
	 * @return void
	 */
	private function process( $update ) {
		if ( ! is_array( $update ) ) {
			return;
		}

		if ( isset( $update['my_chat_member'] ) && is_array( $update['my_chat_member'] ) ) {
			$this->on_membership_change( $update['my_chat_member'] );
			return;
		}

		if ( isset( $update['message'] ) && is_array( $update['message'] ) ) {
			$this->on_message( $update['message'] );
		}
	}

	/**
	 * Somebody blocked or removed the bot.
	 *
	 * @since 1.1.0
	 * @param array $event my_chat_member payload.
	 * @return void
	 */
	private function on_membership_change( array $event ) {
		$chat_id = isset( $event['chat']['id'] ) ? (string) $event['chat']['id'] : '';
		$status  = isset( $event['new_chat_member']['status'] ) ? (string) $event['new_chat_member']['status'] : '';

		if ( '' === $chat_id || ! in_array( $status, array( 'kicked', 'left' ), true ) ) {
			return;
		}

		Binding::unbind_chat( $chat_id );
	}

	/**
	 * Somebody wrote to the bot.
	 *
	 * Only two commands mean anything here. Everything else is ignored without
	 * touching the database — the bot's username is printed on a public page,
	 * so anyone can write to it as often as they like.
	 *
	 * @since 1.1.0
	 * @param array $message Message payload.
	 * @return void
	 */
	private function on_message( array $message ) {
		$chat_id = isset( $message['chat']['id'] ) ? (string) $message['chat']['id'] : '';
		$text    = isset( $message['text'] ) ? trim( (string) $message['text'] ) : '';

		if ( '' === $chat_id || '/' !== substr( $text, 0, 1 ) ) {
			return;
		}

		// "/start payload", and in a group also "/start@mybot payload".
		$parts   = preg_split( '/\s+/', $text, 2 );
		$command = strtolower( strtok( (string) $parts[0], '@' ) );
		$payload = isset( $parts[1] ) ? $parts[1] : '';

		if ( '/start' === $command ) {
			$reply = '' === $payload
				? __( 'Open your order in the shop and press “Connect Telegram” — that link brings you back here already signed in.', 'mvweb-telegram-hub' )
				: Binding::claim( $payload, $chat_id );
		} elseif ( '/stop' === $command ) {
			$reply = Binding::unbind_chat( $chat_id ) > 0
				? __( 'Done. No more order updates will be sent here.', 'mvweb-telegram-hub' )
				: __( 'There was nothing connected to this chat.', 'mvweb-telegram-hub' );
		} else {
			return;
		}

		( new Client() )->send_message( $chat_id, Formatter::escape( $reply ) );
	}

	/**
	 * A secret Telegram will accept.
	 *
	 * The core generator runs its output through the public random_password
	 * filter, so the character set is re-checked here rather than assumed:
	 * Telegram allows A-Z, a-z, 0-9, underscore and hyphen only.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private static function generate_secret() {
		$secret = wp_generate_password( 48, false, false );

		if ( ! preg_match( '/^[A-Za-z0-9_-]{1,256}$/', $secret ) ) {
			$secret = bin2hex( random_bytes( 24 ) );
		}

		return $secret;
	}

	/**
	 * Shape one outcome for the caller.
	 *
	 * @since 1.1.0
	 * @param bool   $ok      Whether it worked.
	 * @param string $message Sentence for the operator.
	 * @return array
	 */
	private static function result( $ok, $message ) {
		return array(
			'ok'      => (bool) $ok,
			'message' => (string) $message,
		);
	}
}
