<?php
/**
 * Settings storage and accessors.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Single source of truth for plugin options.
 *
 * Everything lives in one option array so a settings screen save is one write
 * and one autoloaded row.
 *
 * @since 1.0.0
 */
final class Settings {

	/**
	 * Option name holding every setting.
	 *
	 * @var string
	 */
	public const OPTION = 'mvweb_tg_settings';

	/**
	 * Option holding the log table schema version.
	 *
	 * @var string
	 */
	public const DB_VERSION_OPTION = 'mvweb_tg_db_version';

	/**
	 * Option holding the username of the connected bot.
	 *
	 * Kept out of the settings array and out of the transient cache alike: the
	 * customer-facing block builds its deep link from it on every storefront
	 * hit, and a cache that expires would take the connect button away with it.
	 * It is a fact about the token, not a setting, so it never travels through
	 * the settings sanitiser.
	 *
	 * @var string
	 */
	public const BOT_USERNAME_OPTION = 'mvweb_tg_bot_username';

	/**
	 * Option holding the OpenID Connect client secret.
	 *
	 * Its own row for the same two reasons the webhook secret has one: the
	 * settings array is autoloaded on every request and travels through a
	 * sanitiser fed by a form, and a credential in there is one careless
	 * var_dump away from a page.
	 *
	 * @var string
	 */
	public const LOGIN_SECRET_OPTION = 'mvweb_tg_login_secret';

	/**
	 * Default Telegram Bot API host.
	 *
	 * @var string
	 */
	public const DEFAULT_API_BASE = 'https://api.telegram.org';

	/**
	 * Cached settings for this request.
	 *
	 * @var array|null
	 */
	private static $cache = null;

	/**
	 * Default values for every setting.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function defaults() {
		return array(
			'bot_token'             => '',
			'api_base'              => '',
			'modules'               => array( 'woo-orders' => true ),
			'recipients'            => array(),
			'order_template'        => self::default_template(),
			'items_limit'           => 10,
			'log_days'              => 30,
			'delete_data'           => false,
			'customer_statuses'     => self::default_customer_statuses(),

			// Sign-in. Off out of the box, like every other module: switching it
			// on adds a way into the site, and that is the owner's decision.
			'login_enabled'         => false,
			'login_client_id'       => '',
			'login_roles'           => array( 'subscriber', 'customer' ),
			'login_register'        => true,
			'login_register_closed' => false,

			// Channel posting.
			'channels'              => array(),
			'post_types'            => array( 'post' ),
			'post_terms'            => array(),
			'post_template'         => self::default_post_template(),
			'post_delay'            => 0,
			'post_photo'            => 'preview',
			'post_excerpt_length'   => 600,
			'post_button'           => self::default_post_button(),
			'post_text_field'       => false,
		);
	}

	/**
	 * Default label of the button under a channel post.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function default_post_button() {
		return __( 'Read on the site →', 'mvweb-telegram-hub' );
	}

	/**
	 * Default template for a post announced in a channel.
	 *
	 * The excerpt rather than the whole post on purpose: a channel entry is an
	 * invitation to read, and a reader who wanted the whole text follows the
	 * button. Whoever wants the article in the channel swaps one macro.
	 *
	 * No {post_url}: the address goes into the button under the message. As
	 * bare text a permalink with a non-Latin slug arrives percent-encoded,
	 * a line of %d0%b1 several times longer than the title.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function default_post_template() {
		return __(
			"<b>{post_title}</b>\n\n{post_excerpt}\n\n{hashtags}",
			'mvweb-telegram-hub'
		);
	}

	/**
	 * Order statuses a customer hears about out of the box.
	 *
	 * The three a shopper actually waits for. "Pending payment" and "Failed"
	 * are left off: both fire during checkout, where the shopper is already
	 * looking at the page that says the same thing.
	 *
	 * Keys carry the wc- prefix, exactly as wc_get_order_statuses() returns
	 * them — the hook argument does not, so the comparison prefixes it there.
	 *
	 * @since 1.1.0
	 * @return string[]
	 */
	public static function default_customer_statuses() {
		return array( 'wc-processing', 'wc-completed', 'wc-cancelled' );
	}

	/**
	 * Default order message template.
	 *
	 * Translatable: the Russian catalogue ships the Russian wording.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function default_template() {
		/*
		 * One macro per line. Two of them on a shared line looked tidier until an
		 * order arrived without a payment method: the line is not empty, so it
		 * survives the empty-line rule, and the separator is left hanging on its
		 * own. A line that carries a single macro simply disappears with it.
		 */
		return __(
			"🛒 <b>Order #{order_number}</b>\n<i>{order_date}</i>\n\n💰 <b>{order_total}</b>\n💳 {payment_method}\n🚚 {shipping_method}\n\n<b>Items:</b>\n{order_items}\n\n👤 {customer_name}\n📞 {customer_phone}\n✉️ {customer_email}\n💬 {order_note}\n\n<a href=\"{admin_url}\">Open the order →</a>",
			'mvweb-telegram-hub'
		);
	}

	/**
	 * Get every setting, merged over defaults.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function all() {
		if ( null === self::$cache ) {
			$stored = get_option( self::OPTION, array() );
			if ( ! is_array( $stored ) ) {
				$stored = array();
			}
			self::$cache = array_merge( self::defaults(), $stored );
		}
		return self::$cache;
	}

	/**
	 * Get one setting.
	 *
	 * @since 1.0.0
	 * @param string $key      Setting key.
	 * @param mixed  $fallback Value returned when the key is unknown.
	 * @return mixed
	 */
	public static function get( $key, $fallback = null ) {
		$all = self::all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
	}

	/**
	 * Drop the in-request cache after a write.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function flush_cache() {
		self::$cache = null;
	}

	/**
	 * Whether the bot token comes from wp-config.php.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function token_is_constant() {
		return defined( 'MVWEB_TG_BOT_TOKEN' ) && '' !== (string) constant( 'MVWEB_TG_BOT_TOKEN' );
	}

	/**
	 * Get the bot token.
	 *
	 * A wp-config.php constant always wins over the stored value, so a client
	 * can keep the token out of database dumps.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function token() {
		if ( self::token_is_constant() ) {
			return (string) constant( 'MVWEB_TG_BOT_TOKEN' );
		}
		return (string) self::get( 'bot_token', '' );
	}

	/**
	 * Token with its middle replaced by an ellipsis, for display.
	 *
	 * The full token is never printed into admin HTML.
	 *
	 * @since 1.0.0
	 * @return string Empty string when no token is set.
	 */
	public static function masked_token() {
		$token = self::token();
		if ( '' === $token ) {
			return '';
		}
		if ( strlen( $token ) <= 18 ) {
			return str_repeat( '•', strlen( $token ) );
		}
		return substr( $token, 0, 10 ) . '…' . substr( $token, -4 );
	}

	/**
	 * Bot API base URL without a trailing slash.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function api_base() {
		$base = trim( (string) self::get( 'api_base', '' ) );
		if ( '' === $base ) {
			$base = self::DEFAULT_API_BASE;
		}
		return untrailingslashit( $base );
	}

	/**
	 * Configured recipients.
	 *
	 * @since 1.0.0
	 * @return string[] List of chat identifiers.
	 */
	public static function recipients() {
		$recipients = self::get( 'recipients', array() );
		return is_array( $recipients ) ? array_values( array_filter( $recipients ) ) : array();
	}

	/**
	 * Whether a module is switched on.
	 *
	 * @since 1.0.0
	 * @param string $slug Module slug.
	 * @return bool
	 */
	public static function module_enabled( $slug ) {
		$modules = self::get( 'modules', array() );
		return ! empty( $modules[ $slug ] );
	}

	/**
	 * Order statuses the customer is notified about, prefixed with wc-.
	 *
	 * @since 1.1.0
	 * @return string[]
	 */
	public static function customer_statuses() {
		$statuses = self::get( 'customer_statuses', array() );

		return is_array( $statuses ) ? array_values( array_filter( $statuses ) ) : array();
	}

	/**
	 * Whether the plugin is configured well enough to send anything.
	 *
	 * Operator notifications need a recipient list; customer notifications do
	 * not, so they gate on has_token() instead. A shop that only writes to its
	 * buyers would otherwise stay silent with no explanation.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function is_ready() {
		return self::has_token() && array() !== self::recipients();
	}

	/**
	 * Whether a bot token is available at all.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function has_token() {
		return '' !== self::token();
	}

	/**
	 * Username of the connected bot, without the leading @.
	 *
	 * Never calls Telegram: this is read while rendering the storefront, and a
	 * fifteen-second HTTP timeout there would hold up the page. The value is
	 * written whenever the token is verified.
	 *
	 * @since 1.1.0
	 * @return string Empty string when no bot is known yet.
	 */
	public static function bot_username() {
		$bot = get_transient( 'mvweb_tg_bot_info' );

		if ( is_array( $bot ) && ! empty( $bot['username'] ) ) {
			return (string) $bot['username'];
		}

		return (string) get_option( self::BOT_USERNAME_OPTION, '' );
	}

	/**
	 * Remember who the token belongs to.
	 *
	 * @since 1.1.0
	 * @param array $bot Bot profile with at least id and username.
	 * @return void
	 */
	public static function remember_bot( array $bot ) {
		set_transient( 'mvweb_tg_bot_info', $bot, 12 * HOUR_IN_SECONDS );

		if ( ! empty( $bot['username'] ) ) {
			update_option( self::BOT_USERNAME_OPTION, (string) $bot['username'], false );
		}
	}

	/**
	 * Forget the cached bot profile.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function forget_bot() {
		delete_transient( 'mvweb_tg_bot_info' );
		delete_option( self::BOT_USERNAME_OPTION );
	}

	/**
	 * Whether signing in with Telegram is switched on.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function login_enabled() {
		return (bool) self::get( 'login_enabled', false );
	}

	/**
	 * OpenID Connect client id, as issued by BotFather.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function login_client_id() {
		return trim( (string) self::get( 'login_client_id', '' ) );
	}

	/**
	 * Whether the client secret comes from wp-config.php.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function login_secret_is_constant() {
		return defined( 'MVWEB_TG_LOGIN_SECRET' ) && '' !== (string) constant( 'MVWEB_TG_LOGIN_SECRET' );
	}

	/**
	 * OpenID Connect client secret.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function login_secret() {
		if ( self::login_secret_is_constant() ) {
			return (string) constant( 'MVWEB_TG_LOGIN_SECRET' );
		}

		return (string) get_option( self::LOGIN_SECRET_OPTION, '' );
	}

	/**
	 * Client secret with its middle replaced, for display.
	 *
	 * @since 1.1.0
	 * @return string Empty string when no secret is set.
	 */
	public static function masked_login_secret() {
		$secret = self::login_secret();

		if ( '' === $secret ) {
			return '';
		}

		if ( strlen( $secret ) <= 12 ) {
			return str_repeat( '•', strlen( $secret ) );
		}

		return substr( $secret, 0, 6 ) . '…' . substr( $secret, -4 );
	}

	/**
	 * Roles allowed to sign in with Telegram, as ticked.
	 *
	 * Raw list from the settings. Users::allowed_roles() narrows it to roles
	 * that exist and are not privileged.
	 *
	 * @since 1.1.0
	 * @return string[]
	 */
	public static function login_roles() {
		$roles = self::get( 'login_roles', array( 'subscriber', 'customer' ) );

		return is_array( $roles ) ? array_values( array_filter( array_map( 'strval', $roles ) ) ) : array();
	}

	/**
	 * Whether an unknown Telegram account may become a new account here.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function login_registration() {
		return (bool) self::get( 'login_register', true );
	}

	/**
	 * Whether to register even though the site says registration is closed.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function login_registration_when_closed() {
		return (bool) self::get( 'login_register_closed', false );
	}

	/**
	 * Channels a new post is announced in.
	 *
	 * A list of its own, never the operator recipients: those are the manager
	 * chats that hear about orders, and a shop that put its team chat in there
	 * has not asked for its articles to land in it.
	 *
	 * @since 1.1.0
	 * @return string[]
	 */
	public static function channels() {
		$channels = self::get( 'channels', array() );

		return is_array( $channels ) ? array_values( array_filter( $channels ) ) : array();
	}

	/**
	 * Post types that are announced.
	 *
	 * @since 1.1.0
	 * @return string[]
	 */
	public static function post_types() {
		$types = self::get( 'post_types', array() );

		return is_array( $types ) ? array_values( array_filter( $types ) ) : array();
	}

	/**
	 * Category ids that are announced. Empty means every category.
	 *
	 * @since 1.1.0
	 * @return int[]
	 */
	public static function post_terms() {
		$terms = self::get( 'post_terms', array() );

		return is_array( $terms ) ? array_values( array_filter( array_map( 'absint', $terms ) ) ) : array();
	}

	/**
	 * Template for a channel post.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function post_template() {
		$template = trim( (string) self::get( 'post_template', '' ) );

		return '' !== $template ? $template : self::default_post_template();
	}

	/**
	 * Minutes to wait after publication before announcing.
	 *
	 * @since 1.1.0
	 * @return int
	 */
	public static function post_delay() {
		return max( 0, (int) self::get( 'post_delay', 0 ) );
	}

	/**
	 * What to do with the featured image.
	 *
	 * @since 1.1.0
	 * @return string One of preview, photo, none.
	 */
	public static function post_photo_mode() {
		$mode = (string) self::get( 'post_photo', 'preview' );

		return in_array( $mode, array( 'preview', 'photo', 'none' ), true ) ? $mode : 'preview';
	}

	/**
	 * Length of the teaser built from the start of a post, in characters.
	 *
	 * @since 1.1.0
	 * @return int
	 */
	public static function post_excerpt_length() {
		return min( 3000, max( 100, (int) self::get( 'post_excerpt_length', 600 ) ) );
	}

	/**
	 * Whether posts get a separate "Text for Telegram" field.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function post_text_field() {
		return (bool) self::get( 'post_text_field', false );
	}

	/**
	 * Label of the button under a channel post.
	 *
	 * @since 1.1.0
	 * @return string Empty when the operator wants no button.
	 */
	public static function post_button() {
		return trim( (string) self::get( 'post_button', self::default_post_button() ) );
	}
}
