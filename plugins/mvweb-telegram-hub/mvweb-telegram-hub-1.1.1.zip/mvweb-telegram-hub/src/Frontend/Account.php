<?php
/**
 * The "Telegram" section of the WooCommerce account.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.1
 */

namespace MVweb\Telegram\Hub\Frontend;

use MVweb\Telegram\Hub\Auth\Screen;
use MVweb\Telegram\Hub\Link\Binding;
use MVweb\Telegram\Hub\Modules\WooCustomer\Module as CustomerModule;
use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One account page for everything Telegram: order updates and signing in.
 *
 * A WooCommerce account endpoint rather than a page of its own, so the theme
 * draws it like every other section — its menu, its title, its notices — and
 * the plugin prints only the content, in WooCommerce's own form markup.
 *
 * The endpoint is declared whatever the settings say. Declaring it only while
 * a feature is on would change the rewrite rules on every switch of a toggle,
 * and a rule set that was not flushed afterwards turns the menu item into a
 * 404. A section with nothing to show is left out of the menu and sends
 * whoever opens it to the dashboard instead.
 *
 * @since 1.1.1
 */
final class Account {

	/**
	 * Endpoint slug, also the query var.
	 *
	 * @since 1.1.1
	 * @var string
	 */
	public const ENDPOINT = 'telegram';

	/**
	 * Option remembering which set of rewrite rules was last flushed.
	 *
	 * @since 1.1.1
	 * @var string
	 */
	public const REWRITE_OPTION = 'mvweb_tg_rewrite_version';

	/**
	 * Bumped whenever the plugin adds or renames an endpoint.
	 *
	 * @since 1.1.1
	 * @var string
	 */
	private const REWRITE_VERSION = '1';

	/**
	 * Add the endpoint to WooCommerce's list.
	 *
	 * Hooked from the main plugin file rather than from boot: WooCommerce turns
	 * this list into rewrite endpoints on init at the default priority, and
	 * boot runs on that same hook, so whether it got there first would depend
	 * on the order the plugins were loaded in.
	 *
	 * @since 1.1.1
	 * @param array $vars Query vars, keyed by endpoint.
	 * @return array
	 */
	public static function add_query_var( $vars ) {
		$vars = is_array( $vars ) ? $vars : array();

		$vars[ self::ENDPOINT ] = self::ENDPOINT;

		return $vars;
	}

	/**
	 * Address of the section.
	 *
	 * @since 1.1.1
	 * @return string
	 */
	public static function url() {
		return function_exists( 'wc_get_account_endpoint_url' ) ? (string) wc_get_account_endpoint_url( self::ENDPOINT ) : '';
	}

	/**
	 * Hook the account page.
	 *
	 * @since 1.1.1
	 * @return void
	 */
	public function register() {
		add_action( 'wp_loaded', array( $this, 'maybe_flush' ) );
		add_action( 'template_redirect', array( $this, 'maybe_leave' ) );
		add_filter( 'woocommerce_account_menu_items', array( $this, 'menu_item' ), 30 );
		add_filter( 'woocommerce_endpoint_' . self::ENDPOINT . '_title', array( $this, 'title' ) );
		add_action( 'woocommerce_account_' . self::ENDPOINT . '_endpoint', array( $this, 'render' ) );
	}

	/**
	 * Rebuild the rewrite rules once after the endpoint appears.
	 *
	 * An update does not run the activation hook, so this cannot live there.
	 * Done in the admin only: the first visit to the dashboard after an update
	 * is soon enough, and a storefront request should never rewrite rules.
	 *
	 * @since 1.1.1
	 * @return void
	 */
	public function maybe_flush() {
		if ( ! is_admin() || wp_doing_ajax() || self::REWRITE_VERSION === get_option( self::REWRITE_OPTION ) ) {
			return;
		}

		flush_rewrite_rules( false );
		update_option( self::REWRITE_OPTION, self::REWRITE_VERSION, false );
	}

	/**
	 * Send a visitor away from a section that has nothing for them.
	 *
	 * @since 1.1.1
	 * @return void
	 */
	public function maybe_leave() {
		if ( ! function_exists( 'is_wc_endpoint_url' ) || ! is_wc_endpoint_url( self::ENDPOINT ) || ! is_user_logged_in() ) {
			return;
		}

		if ( self::has_content( wp_get_current_user() ) ) {
			return;
		}

		wp_safe_redirect( wc_get_page_permalink( 'myaccount' ) );
		exit;
	}

	/**
	 * Put the section into the account menu, just above "Log out".
	 *
	 * @since 1.1.1
	 * @param array $items Menu items, keyed by endpoint.
	 * @return array
	 */
	public function menu_item( $items ) {
		if ( ! is_array( $items ) || ! self::has_content( wp_get_current_user() ) ) {
			return $items;
		}

		$label = __( 'Telegram', 'mvweb-telegram-hub' );

		if ( ! isset( $items['customer-logout'] ) ) {
			$items[ self::ENDPOINT ] = $label;
			return $items;
		}

		$logout = $items['customer-logout'];
		unset( $items['customer-logout'] );

		$items[ self::ENDPOINT ]  = $label;
		$items['customer-logout'] = $logout;

		return $items;
	}

	/**
	 * Page title of the section.
	 *
	 * @since 1.1.1
	 * @return string
	 */
	public function title() {
		return __( 'Telegram', 'mvweb-telegram-hub' );
	}

	/**
	 * Print the section.
	 *
	 * @since 1.1.1
	 * @return void
	 */
	public function render() {
		$user = wp_get_current_user();

		if ( ! $user->exists() ) {
			return;
		}

		if ( self::notifications_on() ) {
			( new Connect() )->render_account_section( $user->ID );
		}

		echo Screen::link_block( self::url() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped where it is built.
	}

	/**
	 * Whether the section has anything to show this user.
	 *
	 * @since 1.1.1
	 * @param \WP_User $user User.
	 * @return bool
	 */
	private static function has_content( $user ) {
		if ( ! $user instanceof \WP_User || ! $user->exists() ) {
			return false;
		}

		/*
		 * Without the bot's name there is no link to connect with, so a section
		 * built on notifications alone would be an empty page. Somebody already
		 * connected still needs it, for the disconnect button and the statuses.
		 */
		$notifications = self::notifications_on()
			&& ( '' !== Settings::bot_username() || '' !== Binding::of_user( $user->ID ) );

		return $notifications || Screen::offers_link( $user );
	}

	/**
	 * Whether customers can connect order updates at all.
	 *
	 * @since 1.1.1
	 * @return bool
	 */
	private static function notifications_on() {
		return Settings::module_enabled( CustomerModule::slug() ) && CustomerModule::requirements_met() && Settings::has_token();
	}
}
