<?php
/**
 * Queues Telegram deliveries.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Queue;

use MVweb\Telegram\Hub\Log\Repository;
use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Puts one job per recipient onto the queue.
 *
 * Nothing is sent on the checkout request itself: the shopper must never wait
 * for api.telegram.org. Action Scheduler ships with WooCommerce, so this adds
 * no new dependency and the queue is visible under WooCommerce → Status →
 * Scheduled Actions.
 *
 * @since 1.0.0
 */
final class Dispatcher {

	/**
	 * Action hook the worker listens on.
	 *
	 * @var string
	 */
	public const HOOK = 'mvweb_tg_send';

	/**
	 * Action Scheduler group.
	 *
	 * @var string
	 */
	public const GROUP = 'mvweb-tg';

	/**
	 * Queue a message for every configured recipient.
	 *
	 * @since 1.0.0
	 * @param string $module    Module slug that owns the message.
	 * @param int    $object_id Related object, e.g. an order id.
	 * @return int Number of jobs queued.
	 */
	public static function dispatch( $module, $object_id ) {
		$queued = 0;

		foreach ( Settings::recipients() as $chat_id ) {
			self::schedule(
				array(
					'module'    => (string) $module,
					'object_id' => absint( $object_id ),
					'chat_id'   => (string) $chat_id,
					'attempt'   => 1,
				),
				0
			);
			++$queued;
		}

		return $queued;
	}

	/**
	 * Schedule a single delivery job.
	 *
	 * The message text is not carried in the payload — the worker rebuilds it
	 * from the order, which keeps job arguments small and picks up template
	 * edits made between the order and the retry.
	 *
	 * @since 1.0.0
	 * @param array $payload Job payload.
	 * @param int   $delay   Seconds to wait before running.
	 * @return bool Whether the job made it onto a queue.
	 */
	public static function schedule( array $payload, $delay = 0 ) {
		$timestamp = time() + max( 0, (int) $delay );

		if ( function_exists( 'as_schedule_single_action' ) ) {
			$action_id = as_schedule_single_action( $timestamp, self::HOOK, array( $payload ), self::GROUP );

			if ( $action_id ) {
				return true;
			}

			/*
			 * Action Scheduler catches its own exceptions, writes a line to the
			 * PHP error log and answers 0. Without this the notification would
			 * simply never arrive and the delivery log would show nothing at all
			 * — the one failure mode the log exists to prevent. The usual cause
			 * is the 8000-byte ceiling on job arguments.
			 */
			Repository::add(
				array(
					'module'        => isset( $payload['module'] ) ? $payload['module'] : '',
					'object_id'     => isset( $payload['object_id'] ) ? $payload['object_id'] : 0,
					'chat_id'       => isset( $payload['chat_id'] ) ? $payload['chat_id'] : '',
					'attempt'       => isset( $payload['attempt'] ) ? $payload['attempt'] : 1,
					'status'        => Repository::STATUS_FAILED,
					'error_code'    => 0,
					'error_message' => __( 'The job could not be queued. Action Scheduler refused it — see the PHP error log for the reason.', 'mvweb-telegram-hub' ),
				)
			);

			return false;
		}

		// WooCommerce (and with it Action Scheduler) went away mid-flight.
		// WP-Cron is less reliable but better than dropping the notification.
		return false !== wp_schedule_single_event( $timestamp, self::HOOK, array( $payload ) );
	}

	/**
	 * Cancel every pending job of this plugin.
	 *
	 * Action Scheduler is asked by group with an empty hook: passing hook and
	 * group together sends it down the single-action path, which looks for a
	 * job with empty arguments and therefore never matches ours.
	 *
	 * WP-Cron is cleared with wp_unschedule_hook() rather than a
	 * wp_next_scheduled() loop, because that lookup keys on the arguments and
	 * would miss every event scheduled with a payload.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function cancel_all() {
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( '', array(), self::GROUP );
		}

		wp_unschedule_hook( self::HOOK );
	}
}
