<?php
/**
 * Executes queued Telegram deliveries.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Queue;

use MVweb\Telegram\Hub\Link\Binding;
use MVweb\Telegram\Hub\Log\Repository;
use MVweb\Telegram\Hub\Modules\Registry;
use MVweb\Telegram\Hub\Telegram\Client;
use MVweb\Telegram\Hub\Telegram\ErrorHint;
use MVweb\Telegram\Hub\Telegram\Formatter;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sends one queued message and decides whether to try again.
 *
 * @since 1.0.0
 */
final class Worker {

	/**
	 * Pause before each retry, in seconds.
	 *
	 * Three entries means the first send may be followed by three retries:
	 * after 1, 5 and 15 minutes.
	 *
	 * @var int[]
	 */
	private const RETRY_DELAYS = array( 60, 300, 900 );

	/**
	 * Hook the queue handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register() {
		add_action( Dispatcher::HOOK, array( $this, 'run' ), 10, 1 );
	}

	/**
	 * Handle one queued job.
	 *
	 * @since 1.0.0
	 * @param array $payload Job payload written by the dispatcher.
	 * @return void
	 */
	public function run( $payload ) {
		if ( ! is_array( $payload ) ) {
			return;
		}

		$module_slug = isset( $payload['module'] ) ? (string) $payload['module'] : '';
		$object_id   = isset( $payload['object_id'] ) ? absint( $payload['object_id'] ) : 0;
		$user_id     = isset( $payload['user_id'] ) ? absint( $payload['user_id'] ) : 0;
		$chat_id     = isset( $payload['chat_id'] ) ? (string) $payload['chat_id'] : '';
		$text        = isset( $payload['text'] ) ? (string) $payload['text'] : '';
		$attempt     = isset( $payload['attempt'] ) ? max( 1, absint( $payload['attempt'] ) ) : 1;

		/*
		 * Operator jobs name their recipient, because it comes from a settings
		 * list that has nothing to do with the order. Customer jobs leave it out
		 * and have it looked up here, at delivery: a job can sit in the queue for
		 * twenty minutes across its retries, and somebody who unsubscribed in
		 * that time must not receive the tail of it.
		 */
		if ( '' === $chat_id ) {
			$chat_id = '' !== $text
				? Binding::of_user( $user_id )
				: (string) apply_filters( 'mvweb_tg_resolve_chat', '', $module_slug, $object_id );
		}

		if ( '' === $chat_id ) {
			return;
		}

		if ( '' === $text ) {
			if ( ! $object_id ) {
				return;
			}

			$module = Registry::get( $module_slug );
			if ( ! $module ) {
				return;
			}

			$text = (string) $module->build_message( $object_id );
			if ( '' === $text ) {
				// The order is gone or the template renders empty — nothing to send.
				return;
			}
		}

		$client   = new Client();
		$response = $this->send( $client, $chat_id, $text, $payload );

		if ( ! empty( $response['ok'] ) ) {
			/**
			 * Fires after a message has been accepted by Telegram.
			 *
			 * The message id is worth having for anything that may later want
			 * to edit or remove what it sent: Telegram puts no time limit on
			 * editing a message of your own, and the id is the only way back
			 * to it. Nothing in the queue needs it, so it is handed over
			 * rather than stored here.
			 *
			 * @since 1.1.0
			 * @param array  $payload    Job payload that was delivered.
			 * @param string $chat_id    Recipient that took it.
			 * @param int    $message_id Identifier Telegram answered with.
			 */
			do_action(
				'mvweb_tg_sent',
				$payload,
				$chat_id,
				isset( $response['result']['message_id'] ) ? (int) $response['result']['message_id'] : 0
			);

			return;
		}

		$this->handle_failure( $payload, $attempt, $response, $chat_id );
	}

	/**
	 * Send one job the way its payload asks for.
	 *
	 * Three shapes, and the difference between them is where the picture goes.
	 * Any of them can carry a link button under it.
	 * A photo carries the text as its caption and is capped at 1024 characters;
	 * a link preview keeps all 4096 and puts the image above the text, which is
	 * what an article in a channel wants. Plain text is everything else.
	 *
	 * @since 1.1.0
	 * @param Client $client  Configured API client.
	 * @param string $chat_id Recipient.
	 * @param string $text    Message in Telegram HTML.
	 * @param array  $payload Job payload.
	 * @return array Normalised response.
	 */
	private function send( Client $client, $chat_id, $text, array $payload ) {
		$photo  = isset( $payload['photo'] ) ? (string) $payload['photo'] : '';
		$button = isset( $payload['button'] ) && is_array( $payload['button'] ) ? $payload['button'] : array();

		if ( '' !== $photo ) {
			// Only here is it known that the text is a caption, and a caption is
			// a quarter of a message. Cutting it anywhere earlier would be a
			// guess about a picture that may have changed since.
			return $client->send_photo( $chat_id, $photo, Formatter::truncate( $text, Formatter::CAPTION_LIMIT ), $button );
		}

		$preview = isset( $payload['preview'] ) ? (string) $payload['preview'] : '';

		if ( '' === $preview ) {
			return $client->send_message( $chat_id, $text, array(), $button );
		}

		return $client->send_message(
			$chat_id,
			$text,
			array(
				'url'                => $preview,
				'prefer_large_media' => true,
				'show_above_text'    => true,
			),
			$button
		);
	}

	/**
	 * Log a failed attempt and re-queue it when that can help.
	 *
	 * @since 1.0.0
	 * @param array  $payload  Original job payload.
	 * @param int    $attempt  Attempt number that just failed.
	 * @param array  $response Normalised client response.
	 * @param string $chat_id  Recipient this attempt was addressed to.
	 * @return void
	 */
	private function handle_failure( array $payload, $attempt, array $response, $chat_id ) {
		$retryable   = ! empty( $response['retryable'] );
		$has_retries = $attempt <= count( self::RETRY_DELAYS );
		$will_retry  = $retryable && $has_retries;

		Repository::add(
			array(
				'module'        => isset( $payload['module'] ) ? $payload['module'] : '',
				'object_id'     => isset( $payload['object_id'] ) ? $payload['object_id'] : 0,
				'chat_id'       => $chat_id,
				'attempt'       => $attempt,
				'status'        => $will_retry ? Repository::STATUS_RETRY : Repository::STATUS_FAILED,
				'error_code'    => isset( $response['error_code'] ) ? $response['error_code'] : 0,
				'error_message' => isset( $response['description'] ) ? $response['description'] : '',
			)
		);

		/*
		 * A customer who blocked the bot would otherwise keep producing a failed
		 * row on every status change, for ever: nothing else ever tells us the
		 * chat is dead if they place no further orders. Matched on Telegram's own
		 * wording and not on the bare 403, so a proxy or a WAF answering in its
		 * place cannot take a live binding down. Operator recipients live in the
		 * settings list and are not touched by this.
		 */
		if ( ErrorHint::is_dead_chat(
			isset( $response['error_code'] ) ? $response['error_code'] : 0,
			isset( $response['description'] ) ? $response['description'] : ''
		) ) {
			Binding::unbind_chat( $chat_id );
		}

		if ( ! $will_retry ) {
			return;
		}

		$delay = self::RETRY_DELAYS[ $attempt - 1 ];

		// Telegram knows better than we do how long it wants us to wait.
		if ( ! empty( $response['retry_after'] ) ) {
			$delay = max( $delay, (int) $response['retry_after'] );
		}

		$payload['attempt'] = $attempt + 1;

		Dispatcher::schedule( $payload, $delay );
	}
}
