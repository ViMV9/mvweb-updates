<?php
/**
 * Settings sanitisation.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Admin;

use MVweb\Telegram\Hub\Auth\Users;
use MVweb\Telegram\Hub\Settings;
use MVweb\Telegram\Hub\Telegram\Client;
use MVweb\Telegram\Hub\Telegram\Formatter;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cleans everything that arrives from the settings screen.
 *
 * Each tab posts its own form, so the incoming array only carries the keys of
 * that tab. Values are therefore merged over what is already stored instead of
 * replacing the whole option — otherwise saving one tab would blank the rest.
 *
 * @since 1.0.0
 */
final class Sanitizer {

	/**
	 * Guard against WordPress calling the sanitiser twice in one request.
	 *
	 * @var bool
	 */
	private static $token_checked = false;

	/**
	 * Sanitise the posted settings.
	 *
	 * @since 1.0.0
	 * @param mixed $input Raw value from the form.
	 * @return array Full option array, ready to store.
	 */
	public static function sanitize( $input ) {
		$stored = Settings::all();
		$input  = is_array( $input ) ? $input : array();
		$clean  = $stored;

		// The API address is resolved first: both fields live on the same tab,
		// and verifying the token against the previous host would report a
		// false failure exactly where a custom proxy is being set up.
		if ( array_key_exists( 'api_base', $input ) ) {
			$clean['api_base'] = self::api_base( $input['api_base'] );
		}

		if ( array_key_exists( 'bot_token', $input ) ) {
			$clean['bot_token'] = self::token( $input['bot_token'], $stored['bot_token'], $clean['api_base'] );
		}

		if ( array_key_exists( 'modules', $input ) ) {
			$clean['modules'] = self::modules( $input['modules'] );
		}

		if ( array_key_exists( 'recipients', $input ) ) {
			$clean['recipients'] = self::recipients( $input['recipients'] );
		}

		if ( array_key_exists( 'order_template', $input ) ) {
			$clean['order_template'] = self::template( $input['order_template'] );
		}

		if ( array_key_exists( 'items_limit', $input ) ) {
			$clean['items_limit'] = self::in_range( $input['items_limit'], 1, 50, 10 );
		}

		if ( array_key_exists( 'log_days', $input ) ) {
			$clean['log_days'] = self::in_range( $input['log_days'], 1, 365, 30 );
		}

		if ( array_key_exists( 'delete_data', $input ) ) {
			$clean['delete_data'] = (bool) $input['delete_data'];
		}

		if ( array_key_exists( 'customer_statuses', $input ) ) {
			$clean['customer_statuses'] = self::customer_statuses( $input['customer_statuses'] );
		}

		if ( array_key_exists( 'channels', $input ) ) {
			$clean['channels'] = self::recipients(
				$input['channels'],
				'mvweb_tg_channels',
				/* translators: %s: comma-separated list of rejected values. */
				__( 'These channels were skipped — expected a chat number or an @name: %s', 'mvweb-telegram-hub' )
			);
		}

		if ( array_key_exists( 'post_types', $input ) ) {
			$clean['post_types'] = self::post_types( $input['post_types'] );
		}

		if ( array_key_exists( 'login_roles', $input ) ) {
			$clean['login_roles'] = self::login_roles( $input['login_roles'] );
		}

		if ( array_key_exists( 'post_terms', $input ) ) {
			$clean['post_terms'] = self::post_terms( $input['post_terms'] );
		}

		if ( array_key_exists( 'post_template', $input ) ) {
			$clean['post_template'] = self::template( $input['post_template'] );
		}

		if ( array_key_exists( 'post_delay', $input ) ) {
			$clean['post_delay'] = min( 10080, max( 0, absint( $input['post_delay'] ) ) );
		}

		if ( array_key_exists( 'post_photo', $input ) ) {
			$clean['post_photo'] = in_array( $input['post_photo'], array( 'preview', 'photo', 'none' ), true )
				? $input['post_photo']
				: 'preview';
		}

		if ( array_key_exists( 'post_excerpt_length', $input ) ) {
			$clean['post_excerpt_length'] = self::in_range( $input['post_excerpt_length'], 100, 3000, 600 );
		}

		if ( array_key_exists( 'post_button', $input ) ) {
			$clean['post_button'] = mb_substr( sanitize_text_field( (string) $input['post_button'] ), 0, 64 );
		}

		foreach ( array( 'login_enabled', 'login_register', 'login_register_closed', 'post_text_field' ) as $flag ) {
			if ( array_key_exists( $flag, $input ) ) {
				$clean[ $flag ] = (bool) $input[ $flag ];
			}
		}

		if ( array_key_exists( 'login_client_id', $input ) ) {
			$clean['login_client_id'] = trim( sanitize_text_field( (string) $input['login_client_id'] ) );
		}

		/*
		 * The client secret is written to a row of its own and never becomes
		 * part of this array. Unsetting the key matters: update_option() calls
		 * the sanitiser again through add_option() the first time an option is
		 * created, and the second pass is fed whatever the first one returned.
		 */
		if ( array_key_exists( 'login_client_secret', $input ) ) {
			self::login_secret( $input['login_client_secret'] );
		}

		unset( $clean['login_client_secret'] );

		Settings::flush_cache();

		return $clean;
	}

	/**
	 * Store the OpenID Connect client secret.
	 *
	 * Empty means "leave it as it is", the same bargain the bot token field
	 * makes, so a credential never has to be printed back into a page just to
	 * survive a save.
	 *
	 * @since 1.1.0
	 * @param mixed $value Posted value.
	 * @return void
	 */
	private static function login_secret( $value ) {
		$value = trim( sanitize_text_field( (string) $value ) );

		if ( '' === $value || Settings::login_secret_is_constant() ) {
			return;
		}

		update_option( Settings::LOGIN_SECRET_OPTION, $value, false );
	}

	/**
	 * Validate the bot token and verify it against Telegram.
	 *
	 * An empty field means "leave it as it is", so the token never has to be
	 * rendered back into the page just to survive a save.
	 *
	 * @since 1.0.0
	 * @param mixed  $value    Posted value.
	 * @param string $existing Currently stored token.
	 * @param string $api_base API address being saved in the same request.
	 * @return string
	 */
	private static function token( $value, $existing, $api_base ) {
		$value = trim( sanitize_text_field( (string) $value ) );

		if ( '' === $value ) {
			return (string) $existing;
		}

		if ( ! preg_match( '/^\d{5,}:[A-Za-z0-9_-]{30,}$/', $value ) ) {
			add_settings_error(
				Page::NOTICE_SLUG,
				'mvweb_tg_token_format',
				__( 'That does not look like a bot token. Expected the format 1234567890:AA…, as issued by @BotFather.', 'mvweb-telegram-hub' ),
				'error'
			);
			return (string) $existing;
		}

		self::verify_token( $value, $api_base );

		return $value;
	}

	/**
	 * Ask Telegram who the token belongs to.
	 *
	 * A failure is reported but never blocks the save: on a host where
	 * Telegram is unreachable, blocking would make the settings unchangeable.
	 *
	 * @since 1.0.0
	 * @param string $token    Validated token.
	 * @param string $api_base API address to verify against.
	 * @return void
	 */
	private static function verify_token( $token, $api_base ) {
		if ( self::$token_checked ) {
			return;
		}
		self::$token_checked = true;

		$host = '' === $api_base ? null : $api_base;

		$response = ( new Client( $token, $host ) )->get_me();

		if ( empty( $response['ok'] ) ) {
			Settings::forget_bot();

			// The description comes from whatever host api_base points at, and
			// add_settings_error() output is printed by core as raw HTML.
			add_settings_error(
				Page::NOTICE_SLUG,
				'mvweb_tg_token_unverified',
				sprintf(
					/* translators: %s: error description from Telegram. */
					__( 'The token was saved, but Telegram did not accept it: %s', 'mvweb-telegram-hub' ),
					$response['description'] ? esc_html( $response['description'] ) : __( 'no response', 'mvweb-telegram-hub' )
				),
				'warning'
			);
			return;
		}

		$bot = array(
			'id'       => isset( $response['result']['id'] ) ? (int) $response['result']['id'] : 0,
			'username' => isset( $response['result']['username'] ) ? (string) $response['result']['username'] : '',
		);

		Settings::remember_bot( $bot );

		add_settings_error(
			Page::NOTICE_SLUG,
			'mvweb_tg_token_ok',
			sprintf(
				/* translators: %s: bot username. */
				__( 'Connected to @%s.', 'mvweb-telegram-hub' ),
				esc_html( $bot['username'] )
			),
			'success'
		);
	}

	/**
	 * Validate a custom API base URL.
	 *
	 * @since 1.0.0
	 * @param mixed $value Posted value.
	 * @return string Empty string means "use the default host".
	 */
	private static function api_base( $value ) {
		$value = trim( (string) $value );

		if ( '' === $value ) {
			return '';
		}

		$url = esc_url_raw( $value, array( 'https' ) );

		if ( '' === $url ) {
			add_settings_error(
				Page::NOTICE_SLUG,
				'mvweb_tg_api_base',
				__( 'The API address must be a full https:// URL. Falling back to api.telegram.org.', 'mvweb-telegram-hub' ),
				'error'
			);
			return '';
		}

		return untrailingslashit( $url );
	}

	/**
	 * Normalise the module toggles.
	 *
	 * A toggle that was not on the screen keeps its stored value: the shop
	 * modules are hidden while WooCommerce is off, and switching it off for an
	 * update must not switch them off too.
	 *
	 * @since 1.0.0
	 * @param mixed $value Posted value.
	 * @return array<string, bool>
	 */
	private static function modules( $value ) {
		$value  = is_array( $value ) ? $value : array();
		$result = array();

		foreach ( array_keys( \MVweb\Telegram\Hub\Modules\Registry::labels() ) as $slug ) {
			$result[ $slug ] = array_key_exists( $slug, $value ) ? ! empty( $value[ $slug ] ) : Settings::module_enabled( $slug );
		}

		return $result;
	}

	/**
	 * Parse the recipients textarea.
	 *
	 * Accepts numeric chat ids (negative ones for groups and channels) and
	 * public channel handles. Anything else is reported and dropped.
	 *
	 * The value arrives as the raw textarea, but WordPress runs the sanitiser a
	 * second time inside update_option() — and by then it is the array this
	 * method returned. Casting that to a string yields the literal "Array",
	 * which then fails validation and reports itself as a rejected recipient.
	 *
	 * Shared with the channel list, which is the same kind of value under a
	 * different name and needs its own wording when something is rejected.
	 *
	 * @since 1.0.0
	 * @since 1.1.0 Takes the error identity, so a second list can use it.
	 * @param mixed  $value  Posted textarea, or the already parsed list.
	 * @param string $code   Identifier of the settings error.
	 * @param string $notice Message with one %s for the rejected values.
	 * @return string[]
	 */
	private static function recipients( $value, $code = 'mvweb_tg_recipients', $notice = '' ) {
		$lines   = is_array( $value ) ? $value : preg_split( '/\R/u', (string) $value );
		$clean   = array();
		$invalid = array();

		foreach ( (array) $lines as $line ) {
			$line = trim( sanitize_text_field( $line ) );

			if ( '' === $line ) {
				continue;
			}

			if ( ! preg_match( '/^(-?\d+|@[A-Za-z][A-Za-z0-9_]{4,31})$/', $line ) ) {
				$invalid[] = $line;
				continue;
			}

			if ( ! in_array( $line, $clean, true ) ) {
				$clean[] = $line;
			}
		}

		if ( $invalid ) {
			add_settings_error(
				Page::NOTICE_SLUG,
				$code,
				sprintf(
					/* translators: %s: comma-separated list of rejected values. */
					'' !== $notice ? $notice : __( 'These recipients were skipped — expected a chat number or an @name: %s', 'mvweb-telegram-hub' ),
					implode( ', ', array_map( 'esc_html', $invalid ) )
				),
				'error'
			);
		}

		return $clean;
	}

	/**
	 * Keep only order statuses WooCommerce actually knows.
	 *
	 * The list is checked against wc_get_order_statuses() rather than a
	 * hardcoded seven, so statuses added by other plugins through the
	 * wc_order_statuses filter can be ticked as well.
	 *
	 * @since 1.1.0
	 * @param mixed $value Posted value.
	 * @return string[]
	 */
	private static function customer_statuses( $value ) {
		$value = is_array( $value ) ? $value : array();
		$known = function_exists( 'wc_get_order_statuses' ) ? array_keys( wc_get_order_statuses() ) : array();

		// Without WooCommerce there is nothing to validate against, and dropping
		// everything would silently wipe the operator's choice.
		if ( ! $known ) {
			return array_values( array_unique( array_map( 'sanitize_key', $value ) ) );
		}

		return array_values( array_intersect( $known, array_map( 'sanitize_key', $value ) ) );
	}

	/**
	 * Keep only post types the site actually has and shows.
	 *
	 * Checked against the registered list rather than a fixed pair, so a custom
	 * type can be announced too. Types that are not public are dropped: a
	 * channel is public, and something WordPress hides has no business there.
	 *
	 * @since 1.1.0
	 * @param mixed $value Posted value.
	 * @return string[]
	 */
	private static function post_types( $value ) {
		$value = is_array( $value ) ? $value : array();
		$known = get_post_types( array( 'public' => true ), 'names' );

		unset( $known['attachment'] );

		return array_values( array_intersect( $known, array_map( 'sanitize_key', $value ) ) );
	}

	/**
	 * Keep only roles that may be offered at all.
	 *
	 * @since 1.1.0
	 * @param mixed $value Posted value.
	 * @return string[]
	 */
	private static function login_roles( $value ) {
		$value = is_array( $value ) ? $value : array();

		return array_values( array_intersect( array_keys( Users::eligible_roles() ), array_map( 'sanitize_key', $value ) ) );
	}

	/**
	 * Keep only categories that exist.
	 *
	 * @since 1.1.0
	 * @param mixed $value Posted value.
	 * @return int[]
	 */
	private static function post_terms( $value ) {
		$value = is_array( $value ) ? $value : array();
		$clean = array();

		foreach ( $value as $term_id ) {
			$term_id = absint( $term_id );

			if ( $term_id && get_term( $term_id, 'category' ) instanceof \WP_Term ) {
				$clean[] = $term_id;
			}
		}

		return array_values( array_unique( $clean ) );
	}

	/**
	 * Clean the message template.
	 *
	 * Only tags Telegram understands survive; anything else would make the API
	 * reject every notification.
	 *
	 * @since 1.0.0
	 * @param mixed $value Posted value.
	 * @return string
	 */
	private static function template( $value ) {
		// options.php already unslashed the value before update_option() reached
		// this callback; unslashing twice would eat the operator's backslashes.
		return trim( wp_kses( (string) $value, Formatter::allowed_tags() ) );
	}

	/**
	 * Clamp an integer into a range.
	 *
	 * @since 1.0.0
	 * @param mixed $value    Posted value.
	 * @param int   $min      Lower bound.
	 * @param int   $max      Upper bound.
	 * @param int   $fallback Used when the value is empty.
	 * @return int
	 */
	private static function in_range( $value, $min, $max, $fallback ) {
		$value = absint( $value );

		if ( ! $value ) {
			return $fallback;
		}

		return max( $min, min( $max, $value ) );
	}
}
