<?php
/**
 * Admin-post handlers for the diagnostic buttons.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Admin;

use MVweb\Telegram\Hub\Auth\Provider;
use MVweb\Telegram\Hub\Log\Repository;
use MVweb\Telegram\Hub\Modules\Registry;
use MVweb\Telegram\Hub\Modules\WooOrders;
use MVweb\Telegram\Hub\Rest\Webhook;
use MVweb\Telegram\Hub\Settings;
use MVweb\Telegram\Hub\Telegram\Client;
use MVweb\Telegram\Hub\Telegram\ErrorHint;
use MVweb\Telegram\Hub\Telegram\Formatter;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Buttons that do something instead of saving something.
 *
 * Plain admin-post.php forms rather than AJAX: nonce and capability checks
 * stay in the boring, well-trodden path.
 *
 * @since 1.0.0
 */
final class Actions {

	/**
	 * Transient prefix used to carry a result across the redirect.
	 *
	 * @var string
	 */
	private const NOTICE_PREFIX = 'mvweb_tg_notice_';

	/**
	 * Hook every handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register() {
		add_action( 'admin_post_mvweb_tg_discover', array( $this, 'discover_chats' ) );
		add_action( 'admin_post_mvweb_tg_verify', array( $this, 'verify_recipients' ) );
		add_action( 'admin_post_mvweb_tg_test', array( $this, 'send_test' ) );
		add_action( 'admin_post_mvweb_tg_clear_log', array( $this, 'clear_log' ) );
		add_action( 'admin_post_mvweb_tg_delete_token', array( $this, 'delete_token' ) );
		add_action( 'admin_post_mvweb_tg_webhook_on', array( $this, 'enable_webhook' ) );
		add_action( 'admin_post_mvweb_tg_webhook_off', array( $this, 'disable_webhook' ) );
		add_action( 'admin_post_mvweb_tg_login_check', array( $this, 'check_login' ) );
		add_action( 'admin_post_mvweb_tg_login_forget', array( $this, 'forget_login_secret' ) );
	}

	/**
	 * Ask oauth.telegram.org whether this server can reach it.
	 *
	 * Only half the answer, and the settings screen says so: the visitor's
	 * browser has to reach the same host, and that is a different network.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function check_login() {
		$this->guard( 'mvweb_tg_login_check' );

		$result = Provider::check();

		$this->finish(
			array(
				'type'    => $result['ok'] ? 'success' : 'error',
				'message' => $result['message'],
				'rows'    => array(),
			),
			'login'
		);
	}

	/**
	 * Forget the stored client secret.
	 *
	 * A plain delete_option: unlike the bot token, the secret was never part of
	 * the settings array, so there is no sanitiser to work around.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function forget_login_secret() {
		$this->guard( 'mvweb_tg_login_forget' );

		delete_option( Settings::LOGIN_SECRET_OPTION );

		$this->finish(
			array(
				'type'    => 'success',
				'message' => __( 'The client secret has been removed. Signing in with Telegram is off until a new one is saved.', 'mvweb-telegram-hub' ),
				'rows'    => array(),
			),
			'login'
		);
	}

	/**
	 * Ask Telegram to deliver commands to this site.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function enable_webhook() {
		$this->guard( 'mvweb_tg_webhook_on' );

		$result = Webhook::enable();

		$this->finish(
			array(
				'type'    => $result['ok'] ? 'success' : 'error',
				'message' => $result['message'],
				'rows'    => array(),
			),
			'bot'
		);
	}

	/**
	 * Stop accepting commands.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function disable_webhook() {
		$this->guard( 'mvweb_tg_webhook_off' );

		Webhook::disable();

		$this->finish(
			array(
				'type'    => 'success',
				'message' => __( 'Commands from Telegram are no longer accepted. Customers who are already connected keep receiving notifications; new ones cannot connect.', 'mvweb-telegram-hub' ),
				'rows'    => array(),
			),
			'bot'
		);
	}

	/**
	 * List the chats the bot has seen, with their ids.
	 *
	 * A private channel has no @name to address it by, and its numeric id is
	 * nowhere in the Telegram interface. Asking the Bot API is the only way
	 * that does not send the operator to a third-party bot.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function discover_chats() {
		$this->guard( 'mvweb_tg_discover' );

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- verified by guard() above.
		$tab = isset( $_GET['tab'] ) && 'channels' === sanitize_key( wp_unslash( $_GET['tab'] ) ) ? 'channels' : 'orders';

		$client   = new Client();
		$response = $client->get_updates();

		if ( empty( $response['ok'] ) ) {
			$this->finish(
				array(
					'type'    => 'error',
					'message' => $this->error_text( $response ),
					'hint'    => ErrorHint::get(
						isset( $response['error_code'] ) ? $response['error_code'] : 0,
						isset( $response['description'] ) ? $response['description'] : ''
					),
					'rows'    => array(),
				),
				$tab
			);
		}

		$chats = $this->chats_from_updates( is_array( $response['result'] ) ? $response['result'] : array() );

		if ( ! $chats ) {
			$this->finish(
				array(
					'type'    => 'warning',
					'message' => __( 'No chats found yet.', 'mvweb-telegram-hub' ),
					'hint'    => $this->discovery_hint(),
					'rows'    => array(),
				),
				$tab
			);
		}

		$rows = array();

		foreach ( $chats as $chat_id => $title ) {
			$rows[] = array(
				'chat' => (string) $chat_id,
				'ok'   => true,
				'text' => $title,
				'hint' => '',
			);
		}

		$this->finish(
			array(
				'type'    => 'info',
				'message' => __( 'Chats the bot can see', 'mvweb-telegram-hub' ),
				'hint'    => __( 'Copy the number you need into the list on this tab and save. Telegram keeps these events for 24 hours, so an old chat may be missing — write something in it and press the button again.', 'mvweb-telegram-hub' ),
				'rows'    => $rows,
			),
			$tab
		);
	}

	/**
	 * Resolve every recipient through getChat and report what came back.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function verify_recipients() {
		$this->guard( 'mvweb_tg_verify' );

		$client = new Client();
		$rows   = array();

		foreach ( Settings::recipients() as $chat_id ) {
			$response = $client->get_chat( $chat_id );

			$rows[] = $this->row(
				$chat_id,
				$response,
				! empty( $response['ok'] ) ? $this->chat_title( $response['result'] ) : ''
			);
		}

		$this->finish(
			array(
				'type'          => 'info',
				'message'       => __( 'Recipient check', 'mvweb-telegram-hub' ),
				'rows'          => $rows,
				'per_recipient' => true,
			),
			'orders'
		);
	}

	/**
	 * Send a test message to every recipient.
	 *
	 * Sent synchronously, not through the queue: the operator is standing in
	 * front of the screen waiting for the answer.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function send_test() {
		$this->guard( 'mvweb_tg_test' );

		$client = new Client();
		$rows   = array();
		$text   = $this->test_text();

		$delivered = false;

		foreach ( Settings::recipients() as $chat_id ) {
			$response = $client->send_message( $chat_id, $text );

			$rows[]    = $this->row( $chat_id, $response, __( 'Delivered', 'mvweb-telegram-hub' ) );
			$delivered = $delivered || ! empty( $response['ok'] );
		}

		if ( $delivered ) {
			Setup::mark_test_passed();
		}

		$this->finish(
			array(
				'type'          => 'info',
				'message'       => __( 'Test message', 'mvweb-telegram-hub' ),
				'rows'          => $rows,
				'per_recipient' => true,
			),
			'orders'
		);
	}

	/**
	 * Empty the delivery log.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function clear_log() {
		$this->guard( 'mvweb_tg_clear_log' );

		Repository::clear();

		$this->finish(
			array(
				'type'    => 'success',
				'message' => __( 'The delivery log is empty.', 'mvweb-telegram-hub' ),
				'rows'    => array(),
			),
			'log'
		);
	}

	/**
	 * Forget the stored bot token.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function delete_token() {
		$this->guard( 'mvweb_tg_delete_token' );

		// The webhook belongs to the bot, not to the site: leaving it registered
		// would keep Telegram posting updates the site can no longer answer, and
		// would block getUpdates for whoever picks the bot up next. It has to go
		// before the token does — removing it needs the token.
		Webhook::disable();

		$settings              = Settings::all();
		$settings['bot_token'] = '';

		/*
		 * Written past the settings sanitiser on purpose. An empty token field
		 * means "leave it as it is" — that is form behaviour, so that the token
		 * never has to be printed back into the page just to survive a save —
		 * and update_option() runs the same sanitiser through
		 * sanitize_option_{$option}. Going the ordinary way here would hand the
		 * old token straight back and this button would report success while
		 * changing nothing.
		 */
		remove_filter( 'sanitize_option_' . Settings::OPTION, array( Sanitizer::class, 'sanitize' ) );
		update_option( Settings::OPTION, $settings );
		add_filter( 'sanitize_option_' . Settings::OPTION, array( Sanitizer::class, 'sanitize' ) );

		Settings::forget_bot();
		Settings::flush_cache();

		$this->finish(
			array(
				'type'    => 'success',
				'message' => __( 'The bot token has been removed.', 'mvweb-telegram-hub' ),
				'rows'    => array(),
			),
			'bot'
		);
	}

	/**
	 * Store the pending notice for the current user and consume it.
	 *
	 * @since 1.0.0
	 * @return array|null
	 */
	public static function pull_notice() {
		$key    = self::NOTICE_PREFIX . get_current_user_id();
		$notice = get_transient( $key );

		if ( ! $notice ) {
			return null;
		}

		delete_transient( $key );

		return is_array( $notice ) ? $notice : null;
	}

	/**
	 * Verify nonce and capability, or stop right here.
	 *
	 * @since 1.0.0
	 * @param string $action Nonce action.
	 * @return void
	 */
	private function guard( $action ) {
		if ( ! current_user_can( Page::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'mvweb-telegram-hub' ), '', array( 'response' => 403 ) );
		}

		check_admin_referer( $action );
	}

	/**
	 * Save the result and go back to the settings screen.
	 *
	 * @since 1.0.0
	 * @param array  $notice Notice payload.
	 * @param string $tab    Tab to reopen.
	 * @return void
	 */
	private function finish( array $notice, $tab ) {
		set_transient( self::NOTICE_PREFIX . get_current_user_id(), $notice, 5 * MINUTE_IN_SECONDS );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page' => MVWEB_TG_SLUG,
					'tab'  => $tab,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Human-readable chat name from a getChat result.
	 *
	 * @since 1.0.0
	 * @param array $chat Chat object from Telegram.
	 * @return string
	 */
	private function chat_title( array $chat ) {
		foreach ( array( 'title', 'username', 'first_name' ) as $key ) {
			if ( ! empty( $chat[ $key ] ) ) {
				return (string) $chat[ $key ];
			}
		}

		return __( 'Chat found', 'mvweb-telegram-hub' );
	}

	/**
	 * Body of the test message.
	 *
	 * Built from the real template on the most recent order, so the button
	 * answers "how will my message look" and not merely "does the connection
	 * work". Falls back to a plain line on a shop with no orders yet.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private function test_text() {
		$intro = sprintf(
			/* translators: %s: site title. */
			__( 'Test message from %s', 'mvweb-telegram-hub' ),
			Formatter::escape( get_bloginfo( 'name' ) )
		);

		$module = Registry::get( WooOrders\Module::slug() );
		$order  = $module ? $this->latest_order_id() : 0;

		if ( ! $order ) {
			return '<b>MVweb Telegram Hub</b>' . "\n" . $intro;
		}

		$preview = $module->build_message( $order );

		if ( null === $preview || '' === trim( $preview ) ) {
			return '<b>MVweb Telegram Hub</b>' . "\n" . $intro;
		}

		return '<b>' . $intro . '</b>' . "\n" . __( 'This is how a new order will look:', 'mvweb-telegram-hub' ) . "\n\n" . $preview;
	}

	/**
	 * Id of the most recent order, or 0 when the shop has none.
	 *
	 * @since 1.0.0
	 * @return int
	 */
	private function latest_order_id() {
		if ( ! function_exists( 'wc_get_orders' ) ) {
			return 0;
		}

		$orders = wc_get_orders(
			array(
				'limit'   => 1,
				'orderby' => 'date',
				'order'   => 'DESC',
				'return'  => 'ids',
			)
		);

		return $orders ? (int) $orders[0] : 0;
	}

	/**
	 * Unique chats mentioned anywhere in a batch of updates.
	 *
	 * Every update type is walked, not just messages: being promoted to
	 * administrator of a channel arrives as my_chat_member, and for a channel
	 * nobody writes in that is the only event there will ever be.
	 *
	 * @since 1.0.0
	 * @param array $updates Update objects from getUpdates.
	 * @return array Chat id => human readable title.
	 */
	private function chats_from_updates( array $updates ) {
		$chats = array();

		foreach ( $updates as $update ) {
			if ( ! is_array( $update ) ) {
				continue;
			}

			foreach ( $update as $payload ) {
				if ( ! is_array( $payload ) || empty( $payload['chat']['id'] ) ) {
					continue;
				}

				$chat = $payload['chat'];
				$id   = (string) $chat['id'];

				if ( isset( $chats[ $id ] ) ) {
					continue;
				}

				$chats[ $id ] = $this->chat_label( $chat );
			}
		}

		return $chats;
	}

	/**
	 * Readable "name (kind)" for a chat object.
	 *
	 * @since 1.0.0
	 * @param array $chat Chat object from Telegram.
	 * @return string
	 */
	private function chat_label( array $chat ) {
		$name = $this->chat_title( $chat );
		$kind = isset( $chat['type'] ) ? (string) $chat['type'] : '';

		$kinds = array(
			'private'    => __( 'private chat', 'mvweb-telegram-hub' ),
			'group'      => __( 'group', 'mvweb-telegram-hub' ),
			'supergroup' => __( 'group', 'mvweb-telegram-hub' ),
			'channel'    => __( 'channel', 'mvweb-telegram-hub' ),
		);

		if ( isset( $kinds[ $kind ] ) ) {
			return sprintf( '%s — %s', $name, $kinds[ $kind ] );
		}

		return $name;
	}

	/**
	 * Why discovery came back empty.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private function discovery_hint() {
		return __( 'Write something to the bot from the account that should receive messages, or add it to the group or channel — then press the button again. Telegram only reports chats the bot has taken part in.', 'mvweb-telegram-hub' );
	}

	/**
	 * One line of a diagnostic report.
	 *
	 * A failure carries the advice too: "403 — Forbidden: bot was blocked by
	 * the user" is a fact, not something the shop owner can act on.
	 *
	 * @since 1.0.0
	 * @param string $chat_id  Recipient.
	 * @param array  $response Normalised client response.
	 * @param string $ok_text  Text to show when the call succeeded.
	 * @return array
	 */
	private function row( $chat_id, array $response, $ok_text ) {
		if ( ! empty( $response['ok'] ) ) {
			return array(
				'chat' => $chat_id,
				'ok'   => true,
				'text' => '' !== $ok_text ? $ok_text : __( 'Chat found', 'mvweb-telegram-hub' ),
				'hint' => '',
			);
		}

		return array(
			'chat' => $chat_id,
			'ok'   => false,
			'text' => $this->error_text( $response ),
			'hint' => ErrorHint::get(
				isset( $response['error_code'] ) ? $response['error_code'] : 0,
				isset( $response['description'] ) ? $response['description'] : ''
			),
		);
	}

	/**
	 * Readable error line from a client response.
	 *
	 * @since 1.0.0
	 * @param array $response Normalised client response.
	 * @return string
	 */
	private function error_text( array $response ) {
		$description = isset( $response['description'] ) ? (string) $response['description'] : '';
		$code        = isset( $response['error_code'] ) ? (int) $response['error_code'] : 0;

		if ( '' === $description ) {
			$description = __( 'Unknown error', 'mvweb-telegram-hub' );
		}

		return $code ? sprintf( '%d — %s', $code, $description ) : $description;
	}
}
