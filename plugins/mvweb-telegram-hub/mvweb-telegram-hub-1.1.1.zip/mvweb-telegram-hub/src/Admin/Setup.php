<?php
/**
 * Setup progress shown at the top of the settings screen.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Admin;

use MVweb\Telegram\Hub\Modules\Posts\Module as PostsModule;
use MVweb\Telegram\Hub\Modules\WooCustomer\Module as CustomerModule;
use MVweb\Telegram\Hub\Modules\WooOrders\Module;
use MVweb\Telegram\Hub\Rest\Webhook;
use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tells the operator where they are in the setup.
 *
 * Connecting the plugin takes four steps across two tabs, and each one is saved
 * on its own. Without a map of it the screen answers neither "what now" nor
 * "did the last save actually land".
 *
 * @since 1.0.0
 */
final class Setup {

	/**
	 * Option holding the time of the last successful test message.
	 *
	 * Kept out of the settings array: it is a fact about the site, not a
	 * setting, and it must not travel through the settings sanitiser.
	 *
	 * @var string
	 */
	public const TEST_OPTION = 'mvweb_tg_test_passed';

	/**
	 * Remember that a test message reached at least one recipient.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function mark_test_passed() {
		update_option( self::TEST_OPTION, time(), false );
	}

	/**
	 * The steps, in the order they are meant to be done.
	 *
	 * Four of them always, plus one more once the shop offers customers a
	 * Telegram connect button of their own. Without WooCommerce there are no
	 * orders, and the card leads to the channel instead.
	 *
	 * @since 1.0.0
	 * @return array[] Each step: title, done, detail, tab.
	 */
	public static function steps() {
		$bot       = get_transient( 'mvweb_tg_bot_info' );
		$has_token = '' !== Settings::token();
		$bot_name  = is_array( $bot ) && ! empty( $bot['username'] ) ? '@' . $bot['username'] : '';

		$bot_step = array(
			'title'  => __( 'Connect a bot', 'mvweb-telegram-hub' ),
			'done'   => $has_token,
			'tab'    => 'bot',
			'detail' => $has_token
				? ( '' !== $bot_name
					/* translators: %s: bot username. */
					? sprintf( __( 'Bot %s is connected.', 'mvweb-telegram-hub' ), $bot_name )
					: __( 'The token is saved.', 'mvweb-telegram-hub' ) )
				: __( 'Create a bot with @BotFather and paste its token below.', 'mvweb-telegram-hub' ),
		);

		if ( ! class_exists( 'WooCommerce' ) ) {
			return self::blog_steps( $bot_step );
		}

		$recipients  = Settings::recipients();
		$module_on   = Settings::module_enabled( Module::slug() );
		$woo_ok      = Module::requirements_met();
		$tested      = (int) get_option( self::TEST_OPTION, 0 );
		$customer_on = Settings::module_enabled( CustomerModule::slug() ) && CustomerModule::requirements_met();

		$steps = array(
			$bot_step,
			array(
				'title'  => __( 'Add recipients', 'mvweb-telegram-hub' ),
				'done'   => (bool) $recipients,
				'tab'    => 'orders',
				'detail' => $recipients
					? sprintf(
						/* translators: %d: number of recipients. */
						_n( '%d chat will receive orders.', '%d chats will receive orders.', count( $recipients ), 'mvweb-telegram-hub' ),
						count( $recipients )
					)
					: __( 'Say who gets a message about a new order.', 'mvweb-telegram-hub' ),
			),
			array(
				'title'  => __( 'Switch order notifications on', 'mvweb-telegram-hub' ),
				'done'   => $module_on && $woo_ok,
				'tab'    => 'bot',
				'detail' => self::module_detail( $module_on, $woo_ok ),
			),
			array(
				'title'  => __( 'Check with a test message', 'mvweb-telegram-hub' ),
				'done'   => $tested > 0,
				'tab'    => 'orders',
				'detail' => $tested > 0
					? sprintf(
						/* translators: %s: date and time of the last successful test. */
						__( 'Last delivered test: %s.', 'mvweb-telegram-hub' ),
						wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $tested )
					)
					: __( 'Make sure a message really arrives before a customer places an order.', 'mvweb-telegram-hub' ),
			),
		);

		/*
		 * Only listed once the shop has asked for it. Carried as a permanent
		 * fifth step it would hold the progress bar below 100% for ever on every
		 * shop that only writes to its own staff, which reads as "something is
		 * broken" rather than "you did not want this".
		 */
		if ( $customer_on ) {
			$state = Webhook::is_enabled() ? Webhook::info() : array(
				'ok'     => false,
				'result' => array(),
			);

			$steps[] = array(
				'title'  => __( 'Let customers connect Telegram', 'mvweb-telegram-hub' ),
				'done'   => Webhook::is_enabled() && ! empty( $state['ok'] ) && empty( $state['result']['last_error_message'] ),
				'tab'    => 'bot',
				'detail' => self::customer_detail( $state ),
			);
		}

		return $steps;
	}

	/**
	 * The steps on a site without a shop: the channel is all there is.
	 *
	 * @since 1.1.0
	 * @param array $bot_step The step that connects the bot.
	 * @return array[] Each step: title, done, detail, tab.
	 */
	private static function blog_steps( array $bot_step ) {
		$channels = Settings::channels();
		$posting  = Settings::module_enabled( PostsModule::slug() );

		return array(
			$bot_step,
			array(
				'title'  => __( 'Add a channel', 'mvweb-telegram-hub' ),
				'done'   => (bool) $channels,
				'tab'    => 'channels',
				'detail' => $channels
					? sprintf(
						/* translators: %d: number of channels. */
						_n( '%d channel will receive new posts.', '%d channels will receive new posts.', count( $channels ), 'mvweb-telegram-hub' ),
						count( $channels )
					)
					: __( 'Say which channel gets the new posts.', 'mvweb-telegram-hub' ),
			),
			array(
				'title'  => __( 'Switch channel posting on', 'mvweb-telegram-hub' ),
				'done'   => $posting,
				'tab'    => 'bot',
				'detail' => $posting
					? __( 'New posts are announced in the channel.', 'mvweb-telegram-hub' )
					: __( 'The “New posts to a Telegram channel” module is switched off below.', 'mvweb-telegram-hub' ),
			),
		);
	}

	/**
	 * Wording for the customer step.
	 *
	 * It doubles as the health check for the webhook, which is the one part of
	 * the plugin whose failure is completely silent: Telegram simply stops
	 * being able to reach the site, nothing is written anywhere, and customers
	 * quietly cannot connect.
	 *
	 * @since 1.1.0
	 * @param array $state Cached answer from Webhook::info().
	 * @return string
	 */
	private static function customer_detail( array $state ) {
		if ( ! Webhook::is_enabled() ) {
			return __( 'Almost there: press “Accept commands” under “Commands from Telegram” below, otherwise nobody can finish connecting.', 'mvweb-telegram-hub' );
		}

		if ( empty( $state['ok'] ) ) {
			return __( 'The site could not reach Telegram to check this. Until it can, treat the state as unknown.', 'mvweb-telegram-hub' );
		}

		if ( ! empty( $state['result']['last_error_message'] ) ) {
			return sprintf(
				/* translators: %s: error text reported by Telegram. */
				__( 'Telegram cannot reach the site: %s', 'mvweb-telegram-hub' ),
				(string) $state['result']['last_error_message']
			);
		}

		return __( 'Customers can connect Telegram in the “Telegram” section of their account, guests on their order page.', 'mvweb-telegram-hub' );
	}

	/**
	 * How many steps are done.
	 *
	 * @since 1.0.0
	 * @param array[] $steps Steps from steps().
	 * @return int
	 */
	public static function done_count( array $steps ) {
		return count(
			array_filter(
				$steps,
				static function ( $step ) {
					return ! empty( $step['done'] );
				}
			)
		);
	}

	/**
	 * Wording for the module step.
	 *
	 * @since 1.0.0
	 * @param bool $module_on Module toggle.
	 * @param bool $woo_ok    WooCommerce present and recent enough.
	 * @return string
	 */
	private static function module_detail( $module_on, $woo_ok ) {
		if ( ! $woo_ok ) {
			return __( 'This WooCommerce version is too old, so order notifications are not sent. Update WooCommerce.', 'mvweb-telegram-hub' );
		}

		return $module_on
			? __( 'New orders from the checkout are being sent.', 'mvweb-telegram-hub' )
			: __( 'The “WooCommerce orders” module is switched off below.', 'mvweb-telegram-hub' );
	}
}
