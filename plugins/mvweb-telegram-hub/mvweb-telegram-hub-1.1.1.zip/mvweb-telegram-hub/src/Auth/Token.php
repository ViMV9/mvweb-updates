<?php
/**
 * Identity token verification.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Auth;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The one place in this plugin where cryptography is written by hand.
 *
 * WordPress has no JWT verifier, so there is nothing native to lean on. Getting
 * this wrong is not a bug, it is handing the site away: a token whose signature
 * is never checked can be typed out by anyone, and that single omission is the
 * whole of CVE-2025-9485 and CVE-2026-8457, both scored 9.8.
 *
 * Five things are checked, and a failure of any one of them is a refusal:
 *
 *   1. the algorithm is taken from our own allow-list, never from the token;
 *   2. the key is looked up by kid in the published key set;
 *   3. the issuer matches the one we asked;
 *   4. the audience is our client id;
 *   5. the token is not expired, and echoes the nonce if it carries one.
 *
 * @since 1.1.0
 */
final class Token {

	/**
	 * Algorithms this plugin can verify, mapped to their key type.
	 *
	 * Telegram publishes four. EdDSA and ES256K are left out because openssl
	 * cannot verify them here, and a signature nobody can check is refused
	 * rather than waved through — the failure says which algorithm it was.
	 *
	 * @var array<string, string>
	 */
	private const ALGORITHMS = array(
		'RS256' => 'RSA',
		'ES256' => 'EC',
	);

	/**
	 * Seconds of clock skew tolerated on exp and iat.
	 *
	 * @var int
	 */
	private const LEEWAY = 60;

	/**
	 * Fixed head of a P-256 SubjectPublicKeyInfo, up to the point itself.
	 *
	 * @var string
	 */
	private const EC_P256_HEADER = '3059301306072a8648ce3d020106082a8648ce3d03010703420004';

	/**
	 * AlgorithmIdentifier for rsaEncryption with absent parameters.
	 *
	 * @var string
	 */
	private const RSA_ALGORITHM_ID = '300d06092a864886f70d0101010500';

	/**
	 * Check a token and return what it says.
	 *
	 * @since 1.1.0
	 * @param string $jwt       Raw identity token.
	 * @param string $client_id Our client id, which the audience has to name.
	 * @param string $nonce     Nonce sent with the request.
	 * @return array {
	 *     Outcome.
	 *
	 *     @type bool   $ok     Whether the token is genuine and current.
	 *     @type array  $claims Decoded payload, empty on failure.
	 *     @type string $error  What failed, for the log. Never shown to a visitor.
	 * }
	 */
	public static function validate( $jwt, $client_id, $nonce ) {
		$parts = explode( '.', (string) $jwt );

		if ( 3 !== count( $parts ) ) {
			return self::refuse( 'token is not a JWT' );
		}

		/*
		 * JSON_BIGINT_AS_STRING on the payload, because the subject identifier
		 * is a nineteen-digit number and the largest of those do not fit in a
		 * PHP integer. Without the flag such a value decodes to a float, and a
		 * float has already lost the last digits by the time anybody looks —
		 * which would quietly merge two different people onto one account.
		 */
		$header    = json_decode( self::decode( $parts[0] ), true );
		$claims    = json_decode( self::decode( $parts[1] ), true, 512, JSON_BIGINT_AS_STRING );
		$signature = self::decode( $parts[2] );

		if ( ! is_array( $header ) || ! is_array( $claims ) || '' === $signature ) {
			return self::refuse( 'token could not be decoded' );
		}

		$alg = self::text( $header, 'alg' );
		$kid = self::text( $header, 'kid' );

		if ( ! isset( self::ALGORITHMS[ $alg ] ) ) {
			return self::refuse( sprintf( 'unsupported signing algorithm %s', $alg ) );
		}

		if ( '' === $kid ) {
			return self::refuse( 'token names no signing key' );
		}

		$key = self::key( $kid );

		if ( ! $key ) {
			return self::refuse( sprintf( 'signing key %s is not published', $kid ) );
		}

		if ( ! isset( $key['kty'] ) || self::ALGORITHMS[ $alg ] !== $key['kty'] ) {
			return self::refuse( 'signing key does not match the algorithm' );
		}

		if ( ! self::verify( $parts[0] . '.' . $parts[1], $signature, $alg, $key ) ) {
			return self::refuse( 'signature does not check out' );
		}

		$error = self::check_claims( $claims, $client_id, $nonce );

		if ( '' !== $error ) {
			return self::refuse( $error );
		}

		return array(
			'ok'     => true,
			'claims' => $claims,
			'error'  => '',
		);
	}

	/**
	 * Look a key up, refreshing the set once if the id is unknown.
	 *
	 * An unknown key id is what a rotation looks like from here, and a rotation
	 * that locked everybody out until a transient expired would be an outage.
	 *
	 * @since 1.1.0
	 * @param string $kid Key id from the token header.
	 * @return array|null
	 */
	private static function key( $kid ) {
		$keys = Provider::jwks();

		if ( isset( $keys[ $kid ] ) ) {
			return $keys[ $kid ];
		}

		$keys = Provider::jwks( true );

		return isset( $keys[ $kid ] ) ? $keys[ $kid ] : null;
	}

	/**
	 * Verify the signature over the signing input.
	 *
	 * @since 1.1.0
	 * @param string $input     Header and payload, joined by a dot.
	 * @param string $signature Raw signature bytes.
	 * @param string $alg       Algorithm from the allow-list.
	 * @param array  $key       Published key.
	 * @return bool
	 */
	private static function verify( $input, $signature, $alg, array $key ) {
		$pem = 'RS256' === $alg ? self::rsa_pem( $key ) : self::ec_pem( $key );

		if ( '' === $pem ) {
			return false;
		}

		if ( 'ES256' === $alg ) {
			$signature = self::ecdsa_to_der( $signature );

			if ( '' === $signature ) {
				return false;
			}
		}

		$public = openssl_pkey_get_public( $pem );

		if ( ! $public ) {
			return false;
		}

		return 1 === openssl_verify( $input, $signature, $public, OPENSSL_ALGO_SHA256 );
	}

	/**
	 * Check everything the payload has to say.
	 *
	 * The nonce is checked when the token carries one. Telegram does not list
	 * it among the claims it publishes, and a check that always fails would
	 * turn a working sign-in into a dead button — the reply is already tied to
	 * this browser by the state cookie and to this attempt by PKCE.
	 *
	 * @since 1.1.0
	 * @param array  $claims    Decoded payload.
	 * @param string $client_id Our client id.
	 * @param string $nonce     Nonce sent with the request.
	 * @return string Empty when everything checks out.
	 */
	private static function check_claims( array $claims, $client_id, $nonce ) {
		if ( Provider::ISSUER !== self::text( $claims, 'iss' ) ) {
			return 'issuer does not match';
		}

		// The audience is a string or a list of them. Anything nested is not a
		// list of audiences, and casting it would only produce a warning and
		// the word "Array".
		$raw      = isset( $claims['aud'] ) ? $claims['aud'] : '';
		$audience = array();

		foreach ( is_array( $raw ) ? $raw : array( $raw ) as $one ) {
			if ( is_string( $one ) || is_int( $one ) ) {
				$audience[] = (string) $one;
			}
		}

		if ( '' === (string) $client_id || ! in_array( (string) $client_id, $audience, true ) ) {
			return 'audience is not this site';
		}

		$expires = isset( $claims['exp'] ) ? (int) $claims['exp'] : 0;

		if ( $expires <= 0 || time() > $expires + self::LEEWAY ) {
			return 'token has expired';
		}

		$issued = isset( $claims['iat'] ) ? (int) $claims['iat'] : 0;

		if ( $issued > 0 && $issued - self::LEEWAY > time() ) {
			return 'token is issued in the future';
		}

		if ( isset( $claims['nonce'] ) && ! hash_equals( (string) $nonce, self::text( $claims, 'nonce' ) ) ) {
			return 'nonce does not match';
		}

		// A string or a number, and not empty. Deliberately not empty(): the
		// string "0" is a legitimate identifier, and is_scalar() alone would let
		// a boolean through to become the identity of user "1".
		if ( '' === self::text( $claims, 'sub' ) ) {
			return 'token identifies nobody';
		}

		return '';
	}

	/**
	 * One field of a decoded token as a string.
	 *
	 * Anything that is not a string or a number comes back empty rather than
	 * being cast. A cast would answer "Array", raise a warning on the way, and
	 * hand a value that looks real to whatever compares it next.
	 *
	 * @since 1.1.0
	 * @param array  $source Decoded header or payload.
	 * @param string $key    Field to read.
	 * @return string
	 */
	private static function text( array $source, $key ) {
		if ( ! isset( $source[ $key ] ) || ( ! is_string( $source[ $key ] ) && ! is_int( $source[ $key ] ) ) ) {
			return '';
		}

		return (string) $source[ $key ];
	}

	/**
	 * Public key PEM from an RSA JWK.
	 *
	 * @since 1.1.0
	 * @param array $key Published key.
	 * @return string Empty when the key is not usable.
	 */
	private static function rsa_pem( array $key ) {
		if ( empty( $key['n'] ) || empty( $key['e'] ) ) {
			return '';
		}

		$rsa = self::sequence(
			self::integer( self::decode( $key['n'] ) ) . self::integer( self::decode( $key['e'] ) )
		);

		$bits = "\x03" . self::der_length( strlen( $rsa ) + 1 ) . "\x00" . $rsa;
		$spki = self::sequence( hex2bin( self::RSA_ALGORITHM_ID ) . $bits );

		return self::pem( $spki );
	}

	/**
	 * Public key PEM from a P-256 JWK.
	 *
	 * @since 1.1.0
	 * @param array $key Published key.
	 * @return string Empty when the key is not usable.
	 */
	private static function ec_pem( array $key ) {
		if ( empty( $key['x'] ) || empty( $key['y'] ) || ! isset( $key['crv'] ) || 'P-256' !== $key['crv'] ) {
			return '';
		}

		$x = self::decode( $key['x'] );
		$y = self::decode( $key['y'] );

		if ( 32 !== strlen( $x ) || 32 !== strlen( $y ) ) {
			return '';
		}

		return self::pem( hex2bin( self::EC_P256_HEADER ) . $x . $y );
	}

	/**
	 * Turn a raw ECDSA signature into the DER form openssl expects.
	 *
	 * JWS carries r and s as two fixed-width halves; openssl wants a SEQUENCE
	 * of two signed integers.
	 *
	 * @since 1.1.0
	 * @param string $signature Raw 64-byte signature.
	 * @return string Empty when the length is wrong.
	 */
	private static function ecdsa_to_der( $signature ) {
		if ( 64 !== strlen( $signature ) ) {
			return '';
		}

		return self::sequence(
			self::integer( substr( $signature, 0, 32 ) ) . self::integer( substr( $signature, 32, 32 ) )
		);
	}

	/**
	 * Wrap DER bytes in a PEM envelope.
	 *
	 * @since 1.1.0
	 * @param string $der Encoded key.
	 * @return string
	 */
	private static function pem( $der ) {
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- PEM is base64 by definition.
		return "-----BEGIN PUBLIC KEY-----\n" . chunk_split( base64_encode( $der ), 64, "\n" ) . "-----END PUBLIC KEY-----\n";
	}

	/**
	 * DER SEQUENCE around already encoded contents.
	 *
	 * @since 1.1.0
	 * @param string $contents Encoded members.
	 * @return string
	 */
	private static function sequence( $contents ) {
		return "\x30" . self::der_length( strlen( $contents ) ) . $contents;
	}

	/**
	 * DER INTEGER holding an unsigned big-endian number.
	 *
	 * @since 1.1.0
	 * @param string $bytes Raw number.
	 * @return string
	 */
	private static function integer( $bytes ) {
		$bytes = ltrim( $bytes, "\x00" );

		if ( '' === $bytes ) {
			$bytes = "\x00";
		}

		// DER integers are signed, so a leading bit that is set needs a pad byte
		// or the number reads as negative.
		if ( ord( $bytes[0] ) > 0x7f ) {
			$bytes = "\x00" . $bytes;
		}

		return "\x02" . self::der_length( strlen( $bytes ) ) . $bytes;
	}

	/**
	 * DER length prefix, short or long form.
	 *
	 * @since 1.1.0
	 * @param int $length Number of content bytes.
	 * @return string
	 */
	private static function der_length( $length ) {
		if ( $length < 128 ) {
			return chr( $length );
		}

		$bytes = ltrim( pack( 'N', $length ), "\x00" );

		return chr( 0x80 | strlen( $bytes ) ) . $bytes;
	}

	/**
	 * Decode one base64url segment.
	 *
	 * @since 1.1.0
	 * @param string $value Segment.
	 * @return string Empty when the segment is not valid base64url.
	 */
	private static function decode( $value ) {
		$value = strtr( (string) $value, '-_', '+/' );
		$pad   = strlen( $value ) % 4;

		if ( $pad ) {
			$value .= str_repeat( '=', 4 - $pad );
		}

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- base64url, as JWS defines it.
		$decoded = base64_decode( $value, true );

		return false === $decoded ? '' : $decoded;
	}

	/**
	 * Shape a refusal.
	 *
	 * @since 1.1.0
	 * @param string $error What failed.
	 * @return array
	 */
	private static function refuse( $error ) {
		return array(
			'ok'     => false,
			'claims' => array(),
			'error'  => (string) $error,
		);
	}
}
