<?php
/**
 * Everything a visitor sees of signing in with Telegram.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Auth;

use WP_User;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The storefront side: the button, the results and the
 * connect block.
 *
 * Signing in with Telegram is for the people who buy and comment, so all of it
 * lives on the storefront — the WooCommerce account page and a shortcode for
 * any other page. Nothing is added to wp-login.php: that page is where staff
 * sign in, and their accounts can never use Telegram anyway.
 *
 * The button starts hidden and is revealed only once the visitor's own browser
 * has proved it can reach Telegram. Everyone else sees exactly the page they saw
 * before this plugin existed, and nothing waits on anything.
 *
 * @since 1.1.0
 */
final class Screen {

	/**
	 * Parts already drawn in this request.
	 *
	 * A shortcode placed on the account page would otherwise repeat the
	 * button and the result the page already shows.
	 *
	 * @var array<string, bool>
	 */
	private static $drawn = array();

	/**
	 * Hook the storefront.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function register() {
		add_shortcode( 'mvweb_tg_login', array( $this, 'shortcode' ) );

		add_action( 'admin_post_mvweb_tg_unlink', array( $this, 'unlink' ) );
		add_action( 'admin_post_mvweb_tg_unlink_user', array( $this, 'unlink_user' ) );
		add_action( 'edit_user_profile', array( $this, 'profile_row' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );

		add_action( 'woocommerce_before_customer_login_form', array( $this, 'render_account_top' ) );
		add_action( 'woocommerce_before_checkout_form', array( $this, 'render_checkout_top' ), 5 );
		add_action( 'woocommerce_login_form_end', array( $this, 'render_account_button' ) );
		add_action( 'woocommerce_account_dashboard', array( $this, 'render_account_notice' ) );
	}

	/**
	 * Declare the two assets.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function register_assets() {
		wp_register_style(
			'mvweb-tg-login',
			MVWEB_TG_URL . 'public/css/login.min.css',
			array(),
			self::asset_version( 'public/css/login.min.css' )
		);

		wp_register_script(
			'mvweb-tg-login',
			MVWEB_TG_URL . 'public/js/login.min.js',
			array(),
			self::asset_version( 'public/js/login.min.js' ),
			true
		);
	}

	/**
	 * Above the WooCommerce login form: the result of an attempt.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function render_account_top() {
		echo self::guest_top(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped where it is built.
	}

	/**
	 * Above the checkout: the result of an attempt.
	 *
	 * The checkout login form fires the same hook as the account page, so the
	 * button appears there too and brings the shopper back to the checkout.
	 * This is where whatever they come back to gets said.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function render_checkout_top() {
		if ( is_user_logged_in() ) {
			return;
		}

		echo self::guest_top(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped where it is built.
	}

	/**
	 * The button at the end of the WooCommerce login form.
	 *
	 * A bare link, so being inside that form is harmless. The checkout uses the
	 * same form, and a shopper who signs in there goes back to the checkout.
	 * Elsewhere a redirect_to in the address is honoured, so a theme that
	 * sends the shopper from the checkout to the account page can bring them
	 * back; the round trip validates it again before using it.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function render_account_button() {
		if ( ! Flow::is_available() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- only where to land afterwards, checked by wp_validate_redirect().
		$asked = isset( $_GET['redirect_to'] ) ? wp_validate_redirect( esc_url_raw( wp_unslash( $_GET['redirect_to'] ) ), '' ) : '';
		$back  = function_exists( 'is_checkout' ) && is_checkout() ? (string) wc_get_checkout_url() : ( '' !== $asked ? $asked : Flow::home() );

		echo self::login_button( $back, true ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in button().
	}

	/**
	 * A result on the account dashboard.
	 *
	 * Where a signed-in visitor lands when the page they started from is not
	 * known, so a failed connection still gets explained.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function render_account_notice() {
		$code = self::result();

		if ( '' === $code || ! empty( self::$drawn['link'] ) ) {
			return;
		}

		echo self::notice( $code ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in notice().
	}

	/**
	 * Whether the connect block has anything to show this user.
	 *
	 * The same test link_block() applies, so the account menu offers the
	 * section exactly when the block would appear in it.
	 *
	 * @since 1.1.1
	 * @param WP_User $user User.
	 * @return bool
	 */
	public static function offers_link( WP_User $user ) {
		return '' !== Users::sub_of( $user->ID ) || ( Users::may_sign_in( $user ) && Flow::is_available() );
	}

	/**
	 * The same, anywhere else.
	 *
	 * A guest gets the button and the result of an attempt;
	 * somebody signed in gets the block that connects or disconnects Telegram.
	 *
	 * @since 1.1.0
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function shortcode( $atts ) {
		$atts = shortcode_atts(
			array( 'redirect' => '' ),
			$atts,
			'mvweb_tg_login'
		);

		$back = '' !== $atts['redirect'] ? esc_url_raw( (string) $atts['redirect'] ) : ( is_singular() ? (string) get_permalink() : Flow::home() );

		if ( is_user_logged_in() ) {
			return self::link_block( $back );
		}

		$html = self::guest_top();

		if ( Flow::is_available() ) {
			$html .= self::login_button( $back, false );
		}

		return $html;
	}

	/**
	 * A Telegram connection in somebody else's profile, for an administrator.
	 *
	 * Removing only, never adding: attaching somebody's Telegram to an account
	 * is the takeover the whole feature is built to avoid. Removing is what a
	 * support request needs — a customer who lost the old Telegram account.
	 * A link rather than a button, because this hook sits inside the profile
	 * form and a form inside a form is markup no browser submits.
	 *
	 * @since 1.1.0
	 * @param WP_User $user Profile being shown.
	 * @return void
	 */
	public function profile_row( $user ) {
		if ( ! $user instanceof WP_User || ! current_user_can( 'edit_user', $user->ID ) ) {
			return;
		}

		$sub = Users::sub_of( $user->ID );

		if ( '' === $sub ) {
			return;
		}

		$username = Users::username_of( $user->ID );
		$url      = wp_nonce_url(
			add_query_arg(
				array(
					'action'  => 'mvweb_tg_unlink_user',
					'user_id' => $user->ID,
				),
				admin_url( 'admin-post.php' )
			),
			'mvweb_tg_unlink_user_' . $user->ID
		);

		?>
		<h2><?php esc_html_e( 'Telegram', 'mvweb-telegram-hub' ); ?></h2>
		<table class="form-table" role="presentation">
			<tr>
				<th scope="row"><?php esc_html_e( 'Signing in with Telegram', 'mvweb-telegram-hub' ); ?></th>
				<td>
					<p><strong><?php echo '' !== $username ? esc_html( '@' . $username ) : esc_html__( 'Connected', 'mvweb-telegram-hub' ); ?></strong></p>
					<p><a class="button" href="<?php echo esc_url( $url ); ?>"><?php esc_html_e( 'Disconnect', 'mvweb-telegram-hub' ); ?></a></p>
					<p class="description"><?php esc_html_e( 'Disconnecting stops sign-in through Telegram for this account. The password is not affected.', 'mvweb-telegram-hub' ); ?></p>
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * Remove a connection from somebody else's account.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function unlink_user() {
		$user_id = isset( $_GET['user_id'] ) ? absint( wp_unslash( $_GET['user_id'] ) ) : 0;

		check_admin_referer( 'mvweb_tg_unlink_user_' . $user_id );

		if ( ! $user_id || ! current_user_can( 'edit_user', $user_id ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'mvweb-telegram-hub' ), '', array( 'response' => 403 ) );
		}

		Users::unlink( $user_id );

		wp_safe_redirect(
			add_query_arg(
				array(
					'user_id' => $user_id,
					'updated' => 1,
				),
				admin_url( 'user-edit.php' )
			)
		);
		exit;
	}

	/**
	 * Remove the connection between the signed-in account and its Telegram.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function unlink() {
		$user_id = get_current_user_id();

		check_admin_referer( 'mvweb_tg_unlink_' . $user_id );

		if ( ! $user_id ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'mvweb-telegram-hub' ), '', array( 'response' => 403 ) );
		}

		$back = isset( $_POST['redirect'] ) ? esc_url_raw( wp_unslash( $_POST['redirect'] ) ) : '';
		$back = '' !== $back ? wp_validate_redirect( remove_query_arg( Flow::RESULT, $back ), Flow::home() ) : Flow::home();

		if ( '' === wp_get_current_user()->user_email ) {
			wp_safe_redirect( add_query_arg( Flow::RESULT, 'unlink_locked', $back ) );
			exit;
		}

		Users::unlink( $user_id );

		wp_safe_redirect( add_query_arg( Flow::RESULT, 'unlinked', $back ) );
		exit;
	}

	/**
	 * What a guest sees above the button: the result of an attempt.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private static function guest_top() {
		if ( ! empty( self::$drawn['guest'] ) ) {
			return '';
		}

		self::$drawn['guest'] = true;

		$code = self::result();

		return '' !== $code ? self::notice( $code ) : '';
	}

	/**
	 * Connect or disconnect Telegram, for the signed-in account.
	 *
	 * Connecting is offered only to accounts allowed to sign in this way, and
	 * only on one's own account: attaching somebody else's Telegram is exactly
	 * the takeover the whole feature is built to avoid. Disconnecting is always
	 * possible, so a role that lost the right can still drop the connection.
	 *
	 * @since 1.1.0
	 * @param string $back Page to return to.
	 * @return string
	 */
	public static function link_block( $back ) {
		$user = wp_get_current_user();

		if ( ! $user instanceof WP_User || ! $user->exists() || ! empty( self::$drawn['link'] ) ) {
			return '';
		}

		if ( ! self::offers_link( $user ) ) {
			return '';
		}

		$sub = Users::sub_of( $user->ID );

		self::$drawn['link'] = true;
		self::assets();

		$code = self::result();
		$html = '' !== $code ? self::notice( $code ) : '';

		$html .= '<div class="mvweb-tg-account">';
		$html .= '<h3 class="mvweb-tg-account__title">' . esc_html__( 'Signing in with Telegram', 'mvweb-telegram-hub' ) . '</h3>';

		if ( '' === $sub ) {
			$html .= '<p class="mvweb-tg-account__text">' . esc_html__( 'Afterwards you can sign in with one tap instead of a password. Your password keeps working.', 'mvweb-telegram-hub' ) . '</p>';
			$html .= self::button( Flow::start_url( 'link', $back ), __( 'Connect Telegram', 'mvweb-telegram-hub' ), false );
		} else {
			$username = Users::username_of( $user->ID );

			$html .= '<p class="mvweb-tg-account__text"><strong>' . ( '' !== $username ? esc_html( '@' . $username ) : esc_html__( 'Connected', 'mvweb-telegram-hub' ) ) . '</strong></p>';

			if ( '' === $user->user_email ) {
				$html .= '<p class="mvweb-tg-account__note">' . esc_html__( 'Telegram is the only way into this account. Add an email address in your account details first: after disconnecting, you can set a password with the password reset link on the login page.', 'mvweb-telegram-hub' ) . '</p>';

				return $html . '</div>';
			}

			$html .= '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
			$html .= wp_nonce_field( 'mvweb_tg_unlink_' . $user->ID, '_wpnonce', true, false );
			$html .= '<input type="hidden" name="action" value="mvweb_tg_unlink">';
			$html .= '<input type="hidden" name="redirect" value="' . esc_url( $back ) . '">';
			$html .= '<button type="submit" class="button">' . esc_html__( 'Disconnect', 'mvweb-telegram-hub' ) . '</button>';
			$html .= '</form>';
			$html .= '<p class="mvweb-tg-account__note">' . esc_html__( 'Disconnecting stops sign-in through Telegram for this account. The password is not affected.', 'mvweb-telegram-hub' ) . '</p>';
		}

		return $html . '</div>';
	}

	/**
	 * One result, in the theme's own notice style where there is one.
	 *
	 * @since 1.1.0
	 * @param string $code Result code from the round trip.
	 * @return string Empty for an unknown code.
	 */
	private static function notice( $code ) {
		$messages = self::messages();

		if ( ! isset( $messages[ $code ] ) ) {
			return '';
		}

		list( $type, $text ) = $messages[ $code ];

		if ( function_exists( 'wc_print_notice' ) ) {
			return (string) wc_print_notice( $text, $type, array(), true );
		}

		self::assets();

		return '<div class="mvweb-tg-notice mvweb-tg-notice--' . esc_attr( $type ) . '" role="' . ( 'error' === $type ? 'alert' : 'status' ) . '">' . esc_html( $text ) . '</div>';
	}

	/**
	 * Result codes and what they say.
	 *
	 * @since 1.1.0
	 * @return array<string, array{0: string, 1: string}> Code mapped to notice type and text.
	 */
	private static function messages() {
		return array(
			'too_many'         => array( 'error', __( 'Too many attempts. Wait a few minutes and try again.', 'mvweb-telegram-hub' ) ),
			'link_expired'     => array( 'error', __( 'That link has expired. Try connecting Telegram again.', 'mvweb-telegram-hub' ) ),
			'link_not_allowed' => array( 'error', __( 'Signing in with Telegram is not available for this account.', 'mvweb-telegram-hub' ) ),
			'mismatch'         => array( 'error', __( 'That sign-in could not be matched to this browser. Start again from the login page.', 'mvweb-telegram-hub' ) ),
			'expired'          => array( 'error', __( 'That sign-in has expired. Start again from the login page.', 'mvweb-telegram-hub' ) ),
			'failed'           => array( 'error', __( 'Telegram did not confirm the sign-in. Try again in a minute.', 'mvweb-telegram-hub' ) ),
			'unverified'       => array( 'error', __( 'The answer from Telegram could not be verified, so nobody was signed in.', 'mvweb-telegram-hub' ) ),
			'account_exists'   => array( 'error', __( 'This Telegram account already had an account here, and Telegram was disconnected from it. Contact the site owner to restore access.', 'mvweb-telegram-hub' ) ),
			'create_failed'    => array( 'error', __( 'The account could not be created. Contact the site owner.', 'mvweb-telegram-hub' ) ),
			'ambiguous'        => array( 'error', __( 'This Telegram account is connected to more than one account here, so it cannot be used to sign in. Contact the site owner.', 'mvweb-telegram-hub' ) ),
			'gone'             => array( 'error', __( 'That account no longer exists.', 'mvweb-telegram-hub' ) ),
			'not_allowed'      => array( 'error', __( 'Signing in with Telegram is not available for this account. Use your password.', 'mvweb-telegram-hub' ) ),
			'unlink_locked'    => array( 'error', __( 'Add an email address to the account first. Without it, disconnecting Telegram would lock you out.', 'mvweb-telegram-hub' ) ),
			'closed'           => array( 'error', __( 'This Telegram account is not connected to anything here, and the site is not accepting new accounts.', 'mvweb-telegram-hub' ) ),
			'link_session'     => array( 'error', __( 'You are no longer signed in as the account that started this. Sign in and try again.', 'mvweb-telegram-hub' ) ),
			'link_occupied'    => array( 'error', __( 'This account already has a Telegram account connected. Disconnect that one first.', 'mvweb-telegram-hub' ) ),
			'link_taken'       => array( 'error', __( 'This Telegram account is already connected to another account on this site.', 'mvweb-telegram-hub' ) ),
			'linked'           => array( 'success', __( 'Telegram is connected. Next time you can sign in with one tap.', 'mvweb-telegram-hub' ) ),
			'unlinked'         => array( 'success', __( 'Telegram is disconnected from your account. Your password keeps working.', 'mvweb-telegram-hub' ) ),
		);
	}

	/**
	 * Result code in this request, if any.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private static function result() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a fixed word that only selects which message to show.
		return isset( $_GET[ Flow::RESULT ] ) ? sanitize_key( wp_unslash( $_GET[ Flow::RESULT ] ) ) : '';
	}

	/**
	 * A Telegram button.
	 *
	 * Rendered with the hidden attribute and revealed by the script once the
	 * visitor's browser has reached Telegram. A button that leads nowhere is
	 * worse than no button: the person cannot tell whether the site is broken
	 * or their connection is.
	 *
	 * @since 1.1.0
	 * @param string $url   Where the button goes.
	 * @param string $label Button text.
	 * @param bool   $rule  Whether to draw the "or" rule above it.
	 * @return string
	 */
	private static function button( $url, $label, $rule ) {
		self::assets();

		return '<div class="mvweb-tg-login" hidden>'
			. ( $rule ? '<div class="mvweb-tg-login__or"><span>' . esc_html__( 'or', 'mvweb-telegram-hub' ) . '</span></div>' : '' )
			. '<a class="mvweb-tg-login__btn" href="' . esc_url( $url ) . '">'
			. '<svg class="mvweb-tg-login__icon" viewBox="0 0 24 24" width="20" height="20" fill="currentColor" aria-hidden="true" focusable="false">'
			. '<path d="M21.94 4.6 18.6 20.3c-.25 1.11-.91 1.38-1.84.86l-5.1-3.76-2.46 2.37c-.27.27-.5.5-1.03.5l.37-5.2 9.47-8.56c.41-.37-.09-.57-.64-.2L5.67 13.68.63 12.1c-1.1-.34-1.12-1.1.23-1.62L20.5 2.98c.91-.34 1.71.2 1.44 1.62z"/>'
			. '</svg>'
			. '<span>' . esc_html( $label ) . '</span>'
			. '</a>'
			. '</div>';
	}

	/**
	 * The sign-in button, drawn once per page.
	 *
	 * @since 1.1.0
	 * @param string $back Page to return to.
	 * @param bool   $rule Whether to draw the "or" rule above it.
	 * @return string
	 */
	private static function login_button( $back, $rule ) {
		if ( ! empty( self::$drawn['button'] ) ) {
			return '';
		}

		self::$drawn['button'] = true;

		return self::button( Flow::start_url( '', $back ), __( 'Sign in with Telegram', 'mvweb-telegram-hub' ), $rule );
	}

	/**
	 * Load the stylesheet and the script.
	 *
	 * Called by every part that draws something, not only by the button: the
	 * connected block and the plain notice have no button to bring them along.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	private static function assets() {
		wp_enqueue_style( 'mvweb-tg-login' );
		wp_enqueue_script( 'mvweb-tg-login' );
	}

	/**
	 * Cache-busting version for an asset.
	 *
	 * @since 1.1.0
	 * @param string $relative Path relative to the plugin root.
	 * @return string
	 */
	private static function asset_version( $relative ) {
		$path  = MVWEB_TG_PATH . $relative;
		$mtime = file_exists( $path ) ? filemtime( $path ) : 0;

		return $mtime ? (string) $mtime : MVWEB_TG_VERSION;
	}
}
