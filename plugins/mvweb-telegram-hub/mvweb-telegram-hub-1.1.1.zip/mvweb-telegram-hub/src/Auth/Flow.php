<?php
/**
 * The sign-in round trip.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Auth;

use MVweb\Telegram\Hub\Link\Binding;
use MVweb\Telegram\Hub\Log\Repository;
use MVweb\Telegram\Hub\Settings;
use WP_User;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The round trip, and the state that ties it together.
 *
 * The two handlers hang off login_form_{action} on wp-login.php, which is the
 * one entry point that works for a guest and for a signed-in user alike and
 * needs no rewrite rule. The REST API was the other candidate and is not
 * usable here: a signed-in visitor arriving on a REST route from a plain
 * browser navigation is refused by rest_cookie_check_errors for want of a
 * nonce, and the address Telegram returns to is fixed at registration time and
 * cannot carry one.
 *
 * Nothing is drawn there. Signing in with Telegram is for the people who use
 * the storefront, so every handler ends in a redirect back to the page the
 * visitor started from, with a short result code that Screen turns into a
 * message or nothing at all.
 *
 * The attempt is tied to one browser and one round trip by three separate
 * things: a state value held in a __Host- cookie, a server-side record burnt on
 * first use, and a PKCE verifier that never leaves the site.
 *
 * @since 1.1.0
 */
final class Flow {

	/**
	 * Action that starts the round trip.
	 *
	 * @var string
	 */
	public const START = 'mvweb_tg_start';

	/**
	 * Action Telegram returns to. Registered with BotFather, never changes.
	 *
	 * @var string
	 */
	public const CALLBACK = 'mvweb_tg_callback';

	/**
	 * Cookie holding the state of an attempt.
	 *
	 * @var string
	 */
	private const STATE_COOKIE = '__Host-mvweb_tg_login';

	/**
	 * How long a visitor has to finish at Telegram.
	 *
	 * @var int
	 */
	private const ATTEMPT_TTL = 10 * MINUTE_IN_SECONDS;

	/**
	 * Length of the rate-limiting window, in seconds.
	 *
	 * @var int
	 */
	private const START_WINDOW = 5 * MINUTE_IN_SECONDS;

	/**
	 * Attempts one address may start inside one window.
	 *
	 * The address is REMOTE_ADDR and nothing else: X-Forwarded-For is written
	 * by whoever asks unless the site is configured to trust one specific
	 * proxy, so believing it would hand the ceiling to the very people it is
	 * for. Behind a proxy that hides the real address this becomes one bucket
	 * for the whole site, which is why the number is generous — the point is
	 * to bound how many rows an open endpoint can write, not to police people.
	 *
	 * @var int
	 */
	private const STARTS_PER_WINDOW = 30;

	/**
	 * Query argument carrying the result back to the storefront.
	 *
	 * @var string
	 */
	public const RESULT = 'mvweb_tg';

	/**
	 * Hook the two handlers.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function register() {
		add_action( 'login_form_' . self::START, array( $this, 'start' ) );
		add_action( 'login_form_' . self::CALLBACK, array( $this, 'callback' ) );
	}

	/**
	 * Address of the button.
	 *
	 * @since 1.1.0
	 * @param string $mode        Either an empty string for signing in, or "link".
	 * @param string $redirect_to Where to land afterwards.
	 * @return string
	 */
	public static function start_url( $mode = '', $redirect_to = '' ) {
		$args = array( 'action' => self::START );

		if ( 'link' === $mode ) {
			$args['mode']     = 'link';
			$args['_wpnonce'] = wp_create_nonce( 'mvweb_tg_link' );
		}

		if ( '' !== $redirect_to ) {
			$args['redirect_to'] = rawurlencode( $redirect_to );
		}

		return add_query_arg( $args, wp_login_url() );
	}

	/**
	 * Whether the feature is switched on and able to run.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function is_available() {
		return Settings::login_enabled() && Provider::is_configured() && is_ssl();
	}

	/**
	 * Send the visitor to Telegram.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function start() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- a public entry point; the link mode below verifies its own nonce.
		$mode        = isset( $_GET['mode'] ) ? sanitize_key( wp_unslash( $_GET['mode'] ) ) : '';
		$redirect_to = isset( $_GET['redirect_to'] ) ? esc_url_raw( wp_unslash( $_GET['redirect_to'] ) ) : '';
		$nonce       = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$user_id = 0;

		if ( 'link' === $mode ) {
			// Attaching a Telegram account to somebody's account is a change to
			// that account, so it cannot be started by a link on another site.
			if ( ! is_user_logged_in() || ! wp_verify_nonce( $nonce, 'mvweb_tg_link' ) ) {
				self::back( $redirect_to, 'link_expired' );
			}

			$current = wp_get_current_user();

			if ( ! Users::may_sign_in( $current ) ) {
				self::back( $redirect_to, 'link_not_allowed' );
			}

			$user_id = $current->ID;
		} else {
			$mode = '';
		}

		if ( ! self::within_start_limit() ) {
			self::back( $redirect_to, 'too_many' );
		}

		$state    = wp_generate_password( 32, false, false );
		$verifier = wp_generate_password( 64, false, false );
		$nonce_id = wp_generate_password( 32, false, false );

		set_transient(
			self::attempt_key( $state ),
			array(
				'nonce'       => $nonce_id,
				'verifier'    => $verifier,
				'redirect_to' => $redirect_to,
				'mode'        => $mode,
				'user_id'     => $user_id,
			),
			self::ATTEMPT_TTL
		);

		self::set_cookie( self::STATE_COOKIE, $state, time() + self::ATTEMPT_TTL );

		nocache_headers();
		wp_redirect( Provider::authorize_url( $state, $nonce_id, $verifier ) ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- an external identity provider is the whole point.
		exit;
	}

	/**
	 * Take the answer back from Telegram.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function callback() {
		nocache_headers();

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- the state below is this request's proof, and it is compared with hash_equals.
		$state = isset( $_GET['state'] ) ? sanitize_text_field( wp_unslash( $_GET['state'] ) ) : '';
		$code  = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : '';
		$error = isset( $_GET['error'] ) ? sanitize_text_field( wp_unslash( $_GET['error'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$cookie = isset( $_COOKIE[ self::STATE_COOKIE ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ self::STATE_COOKIE ] ) ) : '';

		self::clear_cookie( self::STATE_COOKIE );

		if ( '' === $state || '' === $cookie || ! hash_equals( $cookie, $state ) ) {
			self::back( '', 'mismatch' );
		}

		// Burnt before anything is done with it, so the same code cannot be
		// presented twice for a second session.
		$attempt = get_transient( self::attempt_key( $state ) );
		delete_transient( self::attempt_key( $state ) );

		if ( ! is_array( $attempt ) ) {
			self::back( '', 'expired' );
		}

		$back = (string) $attempt['redirect_to'];

		// The visitor changed their mind at Telegram. Nothing went wrong, so
		// nothing is reported.
		if ( '' !== $error || '' === $code ) {
			self::back( $back );
		}

		$exchange = Provider::exchange( $code, $attempt['verifier'] );

		if ( empty( $exchange['ok'] ) ) {
			self::log( 'token exchange failed: ' . $exchange['error'] );
			self::back( $back, 'failed' );
		}

		$token = Token::validate( $exchange['id_token'], Settings::login_client_id(), $attempt['nonce'] );

		if ( empty( $token['ok'] ) ) {
			self::log( 'identity token refused: ' . $token['error'] );
			self::back( $back, 'unverified' );
		}

		$identity = self::identity( $token['claims'], $back );

		if ( 'link' === $attempt['mode'] ) {
			self::finish_link( $identity, (int) $attempt['user_id'], $attempt['redirect_to'] );
		}

		self::finish_login( $identity, $attempt['redirect_to'] );
	}

	/**
	 * Where the storefront side of signing in lives.
	 *
	 * The WooCommerce account page when there is one, the front page otherwise.
	 * Used whenever the page the visitor started from is not known.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function home() {
		$account = function_exists( 'wc_get_page_permalink' ) ? (string) wc_get_page_permalink( 'myaccount' ) : '';

		return '' !== $account ? $account : home_url( '/' );
	}

	/**
	 * Sign somebody in, or give them an account.
	 *
	 * An existing account's notification settings are left alone here: a
	 * customer who turned updates off is not switched back on by signing in.
	 *
	 * @since 1.1.0
	 * @param array  $identity    Verified identity.
	 * @param string $redirect_to Where the visitor wanted to go.
	 * @return void
	 */
	private static function finish_login( array $identity, $redirect_to ) {
		$holder = Users::by_sub( $identity['sub'] );

		if ( -1 === $holder ) {
			self::log( 'refused: one Telegram identity is attached to more than one account' );
			self::back( $redirect_to, 'ambiguous' );
		}

		if ( 0 === $holder ) {
			self::register_visitor( $identity, $redirect_to );
		}

		$user = get_userdata( $holder );

		if ( ! $user instanceof WP_User ) {
			self::back( $redirect_to, 'gone' );
		}

		if ( ! Users::may_sign_in( $user ) ) {
			self::back( $redirect_to, 'not_allowed' );
		}

		if ( '' !== $identity['username'] ) {
			update_user_option( $user->ID, Users::NAME_OPTION, $identity['username'] );
		}

		Users::sign_in( $user );

		self::land( $user, $redirect_to );
	}

	/**
	 * Attach the identity to the account that asked for it.
	 *
	 * @since 1.1.0
	 * @param array  $identity    Verified identity.
	 * @param int    $user_id     Account that started the attempt.
	 * @param string $redirect_to Where the visitor wanted to go.
	 * @return void
	 */
	private static function finish_link( array $identity, $user_id, $redirect_to ) {
		// The session that started this has to be the session that finishes it.
		if ( ! $user_id || get_current_user_id() !== $user_id ) {
			self::back( $redirect_to, 'link_session' );
		}

		$linked = Users::link( $user_id, $identity['sub'], $identity['username'] );

		if ( is_wp_error( $linked ) ) {
			self::back( $redirect_to, 'mvweb_tg_link_occupied' === $linked->get_error_code() ? 'link_occupied' : 'link_taken' );
		}

		self::notify_here( $user_id, $identity );

		self::back( $redirect_to, 'linked' );
	}

	/**
	 * Give a brand new visitor an account and sign them in.
	 *
	 * No address is asked for, so there is nothing to confirm and no letter to
	 * wait for: the Telegram account is the proof of who this is.
	 *
	 * @since 1.1.0
	 * @param array  $identity    Verified identity.
	 * @param string $redirect_to Where the visitor wanted to go.
	 * @return void
	 */
	private static function register_visitor( array $identity, $redirect_to ) {
		if ( ! Users::registration_allowed() ) {
			self::back( $redirect_to, 'closed' );
		}

		$user_id = Users::register( $identity['sub'], $identity['name'], $identity['username'] );

		if ( is_wp_error( $user_id ) ) {
			self::log( 'registration failed: ' . $user_id->get_error_code() );

			/*
			 * The login name is derived from the subject identifier, so a name
			 * that is taken can only have been taken by this same Telegram
			 * account — somebody who disconnected and came back. Saying so
			 * gives nothing away and is the only answer they can act on.
			 */
			self::back( $redirect_to, 'existing_user_login' === $user_id->get_error_code() ? 'account_exists' : 'create_failed' );
		}

		$user = get_userdata( $user_id );

		if ( ! $user instanceof WP_User || ! Users::may_sign_in( $user ) ) {
			self::back( $redirect_to, 'create_failed' );
		}

		self::notify_here( $user->ID, $identity );

		Users::sign_in( $user );

		self::land( $user, $redirect_to );
	}

	/**
	 * Send order updates to the Telegram account that just joined.
	 *
	 * Only when the sign-in bot is the bot that sends the updates, so the
	 * visitor was asked to let it write to them, and only into an empty slot:
	 * an account that already chose a chat, or turned updates off with /stop,
	 * keeps that choice. A private chat with a user has the user's id for its
	 * id. Somebody who refused gets no message: the first one fails with
	 * "can't initiate conversation" and the worker drops the binding.
	 *
	 * @since 1.1.0
	 * @param int   $user_id  Account.
	 * @param array $identity Verified identity.
	 * @return void
	 */
	private static function notify_here( $user_id, array $identity ) {
		if ( '' === $identity['chat'] || ! Provider::writes_to_user() || '' !== Binding::of_user( $user_id ) ) {
			return;
		}

		update_user_option( $user_id, Binding::USER_OPTION, $identity['chat'] );
	}

	/**
	 * Pull the four things we keep out of a verified token.
	 *
	 * The username is display only, and never a way of finding anybody: its
	 * owner can release it and the next person can take it.
	 *
	 * @since 1.1.0
	 * @param array  $claims Verified payload.
	 * @param string $back   Page to return to if the answer is refused.
	 * @return array<string, string>
	 */
	private static function identity( array $claims, $back ) {
		$username = isset( $claims['preferred_username'] ) ? (string) $claims['preferred_username'] : '';
		$sub      = (string) $claims['sub'];

		/*
		 * The subject identifier is the key an account is found by, and it is
		 * looked up through a MySQL comparison, which ignores trailing spaces
		 * and letter case. Pinning the character set here means those can
		 * never come into it — nothing chooses this value but Telegram, and
		 * Telegram has no reason to send anything outside it.
		 */
		if ( ! preg_match( '/^[A-Za-z0-9_.:-]{1,128}$/', $sub ) ) {
			self::log( 'refused: subject identifier has an unexpected shape' );
			self::back( $back, 'unverified' );
		}

		return array(
			'sub'      => $sub,
			'name'     => isset( $claims['name'] ) ? sanitize_text_field( (string) $claims['name'] ) : '',
			'username' => preg_match( '/^[A-Za-z0-9_]{1,32}$/', $username ) ? $username : '',
			'chat'     => isset( $claims['id'] ) && preg_match( '/^[1-9]\d{0,19}$/', (string) $claims['id'] ) ? (string) $claims['id'] : '',
		);
	}

	/**
	 * Send a signed-in visitor on their way.
	 *
	 * Validated against the storefront rather than left to wp_safe_redirect(),
	 * whose own fallback is the dashboard — no place for a customer.
	 *
	 * @since 1.1.0
	 * @param WP_User $user        Account that was signed in.
	 * @param string  $redirect_to Where the visitor wanted to go.
	 * @return void
	 */
	private static function land( WP_User $user, $redirect_to ) {
		$requested = remove_query_arg( self::RESULT, (string) $redirect_to );
		$target    = '' !== $requested ? $requested : self::home();

		/** This filter is documented in wp-login.php */
		$target = apply_filters( 'login_redirect', $target, $requested, $user );

		wp_safe_redirect( wp_validate_redirect( (string) $target, self::home() ) );
		exit;
	}

	/**
	 * Return to the storefront, with a result code when there is something to say.
	 *
	 * The code is a fixed word, never text: Screen owns the wording, and the
	 * address bar carries nothing a visitor could use to make the site say
	 * something it did not. Every refusal reads the same way where it can,
	 * because the visitor is not necessarily the person whose account is
	 * involved.
	 *
	 * @since 1.1.0
	 * @param string $url  Page the visitor started from; empty for the default.
	 * @param string $code Result code, or empty for none.
	 * @return void
	 */
	private static function back( $url, $code = '' ) {
		$url = remove_query_arg( self::RESULT, (string) $url );
		$url = '' !== $url ? wp_validate_redirect( $url, self::home() ) : self::home();

		if ( '' !== $code ) {
			$url = add_query_arg( self::RESULT, $code, $url );
		}

		wp_safe_redirect( $url );
		exit;
	}

	/**
	 * Whether this address may start another attempt.
	 *
	 * Every start writes a row, so an open endpoint that mints them without a
	 * ceiling is a way of filling the options table from the outside.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	private static function within_start_limit() {
		$address = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

		if ( '' === $address ) {
			return true;
		}

		/*
		 * The window number is part of the key, so the counter cannot slide:
		 * writing it again used to push the expiry out, which meant a busy
		 * address never got its allowance back.
		 */
		$window = (int) floor( time() / self::START_WINDOW );
		$key    = 'mvweb_tg_login_starts_' . md5( $address . '|' . $window );
		$count  = (int) get_transient( $key );

		if ( $count >= self::STARTS_PER_WINDOW ) {
			return false;
		}

		set_transient( $key, $count + 1, self::START_WINDOW );

		return true;
	}

	/**
	 * Set one of our cookies.
	 *
	 * The __Host- prefix is what makes a cookie belong to this exact origin: no
	 * Domain attribute, path /, secure only. A subdomain, or the same site over
	 * plain http, cannot write it.
	 *
	 * @since 1.1.0
	 * @param string $name    Cookie name.
	 * @param string $value   Cookie value.
	 * @param int    $expires Expiry timestamp.
	 * @return void
	 */
	private static function set_cookie( $name, $value, $expires ) {
		setcookie(
			$name,
			$value,
			array(
				'expires'  => $expires,
				'path'     => '/',
				'secure'   => true,
				'httponly' => true,
				'samesite' => 'Lax',
			)
		);
	}

	/**
	 * Remove one of our cookies.
	 *
	 * @since 1.1.0
	 * @param string $name Cookie name.
	 * @return void
	 */
	private static function clear_cookie( $name ) {
		self::set_cookie( $name, '', time() - YEAR_IN_SECONDS );

		unset( $_COOKIE[ $name ] );
	}

	/**
	 * Transient key of one attempt.
	 *
	 * @since 1.1.0
	 * @param string $state State value.
	 * @return string
	 */
	private static function attempt_key( $state ) {
		return 'mvweb_tg_login_' . md5( (string) $state );
	}

	/**
	 * Record why a sign-in did not happen.
	 *
	 * Goes to the plugin's own delivery log, where the operator already looks
	 * when something is wrong. The visitor is told nothing beyond "it did not
	 * work" — the detail is for the person who can act on it.
	 *
	 * @since 1.1.0
	 * @param string $message What happened.
	 * @return void
	 */
	private static function log( $message ) {
		Repository::add(
			array(
				'module'        => 'login',
				'object_id'     => 0,
				'chat_id'       => '',
				'attempt'       => 1,
				'status'        => Repository::STATUS_FAILED,
				'error_code'    => 0,
				'error_message' => (string) $message,
			)
		);
	}
}
