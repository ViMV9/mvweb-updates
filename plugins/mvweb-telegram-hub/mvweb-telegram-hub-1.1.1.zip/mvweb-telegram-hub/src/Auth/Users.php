<?php
/**
 * Accounts on the WordPress side of a Telegram identity.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Auth;

use MVweb\Telegram\Hub\Settings;
use WP_Error;
use WP_User;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Finding, creating and signing in the person behind a verified sub.
 *
 * Two rules run through all of it.
 *
 * The first is that an account is only ever found by the subject identifier out
 * of a signature we checked ourselves. Never by e-mail, never by username. That
 * is not caution: matching on an address supplied by the caller is the root of
 * CVE-2023-2982, CVE-2024-9893, CVE-2025-1061 and CVE-2024-10961, four separate
 * plugins scoring 9.8 for the same mistake. A preferred_username is worse still
 * — its owner can release it and somebody else can take it.
 *
 * The second is that signing in this way skips the authenticate filter, and
 * with it every two-factor plugin on the site. So the capability ceiling below
 * is not decoration: without it, switching this feature on would quietly become
 * a way around the site's second factor for its administrators.
 *
 * @since 1.1.0
 */
final class Users {

	/**
	 * User option holding the verified Telegram subject identifier.
	 *
	 * Deliberately not the chat id the notification feature keeps. They are
	 * different values, and that one is handed out to whoever opens a link to
	 * an order — an identifier good enough to receive a delivery note is not
	 * good enough to receive a session.
	 *
	 * @var string
	 */
	public const SUB_OPTION = 'mvweb_tg_sub';

	/**
	 * User option holding the Telegram username, for display only.
	 *
	 * @var string
	 */
	public const NAME_OPTION = 'mvweb_tg_username';

	/**
	 * Capabilities that make an account privileged.
	 *
	 * Compared by capability rather than by role name: on somebody else's site
	 * the role that installs plugins may be called anything at all.
	 *
	 * @var string[]
	 */
	private const PRIVILEGED = array( 'manage_options', 'edit_users', 'install_plugins', 'edit_posts' );

	/**
	 * New accounts allowed in one hour.
	 *
	 * @var int
	 */
	private const REGISTRATIONS_PER_HOUR = 20;

	/**
	 * Transient counting registrations.
	 *
	 * @var string
	 */
	private const RATE_TRANSIENT = 'mvweb_tg_login_registrations';

	/**
	 * Account holding this subject identifier.
	 *
	 * @since 1.1.0
	 * @param string $sub Verified subject identifier.
	 * @return int User id, 0 when nobody holds it, -1 when more than one does.
	 */
	public static function by_sub( $sub ) {
		global $wpdb;

		$sub = trim( (string) $sub );

		if ( '' === $sub ) {
			return 0;
		}

		$ids = get_users(
			array(
				'meta_key'   => $wpdb->get_blog_prefix() . self::SUB_OPTION, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- indexed by meta_key, bounded by number.
				'meta_value' => $sub,                                        // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- see above.
				'number'     => 2,
				'fields'     => 'ID',
			)
		);

		if ( ! is_array( $ids ) || array() === $ids ) {
			return 0;
		}

		return count( $ids ) > 1 ? -1 : (int) $ids[0];
	}

	/**
	 * Subject identifier held by an account.
	 *
	 * @since 1.1.0
	 * @param int $user_id User id.
	 * @return string
	 */
	public static function sub_of( $user_id ) {
		$user_id = absint( $user_id );

		return $user_id ? (string) get_user_option( self::SUB_OPTION, $user_id ) : '';
	}

	/**
	 * Telegram username held by an account, without the leading @.
	 *
	 * @since 1.1.0
	 * @param int $user_id User id.
	 * @return string
	 */
	public static function username_of( $user_id ) {
		$user_id = absint( $user_id );

		return $user_id ? (string) get_user_option( self::NAME_OPTION, $user_id ) : '';
	}

	/**
	 * Attach a Telegram identity to an account.
	 *
	 * One account carries at most one Telegram, and one Telegram belongs to at
	 * most one account. Both directions are checked, and a clash is refused
	 * rather than resolved by picking the first row.
	 *
	 * @since 1.1.0
	 * @param int    $user_id  Account to attach to.
	 * @param string $sub      Verified subject identifier.
	 * @param string $username Telegram username, for display.
	 * @return true|WP_Error
	 */
	public static function link( $user_id, $sub, $username = '' ) {
		$user_id = absint( $user_id );
		$sub     = trim( (string) $sub );

		if ( ! $user_id || '' === $sub ) {
			return new WP_Error( 'mvweb_tg_link_invalid', __( 'Nothing to connect.', 'mvweb-telegram-hub' ) );
		}

		$existing = self::sub_of( $user_id );

		if ( '' !== $existing && ! hash_equals( $existing, $sub ) ) {
			return new WP_Error(
				'mvweb_tg_link_occupied',
				__( 'This account already has a Telegram account connected. Disconnect that one first.', 'mvweb-telegram-hub' )
			);
		}

		$holder = self::by_sub( $sub );

		if ( -1 === $holder || ( $holder > 0 && $holder !== $user_id ) ) {
			return new WP_Error(
				'mvweb_tg_link_taken',
				__( 'This Telegram account is already connected to another account on this site.', 'mvweb-telegram-hub' )
			);
		}

		update_user_option( $user_id, self::SUB_OPTION, $sub );

		if ( '' !== $username ) {
			update_user_option( $user_id, self::NAME_OPTION, $username );
		}

		/**
		 * Fires after a Telegram identity is attached to an account.
		 *
		 * @since 1.1.0
		 * @param int    $user_id Account the identity was attached to.
		 * @param string $sub     Verified subject identifier.
		 */
		do_action( 'mvweb_tg_linked', $user_id, $sub );

		return true;
	}

	/**
	 * Detach the Telegram identity from an account.
	 *
	 * @since 1.1.0
	 * @param int $user_id User id.
	 * @return void
	 */
	public static function unlink( $user_id ) {
		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return;
		}

		delete_user_option( $user_id, self::SUB_OPTION );
		delete_user_option( $user_id, self::NAME_OPTION );
	}

	/**
	 * Whether this account may be given a session through Telegram.
	 *
	 * Only accounts in one of the roles the operator ticked, and never one that
	 * can edit content or run the site: signing in with Telegram is for the
	 * people who buy and comment, and it bypasses every second factor.
	 *
	 * @since 1.1.0
	 * @param WP_User $user Account being signed in.
	 * @return bool
	 */
	public static function may_sign_in( WP_User $user ) {
		$allowed = ! self::is_privileged( $user )
			&& array() !== array_intersect( (array) $user->roles, self::allowed_roles() );

		/**
		 * Filter whether an account may sign in through Telegram.
		 *
		 * The hook a two-factor plugin can hold on to: this path never reaches
		 * the authenticate filter, so nothing else on the site gets a say.
		 *
		 * @since 1.1.0
		 * @param bool    $allowed Whether the sign-in may proceed.
		 * @param WP_User $user    Account being signed in.
		 */
		return (bool) apply_filters( 'mvweb_tg_can_login', $allowed, $user );
	}

	/**
	 * Whether an account carries any of the capabilities that matter.
	 *
	 * @since 1.1.0
	 * @param WP_User $user Account to inspect.
	 * @return bool
	 */
	public static function is_privileged( WP_User $user ) {
		foreach ( self::PRIVILEGED as $capability ) {
			if ( $user->has_cap( $capability ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Hand out the session.
	 *
	 * Exactly what wp_signon() does once it is satisfied, and nothing more.
	 * wp_signon() itself is no use here: it runs the authenticate filter, where
	 * wp_authenticate_username_password sits at priority 20 and turns an empty
	 * password into an error. The wp_login action is not optional either — the
	 * WooCommerce customer session, login limiters and audit logs all hang off
	 * it.
	 *
	 * @since 1.1.0
	 * @param WP_User $user     Account to sign in.
	 * @param bool    $remember Whether to issue a long-lived cookie.
	 * @return void
	 */
	public static function sign_in( WP_User $user, $remember = false ) {
		wp_set_auth_cookie( $user->ID, (bool) $remember );
		wp_set_current_user( $user->ID );

		do_action( 'wp_login', $user->user_login, $user );
	}

	/**
	 * Roles allowed to sign in with Telegram.
	 *
	 * The ticked list from the settings, narrowed to roles that exist on this
	 * site and carry none of the privileged capabilities. A role that gains
	 * one of them later drops out on its own.
	 *
	 * @since 1.1.0
	 * @return string[] Role slugs.
	 */
	public static function allowed_roles() {
		return array_values( array_intersect( Settings::login_roles(), array_keys( self::eligible_roles() ) ) );
	}

	/**
	 * Roles that could be offered in the settings at all.
	 *
	 * @since 1.1.0
	 * @return array<string, string> Role slug mapped to its translated name.
	 */
	public static function eligible_roles() {
		$roles = array();

		foreach ( wp_roles()->roles as $slug => $role ) {
			$caps = isset( $role['capabilities'] ) && is_array( $role['capabilities'] ) ? $role['capabilities'] : array();

			foreach ( self::PRIVILEGED as $capability ) {
				if ( ! empty( $caps[ $capability ] ) ) {
					continue 2;
				}
			}

			$roles[ $slug ] = translate_user_role( $role['name'] );
		}

		return $roles;
	}

	/**
	 * Role a new account is given.
	 *
	 * The shop's own customer role when WooCommerce provides one, otherwise the
	 * site's default role — and only if that role is on the allowed list, or the
	 * account would be created and then refused at its first sign-in.
	 *
	 * @since 1.1.0
	 * @return string Role slug, empty when no allowed role fits.
	 */
	public static function new_account_role() {
		$allowed = self::allowed_roles();

		foreach ( array( 'customer', (string) get_option( 'default_role', 'subscriber' ) ) as $role ) {
			if ( get_role( $role ) && in_array( $role, $allowed, true ) ) {
				return $role;
			}
		}

		return '';
	}

	/**
	 * Whether a brand new visitor may be given an account.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function registration_allowed() {
		if ( ! Settings::login_registration() ) {
			return false;
		}

		// Core enforces users_can_register in wp-login.php, not in
		// the user functions, so a plugin that creates accounts itself walks
		// straight past the site's own answer unless it asks.
		if ( ! get_option( 'users_can_register' ) && ! Settings::login_registration_when_closed() ) {
			return false;
		}

		return '' !== self::new_account_role();
	}

	/**
	 * Create an account for a verified identity.
	 *
	 * The account has no email address. Telegram does not share one, and one
	 * typed in by the visitor would prove nothing: anybody could attach a
	 * stranger's address to an account their own Telegram opens. The customer
	 * gives an address with the first order, and it stays on the order.
	 *
	 * wp_insert_user() rather than register_new_user(): the latter insists on an
	 * address, mails a "set your password" link and flags the account as
	 * holding a temporary password, none of which applies to an account that
	 * signs in through Telegram. It still runs sanitize_user, the illegal login
	 * list and the duplicate login check.
	 *
	 * @since 1.1.0
	 * @param string $sub      Verified subject identifier.
	 * @param string $name     Display name from the token, if any.
	 * @param string $username Telegram username, for display.
	 * @return int|WP_Error New user id.
	 */
	public static function register( $sub, $name = '', $username = '' ) {
		if ( ! self::registration_allowed() ) {
			return new WP_Error( 'mvweb_tg_registration_closed', __( 'This site is not accepting new accounts.', 'mvweb-telegram-hub' ) );
		}

		if ( ! self::within_rate_limit() ) {
			return new WP_Error( 'mvweb_tg_registration_rate', __( 'Too many accounts have been created in the past hour. Try again later.', 'mvweb-telegram-hub' ) );
		}

		$name    = trim( sanitize_text_field( (string) $name ) );
		$display = '' !== $name ? $name : (string) $username;
		$user_id = wp_insert_user(
			array(
				'user_login'   => self::technical_login( $sub ),
				'user_pass'    => wp_generate_password( 32, true, true ),
				'user_email'   => '',
				'display_name' => $display,
				'nickname'     => $display,
				'role'         => self::new_account_role(),
			)
		);

		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		self::count_registration();

		$linked = self::link( $user_id, $sub, $username );

		if ( is_wp_error( $linked ) ) {
			/*
			 * Nobody can ever sign in as this account, so it is not left behind.
			 * The two removal functions live in two different files and neither
			 * one is loaded here — this runs on wp-login.php, not in the admin.
			 * wpmu_delete_user() in particular is in ms.php, which user.php does
			 * not pull in, so asking for the wrong file is a fatal error on the
			 * one path that exists to clean up after a failure.
			 */
			if ( ! function_exists( 'wp_delete_user' ) ) {
				require_once ABSPATH . 'wp-admin/includes/user.php';
			}

			if ( is_multisite() ) {
				if ( ! function_exists( 'wpmu_delete_user' ) ) {
					require_once ABSPATH . 'wp-admin/includes/ms.php';
				}

				wpmu_delete_user( $user_id );
			} else {
				wp_delete_user( $user_id );
			}

			return $linked;
		}

		return (int) $user_id;
	}

	/**
	 * Login name derived from the subject identifier.
	 *
	 * Technical on purpose. A name out of the token would not survive
	 * validate_username(), which runs a strict sanitize_user() and drops
	 * everything outside a-z, digits and a handful of punctuation — a Cyrillic
	 * first name comes back empty.
	 *
	 * @since 1.1.0
	 * @param string $sub Verified subject identifier.
	 * @return string
	 */
	public static function technical_login( $sub ) {
		return 'tg_' . substr( hash( 'sha256', (string) $sub ), 0, 12 );
	}

	/**
	 * Whether another account may be created this hour.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	private static function within_rate_limit() {
		return (int) get_transient( self::RATE_TRANSIENT ) < self::REGISTRATIONS_PER_HOUR;
	}

	/**
	 * Count one account against the hourly ceiling.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	private static function count_registration() {
		set_transient( self::RATE_TRANSIENT, (int) get_transient( self::RATE_TRANSIENT ) + 1, HOUR_IN_SECONDS );
	}
}
