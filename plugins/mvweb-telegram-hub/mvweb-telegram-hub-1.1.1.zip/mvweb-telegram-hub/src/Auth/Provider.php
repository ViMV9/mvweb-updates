<?php
/**
 * Telegram as an OpenID Connect provider.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Auth;

use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Everything that talks to oauth.telegram.org.
 *
 * Telegram archived its Login Widget and moved sign-in to OpenID Connect, so
 * there is no third-party script on the login page and the bot token is not
 * the key that proves anything. The client credentials come from BotFather and
 * live apart from the bot token.
 *
 * One rule holds the whole class together: no HTTP call ever happens where
 * somebody is waiting for a page. Discovery is refreshed from the settings
 * screen and read from cache everywhere else; the key set is fetched once the
 * visitor is already coming back from Telegram, and cached for half a day.
 * A login page that waited fifteen seconds on a foreign host would be a login
 * page that breaks whenever that host has a bad minute.
 *
 * @since 1.1.0
 */
final class Provider {

	/**
	 * Issuer, as published in the discovery document.
	 *
	 * @var string
	 */
	public const ISSUER = 'https://oauth.telegram.org';

	/**
	 * Where the discovery document lives.
	 *
	 * @var string
	 */
	private const DISCOVERY_URL = self::ISSUER . '/.well-known/openid-configuration';

	/**
	 * Transient holding the discovery document.
	 *
	 * @var string
	 */
	private const CONFIG_TRANSIENT = 'mvweb_tg_oidc_config';

	/**
	 * Transient holding the signing keys.
	 *
	 * @var string
	 */
	private const JWKS_TRANSIENT = 'mvweb_tg_oidc_jwks';

	/**
	 * Request timeout in seconds.
	 *
	 * @var int
	 */
	private const TIMEOUT = 15;

	/**
	 * Largest answer worth reading, in bytes.
	 *
	 * Everything expected here is a few kilobytes. Without a ceiling the whole
	 * body is read into memory before json_decode() ever sees it, which turns
	 * a misbehaving or hijacked host into an out-of-memory error.
	 *
	 * @var int
	 */
	private const MAX_RESPONSE = 262144;

	/**
	 * Scopes asked for.
	 *
	 * Only the two that identify a person. The phone scope Telegram also offers
	 * is left alone: it is worth having in a shop, but asking for it turns a
	 * one-tap sign-in into a consent screen about a phone number, and nothing
	 * in this feature needs it.
	 *
	 * @var string
	 */
	private const SCOPE = 'openid profile';

	/**
	 * Scope that lets the bot write to the person who signed in.
	 *
	 * Asked for only when the sign-in bot is also the bot that sends order
	 * updates, so a customer who joins through Telegram gets them there
	 * without a separate "Connect Telegram" step.
	 *
	 * @var string
	 */
	private const WRITE_SCOPE = 'telegram:bot_access';

	/**
	 * Endpoints used when discovery cannot be reached.
	 *
	 * Not a shortcut around discovery — the document is still fetched and
	 * cached. This is what keeps a sign-in working through a minute of network
	 * trouble instead of failing on a lookup whose answer has not changed.
	 *
	 * @var array<string, string>
	 */
	private const FALLBACK = array(
		'issuer'                 => self::ISSUER,
		'authorization_endpoint' => self::ISSUER . '/auth',
		'token_endpoint'         => self::ISSUER . '/token',
		'jwks_uri'               => self::ISSUER . '/.well-known/jwks.json',
	);

	/**
	 * The discovery document, from cache only.
	 *
	 * Never fetches. This is read while a visitor is mid-click, and a cold
	 * cache used to mean a blocking request of up to fifteen seconds inside
	 * that click — for a document whose four values, checked against the live
	 * endpoint, are byte for byte the constants above. Refreshing is the job
	 * of the settings screen, which is the one place where somebody is
	 * deliberately waiting for an answer from Telegram.
	 *
	 * @since 1.1.0
	 * @return array<string, mixed>
	 */
	public static function config() {
		$cached = get_transient( self::CONFIG_TRANSIENT );

		return is_array( $cached ) && ! empty( $cached['token_endpoint'] ) ? $cached : self::FALLBACK;
	}

	/**
	 * Read the discovery document and cache it if it is usable.
	 *
	 * @since 1.1.0
	 * @return array|null The document, or null when it could not be had.
	 */
	private static function refresh_config() {
		$document = self::fetch_json( self::DISCOVERY_URL );

		// jwks_uri is checked here rather than where it is read: a document
		// missing it would otherwise be cached for twelve hours and every
		// sign-in in that window would die on an undefined key.
		if ( ! is_array( $document ) || empty( $document['token_endpoint'] ) || empty( $document['authorization_endpoint'] ) || empty( $document['jwks_uri'] ) ) {
			return null;
		}

		// The issuer a token claims has to match the issuer we asked, and a
		// discovery document that names somebody else is not one we follow.
		if ( ! isset( $document['issuer'] ) || self::ISSUER !== $document['issuer'] ) {
			return null;
		}

		set_transient( self::CONFIG_TRANSIENT, $document, 12 * HOUR_IN_SECONDS );

		return $document;
	}

	/**
	 * Address the visitor is sent to.
	 *
	 * @since 1.1.0
	 * @param string $state    Opaque value tying the answer to this browser.
	 * @param string $nonce    Value echoed back in the token, when supported.
	 * @param string $verifier PKCE code verifier.
	 * @return string
	 */
	public static function authorize_url( $state, $nonce, $verifier ) {
		$config = self::config();

		return add_query_arg(
			array(
				'client_id'             => rawurlencode( Settings::login_client_id() ),
				'redirect_uri'          => rawurlencode( self::redirect_uri() ),
				'response_type'         => 'code',
				'scope'                 => rawurlencode( self::writes_to_user() ? self::SCOPE . ' ' . self::WRITE_SCOPE : self::SCOPE ),
				'state'                 => rawurlencode( $state ),
				'nonce'                 => rawurlencode( $nonce ),
				'code_challenge'        => rawurlencode( self::challenge( $verifier ) ),
				'code_challenge_method' => 'S256',
			),
			$config['authorization_endpoint']
		);
	}

	/**
	 * Swap the authorisation code for an identity token.
	 *
	 * Server to server over TLS, with the client secret and the PKCE verifier.
	 * The code arrived through the visitor's browser and is worthless without
	 * both.
	 *
	 * @since 1.1.0
	 * @param string $code     Code Telegram sent back.
	 * @param string $verifier PKCE code verifier held for this attempt.
	 * @return array {
	 *     Outcome.
	 *
	 *     @type bool   $ok       Whether a token came back.
	 *     @type string $id_token The identity token, unverified.
	 *     @type string $error    What went wrong, for the log.
	 * }
	 */
	public static function exchange( $code, $verifier ) {
		$config = self::config();

		$response = wp_safe_remote_post(
			$config['token_endpoint'],
			array(
				'timeout'             => self::TIMEOUT,
				'limit_response_size' => self::MAX_RESPONSE,
				'headers'             => array(
					'Accept'        => 'application/json',
					'Authorization' => 'Basic ' . base64_encode( Settings::login_client_id() . ':' . Settings::login_secret() ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- HTTP Basic authentication, which Telegram requires here.
				),
				'body'                => array(
					'grant_type'    => 'authorization_code',
					'code'          => (string) $code,
					'redirect_uri'  => self::redirect_uri(),
					'client_id'     => Settings::login_client_id(),
					'code_verifier' => (string) $verifier,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return self::failed( $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $body ) ) {
			return self::failed( __( 'Telegram returned a malformed response.', 'mvweb-telegram-hub' ) );
		}

		if ( empty( $body['id_token'] ) || ! is_string( $body['id_token'] ) ) {
			$error = isset( $body['error_description'] ) ? $body['error_description'] : '';

			if ( '' === $error ) {
				$error = isset( $body['error'] ) ? $body['error'] : __( 'no identity token in the answer', 'mvweb-telegram-hub' );
			}

			return self::failed( (string) $error );
		}

		return array(
			'ok'       => true,
			'id_token' => $body['id_token'],
			'error'    => '',
		);
	}

	/**
	 * Signing keys, cached.
	 *
	 * @since 1.1.0
	 * @param bool $fresh Skip the cache. Used once when a key id is unknown,
	 *                    which is what a key rotation looks like from here.
	 * @return array<string, array> Key id mapped to the key.
	 */
	public static function jwks( $fresh = false ) {
		if ( ! $fresh ) {
			$cached = get_transient( self::JWKS_TRANSIENT );

			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$config   = self::config();
		$document = self::fetch_json( $config['jwks_uri'] );
		$keys     = array();

		if ( is_array( $document ) && isset( $document['keys'] ) && is_array( $document['keys'] ) ) {
			foreach ( $document['keys'] as $key ) {
				if ( is_array( $key ) && ! empty( $key['kid'] ) ) {
					$keys[ (string) $key['kid'] ] = $key;
				}
			}
		}

		if ( array() === $keys ) {
			return array();
		}

		set_transient( self::JWKS_TRANSIENT, $keys, 12 * HOUR_IN_SECONDS );

		return $keys;
	}

	/**
	 * The one address Telegram is allowed to send the answer back to.
	 *
	 * Built from wp_login_url() rather than from site_url(), so a site that
	 * moved its login page keeps a working address. That address is registered
	 * with BotFather by hand and cannot be edited afterwards, which is the one
	 * thing the settings screen says twice.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function redirect_uri() {
		return add_query_arg( 'action', Flow::CALLBACK, wp_login_url() );
	}

	/**
	 * Whether sign-in can be attempted at all.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function is_configured() {
		return '' !== Settings::login_client_id() && '' !== Settings::login_secret();
	}

	/**
	 * Whether the sign-in bot is the bot that sends order updates.
	 *
	 * The client id BotFather issues is the bot's own id, the part of the
	 * token before the colon.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function writes_to_user() {
		$client = Settings::login_client_id();

		return '' !== $client && strtok( Settings::token(), ':' ) === $client;
	}

	/**
	 * Ask Telegram whether it is there, for the settings screen.
	 *
	 * The only place that fetches the discovery document, and therefore the
	 * only place that keeps it current. That is not a limitation to work
	 * around: connecting the feature means pressing this button, and this is
	 * the one screen where somebody is deliberately waiting for Telegram.
	 *
	 * @since 1.1.0
	 * @return array {
	 *     Outcome.
	 *
	 *     @type bool   $ok      Whether the discovery document came back.
	 *     @type string $message Sentence for the operator.
	 * }
	 */
	public static function check() {
		delete_transient( self::CONFIG_TRANSIENT );
		delete_transient( self::JWKS_TRANSIENT );

		if ( ! self::refresh_config() ) {
			return array(
				'ok'      => false,
				'message' => __( 'This site could not reach oauth.telegram.org. Sign-in will not work until it can — the visitor’s browser has to reach it as well.', 'mvweb-telegram-hub' ),
			);
		}

		$keys = self::jwks( true );

		if ( array() === $keys ) {
			return array(
				'ok'      => false,
				'message' => __( 'Telegram answered, but its signing keys could not be read. Try again in a minute.', 'mvweb-telegram-hub' ),
			);
		}

		return array(
			'ok'      => true,
			'message' => sprintf(
				/* translators: %d: number of signing keys published by Telegram. */
				__( 'Telegram answered and published %d signing keys. The connection from this site is fine.', 'mvweb-telegram-hub' ),
				count( $keys )
			),
		);
	}

	/**
	 * PKCE challenge for a verifier.
	 *
	 * @since 1.1.0
	 * @param string $verifier Code verifier.
	 * @return string
	 */
	private static function challenge( $verifier ) {
		return rtrim( strtr( base64_encode( hash( 'sha256', (string) $verifier, true ) ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- base64url, as PKCE defines it.
	}

	/**
	 * Fetch and decode a JSON document.
	 *
	 * @since 1.1.0
	 * @param string $url Address to read.
	 * @return array|null Null when anything went wrong.
	 */
	private static function fetch_json( $url ) {
		$response = wp_safe_remote_get(
			$url,
			array(
				'timeout'             => self::TIMEOUT,
				'limit_response_size' => self::MAX_RESPONSE,
				'headers'             => array( 'Accept' => 'application/json' ),
			)
		);

		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return null;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		return is_array( $body ) ? $body : null;
	}

	/**
	 * Shape a failed exchange.
	 *
	 * @since 1.1.0
	 * @param string $error What went wrong.
	 * @return array
	 */
	private static function failed( $error ) {
		return array(
			'ok'       => false,
			'id_token' => '',
			'error'    => (string) $error,
		);
	}
}
