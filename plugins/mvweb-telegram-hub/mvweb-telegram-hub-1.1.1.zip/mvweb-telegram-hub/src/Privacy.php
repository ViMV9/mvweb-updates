<?php
/**
 * Personal data disclosure, export and erasure.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub;

use MVweb\Telegram\Hub\Auth\Users;
use MVweb\Telegram\Hub\Link\Binding;
use WC_Customer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Makes the Telegram binding visible to the tools that handle personal data.
 *
 * A chat id identifies a person, so it belongs in the shop's privacy policy,
 * in a data export and in an erasure request. The order-side of it hangs off
 * WooCommerce's own filters rather than a pair of exporters of our own — that
 * way the value is also removed by the shop's data-retention schedule and by
 * the "Remove personal data" action in the orders list, neither of which ever
 * asks a third-party exporter anything.
 *
 * @since 1.1.0
 */
final class Privacy {

	/**
	 * Hook the disclosure and the four WooCommerce filters.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function register() {
		add_action( 'admin_init', array( $this, 'add_policy_content' ) );

		// Sign-in works with or without WooCommerce, so its data goes through
		// the core tools rather than the shop's.
		add_filter( 'wp_privacy_personal_data_exporters', array( $this, 'register_exporter' ) );
		add_filter( 'wp_privacy_personal_data_erasers', array( $this, 'register_eraser' ) );

		add_filter( 'woocommerce_privacy_export_order_personal_data_meta', array( $this, 'export_order_meta' ) );
		add_filter( 'woocommerce_privacy_remove_order_personal_data_meta', array( $this, 'erase_order_meta' ) );
		add_filter( 'woocommerce_privacy_remove_order_personal_data_meta_value', array( $this, 'erase_order_meta_value' ), 10, 2 );
		add_filter( 'woocommerce_privacy_export_customer_personal_data', array( $this, 'export_customer_data' ), 10, 2 );
		add_filter( 'woocommerce_privacy_erase_personal_data_customer', array( $this, 'erase_customer_data' ), 10, 2 );
	}

	/**
	 * Suggested wording for the site's privacy policy.
	 *
	 * Only useful on admin_init — anywhere else WordPress answers with
	 * _doing_it_wrong and drops the text.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function add_policy_content() {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		wp_add_privacy_policy_content(
			__( 'MVweb Telegram Hub', 'mvweb-telegram-hub' ),
			wp_kses_post(
				'<p>' . __( 'When a customer connects Telegram to their orders, we store the identifier of their Telegram chat and send order details — the order number, its status and its total — through the servers of Telegram Messenger Inc. That means the data leaves this site and, depending on where the customer is, crosses a border. Nothing is sent until the customer opens the chat and presses the start button, and they can stop it at any time from their order page or by sending /stop to the bot.', 'mvweb-telegram-hub' ) . '</p>'
				. '<p>' . __( 'When somebody signs in with Telegram, we store the account identifier Telegram gives us and the username it publishes. An account created this way has no email address until its owner adds one. If the sign-in bot also sends order updates, the Telegram account it signed in with is where they go. Telegram is told which site the sign-in is for. A page that shows the sign-in button also makes one request to Telegram from the visitor’s browser, purely to find out whether the button is worth showing.', 'mvweb-telegram-hub' ) . '</p>'
			)
		);
	}

	/**
	 * Declare the sign-in exporter.
	 *
	 * @since 1.1.0
	 * @param array $exporters Registered exporters.
	 * @return array
	 */
	public function register_exporter( $exporters ) {
		$exporters = is_array( $exporters ) ? $exporters : array();

		$exporters['mvweb-telegram-hub-login'] = array(
			'exporter_friendly_name' => __( 'Telegram sign-in', 'mvweb-telegram-hub' ),
			'callback'               => array( $this, 'export_login_data' ),
		);

		return $exporters;
	}

	/**
	 * Declare the sign-in eraser.
	 *
	 * @since 1.1.0
	 * @param array $erasers Registered erasers.
	 * @return array
	 */
	public function register_eraser( $erasers ) {
		$erasers = is_array( $erasers ) ? $erasers : array();

		$erasers['mvweb-telegram-hub-login'] = array(
			'eraser_friendly_name' => __( 'Telegram sign-in', 'mvweb-telegram-hub' ),
			'callback'             => array( $this, 'erase_login_data' ),
		);

		return $erasers;
	}

	/**
	 * What we hold about somebody's Telegram sign-in.
	 *
	 * @since 1.1.0
	 * @param string $email_address Address the request was made for.
	 * @return array
	 */
	public function export_login_data( $email_address ) {
		$empty = array(
			'data' => array(),
			'done' => true,
		);

		$user = get_user_by( 'email', $email_address );

		if ( ! $user ) {
			return $empty;
		}

		$sub = Users::sub_of( $user->ID );

		if ( '' === $sub ) {
			return $empty;
		}

		$items = array(
			array(
				'name'  => __( 'Telegram account identifier', 'mvweb-telegram-hub' ),
				'value' => $sub,
			),
		);

		$username = Users::username_of( $user->ID );

		if ( '' !== $username ) {
			$items[] = array(
				'name'  => __( 'Telegram username', 'mvweb-telegram-hub' ),
				'value' => '@' . $username,
			);
		}

		return array(
			'data' => array(
				array(
					'group_id'    => 'mvweb-telegram-hub-login',
					'group_label' => __( 'Telegram sign-in', 'mvweb-telegram-hub' ),
					'item_id'     => 'mvweb-tg-login-' . $user->ID,
					'data'        => $items,
				),
			),
			'done' => true,
		);
	}

	/**
	 * Drop the Telegram identity on an erasure request.
	 *
	 * @since 1.1.0
	 * @param string $email_address Address the request was made for.
	 * @return array
	 */
	public function erase_login_data( $email_address ) {
		$response = array(
			'items_removed'  => false,
			'items_retained' => false,
			'messages'       => array(),
			'done'           => true,
		);

		$user = get_user_by( 'email', $email_address );

		if ( ! $user || '' === Users::sub_of( $user->ID ) ) {
			return $response;
		}

		Users::unlink( $user->ID );

		$response['items_removed'] = true;
		$response['messages'][]    = __( 'Removed the Telegram sign-in connection.', 'mvweb-telegram-hub' );

		return $response;
	}

	/**
	 * Include the chat id in an order data export.
	 *
	 * @since 1.1.0
	 * @param array $meta Meta keys mapped to their exported labels.
	 * @return array
	 */
	public function export_order_meta( $meta ) {
		$meta = is_array( $meta ) ? $meta : array();

		$meta[ Binding::ORDER_META ] = __( 'Telegram chat for notifications', 'mvweb-telegram-hub' );

		return $meta;
	}

	/**
	 * Include the chat id in order data erasure.
	 *
	 * @since 1.1.0
	 * @param array $meta Meta keys mapped to how they should be cleared.
	 * @return array
	 */
	public function erase_order_meta( $meta ) {
		$meta = is_array( $meta ) ? $meta : array();

		$meta[ Binding::ORDER_META ] = 'text';

		return $meta;
	}

	/**
	 * Erase the chat id outright instead of anonymising it.
	 *
	 * WooCommerce reads the value from the list above as a data type and asks
	 * wp_privacy_anonymize_data() what to put in its place; for 'text' that is
	 * the literal "[deleted]", and a non-empty replacement makes it overwrite
	 * the meta rather than remove it. That would leave a binding behind that
	 * is not a chat id and not empty either — Telegram would answer 400 on
	 * every status change for ever, and the value would hide the customer's
	 * account-wide binding underneath it. An empty replacement is what sends
	 * WooCommerce down its delete_meta_data() branch.
	 *
	 * @since 1.1.0
	 * @param string $anon_value Replacement WooCommerce is about to write.
	 * @param string $meta_key   Meta key being processed.
	 * @return string
	 */
	public function erase_order_meta_value( $anon_value, $meta_key ) {
		return Binding::ORDER_META === $meta_key ? '' : $anon_value;
	}

	/**
	 * Add the account-wide binding to a customer export.
	 *
	 * A plain filter on the assembled list, not a property name: WooCommerce
	 * builds most of that list by calling get_{prop}() on the customer, and
	 * there is no such getter for something we keep in a user option.
	 *
	 * @since 1.1.0
	 * @param array       $data     Rows already collected.
	 * @param WC_Customer $customer Customer being exported.
	 * @return array
	 */
	public function export_customer_data( $data, $customer ) {
		$data = is_array( $data ) ? $data : array();

		if ( ! $customer instanceof WC_Customer ) {
			return $data;
		}

		$chat_id = Binding::of_user( $customer->get_id() );

		if ( '' === $chat_id ) {
			return $data;
		}

		$data[] = array(
			'name'  => __( 'Telegram chat for notifications', 'mvweb-telegram-hub' ),
			'value' => $chat_id,
		);

		return $data;
	}

	/**
	 * Drop the account-wide binding on an erasure request.
	 *
	 * @since 1.1.0
	 * @param array       $response Erasure response being assembled.
	 * @param WC_Customer $customer Customer being erased.
	 * @return array
	 */
	public function erase_customer_data( $response, $customer ) {
		$response = is_array( $response ) ? $response : array();

		if ( ! $customer instanceof WC_Customer || '' === Binding::of_user( $customer->get_id() ) ) {
			return $response;
		}

		Binding::unbind_user( $customer->get_id() );

		$response['items_removed'] = true;
		$response['messages'][]    = __( 'Removed the Telegram notification binding.', 'mvweb-telegram-hub' );

		return $response;
	}
}
