<?php
/**
 * WooCommerce order status module, addressed to the customer.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Modules\WooCustomer;

use MVweb\Telegram\Hub\Frontend\Connect;
use MVweb\Telegram\Hub\Link\Binding;
use MVweb\Telegram\Hub\Modules\ModuleInterface;
use MVweb\Telegram\Hub\Modules\WooOrders\Macros;
use MVweb\Telegram\Hub\Telegram\Formatter;
use WC_Order;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tells a shopper when their own order moves on.
 *
 * A second module rather than a second mode of the operator one. Everything
 * that makes a module — its own switch on the settings screen, its own place
 * in the queue, its own message — comes free with the registry entry, and the
 * module contract stays exactly as it was. Widening ModuleInterface would have
 * been a fatal error at class-compile time for any implementation left on the
 * old signature, which is a white screen for the whole site rather than a
 * broken plugin.
 *
 * @since 1.1.0
 */
final class Module implements ModuleInterface {

	/**
	 * Module slug.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function slug() {
		return 'woo-customer';
	}

	/**
	 * Module name for the settings screen.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function label() {
		return __( 'Order status for the customer', 'mvweb-telegram-hub' );
	}

	/**
	 * WooCommerce must be active and recent enough.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function requirements_met() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return false;
		}

		if ( defined( 'WC_VERSION' ) ) {
			return version_compare( WC_VERSION, MVWEB_TG_MIN_WC, '>=' );
		}

		return true;
	}

	/**
	 * Explain why the module cannot run.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function requirement_message() {
		return sprintf(
			/* translators: 1: module name, 2: minimum WooCommerce version. */
			__( 'The “%1$s” module needs WooCommerce %2$s or newer to be active.', 'mvweb-telegram-hub' ),
			self::label(),
			MVWEB_TG_MIN_WC
		);
	}

	/**
	 * Hook the status trigger, the recipient lookup and the storefront block.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function register() {
		( new Trigger() )->register();
		( new Connect() )->register();

		add_filter( 'mvweb_tg_resolve_chat', array( $this, 'resolve_chat' ), 10, 3 );
	}

	/**
	 * Answer the queue's question "who is this order's message for".
	 *
	 * Asked at delivery rather than when the job was created, so an unsubscribe
	 * takes effect immediately, retries included.
	 *
	 * @since 1.1.0
	 * @param string $chat_id     Chat resolved so far.
	 * @param string $module_slug Module the job belongs to.
	 * @param int    $object_id   Order id.
	 * @return string
	 */
	public function resolve_chat( $chat_id, $module_slug, $object_id ) {
		if ( '' !== (string) $chat_id || self::slug() !== $module_slug ) {
			return $chat_id;
		}

		$order = wc_get_order( absint( $object_id ) );

		return $order instanceof WC_Order ? Binding::for_order( $order ) : '';
	}

	/**
	 * Build the notification text for an order.
	 *
	 * Deliberately not the operator template and deliberately not editable.
	 * What a shopper needs is the order number, where it stands and a way back
	 * to it; what they must not get is a link into wp-admin, their own contact
	 * details read back at them, or a fifteen-line list of what they bought
	 * spilling onto a lock screen. A free-text field on the settings page would
	 * make all three one careless paste away, so the wording is a translatable
	 * string and the shop tunes it through a filter if it really has to.
	 *
	 * @since 1.1.0
	 * @param int $object_id Order id.
	 * @return string|null Null when the order no longer exists.
	 */
	public function build_message( $object_id ) {
		$order = wc_get_order( absint( $object_id ) );

		if ( ! $order instanceof WC_Order ) {
			return null;
		}

		$lines = array(
			'<b>' . sprintf(
				/* translators: %s: order number. */
				Formatter::escape( __( 'Order %s', 'mvweb-telegram-hub' ) ),
				Formatter::escape( $order->get_order_number() )
			) . '</b>',
			sprintf(
				/* translators: %s: order status, e.g. Processing. */
				Formatter::escape( __( 'Status: %s', 'mvweb-telegram-hub' ) ),
				Formatter::escape( wc_get_order_status_name( $order->get_status() ) )
			),
			sprintf(
				/* translators: %s: order total with currency. */
				Formatter::escape( __( 'Total: %s', 'mvweb-telegram-hub' ) ),
				Formatter::escape( Macros::price( $order->get_total(), $order->get_currency() ) )
			),
		);

		$url = self::order_url( $order );

		if ( '' !== $url ) {
			$lines[] = '';
			$lines[] = sprintf(
				'<a href="%1$s">%2$s</a>',
				Formatter::escape( $url ),
				Formatter::escape( __( 'Open the order →', 'mvweb-telegram-hub' ) )
			);
		}

		$text = implode( "\n", $lines );

		/**
		 * Filter the customer notification before it is sent.
		 *
		 * @since 1.1.0
		 * @param string    $text  Message in Telegram HTML.
		 * @param \WC_Order $order Order object.
		 */
		$text = (string) apply_filters( 'mvweb_tg_customer_message', $text, $order );

		return Formatter::truncate( $text, Formatter::SAFE_LIMIT );
	}

	/**
	 * Where the "open the order" button should take this customer.
	 *
	 * A guest has no account page to go to: the meta capability behind
	 * view-order only ever passes the account the order belongs to, and a guest
	 * order belongs to none. The order-received address carries the order key
	 * instead, which is the only door WooCommerce leaves open for them.
	 *
	 * That door is on a timer: ten minutes after the order was placed, the page
	 * starts asking for the billing email. Practically every status change
	 * happens after that, so the link is a convenience and the three lines
	 * above it have to stand on their own.
	 *
	 * @since 1.1.0
	 * @param WC_Order $order Order object.
	 * @return string
	 */
	private static function order_url( WC_Order $order ) {
		return $order->get_customer_id()
			? (string) $order->get_view_order_url()
			: (string) $order->get_checkout_order_received_url();
	}
}
