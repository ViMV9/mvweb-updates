<?php
/**
 * Which order statuses a customer chose to hear about.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.1
 */

namespace MVweb\Telegram\Hub\Modules\WooCustomer;

use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * The shop's list, minus what the customer switched off.
 *
 * What is stored is the customer's "no", not their "yes". A status the shop
 * ticks later reaches everyone at once, including people who saved their
 * choice a year ago; a status the shop unticks is gone for everyone, whatever
 * anybody saved. The customer can only narrow the shop's list, never widen it:
 * the list is also where the shop keeps internal statuses such as a draft or a
 * failed payment away from its customers.
 *
 * A user option rather than plain user meta, like the chat binding next to it:
 * on a multisite the same person can shop on two sites with different choices.
 *
 * @since 1.1.1
 */
final class Preferences {

	/**
	 * User option holding the statuses the customer switched off.
	 *
	 * @since 1.1.1
	 * @var string
	 */
	public const USER_OPTION = 'mvweb_tg_muted_statuses';

	/**
	 * Statuses this customer is told about, prefixed with wc-.
	 *
	 * @since 1.1.1
	 * @param int $user_id User id. Zero for a guest, who gets the shop's list.
	 * @return string[]
	 */
	public static function statuses_for( $user_id ) {
		return array_values( array_diff( Settings::customer_statuses(), self::muted( $user_id ) ) );
	}

	/**
	 * Statuses this customer switched off.
	 *
	 * @since 1.1.1
	 * @param int $user_id User id.
	 * @return string[]
	 */
	public static function muted( $user_id ) {
		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return array();
		}

		$muted = get_user_option( self::USER_OPTION, $user_id );

		return is_array( $muted ) ? array_values( array_filter( $muted, 'is_string' ) ) : array();
	}

	/**
	 * Save the statuses the customer left ticked.
	 *
	 * Anything posted that is not on the shop's list is ignored, so a forged
	 * form cannot switch on a status the shop keeps to itself.
	 *
	 * @since 1.1.1
	 * @param int      $user_id User id.
	 * @param string[] $wanted  Statuses ticked in the form.
	 * @return void
	 */
	public static function save( $user_id, array $wanted ) {
		$muted = array_values( array_diff( Settings::customer_statuses(), $wanted ) );

		if ( $muted ) {
			update_user_option( $user_id, self::USER_OPTION, $muted );
			return;
		}

		delete_user_option( $user_id, self::USER_OPTION );
	}
}
