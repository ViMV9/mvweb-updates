<?php
/**
 * Order macros for the message template.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Modules\WooOrders;

use MVweb\Telegram\Hub\Settings;
use MVweb\Telegram\Hub\Telegram\Formatter;
use MVweb\Telegram\Hub\Telegram\Template;
use WC_Order;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Turns a WC_Order into the values the template expects.
 *
 * Every value is read through the order CRUD API, never through post meta, so
 * the module works the same with HPOS on and off.
 *
 * @since 1.0.0
 */
final class Macros {

	/**
	 * Available macros with their descriptions, for the settings screen.
	 *
	 * @since 1.0.0
	 * @return array<string, string>
	 */
	public static function catalogue() {
		return array(
			'order_id'          => __( 'Order number used inside WordPress', 'mvweb-telegram-hub' ),
			'order_number'      => __( 'Order number shown to the customer', 'mvweb-telegram-hub' ),
			'order_total'       => __( 'Order total with currency', 'mvweb-telegram-hub' ),
			'order_currency'    => __( 'Currency code', 'mvweb-telegram-hub' ),
			'order_items'       => __( 'Line items, one per line', 'mvweb-telegram-hub' ),
			'order_items_count' => __( 'Number of line items', 'mvweb-telegram-hub' ),
			'customer_name'     => __( 'Customer name from the order form', 'mvweb-telegram-hub' ),
			'customer_phone'    => __( 'Customer phone from the order form', 'mvweb-telegram-hub' ),
			'customer_email'    => __( 'Customer email from the order form', 'mvweb-telegram-hub' ),
			'payment_method'    => __( 'How the order is paid for', 'mvweb-telegram-hub' ),
			'shipping_method'   => __( 'How the order is delivered', 'mvweb-telegram-hub' ),
			'order_note'        => __( 'Note left by the customer', 'mvweb-telegram-hub' ),
			'order_date'        => __( 'Order date in the site timezone', 'mvweb-telegram-hub' ),
			'order_status'      => __( 'Order status name', 'mvweb-telegram-hub' ),
			'admin_url'         => __( 'Link that opens the order in the admin', 'mvweb-telegram-hub' ),
			'site_name'         => __( 'Site title', 'mvweb-telegram-hub' ),
		);
	}

	/**
	 * Render the order template.
	 *
	 * @since 1.0.0
	 * @param WC_Order $order    Order object.
	 * @param string   $template Raw template.
	 * @return string
	 */
	public static function render( WC_Order $order, $template ) {
		return Template::render( self::values( $order ), $template );
	}

	/**
	 * Build every macro value, already escaped for Telegram HTML.
	 *
	 * @since 1.0.0
	 * @param WC_Order $order Order object.
	 * @return array<string, string>
	 */
	public static function values( WC_Order $order ) {
		$date = $order->get_date_created();

		return array(
			'order_id'          => Formatter::escape( $order->get_id() ),
			'order_number'      => Formatter::escape( $order->get_order_number() ),
			'order_total'       => Formatter::escape( self::price( $order->get_total(), $order->get_currency() ) ),
			'order_currency'    => Formatter::escape( $order->get_currency() ),
			'order_items'       => self::items( $order ),
			'order_items_count' => Formatter::escape( (string) count( $order->get_items() ) ),
			'customer_name'     => Formatter::escape( trim( $order->get_formatted_billing_full_name() ) ),
			'customer_phone'    => Formatter::escape( $order->get_billing_phone() ),
			'customer_email'    => Formatter::escape( $order->get_billing_email() ),
			'payment_method'    => Formatter::escape( $order->get_payment_method_title() ),
			'shipping_method'   => Formatter::escape( wp_strip_all_tags( (string) $order->get_shipping_method() ) ),
			'order_note'        => Formatter::escape( $order->get_customer_note() ),
			'order_date'        => Formatter::escape( $date ? wp_date( 'd.m.Y H:i', $date->getTimestamp() ) : '' ),
			'order_status'      => Formatter::escape( wc_get_order_status_name( $order->get_status() ) ),
			'admin_url'         => Formatter::escape( $order->get_edit_order_url() ),
			'site_name'         => Formatter::escape( wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ),
		);
	}

	/**
	 * Build the line-items block.
	 *
	 * Capped at the configured limit so a wholesale order cannot blow past the
	 * Telegram message limit; the rest is one line away in wp-admin.
	 *
	 * @since 1.0.0
	 * @param WC_Order $order Order object.
	 * @return string
	 */
	private static function items( WC_Order $order ) {
		$limit = max( 1, (int) Settings::get( 'items_limit', 10 ) );
		$items = $order->get_items();
		$lines = array();
		$shown = 0;

		foreach ( $items as $item ) {
			if ( $shown >= $limit ) {
				break;
			}

			/*
			 * Two lines per item. Product names in a shop run long and wrap in
			 * Telegram, and a "× 2 · 10 400 ₽" tail glued to the end of a wrapped
			 * name is unreadable — and reads as the price of one piece, when it
			 * is the line total. Name on its own line, figures underneath.
			 */
			$lines[] = '• ' . Formatter::escape( $item->get_name() );
			$lines[] = '   ' . self::item_figures( $order, $item );

			++$shown;
		}

		$hidden = count( $items ) - $shown;

		if ( $hidden > 0 ) {
			$lines[] = Formatter::escape(
				sprintf(
					/* translators: %d: number of line items not shown. */
					_n( 'and %d more item', 'and %d more items', $hidden, 'mvweb-telegram-hub' ),
					$hidden
				)
			);
		}

		return implode( "\n", $lines );
	}

	/**
	 * Quantity and money for one line item.
	 *
	 * A single piece needs no arithmetic — just what it costs. More than one
	 * spells the sum out, because "2 × 5 200 ₽" and "10 400 ₽" answer different
	 * questions and the reader should not have to multiply.
	 *
	 * @since 1.0.0
	 * @param WC_Order $order Order object.
	 * @param object   $item  Line item.
	 * @return string
	 */
	private static function item_figures( WC_Order $order, $item ) {
		$currency = $order->get_currency();
		$quantity = (int) $item->get_quantity();
		$total    = Formatter::escape( self::price( $order->get_line_total( $item, true ), $currency ) );

		if ( $quantity <= 1 ) {
			return '<b>' . $total . '</b>';
		}

		return sprintf(
			'%1$s × %2$s = <b>%3$s</b>',
			Formatter::escape( (string) $quantity ),
			Formatter::escape( self::price( $order->get_item_total( $item, true ), $currency ) ),
			$total
		);
	}

	/**
	 * Format a price as plain text.
	 *
	 * The core helper returns markup; Telegram wants text, and the currency
	 * symbol arrives as an HTML entity that has to be decoded before escaping.
	 *
	 * @since 1.0.0
	 * @param float|string $amount   Amount.
	 * @param string       $currency Currency code.
	 * @return string
	 */
	public static function price( $amount, $currency ) {
		$html = wc_price( (float) $amount, array( 'currency' => $currency ) );

		return trim(
			html_entity_decode(
				wp_strip_all_tags( $html ),
				ENT_QUOTES | ENT_HTML5,
				'UTF-8'
			)
		);
	}
}
