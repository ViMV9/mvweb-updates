<?php
/**
 * Macros available in the channel post template.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Modules\Posts;

use MVweb\Telegram\Hub\Settings;
use MVweb\Telegram\Hub\Telegram\Formatter;
use MVweb\Telegram\Hub\Telegram\Template;
use WP_Post;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * What a post can put into a channel message.
 *
 * Every value comes back already escaped for Telegram HTML, except the content
 * one, which is converted instead — it is the only macro that is meant to keep
 * its formatting.
 *
 * @since 1.1.0
 */
final class Macros {

	/**
	 * Macro names and what they mean, for the settings screen.
	 *
	 * @since 1.1.0
	 * @return array<string, string>
	 */
	public static function catalogue() {
		return array(
			'post_title'   => __( 'Post title', 'mvweb-telegram-hub' ),
			'post_url'     => __( 'Address of the post', 'mvweb-telegram-hub' ),
			'post_excerpt' => __( 'Teaser with the post\'s formatting: the written excerpt, or everything before the “more” tag, or the first characters of the post', 'mvweb-telegram-hub' ),
			'post_content' => __( 'Whole post, converted to what Telegram understands', 'mvweb-telegram-hub' ),
			'post_date'    => __( 'Publication date in the site timezone', 'mvweb-telegram-hub' ),
			'post_author'  => __( 'Author name', 'mvweb-telegram-hub' ),
			'post_type'    => __( 'Name of the post type', 'mvweb-telegram-hub' ),
			'categories'   => __( 'Categories, comma separated', 'mvweb-telegram-hub' ),
			'tags'         => __( 'Tags, comma separated', 'mvweb-telegram-hub' ),
			'hashtags'     => __( 'Categories and tags as #hashtags', 'mvweb-telegram-hub' ),
			'site_name'    => __( 'Site title', 'mvweb-telegram-hub' ),
			'site_url'     => __( 'Site address', 'mvweb-telegram-hub' ),
		);
	}

	/**
	 * Render the template for one post.
	 *
	 * @since 1.1.0
	 * @param WP_Post $post     Post being announced.
	 * @param string  $template Raw template.
	 * @param int     $limit    Visible length the message may take.
	 * @return string
	 */
	public static function render( WP_Post $post, $template, $limit = Formatter::SAFE_LIMIT ) {
		return Template::render( self::fit( self::values( $post, $template ), $template, (int) $limit ), $template );
	}

	/**
	 * Shorten the long macros so the whole message fits its limit.
	 *
	 * Cutting the finished message takes its end, and the end of a template is
	 * where the hashtags and the links live. Only the excerpt and the content
	 * are allowed to give way; everything else in the template is measured
	 * first and kept whole.
	 *
	 * The long macros are measured as one character each rather than as
	 * nothing: an empty value drops its whole line from the template, and the
	 * text written around the macro on that line would go uncounted. The
	 * excerpt is fitted before the content, so a template that uses both
	 * keeps its teaser. The placeholder's one unit is left in the count on
	 * purpose: it is the room for the ellipsis a cut value ends with. Escaped
	 * entities are counted at their full length, which only errs on the safe
	 * side.
	 *
	 * @since 1.1.0
	 * @param array<string, string> $values   Macro values.
	 * @param string                $template Raw template.
	 * @param int                   $limit    Visible length the message may take.
	 * @return array<string, string>
	 */
	private static function fit( array $values, $template, $limit ) {
		$uses = array();

		foreach ( array( 'post_excerpt', 'post_content' ) as $key ) {
			$count = substr_count( (string) $template, '{' . $key . '}' );

			if ( $count > 0 ) {
				$uses[ $key ] = $count;
			}
		}

		if ( array() === $uses ) {
			return $values;
		}

		$rest = $values;

		foreach ( $uses as $key => $count ) {
			$rest[ $key ] = '.';
		}

		$budget = $limit - Formatter::length( wp_strip_all_tags( Template::render( $rest, $template ) ) );

		foreach ( $uses as $key => $count ) {
			$share = (int) floor( $budget / $count );

			if ( Formatter::length( wp_strip_all_tags( $values[ $key ] ) ) > $share ) {
				$values[ $key ] = $share > 20 ? Formatter::truncate( $values[ $key ], $share ) : '';
			}

			$budget -= $count * Formatter::length( wp_strip_all_tags( $values[ $key ] ) );
		}

		return $values;
	}

	/**
	 * Every macro value for one post.
	 *
	 * The excerpt and the content each run the post through the_content, so
	 * whatever the template does not ask for is left empty rather than
	 * rendered and thrown away. A filled "Text for Telegram" field stands in
	 * for both: the author wrote it for the channel, so it is taken whole and
	 * only the limit of the message can shorten it.
	 *
	 * @since 1.1.0
	 * @param WP_Post     $post     Post being announced.
	 * @param string|null $template Template the values are for; null renders every macro.
	 * @return array<string, string>
	 */
	public static function values( WP_Post $post, $template = null ) {
		$author = (string) get_the_author_meta( 'display_name', (int) $post->post_author );
		$type   = get_post_type_object( $post->post_type );
		$wants  = static function ( $key ) use ( $template ) {
			return null === $template || false !== strpos( (string) $template, '{' . $key . '}' );
		};
		$own    = $wants( 'post_excerpt' ) || $wants( 'post_content' ) ? Field::text( $post ) : '';

		return array(
			'post_title'   => Formatter::escape( get_the_title( $post ) ),
			'post_url'     => Formatter::escape( (string) get_permalink( $post ) ),
			'post_excerpt' => $wants( 'post_excerpt' ) ? ( '' !== $own ? $own : self::excerpt( $post ) ) : '',
			'post_content' => $wants( 'post_content' ) ? ( '' !== $own ? $own : self::content( $post ) ) : '',
			'post_date'    => Formatter::escape( (string) wp_date( get_option( 'date_format' ), get_post_timestamp( $post ) ) ),
			'post_author'  => Formatter::escape( $author ),
			'post_type'    => Formatter::escape( $type ? $type->labels->singular_name : $post->post_type ),
			'categories'   => Formatter::escape( self::terms( $post ) ),
			'tags'         => Formatter::escape( self::terms( $post, 'post_tag' ) ),
			'hashtags'     => Formatter::escape( self::hashtags( $post ) ),
			'site_name'    => Formatter::escape( wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ),
			'site_url'     => Formatter::escape( home_url( '/' ) ),
		);
	}

	/**
	 * Post content, converted.
	 *
	 * The the_content filter is applied first, so shortcodes, blocks and
	 * whatever a page builder adds are all resolved — the raw post_content of a
	 * block post is a pile of HTML comments.
	 *
	 * @since 1.1.0
	 * @param WP_Post $post Post being announced.
	 * @return string
	 */
	private static function content( WP_Post $post ) {
		if ( post_password_required( $post ) ) {
			return '';
		}

		return Content::convert( self::rendered( $post, $post->post_content ) );
	}

	/**
	 * Raw post markup run through the_content with the post made current.
	 *
	 * @since 1.1.0
	 * @param WP_Post $post Post being announced.
	 * @param string  $raw  Markup to render: the whole post or a part of it.
	 * @return string
	 */
	private static function rendered( WP_Post $post, $raw ) {
		/*
		 * The rendering happens in a queue request, where there is no global
		 * post. Blocks and shortcodes that ask get_the_ID() would answer for
		 * nobody, or for whatever was there before.
		 */
		$previous = isset( $GLOBALS['post'] ) ? $GLOBALS['post'] : null;

		// There is no API for this: setup_postdata() fills everything except the
		// global that get_the_ID() actually reads, and core's own the_post() sets
		// it by hand in the same way. Put back below, whatever happens.
		$GLOBALS['post'] = $post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- restored a few lines down; the_content needs a current post.

		setup_postdata( $post );

		/** This filter is documented in wp-includes/post-template.php */
		$html = apply_filters( 'the_content', (string) $raw );

		wp_reset_postdata();

		// wp_reset_postdata() restores from the main query, which in a queue
		// request is empty — so the global is put back by hand.
		$GLOBALS['post'] = $previous; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- restoring what was there before.

		return (string) $html;
	}

	/**
	 * The excerpt, written or derived, in Telegram HTML.
	 *
	 * A written excerpt wins: it is the author's own choice of words, and the
	 * field holds plain text, so it is escaped rather than converted. Otherwise
	 * the teaser keeps the post's formatting. Everything before the "more" tag
	 * when there is one, since that is exactly where the author asked for the
	 * break; the first few hundred characters, cut at a word, when there is not.
	 *
	 * @since 1.1.0
	 * @param WP_Post $post Post being announced.
	 * @return string
	 */
	private static function excerpt( WP_Post $post ) {
		if ( '' !== trim( (string) $post->post_excerpt ) ) {
			return Formatter::escape( trim( wp_strip_all_tags( $post->post_excerpt ) ) );
		}

		if ( post_password_required( $post ) ) {
			return '';
		}

		$parts = get_extended( (string) $post->post_content );

		if ( '' !== (string) $parts['extended'] ) {
			return Content::convert( self::rendered( $post, $parts['main'] ) );
		}

		return Formatter::truncate(
			Content::convert( self::rendered( $post, $post->post_content ) ),
			Settings::post_excerpt_length()
		);
	}

	/**
	 * Term names of a post, comma separated.
	 *
	 * The default category is left out: WordPress files a post under it when
	 * nobody chose one, and as #Uncategorized it would end every announcement.
	 *
	 * @since 1.1.0
	 * @param WP_Post $post     Post being announced.
	 * @param string  $taxonomy Taxonomy to read.
	 * @return string
	 */
	private static function terms( WP_Post $post, $taxonomy = 'category' ) {
		if ( ! is_object_in_taxonomy( $post->post_type, $taxonomy ) ) {
			return '';
		}

		$terms = get_the_terms( $post, $taxonomy );

		if ( ! is_array( $terms ) ) {
			return '';
		}

		if ( 'category' === $taxonomy ) {
			$fallback = (int) get_option( 'default_category' );
			$terms    = array_filter(
				$terms,
				static function ( $term ) use ( $fallback ) {
					return (int) $term->term_id !== $fallback;
				}
			);
		}

		return implode( ', ', wp_list_pluck( $terms, 'name' ) );
	}

	/**
	 * Categories and tags as hashtags.
	 *
	 * A hashtag in Telegram is one word: everything outside letters, digits and
	 * the underscore is dropped rather than replaced, because a "#web-design"
	 * ends at the hyphen and the rest is left as loose text.
	 *
	 * @since 1.1.0
	 * @param WP_Post $post Post being announced.
	 * @return string
	 */
	private static function hashtags( WP_Post $post ) {
		$names = array_merge(
			array_filter( explode( ', ', self::terms( $post ) ) ),
			array_filter( explode( ', ', self::terms( $post, 'post_tag' ) ) )
		);

		$tags = array();

		foreach ( $names as $name ) {
			$word = preg_replace( '/[^\p{L}\p{N}_]+/u', '_', trim( (string) $name ) );
			$word = trim( (string) $word, '_' );

			// A hashtag cannot start with a digit — Telegram does not link it.
			if ( '' === $word || preg_match( '/^\p{N}/u', $word ) ) {
				continue;
			}

			$tags[ '#' . $word ] = '#' . $word;
		}

		return implode( ' ', $tags );
	}
}
