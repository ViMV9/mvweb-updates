<?php
/**
 * Announcing new posts in Telegram channels.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Modules\Posts;

use MVweb\Telegram\Hub\Modules\ModuleInterface;
use MVweb\Telegram\Hub\Settings;
use MVweb\Telegram\Hub\Telegram\Formatter;
use WP_Post;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A new article goes to the channel.
 *
 * The first module in the plugin that has nothing to do with WooCommerce: the
 * recipient is a public channel rather than a person, so there is no binding,
 * no consent and no personal data — and equally no way to write anywhere the
 * bot has not been made an administrator.
 *
 * @since 1.1.0
 */
final class Module implements ModuleInterface {

	/**
	 * Post meta recording which channels already have this post.
	 *
	 * Keyed by chat id, holding the message id Telegram answered with. Two
	 * jobs in one: the key is the idempotency guard, and the value is what a
	 * later edit or removal would need — Telegram puts no time limit on
	 * editing a message of your own, so keeping it from the first day costs
	 * nothing and not keeping it closes the door for good.
	 *
	 * @var string
	 */
	public const SENT_META = '_mvweb_tg_channel_posts';

	/**
	 * Module slug.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function slug() {
		return 'posts';
	}

	/**
	 * Module name for the settings screen.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function label() {
		return __( 'New posts to a Telegram channel', 'mvweb-telegram-hub' );
	}

	/**
	 * Nothing beyond WordPress itself is needed.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function requirements_met() {
		return true;
	}

	/**
	 * Never shown, because the requirements are always met.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function requirement_message() {
		return '';
	}

	/**
	 * Hook the publication trigger and the delivery bookkeeping.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function register() {
		( new Trigger() )->register();
		( new Field() )->register();

		add_action( 'mvweb_tg_sent', array( $this, 'remember_message' ), 10, 3 );
	}

	/**
	 * Build the message for a post.
	 *
	 * Rendered at delivery rather than when the job was queued, so an edit to
	 * the template between publication and a retry is picked up, and the job
	 * arguments stay small enough for Action Scheduler.
	 *
	 * @since 1.1.0
	 * @param int $object_id Post id.
	 * @return string|null Null when the post is gone or no longer public.
	 */
	public function build_message( $object_id ) {
		$post = get_post( absint( $object_id ) );

		if ( ! $post instanceof WP_Post || 'publish' !== $post->post_status ) {
			self::release( absint( $object_id ) );

			return null;
		}

		$limit = 'photo' === Settings::post_photo_mode() && has_post_thumbnail( $post )
			? Formatter::CAPTION_LIMIT
			: Formatter::SAFE_LIMIT;

		$text = Macros::render( $post, Settings::post_template(), $limit );

		/**
		 * Filter the channel message before it is sent.
		 *
		 * @since 1.1.0
		 * @param string   $text Message in Telegram HTML.
		 * @param \WP_Post $post Post being announced.
		 */
		$text = (string) apply_filters( 'mvweb_tg_post_message', $text, $post );

		/*
		 * The macros were already fitted to the caption when a photo is
		 * expected. This is the backstop for a filter that added text, and the
		 * queue cuts a caption down again for a job whose picture changed while
		 * it waited.
		 */
		return Formatter::truncate( $text, Formatter::SAFE_LIMIT );
	}

	/**
	 * Give a channel back after a job that will never be delivered.
	 *
	 * A channel is claimed the moment its job is queued, so that a second
	 * publication inside the delay window cannot queue the same post twice.
	 * If the post is unpublished before the job runs, that claim would outlive
	 * the job: nothing is sent, nothing reaches the log, and publishing again
	 * would find the channel still taken. Claims that never turned into a
	 * message are dropped; the ones that did are left alone.
	 *
	 * @since 1.1.0
	 * @param int $post_id Post the job belonged to.
	 * @return void
	 */
	private static function release( $post_id ) {
		if ( ! $post_id ) {
			return;
		}

		$sent = self::already_sent( $post_id );
		$live = array_filter( $sent );

		if ( $live === $sent ) {
			return;
		}

		if ( array() === $live ) {
			delete_post_meta( $post_id, self::SENT_META );

			return;
		}

		update_post_meta( $post_id, self::SENT_META, $live );
	}

	/**
	 * Record the message id a channel gave back.
	 *
	 * @since 1.1.0
	 * @param array  $payload    Job payload that was delivered.
	 * @param string $chat_id    Channel that took it.
	 * @param int    $message_id Identifier Telegram answered with.
	 * @return void
	 */
	public function remember_message( $payload, $chat_id, $message_id ) {
		if ( ! is_array( $payload ) || self::slug() !== ( isset( $payload['module'] ) ? $payload['module'] : '' ) ) {
			return;
		}

		$post_id = isset( $payload['object_id'] ) ? absint( $payload['object_id'] ) : 0;
		$chat_id = (string) $chat_id;

		if ( ! $post_id || '' === $chat_id ) {
			return;
		}

		$sent = get_post_meta( $post_id, self::SENT_META, true );
		$sent = is_array( $sent ) ? $sent : array();

		$sent[ $chat_id ] = absint( $message_id );

		update_post_meta( $post_id, self::SENT_META, $sent );
	}

	/**
	 * Channels this post has already been announced in.
	 *
	 * @since 1.1.0
	 * @param int $post_id Post id.
	 * @return array<string, int> Chat id mapped to message id.
	 */
	public static function already_sent( $post_id ) {
		$sent = get_post_meta( absint( $post_id ), self::SENT_META, true );

		return is_array( $sent ) ? $sent : array();
	}
}
