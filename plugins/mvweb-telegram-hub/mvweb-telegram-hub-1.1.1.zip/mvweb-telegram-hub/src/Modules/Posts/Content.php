<?php
/**
 * Turns post content into something Telegram will accept.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Modules\Posts;

use MVweb\Telegram\Hub\Telegram\Formatter;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Web HTML in, Telegram HTML out.
 *
 * Telegram accepts a dozen tags and four named entities. Everything a theme,
 * the block editor and a page builder put into post content is outside that,
 * and a single stray tag or a bare "&mdash;" does not get ignored — the API
 * answers 400 and the whole post is lost. That failure, reported as "the text
 * arrives glued together" or "can't parse entities", is the single most common
 * complaint about every plugin in this category.
 *
 * The work is done token by token rather than with wp_kses alone, because the
 * two halves need opposite treatment: a tag is either kept verbatim or dropped,
 * while text has to be decoded to real characters first — otherwise a "&nbsp;"
 * from the editor survives as five literal characters Telegram cannot read —
 * and only then escaped again, for the three characters Telegram does want
 * escaped.
 *
 * @since 1.1.0
 */
final class Content {

	/**
	 * Elements whose contents go with them.
	 *
	 * Stripping only the tags would leave a stylesheet, a script body or an
	 * image caption sitting in the middle of the message as plain text.
	 *
	 * @var string[]
	 */
	private const DROP_WHOLE = array( 'script', 'style', 'noscript', 'figcaption', 'iframe', 'form', 'select', 'textarea' );

	/**
	 * Elements whose unclosed body is swallowed all the way to the end.
	 *
	 * Only these two. An unclosed script or stylesheet is machine code and
	 * everything after it is code as well; an unclosed form or figure is
	 * ordinary prose that must not disappear with it.
	 *
	 * @var string[]
	 */
	private const DROP_TO_END = array( 'script', 'style' );

	/**
	 * Structural replacements applied before anything is parsed.
	 *
	 * Telegram has no block layout at all: a paragraph, a heading and a list
	 * item are all just text, and the only thing that separates them is a line
	 * break. Headings become bold, because that is the whole of what Telegram
	 * can say about a heading.
	 *
	 * @var array<string, string>
	 */
	private const STRUCTURE = array(
		'#<h[1-6][^>]*>#i'             => "\n\n<b>",
		'#</h[1-6]>#i'                 => "</b>\n\n",
		'#</li>\s*#i'                  => '',
		'#\s*<li\b[^>]*>#i'            => "\n• ",
		'#<br\b[^>]*>#i'               => "\n",
		'#</(p|div|ul|ol|tr|table)>#i' => "\n\n",
		'#</(td|th)>#i'                => ' ',
		'#<hr\b[^>]*>#i'               => "\n\n",
	);

	/**
	 * Convert a piece of post content.
	 *
	 * @since 1.1.0
	 * @param string $html Content after the_content has run.
	 * @return string Telegram HTML.
	 */
	public static function convert( $html ) {
		// Every pattern below carries /u, and one broken byte makes PCRE answer
		// null for all of them — the post would become an empty message and be
		// dropped by the queue in silence.
		$html = (string) wp_check_invalid_utf8( (string) $html, true );
		$html = self::drop_whole( $html );

		foreach ( self::STRUCTURE as $pattern => $replacement ) {
			$html = (string) preg_replace( $pattern, $replacement, $html );
		}

		/*
		 * A "<" that opens nothing is text, and the splitter below would eat it
		 * together with everything up to the next ">". A post reading "5 < 7 and
		 * a > b" lost its middle; one starting "<3" lost everything.
		 */
		$html = (string) preg_replace( '#<(?![a-z!/])#i', '&lt;', $html );

		return self::tokenise( $html );
	}

	/**
	 * Remove elements together with everything inside them.
	 *
	 * @since 1.1.0
	 * @param string $html Raw content.
	 * @return string
	 */
	private static function drop_whole( $html ) {
		foreach ( self::DROP_WHOLE as $tag ) {
			$html = preg_replace( '#<' . $tag . '\\b[^>]*>.*?</' . $tag . '>#is', '', (string) $html );
		}

		// An unclosed script or style takes the rest with it, or its body would
		// stand in the middle of the message as plain text.
		foreach ( self::DROP_TO_END as $tag ) {
			$html = preg_replace( '#<' . $tag . '\\b[^>]*>.*$#is', '', (string) $html );
		}

		// Self-closing ones, and the leftovers of a pair that never matched.
		return (string) preg_replace( '#</?(' . implode( '|', self::DROP_WHOLE ) . ')\\b[^>]*/?>#i', '', (string) $html );
	}

	/**
	 * Walk tags and text separately and rebuild a valid message.
	 *
	 * @since 1.1.0
	 * @param string $html Content with the structure already flattened.
	 * @return string
	 */
	private static function tokenise( $html ) {
		$allowed = Formatter::allowed_tags();
		$tokens  = preg_split( '/(<[^>]*>)/u', $html, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		$out     = '';
		$stack   = array();

		foreach ( (array) $tokens as $token ) {
			// A tag both opens and closes. A fragment that only opens is the
			// tail of a truncated document, and it is text.
			$is_tag = '<' === substr( $token, 0, 1 ) && '>' === substr( $token, -1 );

			if ( ! $is_tag ) {
				$out .= self::text( $token, self::verbatim( $stack ) );
				continue;
			}

			// A closing tag is only written out when it closes something that is
			// actually open — Telegram rejects the message otherwise.
			if ( preg_match( '#^</\s*([a-z0-9]+)#i', $token, $m ) ) {
				$name = strtolower( $m[1] );

				if ( array() !== $stack && end( $stack ) === $name ) {
					array_pop( $stack );
					$out .= '</' . $name . '>';
				}

				continue;
			}

			if ( ! preg_match( '#^<\s*([a-z0-9]+)#i', $token, $m ) ) {
				continue;
			}

			$name = strtolower( $m[1] );

			if ( ! isset( $allowed[ $name ] ) || ! self::may_open( $stack, $name ) ) {
				continue;
			}

			if ( 'a' === $name ) {
				$href = self::href( $token );

				if ( '' === $href ) {
					continue;
				}

				$stack[] = $name;
				$out    .= '<a href="' . Formatter::escape( $href ) . '">';
				continue;
			}

			$stack[] = $name;
			$out    .= '<' . $name . '>';
		}

		// Close whatever the content left open.
		foreach ( array_reverse( $stack ) as $name ) {
			$out .= '</' . $name . '>';
		}

		return Formatter::tidy( $out );
	}

	/**
	 * Whether a tag may open where the walk currently is.
	 *
	 * Telegram has three nesting rules of its own, and breaking any of them
	 * costs the whole message: pre and code hold text and nothing else, a
	 * blockquote cannot sit inside a blockquote, and a link cannot sit inside a
	 * link. A theme or the block editor produces all three without trying.
	 *
	 * @since 1.1.0
	 * @param array  $stack Tags currently open.
	 * @param string $name  Tag about to open.
	 * @return bool
	 */
	private static function may_open( array $stack, $name ) {
		if ( in_array( 'code', $stack, true ) ) {
			return false;
		}

		// <pre><code> is the one pair Telegram documents for a code block.
		if ( in_array( 'pre', $stack, true ) ) {
			return 'code' === $name;
		}

		if ( in_array( $name, array( 'blockquote', 'a' ), true ) && in_array( $name, $stack, true ) ) {
			return false;
		}

		return true;
	}

	/**
	 * Whether the walk is inside an element that keeps its text as typed.
	 *
	 * @since 1.1.0
	 * @param array $stack Tags currently open.
	 * @return bool
	 */
	private static function verbatim( array $stack ) {
		return in_array( 'pre', $stack, true ) || in_array( 'code', $stack, true );
	}

	/**
	 * One run of text, ready for Telegram.
	 *
	 * Entities are decoded to real characters first — a "&nbsp;" left as it is
	 * would arrive as five literal characters — and only then are the three
	 * Telegram wants escaped escaped again.
	 *
	 * Runs of spaces are collapsed here rather than at the end, because by then
	 * there is no way to tell the indentation of a code block from the stray
	 * whitespace a theme leaves between tags.
	 *
	 * @since 1.1.0
	 * @param string $token    Raw text.
	 * @param bool   $verbatim Whether whitespace must be kept as it is.
	 * @return string
	 */
	private static function text( $token, $verbatim ) {
		$text = html_entity_decode( $token, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

		if ( ! $verbatim ) {
			$text = (string) preg_replace( '/[ \t]+/u', ' ', $text );
			$text = (string) preg_replace( '/ *\n */u', "\n", $text );
		}

		return Formatter::escape( $text );
	}

	/**
	 * The address of a link, if it is one Telegram will take.
	 *
	 * @since 1.1.0
	 * @param string $tag Opening anchor tag.
	 * @return string Empty when there is nothing usable.
	 */
	private static function href( $tag ) {
		// The boundary matters: without it "data-href" and a title containing
		// the word href both win over the real attribute.
		if ( ! preg_match( '#(?:^|\s)href\s*=\s*("([^"]*)"|\'([^\']*)\'|([^\s"\'>]+))#i', $tag, $m ) ) {
			return '';
		}

		$raw = '';

		foreach ( array( 2, 3, 4 ) as $group ) {
			if ( isset( $m[ $group ] ) && '' !== $m[ $group ] ) {
				$raw = $m[ $group ];
				break;
			}
		}

		$href = html_entity_decode( $raw, ENT_QUOTES | ENT_HTML5, 'UTF-8' );

		// A path relative to the site is a real destination and worth keeping,
		// but only Telegram's own schemes travel — it makes nothing absolute on
		// its own, and an anchor like "#fn1" points at a page nobody is on.
		if ( '' !== $href && '/' === $href[0] && '/' !== substr( $href, 1, 1 ) ) {
			$href = home_url( $href );
		}

		if ( ! preg_match( '#^(https?|tg)://#i', $href ) ) {
			return '';
		}

		return (string) esc_url_raw( $href, array( 'http', 'https', 'tg' ) );
	}
}
