<?php
/**
 * Decides when a post belongs in a channel.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Modules\Posts;

use MVweb\Telegram\Hub\Queue\Dispatcher;
use MVweb\Telegram\Hub\Settings;
use WP_Post;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One hook, and the guards that make it usable.
 *
 * The hook wp_after_insert_post is the only correct one here, and not by taste.
 * The REST controller behind the block editor calls wp_insert_post() with
 * $fire_after_hooks = false and then attaches the terms and the featured image
 * afterwards, in separate calls — so at publish_post, save_post and
 * transition_post_status a block-editor post has neither categories nor a
 * picture yet. wp_after_insert_post is documented as firing once the post, its
 * terms and its meta are all saved.
 *
 * What it does not do is filter anything out. Its only early return is for a
 * missing post, so it fires on revisions, on autosaves and on Quick Edit as
 * well. Every guard below earns its place: without them the channel gets a
 * copy of the article each time the author pauses typing.
 *
 * @since 1.1.0
 */
final class Trigger {

	/**
	 * Seconds between two channels of the same batch.
	 *
	 * Telegram accepts one message per second into one chat. Different chats
	 * are not the same chat, but a burst across several of them still counts
	 * towards the overall ceiling, and the cost of spacing them is nothing.
	 *
	 * @var int
	 */
	private const THROTTLE = 1;

	/**
	 * Seconds a REST publication waits for the block editor's meta boxes.
	 *
	 * The block editor publishes through REST and saves meta boxes in a second
	 * request afterwards. With the "Text for Telegram" field in use, a job run
	 * straight away could beat that request and announce the article instead
	 * of the text written for the channel.
	 *
	 * @var int
	 */
	private const META_BOX_WAIT = 30;

	/**
	 * Hook the publication.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function register() {
		add_action( 'wp_after_insert_post', array( $this, 'maybe_announce' ), 10, 4 );
	}

	/**
	 * Queue a post for every channel that has not had it yet.
	 *
	 * @since 1.1.0
	 * @param int          $post_id     Post id.
	 * @param WP_Post      $post        Post object.
	 * @param bool         $update      Whether this was an update.
	 * @param WP_Post|null $post_before Post as it was, on an update.
	 * @return void
	 */
	public function maybe_announce( $post_id, $post, $update, $post_before ) {
		unset( $update );

		if ( ! $post instanceof WP_Post || ! $this->is_announceable( $post ) ) {
			return;
		}

		/*
		 * A post that was already published and is being saved again is an
		 * edit, not a publication. This is also what keeps Quick Edit and the
		 * "update" button quiet, and it needs no meta of its own to do it.
		 */
		if ( $post_before instanceof WP_Post && 'publish' === $post_before->post_status ) {
			return;
		}

		$channels = Settings::channels();

		if ( ! Settings::has_token() || array() === $channels ) {
			return;
		}

		$sent   = Module::already_sent( $post_id );
		$photo  = $this->photo( $post );
		$button = Settings::post_button();
		$delay  = Settings::post_delay() * MINUTE_IN_SECONDS;

		if ( Settings::post_text_field() && wp_is_serving_rest_request() ) {
			$delay = max( $delay, self::META_BOX_WAIT );
		}

		$step = 0;

		foreach ( $channels as $chat_id ) {
			if ( isset( $sent[ $chat_id ] ) ) {
				continue;
			}

			$payload = array(
				'module'    => Module::slug(),
				'object_id' => (int) $post_id,
				'chat_id'   => (string) $chat_id,
				'attempt'   => 1,
			);

			if ( '' !== $photo ) {
				$key             = 'photo' === Settings::post_photo_mode() ? 'photo' : 'preview';
				$payload[ $key ] = $photo;
			}

			if ( '' !== $button ) {
				$payload['button'] = array(
					'text' => $button,
					'url'  => (string) get_permalink( $post ),
				);
			}

			if ( ! Dispatcher::schedule( $payload, $delay + ( $step * self::THROTTLE ) ) ) {
				continue;
			}

			/*
			 * Claimed the moment the job is queued, not when it is delivered.
			 * A delayed announcement lives longer than the request that made
			 * it, and until the job runs there is nothing else to stop a
			 * second publication from queueing the same post again.
			 */
			$sent[ $chat_id ] = 0;
			++$step;
		}

		if ( array() !== $sent ) {
			update_post_meta( $post_id, Module::SENT_META, $sent );
		}
	}

	/**
	 * Whether this post is one the operator asked to announce.
	 *
	 * @since 1.1.0
	 * @param WP_Post $post Post being saved.
	 * @return bool
	 */
	private function is_announceable( WP_Post $post ) {
		// The post type list never contains "revision", so this is also the
		// guard against revisions and autosaves. Both are checked by name as
		// well, because a site can register a type called anything at all.
		if ( ! in_array( $post->post_type, Settings::post_types(), true ) ) {
			return false;
		}

		if ( wp_is_post_revision( $post ) || wp_is_post_autosave( $post ) ) {
			return false;
		}

		// An importer inserts finished posts with post_status=publish and no
		// $post_before, so every guard above lets them through — and a hundred
		// archived articles land in the channel one after another.
		if ( ( defined( 'WP_IMPORTING' ) && WP_IMPORTING ) || wp_installing() ) {
			return false;
		}

		if ( 'publish' !== $post->post_status ) {
			return false;
		}

		// A post behind a password, or one the site keeps out of search, is not
		// something to push into a public channel.
		if ( '' !== (string) $post->post_password ) {
			return false;
		}

		if ( array() !== Settings::post_terms() && ! $this->in_chosen_terms( $post ) ) {
			return false;
		}

		/**
		 * Filter whether a post is announced in the channels.
		 *
		 * @since 1.1.0
		 * @param bool     $announce Whether to announce it.
		 * @param \WP_Post $post     Post being saved.
		 */
		return (bool) apply_filters( 'mvweb_tg_should_announce', true, $post );
	}

	/**
	 * Whether the post carries one of the chosen categories.
	 *
	 * @since 1.1.0
	 * @param WP_Post $post Post being saved.
	 * @return bool
	 */
	private function in_chosen_terms( WP_Post $post ) {
		if ( ! is_object_in_taxonomy( $post->post_type, 'category' ) ) {
			// A type with no categories cannot match a category filter, but
			// silently dropping it would be a filter for one type quietly
			// switching off another. It passes.
			return true;
		}

		$terms = get_the_terms( $post, 'category' );

		if ( ! is_array( $terms ) ) {
			return false;
		}

		return array() !== array_intersect(
			array_map( 'absint', wp_list_pluck( $terms, 'term_id' ) ),
			Settings::post_terms()
		);
	}

	/**
	 * Public address of the featured image, if there is one to send.
	 *
	 * The registered "large" size rather than the original: an original from a
	 * modern camera can be four thousand pixels on a side and fall foul of the
	 * limit Telegram puts on the sum of the two sides.
	 *
	 * @since 1.1.0
	 * @param WP_Post $post Post being announced.
	 * @return string Empty when there is no image or the operator asked for none.
	 */
	private function photo( WP_Post $post ) {
		if ( 'none' === Settings::post_photo_mode() ) {
			return '';
		}

		$thumbnail = get_post_thumbnail_id( $post );

		if ( ! $thumbnail ) {
			return '';
		}

		return (string) wp_get_attachment_image_url( $thumbnail, 'large' );
	}
}
