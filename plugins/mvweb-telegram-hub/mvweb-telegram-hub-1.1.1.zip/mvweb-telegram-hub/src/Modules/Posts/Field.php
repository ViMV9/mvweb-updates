<?php
/**
 * The "Text for Telegram" field in the post editor.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Modules\Posts;

use MVweb\Telegram\Hub\Settings;
use WP_Post;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A text written for the channel, separate from the article.
 *
 * A meta box with the classic WordPress editor, so the author gets the same
 * Visual and Code tabs as for the post itself. The toolbar keeps only what
 * survives the trip: the editor's underline is a styled span, which
 * Telegram drops, so that button is left out. It appears only when the
 * operator switched the option on, and only on the post types that are
 * announced at all.
 *
 * The block editor saves meta boxes in a second request, after the post
 * itself has gone through REST and wp_after_insert_post has already fired.
 * The trigger therefore waits a little longer for REST publications while
 * this option is on, and the message is built at delivery, by which time the
 * field is in the database.
 *
 * @since 1.1.0
 */
final class Field {

	/**
	 * Post meta holding the text.
	 *
	 * @var string
	 */
	public const META = '_mvweb_tg_post_text';

	/**
	 * Field name in the edit form.
	 *
	 * @var string
	 */
	private const INPUT = 'mvweb_tg_post_text';

	/**
	 * Nonce action and field name.
	 *
	 * @var string
	 */
	private const NONCE = 'mvweb_tg_post_text_nonce';

	/**
	 * Hook the meta box and its saving.
	 *
	 * The key is protected (it starts with an underscore) and deliberately not
	 * registered: the box below is the only way to write it, so the REST API,
	 * XML-RPC and the custom fields panel all leave it alone.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function register() {
		if ( ! Settings::post_text_field() ) {
			return;
		}

		add_action( 'add_meta_boxes', array( $this, 'add_box' ) );
		add_action( 'save_post', array( $this, 'save' ), 10, 2 );
	}

	/**
	 * Add the box to every announced post type.
	 *
	 * @since 1.1.0
	 * @param string $post_type Post type of the screen.
	 * @return void
	 */
	public function add_box( $post_type ) {
		if ( ! in_array( $post_type, Settings::post_types(), true ) ) {
			return;
		}

		add_meta_box(
			'mvweb-tg-post-text',
			__( 'Text for Telegram', 'mvweb-telegram-hub' ),
			array( $this, 'render' ),
			$post_type,
			'normal',
			'default'
		);
	}

	/**
	 * Print the editor.
	 *
	 * @since 1.1.0
	 * @param WP_Post $post Post being edited.
	 * @return void
	 */
	public function render( $post ) {
		wp_nonce_field( self::NONCE, self::NONCE );

		echo '<p class="description">' . esc_html__( 'Goes to the Telegram channel instead of the article text. Bold, italics, lists, quotes and links are kept; anything else is dropped, because Telegram does not show it. Leave it empty to announce the article as usual.', 'mvweb-telegram-hub' ) . '</p>';

		wp_editor(
			(string) get_post_meta( $post->ID, self::META, true ),
			'mvwebtgposttext',
			array(
				'textarea_name' => self::INPUT,
				'textarea_rows' => 8,
				'media_buttons' => false,
				'tinymce'       => array(
					'toolbar1' => 'bold,italic,strikethrough,blockquote,bullist,numlist,link,unlink,removeformat,undo,redo',
					'toolbar2' => '',
				),
				'quicktags'     => array(
					'buttons' => 'strong,em,del,link,ul,ol,li,code,block,close',
				),
			)
		);
	}

	/**
	 * Store the text with the post.
	 *
	 * The core's update_post_meta() unslashes what it is given, so the value,
	 * already unslashed to be cleaned, is slashed back first: otherwise every
	 * literal backslash in the text would be lost.
	 *
	 * @since 1.1.0
	 * @param int     $post_id Post id.
	 * @param WP_Post $post    Post object.
	 * @return void
	 */
	public function save( $post_id, $post ) {
		if ( ! isset( $_POST[ self::NONCE ] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST[ self::NONCE ] ) ), self::NONCE ) ) {
			return;
		}

		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! $post instanceof WP_Post || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$text = isset( $_POST[ self::INPUT ] ) ? wp_kses_post( wp_unslash( $_POST[ self::INPUT ] ) ) : '';

		if ( '' === trim( wp_strip_all_tags( $text ) ) ) {
			delete_post_meta( $post_id, self::META );
			return;
		}

		update_post_meta( $post_id, self::META, wp_slash( $text ) );
	}

	/**
	 * The field's text for a post, in Telegram HTML.
	 *
	 * The classic editor stores paragraphs as blank lines and leaves them to
	 * wpautop() at display time, so the text gets the same treatment here
	 * before it is converted.
	 *
	 * @since 1.1.0
	 * @param WP_Post $post Post being announced.
	 * @return string Empty when the option is off or the field is.
	 */
	public static function text( WP_Post $post ) {
		if ( ! Settings::post_text_field() ) {
			return '';
		}

		$raw = (string) get_post_meta( $post->ID, self::META, true );

		if ( '' === trim( wp_strip_all_tags( $raw ) ) ) {
			return '';
		}

		return Content::convert( wpautop( $raw ) );
	}
}
