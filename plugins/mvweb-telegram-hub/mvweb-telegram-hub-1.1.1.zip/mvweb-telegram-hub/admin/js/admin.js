/**
 * Admin JavaScript for MVweb Telegram Hub.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		initTabs();
		initMacroInsert();
		initTemplateReset();
		initConfirm();
		initSelectOnFocus();
	});

	/**
	 * Select a read-only address the moment it is focused.
	 *
	 * These fields exist to be copied somewhere else — into BotFather, into a
	 * security plugin's allow-list — and selecting the whole of a long URL by
	 * hand is the fiddliest part of setting the plugin up.
	 */
	function initSelectOnFocus() {
		document.querySelectorAll('.mvweb-tg-selectable').forEach(function (field) {
			field.addEventListener('focus', function () {
				field.select();
			});
		});
	}

	/**
	 * Ask before an action that cannot be taken back.
	 *
	 * Deleting the token or emptying the log is a server action behind a
	 * redirect — there is no undo once the form is posted.
	 */
	function initConfirm() {
		document.querySelectorAll('.mvweb-tg-confirm').forEach(function (button) {
			button.addEventListener('click', function (event) {
				var question = button.getAttribute('data-confirm') || '';

				if (question && !window.confirm(question)) {
					event.preventDefault();
				}
			});
		});
	}

	/**
	 * Drop the standard template into the field.
	 *
	 * Done in the browser rather than through a server action: nothing is
	 * stored until the operator presses Save, so a misclick costs one Ctrl+Z
	 * instead of the template they had written.
	 */
	function initTemplateReset() {
		var button = document.getElementById('mvweb-tg-template-reset');
		var field = document.getElementById('mvweb-tg-template');

		if (!button || !field) {
			return;
		}

		button.addEventListener('click', function () {
			var template = button.getAttribute('data-template') || '';
			var confirmText = button.getAttribute('data-confirm') || '';

			if (field.value.trim() && confirmText && !window.confirm(confirmText)) {
				return;
			}

			field.value = template;
			field.focus();
		});
	}

	/**
	 * Put a macro into the template at the cursor position.
	 *
	 * Typing {customer_phone} by hand is where the typos come from, and a typo
	 * silently ships a message with a literal macro inside it.
	 */
	function initMacroInsert() {
		// Each glossary names the field it belongs to: there is one per
		// template, and a hardcoded id would make every button on the screen
		// type into whichever field happened to be first.
		document.querySelectorAll('.mvweb-tg-macros[data-target]').forEach(function (list) {
			var field = document.getElementById(list.getAttribute('data-target'));

			if (!field) {
				return;
			}

			list.querySelectorAll('.mvweb-tg-macros__insert').forEach(function (button) {
				button.addEventListener('click', function () {
					var macro = button.getAttribute('data-macro') || '';
					var start = field.selectionStart;
					var end = field.selectionEnd;

					field.value = field.value.slice(0, start) + macro + field.value.slice(end);
					field.focus();
					field.selectionStart = start + macro.length;
					field.selectionEnd = field.selectionStart;
				});
			});
		});
	}

	/**
	 * Switch between the sidebar tabs without reloading the page.
	 *
	 * The server already marks the active tab, so this only handles clicks.
	 * The URL is kept in sync so a reload — or a redirect back from an
	 * admin-post action — lands on the same tab.
	 */
	function initTabs() {
		var links = document.querySelectorAll('.mvweb-nav__link[data-tab]');
		var panels = document.querySelectorAll('.mvweb-tab-content');

		if (!links.length || !panels.length) {
			return;
		}

		links.forEach(function (link) {
			link.addEventListener('click', function (event) {
				event.preventDefault();

				var target = link.getAttribute('data-tab');
				var panel = document.getElementById(target);

				if (!panel) {
					return;
				}

				links.forEach(function (item) {
					item.classList.remove('mvweb-nav__link--active');
					item.removeAttribute('aria-current');
				});
				panels.forEach(function (item) {
					item.classList.remove('active');
				});

				link.classList.add('mvweb-nav__link--active');
				link.setAttribute('aria-current', 'page');
				panel.classList.add('active');

				if (window.history && window.history.replaceState) {
					var url = new URL(window.location.href);
					url.searchParams.set('tab', target);
					window.history.replaceState({}, '', url.toString());
				}
			});
		});
	}
})();
