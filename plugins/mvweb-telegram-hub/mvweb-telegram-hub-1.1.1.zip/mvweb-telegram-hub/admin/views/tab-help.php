<?php
/**
 * Help tab: how to set the plugin up and what to check when it goes quiet.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

use MVweb\Telegram\Hub\Admin\Page;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tg_shop = class_exists( 'WooCommerce' );
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-telegram-hub' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Four steps, about five minutes. No programming needed — everything happens inside Telegram and on these tabs.', 'mvweb-telegram-hub' ); ?>
	</p>

	<ol class="mvweb-steps">
		<li>
			<div>
				<strong><?php esc_html_e( 'Create a bot in Telegram', 'mvweb-telegram-hub' ); ?></strong>
				<p>
					<?php
					printf(
						/* translators: 1: BotFather link, 2: the /newbot command. */
						esc_html__( 'Open %1$s, send %2$s and answer two questions: the bot name and its username. In reply BotFather sends a long line like 1234567890:AAH… — that is the token.', 'mvweb-telegram-hub' ),
						'<a href="https://t.me/BotFather" target="_blank" rel="noopener">@BotFather</a>',
						'<code>/newbot</code>'
					);
					?>
				</p>
			</div>
		</li>
		<li>
			<div>
				<strong><?php esc_html_e( 'Paste the token', 'mvweb-telegram-hub' ); ?></strong>
				<p>
					<?php
					printf(
						/* translators: %s: link to the Bot tab. */
						esc_html__( 'Copy the whole line into the “Bot token” field on the %s tab and save. If Telegram accepts it, the bot username appears next to the field.', 'mvweb-telegram-hub' ),
						'<a href="' . esc_url( Page::tab_url( 'bot' ) ) . '">' . esc_html__( 'Bot', 'mvweb-telegram-hub' ) . '</a>'
					);
					?>
				</p>
			</div>
		</li>
		<?php if ( $mvweb_tg_shop ) : ?>
		<li>
			<div>
				<strong><?php esc_html_e( 'Say who gets the notifications', 'mvweb-telegram-hub' ); ?></strong>
				<p>
					<?php
					printf(
						/* translators: 1: userinfobot link, 2: link to the orders tab. */
						esc_html__( 'A bot cannot write first, so every person has to open the bot and press “Start”. Then get their number from %1$s and put it on the %2$s tab, one per line.', 'mvweb-telegram-hub' ),
						'<a href="https://t.me/userinfobot" target="_blank" rel="noopener">@userinfobot</a>',
						'<a href="' . esc_url( Page::tab_url( 'orders' ) ) . '">' . esc_html__( 'WooCommerce orders', 'mvweb-telegram-hub' ) . '</a>'
					);
					?>
				</p>
			</div>
		</li>
		<li>
			<div>
				<strong><?php esc_html_e( 'Check it before the first order', 'mvweb-telegram-hub' ); ?></strong>
				<p><?php esc_html_e( 'Press “Check recipients” and then “Send a test message”. Both report on every recipient separately, so a typo in one number shows up straight away.', 'mvweb-telegram-hub' ); ?></p>
			</div>
		</li>
		<?php else : ?>
		<li>
			<div>
				<strong><?php esc_html_e( 'Add the channel', 'mvweb-telegram-hub' ); ?></strong>
				<p>
					<?php
					printf(
						/* translators: %s: link to the Channels tab. */
						esc_html__( 'Make the bot an administrator of the channel with the right to post messages, then put the channel on the %s tab.', 'mvweb-telegram-hub' ),
						'<a href="' . esc_url( Page::tab_url( 'channels' ) ) . '">' . esc_html__( 'Channels', 'mvweb-telegram-hub' ) . '</a>'
					);
					?>
				</p>
			</div>
		</li>
		<li>
			<div>
				<strong><?php esc_html_e( 'Switch posting on and publish a post', 'mvweb-telegram-hub' ); ?></strong>
				<p><?php esc_html_e( 'Turn on “New posts to a Telegram channel” on the Bot tab and publish a post. It appears in the channel within a minute; if not, the reason is on the Log tab.', 'mvweb-telegram-hub' ); ?></p>
			</div>
		</li>
		<?php endif; ?>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Where do I get the chat number?', 'mvweb-telegram-hub' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Every person, group and channel in Telegram has a number of its own — elsewhere on the internet it is called a chat ID. Which one you need depends on where the notifications should land.', 'mvweb-telegram-hub' ); ?>
	</p>

	<div class="mvweb-table-wrap mvweb-tg-scroll">
		<table class="mvweb-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Notifications go to', 'mvweb-telegram-hub' ); ?></th>
					<th><?php esc_html_e( 'What to do', 'mvweb-telegram-hub' ); ?></th>
					<th><?php esc_html_e( 'What it looks like', 'mvweb-telegram-hub' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><?php esc_html_e( 'One person', 'mvweb-telegram-hub' ); ?></td>
					<td>
						<?php
						printf(
							/* translators: %s: userinfobot link. */
							esc_html__( 'They open your bot, press “Start”, then write to %s — it answers with their number.', 'mvweb-telegram-hub' ),
							'<a href="https://t.me/userinfobot" target="_blank" rel="noopener">@userinfobot</a>'
						);
						?>
					</td>
					<td><code>123456789</code></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'A group of managers', 'mvweb-telegram-hub' ); ?></td>
					<td><?php esc_html_e( 'Add your bot to the group, then add @userinfobot too — it prints the group number and can be removed afterwards.', 'mvweb-telegram-hub' ); ?></td>
					<td><code>-1001234567890</code></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'A channel', 'mvweb-telegram-hub' ); ?></td>
					<td><?php esc_html_e( 'Add the bot as an administrator with the right to post messages. A public channel can be addressed by its handle instead of a number.', 'mvweb-telegram-hub' ); ?></td>
					<td><code>@myshoporders</code></td>
				</tr>
			</tbody>
		</table>
	</div>

	<p class="mvweb-form-row__desc">
		<?php esc_html_e( 'Keep the minus sign in group and channel numbers — without it the number points at a different chat and nothing arrives.', 'mvweb-telegram-hub' ); ?>
	</p>
</div>

<?php if ( $mvweb_tg_shop ) : ?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'How notifications work', 'mvweb-telegram-hub' ); ?></div>
	</div>

	<p><?php esc_html_e( 'An order placed at checkout — classic or block — is queued straight away and delivered in the background. The customer never waits for Telegram, so a slow or blocked connection cannot hold up the checkout page.', 'mvweb-telegram-hub' ); ?></p>
	<p><?php esc_html_e( 'Each recipient gets its own job. If one fails, the others are unaffected. Network errors, rate limits and server errors are retried after 1, 5 and 15 minutes; a wrong number or a blocked bot is not retried, because that never fixes itself.', 'mvweb-telegram-hub' ); ?></p>
	<p><?php esc_html_e( 'Only orders that customers place themselves are announced. An order you create by hand in the admin, or one brought in by an import or another plugin, stays quiet.', 'mvweb-telegram-hub' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Letting customers get their own updates', 'mvweb-telegram-hub' ); ?></div>
	</div>

	<p><?php esc_html_e( 'This is a separate module, switched off to begin with. Turn on “Order status for the customer” on the Bot tab, press “Accept commands” just below it, and tick the statuses to report on the WooCommerce orders tab.', 'mvweb-telegram-hub' ); ?></p>
	<p><?php esc_html_e( 'From then on a signed-in customer finds a “Telegram” section in their account, and the account dashboard points to it. They press “Connect Telegram”, press start in the bot, and updates on all their orders, later ones included, arrive in Telegram. In the same section they untick the statuses they do not want; they can only narrow the list you ticked, never add to it. A guest gets the button on their order page and connects that one order — there is no account to attach anything to.', 'mvweb-telegram-hub' ); ?></p>
	<p><?php esc_html_e( 'Three things have to be true of the site: it answers over https on port 443, 80, 88 or 8443; its REST API is not closed to guests, or at least the mvweb-telegram-hub namespace is allowed through; and the bot serves this site only. A bot already pointed at another address will not be taken over — Telegram gives its events to one place at a time.', 'mvweb-telegram-hub' ); ?></p>
	<p><?php esc_html_e( 'Whoever is connected can leave at any moment. The “Disconnect” button in the “Telegram” section releases the account, the one on a guest order page releases that order; the /stop command or blocking the bot releases everything they are connected to.', 'mvweb-telegram-hub' ); ?></p>
</div>

<?php endif; ?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Sending new posts to a channel', 'mvweb-telegram-hub' ); ?></div>
	</div>

	<p><?php esc_html_e( 'A third module, also off to begin with. Turn on “New posts to a Telegram channel” on the Bot tab, then open the Channels tab and add the channel there.', 'mvweb-telegram-hub' ); ?></p>
	<p><?php esc_html_e( 'The bot has to be an administrator of the channel with the right to post messages. Without that right Telegram refuses every message, and the refusal is written to the Log tab rather than swallowed.', 'mvweb-telegram-hub' ); ?></p>
	<p><?php esc_html_e( 'Only a first publication goes out. Editing an article that is already in the channel changes nothing there, and neither do autosaves, revisions or quick edits. A post can be delayed by a set number of minutes, which is the cheapest way to catch a typo before the readers do.', 'mvweb-telegram-hub' ); ?></p>
	<p><?php esc_html_e( 'The article is converted to the handful of tags Telegram understands: headings become bold, lists become bullets, everything else is unwrapped. Telegram allows 4096 characters, and a longer post is cut with the tags closed properly instead of being rejected whole.', 'mvweb-telegram-hub' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Signing in with Telegram', 'mvweb-telegram-hub' ); ?></div>
	</div>

	<p><?php esc_html_e( 'Also a separate feature with its own tab, and also off to begin with. It is for customers and readers on the storefront: a “Sign in with Telegram” button on the WooCommerce account and checkout forms and wherever you place the shortcode [mvweb_tg_login]. The WordPress login page is left alone, and the password form keeps working.', 'mvweb-telegram-hub' ); ?></p>
	<p><?php esc_html_e( 'It needs its own pair of credentials from BotFather — a client ID and a client secret, which are not the bot token. In the BotFather mini app switch the bot to OpenID Connect, add the address printed on the Sign-in tab as a redirect address, and paste both on the Sign-in tab. The site must answer over https.', 'mvweb-telegram-hub' ); ?></p>
	<p><?php esc_html_e( 'Switch the bot that already sends order updates, not a new one. Then a customer who joins through Telegram gets order updates there straight away, without pressing "Connect Telegram". A new visitor gets an account at once, with no email address of its own: the address given at checkout stays with the order. An account without an address cannot be found by the personal data export and erase tools; to remove its data, delete the account.', 'mvweb-telegram-hub' ); ?></p>
	<p><?php esc_html_e( 'Someone who already has an account here connects Telegram to it in the “Telegram” section of their account, while signed in. That order matters: it is the only way that cannot be turned into a way of taking over somebody else’s account.', 'mvweb-telegram-hub' ); ?></p>
	<p><?php esc_html_e( 'Only the roles ticked on the Sign-in tab can use it — Subscriber and Customer to begin with. Roles that edit content or run the site are never offered: this way in does not pass through the password form, so it does not pass through a two-factor plugin either.', 'mvweb-telegram-hub' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-telegram-hub' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The post did not reach the channel.', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Open the Log tab — a refusal from Telegram is always written there with the reason. The usual one is that the bot is in the channel but not an administrator, or is an administrator without the right to post.', 'mvweb-telegram-hub' ); ?></p>
			<p><?php esc_html_e( 'If the log is empty, the post never got as far as being queued: check that the module is on, that the post type and category are among the chosen ones, and that this was a first publication rather than an edit.', 'mvweb-telegram-hub' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The article went out without its picture.', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Telegram fetches the picture by its address, from its own servers. If the site is behind a password, on a local machine or otherwise closed to the outside, there is nothing for it to fetch. The text still goes out.', 'mvweb-telegram-hub' ); ?></p>
			<p><?php esc_html_e( 'The other case is a post with no featured image — there is nothing to send, and that is not an error.', 'mvweb-telegram-hub' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can I edit a post in the channel after publishing?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'Not yet, but the plugin already stores the identifier of every message it sends, which is what editing needs. Telegram puts no time limit on editing a message of your own, so nothing is lost while that is being built.', 'mvweb-telegram-hub' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The Telegram sign-in button does not appear.', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'It is drawn only once the visitor’s own browser has reached Telegram — that is deliberate, so nobody is shown a button that leads nowhere. Open the account page from a network where Telegram works and it appears.', 'mvweb-telegram-hub' ); ?></p>
			<p><?php esc_html_e( 'If it does not appear anywhere, check the Sign-in tab: the feature has to be switched on, the client ID and secret have to be saved, and the site has to answer over https.', 'mvweb-telegram-hub' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can an administrator sign in with Telegram?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'No. Signing in this way skips the password form, and therefore skips whatever second factor the site uses; it also swaps the password for a phone number, since a cloud password in Telegram is optional. That is fine for a customer and not for the people who run the site.', 'mvweb-telegram-hub' ); ?></p>
			<p><?php esc_html_e( 'The rule goes by what an account can do, not by the name of its role — anything able to manage options, edit users, install plugins or write posts counts.', 'mvweb-telegram-hub' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Somebody already has an account here. Will Telegram find it?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Not on its own, and that is the safe answer rather than a missing feature. Matching an incoming sign-in to an existing account by email address is how several well-known plugins let anyone log in as anyone whose address they knew.', 'mvweb-telegram-hub' ); ?></p>
			<p><?php esc_html_e( 'The person signs in with their password once and connects Telegram in the “Telegram” section of their account. From then on the button knows them.', 'mvweb-telegram-hub' ); ?></p>
		</div>
	</details>

	<?php if ( $mvweb_tg_shop ) : ?>
	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Nothing arrives. Where do I look?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Send a test message first — it answers per recipient and names the exact problem.', 'mvweb-telegram-hub' ); ?></p>
			<p><?php esc_html_e( 'If the test arrives but orders do not, check three things: the WooCommerce orders module is on, the order was placed at checkout rather than created in the admin, and the Log tab — it lists every failed delivery with advice on what to fix.', 'mvweb-telegram-hub' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The message arrived a minute late. Is that normal?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'Yes. Delivery runs in the background so the customer is never kept waiting at checkout. On a quiet site the background queue starts on the next visit to the site, which can take a moment.', 'mvweb-telegram-hub' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can several people get the notifications?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'Yes — put every number on its own line. Each recipient is delivered separately, so one blocked bot does not stop the others. For a team it is usually simpler to create one group and add the bot to it.', 'mvweb-telegram-hub' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'A customer phone number should not be in the group chat.', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'The message contains exactly what the template says. Delete the {customer_phone} macro from it and the phone number is never sent. You stay responsible for what personal data leaves the site.', 'mvweb-telegram-hub' ); ?>
		</div>
	</details>

	<?php endif; ?>
	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The host cannot reach Telegram. Anything I can do?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'Put your own https proxy into the “Custom API address” field on the Bot tab and the plugin will use it instead of api.telegram.org. Leave the field empty unless the hosting really blocks Telegram — an empty field is the normal setup.', 'mvweb-telegram-hub' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can I keep the token out of the database?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'Yes. Define MVWEB_TG_BOT_TOKEN in wp-config.php and it wins over the stored value; the field on the Bot tab then becomes read-only.', 'mvweb-telegram-hub' ); ?>
		</div>
	</details>

	<?php if ( $mvweb_tg_shop ) : ?>
	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'A customer says the connect button does nothing.', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Look at “Commands from Telegram” on the Bot tab. If it is off, the button opens the bot but the site never hears the start, so nothing is connected. If it is on and the line underneath reports a delivery error, Telegram cannot reach the site — usually a security plugin blocking the REST API for guests, or an address that is not https.', 'mvweb-telegram-hub' ); ?></p>
			<p><?php esc_html_e( 'The button is also hidden on an order with no email address on it, such as one typed in by hand from a phone call. Without an address there is no way to warn the customer that a Telegram account was attached to their order.', 'mvweb-telegram-hub' ); ?></p>
		</div>
	</details>

	<?php endif; ?>
	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can I use the same bot on two sites?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'For notifications to your own staff, yes — that direction only sends. For customer notifications, no: a bot delivers what people write to it to one address, and a second site registering itself would silently take the first one\'s updates. The plugin refuses to do that and asks for a separate bot. Making one takes a minute.', 'mvweb-telegram-hub' ); ?></p>
			<p><?php esc_html_e( 'Changing the bot later means every customer has to connect again: a chat number belongs to one bot and means nothing to another.', 'mvweb-telegram-hub' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'What happens to my settings if I delete the plugin?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'They stay, so reinstalling does not cost you the token and the template. Data is removed only when “Delete data on uninstall” is switched on before you delete the plugin.', 'mvweb-telegram-hub' ); ?>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-telegram-hub' ); ?></div>
	</div>

	<p>
		<?php
		printf(
			/* translators: %s: link to the studio website. */
			esc_html__( 'Plugin by MVweb — %s', 'mvweb-telegram-hub' ),
			'<a href="https://mvweb.ru" target="_blank" rel="noopener">mvweb.ru</a>'
		);
		?>
	</p>
	<p>
		<?php
		printf(
			/* translators: %s: plugin version. */
			esc_html__( 'Version %s', 'mvweb-telegram-hub' ),
			esc_html( MVWEB_TG_VERSION )
		);
		?>
	</p>
</div>
