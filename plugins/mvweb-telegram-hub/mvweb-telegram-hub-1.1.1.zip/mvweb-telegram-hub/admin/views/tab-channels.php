<?php
/**
 * Channels tab: where new posts go and what they look like.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

use MVweb\Telegram\Hub\Admin\Page;
use MVweb\Telegram\Hub\Modules\Posts\Macros;
use MVweb\Telegram\Hub\Modules\Posts\Module;
use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tg_option    = Settings::OPTION;
$mvweb_tg_on        = Settings::module_enabled( Module::slug() );
$mvweb_tg_has_token = Settings::has_token();
$mvweb_tg_channels  = implode( "\n", Settings::channels() );
$mvweb_tg_types     = Settings::post_types();
$mvweb_tg_terms     = Settings::post_terms();
$mvweb_tg_template  = Settings::post_template();
$mvweb_tg_delay     = Settings::post_delay();
$mvweb_tg_photo     = Settings::post_photo_mode();
$mvweb_tg_teaser    = Settings::post_excerpt_length();
$mvweb_tg_button    = Settings::post_button();
$mvweb_tg_own_text  = Settings::post_text_field();

$mvweb_tg_all_types = get_post_types(
	array( 'public' => true ),
	'objects'
);
unset( $mvweb_tg_all_types['attachment'] );

$mvweb_tg_categories = get_categories(
	array(
		'hide_empty' => false,
		'number'     => 200,
		'orderby'    => 'name',
	)
);
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'New posts to a channel', 'mvweb-telegram-hub' ); ?></div>
		<span class="mvweb-badge <?php echo $mvweb_tg_on ? 'mvweb-badge--success' : 'mvweb-badge--plain'; ?>">
			<?php echo $mvweb_tg_on ? esc_html__( 'On', 'mvweb-telegram-hub' ) : esc_html__( 'Off', 'mvweb-telegram-hub' ); ?>
		</span>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'A post published on the site goes out to your Telegram channels. Nothing else does: an edit to an article that is already out stays on the site, and so do drafts, revisions and quick edits.', 'mvweb-telegram-hub' ); ?>
	</p>

	<?php if ( ! $mvweb_tg_on ) : ?>
		<div class="mvweb-alert mvweb-alert--info">
			<div class="mvweb-alert__body">
				<?php
				printf(
					/* translators: %s: link to the Bot tab. */
					esc_html__( 'The module is switched off. Turn on “New posts to a Telegram channel” under Modules on the %s tab.', 'mvweb-telegram-hub' ),
					'<a href="' . esc_url( Page::tab_url( 'bot' ) ) . '">' . esc_html__( 'Bot', 'mvweb-telegram-hub' ) . '</a>'
				);
				?>
			</div>
		</div>
	<?php elseif ( ! $mvweb_tg_has_token ) : ?>
		<div class="mvweb-alert mvweb-alert--warning">
			<div class="mvweb-alert__body">
				<?php esc_html_e( 'No bot token is saved, so nothing can be sent anywhere yet.', 'mvweb-telegram-hub' ); ?>
			</div>
		</div>
	<?php endif; ?>
</div>

<form id="mvweb-tg-form-channels" method="post" action="options.php">
	<?php settings_fields( Page::GROUP ); ?>
	<?php Page::referer_field( 'channels' ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Channels', 'mvweb-telegram-hub' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'One per line. A separate list from the order recipients on purpose — the team chat that hears about orders is not where the articles belong.', 'mvweb-telegram-hub' ); ?>
		</p>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-channels" class="mvweb-form-row__label">
				<?php esc_html_e( 'Where to post', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'A public channel can be addressed by its handle, @mychannel. A private one has only a number, which starts with a minus — press “Find my chats” below to read it. The bot has to be an administrator of the channel with the right to post messages.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-tg-channels"
					name="<?php echo esc_attr( $mvweb_tg_option ); ?>[channels]"
					class="mvweb-textarea"
					rows="4"
					spellcheck="false"
					placeholder="@mychannel&#10;-1001234567890"><?php echo esc_textarea( $mvweb_tg_channels ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Add the bot to the channel as an administrator and allow it to post messages. Without that right Telegram refuses every message, and the reason lands on the Log tab.', 'mvweb-telegram-hub' ); ?>
				</p>
				<p class="mvweb-tg-discover">
					<a class="mvweb-btn" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mvweb_tg_discover&tab=channels' ), 'mvweb_tg_discover' ) ); ?>">
						<?php esc_html_e( 'Find my chats', 'mvweb-telegram-hub' ); ?>
					</a>
					<span>
						<?php esc_html_e( 'Asks Telegram which chats the bot has taken part in and shows their numbers — the only way to learn the number of a private channel, which has no name to address it by. Unsaved changes on this page will be lost.', 'mvweb-telegram-hub' ); ?>
					</span>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'What gets posted', 'mvweb-telegram-hub' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label" id="mvweb-tg-post-types-label"><?php esc_html_e( 'Post types', 'mvweb-telegram-hub' ); ?></span>
			<div class="mvweb-form-row__field" role="group" aria-labelledby="mvweb-tg-post-types-label">
				<input type="hidden" name="<?php echo esc_attr( $mvweb_tg_option ); ?>[post_types][]" value="">
				<?php foreach ( $mvweb_tg_all_types as $mvweb_tg_type ) : ?>
					<label class="mvweb-check mvweb-tg-check">
						<input type="checkbox"
							name="<?php echo esc_attr( $mvweb_tg_option ); ?>[post_types][]"
							value="<?php echo esc_attr( $mvweb_tg_type->name ); ?>"
							<?php checked( in_array( $mvweb_tg_type->name, $mvweb_tg_types, true ) ); ?>>
						<span><?php echo esc_html( $mvweb_tg_type->labels->name ); ?></span>
					</label>
				<?php endforeach; ?>
			</div>
		</div>

		<?php if ( $mvweb_tg_categories ) : ?>
			<div class="mvweb-form-row">
				<span class="mvweb-form-row__label" id="mvweb-tg-post-terms-label">
					<?php esc_html_e( 'Categories', 'mvweb-telegram-hub' ); ?>
					<?php Page::help_tip( __( 'Leave every box empty to post everything. Ticking some means only posts in those categories go out. Post types that have no categories are unaffected either way.', 'mvweb-telegram-hub' ) ); ?>
				</span>
				<div class="mvweb-form-row__field" role="group" aria-labelledby="mvweb-tg-post-terms-label">
					<input type="hidden" name="<?php echo esc_attr( $mvweb_tg_option ); ?>[post_terms][]" value="">
					<div class="mvweb-tg-checklist">
						<?php foreach ( $mvweb_tg_categories as $mvweb_tg_cat ) : ?>
							<label class="mvweb-check mvweb-tg-check">
								<input type="checkbox"
									name="<?php echo esc_attr( $mvweb_tg_option ); ?>[post_terms][]"
									value="<?php echo esc_attr( (string) $mvweb_tg_cat->term_id ); ?>"
									<?php checked( in_array( (int) $mvweb_tg_cat->term_id, $mvweb_tg_terms, true ) ); ?>>
								<span><?php echo esc_html( $mvweb_tg_cat->name ); ?></span>
							</label>
						<?php endforeach; ?>
					</div>
					<p class="mvweb-form-row__desc">
						<?php esc_html_e( 'Nothing ticked means every category.', 'mvweb-telegram-hub' ); ?>
					</p>
				</div>
			</div>
		<?php endif; ?>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-post-delay" class="mvweb-form-row__label">
				<?php esc_html_e( 'Wait before posting', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'Minutes between publishing on the site and the message in the channel. Useful for catching a typo before the readers do. Zero sends it straight away.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
					id="mvweb-tg-post-delay"
					name="<?php echo esc_attr( $mvweb_tg_option ); ?>[post_delay]"
					class="mvweb-input mvweb-tg-narrow"
					value="<?php echo esc_attr( (string) $mvweb_tg_delay ); ?>"
					min="0"
					max="10080"
					step="1">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Minutes. The message goes out at that moment or at the first visit to the site after it — neither WordPress nor its queue can promise the exact minute on a quiet site.', 'mvweb-telegram-hub' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-post-photo" class="mvweb-form-row__label">
				<?php esc_html_e( 'Featured image', 'mvweb-telegram-hub' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb-tg-post-photo"
					name="<?php echo esc_attr( $mvweb_tg_option ); ?>[post_photo]"
					class="mvweb-select">
					<option value="preview" <?php selected( 'preview', $mvweb_tg_photo ); ?>><?php esc_html_e( 'Picture above the text, full length text', 'mvweb-telegram-hub' ); ?></option>
					<option value="photo" <?php selected( 'photo', $mvweb_tg_photo ); ?>><?php esc_html_e( 'Photo card, text cut to 1024 characters', 'mvweb-telegram-hub' ); ?></option>
					<option value="none" <?php selected( 'none', $mvweb_tg_photo ); ?>><?php esc_html_e( 'No picture', 'mvweb-telegram-hub' ); ?></option>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Telegram allows 4096 characters in a message but only 1024 in the caption of a photo. The first option gets the picture as a link preview and keeps the whole text; the second is a proper photo card and costs three quarters of the room. A post with no featured image goes out as text either way.', 'mvweb-telegram-hub' ); ?>
				</p>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Telegram fetches the picture by address, so it has to be reachable from outside. On a staging site behind a password there will be no picture.', 'mvweb-telegram-hub' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Message', 'mvweb-telegram-hub' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'A line whose macros all come out empty disappears, so a post without categories leaves no blank gap.', 'mvweb-telegram-hub' ); ?>
		</p>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Macros', 'mvweb-telegram-hub' ); ?></span>
			<div class="mvweb-form-row__field">
				<?php
				$mvweb_tg_macro_list   = Macros::catalogue();
				$mvweb_tg_macro_target = 'mvweb-tg-post-template';
				require MVWEB_TG_PATH . 'admin/views/partial-macros.php';
				?>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-post-template" class="mvweb-form-row__label">
				<?php esc_html_e( 'Template', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'Telegram HTML is supported: b, strong, i, em, u, ins, s, strike, del, code, pre, blockquote and a. Anything else is removed when you save, because Telegram would reject the whole message.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-tg-post-template"
					name="<?php echo esc_attr( $mvweb_tg_option ); ?>[post_template]"
					class="mvweb-textarea"
					rows="10"
					spellcheck="false"><?php echo esc_textarea( $mvweb_tg_template ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Use {post_excerpt} for a teaser and {post_content} for the whole article. Both keep bold, italics, lists and links; the whole article is cut at 4096 characters. Empty the field and save to get the default template back.', 'mvweb-telegram-hub' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-post-teaser" class="mvweb-form-row__label">
				<?php esc_html_e( 'Teaser length', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'Used by {post_excerpt} when the post has no written excerpt and no “more” tag. The cut falls between words, and tags left open are closed.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
					id="mvweb-tg-post-teaser"
					name="<?php echo esc_attr( $mvweb_tg_option ); ?>[post_excerpt_length]"
					class="mvweb-input mvweb-tg-narrow"
					value="<?php echo esc_attr( (string) $mvweb_tg_teaser ); ?>"
					min="100"
					max="3000"
					step="50">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Characters. A written excerpt is used as it is, and a “more” tag in the post marks the end of the teaser exactly.', 'mvweb-telegram-hub' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-post-own-text" class="mvweb-form-row__label">
				<?php esc_html_e( 'Text for Telegram', 'mvweb-telegram-hub' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<input type="hidden" name="<?php echo esc_attr( $mvweb_tg_option ); ?>[post_text_field]" value="0">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb-tg-post-own-text"
							name="<?php echo esc_attr( $mvweb_tg_option ); ?>[post_text_field]"
							value="1"
							<?php checked( $mvweb_tg_own_text ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Take the text from a separate field in the post', 'mvweb-telegram-hub' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Adds a “Text for Telegram” field with the usual Visual and Code tabs under the post editor. When it is filled in, {post_excerpt} and {post_content} take that text instead of the article; when it is empty, the article is announced as usual.', 'mvweb-telegram-hub' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-post-button" class="mvweb-form-row__label">
				<?php esc_html_e( 'Button under the post', 'mvweb-telegram-hub' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
					id="mvweb-tg-post-button"
					name="<?php echo esc_attr( $mvweb_tg_option ); ?>[post_button]"
					class="mvweb-input"
					value="<?php echo esc_attr( $mvweb_tg_button ); ?>"
					maxlength="64">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Label of the button that opens the post on the site. Leave it empty for no button — then put {post_url} in the template, or readers will have no way to the article.', 'mvweb-telegram-hub' ); ?>
				</p>
			</div>
		</div>
	</div>

</form>

<div class="mvweb-submit">
	<button type="submit" name="submit" form="mvweb-tg-form-channels" class="mvweb-btn mvweb-btn--primary">
		<?php esc_html_e( 'Save changes', 'mvweb-telegram-hub' ); ?>
	</button>
</div>
