<?php
/**
 * Macro glossary for a message template.
 *
 * Shared by the order template and the channel post template — the same list,
 * a different catalogue and a different field to type into.
 *
 * Expects two variables from the caller:
 *   $mvweb_tg_macro_list   array<string, string>  macro name => description
 *   $mvweb_tg_macro_target string                 id of the textarea to insert into
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $mvweb_tg_macro_list ) || empty( $mvweb_tg_macro_target ) ) {
	return;
}
?>
<dl class="mvweb-tg-macros" data-target="<?php echo esc_attr( $mvweb_tg_macro_target ); ?>">
	<?php foreach ( $mvweb_tg_macro_list as $mvweb_tg_macro => $mvweb_tg_desc ) : ?>
		<dt>
			<button type="button"
				class="mvweb-tg-macros__insert"
				data-macro="{<?php echo esc_attr( $mvweb_tg_macro ); ?>}"
				title="<?php esc_attr_e( 'Insert into the template', 'mvweb-telegram-hub' ); ?>">
				<code>{<?php echo esc_html( $mvweb_tg_macro ); ?>}</code>
			</button>
		</dt>
		<dd><?php echo esc_html( $mvweb_tg_desc ); ?></dd>
	<?php endforeach; ?>
</dl>
