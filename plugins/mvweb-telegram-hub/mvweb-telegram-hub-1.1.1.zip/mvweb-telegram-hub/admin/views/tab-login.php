<?php
/**
 * Login tab: OpenID Connect credentials and who may sign in.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

use MVweb\Telegram\Hub\Admin\Page;
use MVweb\Telegram\Hub\Auth\Flow;
use MVweb\Telegram\Hub\Auth\Provider;
use MVweb\Telegram\Hub\Auth\Users;
use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tg_option        = Settings::OPTION;
$mvweb_tg_login_on      = Settings::login_enabled();
$mvweb_tg_client_id     = Settings::login_client_id();
$mvweb_tg_secret_const  = Settings::login_secret_is_constant();
$mvweb_tg_secret_masked = Settings::masked_login_secret();
$mvweb_tg_redirect      = Provider::redirect_uri();
$mvweb_tg_ready         = Flow::is_available();
$mvweb_tg_ssl           = is_ssl();
$mvweb_tg_open_register = (bool) get_option( 'users_can_register' );
$mvweb_tg_no_new_role   = '' === Users::new_account_role();
$mvweb_tg_roles         = Users::eligible_roles();
$mvweb_tg_roles_on      = Settings::login_roles();
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Signing in with Telegram', 'mvweb-telegram-hub' ); ?></div>
		<span class="mvweb-badge <?php echo $mvweb_tg_ready ? 'mvweb-badge--success' : 'mvweb-badge--plain'; ?>">
			<?php echo $mvweb_tg_ready ? esc_html__( 'On', 'mvweb-telegram-hub' ) : esc_html__( 'Off', 'mvweb-telegram-hub' ); ?>
		</span>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'A “Sign in with Telegram” button for customers and readers on the storefront: on the WooCommerce account and checkout login forms, and on any page where you place the shortcode. Signed-in customers connect or disconnect Telegram in the “Telegram” section of their account. The WordPress login page is left alone, and the password form keeps working exactly as it does now.', 'mvweb-telegram-hub' ); ?>
	</p>

	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Shortcode for any page:', 'mvweb-telegram-hub' ); ?>
		<code class="mvweb-tg-selectable">[mvweb_tg_login]</code>
	</p>

	<?php if ( ! $mvweb_tg_ssl ) : ?>
		<div class="mvweb-alert mvweb-alert--error">
			<div class="mvweb-alert__body">
				<?php esc_html_e( 'This site is not served over https, and sign-in needs it: Telegram will not send an answer to a plain http address, and the cookie that ties the answer to the visitor’s browser only exists on a secure connection.', 'mvweb-telegram-hub' ); ?>
			</div>
		</div>
	<?php endif; ?>

	<div class="mvweb-alert mvweb-alert--info">
		<div class="mvweb-alert__body">
			<?php esc_html_e( 'The button is drawn only for visitors whose own browser can reach Telegram. For everyone else it is not shown at all, and the page behaves as though this feature did not exist.', 'mvweb-telegram-hub' ); ?>
		</div>
	</div>
</div>

<form id="mvweb-tg-form-login" method="post" action="options.php">
	<?php settings_fields( Page::GROUP ); ?>
	<?php Page::referer_field( 'login' ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Credentials from BotFather', 'mvweb-telegram-hub' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'These are not the bot token. Telegram issues a separate pair for signing in, and it is issued once per bot.', 'mvweb-telegram-hub' ); ?>
		</p>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-redirect-uri" class="mvweb-form-row__label">
				<?php esc_html_e( 'Address to register', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'Telegram sends its answer here and nowhere else. Paste it into BotFather exactly as it is written, including https and any trailing part. It cannot be edited afterwards, so check it before you send it.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
					id="mvweb-tg-redirect-uri"
					class="mvweb-input mvweb-tg-selectable"
					value="<?php echo esc_attr( $mvweb_tg_redirect ); ?>"
					readonly>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'This address follows the site’s login page. If you later move or rename the login page, it changes — and it has to be registered again with Telegram.', 'mvweb-telegram-hub' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-client-id" class="mvweb-form-row__label">
				<?php esc_html_e( 'Client ID', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'Choose the bot once. Telegram gives each bot a different identifier for the same person, so after a change everyone who signed in through the old bot is a stranger to the new one and gets a second, empty account.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
					id="mvweb-tg-client-id"
					name="<?php echo esc_attr( $mvweb_tg_option ); ?>[login_client_id]"
					class="mvweb-input"
					value="<?php echo esc_attr( $mvweb_tg_client_id ); ?>"
					autocomplete="off"
					spellcheck="false"
					data-1p-ignore
					data-lpignore="true">
				<p class="mvweb-form-row__desc">
					<?php if ( Provider::writes_to_user() ) : ?>
						<?php esc_html_e( 'This is the bot that sends order updates, so a customer who joins through Telegram gets them there straight away.', 'mvweb-telegram-hub' ); ?>
					<?php else : ?>
						<?php esc_html_e( 'Use the bot that sends order updates, and a customer who joins through Telegram gets them there straight away, without connecting it separately.', 'mvweb-telegram-hub' ); ?>
					<?php endif; ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-client-secret" class="mvweb-form-row__label">
				<?php esc_html_e( 'Client secret', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'Whoever has this line can ask Telegram to confirm sign-ins on behalf of your site. Keep it to yourself. It can also be put in wp-config.php as MVWEB_TG_LOGIN_SECRET, and then it never reaches the database.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php if ( $mvweb_tg_secret_const ) : ?>
					<input type="text" id="mvweb-tg-client-secret" class="mvweb-input" value="<?php echo esc_attr( $mvweb_tg_secret_masked ); ?>" disabled>
					<p class="mvweb-form-row__desc">
						<?php esc_html_e( 'Defined in wp-config.php as MVWEB_TG_LOGIN_SECRET. Edit that file to change it.', 'mvweb-telegram-hub' ); ?>
					</p>
				<?php else : ?>
					<input type="text"
						id="mvweb-tg-client-secret"
						name="<?php echo esc_attr( $mvweb_tg_option ); ?>[login_client_secret]"
						class="mvweb-input"
						value=""
						autocomplete="off"
						spellcheck="false"
						data-1p-ignore
						data-lpignore="true">
					<p class="mvweb-form-row__desc">
						<?php if ( '' !== $mvweb_tg_secret_masked ) : ?>
							<?php
							printf(
								/* translators: %s: masked client secret. */
								esc_html__( 'Saved secret: %s. Leave the field empty to keep it.', 'mvweb-telegram-hub' ),
								'<code>' . esc_html( $mvweb_tg_secret_masked ) . '</code>'
							);
							?>
						<?php else : ?>
							<?php esc_html_e( 'No secret saved yet.', 'mvweb-telegram-hub' ); ?>
						<?php endif; ?>
					</p>
				<?php endif; ?>

				<details class="mvweb-tg-howto" <?php echo Provider::is_configured() ? '' : 'open'; ?>>
					<summary class="mvweb-tg-howto__lead"><?php esc_html_e( 'How to get the pair — in BotFather', 'mvweb-telegram-hub' ); ?></summary>
					<ol>
						<li>
							<?php
							printf(
								/* translators: %s: BotFather link. */
								esc_html__( 'Open %s and press Open next to the message field: this starts its mini app.', 'mvweb-telegram-hub' ),
								'<a href="https://t.me/BotFather" target="_blank" rel="noopener">@BotFather</a>'
							);
							?>
						</li>
						<li><?php esc_html_e( 'Pick the bot, open Login Widget and press “Switch to OpenID Connect Login”.', 'mvweb-telegram-hub' ); ?></li>
						<li><?php esc_html_e( 'Under Redirect URIs add the address printed above, exactly as it is.', 'mvweb-telegram-hub' ); ?></li>
						<li><?php esc_html_e( 'The same screen shows the client ID and the client secret. Paste both here and save.', 'mvweb-telegram-hub' ); ?></li>
					</ol>
					<p class="mvweb-tg-howto__note"><?php esc_html_e( 'A bot switched to OpenID Connect stops serving the old login widget. If something else relies on that widget, switch a separate bot instead; customers then connect order updates on their own.', 'mvweb-telegram-hub' ); ?></p>
				</details>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Who may sign in', 'mvweb-telegram-hub' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Only the roles ticked below can sign in with Telegram. Roles that edit content or run the site are never offered: this way in skips the password form, and with it any two-factor plugin.', 'mvweb-telegram-hub' ); ?>
		</p>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-login-enabled" class="mvweb-form-row__label">
				<?php esc_html_e( 'Show the button', 'mvweb-telegram-hub' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<input type="hidden" name="<?php echo esc_attr( $mvweb_tg_option ); ?>[login_enabled]" value="0">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb-tg-login-enabled"
							name="<?php echo esc_attr( $mvweb_tg_option ); ?>[login_enabled]"
							value="1"
							<?php checked( $mvweb_tg_login_on ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Offer signing in with Telegram', 'mvweb-telegram-hub' ); ?></span>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-login-register" class="mvweb-form-row__label">
				<?php esc_html_e( 'New visitors', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'A Telegram account nobody here has seen before. With this off, only people who already have an account and have connected Telegram to it can use the button.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<input type="hidden" name="<?php echo esc_attr( $mvweb_tg_option ); ?>[login_register]" value="0">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb-tg-login-register"
							name="<?php echo esc_attr( $mvweb_tg_option ); ?>[login_register]"
							value="1"
							<?php checked( Settings::login_registration() ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Let a new visitor create an account', 'mvweb-telegram-hub' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'The account is created at once, with no email address: Telegram does not share one, and an address nobody has confirmed would prove nothing. An address given at checkout stays with the order. Until the customer adds one in their account details, Telegram is the only way in.', 'mvweb-telegram-hub' ); ?>
				</p>

				<?php if ( ! $mvweb_tg_open_register ) : ?>
					<div class="mvweb-toggle-row">
						<input type="hidden" name="<?php echo esc_attr( $mvweb_tg_option ); ?>[login_register_closed]" value="0">
						<label class="mvweb-toggle">
							<input type="checkbox"
								id="mvweb-tg-login-register-closed"
								name="<?php echo esc_attr( $mvweb_tg_option ); ?>[login_register_closed]"
								value="1"
								<?php checked( Settings::login_registration_when_closed() ); ?>>
							<span class="mvweb-toggle__slider"></span>
						</label>
						<span><?php esc_html_e( 'Create accounts even though registration is closed on this site', 'mvweb-telegram-hub' ); ?></span>
					</div>
					<p class="mvweb-form-row__desc">
						<?php esc_html_e( 'Settings → General says “Anyone can register” is off. Without this box ticked, that answer is respected and nobody new is created.', 'mvweb-telegram-hub' ); ?>
					</p>
				<?php endif; ?>

				<?php if ( $mvweb_tg_no_new_role ) : ?>
					<div class="mvweb-alert mvweb-alert--warning">
						<div class="mvweb-alert__body">
							<?php esc_html_e( 'New accounts get the Customer role, or the default role from Settings → General where there is no shop. Neither is ticked below, so no account will be created through Telegram until one of them is.', 'mvweb-telegram-hub' ); ?>
						</div>
					</div>
				<?php endif; ?>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label" id="mvweb-tg-login-roles-label">
				<?php esc_html_e( 'Roles', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'Roles that can manage options, edit users, install plugins or write posts are left out of this list. They are judged by what they can do, not by the name of their role.', 'mvweb-telegram-hub' ) ); ?>
			</span>
			<div class="mvweb-form-row__field" role="group" aria-labelledby="mvweb-tg-login-roles-label">
				<input type="hidden" name="<?php echo esc_attr( $mvweb_tg_option ); ?>[login_roles][]" value="">
				<?php foreach ( $mvweb_tg_roles as $mvweb_tg_role => $mvweb_tg_role_name ) : ?>
					<label class="mvweb-check mvweb-tg-check">
						<input type="checkbox"
							name="<?php echo esc_attr( $mvweb_tg_option ); ?>[login_roles][]"
							value="<?php echo esc_attr( $mvweb_tg_role ); ?>"
							<?php checked( in_array( $mvweb_tg_role, $mvweb_tg_roles_on, true ) ); ?>>
						<span><?php echo esc_html( $mvweb_tg_role_name ); ?></span>
					</label>
				<?php endforeach; ?>
			</div>
		</div>
	</div>

</form>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Connection', 'mvweb-telegram-hub' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Asks Telegram for its public configuration and its signing keys. This checks the connection from the server — a visitor’s browser has to reach the same host, and that is a different network.', 'mvweb-telegram-hub' ); ?>
	</p>

	<div class="mvweb-toolbar mvweb-tg-actions">
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'mvweb_tg_login_check' ); ?>
			<input type="hidden" name="action" value="mvweb_tg_login_check">
			<button type="submit" class="mvweb-btn"><?php esc_html_e( 'Check the connection', 'mvweb-telegram-hub' ); ?></button>
		</form>
	</div>
</div>

<?php if ( ! $mvweb_tg_secret_const && '' !== $mvweb_tg_secret_masked ) : ?>
	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Remove the client secret', 'mvweb-telegram-hub' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Erases the saved secret right away and cannot be undone. Signing in with Telegram stops until a new one is saved; the connections people have already made stay where they are.', 'mvweb-telegram-hub' ); ?>
		</p>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="mvweb-tg-inline-form">
			<?php wp_nonce_field( 'mvweb_tg_login_forget' ); ?>
			<input type="hidden" name="action" value="mvweb_tg_login_forget">
			<button type="submit"
				class="mvweb-btn mvweb-btn--danger mvweb-tg-confirm"
				data-confirm="<?php esc_attr_e( 'Delete the saved client secret? Signing in with Telegram will stop working.', 'mvweb-telegram-hub' ); ?>">
				<?php esc_html_e( 'Delete client secret', 'mvweb-telegram-hub' ); ?>
			</button>
		</form>
	</div>
<?php endif; ?>

<div class="mvweb-submit">
	<button type="submit" name="submit" form="mvweb-tg-form-login" class="mvweb-btn mvweb-btn--primary">
		<?php esc_html_e( 'Save changes', 'mvweb-telegram-hub' ); ?>
	</button>
</div>
