<?php
/**
 * The customer's choice of order statuses, in the "Telegram" account section.
 *
 * Rendered by Frontend\Connect, which supplies:
 *
 *   array    $mvweb_tg_offered Statuses the shop offers, wc- key => name.
 *   string[] $mvweb_tg_chosen  Statuses this customer currently gets.
 *
 * WooCommerce's own account form markup and classes, so the theme styles it
 * exactly like the account details form next door.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.1
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tg_button_class = wc_wp_theme_get_element_class_name( 'button' );
?>

<form class="woocommerce-EditAccountForm edit-account mvweb-tg-statuses" action="" method="post">
	<fieldset>
		<legend><?php esc_html_e( 'What to send to Telegram', 'mvweb-telegram-hub' ); ?></legend>

		<?php foreach ( $mvweb_tg_offered as $mvweb_tg_key => $mvweb_tg_name ) : ?>
			<p class="woocommerce-form-row woocommerce-form-row--wide form-row form-row-wide">
				<label class="woocommerce-form__label woocommerce-form__label-for-checkbox">
					<input class="woocommerce-form__input woocommerce-form__input-checkbox"
						type="checkbox"
						name="mvweb_tg_statuses[]"
						value="<?php echo esc_attr( $mvweb_tg_key ); ?>"
						<?php checked( in_array( $mvweb_tg_key, $mvweb_tg_chosen, true ) ); ?>>
					<span>
						<?php
						/* translators: %s: order status, e.g. Completed. */
						echo esc_html( sprintf( __( 'Order is “%s”', 'mvweb-telegram-hub' ), $mvweb_tg_name ) );
						?>
					</span>
				</label>
			</p>
		<?php endforeach; ?>
	</fieldset>

	<p>
		<?php wp_nonce_field( 'mvweb_tg_statuses_' . get_current_user_id(), 'mvweb_tg_statuses_nonce' ); ?>
		<button type="submit" class="woocommerce-Button button<?php echo esc_attr( $mvweb_tg_button_class ? ' ' . $mvweb_tg_button_class : '' ); ?>"><?php esc_html_e( 'Save changes', 'mvweb-telegram-hub' ); ?></button>
	</p>
</form>
