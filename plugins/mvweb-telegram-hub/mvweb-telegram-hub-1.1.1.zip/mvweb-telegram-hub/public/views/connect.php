<?php
/**
 * Storefront connect block.
 *
 * Rendered by Frontend\Connect, which supplies:
 *
 *   bool   $mvweb_tg_connected    Whether a chat is already bound.
 *   string $mvweb_tg_link         Deep link that binds one.
 *   string $mvweb_tg_unbind_url   Signed address that undoes the binding.
 *   string $mvweb_tg_order_number Order this block belongs to, empty for an account.
 *
 * The Telegram handle of whoever is connected is deliberately not printed: a
 * guest order page opens to anyone holding its key, and that would hand them
 * the customer's Telegram name.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-tg-connect" data-mvweb-tg-connect>
	<h3 class="mvweb-tg-connect__title"><?php esc_html_e( 'Telegram notifications', 'mvweb-telegram-hub' ); ?></h3>

	<?php if ( $mvweb_tg_connected ) : ?>

		<p class="mvweb-tg-connect__text">
			<?php if ( '' !== $mvweb_tg_order_number ) : ?>
				<?php esc_html_e( 'Connected. Updates on this order arrive in Telegram and by email.', 'mvweb-telegram-hub' ); ?>
			<?php else : ?>
				<?php esc_html_e( 'Connected. Updates on all your orders, future ones included, arrive in Telegram and by email.', 'mvweb-telegram-hub' ); ?>
			<?php endif; ?>
		</p>

		<p class="mvweb-tg-connect__actions">
			<a class="button button-secondary mvweb-tg-connect__disconnect" href="<?php echo esc_url( $mvweb_tg_unbind_url ); ?>">
				<?php esc_html_e( 'Disconnect', 'mvweb-telegram-hub' ); ?>
			</a>
		</p>

	<?php else : ?>

		<p class="mvweb-tg-connect__text" data-mvweb-tg-text>
			<?php if ( '' !== $mvweb_tg_order_number ) : ?>
				<?php esc_html_e( 'Updates on this order will arrive in Telegram, not only by email.', 'mvweb-telegram-hub' ); ?>
			<?php else : ?>
				<?php esc_html_e( 'Order updates will arrive in Telegram, not only by email.', 'mvweb-telegram-hub' ); ?>
			<?php endif; ?>
		</p>

		<p class="mvweb-tg-connect__actions">
			<?php // The theme's own button class: this block should look like the page it sits on, not like a plugin. ?>
			<a class="button mvweb-tg-connect__button"
				href="<?php echo esc_url( $mvweb_tg_link ); ?>"
				target="_blank"
				rel="noopener"
				data-mvweb-tg-start>
				<?php esc_html_e( 'Connect Telegram', 'mvweb-telegram-hub' ); ?>
			</a>

			<?php // Shown once the visitor has left for Telegram; also the whole fallback when JavaScript is off. ?>
			<a class="mvweb-tg-connect__check" href="<?php echo esc_url( remove_query_arg( array( 'mvweb_tg_unbind', '_wpnonce' ) ) ); ?>" hidden data-mvweb-tg-check>
				<?php esc_html_e( 'Check connection', 'mvweb-telegram-hub' ); ?>
			</a>
		</p>

		<details class="mvweb-tg-connect__details" data-mvweb-tg-details>
			<summary class="mvweb-tg-connect__summary"><?php esc_html_e( 'Open on a phone', 'mvweb-telegram-hub' ); ?></summary>

			<?php // A QR cannot be read by a screen reader or copied, so the address is always there in full underneath. ?>
			<div class="mvweb-tg-connect__qr" data-mvweb-tg-qr data-value="<?php echo esc_attr( $mvweb_tg_link ); ?>"></div>

			<p class="mvweb-tg-connect__address">
				<a href="<?php echo esc_url( $mvweb_tg_link ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $mvweb_tg_link ); ?></a>
			</p>
		</details>

		<p class="mvweb-tg-connect__note"><?php esc_html_e( 'Emails are sent either way.', 'mvweb-telegram-hub' ); ?></p>

		<?php // In the DOM from the start, empty: a region added later is not announced. ?>
		<p class="mvweb-tg-connect__status" role="status" data-mvweb-tg-status></p>

	<?php endif; ?>
</div>
