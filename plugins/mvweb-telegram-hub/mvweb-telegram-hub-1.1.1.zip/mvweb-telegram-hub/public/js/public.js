/**
 * Storefront behaviour for the Telegram connect block.
 *
 * The block itself is rendered by PHP and every state it can be in is a
 * server-rendered page, so there is no state machine here and no endpoint to
 * poll: "redraw the block" means "load the page again". What is left is the
 * one thing the server cannot know — that the visitor has just left for
 * Telegram — and the QR code, which only exists to carry the link from a
 * desktop screen to the phone in the visitor's hand.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

( function () {
	'use strict';

	var strings = window.mvwebTgConnect || {};

	/**
	 * Draw the QR code into its box, once.
	 *
	 * The library is handed an address this page just built, and it answers
	 * with a data URL for an image — so nothing here parses or injects markup.
	 *
	 * @param {HTMLElement} box Element carrying data-value.
	 */
	function drawQr( box ) {
		var factory = window.mvwebTgQrcode;
		var value = box.getAttribute( 'data-value' );

		if ( box.getAttribute( 'data-drawn' ) || ! value || typeof factory !== 'function' ) {
			return;
		}

		try {
			var qr = factory( 0, 'M' );
			qr.addData( value );
			qr.make();

			var image = document.createElement( 'img' );
			image.src = qr.createDataURL( 6, 4 );
			image.alt = strings.qrAlt || '';
			image.className = 'mvweb-tg-connect__qr-image';

			box.appendChild( image );
			box.setAttribute( 'data-drawn', '1' );
		} catch ( error ) {
			// The address in full is right underneath, so a missing picture
			// costs nothing. Take the empty frame away rather than leave it.
			box.hidden = true;
		}
	}

	/**
	 * Switch one block into "waiting for confirmation".
	 *
	 * Done on the click, not on an answer from Telegram: otherwise the visitor
	 * comes back to the tab, sees the same button as before and presses it a
	 * second time.
	 *
	 * @param {HTMLElement} block Block root.
	 */
	function setWaiting( block ) {
		var text = block.querySelector( '[data-mvweb-tg-text]' );
		var status = block.querySelector( '[data-mvweb-tg-status]' );
		var check = block.querySelector( '[data-mvweb-tg-check]' );

		block.setAttribute( 'data-waiting', '1' );

		if ( text && strings.waiting ) {
			text.textContent = strings.waiting;
		}

		if ( status && strings.waitingHint ) {
			status.textContent = strings.waitingHint;
		}

		if ( check ) {
			check.hidden = false;
		}
	}

	var blocks = document.querySelectorAll( '[data-mvweb-tg-connect]' );

	Array.prototype.forEach.call( blocks, function ( block ) {
		var start = block.querySelector( '[data-mvweb-tg-start]' );
		var details = block.querySelector( '[data-mvweb-tg-details]' );
		var box = block.querySelector( '[data-mvweb-tg-qr]' );

		if ( start ) {
			start.addEventListener( 'click', function () {
				setWaiting( block );
			} );
		}

		// Drawn when the panel is opened rather than on load: most visitors
		// press the button on the device they are already holding.
		if ( details && box ) {
			details.addEventListener( 'toggle', function () {
				if ( details.open ) {
					drawQr( box );
				}
			} );

			if ( details.open ) {
				drawQr( box );
			}
		}
	} );

	/**
	 * Come back to the tab after pressing Start and the block is stale.
	 *
	 * Reloading is the whole update mechanism. It also covers iOS, where a
	 * backgrounded tab has its timers frozen and any polling would have died
	 * silently anyway.
	 */
	document.addEventListener( 'visibilitychange', function () {
		if ( document.hidden ) {
			return;
		}

		var waiting = document.querySelector( '[data-mvweb-tg-connect][data-waiting="1"]' );

		if ( waiting ) {
			waiting.removeAttribute( 'data-waiting' );
			window.location.reload();
		}
	} );
} )();
