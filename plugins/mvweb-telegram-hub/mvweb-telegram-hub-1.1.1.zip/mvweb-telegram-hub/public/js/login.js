/**
 * Show the Telegram button only where it can work.
 *
 * The server cannot answer that: the server can
 * reach Telegram or not, and the visitor's browser can reach Telegram or not,
 * and the two have nothing to do with each other. So the block is rendered
 * hidden and shown once one no-cors request has come back. Such a request
 * resolves on any HTTP answer, whatever its status or content type, and
 * rejects only when the connection itself failed — which is the question.
 *
 * Nothing waits on any of this: the ordinary WordPress form is already on
 * screen and stays usable throughout.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

( function () {
	'use strict';

	var PROBE = 'https://oauth.telegram.org/.well-known/openid-configuration';
	var TIMEOUT = 5000;

	var blocks = document.querySelectorAll( '.mvweb-tg-login' );

	if ( ! blocks.length ) {
		return;
	}

	function reveal() {
		Array.prototype.forEach.call( blocks, function ( block ) {
			block.hidden = false;
		} );
	}

	// No fetch means no way to ask, and a button nobody can see is worse than
	// one that might not work. An old browser gets the button.
	if ( typeof window.fetch !== 'function' ) {
		reveal();
		return;
	}

	var controller = typeof window.AbortController === 'function' ? new window.AbortController() : null;
	var timer = null;

	if ( controller ) {
		timer = window.setTimeout( function () {
			controller.abort();
		}, TIMEOUT );
	}

	window
		.fetch( PROBE, {
			mode: 'no-cors',
			cache: 'no-store',
			credentials: 'omit',
			redirect: 'follow',
			signal: controller ? controller.signal : undefined
		} )
		.then( reveal )
		.catch( function () {
			// Nothing to report and nothing to fall back to: the password form
			// is already there, and it is the one that always works.
		} )
		.then( function () {
			if ( timer ) {
				window.clearTimeout( timer );
			}
		} );
} )();
