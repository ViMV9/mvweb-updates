<?php
/**
 * Plugin Name:       MVweb Telegram Hub
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-telegram-hub
 * Description:       Connects a WordPress site to Telegram. Order notifications for the shop team and for the customer, new posts to a channel, and signing in with Telegram.
 * Version:           1.1.0
 * Requires at least: 7.0
 * Tested up to:      7.1.3
 * Requires PHP:      8.1
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-telegram-hub
 * Domain Path:       /languages
 * Update URI:        https://mvweb.ru/plugins/mvweb-telegram-hub
 *
 * @package MVweb\Telegram\Hub
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_TG_VERSION' ) ) {
	return;
}

define( 'MVWEB_TG_VERSION', '1.1.0' );
define( 'MVWEB_TG_FILE', __FILE__ );
define( 'MVWEB_TG_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_TG_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_TG_BASENAME', plugin_basename( __FILE__ ) );
define( 'MVWEB_TG_SLUG', 'mvweb-telegram-hub' );

// Minimum environment. Kept as constants so Lifecycle and the admin notice agree.
define( 'MVWEB_TG_MIN_WP', '7.0' );
define( 'MVWEB_TG_MIN_PHP', '8.1' );
define( 'MVWEB_TG_MIN_WC', '11.0' );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$mvweb_tg_shared_path = dirname( dirname( MVWEB_TG_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_TG_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_TG_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $mvweb_tg_shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $mvweb_tg_shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_TG_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_TG_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $mvweb_tg_shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $mvweb_tg_shared_path . 'class-mvweb-updater.php';
}

$mvweb_tg_updater = null;

if ( class_exists( 'MVweb_Updater' ) ) {
	$mvweb_tg_updater = MVweb_Updater::create( MVWEB_TG_FILE, MVWEB_TG_SLUG );
}

// Load MVweb License.
if ( file_exists( MVWEB_TG_PATH . 'includes/class-mvweb-license.php' ) ) {
	require_once MVWEB_TG_PATH . 'includes/class-mvweb-license.php';
} elseif ( file_exists( $mvweb_tg_shared_path . 'class-mvweb-license.php' ) ) {
	require_once $mvweb_tg_shared_path . 'class-mvweb-license.php';
}

if ( class_exists( 'MVweb_License' ) ) {
	MVweb_License::init( MVWEB_TG_SLUG, $mvweb_tg_updater, 'plugin', MVWEB_TG_SLUG );
}

unset( $mvweb_tg_shared_path, $mvweb_tg_updater );

// ───────────────────────────────────────────────
// Plugin bootstrap
// ───────────────────────────────────────────────
require_once MVWEB_TG_PATH . 'src/Autoloader.php';

\MVweb\Telegram\Hub\Autoloader::register();

register_activation_hook( MVWEB_TG_FILE, array( \MVweb\Telegram\Hub\Lifecycle::class, 'activate' ) );
register_deactivation_hook( MVWEB_TG_FILE, array( \MVweb\Telegram\Hub\Lifecycle::class, 'deactivate' ) );

// HPOS compatibility must be declared before WooCommerce boots, so it cannot
// wait for Plugin::boot() on plugins_loaded.
add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
				'custom_order_tables',
				MVWEB_TG_FILE,
				true
			);
		}
	}
);

// Register this plugin with MVweb Menu hub page.
add_filter(
	'mvweb_registered_plugins',
	static function ( $plugins ) {
		$plugins[ MVWEB_TG_SLUG ] = array(
			'name'         => 'MVweb Telegram Hub',
			'description'  => __( 'Connects a WordPress site to Telegram. Order notifications for the shop team and for the customer, new posts to a channel, and signing in with Telegram.', 'mvweb-telegram-hub' ),
			'url'          => 'https://mvweb.ru/plugins/mvweb-telegram-hub',
			'settings_url' => 'admin.php?page=' . MVWEB_TG_SLUG,
			'textdomain'   => 'mvweb-telegram-hub',
		);
		return $plugins;
	}
);

add_action(
	'plugins_loaded',
	static function () {
		load_plugin_textdomain(
			'mvweb-telegram-hub',
			false,
			dirname( plugin_basename( MVWEB_TG_FILE ) ) . '/languages/'
		);
	}
);

if ( ! function_exists( 'mvweb_tg_notify_user' ) ) {
	/**
	 * Send a customer a message of your own through their Telegram binding.
	 *
	 * The way a site puts its own events — a return, a pre-order, a support
	 * reply — down the channel the customer already connected, without the
	 * plugin having to know what any of those are.
	 *
	 * Nothing happens unless that customer has connected Telegram themselves:
	 * the binding is the consent, and there is no way to write to somebody who
	 * has not given it.
	 *
	 * The text is escaped here rather than at the call site. Every other path
	 * in the plugin escapes at the source, and a public entry point is the
	 * worst possible place to make that somebody else's job — an unescaped
	 * ampersand in a product name is enough for Telegram to reject the whole
	 * message with a 400, which is not retried.
	 *
	 * It is also cut down to a thousand characters, and that is not about
	 * readability. Job arguments are capped at 8000 bytes, and the encoder that
	 * writes them escapes every Cyrillic character as \uXXXX — six bytes each.
	 * Past the cap the job is dropped where nobody is looking.
	 *
	 * @since 1.1.0
	 *
	 * @param int    $user_id    WordPress user to write to.
	 * @param string $text       Message. Plain text unless $allow_html is set.
	 * @param bool   $allow_html Keep the handful of tags Telegram understands.
	 * @return bool Whether the message was queued.
	 */
	function mvweb_tg_notify_user( $user_id, $text, $allow_html = false ) {
		$user_id = absint( $user_id );
		$text    = trim( (string) $text );

		if ( ! $user_id || '' === $text ) {
			return false;
		}

		if ( '' === \MVweb\Telegram\Hub\Link\Binding::of_user( $user_id ) ) {
			return false;
		}

		$text = $allow_html
			? wp_kses( $text, \MVweb\Telegram\Hub\Telegram\Formatter::allowed_tags() )
			: \MVweb\Telegram\Hub\Telegram\Formatter::escape( $text );

		return \MVweb\Telegram\Hub\Queue\Dispatcher::schedule(
			array(
				'user_id' => $user_id,
				'text'    => \MVweb\Telegram\Hub\Telegram\Formatter::truncate( $text, 1000 ),
				'attempt' => 1,
			)
		);
	}
}

/*
 * Boot on init, not on plugins_loaded. Reading a setting merges the defaults,
 * and the default message template is a translatable string — so the very first
 * Settings::get() pulls the textdomain in. Before init that is a just-in-time
 * load, which WordPress 6.7 reports as _doing_it_wrong. Nothing here needs to
 * run earlier: every hook this registers (checkout, queue, cron, admin screens)
 * fires well after init, and the HPOS declaration has its own hook above.
 */
add_action(
	'init',
	static function () {
		\MVweb\Telegram\Hub\Plugin::instance()->boot();
	}
);
