<?php
/**
 * Activation and deactivation handlers.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub;

use MVweb\Telegram\Hub\Log\Cleanup;
use MVweb\Telegram\Hub\Log\Table;
use MVweb\Telegram\Hub\Queue\Dispatcher;
use MVweb\Telegram\Hub\Rest\Webhook;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sets the plugin up and takes it back down cleanly.
 *
 * Neither handler touches stored settings or the log — removing data is the
 * uninstall step, and only when the operator asked for it.
 *
 * @since 1.0.0
 */
final class Lifecycle {

	/**
	 * Prepare storage and schedules.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function activate() {
		self::guard_environment();

		Table::install();

		add_option( Settings::OPTION, Settings::defaults(), '', true );

		Cleanup::schedule();
	}

	/**
	 * Stop background work. Data stays untouched.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function deactivate() {
		Cleanup::unschedule();
		Dispatcher::cancel_all();

		/*
		 * A webhook is registered against the bot, not against the site, and it
		 * outlives the plugin: Telegram would go on posting updates to an
		 * address that no longer answers, and getUpdates — which the "find my
		 * chats" button needs — stays blocked for as long as one is set. Costs
		 * one API call, and only on a host that cannot reach Telegram is that
		 * call slow, which is a host where the webhook never worked anyway.
		 */
		Webhook::disable();
	}

	/**
	 * Refuse to activate on an environment we do not support.
	 *
	 * WooCommerce is not checked here and is not a "Requires Plugins" header
	 * either: two of the four features — channel posting and signing in — have
	 * nothing to do with it, and the header would stop a plain blog from
	 * activating the plugin at all. The modules that do need WooCommerce say so
	 * themselves through requirements_met().
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function guard_environment() {
		global $wp_version;

		$problem = '';

		if ( version_compare( PHP_VERSION, MVWEB_TG_MIN_PHP, '<' ) ) {
			$problem = sprintf(
				/* translators: 1: required PHP version, 2: current PHP version. */
				__( 'MVweb Telegram Hub needs PHP %1$s or newer. This server runs PHP %2$s.', 'mvweb-telegram-hub' ),
				MVWEB_TG_MIN_PHP,
				PHP_VERSION
			);
		} elseif ( version_compare( $wp_version, MVWEB_TG_MIN_WP, '<' ) ) {
			$problem = sprintf(
				/* translators: 1: required WordPress version, 2: current WordPress version. */
				__( 'MVweb Telegram Hub needs WordPress %1$s or newer. This site runs WordPress %2$s.', 'mvweb-telegram-hub' ),
				MVWEB_TG_MIN_WP,
				$wp_version
			);
		}

		if ( '' === $problem ) {
			return;
		}

		deactivate_plugins( MVWEB_TG_BASENAME );

		wp_die(
			esc_html( $problem ),
			esc_html__( 'Plugin activation failed', 'mvweb-telegram-hub' ),
			array( 'back_link' => true )
		);
	}
}
