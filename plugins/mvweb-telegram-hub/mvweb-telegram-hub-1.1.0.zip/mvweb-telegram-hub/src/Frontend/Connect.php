<?php
/**
 * The connect block a customer sees in the shop.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Frontend;

use MVweb\Telegram\Hub\Link\Binding;
use WC_Order;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One block, two states, no endpoint of its own.
 *
 * Where it appears is mostly a single hook:
 * woocommerce_order_details_after_order_table covers the "order received" page
 * in the classic templates, the same page built out of blocks, and the order
 * view inside the account — and it arrives with the order already loaded.
 * woocommerce_thankyou and woocommerce_view_order stand behind it for themes
 * that replace the order table with their own markup.
 * woocommerce_account_dashboard adds the one place that belongs to no order,
 * which is where a returning customer connects once and is done.
 *
 * There is no AJAX and nothing to poll. The block is server-rendered, so the
 * way to redraw it is to load the page again; the only client-side state is
 * "this visitor has just left for Telegram", which lives for as long as the
 * tab stays in the background.
 *
 * Because there is no endpoint that mints a link, there is nothing to point a
 * forged order id at: the link is built while rendering a page WooCommerce has
 * already decided this visitor may see, from the order object it handed over.
 *
 * @since 1.1.0
 */
final class Connect {

	/**
	 * Targets already rendered in this request.
	 *
	 * The order-details hook fires from more than one template, and a theme
	 * that prints both would otherwise show the block twice.
	 *
	 * @var array<string, bool>
	 */
	private static $rendered = array();

	/**
	 * Hook the storefront.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function register() {
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'wp_loaded', array( $this, 'maybe_unbind' ) );
		add_action( 'woocommerce_order_details_after_order_table', array( $this, 'render_for_order' ) );
		add_action( 'woocommerce_thankyou', array( $this, 'render_for_order_id' ), 20 );
		add_action( 'woocommerce_view_order', array( $this, 'render_for_order_id' ), 20 );
		add_action( 'woocommerce_account_dashboard', array( $this, 'render_for_account' ) );
	}

	/**
	 * Render the block from a hook that hands over only the order id.
	 *
	 * A theme with its own order layout unhooks woocommerce_order_details_table
	 * from these two pages, and the order-details hook goes with it. Both pages
	 * still fire their own action, so the block falls back to that; on a theme
	 * that keeps the table, the order-details hook has already run and the
	 * rendered guard stops a second copy.
	 *
	 * @since 1.1.0
	 * @param mixed $order_id Order id, per the hook.
	 * @return void
	 */
	public function render_for_order_id( $order_id ) {
		$order = wc_get_order( absint( $order_id ) );

		if ( $order ) {
			$this->render_for_order( $order );
		}
	}

	/**
	 * Declare the assets without loading them.
	 *
	 * They are enqueued from the render, so a shop where nobody ever sees the
	 * block never serves them.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function register_assets() {
		wp_register_style(
			'mvweb-tg-public',
			MVWEB_TG_URL . 'public/css/public.min.css',
			array(),
			self::asset_version( 'public/css/public.min.css' )
		);

		wp_register_script(
			'mvweb-tg-qrcode',
			MVWEB_TG_URL . 'public/js/qrcode.min.js',
			array(),
			self::asset_version( 'public/js/qrcode.min.js' ),
			true
		);

		wp_register_script(
			'mvweb-tg-public',
			MVWEB_TG_URL . 'public/js/public.min.js',
			array( 'mvweb-tg-qrcode' ),
			self::asset_version( 'public/js/public.min.js' ),
			true
		);

		wp_localize_script(
			'mvweb-tg-public',
			'mvwebTgConnect',
			array(
				'waiting'     => __( 'Waiting for confirmation in Telegram', 'mvweb-telegram-hub' ),
				'waitingHint' => __( 'Press the start button in the chat that just opened.', 'mvweb-telegram-hub' ),
				'qrAlt'       => __( 'QR code with the link to the bot', 'mvweb-telegram-hub' ),
			)
		);
	}

	/**
	 * Render the block under an order.
	 *
	 * @since 1.1.0
	 * @param mixed $order Order object, per the hook.
	 * @return void
	 */
	public function render_for_order( $order ) {
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		$target = 'o' . $order->get_id();

		if ( isset( self::$rendered[ $target ] ) ) {
			return;
		}

		if ( ! Binding::can_manage_order( $order, self::requested_key() ) ) {
			return;
		}

		self::$rendered[ $target ] = true;

		$user_id    = get_current_user_id();
		$is_owner   = $user_id > 0 && $order->get_customer_id() === $user_id;
		$order_chat = (string) $order->get_meta( Binding::ORDER_META );

		/*
		 * A signed-in owner is offered the account-wide binding instead: they
		 * will order again, and one press should still be enough then. The
		 * exception is an order that carries a binding of its own — handed to a
		 * colleague, say — which stays with whoever holds it.
		 */
		if ( '' === $order_chat && $is_owner ) {
			$this->render_account( $user_id );
			return;
		}

		// No address on file means no way to warn the customer that somebody
		// attached a Telegram account to their order, so it is not offered.
		if ( '' === $order_chat && ! Binding::order_can_bind( $order ) ) {
			return;
		}

		$back = $is_owner ? $order->get_view_order_url() : $order->get_checkout_order_received_url();

		$this->render(
			$order_chat,
			Binding::order_link( $order ),
			self::unbind_url( $target, $back ),
			$order->get_order_number()
		);
	}

	/**
	 * Render the block on the account dashboard.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function render_for_account() {
		$user_id = get_current_user_id();

		if ( ! $user_id ) {
			return;
		}

		$this->render_account( $user_id );
	}

	/**
	 * Undo a binding from the link in the block.
	 *
	 * A signed GET handled on wp_loaded, the way WooCommerce cancels an order:
	 * no admin-post round trip, so it also works on a site that keeps guests
	 * out of wp-admin. The nonce alone proves nothing for a guest — every
	 * signed-out visitor shares one — so ownership is proved the way
	 * WooCommerce proves it, by the order key.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function maybe_unbind() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- the nonce is verified below, once there is something to verify.
		if ( empty( $_GET['mvweb_tg_unbind'] ) ) {
			return;
		}

		$target = sanitize_text_field( wp_unslash( $_GET['mvweb_tg_unbind'] ) );
		$nonce  = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		if ( ! wp_verify_nonce( $nonce, 'mvweb_tg_unbind_' . $target ) ) {
			return;
		}

		nocache_headers();

		$back = '';

		if ( preg_match( '/^o(\d+)$/', $target, $parts ) ) {
			$order = wc_get_order( (int) $parts[1] );

			if ( $order instanceof WC_Order && Binding::can_manage_order( $order, self::requested_key() ) ) {
				Binding::unbind_order( $order );

				$back = $order->get_customer_id() && get_current_user_id() === $order->get_customer_id()
					? $order->get_view_order_url()
					: $order->get_checkout_order_received_url();
			}
		} elseif ( preg_match( '/^u(\d+)$/', $target, $parts ) && get_current_user_id() === (int) $parts[1] ) {
			Binding::unbind_user( (int) $parts[1] );

			$back = wc_get_page_permalink( 'myaccount' );
		}

		if ( '' === $back ) {
			return;
		}

		wp_safe_redirect( $back );
		exit;
	}

	/**
	 * Render the account-wide block.
	 *
	 * @since 1.1.0
	 * @param int $user_id User id.
	 * @return void
	 */
	private function render_account( $user_id ) {
		$target = 'u' . $user_id;

		if ( isset( self::$rendered[ $target ] ) ) {
			return;
		}

		self::$rendered[ $target ] = true;

		$this->render(
			Binding::of_user( $user_id ),
			Binding::account_link( $user_id ),
			self::unbind_url( $target, wc_get_page_permalink( 'myaccount' ) ),
			''
		);
	}

	/**
	 * Print one block.
	 *
	 * @since 1.1.0
	 * @param string $chat_id      Chat already bound, empty when there is none.
	 * @param string $link         Deep link that would bind it.
	 * @param string $unbind_url   Signed address that undoes the binding.
	 * @param string $order_number Order this block belongs to, empty for an account.
	 * @return void
	 */
	private function render( $chat_id, $link, $unbind_url, $order_number ) {
		$connected = '' !== $chat_id;

		// Nothing to offer and nothing to report: no bot, so no block.
		if ( ! $connected && '' === $link ) {
			return;
		}

		wp_enqueue_style( 'mvweb-tg-public' );

		if ( ! $connected ) {
			wp_enqueue_script( 'mvweb-tg-public' );
		}

		// Used by the view.
		$mvweb_tg_connected    = $connected;
		$mvweb_tg_link         = $link;
		$mvweb_tg_unbind_url   = $unbind_url;
		$mvweb_tg_order_number = $order_number;

		require MVWEB_TG_PATH . 'public/views/connect.php';
	}

	/**
	 * Signed address that removes a binding.
	 *
	 * @since 1.1.0
	 * @param string $target Binding key, e.g. o1234 or u7.
	 * @param string $base   Page to return to afterwards.
	 * @return string
	 */
	private static function unbind_url( $target, $base ) {
		return wp_nonce_url(
			add_query_arg( 'mvweb_tg_unbind', $target, $base ),
			'mvweb_tg_unbind_' . $target
		);
	}

	/**
	 * Order key supplied with the current request, if any.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private static function requested_key() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- a bearer value WooCommerce itself reads the same way, compared with hash_equals().
		return isset( $_GET['key'] ) ? sanitize_text_field( wp_unslash( $_GET['key'] ) ) : '';
	}

	/**
	 * Cache-busting version for an asset.
	 *
	 * @since 1.1.0
	 * @param string $relative Path relative to the plugin root.
	 * @return string
	 */
	private static function asset_version( $relative ) {
		$path  = MVWEB_TG_PATH . $relative;
		$mtime = file_exists( $path ) ? filemtime( $path ) : 0;

		return $mtime ? (string) $mtime : MVWEB_TG_VERSION;
	}
}
