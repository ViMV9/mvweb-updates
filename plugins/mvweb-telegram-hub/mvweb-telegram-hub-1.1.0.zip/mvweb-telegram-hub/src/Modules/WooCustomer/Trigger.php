<?php
/**
 * Order status trigger for customer notifications.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.1.0
 */

namespace MVweb\Telegram\Hub\Modules\WooCustomer;

use MVweb\Telegram\Hub\Link\Binding;
use MVweb\Telegram\Hub\Queue\Dispatcher;
use MVweb\Telegram\Hub\Settings;
use WC_Order;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Decides which status changes are worth a message to the shopper.
 *
 * @since 1.1.0
 */
final class Trigger {

	/**
	 * Hook the status transition.
	 *
	 * Subscribed to woocommerce_order_status_changed rather than to the
	 * per-status variants: it is fired from WC_Order::save(), so one hook
	 * covers the admin screen, wp-cli, the REST API and both order stores.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function register() {
		add_action( 'woocommerce_order_status_changed', array( $this, 'on_status_changed' ), 10, 4 );
	}

	/**
	 * Queue a notification when the new status is one the shop ticked.
	 *
	 * @since 1.1.0
	 * @param int      $order_id    Order id.
	 * @param string   $status_from Status the order left. Unused.
	 * @param string   $status_to   Status the order entered, without the wc- prefix.
	 * @param WC_Order $order       Order object.
	 * @return void
	 */
	public function on_status_changed( $order_id, $status_from, $status_to, $order = null ) {
		unset( $status_from );

		// Only the token matters here. is_ready() also demands an operator chat,
		// and a shop that writes to its customers and to nobody else would then
		// stay silent with nothing on screen to explain why.
		if ( ! Settings::has_token() ) {
			return;
		}

		if ( self::inside_checkout() ) {
			return;
		}

		/*
		 * wc_get_order_statuses() keys carry the wc- prefix and the hook
		 * argument does not, so the two never match without this. Prefixing the
		 * incoming slug is what WooCommerce itself does when it has to compare
		 * the two.
		 */
		if ( ! in_array( 'wc-' . $status_to, Settings::customer_statuses(), true ) ) {
			return;
		}

		if ( ! $order instanceof WC_Order ) {
			$order = wc_get_order( $order_id );
		}

		if ( ! $order instanceof WC_Order ) {
			return;
		}

		// Nobody to write to. Checked here as well as at delivery so the queue
		// does not fill with jobs for orders that have no Telegram behind them.
		if ( '' === Binding::for_order( $order ) ) {
			return;
		}

		Dispatcher::schedule(
			array(
				'module'    => Module::slug(),
				'object_id' => $order->get_id(),
				'attempt'   => 1,
			)
		);
	}

	/**
	 * Whether the order is being placed right now.
	 *
	 * A brand-new order does not sit still: it is created as "pending" and the
	 * gateway moves it to "processing" or "on-hold" inside the same request, so
	 * the transition hook fires during checkout with a perfectly ordinary
	 * from-status. A customer who is already connected would get a Telegram
	 * message on top of the "order received" page they are looking at and the
	 * confirmation email — three touches in one minute.
	 *
	 * did_action() answers this without storing anything: both checkout hooks
	 * run before payment is processed, so by the time a status changes in that
	 * request the counter is no longer zero.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	private static function inside_checkout() {
		return did_action( 'woocommerce_checkout_order_processed' ) > 0
			|| did_action( 'woocommerce_store_api_checkout_order_processed' ) > 0;
	}
}
