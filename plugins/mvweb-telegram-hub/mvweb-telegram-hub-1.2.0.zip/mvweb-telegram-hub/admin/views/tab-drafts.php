<?php
/**
 * Queue tab: prepared posts published on a schedule.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.2.0
 */

use MVweb\Telegram\Hub\Admin\Page;
use MVweb\Telegram\Hub\Modules\Drafts\Import;
use MVweb\Telegram\Hub\Modules\Drafts\Module;
use MVweb\Telegram\Hub\Modules\Drafts\PostType;
use MVweb\Telegram\Hub\Modules\Drafts\Schedule;
use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tg_option    = Settings::OPTION;
$mvweb_tg_on        = Settings::module_enabled( Module::slug() );
$mvweb_tg_has_token = Settings::has_token();
$mvweb_tg_has_chan  = array() !== Settings::channels();
$mvweb_tg_times     = implode( ', ', Settings::drafts_times() );
$mvweb_tg_order     = Settings::drafts_order();
$mvweb_tg_end       = Settings::drafts_end();
$mvweb_tg_counts    = $mvweb_tg_on ? Module::counts() : array(
	'waiting' => 0,
	'sent'    => 0,
);
$mvweb_tg_next      = $mvweb_tg_on ? Schedule::next_run() : 0;
$mvweb_tg_format    = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Prepared posts on a schedule', 'mvweb-telegram-hub' ); ?></div>
		<span class="mvweb-badge <?php echo $mvweb_tg_on ? 'mvweb-badge--success' : 'mvweb-badge--plain'; ?>">
			<?php echo $mvweb_tg_on ? esc_html__( 'On', 'mvweb-telegram-hub' ) : esc_html__( 'Off', 'mvweb-telegram-hub' ); ?>
		</span>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Texts written in advance — facts, tips, reminders — go to your channels one at a time, at the times you set. They go to the same channels as new posts, listed on the Channels tab.', 'mvweb-telegram-hub' ); ?>
	</p>

	<?php if ( ! $mvweb_tg_on ) : ?>
		<div class="mvweb-alert mvweb-alert--info">
			<div class="mvweb-alert__body">
				<?php
				printf(
					/* translators: %s: link to the Bot tab. */
					esc_html__( 'The module is switched off. Turn on “Prepared posts to a Telegram channel on a schedule” under Modules on the %s tab.', 'mvweb-telegram-hub' ),
					'<a href="' . esc_url( Page::tab_url( 'bot' ) ) . '">' . esc_html__( 'Bot', 'mvweb-telegram-hub' ) . '</a>'
				);
				?>
			</div>
		</div>
	<?php elseif ( ! $mvweb_tg_has_token ) : ?>
		<div class="mvweb-alert mvweb-alert--warning">
			<div class="mvweb-alert__body">
				<?php esc_html_e( 'No bot token is saved, so nothing can be sent anywhere yet.', 'mvweb-telegram-hub' ); ?>
			</div>
		</div>
	<?php elseif ( ! $mvweb_tg_has_chan ) : ?>
		<div class="mvweb-alert mvweb-alert--warning">
			<div class="mvweb-alert__body">
				<?php
				printf(
					/* translators: %s: link to the Channels tab. */
					esc_html__( 'No channel is listed yet. Add one on the %s tab, or the queue has nowhere to go.', 'mvweb-telegram-hub' ),
					'<a href="' . esc_url( Page::tab_url( 'channels' ) ) . '">' . esc_html__( 'Channels', 'mvweb-telegram-hub' ) . '</a>'
				);
				?>
			</div>
		</div>
	<?php endif; ?>

	<?php if ( $mvweb_tg_on ) : ?>
		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Queue', 'mvweb-telegram-hub' ); ?></span>
			<div class="mvweb-form-row__field">
				<p>
					<?php
					printf(
						/* translators: 1: number of posts waiting, 2: number of posts already published. */
						esc_html__( 'Waiting: %1$d. Already published: %2$d.', 'mvweb-telegram-hub' ),
						(int) $mvweb_tg_counts['waiting'],
						(int) $mvweb_tg_counts['sent']
					);
					?>
				</p>
				<p class="mvweb-form-row__desc">
					<?php if ( ! $mvweb_tg_next ) : ?>
						<?php esc_html_e( 'Nothing is scheduled: save at least one time below.', 'mvweb-telegram-hub' ); ?>
					<?php elseif ( 0 === (int) $mvweb_tg_counts['waiting'] && 'stop' === $mvweb_tg_end ) : ?>
						<?php esc_html_e( 'Every post has been published and the queue is set to stop. Add new posts and it carries on by itself.', 'mvweb-telegram-hub' ); ?>
					<?php else : ?>
						<?php
						printf(
							/* translators: %s: date and time. */
							esc_html__( 'Next post: %s, or on the first visit to the site after that.', 'mvweb-telegram-hub' ),
							esc_html( wp_date( $mvweb_tg_format, $mvweb_tg_next ) )
						);
						?>
					<?php endif; ?>
				</p>
				<p class="mvweb-tg-discover">
					<a class="mvweb-btn mvweb-btn--primary" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=' . PostType::NAME ) ); ?>">
						<?php esc_html_e( 'Add post', 'mvweb-telegram-hub' ); ?>
					</a>
					<a class="mvweb-btn" href="<?php echo esc_url( admin_url( 'edit.php?post_type=' . PostType::NAME ) ); ?>">
						<?php esc_html_e( 'Open the queue', 'mvweb-telegram-hub' ); ?>
					</a>
				</p>
			</div>
		</div>
	<?php endif; ?>
</div>

<form id="mvweb-tg-form-drafts" method="post" action="options.php">
	<?php settings_fields( Page::GROUP ); ?>
	<?php Page::referer_field( 'drafts' ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Schedule', 'mvweb-telegram-hub' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-drafts-times" class="mvweb-form-row__label">
				<?php esc_html_e( 'Publish at', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'In the site’s time zone, set under Settings → General. One post goes out at each time, every day.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
					id="mvweb-tg-drafts-times"
					name="<?php echo esc_attr( $mvweb_tg_option ); ?>[drafts_times]"
					class="mvweb-input"
					value="<?php echo esc_attr( $mvweb_tg_times ); ?>"
					placeholder="10:00, 18:00"
					spellcheck="false">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Times separated by commas, for example 10:00, 18:00. The site publishes at the time given or on the first visit after it: WordPress runs its schedule when somebody opens the site, so on a quiet site a post can come a little late.', 'mvweb-telegram-hub' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-drafts-order" class="mvweb-form-row__label"><?php esc_html_e( 'Order', 'mvweb-telegram-hub' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb-tg-drafts-order" name="<?php echo esc_attr( $mvweb_tg_option ); ?>[drafts_order]" class="mvweb-select">
					<option value="list" <?php selected( 'list', $mvweb_tg_order ); ?>><?php esc_html_e( 'As listed', 'mvweb-telegram-hub' ); ?></option>
					<option value="random" <?php selected( 'random', $mvweb_tg_order ); ?>><?php esc_html_e( 'Random, without repeats', 'mvweb-telegram-hub' ); ?></option>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( '“As listed” follows the Order field of each post, smallest first. “Random” picks any post that has not gone out yet, so nothing repeats until the whole queue is through.', 'mvweb-telegram-hub' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-drafts-end" class="mvweb-form-row__label"><?php esc_html_e( 'When the queue runs out', 'mvweb-telegram-hub' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb-tg-drafts-end" name="<?php echo esc_attr( $mvweb_tg_option ); ?>[drafts_end]" class="mvweb-select">
					<option value="stop" <?php selected( 'stop', $mvweb_tg_end ); ?>><?php esc_html_e( 'Stop and wait for new posts', 'mvweb-telegram-hub' ); ?></option>
					<option value="loop" <?php selected( 'loop', $mvweb_tg_end ); ?>><?php esc_html_e( 'Start over from the beginning', 'mvweb-telegram-hub' ); ?></option>
				</select>
			</div>
		</div>
	</div>
</form>

<div class="mvweb-submit">
	<button type="submit" name="submit" form="mvweb-tg-form-drafts" class="mvweb-btn mvweb-btn--primary">
		<?php esc_html_e( 'Save changes', 'mvweb-telegram-hub' ); ?>
	</button>
</div>

<?php if ( $mvweb_tg_on ) : ?>
	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Import from a file', 'mvweb-telegram-hub' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'A CSV table, one post per row, added to the end of the queue. Columns in this order: text, picture address, button label, button link. Only the text is required. A header row is fine. Up to 500 rows at a time.', 'mvweb-telegram-hub' ); ?>
		</p>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
			<input type="hidden" name="action" value="<?php echo esc_attr( Import::ACTION ); ?>">
			<?php wp_nonce_field( Import::ACTION ); ?>

			<div class="mvweb-form-row">
				<label for="mvweb-tg-drafts-file" class="mvweb-form-row__label"><?php esc_html_e( 'CSV file', 'mvweb-telegram-hub' ); ?></label>
				<div class="mvweb-form-row__field">
					<input type="file" id="mvweb-tg-drafts-file" name="mvweb_tg_drafts_file" accept=".csv,text/csv" required>
					<p class="mvweb-form-row__desc">
						<?php esc_html_e( 'From Excel or Google Sheets: File → Save as / Download → CSV. A comma or a semicolon as the separator both work.', 'mvweb-telegram-hub' ); ?>
					</p>
					<p>
						<button type="submit" class="mvweb-btn"><?php esc_html_e( 'Import', 'mvweb-telegram-hub' ); ?></button>
					</p>
				</div>
			</div>
		</form>
	</div>
<?php endif; ?>
