<?php
/**
 * Prepared posts published to the channels on a schedule.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.2.0
 */

namespace MVweb\Telegram\Hub\Modules\Drafts;

use MVweb\Telegram\Hub\Modules\ModuleInterface;
use MVweb\Telegram\Hub\Modules\Posts\Content;
use MVweb\Telegram\Hub\Modules\Posts\Module as PostsModule;
use MVweb\Telegram\Hub\Queue\Dispatcher;
use MVweb\Telegram\Hub\Settings;
use MVweb\Telegram\Hub\Telegram\Formatter;
use WP_Post;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A queue of texts written in advance, one taken at each scheduled time.
 *
 * The second source of channel posts, next to the site's own articles. It
 * shares their channel list and their picture mode, and nothing else: an item
 * here is not a page on the site, so there is no permalink, no template and no
 * category filter — the item is the message.
 *
 * @since 1.2.0
 */
final class Module implements ModuleInterface {

	/**
	 * Post meta: when the item was taken from the queue.
	 *
	 * A meta value rather than a post status. A status of our own does not
	 * appear in the editor or in Quick Edit without writing that interface too,
	 * and an item that went out should stay an ordinary published entry that
	 * can be edited and sent again.
	 *
	 * @var string
	 */
	public const SENT_META = '_mvweb_tg_draft_sent';

	/**
	 * Name of the lock held for the whole run.
	 *
	 * WP_Upgrader::create_lock() stores it as the option "{name}.lock" with
	 * INSERT IGNORE, which is atomic: of two runs started together exactly one
	 * gets the row. add_option() would not do — it is an upsert, and both runs
	 * would be told they had won.
	 *
	 * @var string
	 */
	private const LOCK = 'mvweb_tg_drafts';

	/**
	 * Seconds after which a lock is considered abandoned.
	 *
	 * @var int
	 */
	private const LOCK_TTL = 300;

	/**
	 * Seconds between two channels of the same item.
	 *
	 * @var int
	 */
	private const THROTTLE = 1;

	/**
	 * Module slug.
	 *
	 * @since 1.2.0
	 * @return string
	 */
	public static function slug() {
		return 'drafts';
	}

	/**
	 * Module name for the settings screen.
	 *
	 * @since 1.2.0
	 * @return string
	 */
	public static function label() {
		return __( 'Prepared posts to a Telegram channel on a schedule', 'mvweb-telegram-hub' );
	}

	/**
	 * Nothing beyond WordPress itself is needed.
	 *
	 * @since 1.2.0
	 * @return bool
	 */
	public static function requirements_met() {
		return true;
	}

	/**
	 * Never shown, because the requirements are always met.
	 *
	 * @since 1.2.0
	 * @return string
	 */
	public static function requirement_message() {
		return '';
	}

	/**
	 * Hook the post type, the schedule and the delivery bookkeeping.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public function register() {
		( new PostType() )->register();
		( new Schedule() )->register();
		( new Import() )->register();

		add_action( 'mvweb_tg_sent', array( $this, 'remember_message' ), 10, 3 );
	}

	/**
	 * Build the message for an item.
	 *
	 * @since 1.2.0
	 * @param int $object_id Item id.
	 * @return string|null Null when the item is gone or was taken out of the queue.
	 */
	public function build_message( $object_id ) {
		$post = get_post( absint( $object_id ) );

		if ( ! $post instanceof WP_Post || PostType::NAME !== $post->post_type || 'publish' !== $post->post_status ) {
			return null;
		}

		$text = Content::convert( wpautop( (string) $post->post_content ) );

		/**
		 * Filter a prepared post before it is sent.
		 *
		 * @since 1.2.0
		 * @param string   $text Message in Telegram HTML.
		 * @param \WP_Post $post Queue item.
		 */
		$text = (string) apply_filters( 'mvweb_tg_draft_message', $text, $post );

		$limit = 'photo' === Settings::post_photo_mode() && '' !== self::photo( $post )
			? Formatter::CAPTION_LIMIT
			: Formatter::SAFE_LIMIT;

		return Formatter::truncate( $text, $limit );
	}

	/**
	 * Take the next item and send it to every channel.
	 *
	 * The caller holds the lock (see lock()), so two cron runs that start at
	 * the same moment cannot both take the item at the head of the list. The
	 * item is marked as taken before its jobs are queued and unmarked again if
	 * not one of them could be queued, so a refusal of the queue does not lose
	 * it until the next round.
	 *
	 * @since 1.2.0
	 * @return int Item id that went out, zero when nothing did.
	 */
	public static function publish_next() {
		$channels = Settings::channels();

		if ( ! Settings::has_token() || array() === $channels ) {
			return 0;
		}

		$post = self::take_next();

		if ( ! $post instanceof WP_Post ) {
			return 0;
		}

		$photo  = self::photo( $post );
		$button = self::button( $post );
		$round  = time();
		$step   = 0;

		foreach ( $channels as $chat_id ) {
			// The round tells the queue's duplicate guard that a queue started
			// over is posting this text again on purpose.
			$payload = array(
				'module'    => self::slug(),
				'object_id' => (int) $post->ID,
				'chat_id'   => (string) $chat_id,
				'round'     => $round,
				'attempt'   => 1,
			);

			if ( '' !== $photo ) {
				$key             = 'photo' === Settings::post_photo_mode() ? 'photo' : 'preview';
				$payload[ $key ] = $photo;
			}

			if ( $button ) {
				$payload['button'] = $button;
			}

			if ( Dispatcher::schedule( $payload, $step * self::THROTTLE ) ) {
				++$step;
			}
		}

		if ( 0 === $step ) {
			delete_post_meta( $post->ID, self::SENT_META );

			return 0;
		}

		return (int) $post->ID;
	}

	/**
	 * How many items wait and how many already went out.
	 *
	 * @since 1.2.0
	 * @return array{waiting: int, sent: int}
	 */
	public static function counts() {
		$sent  = self::count_sent();
		$total = (int) wp_count_posts( PostType::NAME )->publish;

		return array(
			'waiting' => max( 0, $total - $sent ),
			'sent'    => $sent,
		);
	}

	/**
	 * Record the message id a channel gave back.
	 *
	 * Kept under the same key the article announcements use, so a later "edit
	 * what was sent" can treat both sources alike.
	 *
	 * @since 1.2.0
	 * @param array  $payload    Job payload that was delivered.
	 * @param string $chat_id    Channel that took it.
	 * @param int    $message_id Identifier Telegram answered with.
	 * @return void
	 */
	public function remember_message( $payload, $chat_id, $message_id ) {
		if ( ! is_array( $payload ) || self::slug() !== ( isset( $payload['module'] ) ? $payload['module'] : '' ) ) {
			return;
		}

		$post_id = isset( $payload['object_id'] ) ? absint( $payload['object_id'] ) : 0;

		if ( ! $post_id || '' === (string) $chat_id ) {
			return;
		}

		$sent = get_post_meta( $post_id, PostsModule::SENT_META, true );
		$sent = is_array( $sent ) ? $sent : array();

		$sent[ (string) $chat_id ] = absint( $message_id );

		update_post_meta( $post_id, PostsModule::SENT_META, $sent );
	}

	/**
	 * Pick the next item and mark it as taken.
	 *
	 * @since 1.2.0
	 * @return WP_Post|null
	 */
	private static function take_next() {
		$post = self::query_next();

		if ( ! $post && 'loop' === Settings::drafts_end() && self::count_sent() > 0 ) {
			// The meta key belongs to queue items alone, so clearing it for
			// every post is clearing it for the queue.
			delete_post_meta_by_key( self::SENT_META );

			$post = self::query_next();
		}

		if ( $post ) {
			update_post_meta( $post->ID, self::SENT_META, time() );
		}

		return $post;
	}

	/**
	 * First item not taken yet, in the chosen order.
	 *
	 * @since 1.2.0
	 * @return WP_Post|null
	 */
	private static function query_next() {
		$order = 'random' === Settings::drafts_order()
			? 'rand'
			: array(
				'menu_order' => 'ASC',
				'date'       => 'ASC',
				'ID'         => 'ASC',
			);

		$query = new WP_Query(
			array(
				'post_type'              => PostType::NAME,
				'post_status'            => 'publish',
				'posts_per_page'         => 1,
				'orderby'                => $order,
				'no_found_rows'          => true,
				'update_post_term_cache' => false,
				'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- a short list, and NOT EXISTS is the only way to ask "not taken yet".
					array(
						'key'     => self::SENT_META,
						'compare' => 'NOT EXISTS',
					),
				),
			)
		);

		return $query->posts ? $query->posts[0] : null;
	}

	/**
	 * Count published items that were already taken.
	 *
	 * @since 1.2.0
	 * @return int
	 */
	private static function count_sent() {
		$query = new WP_Query(
			array(
				'post_type'              => PostType::NAME,
				'post_status'            => 'publish',
				'posts_per_page'         => 1,
				'fields'                 => 'ids',
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
				'meta_query'             => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- counted on the settings screen only.
					array(
						'key'     => self::SENT_META,
						'compare' => 'EXISTS',
					),
				),
			)
		);

		return (int) $query->found_posts;
	}

	/**
	 * Take the run lock. One left behind by a crashed run expires by itself.
	 *
	 * @since 1.2.0
	 * @return bool
	 */
	public static function lock() {
		if ( ! class_exists( 'WP_Upgrader', false ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		}

		return \WP_Upgrader::create_lock( self::LOCK, self::LOCK_TTL );
	}

	/**
	 * Release the run lock.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function unlock() {
		\WP_Upgrader::release_lock( self::LOCK );
	}

	/**
	 * Address of the item's picture.
	 *
	 * The featured image first, in the registered "large" size for the same
	 * reason as for articles; then the address given in the item, which is how
	 * a picture arrives from an imported file without filling the media library.
	 *
	 * @since 1.2.0
	 * @param WP_Post $post Queue item.
	 * @return string Empty when there is none or the operator asked for none.
	 */
	private static function photo( WP_Post $post ) {
		if ( 'none' === Settings::post_photo_mode() ) {
			return '';
		}

		$thumbnail = get_post_thumbnail_id( $post );

		if ( $thumbnail ) {
			return (string) wp_get_attachment_image_url( $thumbnail, 'large' );
		}

		return (string) get_post_meta( $post->ID, PostType::IMAGE_META, true );
	}

	/**
	 * The item's link button, when it has both a label and an address.
	 *
	 * @since 1.2.0
	 * @param WP_Post $post Queue item.
	 * @return array{text: string, url: string}|array{}
	 */
	private static function button( WP_Post $post ) {
		$text = trim( (string) get_post_meta( $post->ID, PostType::BUTTON_TEXT_META, true ) );
		$url  = trim( (string) get_post_meta( $post->ID, PostType::BUTTON_URL_META, true ) );

		if ( '' === $text || '' === $url ) {
			return array();
		}

		return array(
			'text' => $text,
			'url'  => $url,
		);
	}
}
