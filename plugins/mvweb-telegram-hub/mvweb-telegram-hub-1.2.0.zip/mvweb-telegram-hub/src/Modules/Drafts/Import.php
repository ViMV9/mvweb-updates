<?php
/**
 * Filling the queue from a CSV file.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.2.0
 */

namespace MVweb\Telegram\Hub\Modules\Drafts;

use MVweb\Telegram\Hub\Admin\Actions;
use MVweb\Telegram\Hub\Admin\Page;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One file in, one prepared post per row.
 *
 * The upload follows the path WooCommerce takes for its product import:
 * is_uploaded_file(), then wp_handle_upload() with a list of allowed types,
 * then the content is read by the parser and the file removed. Not
 * media_handle_upload(): that creates an attachment, and the list would stay
 * behind in the media library as rubbish.
 *
 * Columns by position, so a file made by hand needs no header: text, picture
 * address, button label, button link. A first row that reads like a header is
 * skipped. Both separators are accepted — a comma, and the semicolon that a
 * spreadsheet saves in Russian locales — and a file saved in Windows-1251 is
 * converted rather than turned into question marks.
 *
 * @since 1.2.0
 */
final class Import {

	/**
	 * Admin-post action and nonce action.
	 *
	 * @var string
	 */
	public const ACTION = 'mvweb_tg_drafts_import';

	/**
	 * Most rows taken from one file.
	 *
	 * @var int
	 */
	private const MAX_ROWS = 500;

	/**
	 * Hook the handler.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public function register() {
		add_action( 'admin_post_' . self::ACTION, array( $this, 'handle' ) );
	}

	/**
	 * Take the uploaded file and add its rows to the end of the queue.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public function handle() {
		// The settings screen's own capability: the form lives there and the
		// result is shown there, so anybody else would land on a refusal.
		if ( ! current_user_can( Page::CAPABILITY ) ) {
			wp_die( esc_html__( 'You are not allowed to do that.', 'mvweb-telegram-hub' ), '', array( 'response' => 403 ) );
		}

		check_admin_referer( self::ACTION );

		$file = isset( $_FILES['mvweb_tg_drafts_file'] ) && is_array( $_FILES['mvweb_tg_drafts_file'] ) ? $_FILES['mvweb_tg_drafts_file'] : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- handed to wp_handle_upload(), which validates it.

		if ( empty( $file['tmp_name'] ) || ! is_uploaded_file( (string) $file['tmp_name'] ) ) {
			self::finish( 'error', __( 'Choose a CSV file first.', 'mvweb-telegram-hub' ) );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';

		$upload = wp_handle_upload(
			$file,
			array(
				'test_form' => false,
				'mimes'     => array(
					'csv' => 'text/csv',
					'txt' => 'text/plain',
				),
			)
		);

		if ( isset( $upload['error'] ) || empty( $upload['file'] ) ) {
			self::finish( 'error', __( 'The file was not accepted. Save the table as CSV (UTF-8) and try again.', 'mvweb-telegram-hub' ) );
		}

		$rows = self::read( (string) $upload['file'] );

		wp_delete_file( (string) $upload['file'] );

		$added = self::add( $rows );

		if ( ! $added ) {
			self::finish( 'warning', __( 'No posts were added: the file has no rows with text in the first column.', 'mvweb-telegram-hub' ) );
		}

		self::finish(
			'success',
			sprintf(
				/* translators: %d: number of posts added. */
				_n( '%d post added to the end of the queue.', '%d posts added to the end of the queue.', $added, 'mvweb-telegram-hub' ),
				$added
			)
		);
	}

	/**
	 * Read the rows of a CSV file.
	 *
	 * @since 1.2.0
	 * @param string $path File on disk, already validated by the upload.
	 * @return array<int, string[]>
	 */
	private static function read( $path ) {
		$raw = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- a local file wp_handle_upload() just wrote.

		if ( ! is_string( $raw ) || '' === $raw ) {
			return array();
		}

		// A spreadsheet saving "CSV UTF-8" puts a byte order mark in front.
		$raw = preg_replace( '/^\xEF\xBB\xBF/', '', $raw );

		if ( ! mb_check_encoding( $raw, 'UTF-8' ) ) {
			$raw = mb_convert_encoding( $raw, 'UTF-8', 'Windows-1251' );
		}

		$separator = self::separator( (string) strtok( $raw, "\n" ) );

		$stream = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- an in-memory buffer for fgetcsv().
		fwrite( $stream, $raw ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- same buffer.
		rewind( $stream );

		$rows  = array();
		$kept  = 0;
		$first = true;

		while ( $kept < self::MAX_ROWS ) {
			$row = fgetcsv( $stream, 0, $separator, '"', '' );

			if ( false === $row ) {
				break;
			}

			$row = array_map( 'strval', $row );

			// Checked before whole_text(): a header's second cell is a word,
			// not a link, and would otherwise be glued into a "post".
			if ( $first && self::is_header( $row ) ) {
				$first = false;
				continue;
			}

			$first  = false;
			$rows[] = self::whole_text( $row, $separator );
			++$kept;
		}

		fclose( $stream ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- same buffer.

		return $rows;
	}

	/**
	 * Separator of the file, judged by its first line.
	 *
	 * Quoted parts are left out of the count: a comma inside a text is part of
	 * the text. A semicolon outside quotes means a semicolon file — that is
	 * what a spreadsheet saves in Russian locales, and a comma file has no
	 * reason to carry a bare one. Anything else is read as comma-separated, and
	 * a one-column file with commas in its text is fine too, because every
	 * spreadsheet quotes such a cell.
	 *
	 * @since 1.2.0
	 * @param string $line First line of the file.
	 * @return string
	 */
	private static function separator( $line ) {
		$bare = (string) preg_replace( '/"[^"]*"/', '', $line );

		return false !== strpos( $bare, ';' ) ? ';' : ',';
	}

	/**
	 * Put a text that was split at its own commas back together.
	 *
	 * The second column is a picture address, so it is either empty or a
	 * link. When it is neither, the separator was part of the text — a
	 * one-column file written by hand, without quotes — and the row is one
	 * text again, exactly as it was in the file.
	 *
	 * @since 1.2.0
	 * @param string[] $row       Row as split.
	 * @param string   $separator Separator it was split at.
	 * @return string[]
	 */
	private static function whole_text( array $row, $separator ) {
		$picture = isset( $row[1] ) ? trim( $row[1] ) : '';

		if ( '' === $picture || preg_match( '#^https?://#i', $picture ) ) {
			return $row;
		}

		return array( implode( $separator, $row ) );
	}

	/**
	 * Whether a row is a header rather than a post.
	 *
	 * @since 1.2.0
	 * @param string[] $row First row of the file.
	 * @return bool
	 */
	private static function is_header( array $row ) {
		$cell = mb_strtolower( trim( isset( $row[0] ) ? $row[0] : '' ) );

		return in_array( $cell, array( 'text', 'текст', 'message', 'сообщение' ), true );
	}

	/**
	 * Create one published item per row, after the last one in the queue.
	 *
	 * @since 1.2.0
	 * @param array<int, string[]> $rows Rows read from the file.
	 * @return int Number of items created.
	 */
	private static function add( array $rows ) {
		$order = PostType::last_order();
		$added = 0;

		foreach ( $rows as $row ) {
			$text = wp_kses_post( trim( isset( $row[0] ) ? $row[0] : '' ) );

			if ( '' === trim( wp_strip_all_tags( $text ) ) ) {
				continue;
			}

			$post_id = wp_insert_post(
				wp_slash(
					array(
						'post_type'    => PostType::NAME,
						'post_status'  => 'publish',
						'post_content' => $text,
						'menu_order'   => ++$order,
					)
				),
				true
			);

			if ( is_wp_error( $post_id ) ) {
				continue;
			}

			PostType::store(
				$post_id,
				isset( $row[1] ) ? $row[1] : '',
				isset( $row[2] ) ? $row[2] : '',
				isset( $row[3] ) ? $row[3] : ''
			);

			++$added;
		}

		return $added;
	}

	/**
	 * Report back on the Prepared posts tab.
	 *
	 * @since 1.2.0
	 * @param string $type    Notice type.
	 * @param string $message Notice text.
	 * @return void
	 */
	private static function finish( $type, $message ) {
		Actions::notify(
			array(
				'type'    => $type,
				'message' => $message,
				'rows'    => array(),
			),
			'drafts'
		);
	}
}
