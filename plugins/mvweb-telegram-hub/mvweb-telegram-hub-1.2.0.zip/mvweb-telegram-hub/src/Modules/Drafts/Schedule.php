<?php
/**
 * When the next prepared post goes out.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.2.0
 */

namespace MVweb\Telegram\Hub\Modules\Drafts;

use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * One WP-Cron event at a time, always pointing at the next slot.
 *
 * Not a recurring event: WordPress schedules repeat by interval from the first
 * run, and "10:00 and 18:00 every day" is not an interval. Each run publishes
 * one item and books the next slot from the list.
 *
 * Accuracy is that of WP-Cron, and the screen says so: at the time given or on
 * the first visit to the site after it. Action Scheduler would not do better —
 * it is driven by the same WP-Cron.
 *
 * Times are read in the site's time zone through current_datetime(), never
 * with strtotime() or sums over gmt_offset, so a change to or from summer
 * time moves nothing.
 *
 * @since 1.2.0
 */
final class Schedule {

	/**
	 * Cron hook of the run.
	 *
	 * @var string
	 */
	public const HOOK = 'mvweb_tg_drafts_tick';

	/**
	 * Option with the time of the last run.
	 *
	 * @var string
	 */
	public const LAST_OPTION = 'mvweb_tg_drafts_last';

	/**
	 * Seconds inside which a second run counts as the same run.
	 *
	 * WP-Cron can start the same event twice when two visits arrive together.
	 * The lock keeps the two apart; this stops the second from publishing
	 * another item once the first has finished.
	 *
	 * @var int
	 */
	private const SAME_RUN = 60;

	/**
	 * Hook the run and keep the next slot booked.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public function register() {
		add_action( self::HOOK, array( $this, 'run' ) );
		add_action( 'update_option_' . Settings::OPTION, array( $this, 'reschedule' ), 10, 0 );
		add_action( 'add_option_' . Settings::OPTION, array( $this, 'reschedule' ), 10, 0 );

		// The storefront never needs to check: the admin and cron do it often
		// enough to repair a lost event within minutes.
		if ( is_admin() || wp_doing_cron() ) {
			self::ensure();
		}
	}

	/**
	 * Publish one item and book the next slot.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public function run() {
		// Another run holds the lock and books the next slot itself.
		if ( ! Module::lock() ) {
			return;
		}

		try {
			$last = (int) get_option( self::LAST_OPTION, 0 );

			if ( ! $last || time() - $last >= self::SAME_RUN ) {
				update_option( self::LAST_OPTION, time(), false );

				Module::publish_next();
			}
		} finally {
			Module::unlock();
		}

		self::ensure();
	}

	/**
	 * Drop the booked slot and book it again from the saved times.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public function reschedule() {
		Settings::flush_cache();

		// A slot that is due but has not run yet, on a quiet site, is left
		// alone: rebooking from the times would skip it to the next one. The
		// run books the following slot itself.
		$booked = wp_next_scheduled( self::HOOK );

		if ( $booked && $booked <= time() && Settings::module_enabled( Module::slug() ) ) {
			return;
		}

		wp_clear_scheduled_hook( self::HOOK );

		self::ensure();
	}

	/**
	 * Book the next slot unless one is booked already.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function ensure() {
		if ( ! Settings::module_enabled( Module::slug() ) || wp_next_scheduled( self::HOOK ) ) {
			return;
		}

		$next = self::next_slot();

		if ( $next ) {
			wp_schedule_single_event( $next, self::HOOK );
		}
	}

	/**
	 * When the booked run will happen.
	 *
	 * @since 1.2.0
	 * @return int Unix time, zero when nothing is booked.
	 */
	public static function next_run() {
		return (int) wp_next_scheduled( self::HOOK );
	}

	/**
	 * The nearest of the saved times that is still ahead.
	 *
	 * @since 1.2.0
	 * @return int Unix time, zero when no time is saved.
	 */
	public static function next_slot() {
		$now  = current_datetime();
		$next = 0;

		foreach ( Settings::drafts_times() as $time ) {
			list( $hour, $minute ) = array_map( 'intval', explode( ':', $time ) );

			$slot = $now->setTime( $hour, $minute );

			if ( $slot <= $now ) {
				$slot = $slot->modify( '+1 day' );
			}

			$stamp = $slot->getTimestamp();

			if ( ! $next || $stamp < $next ) {
				$next = $stamp;
			}
		}

		return $next;
	}
}
