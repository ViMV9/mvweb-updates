<?php
/**
 * The list of prepared posts in the admin.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.2.0
 */

namespace MVweb\Telegram\Hub\Modules\Drafts;

use WP_Post;
use WP_Query;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A private post type, so the list costs nothing to build.
 *
 * WordPress gives the list, search, paging, the editor, drafts, the trash, and
 * ordering through menu_order for free. Not a table of our own, which would
 * add nothing over this for a few hundred short texts and lose the interface,
 * and not an option, which loses autoloading past 150 KB and has no paging.
 *
 * The classic editor, not the block editor: the text ends up as a handful of
 * Telegram tags, and a block editor full of layout that the channel will never
 * show would only promise what does not arrive.
 *
 * @since 1.2.0
 */
final class PostType {

	/**
	 * Post type name.
	 *
	 * @var string
	 */
	public const NAME = 'mvweb_tg_draft';

	/**
	 * Post meta: address of a picture given instead of a featured image.
	 *
	 * @var string
	 */
	public const IMAGE_META = '_mvweb_tg_draft_image';

	/**
	 * Post meta: label of the link button.
	 *
	 * @var string
	 */
	public const BUTTON_TEXT_META = '_mvweb_tg_draft_button_text';

	/**
	 * Post meta: address of the link button.
	 *
	 * @var string
	 */
	public const BUTTON_URL_META = '_mvweb_tg_draft_button_url';

	/**
	 * Nonce action and field name of the item's box.
	 *
	 * @var string
	 */
	private const NONCE = 'mvweb_tg_draft_nonce';

	/**
	 * Register the type and its screens.
	 *
	 * Called from boot, which itself runs on init, so the type is registered
	 * straight away rather than on a hook that is already firing.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public function register() {
		self::register_type();

		add_filter( 'wp_insert_post_data', array( $this, 'fill_defaults' ), 10, 2 );
		add_action( 'add_meta_boxes_' . self::NAME, array( $this, 'add_box' ) );
		add_action( 'save_post_' . self::NAME, array( $this, 'save' ), 10, 2 );
		add_filter( 'manage_' . self::NAME . '_posts_columns', array( $this, 'columns' ) );
		add_action( 'manage_' . self::NAME . '_posts_custom_column', array( $this, 'column' ), 10, 2 );
		add_action( 'pre_get_posts', array( $this, 'list_order' ) );
	}

	/**
	 * Register the post type.
	 *
	 * Capabilities of pages: an item goes to a public channel in the name of
	 * the site, which is an editor's call, not an author's.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public static function register_type() {
		register_post_type(
			self::NAME,
			array(
				'labels'          => array(
					'name'               => __( 'Telegram queue', 'mvweb-telegram-hub' ),
					'singular_name'      => __( 'Prepared post', 'mvweb-telegram-hub' ),
					'menu_name'          => __( 'Telegram queue', 'mvweb-telegram-hub' ),
					'all_items'          => __( 'Telegram queue', 'mvweb-telegram-hub' ),
					'add_new'            => __( 'Add post', 'mvweb-telegram-hub' ),
					'add_new_item'       => __( 'New prepared post', 'mvweb-telegram-hub' ),
					'edit_item'          => __( 'Edit prepared post', 'mvweb-telegram-hub' ),
					'new_item'           => __( 'New prepared post', 'mvweb-telegram-hub' ),
					'search_items'       => __( 'Search prepared posts', 'mvweb-telegram-hub' ),
					'not_found'          => __( 'The queue is empty.', 'mvweb-telegram-hub' ),
					'not_found_in_trash' => __( 'Nothing in the trash.', 'mvweb-telegram-hub' ),
				),
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => 'mvweb-hub',
				'show_in_rest'    => false,
				'capability_type' => 'page',
				'map_meta_cap'    => true,
				'hierarchical'    => false,
				'supports'        => array( 'title', 'editor', 'thumbnail', 'page-attributes' ),
				'rewrite'         => false,
				'query_var'       => false,
			)
		);
	}

	/**
	 * Fill in what an item is saved without: its place and its title.
	 *
	 * A new item goes to the end of the queue. The editor creates it as an
	 * auto-draft with order 0, which in "as listed" mode would put a fact typed
	 * today ahead of a hundred imported ones; it gets the next number instead,
	 * and the Order field shows it.
	 *
	 * The title never reaches Telegram; it is only what the list shows. Typing
	 * one for each of a hundred facts is busywork, and "(no title)" a hundred
	 * times makes the list useless.
	 *
	 * @since 1.2.0
	 * @param array $data    Post data about to be saved, slashed.
	 * @param array $postarr Raw post array.
	 * @return array
	 */
	public function fill_defaults( $data, $postarr ) {
		unset( $postarr );

		if ( self::NAME !== $data['post_type'] ) {
			return $data;
		}

		if ( 'auto-draft' === $data['post_status'] && 0 === (int) $data['menu_order'] ) {
			$data['menu_order'] = self::last_order() + 1;
		}

		if ( '' !== trim( (string) $data['post_title'] ) ) {
			return $data;
		}

		$words = wp_trim_words( wp_strip_all_tags( wp_unslash( (string) $data['post_content'] ) ), 10, '…' );

		if ( '' !== $words ) {
			$data['post_title'] = wp_slash( $words );
		}

		return $data;
	}

	/**
	 * Add the box with the picture address and the button.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public function add_box() {
		add_meta_box(
			'mvweb-tg-draft',
			__( 'Telegram', 'mvweb-telegram-hub' ),
			array( $this, 'render' ),
			self::NAME,
			'normal',
			'high'
		);
	}

	/**
	 * Print the box.
	 *
	 * @since 1.2.0
	 * @param WP_Post $post Item being edited.
	 * @return void
	 */
	public function render( $post ) {
		wp_nonce_field( self::NONCE, self::NONCE );

		$fields = array(
			array( 'mvweb_tg_draft_image', self::IMAGE_META, __( 'Picture address', 'mvweb-telegram-hub' ), 'url', __( 'Used when the post has no featured image. A direct link to a JPG or PNG, up to 5 MB.', 'mvweb-telegram-hub' ) ),
			array( 'mvweb_tg_draft_button_text', self::BUTTON_TEXT_META, __( 'Button label', 'mvweb-telegram-hub' ), 'text', '' ),
			array( 'mvweb_tg_draft_button_url', self::BUTTON_URL_META, __( 'Button link', 'mvweb-telegram-hub' ), 'url', __( 'The button appears under the post when both the label and the link are filled in.', 'mvweb-telegram-hub' ) ),
		);

		echo '<p class="description">' . esc_html__( 'The text above goes to every channel on the Channels tab. Bold, italics, lists, quotes and links are kept; anything else is dropped, because Telegram does not show it.', 'mvweb-telegram-hub' ) . '</p>';
		echo '<table class="form-table" role="presentation"><tbody>';

		foreach ( $fields as $field ) {
			list( $name, $meta, $label, $type, $hint ) = $field;

			echo '<tr><th scope="row"><label for="' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label></th><td>';
			echo '<input type="' . esc_attr( $type ) . '" class="regular-text" id="' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) get_post_meta( $post->ID, $meta, true ) ) . '"' . ( 'text' === $type ? ' maxlength="64"' : '' ) . '>';

			if ( '' !== $hint ) {
				echo '<p class="description">' . esc_html( $hint ) . '</p>';
			}

			echo '</td></tr>';
		}

		echo '</tbody></table>';

		$sent = (int) get_post_meta( $post->ID, Module::SENT_META, true );

		if ( $sent ) {
			echo '<p>' . esc_html(
				sprintf(
					/* translators: %s: date and time. */
					__( 'Already published on %s. It goes out again only when the queue starts over.', 'mvweb-telegram-hub' ),
					wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $sent )
				)
			) . '</p>';
		}
	}

	/**
	 * Store the box.
	 *
	 * @since 1.2.0
	 * @param int     $post_id Item id.
	 * @param WP_Post $post    Item.
	 * @return void
	 */
	public function save( $post_id, $post ) {
		if ( ! isset( $_POST[ self::NONCE ] ) || ! wp_verify_nonce( sanitize_key( wp_unslash( $_POST[ self::NONCE ] ) ), self::NONCE ) ) {
			return;
		}

		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! $post instanceof WP_Post || ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		self::store(
			$post_id,
			isset( $_POST['mvweb_tg_draft_image'] ) ? wp_unslash( $_POST['mvweb_tg_draft_image'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised in store().
			isset( $_POST['mvweb_tg_draft_button_text'] ) ? wp_unslash( $_POST['mvweb_tg_draft_button_text'] ) : '', // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised in store().
			isset( $_POST['mvweb_tg_draft_button_url'] ) ? wp_unslash( $_POST['mvweb_tg_draft_button_url'] ) : '' // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitised in store().
		);
	}

	/**
	 * Write the picture and button of an item, dropping anything empty.
	 *
	 * Shared by the edit screen and the import, so a file cannot put into an
	 * item what the form would have refused.
	 *
	 * @since 1.2.0
	 * @param int    $post_id     Item id.
	 * @param string $image       Picture address.
	 * @param string $button_text Button label.
	 * @param string $button_url  Button address.
	 * @return void
	 */
	public static function store( $post_id, $image, $button_text, $button_url ) {
		$values = array(
			self::IMAGE_META       => self::web_url( $image ),
			self::BUTTON_TEXT_META => mb_substr( sanitize_text_field( (string) $button_text ), 0, 64 ),
			self::BUTTON_URL_META  => self::web_url( $button_url ),
		);

		foreach ( $values as $key => $value ) {
			if ( '' === $value ) {
				delete_post_meta( $post_id, $key );
				continue;
			}

			// update_post_meta() unslashes what it is given, and the value is
			// already unslashed: without this a backslash in a label is lost.
			update_post_meta( $post_id, $key, wp_slash( $value ) );
		}
	}

	/**
	 * Highest order number in the queue.
	 *
	 * @since 1.2.0
	 * @return int
	 */
	public static function last_order() {
		$last = get_posts(
			array(
				'post_type'              => self::NAME,
				'post_status'            => 'any',
				'posts_per_page'         => 1,
				'orderby'                => 'menu_order',
				'order'                  => 'DESC',
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		return $last ? (int) get_post_field( 'menu_order', $last[0] ) : 0;
	}

	/**
	 * Columns of the list: the order number and whether the item went out.
	 *
	 * @since 1.2.0
	 * @param array $columns Default columns.
	 * @return array
	 */
	public function columns( $columns ) {
		$date = isset( $columns['date'] ) ? $columns['date'] : null;
		unset( $columns['date'] );

		$columns['mvweb_tg_order']  = __( 'Order', 'mvweb-telegram-hub' );
		$columns['mvweb_tg_status'] = __( 'In the channel', 'mvweb-telegram-hub' );

		if ( null !== $date ) {
			$columns['date'] = $date;
		}

		return $columns;
	}

	/**
	 * Print one cell of a custom column.
	 *
	 * @since 1.2.0
	 * @param string $column  Column key.
	 * @param int    $post_id Item id.
	 * @return void
	 */
	public function column( $column, $post_id ) {
		if ( 'mvweb_tg_order' === $column ) {
			echo esc_html( (string) get_post_field( 'menu_order', $post_id ) );
			return;
		}

		if ( 'mvweb_tg_status' !== $column ) {
			return;
		}

		$sent = (int) get_post_meta( $post_id, Module::SENT_META, true );

		echo $sent
			? esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $sent ) )
			: esc_html__( 'Waiting', 'mvweb-telegram-hub' );
	}

	/**
	 * Show the list in the order it goes out.
	 *
	 * Only when nobody asked for another order by clicking a column header.
	 *
	 * @since 1.2.0
	 * @param WP_Query $query Query being prepared.
	 * @return void
	 */
	public function list_order( $query ) {
		if ( ! is_admin() || ! $query->is_main_query() || self::NAME !== $query->get( 'post_type' ) || $query->get( 'orderby' ) ) {
			return;
		}

		$query->set(
			'orderby',
			array(
				'menu_order' => 'ASC',
				'date'       => 'ASC',
			)
		);
	}

	/**
	 * Keep an address only when it is a web address.
	 *
	 * The site never fetches it — Telegram does — so there is no request of our
	 * own to protect, and wp_http_validate_url() would cost a DNS lookup per
	 * address, a thousand of them for a full import.
	 *
	 * @since 1.2.0
	 * @param string $url Address as given.
	 * @return string Empty when it is not http or https.
	 */
	private static function web_url( $url ) {
		return esc_url_raw( trim( (string) $url ), array( 'http', 'https' ) );
	}
}
