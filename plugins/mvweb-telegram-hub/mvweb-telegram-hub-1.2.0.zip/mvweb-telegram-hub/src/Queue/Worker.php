<?php
/**
 * Executes queued Telegram deliveries.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Queue;

use MVweb\Telegram\Hub\Link\Binding;
use MVweb\Telegram\Hub\Log\Repository;
use MVweb\Telegram\Hub\Modules\Registry;
use MVweb\Telegram\Hub\Telegram\Client;
use MVweb\Telegram\Hub\Telegram\ErrorHint;
use MVweb\Telegram\Hub\Telegram\Formatter;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sends one queued message and decides whether to try again.
 *
 * @since 1.0.0
 */
final class Worker {

	/**
	 * Pause between two attempts, in seconds.
	 *
	 * Five minutes: short enough that an order reaches the shop soon after the
	 * connection comes back, long enough that a day of retries stays a few
	 * hundred cheap jobs.
	 *
	 * @var int
	 */
	private const RETRY_INTERVAL = 300;

	/**
	 * How long to keep trying, in seconds.
	 *
	 * A host that cannot reach Telegram for longer than a day has an outage of
	 * its own, and an order announced a day late is worth little to the shop;
	 * the email arrived long before. The job then gives up and says so in the
	 * log instead of circling for ever.
	 *
	 * @var int
	 */
	private const RETRY_WINDOW = DAY_IN_SECONDS;

	/**
	 * Every how many failed attempts a retry is written to the log.
	 *
	 * Twelve attempts five minutes apart is one row an hour. The first failure,
	 * the hourly rows, the delivery and the final refusal are enough to see
	 * what happened; all 288 attempts would bury every other row.
	 *
	 * @var int
	 */
	private const LOG_EVERY = 12;

	/**
	 * How long a delivered message is remembered, in seconds.
	 *
	 * A day of retries and an hour of slack: no job that could still repeat
	 * this message outlives the record that it went through.
	 *
	 * @var int
	 */
	private const SENT_TTL = DAY_IN_SECONDS + HOUR_IN_SECONDS;

	/**
	 * Seconds a delivery holds its lock.
	 *
	 * Longer than the request timeout, so a slow send cannot lose the lock to
	 * a second copy halfway through; short enough that a crashed run does not
	 * block that message for long.
	 *
	 * @var int
	 */
	private const SEND_LOCK_TTL = 120;

	/**
	 * Hook the queue handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register() {
		add_action( Dispatcher::HOOK, array( $this, 'run' ), 10, 1 );
	}

	/**
	 * Handle one queued job.
	 *
	 * @since 1.0.0
	 * @param array $payload Job payload written by the dispatcher.
	 * @return void
	 */
	public function run( $payload ) {
		if ( ! is_array( $payload ) ) {
			return;
		}

		$module_slug = isset( $payload['module'] ) ? (string) $payload['module'] : '';
		$object_id   = isset( $payload['object_id'] ) ? absint( $payload['object_id'] ) : 0;
		$user_id     = isset( $payload['user_id'] ) ? absint( $payload['user_id'] ) : 0;
		$chat_id     = isset( $payload['chat_id'] ) ? (string) $payload['chat_id'] : '';
		$text        = isset( $payload['text'] ) ? (string) $payload['text'] : '';
		$attempt     = isset( $payload['attempt'] ) ? max( 1, absint( $payload['attempt'] ) ) : 1;

		/*
		 * Operator jobs name their recipient, because it comes from a settings
		 * list that has nothing to do with the order. Customer jobs leave it out
		 * and have it looked up here, at delivery: a job can sit in the queue for
		 * twenty minutes across its retries, and somebody who unsubscribed in
		 * that time must not receive the tail of it.
		 */
		if ( '' === $chat_id ) {
			$chat_id = '' !== $text
				? Binding::of_user( $user_id )
				: (string) apply_filters( 'mvweb_tg_resolve_chat', '', $module_slug, $object_id );
		}

		if ( '' === $chat_id ) {
			return;
		}

		if ( '' === $text ) {
			if ( ! $object_id ) {
				return;
			}

			$module = Registry::get( $module_slug );
			if ( ! $module ) {
				return;
			}

			$text = (string) $module->build_message( $object_id );
			if ( '' === $text ) {
				// The order is gone or the template renders empty — nothing to send.
				return;
			}
		}

		/*
		 * The same message to the same chat goes out once. "The same" is the
		 * finished text for this object and this recipient, so it covers every
		 * way a second copy could appear: two jobs for one order, a job Action
		 * Scheduler ran twice, a resend by hand. A record of each delivery is
		 * kept for longer than any retry can run, and the send itself happens
		 * under a lock, so two copies running at once cannot both get through.
		 */
		$sent_key = self::sent_key( $chat_id, $text, $payload );

		if ( ! self::lock( $sent_key ) ) {
			return;
		}

		try {
			// Read under the lock: a copy that finished a moment ago has
			// already written the record and let the lock go.
			if ( false !== get_transient( $sent_key ) ) {
				return;
			}

			$response = $this->send( new Client(), $chat_id, $text, $payload );

			if ( ! empty( $response['ok'] ) ) {
				set_transient( $sent_key, time(), self::SENT_TTL );
			}
		} finally {
			\WP_Upgrader::release_lock( $sent_key );
		}

		if ( ! empty( $response['ok'] ) ) {
			// After failed attempts the log shows how it ended, so nobody has to
			// wonder whether the order from the hour without Telegram arrived.
			if ( $attempt > 1 ) {
				Repository::add(
					array(
						'module'        => $module_slug,
						'object_id'     => $object_id,
						'chat_id'       => $chat_id,
						'attempt'       => $attempt,
						'status'        => Repository::STATUS_DELIVERED,
						'error_code'    => 0,
						'error_message' => '',
					)
				);
			}

			/**
			 * Fires after a message has been accepted by Telegram.
			 *
			 * The message id is worth having for anything that may later want
			 * to edit or remove what it sent: Telegram puts no time limit on
			 * editing a message of your own, and the id is the only way back
			 * to it. Nothing in the queue needs it, so it is handed over
			 * rather than stored here.
			 *
			 * @since 1.1.0
			 * @param array  $payload    Job payload that was delivered.
			 * @param string $chat_id    Recipient that took it.
			 * @param int    $message_id Identifier Telegram answered with.
			 */
			do_action(
				'mvweb_tg_sent',
				$payload,
				$chat_id,
				isset( $response['result']['message_id'] ) ? (int) $response['result']['message_id'] : 0
			);

			return;
		}

		$this->handle_failure( $payload, $attempt, $response, $chat_id );
	}

	/**
	 * Send one job the way its payload asks for.
	 *
	 * Three shapes, and the difference between them is where the picture goes.
	 * Any of them can carry a link button under it.
	 * A photo carries the text as its caption and is capped at 1024 characters;
	 * a link preview keeps all 4096 and puts the image above the text, which is
	 * what an article in a channel wants. Plain text is everything else.
	 *
	 * @since 1.1.0
	 * @param Client $client  Configured API client.
	 * @param string $chat_id Recipient.
	 * @param string $text    Message in Telegram HTML.
	 * @param array  $payload Job payload.
	 * @return array Normalised response.
	 */
	private function send( Client $client, $chat_id, $text, array $payload ) {
		$photo  = isset( $payload['photo'] ) ? (string) $payload['photo'] : '';
		$button = isset( $payload['button'] ) && is_array( $payload['button'] ) ? $payload['button'] : array();

		if ( '' !== $photo ) {
			// Only here is it known that the text is a caption, and a caption is
			// a quarter of a message. Cutting it anywhere earlier would be a
			// guess about a picture that may have changed since.
			return $client->send_photo( $chat_id, $photo, Formatter::truncate( $text, Formatter::CAPTION_LIMIT ), $button );
		}

		$preview = isset( $payload['preview'] ) ? (string) $payload['preview'] : '';

		if ( '' === $preview ) {
			return $client->send_message( $chat_id, $text, array(), $button );
		}

		return $client->send_message(
			$chat_id,
			$text,
			array(
				'url'                => $preview,
				'prefer_large_media' => true,
				'show_above_text'    => true,
			),
			$button
		);
	}

	/**
	 * Log a failed attempt and re-queue it when that can help.
	 *
	 * @since 1.0.0
	 * @param array  $payload  Original job payload.
	 * @param int    $attempt  Attempt number that just failed.
	 * @param array  $response Normalised client response.
	 * @param string $chat_id  Recipient this attempt was addressed to.
	 * @return void
	 */
	private function handle_failure( array $payload, $attempt, array $response, $chat_id ) {
		$retryable  = ! empty( $response['retryable'] );
		$will_retry = $retryable && $attempt < self::max_attempts();

		if ( 1 === $attempt || ! $will_retry || 0 === $attempt % self::LOG_EVERY ) {
			Repository::add(
				array(
					'module'        => isset( $payload['module'] ) ? $payload['module'] : '',
					'object_id'     => isset( $payload['object_id'] ) ? $payload['object_id'] : 0,
					'chat_id'       => $chat_id,
					'attempt'       => $attempt,
					'status'        => $will_retry ? Repository::STATUS_RETRY : Repository::STATUS_FAILED,
					'error_code'    => isset( $response['error_code'] ) ? $response['error_code'] : 0,
					'error_message' => isset( $response['description'] ) ? $response['description'] : '',
				)
			);
		}

		/*
		 * A customer who blocked the bot would otherwise keep producing a failed
		 * row on every status change, for ever: nothing else ever tells us the
		 * chat is dead if they place no further orders. Matched on Telegram's own
		 * wording and not on the bare 403, so a proxy or a WAF answering in its
		 * place cannot take a live binding down. Operator recipients live in the
		 * settings list and are not touched by this.
		 */
		if ( ErrorHint::is_dead_chat(
			isset( $response['error_code'] ) ? $response['error_code'] : 0,
			isset( $response['description'] ) ? $response['description'] : ''
		) ) {
			Binding::unbind_chat( $chat_id );
		}

		if ( ! $will_retry ) {
			return;
		}

		// Telegram knows better than we do how long it wants us to wait.
		$delay = max( self::RETRY_INTERVAL, (int) ( $response['retry_after'] ?? 0 ) );

		$payload['attempt'] = $attempt + 1;

		Dispatcher::schedule( $payload, $delay );
	}

	/**
	 * Most attempts one job gets: the first one and a day of retries.
	 *
	 * Retries are the same message to the same chat, not new messages, so a
	 * job that keeps failing never produces a second copy. The exception is a
	 * timeout after the request left: Telegram may have taken it, and there is
	 * no way to ask. Sending again then risks a duplicate, which beats losing
	 * an order.
	 *
	 * @since 1.2.0
	 * @return int
	 */
	private static function max_attempts() {
		return 1 + intdiv( self::RETRY_WINDOW, self::RETRY_INTERVAL );
	}

	/**
	 * Name of the record that a message reached a chat.
	 *
	 * Built from what makes a message the same message: the object, the
	 * recipient and the finished text. A customer hearing that the order moved
	 * on gets a different text for each status, so each status still arrives.
	 * A queued channel post carries the round it was taken in, so a queue that
	 * starts over may post the same text again on purpose; a message handed
	 * over by other code carries the moment it was handed over, so each call
	 * is a message of its own.
	 *
	 * @since 1.2.0
	 * @param string $chat_id Recipient.
	 * @param string $text    Message in Telegram HTML.
	 * @param array  $payload Job payload.
	 * @return string Transient name.
	 */
	private static function sent_key( $chat_id, $text, array $payload ) {
		return 'mvweb_tg_sent_' . md5(
			implode(
				'|',
				array(
					isset( $payload['module'] ) ? (string) $payload['module'] : '',
					isset( $payload['object_id'] ) ? (string) absint( $payload['object_id'] ) : '0',
					isset( $payload['user_id'] ) ? (string) absint( $payload['user_id'] ) : '0',
					isset( $payload['round'] ) ? (string) absint( $payload['round'] ) : '',
					(string) $chat_id,
					(string) $text,
				)
			)
		);
	}

	/**
	 * Take the lock for one message.
	 *
	 * WP_Upgrader::create_lock() writes the lock with INSERT IGNORE, so of two
	 * runs that reach this together exactly one gets it.
	 *
	 * @since 1.2.0
	 * @param string $name Lock name.
	 * @return bool
	 */
	private static function lock( $name ) {
		if ( ! class_exists( 'WP_Upgrader', false ) ) {
			require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
		}

		return \WP_Upgrader::create_lock( $name, self::SEND_LOCK_TTL );
	}
}
