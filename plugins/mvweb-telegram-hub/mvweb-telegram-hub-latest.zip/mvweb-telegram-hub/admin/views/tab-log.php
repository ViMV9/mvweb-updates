<?php
/**
 * Log tab: retention, the failure list and a way to empty it.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

use MVweb\Telegram\Hub\Admin\Page;
use MVweb\Telegram\Hub\Log\Repository;
use MVweb\Telegram\Hub\Settings;
use MVweb\Telegram\Hub\Telegram\ErrorHint;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tg_option   = Settings::OPTION;
$mvweb_tg_days     = (int) Settings::get( 'log_days', 30 );
$mvweb_tg_per_page = 20;

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only filtering of an admin list.
$mvweb_tg_page     = isset( $_GET['log_page'] ) ? max( 1, absint( wp_unslash( $_GET['log_page'] ) ) ) : 1;
$mvweb_tg_order_id = isset( $_GET['log_order'] ) ? absint( wp_unslash( $_GET['log_order'] ) ) : 0;
$mvweb_tg_code     = isset( $_GET['log_code'] ) ? absint( wp_unslash( $_GET['log_code'] ) ) : 0;
// phpcs:enable WordPress.Security.NonceVerification.Recommended

$mvweb_tg_filters = array(
	'order_id'   => $mvweb_tg_order_id,
	'error_code' => $mvweb_tg_code,
);

$mvweb_tg_total    = Repository::count( $mvweb_tg_filters );
$mvweb_tg_rows     = Repository::query(
	$mvweb_tg_filters + array(
		'per_page' => $mvweb_tg_per_page,
		'page'     => $mvweb_tg_page,
	)
);
$mvweb_tg_pages    = (int) ceil( $mvweb_tg_total / $mvweb_tg_per_page );
$mvweb_tg_all_url  = admin_url( 'admin.php?page=' . MVWEB_TG_SLUG . '&tab=log' );
$mvweb_tg_codes    = Repository::error_codes();
$mvweb_tg_filtered = $mvweb_tg_order_id || $mvweb_tg_code;
?>

<form id="mvweb-tg-form-log" method="post" action="options.php">
	<?php settings_fields( Page::GROUP ); ?>
	<?php Page::referer_field( 'log' ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Retention', 'mvweb-telegram-hub' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'The log only records deliveries that failed or had to be retried. Successful notifications are not written down, so an empty page here is good news.', 'mvweb-telegram-hub' ); ?>
		</p>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-log-days" class="mvweb-form-row__label">
				<?php esc_html_e( 'Keep entries for', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'Older entries are removed automatically once a day, so the log cannot grow endlessly.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
					id="mvweb-tg-log-days"
					name="<?php echo esc_attr( $mvweb_tg_option ); ?>[log_days]"
					class="mvweb-input mvweb-tg-narrow"
					value="<?php echo esc_attr( (string) $mvweb_tg_days ); ?>"
					min="1"
					max="365"
					step="1">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Days.', 'mvweb-telegram-hub' ); ?>
				</p>
			</div>
		</div>
	</div>

</form>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Failed deliveries', 'mvweb-telegram-hub' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Every line is one notification that did not reach one recipient. The last column says what Telegram answered and what to do about it.', 'mvweb-telegram-hub' ); ?>
	</p>

	<?php if ( $mvweb_tg_codes || $mvweb_tg_filtered ) : ?>
		<div class="mvweb-toolbar mvweb-tg-actions">
			<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
				<input type="hidden" name="page" value="<?php echo esc_attr( MVWEB_TG_SLUG ); ?>">
				<input type="hidden" name="tab" value="log">

				<label for="mvweb-tg-log-code" class="screen-reader-text">
					<?php esc_html_e( 'Error code', 'mvweb-telegram-hub' ); ?>
				</label>
				<select id="mvweb-tg-log-code" name="log_code" class="mvweb-select">
					<option value="0"><?php esc_html_e( 'Any error code', 'mvweb-telegram-hub' ); ?></option>
					<?php foreach ( $mvweb_tg_codes as $mvweb_tg_code_option ) : ?>
						<option value="<?php echo esc_attr( (string) $mvweb_tg_code_option ); ?>" <?php selected( $mvweb_tg_code, $mvweb_tg_code_option ); ?>>
							<?php echo esc_html( (string) $mvweb_tg_code_option ); ?>
						</option>
					<?php endforeach; ?>
				</select>

				<?php if ( $mvweb_tg_order_id ) : ?>
					<input type="hidden" name="log_order" value="<?php echo esc_attr( (string) $mvweb_tg_order_id ); ?>">
				<?php endif; ?>

				<button type="submit" class="mvweb-btn"><?php esc_html_e( 'Filter', 'mvweb-telegram-hub' ); ?></button>
			</form>

			<?php if ( $mvweb_tg_filtered ) : ?>
				<a class="mvweb-btn mvweb-btn--ghost" href="<?php echo esc_url( $mvweb_tg_all_url ); ?>">
					<?php esc_html_e( 'Show all', 'mvweb-telegram-hub' ); ?>
				</a>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<?php if ( $mvweb_tg_order_id ) : ?>
		<p class="mvweb-block__sub">
			<?php
			printf(
				/* translators: %d: order number. */
				esc_html__( 'Filtered by order #%d.', 'mvweb-telegram-hub' ),
				(int) $mvweb_tg_order_id
			);
			?>
		</p>
	<?php endif; ?>

	<?php if ( ! $mvweb_tg_rows ) : ?>
		<div class="mvweb-empty">
			<?php if ( $mvweb_tg_filtered ) : ?>
				<div class="mvweb-empty__title"><?php esc_html_e( 'Nothing matches this filter', 'mvweb-telegram-hub' ); ?></div>
				<p class="mvweb-empty__text">
					<?php esc_html_e( 'The log is not empty — it just has no failures for what you picked. Press “Show all” above to see everything.', 'mvweb-telegram-hub' ); ?>
				</p>
			<?php else : ?>
				<div class="mvweb-empty__icon">
					<?php
					// Inline SVG: a single decorative icon is not worth an HTTP request.
					// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded markup.
					echo '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 6 9 17l-5-5"/></svg>';
					?>
				</div>
				<div class="mvweb-empty__title"><?php esc_html_e( 'Nothing here', 'mvweb-telegram-hub' ); ?></div>
				<p class="mvweb-empty__text">
					<?php esc_html_e( 'Only failed and retried deliveries are written down, so an empty log means every notification went through.', 'mvweb-telegram-hub' ); ?>
				</p>
			<?php endif; ?>
		</div>
	<?php else : ?>
		<div class="mvweb-table-wrap mvweb-tg-scroll">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Time', 'mvweb-telegram-hub' ); ?></th>
						<th><?php esc_html_e( 'Order', 'mvweb-telegram-hub' ); ?></th>
						<th><?php esc_html_e( 'Recipient', 'mvweb-telegram-hub' ); ?></th>
						<th>
							<?php esc_html_e( 'Attempt', 'mvweb-telegram-hub' ); ?>
							<?php Page::help_tip( __( 'The plugin makes up to four attempts: the first one, then after 1, 5 and 15 minutes. Number 4 means it gave up.', 'mvweb-telegram-hub' ) ); ?>
						</th>
						<th><?php esc_html_e( 'Status', 'mvweb-telegram-hub' ); ?></th>
						<th><?php esc_html_e( 'What went wrong', 'mvweb-telegram-hub' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					foreach ( $mvweb_tg_rows as $mvweb_tg_row ) :
						$mvweb_tg_hint = ErrorHint::get( $mvweb_tg_row['error_code'], $mvweb_tg_row['error_message'] );
						?>
						<tr>
							<td>
								<?php
								// Stored in UTC; nobody reads a log in a timezone they do not live in.
								echo esc_html(
									get_date_from_gmt(
										$mvweb_tg_row['created_at'],
										get_option( 'date_format' ) . ' ' . get_option( 'time_format' )
									)
								);
								?>
							</td>
							<td>
								<?php if ( ! empty( $mvweb_tg_row['object_id'] ) ) : ?>
									<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . MVWEB_TG_SLUG . '&tab=log&log_order=' . (int) $mvweb_tg_row['object_id'] ) ); ?>">
										#<?php echo esc_html( $mvweb_tg_row['object_id'] ); ?>
									</a>
								<?php else : ?>
									&mdash;
								<?php endif; ?>
							</td>
							<td><code><?php echo esc_html( $mvweb_tg_row['chat_id'] ); ?></code></td>
							<td><?php echo esc_html( $mvweb_tg_row['attempt'] ); ?></td>
							<td>
								<span class="mvweb-badge mvweb-badge--<?php echo 'failed' === $mvweb_tg_row['status'] ? 'error' : 'warning'; ?>">
									<?php
									echo 'failed' === $mvweb_tg_row['status']
										? esc_html__( 'Given up', 'mvweb-telegram-hub' )
										: esc_html__( 'Retried', 'mvweb-telegram-hub' );
									?>
								</span>
							</td>
							<td>
								<?php if ( '' !== $mvweb_tg_hint ) : ?>
									<div class="mvweb-tg-log__hint"><?php echo esc_html( $mvweb_tg_hint ); ?></div>
								<?php endif; ?>
								<div class="mvweb-tg-log__raw">
									<?php if ( ! empty( $mvweb_tg_row['error_code'] ) ) : ?>
										<code><?php echo esc_html( $mvweb_tg_row['error_code'] ); ?></code>
									<?php endif; ?>
									<?php echo esc_html( $mvweb_tg_row['error_message'] ); ?>
								</div>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php if ( $mvweb_tg_pages > 1 ) : ?>
			<div class="mvweb-pagination">
				<?php
				echo wp_kses_post(
					paginate_links(
						array(
							'base'      => add_query_arg( 'log_page', '%#%' ),
							'format'    => '',
							'current'   => $mvweb_tg_page,
							'total'     => $mvweb_tg_pages,
							'prev_text' => '&laquo;',
							'next_text' => '&raquo;',
						)
					)
				);
				?>
			</div>
		<?php endif; ?>

		<div class="mvweb-toolbar mvweb-tg-actions">
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<?php wp_nonce_field( 'mvweb_tg_clear_log' ); ?>
				<input type="hidden" name="action" value="mvweb_tg_clear_log">
				<button type="submit"
					class="mvweb-btn mvweb-btn--danger mvweb-tg-confirm"
					data-confirm="<?php esc_attr_e( 'Delete every entry in the log? The history of failed deliveries will be gone.', 'mvweb-telegram-hub' ); ?>">
					<?php esc_html_e( 'Clear the log', 'mvweb-telegram-hub' ); ?>
				</button>
			</form>
		</div>
	<?php endif; ?>
</div>

<div class="mvweb-submit">
	<button type="submit" name="submit" form="mvweb-tg-form-log" class="mvweb-btn mvweb-btn--primary">
		<?php esc_html_e( 'Save changes', 'mvweb-telegram-hub' ); ?>
	</button>
</div>
