<?php
/**
 * Help tab: how to set the plugin up and what to check when it goes quiet.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

use MVweb\Telegram\Hub\Admin\Page;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-telegram-hub' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Four steps, about five minutes. No programming needed — everything happens inside Telegram and on these tabs.', 'mvweb-telegram-hub' ); ?>
	</p>

	<ol class="mvweb-steps">
		<li>
			<div>
				<strong><?php esc_html_e( 'Create a bot in Telegram', 'mvweb-telegram-hub' ); ?></strong>
				<p>
					<?php
					printf(
						/* translators: 1: BotFather link, 2: the /newbot command. */
						esc_html__( 'Open %1$s, send %2$s and answer two questions: the bot name and its username. In reply BotFather sends a long line like 1234567890:AAH… — that is the token.', 'mvweb-telegram-hub' ),
						'<a href="https://t.me/BotFather" target="_blank" rel="noopener">@BotFather</a>',
						'<code>/newbot</code>'
					);
					?>
				</p>
			</div>
		</li>
		<li>
			<div>
				<strong><?php esc_html_e( 'Paste the token', 'mvweb-telegram-hub' ); ?></strong>
				<p>
					<?php
					printf(
						/* translators: %s: link to the Bot tab. */
						esc_html__( 'Copy the whole line into the “Bot token” field on the %s tab and save. If Telegram accepts it, the bot username appears next to the field.', 'mvweb-telegram-hub' ),
						'<a href="' . esc_url( Page::tab_url( 'bot' ) ) . '">' . esc_html__( 'Bot', 'mvweb-telegram-hub' ) . '</a>'
					);
					?>
				</p>
			</div>
		</li>
		<li>
			<div>
				<strong><?php esc_html_e( 'Say who gets the notifications', 'mvweb-telegram-hub' ); ?></strong>
				<p>
					<?php
					printf(
						/* translators: 1: userinfobot link, 2: link to the orders tab. */
						esc_html__( 'A bot cannot write first, so every person has to open the bot and press “Start”. Then get their number from %1$s and put it on the %2$s tab, one per line.', 'mvweb-telegram-hub' ),
						'<a href="https://t.me/userinfobot" target="_blank" rel="noopener">@userinfobot</a>',
						'<a href="' . esc_url( Page::tab_url( 'orders' ) ) . '">' . esc_html__( 'WooCommerce orders', 'mvweb-telegram-hub' ) . '</a>'
					);
					?>
				</p>
			</div>
		</li>
		<li>
			<div>
				<strong><?php esc_html_e( 'Check it before the first order', 'mvweb-telegram-hub' ); ?></strong>
				<p><?php esc_html_e( 'Press “Check recipients” and then “Send a test message”. Both report on every recipient separately, so a typo in one number shows up straight away.', 'mvweb-telegram-hub' ); ?></p>
			</div>
		</li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Where do I get the chat number?', 'mvweb-telegram-hub' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Every person, group and channel in Telegram has a number of its own — elsewhere on the internet it is called a chat ID. Which one you need depends on where the notifications should land.', 'mvweb-telegram-hub' ); ?>
	</p>

	<div class="mvweb-table-wrap mvweb-tg-scroll">
		<table class="mvweb-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Notifications go to', 'mvweb-telegram-hub' ); ?></th>
					<th><?php esc_html_e( 'What to do', 'mvweb-telegram-hub' ); ?></th>
					<th><?php esc_html_e( 'What it looks like', 'mvweb-telegram-hub' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><?php esc_html_e( 'One person', 'mvweb-telegram-hub' ); ?></td>
					<td>
						<?php
						printf(
							/* translators: %s: userinfobot link. */
							esc_html__( 'They open your bot, press “Start”, then write to %s — it answers with their number.', 'mvweb-telegram-hub' ),
							'<a href="https://t.me/userinfobot" target="_blank" rel="noopener">@userinfobot</a>'
						);
						?>
					</td>
					<td><code>123456789</code></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'A group of managers', 'mvweb-telegram-hub' ); ?></td>
					<td><?php esc_html_e( 'Add your bot to the group, then add @userinfobot too — it prints the group number and can be removed afterwards.', 'mvweb-telegram-hub' ); ?></td>
					<td><code>-1001234567890</code></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'A channel', 'mvweb-telegram-hub' ); ?></td>
					<td><?php esc_html_e( 'Add the bot as an administrator with the right to post messages. A public channel can be addressed by its handle instead of a number.', 'mvweb-telegram-hub' ); ?></td>
					<td><code>@myshoporders</code></td>
				</tr>
			</tbody>
		</table>
	</div>

	<p class="mvweb-form-row__desc">
		<?php esc_html_e( 'Keep the minus sign in group and channel numbers — without it the number points at a different chat and nothing arrives.', 'mvweb-telegram-hub' ); ?>
	</p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'How notifications work', 'mvweb-telegram-hub' ); ?></div>
	</div>

	<p><?php esc_html_e( 'An order placed at checkout — classic or block — is queued straight away and delivered in the background. The customer never waits for Telegram, so a slow or blocked connection cannot hold up the checkout page.', 'mvweb-telegram-hub' ); ?></p>
	<p><?php esc_html_e( 'Each recipient gets its own job. If one fails, the others are unaffected. Network errors, rate limits and server errors are retried after 1, 5 and 15 minutes; a wrong number or a blocked bot is not retried, because that never fixes itself.', 'mvweb-telegram-hub' ); ?></p>
	<p><?php esc_html_e( 'Only orders that customers place themselves are announced. An order you create by hand in the admin, or one brought in by an import or another plugin, stays quiet.', 'mvweb-telegram-hub' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-telegram-hub' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Nothing arrives. Where do I look?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Send a test message first — it answers per recipient and names the exact problem.', 'mvweb-telegram-hub' ); ?></p>
			<p><?php esc_html_e( 'If the test arrives but orders do not, check three things: the WooCommerce orders module is on, the order was placed at checkout rather than created in the admin, and the Log tab — it lists every failed delivery with advice on what to fix.', 'mvweb-telegram-hub' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The message arrived a minute late. Is that normal?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'Yes. Delivery runs in the background so the customer is never kept waiting at checkout. On a quiet site the background queue starts on the next visit to the site, which can take a moment.', 'mvweb-telegram-hub' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can several people get the notifications?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'Yes — put every number on its own line. Each recipient is delivered separately, so one blocked bot does not stop the others. For a team it is usually simpler to create one group and add the bot to it.', 'mvweb-telegram-hub' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'A customer phone number should not be in the group chat.', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'The message contains exactly what the template says. Delete the {customer_phone} macro from it and the phone number is never sent. You stay responsible for what personal data leaves the site.', 'mvweb-telegram-hub' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The host cannot reach Telegram. Anything I can do?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'Put your own https proxy into the “Custom API address” field on the Bot tab and the plugin will use it instead of api.telegram.org. Leave the field empty unless the hosting really blocks Telegram — an empty field is the normal setup.', 'mvweb-telegram-hub' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can I keep the token out of the database?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'Yes. Define MVWEB_TG_BOT_TOKEN in wp-config.php and it wins over the stored value; the field on the Bot tab then becomes read-only.', 'mvweb-telegram-hub' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'What happens to my settings if I delete the plugin?', 'mvweb-telegram-hub' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'They stay, so reinstalling does not cost you the token and the template. Data is removed only when “Delete data on uninstall” is switched on before you delete the plugin.', 'mvweb-telegram-hub' ); ?>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-telegram-hub' ); ?></div>
	</div>

	<p>
		<?php
		printf(
			/* translators: %s: link to the studio website. */
			esc_html__( 'Plugin by MVweb — %s', 'mvweb-telegram-hub' ),
			'<a href="https://mvweb.ru" target="_blank" rel="noopener">mvweb.ru</a>'
		);
		?>
	</p>
	<p>
		<?php
		printf(
			/* translators: %s: plugin version. */
			esc_html__( 'Version %s', 'mvweb-telegram-hub' ),
			esc_html( MVWEB_TG_VERSION )
		);
		?>
	</p>
</div>
