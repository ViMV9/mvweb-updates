<?php
/**
 * WooCommerce orders tab: recipients, message template, diagnostics.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

use MVweb\Telegram\Hub\Admin\Page;
use MVweb\Telegram\Hub\Modules\WooCustomer\Module as CustomerModule;
use MVweb\Telegram\Hub\Modules\WooOrders\Macros;
use MVweb\Telegram\Hub\Modules\WooOrders\Module;
use MVweb\Telegram\Hub\Rest\Webhook;
use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tg_option     = Settings::OPTION;
$mvweb_tg_recipients = implode( "\n", Settings::recipients() );
$mvweb_tg_template   = (string) Settings::get( 'order_template', '' );
$mvweb_tg_limit      = (int) Settings::get( 'items_limit', 10 );
$mvweb_tg_ready      = Settings::is_ready();
$mvweb_tg_module_on  = Settings::module_enabled( Module::slug() );
$mvweb_tg_wc_ok      = Module::requirements_met();
$mvweb_tg_has_token  = '' !== Settings::token();
$mvweb_tg_has_chats  = (bool) Settings::recipients();
$mvweb_tg_shop       = class_exists( 'WooCommerce' );

$mvweb_tg_customer_on       = Settings::module_enabled( CustomerModule::slug() );
$mvweb_tg_customer_statuses = Settings::customer_statuses();
$mvweb_tg_hook_on           = Webhook::is_enabled();
$mvweb_tg_all_statuses      = function_exists( 'wc_get_order_statuses' ) ? wc_get_order_statuses() : array();

// Naming the actual bot beats "your bot": the operator can hand these steps to
// a colleague as they are, without explaining which bot is meant.
$mvweb_tg_bot        = get_transient( 'mvweb_tg_bot_info' );
$mvweb_tg_bot_handle = is_array( $mvweb_tg_bot ) && ! empty( $mvweb_tg_bot['username'] )
	? '@' . $mvweb_tg_bot['username']
	: __( 'your bot', 'mvweb-telegram-hub' );

// Name what is actually missing: "needs a token and a recipient" reads as an
// accusation when the token was saved a minute ago.
$mvweb_tg_missing = '';

if ( ! $mvweb_tg_has_token && ! $mvweb_tg_has_chats ) {
	$mvweb_tg_missing = __( 'Nothing is sent yet: the bot token is missing, and so are the recipients. Start on the Bot tab, then come back here.', 'mvweb-telegram-hub' );
} elseif ( ! $mvweb_tg_has_token ) {
	$mvweb_tg_missing = __( 'Nothing is sent yet: the bot token is missing. Paste it on the Bot tab.', 'mvweb-telegram-hub' );
} elseif ( ! $mvweb_tg_has_chats ) {
	$mvweb_tg_missing = __( 'The bot is connected, one thing left: add at least one recipient below and save.', 'mvweb-telegram-hub' );
}
?>

<?php if ( $mvweb_tg_shop && ! $mvweb_tg_wc_ok ) : ?>
	<div class="mvweb-alert mvweb-alert--error">
		<div class="mvweb-alert__body">
			<?php echo esc_html( Module::requirement_message() ); ?>
			<?php esc_html_e( 'The settings below can still be edited, but nothing is sent until WooCommerce is updated.', 'mvweb-telegram-hub' ); ?>
		</div>
	</div>
<?php elseif ( $mvweb_tg_shop && ! $mvweb_tg_module_on ) : ?>
	<div class="mvweb-alert mvweb-alert--warning">
		<div class="mvweb-alert__body">
			<?php esc_html_e( 'The WooCommerce orders module is switched off on the Bot tab, so no order notifications are sent.', 'mvweb-telegram-hub' ); ?>
		</div>
	</div>
<?php elseif ( ! $mvweb_tg_ready ) : ?>
	<div class="mvweb-alert mvweb-alert--warning">
		<div class="mvweb-alert__body">
			<?php echo esc_html( $mvweb_tg_missing ); ?>
		</div>
	</div>
<?php endif; ?>

<form id="mvweb-tg-form-orders" method="post" action="options.php">
	<?php settings_fields( Page::GROUP ); ?>
	<?php Page::referer_field( 'orders' ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Recipients', 'mvweb-telegram-hub' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php
			if ( $mvweb_tg_shop ) {
				esc_html_e( 'Who receives a message about every new order, and service messages from other plugins of the site — a failed backup, for one. One recipient per line — a person, a group of managers or a channel.', 'mvweb-telegram-hub' );
			} else {
				esc_html_e( 'Who receives service messages from other plugins of the site — a failed backup, for one. One recipient per line — a person, a group or a channel.', 'mvweb-telegram-hub' );
			}
			?>
		</p>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-recipients" class="mvweb-form-row__label">
				<?php esc_html_e( 'Chats', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'A person is a plain number: 123456789. A group or channel starts with a minus: -1001234567890 — the minus is part of the number. A public channel can also be written as @channelname.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-tg-recipients"
					name="<?php echo esc_attr( $mvweb_tg_option ); ?>[recipients]"
					class="mvweb-textarea"
					rows="4"
					spellcheck="false"
					placeholder="123456789&#10;-1001234567890"><?php echo esc_textarea( $mvweb_tg_recipients ); ?></textarea>
				<?php
				/*
				 * Folded once there is a recipient, exactly like the token steps on
				 * the Bot tab: three cases of prose are four times taller than the
				 * field they explain, and after the first setup they are only
				 * needed when another chat is being added.
				 */
				?>
				<details class="mvweb-tg-howto" <?php echo $mvweb_tg_has_chats ? '' : 'open'; ?>>
					<summary class="mvweb-tg-howto__lead">
						<?php esc_html_e( 'Where to get the number — pick the line that matches you', 'mvweb-telegram-hub' ); ?>
					</summary>
					<ul>
						<li>
							<strong><?php esc_html_e( 'To yourself or a colleague', 'mvweb-telegram-hub' ); ?></strong>
							<span>
								<?php
								printf(
									/* translators: 1: bot username or a generic wording, 2: userinfobot link. */
									esc_html__( 'The person opens %1$s, presses “Start”, then writes to %2$s — it replies with a number like 123456789. That is the one to paste here.', 'mvweb-telegram-hub' ),
									esc_html( $mvweb_tg_bot_handle ),
									'<a href="https://t.me/userinfobot" target="_blank" rel="noopener">@userinfobot</a>'
								);
								?>
							</span>
						</li>
						<li>
							<strong><?php esc_html_e( 'To a group of managers', 'mvweb-telegram-hub' ); ?></strong>
							<span>
								<?php
								printf(
									/* translators: 1: bot username or a generic wording, 2: userinfobot link. */
									esc_html__( 'Create a group, add %1$s to it, then add %2$s — it prints the group number, one with a minus like -1001234567890. Copy it with the minus and remove that second bot.', 'mvweb-telegram-hub' ),
									esc_html( $mvweb_tg_bot_handle ),
									'<a href="https://t.me/userinfobot" target="_blank" rel="noopener">@userinfobot</a>'
								);
								?>
							</span>
						</li>
						<li>
							<strong><?php esc_html_e( 'To a channel', 'mvweb-telegram-hub' ); ?></strong>
							<span>
								<?php
								printf(
									/* translators: %s: bot username or a generic wording. */
									esc_html__( 'Add %s as an administrator of the channel and allow it to post messages. A public channel can then be written by name: @mychannel. A private one has no name — press “Find my chats” below and the plugin will report its number.', 'mvweb-telegram-hub' ),
									esc_html( $mvweb_tg_bot_handle )
								);
								?>
							</span>
						</li>
					</ul>
					<p class="mvweb-tg-howto__note">
						<?php esc_html_e( 'A bot cannot write first — that is a Telegram rule, not a plugin limitation. Until the person presses “Start”, or the bot is added to the group, nothing arrives.', 'mvweb-telegram-hub' ); ?>
					</p>
				</details>

				<?php
				/*
				 * Outside the folded block and a link rather than a form: this sits
				 * inside the settings form, and a nested <form> is invalid HTML that
				 * the browser drops on the floor. The action only reads from the API,
				 * so a nonced GET is enough.
				 */
				?>
				<p class="mvweb-tg-discover">
					<a class="mvweb-btn" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mvweb_tg_discover&tab=orders' ), 'mvweb_tg_discover' ) ); ?>">
						<?php esc_html_e( 'Find my chats', 'mvweb-telegram-hub' ); ?>
					</a>
					<span>
						<?php esc_html_e( 'Asks Telegram which chats the bot has taken part in and shows their numbers — the only way to learn the number of a private channel, which has no name to address it by. Unsaved changes on this page will be lost.', 'mvweb-telegram-hub' ); ?>
					</span>
				</p>
			</div>
		</div>
	</div>

	<?php if ( $mvweb_tg_shop ) : ?>
	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Message template', 'mvweb-telegram-hub' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'What the message looks like. Write it the way you want to read it, and put a macro where the order data should appear — the plugin replaces every macro with the real value.', 'mvweb-telegram-hub' ); ?>
		</p>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-template" class="mvweb-form-row__label">
				<?php esc_html_e( 'Template', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'Bold is written as <b>text</b>, italic as <i>text</i>. Telegram also understands strong, em, u, ins, s, strike, del, code, pre, blockquote and a. Any other tag is removed when you save.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-tg-template"
					name="<?php echo esc_attr( $mvweb_tg_option ); ?>[order_template]"
					class="mvweb-textarea"
					rows="12"
					spellcheck="false"><?php echo esc_textarea( $mvweb_tg_template ); ?></textarea>
				<button type="button"
					class="mvweb-btn mvweb-btn--sm"
					id="mvweb-tg-template-reset"
					data-template="<?php echo esc_attr( Settings::default_template() ); ?>"
					data-confirm="<?php esc_attr_e( 'Replace the current template with the standard one? Your text will be lost.', 'mvweb-telegram-hub' ); ?>">
					<?php esc_html_e( 'Insert the standard template', 'mvweb-telegram-hub' ); ?>
				</button>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Fills the field with the ready-made layout. Nothing is saved until you press “Save changes”.', 'mvweb-telegram-hub' ); ?>
				</p>

				<details class="mvweb-tg-howto">
					<summary class="mvweb-tg-howto__lead">
						<?php esc_html_e( 'How the template behaves', 'mvweb-telegram-hub' ); ?>
					</summary>
					<ul>
						<li>
							<strong><?php esc_html_e( 'Formatting', 'mvweb-telegram-hub' ); ?></strong>
							<span><?php esc_html_e( 'Bold is written as <b>text</b>, italic as <i>text</i>. Telegram also takes strong, em, u, ins, s, strike, del, code, pre, blockquote and a. Any other tag is removed when you save.', 'mvweb-telegram-hub' ); ?></span>
						</li>
						<li>
							<strong><?php esc_html_e( 'Empty values', 'mvweb-telegram-hub' ); ?></strong>
							<span><?php esc_html_e( 'A line whose macros all came out empty is dropped, so an order without a phone number does not arrive with a dangling “Phone:” line.', 'mvweb-telegram-hub' ); ?></span>
						</li>
						<li>
							<strong><?php esc_html_e( 'Privacy', 'mvweb-telegram-hub' ); ?></strong>
							<span><?php esc_html_e( 'The message contains exactly what is written here. Delete a macro — that data never leaves the site.', 'mvweb-telegram-hub' ); ?></span>
						</li>
					</ul>
				</details>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Macros', 'mvweb-telegram-hub' ); ?></span>
			<div class="mvweb-form-row__field">
				<?php
				/*
				 * Sixteen macros with their descriptions push the item limit and
				 * the diagnostics buttons off the screen. Folded: the reference is
				 * needed while writing the template, not on every visit.
				 */
				?>
				<details class="mvweb-tg-howto">
					<summary class="mvweb-tg-howto__lead">
						<?php esc_html_e( 'Show the list of macros', 'mvweb-telegram-hub' ); ?>
					</summary>
					<p class="mvweb-tg-howto__hint">
						<?php esc_html_e( 'Click a macro to insert it at the cursor. Delete one from the template and that data is never sent.', 'mvweb-telegram-hub' ); ?>
					</p>
					<?php
					/*
					 * A definition list, not a ul: dt and dd are direct children of
					 * one grid, so the column of codes lines up across all sixteen
					 * rows and a long description can only ever grow inside its own
					 * cell — it cannot drift under a neighbouring macro.
					 */
					?>
					<?php
					$mvweb_tg_macro_list   = Macros::catalogue();
					$mvweb_tg_macro_target = 'mvweb-tg-template';
					require MVWEB_TG_PATH . 'admin/views/partial-macros.php';
					?>
				</details>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-items-limit" class="mvweb-form-row__label">
				<?php esc_html_e( 'Line items to show', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'Only affects the {order_items} macro. Ten lines is usually enough to see what was ordered; the rest is summarised in one line and the full list stays in the order card.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
					id="mvweb-tg-items-limit"
					name="<?php echo esc_attr( $mvweb_tg_option ); ?>[items_limit]"
					class="mvweb-input mvweb-tg-narrow"
					value="<?php echo esc_attr( (string) $mvweb_tg_limit ); ?>"
					min="1"
					max="50"
					step="1">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Everything above this count becomes a single “and N more items” line, so a big order still fits into one Telegram message.', 'mvweb-telegram-hub' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Notifications to the customer', 'mvweb-telegram-hub' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'A separate channel from the one above: the shopper connects Telegram themselves and hears about their own orders only. A signed-in customer does it in the “Telegram” section of their account, a guest on the page of the order. The wording they get is fixed — the order number, its status, the total and a way back to it, and nothing that belongs in the shop office.', 'mvweb-telegram-hub' ); ?>
		</p>

		<?php if ( ! $mvweb_tg_customer_on ) : ?>
			<div class="mvweb-alert mvweb-alert--info">
				<div class="mvweb-alert__body">
					<?php esc_html_e( 'The “Order status for the customer” module is switched off on the Bot tab, so the connect button does not appear in the shop.', 'mvweb-telegram-hub' ); ?>
				</div>
			</div>
		<?php elseif ( ! $mvweb_tg_hook_on ) : ?>
			<div class="mvweb-alert mvweb-alert--warning">
				<div class="mvweb-alert__body">
					<?php esc_html_e( 'Commands from Telegram are not being accepted, so nobody can finish connecting. Switch them on under “Commands from Telegram” on the Bot tab.', 'mvweb-telegram-hub' ); ?>
				</div>
			</div>
		<?php endif; ?>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label">
				<?php esc_html_e( 'Tell the customer about', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'The statuses a message is sent on. A signed-in customer sees the same list in the “Telegram” section of their account and can untick any of it for themselves; a status left unticked here is not offered to them at all. Statuses added by other plugins appear here too. Nothing is sent for the status an order gets while it is being placed — the shopper is looking at the “order received” page at that moment and gets the email as well.', 'mvweb-telegram-hub' ) ); ?>
			</span>
			<div class="mvweb-form-row__field">
				<input type="hidden" name="<?php echo esc_attr( $mvweb_tg_option ); ?>[customer_statuses][]" value="">
				<?php foreach ( $mvweb_tg_all_statuses as $mvweb_tg_status_key => $mvweb_tg_status_name ) : ?>
					<label class="mvweb-check mvweb-tg-check">
						<input type="checkbox"
							name="<?php echo esc_attr( $mvweb_tg_option ); ?>[customer_statuses][]"
							value="<?php echo esc_attr( $mvweb_tg_status_key ); ?>"
							<?php checked( in_array( $mvweb_tg_status_key, $mvweb_tg_customer_statuses, true ) ); ?>>
						<span><?php echo esc_html( $mvweb_tg_status_name ); ?></span>
					</label>
				<?php endforeach; ?>
				<?php if ( ! $mvweb_tg_all_statuses ) : ?>
					<p class="mvweb-form-row__desc"><?php esc_html_e( 'WooCommerce is not active, so there are no statuses to choose from.', 'mvweb-telegram-hub' ); ?></p>
				<?php endif; ?>
			</div>
		</div>
	</div>
	<?php endif; ?>

</form>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Diagnostics', 'mvweb-telegram-hub' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php
		if ( $mvweb_tg_shop ) {
			esc_html_e( 'Two ways to make sure everything works before a real customer places an order. Save your changes first — both buttons work with the stored settings.', 'mvweb-telegram-hub' );
		} else {
			esc_html_e( 'Two ways to make sure messages get through. Save your changes first — both buttons work with the stored settings.', 'mvweb-telegram-hub' );
		}
		?>
	</p>

	<div class="mvweb-toolbar mvweb-tg-actions">
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'mvweb_tg_verify' ); ?>
			<input type="hidden" name="action" value="mvweb_tg_verify">
			<button type="submit" class="mvweb-btn">
				<?php esc_html_e( 'Check recipients', 'mvweb-telegram-hub' ); ?>
			</button>
		</form>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<?php wp_nonce_field( 'mvweb_tg_test' ); ?>
			<input type="hidden" name="action" value="mvweb_tg_test">
			<?php
			/*
			 * Not --primary: the sticky save bar is on screen at all times and
			 * already carries the brand fill. Two filled buttons pulling in
			 * different directions cancel each other out.
			 */
			?>
			<button type="submit" class="mvweb-btn">
				<?php esc_html_e( 'Send a test message', 'mvweb-telegram-hub' ); ?>
			</button>
		</form>
	</div>

	<p class="mvweb-form-row__desc">
		<?php esc_html_e( '“Check recipients” asks Telegram whether each chat exists and the bot may write there — nobody is disturbed. “Send a test message” really writes to every recipient.', 'mvweb-telegram-hub' ); ?>
	</p>
</div>

<div class="mvweb-submit">
	<button type="submit" name="submit" form="mvweb-tg-form-orders" class="mvweb-btn mvweb-btn--primary">
		<?php esc_html_e( 'Save changes', 'mvweb-telegram-hub' ); ?>
	</button>
</div>
