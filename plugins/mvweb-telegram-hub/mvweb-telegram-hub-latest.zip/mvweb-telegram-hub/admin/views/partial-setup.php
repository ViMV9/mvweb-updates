<?php
/**
 * Setup progress card shown at the top of the settings screen.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

use MVweb\Telegram\Hub\Admin\Page;
use MVweb\Telegram\Hub\Admin\Setup;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Set by the including tab: a "go to this step" link pointing at the tab the
// operator is already on would be a link to nowhere.
$mvweb_tg_setup_tab = isset( $mvweb_tg_setup_tab ) ? $mvweb_tg_setup_tab : '';

$mvweb_tg_steps    = Setup::steps();
$mvweb_tg_total    = count( $mvweb_tg_steps );
$mvweb_tg_done     = Setup::done_count( $mvweb_tg_steps );
$mvweb_tg_ready    = $mvweb_tg_done === $mvweb_tg_total;
$mvweb_tg_percent  = $mvweb_tg_total ? round( $mvweb_tg_done / $mvweb_tg_total * 100 ) : 0;
$mvweb_tg_next_hit = false;
?>

<div class="mvweb-block mvweb-tg-setup">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Setup', 'mvweb-telegram-hub' ); ?></div>
		<span class="mvweb-badge mvweb-badge--<?php echo $mvweb_tg_ready ? 'success' : 'plain'; ?>">
			<?php
			echo $mvweb_tg_ready
				? esc_html__( 'Ready to work', 'mvweb-telegram-hub' )
				: esc_html(
					sprintf(
						/* translators: 1: completed steps, 2: total steps. */
						__( '%1$d of %2$d done', 'mvweb-telegram-hub' ),
						$mvweb_tg_done,
						$mvweb_tg_total
					)
				);
			?>
		</span>
	</div>

	<div class="mvweb-progress">
		<span class="mvweb-progress__bar" style="width: <?php echo esc_attr( (string) $mvweb_tg_percent ); ?>%;"></span>
	</div>

	<ol class="mvweb-tg-setup__list">
		<?php
		foreach ( $mvweb_tg_steps as $mvweb_tg_index => $mvweb_tg_step ) :
			$mvweb_tg_state = 'waiting';

			if ( $mvweb_tg_step['done'] ) {
				$mvweb_tg_state = 'done';
			} elseif ( ! $mvweb_tg_next_hit ) {
				// Only the first unfinished step is the one to do now; the rest wait.
				$mvweb_tg_state    = 'current';
				$mvweb_tg_next_hit = true;
			}
			?>
			<li class="mvweb-tg-setup__item mvweb-tg-setup__item--<?php echo esc_attr( $mvweb_tg_state ); ?>">
				<span class="mvweb-tg-setup__mark" aria-hidden="true">
					<?php echo 'done' === $mvweb_tg_state ? '✓' : esc_html( (string) ( $mvweb_tg_index + 1 ) ); ?>
				</span>
				<span class="mvweb-tg-setup__body">
					<span class="mvweb-tg-setup__title">
						<?php echo esc_html( $mvweb_tg_step['title'] ); ?>
						<?php if ( 'current' === $mvweb_tg_state && $mvweb_tg_step['tab'] !== $mvweb_tg_setup_tab ) : ?>
							<a class="mvweb-tg-setup__go" href="<?php echo esc_url( Page::tab_url( $mvweb_tg_step['tab'] ) ); ?>">
								<?php esc_html_e( 'Go to this step', 'mvweb-telegram-hub' ); ?>
							</a>
						<?php endif; ?>
					</span>
					<span class="mvweb-tg-setup__detail"><?php echo esc_html( $mvweb_tg_step['detail'] ); ?></span>
				</span>
			</li>
		<?php endforeach; ?>
	</ol>
</div>
