<?php
/**
 * Result of a diagnostic action, carried across the redirect.
 *
 * Expects $mvweb_tg_notice from settings-page.php.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $mvweb_tg_notice ) || ! is_array( $mvweb_tg_notice ) ) {
	return;
}

$mvweb_tg_notice_type = isset( $mvweb_tg_notice['type'] ) ? $mvweb_tg_notice['type'] : 'info';
$mvweb_tg_notice_rows = isset( $mvweb_tg_notice['rows'] ) && is_array( $mvweb_tg_notice['rows'] ) ? $mvweb_tg_notice['rows'] : array();
?>

<div class="mvweb-alert mvweb-alert--<?php echo esc_attr( $mvweb_tg_notice_type ); ?>">
	<div class="mvweb-alert__body">
		<div class="mvweb-alert__title"><?php echo esc_html( isset( $mvweb_tg_notice['message'] ) ? $mvweb_tg_notice['message'] : '' ); ?></div>

		<?php if ( ! empty( $mvweb_tg_notice['hint'] ) ) : ?>
			<p><?php echo esc_html( $mvweb_tg_notice['hint'] ); ?></p>
		<?php endif; ?>

		<?php if ( $mvweb_tg_notice_rows ) : ?>
			<div class="mvweb-table-wrap mvweb-tg-report mvweb-tg-scroll">
				<table class="mvweb-table">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Recipient', 'mvweb-telegram-hub' ); ?></th>
							<th><?php esc_html_e( 'Result', 'mvweb-telegram-hub' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $mvweb_tg_notice_rows as $mvweb_tg_row ) : ?>
							<tr>
								<td><code><?php echo esc_html( $mvweb_tg_row['chat'] ); ?></code></td>
								<td>
									<span class="mvweb-badge mvweb-badge--<?php echo empty( $mvweb_tg_row['ok'] ) ? 'error' : 'success'; ?>">
										<?php echo esc_html( $mvweb_tg_row['text'] ); ?>
									</span>
									<?php if ( ! empty( $mvweb_tg_row['hint'] ) ) : ?>
										<div class="mvweb-tg-log__hint"><?php echo esc_html( $mvweb_tg_row['hint'] ); ?></div>
									<?php endif; ?>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php elseif ( 'success' !== $mvweb_tg_notice_type ) : ?>
			<p><?php esc_html_e( 'No recipients are configured yet.', 'mvweb-telegram-hub' ); ?></p>
		<?php endif; ?>
	</div>
</div>
