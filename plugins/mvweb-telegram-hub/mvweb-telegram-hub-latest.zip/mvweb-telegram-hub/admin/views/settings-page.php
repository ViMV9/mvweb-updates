<?php
/**
 * Admin settings page template.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 * Reference: docs/ui-kit-reference.html
 *
 *   .wrap.mvweb-settings
 *     ├── aside.mvweb-sidebar  — brand + tab navigation
 *     └── main.mvweb-main      — tab panels
 *
 * Each tab is a partial in admin/views/tab-{slug}.php. Switching is done in
 * JS (admin.js) via .mvweb-tab-content.active; the server still marks the
 * right panel so a redirect with ?tab= lands where it should.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

use MVweb\Telegram\Hub\Admin\Actions;
use MVweb\Telegram\Hub\Admin\Page;
use MVweb\Telegram\Hub\Log\Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tg_current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'bot'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.
$mvweb_tg_notice      = Actions::pull_notice();
$mvweb_tg_log_count   = Repository::count();

$mvweb_tg_tabs = array(
	'bot'    => array(
		'label' => __( 'Bot', 'mvweb-telegram-hub' ),
		'count' => null,
		'icon'  => 'plug',
	),
	'orders' => array(
		'label' => __( 'WooCommerce orders', 'mvweb-telegram-hub' ),
		'count' => null,
		'icon'  => 'cart',
	),
	'log'    => array(
		'label' => __( 'Log', 'mvweb-telegram-hub' ),
		'count' => $mvweb_tg_log_count ? $mvweb_tg_log_count : null,
		'icon'  => 'list',
	),
	'help'   => array(
		'label' => __( 'Help', 'mvweb-telegram-hub' ),
		'count' => null,
		'icon'  => 'help',
	),
);

if ( ! isset( $mvweb_tg_tabs[ $mvweb_tg_current_tab ] ) ) {
	$mvweb_tg_current_tab = 'bot';
}

$mvweb_tg_icons = array(
	'plug' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9 2v6"/><path d="M15 2v6"/><path d="M6 8h12v3a6 6 0 0 1-6 6 6 6 0 0 1-6-6z"/><path d="M12 17v5"/></svg>',
	'cart' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.4 11.2a2 2 0 0 0 2 1.6h7.7a2 2 0 0 0 2-1.6L21 7H6"/></svg>',
	'list' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="9" y1="6" x2="20" y2="6"/><line x1="9" y1="12" x2="20" y2="12"/><line x1="9" y1="18" x2="20" y2="18"/><circle cx="4.5" cy="6" r="1"/><circle cx="4.5" cy="12" r="1"/><circle cx="4.5" cy="18" r="1"/></svg>',
	'help' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">TG</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Telegram Hub', 'mvweb-telegram-hub' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_TG_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $mvweb_tg_tabs as $mvweb_tg_tab_id => $mvweb_tg_tab ) : ?>
				<li>
					<?php // aria-current, not colour alone: the active tab differs only by background otherwise. ?>
					<a href="#<?php echo esc_attr( $mvweb_tg_tab_id ); ?>"
						class="mvweb-nav__link <?php echo $mvweb_tg_current_tab === $mvweb_tg_tab_id ? 'mvweb-nav__link--active' : ''; ?>"
						<?php echo $mvweb_tg_current_tab === $mvweb_tg_tab_id ? 'aria-current="page"' : ''; ?>
						data-tab="<?php echo esc_attr( $mvweb_tg_tab_id ); ?>">
						<?php echo $mvweb_tg_icons[ $mvweb_tg_tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $mvweb_tg_tab['label'] ); ?>
						<?php if ( null !== $mvweb_tg_tab['count'] ) : ?>
							<span class="mvweb-nav__badge"><?php echo esc_html( (string) $mvweb_tg_tab['count'] ); ?></span>
						<?php endif; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php
		// Core files its "Settings saved." notice under the 'general' slug, so
		// printing only our own slug would leave a successful save silent.
		settings_errors( 'general' );
		settings_errors( Page::NOTICE_SLUG );
		?>

		<?php if ( $mvweb_tg_notice ) : ?>
			<?php require MVWEB_TG_PATH . 'admin/views/partial-notice.php'; ?>
		<?php endif; ?>

		<div id="bot" class="mvweb-tab-content <?php echo 'bot' === $mvweb_tg_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_TG_PATH . 'admin/views/tab-bot.php'; ?>
		</div>

		<div id="orders" class="mvweb-tab-content <?php echo 'orders' === $mvweb_tg_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_TG_PATH . 'admin/views/tab-orders.php'; ?>
		</div>

		<div id="log" class="mvweb-tab-content <?php echo 'log' === $mvweb_tg_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_TG_PATH . 'admin/views/tab-log.php'; ?>
		</div>

		<div id="help" class="mvweb-tab-content <?php echo 'help' === $mvweb_tg_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_TG_PATH . 'admin/views/tab-help.php'; ?>
		</div>

	</main>
</div>
