<?php
/**
 * Bot tab: token, API address, modules, uninstall behaviour.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

use MVweb\Telegram\Hub\Admin\Page;
use MVweb\Telegram\Hub\Modules\Registry;
use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_tg_option       = Settings::OPTION;
$mvweb_tg_by_constant  = Settings::token_is_constant();
$mvweb_tg_masked       = Settings::masked_token();
$mvweb_tg_bot          = get_transient( 'mvweb_tg_bot_info' );
$mvweb_tg_api_base     = (string) Settings::get( 'api_base', '' );
$mvweb_tg_delete_data  = (bool) Settings::get( 'delete_data', false );
$mvweb_tg_module_names = Registry::labels();
$mvweb_tg_has_token    = '' !== $mvweb_tg_masked;
?>

<?php
$mvweb_tg_setup_tab = 'bot';
require MVWEB_TG_PATH . 'admin/views/partial-setup.php';
?>


<form id="mvweb-tg-form-bot" method="post" action="options.php">
	<?php settings_fields( Page::GROUP ); ?>
	<?php Page::referer_field( 'bot' ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Telegram bot', 'mvweb-telegram-hub' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'The bot is the account that writes to you in Telegram. It is created in Telegram itself, in one minute, and costs nothing.', 'mvweb-telegram-hub' ); ?>
		</p>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-token" class="mvweb-form-row__label">
				<?php esc_html_e( 'Bot token', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'The line @BotFather sends you after /newbot. It looks like 1234567890:AAHdqTcvCH1vGWJxfSeofSAs0K5PALDsaw — copy all of it, including the digits before the colon. Anyone who has this line can write on behalf of your bot, so do not publish it.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php if ( $mvweb_tg_by_constant ) : ?>
					<input type="text" id="mvweb-tg-token" class="mvweb-input" value="<?php echo esc_attr( $mvweb_tg_masked ); ?>" disabled>
					<p class="mvweb-form-row__desc">
						<?php esc_html_e( 'Defined in wp-config.php as MVWEB_TG_BOT_TOKEN. Edit that file to change it.', 'mvweb-telegram-hub' ); ?>
					</p>
				<?php else : ?>
					<?php
					/*
					 * Deliberately not type="password": the browser then treats the
					 * form as a login, offers to fill it from the keychain and asks
					 * to save a password on every save. This is an API key, and the
					 * field is always rendered empty anyway — the stored token is
					 * shown masked underneath, never as a value.
					 */
					?>
					<input type="text"
						id="mvweb-tg-token"
						name="<?php echo esc_attr( $mvweb_tg_option ); ?>[bot_token]"
						class="mvweb-input"
						value=""
						autocomplete="off"
						autocapitalize="off"
						autocorrect="off"
						spellcheck="false"
						data-1p-ignore
						data-lpignore="true"
						placeholder="1234567890:AA…">
					<p class="mvweb-form-row__desc">
						<?php if ( '' !== $mvweb_tg_masked ) : ?>
							<?php
							printf(
								/* translators: %s: masked bot token. */
								esc_html__( 'Saved token: %s. Leave the field empty to keep it.', 'mvweb-telegram-hub' ),
								'<code>' . esc_html( $mvweb_tg_masked ) . '</code>'
							);
							?>
						<?php else : ?>
							<?php esc_html_e( 'No token saved yet.', 'mvweb-telegram-hub' ); ?>
						<?php endif; ?>
					</p>
				<?php endif; ?>

				<?php if ( is_array( $mvweb_tg_bot ) && ! empty( $mvweb_tg_bot['username'] ) ) : ?>
					<p class="mvweb-form-row__desc">
						<span class="mvweb-badge mvweb-badge--success">
							<?php echo esc_html( '@' . $mvweb_tg_bot['username'] ); ?>
						</span>
						<?php esc_html_e( 'Telegram accepted the token — this is your bot.', 'mvweb-telegram-hub' ); ?>
					</p>
				<?php endif; ?>

				<?php if ( ! $mvweb_tg_by_constant ) : ?>
					<?php
					/*
					 * Open while there is nothing to connect with, folded once the
					 * bot works: the same four steps are then only needed when the
					 * token is being replaced.
					 */
					?>
					<details class="mvweb-tg-howto" <?php echo $mvweb_tg_has_token ? '' : 'open'; ?>>
						<summary class="mvweb-tg-howto__lead"><?php esc_html_e( 'How to get the token — three minutes in Telegram', 'mvweb-telegram-hub' ); ?></summary>
						<ol>
							<li>
								<?php
								printf(
									/* translators: %s: BotFather link. */
									esc_html__( 'Open %s — this is the official Telegram bot that hands out bots.', 'mvweb-telegram-hub' ),
									'<a href="https://t.me/BotFather" target="_blank" rel="noopener">@BotFather</a>'
								);
								?>
							</li>
							<li>
								<?php
								printf(
									/* translators: %s: the /newbot command. */
									esc_html__( 'Send it %s.', 'mvweb-telegram-hub' ),
									'<code>/newbot</code>'
								);
								?>
							</li>
							<li><?php esc_html_e( 'Answer two questions: a name for the bot (any, for example “Orders of my shop”) and a username, which must end in bot.', 'mvweb-telegram-hub' ); ?></li>
							<li><?php esc_html_e( 'BotFather replies with a line like 1234567890:AAHdqTcv… — copy it whole and paste it into the field above, then save.', 'mvweb-telegram-hub' ); ?></li>
						</ol>
						<p class="mvweb-tg-howto__note"><?php esc_html_e( 'Keep the token to yourself: whoever has it can write on behalf of the bot. If it leaks, send /revoke to BotFather and paste the new one here.', 'mvweb-telegram-hub' ); ?></p>
					</details>
				<?php endif; ?>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-api-base" class="mvweb-form-row__label">
				<?php esc_html_e( 'Custom API address', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'For hosting that blocks Telegram. If messages arrive normally, this field is not for you — leave it empty.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="url"
					id="mvweb-tg-api-base"
					name="<?php echo esc_attr( $mvweb_tg_option ); ?>[api_base]"
					class="mvweb-input"
					value="<?php echo esc_attr( $mvweb_tg_api_base ); ?>"
					autocomplete="off"
					autocapitalize="off"
					autocorrect="off"
					spellcheck="false"
					data-1p-ignore
					data-lpignore="true"
					placeholder="<?php echo esc_attr( Settings::DEFAULT_API_BASE ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Usually stays empty — then the site talks to api.telegram.org directly. Fill it in only if the hosting blocks Telegram and you have your own https proxy.', 'mvweb-telegram-hub' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Modules', 'mvweb-telegram-hub' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'A master switch for each kind of notification. Switch one off and the plugin stops sending it, keeping all its settings for later.', 'mvweb-telegram-hub' ); ?>
		</p>

		<?php foreach ( $mvweb_tg_module_names as $mvweb_tg_slug => $mvweb_tg_label ) : ?>
			<div class="mvweb-form-row">
				<label for="mvweb-tg-module-<?php echo esc_attr( $mvweb_tg_slug ); ?>" class="mvweb-form-row__label">
					<?php echo esc_html( $mvweb_tg_label ); ?>
				</label>
				<div class="mvweb-form-row__field">
					<div class="mvweb-toggle-row">
						<input type="hidden" name="<?php echo esc_attr( $mvweb_tg_option ); ?>[modules][<?php echo esc_attr( $mvweb_tg_slug ); ?>]" value="0">
						<label class="mvweb-toggle">
							<input type="checkbox"
								id="mvweb-tg-module-<?php echo esc_attr( $mvweb_tg_slug ); ?>"
								name="<?php echo esc_attr( $mvweb_tg_option ); ?>[modules][<?php echo esc_attr( $mvweb_tg_slug ); ?>]"
								value="1"
								<?php checked( Settings::module_enabled( $mvweb_tg_slug ) ); ?>>
							<span class="mvweb-toggle__slider"></span>
						</label>
						<span><?php esc_html_e( 'Send notifications for this module', 'mvweb-telegram-hub' ); ?></span>
					</div>
				</div>
			</div>
		<?php endforeach; ?>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Data', 'mvweb-telegram-hub' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'What happens to the settings, the delivery log and the marks left on orders when the plugin goes away.', 'mvweb-telegram-hub' ); ?>
		</p>

		<div class="mvweb-form-row">
			<label for="mvweb-tg-delete-data" class="mvweb-form-row__label">
				<?php esc_html_e( 'Delete data on uninstall', 'mvweb-telegram-hub' ); ?>
				<?php Page::help_tip( __( 'Applies to deleting the plugin, not deactivating it. Deactivation never touches your settings.', 'mvweb-telegram-hub' ) ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<input type="hidden" name="<?php echo esc_attr( $mvweb_tg_option ); ?>[delete_data]" value="0">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb-tg-delete-data"
							name="<?php echo esc_attr( $mvweb_tg_option ); ?>[delete_data]"
							value="1"
							<?php checked( $mvweb_tg_delete_data ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Remove settings, the delivery log and order flags when the plugin is deleted', 'mvweb-telegram-hub' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Off by default, so deleting the plugin by mistake does not cost you the token and the template.', 'mvweb-telegram-hub' ); ?>
				</p>
			</div>
		</div>
	</div>

</form>

<?php if ( ! $mvweb_tg_by_constant && '' !== $mvweb_tg_masked ) : ?>
	<?php
	/*
	 * Outside the settings form on purpose — a form cannot be nested in another
	 * one — but inside its own card, so the only irreversible action on the
	 * screen sits in the grid with everything else instead of hanging loose.
	 */
	?>
	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Remove the token', 'mvweb-telegram-hub' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Erases the saved token right away and cannot be undone. Notifications stop until a new token is saved; recipients, the template and the log stay where they are.', 'mvweb-telegram-hub' ); ?>
		</p>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="mvweb-tg-inline-form">
			<?php wp_nonce_field( 'mvweb_tg_delete_token' ); ?>
			<input type="hidden" name="action" value="mvweb_tg_delete_token">
			<button type="submit"
				class="mvweb-btn mvweb-btn--danger mvweb-tg-confirm"
				data-confirm="<?php esc_attr_e( 'Delete the saved token? Notifications will stop until you paste a new one.', 'mvweb-telegram-hub' ); ?>">
				<?php esc_html_e( 'Delete token', 'mvweb-telegram-hub' ); ?>
			</button>
		</form>
	</div>
<?php endif; ?>

<div class="mvweb-submit">
	<button type="submit" name="submit" form="mvweb-tg-form-bot" class="mvweb-btn mvweb-btn--primary">
		<?php esc_html_e( 'Save changes', 'mvweb-telegram-hub' ); ?>
	</button>
</div>
