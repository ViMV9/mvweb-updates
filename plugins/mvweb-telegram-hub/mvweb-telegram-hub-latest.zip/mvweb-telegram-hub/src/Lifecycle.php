<?php
/**
 * Activation and deactivation handlers.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub;

use MVweb\Telegram\Hub\Log\Cleanup;
use MVweb\Telegram\Hub\Log\Table;
use MVweb\Telegram\Hub\Queue\Dispatcher;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sets the plugin up and takes it back down cleanly.
 *
 * Neither handler touches stored settings or the log — removing data is the
 * uninstall step, and only when the operator asked for it.
 *
 * @since 1.0.0
 */
final class Lifecycle {

	/**
	 * Prepare storage and schedules.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function activate() {
		self::guard_environment();

		Table::install();

		add_option( Settings::OPTION, Settings::defaults(), '', true );

		Cleanup::schedule();
	}

	/**
	 * Stop background work. Data stays untouched.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function deactivate() {
		Cleanup::unschedule();
		Dispatcher::cancel_all();
	}

	/**
	 * Refuse to activate on an environment we do not support.
	 *
	 * WooCommerce itself is handled by the "Requires Plugins" header and, at
	 * runtime, by the module's own requirement check.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function guard_environment() {
		global $wp_version;

		$problem = '';

		if ( version_compare( PHP_VERSION, MVWEB_TG_MIN_PHP, '<' ) ) {
			$problem = sprintf(
				/* translators: 1: required PHP version, 2: current PHP version. */
				__( 'MVweb Telegram Hub needs PHP %1$s or newer. This server runs PHP %2$s.', 'mvweb-telegram-hub' ),
				MVWEB_TG_MIN_PHP,
				PHP_VERSION
			);
		} elseif ( version_compare( $wp_version, MVWEB_TG_MIN_WP, '<' ) ) {
			$problem = sprintf(
				/* translators: 1: required WordPress version, 2: current WordPress version. */
				__( 'MVweb Telegram Hub needs WordPress %1$s or newer. This site runs WordPress %2$s.', 'mvweb-telegram-hub' ),
				MVWEB_TG_MIN_WP,
				$wp_version
			);
		}

		if ( '' === $problem ) {
			return;
		}

		deactivate_plugins( MVWEB_TG_BASENAME );

		wp_die(
			esc_html( $problem ),
			esc_html__( 'Plugin activation failed', 'mvweb-telegram-hub' ),
			array( 'back_link' => true )
		);
	}
}
