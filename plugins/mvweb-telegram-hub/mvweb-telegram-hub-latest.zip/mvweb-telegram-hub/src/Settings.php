<?php
/**
 * Settings storage and accessors.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Single source of truth for plugin options.
 *
 * Everything lives in one option array so a settings screen save is one write
 * and one autoloaded row.
 *
 * @since 1.0.0
 */
final class Settings {

	/**
	 * Option name holding every setting.
	 *
	 * @var string
	 */
	public const OPTION = 'mvweb_tg_settings';

	/**
	 * Option holding the log table schema version.
	 *
	 * @var string
	 */
	public const DB_VERSION_OPTION = 'mvweb_tg_db_version';

	/**
	 * Default Telegram Bot API host.
	 *
	 * @var string
	 */
	public const DEFAULT_API_BASE = 'https://api.telegram.org';

	/**
	 * Cached settings for this request.
	 *
	 * @var array|null
	 */
	private static $cache = null;

	/**
	 * Default values for every setting.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function defaults() {
		return array(
			'bot_token'      => '',
			'api_base'       => '',
			'modules'        => array( 'woo-orders' => true ),
			'recipients'     => array(),
			'order_template' => self::default_template(),
			'items_limit'    => 10,
			'log_days'       => 30,
			'delete_data'    => false,
		);
	}

	/**
	 * Default order message template.
	 *
	 * Translatable: the Russian catalogue ships the Russian wording.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function default_template() {
		/*
		 * One macro per line. Two of them on a shared line looked tidier until an
		 * order arrived without a payment method: the line is not empty, so it
		 * survives the empty-line rule, and the separator is left hanging on its
		 * own. A line that carries a single macro simply disappears with it.
		 */
		return __(
			"🛒 <b>Order #{order_number}</b>\n<i>{order_date}</i>\n\n💰 <b>{order_total}</b>\n💳 {payment_method}\n🚚 {shipping_method}\n\n<b>Items:</b>\n{order_items}\n\n👤 {customer_name}\n📞 {customer_phone}\n✉️ {customer_email}\n💬 {order_note}\n\n<a href=\"{admin_url}\">Open the order →</a>",
			'mvweb-telegram-hub'
		);
	}

	/**
	 * Get every setting, merged over defaults.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function all() {
		if ( null === self::$cache ) {
			$stored = get_option( self::OPTION, array() );
			if ( ! is_array( $stored ) ) {
				$stored = array();
			}
			self::$cache = array_merge( self::defaults(), $stored );
		}
		return self::$cache;
	}

	/**
	 * Get one setting.
	 *
	 * @since 1.0.0
	 * @param string $key      Setting key.
	 * @param mixed  $fallback Value returned when the key is unknown.
	 * @return mixed
	 */
	public static function get( $key, $fallback = null ) {
		$all = self::all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
	}

	/**
	 * Drop the in-request cache after a write.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function flush_cache() {
		self::$cache = null;
	}

	/**
	 * Whether the bot token comes from wp-config.php.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function token_is_constant() {
		return defined( 'MVWEB_TG_BOT_TOKEN' ) && '' !== (string) constant( 'MVWEB_TG_BOT_TOKEN' );
	}

	/**
	 * Get the bot token.
	 *
	 * A wp-config.php constant always wins over the stored value, so a client
	 * can keep the token out of database dumps.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function token() {
		if ( self::token_is_constant() ) {
			return (string) constant( 'MVWEB_TG_BOT_TOKEN' );
		}
		return (string) self::get( 'bot_token', '' );
	}

	/**
	 * Token with its middle replaced by an ellipsis, for display.
	 *
	 * The full token is never printed into admin HTML.
	 *
	 * @since 1.0.0
	 * @return string Empty string when no token is set.
	 */
	public static function masked_token() {
		$token = self::token();
		if ( '' === $token ) {
			return '';
		}
		if ( strlen( $token ) <= 18 ) {
			return str_repeat( '•', strlen( $token ) );
		}
		return substr( $token, 0, 10 ) . '…' . substr( $token, -4 );
	}

	/**
	 * Bot API base URL without a trailing slash.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function api_base() {
		$base = trim( (string) self::get( 'api_base', '' ) );
		if ( '' === $base ) {
			$base = self::DEFAULT_API_BASE;
		}
		return untrailingslashit( $base );
	}

	/**
	 * Configured recipients.
	 *
	 * @since 1.0.0
	 * @return string[] List of chat identifiers.
	 */
	public static function recipients() {
		$recipients = self::get( 'recipients', array() );
		return is_array( $recipients ) ? array_values( array_filter( $recipients ) ) : array();
	}

	/**
	 * Whether a module is switched on.
	 *
	 * @since 1.0.0
	 * @param string $slug Module slug.
	 * @return bool
	 */
	public static function module_enabled( $slug ) {
		$modules = self::get( 'modules', array() );
		return ! empty( $modules[ $slug ] );
	}

	/**
	 * Whether the plugin is configured well enough to send anything.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function is_ready() {
		return '' !== self::token() && array() !== self::recipients();
	}
}
