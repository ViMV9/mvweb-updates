<?php
/**
 * WooCommerce orders module.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Modules\WooOrders;

use MVweb\Telegram\Hub\Modules\ModuleInterface;
use MVweb\Telegram\Hub\Settings;
use MVweb\Telegram\Hub\Telegram\Formatter;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Notifies chats about new WooCommerce orders.
 *
 * @since 1.0.0
 */
final class Module implements ModuleInterface {

	/**
	 * Module slug.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function slug() {
		return 'woo-orders';
	}

	/**
	 * Module name for the settings screen.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function label() {
		return __( 'WooCommerce orders', 'mvweb-telegram-hub' );
	}

	/**
	 * WooCommerce must be active and recent enough.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function requirements_met() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return false;
		}

		if ( defined( 'WC_VERSION' ) ) {
			return version_compare( WC_VERSION, MVWEB_TG_MIN_WC, '>=' );
		}

		return true;
	}

	/**
	 * Explain why the module cannot run.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function requirement_message() {
		return sprintf(
			/* translators: 1: module name, 2: minimum WooCommerce version. */
			__( 'The “%1$s” module needs WooCommerce %2$s or newer to be active.', 'mvweb-telegram-hub' ),
			self::label(),
			MVWEB_TG_MIN_WC
		);
	}

	/**
	 * Hook the order triggers.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register() {
		( new Trigger() )->register();
	}

	/**
	 * Build the notification text for an order.
	 *
	 * @since 1.0.0
	 * @param int $object_id Order id.
	 * @return string|null Null when the order no longer exists.
	 */
	public function build_message( $object_id ) {
		$order = wc_get_order( absint( $object_id ) );

		if ( ! $order ) {
			return null;
		}

		$text = Macros::render( $order, (string) Settings::get( 'order_template', '' ) );

		/**
		 * Filter the order notification before it is sent.
		 *
		 * @since 1.0.0
		 * @param string    $text  Message in Telegram HTML.
		 * @param \WC_Order $order Order object.
		 */
		$text = (string) apply_filters( 'mvweb_tg_order_message', $text, $order );

		// {admin_url} usually sits at the end of the template, so a message that
		// gets cut loses the link exactly when it is needed most. Put it back as
		// part of the ellipsis — as a link, not a naked address.
		$suffix = sprintf(
			"…\n\n<a href=\"%s\">%s</a>",
			Formatter::escape( $order->get_edit_order_url() ),
			Formatter::escape( __( 'Open the order →', 'mvweb-telegram-hub' ) )
		);

		return Formatter::truncate( $text, Formatter::SAFE_LIMIT, $suffix );
	}
}
