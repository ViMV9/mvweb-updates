<?php
/**
 * Order triggers.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Modules\WooOrders;

use MVweb\Telegram\Hub\Queue\Dispatcher;
use MVweb\Telegram\Hub\Settings;
use WC_Order;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Decides which orders produce a notification.
 *
 * Only orders placed by a shopper count. Both checkout flows are covered:
 * the classic one and the block checkout, which goes through the Store API.
 *
 * woocommerce_new_order is deliberately not used — several gateways fire it
 * before line items are written, which would send an empty order to the chat.
 *
 * @since 1.0.0
 */
final class Trigger {

	/**
	 * Order meta flag marking a queued notification.
	 *
	 * @var string
	 */
	public const META_SENT = '_mvweb_tg_sent';

	/**
	 * Hook both checkout flows.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register() {
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'on_checkout' ), 10, 3 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'on_store_api' ), 10, 1 );
	}

	/**
	 * Classic checkout.
	 *
	 * @since 1.0.0
	 * @param int      $order_id    Order id.
	 * @param array    $posted_data Submitted checkout fields. Unused.
	 * @param WC_Order $order       Order object.
	 * @return void
	 */
	public function on_checkout( $order_id, $posted_data, $order ) {
		unset( $posted_data );

		if ( ! $order instanceof WC_Order ) {
			$order = wc_get_order( $order_id );
		}

		$this->maybe_dispatch( $order );
	}

	/**
	 * Block checkout (Store API).
	 *
	 * @since 1.0.0
	 * @param WC_Order $order Order object.
	 * @return void
	 */
	public function on_store_api( $order ) {
		$this->maybe_dispatch( $order );
	}

	/**
	 * Queue the notification unless this order already has one.
	 *
	 * The flag is written before dispatching, not after: a gateway that fires
	 * both checkout hooks would otherwise queue the order twice.
	 *
	 * @since 1.0.0
	 * @param mixed $order Order object or anything else.
	 * @return void
	 */
	private function maybe_dispatch( $order ) {
		if ( ! $order instanceof WC_Order ) {
			return;
		}

		if ( ! Settings::is_ready() ) {
			return;
		}

		if ( '' !== (string) $order->get_meta( self::META_SENT ) ) {
			return;
		}

		$order->update_meta_data( self::META_SENT, (string) time() );
		$order->save();

		Dispatcher::dispatch( Module::slug(), $order->get_id() );
	}
}
