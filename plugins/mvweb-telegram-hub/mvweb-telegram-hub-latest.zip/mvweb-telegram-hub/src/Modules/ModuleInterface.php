<?php
/**
 * Contract every notification module implements.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Modules;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * A module turns a site event into a Telegram message.
 *
 * The queue only needs two things from a module: a way to hook its triggers
 * and a way to rebuild the message text at delivery time.
 *
 * @since 1.0.0
 */
interface ModuleInterface {

	/**
	 * Module slug, used in settings and in log rows.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function slug();

	/**
	 * Human-readable module name.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function label();

	/**
	 * Whether the environment can run this module.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function requirements_met();

	/**
	 * Message shown when requirements_met() is false.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function requirement_message();

	/**
	 * Hook the module's triggers.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register();

	/**
	 * Build the message for an object.
	 *
	 * @since 1.0.0
	 * @param int $object_id Related object id.
	 * @return string|null Message in Telegram HTML, or null when unavailable.
	 */
	public function build_message( $object_id );
}
