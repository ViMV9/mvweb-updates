<?php
/**
 * Module registry.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Modules;

use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Knows which modules exist and which of them may run.
 *
 * Adding a module from the roadmap means one more entry in MODULES — the core
 * needs no changes.
 *
 * @since 1.0.0
 */
final class Registry {

	/**
	 * Available modules, slug => class name.
	 *
	 * @var array<string, class-string<ModuleInterface>>
	 */
	private const MODULES = array(
		'woo-orders' => WooOrders\Module::class,
	);

	/**
	 * Booted module instances, slug => object.
	 *
	 * @var array<string, ModuleInterface>
	 */
	private static $active = array();

	/**
	 * Instantiate and register every enabled module whose requirements are met.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function boot() {
		foreach ( self::MODULES as $slug => $class ) {
			if ( ! Settings::module_enabled( $slug ) ) {
				continue;
			}
			if ( ! $class::requirements_met() ) {
				continue;
			}

			$module = new $class();
			$module->register();

			self::$active[ $slug ] = $module;
		}
	}

	/**
	 * Get a module instance by slug.
	 *
	 * Falls back to instantiating the class so a queued job still resolves when
	 * the module was not booted in this request. A module switched off in the
	 * meantime returns null, so jobs queued before that stop sending.
	 *
	 * @since 1.0.0
	 * @param string $slug Module slug.
	 * @return ModuleInterface|null
	 */
	public static function get( $slug ) {
		if ( isset( self::$active[ $slug ] ) ) {
			return self::$active[ $slug ];
		}

		if ( ! isset( self::MODULES[ $slug ] ) ) {
			return null;
		}

		if ( ! Settings::module_enabled( $slug ) ) {
			return null;
		}

		$class = self::MODULES[ $slug ];

		return $class::requirements_met() ? new $class() : null;
	}

	/**
	 * All module slugs with their labels, for the settings screen.
	 *
	 * @since 1.0.0
	 * @return array<string, string>
	 */
	public static function labels() {
		$labels = array();
		foreach ( self::MODULES as $slug => $class ) {
			$labels[ $slug ] = $class::label();
		}
		return $labels;
	}

	/**
	 * Messages for modules that are switched on but cannot run.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	public static function unmet_requirements() {
		$messages = array();

		foreach ( self::MODULES as $slug => $class ) {
			if ( Settings::module_enabled( $slug ) && ! $class::requirements_met() ) {
				$messages[] = $class::requirement_message();
			}
		}

		return $messages;
	}
}
