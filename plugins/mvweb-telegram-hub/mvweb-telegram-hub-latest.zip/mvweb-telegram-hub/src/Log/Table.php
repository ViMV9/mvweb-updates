<?php
/**
 * Delivery log table schema.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Log;

use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Owns the wp_mvweb_tg_log table.
 *
 * @since 1.0.0
 */
final class Table {

	/**
	 * Schema version. Bump when the CREATE TABLE below changes.
	 *
	 * @var string
	 */
	public const SCHEMA_VERSION = '1.0.0';

	/**
	 * Fully-qualified table name.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function name() {
		global $wpdb;
		return $wpdb->prefix . 'mvweb_tg_log';
	}

	/**
	 * Create or update the table when the schema version moved.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function maybe_install() {
		if ( get_option( Settings::DB_VERSION_OPTION ) === self::SCHEMA_VERSION ) {
			return;
		}

		self::install();
	}

	/**
	 * Run dbDelta for the log table.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function install() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$table   = self::name();
		$collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			created_at datetime NOT NULL,
			module varchar(32) NOT NULL DEFAULT '',
			object_id bigint(20) unsigned NOT NULL DEFAULT 0,
			chat_id varchar(64) NOT NULL DEFAULT '',
			attempt tinyint(3) unsigned NOT NULL DEFAULT 0,
			status varchar(16) NOT NULL DEFAULT '',
			error_code int(11) NOT NULL DEFAULT 0,
			error_message text NOT NULL,
			PRIMARY KEY  (id),
			KEY created_at (created_at),
			KEY object_id (object_id)
		) {$collate};";

		dbDelta( $sql );

		update_option( Settings::DB_VERSION_OPTION, self::SCHEMA_VERSION, false );
	}

	/**
	 * Drop the table. Only called from uninstall.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function drop() {
		global $wpdb;

		$sql = $wpdb->prepare( 'DROP TABLE IF EXISTS %i', self::name() );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- prepared above.
		$wpdb->query( $sql );

		delete_option( Settings::DB_VERSION_OPTION );
	}
}
