<?php
/**
 * Delivery log reads and writes.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Log;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Stores failed and retried deliveries.
 *
 * Successful sends are deliberately not logged: the order already carries the
 * _mvweb_tg_sent flag, and a busy shop would fill the table with rows nobody
 * ever reads. Raw API responses are not stored either — they echo the message
 * text back, which would turn the log into a store of customer personal data.
 *
 * Queries use the %i identifier placeholder, so the table name goes through
 * $wpdb->prepare() like any other value.
 *
 * @since 1.0.0
 */
final class Repository {

	/**
	 * Status for an attempt that will be tried again.
	 *
	 * @var string
	 */
	public const STATUS_RETRY = 'retry';

	/**
	 * Status for an attempt after which the plugin gave up.
	 *
	 * @var string
	 */
	public const STATUS_FAILED = 'failed';

	/**
	 * Record one failed attempt.
	 *
	 * @since 1.0.0
	 * @param array $row {
	 *     Row data.
	 *
	 *     @type string $module        Module slug.
	 *     @type int    $object_id     Related object, e.g. order id.
	 *     @type string $chat_id       Recipient.
	 *     @type int    $attempt       Attempt number, 1-based.
	 *     @type string $status        One of the STATUS_* constants.
	 *     @type int    $error_code    Telegram or HTTP code.
	 *     @type string $error_message Description from Telegram.
	 * }
	 * @return void
	 */
	public static function add( array $row ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- custom plugin table, no core API covers it.
		$wpdb->insert(
			Table::name(),
			array(
				'created_at'    => current_time( 'mysql', true ),
				'module'        => isset( $row['module'] ) ? substr( (string) $row['module'], 0, 32 ) : '',
				'object_id'     => isset( $row['object_id'] ) ? absint( $row['object_id'] ) : 0,
				'chat_id'       => isset( $row['chat_id'] ) ? substr( (string) $row['chat_id'], 0, 64 ) : '',
				'attempt'       => isset( $row['attempt'] ) ? absint( $row['attempt'] ) : 0,
				'status'        => isset( $row['status'] ) ? substr( (string) $row['status'], 0, 16 ) : '',
				'error_code'    => isset( $row['error_code'] ) ? (int) $row['error_code'] : 0,
				'error_message' => isset( $row['error_message'] ) ? (string) $row['error_message'] : '',
			),
			array( '%s', '%s', '%d', '%s', '%d', '%s', '%d', '%s' )
		);
	}

	/**
	 * Fetch a page of log rows, newest first.
	 *
	 * @since 1.0.0
	 * @param array $args {
	 *     Query arguments.
	 *
	 *     @type int $order_id   Filter by related object id.
	 *     @type int $error_code Filter by Telegram or HTTP code.
	 *     @type int $per_page   Rows per page.
	 *     @type int $page       1-based page number.
	 * }
	 * @return array[] Log rows as associative arrays.
	 */
	public static function query( array $args = array() ) {
		global $wpdb;

		$per_page = isset( $args['per_page'] ) ? max( 1, absint( $args['per_page'] ) ) : 20;
		$page     = isset( $args['page'] ) ? max( 1, absint( $args['page'] ) ) : 1;
		$offset   = ( $page - 1 ) * $per_page;

		list( $where, $params ) = self::filters( $args );

		// phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- the sniff cannot count through array_merge(); prepare() takes the values as one array.
		$sql = $wpdb->prepare(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where is built from fixed fragments, its values are in $params.
			"SELECT * FROM %i {$where} ORDER BY id DESC LIMIT %d OFFSET %d",
			array_merge( array( Table::name() ), $params, array( $per_page, $offset ) )
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- prepared above.
		$rows = $wpdb->get_results( $sql, ARRAY_A );

		return is_array( $rows ) ? $rows : array();
	}

	/**
	 * Total number of rows matching the same filters as query().
	 *
	 * @since 1.0.0
	 * @param array $args Same filter keys as query().
	 * @return int
	 */
	public static function count( array $args = array() ) {
		global $wpdb;

		list( $where, $params ) = self::filters( $args );

		$sql = $wpdb->prepare(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $where is built from fixed fragments, its values are in $params.
			"SELECT COUNT(*) FROM %i {$where}",
			array_merge( array( Table::name() ), $params )
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- prepared above.
		return (int) $wpdb->get_var( $sql );
	}

	/**
	 * Build the WHERE clause and its bound values.
	 *
	 * @since 1.0.0
	 * @param array $args Filter arguments.
	 * @return array{0:string,1:array} Clause and parameters.
	 */
	private static function filters( array $args ) {
		$clauses = array();
		$params  = array();

		if ( ! empty( $args['order_id'] ) ) {
			$clauses[] = 'object_id = %d';
			$params[]  = absint( $args['order_id'] );
		}

		if ( ! empty( $args['error_code'] ) ) {
			$clauses[] = 'error_code = %d';
			$params[]  = (int) $args['error_code'];
		}

		$where = $clauses ? 'WHERE ' . implode( ' AND ', $clauses ) : '';

		return array( $where, $params );
	}

	/**
	 * Distinct error codes present in the log, for the filter dropdown.
	 *
	 * @since 1.0.0
	 * @return int[]
	 */
	public static function error_codes() {
		global $wpdb;

		$sql = $wpdb->prepare( 'SELECT DISTINCT error_code FROM %i ORDER BY error_code ASC', Table::name() );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- prepared above.
		$codes = $wpdb->get_col( $sql );

		return is_array( $codes ) ? array_map( 'intval', $codes ) : array();
	}

	/**
	 * Delete rows older than the given number of days.
	 *
	 * @since 1.0.0
	 * @param int $days Retention window in days.
	 * @return int Rows removed.
	 */
	public static function purge_older_than( $days ) {
		global $wpdb;

		$days   = max( 1, absint( $days ) );
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

		$sql = $wpdb->prepare( 'DELETE FROM %i WHERE created_at < %s', Table::name(), $cutoff );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- prepared above.
		return (int) $wpdb->query( $sql );
	}

	/**
	 * Remove every row.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function clear() {
		global $wpdb;

		$sql = $wpdb->prepare( 'TRUNCATE TABLE %i', Table::name() );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- prepared above.
		$wpdb->query( $sql );
	}
}
