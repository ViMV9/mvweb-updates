<?php
/**
 * Scheduled log rotation.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Log;

use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Trims the log daily so the table never grows without bound.
 *
 * Daily rather than "once per retention window": deleting a little every day
 * keeps the table small and each DELETE cheap.
 *
 * @since 1.0.0
 */
final class Cleanup {

	/**
	 * Cron hook name.
	 *
	 * @var string
	 */
	public const HOOK = 'mvweb_tg_cleanup_log';

	/**
	 * Hook the cron handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register() {
		add_action( self::HOOK, array( $this, 'run' ) );
	}

	/**
	 * Delete rows older than the configured retention window.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function run() {
		Repository::purge_older_than( (int) Settings::get( 'log_days', 30 ) );
	}

	/**
	 * Schedule the daily event if it is not scheduled yet.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', self::HOOK );
		}
	}

	/**
	 * Remove the scheduled event.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function unschedule() {
		wp_clear_scheduled_hook( self::HOOK );
	}
}
