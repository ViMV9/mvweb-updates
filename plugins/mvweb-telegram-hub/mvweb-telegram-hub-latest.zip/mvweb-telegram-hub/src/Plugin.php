<?php
/**
 * Plugin orchestrator.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub;

use MVweb\Telegram\Hub\Admin\Page;
use MVweb\Telegram\Hub\Log\Cleanup;
use MVweb\Telegram\Hub\Log\Table;
use MVweb\Telegram\Hub\Modules\Registry;
use MVweb\Telegram\Hub\Queue\Worker;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Boots the plugin subsystems.
 *
 * The core (settings screen, bot client, log) works on its own. Modules are
 * optional and each one declares its own requirements.
 *
 * @since 1.0.0
 */
final class Plugin {

	/**
	 * Singleton instance.
	 *
	 * @var Plugin|null
	 */
	private static $instance = null;

	/**
	 * Whether boot() already ran.
	 *
	 * @var bool
	 */
	private $booted = false;

	/**
	 * Get the singleton instance.
	 *
	 * @since 1.0.0
	 * @return Plugin
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Private constructor — use instance().
	 *
	 * @since 1.0.0
	 */
	private function __construct() {}

	/**
	 * Wire up every subsystem.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function boot() {
		if ( $this->booted ) {
			return;
		}
		$this->booted = true;

		/*
		 * Plugin updates do not fire the activation hook, so the schema check
		 * belongs here — but only where the table is actually touched. The row
		 * it reads is not autoloaded, so on a storefront hit it would be one
		 * extra query per request for a migration that cannot be needed there:
		 * the log is written from the queue worker and read in the admin.
		 */
		if ( is_admin() || wp_doing_cron() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			Table::maybe_install();
		}

		// The queue worker must run in cron and CLI context too, not just admin.
		( new Worker() )->register();
		( new Cleanup() )->register();

		Registry::boot();

		if ( is_admin() ) {
			( new Page() )->register();
			add_action( 'admin_notices', array( $this, 'render_environment_notice' ) );
		}
	}

	/**
	 * Warn when an enabled module cannot run in the current environment.
	 *
	 * Only on the plugins list, and only for an enabled module: that is the one
	 * screen where the problem is invisible otherwise. The settings screen says
	 * the same thing in its own card, right above the settings it affects, so a
	 * notice there would be the same sentence twice — carrying a plugin-name
	 * prefix that only makes sense away from home.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function render_environment_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$screen = get_current_screen();

		if ( ! $screen || 'plugins' !== $screen->id ) {
			return;
		}

		foreach ( Registry::unmet_requirements() as $message ) {
			printf(
				'<div class="notice notice-warning"><p>%s</p></div>',
				esc_html( sprintf( '%s: %s', 'MVweb Telegram Hub', $message ) )
			);
		}
	}

	/**
	 * Prevent cloning of the singleton.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function __clone() {}

	/**
	 * Prevent unserializing of the singleton.
	 *
	 * @since 1.0.0
	 * @throws \LogicException Always.
	 * @return void
	 */
	public function __wakeup() {
		throw new \LogicException( 'Cannot unserialize a singleton.' );
	}
}
