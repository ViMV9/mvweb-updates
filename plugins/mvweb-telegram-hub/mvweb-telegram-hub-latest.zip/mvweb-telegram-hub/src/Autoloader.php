<?php
/**
 * PSR-4 autoloader for the MVweb\Telegram\Hub namespace.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Lightweight PSR-4 autoloader.
 *
 * Maps the MVweb\Telegram\Hub namespace to the plugin's src/ directory.
 *
 * @since 1.0.0
 */
final class Autoloader {

	/**
	 * Namespace prefix this autoloader is responsible for.
	 *
	 * @var string
	 */
	private const PREFIX = 'MVweb\\Telegram\\Hub\\';

	/**
	 * Register the autoloader with the SPL stack.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register() {
		spl_autoload_register( array( self::class, 'autoload' ) );
	}

	/**
	 * Resolve a fully-qualified class name to a file in src/.
	 *
	 * @since 1.0.0
	 * @param string $class_name Fully-qualified class name.
	 * @return void
	 */
	public static function autoload( $class_name ) {
		if ( 0 !== strpos( $class_name, self::PREFIX ) ) {
			return;
		}

		$relative = substr( $class_name, strlen( self::PREFIX ) );
		$path     = MVWEB_TG_PATH . 'src/' . str_replace( '\\', '/', $relative ) . '.php';

		if ( is_readable( $path ) ) {
			require $path;
		}
	}
}
