<?php
/**
 * Settings sanitisation.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Admin;

use MVweb\Telegram\Hub\Settings;
use MVweb\Telegram\Hub\Telegram\Client;
use MVweb\Telegram\Hub\Telegram\Formatter;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cleans everything that arrives from the settings screen.
 *
 * Each tab posts its own form, so the incoming array only carries the keys of
 * that tab. Values are therefore merged over what is already stored instead of
 * replacing the whole option — otherwise saving one tab would blank the rest.
 *
 * @since 1.0.0
 */
final class Sanitizer {

	/**
	 * Guard against WordPress calling the sanitiser twice in one request.
	 *
	 * @var bool
	 */
	private static $token_checked = false;

	/**
	 * Sanitise the posted settings.
	 *
	 * @since 1.0.0
	 * @param mixed $input Raw value from the form.
	 * @return array Full option array, ready to store.
	 */
	public static function sanitize( $input ) {
		$stored = Settings::all();
		$input  = is_array( $input ) ? $input : array();
		$clean  = $stored;

		// The API address is resolved first: both fields live on the same tab,
		// and verifying the token against the previous host would report a
		// false failure exactly where a custom proxy is being set up.
		if ( array_key_exists( 'api_base', $input ) ) {
			$clean['api_base'] = self::api_base( $input['api_base'] );
		}

		if ( array_key_exists( 'bot_token', $input ) ) {
			$clean['bot_token'] = self::token( $input['bot_token'], $stored['bot_token'], $clean['api_base'] );
		}

		if ( array_key_exists( 'modules', $input ) ) {
			$clean['modules'] = self::modules( $input['modules'] );
		}

		if ( array_key_exists( 'recipients', $input ) ) {
			$clean['recipients'] = self::recipients( $input['recipients'] );
		}

		if ( array_key_exists( 'order_template', $input ) ) {
			$clean['order_template'] = self::template( $input['order_template'] );
		}

		if ( array_key_exists( 'items_limit', $input ) ) {
			$clean['items_limit'] = self::in_range( $input['items_limit'], 1, 50, 10 );
		}

		if ( array_key_exists( 'log_days', $input ) ) {
			$clean['log_days'] = self::in_range( $input['log_days'], 1, 365, 30 );
		}

		if ( array_key_exists( 'delete_data', $input ) ) {
			$clean['delete_data'] = (bool) $input['delete_data'];
		}

		Settings::flush_cache();

		return $clean;
	}

	/**
	 * Validate the bot token and verify it against Telegram.
	 *
	 * An empty field means "leave it as it is", so the token never has to be
	 * rendered back into the page just to survive a save.
	 *
	 * @since 1.0.0
	 * @param mixed  $value    Posted value.
	 * @param string $existing Currently stored token.
	 * @param string $api_base API address being saved in the same request.
	 * @return string
	 */
	private static function token( $value, $existing, $api_base ) {
		$value = trim( sanitize_text_field( (string) $value ) );

		if ( '' === $value ) {
			return (string) $existing;
		}

		if ( ! preg_match( '/^\d{5,}:[A-Za-z0-9_-]{30,}$/', $value ) ) {
			add_settings_error(
				Page::NOTICE_SLUG,
				'mvweb_tg_token_format',
				__( 'That does not look like a bot token. Expected the format 1234567890:AA…, as issued by @BotFather.', 'mvweb-telegram-hub' ),
				'error'
			);
			return (string) $existing;
		}

		self::verify_token( $value, $api_base );

		return $value;
	}

	/**
	 * Ask Telegram who the token belongs to.
	 *
	 * A failure is reported but never blocks the save: on a host where
	 * Telegram is unreachable, blocking would make the settings unchangeable.
	 *
	 * @since 1.0.0
	 * @param string $token    Validated token.
	 * @param string $api_base API address to verify against.
	 * @return void
	 */
	private static function verify_token( $token, $api_base ) {
		if ( self::$token_checked ) {
			return;
		}
		self::$token_checked = true;

		$host = '' === $api_base ? null : $api_base;

		$response = ( new Client( $token, $host ) )->get_me();

		if ( empty( $response['ok'] ) ) {
			delete_transient( 'mvweb_tg_bot_info' );

			// The description comes from whatever host api_base points at, and
			// add_settings_error() output is printed by core as raw HTML.
			add_settings_error(
				Page::NOTICE_SLUG,
				'mvweb_tg_token_unverified',
				sprintf(
					/* translators: %s: error description from Telegram. */
					__( 'The token was saved, but Telegram did not accept it: %s', 'mvweb-telegram-hub' ),
					$response['description'] ? esc_html( $response['description'] ) : __( 'no response', 'mvweb-telegram-hub' )
				),
				'warning'
			);
			return;
		}

		$bot = array(
			'id'       => isset( $response['result']['id'] ) ? (int) $response['result']['id'] : 0,
			'username' => isset( $response['result']['username'] ) ? (string) $response['result']['username'] : '',
		);

		set_transient( 'mvweb_tg_bot_info', $bot, 12 * HOUR_IN_SECONDS );

		add_settings_error(
			Page::NOTICE_SLUG,
			'mvweb_tg_token_ok',
			sprintf(
				/* translators: %s: bot username. */
				__( 'Connected to @%s.', 'mvweb-telegram-hub' ),
				esc_html( $bot['username'] )
			),
			'success'
		);
	}

	/**
	 * Validate a custom API base URL.
	 *
	 * @since 1.0.0
	 * @param mixed $value Posted value.
	 * @return string Empty string means "use the default host".
	 */
	private static function api_base( $value ) {
		$value = trim( (string) $value );

		if ( '' === $value ) {
			return '';
		}

		$url = esc_url_raw( $value, array( 'https' ) );

		if ( '' === $url ) {
			add_settings_error(
				Page::NOTICE_SLUG,
				'mvweb_tg_api_base',
				__( 'The API address must be a full https:// URL. Falling back to api.telegram.org.', 'mvweb-telegram-hub' ),
				'error'
			);
			return '';
		}

		return untrailingslashit( $url );
	}

	/**
	 * Normalise the module toggles.
	 *
	 * @since 1.0.0
	 * @param mixed $value Posted value.
	 * @return array<string, bool>
	 */
	private static function modules( $value ) {
		$value  = is_array( $value ) ? $value : array();
		$result = array();

		foreach ( array_keys( \MVweb\Telegram\Hub\Modules\Registry::labels() ) as $slug ) {
			$result[ $slug ] = ! empty( $value[ $slug ] );
		}

		return $result;
	}

	/**
	 * Parse the recipients textarea.
	 *
	 * Accepts numeric chat ids (negative ones for groups and channels) and
	 * public channel handles. Anything else is reported and dropped.
	 *
	 * The value arrives as the raw textarea, but WordPress runs the sanitiser a
	 * second time inside update_option() — and by then it is the array this
	 * method returned. Casting that to a string yields the literal "Array",
	 * which then fails validation and reports itself as a rejected recipient.
	 *
	 * @since 1.0.0
	 * @param mixed $value Posted textarea, or the already parsed list.
	 * @return string[]
	 */
	private static function recipients( $value ) {
		$lines   = is_array( $value ) ? $value : preg_split( '/\R/u', (string) $value );
		$clean   = array();
		$invalid = array();

		foreach ( (array) $lines as $line ) {
			$line = trim( sanitize_text_field( $line ) );

			if ( '' === $line ) {
				continue;
			}

			if ( ! preg_match( '/^(-?\d+|@[A-Za-z][A-Za-z0-9_]{4,31})$/', $line ) ) {
				$invalid[] = $line;
				continue;
			}

			if ( ! in_array( $line, $clean, true ) ) {
				$clean[] = $line;
			}
		}

		if ( $invalid ) {
			add_settings_error(
				Page::NOTICE_SLUG,
				'mvweb_tg_recipients',
				sprintf(
					/* translators: %s: comma-separated list of rejected values. */
					__( 'These recipients were skipped — expected a chat number or an @name: %s', 'mvweb-telegram-hub' ),
					implode( ', ', array_map( 'esc_html', $invalid ) )
				),
				'error'
			);
		}

		return $clean;
	}

	/**
	 * Clean the message template.
	 *
	 * Only tags Telegram understands survive; anything else would make the API
	 * reject every notification.
	 *
	 * @since 1.0.0
	 * @param mixed $value Posted value.
	 * @return string
	 */
	private static function template( $value ) {
		// options.php already unslashed the value before update_option() reached
		// this callback; unslashing twice would eat the operator's backslashes.
		return trim( wp_kses( (string) $value, Formatter::allowed_tags() ) );
	}

	/**
	 * Clamp an integer into a range.
	 *
	 * @since 1.0.0
	 * @param mixed $value    Posted value.
	 * @param int   $min      Lower bound.
	 * @param int   $max      Upper bound.
	 * @param int   $fallback Used when the value is empty.
	 * @return int
	 */
	private static function in_range( $value, $min, $max, $fallback ) {
		$value = absint( $value );

		if ( ! $value ) {
			return $fallback;
		}

		return max( $min, min( $max, $value ) );
	}
}
