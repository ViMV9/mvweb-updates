<?php
/**
 * Settings API registration.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Admin;

use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the single option with the Settings API.
 *
 * Forms post to options.php, so WordPress itself handles the nonce, the
 * capability check and the call to the sanitiser. The markup is written by
 * hand in admin/views because the UI Kit layout does not match what
 * do_settings_sections() emits.
 *
 * @since 1.0.0
 */
final class Fields {

	/**
	 * Register the option.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register() {
		register_setting(
			Page::GROUP,
			Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( Sanitizer::class, 'sanitize' ),
				'default'           => Settings::defaults(),
				'show_in_rest'      => false,
			)
		);
	}
}
