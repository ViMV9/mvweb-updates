<?php
/**
 * Setup progress shown at the top of the settings screen.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Admin;

use MVweb\Telegram\Hub\Modules\WooOrders\Module;
use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Tells the operator where they are in the setup.
 *
 * Connecting the plugin takes four steps across two tabs, and each one is saved
 * on its own. Without a map of it the screen answers neither "what now" nor
 * "did the last save actually land".
 *
 * @since 1.0.0
 */
final class Setup {

	/**
	 * Option holding the time of the last successful test message.
	 *
	 * Kept out of the settings array: it is a fact about the site, not a
	 * setting, and it must not travel through the settings sanitiser.
	 *
	 * @var string
	 */
	public const TEST_OPTION = 'mvweb_tg_test_passed';

	/**
	 * Remember that a test message reached at least one recipient.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function mark_test_passed() {
		update_option( self::TEST_OPTION, time(), false );
	}

	/**
	 * The four steps, in the order they are meant to be done.
	 *
	 * @since 1.0.0
	 * @return array[] Each step: title, done, detail, tab.
	 */
	public static function steps() {
		$bot        = get_transient( 'mvweb_tg_bot_info' );
		$recipients = Settings::recipients();
		$module_on  = Settings::module_enabled( Module::slug() );
		$woo_ok     = Module::requirements_met();
		$tested     = (int) get_option( self::TEST_OPTION, 0 );
		$has_token  = '' !== Settings::token();
		$bot_name   = is_array( $bot ) && ! empty( $bot['username'] ) ? '@' . $bot['username'] : '';

		return array(
			array(
				'title'  => __( 'Connect a bot', 'mvweb-telegram-hub' ),
				'done'   => $has_token,
				'tab'    => 'bot',
				'detail' => $has_token
					? ( '' !== $bot_name
						/* translators: %s: bot username. */
						? sprintf( __( 'Bot %s is connected.', 'mvweb-telegram-hub' ), $bot_name )
						: __( 'The token is saved.', 'mvweb-telegram-hub' ) )
					: __( 'Create a bot with @BotFather and paste its token below.', 'mvweb-telegram-hub' ),
			),
			array(
				'title'  => __( 'Add recipients', 'mvweb-telegram-hub' ),
				'done'   => (bool) $recipients,
				'tab'    => 'orders',
				'detail' => $recipients
					? sprintf(
						/* translators: %d: number of recipients. */
						_n( '%d chat will receive orders.', '%d chats will receive orders.', count( $recipients ), 'mvweb-telegram-hub' ),
						count( $recipients )
					)
					: __( 'Say who gets a message about a new order.', 'mvweb-telegram-hub' ),
			),
			array(
				'title'  => __( 'Switch order notifications on', 'mvweb-telegram-hub' ),
				'done'   => $module_on && $woo_ok,
				'tab'    => 'bot',
				'detail' => self::module_detail( $module_on, $woo_ok ),
			),
			array(
				'title'  => __( 'Check with a test message', 'mvweb-telegram-hub' ),
				'done'   => $tested > 0,
				'tab'    => 'orders',
				'detail' => $tested > 0
					? sprintf(
						/* translators: %s: date and time of the last successful test. */
						__( 'Last delivered test: %s.', 'mvweb-telegram-hub' ),
						wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $tested )
					)
					: __( 'Make sure a message really arrives before a customer places an order.', 'mvweb-telegram-hub' ),
			),
		);
	}

	/**
	 * How many steps are done.
	 *
	 * @since 1.0.0
	 * @param array[] $steps Steps from steps().
	 * @return int
	 */
	public static function done_count( array $steps ) {
		return count(
			array_filter(
				$steps,
				static function ( $step ) {
					return ! empty( $step['done'] );
				}
			)
		);
	}

	/**
	 * Wording for the module step.
	 *
	 * @since 1.0.0
	 * @param bool $module_on Module toggle.
	 * @param bool $woo_ok    WooCommerce present and recent enough.
	 * @return string
	 */
	private static function module_detail( $module_on, $woo_ok ) {
		if ( ! $woo_ok ) {
			return __( 'WooCommerce is not active, so there are no orders to report.', 'mvweb-telegram-hub' );
		}

		return $module_on
			? __( 'New orders from the checkout are being sent.', 'mvweb-telegram-hub' )
			: __( 'The “WooCommerce orders” module is switched off below.', 'mvweb-telegram-hub' );
	}
}
