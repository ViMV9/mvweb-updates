<?php
/**
 * Settings screen.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Admin;

use MVweb_Menu;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers the settings page under the MVweb Hub and renders it.
 *
 * @since 1.0.0
 */
final class Page {

	/**
	 * Capability required for the whole screen.
	 *
	 * The bot token lives here, and it is the key to the client's chats.
	 *
	 * @var string
	 */
	public const CAPABILITY = 'manage_options';

	/**
	 * Settings group used by register_setting() and settings_fields().
	 *
	 * @var string
	 */
	public const GROUP = 'mvweb_tg_settings_group';

	/**
	 * Slug used by add_settings_error() and settings_errors().
	 *
	 * @var string
	 */
	public const NOTICE_SLUG = 'mvweb_tg_messages';

	/**
	 * Hook suffix returned by add_submenu_page().
	 *
	 * @var string
	 */
	private static $hook_suffix = '';

	/**
	 * Hook the admin screen.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register() {
		add_action( 'admin_menu', array( $this, 'register_menu' ), 11 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_init', array( Fields::class, 'register' ) );

		( new Actions() )->register();
	}

	/**
	 * Add the submenu entry under the MVweb Hub.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register_menu() {
		$parent = class_exists( 'MVweb_Menu' ) && method_exists( 'MVweb_Menu', 'get_menu_slug' )
			? MVweb_Menu::get_menu_slug()
			: 'mvweb-hub';

		self::$hook_suffix = add_submenu_page(
			$parent,
			__( 'MVweb Telegram Hub', 'mvweb-telegram-hub' ),
			__( 'Telegram Hub', 'mvweb-telegram-hub' ),
			self::CAPABILITY,
			MVWEB_TG_SLUG,
			array( $this, 'render' )
		);
	}

	/**
	 * Load the UI Kit and the plugin styles on this screen only.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook suffix.
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		if ( '' === self::$hook_suffix || $hook !== self::$hook_suffix ) {
			return;
		}

		wp_enqueue_style(
			'mvweb-tg-admin',
			MVWEB_TG_URL . 'admin/css/admin.min.css',
			array(),
			self::asset_version( 'admin/css/admin.min.css' )
		);
		wp_enqueue_style(
			'mvweb-tg-plugin',
			MVWEB_TG_URL . 'admin/css/plugin.min.css',
			array( 'mvweb-tg-admin' ),
			self::asset_version( 'admin/css/plugin.min.css' )
		);
		wp_enqueue_script(
			'mvweb-tg-admin',
			MVWEB_TG_URL . 'admin/js/admin.min.js',
			array(),
			self::asset_version( 'admin/js/admin.min.js' ),
			true
		);
	}

	/**
	 * Render the settings page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function render() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}

		require MVWEB_TG_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Admin URL of one tab of this screen.
	 *
	 * @since 1.0.0
	 * @param string $tab Tab slug.
	 * @return string
	 */
	public static function tab_url( $tab ) {
		return admin_url( 'admin.php?page=' . MVWEB_TG_SLUG . '&tab=' . rawurlencode( $tab ) );
	}

	/**
	 * Point the post-save redirect at the tab the form belongs to.
	 *
	 * Core writes a _wp_http_referer field holding the URL the page was opened
	 * with, which carries no tab — so saving the orders tab would land the
	 * operator back on the bot tab. Printing the field again after it wins,
	 * because the later value is the one PHP keeps.
	 *
	 * @since 1.0.0
	 * @param string $tab Tab slug.
	 * @return void
	 */
	public static function referer_field( $tab ) {
		printf(
			'<input type="hidden" name="_wp_http_referer" value="%s">',
			esc_attr( self::tab_url( $tab ) )
		);
	}

	/**
	 * Print a question-mark tip next to a field label.
	 *
	 * The long explanation belongs in the tip, not under the field: a screen
	 * where every row carries three lines of prose reads as a manual, and the
	 * operator stops seeing the fields themselves.
	 *
	 * @since 1.0.0
	 * @param string $text Explanation shown on hover.
	 * @return void
	 */
	public static function help_tip( $text ) {
		printf(
			'<button type="button" class="mvweb-help-tip" title="%1$s" aria-label="%1$s">'
				. '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true" focusable="false">'
				. '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>'
				. '</svg></button>',
			esc_attr( $text )
		);
	}

	/**
	 * Cache-busting version for an asset.
	 *
	 * @since 1.0.0
	 * @param string $relative Path relative to the plugin root.
	 * @return string
	 */
	private static function asset_version( $relative ) {
		$path  = MVWEB_TG_PATH . $relative;
		$mtime = file_exists( $path ) ? filemtime( $path ) : 0;

		return $mtime ? (string) $mtime : MVWEB_TG_VERSION;
	}
}
