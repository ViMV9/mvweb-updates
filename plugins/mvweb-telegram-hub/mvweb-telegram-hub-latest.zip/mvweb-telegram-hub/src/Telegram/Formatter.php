<?php
/**
 * Message formatting helpers for Telegram HTML.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Telegram;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Escapes, sanitises and truncates Telegram HTML messages.
 *
 * @since 1.0.0
 */
final class Formatter {

	/**
	 * Hard limit Telegram enforces on a message.
	 *
	 * @var int
	 */
	public const HARD_LIMIT = 4096;

	/**
	 * Length we truncate to, leaving room for the ellipsis and the order link.
	 *
	 * @var int
	 */
	public const SAFE_LIMIT = 4000;

	/**
	 * Tags Telegram understands in HTML parse mode.
	 *
	 * Used as the wp_kses whitelist for the user-editable template.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function allowed_tags() {
		return array(
			'b'      => array(),
			'strong' => array(),
			'i'      => array(),
			'em'     => array(),
			'u'      => array(),
			's'      => array(),
			'code'   => array(),
			'pre'    => array(),
			'a'      => array( 'href' => array() ),
		);
	}

	/**
	 * Escape a macro value for Telegram HTML.
	 *
	 * Telegram only requires &, < and > to be escaped. Product titles routinely
	 * contain those characters, and an unescaped one makes the API reject the
	 * whole message with a 400.
	 *
	 * @since 1.0.0
	 * @param string $value Raw value.
	 * @return string
	 */
	public static function escape( $value ) {
		return str_replace(
			array( '&', '<', '>' ),
			array( '&amp;', '&lt;', '&gt;' ),
			(string) $value
		);
	}

	/**
	 * Tidy up the whitespace of a rendered message.
	 *
	 * Dropping lines whose macros came out empty is the caller's job — only it
	 * knows which macros a line carried. Judging that here, on the rendered
	 * text, would also delete honest headings such as "<b>Items:</b>".
	 *
	 * @since 1.0.0
	 * @param string $text Message after macro substitution.
	 * @return string
	 */
	public static function tidy( $text ) {
		$lines = preg_split( '/\R/u', (string) $text );
		$kept  = array();

		foreach ( (array) $lines as $line ) {
			$kept[] = rtrim( $line );
		}

		$text = implode( "\n", $kept );

		// Never leave more than one blank line in a row.
		$text = preg_replace( "/\n{3,}/u", "\n\n", $text );

		return trim( (string) $text );
	}

	/**
	 * Truncate a Telegram HTML message without breaking its markup.
	 *
	 * Cutting mid-tag or leaving a tag unclosed makes Telegram reject the
	 * message outright, so the whole notification would be lost — worse than a
	 * shortened one. This walks tags and text separately, cuts inside text only
	 * and closes whatever is still open.
	 *
	 * @since 1.0.0
	 * @param string $html   Message in Telegram HTML.
	 * @param int    $limit  Maximum visible length.
	 * @param string $suffix Appended when the message was cut.
	 * @return string
	 */
	public static function truncate( $html, $limit = self::SAFE_LIMIT, $suffix = '…' ) {
		$html  = (string) $html;
		$limit = (int) $limit;

		if ( mb_strlen( wp_strip_all_tags( $html ) ) <= $limit ) {
			return $html;
		}

		$tokens = preg_split( '/(<[^>]*>)/u', $html, -1, PREG_SPLIT_DELIM_CAPTURE | PREG_SPLIT_NO_EMPTY );
		$out    = '';
		$stack  = array();
		$used   = 0;
		$cut    = false;

		foreach ( (array) $tokens as $token ) {
			if ( '<' === substr( $token, 0, 1 ) ) {
				$out .= $token;

				if ( preg_match( '#^</\s*([a-z]+)#i', $token, $m ) ) {
					$open = array_search( strtolower( $m[1] ), $stack, true );
					if ( false !== $open ) {
						unset( $stack[ $open ] );
						$stack = array_values( $stack );
					}
				} elseif ( preg_match( '#^<\s*([a-z]+)#i', $token, $m ) ) {
					$stack[] = strtolower( $m[1] );
				}

				continue;
			}

			$length = mb_strlen( $token );

			if ( $used + $length <= $limit ) {
				$out  .= $token;
				$used += $length;
				continue;
			}

			$out .= mb_substr( $token, 0, max( 0, $limit - $used ) );
			$cut  = true;
			break;
		}

		if ( $cut ) {
			// The cut can land inside an escaped entity. A bare "&" or a stub
			// like "&am" is invalid Telegram HTML and gets the whole message
			// rejected with a 400, so the fragment goes.
			$out = preg_replace( '/&[#a-zA-Z0-9]{0,9}$/', '', rtrim( $out ) );
			$out = rtrim( (string) $out ) . $suffix;
		}

		// Close whatever the cut left open, innermost first.
		foreach ( array_reverse( $stack ) as $tag ) {
			$out .= '</' . $tag . '>';
		}

		return $out;
	}
}
