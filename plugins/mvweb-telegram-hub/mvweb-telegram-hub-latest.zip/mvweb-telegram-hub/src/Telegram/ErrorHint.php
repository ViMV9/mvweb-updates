<?php
/**
 * Turns a Telegram API error into an instruction the shop owner can follow.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Telegram;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Human advice for a failed delivery.
 *
 * Telegram answers in English developer prose — "Forbidden: bot was blocked by
 * the user" tells a shop owner nothing about what to press. The raw text is
 * still shown, this only adds the next step.
 *
 * @since 1.0.0
 */
final class ErrorHint {

	/**
	 * Advice for one failure, or an empty string when there is nothing useful
	 * to add.
	 *
	 * @since 1.0.0
	 * @param int    $code    HTTP status Telegram returned, 0 for a network error.
	 * @param string $message Description Telegram returned.
	 * @return string
	 */
	public static function get( $code, $message = '' ) {
		$code    = (int) $code;
		$message = strtolower( (string) $message );

		if ( 0 === $code ) {
			return __( 'The site could not reach Telegram at all. Usually the host blocks outgoing connections — ask the hosting support, or set your own proxy in “Custom API address” on the Bot tab.', 'mvweb-telegram-hub' );
		}

		foreach ( self::by_message() as $needle => $hint ) {
			if ( false !== strpos( $message, $needle ) ) {
				return $hint;
			}
		}

		$by_code = self::by_code();

		if ( isset( $by_code[ $code ] ) ) {
			return $by_code[ $code ];
		}

		if ( $code >= 500 ) {
			return __( 'Telegram itself was down for a moment. The plugin retries on its own, nothing to do here.', 'mvweb-telegram-hub' );
		}

		return '';
	}

	/**
	 * Advice keyed by a fragment of the Telegram description.
	 *
	 * Matched before the status code, because one 400 covers a dozen very
	 * different mistakes.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private static function by_message() {
		return array(
			'chat not found'          => __( 'No such chat. Check the ID: group and channel IDs start with a minus sign, and the bot has to be added to the chat first.', 'mvweb-telegram-hub' ),
			'bot was blocked'         => __( 'The recipient blocked the bot. They need to open the chat with it and press “Restart”.', 'mvweb-telegram-hub' ),
			'user is deactivated'     => __( 'That Telegram account is deleted. Remove the ID from the recipients list.', 'mvweb-telegram-hub' ),
			'bot is not a member'     => __( 'The bot is not in that group or channel. Add it and — in a channel — give it the right to post messages.', 'mvweb-telegram-hub' ),
			'not enough rights'       => __( 'The bot is in the chat but is not allowed to write there. Give it the “Post messages” right in the chat settings.', 'mvweb-telegram-hub' ),
			'need administrator'      => __( 'The bot has to be an administrator of the channel to post in it.', 'mvweb-telegram-hub' ),
			'chat_id is empty'        => __( 'The recipient line is empty. Remove the blank line on the WooCommerce orders tab.', 'mvweb-telegram-hub' ),
			'unauthorized'            => __( 'Telegram rejected the token. Copy it from @BotFather again — the whole line, including the part before the colon.', 'mvweb-telegram-hub' ),
			"can't parse entities"    => __( 'The message template has broken HTML. Only these tags work: b, strong, i, em, u, s, code, pre, a — and every tag must be closed.', 'mvweb-telegram-hub' ),
			'unsupported start tag'   => __( 'The message template uses a tag Telegram does not know. Allowed: b, strong, i, em, u, s, code, pre, a.', 'mvweb-telegram-hub' ),
			'message is too long'     => __( 'The message went over the Telegram limit. Lower “Line items to show” or shorten the template.', 'mvweb-telegram-hub' ),
			'too many requests'       => __( 'Too many messages at once, Telegram asked to slow down. The plugin waits and retries by itself.', 'mvweb-telegram-hub' ),
			'group chat was upgraded' => __( 'The group was upgraded to a supergroup and got a new ID. Replace the old ID in the recipients list.', 'mvweb-telegram-hub' ),
		);
	}

	/**
	 * Fallback advice keyed by status code.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	private static function by_code() {
		return array(
			400 => __( 'Telegram refused the request. Most often the chat ID is wrong or the message template has broken HTML.', 'mvweb-telegram-hub' ),
			401 => __( 'The bot token is wrong or was revoked. Get a fresh one from @BotFather.', 'mvweb-telegram-hub' ),
			403 => __( 'The bot is not allowed to write to that chat. Ask the recipient to press “Start”, or add the bot to the group or channel.', 'mvweb-telegram-hub' ),
			404 => __( 'Telegram did not recognise the request. Check “Custom API address” on the Bot tab — if it is filled in, the proxy is answering incorrectly.', 'mvweb-telegram-hub' ),
			429 => __( 'Too many messages at once, Telegram asked to slow down. The plugin waits and retries by itself.', 'mvweb-telegram-hub' ),
		);
	}
}
