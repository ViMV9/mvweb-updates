<?php
/**
 * Queues Telegram deliveries.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Queue;

use MVweb\Telegram\Hub\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Puts one job per recipient onto the queue.
 *
 * Nothing is sent on the checkout request itself: the shopper must never wait
 * for api.telegram.org. Action Scheduler ships with WooCommerce, so this adds
 * no new dependency and the queue is visible under WooCommerce → Status →
 * Scheduled Actions.
 *
 * @since 1.0.0
 */
final class Dispatcher {

	/**
	 * Action hook the worker listens on.
	 *
	 * @var string
	 */
	public const HOOK = 'mvweb_tg_send';

	/**
	 * Action Scheduler group.
	 *
	 * @var string
	 */
	public const GROUP = 'mvweb-tg';

	/**
	 * Queue a message for every configured recipient.
	 *
	 * @since 1.0.0
	 * @param string $module    Module slug that owns the message.
	 * @param int    $object_id Related object, e.g. an order id.
	 * @return int Number of jobs queued.
	 */
	public static function dispatch( $module, $object_id ) {
		$queued = 0;

		foreach ( Settings::recipients() as $chat_id ) {
			self::schedule(
				array(
					'module'    => (string) $module,
					'object_id' => absint( $object_id ),
					'chat_id'   => (string) $chat_id,
					'attempt'   => 1,
				),
				0
			);
			++$queued;
		}

		return $queued;
	}

	/**
	 * Schedule a single delivery job.
	 *
	 * The message text is not carried in the payload — the worker rebuilds it
	 * from the order, which keeps job arguments small and picks up template
	 * edits made between the order and the retry.
	 *
	 * @since 1.0.0
	 * @param array $payload Job payload.
	 * @param int   $delay   Seconds to wait before running.
	 * @return void
	 */
	public static function schedule( array $payload, $delay = 0 ) {
		$timestamp = time() + max( 0, (int) $delay );

		if ( function_exists( 'as_schedule_single_action' ) ) {
			as_schedule_single_action( $timestamp, self::HOOK, array( $payload ), self::GROUP );
			return;
		}

		// WooCommerce (and with it Action Scheduler) went away mid-flight.
		// WP-Cron is less reliable but better than dropping the notification.
		wp_schedule_single_event( $timestamp, self::HOOK, array( $payload ) );
	}

	/**
	 * Cancel every pending job of this plugin.
	 *
	 * Action Scheduler is asked by group with an empty hook: passing hook and
	 * group together sends it down the single-action path, which looks for a
	 * job with empty arguments and therefore never matches ours.
	 *
	 * WP-Cron is cleared with wp_unschedule_hook() rather than a
	 * wp_next_scheduled() loop, because that lookup keys on the arguments and
	 * would miss every event scheduled with a payload.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function cancel_all() {
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( '', array(), self::GROUP );
		}

		wp_unschedule_hook( self::HOOK );
	}
}
