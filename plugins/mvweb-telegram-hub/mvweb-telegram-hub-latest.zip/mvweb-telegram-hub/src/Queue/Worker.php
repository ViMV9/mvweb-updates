<?php
/**
 * Executes queued Telegram deliveries.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

namespace MVweb\Telegram\Hub\Queue;

use MVweb\Telegram\Hub\Log\Repository;
use MVweb\Telegram\Hub\Modules\Registry;
use MVweb\Telegram\Hub\Telegram\Client;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sends one queued message and decides whether to try again.
 *
 * @since 1.0.0
 */
final class Worker {

	/**
	 * Pause before each retry, in seconds.
	 *
	 * Three entries means the first send may be followed by three retries:
	 * after 1, 5 and 15 minutes.
	 *
	 * @var int[]
	 */
	private const RETRY_DELAYS = array( 60, 300, 900 );

	/**
	 * Hook the queue handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register() {
		add_action( Dispatcher::HOOK, array( $this, 'run' ), 10, 1 );
	}

	/**
	 * Handle one queued job.
	 *
	 * @since 1.0.0
	 * @param array $payload Job payload written by the dispatcher.
	 * @return void
	 */
	public function run( $payload ) {
		if ( ! is_array( $payload ) ) {
			return;
		}

		$module_slug = isset( $payload['module'] ) ? (string) $payload['module'] : '';
		$object_id   = isset( $payload['object_id'] ) ? absint( $payload['object_id'] ) : 0;
		$chat_id     = isset( $payload['chat_id'] ) ? (string) $payload['chat_id'] : '';
		$attempt     = isset( $payload['attempt'] ) ? max( 1, absint( $payload['attempt'] ) ) : 1;

		if ( '' === $chat_id || ! $object_id ) {
			return;
		}

		$module = Registry::get( $module_slug );
		if ( ! $module ) {
			return;
		}

		$text = $module->build_message( $object_id );
		if ( null === $text || '' === $text ) {
			// The order is gone or the template renders empty — nothing to send.
			return;
		}

		$client   = new Client();
		$response = $client->send_message( $chat_id, $text );

		if ( ! empty( $response['ok'] ) ) {
			return;
		}

		$this->handle_failure( $payload, $attempt, $response );
	}

	/**
	 * Log a failed attempt and re-queue it when that can help.
	 *
	 * @since 1.0.0
	 * @param array $payload  Original job payload.
	 * @param int   $attempt  Attempt number that just failed.
	 * @param array $response Normalised client response.
	 * @return void
	 */
	private function handle_failure( array $payload, $attempt, array $response ) {
		$retryable   = ! empty( $response['retryable'] );
		$has_retries = $attempt <= count( self::RETRY_DELAYS );
		$will_retry  = $retryable && $has_retries;

		Repository::add(
			array(
				'module'        => isset( $payload['module'] ) ? $payload['module'] : '',
				'object_id'     => isset( $payload['object_id'] ) ? $payload['object_id'] : 0,
				'chat_id'       => isset( $payload['chat_id'] ) ? $payload['chat_id'] : '',
				'attempt'       => $attempt,
				'status'        => $will_retry ? Repository::STATUS_RETRY : Repository::STATUS_FAILED,
				'error_code'    => isset( $response['error_code'] ) ? $response['error_code'] : 0,
				'error_message' => isset( $response['description'] ) ? $response['description'] : '',
			)
		);

		if ( ! $will_retry ) {
			return;
		}

		$delay = self::RETRY_DELAYS[ $attempt - 1 ];

		// Telegram knows better than we do how long it wants us to wait.
		if ( ! empty( $response['retry_after'] ) ) {
			$delay = max( $delay, (int) $response['retry_after'] );
		}

		$payload['attempt'] = $attempt + 1;

		Dispatcher::schedule( $payload, $delay );
	}
}
