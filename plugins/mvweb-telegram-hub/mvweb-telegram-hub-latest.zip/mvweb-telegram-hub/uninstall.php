<?php
/**
 * Uninstall MVweb Telegram Hub.
 *
 * Nothing is removed unless the operator ticked "Delete data on uninstall" on
 * the Bot tab. An accidental delete-and-reinstall should not cost the token,
 * the recipients and the message template.
 *
 * Kept as plain procedural code: the plugin is not loaded at this point, so
 * there is no autoloader and no settings class to lean on.
 *
 * @package MVweb\Telegram\Hub
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$mvweb_tg_settings = get_option( 'mvweb_tg_settings', array() );

if ( ! is_array( $mvweb_tg_settings ) || empty( $mvweb_tg_settings['delete_data'] ) ) {
	return;
}

global $wpdb;

// Scheduled work. wp_unschedule_hook() also catches queue jobs, which carry a
// payload and are therefore invisible to a wp_next_scheduled() lookup.
wp_clear_scheduled_hook( 'mvweb_tg_cleanup_log' );
wp_unschedule_hook( 'mvweb_tg_send' );

// Options and cached bot info.
delete_option( 'mvweb_tg_settings' );
delete_option( 'mvweb_tg_db_version' );
delete_transient( 'mvweb_tg_bot_info' );

// Delivery log.
$mvweb_tg_sql = $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $wpdb->prefix . 'mvweb_tg_log' );
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- prepared above.
$wpdb->query( $mvweb_tg_sql );

/*
 * Order meta. It lives in postmeta with classic storage and in wc_orders_meta
 * with HPOS, so both are swept. Batched on purpose: a shop with tens of
 * thousands of orders should not hit one unbounded DELETE.
 */
$mvweb_tg_meta_tables = array(
	$wpdb->postmeta,
	$wpdb->prefix . 'wc_orders_meta',
);

foreach ( $mvweb_tg_meta_tables as $mvweb_tg_table ) {
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
	$mvweb_tg_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $mvweb_tg_table ) );

	if ( $mvweb_tg_exists !== $mvweb_tg_table ) {
		continue;
	}

	do {
		$mvweb_tg_sql = $wpdb->prepare(
			'DELETE FROM %i WHERE meta_key = %s LIMIT 1000',
			$mvweb_tg_table,
			'_mvweb_tg_sent'
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- prepared above.
		$mvweb_tg_deleted = $wpdb->query( $mvweb_tg_sql );
	} while ( $mvweb_tg_deleted > 0 );
}
