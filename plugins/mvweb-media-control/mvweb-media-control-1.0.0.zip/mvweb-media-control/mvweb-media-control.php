<?php
/**
 * Plugin Name:       MVweb Media Control
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-media-control
 * Description:       Disables unneeded image sizes, converts new uploads to WebP and safely cleans up files of disabled sizes.
 * Version:           1.0.0
 * Requires at least: 7.0
 * Tested up to:      7.1
 * Requires PHP:      8.2
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-media-control
 * Domain Path:       /languages
 *
 * @package mvweb_mdc
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_MDC_VERSION' ) ) {
	return;
}

define( 'MVWEB_MDC_VERSION', '1.0.0' );
define( 'MVWEB_MDC_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_MDC_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_MDC_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_MDC_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_MDC_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_MDC_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_MDC_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_MDC_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

$mvweb_mdc_updater = null;

if ( class_exists( 'MVweb_Updater' ) ) {
	$mvweb_mdc_updater = MVweb_Updater::create( __FILE__, 'mvweb-media-control' );
}

// Load MVweb License.
if ( file_exists( MVWEB_MDC_PATH . 'includes/class-mvweb-license.php' ) ) {
	require_once MVWEB_MDC_PATH . 'includes/class-mvweb-license.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-license.php' ) ) {
	require_once $shared_path . 'class-mvweb-license.php';
}

if ( class_exists( 'MVweb_License' ) ) {
	MVweb_License::init( 'mvweb-media-control', $mvweb_mdc_updater, 'plugin', 'mvweb-media-control' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter(
	'mvweb_registered_plugins',
	function ( $plugins ) {
		$plugins['mvweb-media-control'] = array(
			'name'         => 'MVweb Media Control',
			'description'  => __( 'Disables unneeded image sizes, converts new uploads to WebP and safely cleans up files of disabled sizes.', 'mvweb-media-control' ),
			'url'          => 'https://mvweb.ru/plugins/mvweb-media-control',
			'settings_url' => 'admin.php?page=mvweb-media-control',
			'textdomain'   => 'mvweb-media-control',
		);
		return $plugins;
	}
);

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_mdc_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-media-control',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_mdc_load_textdomain' );

require_once MVWEB_MDC_PATH . 'includes/helpers.php';
require_once MVWEB_MDC_PATH . 'includes/class-mvweb-mdc-uploads.php';
MVweb_MDC_Uploads::init();
require_once MVWEB_MDC_PATH . 'includes/class-mvweb-mdc-cleaner.php';
MVweb_MDC_Cleaner::init();
require_once MVWEB_MDC_PATH . 'includes/class-mvweb-mdc-converter.php';
MVweb_MDC_Converter::init();
require_once MVWEB_MDC_PATH . 'includes/class-mvweb-mdc-unused.php';
MVweb_MDC_Unused::init();

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once MVWEB_MDC_PATH . 'includes/class-mvweb-mdc-cli.php';
	WP_CLI::add_command( 'mvweb-media-control', 'MVweb_MDC_CLI' );
}

if ( is_admin() ) {
	require_once MVWEB_MDC_PATH . 'includes/class-mvweb-mdc-sources.php';
	require_once MVWEB_MDC_PATH . 'includes/class-mvweb-mdc-admin.php';
	MVweb_MDC_Admin::init();
}
