/**
 * Admin JavaScript for MVweb Media Control.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		initTabs();
		initDependentToggles();
		initJobs();
		initOriginals();
		initMarkUnused();
		initSources();
		initWhereUsed();
		initConvert();
		initUnused();
	});

	/**
	 * Unused images tab: the scan runs in slices; trash, restore and purge
	 * send the selected groups in small batches, then the page reloads.
	 */
	function initUnused() {
		var cfg = window.mvwebMdc;
		var box = document.querySelector('[data-mvweb-mdc-uprogress]');

		if (!cfg || !box) {
			return;
		}

		var label = box.querySelector('[data-mvweb-mdc-ulabel]');
		var bar = box.querySelector('[data-mvweb-mdc-ubar]');
		var message = document.querySelector('[data-mvweb-mdc-umessage]');
		var buttons = document.querySelectorAll('[data-mvweb-mdc-unused]');

		var setBusy = function (busy) {
			buttons.forEach(function (btn) { btn.disabled = busy; });
		};

		var fail = function (text) {
			setBusy(false);
			message.querySelector('.mvweb-alert__body').textContent = text;
			message.hidden = false;
		};

		var post = function (data) {
			var body = new URLSearchParams({ action: 'mvweb_mdc_unused', _ajax_nonce: cfg.nonce });
			Object.keys(data).forEach(function (key) {
				if (Array.isArray(data[key])) {
					data[key].forEach(function (value) { body.append(key + '[]', value); });
				} else {
					body.append(key, data[key]);
				}
			});
			return fetch(cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body }).then(function (response) {
				return response.json();
			});
		};

		var scan = function (data) {
			message.hidden = true;
			box.hidden = false;
			setBusy(true);

			post(data).then(function (res) {
				if (!res || !res.success) {
					fail(res && res.data && res.data.message ? res.data.message : cfg.failed);
					return;
				}

				var job = res.data;

				if (job.finished) {
					window.location.href = cfg.unusedUrl;
					return;
				}

				bar.style.width = (job.total > 0 ? Math.min(100, Math.round(job.processed / job.total * 100)) : 0) + '%';
				label.textContent = (cfg.unusedPhases[job.phase] || '') + (job.total > 0 ? ' — ' + job.processed + ' / ' + job.total : '');
				scan({ do: 'step' });
			}).catch(function () {
				fail(cfg.failed);
			});
		};

		var act = function (action, form) {
			var ids = Array.prototype.map.call(form.querySelectorAll('input[name="mdc_unused[]"]:checked'), function (input) {
				return input.value;
			});
			var backup = form.querySelector('input[name="mdc_backup"]');
			var status = form.querySelector('[data-mvweb-mdc-ustatus]');
			var done = 0;

			if (!ids.length) {
				fail(cfg.noneSelected);
				return;
			}

			if ('trash' === action && !window.confirm(cfg.confirmTrash)) {
				return;
			}

			if ('purge' === action && backup && backup.checked && !window.confirm(cfg.confirmPurge)) {
				return;
			}

			message.hidden = true;
			setBusy(true);

			var next = function () {
				var batch = ids.slice(done, done + 20);

				if (!batch.length) {
					window.location.reload();
					return;
				}

				post({ do: action, ids: batch, backup: backup && backup.checked ? '1' : '' }).then(function (res) {
					if (!res || !res.success) {
						fail(res && res.data && res.data.message ? res.data.message : cfg.failed);
						return;
					}
					done += batch.length;
					status.textContent = cfg.unusedDone.replace('%1$d', done).replace('%2$d', ids.length);
					next();
				}).catch(function () {
					fail(cfg.failed);
				});
			};

			next();
		};

		buttons.forEach(function (btn) {
			btn.addEventListener('click', function () {
				var action = btn.getAttribute('data-mvweb-mdc-unused');

				if ('scan' === action || 'step' === action) {
					scan({ do: action });
				} else if ('cancel' === action) {
					post({ do: 'cancel' }).then(function () { window.location.href = cfg.unusedUrl; });
				} else {
					act(action, btn.closest('[data-mvweb-mdc-uform]'));
				}
			});
		});

		document.querySelectorAll('[data-mvweb-mdc-uall]').forEach(function (all) {
			all.addEventListener('change', function () {
				all.closest('table').querySelectorAll('input[name="mdc_unused[]"]').forEach(function (input) {
					input.checked = all.checked;
				});
			});
		});
	}

	/**
	 * Conversion tab: estimate, start, pause and resume reload the page;
	 * the final step and undo run in slices until the task stops working.
	 */
	function initConvert() {
		var cfg = window.mvwebMdc;
		var box = document.querySelector('[data-mvweb-mdc-cprogress]');

		if (!cfg || !box) {
			return;
		}

		var label = box.querySelector('[data-mvweb-mdc-clabel]');
		var bar = box.querySelector('[data-mvweb-mdc-cbar]');
		var message = document.querySelector('[data-mvweb-mdc-cmessage]');
		var buttons = document.querySelectorAll('[data-mvweb-mdc-convert]');

		var setBusy = function (busy) {
			buttons.forEach(function (btn) { btn.disabled = busy; });
		};

		var fail = function (text) {
			setBusy(false);
			message.querySelector('.mvweb-alert__body').textContent = text;
			message.hidden = false;
		};

		var post = function (data) {
			var body = new URLSearchParams({ action: 'mvweb_mdc_convert', _ajax_nonce: cfg.nonce });
			Object.keys(data).forEach(function (key) { body.append(key, data[key]); });
			return fetch(cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body }).then(function (response) {
				return response.json();
			});
		};

		var run = function (data) {
			message.hidden = true;
			setBusy(true);

			post(data).then(function (res) {
				if (!res || !res.success) {
					fail(res && res.data && res.data.message ? res.data.message : cfg.failed);
					return;
				}

				var job = res.data;

				if ('working' !== job.status) {
					window.location.href = cfg.convertUrl;
					return;
				}

				box.hidden = false;
				bar.style.width = (job.total > 0 ? Math.min(100, Math.round(job.processed / job.total * 100)) : 0) + '%';
				label.textContent = (cfg.convertPhases[job.phase] || '') + (job.total > 0 ? ' — ' + job.processed + ' / ' + job.total : '');
				run({ do: 'step' });
			}).catch(function () {
				fail(cfg.failed);
			});
		};

		buttons.forEach(function (btn) {
			btn.addEventListener('click', function () {
				var action = btn.getAttribute('data-mvweb-mdc-convert');
				var form = btn.closest('[data-mvweb-mdc-cform]');
				var data = { do: action };

				if (form) {
					var period = form.querySelector('input[name="mdc_period"]:checked');
					['mdc_backup', 'mdc_png', 'mdc_originals'].forEach(function (name) {
						var input = form.querySelector('input[name="' + name + '"]');
						if (input && input.checked) {
							data[name.replace('mdc_', '')] = '1';
						}
					});
					if (period) {
						data.period = period.value;
					}
				}

				if ('delete' === action && data.backup && !window.confirm(cfg.confirmOld)) {
					return;
				}

				if ('undo' === action && !window.confirm(cfg.confirmUndo)) {
					return;
				}

				run(data);
			});
		});
	}

	/**
	 * Show where content links to a file kept by the scan.
	 */
	function initWhereUsed() {
		var cfg = window.mvwebMdc;

		if (!cfg) {
			return;
		}

		var item = function (text, url) {
			var li = document.createElement('li');
			var node = li;

			if (url) {
				node = document.createElement('a');
				node.href = url;
				node.target = '_blank';
				node.rel = 'noopener';
				li.appendChild(node);
			}

			node.textContent = text;
			return li;
		};

		document.addEventListener('click', function (event) {
			var btn = event.target.closest('[data-mvweb-mdc-where]');

			if (!btn) {
				return;
			}

			var list = btn.nextElementSibling;
			var body = new URLSearchParams({ action: 'mvweb_mdc_job', _ajax_nonce: cfg.nonce, do: 'where', file: btn.getAttribute('data-mvweb-mdc-where') });

			btn.disabled = true;

			fetch(cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body })
				.then(function (response) { return response.json(); })
				.then(function (res) {
					list.replaceChildren();

					if (!res || !res.success) {
						list.appendChild(item(res && res.data && res.data.message ? res.data.message : cfg.whereFailed, ''));
					} else if (!res.data.places.length) {
						list.appendChild(item(cfg.whereNone, ''));
					} else {
						res.data.places.forEach(function (place) { list.appendChild(item(place.label, place.url)); });
					}
				})
				.catch(function () {
					list.replaceChildren(item(cfg.whereFailed, ''));
				})
				.then(function () {
					list.hidden = false;
					btn.disabled = false;
				});
		});
	}

	/**
	 * Tick "Do not create" for sizes no theme or plugin needs. Saving stays with the user.
	 *
	 * Delegated: the sizes block is replaced after the background scan.
	 */
	function initMarkUnused() {
		var cfg = window.mvwebMdc;

		if (!cfg) {
			return;
		}

		document.addEventListener('click', function (event) {
			if (!event.target.closest('[data-mvweb-mdc-mark-unused]')) {
				return;
			}

			var boxes = document.querySelectorAll('input[data-mvweb-mdc-unused]');

			boxes.forEach(function (box) { box.checked = true; });
			document.querySelector('[data-mvweb-mdc-mark-status]').textContent = cfg.marked.replace('%d', boxes.length);
		});
	}

	/**
	 * Check the theme and plugins in the background and refresh the sizes block if they changed.
	 *
	 * The spinner shows only when the check takes long, which means a rescan.
	 * Checkboxes the user changed meanwhile keep their state. The markup comes
	 * from the plugin's own escaped template; DOMParser keeps scripts inert.
	 */
	function initSources() {
		var cfg = window.mvwebMdc;
		var box = document.querySelector('[data-mvweb-mdc-sizes]');
		var status = document.querySelector('[data-mvweb-mdc-scan]');

		if (!cfg || !box || !status) {
			return;
		}

		var timer = window.setTimeout(function () { status.hidden = false; }, 700);
		var body = new URLSearchParams({ action: 'mvweb_mdc_job', _ajax_nonce: cfg.nonce, do: 'sources' });

		fetch(cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body })
			.then(function (response) { return response.json(); })
			.then(function (res) {
				if (!res || !res.success || !res.data.changed) {
					return;
				}

				var state = {};
				var doc = new DOMParser().parseFromString(res.data.html, 'text/html');

				box.querySelectorAll('input[type="checkbox"]').forEach(function (input) { state[input.value] = input.checked; });
				box.replaceChildren.apply(box, Array.prototype.slice.call(doc.body.childNodes));
				box.querySelectorAll('input[type="checkbox"]').forEach(function (input) {
					if (Object.prototype.hasOwnProperty.call(state, input.value)) {
						input.checked = state[input.value];
					}
				});
			})
			.catch(function () {})
			.then(function () {
				window.clearTimeout(timer);
				status.hidden = true;
			});
	}

	/**
	 * Complete kept originals: regenerate missing sizes, then delete the originals.
	 */
	function initOriginals() {
		var cfg = window.mvwebMdc;
		var btn = document.querySelector('[data-mvweb-mdc-originals]');

		if (!cfg || !btn) {
			return;
		}

		var status = document.querySelector('[data-mvweb-mdc-originals-status]');
		var done = 0;

		var run = function (cursor) {
			var body = new URLSearchParams({ action: 'mvweb_mdc_job', _ajax_nonce: cfg.nonce, do: 'originals', cursor: String(cursor) });

			fetch(cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body })
				.then(function (response) { return response.json(); })
				.then(function (res) {
					if (!res || !res.success) {
						throw new Error('failed');
					}
					done += res.data.done;
					status.textContent = cfg.originalsDone.replace('%1$d', done).replace('%2$d', res.data.remaining);
					if (res.data.finished) {
						window.location.reload();
						return;
					}
					run(res.data.cursor);
				})
				.catch(function () {
					btn.disabled = false;
					status.textContent = cfg.failed;
				});
		};

		btn.addEventListener('click', function () {
			btn.disabled = true;
			done = 0;
			run(0);
		});
	}

	/**
	 * Run cleanup tasks in slices through admin-ajax until they finish.
	 */
	function initJobs() {
		var cfg = window.mvwebMdc;
		var box = document.querySelector('[data-mvweb-mdc-progress]');

		if (!cfg || !box) {
			return;
		}

		var label = box.querySelector('[data-mvweb-mdc-label]');
		var bar = box.querySelector('[data-mvweb-mdc-bar]');
		var btnContinue = box.querySelector('[data-mvweb-mdc-continue]');
		var btnPause = box.querySelector('[data-mvweb-mdc-pause]');
		var btnCancel = box.querySelector('[data-mvweb-mdc-cancel]');
		var message = document.querySelector('[data-mvweb-mdc-message]');
		var taskButtons = document.querySelectorAll('[data-mvweb-mdc-task]');
		var stop = false;

		var setBusy = function (busy) {
			taskButtons.forEach(function (btn) { btn.disabled = busy; });
			btnPause.hidden = !busy;
			btnContinue.hidden = busy;
		};

		var showError = function (text) {
			message.querySelector('.mvweb-alert__body').textContent = text;
			message.hidden = false;
		};

		var post = function (data) {
			var body = new URLSearchParams();
			body.append('action', 'mvweb_mdc_job');
			body.append('_ajax_nonce', cfg.nonce);
			Object.keys(data).forEach(function (key) {
				if (Array.isArray(data[key])) {
					data[key].forEach(function (value) { body.append(key + '[]', value); });
				} else {
					body.append(key, data[key]);
				}
			});
			return fetch(cfg.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body }).then(function (response) {
				return response.json();
			});
		};

		var run = function (data) {
			box.hidden = false;
			message.hidden = true;
			stop = false;
			setBusy(true);

			post(data).then(function (res) {
				if (!res || !res.success) {
					setBusy(false);
					btnContinue.hidden = true;
					showError(res && res.data && res.data.message ? res.data.message : cfg.failed);
					return;
				}

				var job = res.data;
				var percent = job.total > 0 ? Math.min(100, Math.round(job.processed / job.total * 100)) : 0;

				bar.style.width = percent + '%';
				label.textContent = (cfg.phases[job.phase] || '') + (job.total > 0 ? ' — ' + job.processed + ' / ' + job.total : '');

				if (job.finished) {
					window.location.href = cfg.doneUrl;
					return;
				}

				if (stop) {
					setBusy(false);
					label.textContent = cfg.paused;
					return;
				}

				run({ do: 'step' });
			}).catch(function () {
				setBusy(false);
				label.textContent = cfg.failed;
			});
		};

		taskButtons.forEach(function (btn) {
			btn.addEventListener('click', function () {
				var task = btn.getAttribute('data-mvweb-mdc-task');
				var form = btn.closest('[data-mvweb-mdc-form]');
				var data = { do: 'start', task: task };

				if ('delete' === task && !window.confirm(cfg.confirmB)) {
					return;
				}

				if (form) {
					data.sizes = Array.prototype.map.call(form.querySelectorAll('input[name="mdc_sizes[]"]:checked'), function (input) {
						return input.value;
					});
					var backup = form.querySelector('input[name="mdc_backup"]');
					if (backup && backup.checked) {
						data.backup = '1';
					}
				}

				run(data);
			});
		});

		btnContinue.addEventListener('click', function () { run({ do: 'step' }); });
		btnPause.addEventListener('click', function () { stop = true; });
		btnCancel.addEventListener('click', function () {
			stop = true;
			post({ do: 'cancel' }).then(function () { window.location.href = cfg.doneUrl; });
		});
	}

	/**
	 * Enable a checkbox only while the checkbox it depends on is checked.
	 */
	function initDependentToggles() {
		document.querySelectorAll('[data-mvweb-mdc-requires]').forEach(function (input) {
			var parent = document.getElementById(input.getAttribute('data-mvweb-mdc-requires'));

			if (!parent) {
				return;
			}

			var sync = function () {
				input.disabled = parent.disabled || !parent.checked;
				if (input.disabled) {
					input.checked = false;
				}
			};

			parent.addEventListener('change', sync);
		});
	}

	/**
	 * Initialize tab navigation on the settings page.
	 */
	function initTabs() {
		var links = document.querySelectorAll('.mvweb-nav__link');
		var panels = document.querySelectorAll('.mvweb-tab-content');

		if (!links.length || !panels.length) {
			return;
		}

		links.forEach(function (link) {
			link.addEventListener('click', function (event) {
				event.preventDefault();

				var target = link.getAttribute('data-tab') || link.getAttribute('href').replace('#', '');
				var panel = document.getElementById(target);

				if (!panel) {
					return;
				}

				links.forEach(function (l) { l.classList.remove('mvweb-nav__link--active'); });
				panels.forEach(function (p) { p.classList.remove('active'); });

				link.classList.add('mvweb-nav__link--active');
				panel.classList.add('active');
			});
		});
	}
})();
