<?php
/**
 * Conversion tab: convert existing JPEG and PNG images to WebP.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_mdc_cjob     = MVweb_MDC_Converter::get_job();
$mvweb_mdc_cstatus  = (string) ( $mvweb_mdc_cjob['status'] ?? '' );
$mvweb_mdc_estimate = get_option( MVweb_MDC_Converter::ESTIMATE_OPTION, array() );
$mvweb_mdc_cstats   = (array) ( $mvweb_mdc_cjob['stats'] ?? array() );
$mvweb_mdc_blocked  = MVweb_MDC_Cleaner::is_running() || MVweb_MDC_Cleaner::pending_count() > 0;
$mvweb_mdc_datefmt  = get_option( 'date_format' ) . ' ' . get_option( 'time_format' );

$mvweb_mdc_creasons = array(
	'bad_meta'       => __( 'metadata is damaged', 'mvweb-media-control' ),
	'not_image'      => __( 'not an image', 'mvweb-media-control' ),
	'unsupported'    => __( 'the server cannot process this format', 'mvweb-media-control' ),
	'no_original'    => __( 'no original file to regenerate from', 'mvweb-media-control' ),
	'edited'         => __( 'edited in the image editor', 'mvweb-media-control' ),
	'too_new'        => __( 'uploaded less than an hour ago', 'mvweb-media-control' ),
	'offloaded'      => __( 'stored by an offload plugin', 'mvweb-media-control' ),
	'site_icon'      => __( 'site icon', 'mvweb-media-control' ),
	'not_source'     => __( 'already WebP', 'mvweb-media-control' ),
	'journal'        => __( 'already being converted', 'mvweb-media-control' ),
	'name_taken'     => __( 'a WebP file with the same name exists (an optimizer copy or another image)', 'mvweb-media-control' ),
	'journal_write'  => __( 'the journal could not be saved', 'mvweb-media-control' ),
	'convert_failed' => __( 'conversion failed, the image was returned as it was', 'mvweb-media-control' ),
	'no_gain'        => __( 'WebP is not smaller, the image was returned as it was', 'mvweb-media-control' ),
	'changed'        => __( 'changed after conversion, not returned', 'mvweb-media-control' ),
);

$mvweb_mdc_clabels = array(
	'converted'   => __( 'images converted', 'mvweb-media-control' ),
	'rows'        => __( 'database values with links replaced', 'mvweb-media-control' ),
	'deleted'     => __( 'old files deleted', 'mvweb-media-control' ),
	'freed'       => __( 'space freed', 'mvweb-media-control' ),
	'kept'        => __( 'old files kept: a link to them cannot be replaced', 'mvweb-media-control' ),
	'not_deleted' => __( 'files not deleted (permissions)', 'mvweb-media-control' ),
	'wait'        => __( 'images waiting for the next run: links to them were replaced just now', 'mvweb-media-control' ),
	'undone'      => __( 'images returned', 'mvweb-media-control' ),
	'changed'     => __( 'images not returned: changed after conversion', 'mvweb-media-control' ),
);

$mvweb_mdc_periods = array(
	'day'   => __( 'One day', 'mvweb-media-control' ),
	'2days' => __( 'Two days', 'mvweb-media-control' ),
	'week'  => __( 'One week', 'mvweb-media-control' ),
);

$mvweb_mdc_cphases = array(
	'convert' => __( 'Converting images', 'mvweb-media-control' ),
	'index'   => __( 'Indexing links in content', 'mvweb-media-control' ),
	'links'   => __( 'Replacing links', 'mvweb-media-control' ),
	'delete'  => __( 'Deleting old files', 'mvweb-media-control' ),
	'undo'    => __( 'Undoing conversion', 'mvweb-media-control' ),
);

$mvweb_mdc_summary = static function ( array $stats, array $failed ) use ( $mvweb_mdc_clabels, $mvweb_mdc_creasons ): string {
	$lines = array();

	foreach ( $mvweb_mdc_clabels as $key => $label ) {
		if ( ! empty( $stats[ $key ] ) ) {
			$lines[] = $label . ': ' . ( 'freed' === $key ? size_format( (int) $stats[ $key ] ) : (int) $stats[ $key ] );
		}
	}

	if ( ! empty( $stats['bytes_old'] ) ) {
		/* translators: 1: weight before, 2: weight after */
		$lines[] = sprintf( __( 'main files and sizes: %1$s → %2$s', 'mvweb-media-control' ), size_format( (int) $stats['bytes_old'] ), size_format( (int) $stats['bytes_new'] ) );
	}

	foreach ( (array) ( $stats['skipped'] ?? array() ) as $reason => $count ) {
		$lines[] = __( 'skipped', 'mvweb-media-control' ) . ' (' . ( $mvweb_mdc_creasons[ $reason ] ?? $reason ) . '): ' . (int) $count;
	}

	if ( $failed ) {
		$lines[] = __( 'failed attachments (IDs)', 'mvweb-media-control' ) . ': ' . implode( ', ', array_map( 'intval', array_keys( $failed ) ) );
	}

	return implode( '; ', $lines );
};
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Convert existing images to WebP', 'mvweb-media-control' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'JPEG and PNG images already in the media library get WebP files and sizes. Links to them in content, fields and options are replaced. The old files stay on disk until you delete them in the last step, after purging the page cache, so cached pages keep working. Until then everything can be undone.', 'mvweb-media-control' ); ?></p>
	<ol class="mvweb-steps">
		<li><div><?php esc_html_e( 'Estimate and start. The work runs in the background by WP-Cron, spread over the chosen period.', 'mvweb-media-control' ); ?></div></li>
		<li><div><?php esc_html_e( 'Purge the page cache and CDN when conversion has finished.', 'mvweb-media-control' ); ?></div></li>
		<li><div><?php esc_html_e( 'Delete the old files.', 'mvweb-media-control' ); ?></div></li>
	</ol>
</div>

<div class="mvweb-alert mvweb-alert--error" data-mvweb-mdc-cmessage hidden>
	<div class="mvweb-alert__body"></div>
</div>

<div class="mvweb-block" data-mvweb-mdc-cprogress<?php echo 'working' === $mvweb_mdc_cstatus ? '' : ' hidden'; ?>>
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Task in progress', 'mvweb-media-control' ); ?></div>
	</div>
	<p class="mvweb-block__sub" data-mvweb-mdc-clabel><?php echo 'working' === $mvweb_mdc_cstatus ? esc_html__( 'Paused. Press Continue to resume.', 'mvweb-media-control' ) : ''; ?></p>
	<div class="mvweb-progress"><span class="mvweb-progress__bar" data-mvweb-mdc-cbar style="width:0%"></span></div>
	<div class="mvweb-mdc-actions">
		<button type="button" class="mvweb-btn mvweb-btn--primary" data-mvweb-mdc-convert="step"><?php esc_html_e( 'Continue', 'mvweb-media-control' ); ?></button>
	</div>
</div>

<?php if ( 'done' === $mvweb_mdc_cstatus && ( $mvweb_mdc_cstats || ! empty( $mvweb_mdc_cjob['failed'] ) ) ) : ?>
	<div class="mvweb-alert mvweb-alert--success">
		<div class="mvweb-alert__title"><?php esc_html_e( 'Last conversion', 'mvweb-media-control' ); ?></div>
		<div class="mvweb-alert__body"><?php echo esc_html( $mvweb_mdc_summary( $mvweb_mdc_cstats, (array) ( $mvweb_mdc_cjob['failed'] ?? array() ) ) ); ?></div>
	</div>
<?php endif; ?>

<?php if ( in_array( $mvweb_mdc_cstatus, array( '', 'done' ), true ) ) : ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( '1. Estimate', 'mvweb-media-control' ); ?></div>
		</div>

		<?php if ( ! empty( $mvweb_mdc_estimate['at'] ) ) : ?>
			<p>
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: date, 2: JPEG count, 3: JPEG weight, 4: PNG count, 5: PNG weight */
						__( '%1$s: JPEG %2$d (%3$s), PNG %4$d (%5$s).', 'mvweb-media-control' ),
						wp_date( $mvweb_mdc_datefmt, (int) $mvweb_mdc_estimate['at'] ),
						(int) $mvweb_mdc_estimate['jpeg'],
						size_format( (int) $mvweb_mdc_estimate['bytes']['jpeg'] ),
						(int) $mvweb_mdc_estimate['png'],
						size_format( (int) $mvweb_mdc_estimate['bytes']['png'] )
					)
				);
				?>
				<?php if ( ! empty( $mvweb_mdc_estimate['partial'] ) ) : ?>
					<?php echo esc_html( sprintf( /* translators: 1: counted, 2: total */ __( 'Counted %1$d of %2$d, the rest did not fit in one request.', 'mvweb-media-control' ), (int) $mvweb_mdc_estimate['counted'], (int) $mvweb_mdc_estimate['total'] ) ); ?>
				<?php endif; ?>
			</p>
			<?php if ( ! empty( $mvweb_mdc_estimate['skipped'] ) ) : ?>
				<p>
					<?php
					$mvweb_mdc_skips = array();
					foreach ( (array) $mvweb_mdc_estimate['skipped'] as $mvweb_mdc_reason => $mvweb_mdc_count ) {
						$mvweb_mdc_skips[] = ( $mvweb_mdc_creasons[ $mvweb_mdc_reason ] ?? $mvweb_mdc_reason ) . ': ' . (int) $mvweb_mdc_count;
					}
					echo esc_html( sprintf( /* translators: %s: reasons with counts */ __( 'Will not be converted: %s.', 'mvweb-media-control' ), implode( '; ', $mvweb_mdc_skips ) ) );
					?>
				</p>
			<?php endif; ?>
			<p class="mvweb-mdc-note">
				<?php
				echo esc_html(
					sprintf(
						/* translators: %s: size */
						__( 'While conversion runs, old and new files are kept together: about %s more on disk until the last step (new WebP files usually weigh about a quarter of the old ones).', 'mvweb-media-control' ),
						size_format( (int) $mvweb_mdc_estimate['growth'] )
					)
				);
				if ( null !== $mvweb_mdc_estimate['free'] ) {
					echo ' ' . esc_html( sprintf( /* translators: %s: size */ __( 'Free on the disk: %s (a hosting quota may be smaller).', 'mvweb-media-control' ), size_format( (float) $mvweb_mdc_estimate['free'] ) ) );
				}
				?>
			</p>
			<?php if ( ! empty( $mvweb_mdc_estimate['optimizers'] ) ) : ?>
				<div class="mvweb-alert mvweb-alert--warning">
					<div class="mvweb-alert__body">
						<?php
						echo esc_html(
							sprintf(
								/* translators: %s: plugin names */
								__( '%s is active. It may already keep WebP copies named photo.webp: such images are skipped, so another file is never overwritten.', 'mvweb-media-control' ),
								implode( ', ', $mvweb_mdc_estimate['optimizers'] )
							)
						);
						?>
					</div>
				</div>
			<?php endif; ?>
		<?php endif; ?>

		<div class="mvweb-mdc-actions">
			<button type="button" class="mvweb-btn" data-mvweb-mdc-convert="estimate"><?php esc_html_e( 'Estimate', 'mvweb-media-control' ); ?></button>
		</div>
	</div>

	<?php if ( ! empty( $mvweb_mdc_estimate['at'] ) ) : ?>
		<div class="mvweb-block" data-mvweb-mdc-cform>
			<div class="mvweb-block__head">
				<div class="mvweb-block__title"><?php esc_html_e( '2. Start', 'mvweb-media-control' ); ?></div>
			</div>

			<?php if ( ! mvweb_mdc_can_write_webp() ) : ?>
				<div class="mvweb-alert mvweb-alert--warning">
					<div class="mvweb-alert__body"><?php esc_html_e( 'The server image editor cannot write WebP (GD or Imagick without WebP support). Conversion is unavailable.', 'mvweb-media-control' ); ?></div>
				</div>
			<?php elseif ( $mvweb_mdc_blocked ) : ?>
				<div class="mvweb-alert mvweb-alert--warning">
					<div class="mvweb-alert__body"><?php esc_html_e( 'A cleanup task is not finished: delete the files of step B or undo step A on the Cleanup tab first.', 'mvweb-media-control' ); ?></div>
				</div>
			<?php else : ?>
				<div class="mvweb-form-row">
					<span class="mvweb-form-row__label"><?php esc_html_e( 'Spread over', 'mvweb-media-control' ); ?></span>
					<div class="mvweb-form-row__field">
						<?php foreach ( $mvweb_mdc_periods as $mvweb_mdc_key => $mvweb_mdc_label ) : ?>
							<label class="mvweb-mdc-radio"><input type="radio" name="mdc_period" value="<?php echo esc_attr( $mvweb_mdc_key ); ?>" <?php checked( 'day', $mvweb_mdc_key ); ?>> <?php echo esc_html( $mvweb_mdc_label ); ?></label>
						<?php endforeach; ?>
						<p class="mvweb-mdc-note"><?php esc_html_e( 'A longer period means a smaller load: every five minutes the server converts a few images. WP-Cron runs on site visits, so on a site with few visitors it takes longer.', 'mvweb-media-control' ); ?></p>
					</div>
				</div>

				<div class="mvweb-toggle-row">
					<input type="checkbox" id="mvweb_mdc_cpng" name="mdc_png" value="1" checked>
					<label for="mvweb_mdc_cpng"><?php esc_html_e( 'Convert PNG', 'mvweb-media-control' ); ?></label>
				</div>
				<p class="mvweb-mdc-note"><?php esc_html_e( 'PNG is saved to WebP with light compression. Photos and logos look the same; screenshots with small text and diagrams may lose some sharpness. Untick on sites with such images.', 'mvweb-media-control' ); ?></p>

				<div class="mvweb-toggle-row">
					<input type="checkbox" id="mvweb_mdc_coriginals" name="mdc_originals" value="1">
					<label for="mvweb_mdc_coriginals"><?php esc_html_e( 'Delete originals in the last step', 'mvweb-media-control' ); ?></label>
				</div>
				<p class="mvweb-mdc-note"><?php esc_html_e( 'Without it the original JPEG or PNG of every image stays on disk. With it the largest version left is the WebP, not bigger than 2560 px: the original resolution is lost.', 'mvweb-media-control' ); ?></p>

				<div class="mvweb-alert mvweb-alert--warning">
					<div class="mvweb-alert__body"><?php esc_html_e( 'Links in the database are replaced. Links in theme files and CSS, on other sites, in image search, emails and exported feeds cannot be replaced: after the last step they lead to missing files. ShortPixel and similar services spend quota on new files.', 'mvweb-media-control' ); ?></div>
				</div>

				<div class="mvweb-toggle-row">
					<input type="checkbox" id="mvweb_mdc_cbackup" name="mdc_backup" value="1">
					<label for="mvweb_mdc_cbackup"><?php esc_html_e( 'A backup of uploads and the database is made', 'mvweb-media-control' ); ?></label>
				</div>

				<div class="mvweb-mdc-actions">
					<button type="button" class="mvweb-btn mvweb-btn--primary" data-mvweb-mdc-convert="start"><?php esc_html_e( 'Start conversion', 'mvweb-media-control' ); ?></button>
				</div>
			<?php endif; ?>
		</div>
	<?php endif; ?>

<?php elseif ( in_array( $mvweb_mdc_cstatus, array( 'running', 'paused' ), true ) ) : ?>

	<?php
	$mvweb_mdc_cphase = $mvweb_mdc_cjob['phases'][ $mvweb_mdc_cjob['phase'] ] ?? '';
	$mvweb_mdc_stale  = 'running' === $mvweb_mdc_cstatus && time() - max( (int) $mvweb_mdc_cjob['last_run'], (int) $mvweb_mdc_cjob['started'] ) > 30 * MINUTE_IN_SECONDS;
	$mvweb_mdc_eta    = 0;
	if ( 'convert' === $mvweb_mdc_cphase && (int) $mvweb_mdc_cjob['entered'] >= 0 && (int) $mvweb_mdc_cjob['processed'] > 0 ) {
		$mvweb_mdc_eta = time() + (int) round( ( (int) $mvweb_mdc_cjob['total'] - (int) $mvweb_mdc_cjob['processed'] ) * ( time() - (int) $mvweb_mdc_cjob['started'] ) / (int) $mvweb_mdc_cjob['processed'] );
	}
	?>
	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title">
				<?php echo 'paused' === $mvweb_mdc_cstatus ? esc_html__( 'Conversion is paused', 'mvweb-media-control' ) : esc_html__( 'Conversion is running', 'mvweb-media-control' ); ?>
			</div>
		</div>
		<p>
			<?php
			if ( (int) $mvweb_mdc_cjob['entered'] < 0 ) {
				esc_html_e( 'Waiting for the first WP-Cron run.', 'mvweb-media-control' );
			} else {
				echo esc_html(
					sprintf(
						/* translators: 1: phase, 2: processed, 3: total */
						__( '%1$s: %2$d of %3$d.', 'mvweb-media-control' ),
						$mvweb_mdc_cphases[ $mvweb_mdc_cphase ] ?? $mvweb_mdc_cphase,
						(int) $mvweb_mdc_cjob['processed'],
						(int) $mvweb_mdc_cjob['total']
					)
				);
			}
			?>
			<?php
			echo esc_html(
				sprintf(
					/* translators: 1: planned end, 2: last run or a dash */
					__( 'Planned end: %1$s. Last run: %2$s.', 'mvweb-media-control' ),
					wp_date( $mvweb_mdc_datefmt, (int) $mvweb_mdc_cjob['due'] ),
					$mvweb_mdc_cjob['last_run'] ? wp_date( $mvweb_mdc_datefmt, (int) $mvweb_mdc_cjob['last_run'] ) : '—'
				)
			);
			?>
			<?php if ( $mvweb_mdc_eta > (int) $mvweb_mdc_cjob['due'] + HOUR_IN_SECONDS ) : ?>
				<?php echo esc_html( sprintf( /* translators: %s: date */ __( 'At the current pace it ends about %s.', 'mvweb-media-control' ), wp_date( $mvweb_mdc_datefmt, $mvweb_mdc_eta ) ) ); ?>
			<?php endif; ?>
		</p>
		<?php if ( $mvweb_mdc_cstats || ! empty( $mvweb_mdc_cjob['failed'] ) ) : ?>
			<p class="mvweb-mdc-note"><?php echo esc_html( $mvweb_mdc_summary( $mvweb_mdc_cstats, (array) ( $mvweb_mdc_cjob['failed'] ?? array() ) ) ); ?></p>
		<?php endif; ?>

		<?php if ( $mvweb_mdc_stale ) : ?>
			<div class="mvweb-alert mvweb-alert--warning">
				<div class="mvweb-alert__body"><?php esc_html_e( 'WP-Cron has not run for more than 30 minutes. It runs on site visits and is off when DISABLE_WP_CRON is set. Ask the hosting to call wp-cron.php every 5 minutes, or run "wp mvweb-media-control convert run".', 'mvweb-media-control' ); ?></div>
			</div>
		<?php endif; ?>

		<div class="mvweb-mdc-actions">
			<?php if ( 'paused' === $mvweb_mdc_cstatus ) : ?>
				<button type="button" class="mvweb-btn mvweb-btn--primary" data-mvweb-mdc-convert="resume"><?php esc_html_e( 'Resume', 'mvweb-media-control' ); ?></button>
			<?php else : ?>
				<button type="button" class="mvweb-btn" data-mvweb-mdc-convert="pause"><?php esc_html_e( 'Pause', 'mvweb-media-control' ); ?></button>
			<?php endif; ?>
			<button type="button" class="mvweb-btn" data-mvweb-mdc-convert="undo"><?php esc_html_e( 'Undo conversion', 'mvweb-media-control' ); ?></button>
		</div>
	</div>

<?php elseif ( 'ready' === $mvweb_mdc_cstatus ) : ?>

	<?php if ( $mvweb_mdc_cstats || ! empty( $mvweb_mdc_cjob['failed'] ) ) : ?>
		<div class="mvweb-alert mvweb-alert--success">
			<div class="mvweb-alert__title"><?php esc_html_e( 'Last run', 'mvweb-media-control' ); ?></div>
			<div class="mvweb-alert__body"><?php echo esc_html( $mvweb_mdc_summary( $mvweb_mdc_cstats, (array) ( $mvweb_mdc_cjob['failed'] ?? array() ) ) ); ?></div>
		</div>
	<?php endif; ?>

	<div class="mvweb-block" data-mvweb-mdc-cform>
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( '3. Delete old files', 'mvweb-media-control' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php
			echo esc_html(
				sprintf(
					/* translators: %d: number of images */
					_n( '%d image is converted and waits for this step.', '%d images are converted and wait for this step.', MVweb_MDC_Converter::journal_count(), 'mvweb-media-control' ),
					MVweb_MDC_Converter::journal_count()
				)
			);
			?>
		</p>
		<ol class="mvweb-steps">
			<li><div><?php esc_html_e( 'Purge the page cache (caching plugin, hosting) and the CDN cache. The Elementor cache was cleared automatically.', 'mvweb-media-control' ); ?></div></li>
			<li><div><?php esc_html_e( 'Regenerate product feeds (Yandex Market, Google Merchant and others): feed files keep the old links.', 'mvweb-media-control' ); ?></div></li>
			<li><div><?php esc_html_e( 'Open a few pages and make sure the images show.', 'mvweb-media-control' ); ?></div></li>
			<li><div><?php esc_html_e( 'Delete the old files. Links are checked again first; files whose links were replaced only now are deleted on the next run, after one more cache purge.', 'mvweb-media-control' ); ?></div></li>
		</ol>

		<div class="mvweb-alert mvweb-alert--warning">
			<div class="mvweb-alert__body"><?php esc_html_e( 'Links in theme files and CSS, on other sites, in image search, emails and exported feeds cannot be replaced: after this step they lead to missing files. This step cannot be undone.', 'mvweb-media-control' ); ?></div>
		</div>

		<div class="mvweb-toggle-row">
			<input type="checkbox" id="mvweb_mdc_cbackup2" name="mdc_backup" value="1">
			<label for="mvweb_mdc_cbackup2"><?php esc_html_e( 'A backup of uploads and the database is made', 'mvweb-media-control' ); ?></label>
		</div>

		<div class="mvweb-mdc-actions">
			<button type="button" class="mvweb-btn mvweb-btn--primary" data-mvweb-mdc-convert="delete"><?php esc_html_e( 'Delete old files', 'mvweb-media-control' ); ?></button>
			<button type="button" class="mvweb-btn" data-mvweb-mdc-convert="undo"><?php esc_html_e( 'Undo conversion', 'mvweb-media-control' ); ?></button>
		</div>
	</div>

<?php endif; ?>

<?php if ( ! empty( $mvweb_mdc_cstats['kept_files'] ) ) : ?>
	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Old files kept because a link to them cannot be replaced', 'mvweb-media-control' ); ?></summary>
		<div class="mvweb-faq__body">
			<p class="mvweb-mdc-note"><?php esc_html_e( 'The link is inside a value this plugin does not rewrite (an object or an encoded form) or points to another address. Replace the image in that place by hand; the file is deleted together with its image.', 'mvweb-media-control' ); ?></p>
			<div class="mvweb-table-wrap mvweb-mdc-scroll">
				<table class="mvweb-table">
					<thead>
						<tr>
							<th scope="col"><?php esc_html_e( 'File', 'mvweb-media-control' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Where used', 'mvweb-media-control' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( array_keys( $mvweb_mdc_cstats['kept_files'] ) as $mvweb_mdc_file ) : ?>
							<tr>
								<td><code><?php echo esc_html( (string) $mvweb_mdc_file ); ?></code></td>
								<td>
									<button type="button" class="mvweb-btn mvweb-btn--sm" data-mvweb-mdc-where="<?php echo esc_attr( (string) $mvweb_mdc_file ); ?>"><?php esc_html_e( 'Where used', 'mvweb-media-control' ); ?></button>
									<ul class="mvweb-mdc-where" hidden></ul>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</div>
	</details>
<?php endif; ?>
