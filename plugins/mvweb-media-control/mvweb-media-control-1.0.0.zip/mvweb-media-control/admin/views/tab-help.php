<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-media-control' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Turn on WebP conversion', 'mvweb-media-control' ); ?></strong>
			<p><?php esc_html_e( 'New JPEG, PNG and HEIC uploads are saved as WebP together with all their sizes.', 'mvweb-media-control' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Decide on originals', 'mvweb-media-control' ); ?></strong>
			<p><?php esc_html_e( 'Turn on deleting originals to keep only WebP files on disk. The original resolution above the scaled copy is lost.', 'mvweb-media-control' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Disable unneeded sizes', 'mvweb-media-control' ); ?></strong>
			<p><?php esc_html_e( 'Tick the sizes your theme does not use. They are no longer created for new uploads.', 'mvweb-media-control' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-media-control' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Why do disabled sizes stay registered?', 'mvweb-media-control' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Page builders and widgets check the size registry when they output images. Removing a size from it breaks srcset and image dimensions, so the plugin only stops the files from being created.', 'mvweb-media-control' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Are existing images changed?', 'mvweb-media-control' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Not by the upload settings: they apply to new uploads only. Existing JPEG and PNG images are converted on the Conversion tab.', 'mvweb-media-control' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How does converting existing images work?', 'mvweb-media-control' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'WP-Cron converts a few images every five minutes, so the load is spread over the chosen period. Every image gets WebP files and sizes, then links to the old files in posts, fields, options and Yoast SEO are replaced. The old files stay until you delete them in the last step after purging the page cache. Until then Undo returns the metadata, the links and the files. A value the plugin cannot rewrite safely (an object, an encoded link, another domain) is left as it is, and its file is kept.', 'mvweb-media-control' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Conversion is slower than planned', 'mvweb-media-control' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'WP-Cron runs only when someone visits the site, and a slow server converts fewer images per run. Ask the hosting to call wp-cron.php every five minutes, or run "wp mvweb-media-control convert run" over SSH.', 'mvweb-media-control' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Why does cleanup take two steps?', 'mvweb-media-control' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Cached pages keep the old srcset. Step A only removes sizes from metadata, so cached pages still find their files. After you purge the page cache and CDN, step B deletes the files. Until step B, Undo returns everything instantly.', 'mvweb-media-control' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can deleted files be brought back?', 'mvweb-media-control' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Registered sizes are regenerated from the originals with Restore sizes. There is no byte-for-byte undo: a full rollback is only possible from a hosting backup. If the plugin is removed between step A and step B, the files stay on disk without metadata.', 'mvweb-media-control' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How are unused images found and removed?', 'mvweb-media-control' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'An image counts as used when its file name appears in any table of the site or in the theme code, or its ID is stored in a known field. Images uploaded less than 30 days ago are not offered. Images something may still show are listed under "Check by hand". Moving to the trash keeps the files on disk for 30 days; the site then deletes them. If content links to an image again before that, it is put back from the trash. The trash does not work when EMPTY_TRASH_DAYS is 0 in wp-config.php.', 'mvweb-media-control' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can I regenerate thumbnails with other plugins?', 'mvweb-media-control' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Regenerate Thumbnails and wp media regenerate without --skip-delete delete size files without checking whether content links to them. Use them with care.', 'mvweb-media-control' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-media-control' ); ?></div>
	</div>
	<p>
		<?php
		printf(
			/* translators: %s: MVweb plugin URL */
			esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-media-control' ),
			'<a href="https://mvweb.ru/plugins/mvweb-media-control" target="_blank" rel="noopener">mvweb.ru</a>'
		);
		?>
	</p>
	<p class="mvweb-block__sub">
		<?php
		printf(
			/* translators: %s: plugin version */
			esc_html__( 'Version %s', 'mvweb-media-control' ),
			esc_html( MVWEB_MDC_VERSION )
		);
		?>
	</p>
</div>
