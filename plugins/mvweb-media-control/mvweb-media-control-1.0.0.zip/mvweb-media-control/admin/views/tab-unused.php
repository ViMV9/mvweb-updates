<?php
/**
 * Unused images tab: scan, report, trash, restore, purge.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_mdc_ureport  = MVweb_MDC_Unused::report();
$mvweb_mdc_ujob     = MVweb_MDC_Unused::get_job();
$mvweb_mdc_urunning = MVweb_MDC_Unused::is_running();
$mvweb_mdc_blocker  = MVweb_MDC_Unused::trash_blocker();
$mvweb_mdc_trashed  = MVweb_MDC_Unused::trashed_groups();
$mvweb_mdc_ugroup   = isset( $_GET['ugroup'] ) && 'manual' === $_GET['ugroup'] ? 'manual' : 'unused'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only filter.
$mvweb_mdc_upaged   = isset( $_GET['upaged'] ) ? max( 1, absint( $_GET['upaged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only paging.
$mvweb_mdc_per_page = 50;

$mvweb_mdc_ureasons = array(
	'bad_meta'  => __( 'metadata is damaged, files cannot be listed', 'mvweb-media-control' ),
	'id_match'  => __( 'its ID is stored in a field named like an image', 'mvweb-media-control' ),
	'header'    => __( 'uploaded as a header or background image', 'mvweb-media-control' ),
	'attached'  => __( 'attached to a published post without a link', 'mvweb-media-control' ),
	'too_new'   => __( 'uploaded less than 30 days ago', 'mvweb-media-control' ),
	'site_icon' => __( 'site icon', 'mvweb-media-control' ),
	'busy'      => __( 'a cleanup or conversion journal is open', 'mvweb-media-control' ),
	'offloaded' => __( 'stored by an offload plugin', 'mvweb-media-control' ),
);

$mvweb_mdc_rows = array();
foreach ( $mvweb_mdc_ureport['list'] ?? array() as $mvweb_mdc_leader => $mvweb_mdc_entry ) {
	if ( $mvweb_mdc_ugroup === $mvweb_mdc_entry['status'] ) {
		$mvweb_mdc_rows[ (int) $mvweb_mdc_leader ] = $mvweb_mdc_entry;
	}
}
uasort( $mvweb_mdc_rows, static fn( array $a, array $b ): int => $b['bytes'] <=> $a['bytes'] );

$mvweb_mdc_pages = max( 1, (int) ceil( count( $mvweb_mdc_rows ) / $mvweb_mdc_per_page ) );
$mvweb_mdc_page  = array_slice( $mvweb_mdc_rows, ( min( $mvweb_mdc_upaged, $mvweb_mdc_pages ) - 1 ) * $mvweb_mdc_per_page, $mvweb_mdc_per_page, true );
$mvweb_mdc_base  = admin_url( 'admin.php?page=' . MVweb_MDC_Admin::PAGE . '&tab=unused' );
$mvweb_mdc_date  = get_option( 'date_format' );
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Unused images', 'mvweb-media-control' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Finds images nothing on the site refers to: by file name in any table of the site, by ID in known fields (featured images, product galleries, blocks, galleries, widgets, logo, ACF, Yoast SEO) and in the code of the active theme. Selected images go to the trash: their files stay on disk for 30 days, pages keep working, and until then they can be restored. After that the site deletes them with all their sizes.', 'mvweb-media-control' ); ?></p>
	<div class="mvweb-alert mvweb-alert--warning">
		<div class="mvweb-alert__body"><?php esc_html_e( 'Not seen: plugin code, images a plugin picks at random or by a query, links from other sites, emails, feeds and image search. After final deletion such links lead to missing files. Galleries built with the [gallery] shortcode or the Gallery widget stop showing an image as soon as it is in the trash.', 'mvweb-media-control' ); ?></div>
	</div>
</div>

<div class="mvweb-block" data-mvweb-mdc-uprogress<?php echo $mvweb_mdc_urunning ? '' : ' hidden'; ?>>
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Scan in progress', 'mvweb-media-control' ); ?></div>
	</div>
	<p class="mvweb-block__sub" data-mvweb-mdc-ulabel><?php echo $mvweb_mdc_urunning ? esc_html__( 'Paused. Press Continue to resume.', 'mvweb-media-control' ) : ''; ?></p>
	<div class="mvweb-progress"><span class="mvweb-progress__bar" data-mvweb-mdc-ubar style="width:0%"></span></div>
	<div class="mvweb-mdc-actions">
		<button type="button" class="mvweb-btn mvweb-btn--primary" data-mvweb-mdc-unused="step"<?php echo $mvweb_mdc_urunning ? '' : ' hidden'; ?>><?php esc_html_e( 'Continue', 'mvweb-media-control' ); ?></button>
		<button type="button" class="mvweb-btn" data-mvweb-mdc-unused="cancel"><?php esc_html_e( 'Cancel task', 'mvweb-media-control' ); ?></button>
	</div>
</div>

<div class="mvweb-alert mvweb-alert--error" data-mvweb-mdc-umessage hidden>
	<div class="mvweb-alert__body"></div>
</div>

<?php if ( 'index_write' === ( $mvweb_mdc_ujob['error'] ?? '' ) ) : ?>
	<div class="mvweb-alert mvweb-alert--error">
		<div class="mvweb-alert__body"><?php esc_html_e( 'The last task stopped: the link index could not be saved. The database may reject large values (max_allowed_packet).', 'mvweb-media-control' ); ?></div>
	</div>
<?php endif; ?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( '1. Scan', 'mvweb-media-control' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Reads every table of the site and the theme code. Nothing is changed. On a large site it takes a few minutes.', 'mvweb-media-control' ); ?></p>

	<?php if ( ! empty( $mvweb_mdc_ureport['at'] ) ) : ?>
		<p>
			<?php
			echo esc_html(
				sprintf(
					/* translators: 1: date, 2: number of attachments */
					__( 'Last scan: %1$s, %2$d images.', 'mvweb-media-control' ),
					wp_date( $mvweb_mdc_date . ' ' . get_option( 'time_format' ), (int) $mvweb_mdc_ureport['at'] ),
					(int) $mvweb_mdc_ureport['attachments']
				)
			);
			?>
		</p>

		<div class="mvweb-metrics">
			<div class="mvweb-metric">
				<div class="mvweb-metric__label"><?php esc_html_e( 'No references found', 'mvweb-media-control' ); ?></div>
				<div class="mvweb-metric__value"><?php echo esc_html( (string) (int) $mvweb_mdc_ureport['stats']['unused']['groups'] ); ?></div>
				<div class="mvweb-metric__delta"><?php echo esc_html( size_format( (int) $mvweb_mdc_ureport['stats']['unused']['bytes'] ) ); ?></div>
			</div>
			<div class="mvweb-metric">
				<div class="mvweb-metric__label"><?php esc_html_e( 'Check by hand', 'mvweb-media-control' ); ?></div>
				<div class="mvweb-metric__value"><?php echo esc_html( (string) (int) $mvweb_mdc_ureport['stats']['manual']['groups'] ); ?></div>
				<div class="mvweb-metric__delta"><?php echo esc_html( size_format( (int) $mvweb_mdc_ureport['stats']['manual']['bytes'] ) ); ?></div>
			</div>
			<div class="mvweb-metric">
				<div class="mvweb-metric__label"><?php esc_html_e( 'In use', 'mvweb-media-control' ); ?></div>
				<div class="mvweb-metric__value"><?php echo esc_html( (string) (int) $mvweb_mdc_ureport['stats']['used'] ); ?></div>
			</div>
		</div>

		<?php if ( ! empty( $mvweb_mdc_ureport['stats']['skipped'] ) ) : ?>
			<p class="mvweb-block__sub">
				<?php
				$mvweb_mdc_parts = array();
				foreach ( $mvweb_mdc_ureport['stats']['skipped'] as $mvweb_mdc_reason => $mvweb_mdc_count ) {
					$mvweb_mdc_parts[] = ( $mvweb_mdc_ureasons[ $mvweb_mdc_reason ] ?? $mvweb_mdc_reason ) . ': ' . (int) $mvweb_mdc_count;
				}
				echo esc_html( __( 'Not checked:', 'mvweb-media-control' ) . ' ' . implode( '; ', $mvweb_mdc_parts ) );
				?>
			</p>
		<?php endif; ?>

		<?php if ( ! empty( $mvweb_mdc_ureport['unread'] ) ) : ?>
			<div class="mvweb-alert mvweb-alert--warning">
				<div class="mvweb-alert__body"><?php echo esc_html( __( 'These tables could not be read, links in them are not seen:', 'mvweb-media-control' ) . ' ' . implode( ', ', array_map( 'strval', $mvweb_mdc_ureport['unread'] ) ) ); ?></div>
			</div>
		<?php endif; ?>
	<?php endif; ?>

	<div class="mvweb-mdc-actions">
		<button type="button" class="mvweb-btn mvweb-btn--primary" data-mvweb-mdc-unused="scan" <?php disabled( $mvweb_mdc_urunning ); ?>><?php esc_html_e( 'Find unused images', 'mvweb-media-control' ); ?></button>
	</div>
</div>

<?php if ( ! empty( $mvweb_mdc_ureport['at'] ) ) : ?>
	<div class="mvweb-block" data-mvweb-mdc-uform>
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( '2. Review and move to the trash', 'mvweb-media-control' ); ?></div>
		</div>

		<div class="mvweb-tabs">
			<a class="mvweb-tabs__tab<?php echo 'unused' === $mvweb_mdc_ugroup ? ' mvweb-tabs__tab--active' : ''; ?>" href="<?php echo esc_url( $mvweb_mdc_base . '&ugroup=unused' ); ?>"><?php esc_html_e( 'No references found', 'mvweb-media-control' ); ?></a>
			<a class="mvweb-tabs__tab<?php echo 'manual' === $mvweb_mdc_ugroup ? ' mvweb-tabs__tab--active' : ''; ?>" href="<?php echo esc_url( $mvweb_mdc_base . '&ugroup=manual' ); ?>"><?php esc_html_e( 'Check by hand', 'mvweb-media-control' ); ?></a>
		</div>

		<p class="mvweb-block__sub">
			<?php
			echo 'manual' === $mvweb_mdc_ugroup
				? esc_html__( 'Something may still show these images: open the post or field named in the reason before moving them to the trash.', 'mvweb-media-control' )
				: esc_html__( 'Nothing found refers to these images. The heaviest are at the top. Open a few of them to make sure.', 'mvweb-media-control' );
			?>
		</p>

		<?php if ( ! $mvweb_mdc_page ) : ?>
			<p><?php esc_html_e( 'Nothing here.', 'mvweb-media-control' ); ?></p>
		<?php else : ?>
			<div class="mvweb-table-wrap mvweb-mdc-scroll">
				<table class="mvweb-table">
					<thead>
						<tr>
							<th scope="col"><input type="checkbox" data-mvweb-mdc-uall aria-label="<?php esc_attr_e( 'Select all on this page', 'mvweb-media-control' ); ?>"></th>
							<th scope="col"><?php esc_html_e( 'Image', 'mvweb-media-control' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Uploaded', 'mvweb-media-control' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Space', 'mvweb-media-control' ); ?></th>
							<th scope="col"><?php esc_html_e( 'Attached to', 'mvweb-media-control' ); ?></th>
							<?php if ( 'manual' === $mvweb_mdc_ugroup ) : ?>
								<th scope="col"><?php esc_html_e( 'Why check', 'mvweb-media-control' ); ?></th>
							<?php endif; ?>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $mvweb_mdc_page as $mvweb_mdc_leader => $mvweb_mdc_entry ) : ?>
							<?php
							$mvweb_mdc_parent = (int) get_post_field( 'post_parent', $mvweb_mdc_leader );
							$mvweb_mdc_file   = (string) get_post_meta( $mvweb_mdc_leader, '_wp_attached_file', true );
							?>
							<tr>
								<td><input type="checkbox" name="mdc_unused[]" value="<?php echo esc_attr( (string) $mvweb_mdc_leader ); ?>" aria-label="<?php echo esc_attr( wp_basename( $mvweb_mdc_file ) ); ?>"></td>
								<td>
									<div class="mvweb-mdc-image">
										<?php echo wp_get_attachment_image( $mvweb_mdc_leader, array( 60, 60 ), false, array( 'loading' => 'lazy' ) ); ?>
										<div>
											<a href="<?php echo esc_url( (string) get_edit_post_link( $mvweb_mdc_leader ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( wp_basename( $mvweb_mdc_file ) ); ?></a>
											<?php if ( count( $mvweb_mdc_entry['ids'] ) > 1 ) : ?>
												<span class="mvweb-badge mvweb-badge--plain mvweb-badge--small"><?php echo esc_html( sprintf( /* translators: %d: number of attachments sharing one file */ _n( '%d attachment with one file', '%d attachments with one file', count( $mvweb_mdc_entry['ids'] ), 'mvweb-media-control' ), count( $mvweb_mdc_entry['ids'] ) ) ); ?></span>
											<?php endif; ?>
										</div>
									</div>
								</td>
								<td><?php echo esc_html( (string) get_the_date( $mvweb_mdc_date, $mvweb_mdc_leader ) ); ?></td>
								<td><?php echo esc_html( size_format( (int) $mvweb_mdc_entry['bytes'] ) ); ?></td>
								<td>
									<?php if ( $mvweb_mdc_parent && get_post( $mvweb_mdc_parent ) ) : ?>
										<a href="<?php echo esc_url( (string) get_edit_post_link( $mvweb_mdc_parent ) ); ?>" target="_blank" rel="noopener"><?php echo esc_html( get_the_title( $mvweb_mdc_parent ) ? get_the_title( $mvweb_mdc_parent ) : '#' . $mvweb_mdc_parent ); ?></a>
									<?php else : ?>
										&mdash;
									<?php endif; ?>
								</td>
								<?php if ( 'manual' === $mvweb_mdc_ugroup ) : ?>
									<td><?php echo esc_html( $mvweb_mdc_ureasons[ $mvweb_mdc_entry['reason'] ] ?? $mvweb_mdc_entry['reason'] ); ?></td>
								<?php endif; ?>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>

			<?php if ( $mvweb_mdc_pages > 1 ) : ?>
				<div class="mvweb-pagination">
					<?php for ( $mvweb_mdc_i = 1; $mvweb_mdc_i <= $mvweb_mdc_pages; $mvweb_mdc_i++ ) : ?>
						<a class="<?php echo min( $mvweb_mdc_upaged, $mvweb_mdc_pages ) === $mvweb_mdc_i ? 'current' : ''; ?>" href="<?php echo esc_url( $mvweb_mdc_base . '&ugroup=' . $mvweb_mdc_ugroup . '&upaged=' . $mvweb_mdc_i ); ?>"><?php echo esc_html( (string) $mvweb_mdc_i ); ?></a>
					<?php endfor; ?>
				</div>
			<?php endif; ?>

			<?php if ( '' !== $mvweb_mdc_blocker ) : ?>
				<div class="mvweb-alert mvweb-alert--warning">
					<div class="mvweb-alert__body"><?php echo esc_html( $mvweb_mdc_blocker ); ?></div>
				</div>
			<?php endif; ?>

			<div class="mvweb-mdc-actions">
				<button type="button" class="mvweb-btn mvweb-btn--primary" data-mvweb-mdc-unused="trash" <?php disabled( '' !== $mvweb_mdc_blocker ); ?>><?php esc_html_e( 'Move selected to the trash', 'mvweb-media-control' ); ?></button>
				<a class="mvweb-btn" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=mvweb_mdc_unused_csv&group=' . $mvweb_mdc_ugroup ), 'mvweb_mdc_unused_csv' ) ); ?>"><?php esc_html_e( 'Download CSV', 'mvweb-media-control' ); ?></a>
				<span data-mvweb-mdc-ustatus></span>
			</div>
		<?php endif; ?>
	</div>
<?php endif; ?>

<?php if ( $mvweb_mdc_trashed ) : ?>
	<div class="mvweb-block" data-mvweb-mdc-uform>
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( '3. In the trash', 'mvweb-media-control' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Files stay on disk until the date shown, then the site deletes them. Deletion needs WP-Cron and runs after a visit to the admin area. To delete earlier, use the button below.', 'mvweb-media-control' ); ?></p>

		<div class="mvweb-table-wrap mvweb-mdc-scroll">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th scope="col"><input type="checkbox" data-mvweb-mdc-uall aria-label="<?php esc_attr_e( 'Select all on this page', 'mvweb-media-control' ); ?>"></th>
						<th scope="col"><?php esc_html_e( 'Image', 'mvweb-media-control' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Deleted after', 'mvweb-media-control' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( array_slice( $mvweb_mdc_trashed, 0, 200, true ) as $mvweb_mdc_leader => $mvweb_mdc_members ) : ?>
						<tr>
							<td><input type="checkbox" name="mdc_unused[]" value="<?php echo esc_attr( (string) $mvweb_mdc_leader ); ?>" aria-label="<?php echo esc_attr( wp_basename( (string) get_post_meta( $mvweb_mdc_leader, '_wp_attached_file', true ) ) ); ?>"></td>
							<td><?php echo esc_html( wp_basename( (string) get_post_meta( $mvweb_mdc_leader, '_wp_attached_file', true ) ) ); ?></td>
							<td><?php echo esc_html( wp_date( $mvweb_mdc_date, MVweb_MDC_Unused::delete_after( $mvweb_mdc_leader ) ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php if ( count( $mvweb_mdc_trashed ) > 200 ) : ?>
			<p class="mvweb-mdc-note"><?php echo esc_html( sprintf( /* translators: %d: number of images */ __( 'The first 200 of %d are listed.', 'mvweb-media-control' ), count( $mvweb_mdc_trashed ) ) ); ?></p>
		<?php endif; ?>

		<div class="mvweb-toggle-row">
			<input type="checkbox" id="mvweb_mdc_ubackup" name="mdc_backup" value="1">
			<label for="mvweb_mdc_ubackup"><?php esc_html_e( 'A backup of uploads and the database is made', 'mvweb-media-control' ); ?></label>
		</div>

		<div class="mvweb-mdc-actions">
			<button type="button" class="mvweb-btn mvweb-btn--primary" data-mvweb-mdc-unused="restore"><?php esc_html_e( 'Restore selected', 'mvweb-media-control' ); ?></button>
			<button type="button" class="mvweb-btn mvweb-btn--danger" data-mvweb-mdc-unused="purge"><?php esc_html_e( 'Delete selected now', 'mvweb-media-control' ); ?></button>
			<span data-mvweb-mdc-ustatus></span>
		</div>
	</div>
<?php endif; ?>
