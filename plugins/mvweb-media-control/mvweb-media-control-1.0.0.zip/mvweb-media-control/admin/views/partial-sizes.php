<?php
/**
 * Image sizes table with sources: rendered on the Uploads tab and by the sources AJAX request.
 *
 * Expects $mvweb_mdc_sources: sources from MVweb_MDC_Sources, or null before the first scan.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_mdc_settings = mvweb_mdc_get_settings();
$mvweb_mdc_sizes    = wp_get_registered_image_subsizes();
$mvweb_mdc_used     = (array) get_option( MVweb_MDC_Uploads::USED_OPTION, array() );
$mvweb_mdc_names    = array_map( 'strval', array_keys( $mvweb_mdc_sizes ) );
$mvweb_mdc_scanned  = is_array( $mvweb_mdc_sources );
$mvweb_mdc_unused   = $mvweb_mdc_scanned ? array_values( array_diff( array_intersect( MVweb_MDC_Sources::unused( $mvweb_mdc_sources, $mvweb_mdc_used ), $mvweb_mdc_names ), $mvweb_mdc_settings['disabled_sizes'] ) ) : array();
$mvweb_mdc_media    = array_diff( array_intersect( MVweb_MDC_Sources::MEDIA_SETTINGS, $mvweb_mdc_names ), $mvweb_mdc_settings['disabled_sizes'] );
$mvweb_mdc_notes    = array(
	'thumbnail'    => __( 'Without it, the media library list view loads full images.', 'mvweb-media-control' ),
	'medium'       => __( 'Without it, the media library grid loads the large size or a bigger file.', 'mvweb-media-control' ),
	'large'        => __( 'Used in srcset and offered when inserting an image into a post. Without it, some screens get a bigger file.', 'mvweb-media-control' ),
	'medium_large' => __( 'Only used in srcset. Without it, some screens get a bigger file.', 'mvweb-media-control' ),
	'1536x1536'    => __( 'Only used in srcset. Without it, wide and retina screens get a bigger file.', 'mvweb-media-control' ),
	'2048x2048'    => __( 'Only used in srcset. Without it, wide and retina screens get a bigger file.', 'mvweb-media-control' ),
);
?>

<?php if ( $mvweb_mdc_media ) : ?>
	<div class="mvweb-alert mvweb-alert--info">
		<div class="mvweb-alert__body">
			<p class="mvweb-alert__title"><?php esc_html_e( 'Sizes from Settings → Media', 'mvweb-media-control' ); ?></p>
			<?php
			echo wp_kses(
				sprintf(
					/* translators: 1: size names, 2: link to Settings → Media */
					esc_html__( '%1$s are set in %2$s and are created for every upload. To stop creating them, tick "Do not create" below. Do not set them to 0 there: WordPress then drops the size from its list, and page builders lose srcset.', 'mvweb-media-control' ),
					'<code>' . implode( '</code>, <code>', array_map( 'esc_html', $mvweb_mdc_media ) ) . '</code>',
					'<a href="' . esc_url( admin_url( 'options-media.php' ) ) . '">' . esc_html__( 'Settings → Media', 'mvweb-media-control' ) . '</a>'
				),
				array(
					'code' => array(),
					'a'    => array( 'href' => array() ),
				)
			);
			?>
		</div>
	</div>
<?php endif; ?>

<?php if ( $mvweb_mdc_unused ) : ?>
	<div class="mvweb-alert mvweb-alert--warning">
		<div class="mvweb-alert__body">
			<?php
			echo wp_kses(
				sprintf(
					/* translators: %s: size names */
					esc_html__( 'No theme or plugin registers or asks for these sizes: %s. WordPress itself still uses them in srcset or in the media library: read the note under each size before saving.', 'mvweb-media-control' ),
					'<code>' . implode( '</code>, <code>', array_map( 'esc_html', $mvweb_mdc_unused ) ) . '</code>'
				),
				array( 'code' => array() )
			);
			?>
		</div>
		<div class="mvweb-mdc-actions">
			<button type="button" class="mvweb-btn" data-mvweb-mdc-mark-unused><?php esc_html_e( 'Mark unused sizes', 'mvweb-media-control' ); ?></button>
			<span data-mvweb-mdc-mark-status></span>
		</div>
	</div>
<?php endif; ?>

<div class="mvweb-table-wrap">
	<table class="mvweb-table">
		<thead>
			<tr>
				<th scope="col"><?php esc_html_e( 'Size', 'mvweb-media-control' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Created by', 'mvweb-media-control' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Dimensions', 'mvweb-media-control' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Crop', 'mvweb-media-control' ); ?></th>
				<th scope="col"><?php esc_html_e( 'Do not create', 'mvweb-media-control' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $mvweb_mdc_sizes as $mvweb_mdc_name => $mvweb_mdc_size ) : ?>
				<?php
				$mvweb_mdc_name       = (string) $mvweb_mdc_name;
				$mvweb_mdc_registrars = $mvweb_mdc_sources['registrars'][ $mvweb_mdc_name ] ?? array();
				$mvweb_mdc_callers    = array_values( array_diff( $mvweb_mdc_sources['callers'][ $mvweb_mdc_name ] ?? array(), $mvweb_mdc_registrars ) );
				$mvweb_mdc_is_core    = in_array( $mvweb_mdc_name, MVweb_MDC_Sources::CORE, true );
				$mvweb_mdc_is_unused  = in_array( $mvweb_mdc_name, $mvweb_mdc_unused, true );
				$mvweb_mdc_needed     = in_array( $mvweb_mdc_name, $mvweb_mdc_settings['disabled_sizes'], true ) ? $mvweb_mdc_registrars : array();
				if ( $mvweb_mdc_is_core ) {
					array_unshift( $mvweb_mdc_registrars, 'WordPress' );
				}
				?>
				<tr>
					<td>
						<code><?php echo esc_html( $mvweb_mdc_name ); ?></code>
						<?php if ( in_array( $mvweb_mdc_name, $mvweb_mdc_used, true ) ) : ?>
							<span class="mvweb-badge mvweb-badge--warning mvweb-badge--small"><?php esc_html_e( 'used on site', 'mvweb-media-control' ); ?></span>
						<?php endif; ?>
						<?php if ( $mvweb_mdc_needed ) : ?>
							<span class="mvweb-badge mvweb-badge--warning mvweb-badge--small"><?php echo esc_html( sprintf( /* translators: %s: themes and plugins */ __( 'disabled, needed by %s', 'mvweb-media-control' ), implode( ', ', $mvweb_mdc_needed ) ) ); ?></span>
						<?php endif; ?>
						<?php if ( $mvweb_mdc_is_unused ) : ?>
							<span class="mvweb-badge mvweb-badge--plain mvweb-badge--small"><?php esc_html_e( 'not used', 'mvweb-media-control' ); ?></span>
						<?php endif; ?>
					</td>
					<td>
						<?php if ( $mvweb_mdc_registrars ) : ?>
							<?php echo esc_html( implode( ', ', $mvweb_mdc_registrars ) ); ?>
							<?php if ( in_array( $mvweb_mdc_name, MVweb_MDC_Sources::MEDIA_SETTINGS, true ) ) : ?>
								· <a href="<?php echo esc_url( admin_url( 'options-media.php' ) ); ?>"><?php esc_html_e( 'Settings → Media', 'mvweb-media-control' ); ?></a>
							<?php endif; ?>
						<?php elseif ( ! $mvweb_mdc_scanned ) : ?>
							—
						<?php else : ?>
							<span class="mvweb-badge mvweb-badge--plain mvweb-badge--small"><?php esc_html_e( 'source not found', 'mvweb-media-control' ); ?></span>
						<?php endif; ?>
						<?php if ( $mvweb_mdc_callers ) : ?>
							<p class="mvweb-mdc-note">
								<?php
								echo esc_html(
									sprintf(
										/* translators: %s: list of themes and plugins */
										__( 'Asked for by name: %s', 'mvweb-media-control' ),
										count( $mvweb_mdc_callers ) > 3
											? sprintf(
												/* translators: 1: first themes and plugins, 2: number of the rest */
												__( '%1$s and %2$d more', 'mvweb-media-control' ),
												implode( ', ', array_slice( $mvweb_mdc_callers, 0, 3 ) ),
												count( $mvweb_mdc_callers ) - 3
											)
											: implode( ', ', $mvweb_mdc_callers )
									)
								);
								?>
							</p>
						<?php endif; ?>
						<?php if ( isset( $mvweb_mdc_notes[ $mvweb_mdc_name ] ) ) : ?>
							<p class="mvweb-mdc-note"><?php echo esc_html( $mvweb_mdc_notes[ $mvweb_mdc_name ] ); ?></p>
						<?php endif; ?>
					</td>
					<td><?php echo esc_html( (int) $mvweb_mdc_size['width'] . ' × ' . (int) $mvweb_mdc_size['height'] ); ?></td>
					<td><?php echo $mvweb_mdc_size['crop'] ? esc_html__( 'Yes', 'mvweb-media-control' ) : esc_html__( 'No', 'mvweb-media-control' ); ?></td>
					<td>
						<input type="checkbox"
							name="mvweb_mdc_settings[disabled_sizes][]"
							value="<?php echo esc_attr( $mvweb_mdc_name ); ?>"
							aria-label="<?php echo esc_attr( sprintf( /* translators: %s: image size name */ __( 'Do not create %s', 'mvweb-media-control' ), $mvweb_mdc_name ) ); ?>"
							<?php echo $mvweb_mdc_is_unused ? 'data-mvweb-mdc-unused' : ''; ?>
							<?php checked( in_array( $mvweb_mdc_name, $mvweb_mdc_settings['disabled_sizes'], true ) ); ?>>
					</td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>
