<?php
/**
 * Admin settings page template.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 * Reference: docs/ui-kit-reference.html
 *
 * Структура:
 *   .wrap.mvweb-settings  — корневой контейнер (max-width 1280px из UI Kit)
 *     ├── aside.mvweb-sidebar  — левая колонка 272px (бренд + меню вкладок)
 *     │     └── ul.mvweb-nav   — вкладки рендерятся как nav-ссылки с иконкой
 *     └── main.mvweb-main      — правая колонка (header + контент вкладок)
 *
 * Каждая вкладка — отдельный partial admin/views/tab-{slug}.php.
 * Переключение вкладок — на JS (admin.js), классы .mvweb-tab-content.active.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_mdc_current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'uploads'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.

$mvweb_mdc_tabs = array(
	'uploads' => array(
		'label' => __( 'Uploads', 'mvweb-media-control' ),
		'count' => null,
		'icon'  => 'image',
	),
	'cleanup' => array(
		'label' => __( 'Cleanup', 'mvweb-media-control' ),
		'count' => MVweb_MDC_Cleaner::pending_count() ? MVweb_MDC_Cleaner::pending_count() : null,
		'icon'  => 'trash',
	),
	'convert' => array(
		'label' => __( 'Conversion', 'mvweb-media-control' ),
		'count' => MVweb_MDC_Converter::journal_count() ? MVweb_MDC_Converter::journal_count() : null,
		'icon'  => 'convert',
	),
	'unused'  => array(
		'label' => __( 'Unused', 'mvweb-media-control' ),
		'count' => MVweb_MDC_Unused::trashed_groups() ? count( MVweb_MDC_Unused::trashed_groups() ) : null,
		'icon'  => 'search',
	),
	'help'    => array(
		'label' => __( 'Help', 'mvweb-media-control' ),
		'count' => null,
		'icon'  => 'help',
	),
);

$mvweb_mdc_icons = array(
	'image'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></svg>',
	'trash'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/></svg>',
	'convert' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M17 1l4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><path d="M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>',
	'search'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/></svg>',
	'help'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">MDC</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Media Control', 'mvweb-media-control' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_MDC_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $mvweb_mdc_tabs as $mvweb_mdc_tab_id => $mvweb_mdc_tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $mvweb_mdc_tab_id ); ?>"
						class="mvweb-nav__link <?php echo $mvweb_mdc_current_tab === $mvweb_mdc_tab_id ? 'mvweb-nav__link--active' : ''; ?>"
						data-tab="<?php echo esc_attr( $mvweb_mdc_tab_id ); ?>">
						<?php echo $mvweb_mdc_icons[ $mvweb_mdc_tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $mvweb_mdc_tab['label'] ); ?>
						<?php if ( null !== $mvweb_mdc_tab['count'] ) : ?>
							<span class="mvweb-nav__badge"><?php echo esc_html( (string) $mvweb_mdc_tab['count'] ); ?></span>
						<?php endif; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php settings_errors(); ?>

		<div id="uploads" class="mvweb-tab-content <?php echo 'uploads' === $mvweb_mdc_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_MDC_PATH . 'admin/views/tab-uploads.php'; ?>
		</div>

		<div id="cleanup" class="mvweb-tab-content <?php echo 'cleanup' === $mvweb_mdc_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_MDC_PATH . 'admin/views/tab-cleanup.php'; ?>
		</div>

		<div id="convert" class="mvweb-tab-content <?php echo 'convert' === $mvweb_mdc_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_MDC_PATH . 'admin/views/tab-convert.php'; ?>
		</div>

		<div id="unused" class="mvweb-tab-content <?php echo 'unused' === $mvweb_mdc_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_MDC_PATH . 'admin/views/tab-unused.php'; ?>
		</div>

		<div id="help" class="mvweb-tab-content <?php echo 'help' === $mvweb_mdc_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_MDC_PATH . 'admin/views/tab-help.php'; ?>
		</div>

	</main>
</div>
