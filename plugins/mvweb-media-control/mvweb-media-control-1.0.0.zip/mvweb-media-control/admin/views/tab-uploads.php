<?php
/**
 * Uploads tab: WebP conversion and image sizes.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_mdc_settings = mvweb_mdc_get_settings();
$mvweb_mdc_webp_ok  = mvweb_mdc_can_write_webp();
$mvweb_mdc_kept     = mvweb_mdc_kept_originals_count();
$mvweb_mdc_switched = (string) get_option( MVweb_MDC_Uploads::THEME_NOTICE, '' );

if ( '' !== $mvweb_mdc_switched ) {
	delete_option( MVweb_MDC_Uploads::THEME_NOTICE );
}
?>

<form method="post" action="options.php">
	<?php settings_fields( MVweb_MDC_Admin::OPTION_GROUP ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'WebP', 'mvweb-media-control' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Applies to new uploads only. Existing images are converted on the Conversion tab.', 'mvweb-media-control' ); ?></p>

		<?php if ( ! $mvweb_mdc_webp_ok ) : ?>
			<div class="mvweb-alert mvweb-alert--warning">
				<div class="mvweb-alert__body"><?php esc_html_e( 'The server image editor cannot write WebP (GD or Imagick without WebP support). Conversion is unavailable.', 'mvweb-media-control' ); ?></div>
			</div>
		<?php endif; ?>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Convert to WebP', 'mvweb-media-control' ); ?></span>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_mdc_convert_webp"
							name="mvweb_mdc_settings[convert_webp]"
							value="1"
							<?php checked( $mvweb_mdc_settings['convert_webp'] && $mvweb_mdc_webp_ok ); ?>
							<?php disabled( ! $mvweb_mdc_webp_ok ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<label for="mvweb_mdc_convert_webp"><?php esc_html_e( 'Convert new JPEG, PNG and HEIC uploads to WebP', 'mvweb-media-control' ); ?></label>
				</div>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'The main file and all sizes are saved as WebP. GIF and SVG are not converted.', 'mvweb-media-control' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Delete originals', 'mvweb-media-control' ); ?></span>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_mdc_delete_originals"
							name="mvweb_mdc_settings[delete_originals]"
							value="1"
							data-mvweb-mdc-requires="mvweb_mdc_convert_webp"
							<?php checked( $mvweb_mdc_settings['delete_originals'] && $mvweb_mdc_settings['convert_webp'] && $mvweb_mdc_webp_ok ); ?>
							<?php disabled( ! ( $mvweb_mdc_settings['convert_webp'] && $mvweb_mdc_webp_ok ) ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<label for="mvweb_mdc_delete_originals"><?php esc_html_e( 'Delete the original JPEG, PNG or HEIC after a successful conversion', 'mvweb-media-control' ); ?></label>
				</div>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'The original is deleted only when the main file is WebP and every size has been created. Otherwise it is kept.', 'mvweb-media-control' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'WebP quality', 'mvweb-media-control' ); ?></span>
			<div class="mvweb-form-row__field">
				<?php foreach ( mvweb_mdc_webp_qualities() as $mvweb_mdc_value => $mvweb_mdc_label ) : ?>
					<label class="mvweb-mdc-radio"><input type="radio" name="mvweb_mdc_settings[webp_quality]" value="<?php echo esc_attr( (string) $mvweb_mdc_value ); ?>" <?php checked( $mvweb_mdc_settings['webp_quality'], $mvweb_mdc_value ); ?> <?php disabled( ! $mvweb_mdc_webp_ok ); ?>> <?php echo esc_html( $mvweb_mdc_label ); ?></label>
				<?php endforeach; ?>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Applies to every WebP file the site creates from now on: new uploads, conversion on the Conversion tab and regenerated sizes. Files already on disk are not recompressed. Some server image libraries ignore this setting, and then file sizes do not change.', 'mvweb-media-control' ); ?></p>
			</div>
		</div>

		<div class="mvweb-alert mvweb-alert--info">
			<div class="mvweb-alert__body"><?php esc_html_e( 'Without the original, the largest version is the scaled copy (up to 2560 px by default): the original resolution is lost for good. Sizes are regenerated from WebP with recompression.', 'mvweb-media-control' ); ?></div>
		</div>

		<?php if ( $mvweb_mdc_kept > 0 ) : ?>
			<div class="mvweb-alert mvweb-alert--warning">
				<div class="mvweb-alert__body">
					<?php
					echo esc_html(
						sprintf(
							/* translators: %d: number of images */
							_n(
								'Original kept for %d image: not every size was created, so it was not deleted.',
								'Originals kept for %d images: not every size was created, so they were not deleted.',
								$mvweb_mdc_kept,
								'mvweb-media-control'
							),
							$mvweb_mdc_kept
						)
					);
					?>
				</div>
				<div class="mvweb-mdc-actions">
					<button type="button" class="mvweb-btn" data-mvweb-mdc-originals><?php esc_html_e( 'Create missing sizes and delete originals', 'mvweb-media-control' ); ?></button>
					<span data-mvweb-mdc-originals-status></span>
				</div>
			</div>
		<?php endif; ?>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Image sizes', 'mvweb-media-control' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Disabled sizes are not created for new uploads. Sizes stay registered, so themes and page builders keep working.', 'mvweb-media-control' ); ?></p>
		<p class="mvweb-block__sub"><?php esc_html_e( 'The "used on site" badge means a page requested this size by name. If it is disabled, such pages get the full image instead. The badge only covers pages opened since the plugin was installed and not served from the page cache.', 'mvweb-media-control' ); ?></p>
		<p class="mvweb-block__sub"><?php esc_html_e( 'The "Created by" column comes from the code of the active theme and plugins. A size registered by a theme or plugin is needed by it. "Asked for by name" lists code that mentions the size.', 'mvweb-media-control' ); ?></p>
		<?php if ( '' !== $mvweb_mdc_switched ) : ?>
			<div class="mvweb-alert mvweb-alert--warning">
				<div class="mvweb-alert__body">
					<?php
					echo esc_html(
						sprintf(
							/* translators: %s: theme name */
							__( 'The theme was switched to %s. Disabled sizes are kept by name: check the "Created by" column and enable the sizes the new theme registers.', 'mvweb-media-control' ),
							$mvweb_mdc_switched
						)
					);
					?>
				</div>
			</div>
		<?php endif; ?>

		<p class="mvweb-mdc-note" data-mvweb-mdc-scan hidden><span class="mvweb-spinner"></span> <?php esc_html_e( 'Checking the theme and plugins…', 'mvweb-media-control' ); ?></p>

		<div data-mvweb-mdc-sizes>
			<?php MVweb_MDC_Admin::render_sizes( MVweb_MDC_Sources::cached() ); ?>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Save Changes', 'mvweb-media-control' ); ?>
		</button>
	</div>
</form>
