<?php
/**
 * Cleanup tab: scan, step A, step B, undo, restore.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_mdc_report     = get_option( MVweb_MDC_Cleaner::REPORT_OPTION, array() );
$mvweb_mdc_job        = MVweb_MDC_Cleaner::get_job();
$mvweb_mdc_running    = MVweb_MDC_Cleaner::is_running();
$mvweb_mdc_pending    = MVweb_MDC_Cleaner::pending_summary();
$mvweb_mdc_selectable = MVweb_MDC_Cleaner::selectable_sizes();
$mvweb_mdc_restorable = MVweb_MDC_Cleaner::restorable_sizes();
$mvweb_mdc_registered = mvweb_mdc_allowed_size_names();
$mvweb_mdc_disabled   = mvweb_mdc_get_settings()['disabled_sizes'];

$mvweb_mdc_reasons = array(
	'bad_meta'    => __( 'metadata is damaged', 'mvweb-media-control' ),
	'not_image'   => __( 'not an image', 'mvweb-media-control' ),
	'unsupported' => __( 'the server cannot process this format', 'mvweb-media-control' ),
	'no_original' => __( 'no original file to regenerate from', 'mvweb-media-control' ),
	'edited'      => __( 'edited in the image editor', 'mvweb-media-control' ),
	'too_new'     => __( 'uploaded less than an hour ago', 'mvweb-media-control' ),
	'offloaded'   => __( 'stored by an offload plugin', 'mvweb-media-control' ),
	'site_icon'   => __( 'site icon', 'mvweb-media-control' ),
	'group'       => __( 'a translation of this file is skipped', 'mvweb-media-control' ),
);

$mvweb_mdc_actions = array(
	'scan'    => __( 'Scan', 'mvweb-media-control' ),
	'apply'   => __( 'Step A', 'mvweb-media-control' ),
	'delete'  => __( 'Step B', 'mvweb-media-control' ),
	'undo'    => __( 'Undo', 'mvweb-media-control' ),
	'restore' => __( 'Restore', 'mvweb-media-control' ),
);

$mvweb_mdc_stat_labels = array(
	'sizes'        => __( 'sizes removed from metadata', 'mvweb-media-control' ),
	'protected'    => __( 'sizes kept: file is used', 'mvweb-media-control' ),
	'skipped'      => __( 'attachments skipped', 'mvweb-media-control' ),
	'deleted'      => __( 'files deleted', 'mvweb-media-control' ),
	'bytes'        => __( 'space freed', 'mvweb-media-control' ),
	'kept'         => __( 'files kept: now in use', 'mvweb-media-control' ),
	'not_deleted'  => __( 'files not deleted (permissions)', 'mvweb-media-control' ),
	'restored'     => __( 'sizes restored', 'mvweb-media-control' ),
	'lost'         => __( 'sizes not restored: file is gone', 'mvweb-media-control' ),
	'not_restored' => __( 'sizes not regenerated', 'mvweb-media-control' ),
);
?>

<div class="mvweb-block" data-mvweb-mdc-progress<?php echo $mvweb_mdc_running ? '' : ' hidden'; ?>>
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Task in progress', 'mvweb-media-control' ); ?></div>
	</div>
	<p class="mvweb-block__sub" data-mvweb-mdc-label><?php echo $mvweb_mdc_running ? esc_html__( 'Paused. Press Continue to resume.', 'mvweb-media-control' ) : ''; ?></p>
	<div class="mvweb-progress"><span class="mvweb-progress__bar" data-mvweb-mdc-bar style="width:0%"></span></div>
	<div class="mvweb-mdc-actions">
		<button type="button" class="mvweb-btn mvweb-btn--primary" data-mvweb-mdc-continue<?php echo $mvweb_mdc_running ? '' : ' hidden'; ?>><?php esc_html_e( 'Continue', 'mvweb-media-control' ); ?></button>
		<button type="button" class="mvweb-btn" data-mvweb-mdc-pause hidden><?php esc_html_e( 'Pause', 'mvweb-media-control' ); ?></button>
		<button type="button" class="mvweb-btn" data-mvweb-mdc-cancel><?php esc_html_e( 'Cancel task', 'mvweb-media-control' ); ?></button>
	</div>
</div>

<div class="mvweb-alert mvweb-alert--error" data-mvweb-mdc-message hidden>
	<div class="mvweb-alert__body"></div>
</div>

<?php if ( ! empty( $mvweb_mdc_job['finished'] ) && empty( $mvweb_mdc_job['error'] ) && ! empty( $mvweb_mdc_job['stats'] ) && 'scan' !== $mvweb_mdc_job['action'] ) : ?>
	<div class="mvweb-alert mvweb-alert--success">
		<div class="mvweb-alert__title"><?php echo esc_html( sprintf( /* translators: %s: task name */ __( 'Last task: %s', 'mvweb-media-control' ), $mvweb_mdc_actions[ $mvweb_mdc_job['action'] ] ?? '' ) ); ?></div>
		<div class="mvweb-alert__body">
			<?php
			$mvweb_mdc_lines = array();
			foreach ( $mvweb_mdc_job['stats'] as $mvweb_mdc_key => $mvweb_mdc_value ) {
				if ( isset( $mvweb_mdc_stat_labels[ $mvweb_mdc_key ] ) && is_scalar( $mvweb_mdc_value ) ) {
					$mvweb_mdc_lines[] = $mvweb_mdc_stat_labels[ $mvweb_mdc_key ] . ': ' . ( 'bytes' === $mvweb_mdc_key ? size_format( (int) $mvweb_mdc_value ) : (int) $mvweb_mdc_value );
				}
			}
			if ( $mvweb_mdc_job['failed'] ) {
				$mvweb_mdc_lines[] = __( 'failed attachments (IDs)', 'mvweb-media-control' ) . ': ' . implode( ', ', array_unique( array_map( 'intval', $mvweb_mdc_job['failed'] ) ) );
			}
			echo esc_html( implode( '; ', $mvweb_mdc_lines ) );
			?>
		</div>
	</div>
<?php elseif ( ! empty( $mvweb_mdc_job['error'] ) && 'cancelled' !== $mvweb_mdc_job['error'] ) : ?>
	<div class="mvweb-alert mvweb-alert--error">
		<div class="mvweb-alert__body"><?php esc_html_e( 'The last task stopped: the link index could not be saved. The database may reject large values (max_allowed_packet).', 'mvweb-media-control' ); ?></div>
	</div>
<?php endif; ?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( '1. Scan', 'mvweb-media-control' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Reads content and metadata and counts the files of every size. Nothing is changed.', 'mvweb-media-control' ); ?></p>

	<?php if ( ! empty( $mvweb_mdc_report['at'] ) ) : ?>
		<p>
			<?php
			echo esc_html(
				sprintf(
					/* translators: 1: date, 2: number of attachments */
					__( 'Last scan: %1$s, %2$d images.', 'mvweb-media-control' ),
					wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $mvweb_mdc_report['at'] ),
					(int) $mvweb_mdc_report['attachments']
				)
			);
			?>
			<?php if ( ! empty( $mvweb_mdc_report['stale'] ) ) : ?>
				<span class="mvweb-badge mvweb-badge--warning mvweb-badge--small"><?php esc_html_e( 'outdated, scan again', 'mvweb-media-control' ); ?></span>
			<?php endif; ?>
		</p>
	<?php endif; ?>

	<div class="mvweb-mdc-actions">
		<button type="button" class="mvweb-btn mvweb-btn--primary" data-mvweb-mdc-task="scan" <?php disabled( $mvweb_mdc_running ); ?>><?php esc_html_e( 'Scan', 'mvweb-media-control' ); ?></button>
	</div>
</div>

<?php if ( ! empty( $mvweb_mdc_report['sizes'] ) ) : ?>
	<div class="mvweb-block" data-mvweb-mdc-form>
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( '2. Step A: remove sizes from metadata', 'mvweb-media-control' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Only disabled sizes and sizes no longer registered by the theme can be selected. Files stay on disk until step B, so pages cached with the old srcset keep working.', 'mvweb-media-control' ); ?></p>

		<div class="mvweb-table-wrap mvweb-mdc-scroll">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Size', 'mvweb-media-control' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Images', 'mvweb-media-control' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Files', 'mvweb-media-control' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Space', 'mvweb-media-control' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Protected', 'mvweb-media-control' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Skipped', 'mvweb-media-control' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Clean', 'mvweb-media-control' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $mvweb_mdc_report['sizes'] as $mvweb_mdc_name => $mvweb_mdc_row ) : ?>
						<?php
						$mvweb_mdc_name   = (string) $mvweb_mdc_name;
						$mvweb_mdc_status = '';
						if ( ! in_array( $mvweb_mdc_name, $mvweb_mdc_registered, true ) ) {
							$mvweb_mdc_status = __( 'not registered', 'mvweb-media-control' );
						} elseif ( in_array( $mvweb_mdc_name, $mvweb_mdc_disabled, true ) ) {
							$mvweb_mdc_status = __( 'disabled', 'mvweb-media-control' );
						}
						?>
						<tr>
							<td>
								<code><?php echo esc_html( $mvweb_mdc_name ); ?></code>
								<?php if ( '' !== $mvweb_mdc_status ) : ?>
									<span class="mvweb-badge mvweb-badge--plain mvweb-badge--small"><?php echo esc_html( $mvweb_mdc_status ); ?></span>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( (string) (int) $mvweb_mdc_row['attachments'] ); ?></td>
							<td><?php echo esc_html( (string) (int) $mvweb_mdc_row['files'] ); ?></td>
							<td><?php echo esc_html( size_format( (int) $mvweb_mdc_row['bytes'] ) ); ?></td>
							<td><?php echo esc_html( (string) (int) $mvweb_mdc_row['protected'] ); ?></td>
							<td><?php echo esc_html( (string) (int) $mvweb_mdc_row['skipped'] ); ?></td>
							<td>
								<?php if ( in_array( $mvweb_mdc_name, $mvweb_mdc_selectable, true ) ) : ?>
									<input type="checkbox" name="mdc_sizes[]" value="<?php echo esc_attr( $mvweb_mdc_name ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: image size name */ __( 'Clean %s', 'mvweb-media-control' ), $mvweb_mdc_name ) ); ?>">
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<?php if ( ! empty( $mvweb_mdc_report['skipped'] ) ) : ?>
			<p class="mvweb-block__sub">
				<?php
				$mvweb_mdc_parts = array();
				foreach ( $mvweb_mdc_report['skipped'] as $mvweb_mdc_reason => $mvweb_mdc_count ) {
					$mvweb_mdc_parts[] = ( $mvweb_mdc_reasons[ $mvweb_mdc_reason ] ?? $mvweb_mdc_reason ) . ': ' . (int) $mvweb_mdc_count;
				}
				echo esc_html( __( 'Images skipped, their sizes could not be regenerated:', 'mvweb-media-control' ) . ' ' . implode( '; ', $mvweb_mdc_parts ) );
				?>
			</p>
		<?php endif; ?>

		<?php if ( ! empty( $mvweb_mdc_report['not_freed']['files'] ) ) : ?>
			<p class="mvweb-block__sub">
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: number of files, 2: size */
						__( 'Not freed: %1$d optimizer copies named without the original extension (%2$s). Their owner cannot be told apart, so this plugin leaves them; some optimizers remove such copies themselves.', 'mvweb-media-control' ),
						(int) $mvweb_mdc_report['not_freed']['files'],
						size_format( (int) $mvweb_mdc_report['not_freed']['bytes'] )
					)
				);
				?>
			</p>
		<?php endif; ?>

		<?php if ( ! empty( $mvweb_mdc_report['linked'] ) ) : ?>
			<details class="mvweb-faq">
				<summary>
					<?php
					echo esc_html(
						sprintf(
							/* translators: %d: number of files */
							_n( 'Kept because content links to it: %d file', 'Kept because content links to them: %d files', (int) $mvweb_mdc_report['linked_total'], 'mvweb-media-control' ),
							(int) $mvweb_mdc_report['linked_total']
						)
					);
					?>
				</summary>
				<div class="mvweb-faq__body">
					<?php if ( (int) $mvweb_mdc_report['linked_total'] > count( $mvweb_mdc_report['linked'] ) ) : ?>
						<p class="mvweb-mdc-note"><?php echo esc_html( sprintf( /* translators: %d: number of files */ __( 'The first %d are listed.', 'mvweb-media-control' ), count( $mvweb_mdc_report['linked'] ) ) ); ?></p>
					<?php endif; ?>
					<div class="mvweb-table-wrap mvweb-mdc-scroll">
						<table class="mvweb-table">
							<thead>
								<tr>
									<th scope="col"><?php esc_html_e( 'File', 'mvweb-media-control' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Size', 'mvweb-media-control' ); ?></th>
									<th scope="col"><?php esc_html_e( 'Where used', 'mvweb-media-control' ); ?></th>
								</tr>
							</thead>
							<tbody>
								<?php foreach ( $mvweb_mdc_report['linked'] as $mvweb_mdc_file => $mvweb_mdc_size_name ) : ?>
									<tr>
										<td><code><?php echo esc_html( (string) $mvweb_mdc_file ); ?></code></td>
										<td><code><?php echo esc_html( (string) $mvweb_mdc_size_name ); ?></code></td>
										<td>
											<button type="button" class="mvweb-btn mvweb-btn--sm" data-mvweb-mdc-where="<?php echo esc_attr( (string) $mvweb_mdc_file ); ?>"><?php esc_html_e( 'Where used', 'mvweb-media-control' ); ?></button>
											<ul class="mvweb-mdc-where" hidden></ul>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>
					</div>
				</div>
			</details>
		<?php endif; ?>

		<div class="mvweb-alert mvweb-alert--warning">
			<div class="mvweb-alert__body"><?php esc_html_e( 'Files are kept when content, meta or options link to them. Links in custom plugin tables, theme files, other sites, feeds and emails cannot be found. Sizes that are not registered cannot be regenerated after step B.', 'mvweb-media-control' ); ?></div>
		</div>

		<div class="mvweb-toggle-row">
			<input type="checkbox" id="mvweb_mdc_backup" name="mdc_backup" value="1">
			<label for="mvweb_mdc_backup"><?php esc_html_e( 'A backup of uploads and the database is made', 'mvweb-media-control' ); ?></label>
		</div>

		<div class="mvweb-mdc-actions">
			<button type="button" class="mvweb-btn mvweb-btn--primary" data-mvweb-mdc-task="apply" <?php disabled( $mvweb_mdc_running ); ?>><?php esc_html_e( 'Step A: remove from metadata', 'mvweb-media-control' ); ?></button>
		</div>
	</div>
<?php endif; ?>

<?php if ( $mvweb_mdc_pending['attachments'] > 0 ) : ?>
	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( '3. Step B: delete files', 'mvweb-media-control' ); ?></div>
		</div>
		<ol class="mvweb-steps">
			<li><div><?php esc_html_e( 'Purge the page cache (caching plugin, hosting) and the CDN cache. The Elementor cache was cleared automatically.', 'mvweb-media-control' ); ?></div></li>
			<li><div><?php esc_html_e( 'Regenerate product feeds (Yandex Market, Google Merchant and others) if they use a reduced image size: feed files keep the old links.', 'mvweb-media-control' ); ?></div></li>
			<li><div><?php esc_html_e( 'Open a few pages and make sure the images show.', 'mvweb-media-control' ); ?></div></li>
			<li><div><?php esc_html_e( 'Delete the files. Before deleting, every file is checked again against the current content.', 'mvweb-media-control' ); ?></div></li>
		</ol>
		<div class="mvweb-mdc-actions">
			<button type="button" class="mvweb-btn mvweb-btn--primary" data-mvweb-mdc-task="delete" <?php disabled( $mvweb_mdc_running ); ?>>
				<?php
				echo esc_html(
					sprintf(
						/* translators: 1: number of files, 2: size */
						_n( 'Step B: delete %1$d file (%2$s)', 'Step B: delete %1$d files (%2$s)', $mvweb_mdc_pending['files'], 'mvweb-media-control' ),
						$mvweb_mdc_pending['files'],
						size_format( $mvweb_mdc_pending['bytes'] )
					)
				);
				?>
			</button>
			<button type="button" class="mvweb-btn" data-mvweb-mdc-task="undo" <?php disabled( $mvweb_mdc_running ); ?>><?php esc_html_e( 'Undo step A', 'mvweb-media-control' ); ?></button>
		</div>
	</div>
<?php endif; ?>

<div class="mvweb-block" data-mvweb-mdc-form>
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Restore sizes', 'mvweb-media-control' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Regenerates missing files of the selected sizes from the originals. To restore a disabled size, enable it on the Uploads tab first. This is CPU-heavy; ShortPixel and similar services spend quota on new files.', 'mvweb-media-control' ); ?></p>

	<div class="mvweb-mdc-checks">
		<?php foreach ( $mvweb_mdc_restorable as $mvweb_mdc_name ) : ?>
			<label><input type="checkbox" name="mdc_sizes[]" value="<?php echo esc_attr( $mvweb_mdc_name ); ?>"> <code><?php echo esc_html( $mvweb_mdc_name ); ?></code></label>
		<?php endforeach; ?>
	</div>

	<div class="mvweb-mdc-actions">
		<button type="button" class="mvweb-btn" data-mvweb-mdc-task="restore" <?php disabled( $mvweb_mdc_running ); ?>><?php esc_html_e( 'Restore sizes', 'mvweb-media-control' ); ?></button>
	</div>
</div>
