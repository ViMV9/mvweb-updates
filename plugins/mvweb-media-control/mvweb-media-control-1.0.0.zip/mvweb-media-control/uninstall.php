<?php
/**
 * Uninstall MVweb Media Control
 *
 * Removes plugin options and post meta. Files in uploads are not touched.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Delete plugin data for the current site.
 *
 * @return void
 */
function mvweb_mdc_uninstall_site() {
	global $wpdb;

	foreach ( array( 'mvweb_mdc_settings', 'mvweb_mdc_used_sizes', 'mvweb_mdc_job', 'mvweb_mdc_report', 'mvweb_mdc_index', 'mvweb_mdc_lock', 'mvweb_mdc_sources', 'mvweb_mdc_theme_notice', 'mvweb_mdc_convert_job', 'mvweb_mdc_convert_estimate', 'mvweb_mdc_unused_job', 'mvweb_mdc_unused_report' ) as $option ) {
		delete_option( $option );
	}

	$chunks = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s", $wpdb->esc_like( 'mdc_idx_' ) . '%', $wpdb->esc_like( 'mdc_uidx_' ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	foreach ( $chunks as $chunk ) {
		delete_option( $chunk );
	}

	delete_post_meta_by_key( '_mvweb_mdc_source' );
	delete_post_meta_by_key( '_mvweb_mdc_pending' );
	delete_post_meta_by_key( '_mvweb_mdc_convert' );
	delete_post_meta_by_key( '_mvweb_mdc_links' );
	delete_post_meta_by_key( '_mvweb_mdc_kept' );
	delete_post_meta_by_key( '_mvweb_mdc_trashed' );
	delete_transient( 'mvweb_mdc_unused_ids' );

	wp_clear_scheduled_hook( 'mvweb_mdc_convert' );
}

if ( is_multisite() ) {
	foreach ( get_sites(
		array(
			'fields' => 'ids',
			'number' => 0,
		)
	) as $mvweb_mdc_site_id ) {
		switch_to_blog( $mvweb_mdc_site_id );
		mvweb_mdc_uninstall_site();
		restore_current_blog();
	}
} else {
	mvweb_mdc_uninstall_site();
}
