<?php
/**
 * Who registers each image size and who asks for it by name.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Size sources found in the code of the active theme and plugins.
 *
 * The add_image_size() function has no hook, so the only way to learn who registered a
 * size is to read the code. Calls are found with the PHP tokenizer: comments,
 * method calls and strings are skipped. The first argument is resolved when it
 * is built from string literals and constants (THEME_SLUG . '_card',
 * self::IMAGE_SIZE); anything else is left unknown.
 *
 * @since 1.0.0
 */
final class MVweb_MDC_Sources {

	const OPTION = 'mvweb_mdc_sources';

	const CORE = array( 'thumbnail', 'medium', 'medium_large', 'large', '1536x1536', '2048x2048' );

	const MEDIA_SETTINGS = array( 'thumbnail', 'medium', 'large' );

	const MAX_FILE_BYTES = 5242880;

	/**
	 * Sources for the registered sizes, rescanned when the theme, plugins or sizes change.
	 *
	 * A component counts as changed when the number of its PHP files or the
	 * latest modification time among them changes: a single file edited over
	 * SFTP leaves style.css and the main plugin file untouched.
	 *
	 * @since 1.0.0
	 * @param string[] $names Registered size names.
	 * @return array{registrars: array<string, string[]>, callers: array<string, string[]>}
	 */
	public static function get( array $names ): array {
		$components = self::components();
		$stamps     = array();

		foreach ( $components as $i => $component ) {
			$files  = self::php_files( $component['path'] );
			$latest = 0;

			foreach ( $files as $file ) {
				$latest = max( $latest, (int) @filemtime( $file ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- a file removed during the walk only loses its time.
			}

			$components[ $i ]['files']    = $files;
			$stamps[ $component['path'] ] = array( count( $files ), $latest );
		}

		$hash  = md5( (string) wp_json_encode( array( $stamps, $names ) ) );
		$saved = get_option( self::OPTION );

		if ( is_array( $saved ) && ( $saved['hash'] ?? '' ) === $hash ) {
			return $saved;
		}

		$data         = self::scan( $components, $names );
		$data['hash'] = $hash;

		update_option( self::OPTION, $data, false );

		return $data;
	}

	/**
	 * Sources from the last scan, without touching the file system.
	 *
	 * @since 1.0.0
	 * @return array|null Null before the first scan.
	 */
	public static function cached(): ?array {
		$saved = get_option( self::OPTION );

		return is_array( $saved ) && isset( $saved['hash'] ) ? $saved : null;
	}

	/**
	 * Core sizes that no theme or plugin registers or asks for by name.
	 *
	 * Sizes of unknown origin are never included: a missed source is safer
	 * than a disabled size the theme needs.
	 *
	 * @since 1.0.0
	 * @param array    $sources Result of get().
	 * @param string[] $used    Sizes seen on the front end.
	 * @return string[]
	 */
	public static function unused( array $sources, array $used ): array {
		$unused = array();

		foreach ( self::CORE as $name ) {
			if ( empty( $sources['registrars'][ $name ] ) && empty( $sources['callers'][ $name ] ) && ! in_array( $name, $used, true ) ) {
				$unused[] = $name;
			}
		}

		return $unused;
	}

	/**
	 * Active theme, parent theme, active plugins and must-use plugins.
	 *
	 * @since 1.0.0
	 * @return array<int, array{label: string, path: string}>
	 */
	private static function components(): array {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$components = array();
		$theme      = wp_get_theme();

		foreach ( array_unique( array( get_stylesheet_directory(), get_template_directory() ) ) as $dir ) {
			$current      = get_template_directory() === $dir && $theme->parent() ? $theme->parent() : $theme;
			$components[] = array(
				/* translators: %s: theme name */
				'label' => sprintf( __( 'Theme %s', 'mvweb-media-control' ), $current->get( 'Name' ) ),
				'path'  => $dir,
			);
		}

		$active = (array) get_option( 'active_plugins', array() );

		if ( is_multisite() ) {
			$active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', array() ) ) );
		}

		$plugins = get_plugins();

		foreach ( array_unique( $active ) as $file ) {
			$file = (string) $file;
			$main = WP_PLUGIN_DIR . '/' . $file;

			if ( MVWEB_MDC_BASENAME === $file || ! is_file( $main ) ) {
				continue;
			}

			$components[] = array(
				/* translators: %s: plugin name */
				'label' => sprintf( __( 'Plugin %s', 'mvweb-media-control' ), $plugins[ $file ]['Name'] ?? $file ),
				'path'  => '.' === dirname( $file ) ? $main : dirname( $main ),
			);
		}

		if ( is_dir( WPMU_PLUGIN_DIR ) ) {
			$components[] = array(
				'label' => __( 'Must-use plugins', 'mvweb-media-control' ),
				'path'  => WPMU_PLUGIN_DIR,
			);
		}

		return $components;
	}

	/**
	 * Read the PHP files of each component.
	 *
	 * @since 1.0.0
	 * @param array    $components Components with their PHP files.
	 * @param string[] $names      Registered size names.
	 * @return array{registrars: array<string, string[]>, callers: array<string, string[]>}
	 */
	private static function scan( array $components, array $names ): array {
		$registrars = array();
		$callers    = array();

		foreach ( $components as $component ) {
			foreach ( $component['files'] as $file ) {
				if ( filesize( $file ) > self::MAX_FILE_BYTES ) {
					continue;
				}

				$code = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local file.

				if ( false === $code ) {
					continue;
				}

				if ( str_contains( $code, 'add_image_size' ) || str_contains( $code, 'set_post_thumbnail_size' ) ) {
					foreach ( self::registrations( $code ) as $name ) {
						$registrars[ $name ][ $component['label'] ] = true;
					}
				}

				foreach ( $names as $name ) {
					if ( ! isset( $callers[ $name ][ $component['label'] ] ) && ( str_contains( $code, "'" . $name . "'" ) || str_contains( $code, '"' . $name . '"' ) ) ) {
						$callers[ $name ][ $component['label'] ] = true;
					}
				}
			}
		}

		return array(
			'registrars' => array_map( 'array_keys', $registrars ),
			'callers'    => array_map( 'array_keys', $callers ),
		);
	}

	/**
	 * PHP files of a directory tree, or the file itself.
	 *
	 * @since 1.0.0
	 * @param string $path Directory or file.
	 * @return string[]
	 */
	private static function php_files( string $path ): array {
		if ( is_file( $path ) ) {
			return array( $path );
		}

		$files = array();

		try {
			$iterator = new RecursiveIteratorIterator(
				new RecursiveCallbackFilterIterator(
					new RecursiveDirectoryIterator( $path, FilesystemIterator::SKIP_DOTS ),
					static function ( SplFileInfo $item ): bool {
						return ! ( $item->isDir() && in_array( $item->getFilename(), array( 'node_modules', '.git' ), true ) );
					}
				),
				RecursiveIteratorIterator::LEAVES_ONLY,
				RecursiveIteratorIterator::CATCH_GET_CHILD
			);

			foreach ( $iterator as $item ) {
				if ( 'php' === strtolower( $item->getExtension() ) ) {
					$files[] = $item->getPathname();
				}
			}
		} catch ( UnexpectedValueException ) {
			return $files;
		}

		return $files;
	}

	/**
	 * Size names registered by add_image_size() and set_post_thumbnail_size() calls.
	 *
	 * @since 1.0.0
	 * @param string $code PHP source.
	 * @return string[]
	 */
	private static function registrations( string $code ): array {
		$tokens = array_values(
			array_filter(
				token_get_all( $code ),
				static function ( $token ): bool {
					return ! is_array( $token ) || ! in_array( $token[0], array( T_WHITESPACE, T_COMMENT, T_DOC_COMMENT ), true );
				}
			)
		);

		$names     = array();
		$namespace = '';
		$class     = '';
		$count     = count( $tokens );

		for ( $i = 0; $i < $count; $i++ ) {
			$token = $tokens[ $i ];

			if ( ! is_array( $token ) ) {
				continue;
			}

			$prev = $tokens[ $i - 1 ] ?? null;
			$prev = is_array( $prev ) ? $prev[0] : $prev;

			if ( T_NAMESPACE === $token[0] && isset( $tokens[ $i + 1 ][1] ) && in_array( $tokens[ $i + 1 ][0], array( T_STRING, T_NAME_QUALIFIED ), true ) ) {
				$namespace = $tokens[ $i + 1 ][1];
				continue;
			}

			if ( in_array( $token[0], array( T_CLASS, T_TRAIT, T_ENUM ), true ) && T_DOUBLE_COLON !== $prev && isset( $tokens[ $i + 1 ][1] ) && T_STRING === $tokens[ $i + 1 ][0] ) {
				$class = ltrim( $namespace . '\\' . $tokens[ $i + 1 ][1], '\\' );
				continue;
			}

			$function = strtolower( ltrim( $token[1], '\\' ) );

			if ( ! in_array( $token[0], array( T_STRING, T_NAME_FULLY_QUALIFIED ), true ) || ! in_array( $function, array( 'add_image_size', 'set_post_thumbnail_size' ), true ) ) {
				continue;
			}

			if ( in_array( $prev, array( T_OBJECT_OPERATOR, T_NULLSAFE_OBJECT_OPERATOR, T_DOUBLE_COLON, T_FUNCTION, T_NEW, T_CONST ), true ) || '(' !== ( $tokens[ $i + 1 ] ?? null ) ) {
				continue;
			}

			if ( 'set_post_thumbnail_size' === $function ) {
				$names[] = 'post-thumbnail';
				continue;
			}

			$argument = array();
			$depth    = 0;

			for ( $j = $i + 2; $j < $count; $j++ ) {
				$part = $tokens[ $j ];

				if ( 0 === $depth && ( ',' === $part || ')' === $part ) ) {
					break;
				}

				if ( in_array( $part, array( '(', '[' ), true ) ) {
					++$depth;
				} elseif ( in_array( $part, array( ')', ']' ), true ) ) {
					--$depth;
				}

				$argument[] = $part;
			}

			$name = self::resolve( $argument, $namespace, $class );

			if ( null !== $name && '' !== $name ) {
				$names[] = $name;
			}
		}

		return array_unique( $names );
	}

	/**
	 * Value of an argument made of string literals and constants joined by dots.
	 *
	 * Classes are not autoloaded: a constant of a class that is not loaded yet
	 * stays unknown.
	 *
	 * @since 1.0.0
	 * @param array  $tokens         Argument tokens.
	 * @param string $file_namespace Namespace of the file.
	 * @param string $current_class  Class the call is in.
	 * @return string|null
	 */
	private static function resolve( array $tokens, string $file_namespace, string $current_class ): ?string {
		$value = '';
		$count = count( $tokens );

		for ( $i = 0; $i < $count; $i++ ) {
			$token = $tokens[ $i ];

			if ( $i % 2 ) {
				if ( '.' !== $token ) {
					return null;
				}
				continue;
			}

			if ( ! is_array( $token ) ) {
				return null;
			}

			if ( T_CONSTANT_ENCAPSED_STRING === $token[0] ) {
				$quote  = $token[1][0];
				$inner  = substr( $token[1], 1, -1 );
				$value .= "'" === $quote ? str_replace( array( "\\'", '\\\\' ), array( "'", '\\' ), $inner ) : stripcslashes( $inner );
				continue;
			}

			if ( ! in_array( $token[0], array( T_STRING, T_NAME_QUALIFIED, T_NAME_FULLY_QUALIFIED, T_STATIC ), true ) ) {
				return null;
			}

			if ( T_DOUBLE_COLON === ( $tokens[ $i + 1 ][0] ?? null ) && T_STRING === ( $tokens[ $i + 2 ][0] ?? null ) ) {
				$owner = in_array( strtolower( $token[1] ), array( 'self', 'static' ), true ) ? $current_class : ltrim( $token[1], '\\' );

				if ( '' === $owner || ! class_exists( $owner, false ) || ! defined( $owner . '::' . $tokens[ $i + 2 ][1] ) ) {
					return null;
				}

				$value .= (string) constant( $owner . '::' . $tokens[ $i + 2 ][1] );

				array_splice( $tokens, $i + 1, 2 );
				$count -= 2;
				continue;
			}

			$constant = ltrim( $token[1], '\\' );
			$local    = '' !== $file_namespace && T_STRING === $token[0] ? $file_namespace . '\\' . $constant : '';

			if ( '' !== $local && defined( $local ) ) {
				$value .= (string) constant( $local );
			} elseif ( defined( $constant ) ) {
				$value .= (string) constant( $constant );
			} else {
				return null;
			}
		}

		return $value;
	}
}
