<?php
/**
 * Conversion of existing JPEG and PNG images to WebP.
 *
 * WP-Cron runs three phases spread over the chosen period: convert (new WebP
 * files and metadata, old files stay), index and links (old URLs in the
 * database replaced). Old files are deleted later by a button, after the page
 * cache is purged. Until then every change is journaled and can be undone.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Conversion engine.
 *
 * @since 1.0.0
 */
final class MVweb_MDC_Converter {

	const JOB_OPTION = 'mvweb_mdc_convert_job';

	const ESTIMATE_OPTION = 'mvweb_mdc_convert_estimate';

	const JOURNAL = '_mvweb_mdc_convert';

	const LINKS = '_mvweb_mdc_links';

	const KEPT = '_mvweb_mdc_kept';

	const HOOK = 'mvweb_mdc_convert';

	const SCHEDULE = 'mvweb_mdc_5min';

	const INTERVAL = 300;

	const SLICE = 20;

	const PERIODS = array(
		'day'   => DAY_IN_SECONDS,
		'2days' => 2 * DAY_IN_SECONDS,
		'week'  => WEEK_IN_SECONDS,
	);

	const GAIN = 0.22;

	const SOURCE_EXT = array( 'jpg', 'jpeg', 'jpe', 'png' );

	const LIKE_LIMIT = 1000;

	/**
	 * Register hooks.
	 *
	 * The lost-event check runs only in the admin and WP-Cron: the job option
	 * is not autoloaded and would cost a query on every front-end visit.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_filter( 'cron_schedules', array( __CLASS__, 'schedules' ) ); // phpcs:ignore WordPress.WP.CronInterval -- five minutes, one slice each.
		add_action( self::HOOK, array( __CLASS__, 'cron' ) );

		if ( is_admin() || wp_doing_cron() ) {
			add_action( 'init', array( __CLASS__, 'ensure_scheduled' ) );
		}

		add_action( 'delete_attachment', array( __CLASS__, 'on_delete_attachment' ) );
	}

	/**
	 * Add the five-minute schedule.
	 *
	 * @since 1.0.0
	 * @param mixed $schedules Schedules.
	 * @return mixed
	 */
	public static function schedules( $schedules ) {
		if ( is_array( $schedules ) ) {
			$schedules[ self::SCHEDULE ] = array(
				'interval' => self::INTERVAL,
				'display'  => __( 'Every 5 minutes (MVweb Media Control)', 'mvweb-media-control' ),
			);
		}

		return $schedules;
	}

	/**
	 * Put the event back when a running job lost it (plugin reactivated, cron table cleared).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ensure_scheduled(): void {
		if ( 'running' === self::status() && ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + self::INTERVAL, self::SCHEDULE, self::HOOK );
		}
	}

	/* ─── Job lifecycle ─────────────────────────────────────────── */

	/**
	 * Current job state.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function get_job(): array {
		$job = get_option( self::JOB_OPTION, array() );
		return is_array( $job ) ? $job : array();
	}

	/**
	 * Job status: running, paused, ready, working, done or empty.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function status(): string {
		return (string) ( self::get_job()['status'] ?? '' );
	}

	/**
	 * Whether conversion owns the media library: a job or journals exist.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function is_active(): bool {
		return in_array( self::status(), array( 'running', 'paused', 'ready', 'working' ), true ) || self::journal_count() > 0;
	}

	/**
	 * Number of attachments with a conversion journal.
	 *
	 * @since 1.0.0
	 * @return int
	 */
	public static function journal_count(): int {
		global $wpdb;

		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s", self::JOURNAL ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Start conversion by WP-Cron.
	 *
	 * @since 1.0.0
	 * @param string $period           Key of self::PERIODS.
	 * @param bool   $delete_originals Delete originals in the final step.
	 * @param bool   $png              Convert PNG as well.
	 * @return array|WP_Error Job state.
	 */
	public static function start( string $period, bool $delete_originals, bool $png ) {
		if ( ! isset( self::PERIODS[ $period ] ) ) {
			return new WP_Error( 'mvweb_mdc_period', __( 'Choose a period.', 'mvweb-media-control' ) );
		}

		if ( ! mvweb_mdc_can_write_webp() ) {
			return new WP_Error( 'mvweb_mdc_webp', __( 'The server image editor cannot write WebP.', 'mvweb-media-control' ) );
		}

		if ( MVweb_MDC_Cleaner::is_running() || MVweb_MDC_Cleaner::pending_count() ) {
			return new WP_Error( 'mvweb_mdc_cleanup', __( 'Finish or undo the cleanup task first: conversion rebuilds the metadata it works with.', 'mvweb-media-control' ) );
		}

		if ( self::is_active() ) {
			return new WP_Error( 'mvweb_mdc_running', __( 'Conversion is already in progress.', 'mvweb-media-control' ) );
		}

		$estimate = get_option( self::ESTIMATE_OPTION, array() );
		$free     = self::free_space();

		if ( null !== $free && is_array( $estimate ) && ! empty( $estimate['growth'] ) && $free < 1.5 * (float) $estimate['growth'] ) {
			return new WP_Error( 'mvweb_mdc_disk', __( 'Not enough free disk space: old and new files are kept together until the final step.', 'mvweb-media-control' ) );
		}

		if ( ! MVweb_MDC_Cleaner::lock() ) {
			return new WP_Error( 'mvweb_mdc_locked', __( 'The task is already running in another tab or process.', 'mvweb-media-control' ) );
		}

		$job = self::new_job( 'cron', array( 'convert', 'index', 'links' ) ) + array(
			'period'           => $period,
			'due'              => time() + self::PERIODS[ $period ],
			'delete_originals' => $delete_originals,
			'png'              => $png,
			'started'          => time(),
		);

		$job['status'] = 'running';

		update_option( self::JOB_OPTION, $job, false );
		MVweb_MDC_Cleaner::unlock();

		wp_clear_scheduled_hook( self::HOOK );
		wp_schedule_event( time(), self::SCHEDULE, self::HOOK );

		return $job;
	}

	/**
	 * Fresh phase state.
	 *
	 * @param string   $mode   cron, delete or undo.
	 * @param string[] $phases Phase names.
	 * @return array
	 */
	private static function new_job( string $mode, array $phases ): array {
		return array(
			'mode'      => $mode,
			'phases'    => $phases,
			'phase'     => 0,
			'entered'   => -1,
			'cursor'    => 0,
			'source'    => 0,
			'current'   => 0,
			'total'     => 0,
			'processed' => 0,
			'stats'     => array(),
			'failed'    => array(),
			'error'     => '',
			'run'       => uniqid( '', true ),
			'last_run'  => 0,
			'finished'  => 0,
		);
	}

	/**
	 * Pause the cron job.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function pause(): void {
		$job = self::get_job();

		if ( 'running' === ( $job['status'] ?? '' ) ) {
			$job['status']    = 'paused';
			$job['paused_at'] = time();
			update_option( self::JOB_OPTION, $job, false );
		}

		wp_clear_scheduled_hook( self::HOOK );
	}

	/**
	 * Resume a paused cron job; the period is extended by the pause.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function resume(): void {
		$job = self::get_job();

		if ( 'paused' !== ( $job['status'] ?? '' ) ) {
			return;
		}

		$job['status'] = 'running';
		$job['due']    = (int) ( $job['due'] ?? time() ) + max( 0, time() - (int) ( $job['paused_at'] ?? time() ) );
		update_option( self::JOB_OPTION, $job, false );

		wp_clear_scheduled_hook( self::HOOK );
		wp_schedule_event( time(), self::SCHEDULE, self::HOOK );
	}

	/**
	 * Start the final step (delete old files) or undo, driven by admin AJAX or WP-CLI.
	 *
	 * @since 1.0.0
	 * @param string $mode delete or undo.
	 * @return array|WP_Error Job state.
	 */
	public static function begin( string $mode ) {
		$job    = self::get_job();
		$status = (string) ( $job['status'] ?? '' );

		if ( 'delete' === $mode && 'ready' !== $status ) {
			return new WP_Error( 'mvweb_mdc_not_ready', __( 'Old files can be deleted after conversion has finished.', 'mvweb-media-control' ) );
		}

		if ( 'undo' === $mode && ! in_array( $status, array( 'running', 'paused', 'ready' ), true ) ) {
			return new WP_Error( 'mvweb_mdc_nothing', __( 'There is nothing to process.', 'mvweb-media-control' ) );
		}

		if ( ! in_array( $mode, array( 'delete', 'undo' ), true ) ) {
			return new WP_Error( 'mvweb_mdc_action', __( 'Unknown action.', 'mvweb-media-control' ) );
		}

		if ( ! MVweb_MDC_Cleaner::lock() ) {
			return new WP_Error( 'mvweb_mdc_locked', __( 'The task is already running in another tab or process.', 'mvweb-media-control' ) );
		}

		wp_clear_scheduled_hook( self::HOOK );

		$phases = 'delete' === $mode ? array( 'index', 'links', 'delete' ) : array( 'undo' );
		$job    = array_merge( $job, self::new_job( $mode, $phases ) );

		$job['status'] = 'working';

		update_option( self::JOB_OPTION, $job, false );
		MVweb_MDC_Cleaner::unlock();

		return $job;
	}

	/**
	 * WP-Cron handler: one slice of the cron job.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function cron(): void {
		$job = self::get_job();

		if ( 'running' !== ( $job['status'] ?? '' ) ) {
			wp_clear_scheduled_hook( self::HOOK );
			return;
		}

		$limit = (int) ini_get( 'max_execution_time' );
		$slice = $limit > 0 ? max( 5, min( self::SLICE, $limit - 10 ) ) : self::SLICE;

		self::step( microtime( true ) + $slice, true );
	}

	/**
	 * Attachments to convert in this run so that the job ends by its due time.
	 *
	 * @param array $job Job state in the convert phase.
	 * @return int
	 */
	private static function quota( array $job ): int {
		$left = max( 0, (int) $job['total'] - (int) $job['processed'] );
		$runs = max( 1, (int) floor( ( (int) $job['due'] - time() ) / self::INTERVAL ) );

		return max( 1, (int) ceil( $left / $runs ) );
	}

	/**
	 * Run the job until it finishes, the deadline passes or the run's share of
	 * conversions is done.
	 *
	 * @since 1.0.0
	 * @param float $deadline Unix time with microseconds; 0 runs to the end.
	 * @param bool  $paced    Convert only this run's share of the period (WP-Cron).
	 * @return array|WP_Error Job state.
	 */
	public static function step( float $deadline, bool $paced = false ) {
		$job = self::get_job();

		if ( ! in_array( $job['status'] ?? '', array( 'running', 'working' ), true ) ) {
			return $job;
		}

		if ( ! MVweb_MDC_Cleaner::lock() ) {
			return new WP_Error( 'mvweb_mdc_locked', __( 'The task is already running in another tab or process.', 'mvweb-media-control' ) );
		}

		$job['last_run'] = time();

		if ( ! empty( $job['current'] ) ) {
			$journal = get_post_meta( (int) $job['current'], self::JOURNAL, true );
			self::rollback_group( is_array( $journal ) && ! empty( $journal['members'] ) ? array_map( 'intval', $journal['members'] ) : array( (int) $job['current'] ), false, $job );
			self::fail( $job, (int) $job['current'], 'convert_failed' );
			$job['cursor']  = max( (int) $job['cursor'], (int) $job['current'] );
			$job['current'] = 0;
		}

		$done  = 0;
		$quota = 0;

		while ( true ) {
			if ( $job['entered'] !== $job['phase'] ) {
				self::enter_phase( $job );
			}

			$phase = $job['phases'][ $job['phase'] ];

			if ( $paced && 'convert' === $phase && ! $quota ) {
				$quota = self::quota( $job );
			}
			$over = self::run_unit( $phase, $job, $done );

			if ( '' !== $job['error'] ) {
				self::finish( $job );
				break;
			}

			if ( $over ) {
				self::leave_phase( $phase, $job );
				++$job['phase'];

				if ( ! isset( $job['phases'][ $job['phase'] ] ) ) {
					self::finish( $job );
					break;
				}
			}

			update_option( self::JOB_OPTION, $job, false );

			if ( ( $quota && $done >= $quota ) || MVweb_MDC_Cleaner::out_of_budget( $deadline ) ) {
				break;
			}

			MVweb_MDC_Cleaner::lock();
		}

		update_option( self::JOB_OPTION, $job, false );
		MVweb_MDC_Cleaner::unlock();

		return $job;
	}

	/**
	 * Close the current mode and set the next status.
	 *
	 * @param array $job Job state.
	 * @return void
	 */
	private static function finish( array &$job ): void {
		$job['finished'] = time();
		$job['status']   = self::journal_count() > 0 ? 'ready' : 'done';

		if ( 'cron' === $job['mode'] && '' !== $job['error'] ) {
			$job['status'] = 'paused';
		}

		wp_clear_scheduled_hook( self::HOOK );
	}

	/**
	 * Record a failed attachment with its reason.
	 *
	 * @param array  $job    Job state.
	 * @param int    $id     Attachment ID.
	 * @param string $reason Reason code.
	 * @return void
	 */
	private static function fail( array &$job, int $id, string $reason ): void {
		$job['failed'][ $id ]               = $reason;
		$job['stats']['skipped'][ $reason ] = ( $job['stats']['skipped'][ $reason ] ?? 0 ) + 1;
	}

	/**
	 * Prepare a phase.
	 *
	 * @param array $job Job state.
	 * @return void
	 */
	private static function enter_phase( array &$job ): void {
		$phase            = $job['phases'][ $job['phase'] ];
		$job['entered']   = $job['phase'];
		$job['cursor']    = 0;
		$job['source']    = 0;
		$job['processed'] = 0;

		switch ( $phase ) {
			case 'convert':
				$job['total'] = self::count_candidates( ! empty( $job['png'] ) );
				break;
			case 'index':
				$job['total'] = MVweb_MDC_Cleaner::index_begin();
				break;
			default:
				$job['total'] = self::journal_count();
		}
	}

	/**
	 * Finish a phase.
	 *
	 * @param string $phase Phase name.
	 * @param array  $job   Job state.
	 * @return void
	 */
	private static function leave_phase( string $phase, array &$job ): void {
		if ( 'index' === $phase ) {
			MVweb_MDC_Cleaner::index_end( $job );
		}

		if ( 'links' === $phase || 'undo' === $phase ) {
			MVweb_MDC_Cleaner::clear_builder_cache();
		}
	}

	/**
	 * Run one unit of work.
	 *
	 * @param string $phase Phase name.
	 * @param array  $job   Job state.
	 * @param int    $done  Conversions made in this run.
	 * @return bool True when the phase is complete.
	 */
	private static function run_unit( string $phase, array &$job, int &$done ): bool {
		if ( 'index' === $phase ) {
			return MVweb_MDC_Cleaner::index_step( $job );
		}

		$id = 'convert' === $phase ? self::next_candidate( (int) $job['cursor'], ! empty( $job['png'] ) ) : self::next_journal( (int) $job['cursor'] );

		if ( ! $id ) {
			return true;
		}

		$members = self::members( $id );
		++$job['processed'];

		if ( $members[0] === $id ) {
			switch ( $phase ) {
				case 'convert':
					self::convert_group( $members, $job );
					++$done;
					break;
				case 'links':
					self::links_group( $members, $job );
					break;
				case 'delete':
					self::delete_group( $members, $job );
					break;
				case 'undo':
					self::undo_group( $members, $job );
					break;
			}

			foreach ( $members as $member ) {
				wp_cache_delete( $member, 'post_meta' );
				wp_cache_delete( $member, 'posts' );
			}
		}

		$job['cursor'] = $id;

		return false;
	}

	/* ─── Selection ─────────────────────────────────────────────── */

	/**
	 * SQL condition for convertible attachments: JPEG/PNG type and file.
	 *
	 * Uploads converted at upload time keep the JPEG type while the file is
	 * WebP, so the file extension is checked too.
	 *
	 * @param bool $png Include PNG.
	 * @return string
	 */
	private static function candidate_sql( bool $png ): string {
		global $wpdb;

		$mimes = $png ? "'image/jpeg','image/png'" : "'image/jpeg'";
		$exts  = $png ? self::SOURCE_EXT : array( 'jpg', 'jpeg', 'jpe' );
		$likes = array();

		foreach ( $exts as $ext ) {
			$likes[] = $wpdb->prepare( 'f.meta_value LIKE %s', '%.' . $ext );
		}

		return "FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} f ON f.post_id = p.ID AND f.meta_key = '_wp_attached_file'
			WHERE p.post_type = 'attachment' AND p.post_mime_type IN ({$mimes}) AND (" . implode( ' OR ', $likes ) . ')';
	}

	/**
	 * Number of convertible attachments.
	 *
	 * @param bool $png Include PNG.
	 * @return int
	 */
	private static function count_candidates( bool $png ): int {
		global $wpdb;

		return (int) $wpdb->get_var( 'SELECT COUNT(*) ' . self::candidate_sql( $png ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared -- built from fixed parts and prepared LIKE patterns.
	}

	/**
	 * Next convertible attachment after the cursor.
	 *
	 * @param int  $cursor Last processed ID.
	 * @param bool $png    Include PNG.
	 * @return int 0 when none.
	 */
	private static function next_candidate( int $cursor, bool $png ): int {
		global $wpdb;

		return (int) $wpdb->get_var( 'SELECT p.ID ' . self::candidate_sql( $png ) . $wpdb->prepare( ' AND p.ID > %d ORDER BY p.ID ASC LIMIT 1', $cursor ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared -- built from fixed parts and prepared values.
	}

	/**
	 * Next attachment with a journal after the cursor.
	 *
	 * @param int $cursor Last processed ID.
	 * @return int 0 when none.
	 */
	private static function next_journal( int $cursor ): int {
		global $wpdb;

		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND post_id > %d ORDER BY post_id ASC LIMIT 1", self::JOURNAL, $cursor ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Attachments sharing the file with this one (translations), lowest ID first.
	 *
	 * @param int $id Attachment ID.
	 * @return int[]
	 */
	private static function members( int $id ): array {
		return MVweb_MDC_Cleaner::groups_for( array( $id ) )[ $id ] ?? array( $id );
	}

	/**
	 * Why an attachment is not converted.
	 *
	 * @param array $item Loaded attachment.
	 * @param array $job  Job state.
	 * @return string Reason code, empty when it can be converted.
	 */
	private static function skip_reason( array $item, array $job ): string {
		$reason = MVweb_MDC_Cleaner::skip_reason( $item );

		if ( '' !== $reason ) {
			return $reason;
		}

		$ext = strtolower( pathinfo( $item['file'], PATHINFO_EXTENSION ) );

		if ( ! in_array( $ext, self::SOURCE_EXT, true ) || ( 'png' === $ext && empty( $job['png'] ) ) ) {
			return 'not_source';
		}

		if ( metadata_exists( 'post', $item['id'], self::JOURNAL ) ) {
			return 'journal';
		}

		return '';
	}

	/* ─── Phase 1: convert ──────────────────────────────────────── */

	/**
	 * Convert one group: journal, new WebP files and metadata, check.
	 *
	 * @param int[] $members Group member IDs.
	 * @param array $job     Job state.
	 * @return void
	 */
	private static function convert_group( array $members, array &$job ): void {
		global $wpdb;

		$items = array_map( array( 'MVweb_MDC_Cleaner', 'load' ), $members );

		foreach ( $items as $item ) {
			$reason = self::skip_reason( $item, $job );
			if ( '' !== $reason ) {
				$job['stats']['skipped'][ $reason ] = ( $job['stats']['skipped'][ $reason ] ?? 0 ) + count( $items );
				return;
			}
		}

		$id       = $members[0];
		$dir      = dirname( $items[0]['file'] );
		$original = (string) wp_get_original_image_path( $id, true );
		$stem     = pathinfo( $original, PATHINFO_FILENAME );
		$old      = self::old_files( $items, $dir );

		if ( array_diff( self::created_files( $dir, $stem ), $old ) ) {
			$job['stats']['skipped']['name_taken'] = ( $job['stats']['skipped']['name_taken'] ?? 0 ) + count( $items );
			return;
		}

		$job['current'] = $id;
		update_option( self::JOB_OPTION, $job, false );

		foreach ( $items as $item ) {
			$journal = array(
				'state'   => 'converting',
				'members' => $members,
				'meta'    => $item['meta'],
				'file'    => (string) get_post_meta( $item['id'], '_wp_attached_file', true ),
				'mime'    => (string) get_post_mime_type( $item['id'] ),
				'dir'     => $dir,
				'stem'    => $stem,
				'old'     => $old,
				'at'      => time(),
			);

			update_post_meta( $item['id'], self::JOURNAL, wp_slash( $journal ) );
			wp_cache_delete( $item['id'], 'post_meta' );

			if ( get_post_meta( $item['id'], self::JOURNAL, true ) !== $journal ) {
				foreach ( $members as $member ) {
					delete_post_meta( $member, self::JOURNAL );
				}
				self::fail( $job, $id, 'journal_write' );
				$job['current'] = 0;
				return;
			}
		}

		require_once ABSPATH . 'wp-admin/includes/image.php';
		wp_raise_memory_limit( 'image' );

		$png    = ! empty( $job['png'] );
		$format = static function ( $formats ) use ( $png ) {
			$formats               = is_array( $formats ) ? $formats : array();
			$formats['image/jpeg'] = 'image/webp';
			if ( $png ) {
				$formats['image/png'] = 'image/webp';
			}
			return $formats;
		};

		add_filter( 'image_editor_output_format', $format, PHP_INT_MAX );
		wp_create_image_subsizes( $original, $id );
		remove_filter( 'image_editor_output_format', $format, PHP_INT_MAX );

		$reason = self::check( $id, $items[0]['meta'], $dir );

		if ( '' !== $reason ) {
			self::rollback_group( $members, false, $job );
			self::fail( $job, $id, $reason );
			$job['current'] = 0;
			return;
		}

		$new  = wp_get_attachment_metadata( $id, true );
		$main = (string) get_attached_file( $id, true );
		$map  = self::name_map( $items[0]['meta'], $new, $old );

		foreach ( $members as $member ) {
			if ( $member !== $id ) {
				update_attached_file( $member, $main );
				wp_update_attachment_metadata( $member, $new );
			}

			$wpdb->update( $wpdb->posts, array( 'post_mime_type' => 'image/webp' ), array( 'ID' => $member ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- wp_update_post() would run save_post of every plugin in cron.
			clean_post_cache( $member );

			wp_cache_delete( $member, 'post_meta' );
			$journal             = get_post_meta( $member, self::JOURNAL, true );
			$journal['state']    = 'converted';
			$journal['new_meta'] = $new;
			$journal['map']      = $map;
			update_post_meta( $member, self::JOURNAL, wp_slash( $journal ) );
		}

		$job['stats']['converted'] = ( $job['stats']['converted'] ?? 0 ) + count( $members );
		$job['stats']['bytes_old'] = ( $job['stats']['bytes_old'] ?? 0 ) + self::bytes( $dir, self::meta_files( $items[0]['meta'] ) );
		$job['stats']['bytes_new'] = ( $job['stats']['bytes_new'] ?? 0 ) + self::bytes( $dir, self::meta_files( $new ) );
		$job['current']            = 0;
	}

	/**
	 * Check the conversion result.
	 *
	 * @param int    $id       Attachment ID.
	 * @param mixed  $old_meta Metadata before conversion.
	 * @param string $dir      Directory.
	 * @return string Reason code, empty when the result is complete and smaller.
	 */
	private static function check( int $id, $old_meta, string $dir ): string {
		wp_cache_delete( $id, 'post_meta' );

		$meta = wp_get_attachment_metadata( $id, true );
		$main = (string) get_attached_file( $id, true );

		if ( ! is_array( $meta ) || '' === $main || ! is_file( $main ) || ! filesize( $main ) || 'image/webp' !== wp_get_image_mime( $main ) ) {
			return 'convert_failed';
		}

		if ( array() !== wp_get_missing_image_subsizes( $id ) ) {
			return 'convert_failed';
		}

		foreach ( self::meta_files( $meta ) as $file ) {
			if ( ! is_file( $dir . '/' . $file ) ) {
				return 'convert_failed';
			}
		}

		if ( self::bytes( $dir, self::meta_files( $meta ) ) >= self::bytes( $dir, self::meta_files( is_array( $old_meta ) ? $old_meta : array() ) ) ) {
			return 'no_gain';
		}

		return '';
	}

	/**
	 * Main file and size files named in metadata, without the original.
	 *
	 * @param array $meta Metadata.
	 * @return string[] Base names.
	 */
	private static function meta_files( array $meta ): array {
		$files = array();

		if ( ! empty( $meta['file'] ) ) {
			$files[] = wp_basename( (string) $meta['file'] );
		}

		foreach ( (array) ( $meta['sizes'] ?? array() ) as $entry ) {
			if ( is_array( $entry ) && ! empty( $entry['file'] ) ) {
				$files[] = wp_basename( (string) $entry['file'] );
			}
		}

		return array_values( array_unique( $files ) );
	}

	/**
	 * Total size of existing files.
	 *
	 * @param string   $dir   Directory.
	 * @param string[] $files Base names.
	 * @return int
	 */
	private static function bytes( string $dir, array $files ): int {
		$total = 0;

		foreach ( $files as $file ) {
			if ( is_file( $dir . '/' . $file ) ) {
				$total += (int) filesize( $dir . '/' . $file );
			}
		}

		return $total;
	}

	/**
	 * Every existing file of the group before conversion.
	 *
	 * Main files, originals, sizes, format sources and optimizer copies named
	 * with a double extension.
	 *
	 * @param array[] $items Loaded group members.
	 * @param string  $dir   Directory.
	 * @return string[] Base names.
	 */
	private static function old_files( array $items, string $dir ): array {
		$files = array();

		foreach ( $items as $item ) {
			$meta    = is_array( $item['meta'] ) ? $item['meta'] : array();
			$files[] = wp_basename( $item['file'] );

			foreach ( array( 'original_image', 'source_image' ) as $key ) {
				if ( ! empty( $meta[ $key ] ) && is_string( $meta[ $key ] ) ) {
					$files[] = wp_basename( $meta[ $key ] );
				}
			}

			$files = array_merge( $files, MVweb_MDC_Cleaner::collect_files( $meta['sizes'] ?? array() ), MVweb_MDC_Cleaner::collect_files( $meta['sources'] ?? array() ) );
		}

		foreach ( $files as $file ) {
			$files[] = $file . '.webp';
			$files[] = $file . '.avif';
		}

		return array_values(
			array_filter(
				array_unique( $files ),
				static function ( string $file ) use ( $dir ): bool {
					return is_file( $dir . '/' . $file );
				}
			)
		);
	}

	/**
	 * WebP files the core writes for this stem, found on disk.
	 *
	 * The image editor writes without checking whether the name is taken, so
	 * any match before conversion belongs to someone else.
	 *
	 * @param string $dir  Directory.
	 * @param string $stem Base name of the source without extension.
	 * @return string[] Base names.
	 */
	private static function created_files( string $dir, string $stem ): array {
		$escape = static function ( string $value ): string {
			return (string) preg_replace( '/[\\\\*?\[\]]/', '\\\\$0', $value );
		};

		$found   = glob( $escape( $dir ) . '/' . $escape( $stem ) . '*.webp' );
		$pattern = '/^' . preg_quote( $stem, '/' ) . '(?:-scaled)?(?:-\d+x\d+)?\.webp$/';
		$files   = array();

		foreach ( is_array( $found ) ? $found : array() as $path ) {
			$name = wp_basename( $path );
			if ( preg_match( $pattern, $name ) ) {
				$files[] = $name;
			}
		}

		return $files;
	}

	/**
	 * Old file name => new file name, for URL replacement.
	 *
	 * Sizes map by name; a size the new metadata lacks is not mapped: its crop
	 * is unknown and another size would distort the image. Main file and
	 * original map to the new main file.
	 *
	 * @param mixed    $old_meta Metadata before conversion.
	 * @param array    $new_meta Metadata after conversion.
	 * @param string[] $old      Old files.
	 * @return array<string, string>
	 */
	private static function name_map( $old_meta, array $new_meta, array $old ): array {
		$old_meta = is_array( $old_meta ) ? $old_meta : array();
		$main     = wp_basename( (string) ( $new_meta['file'] ?? '' ) );
		$map      = array();

		foreach ( array( $old_meta['file'] ?? '', $old_meta['original_image'] ?? '' ) as $file ) {
			if ( '' !== $file ) {
				$map[ wp_basename( (string) $file ) ] = $main;
			}
		}

		foreach ( (array) ( $old_meta['sizes'] ?? array() ) as $name => $entry ) {
			$target = $new_meta['sizes'][ $name ]['file'] ?? '';

			if ( ! is_array( $entry ) || '' === $target ) {
				continue;
			}

			foreach ( MVweb_MDC_Cleaner::collect_files( $entry ) as $file ) {
				$map[ $file ] = wp_basename( (string) $target );
			}
		}

		return array_intersect_key( $map, array_flip( $old ) );
	}

	/**
	 * Return a group to its state before conversion.
	 *
	 * @param int[] $members     Group member IDs.
	 * @param bool  $check_links Keep new files the database still links to (undo), false right after a failed conversion.
	 * @param array $job         Job state.
	 * @return void
	 */
	private static function rollback_group( array $members, bool $check_links, array &$job ): void {
		global $wpdb;

		$dir  = '';
		$stem = '';
		$old  = array();

		foreach ( $members as $member ) {
			wp_cache_delete( $member, 'post_meta' );
			$journal = get_post_meta( $member, self::JOURNAL, true );

			if ( ! is_array( $journal ) ) {
				continue;
			}

			update_post_meta( $member, '_wp_attached_file', wp_slash( $journal['file'] ) );
			update_post_meta( $member, '_wp_attachment_metadata', wp_slash( $journal['meta'] ) );
			$wpdb->update( $wpdb->posts, array( 'post_mime_type' => $journal['mime'] ), array( 'ID' => $member ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- see convert_group().
			clean_post_cache( $member );

			$dir  = (string) $journal['dir'];
			$stem = (string) $journal['stem'];
			$old  = (array) $journal['old'];
		}

		if ( '' !== $dir ) {
			$created = array_values( array_diff( self::created_files( $dir, $stem ), $old ) );
			$kept    = $check_links ? self::referenced( $created ) : array();

			foreach ( array_diff( $created, $kept ) as $file ) {
				wp_delete_file_from_directory( $dir . '/' . $file, $dir );
			}

			self::add_kept( $members, $kept, $job );
		}

		foreach ( $members as $member ) {
			delete_post_meta( $member, self::JOURNAL );
			delete_post_meta( $member, self::LINKS );
			wp_cache_delete( $member, 'post_meta' );
		}
	}

	/**
	 * Remember files left on disk because content links to them.
	 *
	 * @param int[]    $members Group member IDs.
	 * @param string[] $files   Base names.
	 * @param array    $job     Job state.
	 * @return void
	 */
	private static function add_kept( array $members, array $files, array &$job ): void {
		if ( ! $files ) {
			return;
		}

		foreach ( $members as $member ) {
			$kept = get_post_meta( $member, self::KEPT, true );
			$kept = array_values( array_unique( array_merge( is_array( $kept ) ? $kept : array(), $files ) ) );
			update_post_meta( $member, self::KEPT, wp_slash( $kept ) );
		}

		$job['stats']['kept'] = ( $job['stats']['kept'] ?? 0 ) + count( $files );

		foreach ( $files as $file ) {
			if ( count( $job['stats']['kept_files'] ?? array() ) < MVweb_MDC_Cleaner::LINKED_MAX ) {
				$job['stats']['kept_files'][ $file ] = true;
			}
		}
	}

	/**
	 * Names the database mentions now, found by a direct search.
	 *
	 * Used where the link index would be stale: after links were put back
	 * (undo) and when an attachment is deleted.
	 *
	 * @param string[] $names Base names.
	 * @return string[]
	 */
	private static function referenced( array $names ): array {
		global $wpdb;

		$found = array();

		foreach ( MVweb_MDC_Cleaner::index_sources() as $src ) {
			$left = array_diff( $names, $found );

			if ( ! $left ) {
				break;
			}

			$cols  = $wpdb->prefix . 'yoast_indexable' === $src['table'] ? array_diff( $src['cols'], array( 'open_graph_image_meta' ) ) : $src['cols'];
			$likes = array();
			foreach ( $cols as $col ) {
				foreach ( $left as $name ) {
					foreach ( array_unique( array( $name, rawurlencode( $name ) ) ) as $needle ) {
						$likes[] = $wpdb->prepare( "{$col} LIKE CAST(%s AS BINARY)", '%' . $wpdb->esc_like( $needle ) . '%' ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- fixed column names; a byte match is 8 times faster than the collation one and is what str_contains() checks next.
					}
				}
			}

			$where = '' !== $src['where'] ? ' AND ' . $src['where'] : '';
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- conditions are prepared above, tables and filters are fixed.
			$rows = $wpdb->get_results( 'SELECT ' . implode( ', ', $cols ) . " FROM {$src['table']} WHERE (" . implode( ' OR ', $likes ) . "){$where} LIMIT " . self::LIKE_LIMIT, ARRAY_A );

			foreach ( $rows as $row ) {
				$value = implode( "\n", $row );
				foreach ( $left as $name ) {
					if ( str_contains( $value, $name ) || str_contains( $value, rawurlencode( $name ) ) ) {
						$found[] = $name;
					}
				}
			}
		}

		return array_values( array_unique( $found ) );
	}

	/* ─── Phase 2: links ────────────────────────────────────────── */

	/**
	 * Old files of a group that may go in the final step.
	 *
	 * The original stays unless deleting originals was chosen.
	 *
	 * @param int[] $members Group member IDs.
	 * @param array $journal Leader journal.
	 * @param array $job     Job state.
	 * @return string[]
	 */
	private static function candidates( array $members, array $journal, array $job ): array {
		$items   = array_map( array( 'MVweb_MDC_Cleaner', 'load' ), $members );
		$protect = MVweb_MDC_Cleaner::base_protected( $items );
		$old     = (array) $journal['old'];

		foreach ( $items as $item ) {
			foreach ( MVweb_MDC_Cleaner::collect_files( $item['meta']['sizes'] ?? array() ) as $file ) {
				$protect[ $file ] = true;
			}
		}

		$originals = array();
		foreach ( array( $journal['new_meta']['original_image'] ?? '', $journal['meta']['original_image'] ?? '', $journal['meta']['source_image'] ?? '' ) as $file ) {
			if ( '' !== $file ) {
				$originals[] = wp_basename( (string) $file );
			}
		}

		if ( ! empty( $job['delete_originals'] ) ) {
			foreach ( $originals as $file ) {
				unset( $protect[ $file ] );
			}
		} else {
			$protect += array_fill_keys( $originals, true );
		}

		return array_values( array_diff( $old, array_keys( $protect ) ) );
	}

	/**
	 * Replace links to the old files of one group and record a verdict per file.
	 *
	 * Verdicts: free (no link), wait (links replaced now, cached pages may still
	 * use the old file), stuck (a link that cannot be replaced).
	 *
	 * @param int[] $members Group member IDs.
	 * @param array $job     Job state.
	 * @return void
	 */
	private static function links_group( array $members, array &$job ): void {
		$id      = $members[0];
		$journal = get_post_meta( $id, self::JOURNAL, true );

		if ( ! is_array( $journal ) || 'converted' !== ( $journal['state'] ?? '' ) ) {
			return;
		}

		$files   = self::candidates( $members, $journal, $job );
		$linked  = array_values( array_filter( $files, array( 'MVweb_MDC_Cleaner', 'is_linked' ) ) );
		$verdict = array_fill_keys( $files, 'free' );

		if ( $linked ) {
			$verdict = array_merge( $verdict, self::rewrite( $id, $linked, (array) ( $journal['map'] ?? array() ), self::rel_dir( $journal ), $job ) );
		}

		$journal['verdict'] = $verdict;
		$journal['run']     = $job['run'];
		update_post_meta( $id, self::JOURNAL, wp_slash( $journal ) );
	}

	/**
	 * Directory of the group relative to uploads, without slashes at the ends.
	 *
	 * @param array $journal Journal.
	 * @return string
	 */
	private static function rel_dir( array $journal ): string {
		$dir = dirname( (string) $journal['file'] );
		return '.' === $dir ? '' : trim( $dir, '/' );
	}

	/**
	 * Find rows that mention the files and replace the old URLs in them.
	 *
	 * Yoast SEO image metadata also holds the file path, type and size. It is
	 * not treated as a link: the row is marked outdated and Yoast rebuilds it
	 * from the attachment on the next read.
	 *
	 * @param int                   $id     Leader attachment ID; the link journal is kept there.
	 * @param string[]              $files  Old base names found in the link index.
	 * @param array<string, string> $map    Old => new base names.
	 * @param string                $rel    Directory relative to uploads.
	 * @param array                 $job    Job state.
	 * @return array<string, string> File => verdict.
	 */
	private static function rewrite( int $id, array $files, array $map, string $rel, array &$job ): array {
		global $wpdb;

		$verdict = array_fill_keys( $files, '' );
		$pairs   = array_intersect_key( $map, $verdict );
		$log     = get_post_meta( $id, self::LINKS, true );
		$log     = is_array( $log ) ? $log : array();
		$owners  = self::owner_columns();
		$seen    = array();

		foreach ( MVweb_MDC_Cleaner::index_sources() as $src ) {
			$likes = array();
			foreach ( $src['cols'] as $col ) {
				foreach ( $files as $file ) {
					foreach ( array_unique( array( $file, rawurlencode( $file ) ) ) as $needle ) {
						$likes[] = $wpdb->prepare( "{$col} LIKE CAST(%s AS BINARY)", '%' . $wpdb->esc_like( $needle ) . '%' ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- fixed column names; a byte match is 8 times faster than the collation one and is what str_contains() checks next.
					}
				}
			}

			$owner = $owners[ $src['table'] ] ?? '';
			$cols  = implode( ', ', array_merge( array( $src['id'] ), '' !== $owner ? array( $owner ) : array(), $src['cols'] ) );
			$where = '' !== $src['where'] ? ' AND ' . $src['where'] : '';

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- conditions are prepared above, tables and filters are fixed.
			$rows  = $wpdb->get_results( "SELECT {$cols} FROM {$src['table']} WHERE (" . implode( ' OR ', $likes ) . "){$where} LIMIT " . self::LIKE_LIMIT, ARRAY_A );
			$yoast = $wpdb->prefix . 'yoast_indexable' === $src['table'];

			foreach ( $rows as $row ) {
				if ( $yoast ) {
					$wpdb->update( $src['table'], array( 'version' => 0 ), array( 'id' => (int) $row['id'] ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Yoast rebuilds rows with an old version on the next read.
				}

				foreach ( $src['cols'] as $col ) {
					$value   = (string) $row[ $col ];
					$present = array_filter(
						$files,
						static function ( string $file ) use ( $value ): bool {
							return str_contains( $value, $file ) || str_contains( $value, rawurlencode( $file ) );
						}
					);

					if ( ! $present ) {
						continue;
					}

					$seen += array_fill_keys( $present, true );

					$result = self::transform( $value, array_intersect_key( $pairs, array_flip( $present ) ), $rel );

					foreach ( $yoast && 'open_graph_image_meta' === $col ? array() : $present as $file ) {
						if ( in_array( $file, $result['stuck'], true ) || ( ! isset( $pairs[ $file ] ) && self::mentions( $value, $file, $rel ) ) ) {
							$verdict[ $file ] = 'stuck';
						}
					}

					if ( null === $result['value'] ) {
						continue;
					}

					$written = self::write( $src['table'], $src['id'], (int) $row[ $src['id'] ], $col, $value, $result['value'] );

					foreach ( $result['hits'] as $file ) {
						if ( 'stuck' !== $verdict[ $file ] ) {
							$verdict[ $file ] = 'wait';
						}
					}

					if ( ! $written ) {
						continue;
					}

					self::clear_row_cache( $src['table'], $row );
					$log[]                = array(
						't' => $src['table'],
						'k' => $src['id'],
						'i' => (int) $row[ $src['id'] ],
						'c' => $col,
						'o' => '' !== $owner ? array_intersect_key( $row, array_flip( array_map( 'trim', explode( ',', $owner ) ) ) ) : array(),
						'p' => array_intersect_key( $pairs, array_flip( $result['hits'] ) ),
						'd' => $rel,
					);
					$job['stats']['rows'] = ( $job['stats']['rows'] ?? 0 ) + 1;
				}
			}
		}

		if ( $log ) {
			update_post_meta( $id, self::LINKS, wp_slash( $log ) );
		}

		// In the index but not found by a direct search: the link is stored encoded (\uXXXX).
		foreach ( $verdict as $file => $value ) {
			if ( '' === $value ) {
				$verdict[ $file ] = isset( $seen[ $file ] ) ? 'free' : 'stuck';
			}
		}

		return $verdict;
	}

	/**
	 * Columns needed to clear the object cache of a changed row.
	 *
	 * @return array<string, string>
	 */
	private static function owner_columns(): array {
		global $wpdb;

		return array(
			$wpdb->postmeta      => 'post_id',
			$wpdb->termmeta      => 'term_id',
			$wpdb->usermeta      => 'user_id',
			$wpdb->options       => 'option_name',
			$wpdb->term_taxonomy => 'term_id, taxonomy',
		);
	}

	/**
	 * Write a value only if the row still holds the value that was read.
	 *
	 * Core wrappers are not used: update_option() runs other plugins' sanitize
	 * callbacks, update_metadata() strips slashes, wp_update_post() adds a revision.
	 *
	 * @param string $table Table.
	 * @param string $key   Primary key column.
	 * @param int    $id    Row ID.
	 * @param string $col   Column.
	 * @param string $old   Value read.
	 * @param string $value New value.
	 * @return bool
	 */
	private static function write( string $table, string $key, int $id, string $col, string $old, string $value ): bool {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table and columns come from the fixed index sources.
		return 1 === $wpdb->query( $wpdb->prepare( "UPDATE {$table} SET {$col} = %s WHERE {$key} = %d AND {$col} = %s", $value, $id, $old ) );
	}

	/**
	 * Clear the object cache of a changed row.
	 *
	 * @param string $table Table.
	 * @param array  $row   Row with the key and owner columns.
	 * @return void
	 */
	private static function clear_row_cache( string $table, array $row ): void {
		global $wpdb;

		switch ( $table ) {
			case $wpdb->posts:
				clean_post_cache( (int) $row['ID'] );
				break;
			case $wpdb->postmeta:
				wp_cache_delete( (int) $row['post_id'], 'post_meta' );
				break;
			case $wpdb->termmeta:
				wp_cache_delete( (int) $row['term_id'], 'term_meta' );
				break;
			case $wpdb->usermeta:
				wp_cache_delete( (int) $row['user_id'], 'user_meta' );
				break;
			case $wpdb->options:
				wp_cache_delete( (string) $row['option_name'], 'options' );
				wp_cache_delete( 'alloptions', 'options' );
				wp_cache_delete( 'notoptions', 'options' );
				break;
			case $wpdb->term_taxonomy:
				clean_term_cache( (int) $row['term_id'], (string) $row['taxonomy'] );
				break;
			case $wpdb->comments:
				clean_comment_cache( (int) $row['comment_ID'] );
				break;
		}
	}

	/**
	 * Replace file URLs in a raw database value.
	 *
	 * Serialized values are unserialized without classes, walked (nested
	 * serialized strings too) and serialized again, so string lengths stay
	 * right. Values with objects, broken serialization or JSON that stops
	 * decoding are left as they are.
	 *
	 * @param string                $value   Raw value.
	 * @param array<string, string> $pairs   From => to base names.
	 * @param string                $rel     Directory relative to uploads.
	 * @return array{value: ?string, hits: string[], stuck: string[]}
	 */
	private static function transform( string $value, array $pairs, string $rel ): array {
		$hits   = array();
		$broken = false;

		$walk = static function ( $data ) use ( &$walk, &$hits, &$broken, $pairs, $rel ) {
			if ( is_array( $data ) ) {
				foreach ( $data as $key => $item ) {
					$data[ $key ] = $walk( $item );
				}
				return $data;
			}

			if ( is_object( $data ) ) {
				$broken = true;
				return $data;
			}

			if ( ! is_string( $data ) ) {
				return $data;
			}

			if ( is_serialized( $data ) ) {
				$inner = @unserialize( trim( $data ), array( 'allowed_classes' => false ) ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.DiscouragedPHPFunctions.serialize_unserialize -- classes are disabled; a broken value is detected below.
				if ( false === $inner && 'b:0;' !== trim( $data ) ) {
					$broken = true;
					return $data;
				}
				return serialize( $walk( $inner ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize -- the value was serialized.
			}

			return self::replace_urls( $data, $pairs, $rel, $hits );
		};

		$new = $walk( $value );

		if ( ! $broken && is_serialized( $value ) && false === @unserialize( $new, array( 'allowed_classes' => false ) ) && 'b:0;' !== $new ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.DiscouragedPHPFunctions.serialize_unserialize -- round-trip check.
			$broken = true;
		}

		$trimmed = ltrim( $value );
		if ( ! $broken && '' !== $trimmed && in_array( $trimmed[0], array( '{', '[' ), true ) && null !== json_decode( $value ) && null === json_decode( (string) $new ) ) {
			$broken = true;
		}

		$stuck = array();
		$check = $broken ? $value : (string) $new;

		foreach ( array_keys( $pairs ) as $file ) {
			if ( self::mentions( $check, $file, $rel ) ) {
				$stuck[] = $file;
			}
		}

		return array(
			'value' => $broken || $new === $value ? null : (string) $new,
			'hits'  => $broken ? array() : array_values( array_unique( $hits ) ),
			'stuck' => $stuck,
		);
	}

	/**
	 * Whether a value still mentions the file under its uploads directory.
	 *
	 * Catches links the URL pattern did not replace: another host, a path
	 * without the site root.
	 *
	 * @param string $value Value.
	 * @param string $file  Base name.
	 * @param string $rel   Directory relative to uploads.
	 * @return bool
	 */
	private static function mentions( string $value, string $file, string $rel ): bool {
		$base  = wp_basename( (string) wp_parse_url( wp_get_upload_dir()['baseurl'], PHP_URL_PATH ) );
		$token = $base . '/' . ( '' !== $rel ? $rel . '/' : '' );

		foreach ( array( $token . $file, $token . rawurlencode( $file ) ) as $needle ) {
			foreach ( array( $needle, str_replace( '/', '\\/', $needle ) ) as $form ) {
				if ( preg_match( '#' . preg_quote( $form, '#' ) . '(?![A-Za-z0-9_.%-])#', $value ) ) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * Replace URLs of the given files in a plain string.
	 *
	 * Matches the uploads path of this site, optionally with its scheme and
	 * host, plain or with JSON-escaped slashes, the name as is or URL-encoded.
	 * On the left the URL must start the value or follow a quote, bracket,
	 * space, equals sign, comma or semicolon; on the right no name character
	 * may follow, so photo.jpg.webp is not touched.
	 *
	 * @param string                $value Text.
	 * @param array<string, string> $pairs From => to base names.
	 * @param string                $rel   Directory relative to uploads.
	 * @param string[]              $hits  Replaced source names, appended.
	 * @return string
	 */
	private static function replace_urls( string $value, array $pairs, string $rel, array &$hits ): string {
		$prefix = self::prefix_pattern( $rel );

		foreach ( $pairs as $from => $to ) {
			$from = (string) $from;

			if ( ! str_contains( $value, $from ) && ! str_contains( $value, rawurlencode( $from ) ) ) {
				continue;
			}

			$names   = array_unique( array( preg_quote( $from, '#' ), preg_quote( rawurlencode( $from ), '#' ) ) );
			$pattern = '#(^|[\s"\'(=,;\[>])(' . $prefix . ')(' . implode( '|', $names ) . ')(?![A-Za-z0-9_.%-])#';
			$count   = 0;
			$value   = (string) preg_replace_callback(
				$pattern,
				static function ( array $m ) use ( $from, $to ): string {
					return $m[1] . $m[2] . ( $m[3] === $from ? $to : rawurlencode( $to ) );
				},
				$value,
				-1,
				$count
			);

			if ( $count > 0 ) {
				$hits[] = $from;
			}
		}

		return $value;
	}

	/**
	 * Regex for the part of an uploads URL before the file name.
	 *
	 * @param string $rel Directory relative to uploads.
	 * @return string
	 */
	private static function prefix_pattern( string $rel ): string {
		static $cache = array();

		if ( isset( $cache[ $rel ] ) ) {
			return $cache[ $rel ];
		}

		$sep     = '(?:\\\\/|/)';
		$baseurl = (string) wp_get_upload_dir()['baseurl'];
		$path    = trim( (string) wp_parse_url( $baseurl, PHP_URL_PATH ), '/' ) . ( '' !== $rel ? '/' . $rel : '' );
		$hosts   = array();

		foreach ( array( home_url(), site_url(), $baseurl ) as $url ) {
			$host = (string) wp_parse_url( $url, PHP_URL_HOST );
			if ( '' !== $host ) {
				$hosts[] = preg_quote( strtolower( $host ), '#' );
			}
		}

		$host = $hosts ? '(?:(?:https?:)?' . $sep . $sep . '(?i:' . implode( '|', array_unique( $hosts ) ) . ')(?::\d+)?)?' : '';
		$path = implode( $sep, array_map( static fn( string $part ): string => preg_quote( $part, '#' ), array_filter( explode( '/', $path ), 'strlen' ) ) );

		$cache[ $rel ] = $host . $sep . ( '' !== $path ? $path . $sep : '' );

		return $cache[ $rel ];
	}

	/* ─── Final step: delete old files ──────────────────────────── */

	/**
	 * Delete old files of one group that nothing links to.
	 *
	 * A group with links replaced in this run waits for the next run: pages
	 * with those links were cached before and still use the old files.
	 *
	 * @param int[] $members Group member IDs.
	 * @param array $job     Job state.
	 * @return void
	 */
	private static function delete_group( array $members, array &$job ): void {
		$id      = $members[0];
		$journal = get_post_meta( $id, self::JOURNAL, true );

		if ( ! is_array( $journal ) || 'converted' !== ( $journal['state'] ?? '' ) || ( $journal['run'] ?? 0 ) !== $job['run'] ) {
			return;
		}

		$verdict = (array) ( $journal['verdict'] ?? array() );

		if ( in_array( 'wait', $verdict, true ) ) {
			$job['stats']['wait'] = ( $job['stats']['wait'] ?? 0 ) + 1;
			return;
		}

		$dir     = (string) $journal['dir'];
		$kept    = array();
		$deleted = array();

		foreach ( $verdict as $file => $value ) {
			$file = wp_basename( (string) $file );
			$path = $dir . '/' . $file;

			if ( 'free' !== $value ) {
				$kept[] = $file;
				continue;
			}

			if ( ! is_file( $path ) ) {
				continue;
			}

			$bytes = (int) filesize( $path );

			wp_delete_file_from_directory( $path, $dir );
			clearstatcache( true, $path );

			if ( file_exists( $path ) ) {
				$job['stats']['not_deleted'] = ( $job['stats']['not_deleted'] ?? 0 ) + 1;
				$kept[]                      = $file;
				continue;
			}

			$deleted[]               = $file;
			$job['stats']['deleted'] = ( $job['stats']['deleted'] ?? 0 ) + 1;
			$job['stats']['freed']   = ( $job['stats']['freed'] ?? 0 ) + $bytes;

			if ( is_multisite() ) {
				clean_dirsize_cache( $path );
			}
		}

		foreach ( $members as $member ) {
			$meta = wp_get_attachment_metadata( $member, true );

			if ( is_array( $meta ) ) {
				$changed = false;
				foreach ( array( 'original_image', 'source_image' ) as $key ) {
					if ( ! empty( $meta[ $key ] ) && in_array( wp_basename( (string) $meta[ $key ] ), $deleted, true ) ) {
						unset( $meta[ $key ] );
						$changed = true;
					}
				}
				if ( $changed ) {
					wp_update_attachment_metadata( $member, $meta );
				}
			}

			delete_post_meta( $member, self::JOURNAL );
			delete_post_meta( $member, self::LINKS );
		}

		self::add_kept( $members, $kept, $job );
	}

	/* ─── Undo ──────────────────────────────────────────────────── */

	/**
	 * Undo the conversion of one group: links back, old metadata, new files removed.
	 *
	 * @param int[] $members Group member IDs.
	 * @param array $job     Job state.
	 * @return void
	 */
	private static function undo_group( array $members, array &$job ): void {
		$id      = $members[0];
		$journal = get_post_meta( $id, self::JOURNAL, true );

		if ( ! is_array( $journal ) ) {
			return;
		}

		if ( 'converted' === ( $journal['state'] ?? '' ) && wp_get_attachment_metadata( $id, true ) !== ( $journal['new_meta'] ?? null ) ) {
			$job['stats']['changed'] = ( $job['stats']['changed'] ?? 0 ) + 1;
			$job['failed'][ $id ]    = 'changed';
			return;
		}

		$log = get_post_meta( $id, self::LINKS, true );

		foreach ( is_array( $log ) ? array_reverse( $log ) : array() as $entry ) {
			self::unrewrite( $entry, $job );
		}

		self::rollback_group( $members, true, $job );
		$job['stats']['undone'] = ( $job['stats']['undone'] ?? 0 ) + count( $members );
	}

	/**
	 * Put the old URLs back into one row.
	 *
	 * @param array $entry Link journal entry.
	 * @param array $job   Job state.
	 * @return void
	 */
	private static function unrewrite( array $entry, array &$job ): void {
		global $wpdb;

		$table = (string) ( $entry['t'] ?? '' );
		$key   = (string) ( $entry['k'] ?? '' );
		$col   = (string) ( $entry['c'] ?? '' );
		$known = array();

		foreach ( MVweb_MDC_Cleaner::index_sources() as $src ) {
			if ( $src['table'] === $table && $src['id'] === $key && in_array( $col, $src['cols'], true ) ) {
				$known = $src;
			}
		}

		if ( ! $known ) {
			return;
		}

		$value = $wpdb->get_var( $wpdb->prepare( "SELECT {$col} FROM {$table} WHERE {$key} = %d", (int) $entry['i'] ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table and column checked against the index sources.

		if ( null === $value ) {
			return;
		}

		if ( $wpdb->prefix . 'yoast_indexable' === $table ) {
			$wpdb->update( $table, array( 'version' => 0 ), array( $key => (int) $entry['i'] ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- Yoast rebuilds rows with an old version on the next read.
		}

		$result = self::transform( (string) $value, array_flip( (array) $entry['p'] ), (string) $entry['d'] );

		if ( null !== $result['value'] && self::write( $table, $key, (int) $entry['i'], $col, (string) $value, $result['value'] ) ) {
			self::clear_row_cache( $table, array( $key => (int) $entry['i'] ) + (array) $entry['o'] );
			$job['stats']['rows'] = ( $job['stats']['rows'] ?? 0 ) + 1;
		}
	}

	/* ─── Attachment deletion ───────────────────────────────────── */

	/**
	 * Delete old and kept files when the attachment itself is deleted.
	 *
	 * The core knows only the files of the new metadata. Files shared with a
	 * translation that stays, or linked from content, are left.
	 *
	 * @since 1.0.0
	 * @param int $id Attachment ID.
	 * @return void
	 */
	public static function on_delete_attachment( $id ): void {
		$id      = (int) $id;
		$journal = get_post_meta( $id, self::JOURNAL, true );
		$kept    = get_post_meta( $id, self::KEPT, true );

		if ( ! is_array( $journal ) && ! is_array( $kept ) ) {
			return;
		}

		if ( array_diff( self::members( $id ), array( $id ) ) ) {
			return;
		}

		$file = (string) get_attached_file( $id, true );
		$dir  = is_array( $journal ) ? (string) $journal['dir'] : dirname( $file );

		if ( '' === $file && ! is_array( $journal ) ) {
			return;
		}

		$files = array_values( array_unique( array_map( 'wp_basename', array_merge( is_array( $journal ) ? (array) $journal['old'] : array(), is_array( $kept ) ? $kept : array() ) ) ) );

		foreach ( array_diff( $files, self::referenced( $files ) ) as $name ) {
			wp_delete_file_from_directory( $dir . '/' . $name, $dir );
		}
	}

	/* ─── Estimate ──────────────────────────────────────────────── */

	/**
	 * Count convertible images and their weight, store the estimate.
	 *
	 * @since 1.0.0
	 * @param float $deadline Unix time with microseconds; 0 for no limit.
	 * @return array
	 */
	public static function estimate( float $deadline ): array {
		global $wpdb;

		$result = array(
			'at'      => time(),
			'jpeg'    => 0,
			'png'     => 0,
			'bytes'   => array(
				'jpeg' => 0,
				'png'  => 0,
			),
			'skipped' => array(),
			'counted' => 0,
			'total'   => self::count_candidates( true ),
			'partial' => false,
		);

		$cursor  = 0;
		$basedir = trailingslashit( wp_get_upload_dir()['basedir'] );

		do {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared -- built from fixed parts and prepared values.
			$rows = $wpdb->get_results( 'SELECT p.ID, p.post_mime_type, f.meta_value AS file ' . self::candidate_sql( true ) . $wpdb->prepare( ' AND p.ID > %d ORDER BY p.ID ASC LIMIT 200', $cursor ), ARRAY_A );

			foreach ( $rows as $row ) {
				$cursor = (int) $row['ID'];
				$item   = MVweb_MDC_Cleaner::load( $cursor );
				$reason = self::skip_reason( $item, array( 'png' => true ) );

				++$result['counted'];
				wp_cache_delete( $cursor, 'post_meta' );

				if ( '' !== $reason ) {
					$result['skipped'][ $reason ] = ( $result['skipped'][ $reason ] ?? 0 ) + 1;
					continue;
				}

				$type = 'image/png' === $row['post_mime_type'] ? 'png' : 'jpeg';
				++$result[ $type ];
				$result['bytes'][ $type ] += self::bytes( $basedir . dirname( (string) $row['file'] ), self::meta_files( $item['meta'] ) );
			}

			if ( $deadline > 0 && microtime( true ) >= $deadline && $rows ) {
				$result['partial'] = true;
				break;
			}
		} while ( $rows );

		$result['growth']     = (int) round( ( $result['bytes']['jpeg'] + $result['bytes']['png'] ) * self::GAIN );
		$result['free']       = self::free_space();
		$result['optimizers'] = self::optimizers();

		update_option( self::ESTIMATE_OPTION, $result, false );

		return $result;
	}

	/**
	 * Free disk space under uploads, or null when the host hides it.
	 *
	 * @since 1.0.0
	 * @return float|null
	 */
	public static function free_space(): ?float {
		if ( ! function_exists( 'disk_free_space' ) ) {
			return null;
		}

		$free = @disk_free_space( wp_get_upload_dir()['basedir'] ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- disabled on some hosts.

		return false === $free ? null : (float) $free;
	}

	/**
	 * Active optimizers that keep their own WebP copies named like ours.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	public static function optimizers(): array {
		$found = array();

		if ( defined( 'EWWW_IMAGE_OPTIMIZER_VERSION' ) ) {
			$found[] = 'EWWW Image Optimizer';
		}

		if ( defined( 'SHORTPIXEL_IMAGE_OPTIMISER_VERSION' ) ) {
			$found[] = 'ShortPixel';
		}

		return $found;
	}
}
