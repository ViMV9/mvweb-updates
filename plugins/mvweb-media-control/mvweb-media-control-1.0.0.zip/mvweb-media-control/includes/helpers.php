<?php
/**
 * Helper functions for MVweb Media Control.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Plugin settings merged with defaults.
 *
 * @since 1.0.0
 * @return array{convert_webp: bool, delete_originals: bool, webp_quality: int, disabled_sizes: string[]}
 */
function mvweb_mdc_get_settings(): array {
	$defaults = array(
		'convert_webp'     => false,
		'delete_originals' => false,
		'webp_quality'     => MVweb_MDC_Uploads::WEBP_QUALITY,
		'disabled_sizes'   => array(),
	);

	$saved = get_option( 'mvweb_mdc_settings', array() );

	return array_merge( $defaults, is_array( $saved ) ? $saved : array() );
}

/**
 * WebP quality choices: value => label. The first one is the core default.
 *
 * @since 1.0.0
 * @return array<int, string>
 */
function mvweb_mdc_webp_qualities(): array {
	return array(
		MVweb_MDC_Uploads::WEBP_QUALITY => __( '86: WordPress default', 'mvweb-media-control' ),
		80                              => __( '80: smaller files', 'mvweb-media-control' ),
		75                              => __( '75: smallest files', 'mvweb-media-control' ),
	);
}

/**
 * Whether the server image editor can write WebP.
 *
 * @since 1.0.0
 * @return bool
 */
function mvweb_mdc_can_write_webp(): bool {
	static $supported = null;

	if ( null === $supported ) {
		$supported = wp_image_editor_supports( array( 'mime_type' => 'image/webp' ) );
	}

	return $supported;
}

/**
 * Whether the attachment is managed by an offload plugin.
 *
 * Any of: uploads on a stream wrapper, main file missing locally, URL outside
 * the uploads base URL, a WP-Stateless record, or a WP Offload Media row
 * ("copy to bucket, serve locally" keeps local files but re-uploads on every
 * metadata change).
 *
 * @since 1.0.0
 * @param int $attachment_id Attachment ID.
 * @return bool
 */
function mvweb_mdc_is_offloaded( int $attachment_id ): bool {
	global $wpdb;
	static $has_as3cf = null;

	$uploads = wp_get_upload_dir();

	if ( wp_is_stream( (string) $uploads['basedir'] ) ) {
		return true;
	}

	$file = (string) get_attached_file( $attachment_id, true );

	if ( '' === $file || ! is_file( $file ) ) {
		return true;
	}

	$strip_scheme = static function ( string $url ): string {
		return (string) preg_replace( '#^https?:#i', '', $url );
	};

	if ( ! str_starts_with( $strip_scheme( (string) wp_get_attachment_url( $attachment_id ) ), $strip_scheme( (string) $uploads['baseurl'] ) ) ) {
		return true;
	}

	// WP-Stateless lists the cloud copy of every size here and re-uploads on each metadata change.
	if ( metadata_exists( 'post', $attachment_id, 'sm_cloud' ) ) {
		return true;
	}

	$table = $wpdb->prefix . 'as3cf_items';

	if ( null === $has_as3cf ) {
		$has_as3cf = $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- schema check, one per request.
	}

	if ( ! $has_as3cf ) {
		return false;
	}

	return (bool) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- third-party table, no API.
		$wpdb->prepare(
			'SELECT 1 FROM %i WHERE source_type = %s AND source_id = %d LIMIT 1',
			$table,
			'media-library',
			$attachment_id
		)
	);
}

/**
 * Number of attachments whose original was kept after conversion.
 *
 * @since 1.0.0
 * @return int
 */
function mvweb_mdc_kept_originals_count(): int {
	global $wpdb;

	return count( mvweb_mdc_kept_original_ids( 0, 0 ) );
}

/**
 * Attachments converted to WebP whose original is still kept.
 *
 * Records whose main file is not WebP yet are left out: either client-side
 * processing is still running, or the server could not convert the file.
 *
 * @since 1.0.0
 * @param int $after Return IDs greater than this.
 * @param int $limit Maximum number of IDs, 0 for all.
 * @return int[]
 */
function mvweb_mdc_kept_original_ids( int $after, int $limit ): array {
	global $wpdb;

	$sql = $wpdb->prepare(
		"SELECT s.post_id FROM {$wpdb->postmeta} s
		INNER JOIN {$wpdb->postmeta} f ON f.post_id = s.post_id AND f.meta_key = '_wp_attached_file'
		WHERE s.meta_key = %s AND f.meta_value LIKE %s AND s.post_id > %d
		ORDER BY s.post_id ASC",
		'_mvweb_mdc_source',
		'%' . $wpdb->esc_like( '.webp' ),
		$after
	);

	if ( $limit > 0 ) {
		$sql .= $wpdb->prepare( ' LIMIT %d', $limit );
	}

	return array_map( 'intval', $wpdb->get_col( $sql ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared -- prepared above.
}

/**
 * Size names allowed in requests: the registered sizes.
 *
 * Compared strictly against the raw string. sanitize_key() is not used:
 * it lowercases and strips characters, while add_image_size() accepts any string.
 *
 * @since 1.0.0
 * @return string[]
 */
function mvweb_mdc_allowed_size_names(): array {
	return array_map( 'strval', array_keys( wp_get_registered_image_subsizes() ) );
}
