<?php
/**
 * WP-CLI commands: a thin wrapper over the cleanup engine.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable Generic.CodeAnalysis.UnusedFunctionParameter -- WP-CLI passes $args and $assoc_args to every subcommand.

/**
 * Clean up generated image sizes.
 *
 * ## EXAMPLES
 *
 *     wp mvweb-media-control scan
 *     wp mvweb-media-control clean --sizes=medium_large,1536x1536
 *     wp mvweb-media-control delete
 *
 * @since 1.0.0
 */
final class MVweb_MDC_CLI {

	/**
	 * Build the link index and report sizes, files and space.
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Named arguments.
	 * @return void
	 */
	public function scan( $args, $assoc_args ): void {
		$this->run( 'scan' );
		$this->print_report();
	}

	/**
	 * Step A: remove sizes from metadata. Files stay until `delete`.
	 *
	 * ## OPTIONS
	 *
	 * --sizes=<names>
	 * : Comma-separated size names: disabled or no longer registered, from the last scan.
	 *
	 * [--yes]
	 * : Skip the confirmation.
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Named arguments.
	 * @return void
	 */
	public function clean( $args, $assoc_args ): void {
		$sizes   = array_filter( array_map( 'trim', explode( ',', (string) ( $assoc_args['sizes'] ?? '' ) ) ) );
		$invalid = array_diff( $sizes, MVweb_MDC_Cleaner::selectable_sizes() );

		if ( ! $sizes || $invalid ) {
			WP_CLI::error( sprintf( 'Not selectable: %s. Run `scan` first; only disabled or unregistered sizes can be cleaned.', $invalid ? implode( ', ', $invalid ) : '(none given)' ) );
		}

		$this->print_report( $sizes );
		WP_CLI::confirm( 'Remove these sizes from metadata? Files are deleted later by `delete`.', $assoc_args );

		$this->run( 'apply', $sizes );
		WP_CLI::log( 'Now purge the page cache and CDN, then run `wp mvweb-media-control delete`.' );
	}

	/**
	 * Step B: delete files removed from metadata by `clean`.
	 *
	 * ## OPTIONS
	 *
	 * [--yes]
	 * : Skip the confirmation.
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Named arguments.
	 * @return void
	 */
	public function delete( $args, $assoc_args ): void {
		$pending = MVweb_MDC_Cleaner::pending_summary();

		if ( ! $pending['attachments'] ) {
			WP_CLI::error( 'Nothing to delete.' );
		}

		WP_CLI::confirm( sprintf( 'Delete %d files (%s)? Page cache and CDN must be purged first.', $pending['files'], size_format( $pending['bytes'] ) ), $assoc_args );

		$this->run( 'delete' );
	}

	/**
	 * Undo `clean`: return sizes to metadata while their files still exist.
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Named arguments.
	 * @return void
	 */
	public function undo( $args, $assoc_args ): void {
		$this->run( 'undo' );
	}

	/**
	 * Regenerate sizes from the original images.
	 *
	 * ## OPTIONS
	 *
	 * --sizes=<names>
	 * : Comma-separated registered size names that are not disabled.
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Named arguments.
	 * @return void
	 */
	public function restore( $args, $assoc_args ): void {
		$sizes   = array_filter( array_map( 'trim', explode( ',', (string) ( $assoc_args['sizes'] ?? '' ) ) ) );
		$invalid = array_diff( $sizes, MVweb_MDC_Cleaner::restorable_sizes() );

		if ( ! $sizes || $invalid ) {
			WP_CLI::error( sprintf( 'Not restorable: %s. Only registered sizes that are not disabled.', $invalid ? implode( ', ', $invalid ) : '(none given)' ) );
		}

		$this->run( 'restore', $sizes );
	}

	/**
	 * Show the current task and pending files.
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Named arguments.
	 * @return void
	 */
	public function status( $args, $assoc_args ): void {
		$job     = MVweb_MDC_Cleaner::get_job();
		$pending = MVweb_MDC_Cleaner::pending_summary();

		WP_CLI::log( sprintf( 'Task: %s', empty( $job['action'] ) ? 'none' : $job['action'] . ( empty( $job['finished'] ) ? ' (in progress)' : ' (finished)' ) ) );
		WP_CLI::log( sprintf( 'Waiting for delete: %d attachments, %d files, %s', $pending['attachments'], $pending['files'], size_format( $pending['bytes'] ) ) );
	}

	/**
	 * Cancel the current task. Pending journals are kept.
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Named arguments.
	 * @return void
	 */
	public function cancel( $args, $assoc_args ): void {
		MVweb_MDC_Cleaner::cancel();
		WP_CLI::success( 'Cancelled.' );
	}

	/**
	 * Convert existing JPEG and PNG images to WebP.
	 *
	 * ## OPTIONS
	 *
	 * <command>
	 * : estimate, start, status, pause, resume, run (convert and replace links now), undo, delete (old files).
	 *
	 * [--period=<period>]
	 * : For start: day, 2days or week.
	 * ---
	 * default: day
	 * ---
	 *
	 * [--delete-originals]
	 * : For start: delete originals in the last step.
	 *
	 * [--skip-png]
	 * : For start: convert JPEG only.
	 *
	 * [--yes]
	 * : Skip the confirmation.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-media-control convert start --period=week
	 *     wp mvweb-media-control convert run
	 *     wp mvweb-media-control convert delete
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Named arguments.
	 * @return void
	 */
	public function convert( $args, $assoc_args ): void {
		$this->guard();

		$command = (string) ( $args[0] ?? '' );

		switch ( $command ) {
			case 'estimate':
				$e = MVweb_MDC_Converter::estimate( 0 );
				WP_CLI::log( sprintf( 'JPEG: %d (%s), PNG: %d (%s)', $e['jpeg'], size_format( (int) $e['bytes']['jpeg'] ), $e['png'], size_format( (int) $e['bytes']['png'] ) ) );
				if ( $e['skipped'] ) {
					WP_CLI::log( 'Will not be converted: ' . wp_json_encode( $e['skipped'] ) );
				}
				WP_CLI::log( sprintf( 'Extra disk space until the last step: about %s. Free: %s', size_format( (int) $e['growth'] ), null === $e['free'] ? 'unknown' : size_format( (float) $e['free'] ) ) );
				if ( $e['optimizers'] ) {
					WP_CLI::warning( sprintf( 'Active: %s. Images with an existing photo.webp are skipped.', implode( ', ', $e['optimizers'] ) ) );
				}
				return;

			case 'start':
				WP_CLI::confirm( 'Start conversion? A backup of uploads and the database must exist.', $assoc_args );
				$job = MVweb_MDC_Converter::start( (string) ( $assoc_args['period'] ?? 'day' ), ! empty( $assoc_args['delete-originals'] ), empty( $assoc_args['skip-png'] ) );
				if ( is_wp_error( $job ) ) {
					WP_CLI::error( $job->get_error_message() );
				}
				WP_CLI::success( 'Started. WP-Cron converts the images; `run` does it now.' );
				return;

			case 'pause':
				MVweb_MDC_Converter::pause();
				WP_CLI::success( 'Paused.' );
				return;

			case 'resume':
				MVweb_MDC_Converter::resume();
				WP_CLI::success( 'Resumed.' );
				return;

			case 'run':
				if ( 'running' !== MVweb_MDC_Converter::status() ) {
					WP_CLI::error( 'Conversion is not running. Use `start` or `resume`.' );
				}
				$this->report( MVweb_MDC_Converter::step( 0 ) );
				return;

			case 'delete':
			case 'undo':
				WP_CLI::confirm( 'delete' === $command ? 'Delete the old files? Page cache and CDN must be purged first. This cannot be undone.' : 'Undo the conversion?', $assoc_args );
				$job = MVweb_MDC_Converter::begin( $command );
				if ( is_wp_error( $job ) ) {
					WP_CLI::error( $job->get_error_message() );
				}
				$this->report( MVweb_MDC_Converter::step( 0 ) );
				return;

			case 'status':
				$job = MVweb_MDC_Converter::get_job();
				WP_CLI::log( sprintf( 'Status: %s', '' === ( $job['status'] ?? '' ) ? 'none' : $job['status'] ) );
				if ( ! empty( $job['phases'] ) ) {
					WP_CLI::log( sprintf( 'Phase: %s, %d of %d', $job['phases'][ $job['phase'] ] ?? 'finished', $job['processed'], $job['total'] ) );
				}
				WP_CLI::log( sprintf( 'Converted and waiting for delete: %d', MVweb_MDC_Converter::journal_count() ) );
				return;
		}

		WP_CLI::error( 'Unknown command. Use estimate, start, status, pause, resume, run, undo or delete.' );
	}

	/**
	 * Find images nothing refers to and move them to the trash.
	 *
	 * ## OPTIONS
	 *
	 * <command>
	 * : scan, list, trash, restore, purge.
	 *
	 * [--group=<group>]
	 * : For list and trash: unused (no references found) or manual (check by hand).
	 * ---
	 * default: unused
	 * ---
	 *
	 * [--ids=<ids>]
	 * : For trash, restore and purge: comma-separated attachment IDs (group leaders).
	 *
	 * [--all]
	 * : For trash: the whole group; for restore and purge: everything this plugin trashed.
	 *
	 * [--format=<format>]
	 * : For list: table, csv or ids.
	 * ---
	 * default: table
	 * ---
	 *
	 * [--yes]
	 * : Skip the confirmation.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-media-control unused scan
	 *     wp mvweb-media-control unused list --format=csv
	 *     wp mvweb-media-control unused trash --ids=123,456
	 *     wp mvweb-media-control unused restore --all
	 *
	 * @param array $args       Positional arguments.
	 * @param array $assoc_args Named arguments.
	 * @return void
	 */
	public function unused( $args, $assoc_args ): void {
		$command = (string) ( $args[0] ?? '' );
		$group   = 'manual' === ( $assoc_args['group'] ?? '' ) ? 'manual' : 'unused';
		$ids     = wp_parse_id_list( (string) ( $assoc_args['ids'] ?? '' ) );
		$all     = ! empty( $assoc_args['all'] );

		switch ( $command ) {
			case 'scan':
				$job = MVweb_MDC_Unused::start();
				if ( is_wp_error( $job ) ) {
					WP_CLI::error( $job->get_error_message() );
				}
				$job = MVweb_MDC_Unused::step( 0 );
				if ( is_wp_error( $job ) || '' !== $job['error'] ) {
					WP_CLI::error( is_wp_error( $job ) ? $job->get_error_message() : 'Scan stopped: ' . $job['error'] );
				}
				$report = MVweb_MDC_Unused::report();
				WP_CLI::log( sprintf( 'Images: %d, in use: %d', $report['attachments'], $report['stats']['used'] ) );
				WP_CLI::log( sprintf( 'No references found: %d groups, %s', $report['stats']['unused']['groups'], size_format( (int) $report['stats']['unused']['bytes'] ) ) );
				WP_CLI::log( sprintf( 'Check by hand: %d groups, %s', $report['stats']['manual']['groups'], size_format( (int) $report['stats']['manual']['bytes'] ) ) );
				if ( $report['stats']['skipped'] ) {
					WP_CLI::log( 'Not checked: ' . wp_json_encode( $report['stats']['skipped'] ) );
				}
				if ( $report['unread'] ) {
					WP_CLI::warning( 'Tables not read: ' . implode( ', ', $report['unread'] ) );
				}
				break;

			case 'list':
				$rows = MVweb_MDC_Unused::rows( $group );
				if ( 'ids' === ( $assoc_args['format'] ?? '' ) ) {
					WP_CLI::log( implode( ' ', wp_list_pluck( $rows, 'id' ) ) );
					break;
				}
				WP_CLI\Utils\format_items( (string) ( $assoc_args['format'] ?? 'table' ), $rows, array( 'id', 'ids', 'file', 'date', 'bytes', 'parent', 'reason' ) );
				break;

			case 'trash':
				$ids = $all ? wp_list_pluck( MVweb_MDC_Unused::rows( $group ), 'id' ) : $ids;
				if ( ! $ids ) {
					WP_CLI::error( 'Nothing selected: pass --ids or --all.' );
				}
				WP_CLI::confirm( sprintf( 'Move %d groups to the trash? Files stay on disk for 30 days.', count( $ids ) ), $assoc_args );
				$result = MVweb_MDC_Unused::trash( $ids );
				if ( is_wp_error( $result ) ) {
					WP_CLI::error( $result->get_error_message() );
				}
				WP_CLI::success( sprintf( 'Trashed: %d, kept (referenced again or changed): %d, failed: %d', $result['done'], $result['kept'], $result['failed'] ) );
				break;

			case 'restore':
			case 'purge':
				$ids = $all ? array_keys( MVweb_MDC_Unused::trashed_groups() ) : $ids;
				if ( ! $ids ) {
					WP_CLI::error( 'Nothing selected: pass --ids or --all.' );
				}
				if ( 'purge' === $command ) {
					WP_CLI::confirm( sprintf( 'Delete %d groups and all their files for good? Make sure a backup exists.', count( $ids ) ), $assoc_args );
					$result = MVweb_MDC_Unused::purge( $ids );
					WP_CLI::success( sprintf( 'Deleted: %d (%s), failed: %d', $result['done'], size_format( $result['bytes'] ), $result['failed'] ) );
				} else {
					$result = MVweb_MDC_Unused::restore( $ids );
					WP_CLI::success( sprintf( 'Restored: %d, failed: %d', $result['done'], $result['failed'] ) );
				}
				break;

			default:
				WP_CLI::error( 'Unknown command. Use scan, list, trash, restore or purge.' );
		}
	}

	/**
	 * Print the result of a conversion run.
	 *
	 * @param array|WP_Error $job Job state.
	 * @return void
	 */
	private function report( $job ): void {
		if ( is_wp_error( $job ) ) {
			WP_CLI::error( $job->get_error_message() );
		}

		foreach ( $job['stats'] as $key => $value ) {
			if ( is_scalar( $value ) ) {
				WP_CLI::log( sprintf( '%s: %s', $key, in_array( $key, array( 'freed', 'bytes_old', 'bytes_new' ), true ) ? size_format( (int) $value ) : $value ) );
			} elseif ( 'skipped' === $key ) {
				WP_CLI::log( 'skipped: ' . wp_json_encode( $value ) );
			}
		}

		if ( $job['failed'] ) {
			WP_CLI::warning( 'Failed: ' . wp_json_encode( $job['failed'] ) );
		}

		WP_CLI::success( sprintf( 'Status: %s.', $job['status'] ) );
	}

	/**
	 * Start or continue a task and run it to the end.
	 *
	 * @param string   $action Action.
	 * @param string[] $sizes  Size names.
	 * @return void
	 */
	private function run( string $action, array $sizes = array() ): void {
		$this->guard();

		$job = MVweb_MDC_Cleaner::get_job();

		if ( MVweb_MDC_Cleaner::is_running() ) {
			if ( ( $job['action'] ?? '' ) !== $action ) {
				WP_CLI::error( sprintf( 'Another task is in progress: %s. Run `status` or `cancel`.', $job['action'] ) );
			}
			WP_CLI::log( 'Continuing the unfinished task.' );
		} else {
			$job = MVweb_MDC_Cleaner::start( $action, $sizes );
			if ( is_wp_error( $job ) ) {
				WP_CLI::error( $job->get_error_message() );
			}
		}

		$job = MVweb_MDC_Cleaner::step( 0 );

		if ( is_wp_error( $job ) ) {
			WP_CLI::error( $job->get_error_message() );
		}

		if ( '' !== $job['error'] ) {
			WP_CLI::error( sprintf( 'Stopped: %s.', $job['error'] ) );
		}

		foreach ( $job['stats'] as $key => $value ) {
			if ( is_scalar( $value ) ) {
				WP_CLI::log( sprintf( '%s: %s', $key, 'bytes' === $key ? size_format( (int) $value ) : $value ) );
			}
		}

		if ( $job['failed'] ) {
			WP_CLI::warning( sprintf( 'Failed attachments: %s', implode( ', ', array_unique( $job['failed'] ) ) ) );
		}

		WP_CLI::success( sprintf( '%s finished.', ucfirst( $action ) ) );
	}

	/**
	 * Refuse to run without themes or plugins: the size registry would be incomplete.
	 *
	 * @return void
	 */
	private function guard(): void {
		$config = WP_CLI::get_runner()->config;

		if ( ! empty( $config['skip-themes'] ) || ! empty( $config['skip-plugins'] ) ) {
			WP_CLI::error( 'Run without --skip-themes and --skip-plugins: image sizes are registered by the theme and plugins.' );
		}
	}

	/**
	 * Print the last scan report.
	 *
	 * @param string[] $only Limit to these sizes.
	 * @return void
	 */
	private function print_report( array $only = array() ): void {
		$report = get_option( MVweb_MDC_Cleaner::REPORT_OPTION, array() );

		if ( empty( $report['sizes'] ) ) {
			WP_CLI::log( 'No report yet.' );
			return;
		}

		$selectable = MVweb_MDC_Cleaner::selectable_sizes();
		$rows       = array();

		foreach ( $report['sizes'] as $name => $row ) {
			$name = (string) $name;
			if ( $only && ! in_array( $name, $only, true ) ) {
				continue;
			}
			$rows[] = array(
				'size'        => $name,
				'selectable'  => in_array( $name, $selectable, true ) ? 'yes' : 'no',
				'attachments' => $row['attachments'],
				'files'       => $row['files'],
				'space'       => size_format( (int) $row['bytes'] ),
				'protected'   => $row['protected'],
				'skipped'     => $row['skipped'],
			);
		}

		WP_CLI\Utils\format_items( 'table', $rows, array( 'size', 'selectable', 'attachments', 'files', 'space', 'protected', 'skipped' ) );

		if ( ! empty( $report['skipped'] ) ) {
			WP_CLI::log( 'Skipped attachments: ' . wp_json_encode( $report['skipped'] ) );
		}

		if ( ! empty( $report['not_freed']['files'] ) ) {
			WP_CLI::log( sprintf( 'Not freed (optimizer copies named by stem): %d files, %s', $report['not_freed']['files'], size_format( (int) $report['not_freed']['bytes'] ) ) );
		}
	}
}
