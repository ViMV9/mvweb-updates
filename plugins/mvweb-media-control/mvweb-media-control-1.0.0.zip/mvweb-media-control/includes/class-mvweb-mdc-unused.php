<?php
/**
 * Unused attachments: usage index, scan, trash, restore, purge.
 *
 * Keeps its own index: the stage 1 index contains _wp_attached_file, so every
 * attachment would look used, and its source list is also written to by the
 * conversion. Trashed attachments are deleted by the core trash cron.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Unused attachments engine.
 *
 * @since 1.0.0
 */
final class MVweb_MDC_Unused {

	const JOB_OPTION = 'mvweb_mdc_unused_job';

	const REPORT_OPTION = 'mvweb_mdc_unused_report';

	const IDS_TRANSIENT = 'mvweb_mdc_unused_ids';

	const INDEX_PREFIX = 'mdc_uidx_';

	const TRASHED_META = '_mvweb_mdc_trashed';

	const MIN_AGE = 30 * DAY_IN_SECONDS;

	const HOLD = 30 * DAY_IN_SECONDS;

	const REPORT_TTL = HOUR_IN_SECONDS;

	const ROWS = 200;

	const BATCH = 50;

	const FLUSH = 5000;

	const KEY_PATTERN = 'image|img|logo|icon|photo|thumb|banner|background|bg|gallery|avatar|media';

	const THEME_EXT = array( 'php', 'css', 'js', 'json', 'html', 'htm' );

	const SKIP_TABLES = array( 'actionscheduler_logs', 'woocommerce_sessions', 'wc_sessions' );

	/**
	 * Names collected in this request and not yet stored.
	 *
	 * @var array<string, true>
	 */
	private static array $buffer = array();

	/**
	 * Loaded usage index.
	 *
	 * @var array<string, true>|null
	 */
	private static ?array $index = null;

	/**
	 * Whether this request purges on purpose, past the hold.
	 *
	 * @var bool
	 */
	private static bool $purging = false;

	/**
	 * Register hooks that must run outside the admin page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_filter( 'pre_delete_attachment', array( __CLASS__, 'guard_delete' ), 10, 2 );
	}

	/* ─── Scan job ──────────────────────────────────────────────── */

	/**
	 * Current scan job.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function get_job(): array {
		$job = get_option( self::JOB_OPTION, array() );
		return is_array( $job ) ? $job : array();
	}

	/**
	 * Whether a scan is started and not finished.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function is_running(): bool {
		$job = self::get_job();
		return ! empty( $job['started'] ) && empty( $job['finished'] );
	}

	/**
	 * Last scan report.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function report(): array {
		$report = get_option( self::REPORT_OPTION, array() );
		return is_array( $report ) ? $report : array();
	}

	/**
	 * Start a scan.
	 *
	 * @since 1.0.0
	 * @return array|WP_Error Job state.
	 */
	public static function start() {
		if ( MVweb_MDC_Cleaner::is_running() || MVweb_MDC_Converter::is_active() ) {
			return new WP_Error( 'mvweb_mdc_busy', __( 'A cleanup or conversion task is in progress. Finish it first.', 'mvweb-media-control' ) );
		}

		if ( ! MVweb_MDC_Cleaner::lock() ) {
			return new WP_Error( 'mvweb_mdc_locked', __( 'The task is already running in another tab or process.', 'mvweb-media-control' ) );
		}

		self::drop_index();
		delete_transient( self::IDS_TRANSIENT );

		$sources = self::sources();
		$job     = array(
			'phase'     => 'index',
			'sources'   => $sources,
			'source'    => 0,
			'cursor'    => 0,
			'offset'    => 0,
			'total'     => count( $sources ),
			'processed' => 0,
			'chunks'    => 0,
			'ids'       => array(),
			'unread'    => array(),
			'stats'     => self::empty_stats(),
			'list'      => array(),
			'error'     => '',
			'started'   => time(),
			'finished'  => 0,
		);

		update_option( self::JOB_OPTION, $job, false );
		MVweb_MDC_Cleaner::unlock();

		return $job;
	}

	/**
	 * Stop the scan without a report.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function cancel(): void {
		$job = self::get_job();

		if ( self::is_running() ) {
			$job['finished'] = time();
			$job['error']    = 'cancelled';
			update_option( self::JOB_OPTION, $job, false );
		}
	}

	/**
	 * Run the scan until it finishes or the deadline passes.
	 *
	 * Phases: index (all tables, names and IDs in content), theme (theme code),
	 * ids (known ID fields), check (attachments).
	 *
	 * @since 1.0.0
	 * @param float $deadline Unix time with microseconds; 0 runs to the end.
	 * @return array|WP_Error Job state.
	 */
	public static function step( float $deadline ) {
		$job = self::get_job();

		if ( empty( $job['started'] ) || ! empty( $job['finished'] ) ) {
			return $job;
		}

		if ( ! MVweb_MDC_Cleaner::lock() ) {
			return new WP_Error( 'mvweb_mdc_locked', __( 'The task is already running in another tab or process.', 'mvweb-media-control' ) );
		}

		while ( empty( $job['finished'] ) ) {
			switch ( $job['phase'] ) {
				case 'index':
					if ( self::index_unit( $job ) ) {
						$job['phase']     = 'theme';
						$job['processed'] = 0;
					}
					break;

				case 'theme':
					self::theme_unit( $job );
					$job['phase'] = 'ids';
					break;

				case 'ids':
					$job['ids']       = self::collect_ids( $job['ids'] );
					$job['phase']     = 'check';
					$job['cursor']    = 0;
					$job['processed'] = 0;
					$job['total']     = self::image_count();
					break;

				case 'check':
					self::flush( $job );
					if ( self::check_unit( $job ) ) {
						self::finish( $job );
					}
					break;
			}

			self::flush( $job );

			if ( '' !== $job['error'] && empty( $job['finished'] ) ) {
				$job['finished'] = time();
			}

			update_option( self::JOB_OPTION, $job, false );

			if ( MVweb_MDC_Cleaner::out_of_budget( $deadline ) ) {
				break;
			}

			MVweb_MDC_Cleaner::lock();
		}

		MVweb_MDC_Cleaner::unlock();

		return $job;
	}

	/**
	 * Counters of a new scan.
	 *
	 * @return array
	 */
	private static function empty_stats(): array {
		return array(
			'used'    => 0,
			'unused'  => array(
				'groups' => 0,
				'bytes'  => 0,
			),
			'manual'  => array(
				'groups' => 0,
				'bytes'  => 0,
			),
			'skipped' => array(),
		);
	}

	/**
	 * Store the report and drop the job data.
	 *
	 * @param array $job Job state.
	 * @return void
	 */
	private static function finish( array &$job ): void {
		update_option(
			self::REPORT_OPTION,
			array(
				'at'          => time(),
				'attachments' => (int) $job['processed'],
				'stats'       => $job['stats'],
				'unread'      => $job['unread'],
				'list'        => $job['list'],
			),
			false
		);

		$job['finished'] = time();
		$job['list']     = array();
		$job['ids']      = array();
		$job['sources']  = array();
	}

	/**
	 * Number of image attachments outside the trash.
	 *
	 * @return int
	 */
	private static function image_count(): int {
		global $wpdb;

		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_mime_type LIKE 'image/%' AND post_status <> 'trash'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/* ─── Usage index ───────────────────────────────────────────── */

	/**
	 * Tables and columns read for file names.
	 *
	 * The stage 1 sources without self-references (_wp_attached_file, Yoast rows
	 * of attachments, attachment posts), plus every other table of the site.
	 *
	 * @since 1.0.0
	 * @return array<int, array{table: string, id: string, cols: string[], where: string, content?: bool}>
	 */
	public static function sources(): array {
		global $wpdb;

		$sources = array();
		$known   = array();

		foreach ( MVweb_MDC_Cleaner::index_sources() as $src ) {
			$known[ $src['table'] ] = true;

			if ( $wpdb->posts === $src['table'] ) {
				$src['where']   = "post_type <> 'attachment'";
				$src['content'] = true;
			} elseif ( $wpdb->postmeta === $src['table'] ) {
				$src['where'] .= " AND meta_key <> '_wp_attached_file'";
			} elseif ( $wpdb->options === $src['table'] ) {
				$src['where'] .= " AND option_name NOT LIKE 'mdc\\_uidx\\_%'";
			} elseif ( $wpdb->prefix . 'yoast_indexable' === $src['table'] ) {
				$src['where'] = "(object_sub_type IS NULL OR object_sub_type <> 'attachment')";
			}

			$sources[] = $src;
		}

		foreach ( self::extra_tables( $known ) as $src ) {
			$sources[] = $src;
		}

		return $sources;
	}

	/**
	 * Other tables of this site with their text columns.
	 *
	 * @param array<string, true> $known Tables already read.
	 * @return array[]
	 */
	private static function extra_tables( array $known ): array {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery -- schema reads.
		$tables = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $wpdb->prefix ) . '%' ) );
		$result = array();
		$other  = is_multisite() && $wpdb->prefix === $wpdb->base_prefix ? '/^' . preg_quote( $wpdb->base_prefix, '/' ) . '\d+_/' : '';

		foreach ( $tables as $table ) {
			$table = (string) $table;
			$short = substr( $table, strlen( $wpdb->prefix ) );

			if ( isset( $known[ $table ] ) || in_array( $short, self::SKIP_TABLES, true ) || ( '' !== $other && preg_match( $other, $table ) ) ) {
				continue;
			}

			$cols = array();
			$key  = '';

			foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SHOW COLUMNS FROM %i', $table ), ARRAY_A ) as $col ) {
				$type = strtolower( (string) $col['Type'] );

				if ( preg_match( '/char|text|json/', $type ) ) {
					$cols[] = (string) $col['Field'];
				}

				if ( 'PRI' === $col['Key'] && preg_match( '/int/', $type ) ) {
					$key = '' === $key ? (string) $col['Field'] : '-';
				}
			}
			// phpcs:enable

			if ( $cols ) {
				$result[] = array(
					'table' => $table,
					'id'    => '-' === $key ? '' : $key,
					'cols'  => $cols,
					'where' => '',
				);
			}
		}

		return $result;
	}

	/**
	 * Read one batch of the current source.
	 *
	 * A table without a single numeric primary key is read by offset, sorted by
	 * all its columns so that batches do not overlap or skip rows.
	 *
	 * @param array $job Job state.
	 * @return bool True when all sources are read.
	 */
	private static function index_unit( array &$job ): bool {
		global $wpdb;

		$sources = $job['sources'];

		if ( ! isset( $sources[ $job['source'] ] ) ) {
			return true;
		}

		$src   = $sources[ $job['source'] ];
		$where = '' !== $src['where'] ? ' AND ' . $src['where'] : '';
		$cols  = array_merge( '' !== $src['id'] ? array( $src['id'] ) : array(), $src['cols'] );
		$list  = implode( ', ', array_fill( 0, count( $cols ), '%i' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- identifiers go through %i, filters are fixed above.
		if ( '' !== $src['id'] ) {
			$sql = $wpdb->prepare( "SELECT {$list} FROM %i WHERE %i > %d", array_merge( $cols, array( $src['table'], $src['id'], (int) $job['cursor'] ) ) )
				. $where
				. $wpdb->prepare( ' ORDER BY %i ASC LIMIT %d', $src['id'], self::ROWS );
		} else {
			$sql = $wpdb->prepare( "SELECT {$list} FROM %i ORDER BY {$list} LIMIT %d, %d", array_merge( $cols, array( $src['table'] ), $cols, array( (int) $job['offset'], self::ROWS ) ) );
		}

		$wpdb->last_error = '';
		$rows             = $wpdb->get_results( $sql, ARRAY_A );
		// phpcs:enable

		if ( '' !== $wpdb->last_error ) {
			$job['unread'][] = $src['table'];
			$rows            = array();
		}

		foreach ( $rows as $row ) {
			foreach ( $src['cols'] as $col ) {
				$value = (string) $row[ $col ];
				self::collect_names( $value );

				if ( ! empty( $src['content'] ) && 'post_content' === $col ) {
					$job['ids'] = self::content_ids( $value, (int) $row[ $src['id'] ], $job['ids'] );
				}
			}

			if ( '' !== $src['id'] ) {
				$job['cursor'] = (int) $row[ $src['id'] ];
			}
		}

		$job['offset'] += count( $rows );

		if ( count( $rows ) < self::ROWS ) {
			++$job['source'];
			++$job['processed'];
			$job['cursor'] = 0;
			$job['offset'] = 0;
		}

		if ( count( self::$buffer ) >= self::FLUSH ) {
			self::flush( $job );
		}

		return ! isset( $sources[ $job['source'] ] );
	}

	/**
	 * Add image file names found in a value to the buffer.
	 *
	 * @param string $value Raw value.
	 * @return void
	 */
	private static function collect_names( string $value ): void {
		if ( '' === $value || ! preg_match( '/\.(?:' . MVweb_MDC_Cleaner::IMAGE_EXT . ')/i', $value ) ) {
			return;
		}

		foreach ( MVweb_MDC_Cleaner::extract_names( $value ) as $name ) {
			self::$buffer[ $name ] = true;
		}
	}

	/**
	 * Store buffered names as a new index chunk.
	 *
	 * @param array $job Job state.
	 * @return void
	 */
	private static function flush( array &$job ): void {
		if ( ! self::$buffer ) {
			return;
		}

		$n = (int) $job['chunks'] + 1;

		if ( ! add_option( self::INDEX_PREFIX . $n, array_keys( self::$buffer ), '', false ) ) {
			$job['error'] = 'index_write';
			return;
		}

		$job['chunks'] = $n;

		if ( null !== self::$index ) {
			self::$index += self::$buffer;
		}

		self::$buffer = array();
	}

	/**
	 * Delete all index chunks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function drop_index(): void {
		global $wpdb;

		$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( self::INDEX_PREFIX ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		foreach ( $names as $name ) {
			delete_option( $name );
		}

		self::$index = null;
	}

	/**
	 * Whether a file name is in the usage index.
	 *
	 * @param string $name File base name.
	 * @return bool
	 */
	private static function in_index( string $name ): bool {
		global $wpdb;

		if ( null === self::$index ) {
			self::$index = array();
			$values      = $wpdb->get_col( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( self::INDEX_PREFIX ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

			foreach ( $values as $value ) {
				$names = maybe_unserialize( $value );
				if ( is_array( $names ) ) {
					self::$index += array_fill_keys( $names, true );
				}
			}
		}

		return isset( self::$index[ $name ] );
	}

	/**
	 * Read the active and parent theme code for file names and fixed IDs.
	 *
	 * @param array $job Job state.
	 * @return void
	 */
	private static function theme_unit( array &$job ): void {
		foreach ( array_unique( array( get_stylesheet_directory(), get_template_directory() ) ) as $dir ) {
			if ( ! is_dir( $dir ) ) {
				continue;
			}

			$iterator = new RecursiveIteratorIterator(
				new RecursiveCallbackFilterIterator(
					new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ),
					static function ( SplFileInfo $item ): bool {
						return ! $item->isDir() || ! in_array( $item->getFilename(), array( 'node_modules', 'vendor', '.git' ), true );
					}
				)
			);

			foreach ( $iterator as $item ) {
				if ( ! in_array( strtolower( $item->getExtension() ), self::THEME_EXT, true ) || $item->getSize() > 2 * MB_IN_BYTES ) {
					continue;
				}

				$code = (string) file_get_contents( $item->getPathname() ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local theme file.
				self::collect_names( $code );

				if ( preg_match_all( '/wp_get_attachment_\w+\(\s*(\d+)/', $code, $m ) ) {
					foreach ( $m[1] as $id ) {
						$job['ids']['used'][ (int) $id ] = true;
					}
				}
			}
		}
	}

	/* ─── References by ID ──────────────────────────────────────── */

	/**
	 * Attachment IDs referenced in post content.
	 *
	 * Image classes, captions, gallery shortcodes and core block attributes
	 * mean used. A numeric id attribute of another block means "check by hand".
	 * A gallery without ids shows the attachments of its post.
	 *
	 * @since 1.0.0
	 * @param string $content Post content.
	 * @param int    $post_id Post ID.
	 * @param array  $ids     Collected sets: used, maybe, parents.
	 * @return array
	 */
	public static function content_ids( string $content, int $post_id, array $ids ): array {
		if ( '' === $content ) {
			return $ids;
		}

		if ( preg_match_all( '/wp-image-(\d+)|\[caption[^\]]*\bid=["\']?attachment_(\d+)/', $content, $m ) ) {
			foreach ( array_filter( array_merge( $m[1], $m[2] ) ) as $id ) {
				$ids['used'][ (int) $id ] = true;
			}
		}

		if ( str_contains( $content, '[gallery' ) && preg_match_all( '/' . get_shortcode_regex( array( 'gallery' ) ) . '/', $content, $m, PREG_SET_ORDER ) ) {
			foreach ( $m as $shortcode ) {
				$atts = shortcode_parse_atts( $shortcode[3] );
				$list = is_array( $atts ) ? ( $atts['ids'] ?? $atts['include'] ?? '' ) : '';

				if ( '' === $list ) {
					$ids['parents'][ $post_id ] = true;
				}

				foreach ( wp_parse_id_list( $list ) as $id ) {
					$ids['used'][ $id ] = true;
				}
			}
		}

		if ( str_contains( $content, '<!-- wp:' ) ) {
			$ids = self::block_ids( parse_blocks( $content ), $ids );
		}

		return $ids;
	}

	/**
	 * Attachment IDs in block attributes.
	 *
	 * @param array[] $blocks Parsed blocks.
	 * @param array   $ids    Collected sets.
	 * @return array
	 */
	private static function block_ids( array $blocks, array $ids ): array {
		foreach ( $blocks as $block ) {
			$core = str_starts_with( (string) $block['blockName'], 'core/' );

			foreach ( (array) $block['attrs'] as $key => $value ) {
				if ( $core && in_array( $key, array( 'id', 'ids', 'mediaId' ), true ) ) {
					foreach ( wp_parse_id_list( is_array( $value ) ? $value : (string) $value ) as $id ) {
						$ids['used'][ $id ] = true;
					}
				} elseif ( ! $core && is_int( $value ) && preg_match( '/id$/i', (string) $key ) ) {
					$ids['maybe'][ $value ] = true;
				}
			}

			if ( ! empty( $block['innerBlocks'] ) ) {
				$ids = self::block_ids( $block['innerBlocks'], $ids );
			}
		}

		return $ids;
	}

	/**
	 * Attachment IDs in known fields of the core, WooCommerce, ACF and Yoast SEO,
	 * and numbers in fields named like an image.
	 *
	 * @since 1.0.0
	 * @param array $ids Sets collected from content.
	 * @return array{used: array<int, true>, maybe: array<int, true>, parents: array<int, true>}
	 */
	public static function collect_ids( array $ids = array() ): array {
		global $wpdb;

		$ids += array(
			'used'    => array(),
			'maybe'   => array(),
			'parents' => array(),
		);

		$add = static function ( $value, string $set = 'used' ) use ( &$ids ): void {
			foreach ( self::numbers( $value ) as $id ) {
				$ids[ $set ][ $id ] = true;
			}
		};

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- fixed keys, read only.
		$add( $wpdb->get_col( "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key IN ('_thumbnail_id', '_product_image_gallery', '_yoast_wpseo_opengraph-image-id', '_yoast_wpseo_twitter-image-id')" ) );
		$add( $wpdb->get_col( "SELECT meta_value FROM {$wpdb->termmeta} WHERE meta_key = 'thumbnail_id'" ) );

		foreach ( array( 'site_icon', 'site_logo', 'woocommerce_placeholder_image' ) as $name ) {
			$add( get_option( $name ) );
		}

		foreach ( array_unique( array( get_stylesheet(), get_template() ) ) as $slug ) {
			$mods = get_option( 'theme_mods_' . $slug, array() );
			$mods = is_array( $mods ) ? $mods : array();
			$add( $mods['custom_logo'] ?? 0 );
			$add( ( (array) ( $mods['header_image_data'] ?? array() ) )['attachment_id'] ?? 0 );
			$add( self::image_keyed( $mods ), 'maybe' );

			if ( 'random-uploaded-image' === ( $mods['header_image'] ?? '' ) ) {
				$add( $wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attachment_is_custom_header' AND meta_value = %s", $slug ) ) );
			}
		}

		foreach ( (array) get_option( 'widget_media_image', array() ) as $widget ) {
			$add( is_array( $widget ) ? ( $widget['attachment_id'] ?? 0 ) : 0 );
		}

		foreach ( (array) get_option( 'widget_media_gallery', array() ) as $widget ) {
			$add( is_array( $widget ) ? ( $widget['ids'] ?? array() ) : array() );
		}

		$social = (array) get_option( 'wpseo_social', array() );
		$titles = (array) get_option( 'wpseo_titles', array() );
		$add( array( $social['og_default_image_id'] ?? 0, $social['og_frontpage_image_id'] ?? 0, $titles['company_logo_id'] ?? 0, $titles['person_logo_id'] ?? 0, $titles['open_graph_frontpage_image_id'] ?? 0 ) );
		$add( self::keys_ending( get_option( 'wpseo_taxonomy_meta', array() ), 'image-id' ) );

		$acf = array();
		foreach ( $wpdb->get_results( "SELECT post_name, post_content FROM {$wpdb->posts} WHERE post_type = 'acf-field'", ARRAY_A ) as $field ) {
			$settings = maybe_unserialize( $field['post_content'] );
			if ( is_array( $settings ) && in_array( $settings['type'] ?? '', array( 'image', 'gallery', 'file' ), true ) ) {
				$acf[] = (string) $field['post_name'];
			}
		}

		if ( $acf ) {
			$in = implode( ',', array_fill( 0, count( $acf ), '%s' ) );
			foreach ( array( array( $wpdb->postmeta, 'post_id' ), array( $wpdb->termmeta, 'term_id' ), array( $wpdb->usermeta, 'user_id' ) ) as $meta ) {
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- placeholders built from the key count.
				$add( $wpdb->get_col( $wpdb->prepare( "SELECT v.meta_value FROM %i v INNER JOIN %i r ON r.%i = v.%i AND r.meta_key = CONCAT('_', v.meta_key) WHERE r.meta_value IN ({$in})", array_merge( array( $meta[0], $meta[0], $meta[1], $meta[1] ), $acf ) ) ) );
			}
			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- placeholders built from the key count.
			$add( $wpdb->get_col( $wpdb->prepare( "SELECT v.option_value FROM {$wpdb->options} v INNER JOIN {$wpdb->options} r ON r.option_name = CONCAT('_', v.option_name) WHERE r.option_value IN ({$in})", $acf ) ) );
		}

		$pattern = self::KEY_PATTERN;
		foreach ( array( $wpdb->postmeta, $wpdb->termmeta, $wpdb->usermeta ) as $table ) {
			$add( $wpdb->get_col( $wpdb->prepare( "SELECT meta_value FROM %i WHERE meta_value REGEXP '^[0-9]+$' AND meta_key REGEXP %s AND meta_key NOT IN ('_thumbnail_id', 'thumbnail_id')", $table, $pattern ) ), 'maybe' );
		}
		$add( $wpdb->get_col( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_value REGEXP '^[0-9]+$' AND option_name REGEXP %s", $pattern ) ), 'maybe' );
		// phpcs:enable

		return $ids;
	}

	/**
	 * Positive integers in a value: a number, a comma list, or an array of them.
	 *
	 * @param mixed $value Value.
	 * @return int[]
	 */
	private static function numbers( $value ): array {
		if ( is_array( $value ) ) {
			return array_merge( array(), ...array_map( array( __CLASS__, 'numbers' ), array_values( $value ) ) );
		}

		if ( is_string( $value ) && is_serialized( $value ) ) {
			return self::numbers( maybe_unserialize( $value ) );
		}

		if ( is_int( $value ) || ( is_string( $value ) && preg_match( '/^\s*\d+(\s*,\s*\d+)*\s*$/', $value ) ) ) {
			return array_filter( wp_parse_id_list( (string) $value ) );
		}

		return array();
	}

	/**
	 * Values of image-like keys anywhere in an array.
	 *
	 * @param mixed $data Array.
	 * @return array
	 */
	private static function image_keyed( $data ): array {
		$found = array();

		foreach ( is_array( $data ) ? $data : array() as $key => $value ) {
			if ( is_array( $value ) ) {
				$found = array_merge( $found, self::image_keyed( $value ) );
			} elseif ( preg_match( '/' . self::KEY_PATTERN . '/i', (string) $key ) && is_scalar( $value ) ) {
				$found[] = $value;
			}
		}

		return $found;
	}

	/**
	 * Values of keys ending with a suffix anywhere in an array.
	 *
	 * @param mixed  $data   Array.
	 * @param string $suffix Key suffix.
	 * @return array
	 */
	private static function keys_ending( $data, string $suffix ): array {
		$found = array();

		foreach ( is_array( $data ) ? $data : array() as $key => $value ) {
			if ( is_array( $value ) ) {
				$found = array_merge( $found, self::keys_ending( $value, $suffix ) );
			} elseif ( str_ends_with( (string) $key, $suffix ) ) {
				$found[] = $value;
			}
		}

		return $found;
	}

	/* ─── Attachments ───────────────────────────────────────────── */

	/**
	 * Check the next batch of image attachments.
	 *
	 * @param array $job Job state.
	 * @return bool True when all are checked.
	 */
	private static function check_unit( array &$job ): bool {
		global $wpdb;

		$ids = array_map( 'intval', $wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_mime_type LIKE 'image/%%' AND post_status <> 'trash' AND ID > %d ORDER BY ID ASC LIMIT %d", (int) $job['cursor'], self::BATCH ) ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders.LikeWildcardsInQuery -- fixed mime prefix.

		if ( ! $ids ) {
			return true;
		}

		$groups = MVweb_MDC_Cleaner::groups_for( $ids );

		foreach ( $ids as $id ) {
			$members = $groups[ $id ] ?? array( $id );
			$lead    = $members[0];
			++$job['processed'];
			$job['cursor'] = $id;

			foreach ( $members as $member ) {
				if ( 'trash' !== get_post_field( 'post_status', $member ) ) {
					$lead = $member;
					break;
				}
			}

			if ( $lead !== $id ) {
				continue;
			}

			$verdict = self::verdict( $members, $job['ids'] );

			foreach ( $members as $member ) {
				wp_cache_delete( $member, 'post_meta' );
				wp_cache_delete( $member, 'posts' );
			}

			if ( 'used' === $verdict['status'] ) {
				$job['stats']['used'] += count( $members );
				continue;
			}

			if ( 'skipped' === $verdict['status'] ) {
				$job['stats']['skipped'][ $verdict['reason'] ] = ( $job['stats']['skipped'][ $verdict['reason'] ] ?? 0 ) + count( $members );
				continue;
			}

			++$job['stats'][ $verdict['status'] ]['groups'];
			$job['stats'][ $verdict['status'] ]['bytes'] += $verdict['bytes'];
			$job['list'][ $id ]                           = array(
				'ids'    => $members,
				'status' => $verdict['status'],
				'reason' => $verdict['reason'],
				'bytes'  => $verdict['bytes'],
			);
		}

		return count( $ids ) < self::BATCH;
	}

	/**
	 * Verdict for one group: used, skipped, manual (check by hand) or unused.
	 *
	 * A reference to any member makes the whole group used, so references are
	 * checked for every member before any member is skipped.
	 *
	 * @since 1.0.0
	 * @param int[] $members Group member IDs.
	 * @param array $ids     Referenced ID sets.
	 * @return array{status: string, reason: string, bytes: int}
	 */
	public static function verdict( array $members, array $ids ): array {
		$result = static fn( string $status, string $reason = '', int $bytes = 0 ): array => array(
			'status' => $status,
			'reason' => $reason,
			'bytes'  => $bytes,
		);
		$items  = array_map( array( 'MVweb_MDC_Cleaner', 'load' ), $members );
		$files  = self::group_files( $items );
		$manual = '';

		foreach ( $items as $item ) {
			$parent = (int) get_post_field( 'post_parent', $item['id'] );

			if ( isset( $ids['used'][ $item['id'] ] ) || ( $parent && isset( $ids['parents'][ $parent ] ) ) ) {
				return $result( 'used' );
			}
		}

		foreach ( array_keys( $files ) as $name ) {
			if ( self::in_index( $name ) ) {
				return $result( 'used' );
			}
		}

		foreach ( $items as $item ) {
			$id   = $item['id'];
			$post = get_post( $id );

			if ( ! $post || strtotime( $post->post_date_gmt . ' UTC' ) > time() - self::MIN_AGE ) {
				return $result( 'skipped', 'too_new' );
			}

			if ( 'site-icon' === get_post_meta( $id, '_wp_attachment_context', true ) ) {
				return $result( 'skipped', 'site_icon' );
			}

			if ( metadata_exists( 'post', $id, MVweb_MDC_Cleaner::PENDING_META ) || metadata_exists( 'post', $id, MVweb_MDC_Converter::JOURNAL ) ) {
				return $result( 'skipped', 'busy' );
			}

			if ( mvweb_mdc_is_offloaded( $id ) ) {
				return $result( 'skipped', 'offloaded' );
			}

			if ( '' === $manual ) {
				if ( ! is_array( $item['meta'] ) || empty( $item['meta']['file'] ) ) {
					$manual = 'bad_meta';
				} elseif ( isset( $ids['maybe'][ $id ] ) ) {
					$manual = 'id_match';
				} elseif ( metadata_exists( 'post', $id, '_wp_attachment_is_custom_header' ) || metadata_exists( 'post', $id, '_wp_attachment_is_custom_background' ) ) {
					$manual = 'header';
				} elseif ( $post->post_parent && 'publish' === get_post_status( $post->post_parent ) ) {
					$manual = 'attached';
				}
			}
		}

		$bytes = (int) array_sum( $files );

		return '' !== $manual ? $result( 'manual', $manual, $bytes ) : $result( 'unused', '', $bytes );
	}

	/**
	 * Every file of a group: name => bytes on disk (0 when missing).
	 *
	 * @param array[] $items Loaded group members.
	 * @return array<string, int>
	 */
	private static function group_files( array $items ): array {
		$names = array();
		$dir   = '';

		foreach ( $items as $item ) {
			$meta  = is_array( $item['meta'] ) ? $item['meta'] : array();
			$names = array_merge( $names, array_keys( MVweb_MDC_Cleaner::base_protected( array( $item ) ) ), MVweb_MDC_Cleaner::collect_files( $meta['sizes'] ?? array() ) );

			if ( '' === $dir && '' !== $item['file'] ) {
				$dir = dirname( $item['file'] );
			}
		}

		$files = array();

		foreach ( array_unique( array_filter( $names ) ) as $name ) {
			foreach ( array( $name, $name . '.webp', $name . '.avif' ) as $file ) {
				$path           = $dir . '/' . $file;
				$files[ $file ] = '' !== $dir && is_file( $path ) ? (int) filesize( $path ) : 0;
			}
		}

		return array_filter( $files, static fn( int $bytes, string $file ): bool => $bytes > 0 || in_array( $file, $names, true ), ARRAY_FILTER_USE_BOTH );
	}

	/* ─── Trash, restore, purge ─────────────────────────────────── */

	/**
	 * Why the trash cannot be used now, or an empty string.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function trash_blocker(): string {
		if ( ! EMPTY_TRASH_DAYS ) {
			return __( 'The trash is turned off on this site (EMPTY_TRASH_DAYS is 0): moving to the trash would delete at once. Turn the trash on to use this tab.', 'mvweb-media-control' );
		}

		if ( MVweb_MDC_Cleaner::is_running() || MVweb_MDC_Converter::is_active() || self::is_running() ) {
			return __( 'A cleanup, conversion or scan task is in progress. Finish it first.', 'mvweb-media-control' );
		}

		$report = self::report();

		if ( empty( $report['at'] ) || (int) $report['at'] < time() - self::REPORT_TTL ) {
			return __( 'The report is older than an hour. Scan again before moving images to the trash.', 'mvweb-media-control' );
		}

		return '';
	}

	/**
	 * Move report groups to the trash.
	 *
	 * Each group is checked again: the same members, not in the trash, and no new
	 * reference from posts changed since the scan or from the known ID fields.
	 *
	 * @since 1.0.0
	 * @param int[] $leaders Group leader IDs from the report.
	 * @return array{done: int, kept: int, failed: int}|WP_Error
	 */
	public static function trash( array $leaders ) {
		$blocker = self::trash_blocker();

		if ( '' !== $blocker ) {
			return new WP_Error( 'mvweb_mdc_trash', $blocker );
		}

		$report = self::report();
		$fresh  = self::fresh_refs( (int) $report['at'] );
		$result = array(
			'done'   => 0,
			'kept'   => 0,
			'failed' => 0,
		);

		foreach ( array_unique( array_map( 'intval', $leaders ) ) as $leader ) {
			$entry = $report['list'][ $leader ] ?? null;

			if ( ! $entry ) {
				continue;
			}

			$members = MVweb_MDC_Cleaner::groups_for( array( $leader ) )[ $leader ] ?? array( $leader );
			$names   = array_keys( self::group_files( array_map( array( 'MVweb_MDC_Cleaner', 'load' ), $members ) ) );

			if ( $members !== $entry['ids'] || array_intersect_key( array_flip( $members ), $fresh['ids'] ) || array_intersect_key( array_flip( $names ), $fresh['names'] ) || in_array( 'trash', array_map( static fn( int $id ): string => (string) get_post_field( 'post_status', $id ), $members ), true ) ) {
				++$result['kept'];
			} elseif ( self::trash_group( $members ) ) {
				++$result['done'];
			} else {
				++$result['failed'];
			}

			unset( $report['list'][ $leader ] );
		}

		update_option( self::REPORT_OPTION, $report, false );

		return $result;
	}

	/**
	 * Trash every member of a group, or none of them.
	 *
	 * @param int[] $members Member IDs.
	 * @return bool
	 */
	private static function trash_group( array $members ): bool {
		$done = array();

		foreach ( $members as $id ) {
			if ( ! wp_trash_post( $id ) ) {
				foreach ( $done as $back ) {
					wp_untrash_post( $back );
					delete_post_meta( $back, self::TRASHED_META );
				}
				return false;
			}

			update_post_meta( $id, self::TRASHED_META, time() );
			$done[] = $id;
		}

		return true;
	}

	/**
	 * References added since the scan: names and IDs in posts changed after it,
	 * and the known ID fields read again. Cached for a few minutes.
	 *
	 * @param int $since Scan time.
	 * @return array{names: array<string, true>, ids: array<int, true>}
	 */
	private static function fresh_refs( int $since ): array {
		global $wpdb;

		$cached = get_transient( self::IDS_TRANSIENT );

		if ( is_array( $cached ) && ( $cached['since'] ?? 0 ) === $since ) {
			return $cached;
		}

		$ids   = self::collect_ids();
		$from  = gmdate( 'Y-m-d H:i:s', max( 0, $since - MINUTE_IN_SECONDS ) );
		$posts = $wpdb->get_results( $wpdb->prepare( "SELECT ID, post_content, post_excerpt FROM {$wpdb->posts} WHERE post_type <> 'attachment' AND (post_modified_gmt >= %s OR post_modified >= %s)", $from, get_date_from_gmt( $from ) ), ARRAY_A ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		self::$buffer = array();

		foreach ( $posts as $post ) {
			self::collect_names( (string) $post['post_content'] . ' ' . (string) $post['post_excerpt'] );
			$ids = self::content_ids( (string) $post['post_content'], (int) $post['ID'], $ids );

			foreach ( (array) get_post_meta( (int) $post['ID'] ) as $key => $values ) {
				if ( '_wp_attached_file' !== $key ) {
					self::collect_names( implode( ' ', array_map( 'strval', (array) $values ) ) );
				}
			}
		}

		$fresh        = array(
			'since' => $since,
			'names' => self::$buffer,
			'ids'   => $ids['used'],
		);
		self::$buffer = array();

		foreach ( array_keys( $ids['parents'] ) as $parent ) {
			foreach ( get_children(
				array(
					'post_parent' => $parent,
					'post_type'   => 'attachment',
					'fields'      => 'ids',
					'post_status' => 'any',
				)
			) as $child ) {
				$fresh['ids'][ (int) $child ] = true;
			}
		}

		set_transient( self::IDS_TRANSIENT, $fresh, 5 * MINUTE_IN_SECONDS );

		return $fresh;
	}

	/**
	 * Groups of trashed attachments this plugin moved: leader => members.
	 *
	 * @since 1.0.0
	 * @return array<int, int[]>
	 */
	public static function trashed_groups(): array {
		$ids = get_posts(
			array(
				'post_type'      => 'attachment',
				'post_status'    => 'trash',
				'meta_key'       => self::TRASHED_META, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- small set, plugin's own marker.
				'fields'         => 'ids',
				'posts_per_page' => -1,
				'orderby'        => 'ID',
				'order'          => 'ASC',
			)
		);

		$groups = array();

		foreach ( MVweb_MDC_Cleaner::groups_for( array_map( 'intval', $ids ) ) as $members ) {
			$groups[ $members[0] ] = $members;
		}

		return $groups;
	}

	/**
	 * When the core trash cron may delete a trashed group for good.
	 *
	 * @since 1.0.0
	 * @param int $id Attachment ID.
	 * @return int Unix time.
	 */
	public static function delete_after( int $id ): int {
		$trashed = (int) get_post_meta( $id, '_wp_trash_meta_time', true );
		$marked  = (int) get_post_meta( $id, self::TRASHED_META, true );

		return max( $trashed + EMPTY_TRASH_DAYS * DAY_IN_SECONDS, $marked + self::HOLD );
	}

	/**
	 * Restore trashed groups.
	 *
	 * @since 1.0.0
	 * @param int[] $leaders Group leader IDs.
	 * @return array{done: int, failed: int}
	 */
	public static function restore( array $leaders ): array {
		$groups = self::trashed_groups();
		$result = array(
			'done'   => 0,
			'failed' => 0,
		);

		foreach ( array_unique( array_map( 'intval', $leaders ) ) as $leader ) {
			if ( ! isset( $groups[ $leader ] ) ) {
				continue;
			}

			$ok = true;
			foreach ( $groups[ $leader ] as $id ) {
				if ( 'trash' === get_post_field( 'post_status', $id ) && ! wp_untrash_post( $id ) ) {
					$ok = false;
					continue;
				}
				delete_post_meta( $id, self::TRASHED_META );
			}

			++$result[ $ok ? 'done' : 'failed' ];
		}

		return $result;
	}

	/**
	 * Delete trashed groups for good, with all their files.
	 *
	 * @since 1.0.0
	 * @param int[] $leaders Group leader IDs.
	 * @return array{done: int, failed: int, bytes: int}
	 */
	public static function purge( array $leaders ): array {
		$groups = self::trashed_groups();
		$result = array(
			'done'   => 0,
			'failed' => 0,
			'bytes'  => 0,
		);

		self::$purging = true;

		foreach ( array_unique( array_map( 'intval', $leaders ) ) as $leader ) {
			$members = $groups[ $leader ] ?? array();

			if ( ! $members || in_array( false, array_map( static fn( int $id ): bool => 'trash' === get_post_field( 'post_status', $id ), $members ), true ) ) {
				continue;
			}

			$bytes = (int) array_sum( self::group_files( array_map( array( 'MVweb_MDC_Cleaner', 'load' ), $members ) ) );
			$ok    = true;

			foreach ( $members as $id ) {
				$ok = (bool) wp_delete_attachment( $id, true ) && $ok;
			}

			++$result[ $ok ? 'done' : 'failed' ];
			$result['bytes'] += $ok ? $bytes : 0;
		}

		self::$purging = false;

		return $result;
	}

	/**
	 * Hold back the core trash cron for attachments this plugin trashed.
	 *
	 * Keeps them for the full hold even when EMPTY_TRASH_DAYS is shorter, never
	 * deletes one of a group while another member is out of the trash (they share
	 * the main file), and puts the group back when content links to its main
	 * file again.
	 *
	 * @since 1.0.0
	 * @param mixed   $delete Short-circuit value.
	 * @param WP_Post $post   Attachment.
	 * @return mixed
	 */
	public static function guard_delete( $delete, $post ) {
		global $wpdb;

		if ( null !== $delete || self::$purging || ! $post instanceof WP_Post ) {
			return $delete;
		}

		$marked = (int) get_post_meta( $post->ID, self::TRASHED_META, true );

		if ( ! $marked ) {
			return $delete;
		}

		if ( $marked > time() - self::HOLD ) {
			return false;
		}

		$members = MVweb_MDC_Cleaner::groups_for( array( $post->ID ) )[ $post->ID ] ?? array( $post->ID );

		if ( in_array( false, array_map( static fn( int $id ): bool => 'trash' === get_post_field( 'post_status', $id ), $members ), true ) ) {
			return false;
		}

		$name = wp_basename( (string) get_post_meta( $post->ID, '_wp_attached_file', true ) );
		$like = '%' . $wpdb->esc_like( $name ) . '%';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery -- one check per deleted attachment.
		$linked = '' !== $name && (
			$wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$wpdb->posts} WHERE post_type NOT IN ('attachment', 'revision') AND post_status <> 'trash' AND post_content LIKE %s LIMIT 1", $like ) )
			|| $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$wpdb->postmeta} WHERE meta_key NOT IN ('_wp_attached_file', '_wp_attachment_metadata') AND meta_value LIKE %s LIMIT 1", $like ) )
		);
		// phpcs:enable

		if ( $linked ) {
			self::restore( array( $members[0] ) );
			return false;
		}

		return $delete;
	}

	/**
	 * Rows of one report group for CSV export and WP-CLI.
	 *
	 * @since 1.0.0
	 * @param string $status 'unused' or 'manual'.
	 * @return array[]
	 */
	public static function rows( string $status ): array {
		$rows = array();

		foreach ( self::report()['list'] ?? array() as $leader => $entry ) {
			if ( $status !== $entry['status'] ) {
				continue;
			}

			$rows[] = array(
				'id'     => (int) $leader,
				'ids'    => implode( ' ', array_map( 'intval', $entry['ids'] ) ),
				'file'   => (string) get_post_meta( (int) $leader, '_wp_attached_file', true ),
				'date'   => (string) get_post_field( 'post_date', (int) $leader ),
				'bytes'  => (int) $entry['bytes'],
				'parent' => (int) get_post_field( 'post_parent', (int) $leader ),
				'reason' => (string) $entry['reason'],
			);
		}

		usort( $rows, static fn( array $a, array $b ): int => $b['bytes'] <=> $a['bytes'] );

		return $rows;
	}
}
