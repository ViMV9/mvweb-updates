<?php
/**
 * Admin page: menu, assets, settings.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin controller.
 *
 * @since 1.0.0
 */
final class MVweb_MDC_Admin {

	const PAGE = 'mvweb-media-control';

	const OPTION_GROUP = 'mvweb_mdc_settings_group';

	/**
	 * Register hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'wp_ajax_mvweb_mdc_job', array( __CLASS__, 'ajax_job' ) );
		add_action( 'wp_ajax_mvweb_mdc_convert', array( __CLASS__, 'ajax_convert' ) );
		add_action( 'wp_ajax_mvweb_mdc_unused', array( __CLASS__, 'ajax_unused' ) );
		add_action( 'admin_post_mvweb_mdc_unused_csv', array( __CLASS__, 'unused_csv' ) );
		add_action( 'admin_notices', array( __CLASS__, 'theme_notice' ) );
		add_action( 'admin_notices', array( __CLASS__, 'convert_notice' ) );
	}

	/**
	 * Tell that conversion has finished and old files wait for the final step.
	 *
	 * Not shown on the plugin page itself: the Conversion tab says it.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function convert_notice(): void {
		$screen = get_current_screen();

		if ( 'ready' !== MVweb_MDC_Converter::status() || ! current_user_can( 'manage_options' ) || ( $screen && str_contains( (string) $screen->id, self::PAGE ) ) ) {
			return;
		}

		printf(
			'<div class="notice notice-info"><p>%1$s <a href="%2$s">%3$s</a></p></div>',
			esc_html__( 'MVweb Media Control: images are converted to WebP. Purge the page cache and CDN, then delete the old files.', 'mvweb-media-control' ),
			esc_url( admin_url( 'admin.php?page=' . self::PAGE . '&tab=convert' ) ),
			esc_html__( 'Open', 'mvweb-media-control' )
		);
	}

	/**
	 * AJAX: conversion estimate, start, pause, resume, final step and undo.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_convert(): void {
		check_ajax_referer( 'mvweb_mdc_job' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have sufficient permissions to access this page.', 'mvweb-media-control' ) ), 403 );
		}

		$do     = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$limit  = (int) ini_get( 'max_execution_time' );
		$budget = $limit > 0 ? min( 15, max( 1, $limit - 10 ) ) : 15;
		$job    = null;

		switch ( $do ) {
			case 'estimate':
				MVweb_MDC_Converter::estimate( microtime( true ) + $budget );
				break;

			case 'start':
				if ( empty( $_POST['backup'] ) ) {
					wp_send_json_error( array( 'message' => __( 'Confirm that a backup of uploads and the database exists.', 'mvweb-media-control' ) ) );
				}
				$job = MVweb_MDC_Converter::start(
					isset( $_POST['period'] ) ? sanitize_key( wp_unslash( $_POST['period'] ) ) : '',
					! empty( $_POST['originals'] ),
					! empty( $_POST['png'] )
				);
				break;

			case 'pause':
				MVweb_MDC_Converter::pause();
				break;

			case 'resume':
				MVweb_MDC_Converter::resume();
				break;

			case 'delete':
			case 'undo':
				if ( 'delete' === $do && empty( $_POST['backup'] ) ) {
					wp_send_json_error( array( 'message' => __( 'Confirm that a backup of uploads and the database exists.', 'mvweb-media-control' ) ) );
				}
				$job = MVweb_MDC_Converter::begin( $do );
				if ( ! is_wp_error( $job ) ) {
					$job = MVweb_MDC_Converter::step( microtime( true ) + $budget );
				}
				break;

			case 'step':
				$job = MVweb_MDC_Converter::step( microtime( true ) + $budget );
				break;

			default:
				wp_send_json_error( array( 'message' => __( 'Unknown action.', 'mvweb-media-control' ) ) );
		}

		if ( is_wp_error( $job ) ) {
			wp_send_json_error( array( 'message' => $job->get_error_message() ) );
		}

		$job = MVweb_MDC_Converter::get_job();

		wp_send_json_success(
			array(
				'status'    => (string) ( $job['status'] ?? '' ),
				'phase'     => $job['phases'][ $job['phase'] ?? 0 ] ?? '',
				'processed' => (int) ( $job['processed'] ?? 0 ),
				'total'     => (int) ( $job['total'] ?? 0 ),
			)
		);
	}

	/**
	 * AJAX: unused images scan, trash, restore and purge.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_unused(): void {
		check_ajax_referer( 'mvweb_mdc_job' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have sufficient permissions to access this page.', 'mvweb-media-control' ) ), 403 );
		}

		$do     = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$ids    = isset( $_POST['ids'] ) && is_array( $_POST['ids'] ) ? array_map( 'absint', wp_unslash( $_POST['ids'] ) ) : array();
		$limit  = (int) ini_get( 'max_execution_time' );
		$budget = $limit > 0 ? min( 15, max( 1, $limit - 10 ) ) : 15;

		switch ( $do ) {
			case 'scan':
				$job = MVweb_MDC_Unused::start();
				if ( ! is_wp_error( $job ) ) {
					$job = MVweb_MDC_Unused::step( microtime( true ) + $budget );
				}
				break;

			case 'step':
				$job = MVweb_MDC_Unused::step( microtime( true ) + $budget );
				break;

			case 'cancel':
				MVweb_MDC_Unused::cancel();
				$job = MVweb_MDC_Unused::get_job();
				break;

			case 'trash':
				$result = MVweb_MDC_Unused::trash( $ids );
				if ( is_wp_error( $result ) ) {
					wp_send_json_error( array( 'message' => $result->get_error_message() ) );
				}
				wp_send_json_success( $result );
				break;

			case 'restore':
				wp_send_json_success( MVweb_MDC_Unused::restore( $ids ) );
				break;

			case 'purge':
				if ( empty( $_POST['backup'] ) ) {
					wp_send_json_error( array( 'message' => __( 'Confirm that a backup of uploads and the database exists.', 'mvweb-media-control' ) ) );
				}
				wp_send_json_success( MVweb_MDC_Unused::purge( $ids ) );
				break;

			default:
				wp_send_json_error( array( 'message' => __( 'Unknown action.', 'mvweb-media-control' ) ) );
		}

		if ( is_wp_error( $job ) ) {
			wp_send_json_error( array( 'message' => $job->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				'phase'     => (string) ( $job['phase'] ?? '' ),
				'processed' => (int) ( $job['processed'] ?? 0 ),
				'total'     => (int) ( $job['total'] ?? 0 ),
				'finished'  => ! empty( $job['finished'] ),
				'error'     => (string) ( $job['error'] ?? '' ),
			)
		);
	}

	/**
	 * Download one group of the unused images report as CSV.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function unused_csv(): void {
		check_admin_referer( 'mvweb_mdc_unused_csv' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'mvweb-media-control' ) );
		}

		$status  = isset( $_GET['group'] ) && 'manual' === $_GET['group'] ? 'manual' : 'unused';
		$uploads = wp_get_upload_dir()['baseurl'];

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=unused-images-' . $status . '-' . gmdate( 'Y-m-d' ) . '.csv' );

		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- stream to the browser.
		fputcsv( $out, array( 'id', 'group_ids', 'url', 'uploaded', 'bytes', 'attached_to', 'reason' ) );

		foreach ( MVweb_MDC_Unused::rows( $status ) as $row ) {
			fputcsv( $out, array( $row['id'], $row['ids'], $uploads . '/' . $row['file'], $row['date'], $row['bytes'], $row['parent'] ? get_permalink( $row['parent'] ) : '', $row['reason'] ) );
		}

		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- stream to the browser.
		exit;
	}

	/**
	 * Warn after a theme switch that disabled sizes may be needed by the new theme.
	 *
	 * Not shown on the plugin page itself: the Uploads tab shows its own note.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function theme_notice(): void {
		$theme  = (string) get_option( MVweb_MDC_Uploads::THEME_NOTICE, '' );
		$screen = get_current_screen();

		if ( '' === $theme || ! current_user_can( 'manage_options' ) || ( $screen && str_contains( (string) $screen->id, self::PAGE ) ) ) {
			return;
		}

		printf(
			'<div class="notice notice-warning"><p>%1$s <a href="%2$s">%3$s</a></p></div>',
			esc_html(
				sprintf(
					/* translators: %s: theme name */
					__( 'The theme was switched to %s. MVweb Media Control keeps disabled image sizes by name: check that the new theme does not need any of them.', 'mvweb-media-control' ),
					$theme
				)
			),
			esc_url( admin_url( 'admin.php?page=' . self::PAGE ) ),
			esc_html__( 'Check sizes', 'mvweb-media-control' )
		);
	}

	/**
	 * AJAX: start, advance or cancel a cleanup task.
	 *
	 * Uses admin-ajax rather than REST: security plugins often close REST.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_job(): void {
		check_ajax_referer( 'mvweb_mdc_job' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have sufficient permissions to access this page.', 'mvweb-media-control' ) ), 403 );
		}

		$do     = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$limit  = (int) ini_get( 'max_execution_time' );
		$budget = $limit > 0 ? min( 15, max( 1, $limit - 10 ) ) : 15;

		if ( 'sources' === $do ) {
			$before = MVweb_MDC_Sources::cached();
			$after  = MVweb_MDC_Sources::get( mvweb_mdc_allowed_size_names() );

			if ( null !== $before && $before['hash'] === $after['hash'] ) {
				wp_send_json_success( array( 'changed' => false ) );
			}

			ob_start();
			self::render_sizes( $after );
			wp_send_json_success(
				array(
					'changed' => true,
					'html'    => ob_get_clean(),
				)
			);
		}

		if ( 'where' === $do ) {
			$file   = isset( $_POST['file'] ) ? (string) wp_unslash( $_POST['file'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- compared strictly against the link index in where_used().
			$places = MVweb_MDC_Cleaner::where_used( $file );

			if ( null === $places ) {
				wp_send_json_error( array( 'message' => __( 'The file is not in the link index. Scan again.', 'mvweb-media-control' ) ) );
			}

			wp_send_json_success(
				array(
					'places' => array_map(
						static function ( array $place ): array {
							return array(
								'label' => $place['label'],
								'url'   => esc_url_raw( $place['url'] ),
							);
						},
						$places
					),
				)
			);
		}

		if ( 'originals' === $do ) {
			$after = isset( $_POST['cursor'] ) ? absint( $_POST['cursor'] ) : 0;
			wp_send_json_success( MVweb_MDC_Uploads::complete_originals( $after, microtime( true ) + $budget ) );
		}

		if ( 'start' === $do ) {
			$action = isset( $_POST['task'] ) ? sanitize_key( wp_unslash( $_POST['task'] ) ) : '';
			$sizes  = isset( $_POST['sizes'] ) && is_array( $_POST['sizes'] ) ? array_map( 'strval', wp_unslash( $_POST['sizes'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- compared strictly against the size whitelist in start().

			if ( 'apply' === $action && empty( $_POST['backup'] ) ) {
				wp_send_json_error( array( 'message' => __( 'Confirm that a backup of uploads and the database exists.', 'mvweb-media-control' ) ) );
			}

			$job = MVweb_MDC_Cleaner::start( $action, $sizes );
		} elseif ( 'cancel' === $do ) {
			MVweb_MDC_Cleaner::cancel();
			$job = MVweb_MDC_Cleaner::get_job();
		} else {
			$job = MVweb_MDC_Cleaner::get_job();
		}

		if ( ! is_wp_error( $job ) && 'cancel' !== $do ) {
			$job = MVweb_MDC_Cleaner::step( microtime( true ) + $budget );
		}

		if ( is_wp_error( $job ) ) {
			wp_send_json_error( array( 'message' => $job->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				'action'    => $job['action'] ?? '',
				'phase'     => $job['phases'][ $job['phase'] ?? 0 ] ?? '',
				'processed' => (int) ( $job['processed'] ?? 0 ),
				'total'     => (int) ( $job['total'] ?? 0 ),
				'finished'  => ! empty( $job['finished'] ),
				'error'     => (string) ( $job['error'] ?? '' ),
			)
		);
	}

	/**
	 * Add the submenu page under MVweb Hub.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_menu(): void {
		$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

		add_submenu_page(
			$parent_slug,
			__( 'MVweb Media Control', 'mvweb-media-control' ),
			__( 'Media Control', 'mvweb-media-control' ),
			'manage_options',
			self::PAGE,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Render the settings page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'mvweb-media-control' ) );
		}

		require MVWEB_MDC_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Render the image sizes table.
	 *
	 * @since 1.0.0
	 * @param array|null $mvweb_mdc_sources Sources, or null before the first scan.
	 * @return void
	 */
	public static function render_sizes( ?array $mvweb_mdc_sources ): void { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found -- read by the template.
		require MVWEB_MDC_PATH . 'admin/views/partial-sizes.php';
	}

	/**
	 * Register the settings option.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_settings(): void {
		register_setting(
			self::OPTION_GROUP,
			'mvweb_mdc_settings',
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
				'default'           => array(),
			)
		);
	}

	/**
	 * Sanitize settings from the form.
	 *
	 * @since 1.0.0
	 * @param mixed $input Raw input.
	 * @return array
	 */
	public static function sanitize_settings( $input ): array {
		if ( MVweb_MDC_Cleaner::is_running() ) {
			add_settings_error( 'mvweb_mdc_settings', 'mvweb_mdc_running', __( 'Settings are locked while a cleanup task is in progress.', 'mvweb-media-control' ) );
			return mvweb_mdc_get_settings();
		}

		if ( in_array( MVweb_MDC_Converter::status(), array( 'running', 'working' ), true ) ) {
			add_settings_error( 'mvweb_mdc_settings', 'mvweb_mdc_converting', __( 'Settings are locked while conversion is running: new metadata is built from the enabled sizes. Pause conversion to change them.', 'mvweb-media-control' ) );
			return mvweb_mdc_get_settings();
		}

		$input = is_array( $input ) ? $input : array();

		$convert = ! empty( $input['convert_webp'] ) && mvweb_mdc_can_write_webp();

		$allowed  = mvweb_mdc_allowed_size_names();
		$disabled = array();
		foreach ( (array) ( $input['disabled_sizes'] ?? array() ) as $name ) {
			if ( is_string( $name ) && in_array( $name, $allowed, true ) ) {
				$disabled[] = $name;
			}
		}

		$quality = (int) ( $input['webp_quality'] ?? 0 );

		return array(
			'convert_webp'     => $convert,
			'delete_originals' => $convert && ! empty( $input['delete_originals'] ),
			'webp_quality'     => isset( mvweb_mdc_webp_qualities()[ $quality ] ) ? $quality : MVweb_MDC_Uploads::WEBP_QUALITY,
			'disabled_sizes'   => array_values( array_unique( $disabled ) ),
		);
	}

	/**
	 * Enqueue admin assets on the plugin page only.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue( $hook ): void {
		if ( false === strpos( (string) $hook, self::PAGE ) ) {
			return;
		}

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		$ver = static function ( string $relative_path ): string {
			$mtime = @filemtime( MVWEB_MDC_PATH . $relative_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- missing file falls back to plugin version.
			return $mtime ? (string) $mtime : MVWEB_MDC_VERSION;
		};

		wp_enqueue_style( 'mvweb-mdc-admin', MVWEB_MDC_URL . 'admin/css/admin' . $suffix . '.css', array(), $ver( 'admin/css/admin' . $suffix . '.css' ) );
		wp_enqueue_style( 'mvweb-mdc-plugin', MVWEB_MDC_URL . 'admin/css/plugin' . $suffix . '.css', array( 'mvweb-mdc-admin' ), $ver( 'admin/css/plugin' . $suffix . '.css' ) );
		wp_enqueue_script( 'mvweb-mdc-admin', MVWEB_MDC_URL . 'admin/js/admin' . $suffix . '.js', array(), $ver( 'admin/js/admin' . $suffix . '.js' ), true );
		wp_localize_script(
			'mvweb-mdc-admin',
			'mvwebMdc',
			array(
				'ajaxUrl'       => admin_url( 'admin-ajax.php' ),
				'nonce'         => wp_create_nonce( 'mvweb_mdc_job' ),
				'doneUrl'       => admin_url( 'admin.php?page=' . self::PAGE . '&tab=cleanup' ),
				'phases'        => array(
					'index'   => __( 'Indexing links in content', 'mvweb-media-control' ),
					'scan'    => __( 'Scanning attachments', 'mvweb-media-control' ),
					'apply'   => __( 'Removing sizes from metadata', 'mvweb-media-control' ),
					'delete'  => __( 'Deleting files', 'mvweb-media-control' ),
					'undo'    => __( 'Returning sizes to metadata', 'mvweb-media-control' ),
					'restore' => __( 'Regenerating sizes', 'mvweb-media-control' ),
				),
				'paused'        => __( 'Paused. Press Continue to resume.', 'mvweb-media-control' ),
				'failed'        => __( 'Request failed. Press Continue to retry.', 'mvweb-media-control' ),
				/* translators: 1: originals deleted, 2: originals still kept */
				'originalsDone' => __( 'Deleted: %1$d, still kept: %2$d', 'mvweb-media-control' ),
				/* translators: %d: number of sizes */
				'marked'        => __( 'Marked: %d. Press Save Changes to apply.', 'mvweb-media-control' ),
				'whereNone'     => __( 'Not found by a direct search: the link is stored in an encoded form. The file is still kept.', 'mvweb-media-control' ),
				'whereFailed'   => __( 'Request failed. Try again.', 'mvweb-media-control' ),
				'confirmB'      => __( 'Delete the files now? Make sure the page cache and CDN are purged. This cannot be undone.', 'mvweb-media-control' ),
				'convertUrl'    => admin_url( 'admin.php?page=' . self::PAGE . '&tab=convert' ),
				'convertPhases' => array(
					'index'  => __( 'Indexing links in content', 'mvweb-media-control' ),
					'links'  => __( 'Replacing links', 'mvweb-media-control' ),
					'delete' => __( 'Deleting old files', 'mvweb-media-control' ),
					'undo'   => __( 'Undoing conversion', 'mvweb-media-control' ),
				),
				'confirmOld'    => __( 'Delete the old files now? Make sure the page cache and CDN are purged. This cannot be undone.', 'mvweb-media-control' ),
				'confirmUndo'   => __( 'Undo the conversion? Links are put back, WebP files are deleted, the old files stay.', 'mvweb-media-control' ),
				'unusedUrl'     => admin_url( 'admin.php?page=' . self::PAGE . '&tab=unused' ),
				'unusedPhases'  => array(
					'index' => __( 'Reading the database', 'mvweb-media-control' ),
					'theme' => __( 'Reading the theme code', 'mvweb-media-control' ),
					'ids'   => __( 'Reading image fields', 'mvweb-media-control' ),
					'check' => __( 'Checking images', 'mvweb-media-control' ),
				),
				/* translators: 1: groups done, 2: groups selected */
				'unusedDone'    => __( 'Done: %1$d of %2$d', 'mvweb-media-control' ),
				'confirmTrash'  => __( 'Move the selected images to the trash? Their files stay on disk for 30 days, then the site deletes them. Until then they can be restored.', 'mvweb-media-control' ),
				'confirmPurge'  => __( 'Delete the selected images and all their files now? This cannot be undone.', 'mvweb-media-control' ),
				'noneSelected'  => __( 'Select at least one image.', 'mvweb-media-control' ),
			)
		);
	}
}
