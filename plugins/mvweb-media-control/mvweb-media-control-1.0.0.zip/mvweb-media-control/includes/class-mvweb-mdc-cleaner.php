<?php
/**
 * Cleanup of generated image sizes: link index, scan, step A, step B, undo, restore.
 *
 * Shared by the admin AJAX loop and WP-CLI. Work is split into slices bounded
 * by a deadline; the job state lives in a non-autoloaded option.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cleanup engine.
 *
 * @since 1.0.0
 */
final class MVweb_MDC_Cleaner {

	const JOB_OPTION = 'mvweb_mdc_job';

	const REPORT_OPTION = 'mvweb_mdc_report';

	const INDEX_OPTION = 'mvweb_mdc_index';

	const LOCK_OPTION = 'mvweb_mdc_lock';

	const INDEX_PREFIX = 'mdc_idx_';

	const PENDING_META = '_mvweb_mdc_pending';

	const ACTIONS = array( 'scan', 'apply', 'delete', 'undo', 'restore' );

	const BATCH = 50;

	const INDEX_ROWS = 200;

	const INDEX_FLUSH = 5000;

	const LOCK_TTL = 300;

	const MIN_AGE = HOUR_IN_SECONDS;

	const LINKED_MAX = 50;

	const IMAGE_EXT = 'jpe?g|jpe|png|gif|webp|avif|heic|heif|bmp|tiff?';

	/**
	 * Index names collected in this request and not yet stored.
	 *
	 * @var array<string, true>
	 */
	private static array $buffer = array();

	/**
	 * Loaded link index.
	 *
	 * @var array<string, true>|null
	 */
	private static ?array $index = null;

	/**
	 * Editor support per mime type.
	 *
	 * @var array<string, bool>
	 */
	private static array $editor_support = array();

	/**
	 * Whether this request holds the lock.
	 *
	 * @var bool
	 */
	private static bool $held = false;

	/**
	 * Register hooks that must run outside the job.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'delete_attachment', array( __CLASS__, 'on_delete_attachment' ) );
	}

	/* ─── Job lifecycle ─────────────────────────────────────────── */

	/**
	 * Current job state.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function get_job(): array {
		$job = get_option( self::JOB_OPTION, array() );
		return is_array( $job ) ? $job : array();
	}

	/**
	 * Whether a job is started and not finished.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function is_running(): bool {
		$job = self::get_job();
		return ! empty( $job['action'] ) && empty( $job['finished'] );
	}

	/**
	 * Start a job.
	 *
	 * @since 1.0.0
	 * @param string   $action One of self::ACTIONS.
	 * @param string[] $sizes  Size names for apply and restore.
	 * @return array|WP_Error Job state.
	 */
	public static function start( string $action, array $sizes = array() ) {
		if ( ! self::lock() ) {
			return new WP_Error( 'mvweb_mdc_locked', __( 'The task is already running in another tab or process.', 'mvweb-media-control' ) );
		}

		$job = self::create( $action, $sizes );
		self::unlock();

		return $job;
	}

	/**
	 * Validate the request and store a new job. Runs under the lock.
	 *
	 * @param string   $action Action.
	 * @param string[] $sizes  Size names.
	 * @return array|WP_Error Job state.
	 */
	private static function create( string $action, array $sizes ) {
		if ( ! in_array( $action, self::ACTIONS, true ) ) {
			return new WP_Error( 'mvweb_mdc_action', __( 'Unknown action.', 'mvweb-media-control' ) );
		}

		if ( self::is_running() ) {
			return new WP_Error( 'mvweb_mdc_running', __( 'Another task is in progress. Continue or cancel it first.', 'mvweb-media-control' ) );
		}

		if ( MVweb_MDC_Converter::is_active() ) {
			return new WP_Error( 'mvweb_mdc_converting', __( 'Conversion to WebP is in progress. Finish it on the Conversion tab first.', 'mvweb-media-control' ) );
		}

		$sizes = array_values( array_unique( array_filter( $sizes, 'is_string' ) ) );

		if ( 'apply' === $action ) {
			$sizes = array_values( array_intersect( $sizes, self::selectable_sizes() ) );
		} elseif ( 'restore' === $action ) {
			$sizes = array_values( array_intersect( $sizes, self::restorable_sizes() ) );
		}

		if ( in_array( $action, array( 'apply', 'restore' ), true ) && ! $sizes ) {
			return new WP_Error( 'mvweb_mdc_sizes', __( 'Select at least one size.', 'mvweb-media-control' ) );
		}

		if ( in_array( $action, array( 'delete', 'undo' ), true ) && ! self::pending_count() ) {
			return new WP_Error( 'mvweb_mdc_nothing', __( 'There is nothing to process.', 'mvweb-media-control' ) );
		}

		$phases = array( $action );

		if ( 'scan' === $action || ( in_array( $action, array( 'apply', 'delete' ), true ) && self::index_is_stale() ) ) {
			array_unshift( $phases, 'index' );
		}

		$job = array(
			'action'    => $action,
			'phases'    => $phases,
			'phase'     => 0,
			'entered'   => -1,
			'sizes'     => $sizes,
			'cursor'    => 0,
			'source'    => 0,
			'current'   => 0,
			'total'     => 0,
			'processed' => 0,
			'stats'     => array(),
			'failed'    => array(),
			'error'     => '',
			'started'   => time(),
			'finished'  => 0,
		);

		update_option( self::JOB_OPTION, $job, false );

		return $job;
	}

	/**
	 * Drop the current job. Journals of step A stay and can be deleted or undone.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function cancel(): void {
		$job = self::get_job();

		if ( ! empty( $job['action'] ) && empty( $job['finished'] ) ) {
			$job['finished'] = time();
			$job['error']    = 'cancelled';
			update_option( self::JOB_OPTION, $job, false );
		}
	}

	/**
	 * Run the job until it finishes or the deadline passes.
	 *
	 * @since 1.0.0
	 * @param float $deadline Unix time with microseconds; 0 runs to the end.
	 * @return array|WP_Error Job state.
	 */
	public static function step( float $deadline ) {
		$job = self::get_job();

		if ( empty( $job['action'] ) || ! empty( $job['finished'] ) ) {
			return $job;
		}

		if ( ! self::lock() ) {
			return new WP_Error( 'mvweb_mdc_locked', __( 'The task is already running in another tab or process.', 'mvweb-media-control' ) );
		}

		if ( ! empty( $job['current'] ) ) {
			$job['failed'][] = (int) $job['current'];
			$job['cursor']   = max( (int) $job['cursor'], (int) $job['current'] );
			$job['current']  = 0;
		}

		while ( empty( $job['finished'] ) ) {
			if ( $job['entered'] !== $job['phase'] ) {
				self::enter_phase( $job );
			}

			$phase = $job['phases'][ $job['phase'] ];
			$done  = self::run_unit( $phase, $job );

			if ( '' !== $job['error'] ) {
				$job['finished'] = time();
				break;
			}

			if ( $done ) {
				self::leave_phase( $phase, $job );

				++$job['phase'];

				if ( ! isset( $job['phases'][ $job['phase'] ] ) ) {
					$job['finished'] = time();
				}
			}

			self::flush_buffer( $job );

			if ( '' !== $job['error'] ) {
				$job['finished'] = time();
			}

			update_option( self::JOB_OPTION, $job, false );

			if ( self::out_of_budget( $deadline ) ) {
				break;
			}

			self::lock();
		}

		self::flush_buffer( $job );

		if ( '' !== $job['error'] && empty( $job['finished'] ) ) {
			$job['finished'] = time();
		}

		update_option( self::JOB_OPTION, $job, false );
		self::unlock();

		return $job;
	}

	/**
	 * Prepare a phase.
	 *
	 * @param array $job Job state.
	 * @return void
	 */
	private static function enter_phase( array &$job ): void {
		global $wpdb;

		$phase            = $job['phases'][ $job['phase'] ];
		$job['entered']   = $job['phase'];
		$job['cursor']    = 0;
		$job['source']    = 0;
		$job['processed'] = 0;

		switch ( $phase ) {
			case 'index':
				$job['total'] = self::index_begin();
				break;

			case 'scan':
			case 'apply':
			case 'restore':
				$job['total'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_mime_type LIKE 'image/%'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
				break;

			case 'delete':
			case 'undo':
				$job['total'] = self::pending_count();
				break;
		}

		if ( in_array( $phase, array( 'apply', 'delete' ), true ) && 'index' !== ( $job['phases'][0] ?? '' ) ) {
			self::refresh_index();
		}
	}

	/**
	 * Finish a phase.
	 *
	 * @param string $phase Phase name.
	 * @param array  $job   Job state.
	 * @return void
	 */
	private static function leave_phase( string $phase, array &$job ): void {
		if ( 'index' === $phase ) {
			self::index_end( $job );
		}

		if ( 'scan' === $phase ) {
			update_option(
				self::REPORT_OPTION,
				array(
					'at'           => time(),
					'attachments'  => (int) $job['processed'],
					'sizes'        => $job['stats']['sizes'] ?? array(),
					'skipped'      => $job['stats']['skipped'] ?? array(),
					'not_freed'    => $job['stats']['not_freed'] ?? array(
						'files' => 0,
						'bytes' => 0,
					),
					'linked'       => $job['stats']['linked'] ?? array(),
					'linked_total' => (int) ( $job['stats']['linked_total'] ?? 0 ),
				),
				false
			);
		}

		if ( 'apply' === $phase ) {
			self::clear_builder_cache();
		}

		if ( in_array( $phase, array( 'apply', 'delete', 'undo', 'restore' ), true ) ) {
			$report = get_option( self::REPORT_OPTION, array() );
			if ( is_array( $report ) && $report ) {
				$report['stale'] = true;
				update_option( self::REPORT_OPTION, $report, false );
			}
		}
	}

	/**
	 * Run one unit of work.
	 *
	 * @param string $phase Phase name.
	 * @param array  $job   Job state.
	 * @return bool True when the phase is complete.
	 */
	private static function run_unit( string $phase, array &$job ): bool {
		switch ( $phase ) {
			case 'index':
				return self::index_unit( $job );
			case 'scan':
			case 'apply':
				return self::attachments_unit( $phase, $job );
			case 'restore':
				return self::restore_unit( $job );
			case 'delete':
			case 'undo':
				return self::pending_unit( $phase, $job );
		}

		return true;
	}

	/**
	 * Whether the slice must stop: deadline or 75% of the memory limit.
	 *
	 * @param float $deadline Deadline, 0 for none.
	 * @return bool
	 */
	public static function out_of_budget( float $deadline ): bool {
		if ( $deadline > 0 && microtime( true ) >= $deadline ) {
			return true;
		}

		$limit = wp_convert_hr_to_bytes( (string) ini_get( 'memory_limit' ) );

		return $limit > 0 && memory_get_usage() > 0.75 * $limit;
	}

	/**
	 * Take or extend the lock.
	 *
	 * @return bool
	 */
	public static function lock(): bool {
		global $wpdb;

		$now = time();

		if ( self::$held ) {
			update_option( self::LOCK_OPTION, $now, false );
			return true;
		}

		if ( add_option( self::LOCK_OPTION, $now, '', false ) ) {
			self::$held = true;
			add_action( 'shutdown', array( __CLASS__, 'unlock' ) );
			return true;
		}

		wp_cache_delete( self::LOCK_OPTION, 'options' );
		$old = (int) get_option( self::LOCK_OPTION, 0 );

		if ( $now - $old < self::LOCK_TTL ) {
			return false;
		}

		$taken = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND option_value = %s",
				(string) $now,
				self::LOCK_OPTION,
				(string) $old
			)
		);

		if ( 1 !== $taken ) {
			return false;
		}

		wp_cache_delete( self::LOCK_OPTION, 'options' );
		self::$held = true;
		add_action( 'shutdown', array( __CLASS__, 'unlock' ) );

		return true;
	}

	/**
	 * Release the lock.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function unlock(): void {
		if ( ! self::$held ) {
			return;
		}

		self::$held = false;
		delete_option( self::LOCK_OPTION );
	}

	/* ─── Link index ────────────────────────────────────────────── */

	/**
	 * Drop the index and mark a rebuild as started.
	 *
	 * @since 1.0.0
	 * @return int Number of sources to read.
	 */
	public static function index_begin(): int {
		self::drop_index();
		update_option(
			self::INDEX_OPTION,
			array(
				'built'   => 0,
				'partial' => true,
				'chunks'  => 0,
			),
			false
		);

		return count( self::index_sources() );
	}

	/**
	 * Read one batch of the index rebuild and store what was found.
	 *
	 * @since 1.0.0
	 * @param array $job Job state with source, cursor, processed and error keys.
	 * @return bool True when all sources are read.
	 */
	public static function index_step( array &$job ): bool {
		$done = self::index_unit( $job );
		self::flush_buffer( $job );

		return $done;
	}

	/**
	 * Mark the index rebuild as complete.
	 *
	 * @since 1.0.0
	 * @param array $job Job state.
	 * @return void
	 */
	public static function index_end( array &$job ): void {
		self::flush_buffer( $job );
		$meta            = get_option( self::INDEX_OPTION, array() );
		$meta['built']   = time();
		$meta['partial'] = false;
		update_option( self::INDEX_OPTION, $meta, false );
		self::$index = null;
	}

	/**
	 * Tables and columns searched for file names.
	 *
	 * Attachment metadata and caches are excluded: they list every size and
	 * would protect everything.
	 *
	 * @return array<int, array{table: string, id: string, cols: string[], where: string}>
	 */
	public static function index_sources(): array {
		global $wpdb;

		$skip_meta = array(
			'_wp_attachment_metadata',
			'_wp_attachment_backup_sizes',
			'_wp_attachment_backup_sources',
			'_wp_sideloaded_file',
			'_elementor_element_cache',
			'_elementor_css',
			'_elementor_page_assets',
			self::PENDING_META,
			MVweb_MDC_Uploads::SOURCE_META,
			MVweb_MDC_Converter::JOURNAL,
			MVweb_MDC_Converter::LINKS,
			MVweb_MDC_Converter::KEPT,
		);

		$keys = "'" . implode( "','", array_map( 'esc_sql', $skip_meta ) ) . "'";

		$sources = array(
			array(
				'table' => $wpdb->posts,
				'id'    => 'ID',
				'cols'  => array( 'post_content', 'post_excerpt' ),
				'where' => '',
			),
			array(
				'table' => $wpdb->postmeta,
				'id'    => 'meta_id',
				'cols'  => array( 'meta_value' ),
				'where' => "meta_key NOT IN ({$keys}) AND meta_key NOT LIKE '\\_oembed\\_%'",
			),
			array(
				'table' => $wpdb->termmeta,
				'id'    => 'meta_id',
				'cols'  => array( 'meta_value' ),
				'where' => '',
			),
			array(
				'table' => $wpdb->usermeta,
				'id'    => 'umeta_id',
				'cols'  => array( 'meta_value' ),
				'where' => '',
			),
			array(
				'table' => $wpdb->options,
				'id'    => 'option_id',
				'cols'  => array( 'option_value' ),
				'where' => "option_name NOT LIKE '\\_transient\\_%' AND option_name NOT LIKE '\\_site\\_transient\\_%' AND option_name NOT LIKE 'mdc\\_idx\\_%' AND option_name NOT LIKE 'mvweb\\_mdc\\_%'",
			),
			array(
				'table' => $wpdb->term_taxonomy,
				'id'    => 'term_taxonomy_id',
				'cols'  => array( 'description' ),
				'where' => '',
			),
			array(
				'table' => $wpdb->comments,
				'id'    => 'comment_ID',
				'cols'  => array( 'comment_content' ),
				'where' => '',
			),
		);

		// Yoast SEO keeps the social image URL only in its own table. When the full
		// file is too heavy, that URL points to the large or medium_large size.
		if ( '' !== self::yoast_table() ) {
			$sources[] = array(
				'table' => self::yoast_table(),
				'id'    => 'id',
				'cols'  => array( 'open_graph_image', 'twitter_image', 'open_graph_image_meta' ),
				'where' => '',
			);
		}

		return $sources;
	}

	/**
	 * Yoast SEO indexable table name, or an empty string when it does not exist.
	 *
	 * @return string
	 */
	private static function yoast_table(): string {
		global $wpdb;
		static $table = null;

		if ( null === $table ) {
			$name  = $wpdb->prefix . 'yoast_indexable';
			$table = $name === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $name ) ) ) ? $name : ''; // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- schema check, once per request.
		}

		return $table;
	}

	/**
	 * Read one batch of rows from the current index source.
	 *
	 * @param array $job Job state.
	 * @return bool
	 */
	private static function index_unit( array &$job ): bool {
		global $wpdb;

		$sources = self::index_sources();

		if ( ! isset( $sources[ $job['source'] ] ) ) {
			return true;
		}

		$src   = $sources[ $job['source'] ];
		$where = '' !== $src['where'] ? ' AND ' . $src['where'] : '';
		$cols  = implode( ', ', array_merge( array( $src['id'] ), $src['cols'] ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- table, columns and filters are fixed above; LIKE patterns stay outside prepare().
		$sql  = $wpdb->prepare( "SELECT {$cols} FROM {$src['table']} WHERE {$src['id']} > %d", (int) $job['cursor'] )
			. $where
			. $wpdb->prepare( " ORDER BY {$src['id']} ASC LIMIT %d", self::INDEX_ROWS );
		$rows = $wpdb->get_results( $sql, ARRAY_A );
		// phpcs:enable

		foreach ( $rows as $row ) {
			foreach ( $src['cols'] as $col ) {
				self::collect_names( (string) $row[ $col ] );
			}
			$job['cursor'] = (int) $row[ $src['id'] ];
		}

		if ( count( self::$buffer ) >= self::INDEX_FLUSH ) {
			self::flush_buffer( $job );
		}

		if ( count( $rows ) < self::INDEX_ROWS ) {
			++$job['source'];
			$job['cursor'] = 0;
			++$job['processed'];
		}

		return ! isset( $sources[ $job['source'] ] );
	}

	/**
	 * Add size file names found in a value to the buffer.
	 *
	 * @param string $value Raw value.
	 * @return void
	 */
	private static function collect_names( string $value ): void {
		if ( '' === $value || ! preg_match( '/\.(?:' . self::IMAGE_EXT . ')/i', $value ) ) {
			return;
		}

		foreach ( self::extract_names( $value ) as $name ) {
			self::$buffer[ $name ] = true;
		}
	}

	/**
	 * Extract image file names from text.
	 *
	 * Handles JSON-escaped slashes, \uXXXX escapes and URL encoding. Size files
	 * (-300x200.jpg, -300x200-1.jpg, -300x200-jpg.webp, -300x200.jpg.webp) and
	 * main files (photo.jpg, photo-scaled.jpg) are both taken: conversion to
	 * WebP replaces main files too.
	 *
	 * @since 1.0.0
	 * @param string $value Text.
	 * @return string[]
	 */
	public static function extract_names( string $value ): array {
		$value = str_replace( '\\/', '/', $value );

		if ( str_contains( $value, '\\u' ) ) {
			$value = (string) preg_replace_callback(
				'/\\\\u([0-9a-fA-F]{4})/',
				static function ( array $m ): string {
					return mb_chr( (int) hexdec( $m[1] ), 'UTF-8' );
				},
				$value
			);
		}

		if ( str_contains( $value, '%' ) ) {
			$value = rawurldecode( $value );
		}

		$ext     = self::IMAGE_EXT;
		$pattern = '#[^/\\\\\s"\'<>()?\#&=,;|*]+\.(?:' . $ext . ')(?:\.(?:webp|avif))?(?![A-Za-z0-9])#i';

		return preg_match_all( $pattern, $value, $m ) ? array_unique( $m[0] ) : array();
	}

	/**
	 * Store buffered names as a new index chunk.
	 *
	 * @param array $job Job state.
	 * @return void
	 */
	private static function flush_buffer( array &$job ): void {
		if ( ! self::$buffer ) {
			return;
		}

		$meta = get_option( self::INDEX_OPTION, array() );
		$meta = is_array( $meta ) ? $meta : array();
		$n    = (int) ( $meta['chunks'] ?? 0 ) + 1;

		if ( ! add_option( self::INDEX_PREFIX . $n, array_keys( self::$buffer ), '', false ) ) {
			$job['error'] = 'index_write';
			return;
		}

		$meta['chunks'] = $n;
		update_option( self::INDEX_OPTION, $meta, false );

		if ( null !== self::$index ) {
			self::$index += self::$buffer;
		}

		self::$buffer = array();
	}

	/**
	 * Delete all index chunks.
	 *
	 * @return void
	 */
	private static function drop_index(): void {
		global $wpdb;

		$names = $wpdb->get_col( $wpdb->prepare( "SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( self::INDEX_PREFIX ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		foreach ( $names as $name ) {
			delete_option( $name );
		}

		self::$index = null;
	}

	/**
	 * Whether the index must be rebuilt (missing, partial or older than a day).
	 *
	 * @return bool
	 */
	private static function index_is_stale(): bool {
		$meta = get_option( self::INDEX_OPTION, array() );

		return ! is_array( $meta ) || ! empty( $meta['partial'] ) || empty( $meta['built'] ) || (int) $meta['built'] < time() - DAY_IN_SECONDS;
	}

	/**
	 * Add names from posts and their meta changed since the index was built.
	 *
	 * @return void
	 */
	private static function refresh_index(): void {
		global $wpdb;

		$meta  = get_option( self::INDEX_OPTION, array() );
		$since = max( (int) ( $meta['built'] ?? 0 ), (int) ( $meta['refreshed'] ?? 0 ) );
		$now   = time();

		// Drafts keep post_modified_gmt at zero, so the local column is checked too.
		$since = max( 0, $since - MINUTE_IN_SECONDS );
		$posts = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$wpdb->prepare(
				"SELECT ID, post_content, post_excerpt FROM {$wpdb->posts} WHERE post_modified_gmt >= %s OR post_modified >= %s",
				gmdate( 'Y-m-d H:i:s', $since ),
				get_date_from_gmt( gmdate( 'Y-m-d H:i:s', $since ) )
			),
			ARRAY_A
		);

		$ids = array();
		foreach ( $posts as $post ) {
			self::collect_names( (string) $post['post_content'] );
			self::collect_names( (string) $post['post_excerpt'] );
			$ids[] = (int) $post['ID'];
		}

		$sources = self::index_sources();
		foreach ( array_chunk( $ids, 500 ) as $chunk ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- ids are integers, filter is fixed.
			$values = $wpdb->get_col( "SELECT meta_value FROM {$wpdb->postmeta} WHERE post_id IN (" . implode( ',', array_map( 'intval', $chunk ) ) . ") AND {$sources[1]['where']}" );
			foreach ( $values as $value ) {
				self::collect_names( (string) $value );
			}
		}

		$job = array( 'error' => '' );
		self::flush_buffer( $job );

		$meta              = get_option( self::INDEX_OPTION, array() );
		$meta['refreshed'] = $now;
		update_option( self::INDEX_OPTION, $meta, false );
	}

	/**
	 * Whether a file name is referenced by content.
	 *
	 * @param string $name File base name.
	 * @return bool
	 */
	public static function is_linked( string $name ): bool {
		return self::in_index( $name );
	}

	/**
	 * Whether a file name is referenced by content, loading the index once.
	 *
	 * @param string $name File base name.
	 * @return bool
	 */
	private static function in_index( string $name ): bool {
		global $wpdb;

		if ( null === self::$index ) {
			self::$index = array();
			$values      = $wpdb->get_col( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name LIKE %s", $wpdb->esc_like( self::INDEX_PREFIX ) . '%' ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

			foreach ( $values as $value ) {
				$names = maybe_unserialize( $value );
				if ( is_array( $names ) ) {
					self::$index += array_fill_keys( $names, true );
				}
			}
		}

		return isset( self::$index[ $name ] );
	}

	/**
	 * Where content links to a file: the same tables as the index, searched on demand.
	 *
	 * Only names already in the index are accepted, so the request cannot
	 * probe arbitrary strings. A name written with \uXXXX escapes is not found
	 * by this search, although the index has it.
	 *
	 * @since 1.0.0
	 * @param string $file File base name.
	 * @return array<int, array{label: string, url: string}>|null Null when the name is not in the index.
	 */
	public static function where_used( string $file ): ?array {
		global $wpdb;

		if ( '' === $file || ! self::in_index( $file ) ) {
			return null;
		}

		$likes = array_unique( array( $file, rawurlencode( $file ) ) );
		$match = static function ( string $col ) use ( $wpdb, $likes ): string {
			$parts = array();
			foreach ( $likes as $like ) {
				$parts[] = $wpdb->prepare( "{$col} LIKE %s", '%' . $wpdb->esc_like( $like ) . '%' ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- fixed column names.
			}
			return '(' . implode( ' OR ', $parts ) . ')';
		};

		$sources = self::index_sources();
		$places  = array();
		$limit   = ' LIMIT 10';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- conditions are prepared above, tables and filters are fixed.
		foreach ( $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE (" . $match( 'post_content' ) . ' OR ' . $match( 'post_excerpt' ) . "){$limit}" ) as $id ) {
			$places[] = self::post_place( (int) $id, '' );
		}

		foreach ( $wpdb->get_results( "SELECT post_id, meta_key FROM {$wpdb->postmeta} WHERE " . $match( 'meta_value' ) . " AND {$sources[1]['where']}{$limit}" ) as $row ) {
			$places[] = self::post_place( (int) $row->post_id, (string) $row->meta_key );
		}

		foreach ( $wpdb->get_results( "SELECT term_id, meta_key FROM {$wpdb->termmeta} WHERE " . $match( 'meta_value' ) . $limit ) as $row ) {
			$term     = get_term( (int) $row->term_id );
			$places[] = array(
				/* translators: 1: term name, 2: meta key */
				'label' => sprintf( __( 'Term "%1$s", field %2$s', 'mvweb-media-control' ), $term instanceof WP_Term ? $term->name : '#' . (int) $row->term_id, $row->meta_key ),
				'url'   => (string) get_edit_term_link( (int) $row->term_id ),
			);
		}

		foreach ( $wpdb->get_results( "SELECT term_id, taxonomy FROM {$wpdb->term_taxonomy} WHERE " . $match( 'description' ) . $limit ) as $row ) {
			$term     = get_term( (int) $row->term_id, (string) $row->taxonomy );
			$places[] = array(
				/* translators: %s: term name */
				'label' => sprintf( __( 'Term "%s", description', 'mvweb-media-control' ), $term instanceof WP_Term ? $term->name : '#' . (int) $row->term_id ),
				'url'   => (string) get_edit_term_link( (int) $row->term_id, (string) $row->taxonomy ),
			);
		}

		foreach ( $wpdb->get_results( "SELECT user_id, meta_key FROM {$wpdb->usermeta} WHERE " . $match( 'meta_value' ) . $limit ) as $row ) {
			$user     = get_userdata( (int) $row->user_id );
			$places[] = array(
				/* translators: 1: user name, 2: meta key */
				'label' => sprintf( __( 'User %1$s, field %2$s', 'mvweb-media-control' ), $user ? $user->display_name : '#' . (int) $row->user_id, $row->meta_key ),
				'url'   => (string) get_edit_user_link( (int) $row->user_id ),
			);
		}

		foreach ( $wpdb->get_col( "SELECT option_name FROM {$wpdb->options} WHERE " . $match( 'option_value' ) . " AND {$sources[4]['where']}{$limit}" ) as $name ) {
			$places[] = array(
				/* translators: %s: option name */
				'label' => sprintf( __( 'Site option %s', 'mvweb-media-control' ), $name ),
				'url'   => str_starts_with( (string) $name, 'theme_mods_' ) ? admin_url( 'customize.php' ) : '',
			);
		}

		if ( '' !== self::yoast_table() ) {
			foreach ( $wpdb->get_results( 'SELECT object_id, object_type FROM ' . self::yoast_table() . ' WHERE (' . $match( 'open_graph_image' ) . ' OR ' . $match( 'twitter_image' ) . ' OR ' . $match( 'open_graph_image_meta' ) . "){$limit}" ) as $row ) {
				$place    = 'post' === $row->object_type ? self::post_place( (int) $row->object_id, '' ) : array(
					'label' => (string) $row->object_type . ' #' . (int) $row->object_id,
					'url'   => '',
				);
				$places[] = array(
					/* translators: %s: post type and title */
					'label' => sprintf( __( 'Yoast SEO social image of %s', 'mvweb-media-control' ), $place['label'] ),
					'url'   => $place['url'],
				);
			}
		}

		foreach ( $wpdb->get_col( "SELECT comment_ID FROM {$wpdb->comments} WHERE " . $match( 'comment_content' ) . $limit ) as $id ) {
			$places[] = array(
				/* translators: %d: comment ID */
				'label' => sprintf( __( 'Comment #%d', 'mvweb-media-control' ), (int) $id ),
				'url'   => (string) get_edit_comment_link( (int) $id ),
			);
		}
		// phpcs:enable

		return $places;
	}

	/**
	 * Label and edit link for a post, revision or one of its fields.
	 *
	 * @param int    $post_id  Post ID.
	 * @param string $meta_key Meta key, empty for the content itself.
	 * @return array{label: string, url: string}
	 */
	private static function post_place( int $post_id, string $meta_key ): array {
		$post  = get_post( $post_id );
		$title = $post ? ( '' !== $post->post_title ? $post->post_title : __( '(no title)', 'mvweb-media-control' ) ) : '#' . $post_id;
		$type  = $post ? get_post_type_object( $post->post_type ) : null;
		/* translators: 1: post type name, 2: post title */
		$what = sprintf( __( '%1$s "%2$s"', 'mvweb-media-control' ), $type ? $type->labels->singular_name : __( 'Post', 'mvweb-media-control' ), $title );

		return array(
			/* translators: 1: post type and title, 2: meta key */
			'label' => '' !== $meta_key ? sprintf( __( '%1$s, field %2$s', 'mvweb-media-control' ), $what, $meta_key ) : $what,
			'url'   => (string) get_edit_post_link( $post_id, 'raw' ),
		);
	}

	/* ─── Attachments ───────────────────────────────────────────── */

	/**
	 * Next batch of image attachment IDs.
	 *
	 * @param int $cursor Last processed ID.
	 * @return int[]
	 */
	private static function next_ids( int $cursor ): array {
		global $wpdb;

		return array_map(
			'intval',
			$wpdb->get_col( $wpdb->prepare( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_mime_type LIKE 'image/%%' AND ID > %d ORDER BY ID ASC LIMIT %d", $cursor, self::BATCH ) ) // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders.LikeWildcardsInQuery -- fixed mime prefix.
		);
	}

	/**
	 * Attachments sharing the same file (WPML/Polylang translations).
	 *
	 * @param int[] $ids Attachment IDs.
	 * @return array<int, int[]> ID => sorted group member IDs.
	 */
	public static function groups_for( array $ids ): array {
		global $wpdb;

		$groups = array_combine( $ids, array_map( static fn( int $id ): array => array( $id ), $ids ) );

		if ( ! $ids ) {
			return array();
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- ids are integers.
		$files = $wpdb->get_results( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND post_id IN (" . implode( ',', $ids ) . ')', ARRAY_A );

		if ( ! $files ) {
			return $groups;
		}

		$values = array_unique( wp_list_pluck( $files, 'meta_value' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- placeholders built from the value count.
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND meta_value IN (" . implode( ',', array_fill( 0, count( $values ), '%s' ) ) . ')', $values ), ARRAY_A );

		$by_file = array();
		foreach ( $rows as $row ) {
			$by_file[ $row['meta_value'] ][] = (int) $row['post_id'];
		}

		foreach ( $files as $row ) {
			$members = $by_file[ $row['meta_value'] ] ?? array( (int) $row['post_id'] );
			sort( $members );
			$groups[ (int) $row['post_id'] ] = $members;
		}

		return $groups;
	}

	/**
	 * Load attachment data without filters (offload plugins change both).
	 *
	 * @param int $id Attachment ID.
	 * @return array{id: int, meta: mixed, file: string}
	 */
	public static function load( int $id ): array {
		wp_cache_delete( $id, 'post_meta' );

		return array(
			'id'   => $id,
			'meta' => wp_get_attachment_metadata( $id, true ),
			'file' => (string) get_attached_file( $id, true ),
		);
	}

	/**
	 * Why an attachment cannot be cleaned: its sizes could not be restored.
	 *
	 * @param array $item Loaded attachment.
	 * @return string Reason code, empty when it can be processed.
	 */
	public static function skip_reason( array $item ): string {
		$id   = $item['id'];
		$meta = $item['meta'];

		if ( ! is_array( $meta ) || empty( $meta['file'] ) || '' === $item['file'] ) {
			return 'bad_meta';
		}

		if ( ! wp_attachment_is_image( $id ) ) {
			return 'not_image';
		}

		$mime = (string) ( wp_check_filetype( $item['file'] )['type'] ?? '' );

		if ( ! isset( self::$editor_support[ $mime ] ) ) {
			self::$editor_support[ $mime ] = '' !== $mime && wp_image_editor_supports( array( 'mime_type' => $mime ) );
		}

		if ( ! self::$editor_support[ $mime ] ) {
			return 'unsupported';
		}

		$original = wp_get_original_image_path( $id, true );

		if ( ! $original || ! is_file( $original ) ) {
			return 'no_original';
		}

		if ( get_post_meta( $id, '_wp_attachment_backup_sizes', true ) ) {
			return 'edited';
		}

		$post = get_post( $id );

		if ( ! $post || strtotime( $post->post_date_gmt . ' UTC' ) > time() - self::MIN_AGE ) {
			return 'too_new';
		}

		if ( mvweb_mdc_is_offloaded( $id ) ) {
			return 'offloaded';
		}

		if ( 'site-icon' === get_post_meta( $id, '_wp_attachment_context', true ) ) {
			return 'site_icon';
		}

		return '';
	}

	/**
	 * Collect every string under a 'file' key.
	 *
	 * @param mixed $data Array to walk.
	 * @return string[] Base names.
	 */
	public static function collect_files( $data ): array {
		$files = array();

		if ( ! is_array( $data ) ) {
			return $files;
		}

		foreach ( $data as $key => $value ) {
			if ( 'file' === $key && is_string( $value ) && '' !== $value ) {
				$files[] = wp_basename( $value );
			} elseif ( is_array( $value ) ) {
				$files = array_merge( $files, self::collect_files( $value ) );
			}
		}

		return $files;
	}

	/**
	 * Files of one size entry: the file, format sources and .webp/.avif copies.
	 *
	 * @param array  $entry    Size entry from metadata.
	 * @param string $dir      Attachment directory.
	 * @param bool   $existing Only files present on disk.
	 * @return string[] Base names.
	 */
	private static function size_files( array $entry, string $dir, bool $existing ): array {
		$files = self::collect_files( $entry );

		foreach ( $files as $file ) {
			$files[] = $file . '.webp';
			$files[] = $file . '.avif';
		}

		$files = array_values( array_unique( $files ) );

		if ( $existing ) {
			$files = array_values(
				array_filter(
					$files,
					static function ( string $file ) use ( $dir ): bool {
						return is_file( $dir . '/' . $file );
					}
				)
			);
		}

		return $files;
	}

	/**
	 * Files of a group that are never deleted, except kept sizes.
	 *
	 * Main files, originals, full size, format sources and editor backups,
	 * as listed by wp_delete_attachment_files().
	 *
	 * @param array[] $items Loaded group members.
	 * @return array<string, true>
	 */
	public static function base_protected( array $items ): array {
		$names = array();

		foreach ( $items as $item ) {
			$meta    = is_array( $item['meta'] ) ? $item['meta'] : array();
			$names[] = wp_basename( $item['file'] );

			foreach ( array( 'file', 'original_image', 'source_image', 'thumb', 'animated_video', 'animated_video_poster' ) as $key ) {
				if ( ! empty( $meta[ $key ] ) && is_string( $meta[ $key ] ) ) {
					$names[] = wp_basename( $meta[ $key ] );
				}
			}

			$names = array_merge(
				$names,
				self::collect_files( $meta['sources'] ?? array() ),
				self::collect_files( $meta['sizes']['full'] ?? array() ),
				self::collect_files( get_post_meta( $item['id'], '_wp_attachment_backup_sizes', true ) ),
				self::collect_files( get_post_meta( $item['id'], '_wp_attachment_backup_sources', true ) )
			);

			$source = (string) get_post_meta( $item['id'], MVweb_MDC_Uploads::SOURCE_META, true );
			if ( '' !== $source ) {
				$names[] = wp_basename( $source );
			}
		}

		return array_fill_keys( array_filter( $names ), true );
	}

	/**
	 * Map file => size names that use it, over all group members.
	 *
	 * @param array[] $items Loaded group members.
	 * @param string  $dir   Directory.
	 * @return array<string, array<string, true>>
	 */
	private static function file_owners( array $items, string $dir ): array {
		$owners = array();

		foreach ( $items as $item ) {
			foreach ( ( $item['meta']['sizes'] ?? array() ) as $name => $entry ) {
				if ( 'full' === $name || ! is_array( $entry ) ) {
					continue;
				}
				foreach ( self::size_files( $entry, $dir, false ) as $file ) {
					$owners[ $file ][ (string) $name ] = true;
				}
			}
		}

		return $owners;
	}

	/**
	 * Whether a file must stay when the given sizes are removed.
	 *
	 * @param string                             $file    Base name.
	 * @param array<string, true>                $base    Base protected set.
	 * @param array<string, array<string, true>> $owners  File owners.
	 * @param string[]                           $removed Size names being removed.
	 * @return bool
	 */
	private static function is_protected( string $file, array $base, array $owners, array $removed ): bool {
		if ( isset( $base[ $file ] ) || self::in_index( $file ) ) {
			return true;
		}

		return (bool) array_diff( array_keys( $owners[ $file ] ?? array() ), $removed );
	}

	/**
	 * Process the next batch of attachments for scan or step A.
	 *
	 * @param string $phase 'scan' or 'apply'.
	 * @param array  $job   Job state.
	 * @return bool
	 */
	private static function attachments_unit( string $phase, array &$job ): bool {
		$ids = self::next_ids( (int) $job['cursor'] );

		if ( ! $ids ) {
			return true;
		}

		$groups = self::groups_for( $ids );

		foreach ( $ids as $id ) {
			$members = $groups[ $id ] ?? array( $id );
			++$job['processed'];

			if ( $members[0] === $id ) {
				$job['current'] = $id;
				update_option( self::JOB_OPTION, $job, false );

				$items = array_map( array( __CLASS__, 'load' ), $members );

				if ( 'scan' === $phase ) {
					self::scan_group( $items, $job );
				} else {
					self::apply_group( $items, $job );
				}

				foreach ( $members as $member ) {
					wp_cache_delete( $member, 'post_meta' );
					wp_cache_delete( $member, 'posts' );
				}

				$job['current'] = 0;
			}

			$job['cursor'] = $id;
		}

		return count( $ids ) < self::BATCH;
	}

	/**
	 * Add one group to the scan report.
	 *
	 * @param array[] $items Loaded group members.
	 * @param array   $job   Job state.
	 * @return void
	 */
	private static function scan_group( array $items, array &$job ): void {
		$stats   = &$job['stats'];
		$reasons = array_map( array( __CLASS__, 'skip_reason' ), $items );
		$blocked = (bool) array_filter( $reasons );

		foreach ( $items as $i => $item ) {
			if ( $blocked ) {
				$reason                      = '' !== $reasons[ $i ] ? $reasons[ $i ] : 'group';
				$stats['skipped'][ $reason ] = ( $stats['skipped'][ $reason ] ?? 0 ) + 1;
			}

			foreach ( array_keys( ( is_array( $item['meta'] ) ? $item['meta']['sizes'] ?? array() : array() ) ) as $name ) {
				$name = (string) $name;
				if ( 'full' === $name ) {
					continue;
				}
				$stats['sizes'][ $name ] ??= array(
					'attachments' => 0,
					'files'       => 0,
					'bytes'       => 0,
					'protected'   => 0,
					'skipped'     => 0,
				);
				++$stats['sizes'][ $name ]['attachments'];

				if ( $blocked ) {
					++$stats['sizes'][ $name ]['skipped'];
				}
			}
		}

		if ( $blocked ) {
			return;
		}

		$dir     = dirname( $items[0]['file'] );
		$base    = self::base_protected( $items );
		$owners  = self::file_owners( $items, $dir );
		$counted = array();

		$stats['not_freed'] ??= array(
			'files' => 0,
			'bytes' => 0,
		);

		foreach ( $items as $item ) {
			foreach ( $item['meta']['sizes'] ?? array() as $name => $entry ) {
				$name = (string) $name;
				if ( 'full' === $name || ! is_array( $entry ) ) {
					continue;
				}

				$files = self::size_files( $entry, $dir, true );

				foreach ( $files as $file ) {
					if ( self::is_protected( $file, $base, $owners, array( $name ) ) ) {
						++$stats['sizes'][ $name ]['protected'];

						if ( ! isset( $base[ $file ] ) && self::in_index( $file ) && ! isset( $stats['linked'][ $file ] ) ) {
							$stats['linked_total'] = ( $stats['linked_total'] ?? 0 ) + 1;
							if ( count( $stats['linked'] ?? array() ) < self::LINKED_MAX ) {
								$stats['linked'][ $file ] = $name;
							}
						}
						continue 2;
					}
				}

				foreach ( $files as $file ) {
					if ( isset( $counted[ $file ] ) ) {
						continue;
					}
					$counted[ $file ] = true;
					++$stats['sizes'][ $name ]['files'];
					$stats['sizes'][ $name ]['bytes'] += (int) filesize( $dir . '/' . $file );
				}

				if ( ! empty( $entry['file'] ) ) {
					$stem = pathinfo( (string) $entry['file'], PATHINFO_FILENAME );
					foreach ( array( 'webp', 'avif' ) as $ext ) {
						$copy = $stem . '.' . $ext;
						if ( $copy !== $entry['file'] && ! isset( $counted[ $copy ] ) && is_file( $dir . '/' . $copy ) ) {
							$counted[ $copy ] = true;
							++$stats['not_freed']['files'];
							$stats['not_freed']['bytes'] += (int) filesize( $dir . '/' . $copy );
						}
					}
				}
			}
		}
	}

	/**
	 * Step A for one group: move selected sizes from metadata to the journal.
	 *
	 * @param array[] $items Loaded group members.
	 * @param array   $job   Job state.
	 * @return void
	 */
	private static function apply_group( array $items, array &$job ): void {
		$stats    = &$job['stats'];
		$selected = $job['sizes'];

		foreach ( $items as $item ) {
			if ( '' !== self::skip_reason( $item ) ) {
				$stats['skipped'] = ( $stats['skipped'] ?? 0 ) + count( $items );
				return;
			}
		}

		$dir     = dirname( $items[0]['file'] );
		$base    = self::base_protected( $items );
		$owners  = self::file_owners( $items, $dir );
		$claimed = array();

		foreach ( $items as $item ) {
			$meta    = $item['meta'];
			$journal = get_post_meta( $item['id'], self::PENDING_META, true );
			$journal = is_array( $journal ) ? $journal : array(
				'sizes' => array(),
				'files' => array(),
				'bytes' => 0,
			);
			$before  = $journal;
			$changed = false;

			foreach ( array_intersect( $selected, array_map( 'strval', array_keys( $meta['sizes'] ?? array() ) ) ) as $name ) {
				$entry = $meta['sizes'][ $name ];
				$files = is_array( $entry ) ? self::size_files( $entry, $dir, true ) : array();

				foreach ( $files as $file ) {
					if ( self::is_protected( $file, $base, $owners, $selected ) ) {
						$stats['protected'] = ( $stats['protected'] ?? 0 ) + 1;
						continue 2;
					}
				}

				$journal['sizes'][ $name ] = $entry;

				foreach ( $files as $file ) {
					if ( ! isset( $claimed[ $file ] ) && ! in_array( $file, $journal['files'], true ) ) {
						$claimed[ $file ]   = true;
						$journal['files'][] = $file;
						$journal['bytes']  += (int) filesize( $dir . '/' . $file );
					}
				}

				unset( $meta['sizes'][ $name ] );
				$stats['sizes'] = ( $stats['sizes'] ?? 0 ) + 1;
				$changed        = true;
			}

			if ( ! $changed ) {
				continue;
			}

			$journal['at'] = time();
			update_post_meta( $item['id'], self::PENDING_META, $journal );
			wp_update_attachment_metadata( $item['id'], $meta );

			wp_cache_delete( $item['id'], 'post_meta' );
			$saved = wp_get_attachment_metadata( $item['id'], true );

			if ( ! is_array( $saved ) || array_keys( $saved['sizes'] ?? array() ) !== array_keys( $meta['sizes'] ?? array() ) ) {
				update_post_meta( $item['id'], '_wp_attachment_metadata', $item['meta'] );

				if ( $before['sizes'] ) {
					update_post_meta( $item['id'], self::PENDING_META, $before );
				} else {
					delete_post_meta( $item['id'], self::PENDING_META );
				}

				$job['failed'][] = $item['id'];
			}
		}
	}

	/* ─── Pending journals: step B and undo ─────────────────────── */

	/**
	 * Number of attachments with a step A journal.
	 *
	 * @since 1.0.0
	 * @return int
	 */
	public static function pending_count(): int {
		global $wpdb;

		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s", self::PENDING_META ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
	}

	/**
	 * Files and bytes waiting for step B.
	 *
	 * @since 1.0.0
	 * @return array{attachments: int, files: int, bytes: int}
	 */
	public static function pending_summary(): array {
		global $wpdb;

		$summary = array(
			'attachments' => 0,
			'files'       => 0,
			'bytes'       => 0,
		);

		$values = $wpdb->get_col( $wpdb->prepare( "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s", self::PENDING_META ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

		foreach ( $values as $value ) {
			$journal = maybe_unserialize( $value );
			if ( is_array( $journal ) ) {
				++$summary['attachments'];
				$summary['files'] += count( $journal['files'] ?? array() );
				$summary['bytes'] += (int) ( $journal['bytes'] ?? 0 );
			}
		}

		return $summary;
	}

	/**
	 * Process the next batch of journals.
	 *
	 * @param string $phase 'delete' or 'undo'.
	 * @param array  $job   Job state.
	 * @return bool
	 */
	private static function pending_unit( string $phase, array &$job ): bool {
		global $wpdb;

		$ids = array_map(
			'intval',
			$wpdb->get_col( $wpdb->prepare( "SELECT post_id FROM {$wpdb->postmeta} WHERE meta_key = %s AND post_id > %d ORDER BY post_id ASC LIMIT %d", self::PENDING_META, (int) $job['cursor'], self::BATCH ) ) // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		);

		if ( ! $ids ) {
			return true;
		}

		$groups = 'delete' === $phase ? self::groups_for( $ids ) : array();

		foreach ( $ids as $id ) {
			$job['current'] = $id;
			update_option( self::JOB_OPTION, $job, false );

			if ( 'delete' === $phase ) {
				self::delete_files( $id, $groups[ $id ] ?? array( $id ), $job );
			} else {
				self::undo_one( $id, $job );
			}

			wp_cache_delete( $id, 'post_meta' );
			wp_cache_delete( $id, 'posts' );

			$job['current'] = 0;
			$job['cursor']  = $id;
			++$job['processed'];
		}

		return count( $ids ) < self::BATCH;
	}

	/**
	 * Step B for one attachment: delete journal files that nothing uses now.
	 *
	 * @param int   $id      Attachment ID.
	 * @param int[] $members Group member IDs.
	 * @param array $job     Job state.
	 * @return void
	 */
	private static function delete_files( int $id, array $members, array &$job ): void {
		$stats   = &$job['stats'];
		$journal = get_post_meta( $id, self::PENDING_META, true );
		$items   = array_map( array( __CLASS__, 'load' ), $members );
		$self    = self::load( $id );

		if ( ! is_array( $journal ) || '' === $self['file'] ) {
			delete_post_meta( $id, self::PENDING_META );
			return;
		}

		$dir    = dirname( $self['file'] );
		$base   = self::base_protected( $items );
		$owners = self::file_owners( $items, $dir );

		foreach ( (array) ( $journal['files'] ?? array() ) as $file ) {
			$file = wp_basename( (string) $file );
			$path = $dir . '/' . $file;

			if ( ! is_file( $path ) ) {
				continue;
			}

			if ( isset( $base[ $file ] ) || isset( $owners[ $file ] ) || self::in_index( $file ) ) {
				$stats['kept'] = ( $stats['kept'] ?? 0 ) + 1;
				continue;
			}

			$bytes = (int) filesize( $path );

			wp_delete_file_from_directory( $path, $dir );
			clearstatcache( true, $path );

			if ( file_exists( $path ) ) {
				$stats['not_deleted'] = ( $stats['not_deleted'] ?? 0 ) + 1;
				continue;
			}

			$stats['deleted'] = ( $stats['deleted'] ?? 0 ) + 1;
			$stats['bytes']   = ( $stats['bytes'] ?? 0 ) + $bytes;

			/** This action is documented by Force Regenerate Thumbnails; EWWW removes its copies and records on it. */
			do_action( 'regenerate_thumbs_post_delete', $path );

			if ( is_multisite() ) {
				clean_dirsize_cache( $path );
			}
		}

		delete_post_meta( $id, self::PENDING_META );
	}

	/**
	 * Undo step A for one attachment: return sizes whose files are still there.
	 *
	 * @param int   $id  Attachment ID.
	 * @param array $job Job state.
	 * @return void
	 */
	private static function undo_one( int $id, array &$job ): void {
		$stats   = &$job['stats'];
		$journal = get_post_meta( $id, self::PENDING_META, true );
		$item    = self::load( $id );
		$meta    = $item['meta'];

		if ( is_array( $journal ) && is_array( $meta ) && '' !== $item['file'] ) {
			$dir = dirname( $item['file'] );

			foreach ( (array) ( $journal['sizes'] ?? array() ) as $name => $entry ) {
				if ( isset( $meta['sizes'][ $name ] ) || empty( $entry['file'] ) ) {
					continue;
				}

				if ( is_file( $dir . '/' . wp_basename( (string) $entry['file'] ) ) ) {
					$meta['sizes'][ $name ] = $entry;
					$stats['restored']      = ( $stats['restored'] ?? 0 ) + 1;
				} else {
					$stats['lost'] = ( $stats['lost'] ?? 0 ) + 1;
				}
			}

			wp_update_attachment_metadata( $id, $meta );
		}

		delete_post_meta( $id, self::PENDING_META );
	}

	/**
	 * Delete journal files when the attachment itself is deleted.
	 *
	 * The core no longer knows these files; without this they stay as orphans.
	 *
	 * @since 1.0.0
	 * @param int $id Attachment ID.
	 * @return void
	 */
	public static function on_delete_attachment( $id ): void {
		$id      = (int) $id;
		$journal = get_post_meta( $id, self::PENDING_META, true );

		if ( ! is_array( $journal ) || empty( $journal['files'] ) ) {
			return;
		}

		$self    = self::load( $id );
		$members = array_diff( self::groups_for( array( $id ) )[ $id ] ?? array(), array( $id ) );
		$items   = array_map( array( __CLASS__, 'load' ), $members );
		$dir     = dirname( $self['file'] );
		$base    = self::base_protected( $items );
		$owners  = self::file_owners( $items, $dir );

		foreach ( $journal['files'] as $file ) {
			$file = wp_basename( (string) $file );
			if ( ! isset( $base[ $file ] ) && ! isset( $owners[ $file ] ) && ! self::in_index( $file ) ) {
				wp_delete_file_from_directory( $dir . '/' . $file, $dir );
			}
		}
	}

	/* ─── Restore ───────────────────────────────────────────────── */

	/**
	 * Restore the selected sizes for the next attachment.
	 *
	 * One attachment per unit: regeneration is CPU-heavy.
	 *
	 * @param array $job Job state.
	 * @return bool
	 */
	private static function restore_unit( array &$job ): bool {
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$ids = self::next_ids( (int) $job['cursor'] );

		if ( ! $ids ) {
			return true;
		}

		$id             = $ids[0];
		$stats          = &$job['stats'];
		$job['current'] = $id;
		update_option( self::JOB_OPTION, $job, false );

		$item = self::load( $id );

		if ( '' !== self::skip_reason( $item ) ) {
			$stats['skipped'] = ( $stats['skipped'] ?? 0 ) + 1;
		} else {
			$want    = array_flip( $job['sizes'] );
			$narrow  = static function ( $missing ) use ( $want ) {
				return is_array( $missing ) ? array_intersect_key( $missing, $want ) : $missing;
			};
			$missing = array_keys( array_intersect_key( wp_get_missing_image_subsizes( $id ), $want ) );

			if ( $missing ) {
				wp_raise_memory_limit( 'image' );
				add_filter( 'wp_get_missing_image_subsizes', $narrow, 6 );
				wp_update_image_subsizes( $id );
				remove_filter( 'wp_get_missing_image_subsizes', $narrow, 6 );

				wp_cache_delete( $id, 'post_meta' );
				$after = wp_get_attachment_metadata( $id, true );
				$got   = count( array_intersect( $missing, array_map( 'strval', array_keys( $after['sizes'] ?? array() ) ) ) );

				$stats['restored'] = ( $stats['restored'] ?? 0 ) + $got;

				if ( $got < count( $missing ) ) {
					$stats['not_restored'] = ( $stats['not_restored'] ?? 0 ) + count( $missing ) - $got;
					$job['failed'][]       = $id;
				}
			}
		}

		wp_cache_delete( $id, 'post_meta' );
		wp_cache_delete( $id, 'posts' );

		$job['current'] = 0;
		$job['cursor']  = $id;
		++$job['processed'];

		return false;
	}

	/* ─── Size lists ────────────────────────────────────────────── */

	/**
	 * Sizes that may be cleaned: from the last scan, disabled or no longer registered.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	public static function selectable_sizes(): array {
		$report     = get_option( self::REPORT_OPTION, array() );
		$registered = mvweb_mdc_allowed_size_names();
		$disabled   = mvweb_mdc_get_settings()['disabled_sizes'];
		$names      = array();

		foreach ( array_keys( (array) ( $report['sizes'] ?? array() ) ) as $name ) {
			$name = (string) $name;
			if ( in_array( $name, $disabled, true ) || ! in_array( $name, $registered, true ) ) {
				$names[] = $name;
			}
		}

		return $names;
	}

	/**
	 * Sizes that can be restored: registered and not disabled.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	public static function restorable_sizes(): array {
		return array_values( array_diff( mvweb_mdc_allowed_size_names(), mvweb_mdc_get_settings()['disabled_sizes'] ) );
	}

	/**
	 * Clear the Elementor element and CSS cache after metadata changed.
	 *
	 * @return void
	 */
	public static function clear_builder_cache(): void {
		if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) && method_exists( \Elementor\Plugin::$instance->files_manager, 'clear_cache' ) ) {
			\Elementor\Plugin::$instance->files_manager->clear_cache();
		}
	}
}
