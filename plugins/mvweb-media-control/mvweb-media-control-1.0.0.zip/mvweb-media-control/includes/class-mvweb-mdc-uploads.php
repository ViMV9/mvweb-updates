<?php
/**
 * Upload-time behaviour: skip disabled sizes, convert to WebP, delete originals.
 *
 * @package mvweb_mdc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Upload hooks.
 *
 * Disabled sizes stay registered: only their generation is intercepted, so
 * page builders and widgets that check the registry keep their srcset.
 *
 * @since 1.0.0
 */
final class MVweb_MDC_Uploads {

	const SOURCE_META = '_mvweb_mdc_source';

	const USED_OPTION = 'mvweb_mdc_used_sizes';

	const THEME_NOTICE = 'mvweb_mdc_theme_notice';

	const WEBP_QUALITY = 86;

	/**
	 * WebP encode quality chosen in the settings.
	 *
	 * @var int
	 */
	private static int $quality = self::WEBP_QUALITY;

	/**
	 * Disabled size names.
	 *
	 * @var string[]
	 */
	private static array $disabled = array();

	/**
	 * Size names seen on the front end during this request.
	 *
	 * @var array<string, true>
	 */
	private static array $seen = array();

	/**
	 * Attachments queued for the original check.
	 *
	 * @var array<int, true>
	 */
	private static array $queued = array();

	/**
	 * Register hooks according to the saved settings.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		$settings = mvweb_mdc_get_settings();

		self::$disabled = $settings['disabled_sizes'];

		if ( self::$disabled ) {
			add_filter( 'intermediate_image_sizes_advanced', array( __CLASS__, 'filter_size_map' ), 20 );
			add_filter( 'wp_get_missing_image_subsizes', array( __CLASS__, 'filter_size_map' ), 5 );
			add_filter( 'fallback_intermediate_image_sizes', array( __CLASS__, 'filter_size_list' ), 20 );
			add_filter( 'woocommerce_image_sizes_to_resize', array( __CLASS__, 'filter_size_list' ), 20 );
			add_action( 'wp_ajax_image-editor', array( __CLASS__, 'filter_image_editor_sizes' ), 0 );
		}

		if ( $settings['convert_webp'] ) {
			add_filter( 'image_editor_output_format', array( __CLASS__, 'output_format' ), 10 );

			if ( $settings['delete_originals'] ) {
				add_filter( 'wp_generate_attachment_metadata', array( __CLASS__, 'queue_original_check' ), 999, 2 );
			}
		}

		self::$quality = (int) $settings['webp_quality'];

		if ( self::WEBP_QUALITY !== self::$quality ) {
			add_filter( 'wp_editor_set_quality', array( __CLASS__, 'webp_quality' ), 10, 2 );
		}

		add_filter( 'wp_get_attachment_image_src', array( __CLASS__, 'track_size' ), 10, 3 );
		add_action( 'after_switch_theme', array( __CLASS__, 'flag_theme_switch' ) );
	}

	/**
	 * Encode quality for WebP output.
	 *
	 * The filter covers the server editor, the media library conversion and, from 7.1,
	 * client-side processing: the REST API reports the same filtered value.
	 *
	 * @since 1.0.0
	 * @param mixed  $quality   Quality level.
	 * @param string $mime_type Output mime type.
	 * @return mixed
	 */
	public static function webp_quality( $quality, $mime_type ) {
		return 'image/webp' === $mime_type ? self::$quality : $quality;
	}

	/**
	 * Remember a theme switch while sizes are disabled.
	 *
	 * Disabled sizes are stored by name, and the new theme may need one of them.
	 * The admin notice stays until the Uploads tab is opened.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function flag_theme_switch(): void {
		if ( self::$disabled ) {
			update_option( self::THEME_NOTICE, (string) wp_get_theme()->get( 'Name' ), true );
		}
	}

	/**
	 * Remove disabled sizes from a name => data map.
	 *
	 * @since 1.0.0
	 * @param mixed $sizes Size map.
	 * @return mixed
	 */
	public static function filter_size_map( $sizes ) {
		return is_array( $sizes ) ? array_diff_key( $sizes, array_flip( self::$disabled ) ) : $sizes;
	}

	/**
	 * Remove disabled sizes from a list of names.
	 *
	 * @since 1.0.0
	 * @param mixed $sizes Size names.
	 * @return mixed
	 */
	public static function filter_size_list( $sizes ) {
		return is_array( $sizes ) ? array_values( array_diff( $sizes, self::$disabled ) ) : $sizes;
	}

	/**
	 * Narrow the size registry for the classic image editor request only.
	 *
	 * The editor's wp_save_image() reads get_intermediate_image_sizes() directly.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function filter_image_editor_sizes(): void {
		add_filter( 'intermediate_image_sizes', array( __CLASS__, 'filter_size_list' ), 20 );
	}

	/**
	 * Save JPEG and PNG as WebP.
	 *
	 * @since 1.0.0
	 * @param mixed $formats Mime type map.
	 * @return mixed
	 */
	public static function output_format( $formats ) {
		if ( ! is_array( $formats ) || ! mvweb_mdc_can_write_webp() ) {
			return $formats;
		}

		// HEIC and HEIF are mapped to JPEG by the core; send them to WebP as well.
		foreach ( array( 'image/jpeg', 'image/png', 'image/heic', 'image/heif', 'image/heic-sequence', 'image/heif-sequence' ) as $mime ) {
			$formats[ $mime ] = 'image/webp';
		}

		return $formats;
	}

	/**
	 * Remember the uploaded source and check the original at shutdown.
	 *
	 * The check cannot run here: during the 7.1 client-side finalize this
	 * filter fires before the metadata is saved, so every size looks missing.
	 * The source name is kept because 7.1 drops it from original_image when
	 * the browser sideloads the -scaled file. A format the server cannot read
	 * (HEIC) has no original_image at all: the uploaded file itself is the source.
	 * An upload that already was WebP is not a conversion and is never recorded.
	 * Attachments converted from the library are left to the conversion task:
	 * their old files are deleted only by its final step.
	 *
	 * @since 1.0.0
	 * @param mixed $metadata      Attachment metadata.
	 * @param int   $attachment_id Attachment ID.
	 * @return mixed
	 */
	public static function queue_original_check( $metadata, $attachment_id ) {
		$attachment_id = (int) $attachment_id;

		if ( ! is_array( $metadata ) || metadata_exists( 'post', $attachment_id, MVweb_MDC_Converter::JOURNAL ) ) {
			return $metadata;
		}

		if ( '' === (string) get_post_meta( $attachment_id, self::SOURCE_META, true ) ) {
			$source = ! empty( $metadata['original_image'] ) ? (string) $metadata['original_image'] : wp_basename( (string) get_attached_file( $attachment_id, true ) );

			if ( '' !== $source && 'webp' !== strtolower( pathinfo( $source, PATHINFO_EXTENSION ) ) ) {
				update_post_meta( $attachment_id, self::SOURCE_META, $source );
			}
		}

		if ( empty( self::$queued ) ) {
			add_action( 'shutdown', array( __CLASS__, 'run_original_checks' ) );
		}

		self::$queued[ $attachment_id ] = true;

		return $metadata;
	}

	/**
	 * Run the queued original checks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function run_original_checks(): void {
		foreach ( array_keys( self::$queued ) as $attachment_id ) {
			self::delete_original( $attachment_id );
		}

		self::$queued = array();
	}

	/**
	 * Create the missing sizes of kept originals and delete the originals.
	 *
	 * Client-side processing in 7.1 sometimes leaves a size uncreated, so the
	 * original stays. Regenerating on the server completes the set.
	 *
	 * Attachments that still cannot be completed keep their record, so the
	 * source file stays tracked; the cursor moves past them.
	 *
	 * @since 1.0.0
	 * @param int   $after    Last processed attachment ID.
	 * @param float $deadline Unix time with microseconds.
	 * @return array{done: int, cursor: int, finished: bool, remaining: int}
	 */
	public static function complete_originals( int $after, float $deadline ): array {
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$done     = 0;
		$finished = true;
		$ids      = mvweb_mdc_kept_original_ids( $after, 20 );

		foreach ( $ids as $i => $id ) {
			wp_raise_memory_limit( 'image' );
			wp_update_image_subsizes( $id );

			if ( self::delete_original( $id ) ) {
				++$done;
			}

			unset( self::$queued[ $id ] );
			$after = $id;

			if ( microtime( true ) >= $deadline && isset( $ids[ $i + 1 ] ) ) {
				$finished = false;
				break;
			}
		}

		if ( 20 === count( $ids ) ) {
			$finished = false;
		}

		return array(
			'done'      => $done,
			'cursor'    => $after,
			'finished'  => $finished,
			'remaining' => mvweb_mdc_kept_originals_count(),
		);
	}

	/**
	 * Delete the original once the WebP version is complete.
	 *
	 * Deletes only when the main file is WebP by content, no size is missing
	 * and the attachment is local. Otherwise the original is kept.
	 *
	 * @since 1.0.0
	 * @param int $attachment_id Attachment ID.
	 * @return bool True when no original is left on disk.
	 */
	public static function delete_original( int $attachment_id ): bool {
		require_once ABSPATH . 'wp-admin/includes/image.php';

		wp_cache_delete( $attachment_id, 'post_meta' );

		$metadata = wp_get_attachment_metadata( $attachment_id, true );
		$main     = (string) get_attached_file( $attachment_id, true );
		$source   = (string) get_post_meta( $attachment_id, self::SOURCE_META, true );

		if ( '' === $source || ! is_array( $metadata ) || '' === $main || metadata_exists( 'post', $attachment_id, MVweb_MDC_Converter::JOURNAL ) || mvweb_mdc_is_offloaded( $attachment_id ) ) {
			return false;
		}

		// Not WebP yet: client-side processing may still replace the main file.
		if ( ! is_file( $main ) || ! filesize( $main ) || 'image/webp' !== wp_get_image_mime( $main ) ) {
			return false;
		}

		if ( array() !== wp_get_missing_image_subsizes( $attachment_id ) ) {
			return false;
		}

		$dir  = dirname( $main );
		$keep = array( wp_basename( $main ) );

		foreach ( $metadata['sizes'] ?? array() as $size ) {
			if ( ! empty( $size['file'] ) ) {
				$keep[] = wp_basename( (string) $size['file'] );
			}
		}

		$candidates = array_filter( array( (string) ( $metadata['original_image'] ?? '' ), (string) ( $metadata['source_image'] ?? '' ), $source ) );
		$candidates = array_diff( array_unique( array_map( 'wp_basename', $candidates ) ), $keep );

		foreach ( $candidates as $file ) {
			wp_delete_file_from_directory( $dir . '/' . $file, $dir );
		}

		clearstatcache();

		$left = array_filter(
			$candidates,
			static function ( string $file ) use ( $dir ): bool {
				return file_exists( $dir . '/' . $file );
			}
		);

		$changed = false;

		foreach ( array( 'original_image', 'source_image' ) as $key ) {
			if ( ! empty( $metadata[ $key ] ) && ! file_exists( $dir . '/' . wp_basename( (string) $metadata[ $key ] ) ) ) {
				unset( $metadata[ $key ] );
				$changed = true;
			}
		}

		if ( $changed ) {
			wp_update_attachment_metadata( $attachment_id, $metadata );
		}

		if ( $left ) {
			return false;
		}

		delete_post_meta( $attachment_id, self::SOURCE_META );

		if ( 'image/webp' !== get_post_mime_type( $attachment_id ) ) {
			wp_update_post(
				array(
					'ID'             => $attachment_id,
					'post_mime_type' => 'image/webp',
				)
			);
		}

		return true;
	}

	/**
	 * Record registered size names requested on the front end.
	 *
	 * Admin, AJAX and REST are skipped: REST returns every size in the
	 * metadata and would mark everything as used.
	 *
	 * @since 1.0.0
	 * @param mixed $image         Image data.
	 * @param mixed $attachment_id Attachment ID.
	 * @param mixed $size          Requested size.
	 * @return mixed
	 */
	public static function track_size( $image, $attachment_id, $size ) {
		if ( ! is_string( $size ) || 'full' === $size || isset( self::$seen[ $size ] ) ) {
			return $image;
		}

		if ( is_admin() || wp_doing_ajax() || wp_is_serving_rest_request() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return $image;
		}

		if ( empty( self::$seen ) ) {
			add_action( 'shutdown', array( __CLASS__, 'save_used_sizes' ) );
		}

		self::$seen[ $size ] = true;

		return $image;
	}

	/**
	 * Store newly seen registered size names in one write.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function save_used_sizes(): void {
		$used = get_option( self::USED_OPTION, array() );
		$used = is_array( $used ) ? $used : array();
		$new  = array_diff( array_intersect( array_keys( self::$seen ), mvweb_mdc_allowed_size_names() ), $used );

		if ( $new ) {
			update_option( self::USED_OPTION, array_values( array_merge( $used, $new ) ), true );
		}
	}
}
