<?php
/**
 * Helper functions for MVweb FAQ.
 *
 * @package mvweb_faq
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option key holding plugin settings.
 *
 * @since 1.0.0
 * @var string
 */
if ( ! defined( 'MVWEB_FAQ_OPTION' ) ) {
	define( 'MVWEB_FAQ_OPTION', 'mvweb_faq_settings' );
}

/**
 * Default plugin settings.
 *
 * @since 1.0.0
 * @return array<string, mixed>
 */
function mvweb_faq_get_defaults() {
	return array(
		'default_style'    => 'accordion', // accordion | open.
		'accordion_single' => false,        // true = only one item open at a time.
		'first_open'       => false,        // true = first item open on load (accordion).
		'schema_enabled'   => true,         // output FAQPage JSON-LD.
		'schema_dedupe'    => true,         // skip JSON-LD if another FAQPage already on page.
		'icon_type'        => 'plus',       // accordion icon, key of mvweb_faq_get_icons().
		'icon_shape'       => 'none',       // icon button shape: none|circle|square|rounded.
		'icon_color'       => '#793ea4',    // accordion icon color.
		'icon_bg'          => '#e7d9f1',    // icon button background (when shape is not none).
		'question_size'    => 0,            // question font size in px (0 = inherit from theme).
		'answer_size'      => 0,            // answer font size in px (0 = inherit from theme).
		'question_weight'  => 600,          // question font weight (400|500|600|700).
		'native_styles'    => false,        // true = do not enqueue our front-end CSS; theme styles the markup.
	);
}

/**
 * Accordion icon presets.
 *
 * @since 1.1.0
 * @return array<string, array{label: string, svg: string, open: string}>
 */
function mvweb_faq_get_icons() {
	return array(
		'plus'           => array(
			'label' => __( 'Plus to minus', 'mvweb-faq' ),
			'svg'   => '<path d="M5 12h14M12 5v14"/>',
			'open'  => '',
		),
		'plus-cross'     => array(
			'label' => __( 'Plus to cross', 'mvweb-faq' ),
			'svg'   => '<path d="M5 12h14M12 5v14"/>',
			'open'  => '45',
		),
		'chevron'        => array(
			'label' => __( 'Chevron down', 'mvweb-faq' ),
			'svg'   => '<path d="m6 9 6 6 6-6"/>',
			'open'  => '180',
		),
		'chevron-right'  => array(
			'label' => __( 'Chevron right', 'mvweb-faq' ),
			'svg'   => '<path d="m9 6 6 6-6 6"/>',
			'open'  => '90',
		),
		'chevrons'       => array(
			'label' => __( 'Double chevron', 'mvweb-faq' ),
			'svg'   => '<path d="m7 6 5 5 5-5M7 13l5 5 5-5"/>',
			'open'  => '180',
		),
		'arrow'          => array(
			'label' => __( 'Arrow down', 'mvweb-faq' ),
			'svg'   => '<path d="M12 5v14M6 13l6 6 6-6"/>',
			'open'  => '180',
		),
		'arrow-right'    => array(
			'label' => __( 'Arrow right', 'mvweb-faq' ),
			'svg'   => '<path d="M5 12h14M13 6l6 6-6 6"/>',
			'open'  => '90',
		),
		'arrow-diagonal' => array(
			'label' => __( 'Diagonal arrow', 'mvweb-faq' ),
			'svg'   => '<path d="M7 17 17 7M8 7h9v9"/>',
			'open'  => '90',
		),
		'caret'          => array(
			'label' => __( 'Triangle down', 'mvweb-faq' ),
			'svg'   => '<path d="M6 9h12l-6 7z" fill="currentColor"/>',
			'open'  => '180',
		),
		'caret-right'    => array(
			'label' => __( 'Triangle right', 'mvweb-faq' ),
			'svg'   => '<path d="M9 6v12l7-6z" fill="currentColor"/>',
			'open'  => '90',
		),
	);
}

/**
 * Inline SVG markup of an accordion icon preset.
 *
 * @since 1.1.0
 * @param string     $type  Icon key from mvweb_faq_get_icons().
 * @param array|null $icons Already loaded presets, to skip building them again.
 * @return string SVG markup, empty for an unknown key.
 */
function mvweb_faq_icon_svg( $type, $icons = null ) {
	$icons = is_array( $icons ) ? $icons : mvweb_faq_get_icons();
	if ( ! isset( $icons[ $type ] ) ) {
		return '';
	}
	return '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $icons[ $type ]['svg'] . '</svg>';
}

/**
 * Get merged plugin settings (stored over defaults).
 *
 * @since 1.0.0
 * @return array<string, mixed>
 */
function mvweb_faq_get_settings() {
	$stored = get_option( MVWEB_FAQ_OPTION, array() );
	if ( ! is_array( $stored ) ) {
		$stored = array();
	}
	return wp_parse_args( $stored, mvweb_faq_get_defaults() );
}

/**
 * Get a single setting value.
 *
 * @since 1.0.0
 * @param string $key      Setting key.
 * @param mixed  $fallback Fallback if key is missing.
 * @return mixed
 */
function mvweb_faq_get_setting( $key, $fallback = null ) {
	$settings = mvweb_faq_get_settings();
	return array_key_exists( $key, $settings ) ? $settings[ $key ] : $fallback;
}

/**
 * Detect a question string corrupted by a re-parsed shortcode.
 *
 * Some themes copy raw post content (incl. our shortcodes) into a hidden HTML
 * attribute via strip_tags()+esc_attr() and let it pass through do_shortcode()
 * a second time. There the attribute quotes are encoded (&quot; / &#034; / …),
 * so WordPress reads q= as an unquoted value and truncates it at the first
 * space, yielding garbage like "&quot;Сколько". Such items must never reach
 * the visible HTML or the FAQPage JSON-LD.
 *
 * @since 1.0.0
 * @param string $question Sanitized question text.
 * @return bool True when the question is a re-parse artifact.
 */
function mvweb_faq_is_corrupt_question( $question ) {
	$entity_prefixes = array( '&quot;', '&#034;', '&#34;', '&#039;', '&#39;' );
	foreach ( $entity_prefixes as $prefix ) {
		if ( 0 === strpos( $question, $prefix ) ) {
			return true;
		}
	}

	return false !== strpos( $question, '[mvweb_faq' );
}

/**
 * Allowed inline HTML tags for an answer body.
 *
 * @since 1.0.0
 * @return array<string, array<string, bool>>
 */
function mvweb_faq_allowed_answer_html() {
	return array(
		'a'      => array(
			'href'   => true,
			'title'  => true,
			'target' => true,
			'rel'    => true,
		),
		'strong' => array(),
		'b'      => array(),
		'em'     => array(),
		'i'      => array(),
		'br'     => array(),
		'ul'     => array(),
		'ol'     => array(),
		'li'     => array(),
		'span'   => array(),
	);
}
