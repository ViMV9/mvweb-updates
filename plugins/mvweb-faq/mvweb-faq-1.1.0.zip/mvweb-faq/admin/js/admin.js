/**
 * Admin JavaScript for MVweb FAQ.
 *
 * @package mvweb_faq
 * @since   1.0.0
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		initTabs();
		initColorPicker();
		initDesignBlock();
	});

	function initDesignBlock() {
		var toggle = document.getElementById('mvweb_faq_native_styles');
		var block = toggle ? toggle.closest('.mvweb-faq-design') : null;
		if (!block) {
			return;
		}
		var toggleRow = toggle.closest('.mvweb-form-row');
		var rows = block.querySelectorAll('.mvweb-form-row');

		function sync() {
			var native = toggle.checked;
			var shape = block.querySelector('input[name$="[icon_shape]"]:checked');
			var noShape = !shape || 'none' === shape.value;

			rows.forEach(function (row) {
				if (row === toggleRow) {
					return;
				}
				var off = native || (row.hasAttribute('data-mvweb-faq-needs-shape') && noShape);
				row.inert = off;
				row.style.opacity = off ? '0.5' : '';
			});
		}

		block.addEventListener('change', sync);
		sync();
	}

	function initColorPicker() {
		document.querySelectorAll('.mvweb-color-picker__swatch').forEach(function (input) {
			var value = input.parentNode.querySelector('.mvweb-color-picker__value');
			if (!value) {
				return;
			}
			input.addEventListener('input', function () {
				value.textContent = input.value;
			});
		});
	}

	function initTabs() {
		var links = document.querySelectorAll('.mvweb-nav .mvweb-nav__link');
		var panels = document.querySelectorAll('.mvweb-tab-content');

		if (!links.length || !panels.length) {
			return;
		}

		links.forEach(function (link) {
			link.addEventListener('click', function (event) {
				event.preventDefault();

				var target = link.getAttribute('data-tab') || (link.getAttribute('href') || '').replace('#', '');
				if (!target) {
					return;
				}

				links.forEach(function (l) { l.classList.remove('mvweb-nav__link--active'); });
				panels.forEach(function (p) { p.classList.remove('active'); });

				link.classList.add('mvweb-nav__link--active');

				var panel = document.getElementById(target);
				if (panel) {
					panel.classList.add('active');
				}
			});
		});
	}
})();
