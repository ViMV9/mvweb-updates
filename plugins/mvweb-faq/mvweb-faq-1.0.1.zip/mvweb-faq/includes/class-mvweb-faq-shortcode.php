<?php
/**
 * Shortcode registration and rendering for MVweb FAQ.
 *
 * Registers [mvweb_faq] (container) and [mvweb_faq_item] (nested item).
 * Items are collected during the container parse and rendered as a list.
 *
 * @package mvweb_faq
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_FAQ_Shortcode
 *
 * @since 1.0.0
 */
class MVweb_FAQ_Shortcode {

	/**
	 * Question/answer pairs collected from the container being parsed.
	 *
	 * @since 1.0.0
	 * @var array<int, array{q: string, a: string}>
	 */
	private static $current_items = array();

	/**
	 * Container nesting depth; items are collected only while > 0.
	 *
	 * @since 1.0.0
	 * @var int
	 */
	private static $depth = 0;

	/**
	 * Running counter to give each container a unique exclusive-group name.
	 *
	 * @since 1.0.0
	 * @var int
	 */
	private static $group_index = 0;

	/**
	 * Initialize shortcodes and asset registration.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_shortcode( 'mvweb_faq', array( __CLASS__, 'render_container' ) );
		add_shortcode( 'mvweb_faq_item', array( __CLASS__, 'collect_item' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );

		if ( ! has_filter( 'widget_text', 'do_shortcode' ) ) {
			add_filter( 'widget_text', 'do_shortcode' );
		}
	}

	/**
	 * Register (but do not enqueue) frontend assets.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_assets() {
		$css_path = MVWEB_FAQ_PATH . 'public/css/faq.min.css';

		wp_register_style(
			'mvweb-faq',
			MVWEB_FAQ_URL . 'public/css/faq.min.css',
			array(),
			file_exists( $css_path ) ? (string) filemtime( $css_path ) : MVWEB_FAQ_VERSION
		);
	}

	/**
	 * Collect a single [mvweb_faq_item] into the current container buffer.
	 *
	 * Returns an empty string: items have no standalone output.
	 *
	 * @since 1.0.0
	 * @param array|string $atts    Item attributes (expects 'q').
	 * @param string|null  $content Answer body (may contain inline HTML).
	 * @return string Always empty.
	 */
	public static function collect_item( $atts, $content = null ) {
		if ( self::$depth < 1 ) {
			return '';
		}

		$atts     = shortcode_atts( array( 'q' => '' ), $atts, 'mvweb_faq_item' );
		$question = sanitize_text_field( (string) $atts['q'] );

		if ( '' === $question || mvweb_faq_is_corrupt_question( $question ) ) {
			return '';
		}

		$answer = wp_kses( (string) $content, mvweb_faq_allowed_answer_html() );
		$answer = wp_targeted_link_rel( $answer );

		self::$current_items[] = array(
			'q' => $question,
			'a' => $answer,
		);

		return '';
	}

	/**
	 * Render the [mvweb_faq] container.
	 *
	 * @since 1.0.0
	 * @param array|string $atts    Container attributes.
	 * @param string|null  $content Nested item shortcodes.
	 * @return string FAQ HTML.
	 */
	public static function render_container( $atts, $content = null ) {
		$settings = mvweb_faq_get_settings();

		$atts = shortcode_atts(
			array(
				'style' => $settings['default_style'],
				'color' => '',
			),
			$atts,
			'mvweb_faq'
		);

		$style = in_array( $atts['style'], array( 'accordion', 'open' ), true )
			? $atts['style']
			: $settings['default_style'];

		$block_color = '' !== $atts['color'] ? (string) sanitize_hex_color( (string) $atts['color'] ) : '';

		$parent_items        = self::$current_items;
		self::$current_items = array();
		++self::$depth;
		do_shortcode( (string) $content );
		--self::$depth;

		$items               = self::$current_items;
		self::$current_items = $parent_items;
		if ( empty( $items ) ) {
			return '';
		}

		if ( empty( $settings['native_styles'] ) ) {
			wp_enqueue_style( 'mvweb-faq' );
		}

		if ( ! empty( $settings['schema_enabled'] ) && class_exists( 'MVweb_FAQ_Schema' ) ) {
			MVweb_FAQ_Schema::add_items( $items );
		}

		return self::build_html( $items, $style, $settings, $block_color );
	}

	/**
	 * Build the FAQ markup from collected items.
	 *
	 * @since 1.0.0
	 * @param array<int, array{q: string, a: string}> $items    Q/A pairs.
	 * @param string                                  $style    accordion|open.
	 * @param array<string, mixed>                    $settings Plugin settings.
	 * @param string                                  $color    Optional per-block icon color override.
	 * @return string
	 */
	private static function build_html( $items, $style, $settings, $color = '' ) {
		$is_accordion = ( 'accordion' === $style );
		$single       = ! empty( $settings['accordion_single'] );
		$first_open   = ! empty( $settings['first_open'] );

		$classes = array( 'mvweb-faq', 'mvweb-faq--' . $style );

		$group_name = '';
		if ( $is_accordion && $single ) {
			$classes[]  = 'mvweb-faq--single';
			$group_name = ' name="mvweb-faq-' . ( ++self::$group_index ) . '"';
		}

		$style_attr = '';
		if ( empty( $settings['native_styles'] ) ) {
			$vars       = array();
			$icon_color = $color ? $color : ( ! empty( $settings['icon_color'] ) ? sanitize_hex_color( (string) $settings['icon_color'] ) : '' );
			if ( $icon_color ) {
				$vars[] = '--mvweb-faq-icon: ' . $icon_color;
			}
			$q_size = (int) ( $settings['question_size'] ?? 0 );
			if ( $q_size > 0 ) {
				$vars[] = '--mvweb-faq-q-size: ' . $q_size . 'px';
			}
			$a_size = (int) ( $settings['answer_size'] ?? 0 );
			if ( $a_size > 0 ) {
				$vars[] = '--mvweb-faq-a-size: ' . $a_size . 'px';
			}
			$q_weight = (int) ( $settings['question_weight'] ?? 600 );
			if ( $q_weight > 0 ) {
				$vars[] = '--mvweb-faq-q-weight: ' . $q_weight;
			}
			if ( $vars ) {
				$style_attr = ' style="' . esc_attr( implode( '; ', $vars ) ) . '"';
			}
		}

		$out = '<div class="' . esc_attr( implode( ' ', $classes ) ) . '"' . $style_attr . '>';

		foreach ( $items as $index => $item ) {
			$open = '';
			if ( ! $is_accordion ) {
				$open = ' open';
			} elseif ( $first_open && 0 === $index ) {
				$open = ' open';
			}

			$out .= '<details class="mvweb-faq__item"' . $group_name . $open . '>';
			$out .= '<summary class="mvweb-faq__question">';
			$out .= '<span class="mvweb-faq__question-text">' . esc_html( $item['q'] ) . '</span>';
			$out .= '<span class="mvweb-faq__icon" aria-hidden="true"></span>';
			$out .= '</summary>';
			$out .= '<div class="mvweb-faq__answer">' . $item['a'] . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- already sanitized via wp_kses() in collect_item().
			$out .= '</details>';
		}

		$out .= '</div>';

		return $out;
	}
}
