<?php
/**
 * General settings tab.
 *
 * @package mvweb_faq
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_faq_s = mvweb_faq_get_settings();
?>

<form method="post" action="">
	<?php wp_nonce_field( 'mvweb_faq_save_settings', 'mvweb_faq_settings_nonce' ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Display', 'mvweb-faq' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'How FAQ blocks render on the front end.', 'mvweb-faq' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb_faq_default_style" class="mvweb-form-row__label">
				<?php esc_html_e( 'Default style', 'mvweb-faq' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_faq_default_style"
					name="<?php echo esc_attr( MVWEB_FAQ_OPTION ); ?>[default_style]"
					class="mvweb-select">
					<option value="accordion" <?php selected( $mvweb_faq_s['default_style'], 'accordion' ); ?>>
						<?php esc_html_e( 'Accordion (collapsed)', 'mvweb-faq' ); ?>
					</option>
					<option value="open" <?php selected( $mvweb_faq_s['default_style'], 'open' ); ?>>
						<?php esc_html_e( 'Open (expanded)', 'mvweb-faq' ); ?>
					</option>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Default for new FAQ blocks. Each block can override this on insert.', 'mvweb-faq' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_faq_accordion_single" class="mvweb-form-row__label">
				<?php esc_html_e( 'One item open at a time', 'mvweb-faq' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_faq_accordion_single"
							name="<?php echo esc_attr( MVWEB_FAQ_OPTION ); ?>[accordion_single]"
							value="1"
							<?php checked( $mvweb_faq_s['accordion_single'] ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Opening one answer closes the others (accordion style)', 'mvweb-faq' ); ?></span>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_faq_first_open" class="mvweb-form-row__label">
				<?php esc_html_e( 'First item open on load', 'mvweb-faq' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_faq_first_open"
							name="<?php echo esc_attr( MVWEB_FAQ_OPTION ); ?>[first_open]"
							value="1"
							<?php checked( $mvweb_faq_s['first_open'] ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Show the first answer expanded (accordion style)', 'mvweb-faq' ); ?></span>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_faq_icon_color" class="mvweb-form-row__label">
				<?php esc_html_e( 'Accordion icon color', 'mvweb-faq' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-color-picker">
					<input type="color"
						id="mvweb_faq_icon_color"
						name="<?php echo esc_attr( MVWEB_FAQ_OPTION ); ?>[icon_color]"
						class="mvweb-color-picker__swatch"
						value="<?php echo esc_attr( $mvweb_faq_s['icon_color'] ); ?>">
					<span class="mvweb-color-picker__value"><?php echo esc_html( $mvweb_faq_s['icon_color'] ); ?></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Color of the expand/collapse icon in accordion style.', 'mvweb-faq' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_faq_question_size" class="mvweb-form-row__label">
				<?php esc_html_e( 'Question font size', 'mvweb-faq' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number" min="0" max="72" step="1"
					id="mvweb_faq_question_size"
					name="<?php echo esc_attr( MVWEB_FAQ_OPTION ); ?>[question_size]"
					class="mvweb-input mvweb-input--narrow"
					value="<?php echo esc_attr( (string) $mvweb_faq_s['question_size'] ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'In pixels. Leave 0 to inherit from the theme.', 'mvweb-faq' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_faq_answer_size" class="mvweb-form-row__label">
				<?php esc_html_e( 'Answer font size', 'mvweb-faq' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number" min="0" max="72" step="1"
					id="mvweb_faq_answer_size"
					name="<?php echo esc_attr( MVWEB_FAQ_OPTION ); ?>[answer_size]"
					class="mvweb-input mvweb-input--narrow"
					value="<?php echo esc_attr( (string) $mvweb_faq_s['answer_size'] ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'In pixels. Leave 0 to inherit from the theme.', 'mvweb-faq' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_faq_question_weight" class="mvweb-form-row__label">
				<?php esc_html_e( 'Question font weight', 'mvweb-faq' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_faq_question_weight"
					name="<?php echo esc_attr( MVWEB_FAQ_OPTION ); ?>[question_weight]"
					class="mvweb-select">
					<option value="400" <?php selected( $mvweb_faq_s['question_weight'], 400 ); ?>><?php esc_html_e( 'Regular (400)', 'mvweb-faq' ); ?></option>
					<option value="500" <?php selected( $mvweb_faq_s['question_weight'], 500 ); ?>><?php esc_html_e( 'Medium (500)', 'mvweb-faq' ); ?></option>
					<option value="600" <?php selected( $mvweb_faq_s['question_weight'], 600 ); ?>><?php esc_html_e( 'Semibold (600)', 'mvweb-faq' ); ?></option>
					<option value="700" <?php selected( $mvweb_faq_s['question_weight'], 700 ); ?>><?php esc_html_e( 'Bold (700)', 'mvweb-faq' ); ?></option>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_faq_native_styles" class="mvweb-form-row__label">
				<?php esc_html_e( 'Use theme styles', 'mvweb-faq' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_faq_native_styles"
							name="<?php echo esc_attr( MVWEB_FAQ_OPTION ); ?>[native_styles]"
							value="1"
							<?php checked( $mvweb_faq_s['native_styles'] ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Do not load the plugin CSS — let the theme style the FAQ markup', 'mvweb-faq' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'When on, the font size, weight and icon color options above are not applied.', 'mvweb-faq' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Schema (structured data)', 'mvweb-faq' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'FAQPage JSON-LD markup for Yandex and Google.', 'mvweb-faq' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb_faq_schema_enabled" class="mvweb-form-row__label">
				<?php esc_html_e( 'Output JSON-LD', 'mvweb-faq' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_faq_schema_enabled"
							name="<?php echo esc_attr( MVWEB_FAQ_OPTION ); ?>[schema_enabled]"
							value="1"
							<?php checked( $mvweb_faq_s['schema_enabled'] ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Add one FAQPage block per page', 'mvweb-faq' ); ?></span>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_faq_schema_dedupe" class="mvweb-form-row__label">
				<?php esc_html_e( 'Avoid duplicates', 'mvweb-faq' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_faq_schema_dedupe"
							name="<?php echo esc_attr( MVWEB_FAQ_OPTION ); ?>[schema_dedupe]"
							value="1"
							<?php checked( $mvweb_faq_s['schema_dedupe'] ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Skip our JSON-LD if a Yoast FAQ block already outputs FAQPage', 'mvweb-faq' ); ?></span>
				</div>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" name="mvweb_faq_save_settings" value="1" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Save Changes', 'mvweb-faq' ); ?>
		</button>
		<span class="mvweb-submit__hint"><kbd>⌘ S</kbd></span>
	</div>
</form>
