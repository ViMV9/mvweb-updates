<?php
/**
 * Plugin Name:       MVweb FAQ
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-faq
 * Description:       Блоки «вопрос-ответ» (FAQ) с микроразметкой Schema.org. Вставка через кнопку в классическом редакторе.
 * Version:           1.0.2
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-faq
 * Domain Path:       /languages
 *
 * @package mvweb_faq
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_FAQ_VERSION' ) ) {
	return;
}

define( 'MVWEB_FAQ_VERSION', '1.0.2' );
define( 'MVWEB_FAQ_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_FAQ_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_FAQ_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_FAQ_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_FAQ_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_FAQ_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_FAQ_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_FAQ_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-faq' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-faq'] = array(
		'name'         => 'MVweb FAQ',
		'description'  => __( 'Блоки «вопрос-ответ» (FAQ) с микроразметкой Schema.org. Вставка через кнопку в классическом редакторе.', 'mvweb-faq' ),
		'url'          => 'https://mvweb.ru/plugins/mvweb-faq',
		'settings_url' => 'admin.php?page=mvweb-faq',
		'textdomain'   => 'mvweb-faq',
	);
	return $plugins;
} );

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_faq_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-faq',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_faq_load_textdomain' );

// ───────────────────────────────────────────────
// Plugin classes
// ───────────────────────────────────────────────
require_once MVWEB_FAQ_PATH . 'includes/helpers.php';
require_once MVWEB_FAQ_PATH . 'includes/class-mvweb-faq-settings.php';
require_once MVWEB_FAQ_PATH . 'includes/class-mvweb-faq-admin.php';
require_once MVWEB_FAQ_PATH . 'includes/class-mvweb-faq-schema.php';
require_once MVWEB_FAQ_PATH . 'includes/class-mvweb-faq-shortcode.php';
require_once MVWEB_FAQ_PATH . 'includes/class-mvweb-faq-editor.php';

MVweb_FAQ_Admin::init();
MVweb_FAQ_Schema::init();
MVweb_FAQ_Shortcode::init();
MVweb_FAQ_Editor::init();
