<?php
/**
 * Admin page for MVweb FAQ.
 *
 * Registers the submenu under MVweb Hub, enqueues admin assets,
 * processes settings, and renders the settings page.
 *
 * @package mvweb_faq
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_FAQ_Admin
 *
 * @since 1.0.0
 */
class MVweb_FAQ_Admin {

	/**
	 * Admin page hook suffix.
	 *
	 * @var string
	 */
	private static $hook_suffix = '';

	/**
	 * Initialize admin hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_init', array( __CLASS__, 'process_settings' ) );
	}

	/**
	 * Register submenu page under MVweb Hub.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_menu() {
		if ( ! class_exists( 'MVweb_Menu' ) ) {
			return;
		}

		self::$hook_suffix = add_submenu_page(
			MVweb_Menu::get_menu_slug(),
			__( 'FAQ', 'mvweb-faq' ),
			__( 'FAQ', 'mvweb-faq' ),
			'manage_options',
			'mvweb-faq',
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Enqueue admin CSS and JS on the plugin page only.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		if ( self::$hook_suffix !== $hook ) {
			return;
		}

		$admin_css  = MVWEB_FAQ_PATH . 'admin/css/admin.min.css';
		$plugin_css = MVWEB_FAQ_PATH . 'admin/css/plugin.min.css';
		$admin_js   = MVWEB_FAQ_PATH . 'admin/js/admin.min.js';

		wp_enqueue_style(
			'mvweb-faq-admin',
			MVWEB_FAQ_URL . 'admin/css/admin.min.css',
			array(),
			file_exists( $admin_css ) ? (string) filemtime( $admin_css ) : MVWEB_FAQ_VERSION
		);

		wp_enqueue_style(
			'mvweb-faq-plugin',
			MVWEB_FAQ_URL . 'admin/css/plugin.min.css',
			array( 'mvweb-faq-admin' ),
			file_exists( $plugin_css ) ? (string) filemtime( $plugin_css ) : MVWEB_FAQ_VERSION
		);

		wp_enqueue_script(
			'mvweb-faq-admin',
			MVWEB_FAQ_URL . 'admin/js/admin.min.js',
			array( 'jquery' ),
			file_exists( $admin_js ) ? (string) filemtime( $admin_js ) : MVWEB_FAQ_VERSION,
			true
		);
	}

	/**
	 * Process settings form submission on admin_init (before output).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function process_settings() {
		if ( empty( $_POST['mvweb_faq_save_settings'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		MVweb_FAQ_Settings::handle_save();

		wp_safe_redirect( admin_url( 'admin.php?page=mvweb-faq&tab=general&saved=1' ) );
		exit;
	}

	/**
	 * Render the settings page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'mvweb-faq' ) );
		}

		if ( isset( $_GET['saved'] ) && '1' === $_GET['saved'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only notice flag.
			add_settings_error(
				'mvweb_faq_messages',
				'mvweb_faq_saved',
				__( 'Settings saved.', 'mvweb-faq' ),
				'updated'
			);
		}

		require MVWEB_FAQ_PATH . 'admin/views/settings-page.php';
	}
}
