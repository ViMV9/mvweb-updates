<?php
/**
 * Settings storage and processing for MVweb FAQ.
 *
 * Uses the Options API (single option array, autoload=false).
 *
 * @package mvweb_faq
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_FAQ_Settings
 *
 * @since 1.0.0
 */
class MVweb_FAQ_Settings {

	/**
	 * Sanitize the full settings array.
	 *
	 * @since 1.0.0
	 * @param mixed $input Raw input.
	 * @return array<string, mixed>
	 */
	public static function sanitize( $input ) {
		$defaults = mvweb_faq_get_defaults();
		$input    = is_array( $input ) ? $input : array();
		$out      = array();

		$style                 = isset( $input['default_style'] ) ? sanitize_key( $input['default_style'] ) : $defaults['default_style'];
		$out['default_style']  = in_array( $style, array( 'accordion', 'open' ), true ) ? $style : $defaults['default_style'];
		$out['accordion_single'] = ! empty( $input['accordion_single'] );
		$out['first_open']       = ! empty( $input['first_open'] );
		$out['schema_enabled']   = ! empty( $input['schema_enabled'] );
		$out['schema_dedupe']    = ! empty( $input['schema_dedupe'] );

		$color              = isset( $input['icon_color'] ) ? sanitize_hex_color( $input['icon_color'] ) : '';
		$out['icon_color']  = $color ? $color : $defaults['icon_color'];

		$out['question_size'] = isset( $input['question_size'] ) ? min( 72, absint( $input['question_size'] ) ) : 0;
		$out['answer_size']   = isset( $input['answer_size'] ) ? min( 72, absint( $input['answer_size'] ) ) : 0;

		$weight                = isset( $input['question_weight'] ) ? absint( $input['question_weight'] ) : $defaults['question_weight'];
		$out['question_weight'] = in_array( $weight, array( 400, 500, 600, 700 ), true ) ? $weight : $defaults['question_weight'];

		$out['native_styles'] = ! empty( $input['native_styles'] );

		return $out;
	}

	/**
	 * Handle the settings form save (called from admin process_settings).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function handle_save() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions.', 'mvweb-faq' ) );
		}

		if ( ! isset( $_POST['mvweb_faq_settings_nonce'] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mvweb_faq_settings_nonce'] ) ), 'mvweb_faq_save_settings' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'mvweb-faq' ) );
		}

		$raw = isset( $_POST[ MVWEB_FAQ_OPTION ] ) ? wp_unslash( $_POST[ MVWEB_FAQ_OPTION ] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- sanitized in self::sanitize().
		update_option( MVWEB_FAQ_OPTION, self::sanitize( $raw ), false );
	}
}
