<?php
/**
 * FAQPage JSON-LD output for MVweb FAQ.
 *
 * Collects question/answer pairs from every FAQ block rendered on the page
 * and prints a single FAQPage graph in the footer.
 *
 * @package mvweb_faq
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_FAQ_Schema
 *
 * @since 1.0.0
 */
class MVweb_FAQ_Schema {

	/**
	 * Questions gathered from all FAQ blocks on the current request.
	 *
	 * @since 1.0.0
	 * @var array<int, array{q: string, a: string}>
	 */
	private static $questions = array();

	/**
	 * Whether the footer output hook is registered.
	 *
	 * @since 1.0.0
	 * @var bool
	 */
	private static $hooked = false;

	/**
	 * Initialize the class.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		self::$questions = array();
		self::$hooked    = false;
	}

	/**
	 * Add a block's question/answer pairs to the page-wide buffer.
	 *
	 * @since 1.0.0
	 * @param array<int, array{q: string, a: string}> $items Q/A pairs.
	 * @return void
	 */
	public static function add_items( $items ) {
		if ( empty( $items ) ) {
			return;
		}

		foreach ( $items as $item ) {
			$question = isset( $item['q'] ) ? trim( (string) $item['q'] ) : '';
			if ( '' === $question ) {
				continue;
			}
			self::$questions[] = array(
				'q' => $question,
				'a' => isset( $item['a'] ) ? (string) $item['a'] : '',
			);
		}

		if ( ! self::$hooked ) {
			add_action( 'wp_footer', array( __CLASS__, 'print_schema' ), 20 );
			self::$hooked = true;
		}
	}

	/**
	 * Print a single FAQPage JSON-LD graph in the footer.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function print_schema() {
		if ( empty( self::$questions ) || self::should_skip() ) {
			return;
		}

		$entities = array();
		$seen     = array();
		foreach ( self::$questions as $item ) {
			$answer_text = self::answer_text( $item['a'] );
			if ( '' === $answer_text ) {
				continue;
			}
			$key = mb_strtolower( $item['q'] );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$entities[]   = array(
				'@type'          => 'Question',
				'name'           => $item['q'],
				'acceptedAnswer' => array(
					'@type' => 'Answer',
					'text'  => $answer_text,
				),
			);
		}

		if ( empty( $entities ) ) {
			return;
		}

		$graph = array(
			'@context'   => 'https://schema.org',
			'@type'      => 'FAQPage',
			'mainEntity' => $entities,
		);

		$json = wp_json_encode( $graph, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG );
		if ( false === $json ) {
			return;
		}

		echo "\n" . '<script type="application/ld+json">' . $json . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- wp_json_encode with JSON_HEX_TAG escapes angle brackets.
	}

	/**
	 * Decide whether our JSON-LD should be suppressed to avoid duplicates.
	 *
	 * Skips output when the dedupe option is on and the current post already
	 * carries a Yoast FAQ block (which emits its own FAQPage).
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	private static function should_skip() {
		if ( empty( mvweb_faq_get_setting( 'schema_dedupe', true ) ) ) {
			return false;
		}

		if ( ! is_singular() ) {
			return false;
		}

		$post = get_post();
		if ( ! $post instanceof WP_Post ) {
			return false;
		}

		return has_block( 'yoast/faq-block', $post );
	}

	/**
	 * Normalize an already-sanitized answer to schema plain text.
	 *
	 * The answer is sanitized via wp_kses() when collected by the shortcode.
	 * Search engines expect plain text in acceptedAnswer.text, so HTML tags
	 * are stripped before whitespace is collapsed and trimmed.
	 *
	 * @since 1.0.0
	 * @param string $answer Sanitized answer HTML.
	 * @return string
	 */
	private static function answer_text( $answer ) {
		$answer = wp_strip_all_tags( (string) $answer );
		$answer = preg_replace( '/\s+/', ' ', $answer );
		return trim( (string) $answer );
	}
}
