<?php
/**
 * Classic editor integration for MVweb FAQ.
 *
 * Adds an "FAQ" button to the TinyMCE (Visual) and Quicktags (Text) toolbars,
 * enqueues the editor assets, and prints the builder modal in the admin footer.
 *
 * @package mvweb_faq
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_FAQ_Editor
 *
 * @since 1.0.0
 */
class MVweb_FAQ_Editor {

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_print_footer_scripts', array( __CLASS__, 'register_quicktag' ), 100 );
		add_action( 'admin_footer', array( __CLASS__, 'print_modal' ) );

		add_filter( 'mce_external_plugins', array( __CLASS__, 'register_tinymce_plugin' ) );
		add_filter( 'mce_buttons', array( __CLASS__, 'register_tinymce_button' ) );
	}

	/**
	 * Whether the current admin screen uses the classic editor.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	private static function is_editor_screen() {
		if ( ! function_exists( 'get_current_screen' ) ) {
			return false;
		}

		$screen = get_current_screen();
		if ( ! $screen ) {
			return false;
		}

		if ( 'post' !== $screen->base ) {
			return false;
		}

		return ! ( method_exists( $screen, 'is_block_editor' ) && $screen->is_block_editor() );
	}

	/**
	 * Enqueue builder CSS/JS on classic editor screens only.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		if ( 'post.php' !== $hook && 'post-new.php' !== $hook ) {
			return;
		}

		if ( ! self::is_editor_screen() ) {
			return;
		}

		$css_path = MVWEB_FAQ_PATH . 'admin/css/plugin.min.css';
		$js_path  = MVWEB_FAQ_PATH . 'admin/js/editor.min.js';

		wp_enqueue_style(
			'mvweb-faq-editor',
			MVWEB_FAQ_URL . 'admin/css/plugin.min.css',
			array(),
			file_exists( $css_path ) ? (string) filemtime( $css_path ) : MVWEB_FAQ_VERSION
		);

		wp_enqueue_script(
			'mvweb-faq-editor',
			MVWEB_FAQ_URL . 'admin/js/editor.min.js',
			array( 'jquery', 'jquery-ui-sortable' ),
			file_exists( $js_path ) ? (string) filemtime( $js_path ) : MVWEB_FAQ_VERSION,
			true
		);

		$settings = mvweb_faq_get_settings();

		wp_localize_script(
			'mvweb-faq-editor',
			'mvwebFaqEditor',
			array(
				'defaultStyle' => in_array( $settings['default_style'], array( 'accordion', 'open' ), true ) ? $settings['default_style'] : 'accordion',
				'i18n'         => array(
					'title'        => __( 'Insert FAQ', 'mvweb-faq' ),
					'question'     => __( 'Question', 'mvweb-faq' ),
					'answer'       => __( 'Answer', 'mvweb-faq' ),
					'questionPh'   => __( 'Enter the question…', 'mvweb-faq' ),
					'answerPh'     => __( 'Enter the answer…', 'mvweb-faq' ),
					'addItem'      => __( 'Add question', 'mvweb-faq' ),
					'remove'       => __( 'Remove', 'mvweb-faq' ),
					'collapse'     => __( 'Collapse', 'mvweb-faq' ),
					'style'        => __( 'Style', 'mvweb-faq' ),
					'styleAcc'     => __( 'Accordion (collapsed)', 'mvweb-faq' ),
					'styleOpen'    => __( 'Open (expanded)', 'mvweb-faq' ),
					'insert'       => __( 'Insert', 'mvweb-faq' ),
					'cancel'       => __( 'Cancel', 'mvweb-faq' ),
					'bold'         => __( 'Bold', 'mvweb-faq' ),
					'link'         => __( 'Link', 'mvweb-faq' ),
					'list'         => __( 'List', 'mvweb-faq' ),
					'linkPrompt'   => __( 'Enter URL:', 'mvweb-faq' ),
					'words'        => __( 'words', 'mvweb-faq' ),
					'longAnswer'   => __( 'Answer is long — consider splitting it.', 'mvweb-faq' ),
					'emptyError'   => __( 'Add at least one question with an answer.', 'mvweb-faq' ),
				),
			)
		);
	}

	/**
	 * Register the TinyMCE plugin script.
	 *
	 * @since 1.0.0
	 * @param array<string, string> $plugins Registered external TinyMCE plugins.
	 * @return array<string, string>
	 */
	public static function register_tinymce_plugin( $plugins ) {
		if ( ! self::is_editor_screen() ) {
			return $plugins;
		}

		$js_path = MVWEB_FAQ_PATH . 'admin/js/tinymce-plugin.min.js';
		$version = file_exists( $js_path ) ? (string) filemtime( $js_path ) : MVWEB_FAQ_VERSION;

		$plugins['mvweb_faq'] = MVWEB_FAQ_URL . 'admin/js/tinymce-plugin.min.js?ver=' . rawurlencode( $version );

		return $plugins;
	}

	/**
	 * Add the FAQ button to the first TinyMCE toolbar row.
	 *
	 * @since 1.0.0
	 * @param array<int, string> $buttons Toolbar buttons.
	 * @return array<int, string>
	 */
	public static function register_tinymce_button( $buttons ) {
		if ( ! self::is_editor_screen() ) {
			return $buttons;
		}

		$buttons[] = 'mvweb_faq';

		return $buttons;
	}

	/**
	 * Register the Quicktags (Text mode) button.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_quicktag() {
		if ( ! self::is_editor_screen() ) {
			return;
		}
		?>
		<script>
		if ( typeof QTags !== 'undefined' ) {
			QTags.addButton( 'mvweb_faq', 'FAQ', function () {
				if ( window.mvwebFaqOpenModal ) {
					window.mvwebFaqOpenModal( 'quicktags' );
				}
			} );
		}
		</script>
		<?php
	}

	/**
	 * Print the builder modal markup in the admin footer.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function print_modal() {
		if ( ! self::is_editor_screen() ) {
			return;
		}

		require MVWEB_FAQ_PATH . 'admin/views/editor-modal.php';
	}
}
