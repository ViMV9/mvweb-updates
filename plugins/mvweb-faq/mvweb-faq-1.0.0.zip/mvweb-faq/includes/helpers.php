<?php
/**
 * Helper functions for MVweb FAQ.
 *
 * @package mvweb_faq
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Option key holding plugin settings.
 *
 * @since 1.0.0
 * @var string
 */
if ( ! defined( 'MVWEB_FAQ_OPTION' ) ) {
	define( 'MVWEB_FAQ_OPTION', 'mvweb_faq_settings' );
}

/**
 * Default plugin settings.
 *
 * @since 1.0.0
 * @return array<string, mixed>
 */
function mvweb_faq_get_defaults() {
	return array(
		'default_style'    => 'accordion', // accordion | open.
		'accordion_single' => false,        // true = only one item open at a time.
		'first_open'       => false,        // true = first item open on load (accordion).
		'schema_enabled'   => true,         // output FAQPage JSON-LD.
		'schema_dedupe'    => true,         // skip JSON-LD if another FAQPage already on page.
		'icon_color'       => '#793ea4',    // accordion icon color.
		'question_size'    => 0,            // question font size in px (0 = inherit from theme).
		'answer_size'      => 0,            // answer font size in px (0 = inherit from theme).
		'question_weight'  => 600,          // question font weight (400|500|600|700).
		'native_styles'    => false,        // true = do not enqueue our front-end CSS; theme styles the markup.
	);
}

/**
 * Get merged plugin settings (stored over defaults).
 *
 * @since 1.0.0
 * @return array<string, mixed>
 */
function mvweb_faq_get_settings() {
	$stored = get_option( MVWEB_FAQ_OPTION, array() );
	if ( ! is_array( $stored ) ) {
		$stored = array();
	}
	return wp_parse_args( $stored, mvweb_faq_get_defaults() );
}

/**
 * Get a single setting value.
 *
 * @since 1.0.0
 * @param string $key      Setting key.
 * @param mixed  $fallback Fallback if key is missing.
 * @return mixed
 */
function mvweb_faq_get_setting( $key, $fallback = null ) {
	$settings = mvweb_faq_get_settings();
	return array_key_exists( $key, $settings ) ? $settings[ $key ] : $fallback;
}

/**
 * Allowed inline HTML tags for an answer body.
 *
 * @since 1.0.0
 * @return array<string, array<string, bool>>
 */
function mvweb_faq_allowed_answer_html() {
	return array(
		'a'      => array(
			'href'   => true,
			'title'  => true,
			'target' => true,
			'rel'    => true,
		),
		'strong' => array(),
		'b'      => array(),
		'em'     => array(),
		'i'      => array(),
		'br'     => array(),
		'ul'     => array(),
		'ol'     => array(),
		'li'     => array(),
		'span'   => array(),
	);
}
