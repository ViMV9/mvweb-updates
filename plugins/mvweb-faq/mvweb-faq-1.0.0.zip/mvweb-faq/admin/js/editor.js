/**
 * FAQ builder modal logic for the classic editor.
 *
 * Exposes window.mvwebFaqOpenModal(mode) used by the TinyMCE button and the
 * Quicktags button. Builds the [mvweb_faq] shortcode and inserts it into the
 * active editor (Visual or Text).
 *
 * @package mvweb_faq
 * @since   1.0.0
 */

(function () {
	'use strict';

	var cfg = window.mvwebFaqEditor || { defaultStyle: 'accordion', i18n: {} };
	var modal, itemsWrap, tpl, styleSelect, errorBox, countHint;
	var currentMode = 'tinymce';
	var SNIPPET_LIMIT = 6;

	document.addEventListener('DOMContentLoaded', init);

	function init() {
		modal = document.getElementById('mvweb-faq-modal');
		if (!modal) {
			return;
		}
		itemsWrap = modal.querySelector('#mvweb-faq-items');
		tpl = modal.querySelector('#mvweb-faq-item-tpl');
		styleSelect = modal.querySelector('#mvweb-faq-style');
		errorBox = modal.querySelector('#mvweb-faq-error');
		countHint = modal.querySelector('#mvweb-faq-count-hint');

		modal.querySelectorAll('[data-mvweb-faq-close]').forEach(function (el) {
			el.addEventListener('click', close);
		});
		modal.querySelector('#mvweb-faq-add').addEventListener('click', function () {
			addItem();
		});
		modal.querySelector('#mvweb-faq-insert').addEventListener('click', insert);

		itemsWrap.addEventListener('click', onItemClick);
		itemsWrap.addEventListener('input', onItemInput);

		if (window.jQuery && jQuery.fn.sortable) {
			jQuery(itemsWrap).sortable({ handle: '.mvweb-faq-item__handle', items: '> .mvweb-faq-item' });
		}

		window.mvwebFaqOpenModal = open;
	}

	function open(mode) {
		currentMode = mode || 'tinymce';
		itemsWrap.replaceChildren();
		addItem();
		styleSelect.value = cfg.defaultStyle || 'accordion';
		hideError();
		updateCount();
		modal.hidden = false;
	}

	function close() {
		modal.hidden = true;
	}

	function addItem() {
		var node = tpl.content.firstElementChild.cloneNode(true);
		itemsWrap.appendChild(node);
		var q = node.querySelector('.mvweb-faq-item__q');
		if (q) {
			q.focus();
		}
		updateCount();
	}

	function updateCount() {
		if (!countHint) {
			return;
		}
		var count = itemsWrap.querySelectorAll('.mvweb-faq-item').length;
		countHint.hidden = count <= SNIPPET_LIMIT;
	}

	function onItemClick(e) {
		var btn = e.target.closest('button');
		if (!btn) {
			return;
		}
		var item = btn.closest('.mvweb-faq-item');
		if (btn.classList.contains('mvweb-faq-item__remove')) {
			if (itemsWrap.querySelectorAll('.mvweb-faq-item').length > 1) {
				item.remove();
			} else {
				item.querySelector('.mvweb-faq-item__q').value = '';
				item.querySelector('.mvweb-faq-item__a').value = '';
				updateWords(item);
			}
			updateCount();
			return;
		}
		if (btn.classList.contains('mvweb-faq-item__toggle')) {
			item.classList.toggle('is-collapsed');
			return;
		}
		if (btn.dataset.cmd) {
			applyFormat(item, btn.dataset.cmd);
		}
	}

	function onItemInput(e) {
		if (e.target.classList.contains('mvweb-faq-item__a')) {
			updateWords(e.target.closest('.mvweb-faq-item'));
		}
	}

	function updateWords(item) {
		var ta = item.querySelector('.mvweb-faq-item__a');
		var text = ta.value.replace(/<[^>]*>/g, ' ').trim();
		var count = text ? text.split(/\s+/).length : 0;
		var label = (cfg.i18n.words || 'words');
		item.querySelector('.mvweb-faq-item__words').textContent = count + ' ' + label;
		var warn = item.querySelector('.mvweb-faq-item__warn');
		warn.hidden = count <= 200;
	}

	function applyFormat(item, cmd) {
		var ta = item.querySelector('.mvweb-faq-item__a');
		var start = ta.selectionStart;
		var end = ta.selectionEnd;
		var sel = ta.value.slice(start, end);
		var replacement = sel;

		if (cmd === 'bold') {
			replacement = '<strong>' + (sel || '') + '</strong>';
		} else if (cmd === 'link') {
			var url = window.prompt(cfg.i18n.linkPrompt || 'Enter URL:', 'https://');
			if (!url) {
				return;
			}
			url = url.trim();
			if (!/^(https?:\/\/|mailto:|tel:|\/|#)/i.test(url)) {
				return;
			}
			replacement = '<a href="' + url.replace(/"/g, '&quot;') + '">' + (sel || url) + '</a>';
		} else if (cmd === 'list') {
			var lines = (sel || '').split('\n').filter(function (l) { return l.trim() !== ''; });
			if (!lines.length) {
				lines = [''];
			}
			replacement = '<ul>' + lines.map(function (l) { return '<li>' + l.trim() + '</li>'; }).join('') + '</ul>';
		}

		ta.value = ta.value.slice(0, start) + replacement + ta.value.slice(end);
		ta.focus();
		ta.selectionStart = start;
		ta.selectionEnd = start + replacement.length;
		updateWords(item);
	}

	function collectPairs() {
		var pairs = [];
		itemsWrap.querySelectorAll('.mvweb-faq-item').forEach(function (item) {
			var q = item.querySelector('.mvweb-faq-item__q').value.trim();
			var a = item.querySelector('.mvweb-faq-item__a').value.trim();
			if (q !== '') {
				pairs.push({ q: q, a: a });
			}
		});
		return pairs;
	}

	function buildShortcode(pairs, style) {
		var out = '[mvweb_faq style="' + style + '"]\n';
		pairs.forEach(function (p) {
			var q = p.q.replace(/"/g, '&quot;').replace(/\[/g, '&#91;').replace(/]/g, '&#93;');
			out += '[mvweb_faq_item q="' + q + '"]' + p.a + '[/mvweb_faq_item]\n';
		});
		out += '[/mvweb_faq]';
		return out;
	}

	function insert() {
		var pairs = collectPairs();
		if (!pairs.length) {
			showError(cfg.i18n.emptyError || 'Add at least one question with an answer.');
			return;
		}
		var style = styleSelect.value === 'open' ? 'open' : 'accordion';
		var shortcode = buildShortcode(pairs, style);
		insertIntoEditor(shortcode);
		close();
	}

	function insertIntoEditor(shortcode) {
		if (currentMode === 'tinymce' && window.tinymce && tinymce.activeEditor && !tinymce.activeEditor.isHidden()) {
			tinymce.activeEditor.insertContent(shortcode);
			return;
		}
		if (window.QTags) {
			QTags.insertContent(shortcode);
			return;
		}
		var ta = document.getElementById('content');
		if (ta) {
			var pos = ta.selectionStart;
			ta.value = ta.value.slice(0, pos) + shortcode + ta.value.slice(ta.selectionEnd);
		}
	}

	function showError(msg) {
		errorBox.textContent = msg;
		errorBox.hidden = false;
	}

	function hideError() {
		errorBox.hidden = true;
	}
})();
