/**
 * TinyMCE plugin for MVweb FAQ — registers the toolbar button.
 *
 * @package mvweb_faq
 * @since   1.0.0
 */

(function () {
	'use strict';

	if (typeof tinymce === 'undefined') {
		return;
	}

	tinymce.PluginManager.add('mvweb_faq', function (editor) {
		editor.addButton('mvweb_faq', {
			text: 'FAQ',
			icon: false,
			tooltip: 'Insert FAQ',
			onclick: function () {
				if (window.mvwebFaqOpenModal) {
					window.mvwebFaqOpenModal('tinymce');
				}
			}
		});
	});
})();
