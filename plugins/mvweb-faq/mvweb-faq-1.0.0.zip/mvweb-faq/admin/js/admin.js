/**
 * Admin JavaScript for MVweb FAQ.
 *
 * @package mvweb_faq
 * @since   1.0.0
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		initTabs();
		initColorPicker();
		initNativeToggle();
	});

	function initNativeToggle() {
		var toggle = document.getElementById('mvweb_faq_native_styles');
		if (!toggle) {
			return;
		}
		var ids = ['mvweb_faq_question_size', 'mvweb_faq_answer_size', 'mvweb_faq_question_weight', 'mvweb_faq_icon_color'];

		function sync() {
			var off = toggle.checked;
			ids.forEach(function (id) {
				var field = document.getElementById(id);
				if (!field) {
					return;
				}
				field.disabled = off;
				var row = field.closest('.mvweb-form-row');
				if (row) {
					row.style.opacity = off ? '0.5' : '';
				}
			});
		}

		toggle.addEventListener('change', sync);
		sync();
	}

	function initColorPicker() {
		var input = document.getElementById('mvweb_faq_icon_color');
		if (!input) {
			return;
		}
		var value = input.parentNode.querySelector('.mvweb-color-picker__value');
		if (!value) {
			return;
		}
		input.addEventListener('input', function () {
			value.textContent = input.value;
		});
	}

	function initTabs() {
		var links = document.querySelectorAll('.mvweb-nav .mvweb-nav__link');
		var panels = document.querySelectorAll('.mvweb-tab-content');

		if (!links.length || !panels.length) {
			return;
		}

		links.forEach(function (link) {
			link.addEventListener('click', function (event) {
				event.preventDefault();

				var target = link.getAttribute('data-tab') || (link.getAttribute('href') || '').replace('#', '');
				if (!target) {
					return;
				}

				links.forEach(function (l) { l.classList.remove('mvweb-nav__link--active'); });
				panels.forEach(function (p) { p.classList.remove('active'); });

				link.classList.add('mvweb-nav__link--active');

				var panel = document.getElementById(target);
				if (panel) {
					panel.classList.add('active');
				}
			});
		});
	}
})();
