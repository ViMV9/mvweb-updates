<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package mvweb_faq
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-faq' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Open the editor', 'mvweb-faq' ); ?></strong>
			<p><?php esc_html_e( 'Edit any page or post in the classic editor and place the cursor where the FAQ should go.', 'mvweb-faq' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Click the FAQ button', 'mvweb-faq' ); ?></strong>
			<p><?php esc_html_e( 'Use the FAQ button in the toolbar (works in both Visual and Text modes) to open the editor dialog.', 'mvweb-faq' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Fill in questions and insert', 'mvweb-faq' ); ?></strong>
			<p><?php esc_html_e( 'Add question / answer pairs, pick a style, and insert. The shortcode is placed at the cursor and renders on the front end with Schema.org markup.', 'mvweb-faq' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-faq' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Does this work with the block editor (Gutenberg)?', 'mvweb-faq' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'The plugin targets the classic editor. The shortcode still works anywhere shortcodes run, including a Shortcode block.', 'mvweb-faq' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How do I edit an existing FAQ?', 'mvweb-faq' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Edit the shortcode text directly in the editor — change the question attribute or the answer between the item tags.', 'mvweb-faq' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'I already use an SEO plugin that adds FAQ markup. Will there be duplicates?', 'mvweb-faq' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Keep "Avoid duplicates" enabled in settings — the plugin then skips its own JSON-LD when a Yoast FAQ block is present on the page.', 'mvweb-faq' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-faq' ); ?></div>
	</div>
	<p>
		<?php
		printf(
			/* translators: %s: MVweb plugin URL */
			wp_kses(
				__( 'Need help? Visit %s for documentation and support.', 'mvweb-faq' ),
				array(
					'a' => array(
						'href'   => true,
						'target' => true,
						'rel'    => true,
					),
				)
			),
			'<a href="' . esc_url( 'https://mvweb.ru/plugins/mvweb-faq' ) . '" target="_blank" rel="noopener">mvweb.ru</a>'
		);
		?>
	</p>
	<p class="mvweb-block__sub">
		<?php
		printf(
			/* translators: %s: plugin version */
			esc_html__( 'Version %s', 'mvweb-faq' ),
			esc_html( MVWEB_FAQ_VERSION )
		);
		?>
	</p>
</div>
