<?php
/**
 * FAQ builder modal markup (printed in the admin footer on classic editor screens).
 *
 * Behaviour and string injection happen in admin/js/editor.js via the
 * localized `mvwebFaqEditor` object. Visible strings here are placeholders
 * replaced/augmented by JS; static labels use the text domain directly.
 *
 * @package mvweb_faq
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div id="mvweb-faq-modal" class="mvweb-faq-modal" hidden>
	<div class="mvweb-faq-modal__backdrop" data-mvweb-faq-close></div>

	<div class="mvweb-dialog mvweb-faq-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="mvweb-faq-modal-title">
		<div class="mvweb-dialog__head">
			<h3 id="mvweb-faq-modal-title"><?php esc_html_e( 'Insert FAQ', 'mvweb-faq' ); ?></h3>
			<button type="button" class="mvweb-faq-modal__x" data-mvweb-faq-close aria-label="<?php esc_attr_e( 'Close', 'mvweb-faq' ); ?>">&times;</button>
		</div>

		<div class="mvweb-dialog__body">
			<div class="mvweb-repeater" id="mvweb-faq-items"></div>

			<p>
				<button type="button" class="mvweb-btn" id="mvweb-faq-add">
					+ <?php esc_html_e( 'Add question', 'mvweb-faq' ); ?>
				</button>
			</p>

			<p class="mvweb-faq-modal__hint" id="mvweb-faq-count-hint" hidden>
				<?php esc_html_e( 'More than 6 questions may prevent the rich snippet from showing. Consider splitting into several pages.', 'mvweb-faq' ); ?>
			</p>

			<div class="mvweb-form-row">
				<label for="mvweb-faq-style" class="mvweb-form-row__label">
					<?php esc_html_e( 'Style', 'mvweb-faq' ); ?>
				</label>
				<div class="mvweb-form-row__field">
					<select id="mvweb-faq-style" class="mvweb-select">
						<option value="accordion"><?php esc_html_e( 'Accordion (collapsed)', 'mvweb-faq' ); ?></option>
						<option value="open"><?php esc_html_e( 'Open (expanded)', 'mvweb-faq' ); ?></option>
					</select>
				</div>
			</div>

			<p class="mvweb-faq-modal__error" id="mvweb-faq-error" hidden></p>
		</div>

		<div class="mvweb-dialog__foot">
			<button type="button" class="mvweb-btn" data-mvweb-faq-close><?php esc_html_e( 'Cancel', 'mvweb-faq' ); ?></button>
			<button type="button" class="mvweb-btn mvweb-btn--primary" id="mvweb-faq-insert"><?php esc_html_e( 'Insert', 'mvweb-faq' ); ?></button>
		</div>
	</div>

	<template id="mvweb-faq-item-tpl">
		<div class="mvweb-faq-item">
			<div class="mvweb-faq-item__head">
				<span class="mvweb-faq-item__handle" aria-hidden="true">⋮⋮</span>
				<input type="text" class="mvweb-input mvweb-faq-item__q" placeholder="<?php esc_attr_e( 'Enter the question…', 'mvweb-faq' ); ?>">
				<button type="button" class="mvweb-faq-item__toggle" aria-label="<?php esc_attr_e( 'Collapse', 'mvweb-faq' ); ?>">▾</button>
				<button type="button" class="mvweb-faq-item__remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-faq' ); ?>">&times;</button>
			</div>
			<div class="mvweb-faq-item__body">
				<div class="mvweb-faq-item__toolbar">
					<button type="button" data-cmd="bold" title="<?php esc_attr_e( 'Bold', 'mvweb-faq' ); ?>"><strong>B</strong></button>
					<button type="button" data-cmd="link" title="<?php esc_attr_e( 'Link', 'mvweb-faq' ); ?>">🔗</button>
					<button type="button" data-cmd="list" title="<?php esc_attr_e( 'List', 'mvweb-faq' ); ?>">☰</button>
				</div>
				<textarea class="mvweb-textarea mvweb-faq-item__a" rows="3" placeholder="<?php esc_attr_e( 'Enter the answer…', 'mvweb-faq' ); ?>"></textarea>
				<div class="mvweb-faq-item__meta">
					<span class="mvweb-faq-item__words">0 <?php esc_html_e( 'words', 'mvweb-faq' ); ?></span>
					<span class="mvweb-faq-item__warn" hidden><?php esc_html_e( 'Answer is long — consider splitting it.', 'mvweb-faq' ); ?></span>
				</div>
			</div>
		</div>
	</template>
</div>
<?php
