/**
 * Admin JavaScript for MVweb Sealant Calc
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

(function($) {
	'use strict';

	/**
	 * Tab navigation without page reload.
	 */
	function initTabs() {
		var $tabs = $('.mvweb-seal-tabs .nav-tab');
		var $contents = $('.mvweb-tab-content');

		$tabs.on('click', function(e) {
			e.preventDefault();

			var $this = $(this);
			var tabId = $this.data('tab');

			$tabs.removeClass('nav-tab-active');
			$this.addClass('nav-tab-active');

			$contents.removeClass('active');
			$('#' + tabId).addClass('active');

			if (history.pushState) {
				history.pushState(null, null, '#' + tabId);
			}
		});

		var hash = window.location.hash.substring(1);
		if (hash && $('#' + hash).length) {
			$tabs.filter('[data-tab="' + hash + '"]').trigger('click');
		}
	}

	/**
	 * Color picker initialization.
	 */
	function initColorPicker() {
		$('.mvweb-color-picker').wpColorPicker();
	}

	/**
	 * Packaging table — add/remove rows.
	 */
	function initPackaging() {
		var $table = $('#mvweb-seal-packaging-table');

		// Add row.
		$('#mvweb-seal-add-packaging').on('click', function() {
			var rowCount = $table.find('tbody tr').length;
			var s = mvwebSealAdmin.strings || {};
			var $row = $('<tr class="mvweb-seal-packaging-row">');
			$row.append('<td><input type="checkbox" name="packaging_enabled[' + rowCount + ']" value="1" checked></td>');
			$row.append('<td><input type="number" name="packaging_volume[]" value="" min="1" class="small-text"></td>');
			$row.append('<td><input type="text" name="packaging_label[]" value="" class="mvweb-input"></td>');

			var $select = $('<select name="packaging_category[]" class="mvweb-select">');
			$select.append($('<option>', { value: 'tube', text: s.tube || 'Tube' }));
			$select.append($('<option>', { value: 'cartridge', text: s.cartridge || 'Cartridge', selected: true }));
			$select.append($('<option>', { value: 'bucket', text: s.bucket || 'Bucket' }));
			$row.append($('<td>').append($select));

			var $btn = $('<button>', {
				type: 'button',
				'class': 'mvweb-btn mvweb-btn--sm mvweb-btn--danger mvweb-seal-remove-row',
				text: s.remove || 'Remove'
			});
			$row.append($('<td>').append($btn));

			$table.find('tbody').append($row);
		});

		// Remove row.
		$table.on('click', '.mvweb-seal-remove-row', function() {
			$(this).closest('tr').remove();
		});
	}

	/**
	 * Analytics data loading.
	 */
	function initAnalytics() {
		$('#mvweb-seal-load-analytics').on('click', function() {
			var $btn = $(this);
			var period = $('#mvweb-seal-period').val();

			$btn.prop('disabled', true);

			var s = mvwebSealAdmin.strings || {};

			$.post(mvwebSealAdmin.ajax_url, {
				action: 'mvweb_seal_analytics',
				nonce: mvwebSealAdmin.nonce,
				period: period
			}, function(response) {
				if (response.success) {
					var data = response.data;

					$('#mvweb-seal-total').text(data.total);
					$('#mvweb-seal-avg-volume').text(data.avg_volume + ' ml');

					// Joint types table — safe DOM insertion.
					var $jtBody = $('#mvweb-seal-joint-types tbody').empty();
					if (data.joint_types && data.joint_types.length) {
						data.joint_types.forEach(function(item) {
							var $tr = $('<tr>');
							$tr.append($('<td>').text(item.joint_type));
							$tr.append($('<td>').text(item.cnt));
							$jtBody.append($tr);
						});
					} else {
						$jtBody.append($('<tr>').append($('<td colspan="2">').text(s.noData || 'No data')));
					}

					// Presets table — safe DOM insertion.
					var $pBody = $('#mvweb-seal-presets tbody').empty();
					if (data.presets && data.presets.length) {
						data.presets.forEach(function(item) {
							var $tr = $('<tr>');
							$tr.append($('<td>').text(item.preset_used));
							$tr.append($('<td>').text(item.cnt));
							$pBody.append($tr);
						});
					} else {
						$pBody.append($('<tr>').append($('<td colspan="2">').text(s.noData || 'No data')));
					}
				}
			}).always(function() {
				$btn.prop('disabled', false);
			});
		});
	}

	/**
	 * Gradient preset selects.
	 */
	function initGradientPresets() {
		$('.mvweb-seal-gradient-preset').on('change', function() {
			var val = $(this).val();
			var targetId = $(this).data('target');
			if (val && targetId) {
				$('#' + targetId).val(val);
			}
		});
	}

	/**
	 * Document ready.
	 */
	$(function() {
		initTabs();
		initColorPicker();
		initPackaging();
		initAnalytics();
		initGradientPresets();
	});

})(jQuery);
