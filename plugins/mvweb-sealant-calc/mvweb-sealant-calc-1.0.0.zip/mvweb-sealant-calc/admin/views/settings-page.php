<?php
/**
 * Admin settings page with tab navigation.
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wc_active = class_exists( 'WooCommerce' );
$settings  = MVweb_Seal_Admin::get_settings();
$packaging = get_option( 'mvweb_seal_packaging', mvweb_seal_default_packaging() );

$tabs = array(
	'general'   => __( 'General', 'mvweb-sealant-calc' ),
	'packaging' => __( 'Packaging', 'mvweb-sealant-calc' ),
);

if ( $wc_active ) {
	$tabs['woocommerce'] = __( 'WooCommerce', 'mvweb-sealant-calc' );
}

$tabs['analytics'] = __( 'Analytics', 'mvweb-sealant-calc' );
$tabs['help']      = __( 'Help', 'mvweb-sealant-calc' );
?>

<div class="wrap mvweb-settings">
	<h1><?php esc_html_e( 'MVweb Sealant Calc', 'mvweb-sealant-calc' ); ?></h1>

	<?php settings_errors( 'mvweb_seal_messages' ); ?>

	<nav class="nav-tab-wrapper mvweb-seal-tabs">
		<?php
		$first = true;
		foreach ( $tabs as $tab_id => $tab_name ) :
			?>
			<a href="#<?php echo esc_attr( $tab_id ); ?>"
			   class="nav-tab<?php echo $first ? ' nav-tab-active' : ''; ?>"
			   data-tab="<?php echo esc_attr( $tab_id ); ?>">
				<?php echo esc_html( $tab_name ); ?>
			</a>
			<?php
			$first = false;
		endforeach;
		?>
	</nav>

	<!-- General Tab -->
	<div id="general" class="mvweb-tab-content active">
		<form method="post" action="">
			<?php wp_nonce_field( 'mvweb_seal_settings', 'mvweb_seal_nonce' ); ?>
			<?php include MVWEB_SEAL_PATH . 'admin/views/tab-general.php'; ?>
			<p class="submit">
				<?php submit_button( __( 'Save Changes', 'mvweb-sealant-calc' ), 'primary', 'mvweb_seal_save', false ); ?>
				<span class="mvweb-spinner"></span>
			</p>
		</form>
	</div>

	<!-- Packaging Tab -->
	<div id="packaging" class="mvweb-tab-content">
		<form method="post" action="">
			<?php wp_nonce_field( 'mvweb_seal_settings', 'mvweb_seal_nonce' ); ?>
			<?php include MVWEB_SEAL_PATH . 'admin/views/tab-packaging.php'; ?>
			<p class="submit">
				<?php submit_button( __( 'Save Packaging', 'mvweb-sealant-calc' ), 'primary', 'mvweb_seal_save_packaging', false ); ?>
				<span class="mvweb-spinner"></span>
				<?php submit_button( __( 'Reset to Defaults', 'mvweb-sealant-calc' ), 'secondary', 'mvweb_seal_reset_packaging', false ); ?>
			</p>
		</form>
	</div>

	<?php if ( $wc_active ) : ?>
	<!-- WooCommerce Tab -->
	<div id="woocommerce" class="mvweb-tab-content">
		<form method="post" action="">
			<?php wp_nonce_field( 'mvweb_seal_settings', 'mvweb_seal_nonce' ); ?>
			<?php include MVWEB_SEAL_PATH . 'admin/views/tab-woocommerce.php'; ?>
			<p class="submit">
				<?php submit_button( __( 'Save Changes', 'mvweb-sealant-calc' ), 'primary', 'mvweb_seal_save_wc', false ); ?>
				<span class="mvweb-spinner"></span>
			</p>
		</form>
	</div>
	<?php endif; ?>

	<!-- Analytics Tab -->
	<div id="analytics" class="mvweb-tab-content">
		<?php include MVWEB_SEAL_PATH . 'admin/views/tab-analytics.php'; ?>
	</div>

	<!-- Help Tab -->
	<div id="help" class="mvweb-tab-content">
		<?php include MVWEB_SEAL_PATH . 'admin/views/tab-help.php'; ?>
	</div>
</div>
