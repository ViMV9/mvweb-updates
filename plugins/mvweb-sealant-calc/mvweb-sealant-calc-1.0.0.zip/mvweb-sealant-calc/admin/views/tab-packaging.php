<?php
/**
 * Packaging settings tab.
 *
 * Variables from settings-page.php: $packaging
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-seal-packaging-tab">

	<div class="mvweb-help-text" style="margin-bottom: 16px;">
		<?php esc_html_e( 'Configure available packaging options. Users will choose from this list in the calculator.', 'mvweb-sealant-calc' ); ?>
	</div>

	<table class="mvweb-table mvweb-seal-packaging-table" id="mvweb-seal-packaging-table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Enabled', 'mvweb-sealant-calc' ); ?></th>
				<th><?php esc_html_e( 'Volume (ml)', 'mvweb-sealant-calc' ); ?></th>
				<th><?php esc_html_e( 'Label', 'mvweb-sealant-calc' ); ?></th>
				<th><?php esc_html_e( 'Category', 'mvweb-sealant-calc' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'mvweb-sealant-calc' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php foreach ( $packaging as $i => $pack ) : ?>
			<tr class="mvweb-seal-packaging-row">
				<td>
					<label class="mvweb-checkbox">
						<input type="checkbox"
							   name="packaging_enabled[<?php echo esc_attr( $i ); ?>]"
							   value="1"
							   <?php checked( ! empty( $pack['enabled'] ) ); ?>>
					</label>
				</td>
				<td>
					<input type="number"
						   name="packaging_volume[]"
						   value="<?php echo esc_attr( $pack['volume'] ); ?>"
						   min="1"
						   class="small-text">
				</td>
				<td>
					<input type="text"
						   name="packaging_label[]"
						   value="<?php echo esc_attr( mvweb_seal_translate_label( $pack['label'] ) ); ?>"
						   class="mvweb-input">
				</td>
				<td>
					<select name="packaging_category[]" class="mvweb-select">
						<option value="tube" <?php selected( $pack['category'], 'tube' ); ?>>
							<?php esc_html_e( 'Tube', 'mvweb-sealant-calc' ); ?>
						</option>
						<option value="cartridge" <?php selected( $pack['category'], 'cartridge' ); ?>>
							<?php esc_html_e( 'Cartridge', 'mvweb-sealant-calc' ); ?>
						</option>
						<option value="bucket" <?php selected( $pack['category'], 'bucket' ); ?>>
							<?php esc_html_e( 'Bucket', 'mvweb-sealant-calc' ); ?>
						</option>
					</select>
				</td>
				<td>
					<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-btn--danger mvweb-seal-remove-row">
						<?php esc_html_e( 'Remove', 'mvweb-sealant-calc' ); ?>
					</button>
				</td>
			</tr>
			<?php endforeach; ?>
		</tbody>
	</table>

	<p>
		<button type="button" class="mvweb-btn" id="mvweb-seal-add-packaging">
			<?php esc_html_e( 'Add Packaging', 'mvweb-sealant-calc' ); ?>
		</button>
	</p>

</div>
