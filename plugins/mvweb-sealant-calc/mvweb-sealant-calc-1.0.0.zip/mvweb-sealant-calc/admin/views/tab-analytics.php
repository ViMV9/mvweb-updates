<?php
/**
 * Analytics tab.
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-seal-analytics">

	<div class="mvweb-form-group">
		<label class="mvweb-label" for="mvweb-seal-period">
			<?php esc_html_e( 'Period', 'mvweb-sealant-calc' ); ?>
		</label>
		<div class="mvweb-seal-analytics-controls">
			<select class="mvweb-select" id="mvweb-seal-period">
				<option value="7"><?php esc_html_e( 'Last 7 days', 'mvweb-sealant-calc' ); ?></option>
				<option value="30" selected><?php esc_html_e( 'Last 30 days', 'mvweb-sealant-calc' ); ?></option>
				<option value="all"><?php esc_html_e( 'All time', 'mvweb-sealant-calc' ); ?></option>
			</select>
			<button type="button" class="mvweb-btn" id="mvweb-seal-load-analytics">
				<?php esc_html_e( 'Load', 'mvweb-sealant-calc' ); ?>
			</button>
		</div>
	</div>

	<div class="mvweb-seal-analytics-grid" id="mvweb-seal-analytics-data">
		<div class="mvweb-card">
			<h3 class="mvweb-card__title"><?php esc_html_e( 'Total calculations', 'mvweb-sealant-calc' ); ?></h3>
			<p class="mvweb-seal-stat mvweb-card__text" id="mvweb-seal-total">&mdash;</p>
		</div>
		<div class="mvweb-card">
			<h3 class="mvweb-card__title"><?php esc_html_e( 'Average volume', 'mvweb-sealant-calc' ); ?></h3>
			<p class="mvweb-seal-stat mvweb-card__text" id="mvweb-seal-avg-volume">&mdash;</p>
		</div>
	</div>

	<div class="mvweb-seal-analytics-tables">
		<div>
			<h3 class="mvweb-section-title"><?php esc_html_e( 'Popular joint types', 'mvweb-sealant-calc' ); ?></h3>
			<table class="mvweb-table" id="mvweb-seal-joint-types">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Joint type', 'mvweb-sealant-calc' ); ?></th>
						<th><?php esc_html_e( 'Count', 'mvweb-sealant-calc' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td colspan="2"><?php esc_html_e( 'Click "Load" to view data.', 'mvweb-sealant-calc' ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
		<div>
			<h3 class="mvweb-section-title"><?php esc_html_e( 'Popular presets', 'mvweb-sealant-calc' ); ?></h3>
			<table class="mvweb-table" id="mvweb-seal-presets">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Preset', 'mvweb-sealant-calc' ); ?></th>
						<th><?php esc_html_e( 'Count', 'mvweb-sealant-calc' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td colspan="2"><?php esc_html_e( 'Click "Load" to view data.', 'mvweb-sealant-calc' ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>

</div>
