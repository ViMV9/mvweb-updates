<?php
/**
 * Help tab template.
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-help">
	<!-- Quick Start -->
	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'Quick Start', 'mvweb-sealant-calc' ); ?></h2>
		<ol class="mvweb-help__steps">
			<li>
				<strong><?php esc_html_e( 'Add the shortcode', 'mvweb-sealant-calc' ); ?></strong>
				<p><?php esc_html_e( 'Place [mvweb_sealant_calc] on any page or post where you want the calculator to appear.', 'mvweb-sealant-calc' ); ?></p>
			</li>
			<li>
				<strong><?php esc_html_e( 'Configure settings', 'mvweb-sealant-calc' ); ?></strong>
				<p><?php esc_html_e( 'Go to General tab to set default waste percentage, display options, and accent color.', 'mvweb-sealant-calc' ); ?></p>
			</li>
			<li>
				<strong><?php esc_html_e( 'Manage packaging', 'mvweb-sealant-calc' ); ?></strong>
				<p><?php esc_html_e( 'Go to Packaging tab to add, remove, or edit available packaging sizes.', 'mvweb-sealant-calc' ); ?></p>
			</li>
		</ol>
	</section>

	<!-- Features -->
	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'Features', 'mvweb-sealant-calc' ); ?></h2>
		<ul>
			<li><?php esc_html_e( '8 joint types: rectangular, triangular, round bead, flat layer, U-shaped, conical, trapezoidal, ring (pipe).', 'mvweb-sealant-calc' ); ?></li>
			<li><?php esc_html_e( 'Multiple sections — calculate total consumption for several joints at once.', 'mvweb-sealant-calc' ); ?></li>
			<li><?php esc_html_e( '12 built-in task presets for common scenarios (window, bathtub, facade, etc.).', 'mvweb-sealant-calc' ); ?></li>
			<li><?php esc_html_e( 'Interactive SVG cross-section diagrams with dimension labels.', 'mvweb-sealant-calc' ); ?></li>
			<li><?php esc_html_e( 'Packaging recommendation table with all sizes and optimal choice.', 'mvweb-sealant-calc' ); ?></li>
			<li><?php esc_html_e( 'Transparent formula display — shows step-by-step calculation.', 'mvweb-sealant-calc' ); ?></li>
			<li><?php esc_html_e( 'Optional WooCommerce integration — auto-fill price and packaging from product data.', 'mvweb-sealant-calc' ); ?></li>
			<li><?php esc_html_e( 'Print-friendly results.', 'mvweb-sealant-calc' ); ?></li>
			<li><?php esc_html_e( 'Usage analytics for popular joint types and presets.', 'mvweb-sealant-calc' ); ?></li>
		</ul>
	</section>

	<!-- Shortcode Reference -->
	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'Shortcode Reference', 'mvweb-sealant-calc' ); ?></h2>
		<table class="mvweb-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Shortcode', 'mvweb-sealant-calc' ); ?></th>
					<th><?php esc_html_e( 'Description', 'mvweb-sealant-calc' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><code>[mvweb_sealant_calc]</code></td>
					<td><?php esc_html_e( 'Basic calculator with all features.', 'mvweb-sealant-calc' ); ?></td>
				</tr>
				<tr>
					<td><code>[mvweb_sealant_calc layout="compact"]</code></td>
					<td><?php esc_html_e( 'Compact layout.', 'mvweb-sealant-calc' ); ?></td>
				</tr>
				<tr>
					<td><code>[mvweb_sealant_calc product_id="123"]</code></td>
					<td><?php esc_html_e( 'Linked to WooCommerce product (auto-fills price and packaging).', 'mvweb-sealant-calc' ); ?></td>
				</tr>
				<tr>
					<td><code>[mvweb_sealant_calc show_presets="false"]</code></td>
					<td><?php esc_html_e( 'Without task presets.', 'mvweb-sealant-calc' ); ?></td>
				</tr>
				<tr>
					<td><code>[mvweb_sealant_calc bg_color="#f5f5f5"]</code></td>
					<td><?php esc_html_e( 'Custom result block background color.', 'mvweb-sealant-calc' ); ?></td>
				</tr>
				<tr>
					<td><code>[mvweb_sealant_calc border_color="#793ea4"]</code></td>
					<td><?php esc_html_e( 'Custom result block border color.', 'mvweb-sealant-calc' ); ?></td>
				</tr>
			</tbody>
		</table>
	</section>

	<!-- WooCommerce Integration -->
	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'WooCommerce Integration', 'mvweb-sealant-calc' ); ?></h2>
		<p><?php esc_html_e( 'The calculator integrates with WooCommerce products. When WooCommerce is active, a "Sealant Calc" tab appears in the product edit page under "Product data".', 'mvweb-sealant-calc' ); ?></p>

		<div class="mvweb-help__subsection">
			<strong><?php esc_html_e( 'Product meta fields:', 'mvweb-sealant-calc' ); ?></strong>
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Field', 'mvweb-sealant-calc' ); ?></th>
						<th><?php esc_html_e( 'Meta key', 'mvweb-sealant-calc' ); ?></th>
						<th><?php esc_html_e( 'Description', 'mvweb-sealant-calc' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><?php esc_html_e( 'Package volume (ml)', 'mvweb-sealant-calc' ); ?></td>
						<td><code>_mvweb_seal_volume</code></td>
						<td><?php esc_html_e( 'Volume of this package in milliliters (e.g. 310). Auto-selects the matching packaging option in the calculator.', 'mvweb-sealant-calc' ); ?></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Packaging unit', 'mvweb-sealant-calc' ); ?></td>
						<td><code>_mvweb_seal_unit</code></td>
						<td><?php esc_html_e( 'Description label (e.g. "Cartridge 310 ml"). For display purposes.', 'mvweb-sealant-calc' ); ?></td>
					</tr>
					<tr>
						<td><?php esc_html_e( 'Show calculator', 'mvweb-sealant-calc' ); ?></td>
						<td><code>_mvweb_seal_show_calc</code></td>
						<td><?php esc_html_e( 'Enable to auto-display the calculator on this product page (requires "Auto-show on products" in WooCommerce settings tab).', 'mvweb-sealant-calc' ); ?></td>
					</tr>
				</tbody>
			</table>
		</div>

		<div class="mvweb-help__subsection" style="margin-top: 12px;">
			<strong><?php esc_html_e( 'How it works:', 'mvweb-sealant-calc' ); ?></strong>
			<ol class="mvweb-help__steps">
				<li><?php esc_html_e( 'Edit a WooCommerce product → Product data → Sealant Calc tab.', 'mvweb-sealant-calc' ); ?></li>
				<li><?php esc_html_e( 'Enter the package volume in ml and check "Show calculator".', 'mvweb-sealant-calc' ); ?></li>
				<li><?php esc_html_e( 'Enable "Auto-show on products" in plugin settings → WooCommerce tab.', 'mvweb-sealant-calc' ); ?></li>
				<li><?php esc_html_e( 'The calculator will appear on the product page with pre-filled packaging and price from the product.', 'mvweb-sealant-calc' ); ?></li>
			</ol>
		</div>

		<div class="mvweb-help__subsection" style="margin-top: 12px;">
			<strong><?php esc_html_e( 'Manual shortcode:', 'mvweb-sealant-calc' ); ?></strong>
			<p><?php esc_html_e( 'You can also manually place the calculator on any page using:', 'mvweb-sealant-calc' ); ?></p>
			<code>[mvweb_sealant_calc product_id="123"]</code>
			<p><?php esc_html_e( 'Replace 123 with the WooCommerce product ID. The calculator will auto-fill packaging volume, price, and show a "View in catalog" link.', 'mvweb-sealant-calc' ); ?></p>
		</div>
	</section>

	<!-- FAQ -->
	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'Frequently Asked Questions', 'mvweb-sealant-calc' ); ?></h2>

		<div class="mvweb-help__faq">
			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'How accurate are the calculations?', 'mvweb-sealant-calc' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p><?php esc_html_e( 'Calculations are based on geometric formulas for joint cross-sections. The waste percentage accounts for real-world losses. Results are estimates — actual consumption may vary depending on surface quality and application technique.', 'mvweb-sealant-calc' ); ?></p>
				</div>
			</details>

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'Does the calculator work without WooCommerce?', 'mvweb-sealant-calc' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p><?php esc_html_e( 'Yes. WooCommerce integration is optional. The calculator works fully on its own — users can select packaging and enter prices manually.', 'mvweb-sealant-calc' ); ?></p>
				</div>
			</details>

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'Can I add custom packaging sizes?', 'mvweb-sealant-calc' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p><?php esc_html_e( 'Yes. Go to the Packaging tab to add, remove, or modify packaging options. You can also set a custom volume in the calculator itself.', 'mvweb-sealant-calc' ); ?></p>
				</div>
			</details>

			<details class="mvweb-help__faq-item mvweb-details">
				<summary><?php esc_html_e( 'What is the waste percentage?', 'mvweb-sealant-calc' ); ?></summary>
				<div class="mvweb-help__faq-answer mvweb-details__body">
					<p><?php esc_html_e( 'Waste accounts for material losses due to uneven surfaces, tool cleaning, and application method. Default is 10%. Users can adjust from 0% to 30%.', 'mvweb-sealant-calc' ); ?></p>
				</div>
			</details>
		</div>
	</section>

	<!-- Support -->
	<section class="mvweb-help__section">
		<h2><?php esc_html_e( 'Support', 'mvweb-sealant-calc' ); ?></h2>
		<p>
			<?php
			printf(
				/* translators: %s: MVweb plugin URL */
				esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-sealant-calc' ),
				'<a href="https://mvweb.ru/plugins/mvweb-sealant-calc" target="_blank">mvweb.ru</a>'
			);
			?>
		</p>
		<p>
			<strong><?php esc_html_e( 'Version:', 'mvweb-sealant-calc' ); ?></strong> <?php echo esc_html( MVWEB_SEAL_VERSION ); ?>
		</p>
	</section>
</div>
