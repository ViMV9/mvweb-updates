<?php
/**
 * General settings tab.
 *
 * Variables from settings-page.php: $settings
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-seal-general-tab">

	<!-- Default waste % -->
	<div class="mvweb-form-group">
		<label class="mvweb-label" for="mvweb-seal-default-waste">
			<?php esc_html_e( 'Default waste %', 'mvweb-sealant-calc' ); ?>
		</label>
		<input type="number" class="mvweb-input mvweb-seal-input--short" id="mvweb-seal-default-waste"
			   name="default_waste"
			   value="<?php echo esc_attr( $settings['default_waste'] ); ?>"
			   min="0" max="30">
		<div class="mvweb-help-text">
			<?php esc_html_e( 'Default material waste percentage (0-30%).', 'mvweb-sealant-calc' ); ?>
		</div>
	</div>

	<!-- Max sections -->
	<div class="mvweb-form-group">
		<label class="mvweb-label" for="mvweb-seal-max-sections">
			<?php esc_html_e( 'Max sections', 'mvweb-sealant-calc' ); ?>
		</label>
		<input type="number" class="mvweb-input mvweb-seal-input--short" id="mvweb-seal-max-sections"
			   name="max_sections"
			   value="<?php echo esc_attr( $settings['max_sections'] ); ?>"
			   min="1" max="50">
		<div class="mvweb-help-text">
			<?php esc_html_e( 'Maximum number of sections per calculation.', 'mvweb-sealant-calc' ); ?>
		</div>
	</div>

	<!-- Display options -->
	<h3 class="mvweb-section-title"><?php esc_html_e( 'Display options', 'mvweb-sealant-calc' ); ?></h3>

	<div class="mvweb-form-group">
		<label class="mvweb-checkbox">
			<input type="checkbox" name="show_presets" value="1"
				   <?php checked( $settings['show_presets'] ); ?>>
			<?php esc_html_e( 'Show task presets', 'mvweb-sealant-calc' ); ?>
		</label>
	</div>

	<div class="mvweb-form-group">
		<label class="mvweb-checkbox">
			<input type="checkbox" name="show_formula" value="1"
				   <?php checked( $settings['show_formula'] ); ?>>
			<?php esc_html_e( 'Show "How we calculate?" block', 'mvweb-sealant-calc' ); ?>
		</label>
	</div>

	<div class="mvweb-form-group">
		<label class="mvweb-checkbox">
			<input type="checkbox" name="show_price" value="1"
				   <?php checked( $settings['show_price'] ); ?>>
			<?php esc_html_e( 'Show price field', 'mvweb-sealant-calc' ); ?>
		</label>
	</div>

	<h3 class="mvweb-section-title"><?php esc_html_e( 'Colors', 'mvweb-sealant-calc' ); ?></h3>

	<!-- Accent color -->
	<div class="mvweb-form-group">
		<label class="mvweb-label" for="accent_color">
			<?php esc_html_e( 'Accent color', 'mvweb-sealant-calc' ); ?>
		</label>
		<input type="text" id="accent_color" name="accent_color"
			   value="<?php echo esc_attr( $settings['accent_color'] ); ?>"
			   class="mvweb-color regular-text mvweb-color-picker"
			   data-default-color="#793ea4">
		<div class="mvweb-help-text">
			<?php esc_html_e( 'Main color for buttons, headings, and result highlights.', 'mvweb-sealant-calc' ); ?>
		</div>
	</div>

	<!-- Header gradient -->
	<div class="mvweb-form-group">
		<label class="mvweb-label" for="header_gradient">
			<?php esc_html_e( 'Header background', 'mvweb-sealant-calc' ); ?>
		</label>
		<select class="mvweb-select mvweb-seal-gradient-preset" data-target="header_gradient">
			<option value=""><?php esc_html_e( 'Gradient presets...', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, #667eea, #764ba2)"><?php esc_html_e( 'Deep Purple', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, #f093fb, #f5576c)"><?php esc_html_e( 'Pink Glow', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, #4facfe, #00f2fe)"><?php esc_html_e( 'Ocean Blue', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, #43e97b, #38f9d7)"><?php esc_html_e( 'Fresh Green', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, #fa709a, #fee140)"><?php esc_html_e( 'Sunset', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, #a18cd1, #fbc2eb)"><?php esc_html_e( 'Lavender', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, #ffecd2, #fcb69f)"><?php esc_html_e( 'Peach', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, #2b5876, #4e4376)"><?php esc_html_e( 'Midnight', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, #0c3483, #a2b6df)"><?php esc_html_e( 'Steel Blue', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, #e8198b, #c7eafd)"><?php esc_html_e( 'Cotton Candy', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, #1a1a2e, #16213e)"><?php esc_html_e( 'Dark Navy', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, #ff9a9e, #fecfef)"><?php esc_html_e( 'Rose', 'mvweb-sealant-calc' ); ?></option>
			<option disabled>───── <?php esc_html_e( 'Fade to transparent', 'mvweb-sealant-calc' ); ?> ─────</option>
			<option value="linear-gradient(135deg, rgba(98,0,234,.15), transparent)"><?php esc_html_e( 'Purple fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, rgba(21,101,192,.15), transparent)"><?php esc_html_e( 'Blue fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, rgba(0,137,123,.15), transparent)"><?php esc_html_e( 'Teal fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, rgba(46,125,50,.15), transparent)"><?php esc_html_e( 'Green fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, rgba(230,81,0,.15), transparent)"><?php esc_html_e( 'Orange fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, rgba(198,40,40,.15), transparent)"><?php esc_html_e( 'Red fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, rgba(173,20,87,.15), transparent)"><?php esc_html_e( 'Pink fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, rgba(55,71,79,.15), transparent)"><?php esc_html_e( 'Grey fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, rgba(26,26,46,.15), transparent)"><?php esc_html_e( 'Dark fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(135deg, rgba(249,168,37,.15), transparent)"><?php esc_html_e( 'Gold fade', 'mvweb-sealant-calc' ); ?></option>
		</select>
		<input type="text" id="header_gradient" name="header_gradient"
			   value="<?php echo esc_attr( $settings['header_gradient'] ?? '' ); ?>"
			   class="regular-text"
			   placeholder="linear-gradient(135deg, #793ea4, #5e2d80)">
		<div class="mvweb-help-text">
			<?php esc_html_e( 'Select a preset or enter a custom CSS gradient. Leave empty for default.', 'mvweb-sealant-calc' ); ?>
		</div>
	</div>

	<!-- Header text color -->
	<div class="mvweb-form-group">
		<label class="mvweb-label" for="header_color">
			<?php esc_html_e( 'Header text color', 'mvweb-sealant-calc' ); ?>
		</label>
		<input type="text" id="header_color" name="header_color"
			   value="<?php echo esc_attr( $settings['header_color'] ?? '' ); ?>"
			   class="mvweb-color regular-text mvweb-color-picker"
			   data-default-color="">
		<div class="mvweb-help-text">
			<?php esc_html_e( 'Text color for the header. Use white (#ffffff) with dark gradients.', 'mvweb-sealant-calc' ); ?>
		</div>
	</div>

	<!-- Result background -->
	<div class="mvweb-form-group">
		<label class="mvweb-label" for="result_bg">
			<?php esc_html_e( 'Result block background', 'mvweb-sealant-calc' ); ?>
		</label>
		<select class="mvweb-select mvweb-seal-gradient-preset" data-target="result_bg">
			<option value=""><?php esc_html_e( 'Gradient presets...', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, #f5f0fa, #eee8f5)"><?php esc_html_e( 'Lavender Light', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, #e8eaf6, #c5cae9)"><?php esc_html_e( 'Indigo Light', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, #e3f2fd, #bbdefb)"><?php esc_html_e( 'Blue Light', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, #e8f5e9, #c8e6c9)"><?php esc_html_e( 'Green Light', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, #fff3e0, #ffe0b2)"><?php esc_html_e( 'Orange Light', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, #fce4ec, #f8bbd0)"><?php esc_html_e( 'Pink Light', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, #f3e5f5, #e1bee7)"><?php esc_html_e( 'Purple Light', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, #e0f7fa, #b2ebf2)"><?php esc_html_e( 'Cyan Light', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, #eceff1, #cfd8dc)"><?php esc_html_e( 'Grey Light', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, #fffde7, #fff9c4)"><?php esc_html_e( 'Yellow Light', 'mvweb-sealant-calc' ); ?></option>
			<option value="#ffffff"><?php esc_html_e( 'White', 'mvweb-sealant-calc' ); ?></option>
			<option value="#f5f5f5"><?php esc_html_e( 'Light Grey', 'mvweb-sealant-calc' ); ?></option>
			<option disabled>───── <?php esc_html_e( 'Fade to transparent', 'mvweb-sealant-calc' ); ?> ─────</option>
			<option value="linear-gradient(160deg, rgba(98,0,234,.1), transparent)"><?php esc_html_e( 'Purple fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, rgba(21,101,192,.1), transparent)"><?php esc_html_e( 'Blue fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, rgba(0,137,123,.1), transparent)"><?php esc_html_e( 'Teal fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, rgba(46,125,50,.1), transparent)"><?php esc_html_e( 'Green fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, rgba(230,81,0,.1), transparent)"><?php esc_html_e( 'Orange fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, rgba(198,40,40,.1), transparent)"><?php esc_html_e( 'Red fade', 'mvweb-sealant-calc' ); ?></option>
			<option value="linear-gradient(160deg, rgba(249,168,37,.08), transparent)"><?php esc_html_e( 'Gold fade', 'mvweb-sealant-calc' ); ?></option>
		</select>
		<input type="text" id="result_bg" name="result_bg"
			   value="<?php echo esc_attr( $settings['result_bg'] ?? '' ); ?>"
			   class="regular-text"
			   placeholder="linear-gradient(160deg, #f5f0fa, #eee8f5)">
		<div class="mvweb-help-text">
			<?php esc_html_e( 'Select a preset or enter a custom CSS gradient. Leave empty for default.', 'mvweb-sealant-calc' ); ?>
		</div>
	</div>

	<!-- Result border color -->
	<div class="mvweb-form-group">
		<label class="mvweb-label" for="result_border">
			<?php esc_html_e( 'Result block border', 'mvweb-sealant-calc' ); ?>
		</label>
		<input type="text" id="result_border" name="result_border"
			   value="<?php echo esc_attr( $settings['result_border'] ?? '' ); ?>"
			   class="mvweb-color regular-text mvweb-color-picker"
			   data-default-color="">
		<div class="mvweb-help-text">
			<?php esc_html_e( 'Border color for the result block. Leave empty for accent color.', 'mvweb-sealant-calc' ); ?>
		</div>
	</div>

</div>
