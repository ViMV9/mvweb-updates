<?php
/**
 * WooCommerce settings tab.
 *
 * Variables from settings-page.php: $settings
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-seal-wc-tab">

	<!-- Auto-show on products -->
	<div class="mvweb-form-group">
		<label class="mvweb-checkbox">
			<input type="checkbox" name="wc_auto_show" value="1"
				   <?php checked( ! empty( $settings['wc_auto_show'] ) ); ?>>
			<?php esc_html_e( 'Auto-show on products', 'mvweb-sealant-calc' ); ?>
		</label>
		<div class="mvweb-help-text">
			<?php esc_html_e( 'Automatically display calculator on products with Sealant Calc meta field enabled.', 'mvweb-sealant-calc' ); ?>
		</div>
	</div>

	<!-- Product link text -->
	<div class="mvweb-form-group">
		<label class="mvweb-label" for="mvweb-seal-wc-link-text">
			<?php esc_html_e( 'Product link text', 'mvweb-sealant-calc' ); ?>
		</label>
		<input type="text" class="regular-text" id="mvweb-seal-wc-link-text"
			   name="wc_product_link_text"
			   value="<?php echo esc_attr( $settings['wc_product_link_text'] ?? __( 'View in catalog', 'mvweb-sealant-calc' ) ); ?>">
		<div class="mvweb-help-text">
			<?php esc_html_e( 'Text for the product link in calculator results.', 'mvweb-sealant-calc' ); ?>
		</div>
	</div>

</div>
