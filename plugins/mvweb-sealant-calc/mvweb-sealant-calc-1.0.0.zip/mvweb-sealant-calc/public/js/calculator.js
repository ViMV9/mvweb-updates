/**
 * MVweb Sealant Calc — Frontend Calculator
 *
 * All calculations are client-side. No jQuery dependency.
 * Uses IIFE for scope isolation.
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */
(function () {
	'use strict';

	/* ══════════════════════════════════════════
	   Configuration & State
	   ══════════════════════════════════════════ */

	var config = window.mvwebSealConfig || {};
	var i18n = config.i18n || {};
	var settings = config.settings || {};

	/** Calculation formulas — return cross-section area in mm². */
	var formulas = {
		rectangular: function (p) { return p.width * p.depth; },
		triangular: function (p) { return p.width * p.depth / 2; },
		round: function (p) { return Math.PI * Math.pow(p.diameter / 2, 2); },
		flat: function (p) { return p.thickness * p.width; },
		uShaped: function (p) { return 2 * p.thickness * p.depth + p.thickness * p.width; },
		conical: function (p) { return (p.widthTop + p.widthBottom) / 2 * p.depth; },
		trapezoidal: function (p) { return (p.widthTop + p.widthBottom) / 2 * p.depth; },
		ring: function (p) { return Math.PI * p.pipeDiameter * p.width * p.depth; }
	};

	/** Formula display names — use i18n if available. */
	function getFormulaNames() {
		var W = i18n.width || 'Width';
		var D = i18n.depth || 'Depth';
		var L = i18n.length || 'Length';
		var T = i18n.thickness || 'Thickness';
		var Dm = i18n.diameter || 'Diameter';
		var Dp = i18n.pipeDiameter || 'Pipe dia.';
		var Wt = i18n.widthTop || 'W\u2081';
		var Wb = i18n.widthBottom || 'W\u2082';
		return {
			rectangular: W + ' \u00d7 ' + D + ' \u00d7 ' + L,
			triangular: W + ' \u00d7 ' + D + ' / 2 \u00d7 ' + L,
			round: '\u03c0 \u00d7 (' + Dm + '/2)\u00b2 \u00d7 ' + L,
			flat: T + ' \u00d7 ' + W + ' \u00d7 ' + L,
			uShaped: '(2 \u00d7 ' + T + ' \u00d7 ' + D + ' + ' + T + ' \u00d7 ' + W + ') \u00d7 ' + L,
			conical: '(' + Wt + ' + ' + Wb + ') / 2 \u00d7 ' + D + ' \u00d7 ' + L,
			trapezoidal: '(' + Wt + ' + ' + Wb + ') / 2 \u00d7 ' + D + ' \u00d7 ' + L,
			ring: '\u03c0 \u00d7 ' + Dp + ' \u00d7 ' + W + ' \u00d7 ' + D
		};
	}
	var formulaNames = getFormulaNames();

	/** Which fields each joint type needs. */
	var fieldMap = {
		rectangular: ['width', 'depth', 'length'],
		triangular: ['width', 'depth', 'length'],
		round: ['diameter', 'length'],
		flat: ['thickness', 'width', 'length'],
		uShaped: ['width', 'depth', 'thickness', 'length'],
		conical: ['width-top', 'width-bottom', 'depth', 'length'],
		trapezoidal: ['width-top', 'width-bottom', 'depth', 'length'],
		ring: ['pipe-diameter', 'width', 'depth']
	};

	/** SVG file mapping. */
	var svgFiles = {
		rectangular: 'joint-rectangular.svg',
		triangular: 'joint-triangular.svg',
		round: 'joint-round.svg',
		flat: 'joint-flat.svg',
		uShaped: 'joint-u-shaped.svg',
		conical: 'joint-conical.svg',
		trapezoidal: 'joint-trapezoidal.svg',
		ring: 'joint-ring.svg'
	};

	/** SVG cache to avoid re-fetching. */
	var svgCache = {};

	/** Debounce timer. */
	var calcTimer = null;
	var analyticsTimer = null;

	/* ══════════════════════════════════════════
	   Initialization
	   ══════════════════════════════════════════ */

	function init() {
		var calculators = document.querySelectorAll('.mvweb-seal');
		for (var i = 0; i < calculators.length; i++) {
			initCalculator(calculators[i]);
		}
	}

	function initCalculator(root) {
		bindEvents(root);
		// Load initial SVG.
		var firstSection = root.querySelector('.mvweb-seal__section');
		if (firstSection) {
			updateFieldVisibility(firstSection);
			loadSVG(firstSection);
		}
	}

	/* ══════════════════════════════════════════
	   Event Binding
	   ══════════════════════════════════════════ */

	function bindEvents(root) {
		// Input changes — debounced calculation.
		root.addEventListener('input', function (e) {
			if (e.target.classList.contains('mvweb-seal__input')) {
				debouncedCalculate(root);
			}
		});

		// Joint type change.
		root.addEventListener('change', function (e) {
			if (e.target.classList.contains('mvweb-seal__joint-type')) {
				var section = e.target.closest('.mvweb-seal__section');
				updateFieldVisibility(section);
				loadSVG(section);
				debouncedCalculate(root);
			}
			// Custom packaging toggle.
			if (e.target.classList.contains('mvweb-seal__packaging')) {
				var customWrap = root.querySelector('.mvweb-seal__custom-packaging');
				if (customWrap) {
					customWrap.style.display = e.target.value === 'custom' ? '' : 'none';
				}
				debouncedCalculate(root);
			}
		});

		// Click handlers.
		root.addEventListener('click', function (e) {
			var target = e.target;

			// Preset.
			if (target.classList.contains('mvweb-seal__preset')) {
				applyPreset(root, target);
				return;
			}

			// Add section.
			if (target.classList.contains('mvweb-seal__btn--add') || target.closest('.mvweb-seal__btn--add')) {
				addSection(root);
				return;
			}

			// Remove section.
			if (target.classList.contains('mvweb-seal__btn--remove') || target.closest('.mvweb-seal__btn--remove')) {
				var section = target.closest('.mvweb-seal__section');
				removeSection(root, section);
				return;
			}

			// Print.
			if (target.classList.contains('mvweb-seal__btn--print') || target.closest('.mvweb-seal__btn--print')) {
				window.print();
				return;
			}

			// Reset.
			if (target.classList.contains('mvweb-seal__btn--reset') || target.closest('.mvweb-seal__btn--reset')) {
				resetCalculator(root);
				return;
			}
		});
	}

	/* ══════════════════════════════════════════
	   Field Visibility
	   ══════════════════════════════════════════ */

	function updateFieldVisibility(section) {
		var typeSelect = section.querySelector('.mvweb-seal__joint-type');
		if (!typeSelect) return;

		var type = typeSelect.value;
		var needed = fieldMap[type] || [];

		var allFieldTypes = ['width', 'depth', 'diameter', 'thickness', 'width-top', 'width-bottom', 'pipe-diameter', 'length'];

		for (var i = 0; i < allFieldTypes.length; i++) {
			var fieldEl = section.querySelector('.mvweb-seal__field--' + allFieldTypes[i]);
			if (fieldEl) {
				fieldEl.style.display = needed.indexOf(allFieldTypes[i]) !== -1 ? '' : 'none';
			}
		}
	}

	/* ══════════════════════════════════════════
	   SVG Loading
	   ══════════════════════════════════════════ */

	function loadSVG(section) {
		var typeSelect = section.querySelector('.mvweb-seal__joint-type');
		if (!typeSelect) return;

		var type = typeSelect.value;
		var svgContainer = section.querySelector('.mvweb-seal__svg');
		if (!svgContainer) return;

		var fileName = svgFiles[type];
		if (!fileName) return;

		// Use cache if available.
		if (svgCache[type]) {
			setSVGContent(svgContainer, svgCache[type]);
			updateSVGLabels(section);
			return;
		}

		var url = (config.svgUrl || '') + fileName;

		var xhr = new XMLHttpRequest();
		xhr.open('GET', url, true);
		xhr.onload = function () {
			if (xhr.status === 200) {
				svgCache[type] = xhr.responseText;
				setSVGContent(svgContainer, xhr.responseText);
				updateSVGLabels(section);
			}
		};
		xhr.send();
	}

	/**
	 * Safely set SVG content from a trusted plugin file.
	 * SVG files are bundled with the plugin, not user-generated.
	 */
	function setSVGContent(container, svgString) {
		// Clear existing children.
		while (container.firstChild) {
			container.removeChild(container.firstChild);
		}
		// Parse SVG as XML and import into document.
		var parser = new DOMParser();
		var doc = parser.parseFromString(svgString, 'image/svg+xml');
		var svgEl = doc.documentElement;
		if (svgEl && svgEl.tagName === 'svg') {
			container.appendChild(document.importNode(svgEl, true));
		}
	}

	function updateSVGLabels(section) {
		var svgEl = section.querySelector('.mvweb-seal__svg svg');
		if (!svgEl) return;

		var params = getSectionParams(section);

		// Update text elements by data-label attribute.
		var labels = svgEl.querySelectorAll('[data-label]');
		for (var i = 0; i < labels.length; i++) {
			var labelName = labels[i].getAttribute('data-label');
			var value = '';

			switch (labelName) {
				case 'width': value = params.width ? params.width + ' mm' : ''; break;
				case 'depth': value = params.depth ? params.depth + ' mm' : ''; break;
				case 'diameter': value = params.diameter ? params.diameter + ' mm' : ''; break;
				case 'thickness': value = params.thickness ? params.thickness + ' mm' : ''; break;
				case 'widthTop': value = params.widthTop ? params.widthTop + ' mm' : ''; break;
				case 'widthBottom': value = params.widthBottom ? params.widthBottom + ' mm' : ''; break;
				case 'pipeDiameter': value = params.pipeDiameter ? params.pipeDiameter + ' mm' : ''; break;
			}

			labels[i].textContent = value;
		}
	}

	/* ══════════════════════════════════════════
	   Section Params
	   ══════════════════════════════════════════ */

	function getSectionParams(section) {
		return {
			type: getVal(section, '.mvweb-seal__joint-type', 'select'),
			width: getVal(section, '.mvweb-seal__width'),
			depth: getVal(section, '.mvweb-seal__depth'),
			diameter: getVal(section, '.mvweb-seal__diameter'),
			thickness: getVal(section, '.mvweb-seal__thickness'),
			widthTop: getVal(section, '.mvweb-seal__width-top'),
			widthBottom: getVal(section, '.mvweb-seal__width-bottom'),
			pipeDiameter: getVal(section, '.mvweb-seal__pipe-diameter'),
			length: getVal(section, '.mvweb-seal__length')
		};
	}

	function getVal(parent, selector, type) {
		var el = parent.querySelector(selector);
		if (!el) return type === 'select' ? 'rectangular' : 0;
		if (type === 'select') return el.value;
		var v = parseFloat(el.value);
		return isNaN(v) ? 0 : v;
	}

	/* ══════════════════════════════════════════
	   Calculation
	   ══════════════════════════════════════════ */

	function debouncedCalculate(root) {
		clearTimeout(calcTimer);
		calcTimer = setTimeout(function () { calculate(root); }, 150);
	}

	function calculate(root) {
		var sections = root.querySelectorAll('.mvweb-seal__section');
		var totalVolume = 0;
		var sectionResults = [];
		var hasValidSection = false;

		for (var i = 0; i < sections.length; i++) {
			var params = getSectionParams(sections[i]);
			var sectionVolume = calculateSection(params);

			// Update SVG labels via requestAnimationFrame.
			(function (sec) {
				requestAnimationFrame(function () { updateSVGLabels(sec); });
			})(sections[i]);

			// Validate and warn.
			validateSection(sections[i], params);

			sectionResults.push({
				type: params.type,
				params: params,
				volume: sectionVolume
			});

			totalVolume += sectionVolume;
			if (sectionVolume > 0) hasValidSection = true;
		}

		// Apply waste.
		var waste = getVal(root, '.mvweb-seal__waste') || 0;
		waste = Math.min(30, Math.max(0, waste));
		var totalWithWaste = totalVolume * (1 + waste / 100);

		// Get packaging.
		var packaging = getPackaging(root);

		// Update result display.
		updateResults(root, totalWithWaste, packaging, hasValidSection);

		// Update packaging table.
		updatePackagingTable(root, totalWithWaste);

		// Update formula.
		if (settings.showFormula) {
			updateFormula(root, sectionResults, waste, totalVolume, totalWithWaste, packaging);
		}

		// Track analytics (debounced).
		if (hasValidSection) {
			trackAnalytics(root, sectionResults, totalWithWaste, packaging, sections.length);
		}
	}

	function calculateSection(params) {
		var type = params.type;
		var formula = formulas[type];
		if (!formula) return 0;

		var crossSection = formula(params);
		if (isNaN(crossSection) || crossSection <= 0) return 0;

		// For ring type, the formula already gives volume in mm³ for one ring.
		if (type === 'ring') {
			return crossSection / 1000;
		}

		// Cross-section in mm², length in m.
		// Volume (ml) = area (mm²) × length (m) × 1000 (mm/m) / 1000 (mm³/ml) = area × length.
		var length = params.length || 0;
		return crossSection * length;
	}

	/* ══════════════════════════════════════════
	   Packaging
	   ══════════════════════════════════════════ */

	function getPackaging(root) {
		var select = root.querySelector('.mvweb-seal__packaging');
		if (!select) return 310;

		if (select.value === 'custom') {
			var customInput = root.querySelector('.mvweb-seal__custom-volume');
			return customInput ? (parseInt(customInput.value, 10) || 310) : 310;
		}

		return parseInt(select.value, 10) || 310;
	}

	function getPrice(root) {
		var priceInput = root.querySelector('.mvweb-seal__price');
		if (!priceInput) return 0;
		return parseFloat(priceInput.value) || 0;
	}

	/* ══════════════════════════════════════════
	   Results Display
	   ══════════════════════════════════════════ */

	function updateResults(root, totalMl, packagingMl, hasValid) {
		var volumeEl = root.querySelector('[data-result="volume"]');
		var packagesEl = root.querySelector('[data-result="packages"]');
		var costEl = root.querySelector('[data-result="cost"]');
		var costItem = root.querySelector('.mvweb-seal__result-cost');

		if (!hasValid || totalMl <= 0) {
			if (volumeEl) volumeEl.textContent = '\u2014';
			if (packagesEl) packagesEl.textContent = '\u2014';
			if (costItem) costItem.style.display = 'none';
			var pkgTable = root.querySelector('.mvweb-seal__packaging-table');
			if (pkgTable) pkgTable.style.display = 'none';
			return;
		}

		var packages = Math.ceil(totalMl / packagingMl);

		// Volume.
		if (volumeEl) {
			var liters = totalMl / 1000;
			if (totalMl >= 1000) {
				volumeEl.textContent = Math.round(totalMl) + ' ' + (i18n.ml || 'ml') + ' (' + liters.toFixed(2) + ' ' + (i18n.l || 'L') + ')';
			} else {
				volumeEl.textContent = Math.round(totalMl) + ' ' + (i18n.ml || 'ml');
			}
		}

		// Packages.
		if (packagesEl) {
			packagesEl.textContent = packages + ' ' + (i18n.pcs || 'pcs') + ' \u00d7 ' + packagingMl + ' ' + (i18n.ml || 'ml');
		}

		// Cost.
		var price = getPrice(root);
		if (price > 0 && costItem && costEl) {
			var totalCost = packages * price;
			costEl.textContent = formatNumber(totalCost) + ' \u20bd';
			costItem.style.display = '';
		} else if (costItem) {
			costItem.style.display = 'none';
		}

		// Show packaging table.
		var pkgTable = root.querySelector('.mvweb-seal__packaging-table');
		if (pkgTable) pkgTable.style.display = '';

		// Clear previous result warning.
		var oldWarn = root.querySelector('.mvweb-seal__result-warning');
		if (oldWarn) oldWarn.remove();

		// Large volume warning.
		if (totalMl > 100000) {
			showWarningInResult(root, i18n.checkData || 'Check input data \u2014 calculated volume is very large');
		}
	}

	function showWarningInResult(root, text) {
		var warn = document.createElement('div');
		warn.className = 'mvweb-seal__warning mvweb-seal__warning--yellow mvweb-seal__result-warning';
		warn.textContent = text;

		var resultHeader = root.querySelector('.mvweb-seal__result-header');
		if (resultHeader && resultHeader.nextSibling) {
			resultHeader.parentNode.insertBefore(warn, resultHeader.nextSibling);
		}
	}

	/* ══════════════════════════════════════════
	   Packaging Table
	   ══════════════════════════════════════════ */

	function updatePackagingTable(root, totalMl) {
		var tbody = root.querySelector('[data-result="packaging-rows"]');
		if (!tbody || totalMl <= 0) return;

		var allPackaging = config.packaging || [];
		if (allPackaging.length === 0) return;

		// Clear existing rows.
		while (tbody.firstChild) {
			tbody.removeChild(tbody.firstChild);
		}

		var rows = [];
		var minRemainder = Infinity;
		var optimalIndex = -1;

		for (var i = 0; i < allPackaging.length; i++) {
			var vol = parseInt(allPackaging[i].volume, 10);
			if (!vol) continue;

			var qty = Math.ceil(totalMl / vol);
			var totalVol = qty * vol;
			var remainder = totalVol - totalMl;
			var remainderPct = totalVol > 0 ? (remainder / totalVol * 100) : 0;

			rows.push({
				label: allPackaging[i].label || (vol + ' ' + (i18n.ml || 'ml')),
				volume: vol,
				qty: qty,
				totalVol: totalVol,
				remainder: Math.round(remainder),
				remainderPct: remainderPct.toFixed(1)
			});

			if (remainder < minRemainder) {
				minRemainder = remainder;
				optimalIndex = rows.length - 1;
			}
		}

		for (var j = 0; j < rows.length; j++) {
			var isOptimal = j === optimalIndex;
			var tr = document.createElement('tr');
			if (isOptimal) tr.className = 'mvweb-seal__packaging-row--optimal';

			var td1 = document.createElement('td');
			td1.textContent = rows[j].label;
			tr.appendChild(td1);

			var td2 = document.createElement('td');
			td2.textContent = rows[j].qty + ' ' + (i18n.pcs || 'pcs');
			tr.appendChild(td2);

			var td3 = document.createElement('td');
			td3.textContent = rows[j].totalVol + ' ' + (i18n.ml || 'ml');
			tr.appendChild(td3);

			var td4 = document.createElement('td');
			td4.textContent = rows[j].remainder + ' ' + (i18n.ml || 'ml') + ' (' + rows[j].remainderPct + '%)';
			tr.appendChild(td4);

			tbody.appendChild(tr);
		}
	}

	/* ══════════════════════════════════════════
	   Formula Display
	   ══════════════════════════════════════════ */

	function updateFormula(root, sectionResults, waste, totalRaw, totalWithWaste, packagingMl) {
		var formulaEl = root.querySelector('[data-result="formula"]');
		if (!formulaEl) return;

		var lines = [];

		for (var i = 0; i < sectionResults.length; i++) {
			var r = sectionResults[i];
			var p = r.params;

			if (sectionResults.length > 1) {
				lines.push('--- ' + (i18n.section || 'Section') + ' ' + (i + 1) + ' ---');
			}

			lines.push((i18n.jointType || 'Joint type') + ': ' + (i18n[r.type] || r.type));
			lines.push((i18n.formula || 'Formula') + ': ' + (formulaNames[r.type] || ''));

			var subst = buildSubstitution(r.type, p);
			lines.push((i18n.substitution || 'Substitution') + ': ' + subst + ' = ' + r.volume.toFixed(1) + ' ' + (i18n.ml || 'ml'));
			lines.push('');
		}

		if (sectionResults.length > 1) {
			lines.push((i18n.total || 'Total') + ' (' + sectionResults.length + ' ' + (i18n.sections || 'sections') + '): ' + totalRaw.toFixed(1) + ' ' + (i18n.ml || 'ml'));
		}

		lines.push((i18n.waste || 'Waste') + ' ' + waste + '%: ' + totalRaw.toFixed(1) + ' \u00d7 ' + (1 + waste / 100).toFixed(2) + ' = ' + totalWithWaste.toFixed(1) + ' ' + (i18n.ml || 'ml'));

		var packages = Math.ceil(totalWithWaste / packagingMl);
		lines.push((i18n.packagesOf || 'Packages of') + ' ' + packagingMl + ' ' + (i18n.ml || 'ml') + ': CEIL(' + totalWithWaste.toFixed(1) + ' / ' + packagingMl + ') = ' + packages + ' ' + (i18n.pcs || 'pcs'));

		formulaEl.textContent = lines.join('\n');
	}

	function buildSubstitution(type, p) {
		var u = i18n.m || 'm';
		switch (type) {
			case 'rectangular':
				return p.width + ' \u00d7 ' + p.depth + ' \u00d7 ' + p.length + ' ' + u;
			case 'triangular':
				return p.width + ' \u00d7 ' + p.depth + ' / 2 \u00d7 ' + p.length + ' ' + u;
			case 'round':
				return '\u03c0 \u00d7 (' + p.diameter + '/2)\u00b2 \u00d7 ' + p.length + ' ' + u;
			case 'flat':
				return p.thickness + ' \u00d7 ' + p.width + ' \u00d7 ' + p.length + ' ' + u;
			case 'uShaped':
				return '(2 \u00d7 ' + p.thickness + ' \u00d7 ' + p.depth + ' + ' + p.thickness + ' \u00d7 ' + p.width + ') \u00d7 ' + p.length + ' ' + u;
			case 'conical':
			case 'trapezoidal':
				return '(' + p.widthTop + ' + ' + p.widthBottom + ') / 2 \u00d7 ' + p.depth + ' \u00d7 ' + p.length + ' ' + u;
			case 'ring':
				return '\u03c0 \u00d7 ' + p.pipeDiameter + ' \u00d7 ' + p.width + ' \u00d7 ' + p.depth;
			default:
				return '';
		}
	}

	/* ══════════════════════════════════════════
	   Validation
	   ══════════════════════════════════════════ */

	function validateSection(section, params) {
		var warningsEl = section.querySelector('.mvweb-seal__warnings');
		if (!warningsEl) return;

		// Clear existing warnings.
		while (warningsEl.firstChild) {
			warningsEl.removeChild(warningsEl.firstChild);
		}

		var type = params.type;

		// Depth > Width warning.
		if (['rectangular', 'triangular'].indexOf(type) !== -1 && params.depth > 0 && params.width > 0) {
			if (params.depth > params.width) {
				addWarning(warningsEl, i18n.depthWarning || 'Joint depth should not exceed width', 'yellow');
			}
		}

		// Deep joint.
		if (params.depth > 20 && ['rectangular', 'triangular', 'uShaped', 'conical', 'trapezoidal'].indexOf(type) !== -1) {
			addWarning(warningsEl, i18n.deepJointWarning || 'Backer rod recommended for depth > 20 mm', 'yellow');
		}

		// Wide joint.
		if (params.width > 50 && ['rectangular', 'triangular', 'flat', 'uShaped'].indexOf(type) !== -1) {
			addWarning(warningsEl, i18n.wideJointWarning || 'Unusually wide joint \u2014 check dimensions', 'yellow');
		}
	}

	function addWarning(container, text, color) {
		var div = document.createElement('div');
		div.className = 'mvweb-seal__warning mvweb-seal__warning--' + color;
		div.textContent = text;
		container.appendChild(div);
	}

	/* ══════════════════════════════════════════
	   Presets
	   ══════════════════════════════════════════ */

	function applyPreset(root, btn) {
		// Deselect all presets.
		var allPresets = root.querySelectorAll('.mvweb-seal__preset');
		for (var i = 0; i < allPresets.length; i++) {
			allPresets[i].classList.remove('mvweb-seal__preset--selected');
		}
		btn.classList.add('mvweb-seal__preset--selected');

		// Get first section.
		var section = root.querySelector('.mvweb-seal__section');
		if (!section) return;

		var type = btn.getAttribute('data-type');
		var typeSelect = section.querySelector('.mvweb-seal__joint-type');
		if (typeSelect && type) {
			typeSelect.value = type;
			updateFieldVisibility(section);
			loadSVG(section);
		}

		// Set values based on data attributes.
		setIfExists(section, '.mvweb-seal__width', btn.getAttribute('data-width'));
		setIfExists(section, '.mvweb-seal__depth', btn.getAttribute('data-depth'));
		setIfExists(section, '.mvweb-seal__diameter', btn.getAttribute('data-diameter'));
		setIfExists(section, '.mvweb-seal__thickness', btn.getAttribute('data-thickness'));
		setIfExists(section, '.mvweb-seal__width-top', btn.getAttribute('data-width-top'));
		setIfExists(section, '.mvweb-seal__width-bottom', btn.getAttribute('data-width-bottom'));
		setIfExists(section, '.mvweb-seal__pipe-diameter', btn.getAttribute('data-pipe-diameter'));

		// For flat preset, width is stored as data-flat-width.
		if (btn.getAttribute('data-flat-width')) {
			setIfExists(section, '.mvweb-seal__width', btn.getAttribute('data-flat-width'));
		}

		// Store preset name.
		root.setAttribute('data-preset', btn.getAttribute('data-preset') || '');

		debouncedCalculate(root);
	}

	function setIfExists(parent, selector, value) {
		if (value === null || value === undefined) return;
		var el = parent.querySelector(selector);
		if (el) el.value = value;
	}

	/* ══════════════════════════════════════════
	   Section Management
	   ══════════════════════════════════════════ */

	function addSection(root) {
		var container = root.querySelector('.mvweb-seal__sections');
		if (!container) return;

		var maxSections = parseInt(container.getAttribute('data-max'), 10) || 20;
		var current = container.querySelectorAll('.mvweb-seal__section');
		if (current.length >= maxSections) return;

		var num = current.length + 1;
		var template = current[0];
		var clone = template.cloneNode(true);

		// Update section number.
		var title = clone.querySelector('.mvweb-seal__section-title');
		if (title) {
			title.textContent = (i18n.section || 'Section') + ' ' + num;
		}

		clone.setAttribute('data-section', num);

		// Add remove button.
		var header = clone.querySelector('.mvweb-seal__section-header');
		if (header && !header.querySelector('.mvweb-seal__btn--remove')) {
			var removeBtn = document.createElement('button');
			removeBtn.type = 'button';
			removeBtn.className = 'mvweb-seal__btn--remove';
			removeBtn.textContent = '\u00d7';
			removeBtn.setAttribute('aria-label', (i18n.removeSection || 'Remove section') + ' ' + num);
			header.appendChild(removeBtn);
		}

		// Clear values.
		var inputs = clone.querySelectorAll('input[type="number"]');
		for (var i = 0; i < inputs.length; i++) {
			inputs[i].value = '';
			if (inputs[i].id) {
				inputs[i].id = inputs[i].id.replace(/-\d+$/, '-' + num);
			}
		}
		var selects = clone.querySelectorAll('select');
		for (var j = 0; j < selects.length; j++) {
			selects[j].selectedIndex = 0;
			if (selects[j].id) {
				selects[j].id = selects[j].id.replace(/-\d+$/, '-' + num);
			}
		}
		var labels = clone.querySelectorAll('label[for]');
		for (var k = 0; k < labels.length; k++) {
			labels[k].setAttribute('for', labels[k].getAttribute('for').replace(/-\d+$/, '-' + num));
		}

		// Clear warnings.
		var warnings = clone.querySelector('.mvweb-seal__warnings');
		if (warnings) {
			while (warnings.firstChild) {
				warnings.removeChild(warnings.firstChild);
			}
		}

		// Clear SVG.
		var svgContainer = clone.querySelector('.mvweb-seal__svg');
		if (svgContainer) {
			while (svgContainer.firstChild) {
				svgContainer.removeChild(svgContainer.firstChild);
			}
		}

		container.appendChild(clone);

		// Reset field visibility and load SVG.
		updateFieldVisibility(clone);
		loadSVG(clone);

		// Focus on the first input of new section.
		var firstInput = clone.querySelector('.mvweb-seal__joint-type');
		if (firstInput) firstInput.focus();

		debouncedCalculate(root);
	}

	function removeSection(root, section) {
		var container = root.querySelector('.mvweb-seal__sections');
		if (!container) return;

		var sections = container.querySelectorAll('.mvweb-seal__section');
		if (sections.length <= 1) return;

		section.remove();

		// Renumber remaining sections.
		var remaining = container.querySelectorAll('.mvweb-seal__section');
		for (var i = 0; i < remaining.length; i++) {
			var num = i + 1;
			remaining[i].setAttribute('data-section', num);
			var title = remaining[i].querySelector('.mvweb-seal__section-title');
			if (title) {
				title.textContent = (i18n.section || 'Section') + ' ' + num;
			}
		}

		debouncedCalculate(root);
	}

	/* ══════════════════════════════════════════
	   Reset
	   ══════════════════════════════════════════ */

	function resetCalculator(root) {
		var container = root.querySelector('.mvweb-seal__sections');
		if (!container) return;

		// Remove all sections except the first.
		var sections = container.querySelectorAll('.mvweb-seal__section');
		for (var i = sections.length - 1; i > 0; i--) {
			sections[i].remove();
		}

		// Reset first section.
		var first = container.querySelector('.mvweb-seal__section');
		if (first) {
			var inputs = first.querySelectorAll('input[type="number"]');
			for (var j = 0; j < inputs.length; j++) {
				inputs[j].value = '';
				inputs[j].classList.remove('mvweb-seal__input--error', 'mvweb-seal__input--warning');
			}

			var typeSelect = first.querySelector('.mvweb-seal__joint-type');
			if (typeSelect) {
				typeSelect.selectedIndex = 0;
				updateFieldVisibility(first);
				loadSVG(first);
			}

			var warnings = first.querySelector('.mvweb-seal__warnings');
			if (warnings) {
				while (warnings.firstChild) {
					warnings.removeChild(warnings.firstChild);
				}
			}
		}

		// Reset waste.
		var wasteInput = root.querySelector('.mvweb-seal__waste');
		if (wasteInput) wasteInput.value = settings.defaultWaste || 10;

		// Reset packaging.
		var packagingSelect = root.querySelector('.mvweb-seal__packaging');
		if (packagingSelect) {
			var found = false;
			for (var k = 0; k < packagingSelect.options.length; k++) {
				if (packagingSelect.options[k].value === '310') {
					packagingSelect.selectedIndex = k;
					found = true;
					break;
				}
			}
			if (!found) packagingSelect.selectedIndex = 0;
		}

		var customWrap = root.querySelector('.mvweb-seal__custom-packaging');
		if (customWrap) customWrap.style.display = 'none';

		// Reset price (only if not product-linked).
		var priceInput = root.querySelector('.mvweb-seal__price');
		if (priceInput && !root.getAttribute('data-product-id')) {
			priceInput.value = '';
		}

		// Deselect presets.
		var presets = root.querySelectorAll('.mvweb-seal__preset');
		for (var m = 0; m < presets.length; m++) {
			presets[m].classList.remove('mvweb-seal__preset--selected');
		}
		root.removeAttribute('data-preset');

		// Clear result warning.
		var resultWarn = root.querySelector('.mvweb-seal__result-warning');
		if (resultWarn) resultWarn.remove();

		calculate(root);
	}

	/* ══════════════════════════════════════════
	   Analytics
	   ══════════════════════════════════════════ */

	function trackAnalytics(root, sectionResults, totalMl, packagingMl, sectionCount) {
		if (!config.ajaxUrl || !config.nonce) return;

		clearTimeout(analyticsTimer);
		analyticsTimer = setTimeout(function () {
			var primaryType = sectionResults.length > 0 ? sectionResults[0].type : '';
			var preset = root.getAttribute('data-preset') || '';

			var data = new FormData();
			data.append('action', 'mvweb_seal_track');
			data.append('nonce', config.nonce);
			data.append('joint_type', primaryType);
			data.append('preset_used', preset || '');
			data.append('volume_ml', totalMl.toFixed(2));
			data.append('packaging_ml', packagingMl);
			data.append('sections', sectionCount);

			fetch(config.ajaxUrl, {
				method: 'POST',
				body: data
			}).catch(function () {
				// Silent fail for analytics.
			});
		}, 2000);
	}

	/* ══════════════════════════════════════════
	   Helpers
	   ══════════════════════════════════════════ */

	function formatNumber(num) {
		return num.toLocaleString('ru-RU', { maximumFractionDigits: 0 });
	}

	/* ══════════════════════════════════════════
	   Boot
	   ══════════════════════════════════════════ */

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}

})();
