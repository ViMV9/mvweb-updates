<?php
/**
 * Calculator frontend template.
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 *
 * @var int    $instance     Instance number.
 * @var string $layout       Layout type: 'full' or 'compact'.
 * @var bool   $show_presets Whether to show presets.
 * @var array  $settings     Plugin settings.
 * @var array  $packaging    Enabled packaging options.
 * @var array  $product_data WooCommerce product data (if any).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$calc_id    = 'mvweb-seal-' . $instance;
$is_compact = 'compact' === $layout;
$currency   = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '₽';
?>

<div id="<?php echo esc_attr( $calc_id ); ?>"
	 class="mvweb-seal<?php echo $is_compact ? ' mvweb-seal--compact' : ''; ?>"
	 data-instance="<?php echo esc_attr( $instance ); ?>"
	 <?php if ( ! empty( $product_data['id'] ) ) : ?>
		data-product-id="<?php echo esc_attr( $product_data['id'] ); ?>"
	 <?php endif; ?>
	 style="--mvweb-seal-accent: <?php echo esc_attr( $settings['accent_color'] ); ?>;<?php if ( ! empty( $header_gradient ) ) : ?> --mvweb-seal-header-bg: <?php echo esc_attr( $header_gradient ); ?>;<?php endif; ?><?php if ( ! empty( $header_color ) ) : ?> --mvweb-seal-header-color: <?php echo esc_attr( $header_color ); ?>;<?php endif; ?><?php if ( ! empty( $result_bg ) ) : ?> --mvweb-seal-result-bg: <?php echo esc_attr( $result_bg ); ?>;<?php endif; ?><?php if ( ! empty( $result_border ) ) : ?> --mvweb-seal-result-border: <?php echo esc_attr( $result_border ); ?>;<?php endif; ?>">

	<!-- ====== HEADER ====== -->
	<div class="mvweb-seal__header">
		<div class="mvweb-seal__header-text">
			<div class="mvweb-seal__title"><?php esc_html_e( 'Sealant / Adhesive Consumption Calculator', 'mvweb-sealant-calc' ); ?></div>
			<div class="mvweb-seal__subtitle"><?php esc_html_e( 'Calculate the exact amount of material for your project', 'mvweb-sealant-calc' ); ?></div>
		</div>
	</div>

	<?php if ( $show_presets ) : ?>
	<!-- ====== QUICK START ====== -->
	<div class="mvweb-seal__quick-start">
		<svg class="mvweb-seal__quick-start-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="20" height="20" fill="currentColor"><path d="M11.1 1.1 3.5 11h4.7L6.9 19l7.6-9.9H9.8z"/></svg>
		<select class="mvweb-seal__ctrl mvweb-seal__preset-select">
			<option value=""><?php esc_html_e( 'Select a common task...', 'mvweb-sealant-calc' ); ?></option>
			<option value="window" data-type="rectangular" data-width="10" data-depth="5"><?php esc_html_e( 'Window — frame-to-reveal joint', 'mvweb-sealant-calc' ); ?></option>
			<option value="bathtub" data-type="triangular" data-width="8" data-depth="8"><?php esc_html_e( 'Bathtub — wall joint', 'mvweb-sealant-calc' ); ?></option>
			<option value="interpanel" data-type="rectangular" data-width="20" data-depth="10"><?php esc_html_e( 'Inter-panel joint — 15-30 mm', 'mvweb-sealant-calc' ); ?></option>
			<option value="floor" data-type="rectangular" data-width="30" data-depth="15"><?php esc_html_e( 'Floor expansion joint — 20-50 mm', 'mvweb-sealant-calc' ); ?></option>
			<option value="pipe" data-type="ring" data-pipe-diameter="50" data-width="10" data-depth="5"><?php esc_html_e( 'Pipe connection sealing', 'mvweb-sealant-calc' ); ?></option>
			<option value="glazing" data-type="triangular" data-width="5" data-depth="5"><?php esc_html_e( 'Glazing unit — secondary seal', 'mvweb-sealant-calc' ); ?></option>
			<option value="facade" data-type="rectangular" data-width="25" data-depth="12"><?php esc_html_e( 'Facade — inter-panel joints', 'mvweb-sealant-calc' ); ?></option>
			<option value="roofing" data-type="rectangular" data-width="15" data-depth="8"><?php esc_html_e( 'Roofing element joints', 'mvweb-sealant-calc' ); ?></option>
			<option value="aquarium" data-type="triangular" data-width="5" data-depth="5"><?php esc_html_e( 'Aquarium — silicone joints', 'mvweb-sealant-calc' ); ?></option>
			<option value="automotive" data-type="round" data-diameter="6"><?php esc_html_e( 'Automotive — windshield, body seams', 'mvweb-sealant-calc' ); ?></option>
			<option value="electronics" data-type="round" data-diameter="3"><?php esc_html_e( 'Electronics — small spot repairs', 'mvweb-sealant-calc' ); ?></option>
			<option value="tiling" data-type="flat" data-thickness="3" data-flat-width="100"><?php esc_html_e( 'Tiling / Panels — adhesive layer', 'mvweb-sealant-calc' ); ?></option>
		</select>
	</div>

	<!-- Hidden buttons for JS compatibility -->
	<div class="mvweb-seal__presets" style="display:none !important;">
		<button type="button" class="mvweb-seal__preset" data-preset="window" data-type="rectangular" data-width="10" data-depth="5"></button>
		<button type="button" class="mvweb-seal__preset" data-preset="bathtub" data-type="triangular" data-width="8" data-depth="8"></button>
		<button type="button" class="mvweb-seal__preset" data-preset="interpanel" data-type="rectangular" data-width="20" data-depth="10"></button>
		<button type="button" class="mvweb-seal__preset" data-preset="floor" data-type="rectangular" data-width="30" data-depth="15"></button>
		<button type="button" class="mvweb-seal__preset" data-preset="pipe" data-type="ring" data-pipe-diameter="50" data-width="10" data-depth="5"></button>
		<button type="button" class="mvweb-seal__preset" data-preset="glazing" data-type="triangular" data-width="5" data-depth="5"></button>
		<button type="button" class="mvweb-seal__preset" data-preset="facade" data-type="rectangular" data-width="25" data-depth="12"></button>
		<button type="button" class="mvweb-seal__preset" data-preset="roofing" data-type="rectangular" data-width="15" data-depth="8"></button>
		<button type="button" class="mvweb-seal__preset" data-preset="aquarium" data-type="triangular" data-width="5" data-depth="5"></button>
		<button type="button" class="mvweb-seal__preset" data-preset="automotive" data-type="round" data-diameter="6"></button>
		<button type="button" class="mvweb-seal__preset" data-preset="electronics" data-type="round" data-diameter="3"></button>
		<button type="button" class="mvweb-seal__preset" data-preset="tiling" data-type="flat" data-thickness="3" data-flat-width="100"></button>
	</div>
	<?php endif; ?>

	<!-- ====== SECTIONS ====== -->
	<div class="mvweb-seal__sections" data-max="<?php echo esc_attr( $settings['max_sections'] ); ?>">
		<div class="mvweb-seal__section mvweb-seal__section--active" data-section="1">
			<div class="mvweb-seal__section-header">
				<div class="mvweb-seal__section-title"><?php printf( esc_html__( 'Section %d', 'mvweb-sealant-calc' ), 1 ); ?></div>
			</div>
			<div class="mvweb-seal__section-body">
				<div class="mvweb-seal__fields">
					<div class="mvweb-seal__field mvweb-seal__field--type">
						<label for="<?php echo esc_attr( $calc_id ); ?>-type-1"><?php esc_html_e( 'Joint type', 'mvweb-sealant-calc' ); ?> <span class="mvweb-seal__tooltip" data-tip="<?php esc_attr_e( 'Select the cross-section shape of the joint', 'mvweb-sealant-calc' ); ?>">?</span></label>
						<select id="<?php echo esc_attr( $calc_id ); ?>-type-1" class="mvweb-seal__ctrl mvweb-seal__joint-type mvweb-seal__input">
							<option value="rectangular"><?php esc_html_e( 'Rectangular', 'mvweb-sealant-calc' ); ?></option>
							<option value="triangular"><?php esc_html_e( 'Triangular (corner)', 'mvweb-sealant-calc' ); ?></option>
							<option value="round"><?php esc_html_e( 'Round bead', 'mvweb-sealant-calc' ); ?></option>
							<option value="flat"><?php esc_html_e( 'Flat layer', 'mvweb-sealant-calc' ); ?></option>
							<option value="uShaped"><?php esc_html_e( 'U-shaped', 'mvweb-sealant-calc' ); ?></option>
							<option value="conical"><?php esc_html_e( 'Conical', 'mvweb-sealant-calc' ); ?></option>
							<option value="trapezoidal"><?php esc_html_e( 'Trapezoidal', 'mvweb-sealant-calc' ); ?></option>
							<option value="ring"><?php esc_html_e( 'Ring (pipe)', 'mvweb-sealant-calc' ); ?></option>
						</select>
					</div>
					<div class="mvweb-seal__dims">
						<div class="mvweb-seal__field mvweb-seal__field--width">
							<label for="<?php echo esc_attr( $calc_id ); ?>-width-1"><?php esc_html_e( 'Width', 'mvweb-sealant-calc' ); ?> <span class="mvweb-seal__tooltip" data-tip="<?php esc_attr_e( 'Width of the gap between surfaces (mm)', 'mvweb-sealant-calc' ); ?>">?</span></label>
							<div class="mvweb-seal__input-group"><input type="number" id="<?php echo esc_attr( $calc_id ); ?>-width-1" class="mvweb-seal__ctrl mvweb-seal__width mvweb-seal__input" inputmode="decimal" min="1" max="200" step="0.1" placeholder="0"><span class="mvweb-seal__unit"><?php esc_html_e( 'mm', 'mvweb-sealant-calc' ); ?></span></div>
						</div>
						<div class="mvweb-seal__field mvweb-seal__field--depth">
							<label for="<?php echo esc_attr( $calc_id ); ?>-depth-1"><?php esc_html_e( 'Depth', 'mvweb-sealant-calc' ); ?> <span class="mvweb-seal__tooltip" data-tip="<?php esc_attr_e( 'Depth of sealant fill (mm). Optimal ratio width:depth = 2:1', 'mvweb-sealant-calc' ); ?>">?</span></label>
							<div class="mvweb-seal__input-group"><input type="number" id="<?php echo esc_attr( $calc_id ); ?>-depth-1" class="mvweb-seal__ctrl mvweb-seal__depth mvweb-seal__input" inputmode="decimal" min="1" max="100" step="0.1" placeholder="0"><span class="mvweb-seal__unit"><?php esc_html_e( 'mm', 'mvweb-sealant-calc' ); ?></span></div>
						</div>
						<div class="mvweb-seal__field mvweb-seal__field--diameter" style="display:none;">
							<label for="<?php echo esc_attr( $calc_id ); ?>-diameter-1"><?php esc_html_e( 'Diameter', 'mvweb-sealant-calc' ); ?> <span class="mvweb-seal__tooltip" data-tip="<?php esc_attr_e( 'Diameter of the sealant bead (mm)', 'mvweb-sealant-calc' ); ?>">?</span></label>
							<div class="mvweb-seal__input-group"><input type="number" id="<?php echo esc_attr( $calc_id ); ?>-diameter-1" class="mvweb-seal__ctrl mvweb-seal__diameter mvweb-seal__input" inputmode="decimal" min="1" max="50" step="0.1" placeholder="0"><span class="mvweb-seal__unit"><?php esc_html_e( 'mm', 'mvweb-sealant-calc' ); ?></span></div>
						</div>
						<div class="mvweb-seal__field mvweb-seal__field--thickness" style="display:none;">
							<label for="<?php echo esc_attr( $calc_id ); ?>-thickness-1"><?php esc_html_e( 'Thickness', 'mvweb-sealant-calc' ); ?> <span class="mvweb-seal__tooltip" data-tip="<?php esc_attr_e( 'Thickness of the applied layer (mm)', 'mvweb-sealant-calc' ); ?>">?</span></label>
							<div class="mvweb-seal__input-group"><input type="number" id="<?php echo esc_attr( $calc_id ); ?>-thickness-1" class="mvweb-seal__ctrl mvweb-seal__thickness mvweb-seal__input" inputmode="decimal" min="0.1" max="50" step="0.1" placeholder="0"><span class="mvweb-seal__unit"><?php esc_html_e( 'mm', 'mvweb-sealant-calc' ); ?></span></div>
						</div>
						<div class="mvweb-seal__field mvweb-seal__field--width-top" style="display:none;">
							<label for="<?php echo esc_attr( $calc_id ); ?>-width-top-1"><?php esc_html_e( 'Width top', 'mvweb-sealant-calc' ); ?> <span class="mvweb-seal__tooltip" data-tip="<?php esc_attr_e( 'Width at the top of the joint (mm)', 'mvweb-sealant-calc' ); ?>">?</span></label>
							<div class="mvweb-seal__input-group"><input type="number" id="<?php echo esc_attr( $calc_id ); ?>-width-top-1" class="mvweb-seal__ctrl mvweb-seal__width-top mvweb-seal__input" inputmode="decimal" min="1" max="200" step="0.1" placeholder="0"><span class="mvweb-seal__unit"><?php esc_html_e( 'mm', 'mvweb-sealant-calc' ); ?></span></div>
						</div>
						<div class="mvweb-seal__field mvweb-seal__field--width-bottom" style="display:none;">
							<label for="<?php echo esc_attr( $calc_id ); ?>-width-bottom-1"><?php esc_html_e( 'Width bottom', 'mvweb-sealant-calc' ); ?> <span class="mvweb-seal__tooltip" data-tip="<?php esc_attr_e( 'Width at the bottom of the joint (mm)', 'mvweb-sealant-calc' ); ?>">?</span></label>
							<div class="mvweb-seal__input-group"><input type="number" id="<?php echo esc_attr( $calc_id ); ?>-width-bottom-1" class="mvweb-seal__ctrl mvweb-seal__width-bottom mvweb-seal__input" inputmode="decimal" min="1" max="200" step="0.1" placeholder="0"><span class="mvweb-seal__unit"><?php esc_html_e( 'mm', 'mvweb-sealant-calc' ); ?></span></div>
						</div>
						<div class="mvweb-seal__field mvweb-seal__field--pipe-diameter" style="display:none;">
							<label for="<?php echo esc_attr( $calc_id ); ?>-pipe-diameter-1"><?php esc_html_e( 'Pipe diameter', 'mvweb-sealant-calc' ); ?> <span class="mvweb-seal__tooltip" data-tip="<?php esc_attr_e( 'Outer diameter of the pipe (mm)', 'mvweb-sealant-calc' ); ?>">?</span></label>
							<div class="mvweb-seal__input-group"><input type="number" id="<?php echo esc_attr( $calc_id ); ?>-pipe-diameter-1" class="mvweb-seal__ctrl mvweb-seal__pipe-diameter mvweb-seal__input" inputmode="decimal" min="1" max="2000" step="1" placeholder="0"><span class="mvweb-seal__unit"><?php esc_html_e( 'mm', 'mvweb-sealant-calc' ); ?></span></div>
						</div>
						<div class="mvweb-seal__field mvweb-seal__field--length">
							<label for="<?php echo esc_attr( $calc_id ); ?>-length-1"><?php esc_html_e( 'Length', 'mvweb-sealant-calc' ); ?> <span class="mvweb-seal__tooltip" data-tip="<?php esc_attr_e( 'Total length of the joint in meters', 'mvweb-sealant-calc' ); ?>">?</span></label>
							<div class="mvweb-seal__input-group"><input type="number" id="<?php echo esc_attr( $calc_id ); ?>-length-1" class="mvweb-seal__ctrl mvweb-seal__length mvweb-seal__input" inputmode="decimal" min="0.1" max="10000" step="0.1" placeholder="0"><span class="mvweb-seal__unit"><?php esc_html_e( 'm', 'mvweb-sealant-calc' ); ?></span></div>
						</div>
					</div>
					<div class="mvweb-seal__warnings"></div>
				</div>
				<div class="mvweb-seal__svg" role="img" aria-label="<?php esc_attr_e( 'Joint cross-section diagram', 'mvweb-sealant-calc' ); ?>"></div>
			</div>
		</div>
	</div>

	<!-- Add section -->
	<div class="mvweb-seal__add-section">
		<button type="button" class="mvweb-seal__btn mvweb-seal__btn--add">+ <?php esc_html_e( 'Add section', 'mvweb-sealant-calc' ); ?></button>
	</div>

	<!-- ====== PARAMETERS ====== -->
	<div class="mvweb-seal__params">
		<div class="mvweb-seal__field">
			<label for="<?php echo esc_attr( $calc_id ); ?>-waste"><?php esc_html_e( 'Waste', 'mvweb-sealant-calc' ); ?> <span class="mvweb-seal__tooltip" data-tip="<?php esc_attr_e( 'Extra material for uneven surfaces and losses (0-30%)', 'mvweb-sealant-calc' ); ?>">?</span></label>
			<div class="mvweb-seal__input-group"><input type="number" id="<?php echo esc_attr( $calc_id ); ?>-waste" class="mvweb-seal__ctrl mvweb-seal__waste mvweb-seal__input" inputmode="numeric" min="0" max="30" value="<?php echo esc_attr( $settings['default_waste'] ); ?>"><span class="mvweb-seal__unit">%</span></div>
		</div>
		<div class="mvweb-seal__field">
			<label for="<?php echo esc_attr( $calc_id ); ?>-packaging"><?php esc_html_e( 'Packaging', 'mvweb-sealant-calc' ); ?> <span class="mvweb-seal__tooltip" data-tip="<?php esc_attr_e( 'Volume of one package', 'mvweb-sealant-calc' ); ?>">?</span></label>
			<select id="<?php echo esc_attr( $calc_id ); ?>-packaging" class="mvweb-seal__ctrl mvweb-seal__packaging mvweb-seal__input">
				<?php foreach ( $packaging as $pack ) :
					$vol = absint( $pack['volume'] );
					$translated = ! empty( $pack['label'] ) ? mvweb_seal_translate_label( $pack['label'] ) : '';
					$display_label = ! empty( $translated ) ? $translated : ( $vol >= 1000 ? sprintf( '%g L', $vol / 1000 ) : $vol . ' ' . __( 'ml', 'mvweb-sealant-calc' ) );
					$selected = '';
					if ( ! empty( $product_data['volume'] ) && absint( $product_data['volume'] ) === $vol ) { $selected = ' selected'; }
					elseif ( 310 === $vol && empty( $product_data['volume'] ) ) { $selected = ' selected'; }
				?>
					<option value="<?php echo esc_attr( $vol ); ?>"<?php echo $selected; ?>><?php echo esc_html( $display_label ); ?></option>
				<?php endforeach; ?>
				<option value="custom"><?php esc_html_e( 'Custom...', 'mvweb-sealant-calc' ); ?></option>
			</select>
			<div class="mvweb-seal__custom-packaging" style="display:none;">
				<div class="mvweb-seal__input-group"><input type="number" class="mvweb-seal__ctrl mvweb-seal__custom-volume mvweb-seal__input" inputmode="numeric" min="1" max="100000" placeholder="<?php esc_attr_e( 'ml', 'mvweb-sealant-calc' ); ?>"><span class="mvweb-seal__unit"><?php esc_html_e( 'ml', 'mvweb-sealant-calc' ); ?></span></div>
			</div>
		</div>
		<?php if ( $settings['show_price'] ) : ?>
		<div class="mvweb-seal__field">
			<label for="<?php echo esc_attr( $calc_id ); ?>-price"><?php esc_html_e( 'Price per unit', 'mvweb-sealant-calc' ); ?> <span class="mvweb-seal__tooltip" data-tip="<?php esc_attr_e( 'Price of one package (optional)', 'mvweb-sealant-calc' ); ?>">?</span></label>
			<div class="mvweb-seal__input-group"><input type="number" id="<?php echo esc_attr( $calc_id ); ?>-price" class="mvweb-seal__ctrl mvweb-seal__price mvweb-seal__input" inputmode="decimal" min="0" step="0.01" <?php if ( ! empty( $product_data['price'] ) ) : ?>value="<?php echo esc_attr( $product_data['price'] ); ?>"<?php endif; ?> placeholder="<?php esc_attr_e( 'optional', 'mvweb-sealant-calc' ); ?>"><span class="mvweb-seal__unit"><?php echo esc_html( $currency ); ?></span></div>
		</div>
		<?php endif; ?>
	</div>

	<!-- ====== RESULT ====== -->
	<div class="mvweb-seal__result" aria-live="polite" aria-atomic="true">
		<div class="mvweb-seal__result-header">
			<div class="mvweb-seal__result-title"><?php esc_html_e( 'Calculation result', 'mvweb-sealant-calc' ); ?></div>
		</div>
		<div class="mvweb-seal__result-summary">
			<div class="mvweb-seal__result-item mvweb-seal__result-volume">
				<svg class="mvweb-seal__result-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M18 18V2H2v16h16zM16 5H4V3h12v2zm0 3H4V6h12v2zm-5 3H4V9h7v2z"/></svg>
				<div><span class="mvweb-seal__result-label"><?php esc_html_e( 'Volume', 'mvweb-sealant-calc' ); ?></span><span class="mvweb-seal__result-value" data-result="volume">&mdash;</span></div>
			</div>
			<div class="mvweb-seal__result-item mvweb-seal__result-packages">
				<svg class="mvweb-seal__result-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M10 .5l-8.5 5V15l8.5 4.5L18.5 15V5.5L10 .5zM10 2.14l6.24 3.69L10 9.52 3.76 5.83 10 2.14zM3.5 7.36l5.5 3.26v7.02L3.5 14.38V7.36zm7.5 10.28V10.62l5.5-3.26v7.02L11 17.64z"/></svg>
				<div><span class="mvweb-seal__result-label"><?php esc_html_e( 'Packages', 'mvweb-sealant-calc' ); ?></span><span class="mvweb-seal__result-value" data-result="packages">&mdash;</span></div>
			</div>
			<div class="mvweb-seal__result-item mvweb-seal__result-cost" style="display:none;">
				<svg class="mvweb-seal__result-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"><path d="M11 4V1H9v3H6v2h3v3h2V6h3V4h-3zm-1 7c-2.8 0-5 1.1-5 2.5V16h10v-2.5c0-1.4-2.2-2.5-5-2.5z"/></svg>
				<div><span class="mvweb-seal__result-label"><?php esc_html_e( 'Cost', 'mvweb-sealant-calc' ); ?></span><span class="mvweb-seal__result-value" data-result="cost">&mdash;</span></div>
			</div>
		</div>

		<div class="mvweb-seal__packaging-table" style="display:none;">
			<div class="mvweb-seal__packaging-title"><?php esc_html_e( 'All packaging options', 'mvweb-sealant-calc' ); ?></div>
			<table><thead><tr>
				<th><?php esc_html_e( 'Packaging', 'mvweb-sealant-calc' ); ?></th>
				<th><?php esc_html_e( 'Qty', 'mvweb-sealant-calc' ); ?></th>
				<th><?php esc_html_e( 'Total', 'mvweb-sealant-calc' ); ?></th>
				<th><?php esc_html_e( 'Remainder', 'mvweb-sealant-calc' ); ?></th>
			</tr></thead><tbody data-result="packaging-rows"></tbody></table>
		</div>

		<?php if ( $settings['show_formula'] ) : ?>
		<!-- Formula popup (hidden, shown by button) -->
		<div class="mvweb-seal__formula" style="display:none;">
			<div class="mvweb-seal__formula-overlay"></div>
			<div class="mvweb-seal__formula-popup">
				<div class="mvweb-seal__formula-popup-header">
					<div class="mvweb-seal__formula-popup-title"><?php esc_html_e( 'How we calculate?', 'mvweb-sealant-calc' ); ?></div>
					<button type="button" class="mvweb-seal__formula-close">&times;</button>
				</div>
				<div class="mvweb-seal__formula-content" data-result="formula"><?php esc_html_e( 'Fill in the fields and the formula will appear here.', 'mvweb-sealant-calc' ); ?></div>
			</div>
		</div>
		<?php endif; ?>

		<!-- Actions row -->
		<div class="mvweb-seal__actions">
			<?php if ( ! empty( $product_data['permalink'] ) ) : ?>
				<a href="<?php echo esc_url( $product_data['permalink'] ); ?>" class="mvweb-seal__btn mvweb-seal__btn--link" target="_blank"><?php echo esc_html( $settings['wc_product_link_text'] ?? __( 'View in catalog', 'mvweb-sealant-calc' ) ); ?></a>
			<?php endif; ?>
			<?php if ( $settings['show_formula'] ) : ?>
			<button type="button" class="mvweb-seal__btn mvweb-seal__btn--formula">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="16" height="16" fill="currentColor"><path d="M5 2h10a2 2 0 012 2v12a2 2 0 01-2 2H5a2 2 0 01-2-2V4a2 2 0 012-2zm0 2v12h10V4H5zm2 2h6v1.5H7V6zm0 3h6v1.5H7V9zm0 3h4v1.5H7V12z"/></svg>
				<?php esc_html_e( 'How we calculate?', 'mvweb-sealant-calc' ); ?>
			</button>
			<?php endif; ?>
			<button type="button" class="mvweb-seal__btn mvweb-seal__btn--print" disabled>
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="16" height="16" fill="currentColor"><path d="M4 5V1h12v4h2v7h-4v5H6v-5H2V5h2zm2-2v2h8V3H6zm8 10v-2H6v2h8zm2-4V7H4v2h12z"/></svg>
				<?php esc_html_e( 'Print', 'mvweb-sealant-calc' ); ?>
			</button>
			<button type="button" class="mvweb-seal__btn mvweb-seal__btn--reset">
				<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" width="16" height="16" fill="currentColor"><path d="M10 2a8 8 0 100 16 8 8 0 000-16zM4 10a6 6 0 0110.3-4.1L5.9 14.3A5.97 5.97 0 014 10zm6 6a5.97 5.97 0 01-4.3-1.9L14.1 5.7A6 6 0 0110 16z"/></svg>
				<?php esc_html_e( 'Reset', 'mvweb-sealant-calc' ); ?>
			</button>
		</div>
	</div>

	<script>
	(function(){
		var root = document.getElementById('<?php echo esc_js( $calc_id ); ?>');
		if (!root) return;
		/* Bridge: preset <select> → hidden <button> click */
		var ps = root.querySelector('.mvweb-seal__preset-select');
		if (ps) ps.addEventListener('change', function(){
			var v = this.value; if (!v) return;
			var b = root.querySelector('.mvweb-seal__preset[data-preset="'+v+'"]');
			if (b) b.click();
		});
		/* Tooltips: toggle on click, preventDefault to stop label focus */
		root.addEventListener('click', function(e){
			var tip = e.target.closest('.mvweb-seal__tooltip');
			if (tip) {
				e.preventDefault();
				e.stopPropagation();
				var wasActive = tip.classList.contains('mvweb-seal__tooltip--active');
				root.querySelectorAll('.mvweb-seal__tooltip--active').forEach(function(t){ t.classList.remove('mvweb-seal__tooltip--active'); });
				if (!wasActive) tip.classList.add('mvweb-seal__tooltip--active');
			} else {
				root.querySelectorAll('.mvweb-seal__tooltip--active').forEach(function(t){ t.classList.remove('mvweb-seal__tooltip--active'); });
			}
		});
		/* Formula popup */
		var fBtn = root.querySelector('.mvweb-seal__btn--formula');
		var fPop = root.querySelector('.mvweb-seal__formula');
		var fClose = root.querySelector('.mvweb-seal__formula-close');
		var fOverlay = root.querySelector('.mvweb-seal__formula-overlay');
		if (fBtn && fPop) {
			fBtn.addEventListener('click', function(){ fPop.style.display = 'flex'; });
			if (fClose) fClose.addEventListener('click', function(){ fPop.style.display = 'none'; });
			if (fOverlay) fOverlay.addEventListener('click', function(){ fPop.style.display = 'none'; });
		}
		/* Print disabled until result */
		var pb = root.querySelector('.mvweb-seal__btn--print');
		var ve = root.querySelector('[data-result="volume"]');
		if (pb && ve) new MutationObserver(function(){
			var t = ve.textContent.trim();
			pb.disabled = (!t || t === '\u2014' || t === '—');
		}).observe(ve, {childList:true, characterData:true, subtree:true});
	})();
	</script>
</div>
