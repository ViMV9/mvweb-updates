<?php
/**
 * Uninstall MVweb Sealant Calc
 *
 * Fired when the plugin is uninstalled.
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// Drop analytics table.
$table_name = $wpdb->prefix . 'mvweb_seal_analytics';
$wpdb->query( "DROP TABLE IF EXISTS {$table_name}" );

// Delete plugin options.
$options = array(
	'mvweb_seal_settings',
	'mvweb_seal_packaging',
	'mvweb_seal_db_version',
);

foreach ( $options as $option ) {
	delete_option( $option );
}

// For multisite, clean up all sites.
if ( is_multisite() ) {
	$sites = get_sites();
	foreach ( $sites as $site ) {
		switch_to_blog( $site->blog_id );

		$table_name = $wpdb->prefix . 'mvweb_seal_analytics';
		$wpdb->query( "DROP TABLE IF EXISTS {$table_name}" );

		foreach ( $options as $option ) {
			delete_option( $option );
		}

		restore_current_blog();
	}
}

// Clear any cached data.
wp_cache_flush();
