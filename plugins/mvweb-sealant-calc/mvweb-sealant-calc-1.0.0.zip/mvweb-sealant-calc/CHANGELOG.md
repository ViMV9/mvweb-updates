# Changelog

All notable changes to MVweb Sealant Calc will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.0] - 2026-03-31

### Added
- 8 joint types: rectangular, triangular, round bead, flat layer, U-shaped, conical, trapezoidal, ring
- Multiple sections support (up to 20 per calculation)
- 12 built-in task presets with quick start dropdown
- Interactive SVG cross-section diagrams with dimension labels
- Configurable packaging options (tubes, cartridges, buckets — 14 defaults)
- Packaging recommendation table with optimal choice highlight
- Formula transparency popup ("How we calculate?")
- Material waste percentage setting (0-30%)
- Optional price calculation with currency support
- Customizable colors: accent, header gradient, result block background/border
- Gradient presets for header and result block (Material Design)
- WooCommerce integration: product meta fields, auto-show on products, price/packaging auto-fill
- Usage analytics with dashboard (joint types, presets, volumes by period)
- Admin settings page with 5 tabs (General, Packaging, WooCommerce, Analytics, Help)
- Help tab with WooCommerce integration guide and shortcode reference
- Shortcode [mvweb_sealant_calc] with attributes: layout, product_id, show_presets, bg_color, border_color
- Responsive design (desktop, tablet 782px, mobile 480px)
- Print-friendly output with dedicated print styles
- Accessibility: ARIA labels, focus management, keyboard navigation, tooltips
- Full Russian (ru_RU) localization (221 strings)
- CSS isolation from theme styles (all: unset + scoped variables)
- MVweb Hub integration (menu, updater, plugin registration)
