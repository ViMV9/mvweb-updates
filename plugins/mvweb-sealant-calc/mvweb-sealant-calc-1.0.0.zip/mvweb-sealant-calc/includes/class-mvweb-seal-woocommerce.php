<?php
/**
 * WooCommerce integration for MVweb Sealant Calc.
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_Seal_WooCommerce
 *
 * Adds meta fields to WooCommerce products and auto-shows calculator.
 *
 * @since 1.0.0
 */
class MVweb_Seal_WooCommerce {

	/**
	 * Initialize WooCommerce hooks.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		// Add meta fields to product data tabs.
		add_action( 'woocommerce_product_data_tabs', array( __CLASS__, 'add_product_tab' ) );
		add_action( 'woocommerce_product_data_panels', array( __CLASS__, 'render_product_panel' ) );
		add_action( 'woocommerce_process_product_meta', array( __CLASS__, 'save_product_meta' ) );

		// Auto-show calculator on product pages.
		$settings = MVweb_Seal_Admin::get_settings();
		if ( ! empty( $settings['wc_auto_show'] ) ) {
			add_action( 'woocommerce_after_single_product_summary', array( __CLASS__, 'auto_show_calculator' ), 25 );
		}
	}

	/**
	 * Add "Sealant Calc" tab to product data.
	 *
	 * @since 1.0.0
	 * @param array $tabs Existing tabs.
	 * @return array
	 */
	public static function add_product_tab( $tabs ) {
		$tabs['mvweb_sealant_calc'] = array(
			'label'    => __( 'Sealant Calc', 'mvweb-sealant-calc' ),
			'target'   => 'mvweb_sealant_calc_data',
			'class'    => array(),
			'priority' => 80,
		);
		return $tabs;
	}

	/**
	 * Render product data panel.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_product_panel() {
		global $post;
		?>
		<div id="mvweb_sealant_calc_data" class="panel woocommerce_options_panel">
			<?php
			woocommerce_wp_text_input( array(
				'id'                => '_mvweb_seal_volume',
				'label'             => __( 'Package volume (ml)', 'mvweb-sealant-calc' ),
				'description'       => __( 'Volume of this package in milliliters (e.g. 310).', 'mvweb-sealant-calc' ),
				'desc_tip'          => true,
				'type'              => 'number',
				'custom_attributes' => array( 'min' => '1', 'step' => '1' ),
			) );

			woocommerce_wp_text_input( array(
				'id'          => '_mvweb_seal_unit',
				'label'       => __( 'Packaging unit', 'mvweb-sealant-calc' ),
				'description' => __( 'Description (e.g. "Cartridge 310 ml").', 'mvweb-sealant-calc' ),
				'desc_tip'    => true,
			) );

			woocommerce_wp_checkbox( array(
				'id'          => '_mvweb_seal_show_calc',
				'label'       => __( 'Show calculator', 'mvweb-sealant-calc' ),
				'description' => __( 'Display sealant calculator on this product page.', 'mvweb-sealant-calc' ),
			) );
			?>
		</div>
		<?php
	}

	/**
	 * Save product meta fields.
	 *
	 * @since 1.0.0
	 * @param int $post_id Product post ID.
	 * @return void
	 */
	public static function save_product_meta( $post_id ) {
		if ( ! isset( $_POST['woocommerce_meta_nonce'] ) ||
			! wp_verify_nonce( sanitize_key( $_POST['woocommerce_meta_nonce'] ), 'woocommerce_save_data' ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$volume = isset( $_POST['_mvweb_seal_volume'] ) ? absint( $_POST['_mvweb_seal_volume'] ) : '';
		$unit   = isset( $_POST['_mvweb_seal_unit'] ) ? sanitize_text_field( $_POST['_mvweb_seal_unit'] ) : '';
		$show   = isset( $_POST['_mvweb_seal_show_calc'] ) ? 'yes' : 'no';

		update_post_meta( $post_id, '_mvweb_seal_volume', $volume );
		update_post_meta( $post_id, '_mvweb_seal_unit', $unit );
		update_post_meta( $post_id, '_mvweb_seal_show_calc', $show );
	}

	/**
	 * Auto-show calculator on product pages where meta is set.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function auto_show_calculator() {
		global $post;

		if ( ! $post ) {
			return;
		}

		$show = get_post_meta( $post->ID, '_mvweb_seal_show_calc', true );
		if ( 'yes' !== $show ) {
			return;
		}

		echo do_shortcode( '[mvweb_sealant_calc product_id="' . absint( $post->ID ) . '"]' );
	}
}

MVweb_Seal_WooCommerce::init();
