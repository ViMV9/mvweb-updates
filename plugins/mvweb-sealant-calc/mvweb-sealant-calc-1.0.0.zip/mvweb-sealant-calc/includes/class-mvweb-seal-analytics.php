<?php
/**
 * Analytics handler for MVweb Sealant Calc.
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_Seal_Analytics
 *
 * Handles analytics tracking (public AJAX) and dashboard data (admin AJAX).
 *
 * @since 1.0.0
 */
class MVweb_Seal_Analytics {

	/**
	 * Allowed joint types for whitelist validation.
	 *
	 * @var array
	 */
	private static $allowed_joint_types = array(
		'rectangular',
		'triangular',
		'round',
		'flat',
		'uShaped',
		'conical',
		'trapezoidal',
		'ring',
	);

	/**
	 * Initialize AJAX hooks.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		// Public: track calculation (logged-in and not).
		add_action( 'wp_ajax_mvweb_seal_track', array( __CLASS__, 'track_calculation' ) );
		add_action( 'wp_ajax_nopriv_mvweb_seal_track', array( __CLASS__, 'track_calculation' ) );

		// Admin: get analytics data.
		add_action( 'wp_ajax_mvweb_seal_analytics', array( __CLASS__, 'get_analytics' ) );
	}

	/**
	 * Track a calculation via AJAX.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function track_calculation() {
		check_ajax_referer( 'mvweb_seal_track', 'nonce' );

		global $wpdb;

		$joint_type   = isset( $_POST['joint_type'] ) ? sanitize_text_field( $_POST['joint_type'] ) : '';
		$preset_used  = isset( $_POST['preset_used'] ) ? sanitize_text_field( $_POST['preset_used'] ) : null;
		$volume_ml    = isset( $_POST['volume_ml'] ) ? floatval( $_POST['volume_ml'] ) : 0;
		$packaging_ml = isset( $_POST['packaging_ml'] ) ? absint( $_POST['packaging_ml'] ) : 0;
		$sections     = isset( $_POST['sections'] ) ? absint( $_POST['sections'] ) : 1;

		// Validate joint type against whitelist.
		if ( ! in_array( $joint_type, self::$allowed_joint_types, true ) ) {
			wp_send_json_error( 'Invalid joint type.' );
		}

		if ( $volume_ml <= 0 || $packaging_ml <= 0 ) {
			wp_send_json_error( 'Invalid values.' );
		}

		$sections = min( 99, max( 1, $sections ) );

		$table_name = $wpdb->prefix . 'mvweb_seal_analytics';

		$wpdb->insert(
			$table_name,
			array(
				'joint_type'   => $joint_type,
				'preset_used'  => $preset_used,
				'volume_ml'    => $volume_ml,
				'packaging_ml' => $packaging_ml,
				'sections'     => $sections,
			),
			array( '%s', '%s', '%f', '%d', '%d' )
		);

		wp_send_json_success();
	}

	/**
	 * Get analytics data for admin dashboard.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function get_analytics() {
		check_ajax_referer( 'mvweb_seal_admin', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( 'Insufficient permissions.' );
		}

		global $wpdb;

		$period = isset( $_POST['period'] ) ? sanitize_text_field( $_POST['period'] ) : 'all';
		$table  = $wpdb->prefix . 'mvweb_seal_analytics';

		// Build date condition.
		$date_condition = '';
		$preset_condition = 'WHERE preset_used IS NOT NULL';

		if ( '7' === $period ) {
			$date_condition   = $wpdb->prepare( 'WHERE created_at >= %s', gmdate( 'Y-m-d H:i:s', strtotime( '-7 days' ) ) );
			$preset_condition = $wpdb->prepare( 'WHERE created_at >= %s AND preset_used IS NOT NULL', gmdate( 'Y-m-d H:i:s', strtotime( '-7 days' ) ) );
		} elseif ( '30' === $period ) {
			$date_condition   = $wpdb->prepare( 'WHERE created_at >= %s', gmdate( 'Y-m-d H:i:s', strtotime( '-30 days' ) ) );
			$preset_condition = $wpdb->prepare( 'WHERE created_at >= %s AND preset_used IS NOT NULL', gmdate( 'Y-m-d H:i:s', strtotime( '-30 days' ) ) );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table is safe prefix + constant.
		$total = $wpdb->get_var( "SELECT COUNT(*) FROM {$table} {$date_condition}" );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$joint_types = $wpdb->get_results(
			"SELECT joint_type, COUNT(*) as cnt FROM {$table} {$date_condition} GROUP BY joint_type ORDER BY cnt DESC LIMIT 10"
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$presets = $wpdb->get_results(
			"SELECT preset_used, COUNT(*) as cnt FROM {$table} {$preset_condition} GROUP BY preset_used ORDER BY cnt DESC LIMIT 10"
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$avg_volume = $wpdb->get_var( "SELECT AVG(volume_ml) FROM {$table} {$date_condition}" );

		wp_send_json_success( array(
			'total'       => (int) $total,
			'joint_types' => $joint_types,
			'presets'     => $presets,
			'avg_volume'  => round( (float) $avg_volume, 1 ),
		) );
	}
}

MVweb_Seal_Analytics::init();
