<?php
/**
 * Shortcode handler for MVweb Sealant Calc.
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_Seal_Shortcode
 *
 * Registers and renders the [mvweb_sealant_calc] shortcode.
 *
 * @since 1.0.0
 */
class MVweb_Seal_Shortcode {

	/**
	 * Whether assets have been enqueued.
	 *
	 * @var bool
	 */
	private static $enqueued = false;

	/**
	 * Instance counter for multiple shortcodes on one page.
	 *
	 * @var int
	 */
	private static $instance = 0;

	/**
	 * Initialize shortcode.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		add_shortcode( 'mvweb_sealant_calc', array( __CLASS__, 'render' ) );
	}

	/**
	 * Render the calculator shortcode.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public static function render( $atts ) {
		$atts = shortcode_atts(
			array(
				'layout'       => 'full',
				'product_id'   => 0,
				'show_presets' => 'true',
				'bg_color'     => '',
				'border_color' => '',
			),
			$atts,
			'mvweb_sealant_calc'
		);

		$atts['product_id']   = absint( $atts['product_id'] );
		$atts['show_presets'] = filter_var( $atts['show_presets'], FILTER_VALIDATE_BOOLEAN );

		// Enqueue assets once.
		if ( ! self::$enqueued ) {
			self::enqueue_assets( $atts );
			self::$enqueued = true;
		}

		++self::$instance;

		$settings  = MVweb_Seal_Admin::get_settings();
		$packaging = get_option( 'mvweb_seal_packaging', mvweb_seal_default_packaging() );

		// Filter enabled packaging only.
		$packaging = array_filter( $packaging, function ( $p ) {
			return ! empty( $p['enabled'] );
		} );

		// Sort by sort order.
		usort( $packaging, function ( $a, $b ) {
			return ( $a['sort'] ?? 0 ) - ( $b['sort'] ?? 0 );
		} );

		// WooCommerce product data.
		$product_data = array();
		if ( $atts['product_id'] && class_exists( 'WC_Product' ) ) {
			$product = wc_get_product( $atts['product_id'] );
			if ( $product ) {
				$product_data = array(
					'id'        => $atts['product_id'],
					'name'      => $product->get_name(),
					'price'     => $product->get_price(),
					'volume'    => get_post_meta( $atts['product_id'], '_mvweb_seal_volume', true ),
					'unit'      => get_post_meta( $atts['product_id'], '_mvweb_seal_unit', true ),
					'permalink' => $product->get_permalink(),
				);
			}
		}

		// Template variables.
		$template_vars = array(
			'instance'     => self::$instance,
			'layout'       => in_array( $atts['layout'], array( 'full', 'compact' ), true ) ? $atts['layout'] : 'full',
			'show_presets' => $atts['show_presets'] && $settings['show_presets'],
			'settings'     => $settings,
			'packaging'    => $packaging,
			'product_data' => $product_data,
			'header_gradient' => $settings['header_gradient'] ?? '',
			'header_color'    => $settings['header_color'] ?? '',
			'result_bg'       => $settings['result_bg'] ?? '',
			'result_border'   => $settings['result_border'] ?? '',
		);

		$instance     = $template_vars['instance'];
		$layout       = $template_vars['layout'];
		$show_presets = $template_vars['show_presets'];
		$settings     = $template_vars['settings'];
		$packaging    = $template_vars['packaging'];
		$product_data = $template_vars['product_data'];
		$header_gradient = $template_vars['header_gradient'];
		$header_color    = $template_vars['header_color'];
		$result_bg       = $template_vars['result_bg'];
		$result_border   = $template_vars['result_border'];

		ob_start();
		include MVWEB_SEAL_PATH . 'public/views/calculator.php';
		return ob_get_clean();
	}

	/**
	 * Enqueue frontend assets.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return void
	 */
	private static function enqueue_assets( $atts ) {
		$settings  = MVweb_Seal_Admin::get_settings();
		$packaging = get_option( 'mvweb_seal_packaging', mvweb_seal_default_packaging() );

		$packaging = array_values( array_filter( $packaging, function ( $p ) {
			return ! empty( $p['enabled'] );
		} ) );

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_style(
			'mvweb-seal-calculator',
			MVWEB_SEAL_URL . 'public/css/calculator' . $suffix . '.css',
			array(),
			MVWEB_SEAL_VERSION
		);

		wp_enqueue_script(
			'mvweb-seal-calculator',
			MVWEB_SEAL_URL . 'public/js/calculator' . $suffix . '.js',
			array(),
			MVWEB_SEAL_VERSION,
			true
		);

		// Build i18n strings for JS.
		$i18n = array(
			'section'            => __( 'Section', 'mvweb-sealant-calc' ),
			'removeSection'      => __( 'Remove section', 'mvweb-sealant-calc' ),
			'fillFields'         => __( 'Fill in the fields to calculate', 'mvweb-sealant-calc' ),
			'volume'             => __( 'Volume', 'mvweb-sealant-calc' ),
			'packages'           => __( 'Packages', 'mvweb-sealant-calc' ),
			'cost'               => __( 'Cost', 'mvweb-sealant-calc' ),
			'optimal'            => __( 'Optimal', 'mvweb-sealant-calc' ),
			'remainder'          => __( 'remainder', 'mvweb-sealant-calc' ),
			'pcs'                => __( 'pcs', 'mvweb-sealant-calc' ),
			'ml'                 => __( 'ml', 'mvweb-sealant-calc' ),
			'l'                  => __( 'L', 'mvweb-sealant-calc' ),
			'mm'                 => __( 'mm', 'mvweb-sealant-calc' ),
			'm'                  => __( 'm', 'mvweb-sealant-calc' ),
			'howWeCalculate'     => __( 'How we calculate?', 'mvweb-sealant-calc' ),
			'jointType'          => __( 'Joint type', 'mvweb-sealant-calc' ),
			'formula'            => __( 'Formula', 'mvweb-sealant-calc' ),
			'substitution'       => __( 'Substitution', 'mvweb-sealant-calc' ),
			'waste'              => __( 'Waste', 'mvweb-sealant-calc' ),
			'total'              => __( 'Total', 'mvweb-sealant-calc' ),
			'packagesOf'         => __( 'Packages of', 'mvweb-sealant-calc' ),
			'checkData'          => __( 'Check input data — calculated volume is very large', 'mvweb-sealant-calc' ),
			'depthWarning'       => __( 'Joint depth should not exceed width', 'mvweb-sealant-calc' ),
			'deepJointWarning'   => __( 'Backer rod recommended for depth > 20 mm', 'mvweb-sealant-calc' ),
			'wideJointWarning'   => __( 'Unusually wide joint — check dimensions', 'mvweb-sealant-calc' ),
			'rectangular'        => __( 'Rectangular', 'mvweb-sealant-calc' ),
			'triangular'         => __( 'Triangular (corner)', 'mvweb-sealant-calc' ),
			'round'              => __( 'Round bead', 'mvweb-sealant-calc' ),
			'flat'               => __( 'Flat layer', 'mvweb-sealant-calc' ),
			'uShaped'            => __( 'U-shaped', 'mvweb-sealant-calc' ),
			'conical'            => __( 'Conical', 'mvweb-sealant-calc' ),
			'trapezoidal'        => __( 'Trapezoidal', 'mvweb-sealant-calc' ),
			'ring'               => __( 'Ring (pipe)', 'mvweb-sealant-calc' ),
			'width'              => __( 'Width', 'mvweb-sealant-calc' ),
			'depth'              => __( 'Depth', 'mvweb-sealant-calc' ),
			'length'             => __( 'Length', 'mvweb-sealant-calc' ),
			'thickness'          => __( 'Thickness', 'mvweb-sealant-calc' ),
			'diameter'           => __( 'Diameter', 'mvweb-sealant-calc' ),
			'pipeDiameter'       => __( 'Pipe diameter', 'mvweb-sealant-calc' ),
			'widthTop'           => __( 'Width top', 'mvweb-sealant-calc' ),
			'widthBottom'        => __( 'Width bottom', 'mvweb-sealant-calc' ),
			'sections'           => __( 'sections', 'mvweb-sealant-calc' ),
		);

		// Build config for JS.
		$config = array(
			'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
			'nonce'        => wp_create_nonce( 'mvweb_seal_track' ),
			'svgUrl'       => MVWEB_SEAL_URL . 'public/svg/',
			'settings'     => array(
				'defaultWaste' => (int) $settings['default_waste'],
				'maxSections'  => (int) $settings['max_sections'],
				'showPresets'  => (bool) $settings['show_presets'],
				'showFormula'  => (bool) $settings['show_formula'],
				'showPrice'    => (bool) $settings['show_price'],
				'accentColor'  => $settings['accent_color'],
			),
			'packaging'    => array_values( $packaging ),
			'i18n'         => $i18n,
		);

		// Add product data if available.
		if ( $atts['product_id'] && class_exists( 'WC_Product' ) ) {
			$product = wc_get_product( absint( $atts['product_id'] ) );
			if ( $product ) {
				$config['product'] = array(
					'id'        => absint( $atts['product_id'] ),
					'price'     => (float) $product->get_price(),
					'volume'    => absint( get_post_meta( absint( $atts['product_id'] ), '_mvweb_seal_volume', true ) ),
					'permalink' => esc_url( $product->get_permalink() ),
					'linkText'  => $settings['wc_product_link_text'] ?? __( 'View in catalog', 'mvweb-sealant-calc' ),
				);
			}
		}

		wp_localize_script( 'mvweb-seal-calculator', 'mvwebSealConfig', $config );
	}
}

MVweb_Seal_Shortcode::init();
