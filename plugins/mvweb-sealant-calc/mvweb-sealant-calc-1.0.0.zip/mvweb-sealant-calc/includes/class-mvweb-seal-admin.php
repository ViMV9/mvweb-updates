<?php
/**
 * Admin settings class for MVweb Sealant Calc.
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_Seal_Admin
 *
 * Handles admin menu, settings page, enqueue, and settings save.
 *
 * @since 1.0.0
 */
class MVweb_Seal_Admin {

	/**
	 * Initialize admin hooks.
	 *
	 * @since 1.0.0
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Register submenu under MVweb Hub.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_menu() {
		$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

		add_submenu_page(
			$parent_slug,
			__( 'Sealant Calc', 'mvweb-sealant-calc' ),
			__( 'Sealant Calc', 'mvweb-sealant-calc' ),
			'manage_options',
			'mvweb-sealant-calc',
			array( __CLASS__, 'render_settings_page' )
		);
	}

	/**
	 * Render settings page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_settings_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// Save settings.
		if ( isset( $_POST['mvweb_seal_save'] ) ) {
			check_admin_referer( 'mvweb_seal_settings', 'mvweb_seal_nonce' );
			self::save_settings();
			add_settings_error(
				'mvweb_seal_messages',
				'mvweb_seal_message',
				__( 'Settings saved.', 'mvweb-sealant-calc' ),
				'updated'
			);
		}

		// Save packaging.
		if ( isset( $_POST['mvweb_seal_save_packaging'] ) ) {
			check_admin_referer( 'mvweb_seal_settings', 'mvweb_seal_nonce' );
			self::save_packaging();
			add_settings_error(
				'mvweb_seal_messages',
				'mvweb_seal_message',
				__( 'Packaging saved.', 'mvweb-sealant-calc' ),
				'updated'
			);
		}

		// Reset packaging to defaults.
		if ( isset( $_POST['mvweb_seal_reset_packaging'] ) ) {
			check_admin_referer( 'mvweb_seal_settings', 'mvweb_seal_nonce' );
			update_option( 'mvweb_seal_packaging', mvweb_seal_default_packaging() );
			add_settings_error(
				'mvweb_seal_messages',
				'mvweb_seal_message',
				__( 'Packaging reset to defaults.', 'mvweb-sealant-calc' ),
				'updated'
			);
		}

		// Save WooCommerce settings.
		if ( isset( $_POST['mvweb_seal_save_wc'] ) ) {
			check_admin_referer( 'mvweb_seal_settings', 'mvweb_seal_nonce' );
			self::save_wc_settings();
			add_settings_error(
				'mvweb_seal_messages',
				'mvweb_seal_message',
				__( 'WooCommerce settings saved.', 'mvweb-sealant-calc' ),
				'updated'
			);
		}

		include MVWEB_SEAL_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Save general settings.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function save_settings() {
		$settings = array(
			'default_waste' => isset( $_POST['default_waste'] ) ? absint( $_POST['default_waste'] ) : 10,
			'max_sections'  => isset( $_POST['max_sections'] ) ? absint( $_POST['max_sections'] ) : 20,
			'show_presets'  => isset( $_POST['show_presets'] ),
			'show_formula'  => isset( $_POST['show_formula'] ),
			'show_price'    => isset( $_POST['show_price'] ),
			'accent_color'    => isset( $_POST['accent_color'] ) ? sanitize_hex_color( $_POST['accent_color'] ) : '#793ea4',
			'header_gradient' => isset( $_POST['header_gradient'] ) ? sanitize_text_field( $_POST['header_gradient'] ) : '',
			'header_color'    => isset( $_POST['header_color'] ) ? sanitize_hex_color( $_POST['header_color'] ) : '',
			'result_bg'       => isset( $_POST['result_bg'] ) ? sanitize_text_field( $_POST['result_bg'] ) : '',
			'result_border'   => isset( $_POST['result_border'] ) ? sanitize_hex_color( $_POST['result_border'] ) : '',
		);

		// Clamp values.
		$settings['default_waste'] = min( 30, max( 0, $settings['default_waste'] ) );
		$settings['max_sections']  = min( 50, max( 1, $settings['max_sections'] ) );

		if ( empty( $settings['accent_color'] ) ) {
			$settings['accent_color'] = '#793ea4';
		}

		update_option( 'mvweb_seal_settings', $settings );
	}

	/**
	 * Save packaging list.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function save_packaging() {
		$packaging = array();

		if ( ! empty( $_POST['packaging_volume'] ) && is_array( $_POST['packaging_volume'] ) ) {
			$volumes    = $_POST['packaging_volume'];
			$labels     = $_POST['packaging_label'];
			$categories = $_POST['packaging_category'];
			$enabled    = isset( $_POST['packaging_enabled'] ) ? $_POST['packaging_enabled'] : array();

			foreach ( $volumes as $i => $volume ) {
				$vol = absint( $volume );
				if ( $vol < 1 ) {
					continue;
				}

				$allowed_categories = array( 'tube', 'cartridge', 'bucket' );
				$cat                = isset( $categories[ $i ] ) ? sanitize_text_field( $categories[ $i ] ) : 'cartridge';
				if ( ! in_array( $cat, $allowed_categories, true ) ) {
					$cat = 'cartridge';
				}

				$packaging[] = array(
					'volume'   => $vol,
					'label'    => isset( $labels[ $i ] ) ? sanitize_text_field( $labels[ $i ] ) : '',
					'category' => $cat,
					'enabled'  => isset( $enabled[ $i ] ),
					'sort'     => ( $i + 1 ) * 10,
				);
			}
		}

		if ( ! empty( $packaging ) ) {
			update_option( 'mvweb_seal_packaging', $packaging );
		}
	}

	/**
	 * Save WooCommerce settings.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function save_wc_settings() {
		$settings                       = get_option( 'mvweb_seal_settings', array() );
		$settings['wc_auto_show']       = isset( $_POST['wc_auto_show'] );
		$settings['wc_product_link_text'] = isset( $_POST['wc_product_link_text'] )
			? sanitize_text_field( $_POST['wc_product_link_text'] )
			: __( 'View in catalog', 'mvweb-sealant-calc' );

		update_option( 'mvweb_seal_settings', $settings );
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		if ( false === strpos( $hook, 'mvweb-sealant-calc' ) ) {
			return;
		}

		wp_enqueue_style( 'wp-color-picker' );

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_style(
			'mvweb-seal-admin-kit',
			MVWEB_SEAL_URL . 'admin/css/admin' . $suffix . '.css',
			array(),
			MVWEB_SEAL_VERSION
		);

		wp_enqueue_style(
			'mvweb-seal-admin',
			MVWEB_SEAL_URL . 'admin/css/plugin' . $suffix . '.css',
			array( 'mvweb-seal-admin-kit' ),
			MVWEB_SEAL_VERSION
		);

		wp_enqueue_script(
			'mvweb-seal-admin',
			MVWEB_SEAL_URL . 'admin/js/admin' . $suffix . '.js',
			array( 'jquery', 'wp-color-picker' ),
			MVWEB_SEAL_VERSION,
			true
		);

		wp_localize_script(
			'mvweb-seal-admin',
			'mvwebSealAdmin',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'mvweb_seal_admin' ),
				'strings'  => array(
					'tube'      => __( 'Tube', 'mvweb-sealant-calc' ),
					'cartridge' => __( 'Cartridge', 'mvweb-sealant-calc' ),
					'bucket'    => __( 'Bucket', 'mvweb-sealant-calc' ),
					'remove'    => __( 'Remove', 'mvweb-sealant-calc' ),
					'noData'    => __( 'No data', 'mvweb-sealant-calc' ),
				),
			)
		);
	}

	/**
	 * Get settings with defaults.
	 *
	 * @since 1.0.0
	 * @return array
	 */
	public static function get_settings() {
		$defaults = array(
			'default_waste'       => 10,
			'max_sections'        => 20,
			'show_presets'        => true,
			'show_formula'        => true,
			'show_price'          => true,
			'accent_color'        => '#793ea4',
			'header_gradient'     => '',
			'header_color'        => '',
			'result_bg'           => '',
			'result_border'       => '',
			'wc_auto_show'        => false,
			'wc_product_link_text' => __( 'View in catalog', 'mvweb-sealant-calc' ),
		);

		$settings = get_option( 'mvweb_seal_settings', array() );

		return wp_parse_args( $settings, $defaults );
	}
}

MVweb_Seal_Admin::init();
