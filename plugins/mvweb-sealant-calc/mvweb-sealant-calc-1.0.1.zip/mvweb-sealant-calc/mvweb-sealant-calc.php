<?php
/**
 * Plugin Name:       MVweb Sealant Calc
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-sealant-calc
 * Description:       Калькулятор расхода герметика и клея с расчётом по геометрии шва, рекомендациями по фасовке и интеграцией с WooCommerce.
 * Version:           1.0.1
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-sealant-calc
 * Domain Path:       /languages
 *
 * @package MVweb_Sealant_Calc
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_SEAL_VERSION' ) ) {
	return;
}

define( 'MVWEB_SEAL_VERSION', '1.0.1' );
define( 'MVWEB_SEAL_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_SEAL_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_SEAL_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_SEAL_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_SEAL_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_SEAL_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_SEAL_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_SEAL_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-sealant-calc' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-sealant-calc'] = array(
		'name'         => 'MVweb Sealant Calc',
		'description'  => __( 'Sealant and adhesive consumption calculator.', 'mvweb-sealant-calc' ),
		'url'          => 'https://mvweb.ru/plugins/mvweb-sealant-calc',
		'settings_url' => 'admin.php?page=mvweb-sealant-calc',
		'textdomain'   => 'mvweb-sealant-calc',
	);
	return $plugins;
} );

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_seal_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-sealant-calc',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_seal_load_textdomain' );

// Load plugin classes.
require_once MVWEB_SEAL_PATH . 'includes/class-mvweb-seal-admin.php';
require_once MVWEB_SEAL_PATH . 'includes/class-mvweb-seal-shortcode.php';
require_once MVWEB_SEAL_PATH . 'includes/class-mvweb-seal-analytics.php';

/**
 * Load WooCommerce integration once all plugins are loaded.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_seal_load_woocommerce() {
	if ( class_exists( 'WooCommerce' ) ) {
		require_once MVWEB_SEAL_PATH . 'includes/class-mvweb-seal-woocommerce.php';
	}
}
add_action( 'plugins_loaded', 'mvweb_seal_load_woocommerce' );

/**
 * Plugin activation hook.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_seal_activate() {
	global $wpdb;

	// Create analytics table.
	$table_name      = $wpdb->prefix . 'mvweb_seal_analytics';
	$charset_collate = $wpdb->get_charset_collate();

	$sql = "CREATE TABLE $table_name (
		id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
		joint_type VARCHAR(30) NOT NULL,
		preset_used VARCHAR(30) DEFAULT NULL,
		volume_ml DECIMAL(10,2) NOT NULL,
		packaging_ml INT UNSIGNED NOT NULL COMMENT 'Selected packaging in ml',
		sections TINYINT UNSIGNED NOT NULL DEFAULT 1,
		created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
		INDEX idx_created_at (created_at),
		INDEX idx_joint_type (joint_type)
	) $charset_collate;";

	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	dbDelta( $sql );

	update_option( 'mvweb_seal_db_version', '1.0.0' );

	// Set default settings.
	if ( false === get_option( 'mvweb_seal_settings' ) ) {
		update_option( 'mvweb_seal_settings', array(
			'default_waste'   => 10,
			'max_sections'    => 20,
			'show_presets'    => true,
			'show_formula'    => true,
			'show_price'      => true,
			'accent_color'    => '#793ea4',
		) );
	}

	// Set default packaging.
	if ( false === get_option( 'mvweb_seal_packaging' ) ) {
		update_option( 'mvweb_seal_packaging', mvweb_seal_default_packaging() );
	}
}
register_activation_hook( __FILE__, 'mvweb_seal_activate' );

/**
 * Plugin deactivation hook.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_seal_deactivate() {
	// Nothing to do on deactivation.
}
register_deactivation_hook( __FILE__, 'mvweb_seal_deactivate' );

/**
 * Get default packaging options.
 *
 * @since 1.0.0
 * @return array
 */
function mvweb_seal_default_packaging() {
	return array(
		array( 'volume' => 50, 'label' => 'Tube 50 ml', 'category' => 'tube', 'enabled' => true, 'sort' => 10 ),
		array( 'volume' => 80, 'label' => 'Tube 80 ml', 'category' => 'tube', 'enabled' => true, 'sort' => 20 ),
		array( 'volume' => 100, 'label' => 'Tube 100 ml', 'category' => 'tube', 'enabled' => true, 'sort' => 30 ),
		array( 'volume' => 280, 'label' => 'Cartridge 280 ml', 'category' => 'cartridge', 'enabled' => true, 'sort' => 40 ),
		array( 'volume' => 300, 'label' => 'Cartridge 300 ml', 'category' => 'cartridge', 'enabled' => true, 'sort' => 50 ),
		array( 'volume' => 310, 'label' => 'Cartridge 310 ml', 'category' => 'cartridge', 'enabled' => true, 'sort' => 60 ),
		array( 'volume' => 400, 'label' => 'Pro cartridge 400 ml', 'category' => 'cartridge', 'enabled' => true, 'sort' => 70 ),
		array( 'volume' => 600, 'label' => 'Pro cartridge 600 ml', 'category' => 'cartridge', 'enabled' => true, 'sort' => 80 ),
		array( 'volume' => 1000, 'label' => 'Bucket 1 L', 'category' => 'bucket', 'enabled' => true, 'sort' => 90 ),
		array( 'volume' => 3000, 'label' => 'Bucket 3 L', 'category' => 'bucket', 'enabled' => true, 'sort' => 100 ),
		array( 'volume' => 5000, 'label' => 'Bucket 5 L', 'category' => 'bucket', 'enabled' => true, 'sort' => 110 ),
		array( 'volume' => 7000, 'label' => 'Bucket 7 L', 'category' => 'bucket', 'enabled' => true, 'sort' => 120 ),
		array( 'volume' => 12000, 'label' => 'Bucket 12 L', 'category' => 'bucket', 'enabled' => true, 'sort' => 130 ),
		array( 'volume' => 20000, 'label' => 'Bucket 20 L', 'category' => 'bucket', 'enabled' => true, 'sort' => 140 ),
	);
}

/**
 * Translate a packaging label for display.
 *
 * Labels are stored in English in the database. This function
 * translates them at runtime using the plugin text domain.
 *
 * @since 1.0.0
 * @param string $label English label from DB.
 * @return string Translated label.
 */
function mvweb_seal_translate_label( $label ) {
	// Map of known default labels for translation.
	static $map = null;
	if ( null === $map ) {
		$map = array(
			'Tube 50 ml'           => __( 'Tube 50 ml', 'mvweb-sealant-calc' ),
			'Tube 80 ml'           => __( 'Tube 80 ml', 'mvweb-sealant-calc' ),
			'Tube 100 ml'          => __( 'Tube 100 ml', 'mvweb-sealant-calc' ),
			'Cartridge 280 ml'     => __( 'Cartridge 280 ml', 'mvweb-sealant-calc' ),
			'Cartridge 300 ml'     => __( 'Cartridge 300 ml', 'mvweb-sealant-calc' ),
			'Cartridge 310 ml'     => __( 'Cartridge 310 ml', 'mvweb-sealant-calc' ),
			'Pro cartridge 400 ml' => __( 'Pro cartridge 400 ml', 'mvweb-sealant-calc' ),
			'Pro cartridge 600 ml' => __( 'Pro cartridge 600 ml', 'mvweb-sealant-calc' ),
			'Bucket 1 L'           => __( 'Bucket 1 L', 'mvweb-sealant-calc' ),
			'Bucket 3 L'           => __( 'Bucket 3 L', 'mvweb-sealant-calc' ),
			'Bucket 5 L'           => __( 'Bucket 5 L', 'mvweb-sealant-calc' ),
			'Bucket 7 L'           => __( 'Bucket 7 L', 'mvweb-sealant-calc' ),
			'Bucket 12 L'          => __( 'Bucket 12 L', 'mvweb-sealant-calc' ),
			'Bucket 20 L'          => __( 'Bucket 20 L', 'mvweb-sealant-calc' ),
		);
	}
	return isset( $map[ $label ] ) ? $map[ $label ] : $label;
}
