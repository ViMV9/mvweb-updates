<?php
/**
 * General settings tab.
 *
 * Variables from settings-page.php: $settings
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$header_gradient_presets = array(
	'linear-gradient(135deg, #667eea, #764ba2)' => __( 'Deep Purple', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, #f093fb, #f5576c)' => __( 'Pink Glow', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, #4facfe, #00f2fe)' => __( 'Ocean Blue', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, #43e97b, #38f9d7)' => __( 'Fresh Green', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, #fa709a, #fee140)' => __( 'Sunset', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, #a18cd1, #fbc2eb)' => __( 'Lavender', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, #ffecd2, #fcb69f)' => __( 'Peach', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, #2b5876, #4e4376)' => __( 'Midnight', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, #0c3483, #a2b6df)' => __( 'Steel Blue', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, #e8198b, #c7eafd)' => __( 'Cotton Candy', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, #1a1a2e, #16213e)' => __( 'Dark Navy', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, #ff9a9e, #fecfef)' => __( 'Rose', 'mvweb-sealant-calc' ),
);

$header_gradient_fades = array(
	'linear-gradient(135deg, rgba(98,0,234,.15), transparent)'  => __( 'Purple fade', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, rgba(21,101,192,.15), transparent)' => __( 'Blue fade', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, rgba(0,137,123,.15), transparent)' => __( 'Teal fade', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, rgba(46,125,50,.15), transparent)' => __( 'Green fade', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, rgba(230,81,0,.15), transparent)'  => __( 'Orange fade', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, rgba(198,40,40,.15), transparent)' => __( 'Red fade', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, rgba(173,20,87,.15), transparent)' => __( 'Pink fade', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, rgba(55,71,79,.15), transparent)'  => __( 'Grey fade', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, rgba(26,26,46,.15), transparent)'  => __( 'Dark fade', 'mvweb-sealant-calc' ),
	'linear-gradient(135deg, rgba(249,168,37,.15), transparent)' => __( 'Gold fade', 'mvweb-sealant-calc' ),
);

$result_bg_presets = array(
	'linear-gradient(160deg, #f5f0fa, #eee8f5)' => __( 'Lavender Light', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, #e8eaf6, #c5cae9)' => __( 'Indigo Light', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, #e3f2fd, #bbdefb)' => __( 'Blue Light', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, #e8f5e9, #c8e6c9)' => __( 'Green Light', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, #fff3e0, #ffe0b2)' => __( 'Orange Light', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, #fce4ec, #f8bbd0)' => __( 'Pink Light', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, #f3e5f5, #e1bee7)' => __( 'Purple Light', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, #e0f7fa, #b2ebf2)' => __( 'Cyan Light', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, #eceff1, #cfd8dc)' => __( 'Grey Light', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, #fffde7, #fff9c4)' => __( 'Yellow Light', 'mvweb-sealant-calc' ),
	'#ffffff' => __( 'White', 'mvweb-sealant-calc' ),
	'#f5f5f5' => __( 'Light Grey', 'mvweb-sealant-calc' ),
);

$result_bg_fades = array(
	'linear-gradient(160deg, rgba(98,0,234,.1), transparent)'  => __( 'Purple fade', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, rgba(21,101,192,.1), transparent)' => __( 'Blue fade', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, rgba(0,137,123,.1), transparent)' => __( 'Teal fade', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, rgba(46,125,50,.1), transparent)' => __( 'Green fade', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, rgba(230,81,0,.1), transparent)'  => __( 'Orange fade', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, rgba(198,40,40,.1), transparent)' => __( 'Red fade', 'mvweb-sealant-calc' ),
	'linear-gradient(160deg, rgba(249,168,37,.08), transparent)' => __( 'Gold fade', 'mvweb-sealant-calc' ),
);
?>

<form method="post" action="">
	<?php wp_nonce_field( 'mvweb_seal_settings', 'mvweb_seal_nonce' ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Calculation', 'mvweb-sealant-calc' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Default values used by the calculator.', 'mvweb-sealant-calc' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb-seal-default-waste" class="mvweb-form-row__label">
				<?php esc_html_e( 'Default waste %', 'mvweb-sealant-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb-seal-default-waste" name="default_waste"
					class="mvweb-input mvweb-seal-input--short"
					value="<?php echo esc_attr( $settings['default_waste'] ); ?>"
					min="0" max="30">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Default material waste percentage (0-30%).', 'mvweb-sealant-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-seal-max-sections" class="mvweb-form-row__label">
				<?php esc_html_e( 'Max sections', 'mvweb-sealant-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb-seal-max-sections" name="max_sections"
					class="mvweb-input mvweb-seal-input--short"
					value="<?php echo esc_attr( $settings['max_sections'] ); ?>"
					min="1" max="50">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Maximum number of sections per calculation.', 'mvweb-sealant-calc' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Display options', 'mvweb-sealant-calc' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Toggle calculator elements on the front-end.', 'mvweb-sealant-calc' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb-seal-show-presets" class="mvweb-form-row__label">
				<?php esc_html_e( 'Task presets', 'mvweb-sealant-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox" id="mvweb-seal-show-presets" name="show_presets" value="1"
							<?php checked( $settings['show_presets'] ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Show task presets', 'mvweb-sealant-calc' ); ?></span>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-seal-show-formula" class="mvweb-form-row__label">
				<?php esc_html_e( 'Formula block', 'mvweb-sealant-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox" id="mvweb-seal-show-formula" name="show_formula" value="1"
							<?php checked( $settings['show_formula'] ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Show "How we calculate?" block', 'mvweb-sealant-calc' ); ?></span>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-seal-show-price" class="mvweb-form-row__label">
				<?php esc_html_e( 'Price field', 'mvweb-sealant-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox" id="mvweb-seal-show-price" name="show_price" value="1"
							<?php checked( $settings['show_price'] ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Show price field', 'mvweb-sealant-calc' ); ?></span>
				</div>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Colors', 'mvweb-sealant-calc' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Accent color and header/result block styling.', 'mvweb-sealant-calc' ); ?></p>

		<div class="mvweb-form-row">
			<label for="accent_color" class="mvweb-form-row__label">
				<?php esc_html_e( 'Accent color', 'mvweb-sealant-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text" id="accent_color" name="accent_color"
					value="<?php echo esc_attr( $settings['accent_color'] ); ?>"
					class="mvweb-color-picker" data-default-color="#793ea4">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Main color for buttons, headings, and result highlights.', 'mvweb-sealant-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="header_gradient" class="mvweb-form-row__label">
				<?php esc_html_e( 'Header background', 'mvweb-sealant-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select class="mvweb-select mvweb-seal-gradient-preset" data-target="header_gradient">
					<option value=""><?php esc_html_e( 'Gradient presets...', 'mvweb-sealant-calc' ); ?></option>
					<?php foreach ( $header_gradient_presets as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
					<option disabled>───── <?php esc_html_e( 'Fade to transparent', 'mvweb-sealant-calc' ); ?> ─────</option>
					<?php foreach ( $header_gradient_fades as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
				<input type="text" id="header_gradient" name="header_gradient"
					value="<?php echo esc_attr( $settings['header_gradient'] ?? '' ); ?>"
					class="mvweb-input"
					placeholder="linear-gradient(135deg, #793ea4, #5e2d80)">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Select a preset or enter a custom CSS gradient. Leave empty for default.', 'mvweb-sealant-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="header_color" class="mvweb-form-row__label">
				<?php esc_html_e( 'Header text color', 'mvweb-sealant-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text" id="header_color" name="header_color"
					value="<?php echo esc_attr( $settings['header_color'] ?? '' ); ?>"
					class="mvweb-color-picker" data-default-color="">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Text color for the header. Use white (#ffffff) with dark gradients.', 'mvweb-sealant-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="result_bg" class="mvweb-form-row__label">
				<?php esc_html_e( 'Result block background', 'mvweb-sealant-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select class="mvweb-select mvweb-seal-gradient-preset" data-target="result_bg">
					<option value=""><?php esc_html_e( 'Gradient presets...', 'mvweb-sealant-calc' ); ?></option>
					<?php foreach ( $result_bg_presets as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
					<option disabled>───── <?php esc_html_e( 'Fade to transparent', 'mvweb-sealant-calc' ); ?> ─────</option>
					<?php foreach ( $result_bg_fades as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
				<input type="text" id="result_bg" name="result_bg"
					value="<?php echo esc_attr( $settings['result_bg'] ?? '' ); ?>"
					class="mvweb-input"
					placeholder="linear-gradient(160deg, #f5f0fa, #eee8f5)">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Select a preset or enter a custom CSS gradient. Leave empty for default.', 'mvweb-sealant-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="result_border" class="mvweb-form-row__label">
				<?php esc_html_e( 'Result block border', 'mvweb-sealant-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text" id="result_border" name="result_border"
					value="<?php echo esc_attr( $settings['result_border'] ?? '' ); ?>"
					class="mvweb-color-picker" data-default-color="">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Border color for the result block. Leave empty for accent color.', 'mvweb-sealant-calc' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" name="mvweb_seal_save" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Save Changes', 'mvweb-sealant-calc' ); ?>
		</button>
	</div>
</form>
