<?php
/**
 * Analytics tab.
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Usage analytics', 'mvweb-sealant-calc' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Calculator usage stats for the selected period.', 'mvweb-sealant-calc' ); ?></p>

	<div class="mvweb-toolbar">
		<select class="mvweb-select" id="mvweb-seal-period">
			<option value="7"><?php esc_html_e( 'Last 7 days', 'mvweb-sealant-calc' ); ?></option>
			<option value="30" selected><?php esc_html_e( 'Last 30 days', 'mvweb-sealant-calc' ); ?></option>
			<option value="all"><?php esc_html_e( 'All time', 'mvweb-sealant-calc' ); ?></option>
		</select>
		<button type="button" class="mvweb-btn mvweb-btn--primary" id="mvweb-seal-load-analytics">
			<?php esc_html_e( 'Load', 'mvweb-sealant-calc' ); ?>
		</button>
	</div>

	<div class="mvweb-metrics" id="mvweb-seal-analytics-data">
		<div class="mvweb-metric">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Total calculations', 'mvweb-sealant-calc' ); ?></div>
			<div class="mvweb-metric__value" id="mvweb-seal-total">&mdash;</div>
		</div>
		<div class="mvweb-metric">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Average volume', 'mvweb-sealant-calc' ); ?></div>
			<div class="mvweb-metric__value" id="mvweb-seal-avg-volume">&mdash;</div>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Popular joint types', 'mvweb-sealant-calc' ); ?></div>
	</div>
	<div class="mvweb-table-wrap">
		<table class="mvweb-table" id="mvweb-seal-joint-types">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Joint type', 'mvweb-sealant-calc' ); ?></th>
					<th><?php esc_html_e( 'Count', 'mvweb-sealant-calc' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td colspan="2"><?php esc_html_e( 'Click "Load" to view data.', 'mvweb-sealant-calc' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Popular presets', 'mvweb-sealant-calc' ); ?></div>
	</div>
	<div class="mvweb-table-wrap">
		<table class="mvweb-table" id="mvweb-seal-presets">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Preset', 'mvweb-sealant-calc' ); ?></th>
					<th><?php esc_html_e( 'Count', 'mvweb-sealant-calc' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td colspan="2"><?php esc_html_e( 'Click "Load" to view data.', 'mvweb-sealant-calc' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>
