<?php
/**
 * Admin settings page template.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 *
 * Структура:
 *   .wrap.mvweb-settings  — корневой контейнер (max-width 1280px из UI Kit)
 *     ├── aside.mvweb-sidebar  — левая колонка 272px (бренд + меню вкладок)
 *     │     └── ul.mvweb-nav   — вкладки рендерятся как nav-ссылки с иконкой
 *     └── main.mvweb-main      — правая колонка (контент вкладок)
 *
 * Каждая вкладка — отдельный partial admin/views/tab-{slug}.php.
 * Переключение вкладок — на JS (admin.js), классы .mvweb-tab-content.active.
 *
 * Variables: $settings, $packaging, $wc_active.
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$wc_active = class_exists( 'WooCommerce' );
$settings  = MVweb_Seal_Admin::get_settings();
$packaging = get_option( 'mvweb_seal_packaging', mvweb_seal_default_packaging() );

$current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.

$tabs = array(
	'general'   => array(
		'label' => __( 'General', 'mvweb-sealant-calc' ),
		'icon'  => 'gear',
	),
	'packaging' => array(
		'label' => __( 'Packaging', 'mvweb-sealant-calc' ),
		'icon'  => 'box',
	),
);

if ( $wc_active ) {
	$tabs['woocommerce'] = array(
		'label' => __( 'WooCommerce', 'mvweb-sealant-calc' ),
		'icon'  => 'cart',
	);
}

$tabs['analytics'] = array(
	'label' => __( 'Analytics', 'mvweb-sealant-calc' ),
	'icon'  => 'chart',
);
$tabs['help'] = array(
	'label' => __( 'Help', 'mvweb-sealant-calc' ),
	'icon'  => 'help',
);

if ( ! isset( $tabs[ $current_tab ] ) ) {
	$current_tab = 'general';
}

$icons = array(
	'gear'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
	'box'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>',
	'cart'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>',
	'chart' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
	'help'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">SC</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Sealant Calc', 'mvweb-sealant-calc' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_SEAL_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $tabs as $tab_id => $tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $tab_id ); ?>"
						class="mvweb-nav__link <?php echo esc_attr( $current_tab === $tab_id ? 'mvweb-nav__link--active' : '' ); ?>"
						data-tab="<?php echo esc_attr( $tab_id ); ?>">
						<?php echo $icons[ $tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $tab['label'] ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php settings_errors( 'mvweb_seal_messages' ); ?>

		<div id="general" class="mvweb-tab-content <?php echo esc_attr( 'general' === $current_tab ? 'active' : '' ); ?>">
			<?php require MVWEB_SEAL_PATH . 'admin/views/tab-general.php'; ?>
		</div>

		<div id="packaging" class="mvweb-tab-content <?php echo esc_attr( 'packaging' === $current_tab ? 'active' : '' ); ?>">
			<?php require MVWEB_SEAL_PATH . 'admin/views/tab-packaging.php'; ?>
		</div>

		<?php if ( $wc_active ) : ?>
		<div id="woocommerce" class="mvweb-tab-content <?php echo esc_attr( 'woocommerce' === $current_tab ? 'active' : '' ); ?>">
			<?php require MVWEB_SEAL_PATH . 'admin/views/tab-woocommerce.php'; ?>
		</div>
		<?php endif; ?>

		<div id="analytics" class="mvweb-tab-content <?php echo esc_attr( 'analytics' === $current_tab ? 'active' : '' ); ?>">
			<?php require MVWEB_SEAL_PATH . 'admin/views/tab-analytics.php'; ?>
		</div>

		<div id="help" class="mvweb-tab-content <?php echo esc_attr( 'help' === $current_tab ? 'active' : '' ); ?>">
			<?php require MVWEB_SEAL_PATH . 'admin/views/tab-help.php'; ?>
		</div>

	</main>
</div>
