<?php
/**
 * WooCommerce settings tab.
 *
 * Variables from settings-page.php: $settings
 *
 * @package MVweb_Sealant_Calc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<form method="post" action="">
	<?php wp_nonce_field( 'mvweb_seal_settings', 'mvweb_seal_nonce' ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'WooCommerce integration', 'mvweb-sealant-calc' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Connect the calculator to your WooCommerce products.', 'mvweb-sealant-calc' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb-seal-wc-auto-show" class="mvweb-form-row__label">
				<?php esc_html_e( 'Auto-show on products', 'mvweb-sealant-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox" id="mvweb-seal-wc-auto-show" name="wc_auto_show" value="1"
							<?php checked( ! empty( $settings['wc_auto_show'] ) ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Display automatically on enabled products', 'mvweb-sealant-calc' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Automatically display calculator on products with Sealant Calc meta field enabled.', 'mvweb-sealant-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-seal-wc-link-text" class="mvweb-form-row__label">
				<?php esc_html_e( 'Product link text', 'mvweb-sealant-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb-seal-wc-link-text" name="wc_product_link_text"
					class="mvweb-input"
					value="<?php echo esc_attr( $settings['wc_product_link_text'] ?? __( 'View in catalog', 'mvweb-sealant-calc' ) ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Text for the product link in calculator results.', 'mvweb-sealant-calc' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" name="mvweb_seal_save_wc" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Save Changes', 'mvweb-sealant-calc' ); ?>
		</button>
	</div>
</form>
