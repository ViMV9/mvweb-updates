<?php
/**
 * Puts a site back from its MVweb Backup repository on an empty server.
 *
 * Usage: php restore.php --repo=owner/name --path=/site/root --db-name=NAME --db-user=USER
 *        [--db-host=localhost] [--at=YYYYMMDD] [--work=DIR] [--server-ip=127.0.0.1] [--new-domain=example.com]
 * Secrets are asked without echo or taken from MVWEB_RESTORE_TOKEN, MVWEB_RESTORE_KEY
 * and MVWEB_RESTORE_DB_PASSWORD.
 * Exit code: 0 when the site is restored and checked, 1 otherwise.
 *
 * @package mvweb_bk
 * @since   1.1.0
 */

declare(strict_types=1);

if ( 'cli' !== PHP_SAPI ) {
	exit;
}

// phpcs:disable WordPress.Files.FileName, WordPress.WP.AlternativeFunctions, WordPress.PHP.DiscouragedPHPFunctions, WordPress.PHP.NoSilencedErrors, WordPress.Security.EscapeOutput, WordPress.DB.RestrictedClasses, WordPress.DB.RestrictedFunctions, WordPress.PHP.IniSet, WordPress.WP.GlobalVariablesOverride, WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase, WordPress.PHP.DevelopmentFunctions -- standalone command-line tool, WordPress is not loaded.

/**
 * Restore run.
 *
 * @since 1.1.0
 */
final class MVweb_BK_Restore {

	const FORMAT = 2;

	const MANIFEST = 'mvweb-backup-manifest.json';

	const SAVED_CONFIG = 'wp-config.saved.php';

	const HOLD_FILE = 'wp-content/mu-plugins/mvweb-restore-hold.php';

	const WP_CLI = 'https://raw.githubusercontent.com/wp-cli/builds/gh-pages/phar/wp-cli.phar';

	const ENV_TOKEN = 'MVWEB_RESTORE_TOKEN';

	const ENV_KEY = 'MVWEB_RESTORE_KEY';

	const ENV_DB_PASSWORD = 'MVWEB_RESTORE_DB_PASSWORD';

	const PASSWORD_MARK = 'mvweb-restore-password-mark';

	const USAGE = "Usage: php restore.php --repo=owner/name --path=/site/root --db-name=NAME --db-user=USER\n"
		. "       [--db-host=localhost] [--at=YYYYMMDD] [--work=DIR] [--server-ip=127.0.0.1] [--new-domain=example.com]\n";

	/**
	 * Command-line options.
	 *
	 * @var array<string, string>
	 */
	private array $options;

	/**
	 * Site root.
	 *
	 * @var string
	 */
	private string $root = '';

	/**
	 * Temporary folder outside the site root.
	 *
	 * @var string
	 */
	private string $work = '';

	/**
	 * GitHub token.
	 *
	 * @var string
	 */
	private string $token = '';

	/**
	 * Database password.
	 *
	 * @var string
	 */
	private string $password = '';

	/**
	 * Secret key, raw bytes. Empty for a backup without encryption.
	 *
	 * @var string
	 */
	private string $secret = '';

	/**
	 * Site manifest from the database release.
	 *
	 * @var array<string, mixed>
	 */
	private array $manifest = array();

	/**
	 * Name of the mysql or mariadb command.
	 *
	 * @var string
	 */
	private string $client = '';

	/**
	 * Path of wp-cli.phar.
	 *
	 * @var string
	 */
	private string $phar = '';

	/**
	 * Path of the option file with the database password.
	 *
	 * @var string
	 */
	private string $db_file = '';

	/**
	 * Uploads folder of the restored site.
	 *
	 * @var string
	 */
	private string $uploads = '';

	/**
	 * Old domain without www. Empty when the domain stays.
	 *
	 * @var string
	 */
	private string $old_domain = '';

	/**
	 * Whether downloads started: they stay for the next attempt.
	 *
	 * @var bool
	 */
	private bool $fetched = false;

	/**
	 * Whether this run created the temporary folder: an older one can hold downloads.
	 *
	 * @var bool
	 */
	private bool $created = false;

	/**
	 * Whether the server was changed: a new attempt needs a clean folder and database.
	 *
	 * @var bool
	 */
	private bool $touched = false;

	/**
	 * Things to look at after the run.
	 *
	 * @var string[]
	 */
	private array $warnings = array();

	/**
	 * Checks that did not pass.
	 *
	 * @var string[]
	 */
	private array $failures = array();

	/**
	 * Checks that passed.
	 *
	 * @var string[]
	 */
	private array $passed = array();

	/**
	 * Set the options.
	 *
	 * @param array<string, string> $options Parsed command line.
	 */
	public function __construct( array $options ) {
		$this->options = $options;
	}

	/**
	 * Parse the command line.
	 *
	 * @param string[] $args Arguments without the script name.
	 * @return array<string, string>
	 * @throws RuntimeException On an unknown or missing option.
	 */
	public static function parse( array $args ): array {
		$allowed = array( 'repo', 'path', 'db-name', 'db-user', 'db-host', 'at', 'work', 'server-ip', 'new-domain' );
		$options = array();

		foreach ( $args as $arg ) {
			if ( ! preg_match( '/^--([a-z-]+)=(.*)$/s', $arg, $match ) || ! in_array( $match[1], $allowed, true ) ) {
				throw new RuntimeException( "Unknown argument: {$arg}\n" . self::USAGE );
			}

			$options[ $match[1] ] = $match[2];
		}

		foreach ( array( 'repo', 'path', 'db-name', 'db-user' ) as $required ) {
			if ( '' === ( $options[ $required ] ?? '' ) ) {
				throw new RuntimeException( "--{$required} is required.\n" . self::USAGE );
			}
		}

		if ( ! preg_match( '#^[A-Za-z0-9._-]+/[A-Za-z0-9._-]+$#', $options['repo'] ) ) {
			throw new RuntimeException( '--repo must look like owner/name.' );
		}

		if ( isset( $options['at'] ) && ! preg_match( '/^\d{8}(-\d{6})?$/', $options['at'] ) ) {
			throw new RuntimeException( '--at must look like YYYYMMDD or YYYYMMDD-HHMMSS.' );
		}

		if ( isset( $options['new-domain'] ) ) {
			$options['new-domain'] = strtolower( $options['new-domain'] );

			if ( ! preg_match( '/^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/D', $options['new-domain'] ) ) {
				throw new RuntimeException( '--new-domain must be a domain only, like example.com: no scheme, port or path. Write a national domain in its xn-- form.' );
			}
		}

		return $options + array(
			'db-host'    => 'localhost',
			'at'         => '',
			'work'       => '',
			'server-ip'  => '127.0.0.1',
			'new-domain' => '',
		);
	}

	/**
	 * Run the restore.
	 *
	 * @return int Exit code.
	 */
	public function run(): int {
		$started = time();
		umask( 0022 );

		try {
			$this->prepare();
			$backup = $this->choose_backup();

			$this->read_manifest( $backup['manifest'] );
			$this->download_all( $backup );

			$plain = $this->open_files( $backup );

			$this->install_core();
			$this->import_database( $plain['db'] );
			$this->verify_rows();
			$this->create_config();

			$root_files = $this->put_files( $plain['code'], $backup['uploads'] );

			$this->write_hold();
			$this->check_wordpress();
			$this->replace_path( $root_files );
			$this->replace_domain();
			$this->finish_site();
			$this->verify( $root_files );
			$this->write_report( $backup, time() - $started );
			$this->clean_up();
		} catch ( Throwable $e ) {
			$this->fail_run( $e );

			return 1;
		}

		return $this->failures ? 1 : 0;
	}

	/**
	 * Check the server, read the secrets and create the temporary folder.
	 *
	 * @return void
	 * @throws RuntimeException When the server is not ready.
	 */
	private function prepare(): void {
		self::say( 'Checking the server' );

		if ( PHP_VERSION_ID < 80200 ) {
			throw new RuntimeException( 'PHP 8.2 or newer is required. This is ' . PHP_VERSION . '. Run the script with a newer PHP binary.' );
		}

		if ( function_exists( 'posix_geteuid' ) && 0 === posix_geteuid() ) {
			throw new RuntimeException( 'Do not run this as root: the site files would belong to root. Run it as the site user.' );
		}

		foreach ( array( 'curl', 'zip', 'zlib', 'mysqli', 'phar' ) as $extension ) {
			if ( ! extension_loaded( $extension ) ) {
				throw new RuntimeException( "The PHP extension {$extension} is required." );
			}
		}

		foreach ( array( 'proc_open', 'proc_close' ) as $function ) {
			if ( ! function_exists( $function ) ) {
				throw new RuntimeException( "The PHP function {$function} is disabled." );
			}
		}

		if ( version_compare( (string) curl_version()['version'], '7.58.0', '<' ) ) {
			throw new RuntimeException( 'libcurl 7.58 or newer is required: older versions send the token to the file storage.' );
		}

		$root = realpath( $this->options['path'] );

		if ( false === $root || ! is_dir( $root ) || ! is_writable( $root ) ) {
			throw new RuntimeException( 'The site folder does not exist or is not writable: ' . $this->options['path'] );
		}

		$this->root = $root;

		$extra = array_diff( (array) scandir( $root ), array( '.', '..', '.well-known', 'cgi-bin', basename( __FILE__ ) ) );

		if ( $extra ) {
			throw new RuntimeException( 'The site folder is not empty. Clear it first: ' . implode( ', ', array_slice( $extra, 0, 10 ) ) );
		}

		$parent = realpath( '' !== $this->options['work'] ? $this->options['work'] : dirname( $root ) );

		if ( false === $parent || ! is_writable( $parent ) ) {
			throw new RuntimeException( 'The temporary folder cannot be created. Choose a writable folder outside the site root with --work=' );
		}

		$work = $parent . '/mvweb-restore-work';

		if ( 0 === strpos( $work . '/', $root . '/' ) ) {
			throw new RuntimeException( 'The temporary folder must be outside the site root: decrypted files go there. Use --work=' );
		}

		$created = ! is_dir( $work );

		if ( ! is_dir( $work . '/plain' ) && ! @mkdir( $work . '/plain', 0700, true ) ) {
			throw new RuntimeException( 'The temporary folder cannot be created: ' . $work );
		}

		if ( ! @chmod( $work, 0700 ) || ! @chmod( $work . '/plain', 0700 ) ) {
			throw new RuntimeException( 'The temporary folder belongs to another user: ' . $work . '. Choose another folder with --work=' );
		}

		$this->work    = $work;
		$this->created = $created;

		self::say( '  Temporary folder: ' . $this->work . '. If you interrupt the script, delete this folder: it can hold the database.' );

		$this->find_client();

		$this->token    = trim( self::secret( self::ENV_TOKEN, 'GitHub token' ) );
		$this->password = self::secret( self::ENV_DB_PASSWORD, 'Database password' );

		$this->write_client_options();

		$database = $this->database();
		$tables   = $database->query( 'SHOW TABLES' );

		if ( false === $tables || $tables->num_rows > 0 ) {
			throw new RuntimeException( 'The database is not empty. Use an empty one: the backup replaces tables with the same names.' );
		}

		self::say( '  PHP ' . PHP_VERSION . ', database ' . $database->server_info . ', site folder ' . $root );
	}

	/**
	 * Find the database client.
	 *
	 * @return void
	 * @throws RuntimeException When there is none.
	 */
	private function find_client(): void {
		foreach ( array( 'mariadb', 'mysql' ) as $binary ) {
			if ( 0 === $this->process( array( $binary, '--version' ) )['code'] ) {
				$this->client = $binary;

				return;
			}
		}

		throw new RuntimeException( 'The mysql or mariadb command is required to import the dump.' );
	}

	/**
	 * Write the option file for the database client, readable by the owner only.
	 *
	 * @return void
	 * @throws RuntimeException When it cannot be written.
	 */
	private function write_client_options(): void {
		$server = self::parse_host( $this->options['db-host'] );
		$quote  = static fn( string $value ): string => '"' . addcslashes( $value, '\\"' ) . '"';
		$text   = "[client]\nuser=" . $quote( $this->options['db-user'] ) . "\npassword=" . $quote( $this->password ) . "\n";

		if ( '' !== $server['host'] ) {
			$text .= 'host=' . $quote( $server['host'] ) . "\n";
		}

		if ( $server['port'] > 0 ) {
			$text .= 'port=' . $server['port'] . "\n";
		}

		if ( '' !== $server['socket'] ) {
			$text .= 'socket=' . $quote( $server['socket'] ) . "\n";
		}

		$this->db_file = $this->work . '/db.cnf';

		if ( ! touch( $this->db_file ) || ! chmod( $this->db_file, 0600 ) || ! file_put_contents( $this->db_file, $text ) ) {
			throw new RuntimeException( 'The temporary folder is not writable: ' . $this->work );
		}
	}

	/**
	 * Split a database host into host, port and socket.
	 *
	 * @param string $value Host as in DB_HOST.
	 * @return array{host: string, port: int, socket: string}
	 */
	private static function parse_host( string $value ): array {
		if ( preg_match( '#^(.*):(/.+)$#', $value, $match ) ) {
			return array(
				'host'   => $match[1],
				'port'   => 0,
				'socket' => $match[2],
			);
		}

		if ( preg_match( '/^(.*):(\d+)$/', $value, $match ) ) {
			return array(
				'host'   => $match[1],
				'port'   => (int) $match[2],
				'socket' => '',
			);
		}

		return array(
			'host'   => $value,
			'port'   => 0,
			'socket' => '',
		);
	}

	/**
	 * Open a new database connection. A long step can outlive an idle connection.
	 *
	 * @return mysqli
	 * @throws RuntimeException When the connection fails.
	 */
	private function database(): mysqli {
		$server = self::parse_host( $this->options['db-host'] );

		mysqli_report( MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT );

		try {
			return new mysqli(
				$server['host'],
				$this->options['db-user'],
				$this->password,
				$this->options['db-name'],
				$server['port'] > 0 ? $server['port'] : null,
				'' !== $server['socket'] ? $server['socket'] : null
			);
		} catch ( mysqli_sql_exception $e ) {
			throw new RuntimeException( 'The database connection failed: ' . $e->getMessage() );
		}
	}

	/**
	 * Read a secret from the environment, otherwise from the terminal without echo.
	 *
	 * @param string $env   Environment variable.
	 * @param string $label Prompt.
	 * @return string
	 * @throws RuntimeException When the input cannot be hidden.
	 */
	private static function secret( string $env, string $label ): string {
		$value = getenv( $env );

		if ( false !== $value ) {
			return $value;
		}

		$terminal = stream_isatty( STDIN );

		if ( $terminal && ! self::terminal_echo( false ) ) {
			throw new RuntimeException( "The input cannot be hidden on this server. Set the variable {$env} instead." );
		}

		echo $label . ': ';

		$line = fgets( STDIN );

		if ( $terminal ) {
			self::terminal_echo( true );
			echo "\n";
		}

		return rtrim( false === $line ? '' : $line, "\r\n" );
	}

	/**
	 * Turn the terminal echo on or off.
	 *
	 * @param bool $on Echo on.
	 * @return bool Whether it worked.
	 */
	private static function terminal_echo( bool $on ): bool {
		$pipes   = array();
		$process = @proc_open(
			array( 'stty', $on ? 'echo' : '-echo' ),
			array(
				0 => STDIN,
				1 => array( 'file', '/dev/null', 'w' ),
				2 => array( 'file', '/dev/null', 'w' ),
			),
			$pipes
		);

		return is_resource( $process ) && 0 === proc_close( $process );
	}

	/**
	 * Choose the releases to restore from.
	 *
	 * @return array{db: array<string, mixed>, manifest: array<string, mixed>, code: array<string, mixed>, uploads: array<int, array<string, mixed>>, db_tag: string, code_tag: string}
	 * @throws RuntimeException When a part is missing.
	 */
	private function choose_backup(): array {
		self::say( 'Reading the backup list' );

		$releases = array();

		for ( $page = 1; ; $page++ ) {
			$list     = $this->api( '/releases?per_page=100&page=' . $page );
			$releases = array_merge( $releases, $list );

			if ( count( $list ) < 100 ) {
				break;
			}
		}

		$db   = $this->newest( $releases, 'db', '.sql.gz' );
		$code = $this->newest( $releases, 'code', '.zip' );

		if ( null === $db ) {
			throw new RuntimeException( 'No database backup with a manifest was found' . ( '' !== $this->options['at'] ? ' up to ' . $this->options['at'] : '' ) . '. A backup made by plugin version 1.0.0 has no manifest: restore it by hand, the steps are in the README of the repository.' );
		}

		if ( null === $code ) {
			throw new RuntimeException( 'No code backup was found' . ( '' !== $this->options['at'] ? ' up to ' . $this->options['at'] : '' ) . '.' );
		}

		$manifest = self::asset( $db['release'], '.manifest.json' );

		if ( self::is_sealed( $db['asset'] ) || self::is_sealed( $code['asset'] ) || self::is_sealed( $manifest ) ) {
			$this->read_secret_key();
		}

		self::say( '  Database: ' . $db['release']['tag_name'] . ', ' . self::size( (int) $db['asset']['size'] ) );
		self::say( '  Code: ' . $code['release']['tag_name'] . ', ' . self::size( (int) $code['asset']['size'] ) );

		return array(
			'db'       => $db['asset'],
			'manifest' => $manifest,
			'code'     => $code['asset'],
			'uploads'  => $this->uploads_assets( $releases ),
			'db_tag'   => (string) $db['release']['tag_name'],
			'code_tag' => (string) $code['release']['tag_name'],
		);
	}

	/**
	 * Find the newest release of a part that has its file; a database release also needs its manifest.
	 *
	 * @param array<int, array<string, mixed>> $releases Releases.
	 * @param string                           $part     Part key.
	 * @param string                           $suffix   File suffix without .enc.
	 * @return array{release: array<string, mixed>, asset: array<string, mixed>}|null
	 */
	private function newest( array $releases, string $part, string $suffix ): ?array {
		$found   = array();
		$skipped = array();
		$at      = $this->options['at'];

		foreach ( $releases as $release ) {
			$tag = (string) ( $release['tag_name'] ?? '' );

			if ( ! empty( $release['draft'] ) || ! preg_match( '/^' . $part . '-(\d{8}-\d{6})$/', $tag, $match ) ) {
				continue;
			}

			if ( '' !== $at && strcmp( substr( $match[1], 0, strlen( $at ) ), $at ) > 0 ) {
				continue;
			}

			$asset = self::asset( $release, $suffix );

			if ( null === $asset ) {
				continue;
			}

			if ( 'db' === $part && null === self::asset( $release, '.manifest.json' ) ) {
				$skipped[ $match[1] ] = $tag;
				continue;
			}

			$found[ $match[1] ] = array(
				'release' => $release,
				'asset'   => $asset,
			);
		}

		if ( ! $found ) {
			return null;
		}

		krsort( $found, SORT_STRING );

		$chosen = (string) array_key_first( $found );
		$newer  = array_filter( $skipped, static fn( string $stamp ): bool => strcmp( $stamp, $chosen ) > 0, ARRAY_FILTER_USE_KEY );

		if ( $newer ) {
			$this->warn( 'Newer database releases have no manifest and were skipped: ' . implode( ', ', $newer ) . '.' );
		}

		return reset( $found );
	}

	/**
	 * Find a fully uploaded file of a release, with or without encryption.
	 *
	 * @param array<string, mixed> $release Release.
	 * @param string               $suffix  File suffix without .enc.
	 * @return array<string, mixed>|null
	 */
	private static function asset( array $release, string $suffix ): ?array {
		$name = $release['tag_name'] . $suffix;

		foreach ( (array) ( $release['assets'] ?? array() ) as $asset ) {
			if ( 'uploaded' === ( $asset['state'] ?? '' ) && in_array( $asset['name'] ?? '', array( $name, $name . '.enc' ), true ) ) {
				return $asset;
			}
		}

		return null;
	}

	/**
	 * Whether a file is encrypted.
	 *
	 * @param array<string, mixed> $asset File.
	 * @return bool
	 */
	private static function is_sealed( array $asset ): bool {
		return '.enc' === substr( (string) $asset['name'], -4 );
	}

	/**
	 * Read and check the secret key.
	 *
	 * @return void
	 * @throws RuntimeException When the key is not valid or sodium is missing.
	 */
	private function read_secret_key(): void {
		if ( ! function_exists( 'sodium_crypto_box_seal_open' ) ) {
			throw new RuntimeException( 'The backup is encrypted: the PHP extension sodium is required.' );
		}

		$key = base64_decode( trim( self::secret( self::ENV_KEY, 'Secret key' ) ), true );

		if ( false === $key || SODIUM_CRYPTO_BOX_SECRETKEYBYTES !== strlen( $key ) ) {
			throw new RuntimeException( 'The secret key is not valid.' );
		}

		$this->secret = $key;
	}

	/**
	 * Files of the uploads release; of two archives of one folder the newer one.
	 *
	 * @param array<int, array<string, mixed>> $releases Releases.
	 * @return array<int, array<string, mixed>>
	 */
	private function uploads_assets( array $releases ): array {
		foreach ( $releases as $release ) {
			if ( 'uploads' !== ( $release['tag_name'] ?? '' ) ) {
				continue;
			}

			$groups = array();

			for ( $page = 1; ; $page++ ) {
				$list = $this->api( '/releases/' . (int) $release['id'] . '/assets?per_page=100&page=' . $page );

				foreach ( $list as $asset ) {
					if ( 'uploaded' !== ( $asset['state'] ?? '' ) || ! preg_match( '/^uploads-(.+)-[0-9a-f]{12}\.zip$/', (string) $asset['name'], $match ) ) {
						continue;
					}

					if ( ! isset( $groups[ $match[1] ] ) || strcmp( (string) $asset['updated_at'], (string) $groups[ $match[1] ]['updated_at'] ) > 0 ) {
						$groups[ $match[1] ] = $asset;
					}
				}

				if ( count( $list ) < 100 ) {
					break;
				}
			}

			self::say( '  Uploads: ' . count( $groups ) . ' archives, ' . self::size( (int) array_sum( array_column( $groups, 'size' ) ) ) );

			return array_values( $groups );
		}

		$this->warn( 'The repository has no uploads release: the media files are not restored.' );

		return array();
	}

	/**
	 * Download the backup and WP-CLI. A second run continues where the first stopped.
	 *
	 * @param array<string, mixed> $backup Result of choose_backup().
	 * @return void
	 * @throws RuntimeException On a failed download or too little disk space.
	 */
	private function download_all( array $backup ): void {
		$files = array_merge( array( $backup['db'], $backup['code'] ), $backup['uploads'] );
		$total = (int) array_sum( array_column( $files, 'size' ) );
		$free  = disk_free_space( $this->work );
		$have  = 0;

		foreach ( $files as $asset ) {
			$target = $this->work . '/' . basename( (string) $asset['name'] );
			$have  += is_file( $target ) ? min( (int) filesize( $target ), (int) $asset['size'] ) : 0;
		}

		if ( false !== $free && $free + $have < $total ) {
			throw new RuntimeException( 'Not enough disk space: the backup takes ' . self::size( $total ) . ', ' . self::size( $have ) . ' of it is downloaded, free ' . self::size( (int) $free ) . '.' );
		}

		if ( false !== $free && $free + $have < 3 * $total ) {
			$this->warn( 'Free disk space is ' . self::size( (int) $free ) . ' for a backup of ' . self::size( $total ) . '. Unpacked files and the database take more than the archives.' );
		}

		self::say( 'Downloading ' . count( $files ) . ' files, ' . self::size( $total ) );

		$started = time();

		foreach ( $files as $asset ) {
			$this->download( $asset );
		}

		self::say( '  Done in ' . ( time() - $started ) . ' s' );

		$this->get_wp_cli();
	}

	/**
	 * Download one file with retries and resume, then compare its SHA-256.
	 *
	 * @param array<string, mixed> $asset File.
	 * @return void
	 * @throws RuntimeException When it cannot be downloaded.
	 */
	private function download( array $asset ): void {
		$name   = basename( (string) $asset['name'] );
		$target = $this->work . '/' . $name;
		$size   = (int) $asset['size'];
		$digest = (string) ( $asset['digest'] ?? '' );
		$digest = 0 === strpos( $digest, 'sha256:' ) ? substr( $digest, 7 ) : '';
		$reason = 'the file size does not match';

		if ( '' === $digest ) {
			$this->warn( "GitHub gave no checksum for {$name}: only its size was compared." );
		}

		for ( $attempt = 0; $attempt <= 5; $attempt++ ) {
			clearstatcache( true, $target );

			$have = is_file( $target ) ? (int) filesize( $target ) : 0;

			if ( $have === $size ) {
				if ( '' === $digest || hash_equals( $digest, (string) hash_file( 'sha256', $target ) ) ) {
					return;
				}

				$reason = 'the checksum does not match';
				unlink( $target );
				$have = 0;
			} elseif ( $have > $size ) {
				unlink( $target );
				$have = 0;
			}

			if ( 5 === $attempt ) {
				break;
			}

			$error = self::fetch( (string) $asset['url'], $target, $have, $this->token );

			if ( '' !== $error ) {
				$reason = $error;
				sleep( 3 * ( $attempt + 1 ) );
			}
		}

		throw new RuntimeException( "The file {$name} cannot be downloaded: {$reason}" );
	}

	/**
	 * Fetch a URL into a file, continuing from an offset.
	 *
	 * @param string $url    URL.
	 * @param string $target File.
	 * @param int    $offset Bytes already in the file.
	 * @param string $token  GitHub token, empty for none.
	 * @return string Empty on success, otherwise the reason.
	 */
	private static function fetch( string $url, string $target, int $offset, string $token ): string {
		$file = fopen( $target, $offset > 0 ? 'ab' : 'wb' );

		if ( false === $file ) {
			return 'the file cannot be written';
		}

		chmod( $target, 0600 );

		$headers = array( 'User-Agent: mvweb-backup-restore', 'Accept: application/octet-stream' );

		if ( '' !== $token ) {
			$headers[] = 'Authorization: Bearer ' . $token;
		}

		$curl = curl_init( $url );

		curl_setopt_array(
			$curl,
			array(
				CURLOPT_FILE            => $file,
				CURLOPT_HTTPHEADER      => $headers,
				CURLOPT_FOLLOWLOCATION  => true,
				CURLOPT_REDIR_PROTOCOLS => CURLPROTO_HTTPS,
				CURLOPT_FAILONERROR     => true,
				CURLOPT_RESUME_FROM     => $offset,
				CURLOPT_CONNECTTIMEOUT  => 30,
				CURLOPT_LOW_SPEED_LIMIT => 1024,
				CURLOPT_LOW_SPEED_TIME  => 120,
			)
		);

		$done  = curl_exec( $curl );
		$error = false === $done ? curl_error( $curl ) : '';

		fclose( $file );

		return $error;
	}

	/**
	 * Call the GitHub API. Temporary server errors are repeated.
	 *
	 * @param string $path Path after the repository.
	 * @return array<int|string, mixed>
	 * @throws RuntimeException On an error answer.
	 */
	private function api( string $path ): array {
		$body = false;
		$code = 0;

		for ( $attempt = 0; $attempt < 4; $attempt++ ) {
			if ( $attempt > 0 ) {
				sleep( 3 * $attempt );
			}

			$curl = curl_init( 'https://api.github.com/repos/' . $this->options['repo'] . $path );

			curl_setopt_array(
				$curl,
				array(
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_CONNECTTIMEOUT => 30,
					CURLOPT_TIMEOUT        => 120,
					CURLOPT_HTTPHEADER     => array(
						'User-Agent: mvweb-backup-restore',
						'Accept: application/vnd.github+json',
						'X-GitHub-Api-Version: 2022-11-28',
						'Authorization: Bearer ' . $this->token,
					),
				)
			);

			$body = curl_exec( $curl );
			$code = (int) curl_getinfo( $curl, CURLINFO_HTTP_CODE );

			if ( false !== $body && $code < 500 ) {
				break;
			}
		}

		if ( 401 === $code ) {
			throw new RuntimeException( 'GitHub rejected the token. It is wrong or has expired.' );
		}

		if ( 403 === $code || 404 === $code ) {
			throw new RuntimeException( 'The repository was not found, or the token has no access to it.' );
		}

		$data = 200 === $code ? json_decode( (string) $body, true ) : null;

		if ( ! is_array( $data ) ) {
			throw new RuntimeException( "GitHub did not answer as expected: HTTP {$code}." );
		}

		return $data;
	}

	/**
	 * Download WP-CLI and check that it starts.
	 *
	 * @return void
	 * @throws RuntimeException When it cannot be downloaded or does not run.
	 */
	private function get_wp_cli(): void {
		$this->phar = $this->work . '/wp-cli.phar';

		$sums = $this->work . '/wp-cli.phar.sha512';

		file_put_contents( $this->work . '/wp-cli.yml', "apache_modules:\n  - mod_rewrite\n" );

		$error = self::fetch( self::WP_CLI, $this->phar, 0, '' );
		$error = '' !== $error ? $error : self::fetch( self::WP_CLI . '.sha512', $sums, 0, '' );

		if ( '' !== $error ) {
			throw new RuntimeException( 'WP-CLI cannot be downloaded: ' . $error );
		}

		if ( ! hash_equals( trim( (string) file_get_contents( $sums ) ), (string) hash_file( 'sha512', $this->phar ) ) ) {
			throw new RuntimeException( 'The WP-CLI download does not match its checksum.' );
		}

		$version = $this->wp( array( '--version' ) );

		if ( 0 !== $version['code'] ) {
			throw new RuntimeException( 'WP-CLI does not start: ' . self::tail( $version ) );
		}

		self::say( '  ' . trim( $version['out'] ) );
	}

	/**
	 * Read the manifest and check that the backup can be restored here.
	 *
	 * Runs before the large downloads, so a wrong key or an old backup stops at once.
	 *
	 * @param array<string, mixed> $asset Manifest file.
	 * @return void
	 * @throws RuntimeException When the backup cannot be used.
	 */
	private function read_manifest( array $asset ): void {
		$this->fetched = true;

		$this->download( $asset );

		$manifest = json_decode( (string) file_get_contents( $this->opened( $asset ) ), true );

		if ( ! is_array( $manifest ) ) {
			throw new RuntimeException( 'The manifest cannot be read.' );
		}

		if ( '' === (string) ( $manifest['charset'] ?? '' ) ) {
			$manifest['charset'] = 'utf8mb4';
		}

		$this->manifest = $manifest;

		if ( self::FORMAT !== (int) ( $manifest['format'] ?? 0 ) ) {
			throw new RuntimeException( 'The backup format is ' . (int) ( $manifest['format'] ?? 0 ) . ', this script reads ' . self::FORMAT . '. Use restore.php from the same repository.' );
		}

		if ( ! empty( $manifest['multisite'] ) ) {
			throw new RuntimeException( 'The backup is of a multisite network. This script restores single sites only.' );
		}

		if ( ! preg_match( '/^[A-Za-z0-9_]+$/', (string) ( $manifest['table_prefix'] ?? '' ) ) || ! preg_match( '/^\d+\.\d+/', (string) ( $manifest['wordpress'] ?? '' ) ) || '' === (string) ( $manifest['home'] ?? '' ) ) {
			throw new RuntimeException( 'The manifest is not complete.' );
		}

		self::say( 'Site: ' . $manifest['home'] . ', WordPress ' . $manifest['wordpress'] . ', backup made ' . $manifest['created'] );
		self::say( '  The site ran on PHP ' . $manifest['php'] . ', database ' . ( $manifest['database'] ?? 'unknown' ) );

		if ( version_compare( PHP_VERSION, implode( '.', array_slice( explode( '.', (string) $manifest['php'] ), 0, 2 ) ), '<' ) ) {
			$this->warn( 'This server has PHP ' . PHP_VERSION . ', the site ran on PHP ' . $manifest['php'] . '. Plugins can stop working: choose the same or a newer PHP.' );
		}

		$this->check_new_domain();
	}

	/**
	 * Check the new domain against the address in the manifest.
	 *
	 * @return void
	 * @throws RuntimeException When the replacement would give wrong addresses.
	 */
	private function check_new_domain(): void {
		$new = $this->options['new-domain'];

		if ( '' === $new ) {
			return;
		}

		$home = (string) $this->manifest['home'];
		$host = strtolower( (string) parse_url( $home, PHP_URL_HOST ) );
		$bare = (string) preg_replace( '/^www\./', '', $host );
		$www  = 'www.' . $bare;

		if ( '' === $bare ) {
			throw new RuntimeException( 'The manifest has no domain: ' . $home );
		}

		if ( null !== parse_url( $home, PHP_URL_PORT ) ) {
			throw new RuntimeException( "The address of the backup has a port: {$home}. --new-domain cannot replace it. Restore without the flag and replace the address by hand." );
		}

		if ( $new === $host ) {
			throw new RuntimeException( "The backup already has the address {$new}. Leave out --new-domain." );
		}

		if ( $new !== $www && 0 === strpos( $new, $www ) ) {
			throw new RuntimeException( "The new domain {$new} starts with {$www}: the second pass of the replacement would double it. Restore to another domain first." );
		}

		$this->old_domain = $bare;

		self::say( '  The domain changes from ' . $host . ' to ' . $new );
	}

	/**
	 * Decrypt the database and code files and check the archive layout.
	 *
	 * @param array<string, mixed> $backup Result of choose_backup().
	 * @return array{db: string, code: string}
	 * @throws RuntimeException When a file cannot be used.
	 */
	private function open_files( array $backup ): array {
		if ( '' !== $this->secret ) {
			self::say( 'Decrypting' );
		}

		$files = array(
			'db'   => $this->opened( $backup['db'] ),
			'code' => $this->opened( $backup['code'] ),
		);

		$this->check_code_archive( $files['code'] );

		return $files;
	}

	/**
	 * Check that the code archive has the current layout.
	 *
	 * @param string $file Archive.
	 * @return void
	 * @throws RuntimeException When it does not.
	 */
	private function check_code_archive( string $file ): void {
		$zip = new ZipArchive();

		if ( true !== $zip->open( $file, ZipArchive::RDONLY ) ) {
			throw new RuntimeException( 'The code archive cannot be opened.' );
		}

		$inner = json_decode( (string) $zip->getFromName( self::MANIFEST ), true );

		$zip->close();

		if ( ! is_array( $inner ) || self::FORMAT !== (int) ( $inner['format'] ?? 0 ) ) {
			throw new RuntimeException( 'The code archive was made by plugin version 1.0.0 or holds no manifest. Make a new code backup, or restore by hand with the steps in the README of the repository.' );
		}

		if ( ( $inner['home'] ?? '' ) !== $this->manifest['home'] ) {
			$this->warn( 'The code archive is of ' . ( $inner['home'] ?? '?' ) . ', the database of ' . $this->manifest['home'] . '.' );
		}
	}

	/**
	 * Path of a downloaded file in readable form, decrypted if needed.
	 *
	 * @param array<string, mixed> $asset File.
	 * @return string
	 * @throws RuntimeException When it cannot be decrypted.
	 */
	private function opened( array $asset ): string {
		$name = basename( (string) $asset['name'] );
		$file = $this->work . '/' . $name;

		if ( ! self::is_sealed( $asset ) ) {
			return $file;
		}

		$target = $this->work . '/plain/' . substr( $name, 0, -4 );

		$this->decrypt( $file, $target );

		return $target;
	}

	/**
	 * Decrypt a file.
	 *
	 * @param string $source Encrypted file.
	 * @param string $target Target file.
	 * @return void
	 * @throws RuntimeException When the key is wrong or the file is damaged.
	 */
	private function decrypt( string $source, string $target ): void {
		$in  = fopen( $source, 'rb' );
		$out = fopen( $target, 'wb' );

		if ( false === $in || false === $out ) {
			throw new RuntimeException( 'The file cannot be decrypted: ' . basename( $source ) );
		}

		chmod( $target, 0600 );

		try {
			$pair = sodium_crypto_box_keypair_from_secretkey_and_publickey( $this->secret, sodium_crypto_box_publickey_from_secretkey( $this->secret ) );

			if ( 'MVBK1' !== fread( $in, 5 ) ) {
				throw new RuntimeException( 'This is not an MVweb Backup file: ' . basename( $source ) );
			}

			$key = sodium_crypto_box_seal_open( (string) fread( $in, 80 ), $pair );

			if ( false === $key ) {
				throw new RuntimeException( 'The secret key does not fit this backup.' );
			}

			$state = sodium_crypto_secretstream_xchacha20poly1305_init_pull( (string) fread( $in, 24 ), $key );
			$tag   = 0;

			while ( ! feof( $in ) ) {
				$chunk = fread( $in, 1048593 );

				if ( false === $chunk || '' === $chunk ) {
					break;
				}

				$plain = sodium_crypto_secretstream_xchacha20poly1305_pull( $state, $chunk );

				if ( false === $plain ) {
					throw new RuntimeException( 'The file is damaged: ' . basename( $source ) );
				}

				if ( strlen( $plain[0] ) !== fwrite( $out, $plain[0] ) ) {
					throw new RuntimeException( 'The decrypted file cannot be written. The disk may be full.' );
				}

				$tag = $plain[1];
			}

			if ( SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL !== $tag ) {
				throw new RuntimeException( 'The file is cut short: ' . basename( $source ) );
			}
		} catch ( SodiumException $e ) {
			throw new RuntimeException( 'The file is damaged: ' . basename( $source ) );
		} finally {
			fclose( $in );
			fclose( $out );
		}
	}

	/**
	 * Install the WordPress version and language of the site, without default themes.
	 *
	 * @return void
	 * @throws RuntimeException When the download fails.
	 */
	private function install_core(): void {
		self::say( 'Installing WordPress ' . $this->manifest['wordpress'] );

		$this->touched = true;

		$result = $this->wp( array( 'core', 'download', '--version=' . $this->manifest['wordpress'], '--locale=' . $this->manifest['locale'], '--skip-content' ) );

		if ( 0 !== $result['code'] ) {
			throw new RuntimeException( 'WordPress cannot be downloaded: ' . self::tail( $result ) );
		}
	}

	/**
	 * Import the dump, fixing what the new server would refuse.
	 *
	 * Data lines are passed as they are, so text in posts stays unchanged.
	 *
	 * @param string $file Dump, gzip.
	 * @return void
	 * @throws RuntimeException When the import fails.
	 */
	private function import_database( string $file ): void {
		self::say( 'Importing the database' );

		$started = time();
		$known   = array();
		$found   = $this->database()->query( "SHOW COLLATION WHERE Charset = 'utf8mb4'" );

		foreach ( $found as $row ) {
			$known[ $row['Collation'] ] = true;
		}

		$errors  = $this->work . '/import.err';
		$pipes   = array();
		$process = proc_open(
			array( $this->client, '--defaults-extra-file=' . $this->db_file, '--binary-mode', '--default-character-set=' . $this->manifest['charset'], $this->options['db-name'] ),
			array(
				0 => array( 'pipe', 'r' ),
				1 => array( 'file', '/dev/null', 'w' ),
				2 => array( 'file', $errors, 'w' ),
			),
			$pipes,
			$this->work,
			$this->child_env()
		);

		if ( ! is_resource( $process ) ) {
			throw new RuntimeException( 'The database client did not start.' );
		}

		$dump = gzopen( $file, 'rb' );

		if ( false === $dump ) {
			fclose( $pipes[0] );
			proc_close( $process );
			throw new RuntimeException( 'The dump cannot be opened.' );
		}

		$replaced = 0;
		$last     = '';
		$broken   = false;

		while ( ! $broken ) {
			$line = gzgets( $dump );

			if ( false === $line ) {
				break;
			}

			if ( '' !== trim( $line ) ) {
				$last = $line;
			}

			if ( '(' !== $line[0] && 0 !== strpos( $line, 'INSERT ' ) ) {
				$line = self::fix_schema_line( $line, $known, $replaced );
			}

			$broken = ! self::write_all( $pipes[0], $line );
		}

		gzclose( $dump );
		fclose( $pipes[0] );

		$code = proc_close( $process );

		@unlink( $this->db_file );

		if ( 0 !== $code || $broken ) {
			throw new RuntimeException( 'The import failed: ' . substr( trim( (string) file_get_contents( $errors ) ), 0, 500 ) );
		}

		if ( false === strpos( $last, 'Dump completed' ) ) {
			throw new RuntimeException( 'The dump is incomplete: it has no closing line.' );
		}

		if ( $replaced > 0 ) {
			$this->warn( "Collations unknown to this database were replaced with utf8mb4_unicode_520_ci in {$replaced} lines." );
		}

		self::say( '  Done in ' . ( time() - $started ) . ' s' );
	}

	/**
	 * Write all bytes to a pipe.
	 *
	 * @param resource $pipe Pipe.
	 * @param string   $data Data.
	 * @return bool Whether everything was written.
	 */
	private static function write_all( $pipe, string $data ): bool {
		$length = strlen( $data );
		$sent   = 0;

		while ( $sent < $length ) {
			$written = @fwrite( $pipe, 0 === $sent ? $data : substr( $data, $sent ) );

			if ( false === $written || 0 === $written ) {
				return false;
			}

			$sent += $written;
		}

		return true;
	}

	/**
	 * Fix one line of table structure for the new server.
	 *
	 * @param string              $line     Line of the dump.
	 * @param array<string, bool> $known    Collations of this server.
	 * @param int                 $replaced Lines with a replaced collation (in, out).
	 * @return string
	 */
	private static function fix_schema_line( string $line, array $known, int &$replaced ): string {
		if ( 0 === strpos( $line, '/*M!999999' ) ) {
			return '';
		}

		$changed = false;
		$line    = (string) preg_replace_callback(
			'/\butf8mb4_[a-z0-9_]+\b/',
			static function ( array $found ) use ( $known, &$changed ): string {
				if ( isset( $known[ $found[0] ] ) ) {
					return $found[0];
				}

				$changed = true;

				return 'utf8mb4_unicode_520_ci';
			},
			$line
		);

		if ( $changed ) {
			++$replaced;
		}

		return (string) preg_replace( '/\s*DEFINER\s*=\s*`[^`]*`@`[^`]*`/', ' ', $line );
	}

	/**
	 * Create wp-config.php with the table prefix of the site and new salts.
	 *
	 * The password is written by this script: it stays out of the argument list,
	 * and WP-CLI escapes a double quote in a password wrongly.
	 *
	 * @return void
	 * @throws RuntimeException On failure.
	 */
	private function create_config(): void {
		self::say( 'Creating wp-config.php' );

		$result = $this->wp(
			array(
				'config',
				'create',
				'--dbname=' . $this->options['db-name'],
				'--dbuser=' . $this->options['db-user'],
				'--dbhost=' . $this->options['db-host'],
				'--dbprefix=' . $this->manifest['table_prefix'],
				'--dbcharset=' . $this->manifest['charset'],
				'--dbpass=' . self::PASSWORD_MARK,
				'--skip-check',
			)
		);

		if ( 0 !== $result['code'] ) {
			throw new RuntimeException( 'wp-config.php cannot be created: ' . self::tail( $result ) );
		}

		$file = $this->root . '/wp-config.php';
		$text = (string) file_get_contents( $file );
		$mark = "'" . self::PASSWORD_MARK . "'";

		if ( 1 !== substr_count( $text, $mark ) || ! chmod( $file, 0640 ) || ! file_put_contents( $file, str_replace( $mark, var_export( $this->password, true ), $text ) ) ) {
			throw new RuntimeException( 'The database password cannot be written to wp-config.php.' );
		}
	}

	/**
	 * Unpack the code and uploads archives and put the saved constants aside.
	 *
	 * @param string                           $code    Code archive.
	 * @param array<int, array<string, mixed>> $uploads Uploads archives.
	 * @return string[] Files the archive put into the site root.
	 * @throws RuntimeException On failure.
	 */
	private function put_files( string $code, array $uploads ): array {
		self::say( 'Unpacking the files' );

		$started = time();
		$names   = $this->unpack( $code, $this->root, array( 'wp-config.php', self::MANIFEST, self::SAVED_CONFIG ) );

		$this->uploads = $this->uploads_dir();

		if ( $uploads && ! is_dir( $this->uploads ) && ! mkdir( $this->uploads, 0755, true ) ) {
			throw new RuntimeException( 'The uploads folder cannot be created: ' . $this->uploads );
		}

		foreach ( $uploads as $asset ) {
			$this->unpack( $this->work . '/' . basename( (string) $asset['name'] ), $this->uploads, array() );
		}

		$this->save_constants( $code );

		self::say( '  ' . count( $names ) . ' code files and ' . count( $uploads ) . ' uploads archives in ' . ( time() - $started ) . ' s' );

		return array_values( array_filter( $names, static fn( string $name ): bool => false === strpos( $name, '/' ) ) );
	}

	/**
	 * Extract an archive, refusing paths that lead out of the target.
	 *
	 * @param string   $file   Archive.
	 * @param string   $target Folder.
	 * @param string[] $skip   Entries to leave out.
	 * @return string[] Extracted entries.
	 * @throws RuntimeException On a bad archive.
	 */
	private function unpack( string $file, string $target, array $skip ): array {
		$zip = new ZipArchive();

		if ( true !== $zip->open( $file, ZipArchive::RDONLY ) ) {
			throw new RuntimeException( 'The archive cannot be opened: ' . basename( $file ) );
		}

		$names = array();

		for ( $index = 0; $index < $zip->numFiles; $index++ ) {
			$name = (string) $zip->getNameIndex( $index );

			if ( '' === $name || '/' === $name[0] || '\\' === $name[0] || preg_match( '#(^|[/\\\\])\.\.([/\\\\]|$)#', $name ) ) {
				throw new RuntimeException( 'The archive ' . basename( $file ) . ' has an unsafe path: ' . $name );
			}

			if ( ! in_array( $name, $skip, true ) ) {
				$names[] = $name;
			}
		}

		if ( $names && ! $zip->extractTo( $target, $names ) ) {
			throw new RuntimeException( 'The archive cannot be extracted: ' . basename( $file ) . '. The disk may be full. ' . $zip->getStatusString() );
		}

		$zip->close();

		return $names;
	}

	/**
	 * Uploads folder of the site in its new place.
	 *
	 * @return string
	 */
	private function uploads_dir(): string {
		$old  = (string) ( $this->manifest['uploads'] ?? '' );
		$base = rtrim( (string) ( $this->manifest['abspath'] ?? '' ), '/' ) . '/';

		if ( 0 === strpos( $old, $base ) && ! preg_match( '#(^|/)\.\.(/|$)#', $old ) ) {
			return $this->root . '/' . trim( substr( $old, strlen( $base ) ), '/' );
		}

		$this->warn( 'The uploads folder of the old site was outside the site root: ' . $old . '. The files went to wp-content/uploads.' );

		return $this->root . '/wp-content/uploads';
	}

	/**
	 * Put the copy of wp-config.php outside the site root.
	 *
	 * @param string $code Code archive.
	 * @return void
	 */
	private function save_constants( string $code ): void {
		$zip = new ZipArchive();

		if ( true !== $zip->open( $code, ZipArchive::RDONLY ) ) {
			return;
		}

		$text = $zip->getFromName( self::SAVED_CONFIG );

		$zip->close();

		if ( false === $text ) {
			return;
		}

		$target = dirname( $this->work ) . '/' . self::SAVED_CONFIG;

		if ( touch( $target ) && chmod( $target, 0600 ) && file_put_contents( $target, $text ) ) {
			$this->warn( 'The old constants are in ' . $target . '. Copy the ones you need into wp-config.php and delete the file. If the site was hacked, replace all keys and tokens.' );
		} else {
			$this->warn( 'The copy of the old wp-config.php could not be written to ' . $target . '.' );
		}
	}

	/**
	 * Keep the site from acting on its own until it is checked.
	 *
	 * Lives in one file, so going live changes nothing in wp-config.php and keeps
	 * the same constants if the site defines them itself.
	 *
	 * @return void
	 * @throws RuntimeException When it cannot be written.
	 */
	private function write_hold(): void {
		$file = $this->root . '/' . self::HOLD_FILE;
		$text = <<<'MVWEB_BK_HOLD'
<?php
/**
 * Plugin Name: MVweb restore hold
 * Description: Keeps a restored site quiet until it is checked: no requests through WordPress, mail, cron or background queues. Plugins that call curl directly are not stopped. Delete this file to go live.
 */

defined( 'ABSPATH' ) || exit;
defined( 'WP_HTTP_BLOCK_EXTERNAL' ) || define( 'WP_HTTP_BLOCK_EXTERNAL', true );
defined( 'DISABLE_WP_CRON' ) || define( 'DISABLE_WP_CRON', true );

if ( wp_doing_cron() ) {
	exit;
}

add_filter( 'pre_wp_mail', '__return_false' );
add_filter( 'block_local_requests', '__return_true' );
add_filter( 'action_scheduler_allow_async_request_runner', '__return_false' );

MVWEB_BK_HOLD;

		if ( ! is_dir( dirname( $file ) ) ) {
			mkdir( dirname( $file ), 0755, true );
		}

		if ( ! file_put_contents( $file, $text ) ) {
			throw new RuntimeException( 'The hold file cannot be written: ' . $file );
		}
	}

	/**
	 * Check that WordPress reads the restored database.
	 *
	 * @return void
	 * @throws RuntimeException When it does not.
	 */
	private function check_wordpress(): void {
		$bare = $this->wp( array( 'option', 'get', 'home', '--skip-plugins', '--skip-themes' ) );

		if ( 0 !== $bare['code'] ) {
			throw new RuntimeException( 'WordPress does not read the restored database: ' . self::tail( $bare ) );
		}

		if ( trim( $bare['out'] ) !== $this->manifest['home'] ) {
			$this->warn( 'The home option is ' . trim( $bare['out'] ) . ', the old site worked as ' . $this->manifest['home'] . '. The old wp-config.php or a plugin may have set the address: check it.' );
		}

		$full = $this->wp( array( 'option', 'get', 'home' ) );

		if ( 0 !== $full['code'] ) {
			$this->warn( 'WordPress loads, but fails with its plugins and theme: ' . self::tail( $full ) );
		}
	}

	/**
	 * Replace the old server path in the database and in the files of the site root.
	 *
	 * @param string[] $root_files Files the archive put into the site root.
	 * @return void
	 */
	private function replace_path( array $root_files ): void {
		$old = rtrim( (string) ( $this->manifest['abspath'] ?? '' ), '/' );

		if ( '' === $old || $old === $this->root ) {
			return;
		}

		self::say( 'Replacing the server path ' . $old . ' with ' . $this->root );

		$this->search_replace(
			array(
				array( $old, $this->root ),
				array( str_replace( '/', '\\/', $old ), str_replace( '/', '\\/', $this->root ) ),
			)
		);

		foreach ( $root_files as $name ) {
			$file = $this->root . '/' . $name;
			$text = is_file( $file ) && filesize( $file ) < 2097152 ? file_get_contents( $file ) : false;

			if ( false === $text || false === strpos( $text, $old ) ) {
				continue;
			}

			if ( ! in_array( $name, array( '.htaccess', '.user.ini', 'php.ini', 'wordfence-waf.php' ), true ) ) {
				$this->warn( "The file {$name} mentions the old server path. Check it by hand." );
			} elseif ( ! file_put_contents( $file, str_replace( $old, $this->root, $text ) ) ) {
				$this->warn( "The old server path was not replaced in {$name}. Replace it by hand." );
			}
		}
	}

	/**
	 * Replace the old domain in the database and in .htaccess and robots.txt.
	 *
	 * Only the //domain forms change, so email addresses stay. The order matters:
	 * the bare domain goes first, then www, then the scheme.
	 *
	 * @return void
	 */
	private function replace_domain(): void {
		if ( '' === $this->old_domain ) {
			return;
		}

		$old = $this->old_domain;
		$new = $this->options['new-domain'];

		self::say( 'Replacing the domain ' . $old . ' with ' . $new );

		$forms = array(
			array( '//' . $old, '//' . $new ),
			array( '//www.' . $old, '//' . $new ),
			array( '\\/\\/' . $old, '\\/\\/' . $new ),
			array( '\\/\\/www.' . $old, '\\/\\/' . $new ),
		);

		if ( 'https' === parse_url( (string) $this->manifest['home'], PHP_URL_SCHEME ) ) {
			$forms[] = array( 'http://' . $new, 'https://' . $new );
			$forms[] = array( 'http:\\/\\/' . $new, 'https:\\/\\/' . $new );
		}

		$this->search_replace( $forms );

		$host      = (string) parse_url( (string) $this->manifest['home'], PHP_URL_HOST );
		$same_form = ( 0 === stripos( $host, 'www.' ) ) === ( 0 === strpos( $new, 'www.' ) );

		if ( $same_form && ! $this->new_holds_old() ) {
			$this->replace_domain_in_files( $old, $new );
		} else {
			$this->report_files_left( $old );
		}

		$home = $this->wp( array( 'option', 'get', 'home', '--skip-plugins', '--skip-themes' ) );
		$site = $this->wp( array( 'option', 'get', 'siteurl', '--skip-plugins', '--skip-themes' ) );

		if ( 0 !== $home['code'] || 0 !== $site['code'] || parse_url( trim( $home['out'] ), PHP_URL_HOST ) !== $new ) {
			$this->failures[] = 'The address of the site was not replaced: ' . ( 0 === $home['code'] ? trim( $home['out'] ) : self::tail( $home ) ) . '. Replace the home and siteurl options by hand.';

			return;
		}

		$this->manifest['home']    = trim( $home['out'] );
		$this->manifest['siteurl'] = trim( $site['out'] );
	}

	/**
	 * Whether the new domain has the old one inside it: www.old.ru, shop.old.ru, my-old.ru.
	 *
	 * A search for the old domain then also finds the new addresses.
	 *
	 * @return bool
	 */
	private function new_holds_old(): bool {
		return false !== strpos( $this->options['new-domain'], $this->old_domain );
	}

	/**
	 * Name the server files left unchanged: their rules can redirect in a loop when the www form changes.
	 *
	 * @param string $old Old domain.
	 * @return void
	 */
	private function report_files_left( string $old ): void {
		foreach ( array( '.htaccess', 'robots.txt' ) as $name ) {
			$file = $this->root . '/' . $name;

			if ( is_file( $file ) && false !== strpos( (string) file_get_contents( $file ), $old ) ) {
				$this->warn( "The domain was not replaced in {$name}: the www form changes or the new domain holds the old one. Replace it by hand." );
			}
		}
	}

	/**
	 * Replace the domain in the server files of the site root, in plain and regular expression form.
	 *
	 * @param string $from Old domain.
	 * @param string $to   New domain.
	 * @return void
	 */
	private function replace_domain_in_files( string $from, string $to ): void {
		$escaped = static fn( string $domain ): string => str_replace( '.', '\\.', $domain );
		$pattern = static fn( string $domain ): string => '/(?<![\w-])' . preg_quote( $domain, '/' ) . '(?![\w-])/';

		foreach ( array( '.htaccess', 'robots.txt' ) as $name ) {
			$file = $this->root . '/' . $name;
			$text = is_file( $file ) ? file_get_contents( $file ) : false;

			if ( false === $text ) {
				continue;
			}

			$count  = 0;
			$result = preg_replace_callback_array(
				array(
					$pattern( $escaped( $from ) ) => static fn(): string => $escaped( $to ),
					$pattern( $from )             => static fn(): string => $to,
				),
				$text,
				-1,
				$count
			);

			if ( 0 === $count ) {
				continue;
			}

			if ( null === $result || ! file_put_contents( $file, $result ) ) {
				$this->warn( "The domain was not replaced in {$name}. Replace it by hand." );
			} else {
				self::say( "  {$name}: {$count} replacements" );
				$this->warn( "The domain was replaced in {$name}. Check the rules in this file." );
			}
		}
	}

	/**
	 * Replace strings in all tables of the site, except guid.
	 *
	 * @param array<int, array{0: string, 1: string}> $forms Pairs of old and new strings, in order.
	 * @return void
	 */
	private function search_replace( array $forms ): void {
		foreach ( $forms as $form ) {
			if ( $form[0] === $form[1] ) {
				continue;
			}

			$result = $this->wp( array( 'search-replace', $form[0], $form[1], '--all-tables-with-prefix', '--skip-columns=guid', '--format=count' ) );

			if ( 0 !== $result['code'] ) {
				$this->warn( $form[0] . ' was not replaced in the database: ' . self::tail( $result ) );
			} else {
				self::say( '  ' . $form[0] . ': ' . trim( $result['out'] ) . ' replacements' );
			}
		}
	}

	/**
	 * Rebuild what the backup leaves out.
	 *
	 * A failure here does not stop the restore: it is reported at the end.
	 *
	 * @return void
	 */
	private function finish_site(): void {
		self::say( 'Finishing the site' );

		$this->step( array( 'rewrite', 'flush', '--hard' ), 'Permalink rules were not rebuilt' );

		if ( ! is_file( $this->root . '/.htaccess' ) || false === strpos( (string) file_get_contents( $this->root . '/.htaccess' ), 'BEGIN WordPress' ) ) {
			$this->warn( '.htaccess has no WordPress rules. This is normal on nginx. On Apache permalinks return 404 until you add them.' );
		}

		$this->step( array( 'transient', 'delete', '--all' ), 'Transients were not deleted' );
		$this->step( array( 'cache', 'flush' ), 'The cache was not flushed' );

		if ( ! empty( $this->manifest['plugins']['elementor/elementor.php']['active'] ) ) {
			$this->step( array( 'elementor', 'flush-css' ), 'Elementor CSS was not rebuilt' );
		}

		self::say( '  Creating thumbnails' );

		$started = time();
		$result  = $this->wp( array( 'media', 'regenerate', '--only-missing', '--skip-delete', '--yes' ), '', true );

		if ( 0 !== $result['code'] ) {
			$this->warn( 'Some thumbnails were not created. Run wp media regenerate --only-missing --skip-delete --yes and check the output.' );
		}

		self::say( '  Done in ' . ( time() - $started ) . ' s' );
	}

	/**
	 * Run a WP-CLI command and report a failure.
	 *
	 * @param string[] $command Command.
	 * @param string   $message Message on failure.
	 * @return void
	 */
	private function step( array $command, string $message ): void {
		$result = $this->wp( $command );

		if ( 0 !== $result['code'] ) {
			$this->warn( $message . ': ' . self::tail( $result ) );
		}
	}

	/**
	 * Check the restored site.
	 *
	 * @param string[] $root_files Files the archive put into the site root.
	 * @return void
	 */
	private function verify( array $root_files ): void {
		self::say( 'Checking the site' );

		$this->verify_plugins();
		$this->verify_checksums();
		$this->verify_root_files( $root_files );
		$this->verify_uploads();
		$this->verify_old_domain( $root_files );
		$this->verify_http();
	}

	/**
	 * Show where the old domain stays in the database and in the site files.
	 *
	 * @param string[] $root_files Files the archive put into the site root.
	 * @return void
	 */
	private function verify_old_domain( array $root_files ): void {
		if ( '' === $this->old_domain ) {
			return;
		}

		if ( $this->new_holds_old() ) {
			$this->warn( 'The new domain holds the old one, so what is left of the old domain was not searched.' );

			return;
		}

		$result = $this->wp( array( 'search-replace', $this->old_domain, 'mvweb-restore-none', '--dry-run', '--all-tables-with-prefix', '--skip-columns=guid', '--report-changed-only' ) );
		$found  = array();

		preg_match_all( '/^\|?\s*(\S+)[\s|]+(\S+)[\s|]+(\d+)[\s|]+\S+/m', $result['out'], $rows, PREG_SET_ORDER );

		foreach ( $rows as $row ) {
			if ( (int) $row[3] > 0 ) {
				$found[] = $row[1] . '.' . $row[2] . ' ' . $row[3];
			}
		}

		if ( 0 !== $result['code'] || ! preg_match( '/^Success: (\d+)/m', $result['out'], $total ) ) {
			$this->warn( 'The database was not searched for the old domain: ' . self::tail( $result ) );
		} elseif ( '0' !== $total[1] ) {
			$this->warn( 'The old domain stays in the database, ' . $total[1] . ' times: ' . implode( ', ', $found ) . '. Email addresses stay on purpose, check the rest. WP-CLI skips objects of classes it cannot load.' );
		} else {
			$this->passed[] = 'The old domain is not in the database.';
		}

		$files = $this->files_with_old_domain( $root_files );

		if ( $files ) {
			$this->warn( 'Files that mention the old domain and were not changed (' . count( $files ) . '): ' . implode( ', ', array_slice( $files, 0, 20 ) ) . '. Check them.' );
		} else {
			$this->passed[] = 'The old domain is not in the code files.';
		}
	}

	/**
	 * Find the old domain in the files of the site root and in code files of wp-content.
	 *
	 * @param string[] $root_files Files the archive put into the site root.
	 * @return string[] Paths from the site root.
	 */
	private function files_with_old_domain( array $root_files ): array {
		$paths   = array();
		$content = $this->root . '/wp-content';

		foreach ( $root_files as $name ) {
			$paths[] = $this->root . '/' . $name;
		}

		$walker = new RecursiveDirectoryIterator( $content, FilesystemIterator::SKIP_DOTS );

		foreach ( new RecursiveIteratorIterator( $walker, RecursiveIteratorIterator::LEAVES_ONLY, RecursiveIteratorIterator::CATCH_GET_CHILD ) as $file ) {
			$path = $file->getPathname();

			if ( $file->isFile() && preg_match( '/\.(php|css|js|json|html?)$/i', $path ) && 0 !== strpos( $path, $content . '/uploads/' ) && 0 !== strpos( $path, $content . '/cache/' ) ) {
				$paths[] = $path;
			}
		}

		$found = array();

		foreach ( $paths as $path ) {
			if ( is_file( $path ) && filesize( $path ) < 2097152 && false !== strpos( (string) file_get_contents( $path ), $this->old_domain ) ) {
				$found[] = substr( $path, strlen( $this->root ) + 1 );
			}
		}

		return $found;
	}

	/**
	 * Compare table sizes with the manifest, before any plugin code runs.
	 *
	 * The site works while the dump runs and the import is checked on its own,
	 * so fewer rows are a thing to look at, not a failure.
	 *
	 * @return void
	 */
	private function verify_rows(): void {
		$database = $this->database();
		$lines    = array();

		foreach ( (array) ( $this->manifest['rows'] ?? array() ) as $table => $expected ) {
			if ( ! preg_match( '/^[A-Za-z0-9_]+$/', (string) $table ) ) {
				continue;
			}

			try {
				$actual = (int) $database->query( 'SELECT COUNT(*) FROM `' . $table . '`' )->fetch_row()[0];
			} catch ( mysqli_sql_exception $e ) {
				$this->failures[] = "The table {$table} is missing.";
				continue;
			}

			if ( $actual < (int) $expected ) {
				$this->warn( "The table {$table} has {$actual} rows, the site had {$expected} when the backup started. Rows can be deleted while the dump runs: check this table." );
				continue;
			}

			$lines[] = "{$table} {$actual}/{$expected}";
		}

		if ( $lines ) {
			$this->passed[] = 'Rows, restored/manifest: ' . implode( ', ', $lines );
		}
	}

	/**
	 * Name the PHP files of the old site root. WordPress core files are not in the archive,
	 * and the core checksum check only warns about extra files.
	 *
	 * @param string[] $root_files Files the archive put into the site root.
	 * @return void
	 */
	private function verify_root_files( array $root_files ): void {
		$scripts = preg_grep( '/\.(php\d?|phtml|phar)$/i', $root_files );

		if ( $scripts ) {
			$this->warn( 'PHP files from the old site root that are not part of WordPress (' . count( $scripts ) . '): ' . implode( ', ', array_slice( $scripts, 0, 20 ) ) . '. Check them before going live: a hacked site hides scripts here.' );
		} else {
			$this->passed[] = 'No extra PHP files in the site root.';
		}
	}

	/**
	 * Compare plugins and the theme with the manifest.
	 *
	 * @return void
	 */
	private function verify_plugins(): void {
		$result = $this->wp( array( 'plugin', 'list', '--fields=file,version', '--format=json', '--skip-update-check' ) );
		$list   = json_decode( $result['out'], true );

		if ( 0 !== $result['code'] || ! is_array( $list ) ) {
			$this->warn( 'The plugin list could not be read: ' . self::tail( $result ) );

			return;
		}

		$now      = array_column( $list, 'version', 'file' );
		$missing  = array();
		$versions = array();

		foreach ( (array) ( $this->manifest['plugins'] ?? array() ) as $file => $plugin ) {
			if ( ! isset( $now[ $file ] ) ) {
				$missing[] = $file;
			} elseif ( (string) $now[ $file ] !== (string) $plugin['version'] ) {
				$versions[] = $file . ' ' . $now[ $file ] . ' (database backup: ' . $plugin['version'] . ')';
			}
		}

		if ( $missing ) {
			$this->failures[] = 'Plugins from the manifest are missing: ' . implode( ', ', $missing );
		}

		if ( $versions ) {
			$this->warn( 'Plugin versions differ from the manifest, the code backup is older or newer than the database: ' . implode( ', ', $versions ) );
		}

		foreach ( array( 'stylesheet', 'template' ) as $key ) {
			$theme = (string) ( $this->manifest['theme'][ $key ] ?? '' );

			if ( '' !== $theme && ! is_dir( $this->root . '/wp-content/themes/' . $theme ) ) {
				$this->failures[] = "The theme {$theme} is missing.";
			}
		}

		if ( ! $missing ) {
			$this->passed[] = 'All ' . count( (array) $this->manifest['plugins'] ) . ' plugins from the manifest are in place.';
		}
	}

	/**
	 * Compare core and plugin files with the checksums of wordpress.org.
	 *
	 * @return void
	 */
	private function verify_checksums(): void {
		$core = $this->wp( array( 'core', 'verify-checksums', '--locale=' . $this->manifest['locale'] ) );

		if ( 0 === $core['code'] ) {
			$this->passed[] = 'WordPress core files match the checksums.';
		} else {
			$this->warn( 'WordPress core files do not match the checksums: ' . self::tail( $core ) );
		}

		$plugins = $this->wp( array( 'plugin', 'verify-checksums', '--all', '--format=json' ) );
		$changed = json_decode( $plugins['out'], true );

		if ( is_array( $changed ) && $changed ) {
			$names = array_unique( array_column( $changed, 'plugin_name' ) );

			$this->warn( count( $changed ) . ' files of wordpress.org plugins differ from the originals, in: ' . implode( ', ', $names ) . '. If the old site was hacked, reinstall these plugins.' );
		} elseif ( 0 === $plugins['code'] ) {
			$this->passed[] = 'Plugin checksums, wordpress.org plugins only: ' . trim( str_replace( 'Success: ', '', $plugins['out'] ) );
		} else {
			$this->warn( 'Plugin checksums were not checked: ' . self::tail( $plugins ) );
		}
	}

	/**
	 * Look for scripts in the uploads folder.
	 *
	 * @return void
	 */
	private function verify_uploads(): void {
		if ( '' === $this->uploads || ! is_dir( $this->uploads ) ) {
			return;
		}

		$found = array();

		foreach ( new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $this->uploads, FilesystemIterator::SKIP_DOTS ) ) as $file ) {
			if ( ! $file->isFile() || ! preg_match( '/\.(php\d?|phtml|phar)$/i', $file->getFilename() ) ) {
				continue;
			}

			if ( $file->getSize() < 200 && false !== strpos( (string) file_get_contents( $file->getPathname() ), 'Silence is golden' ) ) {
				continue;
			}

			$found[] = substr( $file->getPathname(), strlen( $this->root ) + 1 );
		}

		if ( $found ) {
			$this->warn( 'PHP files in uploads (' . count( $found ) . '). Uploads normally hold none: check them before going live. ' . implode( ', ', array_slice( $found, 0, 20 ) ) );
		} else {
			$this->passed[] = 'No PHP files in uploads.';
		}
	}

	/**
	 * Request the home and login pages from this server, before DNS points here.
	 *
	 * @return void
	 */
	private function verify_http(): void {
		$pages = array(
			array( (string) $this->manifest['home'] . '/', 'wp-content' ),
			array( (string) ( $this->manifest['siteurl'] ?? $this->manifest['home'] ) . '/wp-login.php', 'user_login' ),
		);

		foreach ( $pages as $page ) {
			$url  = $page[0];
			$host = (string) parse_url( $url, PHP_URL_HOST );
			$ip   = $this->options['server-ip'];
			$curl = curl_init( $url );

			curl_setopt_array(
				$curl,
				array(
					CURLOPT_RETURNTRANSFER => true,
					CURLOPT_TIMEOUT        => 120,
					CURLOPT_RESOLVE        => array( "{$host}:80:{$ip}", "{$host}:443:{$ip}" ),
					CURLOPT_SSL_VERIFYPEER => false,
					CURLOPT_SSL_VERIFYHOST => 0,
					CURLOPT_FOLLOWLOCATION => true,
					CURLOPT_MAXREDIRS      => 3,
				)
			);

			$body  = curl_exec( $curl );
			$code  = (int) curl_getinfo( $curl, CURLINFO_HTTP_CODE );
			$final = (string) curl_getinfo( $curl, CURLINFO_EFFECTIVE_URL );

			if ( false === $body ) {
				$this->warn( "{$url} was not checked from this server: " . curl_error( $curl ) . '. Open it in a browser with the server address in your hosts file.' );
			} elseif ( parse_url( $final, PHP_URL_HOST ) !== $host ) {
				$this->warn( "{$url} redirects to {$final}. Check it in a browser." );
			} elseif ( 200 === $code && false !== strpos( (string) $body, $page[1] ) ) {
				$this->passed[] = "{$url} answers 200.";
			} else {
				$this->warn( "{$url} answers {$code}" . ( 200 === $code ? ' with another page, not WordPress' : '' ) . '. Open it in a browser with the server address in your hosts file.' );
			}

			if ( '' !== $this->old_domain && ! $this->new_holds_old() && preg_match_all( '#\\\\?/\\\\?/(www\.)?' . preg_quote( $this->old_domain, '#' ) . '(?![\w-])#', (string) $body ) ) {
				$this->warn( "{$url} still links to the old domain." );
			}
		}
	}

	/**
	 * Print the result and the steps left, and keep them next to the temporary folder.
	 *
	 * @param array<string, mixed> $backup  Result of choose_backup().
	 * @param int                  $seconds Run time.
	 * @return void
	 */
	private function write_report( array $backup, int $seconds ): void {
		$constants = (array) ( $this->manifest['constants'] ?? array() );
		$lines     = array( '', '=== ' . ( $this->failures ? 'RESTORED WITH ERRORS' : 'RESTORED' ) . ' in ' . $seconds . ' s ===', '' );
		$lines[]   = 'Site: ' . $this->manifest['home'] . ' in ' . $this->root;
		$lines[]   = 'Database backup: ' . $backup['db_tag'] . ', code backup: ' . $backup['code_tag'];

		$groups = array(
			'Errors'        => $this->failures,
			'Check by hand' => $this->warnings,
			'Passed'        => $this->passed,
		);

		foreach ( $groups as $title => $items ) {
			if ( $items ) {
				$lines[] = '';
				$lines[] = $title . ':';

				foreach ( $items as $item ) {
					$lines[] = '- ' . $item;
				}
			}
		}

		$steps = array(
			'Revoke the GitHub token of the old server, if not done yet: if the old server comes back, its backups push out the new ones.',
			'Open the site and the admin area with the server address in your hosts file. All sessions are closed, log in again.',
		);

		if ( $constants ) {
			$steps[] = 'Set the constants the site needs in wp-config.php: ' . implode( ', ', $constants ) . '.' . ( '' !== $this->old_domain ? ' Their saved values can hold the old domain.' : '' );
		}

		$steps[] = 'WordPress sends nothing yet: no outgoing requests, mail, cron or background queues. Plugins that call curl directly are not stopped. To go live, delete the file: rm ' . $this->root . '/' . self::HOLD_FILE;
		$steps[] = 'Point the domain to this server and issue the SSL certificate, if not done yet.';
		$steps[] = 'Create the cron tasks of the site. Add a new GitHub token to wp-config.php and the backup cron command from the plugin settings.';

		if ( '' !== $this->old_domain ) {
			$steps[] = 'Ask the studio to add the new domain to the license list: without it the settings of MVweb plugins and their updates stay closed.';
			$steps[] = 'Set the sender address of site emails, and SPF, DKIM and DMARC for the new domain. Rebuild product feeds.';
			$steps[] = 'Register again what is tied to the address: webhooks, payment systems, connected services. A Telegram bot refuses a second address: call its deleteWebhook method first. Browser push subscribers have to subscribe again.';
			$steps[] = 'Add the new address to Yandex Metrika. Add the site to Yandex Webmaster and Google Search Console and submit the sitemap. Use the site move tools of these two only if the old domain still redirects here.';
		}

		$lines[] = '';
		$lines[] = 'Next steps:';

		foreach ( $steps as $number => $step ) {
			$lines[] = ( $number + 1 ) . '. ' . $step;
		}

		$text = implode( "\n", $lines ) . "\n";
		$file = dirname( $this->work ) . '/mvweb-restore-report.txt';

		echo $text;

		if ( file_put_contents( $file, $text ) ) {
			chmod( $file, 0600 );
			echo "\nThis report is saved in {$file}\n";
		}
	}

	/**
	 * Delete the temporary folder and this script.
	 *
	 * @return void
	 */
	private function clean_up(): void {
		self::remove_tree( $this->work );

		if ( is_dir( $this->work ) ) {
			echo "\nThe temporary folder was not deleted. Delete it by hand, it can hold the database: {$this->work}\n";
		}

		if ( ! @unlink( __FILE__ ) ) {
			echo "\nThis script was not deleted. Delete it by hand: " . __FILE__ . "\n";
		}
	}

	/**
	 * Report a failed run and delete what must not stay on the disk.
	 *
	 * Downloads stay, so the next attempt does not fetch them again.
	 *
	 * @param Throwable $error Reason.
	 * @return void
	 */
	private function fail_run( Throwable $error ): void {
		fwrite( STDERR, "\nError: " . $error->getMessage() . "\n" );

		if ( $this->created && ! $this->fetched ) {
			self::remove_tree( $this->work );
		} elseif ( '' !== $this->work && is_dir( $this->work ) ) {
			self::remove_tree( $this->work . '/plain' );
			@unlink( $this->db_file );

			fwrite( STDERR, "\nDownloaded files stay in {$this->work} for the next attempt. Delete the folder if you stop here: it can hold the database.\n" );
		}

		if ( $this->touched ) {
			fwrite( STDERR, "Before the next attempt empty the site folder and the database.\n" );
		}
	}

	/**
	 * Delete a folder with its contents.
	 *
	 * @param string $path Folder.
	 * @return void
	 */
	private static function remove_tree( string $path ): void {
		if ( ! is_dir( $path ) ) {
			return;
		}

		$items = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $path, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );

		foreach ( $items as $item ) {
			if ( $item->isDir() && ! $item->isLink() ) {
				@rmdir( $item->getPathname() );
			} else {
				@unlink( $item->getPathname() );
			}
		}

		@rmdir( $path );
	}

	/**
	 * Run WP-CLI on the site.
	 *
	 * @param string[] $command Command and its arguments.
	 * @param string   $input   Standard input.
	 * @param bool     $show    Whether the output goes to the screen.
	 * @return array{code: int, out: string, err: string}
	 */
	private function wp( array $command, string $input = '', bool $show = false ): array {
		$php = array( PHP_BINARY, '-d', 'memory_limit=1G', '-d', 'display_errors=stderr', $this->phar, '--path=' . $this->root, '--no-color' );

		return $this->process( array_merge( $php, $command ), $input, $show );
	}

	/**
	 * Run a program without a shell, with the secrets removed from its environment.
	 *
	 * @param string[] $command Program and its arguments.
	 * @param string   $input   Standard input.
	 * @param bool     $show    Whether the output goes to the screen.
	 * @return array{code: int, out: string, err: string}
	 */
	private function process( array $command, string $input = '', bool $show = false ): array {
		$out   = $this->work . '/process.out';
		$err   = $this->work . '/process.err';
		$pipes = array();

		$process = @proc_open(
			$command,
			array(
				0 => array( 'pipe', 'r' ),
				1 => $show ? STDOUT : array( 'file', $out, 'w' ),
				2 => array( 'file', $err, 'w' ),
			),
			$pipes,
			$this->work,
			$this->child_env()
		);

		if ( ! is_resource( $process ) ) {
			return array(
				'code' => 127,
				'out'  => '',
				'err'  => 'The program did not start: ' . $command[0],
			);
		}

		if ( '' !== $input ) {
			fwrite( $pipes[0], $input );
		}

		fclose( $pipes[0] );

		$code = proc_close( $process );

		return array(
			'code' => $code,
			'out'  => $show ? '' : (string) @file_get_contents( $out ),
			'err'  => (string) @file_get_contents( $err ),
		);
	}

	/**
	 * Environment of child processes: without the secrets, with WP-CLI settings.
	 *
	 * @return array<string, string>
	 */
	private function child_env(): array {
		$env = getenv();

		unset( $env[ self::ENV_TOKEN ], $env[ self::ENV_KEY ], $env[ self::ENV_DB_PASSWORD ] );

		$env['WP_CLI_CONFIG_PATH']               = $this->work . '/wp-cli.yml';
		$env['WP_CLI_CACHE_DIR']                 = $this->work . '/wp-cli-cache';
		$env['WP_CLI_DISABLE_AUTO_CHECK_UPDATE'] = '1';

		return $env;
	}

	/**
	 * Last lines of a failed command.
	 *
	 * @param array{code: int, out: string, err: string} $result Result of process().
	 * @return string
	 */
	private static function tail( array $result ): string {
		$text = trim( '' !== trim( $result['err'] ) ? $result['err'] : $result['out'] );

		return '' !== $text ? substr( $text, -500 ) : 'exit code ' . $result['code'];
	}

	/**
	 * Note something to look at, now and in the report.
	 *
	 * @param string $message Text.
	 * @return void
	 */
	private function warn( string $message ): void {
		$this->warnings[] = $message;

		echo '  ! ' . $message . "\n";
	}

	/**
	 * Print a line.
	 *
	 * @param string $message Text.
	 * @return void
	 */
	private static function say( string $message ): void {
		echo $message . "\n";
	}

	/**
	 * Size in readable form.
	 *
	 * @param int $bytes Bytes.
	 * @return string
	 */
	private static function size( int $bytes ): string {
		return $bytes >= 1073741824 ? round( $bytes / 1073741824, 1 ) . ' GB' : round( $bytes / 1048576, 1 ) . ' MB';
	}
}

try {
	$mvweb_bk_options = MVweb_BK_Restore::parse( array_slice( $argv ?? array(), 1 ) );
} catch ( RuntimeException $mvweb_bk_error ) {
	fwrite( STDERR, $mvweb_bk_error->getMessage() . "\n" );
	exit( 1 );
}

exit( ( new MVweb_BK_Restore( $mvweb_bk_options ) )->run() );
