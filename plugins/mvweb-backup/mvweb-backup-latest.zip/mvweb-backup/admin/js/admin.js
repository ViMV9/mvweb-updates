/**
 * Admin JavaScript for MVweb Backup.
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		initTabs();
		initCopy();
	});

	/**
	 * Initialize tab navigation on the settings page.
	 */
	function initTabs() {
		var links = document.querySelectorAll('.mvweb-nav__link');
		var panels = document.querySelectorAll('.mvweb-tab-content');

		if (!links.length || !panels.length) {
			return;
		}

		links.forEach(function (link) {
			link.addEventListener('click', function (event) {
				event.preventDefault();

				var target = link.getAttribute('data-tab') || link.getAttribute('href').replace('#', '');
				var panel = document.getElementById(target);

				if (!panel) {
					return;
				}

				links.forEach(function (l) { l.classList.remove('mvweb-nav__link--active'); });
				panels.forEach(function (p) { p.classList.remove('active'); });

				link.classList.add('mvweb-nav__link--active');
				panel.classList.add('active');
			});
		});
	}

	/**
	 * Copy the text of an element to the clipboard.
	 */
	function initCopy() {
		document.querySelectorAll('[data-mvweb-bk-copy]').forEach(function (button) {
			var label = button.textContent;

			button.addEventListener('click', function () {
				var source = document.querySelector(button.getAttribute('data-mvweb-bk-copy'));

				if (!source || !navigator.clipboard) {
					return;
				}

				navigator.clipboard.writeText(source.textContent.trim()).then(function () {
					button.textContent = button.getAttribute('data-copied') || label;
					setTimeout(function () { button.textContent = label; }, 2000);
				});
			});
		});
	}
})();
