<?php
/**
 * Settings tab.
 *
 * Settings API form (options.php) for the "mvweb_bk_settings" option, plus a
 * separate admin-post.php form for the connection check.
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_bk_settings = mvweb_bk_get_settings();
$mvweb_bk_name     = 'mvweb_bk_settings';
$mvweb_bk_labels   = mvweb_bk_part_labels();
$mvweb_bk_token    = mvweb_bk_token_is_set();
$mvweb_bk_lines    = mvweb_bk_cron_lines();
$mvweb_bk_freqs    = mvweb_bk_frequencies();
?>

<form method="post" action="options.php">
	<?php settings_fields( MVweb_BK_Admin::OPTION_GROUP ); ?>
	<input type="hidden" name="_wp_http_referer" value="<?php echo esc_attr( remove_query_arg( 'mvweb_bk_notice', wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- escaped on output, same source as wp_referer_field(). ?>">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Connection', 'mvweb-backup' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'A private GitHub repository receives the backups.', 'mvweb-backup' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb_bk_repo" class="mvweb-form-row__label"><?php esc_html_e( 'Repository', 'mvweb-backup' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text"
					id="mvweb_bk_repo"
					name="<?php echo esc_attr( $mvweb_bk_name ); ?>[repo]"
					class="mvweb-input"
					value="<?php echo esc_attr( (string) $mvweb_bk_settings['repo'] ); ?>"
					placeholder="owner/name"
					autocomplete="off"
					spellcheck="false">
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Owner and name of the private repository, for example my-studio/site-backup. Use a separate repository for each site.', 'mvweb-backup' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'GitHub token', 'mvweb-backup' ); ?></span>
			<div class="mvweb-form-row__field">
				<div>
					<?php if ( $mvweb_bk_token ) : ?>
						<span class="mvweb-badge mvweb-badge--success"><?php esc_html_e( 'Set', 'mvweb-backup' ); ?></span>
					<?php else : ?>
						<span class="mvweb-badge mvweb-badge--warning"><?php esc_html_e( 'Not set', 'mvweb-backup' ); ?></span>
					<?php endif; ?>
				</div>
				<p class="mvweb-form-row__desc">
					<?php
					printf(
						/* translators: %s: constant name */
						esc_html__( 'Define %s in wp-config.php. The token is never saved in the database and never shown here.', 'mvweb-backup' ),
						'<code>MVWEB_BK_GITHUB_TOKEN</code>'
					);
					?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Connection check', 'mvweb-backup' ); ?></span>
			<div class="mvweb-form-row__field">
				<div>
					<button type="submit" form="mvweb-bk-test-form" class="mvweb-btn mvweb-btn--secondary"><?php esc_html_e( 'Check connection', 'mvweb-backup' ); ?></button>
				</div>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Checks the token, the repository and the tools. Nothing is written to the repository.', 'mvweb-backup' ); ?></p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'What to back up', 'mvweb-backup' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'How often each part is backed up. The cron lines below are built from it, and the plugin warns you when a backup is late.', 'mvweb-backup' ); ?></p>

		<?php foreach ( $mvweb_bk_labels as $mvweb_bk_part => $mvweb_bk_label ) : ?>
			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label" for="mvweb-bk-schedule-<?php echo esc_attr( $mvweb_bk_part ); ?>"><?php echo esc_html( $mvweb_bk_label ); ?></label>
				<div class="mvweb-form-row__field">
					<select class="mvweb-select"
						id="mvweb-bk-schedule-<?php echo esc_attr( $mvweb_bk_part ); ?>"
						name="<?php echo esc_attr( $mvweb_bk_name ); ?>[schedule][<?php echo esc_attr( $mvweb_bk_part ); ?>]">
						<?php foreach ( $mvweb_bk_freqs as $mvweb_bk_freq => $mvweb_bk_freq_data ) : ?>
							<option value="<?php echo esc_attr( $mvweb_bk_freq ); ?>" <?php selected( $mvweb_bk_settings['schedule'][ $mvweb_bk_part ] ?? '', $mvweb_bk_freq ); ?>><?php echo esc_html( $mvweb_bk_freq_data['label'] ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>
			</div>
		<?php endforeach; ?>

		<p class="mvweb-form-row__desc"><?php esc_html_e( 'GitHub keeps 30 database copies and 5 code copies. With the code backed up daily, it can be restored only 5 days back, so weekly is better for the code.', 'mvweb-backup' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb_bk_code_exclude" class="mvweb-form-row__label"><?php esc_html_e( 'Skip in code', 'mvweb-backup' ); ?></label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb_bk_code_exclude"
					name="<?php echo esc_attr( $mvweb_bk_name ); ?>[code_exclude]"
					class="mvweb-textarea"
					rows="4"
					spellcheck="false"><?php echo esc_textarea( implode( "\n", (array) $mvweb_bk_settings['code_exclude'] ) ); ?></textarea>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'The code part takes the whole wp-content folder and the files in the site root. One folder per line, relative to wp-content, for example plugins/heavy-plugin. Uploads, caches, logs, backups of other plugins and the cache drop-ins are always skipped.', 'mvweb-backup' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_bk_uploads_exclude" class="mvweb-form-row__label"><?php esc_html_e( 'Skip in uploads', 'mvweb-backup' ); ?></label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb_bk_uploads_exclude"
					name="<?php echo esc_attr( $mvweb_bk_name ); ?>[uploads_exclude]"
					class="mvweb-textarea"
					rows="4"
					spellcheck="false"><?php echo esc_textarea( implode( "\n", (array) $mvweb_bk_settings['uploads_exclude'] ) ); ?></textarea>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'One folder per line, relative to the uploads folder, for example cache or 2019/03. Image thumbnails and WooCommerce logs are always skipped.', 'mvweb-backup' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_bk_skip_product_images" class="mvweb-form-row__label"><?php esc_html_e( 'Product images', 'mvweb-backup' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_bk_skip_product_images"
							name="<?php echo esc_attr( $mvweb_bk_name ); ?>[skip_product_images]"
							value="1"
							<?php checked( ! empty( $mvweb_bk_settings['skip_product_images'] ) ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Skip WooCommerce product images', 'mvweb-backup' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Turn on when the catalogue photos come from an outside service, for example MoySklad, and can be imported again. Images attached to products or set as their main or gallery image are left out, even if a post also uses them.', 'mvweb-backup' ); ?></p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Encryption', 'mvweb-backup' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Release files (database and code archive) can be encrypted with a public key. Only you hold the secret key.', 'mvweb-backup' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb_bk_encrypt" class="mvweb-form-row__label"><?php esc_html_e( 'Encrypt backups', 'mvweb-backup' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_bk_encrypt"
							name="<?php echo esc_attr( $mvweb_bk_name ); ?>[encrypt]"
							value="1"
							<?php checked( ! empty( $mvweb_bk_settings['encrypt'] ) ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Encrypt release files', 'mvweb-backup' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'With encryption on, the code archive also keeps wp-config.php without the database password, salts and backup token, so API keys of the site can be restored.', 'mvweb-backup' ); ?></p>
				<?php if ( ! extension_loaded( 'sodium' ) ) : ?>
					<p class="mvweb-form-row__desc"><?php esc_html_e( 'The sodium PHP extension is not available on this server. Encryption cannot work without it.', 'mvweb-backup' ); ?></p>
				<?php endif; ?>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_bk_public_key" class="mvweb-form-row__label"><?php esc_html_e( 'Public key', 'mvweb-backup' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text"
					id="mvweb_bk_public_key"
					name="<?php echo esc_attr( $mvweb_bk_name ); ?>[public_key]"
					class="mvweb-input"
					value="<?php echo esc_attr( (string) $mvweb_bk_settings['public_key'] ); ?>"
					autocomplete="off"
					spellcheck="false">
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Base64 public key. The Help tab shows how to create a key pair. Never put the secret key on the server.', 'mvweb-backup' ); ?></p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Alerts', 'mvweb-backup' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'A failed run is reported once, then at most once a day until a run succeeds.', 'mvweb-backup' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb_bk_alert_email" class="mvweb-form-row__label"><?php esc_html_e( 'Email recipients', 'mvweb-backup' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text"
					id="mvweb_bk_alert_email"
					name="<?php echo esc_attr( $mvweb_bk_name ); ?>[alert_email]"
					class="mvweb-input"
					value="<?php echo esc_attr( (string) $mvweb_bk_settings['alert_email'] ); ?>"
					placeholder="<?php echo esc_attr( (string) get_option( 'admin_email' ) ); ?>"
					autocomplete="off">
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Comma-separated list. Empty means the site admin email. If MVweb Telegram Hub is active and set up, alerts go to Telegram instead.', 'mvweb-backup' ); ?></p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" class="mvweb-btn mvweb-btn--primary"><?php esc_html_e( 'Save Changes', 'mvweb-backup' ); ?></button>
	</div>
</form>

<form id="mvweb-bk-test-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
	<input type="hidden" name="action" value="mvweb_bk_test_connection">
	<?php wp_nonce_field( 'mvweb_bk_test_connection', 'mvweb_bk_nonce', false ); ?>
</form>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Cron command', 'mvweb-backup' ); ?></div>
	</div>
	<?php if ( $mvweb_bk_lines ) : ?>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Add each line as a separate task to the server cron. The lines follow the saved frequencies: after changing them, save and update the cron tasks.', 'mvweb-backup' ); ?></p>

		<pre class="mvweb-codeblock mvweb-bk-code" id="mvweb-bk-cron-command"><code><?php echo esc_html( implode( "\n", $mvweb_bk_lines ) ); ?></code></pre>

		<p>
			<button type="button"
				class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm"
				data-mvweb-bk-copy="#mvweb-bk-cron-command"
				data-copied="<?php esc_attr_e( 'Copied', 'mvweb-backup' ); ?>"><?php esc_html_e( 'Copy', 'mvweb-backup' ); ?></button>
		</p>

		<p class="mvweb-form-row__desc">
			<?php esc_html_e( 'The five fields at the start of a line are the time: minute, hour, day, month, weekday. The PHP path is for Beget. On other hosting, ask the host for the path to PHP.', 'mvweb-backup' ); ?>
		</p>
	<?php else : ?>
		<p class="mvweb-block__sub"><?php esc_html_e( 'All parts are set to "Do not back up", so there is nothing to add to cron.', 'mvweb-backup' ); ?></p>
	<?php endif; ?>
</div>
