<?php
/**
 * Settings tab.
 *
 * Settings API form (options.php) for the "mvweb_bk_settings" option, plus a
 * separate admin-post.php form for the connection check.
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'get_plugins' ) ) {
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
}

$mvweb_bk_settings = mvweb_bk_get_settings();
$mvweb_bk_name     = 'mvweb_bk_settings';
$mvweb_bk_labels   = mvweb_bk_part_labels();
$mvweb_bk_themes   = wp_get_themes();
$mvweb_bk_plugins  = get_plugins();
$mvweb_bk_token    = mvweb_bk_token_is_set();
$mvweb_bk_command  = mvweb_bk_cron_command( (array) $mvweb_bk_settings['parts'] );
?>

<form method="post" action="options.php">
	<?php settings_fields( MVweb_BK_Admin::OPTION_GROUP ); ?>
	<input type="hidden" name="_wp_http_referer" value="<?php echo esc_attr( remove_query_arg( 'mvweb_bk_notice', wp_unslash( $_SERVER['REQUEST_URI'] ?? '' ) ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- escaped on output, same source as wp_referer_field(). ?>">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Connection', 'mvweb-backup' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'A private GitHub repository receives the backups.', 'mvweb-backup' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb_bk_repo" class="mvweb-form-row__label"><?php esc_html_e( 'Repository', 'mvweb-backup' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text"
					id="mvweb_bk_repo"
					name="<?php echo esc_attr( $mvweb_bk_name ); ?>[repo]"
					class="mvweb-input"
					value="<?php echo esc_attr( (string) $mvweb_bk_settings['repo'] ); ?>"
					placeholder="owner/name"
					autocomplete="off"
					spellcheck="false">
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Owner and name of the private repository, for example my-studio/site-backup. Use a separate repository for each site.', 'mvweb-backup' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'GitHub token', 'mvweb-backup' ); ?></span>
			<div class="mvweb-form-row__field">
				<div>
					<?php if ( $mvweb_bk_token ) : ?>
						<span class="mvweb-badge mvweb-badge--success"><?php esc_html_e( 'Set', 'mvweb-backup' ); ?></span>
					<?php else : ?>
						<span class="mvweb-badge mvweb-badge--warning"><?php esc_html_e( 'Not set', 'mvweb-backup' ); ?></span>
					<?php endif; ?>
				</div>
				<p class="mvweb-form-row__desc">
					<?php
					printf(
						/* translators: %s: constant name */
						esc_html__( 'Define %s in wp-config.php. The token is never saved in the database and never shown here.', 'mvweb-backup' ),
						'<code>MVWEB_BK_GITHUB_TOKEN</code>'
					);
					?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Connection check', 'mvweb-backup' ); ?></span>
			<div class="mvweb-form-row__field">
				<div>
					<button type="submit" form="mvweb-bk-test-form" class="mvweb-btn mvweb-btn--secondary"><?php esc_html_e( 'Check connection', 'mvweb-backup' ); ?></button>
				</div>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Checks the token, the repository and the tools. Nothing is written to the repository.', 'mvweb-backup' ); ?></p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'What to back up', 'mvweb-backup' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Parts for the cron command below. The command without the --only option backs up all parts.', 'mvweb-backup' ); ?></p>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Parts', 'mvweb-backup' ); ?></span>
			<div class="mvweb-form-row__field">
				<?php foreach ( $mvweb_bk_labels as $mvweb_bk_part => $mvweb_bk_label ) : ?>
					<label class="mvweb-check">
						<input type="checkbox"
							name="<?php echo esc_attr( $mvweb_bk_name ); ?>[parts][]"
							value="<?php echo esc_attr( $mvweb_bk_part ); ?>"
							<?php checked( in_array( $mvweb_bk_part, (array) $mvweb_bk_settings['parts'], true ) ); ?>>
						<?php echo esc_html( $mvweb_bk_label ); ?>
					</label>
				<?php endforeach; ?>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'If nothing is ticked, all parts are backed up.', 'mvweb-backup' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Themes', 'mvweb-backup' ); ?></span>
			<div class="mvweb-form-row__field">
				<div class="mvweb-bk-list">
					<?php foreach ( $mvweb_bk_themes as $mvweb_bk_slug => $mvweb_bk_theme ) : ?>
						<label class="mvweb-check">
							<input type="checkbox"
								name="<?php echo esc_attr( $mvweb_bk_name ); ?>[themes][]"
								value="<?php echo esc_attr( (string) $mvweb_bk_slug ); ?>"
								<?php checked( in_array( (string) $mvweb_bk_slug, (array) $mvweb_bk_settings['themes'], true ) ); ?>>
							<?php echo esc_html( (string) $mvweb_bk_theme->get( 'Name' ) ); ?>
						</label>
					<?php endforeach; ?>
				</div>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Only ticked themes are added to the code archive.', 'mvweb-backup' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Plugins', 'mvweb-backup' ); ?></span>
			<div class="mvweb-form-row__field">
				<div class="mvweb-bk-list">
					<?php foreach ( $mvweb_bk_plugins as $mvweb_bk_file => $mvweb_bk_plugin ) : ?>
						<label class="mvweb-check">
							<input type="checkbox"
								name="<?php echo esc_attr( $mvweb_bk_name ); ?>[plugins][]"
								value="<?php echo esc_attr( (string) $mvweb_bk_file ); ?>"
								<?php checked( in_array( (string) $mvweb_bk_file, (array) $mvweb_bk_settings['plugins'], true ) ); ?>>
							<?php echo esc_html( (string) $mvweb_bk_plugin['Name'] ); ?>
						</label>
					<?php endforeach; ?>
				</div>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Only ticked plugins are added to the code archive.', 'mvweb-backup' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_bk_uploads_exclude" class="mvweb-form-row__label"><?php esc_html_e( 'Skip in uploads', 'mvweb-backup' ); ?></label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb_bk_uploads_exclude"
					name="<?php echo esc_attr( $mvweb_bk_name ); ?>[uploads_exclude]"
					class="mvweb-textarea"
					rows="4"
					spellcheck="false"><?php echo esc_textarea( implode( "\n", (array) $mvweb_bk_settings['uploads_exclude'] ) ); ?></textarea>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'One folder per line, relative to the uploads folder, for example cache or 2019/03. Image thumbnails and WooCommerce logs are always skipped.', 'mvweb-backup' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_bk_skip_product_images" class="mvweb-form-row__label"><?php esc_html_e( 'Product images', 'mvweb-backup' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_bk_skip_product_images"
							name="<?php echo esc_attr( $mvweb_bk_name ); ?>[skip_product_images]"
							value="1"
							<?php checked( ! empty( $mvweb_bk_settings['skip_product_images'] ) ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Skip WooCommerce product images', 'mvweb-backup' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Turn on when the catalogue photos come from an outside service, for example MoySklad, and can be imported again. Images attached to products or set as their main or gallery image are left out, even if a post also uses them.', 'mvweb-backup' ); ?></p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Encryption', 'mvweb-backup' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Release files (database and code archive) can be encrypted with a public key. Only you hold the secret key.', 'mvweb-backup' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb_bk_encrypt" class="mvweb-form-row__label"><?php esc_html_e( 'Encrypt backups', 'mvweb-backup' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_bk_encrypt"
							name="<?php echo esc_attr( $mvweb_bk_name ); ?>[encrypt]"
							value="1"
							<?php checked( ! empty( $mvweb_bk_settings['encrypt'] ) ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Encrypt release files', 'mvweb-backup' ); ?></span>
				</div>
				<?php if ( ! extension_loaded( 'sodium' ) ) : ?>
					<p class="mvweb-form-row__desc"><?php esc_html_e( 'The sodium PHP extension is not available on this server. Encryption cannot work without it.', 'mvweb-backup' ); ?></p>
				<?php endif; ?>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_bk_public_key" class="mvweb-form-row__label"><?php esc_html_e( 'Public key', 'mvweb-backup' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text"
					id="mvweb_bk_public_key"
					name="<?php echo esc_attr( $mvweb_bk_name ); ?>[public_key]"
					class="mvweb-input"
					value="<?php echo esc_attr( (string) $mvweb_bk_settings['public_key'] ); ?>"
					autocomplete="off"
					spellcheck="false">
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Base64 public key. The Help tab shows how to create a key pair. Never put the secret key on the server.', 'mvweb-backup' ); ?></p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Alerts', 'mvweb-backup' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'A failed run is reported once, then at most once a day until a run succeeds.', 'mvweb-backup' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb_bk_alert_email" class="mvweb-form-row__label"><?php esc_html_e( 'Email recipients', 'mvweb-backup' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text"
					id="mvweb_bk_alert_email"
					name="<?php echo esc_attr( $mvweb_bk_name ); ?>[alert_email]"
					class="mvweb-input"
					value="<?php echo esc_attr( (string) $mvweb_bk_settings['alert_email'] ); ?>"
					placeholder="<?php echo esc_attr( (string) get_option( 'admin_email' ) ); ?>"
					autocomplete="off">
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Comma-separated list. Empty means the site admin email. If MVweb Telegram Hub is active and set up, alerts go to Telegram instead.', 'mvweb-backup' ); ?></p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" class="mvweb-btn mvweb-btn--primary"><?php esc_html_e( 'Save Changes', 'mvweb-backup' ); ?></button>
	</div>
</form>

<form id="mvweb-bk-test-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
	<input type="hidden" name="action" value="mvweb_bk_test_connection">
	<?php wp_nonce_field( 'mvweb_bk_test_connection', 'mvweb_bk_nonce', false ); ?>
</form>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Cron command', 'mvweb-backup' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Add this command to the server cron. It is built from the saved default parts.', 'mvweb-backup' ); ?></p>

	<pre class="mvweb-codeblock mvweb-bk-code" id="mvweb-bk-cron-command"><code><?php echo esc_html( $mvweb_bk_command ); ?></code></pre>

	<p>
		<button type="button"
			class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm"
			data-mvweb-bk-copy="#mvweb-bk-cron-command"
			data-copied="<?php esc_attr_e( 'Copied', 'mvweb-backup' ); ?>"><?php esc_html_e( 'Copy', 'mvweb-backup' ); ?></button>
	</p>

	<p class="mvweb-form-row__desc">
		<?php esc_html_e( 'The PHP path is for Beget. On other hosting, ask the host for the path to PHP. To run parts at different times, add one cron line per frequency and change the --only list: db, uploads, code.', 'mvweb-backup' ); ?>
	</p>
</div>
