<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Print a command in a code block.
 *
 * @param string $mvweb_bk_code Command text (not translated).
 * @return void
 */
$mvweb_bk_pre = static function ( string $mvweb_bk_code ): void {
	echo '<pre class="mvweb-codeblock mvweb-bk-code"><code>' . esc_html( $mvweb_bk_code ) . '</code></pre>';
};

require_once MVWEB_BK_PATH . 'includes/class-mvweb-bk-site.php';

$mvweb_bk_cron_example = implode( "\n", mvweb_bk_cron_lines() ? mvweb_bk_cron_lines() : array( '30 3 * * * ' . mvweb_bk_cron_command( mvweb_bk_parts() ) ) );
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-backup' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Create a private repository and a token', 'mvweb-backup' ); ?></strong>
			<p><?php esc_html_e( 'The repository receives the backups. The token lets the plugin write to this one repository only. See the GitHub section below.', 'mvweb-backup' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Put the token into wp-config.php', 'mvweb-backup' ); ?></strong>
			<p><?php esc_html_e( 'The token is kept in a constant, never in the database. The Settings tab shows only whether it is set.', 'mvweb-backup' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Fill in the Settings tab', 'mvweb-backup' ); ?></strong>
			<p><?php esc_html_e( 'Enter the repository, save, then press Check connection.', 'mvweb-backup' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Add the cron command', 'mvweb-backup' ); ?></strong>
			<p><?php esc_html_e( 'Choose how often each part is backed up on the Settings tab. Copy the cron lines shown there into the server cron, one task per line.', 'mvweb-backup' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Optional: turn on encryption', 'mvweb-backup' ); ?></strong>
			<p><?php esc_html_e( 'Create a key pair on your own computer and paste only the public key into the Settings tab.', 'mvweb-backup' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'What is backed up', 'mvweb-backup' ); ?></div>
	</div>

	<div class="mvweb-table-wrap">
		<table class="mvweb-table">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Part', 'mvweb-backup' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Where it goes', 'mvweb-backup' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><?php esc_html_e( 'Database (including WooCommerce orders)', 'mvweb-backup' ); ?></td>
					<td><?php esc_html_e( 'A compressed SQL file attached to a release of the repository, with a manifest of the site: address, versions, table prefix, plugins.', 'mvweb-backup' ); ?></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'The wp-content folder without uploads and caches, and the site files from the root such as .htaccess and robots.txt', 'mvweb-backup' ); ?></td>
					<td><?php esc_html_e( 'A ZIP archive attached to its own release, with a manifest of the site. Folders in the site root are not included. The wp-config.php file is included only with encryption on, without the database password, salts and backup token.', 'mvweb-backup' ); ?></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Uploads', 'mvweb-backup' ); ?></td>
					<td><?php esc_html_e( 'ZIP archives in the permanent release "uploads": one per month folder and one per other folder. Only archives whose files changed are uploaded again. Thumbnails, WooCommerce logs, the skipped folders and, if chosen, product images are left out.', 'mvweb-backup' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>

	<p><?php esc_html_e( 'The 30 latest database releases and the 5 latest code releases are kept, older ones are deleted automatically. Upload archives of folders that no longer have files to back up stay in the release.', 'mvweb-backup' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( '1. GitHub: repository and token', 'mvweb-backup' ); ?></div>
	</div>

	<p><?php esc_html_e( 'Choose the account that will own the repository. Either use a separate machine account of your studio (GitHub allows one person one free personal account plus one machine account), or use the client\'s own account.', 'mvweb-backup' ); ?></p>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Create a private repository', 'mvweb-backup' ); ?></strong>
			<p><?php esc_html_e( 'Make it private and tick Add a README file: the repository must not be empty. Use a separate repository for each site, otherwise the sites delete each other\'s backups.', 'mvweb-backup' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Open the token page', 'mvweb-backup' ); ?></strong>
			<p><?php esc_html_e( 'On GitHub open Settings, then Developer settings, then Personal access tokens, then Fine-grained tokens, then Generate new token.', 'mvweb-backup' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Limit the token to one repository', 'mvweb-backup' ); ?></strong>
			<p><?php esc_html_e( 'Under Repository access choose Only select repositories and pick the backup repository.', 'mvweb-backup' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Give the only permission needed', 'mvweb-backup' ); ?></strong>
			<p><?php esc_html_e( 'Under Permissions, Repository permissions, set Contents to Read and write. Metadata: Read is added automatically.', 'mvweb-backup' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Set the expiry', 'mvweb-backup' ); ?></strong>
			<p><?php esc_html_e( 'Choose the longest period GitHub allows and set a reminder to replace the token before it expires. An expired token stops the backups.', 'mvweb-backup' ); ?></p>
		</div></li>
	</ol>

	<div class="mvweb-alert mvweb-alert--warning">
		<div class="mvweb-alert__body">
			<p class="mvweb-alert__title"><?php esc_html_e( 'What the token can and cannot do', 'mvweb-backup' ); ?></p>
			<?php esc_html_e( 'The token cannot delete the repository, because it has no Administration permission. It can delete releases and rewrite the history of the repository. Keep it secret and keep the repository private.', 'mvweb-backup' ); ?>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( '2. wp-config.php: the token constant', 'mvweb-backup' ); ?></div>
	</div>

	<p><?php esc_html_e( 'Open wp-config.php in the site root and add this line above the comment "That\'s all, stop editing!". Replace the value with your token.', 'mvweb-backup' ); ?></p>

	<?php $mvweb_bk_pre( "define( 'MVWEB_BK_GITHUB_TOKEN', 'github_pat_...' );" ); ?>

	<p><?php esc_html_e( 'The token is not saved in the database, so it does not end up in the database dump. After saving the file, the Settings tab shows the token as Set.', 'mvweb-backup' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( '3. Cron', 'mvweb-backup' ); ?></div>
	</div>

	<p><?php esc_html_e( 'Backups run from the server cron, not from WP-Cron and not through a web request. WP-Cron runs only when someone visits the site and is limited by web time limits. A web request from a cron service can be answered with a JavaScript stub page by the host, so the task never starts. WP-Cron only checks every hour that no backup is late.', 'mvweb-backup' ); ?></p>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'On Beget', 'mvweb-backup' ); ?></strong>
			<p><?php esc_html_e( 'Open the hosting panel, then CRON, and add a task for each line from the Settings tab. Set the time as in the first five fields of the line and paste the rest as the command.', 'mvweb-backup' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'On other hosting or your own server', 'mvweb-backup' ); ?></strong>
			<p><?php esc_html_e( 'Run crontab -e and paste the lines from the Settings tab, like the ones below. Ask the host for the correct path to PHP.', 'mvweb-backup' ); ?></p>
		</div></li>
	</ol>

	<?php $mvweb_bk_pre( $mvweb_bk_cron_example ); ?>

	<p><?php esc_html_e( 'The lines follow the frequencies on the Settings tab: parts with the same frequency share one line, and --only lists them. A command without --only backs up all parts. GitHub keeps 30 database copies and 5 code copies: with a daily run the code can be restored only 5 days back.', 'mvweb-backup' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( '4. Encryption', 'mvweb-backup' ); ?></div>
	</div>

	<p><?php esc_html_e( 'Encryption is optional and off by default. When it is on, the database dump and the code archive are encrypted with your public key. The server holds only the public key, so a stolen token or repository does not expose them. Uploads are not encrypted and are taken as they are, including database dumps and archives that other plugins leave there. Closed folders such as woocommerce_uploads with paid downloads go to GitHub too: add such folders to the skipped folders if they must not leave the server.', 'mvweb-backup' ); ?></p>

	<p><?php esc_html_e( 'A folder added to the skipped list later keeps its old archive in the uploads release. Delete that archive on GitHub by hand.', 'mvweb-backup' ); ?></p>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Create a key pair on your own computer', 'mvweb-backup' ); ?></strong>
			<p><?php esc_html_e( 'Run this command in a terminal on your computer, not on the server. PHP with the sodium extension is required.', 'mvweb-backup' ); ?></p>
		</div></li>
	</ol>

	<?php $mvweb_bk_pre( "php -r '\$k=sodium_crypto_box_keypair();echo \"public: \",base64_encode(sodium_crypto_box_publickey(\$k)),\"\\nsecret: \",base64_encode(sodium_crypto_box_secretkey(\$k)),\"\\n\";'" ); ?>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Store the keys', 'mvweb-backup' ); ?></strong>
			<p><?php esc_html_e( 'Paste the public key into the Public key field on the Settings tab and turn encryption on. Save the secret key in a password manager. Never put the secret key on the server.', 'mvweb-backup' ); ?></p>
		</div></li>
	</ol>

	<div class="mvweb-alert mvweb-alert--error">
		<div class="mvweb-alert__body">
			<p class="mvweb-alert__title"><?php esc_html_e( 'Lost secret key means lost backups', 'mvweb-backup' ); ?></p>
			<?php esc_html_e( 'Nobody can decrypt encrypted backups without the secret key, not even the plugin author. Keep a second copy of the secret key in a safe place.', 'mvweb-backup' ); ?>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( '5. Restore', 'mvweb-backup' ); ?></div>
	</div>

	<p><?php esc_html_e( 'The same steps are kept in the README of the backup repository, so they stay at hand when the site is down. Save the repository name, the secret key and access to the GitHub account outside the server.', 'mvweb-backup' ); ?></p>

	<ol class="mvweb-steps">
		<?php foreach ( MVweb_BK_Site::restore_steps() as $mvweb_bk_step ) : ?>
			<li><div>
				<strong><?php echo esc_html( $mvweb_bk_step['title'] ); ?></strong>
				<p><?php echo esc_html( $mvweb_bk_step['text'] ); ?></p>
				<?php
				if ( '' !== $mvweb_bk_step['code'] ) {
					$mvweb_bk_pre( $mvweb_bk_step['code'] );
				}
				?>
			</div></li>
		<?php endforeach; ?>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-backup' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Why is the token not entered on the Settings tab?', 'mvweb-backup' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'A value saved in the settings goes into the database, and the database dump goes to GitHub. The token in wp-config.php stays out of the dump.', 'mvweb-backup' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Does the backup help if the whole hosting is down?', 'mvweb-backup' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'The data is safe on GitHub, but the site stays offline until it is restored on another server. If the domain DNS is also managed at the same hosting, move the name servers elsewhere, otherwise the domain cannot be pointed to a new server.', 'mvweb-backup' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Are WooCommerce orders backed up?', 'mvweb-backup' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Yes. Orders live in the database, and the whole database is backed up. WooCommerce does not have to be installed.', 'mvweb-backup' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Why are 30 database copies kept?', 'mvweb-backup' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'A hacked site is often found days later, when the latest copies already hold the damage. With a daily backup 30 copies go back a month. Release files do not count toward the repository size, but one file can be at most 2 GiB. The media files have one copy, so check them for scripts after a hack.', 'mvweb-backup' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How am I told about a failed backup?', 'mvweb-backup' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'By Telegram when MVweb Telegram Hub is active and set up, otherwise by email. The first failure is reported at once. While it repeats, a reminder comes at most once a day. After the first successful run one message says the backup works again. A backup that is late for its frequency, for example because the server cron stopped, is reported the same way and marked on the Log tab.', 'mvweb-backup' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The cron command does nothing. What should I check?', 'mvweb-backup' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Open the Log tab. If a run is listed, read its error. If there are no runs, check that the PHP path in the command is correct for your host, and that the cron task is saved and enabled. The command exits with code 1 and prints the error text when a run fails.', 'mvweb-backup' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-backup' ); ?></div>
	</div>
	<p>
		<?php
		printf(
			/* translators: %s: MVweb plugin URL */
			esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-backup' ),
			'<a href="https://mvweb.ru/plugins/mvweb-backup" target="_blank" rel="noopener">mvweb.ru</a>'
		);
		?>
	</p>
	<p>
		<?php
		printf(
			/* translators: %s: plugin version */
			esc_html__( 'Version: %s', 'mvweb-backup' ),
			esc_html( MVWEB_BK_VERSION )
		);
		?>
	</p>
</div>
