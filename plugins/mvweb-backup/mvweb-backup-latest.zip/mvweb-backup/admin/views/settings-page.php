<?php
/**
 * Admin settings page template.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 * Reference: docs/ui-kit-reference.html
 *
 * Структура:
 *   .wrap.mvweb-settings  — корневой контейнер (max-width 1280px из UI Kit)
 *     ├── aside.mvweb-sidebar  — левая колонка 272px (бренд + меню вкладок)
 *     │     └── ul.mvweb-nav   — вкладки рендерятся как nav-ссылки с иконкой
 *     └── main.mvweb-main      — правая колонка (header + контент вкладок)
 *
 * Каждая вкладка — отдельный partial admin/views/tab-{slug}.php.
 * Переключение вкладок — на JS (admin.js), классы .mvweb-tab-content.active.
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_bk_current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'settings'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.

$mvweb_bk_tabs = array(
	'settings' => array(
		'label' => __( 'Settings', 'mvweb-backup' ),
		'count' => null,
		'icon'  => 'gear',
	),
	'log'      => array(
		'label' => __( 'Log', 'mvweb-backup' ),
		'count' => null,
		'icon'  => 'list',
	),
	'help'     => array(
		'label' => __( 'Help', 'mvweb-backup' ),
		'count' => null,
		'icon'  => 'help',
	),
);

if ( ! isset( $mvweb_bk_tabs[ $mvweb_bk_current_tab ] ) ) {
	$mvweb_bk_current_tab = 'settings';
}

$mvweb_bk_icons = array(
	'list' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/></svg>',
	'gear' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
	'help' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">BK</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Backup', 'mvweb-backup' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_BK_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $mvweb_bk_tabs as $mvweb_bk_tab_id => $mvweb_bk_tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $mvweb_bk_tab_id ); ?>"
						class="mvweb-nav__link <?php echo $mvweb_bk_current_tab === $mvweb_bk_tab_id ? 'mvweb-nav__link--active' : ''; ?>"
						data-tab="<?php echo esc_attr( $mvweb_bk_tab_id ); ?>">
						<?php echo $mvweb_bk_icons[ $mvweb_bk_tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $mvweb_bk_tab['label'] ); ?>
						<?php if ( null !== $mvweb_bk_tab['count'] ) : ?>
							<span class="mvweb-nav__badge"><?php echo esc_html( (string) $mvweb_bk_tab['count'] ); ?></span>
						<?php endif; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php
		if ( isset( $_GET['settings-updated'] ) && 'true' === sanitize_key( wp_unslash( $_GET['settings-updated'] ) ) && ! get_settings_errors( 'mvweb_bk_settings' ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flag set by options.php.
			add_settings_error( 'mvweb_bk_settings', 'mvweb_bk_saved', __( 'Settings saved.', 'mvweb-backup' ), 'success' );
		}
		settings_errors( 'mvweb_bk_settings' );

		$mvweb_bk_check = array();

		if ( isset( $_GET['mvweb_bk_notice'] ) && 'checked' === sanitize_key( wp_unslash( $_GET['mvweb_bk_notice'] ) ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only flag, the result comes from the user's own transient.
			$mvweb_bk_check = get_transient( MVweb_BK_Admin::check_transient() );
			$mvweb_bk_check = is_array( $mvweb_bk_check ) ? $mvweb_bk_check : array();
			delete_transient( MVweb_BK_Admin::check_transient() );
		}

		$mvweb_bk_statuses = array_column( $mvweb_bk_check, 'status' );
		$mvweb_bk_alert    = in_array( 'error', $mvweb_bk_statuses, true ) ? 'error' : ( in_array( 'warning', $mvweb_bk_statuses, true ) ? 'warning' : 'success' );
		$mvweb_bk_badges   = array(
			'ok'      => array( 'success', __( 'OK', 'mvweb-backup' ) ),
			'warning' => array( 'warning', __( 'Warning', 'mvweb-backup' ) ),
			'error'   => array( 'error', __( 'Error', 'mvweb-backup' ) ),
		);
		?>

		<?php if ( mvweb_bk_late_parts() ) : ?>
			<div class="mvweb-alert mvweb-alert--error" role="status">
				<div class="mvweb-alert__body">
					<div class="mvweb-alert__title"><?php esc_html_e( 'The backup is late', 'mvweb-backup' ); ?></div>
					<p><?php esc_html_e( 'A part has not been backed up as often as set. Check the cron task on the server. Details are on the Log tab.', 'mvweb-backup' ); ?></p>
				</div>
			</div>
		<?php endif; ?>

		<?php if ( $mvweb_bk_check ) : ?>
			<div class="mvweb-alert mvweb-alert--<?php echo esc_attr( $mvweb_bk_alert ); ?>" role="status">
				<div class="mvweb-alert__body">
					<div class="mvweb-alert__title"><?php esc_html_e( 'Connection check', 'mvweb-backup' ); ?></div>
					<ul class="mvweb-bk-check">
						<?php foreach ( $mvweb_bk_check as $mvweb_bk_row ) : ?>
							<?php $mvweb_bk_badge = $mvweb_bk_badges[ $mvweb_bk_row['status'] ?? 'error' ] ?? $mvweb_bk_badges['error']; ?>
							<li>
								<span class="mvweb-badge mvweb-badge--<?php echo esc_attr( $mvweb_bk_badge[0] ); ?>"><?php echo esc_html( $mvweb_bk_badge[1] ); ?></span>
								<?php echo esc_html( (string) ( $mvweb_bk_row['text'] ?? '' ) ); ?>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			</div>
		<?php endif; ?>

		<div id="settings" class="mvweb-tab-content <?php echo 'settings' === $mvweb_bk_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_BK_PATH . 'admin/views/tab-settings.php'; ?>
		</div>

		<div id="log" class="mvweb-tab-content <?php echo 'log' === $mvweb_bk_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_BK_PATH . 'admin/views/tab-log.php'; ?>
		</div>

		<div id="help" class="mvweb-tab-content <?php echo 'help' === $mvweb_bk_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_BK_PATH . 'admin/views/tab-help.php'; ?>
		</div>

	</main>
</div>
