<?php
/**
 * Log tab: the last backup runs.
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_bk_log    = array_reverse( mvweb_bk_get_log() );
$mvweb_bk_labels = mvweb_bk_part_labels();
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Recent runs', 'mvweb-backup' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'The last 30 runs, newest first.', 'mvweb-backup' ); ?></p>

	<?php if ( empty( $mvweb_bk_log ) ) : ?>
		<div class="mvweb-empty">
			<h3 class="mvweb-empty__title"><?php esc_html_e( 'No runs yet', 'mvweb-backup' ); ?></h3>
			<p class="mvweb-empty__text"><?php esc_html_e( 'Runs appear here after the cron command has been executed.', 'mvweb-backup' ); ?></p>
		</div>
	<?php else : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th scope="col"><?php esc_html_e( 'Date', 'mvweb-backup' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Parts', 'mvweb-backup' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Size', 'mvweb-backup' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Duration', 'mvweb-backup' ); ?></th>
						<th scope="col"><?php esc_html_e( 'Result', 'mvweb-backup' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $mvweb_bk_log as $mvweb_bk_entry ) : ?>
						<?php
						if ( ! is_array( $mvweb_bk_entry ) ) {
							continue;
						}

						$mvweb_bk_parts_text = array();
						foreach ( (array) ( $mvweb_bk_entry['parts'] ?? array() ) as $mvweb_bk_part ) {
							if ( isset( $mvweb_bk_labels[ $mvweb_bk_part ] ) ) {
								$mvweb_bk_parts_text[] = $mvweb_bk_labels[ $mvweb_bk_part ];
							}
						}

						$mvweb_bk_error = isset( $mvweb_bk_entry['error'] ) ? (string) $mvweb_bk_entry['error'] : '';
						?>
						<tr>
							<td><?php echo esc_html( wp_date( 'Y-m-d H:i', (int) ( $mvweb_bk_entry['time'] ?? 0 ) ) ); ?></td>
							<td><?php echo esc_html( implode( ', ', $mvweb_bk_parts_text ) ); ?></td>
							<td><?php echo esc_html( size_format( (int) ( $mvweb_bk_entry['size'] ?? 0 ) ) ); ?></td>
							<td>
								<?php
								echo esc_html(
									sprintf(
										/* translators: %d: number of seconds */
										__( '%d s', 'mvweb-backup' ),
										(int) ( $mvweb_bk_entry['duration'] ?? 0 )
									)
								);
								?>
							</td>
							<td>
								<?php if ( '' === $mvweb_bk_error ) : ?>
									<span class="mvweb-badge mvweb-badge--success"><?php esc_html_e( 'Success', 'mvweb-backup' ); ?></span>
								<?php else : ?>
									<span class="mvweb-badge mvweb-badge--error"><?php esc_html_e( 'Error', 'mvweb-backup' ); ?></span>
									<span class="mvweb-bk-error"><?php echo esc_html( $mvweb_bk_error ); ?></span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</div>
