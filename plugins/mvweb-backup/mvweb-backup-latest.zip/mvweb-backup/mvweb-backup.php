<?php
/**
 * Plugin Name:       MVweb Backup
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-backup
 * Description:       Backs up the site database, uploads and selected code to a private GitHub repository.
 * Version:           1.1.0
 * Requires at least: 7.0
 * Tested up to:      7.1.4
 * Requires PHP:      8.2
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-backup
 * Domain Path:       /languages
 *
 * @package mvweb_bk
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_BK_VERSION' ) ) {
	return;
}

define( 'MVWEB_BK_VERSION', '1.1.0' );
define( 'MVWEB_BK_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_BK_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_BK_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_BK_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_BK_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_BK_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_BK_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_BK_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

$mvweb_bk_updater = null;

if ( class_exists( 'MVweb_Updater' ) ) {
	$mvweb_bk_updater = MVweb_Updater::create( __FILE__, 'mvweb-backup' );
}

// Load MVweb License.
if ( file_exists( MVWEB_BK_PATH . 'includes/class-mvweb-license.php' ) ) {
	require_once MVWEB_BK_PATH . 'includes/class-mvweb-license.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-license.php' ) ) {
	require_once $shared_path . 'class-mvweb-license.php';
}

if ( class_exists( 'MVweb_License' ) ) {
	MVweb_License::init( 'mvweb-backup', $mvweb_bk_updater, 'plugin', 'mvweb-backup' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-backup'] = array(
		'name'         => 'MVweb Backup',
		'description'  => 'Backs up the site database, uploads and selected code to a private GitHub repository.',
		'url'          => 'https://mvweb.ru/plugins/mvweb-backup',
		'settings_url' => 'admin.php?page=mvweb-backup',
		'textdomain'   => 'mvweb-backup',
	);
	return $plugins;
} );

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_bk_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-backup',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_bk_load_textdomain' );

require_once MVWEB_BK_PATH . 'includes/helpers.php';
require_once MVWEB_BK_PATH . 'includes/class-mvweb-bk-github.php';

add_action(
	'init',
	static function () {
		if ( ! wp_next_scheduled( 'mvweb_bk_check_late' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'mvweb_bk_check_late' );
		}
	}
);

add_action(
	'mvweb_bk_check_late',
	static function () {
		require_once MVWEB_BK_PATH . 'includes/class-mvweb-bk-runner.php';
		MVweb_BK_Runner::check_late();
	}
);

register_deactivation_hook(
	__FILE__,
	static function () {
		wp_clear_scheduled_hook( 'mvweb_bk_check_late' );
	}
);

if ( is_admin() ) {
	require_once MVWEB_BK_PATH . 'includes/class-mvweb-bk-admin.php';
	MVweb_BK_Admin::init();
}
