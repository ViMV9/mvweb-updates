<?php
/**
 * Uninstall MVweb Backup
 *
 * Fired when the plugin is uninstalled.
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Delete plugin options.
$options = array(
	'mvweb_bk_settings',
	'mvweb_bk_log',
	'mvweb_bk_alert_state',
);

foreach ( $options as $option ) {
	delete_option( $option );
}

// For multisite, clean up all sites.
if ( is_multisite() ) {
	$sites = get_sites( array( 'number' => 0 ) );
	foreach ( $sites as $site ) {
		switch_to_blog( $site->blog_id );

		foreach ( $options as $option ) {
			delete_option( $option );
		}

		restore_current_blog();
	}
}

// Clear any cached data.
wp_cache_flush();
