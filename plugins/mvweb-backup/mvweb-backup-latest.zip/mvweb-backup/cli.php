<?php
/**
 * Command-line entry point of MVweb Backup.
 *
 * Usage: php cli.php [--only=db,uploads,code]
 * Exit code: 0 on success, 1 on error (message on stderr).
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

if ( 'cli' !== PHP_SAPI ) {
	exit;
}

// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- command-line output to STDOUT and STDERR.

$mvweb_bk_args = isset( $argv ) && is_array( $argv ) ? array_slice( $argv, 1 ) : array();

$mvweb_bk_dir  = __DIR__;
$mvweb_bk_load = '';

for ( $mvweb_bk_level = 0; $mvweb_bk_level < 10; $mvweb_bk_level++ ) {
	if ( is_file( $mvweb_bk_dir . '/wp-load.php' ) ) {
		$mvweb_bk_load = $mvweb_bk_dir . '/wp-load.php';
		break;
	}

	$mvweb_bk_parent = dirname( $mvweb_bk_dir );

	if ( $mvweb_bk_parent === $mvweb_bk_dir ) {
		break;
	}

	$mvweb_bk_dir = $mvweb_bk_parent;
}

if ( '' === $mvweb_bk_load ) {
	fwrite( STDERR, "wp-load.php was not found above the plugin folder.\n" );
	exit( 1 );
}

require_once $mvweb_bk_load;

if ( ! function_exists( 'mvweb_bk_parts' ) ) {
	fwrite( STDERR, "MVweb Backup is not active on this site.\n" );
	exit( 1 );
}

$mvweb_bk_only = array();

foreach ( $mvweb_bk_args as $mvweb_bk_arg ) {
	if ( 0 !== strpos( $mvweb_bk_arg, '--only=' ) ) {
		fwrite( STDERR, "Unknown argument. Usage: php cli.php [--only=db,uploads,code]\n" );
		exit( 1 );
	}

	if ( '' === trim( substr( $mvweb_bk_arg, 7 ), " \t," ) ) {
		fwrite( STDERR, '--only is empty. Allowed: ' . implode( ', ', mvweb_bk_parts() ) . "\n" );
		exit( 1 );
	}

	foreach ( explode( ',', substr( $mvweb_bk_arg, 7 ) ) as $mvweb_bk_part ) {
		$mvweb_bk_part = trim( $mvweb_bk_part );

		if ( '' === $mvweb_bk_part ) {
			continue;
		}

		if ( ! in_array( $mvweb_bk_part, mvweb_bk_parts(), true ) ) {
			fwrite( STDERR, 'Unknown part in --only. Allowed: ' . implode( ', ', mvweb_bk_parts() ) . "\n" );
			exit( 1 );
		}

		$mvweb_bk_only[ $mvweb_bk_part ] = $mvweb_bk_part;
	}
}

$mvweb_bk_run_parts = $mvweb_bk_only ? array_values( $mvweb_bk_only ) : mvweb_bk_parts();

require_once MVWEB_BK_PATH . 'includes/class-mvweb-bk-db.php';
require_once MVWEB_BK_PATH . 'includes/class-mvweb-bk-runner.php';
require_once MVWEB_BK_PATH . 'includes/class-mvweb-bk-uploads.php';
require_once MVWEB_BK_PATH . 'includes/class-mvweb-bk-site.php';
require_once MVWEB_BK_PATH . 'includes/class-mvweb-bk-crypto.php';

$mvweb_bk_failed = false;

foreach ( MVweb_BK_Runner::run( $mvweb_bk_run_parts ) as $mvweb_bk_result ) {
	$mvweb_bk_line = ( '' !== $mvweb_bk_result['part'] ? $mvweb_bk_result['part'] . ': ' : '' ) . $mvweb_bk_result['message'] . "\n";

	if ( $mvweb_bk_result['ok'] ) {
		fwrite( STDOUT, $mvweb_bk_line );
	} else {
		fwrite( STDERR, $mvweb_bk_line );
		$mvweb_bk_failed = true;
	}
}

exit( $mvweb_bk_failed ? 1 : 0 );
