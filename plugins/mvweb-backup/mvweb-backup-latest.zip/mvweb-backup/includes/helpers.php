<?php
/**
 * Helper functions for MVweb Backup.
 *
 * Shared by the admin page and the CLI entry point (cli.php).
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Backup parts the plugin can handle, in display order.
 *
 * @since 1.0.0
 * @return string[] Part keys, also accepted by the --only= CLI option.
 */
function mvweb_bk_parts(): array {
	return array( 'db', 'uploads', 'code' );
}

/**
 * Human-readable labels for backup parts.
 *
 * @since 1.0.0
 * @return array<string, string> Part key => translated label.
 */
function mvweb_bk_part_labels(): array {
	return array(
		'db'      => __( 'Database', 'mvweb-backup' ),
		'uploads' => __( 'Uploads', 'mvweb-backup' ),
		'code'    => __( 'Theme and plugin code', 'mvweb-backup' ),
	);
}

/**
 * Default value of the settings option.
 *
 * @since 1.0.0
 * @return array<string, mixed>
 */
function mvweb_bk_default_settings(): array {
	return array(
		'repo'                => '',
		'parts'               => mvweb_bk_parts(),
		'themes'              => array(),
		'plugins'             => array(),
		'uploads_exclude'     => array(),
		'skip_product_images' => false,
		'encrypt'             => false,
		'public_key'          => '',
		'alert_email'         => '',
	);
}

/**
 * Read the settings option merged with defaults.
 *
 * @since 1.0.0
 * @return array<string, mixed>
 */
function mvweb_bk_get_settings(): array {
	$saved = get_option( 'mvweb_bk_settings', array() );

	return wp_parse_args( is_array( $saved ) ? $saved : array(), mvweb_bk_default_settings() );
}

/**
 * Whether the GitHub token constant is defined in wp-config.php.
 *
 * The value is never read into any output.
 *
 * @since 1.0.0
 * @return bool
 */
function mvweb_bk_token_is_set(): bool {
	return defined( 'MVWEB_BK_GITHUB_TOKEN' ) && '' !== (string) constant( 'MVWEB_BK_GITHUB_TOKEN' );
}

/**
 * Read the run log (newest entries last, at most 30).
 *
 * Entry keys: time (Unix timestamp), parts (string[]), size (bytes),
 * duration (seconds), error (string, empty on success).
 *
 * @since 1.0.0
 * @return array<int, array<string, mixed>>
 */
function mvweb_bk_get_log(): array {
	$log = get_option( 'mvweb_bk_log', array() );

	return is_array( $log ) ? array_values( $log ) : array();
}

/**
 * Append a run to the log, keeping the last 30 entries.
 *
 * @since 1.0.0
 * @param array<string, mixed> $entry Keys as in mvweb_bk_get_log().
 * @return void
 */
function mvweb_bk_add_log( array $entry ): void {
	$log   = mvweb_bk_get_log();
	$log[] = $entry;

	update_option( 'mvweb_bk_log', array_slice( $log, -30 ), false );
}

/**
 * Quote a value for a POSIX shell only when it needs quoting.
 *
 * @since 1.0.0
 * @param string $value Raw value.
 * @return string
 */
function mvweb_bk_shell_quote( string $value ): string {
	if ( preg_match( '/^[A-Za-z0-9_\/.:@%+=,-]+$/', $value ) ) {
		return $value;
	}

	return "'" . str_replace( "'", "'\\''", $value ) . "'";
}

/**
 * Build the cron command line for the given parts.
 *
 * The PHP binary path is the Beget layout; other hosts differ.
 *
 * @since 1.0.0
 * @param string[] $parts Selected part keys.
 * @return string
 */
function mvweb_bk_cron_command( array $parts ): string {
	$command = '/usr/local/bin/php' . PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION . ' ' . mvweb_bk_shell_quote( MVWEB_BK_PATH . 'cli.php' );

	$parts = array_values( array_intersect( mvweb_bk_parts(), $parts ) );

	if ( $parts && count( $parts ) < count( mvweb_bk_parts() ) ) {
		$command .= ' --only=' . implode( ',', $parts );
	}

	return $command;
}

/**
 * Find a working mysqldump binary.
 *
 * Runs "<binary> --version" without a shell. Bare names rely on PATH, which
 * can be short under PHP-FPM, so common absolute paths are tried as well.
 *
 * @since 1.0.0
 * @return array{bin: string, version: string}|null Binary and its version line, or null.
 */
function mvweb_bk_find_mysqldump(): ?array {
	if ( ! function_exists( 'proc_open' ) ) {
		return null;
	}

	$candidates = array( 'mysqldump', 'mariadb-dump' );

	if ( '' === (string) ini_get( 'open_basedir' ) ) {
		foreach ( array( '/usr/local/bin/mysqldump', '/usr/bin/mysqldump', '/usr/local/bin/mariadb-dump', '/usr/bin/mariadb-dump' ) as $path ) {
			if ( is_executable( $path ) ) {
				$candidates[] = $path;
			}
		}
	}

	$descriptors = array(
		1 => array( 'pipe', 'w' ),
		2 => array( 'pipe', 'w' ),
	);

	foreach ( $candidates as $bin ) {
		$pipes   = array();
		$process = @proc_open( array( $bin, '--version' ), $descriptors, $pipes ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_proc_open, WordPress.PHP.NoSilencedErrors.Discouraged -- fixed argument list, no shell; a missing binary warns under posix_spawn and is handled as false.

		if ( ! is_resource( $process ) ) {
			continue;
		}

		$output = (string) stream_get_contents( $pipes[1] );
		fclose( $pipes[1] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- process pipe.
		fclose( $pipes[2] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- process pipe.

		if ( 0 === proc_close( $process ) && '' !== trim( $output ) ) {
			return array(
				'bin'     => $bin,
				'version' => trim( strtok( $output, "\n" ) ),
			);
		}
	}

	return null;
}

/**
 * Sanitize the "owner/name" repository value.
 *
 * @since 1.0.0
 * @param mixed $value Raw value.
 * @return string Valid value or empty string.
 */
function mvweb_bk_sanitize_repo( $value ): string {
	$value = is_string( $value ) ? trim( $value ) : '';

	if ( '' === $value ) {
		return '';
	}

	if ( ! preg_match( '#^[A-Za-z0-9._-]+/[A-Za-z0-9._-]+$#', $value ) ) {
		return '';
	}

	foreach ( explode( '/', $value ) as $segment ) {
		if ( '.' === $segment || '..' === $segment ) {
			return '';
		}
	}

	return $value;
}

/**
 * Sanitize a base64 libsodium public key.
 *
 * @since 1.0.0
 * @param mixed $value Raw value.
 * @return string Valid key or empty string.
 */
function mvweb_bk_sanitize_public_key( $value ): string {
	$value = is_string( $value ) ? preg_replace( '/\s+/', '', $value ) : '';

	if ( ! is_string( $value ) || '' === $value ) {
		return '';
	}

	$length  = defined( 'SODIUM_CRYPTO_BOX_PUBLICKEYBYTES' ) ? (int) SODIUM_CRYPTO_BOX_PUBLICKEYBYTES : 32;
	$decoded = base64_decode( $value, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- public key validation.

	if ( false === $decoded || strlen( $decoded ) !== $length || base64_encode( $decoded ) !== $value ) { // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- public key validation.
		return '';
	}

	return $value;
}

/**
 * Sanitize the list of upload paths to skip.
 *
 * Accepts a newline-separated string or an array. Keeps relative paths inside
 * uploads only: no absolute paths, no "." or ".." segments.
 *
 * @since 1.0.0
 * @param mixed $value Raw value.
 * @param int   $rejected Number of rejected lines (out).
 * @return string[]
 */
function mvweb_bk_sanitize_excludes( $value, int &$rejected = 0 ): array {
	$lines = is_array( $value ) ? $value : preg_split( '/\R/', is_string( $value ) ? $value : '' );
	$clean = array();

	foreach ( (array) $lines as $line ) {
		$line = trim( str_replace( '\\', '/', sanitize_text_field( (string) $line ) ), " \t/" );

		if ( '' === $line ) {
			continue;
		}

		$valid = ! preg_match( '#^[A-Za-z]:#', $line );

		foreach ( explode( '/', $line ) as $segment ) {
			if ( '' === $segment || '.' === $segment || '..' === $segment ) {
				$valid = false;
				break;
			}
		}

		if ( ! $valid ) {
			++$rejected;
			continue;
		}

		$clean[ $line ] = $line;
	}

	return array_slice( array_values( $clean ), 0, 200 );
}

/**
 * Sanitize a comma-separated list of notification emails.
 *
 * @since 1.0.0
 * @param mixed $value Raw value.
 * @return string Comma-separated valid emails, may be empty.
 */
function mvweb_bk_sanitize_emails( $value ): string {
	$emails = array();

	foreach ( explode( ',', is_string( $value ) ? $value : '' ) as $email ) {
		$email = sanitize_email( trim( $email ) );

		if ( '' !== $email && is_email( $email ) ) {
			$emails[ $email ] = $email;
		}
	}

	return implode( ', ', $emails );
}

/**
 * Settings API sanitize callback for the "mvweb_bk_settings" option.
 *
 * @since 1.0.0
 * @param mixed $input Raw submitted value.
 * @return array<string, mixed>
 */
function mvweb_bk_sanitize_settings( $input ): array {
	$input    = is_array( $input ) ? $input : array();
	$defaults = mvweb_bk_default_settings();
	$output   = $defaults;

	// Repository.
	$repo           = isset( $input['repo'] ) ? trim( (string) $input['repo'] ) : '';
	$output['repo'] = mvweb_bk_sanitize_repo( $repo );

	if ( '' !== $repo && '' === $output['repo'] ) {
		add_settings_error(
			'mvweb_bk_settings',
			'mvweb_bk_repo',
			__( 'The repository must look like owner/name and use only letters, digits, dots, hyphens and underscores.', 'mvweb-backup' ),
			'error'
		);
	}

	// Default parts: nothing ticked means everything.
	$parts = isset( $input['parts'] ) && is_array( $input['parts'] ) ? array_map( 'strval', $input['parts'] ) : array();
	$parts = array_values( array_intersect( mvweb_bk_parts(), $parts ) );

	$output['parts'] = $parts ? $parts : $defaults['parts'];

	// Themes and plugins: only installed ones.
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}

	$themes  = isset( $input['themes'] ) && is_array( $input['themes'] ) ? array_map( 'strval', $input['themes'] ) : array();
	$plugins = isset( $input['plugins'] ) && is_array( $input['plugins'] ) ? array_map( 'strval', $input['plugins'] ) : array();

	$output['themes']  = array_values( array_intersect( array_map( 'strval', array_keys( wp_get_themes() ) ), $themes ) );
	$output['plugins'] = array_values( array_intersect( array_map( 'strval', array_keys( get_plugins() ) ), $plugins ) );

	// Uploads exclusions.
	$rejected                  = 0;
	$output['uploads_exclude'] = mvweb_bk_sanitize_excludes( $input['uploads_exclude'] ?? '', $rejected );

	if ( $rejected > 0 ) {
		add_settings_error(
			'mvweb_bk_settings',
			'mvweb_bk_exclude',
			__( 'Some excluded paths were removed. Use paths relative to the uploads folder without "." or "..".', 'mvweb-backup' ),
			'warning'
		);
	}

	$output['skip_product_images'] = ! empty( $input['skip_product_images'] );

	// Encryption.
	$key       = isset( $input['public_key'] ) ? (string) $input['public_key'] : '';
	$key_clean = mvweb_bk_sanitize_public_key( $key );
	$encrypt   = ! empty( $input['encrypt'] );

	$output['public_key'] = $key_clean;

	// A mistyped key keeps the saved one, so backups do not silently go out unencrypted.
	if ( '' !== trim( $key ) && '' === $key_clean ) {
		$key_clean            = (string) mvweb_bk_get_settings()['public_key'];
		$output['public_key'] = $key_clean;

		add_settings_error(
			'mvweb_bk_settings',
			'mvweb_bk_key',
			__( 'The public key is not valid and was not saved. Paste the base64 public key printed by the key generation command.', 'mvweb-backup' ),
			'error'
		);
	}

	if ( $encrypt && '' === $key_clean ) {
		$encrypt = false;

		add_settings_error(
			'mvweb_bk_settings',
			'mvweb_bk_encrypt',
			__( 'Encryption was turned off because there is no valid public key.', 'mvweb-backup' ),
			'error'
		);
	}

	$output['encrypt'] = $encrypt;

	// Alert recipients.
	$output['alert_email'] = mvweb_bk_sanitize_emails( $input['alert_email'] ?? '' );

	return $output;
}
