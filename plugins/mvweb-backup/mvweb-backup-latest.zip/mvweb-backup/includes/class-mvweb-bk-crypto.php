<?php
/**
 * File encryption with a public key (libsodium), streamed in chunks.
 *
 * Loaded by cli.php only.
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messages go to the CLI and the run log, escaped where shown.
// phpcs:disable WordPress.WP.AlternativeFunctions -- streamed local temp files.

/**
 * Encrypts a file so that only the holder of the secret key can read it.
 *
 * File format: "MVBK1", the random file key sealed with the public key
 * (sodium_crypto_box_seal, 80 bytes), the secretstream header (24 bytes),
 * then chunks of CHUNK plain bytes, each with a 17-byte tag; the last chunk is
 * marked final, so a cut file is detected. Only the server never sees the
 * secret key; decryption runs on the owner's computer (command in the Help tab).
 *
 * @since 1.0.0
 */
final class MVweb_BK_Crypto {

	const MAGIC = 'MVBK1';

	const CHUNK = 1048576;

	/**
	 * Encrypt a file.
	 *
	 * @since 1.0.0
	 * @param string $in         Plain file.
	 * @param string $out        Encrypted file, overwritten.
	 * @param string $public_key Base64 public key from the settings.
	 * @return void
	 * @throws RuntimeException On failure.
	 */
	public static function encrypt_file( string $in, string $out, string $public_key ): void {
		if ( ! function_exists( 'sodium_crypto_secretstream_xchacha20poly1305_init_push' ) ) {
			throw new RuntimeException( __( 'Encryption is on, but the sodium PHP extension is not available.', 'mvweb-backup' ) );
		}

		$recipient = base64_decode( $public_key, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- key from the settings.

		if ( false === $recipient || SODIUM_CRYPTO_BOX_PUBLICKEYBYTES !== strlen( $recipient ) ) {
			throw new RuntimeException( __( 'Encryption is on, but the public key in the settings is not valid.', 'mvweb-backup' ) );
		}

		$source = fopen( $in, 'rb' );

		if ( false === $source ) {
			throw new RuntimeException( __( 'The backup file cannot be read.', 'mvweb-backup' ) );
		}

		$target = fopen( $out, 'wb' );

		if ( false === $target ) {
			fclose( $source );
			throw new RuntimeException( __( 'The encrypted file cannot be created.', 'mvweb-backup' ) );
		}

		$key = sodium_crypto_secretstream_xchacha20poly1305_keygen();

		try {
			list( $state, $header ) = sodium_crypto_secretstream_xchacha20poly1305_init_push( $key );

			self::write( $target, self::MAGIC . sodium_crypto_box_seal( $key, $recipient ) . $header );

			$chunk = self::read( $source );

			while ( true ) {
				$next  = feof( $source ) ? '' : self::read( $source );
				$final = '' === $next;
				$tag   = $final ? SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_FINAL : SODIUM_CRYPTO_SECRETSTREAM_XCHACHA20POLY1305_TAG_MESSAGE;

				self::write( $target, sodium_crypto_secretstream_xchacha20poly1305_push( $state, $chunk, '', $tag ) );

				if ( $final ) {
					break;
				}

				$chunk = $next;
			}
		} finally {
			sodium_memzero( $key );
			fclose( $source );
			fclose( $target );
		}
	}

	/**
	 * Read the next chunk; a read error must not look like the end of the file.
	 *
	 * @since 1.0.0
	 * @param resource $handle File handle.
	 * @return string Up to CHUNK bytes, empty at the end of the file.
	 * @throws RuntimeException On a read error.
	 */
	private static function read( $handle ): string {
		$data = fread( $handle, self::CHUNK );

		if ( false === $data ) {
			throw new RuntimeException( __( 'The backup file cannot be read.', 'mvweb-backup' ) );
		}

		return $data;
	}

	/**
	 * Write all bytes or throw.
	 *
	 * @since 1.0.0
	 * @param resource $handle File handle.
	 * @param string   $data   Data.
	 * @return void
	 * @throws RuntimeException When not everything was written.
	 */
	private static function write( $handle, string $data ): void {
		if ( strlen( $data ) !== fwrite( $handle, $data ) ) {
			throw new RuntimeException( __( 'The encrypted file cannot be written. The disk may be full.', 'mvweb-backup' ) );
		}
	}
}
