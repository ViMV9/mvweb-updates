<?php
/**
 * Admin page: menu, assets, settings registration, form handlers.
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin controller.
 *
 * @since 1.0.0
 */
final class MVweb_BK_Admin {

	const PAGE = 'mvweb-backup';

	const OPTION_GROUP = 'mvweb_bk_settings_group';

	/**
	 * Register hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue' ) );
		add_action( 'admin_post_mvweb_bk_test_connection', array( __CLASS__, 'handle_test_connection' ) );
	}

	/**
	 * Add the submenu page under MVweb Hub.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_menu(): void {
		$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

		add_submenu_page(
			$parent_slug,
			__( 'MVweb Backup', 'mvweb-backup' ),
			__( 'Backup', 'mvweb-backup' ),
			'manage_options',
			self::PAGE,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Register the settings option (Settings API).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_settings(): void {
		register_setting(
			self::OPTION_GROUP,
			'mvweb_bk_settings',
			array(
				'type'              => 'array',
				'sanitize_callback' => 'mvweb_bk_sanitize_settings',
				'default'           => mvweb_bk_default_settings(),
				'show_in_rest'      => false,
			)
		);
	}

	/**
	 * Load admin assets on the plugin page only.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue( $hook ): void {
		if ( false === strpos( (string) $hook, self::PAGE ) ) {
			return;
		}

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_style( 'mvweb-bk-admin', MVWEB_BK_URL . "admin/css/admin{$suffix}.css", array(), MVWEB_BK_VERSION );
		wp_enqueue_style( 'mvweb-bk-plugin', MVWEB_BK_URL . "admin/css/plugin{$suffix}.css", array( 'mvweb-bk-admin' ), MVWEB_BK_VERSION );
		wp_enqueue_script( 'mvweb-bk-admin', MVWEB_BK_URL . "admin/js/admin{$suffix}.js", array(), MVWEB_BK_VERSION, true );
	}

	/**
	 * Render the settings page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'mvweb-backup' ), '', array( 'response' => 403 ) );
		}

		require MVWEB_BK_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Transient key that holds the last check result of the current user.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function check_transient(): string {
		return 'mvweb_bk_check_' . get_current_user_id();
	}

	/**
	 * Handle the "Check connection" form (admin-post.php).
	 *
	 * Runs the checks, keeps the result for the next page view, redirects back.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function handle_test_connection(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'mvweb-backup' ), '', array( 'response' => 403 ) );
		}

		check_admin_referer( 'mvweb_bk_test_connection', 'mvweb_bk_nonce' );

		set_transient( self::check_transient(), self::run_checks(), 5 * MINUTE_IN_SECONDS );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page'            => self::PAGE,
					'tab'             => 'settings',
					'mvweb_bk_notice' => 'checked',
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Check the token, the repository and the server tools.
	 *
	 * Nothing is written to the repository.
	 *
	 * @since 1.0.0
	 * @return array<int, array{status: string, text: string}> Rows, status is ok, warning or error.
	 */
	public static function run_checks(): array {
		$settings = mvweb_bk_get_settings();
		$repo     = (string) $settings['repo'];
		$rows     = array();

		if ( ! mvweb_bk_token_is_set() ) {
			$rows[] = array(
				'status' => 'error',
				'text'   => __( 'The token is not set. Define MVWEB_BK_GITHUB_TOKEN in wp-config.php.', 'mvweb-backup' ),
			);
		}

		if ( '' === $repo ) {
			$rows[] = array(
				'status' => 'error',
				'text'   => __( 'The repository is not set. Enter owner/name and save the settings.', 'mvweb-backup' ),
			);
		}

		if ( ! $rows ) {
			$rows = self::check_github( new MVweb_BK_GitHub( $repo, (string) constant( 'MVWEB_BK_GITHUB_TOKEN' ) ) );
		}

		$dump = mvweb_bk_find_mysqldump();

		$rows[] = $dump
			? array(
				'status' => 'ok',
				/* translators: %s: mysqldump version line */
				'text'   => sprintf( __( 'mysqldump is available: %s', 'mvweb-backup' ), $dump['version'] ),
			)
			: array(
				'status' => 'warning',
				'text'   => __( 'mysqldump is not available. The database will be dumped by PHP, which is slower.', 'mvweb-backup' ),
			);

		if ( ! empty( $settings['encrypt'] ) ) {
			$rows[] = function_exists( 'sodium_crypto_box_seal' )
				? array(
					'status' => 'ok',
					'text'   => __( 'Encryption is available.', 'mvweb-backup' ),
				)
				: array(
					'status' => 'error',
					'text'   => __( 'Encryption is on, but the sodium PHP extension is not available.', 'mvweb-backup' ),
				);
		}

		return $rows;
	}

	/**
	 * Check repository access through the GitHub API.
	 *
	 * Write access is probed with an empty "create reference" request: GitHub
	 * answers 403 without the Contents write permission and 422 (invalid body)
	 * with it, so nothing is created. The "permissions" field of the repository
	 * shows the role of the token owner, not the token rights.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api Client.
	 * @return array<int, array{status: string, text: string}>
	 */
	private static function check_github( MVweb_BK_GitHub $api ): array {
		$rows     = array();
		$response = $api->request( 'GET' );

		if ( is_wp_error( $response ) ) {
			return array(
				array(
					'status' => 'error',
					/* translators: %s: error message */
					'text'   => sprintf( __( 'GitHub did not answer: %s', 'mvweb-backup' ), $response->get_error_message() ),
				),
			);
		}

		if ( 401 === $response['code'] ) {
			return array(
				array(
					'status' => 'error',
					'text'   => __( 'GitHub rejected the token. It is wrong or has expired.', 'mvweb-backup' ),
				),
			);
		}

		if ( 403 === $response['code'] || 404 === $response['code'] ) {
			return array(
				array(
					'status' => 'error',
					'text'   => __( 'The repository was not found, or the token has no access to it. Check owner/name and the repository access of the token.', 'mvweb-backup' ),
				),
			);
		}

		if ( 200 !== $response['code'] || ! is_array( $response['data'] ) ) {
			return array(
				array(
					'status' => 'error',
					/* translators: %d: HTTP status code */
					'text'   => sprintf( __( 'Unexpected GitHub answer: HTTP %d.', 'mvweb-backup' ), $response['code'] ),
				),
			);
		}

		$rows[] = true === ( $response['data']['private'] ?? null )
			? array(
				'status' => 'ok',
				'text'   => __( 'The repository is found and private.', 'mvweb-backup' ),
			)
			: array(
				'status' => 'error',
				'text'   => __( 'The repository is public. Make it private: backups contain the site database.', 'mvweb-backup' ),
			);

		$branch = (string) ( $response['data']['default_branch'] ?? '' );
		$ref    = $api->request( 'GET', '/git/ref/heads/' . $branch );

		if ( is_wp_error( $ref ) ) {
			$rows[] = array(
				'status' => 'warning',
				/* translators: %s: error message */
				'text'   => sprintf( __( 'Write access was not checked: %s', 'mvweb-backup' ), $ref->get_error_message() ),
			);

			return $rows;
		}

		if ( 403 === $ref['code'] ) {
			$rows[] = array(
				'status' => 'error',
				'text'   => __( 'The token cannot write to the repository. Give it the Contents permission with Read and write access.', 'mvweb-backup' ),
			);

			return $rows;
		}

		if ( 200 !== $ref['code'] && 404 !== $ref['code'] && 409 !== $ref['code'] ) {
			$rows[] = array(
				'status' => 'warning',
				/* translators: %d: HTTP status code */
				'text'   => sprintf( __( 'Write access was not checked: HTTP %d.', 'mvweb-backup' ), $ref['code'] ),
			);

			return $rows;
		}

		if ( 200 !== $ref['code'] ) {
			$rows[] = array(
				'status' => 'error',
				'text'   => __( 'The repository is empty. Create the first commit on GitHub, for example add a README file.', 'mvweb-backup' ),
			);

			return $rows;
		}

		$probe = $api->request( 'POST', '/git/refs', new stdClass() );

		if ( is_wp_error( $probe ) ) {
			$rows[] = array(
				'status' => 'warning',
				/* translators: %s: error message */
				'text'   => sprintf( __( 'Write access was not checked: %s', 'mvweb-backup' ), $probe->get_error_message() ),
			);
		} elseif ( 422 === $probe['code'] ) {
			$rows[] = array(
				'status' => 'ok',
				'text'   => __( 'The token can write to the repository.', 'mvweb-backup' ),
			);
		} elseif ( 403 === $probe['code'] || 404 === $probe['code'] ) {
			$rows[] = array(
				'status' => 'error',
				'text'   => __( 'The token cannot write to the repository. Give it the Contents permission with Read and write access.', 'mvweb-backup' ),
			);
		} else {
			$rows[] = array(
				'status' => 'warning',
				/* translators: %d: HTTP status code */
				'text'   => sprintf( __( 'Write access was not checked: HTTP %d.', 'mvweb-backup' ), $probe['code'] ),
			);
		}

		return $rows;
	}
}
