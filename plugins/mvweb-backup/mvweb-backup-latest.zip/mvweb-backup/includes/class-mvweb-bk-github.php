<?php
/**
 * Minimal GitHub REST API client for one repository.
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * GitHub API client bound to "owner/name".
 *
 * The token is sent only in the Authorization header and is never part of a
 * returned value or an error message.
 *
 * @since 1.0.0
 */
final class MVweb_BK_GitHub {

	const API = 'https://api.github.com';

	/**
	 * Repository, "owner/name".
	 *
	 * @var string
	 */
	private string $repo;

	/**
	 * Access token.
	 *
	 * @var string
	 */
	private string $token;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 * @param string $repo  Repository, "owner/name".
	 * @param string $token Access token.
	 */
	public function __construct( string $repo, string $token ) {
		$this->repo  = $repo;
		$this->token = $token;
	}

	/**
	 * Send a request to an endpoint of the repository.
	 *
	 * @since 1.0.0
	 * @param string     $method HTTP method.
	 * @param string     $path   Path after /repos/{owner}/{name}, empty for the repository itself.
	 * @param mixed|null $body   Request body, sent as JSON. Null sends no body.
	 * @return array{code: int, data: mixed}|WP_Error HTTP status and decoded JSON body.
	 */
	public function request( string $method, string $path = '', $body = null ) {
		$args = array(
			'method'     => $method,
			'timeout'    => 15,
			'user-agent' => 'MVweb-Backup/' . MVWEB_BK_VERSION,
			'headers'    => array(
				'Authorization' => 'Bearer ' . $this->token,
				'Accept'        => 'application/vnd.github+json',
			),
		);

		if ( null !== $body ) {
			$args['body']                    = wp_json_encode( $body );
			$args['headers']['Content-Type'] = 'application/json';
		}

		// GitHub answers 500/502/503/504 now and then; a repeat a few seconds later usually passes.
		// Repeated are reads, deletes and release creation (the tag is unique, so a repeat cannot
		// make a second release), and only from the command line, so the admin page never waits.
		$safe    = in_array( $method, array( 'GET', 'DELETE' ), true ) || ( 'POST' === $method && '/releases' === $path );
		$retries = 'cli' === PHP_SAPI && $safe ? 2 : 0;

		for ( $attempt = 0; ; $attempt++ ) {
			$response = wp_remote_request( self::API . '/repos/' . $this->repo . $path, $args );
			$code     = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );

			if ( $attempt >= $retries || ! in_array( $code, array( 0, 500, 502, 503, 504 ), true ) ) {
				break;
			}

			sleep( 3 * ( $attempt + 1 ) );
		}

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		return array(
			'code' => (int) wp_remote_retrieve_response_code( $response ),
			'data' => json_decode( wp_remote_retrieve_body( $response ), true ),
		);
	}

	/**
	 * Upload a file as a release asset, streaming it from disk.
	 *
	 * The WP HTTP API needs the whole body in memory, so a database dump of
	 * hundreds of megabytes is sent with cURL directly.
	 *
	 * @since 1.0.0
	 * @param string $upload_url "upload_url" of the release, with or without the {?name,label} template.
	 * @param string $file       Path to the file.
	 * @param string $name       Asset file name.
	 * @param string $type       Content type.
	 * @return true|WP_Error
	 */
	public function upload_asset( string $upload_url, string $file, string $name, string $type ) {
		if ( ! function_exists( 'curl_init' ) ) {
			return new WP_Error( 'mvweb_bk_upload', __( 'The cURL PHP extension is not available.', 'mvweb-backup' ) );
		}

		$size   = filesize( $file );
		$handle = fopen( $file, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen -- streamed upload.

		if ( false === $size || false === $handle ) {
			return new WP_Error( 'mvweb_bk_upload', __( 'The backup file cannot be read.', 'mvweb-backup' ) );
		}

		// phpcs:disable WordPress.WP.AlternativeFunctions -- the WP HTTP API cannot stream a request body from a file.
		$curl = curl_init( (string) preg_replace( '/\{.*\}$/', '', $upload_url ) . '?name=' . rawurlencode( $name ) );

		curl_setopt_array(
			$curl,
			array(
				CURLOPT_CUSTOMREQUEST  => 'POST',
				CURLOPT_UPLOAD         => true,
				CURLOPT_INFILE         => $handle,
				CURLOPT_INFILESIZE     => $size,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_CONNECTTIMEOUT => 30,
				CURLOPT_TIMEOUT        => 3600,
				CURLOPT_USERAGENT      => 'MVweb-Backup/' . MVWEB_BK_VERSION,
				CURLOPT_CAINFO         => ABSPATH . WPINC . '/certificates/ca-bundle.crt',
				CURLOPT_HTTPHEADER     => array(
					'Authorization: Bearer ' . $this->token,
					'Accept: application/vnd.github+json',
					'Content-Type: ' . $type,
					'Expect:',
				),
			)
		);

		$body  = curl_exec( $curl );
		$code  = (int) curl_getinfo( $curl, CURLINFO_RESPONSE_CODE );
		$error = curl_error( $curl );

		fclose( $handle );
		// phpcs:enable

		if ( false === $body ) {
			return new WP_Error( 'mvweb_bk_upload', $error );
		}

		if ( 201 !== $code ) {
			$data = json_decode( (string) $body, true );

			/* translators: 1: HTTP status code, 2: GitHub message */
			return new WP_Error( 'mvweb_bk_upload', sprintf( __( 'GitHub refused the file: HTTP %1$d %2$s', 'mvweb-backup' ), $code, (string) ( $data['message'] ?? '' ) ) );
		}

		return true;
	}
}
