<?php
/**
 * Uploads backup: one ZIP archive per month folder in a permanent release.
 *
 * Loaded by cli.php only.
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messages go to the CLI and the run log, escaped where shown.

/**
 * Uploads backup.
 *
 * Files are grouped by "YYYY/MM" folder; anything else by its top folder.
 * The asset name carries a hash of the group's file list, so a group is
 * uploaded again only when a file in it was added, changed or removed.
 * Archives of groups no longer on the site stay in the release.
 *
 * @since 1.0.0
 */
final class MVweb_BK_Uploads {

	const TAG = 'uploads';

	/**
	 * Back up the uploads folder.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api Client.
	 * @return array{message: string, size: int}
	 * @throws RuntimeException On failure.
	 */
	public static function run( MVweb_BK_GitHub $api ): array {
		if ( ! class_exists( 'ZipArchive' ) ) {
			throw new RuntimeException( __( 'The zip PHP extension is not available.', 'mvweb-backup' ) );
		}

		$base       = untrailingslashit( wp_get_upload_dir()['basedir'] );
		$unreadable = array();
		$groups     = self::groups( $base, $unreadable );

		$release = self::release( $api );
		$assets  = self::assets( $api, (int) $release['id'] );

		$uploaded = 0;
		$size     = 0;
		$errors   = array();

		foreach ( $groups as $group => $files ) {
			$group = (string) $group;
			$name  = 'uploads-' . $group . '-' . substr( sha1( implode( "\n", $files ) ), 0, 12 ) . '.zip';

			try {
				if ( ! isset( $assets[ $name ] ) ) {
					$size += self::upload_group( $api, $release, $base, array_keys( $files ), $name );
					++$uploaded;
				}

				// Remove older archives of the group on every run, so a failed delete is retried.
				foreach ( $assets as $old => $id ) {
					if ( $old !== $name && preg_match( '/^uploads-' . preg_quote( $group, '/' ) . '-[0-9a-f]{12}\.zip$/', (string) $old ) ) {
						$deleted = $api->request( 'DELETE', '/releases/assets/' . $id );

						if ( is_wp_error( $deleted ) || ! in_array( $deleted['code'], array( 204, 404 ), true ) ) {
							/* translators: %s: archive file name */
							throw new RuntimeException( sprintf( __( 'The old archive %s was not removed. Do not restore it together with the new one.', 'mvweb-backup' ), $old ) );
						}
					}
				}
			} catch ( RuntimeException $e ) {
				$errors[] = $group . ': ' . $e->getMessage();
			}
		}

		if ( $unreadable ) {
			/* translators: %s: list of folders */
			$errors[] = sprintf( __( 'These folders cannot be read and were not backed up: %s', 'mvweb-backup' ), implode( ', ', $unreadable ) );
		}

		if ( $errors ) {
			throw new RuntimeException( implode( '; ', $errors ) );
		}

		return array(
			/* translators: 1: archives uploaded, 2: archives in total */
			'message' => sprintf( __( '%1$d of %2$d archives uploaded', 'mvweb-backup' ), $uploaded, count( $groups ) ) . ', ' . size_format( $size, 1 ),
			'size'    => $size,
		);
	}

	/**
	 * Collect files to back up, grouped.
	 *
	 * A file named "{name}-{W}x{H}.{ext}" is a thumbnail only when "{name}.*"
	 * lies in the same folder, so an original called banner-1920x1080.jpg is
	 * kept. Unreadable folders are skipped and reported.
	 *
	 * @since 1.0.0
	 * @param string   $base       Uploads folder.
	 * @param string[] $unreadable Relative paths of folders that cannot be read (out).
	 * @return array<string, array<string, string>> Group => (relative path => "path size mtime").
	 */
	private static function groups( string $base, array &$unreadable ): array {
		$settings = mvweb_bk_get_settings();
		$skip     = array_merge( array( 'wc-logs' ), (array) $settings['uploads_exclude'] );
		$products = ! empty( $settings['skip_product_images'] ) ? self::product_files() : array();
		$files    = self::walk( $base, '', $skip, $unreadable );
		$stems    = array();
		$groups   = array();

		foreach ( array_keys( $files ) as $relative ) {
			$stems[ (string) preg_replace( '/\.[^.\/]+$/', '', (string) $relative ) ] = true;
		}

		foreach ( $files as $relative => $line ) {
			$relative = (string) $relative;

			if ( isset( $products[ $relative ] ) ) {
				continue;
			}

			if ( preg_match( '/^(.+)-\d+x\d+\.[a-z0-9]+$/i', $relative, $thumb ) && ( isset( $stems[ $thumb[1] ] ) || isset( $stems[ $thumb[1] . '-scaled' ] ) ) ) {
				continue;
			}

			if ( preg_match( '#^(\d{4})/(\d{2})/#', $relative, $match ) ) {
				$group = $match[1] . '-' . $match[2];
			} elseif ( false !== strpos( $relative, '/' ) ) {
				$group = (string) preg_replace( '/[^A-Za-z0-9._-]/', '_', strtok( $relative, '/' ) );
			} else {
				$group = 'root';
			}

			$groups[ $group ][ $relative ] = $line;
		}

		foreach ( $groups as &$list ) {
			ksort( $list, SORT_STRING );
		}
		unset( $list );

		ksort( $groups, SORT_STRING );

		return $groups;
	}

	/**
	 * List files under a folder, without symlinks and skipped folders.
	 *
	 * @since 1.0.0
	 * @param string   $base       Uploads folder.
	 * @param string   $dir        Folder relative to $base, empty for $base.
	 * @param string[] $skip       Relative folders to leave out.
	 * @param string[] $unreadable Folders that cannot be read (out).
	 * @return array<string, string> Relative path => "path size mtime".
	 */
	private static function walk( string $base, string $dir, array $skip, array &$unreadable ): array {
		$path    = '' === $dir ? $base : $base . '/' . $dir;
		$entries = is_readable( $path ) ? @scandir( $path ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- an unreadable folder is reported in the run result.

		if ( false === $entries ) {
			$unreadable[] = '' === $dir ? '/' : $dir;

			return array();
		}

		$files = array();

		foreach ( $entries as $entry ) {
			if ( '.' === $entry || '..' === $entry ) {
				continue;
			}

			$relative = '' === $dir ? $entry : $dir . '/' . $entry;
			$full     = $base . '/' . $relative;

			if ( is_link( $full ) ) {
				continue;
			}

			if ( is_dir( $full ) ) {
				foreach ( $skip as $folder ) {
					if ( rtrim( (string) $folder, '/' ) === $relative ) {
						continue 2;
					}
				}

				$files += self::walk( $base, $relative, $skip, $unreadable );
			} elseif ( is_file( $full ) ) {
				$files[ $relative ] = $relative . ' ' . filesize( $full ) . ' ' . filemtime( $full );
			}
		}

		return $files;
	}

	/**
	 * Files of WooCommerce product images, relative to the uploads folder.
	 *
	 * An image counts as a product image when it is attached to a product or
	 * variation, or is set as its main or gallery image. The full-size original
	 * kept next to a "-scaled" image is included.
	 *
	 * @since 1.0.0
	 * @return array<string, true>
	 */
	private static function product_files(): array {
		global $wpdb;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery -- one-off read of all product images.
		$products = "SELECT ID FROM {$wpdb->posts} WHERE post_type IN ('product', 'product_variation')";
		$ids      = $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_mime_type LIKE 'image/%' AND post_parent IN ({$products})" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table names only.
		$meta     = $wpdb->get_col( "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key IN ('_thumbnail_id', '_product_image_gallery') AND post_id IN ({$products})" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table names only.

		foreach ( $meta as $value ) {
			$ids = array_merge( $ids, explode( ',', (string) $value ) );
		}

		$ids   = array_filter( array_unique( array_map( 'absint', $ids ) ) );
		$files = array();

		foreach ( array_chunk( $ids, 1000 ) as $chunk ) {
			$paths = $wpdb->get_col( "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_wp_attached_file' AND post_id IN (" . implode( ',', $chunk ) . ')' ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared -- integers from absint().

			foreach ( $paths as $path ) {
				$files[ (string) $path ] = true;
				$files[ (string) preg_replace( '/-scaled(\.[a-z0-9]+)$/i', '$1', (string) $path ) ] = true;
			}
		}
		// phpcs:enable WordPress.DB.DirectDatabaseQuery

		return $files;
	}

	/**
	 * Get the permanent "uploads" release, create it if missing.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api Client.
	 * @return array<string, mixed> Release data.
	 * @throws RuntimeException When it cannot be read or created.
	 */
	private static function release( MVweb_BK_GitHub $api ): array {
		$release = $api->request( 'GET', '/releases/tags/' . self::TAG );

		if ( ! is_wp_error( $release ) && 404 === $release['code'] ) {
			$release = $api->request(
				'POST',
				'/releases',
				array(
					'tag_name'    => self::TAG,
					'name'        => self::TAG,
					'body'        => home_url() . "\nwp-content/uploads",
					'make_latest' => 'false',
				)
			);
		}

		if ( is_wp_error( $release ) ) {
			/* translators: %s: error message */
			throw new RuntimeException( sprintf( __( 'GitHub release was not created: %s', 'mvweb-backup' ), $release->get_error_message() ) );
		}

		if ( ! in_array( $release['code'], array( 200, 201 ), true ) || empty( $release['data']['id'] ) ) {
			/* translators: %s: error message */
			throw new RuntimeException( sprintf( __( 'GitHub release was not created: %s', 'mvweb-backup' ), 'HTTP ' . $release['code'] . ' ' . (string) ( $release['data']['message'] ?? '' ) ) );
		}

		return $release['data'];
	}

	/**
	 * Asset names and IDs of a release.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api Client.
	 * @param int             $id  Release ID.
	 * @return array<string, int> Name => asset ID.
	 * @throws RuntimeException When the list cannot be read.
	 */
	private static function assets( MVweb_BK_GitHub $api, int $id ): array {
		$assets = array();

		for ( $page = 1; ; $page++ ) {
			$list = $api->request( 'GET', '/releases/' . $id . '/assets?per_page=100&page=' . $page );

			if ( is_wp_error( $list ) || 200 !== $list['code'] || ! is_array( $list['data'] ) ) {
				throw new RuntimeException( __( 'GitHub did not return the list of uploaded archives.', 'mvweb-backup' ) );
			}

			foreach ( $list['data'] as $asset ) {
				// An interrupted upload leaves an asset that is not "uploaded"; remove it so the name is free.
				if ( 'uploaded' !== ( $asset['state'] ?? 'uploaded' ) ) {
					$api->request( 'DELETE', '/releases/assets/' . (int) $asset['id'] );
					continue;
				}

				$assets[ (string) $asset['name'] ] = (int) $asset['id'];
			}

			if ( count( $list['data'] ) < 100 ) {
				return $assets;
			}
		}
	}

	/**
	 * Pack one group into a ZIP file and upload it.
	 *
	 * Images are stored without compression: they are compressed already.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub      $api     Client.
	 * @param array<string, mixed> $release Release data.
	 * @param string               $base    Uploads folder.
	 * @param string[]             $files   Relative paths.
	 * @param string               $name    Asset name.
	 * @return int Uploaded bytes.
	 * @throws RuntimeException On failure.
	 */
	private static function upload_group( MVweb_BK_GitHub $api, array $release, string $base, array $files, string $name ): int {
		$path = MVweb_BK_DB::temp_file();
		$zip  = null;

		try {
			$zip = new ZipArchive();

			if ( true !== $zip->open( $path, ZipArchive::OVERWRITE ) ) {
				throw new RuntimeException( __( 'The archive cannot be created.', 'mvweb-backup' ) );
			}

			foreach ( $files as $relative ) {
				if ( ! $zip->addFile( $base . '/' . $relative, $relative ) ) {
					/* translators: %s: file path */
					throw new RuntimeException( sprintf( __( 'The file %s cannot be read.', 'mvweb-backup' ), $relative ) );
				}

				$zip->setCompressionName( $relative, ZipArchive::CM_STORE );
			}

			// From here the destructor has nothing to write: close() ends the archive either way.
			$open = $zip;
			$zip  = null;

			if ( ! $open->close() ) {
				/* translators: %s: error from the zip library, for example a missing file or a full disk */
				throw new RuntimeException( sprintf( __( 'The archive cannot be written: %s', 'mvweb-backup' ), $open->getStatusString() ) );
			}

			clearstatcache( true, $path );
			$size = (int) filesize( $path );

			if ( $size >= MVweb_BK_Runner::MAX_ASSET ) {
				throw new RuntimeException( __( 'The backup file is larger than the 2 GiB GitHub limit.', 'mvweb-backup' ) );
			}

			$uploaded = $api->upload_asset( (string) $release['upload_url'], $path, $name, 'application/zip' );

			if ( is_wp_error( $uploaded ) ) {
				/* translators: %s: error message */
				throw new RuntimeException( sprintf( __( 'The file was not uploaded to GitHub: %s', 'mvweb-backup' ), $uploaded->get_error_message() ) );
			}

			return $size;
		} finally {
			// An archive left open by an error would be written again by its destructor.
			if ( $zip instanceof ZipArchive ) {
				$zip->unchangeAll();
			}

			wp_delete_file( $path );
		}
	}
}
