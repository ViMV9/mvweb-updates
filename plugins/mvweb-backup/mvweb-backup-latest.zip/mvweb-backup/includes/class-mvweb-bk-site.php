<?php
/**
 * What a restore needs from the site: code files, root files, manifest, saved
 * constants and the restore instructions.
 *
 * Loaded by cli.php and the Help tab.
 *
 * @package mvweb_bk
 * @since   1.1.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Site contents for the code part and the restore instructions.
 *
 * @since 1.1.0
 */
final class MVweb_BK_Site {

	/**
	 * Layout of the code archive: paths are relative to the site root.
	 */
	const FORMAT = 2;

	/**
	 * Manifest file name inside the code archive.
	 */
	const MANIFEST = 'mvweb-backup-manifest.json';

	/**
	 * Name of the wp-config.php copy inside the code archive.
	 */
	const SAVED_CONFIG = 'wp-config.saved.php';

	/**
	 * Constants a restore creates anew or that must not leave the server.
	 */
	const SECRET_CONSTANTS = array(
		'DB_PASSWORD',
		'MVWEB_BK_GITHUB_TOKEN',
		'AUTH_KEY',
		'SECURE_AUTH_KEY',
		'LOGGED_IN_KEY',
		'NONCE_KEY',
		'AUTH_SALT',
		'SECURE_AUTH_SALT',
		'LOGGED_IN_SALT',
		'NONCE_SALT',
	);

	/**
	 * Files of the WordPress core in the site root.
	 */
	const CORE_ROOT_FILES = array(
		'index.php',
		'license.txt',
		'readme.html',
		'wp-activate.php',
		'wp-blog-header.php',
		'wp-comments-post.php',
		'wp-config-sample.php',
		'wp-config.php',
		'wp-cron.php',
		'wp-links-opml.php',
		'wp-load.php',
		'wp-login.php',
		'wp-mail.php',
		'wp-settings.php',
		'wp-signup.php',
		'wp-trackback.php',
		'xmlrpc.php',
	);

	/**
	 * Files of wp-content worth keeping.
	 *
	 * Left out: uploads (their own part), caches, updates in progress, backups
	 * of other plugins, logs, version control, files with passwords (.env,
	 * .htpasswd), and the cache drop-ins, which hold paths of the old server.
	 *
	 * @since 1.1.0
	 * @param string[] $unreadable Folders that cannot be read (out).
	 * @return string[] Paths relative to wp-content.
	 */
	public static function content_files( array &$unreadable ): array {
		$base    = untrailingslashit( wp_normalize_path( WP_CONTENT_DIR ) );
		$uploads = untrailingslashit( wp_normalize_path( wp_get_upload_dir()['basedir'] ) );
		$skip    = array_merge(
			array( 'cache', 'upgrade', 'upgrade-temp-backup', 'ai1wm-backups', 'updraft', 'backups', 'wflogs' ),
			(array) mvweb_bk_get_settings()['code_exclude']
		);

		if ( 0 === strpos( $uploads, $base . '/' ) ) {
			$skip[] = substr( $uploads, strlen( $base ) + 1 );
		}

		$files = array();

		foreach ( array_keys( MVweb_BK_Uploads::walk( $base, '', $skip, $unreadable, array( '.git', '.svn', 'node_modules' ) ) ) as $relative ) {
			$relative = (string) $relative;

			if ( preg_match( '/(?:\.log|(?:^|\/)\.env(?:\.[^\/]*)?|(?:^|\/)\.htpasswd)$/i', $relative ) ) {
				continue;
			}

			if ( false === strpos( $relative, '/' ) && ( in_array( $relative, array( 'advanced-cache.php', 'object-cache.php' ), true ) || self::is_archive( $relative ) ) ) {
				continue;
			}

			$files[] = $relative;
		}

		return $files;
	}

	/**
	 * Files in the site root that are not part of WordPress.
	 *
	 * Folders are left out, and so are copies of wp-config.php with the password
	 * in them. Of the hidden files only the server settings are taken: on shared
	 * hosting the root can also hold a shell history.
	 *
	 * @since 1.1.0
	 * @return string[] File names.
	 */
	public static function root_files(): array {
		$entries = @scandir( ABSPATH ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- an unreadable root gives an empty list.
		$files   = array();

		foreach ( is_array( $entries ) ? $entries : array() as $entry ) {
			$full = ABSPATH . $entry;

			if ( is_link( $full ) || ! is_file( $full ) || in_array( $entry, self::CORE_ROOT_FILES, true ) || 0 === stripos( $entry, 'wp-config' ) || 'error_log' === $entry || self::is_archive( $entry ) ) {
				continue;
			}

			if ( '.' === $entry[0] && ! in_array( $entry, array( '.htaccess', '.user.ini' ), true ) ) {
				continue;
			}

			$files[] = $entry;
		}

		return $files;
	}

	/**
	 * Whether a file in a top folder is a dump, an archive or a log.
	 *
	 * @since 1.1.0
	 * @param string $name File name.
	 * @return bool
	 */
	private static function is_archive( string $name ): bool {
		return 1 === preg_match( '/\.(sql|gz|zip|tar|tgz|wpress|bak|phar|log)$/i', $name );
	}

	/**
	 * Facts about the site that a dump and an archive do not state plainly.
	 *
	 * Holds no secret values: constants are listed by name only.
	 *
	 * @since 1.1.0
	 * @return array<string, mixed>
	 */
	public static function manifest(): array {
		global $wpdb;

		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$plugins = array();

		foreach ( get_plugins() as $file => $data ) {
			$plugins[ $file ] = array(
				'version' => (string) $data['Version'],
				'active'  => is_plugin_active( $file ),
			);
		}

		$theme = wp_get_theme();
		$rows  = array();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery -- row counts for the restore check.
		foreach ( array( $wpdb->posts, $wpdb->postmeta, $wpdb->users, $wpdb->terms, $wpdb->prefix . 'wc_orders' ) as $table ) {
			if ( $table === $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) ) ) {
				$rows[ $table ] = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM %i', $table ) );
			}
		}
		// phpcs:enable WordPress.DB.DirectDatabaseQuery

		return array(
			'format'         => self::FORMAT,
			'plugin_version' => MVWEB_BK_VERSION,
			'created'        => gmdate( 'c' ),
			'home'           => home_url(),
			'siteurl'        => site_url(),
			'abspath'        => untrailingslashit( ABSPATH ),
			'uploads'        => wp_get_upload_dir()['basedir'],
			'table_prefix'   => $wpdb->prefix,
			'charset'        => $wpdb->charset,
			'collate'        => $wpdb->collate,
			'wordpress'      => get_bloginfo( 'version' ),
			'php'            => PHP_VERSION,
			'database'       => (string) $wpdb->db_server_info(),
			'locale'         => get_locale(),
			'memory_limit'   => (string) ini_get( 'memory_limit' ),
			'permalinks'     => (string) get_option( 'permalink_structure' ),
			'multisite'      => is_multisite(),
			'theme'          => array(
				'stylesheet' => $theme->get_stylesheet(),
				'template'   => $theme->get_template(),
				'version'    => (string) $theme->get( 'Version' ),
			),
			'plugins'        => $plugins,
			'constants'      => self::custom_constants(),
			'rows'           => $rows,
		);
	}

	/**
	 * Manifest as JSON.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public static function manifest_json(): string {
		return (string) wp_json_encode( self::manifest(), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
	}

	/**
	 * Path to wp-config.php, which may lie one folder above the site root.
	 *
	 * @since 1.1.0
	 * @return string Empty when it is not found.
	 */
	private static function config_path(): string {
		foreach ( array( ABSPATH . 'wp-config.php', dirname( ABSPATH ) . '/wp-config.php' ) as $path ) {
			if ( is_readable( $path ) ) {
				return $path;
			}
		}

		return '';
	}

	/**
	 * Names of the constants the site adds to wp-config.php.
	 *
	 * @since 1.1.0
	 * @return string[]
	 */
	private static function custom_constants(): array {
		$path = self::config_path();
		$text = '' !== $path ? (string) file_get_contents( $path ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local file.

		if ( ! preg_match_all( '/^[^\/#*\n]*\bdefine\s*\(\s*[\'"]([A-Za-z0-9_]+)[\'"]/m', $text, $found ) ) {
			return array();
		}

		$standard = array_merge( self::SECRET_CONSTANTS, array( 'DB_NAME', 'DB_USER', 'DB_HOST', 'DB_CHARSET', 'DB_COLLATE', 'ABSPATH' ) );

		return array_values( array_unique( array_diff( $found[1], $standard ) ) );
	}

	/**
	 * Copy of wp-config.php without the database password, salts, backup token and comments.
	 *
	 * Works on PHP tokens, so a define() over several lines goes as a whole and a
	 * value that also serves as the database name stays where it belongs.
	 *
	 * @since 1.1.0
	 * @return string|null Text of the copy. Null when the file cannot be read or the token is still in it.
	 */
	public static function saved_config(): ?string {
		$path = self::config_path();

		if ( '' === $path ) {
			return null;
		}

		$tokens = token_get_all( (string) file_get_contents( $path ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local file.
		$total  = count( $tokens );
		$text   = '';

		for ( $index = 0; $index < $total; $index++ ) {
			$token = $tokens[ $index ];

			if ( ! is_array( $token ) ) {
				$text .= $token;
				continue;
			}

			if ( T_COMMENT === $token[0] || T_DOC_COMMENT === $token[0] ) {
				continue;
			}

			if ( self::defines_secret( $tokens, $index ) ) {
				while ( $index < $total && ';' !== $tokens[ $index ] ) {
					++$index;
				}

				continue;
			}

			$text .= $token[1];
		}

		$secret = defined( 'MVWEB_BK_GITHUB_TOKEN' ) ? (string) constant( 'MVWEB_BK_GITHUB_TOKEN' ) : '';

		if ( '' !== $secret && false !== strpos( $text, $secret ) ) {
			return null;
		}

		return (string) preg_replace( '/\n\s*\n\s*\n/', "\n\n", $text );
	}

	/**
	 * Whether the token at the index opens a define() of a secret constant.
	 *
	 * @since 1.1.0
	 * @param array<int, mixed> $tokens PHP tokens.
	 * @param int               $index  Position to look at.
	 * @return bool
	 */
	private static function defines_secret( array $tokens, int $index ): bool {
		$token = $tokens[ $index ];

		if ( ! is_array( $token ) || ! in_array( $token[0], array( T_STRING, T_NAME_FULLY_QUALIFIED ), true ) || 'define' !== strtolower( ltrim( $token[1], '\\' ) ) ) {
			return false;
		}

		$total = count( $tokens );

		for ( $next = $index + 1; $next < $total; $next++ ) {
			$item = $tokens[ $next ];

			if ( '(' === $item || ( is_array( $item ) && in_array( $item[0], array( T_WHITESPACE, T_COMMENT ), true ) ) ) {
				continue;
			}

			return is_array( $item ) && T_CONSTANT_ENCAPSED_STRING === $item[0] && in_array( trim( $item[1], '\'"' ), self::SECRET_CONSTANTS, true );
		}

		return false;
	}

	/**
	 * Restore steps, for the Help tab and the README of the backup repository.
	 *
	 * Commands carry the real values of this site.
	 *
	 * @since 1.1.0
	 * @return array<int, array{title: string, text: string, code: string}>
	 */
	public static function restore_steps(): array {
		global $wpdb;

		$host = (string) preg_replace( '/^www\./i', '', (string) wp_parse_url( home_url(), PHP_URL_HOST ) );
		$path = untrailingslashit( ABSPATH );
		$all  = ' --all-tables-with-prefix --skip-columns=guid';

		$replace = array(
			"wp search-replace '//" . $host . "' '//NEW-DOMAIN'" . $all,
			"wp search-replace '//www." . $host . "' '//NEW-DOMAIN'" . $all,
			"wp search-replace '\\/\\/" . $host . "' '\\/\\/NEW-DOMAIN'" . $all,
			"wp search-replace '\\/\\/www." . $host . "' '\\/\\/NEW-DOMAIN'" . $all,
		);

		if ( 'https' === wp_parse_url( home_url(), PHP_URL_SCHEME ) ) {
			$replace[] = "wp search-replace 'http://NEW-DOMAIN' 'https://NEW-DOMAIN'" . $all;
			$replace[] = "wp search-replace 'http:\\/\\/NEW-DOMAIN' 'https:\\/\\/NEW-DOMAIN'" . $all;
		}

		$replace[] = "wp search-replace '" . $path . "' '/new/path'" . $all;
		$replace[] = "wp search-replace '" . str_replace( '/', '\\/', $path ) . "' '\\/new\\/path'" . $all;

		$repo = (string) mvweb_bk_get_settings()['repo'];
		$repo = '' !== $repo ? $repo : 'OWNER/REPOSITORY';

		$script = array(
			'read -rs MVWEB_RESTORE_TOKEN',
			"printf 'header = \"Authorization: Bearer %s\"\\n' \"\$MVWEB_RESTORE_TOKEN\" | curl -fsSL -K - -H 'Accept: application/vnd.github.raw' -o restore.php https://api.github.com/repos/" . $repo . '/contents/restore.php',
			'unset MVWEB_RESTORE_TOKEN',
			'php restore.php --repo=' . $repo . ' --path=/full/path/to/site --db-name=DB_NAME --db-user=DB_USER',
		);

		return array(
			array(
				'title' => __( 'Restore with the script', 'mvweb-backup' ),
				'text'  => __( 'This is the fast way. To move to a new domain, point it to the server, issue the SSL certificate and add --new-domain=NEW-DOMAIN to the command. It needs SSH, bash, PHP 8.2 or newer, an empty site folder and an empty database. Revoke the token of the old server and create a read-only token: Contents, Read. If the site was hacked or the token leaked, do not download the script from this repository: the attacker could replace it and get your secret key. Take restore.php from a plugin ZIP you trust. After the first command paste this token and press Enter: it is not shown. The script asks for the token again, for the database password, and for the secret key if encryption was on. It installs WordPress, the database and the files, replaces the old server path and, with this flag, the domain, and prints a report with the next steps. WordPress sends no mail or requests until you delete the file the report names; plugins that call curl directly are not stopped. If the database is on another server, add --db-host=HOST. If php on the server is older than 8.2, use the full path to a newer PHP. The steps below do the same by hand.', 'mvweb-backup' ),
				'code'  => implode( "\n", $script ),
			),
			array(
				'title' => __( 'Download the backup', 'mvweb-backup' ),
				'text'  => __( 'From the latest db- release download the database file and the manifest. From the latest code- release download the code archive. From the uploads release download all ZIP archives. If an uploads folder has two archives, take the newer one.', 'mvweb-backup' ),
				'code'  => '',
			),
			array(
				'title' => __( 'Decrypt the files if encryption was on', 'mvweb-backup' ),
				'text'  => __( 'Encrypted files end with .enc. Run the commands with PHP 8.2 or newer. After the first command paste the secret key and press Enter: it is not shown and does not stay in the command history. Run the second command for each file with your file names; the output file must not exist yet. If a file is damaged, nothing is left behind.', 'mvweb-backup' ),
				'code'  => mvweb_bk_decrypt_command(),
			),
			array(
				'title' => __( 'Import the database', 'mvweb-backup' ),
				'text'  => __( 'Create an empty database, then import the dump. If MariaDB reports an unknown collation utf8mb4_0900_ai_ci, replace it with utf8mb4_unicode_520_ci in the dump first.', 'mvweb-backup' ),
				'code'  => 'gunzip -c database.sql.gz | mysql --binary-mode -u DB_USER -p DB_NAME',
			),
			array(
				'title' => __( 'Install WordPress and create wp-config.php', 'mvweb-backup' ),
				'text'  => __( 'The manifest shows the WordPress and PHP versions of the backup. If its WordPress version differs from the command, use the version from the manifest. Keep the table prefix below, it matches the dump. If WP-CLI runs out of memory, run it as php -d memory_limit=1G and the path to wp. If the database password has a double quote, open wp-config.php and remove the backslash WP-CLI puts before it.', 'mvweb-backup' ),
				'code'  => 'wp core download --version=' . get_bloginfo( 'version' ) . ' --locale=' . get_locale() . " --skip-content\nwp config create --dbname=DB_NAME --dbuser=DB_USER --prompt=dbpass --dbprefix=" . $wpdb->prefix,
			),
			array(
				'title' => __( 'Put the files back', 'mvweb-backup' ),
				'text'  => __( 'Unpack the code archive into the site root: it holds wp-content without uploads, and the site files from the root. Unpack every uploads archive into wp-content/uploads. Delete the manifest file from the site root. Check .user.ini in the site root: a path of the old server in it stops the site. A code archive made by version 1.0.0 holds themes, plugins and .htaccess: unpack its folders into wp-content and .htaccess into the site root.', 'mvweb-backup' ),
				'code'  => '',
			),
			array(
				'title' => __( 'Move the constants', 'mvweb-backup' ),
				'text'  => __( 'With encryption on, the archive holds wp-config.saved.php without the database password, salts and backup token. Move it out of the site root, copy the constants you need into wp-config.php and delete it. Without encryption, the manifest lists the constant names only. If the site was hacked, replace all keys and tokens.', 'mvweb-backup' ),
				'code'  => '',
			),
			array(
				'title' => __( 'Replace the old server path and address', 'mvweb-backup' ),
				'text'  => __( 'If the domain stays the same, run only the last two commands: they replace the old server path. Skip them if the path also stays the same. If the domain changes, run all the commands in this order, with the new domain and the full new path to the site. Stop if the new domain starts with www and the old domain and goes on, for example www.old.example.com: the second pass would double it. Email addresses stay unchanged, set the sender of site emails by hand. Replace the domain in .htaccess and robots.txt, and rebuild product feeds.', 'mvweb-backup' ),
				'code'  => implode( "\n", $replace ),
			),
			array(
				'title' => __( 'Finish and check', 'mvweb-backup' ),
				'text'  => __( 'Thumbnails are not backed up, these commands create them again. Then open the site and the admin area.', 'mvweb-backup' ),
				'code'  => "wp rewrite flush\nwp media regenerate --only-missing --skip-delete --yes",
			),
			array(
				'title' => __( 'Turn the backups on again', 'mvweb-backup' ),
				'text'  => __( 'Revoke the token of the old server: if the old server comes back, its backups push out the new ones. Create a new token, add it to wp-config.php and add the cron command from the plugin settings. Recreate the other cron tasks of the site.', 'mvweb-backup' ),
				'code'  => '',
			),
		);
	}

	/**
	 * README of the backup repository, so the steps are at hand when the site is down.
	 *
	 * @since 1.1.0
	 * @return string Markdown.
	 */
	public static function readme(): string {
		/* translators: %s: site address */
		$text = '# ' . sprintf( __( 'Backup of %s', 'mvweb-backup' ), home_url() ) . "\n\n";

		foreach ( self::restore_steps() as $number => $step ) {
			$text .= '## ' . ( $number + 1 ) . '. ' . $step['title'] . "\n\n" . $step['text'] . "\n\n";

			if ( '' !== $step['code'] ) {
				$text .= "```\n" . $step['code'] . "\n```\n\n";
			}
		}

		return $text;
	}
}
