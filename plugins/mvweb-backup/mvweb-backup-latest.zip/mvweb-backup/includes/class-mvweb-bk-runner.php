<?php
/**
 * Backup run: makes each part and sends it to GitHub.
 *
 * Loaded by cli.php only.
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messages go to the CLI and the run log, escaped where shown.

/**
 * Backup runner.
 *
 * @since 1.0.0
 */
final class MVweb_BK_Runner {

	/**
	 * Releases kept per part. Older ones are deleted with their tags.
	 */
	const KEEP = 2;

	/**
	 * GitHub release assets are limited to 2 GiB.
	 */
	const MAX_ASSET = 2147483648;

	/**
	 * Run the given parts.
	 *
	 * @since 1.0.0
	 * @param string[] $parts Part keys.
	 * @return array<int, array{part: string, ok: bool, message: string, size: int}>
	 */
	public static function run( array $parts ): array {
		$started = microtime( true );
		$results = self::run_parts( $parts );
		$errors  = array();
		$size    = 0;

		foreach ( $results as $result ) {
			$size += $result['size'];

			if ( ! $result['ok'] ) {
				$errors[] = ( '' !== $result['part'] ? $result['part'] . ': ' : '' ) . $result['message'];
			}
		}

		$error = implode( "\n", $errors );

		mvweb_bk_add_log(
			array(
				'time'     => time(),
				'parts'    => $parts,
				'size'     => $size,
				'duration' => (int) round( microtime( true ) - $started ),
				'error'    => $error,
			)
		);

		self::alert( $error, $parts );

		return $results;
	}

	/**
	 * Make each part.
	 *
	 * @since 1.0.0
	 * @param string[] $parts Part keys.
	 * @return array<int, array{part: string, ok: bool, message: string, size: int}>
	 */
	private static function run_parts( array $parts ): array {
		$repo = (string) mvweb_bk_get_settings()['repo'];

		if ( ! mvweb_bk_token_is_set() || '' === $repo ) {
			return array(
				array(
					'part'    => '',
					'ok'      => false,
					'message' => __( 'The token or the repository is not set.', 'mvweb-backup' ),
					'size'    => 0,
				),
			);
		}

		$api     = new MVweb_BK_GitHub( $repo, (string) constant( 'MVWEB_BK_GITHUB_TOKEN' ) );
		$results = array();
		$denied  = self::repository_error( $api );

		if ( '' !== $denied ) {
			return array(
				array(
					'part'    => '',
					'ok'      => false,
					'message' => $denied,
					'size'    => 0,
				),
			);
		}

		foreach ( $parts as $part ) {
			$result = array(
				'part'    => $part,
				'ok'      => false,
				'message' => '',
				'size'    => 0,
			);

			try {
				if ( 'db' === $part ) {
					$done = self::db( $api );
				} elseif ( 'code' === $part ) {
					$done = self::code( $api );
				} else {
					$done = MVweb_BK_Uploads::run( $api );
				}

				$result = array_merge( $result, $done, array( 'ok' => true ) );
			} catch ( Throwable $e ) {
				$result['message'] = $e->getMessage();
			}

			$results[] = $result;
		}

		return $results;
	}

	/**
	 * Check that the repository is reachable and private before anything is uploaded.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api Client.
	 * @return string Empty when the backup may go on, otherwise the reason.
	 */
	private static function repository_error( MVweb_BK_GitHub $api ): string {
		$response = $api->request( 'GET' );

		if ( is_wp_error( $response ) ) {
			/* translators: %s: error message */
			return sprintf( __( 'GitHub did not answer: %s', 'mvweb-backup' ), $response->get_error_message() );
		}

		if ( 401 === $response['code'] ) {
			return __( 'GitHub rejected the token. It is wrong or has expired.', 'mvweb-backup' );
		}

		if ( 403 === $response['code'] || 404 === $response['code'] ) {
			return __( 'The repository was not found, or the token has no access to it. Check owner/name and the repository access of the token.', 'mvweb-backup' );
		}

		if ( 200 !== $response['code'] || ! is_array( $response['data'] ) ) {
			/* translators: %d: HTTP status code */
			return sprintf( __( 'Unexpected GitHub answer: HTTP %d.', 'mvweb-backup' ), $response['code'] );
		}

		if ( true !== ( $response['data']['private'] ?? null ) ) {
			return __( 'The repository is public. Make it private: backups contain the site database.', 'mvweb-backup' );
		}

		return '';
	}

	/**
	 * Report a failed run once, then at most once a day, then report recovery.
	 *
	 * Each set of parts (one cron line) has its own state, so a passing
	 * database run does not hide a failing uploads run.
	 * The state changes only when a message was delivered, so a broken channel
	 * retries on the next run instead of losing the alert.
	 *
	 * @since 1.0.0
	 * @param string   $error Errors of this run, empty on success.
	 * @param string[] $parts Parts of this run.
	 * @return void
	 */
	private static function alert( string $error, array $parts ): void {
		$states = get_option( 'mvweb_bk_alert_state', array() );
		$states = is_array( $states ) ? $states : array();
		$key    = implode( ',', array_intersect( mvweb_bk_parts(), $parts ) );
		$state  = isset( $states[ $key ] ) && is_array( $states[ $key ] ) ? $states[ $key ] : array();
		$first  = (int) ( $state['first_failure'] ?? 0 );
		$last   = (int) ( $state['last_alert'] ?? 0 );
		$now    = time();
		$site   = wp_parse_url( home_url(), PHP_URL_HOST );
		$site   = is_string( $site ) ? $site : home_url();
		/* translators: %s: comma-separated backup parts, for example db,uploads */
		$scope = sprintf( __( 'Parts: %s', 'mvweb-backup' ), $key );

		if ( '' === $error ) {
			if ( $first && self::send(
				/* translators: %s: site domain */
				sprintf( __( 'Backup of %s works again', 'mvweb-backup' ), $site ),
				/* translators: %s: date and time of the first failure */
				$scope . "\n" . sprintf( __( 'Failed since %s.', 'mvweb-backup' ), wp_date( 'Y-m-d H:i', $first ) )
			) ) {
				unset( $states[ $key ] );
				self::save_alert_states( $states );
			}

			return;
		}

		if ( $first && $now - $last < DAY_IN_SECONDS ) {
			return;
		}

		$text = $first
			/* translators: %s: date and time of the first failure */
			? sprintf( __( 'Still failing, since %s.', 'mvweb-backup' ), wp_date( 'Y-m-d H:i', $first ) ) . "\n\n" . $error
			: $error;

		/* translators: %s: site domain */
		if ( self::send( sprintf( __( 'Backup of %s failed', 'mvweb-backup' ), $site ), $scope . "\n" . $text ) ) {
			$states[ $key ] = array(
				'first_failure' => $first ? $first : $now,
				'last_alert'    => $now,
			);
			self::save_alert_states( $states );
		}
	}

	/**
	 * Store the alert states, or remove the option when nothing is failing.
	 *
	 * @since 1.0.0
	 * @param array<string, array{first_failure: int, last_alert: int}> $states Parts key => state.
	 * @return void
	 */
	private static function save_alert_states( array $states ): void {
		if ( $states ) {
			update_option( 'mvweb_bk_alert_state', $states, false );
		} else {
			delete_option( 'mvweb_bk_alert_state' );
		}
	}

	/**
	 * Send an alert to Telegram through MVweb Telegram Hub, otherwise by email.
	 *
	 * @since 1.0.0
	 * @param string $subject Short title.
	 * @param string $text    Message.
	 * @return bool Whether a channel accepted the message.
	 */
	private static function send( string $subject, string $text ): bool {
		if ( function_exists( 'mvweb_tg_notify_operators' ) && mvweb_tg_notify_operators( $subject . "\n\n" . $text ) ) {
			return true;
		}

		$to = (string) mvweb_bk_get_settings()['alert_email'];

		return wp_mail( '' !== $to ? $to : (string) get_option( 'admin_email' ), $subject, $text );
	}

	/**
	 * Dump the database and publish it as a release asset.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api Client.
	 * @return array{message: string, size: int}
	 * @throws RuntimeException On failure.
	 */
	private static function db( MVweb_BK_GitHub $api ): array {
		$file = MVweb_BK_DB::temp_file();

		try {
			$method = MVweb_BK_DB::dump( $file );
			$size   = (int) filesize( $file );
			$tag    = self::publish( $api, 'db', $file, '.sql.gz', 'application/gzip' );
		} finally {
			wp_delete_file( $file );
		}

		return array(
			'message' => $tag . ', ' . size_format( $size, 1 ) . ', ' . $method,
			'size'    => $size,
		);
	}

	/**
	 * Archive the ticked themes and plugins and .htaccess, publish as a release asset.
	 *
	 * Paths in the archive: themes/{slug}/…, plugins/{folder}/…, .htaccess.
	 * Version control folders and node_modules are left out.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api Client.
	 * @return array{message: string, size: int}
	 * @throws RuntimeException On failure.
	 */
	private static function code( MVweb_BK_GitHub $api ): array {
		$settings = mvweb_bk_get_settings();

		if ( ! class_exists( 'ZipArchive' ) ) {
			throw new RuntimeException( __( 'The zip PHP extension is not available.', 'mvweb-backup' ) );
		}

		$sources = array();

		foreach ( (array) $settings['themes'] as $slug ) {
			$theme = wp_get_theme( (string) $slug );

			if ( $theme->exists() ) {
				$sources[ 'themes/' . $theme->get_stylesheet() ] = $theme->get_stylesheet_directory();
			}
		}

		foreach ( (array) $settings['plugins'] as $plugin ) {
			$path = WP_PLUGIN_DIR . '/' . (string) $plugin;

			if ( false !== strpos( (string) $plugin, '/' ) ) {
				if ( is_dir( dirname( $path ) ) ) {
					$sources[ 'plugins/' . dirname( (string) $plugin ) ] = dirname( $path );
				}
			} elseif ( is_file( $path ) ) {
				$sources[ 'plugins/' . (string) $plugin ] = $path;
			}
		}

		if ( ! $sources ) {
			throw new RuntimeException( __( 'No themes or plugins are ticked in the settings.', 'mvweb-backup' ) );
		}

		$file = MVweb_BK_DB::temp_file();
		$zip  = null;

		try {
			$zip = new ZipArchive();

			if ( true !== $zip->open( $file, ZipArchive::OVERWRITE ) ) {
				throw new RuntimeException( __( 'The archive cannot be created.', 'mvweb-backup' ) );
			}

			foreach ( $sources as $target => $source ) {
				self::zip_path( $zip, $source, $target );
			}

			if ( is_file( ABSPATH . '.htaccess' ) ) {
				$zip->addFile( ABSPATH . '.htaccess', '.htaccess' );
			}

			// From here the destructor has nothing to write: close() ends the archive either way.
			$open = $zip;
			$zip  = null;

			if ( ! $open->close() ) {
				/* translators: %s: error from the zip library, for example a missing file or a full disk */
				throw new RuntimeException( sprintf( __( 'The archive cannot be written: %s', 'mvweb-backup' ), $open->getStatusString() ) );
			}

			clearstatcache( true, $file );
			$size = (int) filesize( $file );
			$tag  = self::publish( $api, 'code', $file, '.zip', 'application/zip' );
		} finally {
			// An archive left open by an error would be written again by its destructor.
			if ( $zip instanceof ZipArchive ) {
				$zip->unchangeAll();
			}

			wp_delete_file( $file );
		}

		return array(
			'message' => $tag . ', ' . size_format( $size, 1 ) . ', ' . implode( ', ', array_keys( $sources ) ),
			'size'    => $size,
		);
	}

	/**
	 * Add a file or a folder tree to the archive.
	 *
	 * @since 1.0.0
	 * @param ZipArchive $zip    Open archive.
	 * @param string     $source File or folder on disk.
	 * @param string     $target Path inside the archive.
	 * @return void
	 * @throws RuntimeException When a file cannot be added. A folder that cannot be read throws UnexpectedValueException.
	 */
	private static function zip_path( ZipArchive $zip, string $source, string $target ): void {
		if ( is_file( $source ) ) {
			if ( ! $zip->addFile( $source, $target ) ) {
				/* translators: %s: file path */
				throw new RuntimeException( sprintf( __( 'The file %s cannot be read.', 'mvweb-backup' ), $target ) );
			}

			return;
		}

		$iterator = new RecursiveIteratorIterator(
			new RecursiveCallbackFilterIterator(
				new RecursiveDirectoryIterator( $source, FilesystemIterator::SKIP_DOTS ),
				static fn( SplFileInfo $item ): bool => ! $item->isLink() && ! in_array( $item->getFilename(), array( '.git', '.svn', 'node_modules' ), true )
			)
		);

		foreach ( $iterator as $item ) {
			if ( ! $item->isFile() ) {
				continue;
			}

			$name = $target . '/' . str_replace( '\\', '/', substr( $item->getPathname(), strlen( $source ) + 1 ) );

			if ( ! $zip->addFile( $item->getPathname(), $name ) ) {
				/* translators: %s: file path */
				throw new RuntimeException( sprintf( __( 'The file %s cannot be read.', 'mvweb-backup' ), $name ) );
			}
		}
	}

	/**
	 * Publish a part, encrypted first when encryption is on.
	 *
	 * An encrypted file gets ".enc" added to its name.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api       Client.
	 * @param string          $part      Part key, also the tag prefix.
	 * @param string          $file      Path to the file.
	 * @param string          $extension Asset extension with the leading dot.
	 * @param string          $type      Content type.
	 * @return string Tag of the new release.
	 * @throws RuntimeException On failure.
	 */
	private static function publish( MVweb_BK_GitHub $api, string $part, string $file, string $extension, string $type ): string {
		$settings = mvweb_bk_get_settings();

		if ( empty( $settings['encrypt'] ) ) {
			return self::publish_file( $api, $part, $file, $extension, $type );
		}

		$encrypted = MVweb_BK_DB::temp_file();

		try {
			MVweb_BK_Crypto::encrypt_file( $file, $encrypted, (string) $settings['public_key'] );

			return self::publish_file( $api, $part, $encrypted, $extension . '.enc', 'application/octet-stream' );
		} finally {
			wp_delete_file( $encrypted );
		}
	}

	/**
	 * Create a release for one part, attach the file, delete older releases.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api       Client.
	 * @param string          $part      Part key, also the tag prefix.
	 * @param string          $file      Path to the file.
	 * @param string          $extension Asset extension with the leading dot.
	 * @param string          $type      Content type.
	 * @return string Tag of the new release.
	 * @throws RuntimeException On failure.
	 */
	private static function publish_file( MVweb_BK_GitHub $api, string $part, string $file, string $extension, string $type ): string {
		$size = (int) filesize( $file );

		if ( $size <= 0 ) {
			throw new RuntimeException( __( 'The backup file is empty.', 'mvweb-backup' ) );
		}

		if ( $size >= self::MAX_ASSET ) {
			throw new RuntimeException( __( 'The backup file is larger than the 2 GiB GitHub limit.', 'mvweb-backup' ) );
		}

		$tag     = $part . '-' . gmdate( 'Ymd-His' );
		$release = $api->request(
			'POST',
			'/releases',
			array(
				'tag_name'    => $tag,
				'name'        => $tag,
				'body'        => home_url() . "\n" . size_format( $size, 1 ),
				'make_latest' => 'false',
			)
		);

		if ( is_wp_error( $release ) ) {
			/* translators: %s: error message */
			throw new RuntimeException( sprintf( __( 'GitHub release was not created: %s', 'mvweb-backup' ), $release->get_error_message() ) );
		}

		if ( 201 !== $release['code'] || empty( $release['data']['id'] ) ) {
			/* translators: %s: error message */
			throw new RuntimeException( sprintf( __( 'GitHub release was not created: %s', 'mvweb-backup' ), 'HTTP ' . $release['code'] . ' ' . (string) ( $release['data']['message'] ?? '' ) ) );
		}

		try {
			$uploaded = $api->upload_asset( (string) $release['data']['upload_url'], $file, $tag . $extension, $type );
		} catch ( Throwable $e ) {
			$uploaded = new WP_Error( 'mvweb_bk_upload', $e->getMessage() );
		}

		if ( is_wp_error( $uploaded ) ) {
			self::delete_release( $api, (int) $release['data']['id'], $tag );

			/* translators: %s: error message */
			throw new RuntimeException( sprintf( __( 'The file was not uploaded to GitHub: %s', 'mvweb-backup' ), $uploaded->get_error_message() ) );
		}

		self::prune( $api, $part, $tag );

		return $tag;
	}

	/**
	 * Keep the new release and the newest KEEP-1 other releases with a file.
	 *
	 * Only tags made by this plugin ("{part}-YYYYMMDD-HHMMSS") are touched.
	 * Releases left without a file by an interrupted run are deleted and never
	 * count as a kept backup.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api     Client.
	 * @param string          $part    Part key.
	 * @param string          $current Tag of the release just uploaded.
	 * @return void
	 * @throws RuntimeException When the list cannot be read or a release cannot be deleted.
	 */
	private static function prune( MVweb_BK_GitHub $api, string $part, string $current ): void {
		$list = $api->request( 'GET', '/releases?per_page=100' );

		if ( is_wp_error( $list ) || 200 !== $list['code'] || ! is_array( $list['data'] ) ) {
			throw new RuntimeException( __( 'The backup is uploaded, but old backups were not removed: GitHub did not return the release list.', 'mvweb-backup' ) );
		}

		$full   = array();
		$delete = array();

		foreach ( $list['data'] as $release ) {
			$tag = (string) ( $release['tag_name'] ?? '' );

			if ( $current === $tag || ! preg_match( '/^' . preg_quote( $part, '/' ) . '-\d{8}-\d{6}$/', $tag ) ) {
				continue;
			}

			// A file cut off by an interrupted upload is not "uploaded" and does not make a backup.
			$files = array_filter(
				(array) ( $release['assets'] ?? array() ),
				static fn( $asset ): bool => is_array( $asset ) && 'uploaded' === ( $asset['state'] ?? 'uploaded' )
			);

			if ( ! $files ) {
				$delete[ $tag ] = (int) $release['id'];
			} else {
				$full[ $tag ] = (int) $release['id'];
			}
		}

		krsort( $full, SORT_STRING );

		$delete += array_slice( $full, self::KEEP - 1, null, true );

		foreach ( $delete as $tag => $id ) {
			$reason = self::delete_release( $api, $id, (string) $tag );

			if ( '' !== $reason ) {
				/* translators: %s: release tag */
				throw new RuntimeException( sprintf( __( 'The backup is uploaded, but the old backup %s was not removed.', 'mvweb-backup' ), $tag ) . ' ' . $reason );
			}
		}
	}

	/**
	 * Delete a release and its tag.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api Client.
	 * @param int             $id  Release ID.
	 * @param string          $tag Tag name.
	 * @return string Empty when both were deleted (or already gone), otherwise the reason.
	 */
	private static function delete_release( MVweb_BK_GitHub $api, int $id, string $tag ): string {
		// The tag goes only after the release: a release without its tag turns into a draft.
		foreach ( array( '/releases/' . $id, '/git/refs/tags/' . rawurlencode( $tag ) ) as $path ) {
			$response = $api->request( 'DELETE', $path );

			if ( is_wp_error( $response ) ) {
				return $response->get_error_message();
			}

			if ( ! in_array( $response['code'], array( 204, 404, 422 ), true ) ) {
				return 'HTTP ' . $response['code'] . ' ' . (string) ( $response['data']['message'] ?? '' );
			}
		}

		return '';
	}
}
