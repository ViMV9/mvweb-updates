<?php
/**
 * Backup run: makes each part and sends it to GitHub.
 *
 * Loaded by cli.php and by the hourly WP-Cron check.
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messages go to the CLI and the run log, escaped where shown.

/**
 * Backup runner.
 *
 * @since 1.0.0
 */
final class MVweb_BK_Runner {

	/**
	 * Releases kept per part. Older ones are deleted with their tags.
	 */
	const KEEP = array(
		'db'   => 30,
		'code' => 5,
	);

	/**
	 * GitHub release assets are limited to 2 GiB.
	 */
	const MAX_ASSET = 2147483648;

	/**
	 * Run the given parts.
	 *
	 * @since 1.0.0
	 * @param string[] $parts Part keys.
	 * @return array<int, array{part: string, ok: bool, message: string, size: int}>
	 */
	public static function run( array $parts ): array {
		$started = microtime( true );
		$results = self::run_parts( $parts );
		$errors  = array();
		$size    = 0;
		$last    = mvweb_bk_last_success();
		$labels  = mvweb_bk_part_labels();

		foreach ( $results as $result ) {
			$size += $result['size'];

			if ( ! $result['ok'] ) {
				$errors[] = ( '' !== $result['part'] ? ( $labels[ $result['part'] ] ?? $result['part'] ) . ': ' : '' ) . $result['message'];
			} elseif ( '' !== $result['part'] ) {
				$last[ $result['part'] ] = time();
			}
		}

		update_option( 'mvweb_bk_last_success', $last, false );

		$error = implode( "\n", $errors );

		mvweb_bk_add_log(
			array(
				'time'     => time(),
				'parts'    => $parts,
				'size'     => $size,
				'duration' => (int) round( microtime( true ) - $started ),
				'error'    => $error,
			)
		);

		self::alert( $error, $parts );

		return $results;
	}

	/**
	 * Alert when a scheduled backup is late, which means the server cron stopped.
	 *
	 * Runs on WP-Cron. Parts are checked in the groups of their cron lines, so the
	 * next successful run of a line clears the alert.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function check_late(): void {
		if ( ! mvweb_bk_token_is_set() || '' === (string) mvweb_bk_get_settings()['repo'] ) {
			return;
		}

		$late   = mvweb_bk_late_parts();
		$labels = mvweb_bk_part_labels();

		foreach ( mvweb_bk_schedule_groups() as $parts ) {
			$lines = array();

			foreach ( array_intersect( $parts, array_keys( $late ) ) as $part ) {
				/* translators: 1: backup part, 2: date and time */
				$lines[] = sprintf( __( '%1$s: the last successful backup was on %2$s.', 'mvweb-backup' ), $labels[ $part ], wp_date( 'Y-m-d H:i', $late[ $part ] ) );
			}

			if ( $lines ) {
				self::alert( implode( "\n", $lines ) . "\n" . __( 'The backup is late. Check the cron task on the server.', 'mvweb-backup' ), $parts );
			}
		}
	}

	/**
	 * Make each part.
	 *
	 * @since 1.0.0
	 * @param string[] $parts Part keys.
	 * @return array<int, array{part: string, ok: bool, message: string, size: int}>
	 */
	private static function run_parts( array $parts ): array {
		$repo = (string) mvweb_bk_get_settings()['repo'];

		if ( ! mvweb_bk_token_is_set() || '' === $repo ) {
			return array(
				array(
					'part'    => '',
					'ok'      => false,
					'message' => __( 'The token or the repository is not set.', 'mvweb-backup' ),
					'size'    => 0,
				),
			);
		}

		$api     = new MVweb_BK_GitHub( $repo, (string) constant( 'MVWEB_BK_GITHUB_TOKEN' ) );
		$results = array();
		$denied  = self::repository_error( $api );

		if ( '' !== $denied ) {
			return array(
				array(
					'part'    => '',
					'ok'      => false,
					'message' => $denied,
					'size'    => 0,
				),
			);
		}

		foreach ( $parts as $part ) {
			$result = array(
				'part'    => $part,
				'ok'      => false,
				'message' => '',
				'size'    => 0,
			);

			try {
				if ( 'db' === $part ) {
					$done = self::db( $api );
				} elseif ( 'code' === $part ) {
					$done = self::code( $api );
				} else {
					$done = MVweb_BK_Uploads::run( $api );
				}

				$result = array_merge( $result, $done, array( 'ok' => true ) );
			} catch ( Throwable $e ) {
				$result['message'] = $e->getMessage();
			}

			$results[] = $result;
		}

		foreach ( self::write_restore_files( $api, $repo ) as $file => $reason ) {
			$results[] = array(
				'part'    => '',
				'ok'      => false,
				/* translators: 1: file name, 2: error message */
				'message' => sprintf( __( 'The file %1$s was not written to the repository: %2$s', 'mvweb-backup' ), $file, $reason ),
				'size'    => 0,
			);
		}

		return $results;
	}

	/**
	 * Keep the restore instructions and the restore script in the backup repository.
	 *
	 * They change only with the plugin version or the site address, path or
	 * language, so this usually makes no request. A failure is reported and
	 * retried on the next run.
	 *
	 * @since 1.1.0
	 * @param MVweb_BK_GitHub $api  Client.
	 * @param string          $repo Repository.
	 * @return array<string, string> File => reason, for the files not written.
	 */
	private static function write_restore_files( MVweb_BK_GitHub $api, string $repo ): array {
		$saved  = get_option( 'mvweb_bk_repo_files', array() );
		$saved  = is_array( $saved ) ? $saved : array();
		$errors = array();
		$files  = array(
			'README.md'   => MVweb_BK_Site::readme(),
			'restore.php' => (string) file_get_contents( MVWEB_BK_PATH . 'restore.php' ), // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local file.
		);

		foreach ( $files as $file => $text ) {
			$hash = md5( $repo . "\n" . $text );

			if ( ( $saved[ $file ] ?? '' ) === $hash ) {
				continue;
			}

			$reason = '' !== $text ? self::write_repo_file( $api, $file, $text ) : __( 'The file cannot be read.', 'mvweb-backup' );

			if ( '' !== $reason ) {
				$errors[ $file ] = $reason;
				continue;
			}

			$saved[ $file ] = $hash;
			update_option( 'mvweb_bk_repo_files', $saved, false );
		}

		return $errors;
	}

	/**
	 * Create or replace a file in the backup repository.
	 *
	 * @since 1.1.0
	 * @param MVweb_BK_GitHub $api  Client.
	 * @param string          $file Path in the repository.
	 * @param string          $text File contents.
	 * @return string Empty on success, otherwise the reason.
	 */
	private static function write_repo_file( MVweb_BK_GitHub $api, string $file, string $text ): string {
		$current = $api->request( 'GET', '/contents/' . $file );

		if ( is_wp_error( $current ) ) {
			return $current->get_error_message();
		}

		if ( 200 !== $current['code'] && 404 !== $current['code'] ) {
			return 'HTTP ' . $current['code'];
		}

		$body = array(
			'message' => 'Update restore instructions',
			'content' => base64_encode( $text ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- the GitHub contents API takes base64.
		);

		if ( 200 === $current['code'] ) {
			$body['sha'] = (string) ( $current['data']['sha'] ?? '' );
		}

		$saved = $api->request( 'PUT', '/contents/' . $file, $body );

		if ( is_wp_error( $saved ) ) {
			return $saved->get_error_message();
		}

		if ( ! in_array( $saved['code'], array( 200, 201 ), true ) ) {
			return 'HTTP ' . $saved['code'] . ' ' . (string) ( $saved['data']['message'] ?? '' );
		}

		return '';
	}

	/**
	 * Check that the repository is reachable and private before anything is uploaded.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api Client.
	 * @return string Empty when the backup may go on, otherwise the reason.
	 */
	private static function repository_error( MVweb_BK_GitHub $api ): string {
		$response = $api->request( 'GET' );

		if ( is_wp_error( $response ) ) {
			/* translators: %s: error message */
			return sprintf( __( 'GitHub did not answer: %s', 'mvweb-backup' ), $response->get_error_message() );
		}

		if ( 401 === $response['code'] ) {
			return __( 'GitHub rejected the token. It is wrong or has expired.', 'mvweb-backup' );
		}

		if ( 403 === $response['code'] || 404 === $response['code'] ) {
			return __( 'The repository was not found, or the token has no access to it. Check owner/name and the repository access of the token.', 'mvweb-backup' );
		}

		if ( 200 !== $response['code'] || ! is_array( $response['data'] ) ) {
			/* translators: %d: HTTP status code */
			return sprintf( __( 'Unexpected GitHub answer: HTTP %d.', 'mvweb-backup' ), $response['code'] );
		}

		if ( true !== ( $response['data']['private'] ?? null ) ) {
			return __( 'The repository is public. Make it private: backups contain the site database.', 'mvweb-backup' );
		}

		return '';
	}

	/**
	 * Report a failed run once, then at most once a day, then report recovery.
	 *
	 * Each set of parts (one cron line) has its own state, so a passing
	 * database run does not hide a failing uploads run.
	 * The state changes only when a message was delivered, so a broken channel
	 * retries on the next run instead of losing the alert.
	 *
	 * @since 1.0.0
	 * @param string   $error Errors of this run, empty on success.
	 * @param string[] $parts Parts of this run.
	 * @return void
	 */
	private static function alert( string $error, array $parts ): void {
		$states = get_option( 'mvweb_bk_alert_state', array() );
		$states = is_array( $states ) ? $states : array();
		$key    = implode( ',', array_intersect( mvweb_bk_parts(), $parts ) );
		$state  = isset( $states[ $key ] ) && is_array( $states[ $key ] ) ? $states[ $key ] : array();
		$first  = (int) ( $state['first_failure'] ?? 0 );
		$last   = (int) ( $state['last_alert'] ?? 0 );
		$now    = time();
		$site   = wp_parse_url( home_url(), PHP_URL_HOST );
		$site   = is_string( $site ) ? $site : home_url();
		/* translators: %s: comma-separated backup parts, for example Database, Uploads */
		$scope = sprintf( __( 'Parts: %s', 'mvweb-backup' ), implode( ', ', array_intersect_key( mvweb_bk_part_labels(), array_flip( explode( ',', $key ) ) ) ) );

		if ( '' === $error ) {
			if ( $first && self::send(
				/* translators: %s: site domain */
				sprintf( __( 'Backup of %s works again', 'mvweb-backup' ), $site ),
				/* translators: %s: date and time of the first failure */
				$scope . "\n" . sprintf( __( 'Failed since %s.', 'mvweb-backup' ), wp_date( 'Y-m-d H:i', $first ) )
			) ) {
				unset( $states[ $key ] );
				self::save_alert_states( $states );
			}

			return;
		}

		if ( $first && $now - $last < DAY_IN_SECONDS ) {
			return;
		}

		$text = $first
			/* translators: %s: date and time of the first failure */
			? sprintf( __( 'Still failing, since %s.', 'mvweb-backup' ), wp_date( 'Y-m-d H:i', $first ) ) . "\n\n" . $error
			: $error;

		/* translators: %s: site domain */
		if ( self::send( sprintf( __( 'Backup of %s failed', 'mvweb-backup' ), $site ), $scope . "\n" . $text ) ) {
			$states[ $key ] = array(
				'first_failure' => $first ? $first : $now,
				'last_alert'    => $now,
			);
			self::save_alert_states( $states );
		}
	}

	/**
	 * Store the alert states, or remove the option when nothing is failing.
	 *
	 * @since 1.0.0
	 * @param array<string, array{first_failure: int, last_alert: int}> $states Parts key => state.
	 * @return void
	 */
	private static function save_alert_states( array $states ): void {
		if ( $states ) {
			update_option( 'mvweb_bk_alert_state', $states, false );
		} else {
			delete_option( 'mvweb_bk_alert_state' );
		}
	}

	/**
	 * Send an alert to Telegram through MVweb Telegram Hub, otherwise by email.
	 *
	 * @since 1.0.0
	 * @param string $subject Short title.
	 * @param string $text    Message.
	 * @return bool Whether a channel accepted the message.
	 */
	private static function send( string $subject, string $text ): bool {
		if ( function_exists( 'mvweb_tg_notify_operators' ) && mvweb_tg_notify_operators( $subject . "\n\n" . $text ) ) {
			return true;
		}

		$to = (string) mvweb_bk_get_settings()['alert_email'];

		return wp_mail( '' !== $to ? $to : (string) get_option( 'admin_email' ), $subject, $text );
	}

	/**
	 * Dump the database and publish it as a release asset.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api Client.
	 * @return array{message: string, size: int}
	 * @throws RuntimeException On failure.
	 */
	private static function db( MVweb_BK_GitHub $api ): array {
		$file     = MVweb_BK_DB::temp_file();
		$manifest = MVweb_BK_DB::temp_file();

		try {
			// Counted before the dump: rows added meanwhile can only make the dump larger.
			if ( ! file_put_contents( $manifest, MVweb_BK_Site::manifest_json() ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- temporary file.
				throw new RuntimeException( __( 'The manifest cannot be written. The disk may be full.', 'mvweb-backup' ) );
			}

			$method = MVweb_BK_DB::dump( $file );
			$size   = (int) filesize( $file );
			$tag    = self::publish( $api, 'db', $file, '.sql.gz', 'application/gzip', $manifest );
		} finally {
			wp_delete_file( $file );
			wp_delete_file( $manifest );
		}

		return array(
			'message' => $tag . ', ' . size_format( $size, 1 ) . ', ' . $method,
			'size'    => $size,
		);
	}

	/**
	 * Archive wp-content without uploads and the site files from the root.
	 *
	 * Paths in the archive are relative to the site root. Folders that cannot be
	 * read do not stop the backup: the rest is uploaded and the run reports them.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api Client.
	 * @return array{message: string, size: int}
	 * @throws RuntimeException On failure.
	 */
	private static function code( MVweb_BK_GitHub $api ): array {
		if ( ! class_exists( 'ZipArchive' ) ) {
			throw new RuntimeException( __( 'The zip PHP extension is not available.', 'mvweb-backup' ) );
		}

		$problems = array();
		$content  = MVweb_BK_Site::content_files( $problems );
		$root     = MVweb_BK_Site::root_files();

		if ( $problems ) {
			/* translators: %s: list of folders */
			$problems = array( sprintf( __( 'These folders cannot be read and were not backed up: %s', 'mvweb-backup' ), implode( ', ', $problems ) ) );
		}

		$file = MVweb_BK_DB::temp_file();
		$zip  = null;

		try {
			$zip = new ZipArchive();

			if ( true !== $zip->open( $file, ZipArchive::OVERWRITE ) ) {
				throw new RuntimeException( __( 'The archive cannot be created.', 'mvweb-backup' ) );
			}

			foreach ( $content as $relative ) {
				self::zip_file( $zip, WP_CONTENT_DIR . '/' . $relative, 'wp-content/' . $relative );
			}

			foreach ( $root as $name ) {
				self::zip_file( $zip, ABSPATH . $name, $name );
			}

			$zip->addFromString( MVweb_BK_Site::MANIFEST, MVweb_BK_Site::manifest_json() );

			if ( ! empty( mvweb_bk_get_settings()['encrypt'] ) ) {
				$saved = MVweb_BK_Site::saved_config();

				if ( null === $saved ) {
					$problems[] = __( 'The wp-config.php copy was left out: the file cannot be read, or the backup token could not be removed from it.', 'mvweb-backup' );
				} else {
					$zip->addFromString( MVweb_BK_Site::SAVED_CONFIG, $saved );
				}
			}

			// From here the destructor has nothing to write: close() ends the archive either way.
			$open = $zip;
			$zip  = null;

			if ( ! $open->close() ) {
				/* translators: %s: error from the zip library, for example a missing file or a full disk */
				throw new RuntimeException( sprintf( __( 'The archive cannot be written: %s', 'mvweb-backup' ), $open->getStatusString() ) );
			}

			clearstatcache( true, $file );
			$size = (int) filesize( $file );
			$tag  = self::publish( $api, 'code', $file, '.zip', 'application/zip' );
		} finally {
			// An archive left open by an error would be written again by its destructor.
			if ( $zip instanceof ZipArchive ) {
				$zip->unchangeAll();
			}

			wp_delete_file( $file );
		}

		if ( $problems ) {
			throw new RuntimeException( $tag . ': ' . implode( ' ', $problems ) );
		}

		return array(
			/* translators: %d: number of files in the archive */
			'message' => $tag . ', ' . size_format( $size, 1 ) . ', ' . sprintf( __( 'files: %d', 'mvweb-backup' ), count( $content ) + count( $root ) ),
			'size'    => $size,
		);
	}

	/**
	 * Add a file to the archive.
	 *
	 * @since 1.1.0
	 * @param ZipArchive $zip    Open archive.
	 * @param string     $source File on disk.
	 * @param string     $target Path inside the archive.
	 * @return void
	 * @throws RuntimeException When the file cannot be added.
	 */
	private static function zip_file( ZipArchive $zip, string $source, string $target ): void {
		if ( ! $zip->addFile( $source, $target ) ) {
			/* translators: %s: file path */
			throw new RuntimeException( sprintf( __( 'The file %s cannot be read.', 'mvweb-backup' ), $target ) );
		}
	}

	/**
	 * Publish a part, encrypted first when encryption is on.
	 *
	 * An encrypted file gets ".enc" added to its name.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api       Client.
	 * @param string          $part      Part key, also the tag prefix.
	 * @param string          $file      Path to the file.
	 * @param string          $extension Asset extension with the leading dot.
	 * @param string          $type      Content type.
	 * @param string          $manifest  Path to the manifest to attach, empty for none.
	 * @return string Tag of the new release.
	 * @throws RuntimeException On failure.
	 */
	private static function publish( MVweb_BK_GitHub $api, string $part, string $file, string $extension, string $type, string $manifest = '' ): string {
		$settings = mvweb_bk_get_settings();

		if ( empty( $settings['encrypt'] ) ) {
			return self::publish_file( $api, $part, $file, $extension, $type, $manifest, '.manifest.json', 'application/json' );
		}

		$encrypted = MVweb_BK_DB::temp_file();
		$sealed    = '' !== $manifest ? MVweb_BK_DB::temp_file() : '';

		try {
			MVweb_BK_Crypto::encrypt_file( $file, $encrypted, (string) $settings['public_key'] );

			if ( '' !== $sealed ) {
				MVweb_BK_Crypto::encrypt_file( $manifest, $sealed, (string) $settings['public_key'] );
			}

			return self::publish_file( $api, $part, $encrypted, $extension . '.enc', 'application/octet-stream', $sealed, '.manifest.json.enc', 'application/octet-stream' );
		} finally {
			wp_delete_file( $encrypted );

			if ( '' !== $sealed ) {
				wp_delete_file( $sealed );
			}
		}
	}

	/**
	 * Create a release for one part, attach the file, delete older releases.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api       Client.
	 * @param string          $part      Part key, also the tag prefix.
	 * @param string          $file      Path to the file.
	 * @param string          $extension Asset extension with the leading dot.
	 * @param string          $type      Content type.
	 * @param string          $extra     Path to a second file for the release, empty for none.
	 * @param string          $extra_ext Asset extension of the second file.
	 * @param string          $extra_type Content type of the second file.
	 * @return string Tag of the new release.
	 * @throws RuntimeException On failure.
	 */
	private static function publish_file( MVweb_BK_GitHub $api, string $part, string $file, string $extension, string $type, string $extra = '', string $extra_ext = '', string $extra_type = '' ): string {
		$size = (int) filesize( $file );

		if ( $size <= 0 ) {
			throw new RuntimeException( __( 'The backup file is empty.', 'mvweb-backup' ) );
		}

		if ( $size >= self::MAX_ASSET ) {
			throw new RuntimeException( __( 'The backup file is larger than the 2 GiB GitHub limit.', 'mvweb-backup' ) );
		}

		$tag     = $part . '-' . gmdate( 'Ymd-His' );
		$release = $api->request(
			'POST',
			'/releases',
			array(
				'tag_name'    => $tag,
				'name'        => $tag,
				'body'        => home_url() . "\n" . size_format( $size, 1 ),
				'make_latest' => 'false',
			)
		);

		if ( is_wp_error( $release ) ) {
			/* translators: %s: error message */
			throw new RuntimeException( sprintf( __( 'GitHub release was not created: %s', 'mvweb-backup' ), $release->get_error_message() ) );
		}

		if ( 201 !== $release['code'] || empty( $release['data']['id'] ) ) {
			/* translators: %s: error message */
			throw new RuntimeException( sprintf( __( 'GitHub release was not created: %s', 'mvweb-backup' ), 'HTTP ' . $release['code'] . ' ' . (string) ( $release['data']['message'] ?? '' ) ) );
		}

		try {
			$uploaded = $api->upload_asset( (string) $release['data']['upload_url'], $file, $tag . $extension, $type );
		} catch ( Throwable $e ) {
			$uploaded = new WP_Error( 'mvweb_bk_upload', $e->getMessage() );
		}

		if ( is_wp_error( $uploaded ) ) {
			self::delete_release( $api, (int) $release['data']['id'], $tag );

			/* translators: %s: error message */
			throw new RuntimeException( sprintf( __( 'The file was not uploaded to GitHub: %s', 'mvweb-backup' ), $uploaded->get_error_message() ) );
		}

		// The backup itself is safe by now: keep the release, keep the older ones, report the run as failed.
		if ( '' !== $extra ) {
			$attached = $api->upload_asset( (string) $release['data']['upload_url'], $extra, $tag . $extra_ext, $extra_type );

			if ( is_wp_error( $attached ) ) {
				/* translators: 1: release tag, 2: error message */
				throw new RuntimeException( sprintf( __( 'The backup %1$s is uploaded, but its manifest is not: %2$s', 'mvweb-backup' ), $tag, $attached->get_error_message() ) );
			}
		}

		self::prune( $api, $part, $tag );

		return $tag;
	}

	/**
	 * Keep the new release and the newest other releases with a file, KEEP in all.
	 *
	 * Only tags made by this plugin ("{part}-YYYYMMDD-HHMMSS") are touched.
	 * Releases left without a file by an interrupted run are deleted and never
	 * count as a kept backup.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api     Client.
	 * @param string          $part    Part key.
	 * @param string          $current Tag of the release just uploaded.
	 * @return void
	 * @throws RuntimeException When the list cannot be read or a release cannot be deleted.
	 */
	private static function prune( MVweb_BK_GitHub $api, string $part, string $current ): void {
		$list = $api->request( 'GET', '/releases?per_page=100' );

		if ( is_wp_error( $list ) || 200 !== $list['code'] || ! is_array( $list['data'] ) ) {
			throw new RuntimeException( __( 'The backup is uploaded, but old backups were not removed: GitHub did not return the release list.', 'mvweb-backup' ) );
		}

		$full   = array();
		$delete = array();

		foreach ( $list['data'] as $release ) {
			$tag = (string) ( $release['tag_name'] ?? '' );

			if ( $current === $tag || ! preg_match( '/^' . preg_quote( $part, '/' ) . '-\d{8}-\d{6}$/', $tag ) ) {
				continue;
			}

			// A file cut off by an interrupted upload is not "uploaded" and does not make a backup.
			$files = array_filter(
				(array) ( $release['assets'] ?? array() ),
				static fn( $asset ): bool => is_array( $asset ) && 'uploaded' === ( $asset['state'] ?? 'uploaded' )
			);

			if ( ! $files ) {
				$delete[ $tag ] = (int) $release['id'];
			} else {
				$full[ $tag ] = (int) $release['id'];
			}
		}

		krsort( $full, SORT_STRING );

		$delete += array_slice( $full, self::KEEP[ $part ] - 1, null, true );

		foreach ( $delete as $tag => $id ) {
			$reason = self::delete_release( $api, $id, (string) $tag );

			if ( '' !== $reason ) {
				/* translators: %s: release tag */
				throw new RuntimeException( sprintf( __( 'The backup is uploaded, but the old backup %s was not removed.', 'mvweb-backup' ), $tag ) . ' ' . $reason );
			}
		}
	}

	/**
	 * Delete a release and its tag.
	 *
	 * @since 1.0.0
	 * @param MVweb_BK_GitHub $api Client.
	 * @param int             $id  Release ID.
	 * @param string          $tag Tag name.
	 * @return string Empty when both were deleted (or already gone), otherwise the reason.
	 */
	private static function delete_release( MVweb_BK_GitHub $api, int $id, string $tag ): string {
		// The tag goes only after the release: a release without its tag turns into a draft.
		foreach ( array( '/releases/' . $id, '/git/refs/tags/' . rawurlencode( $tag ) ) as $path ) {
			$response = $api->request( 'DELETE', $path );

			if ( is_wp_error( $response ) ) {
				return $response->get_error_message();
			}

			if ( ! in_array( $response['code'], array( 204, 404, 422 ), true ) ) {
				return 'HTTP ' . $response['code'] . ' ' . (string) ( $response['data']['message'] ?? '' );
			}
		}

		return '';
	}
}
