<?php
/**
 * Database dump to a gzip file.
 *
 * @package mvweb_bk
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.EscapeOutput.ExceptionNotEscaped -- messages go to the CLI and the run log, escaped where shown.

/**
 * Dumps the site database with mysqldump, or with PHP when mysqldump fails.
 *
 * @since 1.0.0
 */
final class MVweb_BK_DB {

	const ROWS_PER_QUERY = 1000;

	/**
	 * Bytes per INSERT in the PHP dump, below the usual 4–16 MB max_allowed_packet.
	 */
	const MAX_INSERT = 1048576;

	/**
	 * Dump the database to a gzip file.
	 *
	 * @since 1.0.0
	 * @param string $file Target path, overwritten.
	 * @return string How the dump was made, for the run log.
	 * @throws RuntimeException When both methods fail.
	 */
	public static function dump( string $file ): string {
		$tool = mvweb_bk_find_mysqldump();
		$note = '';

		if ( $tool ) {
			try {
				self::mysqldump( $tool, $file );

				return 'mysqldump';
			} catch ( RuntimeException $e ) {
				$note = $e->getMessage();
			}
		}

		self::php_dump( $file );

		return '' === $note ? 'php' : 'php (mysqldump: ' . $note . ')';
	}

	/**
	 * Run mysqldump without a shell. The password goes through a 0600 option
	 * file, never through the argument list.
	 *
	 * @since 1.0.0
	 * @param array{bin: string, version: string} $tool Binary from mvweb_bk_find_mysqldump().
	 * @param string                              $file Target path.
	 * @return void
	 * @throws RuntimeException On any failure.
	 */
	private static function mysqldump( array $tool, string $file ): void {
		global $wpdb;

		$parsed = $wpdb->parse_db_host( DB_HOST );

		if ( ! is_array( $parsed ) ) {
			throw new RuntimeException( 'DB_HOST cannot be parsed.' );
		}

		list( $host, $port, $socket ) = $parsed;

		$quote   = static fn( string $value ): string => '"' . addcslashes( $value, '\\"' ) . '"';
		$options = "[client]\nuser=" . $quote( (string) DB_USER ) . "\npassword=" . $quote( (string) DB_PASSWORD ) . "\n";

		if ( $host ) {
			$options .= 'host=' . $quote( (string) $host ) . "\n";
		}

		if ( $port ) {
			$options .= 'port=' . (int) $port . "\n";
		}

		if ( $socket ) {
			$options .= 'socket=' . $quote( (string) $socket ) . "\n";
		}

		$config = self::temp_file();
		$errors = '';

		try {
			$errors = self::temp_file();

			file_put_contents( $config, $options ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents -- private 0600 temp file.

			$args = array(
				$tool['bin'],
				'--defaults-extra-file=' . $config,
				'--single-transaction',
				'--quick',
				'--no-tablespaces',
				'--default-character-set=' . ( $wpdb->charset ? $wpdb->charset : 'utf8mb4' ),
			);

			if ( false === stripos( $tool['version'], 'mariadb' ) ) {
				$args[] = '--set-gtid-purged=OFF';
			}

			$args[] = (string) DB_NAME;

			$descriptors = array(
				1 => array( 'pipe', 'w' ),
				2 => array( 'file', $errors, 'w' ),
			);

			$pipes   = array();
			$process = proc_open( $args, $descriptors, $pipes ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_proc_open -- fixed argument list, no shell.

			if ( ! is_resource( $process ) ) {
				throw new RuntimeException( 'mysqldump did not start.' );
			}

			$gz   = gzopen( $file, 'wb6' );
			$tail = '';

			if ( false === $gz ) {
				fclose( $pipes[1] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- process pipe.
				proc_close( $process );
				throw new RuntimeException( __( 'The dump file cannot be created.', 'mvweb-backup' ) );
			}

			while ( ! feof( $pipes[1] ) ) {
				$chunk = fread( $pipes[1], 1048576 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread -- process pipe.

				if ( false === $chunk || '' === $chunk ) {
					continue;
				}

				if ( strlen( $chunk ) !== gzwrite( $gz, $chunk ) ) {
					break;
				}

				$tail = substr( $tail . $chunk, -200 );
			}

			$written = feof( $pipes[1] ) && gzclose( $gz );
			fclose( $pipes[1] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- process pipe.

			$code = proc_close( $process );

			if ( ! $written ) {
				throw new RuntimeException( __( 'The dump file cannot be written. The disk may be full.', 'mvweb-backup' ) );
			}

			$message = trim( (string) file_get_contents( $errors ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local temp file.

			if ( 0 !== $code ) {
				throw new RuntimeException( '' !== $message ? substr( $message, 0, 300 ) : 'exit code ' . $code );
			}

			if ( false === strpos( $tail, '-- Dump completed' ) ) {
				throw new RuntimeException( 'the dump is incomplete.' );
			}
		} finally {
			wp_delete_file( $config );

			if ( '' !== $errors ) {
				wp_delete_file( $errors );
			}
		}
	}

	/**
	 * Dump all base tables through $wpdb in portions.
	 *
	 * @since 1.0.0
	 * @param string $file Target path.
	 * @return void
	 * @throws RuntimeException On a database error.
	 */
	private static function php_dump( string $file ): void {
		global $wpdb;

		$gz = gzopen( $file, 'wb6' );

		if ( false === $gz ) {
			throw new RuntimeException( __( 'The dump file cannot be created.', 'mvweb-backup' ) );
		}

		$charset = $wpdb->charset ? $wpdb->charset : 'utf8mb4';

		self::write( $gz, "SET NAMES {$charset};\nSET FOREIGN_KEY_CHECKS=0;\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n\n" );

		$tables = $wpdb->get_col( "SHOW FULL TABLES WHERE Table_type = 'BASE TABLE'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- full database dump.

		self::check_db_error();

		// One snapshot for all portions: rows written meanwhile do not shift the offsets (InnoDB).
		$wpdb->query( 'START TRANSACTION WITH CONSISTENT SNAPSHOT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- full database dump.

		try {
			foreach ( $tables as $table ) {
				self::php_dump_table( $gz, (string) $table );
			}
		} finally {
			$wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- full database dump.
		}

		self::write( $gz, "SET FOREIGN_KEY_CHECKS=1;\n-- Dump completed by MVweb Backup\n" );

		if ( ! gzclose( $gz ) ) {
			throw new RuntimeException( __( 'The dump file cannot be written. The disk may be full.', 'mvweb-backup' ) );
		}
	}

	/**
	 * Write one table: structure, then INSERTs of at most about MAX_INSERT bytes.
	 *
	 * @since 1.0.0
	 * @param resource $gz    Open gzip file.
	 * @param string   $table Table name.
	 * @return void
	 * @throws RuntimeException On a database or write error.
	 */
	private static function php_dump_table( $gz, string $table ): void {
		global $wpdb;

		$name   = '`' . str_replace( '`', '``', $table ) . '`';
		$create = $wpdb->get_row( $wpdb->prepare( 'SHOW CREATE TABLE %i', $table ), ARRAY_N ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- full database dump.

		self::check_db_error();
		self::write( $gz, "DROP TABLE IF EXISTS {$name};\n" . $create[1] . ";\n\n" );

		for ( $offset = 0; ; $offset += self::ROWS_PER_QUERY ) {
			$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM %i LIMIT %d, %d', $table, $offset, self::ROWS_PER_QUERY ), ARRAY_N ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery -- full database dump.

			self::check_db_error();

			if ( ! $rows ) {
				break;
			}

			// mysqli returns BIT as a decimal string; quoted, it would be stored as characters.
			$bits   = array_keys( (array) $wpdb->get_col_info( 'type' ), MYSQLI_TYPE_BIT, true );
			$values = array();
			$length = 0;

			foreach ( $rows as $row ) {
				$cells = array();

				foreach ( $row as $index => $cell ) {
					if ( null === $cell ) {
						$cells[] = 'NULL';
					} elseif ( in_array( $index, $bits, true ) ) {
						$cells[] = ctype_digit( (string) $cell ) ? (string) $cell : "x'" . bin2hex( (string) $cell ) . "'";
					} else {
						$cells[] = "'" . $wpdb->remove_placeholder_escape( $wpdb->_real_escape( (string) $cell ) ) . "'";
					}
				}

				$value    = '(' . implode( ',', $cells ) . ')';
				$values[] = $value;
				$length  += strlen( $value );

				if ( $length >= self::MAX_INSERT ) {
					self::write( $gz, "INSERT INTO {$name} VALUES\n" . implode( ",\n", $values ) . ";\n" );
					$values = array();
					$length = 0;
				}
			}

			if ( $values ) {
				self::write( $gz, "INSERT INTO {$name} VALUES\n" . implode( ",\n", $values ) . ";\n" );
			}

			$wpdb->flush();
		}

		self::write( $gz, "\n" );
	}

	/**
	 * Write to the gzip file or throw.
	 *
	 * @since 1.0.0
	 * @param resource $gz   Open gzip file.
	 * @param string   $data Data.
	 * @return void
	 * @throws RuntimeException When not everything was written.
	 */
	private static function write( $gz, string $data ): void {
		if ( strlen( $data ) !== gzwrite( $gz, $data ) ) {
			throw new RuntimeException( __( 'The dump file cannot be written. The disk may be full.', 'mvweb-backup' ) );
		}
	}

	/**
	 * Throw if the last $wpdb query failed.
	 *
	 * @since 1.0.0
	 * @return void
	 * @throws RuntimeException With the database error.
	 */
	private static function check_db_error(): void {
		global $wpdb;

		if ( '' !== (string) $wpdb->last_error ) {
			/* translators: %s: database error */
			throw new RuntimeException( sprintf( __( 'Database error: %s', 'mvweb-backup' ), $wpdb->last_error ) );
		}
	}

	/**
	 * Create an empty private temp file.
	 *
	 * @since 1.0.0
	 * @return string Path.
	 * @throws RuntimeException When the temp folder is not writable.
	 */
	public static function temp_file(): string {
		$path = tempnam( get_temp_dir(), 'mvbk' );

		if ( false === $path ) {
			throw new RuntimeException( __( 'The temp folder is not writable.', 'mvweb-backup' ) );
		}

		chmod( $path, 0600 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_chmod -- private temp file.

		// Also removed after a fatal error, when finally blocks do not run.
		register_shutdown_function( 'wp_delete_file', $path );

		return $path;
	}
}
