<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package MVweb_Custom_Functions
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick Start', 'mvweb-custom-functions' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Enable execution', 'mvweb-custom-functions' ); ?></strong>
			<p><?php esc_html_e( 'Turn on the "Enable execution of custom code" toggle.', 'mvweb-custom-functions' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Write code', 'mvweb-custom-functions' ); ?></strong>
			<p><?php esc_html_e( 'Enter your PHP code in the editor. Do not include the opening <?php tag.', 'mvweb-custom-functions' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Save', 'mvweb-custom-functions' ); ?></strong>
			<p><?php esc_html_e( 'Click "Save Changes". Your code will be syntax-checked before saving.', 'mvweb-custom-functions' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Features', 'mvweb-custom-functions' ); ?></div>
	</div>
	<ul class="mvweb-bullets">
		<li><span class="mvweb-bullet-dot mvweb-bullet-dot--good"></span><span><?php esc_html_e( 'PHP code editor with syntax highlighting (CodeMirror)', 'mvweb-custom-functions' ); ?></span></li>
		<li><span class="mvweb-bullet-dot mvweb-bullet-dot--good"></span><span><?php esc_html_e( 'Syntax validation before saving', 'mvweb-custom-functions' ); ?></span></li>
		<li><span class="mvweb-bullet-dot mvweb-bullet-dot--good"></span><span><?php esc_html_e( 'Enable/Disable toggle (kill switch)', 'mvweb-custom-functions' ); ?></span></li>
		<li><span class="mvweb-bullet-dot mvweb-bullet-dot--good"></span><span><?php esc_html_e( 'Auto-disable on fatal error', 'mvweb-custom-functions' ); ?></span></li>
		<li><span class="mvweb-bullet-dot mvweb-bullet-dot--good"></span><span><?php esc_html_e( 'Emergency killswitch via wp-config.php', 'mvweb-custom-functions' ); ?></span></li>
		<li><span class="mvweb-bullet-dot mvweb-bullet-dot--good"></span><span><?php esc_html_e( 'Error logging to debug.log', 'mvweb-custom-functions' ); ?></span></li>
	</ul>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Important Notes', 'mvweb-custom-functions' ); ?></div>
	</div>

	<div class="mvweb-alert mvweb-alert--warning">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
		<div class="mvweb-alert__body">
			<ul>
				<li><?php esc_html_e( 'Only administrators with manage_options capability can access this plugin.', 'mvweb-custom-functions' ); ?></li>
				<li><?php esc_html_e( 'Code runs on every page load (frontend and admin).', 'mvweb-custom-functions' ); ?></li>
				<li><?php esc_html_e( 'If your code causes a fatal error, it will be automatically disabled.', 'mvweb-custom-functions' ); ?></li>
				<li>
					<?php
					printf(
						/* translators: %s: PHP constant code */
						esc_html__( 'For emergency disable, add %s to your wp-config.php file.', 'mvweb-custom-functions' ),
						'<code>define( \'MVWEB_CF_DISABLE\', true );</code>'
					);
					?>
				</li>
			</ul>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Frequently Asked Questions', 'mvweb-custom-functions' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Do I need to include the <?php tag?', 'mvweb-custom-functions' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'No. The opening PHP tag is added automatically. Just write your code directly.', 'mvweb-custom-functions' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'What if my code breaks the site?', 'mvweb-custom-functions' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'The plugin will automatically disable code execution if a fatal error is detected. You can also add the following line to wp-config.php as an emergency killswitch:', 'mvweb-custom-functions' ); ?></p>
			<p><code>define( 'MVWEB_CF_DISABLE', true );</code></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can I use WordPress functions?', 'mvweb-custom-functions' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Yes. All WordPress functions are available: add_filter(), add_action(), get_option(), etc. The code runs on the plugins_loaded hook.', 'mvweb-custom-functions' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Where can I see error logs?', 'mvweb-custom-functions' ); ?></summary>
		<div class="mvweb-faq__body">
			<p>
				<?php
				printf(
					/* translators: %s: debug log path */
					esc_html__( 'Check the %s file in your WordPress content directory. Make sure WP_DEBUG_LOG is enabled.', 'mvweb-custom-functions' ),
					'<code>wp-content/debug.log</code>'
				);
				?>
			</p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-custom-functions' ); ?></div>
	</div>
	<p>
		<?php
		printf(
			/* translators: %s: MVweb plugin URL */
			esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-custom-functions' ),
			'<a href="https://mvweb.ru/plugins/mvweb-custom-functions" target="_blank">mvweb.ru</a>'
		);
		?>
	</p>
	<p>
		<strong><?php esc_html_e( 'Version:', 'mvweb-custom-functions' ); ?></strong> <?php echo esc_html( MVWEB_CF_VERSION ); ?>
	</p>
</div>
