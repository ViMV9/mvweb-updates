<?php
/**
 * Snippets tab — custom PHP code editor.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package MVweb_Custom_Functions
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$current_code = ( isset( $_POST['mvweb_cf_code'] )
	&& isset( $_POST['mvweb_cf_nonce'] )
	&& wp_verify_nonce( sanitize_key( wp_unslash( $_POST['mvweb_cf_nonce'] ) ), 'mvweb_cf_settings' )
	&& ! empty( get_settings_errors( 'mvweb_cf' ) ) )
	? wp_unslash( $_POST['mvweb_cf_code'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- raw PHP snippet re-displayed in editor, escaped via esc_textarea() below.
	: get_option( 'mvweb_cf_code', '' );

$error = get_option( 'mvweb_cf_error', '' );
?>

<form method="post" action="" class="mvweb-cf-form">
	<?php wp_nonce_field( 'mvweb_cf_settings', 'mvweb_cf_nonce' ); ?>

	<?php if ( ! empty( $error ) ) : ?>
		<div class="mvweb-alert mvweb-alert--warning">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
			<div class="mvweb-alert__body">
				<p class="mvweb-alert__title"><?php esc_html_e( 'Code was auto-disabled due to error:', 'mvweb-custom-functions' ); ?></p>
				<p><?php echo esc_html( $error ); ?></p>
			</div>
		</div>
	<?php endif; ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Custom PHP code', 'mvweb-custom-functions' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Код выполняется на каждой загрузке страницы после загрузки всех плагинов.', 'mvweb-custom-functions' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb_cf_enabled" class="mvweb-form-row__label">
				<?php esc_html_e( 'Enable', 'mvweb-custom-functions' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox" id="mvweb_cf_enabled" name="mvweb_cf_enabled" value="1"
							<?php checked( get_option( 'mvweb_cf_enabled', '0' ), '1' ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Enable execution of custom code', 'mvweb-custom-functions' ); ?></span>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-cf-code" class="mvweb-form-row__label">
				<?php esc_html_e( 'Code', 'mvweb-custom-functions' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-cf-editor-wrap">
					<textarea id="mvweb-cf-code" name="mvweb_cf_code" rows="20"
						class="mvweb-textarea"><?php echo esc_textarea( $current_code ); ?></textarea>
				</div>
				<p class="mvweb-form-row__desc">
					<?php
					printf(
						/* translators: %s: PHP opening tag */
						esc_html__( 'Do not include opening %s tag. It is added automatically.', 'mvweb-custom-functions' ),
						'<code>&lt;?php</code>'
					);
					?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" name="mvweb_cf_save" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Save Changes', 'mvweb-custom-functions' ); ?>
		</button>
	</div>
</form>
