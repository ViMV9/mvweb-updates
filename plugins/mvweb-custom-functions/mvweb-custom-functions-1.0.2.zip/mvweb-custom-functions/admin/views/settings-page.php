<?php
/**
 * Admin settings page template.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 *
 * @package MVweb_Custom_Functions
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'snippets'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.

$tabs = array(
	'snippets' => array(
		'label' => __( 'Snippets', 'mvweb-custom-functions' ),
		'icon'  => 'code',
	),
	'help'     => array(
		'label' => __( 'Help', 'mvweb-custom-functions' ),
		'icon'  => 'help',
	),
);

$icons = array(
	'code' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
	'help' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">CF</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Custom Functions', 'mvweb-custom-functions' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_CF_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $tabs as $tab_id => $tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $tab_id ); ?>"
						class="mvweb-nav__link <?php echo esc_attr( $current_tab === $tab_id ? 'mvweb-nav__link--active' : '' ); ?>"
						data-tab="<?php echo esc_attr( $tab_id ); ?>">
						<?php echo $icons[ $tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $tab['label'] ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php settings_errors( 'mvweb_cf' ); ?>

		<div id="snippets" class="mvweb-tab-content <?php echo esc_attr( 'snippets' === $current_tab ? 'active' : '' ); ?>">
			<?php require MVWEB_CF_PATH . 'admin/views/tab-snippets.php'; ?>
		</div>

		<div id="help" class="mvweb-tab-content <?php echo esc_attr( 'help' === $current_tab ? 'active' : '' ); ?>">
			<?php require MVWEB_CF_PATH . 'admin/views/tab-help.php'; ?>
		</div>

	</main>
</div>
