/**
 * Admin JavaScript for MVweb Custom Functions.
 *
 * @package MVweb_Custom_Functions
 * @since   1.0.0
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		initTabs();
		initCodeEditor();
	});

	/**
	 * Tab navigation without page reload.
	 */
	function initTabs() {
		var links = document.querySelectorAll('.mvweb-nav__link');
		var panels = document.querySelectorAll('.mvweb-tab-content');

		if (!links.length || !panels.length) {
			return;
		}

		function activate(target) {
			links.forEach(function (l) {
				l.classList.toggle('mvweb-nav__link--active', l.getAttribute('data-tab') === target);
			});
			panels.forEach(function (p) {
				p.classList.toggle('active', p.id === target);
			});
		}

		links.forEach(function (link) {
			link.addEventListener('click', function (event) {
				event.preventDefault();

				var target = link.getAttribute('data-tab') || link.getAttribute('href').replace('#', '');
				activate(target);

				if (history.pushState) {
					history.pushState(null, '', '#' + target);
				}
			});
		});

		var hash = window.location.hash.substring(1);
		if (hash && document.getElementById(hash)) {
			activate(hash);
		}
	}

	/**
	 * Initialize CodeMirror via WP API.
	 */
	function initCodeEditor() {
		if (typeof wp !== 'undefined' && wp.codeEditor && typeof mvwebCfCm !== 'undefined') {
			wp.codeEditor.initialize('mvweb-cf-code', mvwebCfCm);
		}
	}
})();
