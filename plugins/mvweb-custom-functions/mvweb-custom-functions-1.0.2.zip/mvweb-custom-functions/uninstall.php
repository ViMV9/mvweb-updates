<?php
/**
 * Uninstall MVweb Custom Functions
 *
 * Fired when the plugin is uninstalled.
 *
 * @package MVweb_Custom_Functions
 * @since   1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Plugin options to delete.
$options = array(
	'mvweb_cf_code',
	'mvweb_cf_enabled',
	'mvweb_cf_error',
);

// Delete options on single site.
foreach ( $options as $option ) {
	delete_option( $option );
}

// For multisite, delete options from all sites.
if ( is_multisite() ) {
	$sites = get_sites();
	foreach ( $sites as $site ) {
		switch_to_blog( $site->blog_id );
		foreach ( $options as $option ) {
			delete_option( $option );
		}
		restore_current_blog();
	}
}

// Clear any cached data.
wp_cache_flush();
