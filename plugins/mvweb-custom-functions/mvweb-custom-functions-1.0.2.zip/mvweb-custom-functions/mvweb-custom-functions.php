<?php
/**
 * Plugin Name:       MVweb Custom Functions
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-custom-functions
 * Description:       Execute custom PHP code from WordPress admin.
 * Version:           1.0.2
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-custom-functions
 * Domain Path:       /languages
 *
 * @package MVweb_Custom_Functions
 * @since 1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_CF_VERSION' ) ) {
	return;
}

if ( defined( 'MVWEB_CF_DISABLE' ) && MVWEB_CF_DISABLE ) {
	return;
}

/**
 * Plugin version.
 */
define( 'MVWEB_CF_VERSION', '1.0.2' );

/**
 * Plugin directory path.
 */
define( 'MVWEB_CF_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Plugin directory URL.
 */
define( 'MVWEB_CF_URL', plugin_dir_url( __FILE__ ) );

/**
 * Plugin basename.
 */
define( 'MVWEB_CF_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_CF_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_CF_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_CF_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_CF_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_CF_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-custom-functions' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-custom-functions'] = array(
		'name'         => 'MVweb Custom Functions',
		'description'  => __( 'Execute custom PHP code from WordPress admin.', 'mvweb-custom-functions' ),
		'url'          => 'https://mvweb.ru/plugins/mvweb-custom-functions',
		'settings_url' => 'admin.php?page=mvweb-custom-functions',
		'textdomain'   => 'mvweb-custom-functions',
	);
	return $plugins;
} );

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cf_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-custom-functions',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_cf_load_textdomain' );

// ───────────────────────────────────────────────
// Code execution
// ───────────────────────────────────────────────

/**
 * Execute user's custom PHP code.
 *
 * Hooked on plugins_loaded with priority 99 to run after all plugins are loaded.
 * Auto-disables on error via try/catch and shutdown handler.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cf_execute_code() {
	$mvweb_cf_enabled = get_option( 'mvweb_cf_enabled', '0' );
	$mvweb_cf_code    = get_option( 'mvweb_cf_code', '' );

	if ( '1' !== $mvweb_cf_enabled || empty( $mvweb_cf_code ) ) {
		return;
	}

	// Limit execution time to prevent infinite loops.
	$mvweb_cf_original_time_limit = (int) ini_get( 'max_execution_time' );
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( 10 );
	}

	try {
		eval( $mvweb_cf_code );
	} catch ( \Throwable $e ) {
		// Auto-disable on error.
		update_option( 'mvweb_cf_enabled', '0' );
		update_option( 'mvweb_cf_error', $e->getMessage() );
		error_log( '[MVweb Custom Functions] Error: ' . $e->getMessage() );
	}

	// Restore original time limit.
	if ( function_exists( 'set_time_limit' ) ) {
		@set_time_limit( $mvweb_cf_original_time_limit );
	}
}
add_action( 'plugins_loaded', 'mvweb_cf_execute_code', 99 );

/**
 * Shutdown handler to catch fatal errors from eval'd code.
 *
 * Catches E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR that
 * originate from eval(). Auto-disables code execution on fatal error.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cf_shutdown_handler() {
	$error = error_get_last();
	if ( ! $error ) {
		return;
	}

	$fatal_types = array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR );

	if ( in_array( $error['type'], $fatal_types, true )
		&& preg_match( '/eval\(\).*mvweb_cf_execute_code/', $error['file'] )
	) {
		update_option( 'mvweb_cf_enabled', '0' );
		update_option( 'mvweb_cf_error', $error['message'] );
		error_log( '[MVweb Custom Functions] Fatal: ' . $error['message'] );
	}
}
register_shutdown_function( 'mvweb_cf_shutdown_handler' );

// ───────────────────────────────────────────────
// Syntax checking
// ───────────────────────────────────────────────

/**
 * Check PHP code syntax.
 *
 * Uses php -l (lint) via proc_open for reliable syntax checking.
 * Falls back to token_get_all() if proc_open is unavailable.
 *
 * @since 1.0.0
 * @param string $code PHP code without opening tag.
 * @return true|string True if valid, error message string on failure.
 */
function mvweb_cf_check_syntax( $code ) {
	$full_code = '<?php ' . $code;

	// Primary: php -l via proc_open (most reliable).
	if ( function_exists( 'proc_open' )
		&& ! in_array( 'proc_open', explode( ',', (string) ini_get( 'disable_functions' ) ), true )
	) {
		$descriptors = array(
			0 => array( 'pipe', 'r' ),
			1 => array( 'pipe', 'w' ),
			2 => array( 'pipe', 'w' ),
		);

		$process = proc_open( 'php -l', $descriptors, $pipes );

		if ( is_resource( $process ) ) {
			fwrite( $pipes[0], $full_code );
			fclose( $pipes[0] );

			$stderr = stream_get_contents( $pipes[2] );
			fclose( $pipes[1] );
			fclose( $pipes[2] );

			$exit_code = proc_close( $process );

			if ( 0 !== $exit_code ) {
				return trim( $stderr );
			}

			return true;
		}
	}

	// Fallback: token_get_all with TOKEN_PARSE (PHP 7.0+).
	try {
		token_get_all( $full_code, TOKEN_PARSE );
		return true;
	} catch ( \ParseError $e ) {
		return $e->getMessage();
	}
}

// ───────────────────────────────────────────────
// Admin: save handler
// ───────────────────────────────────────────────

/**
 * Handle settings form submission.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cf_handle_save() {
	if ( ! isset( $_POST['mvweb_cf_save'] ) ) {
		return;
	}
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Unauthorized access.', 'mvweb-custom-functions' ) );
	}
	check_admin_referer( 'mvweb_cf_settings', 'mvweb_cf_nonce' );

	// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- raw PHP snippet; sanitize_text_field() would strip code. Validated via mvweb_cf_check_syntax() before save, escaped via esc_textarea() on display.
	$code    = isset( $_POST['mvweb_cf_code'] ) ? wp_unslash( $_POST['mvweb_cf_code'] ) : '';
	$enabled = isset( $_POST['mvweb_cf_enabled'] ) ? '1' : '0';

	// Check syntax if code is not empty.
	if ( ! empty( $code ) ) {
		$syntax_result = mvweb_cf_check_syntax( $code );
		if ( true !== $syntax_result ) {
			// Syntax error — do NOT save code, show error notice.
			add_settings_error(
				'mvweb_cf',
				'syntax_error',
				/* translators: %s: syntax error message */
				sprintf( __( 'Syntax error: %s', 'mvweb-custom-functions' ), $syntax_result ),
				'error'
			);
			return;
		}
	}

	update_option( 'mvweb_cf_code', $code );
	update_option( 'mvweb_cf_enabled', $enabled );
	delete_option( 'mvweb_cf_error' ); // Clear previous error on successful save.

	add_settings_error(
		'mvweb_cf',
		'saved',
		__( 'Settings saved.', 'mvweb-custom-functions' ),
		'updated'
	);
}

// ───────────────────────────────────────────────
// Admin: menu & page
// ───────────────────────────────────────────────

/**
 * Register plugin submenu under MVweb.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cf_register_menu() {
	$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

	add_submenu_page(
		$parent_slug,
		__( 'MVweb Custom Functions', 'mvweb-custom-functions' ),
		__( 'Custom Functions', 'mvweb-custom-functions' ),
		'manage_options',
		'mvweb-custom-functions',
		'mvweb_cf_settings_page'
	);
}
add_action( 'admin_menu', 'mvweb_cf_register_menu' );

/**
 * Plugin settings page callback.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_cf_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	// Handle form submission.
	mvweb_cf_handle_save();

	require MVWEB_CF_PATH . 'admin/views/settings-page.php';
}

// ───────────────────────────────────────────────
// Admin: enqueue assets
// ───────────────────────────────────────────────

/**
 * Enqueue admin styles and scripts.
 *
 * @since 1.0.0
 * @param string $hook Current admin page hook.
 * @return void
 */
function mvweb_cf_admin_enqueue( $hook ) {
	if ( false === strpos( $hook, 'mvweb-custom-functions' ) ) {
		return;
	}

	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

	// MVweb UI Kit.
	wp_enqueue_style(
		'mvweb-cf-admin',
		MVWEB_CF_URL . 'admin/css/admin' . $suffix . '.css',
		array(),
		(string) filemtime( MVWEB_CF_PATH . 'admin/css/admin' . $suffix . '.css' )
	);

	// Plugin-specific styles.
	wp_enqueue_style(
		'mvweb-cf-plugin',
		MVWEB_CF_URL . 'admin/css/plugin' . $suffix . '.css',
		array( 'mvweb-cf-admin' ),
		(string) filemtime( MVWEB_CF_PATH . 'admin/css/plugin' . $suffix . '.css' )
	);

	// WordPress CodeMirror (PHP mode).
	$cm_settings = wp_enqueue_code_editor( array( 'type' => 'application/x-httpd-php' ) );

	// Admin JS.
	wp_enqueue_script(
		'mvweb-cf-admin',
		MVWEB_CF_URL . 'admin/js/admin' . $suffix . '.js',
		array( 'jquery', 'wp-theme-plugin-editor' ),
		(string) filemtime( MVWEB_CF_PATH . 'admin/js/admin' . $suffix . '.js' ),
		true
	);

	// Pass CodeMirror settings to JS.
	if ( false !== $cm_settings ) {
		wp_localize_script( 'mvweb-cf-admin', 'mvwebCfCm', $cm_settings );
	}
}
add_action( 'admin_enqueue_scripts', 'mvweb_cf_admin_enqueue' );
