# MVweb Custom Functions

Execute custom PHP code from the WordPress admin panel.

## Description

MVweb Custom Functions provides a simple code editor in the WordPress admin where you can add PHP snippets — custom hooks, filters, shortcodes, and other functions — without editing theme files or creating a separate plugin.

**Features:**

- PHP code editor with syntax highlighting (CodeMirror)
- Syntax validation before saving
- Enable/Disable toggle
- Auto-disable on fatal error
- Emergency killswitch via `wp-config.php`
- Error logging to `debug.log`

## Requirements

- WordPress 6.4+
- PHP 8.0+

## Installation

1. Upload the `mvweb-custom-functions` folder to `/wp-content/plugins/`.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Navigate to **MVweb Hub → Custom Functions** in the admin menu.

## Usage

1. Check the **"Enable execution of custom code"** checkbox.
2. Enter your PHP code in the editor. Do not include the opening `<?php` tag — it is added automatically.
3. Click **"Save Changes"**. Your code will be syntax-checked before saving.

## Safety

The plugin includes multiple safety mechanisms:

- **Syntax check** before saving prevents broken code from being executed.
- **Auto-disable** on fatal errors — the plugin automatically disables code execution if a fatal error is detected.
- **Emergency killswitch** — add the following to `wp-config.php` to disable the plugin entirely:

```php
define( 'MVWEB_CF_DISABLE', true );
```

## FAQ

**Do I need to include the `<?php` tag?**
No. The opening PHP tag is added automatically.

**What if my code breaks the site?**
The plugin will automatically disable code execution if a fatal error is detected. Use the `MVWEB_CF_DISABLE` constant in `wp-config.php` as an emergency killswitch.

**Can I use WordPress functions?**
Yes. All WordPress functions are available (`add_filter()`, `add_action()`, `get_option()`, etc.). The code runs on the `plugins_loaded` hook.

## Support

Visit [mvweb.ru](https://mvweb.ru/plugins/mvweb-custom-functions) for documentation and support.

## License

GPL v2 or later.
