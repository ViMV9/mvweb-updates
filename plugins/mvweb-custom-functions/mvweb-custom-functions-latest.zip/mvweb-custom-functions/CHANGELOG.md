# Changelog

All notable changes to MVweb Custom Functions will be documented in this file.

## [1.0.1] - 2026-06-03

### Changed
- Snippets tab: code editor and toggle now span the full width (label on top) and the toggle label reads "Enable" instead of "Execution".
- Migrated admin UI to the new MVweb Admin UI Kit (slate palette, Yoast-style sidebar layout).
- Settings page split into `tab-snippets.php` and `tab-help.php` partials with a sidebar orchestrator.
- Admin JavaScript rewritten in vanilla JS (no jQuery wrapper); tab switching uses `.mvweb-nav__link`.
- Bundled shared `MVweb_Menu` updated to v2.2.0 (brand logo support, plugin icon labels).
- Plugin description in MVweb Hub now translatable via `__()`.
- Russian translation: "Custom Functions" submenu translated to "Пользовательские функции".

### Added
- `images/mv-logo-violet.png` for the MVweb Hub brand logo.
- `build:locale` npm script for PO→MO compilation.
- Technical documentation (`docs/plugins/mvweb-custom-functions.md`).
- Plugin README.md.

### Fixed
- Tab switching: restored `.mvweb-tab-content` show/hide rules in `plugin.css` (display:none / .active) — without them all tabs rendered at once.
- Help tab layout: synced `admin.css` with the boilerplate (block heading spacing, FAQ answer card), wrapped `.mvweb-steps` items in a `<div>` so descriptions fill the column, and switched the Features list to `.mvweb-bullets`.
- Shutdown handler: narrowed the executor regex to target only `mvweb_cf_execute_code` context, preventing false positives from other plugins.
- Syntax check: added `disable_functions` INI check for `proc_open()` to ensure reliable fallback.
- Settings view: added nonce verification when re-displaying POST data after syntax error.
- Variable isolation in `mvweb_cf_execute_code()`: prefixed local variables with `mvweb_cf_` to avoid conflicts with user code.
- Added `function_exists()` check for `set_time_limit()` for hosting compatibility.

## [1.0.0] - 2026-02-10

### Added
- PHP code editor with CodeMirror syntax highlighting.
- Enable/Disable toggle (kill switch).
- Syntax validation before saving (php -l with token_get_all fallback).
- Auto-disable on fatal error with shutdown handler.
- Emergency killswitch via wp-config.php constant `MVWEB_CF_DISABLE`.
- Error logging to debug.log.
- Help tab with Quick Start, Features, Important Notes, FAQ, and Support sections.
- Russian (ru_RU) translation.
- Multisite-aware uninstall cleanup.
