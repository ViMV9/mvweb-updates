# Changelog

All notable changes to this project will be documented in this file.

## [1.0.1] - 2026-02-09

### Fixed
- Hub page translations missing for Russian locale (added all MVweb Hub strings to .po)
- Premature `__()` call in `mvweb_registered_plugins` filter (textdomain not loaded yet)
- `detect_textdomain()` missing `MVWEB_DE_VERSION` constant check
- Admin menu renamed from "MVweb" to "MVweb Hub"

## [1.0.0] - 2026-02-08

### Added
- Plugin scaffolding: entry point, constants, shared components (Menu, Updater, PUC).
- Admin page with 5 tabs (Export, Presets, History, Settings, Help).
- Help tab with Quick Start, Features, FAQ, and Support sections.
- Settings tab: encoding, header language, batch size, max records, max history, delete on uninstall.
- System information block: PHP limits, disk space, export directory status, WooCommerce status.
- AJAX handler for saving settings with validation.
- File manager: export directory creation, .htaccess protection, index.php, Nginx detection with admin notice.
- Tab switching with localStorage persistence.
- Inline notifications system.
- CSS with BEM methodology and brand color (#793ea4).
- Build system: terser + clean-css minification.
- Field registry: dynamic field discovery for post types and taxonomies with transient caching.
- CSV/TXT writer with UTF-8 BOM support, semicolon/tab delimiters.
- Streaming write API in CSV Writer (`open_for_append`, `write_single_row`, `write_rows`, `close`).
- Cursor-based pagination for ID-sorted exports (avoids slow OFFSET on large tables).
- Exporter: WP_Query-based batch processing with memory monitoring and cache preloading.
- AJAX export flow: start, batch, cancel, download with session management and user locking.
- Drag-n-drop field selection with jQuery UI Sortable (available/selected lists).
- Progress bar with percentage counter and cancel button.
- Download via hidden iframe with IDOR protection and path traversal prevention.
- Export history with FIFO rotation stored in wp_options.
- Filters: post status (multiselect), taxonomy terms, date range, author dropdown.
- Dynamic filter loading via AJAX on source change.
- Preview: display first 10 rows in scrollable table before export.
- Permissions model: admins see all, editors see published + own posts of any status.
- Cancel export with confirmation dialog and temporary file cleanup.
- Preset manager: CRUD for export presets with per-user limits (max 20) and IDOR protection.
- Preset bar on Export tab: dropdown, Load, Save as Preset controls.
- Presets tab: full table UI with lazy-loading, load/delete actions.
- History tab: full table UI with lazy-loading, download links, delete actions.
- AJAX endpoints: save_preset, delete_preset, get_presets, get_history, delete_history.
- Preset restoration: export type, source, fields, format, filters applied on load.
- Migrated CSS to MVweb UI Kit Classic Clean (global variables, components).
- Preset manager saves `variation_mode` and sanitizes WC-specific filters (price, stock status, product type).
- Export batch handler returns file write errors to client via `error` key in response.
