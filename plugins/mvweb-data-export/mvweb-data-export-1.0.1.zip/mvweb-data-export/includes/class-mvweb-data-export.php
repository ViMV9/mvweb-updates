<?php
/**
 * Main plugin class.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_Data_Export
 *
 * Initializes all plugin components and hooks.
 * NOT a Singleton — instantiated once in the entry point.
 *
 * @since 0.1.0
 */
class MVweb_Data_Export {

	/**
	 * Admin component.
	 *
	 * @var MVweb_DE_Admin
	 */
	private MVweb_DE_Admin $admin;

	/**
	 * AJAX component.
	 *
	 * @var MVweb_DE_Ajax
	 */
	private MVweb_DE_Ajax $ajax;

	/**
	 * File manager component.
	 *
	 * @var MVweb_DE_File_Manager
	 */
	private MVweb_DE_File_Manager $file_manager;

	/**
	 * Field registry component.
	 *
	 * @var MVweb_DE_Field_Registry
	 */
	private MVweb_DE_Field_Registry $field_registry;

	/**
	 * Exporter component.
	 *
	 * @var MVweb_DE_Exporter
	 */
	private MVweb_DE_Exporter $exporter;

	/**
	 * Preset manager component.
	 *
	 * @var MVweb_DE_Preset_Manager
	 */
	private MVweb_DE_Preset_Manager $preset_manager;

	/**
	 * WooCommerce fields component (conditional).
	 *
	 * @var MVweb_DE_WC_Fields|null
	 */
	private ?MVweb_DE_WC_Fields $wc_fields = null;

	/**
	 * Initialize the plugin.
	 *
	 * Loads textdomain, dependencies, and hooks.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function init(): void {
		$this->load_textdomain();
		$this->load_dependencies();
		$this->init_hooks();
		$this->init_cron();
	}

	/**
	 * Load plugin textdomain.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	private function load_textdomain(): void {
		add_action( 'plugins_loaded', function () {
			load_plugin_textdomain(
				'mvweb-data-export',
				false,
				dirname( MVWEB_DE_BASENAME ) . '/languages/'
			);
		} );
	}

	/**
	 * Load required dependencies.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	private function load_dependencies(): void {
		require_once MVWEB_DE_PATH . 'includes/class-file-manager.php';
		require_once MVWEB_DE_PATH . 'includes/class-field-registry.php';
		require_once MVWEB_DE_PATH . 'includes/class-csv-writer.php';
		require_once MVWEB_DE_PATH . 'includes/class-exporter.php';
		require_once MVWEB_DE_PATH . 'includes/class-preset-manager.php';
		require_once MVWEB_DE_PATH . 'includes/class-admin.php';
		require_once MVWEB_DE_PATH . 'includes/class-ajax.php';

		$this->file_manager   = new MVweb_DE_File_Manager();
		$this->field_registry = new MVweb_DE_Field_Registry();
		$this->exporter       = new MVweb_DE_Exporter( $this->field_registry );
		$this->preset_manager = new MVweb_DE_Preset_Manager();
		$this->admin          = new MVweb_DE_Admin();
		$this->ajax           = new MVweb_DE_Ajax( $this->field_registry, $this->exporter, $this->preset_manager );

		// Conditional WooCommerce integration.
		require_once MVWEB_DE_PATH . 'includes/class-wc-fields.php';
		if ( MVweb_DE_WC_Fields::is_available() ) {
			$this->wc_fields = new MVweb_DE_WC_Fields();
			$this->wc_fields->init();
			$this->exporter->set_wc_fields( $this->wc_fields );
		}
	}

	/**
	 * Initialize hooks.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	private function init_hooks(): void {
		// Translate plugin metadata in plugins list.
		add_filter( 'all_plugins', array( $this, 'translate_plugin_meta' ) );

		// Add settings link on plugins page.
		add_filter( 'plugin_action_links_' . MVWEB_DE_BASENAME, array( $this, 'add_settings_link' ) );
	}

	/**
	 * Initialize cron schedule for session cleanup.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	private function init_cron(): void {
		add_action( 'mvweb_de_cleanup_sessions', array( $this, 'run_cleanup' ) );

		if ( ! wp_next_scheduled( 'mvweb_de_cleanup_sessions' ) ) {
			wp_schedule_event( time(), 'hourly', 'mvweb_de_cleanup_sessions' );
		}
	}

	/**
	 * Run scheduled cleanup of orphan files and expired sessions.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function run_cleanup(): void {
		$export_dir = MVweb_DE_File_Manager::get_export_dir();
		if ( ! is_dir( $export_dir ) ) {
			return;
		}

		$history   = get_option( 'mvweb_de_history', array() );
		$known     = array();
		$protected = array( 'index.php', '.htaccess' );

		foreach ( $history as $entry ) {
			if ( ! empty( $entry['filename'] ) ) {
				$known[] = $entry['filename'];
			}
		}

		// Remove orphan files (in directory but not in history).
		$files = glob( $export_dir . '*.{csv,txt}', GLOB_BRACE );
		if ( is_array( $files ) ) {
			foreach ( $files as $file ) {
				$basename = basename( $file );
				if ( in_array( $basename, $protected, true ) ) {
					continue;
				}
				if ( ! in_array( $basename, $known, true ) ) {
					// Only delete if file is older than 4 hours (session TTL).
					$mtime = filemtime( $file );
					if ( $mtime && ( time() - $mtime ) > 4 * HOUR_IN_SECONDS ) {
						wp_delete_file( $file );
					}
				}
			}
		}

		// Clean up expired locks.
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			"DELETE FROM {$wpdb->options}
			WHERE option_name LIKE '_transient_timeout_mvweb_de_lock_%'
			  AND option_value < UNIX_TIMESTAMP()"
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query(
			"DELETE FROM {$wpdb->options}
			WHERE option_name LIKE '_transient_mvweb_de_lock_%'
			  AND option_name NOT LIKE '_transient_timeout_%'
			  AND option_name NOT IN (
			    SELECT REPLACE(option_name, '_transient_timeout_', '_transient_')
			    FROM {$wpdb->options}
			    WHERE option_name LIKE '_transient_timeout_mvweb_de_lock_%'
			  )"
		);
	}

	/**
	 * Translate plugin metadata in plugins list.
	 *
	 * @since 0.1.0
	 * @param array $plugins Array of plugin data.
	 * @return array Modified plugins array.
	 */
	public function translate_plugin_meta( array $plugins ): array {
		$plugin_file = MVWEB_DE_BASENAME;

		if ( isset( $plugins[ $plugin_file ] ) ) {
			$plugins[ $plugin_file ]['Name']        = __( 'MVweb Data Export', 'mvweb-data-export' );
			$plugins[ $plugin_file ]['Title']       = __( 'MVweb Data Export', 'mvweb-data-export' );
			$plugins[ $plugin_file ]['Description'] = __( 'Export posts, pages, CPT and WooCommerce products to CSV/TXT.', 'mvweb-data-export' );
		}

		return $plugins;
	}

	/**
	 * Add settings link to plugins list.
	 *
	 * @since 0.1.0
	 * @param array $links Plugin action links.
	 * @return array Modified links.
	 */
	public function add_settings_link( array $links ): array {
		$settings_link = sprintf(
			'<a href="%s">%s</a>',
			esc_url( admin_url( 'admin.php?page=mvweb-data-export' ) ),
			esc_html__( 'Settings', 'mvweb-data-export' )
		);
		array_unshift( $links, $settings_link );

		return $links;
	}
}
