<?php
/**
 * AJAX handlers for MVweb Data Export.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_DE_Ajax
 *
 * Handles all AJAX requests for the plugin.
 *
 * @since 0.1.0
 */
class MVweb_DE_Ajax {

	/**
	 * Field registry instance.
	 *
	 * @var MVweb_DE_Field_Registry
	 */
	private MVweb_DE_Field_Registry $field_registry;

	/**
	 * Exporter instance.
	 *
	 * @var MVweb_DE_Exporter
	 */
	private MVweb_DE_Exporter $exporter;

	/**
	 * Preset manager instance.
	 *
	 * @var MVweb_DE_Preset_Manager
	 */
	private MVweb_DE_Preset_Manager $preset_manager;

	/**
	 * Constructor.
	 *
	 * @since 0.1.0
	 * @param MVweb_DE_Field_Registry $field_registry Field registry instance.
	 * @param MVweb_DE_Exporter       $exporter       Exporter instance.
	 * @param MVweb_DE_Preset_Manager $preset_manager Preset manager instance.
	 */
	public function __construct( MVweb_DE_Field_Registry $field_registry, MVweb_DE_Exporter $exporter, MVweb_DE_Preset_Manager $preset_manager ) {
		$this->field_registry  = $field_registry;
		$this->exporter        = $exporter;
		$this->preset_manager  = $preset_manager;

		add_action( 'wp_ajax_mvweb_de_save_settings', array( $this, 'save_settings' ) );
		add_action( 'wp_ajax_mvweb_de_get_fields', array( $this, 'get_fields' ) );
		add_action( 'wp_ajax_mvweb_de_get_filters', array( $this, 'get_filters' ) );
		add_action( 'wp_ajax_mvweb_de_preview', array( $this, 'preview' ) );
		add_action( 'wp_ajax_mvweb_de_start_export', array( $this, 'start_export' ) );
		add_action( 'wp_ajax_mvweb_de_export_batch', array( $this, 'export_batch' ) );
		add_action( 'wp_ajax_mvweb_de_cancel_export', array( $this, 'cancel_export' ) );
		add_action( 'wp_ajax_mvweb_de_download', array( $this, 'download' ) );
		add_action( 'wp_ajax_mvweb_de_save_preset', array( $this, 'save_preset' ) );
		add_action( 'wp_ajax_mvweb_de_delete_preset', array( $this, 'delete_preset' ) );
		add_action( 'wp_ajax_mvweb_de_get_presets', array( $this, 'get_presets' ) );
		add_action( 'wp_ajax_mvweb_de_get_history', array( $this, 'get_history' ) );
		add_action( 'wp_ajax_mvweb_de_delete_history', array( $this, 'delete_history' ) );
	}

	/**
	 * Verify AJAX request (nonce + capability).
	 *
	 * @since 0.1.0
	 * @param string $capability Required capability. Default 'edit_others_posts'.
	 * @return void Sends JSON error and dies if verification fails.
	 */
	private function verify_request( string $capability = 'edit_others_posts' ): void {
		check_ajax_referer( 'mvweb_de_action', 'nonce' );

		if ( ! current_user_can( $capability ) ) {
			wp_send_json_error(
				array(
					'code'    => 'insufficient_permissions',
					'message' => __( 'You do not have permission to perform this action.', 'mvweb-data-export' ),
				),
				403
			);
		}
	}

	/**
	 * Save settings handler.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function save_settings(): void {
		$this->verify_request( 'manage_options' );

		$settings = mvweb_de_get_settings();

		// Encoding.
		$encoding = isset( $_POST['encoding'] ) ? sanitize_key( $_POST['encoding'] ) : 'utf8bom';
		$settings['encoding'] = in_array( $encoding, array( 'utf8bom', 'utf8' ), true ) ? $encoding : 'utf8bom';

		// Header language.
		$header_lang = isset( $_POST['header_lang'] ) ? sanitize_key( $_POST['header_lang'] ) : 'auto';
		$settings['header_lang'] = in_array( $header_lang, array( 'auto', 'en', 'ru' ), true ) ? $header_lang : 'auto';

		// Batch size (10–500).
		$batch_size = isset( $_POST['batch_size'] ) ? absint( $_POST['batch_size'] ) : 100;
		$settings['batch_size'] = max( 10, min( 500, $batch_size ) );

		// Max records (100–50000).
		$max_records = isset( $_POST['max_records'] ) ? absint( $_POST['max_records'] ) : 10000;
		$settings['max_records'] = max( 100, min( 50000, $max_records ) );

		// Max history files (1–50).
		$max_history = isset( $_POST['max_history'] ) ? absint( $_POST['max_history'] ) : 10;
		$settings['max_history'] = max( 1, min( 50, $max_history ) );

		// Delete data on uninstall.
		$settings['delete_data'] = ! empty( $_POST['delete_data'] );

		update_option( 'mvweb_de_settings', $settings );

		wp_send_json_success(
			array(
				'message' => __( 'Settings saved successfully.', 'mvweb-data-export' ),
			)
		);
	}

	/**
	 * Get fields for a post type or taxonomy.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function get_fields(): void {
		$this->verify_request();

		$export_type = isset( $_POST['export_type'] ) ? sanitize_key( $_POST['export_type'] ) : 'posts';
		$source      = isset( $_POST['source'] ) ? sanitize_key( $_POST['source'] ) : '';

		if ( empty( $source ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Please select a source.', 'mvweb-data-export' ) )
			);
		}

		if ( 'taxonomies' === $export_type ) {
			$groups = $this->field_registry->get_fields_for_taxonomy( $source );
		} else {
			$groups = $this->field_registry->get_fields_for_post_type( $source );
		}

		wp_send_json_success( array( 'groups' => $groups ) );
	}

	/**
	 * Start export: validate, lock, count, create session.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function start_export(): void {
		$this->verify_request();

		$config = $this->parse_export_config();
		if ( is_wp_error( $config ) ) {
			wp_send_json_error( array( 'message' => $config->get_error_message() ) );
		}

		// Atomic lock (1 export per user).
		$user_id    = get_current_user_id();
		$lock_key   = 'mvweb_de_lock_' . $user_id;
		$session_id = wp_generate_uuid4();

		if ( ! $this->acquire_lock( $lock_key, $session_id ) ) {
			wp_send_json_error(
				array( 'message' => __( 'An export is already in progress. Please wait for it to complete.', 'mvweb-data-export' ) )
			);
		}

		// Check disk space.
		if ( ! MVweb_DE_Exporter::has_enough_disk_space() ) {
			delete_transient( $lock_key );
			wp_send_json_error(
				array( 'message' => __( 'Insufficient disk space. At least 50 MB required.', 'mvweb-data-export' ) )
			);
		}

		// Count records.
		$total = $this->exporter->count_records( $config );

		if ( 0 === $total ) {
			delete_transient( $lock_key );
			wp_send_json_error(
				array( 'message' => __( 'No records found matching your criteria.', 'mvweb-data-export' ) )
			);
		}

		$settings   = mvweb_de_get_settings();
		$batch_size = (int) $settings['batch_size'];

		// Generate file.
		$export_dir = MVweb_DE_File_Manager::get_export_dir();
		MVweb_DE_File_Manager::ensure_export_dir();

		$filename = MVweb_DE_CSV_Writer::generate_filename( $config['source'], $config['format'] );
		$filepath = $export_dir . $filename;

		// Create CSV writer and write headers.
		$use_bom = ( 'utf8bom' === $settings['encoding'] );
		$writer  = new MVweb_DE_CSV_Writer( $filepath, $config['format'], $use_bom );

		$headers = $this->exporter->get_headers( $config['fields'], $config['export_type'], $config['source'] );
		if ( ! $writer->create_with_headers( $headers ) ) {
			delete_transient( $lock_key );
			wp_send_json_error(
				array( 'message' => __( 'Failed to create export file. Check directory permissions.', 'mvweb-data-export' ) )
			);
		}

		// Create session.
		$session = array(
			'id'            => $session_id,
			'user_id'       => $user_id,
			'filepath'      => $filepath,
			'filename'      => $filename,
			'config'        => $config,
			'total'         => $total,
			'processed'     => 0,
			'current_batch' => 0,
			'last_activity' => time(),
			'status'        => 'in_progress',
			'started_at'    => time(),
		);

		set_transient( 'mvweb_de_session_' . $session_id, $session, 4 * HOUR_IN_SECONDS );

		wp_send_json_success(
			array(
				'session_id' => $session_id,
				'total'      => $total,
				'batch_size' => $batch_size,
			)
		);
	}

	/**
	 * Atomically acquire an export lock.
	 *
	 * Uses wp_cache_add() for object cache (atomic), falls back to
	 * INSERT IGNORE via $wpdb for the options table (also atomic).
	 *
	 * @since 0.1.0
	 * @param string $lock_key  Transient key for the lock.
	 * @param string $session_id Session ID to store as lock value.
	 * @return bool True if lock acquired, false if already locked.
	 */
	private function acquire_lock( string $lock_key, string $session_id ): bool {
		// If an external object cache is active, wp_cache_add() is atomic.
		if ( wp_using_ext_object_cache() ) {
			return wp_cache_add( $lock_key, $session_id, 'transient', 4 * HOUR_IN_SECONDS );
		}

		// Fallback: atomic INSERT IGNORE into options table.
		global $wpdb;

		$transient_key   = '_transient_' . $lock_key;
		$timeout_key     = '_transient_timeout_' . $lock_key;
		$expiration_time = time() + 4 * HOUR_IN_SECONDS;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$inserted = $wpdb->query(
			$wpdb->prepare(
				"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')",
				$transient_key,
				$session_id
			)
		);

		if ( $inserted ) {
			// Set the timeout entry.
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->query(
				$wpdb->prepare(
					"INSERT INTO {$wpdb->options} (option_name, option_value, autoload)
					VALUES (%s, %s, 'no')
					ON DUPLICATE KEY UPDATE option_value = %s",
					$timeout_key,
					$expiration_time,
					$expiration_time
				)
			);
			return true;
		}

		// Key exists — check if it has expired.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$timeout = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
				$timeout_key
			)
		);

		if ( $timeout && (int) $timeout < time() ) {
			// Expired — clean up and retry.
			delete_transient( $lock_key );
			return $this->acquire_lock( $lock_key, $session_id );
		}

		return false;
	}

	/**
	 * Export a single batch.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function export_batch(): void {
		$this->verify_request();

		$session_id = isset( $_POST['session_id'] ) ? sanitize_key( $_POST['session_id'] ) : '';
		if ( empty( $session_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid session.', 'mvweb-data-export' ) ) );
		}

		$session = get_transient( 'mvweb_de_session_' . $session_id );
		if ( ! $session ) {
			wp_send_json_error( array( 'message' => __( 'Export session expired.', 'mvweb-data-export' ) ) );
		}

		// Check if cancelled.
		if ( 'cancelled' === $session['status'] ) {
			wp_send_json_error( array( 'message' => __( 'Export was cancelled.', 'mvweb-data-export' ) ) );
		}

		// Verify session belongs to current user.
		if ( (int) $session['user_id'] !== get_current_user_id() ) {
			wp_send_json_error( array( 'message' => __( 'Session mismatch.', 'mvweb-data-export' ) ) );
		}

		$config     = $session['config'];
		$settings   = mvweb_de_get_settings();
		$batch_size = (int) $settings['batch_size'];
		$offset     = (int) $session['processed'];

		// Pass cursor_last_id from session to config for cursor-based pagination.
		if ( ! empty( $session['cursor_last_id'] ) ) {
			$config['cursor_last_id'] = (int) $session['cursor_last_id'];
		}

		// Create writer for append.
		$writer = new MVweb_DE_CSV_Writer(
			$session['filepath'],
			$config['format'],
			false // No BOM on append.
		);

		$result = $this->exporter->export_batch( $config, $offset, $batch_size, $writer );

		// Check for file write errors.
		if ( ! empty( $result['error'] ) ) {
			wp_send_json_error( array( 'message' => $result['error'] ) );
		}

		$processed = $offset + $result['processed'];

		$is_complete = ( $processed >= $session['total'] ) || ( 0 === $result['processed'] );

		// Update session.
		$session['processed']     = $processed;
		$session['current_batch'] = $session['current_batch'] + 1;
		$session['last_activity'] = time();

		// Save cursor_last_id for next batch.
		if ( ! empty( $result['cursor_last_id'] ) ) {
			$session['cursor_last_id'] = (int) $result['cursor_last_id'];
		}

		if ( $is_complete ) {
			$session['status'] = 'completed';

			// Save to history.
			$this->save_to_history( $session );

			// Remove lock.
			delete_transient( 'mvweb_de_lock_' . $session['user_id'] );
		}

		set_transient( 'mvweb_de_session_' . $session_id, $session, 4 * HOUR_IN_SECONDS );

		$progress_percent = $session['total'] > 0 ? round( ( $processed / $session['total'] ) * 100 ) : 100;

		$response = array(
			'processed'        => $processed,
			'total'            => $session['total'],
			'progress_percent' => $progress_percent,
			'is_complete'      => $is_complete,
			'memory_warning'   => $result['memory_warning'],
		);

		if ( $is_complete ) {
			$response['file_id'] = $this->get_history_file_id( $session['filename'] );
		}

		wp_send_json_success( $response );
	}

	/**
	 * Cancel export.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function cancel_export(): void {
		$this->verify_request();

		$session_id = isset( $_POST['session_id'] ) ? sanitize_key( $_POST['session_id'] ) : '';
		if ( empty( $session_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid session.', 'mvweb-data-export' ) ) );
		}

		$session = get_transient( 'mvweb_de_session_' . $session_id );
		if ( ! $session ) {
			wp_send_json_error( array( 'message' => __( 'Session not found.', 'mvweb-data-export' ) ) );
		}

		// Verify session belongs to current user.
		if ( (int) $session['user_id'] !== get_current_user_id() ) {
			wp_send_json_error( array( 'message' => __( 'Session mismatch.', 'mvweb-data-export' ) ) );
		}

		// Update status.
		$session['status'] = 'cancelled';
		set_transient( 'mvweb_de_session_' . $session_id, $session, 4 * HOUR_IN_SECONDS );

		// Delete temp file.
		if ( ! empty( $session['filepath'] ) && file_exists( $session['filepath'] ) ) {
			wp_delete_file( $session['filepath'] );
		}

		// Remove lock.
		delete_transient( 'mvweb_de_lock_' . $session['user_id'] );

		wp_send_json_success(
			array( 'message' => __( 'Export cancelled.', 'mvweb-data-export' ) )
		);
	}

	/**
	 * Download an export file.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function download(): void {
		// Use GET nonce for download links.
		check_ajax_referer( 'mvweb_de_action', 'nonce' );

		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( esc_html__( 'You do not have permission to download this file.', 'mvweb-data-export' ), 403 );
		}

		$file_id = isset( $_GET['file_id'] ) ? sanitize_key( $_GET['file_id'] ) : '';
		if ( empty( $file_id ) ) {
			wp_die( esc_html__( 'Invalid file ID.', 'mvweb-data-export' ), 400 );
		}

		// Find in history.
		$history = get_option( 'mvweb_de_history', array() );
		$entry   = null;

		foreach ( $history as $item ) {
			if ( $item['id'] === $file_id ) {
				$entry = $item;
				break;
			}
		}

		if ( ! $entry ) {
			wp_die( esc_html__( 'File not found in history.', 'mvweb-data-export' ), 404 );
		}

		// IDOR check: editors can only download their own files.
		if ( ! current_user_can( 'manage_options' ) && (int) $entry['user_id'] !== get_current_user_id() ) {
			wp_die( esc_html__( 'You do not have permission to download this file.', 'mvweb-data-export' ), 403 );
		}

		// Sanitize filepath: strip null bytes and trim.
		$filepath = trim( str_replace( "\0", '', $entry['filepath'] ) );

		// Whitelist extensions.
		$ext = pathinfo( $filepath, PATHINFO_EXTENSION );
		if ( ! in_array( $ext, array( 'csv', 'txt' ), true ) ) {
			wp_die( esc_html__( 'Invalid file type.', 'mvweb-data-export' ), 400 );
		}

		// Path traversal protection.
		$real_path  = realpath( $filepath );
		$export_dir = realpath( MVweb_DE_File_Manager::get_export_dir() );

		if ( ! $real_path || ! $export_dir || ! str_starts_with( $real_path, $export_dir ) ) {
			wp_die( esc_html__( 'Invalid file path.', 'mvweb-data-export' ), 400 );
		}

		if ( ! file_exists( $real_path ) ) {
			wp_die( esc_html__( 'File no longer exists.', 'mvweb-data-export' ), 404 );
		}

		// Sanitize filename for Content-Disposition header (prevent CRLF injection).
		$safe_filename = str_replace( array( '"', "\r", "\n", "\0" ), '', $entry['filename'] );

		// Send file.
		nocache_headers();
		header( 'Content-Type: application/octet-stream' );
		header( 'Content-Disposition: attachment; filename="' . $safe_filename . '"' );
		header( 'Content-Length: ' . filesize( $real_path ) );
		header( 'X-Content-Type-Options: nosniff' );

		// Chunk-read (8 KB).
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		$handle = fopen( $real_path, 'rb' );
		if ( $handle ) {
			while ( ! feof( $handle ) ) {
				// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread
				echo fread( $handle, 8192 );
				flush();
			}
			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		}

		exit;
	}

	/**
	 * Parse and validate export configuration from POST data.
	 *
	 * @since 0.1.0
	 * @return array|WP_Error Validated config or WP_Error.
	 */
	private function parse_export_config() {
		$export_type = isset( $_POST['export_type'] ) ? sanitize_key( $_POST['export_type'] ) : 'posts';
		if ( ! in_array( $export_type, array( 'posts', 'taxonomies' ), true ) ) {
			return new WP_Error( 'invalid_type', __( 'Invalid export type.', 'mvweb-data-export' ) );
		}

		$source = isset( $_POST['source'] ) ? sanitize_key( $_POST['source'] ) : '';
		if ( empty( $source ) ) {
			return new WP_Error( 'no_source', __( 'Please select a source.', 'mvweb-data-export' ) );
		}

		// Validate source exists.
		if ( 'posts' === $export_type ) {
			if ( ! post_type_exists( $source ) ) {
				return new WP_Error( 'invalid_source', __( 'Invalid post type.', 'mvweb-data-export' ) );
			}
		} else {
			if ( ! taxonomy_exists( $source ) ) {
				return new WP_Error( 'invalid_source', __( 'Invalid taxonomy.', 'mvweb-data-export' ) );
			}
		}

		// Fields.
		$fields = isset( $_POST['fields'] ) && is_array( $_POST['fields'] )
			? array_map( 'sanitize_key', $_POST['fields'] )
			: array();

		if ( empty( $fields ) ) {
			return new WP_Error( 'no_fields', __( 'Please select at least one field.', 'mvweb-data-export' ) );
		}

		// Format.
		$format = isset( $_POST['format'] ) ? sanitize_key( $_POST['format'] ) : 'csv';
		if ( ! in_array( $format, array( 'csv', 'txt' ), true ) ) {
			$format = 'csv';
		}

		// URL format.
		$url_format = isset( $_POST['url_format'] ) ? sanitize_key( $_POST['url_format'] ) : 'full';
		if ( ! in_array( $url_format, array( 'full', 'relative' ), true ) ) {
			$url_format = 'full';
		}

		// Sort.
		$sort_by = isset( $_POST['sort_by'] ) ? sanitize_key( $_POST['sort_by'] ) : 'post_date';
		$sort_whitelist = array( 'post_date', 'post_title', 'ID' );
		if ( ! in_array( $sort_by, $sort_whitelist, true ) ) {
			$sort_by = 'post_date';
		}

		$sort_order = isset( $_POST['sort_order'] ) ? strtoupper( sanitize_key( $_POST['sort_order'] ) ) : 'DESC';
		if ( ! in_array( $sort_order, array( 'ASC', 'DESC' ), true ) ) {
			$sort_order = 'DESC';
		}

		// Variation mode (WooCommerce only).
		$variation_mode = isset( $_POST['variation_mode'] ) ? sanitize_key( $_POST['variation_mode'] ) : 'inline';
		if ( ! in_array( $variation_mode, array( 'separate', 'inline' ), true ) ) {
			$variation_mode = 'inline';
		}

		// Filters (only for posts export type).
		$filters = array();
		if ( 'posts' === $export_type ) {
			$filters = $this->parse_filters( $source );
		}

		return array(
			'export_type'    => $export_type,
			'source'         => $source,
			'fields'         => $fields,
			'format'         => $format,
			'url_format'     => $url_format,
			'sort_by'        => $sort_by,
			'sort_order'     => $sort_order,
			'variation_mode' => $variation_mode,
			'filters'        => $filters,
		);
	}

	/**
	 * Get available filters for a post type (statuses, taxonomies, authors).
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function get_filters(): void {
		$this->verify_request();

		$source = isset( $_POST['source'] ) ? sanitize_key( $_POST['source'] ) : '';
		if ( empty( $source ) || ! post_type_exists( $source ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid post type.', 'mvweb-data-export' ) ) );
		}

		// Statuses — whitelist via get_post_stati().
		$all_statuses = get_post_stati( array( 'internal' => false ), 'objects' );
		$statuses     = array();
		foreach ( $all_statuses as $status_obj ) {
			$statuses[] = array(
				'value' => $status_obj->name,
				'label' => $status_obj->label,
			);
		}

		// Taxonomies with terms for this post type.
		$tax_objects = get_object_taxonomies( $source, 'objects' );
		$taxonomies  = array();
		foreach ( $tax_objects as $tax ) {
			if ( ! $tax->public && ! $tax->publicly_queryable ) {
				continue;
			}
			$terms = get_terms(
				array(
					'taxonomy'   => $tax->name,
					'hide_empty' => false,
					'number'     => 200,
				)
			);
			$term_list = array();
			if ( ! is_wp_error( $terms ) ) {
				foreach ( $terms as $term ) {
					$term_list[] = array(
						'value' => $term->term_id,
						'label' => $term->name,
					);
				}
			}
			$taxonomies[] = array(
				'slug'  => $tax->name,
				'label' => $tax->label,
				'terms' => $term_list,
			);
		}

		// Authors — users who have posts of this type.
		$authors     = get_users(
			array(
				'who'     => 'authors',
				'orderby' => 'display_name',
				'order'   => 'ASC',
				'fields'  => array( 'ID', 'display_name' ),
			)
		);
		$author_list = array();
		foreach ( $authors as $author ) {
			$author_list[] = array(
				'value' => (int) $author->ID,
				'label' => $author->display_name,
			);
		}

		$response = array(
			'statuses'   => $statuses,
			'taxonomies' => $taxonomies,
			'authors'    => $author_list,
		);

		// WooCommerce-specific filter options.
		if ( 'product' === $source && class_exists( 'WooCommerce' ) && MVweb_DE_WC_Fields::is_available() ) {
			$response['has_wc_filters'] = true;

			// Stock status options.
			$stock_options = array();
			if ( function_exists( 'wc_get_product_stock_status_options' ) ) {
				foreach ( wc_get_product_stock_status_options() as $key => $label ) {
					$stock_options[] = array(
						'value' => $key,
						'label' => $label,
					);
				}
			}
			$response['stock_statuses'] = $stock_options;

			// Product type options.
			$type_options = array();
			if ( function_exists( 'wc_get_product_types' ) ) {
				foreach ( wc_get_product_types() as $key => $label ) {
					$type_options[] = array(
						'value' => $key,
						'label' => $label,
					);
				}
			}
			$response['product_types'] = $type_options;
		}

		wp_send_json_success( $response );
	}

	/**
	 * Preview export — return first 10 rows as JSON.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function preview(): void {
		$this->verify_request();

		$config = $this->parse_export_config();
		if ( is_wp_error( $config ) ) {
			wp_send_json_error( array( 'message' => $config->get_error_message() ) );
		}

		// Get headers.
		$headers = $this->exporter->get_headers( $config['fields'], $config['export_type'], $config['source'] );

		// Count total records.
		$total = $this->exporter->count_records( $config );

		// Get first 10 rows.
		$rows = $this->exporter->get_preview_rows( $config, 10 );

		// Truncate long values and escape (defense-in-depth).
		$max_len = 200;
		foreach ( $rows as &$row ) {
			foreach ( $row as &$cell ) {
				if ( mb_strlen( $cell ) > $max_len ) {
					$cell = mb_substr( $cell, 0, $max_len ) . '...';
				}
				$cell = esc_html( $cell );
			}
		}
		unset( $row, $cell );

		$headers = array_map( 'esc_html', $headers );

		wp_send_json_success(
			array(
				'headers' => $headers,
				'rows'    => $rows,
				'total'   => $total,
			)
		);
	}

	/**
	 * Parse filter values from POST data.
	 *
	 * @since 0.1.0
	 * @param string $source Post type slug.
	 * @return array Parsed filters.
	 */
	private function parse_filters( string $source ): array {
		$filters = array();

		// Post status — whitelist against registered statuses.
		if ( ! empty( $_POST['filter_status'] ) && is_array( $_POST['filter_status'] ) ) {
			$valid_statuses = array_keys( get_post_stati( array( 'internal' => false ) ) );
			$statuses       = array_map( 'sanitize_key', $_POST['filter_status'] );
			$statuses       = array_intersect( $statuses, $valid_statuses );
			if ( ! empty( $statuses ) ) {
				$filters['post_status'] = array_values( $statuses );
			}
		}

		// Taxonomy terms.
		if ( ! empty( $_POST['filter_taxonomy'] ) ) {
			$taxonomy = sanitize_key( $_POST['filter_taxonomy'] );
			// Validate taxonomy belongs to this post type.
			$valid_taxonomies = get_object_taxonomies( $source );
			if ( in_array( $taxonomy, $valid_taxonomies, true ) && ! empty( $_POST['filter_terms'] ) && is_array( $_POST['filter_terms'] ) ) {
				$term_ids = array_map( 'absint', $_POST['filter_terms'] );
				$term_ids = array_filter( $term_ids );
				if ( ! empty( $term_ids ) ) {
					$filters['taxonomy']  = $taxonomy;
					$filters['term_ids']  = $term_ids;
				}
			}
		}

		// Date range.
		if ( ! empty( $_POST['filter_date_from'] ) ) {
			$date_from = sanitize_text_field( $_POST['filter_date_from'] );
			if ( $this->validate_date( $date_from ) ) {
				$filters['date_from'] = $date_from;
			}
		}

		if ( ! empty( $_POST['filter_date_to'] ) ) {
			$date_to = sanitize_text_field( $_POST['filter_date_to'] );
			if ( $this->validate_date( $date_to ) ) {
				$filters['date_to'] = $date_to;
			}
		}

		// Author.
		if ( ! empty( $_POST['filter_author'] ) ) {
			$author_id = absint( $_POST['filter_author'] );
			if ( $author_id > 0 ) {
				$filters['author'] = $author_id;
			}
		}

		// WooCommerce-specific filters (only for product post type).
		if ( 'product' === $source && class_exists( 'WooCommerce' ) ) {
			// Price range.
			if ( isset( $_POST['filter_price_min'] ) && '' !== $_POST['filter_price_min'] ) {
				$filters['price_min'] = max( 0, floatval( $_POST['filter_price_min'] ) );
			}
			if ( isset( $_POST['filter_price_max'] ) && '' !== $_POST['filter_price_max'] ) {
				$filters['price_max'] = max( 0, floatval( $_POST['filter_price_max'] ) );
			}

			// Stock status.
			if ( ! empty( $_POST['filter_stock_status'] ) && is_array( $_POST['filter_stock_status'] ) ) {
				$valid_stock = array( 'instock', 'outofstock', 'onbackorder' );
				$stock       = array_map( 'sanitize_key', $_POST['filter_stock_status'] );
				$stock       = array_intersect( $stock, $valid_stock );
				if ( ! empty( $stock ) ) {
					$filters['stock_status'] = array_values( $stock );
				}
			}

			// Product type.
			if ( ! empty( $_POST['filter_product_type'] ) && is_array( $_POST['filter_product_type'] ) ) {
				$valid_types = array( 'simple', 'variable', 'grouped', 'external' );
				$types       = array_map( 'sanitize_key', $_POST['filter_product_type'] );
				$types       = array_intersect( $types, $valid_types );
				if ( ! empty( $types ) ) {
					$filters['product_type'] = array_values( $types );
				}
			}
		}

		return $filters;
	}

	/**
	 * Validate a date string (YYYY-MM-DD).
	 *
	 * @since 0.1.0
	 * @param string $date Date string.
	 * @return bool True if valid.
	 */
	private function validate_date( string $date ): bool {
		$dt = \DateTime::createFromFormat( 'Y-m-d', $date );
		return $dt && $dt->format( 'Y-m-d' ) === $date;
	}

	/**
	 * Save a completed export to history.
	 *
	 * @since 0.1.0
	 * @param array $session Session data.
	 * @return void
	 */
	private function save_to_history( array $session ): void {
		$history  = get_option( 'mvweb_de_history', array() );
		$settings = mvweb_de_get_settings();

		$filesize = file_exists( $session['filepath'] ) ? filesize( $session['filepath'] ) : 0;

		$entry = array(
			'id'         => bin2hex( random_bytes( 8 ) ),
			'filename'   => $session['filename'],
			'filepath'   => $session['filepath'],
			'post_type'  => $session['config']['source'],
			'format'     => $session['config']['format'],
			'rows'       => $session['processed'],
			'filesize'   => $filesize,
			'user_id'    => $session['user_id'],
			'created_at' => wp_date( 'Y-m-d H:i:s' ),
		);

		// Prepend new entry.
		array_unshift( $history, $entry );

		// FIFO: remove old entries beyond limit.
		$max_history = (int) $settings['max_history'];
		while ( count( $history ) > $max_history ) {
			$old = array_pop( $history );
			// Delete old file.
			if ( ! empty( $old['filepath'] ) && file_exists( $old['filepath'] ) ) {
				wp_delete_file( $old['filepath'] );
			}
		}

		update_option( 'mvweb_de_history', $history, false );
	}

	/**
	 * Get history file ID by filename.
	 *
	 * @since 0.1.0
	 * @param string $filename Filename to search.
	 * @return string File ID or empty string.
	 */
	private function get_history_file_id( string $filename ): string {
		$history = get_option( 'mvweb_de_history', array() );

		foreach ( $history as $item ) {
			if ( $item['filename'] === $filename ) {
				return $item['id'];
			}
		}

		return '';
	}

	/**
	 * Save a preset.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function save_preset(): void {
		$this->verify_request();

		$name = isset( $_POST['preset_name'] ) ? sanitize_text_field( $_POST['preset_name'] ) : '';
		if ( empty( $name ) ) {
			wp_send_json_error( array( 'message' => __( 'Preset name is required.', 'mvweb-data-export' ) ) );
		}

		$config = array(
			'export_type'    => isset( $_POST['export_type'] ) ? sanitize_key( $_POST['export_type'] ) : 'posts',
			'source'         => isset( $_POST['source'] ) ? sanitize_key( $_POST['source'] ) : '',
			'fields'         => isset( $_POST['fields'] ) && is_array( $_POST['fields'] )
				? array_map( 'sanitize_key', $_POST['fields'] )
				: array(),
			'format'         => isset( $_POST['format'] ) ? sanitize_key( $_POST['format'] ) : 'csv',
			'url_format'     => isset( $_POST['url_format'] ) ? sanitize_key( $_POST['url_format'] ) : 'full',
			'sort_by'        => isset( $_POST['sort_by'] ) ? sanitize_key( $_POST['sort_by'] ) : 'post_date',
			'sort_order'     => isset( $_POST['sort_order'] ) ? sanitize_key( $_POST['sort_order'] ) : 'DESC',
			'variation_mode' => isset( $_POST['variation_mode'] ) ? sanitize_key( $_POST['variation_mode'] ) : 'inline',
			'filters'        => $this->collect_filter_post_data(),
		);

		$result = $this->preset_manager->save_preset( $name, $config );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				'message' => __( 'Preset saved.', 'mvweb-data-export' ),
				'preset'  => $result,
			)
		);
	}

	/**
	 * Delete a preset.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function delete_preset(): void {
		$this->verify_request();

		$preset_id = isset( $_POST['preset_id'] ) ? sanitize_key( $_POST['preset_id'] ) : '';
		if ( empty( $preset_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid preset ID.', 'mvweb-data-export' ) ) );
		}

		$result = $this->preset_manager->delete_preset( $preset_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success(
			array( 'message' => __( 'Preset deleted.', 'mvweb-data-export' ) )
		);
	}

	/**
	 * Get presets for the current user.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function get_presets(): void {
		$this->verify_request();

		$presets = $this->preset_manager->get_presets();

		// Add author display name for admin view.
		foreach ( $presets as &$preset ) {
			$user = get_userdata( (int) $preset['user_id'] );
			$preset['user_name'] = $user ? $user->display_name : __( 'Unknown', 'mvweb-data-export' );
		}
		unset( $preset );

		wp_send_json_success( array( 'presets' => $presets ) );
	}

	/**
	 * Get export history for the current user.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function get_history(): void {
		$this->verify_request();

		$history = get_option( 'mvweb_de_history', array() );
		$user_id = get_current_user_id();
		$is_admin = current_user_can( 'manage_options' );

		$items = array();

		foreach ( $history as $entry ) {
			// IDOR: editors see only their own.
			if ( ! $is_admin && (int) $entry['user_id'] !== $user_id ) {
				continue;
			}

			$file_exists = ! empty( $entry['filepath'] ) && file_exists( $entry['filepath'] );
			$user        = get_userdata( (int) $entry['user_id'] );

			$items[] = array(
				'id'          => $entry['id'],
				'filename'    => $entry['filename'],
				'post_type'   => $entry['post_type'],
				'format'      => $entry['format'],
				'rows'        => $entry['rows'],
				'filesize'    => size_format( $entry['filesize'] ),
				'user_name'   => $user ? $user->display_name : __( 'Unknown', 'mvweb-data-export' ),
				'created_at'  => $entry['created_at'],
				'file_exists' => $file_exists,
			);
		}

		wp_send_json_success( array( 'history' => $items ) );
	}

	/**
	 * Delete a history entry and its file.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function delete_history(): void {
		$this->verify_request();

		$file_id = isset( $_POST['file_id'] ) ? sanitize_key( $_POST['file_id'] ) : '';
		if ( empty( $file_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid file ID.', 'mvweb-data-export' ) ) );
		}

		$history = get_option( 'mvweb_de_history', array() );
		$user_id = get_current_user_id();
		$found   = false;

		foreach ( $history as $index => $entry ) {
			if ( $entry['id'] === $file_id ) {
				// IDOR check.
				if ( ! current_user_can( 'manage_options' ) && (int) $entry['user_id'] !== $user_id ) {
					wp_send_json_error(
						array( 'message' => __( 'You do not have permission to delete this file.', 'mvweb-data-export' ) ),
						403
					);
				}

				// Delete the file.
				if ( ! empty( $entry['filepath'] ) && file_exists( $entry['filepath'] ) ) {
					wp_delete_file( $entry['filepath'] );
				}

				unset( $history[ $index ] );
				$found = true;
				break;
			}
		}

		if ( ! $found ) {
			wp_send_json_error( array( 'message' => __( 'File not found in history.', 'mvweb-data-export' ) ) );
		}

		update_option( 'mvweb_de_history', array_values( $history ), false );

		wp_send_json_success(
			array( 'message' => __( 'History entry deleted.', 'mvweb-data-export' ) )
		);
	}

	/**
	 * Collect raw filter values from POST data for preset storage.
	 *
	 * Unlike parse_filters(), this preserves the POST key names
	 * so the preset can be restored to the form.
	 *
	 * @since 0.1.0
	 * @return array Filter POST data (sanitized).
	 */
	private function collect_filter_post_data(): array {
		$filters = array();

		if ( ! empty( $_POST['filter_status'] ) && is_array( $_POST['filter_status'] ) ) {
			$filters['filter_status'] = array_map( 'sanitize_key', $_POST['filter_status'] );
		}

		if ( ! empty( $_POST['filter_taxonomy'] ) ) {
			$filters['filter_taxonomy'] = sanitize_key( $_POST['filter_taxonomy'] );
		}

		if ( ! empty( $_POST['filter_terms'] ) && is_array( $_POST['filter_terms'] ) ) {
			$filters['filter_terms'] = array_map( 'absint', $_POST['filter_terms'] );
		}

		if ( ! empty( $_POST['filter_date_from'] ) ) {
			$filters['filter_date_from'] = sanitize_text_field( $_POST['filter_date_from'] );
		}

		if ( ! empty( $_POST['filter_date_to'] ) ) {
			$filters['filter_date_to'] = sanitize_text_field( $_POST['filter_date_to'] );
		}

		if ( ! empty( $_POST['filter_author'] ) ) {
			$filters['filter_author'] = absint( $_POST['filter_author'] );
		}

		// WooCommerce-specific filter data.
		if ( isset( $_POST['filter_price_min'] ) && '' !== $_POST['filter_price_min'] ) {
			$filters['filter_price_min'] = floatval( $_POST['filter_price_min'] );
		}

		if ( isset( $_POST['filter_price_max'] ) && '' !== $_POST['filter_price_max'] ) {
			$filters['filter_price_max'] = floatval( $_POST['filter_price_max'] );
		}

		if ( ! empty( $_POST['filter_stock_status'] ) && is_array( $_POST['filter_stock_status'] ) ) {
			$filters['filter_stock_status'] = array_map( 'sanitize_key', $_POST['filter_stock_status'] );
		}

		if ( ! empty( $_POST['filter_product_type'] ) && is_array( $_POST['filter_product_type'] ) ) {
			$filters['filter_product_type'] = array_map( 'sanitize_key', $_POST['filter_product_type'] );
		}

		return $filters;
	}
}
