<?php
/**
 * Admin class for MVweb Data Export.
 *
 * Registers submenu, enqueues assets, renders admin pages.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_DE_Admin
 *
 * @since 0.1.0
 */
class MVweb_DE_Admin {

	/**
	 * Constructor.
	 *
	 * @since 0.1.0
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Register plugin submenu under MVweb.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function register_menu(): void {
		$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

		add_submenu_page(
			$parent_slug,
			__( 'Data Export', 'mvweb-data-export' ),
			__( 'Data Export', 'mvweb-data-export' ),
			'edit_others_posts',
			'mvweb-data-export',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Enqueue admin styles and scripts.
	 *
	 * Only loads on the plugin page.
	 *
	 * @since 0.1.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_assets( string $hook ): void {
		if ( 'mvweb_page_mvweb-data-export' !== $hook ) {
			return;
		}

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		// MVweb UI Kit — base styles (DO NOT MODIFY this file).
		wp_enqueue_style(
			'mvweb-de-admin',
			MVWEB_DE_URL . 'admin/css/admin' . $suffix . '.css',
			array(),
			MVWEB_DE_VERSION
		);

		// Plugin-specific styles (depends on admin.css).
		wp_enqueue_style(
			'mvweb-de-plugin',
			MVWEB_DE_URL . 'admin/css/plugin' . $suffix . '.css',
			array( 'mvweb-de-admin' ),
			MVWEB_DE_VERSION
		);

		// jQuery UI Sortable for drag-n-drop field selection.
		wp_enqueue_script( 'jquery-ui-sortable' );

		// SelectWoo (bundled with WooCommerce) for enhanced multi-selects.
		$js_deps = array( 'jquery', 'jquery-ui-sortable' );
		if ( class_exists( 'WooCommerce' ) ) {
			wp_enqueue_script( 'selectWoo' );
			wp_enqueue_style( 'select2' );
			$js_deps[] = 'selectWoo';
		}

		wp_enqueue_script(
			'mvweb-de-admin',
			MVWEB_DE_URL . 'admin/js/admin' . $suffix . '.js',
			$js_deps,
			MVWEB_DE_VERSION,
			true
		);

		wp_localize_script(
			'mvweb-de-admin',
			'mvwebDeAdmin',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'mvweb_de_action' ),
				'has_wc'         => class_exists( 'WooCommerce' ),
				'has_select_woo' => class_exists( 'WooCommerce' ),
				'is_admin'       => current_user_can( 'manage_options' ),
				'i18n'     => array(
					'saving'         => __( 'Saving...', 'mvweb-data-export' ),
					'saved'          => __( 'Settings saved.', 'mvweb-data-export' ),
					'error'          => __( 'An error occurred.', 'mvweb-data-export' ),
					'exporting'      => __( 'Exporting...', 'mvweb-data-export' ),
					'completed'      => __( 'Export completed!', 'mvweb-data-export' ),
					'cancelled'      => __( 'Export cancelled.', 'mvweb-data-export' ),
					'confirmCancel'  => __( 'Are you sure you want to cancel the export?', 'mvweb-data-export' ),
					'selectFields'   => __( 'Please select at least one field.', 'mvweb-data-export' ),
					'processing'     => __( 'Processing...', 'mvweb-data-export' ),
					'downloading'    => __( 'Downloading...', 'mvweb-data-export' ),
					'noResults'      => __( 'No records found.', 'mvweb-data-export' ),
					'memoryWarning'  => __( 'Memory limit reached. Please reduce batch size in Settings.', 'mvweb-data-export' ),
					'diskSpaceError' => __( 'Insufficient disk space.', 'mvweb-data-export' ),
					'loadingFields'  => __( 'Loading fields...', 'mvweb-data-export' ),
					'selectAll'      => __( 'Select All', 'mvweb-data-export' ),
					'clearAll'       => __( 'Clear All', 'mvweb-data-export' ),
					'export'         => _x( 'Export', 'button label', 'mvweb-data-export' ),
					'preview'        => __( 'Preview', 'mvweb-data-export' ),
					'loading'        => __( 'Loading...', 'mvweb-data-export' ),
					'totalRecords'   => __( 'Total records', 'mvweb-data-export' ),
					'allAuthors'     => __( 'All Authors', 'mvweb-data-export' ),
					'allTerms'            => __( 'All', 'mvweb-data-export' ),
					'loadPreset'          => __( 'Load Preset...', 'mvweb-data-export' ),
					'presetNamePrompt'    => __( 'Enter a name for this preset:', 'mvweb-data-export' ),
					'load'                => __( 'Load', 'mvweb-data-export' ),
					'deleteLabel'         => __( 'Delete', 'mvweb-data-export' ),
					'confirmDeletePreset' => __( 'Are you sure you want to delete this preset?', 'mvweb-data-export' ),
					'confirmDeleteHistory' => __( 'Are you sure you want to delete this file?', 'mvweb-data-export' ),
					'postsCpt'            => __( 'Posts / CPT', 'mvweb-data-export' ),
					'taxonomies'          => __( 'Taxonomies', 'mvweb-data-export' ),
					'fileDeleted'         => __( 'file deleted', 'mvweb-data-export' ),
				),
			)
		);
	}

	/**
	 * Render the admin page.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function render_page(): void {
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'mvweb-data-export' ) );
		}

		include MVWEB_DE_PATH . 'admin/views/page-export.php';
	}
}
