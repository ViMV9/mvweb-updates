<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick Start', 'mvweb-data-export' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Choose export type', 'mvweb-data-export' ); ?></strong>
			<p><?php esc_html_e( 'Select "Posts / CPT" to export posts, pages, or custom post types. Select "Taxonomies" to export categories, tags, or custom taxonomies.', 'mvweb-data-export' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Select source and fields', 'mvweb-data-export' ); ?></strong>
			<p><?php esc_html_e( 'Choose the specific post type or taxonomy, then drag the fields you want into the "Selected Fields" column. You can reorder them.', 'mvweb-data-export' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Apply filters (optional)', 'mvweb-data-export' ); ?></strong>
			<p><?php esc_html_e( 'Filter by status, taxonomy terms, date range, author, or WooCommerce-specific criteria (price, stock, product type).', 'mvweb-data-export' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Preview and export', 'mvweb-data-export' ); ?></strong>
			<p><?php esc_html_e( 'Click "Preview" to check first 10 rows, then "Export" to generate the file. The file will download automatically.', 'mvweb-data-export' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Features', 'mvweb-data-export' ); ?></div>
	</div>

	<h4><?php esc_html_e( 'Export Capabilities', 'mvweb-data-export' ); ?></h4>
	<ul>
		<li><?php esc_html_e( 'Export posts, pages, and custom post types (CPT)', 'mvweb-data-export' ); ?></li>
		<li><?php esc_html_e( 'Export taxonomies (categories, tags, custom taxonomies)', 'mvweb-data-export' ); ?></li>
		<li><?php esc_html_e( 'WooCommerce products support with variations', 'mvweb-data-export' ); ?></li>
		<li><?php esc_html_e( 'CSV and TXT (TSV) output formats', 'mvweb-data-export' ); ?></li>
		<li><?php esc_html_e( 'Batch processing for large datasets (up to 50,000 records)', 'mvweb-data-export' ); ?></li>
	</ul>

	<h4><?php esc_html_e( 'Presets', 'mvweb-data-export' ); ?></h4>
	<ul>
		<li><?php esc_html_e( 'Save export configurations as presets for quick reuse', 'mvweb-data-export' ); ?></li>
		<li><?php esc_html_e( 'Load presets from the Export tab or the Presets tab', 'mvweb-data-export' ); ?></li>
		<li><?php esc_html_e( 'Presets store fields, filters, format, and sorting options', 'mvweb-data-export' ); ?></li>
	</ul>

	<h4><?php esc_html_e( 'History', 'mvweb-data-export' ); ?></h4>
	<ul>
		<li><?php esc_html_e( 'Previously exported files are saved in history', 'mvweb-data-export' ); ?></li>
		<li><?php esc_html_e( 'Download or delete old export files', 'mvweb-data-export' ); ?></li>
		<li><?php esc_html_e( 'Automatic cleanup based on max history setting', 'mvweb-data-export' ); ?></li>
	</ul>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Frequently Asked Questions', 'mvweb-data-export' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The exported CSV opens with broken characters in Excel', 'mvweb-data-export' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Go to Settings tab and set Encoding to "UTF-8 with BOM". This ensures Excel correctly detects the encoding. Re-export after changing the setting.', 'mvweb-data-export' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How to export WooCommerce product variations?', 'mvweb-data-export' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Select "Products" as the source. When WooCommerce is active, a "Variations" option will appear. Choose "Inline" to show all variations in one cell, or "Separate rows" to output each variation as its own row.', 'mvweb-data-export' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Export is slow or times out', 'mvweb-data-export' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Try reducing the "Batch size" in Settings (e.g., to 50). The plugin processes data in batches via AJAX, so a smaller batch size is safer for servers with limited resources. Also check the System Information section for PHP limits.', 'mvweb-data-export' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Who can use Data Export?', 'mvweb-data-export' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Administrators have full access (all tabs, all data). Editors can export published content and their own posts of any status. The Settings tab is only visible to administrators.', 'mvweb-data-export' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-data-export' ); ?></div>
	</div>
	<p>
		<?php
		echo wp_kses(
			sprintf(
				/* translators: %s: MVweb plugin URL */
				__( 'Need help? Visit %s for documentation and support.', 'mvweb-data-export' ),
				'<a href="' . esc_url( 'https://mvweb.ru/plugins/mvweb-data-export' ) . '" target="_blank" rel="noopener noreferrer">mvweb.ru</a>'
			),
			array(
				'a' => array(
					'href'   => array(),
					'target' => array(),
					'rel'    => array(),
				),
			)
		);
		?>
	</p>
	<p>
		<strong><?php esc_html_e( 'Version:', 'mvweb-data-export' ); ?></strong> <?php echo esc_html( MVWEB_DE_VERSION ); ?>
	</p>
</div>
