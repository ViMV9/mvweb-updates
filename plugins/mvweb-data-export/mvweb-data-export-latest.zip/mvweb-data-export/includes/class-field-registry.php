<?php
/**
 * Field Registry for MVweb Data Export.
 *
 * Defines available export fields per post type, grouped by category.
 * Discovers meta keys dynamically (cached in transient).
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_DE_Field_Registry
 *
 * @since 0.1.0
 */
class MVweb_DE_Field_Registry {

	/**
	 * Transient TTL for meta keys cache (1 hour).
	 *
	 * @var int
	 */
	private const META_CACHE_TTL = HOUR_IN_SECONDS;

	/**
	 * Maximum number of meta keys to retrieve per post type.
	 *
	 * @var int
	 */
	private const META_KEYS_LIMIT = 200;

	/**
	 * Get all available fields for a post type (posts/CPT export).
	 *
	 * @since 0.1.0
	 * @param string $post_type Post type slug.
	 * @return array Grouped fields: [ 'group_key' => [ 'label' => ..., 'fields' => [...] ] ].
	 */
	public function get_fields_for_post_type( string $post_type ): array {
		$groups = array();

		// Basic fields.
		$groups['basic'] = array(
			'label'  => __( 'Basic', 'mvweb-data-export' ),
			'fields' => $this->get_basic_fields(),
		);

		// Taxonomy fields.
		$tax_fields = $this->get_taxonomy_fields( $post_type );
		if ( ! empty( $tax_fields ) ) {
			$groups['taxonomies'] = array(
				'label'  => __( 'Taxonomies', 'mvweb-data-export' ),
				'fields' => $tax_fields,
			);
		}

		// Meta fields.
		$meta_fields = $this->get_meta_fields( $post_type );
		if ( ! empty( $meta_fields ) ) {
			$groups['meta'] = array(
				'label'  => __( 'Meta Fields', 'mvweb-data-export' ),
				'fields' => $meta_fields,
			);
		}

		/**
		 * Filter the available export fields for a post type.
		 *
		 * @since 0.1.0
		 * @param array  $groups    Grouped fields.
		 * @param string $post_type Post type slug.
		 */
		return apply_filters( 'mvweb_de_fields', $groups, $post_type );
	}

	/**
	 * Get all available fields for a taxonomy export.
	 *
	 * @since 0.1.0
	 * @param string $taxonomy Taxonomy slug.
	 * @return array Grouped fields.
	 */
	public function get_fields_for_taxonomy( string $taxonomy ): array {
		$groups = array();

		$groups['basic'] = array(
			'label'  => __( 'Basic', 'mvweb-data-export' ),
			'fields' => $this->get_taxonomy_term_fields(),
		);

		// Term meta fields.
		$meta_fields = $this->get_term_meta_fields( $taxonomy );
		if ( ! empty( $meta_fields ) ) {
			$groups['meta'] = array(
				'label'  => __( 'Meta Fields', 'mvweb-data-export' ),
				'fields' => $meta_fields,
			);
		}

		/** This filter is documented in includes/class-field-registry.php */
		return apply_filters( 'mvweb_de_fields', $groups, $taxonomy );
	}

	/**
	 * Get basic post fields.
	 *
	 * @since 0.1.0
	 * @return array Array of [ 'key' => string, 'label' => string ].
	 */
	private function get_basic_fields(): array {
		return array(
			array(
				'key'   => 'post_id',
				'label' => __( 'ID', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'post_title',
				'label' => __( 'Title', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'post_url',
				'label' => __( 'URL', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'post_slug',
				'label' => _x( 'Slug', 'post field', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'post_status',
				'label' => _x( 'Status', 'post status', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'post_date',
				'label' => __( 'Published Date', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'post_modified',
				'label' => __( 'Modified Date', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'post_author',
				'label' => __( 'Author', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'post_excerpt',
				'label' => __( 'Excerpt', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'post_content',
				'label' => __( 'Content', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'post_type',
				'label' => __( 'Post Type', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'post_parent',
				'label' => __( 'Parent', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'comment_count',
				'label' => __( 'Comments', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'thumbnail_url',
				'label' => __( 'Thumbnail URL', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'menu_order',
				'label' => __( 'Menu Order', 'mvweb-data-export' ),
			),
		);
	}

	/**
	 * Get taxonomy fields for a post type.
	 *
	 * @since 0.1.0
	 * @param string $post_type Post type slug.
	 * @return array Array of [ 'key' => string, 'label' => string ].
	 */
	private function get_taxonomy_fields( string $post_type ): array {
		$taxonomies = get_object_taxonomies( $post_type, 'objects' );
		$fields     = array();

		foreach ( $taxonomies as $tax ) {
			if ( ! $tax->public ) {
				continue;
			}

			$fields[] = array(
				'key'   => 'tax_' . $tax->name,
				'label' => $tax->labels->singular_name,
			);
		}

		return $fields;
	}

	/**
	 * Get public meta fields for a post type.
	 *
	 * Discovers meta keys dynamically from the database.
	 * Results are cached in a transient for 1 hour.
	 *
	 * @since 0.1.0
	 * @param string $post_type Post type slug.
	 * @return array Array of [ 'key' => string, 'label' => string ].
	 */
	private function get_meta_fields( string $post_type ): array {
		$transient_key = 'mvweb_de_meta_keys_' . $post_type;
		$cached        = get_transient( $transient_key );

		if ( false !== $cached ) {
			return $cached;
		}

		global $wpdb;

		// Single query: get meta keys + sample value for serialization check.
		// 50 chars of sample value is enough to detect a:, O:, s: patterns.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$results = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT pm.meta_key, SUBSTRING( MIN( pm.meta_value ), 1, 50 ) AS sample_value
				FROM {$wpdb->postmeta} pm
				INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
				WHERE p.post_type = %s
				  AND pm.meta_key NOT LIKE %s
				GROUP BY pm.meta_key
				ORDER BY pm.meta_key ASC
				LIMIT %d",
				$post_type,
				$wpdb->esc_like( '_' ) . '%',
				self::META_KEYS_LIMIT
			)
		);

		if ( empty( $results ) ) {
			set_transient( $transient_key, array(), self::META_CACHE_TTL );
			return array();
		}

		$fields = array();

		foreach ( $results as $row ) {
			if ( is_serialized( $row->sample_value ) ) {
				continue;
			}

			$fields[] = array(
				'key'   => 'meta_' . $row->meta_key,
				/* translators: %s: meta key name */
				'label' => sprintf( __( 'Meta: %s', 'mvweb-data-export' ), $row->meta_key ),
			);
		}

		set_transient( $transient_key, $fields, self::META_CACHE_TTL );

		return $fields;
	}

	/**
	 * Get basic term fields for taxonomy export.
	 *
	 * @since 0.1.0
	 * @return array Array of [ 'key' => string, 'label' => string ].
	 */
	private function get_taxonomy_term_fields(): array {
		return array(
			array(
				'key'   => 'term_id',
				'label' => __( 'ID', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'term_name',
				'label' => __( 'Name', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'term_slug',
				'label' => _x( 'Slug', 'term field', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'term_description',
				'label' => __( 'Description', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'term_url',
				'label' => __( 'URL', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'term_count',
				'label' => __( 'Post Count', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'term_parent',
				'label' => __( 'Parent', 'mvweb-data-export' ),
			),
		);
	}

	/**
	 * Get public term meta fields for a taxonomy.
	 *
	 * @since 0.1.0
	 * @param string $taxonomy Taxonomy slug.
	 * @return array Array of [ 'key' => string, 'label' => string ].
	 */
	private function get_term_meta_fields( string $taxonomy ): array {
		$transient_key = 'mvweb_de_meta_keys_tax_' . $taxonomy;
		$cached        = get_transient( $transient_key );

		if ( false !== $cached ) {
			return $cached;
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$meta_keys = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT tm.meta_key
				FROM {$wpdb->termmeta} tm
				INNER JOIN {$wpdb->term_taxonomy} tt ON tt.term_id = tm.term_id
				WHERE tt.taxonomy = %s
				  AND tm.meta_key NOT LIKE %s
				ORDER BY tm.meta_key ASC
				LIMIT %d",
				$taxonomy,
				$wpdb->esc_like( '_' ) . '%',
				self::META_KEYS_LIMIT
			)
		);

		if ( empty( $meta_keys ) ) {
			set_transient( $transient_key, array(), self::META_CACHE_TTL );
			return array();
		}

		$fields = array();

		foreach ( $meta_keys as $meta_key ) {
			$fields[] = array(
				'key'   => 'term_meta_' . $meta_key,
				/* translators: %s: meta key name */
				'label' => sprintf( __( 'Meta: %s', 'mvweb-data-export' ), $meta_key ),
			);
		}

		set_transient( $transient_key, $fields, self::META_CACHE_TTL );

		return $fields;
	}

	/**
	 * Get all public post types for the export dropdown.
	 *
	 * @since 0.1.0
	 * @return array Array of [ 'slug' => string, 'label' => string ].
	 */
	public static function get_public_post_types(): array {
		$post_types = get_post_types( array( 'public' => true ), 'objects' );
		$result     = array();

		foreach ( $post_types as $pt ) {
			if ( 'attachment' === $pt->name ) {
				continue;
			}

			$result[] = array(
				'slug'  => $pt->name,
				'label' => $pt->labels->singular_name,
			);
		}

		return $result;
	}

	/**
	 * Get all public taxonomies for the export dropdown.
	 *
	 * @since 0.1.0
	 * @return array Array of [ 'slug' => string, 'label' => string ].
	 */
	public static function get_public_taxonomies(): array {
		$taxonomies = get_taxonomies( array( 'public' => true ), 'objects' );
		$result     = array();

		foreach ( $taxonomies as $tax ) {
			$result[] = array(
				'slug'  => $tax->name,
				'label' => $tax->labels->singular_name,
			);
		}

		return $result;
	}

	/**
	 * Flatten grouped fields into a simple key => label map.
	 *
	 * @since 0.1.0
	 * @param array $groups Grouped fields from get_fields_for_post_type() or get_fields_for_taxonomy().
	 * @return array [ 'field_key' => 'Field Label', ... ].
	 */
	public static function flatten_fields( array $groups ): array {
		$flat = array();

		foreach ( $groups as $group ) {
			if ( empty( $group['fields'] ) ) {
				continue;
			}

			foreach ( $group['fields'] as $field ) {
				$flat[ $field['key'] ] = $field['label'];
			}
		}

		return $flat;
	}
}
