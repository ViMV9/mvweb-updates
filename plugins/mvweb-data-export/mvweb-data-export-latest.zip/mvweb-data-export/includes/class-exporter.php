<?php
/**
 * Exporter for MVweb Data Export.
 *
 * Builds WP_Query / get_terms(), extracts data, writes to CSV via batch processing.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_DE_Exporter
 *
 * @since 0.1.0
 */
class MVweb_DE_Exporter {

	/**
	 * Memory usage threshold (80%).
	 *
	 * @var float
	 */
	private const MEMORY_THRESHOLD = 0.8;

	/**
	 * Minimum free disk space in bytes (50 MB).
	 *
	 * @var int
	 */
	private const MIN_DISK_SPACE = 52428800;

	/**
	 * Field registry instance.
	 *
	 * @var MVweb_DE_Field_Registry
	 */
	private MVweb_DE_Field_Registry $field_registry;

	/**
	 * WooCommerce fields instance (may be null if WC is not active).
	 *
	 * @var MVweb_DE_WC_Fields|null
	 */
	private ?MVweb_DE_WC_Fields $wc_fields = null;

	/**
	 * Whether editor permission filter is needed for the next query.
	 *
	 * @var bool
	 */
	private bool $needs_editor_filter = false;

	/**
	 * Constructor.
	 *
	 * @since 0.1.0
	 * @param MVweb_DE_Field_Registry $field_registry Field registry instance.
	 */
	public function __construct( MVweb_DE_Field_Registry $field_registry ) {
		$this->field_registry = $field_registry;
	}

	/**
	 * Set WooCommerce fields handler.
	 *
	 * @since 0.1.0
	 * @param MVweb_DE_WC_Fields $wc_fields WC fields instance.
	 * @return void
	 */
	public function set_wc_fields( MVweb_DE_WC_Fields $wc_fields ): void {
		$this->wc_fields = $wc_fields;
	}

	/**
	 * Count total records matching the export configuration.
	 *
	 * @since 0.1.0
	 * @param array $config Export configuration.
	 * @return int Total record count.
	 */
	public function count_records( array $config ): int {
		$settings    = mvweb_de_get_settings();
		$max_records = (int) $settings['max_records'];

		if ( 'taxonomies' === $config['export_type'] ) {
			return $this->count_terms( $config );
		}

		$args = $this->build_query_args( $config );

		// Count query: need found_rows.
		$args['posts_per_page'] = 1;
		$args['no_found_rows']  = false;
		$args['fields']         = 'ids';

		$query = $this->run_query( $args );

		return min( $query->found_posts, $max_records );
	}

	/**
	 * Count terms matching the export configuration.
	 *
	 * @since 0.1.0
	 * @param array $config Export configuration.
	 * @return int Term count.
	 */
	private function count_terms( array $config ): int {
		$args = array(
			'taxonomy'   => sanitize_key( $config['source'] ),
			'hide_empty' => true,
			'fields'     => 'count',
		);

		$count = (int) wp_count_terms( $args );

		$settings = mvweb_de_get_settings();

		return min( $count, (int) $settings['max_records'] );
	}

	/**
	 * Export a batch of records.
	 *
	 * @since 0.1.0
	 * @param array             $config     Export configuration.
	 * @param int               $offset     Current offset.
	 * @param int               $batch_size Batch size.
	 * @param MVweb_DE_CSV_Writer $writer    CSV writer instance.
	 * @return array Result: [ 'processed' => int, 'memory_warning' => bool ].
	 */
	public function export_batch( array $config, int $offset, int $batch_size, MVweb_DE_CSV_Writer $writer ): array {
		if ( 'taxonomies' === $config['export_type'] ) {
			return $this->export_terms_batch( $config, $offset, $batch_size, $writer );
		}

		return $this->export_posts_batch( $config, $offset, $batch_size, $writer );
	}

	/**
	 * Export a batch of posts.
	 *
	 * @since 0.1.0
	 * @param array             $config     Export configuration.
	 * @param int               $offset     Current offset.
	 * @param int               $batch_size Batch size.
	 * @param MVweb_DE_CSV_Writer $writer    CSV writer instance.
	 * @return array Result.
	 */
	private function export_posts_batch( array $config, int $offset, int $batch_size, MVweb_DE_CSV_Writer $writer ): array {
		// Adaptive batch size for WC products.
		if ( 'product' === $config['source'] && $this->wc_fields ) {
			$variation_mode = $config['variation_mode'] ?? 'inline';
			$batch_size     = MVweb_DE_WC_Fields::get_adaptive_batch_size(
				$batch_size,
				'separate' === $variation_mode
			);
		}

		$args = $this->build_query_args( $config );

		// Batch query: no need for total count.
		$args['posts_per_page'] = $batch_size;
		$args['no_found_rows']  = true;
		$args['fields']         = 'ids';

		// Cursor-based pagination for ID sorting (avoids slow OFFSET on large tables).
		$cursor_last_id = $config['cursor_last_id'] ?? 0;
		if ( 'ID' === ( $config['sort_by'] ?? '' ) && $cursor_last_id > 0 ) {
			$cursor_order = strtoupper( $config['sort_order'] ?? 'DESC' );
			$cursor_callback = function ( $where ) use ( $cursor_last_id, $cursor_order ) {
				global $wpdb;
				if ( 'ASC' === $cursor_order ) {
					$where .= $wpdb->prepare( " AND {$wpdb->posts}.ID > %d", $cursor_last_id );
				} else {
					$where .= $wpdb->prepare( " AND {$wpdb->posts}.ID < %d", $cursor_last_id );
				}
				return $where;
			};
			add_filter( 'posts_where', $cursor_callback );
		} else {
			$args['offset'] = $offset;
			$cursor_callback = null;
		}

		$query    = $this->run_query( $args );
		$post_ids = $query->posts;

		if ( $cursor_callback ) {
			remove_filter( 'posts_where', $cursor_callback );
		}

		if ( empty( $post_ids ) ) {
			return array(
				'processed'      => 0,
				'memory_warning' => false,
			);
		}

		// Preload meta and terms (before cache suspension).
		update_postmeta_cache( $post_ids );

		// Preloads product_cat, product_tag, and all other registered taxonomies for this post type.
		update_object_term_cache( $post_ids, $config['source'] );

		// Preload author user objects to avoid N+1 get_userdata() calls.
		$fields = $config['fields'];
		if ( in_array( 'post_author', $fields, true ) ) {
			$author_ids = array();
			foreach ( $post_ids as $pid ) {
				$p = get_post( $pid );
				if ( $p ) {
					$author_ids[] = (int) $p->post_author;
				}
			}
			$author_ids = array_unique( $author_ids );
			if ( ! empty( $author_ids ) ) {
				cache_users( $author_ids );
			}
		}

		// Suspend cache additions during batch.
		wp_suspend_cache_addition( true );

		$url_format     = $config['url_format'] ?? 'full';
		$variation_mode = $config['variation_mode'] ?? 'inline';

		// Stream rows directly to file instead of accumulating in memory.
		if ( ! $writer->open_for_append() ) {
			wp_suspend_cache_addition( false );
			return array(
				'processed'      => 0,
				'memory_warning' => false,
				'error'          => __( 'Failed to open export file for writing.', 'mvweb-data-export' ),
			);
		}

		foreach ( $post_ids as $post_id ) {
			$row = $this->extract_post_data( $post_id, $fields, $url_format );
			$writer->write_single_row( $row );

			// Handle WC variations in 'separate' mode.
			if ( 'separate' === $variation_mode && $this->wc_fields && 'product' === $config['source'] ) {
				$var_rows = $this->wc_fields->get_variations_data( $post_id, 'separate', $fields, $url_format );
				if ( is_array( $var_rows ) && ! empty( $var_rows ) ) {
					$writer->write_rows( $var_rows );
				}
			}
		}

		$writer->close();

		wp_suspend_cache_addition( false );

		$memory_warning = $this->is_memory_near_limit();

		$result = array(
			'processed'      => count( $post_ids ),
			'memory_warning' => $memory_warning,
		);

		// Return last post ID for cursor-based pagination.
		if ( 'ID' === ( $config['sort_by'] ?? '' ) ) {
			$result['cursor_last_id'] = end( $post_ids );
		}

		return $result;
	}

	/**
	 * Export a batch of terms.
	 *
	 * @since 0.1.0
	 * @param array             $config     Export configuration.
	 * @param int               $offset     Current offset.
	 * @param int               $batch_size Batch size.
	 * @param MVweb_DE_CSV_Writer $writer    CSV writer instance.
	 * @return array Result.
	 */
	private function export_terms_batch( array $config, int $offset, int $batch_size, MVweb_DE_CSV_Writer $writer ): array {
		$taxonomy = sanitize_key( $config['source'] );

		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => true,
				'number'     => $batch_size,
				'offset'     => $offset,
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return array(
				'processed'      => 0,
				'memory_warning' => false,
			);
		}

		$fields     = $config['fields'];
		$url_format = $config['url_format'] ?? 'full';
		$rows       = array();

		foreach ( $terms as $term ) {
			$row = $this->extract_term_data( $term, $fields, $url_format );
			$rows[] = $row;
		}

		$writer->append_rows( $rows );

		return array(
			'processed'      => count( $terms ),
			'memory_warning' => $this->is_memory_near_limit(),
		);
	}

	/**
	 * Extract data for a single post according to selected fields.
	 *
	 * @since 0.1.0
	 * @param int    $post_id    Post ID.
	 * @param array  $fields     Ordered array of field keys.
	 * @param string $url_format 'full' or 'relative'.
	 * @return array Row values in the same order as $fields.
	 */
	private function extract_post_data( int $post_id, array $fields, string $url_format ): array {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return array_fill( 0, count( $fields ), '' );
		}

		$row = array();

		foreach ( $fields as $field_key ) {
			$row[] = $this->get_post_field_value( $post, $field_key, $url_format );
		}

		return $row;
	}

	/**
	 * Get a single field value for a post.
	 *
	 * @since 0.1.0
	 * @param WP_Post $post      Post object.
	 * @param string  $field_key Field key.
	 * @param string  $url_format 'full' or 'relative'.
	 * @return string Field value.
	 */
	private function get_post_field_value( WP_Post $post, string $field_key, string $url_format ): string {
		switch ( $field_key ) {
			case 'post_id':
				return (string) $post->ID;

			case 'post_title':
				return $post->post_title;

			case 'post_url':
				$url = get_permalink( $post->ID );
				if ( 'relative' === $url_format && $url ) {
					$url = wp_make_link_relative( $url );
				}
				return $url ?: '';

			case 'post_slug':
				return $post->post_name;

			case 'post_status':
				return $post->post_status;

			case 'post_date':
				return $post->post_date;

			case 'post_modified':
				return $post->post_modified;

			case 'post_author':
				$author = get_userdata( (int) $post->post_author );
				return $author ? $author->display_name : '';

			case 'post_excerpt':
				return strip_tags( $post->post_excerpt );

			case 'post_content':
				return strip_tags( $post->post_content );

			case 'post_type':
				return $post->post_type;

			case 'post_parent':
				return (string) $post->post_parent;

			case 'comment_count':
				return (string) $post->comment_count;

			case 'thumbnail_url':
				$thumb_id = get_post_thumbnail_id( $post->ID );
				if ( $thumb_id ) {
					$url = wp_get_attachment_url( $thumb_id );
					return $url ?: '';
				}
				return '';

			case 'menu_order':
				return (string) $post->menu_order;

			default:
				// WooCommerce fields: wc_* (including wc_attr_*).
				if ( str_starts_with( $field_key, 'wc_' ) && $this->wc_fields ) {
					return $this->wc_fields->get_field_value( $post->ID, $field_key );
				}

				// Taxonomy fields: tax_{taxonomy}.
				if ( str_starts_with( $field_key, 'tax_' ) ) {
					$taxonomy = substr( $field_key, 4 );
					$terms    = get_the_terms( $post->ID, $taxonomy );
					if ( $terms && ! is_wp_error( $terms ) ) {
						return implode( ' | ', wp_list_pluck( $terms, 'name' ) );
					}
					return '';
				}

				// Meta fields: meta_{key}.
				if ( str_starts_with( $field_key, 'meta_' ) ) {
					$meta_key = substr( $field_key, 5 );
					$value    = get_post_meta( $post->ID, $meta_key, true );
					if ( is_array( $value ) || is_serialized( $value ) ) {
						return '';
					}
					return (string) $value;
				}

				return '';
		}
	}

	/**
	 * Extract data for a single term.
	 *
	 * @since 0.1.0
	 * @param WP_Term $term       Term object.
	 * @param array   $fields     Ordered array of field keys.
	 * @param string  $url_format 'full' or 'relative'.
	 * @return array Row values.
	 */
	private function extract_term_data( WP_Term $term, array $fields, string $url_format ): array {
		$row = array();

		foreach ( $fields as $field_key ) {
			switch ( $field_key ) {
				case 'term_id':
					$row[] = (string) $term->term_id;
					break;

				case 'term_name':
					$row[] = $term->name;
					break;

				case 'term_slug':
					$row[] = $term->slug;
					break;

				case 'term_description':
					$row[] = strip_tags( $term->description );
					break;

				case 'term_url':
					$url = get_term_link( $term );
					if ( is_wp_error( $url ) ) {
						$row[] = '';
					} elseif ( 'relative' === $url_format ) {
						$row[] = wp_make_link_relative( $url );
					} else {
						$row[] = $url;
					}
					break;

				case 'term_count':
					$row[] = (string) $term->count;
					break;

				case 'term_parent':
					$row[] = (string) $term->parent;
					break;

				default:
					// Term meta: term_meta_{key}.
					if ( str_starts_with( $field_key, 'term_meta_' ) ) {
						$meta_key = substr( $field_key, 10 );
						$value    = get_term_meta( $term->term_id, $meta_key, true );
						if ( is_array( $value ) || is_serialized( $value ) ) {
							$row[] = '';
						} else {
							$row[] = (string) $value;
						}
					} else {
						$row[] = '';
					}
					break;
			}
		}

		return $row;
	}

	/**
	 * Get preview rows (first N rows) without writing to file.
	 *
	 * @since 0.1.0
	 * @param array $config Export configuration.
	 * @param int   $limit  Number of rows to return.
	 * @return array Array of row arrays.
	 */
	public function get_preview_rows( array $config, int $limit = 10 ): array {
		if ( 'taxonomies' === $config['export_type'] ) {
			return $this->get_preview_terms( $config, $limit );
		}

		$args = $this->build_query_args( $config );

		$args['posts_per_page'] = $limit;
		$args['offset']         = 0;
		$args['no_found_rows']  = true;
		$args['fields']         = 'ids';

		$query    = $this->run_query( $args );
		$post_ids = $query->posts;

		if ( empty( $post_ids ) ) {
			return array();
		}

		update_postmeta_cache( $post_ids );
		update_object_term_cache( $post_ids, $config['source'] );

		$fields     = $config['fields'];
		$url_format = $config['url_format'] ?? 'full';

		// Preload author user objects to avoid N+1 get_userdata() calls.
		if ( in_array( 'post_author', $fields, true ) ) {
			$author_ids = array();
			foreach ( $post_ids as $pid ) {
				$p = get_post( $pid );
				if ( $p ) {
					$author_ids[] = (int) $p->post_author;
				}
			}
			$author_ids = array_unique( $author_ids );
			if ( ! empty( $author_ids ) ) {
				cache_users( $author_ids );
			}
		}

		$rows = array();

		foreach ( $post_ids as $post_id ) {
			$rows[] = $this->extract_post_data( $post_id, $fields, $url_format );
		}

		return $rows;
	}

	/**
	 * Get preview rows for terms.
	 *
	 * @since 0.1.0
	 * @param array $config Export configuration.
	 * @param int   $limit  Number of rows.
	 * @return array Array of row arrays.
	 */
	private function get_preview_terms( array $config, int $limit ): array {
		$taxonomy = sanitize_key( $config['source'] );

		$terms = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => true,
				'number'     => $limit,
				'offset'     => 0,
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return array();
		}

		$fields     = $config['fields'];
		$url_format = $config['url_format'] ?? 'full';
		$rows       = array();

		foreach ( $terms as $term ) {
			$rows[] = $this->extract_term_data( $term, $fields, $url_format );
		}

		return $rows;
	}

	/**
	 * Build WP_Query arguments from export configuration.
	 *
	 * @since 0.1.0
	 * @param array $config Export configuration.
	 * @return array WP_Query arguments.
	 */
	private function build_query_args( array $config ): array {
		$args = array(
			'post_type'      => sanitize_key( $config['source'] ),
			'post_status'    => 'publish',
			'orderby'        => 'date',
			'order'          => 'DESC',
		);

		// Sort.
		$sort_whitelist = array( 'post_date' => 'date', 'post_title' => 'title', 'ID' => 'ID' );
		if ( ! empty( $config['sort_by'] ) && isset( $sort_whitelist[ $config['sort_by'] ] ) ) {
			$args['orderby'] = $sort_whitelist[ $config['sort_by'] ];
		}

		if ( ! empty( $config['sort_order'] ) && in_array( strtoupper( $config['sort_order'] ), array( 'ASC', 'DESC' ), true ) ) {
			$args['order'] = strtoupper( $config['sort_order'] );
		}

		// Apply filters.
		$filters = $config['filters'] ?? array();
		if ( ! empty( $filters ) ) {
			$this->apply_filters_to_query( $args, $filters );
		}

		// Apply permissions model.
		$this->apply_permissions_to_query( $args );

		return $args;
	}

	/**
	 * Apply user-selected filters to WP_Query arguments.
	 *
	 * @since 0.1.0
	 * @param array $args    WP_Query arguments (by reference).
	 * @param array $filters Parsed filter values.
	 * @return void
	 */
	private function apply_filters_to_query( array &$args, array $filters ): void {
		// Post status filter.
		if ( ! empty( $filters['post_status'] ) ) {
			$args['post_status'] = $filters['post_status'];
		}

		// Taxonomy filter.
		if ( ! empty( $filters['taxonomy'] ) && ! empty( $filters['term_ids'] ) ) {
			$args['tax_query'] = array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
				array(
					'taxonomy' => $filters['taxonomy'],
					'field'    => 'term_id',
					'terms'    => $filters['term_ids'],
					'operator' => 'IN',
				),
			);
		}

		// Date range filter.
		if ( ! empty( $filters['date_from'] ) || ! empty( $filters['date_to'] ) ) {
			$date_query = array( 'inclusive' => true );

			if ( ! empty( $filters['date_from'] ) ) {
				$date_query['after'] = $filters['date_from'];
			}
			if ( ! empty( $filters['date_to'] ) ) {
				$date_query['before'] = $filters['date_to'] . ' 23:59:59';
			}

			$args['date_query'] = array( $date_query );
		}

		// Author filter.
		if ( ! empty( $filters['author'] ) ) {
			$args['author'] = (int) $filters['author'];
		}

		// WooCommerce-specific filters.
		if ( ! empty( $filters['price_min'] ) || ! empty( $filters['price_max'] ) ) {
			if ( ! isset( $args['meta_query'] ) ) {
				$args['meta_query'] = array(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			}

			if ( ! empty( $filters['price_min'] ) ) {
				$args['meta_query'][] = array(
					'key'     => '_price',
					'value'   => (float) $filters['price_min'],
					'compare' => '>=',
					'type'    => 'DECIMAL(10,2)',
				);
			}

			if ( ! empty( $filters['price_max'] ) ) {
				$args['meta_query'][] = array(
					'key'     => '_price',
					'value'   => (float) $filters['price_max'],
					'compare' => '<=',
					'type'    => 'DECIMAL(10,2)',
				);
			}
		}

		if ( ! empty( $filters['stock_status'] ) ) {
			if ( ! isset( $args['meta_query'] ) ) {
				$args['meta_query'] = array(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			}

			$args['meta_query'][] = array(
				'key'     => '_stock_status',
				'value'   => $filters['stock_status'],
				'compare' => 'IN',
			);
		}

		if ( ! empty( $filters['product_type'] ) ) {
			if ( ! isset( $args['tax_query'] ) ) {
				$args['tax_query'] = array(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
			}

			$args['tax_query'][] = array(
				'taxonomy' => 'product_type',
				'field'    => 'slug',
				'terms'    => $filters['product_type'],
				'operator' => 'IN',
			);
		}
	}

	/**
	 * Apply permissions-based restrictions to WP_Query.
	 *
	 * Admins (manage_options): all posts, all statuses.
	 * Editors (edit_others_posts): only 'publish' + own posts of any status.
	 *
	 * If the editor requested non-publish statuses, we broaden post_status
	 * and set a flag to add a posts_where filter during query execution.
	 *
	 * @since 0.1.0
	 * @param array $args WP_Query arguments (by reference).
	 * @return void
	 */
	private function apply_permissions_to_query( array &$args ): void {
		// Admins see everything — no restrictions needed.
		if ( current_user_can( 'manage_options' ) ) {
			return;
		}

		// Mark that editor permission filter is needed.
		$this->needs_editor_filter = true;

		// Ensure post_status includes all requested statuses; the WHERE clause handles permissions.
		$current_status = $args['post_status'];
		if ( is_string( $current_status ) && 'publish' === $current_status ) {
			// No non-publish statuses requested — no extra filtering needed.
			$this->needs_editor_filter = false;
		}
	}

	/**
	 * Execute WP_Query with permission-aware filtering.
	 *
	 * Adds/removes a posts_where filter for editors so they see
	 * published posts from anyone + own posts of any status.
	 *
	 * @since 0.1.0
	 * @param array $args WP_Query arguments.
	 * @return WP_Query
	 */
	private function run_query( array $args ): WP_Query {
		$callback = null;

		if ( ! empty( $this->needs_editor_filter ) ) {
			$current_user_id = get_current_user_id();
			$callback        = function ( $where ) use ( $current_user_id ) {
				global $wpdb;
				$where .= $wpdb->prepare(
					" AND ({$wpdb->posts}.post_status = 'publish' OR {$wpdb->posts}.post_author = %d)",
					$current_user_id
				);
				return $where;
			};
			add_filter( 'posts_where', $callback );
		}

		$query = new WP_Query( $args );

		if ( $callback ) {
			remove_filter( 'posts_where', $callback );
		}

		// Reset flag.
		$this->needs_editor_filter = false;

		return $query;
	}

	/**
	 * Check if memory usage is near the limit.
	 *
	 * @since 0.1.0
	 * @return bool True if memory usage exceeds threshold.
	 */
	private function is_memory_near_limit(): bool {
		$limit = $this->get_memory_limit();
		if ( $limit <= 0 ) {
			return false;
		}

		$usage = memory_get_usage( true );

		return ( $usage / $limit ) >= self::MEMORY_THRESHOLD;
	}

	/**
	 * Get PHP memory limit in bytes.
	 *
	 * @since 0.1.0
	 * @return int Memory limit in bytes, or -1 if unlimited.
	 */
	private function get_memory_limit(): int {
		$limit = ini_get( 'memory_limit' );

		if ( '-1' === $limit ) {
			return -1;
		}

		return wp_convert_hr_to_bytes( $limit );
	}

	/**
	 * Check if there is enough disk space for export.
	 *
	 * @since 0.1.0
	 * @return bool True if enough space.
	 */
	public static function has_enough_disk_space(): bool {
		$export_dir = MVweb_DE_File_Manager::get_export_dir();

		if ( ! function_exists( 'disk_free_space' ) ) {
			return true; // Cannot determine, proceed.
		}

		$free = @disk_free_space( $export_dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

		if ( false === $free ) {
			return true; // Cannot determine, proceed.
		}

		return $free >= self::MIN_DISK_SPACE;
	}

	/**
	 * Get headers (column labels) for the selected fields.
	 *
	 * Respects header language setting via switch_to_locale().
	 *
	 * @since 0.1.0
	 * @param array  $fields      Ordered field keys.
	 * @param string $export_type 'posts' or 'taxonomies'.
	 * @param string $source      Post type or taxonomy slug.
	 * @return array Column labels in the same order as $fields.
	 */
	public function get_headers( array $fields, string $export_type, string $source ): array {
		$settings    = mvweb_de_get_settings();
		$header_lang = $settings['header_lang'];

		$switched = false;
		if ( 'auto' !== $header_lang ) {
			$locale = ( 'ru' === $header_lang ) ? 'ru_RU' : 'en_US';
			if ( function_exists( 'switch_to_locale' ) ) {
				switch_to_locale( $locale );
				$switched = true;
			}
		}

		if ( 'taxonomies' === $export_type ) {
			$groups = $this->field_registry->get_fields_for_taxonomy( $source );
		} else {
			$groups = $this->field_registry->get_fields_for_post_type( $source );
		}

		$flat_fields = MVweb_DE_Field_Registry::flatten_fields( $groups );

		$headers = array();
		foreach ( $fields as $key ) {
			$headers[] = $flat_fields[ $key ] ?? $key;
		}

		if ( $switched && function_exists( 'restore_current_locale' ) ) {
			restore_current_locale();
		}

		return $headers;
	}
}
