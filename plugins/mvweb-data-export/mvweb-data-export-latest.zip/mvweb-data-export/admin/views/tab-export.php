<?php
/**
 * Export tab content.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$post_types  = MVweb_DE_Field_Registry::get_public_post_types();
$taxonomies  = MVweb_DE_Field_Registry::get_public_taxonomies();
?>
<div class="mvweb-de-export" id="mvweb-de-export-form">

	<!-- Preset controls -->
	<div class="mvweb-de-export__preset-bar">
		<select id="mvweb-de-preset-select" class="regular-text">
			<option value=""><?php esc_html_e( 'Load Preset...', 'mvweb-data-export' ); ?></option>
		</select>
		<button type="button" class="button button-small" id="mvweb-de-preset-load" disabled>
			<?php esc_html_e( 'Load', 'mvweb-data-export' ); ?>
		</button>
		<button type="button" class="button button-small" id="mvweb-de-preset-save">
			<?php esc_html_e( 'Save as Preset', 'mvweb-data-export' ); ?>
		</button>
		<span class="spinner" id="mvweb-de-preset-spinner"></span>
	</div>

	<!-- Export Type -->
	<table class="form-table mvweb-de-export__table">
		<tr>
			<th scope="row"><?php esc_html_e( 'Export Type', 'mvweb-data-export' ); ?></th>
			<td>
				<label>
					<input type="radio" name="mvweb_de_export_type" value="posts" checked>
					<?php esc_html_e( 'Posts / CPT', 'mvweb-data-export' ); ?>
				</label>
				&nbsp;&nbsp;
				<label>
					<input type="radio" name="mvweb_de_export_type" value="taxonomies">
					<?php esc_html_e( 'Taxonomies', 'mvweb-data-export' ); ?>
				</label>
			</td>
		</tr>

		<!-- Source (post type or taxonomy) -->
		<tr>
			<th scope="row">
				<span class="mvweb-de-export__source-label" data-posts="<?php esc_attr_e( 'Post Type', 'mvweb-data-export' ); ?>" data-taxonomies="<?php esc_attr_e( 'Taxonomy', 'mvweb-data-export' ); ?>">
					<?php esc_html_e( 'Post Type', 'mvweb-data-export' ); ?>
				</span>
			</th>
			<td>
				<select id="mvweb-de-source" class="regular-text">
					<option value=""><?php esc_html_e( '&mdash; Select &mdash;', 'mvweb-data-export' ); ?></option>
				</select>
				<span class="spinner" id="mvweb-de-fields-spinner"></span>

				<!-- Hidden data for JS -->
				<script type="application/json" id="mvweb-de-post-types-data"><?php echo wp_json_encode( $post_types ); ?></script>
				<script type="application/json" id="mvweb-de-taxonomies-data"><?php echo wp_json_encode( $taxonomies ); ?></script>
			</td>
		</tr>

		<!-- Format -->
		<tr>
			<th scope="row"><?php esc_html_e( 'Format', 'mvweb-data-export' ); ?></th>
			<td>
				<label>
					<input type="radio" name="mvweb_de_format" value="csv" checked>
					CSV
				</label>
				&nbsp;&nbsp;
				<label>
					<input type="radio" name="mvweb_de_format" value="txt">
					TXT (TSV)
				</label>
			</td>
		</tr>

		<!-- URL Format -->
		<tr>
			<th scope="row"><?php esc_html_e( 'URL Format', 'mvweb-data-export' ); ?></th>
			<td>
				<label>
					<input type="radio" name="mvweb_de_url_format" value="full" checked>
					<?php esc_html_e( 'Full URL', 'mvweb-data-export' ); ?>
				</label>
				&nbsp;&nbsp;
				<label>
					<input type="radio" name="mvweb_de_url_format" value="relative">
					<?php esc_html_e( 'Relative path', 'mvweb-data-export' ); ?>
				</label>
			</td>
		</tr>

		<!-- Sort -->
		<tr>
			<th scope="row"><?php esc_html_e( 'Sort by', 'mvweb-data-export' ); ?></th>
			<td>
				<select id="mvweb-de-sort-by">
					<option value="post_date" selected><?php esc_html_e( 'Date', 'mvweb-data-export' ); ?></option>
					<option value="post_title"><?php esc_html_e( 'Title', 'mvweb-data-export' ); ?></option>
					<option value="ID">ID</option>
				</select>
				<select id="mvweb-de-sort-order">
					<option value="DESC" selected>DESC</option>
					<option value="ASC">ASC</option>
				</select>
			</td>
		</tr>
	</table>

	<!-- Filters (shown after source is selected, only for posts) -->
	<div class="mvweb-de-filters" id="mvweb-de-filters-section" style="display: none;">
		<h3><?php esc_html_e( 'Filters', 'mvweb-data-export' ); ?></h3>
		<table class="form-table mvweb-de-export__table">
			<!-- Post Status -->
			<tr class="mvweb-de-filters__row--posts">
				<th scope="row"><?php esc_html_e( 'Status', 'mvweb-data-export' ); ?></th>
				<td>
					<select id="mvweb-de-filter-status" multiple class="mvweb-de-filters__select">
						<!-- Populated via JS -->
					</select>
					<p class="description"><?php esc_html_e( 'Leave empty for all statuses available to your role.', 'mvweb-data-export' ); ?></p>
				</td>
			</tr>

			<!-- Taxonomy Terms -->
			<tr class="mvweb-de-filters__row--posts" id="mvweb-de-filter-tax-row" style="display: none;">
				<th scope="row">
					<span id="mvweb-de-filter-tax-label"><?php esc_html_e( 'Category', 'mvweb-data-export' ); ?></span>
				</th>
				<td>
					<select id="mvweb-de-filter-taxonomy" class="regular-text">
						<!-- Populated via JS: list of taxonomies for current post type -->
					</select>
					<select id="mvweb-de-filter-terms" multiple class="mvweb-de-filters__select" style="display: none;">
						<!-- Populated via JS: terms for selected taxonomy -->
					</select>
					<span class="spinner" id="mvweb-de-terms-spinner"></span>
				</td>
			</tr>

			<!-- Date Range -->
			<tr class="mvweb-de-filters__row--posts">
				<th scope="row"><?php esc_html_e( 'Date Range', 'mvweb-data-export' ); ?></th>
				<td>
					<label>
						<?php esc_html_e( 'From:', 'mvweb-data-export' ); ?>
						<input type="date" id="mvweb-de-filter-date-from" class="mvweb-de-filters__date">
					</label>
					&nbsp;&nbsp;
					<label>
						<?php esc_html_e( 'To:', 'mvweb-data-export' ); ?>
						<input type="date" id="mvweb-de-filter-date-to" class="mvweb-de-filters__date">
					</label>
				</td>
			</tr>

			<!-- Author -->
			<tr class="mvweb-de-filters__row--posts">
				<th scope="row"><?php esc_html_e( 'Author', 'mvweb-data-export' ); ?></th>
				<td>
					<select id="mvweb-de-filter-author" class="regular-text">
						<option value=""><?php esc_html_e( 'All Authors', 'mvweb-data-export' ); ?></option>
						<!-- Populated via JS -->
					</select>
				</td>
			</tr>

			<!-- WooCommerce Filters (shown only for product post type) -->
			<tr class="mvweb-de-filters__row--wc" id="mvweb-de-filter-wc-price" style="display: none;">
				<th scope="row"><?php esc_html_e( 'Price Range', 'mvweb-data-export' ); ?></th>
				<td>
					<label>
						<?php esc_html_e( 'From:', 'mvweb-data-export' ); ?>
						<input type="number" id="mvweb-de-filter-price-min" class="small-text" min="0" step="0.01">
					</label>
					&nbsp;&nbsp;
					<label>
						<?php esc_html_e( 'To:', 'mvweb-data-export' ); ?>
						<input type="number" id="mvweb-de-filter-price-max" class="small-text" min="0" step="0.01">
					</label>
				</td>
			</tr>

			<tr class="mvweb-de-filters__row--wc" id="mvweb-de-filter-wc-stock" style="display: none;">
				<th scope="row"><?php esc_html_e( 'Stock Status', 'mvweb-data-export' ); ?></th>
				<td>
					<select id="mvweb-de-filter-stock-status" multiple class="mvweb-de-filters__select mvweb-de-filters__select--wc">
						<!-- Populated via JS -->
					</select>
				</td>
			</tr>

			<tr class="mvweb-de-filters__row--wc" id="mvweb-de-filter-wc-type" style="display: none;">
				<th scope="row"><?php esc_html_e( 'Product Type', 'mvweb-data-export' ); ?></th>
				<td>
					<select id="mvweb-de-filter-product-type" multiple class="mvweb-de-filters__select mvweb-de-filters__select--wc">
						<!-- Populated via JS -->
					</select>
				</td>
			</tr>
		</table>
	</div>

	<!-- Variation Mode (shown only when product type is selected) -->
	<div class="mvweb-de-variation-mode" id="mvweb-de-variation-section" style="display: none;">
		<table class="form-table mvweb-de-export__table">
			<tr>
				<th scope="row"><?php esc_html_e( 'Variations', 'mvweb-data-export' ); ?></th>
				<td>
					<label>
						<input type="radio" name="mvweb_de_variation_mode" value="inline" checked>
						<?php esc_html_e( 'Inline (all variations in one cell)', 'mvweb-data-export' ); ?>
					</label>
					<br>
					<label>
						<input type="radio" name="mvweb_de_variation_mode" value="separate">
						<?php esc_html_e( 'Separate rows (each variation = row)', 'mvweb-data-export' ); ?>
					</label>
					<p class="description"><?php esc_html_e( 'Applies only to variable products.', 'mvweb-data-export' ); ?></p>
				</td>
			</tr>
		</table>
	</div>

	<!-- Fields selection -->
	<div class="mvweb-de-fields" id="mvweb-de-fields-section" style="display: none;">
		<h3><?php esc_html_e( 'Fields', 'mvweb-data-export' ); ?></h3>

		<div class="mvweb-de-fields__container">
			<!-- Available fields -->
			<div class="mvweb-de-fields__column">
				<h4><?php esc_html_e( 'Available Fields', 'mvweb-data-export' ); ?></h4>
				<ul class="mvweb-de-fields__list mvweb-de-fields__list--available" id="mvweb-de-available-fields">
					<!-- Populated via JS -->
				</ul>
				<button type="button" class="button button-small" id="mvweb-de-select-all">
					<?php esc_html_e( 'Select All', 'mvweb-data-export' ); ?>
				</button>
			</div>

			<!-- Selected fields -->
			<div class="mvweb-de-fields__column">
				<h4><?php esc_html_e( 'Selected Fields', 'mvweb-data-export' ); ?></h4>
				<ul class="mvweb-de-fields__list mvweb-de-fields__list--selected" id="mvweb-de-selected-fields">
					<!-- Populated via drag-n-drop -->
				</ul>
				<div class="mvweb-de-fields__actions">
					<button type="button" class="button button-small" id="mvweb-de-clear-all">
						<?php esc_html_e( 'Clear All', 'mvweb-data-export' ); ?>
					</button>
					<button type="button" class="button button-small" id="mvweb-de-move-up" title="<?php esc_attr_e( 'Move Up', 'mvweb-data-export' ); ?>">&#9650;</button>
					<button type="button" class="button button-small" id="mvweb-de-move-down" title="<?php esc_attr_e( 'Move Down', 'mvweb-data-export' ); ?>">&#9660;</button>
				</div>
			</div>
		</div>
	</div>

	<!-- Export / Preview buttons -->
	<div class="mvweb-de-export__actions" id="mvweb-de-export-actions" style="display: none;">
		<button type="button" class="button button-secondary button-hero" id="mvweb-de-btn-preview">
			<?php esc_html_e( 'Preview', 'mvweb-data-export' ); ?>
		</button>
		<button type="button" class="button button-primary button-hero" id="mvweb-de-btn-export">
			<?php echo esc_html( _x( 'Export', 'button label', 'mvweb-data-export' ) ); ?>
		</button>
	</div>

	<!-- Preview table (hidden by default) -->
	<div class="mvweb-de-preview" id="mvweb-de-preview" style="display: none;">
		<h3>
			<?php esc_html_e( 'Preview', 'mvweb-data-export' ); ?>
			<span class="mvweb-de-preview__count" id="mvweb-de-preview-count"></span>
		</h3>
		<div class="mvweb-de-preview__table-wrap">
			<table class="wp-list-table widefat striped" id="mvweb-de-preview-table">
				<thead id="mvweb-de-preview-thead"></thead>
				<tbody id="mvweb-de-preview-tbody"></tbody>
			</table>
		</div>
	</div>

	<!-- Progress bar (hidden by default) -->
	<div class="mvweb-de-progress" id="mvweb-de-progress" style="display: none;">
		<p class="mvweb-de-progress__text" id="mvweb-de-progress-text"></p>
		<div class="mvweb-de-progress__bar-wrap">
			<div class="mvweb-de-progress__bar" id="mvweb-de-progress-bar" style="width: 0%;"></div>
		</div>
		<button type="button" class="button" id="mvweb-de-btn-cancel">
			<?php esc_html_e( 'Cancel', 'mvweb-data-export' ); ?>
		</button>
	</div>

</div>
