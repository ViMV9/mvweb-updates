/**
 * Admin JavaScript for MVweb Data Export.
 *
 * Handles tab switching, field selection (drag-n-drop), AJAX export flow,
 * presets management, and export history.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

/* global jQuery, mvwebDeAdmin */
(function ($) {
	'use strict';

	var STORAGE_KEY = 'mvweb_de_active_tab';
	var currentSessionId = null;
	var isExporting = false;

	/* ──────────────────────────────────────────
	   Tab Navigation
	   ────────────────────────────────────────── */

	function initTabs() {
		var $tabs = $('.mvweb-de-tabs__tab');
		var $contents = $('.mvweb-de-tab-content');

		if (!$tabs.length) {
			return;
		}

		function activateTab(tabId) {
			$tabs.removeClass('nav-tab-active mvweb-de-tabs__tab--active');
			$contents.removeClass('active');

			$tabs.filter('[data-tab="' + tabId + '"]')
				.addClass('nav-tab-active mvweb-de-tabs__tab--active');
			$('#mvweb-de-tab-' + tabId).addClass('active');

			try {
				localStorage.setItem(STORAGE_KEY, tabId);
			} catch (e) {
				// localStorage may be unavailable.
			}

			// Lazy-load tab content.
			if (tabId === 'presets') {
				loadPresetsList();
			} else if (tabId === 'history') {
				loadHistoryList();
			}
		}

		$tabs.on('click', function (e) {
			e.preventDefault();
			activateTab($(this).data('tab'));
		});

		// Restore saved tab or default to first.
		var savedTab = '';
		try {
			savedTab = localStorage.getItem(STORAGE_KEY) || '';
		} catch (e) {
			// Ignore.
		}

		var validTabs = $tabs.map(function () {
			return $(this).data('tab');
		}).get();

		if (savedTab && validTabs.indexOf(savedTab) !== -1) {
			activateTab(savedTab);
		} else {
			activateTab(validTabs[0]);
		}
	}

	/* ──────────────────────────────────────────
	   Notices
	   ────────────────────────────────────────── */

	function showNotice(message, type) {
		type = type || 'success';
		var $container = $('#mvweb-de-notices');
		var $notice = $(
			'<div class="notice notice-' + escAttr(type) + ' is-dismissible">' +
			'<p>' + escHtml(message) + '</p>' +
			'<button type="button" class="notice-dismiss"></button>' +
			'</div>'
		);

		$container.empty().append($notice);

		$notice.find('.notice-dismiss').on('click', function () {
			$notice.fadeOut(200, function () {
				$(this).remove();
			});
		});

		if (type === 'success') {
			setTimeout(function () {
				$notice.fadeOut(200, function () {
					$(this).remove();
				});
			}, 5000);
		}
	}

	/* ──────────────────────────────────────────
	   Settings Form
	   ────────────────────────────────────────── */

	function initSettings() {
		var $form = $('#mvweb-de-settings-form');
		if (!$form.length) {
			return;
		}

		$form.on('submit', function (e) {
			e.preventDefault();

			var $btn = $('#mvweb-de-save-settings');
			var $spinner = $('#mvweb-de-settings-spinner');
			var originalText = $btn.text();

			$btn.prop('disabled', true).text(mvwebDeAdmin.i18n.saving);
			$spinner.addClass('is-active');

			var data = $form.serializeArray();
			data.push({ name: 'action', value: 'mvweb_de_save_settings' });
			data.push({ name: 'nonce', value: mvwebDeAdmin.nonce });

			$.post(mvwebDeAdmin.ajax_url, $.param(data))
				.done(function (response) {
					if (response.success) {
						showNotice(response.data.message, 'success');
					} else {
						showNotice(response.data.message || mvwebDeAdmin.i18n.error, 'error');
					}
				})
				.fail(function () {
					showNotice(mvwebDeAdmin.i18n.error, 'error');
				})
				.always(function () {
					$btn.prop('disabled', false).text(originalText);
					$spinner.removeClass('is-active');
				});
		});
	}

	/* ──────────────────────────────────────────
	   Export Tab: Source Selection
	   ────────────────────────────────────────── */

	// Cache for filters data keyed by post type.
	var filtersCache = {};

	function initExportTab() {
		var $exportType = $('input[name="mvweb_de_export_type"]');
		var $source = $('#mvweb-de-source');

		if (!$exportType.length) {
			return;
		}

		// Parse source data.
		var postTypes = [];
		var taxonomies = [];

		try {
			postTypes = JSON.parse($('#mvweb-de-post-types-data').text() || '[]');
		} catch (e) { /* */ }

		try {
			taxonomies = JSON.parse($('#mvweb-de-taxonomies-data').text() || '[]');
		} catch (e) { /* */ }

		// Toggle source dropdown on export type change.
		$exportType.on('change', function () {
			var type = $('input[name="mvweb_de_export_type"]:checked').val();
			populateSourceDropdown(type);
			clearFields();
			hideFilters();
			hidePreview();

			// Update source label.
			var $label = $('.mvweb-de-export__source-label');
			$label.text(type === 'taxonomies' ? $label.data('taxonomies') : $label.data('posts'));
		});

		function populateSourceDropdown(type) {
			var items = (type === 'taxonomies') ? taxonomies : postTypes;

			$source.empty().append('<option value="">&mdash;</option>');
			$.each(items, function (i, item) {
				$source.append(
					$('<option>').val(item.slug).text(item.label)
				);
			});
		}

		// Initial population.
		populateSourceDropdown('posts');

		// Load fields + filters on source change.
		$source.on('change', function () {
			var source = $(this).val();
			if (!source) {
				clearFields();
				hideFilters();
				hidePreview();
				return;
			}
			loadFields();
			loadFilters();
			hidePreview();
		});

		// Taxonomy dropdown change — show terms for selected taxonomy.
		$('#mvweb-de-filter-taxonomy').on('change', function () {
			var taxSlug = $(this).val();
			populateTaxTerms(taxSlug);
		});
	}

	/* ──────────────────────────────────────────
	   Export Tab: Filters
	   ────────────────────────────────────────── */

	function loadFilters() {
		var exportType = $('input[name="mvweb_de_export_type"]:checked').val();

		// Filters only for posts.
		if (exportType !== 'posts') {
			hideFilters();
			return;
		}

		var source = $('#mvweb-de-source').val();
		if (!source) {
			hideFilters();
			return;
		}

		// Check cache.
		if (filtersCache[source]) {
			renderFilters(filtersCache[source]);
			return;
		}

		$.post(mvwebDeAdmin.ajax_url, {
			action: 'mvweb_de_get_filters',
			nonce: mvwebDeAdmin.nonce,
			source: source
		})
			.done(function (response) {
				if (response.success) {
					filtersCache[source] = response.data;
					renderFilters(response.data);
				}
			});
	}

	function renderFilters(data) {
		// Statuses.
		var $status = $('#mvweb-de-filter-status');
		$status.empty();
		$.each(data.statuses, function (i, s) {
			$status.append($('<option>').val(s.value).text(s.label));
		});

		// Authors.
		var $author = $('#mvweb-de-filter-author');
		$author.empty().append('<option value="">' + escHtml(mvwebDeAdmin.i18n.allAuthors) + '</option>');
		$.each(data.authors, function (i, a) {
			$author.append($('<option>').val(a.value).text(a.label));
		});

		// Taxonomy dropdown.
		var $taxSelect = $('#mvweb-de-filter-taxonomy');
		var $taxRow = $('#mvweb-de-filter-tax-row');
		$taxSelect.empty().append('<option value="">' + escHtml(mvwebDeAdmin.i18n.allTerms) + '</option>');

		if (data.taxonomies && data.taxonomies.length) {
			$.each(data.taxonomies, function (i, tax) {
				$taxSelect.append($('<option>').val(tax.slug).text(tax.label));
			});
			$taxRow.show();
			// Store taxonomy terms data.
			$taxSelect.data('taxData', data.taxonomies);
		} else {
			$taxRow.hide();
		}

		// Reset terms.
		$('#mvweb-de-filter-terms').empty().hide();

		// Reset date fields.
		$('#mvweb-de-filter-date-from').val('');
		$('#mvweb-de-filter-date-to').val('');

		// WooCommerce filters.
		renderWcFilters(data);

		$('#mvweb-de-filters-section').show();
	}

	function renderWcFilters(data) {
		var $wcRows = $('.mvweb-de-filters__row--wc');

		if (!data.has_wc_filters) {
			$wcRows.hide();
			$('#mvweb-de-variation-section').hide();
			return;
		}

		// Stock statuses.
		var $stock = $('#mvweb-de-filter-stock-status');
		$stock.empty();
		if (data.stock_statuses && data.stock_statuses.length) {
			$.each(data.stock_statuses, function (i, s) {
				$stock.append($('<option>').val(s.value).text(s.label));
			});
		}

		// Product types.
		var $types = $('#mvweb-de-filter-product-type');
		$types.empty();
		if (data.product_types && data.product_types.length) {
			$.each(data.product_types, function (i, t) {
				$types.append($('<option>').val(t.value).text(t.label));
			});
		}

		// Reset price range.
		$('#mvweb-de-filter-price-min').val('');
		$('#mvweb-de-filter-price-max').val('');

		$wcRows.show();

		// Show variation mode selector.
		$('#mvweb-de-variation-section').show();

		// Initialize selectWoo on WC multi-selects if available.
		initSelectWoo();
	}

	function initSelectWoo() {
		if (!mvwebDeAdmin.has_select_woo || !$.fn.selectWoo) {
			return;
		}

		$('.mvweb-de-filters__select--wc').each(function () {
			var $el = $(this);
			if (!$el.hasClass('select2-hidden-accessible')) {
				$el.selectWoo({
					width: '280px',
					allowClear: true,
					placeholder: '',
					minimumResultsForSearch: -1
				});
			}
		});
	}

	function populateTaxTerms(taxSlug) {
		var $terms = $('#mvweb-de-filter-terms');
		$terms.empty();

		if (!taxSlug) {
			$terms.hide();
			return;
		}

		var taxData = $('#mvweb-de-filter-taxonomy').data('taxData') || [];
		var found = null;
		$.each(taxData, function (i, tax) {
			if (tax.slug === taxSlug) {
				found = tax;
				return false;
			}
		});

		if (!found || !found.terms.length) {
			$terms.hide();
			return;
		}

		$.each(found.terms, function (i, term) {
			$terms.append($('<option>').val(term.value).text(term.label));
		});
		$terms.show();

		// Update label.
		$('#mvweb-de-filter-tax-label').text(found.label);
	}

	function hideFilters() {
		$('#mvweb-de-filters-section').hide();
		$('#mvweb-de-filter-status').empty();
		$('#mvweb-de-filter-author').empty();
		$('#mvweb-de-filter-taxonomy').empty();
		$('#mvweb-de-filter-terms').empty().hide();
		$('#mvweb-de-filter-date-from').val('');
		$('#mvweb-de-filter-date-to').val('');

		// WC filters.
		$('.mvweb-de-filters__row--wc').hide();
		$('#mvweb-de-filter-price-min').val('');
		$('#mvweb-de-filter-price-max').val('');
		$('#mvweb-de-filter-stock-status').empty();
		$('#mvweb-de-filter-product-type').empty();
		$('#mvweb-de-variation-section').hide();
	}

	function getFilterValues() {
		var filters = {};

		// Post status.
		var statuses = $('#mvweb-de-filter-status').val();
		if (statuses && statuses.length) {
			filters.filter_status = statuses;
		}

		// Taxonomy.
		var taxonomy = $('#mvweb-de-filter-taxonomy').val();
		if (taxonomy) {
			filters.filter_taxonomy = taxonomy;
			var terms = $('#mvweb-de-filter-terms').val();
			if (terms && terms.length) {
				filters.filter_terms = terms;
			}
		}

		// Date range.
		var dateFrom = $('#mvweb-de-filter-date-from').val();
		if (dateFrom) {
			filters.filter_date_from = dateFrom;
		}
		var dateTo = $('#mvweb-de-filter-date-to').val();
		if (dateTo) {
			filters.filter_date_to = dateTo;
		}

		// Author.
		var author = $('#mvweb-de-filter-author').val();
		if (author) {
			filters.filter_author = author;
		}

		// WC: Price range.
		var priceMin = $('#mvweb-de-filter-price-min').val();
		if (priceMin !== '' && priceMin !== undefined) {
			filters.filter_price_min = priceMin;
		}
		var priceMax = $('#mvweb-de-filter-price-max').val();
		if (priceMax !== '' && priceMax !== undefined) {
			filters.filter_price_max = priceMax;
		}

		// WC: Stock status.
		var stockStatus = $('#mvweb-de-filter-stock-status').val();
		if (stockStatus && stockStatus.length) {
			filters.filter_stock_status = stockStatus;
		}

		// WC: Product type.
		var productType = $('#mvweb-de-filter-product-type').val();
		if (productType && productType.length) {
			filters.filter_product_type = productType;
		}

		return filters;
	}

	/* ──────────────────────────────────────────
	   Export Tab: Field Loading & Sortable
	   ────────────────────────────────────────── */

	function loadFields(callback) {
		var exportType = $('input[name="mvweb_de_export_type"]:checked').val();
		var source = $('#mvweb-de-source').val();
		var $spinner = $('#mvweb-de-fields-spinner');

		if (!source) {
			return;
		}

		$spinner.addClass('is-active');

		$.post(mvwebDeAdmin.ajax_url, {
			action: 'mvweb_de_get_fields',
			nonce: mvwebDeAdmin.nonce,
			export_type: exportType,
			source: source
		})
			.done(function (response) {
				if (response.success) {
					renderFieldLists(response.data.groups);
					$('#mvweb-de-fields-section').show();
					$('#mvweb-de-export-actions').show();
					if (typeof callback === 'function') {
						callback(response.data.groups);
					}
				} else {
					showNotice(response.data.message || mvwebDeAdmin.i18n.error, 'error');
				}
			})
			.fail(function () {
				showNotice(mvwebDeAdmin.i18n.error, 'error');
			})
			.always(function () {
				$spinner.removeClass('is-active');
			});
	}

	function renderFieldLists(groups) {
		var $available = $('#mvweb-de-available-fields');
		var $selected = $('#mvweb-de-selected-fields');

		$available.empty();
		$selected.empty();

		$.each(groups, function (groupKey, group) {
			if (!group.fields || !group.fields.length) {
				return;
			}

			// Group header in available list.
			$available.append(
				'<li class="mvweb-de-fields__group-header">' +
				'<strong>' + escHtml(group.label) + '</strong>' +
				'</li>'
			);

			$.each(group.fields, function (i, field) {
				$available.append(
					'<li class="mvweb-de-fields__item" data-key="' + escAttr(field.key) + '">' +
					'<span class="mvweb-de-fields__handle dashicons dashicons-menu"></span> ' +
					escHtml(field.label) +
					'</li>'
				);
			});
		});

		initSortable();
	}

	function initSortable() {
		var $available = $('#mvweb-de-available-fields');
		var $selected = $('#mvweb-de-selected-fields');

		// Destroy existing if re-initializing.
		if ($available.hasClass('ui-sortable')) {
			$available.sortable('destroy');
		}
		if ($selected.hasClass('ui-sortable')) {
			$selected.sortable('destroy');
		}

		$available.sortable({
			connectWith: '#mvweb-de-selected-fields',
			items: '.mvweb-de-fields__item',
			placeholder: 'mvweb-de-fields__placeholder',
			handle: '.mvweb-de-fields__handle',
			tolerance: 'pointer',
			receive: function () {
				// When item returns to available list — no special action needed.
			}
		});

		$selected.sortable({
			connectWith: '#mvweb-de-available-fields',
			items: '.mvweb-de-fields__item',
			placeholder: 'mvweb-de-fields__placeholder',
			handle: '.mvweb-de-fields__handle',
			tolerance: 'pointer'
		});

		// Double-click to move between lists.
		$available.on('dblclick', '.mvweb-de-fields__item', function () {
			$(this).appendTo($selected);
		});

		$selected.on('dblclick', '.mvweb-de-fields__item', function () {
			$(this).appendTo($available);
		});
	}

	function clearFields() {
		$('#mvweb-de-available-fields').empty();
		$('#mvweb-de-selected-fields').empty();
		$('#mvweb-de-fields-section').hide();
		$('#mvweb-de-export-actions').hide();
	}

	/* ──────────────────────────────────────────
	   Export Tab: Select All / Clear All / Move
	   ────────────────────────────────────────── */

	function initFieldActions() {
		$('#mvweb-de-select-all').on('click', function () {
			$('#mvweb-de-available-fields .mvweb-de-fields__item').each(function () {
				$(this).appendTo('#mvweb-de-selected-fields');
			});
		});

		$('#mvweb-de-clear-all').on('click', function () {
			$('#mvweb-de-selected-fields .mvweb-de-fields__item').each(function () {
				$(this).appendTo('#mvweb-de-available-fields');
			});
		});

		// Move up/down (mobile fallback).
		$('#mvweb-de-move-up').on('click', function () {
			var $active = $('#mvweb-de-selected-fields .mvweb-de-fields__item--active');
			if ($active.length && $active.prev('.mvweb-de-fields__item').length) {
				$active.insertBefore($active.prev('.mvweb-de-fields__item'));
			}
		});

		$('#mvweb-de-move-down').on('click', function () {
			var $active = $('#mvweb-de-selected-fields .mvweb-de-fields__item--active');
			if ($active.length && $active.next('.mvweb-de-fields__item').length) {
				$active.insertAfter($active.next('.mvweb-de-fields__item'));
			}
		});

		// Click to select for move up/down.
		$(document).on('click', '#mvweb-de-selected-fields .mvweb-de-fields__item', function (e) {
			if ($(e.target).hasClass('mvweb-de-fields__handle')) {
				return;
			}
			$('#mvweb-de-selected-fields .mvweb-de-fields__item').removeClass('mvweb-de-fields__item--active');
			$(this).addClass('mvweb-de-fields__item--active');
		});
	}

	/* ──────────────────────────────────────────
	   Preview
	   ────────────────────────────────────────── */

	function initPreviewButton() {
		$('#mvweb-de-btn-preview').on('click', function () {
			requestPreview();
		});
	}

	function requestPreview() {
		var fields = getSelectedFields();
		if (!fields.length) {
			showNotice(mvwebDeAdmin.i18n.selectFields, 'warning');
			return;
		}

		var $btn = $('#mvweb-de-btn-preview');
		$btn.prop('disabled', true).text(mvwebDeAdmin.i18n.loading);

		var data = {
			action: 'mvweb_de_preview',
			nonce: mvwebDeAdmin.nonce,
			export_type: $('input[name="mvweb_de_export_type"]:checked').val(),
			source: $('#mvweb-de-source').val(),
			fields: fields,
			format: $('input[name="mvweb_de_format"]:checked').val(),
			url_format: $('input[name="mvweb_de_url_format"]:checked').val(),
			sort_by: $('#mvweb-de-sort-by').val(),
			sort_order: $('#mvweb-de-sort-order').val(),
			variation_mode: $('input[name="mvweb_de_variation_mode"]:checked').val() || 'inline'
		};

		// Add filters.
		var filters = getFilterValues();
		$.extend(data, filters);

		$.post(mvwebDeAdmin.ajax_url, data)
			.done(function (response) {
				if (response.success) {
					renderPreview(response.data);
				} else {
					showNotice(response.data.message || mvwebDeAdmin.i18n.error, 'error');
				}
			})
			.fail(function () {
				showNotice(mvwebDeAdmin.i18n.error, 'error');
			})
			.always(function () {
				$btn.prop('disabled', false).text(mvwebDeAdmin.i18n.preview);
			});
	}

	function renderPreview(data) {
		var $thead = $('#mvweb-de-preview-thead');
		var $tbody = $('#mvweb-de-preview-tbody');

		$thead.empty();
		$tbody.empty();

		// Headers (already escaped server-side).
		var headerRow = '<tr>';
		$.each(data.headers, function (i, h) {
			headerRow += '<th>' + h + '</th>';
		});
		headerRow += '</tr>';
		$thead.append(headerRow);

		// Rows (already escaped server-side).
		if (!data.rows.length) {
			$tbody.append(
				'<tr><td colspan="' + data.headers.length + '">' +
				escHtml(mvwebDeAdmin.i18n.noResults) +
				'</td></tr>'
			);
		} else {
			$.each(data.rows, function (i, row) {
				var tr = '<tr>';
				$.each(row, function (j, cell) {
					tr += '<td>' + cell + '</td>';
				});
				tr += '</tr>';
				$tbody.append(tr);
			});
		}

		// Total count.
		$('#mvweb-de-preview-count').text(
			'(' + mvwebDeAdmin.i18n.totalRecords + ': ' + formatNumber(data.total) + ')'
		);

		$('#mvweb-de-preview').show();
	}

	function hidePreview() {
		$('#mvweb-de-preview').hide();
		$('#mvweb-de-preview-thead').empty();
		$('#mvweb-de-preview-tbody').empty();
		$('#mvweb-de-preview-count').text('');
	}

	/* ──────────────────────────────────────────
	   Export Flow
	   ────────────────────────────────────────── */

	function initExportButton() {
		$('#mvweb-de-btn-export').on('click', function () {
			startExport();
		});

		$('#mvweb-de-btn-cancel').on('click', function () {
			if (confirm(mvwebDeAdmin.i18n.confirmCancel)) {
				cancelExport();
			}
		});
	}

	function getSelectedFields() {
		var fields = [];
		$('#mvweb-de-selected-fields .mvweb-de-fields__item').each(function () {
			fields.push($(this).data('key'));
		});
		return fields;
	}

	function startExport() {
		var fields = getSelectedFields();
		if (!fields.length) {
			showNotice(mvwebDeAdmin.i18n.selectFields, 'warning');
			return;
		}

		var $btn = $('#mvweb-de-btn-export');
		$btn.prop('disabled', true);
		$('#mvweb-de-btn-preview').prop('disabled', true);

		showProgress(0, 0, 0);

		var data = {
			action: 'mvweb_de_start_export',
			nonce: mvwebDeAdmin.nonce,
			export_type: $('input[name="mvweb_de_export_type"]:checked').val(),
			source: $('#mvweb-de-source').val(),
			fields: fields,
			format: $('input[name="mvweb_de_format"]:checked').val(),
			url_format: $('input[name="mvweb_de_url_format"]:checked').val(),
			sort_by: $('#mvweb-de-sort-by').val(),
			sort_order: $('#mvweb-de-sort-order').val(),
			variation_mode: $('input[name="mvweb_de_variation_mode"]:checked').val() || 'inline'
		};

		// Add filters.
		var filters = getFilterValues();
		$.extend(data, filters);

		$.post(mvwebDeAdmin.ajax_url, data)
			.done(function (response) {
				if (response.success) {
					currentSessionId = response.data.session_id;
					isExporting = true;
					showProgress(0, response.data.total, 0);
					processBatch();
				} else {
					hideProgress();
					$btn.prop('disabled', false);
					$('#mvweb-de-btn-preview').prop('disabled', false);
					showNotice(response.data.message || mvwebDeAdmin.i18n.error, 'error');
				}
			})
			.fail(function () {
				hideProgress();
				$btn.prop('disabled', false);
				$('#mvweb-de-btn-preview').prop('disabled', false);
				showNotice(mvwebDeAdmin.i18n.error, 'error');
			});
	}

	function processBatch() {
		if (!isExporting || !currentSessionId) {
			return;
		}

		$.post(mvwebDeAdmin.ajax_url, {
			action: 'mvweb_de_export_batch',
			nonce: mvwebDeAdmin.nonce,
			session_id: currentSessionId
		})
			.done(function (response) {
				if (!response.success) {
					finishExport(false, response.data.message);
					return;
				}

				var data = response.data;
				showProgress(data.processed, data.total, data.progress_percent);

				if (data.memory_warning) {
					showNotice(mvwebDeAdmin.i18n.memoryWarning, 'warning');
				}

				if (data.is_complete) {
					finishExport(true, null, data.file_id);
				} else {
					// Process next batch.
					processBatch();
				}
			})
			.fail(function () {
				finishExport(false, mvwebDeAdmin.i18n.error);
			});
	}

	function cancelExport() {
		isExporting = false;

		if (!currentSessionId) {
			hideProgress();
			$('#mvweb-de-btn-export').prop('disabled', false);
			return;
		}

		$.post(mvwebDeAdmin.ajax_url, {
			action: 'mvweb_de_cancel_export',
			nonce: mvwebDeAdmin.nonce,
			session_id: currentSessionId
		})
			.always(function () {
				currentSessionId = null;
				hideProgress();
				$('#mvweb-de-btn-export').prop('disabled', false);
				$('#mvweb-de-btn-preview').prop('disabled', false);
				showNotice(mvwebDeAdmin.i18n.cancelled, 'info');
			});
	}

	function finishExport(success, errorMessage, fileId) {
		isExporting = false;
		currentSessionId = null;

		if (success && fileId) {
			showNotice(mvwebDeAdmin.i18n.completed, 'success');

			// Trigger download.
			var downloadUrl = mvwebDeAdmin.ajax_url +
				'?action=mvweb_de_download&file_id=' + encodeURIComponent(fileId) +
				'&nonce=' + encodeURIComponent(mvwebDeAdmin.nonce);

			var $iframe = $('<iframe>', {
				src: downloadUrl,
				style: 'display:none'
			}).appendTo('body');

			setTimeout(function () {
				$iframe.remove();
			}, 30000);
		} else {
			showNotice(errorMessage || mvwebDeAdmin.i18n.error, 'error');
		}

		hideProgress();
		$('#mvweb-de-btn-export').prop('disabled', false);
		$('#mvweb-de-btn-preview').prop('disabled', false);
	}

	/* ──────────────────────────────────────────
	   Progress Bar
	   ────────────────────────────────────────── */

	function showProgress(processed, total, percent) {
		var $progress = $('#mvweb-de-progress');
		$progress.show();
		$('#mvweb-de-progress-bar').css('width', percent + '%');
		$('#mvweb-de-progress-text').text(
			mvwebDeAdmin.i18n.exporting + ' ' +
			formatNumber(processed) + ' / ' + formatNumber(total) +
			' (' + percent + '%)'
		);
	}

	function hideProgress() {
		$('#mvweb-de-progress').hide();
		$('#mvweb-de-progress-bar').css('width', '0%');
	}

	/* ──────────────────────────────────────────
	   Presets — Export Tab Controls
	   ────────────────────────────────────────── */

	function initPresetControls() {
		var $select = $('#mvweb-de-preset-select');
		var $loadBtn = $('#mvweb-de-preset-load');
		var $saveBtn = $('#mvweb-de-preset-save');

		if (!$select.length) {
			return;
		}

		// Populate preset dropdown.
		refreshPresetDropdown();

		// Enable/disable load button.
		$select.on('change', function () {
			$loadBtn.prop('disabled', !$(this).val());
		});

		// Load preset.
		$loadBtn.on('click', function () {
			var presetId = $select.val();
			if (presetId) {
				applyPreset(presetId);
			}
		});

		// Save as preset.
		$saveBtn.on('click', function () {
			var name = prompt(mvwebDeAdmin.i18n.presetNamePrompt);
			if (!name || !name.trim()) {
				return;
			}
			saveCurrentAsPreset(name.trim());
		});
	}

	function refreshPresetDropdown() {
		var $select = $('#mvweb-de-preset-select');

		$.post(mvwebDeAdmin.ajax_url, {
			action: 'mvweb_de_get_presets',
			nonce: mvwebDeAdmin.nonce
		})
			.done(function (response) {
				if (!response.success) {
					return;
				}

				$select.empty().append(
					'<option value="">' + escHtml(mvwebDeAdmin.i18n.loadPreset) + '</option>'
				);

				$.each(response.data.presets, function (i, preset) {
					$select.append(
						$('<option>').val(preset.id).text(preset.name)
					);
				});

				// Store presets data for loading.
				$select.data('presets', response.data.presets);
			});
	}

	function applyPreset(presetId) {
		var presets = $('#mvweb-de-preset-select').data('presets') || [];
		var preset = null;

		$.each(presets, function (i, p) {
			if (p.id === presetId) {
				preset = p;
				return false;
			}
		});

		if (!preset) {
			return;
		}

		var $spinner = $('#mvweb-de-preset-spinner');
		$spinner.addClass('is-active');

		// Set export type.
		$('input[name="mvweb_de_export_type"]')
			.filter('[value="' + preset.export_type + '"]')
			.prop('checked', true)
			.trigger('change');

		// Wait for source dropdown to populate, then set source.
		setTimeout(function () {
			$('#mvweb-de-source').val(preset.source);

			// Set format.
			$('input[name="mvweb_de_format"]')
				.filter('[value="' + preset.format + '"]')
				.prop('checked', true);

			// Set URL format.
			$('input[name="mvweb_de_url_format"]')
				.filter('[value="' + preset.url_format + '"]')
				.prop('checked', true);

			// Set sort.
			$('#mvweb-de-sort-by').val(preset.sort_by);
			$('#mvweb-de-sort-order').val(preset.sort_order);

			// Set variation mode.
			if (preset.variation_mode) {
				$('input[name="mvweb_de_variation_mode"]')
					.filter('[value="' + preset.variation_mode + '"]')
					.prop('checked', true);
			}

			// Load fields, then select the preset's fields.
			loadFields(function () {
				selectPresetFields(preset.fields);

				// Apply filters after fields are loaded.
				if (preset.export_type === 'posts') {
					loadFiltersForPreset(preset);
				}

				$spinner.removeClass('is-active');
			});
		}, 100);
	}

	function selectPresetFields(fieldKeys) {
		if (!fieldKeys || !fieldKeys.length) {
			return;
		}

		var $available = $('#mvweb-de-available-fields');
		var $selected = $('#mvweb-de-selected-fields');

		// Move matching fields to selected in order.
		$.each(fieldKeys, function (i, key) {
			var $item = $available.find('.mvweb-de-fields__item[data-key="' + key + '"]');
			if ($item.length) {
				$item.appendTo($selected);
			}
		});
	}

	function loadFiltersForPreset(preset) {
		var source = preset.source;
		var filters = preset.filters || {};

		// Ensure filters are loaded, then set values.
		var applyFilterValues = function () {
			// Status.
			if (filters.filter_status && filters.filter_status.length) {
				$('#mvweb-de-filter-status').val(filters.filter_status);
			}

			// Taxonomy.
			if (filters.filter_taxonomy) {
				$('#mvweb-de-filter-taxonomy').val(filters.filter_taxonomy).trigger('change');

				// Wait for terms to populate.
				setTimeout(function () {
					if (filters.filter_terms && filters.filter_terms.length) {
						var termStrings = $.map(filters.filter_terms, function (t) {
							return String(t);
						});
						$('#mvweb-de-filter-terms').val(termStrings);
					}
				}, 100);
			}

			// Date range.
			if (filters.filter_date_from) {
				$('#mvweb-de-filter-date-from').val(filters.filter_date_from);
			}
			if (filters.filter_date_to) {
				$('#mvweb-de-filter-date-to').val(filters.filter_date_to);
			}

			// Author.
			if (filters.filter_author) {
				$('#mvweb-de-filter-author').val(String(filters.filter_author));
			}

			// WC: Price range.
			if (filters.filter_price_min !== undefined && filters.filter_price_min !== '') {
				$('#mvweb-de-filter-price-min').val(filters.filter_price_min);
			}
			if (filters.filter_price_max !== undefined && filters.filter_price_max !== '') {
				$('#mvweb-de-filter-price-max').val(filters.filter_price_max);
			}

			// WC: Stock status.
			if (filters.filter_stock_status && filters.filter_stock_status.length) {
				$('#mvweb-de-filter-stock-status').val(filters.filter_stock_status);
				if ($.fn.selectWoo) {
					$('#mvweb-de-filter-stock-status').trigger('change.select2');
				}
			}

			// WC: Product type.
			if (filters.filter_product_type && filters.filter_product_type.length) {
				$('#mvweb-de-filter-product-type').val(filters.filter_product_type);
				if ($.fn.selectWoo) {
					$('#mvweb-de-filter-product-type').trigger('change.select2');
				}
			}
		};

		// Check if filters are already cached.
		if (filtersCache[source]) {
			renderFilters(filtersCache[source]);
			applyFilterValues();
		} else {
			$.post(mvwebDeAdmin.ajax_url, {
				action: 'mvweb_de_get_filters',
				nonce: mvwebDeAdmin.nonce,
				source: source
			})
				.done(function (response) {
					if (response.success) {
						filtersCache[source] = response.data;
						renderFilters(response.data);
						applyFilterValues();
					}
				});
		}
	}

	function saveCurrentAsPreset(name) {
		var fields = getSelectedFields();
		if (!fields.length) {
			showNotice(mvwebDeAdmin.i18n.selectFields, 'warning');
			return;
		}

		var $spinner = $('#mvweb-de-preset-spinner');
		$spinner.addClass('is-active');

		var data = {
			action: 'mvweb_de_save_preset',
			nonce: mvwebDeAdmin.nonce,
			preset_name: name,
			export_type: $('input[name="mvweb_de_export_type"]:checked').val(),
			source: $('#mvweb-de-source').val(),
			fields: fields,
			format: $('input[name="mvweb_de_format"]:checked').val(),
			url_format: $('input[name="mvweb_de_url_format"]:checked').val(),
			sort_by: $('#mvweb-de-sort-by').val(),
			sort_order: $('#mvweb-de-sort-order').val(),
			variation_mode: $('input[name="mvweb_de_variation_mode"]:checked').val() || 'inline'
		};

		// Add filters.
		var filters = getFilterValues();
		$.extend(data, filters);

		$.post(mvwebDeAdmin.ajax_url, data)
			.done(function (response) {
				if (response.success) {
					showNotice(response.data.message, 'success');
					refreshPresetDropdown();
				} else {
					showNotice(response.data.message || mvwebDeAdmin.i18n.error, 'error');
				}
			})
			.fail(function () {
				showNotice(mvwebDeAdmin.i18n.error, 'error');
			})
			.always(function () {
				$spinner.removeClass('is-active');
			});
	}

	/* ──────────────────────────────────────────
	   Presets Tab
	   ────────────────────────────────────────── */

	var presetsLoaded = false;

	function loadPresetsList() {
		if (presetsLoaded) {
			return;
		}

		var $loading = $('#mvweb-de-presets-loading');
		var $table = $('#mvweb-de-presets-table');
		var $empty = $('#mvweb-de-presets-empty');

		$loading.show();
		$table.hide();
		$empty.hide();

		$.post(mvwebDeAdmin.ajax_url, {
			action: 'mvweb_de_get_presets',
			nonce: mvwebDeAdmin.nonce
		})
			.done(function (response) {
				if (!response.success) {
					return;
				}

				var presets = response.data.presets;

				if (!presets.length) {
					$empty.show();
				} else {
					renderPresetsTable(presets);
					$table.show();
				}

				presetsLoaded = true;
			})
			.always(function () {
				$loading.hide();
			});
	}

	function renderPresetsTable(presets) {
		var $tbody = $('#mvweb-de-presets-tbody');
		$tbody.empty();

		var isAdmin = mvwebDeAdmin.is_admin;

		$.each(presets, function (i, preset) {
			var typeLabel = preset.export_type === 'taxonomies'
				? mvwebDeAdmin.i18n.taxonomies
				: mvwebDeAdmin.i18n.postsCpt;

			var tr = '<tr data-id="' + escAttr(preset.id) + '">';
			tr += '<td><strong>' + escHtml(preset.name) + '</strong></td>';
			tr += '<td>' + escHtml(typeLabel) + '</td>';
			tr += '<td><code>' + escHtml(preset.source) + '</code></td>';
			tr += '<td>' + escHtml(preset.format.toUpperCase()) + '</td>';
			tr += '<td>' + preset.fields.length + '</td>';

			if (isAdmin) {
				tr += '<td>' + escHtml(preset.user_name) + '</td>';
			}

			tr += '<td>' + escHtml(preset.created_at) + '</td>';
			tr += '<td>';
			tr += '<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-btn--secondary mvweb-de-presets__load" data-id="' + escAttr(preset.id) + '">';
			tr += escHtml(mvwebDeAdmin.i18n.load);
			tr += '</button> ';
			tr += '<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-btn--danger mvweb-de-presets__delete" data-id="' + escAttr(preset.id) + '">';
			tr += escHtml(mvwebDeAdmin.i18n.deleteLabel);
			tr += '</button>';
			tr += '</td>';
			tr += '</tr>';

			$tbody.append(tr);
		});

		// Bind events.
		$tbody.off('click', '.mvweb-de-presets__load').on('click', '.mvweb-de-presets__load', function () {
			var presetId = $(this).data('id');
			// Switch to Export tab and apply preset.
			$('.mvweb-de-tabs__tab[data-tab="export"]').trigger('click');
			setTimeout(function () {
				$('#mvweb-de-preset-select').val(presetId);
				applyPreset(presetId);
			}, 100);
		});

		$tbody.off('click', '.mvweb-de-presets__delete').on('click', '.mvweb-de-presets__delete', function () {
			if (!confirm(mvwebDeAdmin.i18n.confirmDeletePreset)) {
				return;
			}

			var $btn = $(this);
			var presetId = $btn.data('id');

			$btn.prop('disabled', true);

			$.post(mvwebDeAdmin.ajax_url, {
				action: 'mvweb_de_delete_preset',
				nonce: mvwebDeAdmin.nonce,
				preset_id: presetId
			})
				.done(function (response) {
					if (response.success) {
						$btn.closest('tr').fadeOut(200, function () {
							$(this).remove();
							// Check if table is now empty.
							if (!$('#mvweb-de-presets-tbody tr').length) {
								$('#mvweb-de-presets-table').hide();
								$('#mvweb-de-presets-empty').show();
							}
						});
						refreshPresetDropdown();
						showNotice(response.data.message, 'success');
					} else {
						showNotice(response.data.message || mvwebDeAdmin.i18n.error, 'error');
						$btn.prop('disabled', false);
					}
				})
				.fail(function () {
					showNotice(mvwebDeAdmin.i18n.error, 'error');
					$btn.prop('disabled', false);
				});
		});
	}

	/* ──────────────────────────────────────────
	   History Tab
	   ────────────────────────────────────────── */

	var historyLoaded = false;

	function loadHistoryList() {
		if (historyLoaded) {
			return;
		}

		var $loading = $('#mvweb-de-history-loading');
		var $table = $('#mvweb-de-history-table');
		var $empty = $('#mvweb-de-history-empty');

		$loading.show();
		$table.hide();
		$empty.hide();

		$.post(mvwebDeAdmin.ajax_url, {
			action: 'mvweb_de_get_history',
			nonce: mvwebDeAdmin.nonce
		})
			.done(function (response) {
				if (!response.success) {
					return;
				}

				var history = response.data.history;

				if (!history.length) {
					$empty.show();
				} else {
					renderHistoryTable(history);
					$table.show();
				}

				historyLoaded = true;
			})
			.always(function () {
				$loading.hide();
			});
	}

	function renderHistoryTable(history) {
		var $tbody = $('#mvweb-de-history-tbody');
		$tbody.empty();

		var isAdmin = mvwebDeAdmin.is_admin;

		$.each(history, function (i, entry) {
			var tr = '<tr data-id="' + escAttr(entry.id) + '">';

			// File name — link if file exists.
			if (entry.file_exists) {
				var downloadUrl = mvwebDeAdmin.ajax_url +
					'?action=mvweb_de_download&file_id=' + encodeURIComponent(entry.id) +
					'&nonce=' + encodeURIComponent(mvwebDeAdmin.nonce);
				tr += '<td><a href="' + downloadUrl + '" class="mvweb-de-history__download-link">' +
					escHtml(entry.filename) + '</a></td>';
			} else {
				tr += '<td><span class="mvweb-de-history__file-missing">' +
					escHtml(entry.filename) +
					' <em>(' + escHtml(mvwebDeAdmin.i18n.fileDeleted) + ')</em></span></td>';
			}

			tr += '<td><code>' + escHtml(entry.post_type) + '</code></td>';
			tr += '<td>' + escHtml(entry.format.toUpperCase()) + '</td>';
			tr += '<td>' + formatNumber(entry.rows) + '</td>';
			tr += '<td>' + escHtml(entry.filesize) + '</td>';

			if (isAdmin) {
				tr += '<td>' + escHtml(entry.user_name) + '</td>';
			}

			tr += '<td>' + escHtml(entry.created_at) + '</td>';
			tr += '<td>';

			if (entry.file_exists) {
				tr += '<a href="' + downloadUrl + '" class="mvweb-btn mvweb-btn--sm mvweb-btn--secondary">';
				tr += '<span class="dashicons dashicons-download" style="vertical-align: text-bottom; font-size: 16px; width: 16px; height: 16px;"></span>';
				tr += '</a> ';
			}

			tr += '<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-btn--danger mvweb-de-history__delete" data-id="' + escAttr(entry.id) + '">';
			tr += escHtml(mvwebDeAdmin.i18n.deleteLabel);
			tr += '</button>';
			tr += '</td>';
			tr += '</tr>';

			$tbody.append(tr);
		});

		// Bind delete.
		$tbody.off('click', '.mvweb-de-history__delete').on('click', '.mvweb-de-history__delete', function () {
			if (!confirm(mvwebDeAdmin.i18n.confirmDeleteHistory)) {
				return;
			}

			var $btn = $(this);
			var fileId = $btn.data('id');

			$btn.prop('disabled', true);

			$.post(mvwebDeAdmin.ajax_url, {
				action: 'mvweb_de_delete_history',
				nonce: mvwebDeAdmin.nonce,
				file_id: fileId
			})
				.done(function (response) {
					if (response.success) {
						$btn.closest('tr').fadeOut(200, function () {
							$(this).remove();
							if (!$('#mvweb-de-history-tbody tr').length) {
								$('#mvweb-de-history-table').hide();
								$('#mvweb-de-history-empty').show();
							}
						});
						showNotice(response.data.message, 'success');
					} else {
						showNotice(response.data.message || mvwebDeAdmin.i18n.error, 'error');
						$btn.prop('disabled', false);
					}
				})
				.fail(function () {
					showNotice(mvwebDeAdmin.i18n.error, 'error');
					$btn.prop('disabled', false);
				});
		});
	}

	/* ──────────────────────────────────────────
	   Utilities
	   ────────────────────────────────────────── */

	function escHtml(str) {
		var div = document.createElement('div');
		div.appendChild(document.createTextNode(str));
		return div.innerHTML;
	}

	function escAttr(str) {
		return String(str)
			.replace(/&/g, '&amp;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#39;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;');
	}

	function formatNumber(num) {
		return String(num).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
	}

	/* ──────────────────────────────────────────
	   DOM Ready
	   ────────────────────────────────────────── */

	$(function () {
		initTabs();
		initSettings();
		initExportTab();
		initFieldActions();
		initPreviewButton();
		initExportButton();
		initPresetControls();
	});

})(jQuery);
