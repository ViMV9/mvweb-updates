<?php
/**
 * Plugin Name:       MVweb Data Export
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-data-export
 * Description:       Export posts, pages, CPT and WooCommerce products to CSV/TXT.
 * Version:           1.0.4
 * Requires at least: 6.6
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-data-export
 * Domain Path:       /languages
 *
 * @package MVweb_Data_Export
 *
 * @since 0.1.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_DE_VERSION' ) ) {
	return;
}

/**
 * Plugin version.
 */
define( 'MVWEB_DE_VERSION', '1.0.4' );

/**
 * Plugin directory path.
 */
define( 'MVWEB_DE_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Plugin directory URL.
 */
define( 'MVWEB_DE_URL', plugin_dir_url( __FILE__ ) );

/**
 * Plugin basename.
 */
define( 'MVWEB_DE_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_DE_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_DE_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_DE_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
// Do NOT rely on get_instance() at end of class file — OPcache may skip it.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_DE_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_DE_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-data-export' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-data-export'] = array(
		'name'         => __( 'MVweb Data Export', 'mvweb-data-export' ),
		'description'  => __( 'Export posts, pages, CPT and WooCommerce products to CSV/TXT.', 'mvweb-data-export' ),
		'url'          => 'https://mvweb.ru/plugins/mvweb-data-export',
		'settings_url' => 'admin.php?page=mvweb-data-export',
		'textdomain'   => 'mvweb-data-export',
	);
	return $plugins;
} );

/**
 * Plugin activation hook.
 *
 * Creates export directory, generates .htaccess + index.php, sets default options.
 *
 * @since 0.1.0
 * @return void
 */
function mvweb_de_activate() {
	// Set default settings.
	if ( false === get_option( 'mvweb_de_settings' ) ) {
		$defaults = array(
			'encoding'      => 'utf8bom',
			'header_lang'   => 'auto',
			'batch_size'    => 100,
			'max_records'   => 10000,
			'max_history'   => 10,
			'delete_data'   => false,
		);
		add_option( 'mvweb_de_settings', $defaults );
	}

	// Create export directory with protections.
	require_once MVWEB_DE_PATH . 'includes/class-file-manager.php';
	MVweb_DE_File_Manager::ensure_export_dir();
}
register_activation_hook( __FILE__, 'mvweb_de_activate' );

/**
 * Plugin deactivation hook.
 *
 * Clears scheduled cron events.
 *
 * @since 0.1.0
 * @return void
 */
function mvweb_de_deactivate() {
	wp_clear_scheduled_hook( 'mvweb_de_cleanup_sessions' );
}
register_deactivation_hook( __FILE__, 'mvweb_de_deactivate' );

// Include dependencies and initialize plugin.
require_once MVWEB_DE_PATH . 'includes/helpers.php';
require_once MVWEB_DE_PATH . 'includes/class-mvweb-data-export.php';

$mvweb_de_plugin = new MVweb_Data_Export();
$mvweb_de_plugin->init();
