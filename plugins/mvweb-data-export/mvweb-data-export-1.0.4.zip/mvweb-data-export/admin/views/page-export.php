<?php
/**
 * Main admin page wrapper with tab navigation.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tabs = array(
	'export'   => _x( 'Export', 'tab title', 'mvweb-data-export' ),
	'presets'  => __( 'Presets', 'mvweb-data-export' ),
	'history'  => __( 'History', 'mvweb-data-export' ),
	'settings' => __( 'Settings', 'mvweb-data-export' ),
	'help'     => __( 'Help', 'mvweb-data-export' ),
);

// Settings tab only for admins.
$is_admin = current_user_can( 'manage_options' );
if ( ! $is_admin ) {
	unset( $tabs['settings'] );
}
?>
<div class="wrap mvweb-settings mvweb-settings--wide mvweb-de-wrap">
	<h1><?php esc_html_e( 'MVweb Data Export', 'mvweb-data-export' ); ?></h1>

	<nav class="nav-tab-wrapper mvweb-de-tabs">
		<?php foreach ( $tabs as $tab_id => $tab_label ) : ?>
			<a href="#<?php echo esc_attr( $tab_id ); ?>"
			   class="nav-tab mvweb-de-tabs__tab"
			   data-tab="<?php echo esc_attr( $tab_id ); ?>">
				<?php echo esc_html( $tab_label ); ?>
			</a>
		<?php endforeach; ?>
	</nav>

	<div class="mvweb-de-notices" id="mvweb-de-notices"></div>

	<?php
	$allowed_tabs = array( 'export', 'presets', 'history', 'settings', 'help' );

	foreach ( $tabs as $tab_id => $tab_label ) :
		if ( ! in_array( $tab_id, $allowed_tabs, true ) ) {
			continue;
		}

		$tab_file = MVWEB_DE_PATH . 'admin/views/tab-' . $tab_id . '.php';
		if ( ! file_exists( $tab_file ) ) {
			continue;
		}
		?>
		<div class="mvweb-de-tab-content" id="mvweb-de-tab-<?php echo esc_attr( $tab_id ); ?>">
			<?php include $tab_file; ?>
		</div>
	<?php endforeach; ?>
</div>
