<?php
/**
 * Settings tab content.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings    = mvweb_de_get_settings();
$system_info = MVweb_DE_File_Manager::get_system_info();
?>
<div class="mvweb-de-settings">
	<form id="mvweb-de-settings-form" class="mvweb-de-settings__form">

		<table class="form-table" role="presentation">
			<tbody>
				<!-- Encoding -->
				<tr>
					<th scope="row">
						<label for="mvweb-de-encoding"><?php esc_html_e( 'Encoding', 'mvweb-data-export' ); ?></label>
					</th>
					<td>
						<select id="mvweb-de-encoding" name="encoding" class="mvweb-select">
							<option value="utf8bom" <?php selected( $settings['encoding'], 'utf8bom' ); ?>>
								<?php esc_html_e( 'UTF-8 with BOM (recommended for Excel)', 'mvweb-data-export' ); ?>
							</option>
							<option value="utf8" <?php selected( $settings['encoding'], 'utf8' ); ?>>
								<?php esc_html_e( 'UTF-8 without BOM', 'mvweb-data-export' ); ?>
							</option>
						</select>
					</td>
				</tr>

				<!-- Header language -->
				<tr>
					<th scope="row">
						<label for="mvweb-de-header-lang"><?php esc_html_e( 'Column header language', 'mvweb-data-export' ); ?></label>
					</th>
					<td>
						<select id="mvweb-de-header-lang" name="header_lang" class="mvweb-select">
							<option value="auto" <?php selected( $settings['header_lang'], 'auto' ); ?>>
								<?php esc_html_e( 'Auto (admin language)', 'mvweb-data-export' ); ?>
							</option>
							<option value="en" <?php selected( $settings['header_lang'], 'en' ); ?>>
								English
							</option>
							<option value="ru" <?php selected( $settings['header_lang'], 'ru' ); ?>>
								Русский
							</option>
						</select>
						<div class="mvweb-help-text">
							<?php esc_html_e( 'Language for column headers in exported files.', 'mvweb-data-export' ); ?>
						</div>
					</td>
				</tr>

				<!-- Batch size -->
				<tr>
					<th scope="row">
						<label for="mvweb-de-batch-size"><?php esc_html_e( 'Batch size', 'mvweb-data-export' ); ?></label>
					</th>
					<td>
						<input type="number"
							   id="mvweb-de-batch-size"
							   name="batch_size"
							   value="<?php echo esc_attr( $settings['batch_size'] ); ?>"
							   min="10"
							   max="500"
							   step="10"
							   class="small-text">
						<div class="mvweb-help-text">
							<?php esc_html_e( 'Records per AJAX request (10–500).', 'mvweb-data-export' ); ?>
						</div>
					</td>
				</tr>

				<!-- Max records -->
				<tr>
					<th scope="row">
						<label for="mvweb-de-max-records"><?php esc_html_e( 'Max records per export', 'mvweb-data-export' ); ?></label>
					</th>
					<td>
						<input type="number"
							   id="mvweb-de-max-records"
							   name="max_records"
							   value="<?php echo esc_attr( $settings['max_records'] ); ?>"
							   min="100"
							   max="50000"
							   step="100"
							   class="small-text">
						<div class="mvweb-help-text">
							<?php esc_html_e( 'Maximum number of records for a single export (100–50,000).', 'mvweb-data-export' ); ?>
						</div>
					</td>
				</tr>

				<!-- Max history -->
				<tr>
					<th scope="row">
						<label for="mvweb-de-max-history"><?php esc_html_e( 'Max history files', 'mvweb-data-export' ); ?></label>
					</th>
					<td>
						<input type="number"
							   id="mvweb-de-max-history"
							   name="max_history"
							   value="<?php echo esc_attr( $settings['max_history'] ); ?>"
							   min="1"
							   max="50"
							   class="small-text">
						<div class="mvweb-help-text">
							<?php esc_html_e( 'Number of export files to keep in history (1–50).', 'mvweb-data-export' ); ?>
						</div>
					</td>
				</tr>

				<!-- Delete data on uninstall -->
				<tr>
					<th scope="row">
						<?php esc_html_e( 'Delete data on uninstall', 'mvweb-data-export' ); ?>
					</th>
					<td>
						<label class="mvweb-checkbox">
							<input type="checkbox"
								   id="mvweb-de-delete-data"
								   name="delete_data"
								   value="1"
								   <?php checked( $settings['delete_data'] ); ?>>
							<?php esc_html_e( 'Remove all plugin data (settings, presets, history, export files) when the plugin is deleted.', 'mvweb-data-export' ); ?>
						</label>
					</td>
				</tr>
			</tbody>
		</table>

		<p class="submit">
			<button type="submit" class="button button-primary" id="mvweb-de-save-settings">
				<?php esc_html_e( 'Save Settings', 'mvweb-data-export' ); ?>
			</button>
			<span class="mvweb-spinner" id="mvweb-de-settings-spinner"></span>
		</p>
	</form>

	<!-- System Information -->
	<div class="mvweb-de-settings__sysinfo mvweb-card">
		<h2 class="mvweb-card__title"><?php esc_html_e( 'System Information', 'mvweb-data-export' ); ?></h2>
		<table class="mvweb-table mvweb-table--striped">
			<tbody>
				<tr>
					<td><strong><?php esc_html_e( 'PHP memory_limit', 'mvweb-data-export' ); ?></strong></td>
					<td><?php echo esc_html( $system_info['php_memory_limit'] ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'max_execution_time', 'mvweb-data-export' ); ?></strong></td>
					<td><?php echo esc_html( $system_info['max_execution_time'] ); ?>s</td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'upload_max_filesize', 'mvweb-data-export' ); ?></strong></td>
					<td><?php echo esc_html( $system_info['upload_max_filesize'] ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Free disk space (uploads)', 'mvweb-data-export' ); ?></strong></td>
					<td><?php echo esc_html( $system_info['disk_free_space'] ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Export directory', 'mvweb-data-export' ); ?></strong></td>
					<td>
						<code><?php echo esc_html( $system_info['export_dir'] ); ?></code>
						<?php if ( $system_info['dir_exists'] ) : ?>
							<span class="dashicons dashicons-yes-alt mvweb-de-icon--success" title="<?php esc_attr_e( 'Directory exists', 'mvweb-data-export' ); ?>"></span>
						<?php else : ?>
							<span class="dashicons dashicons-warning mvweb-de-icon--error" title="<?php esc_attr_e( 'Directory missing', 'mvweb-data-export' ); ?>"></span>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Directory protection', 'mvweb-data-export' ); ?></strong></td>
					<td>
						<?php if ( $system_info['is_nginx'] ) : ?>
							<span class="dashicons dashicons-warning mvweb-de-icon--warning"></span>
							<?php esc_html_e( 'Nginx — manual configuration required (see notice above)', 'mvweb-data-export' ); ?>
						<?php elseif ( $system_info['htaccess_exists'] ) : ?>
							<span class="dashicons dashicons-yes-alt mvweb-de-icon--success"></span>
							<?php esc_html_e( '.htaccess protection active', 'mvweb-data-export' ); ?>
						<?php else : ?>
							<span class="dashicons dashicons-warning mvweb-de-icon--error"></span>
							<?php esc_html_e( '.htaccess missing — directory may be unprotected', 'mvweb-data-export' ); ?>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'WooCommerce', 'mvweb-data-export' ); ?></strong></td>
					<td><?php echo esc_html( $system_info['woocommerce'] ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>
