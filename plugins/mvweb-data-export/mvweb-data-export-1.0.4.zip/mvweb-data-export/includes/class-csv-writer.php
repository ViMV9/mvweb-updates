<?php
/**
 * CSV/TXT Writer for MVweb Data Export.
 *
 * Handles file creation, header writing, BOM, and batch appending.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_DE_CSV_Writer
 *
 * @since 0.1.0
 */
class MVweb_DE_CSV_Writer {

	/**
	 * Absolute path to the output file.
	 *
	 * @var string
	 */
	private string $filepath;

	/**
	 * File format: 'csv' or 'txt'.
	 *
	 * @var string
	 */
	private string $format;

	/**
	 * Whether to write UTF-8 BOM.
	 *
	 * @var bool
	 */
	private bool $use_bom;

	/**
	 * Field delimiter character.
	 *
	 * @var string
	 */
	private string $delimiter;

	/**
	 * Open file handle for streaming writes.
	 *
	 * @var resource|null
	 */
	private $stream_handle = null;

	/**
	 * Constructor.
	 *
	 * @since 0.1.0
	 * @param string $filepath Absolute path to the output file.
	 * @param string $format   File format: 'csv' or 'txt'.
	 * @param bool   $use_bom  Whether to write UTF-8 BOM on first write.
	 */
	public function __construct( string $filepath, string $format = 'csv', bool $use_bom = true ) {
		$this->filepath  = $filepath;
		$this->format    = $format;
		$this->use_bom   = $use_bom;
		$this->delimiter = ( 'txt' === $format ) ? "\t" : ';';
	}

	/**
	 * Create the file with headers (first batch).
	 *
	 * Writes BOM (if enabled) and the header row.
	 *
	 * @since 0.1.0
	 * @param array $headers Ordered array of column labels.
	 * @return bool True on success.
	 */
	public function create_with_headers( array $headers ): bool {
		$handle = null;

		try {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
			$handle = fopen( $this->filepath, 'wb' );
			if ( ! $handle ) {
				return false;
			}

			// Write BOM only on file creation.
			if ( $this->use_bom ) {
				fwrite( $handle, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
			}

			$this->write_row( $handle, $headers );

			return true;
		} catch ( \Throwable $e ) {
			return false;
		} finally {
			if ( $handle ) {
				fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			}
		}
	}

	/**
	 * Append rows to the file (subsequent batches).
	 *
	 * @since 0.1.0
	 * @param array $rows Array of rows, each row is an array of values.
	 * @return bool True on success.
	 */
	public function append_rows( array $rows ): bool {
		$handle = null;

		try {
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
			$handle = fopen( $this->filepath, 'ab' );
			if ( ! $handle ) {
				return false;
			}

			foreach ( $rows as $row ) {
				$this->write_row( $handle, $row );
			}

			return true;
		} catch ( \Throwable $e ) {
			return false;
		} finally {
			if ( $handle ) {
				fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			}
		}
	}

	/**
	 * Write a single row to the file.
	 *
	 * @since 0.1.0
	 * @param resource $handle File handle.
	 * @param array    $row    Array of cell values.
	 * @return void
	 */
	private function write_row( $handle, array $row ): void {
		if ( 'csv' === $this->format ) {
			fputcsv( $handle, $row, $this->delimiter, '"', '\\' );
		} else {
			// TXT (TSV) — simple tab-separated, no quoting.
			$line = implode( $this->delimiter, array_map( array( $this, 'escape_tsv_value' ), $row ) );
			fwrite( $handle, $line . "\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		}
	}

	/**
	 * Escape a value for TSV format.
	 *
	 * Replaces tabs and newlines with spaces.
	 *
	 * @since 0.1.0
	 * @param string $value Cell value.
	 * @return string Escaped value.
	 */
	private function escape_tsv_value( string $value ): string {
		return str_replace( array( "\t", "\r\n", "\r", "\n" ), ' ', $value );
	}

	/**
	 * Open the file for streaming append writes.
	 *
	 * @since 0.1.0
	 * @return bool True on success, false on failure.
	 */
	public function open_for_append(): bool {
		if ( $this->stream_handle ) {
			return true;
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		$this->stream_handle = fopen( $this->filepath, 'ab' );

		return (bool) $this->stream_handle;
	}

	/**
	 * Write a single row via the streaming handle.
	 *
	 * @since 0.1.0
	 * @param array $row Array of cell values.
	 * @return void
	 */
	public function write_single_row( array $row ): void {
		if ( ! $this->stream_handle ) {
			return;
		}

		$this->write_row( $this->stream_handle, $row );
	}

	/**
	 * Write multiple rows via the streaming handle.
	 *
	 * @since 0.1.0
	 * @param array $rows Array of rows, each row is an array of values.
	 * @return void
	 */
	public function write_rows( array $rows ): void {
		if ( ! $this->stream_handle ) {
			return;
		}

		foreach ( $rows as $row ) {
			$this->write_row( $this->stream_handle, $row );
		}
	}

	/**
	 * Close the streaming file handle.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function close(): void {
		if ( $this->stream_handle ) {
			fclose( $this->stream_handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			$this->stream_handle = null;
		}
	}

	/**
	 * Get the file path.
	 *
	 * @since 0.1.0
	 * @return string
	 */
	public function get_filepath(): string {
		return $this->filepath;
	}

	/**
	 * Generate a sanitized export filename.
	 *
	 * @since 0.1.0
	 * @param string $post_type Post type or taxonomy slug.
	 * @param string $format    File format: 'csv' or 'txt'.
	 * @return string Sanitized filename.
	 */
	public static function generate_filename( string $post_type, string $format = 'csv' ): string {
		$timestamp = gmdate( 'Y-m-d-His' );
		$extension = ( 'txt' === $format ) ? 'txt' : 'csv';

		return sanitize_file_name( "export-{$post_type}-{$timestamp}.{$extension}" );
	}
}
