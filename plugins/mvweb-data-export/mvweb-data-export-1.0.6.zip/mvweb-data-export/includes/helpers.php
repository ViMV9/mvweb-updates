<?php
/**
 * Helper functions for MVweb Data Export.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Recursively sanitize an array of values.
 *
 * @since 0.1.0
 * @param array $array Input array.
 * @return array Sanitized array.
 */
function mvweb_de_sanitize_array( array $array ): array {
	$sanitized = array();

	foreach ( $array as $key => $value ) {
		$key = sanitize_key( $key );

		if ( is_array( $value ) ) {
			$sanitized[ $key ] = mvweb_de_sanitize_array( $value );
		} elseif ( is_numeric( $value ) ) {
			$sanitized[ $key ] = intval( $value );
		} elseif ( is_bool( $value ) ) {
			$sanitized[ $key ] = $value;
		} else {
			$sanitized[ $key ] = sanitize_text_field( $value );
		}
	}

	return $sanitized;
}

/**
 * Get plugin settings with defaults.
 *
 * @since 0.1.0
 * @return array Plugin settings.
 */
function mvweb_de_get_settings(): array {
	$defaults = array(
		'encoding'    => 'utf8bom',
		'header_lang' => 'auto',
		'batch_size'  => 100,
		'max_records' => 10000,
		'max_history' => 10,
		'delete_data' => false,
	);

	$settings = get_option( 'mvweb_de_settings', array() );

	return wp_parse_args( $settings, $defaults );
}

/**
 * Get default price-list settings.
 *
 * @since 1.1.0
 * @return array Default price settings.
 */
function mvweb_de_get_price_defaults(): array {
	return array(
		// File header block (all optional).
		'logo_id'       => 0,
		'company'       => '',
		'description'   => '',
		'phone'         => '',
		'address'       => '',
		'messengers'    => '',

		// Column mapping. Each column:
		//   label     => string  Column header in the file.
		//   source    => string  One of: 'post' | 'meta' | 'wc' | 'taxonomy' | 'variation'.
		//   key       => string  post field / meta key / wc field key / taxonomy slug
		//                         (for 'variation' — the variation meta key, e.g. '_regular_price').
		//   attribute => string  Variation attribute taxonomy (e.g. 'pa_price'). Only for 'variation'.
		//   value     => string  Variation attribute value slug (e.g. 'opt-1'). Only for 'variation'.
		// Universal defaults that work on any standard WooCommerce store out of the box.
		'columns'       => array(
			array( 'label' => 'SKU', 'source' => 'wc', 'key' => 'wc_sku' ),
			array( 'label' => 'Name', 'source' => 'post', 'key' => 'post_title' ),
			array( 'label' => 'Category', 'source' => 'taxonomy', 'key' => 'product_cat' ),
			// 'wc_price' is the effective price: populated for every product type
			// (simple = regular/sale, variable = lowest variation price). 'wc_regular_price'
			// is empty on variable products, so it is a poor universal default.
			array( 'label' => 'Price', 'source' => 'wc', 'key' => 'wc_price' ),
		),

		// Scheduled regeneration via external server cron (secret token).
		'cron_token'    => '',

		// Output.
		'file_format'   => 'xlsx',

		// Runtime stats (updated after each regeneration).
		'last_regen'    => 0,
		'last_count'    => 0,
	);
}

/**
 * Get price-list settings merged with defaults.
 *
 * @since 1.1.0
 * @return array Price settings.
 */
function mvweb_de_get_price_settings(): array {
	$settings = get_option( 'mvweb_de_price_settings', array() );

	return wp_parse_args( $settings, mvweb_de_get_price_defaults() );
}

/**
 * Sanitize a price column-mapping array.
 *
 * @since 1.1.0
 * @param array $columns Raw columns from the settings form.
 * @return array Clean columns.
 */
function mvweb_de_sanitize_price_columns( array $columns ): array {
	$allowed_sources = array( 'post', 'meta', 'wc', 'taxonomy', 'variation' );
	$clean           = array();

	foreach ( $columns as $col ) {
		if ( ! is_array( $col ) ) {
			continue;
		}

		$label  = isset( $col['label'] ) ? sanitize_text_field( $col['label'] ) : '';
		$source = isset( $col['source'] ) ? sanitize_key( $col['source'] ) : '';

		if ( '' === $label || ! in_array( $source, $allowed_sources, true ) ) {
			continue;
		}

		// Meta/variation keys may contain a leading underscore — sanitize_key keeps it.
		$entry = array(
			'label'  => $label,
			'source' => $source,
			'key'    => isset( $col['key'] ) ? sanitize_text_field( $col['key'] ) : '',
		);

		if ( 'variation' === $source ) {
			$entry['attribute'] = isset( $col['attribute'] ) ? sanitize_key( $col['attribute'] ) : '';
			$entry['value']     = isset( $col['value'] ) ? sanitize_title( $col['value'] ) : '';
		}

		$clean[] = $entry;
	}

	return $clean;
}

/**
 * Build the public price regeneration URL with the secret token.
 *
 * @since 1.1.0
 * @param string $token Secret token.
 * @return string Empty string if no token.
 */
function mvweb_de_price_regen_url( string $token ): string {
	if ( '' === $token ) {
		return '';
	}

	return add_query_arg( 'mvweb_de_price_regen', rawurlencode( $token ), home_url( '/' ) );
}

/**
 * Build a ready-to-paste crontab line (every 6 hours).
 *
 * @since 1.1.0
 * @param string $token Secret token.
 * @return string Empty string if no token.
 */
function mvweb_de_price_cron_line( string $token ): string {
	$url = mvweb_de_price_regen_url( $token );
	if ( '' === $url ) {
		return '';
	}

	return '0 */6 * * * curl -s "' . $url . '" > /dev/null 2>&1';
}

/**
 * Friendly catalog of price-list column fields.
 *
 * Maps a human-readable choice (shown in a single dropdown) to the internal
 * storage pair (source, key). The storage model and the generator are unaffected
 * — this is purely a presentation layer so non-technical users don't deal with
 * raw keys like "wc_sku" or "post_title".
 *
 * @since 1.1.0
 * @return array[] Keyed by choice id: [ 'label', 'source', 'key', 'group' ].
 */
function mvweb_de_get_friendly_field_map(): array {
	return array(
		// Basics.
		'name'          => array( 'label' => __( 'Product name', 'mvweb-data-export' ),     'source' => 'post',     'key' => 'post_title',     'group' => 'basic' ),
		'sku'           => array( 'label' => __( 'SKU (article)', 'mvweb-data-export' ),     'source' => 'wc',       'key' => 'wc_sku',         'group' => 'basic' ),
		'category'      => array( 'label' => __( 'Category', 'mvweb-data-export' ),          'source' => 'taxonomy', 'key' => 'product_cat',    'group' => 'basic' ),
		'short_desc'    => array( 'label' => __( 'Short description', 'mvweb-data-export' ), 'source' => 'post',     'key' => 'post_excerpt',   'group' => 'basic' ),
		'product_url'   => array( 'label' => __( 'Product link', 'mvweb-data-export' ),      'source' => 'post',     'key' => 'post_url',       'group' => 'basic' ),
		'image'         => array( 'label' => __( 'Image (URL)', 'mvweb-data-export' ),       'source' => 'post',     'key' => 'thumbnail_url',  'group' => 'basic' ),
		// Prices & stock. 'Price' (the effective price) is listed first — it is the
		// universal, always-filled choice (regular for simple, sale when discounted,
		// lowest variation price for variable). The before/after-discount split follows.
		'current_price' => array( 'label' => __( 'Price', 'mvweb-data-export' ),                          'source' => 'wc', 'key' => 'wc_price',          'group' => 'price' ),
		'regular_price' => array( 'label' => __( 'Regular price (before discount)', 'mvweb-data-export' ), 'source' => 'wc', 'key' => 'wc_regular_price',  'group' => 'price' ),
		'sale_price'    => array( 'label' => __( 'Sale price', 'mvweb-data-export' ),                     'source' => 'wc', 'key' => 'wc_sale_price',     'group' => 'price' ),
		'stock_status'  => array( 'label' => __( 'Stock status', 'mvweb-data-export' ),                   'source' => 'wc', 'key' => 'wc_stock_status',   'group' => 'price' ),
		'stock_qty'     => array( 'label' => __( 'Stock quantity', 'mvweb-data-export' ),    'source' => 'wc',       'key' => 'wc_stock_quantity', 'group' => 'price' ),
		'weight'        => array( 'label' => __( 'Weight', 'mvweb-data-export' ),            'source' => 'wc',       'key' => 'wc_weight',        'group' => 'price' ),
	);
}

/**
 * Resolve a stored (source, key) pair back to a friendly choice id.
 *
 * Used when rendering already-saved columns into the friendly dropdown.
 * Falls back to the advanced gateways: 'variation' or 'meta'.
 *
 * @since 1.1.0
 * @param string $source Stored source.
 * @param string $key    Stored key.
 * @return string Choice id, or 'variation' / 'meta'.
 */
function mvweb_de_resolve_field_choice( string $source, string $key ): string {
	if ( 'variation' === $source ) {
		return 'variation';
	}

	foreach ( mvweb_de_get_friendly_field_map() as $choice => $def ) {
		if ( $def['source'] === $source && $def['key'] === $key ) {
			return $choice;
		}
	}

	// Anything unrecognized (incl. source 'meta') is handled by the custom-meta gateway.
	return 'meta';
}

/**
 * Get global product attributes and their terms for the variation-price picker.
 *
 * Lets users pick the attribute and value from real site data instead of typing
 * raw slugs (e.g. pa_price → opt-1). Returns empty if WooCommerce is unavailable.
 *
 * @since 1.1.0
 * @return array[] Keyed by taxonomy: [ 'label' => string, 'terms' => [ slug => name ] ].
 */
function mvweb_de_get_variation_attributes(): array {
	if ( ! function_exists( 'wc_get_attribute_taxonomies' ) ) {
		return array();
	}

	$result      = array();
	$taxonomies  = wc_get_attribute_taxonomies();

	foreach ( $taxonomies as $attribute ) {
		$taxonomy = 'pa_' . $attribute->attribute_name;
		$terms    = get_terms(
			array(
				'taxonomy'   => $taxonomy,
				'hide_empty' => false,
			)
		);

		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			continue;
		}

		$term_map = array();
		foreach ( $terms as $term ) {
			$term_map[ $term->slug ] = $term->name;
		}

		$result[ $taxonomy ] = array(
			'label' => $attribute->attribute_label ? $attribute->attribute_label : $attribute->attribute_name,
			'terms' => $term_map,
		);
	}

	return $result;
}
