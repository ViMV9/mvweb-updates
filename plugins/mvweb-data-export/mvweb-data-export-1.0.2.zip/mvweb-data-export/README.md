# MVweb Data Export

Export posts, pages, CPT and WooCommerce products to CSV/TXT.

## Requirements

- WordPress 6.6+
- PHP 8.0+
- WooCommerce 8.0+ (optional, for product-specific fields)

## Installation

1. Upload the `mvweb-data-export` folder to `/wp-content/plugins/`.
2. Activate the plugin via the **Plugins** screen.
3. Navigate to **MVweb > Data Export**.

## Features

- Export any public post type or taxonomy to CSV or TXT (TSV).
- Drag-and-drop field selection with custom ordering.
- WooCommerce support: product fields, attributes, variations (inline or separate rows).
- Filters: post status, taxonomy terms, date range, author, WC price/stock/product type.
- Batch processing with progress bar and memory monitoring.
- Preview first 10 rows before exporting.
- Export presets: save and restore export configurations.
- Export history with download links and FIFO rotation.
- UTF-8 BOM support for Excel compatibility.
- IDOR protection: editors see only their own data.

## Usage

1. Go to **MVweb > Data Export**.
2. Select export type (Posts/CPT or Taxonomies) and source.
3. Drag desired fields to the "Selected" list.
4. Optionally apply filters and set sort order.
5. Click **Preview** to check the first 10 rows.
6. Click **Export** to start batch processing.
7. The file downloads automatically when complete.

## Settings

- **Encoding**: UTF-8 with BOM (default) or UTF-8 without BOM.
- **Header language**: Auto, English, or Russian.
- **Batch size**: 10-500 records per batch (default: 100).
- **Max records**: 100-50,000 per export (default: 10,000).
- **Max history**: 1-50 files (default: 10).
- **Delete data on uninstall**: Remove all plugin data when deleted.

## License

GPL v2 or later.
