<?php
/**
 * History tab content.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="mvweb-de-history" id="mvweb-de-history">

	<p class="description">
		<?php esc_html_e( 'Previously exported files. Click on a filename to download.', 'mvweb-data-export' ); ?>
	</p>

	<div id="mvweb-de-history-loading" style="display: none;">
		<span class="spinner is-active"></span>
	</div>

	<div id="mvweb-de-history-empty" style="display: none;">
		<div class="mvweb-notice">
			<p><?php esc_html_e( 'No export history yet. Run an export from the Export tab.', 'mvweb-data-export' ); ?></p>
		</div>
	</div>

	<table class="mvweb-table mvweb-table--striped" id="mvweb-de-history-table" style="display: none;">
		<thead>
			<tr>
				<th><?php esc_html_e( 'File', 'mvweb-data-export' ); ?></th>
				<th><?php esc_html_e( 'Source', 'mvweb-data-export' ); ?></th>
				<th><?php esc_html_e( 'Format', 'mvweb-data-export' ); ?></th>
				<th><?php esc_html_e( 'Rows', 'mvweb-data-export' ); ?></th>
				<th><?php esc_html_e( 'Size', 'mvweb-data-export' ); ?></th>
				<?php if ( current_user_can( 'manage_options' ) ) : ?>
					<th><?php esc_html_e( 'Author', 'mvweb-data-export' ); ?></th>
				<?php endif; ?>
				<th><?php esc_html_e( 'Date', 'mvweb-data-export' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'mvweb-data-export' ); ?></th>
			</tr>
		</thead>
		<tbody id="mvweb-de-history-tbody">
			<!-- Populated via JS -->
		</tbody>
	</table>

</div>
