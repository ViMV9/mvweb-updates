<?php
/**
 * Presets tab content.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="mvweb-de-presets" id="mvweb-de-presets">

	<p class="description">
		<?php esc_html_e( 'Save and load export configurations for quick access.', 'mvweb-data-export' ); ?>
	</p>

	<div id="mvweb-de-presets-loading" style="display: none;">
		<span class="spinner is-active"></span>
	</div>

	<div id="mvweb-de-presets-empty" style="display: none;">
		<div class="mvweb-notice">
			<p><?php esc_html_e( 'No presets saved yet. Go to the Export tab and save your first preset.', 'mvweb-data-export' ); ?></p>
		</div>
	</div>

	<table class="mvweb-table mvweb-table--striped" id="mvweb-de-presets-table" style="display: none;">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Name', 'mvweb-data-export' ); ?></th>
				<th><?php esc_html_e( 'Type', 'mvweb-data-export' ); ?></th>
				<th><?php esc_html_e( 'Source', 'mvweb-data-export' ); ?></th>
				<th><?php esc_html_e( 'Format', 'mvweb-data-export' ); ?></th>
				<th><?php esc_html_e( 'Fields', 'mvweb-data-export' ); ?></th>
				<?php if ( current_user_can( 'manage_options' ) ) : ?>
					<th><?php esc_html_e( 'Author', 'mvweb-data-export' ); ?></th>
				<?php endif; ?>
				<th><?php esc_html_e( 'Created', 'mvweb-data-export' ); ?></th>
				<th><?php esc_html_e( 'Actions', 'mvweb-data-export' ); ?></th>
			</tr>
		</thead>
		<tbody id="mvweb-de-presets-tbody">
			<!-- Populated via JS -->
		</tbody>
	</table>

</div>
