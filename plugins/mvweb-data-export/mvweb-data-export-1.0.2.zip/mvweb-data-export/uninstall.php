<?php
/**
 * Uninstall handler for MVweb Data Export.
 *
 * Removes all plugin data when the plugin is deleted via WordPress admin.
 * Only runs if the "Delete data on uninstall" option is enabled.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

// Exit if not called by WordPress uninstall.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$settings = get_option( 'mvweb_de_settings', array() );

// Only delete data if the user opted in.
if ( empty( $settings['delete_data'] ) ) {
	return;
}

// ───────────────────────────────────────────────
// 1. Delete options
// ───────────────────────────────────────────────
delete_option( 'mvweb_de_settings' );
delete_option( 'mvweb_de_presets' );
delete_option( 'mvweb_de_history' );

// ───────────────────────────────────────────────
// 2. Delete transients
// ───────────────────────────────────────────────
global $wpdb;

$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->options}
		 WHERE option_name LIKE %s
		    OR option_name LIKE %s
		    OR option_name LIKE %s
		    OR option_name LIKE %s
		    OR option_name LIKE %s
		    OR option_name LIKE %s",
		$wpdb->esc_like( '_transient_mvweb_de_session_' ) . '%',
		$wpdb->esc_like( '_transient_timeout_mvweb_de_session_' ) . '%',
		$wpdb->esc_like( '_transient_mvweb_de_lock_' ) . '%',
		$wpdb->esc_like( '_transient_timeout_mvweb_de_lock_' ) . '%',
		$wpdb->esc_like( '_transient_mvweb_de_meta_keys_' ) . '%',
		$wpdb->esc_like( '_transient_timeout_mvweb_de_meta_keys_' ) . '%'
	)
);

// ───────────────────────────────────────────────
// 3. Clear cron events
// ───────────────────────────────────────────────
wp_clear_scheduled_hook( 'mvweb_de_cleanup_sessions' );

// ───────────────────────────────────────────────
// 4. Delete export directory (safe check)
// ───────────────────────────────────────────────
$upload_dir = wp_upload_dir();
$export_dir = trailingslashit( $upload_dir['basedir'] ) . 'mvweb-export/';

if ( is_dir( $export_dir ) ) {
	$allowed_ext    = array( 'csv', 'txt' );
	$safe_to_delete = true;
	$real_dir       = realpath( $export_dir );

	// Single glob — collect files, validate, then delete from the collected list.
	$files     = $real_dir ? glob( $real_dir . DIRECTORY_SEPARATOR . '*' ) : array();
	$to_delete = array();

	foreach ( $files as $file ) {
		$real_file = realpath( $file );

		// Path traversal protection: ensure file is inside export dir.
		if ( ! $real_file || ! $real_dir || ! str_starts_with( $real_file, $real_dir ) ) {
			$safe_to_delete = false;
			break;
		}

		$basename = basename( $real_file );

		// Skip protection files.
		if ( 'index.php' === $basename || '.htaccess' === $basename ) {
			$to_delete[] = $real_file;
			continue;
		}

		if ( is_file( $real_file ) ) {
			$ext = pathinfo( $real_file, PATHINFO_EXTENSION );
			if ( ! in_array( $ext, $allowed_ext, true ) ) {
				$safe_to_delete = false;
				break;
			}
			$to_delete[] = $real_file;
		}
	}

	if ( $safe_to_delete ) {
		foreach ( $to_delete as $file_path ) {
			if ( is_file( $file_path ) ) {
				unlink( $file_path );
			}
		}
		rmdir( $real_dir );
	}
}

// ───────────────────────────────────────────────
// 5. Flush object cache
// ───────────────────────────────────────────────
wp_cache_flush();
