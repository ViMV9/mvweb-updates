<?php
/**
 * File manager for MVweb Data Export.
 *
 * Handles export directory creation, protection, and Nginx detection.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_DE_File_Manager
 *
 * Manages the export directory and file protections.
 *
 * @since 0.1.0
 */
class MVweb_DE_File_Manager {

	/**
	 * Export directory name within uploads.
	 *
	 * @var string
	 */
	private const EXPORT_DIR = 'mvweb-export';

	/**
	 * Constructor.
	 *
	 * @since 0.1.0
	 */
	public function __construct() {
		add_action( 'admin_notices', array( $this, 'nginx_admin_notice' ) );
	}

	/**
	 * Get the export directory path.
	 *
	 * @since 0.1.0
	 * @return string Absolute path to export directory.
	 */
	public static function get_export_dir(): string {
		$upload_dir = wp_upload_dir();
		return trailingslashit( $upload_dir['basedir'] ) . self::EXPORT_DIR . '/';
	}

	/**
	 * Create export directory with protections.
	 *
	 * @since 0.1.0
	 * @return bool True on success.
	 */
	public static function ensure_export_dir(): bool {
		$export_dir = self::get_export_dir();

		if ( ! is_dir( $export_dir ) ) {
			wp_mkdir_p( $export_dir );
		}

		// Create .htaccess for Apache protection.
		$htaccess_path = $export_dir . '.htaccess';
		if ( ! file_exists( $htaccess_path ) ) {
			$htaccess_content = '<Files "*">' . PHP_EOL
				. '    Order Allow,Deny' . PHP_EOL
				. '    Deny from all' . PHP_EOL
				. '</Files>' . PHP_EOL;

			file_put_contents( $htaccess_path, $htaccess_content ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		// Create index.php for directory listing protection.
		$index_path = $export_dir . 'index.php';
		if ( ! file_exists( $index_path ) ) {
			file_put_contents( $index_path, '<?php' . PHP_EOL . '// Silence is golden.' . PHP_EOL ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		return is_dir( $export_dir );
	}

	/**
	 * Check if the server is running Nginx.
	 *
	 * @since 0.1.0
	 * @return bool True if Nginx is detected.
	 */
	public static function is_nginx(): bool {
		$server_software = isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : '';
		return ( false !== stripos( $server_software, 'nginx' ) );
	}

	/**
	 * Check if export directory has .htaccess protection.
	 *
	 * @since 0.1.0
	 * @return bool True if .htaccess exists.
	 */
	public static function has_htaccess_protection(): bool {
		return file_exists( self::get_export_dir() . '.htaccess' );
	}

	/**
	 * Display admin notice for Nginx servers.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function nginx_admin_notice(): void {
		if ( ! self::is_nginx() ) {
			return;
		}

		$screen = get_current_screen();
		if ( ! $screen || 'mvweb_page_mvweb-data-export' !== $screen->id ) {
			return;
		}

		$upload_dir = wp_upload_dir();
		$rel_path   = str_replace( ABSPATH, '/', $upload_dir['basedir'] . '/' . self::EXPORT_DIR . '/' );

		printf(
			'<div class="notice notice-warning"><p><strong>%s</strong></p><p>%s</p><pre>location ~* ^%s {\n    deny all;\n    return 403;\n}</pre></div>',
			esc_html__( 'Nginx detected — manual configuration required', 'mvweb-data-export' ),
			esc_html__( 'Please add the following rule to your Nginx configuration to protect export files from direct access:', 'mvweb-data-export' ),
			esc_html( $rel_path )
		);
	}

	/**
	 * Get system information for the Settings tab.
	 *
	 * @since 0.1.0
	 * @return array System info key-value pairs.
	 */
	public static function get_system_info(): array {
		$export_dir = self::get_export_dir();
		$info       = array();

		$info['php_memory_limit']    = ini_get( 'memory_limit' );
		$info['max_execution_time']  = ini_get( 'max_execution_time' );
		$info['upload_max_filesize'] = ini_get( 'upload_max_filesize' );

		// Disk free space.
		$free_space = function_exists( 'disk_free_space' ) ? @disk_free_space( $export_dir ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		if ( false !== $free_space ) {
			$info['disk_free_space'] = size_format( $free_space );
		} else {
			$info['disk_free_space'] = __( 'Unable to determine', 'mvweb-data-export' );
		}

		$info['export_dir']       = $export_dir;
		$info['dir_exists']       = is_dir( $export_dir );
		$info['htaccess_exists']  = self::has_htaccess_protection();
		$info['is_nginx']         = self::is_nginx();

		// WooCommerce status.
		if ( class_exists( 'WooCommerce' ) ) {
			$info['woocommerce'] = defined( 'WC_VERSION' ) ? WC_VERSION : __( 'Active', 'mvweb-data-export' );
		} else {
			$info['woocommerce'] = __( 'Not installed', 'mvweb-data-export' );
		}

		return $info;
	}
}
