<?php
/**
 * Preset Manager for MVweb Data Export.
 *
 * CRUD operations for export presets. Stores in wp_options (autoload: false).
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_DE_Preset_Manager
 *
 * Manages export presets per user. Admins can see all presets.
 *
 * @since 0.1.0
 */
class MVweb_DE_Preset_Manager {

	/**
	 * Option key for storing presets.
	 *
	 * @var string
	 */
	private const OPTION_KEY = 'mvweb_de_presets';

	/**
	 * Maximum presets per user.
	 *
	 * @var int
	 */
	private const MAX_PER_USER = 20;

	/**
	 * Get all presets visible to the current user.
	 *
	 * Admins see all; editors see only their own.
	 *
	 * @since 0.1.0
	 * @return array Presets array.
	 */
	public function get_presets(): array {
		$all     = $this->get_all_presets();
		$user_id = get_current_user_id();

		if ( current_user_can( 'manage_options' ) ) {
			return $all;
		}

		return array_values(
			array_filter(
				$all,
				function ( $preset ) use ( $user_id ) {
					return (int) $preset['user_id'] === $user_id;
				}
			)
		);
	}

	/**
	 * Save a new preset.
	 *
	 * @since 0.1.0
	 * @param string $name   Preset name.
	 * @param array  $config Export configuration to save.
	 * @return array|WP_Error Saved preset or error.
	 */
	public function save_preset( string $name, array $config ) {
		$user_id = get_current_user_id();
		$all     = $this->get_all_presets();

		// Count presets for this user.
		$user_count = 0;
		foreach ( $all as $p ) {
			if ( (int) $p['user_id'] === $user_id ) {
				++$user_count;
			}
		}

		if ( $user_count >= self::MAX_PER_USER ) {
			return new WP_Error(
				'preset_limit',
				/* translators: %d: maximum number of presets */
				sprintf( __( 'Maximum %d presets per user.', 'mvweb-data-export' ), self::MAX_PER_USER )
			);
		}

		$preset = array(
			'id'             => wp_generate_uuid4(),
			'name'           => sanitize_text_field( $name ),
			'user_id'        => $user_id,
			'export_type'    => sanitize_key( $config['export_type'] ?? 'posts' ),
			'source'         => sanitize_key( $config['source'] ?? '' ),
			'fields'         => array_map( 'sanitize_key', $config['fields'] ?? array() ),
			'format'         => sanitize_key( $config['format'] ?? 'csv' ),
			'url_format'     => sanitize_key( $config['url_format'] ?? 'full' ),
			'sort_by'        => sanitize_key( $config['sort_by'] ?? 'post_date' ),
			'sort_order'     => sanitize_key( $config['sort_order'] ?? 'DESC' ),
			'variation_mode' => sanitize_key( $config['variation_mode'] ?? 'inline' ),
			'filters'        => $this->sanitize_filters( $config['filters'] ?? array() ),
			'created_at'     => wp_date( 'Y-m-d H:i:s' ),
		);

		$all[] = $preset;

		update_option( self::OPTION_KEY, $all, false );

		return $preset;
	}

	/**
	 * Delete a preset by ID.
	 *
	 * @since 0.1.0
	 * @param string $preset_id Preset ID.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	public function delete_preset( string $preset_id ) {
		$all     = $this->get_all_presets();
		$user_id = get_current_user_id();
		$found   = false;

		foreach ( $all as $index => $preset ) {
			if ( $preset['id'] === $preset_id ) {
				// IDOR: editors can only delete their own.
				if ( ! current_user_can( 'manage_options' ) && (int) $preset['user_id'] !== $user_id ) {
					return new WP_Error(
						'forbidden',
						__( 'You do not have permission to delete this preset.', 'mvweb-data-export' )
					);
				}

				unset( $all[ $index ] );
				$found = true;
				break;
			}
		}

		if ( ! $found ) {
			return new WP_Error(
				'not_found',
				__( 'Preset not found.', 'mvweb-data-export' )
			);
		}

		update_option( self::OPTION_KEY, array_values( $all ), false );

		return true;
	}

	/**
	 * Get a single preset by ID (with permission check).
	 *
	 * @since 0.1.0
	 * @param string $preset_id Preset ID.
	 * @return array|null Preset data or null.
	 */
	public function get_preset( string $preset_id ): ?array {
		$all     = $this->get_all_presets();
		$user_id = get_current_user_id();

		foreach ( $all as $preset ) {
			if ( $preset['id'] === $preset_id ) {
				// IDOR check.
				if ( ! current_user_can( 'manage_options' ) && (int) $preset['user_id'] !== $user_id ) {
					return null;
				}
				return $preset;
			}
		}

		return null;
	}

	/**
	 * Get all stored presets (raw, no permission filtering).
	 *
	 * @since 0.1.0
	 * @return array All presets.
	 */
	private function get_all_presets(): array {
		$presets = get_option( self::OPTION_KEY, array() );

		return is_array( $presets ) ? $presets : array();
	}

	/**
	 * Sanitize filter values for storage.
	 *
	 * @since 0.1.0
	 * @param array $filters Raw filter data.
	 * @return array Sanitized filters.
	 */
	private function sanitize_filters( array $filters ): array {
		$clean = array();

		if ( ! empty( $filters['filter_status'] ) && is_array( $filters['filter_status'] ) ) {
			$clean['filter_status'] = array_map( 'sanitize_key', $filters['filter_status'] );
		}

		if ( ! empty( $filters['filter_taxonomy'] ) ) {
			$clean['filter_taxonomy'] = sanitize_key( $filters['filter_taxonomy'] );
		}

		if ( ! empty( $filters['filter_terms'] ) && is_array( $filters['filter_terms'] ) ) {
			$clean['filter_terms'] = array_map( 'absint', $filters['filter_terms'] );
		}

		if ( ! empty( $filters['filter_date_from'] ) ) {
			$clean['filter_date_from'] = sanitize_text_field( $filters['filter_date_from'] );
		}

		if ( ! empty( $filters['filter_date_to'] ) ) {
			$clean['filter_date_to'] = sanitize_text_field( $filters['filter_date_to'] );
		}

		if ( ! empty( $filters['filter_author'] ) ) {
			$clean['filter_author'] = absint( $filters['filter_author'] );
		}

		// WooCommerce-specific filters.
		if ( isset( $filters['filter_price_min'] ) && '' !== $filters['filter_price_min'] ) {
			$clean['filter_price_min'] = max( 0, floatval( $filters['filter_price_min'] ) );
		}

		if ( isset( $filters['filter_price_max'] ) && '' !== $filters['filter_price_max'] ) {
			$clean['filter_price_max'] = max( 0, floatval( $filters['filter_price_max'] ) );
		}

		if ( ! empty( $filters['filter_stock_status'] ) && is_array( $filters['filter_stock_status'] ) ) {
			$valid_stock = array( 'instock', 'outofstock', 'onbackorder' );
			$stock       = array_map( 'sanitize_key', $filters['filter_stock_status'] );
			$clean['filter_stock_status'] = array_values( array_intersect( $stock, $valid_stock ) );
		}

		if ( ! empty( $filters['filter_product_type'] ) && is_array( $filters['filter_product_type'] ) ) {
			$valid_types = array( 'simple', 'variable', 'grouped', 'external' );
			$types       = array_map( 'sanitize_key', $filters['filter_product_type'] );
			$clean['filter_product_type'] = array_values( array_intersect( $types, $valid_types ) );
		}

		return $clean;
	}
}
