<?php
/**
 * Helper functions for MVweb Data Export.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Recursively sanitize an array of values.
 *
 * @since 0.1.0
 * @param array $array Input array.
 * @return array Sanitized array.
 */
function mvweb_de_sanitize_array( array $array ): array {
	$sanitized = array();

	foreach ( $array as $key => $value ) {
		$key = sanitize_key( $key );

		if ( is_array( $value ) ) {
			$sanitized[ $key ] = mvweb_de_sanitize_array( $value );
		} elseif ( is_numeric( $value ) ) {
			$sanitized[ $key ] = intval( $value );
		} elseif ( is_bool( $value ) ) {
			$sanitized[ $key ] = $value;
		} else {
			$sanitized[ $key ] = sanitize_text_field( $value );
		}
	}

	return $sanitized;
}

/**
 * Get plugin settings with defaults.
 *
 * @since 0.1.0
 * @return array Plugin settings.
 */
function mvweb_de_get_settings(): array {
	$defaults = array(
		'encoding'    => 'utf8bom',
		'header_lang' => 'auto',
		'batch_size'  => 100,
		'max_records' => 10000,
		'max_history' => 10,
		'delete_data' => false,
	);

	$settings = get_option( 'mvweb_de_settings', array() );

	return wp_parse_args( $settings, $defaults );
}
