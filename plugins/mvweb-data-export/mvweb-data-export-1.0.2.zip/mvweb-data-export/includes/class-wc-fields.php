<?php
/**
 * WooCommerce fields for MVweb Data Export.
 *
 * Conditional class — loaded only when WooCommerce is active and v8.0+.
 * Registers WC-specific fields, extracts product data, handles variations.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_DE_WC_Fields
 *
 * @since 0.1.0
 */
class MVweb_DE_WC_Fields {

	/**
	 * Minimum required WooCommerce version.
	 *
	 * @var string
	 */
	private const MIN_WC_VERSION = '8.0';

	/**
	 * Check if WooCommerce is available and meets minimum version.
	 *
	 * @since 0.1.0
	 * @return bool
	 */
	public static function is_available(): bool {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return false;
		}

		if ( ! defined( 'WC_VERSION' ) ) {
			return false;
		}

		return version_compare( WC_VERSION, self::MIN_WC_VERSION, '>=' );
	}

	/**
	 * Initialize WC fields integration.
	 *
	 * Hooks into the field registry filter to add WC fields for product post type.
	 *
	 * @since 0.1.0
	 * @return void
	 */
	public function init(): void {
		add_filter( 'mvweb_de_fields', array( $this, 'add_wc_fields' ), 10, 2 );
	}

	/**
	 * Add WooCommerce fields to the field registry for 'product' post type.
	 *
	 * @since 0.1.0
	 * @param array  $groups    Grouped fields.
	 * @param string $post_type Post type or taxonomy slug.
	 * @return array Modified groups.
	 */
	public function add_wc_fields( array $groups, string $post_type ): array {
		if ( 'product' !== $post_type ) {
			return $groups;
		}

		$groups['woocommerce'] = array(
			'label'  => __( 'WooCommerce', 'mvweb-data-export' ),
			'fields' => $this->get_wc_fields(),
		);

		// Add dynamic attributes as separate fields.
		$attr_fields = $this->get_attribute_fields();
		if ( ! empty( $attr_fields ) ) {
			$groups['wc_attributes'] = array(
				'label'  => __( 'Product Attributes', 'mvweb-data-export' ),
				'fields' => $attr_fields,
			);
		}

		return $groups;
	}

	/**
	 * Get static WooCommerce product fields.
	 *
	 * @since 0.1.0
	 * @return array Array of [ 'key' => string, 'label' => string ].
	 */
	private function get_wc_fields(): array {
		return array(
			array(
				'key'   => 'wc_sku',
				'label' => __( 'SKU', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_regular_price',
				'label' => __( 'Regular Price', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_sale_price',
				'label' => __( 'Sale Price', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_price',
				'label' => __( 'Current Price', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_stock_status',
				'label' => _x( 'Stock Status', 'stock status', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_stock_quantity',
				'label' => __( 'Stock Quantity', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_product_type',
				'label' => __( 'Product Type', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_weight',
				'label' => __( 'Weight', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_length',
				'label' => __( 'Length', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_width',
				'label' => __( 'Width', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_height',
				'label' => __( 'Height', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_attributes',
				'label' => __( 'Attributes', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_categories',
				'label' => __( 'Product Categories', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_tags',
				'label' => __( 'Product Tags', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_image_url',
				'label' => __( 'Main Image URL', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_short_description',
				'label' => __( 'Short Description', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_visibility',
				'label' => __( 'Visibility', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_upsell_ids',
				'label' => __( 'Upsell IDs', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_crosssell_ids',
				'label' => __( 'Cross-sell IDs', 'mvweb-data-export' ),
			),
			array(
				'key'   => 'wc_variations',
				'label' => __( 'Variations', 'mvweb-data-export' ),
			),
		);
	}

	/**
	 * Get dynamic product attribute fields (global pa_* attributes).
	 *
	 * @since 0.1.0
	 * @return array Array of [ 'key' => string, 'label' => string ].
	 */
	private function get_attribute_fields(): array {
		$fields         = array();
		$attribute_taxonomies = wc_get_attribute_taxonomies();

		if ( empty( $attribute_taxonomies ) ) {
			return $fields;
		}

		foreach ( $attribute_taxonomies as $attribute ) {
			$fields[] = array(
				'key'   => 'wc_attr_' . $attribute->attribute_name,
				'label' => $attribute->attribute_label ?: $attribute->attribute_name,
			);
		}

		return $fields;
	}

	/**
	 * Extract a WooCommerce field value for a product.
	 *
	 * Simple fields (price, SKU, stock) use get_post_meta() after preload.
	 * Complex fields (attributes, variations) use wc_get_product().
	 *
	 * @since 0.1.0
	 * @param int    $post_id   Post ID.
	 * @param string $field_key Field key.
	 * @return string Field value.
	 */
	public function get_field_value( int $post_id, string $field_key ): string {
		// Simple meta-based fields (fast — uses preloaded cache).
		switch ( $field_key ) {
			case 'wc_sku':
				return (string) get_post_meta( $post_id, '_sku', true );

			case 'wc_regular_price':
				return (string) get_post_meta( $post_id, '_regular_price', true );

			case 'wc_sale_price':
				return (string) get_post_meta( $post_id, '_sale_price', true );

			case 'wc_price':
				return (string) get_post_meta( $post_id, '_price', true );

			case 'wc_stock_status':
				return (string) get_post_meta( $post_id, '_stock_status', true );

			case 'wc_stock_quantity':
				$qty = get_post_meta( $post_id, '_stock', true );
				return ( '' !== $qty && null !== $qty ) ? (string) $qty : '';

			case 'wc_weight':
				return (string) get_post_meta( $post_id, '_weight', true );

			case 'wc_length':
				return (string) get_post_meta( $post_id, '_length', true );

			case 'wc_width':
				return (string) get_post_meta( $post_id, '_width', true );

			case 'wc_height':
				return (string) get_post_meta( $post_id, '_height', true );

			case 'wc_short_description':
				$post = get_post( $post_id );
				return $post ? strip_tags( $post->post_excerpt ) : '';
		}

		// Complex fields requiring WC product object.
		return $this->get_complex_field_value( $post_id, $field_key );
	}

	/**
	 * Extract complex WC field values requiring product object.
	 *
	 * @since 0.1.0
	 * @param int    $post_id   Post ID.
	 * @param string $field_key Field key.
	 * @return string Field value.
	 */
	private function get_complex_field_value( int $post_id, string $field_key ): string {
		$product = wc_get_product( $post_id );
		if ( ! $product ) {
			return '';
		}

		switch ( $field_key ) {
			case 'wc_product_type':
				return $product->get_type();

			case 'wc_variations':
				if ( $product->is_type( 'variable' ) ) {
					$variation_ids = $product->get_children();
					if ( ! empty( $variation_ids ) ) {
						update_postmeta_cache( $variation_ids );
						return $this->format_variations_inline( $variation_ids );
					}
				}
				return '';

			case 'wc_attributes':
				return $this->format_all_attributes( $product );

			case 'wc_categories':
				$terms = get_the_terms( $post_id, 'product_cat' );
				if ( $terms && ! is_wp_error( $terms ) ) {
					return implode( ' | ', wp_list_pluck( $terms, 'name' ) );
				}
				return '';

			case 'wc_tags':
				$terms = get_the_terms( $post_id, 'product_tag' );
				if ( $terms && ! is_wp_error( $terms ) ) {
					return implode( ' | ', wp_list_pluck( $terms, 'name' ) );
				}
				return '';

			case 'wc_image_url':
				$image_id = $product->get_image_id();
				if ( $image_id ) {
					$url = wp_get_attachment_url( $image_id );
					return $url ?: '';
				}
				return '';

			case 'wc_visibility':
				return $product->get_catalog_visibility();

			case 'wc_upsell_ids':
				$ids = $product->get_upsell_ids();
				return ! empty( $ids ) ? implode( ' | ', $ids ) : '';

			case 'wc_crosssell_ids':
				$ids = $product->get_cross_sell_ids();
				return ! empty( $ids ) ? implode( ' | ', $ids ) : '';

			default:
				// Dynamic attribute: wc_attr_{slug}.
				if ( str_starts_with( $field_key, 'wc_attr_' ) ) {
					$attr_slug = substr( $field_key, 8 );
					return $this->get_product_attribute_value( $product, $attr_slug );
				}

				return '';
		}
	}

	/**
	 * Format all product attributes as a single string.
	 *
	 * @since 0.1.0
	 * @param WC_Product $product Product object.
	 * @return string Formatted attributes.
	 */
	private function format_all_attributes( $product ): string {
		$attributes = $product->get_attributes();
		if ( empty( $attributes ) ) {
			return '';
		}

		$parts = array();

		foreach ( $attributes as $attribute ) {
			if ( $attribute instanceof \WC_Product_Attribute ) {
				$name = $attribute->get_name();
				if ( $attribute->is_taxonomy() ) {
					$tax    = $attribute->get_taxonomy_object();
					$label  = $tax ? $tax->attribute_label : $name;
					$terms  = wc_get_product_terms( $product->get_id(), $name, array( 'fields' => 'names' ) );
					$values = implode( ', ', $terms );
				} else {
					$label  = $name;
					$values = implode( ', ', $attribute->get_options() );
				}
				if ( $values ) {
					$parts[] = $label . ': ' . $values;
				}
			}
		}

		return implode( ' | ', $parts );
	}

	/**
	 * Get a single product attribute value by slug.
	 *
	 * @since 0.1.0
	 * @param WC_Product $product   Product object.
	 * @param string     $attr_slug Attribute slug (without pa_ prefix).
	 * @return string Attribute value(s) separated by ' | '.
	 */
	private function get_product_attribute_value( $product, string $attr_slug ): string {
		$taxonomy = 'pa_' . $attr_slug;

		// Try global taxonomy attribute first.
		$terms = wc_get_product_terms( $product->get_id(), $taxonomy, array( 'fields' => 'names' ) );
		if ( ! empty( $terms ) && ! is_wp_error( $terms ) ) {
			return implode( ' | ', $terms );
		}

		// Try local (custom) attribute.
		$attributes = $product->get_attributes();
		foreach ( $attributes as $attribute ) {
			if ( $attribute instanceof \WC_Product_Attribute && ! $attribute->is_taxonomy() ) {
				if ( sanitize_title( $attribute->get_name() ) === $attr_slug ) {
					return implode( ' | ', $attribute->get_options() );
				}
			}
		}

		return '';
	}

	/**
	 * Get variations data for a variable product.
	 *
	 * @since 0.1.0
	 * @param int    $product_id    Parent product ID.
	 * @param string $mode          'separate' for separate rows, 'inline' for single cell.
	 * @param array  $fields        Field keys to extract.
	 * @param string $url_format    'full' or 'relative'.
	 * @return array In 'separate' mode: array of variation rows. In 'inline' mode: single string.
	 */
	public function get_variations_data( int $product_id, string $mode, array $fields, string $url_format ): array|string {
		$product = wc_get_product( $product_id );
		if ( ! $product || ! $product->is_type( 'variable' ) ) {
			return ( 'inline' === $mode ) ? '' : array();
		}

		$variation_ids = $product->get_children();
		if ( empty( $variation_ids ) ) {
			return ( 'inline' === $mode ) ? '' : array();
		}

		// Preload variation postmeta to avoid N+1 queries.
		update_postmeta_cache( $variation_ids );

		if ( 'inline' === $mode ) {
			return $this->format_variations_inline( $variation_ids );
		}

		return $this->format_variations_separate( $product, $variation_ids, $fields, $url_format );
	}

	/**
	 * Format variations as inline string.
	 *
	 * @since 0.1.0
	 * @param array $variation_ids Variation IDs.
	 * @return string Formatted variations.
	 */
	private function format_variations_inline( array $variation_ids ): string {
		$parts = array();

		foreach ( $variation_ids as $var_id ) {
			$variation = wc_get_product( $var_id );
			if ( ! $variation ) {
				continue;
			}

			$attrs = $variation->get_attributes();
			$attr_parts = array();
			foreach ( $attrs as $attr_name => $attr_value ) {
				$label = wc_attribute_label( $attr_name );
				$value = $attr_value ?: __( 'Any', 'mvweb-data-export' );
				$attr_parts[] = $label . '=' . $value;
			}

			$sku   = $variation->get_sku();
			$price = $variation->get_price();

			$line = 'Variation: ' . implode( ', ', $attr_parts );
			if ( $sku ) {
				$line .= ' (SKU: ' . $sku;
				if ( '' !== $price ) {
					$line .= ', Price: ' . $price;
				}
				$line .= ')';
			} elseif ( '' !== $price ) {
				$line .= ' (Price: ' . $price . ')';
			}

			$parts[] = $line;
		}

		return implode( ' | ', $parts );
	}

	/**
	 * Format variations as separate rows (each variation = separate row).
	 *
	 * Each row duplicates parent data + variation-specific overrides.
	 *
	 * @since 0.1.0
	 * @param WC_Product $parent        Parent product.
	 * @param array      $variation_ids Variation IDs.
	 * @param array      $fields        Field keys.
	 * @param string     $url_format    URL format.
	 * @return array Array of variation rows.
	 */
	private function format_variations_separate( $parent, array $variation_ids, array $fields, string $url_format ): array {
		$rows = array();

		foreach ( $variation_ids as $var_id ) {
			$variation = wc_get_product( $var_id );
			if ( ! $variation ) {
				continue;
			}

			$row = array();
			foreach ( $fields as $field_key ) {
				$row[] = $this->get_variation_field_value( $parent, $variation, $field_key, $url_format );
			}

			$rows[] = $row;
		}

		return $rows;
	}

	/**
	 * Get a field value for a variation, falling back to parent data.
	 *
	 * @since 0.1.0
	 * @param WC_Product           $parent    Parent product.
	 * @param WC_Product_Variation $variation Variation product.
	 * @param string               $field_key Field key.
	 * @param string               $url_format URL format.
	 * @return string Field value.
	 */
	private function get_variation_field_value( $parent, $variation, string $field_key, string $url_format ): string {
		$var_id    = $variation->get_id();
		$parent_id = $parent->get_id();

		switch ( $field_key ) {
			case 'post_id':
				return (string) $var_id;

			case 'post_parent':
				return (string) $parent_id;

			case 'wc_sku':
				return $variation->get_sku() ?: $parent->get_sku();

			case 'wc_regular_price':
				return (string) $variation->get_regular_price();

			case 'wc_sale_price':
				return (string) $variation->get_sale_price();

			case 'wc_price':
				return (string) $variation->get_price();

			case 'wc_stock_status':
				return $variation->get_stock_status();

			case 'wc_stock_quantity':
				$qty = $variation->get_stock_quantity();
				return ( null !== $qty ) ? (string) $qty : '';

			case 'wc_weight':
				return (string) $variation->get_weight();

			case 'wc_length':
				return (string) $variation->get_length();

			case 'wc_width':
				return (string) $variation->get_width();

			case 'wc_height':
				return (string) $variation->get_height();

			case 'wc_image_url':
				$image_id = $variation->get_image_id();
				if ( $image_id ) {
					$url = wp_get_attachment_url( $image_id );
					return $url ?: '';
				}
				// Fall back to parent image.
				$image_id = $parent->get_image_id();
				if ( $image_id ) {
					$url = wp_get_attachment_url( $image_id );
					return $url ?: '';
				}
				return '';

			case 'wc_short_description':
				return strip_tags( $variation->get_description() );

			case 'post_url':
				$url = $variation->get_permalink();
				if ( 'relative' === $url_format && $url ) {
					$url = wp_make_link_relative( $url );
				}
				return $url ?: '';

			default:
				// For variation attributes: wc_attr_{slug}.
				if ( str_starts_with( $field_key, 'wc_attr_' ) ) {
					$attr_slug = substr( $field_key, 8 );
					$taxonomy  = 'pa_' . $attr_slug;
					$value     = $variation->get_attribute( $taxonomy );
					if ( $value ) {
						return $value;
					}
					// Fall back to parent attribute.
					return $this->get_product_attribute_value( $parent, $attr_slug );
				}

				// Delegate other fields to parent's post data.
				return '';
		}
	}

	/**
	 * Get the adaptive batch size for WooCommerce products.
	 *
	 * @since 0.1.0
	 * @param int  $default_batch_size Default batch size from settings.
	 * @param bool $has_variations     Whether variation mode is 'separate'.
	 * @return int Adjusted batch size.
	 */
	public static function get_adaptive_batch_size( int $default_batch_size, bool $has_variations = false ): int {
		if ( $has_variations ) {
			return min( $default_batch_size, 50 );
		}

		return min( $default_batch_size, 100 );
	}
}
