<?php
/**
 * Main admin page wrapper with sidebar tab navigation.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tabs = array(
	'export'   => array(
		'label' => _x( 'Export', 'tab title', 'mvweb-data-export' ),
		'icon'  => 'download',
	),
	'presets'  => array(
		'label' => __( 'Presets', 'mvweb-data-export' ),
		'icon'  => 'bookmark',
	),
	'history'  => array(
		'label' => __( 'History', 'mvweb-data-export' ),
		'icon'  => 'clock',
	),
	'price'    => array(
		'label' => __( 'Price List', 'mvweb-data-export' ),
		'icon'  => 'tag',
	),
	'settings' => array(
		'label' => __( 'Settings', 'mvweb-data-export' ),
		'icon'  => 'gear',
	),
	'help'     => array(
		'label' => __( 'Help', 'mvweb-data-export' ),
		'icon'  => 'help',
	),
);

// Settings tab only for admins.
if ( ! current_user_can( 'manage_options' ) ) {
	unset( $tabs['settings'] );
}

// Price List tab: admins only, and only when the price module is loaded
// (which requires WooCommerce at the version supported by MVweb_DE_WC_Fields).
// Gating on the actual loaded class avoids a fatal if the tab renders while
// the module's classes were not required.
if ( ! current_user_can( 'manage_options' ) || ! class_exists( 'MVweb_DE_Price_File_Manager' ) ) {
	unset( $tabs['price'] );
}

$icons = array(
	'download' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>',
	'bookmark' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/></svg>',
	'clock'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>',
	'gear'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
	'help'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
	'tag'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>',
);

$first_tab = array_key_first( $tabs );
?>
<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">DE</div>
			<div>
				<div class="mvweb-sidebar__brand-name">MVweb Data Export</div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_DE_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $tabs as $tab_id => $tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $tab_id ); ?>"
						class="mvweb-nav__link <?php echo esc_attr( $tab_id === $first_tab ? 'mvweb-nav__link--active' : '' ); ?>"
						data-tab="<?php echo esc_attr( $tab_id ); ?>">
						<?php echo $icons[ $tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $tab['label'] ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<div class="mvweb-de-notices" id="mvweb-de-notices"></div>

		<?php
		foreach ( $tabs as $tab_id => $tab ) :
			$tab_file = MVWEB_DE_PATH . 'admin/views/tab-' . $tab_id . '.php';
			if ( ! file_exists( $tab_file ) ) {
				continue;
			}
			?>
			<div id="<?php echo esc_attr( $tab_id ); ?>" class="mvweb-tab-content <?php echo esc_attr( $tab_id === $first_tab ? 'active' : '' ); ?>">
				<?php require $tab_file; ?>
			</div>
		<?php endforeach; ?>
	</main>
</div>
