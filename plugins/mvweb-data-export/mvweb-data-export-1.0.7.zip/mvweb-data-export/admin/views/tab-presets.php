<?php
/**
 * Presets tab content.
 *
 * @package MVweb_Data_Export
 * @since   0.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="mvweb-block mvweb-de-presets" id="mvweb-de-presets">

	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Presets', 'mvweb-data-export' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Save and load export configurations for quick access.', 'mvweb-data-export' ); ?>
	</p>

	<div id="mvweb-de-presets-loading" class="mvweb-hidden">
		<span class="mvweb-spinner"></span>
	</div>

	<div id="mvweb-de-presets-empty" class="mvweb-hidden">
		<div class="mvweb-alert mvweb-alert--info">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
			<div class="mvweb-alert__body">
				<?php esc_html_e( 'No presets saved yet. Go to the Export tab and save your first preset.', 'mvweb-data-export' ); ?>
			</div>
		</div>
	</div>

	<div class="mvweb-table-wrap mvweb-de-presets__table mvweb-hidden" id="mvweb-de-presets-table-wrap">
		<table class="mvweb-table" id="mvweb-de-presets-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Name', 'mvweb-data-export' ); ?></th>
					<th><?php esc_html_e( 'Type', 'mvweb-data-export' ); ?></th>
					<th><?php esc_html_e( 'Source', 'mvweb-data-export' ); ?></th>
					<th><?php esc_html_e( 'Format', 'mvweb-data-export' ); ?></th>
					<th><?php esc_html_e( 'Fields', 'mvweb-data-export' ); ?></th>
					<?php if ( current_user_can( 'manage_options' ) ) : ?>
						<th><?php esc_html_e( 'Author', 'mvweb-data-export' ); ?></th>
					<?php endif; ?>
					<th><?php esc_html_e( 'Created', 'mvweb-data-export' ); ?></th>
					<th><?php esc_html_e( 'Actions', 'mvweb-data-export' ); ?></th>
				</tr>
			</thead>
			<tbody id="mvweb-de-presets-tbody">
				<!-- Populated via JS -->
			</tbody>
		</table>
	</div>

</div>
