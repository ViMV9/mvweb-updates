<?php
/**
 * Price List tab content.
 *
 * Lets the admin configure the client-facing price file: company header,
 * column mapping (incl. variation prices), the public download link and the
 * external server-cron instructions.
 *
 * @package MVweb_Data_Export
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$price       = mvweb_de_get_price_settings();
$ext         = 'xlsx';
$file_exists = MVweb_DE_Price_File_Manager::file_exists( $ext );
$file_url    = $file_exists ? MVweb_DE_Price_File_Manager::get_price_file_url( $ext ) : '';
$file_size   = $file_exists ? size_format( (int) MVweb_DE_Price_File_Manager::get_file_size( $ext ) ) : '';
$file_time   = $file_exists ? wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) MVweb_DE_Price_File_Manager::get_last_modified( $ext ) ) : '';
$regen_url    = mvweb_de_price_regen_url( (string) $price['cron_token'] );
$cron_command = mvweb_de_price_cron_command( (string) $price['cron_token'] );
$cron_line    = mvweb_de_price_cron_line( (string) $price['cron_token'] );
$logo_url    = ! empty( $price['logo_id'] ) ? wp_get_attachment_image_url( (int) $price['logo_id'], 'medium' ) : '';

$field_map    = mvweb_de_get_friendly_field_map();
$attrs_map    = mvweb_de_get_variation_attributes();
$field_groups = array(
	'basic' => __( 'Product', 'mvweb-data-export' ),
	'price' => __( 'Prices & stock', 'mvweb-data-export' ),
);

/**
 * Render a single column-mapping row using one friendly "data" dropdown.
 *
 * Technical inputs (custom meta key, variation attribute/value) are hidden and
 * only revealed when the matching advanced option is chosen.
 *
 * @param array $col          Column data.
 * @param array $field_map    Friendly field catalog.
 * @param array $field_groups Group id => label.
 * @param array $attrs_map    Variation attributes catalog.
 * @return void
 */
$render_column_row = function ( array $col, array $field_map, array $field_groups, array $attrs_map ) {
	$label     = isset( $col['label'] ) ? $col['label'] : '';
	$source    = isset( $col['source'] ) ? $col['source'] : '';
	$key       = isset( $col['key'] ) ? $col['key'] : '';
	$attribute = isset( $col['attribute'] ) ? $col['attribute'] : '';
	$value     = isset( $col['value'] ) ? $col['value'] : '';

	$choice   = ( '' === $source ) ? '' : mvweb_de_resolve_field_choice( $source, $key );
	$is_meta  = ( 'meta' === $choice );
	$is_var   = ( 'variation' === $choice );
	$meta_key = $is_meta ? $key : '';
	?>
	<div class="mvweb-de-price-col">
		<div class="mvweb-de-price-col__grid">
			<select class="mvweb-select mvweb-de-price-col__field">
				<option value=""><?php esc_html_e( '— Choose data —', 'mvweb-data-export' ); ?></option>
				<?php foreach ( $field_groups as $gkey => $glabel ) : ?>
					<optgroup label="<?php echo esc_attr( $glabel ); ?>">
						<?php
						foreach ( $field_map as $cid => $def ) :
							if ( $def['group'] !== $gkey ) {
								continue;
							}
							?>
							<option value="<?php echo esc_attr( $cid ); ?>" <?php selected( $choice, $cid ); ?>><?php echo esc_html( $def['label'] ); ?></option>
						<?php endforeach; ?>
					</optgroup>
				<?php endforeach; ?>
				<optgroup label="<?php esc_attr_e( 'Advanced', 'mvweb-data-export' ); ?>">
					<?php if ( ! empty( $attrs_map ) ) : ?>
						<option value="variation" <?php selected( $choice, 'variation' ); ?>><?php esc_html_e( 'Price from a variation (e.g. wholesale)…', 'mvweb-data-export' ); ?></option>
					<?php endif; ?>
					<option value="meta" <?php selected( $choice, 'meta' ); ?>><?php esc_html_e( 'Custom field (meta key)…', 'mvweb-data-export' ); ?></option>
				</optgroup>
			</select>

			<input type="text" class="mvweb-input mvweb-de-price-col__label" placeholder="<?php esc_attr_e( 'Column title', 'mvweb-data-export' ); ?>" value="<?php echo esc_attr( $label ); ?>">

			<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-de-price-col__remove" aria-label="<?php esc_attr_e( 'Remove column', 'mvweb-data-export' ); ?>">&times;</button>
		</div>

		<div class="mvweb-de-price-col__meta-row" style="<?php echo esc_attr( $is_meta ? '' : 'display:none;' ); ?>">
			<input type="text" class="mvweb-input mvweb-de-price-col__meta-key" placeholder="<?php esc_attr_e( 'Meta key, e.g. _my_price', 'mvweb-data-export' ); ?>" value="<?php echo esc_attr( $meta_key ); ?>">
			<span class="mvweb-de-price-col__hint"><?php esc_html_e( 'The internal field name of the product.', 'mvweb-data-export' ); ?></span>
		</div>

		<div class="mvweb-de-price-col__var-row" style="<?php echo esc_attr( $is_var ? '' : 'display:none;' ); ?>">
			<select class="mvweb-select mvweb-de-price-col__var-attr">
				<option value=""><?php esc_html_e( '— Attribute —', 'mvweb-data-export' ); ?></option>
				<?php foreach ( $attrs_map as $tax => $adef ) : ?>
					<option value="<?php echo esc_attr( $tax ); ?>" <?php selected( $attribute, $tax ); ?>><?php echo esc_html( $adef['label'] ); ?></option>
				<?php endforeach; ?>
			</select>
			<select class="mvweb-select mvweb-de-price-col__var-value">
				<option value=""><?php esc_html_e( '— Value —', 'mvweb-data-export' ); ?></option>
				<?php
				if ( $is_var && isset( $attrs_map[ $attribute ]['terms'] ) ) :
					foreach ( $attrs_map[ $attribute ]['terms'] as $slug => $name ) :
						?>
						<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $value, $slug ); ?>><?php echo esc_html( $name ); ?></option>
						<?php
					endforeach;
				endif;
				?>
			</select>
			<span class="mvweb-de-price-col__hint"><?php esc_html_e( 'Picks the matching variation and reads its regular price.', 'mvweb-data-export' ); ?></span>
		</div>
	</div>
	<?php
};
?>

<form id="mvweb-de-price-form">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Company header', 'mvweb-data-export' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Optional. Shown at the top of the price file. Leave fields empty to hide them.', 'mvweb-data-export' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb-de-price-logo-select" class="mvweb-form-row__label"><?php esc_html_e( 'Logo', 'mvweb-data-export' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="hidden" id="mvweb-de-price-logo-id" value="<?php echo esc_attr( (int) $price['logo_id'] ); ?>">
				<div class="mvweb-de-price-logo">
					<img id="mvweb-de-price-logo-preview" src="<?php echo esc_url( $logo_url ); ?>" alt="" style="<?php echo esc_attr( $logo_url ? '' : 'display:none;' ); ?>">
				</div>
				<button type="button" class="mvweb-btn mvweb-btn--secondary" id="mvweb-de-price-logo-select"><?php esc_html_e( 'Select logo', 'mvweb-data-export' ); ?></button>
				<button type="button" class="mvweb-btn mvweb-btn--ghost" id="mvweb-de-price-logo-remove" style="<?php echo esc_attr( $logo_url ? '' : 'display:none;' ); ?>"><?php esc_html_e( 'Remove', 'mvweb-data-export' ); ?></button>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'PNG or JPG. Embedded into the file.', 'mvweb-data-export' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-de-price-company" class="mvweb-form-row__label"><?php esc_html_e( 'Company name', 'mvweb-data-export' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb-de-price-company" class="mvweb-input" value="<?php echo esc_attr( $price['company'] ); ?>">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-de-price-description" class="mvweb-form-row__label"><?php esc_html_e( 'Short description', 'mvweb-data-export' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb-de-price-description" class="mvweb-input" value="<?php echo esc_attr( $price['description'] ); ?>">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-de-price-phone" class="mvweb-form-row__label"><?php esc_html_e( 'Phone', 'mvweb-data-export' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb-de-price-phone" class="mvweb-input" value="<?php echo esc_attr( $price['phone'] ); ?>">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-de-price-address" class="mvweb-form-row__label"><?php esc_html_e( 'Address', 'mvweb-data-export' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb-de-price-address" class="mvweb-input" value="<?php echo esc_attr( $price['address'] ); ?>">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-de-price-messengers" class="mvweb-form-row__label"><?php esc_html_e( 'Messengers', 'mvweb-data-export' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb-de-price-messengers" class="mvweb-input" value="<?php echo esc_attr( $price['messengers'] ); ?>" placeholder="<?php esc_attr_e( 'e.g. Telegram @shop, WhatsApp +7…', 'mvweb-data-export' ); ?>">
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Columns', 'mvweb-data-export' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'For each column, give it a title and choose what data to show. Tip: "Price" works for every product. Prices stored as product variations (e.g. wholesale tiers) are under "Advanced".', 'mvweb-data-export' ); ?></p>

		<div id="mvweb-de-price-columns">
			<?php
			foreach ( (array) $price['columns'] as $col ) {
				$render_column_row( (array) $col, $field_map, $field_groups, $attrs_map );
			}
			?>
		</div>

		<button type="button" class="mvweb-btn mvweb-btn--secondary" id="mvweb-de-price-add-col">+ <?php esc_html_e( 'Add column', 'mvweb-data-export' ); ?></button>

		<script type="application/json" id="mvweb-de-price-field-map"><?php echo wp_json_encode( $field_map ); ?></script>
		<script type="application/json" id="mvweb-de-price-attrs-map"><?php echo wp_json_encode( $attrs_map ); ?></script>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Automatic update', 'mvweb-data-export' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Keep the price file fresh automatically. The simplest way is via WordPress; a hosting server cron is an optional alternative shown under the download link.', 'mvweb-data-export' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb-de-price-schedule" class="mvweb-form-row__label"><?php esc_html_e( 'Refresh via WordPress', 'mvweb-data-export' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb-de-price-schedule" class="mvweb-select">
					<option value="off" <?php selected( $price['schedule'], 'off' ); ?>><?php esc_html_e( 'Off', 'mvweb-data-export' ); ?></option>
					<option value="6h" <?php selected( $price['schedule'], '6h' ); ?>><?php esc_html_e( 'Every 6 hours', 'mvweb-data-export' ); ?></option>
					<option value="daily" <?php selected( $price['schedule'], 'daily' ); ?>><?php esc_html_e( 'Once a day', 'mvweb-data-export' ); ?></option>
				</select>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'No hosting setup needed. Runs on site visits; for a low-traffic site use the server cron below instead.', 'mvweb-data-export' ); ?></p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" class="mvweb-btn mvweb-btn--primary" id="mvweb-de-price-save"><?php esc_html_e( 'Save Price Settings', 'mvweb-data-export' ); ?></button>
		<span class="mvweb-spinner mvweb-de-spinner" id="mvweb-de-price-save-spinner"></span>
	</div>
</form>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Download link & update', 'mvweb-data-export' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Public file URL', 'mvweb-data-export' ); ?></span>
		<div class="mvweb-form-row__field">
			<div class="mvweb-de-price-copy">
				<input type="text" class="mvweb-input" id="mvweb-de-price-file-url" value="<?php echo esc_url( $file_url ); ?>" readonly>
				<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-de-price-copy-btn" data-copy-target="mvweb-de-price-file-url"><?php esc_html_e( 'Copy', 'mvweb-data-export' ); ?></button>
			</div>
			<p class="mvweb-form-row__desc" id="mvweb-de-price-file-meta">
				<?php if ( $file_exists ) : ?>
					<?php
					printf(
						/* translators: 1: product count, 2: file size, 3: date. */
						esc_html__( '%1$d products · %2$s · updated %3$s', 'mvweb-data-export' ),
						(int) $price['last_count'],
						esc_html( $file_size ),
						esc_html( $file_time )
					);
					?>
				<?php else : ?>
					<?php esc_html_e( 'Not generated yet — click "Regenerate now".', 'mvweb-data-export' ); ?>
				<?php endif; ?>
			</p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"></span>
		<div class="mvweb-form-row__field">
			<button type="button" class="mvweb-btn mvweb-btn--primary" id="mvweb-de-price-regen"><?php esc_html_e( 'Regenerate now', 'mvweb-data-export' ); ?></button>
			<span class="mvweb-spinner mvweb-de-spinner" id="mvweb-de-price-regen-spinner"></span>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Alternative: hosting server cron', 'mvweb-data-export' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'For a low-traffic site you can run the update from your hosting cron instead. The link contains a secret token — keep it private.', 'mvweb-data-export' ); ?></p>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Command', 'mvweb-data-export' ); ?></span>
		<div class="mvweb-form-row__field">
			<div class="mvweb-de-price-copy">
				<input type="text" class="mvweb-input" id="mvweb-de-price-cron-command" value="<?php echo esc_attr( $cron_command ); ?>" readonly>
				<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-de-price-copy-btn" data-copy-target="mvweb-de-price-cron-command"><?php esc_html_e( 'Copy', 'mvweb-data-export' ); ?></button>
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'In a visual cron panel paste only this command and set the schedule (e.g. every 6 hours) in the panel\'s own fields — do not add "0 */6 * * *" here.', 'mvweb-data-export' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Full crontab line', 'mvweb-data-export' ); ?></span>
		<div class="mvweb-form-row__field">
			<div class="mvweb-de-price-copy">
				<input type="text" class="mvweb-input" id="mvweb-de-price-cron-line" value="<?php echo esc_attr( $cron_line ); ?>" readonly>
				<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-de-price-copy-btn" data-copy-target="mvweb-de-price-cron-line"><?php esc_html_e( 'Copy', 'mvweb-data-export' ); ?></button>
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'For a text crontab. Change "0 */6 * * *" for a different schedule (e.g. "0 3 * * *" = daily at 03:00).', 'mvweb-data-export' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'WP-CLI alternative', 'mvweb-data-export' ); ?></span>
		<div class="mvweb-form-row__field">
			<div class="mvweb-de-price-copy">
				<input type="text" class="mvweb-input" id="mvweb-de-price-wpcli-line" value="wp eval 'do_action(&quot;mvweb_de_regen_price&quot;);'" readonly>
				<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-de-price-copy-btn" data-copy-target="mvweb-de-price-wpcli-line"><?php esc_html_e( 'Copy', 'mvweb-data-export' ); ?></button>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Secret link', 'mvweb-data-export' ); ?></span>
		<div class="mvweb-form-row__field">
			<button type="button" class="mvweb-btn mvweb-btn--ghost" id="mvweb-de-price-rotate-token"><?php esc_html_e( 'Generate a new secret link', 'mvweb-data-export' ); ?></button>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Use this if the current link leaked. The old link stops working immediately.', 'mvweb-data-export' ); ?></p>
		</div>
	</div>
</div>

<script type="text/html" id="mvweb-de-price-col-template">
	<?php $render_column_row( array(), $field_map, $field_groups, $attrs_map ); ?>
</script>
