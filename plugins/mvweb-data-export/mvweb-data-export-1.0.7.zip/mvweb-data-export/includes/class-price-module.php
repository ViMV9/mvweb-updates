<?php
/**
 * Price list module controller for MVweb Data Export.
 *
 * Wires the price-list feature: a public token-protected regeneration endpoint
 * (for external server cron), admin AJAX (manual regeneration, settings save,
 * status info), and delegates the actual work to the generator.
 *
 * Auto-update offers two interchangeable options: WordPress' own scheduler
 * (WP-Cron, no hosting setup needed) or an external server cron hitting the
 * public endpoint. Plus a manual "Regenerate now" button.
 *
 * @package MVweb_Data_Export
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_DE_Price_Module
 *
 * @since 1.1.0
 */
class MVweb_DE_Price_Module {

	/**
	 * Public query var that triggers regeneration.
	 *
	 * @var string
	 */
	private const TRIGGER_VAR = 'mvweb_de_price_regen';

	/**
	 * Allowed header text fields and their sanitizers.
	 *
	 * @var string[]
	 */
	private const TEXT_FIELDS = array( 'company', 'description', 'phone', 'address', 'messengers' );

	/**
	 * Generator instance.
	 *
	 * @var MVweb_DE_Price_Generator
	 */
	private MVweb_DE_Price_Generator $generator;

	/**
	 * Writer instance (for extension/URL resolution).
	 *
	 * @var MVweb_DE_Price_Writer_Interface
	 */
	private MVweb_DE_Price_Writer_Interface $writer;

	/**
	 * Constructor.
	 *
	 * @since 1.1.0
	 * @param MVweb_DE_Price_Generator        $generator Generator instance.
	 * @param MVweb_DE_Price_Writer_Interface $writer    Writer instance.
	 */
	public function __construct( MVweb_DE_Price_Generator $generator, MVweb_DE_Price_Writer_Interface $writer ) {
		$this->generator = $generator;
		$this->writer    = $writer;
	}

	/**
	 * Register hooks.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function init(): void {
		add_action( 'init', array( $this, 'handle_public_endpoint' ) );
		add_action( 'mvweb_de_regen_price', array( $this, 'run_regen' ) );
		add_filter( 'cron_schedules', array( $this, 'add_cron_schedule' ) ); // phpcs:ignore WordPress.WP.CronInterval.ChangeDetected
		add_action( 'wp_ajax_mvweb_de_price_regen_now', array( $this, 'ajax_regen_now' ) );
		add_action( 'wp_ajax_mvweb_de_price_save_settings', array( $this, 'ajax_save_settings' ) );
		add_action( 'wp_ajax_mvweb_de_price_get_info', array( $this, 'ajax_get_info' ) );
	}

	/**
	 * Action handler to regenerate the price file (used by WP-CLI / do_action).
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function run_regen(): void {
		$this->generator->generate();
	}

	/**
	 * Handle the public token-protected regeneration endpoint.
	 *
	 * Triggered by an external cron, e.g.:
	 *   curl -s "https://example.com/?mvweb_de_price_regen=TOKEN"
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function handle_public_endpoint(): void {
		if ( ! isset( $_GET[ self::TRIGGER_VAR ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		$token    = sanitize_text_field( wp_unslash( $_GET[ self::TRIGGER_VAR ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$settings = mvweb_de_get_price_settings();
		$expected = (string) $settings['cron_token'];

		nocache_headers();

		if ( '' === $expected || ! hash_equals( $expected, $token ) ) {
			status_header( 403 );
			echo 'FORBIDDEN';
			exit;
		}

		$result = $this->generator->generate();

		if ( ! empty( $result['success'] ) ) {
			status_header( 200 );
			echo 'OK ' . (int) $result['count'];
		} else {
			status_header( 500 );
			echo 'ERROR';
		}
		exit;
	}

	/**
	 * AJAX: regenerate the price file now (admin button).
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function ajax_regen_now(): void {
		$this->verify_admin();

		$result = $this->generator->generate();

		if ( empty( $result['success'] ) ) {
			wp_send_json_error( array( 'message' => $result['error'] ) );
		}

		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: %d: number of products. */
					__( 'Price list updated: %d products.', 'mvweb-data-export' ),
					(int) $result['count']
				),
				'info'    => $this->get_file_info(),
			)
		);
	}

	/**
	 * AJAX: save price settings.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function ajax_save_settings(): void {
		$this->verify_admin();

		$settings = mvweb_de_get_price_settings();

		// Header text fields.
		foreach ( self::TEXT_FIELDS as $field ) {
			if ( isset( $_POST[ $field ] ) ) {
				$settings[ $field ] = sanitize_text_field( wp_unslash( $_POST[ $field ] ) );
			}
		}

		// Logo attachment ID.
		if ( isset( $_POST['logo_id'] ) ) {
			$settings['logo_id'] = absint( wp_unslash( $_POST['logo_id'] ) );
		}

		// Column mapping (JSON-encoded array of objects).
		if ( isset( $_POST['columns'] ) ) {
			$raw = json_decode( wp_unslash( $_POST['columns'] ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$settings['columns'] = is_array( $raw ) ? mvweb_de_sanitize_price_columns( $raw ) : array();
		}

		// Auto-update schedule (WP-Cron): 'off' | '6h' | 'daily'.
		if ( isset( $_POST['schedule'] ) ) {
			$schedule             = sanitize_key( wp_unslash( $_POST['schedule'] ) );
			$settings['schedule'] = in_array( $schedule, array( 'off', '6h', 'daily' ), true ) ? $schedule : 'off';
		}

		// Optional secret-token rotation.
		if ( ! empty( $_POST['regenerate_token'] ) || empty( $settings['cron_token'] ) ) {
			$settings['cron_token'] = wp_generate_password( 32, false );
		}

		update_option( 'mvweb_de_price_settings', $settings );
		$this->sync_schedule( (string) $settings['schedule'] );

		wp_send_json_success(
			array(
				'message' => __( 'Settings saved.', 'mvweb-data-export' ),
				'info'    => $this->get_file_info(),
			)
		);
	}

	/**
	 * AJAX: return current price file + endpoint info.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function ajax_get_info(): void {
		$this->verify_admin();
		wp_send_json_success( array( 'info' => $this->get_file_info() ) );
	}

	/**
	 * Verify an admin AJAX request (nonce + capability).
	 *
	 * Reuses the plugin-wide nonce action 'mvweb_de_action'.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	private function verify_admin(): void {
		check_ajax_referer( 'mvweb_de_action', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'mvweb-data-export' ) ), 403 );
		}
	}

	/**
	 * Build the status info payload for the admin UI.
	 *
	 * @since 1.1.0
	 * @return array
	 */
	private function get_file_info(): array {
		$ext      = $this->writer->get_extension();
		$settings = mvweb_de_get_price_settings();
		$exists   = MVweb_DE_Price_File_Manager::file_exists( $ext );

		return array(
			'exists'     => $exists,
			'url'        => $exists ? MVweb_DE_Price_File_Manager::get_price_file_url( $ext ) : '',
			'size'       => $exists ? size_format( (int) MVweb_DE_Price_File_Manager::get_file_size( $ext ) ) : '',
			'modified'   => $exists ? $this->format_time( (int) MVweb_DE_Price_File_Manager::get_last_modified( $ext ) ) : '',
			'count'        => (int) $settings['last_count'],
			'schedule'     => isset( $settings['schedule'] ) ? (string) $settings['schedule'] : 'off',
			'regen_url'    => $this->get_regen_url( $settings['cron_token'] ),
			'cron_command' => mvweb_de_price_cron_command( (string) $settings['cron_token'] ),
			'cron_line'    => $this->get_cron_line( $settings['cron_token'] ),
			'wpcli_line'   => $this->get_wpcli_line(),
		);
	}

	/**
	 * Register a custom "every 6 hours" WP-Cron interval.
	 *
	 * @since 1.1.0
	 * @param array $schedules Existing cron schedules.
	 * @return array
	 */
	public function add_cron_schedule( array $schedules ): array {
		if ( ! isset( $schedules['mvweb_de_6h'] ) ) {
			$schedules['mvweb_de_6h'] = array(
				'interval' => 6 * HOUR_IN_SECONDS,
				'display'  => __( 'Every 6 hours', 'mvweb-data-export' ),
			);
		}
		return $schedules;
	}

	/**
	 * Schedule or clear the WP-Cron auto-update event.
	 *
	 * Reuses the 'mvweb_de_regen_price' action (already wired to run_regen).
	 *
	 * @since 1.1.0
	 * @param string $schedule One of 'off' | '6h' | 'daily'.
	 * @return void
	 */
	private function sync_schedule( string $schedule ): void {
		wp_clear_scheduled_hook( 'mvweb_de_regen_price' );

		$recurrence = '';
		if ( '6h' === $schedule ) {
			$recurrence = 'mvweb_de_6h';
		} elseif ( 'daily' === $schedule ) {
			$recurrence = 'daily';
		}

		if ( '' !== $recurrence ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, $recurrence, 'mvweb_de_regen_price' );
		}
	}

	/**
	 * Build the public regeneration URL with the secret token.
	 *
	 * @since 1.1.0
	 * @param string $token Secret token.
	 * @return string
	 */
	private function get_regen_url( string $token ): string {
		return mvweb_de_price_regen_url( $token );
	}

	/**
	 * Build a ready-to-paste crontab line (every 6 hours).
	 *
	 * @since 1.1.0
	 * @param string $token Secret token.
	 * @return string
	 */
	private function get_cron_line( string $token ): string {
		return mvweb_de_price_cron_line( $token );
	}

	/**
	 * Build a WP-CLI alternative line.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private function get_wpcli_line(): string {
		return "wp eval 'do_action(\"mvweb_de_regen_price\");'";
	}

	/**
	 * Format a unix timestamp in the site's locale.
	 *
	 * @since 1.1.0
	 * @param int $timestamp Unix timestamp.
	 * @return string
	 */
	private function format_time( int $timestamp ): string {
		if ( $timestamp <= 0 ) {
			return '';
		}
		return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp );
	}
}
