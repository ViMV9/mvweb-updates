<?php
/**
 * XLSX price writer for MVweb Data Export.
 *
 * Produces a real .xlsx file (with embedded logo and a branded header block)
 * using the bundled FastExcelWriter library — a lightweight, pure-PHP writer
 * that does not require the heavy PhpSpreadsheet dependency.
 *
 * @package MVweb_Data_Export
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Load the bundled FastExcelWriter library (registers its own autoloaders).
if ( ! class_exists( '\avadim\FastExcelWriter\Excel' ) ) {
	require_once MVWEB_DE_PATH . 'includes/lib/fast-excel-helper/src/autoload.php';
	require_once MVWEB_DE_PATH . 'includes/lib/fast-excel-writer/src/autoload.php';
}

/**
 * Class MVweb_DE_Price_Writer_Xlsx
 *
 * @since 1.1.0
 */
class MVweb_DE_Price_Writer_Xlsx implements MVweb_DE_Price_Writer_Interface {

	/**
	 * Brand color for the table header background.
	 *
	 * @var string
	 */
	private const BRAND_COLOR = '#793EA4';

	/**
	 * Image extensions Excel can embed.
	 *
	 * @var string[]
	 */
	private const IMAGE_EXT = array( 'png', 'jpg', 'jpeg', 'gif' );

	/**
	 * {@inheritDoc}
	 *
	 * @since 1.1.0
	 * @param array  $header   Header block: logo_path, title, lines[].
	 * @param array  $columns  Column labels.
	 * @param array  $rows     Data rows.
	 * @param string $filepath Target file path.
	 * @return bool
	 */
	public function write( array $header, array $columns, array $rows, string $filepath ): bool {
		if ( empty( $columns ) ) {
			return false;
		}

		try {
			$excel = \avadim\FastExcelWriter\Excel::create( array( 'Price' ) );
			$sheet = $excel->sheet();

			$last_col = \avadim\FastExcelWriter\Excel::colLetter( count( $columns ) );
			$row      = 0;

			$this->write_header_block( $sheet, $header, $last_col, $row );
			$this->write_table( $sheet, $columns, $rows );
			$this->set_column_widths( $sheet, count( $columns ) );

			$tmp = $filepath . '.tmp';
			if ( ! $excel->save( $tmp, true ) || ! file_exists( $tmp ) ) {
				return false;
			}

			return $this->atomic_replace( $tmp, $filepath );
		} catch ( \Throwable $e ) {
			error_log( 'MVweb Data Export price writer error: ' . $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			return false;
		}
	}

	/**
	 * {@inheritDoc}
	 *
	 * @since 1.1.0
	 * @return string
	 */
	public function get_extension(): string {
		return 'xlsx';
	}

	/**
	 * Write the optional logo + company header block.
	 *
	 * @since 1.1.0
	 * @param object $sheet    FastExcelWriter sheet.
	 * @param array  $header   Header data.
	 * @param string $last_col Last column letter for merging.
	 * @param int    $row      Current row counter (by reference, mirrors the writer cursor).
	 * @return void
	 */
	private function write_header_block( $sheet, array $header, string $last_col, int &$row ): void {
		$logo_path = isset( $header['logo_path'] ) ? (string) $header['logo_path'] : '';
		$title     = isset( $header['title'] ) ? (string) $header['title'] : '';
		$lines     = isset( $header['lines'] ) && is_array( $header['lines'] ) ? $header['lines'] : array();

		// Reserved row for the floating logo image.
		if ( '' !== $logo_path && $this->is_embeddable_image( $logo_path ) ) {
			$row++;
			$sheet->writeRow( array( ' ' ) );
			$sheet->setRowHeight( $row, 46 );
			$sheet->addImage( 'A1', $logo_path, array( 'height' => 40 ) );
		}

		if ( '' !== $title ) {
			$row++;
			$sheet->writeRow( array( $title ) );
			$sheet->applyFontStyleBold()->applyFontSize( 14 )->applyAlignLeft();
			$sheet->mergeCells( 'A' . $row . ':' . $last_col . $row );
		}

		foreach ( $lines as $line ) {
			$line = (string) $line;
			if ( '' === $line ) {
				continue;
			}
			$row++;
			$sheet->writeRow( array( $line ) );
			$sheet->applyAlignLeft();
			$sheet->mergeCells( 'A' . $row . ':' . $last_col . $row );
		}

		// Spacer row before the table.
		if ( $row > 0 ) {
			$row++;
			$sheet->writeRow( array( ' ' ) );
		}
	}

	/**
	 * Write the table header and data rows.
	 *
	 * @since 1.1.0
	 * @param object $sheet   FastExcelWriter sheet.
	 * @param array  $columns Column configs (label + source/key).
	 * @param array  $rows    Data rows.
	 * @return void
	 */
	private function write_table( $sheet, array $columns, array $rows ): void {
		$labels     = array();
		$price_cols = array();
		$price_idx  = array();
		foreach ( $columns as $i => $col ) {
			$col      = (array) $col;
			$labels[] = isset( $col['label'] ) ? (string) $col['label'] : '';
			if ( $this->is_price_column( $col ) ) {
				$price_cols[] = \avadim\FastExcelWriter\Excel::colLetter( $i + 1 );
				$price_idx[]  = $i;
			}
		}

		$sheet->writeHeader( $labels );
		$sheet->applyFontStyleBold()
			->applyFontColor( '#FFFFFF' )
			->applyFillColor( self::BRAND_COLOR )
			->applyTextAlign( 'center', 'center' )
			->applyBorder( 'thin' )
			->applyRowHeight( 22 );

		// Right-align the data cells of price columns; the header stays centered.
		foreach ( $price_cols as $col_letter ) {
			$sheet->setColDataStyle( $col_letter, array( 'format-align-horizontal' => 'right' ) );
		}

		if ( empty( $rows ) ) {
			return;
		}

		// Show a placeholder instead of a blank cell when a price is missing.
		if ( ! empty( $price_idx ) ) {
			$placeholder = __( 'On request', 'mvweb-data-export' );
			foreach ( $rows as &$row ) {
				foreach ( $price_idx as $ci ) {
					if ( ! isset( $row[ $ci ] ) || '' === (string) $row[ $ci ] ) {
						$row[ $ci ] = $placeholder;
					}
				}
			}
			unset( $row );
		}

		$sheet->writeRows( $rows );
	}

	/**
	 * Whether a column holds price values (right-aligned in the file).
	 *
	 * @since 1.1.0
	 * @param array $col Column config.
	 * @return bool
	 */
	private function is_price_column( array $col ): bool {
		$source = isset( $col['source'] ) ? $col['source'] : '';

		if ( 'variation' === $source ) {
			return true;
		}

		if ( 'wc' === $source ) {
			$key = isset( $col['key'] ) ? $col['key'] : '';
			return in_array( $key, array( 'wc_regular_price', 'wc_sale_price', 'wc_price' ), true );
		}

		return false;
	}

	/**
	 * Set reasonable column widths (first column wider for names/SKU).
	 *
	 * @since 1.1.0
	 * @param object $sheet     FastExcelWriter sheet.
	 * @param int    $col_count Number of columns.
	 * @return void
	 */
	private function set_column_widths( $sheet, int $col_count ): void {
		$widths = array();
		for ( $i = 0; $i < $col_count; $i++ ) {
			$widths[] = ( 0 === $i ) ? 34 : 18;
		}
		$sheet->setColWidths( $widths );
	}

	/**
	 * Atomically move the temp file into place.
	 *
	 * @since 1.1.0
	 * @param string $tmp   Temp file path.
	 * @param string $final Final file path.
	 * @return bool
	 */
	private function atomic_replace( string $tmp, string $final ): bool {
		if ( @rename( $tmp, $final ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			return true;
		}

		// Fallback: copy + unlink if rename across mounts fails.
		if ( @copy( $tmp, $final ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
			return true;
		}

		@unlink( $tmp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
		return false;
	}

	/**
	 * Whether a file looks like an Excel-embeddable raster image.
	 *
	 * @since 1.1.0
	 * @param string $path Absolute file path.
	 * @return bool
	 */
	private function is_embeddable_image( string $path ): bool {
		if ( ! is_readable( $path ) ) {
			return false;
		}
		$ext = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
		return in_array( $ext, self::IMAGE_EXT, true );
	}
}
