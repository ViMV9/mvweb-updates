<?php
/**
 * Price file manager for MVweb Data Export.
 *
 * Manages a PUBLIC directory for the client price list. Unlike the main export
 * directory (protected by .htaccess Deny from all), this folder is intentionally
 * web-accessible so the price file can be downloaded via a fixed public URL.
 *
 * Only public product data ends up here — the same data already visible on the
 * storefront — so a public directory carries no extra disclosure risk.
 *
 * @package MVweb_Data_Export
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_DE_Price_File_Manager
 *
 * @since 1.1.0
 */
class MVweb_DE_Price_File_Manager {

	/**
	 * Public price directory name within uploads.
	 *
	 * @var string
	 */
	private const PRICE_DIR = 'mvweb-price';

	/**
	 * Base file name (without extension).
	 *
	 * @var string
	 */
	private const PRICE_BASENAME = 'price';

	/**
	 * Get the public price directory path.
	 *
	 * @since 1.1.0
	 * @return string Absolute path with trailing slash.
	 */
	public static function get_price_dir(): string {
		$upload_dir = wp_upload_dir();
		return trailingslashit( $upload_dir['basedir'] ) . self::PRICE_DIR . '/';
	}

	/**
	 * Get the public price directory URL.
	 *
	 * @since 1.1.0
	 * @return string Public base URL with trailing slash.
	 */
	public static function get_price_url_base(): string {
		$upload_dir = wp_upload_dir();
		return trailingslashit( $upload_dir['baseurl'] ) . self::PRICE_DIR . '/';
	}

	/**
	 * Get the absolute file path for a given extension.
	 *
	 * @since 1.1.0
	 * @param string $ext Extension without dot (e.g. 'xlsx').
	 * @return string Absolute file path.
	 */
	public static function get_price_filepath( string $ext ): string {
		return self::get_price_dir() . self::PRICE_BASENAME . '.' . self::sanitize_ext( $ext );
	}

	/**
	 * Get the public URL for the price file of a given extension.
	 *
	 * @since 1.1.0
	 * @param string $ext Extension without dot.
	 * @return string Public file URL.
	 */
	public static function get_price_file_url( string $ext ): string {
		return self::get_price_url_base() . self::PRICE_BASENAME . '.' . self::sanitize_ext( $ext );
	}

	/**
	 * Create the public price directory.
	 *
	 * Adds an index.php to prevent directory listing, but deliberately does NOT
	 * add an .htaccess Deny rule — the file must be publicly downloadable.
	 *
	 * @since 1.1.0
	 * @return bool True if the directory exists after the call.
	 */
	public static function ensure_price_dir(): bool {
		$dir = self::get_price_dir();

		if ( ! is_dir( $dir ) ) {
			wp_mkdir_p( $dir );
		}

		// Prevent directory listing without blocking file access.
		$index_path = $dir . 'index.php';
		if ( ! file_exists( $index_path ) ) {
			file_put_contents( $index_path, '<?php' . PHP_EOL . '// Silence is golden.' . PHP_EOL ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		return is_dir( $dir );
	}

	/**
	 * Check whether a price file exists for the given extension.
	 *
	 * @since 1.1.0
	 * @param string $ext Extension without dot.
	 * @return bool
	 */
	public static function file_exists( string $ext ): bool {
		return file_exists( self::get_price_filepath( $ext ) );
	}

	/**
	 * Get the size of the price file in bytes.
	 *
	 * @since 1.1.0
	 * @param string $ext Extension without dot.
	 * @return int|false Size in bytes, or false if missing.
	 */
	public static function get_file_size( string $ext ) {
		$path = self::get_price_filepath( $ext );
		return file_exists( $path ) ? filesize( $path ) : false;
	}

	/**
	 * Get the last-modified timestamp of the price file.
	 *
	 * @since 1.1.0
	 * @param string $ext Extension without dot.
	 * @return int|false Unix timestamp, or false if missing.
	 */
	public static function get_last_modified( string $ext ) {
		$path = self::get_price_filepath( $ext );
		return file_exists( $path ) ? filemtime( $path ) : false;
	}

	/**
	 * Sanitize an extension string to a safe lowercase token.
	 *
	 * @since 1.1.0
	 * @param string $ext Raw extension.
	 * @return string Safe extension.
	 */
	private static function sanitize_ext( string $ext ): string {
		$ext = strtolower( preg_replace( '/[^a-z0-9]/i', '', $ext ) );
		return '' !== $ext ? $ext : 'xlsx';
	}
}
