<?php
/**
 * Price list generator for MVweb Data Export.
 *
 * Queries published WooCommerce products in batches, resolves each configured
 * column against its data source, and hands the collected data to a writer.
 *
 * Supports two price-source models so the plugin stays universal:
 *  - 'meta'      — price stored in a product custom field (meta key);
 *  - 'variation' — price taken from the product variation whose attribute
 *                  matches a given value (e.g. pa_price = opt-1), reading a
 *                  meta key off that variation (typically _regular_price).
 *
 * @package MVweb_Data_Export
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_DE_Price_Generator
 *
 * @since 1.1.0
 */
class MVweb_DE_Price_Generator {

	/**
	 * Number of products per query batch.
	 *
	 * @var int
	 */
	private const BATCH_SIZE = 200;

	/**
	 * Lock transient key (prevents concurrent regeneration).
	 *
	 * @var string
	 */
	private const LOCK_KEY = 'mvweb_de_price_lock';

	/**
	 * Output writer.
	 *
	 * @var MVweb_DE_Price_Writer_Interface
	 */
	private MVweb_DE_Price_Writer_Interface $writer;

	/**
	 * WooCommerce fields helper (for 'wc' source columns).
	 *
	 * @var MVweb_DE_WC_Fields|null
	 */
	private ?MVweb_DE_WC_Fields $wc_fields;

	/**
	 * Constructor.
	 *
	 * @since 1.1.0
	 * @param MVweb_DE_Price_Writer_Interface $writer    Output writer.
	 * @param MVweb_DE_WC_Fields|null         $wc_fields WooCommerce fields helper.
	 */
	public function __construct( MVweb_DE_Price_Writer_Interface $writer, ?MVweb_DE_WC_Fields $wc_fields = null ) {
		$this->writer    = $writer;
		$this->wc_fields = $wc_fields;
	}

	/**
	 * Generate the price file from current settings.
	 *
	 * @since 1.1.0
	 * @return array Result: success (bool), count (int), url (string), error (string).
	 */
	public function generate(): array {
		$settings = mvweb_de_get_price_settings();
		$columns  = $settings['columns'];

		if ( empty( $columns ) ) {
			return $this->error( __( 'No columns configured for the price list.', 'mvweb-data-export' ) );
		}

		if ( get_transient( self::LOCK_KEY ) ) {
			return $this->error( __( 'Price generation is already running. Try again in a minute.', 'mvweb-data-export' ) );
		}

		set_transient( self::LOCK_KEY, 1, 5 * MINUTE_IN_SECONDS );

		try {
			if ( ! MVweb_DE_Price_File_Manager::ensure_price_dir() ) {
				return $this->error( __( 'Could not create the price directory. Check uploads folder permissions.', 'mvweb-data-export' ) );
			}

			$has_variation_col = $this->has_variation_column( $columns );
			$rows              = $this->collect_rows( $columns, $has_variation_col );

			$ext      = $this->writer->get_extension();
			$filepath = MVweb_DE_Price_File_Manager::get_price_filepath( $ext );

			$ok = $this->writer->write( $this->get_header_data( $settings ), $columns, $rows, $filepath );

			if ( ! $ok ) {
				return $this->error( __( 'Failed to write the price file.', 'mvweb-data-export' ) );
			}

			$settings['last_regen'] = time();
			$settings['last_count'] = count( $rows );
			update_option( 'mvweb_de_price_settings', $settings );

			return array(
				'success' => true,
				'count'   => count( $rows ),
				'url'     => MVweb_DE_Price_File_Manager::get_price_file_url( $ext ),
				'error'   => '',
			);
		} catch ( \Throwable $e ) {
			error_log( 'MVweb Data Export price generator error: ' . $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			return $this->error( __( 'An unexpected error occurred during price generation.', 'mvweb-data-export' ) );
		} finally {
			delete_transient( self::LOCK_KEY );
		}
	}

	/**
	 * Collect all product rows in batches.
	 *
	 * @since 1.1.0
	 * @param array $columns           Column configuration.
	 * @param bool  $has_variation_col Whether any column needs variation data.
	 * @return array Array of value-rows.
	 */
	private function collect_rows( array $columns, bool $has_variation_col ): array {
		$rows   = array();
		$offset = 0;

		do {
			$ids = $this->query_batch( $offset );

			if ( empty( $ids ) ) {
				break;
			}

			update_postmeta_cache( $ids );
			update_object_term_cache( $ids, 'product' );

			foreach ( $ids as $product_id ) {
				$rows[] = $this->build_row( (int) $product_id, $columns, $has_variation_col );
			}

			$offset += self::BATCH_SIZE;
		} while ( count( $ids ) === self::BATCH_SIZE );

		return $rows;
	}

	/**
	 * Query a batch of published product IDs (top-level products only).
	 *
	 * @since 1.1.0
	 * @param int $offset Query offset.
	 * @return array Array of product IDs.
	 */
	private function query_batch( int $offset ): array {
		$query = new WP_Query(
			array(
				'post_type'              => 'product',
				'post_status'            => 'publish',
				'posts_per_page'         => self::BATCH_SIZE,
				'offset'                 => $offset,
				'orderby'                => 'menu_order title',
				'order'                  => 'ASC',
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);

		return $query->posts;
	}

	/**
	 * Build a single product row aligned to the column configuration.
	 *
	 * @since 1.1.0
	 * @param int   $product_id        Product ID.
	 * @param array $columns           Column configuration.
	 * @param bool  $has_variation_col Whether variation data is needed.
	 * @return array Ordered row values.
	 */
	private function build_row( int $product_id, array $columns, bool $has_variation_col ): array {
		$post = get_post( $product_id );
		if ( ! $post ) {
			return array_fill( 0, count( $columns ), '' );
		}

		$variation_ids = array();
		if ( $has_variation_col ) {
			$variation_ids = $this->get_variation_ids( $product_id );
			if ( ! empty( $variation_ids ) ) {
				update_postmeta_cache( $variation_ids );
			}
		}

		$row = array();
		foreach ( $columns as $col ) {
			$row[] = $this->fetch_value( $post, $col, $variation_ids );
		}

		return $row;
	}

	/**
	 * Resolve a single column value for a product.
	 *
	 * @since 1.1.0
	 * @param WP_Post $post          Product post.
	 * @param array   $col           Column configuration.
	 * @param array   $variation_ids Preloaded variation IDs (for 'variation' source).
	 * @return string
	 */
	private function fetch_value( WP_Post $post, array $col, array $variation_ids ): string {
		$source = $col['source'];
		$key    = $col['key'] ?? '';

		switch ( $source ) {
			case 'post':
				return $this->post_field( $post, $key );

			case 'meta':
				$value = get_post_meta( $post->ID, $key, true );
				return ( is_scalar( $value ) ) ? (string) $value : '';

			case 'wc':
				return $this->wc_fields ? $this->wc_fields->get_field_value( $post->ID, $key ) : '';

			case 'taxonomy':
				$terms = get_the_terms( $post->ID, $key );
				if ( $terms && ! is_wp_error( $terms ) ) {
					return implode( ' | ', wp_list_pluck( $terms, 'name' ) );
				}
				return '';

			case 'variation':
				return $this->variation_value( $variation_ids, $col );

			default:
				return '';
		}
	}

	/**
	 * Resolve a core post field.
	 *
	 * @since 1.1.0
	 * @param WP_Post $post Post object.
	 * @param string  $key  Field key.
	 * @return string
	 */
	private function post_field( WP_Post $post, string $key ): string {
		switch ( $key ) {
			case 'post_id':
				return (string) $post->ID;

			case 'post_title':
				return $post->post_title;

			case 'post_slug':
				return $post->post_name;

			case 'post_excerpt':
				return wp_strip_all_tags( $post->post_excerpt );

			case 'post_url':
				$url = get_permalink( $post->ID );
				return $url ? $url : '';

			case 'thumbnail_url':
				$thumb_id = get_post_thumbnail_id( $post->ID );
				if ( $thumb_id ) {
					$url = wp_get_attachment_url( $thumb_id );
					return $url ? $url : '';
				}
				return '';

			default:
				return '';
		}
	}

	/**
	 * Resolve a price from a product variation by attribute value.
	 *
	 * Finds the variation whose attribute (e.g. pa_price) equals the configured
	 * value (e.g. opt-1) and reads the configured meta key (e.g. _regular_price).
	 *
	 * @since 1.1.0
	 * @param array $variation_ids Variation IDs of the product.
	 * @param array $col           Column configuration with attribute/value/key.
	 * @return string
	 */
	private function variation_value( array $variation_ids, array $col ): string {
		if ( empty( $variation_ids ) ) {
			return '';
		}

		$attribute = isset( $col['attribute'] ) ? $col['attribute'] : '';
		$value     = isset( $col['value'] ) ? $col['value'] : '';
		$key       = $col['key'] ?? '_regular_price';

		if ( '' === $attribute || '' === $value ) {
			return '';
		}

		$meta_attr = 'attribute_' . $attribute;

		foreach ( $variation_ids as $vid ) {
			$attr_value = get_post_meta( (int) $vid, $meta_attr, true );
			if ( (string) $attr_value === (string) $value ) {
				$price = get_post_meta( (int) $vid, $key, true );
				return is_scalar( $price ) ? (string) $price : '';
			}
		}

		return '';
	}

	/**
	 * Get published variation IDs for a product.
	 *
	 * @since 1.1.0
	 * @param int $product_id Product ID.
	 * @return array Variation IDs.
	 */
	private function get_variation_ids( int $product_id ): array {
		return get_posts(
			array(
				'post_type'              => 'product_variation',
				'post_parent'            => $product_id,
				'post_status'            => array( 'publish', 'private' ),
				'numberposts'            => -1,
				'orderby'                => 'menu_order',
				'order'                  => 'ASC',
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'update_post_meta_cache' => false,
				'update_post_term_cache' => false,
			)
		);
	}

	/**
	 * Build the header block for the writer.
	 *
	 * @since 1.1.0
	 * @param array $settings Price settings.
	 * @return array Header data: logo_path, title, lines[].
	 */
	private function get_header_data( array $settings ): array {
		$logo_path = '';
		if ( ! empty( $settings['logo_id'] ) ) {
			$path = get_attached_file( (int) $settings['logo_id'] );
			if ( $path && is_readable( $path ) ) {
				$logo_path = $path;
			}
		}

		$lines = array();
		if ( ! empty( $settings['description'] ) ) {
			$lines[] = $settings['description'];
		}
		if ( ! empty( $settings['phone'] ) ) {
			$lines[] = __( 'Phone:', 'mvweb-data-export' ) . ' ' . $settings['phone'];
		}
		if ( ! empty( $settings['address'] ) ) {
			$lines[] = __( 'Address:', 'mvweb-data-export' ) . ' ' . $settings['address'];
		}
		if ( ! empty( $settings['messengers'] ) ) {
			$lines[] = __( 'Messengers:', 'mvweb-data-export' ) . ' ' . $settings['messengers'];
		}

		return array(
			'logo_path' => $logo_path,
			'title'     => isset( $settings['company'] ) ? $settings['company'] : '',
			'lines'     => $lines,
		);
	}

	/**
	 * Whether any column requires variation data.
	 *
	 * @since 1.1.0
	 * @param array $columns Column configuration.
	 * @return bool
	 */
	private function has_variation_column( array $columns ): bool {
		foreach ( $columns as $col ) {
			if ( isset( $col['source'] ) && 'variation' === $col['source'] ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Build a standard error result.
	 *
	 * @since 1.1.0
	 * @param string $message Error message.
	 * @return array
	 */
	private function error( string $message ): array {
		return array(
			'success' => false,
			'count'   => 0,
			'url'     => '',
			'error'   => $message,
		);
	}
}
