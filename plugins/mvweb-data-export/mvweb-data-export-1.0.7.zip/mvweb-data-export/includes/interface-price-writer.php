<?php
/**
 * Price writer interface for MVweb Data Export.
 *
 * Abstracts the output format of the price list. Implementations write the
 * collected data to a file. The rest of the price module is format-agnostic.
 *
 * @package MVweb_Data_Export
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Interface MVweb_DE_Price_Writer_Interface
 *
 * @since 1.1.0
 */
interface MVweb_DE_Price_Writer_Interface {

	/**
	 * Write the price list to a file.
	 *
	 * @since 1.1.0
	 * @param array  $header   Header block (all parts optional): 'logo_path' (absolute local image path),
	 *                         'title' (company name, rendered bold), 'lines' (array of ready-to-print
	 *                         contact strings, e.g. "Phone: ...").
	 * @param array  $columns  Ordered list of column configs; each has at least 'label' (header text) and
	 *                         'source'/'key' (used by writers for presentation, e.g. right-aligning price columns).
	 * @param array  $rows     Array of rows; each row is an ordered array of string values aligned to $columns.
	 * @param string $filepath Absolute target file path (writer handles atomic replace internally).
	 * @return bool True on success.
	 */
	public function write( array $header, array $columns, array $rows, string $filepath ): bool;

	/**
	 * Get the file extension produced by this writer (without dot).
	 *
	 * @since 1.1.0
	 * @return string E.g. 'xlsx', 'csv'.
	 */
	public function get_extension(): string;
}
