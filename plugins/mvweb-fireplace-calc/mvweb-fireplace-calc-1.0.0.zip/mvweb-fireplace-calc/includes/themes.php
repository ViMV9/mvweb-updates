<?php
/**
 * Frontend theme presets for MVweb Fireplace Calc.
 *
 * Each preset = a CSS modifier class on the form (`mvweb-fc--theme-{slug}`)
 * defined in `public/css/fireplace-calc-themes.css`. Themes never touch the
 * admin-controlled appearance properties (radius, border, button color) —
 * those stay user-controlled via the Appearance settings on the admin page.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default theme slug. The `default` theme uses only `fireplace-calc.css` and adds
 * no modifier class on the form — exact behavior as before themes existed.
 */
const MVWEB_FC_DEFAULT_THEME = 'default';

/**
 * Get the list of available theme presets.
 *
 * @since 1.0.0
 * @return array<string, array{label: string, description: string}>
 */
function mvweb_fc_get_themes(): array {
	return array(
		'default'   => array(
			'label'       => __( 'Default', 'mvweb-fireplace-calc' ),
			'description' => __( 'Minimal styles, inherits typography and colors from the active theme.', 'mvweb-fireplace-calc' ),
		),
		'shadcn'    => array(
			'label'       => __( 'shadcn', 'mvweb-fireplace-calc' ),
			'description' => __( 'Tight typography, segmented radio control on a soft surface.', 'mvweb-fireplace-calc' ),
		),
		'pico'      => array(
			'label'       => __( 'Pico', 'mvweb-fireplace-calc' ),
			'description' => __( 'Minimalist look with native radios and taller, mobile-friendly inputs.', 'mvweb-fireplace-calc' ),
		),
		'openprops' => array(
			'label'       => __( 'Open Props', 'mvweb-fireplace-calc' ),
			'description' => __( 'Soft shadows and a subtle gradient on the submit button.', 'mvweb-fireplace-calc' ),
		),
		'shoelace'  => array(
			'label'       => __( 'Shoelace', 'mvweb-fireplace-calc' ),
			'description' => __( 'Joined radio group, soft surface inputs that lift on hover.', 'mvweb-fireplace-calc' ),
		),
		'material'  => array(
			'label'       => __( 'Material 3', 'mvweb-fireplace-calc' ),
			'description' => __( 'Roboto typography, taller inputs and a pill-shaped submit button.', 'mvweb-fireplace-calc' ),
		),
		'bulma'     => array(
			'label'       => __( 'Bulma', 'mvweb-fireplace-calc' ),
			'description' => __( 'Classic look with inset input shadows and bold labels.', 'mvweb-fireplace-calc' ),
		),
		'halfmoon'  => array(
			'label'       => __( 'Halfmoon', 'mvweb-fireplace-calc' ),
			'description' => __( 'Dashboard-style with IBM Plex Sans and joined radios.', 'mvweb-fireplace-calc' ),
		),
		'tabler'    => array(
			'label'       => __( 'Tabler', 'mvweb-fireplace-calc' ),
			'description' => __( 'Inter typography, button-group radios and soft input shadows.', 'mvweb-fireplace-calc' ),
		),
		'daisyui'   => array(
			'label'       => __( 'DaisyUI', 'mvweb-fireplace-calc' ),
			'description' => __( 'Pill-shaped radios, outline focus state and uppercase submit.', 'mvweb-fireplace-calc' ),
		),
		'modern'    => array(
			'label'       => __( 'Modern', 'mvweb-fireplace-calc' ),
			'description' => __( 'Default look with subtle input shadows and a hover glow on the submit button.', 'mvweb-fireplace-calc' ),
		),
	);
}

/**
 * Validate a theme slug. Returns the slug if it's a registered theme, otherwise
 * returns the default theme slug.
 *
 * @since 1.0.0
 * @param string $slug Slug to validate.
 * @return string
 */
function mvweb_fc_validate_theme( string $slug ): string {
	$themes = mvweb_fc_get_themes();
	return array_key_exists( $slug, $themes ) ? $slug : MVWEB_FC_DEFAULT_THEME;
}
