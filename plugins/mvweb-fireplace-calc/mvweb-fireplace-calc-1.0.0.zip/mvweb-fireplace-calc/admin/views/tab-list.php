<?php
/**
 * List tab — table of registered calculators with their shortcodes.
 *
 * Uses MVweb Admin UI Kit (slate palette, Yoast-style layout).
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$calculators = MVweb_FC_Registry::all();

// Count calculators per hub for the group header badges.
// Registry::all() already returns the list sorted by hub then title, so the
// group header can be emitted inline whenever the hub slug changes.
$hub_counts = array();
foreach ( $calculators as $calc ) {
	$hub                = (string) ( $calc['hub'] ?? '' );
	$hub_counts[ $hub ] = ( $hub_counts[ $hub ] ?? 0 ) + 1;
}
$current_hub = null;
?>

<div class="mvweb-block mvweb-fc-list">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Registered Calculators', 'mvweb-fireplace-calc' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Copy a shortcode and paste it on any page, post or widget to render a calculator on the frontend.', 'mvweb-fireplace-calc' ); ?></p>

	<?php if ( array() === $calculators ) : ?>
		<div class="mvweb-empty">
			<div class="mvweb-empty__icon" aria-hidden="true">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" focusable="false">
					<rect x="3" y="3" width="18" height="18" rx="2"/>
					<line x1="9" y1="9" x2="15" y2="15"/>
					<line x1="15" y1="9" x2="9" y2="15"/>
				</svg>
			</div>
			<h3 class="mvweb-empty__title"><?php esc_html_e( 'No calculators yet', 'mvweb-fireplace-calc' ); ?></h3>
			<p class="mvweb-empty__text">
				<?php esc_html_e( 'Add one in the calculators/ folder — a single PHP file with mvweb_fc_register() call is enough.', 'mvweb-fireplace-calc' ); ?>
			</p>
		</div>
	<?php else : ?>
		<div class="mvweb-table-wrap">
		<table class="mvweb-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Title', 'mvweb-fireplace-calc' ); ?></th>
					<th><?php esc_html_e( 'Shortcode', 'mvweb-fireplace-calc' ); ?></th>
					<th><?php esc_html_e( 'Description', 'mvweb-fireplace-calc' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $calculators as $slug => $calc ) : ?>
					<?php
					$shortcode      = sprintf( '[mvweb_fcalc id="%s"]', $slug );
					$formula        = (string) ( $calc['formula'] ?? '' );
					$legend         = isset( $calc['legend'] ) && is_array( $calc['legend'] ) ? $calc['legend'] : array();
					$formula_dialog = 'mvweb-fc-formula-' . $slug;
					$hub            = (string) ( $calc['hub'] ?? '' );
					?>
					<?php if ( $hub !== $current_hub ) : ?>
						<?php $current_hub = $hub; ?>
						<tr class="mvweb-fc-list__group">
							<th colspan="3" scope="colgroup">
								<?php echo esc_html( mvweb_fc_hub_label( $hub ) ); ?>
								<span class="mvweb-badge mvweb-badge--info"><?php echo esc_html( (string) ( $hub_counts[ $hub ] ?? 0 ) ); ?></span>
							</th>
						</tr>
					<?php endif; ?>
					<tr>
						<td><strong><?php echo esc_html( (string) $calc['title'] ); ?></strong></td>
						<td>
							<div class="mvweb-fc-copy-wrap">
								<input
									type="text"
									class="mvweb-fc-copy-input"
									value="<?php echo esc_attr( $shortcode ); ?>"
									readonly
									aria-label="<?php esc_attr_e( 'Click to copy shortcode', 'mvweb-fireplace-calc' ); ?>"
								/>
								<span class="mvweb-fc-copy-popover" role="status" aria-live="polite" hidden>
									<svg class="mvweb-fc-copy-popover__icon" xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
										<circle cx="12" cy="12" r="10"/>
										<polyline points="9 12 11 14 15 10"/>
									</svg>
									<span class="mvweb-fc-copy-popover__text"><?php esc_html_e( 'Copied', 'mvweb-fireplace-calc' ); ?></span>
								</span>
							</div>
						</td>
						<td>
							<?php echo esc_html( (string) ( $calc['description'] ?? '' ) ); ?>
							<?php if ( '' !== $formula ) : ?>
								<button
									type="button"
									class="mvweb-help-tip mvweb-fc-help-btn"
									aria-label="<?php esc_attr_e( 'Show formula', 'mvweb-fireplace-calc' ); ?>"
									title="<?php esc_attr_e( 'Show formula', 'mvweb-fireplace-calc' ); ?>"
									data-mvweb-fc-open-dialog="<?php echo esc_attr( $formula_dialog ); ?>"
								>
									<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">
										<circle cx="12" cy="12" r="10"/>
										<path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/>
										<line x1="12" y1="17" x2="12.01" y2="17"/>
									</svg>
								</button>

								<dialog id="<?php echo esc_attr( $formula_dialog ); ?>" class="mvweb-dialog mvweb-fc-formula-dialog" role="dialog" aria-modal="true">
									<div class="mvweb-dialog__head">
										<h3><?php echo esc_html( (string) $calc['title'] ); ?></h3>
										<span class="mvweb-badge mvweb-badge--info">v<?php echo esc_html( MVWEB_FC_VERSION ); ?></span>
									</div>
									<div class="mvweb-dialog__body">
										<p class="mvweb-dialog__sub">// fireplace-calc · <?php echo esc_html( $slug ); ?></p>
										<div class="mvweb-codeblock"><?php echo mvweb_fc_highlight_formula( $formula ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- mvweb_fc_highlight_formula escapes its output. ?></div>

										<?php if ( array() !== $legend ) : ?>
											<div class="mvweb-params">
												<?php foreach ( $legend as $symbol => $meaning ) : ?>
													<div class="mvweb-params__row">
														<span class="mvweb-params__sym"><?php echo esc_html( (string) $symbol ); ?></span>
														<span><?php echo esc_html( (string) $meaning ); ?></span>
													</div>
												<?php endforeach; ?>
											</div>
										<?php endif; ?>
									</div>
									<div class="mvweb-dialog__foot">
										<button type="button" class="mvweb-btn" data-mvweb-fc-close-dialog>
											<?php esc_html_e( 'Close', 'mvweb-fireplace-calc' ); ?> <kbd>esc</kbd>
										</button>
									</div>
								</dialog>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		</div>
	<?php endif; ?>
</div>
