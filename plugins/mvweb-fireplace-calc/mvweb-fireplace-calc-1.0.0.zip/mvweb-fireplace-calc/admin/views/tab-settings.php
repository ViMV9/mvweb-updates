<?php
/**
 * Settings tab — plugin-wide formatting and appearance options.
 *
 * Uses MVweb Admin UI Kit (slate palette, Yoast-style layout).
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<form method="post" action="options.php">
	<?php settings_fields( MVweb_FC_Admin::SETTINGS_GROUP ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'General Settings', 'mvweb-fireplace-calc' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Configure number formatting for calculator results.', 'mvweb-fireplace-calc' ); ?></p>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_FC_Admin::OPTION_NAME . '-decimals' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Decimal places', 'mvweb-fireplace-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_FC_Admin::render_field_number( 'decimals', 0, 6 ); ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Number of digits shown after the decimal separator (0–6).', 'mvweb-fireplace-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_FC_Admin::OPTION_NAME . '-decimal_sep' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Decimal separator', 'mvweb-fireplace-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_FC_Admin::render_field_short_text( 'decimal_sep' ); ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Character used between integer and fractional parts.', 'mvweb-fireplace-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_FC_Admin::OPTION_NAME . '-thousands_sep' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Thousands separator', 'mvweb-fireplace-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_FC_Admin::render_field_short_text( 'thousands_sep' ); ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Character grouping thousands. Default is a no-break space (U+00A0).', 'mvweb-fireplace-calc' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Appearance', 'mvweb-fireplace-calc' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Pick a frontend theme, then fine-tune borders, corners and the submit button. Leave colors empty to inherit from the active theme.', 'mvweb-fireplace-calc' ); ?></p>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_FC_Admin::OPTION_NAME . '-theme' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Theme preset', 'mvweb-fireplace-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_FC_Admin::render_field_theme(); ?>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_FC_Admin::OPTION_NAME . '-border_radius' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Corner rounding', 'mvweb-fireplace-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_FC_Admin::render_field_number( 'border_radius', 0, 32 ); ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Radius in pixels. Set to 0 for square corners.', 'mvweb-fireplace-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_FC_Admin::OPTION_NAME . '-border_color' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Border color', 'mvweb-fireplace-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_FC_Admin::render_field_color( 'border_color' ); ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Leave empty to inherit the current text color of the theme.', 'mvweb-fireplace-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_FC_Admin::OPTION_NAME . '-border_width' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Border thickness', 'mvweb-fireplace-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_FC_Admin::render_field_number( 'border_width', 0, 6 ); ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Pixels. Set to 0 to hide all borders on inputs and result box.', 'mvweb-fireplace-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_FC_Admin::OPTION_NAME . '-form_border' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Form border', 'mvweb-fireplace-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_FC_Admin::render_field_form_border(); ?>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label">
				<?php esc_html_e( 'Button style', 'mvweb-fireplace-calc' ); ?>
			</span>
			<div class="mvweb-form-row__field">
				<?php MVweb_FC_Admin::render_field_button_variant(); ?>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_FC_Admin::OPTION_NAME . '-button_color' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Button color', 'mvweb-fireplace-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_FC_Admin::render_field_color( 'button_color' ); ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Leave empty to inherit the current text color of the theme.', 'mvweb-fireplace-calc' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Save Changes', 'mvweb-fireplace-calc' ); ?>
		</button>
	</div>
</form>
