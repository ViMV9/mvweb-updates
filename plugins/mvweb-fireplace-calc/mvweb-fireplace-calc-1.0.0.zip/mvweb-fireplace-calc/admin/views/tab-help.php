<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit (slate palette, Yoast-style layout).
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick Start', 'mvweb-fireplace-calc' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Three steps to embed a calculator on the site.', 'mvweb-fireplace-calc' ); ?></p>

	<ol class="mvweb-steps">
		<li>
			<div>
				<strong><?php esc_html_e( 'Pick a calculator', 'mvweb-fireplace-calc' ); ?></strong>
				<p><?php esc_html_e( 'Open the Calculators tab and copy the shortcode of the one you need.', 'mvweb-fireplace-calc' ); ?></p>
			</div>
		</li>
		<li>
			<div>
				<strong><?php esc_html_e( 'Paste the shortcode', 'mvweb-fireplace-calc' ); ?></strong>
				<p><?php esc_html_e( 'Paste [mvweb_fcalc id="..."] on any page, post or widget. The calculator will render automatically on the frontend.', 'mvweb-fireplace-calc' ); ?></p>
			</div>
		</li>
		<li>
			<div>
				<strong><?php esc_html_e( 'Adjust formatting (optional)', 'mvweb-fireplace-calc' ); ?></strong>
				<p><?php esc_html_e( 'Open the Settings tab to change decimal places, number separators or the accent color.', 'mvweb-fireplace-calc' ); ?></p>
			</div>
		</li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Features', 'mvweb-fireplace-calc' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'What the plugin can do.', 'mvweb-fireplace-calc' ); ?></p>
	<ul class="mvweb-fc-features">
		<li><?php esc_html_e( 'A library of ready-to-use construction calculators — paste a single shortcode anywhere on the site.', 'mvweb-fireplace-calc' ); ?></li>
		<li><?php esc_html_e( 'Calculations run on the server, the result is shown without page reload.', 'mvweb-fireplace-calc' ); ?></li>
		<li><?php esc_html_e( 'Automatic result formatting with configurable decimal places, separators and accent color.', 'mvweb-fireplace-calc' ); ?></li>
		<li><?php esc_html_e( 'Inline hints — context-specific recommendations next to the result.', 'mvweb-fireplace-calc' ); ?></li>
		<li><?php esc_html_e( 'Full English and Russian (ru_RU) localization out of the box.', 'mvweb-fireplace-calc' ); ?></li>
	</ul>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-fireplace-calc' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Short answers to recurring questions.', 'mvweb-fireplace-calc' ); ?></p>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Where do I get a shortcode?', 'mvweb-fireplace-calc' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Open the Calculators tab — every registered calculator has its own shortcode. Click the shortcode field to copy it to the clipboard.', 'mvweb-fireplace-calc' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Where can I place the shortcode?', 'mvweb-fireplace-calc' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Any page, post or widget that accepts shortcodes — including the block editor (use a Shortcode block) and classic editor.', 'mvweb-fireplace-calc' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How do I change the accent color or number format?', 'mvweb-fireplace-calc' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'All formatting and color options live on the Settings tab of this plugin.', 'mvweb-fireplace-calc' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'I need a new calculator that is not in the list. How can I get one?', 'mvweb-fireplace-calc' ); ?></summary>
		<div class="mvweb-faq__body">
			<p>
				<?php
				echo wp_kses(
					sprintf(
						/* translators: %s: MVweb support link */
						__( 'New calculators are added by the MVweb studio with a plugin update. Send your request to %s and we will add it in the next release.', 'mvweb-fireplace-calc' ),
						'<a href="' . esc_url( 'https://mvweb.ru/plugins/mvweb-fireplace-calc' ) . '" target="_blank" rel="noopener noreferrer">mvweb.ru</a>'
					),
					array(
						'a' => array(
							'href'   => array(),
							'target' => array(),
							'rel'    => array(),
						),
					)
				);
				?>
			</p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-fireplace-calc' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php
		echo wp_kses(
			sprintf(
				/* translators: %s: MVweb plugin URL */
				__( 'Need help? Visit %s for documentation and support.', 'mvweb-fireplace-calc' ),
				'<a href="' . esc_url( 'https://mvweb.ru/plugins/mvweb-fireplace-calc' ) . '" target="_blank" rel="noopener noreferrer">mvweb.ru</a>'
			),
			array(
				'a' => array(
					'href'   => array(),
					'target' => array(),
					'rel'    => array(),
				),
			)
		);
		?>
	</p>
	<p>
		<strong><?php esc_html_e( 'Version:', 'mvweb-fireplace-calc' ); ?></strong>
		<code><?php echo esc_html( MVWEB_FC_VERSION ); ?></code>
	</p>
</div>
