<?php
/**
 * Calculator: stove heating area from mirror (radiating) surface.
 *
 * Formula:
 *   Q  = mirror_area × 350       (heat output, W)
 *   S  = Q / 100                 (heated area, m²; norm 100 W/m² = 1 kW/10 m²)
 *
 * The "mirror" (зеркало печи) is the total outer radiating surface area
 * of a masonry stove. Specific heat emission of a brick stove surface
 * is approximately 350 W/m² at normal firing mode.
 *
 * Source: Bubnov V.A. "Stoves and fireplaces" (2011),
 * SNiP 41-01-2003 "Heating, ventilation and air conditioning".
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'stove-heating-area',
	array(
		'title'       => __( 'Stove heating area', 'mvweb-fireplace-calc' ),
		'hub'         => 'heating',
		'description' => __( 'Estimates the floor area a masonry stove can heat based on its outer radiating (mirror) surface.', 'mvweb-fireplace-calc' ),
		'formula'     => 'S = (mirror × 350) / 100',
		'legend'      => array(
			'S'      => __( 'heated area, m²', 'mvweb-fireplace-calc' ),
			'mirror' => __( 'stove mirror (radiating surface), m²', 'mvweb-fireplace-calc' ),
			'350'    => __( 'specific heat emission of brick surface, W/m²', 'mvweb-fireplace-calc' ),
			'100'    => __( 'heating norm, W/m² of floor area', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Heated floor area', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'mirror_area' => array(
				'type'     => 'number',
				'label'    => __( 'Stove mirror area', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
				'min'      => 0.5,
				'max'      => 20,
				'step'     => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$mirror = (float) ( $i['mirror_area'] ?? 0 );

			$heat_w  = $mirror * 350;
			$heat_kw = $heat_w / 1000;
			$area    = $heat_w / 100;

			$hints = array();

			/* translators: %s — stove power in kW */
			$hints[] = sprintf(
				__( 'Estimated stove output: %.1f kW (%.0f W).', 'mvweb-fireplace-calc' ),
				$heat_kw,
				$heat_w
			);

			if ( $mirror < 2 ) {
				$hints[] = __( 'A small stove surface is suitable for heating a single room or a bathroom. Consider a larger stove for open-plan spaces.', 'mvweb-fireplace-calc' );
			}

			/* translators: %1$.1f — heated area */
			$hints[] = sprintf(
				__( 'This stove covers approximately %.1f m² — check our catalog for brick stove projects of matching capacity.', 'mvweb-fireplace-calc' ),
				$area
			);

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
