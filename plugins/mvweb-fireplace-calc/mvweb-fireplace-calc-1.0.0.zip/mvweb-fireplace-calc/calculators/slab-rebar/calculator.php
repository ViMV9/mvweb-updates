<?php
/**
 * Calculator: total rebar length for slab reinforcement.
 *
 * Formula (per layer):
 *   bars_along = floor(width  / step) + 1
 *   bars_across = floor(length / step) + 1
 *   total = (bars_along × length + bars_across × width) × layers
 * Result in linear metres before lap-splice allowance.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'slab-rebar',
	array(
		'title'       => __( 'Slab reinforcement', 'mvweb-fireplace-calc' ),
		'hub'         => 'foundation',
		'description' => __( 'Calculates the total linear metres of rebar required for a two-way mesh reinforcement of a concrete slab.', 'mvweb-fireplace-calc' ),
		'formula'     => 'bars_along = ⌊W / step⌋ + 1;  bars_across = ⌊L / step⌋ + 1;  total = (bars_along × L + bars_across × W) × layers',
		'legend'      => array(
			'L'      => __( 'slab length, m', 'mvweb-fireplace-calc' ),
			'W'      => __( 'slab width, m', 'mvweb-fireplace-calc' ),
			'step'   => __( 'mesh cell size, m', 'mvweb-fireplace-calc' ),
			'layers' => __( 'number of reinforcement layers', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Total rebar length', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'length'    => array(
				'type'     => 'number',
				'label'    => __( 'Slab length', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.5,
				'max'      => 15,
				'step'     => 0.1,
				'required' => true,
			),
			'width'     => array(
				'type'     => 'number',
				'label'    => __( 'Slab width', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.5,
				'max'      => 15,
				'step'     => 0.1,
				'required' => true,
			),
			'mesh_step' => array(
				'type'     => 'number',
				'label'    => __( 'Mesh cell size', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'mm', 'mvweb-fireplace-calc' ),
				'min'      => 100,
				'max'      => 300,
				'step'     => 25,
				'default'  => 200,
				'required' => true,
			),
			'layers'    => array(
				'type'       => 'radio',
				'label'      => __( 'Reinforcement layers', 'mvweb-fireplace-calc' ),
				'default'    => '1',
				'full_width' => true,
				'options'    => array(
					'1' => __( '1 layer (light slab)', 'mvweb-fireplace-calc' ),
					'2' => __( '2 layers (heavy load)', 'mvweb-fireplace-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$length    = (float) ( $i['length'] ?? 0 );
			$width     = (float) ( $i['width'] ?? 0 );
			$mesh_mm   = (float) ( $i['mesh_step'] ?? 200 );
			$layers    = (int) ( $i['layers'] ?? 1 );

			$step = $mesh_mm / 1000.0;

			$bars_along  = (int) floor( $width / $step ) + 1;
			$bars_across = (int) floor( $length / $step ) + 1;

			$total = ( $bars_along * $length + $bars_across * $width ) * $layers;

			$hints = array();

			$hints[] = __( 'Add 10–15% to the calculated length for lap splices where rebar sections overlap.', 'mvweb-fireplace-calc' );

			if ( $layers > 1 ) {
				$hints[] = __( 'Use rebar chairs (spacers) between layers to maintain the design gap and ensure proper concrete cover.', 'mvweb-fireplace-calc' );
			}

			/* translators: %1$.1f — total rebar length with lap allowance */
			$hints[] = sprintf(
				__( 'With a 12%% lap-splice allowance order approximately %.1f m — we will help you choose the right barbecue complex to fit your slab.', 'mvweb-fireplace-calc' ),
				$total * 1.12
			);

			return array(
				'value' => $total,
				'hints' => $hints,
			);
		},
	)
);
