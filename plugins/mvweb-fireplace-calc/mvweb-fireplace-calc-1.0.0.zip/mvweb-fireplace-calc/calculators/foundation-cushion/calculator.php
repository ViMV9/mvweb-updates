<?php
/**
 * Calculator: sand and gravel cushion volume under a foundation.
 *
 * Formula:
 *   V_sand   = area × sand_thickness
 *   V_gravel = area × gravel_thickness
 *   V_total  = V_sand + V_gravel
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'foundation-cushion',
	array(
		'title'       => __( 'Sand and gravel cushion', 'mvweb-fireplace-calc' ),
		'hub'         => 'foundation',
		'description' => __( 'Calculates the total volume of the sand-and-gravel bedding layer placed under a foundation slab or pad.', 'mvweb-fireplace-calc' ),
		'formula'     => 'V = area × (sand_thickness + gravel_thickness)',
		'legend'      => array(
			'V'               => __( 'total cushion volume, m³', 'mvweb-fireplace-calc' ),
			'area'            => __( 'foundation footprint area, m²', 'mvweb-fireplace-calc' ),
			'sand_thickness'  => __( 'sand layer thickness, m', 'mvweb-fireplace-calc' ),
			'gravel_thickness' => __( 'gravel layer thickness, m', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Total cushion volume', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'm³', 'mvweb-fireplace-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'area'             => array(
				'type'     => 'number',
				'label'    => __( 'Foundation footprint area', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
				'min'      => 0.5,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'sand_thickness'   => array(
				'type'    => 'number',
				'label'   => __( 'Sand layer thickness', 'mvweb-fireplace-calc' ),
				'unit'    => __( 'm', 'mvweb-fireplace-calc' ),
				'min'     => 0,
				'max'     => 0.5,
				'step'    => 0.01,
				'default' => 0.15,
			),
			'gravel_thickness' => array(
				'type'    => 'number',
				'label'   => __( 'Gravel layer thickness', 'mvweb-fireplace-calc' ),
				'unit'    => __( 'm', 'mvweb-fireplace-calc' ),
				'min'     => 0,
				'max'     => 0.5,
				'step'    => 0.01,
				'default' => 0.15,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area    = (float) ( $i['area'] ?? 0 );
			$sand    = (float) ( $i['sand_thickness'] ?? 0.15 );
			$gravel  = (float) ( $i['gravel_thickness'] ?? 0.15 );

			$v_sand   = $area * $sand;
			$v_gravel = $area * $gravel;
			$v_total  = $v_sand + $v_gravel;

			$hints = array();

			if ( $sand > 0 ) {
				/* translators: %1$.2f — sand volume */
				$hints[] = sprintf(
					__( 'Sand layer: %.2f m³ — use coarse washed sand; compact in 50–100 mm lifts.', 'mvweb-fireplace-calc' ),
					$v_sand
				);
			}

			if ( $gravel > 0 ) {
				/* translators: %1$.2f — gravel volume */
				$hints[] = sprintf(
					__( 'Gravel layer: %.2f m³ — use crushed stone fraction 20–40 mm; compact thoroughly before pouring concrete.', 'mvweb-fireplace-calc' ),
					$v_gravel
				);
			}

			$hints[] = __( 'A well-compacted cushion improves drainage, reduces frost heave, and provides a level working surface — contact us to plan your stove or barbecue complex.', 'mvweb-fireplace-calc' );

			return array(
				'value' => $v_total,
				'hints' => $hints,
			);
		},
	)
);
