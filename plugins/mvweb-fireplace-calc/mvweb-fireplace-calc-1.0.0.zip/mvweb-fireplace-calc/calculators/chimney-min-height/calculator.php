<?php
/**
 * Calculator: minimum total chimney height for stable draft.
 *
 * Formula: H_min = max( 5, H_input ) (m)
 * The minimum 5 m from grate to chimney outlet is required to develop
 * sufficient natural draft (pressure differential ≥ 10 Pa).
 *
 * Source: SP 7.13130.2013 section 5.5; SNiP 41-01-2003 appendix G.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'chimney-min-height',
	array(
		'title'       => __( 'Minimum chimney height', 'mvweb-fireplace-calc' ),
		'hub'         => 'chimney',
		'description' => __( 'Determines the minimum total chimney height from the grate to the outlet needed for stable natural draft.', 'mvweb-fireplace-calc' ),
		'formula'     => 'H_min = max( 5, H_input ) (m)',
		'legend'      => array(
			'H_input' => __( 'actual chimney height from grate to outlet, m', 'mvweb-fireplace-calc' ),
			'H_min'   => __( 'recommended minimum chimney height, m', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended minimum height', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'roof_to_grate' => array(
				'type'     => 'number',
				'label'    => __( 'Chimney height (grate to outlet)', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 1,
				'max'      => 15,
				'step'     => 0.1,
				'required' => true,
				'default'  => 5,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$actual  = (float) ( $i['roof_to_grate'] ?? 0 );
			$minimum = 5.0;
			$result  = max( $minimum, $actual );

			$hints = array();

			if ( $actual < $minimum ) {
				$hints[] = sprintf(
					__( 'The entered height (%.1f m) is below the 5 m norm. Increase the chimney height by at least %.1f m to achieve stable draft. A short chimney causes backdraft and smoke ingress.', 'mvweb-fireplace-calc' ),
					$actual,
					$minimum - $actual
				);
			} else {
				$hints[] = sprintf(
					__( 'The chimney height of %.1f m meets the 5 m minimum. For high-output appliances (> 30 kW), a height of 6–8 m is recommended for optimal draft.', 'mvweb-fireplace-calc' ),
					$actual
				);
			}

			return array(
				'value' => $result,
				'hints' => $hints,
			);
		},
	)
);
