<?php
/**
 * Calculator: minimum chimney height above roof ridge.
 *
 * Rules per SP 7.13130.2013 section 5.6 and SNiP 41-01-2003:
 *   - horizontal distance to ridge ≤ 1.5 m  → chimney top ≥ 0.5 m above ridge;
 *   - horizontal distance 1.5–3.0 m          → chimney top ≥ ridge level (0 m);
 *   - horizontal distance > 3.0 m            → chimney top ≥ line drawn 10° downward
 *                                               from ridge (h = (d − 3) × tan(10°)).
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'chimney-height-ridge',
	array(
		'title'       => __( 'Chimney height above ridge', 'mvweb-fireplace-calc' ),
		'hub'         => 'chimney',
		'description' => __( 'Calculates the minimum chimney height above the roof ridge according to SP 7.13130.2013 fire and ventilation norms.', 'mvweb-fireplace-calc' ),
		'formula'     => 'd ≤ 1.5 m → h ≥ 0.5 m; 1.5–3 m → h ≥ 0 m; d > 3 m → h ≥ (d − 3) × tan(10°)',
		'legend'      => array(
			'd' => __( 'horizontal distance from chimney to ridge, m', 'mvweb-fireplace-calc' ),
			'h' => __( 'minimum height of chimney top above ridge level, m', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Min. height above ridge', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'distance_to_ridge' => array(
				'type'     => 'number',
				'label'    => __( 'Horizontal distance to ridge', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0,
				'max'      => 15,
				'step'     => 0.1,
				'required' => true,
				'default'  => 1.5,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$distance = (float) ( $i['distance_to_ridge'] ?? 0 );

			$hints = array();

			if ( $distance <= 1.5 ) {
				$min_height = 0.5;
				$hints[]    = __( 'Distance to ridge ≤ 1.5 m: the chimney top must be at least 0.5 m above the ridge. This ensures the chimney clears wind turbulence created by the roof peak.', 'mvweb-fireplace-calc' );
			} elseif ( $distance <= 3.0 ) {
				$min_height = 0.0;
				$hints[]    = __( 'Distance to ridge 1.5–3.0 m: the chimney top must be at no lower than ridge level. Raising it slightly above the ridge improves draft stability.', 'mvweb-fireplace-calc' );
			} else {
				$min_height = ( $distance - 3.0 ) * tan( deg2rad( 10.0 ) );
				$hints[]    = sprintf(
					__( 'Distance to ridge > 3.0 m: the chimney top must be at least %.2f m above the horizontal line of the ridge (10° slope rule). Verify the outlet clears the roof surface.', 'mvweb-fireplace-calc' ),
					$min_height
				);
			}

			$hints[] = __( 'Always add a spark arrestor and rain cap. Confirm final height with a licensed chimney installer.', 'mvweb-fireplace-calc' );

			return array(
				'value' => $min_height,
				'hints' => $hints,
			);
		},
	)
);
