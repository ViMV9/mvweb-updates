<?php
/**
 * Calculator: chimney diameter by heating appliance power.
 *
 * Formula: S = power × 8 (cm²); D = sqrt( 4 × S / π ) → mm
 * Nearest standard diameter selected from: 115, 130, 150, 180, 200 mm.
 *
 * Source: SP 7.13130.2013 "Heating, ventilation and air conditioning.
 * Fire safety requirements", section 5.4 — flue cross-section sizing.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'chimney-diameter',
	array(
		'title'       => __( 'Chimney diameter', 'mvweb-fireplace-calc' ),
		'hub'         => 'chimney',
		'description' => __( 'Calculates the required chimney inner diameter based on the heating appliance power.', 'mvweb-fireplace-calc' ),
		'formula'     => 'S = P × 8 (cm²); D = sqrt( 4 × S / π ) (mm)',
		'legend'      => array(
			'S' => __( 'chimney cross-section area, cm²', 'mvweb-fireplace-calc' ),
			'P' => __( 'appliance power, kW', 'mvweb-fireplace-calc' ),
			'D' => __( 'inner diameter, mm', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Required inner diameter', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'mm', 'mvweb-fireplace-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'power' => array(
				'type'     => 'number',
				'label'    => __( 'Appliance power', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'kW', 'mvweb-fireplace-calc' ),
				'min'      => 1,
				'max'      => 100,
				'step'     => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$power = (float) ( $i['power'] ?? 0 );

			$area     = $power * 8.0;
			$diameter = sqrt( 4.0 * $area / M_PI ) * 10.0;

			$standards = array( 115, 130, 150, 180, 200 );
			$nearest   = $standards[0];
			foreach ( $standards as $std ) {
				if ( $std >= $diameter ) {
					$nearest = $std;
					break;
				}
				$nearest = $std;
			}

			$hints = array();

			$hints[] = sprintf(
				__( 'Calculated cross-section: %.1f cm². Nearest standard diameter: %d mm. Use the standard size for off-the-shelf chimney sections.', 'mvweb-fireplace-calc' ),
				$area,
				$nearest
			);

			if ( $diameter > 200 ) {
				$hints[] = __( 'The required diameter exceeds 200 mm. Consider a rectangular flue or consult a specialist for a custom design.', 'mvweb-fireplace-calc' );
			}

			return array(
				'value' => round( $diameter ),
				'hints' => $hints,
			);
		},
	)
);
