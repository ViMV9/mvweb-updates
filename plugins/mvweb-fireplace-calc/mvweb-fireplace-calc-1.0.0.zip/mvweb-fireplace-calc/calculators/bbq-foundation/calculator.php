<?php
/**
 * Calculator: foundation concrete volume for a barbecue complex.
 *
 * Formula:
 *   D_eff = D × 1.3  (heaving soil only)
 *   V = (L + 0.10) × (W + 0.10) × D_eff
 * The +0.10 m adds the required 5 cm overhang per side.
 * Heaving-soil correction per SP 22.13330.2016 §5.5.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'bbq-foundation',
	array(
		'title'       => __( 'Foundation for a barbecue', 'mvweb-fireplace-calc' ),
		'hub'         => 'foundation',
		'description' => __( 'Calculates the concrete volume for a monolithic pad foundation under a barbecue or outdoor kitchen complex. On heaving soils the required depth is increased by 30%.', 'mvweb-fireplace-calc' ),
		'formula'     => 'V = (L + 0.10) × (W + 0.10) × D  |  D × 1.3 on heaving soil',
		'legend'      => array(
			'V' => __( 'concrete volume, m³', 'mvweb-fireplace-calc' ),
			'L' => __( 'complex length, m', 'mvweb-fireplace-calc' ),
			'W' => __( 'complex width, m', 'mvweb-fireplace-calc' ),
			'D' => __( 'foundation depth, m', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Concrete volume', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'm³', 'mvweb-fireplace-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'complex_length' => array(
				'type'     => 'number',
				'label'    => __( 'Complex length', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.5,
				'max'      => 5,
				'step'     => 0.05,
				'required' => true,
			),
			'complex_width'  => array(
				'type'     => 'number',
				'label'    => __( 'Complex width', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.3,
				'max'      => 3,
				'step'     => 0.05,
				'required' => true,
			),
			'depth'          => array(
				'type'     => 'number',
				'label'    => __( 'Foundation depth', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.2,
				'max'      => 1.0,
				'step'     => 0.05,
				'default'  => 0.4,
				'required' => true,
			),
			'soil'           => array(
				'type'       => 'radio',
				'label'      => __( 'Soil type', 'mvweb-fireplace-calc' ),
				'default'    => 'normal',
				'full_width' => true,
				'options'    => array(
					'normal'  => __( 'Normal (non-heaving)', 'mvweb-fireplace-calc' ),
					'heaving' => __( 'Heaving (frost-susceptible)', 'mvweb-fireplace-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$length = (float) ( $i['complex_length'] ?? 0 );
			$width  = (float) ( $i['complex_width'] ?? 0 );
			$depth  = (float) ( $i['depth'] ?? 0.4 );
			$soil   = (string) ( $i['soil'] ?? 'normal' );

			if ( 'heaving' === $soil ) {
				$depth *= 1.3;
			}

			$found_length = $length + 0.10;
			$found_width  = $width + 0.10;
			$volume       = $found_length * $found_width * $depth;

			$hints = array();

			if ( 'heaving' === $soil ) {
				$hints[] = __( 'On heaving (frost-susceptible) soils the foundation depth is increased by 30%. Consider extending below the local frost line for full protection.', 'mvweb-fireplace-calc' );
			}

			$hints[] = __( 'Lay a 150 mm compacted sand-and-gravel cushion under the pad to improve drainage and reduce frost heave.', 'mvweb-fireplace-calc' );

			/* translators: %1$.2f — effective depth used in calculation */
			$hints[] = sprintf(
				__( 'Effective depth used: %.2f m — browse our barbecue complexes to find the right fit.', 'mvweb-fireplace-calc' ),
				$depth
			);

			return array(
				'value' => $volume,
				'hints' => $hints,
			);
		},
	)
);
