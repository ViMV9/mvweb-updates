<?php
/**
 * Calculator: pre-furnace floor protection sheet (предтопочный лист).
 *
 * Formula: sheet_width = firebox_width + 2 × 0.15 m (side margins), min 0.5 m.
 * Sheet depth (projection forward) = fixed 0.5 m per SP 7.13130.2020 clause 6.9.
 *
 * SP 7.13130.2020 clause 6.9 requirements:
 *   - Minimum sheet size: 500 × 700 mm (width × depth from door).
 *   - Sheet must extend at least 500 mm in front of the firebox door.
 *   - Side margins: at least 150 mm on each side of the door opening.
 *   - Material: steel sheet ≥ 1.5 mm on non-combustible (asbestos-free) underlayer.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'hearth-pad',
	array(
		'title'       => __( 'Pre-furnace floor sheet (предтопочный лист)', 'mvweb-fireplace-calc' ),
		'hub'         => 'safety',
		'description' => __( 'Calculates the required width of the metal protection sheet in front of a firebox door per SP 7.13130.2020 clause 6.9.', 'mvweb-fireplace-calc' ),
		'formula'     => 'W_sheet = max( firebox_width + 2 × 150 mm, 500 mm );  D_sheet = 500 mm (fixed)',
		'legend'      => array(
			'W_sheet'       => __( 'required sheet width, m', 'mvweb-fireplace-calc' ),
			'firebox_width' => __( 'width of firebox door / portal opening, m', 'mvweb-fireplace-calc' ),
			'D_sheet'       => __( 'sheet depth (projection in front of door) = 0.5 m (fixed by norm)', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Required sheet width', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'firebox_width' => array(
				'type'     => 'number',
				'label'    => __( 'Firebox door / portal width', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.2,
				'max'      => 2.0,
				'step'     => 0.05,
				'default'  => 0.4,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$firebox_width = (float) ( $i['firebox_width'] ?? 0.4 );

			$side_margin  = 0.15;
			$sheet_depth  = 0.5;
			$min_width    = 0.5;

			$sheet_width = $firebox_width + 2.0 * $side_margin;
			$sheet_width = max( $sheet_width, $min_width );

			$width_mm = (int) round( $sheet_width * 1000 );
			$depth_mm = (int) round( $sheet_depth * 1000 );

			$hints = array();

			$hints[] = sprintf(
				__( 'Required sheet size: %d × %d mm (W × D). Depth of %d mm is fixed by SP 7.13130 clause 6.9.', 'mvweb-fireplace-calc' ),
				$width_mm,
				$depth_mm,
				$depth_mm
			);

			$hints[] = __( 'Material: steel sheet ≥ 1.5 mm on a non-combustible base (calcium silicate or fire-rated gypsum board). Do not use asbestos-containing underlayers.', 'mvweb-fireplace-calc' );

			if ( $sheet_width <= $min_width ) {
				$hints[] = __( 'Sheet width is at the minimum norm value of 500 mm — the firebox opening is narrow. Verify actual door dimensions before ordering sheet metal.', 'mvweb-fireplace-calc' );
			}

			return array(
				'value' => round( $sheet_width, 2 ),
				'hints' => $hints,
			);
		},
	)
);
