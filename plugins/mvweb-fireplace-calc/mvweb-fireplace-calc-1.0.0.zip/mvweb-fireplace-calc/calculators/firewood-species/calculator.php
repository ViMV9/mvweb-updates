<?php
/**
 * Calculator: firewood volume correction by species and moisture.
 *
 * Formula: V_adjusted = base_volume / species_factor × moisture_factor
 * Species factors (relative to birch = 1.0): oak 1.15, pine 0.85, aspen 0.75.
 * Moisture factor: dry (≤20%) = 1.0, wet (>20%) = 1.4.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'firewood-species',
	array(
		'title'       => __( 'Firewood species correction', 'mvweb-fireplace-calc' ),
		'hub'         => 'fuel',
		'description' => __( 'Recalculates the required firewood volume when switching species or accounting for moisture content.', 'mvweb-fireplace-calc' ),
		'formula'     => 'V_adj = V_base / k_species × k_moisture',
		'legend'      => array(
			'V_adj'      => __( 'adjusted volume, m³', 'mvweb-fireplace-calc' ),
			'V_base'     => __( 'base volume calculated for birch, m³', 'mvweb-fireplace-calc' ),
			'k_species'  => __( 'species calorific factor relative to birch', 'mvweb-fireplace-calc' ),
			'k_moisture' => __( 'moisture correction factor (dry = 1.0, wet = 1.4)', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Adjusted firewood volume', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'm³', 'mvweb-fireplace-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'base_volume' => array(
				'type'     => 'number',
				'label'    => __( 'Base volume (birch equivalent)', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm³', 'mvweb-fireplace-calc' ),
				'min'      => 0.5,
				'max'      => 100,
				'step'     => 0.5,
				'required' => true,
			),
			'species'     => array(
				'type'    => 'select',
				'label'   => __( 'Wood species', 'mvweb-fireplace-calc' ),
				'default' => 'birch',
				'options' => array(
					'birch' => __( 'Birch (baseline)', 'mvweb-fireplace-calc' ),
					'oak'   => __( 'Oak (+15% calorific)', 'mvweb-fireplace-calc' ),
					'pine'  => __( 'Pine (−15% calorific)', 'mvweb-fireplace-calc' ),
					'aspen' => __( 'Aspen (−25% calorific)', 'mvweb-fireplace-calc' ),
				),
			),
			'moisture'    => array(
				'type'    => 'radio',
				'label'   => __( 'Moisture content', 'mvweb-fireplace-calc' ),
				'default' => 'dry',
				'options' => array(
					'dry' => __( 'Dry (≤ 20%)', 'mvweb-fireplace-calc' ),
					'wet' => __( 'Wet (> 20%)', 'mvweb-fireplace-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$base_volume = (float) ( $i['base_volume'] ?? 0 );
			$species     = (string) ( $i['species'] ?? 'birch' );
			$moisture    = (string) ( $i['moisture'] ?? 'dry' );

			$species_factors = array(
				'birch' => 1.00,
				'oak'   => 1.15,
				'pine'  => 0.85,
				'aspen' => 0.75,
			);

			$k_species  = $species_factors[ $species ] ?? 1.00;
			$k_moisture = ( 'wet' === $moisture ) ? 1.4 : 1.0;

			$adjusted = $base_volume / $k_species * $k_moisture;

			$hints = array();

			if ( 'oak' === $species ) {
				$hints[] = __( 'Oak has the highest density and calorific value among common firewood species — you need about 15% less volume than birch.', 'mvweb-fireplace-calc' );
			} elseif ( 'aspen' === $species ) {
				$hints[] = __( 'Aspen burns quickly with low heat output. It is mainly used for chimney cleaning, not as primary fuel.', 'mvweb-fireplace-calc' );
			} elseif ( 'pine' === $species ) {
				$hints[] = __( 'Pine contains resins that can deposit creosote in the chimney. Ensure regular flue cleaning when burning pine.', 'mvweb-fireplace-calc' );
			}

			if ( 'wet' === $moisture ) {
				$hints[] = __( 'Wet wood requires up to 40% more volume for the same heat output. Season firewood for at least 1–2 years under a covered shelter.', 'mvweb-fireplace-calc' );
			}

			return array(
				'value' => $adjusted,
				'hints' => $hints,
			);
		},
	)
);
