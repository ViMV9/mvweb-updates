<?php
/**
 * Calculator: convert stacked (apparent) firewood volume to solid wood volume.
 *
 * Formula: V_solid = V_stacked × k_fullness
 * Fullness coefficients per GOST 3243-88:
 *   split logs  k = 0.70
 *   round logs  k = 0.80
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'firewood-stacked-solid',
	array(
		'title'       => __( 'Stacked to solid volume', 'mvweb-fireplace-calc' ),
		'hub'         => 'fuel',
		'description' => __( 'Converts the commercial stacked (apparent) volume of firewood to actual solid wood volume using GOST 3243-88 fullness coefficients.', 'mvweb-fireplace-calc' ),
		'formula'     => 'V_solid = V_stacked × k',
		'legend'      => array(
			'V_solid'   => __( 'solid wood volume, m³', 'mvweb-fireplace-calc' ),
			'V_stacked' => __( 'stacked (apparent) volume, m³', 'mvweb-fireplace-calc' ),
			'k'         => __( 'fullness coefficient: 0.70 for split, 0.80 for round (GOST 3243-88)', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Solid wood volume', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'm³', 'mvweb-fireplace-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'stacked_volume' => array(
				'type'     => 'number',
				'label'    => __( 'Stacked volume', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm³', 'mvweb-fireplace-calc' ),
				'min'      => 0.1,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'log_form'       => array(
				'type'       => 'radio',
				'label'      => __( 'Log form', 'mvweb-fireplace-calc' ),
				'default'    => 'split',
				'full_width' => true,
				'options'    => array(
					'split' => __( 'Split logs (k = 0.70)', 'mvweb-fireplace-calc' ),
					'round' => __( 'Round logs (k = 0.80)', 'mvweb-fireplace-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$stacked  = (float) ( $i['stacked_volume'] ?? 0 );
			$log_form = (string) ( $i['log_form'] ?? 'split' );

			$k      = ( 'round' === $log_form ) ? 0.80 : 0.70;
			$solid  = $stacked * $k;
			$voids  = $stacked - $solid;

			$hints   = array();
			$hints[] = sprintf(
				/* translators: 1: void volume m³, 2: void percentage */
				__( 'Air voids account for %.2f m³ (%.0f%% of stacked volume) — this is normal and expected when stacking firewood.', 'mvweb-fireplace-calc' ),
				$voids,
				( 1.0 - $k ) * 100.0
			);
			$hints[] = __( 'Use the solid volume figure when calculating heat output — only actual wood, not air, releases energy during combustion.', 'mvweb-fireplace-calc' );

			return array(
				'value' => $solid,
				'hints' => $hints,
			);
		},
	)
);
