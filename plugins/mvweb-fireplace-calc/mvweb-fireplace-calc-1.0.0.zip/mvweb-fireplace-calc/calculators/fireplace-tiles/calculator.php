<?php
/**
 * Calculator: facing tiles for fireplace portal.
 *
 * Formula:
 *   N = ceil( portal_area / tile_area × (1 + reserve_pct / 100) )
 *
 * Tile sizes (face area):
 *   200×200 mm  = 0.0400 m²
 *   250×200 mm  = 0.0500 m²
 *   Izrazets 220×220 mm = 0.0484 m²
 *   600×300 mm  = 0.1800 m²
 *
 * Source: standard tile consumption practice, GOST 6141-91.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'fireplace-tiles',
	array(
		'title'       => __( 'Fireplace facing tiles', 'mvweb-fireplace-calc' ),
		'hub'         => 'masonry',
		'description' => __( 'Estimates the number of facing tiles needed to clad a fireplace portal, including waste reserve.', 'mvweb-fireplace-calc' ),
		'formula'     => 'N = ceil( portal_area / tile_area × (1 + reserve% / 100) )',
		'legend'      => array(
			'N'           => __( 'number of tiles', 'mvweb-fireplace-calc' ),
			'portal_area' => __( 'facing area of the fireplace portal, m²', 'mvweb-fireplace-calc' ),
			'tile_area'   => __( 'face area of one tile, m²', 'mvweb-fireplace-calc' ),
			'reserve%'    => __( 'reserve for cutting losses, %', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Number of tiles', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'pcs', 'mvweb-fireplace-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'portal_area' => array(
				'type'     => 'number',
				'label'    => __( 'Portal facing area', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
				'min'      => 0.5,
				'max'      => 20,
				'step'     => 0.1,
				'required' => true,
			),
			'tile_size'   => array(
				'type'    => 'select',
				'label'   => __( 'Tile size', 'mvweb-fireplace-calc' ),
				'default' => '200x200',
				'options' => array(
					'200x200'    => __( '200×200 mm', 'mvweb-fireplace-calc' ),
					'250x200'    => __( '250×200 mm', 'mvweb-fireplace-calc' ),
					'izrazets'   => __( 'Izrazets 220×220 mm', 'mvweb-fireplace-calc' ),
					'600x300'    => __( '600×300 mm', 'mvweb-fireplace-calc' ),
				),
			),
			'reserve_pct' => array(
				'type'    => 'number',
				'label'   => __( 'Reserve for cutting losses', 'mvweb-fireplace-calc' ),
				'unit'    => __( '%', 'mvweb-fireplace-calc' ),
				'min'     => 0,
				'max'     => 20,
				'step'    => 1,
				'default' => 10,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area        = (float) ( $i['portal_area'] ?? 0 );
			$tile_key    = (string) ( $i['tile_size'] ?? '200x200' );
			$reserve     = (float) ( $i['reserve_pct'] ?? 10 );

			$tile_areas = array(
				'200x200'  => 0.200 * 0.200,
				'250x200'  => 0.250 * 0.200,
				'izrazets' => 0.220 * 0.220,
				'600x300'  => 0.600 * 0.300,
			);

			$tile_area = isset( $tile_areas[ $tile_key ] ) ? $tile_areas[ $tile_key ] : 0.04;
			$tiles     = (int) ceil( $area / $tile_area * ( 1 + $reserve / 100 ) );

			$hints = array();

			/* translators: %d — net tile count without reserve */
			$hints[] = sprintf(
				__( 'Net count without reserve: %d pcs. Always order with a reserve — dye lots may differ.', 'mvweb-fireplace-calc' ),
				(int) ceil( $area / $tile_area )
			);

			if ( 'izrazets' === $tile_key ) {
				$hints[] = __( 'Izrazets (majolica tiles) require a dedicated stove setter. Installation is more complex than standard ceramic tile.', 'mvweb-fireplace-calc' );
			}

			if ( $reserve < 10 ) {
				$hints[] = __( 'A 10% reserve is recommended for portal facing — the portal perimeter involves many cuts.', 'mvweb-fireplace-calc' );
			}

			return array(
				'value' => $tiles,
				'hints' => $hints,
			);
		},
	)
);
