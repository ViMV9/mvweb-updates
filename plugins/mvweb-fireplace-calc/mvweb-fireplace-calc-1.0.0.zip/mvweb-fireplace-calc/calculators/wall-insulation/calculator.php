<?php
/**
 * Calculator: wall insulation thickness behind a stove.
 *
 * Formula: thickness = surface_temp / conductivity_factor
 * Conductivity factors (W/m·K):
 *   basalt_wool:       0.040 (λ = 0.040, higher λ → more thickness needed)
 *   calcium_silicate:  0.020 (λ = 0.020, denser, better at high temp)
 *   superisol:         0.012 (λ = 0.012, microporous board, thinnest)
 *
 * Target: limit heat flux through insulation to ≤ 50 W/m² (safe for wall).
 * Required thickness = λ × ΔT / q_max, where ΔT = surface_temp - 20 (ambient).
 * Result rounded up to nearest 5 mm.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'wall-insulation',
	array(
		'title'       => __( 'Wall insulation behind stove', 'mvweb-fireplace-calc' ),
		'hub'         => 'safety',
		'description' => __( 'Calculates the recommended insulation thickness between a hot stove surface and the wall to limit heat flux to a safe level (≤ 50 W/m²).', 'mvweb-fireplace-calc' ),
		'formula'     => 'd = λ × (T_surface − 20) / q_max  [round up to 5 mm]',
		'legend'      => array(
			'd'         => __( 'insulation thickness, mm', 'mvweb-fireplace-calc' ),
			'λ'         => __( 'thermal conductivity of insulation material, W/(m·K)', 'mvweb-fireplace-calc' ),
			'T_surface' => __( 'stove surface temperature, °C', 'mvweb-fireplace-calc' ),
			'q_max'     => __( 'maximum allowable heat flux = 50 W/m²', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended insulation thickness', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'mm', 'mvweb-fireplace-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'surface_temp' => array(
				'type'     => 'number',
				'label'    => __( 'Stove surface temperature', 'mvweb-fireplace-calc' ),
				'unit'     => __( '°C', 'mvweb-fireplace-calc' ),
				'min'      => 50,
				'max'      => 400,
				'step'     => 10,
				'default'  => 200,
				'required' => true,
			),
			'material'     => array(
				'type'     => 'select',
				'label'    => __( 'Insulation material', 'mvweb-fireplace-calc' ),
				'default'  => 'basalt_wool',
				'required' => true,
				'options'  => array(
					'basalt_wool'      => __( 'Basalt (mineral) wool, λ = 0.040 W/(m·K)', 'mvweb-fireplace-calc' ),
					'calcium_silicate' => __( 'Calcium silicate board, λ = 0.020 W/(m·K)', 'mvweb-fireplace-calc' ),
					'superisol'        => __( 'Superisol microporous board, λ = 0.012 W/(m·K)', 'mvweb-fireplace-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$surface_temp = (float) ( $i['surface_temp'] ?? 200 );
			$material     = (string) ( $i['material'] ?? 'basalt_wool' );

			$conductivity_map = array(
				'basalt_wool'      => 0.040,
				'calcium_silicate' => 0.020,
				'superisol'        => 0.012,
			);

			$lambda   = $conductivity_map[ $material ] ?? 0.040;
			$delta_t  = max( 0.0, $surface_temp - 20.0 );
			$q_max    = 50.0;
			$hints    = array();

			$thickness_m  = $lambda * $delta_t / $q_max;
			$thickness_mm = $thickness_m * 1000.0;

			$thickness_rounded = (float) ( ceil( $thickness_mm / 5 ) * 5 );

			if ( 'basalt_wool' === $material ) {
				$hints[] = __( 'Basalt wool: use density ≥ 80 kg/m³ rated for ≥ 600 °C. For the given thickness, consider splitting into two layers for better installation quality.', 'mvweb-fireplace-calc' );
			} elseif ( 'calcium_silicate' === $material ) {
				$hints[] = __( 'Calcium silicate board: rated up to 1000 °C, dimensionally stable. Suitable as a direct backing on the wall before finishing with tile.', 'mvweb-fireplace-calc' );
			} else {
				$hints[] = __( 'Superisol microporous board: excellent high-temperature performance (up to 1000 °C) with minimal thickness. More expensive, but optimal for tight spaces.', 'mvweb-fireplace-calc' );
			}

			if ( $surface_temp > 300 ) {
				$hints[] = __( 'At surface temperatures above 300 °C also verify that the fasteners and adhesive mortar are rated for the expected temperature.', 'mvweb-fireplace-calc' );
			}

			return array(
				'value' => $thickness_rounded,
				'hints' => $hints,
			);
		},
	)
);
