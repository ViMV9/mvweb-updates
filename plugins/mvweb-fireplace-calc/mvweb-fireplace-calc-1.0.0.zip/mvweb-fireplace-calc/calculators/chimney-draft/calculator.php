<?php
/**
 * Calculator: natural chimney draft pressure.
 *
 * Formula (thermodynamic):
 *   ΔP = 0.0342 × P_atm × H × ( 1/T_out − 1/T_gas )
 *
 *   where:
 *     P_atm  = 101325 Pa (standard atmospheric pressure)
 *     T_out  = outdoor air temperature, K  (273.15 + T_out_C)
 *     T_gas  = flue gas temperature, K     (T_out + delta_t)
 *     H      = chimney height, m
 *
 * Source: SP 7.13130.2013 appendix G; SNiP 41-01-2003 section 6.
 * Norm: natural draft 10–20 Pa for residential appliances.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'chimney-draft',
	array(
		'title'       => __( 'Chimney draft', 'mvweb-fireplace-calc' ),
		'hub'         => 'chimney',
		'description' => __( 'Calculates the natural draft pressure in a chimney based on height and temperature differential between flue gases and outdoor air.', 'mvweb-fireplace-calc' ),
		'formula'     => 'ΔP = 0.0342 × P_atm × H × ( 1/T_out − 1/T_gas )',
		'legend'      => array(
			'ΔP'      => __( 'draft pressure, Pa', 'mvweb-fireplace-calc' ),
			'P_atm'   => __( 'atmospheric pressure, Pa (101325)', 'mvweb-fireplace-calc' ),
			'H'       => __( 'chimney height, m', 'mvweb-fireplace-calc' ),
			'T_out'   => __( 'outdoor air temperature, K', 'mvweb-fireplace-calc' ),
			'T_gas'   => __( 'flue gas temperature, K', 'mvweb-fireplace-calc' ),
			'delta_t' => __( 'temperature difference between flue gas and outdoor air, °C', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Draft pressure', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'Pa', 'mvweb-fireplace-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'height'  => array(
				'type'     => 'number',
				'label'    => __( 'Chimney height', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 1,
				'max'      => 20,
				'step'     => 0.1,
				'required' => true,
				'default'  => 5,
			),
			'delta_t' => array(
				'type'     => 'number',
				'label'    => __( 'Gas–outdoor temperature difference', 'mvweb-fireplace-calc' ),
				'unit'     => __( '°C', 'mvweb-fireplace-calc' ),
				'min'      => 50,
				'max'      => 500,
				'step'     => 5,
				'required' => true,
				'default'  => 200,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$height  = (float) ( $i['height'] ?? 0 );
			$delta_t = (float) ( $i['delta_t'] ?? 200 );

			$t_out_c = -15.0;
			$t_out_k = 273.15 + $t_out_c;
			$t_gas_k = $t_out_k + $delta_t;
			$p_atm   = 101325.0;

			$draft = 0.0342 * $p_atm * $height * ( ( 1.0 / $t_out_k ) - ( 1.0 / $t_gas_k ) );

			$hints = array();

			if ( $draft < 10.0 ) {
				$hints[] = sprintf(
					__( 'Draft of %.1f Pa is below the recommended minimum of 10 Pa. Consider increasing chimney height or improving insulation to raise flue gas temperature.', 'mvweb-fireplace-calc' ),
					$draft
				);
			} elseif ( $draft <= 20.0 ) {
				$hints[] = sprintf(
					__( 'Draft of %.1f Pa is within the optimal range of 10–20 Pa for residential appliances. The chimney parameters are well-sized.', 'mvweb-fireplace-calc' ),
					$draft
				);
			} else {
				$hints[] = sprintf(
					__( 'Draft of %.1f Pa exceeds 20 Pa. High draft is generally acceptable but may cause excessive fuel consumption or noise. A draft regulator (damper) is recommended.', 'mvweb-fireplace-calc' ),
					$draft
				);
			}

			$hints[] = __( 'Calculation uses standard atmospheric pressure (101 325 Pa) and outdoor temperature −15 °C. Actual draft varies with altitude and weather.', 'mvweb-fireplace-calc' );

			return array(
				'value' => $draft,
				'hints' => $hints,
			);
		},
	)
);
