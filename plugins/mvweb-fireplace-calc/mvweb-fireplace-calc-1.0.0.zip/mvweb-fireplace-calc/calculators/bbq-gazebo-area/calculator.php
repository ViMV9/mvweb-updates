<?php
/**
 * Calculator: recommended area for a barbecue gazebo.
 *
 * Formula: area = guests × area_per_guest [ + 3 m² if with_bbq = yes ]
 *
 * Planning norms reference:
 *   - Comfortable outdoor seating: 1.5–2.5 m² per person (SP 54.13330 guidance).
 *   - BBQ / mangal zone: ≥ 3 m² extra (1.5 m clearance around grill per fire safety).
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'bbq-gazebo-area',
	array(
		'title'       => __( 'Barbecue / gazebo area', 'mvweb-fireplace-calc' ),
		'hub'         => 'safety',
		'description' => __( 'Estimates the recommended floor area for an outdoor gazebo based on guest count and optional barbecue zone clearance.', 'mvweb-fireplace-calc' ),
		'formula'     => 'A = guests × area_per_guest [ + 3 m² for BBQ zone ]',
		'legend'      => array(
			'A'              => __( 'total recommended gazebo area, m²', 'mvweb-fireplace-calc' ),
			'guests'         => __( 'number of guests', 'mvweb-fireplace-calc' ),
			'area_per_guest' => __( 'area per person, m²', 'mvweb-fireplace-calc' ),
			'BBQ zone'       => __( '+3 m² additional clearance for grill / mangal', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended gazebo area', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'guests'         => array(
				'type'     => 'number',
				'label'    => __( 'Number of guests', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'persons', 'mvweb-fireplace-calc' ),
				'min'      => 2,
				'max'      => 50,
				'step'     => 1,
				'default'  => 6,
				'required' => true,
			),
			'area_per_guest' => array(
				'type'     => 'number',
				'label'    => __( 'Area per person', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
				'min'      => 1.0,
				'max'      => 5.0,
				'step'     => 0.5,
				'default'  => 2.0,
				'required' => true,
			),
			'with_bbq'       => array(
				'type'       => 'radio',
				'label'      => __( 'Include BBQ / mangal zone', 'mvweb-fireplace-calc' ),
				'default'    => 'yes',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'yes' => __( 'Yes — add 3 m² grill clearance zone', 'mvweb-fireplace-calc' ),
					'no'  => __( 'No — seating area only', 'mvweb-fireplace-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$guests         = (float) ( $i['guests'] ?? 6 );
			$area_per_guest = (float) ( $i['area_per_guest'] ?? 2.0 );
			$with_bbq       = (string) ( $i['with_bbq'] ?? 'yes' );

			$area     = $guests * $area_per_guest;
			$bbq_zone = 0.0;
			$hints    = array();

			if ( 'yes' === $with_bbq ) {
				$bbq_zone = 3.0;
				$area    += $bbq_zone;
				$hints[]  = __( 'BBQ / mangal zone (+3 m²) added: maintain at least 1.5 m clearance around the grill on all sides to meet fire safety requirements.', 'mvweb-fireplace-calc' );
			}

			if ( $area_per_guest < 1.5 ) {
				$hints[] = __( 'Area per person below 1.5 m² may feel cramped. 2–2.5 m² per person is the comfortable norm for outdoor dining.', 'mvweb-fireplace-calc' );
			}

			if ( $guests > 20 ) {
				$hints[] = __( 'For large gatherings (> 20 persons) consider splitting into two separate zones with an aisle of at least 1.2 m for comfortable movement.', 'mvweb-fireplace-calc' );
			}

			$hints[] = sprintf(
				__( 'Suggested gazebo footprint: %.0f m² total (%.0f m² seating%s).', 'mvweb-fireplace-calc' ),
				$area,
				$area - $bbq_zone,
				'yes' === $with_bbq ? sprintf( __( ' + %.0f m² BBQ zone', 'mvweb-fireplace-calc' ), $bbq_zone ) : ''
			);

			return array(
				'value' => round( $area, 1 ),
				'hints' => $hints,
			);
		},
	)
);
