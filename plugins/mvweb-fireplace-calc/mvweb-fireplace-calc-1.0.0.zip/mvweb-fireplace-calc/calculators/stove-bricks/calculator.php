<?php
/**
 * Calculator: bricks for a stove.
 *
 * Formula:
 *   Perimeter = 2 × (L + W)
 *   V_masonry  = Perimeter × H × wall_thickness
 *   N_bricks   = V_masonry × 394 × (1 + reserve_pct / 100)
 *
 * Brick density: 394 pcs/m³ (standard 250×120×65 mm with 10 mm mortar joint).
 * Simplified box model: four solid walls, no door/ash-pit openings.
 *
 * Source: GOST 530-2012, common masonry stove design practice.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'stove-bricks',
	array(
		'title'       => __( 'Bricks for a stove', 'mvweb-fireplace-calc' ),
		'hub'         => 'masonry',
		'description' => __( 'Estimates the number of standard bricks for building a masonry stove based on outer dimensions and wall thickness.', 'mvweb-fireplace-calc' ),
		'formula'     => 'N = 2 × (L + W) × H × wall × 394 × (1 + reserve% / 100)',
		'legend'      => array(
			'N'        => __( 'number of bricks', 'mvweb-fireplace-calc' ),
			'L'        => __( 'stove length, m', 'mvweb-fireplace-calc' ),
			'W'        => __( 'stove width, m', 'mvweb-fireplace-calc' ),
			'H'        => __( 'stove height, m', 'mvweb-fireplace-calc' ),
			'wall'     => __( 'wall thickness, m', 'mvweb-fireplace-calc' ),
			'reserve%' => __( 'reserve for cutting losses, %', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Number of bricks', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'pcs', 'mvweb-fireplace-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'length'      => array(
				'type'     => 'number',
				'label'    => __( 'Stove length', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.3,
				'max'      => 3,
				'step'     => 0.05,
				'required' => true,
			),
			'width'       => array(
				'type'     => 'number',
				'label'    => __( 'Stove width', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.3,
				'max'      => 3,
				'step'     => 0.05,
				'required' => true,
			),
			'height'      => array(
				'type'     => 'number',
				'label'    => __( 'Stove height', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.3,
				'max'      => 3,
				'step'     => 0.05,
				'required' => true,
			),
			'reserve_pct' => array(
				'type'    => 'number',
				'label'   => __( 'Reserve for cutting losses', 'mvweb-fireplace-calc' ),
				'unit'    => __( '%', 'mvweb-fireplace-calc' ),
				'min'     => 0,
				'max'     => 15,
				'step'    => 1,
				'default' => 5,
			),
			'wall'        => array(
				'type'       => 'radio',
				'label'      => __( 'Wall thickness', 'mvweb-fireplace-calc' ),
				'default'    => 'half_brick',
				'full_width' => true,
				'options'    => array(
					'half_brick' => __( 'Half-brick — 0.12 m', 'mvweb-fireplace-calc' ),
					'one_brick'  => __( 'One brick — 0.25 m', 'mvweb-fireplace-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$length    = (float) ( $i['length'] ?? 0 );
			$width     = (float) ( $i['width'] ?? 0 );
			$height    = (float) ( $i['height'] ?? 0 );
			$wall_key  = (string) ( $i['wall'] ?? 'half_brick' );
			$reserve   = (float) ( $i['reserve_pct'] ?? 5 );

			$wall_thickness = ( 'one_brick' === $wall_key ) ? 0.25 : 0.12;
			$perimeter      = 2 * ( $length + $width );
			$volume         = $perimeter * $height * $wall_thickness;
			$bricks         = $volume * 394 * ( 1 + $reserve / 100 );

			$hints = array();

			if ( $reserve < 5 ) {
				$hints[] = __( 'A minimum 5% reserve is recommended to account for cutting and breakage.', 'mvweb-fireplace-calc' );
			}

			/* translators: %d — number of bricks without reserve */
			$hints[] = sprintf(
				__( 'Net quantity without reserve: %d pcs. Add the reserve before ordering to avoid a second delivery.', 'mvweb-fireplace-calc' ),
				(int) round( $volume * 394 )
			);

			$hints[] = __( 'Calculation uses a simplified box model. Actual count may vary depending on openings, arch elements and individual masonry plan.', 'mvweb-fireplace-calc' );

			return array(
				'value' => $bricks,
				'hints' => $hints,
			);
		},
	)
);
