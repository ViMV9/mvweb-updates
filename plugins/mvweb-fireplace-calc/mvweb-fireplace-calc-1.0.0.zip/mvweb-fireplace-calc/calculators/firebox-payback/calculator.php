<?php
/**
 * Calculator: payback period for a firebox or stove upgrade.
 *
 * Formula: T_months = firebox_price / (savings_per_season / 12)
 * Result expressed in whole months; hints convert to years.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'firebox-payback',
	array(
		'title'       => __( 'Firebox upgrade payback', 'mvweb-fireplace-calc' ),
		'hub'         => 'fuel',
		'description' => __( 'Estimates how many months it takes for fuel savings from a new firebox or stove to recover the purchase and installation cost.', 'mvweb-fireplace-calc' ),
		'formula'     => 'T = C / (S / 12)',
		'legend'      => array(
			'T' => __( 'payback period, months', 'mvweb-fireplace-calc' ),
			'C' => __( 'firebox price (purchase + installation), ₽', 'mvweb-fireplace-calc' ),
			'S' => __( 'annual fuel savings, ₽/season', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Payback period', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'months', 'mvweb-fireplace-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'savings_per_season' => array(
				'type'     => 'number',
				'label'    => __( 'Annual fuel savings', 'mvweb-fireplace-calc' ),
				'unit'     => __( '₽/season', 'mvweb-fireplace-calc' ),
				'min'      => 1000,
				'max'      => 500000,
				'step'     => 1000,
				'required' => true,
			),
			'firebox_price'      => array(
				'type'     => 'number',
				'label'    => __( 'Firebox total cost', 'mvweb-fireplace-calc' ),
				'unit'     => __( '₽', 'mvweb-fireplace-calc' ),
				'min'      => 5000,
				'max'      => 1000000,
				'step'     => 5000,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$savings       = (float) ( $i['savings_per_season'] ?? 0 );
			$firebox_price = (float) ( $i['firebox_price'] ?? 0 );

			$monthly_savings = ( $savings > 0 ) ? ( $savings / 12.0 ) : 0;
			$months          = ( $monthly_savings > 0 ) ? ( $firebox_price / $monthly_savings ) : 0;

			$years        = $months / 12.0;
			$full_years   = (int) floor( $years );
			$rem_months   = (int) round( ( $years - $full_years ) * 12 );

			$hints = array();

			if ( $full_years > 0 || $rem_months > 0 ) {
				if ( $rem_months > 0 ) {
					$hints[] = sprintf(
						/* translators: 1: full years, 2: remaining months */
						__( 'Payback in %1$d year(s) and %2$d month(s) — after that every season is pure saving.', 'mvweb-fireplace-calc' ),
						$full_years,
						$rem_months
					);
				} else {
					$hints[] = sprintf(
						/* translators: number of full years */
						__( 'Payback in exactly %d year(s) — after that every season is pure saving.', 'mvweb-fireplace-calc' ),
						$full_years
					);
				}
			}

			if ( $years <= 5 ) {
				$hints[] = __( 'Under 5 years is an excellent return on investment for heating equipment — consider proceeding with the upgrade.', 'mvweb-fireplace-calc' );
			} elseif ( $years <= 10 ) {
				$hints[] = __( 'A 5–10 year payback is typical for firebox upgrades. Verify projected savings with a heat-loss calculation for greater accuracy.', 'mvweb-fireplace-calc' );
			} else {
				$hints[] = __( 'Payback over 10 years — review the savings estimate or explore more cost-effective equipment options.', 'mvweb-fireplace-calc' );
			}

			return array(
				'value' => $months,
				'hints' => $hints,
			);
		},
	)
);
