<?php
/**
 * Calculator: clearance distance from stove to wall (отступка).
 *
 * Formula: clearance = f( wall_type, wall_temp )
 * Per SP 7.13130.2020 (fire safety norms for heating appliances).
 *
 * Combustible unprotected wall: ≥ 500 mm at surface temp > 100 °C,
 * reduced to 320 mm at ≤ 100 °C.
 * Protected wall (25 mm min insulation + sheet steel): ≥ 380 mm at > 100 °C,
 * 250 mm at ≤ 100 °C.
 * Non-combustible wall (brick, concrete, block): 0 mm (contact allowed).
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'clearance-distance',
	array(
		'title'       => __( 'Clearance to wall (отступка)', 'mvweb-fireplace-calc' ),
		'hub'         => 'safety',
		'description' => __( 'Calculates the minimum required clearance between a stove or fireplace and a nearby wall per SP 7.13130.2020 fire safety norms.', 'mvweb-fireplace-calc' ),
		'formula'     => __( 'Clearance = f( wall_type, wall_temp ) per SP 7.13130', 'mvweb-fireplace-calc' ),
		'legend'      => array(
			'wall_type' => __( 'combustibility class of the wall material', 'mvweb-fireplace-calc' ),
			'wall_temp' => __( 'surface temperature of the stove wall, °C', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Minimum clearance', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'mm', 'mvweb-fireplace-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'wall_type' => array(
				'type'     => 'radio',
				'label'    => __( 'Wall type', 'mvweb-fireplace-calc' ),
				'default'  => 'combustible',
				'required' => true,
				'options'  => array(
					'combustible'     => __( 'Combustible (unprotected)', 'mvweb-fireplace-calc' ),
					'protected'       => __( 'Protected (insulation + sheet steel)', 'mvweb-fireplace-calc' ),
					'noncombustible'  => __( 'Non-combustible (brick, concrete, block)', 'mvweb-fireplace-calc' ),
				),
			),
			'wall_temp' => array(
				'type'     => 'number',
				'label'    => __( 'Stove surface temperature', 'mvweb-fireplace-calc' ),
				'unit'     => __( '°C', 'mvweb-fireplace-calc' ),
				'min'      => 50,
				'max'      => 500,
				'step'     => 10,
				'default'  => 200,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$wall_type = (string) ( $i['wall_type'] ?? 'combustible' );
			$wall_temp = (float) ( $i['wall_temp'] ?? 200 );

			$clearance = 0;
			$hints     = array();

			if ( 'noncombustible' === $wall_type ) {
				$clearance = 0;
				$hints[]   = __( 'Non-combustible walls (brick, concrete, aerated block) require no minimum clearance per SP 7.13130. Contact installation is permitted.', 'mvweb-fireplace-calc' );
			} elseif ( 'protected' === $wall_type ) {
				$clearance = $wall_temp > 100 ? 380 : 250;
				$hints[]   = __( 'Protected wall: at least 25 mm mineral wool + 1 mm sheet steel covering is required. Clearance reduced vs. unprotected wall per SP 7.13130 clause 6.6.', 'mvweb-fireplace-calc' );
				if ( $wall_temp > 300 ) {
					$hints[] = __( 'At surface temperatures above 300 °C consider using a non-combustible lining or increasing clearance to 500 mm for safety.', 'mvweb-fireplace-calc' );
				}
			} else {
				$clearance = $wall_temp > 100 ? 500 : 320;
				$hints[]   = __( 'Combustible unprotected wall requires 500 mm clearance at surface temp > 100 °C per SP 7.13130 clause 6.6. Consider adding a protective screen to reduce required clearance.', 'mvweb-fireplace-calc' );
				if ( $wall_temp > 250 ) {
					$hints[] = __( 'High surface temperature detected. Review stove installation: consider relining with fireclay or adding an air gap.', 'mvweb-fireplace-calc' );
				}
			}

			return array(
				'value' => (float) $clearance,
				'hints' => $hints,
			);
		},
	)
);
