<?php
/**
 * Calculator: heating power by room volume.
 *
 * Formula: P = (volume / 25) × K
 * Base norm: 1 kW per 25 m³.
 * Insulation coefficient K: well-insulated=0.8, average=1.0, poor=1.4.
 *
 * Source: SP 50.13330.2012 "Building heat protection",
 * residential heating specific load 1 kW/25 m³.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'power-by-volume',
	array(
		'title'       => __( 'Power by room volume', 'mvweb-fireplace-calc' ),
		'hub'         => 'heating',
		'description' => __( 'Calculates required heating power directly from room volume, accounting for insulation quality.', 'mvweb-fireplace-calc' ),
		'formula'     => 'P = (V / 25) × K',
		'legend'      => array(
			'P' => __( 'required heating power, kW', 'mvweb-fireplace-calc' ),
			'V' => __( 'room volume, m³', 'mvweb-fireplace-calc' ),
			'K' => __( 'insulation coefficient (good=0.8, average=1.0, poor=1.4)', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Required heating power', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'kW', 'mvweb-fireplace-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'volume'     => array(
				'type'     => 'number',
				'label'    => __( 'Room volume', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm³', 'mvweb-fireplace-calc' ),
				'min'      => 1,
				'max'      => 2000,
				'step'     => 1,
				'required' => true,
			),
			'insulation' => array(
				'type'    => 'radio',
				'label'   => __( 'Insulation quality', 'mvweb-fireplace-calc' ),
				'default' => 'average',
				'options' => array(
					'good'    => __( 'Good (modern insulation)', 'mvweb-fireplace-calc' ),
					'average' => __( 'Average (standard construction)', 'mvweb-fireplace-calc' ),
					'poor'    => __( 'Poor (old building, no insulation)', 'mvweb-fireplace-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$volume = (float) ( $i['volume'] ?? 0 );
			$ins    = (string) ( $i['insulation'] ?? 'average' );

			$coefficients = array(
				'good'    => 0.8,
				'average' => 1.0,
				'poor'    => 1.4,
			);
			$k     = $coefficients[ $ins ] ?? 1.0;
			$power = ( $volume / 25 ) * $k;

			$hints = array();

			if ( 'poor' === $ins ) {
				$hints[] = __( 'With poor insulation improving the building envelope can reduce heating costs by 30–40%.', 'mvweb-fireplace-calc' );
			}

			/* translators: %1$.1f — calculated power range low, %2$.1f — range high */
			$hints[] = sprintf(
				__( 'Recommended heating unit output %.1f–%.1f kW — see the catalog for suitable fireplace inserts.', 'mvweb-fireplace-calc' ),
				$power * 0.9,
				$power * 1.1
			);

			return array(
				'value' => $power,
				'hints' => $hints,
			);
		},
	)
);
