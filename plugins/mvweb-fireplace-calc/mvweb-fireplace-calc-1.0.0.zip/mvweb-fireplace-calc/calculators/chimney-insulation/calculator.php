<?php
/**
 * Calculator: chimney basalt wool insulation thickness.
 *
 * Logic:
 *   Base thickness is derived from outdoor design temperature using
 *   a linear interpolation: at 0 °C → 30 mm; at −45 °C → 100 mm.
 *   Material correction:
 *     steel  → +20 mm (thin wall, high thermal conductivity, condensate risk)
 *     brick  → −10 mm (thick masonry, inherent thermal mass)
 *     ceramic → no correction (reference material)
 *
 * Source: SP 61.13330.2012 "Thermal insulation of equipment and pipelines";
 * manufacturer guidelines for double-walled sandwich chimneys (CORAX, Schiedel).
 * Practical range: 30–100 mm basalt fibre (λ ≈ 0.036 W/m·K).
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'chimney-insulation',
	array(
		'title'       => __( 'Chimney insulation thickness', 'mvweb-fireplace-calc' ),
		'hub'         => 'chimney',
		'description' => __( 'Estimates the recommended basalt wool insulation thickness for a chimney based on outdoor design temperature and pipe material.', 'mvweb-fireplace-calc' ),
		'formula'     => 't = lerp(30, 100, clamp(-T_out / 45, 0, 1)) + material_correction (mm)',
		'legend'      => array(
			't'                   => __( 'insulation thickness, mm', 'mvweb-fireplace-calc' ),
			'T_out'               => __( 'outdoor design temperature, °C', 'mvweb-fireplace-calc' ),
			'material_correction' => __( 'adjustment for pipe material: steel +20, brick −10, ceramic 0', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended insulation thickness', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'mm', 'mvweb-fireplace-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'pipe_material' => array(
				'type'    => 'radio',
				'label'   => __( 'Chimney pipe material', 'mvweb-fireplace-calc' ),
				'default' => 'ceramic',
				'options' => array(
					'steel'   => __( 'Stainless steel (sandwich)', 'mvweb-fireplace-calc' ),
					'ceramic' => __( 'Ceramic modular', 'mvweb-fireplace-calc' ),
					'brick'   => __( 'Brick', 'mvweb-fireplace-calc' ),
				),
			),
			'outdoor_temp'  => array(
				'type'     => 'number',
				'label'    => __( 'Outdoor design temperature', 'mvweb-fireplace-calc' ),
				'unit'     => __( '°C', 'mvweb-fireplace-calc' ),
				'min'      => -45,
				'max'      => 10,
				'step'     => 1,
				'required' => true,
				'default'  => -25,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$outdoor_temp   = (float) ( $i['outdoor_temp'] ?? -25 );
			$pipe_material  = (string) ( $i['pipe_material'] ?? 'ceramic' );

			$t_min   = 30.0;
			$t_max   = 100.0;
			$ratio   = min( 1.0, max( 0.0, ( -$outdoor_temp ) / 45.0 ) );
			$base    = $t_min + $ratio * ( $t_max - $t_min );

			$corrections = array(
				'steel'   => 20,
				'ceramic' => 0,
				'brick'   => -10,
			);
			$correction = isset( $corrections[ $pipe_material ] ) ? $corrections[ $pipe_material ] : 0;

			$thickness = max( 30, round( $base + $correction ) );

			$hints = array();

			$material_labels = array(
				'steel'   => __( 'stainless steel', 'mvweb-fireplace-calc' ),
				'ceramic' => __( 'ceramic', 'mvweb-fireplace-calc' ),
				'brick'   => __( 'brick', 'mvweb-fireplace-calc' ),
			);
			$label = isset( $material_labels[ $pipe_material ] ) ? $material_labels[ $pipe_material ] : $pipe_material;

			$hints[] = sprintf(
				__( 'For a %s chimney at outdoor design temperature %.0f °C: recommended basalt wool thickness is %d mm (range 30–100 mm). Use density ≥ 100 kg/m³, temperature rating ≥ 700 °C.', 'mvweb-fireplace-calc' ),
				$label,
				$outdoor_temp,
				$thickness
			);

			if ( 'steel' === $pipe_material ) {
				$hints[] = __( 'Steel chimneys are prone to condensation and thermal bridging. Ensure continuous insulation with no gaps, especially at joints and roof penetrations.', 'mvweb-fireplace-calc' );
			}

			if ( 'brick' === $pipe_material && $outdoor_temp < -30 ) {
				$hints[] = __( 'Brick chimneys in climates below −30 °C should have an insulated liner (steel or ceramic insert) in addition to external insulation.', 'mvweb-fireplace-calc' );
			}

			return array(
				'value' => $thickness,
				'hints' => $hints,
			);
		},
	)
);
