<?php
/**
 * Calculator: masonry mortar for stove / fireplace.
 *
 * Formula:
 *   V_mortar = bricks_count / 1000 × 0.25     (m³)
 *   W_mortar = V_mortar × 1700                 (kg)
 *   bags_25  = ceil( W_mortar / 25 )           (bags of 25 kg)
 *
 * Norm: ~0.25 m³ mortar per 1000 standard bricks (250×120×65 mm, 10 mm joint).
 * Mortar density: 1700 kg/m³ (clay-sand mix, typical for stove masonry).
 *
 * Source: SNiP III-17-78, standard masonry mortar consumption norms.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'masonry-mortar',
	array(
		'title'       => __( 'Masonry mortar', 'mvweb-fireplace-calc' ),
		'hub'         => 'masonry',
		'description' => __( 'Calculates the required amount of clay-sand masonry mortar by brick count.', 'mvweb-fireplace-calc' ),
		'formula'     => 'W = (N / 1000) × 0.25 × 1700',
		'legend'      => array(
			'W'    => __( 'mortar weight, kg', 'mvweb-fireplace-calc' ),
			'N'    => __( 'number of bricks', 'mvweb-fireplace-calc' ),
			'0.25' => __( 'mortar volume per 1000 bricks, m³', 'mvweb-fireplace-calc' ),
			'1700' => __( 'mortar density, kg/m³', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Mortar weight', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'kg', 'mvweb-fireplace-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'bricks_count' => array(
				'type'     => 'number',
				'label'    => __( 'Number of bricks', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'pcs', 'mvweb-fireplace-calc' ),
				'min'      => 10,
				'max'      => 10000,
				'step'     => 10,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$bricks   = (float) ( $i['bricks_count'] ?? 0 );
			$volume   = ( $bricks / 1000 ) * 0.25;
			$weight   = $volume * 1700;
			$bags_25  = (int) ceil( $weight / 25 );

			$hints = array();

			/* translators: %1$.3f — mortar volume m³, %2$d — bags of 25 kg */
			$hints[] = sprintf(
				__( 'Mortar volume: %.3f m³ — approximately %d bags of 25 kg dry mix.', 'mvweb-fireplace-calc' ),
				$volume,
				$bags_25
			);

			$hints[] = __( 'Use clay-sand mortar (1:3 to 1:4 ratio) for the main body. Fireclay mortar is required for the firebox lining — sold separately.', 'mvweb-fireplace-calc' );

			if ( $bricks > 1000 ) {
				$hints[] = __( 'For large stoves it is more economical to mix mortar from bulk clay and sand rather than buying bagged dry mix.', 'mvweb-fireplace-calc' );
			}

			return array(
				'value' => $weight,
				'hints' => $hints,
			);
		},
	)
);
