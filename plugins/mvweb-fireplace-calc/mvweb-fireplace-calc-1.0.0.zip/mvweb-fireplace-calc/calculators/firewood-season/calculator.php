<?php
/**
 * Calculator: firewood volume for the heating season.
 *
 * Formula: Q = power × 24 × season_days [kWh]; V = Q / (3000 × efficiency / 100) [m³]
 * Calorific value of dry birch firewood: ~3000 kWh/m³ (stacked solid volume).
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'firewood-season',
	array(
		'title'       => __( 'Firewood for the season', 'mvweb-fireplace-calc' ),
		'hub'         => 'fuel',
		'description' => __( 'Estimates the volume of dry firewood needed for a full heating season based on average heat load and stove efficiency.', 'mvweb-fireplace-calc' ),
		'formula'     => 'V = (P × 24 × D) / (3000 × η / 100)',
		'legend'      => array(
			'V'    => __( 'firewood volume, m³', 'mvweb-fireplace-calc' ),
			'P'    => __( 'average heat load, kW', 'mvweb-fireplace-calc' ),
			'D'    => __( 'heating season duration, days', 'mvweb-fireplace-calc' ),
			'3000' => __( 'calorific value of dry birch, kWh/m³', 'mvweb-fireplace-calc' ),
			'η'    => __( 'stove efficiency, %', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Firewood volume', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'm³', 'mvweb-fireplace-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'power'       => array(
				'type'     => 'number',
				'label'    => __( 'Average heat load', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'kW', 'mvweb-fireplace-calc' ),
				'min'      => 1,
				'max'      => 50,
				'step'     => 0.5,
				'required' => true,
			),
			'efficiency'  => array(
				'type'     => 'number',
				'label'    => __( 'Stove efficiency', 'mvweb-fireplace-calc' ),
				'unit'     => __( '%', 'mvweb-fireplace-calc' ),
				'min'      => 40,
				'max'      => 90,
				'step'     => 1,
				'default'  => 70,
				'required' => true,
			),
			'season_days' => array(
				'type'     => 'number',
				'label'    => __( 'Heating season duration', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'days', 'mvweb-fireplace-calc' ),
				'min'      => 30,
				'max'      => 250,
				'step'     => 1,
				'default'  => 180,
				'required' => true,
			),
			'wood_price'  => array(
				'type'    => 'number',
				'label'   => __( 'Firewood price (optional)', 'mvweb-fireplace-calc' ),
				'unit'    => __( '₽/m³', 'mvweb-fireplace-calc' ),
				'min'     => 0,
				'max'     => 10000,
				'step'    => 100,
				'default' => 0,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$power       = (float) ( $i['power'] ?? 0 );
			$efficiency  = (float) ( $i['efficiency'] ?? 70 );
			$season_days = (float) ( $i['season_days'] ?? 180 );
			$wood_price  = (float) ( $i['wood_price'] ?? 0 );

			$heat_kwh = $power * 24.0 * $season_days;
			$volume   = $heat_kwh / ( 3000.0 * ( $efficiency / 100.0 ) );

			$hints = array();

			if ( $wood_price > 0 ) {
				$cost    = $volume * $wood_price;
				$hints[] = sprintf(
					/* translators: 1: firewood volume m³, 2: total season cost ₽ */
					__( 'At ₽%2$s per m³ the estimated season cost is ₽%1$s.', 'mvweb-fireplace-calc' ),
					number_format( $cost, 0, '.', ' ' ),
					number_format( $wood_price, 0, '.', ' ' )
				);
			}

			$hints[] = __( 'Use properly dried firewood (moisture ≤ 20%) — wet wood can cut effective output by 30–40% and accelerates chimney creosote build-up.', 'mvweb-fireplace-calc' );

			if ( $efficiency < 60 ) {
				$hints[] = __( 'Consider upgrading to a modern closed-combustion stove (η 75–85%) to significantly reduce fuel consumption.', 'mvweb-fireplace-calc' );
			}

			return array(
				'value' => $volume,
				'hints' => $hints,
			);
		},
	)
);
