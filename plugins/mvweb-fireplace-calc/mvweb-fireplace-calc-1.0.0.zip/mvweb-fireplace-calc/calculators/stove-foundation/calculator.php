<?php
/**
 * Calculator: foundation concrete volume for a stove or fireplace.
 *
 * Formula:
 *   V = (L + 0.1) × (W + 0.1) × D × (1 + reserve% / 100)
 * The +0.1 m on each dimension adds the required 5 cm overhang
 * per side beyond the stove footprint (SP 7.13130.2013).
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'stove-foundation',
	array(
		'title'       => __( 'Foundation for a stove/fireplace', 'mvweb-fireplace-calc' ),
		'hub'         => 'foundation',
		'description' => __( 'Calculates the concrete volume for a monolithic pad foundation under a stove or fireplace, with the required 5 cm overhang on each side.', 'mvweb-fireplace-calc' ),
		'formula'     => 'V = (L + 0.10) × (W + 0.10) × D × (1 + reserve% / 100)',
		'legend'      => array(
			'V'        => __( 'concrete volume, m³', 'mvweb-fireplace-calc' ),
			'L'        => __( 'stove length, m', 'mvweb-fireplace-calc' ),
			'W'        => __( 'stove width, m', 'mvweb-fireplace-calc' ),
			'D'        => __( 'foundation depth, m', 'mvweb-fireplace-calc' ),
			'reserve%' => __( 'reserve for casting losses, %', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Concrete volume', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'm³', 'mvweb-fireplace-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'stove_length' => array(
				'type'     => 'number',
				'label'    => __( 'Stove length', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.3,
				'max'      => 3,
				'step'     => 0.01,
				'required' => true,
			),
			'stove_width'  => array(
				'type'     => 'number',
				'label'    => __( 'Stove width', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.3,
				'max'      => 3,
				'step'     => 0.01,
				'required' => true,
			),
			'depth'        => array(
				'type'     => 'number',
				'label'    => __( 'Foundation depth', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.2,
				'max'      => 1.2,
				'step'     => 0.05,
				'default'  => 0.5,
				'required' => true,
			),
			'reserve_pct'  => array(
				'type'    => 'number',
				'label'   => __( 'Reserve for losses', 'mvweb-fireplace-calc' ),
				'unit'    => __( '%', 'mvweb-fireplace-calc' ),
				'min'     => 0,
				'max'     => 15,
				'step'    => 1,
				'default' => 5,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$length  = (float) ( $i['stove_length'] ?? 0 );
			$width   = (float) ( $i['stove_width'] ?? 0 );
			$depth   = (float) ( $i['depth'] ?? 0.5 );
			$reserve = (float) ( $i['reserve_pct'] ?? 5 );

			$found_length = $length + 0.10;
			$found_width  = $width + 0.10;
			$volume       = $found_length * $found_width * $depth * ( 1 + $reserve / 100 );

			$hints = array();

			$hints[] = __( 'Lay a 100–150 mm compacted sand-and-gravel cushion under the pad before pouring.', 'mvweb-fireplace-calc' );
			$hints[] = __( 'Reinforce the slab with a 200 mm mesh grid (rebar Ø8–12 mm, class A-III) to prevent cracking under the stove weight.', 'mvweb-fireplace-calc' );

			/* translators: %1$.2f — foundation length, %2$.2f — foundation width */
			$hints[] = sprintf(
				__( 'Foundation footprint: %.2f m × %.2f m — select the right stove or fireplace in the catalog.', 'mvweb-fireplace-calc' ),
				$found_length,
				$found_width
			);

			return array(
				'value' => $volume,
				'hints' => $hints,
			);
		},
	)
);
