<?php
/**
 * Calculator: tile grout for fireplace facing.
 *
 * Formula:
 *   W_grout = facing_area × consumption_rate
 *
 * Grout consumption rates (kg/m²) by tile size (joint width ~2–3 mm):
 *   200×200 mm  → 0.35 kg/m²
 *   250×200 mm  → 0.30 kg/m²
 *   Izrazets 220×220 mm → 0.32 kg/m²
 *   600×300 mm  → 0.20 kg/m²
 *
 * Source: manufacturer technical datasheets (Ceresit, Knauf), SNiP III-B.12.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'tile-grout',
	array(
		'title'       => __( 'Tile grout', 'mvweb-fireplace-calc' ),
		'hub'         => 'masonry',
		'description' => __( 'Calculates the amount of tile grout required for fireplace facing, based on facing area and tile size.', 'mvweb-fireplace-calc' ),
		'formula'     => 'W = facing_area × consumption_rate',
		'legend'      => array(
			'W'                => __( 'grout weight, kg', 'mvweb-fireplace-calc' ),
			'facing_area'      => __( 'total tile facing area, m²', 'mvweb-fireplace-calc' ),
			'consumption_rate' => __( 'grout consumption, kg/m² (depends on tile size)', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Grout weight', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'kg', 'mvweb-fireplace-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'facing_area' => array(
				'type'     => 'number',
				'label'    => __( 'Facing area', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
				'min'      => 0.5,
				'max'      => 30,
				'step'     => 0.1,
				'required' => true,
			),
			'tile_size'   => array(
				'type'    => 'select',
				'label'   => __( 'Tile size', 'mvweb-fireplace-calc' ),
				'default' => '200x200',
				'options' => array(
					'200x200'  => __( '200×200 mm', 'mvweb-fireplace-calc' ),
					'250x200'  => __( '250×200 mm', 'mvweb-fireplace-calc' ),
					'izrazets' => __( 'Izrazets 220×220 mm', 'mvweb-fireplace-calc' ),
					'600x300'  => __( '600×300 mm', 'mvweb-fireplace-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area     = (float) ( $i['facing_area'] ?? 0 );
			$tile_key = (string) ( $i['tile_size'] ?? '200x200' );

			$rates = array(
				'200x200'  => 0.35,
				'250x200'  => 0.30,
				'izrazets' => 0.32,
				'600x300'  => 0.20,
			);

			$rate   = isset( $rates[ $tile_key ] ) ? $rates[ $tile_key ] : 0.35;
			$weight = $area * $rate;
			$bags   = (int) ceil( $weight / 2 );

			$hints = array();

			/* translators: %1$.2f — rate kg/m², %2$d — number of 2 kg bags */
			$hints[] = sprintf(
				__( 'Consumption rate for selected tile: %.2f kg/m². Approximately %d packs of 2 kg.', 'mvweb-fireplace-calc' ),
				$rate,
				$bags
			);

			$hints[] = __( 'Use heat-resistant grout rated for at least 200 °C for areas directly around the firebox opening.', 'mvweb-fireplace-calc' );

			if ( 'izrazets' === $tile_key ) {
				$hints[] = __( 'For izrazets a coloured clay-based grout is traditional. Verify compatibility with the specific tile glaze.', 'mvweb-fireplace-calc' );
			}

			return array(
				'value' => $weight,
				'hints' => $hints,
			);
		},
	)
);
