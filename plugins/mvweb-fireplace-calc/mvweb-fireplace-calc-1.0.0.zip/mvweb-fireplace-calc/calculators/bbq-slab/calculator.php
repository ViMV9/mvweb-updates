<?php
/**
 * Calculator: concrete slab volume for a barbecue area.
 *
 * Formula: V = area × thickness
 * Minimum recommended thickness for a heavy outdoor complex:
 * 150 mm per SP 63.13330.2018 §8.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'bbq-slab',
	array(
		'title'       => __( 'Slab for a barbecue area', 'mvweb-fireplace-calc' ),
		'hub'         => 'foundation',
		'description' => __( 'Calculates the concrete volume for a flat poured slab used as a barbecue patio or outdoor kitchen area.', 'mvweb-fireplace-calc' ),
		'formula'     => 'V = area × thickness',
		'legend'      => array(
			'V'         => __( 'concrete volume, m³', 'mvweb-fireplace-calc' ),
			'area'      => __( 'slab area, m²', 'mvweb-fireplace-calc' ),
			'thickness' => __( 'slab thickness, m', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Concrete volume', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'm³', 'mvweb-fireplace-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'area'      => array(
				'type'     => 'number',
				'label'    => __( 'Slab area', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
				'min'      => 1,
				'max'      => 100,
				'step'     => 0.5,
				'required' => true,
			),
			'thickness' => array(
				'type'     => 'number',
				'label'    => __( 'Slab thickness', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.05,
				'max'      => 0.4,
				'step'     => 0.01,
				'default'  => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area      = (float) ( $i['area'] ?? 0 );
			$thickness = (float) ( $i['thickness'] ?? 0.1 );

			$volume = $area * $thickness;

			$hints = array();

			if ( $thickness < 0.15 ) {
				$hints[] = __( 'For areas supporting a heavy barbecue complex a slab thickness of at least 0.15 m is recommended to prevent cracking under load.', 'mvweb-fireplace-calc' );
			}

			$hints[] = __( 'Use concrete class B20 (M250) or higher for outdoor slabs exposed to freeze-thaw cycles.', 'mvweb-fireplace-calc' );

			/* translators: %1$.2f — concrete volume */
			$hints[] = sprintf(
				__( 'Order %.2f m³ of concrete — contact us to help plan your barbecue area.', 'mvweb-fireplace-calc' ),
				$volume
			);

			return array(
				'value' => $volume,
				'hints' => $hints,
			);
		},
	)
);
