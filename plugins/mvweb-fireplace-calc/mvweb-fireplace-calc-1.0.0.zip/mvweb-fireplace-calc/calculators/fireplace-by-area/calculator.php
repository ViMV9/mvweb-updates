<?php
/**
 * Calculator: fireplace power by room area.
 *
 * Formula:
 *   Standard ceiling (≤2.7 m): P = area / 10
 *   High ceiling (>2.7 m):     P = (area × 3.0) / 25
 * Base norm: 1 kW per 10 m² for standard rooms,
 * volume method for high-ceiling rooms (assumed 3.0 m).
 *
 * Source: Common Russian practice for fireplace sizing,
 * reference norm SP 50.13330.2012.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'fireplace-by-area',
	array(
		'title'       => __( 'Fireplace power by area', 'mvweb-fireplace-calc' ),
		'hub'         => 'heating',
		'description' => __( 'Quick estimate of required fireplace output from floor area and ceiling height category.', 'mvweb-fireplace-calc' ),
		'formula'     => 'P = area / 10  (standard)  |  P = (area × 3.0) / 25  (high ceiling)',
		'legend'      => array(
			'P'    => __( 'required fireplace power, kW', 'mvweb-fireplace-calc' ),
			'area' => __( 'room area, m²', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Required fireplace power', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'kW', 'mvweb-fireplace-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'area'    => array(
				'type'     => 'number',
				'label'    => __( 'Room area', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
				'min'      => 1,
				'max'      => 500,
				'step'     => 1,
				'required' => true,
			),
			'ceiling' => array(
				'type'       => 'radio',
				'label'      => __( 'Ceiling height', 'mvweb-fireplace-calc' ),
				'default'    => 'standard',
				'full_width' => true,
				'options'    => array(
					'standard' => __( 'Standard (up to 2.7 m)', 'mvweb-fireplace-calc' ),
					'high'     => __( 'High (above 2.7 m)', 'mvweb-fireplace-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area    = (float) ( $i['area'] ?? 0 );
			$ceiling = (string) ( $i['ceiling'] ?? 'standard' );

			if ( 'high' === $ceiling ) {
				$power = ( $area * 3.0 ) / 25;
			} else {
				$power = $area / 10;
			}

			$hints = array();

			if ( 'high' === $ceiling ) {
				$hints[] = __( 'Calculation uses an assumed ceiling height of 3.0 m. For more precision use the "Firebox power" calculator with exact height.', 'mvweb-fireplace-calc' );
			}

			/* translators: %1$.1f — calculated power range low, %2$.1f — range high */
			$hints[] = sprintf(
				__( 'Recommended fireplace output %.1f–%.1f kW — browse the catalog to find the right model.', 'mvweb-fireplace-calc' ),
				$power * 0.9,
				$power * 1.1
			);

			return array(
				'value' => $power,
				'hints' => $hints,
			);
		},
	)
);
