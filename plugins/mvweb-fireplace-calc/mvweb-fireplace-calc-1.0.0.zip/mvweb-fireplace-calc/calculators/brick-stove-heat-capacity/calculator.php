<?php
/**
 * Calculator: brick stove heat output and thermal mass.
 *
 * Formula:
 *   Q   = mirror_area × 350     (heat output, W)
 *   E   = mass × 0.88 × ΔT     (stored energy, kJ; ΔT assumed 150°C heating cycle)
 *   t_h = E / (Q / 1000 × 3600) (estimated hours of warmth after firing, h)
 *
 * Specific heat capacity of fired brick: ~0.88 kJ/(kg·°C).
 * ΔT = 150°C — typical brick temperature rise during a standard firing.
 * The main result (value) is heat output in kW; thermal mass info goes in hints.
 *
 * Source: Bubnov V.A. "Stoves and fireplaces" (2011),
 * thermophysical properties of clay brick per GOST 530-2012.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'brick-stove-heat-capacity',
	array(
		'title'       => __( 'Brick stove heat capacity', 'mvweb-fireplace-calc' ),
		'hub'         => 'heating',
		'description' => __( 'Calculates the heat output of a brick stove and estimates heat retention time based on the stove mass.', 'mvweb-fireplace-calc' ),
		'formula'     => 'Q = mirror × 350;  t = (mass × 0.88 × 150) / (Q × 3.6)',
		'legend'      => array(
			'Q'      => __( 'heat output, kW', 'mvweb-fireplace-calc' ),
			'mirror' => __( 'stove mirror (radiating surface), m²', 'mvweb-fireplace-calc' ),
			'350'    => __( 'specific heat emission of brick surface, W/m²', 'mvweb-fireplace-calc' ),
			'mass'   => __( 'total stove mass, kg', 'mvweb-fireplace-calc' ),
			'0.88'   => __( 'specific heat capacity of fired brick, kJ/(kg·°C)', 'mvweb-fireplace-calc' ),
			't'      => __( 'estimated heat retention time, hours', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Heat output', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'kW', 'mvweb-fireplace-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'mass'        => array(
				'type'     => 'number',
				'label'    => __( 'Stove mass', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'kg', 'mvweb-fireplace-calc' ),
				'min'      => 200,
				'max'      => 5000,
				'step'     => 10,
				'required' => true,
			),
			'mirror_area' => array(
				'type'     => 'number',
				'label'    => __( 'Stove mirror area', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
				'min'      => 0.5,
				'max'      => 20,
				'step'     => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$mass   = (float) ( $i['mass'] ?? 0 );
			$mirror = (float) ( $i['mirror_area'] ?? 0 );

			$heat_w  = $mirror * 350;
			$heat_kw = $heat_w / 1000;

			$delta_t    = 150.0;
			$energy_kj  = $mass * 0.88 * $delta_t;
			$retain_h   = ( $heat_kw > 0 ) ? ( $energy_kj / ( $heat_kw * 3600 ) ) : 0;

			$hints = array();

			/* translators: %1$.1f — retention hours */
			$hints[] = sprintf(
				__( 'After one standard firing this stove retains heat for approximately %.1f hours.', 'mvweb-fireplace-calc' ),
				$retain_h
			);

			if ( $mass < 500 ) {
				$hints[] = __( 'A lighter stove heats up faster but cools down quicker. For long-lasting warmth aim for at least 700–800 kg.', 'mvweb-fireplace-calc' );
			} elseif ( $mass > 2000 ) {
				$hints[] = __( 'A heavy stove stores a large amount of heat and keeps the room warm all day from a single morning firing.', 'mvweb-fireplace-calc' );
			}

			/* translators: %1$.1f — output kW */
			$hints[] = sprintf(
				__( 'Stove output %.1f kW — view matching brick stove projects in the catalog.', 'mvweb-fireplace-calc' ),
				$heat_kw
			);

			return array(
				'value' => $heat_kw,
				'hints' => $hints,
			);
		},
	)
);
