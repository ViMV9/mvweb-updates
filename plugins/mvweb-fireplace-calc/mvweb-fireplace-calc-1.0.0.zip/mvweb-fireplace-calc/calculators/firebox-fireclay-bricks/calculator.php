<?php
/**
 * Calculator: fireclay bricks for firebox lining.
 *
 * Formula:
 *   N = (chamber_area / 0.0262) × 1.10
 *
 * Brick: SHB-5 (ШБ-5), face size 230×114 mm = 0.02622 m².
 * Factor 1.10 accounts for cutting losses and mortar joints (~10%).
 *
 * Source: GOST 390-2018 (fireclay refractory bricks),
 * standard firebox lining practice for masonry stoves and fireplaces.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'firebox-fireclay-bricks',
	array(
		'title'       => __( 'Fireclay bricks for firebox', 'mvweb-fireplace-calc' ),
		'hub'         => 'masonry',
		'description' => __( 'Calculates the number of SHB-5 fireclay bricks required to line a firebox chamber.', 'mvweb-fireplace-calc' ),
		'formula'     => 'N = (chamber_area / 0.0262) × 1.10',
		'legend'      => array(
			'N'            => __( 'number of fireclay bricks', 'mvweb-fireplace-calc' ),
			'chamber_area' => __( 'total lining area of the firebox, m²', 'mvweb-fireplace-calc' ),
			'0.0262'       => __( 'face area of one SHB-5 brick (230×114 mm), m²', 'mvweb-fireplace-calc' ),
			'1.10'         => __( '10% reserve for cutting and joints', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Fireclay bricks', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'pcs', 'mvweb-fireplace-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'chamber_area' => array(
				'type'     => 'number',
				'label'    => __( 'Firebox lining area', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
				'min'      => 0.2,
				'max'      => 10,
				'step'     => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area         = (float) ( $i['chamber_area'] ?? 0 );
			$brick_face   = 0.230 * 0.114;
			$bricks       = ( $area / $brick_face ) * 1.10;

			$hints = array();

			/* translators: %d — net count without reserve */
			$hints[] = sprintf(
				__( 'Net count without reserve: %d pcs (SHB-5, 230×114 mm face).', 'mvweb-fireplace-calc' ),
				(int) round( $area / $brick_face )
			);

			$hints[] = __( 'Lay fireclay bricks on fireclay (chamotte) mortar, not on regular clay mortar. Do not bond fireclay lining rigidly to the outer brick shell — leave a 5 mm expansion gap.', 'mvweb-fireplace-calc' );

			$hints[] = __( 'To find chamber area: sum all inner surfaces (floor, back wall, side walls, ceiling) that require lining.', 'mvweb-fireplace-calc' );

			return array(
				'value' => $bricks,
				'hints' => $hints,
			);
		},
	)
);
