<?php
/**
 * Calculator: wood pellet consumption for the heating season.
 *
 * Formula: Q = power × 24 × season_days [kWh]; M = Q / (4.8 × efficiency / 100) [kg]
 * Calorific value of wood pellets: ~4.8 kWh/kg (EN ISO 17225-2 grade A1).
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'pellets-consumption',
	array(
		'title'       => __( 'Pellet consumption', 'mvweb-fireplace-calc' ),
		'hub'         => 'fuel',
		'description' => __( 'Calculates wood pellet mass required for a full heating season for a pellet stove or boiler.', 'mvweb-fireplace-calc' ),
		'formula'     => 'M = (P × 24 × D) / (4.8 × η / 100)',
		'legend'      => array(
			'M'   => __( 'pellet mass, kg', 'mvweb-fireplace-calc' ),
			'P'   => __( 'average heat load, kW', 'mvweb-fireplace-calc' ),
			'D'   => __( 'heating season duration, days', 'mvweb-fireplace-calc' ),
			'4.8' => __( 'calorific value of pellets, kWh/kg', 'mvweb-fireplace-calc' ),
			'η'   => __( 'appliance efficiency, %', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Pellets per season', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'kg', 'mvweb-fireplace-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'power'       => array(
				'type'     => 'number',
				'label'    => __( 'Average heat load', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'kW', 'mvweb-fireplace-calc' ),
				'min'      => 1,
				'max'      => 50,
				'step'     => 0.5,
				'required' => true,
			),
			'efficiency'  => array(
				'type'     => 'number',
				'label'    => __( 'Appliance efficiency', 'mvweb-fireplace-calc' ),
				'unit'     => __( '%', 'mvweb-fireplace-calc' ),
				'min'      => 70,
				'max'      => 95,
				'step'     => 1,
				'default'  => 85,
				'required' => true,
			),
			'season_days' => array(
				'type'     => 'number',
				'label'    => __( 'Heating season duration', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'days', 'mvweb-fireplace-calc' ),
				'min'      => 30,
				'max'      => 250,
				'step'     => 1,
				'default'  => 180,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$power       = (float) ( $i['power'] ?? 0 );
			$efficiency  = (float) ( $i['efficiency'] ?? 85 );
			$season_days = (float) ( $i['season_days'] ?? 180 );

			$heat_kwh = $power * 24.0 * $season_days;
			$mass_kg  = $heat_kwh / ( 4.8 * ( $efficiency / 100.0 ) );

			$kg_per_day = ( $season_days > 0 ) ? ( $mass_kg / $season_days ) : 0;
			$tonnes     = $mass_kg / 1000.0;
			$bags_15    = (int) ceil( $mass_kg / 15.0 );

			$hints   = array();
			$hints[] = sprintf(
				/* translators: kg per day value */
				__( 'Daily consumption: approximately %.1f kg/day.', 'mvweb-fireplace-calc' ),
				$kg_per_day
			);
			$hints[] = sprintf(
				/* translators: 1: tonnes, 2: number of 15 kg bags */
				__( 'That equals %.2f tonnes or %d bags of 15 kg — order in bulk to reduce the per-kg price.', 'mvweb-fireplace-calc' ),
				$tonnes,
				$bags_15
			);

			return array(
				'value' => $mass_kg,
				'hints' => $hints,
			);
		},
	)
);
