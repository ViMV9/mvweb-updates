<?php
/**
 * Calculator: sauna stove power.
 *
 * Formula: P = volume × 1 + glazing_add
 *   Base norm: 1 kW per m³ of steam room volume.
 *   Glazing surcharge (glass doors/windows lose heat faster):
 *     none  → +0 kW
 *     small → +0.5 kW  (small glass door or porthole)
 *     large → +1.5 kW  (full glass door or panoramic window)
 *
 * Source: STO NOSTROY 2.21.2-2014 "Construction of saunas and bath complexes",
 * sauna stove manufacturer sizing guidelines (Harvia, Narvi).
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'bath-stove-power',
	array(
		'title'       => __( 'Sauna stove power', 'mvweb-fireplace-calc' ),
		'hub'         => 'heating',
		'description' => __( 'Calculates the required sauna (bath) stove output based on steam room volume and glazing.', 'mvweb-fireplace-calc' ),
		'formula'     => 'P = V × 1 + glazing_add',
		'legend'      => array(
			'P'           => __( 'required stove power, kW', 'mvweb-fireplace-calc' ),
			'V'           => __( 'steam room volume, m³', 'mvweb-fireplace-calc' ),
			'glazing_add' => __( 'glazing surcharge: none=0, small=+0.5, large=+1.5 kW', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Required stove power', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'kW', 'mvweb-fireplace-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'volume'  => array(
				'type'     => 'number',
				'label'    => __( 'Steam room volume', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm³', 'mvweb-fireplace-calc' ),
				'min'      => 2,
				'max'      => 40,
				'step'     => 0.5,
				'required' => true,
			),
			'glazing' => array(
				'type'    => 'radio',
				'label'   => __( 'Glazing', 'mvweb-fireplace-calc' ),
				'default' => 'none',
				'options' => array(
					'none'  => __( 'None (solid wooden door)', 'mvweb-fireplace-calc' ),
					'small' => __( 'Small (glass insert or porthole)', 'mvweb-fireplace-calc' ),
					'large' => __( 'Large (full glass door or window)', 'mvweb-fireplace-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$volume  = (float) ( $i['volume'] ?? 0 );
			$glazing = (string) ( $i['glazing'] ?? 'none' );

			$glazing_add = array(
				'none'  => 0.0,
				'small' => 0.5,
				'large' => 1.5,
			);
			$add   = $glazing_add[ $glazing ] ?? 0.0;
			$power = $volume * 1.0 + $add;

			$hints = array();

			if ( 'large' === $glazing ) {
				$hints[] = __( 'Large glazing significantly increases heat loss. Consider double-glazed sauna glass for better efficiency.', 'mvweb-fireplace-calc' );
			}

			if ( $volume > 20 ) {
				$hints[] = __( 'For steam rooms above 20 m³ a two-stage heating approach or a stove with a large stone basket is recommended.', 'mvweb-fireplace-calc' );
			}

			/* translators: %1$.1f — recommended power range low, %2$.1f — range high */
			$hints[] = sprintf(
				__( 'Choose a sauna stove rated %.1f–%.1f kW — browse the catalog for bath stove models.', 'mvweb-fireplace-calc' ),
				$power,
				$power * 1.15
			);

			return array(
				'value' => $power,
				'hints' => $hints,
			);
		},
	)
);
