<?php
/**
 * Calculator: firebox power for room heating.
 *
 * Formula: P = (area × ceiling_height) / 25 × K
 * where K is insulation coefficient (good=0.8, average=1.0, poor=1.4).
 * Base norm: 1 kW per 25 m³ of room volume, adjusted for insulation quality.
 *
 * Source: SP 50.13330.2012 "Building heat protection" (Russia),
 * standard specific heat load 1 kW/25 m³ for residential premises.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'firebox-power',
	array(
		'title'       => __( 'Firebox power', 'mvweb-fireplace-calc' ),
		'hub'         => 'heating',
		'description' => __( 'Calculates the required firebox output based on room area, ceiling height, and insulation quality.', 'mvweb-fireplace-calc' ),
		'formula'     => 'P = (area × H) / 25 × K',
		'legend'      => array(
			'P'    => __( 'required firebox power, kW', 'mvweb-fireplace-calc' ),
			'area' => __( 'room area, m²', 'mvweb-fireplace-calc' ),
			'H'    => __( 'ceiling height, m', 'mvweb-fireplace-calc' ),
			'K'    => __( 'insulation coefficient (good=0.8, average=1.0, poor=1.4)', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Required firebox power', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'kW', 'mvweb-fireplace-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'area'          => array(
				'type'     => 'number',
				'label'    => __( 'Room area', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
				'min'      => 1,
				'max'      => 1000,
				'step'     => 1,
				'required' => true,
			),
			'ceiling_height' => array(
				'type'     => 'number',
				'label'    => __( 'Ceiling height', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 2,
				'max'      => 5,
				'step'     => 0.1,
				'default'  => 2.7,
				'required' => true,
			),
			'insulation'    => array(
				'type'    => 'radio',
				'label'   => __( 'Insulation quality', 'mvweb-fireplace-calc' ),
				'default' => 'average',
				'options' => array(
					'good'    => __( 'Good (modern insulation)', 'mvweb-fireplace-calc' ),
					'average' => __( 'Average (standard construction)', 'mvweb-fireplace-calc' ),
					'poor'    => __( 'Poor (old building, no insulation)', 'mvweb-fireplace-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area    = (float) ( $i['area'] ?? 0 );
			$ceiling = (float) ( $i['ceiling_height'] ?? 2.7 );
			$ins     = (string) ( $i['insulation'] ?? 'average' );

			$coefficients = array(
				'good'    => 0.8,
				'average' => 1.0,
				'poor'    => 1.4,
			);
			$k = $coefficients[ $ins ] ?? 1.0;

			$volume = $area * $ceiling;
			$power  = ( $volume / 25 ) * $k;

			$hints = array();

			if ( $power > 20 ) {
				$hints[] = __( 'For large spaces over 20 kW consider multiple heating zones or a combined heating system.', 'mvweb-fireplace-calc' );
			}

			/* translators: %1$.1f — calculated power range low, %2$.1f — range high */
			$hints[] = sprintf(
				__( 'Recommended firebox power %.1f–%.1f kW — see the catalog for suitable fireplace inserts.', 'mvweb-fireplace-calc' ),
				$power * 0.9,
				$power * 1.1
			);

			return array(
				'value' => $power,
				'hints' => $hints,
			);
		},
	)
);
