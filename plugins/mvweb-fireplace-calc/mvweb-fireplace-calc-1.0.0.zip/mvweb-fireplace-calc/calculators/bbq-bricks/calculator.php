<?php
/**
 * Calculator: bricks for a barbecue.
 *
 * Formula:
 *   Perimeter = 2 × (L + W)
 *   V_masonry  = Perimeter × H × 0.12   (half-brick walls)
 *   N_bricks   = V_masonry × 394 × (1 + reserve_pct / 100)
 *
 * BBQ structures use half-brick (120 mm) walls throughout.
 * Brick density: 394 pcs/m³ (standard 250×120×65 mm with 10 mm joint).
 *
 * Source: GOST 530-2012, standard outdoor masonry practice.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'bbq-bricks',
	array(
		'title'       => __( 'Bricks for a barbecue', 'mvweb-fireplace-calc' ),
		'hub'         => 'masonry',
		'description' => __( 'Estimates the number of standard bricks for an outdoor barbecue structure (half-brick walls).', 'mvweb-fireplace-calc' ),
		'formula'     => 'N = 2 × (L + W) × H × 0.12 × 394 × (1 + reserve% / 100)',
		'legend'      => array(
			'N'        => __( 'number of bricks', 'mvweb-fireplace-calc' ),
			'L'        => __( 'barbecue length, m', 'mvweb-fireplace-calc' ),
			'W'        => __( 'barbecue width, m', 'mvweb-fireplace-calc' ),
			'H'        => __( 'barbecue height, m', 'mvweb-fireplace-calc' ),
			'reserve%' => __( 'reserve for cutting losses, %', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Number of bricks', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'pcs', 'mvweb-fireplace-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'length'      => array(
				'type'     => 'number',
				'label'    => __( 'Barbecue length', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.3,
				'max'      => 4,
				'step'     => 0.05,
				'required' => true,
			),
			'width'       => array(
				'type'     => 'number',
				'label'    => __( 'Barbecue width', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.3,
				'max'      => 3,
				'step'     => 0.05,
				'required' => true,
			),
			'height'      => array(
				'type'     => 'number',
				'label'    => __( 'Barbecue height', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm', 'mvweb-fireplace-calc' ),
				'min'      => 0.3,
				'max'      => 3,
				'step'     => 0.05,
				'required' => true,
			),
			'reserve_pct' => array(
				'type'    => 'number',
				'label'   => __( 'Reserve for cutting losses', 'mvweb-fireplace-calc' ),
				'unit'    => __( '%', 'mvweb-fireplace-calc' ),
				'min'     => 0,
				'max'     => 15,
				'step'    => 1,
				'default' => 7,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$length  = (float) ( $i['length'] ?? 0 );
			$width   = (float) ( $i['width'] ?? 0 );
			$height  = (float) ( $i['height'] ?? 0 );
			$reserve = (float) ( $i['reserve_pct'] ?? 7 );

			$perimeter = 2 * ( $length + $width );
			$volume    = $perimeter * $height * 0.12;
			$bricks    = $volume * 394 * ( 1 + $reserve / 100 );

			$hints = array();

			if ( $reserve < 5 ) {
				$hints[] = __( 'For outdoor structures a minimum 7% reserve is recommended due to angled cuts at the firebox opening.', 'mvweb-fireplace-calc' );
			}

			/* translators: %d — number of bricks without reserve */
			$hints[] = sprintf(
				__( 'Net quantity without reserve: %d pcs. Order with reserve to avoid a second delivery.', 'mvweb-fireplace-calc' ),
				(int) round( $volume * 394 )
			);

			$hints[] = __( 'For the firebox lining use fireclay (chamotte) bricks — use the "Fireclay bricks for firebox" calculator for that estimate.', 'mvweb-fireplace-calc' );

			return array(
				'value' => $bricks,
				'hints' => $hints,
			);
		},
	)
);
