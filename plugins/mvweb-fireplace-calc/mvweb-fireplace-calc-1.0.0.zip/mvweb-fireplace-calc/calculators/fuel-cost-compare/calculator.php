<?php
/**
 * Calculator: fuel cost comparison per kWh of heat.
 *
 * Calorific values used:
 *   Firewood (dry birch)  3000 kWh/m³
 *   Wood pellets          4.8  kWh/kg
 *   Natural gas           9.3  kWh/m³
 *   Electricity           1.0  kWh/kWh (direct conversion, η = 1)
 *
 * All costs are expressed as ₽ per useful kWh (η assumed equal for a fair
 * apples-to-apples comparison; efficiency adjustment can be done separately).
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'fuel-cost-compare',
	array(
		'title'       => __( 'Fuel cost comparison', 'mvweb-fireplace-calc' ),
		'hub'         => 'fuel',
		'description' => __( 'Compares the cost per kWh of heat for four common fuel types to identify the most economical option for your heating season budget.', 'mvweb-fireplace-calc' ),
		'formula'     => 'Cost = price_fuel / calorific_value_fuel',
		'legend'      => array(
			'Cost'              => __( '₽ per kWh of heat', 'mvweb-fireplace-calc' ),
			'price_fuel'        => __( 'price per unit of fuel', 'mvweb-fireplace-calc' ),
			'calorific_value'   => __( 'energy content per unit: firewood 3000 kWh/m³, pellets 4.8 kWh/kg, gas 9.3 kWh/m³, electricity 1 kWh/kWh', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Cheapest fuel cost', 'mvweb-fireplace-calc' ),
			'unit'     => __( '₽/kWh', 'mvweb-fireplace-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'heat_demand'       => array(
				'type'     => 'number',
				'label'    => __( 'Heat demand per season', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'kWh', 'mvweb-fireplace-calc' ),
				'min'      => 1000,
				'max'      => 100000,
				'step'     => 500,
				'required' => true,
			),
			'price_wood'        => array(
				'type'    => 'number',
				'label'   => __( 'Firewood price', 'mvweb-fireplace-calc' ),
				'unit'    => __( '₽/m³', 'mvweb-fireplace-calc' ),
				'min'     => 0,
				'max'     => 10000,
				'step'    => 100,
				'default' => 2500,
			),
			'price_pellets'     => array(
				'type'    => 'number',
				'label'   => __( 'Pellet price', 'mvweb-fireplace-calc' ),
				'unit'    => __( '₽/kg', 'mvweb-fireplace-calc' ),
				'min'     => 0,
				'max'     => 100,
				'step'    => 0.5,
				'default' => 18,
			),
			'price_gas'         => array(
				'type'    => 'number',
				'label'   => __( 'Natural gas price', 'mvweb-fireplace-calc' ),
				'unit'    => __( '₽/m³', 'mvweb-fireplace-calc' ),
				'min'     => 0,
				'max'     => 50,
				'step'    => 0.1,
				'default' => 8,
			),
			'price_electricity' => array(
				'type'    => 'number',
				'label'   => __( 'Electricity price', 'mvweb-fireplace-calc' ),
				'unit'    => __( '₽/kWh', 'mvweb-fireplace-calc' ),
				'min'     => 0,
				'max'     => 20,
				'step'    => 0.1,
				'default' => 5.5,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$heat_demand       = (float) ( $i['heat_demand'] ?? 0 );
			$price_wood        = (float) ( $i['price_wood'] ?? 2500 );
			$price_pellets     = (float) ( $i['price_pellets'] ?? 18 );
			$price_gas         = (float) ( $i['price_gas'] ?? 8 );
			$price_electricity = (float) ( $i['price_electricity'] ?? 5.5 );

			$cost_wood        = ( 3000.0 > 0 ) ? $price_wood / 3000.0 : 0;
			$cost_pellets     = ( 4.8 > 0 )    ? $price_pellets / 4.8  : 0;
			$cost_gas         = ( 9.3 > 0 )    ? $price_gas / 9.3      : 0;
			$cost_electricity = $price_electricity;

			$costs = array(
				__( 'Firewood', 'mvweb-fireplace-calc' )    => $cost_wood,
				__( 'Pellets', 'mvweb-fireplace-calc' )     => $cost_pellets,
				__( 'Natural gas', 'mvweb-fireplace-calc' ) => $cost_gas,
				__( 'Electricity', 'mvweb-fireplace-calc' ) => $cost_electricity,
			);

			$min_cost = min( $costs );
			$cheapest = array_search( $min_cost, $costs, true );

			$hints   = array();
			$lines   = array();

			foreach ( $costs as $label => $cost_per_kwh ) {
				$season_cost = $heat_demand * $cost_per_kwh;
				$lines[]     = sprintf(
					/* translators: 1: fuel name, 2: ₽/kWh, 3: season total ₽ */
					__( '%1$s: ₽%2$.2f/kWh — season total ₽%3$s', 'mvweb-fireplace-calc' ),
					$label,
					$cost_per_kwh,
					number_format( $season_cost, 0, '.', ' ' )
				);
			}

			$hints[] = implode( '; ', $lines ) . '.';
			$hints[] = sprintf(
				/* translators: cheapest fuel name */
				__( '%s is the most cost-effective option at the prices entered. Consider whole-season delivery to lock in the price.', 'mvweb-fireplace-calc' ),
				$cheapest
			);

			return array(
				'value' => $min_cost,
				'hints' => $hints,
			);
		},
	)
);
