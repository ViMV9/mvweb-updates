<?php
/**
 * Calculator: house heat loss estimate.
 *
 * Formula: Q = area × q × (ΔT / ΔT_base)
 *   q      — specific heat loss per m² by wall material, W/m² (at base ΔT)
 *   ΔT     — design temperature difference: T_indoor(20°C) − T_outdoor
 *   ΔT_base = 45°C (20°C indoor − (−25°C) outdoor reference)
 *
 * Specific heat loss values (W/m² at ΔT=45°C):
 *   brick          100 W/m²
 *   aerated_concrete 80 W/m²
 *   wood            90 W/m²
 *   frame           70 W/m²
 *
 * Source: SP 50.13330.2012 "Building heat protection",
 * SP 131.13330.2020 "Construction climatology" (outdoor design temps).
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'house-heat-loss',
	array(
		'title'       => __( 'House heat loss', 'mvweb-fireplace-calc' ),
		'hub'         => 'heating',
		'description' => __( 'Estimates total building heat loss based on floor area, wall material, and outdoor design temperature.', 'mvweb-fireplace-calc' ),
		'formula'     => 'Q = area × q × (ΔT / 45)',
		'legend'      => array(
			'Q'    => __( 'total heat loss, kW', 'mvweb-fireplace-calc' ),
			'area' => __( 'floor area, m²', 'mvweb-fireplace-calc' ),
			'q'    => __( 'specific heat loss by wall material, W/m²', 'mvweb-fireplace-calc' ),
			'ΔT'   => __( 'design temperature difference, °C', 'mvweb-fireplace-calc' ),
			'45'   => __( 'base ΔT (indoor 20°C − outdoor −25°C)', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Total heat loss', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'kW', 'mvweb-fireplace-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'area'          => array(
				'type'     => 'number',
				'label'    => __( 'Floor area', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
				'min'      => 10,
				'max'      => 1000,
				'step'     => 1,
				'required' => true,
			),
			'wall_material' => array(
				'type'    => 'select',
				'label'   => __( 'Wall material', 'mvweb-fireplace-calc' ),
				'default' => 'brick',
				'options' => array(
					'brick'            => __( 'Brick', 'mvweb-fireplace-calc' ),
					'aerated_concrete' => __( 'Aerated concrete (gas block)', 'mvweb-fireplace-calc' ),
					'wood'             => __( 'Wood (log or timber frame)', 'mvweb-fireplace-calc' ),
					'frame'            => __( 'Frame construction (insulated)', 'mvweb-fireplace-calc' ),
				),
			),
			'outdoor_temp'  => array(
				'type'     => 'number',
				'label'    => __( 'Outdoor design temperature', 'mvweb-fireplace-calc' ),
				'unit'     => __( '°C', 'mvweb-fireplace-calc' ),
				'min'      => -45,
				'max'      => 0,
				'step'     => 1,
				'default'  => -25,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area     = (float) ( $i['area'] ?? 0 );
			$material = (string) ( $i['wall_material'] ?? 'brick' );
			$t_out    = (float) ( $i['outdoor_temp'] ?? -25 );

			$specific = array(
				'brick'            => 100.0,
				'aerated_concrete' => 80.0,
				'wood'             => 90.0,
				'frame'            => 70.0,
			);
			$q = $specific[ $material ] ?? 100.0;

			$t_indoor  = 20.0;
			$delta_t   = $t_indoor - $t_out;
			$delta_base = 45.0;

			$heat_loss_w  = $area * $q * ( $delta_t / $delta_base );
			$heat_loss_kw = $heat_loss_w / 1000;

			$hints = array();

			if ( 'brick' === $material ) {
				$hints[] = __( 'Brick walls have high thermal mass but moderate insulation. Adding external insulation can cut heat loss by 25–35%.', 'mvweb-fireplace-calc' );
			} elseif ( 'frame' === $material ) {
				$hints[] = __( 'Frame construction offers excellent insulation-to-cost ratio. Verify insulation thickness meets local building code.', 'mvweb-fireplace-calc' );
			}

			/* translators: %1$.1f — heat loss kW */
			$hints[] = sprintf(
				__( 'Your heating system must cover %.1f kW of heat loss — see the catalog for fireplace inserts and stoves of matching output.', 'mvweb-fireplace-calc' ),
				$heat_loss_kw
			);

			return array(
				'value' => $heat_loss_kw,
				'hints' => $hints,
			);
		},
	)
);
