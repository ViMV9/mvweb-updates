<?php
/**
 * Calculator: stove mirror area and size by heating area.
 *
 * Formula:
 *   P_required  = heating_area × 100          (W)  — 100 W/m² norm
 *   mirror_area = P_required / 350             (m²) — 350 W/m² radiation norm
 *
 * From mirror area approximate stove footprint:
 *   Assume aspect ratio ~1:1.5 (width × depth typical for Russian masonry stove).
 *   width = sqrt( mirror_area / 1.5 )
 *   depth = mirror_area / width
 *
 * Mass estimate: ~1300 kg/m² of mirror area (empirical norm for brick stoves).
 *
 * Sources:
 *   - SP 60.13330.2020 (heating norms, 100 W/m²)
 *   - Standard radiation norm 350 W/m² of stove mirror (Shkolnik, Stove heating, 1990)
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'stove-size-by-area',
	array(
		'title'       => __( 'Stove size by heating area', 'mvweb-fireplace-calc' ),
		'hub'         => 'masonry',
		'description' => __( 'Determines the required stove mirror area and approximate footprint dimensions from the room area to be heated.', 'mvweb-fireplace-calc' ),
		'formula'     => 'mirror = (area × 100) / 350',
		'legend'      => array(
			'mirror'  => __( 'recommended stove mirror area, m²', 'mvweb-fireplace-calc' ),
			'area'    => __( 'room heating area, m²', 'mvweb-fireplace-calc' ),
			'100'     => __( 'heating norm, W/m²', 'mvweb-fireplace-calc' ),
			'350'     => __( 'stove radiation norm, W/m² of mirror', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended mirror area', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'heating_area' => array(
				'type'     => 'number',
				'label'    => __( 'Heating area', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'm²', 'mvweb-fireplace-calc' ),
				'min'      => 5,
				'max'      => 120,
				'step'     => 1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area         = (float) ( $i['heating_area'] ?? 0 );
			$power_w      = $area * 100;
			$mirror       = $power_w / 350;

			$width  = sqrt( $mirror / 1.5 );
			$depth  = $mirror / $width;
			$mass   = round( $mirror * 1300 );

			$hints = array();

			/* translators: %1$.2f — mirror area m², %2$.0f — power W */
			$hints[] = sprintf(
				__( 'Required heat output: %2$.0f W. Mirror area: %1$.2f m².', 'mvweb-fireplace-calc' ),
				$mirror,
				$power_w
			);

			/* translators: %1$.2f — width m, %2$.2f — depth m */
			$hints[] = sprintf(
				__( 'Approximate stove footprint (1:1.5 ratio): %.2f m × %.2f m.', 'mvweb-fireplace-calc' ),
				$width,
				$depth
			);

			/* translators: %d — estimated stove mass kg */
			$hints[] = sprintf(
				__( 'Estimated stove mass: ~%d kg — verify floor load capacity before construction.', 'mvweb-fireplace-calc' ),
				(int) $mass
			);

			$hints[] = __( 'The mirror area is the outer surface of the stove body that radiates heat. For multi-room heating increase the calculated value by 20–30%.', 'mvweb-fireplace-calc' );

			return array(
				'value' => $mirror,
				'hints' => $hints,
			);
		},
	)
);
