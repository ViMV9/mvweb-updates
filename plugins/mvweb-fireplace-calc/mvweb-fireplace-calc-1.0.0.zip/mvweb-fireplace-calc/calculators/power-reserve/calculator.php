<?php
/**
 * Calculator: power reserve for heating systems.
 *
 * Formula: P_total = P_base × (1 + reserve% / 100)
 * A power reserve compensates for extreme cold snaps, heat losses
 * not accounted in base calculation, and equipment degradation over time.
 * Recommended reserve: 20–25% for fireplaces and stoves.
 *
 * Source: Common engineering practice for heating system design,
 * SP 60.13330.2020 "Heating, ventilation and air conditioning".
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'power-reserve',
	array(
		'title'       => __( 'Power reserve', 'mvweb-fireplace-calc' ),
		'hub'         => 'heating',
		'description' => __( 'Adds an engineering reserve to the base heating power to cover extreme conditions and calculation margins.', 'mvweb-fireplace-calc' ),
		'formula'     => 'P = P_base × (1 + reserve% / 100)',
		'legend'      => array(
			'P'        => __( 'required power with reserve, kW', 'mvweb-fireplace-calc' ),
			'P_base'   => __( 'base calculated power, kW', 'mvweb-fireplace-calc' ),
			'reserve%' => __( 'power reserve, %', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Power with reserve', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'kW', 'mvweb-fireplace-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'base_power'  => array(
				'type'     => 'number',
				'label'    => __( 'Base heating power', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'kW', 'mvweb-fireplace-calc' ),
				'min'      => 0.5,
				'max'      => 100,
				'step'     => 0.5,
				'required' => true,
			),
			'reserve_pct' => array(
				'type'    => 'number',
				'label'   => __( 'Power reserve', 'mvweb-fireplace-calc' ),
				'unit'    => __( '%', 'mvweb-fireplace-calc' ),
				'min'     => 0,
				'max'     => 50,
				'step'    => 1,
				'default' => 20,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$base    = (float) ( $i['base_power'] ?? 0 );
			$reserve = (float) ( $i['reserve_pct'] ?? 20 );

			$total = $base * ( 1 + $reserve / 100 );

			$hints = array();

			if ( $reserve < 15 ) {
				$hints[] = __( 'A reserve below 15% may be insufficient. A 20–25% reserve is recommended to handle extreme cold and account for calculation tolerances.', 'mvweb-fireplace-calc' );
			} elseif ( $reserve > 35 ) {
				$hints[] = __( 'A reserve above 35% often leads to oversized equipment that runs inefficiently at partial load. Consider 20–25% unless special conditions apply.', 'mvweb-fireplace-calc' );
			}

			/* translators: %1$.1f — total power, %2$.1f — base power */
			$hints[] = sprintf(
				__( 'Select a heating unit rated at least %.1f kW (base %.1f kW + reserve) — see the catalog.', 'mvweb-fireplace-calc' ),
				$total,
				$base
			);

			return array(
				'value' => $total,
				'hints' => $hints,
			);
		},
	)
);
