<?php
/**
 * Calculator: chimney cross-section area by firebox opening area.
 *
 * Formula: f = F / 10
 *
 * The empirical ratio 1:10 (chimney section to firebox portal area)
 * is the standard design rule for open fireplaces.
 *
 * Source: SP 7.13130.2013 section 5.4;
 * "Fireplaces" manual, NII Mosstroi, Moscow 1991, table 2.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_fc_register(
	'chimney-section-by-firebox',
	array(
		'title'       => __( 'Chimney section by firebox', 'mvweb-fireplace-calc' ),
		'hub'         => 'chimney',
		'description' => __( 'Calculates the required chimney cross-section area based on the firebox portal opening area using the standard 1:10 ratio.', 'mvweb-fireplace-calc' ),
		'formula'     => 'f = F / 10',
		'legend'      => array(
			'F' => __( 'firebox portal area, cm²', 'mvweb-fireplace-calc' ),
			'f' => __( 'required chimney cross-section area, cm²', 'mvweb-fireplace-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Required chimney cross-section', 'mvweb-fireplace-calc' ),
			'unit'     => __( 'cm²', 'mvweb-fireplace-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'firebox_area' => array(
				'type'     => 'number',
				'label'    => __( 'Firebox portal area', 'mvweb-fireplace-calc' ),
				'unit'     => __( 'cm²', 'mvweb-fireplace-calc' ),
				'min'      => 100,
				'max'      => 10000,
				'step'     => 10,
				'required' => true,
				'default'  => 1200,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$firebox_area   = (float) ( $i['firebox_area'] ?? 0 );
			$chimney_area   = $firebox_area / 10.0;
			$diameter_mm    = sqrt( 4.0 * $chimney_area / M_PI ) * 10.0;

			$hints = array();

			$hints[] = sprintf(
				__( 'Required cross-section: %.0f cm². Equivalent round diameter: %.0f mm. For a rectangular flue, keep the aspect ratio no greater than 1:1.5.', 'mvweb-fireplace-calc' ),
				$chimney_area,
				$diameter_mm
			);

			if ( $chimney_area < 200 ) {
				$hints[] = __( 'Cross-section under 200 cm² may restrict airflow for larger fireplaces. Verify against the appliance manufacturer specification.', 'mvweb-fireplace-calc' );
			}

			if ( $chimney_area > 1200 ) {
				$hints[] = __( 'A very large cross-section (> 1200 cm²) can reduce gas velocity and draft. Consider splitting into two separate flue channels.', 'mvweb-fireplace-calc' );
			}

			return array(
				'value' => round( $chimney_area ),
				'hints' => $hints,
			);
		},
	)
);
