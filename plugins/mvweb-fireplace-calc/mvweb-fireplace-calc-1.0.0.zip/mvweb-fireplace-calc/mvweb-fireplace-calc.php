<?php
/**
 * Plugin Name:       MVweb Fireplace Calc
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-fireplace-calc
 * Description:       Fireplace, stove, chimney and barbecue calculator library for WordPress. Calculators are rendered via the [mvweb_fcalc id="..."] shortcode.
 * Version:           1.0.0
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-fireplace-calc
 * Domain Path:       /languages
 *
 * @package MVweb_FC
 *
 * @since 1.0.0 Initial release.
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'MVWEB_FC_VERSION' ) ) {
	return;
}

define( 'MVWEB_FC_VERSION', '1.0.0' );
define( 'MVWEB_FC_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_FC_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_FC_BASENAME', plugin_basename( __FILE__ ) );

$shared_path = dirname( dirname( MVWEB_FC_PATH ) ) . '/shared/';

if ( file_exists( MVWEB_FC_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_FC_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

if ( file_exists( MVWEB_FC_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_FC_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-fireplace-calc' );
}

add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-fireplace-calc'] = array(
		'name'         => __( 'MVweb Fireplace Calc', 'mvweb-fireplace-calc' ),
		'description'  => __( 'Fireplace, stove, chimney and barbecue calculator library.', 'mvweb-fireplace-calc' ),
		'url'          => 'https://mvweb.ru/plugins/mvweb-fireplace-calc',
		'settings_url' => 'admin.php?page=mvweb-fireplace-calc',
		'textdomain'   => 'mvweb-fireplace-calc',
	);
	return $plugins;
} );

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_fc_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-fireplace-calc',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_fc_load_textdomain' );

require_once MVWEB_FC_PATH . 'includes/helpers.php';
require_once MVWEB_FC_PATH . 'includes/themes.php';
require_once MVWEB_FC_PATH . 'includes/class-mvweb-fc-registry.php';
require_once MVWEB_FC_PATH . 'includes/class-mvweb-fc-shortcode.php';
require_once MVWEB_FC_PATH . 'includes/class-mvweb-fc-ajax.php';

if ( is_admin() ) {
	require_once MVWEB_FC_PATH . 'includes/class-mvweb-fc-admin.php';
}

/**
 * Plugin activation hook.
 *
 * Reserved for future setup tasks. Currently a no-op — the plugin has no
 * custom tables, no CPT, no scheduled events.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_fc_activate() {
}
register_activation_hook( __FILE__, 'mvweb_fc_activate' );

/**
 * Plugin deactivation hook.
 *
 * Reserved for future teardown. Settings option is kept; full cleanup
 * happens in uninstall.php.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_fc_deactivate() {
}
register_deactivation_hook( __FILE__, 'mvweb_fc_deactivate' );
