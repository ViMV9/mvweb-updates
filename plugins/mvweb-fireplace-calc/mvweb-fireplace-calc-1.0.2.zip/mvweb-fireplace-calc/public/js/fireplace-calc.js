/**
 * MVweb Fireplace Calc — frontend script.
 *
 * Handles calculator form submission: validates locally, posts to admin-ajax,
 * and renders the result. No client-side formula evaluation — all math is
 * done server-side.
 *
 * @package MVweb_FC
 * @since   1.0.0
 */
(function () {
	'use strict';

	if (typeof window.mvwebFC === 'undefined') {
		return;
	}

	document.addEventListener('DOMContentLoaded', function () {
		document.querySelectorAll('form.mvweb-fc').forEach(initForm);
		initTips();
	});

	function initForm(form) {
		form.addEventListener('submit', function (event) {
			event.preventDefault();
			submitForm(form);
		});

		form.addEventListener('input', function () { hideResult(form); });
		form.addEventListener('change', function () { hideResult(form); });
	}

	/**
	 * Tooltip toggle on touch / click.
	 * Hover is handled by CSS via :hover. This adds mobile support: tap the ? icon
	 * to open the popup, tap again or anywhere outside to close it.
	 */
	function initTips() {
		document.addEventListener('click', function (event) {
			var tip = event.target.closest('form.mvweb-fc .mvweb-fc__tip');
			if (tip) {
				event.preventDefault();
				var wasOpen = tip.hasAttribute('data-mvfc-tip-open');
				closeAllTips();
				if (!wasOpen) {
					tip.setAttribute('data-mvfc-tip-open', '');
				}
				return;
			}
			closeAllTips();
		});

		document.addEventListener('keydown', function (event) {
			if (event.key === 'Escape') { closeAllTips(); }
		});
	}

	function closeAllTips() {
		document.querySelectorAll('form.mvweb-fc .mvweb-fc__tip[data-mvfc-tip-open]')
			.forEach(function (el) { el.removeAttribute('data-mvfc-tip-open'); });
	}

	function submitForm(form) {
		clearErrors(form);

		var submit = form.querySelector('.mvweb-fc__submit');
		if (submit) { submit.disabled = true; }

		var data = new FormData(form);
		data.append('action', 'mvweb_fc_calculate');
		data.append('calc_id', form.dataset.calcId || '');
		data.append('nonce', window.mvwebFC.nonce);

		fetch(window.mvwebFC.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: data
		}).then(function (response) {
			return response.json().catch(function () { return null; });
		}).then(function (payload) {
			if (submit) { submit.disabled = false; }

			if (!payload || typeof payload !== 'object') {
				renderResultError(form, window.mvwebFC.i18n.error);
				return;
			}

			if (payload.success === false) {
				handleErrors(form, payload.data || {});
				return;
			}

			renderResult(form, payload.data || {});
		}).catch(function () {
			if (submit) { submit.disabled = false; }
			renderResultError(form, window.mvwebFC.i18n.error);
		});
	}

	function clearErrors(form) {
		form.querySelectorAll('.mvweb-fc__field').forEach(function (field) {
			field.classList.remove('mvweb-fc__field--error');
			var msg = field.querySelector('.mvweb-fc__field-error');
			if (msg) {
				msg.textContent = '';
				msg.hidden = true;
			}
			var input = field.querySelector('input, select');
			if (input) { input.setAttribute('aria-invalid', 'false'); }
		});
	}

	function handleErrors(form, data) {
		var errors = (data && data.errors) || {};
		var hasFieldError = false;

		Object.keys(errors).forEach(function (key) {
			var field = form.querySelector('.mvweb-fc__field[data-field="' + cssEscape(key) + '"]');
			if (!field) { return; }
			hasFieldError = true;
			field.classList.add('mvweb-fc__field--error');
			var msg = field.querySelector('.mvweb-fc__field-error');
			if (msg) {
				msg.textContent = errors[key];
				msg.hidden = false;
			}
			var input = field.querySelector('input, select');
			if (input) { input.setAttribute('aria-invalid', 'true'); }
		});

		if (!hasFieldError) {
			renderResultError(form, (data && data.message) || window.mvwebFC.i18n.error);
		}
	}

	function clearChildren(node) {
		while (node.firstChild) {
			node.removeChild(node.firstChild);
		}
	}

	function renderResult(form, data) {
		var box = form.querySelector('.mvweb-fc__result');
		if (!box) { return; }

		clearChildren(box);
		box.classList.remove('mvweb-fc__result--error');

		// LEFT COLUMN — headline value (large number + unit).
		var primary = document.createElement('div');
		primary.className = 'mvweb-fc__result-primary';

		if (data.title) {
			var titleEl = document.createElement('p');
			titleEl.className = 'mvweb-fc__result-title';
			titleEl.textContent = String(data.title);
			primary.appendChild(titleEl);
		}

		var valueEl = document.createElement('p');
		valueEl.className = 'mvweb-fc__result-value';
		valueEl.textContent = String(data.formatted || '');
		primary.appendChild(valueEl);

		box.appendChild(primary);

		// RIGHT COLUMN — input summary + hints.
		var details = document.createElement('div');
		details.className = 'mvweb-fc__result-details';
		var hasDetails = false;

		if (Array.isArray(data.summary) && data.summary.length) {
			var dl = document.createElement('dl');
			dl.className = 'mvweb-fc__result-summary';
			data.summary.forEach(function (row) {
				if (!row || !row.label) { return; }
				var dt = document.createElement('dt');
				dt.textContent = String(row.label);
				var dd = document.createElement('dd');
				dd.textContent = String(row.value);
				dl.appendChild(dt);
				dl.appendChild(dd);
			});
			if (dl.children.length) {
				details.appendChild(dl);
				hasDetails = true;
			}
		}

		if (Array.isArray(data.hints) && data.hints.length) {
			var list = document.createElement('ul');
			list.className = 'mvweb-fc__result-hints';
			data.hints.forEach(function (hint) {
				var li = document.createElement('li');
				li.textContent = String(hint);
				list.appendChild(li);
			});
			details.appendChild(list);
			hasDetails = true;
		}

		if (hasDetails) {
			box.appendChild(details);
		}

		box.hidden = false;
	}

	function renderResultError(form, message) {
		var box = form.querySelector('.mvweb-fc__result');
		if (!box) { return; }
		clearChildren(box);
		box.classList.add('mvweb-fc__result--error');
		var primary = document.createElement('div');
		primary.className = 'mvweb-fc__result-primary';
		var valueEl = document.createElement('p');
		valueEl.className = 'mvweb-fc__result-value';
		valueEl.textContent = String(message);
		primary.appendChild(valueEl);
		box.appendChild(primary);
		box.hidden = false;
	}

	function hideResult(form) {
		var box = form.querySelector('.mvweb-fc__result');
		if (box && !box.hidden) {
			box.hidden = true;
			clearChildren(box);
		}
	}

	function cssEscape(str) {
		if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') {
			return CSS.escape(str);
		}
		return String(str).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
	}
})();
