<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package mvweb_rdf
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-reg-domain-filter' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Step 1', 'mvweb-reg-domain-filter' ); ?></strong>
			<p><?php esc_html_e( 'Open the General tab and turn on “Enable filter”.', 'mvweb-reg-domain-filter' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Step 2', 'mvweb-reg-domain-filter' ); ?></strong>
			<p><?php esc_html_e( 'List the allowed domain zones, one per line — for example .ru, .рф, .by.', 'mvweb-reg-domain-filter' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Step 3', 'mvweb-reg-domain-filter' ); ?></strong>
			<p><?php esc_html_e( 'Save. New users can now register only with an e-mail in one of those zones; any other zone is rejected with an error on the registration form.', 'mvweb-reg-domain-filter' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-reg-domain-filter' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Which registration forms are covered?', 'mvweb-reg-domain-filter' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'The standard WordPress registration form (wp-login.php?action=register) and, if WooCommerce is active, the My Account registration form.', 'mvweb-reg-domain-filter' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How do I write a zone?', 'mvweb-reg-domain-filter' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'One zone per line, with or without the leading dot: .ru, ru, .рф — all work. The match is case-insensitive and checks the end of the e-mail domain, so a subdomain like user@mail.example.ru is also accepted for the .ru zone.', 'mvweb-reg-domain-filter' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'What happens if the list is empty?', 'mvweb-reg-domain-filter' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'No restriction is applied — registration from any domain is allowed. The same is true while the filter is turned off.', 'mvweb-reg-domain-filter' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-reg-domain-filter' ); ?></div>
	</div>
	<p>
		<?php
		printf(
			/* translators: %s: MVweb plugin URL */
			esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-reg-domain-filter' ),
			'<a href="https://mvweb.ru/plugins/mvweb-reg-domain-filter" target="_blank">mvweb.ru</a>'
		);
		?>
	</p>
</div>
