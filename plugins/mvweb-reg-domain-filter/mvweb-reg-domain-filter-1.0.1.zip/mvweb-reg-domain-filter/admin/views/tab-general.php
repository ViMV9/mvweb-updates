<?php
/**
 * General settings tab.
 *
 * @package mvweb_rdf
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings   = mvweb_rdf_get_settings();
$zones_text = implode( "\n", $settings['zones'] );
?>

<form method="post" action="">
	<?php wp_nonce_field( 'mvweb_rdf_settings', 'mvweb_rdf_nonce' ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Registration restriction', 'mvweb-reg-domain-filter' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Allow new users to register only with e-mail addresses in the listed domain zones. Registrations with any other zone are rejected with an error on the form.', 'mvweb-reg-domain-filter' ); ?>
		</p>

		<div class="mvweb-form-row mvweb-rdf-form-row--toggle">
			<label for="mvweb_rdf_enabled" class="mvweb-form-row__label">
				<?php esc_html_e( 'Enable filter', 'mvweb-reg-domain-filter' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb_rdf_enabled"
							name="mvweb_rdf_enabled"
							value="1"
							<?php checked( $settings['enabled'] ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Restrict registration by e-mail domain zone', 'mvweb-reg-domain-filter' ); ?></span>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_rdf_zones" class="mvweb-form-row__label">
				<?php esc_html_e( 'Allowed domain zones', 'mvweb-reg-domain-filter' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb_rdf_zones"
					name="mvweb_rdf_zones"
					class="mvweb-textarea"
					rows="6"
					spellcheck="false"
					placeholder=".ru&#10;.рф&#10;.by"><?php echo esc_textarea( $zones_text ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'One zone per line, e.g. .ru, .рф, .by. Leave empty to allow any domain.', 'mvweb-reg-domain-filter' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" name="mvweb_rdf_save" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Save Changes', 'mvweb-reg-domain-filter' ); ?>
		</button>
		<span class="mvweb-submit__hint"><kbd>⌘ S</kbd></span>
	</div>
</form>
