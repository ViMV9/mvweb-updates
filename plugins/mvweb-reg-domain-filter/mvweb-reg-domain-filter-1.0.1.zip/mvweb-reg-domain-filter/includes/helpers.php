<?php
/**
 * Helper functions for MVweb Registration Domain Filter.
 *
 * @package mvweb_rdf
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default allowed domain zones (used before the admin saves anything).
 *
 * @since 1.0.0
 * @return array<int, string>
 */
function mvweb_rdf_default_zones() {
	return array( '.ru', '.рф' );
}

/**
 * Get plugin settings with defaults applied.
 *
 * @since 1.0.0
 * @return array{enabled: bool, zones: array<int, string>}
 */
function mvweb_rdf_get_settings() {
	$settings = get_option( 'mvweb_rdf_settings', array() );
	if ( ! is_array( $settings ) ) {
		$settings = array();
	}

	$settings = array_merge(
		array(
			'enabled' => true,
			'zones'   => mvweb_rdf_default_zones(),
		),
		$settings
	);

	$settings['enabled'] = ! empty( $settings['enabled'] );
	$settings['zones']   = is_array( $settings['zones'] ) ? $settings['zones'] : array();

	return $settings;
}

/**
 * Normalize a single zone string entered by the admin.
 *
 * Lower-cases, strips a stray leading wildcard/at, and guarantees a leading dot:
 * "RU" → ".ru", "рф" → ".рф", ".by" → ".by".
 *
 * @since 1.0.0
 * @param string $raw Raw line from the textarea.
 * @return string Normalized zone, or '' if the line is empty.
 */
function mvweb_rdf_normalize_zone( $raw ) {
	$zone = trim( (string) $raw );
	$zone = ltrim( $zone, "*@ \t" );

	if ( '' === $zone ) {
		return '';
	}

	$zone = function_exists( 'mb_strtolower' ) ? mb_strtolower( $zone, 'UTF-8' ) : strtolower( $zone );

	// Guarantee a leading dot ('.' is a single ASCII byte, safe on UTF-8 strings).
	if ( '.' !== $zone[0] ) {
		$zone = '.' . $zone;
	}

	// Reject dot-only input (".", ".."). As a sole whitelist entry it would match
	// nothing and silently block every registration.
	if ( '' === trim( $zone, '.' ) ) {
		return '';
	}

	return $zone;
}

/**
 * Parse the settings textarea into a de-duplicated list of normalized zones.
 *
 * @since 1.0.0
 * @param string $text Raw textarea content (one zone per line).
 * @return array<int, string>
 */
function mvweb_rdf_parse_zones( $text ) {
	$lines = preg_split( '/[\r\n]+/', (string) $text );
	$zones = array();

	foreach ( (array) $lines as $line ) {
		$zone = mvweb_rdf_normalize_zone( $line );
		if ( '' !== $zone && ! in_array( $zone, $zones, true ) ) {
			$zones[] = $zone;
		}
	}

	return $zones;
}

/**
 * Build the match variants for a configured zone.
 *
 * A Cyrillic zone (e.g. ".рф") can only ever reach us as its punycode form
 * (".xn--p1ai"), because is_email() rejects unicode domains before the
 * registration hooks run. So for non-ASCII zones we also match the punycode.
 *
 * @since 1.0.0
 * @param string $zone Normalized zone (with leading dot).
 * @return array<int, string>
 */
function mvweb_rdf_zone_variants( $zone ) {
	$zone = (string) $zone;
	if ( '' === $zone ) {
		return array();
	}

	$variants = array( $zone );

	if ( preg_match( '/[^\x00-\x7F]/', $zone ) ) {
		$ascii = mvweb_rdf_punycode_zone( $zone );
		if ( '' !== $ascii ) {
			$variants[] = $ascii;
		}
	}

	return array_unique( $variants );
}

/**
 * Resolve a non-ASCII zone to its punycode form.
 *
 * A static map of the Cyrillic ccTLDs works without the intl extension (so the
 * default ".рф" keeps matching on hosts where intl is missing); idn_to_ascii()
 * covers any other non-ASCII zone when intl is available.
 *
 * @since 1.0.0
 * @param string $zone Normalized non-ASCII zone (with leading dot).
 * @return string Punycode zone with leading dot, or '' if it cannot be resolved.
 */
function mvweb_rdf_punycode_zone( $zone ) {
	$map = array(
		'.рф'  => '.xn--p1ai',
		'.рус' => '.xn--p1acf',
		'.бел' => '.xn--90ais',
		'.срб' => '.xn--90a3ac',
		'.укр' => '.xn--j1amh',
		'.мкд' => '.xn--d1alf',
		'.мон' => '.xn--l1acc',
		'.қаз' => '.xn--80ao21a',
	);

	if ( isset( $map[ $zone ] ) ) {
		return $map[ $zone ];
	}

	if ( function_exists( 'idn_to_ascii' ) ) {
		$ascii = idn_to_ascii( ltrim( $zone, '.' ), IDNA_DEFAULT, INTL_IDNA_VARIANT_UTS46 );
		if ( is_string( $ascii ) && '' !== $ascii ) {
			return '.' . strtolower( $ascii );
		}
	}

	return '';
}

/**
 * Decide whether an email's domain zone is allowed to register.
 *
 * Fails open on empty/malformed input — core (is_email) handles those, and we
 * never want to lock everyone out when the whitelist is empty or the filter is
 * disabled.
 *
 * @since 1.0.0
 * @param string $email Email address being registered.
 * @return bool True if allowed to register.
 */
function mvweb_rdf_email_zone_allowed( $email ) {
	$email = trim( (string) $email );
	if ( '' === $email ) {
		return true;
	}

	$at = strrpos( $email, '@' );
	if ( false === $at ) {
		return true;
	}

	$domain = strtolower( substr( $email, $at + 1 ) );
	if ( '' === $domain ) {
		return true;
	}

	$settings = mvweb_rdf_get_settings();
	if ( ! $settings['enabled'] || empty( $settings['zones'] ) ) {
		return true;
	}

	foreach ( $settings['zones'] as $zone ) {
		foreach ( mvweb_rdf_zone_variants( $zone ) as $variant ) {
			if ( '' !== $variant && str_ends_with( $domain, $variant ) ) {
				return true;
			}
		}
	}

	return false;
}

/**
 * Build the user-facing error message listing the allowed zones.
 *
 * @since 1.0.0
 * @return string
 */
function mvweb_rdf_error_message() {
	$zones = mvweb_rdf_get_settings()['zones'];

	if ( empty( $zones ) ) {
		return __( 'Registration from this email domain is not allowed.', 'mvweb-reg-domain-filter' );
	}

	return sprintf(
		/* translators: %s: comma-separated list of allowed domain zones, e.g. ".ru, .рф". */
		__( 'Registration is allowed only for e-mail addresses in these domain zones: %s.', 'mvweb-reg-domain-filter' ),
		esc_html( implode( ', ', $zones ) )
	);
}

/**
 * Validate the email zone on the standard WordPress registration form.
 *
 * Hooked to the native `registration_errors` filter fired inside
 * register_new_user() (wp-includes/user.php). Adding an error stops the
 * registration and WordPress shows the message on the form.
 *
 * @since 1.0.0
 * @param WP_Error $errors               Registration errors so far.
 * @param string   $sanitized_user_login Sanitized login (unused).
 * @param string   $user_email           Submitted email address.
 * @return WP_Error
 */
function mvweb_rdf_validate_registration( $errors, $sanitized_user_login, $user_email ) {
	if ( is_wp_error( $errors ) && ! mvweb_rdf_email_zone_allowed( $user_email ) ) {
		$errors->add( 'mvweb_rdf_domain_not_allowed', mvweb_rdf_error_message() );
	}

	return $errors;
}

/**
 * Validate the email zone on the WooCommerce my-account registration form.
 *
 * Hooked to `woocommerce_registration_errors` inside wc_create_new_customer().
 * No-op when WooCommerce is inactive (the filter never fires).
 *
 * @since 1.0.0
 * @param WP_Error $errors   Registration errors so far.
 * @param string   $username Submitted username (unused).
 * @param string   $email    Submitted email address.
 * @return WP_Error
 */
function mvweb_rdf_validate_wc_registration( $errors, $username, $email ) {
	if ( is_wp_error( $errors ) && ! mvweb_rdf_email_zone_allowed( $email ) ) {
		$errors->add( 'mvweb_rdf_domain_not_allowed', mvweb_rdf_error_message() );
	}

	return $errors;
}
