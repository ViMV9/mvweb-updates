<?php
/**
 * Plugin Name:       MVweb Registration Domain Filter
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-reg-domain-filter
 * Description:       Restricts new user registration to e-mail addresses in an allowed list of domain zones (e.g. .ru, .рф).
 * Version:           1.0.1
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-reg-domain-filter
 * Domain Path:       /languages
 *
 * @package mvweb_rdf
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_RDF_VERSION' ) ) {
	return;
}

define( 'MVWEB_RDF_VERSION', '1.0.1' );
define( 'MVWEB_RDF_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_RDF_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_RDF_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_RDF_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_RDF_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_RDF_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_RDF_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_RDF_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-reg-domain-filter' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-reg-domain-filter'] = array(
		'name'         => 'MVweb Registration Domain Filter',
		'description'  => __( 'Restricts new user registration to e-mail addresses in an allowed list of domain zones (e.g. .ru, .рф).', 'mvweb-reg-domain-filter' ),
		'url'          => 'https://mvweb.ru/plugins/mvweb-reg-domain-filter',
		'settings_url' => 'admin.php?page=mvweb-reg-domain-filter',
		'textdomain'   => 'mvweb-reg-domain-filter',
	);
	return $plugins;
} );

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_rdf_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-reg-domain-filter',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_rdf_load_textdomain' );

// Load helper functions (settings, zone normalization, validation).
require_once MVWEB_RDF_PATH . 'includes/helpers.php';

// ───────────────────────────────────────────────
// Registration guard — native hooks
// ───────────────────────────────────────────────

// Standard WordPress registration form (wp-login.php?action=register).
add_filter( 'registration_errors', 'mvweb_rdf_validate_registration', 10, 3 );

// WooCommerce my-account registration (bypasses register_new_user). Harmless
// no-op when WooCommerce is inactive — the filter simply never fires.
add_filter( 'woocommerce_registration_errors', 'mvweb_rdf_validate_wc_registration', 10, 3 );

// ───────────────────────────────────────────────
// Activation — seed default allowed zones
// ───────────────────────────────────────────────

/**
 * Seed default settings on activation if none exist.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_rdf_activate() {
	if ( false === get_option( 'mvweb_rdf_settings', false ) ) {
		add_option(
			'mvweb_rdf_settings',
			array(
				'enabled' => true,
				'zones'   => mvweb_rdf_default_zones(),
			)
		);
	}
}
register_activation_hook( __FILE__, 'mvweb_rdf_activate' );

// ───────────────────────────────────────────────
// Admin — settings page
// ───────────────────────────────────────────────

/**
 * Register plugin submenu under MVweb Hub.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_rdf_register_menu() {
	$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

	add_submenu_page(
		$parent_slug,
		__( 'MVweb Registration Domain Filter', 'mvweb-reg-domain-filter' ),
		__( 'Registration Domain Filter', 'mvweb-reg-domain-filter' ),
		'manage_options',
		'mvweb-reg-domain-filter',
		'mvweb_rdf_settings_page'
	);
}
add_action( 'admin_menu', 'mvweb_rdf_register_menu' );

/**
 * Settings page callback — handle save, then render the view.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_rdf_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	if ( isset( $_POST['mvweb_rdf_save'] ) ) {
		check_admin_referer( 'mvweb_rdf_settings', 'mvweb_rdf_nonce' );

		$zones_raw = isset( $_POST['mvweb_rdf_zones'] )
			? sanitize_textarea_field( wp_unslash( $_POST['mvweb_rdf_zones'] ) )
			: '';

		update_option(
			'mvweb_rdf_settings',
			array(
				'enabled' => isset( $_POST['mvweb_rdf_enabled'] ),
				'zones'   => mvweb_rdf_parse_zones( $zones_raw ),
			)
		);

		add_settings_error(
			'mvweb_rdf_messages',
			'mvweb_rdf_message',
			__( 'Settings saved.', 'mvweb-reg-domain-filter' ),
			'updated'
		);
	}

	require MVWEB_RDF_PATH . 'admin/views/settings-page.php';
}

/**
 * Enqueue admin styles for the plugin settings page.
 *
 * @since 1.0.0
 * @param string $hook Current admin page hook.
 * @return void
 */
function mvweb_rdf_admin_enqueue( $hook ) {
	if ( false === strpos( $hook, 'mvweb-reg-domain-filter' ) ) {
		return;
	}

	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

	wp_enqueue_style(
		'mvweb-rdf-admin',
		MVWEB_RDF_URL . 'admin/css/admin' . $suffix . '.css',
		array(),
		(string) filemtime( MVWEB_RDF_PATH . 'admin/css/admin' . $suffix . '.css' )
	);

	wp_enqueue_style(
		'mvweb-rdf-plugin',
		MVWEB_RDF_URL . 'admin/css/plugin' . $suffix . '.css',
		array( 'mvweb-rdf-admin' ),
		(string) filemtime( MVWEB_RDF_PATH . 'admin/css/plugin' . $suffix . '.css' )
	);

	wp_enqueue_script(
		'mvweb-rdf-admin',
		MVWEB_RDF_URL . 'admin/js/admin' . $suffix . '.js',
		array(),
		(string) filemtime( MVWEB_RDF_PATH . 'admin/js/admin' . $suffix . '.js' ),
		true
	);
}
add_action( 'admin_enqueue_scripts', 'mvweb_rdf_admin_enqueue' );
