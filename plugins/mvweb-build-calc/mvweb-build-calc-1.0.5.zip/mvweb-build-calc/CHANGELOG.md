# Changelog

All notable changes to MVweb Build Calc will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.5] - 2026-06-02

### Changed
- Calculators admin list is now grouped by hub: a header row with the localized hub name and a count badge is shown above each group (Foundation and earthworks, Unit converters). Hub labels resolved via the new `mvweb_bc_hub_label()` helper.

## [1.0.4] - 2026-06-02

### Added
- **Converters hub** — 13 new unit converters (`hub => converters`), each with a "Convert from" selector plus a single value field; the result shows the value in the base SI unit and lists every other unit in the hints:
  - `convert-mm-cm-m` — length (mm / cm / m).
  - `convert-m2-cm2-mm2` — area (mm² / cm² / m²).
  - `convert-m3-l` — volume (m³ / l).
  - `convert-kg-t` — mass (kg / t).
  - `convert-density` — density (kg/m³ / g/cm³ / t/m³).
  - `convert-w-kw` — power (W / kW).
  - `convert-kw-gcal-btu` — thermal power (kW / Gcal/h / kcal/h / BTU/h).
  - `convert-c-f` — temperature (°C / °F / K), affine conversion with its own formula.
  - `convert-flow` — volumetric flow (l/min / l/s / m³/h).
  - `convert-pressure` — pressure (Pa / kPa / bar / atm / mmHg).
  - `convert-inches-mm` — inches ↔ millimetres.
  - `convert-feet-m` — feet ↔ metres.
  - `convert-area-units` — land area (m² / sotka / ha / acre).
- Russian (ru_RU) translation for all converter strings — titles, descriptions, unit selectors, option labels and hint units (110 new strings added to `.po`/`.pot` and compiled into `.mo`).

## [1.0.3] - 2026-06-01

### Fixed
- Russian translation of the plugin Description header on the Plugins screen — the full header string was missing from the catalogue, so it stayed in English.
- Hub strings `Installed plugins`, `Available plugins`, `not installed`, `active`, `inactive` were marked fuzzy and dropped from the compiled `.mo`; unmarked and recompiled. Corrected the `active` translation.

## [1.0.2] - 2026-06-01

### Changed
- Updated the bundled MVweb Hub menu class (`MVweb_Menu`) to version 2.2.0: new UI Kit markup for the hub page, hub stylesheet now loaded from the shared `admin.css` instead of inline styles, brand logo and CSS resolved from any installed MVweb plugin.
- Singleton `MVweb_Menu` now blocks cloning and unserialization (`__clone()` / `__wakeup()`).
- Refreshed `admin/css/admin.css` to the current MVweb UI Kit baseline (button and input normalization, dashicon sizing inside `.mvweb-btn`).

### Fixed
- Formula syntax highlighting in the Calculators tab — token CSS classes now match the stylesheet (`.tok-var` / `.tok-num` / `.tok-op`), so variables, numbers and operators render coloured again.

### Removed
- Obsolete `includes/languages/mvweb-hub-*` catalogue — hub strings are translated through the plugin text domain.

## [1.0.1] - 2026-05-22

### Added
- **Frontend theme presets** — 10 ready-made visual styles for the calculator form: `shadcn`, `pico`, `openprops`, `shoelace`, `material`, `bulma`, `halfmoon`, `tabler`, `daisyui`, `modern`. Picked via the new "Theme preset" select on the Appearance settings (defaults to `default`, which keeps the previous look). The theme stylesheet `public/css/build-calc-themes.css` is loaded lazily, only when a non-default theme is active.
- All six Appearance settings (radius, border color/width, form border, button variant, button color) continue to fine-tune any chosen theme — themes intentionally never override admin-controlled CSS properties.
- Default `--mvbc-btn-color` switched from `currentColor` to a neutral blue `#3b82f6` so the calculator stays legible on themes that use unusual base text colors.
- Extended `build-calc.css` with base styles for all element types future calculators may use: `textarea`, single `checkbox` and `checks` group, toggle `switch`, range slider with `range-output`, `stepper` (− [n] +), field `group` with floating title, multi-step `steps`, native `details` collapsible, `tip` tooltip trigger, semantic `alert` (info/success/warn/error), `badge`, `spinner`, `skeleton`, `progress` bar, secondary `actions` row and `cost` row for price-aware calculators. New submit variant `--secondary` for "Reset"/"Cancel" buttons.
- `select` field type now supports option grouping via native `<optgroup>`. Calculators can pass a two-level array (`'Group Label' => ['value' => 'Label', ...]`) instead of the flat map and the renderer outputs grouped options automatically. Backward compatible with the flat format.
- `mvweb_bc_flatten_options()` helper for uniform access to options regardless of grouping (used by AJAX validator and summary builder).
- **Foundation hub** — 9 new calculators completing the foundation category:
  - `foundation-rebar` — total length and mass of rebar for a strip foundation (longitudinal bars + stirrups, GOST 5781-82).
  - `formwork-area` — formwork area for strip or slab foundation, plus plywood-sheet count.
  - `sand-cushion-volume` — compacted and loose sand volume under a foundation, plus weight in tonnes.
  - `gravel-cushion-volume` — same as sand cushion but for gravel / crushed stone defaults.
  - `trench-volume` — soil volume to excavate from a trapezoidal trench, slope coefficient by soil type (SNiP 12-04-2002).
  - `pit-volume` — rectangular pit volume with sloped walls using Simpson's prismoidal rule, including loose volume to remove.
  - `frost-depth` — design frost penetration depth for 34 cities (RU federal districts + Belarus) with soil and heating coefficients (SP 22.13330.2016, SP 131.13330.2020). First calculator to use grouped `<optgroup>` select.
  - `lot-slope` — pure units converter between %, ° and mm/m.
  - `lot-elevation-difference` — full elevation + earthwork volume + foundation type recommendation in one shot.

### Fixed
- `trench-volume`, `pit-volume`: slope coefficient `m` is now correctly chosen by **both soil type and depth bracket** (≤1.5 m / ≤3 m / ≤5 m) per SNiP 12-04-2002, table 1 §5.2.6. Previously a single `m` per soil was used, which is only correct for depths up to 1.5 m. Soil list extended with sandy loam and fill ground. Out-of-range warning added for depths > 5 m.
- `frost-depth`: removed the invalid `k_soil` standalone multiplier from the formula. Soil influence is now applied via the `d_0` coefficient from SP 22.13330.2016 eq. 5.4 (`d_fn = d_0 × √Mt`), scaling the precomputed `d_fn(loam)` per city: `d_fn(soil) = d_fn(loam) × d_0(soil) / 0.23`. Yekaterinburg `d_fn` recomputed from 1.90 m to 1.78 m. Documentation now correctly references SP 22 eq. 5.3 and 5.4 instead of "table 5.1 of SP 131".
- `lot-elevation-difference`: clarified in description, formula and hints that the earthwork volume corresponds to **balanced levelling to the mid-elevation** (cut = fill), not full levelling to the lowest point. The formula `/4` is the same; only the semantics is now explicit to avoid misinterpretation.
- AJAX validator: `select` and `radio` fields with numeric-string option keys (e.g. `'8' => '⌀8'`) are no longer rejected as "Invalid choice". PHP silently casts numeric string array keys to `int`, so `array_keys()` on the flat options map returned `[8, 10, 12, ...]`; the strict `in_array((string) $value, $options, true)` check then failed because `"12" !== 12`. `array_keys()` result is now coerced to strings via `array_map( 'strval', ... )`. Affected calculator: `foundation-rebar` (rebar diameter), which was fully unusable — every submission returned an error regardless of the chosen diameter.
- Input summary builder: integer values are no longer truncated. The previous `rtrim( rtrim( (string) $num, '0' ), '.' )` stripped trailing zeros from whole numbers too, so a length of `10` rendered as `"1"`, `20` as `"2"`, `100` as `"1"`, etc. — the displayed inputs no longer matched what the user typed, even though the calculated result was correct. Whole numbers now skip the rtrim and render as integers (`10 → "10"`); decimals keep the previous trailing-zero trimming (`0.30 → "0.3"`).

## [1.0.0] - 2026-05-19

### Added
- Initial plugin scaffold with MVweb Hub registration.
- Calculator registry with auto-discovery from `calculators/` folder.
- `[mvweb_calc id="..."]` shortcode for rendering calculator forms.
- Server-side calculation via admin-ajax with nonce protection and per-field validation.
- Admin UI with list of registered calculators, plugin settings and help tab.
- Reference calculator: `foundation-concrete-volume`.
- Appearance settings: corner radius, border color/width, optional form wrapper border, button variant (Solid / Outline / Ghost) and button color. Empty color fields inherit from the active theme via `currentColor`.

### Changed
- Frontend widget rewritten around CSS custom properties (`--mvbc-*`). The fixed `native` / `slate` / `outline` / `stone` presets were removed in favor of a single theme-driven base plus admin-controlled overrides.
