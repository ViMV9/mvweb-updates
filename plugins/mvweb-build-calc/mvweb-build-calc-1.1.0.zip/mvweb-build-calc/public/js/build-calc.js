/**
 * MVweb Build Calc — frontend script.
 *
 * Handles calculator form submission: validates locally, posts to admin-ajax,
 * and renders the result. No client-side formula evaluation — all math is
 * done server-side.
 *
 * @package MVweb_BC
 * @since   1.0.0
 */
(function () {
	'use strict';

	if (typeof window.mvwebBC === 'undefined') {
		return;
	}

	document.addEventListener('DOMContentLoaded', function () {
		document.querySelectorAll('form.mvweb-bc').forEach(initForm);
		initTips();
	});

	function initForm(form) {
		form.addEventListener('submit', function (event) {
			event.preventDefault();
			submitForm(form);
		});

		form.addEventListener('input', function () { hideResult(form); });
		form.addEventListener('change', function () { hideResult(form); });
	}

	/**
	 * Tooltip toggle on touch / click.
	 * Hover is handled by CSS via :hover. This adds mobile support: tap the ? icon
	 * to open the popup, tap again or anywhere outside to close it.
	 */
	function initTips() {
		document.addEventListener('click', function (event) {
			var tip = event.target.closest('form.mvweb-bc .mvweb-bc__tip');
			if (tip) {
				event.preventDefault();
				var wasOpen = tip.hasAttribute('data-mvbc-tip-open');
				closeAllTips();
				if (!wasOpen) {
					tip.setAttribute('data-mvbc-tip-open', '');
				}
				return;
			}
			closeAllTips();
		});

		document.addEventListener('keydown', function (event) {
			if (event.key === 'Escape') { closeAllTips(); }
		});
	}

	function closeAllTips() {
		document.querySelectorAll('form.mvweb-bc .mvweb-bc__tip[data-mvbc-tip-open]')
			.forEach(function (el) { el.removeAttribute('data-mvbc-tip-open'); });
	}

	function submitForm(form) {
		clearErrors(form);

		var submit = form.querySelector('.mvweb-bc__submit');
		if (submit) { submit.disabled = true; }

		var data = new FormData(form);
		data.append('action', 'mvweb_bc_calculate');
		data.append('calc_id', form.dataset.calcId || '');
		data.append('nonce', window.mvwebBC.nonce);

		fetch(window.mvwebBC.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			body: data
		}).then(function (response) {
			return response.json().catch(function () { return null; });
		}).then(function (payload) {
			if (submit) { submit.disabled = false; }

			if (!payload || typeof payload !== 'object') {
				renderResultError(form, window.mvwebBC.i18n.error);
				return;
			}

			if (payload.success === false) {
				handleErrors(form, payload.data || {});
				return;
			}

			renderResult(form, payload.data || {});
		}).catch(function () {
			if (submit) { submit.disabled = false; }
			renderResultError(form, window.mvwebBC.i18n.error);
		});
	}

	function clearErrors(form) {
		form.querySelectorAll('.mvweb-bc__field').forEach(function (field) {
			field.classList.remove('mvweb-bc__field--error');
			var msg = field.querySelector('.mvweb-bc__field-error');
			if (msg) {
				msg.textContent = '';
				msg.hidden = true;
			}
			var input = field.querySelector('input, select');
			if (input) { input.setAttribute('aria-invalid', 'false'); }
		});
	}

	function handleErrors(form, data) {
		var errors = (data && data.errors) || {};
		var hasFieldError = false;

		Object.keys(errors).forEach(function (key) {
			var field = form.querySelector('.mvweb-bc__field[data-field="' + cssEscape(key) + '"]');
			if (!field) { return; }
			hasFieldError = true;
			field.classList.add('mvweb-bc__field--error');
			var msg = field.querySelector('.mvweb-bc__field-error');
			if (msg) {
				msg.textContent = errors[key];
				msg.hidden = false;
			}
			var input = field.querySelector('input, select');
			if (input) { input.setAttribute('aria-invalid', 'true'); }
		});

		if (!hasFieldError) {
			renderResultError(form, (data && data.message) || window.mvwebBC.i18n.error);
		}
	}

	function clearChildren(node) {
		while (node.firstChild) {
			node.removeChild(node.firstChild);
		}
	}

	function renderResult(form, data) {
		var box = form.querySelector('.mvweb-bc__result');
		if (!box) { return; }

		clearChildren(box);
		box.classList.remove('mvweb-bc__result--error');

		// LEFT COLUMN — headline value (large number + unit).
		var primary = document.createElement('div');
		primary.className = 'mvweb-bc__result-primary';

		if (data.title) {
			var titleEl = document.createElement('p');
			titleEl.className = 'mvweb-bc__result-title';
			titleEl.textContent = String(data.title);
			primary.appendChild(titleEl);
		}

		var valueEl = document.createElement('p');
		valueEl.className = 'mvweb-bc__result-value';
		valueEl.textContent = String(data.formatted || '');
		primary.appendChild(valueEl);

		box.appendChild(primary);

		// RIGHT COLUMN — input summary + hints.
		var details = document.createElement('div');
		details.className = 'mvweb-bc__result-details';
		var hasDetails = false;

		if (Array.isArray(data.summary) && data.summary.length) {
			var dl = document.createElement('dl');
			dl.className = 'mvweb-bc__result-summary';
			data.summary.forEach(function (row) {
				if (!row || !row.label) { return; }
				var pair = document.createElement('div');
				pair.className = 'mvweb-bc__result-summary-row';
				var dt = document.createElement('dt');
				dt.textContent = String(row.label);
				var dd = document.createElement('dd');
				dd.textContent = String(row.value);
				pair.appendChild(dt);
				pair.appendChild(dd);
				dl.appendChild(pair);
			});
			if (dl.children.length) {
				details.appendChild(dl);
				hasDetails = true;
			}
		}

		if (Array.isArray(data.hints) && data.hints.length) {
			var list = document.createElement('ul');
			list.className = 'mvweb-bc__result-hints';
			data.hints.forEach(function (hint) {
				var li = document.createElement('li');
				li.textContent = String(hint);
				list.appendChild(li);
			});
			details.appendChild(list);
			hasDetails = true;
		}

		if (hasDetails) {
			box.appendChild(details);
		}

		// Optional diagram — beam schematic + moment/deflection plot.
		// Rendered last so the result reads top to bottom: value, summary,
		// hints, then the diagram.
		if (data.diagram && typeof data.diagram === 'object') {
			var diagram = buildDiagram(data.diagram);
			if (diagram) {
				box.appendChild(diagram);
				box.classList.add('mvweb-bc__result--has-diagram');
			}
		}

		box.hidden = false;
	}

	var SVG_NS = 'http://www.w3.org/2000/svg';

	function svgEl(name, attrs) {
		var el = document.createElementNS(SVG_NS, name);
		if (attrs) {
			Object.keys(attrs).forEach(function (key) {
				el.setAttribute(key, String(attrs[key]));
			});
		}
		return el;
	}

	/**
	 * Build an inline SVG showing a beam schematic (supports + load) and the
	 * normalised moment/deflection curve below it. Coordinates are drawn in a
	 * fixed 320×170 viewBox; the curve is the array of [0..1] ordinates.
	 */
	function buildDiagram(d) {
		var curve = Array.isArray(d.curve) ? d.curve.filter(function (n) {
			return typeof n === 'number' && isFinite(n);
		}) : [];

		var wrap = document.createElement('div');
		wrap.className = 'mvweb-bc__result-diagram';

		var W = 320, H = 170, padX = 24, beamY = 46, plotTop = 78, plotH = 70;
		var x0 = padX, x1 = W - padX, span = x1 - x0;

		var svg = svgEl('svg', {
			viewBox: '0 0 ' + W + ' ' + H,
			width: '100%',
			role: 'img',
			'aria-label': String(d.peak || 'diagram'),
			'class': 'mvweb-bc__svg'
		});

		// Beam line.
		svg.appendChild(svgEl('line', {
			x1: x0, y1: beamY, x2: x1, y2: beamY,
			'class': 'mvbc-dia-beam'
		}));

		// Supports.
		drawSupports(svg, d.support, x0, x1, beamY);

		// Load arrows.
		drawLoad(svg, d.load, x0, x1, beamY);

		// Plot curve (moment / deflection).
		if (curve.length > 1) {
			var maxAbs = 0;
			curve.forEach(function (n) { maxAbs = Math.max(maxAbs, Math.abs(n)); });
			if (maxAbs === 0) { maxAbs = 1; }

			var baseY = (d.plot === 'deflection') ? plotTop : plotTop + plotH / 2;
			var amp = (d.plot === 'deflection') ? plotH : plotH / 2;

			// Plot baseline.
			svg.appendChild(svgEl('line', {
				x1: x0, y1: baseY, x2: x1, y2: baseY, 'class': 'mvbc-dia-axis'
			}));

			var pts = curve.map(function (n, i) {
				var px = x0 + span * (i / (curve.length - 1));
				var py = baseY + (n / maxAbs) * amp;
				return px.toFixed(1) + ',' + py.toFixed(1);
			});

			var poly = pts.join(' ') + ' ' + x1.toFixed(1) + ',' + baseY + ' ' + x0.toFixed(1) + ',' + baseY;
			svg.appendChild(svgEl('polygon', { points: poly, 'class': 'mvbc-dia-fill' }));
			svg.appendChild(svgEl('polyline', { points: pts.join(' '), 'class': 'mvbc-dia-curve' }));
		}

		wrap.appendChild(svg);

		if (d.peak) {
			var cap = document.createElement('p');
			cap.className = 'mvweb-bc__diagram-caption';
			cap.textContent = String(d.peak);
			wrap.appendChild(cap);
		}

		return wrap;
	}

	function drawSupports(svg, support, x0, x1, beamY) {
		function triangle(cx) {
			svg.appendChild(svgEl('polygon', {
				points: (cx - 7) + ',' + (beamY + 12) + ' ' + (cx + 7) + ',' + (beamY + 12) + ' ' + cx + ',' + beamY,
				'class': 'mvbc-dia-support'
			}));
		}
		function wall(cx, dir) {
			svg.appendChild(svgEl('rect', {
				x: dir > 0 ? cx : cx - 6, y: beamY - 16, width: 6, height: 32,
				'class': 'mvbc-dia-support'
			}));
		}
		if (support === 'cantilever') {
			wall(x0, -1);
		} else if (support === 'fixed') {
			wall(x0, -1);
			wall(x1, 1);
		} else {
			triangle(x0);
			triangle(x1);
		}
	}

	function drawLoad(svg, load, x0, x1, beamY) {
		if (load === 'point') {
			var cx = (x0 + x1) / 2;
			svg.appendChild(svgEl('line', {
				x1: cx, y1: beamY - 30, x2: cx, y2: beamY - 4, 'class': 'mvbc-dia-load'
			}));
			svg.appendChild(svgEl('polygon', {
				points: (cx - 4) + ',' + (beamY - 8) + ' ' + (cx + 4) + ',' + (beamY - 8) + ' ' + cx + ',' + (beamY - 2),
				'class': 'mvbc-dia-load-head'
			}));
			return;
		}
		// Distributed load — a row of short arrows.
		var n = 7;
		for (var i = 0; i <= n; i++) {
			var px = x0 + (x1 - x0) * (i / n);
			svg.appendChild(svgEl('line', {
				x1: px, y1: beamY - 22, x2: px, y2: beamY - 4, 'class': 'mvbc-dia-load'
			}));
			svg.appendChild(svgEl('polygon', {
				points: (px - 3) + ',' + (beamY - 7) + ' ' + (px + 3) + ',' + (beamY - 7) + ' ' + px + ',' + (beamY - 2),
				'class': 'mvbc-dia-load-head'
			}));
		}
		svg.appendChild(svgEl('line', {
			x1: x0, y1: beamY - 22, x2: x1, y2: beamY - 22, 'class': 'mvbc-dia-load'
		}));
	}

	function renderResultError(form, message) {
		var box = form.querySelector('.mvweb-bc__result');
		if (!box) { return; }
		clearChildren(box);
		box.classList.add('mvweb-bc__result--error');
		var primary = document.createElement('div');
		primary.className = 'mvweb-bc__result-primary';
		var valueEl = document.createElement('p');
		valueEl.className = 'mvweb-bc__result-value';
		valueEl.textContent = String(message);
		primary.appendChild(valueEl);
		box.appendChild(primary);
		box.hidden = false;
	}

	function hideResult(form) {
		var box = form.querySelector('.mvweb-bc__result');
		if (box && !box.hidden) {
			box.hidden = true;
			clearChildren(box);
		}
	}

	function cssEscape(str) {
		if (typeof CSS !== 'undefined' && typeof CSS.escape === 'function') {
			return CSS.escape(str);
		}
		return String(str).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
	}
})();
