<?php
/**
 * AJAX handler for MVweb Build Calc.
 *
 * Processes calculator form submissions: nonce check → sanitization →
 * validation → execution of the registered calculate() closure → JSON response.
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_BC_Ajax.
 *
 * @since 1.0.0
 */
class MVweb_BC_Ajax {

	/**
	 * AJAX action name.
	 */
	public const ACTION = 'mvweb_bc_calculate';

	/**
	 * Register WordPress hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'wp_ajax_' . self::ACTION, array( __CLASS__, 'handle' ) );
		add_action( 'wp_ajax_nopriv_' . self::ACTION, array( __CLASS__, 'handle' ) );
	}

	/**
	 * Handle the AJAX request.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function handle(): void {
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, self::ACTION ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Security check failed.', 'mvweb-build-calc' ) ),
				403
			);
		}

		$slug = isset( $_POST['calc_id'] ) ? sanitize_key( wp_unslash( (string) $_POST['calc_id'] ) ) : '';
		$calc = '' !== $slug ? MVweb_BC_Registry::get( $slug ) : null;

		if ( null === $calc ) {
			wp_send_json_error(
				array( 'message' => __( 'Calculator not found.', 'mvweb-build-calc' ) ),
				404
			);
		}

		$fields = (array) $calc['fields'];
		$inputs = array();
		$errors = array();

		foreach ( $fields as $key => $field_config ) {
			$field_config = (array) $field_config;
			$key          = (string) $key;
			// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash -- Nonce verified above; value is unslashed and sanitized by mvweb_bc_sanitize_input() below.
			$raw = $_POST[ $key ] ?? null;

			$is_missing = ( null === $raw || '' === $raw );

			if ( $is_missing ) {
				if ( ! empty( $field_config['required'] ) ) {
					$errors[ $key ] = __( 'This field is required.', 'mvweb-build-calc' );
					continue;
				}
				if ( array_key_exists( 'default', $field_config ) ) {
					$inputs[ $key ] = $field_config['default'];
					continue;
				}
				$inputs[ $key ] = 'number' === ( $field_config['type'] ?? 'number' ) ? 0.0 : '';
				continue;
			}

			$value = mvweb_bc_sanitize_input( wp_unslash( (string) $raw ), $field_config );
			$error = self::validate_field( $value, $field_config );

			if ( null !== $error ) {
				$errors[ $key ] = $error;
				continue;
			}

			$inputs[ $key ] = $value;
		}

		if ( array() !== $errors ) {
			wp_send_json_error( array( 'errors' => $errors ), 422 );
		}

		$calculate = $calc['calculate'];

		try {
			$result = $calculate( $inputs );
		} catch ( \Throwable ) {
			wp_send_json_error(
				array( 'message' => __( 'Calculation failed.', 'mvweb-build-calc' ) ),
				500
			);
		}

		$value = 0.0;
		$hints = array();

		if ( is_array( $result ) ) {
			$value = (float) ( $result['value'] ?? 0 );
			$hints = array_values( array_map( 'strval', (array) ( $result['hints'] ?? array() ) ) );
		} else {
			$value = (float) $result;
		}

		$result_cfg = (array) $calc['result'];
		$unit       = (string) ( $result_cfg['unit'] ?? '' );
		$decimals   = isset( $result_cfg['decimals'] ) ? (int) $result_cfg['decimals'] : null;
		$formatted  = mvweb_bc_format_number( $value, $decimals );

		if ( '' !== $unit ) {
			$formatted .= "\xC2\xA0" . $unit;
		}

		$summary = self::build_summary( $fields, $inputs );

		$response = array(
			'title'     => (string) ( $result_cfg['label'] ?? $calc['title'] ?? '' ),
			'value'     => $value,
			'unit'      => $unit,
			'formatted' => $formatted,
			'hints'     => $hints,
			'summary'   => $summary,
		);

		// Optional diagram payload — calculators that visualise a result
		// (e.g. beam moment / deflection plots) return a 'diagram' array from
		// calculate(). Most calculators omit it and behave exactly as before.
		if ( is_array( $result ) && isset( $result['diagram'] ) && is_array( $result['diagram'] ) ) {
			$response['diagram'] = self::sanitize_diagram( $result['diagram'] );
		}

		wp_send_json_success( $response );
	}

	/**
	 * Sanitize a diagram payload returned by a calculator.
	 *
	 * Calculators that visualise a result (beam strength / deflection) return a
	 * 'diagram' array describing a beam schematic and a plot. The frontend draws
	 * it as inline SVG. Only a fixed, known shape is allowed through:
	 *   - kind:    'beam' (only supported schematic for now)
	 *   - support: 'simple' | 'cantilever' | 'fixed'
	 *   - load:    'udl' | 'point'
	 *   - plot:    'moment' | 'deflection'
	 *   - curve:   array of floats in [0..1] — the normalised plot ordinates,
	 *              sampled left-to-right along the span (max 64 points)
	 *   - peak:    optional label string shown at the curve extremum
	 *
	 * @since 1.0.9
	 * @param array<string, mixed> $diagram Raw diagram array from calculate().
	 * @return array<string, mixed> Sanitized diagram safe for JSON output.
	 */
	private static function sanitize_diagram( array $diagram ): array {
		$support = (string) ( $diagram['support'] ?? 'simple' );
		$load    = (string) ( $diagram['load'] ?? 'udl' );
		$plot    = (string) ( $diagram['plot'] ?? 'moment' );

		if ( ! in_array( $support, array( 'simple', 'cantilever', 'fixed' ), true ) ) {
			$support = 'simple';
		}
		if ( ! in_array( $load, array( 'udl', 'point' ), true ) ) {
			$load = 'udl';
		}
		if ( ! in_array( $plot, array( 'moment', 'deflection' ), true ) ) {
			$plot = 'moment';
		}

		$curve = array();
		foreach ( (array) ( $diagram['curve'] ?? array() ) as $point ) {
			$num     = (float) $point;
			$curve[] = is_finite( $num ) ? $num : 0.0;
			if ( count( $curve ) >= 64 ) {
				break;
			}
		}

		return array(
			'kind'    => 'beam',
			'support' => $support,
			'load'    => $load,
			'plot'    => $plot,
			'curve'   => $curve,
			'peak'    => isset( $diagram['peak'] ) ? (string) $diagram['peak'] : '',
		);
	}

	/**
	 * Build a summary of input values for display in the result box.
	 *
	 * Returns an array of associative items `{label, value}` in the order
	 * the fields are declared in the calculator. `radio` and `select` values
	 * are translated through their `options` map; `number` values are
	 * rendered with their unit suffix.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $fields Calculator field config.
	 * @param array<string, mixed> $inputs Sanitized user input.
	 * @return array<int, array{label: string, value: string}>
	 */
	private static function build_summary( array $fields, array $inputs ): array {
		$summary = array();

		foreach ( $fields as $key => $field_config ) {
			$field_config = (array) $field_config;
			$key          = (string) $key;

			if ( ! array_key_exists( $key, $inputs ) ) {
				continue;
			}

			$label = (string) ( $field_config['label'] ?? $key );
			$type  = (string) ( $field_config['type'] ?? 'number' );
			$raw   = $inputs[ $key ];
			$value = '';

			if ( 'number' === $type ) {
				$num  = (float) $raw;
				$unit = (string) ( $field_config['unit'] ?? '' );
				if ( is_finite( $num ) && fmod( $num, 1.0 ) === 0.0 ) {
					$value = (string) (int) $num;
				} else {
					$value = rtrim( rtrim( number_format( $num, 10, '.', '' ), '0' ), '.' );
				}
				if ( '' === $value || '-' === $value ) {
					$value = '0';
				}
				if ( '' !== $unit ) {
					$value .= "\xC2\xA0" . $unit;
				}
			} elseif ( 'select' === $type || 'radio' === $type ) {
				$options = mvweb_bc_flatten_options( (array) ( $field_config['options'] ?? array() ) );
				$value   = (string) ( $options[ (string) $raw ] ?? (string) $raw );
			} else {
				$value = (string) $raw;
			}

			$summary[] = array(
				'label' => $label,
				'value' => $value,
			);
		}

		return $summary;
	}

	/**
	 * Validate a single field value.
	 *
	 * @since 1.0.0
	 * @param int|float|string     $value        Sanitized value.
	 * @param array<string, mixed> $field_config Field configuration.
	 * @return string|null Error message or null on success.
	 */
	private static function validate_field( int|float|string $value, array $field_config ): ?string {
		$type = (string) ( $field_config['type'] ?? 'number' );

		if ( 'number' === $type ) {
			$num = (float) $value;

			if ( ! is_finite( $num ) ) {
				return __( 'Invalid value.', 'mvweb-build-calc' );
			}

			if ( isset( $field_config['min'] ) && $num < (float) $field_config['min'] ) {
				return sprintf(
					/* translators: %s: minimum value */
					__( 'Minimum value is %s.', 'mvweb-build-calc' ),
					(string) $field_config['min']
				);
			}

			if ( isset( $field_config['max'] ) && $num > (float) $field_config['max'] ) {
				return sprintf(
					/* translators: %s: maximum value */
					__( 'Maximum value is %s.', 'mvweb-build-calc' ),
					(string) $field_config['max']
				);
			}

			return null;
		}

		if ( 'select' === $type || 'radio' === $type ) {
			$options = array_map( 'strval', array_keys( mvweb_bc_flatten_options( (array) ( $field_config['options'] ?? array() ) ) ) );

			if ( ! in_array( (string) $value, $options, true ) ) {
				return __( 'Invalid choice.', 'mvweb-build-calc' );
			}

			return null;
		}

		return null;
	}
}

MVweb_BC_Ajax::init();
