<?php
/**
 * Calculator: wall insulation thickness.
 *
 * Preliminary estimate. From the required wall heat-transfer resistance for the
 * region (R_req = a·ГСОП + b, SP 50.13330 Table 3) minus the resistance the
 * bare wall already provides, the missing resistance is covered by insulation
 * of thickness δ = ΔR × λ.
 *
 * Model:
 *   R_req  = 0.00035 × ГСОП + 1.4   (walls, residential)
 *   R_wall = wall_thickness / λ_wall + 0.16 (surface resistances)
 *   δ      = max(0, R_req − R_wall) × λ_ins
 *
 * Sources: SP 50.13330.2012 Table 3 (a, b); operational λ values — see README.
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'wall-insulation-thickness',
	array(
		'title'       => __( 'Wall insulation thickness', 'mvweb-build-calc' ),
		'hub'         => 'heat',
		'description' => __( 'Estimates the insulation thickness a wall needs to reach the required heat-transfer resistance for the region. The required R is taken from the degree-days band (R = a·ГСОП + b, SP 50.13330.2012 Table 3 for walls); the bare wall’s own resistance is subtracted, and the rest is covered by the chosen insulation. Preliminary estimate, not a thermal design.', 'mvweb-build-calc' ),
		'formula'     => 'δ = (R_req − R_wall) × λ_ins, R_req = 0.00035 × ГСОП + 1.4',
		'legend'      => array(
			'δ'      => __( 'insulation thickness, mm', 'mvweb-build-calc' ),
			'R_req'  => __( 'required wall resistance, m²·°C/W', 'mvweb-build-calc' ),
			'R_wall' => __( 'bare wall resistance, m²·°C/W', 'mvweb-build-calc' ),
			'λ_ins'  => __( 'insulation thermal conductivity, W/(m·°C)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Insulation thickness', 'mvweb-build-calc' ),
			'unit'     => __( 'mm', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'zone'           => array(
				'type'       => 'select',
				'label'      => __( 'Climate (degree-days, ГСОП)', 'mvweb-build-calc' ),
				'default'    => '6000',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'4000' => __( 'Mild (~4000): Krasnodar, Rostov', 'mvweb-build-calc' ),
					'5000' => __( 'Moderate (~5000): Minsk, Kaliningrad', 'mvweb-build-calc' ),
					'6000' => __( 'Central (~6000): Moscow, Saint Petersburg', 'mvweb-build-calc' ),
					'7000' => __( 'Cold (~7000): Yekaterinburg, Novosibirsk', 'mvweb-build-calc' ),
					'9000' => __( 'Severe (~9000): Surgut, Yakutsk', 'mvweb-build-calc' ),
				),
			),
			'wall_material'  => array(
				'type'       => 'select',
				'label'      => __( 'Wall material', 'mvweb-build-calc' ),
				'default'    => 'brick_hollow',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'brick_solid'  => __( 'Solid brick (λ 0.81)', 'mvweb-build-calc' ),
					'brick_hollow' => __( 'Hollow brick (λ 0.50)', 'mvweb-build-calc' ),
					'aerated_d400' => __( 'Aerated concrete D400 (λ 0.117)', 'mvweb-build-calc' ),
					'aerated_d500' => __( 'Aerated concrete D500 (λ 0.147)', 'mvweb-build-calc' ),
					'timber'       => __( 'Timber (λ 0.18)', 'mvweb-build-calc' ),
					'concrete'     => __( 'Reinforced concrete (λ 2.04)', 'mvweb-build-calc' ),
				),
			),
			'wall_thickness' => array(
				'type'     => 'number',
				'label'    => __( 'Wall thickness', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'default'  => 38,
				'min'      => 5,
				'max'      => 100,
				'step'     => 1,
				'required' => true,
			),
			'insulation'     => array(
				'type'       => 'select',
				'label'      => __( 'Insulation', 'mvweb-build-calc' ),
				'default'    => 'mineral_wool',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'mineral_wool' => __( 'Mineral wool (λ 0.040)', 'mvweb-build-calc' ),
					'eps'          => __( 'EPS foam (λ 0.039)', 'mvweb-build-calc' ),
					'xps'          => __( 'Extruded polystyrene (λ 0.032)', 'mvweb-build-calc' ),
					'pir'          => __( 'PIR board (λ 0.025)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$gsop      = (float) ( $i['zone'] ?? 6000 );
			$wall_mat  = (string) ( $i['wall_material'] ?? 'brick_hollow' );
			$wall_cm   = max( 1.0, (float) ( $i['wall_thickness'] ?? 38 ) );
			$ins       = (string) ( $i['insulation'] ?? 'mineral_wool' );

			$lambda_wall = match ( $wall_mat ) {
				'brick_solid'  => 0.81,
				'aerated_d400' => 0.117,
				'aerated_d500' => 0.147,
				'timber'       => 0.18,
				'concrete'     => 2.04,
				default        => 0.50, // brick_hollow.
			};
			$lambda_ins = match ( $ins ) {
				'eps' => 0.039,
				'xps' => 0.032,
				'pir' => 0.025,
				default => 0.040, // mineral_wool.
			};

			// Required resistance for walls (SP 50.13330 Table 3).
			$r_req = 0.00035 * $gsop + 1.4;

			// Bare wall: layer + internal/external surface resistances (0.115 + 0.043 ≈ 0.16).
			$r_wall = ( $wall_cm / 100 ) / $lambda_wall + 0.16;

			$delta_r = max( 0.0, $r_req - $r_wall );
			$thick_m = $delta_r * $lambda_ins;
			$thick_mm = $thick_m * 1000;

			// Round up to the next 10 mm (insulation is sold in 50/100 mm, but 10 mm step reads cleaner).
			$thick_mm_rounded = ceil( $thick_mm / 10 ) * 10;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: required R, 2: bare wall R */
				__( 'Required wall resistance %1$s m²·°C/W; the bare wall gives %2$s.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $r_req, 2 ),
				mvweb_bc_format_number( $r_wall, 2 )
			);

			if ( $thick_mm <= 0 ) {
				$hints[] = __( 'The bare wall already meets the requirement — no insulation is needed for heat protection.', 'mvweb-build-calc' );
			} else {
				$hints[] = sprintf(
					/* translators: %s: standard board thickness mm */
					__( 'Use the next standard board up — typically %s mm.', 'mvweb-build-calc' ),
					mvweb_bc_format_number( ceil( $thick_mm / 50 ) * 50, 0 )
				);
			}

			$hints[] = __( 'Preliminary estimate. A full thermal-protection calculation per SP 50.13330 accounts for the moisture zone, thermal-uniformity factor and all layers; it does not replace a design by an engineer.', 'mvweb-build-calc' );

			return array(
				'value' => $thick_mm_rounded,
				'hints' => $hints,
			);
		},
	)
);
