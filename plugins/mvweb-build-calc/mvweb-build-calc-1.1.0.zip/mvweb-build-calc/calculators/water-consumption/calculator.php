<?php
/**
 * Calculator: household water consumption.
 *
 * Preliminary estimate. Multiplies the number of residents by a daily per-person
 * norm that depends on the plumbing level, and reports the daily and monthly
 * volume. Norms follow SP 30.13330 ranges.
 *
 * Model:
 *   daily   = people × per_person(level)
 *   monthly = daily × 30
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'water-consumption',
	array(
		'title'       => __( 'Water consumption', 'mvweb-build-calc' ),
		'hub'         => 'engineering',
		'description' => __( 'Estimates household water consumption from the number of residents and the plumbing level, and reports the daily and monthly volume. Per-person norms follow SP 30.13330 ranges; a preliminary estimate for sizing storage, pumps and a septic tank, not a metered figure.', 'mvweb-build-calc' ),
		'formula'     => 'daily = people × per_person; monthly = daily × 30',
		'legend'      => array(
			'daily'      => __( 'daily consumption, litres', 'mvweb-build-calc' ),
			'people'     => __( 'number of residents', 'mvweb-build-calc' ),
			'per_person' => __( 'daily norm per person, litres', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Daily consumption', 'mvweb-build-calc' ),
			'unit'     => __( 'l/day', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'people' => array(
				'type'     => 'number',
				'label'    => __( 'Residents', 'mvweb-build-calc' ),
				'default'  => 4,
				'min'      => 1,
				'max'      => 20,
				'step'     => 1,
				'required' => true,
			),
			'level'  => array(
				'type'       => 'select',
				'label'      => __( 'Plumbing level', 'mvweb-build-calc' ),
				'default'    => 'full',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'basic'   => __( 'Cold water + local water heater (~120 l)', 'mvweb-build-calc' ),
					'full'    => __( 'Full plumbing with bath (~200 l)', 'mvweb-build-calc' ),
					'premium' => __( 'Full plumbing + extra fixtures (~250 l)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$people = max( 1, (int) ( $i['people'] ?? 1 ) );
			$level  = (string) ( $i['level'] ?? 'full' );

			$per_person = match ( $level ) {
				'basic'   => 120.0,
				'premium' => 250.0,
				default   => 200.0, // full.
			};

			$daily   = $people * $per_person;
			$monthly = $daily * 30 / 1000; // m³.

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: people count, 2: per-person litres */
				__( '%1$d residents × %2$s l/day per person.', 'mvweb-build-calc' ),
				$people,
				mvweb_bc_format_number( $per_person, 0 )
			);

			$hints[] = sprintf(
				/* translators: %s: monthly volume m³ */
				__( 'About %s m³ per month.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $monthly, 1 )
			);

			$hints[] = __( 'Daily peaks are higher than the average — size a storage tank and pump for the morning and evening demand.', 'mvweb-build-calc' );

			$hints[] = __( 'Per-person norms follow SP 30.13330 ranges. Preliminary estimate, not a metered figure.', 'mvweb-build-calc' );

			return array(
				'value' => $daily,
				'hints' => $hints,
			);
		},
	)
);
