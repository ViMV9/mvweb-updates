<?php
/**
 * Calculator: usable floor area of a house.
 *
 * Estimates the usable (net) floor area from the external footprint, the number
 * of floors and the wall material, by subtracting the share taken by external
 * walls and internal partitions. Planning guide based on common practice.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'usable-area',
	array(
		'title'       => __( 'Usable floor area', 'mvweb-build-calc' ),
		'hub'         => 'layout',
		'description' => __( 'Estimates the usable (net) floor area of a house from its external footprint, the number of floors and the wall thickness, by subtracting the share taken by external walls and internal partitions. Planning guide based on common practice.', 'mvweb-build-calc' ),
		'formula'     => 'usable = footprint × floors × wall efficiency',
		'legend'      => array(
			'usable'    => __( 'usable floor area, m²', 'mvweb-build-calc' ),
			'footprint' => __( 'external footprint area, m²', 'mvweb-build-calc' ),
			'floors'    => __( 'number of floors', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Usable floor area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'footprint' => array(
				'type'     => 'number',
				'label'    => __( 'External footprint area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 20,
				'max'      => 2000,
				'step'     => 0.5,
				'required' => true,
			),
			'floors'    => array(
				'type'     => 'number',
				'label'    => __( 'Number of floors', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 3,
				'step'     => 1,
				'required' => true,
			),
			'walls'     => array(
				'type'       => 'select',
				'label'      => __( 'Wall thickness', 'mvweb-build-calc' ),
				'default'    => 'medium',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'thin'   => __( 'Thin (frame, up to 25 cm) — about 88% usable', 'mvweb-build-calc' ),
					'medium' => __( 'Medium (30–40 cm) — about 83% usable', 'mvweb-build-calc' ),
					'thick'  => __( 'Thick (over 40 cm) — about 78% usable', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$footprint = max( 1.0, (float) ( $i['footprint'] ?? 0 ) );
			$floors    = max( 1.0, (float) ( $i['floors'] ?? 1 ) );
			$walls     = (string) ( $i['walls'] ?? 'medium' );

			$efficiency = match ( $walls ) {
				'thin'  => 0.88,
				'thick' => 0.78,
				default => 0.83,
			};

			$gross  = $footprint * $floors;
			$usable = $gross * $efficiency;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: gross area m², 2: efficiency percent */
				__( 'Gross floor area %1$s m²; about %2$s%% is usable after walls.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $gross, 1 ),
				mvweb_bc_format_number( $efficiency * 100, 0 )
			);

			$hints[] = __( 'Usable area excludes the area taken by external walls and internal partitions, which grows with wall thickness.', 'mvweb-build-calc' );

			$hints[] = __( 'Planning estimate based on common practice — the exact figure depends on the final layout.', 'mvweb-build-calc' );

			return array(
				'value' => round( $usable, 1 ),
				'hints' => $hints,
			);
		},
	)
);
