<?php
/**
 * Calculator: walk-in wardrobe area.
 *
 * Ergonomic planning guide, not a code requirement. Based on common design
 * practice: a walk-in wardrobe needs storage runs (~0.6 m deep) plus a clear
 * passage. The layout sets how many storage walls there are and therefore the
 * minimum practical footprint; per-user area is added on top.
 *
 * Model:
 *   area = max(layout_min, users × per_user)
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'wardrobe-area',
	array(
		'title'       => __( 'Walk-in wardrobe area', 'mvweb-build-calc' ),
		'hub'         => 'rooms',
		'description' => __( 'Estimates the recommended walk-in wardrobe area from its layout and the number of users. This is an ergonomic planning guide based on common design practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'A = max(layout_min, users × per_user)',
		'legend'      => array(
			'A'          => __( 'recommended area, m²', 'mvweb-build-calc' ),
			'layout_min' => __( 'practical minimum by layout (linear 2, corner 3, U-shaped 4, walk-through 4 m²)', 'mvweb-build-calc' ),
			'users'      => __( 'number of users', 'mvweb-build-calc' ),
			'per_user'   => __( 'storage allowance per user (~2 m²)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'users'  => array(
				'type'     => 'number',
				'label'    => __( 'Users', 'mvweb-build-calc' ),
				'default'  => 2,
				'min'      => 1,
				'max'      => 10,
				'step'     => 1,
				'required' => true,
			),
			'layout' => array(
				'type'     => 'select',
				'label'    => __( 'Layout', 'mvweb-build-calc' ),
				'default'  => 'linear',
				'required' => true,
				'options'  => array(
					'linear'       => __( 'Linear (one wall)', 'mvweb-build-calc' ),
					'corner'       => __( 'Corner (L-shaped)', 'mvweb-build-calc' ),
					'u_shaped'     => __( 'U-shaped (three walls)', 'mvweb-build-calc' ),
					'walk_through' => __( 'Walk-through', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$users  = max( 1, (int) ( $i['users'] ?? 2 ) );
			$layout = (string) ( $i['layout'] ?? 'linear' );

			$layout_min = match ( $layout ) {
				'corner'       => 3.0,
				'u_shaped'     => 4.0,
				'walk_through' => 4.0,
				default        => 2.0, // linear.
			};

			$per_user = 2.0;
			$area     = max( $layout_min, $users * $per_user );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: users count, 2: per-user area, 3: layout minimum */
				__( '%1$d user(s) × ~%2$s m², not below the %3$s m² layout minimum.', 'mvweb-build-calc' ),
				$users,
				mvweb_bc_format_number( $per_user, 0 ),
				mvweb_bc_format_number( $layout_min, 0 )
			);

			$hints[] = __( 'Keep a clear passage of at least 0.7 m in front of storage; for a walk-through layout count both side runs.', 'mvweb-build-calc' );

			$hints[] = __( 'This is an ergonomic planning guide based on common design practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
