<?php
/**
 * Calculator: porch steps.
 *
 * Ergonomic guide. From the height of the porch above the ground and a target
 * riser, returns the number of steps, the actual riser, the tread depth and
 * the horizontal run, with the comfort check 2·riser + tread.
 *
 * Model:
 *   steps  = round(height / target_riser)
 *   riser  = height / steps
 *   run    = steps × tread
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'porch-steps',
	array(
		'title'       => __( 'Porch steps', 'mvweb-build-calc' ),
		'hub'         => 'outbuildings',
		'description' => __( 'Calculates the number of porch steps from the porch height above the ground and a target riser, with the actual riser, the tread depth, the horizontal run and the comfort check 2·riser + tread. Ergonomic guide based on common practice and SP 55.13330 (outdoor steps usually have a lower riser and a deeper tread than indoor stairs).', 'mvweb-build-calc' ),
		'formula'     => 'steps = round(height / riser), run = steps × tread',
		'legend'      => array(
			'height' => __( 'porch height above the ground, cm', 'mvweb-build-calc' ),
			'riser'  => __( 'step height, cm', 'mvweb-build-calc' ),
			'tread'  => __( 'step depth, cm', 'mvweb-build-calc' ),
			'run'    => __( 'horizontal run of the flight, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Number of steps', 'mvweb-build-calc' ),
			'unit'     => __( 'pcs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'height'       => array(
				'type'     => 'number',
				'label'    => __( 'Porch height above the ground', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 10,
				'max'      => 300,
				'step'     => 1,
				'required' => true,
			),
			'target_riser' => array(
				'type'     => 'number',
				'label'    => __( 'Target step height', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'default'  => 15,
				'min'      => 10,
				'max'      => 20,
				'step'     => 0.5,
				'required' => true,
			),
			'tread'        => array(
				'type'     => 'number',
				'label'    => __( 'Step depth (tread)', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'default'  => 30,
				'min'      => 25,
				'max'      => 40,
				'step'     => 1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$height       = max( 1.0, (float) ( $i['height'] ?? 0 ) );
			$target_riser = max( 1.0, (float) ( $i['target_riser'] ?? 15 ) );
			$tread        = max( 1.0, (float) ( $i['tread'] ?? 30 ) );

			$steps = max( 1, (int) round( $height / $target_riser ) );
			$riser = $height / $steps;
			$run   = $steps * $tread / 100; // metres.

			$comfort = 2 * $riser + $tread;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: actual riser cm, 2: tread cm, 3: run m */
				__( 'Actual riser %1$s cm, tread %2$s cm, horizontal run %3$s m.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $riser, 1 ),
				mvweb_bc_format_number( $tread, 0 ),
				mvweb_bc_format_number( $run, 2 )
			);

			$hints[] = sprintf(
				/* translators: %s: comfort sum cm */
				__( 'Comfort formula 2·riser + tread = %s cm (comfortable range 60–64 cm).', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $comfort, 0 )
			);

			if ( $riser > 17.0 ) {
				$hints[] = __( 'A riser over 17 cm is steep for an outdoor porch — add a step to lower it.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Outdoor steps work best with a gentle riser (12–15 cm) and a deep tread (30–35 cm); a slight forward slope sheds rainwater.', 'mvweb-build-calc' );

			$hints[] = __( 'A porch wider than ~3 steps usually needs a handrail; check the local rules for public-facing entrances.', 'mvweb-build-calc' );

			return array(
				'value' => (float) $steps,
				'hints' => $hints,
			);
		},
	)
);
