<?php
/**
 * Calculator: internal partitions area.
 *
 * Net area of internal partitions = total partition length × height minus the
 * internal door openings. Geometric calculation.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'internal-walls-area',
	array(
		'title'       => __( 'Internal partitions area', 'mvweb-build-calc' ),
		'hub'         => 'walls',
		'description' => __( 'Calculates the net area of internal partitions — total partition length times height, minus the internal door openings. Use this area for partition material and finishing take-offs.', 'mvweb-build-calc' ),
		'formula'     => 'area = length × H − door openings',
		'legend'      => array(
			'area'   => __( 'net partition area, m²', 'mvweb-build-calc' ),
			'length' => __( 'total partition length, m', 'mvweb-build-calc' ),
			'H'      => __( 'partition height, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Net partitions area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'length' => array(
				'type'     => 'number',
				'label'    => __( 'Total partition length', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 500,
				'step'     => 0.1,
				'required' => true,
			),
			'height' => array(
				'type'     => 'number',
				'label'    => __( 'Partition height', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 6,
				'step'     => 0.1,
				'required' => true,
			),
			'doors'  => array(
				'type'     => 'number',
				'label'    => __( 'Number of internal doors', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 50,
				'step'     => 1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$length = max( 0.0, (float) ( $i['length'] ?? 0 ) );
			$height = max( 0.0, (float) ( $i['height'] ?? 0 ) );
			$doors  = max( 0.0, (float) ( $i['doors'] ?? 0 ) );

			// A standard internal door opening ≈ 0.9 × 2.1 = 1.89 m².
			$door_area = 1.89;
			$openings  = $doors * $door_area;

			$gross = $length * $height;
			$net   = max( 0.0, $gross - $openings );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: gross area m², 2: door count, 3: door openings area m² */
				__( 'Gross area %1$s m²; %2$d doors take about %3$s m².', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $gross, 1 ),
				(int) $doors,
				mvweb_bc_format_number( $openings, 1 )
			);

			$hints[] = __( 'A standard internal door opening is taken as 0.9 × 2.1 m (1.89 m²).', 'mvweb-build-calc' );

			return array(
				'value' => round( $net, 1 ),
				'hints' => $hints,
			);
		},
	)
);
