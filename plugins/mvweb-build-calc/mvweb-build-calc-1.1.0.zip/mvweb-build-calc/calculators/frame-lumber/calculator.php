<?php
/**
 * Calculator: framing lumber for stud walls.
 *
 * Volume of framing lumber for timber-frame walls: vertical studs at the chosen
 * spacing plus top and bottom plates, by wall length and height, times the stud
 * cross-section, plus a waste reserve. Geometric calculation.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'frame-lumber',
	array(
		'title'       => __( 'Framing lumber for stud walls', 'mvweb-build-calc' ),
		'hub'         => 'walls',
		'description' => __( 'Calculates the volume of framing lumber for timber-frame walls — vertical studs at the chosen spacing plus top and bottom plates, from the wall length and height and the stud cross-section, with a waste reserve. Geometric calculation.', 'mvweb-build-calc' ),
		'formula'     => 'volume = (stud length × studs + plates) × section × (1 + reserve%)',
		'legend'      => array(
			'volume' => __( 'lumber volume, m³', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Lumber volume', 'mvweb-build-calc' ),
			'unit'     => __( 'm³', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'length'  => array(
				'type'     => 'number',
				'label'    => __( 'Total wall length', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 500,
				'step'     => 0.1,
				'required' => true,
			),
			'height'  => array(
				'type'     => 'number',
				'label'    => __( 'Wall height', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 6,
				'step'     => 0.1,
				'required' => true,
			),
			'spacing' => array(
				'type'     => 'select',
				'label'    => __( 'Stud spacing', 'mvweb-build-calc' ),
				'default'  => '60',
				'required' => true,
				'options'  => array(
					'40' => __( '400 mm', 'mvweb-build-calc' ),
					'60' => __( '600 mm', 'mvweb-build-calc' ),
				),
			),
			'section' => array(
				'type'       => 'select',
				'label'      => __( 'Stud cross-section', 'mvweb-build-calc' ),
				'default'    => '50x150',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'50x100' => __( '50 × 100 mm', 'mvweb-build-calc' ),
					'50x150' => __( '50 × 150 mm', 'mvweb-build-calc' ),
					'50x200' => __( '50 × 200 mm', 'mvweb-build-calc' ),
				),
			),
			'reserve' => array(
				'type'     => 'number',
				'label'    => __( 'Waste reserve', 'mvweb-build-calc' ),
				'unit'     => __( '%', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 20,
				'step'     => 1,
				'default'  => 10,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$length  = max( 0.0, (float) ( $i['length'] ?? 0 ) );
			$height  = max( 0.0, (float) ( $i['height'] ?? 0 ) );
			$spacing = (float) ( $i['spacing'] ?? 60 ) / 100; // cm → m.
			$reserve = max( 0.0, (float) ( $i['reserve'] ?? 0 ) );
			$section = (string) ( $i['section'] ?? '50x150' );

			$dims = match ( $section ) {
				'50x100' => array( 0.05, 0.10 ),
				'50x200' => array( 0.05, 0.20 ),
				default  => array( 0.05, 0.15 ),
			};
			$sec_area = $dims[0] * $dims[1];

			// Studs: one per spacing along the length, plus one to close the end.
			$studs       = $spacing > 0 ? (int) ceil( $length / $spacing ) + 1 : 0;
			$stud_run    = $studs * $height;
			// Plates: top + bottom run the full length (×2), often doubled top → ×3 total runs.
			$plate_run   = $length * 3;
			$total_run   = $stud_run + $plate_run;

			$volume = $total_run * $sec_area * ( 1 + $reserve / 100 );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: stud count, 2: total linear metres */
				__( 'About %1$d studs; %2$s linear metres of lumber in total.', 'mvweb-build-calc' ),
				$studs,
				mvweb_bc_format_number( $total_run, 1 )
			);

			$hints[] = __( 'Includes top and bottom plates (top plate doubled). Headers, braces and blocking are extra.', 'mvweb-build-calc' );

			$hints[] = __( 'Geometric estimate — timber is sold by volume (m³).', 'mvweb-build-calc' );

			return array(
				'value' => round( $volume, 2 ),
				'hints' => $hints,
			);
		},
	)
);
