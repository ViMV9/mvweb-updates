<?php
/**
 * Calculator: bricks count.
 *
 * Number of bricks for a wall from the wall area, the masonry thickness and the
 * brick height, using the standard per-m² consumption with mortar joints.
 * Consumption rates are the common figures for GOST 530 brick formats.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'bricks-count',
	array(
		'title'       => __( 'Bricks count', 'mvweb-build-calc' ),
		'hub'         => 'walls',
		'description' => __( 'Calculates the number of bricks for a wall from the wall area, the masonry thickness (half-brick to two bricks) and the brick type, using the standard per-m² consumption including mortar joints. Consumption rates follow common figures for GOST 530 formats.', 'mvweb-build-calc' ),
		'formula'     => 'bricks = area × rate(thickness, type) × (1 + reserve%)',
		'legend'      => array(
			'area' => __( 'wall area, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Bricks needed', 'mvweb-build-calc' ),
			'unit'     => __( 'pcs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'area'      => array(
				'type'     => 'number',
				'label'    => __( 'Wall area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 5000,
				'step'     => 0.5,
				'required' => true,
			),
			'thickness' => array(
				'type'       => 'select',
				'label'      => __( 'Masonry thickness', 'mvweb-build-calc' ),
				'default'    => 'one',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'half'         => __( 'Half brick (120 mm)', 'mvweb-build-calc' ),
					'one'          => __( 'One brick (250 mm)', 'mvweb-build-calc' ),
					'one_and_half' => __( 'One and a half bricks (380 mm)', 'mvweb-build-calc' ),
					'two'          => __( 'Two bricks (510 mm)', 'mvweb-build-calc' ),
				),
			),
			'type'      => array(
				'type'       => 'select',
				'label'      => __( 'Brick type', 'mvweb-build-calc' ),
				'default'    => 'single',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'single'   => __( 'Single (65 mm) — with joints', 'mvweb-build-calc' ),
					'one_half' => __( 'Thickened 1.5 (88 mm) — with joints', 'mvweb-build-calc' ),
					'double'   => __( 'Double (138 mm) — with joints', 'mvweb-build-calc' ),
				),
			),
			'reserve'   => array(
				'type'     => 'number',
				'label'    => __( 'Waste reserve', 'mvweb-build-calc' ),
				'unit'     => __( '%', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 15,
				'step'     => 1,
				'default'  => 5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area      = max( 0.0, (float) ( $i['area'] ?? 0 ) );
			$thickness = (string) ( $i['thickness'] ?? 'one' );
			$type      = (string) ( $i['type'] ?? 'single' );
			$reserve   = max( 0.0, (float) ( $i['reserve'] ?? 0 ) );

			// Bricks per m² with 10 mm mortar joints, by thickness and type.
			// Common reference table (GOST 530): with joints.
			$rates = array(
				'single'   => array(
					'half'         => 51,
					'one'          => 102,
					'one_and_half' => 153,
					'two'          => 204,
				),
				'one_half' => array(
					'half'         => 39,
					'one'          => 78,
					'one_and_half' => 117,
					'two'          => 156,
				),
				'double'   => array(
					'half'         => 26,
					'one'          => 52,
					'one_and_half' => 78,
					'two'          => 104,
				),
			);

			$rate   = $rates[ $type ][ $thickness ] ?? 102;
			$bricks = (int) ceil( $area * $rate * ( 1 + $reserve / 100 ) );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: rate per m², 2: reserve percent */
				__( 'Consumption %1$d bricks per m² (with joints), including a %2$s%% reserve.', 'mvweb-build-calc' ),
				$rate,
				mvweb_bc_format_number( $reserve, 0 )
			);

			$hints[] = __( 'Rates include 10 mm mortar joints. Without joints the count is roughly 15–20% higher.', 'mvweb-build-calc' );

			$hints[] = __( 'Geometric estimate based on common GOST 530 consumption figures.', 'mvweb-build-calc' );

			return array(
				'value' => $bricks,
				'hints' => $hints,
			);
		},
	)
);
