<?php
/**
 * Calculator: number of plumbing points.
 *
 * Ergonomic guide. Sums the plumbing fixtures (water + drain points) from the
 * chosen fixture counts, reporting the total points used to size the supply
 * manifold and the drainage.
 *
 * Model:
 *   points = Σ chosen fixtures
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'plumbing-points',
	array(
		'title'       => __( 'Plumbing points', 'mvweb-build-calc' ),
		'hub'         => 'engineering',
		'description' => __( 'Sums the plumbing fixtures of the home — each needs a water connection and most a drain — to give the total number of plumbing points for sizing the supply manifold and the drainage. Ergonomic guide based on common practice.', 'mvweb-build-calc' ),
		'formula'     => 'points = Σ fixtures',
		'legend'      => array(
			'points' => __( 'total plumbing points', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Total plumbing points', 'mvweb-build-calc' ),
			'unit'     => __( 'pcs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'sinks'    => array(
				'type'     => 'number',
				'label'    => __( 'Wash basins / sinks', 'mvweb-build-calc' ),
				'default'  => 3,
				'min'      => 0,
				'max'      => 20,
				'step'     => 1,
				'required' => true,
			),
			'toilets'  => array(
				'type'     => 'number',
				'label'    => __( 'Toilets', 'mvweb-build-calc' ),
				'default'  => 2,
				'min'      => 0,
				'max'      => 10,
				'step'     => 1,
				'required' => true,
			),
			'baths'    => array(
				'type'     => 'number',
				'label'    => __( 'Baths / showers', 'mvweb-build-calc' ),
				'default'  => 2,
				'min'      => 0,
				'max'      => 10,
				'step'     => 1,
				'required' => true,
			),
			'machines' => array(
				'type'     => 'number',
				'label'    => __( 'Washing / dishwashing machines', 'mvweb-build-calc' ),
				'default'  => 2,
				'min'      => 0,
				'max'      => 10,
				'step'     => 1,
				'required' => true,
			),
			'outdoor'  => array(
				'type'     => 'number',
				'label'    => __( 'Outdoor taps', 'mvweb-build-calc' ),
				'default'  => 1,
				'min'      => 0,
				'max'      => 10,
				'step'     => 1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$sinks    = max( 0, (int) ( $i['sinks'] ?? 0 ) );
			$toilets  = max( 0, (int) ( $i['toilets'] ?? 0 ) );
			$baths    = max( 0, (int) ( $i['baths'] ?? 0 ) );
			$machines = max( 0, (int) ( $i['machines'] ?? 0 ) );
			$outdoor  = max( 0, (int) ( $i['outdoor'] ?? 0 ) );

			$total = $sinks + $toilets + $baths + $machines + $outdoor;

			// Drain points: outdoor taps usually have no drain.
			$drains = $sinks + $toilets + $baths + $machines;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: water points, 2: drain points */
				__( '%1$d water points; about %2$d need a drain.', 'mvweb-build-calc' ),
				$total,
				$drains
			);

			$hints[] = __( 'Group wet rooms back-to-back or stacked between floors to keep the supply and drain runs short.', 'mvweb-build-calc' );

			$hints[] = __( 'A toilet needs a 100 mm drain; sinks, baths and machines use 50 mm with the right fall. Ergonomic guide, not a plumbing design.', 'mvweb-build-calc' );

			return array(
				'value' => (float) $total,
				'hints' => $hints,
			);
		},
	)
);
