<?php
/**
 * Calculator: recommended garage size.
 *
 * Ergonomic planning guide, not a code requirement. Sizes a garage from the
 * car footprint plus working clearances around it (door swing, walk-around,
 * front workbench / storage zone).
 *
 * Model:
 *   width  = car_width  + 2 × side_clearance
 *   length = car_length + front_clearance + rear_clearance
 *   area   = width × length
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'garage-size',
	array(
		'title'       => __( 'Garage size', 'mvweb-build-calc' ),
		'hub'         => 'outbuildings',
		'description' => __( 'Estimates the recommended internal garage size from the car dimensions plus comfortable clearances for opening the doors, walking around the car and a front storage or workbench zone. This is an ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'A = (car_width + 2 × side) × (car_length + front + rear)',
		'legend'      => array(
			'A'     => __( 'recommended internal area, m²', 'mvweb-build-calc' ),
			'side'  => __( 'side clearance for door swing and walk-around, m', 'mvweb-build-calc' ),
			'front' => __( 'front zone for storage / workbench, m', 'mvweb-build-calc' ),
			'rear'  => __( 'rear zone behind the car, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended internal area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'car_size' => array(
				'type'       => 'select',
				'label'      => __( 'Car class', 'mvweb-build-calc' ),
				'default'    => 'mid',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'small' => __( 'Small (city car, ~3.8 × 1.7 m)', 'mvweb-build-calc' ),
					'mid'   => __( 'Mid-size (sedan / crossover, ~4.6 × 1.85 m)', 'mvweb-build-calc' ),
					'large' => __( 'Large (SUV / minivan, ~5.1 × 2.0 m)', 'mvweb-build-calc' ),
				),
			),
			'comfort'  => array(
				'type'       => 'radio',
				'label'      => __( 'Clearance level', 'mvweb-build-calc' ),
				'default'    => 'standard',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'tight'    => __( 'Tight (parking only)', 'mvweb-build-calc' ),
					'standard' => __( 'Standard (parking + walk-around)', 'mvweb-build-calc' ),
					'workshop' => __( 'Spacious (workbench + storage)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$car     = (string) ( $i['car_size'] ?? 'mid' );
			$comfort = (string) ( $i['comfort'] ?? 'standard' );

			$dims = match ( $car ) {
				'small' => array( 1.7, 3.8 ),
				'large' => array( 2.0, 5.1 ),
				default => array( 1.85, 4.6 ), // mid.
			};
			$car_w = $dims[0];
			$car_l = $dims[1];

			// Clearances in metres: side (each side), front, rear.
			$clear = match ( $comfort ) {
				'tight'    => array( 0.5, 0.5, 0.4 ),
				'workshop' => array( 1.0, 1.5, 0.7 ),
				default    => array( 0.7, 0.8, 0.5 ), // standard.
			};

			$width  = $car_w + 2 * $clear[0];
			$length = $car_l + $clear[1] + $clear[2];
			$area   = $width * $length;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: internal width m, 2: internal length m */
				__( 'Recommended internal size: %1$s × %2$s m.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $width, 1 ),
				mvweb_bc_format_number( $length, 1 )
			);

			$hints[] = sprintf(
				/* translators: 1: car width m, 2: car length m */
				__( 'Based on a car of about %1$s × %2$s m plus the chosen clearances.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $car_w, 2 ),
				mvweb_bc_format_number( $car_l, 1 )
			);

			$hints[] = __( 'A single garage is usually at least 3 m wide; a comfortable one is 4 m. Add height clearance of at least 2.2 m for the door.', 'mvweb-build-calc' );

			$hints[] = __( 'Ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
