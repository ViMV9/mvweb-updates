<?php
/**
 * Calculator: lintels over openings.
 *
 * Number of lintel beams over openings and their total length: each opening
 * needs a number of lintels across the wall thickness, each of length = opening
 * width + a bearing at both ends. Geometric calculation.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'lintels-count',
	array(
		'title'       => __( 'Lintels over openings', 'mvweb-build-calc' ),
		'hub'         => 'walls',
		'description' => __( 'Calculates the number of lintel beams over openings and their total length: each opening takes a number of lintels across the wall thickness, each of length equal to the opening width plus a bearing at both ends. Geometric calculation.', 'mvweb-build-calc' ),
		'formula'     => 'lintels = openings × per_opening, length = width + 2 × bearing',
		'legend'      => array(
			'lintels' => __( 'number of lintel beams', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Lintel beams needed', 'mvweb-build-calc' ),
			'unit'     => __( 'pcs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'openings'    => array(
				'type'     => 'number',
				'label'    => __( 'Number of openings', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 100,
				'step'     => 1,
				'required' => true,
			),
			'width'       => array(
				'type'     => 'number',
				'label'    => __( 'Average opening width', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.5,
				'max'      => 6,
				'step'     => 0.1,
				'required' => true,
			),
			'per_opening' => array(
				'type'       => 'select',
				'label'      => __( 'Lintels per opening (across wall thickness)', 'mvweb-build-calc' ),
				'default'    => '3',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'2' => __( '2 (thin wall)', 'mvweb-build-calc' ),
					'3' => __( '3 (one-brick / 30–38 cm)', 'mvweb-build-calc' ),
					'4' => __( '4 (thick wall)', 'mvweb-build-calc' ),
				),
			),
			'bearing'     => array(
				'type'     => 'number',
				'label'    => __( 'Bearing at each end', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 12,
				'max'      => 35,
				'step'     => 1,
				'default'  => 25,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$openings    = max( 0.0, (float) ( $i['openings'] ?? 0 ) );
			$width       = max( 0.0, (float) ( $i['width'] ?? 0 ) );
			$per_opening = (int) ( $i['per_opening'] ?? 3 );
			$bearing     = max( 0.0, (float) ( $i['bearing'] ?? 25 ) ) / 100; // cm → m.

			$lintels      = (int) ( $openings * $per_opening );
			$lintel_length = $width + 2 * $bearing;
			$total_length  = $lintels * $lintel_length;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: single lintel length m, 2: bearing cm */
				__( 'Each lintel is %1$s m long (opening width plus %2$s cm bearing at both ends).', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $lintel_length, 2 ),
				mvweb_bc_format_number( $bearing * 100, 0 )
			);

			$hints[] = sprintf(
				/* translators: %s: total length m */
				__( 'Total lintel length about %s m.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $total_length, 1 )
			);

			$hints[] = __( 'Wide openings (over ~2 m) usually need reinforced-concrete or steel lintels designed individually.', 'mvweb-build-calc' );

			$hints[] = __( 'Geometric estimate — confirm the lintel type and bearing with the wall design.', 'mvweb-build-calc' );

			return array(
				'value' => $lintels,
				'hints' => $hints,
			);
		},
	)
);
