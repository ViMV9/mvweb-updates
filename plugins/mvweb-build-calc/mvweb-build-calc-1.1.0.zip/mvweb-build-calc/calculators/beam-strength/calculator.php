<?php
/**
 * Calculator: bending strength of a rectangular beam (timber or steel).
 *
 * Estimate, not a design calculation. Computes the bending moment from the
 * chosen support scheme and load, the rectangular section modulus W = b·h²/6,
 * the bending stress σ = M/W and the strength margin against the design
 * resistance R. Returns a moment-diagram payload for the frontend.
 *
 * Sources (design resistances verified against official texts):
 *   - SP 16.13330.2017 (steel), Ry = 240 MPa (S245, ≤20 mm), 320 MPa (S345).
 *   - SP 64.13330.2017 tab. 3 (timber bending): 1st grade 14, 2nd 13, 3rd 8.5 MPa.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'beam-strength',
	array(
		'title'       => __( 'Beam bending strength', 'mvweb-build-calc' ),
		'hub'         => 'structures',
		'description' => __( 'Estimates the bending strength of a rectangular timber or steel beam: bending moment, section modulus, stress and the strength margin against the design resistance. This is a preliminary estimate based on SP 16.13330 (steel) and SP 64.13330 (timber), not a substitute for a structural design by an engineer.', 'mvweb-build-calc' ),
		'formula'     => 'σ = M / W, W = b × h² / 6, margin = (R − σ) / R × 100',
		'legend'      => array(
			'σ' => __( 'bending stress, MPa', 'mvweb-build-calc' ),
			'M' => __( 'maximum bending moment, kN·m', 'mvweb-build-calc' ),
			'W' => __( 'section modulus, cm³', 'mvweb-build-calc' ),
			'b' => __( 'section width, cm', 'mvweb-build-calc' ),
			'h' => __( 'section height, cm', 'mvweb-build-calc' ),
			'R' => __( 'design bending resistance of the material, MPa', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Strength margin', 'mvweb-build-calc' ),
			'unit'     => __( '%', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'material'  => array(
				'type'       => 'select',
				'label'      => __( 'Material and grade', 'mvweb-build-calc' ),
				'default'    => 'timber2',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'timber1'  => __( 'Timber, pine/spruce, 1st grade (R = 14 MPa)', 'mvweb-build-calc' ),
					'timber2'  => __( 'Timber, pine/spruce, 2nd grade (R = 13 MPa)', 'mvweb-build-calc' ),
					'timber3'  => __( 'Timber, pine/spruce, 3rd grade (R = 8.5 MPa)', 'mvweb-build-calc' ),
					'steel245' => __( 'Steel S245 (R = 240 MPa)', 'mvweb-build-calc' ),
					'steel345' => __( 'Steel S345 (R = 320 MPa)', 'mvweb-build-calc' ),
				),
			),
			'support'   => array(
				'type'       => 'radio',
				'label'      => __( 'Support scheme', 'mvweb-build-calc' ),
				'default'    => 'simple',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'simple'     => __( 'Simply supported (on two supports)', 'mvweb-build-calc' ),
					'cantilever' => __( 'Cantilever (fixed at one end)', 'mvweb-build-calc' ),
				),
			),
			'load_type' => array(
				'type'       => 'radio',
				'label'      => __( 'Load type', 'mvweb-build-calc' ),
				'default'    => 'udl',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'udl'   => __( 'Distributed (kN/m)', 'mvweb-build-calc' ),
					'point' => __( 'Point load (kN)', 'mvweb-build-calc' ),
				),
			),
			'load'      => array(
				'type'     => 'number',
				'label'    => __( 'Load value', 'mvweb-build-calc' ),
				'unit'     => __( 'kN/m or kN', 'mvweb-build-calc' ),
				'min'      => 0.1,
				'max'      => 10000,
				'step'     => 0.1,
				'required' => true,
			),
			'span'      => array(
				'type'     => 'number',
				'label'    => __( 'Span / length', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.1,
				'max'      => 24,
				'step'     => 0.1,
				'required' => true,
			),
			'width'     => array(
				'type'     => 'number',
				'label'    => __( 'Section width b', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 200,
				'step'     => 0.5,
				'required' => true,
			),
			'height'    => array(
				'type'     => 'number',
				'label'    => __( 'Section height h', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 200,
				'step'     => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$material = (string) ( $i['material'] ?? 'timber2' );
			$support  = (string) ( $i['support'] ?? 'simple' );
			$type     = (string) ( $i['load_type'] ?? 'udl' );
			$load     = max( 0.0, (float) ( $i['load'] ?? 0 ) );
			$span     = max( 0.01, (float) ( $i['span'] ?? 0 ) );
			$b        = max( 0.1, (float) ( $i['width'] ?? 0 ) );
			$h        = max( 0.1, (float) ( $i['height'] ?? 0 ) );

			$resistances = array(
				'timber1'  => 14.0,
				'timber2'  => 13.0,
				'timber3'  => 8.5,
				'steel245' => 240.0,
				'steel345' => 320.0,
			);
			$r = $resistances[ $material ] ?? 13.0;

			// Maximum bending moment, kN·m.
			if ( 'cantilever' === $support ) {
				$moment = ( 'point' === $type ) ? $load * $span : $load * $span * $span / 2;
			} else {
				$moment = ( 'point' === $type ) ? $load * $span / 4 : $load * $span * $span / 8;
			}

			// Section modulus, cm³.
			$w = $b * $h * $h / 6;

			// Stress, MPa: M[kN·m]·10^6 N·mm / (W[cm³]·10^3 mm³) = M / W · 10^3.
			$stress = $w > 0 ? ( $moment / $w ) * 1000 : 0.0;

			$margin = $r > 0 ? ( ( $r - $stress ) / $r ) * 100 : 0.0;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: bending moment kN·m, 2: stress MPa, 3: design resistance MPa */
				__( 'Maximum moment M = %1$s kN·m, stress σ = %2$s MPa, design resistance R = %3$s MPa.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $moment, 2 ),
				mvweb_bc_format_number( $stress, 1 ),
				mvweb_bc_format_number( $r, 1 )
			);

			$hints[] = sprintf(
				/* translators: %s: section modulus cm³ */
				__( 'Section modulus W = b·h²/6 = %s cm³.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $w, 1 )
			);

			if ( $margin >= 0 ) {
				$hints[] = __( 'The section passes the bending strength check (σ ≤ R).', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'The section is overstressed (σ > R) — increase the height, width or material grade.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Preliminary estimate only. Bending strength is checked here; deflection, shear and stability are not. It does not replace a structural design by a qualified engineer.', 'mvweb-build-calc' );

			// Moment-diagram ordinates, normalised to [0..1] along the span.
			$curve  = array();
			$points = 24;
			for ( $k = 0; $k <= $points; $k++ ) {
				$x = $k / $points;
				if ( 'cantilever' === $support ) {
					// Moment grows from the free end (x=1) to the fixed end (x=0).
					$m = ( 'point' === $type ) ? ( 1 - $x ) : ( 1 - $x ) * ( 1 - $x );
				} elseif ( 'point' === $type ) {
					// Triangular: peak at mid-span.
					$m = 1 - abs( 2 * $x - 1 );
				} else {
					// Parabolic: 4x(1-x), peak at mid-span.
					$m = 4 * $x * ( 1 - $x );
				}
				$curve[] = round( $m, 4 );
			}

			return array(
				'value'   => round( $margin, 1 ),
				'hints'   => $hints,
				'diagram' => array(
					'support' => $support,
					'load'    => $type,
					'plot'    => 'moment',
					'curve'   => $curve,
					'peak'    => sprintf(
						/* translators: %s: bending moment kN·m */
						__( 'Bending moment diagram, M_max = %s kN·m', 'mvweb-build-calc' ),
						mvweb_bc_format_number( $moment, 2 )
					),
				),
			);
		},
	)
);
