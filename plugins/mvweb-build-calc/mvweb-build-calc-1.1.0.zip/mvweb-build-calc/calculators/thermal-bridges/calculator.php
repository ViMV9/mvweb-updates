<?php
/**
 * Calculator: thermal bridges allowance.
 *
 * Estimate. Thermal bridges (junctions, balconies, lintels, fixings) lower the
 * wall's effective resistance below the ideal flat value. This is expressed by
 * the thermal-uniformity factor r: R_effective = R_flat × r. The calculator
 * returns the effective resistance and the extra heat-loss percentage from a
 * chosen construction quality.
 *
 * Model:
 *   r = uniformity(quality);  R_eff = R_flat × r;  extra = (1/r − 1) × 100
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'thermal-bridges',
	array(
		'title'       => __( 'Thermal bridges', 'mvweb-build-calc' ),
		'hub'         => 'heat',
		'description' => __( 'Estimates how much thermal bridges (junctions, balconies, lintels, fixings) reduce a wall’s effective resistance and add to the heat loss, using the thermal-uniformity factor r for a chosen construction quality. Returns the effective resistance and the extra loss percentage. Preliminary estimate per SP 230.1325800, not a detailed thermal-bridge calculation.', 'mvweb-build-calc' ),
		'formula'     => 'R_eff = R_flat × r; extra loss = (1/r − 1) × 100%',
		'legend'      => array(
			'R_flat' => __( 'flat-zone wall resistance, m²·°C/W', 'mvweb-build-calc' ),
			'r'      => __( 'thermal-uniformity factor (0…1)', 'mvweb-build-calc' ),
			'R_eff'  => __( 'effective resistance with bridges, m²·°C/W', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Effective resistance', 'mvweb-build-calc' ),
			'unit'     => __( 'm²·°C/W', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'r_flat'  => array(
				'type'     => 'number',
				'label'    => __( 'Flat-zone wall resistance', 'mvweb-build-calc' ),
				'unit'     => __( 'm²·°C/W', 'mvweb-build-calc' ),
				'default'  => 3.5,
				'min'      => 0.5,
				'max'      => 10,
				'step'     => 0.1,
				'required' => true,
			),
			'quality' => array(
				'type'       => 'select',
				'label'      => __( 'Construction quality (junction detailing)', 'mvweb-build-calc' ),
				'default'    => 'average',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'good'    => __( 'Good — continuous insulation, few bridges (r ≈ 0.92)', 'mvweb-build-calc' ),
					'average' => __( 'Average — typical detailing (r ≈ 0.80)', 'mvweb-build-calc' ),
					'poor'    => __( 'Poor — many bridges, balconies, fixings (r ≈ 0.65)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$r_flat  = max( 0.1, (float) ( $i['r_flat'] ?? 3.5 ) );
			$quality = (string) ( $i['quality'] ?? 'average' );

			$r = match ( $quality ) {
				'good' => 0.92,
				'poor' => 0.65,
				default => 0.80, // average.
			};

			$r_eff = $r_flat * $r;
			$extra = ( 1 / $r - 1 ) * 100;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: uniformity factor, 2: extra loss percent */
				__( 'Uniformity factor r = %1$s; thermal bridges add about %2$s%% to the heat loss.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $r, 2 ),
				mvweb_bc_format_number( $extra, 0 )
			);

			$hints[] = __( 'Reinforced-concrete balconies, window reveals, mortar joints and metal fixings are the worst bridges — wrap them in continuous insulation.', 'mvweb-build-calc' );

			$hints[] = __( 'Preliminary estimate per SP 230.1325800. A detailed calculation models each junction’s linear loss; it does not replace a design.', 'mvweb-build-calc' );

			return array(
				'value' => $r_eff,
				'hints' => $hints,
			);
		},
	)
);
