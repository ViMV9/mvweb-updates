<?php
/**
 * Calculator: eaves and soffit area.
 *
 * Area of the eaves and gable overhang soffits = the roof perimeter times the
 * horizontal overhang width. Geometric calculation.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'eaves-soffit-area',
	array(
		'title'       => __( 'Eaves and soffit area', 'mvweb-build-calc' ),
		'hub'         => 'roof',
		'description' => __( 'Calculates the area of the eaves and gable overhang soffits — the roof perimeter times the horizontal overhang width — for ordering soffit boards and trims. Geometric calculation.', 'mvweb-build-calc' ),
		'formula'     => 'area = perimeter × overhang width',
		'legend'      => array(
			'area'      => __( 'soffit area, m²', 'mvweb-build-calc' ),
			'perimeter' => __( 'roof overhang perimeter, m', 'mvweb-build-calc' ),
			'overhang'  => __( 'horizontal overhang width, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Soffit area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'perimeter' => array(
				'type'     => 'number',
				'label'    => __( 'Roof overhang perimeter', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 4,
				'max'      => 500,
				'step'     => 0.1,
				'required' => true,
			),
			'overhang'  => array(
				'type'     => 'number',
				'label'    => __( 'Horizontal overhang width', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.2,
				'max'      => 1.5,
				'step'     => 0.05,
				'default'  => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$perimeter = max( 0.0, (float) ( $i['perimeter'] ?? 0 ) );
			$overhang  = max( 0.0, (float) ( $i['overhang'] ?? 0 ) );

			$area = $perimeter * $overhang;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: perimeter m, 2: overhang m */
				__( 'Perimeter %1$s m × overhang %2$s m.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $perimeter, 1 ),
				mvweb_bc_format_number( $overhang, 2 )
			);

			$hints[] = __( 'On a sloped eaves the board run is a little longer than the horizontal width; add a small reserve.', 'mvweb-build-calc' );

			$hints[] = __( 'Add fascia boards along the perimeter and ventilation gaps or vented soffit panels.', 'mvweb-build-calc' );

			return array(
				'value' => round( $area, 1 ),
				'hints' => $hints,
			);
		},
	)
);
