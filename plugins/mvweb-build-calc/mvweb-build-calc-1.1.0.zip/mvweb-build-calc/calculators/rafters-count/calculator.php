<?php
/**
 * Calculator: rafters count.
 *
 * Number of rafters from the roof length (along the ridge) and the rafter
 * spacing, plus one to close the end, doubled for a gable roof. Geometric
 * calculation.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'rafters-count',
	array(
		'title'       => __( 'Rafters count', 'mvweb-build-calc' ),
		'hub'         => 'roof',
		'description' => __( 'Calculates the number of rafters from the roof length along the ridge and the rafter spacing, plus one to close the end, doubled for a gable roof. A smaller spacing is recommended at low slopes and heavy snow loads.', 'mvweb-build-calc' ),
		'formula'     => 'count = (length / spacing + 1) × slopes',
		'legend'      => array(
			'count'   => __( 'number of rafters', 'mvweb-build-calc' ),
			'length'  => __( 'roof length along the ridge, m', 'mvweb-build-calc' ),
			'spacing' => __( 'rafter spacing, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Rafters needed', 'mvweb-build-calc' ),
			'unit'     => __( 'pcs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'length'  => array(
				'type'     => 'number',
				'label'    => __( 'Roof length (along the ridge)', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'spacing' => array(
				'type'     => 'number',
				'label'    => __( 'Rafter spacing', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.4,
				'max'      => 1.2,
				'step'     => 0.05,
				'required' => true,
			),
			'type'    => array(
				'type'       => 'radio',
				'label'      => __( 'Roof type', 'mvweb-build-calc' ),
				'default'    => 'gable',
				'full_width' => true,
				'options'    => array(
					'gable'  => __( 'Gable (two slopes)', 'mvweb-build-calc' ),
					'single' => __( 'Single slope', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$length  = max( 0.0, (float) ( $i['length'] ?? 0 ) );
			$spacing = max( 0.1, (float) ( $i['spacing'] ?? 0 ) );
			$type    = (string) ( $i['type'] ?? 'gable' );

			$per_slope = (int) ceil( $length / $spacing ) + 1;
			$slopes    = ( 'single' === $type ) ? 1 : 2;
			$count     = $per_slope * $slopes;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: rafters per slope, 2: slopes count */
				__( '%1$d rafters per slope × %2$d slope(s).', 'mvweb-build-calc' ),
				$per_slope,
				$slopes
			);

			if ( $spacing > 0.9 ) {
				$hints[] = __( 'A spacing over 0.9 m is large — at low slopes or heavy snow use 0.6 m or less.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Geometric estimate — the exact spacing follows the rafter cross-section and the snow load.', 'mvweb-build-calc' );

			return array(
				'value' => $count,
				'hints' => $hints,
			);
		},
	)
);
