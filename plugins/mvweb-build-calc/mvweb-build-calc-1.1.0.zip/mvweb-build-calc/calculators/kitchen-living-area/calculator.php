<?php
/**
 * Calculator: kitchen / kitchen-living room area by occupants.
 *
 * Combines a code-based minimum with an ergonomic comfort allowance:
 *   - Kitchen minimum follows SP 55.13330.2016 (single-family houses): a
 *     kitchen is at least 6 m², a kitchen niche at least 5 m². The general
 *     living room is at least 12 m² (used as the living-zone floor).
 *   - The comfort multiplier and the per-person living allowance above the
 *     minimum are ergonomic design practice, not code.
 *
 * Model:
 *   separate layout:  area = max(kitchen_min × comfort, kitchen_min)
 *   kitchen-living:   area = kitchen_min × comfort + living_zone
 *                     living_zone = max(12, occupants × 6) × comfort_living
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'kitchen-living-area',
	array(
		'title'       => __( 'Kitchen / kitchen-living area', 'mvweb-build-calc' ),
		'hub'         => 'rooms',
		'description' => __( 'Estimates the recommended area of a kitchen or a combined kitchen-living room from the number of occupants and comfort level. The kitchen minimum follows SP 55.13330.2016 (kitchen ≥ 6 m², kitchen niche ≥ 5 m², living room ≥ 12 m²); the comfort allowance above the minimum is ergonomic design practice.', 'mvweb-build-calc' ),
		'formula'     => 'S = kitchen × comfort (+ living zone for kitchen-living)',
		'legend'      => array(
			'S'       => __( 'recommended area, m²', 'mvweb-build-calc' ),
			'kitchen' => __( 'kitchen minimum by SP 55.13330.2016 (kitchen 6 m², niche 5 m²)', 'mvweb-build-calc' ),
			'comfort' => __( 'comfort multiplier (minimal 1.0, standard 1.3, spacious 1.6)', 'mvweb-build-calc' ),
			'living'  => __( 'living zone for kitchen-living — max(12 m², 6 m² per person)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'occupants' => array(
				'type'     => 'number',
				'label'    => __( 'Occupants', 'mvweb-build-calc' ),
				'default'  => 4,
				'min'      => 1,
				'max'      => 20,
				'step'     => 1,
				'required' => true,
			),
			'layout'    => array(
				'type'       => 'radio',
				'label'      => __( 'Layout', 'mvweb-build-calc' ),
				'default'    => 'combined',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'separate' => __( 'Separate kitchen', 'mvweb-build-calc' ),
					'combined' => __( 'Kitchen-living room', 'mvweb-build-calc' ),
				),
			),
			'comfort'   => array(
				'type'       => 'radio',
				'label'      => __( 'Comfort level', 'mvweb-build-calc' ),
				'default'    => 'standard',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'minimal'  => __( 'Minimal', 'mvweb-build-calc' ),
					'standard' => __( 'Standard', 'mvweb-build-calc' ),
					'spacious' => __( 'Spacious', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$occupants = max( 1, (int) ( $i['occupants'] ?? 4 ) );
			$layout    = (string) ( $i['layout'] ?? 'combined' );
			$comfort   = (string) ( $i['comfort'] ?? 'standard' );

			$mult = match ( $comfort ) {
				'minimal'  => 1.0,
				'spacious' => 1.6,
				default    => 1.3, // standard.
			};

			// Kitchen minimum, SP 55.13330.2016.
			$kitchen_min = 6.0;
			$kitchen     = $kitchen_min * $mult;

			if ( 'separate' === $layout ) {
				$area = $kitchen;

				$hints = array();
				$hints[] = sprintf(
					/* translators: %s: kitchen area in m² */
					__( 'Separate kitchen ≈ %s m². Minimum by SP 55.13330.2016 is 6 m² (kitchen niche 5 m²).', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $area, 0 )
				);
				$hints[] = __( 'The area above the 6 m² code minimum is an ergonomic comfort allowance, not a requirement.', 'mvweb-build-calc' );

				return array(
					'value' => $area,
					'hints' => $hints,
				);
			}

			// Kitchen-living: kitchen + living zone (living room floor is 12 m²).
			$living = max( 12.0, $occupants * 6.0 ) * $mult;
			$area   = $kitchen + $living;

			$hints = array();
			$hints[] = sprintf(
				/* translators: 1: kitchen area, 2: living area, both in m² */
				__( 'Kitchen ≈ %1$s m² + living zone ≈ %2$s m².', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $kitchen, 0 ),
				mvweb_bc_format_number( $living, 0 )
			);
			$hints[] = __( 'Kitchen minimum (6 m²) and living room minimum (12 m²) follow SP 55.13330.2016; the comfort allowance above them is ergonomic practice.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
