<?php
/**
 * Calculator: terrace area.
 *
 * Ergonomic planning guide, not a code requirement. Sizes a terrace from the
 * number of guests it should host (~1.8 m² per person) plus a furniture-zone
 * allowance for the chosen use.
 *
 * Model:
 *   area = guests × 1.8 + furniture_zone(use)
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'terrace-area',
	array(
		'title'       => __( 'Terrace area', 'mvweb-build-calc' ),
		'hub'         => 'rooms',
		'description' => __( 'Estimates the recommended terrace area from the number of guests it should host and how it will be used. This is an ergonomic planning guide based on common design practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'A = guests × 1.8 + furniture_zone',
		'legend'      => array(
			'A'              => __( 'recommended area, m²', 'mvweb-build-calc' ),
			'guests'         => __( 'number of people to host at once (~1.8 m² each)', 'mvweb-build-calc' ),
			'furniture_zone' => __( 'allowance for the use — lounge 2, dining 4, lounge + grill 6 m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'guests' => array(
				'type'     => 'number',
				'label'    => __( 'Guests', 'mvweb-build-calc' ),
				'default'  => 4,
				'min'      => 1,
				'max'      => 40,
				'step'     => 1,
				'required' => true,
			),
			'use'    => array(
				'type'     => 'select',
				'label'    => __( 'Use', 'mvweb-build-calc' ),
				'default'  => 'dining',
				'required' => true,
				'options'  => array(
					'lounge'       => __( 'Lounge only', 'mvweb-build-calc' ),
					'dining'       => __( 'Dining area', 'mvweb-build-calc' ),
					'lounge_grill' => __( 'Lounge + grill', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$guests = max( 1, (int) ( $i['guests'] ?? 4 ) );
			$use    = (string) ( $i['use'] ?? 'dining' );

			$per_person     = 1.8;
			$furniture_zone = match ( $use ) {
				'lounge'       => 2.0,
				'lounge_grill' => 6.0,
				default        => 4.0, // dining.
			};

			$area = $guests * $per_person + $furniture_zone;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: guests count, 2: furniture zone in m² */
				__( '%1$d guests × 1.8 m² + %2$s m² furniture zone.', 'mvweb-build-calc' ),
				$guests,
				mvweb_bc_format_number( $furniture_zone, 0 )
			);

			$hints[] = __( 'As a rule of thumb, a terrace of 10–15% of the house area feels well-proportioned.', 'mvweb-build-calc' );

			$hints[] = __( 'This is an ergonomic planning guide based on common design practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
