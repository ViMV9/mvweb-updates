<?php
/**
 * Calculator: staircase dimensions from floor-to-floor height.
 *
 * Returns the number of steps for a straight flight from the floor height and a
 * target riser, then the actual riser, the horizontal run and the comfort
 * formula 2h + b. Ergonomic guide based on common practice and SP 55.13330
 * (riser ≤ 200 mm, tread ≥ 250 mm; comfort 2h + b ≈ 600–640 mm).
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'staircase-dimensions',
	array(
		'title'       => __( 'Staircase dimensions', 'mvweb-build-calc' ),
		'hub'         => 'layout',
		'description' => __( 'Calculates the number of steps for a straight flight from the floor-to-floor height and a target riser, with the actual riser, the horizontal run and the comfort check 2·riser + tread. Ergonomic guide based on common practice and SP 55.13330 (riser up to 200 mm, tread at least 250 mm).', 'mvweb-build-calc' ),
		'formula'     => 'steps = ceil(H / riser), run = (steps − 1) × tread',
		'legend'      => array(
			'H'     => __( 'floor-to-floor height, cm', 'mvweb-build-calc' ),
			'riser' => __( 'target riser height, cm', 'mvweb-build-calc' ),
			'tread' => __( 'tread depth, cm', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Number of steps', 'mvweb-build-calc' ),
			'unit'     => __( 'pcs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'height' => array(
				'type'     => 'number',
				'label'    => __( 'Floor-to-floor height', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 200,
				'max'      => 500,
				'step'     => 1,
				'required' => true,
			),
			'riser'  => array(
				'type'     => 'number',
				'label'    => __( 'Target riser height', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 14,
				'max'      => 20,
				'step'     => 0.5,
				'required' => true,
			),
			'tread'  => array(
				'type'     => 'number',
				'label'    => __( 'Tread depth', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 25,
				'max'      => 32,
				'step'     => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$height = max( 1.0, (float) ( $i['height'] ?? 0 ) );
			$riser  = max( 1.0, (float) ( $i['riser'] ?? 0 ) );
			$tread  = max( 1.0, (float) ( $i['tread'] ?? 0 ) );

			$steps      = (int) ceil( $height / $riser );
			$real_riser = $steps > 0 ? $height / $steps : 0.0;
			$run        = ( $steps - 1 ) * $tread;
			$comfort    = 2 * $real_riser + $tread;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: actual riser cm, 2: run m */
				__( 'Actual riser %1$s cm, horizontal run %2$s m.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $real_riser, 1 ),
				mvweb_bc_format_number( $run / 100, 2 )
			);

			$hints[] = sprintf(
				/* translators: %s: comfort formula value cm */
				__( 'Comfort formula 2·riser + tread = %s cm (comfortable range 60–64 cm).', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $comfort, 1 )
			);

			if ( $comfort >= 60 && $comfort <= 64 ) {
				$hints[] = __( 'The flight is within the comfortable range.', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'Adjust the riser or tread to bring 2·riser + tread into 60–64 cm.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Ergonomic guide based on common practice and SP 55.13330 (riser up to 200 mm, tread at least 250 mm). Evacuation stairs follow SP 1.13130.', 'mvweb-build-calc' );

			return array(
				'value' => $steps,
				'hints' => $hints,
			);
		},
	)
);
