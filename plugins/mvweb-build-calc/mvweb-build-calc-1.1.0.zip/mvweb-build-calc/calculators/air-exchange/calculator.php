<?php
/**
 * Calculator: required air exchange (ventilation airflow).
 *
 * Preliminary estimate. For living rooms the required supply air is the larger
 * of the area norm (3 m³/h per m²) and the occupancy norm (30 m³/h per person);
 * service rooms use a fixed extract rate per the standard.
 *
 * Model:
 *   living: airflow = max(area × 3, people × 30)
 *   service: airflow = fixed rate by room
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'air-exchange',
	array(
		'title'       => __( 'Air exchange', 'mvweb-build-calc' ),
		'hub'         => 'engineering',
		'description' => __( 'Estimates the required ventilation airflow for a room. For living rooms it takes the larger of the area norm (3 m³/h per m²) and the occupancy norm (30 m³/h per person); kitchens and bathrooms use the standard extract rates. Based on SP 54.13330 / SP 60.13330; a preliminary estimate, not a ventilation design.', 'mvweb-build-calc' ),
		'formula'     => 'living: max(area × 3, people × 30); service: fixed extract',
		'legend'      => array(
			'airflow' => __( 'required airflow, m³/h', 'mvweb-build-calc' ),
			'area'    => __( 'room area, m²', 'mvweb-build-calc' ),
			'people'  => __( 'people in the room', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Required airflow', 'mvweb-build-calc' ),
			'unit'     => __( 'm³/h', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'room'   => array(
				'type'       => 'select',
				'label'      => __( 'Room type', 'mvweb-build-calc' ),
				'default'    => 'living',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'living'     => __( 'Living room / bedroom (supply)', 'mvweb-build-calc' ),
					'kitchen'    => __( 'Kitchen (extract ≥ 60 m³/h)', 'mvweb-build-calc' ),
					'bath'       => __( 'Bathroom / WC (extract ≥ 25 m³/h)', 'mvweb-build-calc' ),
					'combi_bath' => __( 'Combined bathroom (extract ≥ 50 m³/h)', 'mvweb-build-calc' ),
				),
			),
			'area'   => array(
				'type'     => 'number',
				'label'    => __( 'Room area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'default'  => 18,
				'min'      => 2,
				'max'      => 120,
				'step'     => 0.5,
				'required' => true,
			),
			'people' => array(
				'type'    => 'number',
				'label'   => __( 'People (for living rooms)', 'mvweb-build-calc' ),
				'default' => 2,
				'min'     => 0,
				'max'     => 30,
				'step'    => 1,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$room   = (string) ( $i['room'] ?? 'living' );
			$area   = max( 0.0, (float) ( $i['area'] ?? 0 ) );
			$people = max( 0, (int) ( $i['people'] ?? 0 ) );

			$hints = array();

			if ( 'living' === $room ) {
				$by_area   = $area * 3;
				$by_people = $people * 30;
				$airflow   = max( $by_area, $by_people );

				$hints[] = sprintf(
					/* translators: 1: by-area m³/h, 2: by-people m³/h */
					__( 'By area %1$s m³/h, by occupancy %2$s m³/h — the larger applies.', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $by_area, 0 ),
					mvweb_bc_format_number( $by_people, 0 )
				);
			} else {
				$airflow = match ( $room ) {
					'kitchen'    => 60.0,
					'combi_bath' => 50.0,
					default      => 25.0, // bath / WC.
				};

				$hints[] = __( 'Service rooms use a fixed extract rate; the supply comes from the living rooms through door undercuts or transfer grilles.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Balance supply and extract across the home; a gas cooker or a range hood may set a higher kitchen rate.', 'mvweb-build-calc' );

			$hints[] = __( 'Based on SP 54.13330 / SP 60.13330 norms. Preliminary estimate, not a ventilation design.', 'mvweb-build-calc' );

			return array(
				'value' => $airflow,
				'hints' => $hints,
			);
		},
	)
);
