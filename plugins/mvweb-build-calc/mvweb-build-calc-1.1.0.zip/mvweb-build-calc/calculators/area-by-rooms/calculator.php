<?php
/**
 * Calculator: house area from its rooms.
 *
 * Sums the living rooms (bedrooms plus a living room), the service rooms
 * (kitchen, bathrooms, utility) and adds a circulation allowance for hallways
 * and walls to estimate the total floor area. Planning guide.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'area-by-rooms',
	array(
		'title'       => __( 'House area by rooms', 'mvweb-build-calc' ),
		'hub'         => 'layout',
		'description' => __( 'Estimates the total floor area of a house by summing the bedrooms, the living room and the service rooms, then adding a circulation allowance for hallways and walls. Planning guide based on common practice.', 'mvweb-build-calc' ),
		'formula'     => 'total = (bedrooms × area + living + service) × (1 + circulation%)',
		'legend'      => array(
			'total' => __( 'estimated total floor area, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Estimated total area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'bedrooms'     => array(
				'type'     => 'number',
				'label'    => __( 'Number of bedrooms', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 10,
				'step'     => 1,
				'required' => true,
			),
			'bedroom_area' => array(
				'type'     => 'number',
				'label'    => __( 'Average bedroom area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 8,
				'max'      => 40,
				'step'     => 0.5,
				'required' => true,
			),
			'living'       => array(
				'type'     => 'number',
				'label'    => __( 'Living room / kitchen-living area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 12,
				'max'      => 120,
				'step'     => 0.5,
				'required' => true,
			),
			'service'      => array(
				'type'     => 'number',
				'label'    => __( 'Service rooms total (bath, utility, pantry)', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 4,
				'max'      => 80,
				'step'     => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$bedrooms = max( 0.0, (float) ( $i['bedrooms'] ?? 0 ) );
			$bed_area = max( 0.0, (float) ( $i['bedroom_area'] ?? 0 ) );
			$living   = max( 0.0, (float) ( $i['living'] ?? 0 ) );
			$service  = max( 0.0, (float) ( $i['service'] ?? 0 ) );

			$rooms = $bedrooms * $bed_area + $living + $service;

			// Circulation allowance: hallways, stairs and walls add ~20%.
			$circulation = 0.20;
			$total       = $rooms * ( 1 + $circulation );

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: net rooms area m² */
				__( 'Net rooms area %s m² before circulation.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $rooms, 1 )
			);

			$hints[] = sprintf(
				/* translators: %s: circulation percent */
				__( 'A circulation allowance of %s%% is added for hallways, stairs and walls.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $circulation * 100, 0 )
			);

			$hints[] = __( 'Planning estimate based on common practice — the final area depends on the layout and wall thickness.', 'mvweb-build-calc' );

			return array(
				'value' => round( $total, 1 ),
				'hints' => $hints,
			);
		},
	)
);
