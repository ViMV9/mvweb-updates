<?php
/**
 * Calculator: utility outbuilding (hozblok) size.
 *
 * Ergonomic planning guide, not a code requirement. Sizes a utility block by
 * summing the chosen functional zones (storage, tools / workshop, firewood,
 * summer shower, outdoor toilet) by their typical areas.
 *
 * Model:
 *   area = Σ selected zone areas
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'outbuilding-size',
	array(
		'title'       => __( 'Utility block size', 'mvweb-build-calc' ),
		'hub'         => 'outbuildings',
		'description' => __( 'Estimates the recommended area of a utility outbuilding (hozblok) by summing the functional zones it should contain — storage, a tool / workshop corner, firewood, a summer shower and an outdoor toilet. This is an ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'A = storage + workshop? + firewood? + shower? + toilet?',
		'legend'      => array(
			'A'        => __( 'recommended area, m²', 'mvweb-build-calc' ),
			'storage'  => __( 'general storage zone, m²', 'mvweb-build-calc' ),
			'workshop' => __( 'tool / workshop corner, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'storage'  => array(
				'type'    => 'select',
				'label'   => __( 'Storage zone', 'mvweb-build-calc' ),
				'default' => 'medium',
				'options' => array(
					'small'  => __( 'Small (~4 m²)', 'mvweb-build-calc' ),
					'medium' => __( 'Medium (~6 m²)', 'mvweb-build-calc' ),
					'large'  => __( 'Large (~9 m²)', 'mvweb-build-calc' ),
				),
			),
			'workshop' => array(
				'type'    => 'radio',
				'label'   => __( 'Tool / workshop corner', 'mvweb-build-calc' ),
				'default' => 'no',
				'options' => array(
					'yes' => __( 'Yes (+4 m²)', 'mvweb-build-calc' ),
					'no'  => __( 'No', 'mvweb-build-calc' ),
				),
			),
			'firewood' => array(
				'type'    => 'radio',
				'label'   => __( 'Firewood store', 'mvweb-build-calc' ),
				'default' => 'no',
				'options' => array(
					'yes' => __( 'Yes (+3 m²)', 'mvweb-build-calc' ),
					'no'  => __( 'No', 'mvweb-build-calc' ),
				),
			),
			'shower'   => array(
				'type'    => 'radio',
				'label'   => __( 'Summer shower', 'mvweb-build-calc' ),
				'default' => 'no',
				'options' => array(
					'yes' => __( 'Yes (+1.5 m²)', 'mvweb-build-calc' ),
					'no'  => __( 'No', 'mvweb-build-calc' ),
				),
			),
			'toilet'   => array(
				'type'    => 'radio',
				'label'   => __( 'Outdoor toilet', 'mvweb-build-calc' ),
				'default' => 'no',
				'options' => array(
					'yes' => __( 'Yes (+1.5 m²)', 'mvweb-build-calc' ),
					'no'  => __( 'No', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$storage  = (string) ( $i['storage'] ?? 'medium' );
			$workshop = ( 'yes' === (string) ( $i['workshop'] ?? 'no' ) );
			$firewood = ( 'yes' === (string) ( $i['firewood'] ?? 'no' ) );
			$shower   = ( 'yes' === (string) ( $i['shower'] ?? 'no' ) );
			$toilet   = ( 'yes' === (string) ( $i['toilet'] ?? 'no' ) );

			$base = match ( $storage ) {
				'small' => 4.0,
				'large' => 9.0,
				default => 6.0, // medium.
			};

			$area  = $base;
			$area += $workshop ? 4.0 : 0.0;
			$area += $firewood ? 3.0 : 0.0;
			$area += $shower ? 1.5 : 0.0;
			$area += $toilet ? 1.5 : 0.0;

			$zones = 1;
			$zones += $workshop ? 1 : 0;
			$zones += $firewood ? 1 : 0;
			$zones += $shower ? 1 : 0;
			$zones += $toilet ? 1 : 0;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: number of zones, 2: storage base m² */
				__( '%1$d zone(s) summed; storage base %2$s m².', 'mvweb-build-calc' ),
				$zones,
				mvweb_bc_format_number( $base, 1 )
			);

			$hints[] = __( 'A shed under 50 m² and one storey usually needs no building permit, but keep at least 1 m from the plot boundary (SP 53.13330.2019).', 'mvweb-build-calc' );

			$hints[] = __( 'Ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
