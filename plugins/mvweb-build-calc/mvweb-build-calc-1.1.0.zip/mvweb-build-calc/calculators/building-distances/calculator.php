<?php
/**
 * Calculator: minimum distances between buildings on a plot.
 *
 * Code-based. Two modes:
 *   - Sanitary distances (SP 53.13330.2019): house↔toilet ≥ 12 m,
 *     house↔bathhouse ≥ 8 m, well↔toilet/compost ≥ 8 m, house↔shed for
 *     animals ≥ 12 m.
 *   - Fire distances between houses on neighbouring plots (SP 4.13130,
 *     table 1), by material: non-combustible↔non-combustible 6 m,
 *     non-combustible↔wooden 8 m, wooden↔wooden 10 m.
 *
 * The fire matrix uses the widely used three-material reading of SP 4.13130
 * table 1; the exact value depends on the fire-resistance class — the hint
 * points to the standard.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'building-distances',
	array(
		'title'       => __( 'Distances between buildings', 'mvweb-build-calc' ),
		'hub'         => 'lot',
		'description' => __( 'Returns the minimum required distance between buildings on a plot — sanitary distances by SP 53.13330.2019 (house to toilet, bathhouse, well, compost) and fire distances between houses on neighbouring plots by SP 4.13130 (by material).', 'mvweb-build-calc' ),
		'formula'     => 'distance = max(sanitary, fire) per the relevant code',
		'legend'      => array(
			'sanitary' => __( 'sanitary distance — house↔toilet 12 m, house↔bathhouse 8 m, well↔toilet/compost 8 m (SP 53.13330.2019)', 'mvweb-build-calc' ),
			'fire'     => __( 'fire distance between houses on neighbouring plots — 6/8/10 m by material (SP 4.13130)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Minimum distance', 'mvweb-build-calc' ),
			'unit'     => __( 'm', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'mode'       => array(
				'type'       => 'radio',
				'label'      => __( 'Distance type', 'mvweb-build-calc' ),
				'default'    => 'sanitary',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'sanitary' => __( 'Sanitary (within the plot)', 'mvweb-build-calc' ),
					'fire'     => __( 'Fire (between houses on neighbouring plots)', 'mvweb-build-calc' ),
				),
			),
			'pair'       => array(
				'type'       => 'select',
				'label'      => __( 'Between which objects (sanitary)', 'mvweb-build-calc' ),
				'default'    => 'house_toilet',
				'full_width' => true,
				'options'    => array(
					'house_toilet'    => __( 'House — toilet / outhouse', 'mvweb-build-calc' ),
					'house_bathhouse' => __( 'House — bathhouse / shower', 'mvweb-build-calc' ),
					'house_animals'   => __( 'House — shed for animals or poultry', 'mvweb-build-calc' ),
					'well_toilet'     => __( 'Well — toilet', 'mvweb-build-calc' ),
					'well_compost'    => __( 'Well — compost', 'mvweb-build-calc' ),
				),
			),
			'material_a' => array(
				'type'    => 'select',
				'label'   => __( 'House A material (fire)', 'mvweb-build-calc' ),
				'default' => 'noncombustible',
				'options' => array(
					'noncombustible' => __( 'Non-combustible (stone, concrete)', 'mvweb-build-calc' ),
					'wooden'         => __( 'Wooden / timber frame', 'mvweb-build-calc' ),
				),
			),
			'material_b' => array(
				'type'    => 'select',
				'label'   => __( 'House B material (fire)', 'mvweb-build-calc' ),
				'default' => 'wooden',
				'options' => array(
					'noncombustible' => __( 'Non-combustible (stone, concrete)', 'mvweb-build-calc' ),
					'wooden'         => __( 'Wooden / timber frame', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$mode = (string) ( $i['mode'] ?? 'sanitary' );

			if ( 'fire' === $mode ) {
				$a = (string) ( $i['material_a'] ?? 'noncombustible' );
				$b = (string) ( $i['material_b'] ?? 'wooden' );

				// SP 4.13130 table 1, three-material reading.
				if ( 'noncombustible' === $a && 'noncombustible' === $b ) {
					$distance = 6;
				} elseif ( 'wooden' === $a && 'wooden' === $b ) {
					$distance = 10;
				} else {
					$distance = 8;
				}

				$hints   = array();
				$hints[] = sprintf(
					/* translators: %d: fire distance in metres */
					__( 'Minimum fire distance between the houses: %d m.', 'mvweb-build-calc' ),
					$distance
				);
				$hints[] = __( 'Fire distances are not regulated between buildings on the same plot. Between neighbouring plots use SP 4.13130 table 1; the exact value depends on the fire-resistance class of each house.', 'mvweb-build-calc' );

				return array(
					'value' => (float) $distance,
					'hints' => $hints,
				);
			}

			// Sanitary distances, SP 53.13330.2019.
			$pair     = (string) ( $i['pair'] ?? 'house_toilet' );
			$distance = match ( $pair ) {
				'house_bathhouse' => 8,
				'well_toilet'     => 8,
				'well_compost'    => 8,
				default           => 12, // house_toilet, house_animals.
			};

			$hints   = array();
			$hints[] = sprintf(
				/* translators: %d: sanitary distance in metres */
				__( 'Minimum sanitary distance: %d m (SP 53.13330.2019).', 'mvweb-build-calc' ),
				$distance
			);
			$hints[] = __( 'A well or borehole must also be at least 25 m from a toilet or compost. Sanitary distances are kept even within one plot.', 'mvweb-build-calc' );

			return array(
				'value' => (float) $distance,
				'hints' => $hints,
			);
		},
	)
);
