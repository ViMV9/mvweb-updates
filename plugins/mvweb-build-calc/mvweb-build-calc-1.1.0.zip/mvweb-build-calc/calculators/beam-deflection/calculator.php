<?php
/**
 * Calculator: deflection of a rectangular beam under a uniform load.
 *
 * Estimate, not a design calculation. Computes the mid-span (or tip)
 * deflection of a rectangular timber or steel beam and compares it with the
 * code limit f_u = L/n by element type. Returns a deflection-diagram payload.
 *
 * Sources (verified against official texts):
 *   - E: steel 206000 MPa (SP 16.13330.2017), timber 10000 MPa (SP 64.13330.2017).
 *   - Deflection limits f_u = L/n — SP 20.13330.2016 tab. Е.1
 *     (floors 1/250, purlins 1/200, cantilevers ~1/150).
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'beam-deflection',
	array(
		'title'       => __( 'Beam deflection', 'mvweb-build-calc' ),
		'hub'         => 'structures',
		'description' => __( 'Estimates the deflection of a rectangular timber or steel beam under a uniform load and compares it with the code deflection limit L/n by element type. This is a preliminary estimate based on SP 20.13330 deflection limits, not a substitute for a structural design by an engineer.', 'mvweb-build-calc' ),
		'formula'     => 'f = 5 × q × L⁴ / (384 × E × I), I = b × h³ / 12, f_u = L / n',
		'legend'      => array(
			'f'   => __( 'maximum deflection, mm', 'mvweb-build-calc' ),
			'f_u' => __( 'allowable deflection L/n, mm', 'mvweb-build-calc' ),
			'q'   => __( 'uniform load, kN/m', 'mvweb-build-calc' ),
			'L'   => __( 'span, m', 'mvweb-build-calc' ),
			'E'   => __( 'modulus of elasticity, MPa', 'mvweb-build-calc' ),
			'I'   => __( 'moment of inertia b·h³/12, cm⁴', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Deflection margin', 'mvweb-build-calc' ),
			'unit'     => __( '%', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'material' => array(
				'type'       => 'radio',
				'label'      => __( 'Material', 'mvweb-build-calc' ),
				'default'    => 'timber',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'timber' => __( 'Timber (E = 10 000 MPa)', 'mvweb-build-calc' ),
					'steel'  => __( 'Steel (E = 206 000 MPa)', 'mvweb-build-calc' ),
				),
			),
			'element'  => array(
				'type'       => 'select',
				'label'      => __( 'Element type (deflection limit)', 'mvweb-build-calc' ),
				'default'    => 'floor',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'floor'      => __( 'Floor beam / joist (L/250)', 'mvweb-build-calc' ),
					'purlin'     => __( 'Roof purlin / sheathing (L/200)', 'mvweb-build-calc' ),
					'cantilever' => __( 'Cantilever element (L/150)', 'mvweb-build-calc' ),
				),
			),
			'support'  => array(
				'type'       => 'radio',
				'label'      => __( 'Support scheme', 'mvweb-build-calc' ),
				'default'    => 'simple',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'simple'     => __( 'Simply supported', 'mvweb-build-calc' ),
					'cantilever' => __( 'Cantilever (fixed at one end)', 'mvweb-build-calc' ),
				),
			),
			'load'     => array(
				'type'     => 'number',
				'label'    => __( 'Uniform load q', 'mvweb-build-calc' ),
				'unit'     => __( 'kN/m', 'mvweb-build-calc' ),
				'min'      => 0.1,
				'max'      => 1000,
				'step'     => 0.1,
				'required' => true,
			),
			'span'     => array(
				'type'     => 'number',
				'label'    => __( 'Span L', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.5,
				'max'      => 24,
				'step'     => 0.1,
				'required' => true,
			),
			'width'    => array(
				'type'     => 'number',
				'label'    => __( 'Section width b', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 200,
				'step'     => 0.5,
				'required' => true,
			),
			'height'   => array(
				'type'     => 'number',
				'label'    => __( 'Section height h', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 200,
				'step'     => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$material = (string) ( $i['material'] ?? 'timber' );
			$element  = (string) ( $i['element'] ?? 'floor' );
			$support  = (string) ( $i['support'] ?? 'simple' );
			$q        = max( 0.0, (float) ( $i['load'] ?? 0 ) );
			$span     = max( 0.01, (float) ( $i['span'] ?? 0 ) );
			$b        = max( 0.1, (float) ( $i['width'] ?? 0 ) );
			$h        = max( 0.1, (float) ( $i['height'] ?? 0 ) );

			$e = ( 'steel' === $material ) ? 206000.0 : 10000.0;

			$n = match ( $element ) {
				'purlin'     => 200.0,
				'cantilever' => 150.0,
				default      => 250.0,
			};

			// Moment of inertia: cm⁴ for display, mm⁴ for the formula.
			$inertia_cm = $b * $h * $h * $h / 12;
			$inertia_mm = $inertia_cm * 10000;

			// Work in N and mm: q in N/mm (1 kN/m = 1 N/mm), L in mm, E in MPa.
			$q_n  = $q;
			$l_mm = $span * 1000;

			if ( 'cantilever' === $support ) {
				$f = ( $q_n * ( $l_mm ** 4 ) ) / ( 8 * $e * $inertia_mm );
			} else {
				$f = ( 5 * $q_n * ( $l_mm ** 4 ) ) / ( 384 * $e * $inertia_mm );
			}

			$f_u    = $l_mm / $n;
			$margin = $f_u > 0 ? ( ( $f_u - $f ) / $f_u ) * 100 : 0.0;

			$ratio = $f > 0 ? (int) round( $l_mm / $f ) : 0;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: actual deflection mm, 2: allowable deflection mm, 3: limit denominator n */
				__( 'Deflection f = %1$s mm, allowable f_u = L/%3$d = %2$s mm.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $f, 1 ),
				mvweb_bc_format_number( $f_u, 1 ),
				(int) $n
			);

			if ( $ratio > 0 ) {
				$hints[] = sprintf(
					/* translators: %d: actual relative deflection denominator */
					__( 'Actual relative deflection ≈ L/%d.', 'mvweb-build-calc' ),
					$ratio
				);
			}

			$hints[] = sprintf(
				/* translators: 1: modulus MPa, 2: moment of inertia cm⁴ */
				__( 'E = %1$s MPa, I = b·h³/12 = %2$s cm⁴.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $e, 0 ),
				mvweb_bc_format_number( $inertia_cm, 1 )
			);

			if ( $margin >= 0 ) {
				$hints[] = __( 'The deflection is within the code limit (f ≤ f_u).', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'The deflection exceeds the limit (f > f_u) — increase the height, width or use a stiffer material.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Preliminary estimate only. Deflection is checked here; bending strength, shear and stability are not. It does not replace a structural design by a qualified engineer.', 'mvweb-build-calc' );

			// Deflection-diagram ordinates, normalised to [0..1].
			$curve  = array();
			$points = 24;
			for ( $k = 0; $k <= $points; $k++ ) {
				$x = $k / $points;
				if ( 'cantilever' === $support ) {
					// Sag grows toward the free end (x=1).
					$d = $x * $x * ( 3 - $x ) / 2;
				} else {
					// Symmetric sag, peak at mid-span; approximated by sin shape.
					$d = sin( M_PI * $x );
				}
				$curve[] = round( $d, 4 );
			}

			return array(
				'value'   => round( $margin, 1 ),
				'hints'   => $hints,
				'diagram' => array(
					'support' => $support,
					'load'    => 'udl',
					'plot'    => 'deflection',
					'curve'   => $curve,
					'peak'    => sprintf(
						/* translators: %s: deflection mm */
						__( 'Deflection diagram, f_max = %s mm', 'mvweb-build-calc' ),
						mvweb_bc_format_number( $f, 1 )
					),
				),
			);
		},
	)
);
