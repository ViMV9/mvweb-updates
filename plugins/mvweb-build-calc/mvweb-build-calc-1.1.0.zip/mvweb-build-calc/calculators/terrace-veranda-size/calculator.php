<?php
/**
 * Calculator: terrace or veranda size.
 *
 * Ergonomic planning guide, not a code requirement. Sizes an attached terrace
 * or veranda from the people it should host (~1.8 m² each) plus a furniture
 * zone for the chosen use, with a glazing note for an enclosed veranda.
 *
 * Model:
 *   area = people × 1.8 + furniture_zone(use)
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'terrace-veranda-size',
	array(
		'title'       => __( 'Terrace or veranda size', 'mvweb-build-calc' ),
		'hub'         => 'outbuildings',
		'description' => __( 'Estimates the recommended area of an attached terrace or veranda from the number of people it should host and how it will be used. This is an ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'A = people × 1.8 + furniture_zone',
		'legend'      => array(
			'A'              => __( 'recommended area, m²', 'mvweb-build-calc' ),
			'people'         => __( 'people to host at once (~1.8 m² each)', 'mvweb-build-calc' ),
			'furniture_zone' => __( 'allowance for the use, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'kind'   => array(
				'type'       => 'radio',
				'label'      => __( 'Type', 'mvweb-build-calc' ),
				'default'    => 'terrace',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'terrace' => __( 'Open terrace', 'mvweb-build-calc' ),
					'veranda' => __( 'Enclosed / glazed veranda', 'mvweb-build-calc' ),
				),
			),
			'people' => array(
				'type'     => 'number',
				'label'    => __( 'People at once', 'mvweb-build-calc' ),
				'default'  => 4,
				'min'      => 1,
				'max'      => 30,
				'step'     => 1,
				'required' => true,
			),
			'use'    => array(
				'type'       => 'select',
				'label'      => __( 'Use', 'mvweb-build-calc' ),
				'default'    => 'dining',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'lounge'  => __( 'Lounge / seating', 'mvweb-build-calc' ),
					'dining'  => __( 'Dining area', 'mvweb-build-calc' ),
					'kitchen' => __( 'Dining + summer kitchen', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$kind   = (string) ( $i['kind'] ?? 'terrace' );
			$people = max( 1, (int) ( $i['people'] ?? 4 ) );
			$use    = (string) ( $i['use'] ?? 'dining' );

			$furniture_zone = match ( $use ) {
				'lounge'  => 2.0,
				'kitchen' => 6.0,
				default   => 4.0, // dining.
			};

			$area = $people * 1.8 + $furniture_zone;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: people count, 2: furniture zone m² */
				__( '%1$d people × 1.8 m² + furniture zone %2$s m².', 'mvweb-build-calc' ),
				$people,
				mvweb_bc_format_number( $furniture_zone, 0 )
			);

			if ( 'veranda' === $kind ) {
				$hints[] = __( 'An enclosed veranda needs glazing and, for year-round use, insulation and heating; an open terrace only needs a floor and a railing.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'A terrace of about 10–15% of the house area feels well-proportioned.', 'mvweb-build-calc' );

			$hints[] = __( 'Ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
