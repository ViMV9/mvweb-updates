<?php
/**
 * Calculator: carport size.
 *
 * Ergonomic planning guide, not a code requirement. Sizes an open carport for
 * one or more cars: car footprint plus side clearance to the posts, a centre
 * gap between cars and a small overhang front and rear.
 *
 * Model:
 *   width  = cars × car_width + 2 × side + (cars − 1) × gap
 *   length = car_length + 2 × overhang
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'carport-size',
	array(
		'title'       => __( 'Carport size', 'mvweb-build-calc' ),
		'hub'         => 'outbuildings',
		'description' => __( 'Estimates the recommended roof footprint of an open carport for one or more cars, including side clearance to the posts, the gap between cars and a small overhang front and rear. This is an ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'A = (cars × car_width + 2 × side + (cars − 1) × gap) × (car_length + 2 × overhang)',
		'legend'      => array(
			'A'        => __( 'recommended roof footprint, m²', 'mvweb-build-calc' ),
			'side'     => __( 'clearance to the posts on each side, m', 'mvweb-build-calc' ),
			'gap'      => __( 'gap between cars, m', 'mvweb-build-calc' ),
			'overhang' => __( 'roof overhang front and rear, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended roof footprint', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'cars'     => array(
				'type'       => 'radio',
				'label'      => __( 'Number of cars', 'mvweb-build-calc' ),
				'default'    => '1',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'1' => __( 'One car', 'mvweb-build-calc' ),
					'2' => __( 'Two cars', 'mvweb-build-calc' ),
				),
			),
			'car_size' => array(
				'type'       => 'select',
				'label'      => __( 'Car class', 'mvweb-build-calc' ),
				'default'    => 'mid',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'small' => __( 'Small (~3.8 × 1.7 m)', 'mvweb-build-calc' ),
					'mid'   => __( 'Mid-size (~4.6 × 1.85 m)', 'mvweb-build-calc' ),
					'large' => __( 'Large (~5.1 × 2.0 m)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$cars = ( '2' === (string) ( $i['cars'] ?? '1' ) ) ? 2 : 1;
			$car  = (string) ( $i['car_size'] ?? 'mid' );

			$dims = match ( $car ) {
				'small' => array( 1.7, 3.8 ),
				'large' => array( 2.0, 5.1 ),
				default => array( 1.85, 4.6 ), // mid.
			};
			$car_w = $dims[0];
			$car_l = $dims[1];

			$side     = 0.5;
			$gap      = 0.6;
			$overhang = 0.5;

			$width  = $cars * $car_w + 2 * $side + ( $cars - 1 ) * $gap;
			$length = $car_l + 2 * $overhang;
			$area   = $width * $length;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: roof width m, 2: roof length m */
				__( 'Roof size about %1$s × %2$s m.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $width, 1 ),
				mvweb_bc_format_number( $length, 1 )
			);

			$hints[] = __( 'A clear height of at least 2.2 m suits most cars; 2.5 m if a roof box or a tall SUV is expected.', 'mvweb-build-calc' );

			$hints[] = __( 'Ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
