<?php
/**
 * Calculator: recommended number of windows for a room.
 *
 * Ergonomic + daylight guide. From the room floor area and type, returns the
 * recommended number of standard windows to meet the daylight norm
 * (window-to-floor ~1:6), assuming a typical window of ~1.8 m².
 *
 * Model:
 *   needed_glass = floor × norm_ratio(type)
 *   windows      = ceil(needed_glass / one_window_area)
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'windows-by-rooms',
	array(
		'title'       => __( 'Windows by room', 'mvweb-build-calc' ),
		'hub'         => 'openings',
		'description' => __( 'Recommends the number of standard windows a room needs to reach the daylight norm, from its floor area and type. Assumes a typical window of about 1.8 m². Daylight guide based on SP 55.13330.2016 ratios, not a full KEO calculation.', 'mvweb-build-calc' ),
		'formula'     => 'windows = ceil(floor × norm_ratio / window_area)',
		'legend'      => array(
			'floor'       => __( 'room floor area, m²', 'mvweb-build-calc' ),
			'norm_ratio'  => __( 'target glazing-to-floor ratio by room type', 'mvweb-build-calc' ),
			'window_area' => __( 'area of one standard window, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended windows', 'mvweb-build-calc' ),
			'unit'     => __( 'pcs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'floor'       => array(
				'type'     => 'number',
				'label'    => __( 'Room floor area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 4,
				'max'      => 120,
				'step'     => 0.5,
				'required' => true,
			),
			'room'        => array(
				'type'       => 'select',
				'label'      => __( 'Room type', 'mvweb-build-calc' ),
				'default'    => 'living',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'living'  => __( 'Living room (more daylight)', 'mvweb-build-calc' ),
					'bedroom' => __( 'Bedroom / kitchen (standard)', 'mvweb-build-calc' ),
					'utility' => __( 'Hallway / utility (less)', 'mvweb-build-calc' ),
				),
			),
			'window_size' => array(
				'type'       => 'select',
				'label'      => __( 'Standard window size', 'mvweb-build-calc' ),
				'default'    => 'medium',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'small'  => __( 'Small (~1.0 m²)', 'mvweb-build-calc' ),
					'medium' => __( 'Medium (~1.8 m²)', 'mvweb-build-calc' ),
					'large'  => __( 'Large (~2.6 m²)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$floor = max( 1.0, (float) ( $i['floor'] ?? 0 ) );
			$room  = (string) ( $i['room'] ?? 'living' );
			$size  = (string) ( $i['window_size'] ?? 'medium' );

			$norm = match ( $room ) {
				'living'  => 1 / 5.5,
				'utility' => 1 / 8,
				default   => 1 / 6.5, // bedroom / kitchen.
			};

			$one = match ( $size ) {
				'small' => 1.0,
				'large' => 2.6,
				default => 1.8, // medium.
			};

			$needed_glass = $floor * $norm;
			$windows      = max( 1, (int) ceil( $needed_glass / $one ) );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: needed glazing m², 2: one window m² */
				__( 'Needs about %1$s m² of glazing; one window ≈ %2$s m².', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $needed_glass, 1 ),
				mvweb_bc_format_number( $one, 1 )
			);

			$hints[] = __( 'A single wide window often lights a room better than two narrow ones of the same total area.', 'mvweb-build-calc' );

			$hints[] = __( 'Daylight guide based on SP 55.13330.2016 ratios, not a full KEO calculation.', 'mvweb-build-calc' );

			return array(
				'value' => (float) $windows,
				'hints' => $hints,
			);
		},
	)
);
