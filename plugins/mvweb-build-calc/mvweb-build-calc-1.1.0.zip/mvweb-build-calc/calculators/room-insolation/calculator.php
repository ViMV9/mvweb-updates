<?php
/**
 * Calculator: required insolation (direct sunlight) duration.
 *
 * Code-based. SanPiN 1.2.3685-21 sets the minimum continuous insolation of
 * living rooms by latitude zone:
 *   - Northern  (north of 58° N): ≥ 2.5 h (regulated 22 Apr – 22 Aug).
 *   - Central   (58°–48° N):      ≥ 2.0 h (regulated 22 Mar – 22 Sep).
 *   - Southern  (south of 48° N): ≥ 1.5 h (regulated 22 Feb – 22 Oct).
 * If insolation is interrupted, each period must be ≥ 1 h and the total
 * required duration is increased by 0.5 h.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'room-insolation',
	array(
		'title'       => __( 'Required room insolation', 'mvweb-build-calc' ),
		'hub'         => 'lot',
		'description' => __( 'Returns the minimum required duration of direct sunlight (insolation) for a living room by latitude zone, per SanPiN 1.2.3685-21. Interrupted insolation adds 0.5 h to the total and each period must last at least 1 hour.', 'mvweb-build-calc' ),
		'formula'     => 'T = zone minimum (+ 0.5 h if interrupted)',
		'legend'      => array(
			'T'    => __( 'required insolation duration, h', 'mvweb-build-calc' ),
			'zone' => __( 'latitude zone — northern 2.5 h, central 2 h, southern 1.5 h', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Required insolation', 'mvweb-build-calc' ),
			'unit'     => __( 'h', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'zone'        => array(
				'type'       => 'radio',
				'label'      => __( 'Latitude zone', 'mvweb-build-calc' ),
				'default'    => 'central',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'northern' => __( 'Northern (north of 58° N)', 'mvweb-build-calc' ),
					'central'  => __( 'Central (48°–58° N)', 'mvweb-build-calc' ),
					'southern' => __( 'Southern (south of 48° N)', 'mvweb-build-calc' ),
				),
			),
			'interrupted' => array(
				'type'    => 'radio',
				'label'   => __( 'Insolation is interrupted', 'mvweb-build-calc' ),
				'default' => 'no',
				'options' => array(
					'no'  => __( 'No', 'mvweb-build-calc' ),
					'yes' => __( 'Yes', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$zone        = (string) ( $i['zone'] ?? 'central' );
			$interrupted = 'yes' === (string) ( $i['interrupted'] ?? 'no' );

			$base = match ( $zone ) {
				'northern' => 2.5,
				'southern' => 1.5,
				default    => 2.0, // central.
			};

			$required = $interrupted ? $base + 0.5 : $base;

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: base continuous insolation in hours */
				__( 'Continuous insolation minimum for this zone: %s h.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $base, 1 )
			);

			if ( $interrupted ) {
				$hints[] = __( 'Interrupted insolation: each period must last at least 1 hour and the total is increased by 0.5 h (SanPiN 1.2.3685-21).', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Norm per SanPiN 1.2.3685-21. The regulated season depends on the zone (northern 22 Apr–22 Aug, central 22 Mar–22 Sep, southern 22 Feb–22 Oct).', 'mvweb-build-calc' );

			return array(
				'value' => $required,
				'hints' => $hints,
			);
		},
	)
);
