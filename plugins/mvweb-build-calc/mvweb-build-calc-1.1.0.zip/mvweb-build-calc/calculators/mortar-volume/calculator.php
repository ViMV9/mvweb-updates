<?php
/**
 * Calculator: masonry mortar volume.
 *
 * Volume of mortar for masonry from the masonry volume and the unit (brick or
 * block), using common consumption rates per m³ of masonry, plus a reserve.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'mortar-volume',
	array(
		'title'       => __( 'Masonry mortar volume', 'mvweb-build-calc' ),
		'hub'         => 'walls',
		'description' => __( 'Calculates the volume of mortar for masonry from the masonry volume and the unit type (brick or block), using common consumption rates per m³ of masonry, plus a reserve. For aerated blocks on thin-bed adhesive the consumption is much lower.', 'mvweb-build-calc' ),
		'formula'     => 'mortar = masonry volume × rate × (1 + reserve%)',
		'legend'      => array(
			'mortar' => __( 'mortar volume, m³', 'mvweb-build-calc' ),
			'volume' => __( 'masonry volume, m³', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Mortar volume', 'mvweb-build-calc' ),
			'unit'     => __( 'm³', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'volume'  => array(
				'type'     => 'number',
				'label'    => __( 'Masonry volume', 'mvweb-build-calc' ),
				'unit'     => __( 'm³', 'mvweb-build-calc' ),
				'min'      => 0.1,
				'max'      => 2000,
				'step'     => 0.1,
				'required' => true,
			),
			'unit'    => array(
				'type'       => 'select',
				'label'      => __( 'Masonry unit', 'mvweb-build-calc' ),
				'default'    => 'brick_single',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'brick_single' => __( 'Single brick — about 0.23 m³/m³', 'mvweb-build-calc' ),
					'brick_double' => __( 'Double brick — about 0.20 m³/m³', 'mvweb-build-calc' ),
					'block_cement' => __( 'Block on cement mortar — about 0.10 m³/m³', 'mvweb-build-calc' ),
					'block_glue'   => __( 'Aerated block on thin-bed adhesive — about 0.02 m³/m³', 'mvweb-build-calc' ),
				),
			),
			'reserve' => array(
				'type'     => 'number',
				'label'    => __( 'Waste reserve', 'mvweb-build-calc' ),
				'unit'     => __( '%', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 20,
				'step'     => 1,
				'default'  => 10,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$volume  = max( 0.0, (float) ( $i['volume'] ?? 0 ) );
			$reserve = max( 0.0, (float) ( $i['reserve'] ?? 0 ) );
			$unit    = (string) ( $i['unit'] ?? 'brick_single' );

			$rate = match ( $unit ) {
				'brick_double' => 0.20,
				'block_cement' => 0.10,
				'block_glue'   => 0.02,
				default        => 0.23,
			};

			$mortar = $volume * $rate * ( 1 + $reserve / 100 );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: rate m³/m³, 2: reserve percent */
				__( 'Consumption %1$s m³ of mortar per m³ of masonry, including a %2$s%% reserve.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $rate, 2 ),
				mvweb_bc_format_number( $reserve, 0 )
			);

			if ( 'block_glue' === $unit ) {
				$hints[] = __( 'Thin-bed adhesive is sold dry: roughly 25–30 kg per m³ of masonry.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Geometric estimate based on common consumption figures — joint thickness and unit geometry affect it.', 'mvweb-build-calc' );

			return array(
				'value' => round( $mortar, 2 ),
				'hints' => $hints,
			);
		},
	)
);
