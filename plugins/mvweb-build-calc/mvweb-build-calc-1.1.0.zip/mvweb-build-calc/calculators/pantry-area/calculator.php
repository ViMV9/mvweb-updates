<?php
/**
 * Calculator: pantry / storage room area.
 *
 * Ergonomic planning guide, not a code requirement. Common design practice
 * sizes a pantry as a small share of the house area with a practical floor,
 * adjusted by purpose (food storage is smaller, household/utility larger).
 *
 * Model:
 *   area = max(min_by_purpose, house_area × share_by_purpose)
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'pantry-area',
	array(
		'title'       => __( 'Pantry area', 'mvweb-build-calc' ),
		'hub'         => 'rooms',
		'description' => __( 'Estimates the recommended pantry area from the house area and the pantry purpose. This is an ergonomic planning guide based on common design practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'A = max(min, house_area × share)',
		'legend'      => array(
			'A'          => __( 'recommended area, m²', 'mvweb-build-calc' ),
			'house_area' => __( 'total house area, m²', 'mvweb-build-calc' ),
			'share'      => __( 'share of house area by purpose (food 1%, household 1.5%, universal 2%)', 'mvweb-build-calc' ),
			'min'        => __( 'practical minimum (food 1.5, household 2, universal 2 m²)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'house_area' => array(
				'type'     => 'number',
				'label'    => __( 'House area, m²', 'mvweb-build-calc' ),
				'default'  => 120,
				'min'      => 20,
				'max'      => 1000,
				'step'     => 1,
				'required' => true,
			),
			'purpose'    => array(
				'type'     => 'select',
				'label'    => __( 'Purpose', 'mvweb-build-calc' ),
				'default'  => 'universal',
				'required' => true,
				'options'  => array(
					'food'      => __( 'Food storage', 'mvweb-build-calc' ),
					'household' => __( 'Household equipment', 'mvweb-build-calc' ),
					'universal' => __( 'Universal', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$house   = max( 20.0, (float) ( $i['house_area'] ?? 120 ) );
			$purpose = (string) ( $i['purpose'] ?? 'universal' );

			$share = match ( $purpose ) {
				'food'      => 0.01,
				'household' => 0.015,
				default     => 0.02, // universal.
			};
			$min = match ( $purpose ) {
				'food'  => 1.5,
				default => 2.0, // household / universal.
			};

			$area = max( $min, $house * $share );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: share in percent, 2: minimum area in m² */
				__( '≈ %1$s%% of the house area, not below %2$s m².', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $share * 100, 1 ),
				mvweb_bc_format_number( $min, 1 )
			);

			$hints[] = __( 'This is an ergonomic planning guide based on common design practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
