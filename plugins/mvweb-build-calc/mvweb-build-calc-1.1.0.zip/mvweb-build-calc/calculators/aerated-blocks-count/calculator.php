<?php
/**
 * Calculator: aerated concrete blocks count.
 *
 * Number of aerated (gas) concrete blocks for a wall: wall area × thickness
 * gives the masonry volume, divided by one block volume, plus a waste reserve.
 * Block sizes per common GOST 31360 / 21520 formats.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'aerated-blocks-count',
	array(
		'title'       => __( 'Aerated concrete blocks count', 'mvweb-build-calc' ),
		'hub'         => 'walls',
		'description' => __( 'Calculates the number of aerated (gas) concrete blocks for a wall: the wall area times the wall thickness gives the masonry volume, divided by one block volume, plus a waste reserve. Block formats follow common GOST sizes.', 'mvweb-build-calc' ),
		'formula'     => 'blocks = area × thickness / block_volume × (1 + reserve%)',
		'legend'      => array(
			'area'      => __( 'wall area, m²', 'mvweb-build-calc' ),
			'thickness' => __( 'wall (block) thickness, cm', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Blocks needed', 'mvweb-build-calc' ),
			'unit'     => __( 'pcs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'area'      => array(
				'type'     => 'number',
				'label'    => __( 'Wall area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 5000,
				'step'     => 0.5,
				'required' => true,
			),
			'thickness' => array(
				'type'     => 'select',
				'label'    => __( 'Wall thickness (block width)', 'mvweb-build-calc' ),
				'default'  => '30',
				'required' => true,
				'options'  => array(
					'20' => __( '200 mm', 'mvweb-build-calc' ),
					'25' => __( '250 mm', 'mvweb-build-calc' ),
					'30' => __( '300 mm', 'mvweb-build-calc' ),
					'40' => __( '400 mm', 'mvweb-build-calc' ),
				),
			),
			'block'     => array(
				'type'     => 'select',
				'label'    => __( 'Block face size (length × height)', 'mvweb-build-calc' ),
				'default'  => '600x250',
				'required' => true,
				'options'  => array(
					'600x250' => __( '600 × 250 mm', 'mvweb-build-calc' ),
					'625x250' => __( '625 × 250 mm', 'mvweb-build-calc' ),
					'600x200' => __( '600 × 200 mm', 'mvweb-build-calc' ),
				),
			),
			'reserve'   => array(
				'type'     => 'number',
				'label'    => __( 'Waste reserve', 'mvweb-build-calc' ),
				'unit'     => __( '%', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 15,
				'step'     => 1,
				'default'  => 5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area      = max( 0.0, (float) ( $i['area'] ?? 0 ) );
			$thickness = (float) ( $i['thickness'] ?? 30 ) / 100; // cm → m.
			$reserve   = max( 0.0, (float) ( $i['reserve'] ?? 0 ) );
			$block     = (string) ( $i['block'] ?? '600x250' );

			$dims = match ( $block ) {
				'625x250' => array( 0.625, 0.25 ),
				'600x200' => array( 0.6, 0.2 ),
				default   => array( 0.6, 0.25 ),
			};

			// One block volume = length × height × wall thickness.
			$block_volume = $dims[0] * $dims[1] * $thickness;
			$volume       = $area * $thickness;
			$blocks       = $block_volume > 0 ? ( $volume / $block_volume ) * ( 1 + $reserve / 100 ) : 0;
			$blocks       = (int) ceil( $blocks );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: masonry volume m³, 2: reserve percent */
				__( 'Masonry volume %1$s m³, including a %2$s%% waste reserve.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $volume, 2 ),
				mvweb_bc_format_number( $reserve, 0 )
			);

			$hints[] = __( 'Thin-bed adhesive for aerated blocks is about 25–30 kg per m³ of masonry.', 'mvweb-build-calc' );

			$hints[] = __( 'Geometric estimate — round up to whole pallets when ordering.', 'mvweb-build-calc' );

			return array(
				'value' => $blocks,
				'hints' => $hints,
			);
		},
	)
);
