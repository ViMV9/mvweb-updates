<?php
/**
 * Calculator: floor insulation thickness.
 *
 * Preliminary estimate. The required resistance for a floor over an unheated
 * basement / crawl space is R = 0.00045·ГСОП + 1.9 (SP 50.13330 Table 3). The
 * structural deck adds a little; the rest is insulation: δ ≈ (R_req − R_base) × λ.
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'floor-insulation-thickness',
	array(
		'title'       => __( 'Floor insulation thickness', 'mvweb-build-calc' ),
		'hub'         => 'heat',
		'description' => __( 'Estimates the insulation thickness a floor over an unheated basement or crawl space needs to reach the required heat-transfer resistance for the region (R = a·ГСОП + b, SP 50.13330.2012 Table 3 for floors over basements). Preliminary estimate, not a thermal design.', 'mvweb-build-calc' ),
		'formula'     => 'δ = (R_req − R_deck) × λ_ins, R_req = 0.00045 × ГСОП + 1.9',
		'legend'      => array(
			'δ'      => __( 'insulation thickness, mm', 'mvweb-build-calc' ),
			'R_req'  => __( 'required floor resistance, m²·°C/W', 'mvweb-build-calc' ),
			'R_deck' => __( 'resistance of the structural deck, m²·°C/W', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Insulation thickness', 'mvweb-build-calc' ),
			'unit'     => __( 'mm', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'zone'       => array(
				'type'       => 'select',
				'label'      => __( 'Climate (degree-days, ГСОП)', 'mvweb-build-calc' ),
				'default'    => '6000',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'4000' => __( 'Mild (~4000): Krasnodar, Rostov', 'mvweb-build-calc' ),
					'5000' => __( 'Moderate (~5000): Minsk, Kaliningrad', 'mvweb-build-calc' ),
					'6000' => __( 'Central (~6000): Moscow, Saint Petersburg', 'mvweb-build-calc' ),
					'7000' => __( 'Cold (~7000): Yekaterinburg, Novosibirsk', 'mvweb-build-calc' ),
					'9000' => __( 'Severe (~9000): Surgut, Yakutsk', 'mvweb-build-calc' ),
				),
			),
			'deck'       => array(
				'type'       => 'select',
				'label'      => __( 'Structural deck', 'mvweb-build-calc' ),
				'default'    => 'concrete',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'concrete' => __( 'Reinforced concrete slab', 'mvweb-build-calc' ),
					'timber'   => __( 'Timber joists with boarding', 'mvweb-build-calc' ),
				),
			),
			'insulation' => array(
				'type'       => 'select',
				'label'      => __( 'Insulation', 'mvweb-build-calc' ),
				'default'    => 'mineral_wool',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'mineral_wool' => __( 'Mineral wool (λ 0.040)', 'mvweb-build-calc' ),
					'eps'          => __( 'EPS foam (λ 0.039)', 'mvweb-build-calc' ),
					'xps'          => __( 'Extruded polystyrene (λ 0.032)', 'mvweb-build-calc' ),
					'pir'          => __( 'PIR board (λ 0.025)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$gsop = (float) ( $i['zone'] ?? 6000 );
			$deck = (string) ( $i['deck'] ?? 'concrete' );
			$ins  = (string) ( $i['insulation'] ?? 'mineral_wool' );

			$lambda_ins = match ( $ins ) {
				'eps' => 0.039,
				'xps' => 0.032,
				'pir' => 0.025,
				default => 0.040, // mineral_wool.
			};

			$r_req   = 0.00045 * $gsop + 1.9;
			$r_deck  = ( 'timber' === $deck ) ? 0.35 : 0.2; // boarding adds more than bare slab.

			$delta_r  = max( 0.0, $r_req - $r_deck );
			$thick_mm = $delta_r * $lambda_ins * 1000;
			$rounded  = ceil( $thick_mm / 10 ) * 10;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: required R, 2: deck R */
				__( 'Required floor resistance %1$s m²·°C/W; the deck gives about %2$s.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $r_req, 2 ),
				mvweb_bc_format_number( $r_deck, 2 )
			);

			$hints[] = __( 'For a floor over a cold crawl space the insulation goes under the screed or between the joists, with a vapour barrier on the warm side.', 'mvweb-build-calc' );

			$hints[] = __( 'Preliminary estimate per SP 50.13330. It does not replace a thermal design by an engineer.', 'mvweb-build-calc' );

			return array(
				'value' => $rounded,
				'hints' => $hints,
			);
		},
	)
);
