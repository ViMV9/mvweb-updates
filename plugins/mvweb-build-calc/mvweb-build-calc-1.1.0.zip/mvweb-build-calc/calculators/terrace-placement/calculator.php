<?php
/**
 * Calculator: terrace placement suitability by cardinal direction.
 *
 * Recommendation, not a code requirement. Scores how well a terrace
 * orientation matches the intended use (morning sun, evening sun, shade,
 * all-day sun) and names the recommended direction. Score is 0–100.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'terrace-placement',
	array(
		'title'       => __( 'Terrace placement by cardinal direction', 'mvweb-build-calc' ),
		'hub'         => 'lot',
		'description' => __( 'Scores how well a terrace orientation matches the intended use and names the recommended cardinal direction. This is a design recommendation based on sun path practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'score = match(goal, facing)',
		'legend'      => array(
			'score'  => __( 'placement suitability, 0–100', 'mvweb-build-calc' ),
			'goal'   => __( 'how the terrace will be used', 'mvweb-build-calc' ),
			'facing' => __( 'cardinal direction the terrace faces', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Placement score', 'mvweb-build-calc' ),
			'unit'     => __( '/ 100', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'goal'   => array(
				'type'       => 'radio',
				'label'      => __( 'Intended use', 'mvweb-build-calc' ),
				'default'    => 'evening',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'morning' => __( 'Morning sun (breakfast)', 'mvweb-build-calc' ),
					'evening' => __( 'Evening sun (dinner, relaxing)', 'mvweb-build-calc' ),
					'shade'   => __( 'Shade (hot climate)', 'mvweb-build-calc' ),
					'allday'  => __( 'Sun most of the day', 'mvweb-build-calc' ),
				),
			),
			'facing' => array(
				'type'     => 'select',
				'label'    => __( 'Terrace faces', 'mvweb-build-calc' ),
				'default'  => 'w',
				'required' => true,
				'options'  => array(
					'n'  => __( 'North', 'mvweb-build-calc' ),
					'ne' => __( 'North-East', 'mvweb-build-calc' ),
					'e'  => __( 'East', 'mvweb-build-calc' ),
					'se' => __( 'South-East', 'mvweb-build-calc' ),
					's'  => __( 'South', 'mvweb-build-calc' ),
					'sw' => __( 'South-West', 'mvweb-build-calc' ),
					'w'  => __( 'West', 'mvweb-build-calc' ),
					'nw' => __( 'North-West', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$goal   = (string) ( $i['goal'] ?? 'evening' );
			$facing = (string) ( $i['facing'] ?? 'w' );

			$prefs = array(
				'morning' => array(
					'best' => array( 'e', 'se' ),
					'ok'   => array( 'ne', 's' ),
				),
				'evening' => array(
					'best' => array( 'w', 'sw' ),
					'ok'   => array( 's', 'nw' ),
				),
				'shade'   => array(
					'best' => array( 'n', 'ne' ),
					'ok'   => array( 'nw', 'e' ),
				),
				'allday'  => array(
					'best' => array( 's', 'se' ),
					'ok'   => array( 'sw', 'e' ),
				),
			);

			$names = array(
				'n'  => __( 'North', 'mvweb-build-calc' ),
				'ne' => __( 'North-East', 'mvweb-build-calc' ),
				'e'  => __( 'East', 'mvweb-build-calc' ),
				'se' => __( 'South-East', 'mvweb-build-calc' ),
				's'  => __( 'South', 'mvweb-build-calc' ),
				'sw' => __( 'South-West', 'mvweb-build-calc' ),
				'w'  => __( 'West', 'mvweb-build-calc' ),
				'nw' => __( 'North-West', 'mvweb-build-calc' ),
			);

			$pref = $prefs[ $goal ] ?? $prefs['evening'];

			if ( in_array( $facing, $pref['best'], true ) ) {
				$score = 100;
			} elseif ( in_array( $facing, $pref['ok'], true ) ) {
				$score = 60;
			} else {
				$score = 30;
			}

			$best_names = array_map(
				static fn( $d ) => $names[ $d ],
				$pref['best']
			);

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: list of recommended directions */
				__( 'Recommended orientation for this use: %s.', 'mvweb-build-calc' ),
				implode( ', ', $best_names )
			);

			if ( 100 === $score ) {
				$hints[] = __( 'The chosen orientation is ideal.', 'mvweb-build-calc' );
			} elseif ( 60 === $score ) {
				$hints[] = __( 'The chosen orientation is acceptable but not ideal.', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'The chosen orientation is a poor fit — consider a recommended one.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'This is a design recommendation based on sun path practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => (float) $score,
				'hints' => $hints,
			);
		},
	)
);
