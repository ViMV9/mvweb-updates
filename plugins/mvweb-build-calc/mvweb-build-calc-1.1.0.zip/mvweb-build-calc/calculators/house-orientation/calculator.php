<?php
/**
 * Calculator: room orientation suitability by cardinal direction.
 *
 * Recommendation, not a code requirement. Scores how well a chosen window
 * orientation suits a given room, based on common design practice for
 * daylight and overheating in the Russian climate. The score is 0–100; the
 * hints name the ideal direction and explain why.
 *
 * Each room has a set of preferred directions (score 100), acceptable ones
 * (score 60) and the rest (score 30).
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'house-orientation',
	array(
		'title'       => __( 'Room orientation by cardinal direction', 'mvweb-build-calc' ),
		'hub'         => 'lot',
		'description' => __( 'Scores how well a window orientation suits a room and names the ideal direction. This is a design recommendation based on daylight and overheating practice for the Russian climate, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'score = suitability(room, facing)',
		'legend'      => array(
			'score'  => __( 'orientation suitability, 0–100', 'mvweb-build-calc' ),
			'room'   => __( 'room whose windows are being placed', 'mvweb-build-calc' ),
			'facing' => __( 'cardinal direction the windows face', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Orientation score', 'mvweb-build-calc' ),
			'unit'     => __( '/ 100', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'room'   => array(
				'type'       => 'select',
				'label'      => __( 'Room', 'mvweb-build-calc' ),
				'default'    => 'bedroom',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'bedroom'  => __( 'Bedroom', 'mvweb-build-calc' ),
					'living'   => __( 'Living room', 'mvweb-build-calc' ),
					'kitchen'  => __( 'Kitchen', 'mvweb-build-calc' ),
					'children' => __( 'Children’s room', 'mvweb-build-calc' ),
					'office'   => __( 'Home office', 'mvweb-build-calc' ),
				),
			),
			'facing' => array(
				'type'     => 'select',
				'label'    => __( 'Windows face', 'mvweb-build-calc' ),
				'default'  => 'e',
				'required' => true,
				'options'  => array(
					'n'  => __( 'North', 'mvweb-build-calc' ),
					'ne' => __( 'North-East', 'mvweb-build-calc' ),
					'e'  => __( 'East', 'mvweb-build-calc' ),
					'se' => __( 'South-East', 'mvweb-build-calc' ),
					's'  => __( 'South', 'mvweb-build-calc' ),
					'sw' => __( 'South-West', 'mvweb-build-calc' ),
					'w'  => __( 'West', 'mvweb-build-calc' ),
					'nw' => __( 'North-West', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$room   = (string) ( $i['room'] ?? 'bedroom' );
			$facing = (string) ( $i['facing'] ?? 'e' );

			// Preferred and acceptable directions per room.
			$prefs = array(
				'bedroom'  => array(
					'best' => array( 'e', 'se' ),
					'ok'   => array( 'ne', 's' ),
				),
				'living'   => array(
					'best' => array( 's', 'sw' ),
					'ok'   => array( 'se', 'w' ),
				),
				'kitchen'  => array(
					'best' => array( 'n', 'ne' ),
					'ok'   => array( 'e', 'nw' ),
				),
				'children' => array(
					'best' => array( 'e', 'se' ),
					'ok'   => array( 's', 'ne' ),
				),
				'office'   => array(
					'best' => array( 'n', 'ne' ),
					'ok'   => array( 'nw', 'e' ),
				),
			);

			$names = array(
				'n'  => __( 'North', 'mvweb-build-calc' ),
				'ne' => __( 'North-East', 'mvweb-build-calc' ),
				'e'  => __( 'East', 'mvweb-build-calc' ),
				'se' => __( 'South-East', 'mvweb-build-calc' ),
				's'  => __( 'South', 'mvweb-build-calc' ),
				'sw' => __( 'South-West', 'mvweb-build-calc' ),
				'w'  => __( 'West', 'mvweb-build-calc' ),
				'nw' => __( 'North-West', 'mvweb-build-calc' ),
			);

			$pref = $prefs[ $room ] ?? $prefs['bedroom'];

			if ( in_array( $facing, $pref['best'], true ) ) {
				$score = 100;
			} elseif ( in_array( $facing, $pref['ok'], true ) ) {
				$score = 60;
			} else {
				$score = 30;
			}

			$best_names = array_map(
				static fn( $d ) => $names[ $d ],
				$pref['best']
			);

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: list of recommended directions */
				__( 'Best orientation for this room: %s.', 'mvweb-build-calc' ),
				implode( ', ', $best_names )
			);

			if ( 100 === $score ) {
				$hints[] = __( 'The chosen direction is ideal for this room.', 'mvweb-build-calc' );
			} elseif ( 60 === $score ) {
				$hints[] = __( 'The chosen direction is acceptable but not ideal.', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'The chosen direction is a poor fit — consider one of the recommended ones.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'This is a design recommendation based on daylight and overheating practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => (float) $score,
				'hints' => $hints,
			);
		},
	)
);
