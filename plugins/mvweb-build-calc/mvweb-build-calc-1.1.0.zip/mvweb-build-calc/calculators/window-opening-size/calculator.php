<?php
/**
 * Calculator: window opening size.
 *
 * Geometric calculation. From the desired clear window size, returns the rough
 * opening to leave in the wall — the window plus the mounting gap on each side
 * and the sill mounting allowance — and the rough opening area.
 *
 * Model:
 *   opening_w = window_w + 2 × gap
 *   opening_h = window_h + 2 × gap
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'window-opening-size',
	array(
		'title'       => __( 'Window opening size', 'mvweb-build-calc' ),
		'hub'         => 'openings',
		'description' => __( 'Calculates the rough wall opening to leave for a window — the window frame plus the mounting gap on each side for foam and fixing. Returns the opening width, height and area. Geometric calculation based on common mounting practice (GOST 30971).', 'mvweb-build-calc' ),
		'formula'     => 'opening = (window_w + 2 × gap) × (window_h + 2 × gap)',
		'legend'      => array(
			'window_w' => __( 'window frame width, mm', 'mvweb-build-calc' ),
			'window_h' => __( 'window frame height, mm', 'mvweb-build-calc' ),
			'gap'      => __( 'mounting gap on each side, mm', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Rough opening area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'window_w' => array(
				'type'     => 'number',
				'label'    => __( 'Window frame width', 'mvweb-build-calc' ),
				'unit'     => __( 'mm', 'mvweb-build-calc' ),
				'min'      => 300,
				'max'      => 4000,
				'step'     => 10,
				'required' => true,
			),
			'window_h' => array(
				'type'     => 'number',
				'label'    => __( 'Window frame height', 'mvweb-build-calc' ),
				'unit'     => __( 'mm', 'mvweb-build-calc' ),
				'min'      => 300,
				'max'      => 3000,
				'step'     => 10,
				'required' => true,
			),
			'gap'      => array(
				'type'    => 'select',
				'label'   => __( 'Mounting gap (each side)', 'mvweb-build-calc' ),
				'default' => '20',
				'options' => array(
					'15' => __( '15 mm (tight)', 'mvweb-build-calc' ),
					'20' => __( '20 mm (standard)', 'mvweb-build-calc' ),
					'30' => __( '30 mm (with warm sill profile)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$ww  = max( 1.0, (float) ( $i['window_w'] ?? 0 ) );
			$wh  = max( 1.0, (float) ( $i['window_h'] ?? 0 ) );
			$gap = (float) ( $i['gap'] ?? 20 );

			$ow = $ww + 2 * $gap;
			$oh = $wh + 2 * $gap;

			$area_m2 = ( $ow / 1000 ) * ( $oh / 1000 );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: opening width mm, 2: opening height mm */
				__( 'Leave a rough opening of about %1$d × %2$d mm.', 'mvweb-build-calc' ),
				(int) round( $ow ),
				(int) round( $oh )
			);

			$hints[] = __( 'The gap is filled with mounting foam and sealed; a wider gap suits a warm-sill profile or thick walls.', 'mvweb-build-calc' );

			$hints[] = __( 'Geometric estimate per common mounting practice (GOST 30971). Confirm against the chosen window’s spec.', 'mvweb-build-calc' );

			return array(
				'value' => $area_m2,
				'hints' => $hints,
			);
		},
	)
);
