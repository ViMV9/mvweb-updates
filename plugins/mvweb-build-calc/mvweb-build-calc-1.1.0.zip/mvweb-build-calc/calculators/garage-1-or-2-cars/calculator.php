<?php
/**
 * Calculator: garage for one or two cars.
 *
 * Ergonomic planning guide, not a code requirement. Returns the recommended
 * internal footprint of a garage for one or two cars side by side, including
 * a centre gap between the cars and side / front clearances.
 *
 * Model (two cars): width = 2 × car_width + 2 × side + centre_gap
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'garage-1-or-2-cars',
	array(
		'title'       => __( 'Garage for one or two cars', 'mvweb-build-calc' ),
		'hub'         => 'outbuildings',
		'description' => __( 'Estimates the recommended internal footprint of a garage for one or two cars parked side by side, including the gap between the cars and clearances around them. This is an ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'width = cars × car_width + 2 × side + (cars − 1) × centre_gap',
		'legend'      => array(
			'cars'       => __( 'number of cars side by side', 'mvweb-build-calc' ),
			'side'       => __( 'side clearance to the wall, m', 'mvweb-build-calc' ),
			'centre_gap' => __( 'gap between two cars for opening the doors, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended internal area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'cars'     => array(
				'type'       => 'radio',
				'label'      => __( 'Number of cars', 'mvweb-build-calc' ),
				'default'    => '2',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'1' => __( 'One car', 'mvweb-build-calc' ),
					'2' => __( 'Two cars (side by side)', 'mvweb-build-calc' ),
				),
			),
			'car_size' => array(
				'type'       => 'select',
				'label'      => __( 'Car class', 'mvweb-build-calc' ),
				'default'    => 'mid',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'small' => __( 'Small (~3.8 × 1.7 m)', 'mvweb-build-calc' ),
					'mid'   => __( 'Mid-size (~4.6 × 1.85 m)', 'mvweb-build-calc' ),
					'large' => __( 'Large (~5.1 × 2.0 m)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$cars = ( '1' === (string) ( $i['cars'] ?? '2' ) ) ? 1 : 2;
			$car  = (string) ( $i['car_size'] ?? 'mid' );

			$dims = match ( $car ) {
				'small' => array( 1.7, 3.8 ),
				'large' => array( 2.0, 5.1 ),
				default => array( 1.85, 4.6 ), // mid.
			};
			$car_w = $dims[0];
			$car_l = $dims[1];

			$side       = 0.7;  // clearance to each side wall.
			$centre_gap = 0.8;  // gap between two cars for doors.
			$front      = 0.8;  // front zone.
			$rear       = 0.5;  // rear zone.

			$width  = $cars * $car_w + 2 * $side + ( $cars - 1 ) * $centre_gap;
			$length = $car_l + $front + $rear;
			$area   = $width * $length;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: cars count, 2: internal width m, 3: internal length m */
				_n(
					'%1$d car: recommended internal size %2$s × %3$s m.',
					'%1$d cars: recommended internal size %2$s × %3$s m.',
					$cars,
					'mvweb-build-calc'
				),
				$cars,
				mvweb_bc_format_number( $width, 1 ),
				mvweb_bc_format_number( $length, 1 )
			);

			if ( 2 === $cars ) {
				$hints[] = __( 'A two-car garage needs a centre gap of about 0.8 m so both drivers can open their doors.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
