<?php
/**
 * Calculator: ventilation rate (air changes per hour).
 *
 * Preliminary estimate. The air change rate is the airflow divided by the room
 * volume; the volume is area × height. Rates the result against the typical
 * band for the room type.
 *
 * Model:
 *   ACH = airflow / (area × height)
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'ventilation-rate',
	array(
		'title'       => __( 'Ventilation rate', 'mvweb-build-calc' ),
		'hub'         => 'engineering',
		'description' => __( 'Calculates the air change rate (air changes per hour) from the supplied airflow and the room volume, and rates it against the typical band for the room type. Based on SP 60.13330; a preliminary estimate, not a ventilation design.', 'mvweb-build-calc' ),
		'formula'     => 'ACH = airflow / (area × height)',
		'legend'      => array(
			'ACH'     => __( 'air changes per hour, 1/h', 'mvweb-build-calc' ),
			'airflow' => __( 'airflow, m³/h', 'mvweb-build-calc' ),
			'area'    => __( 'room area, m²', 'mvweb-build-calc' ),
			'height'  => __( 'ceiling height, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Air change rate', 'mvweb-build-calc' ),
			'unit'     => __( '1/h', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'airflow' => array(
				'type'     => 'number',
				'label'    => __( 'Airflow', 'mvweb-build-calc' ),
				'unit'     => __( 'm³/h', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 5000,
				'step'     => 1,
				'required' => true,
			),
			'area'    => array(
				'type'     => 'number',
				'label'    => __( 'Room area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 200,
				'step'     => 0.5,
				'required' => true,
			),
			'height'  => array(
				'type'     => 'number',
				'label'    => __( 'Ceiling height', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 2.7,
				'min'      => 2,
				'max'      => 6,
				'step'     => 0.1,
				'required' => true,
			),
			'room'    => array(
				'type'       => 'select',
				'label'      => __( 'Room type (for the target band)', 'mvweb-build-calc' ),
				'default'    => 'living',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'living'  => __( 'Living room (~1/h)', 'mvweb-build-calc' ),
					'kitchen' => __( 'Kitchen (~3/h)', 'mvweb-build-calc' ),
					'bath'    => __( 'Bathroom (~3–5/h)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$airflow = max( 0.0, (float) ( $i['airflow'] ?? 0 ) );
			$area    = max( 0.01, (float) ( $i['area'] ?? 0 ) );
			$height  = max( 0.01, (float) ( $i['height'] ?? 2.7 ) );
			$room    = (string) ( $i['room'] ?? 'living' );

			$volume = $area * $height;
			$ach    = $volume > 0 ? $airflow / $volume : 0.0;

			$target = match ( $room ) {
				'kitchen' => array( 3.0, 6.0 ),
				'bath'    => array( 3.0, 5.0 ),
				default   => array( 0.5, 1.5 ), // living.
			};

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: room volume m³ */
				__( 'Room volume %s m³.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $volume, 1 )
			);

			if ( $ach < $target[0] ) {
				$hints[] = __( 'Below the typical band for this room — increase the airflow or add extract ventilation.', 'mvweb-build-calc' );
			} elseif ( $ach > $target[1] ) {
				$hints[] = __( 'Above the typical band — fine for a wet room, but for a living room it may feel draughty and waste heat.', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'Within the typical band for this room type.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Based on SP 60.13330. Preliminary estimate, not a ventilation design.', 'mvweb-build-calc' );

			return array(
				'value' => $ach,
				'hints' => $hints,
			);
		},
	)
);
