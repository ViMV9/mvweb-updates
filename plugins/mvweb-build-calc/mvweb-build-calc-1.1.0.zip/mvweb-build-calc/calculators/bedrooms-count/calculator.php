<?php
/**
 * Calculator: recommended number of bedrooms by family composition.
 *
 * Ergonomic planning guide, not a code requirement. Building codes do not
 * prescribe a bedroom count; the rule below follows common residential design
 * practice for detached houses.
 *
 * Model:
 *   bedrooms = parents_bedroom (1) + children_bedrooms + guest_bedroom
 *
 * children_bedrooms depends on the chosen sleeping arrangement:
 *   - shared:    young children share, ceil(children / 2)
 *   - separate:  each child gets their own room, = children
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'bedrooms-count',
	array(
		'title'       => __( 'Recommended number of bedrooms', 'mvweb-build-calc' ),
		'hub'         => 'rooms',
		'description' => __( 'Estimates the recommended number of bedrooms from family composition and how children share rooms. This is an ergonomic planning guide based on common design practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'B = 1 + children_rooms + guest',
		'legend'      => array(
			'B'              => __( 'recommended number of bedrooms', 'mvweb-build-calc' ),
			'1'              => __( 'one bedroom for the parents', 'mvweb-build-calc' ),
			'children_rooms' => __( 'rooms for children — shared: ⌈children/2⌉, separate: one each', 'mvweb-build-calc' ),
			'guest'          => __( 'optional guest bedroom (+1)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Bedrooms', 'mvweb-build-calc' ),
			'unit'     => __( 'pcs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'children'   => array(
				'type'    => 'number',
				'label'   => __( 'Children', 'mvweb-build-calc' ),
				'default' => 2,
				'min'     => 0,
				'max'     => 20,
				'step'    => 1,
			),
			'sharing'    => array(
				'type'       => 'radio',
				'label'      => __( 'Children sleeping arrangement', 'mvweb-build-calc' ),
				'default'    => 'shared',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'shared'   => __( 'Young children may share a room', 'mvweb-build-calc' ),
					'separate' => __( 'Each child gets a separate room', 'mvweb-build-calc' ),
				),
			),
			'guest_room' => array(
				'type'    => 'radio',
				'label'   => __( 'Guest bedroom', 'mvweb-build-calc' ),
				'default' => 'no',
				'options' => array(
					'no'  => __( 'No', 'mvweb-build-calc' ),
					'yes' => __( 'Yes', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$children = max( 0, (int) ( $i['children'] ?? 0 ) );
			$sharing  = (string) ( $i['sharing'] ?? 'shared' );
			$guest    = 'yes' === (string) ( $i['guest_room'] ?? 'no' );

			// One bedroom for the parents (couple or single).
			$parents_room = 1;

			$children_rooms = 'separate' === $sharing
				? $children
				: (int) ceil( $children / 2 );

			$bedrooms = $parents_room + $children_rooms + ( $guest ? 1 : 0 );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: children rooms, 2: children count */
				__( '1 for the parents + %1$d for %2$d children%3$s.', 'mvweb-build-calc' ),
				$children_rooms,
				$children,
				$guest ? __( ' + 1 guest', 'mvweb-build-calc' ) : ''
			);

			if ( $children >= 2 && 'shared' === $sharing ) {
				$hints[] = __( 'Same-sex young children can share; once they grow up or differ in sex, plan a separate room for each.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'This is an ergonomic planning guide, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => (float) $bedrooms,
				'hints' => $hints,
			);
		},
	)
);
