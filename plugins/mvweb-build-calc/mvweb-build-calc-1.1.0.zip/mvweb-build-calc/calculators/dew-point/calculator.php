<?php
/**
 * Calculator: dew point in a wall.
 *
 * Estimate. The dew-point temperature for the indoor air is found from the
 * indoor temperature and relative humidity (Magnus approximation), then
 * compared with the indoor surface temperature to flag a condensation risk.
 *
 * Model (Magnus):
 *   γ  = ln(RH/100) + a·t / (b + t)
 *   Td = b·γ / (a − γ),  a = 17.62, b = 243.12
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'dew-point',
	array(
		'title'       => __( 'Dew point in a wall', 'mvweb-build-calc' ),
		'hub'         => 'heat',
		'description' => __( 'Calculates the dew-point temperature of the indoor air from the temperature and relative humidity, and compares it with the inner wall-surface temperature to flag a condensation risk. Uses the Magnus approximation. Preliminary estimate, not a full moisture calculation per SP 50.13330.', 'mvweb-build-calc' ),
		'formula'     => 'Td = b·γ / (a − γ), γ = ln(RH/100) + a·t/(b+t)',
		'legend'      => array(
			'Td' => __( 'dew-point temperature, °C', 'mvweb-build-calc' ),
			't'  => __( 'indoor air temperature, °C', 'mvweb-build-calc' ),
			'RH' => __( 'indoor relative humidity, %', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Dew point', 'mvweb-build-calc' ),
			'unit'     => __( '°C', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'temp'         => array(
				'type'     => 'number',
				'label'    => __( 'Indoor air temperature', 'mvweb-build-calc' ),
				'unit'     => __( '°C', 'mvweb-build-calc' ),
				'default'  => 20,
				'min'      => 5,
				'max'      => 35,
				'step'     => 0.5,
				'required' => true,
			),
			'humidity'     => array(
				'type'     => 'number',
				'label'    => __( 'Indoor relative humidity', 'mvweb-build-calc' ),
				'unit'     => __( '%', 'mvweb-build-calc' ),
				'default'  => 55,
				'min'      => 10,
				'max'      => 99,
				'step'     => 1,
				'required' => true,
			),
			'surface_temp' => array(
				'type'     => 'number',
				'label'    => __( 'Inner wall-surface temperature', 'mvweb-build-calc' ),
				'unit'     => __( '°C', 'mvweb-build-calc' ),
				'default'  => 16,
				'min'      => -10,
				'max'      => 35,
				'step'     => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$t       = (float) ( $i['temp'] ?? 20 );
			$rh      = min( 99.0, max( 1.0, (float) ( $i['humidity'] ?? 55 ) ) );
			$surface = (float) ( $i['surface_temp'] ?? 16 );

			$a = 17.62;
			$b = 243.12;
			$gamma = log( $rh / 100 ) + ( $a * $t ) / ( $b + $t );
			$dew   = ( $b * $gamma ) / ( $a - $gamma );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: indoor temp °C, 2: humidity percent */
				__( 'At %1$s °C and %2$s%% humidity, moisture condenses on any surface colder than the dew point.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $t, 0 ),
				mvweb_bc_format_number( $rh, 0 )
			);

			if ( $surface <= $dew ) {
				$hints[] = sprintf(
					/* translators: 1: surface temp °C, 2: dew point °C */
					__( 'Risk: the surface (%1$s °C) is at or below the dew point (%2$s °C) — condensation likely. Add insulation or lower the humidity.', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $surface, 1 ),
					mvweb_bc_format_number( $dew, 1 )
				);
			} else {
				$hints[] = sprintf(
					/* translators: 1: surface temp °C, 2: margin °C */
					__( 'OK: the surface (%1$s °C) is %2$s °C above the dew point — no condensation expected.', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $surface, 1 ),
					mvweb_bc_format_number( $surface - $dew, 1 )
				);
			}

			$hints[] = __( 'Insulating on the outside keeps the wall warm and moves the dew point into the insulation; insulating inside needs a vapour barrier.', 'mvweb-build-calc' );

			$hints[] = __( 'Preliminary estimate (Magnus approximation). It does not replace a moisture calculation per SP 50.13330.', 'mvweb-build-calc' );

			return array(
				'value' => $dew,
				'hints' => $hints,
			);
		},
	)
);
