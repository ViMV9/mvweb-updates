<?php
/**
 * Calculator: roof insulation area.
 *
 * Insulation area between the rafters of a pitched roof: the sloped roof area
 * minus the area taken by the rafters themselves, with the insulation volume
 * for the chosen thickness. Geometric calculation.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'roof-insulation-area',
	array(
		'title'       => __( 'Roof insulation area', 'mvweb-build-calc' ),
		'hub'         => 'roof',
		'description' => __( 'Calculates the insulation area between the rafters of a pitched roof — the sloped roof area minus the strip taken by the rafters — and the insulation volume for the chosen thickness. Geometric calculation.', 'mvweb-build-calc' ),
		'formula'     => 'area = roof area × (1 − rafter share), volume = area × thickness',
		'legend'      => array(
			'area' => __( 'insulation area, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Insulation area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'area'      => array(
				'type'     => 'number',
				'label'    => __( 'Sloped roof area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 5000,
				'step'     => 0.5,
				'required' => true,
			),
			'thickness' => array(
				'type'     => 'select',
				'label'    => __( 'Insulation thickness', 'mvweb-build-calc' ),
				'default'  => '20',
				'required' => true,
				'options'  => array(
					'15' => __( '150 mm', 'mvweb-build-calc' ),
					'20' => __( '200 mm', 'mvweb-build-calc' ),
					'25' => __( '250 mm', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area      = max( 0.0, (float) ( $i['area'] ?? 0 ) );
			$thickness = (float) ( $i['thickness'] ?? 20 ) / 100; // cm → m.

			// Rafters occupy ~10% of the surface between them.
			$rafter_share = 0.10;
			$ins_area     = $area * ( 1 - $rafter_share );
			$volume       = $ins_area * $thickness;

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: insulation volume m³ */
				__( 'Insulation volume about %s m³ for the chosen thickness.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $volume, 2 )
			);

			$hints[] = __( 'About 10% of the area is taken by the rafters and is not insulated between them.', 'mvweb-build-calc' );

			$hints[] = __( 'For a cold-climate roof the total thickness is often 200–250 mm; confirm with a thermal calculation per SP 50.13330.', 'mvweb-build-calc' );

			return array(
				'value' => round( $ins_area, 1 ),
				'hints' => $hints,
			);
		},
	)
);
