<?php
/**
 * Calculator: external walls area.
 *
 * Net masonry area of the external walls = perimeter × height × floors minus
 * the openings (windows and doors). Geometric calculation.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'external-walls-area',
	array(
		'title'       => __( 'External walls area', 'mvweb-build-calc' ),
		'hub'         => 'walls',
		'description' => __( 'Calculates the net area of the external walls — perimeter times wall height times the number of floors, minus the area of windows and doors. Use this area for masonry, insulation and finishing take-offs.', 'mvweb-build-calc' ),
		'formula'     => 'area = P × H × floors − openings',
		'legend'      => array(
			'area'     => __( 'net external wall area, m²', 'mvweb-build-calc' ),
			'P'        => __( 'wall perimeter, m', 'mvweb-build-calc' ),
			'H'        => __( 'floor height, m', 'mvweb-build-calc' ),
			'openings' => __( 'total area of windows and doors, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Net external wall area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'perimeter' => array(
				'type'     => 'number',
				'label'    => __( 'Wall perimeter', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 4,
				'max'      => 500,
				'step'     => 0.1,
				'required' => true,
			),
			'height'    => array(
				'type'     => 'number',
				'label'    => __( 'Floor height', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 6,
				'step'     => 0.1,
				'required' => true,
			),
			'floors'    => array(
				'type'     => 'number',
				'label'    => __( 'Number of floors', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 3,
				'step'     => 1,
				'required' => true,
			),
			'openings'  => array(
				'type'     => 'number',
				'label'    => __( 'Total openings area (windows + doors)', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 500,
				'step'     => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$perimeter = max( 0.0, (float) ( $i['perimeter'] ?? 0 ) );
			$height    = max( 0.0, (float) ( $i['height'] ?? 0 ) );
			$floors    = max( 1.0, (float) ( $i['floors'] ?? 1 ) );
			$openings  = max( 0.0, (float) ( $i['openings'] ?? 0 ) );

			$gross = $perimeter * $height * $floors;
			$net   = max( 0.0, $gross - $openings );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: gross area m², 2: openings area m² */
				__( 'Gross wall area %1$s m², openings %2$s m².', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $gross, 1 ),
				mvweb_bc_format_number( $openings, 1 )
			);

			$hints[] = __( 'This net area is the masonry surface; multiply by the wall thickness for the masonry volume.', 'mvweb-build-calc' );

			return array(
				'value' => round( $net, 1 ),
				'hints' => $hints,
			);
		},
	)
);
