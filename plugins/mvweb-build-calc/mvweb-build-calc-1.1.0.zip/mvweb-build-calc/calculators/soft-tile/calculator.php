<?php
/**
 * Calculator: soft (bituminous) tile packs.
 *
 * Number of packs of soft bituminous tile for the roof area: roof area divided
 * by the coverage of one pack, plus a cutting reserve. Geometric calculation.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'soft-tile',
	array(
		'title'       => __( 'Soft tile packs', 'mvweb-build-calc' ),
		'hub'         => 'roof',
		'description' => __( 'Calculates the number of packs of soft bituminous (shingle) tile for the roof area: the roof area divided by the coverage of one pack, plus a cutting reserve. A typical pack covers about 3 m². Geometric calculation.', 'mvweb-build-calc' ),
		'formula'     => 'packs = roof area / pack coverage × (1 + reserve%)',
		'legend'      => array(
			'area' => __( 'roof area, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Packs needed', 'mvweb-build-calc' ),
			'unit'     => __( 'packs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'area'     => array(
				'type'     => 'number',
				'label'    => __( 'Roof area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 5000,
				'step'     => 0.5,
				'required' => true,
			),
			'coverage' => array(
				'type'     => 'number',
				'label'    => __( 'Coverage of one pack', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 6,
				'step'     => 0.1,
				'default'  => 3,
				'required' => true,
			),
			'reserve'  => array(
				'type'     => 'number',
				'label'    => __( 'Cutting reserve', 'mvweb-build-calc' ),
				'unit'     => __( '%', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 20,
				'step'     => 1,
				'default'  => 7,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area     = max( 0.0, (float) ( $i['area'] ?? 0 ) );
			$coverage = max( 0.1, (float) ( $i['coverage'] ?? 0 ) );
			$reserve  = max( 0.0, (float) ( $i['reserve'] ?? 0 ) );

			$packs = (int) ceil( $area / $coverage * ( 1 + $reserve / 100 ) );

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: reserve percent */
				__( 'Includes a %s%% cutting reserve; valleys and hips need more.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $reserve, 0 )
			);

			$hints[] = __( 'Add separately: underlay carpet, starter strip, ridge/hip shingles and valley carpet.', 'mvweb-build-calc' );

			$hints[] = __( 'Geometric estimate — take the exact pack coverage from the product sheet.', 'mvweb-build-calc' );

			return array(
				'value' => $packs,
				'hints' => $hints,
			);
		},
	)
);
