<?php
/**
 * Calculator: gutter system.
 *
 * Gutter length along the eaves and the number of downpipes and outlets for the
 * roof, sizing outlets by the served roof area (about one per 10 m of gutter
 * and per ~100 m² of roof). Geometric estimate.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'gutter-system',
	array(
		'title'       => __( 'Gutter system', 'mvweb-build-calc' ),
		'hub'         => 'roof',
		'description' => __( 'Calculates the gutter length along the eaves and the number of downpipes and outlets for the roof, sizing outlets by the served area (about one downpipe per 10 m of gutter and per 100 m² of roof). Geometric estimate.', 'mvweb-build-calc' ),
		'formula'     => 'gutter = eaves length, downpipes = max(eaves/10, area/100)',
		'legend'      => array(
			'gutter' => __( 'gutter length, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Gutter length', 'mvweb-build-calc' ),
			'unit'     => __( 'm', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'eaves'  => array(
				'type'     => 'number',
				'label'    => __( 'Total eaves length', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 500,
				'step'     => 0.1,
				'required' => true,
			),
			'area'   => array(
				'type'     => 'number',
				'label'    => __( 'Roof area drained', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 5,
				'max'      => 5000,
				'step'     => 0.5,
				'required' => true,
			),
			'height' => array(
				'type'     => 'number',
				'label'    => __( 'Eaves height above ground', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 15,
				'step'     => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$eaves  = max( 0.0, (float) ( $i['eaves'] ?? 0 ) );
			$area   = max( 0.0, (float) ( $i['area'] ?? 0 ) );
			$height = max( 0.0, (float) ( $i['height'] ?? 0 ) );

			// One downpipe per ~10 m of gutter and per ~100 m² of roof.
			$by_length = (int) ceil( $eaves / 10 );
			$by_area   = (int) ceil( $area / 100 );
			$downpipes = max( 1, $by_length, $by_area );

			// Pipe length ≈ eaves height per downpipe, plus a 1 m allowance each.
			$pipe_length = $downpipes * ( $height + 1 );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: downpipes count, 2: pipe length m */
				__( 'About %1$d downpipes; roughly %2$s m of pipe in total.', 'mvweb-build-calc' ),
				$downpipes,
				mvweb_bc_format_number( $pipe_length, 1 )
			);

			$hints[] = __( 'Add one outlet (funnel) per downpipe, plus brackets every 0.5–0.6 m and corners as needed.', 'mvweb-build-calc' );

			$hints[] = __( 'Geometric estimate — one downpipe serves about 10 m of gutter or 100 m² of roof.', 'mvweb-build-calc' );

			return array(
				'value' => round( $eaves, 1 ),
				'hints' => $hints,
			);
		},
	)
);
