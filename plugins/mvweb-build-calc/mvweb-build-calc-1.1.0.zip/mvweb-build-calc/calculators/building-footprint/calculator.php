<?php
/**
 * Calculator: building footprint (built-up area on the plot).
 *
 * Geometry. The footprint is the area the house occupies on the ground —
 * the main rectangle plus any projecting parts (porch, terrace, bay window,
 * cantilevers). Per SP 30-102-99 the built-up area counts projecting parts
 * that rest on the ground or overhang it.
 *
 * Model:
 *   footprint = length × width + projections
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'building-footprint',
	array(
		'title'       => __( 'Building footprint', 'mvweb-build-calc' ),
		'hub'         => 'lot',
		'description' => __( 'Calculates the building footprint — the area the house occupies on the plot, including projecting parts such as a porch, terrace or bay window. Used to check the plot coverage limit and the free area left for the garden.', 'mvweb-build-calc' ),
		'formula'     => 'F = L × W + projections',
		'legend'      => array(
			'F'           => __( 'building footprint, m²', 'mvweb-build-calc' ),
			'L'           => __( 'house length along the ground, m', 'mvweb-build-calc' ),
			'W'           => __( 'house width along the ground, m', 'mvweb-build-calc' ),
			'projections' => __( 'projecting parts resting on or overhanging the ground — porch, terrace, bay window, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Building footprint', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'length'      => array(
				'type'     => 'number',
				'label'    => __( 'House length', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 10,
				'min'      => 1,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'width'       => array(
				'type'     => 'number',
				'label'    => __( 'House width', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 8,
				'min'      => 1,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'projections' => array(
				'type'    => 'number',
				'label'   => __( 'Projecting parts (porch, terrace)', 'mvweb-build-calc' ),
				'unit'    => __( 'm²', 'mvweb-build-calc' ),
				'default' => 0,
				'min'     => 0,
				'max'     => 1000,
				'step'    => 0.1,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$length      = max( 0.0, (float) ( $i['length'] ?? 0 ) );
			$width       = max( 0.0, (float) ( $i['width'] ?? 0 ) );
			$projections = max( 0.0, (float) ( $i['projections'] ?? 0 ) );

			$base      = $length * $width;
			$footprint = $base + $projections;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: base rectangle area, 2: projections area, both in m² */
				__( 'Main rectangle %1$s m² + projecting parts %2$s m².', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $base, 1 ),
				mvweb_bc_format_number( $projections, 1 )
			);

			$hints[] = __( 'Per SP 30-102-99 the built-up area includes projecting parts that rest on the ground or overhang it (porch, terrace, bay window, cantilevered floors).', 'mvweb-build-calc' );

			return array(
				'value' => $footprint,
				'hints' => $hints,
			);
		},
	)
);
