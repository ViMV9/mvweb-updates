<?php
/**
 * Calculator: outdoor toilet size and setbacks.
 *
 * Ergonomic + sanitary guide. Returns the recommended cabin footprint by type
 * and reminds the sanitary setbacks an outdoor toilet must keep on a plot
 * (SP 53.13330.2019): at least 12 m from a house and 8 m from a well.
 *
 * Model:
 *   area = cabin footprint by type
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'outdoor-toilet',
	array(
		'title'       => __( 'Outdoor toilet size', 'mvweb-build-calc' ),
		'hub'         => 'outbuildings',
		'description' => __( 'Returns the recommended cabin footprint of an outdoor toilet by type and the sanitary setbacks it must keep on the plot. Cabin sizes are ergonomic; the setbacks follow SP 53.13330.2019. This is a planning guide, not a full design.', 'mvweb-build-calc' ),
		'formula'     => 'area = width × depth (by cabin type)',
		'legend'      => array(
			'area'  => __( 'cabin footprint, m²', 'mvweb-build-calc' ),
			'width' => __( 'cabin width, m', 'mvweb-build-calc' ),
			'depth' => __( 'cabin depth, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Cabin footprint', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'type' => array(
				'type'       => 'select',
				'label'      => __( 'Cabin type', 'mvweb-build-calc' ),
				'default'    => 'standard',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'compact'    => __( 'Compact (1.0 × 1.2 m)', 'mvweb-build-calc' ),
					'standard'   => __( 'Standard (1.2 × 1.5 m)', 'mvweb-build-calc' ),
					'accessible' => __( 'Roomy / accessible (1.5 × 1.8 m)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$type = (string) ( $i['type'] ?? 'standard' );

			$dims = match ( $type ) {
				'compact'    => array( 1.0, 1.2 ),
				'accessible' => array( 1.5, 1.8 ),
				default      => array( 1.2, 1.5 ), // standard.
			};
			$width = $dims[0];
			$depth = $dims[1];
			$area  = $width * $depth;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: width m, 2: depth m */
				__( 'Cabin %1$s × %2$s m. A height of about 2.2 m is comfortable.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $width, 1 ),
				mvweb_bc_format_number( $depth, 1 )
			);

			$hints[] = __( 'Sanitary setbacks (SP 53.13330.2019): at least 12 m from a house, 8 m from a well or borehole, and 1 m from the plot boundary.', 'mvweb-build-calc' );

			$hints[] = __( 'A pit-type toilet is not allowed near a well; for high groundwater use a sealed tank or a composting toilet.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
