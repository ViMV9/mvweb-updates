<?php
/**
 * Calculator: heating boiler power.
 *
 * Preliminary estimate. Sizes the boiler from the heated area scaled by a
 * climate-zone specific heat demand, adjusted for ceiling height, with a
 * reserve and an optional allowance for domestic hot water.
 *
 * Model:
 *   Q = area × spec_power(zone) × height_factor × reserve + dhw
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'boiler-power',
	array(
		'title'       => __( 'Boiler power', 'mvweb-build-calc' ),
		'hub'         => 'engineering',
		'description' => __( 'Estimates the required heating boiler power from the heated area, the climate zone and the ceiling height, with a reserve and an optional allowance for domestic hot water. This is a preliminary estimate based on the common 1 kW per 10 m² rule scaled by climate; a full load is found from a heat-loss calculation per SP 60.13330.', 'mvweb-build-calc' ),
		'formula'     => 'Q = area × spec_power × (height / 2.7) × reserve + DHW',
		'legend'      => array(
			'Q'          => __( 'boiler power, kW', 'mvweb-build-calc' ),
			'area'       => __( 'heated area, m²', 'mvweb-build-calc' ),
			'spec_power' => __( 'specific power by climate zone, kW per 10 m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended boiler power', 'mvweb-build-calc' ),
			'unit'     => __( 'kW', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'area'   => array(
				'type'     => 'number',
				'label'    => __( 'Heated area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 10,
				'max'      => 1500,
				'step'     => 1,
				'required' => true,
			),
			'zone'   => array(
				'type'       => 'select',
				'label'      => __( 'Climate zone', 'mvweb-build-calc' ),
				'default'    => 'central',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'south'   => __( 'Southern (0.8 kW / 10 m²)', 'mvweb-build-calc' ),
					'central' => __( 'Central (1.0 kW / 10 m²)', 'mvweb-build-calc' ),
					'north'   => __( 'Northern (1.5 kW / 10 m²)', 'mvweb-build-calc' ),
				),
			),
			'height' => array(
				'type'     => 'number',
				'label'    => __( 'Ceiling height', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 2.7,
				'min'      => 2.4,
				'max'      => 5,
				'step'     => 0.1,
				'required' => true,
			),
			'dhw'    => array(
				'type'       => 'radio',
				'label'      => __( 'Domestic hot water', 'mvweb-build-calc' ),
				'default'    => 'yes',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'no'  => __( 'Heating only', 'mvweb-build-calc' ),
					'yes' => __( 'Heating + hot water (+25%)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area   = max( 1.0, (float) ( $i['area'] ?? 0 ) );
			$zone   = (string) ( $i['zone'] ?? 'central' );
			$height = max( 2.0, (float) ( $i['height'] ?? 2.7 ) );
			$dhw    = ( 'no' !== (string) ( $i['dhw'] ?? 'yes' ) );

			// Specific power, kW per m².
			$spec = match ( $zone ) {
				'south' => 0.08,
				'north' => 0.15,
				default => 0.10, // central.
			};

			$height_factor = $height / 2.7;
			$reserve       = 1.15;

			$base = $area * $spec * $height_factor * $reserve;
			$q    = $dhw ? $base * 1.25 : $base;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: base heating power kW, 2: reserve percent */
				__( 'Heating demand about %1$s kW including a %2$s%% reserve.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $base, 1 ),
				'15'
			);

			if ( $dhw ) {
				$hints[] = __( 'A further 25% is added for domestic hot water. A dual-circuit boiler or a separate cylinder covers it.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Preliminary estimate based on the 1 kW / 10 m² rule scaled by climate. A full load comes from a heat-loss calculation per SP 60.13330; it does not replace a heating design.', 'mvweb-build-calc' );

			return array(
				'value' => $q,
				'hints' => $hints,
			);
		},
	)
);
