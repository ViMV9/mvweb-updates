<?php
/**
 * Calculator: recommended corridor width.
 *
 * Returns a recommended clear corridor width by its role (main passage,
 * secondary passage, or one leading to a single room). Ergonomic guide based on
 * common practice and SP 55.13330 (main corridors at least ~0.9 m clear).
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'corridor-width',
	array(
		'title'       => __( 'Corridor width', 'mvweb-build-calc' ),
		'hub'         => 'layout',
		'description' => __( 'Recommends a clear corridor width by its role — a main passage, a secondary passage, or one leading to a single room. Ergonomic guide based on common practice and SP 55.13330 (main corridors at least about 0.9 m clear).', 'mvweb-build-calc' ),
		'formula'     => 'width = base by role + allowance for a turn',
		'legend'      => array(
			'width' => __( 'recommended clear width, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended corridor width', 'mvweb-build-calc' ),
			'unit'     => __( 'm', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'role' => array(
				'type'       => 'select',
				'label'      => __( 'Corridor role', 'mvweb-build-calc' ),
				'default'    => 'main',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'main'      => __( 'Main passage (several rooms)', 'mvweb-build-calc' ),
					'secondary' => __( 'Secondary passage', 'mvweb-build-calc' ),
					'single'    => __( 'Leads to a single room', 'mvweb-build-calc' ),
				),
			),
			'turn' => array(
				'type'    => 'radio',
				'label'   => __( 'Has a 90° turn', 'mvweb-build-calc' ),
				'default' => 'no',
				'options' => array(
					'no'  => __( 'No', 'mvweb-build-calc' ),
					'yes' => __( 'Yes', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$role = (string) ( $i['role'] ?? 'main' );
			$turn = (string) ( $i['turn'] ?? 'no' );

			$base = match ( $role ) {
				'secondary' => 0.9,
				'single'    => 0.8,
				default     => 1.1,
			};

			// A turn needs extra width to carry furniture around the corner.
			$width = $base + ( 'yes' === $turn ? 0.2 : 0.0 );

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: base width m */
				__( 'Base recommended width for this role is %s m.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $base, 2 )
			);

			if ( 'yes' === $turn ) {
				$hints[] = __( 'A 90° turn adds 0.2 m so furniture can be carried around the corner.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'A clear width below 0.9 m makes a main corridor cramped and hard to furnish around.', 'mvweb-build-calc' );

			$hints[] = __( 'Ergonomic guide based on common practice and SP 55.13330; it is a recommendation, not a binding minimum for a private house.', 'mvweb-build-calc' );

			return array(
				'value' => round( $width, 2 ),
				'hints' => $hints,
			);
		},
	)
);
