<?php
/**
 * Calculator: recommended tread depth for a given riser.
 *
 * From a chosen riser height it returns the recommended tread depth using the
 * comfort formula 2·riser + tread = 620 mm, clamped to the practical tread
 * range. Ergonomic guide based on common practice and SP 55.13330.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'step-dimensions',
	array(
		'title'       => __( 'Riser and tread dimensions', 'mvweb-build-calc' ),
		'hub'         => 'layout',
		'description' => __( 'Returns the recommended tread depth for a chosen riser height using the comfort formula 2·riser + tread ≈ 600–640 mm. Ergonomic guide based on common practice and SP 55.13330 (riser up to 200 mm, tread at least 250 mm).', 'mvweb-build-calc' ),
		'formula'     => 'tread = 620 − 2 × riser (comfort formula)',
		'legend'      => array(
			'tread' => __( 'recommended tread depth, cm', 'mvweb-build-calc' ),
			'riser' => __( 'riser height, cm', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended tread depth', 'mvweb-build-calc' ),
			'unit'     => __( 'cm', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'riser' => array(
				'type'     => 'number',
				'label'    => __( 'Riser height', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 14,
				'max'      => 20,
				'step'     => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$riser = max( 1.0, (float) ( $i['riser'] ?? 0 ) );

			// Comfort formula 2h + b = 62 cm.
			$tread = 62 - 2 * $riser;
			$tread = max( 25.0, min( 32.0, $tread ) );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: riser cm, 2: tread cm */
				__( 'For a riser of %1$s cm the comfortable tread is about %2$s cm.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $riser, 1 ),
				mvweb_bc_format_number( $tread, 1 )
			);

			$hints[] = sprintf(
				/* translators: %s: comfort value cm */
				__( 'Comfort formula 2·riser + tread = %s cm (target 60–64 cm).', 'mvweb-build-calc' ),
				mvweb_bc_format_number( 2 * $riser + $tread, 1 )
			);

			if ( $riser > 18 ) {
				$hints[] = __( 'A riser over 18 cm is steep for a home staircase — consider lowering it.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Ergonomic guide based on common practice and SP 55.13330 (riser up to 200 mm, tread at least 250 mm).', 'mvweb-build-calc' );

			return array(
				'value' => round( $tread, 1 ),
				'hints' => $hints,
			);
		},
	)
);
