<?php
/**
 * Calculator: timber volume for log/beam walls.
 *
 * Volume of profiled or glued timber for external walls = wall area × timber
 * thickness, plus a waste reserve, with the equivalent piece count for the
 * chosen cross-section and length. Geometric calculation.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'timber-volume',
	array(
		'title'       => __( 'Timber volume for walls', 'mvweb-build-calc' ),
		'hub'         => 'walls',
		'description' => __( 'Calculates the volume of profiled or glued timber for walls — wall area times the timber thickness, plus a waste reserve — with the equivalent number of pieces for the chosen cross-section and length. Geometric calculation.', 'mvweb-build-calc' ),
		'formula'     => 'volume = area × thickness × (1 + reserve%)',
		'legend'      => array(
			'volume'    => __( 'timber volume, m³', 'mvweb-build-calc' ),
			'area'      => __( 'wall area, m²', 'mvweb-build-calc' ),
			'thickness' => __( 'timber thickness, cm', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Timber volume', 'mvweb-build-calc' ),
			'unit'     => __( 'm³', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'area'      => array(
				'type'     => 'number',
				'label'    => __( 'Wall area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 2000,
				'step'     => 0.5,
				'required' => true,
			),
			'thickness' => array(
				'type'     => 'select',
				'label'    => __( 'Timber thickness', 'mvweb-build-calc' ),
				'default'  => '15',
				'required' => true,
				'options'  => array(
					'10' => __( '100 mm', 'mvweb-build-calc' ),
					'15' => __( '150 mm', 'mvweb-build-calc' ),
					'20' => __( '200 mm', 'mvweb-build-calc' ),
				),
			),
			'profile'   => array(
				'type'     => 'select',
				'label'    => __( 'Timber height (one course)', 'mvweb-build-calc' ),
				'default'  => '15',
				'required' => true,
				'options'  => array(
					'15' => __( '150 mm', 'mvweb-build-calc' ),
					'18' => __( '180 mm', 'mvweb-build-calc' ),
					'20' => __( '200 mm', 'mvweb-build-calc' ),
				),
			),
			'length'    => array(
				'type'     => 'number',
				'label'    => __( 'Piece length', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 12,
				'step'     => 0.5,
				'default'  => 6,
				'required' => true,
			),
			'reserve'   => array(
				'type'     => 'number',
				'label'    => __( 'Waste reserve', 'mvweb-build-calc' ),
				'unit'     => __( '%', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 15,
				'step'     => 1,
				'default'  => 7,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area      = max( 0.0, (float) ( $i['area'] ?? 0 ) );
			$thickness = (float) ( $i['thickness'] ?? 15 ) / 100; // cm → m.
			$profile   = (float) ( $i['profile'] ?? 15 ) / 100;   // cm → m.
			$length    = max( 0.1, (float) ( $i['length'] ?? 6 ) );
			$reserve   = max( 0.0, (float) ( $i['reserve'] ?? 0 ) );

			$volume = $area * $thickness * ( 1 + $reserve / 100 );

			// Equivalent piece count: one piece volume = thickness × profile × length.
			$piece_volume = $thickness * $profile * $length;
			$pieces       = $piece_volume > 0 ? (int) ceil( $volume / $piece_volume ) : 0;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: piece count, 2: piece length m */
				__( 'About %1$d pieces of %2$s m length.', 'mvweb-build-calc' ),
				$pieces,
				mvweb_bc_format_number( $length, 1 )
			);

			$hints[] = sprintf(
				/* translators: %s: reserve percent */
				__( 'Includes a %s%% waste reserve for cut-offs and corners.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $reserve, 0 )
			);

			$hints[] = __( 'Geometric estimate — timber is usually sold by volume (m³).', 'mvweb-build-calc' );

			return array(
				'value' => round( $volume, 2 ),
				'hints' => $hints,
			);
		},
	)
);
