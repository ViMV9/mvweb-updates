<?php
/**
 * Calculator: window-to-floor area ratio (daylight check).
 *
 * Compares the glazing area of a room against its floor area and rates the
 * ratio against the daylight norm for living rooms and kitchens
 * (SP 55.13330.2016: window-to-floor ratio between 1:8 and 1:5.5).
 *
 * Model:
 *   ratio = window_area / floor_area  →  expressed as 1 : (floor / window)
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'window-to-room-ratio',
	array(
		'title'       => __( 'Window-to-room ratio', 'mvweb-build-calc' ),
		'hub'         => 'openings',
		'description' => __( 'Checks the daylight ratio of a room — the glazing area against the floor area — and rates it against the norm for living rooms and kitchens (SP 55.13330.2016: a window-to-floor ratio between 1:8 and 1:5.5). This is a planning check, not a full daylight (KEO) calculation.', 'mvweb-build-calc' ),
		'formula'     => 'ratio = window_area / floor_area (norm 1/8 … 1/5.5)',
		'legend'      => array(
			'window_area' => __( 'total glazing area of the room, m²', 'mvweb-build-calc' ),
			'floor_area'  => __( 'room floor area, m²', 'mvweb-build-calc' ),
			'ratio'       => __( 'window-to-floor ratio', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Window-to-floor ratio', 'mvweb-build-calc' ),
			'unit'     => __( '%', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'window_area' => array(
				'type'     => 'number',
				'label'    => __( 'Glazing area of the room', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 0.1,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'floor_area'  => array(
				'type'     => 'number',
				'label'    => __( 'Room floor area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 300,
				'step'     => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$window = max( 0.01, (float) ( $i['window_area'] ?? 0 ) );
			$floor  = max( 0.01, (float) ( $i['floor_area'] ?? 0 ) );

			$ratio    = $window / $floor;         // e.g. 0.15.
			$percent  = $ratio * 100;             // e.g. 15 %.
			$one_over = $window > 0 ? $floor / $window : 0; // e.g. 6.7 → 1:6.7.

			// Norm band: 1/8 (0.125) … 1/5.5 (0.1818).
			$norm_min = 1 / 8;
			$norm_max = 1 / 5.5;

			$hints = array();

			if ( $one_over > 0 ) {
				$hints[] = sprintf(
					/* translators: %s: floor-to-window factor, i.e. the N in 1:N */
					__( 'Glazing-to-floor ratio is about 1:%s.', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $one_over, 1 )
				);
			}

			if ( $ratio < $norm_min ) {
				$hints[] = __( 'Below the daylight norm (1:8) — the room may be dim; consider larger or extra windows.', 'mvweb-build-calc' );
			} elseif ( $ratio > $norm_max ) {
				$hints[] = __( 'Above the usual band (1:5.5) — plenty of daylight, but watch summer overheating and winter heat loss.', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'Within the daylight norm for living rooms and kitchens (1:8 … 1:5.5).', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Norm per SP 55.13330.2016. A full daylight factor (KEO) calculation also accounts for orientation, obstructions and glazing type.', 'mvweb-build-calc' );

			return array(
				'value' => $percent,
				'hints' => $hints,
			);
		},
	)
);
