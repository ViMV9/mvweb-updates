<?php
/**
 * Calculator: rafter length.
 *
 * Length of one rafter from the horizontal run (half-span for a gable roof) and
 * the slope angle, plus the eaves overhang measured along the slope. Geometric
 * calculation.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'rafter-length',
	array(
		'title'       => __( 'Rafter length', 'mvweb-build-calc' ),
		'hub'         => 'roof',
		'description' => __( 'Calculates the length of one rafter from the horizontal run (the half-span for a gable roof) and the slope angle, plus the eaves overhang measured along the slope. Geometric calculation.', 'mvweb-build-calc' ),
		'formula'     => 'length = run / cos(angle) + overhang',
		'legend'      => array(
			'length'   => __( 'rafter length, m', 'mvweb-build-calc' ),
			'run'      => __( 'horizontal run (half-span), m', 'mvweb-build-calc' ),
			'angle'    => __( 'slope angle, degrees', 'mvweb-build-calc' ),
			'overhang' => __( 'eaves overhang along the slope, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Rafter length', 'mvweb-build-calc' ),
			'unit'     => __( 'm', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'run'      => array(
				'type'     => 'number',
				'label'    => __( 'Horizontal run (half-span)', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.5,
				'max'      => 30,
				'step'     => 0.1,
				'required' => true,
			),
			'angle'    => array(
				'type'     => 'number',
				'label'    => __( 'Slope angle', 'mvweb-build-calc' ),
				'unit'     => __( '°', 'mvweb-build-calc' ),
				'min'      => 5,
				'max'      => 70,
				'step'     => 1,
				'required' => true,
			),
			'overhang' => array(
				'type'     => 'number',
				'label'    => __( 'Eaves overhang along the slope', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 1.5,
				'step'     => 0.05,
				'default'  => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$run      = max( 0.0, (float) ( $i['run'] ?? 0 ) );
			$angle    = max( 0.0, min( 89.0, (float) ( $i['angle'] ?? 0 ) ) );
			$overhang = max( 0.0, (float) ( $i['overhang'] ?? 0 ) );

			$cos    = cos( deg2rad( $angle ) );
			$cos    = $cos > 0.01 ? $cos : 0.01;
			$slope  = $run / $cos;
			$length = $slope + $overhang;

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: rafter length without overhang m */
				__( 'Sloped length without overhang %s m.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $slope, 2 )
			);

			$hints[] = __( 'For a gable roof both rafters of a pair have this length; a single-slope roof has one per truss.', 'mvweb-build-calc' );

			$hints[] = __( 'Order timber a little longer to allow for the plumb and seat cuts.', 'mvweb-build-calc' );

			return array(
				'value' => round( $length, 2 ),
				'hints' => $hints,
			);
		},
	)
);
