<?php
/**
 * Calculator: number of radiator sections.
 *
 * Preliminary estimate. From the room area (heat demand at ~100 W/m²) and the
 * heat output of one section by radiator type, returns the number of sections,
 * rounded up.
 *
 * Model:
 *   heat     = area × 100 W/m² × height_factor
 *   sections = ceil(heat / section_output)
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'radiator-sections',
	array(
		'title'       => __( 'Radiator sections', 'mvweb-build-calc' ),
		'hub'         => 'engineering',
		'description' => __( 'Estimates the number of radiator sections for a room from its area (heat demand about 100 W per m², adjusted for ceiling height) and the heat output of one section by radiator type. Section outputs are nominal at ΔT 70°C; the real output drops at lower system temperatures. Preliminary estimate, not a heating design.', 'mvweb-build-calc' ),
		'formula'     => 'sections = ceil(area × 100 W × height_factor / section_output)',
		'legend'      => array(
			'area'           => __( 'room area, m²', 'mvweb-build-calc' ),
			'section_output' => __( 'heat output of one section, W (ΔT 70°C)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Sections needed', 'mvweb-build-calc' ),
			'unit'     => __( 'pcs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'area'   => array(
				'type'     => 'number',
				'label'    => __( 'Room area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 100,
				'step'     => 0.5,
				'required' => true,
			),
			'type'   => array(
				'type'       => 'select',
				'label'      => __( 'Radiator type', 'mvweb-build-calc' ),
				'default'    => 'bimetal',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'aluminium' => __( 'Aluminium (~180 W per section)', 'mvweb-build-calc' ),
					'bimetal'   => __( 'Bimetal (~170 W per section)', 'mvweb-build-calc' ),
					'cast_iron' => __( 'Cast iron (~140 W per section)', 'mvweb-build-calc' ),
				),
			),
			'height' => array(
				'type'     => 'number',
				'label'    => __( 'Ceiling height', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 2.7,
				'min'      => 2.4,
				'max'      => 4,
				'step'     => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area   = max( 1.0, (float) ( $i['area'] ?? 0 ) );
			$type   = (string) ( $i['type'] ?? 'bimetal' );
			$height = max( 2.0, (float) ( $i['height'] ?? 2.7 ) );

			$output = match ( $type ) {
				'aluminium' => 180.0,
				'cast_iron' => 140.0,
				default     => 170.0, // bimetal.
			};

			$height_factor = $height / 2.7;
			$heat          = $area * 100 * $height_factor; // watts.

			$sections = $output > 0 ? (int) ceil( $heat / $output ) : 0;
			$sections = max( 1, $sections );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: heat demand W, 2: section output W */
				__( 'Heat demand about %1$s W; one section ≈ %2$s W.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $heat, 0 ),
				mvweb_bc_format_number( $output, 0 )
			);

			$hints[] = __( 'Section outputs are nominal at ΔT 70°C. A low-temperature or condensing system delivers less per section — add 20–40%.', 'mvweb-build-calc' );

			$hints[] = __( 'A corner room or one with large glazing needs more; split long runs into two radiators under the windows.', 'mvweb-build-calc' );

			$hints[] = __( 'Preliminary estimate, not a heating design.', 'mvweb-build-calc' );

			return array(
				'value' => (float) $sections,
				'hints' => $hints,
			);
		},
	)
);
