<?php
/**
 * Calculator: septic tank volume.
 *
 * Preliminary estimate. The working volume of a septic tank should hold at
 * least three days of wastewater inflow; the inflow is the residents times the
 * daily water norm (most of which becomes wastewater).
 *
 * Model:
 *   daily  = people × per_person
 *   volume = daily × 3
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'septic-volume',
	array(
		'title'       => __( 'Septic tank volume', 'mvweb-build-calc' ),
		'hub'         => 'engineering',
		'description' => __( 'Estimates the required working volume of a septic tank — at least three days of wastewater inflow — from the number of residents and the daily water norm. Based on the three-day rule of SP 32.13330 / SanPiN; a preliminary estimate, not a treatment-system design.', 'mvweb-build-calc' ),
		'formula'     => 'volume = people × per_person × 3 days',
		'legend'      => array(
			'volume'     => __( 'working volume, m³', 'mvweb-build-calc' ),
			'people'     => __( 'number of residents', 'mvweb-build-calc' ),
			'per_person' => __( 'daily wastewater per person, litres', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Working volume', 'mvweb-build-calc' ),
			'unit'     => __( 'm³', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'people'     => array(
				'type'     => 'number',
				'label'    => __( 'Residents', 'mvweb-build-calc' ),
				'default'  => 4,
				'min'      => 1,
				'max'      => 20,
				'step'     => 1,
				'required' => true,
			),
			'per_person' => array(
				'type'     => 'number',
				'label'    => __( 'Daily wastewater per person', 'mvweb-build-calc' ),
				'unit'     => __( 'l', 'mvweb-build-calc' ),
				'default'  => 200,
				'min'      => 100,
				'max'      => 350,
				'step'     => 10,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$people     = max( 1, (int) ( $i['people'] ?? 1 ) );
			$per_person = max( 1.0, (float) ( $i['per_person'] ?? 200 ) );

			$daily  = $people * $per_person / 1000; // m³/day.
			$volume = $daily * 3;                    // three-day rule.

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: daily inflow m³ */
				__( 'Daily inflow about %s m³; the tank holds three days of it.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $daily, 2 )
			);

			$hints[] = __( 'The three-day retention lets solids settle and digest. A multi-chamber tank or an aeration station may use different sizing — follow the manufacturer.', 'mvweb-build-calc' );

			$hints[] = __( 'Keep the tank at least 5 m from the house and the sanitary distance from a well (SP 53.13330 / SanPiN). High groundwater needs a sealed tank.', 'mvweb-build-calc' );

			$hints[] = __( 'Preliminary estimate based on the three-day rule of SP 32.13330. It does not replace a treatment-system design.', 'mvweb-build-calc' );

			return array(
				'value' => $volume,
				'hints' => $hints,
			);
		},
	)
);
