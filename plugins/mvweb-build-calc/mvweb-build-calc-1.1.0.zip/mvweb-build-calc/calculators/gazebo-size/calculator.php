<?php
/**
 * Calculator: gazebo size.
 *
 * Ergonomic planning guide, not a code requirement. Sizes a gazebo from the
 * number of guests (~1.5 m² each at a table) plus an optional grill / barbecue
 * zone.
 *
 * Model:
 *   area = guests × 1.5 + grill_zone
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'gazebo-size',
	array(
		'title'       => __( 'Gazebo size', 'mvweb-build-calc' ),
		'hub'         => 'outbuildings',
		'description' => __( 'Estimates the recommended gazebo area from the number of guests it should seat at a table plus an optional grill or barbecue zone. This is an ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'A = guests × 1.5 + grill_zone',
		'legend'      => array(
			'A'          => __( 'recommended area, m²', 'mvweb-build-calc' ),
			'guests'     => __( 'people at the table (~1.5 m² each)', 'mvweb-build-calc' ),
			'grill_zone' => __( 'grill / barbecue zone, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'guests' => array(
				'type'     => 'number',
				'label'    => __( 'Guests', 'mvweb-build-calc' ),
				'default'  => 6,
				'min'      => 2,
				'max'      => 30,
				'step'     => 1,
				'required' => true,
			),
			'grill'  => array(
				'type'       => 'radio',
				'label'      => __( 'Grill / barbecue zone', 'mvweb-build-calc' ),
				'default'    => 'no',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'no'      => __( 'No grill', 'mvweb-build-calc' ),
					'grill'   => __( 'Portable grill (+2 m²)', 'mvweb-build-calc' ),
					'masonry' => __( 'Built-in barbecue (+4 m²)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$guests = max( 2, (int) ( $i['guests'] ?? 6 ) );
			$grill  = (string) ( $i['grill'] ?? 'no' );

			$grill_zone = match ( $grill ) {
				'grill'   => 2.0,
				'masonry' => 4.0,
				default   => 0.0,
			};

			$area = $guests * 1.5 + $grill_zone;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: guests count, 2: grill zone m² */
				__( '%1$d guests × 1.5 m² + grill zone %2$s m².', 'mvweb-build-calc' ),
				$guests,
				mvweb_bc_format_number( $grill_zone, 0 )
			);

			if ( 'masonry' === $grill ) {
				$hints[] = __( 'A built-in barbecue needs a non-combustible floor and a clear zone in front; keep an open gazebo well ventilated for the smoke.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'A square or hexagonal gazebo of about this area gives a comfortable layout around a central table.', 'mvweb-build-calc' );

			$hints[] = __( 'Ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
