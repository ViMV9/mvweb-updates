<?php
/**
 * Calculator: house energy-efficiency class.
 *
 * Estimate. Compares the building's specific heating energy use against a
 * normalised baseline and maps the deviation to an energy class A–G, returning
 * a 0–100 score. Based on the class bands of SP 50.13330 / the Ministry of
 * Construction order (deviation from the base level, %).
 *
 * Model:
 *   deviation = (actual − base) / base × 100
 *   class / score by deviation band
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'energy-efficiency',
	array(
		'title'       => __( 'Energy-efficiency class', 'mvweb-build-calc' ),
		'hub'         => 'heat',
		'description' => __( 'Estimates the energy-efficiency class (A–G) of a house from its specific heating energy use compared with a normalised baseline, and returns a 0–100 score. Based on the deviation bands of SP 50.13330 / the energy-class order. Preliminary estimate, not an official energy passport.', 'mvweb-build-calc' ),
		'formula'     => 'deviation = (actual − base) / base × 100% → class A…G',
		'legend'      => array(
			'actual' => __( 'specific heating energy use, kWh/(m²·year)', 'mvweb-build-calc' ),
			'base'   => __( 'normalised baseline for the type, kWh/(m²·year)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Efficiency score', 'mvweb-build-calc' ),
			'unit'     => __( '/ 100', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'actual' => array(
				'type'     => 'number',
				'label'    => __( 'Specific heating energy use', 'mvweb-build-calc' ),
				'unit'     => __( 'kWh/(m²·year)', 'mvweb-build-calc' ),
				'default'  => 90,
				'min'      => 10,
				'max'      => 400,
				'step'     => 1,
				'required' => true,
			),
			'base'   => array(
				'type'     => 'number',
				'label'    => __( 'Baseline for this house type', 'mvweb-build-calc' ),
				'unit'     => __( 'kWh/(m²·year)', 'mvweb-build-calc' ),
				'default'  => 120,
				'min'      => 30,
				'max'      => 400,
				'step'     => 1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$actual = max( 1.0, (float) ( $i['actual'] ?? 90 ) );
			$base   = max( 1.0, (float) ( $i['base'] ?? 120 ) );

			$deviation = ( $actual - $base ) / $base * 100; // negative = better than base.

			// Class bands by deviation from the base level (SP 50.13330 / energy-class order).
			if ( $deviation <= -60 ) {
				$class = 'A++';
				$score = 100;
			} elseif ( $deviation <= -50 ) {
				$class = 'A+';
				$score = 95;
			} elseif ( $deviation <= -40 ) {
				$class = 'A';
				$score = 88;
			} elseif ( $deviation <= -30 ) {
				$class = 'B+';
				$score = 80;
			} elseif ( $deviation <= -15 ) {
				$class = 'B';
				$score = 70;
			} elseif ( $deviation <= 5 ) {
				$class = 'C';
				$score = 55;
			} elseif ( $deviation <= 25 ) {
				$class = 'D';
				$score = 35;
			} elseif ( $deviation <= 50 ) {
				$class = 'E';
				$score = 20;
			} elseif ( $deviation <= 75 ) {
				$class = 'F';
				$score = 10;
			} else {
				$class = 'G';
				$score = 3;
			}

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: class letter, 2: deviation percent */
				__( 'Estimated class %1$s — %2$s%% relative to the baseline.', 'mvweb-build-calc' ),
				$class,
				mvweb_bc_format_number( $deviation, 0 )
			);

			$hints[] = __( 'Lower energy use than the baseline means a higher class. Classes A and above qualify a building as energy-efficient.', 'mvweb-build-calc' );

			$hints[] = __( 'The biggest gains come from better wall and roof insulation, triple glazing and heat-recovery ventilation.', 'mvweb-build-calc' );

			$hints[] = __( 'Preliminary estimate based on the deviation bands of SP 50.13330. It does not replace an official energy passport.', 'mvweb-build-calc' );

			return array(
				'value' => (float) $score,
				'hints' => $hints,
			);
		},
	)
);
