<?php
/**
 * Calculator: plot coverage percentage.
 *
 * Geometry plus a user-supplied limit. Coverage is the built-up area as a
 * share of the plot. The maximum allowed coverage is set by the local
 * development rules (PZZ) — usually 20–40% for IZHS — so it is an input with a
 * 30% default, and the result is compared against it.
 *
 * Model:
 *   coverage = built_area / lot_area × 100
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'lot-coverage-percent',
	array(
		'title'       => __( 'Plot coverage percentage', 'mvweb-build-calc' ),
		'hub'         => 'lot',
		'description' => __( 'Calculates the plot coverage — the built-up area as a share of the plot area — and compares it against the limit set by the local development rules (usually 20–40% for low-rise residential plots).', 'mvweb-build-calc' ),
		'formula'     => 'C = built / lot × 100',
		'legend'      => array(
			'C'     => __( 'plot coverage, %', 'mvweb-build-calc' ),
			'built' => __( 'total built-up area of all buildings, m²', 'mvweb-build-calc' ),
			'lot'   => __( 'plot area, m²', 'mvweb-build-calc' ),
			'limit' => __( 'maximum coverage set by the local development rules (PZZ), %', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Plot coverage', 'mvweb-build-calc' ),
			'unit'     => __( '%', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'lot_area'   => array(
				'type'     => 'number',
				'label'    => __( 'Plot area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'default'  => 600,
				'min'      => 1,
				'max'      => 100000,
				'step'     => 1,
				'required' => true,
			),
			'built_area' => array(
				'type'     => 'number',
				'label'    => __( 'Total built-up area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'default'  => 120,
				'min'      => 0,
				'max'      => 100000,
				'step'     => 1,
				'required' => true,
			),
			'limit_pct'  => array(
				'type'     => 'number',
				'label'    => __( 'Coverage limit (local rules)', 'mvweb-build-calc' ),
				'unit'     => __( '%', 'mvweb-build-calc' ),
				'default'  => 30,
				'min'      => 1,
				'max'      => 100,
				'step'     => 1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$lot   = max( 0.0, (float) ( $i['lot_area'] ?? 0 ) );
			$built = max( 0.0, (float) ( $i['built_area'] ?? 0 ) );
			$limit = max( 0.0, (float) ( $i['limit_pct'] ?? 30 ) );

			$coverage = $lot > 0 ? $built / $lot * 100 : 0.0;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: built area, 2: lot area, both in m² */
				__( '%1$s m² built of %2$s m² plot.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $built, 1 ),
				mvweb_bc_format_number( $lot, 1 )
			);

			if ( $coverage > $limit ) {
				$hints[] = sprintf(
					/* translators: %s: coverage limit in percent */
					__( 'Over the %s%% limit — reduce the built-up area or check the local development rules.', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $limit, 0 )
				);
			} else {
				$hints[] = sprintf(
					/* translators: %s: coverage limit in percent */
					__( 'Within the %s%% limit.', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $limit, 0 )
				);
			}

			$hints[] = __( 'The exact coverage limit is set by the local development rules (PZZ) and depends on the zone.', 'mvweb-build-calc' );

			return array(
				'value' => $coverage,
				'hints' => $hints,
			);
		},
	)
);
