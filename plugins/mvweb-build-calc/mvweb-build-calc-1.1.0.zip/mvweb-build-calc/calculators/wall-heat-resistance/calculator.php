<?php
/**
 * Calculator: wall heat-transfer resistance (layer build-up).
 *
 * Preliminary estimate. Sums the thermal resistance of up to three layers
 * (R = δ / λ) plus the internal and external surface resistances (≈ 0.16), and
 * compares the result against the required R for the region.
 *
 * Model:
 *   R = Σ(δ_i / λ_i) + 0.16
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'wall-heat-resistance',
	array(
		'title'       => __( 'Wall heat resistance', 'mvweb-build-calc' ),
		'hub'         => 'heat',
		'description' => __( 'Calculates the heat-transfer resistance of a multi-layer wall by summing each layer (thickness ÷ thermal conductivity) plus the surface resistances, and compares it with the required R for the region (SP 50.13330.2012 Table 3). Preliminary estimate, not a thermal design.', 'mvweb-build-calc' ),
		'formula'     => 'R = Σ(δ / λ) + 0.16',
		'legend'      => array(
			'R' => __( 'wall resistance, m²·°C/W', 'mvweb-build-calc' ),
			'δ' => __( 'layer thickness, m', 'mvweb-build-calc' ),
			'λ' => __( 'layer thermal conductivity, W/(m·°C)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Wall resistance', 'mvweb-build-calc' ),
			'unit'     => __( 'm²·°C/W', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'zone'       => array(
				'type'       => 'select',
				'label'      => __( 'Climate (degree-days, ГСОП)', 'mvweb-build-calc' ),
				'default'    => '6000',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'4000' => __( 'Mild (~4000)', 'mvweb-build-calc' ),
					'5000' => __( 'Moderate (~5000)', 'mvweb-build-calc' ),
					'6000' => __( 'Central (~6000): Moscow, Saint Petersburg', 'mvweb-build-calc' ),
					'7000' => __( 'Cold (~7000)', 'mvweb-build-calc' ),
					'9000' => __( 'Severe (~9000)', 'mvweb-build-calc' ),
				),
			),
			'layer1_mat' => array(
				'type'    => 'select',
				'label'   => __( 'Layer 1 — load-bearing', 'mvweb-build-calc' ),
				'default' => 'brick_hollow',
				'options' => array(
					'brick_solid'  => __( 'Solid brick (λ 0.81)', 'mvweb-build-calc' ),
					'brick_hollow' => __( 'Hollow brick (λ 0.50)', 'mvweb-build-calc' ),
					'aerated_d400' => __( 'Aerated concrete D400 (λ 0.117)', 'mvweb-build-calc' ),
					'aerated_d500' => __( 'Aerated concrete D500 (λ 0.147)', 'mvweb-build-calc' ),
					'timber'       => __( 'Timber (λ 0.18)', 'mvweb-build-calc' ),
					'concrete'     => __( 'Reinforced concrete (λ 2.04)', 'mvweb-build-calc' ),
				),
			),
			'layer1_cm'  => array(
				'type'     => 'number',
				'label'    => __( 'Layer 1 thickness', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'default'  => 38,
				'min'      => 0,
				'max'      => 100,
				'step'     => 1,
				'required' => true,
			),
			'layer2_mat' => array(
				'type'    => 'select',
				'label'   => __( 'Layer 2 — insulation', 'mvweb-build-calc' ),
				'default' => 'mineral_wool',
				'options' => array(
					'none'         => __( 'None', 'mvweb-build-calc' ),
					'mineral_wool' => __( 'Mineral wool (λ 0.040)', 'mvweb-build-calc' ),
					'eps'          => __( 'EPS foam (λ 0.039)', 'mvweb-build-calc' ),
					'xps'          => __( 'Extruded polystyrene (λ 0.032)', 'mvweb-build-calc' ),
					'pir'          => __( 'PIR board (λ 0.025)', 'mvweb-build-calc' ),
				),
			),
			'layer2_cm'  => array(
				'type'    => 'number',
				'label'   => __( 'Layer 2 thickness', 'mvweb-build-calc' ),
				'unit'    => __( 'cm', 'mvweb-build-calc' ),
				'default' => 10,
				'min'     => 0,
				'max'     => 50,
				'step'    => 0.5,
			),
			'layer3_mat' => array(
				'type'    => 'select',
				'label'   => __( 'Layer 3 — facing', 'mvweb-build-calc' ),
				'default' => 'none',
				'options' => array(
					'none'       => __( 'None', 'mvweb-build-calc' ),
					'brick_face' => __( 'Facing brick (λ 0.70)', 'mvweb-build-calc' ),
					'plaster'    => __( 'Plaster (λ 0.70)', 'mvweb-build-calc' ),
				),
			),
			'layer3_cm'  => array(
				'type'    => 'number',
				'label'   => __( 'Layer 3 thickness', 'mvweb-build-calc' ),
				'unit'    => __( 'cm', 'mvweb-build-calc' ),
				'default' => 0,
				'min'     => 0,
				'max'     => 30,
				'step'    => 0.5,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$gsop = (float) ( $i['zone'] ?? 6000 );

			$lambda = array(
				'brick_solid'  => 0.81,
				'brick_hollow' => 0.50,
				'aerated_d400' => 0.117,
				'aerated_d500' => 0.147,
				'timber'       => 0.18,
				'concrete'     => 2.04,
				'mineral_wool' => 0.040,
				'eps'          => 0.039,
				'xps'          => 0.032,
				'pir'          => 0.025,
				'brick_face'   => 0.70,
				'plaster'      => 0.70,
			);

			$layer_r = static function ( string $mat, float $cm ) use ( $lambda ): float {
				if ( 'none' === $mat || $cm <= 0 ) {
					return 0.0;
				}
				$l = $lambda[ $mat ] ?? 0.0;
				return $l > 0 ? ( $cm / 100 ) / $l : 0.0;
			};

			$r = 0.16; // internal + external surface resistances.
			$r += $layer_r( (string) ( $i['layer1_mat'] ?? 'none' ), (float) ( $i['layer1_cm'] ?? 0 ) );
			$r += $layer_r( (string) ( $i['layer2_mat'] ?? 'none' ), (float) ( $i['layer2_cm'] ?? 0 ) );
			$r += $layer_r( (string) ( $i['layer3_mat'] ?? 'none' ), (float) ( $i['layer3_cm'] ?? 0 ) );

			$r_req = 0.00035 * $gsop + 1.4;

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: required resistance */
				__( 'Required for this climate: %s m²·°C/W (walls).', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $r_req, 2 )
			);

			if ( $r >= $r_req ) {
				$hints[] = __( 'The wall meets the requirement (R ≥ R_required).', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'Below the requirement — add or thicken the insulation layer.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Includes surface resistances (≈ 0.16). Preliminary estimate per SP 50.13330; a full calculation uses the thermal-uniformity factor and the moisture zone.', 'mvweb-build-calc' );

			return array(
				'value' => $r,
				'hints' => $hints,
			);
		},
	)
);
