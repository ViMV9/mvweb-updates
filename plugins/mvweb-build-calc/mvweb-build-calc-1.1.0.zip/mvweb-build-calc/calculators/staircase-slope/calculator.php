<?php
/**
 * Calculator: staircase slope angle.
 *
 * Returns the flight slope in degrees from the riser and tread and rates it
 * against the comfortable range for dwellings (30–40°). Ergonomic guide based
 * on common practice and SP 55.13330; evacuation stairs ≤ 45° per SP 1.13130.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'staircase-slope',
	array(
		'title'       => __( 'Staircase slope', 'mvweb-build-calc' ),
		'hub'         => 'layout',
		'description' => __( 'Returns the slope angle of a staircase flight from the riser and tread and rates it against the comfortable range for dwellings (30–40°). Ergonomic guide based on common practice and SP 55.13330; evacuation stairs are limited to 45° by SP 1.13130.', 'mvweb-build-calc' ),
		'formula'     => 'slope = atan(riser / tread)',
		'legend'      => array(
			'slope' => __( 'flight slope, degrees', 'mvweb-build-calc' ),
			'riser' => __( 'riser height, cm', 'mvweb-build-calc' ),
			'tread' => __( 'tread depth, cm', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Slope angle', 'mvweb-build-calc' ),
			'unit'     => __( '°', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'riser' => array(
				'type'     => 'number',
				'label'    => __( 'Riser height', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 10,
				'max'      => 25,
				'step'     => 0.5,
				'required' => true,
			),
			'tread' => array(
				'type'     => 'number',
				'label'    => __( 'Tread depth', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 20,
				'max'      => 35,
				'step'     => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$riser = max( 0.1, (float) ( $i['riser'] ?? 0 ) );
			$tread = max( 0.1, (float) ( $i['tread'] ?? 0 ) );

			$slope = rad2deg( atan( $riser / $tread ) );

			$hints = array();

			if ( $slope >= 30 && $slope <= 40 ) {
				$hints[] = __( 'Comfortable slope for a dwelling (30–40°).', 'mvweb-build-calc' );
			} elseif ( $slope < 30 ) {
				$hints[] = __( 'Gentle slope — comfortable but takes more floor space.', 'mvweb-build-calc' );
			} elseif ( $slope <= 45 ) {
				$hints[] = __( 'Steep slope — acceptable but tiring; still within the 45° evacuation limit.', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'Too steep (over 45°) — not allowed for evacuation stairs; reduce the riser or increase the tread.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Ergonomic guide based on common practice and SP 55.13330; evacuation stairs are limited to 45° by SP 1.13130.', 'mvweb-build-calc' );

			return array(
				'value' => round( $slope, 1 ),
				'hints' => $hints,
			);
		},
	)
);
