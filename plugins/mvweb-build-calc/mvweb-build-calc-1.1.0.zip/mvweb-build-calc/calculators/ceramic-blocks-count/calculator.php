<?php
/**
 * Calculator: ceramic (porotherm) blocks count.
 *
 * Number of large-format porous ceramic blocks for a wall: wall area divided by
 * one block face area (length × height), plus a waste reserve. Block formats
 * follow common porous ceramic sizes (NF-rated).
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'ceramic-blocks-count',
	array(
		'title'       => __( 'Ceramic blocks count', 'mvweb-build-calc' ),
		'hub'         => 'walls',
		'description' => __( 'Calculates the number of large-format porous ceramic blocks for a wall from the wall area and the block face size (length × height), plus a waste reserve. Block formats follow common porous ceramic sizes.', 'mvweb-build-calc' ),
		'formula'     => 'blocks = area / (length × height) × (1 + reserve%)',
		'legend'      => array(
			'area' => __( 'wall area, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Blocks needed', 'mvweb-build-calc' ),
			'unit'     => __( 'pcs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'area'    => array(
				'type'     => 'number',
				'label'    => __( 'Wall area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 5000,
				'step'     => 0.5,
				'required' => true,
			),
			'block'   => array(
				'type'       => 'select',
				'label'      => __( 'Block format (length × height × width)', 'mvweb-build-calc' ),
				'default'    => '380x219x250',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'250x219x380' => __( '250 × 219 × 380 mm (laid lengthwise)', 'mvweb-build-calc' ),
					'380x219x250' => __( '380 × 219 × 250 mm (38 cm wall)', 'mvweb-build-calc' ),
					'440x219x250' => __( '440 × 219 × 250 mm (44 cm wall)', 'mvweb-build-calc' ),
					'510x219x250' => __( '510 × 219 × 250 mm (51 cm wall)', 'mvweb-build-calc' ),
				),
			),
			'reserve' => array(
				'type'     => 'number',
				'label'    => __( 'Waste reserve', 'mvweb-build-calc' ),
				'unit'     => __( '%', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 15,
				'step'     => 1,
				'default'  => 5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area    = max( 0.0, (float) ( $i['area'] ?? 0 ) );
			$reserve = max( 0.0, (float) ( $i['reserve'] ?? 0 ) );
			$block   = (string) ( $i['block'] ?? '380x219x250' );

			// Face area = length × height (mm → m), the surface seen on the wall.
			$face = match ( $block ) {
				'250x219x380' => 0.250 * 0.219,
				'440x219x250' => 0.440 * 0.219,
				'510x219x250' => 0.510 * 0.219,
				default       => 0.380 * 0.219,
			};

			$blocks = $face > 0 ? (int) ceil( $area / $face * ( 1 + $reserve / 100 ) ) : 0;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: blocks per m², 2: reserve percent */
				__( 'About %1$s blocks per m², including a %2$s%% reserve.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( 1 / $face, 1 ),
				mvweb_bc_format_number( $reserve, 0 )
			);

			$hints[] = __( 'Porous ceramic blocks have tongue-and-groove sides, so vertical joints carry no mortar.', 'mvweb-build-calc' );

			$hints[] = __( 'Geometric estimate — round up to whole pallets when ordering.', 'mvweb-build-calc' );

			return array(
				'value' => $blocks,
				'hints' => $hints,
			);
		},
	)
);
