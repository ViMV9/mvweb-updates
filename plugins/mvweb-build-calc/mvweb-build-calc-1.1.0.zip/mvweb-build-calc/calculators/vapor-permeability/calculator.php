<?php
/**
 * Calculator: vapour-permeability check of a wall.
 *
 * Estimate. Compares the vapour-diffusion resistance of the inner part of the
 * wall against the outer part (R_vp = δ / μ for each). A wall sheds moisture
 * outward when each layer toward the outside is more vapour-open than the one
 * before it; a vapour-tight outer layer over an open core traps moisture.
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'vapor-permeability',
	array(
		'title'       => __( 'Vapour permeability check', 'mvweb-build-calc' ),
		'hub'         => 'heat',
		'description' => __( 'Checks whether a two-layer wall sheds moisture to the outside by comparing the vapour-diffusion resistance of the inner (load-bearing) layer with the outer (facing / insulation) layer. The outer layer should be more vapour-open than the inner one. Preliminary estimate per SP 50.13330 section 8, not a full moisture calculation.', 'mvweb-build-calc' ),
		'formula'     => 'R_vp = δ / μ for each layer; outer R_vp should be lower than inner',
		'legend'      => array(
			'R_vp' => __( 'vapour-diffusion resistance, m²·h·Pa/mg', 'mvweb-build-calc' ),
			'δ'    => __( 'layer thickness, m', 'mvweb-build-calc' ),
			'μ'    => __( 'vapour permeability of the material, mg/(m·h·Pa)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Outer-to-inner vapour resistance', 'mvweb-build-calc' ),
			'unit'     => __( 'ratio', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'inner_mat' => array(
				'type'       => 'select',
				'label'      => __( 'Inner (load-bearing) layer', 'mvweb-build-calc' ),
				'default'    => 'aerated',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'aerated'  => __( 'Aerated concrete (μ 0.20)', 'mvweb-build-calc' ),
					'brick'    => __( 'Brick (μ 0.11)', 'mvweb-build-calc' ),
					'concrete' => __( 'Reinforced concrete (μ 0.03)', 'mvweb-build-calc' ),
					'timber'   => __( 'Timber (μ 0.06)', 'mvweb-build-calc' ),
				),
			),
			'inner_cm'  => array(
				'type'     => 'number',
				'label'    => __( 'Inner layer thickness', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'default'  => 30,
				'min'      => 1,
				'max'      => 100,
				'step'     => 1,
				'required' => true,
			),
			'outer_mat' => array(
				'type'       => 'select',
				'label'      => __( 'Outer (facing / insulation) layer', 'mvweb-build-calc' ),
				'default'    => 'mineral_wool',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'mineral_wool' => __( 'Mineral wool (μ 0.30, open)', 'mvweb-build-calc' ),
					'plaster'      => __( 'Vapour-open plaster (μ 0.12)', 'mvweb-build-calc' ),
					'eps'          => __( 'EPS foam (μ 0.05)', 'mvweb-build-calc' ),
					'xps'          => __( 'Extruded polystyrene (μ 0.005, tight)', 'mvweb-build-calc' ),
				),
			),
			'outer_cm'  => array(
				'type'     => 'number',
				'label'    => __( 'Outer layer thickness', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'default'  => 10,
				'min'      => 1,
				'max'      => 50,
				'step'     => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$mu = array(
				'aerated'      => 0.20,
				'brick'        => 0.11,
				'concrete'     => 0.03,
				'timber'       => 0.06,
				'mineral_wool' => 0.30,
				'plaster'      => 0.12,
				'eps'          => 0.05,
				'xps'          => 0.005,
			);

			$inner_mat = (string) ( $i['inner_mat'] ?? 'aerated' );
			$inner_cm  = max( 0.1, (float) ( $i['inner_cm'] ?? 30 ) );
			$outer_mat = (string) ( $i['outer_mat'] ?? 'mineral_wool' );
			$outer_cm  = max( 0.1, (float) ( $i['outer_cm'] ?? 10 ) );

			$mu_in  = $mu[ $inner_mat ] ?? 0.1;
			$mu_out = $mu[ $outer_mat ] ?? 0.1;

			$r_in  = $mu_in > 0 ? ( $inner_cm / 100 ) / $mu_in : 0.0;
			$r_out = $mu_out > 0 ? ( $outer_cm / 100 ) / $mu_out : 0.0;

			$ratio = $r_in > 0 ? $r_out / $r_in : 0.0;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: inner vapour resistance, 2: outer vapour resistance */
				__( 'Inner vapour resistance %1$s, outer %2$s (m²·h·Pa/mg).', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $r_in, 2 ),
				mvweb_bc_format_number( $r_out, 2 )
			);

			if ( $r_out <= $r_in ) {
				$hints[] = __( 'Good: the outer layer is more vapour-open than the inner one, so the wall dries outward.', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'Risk: the outer layer is more vapour-tight than the core — moisture can accumulate at the interface. Use a vapour-open facing or add an inner vapour barrier and a ventilated gap.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Rule of thumb: vapour resistance should fall from inside to outside. Preliminary estimate per SP 50.13330 §8; it does not replace a moisture calculation.', 'mvweb-build-calc' );

			return array(
				'value' => $ratio,
				'hints' => $hints,
			);
		},
	)
);
