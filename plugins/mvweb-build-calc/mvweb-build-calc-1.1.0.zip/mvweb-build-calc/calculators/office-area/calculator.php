<?php
/**
 * Calculator: home office area.
 *
 * Ergonomic planning guide, not a code requirement. Based on common design
 * practice: each workplace needs ~5 m² (desk, chair, clearance), with optional
 * allowances for bookshelves and a small meeting zone.
 *
 * Model:
 *   area = max(6, workplaces × 5) + bookshelves + meeting
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'office-area',
	array(
		'title'       => __( 'Home office area', 'mvweb-build-calc' ),
		'hub'         => 'rooms',
		'description' => __( 'Estimates the recommended home office area from the number of workplaces and optional bookshelves and meeting zone. This is an ergonomic planning guide based on common design practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'A = max(6, workplaces × 5) + bookshelves + meeting',
		'legend'      => array(
			'A'           => __( 'recommended area, m²', 'mvweb-build-calc' ),
			'workplaces'  => __( 'number of workplaces (~5 m² each, min office 6 m²)', 'mvweb-build-calc' ),
			'bookshelves' => __( 'allowance for bookshelves / storage (+2 m²)', 'mvweb-build-calc' ),
			'meeting'     => __( 'allowance for a small meeting zone (+4 m²)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'workplaces'  => array(
				'type'       => 'number',
				'label'      => __( 'Workplaces', 'mvweb-build-calc' ),
				'default'    => 1,
				'min'        => 1,
				'max'        => 10,
				'step'       => 1,
				'required'   => true,
				'full_width' => true,
			),
			'bookshelves' => array(
				'type'    => 'radio',
				'label'   => __( 'Bookshelves / storage', 'mvweb-build-calc' ),
				'default' => 'yes',
				'options' => array(
					'no'  => __( 'No', 'mvweb-build-calc' ),
					'yes' => __( 'Yes', 'mvweb-build-calc' ),
				),
			),
			'meeting'     => array(
				'type'    => 'radio',
				'label'   => __( 'Meeting zone', 'mvweb-build-calc' ),
				'default' => 'no',
				'options' => array(
					'no'  => __( 'No', 'mvweb-build-calc' ),
					'yes' => __( 'Yes', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$workplaces  = max( 1, (int) ( $i['workplaces'] ?? 1 ) );
			$bookshelves = 'yes' === (string) ( $i['bookshelves'] ?? 'no' );
			$meeting     = 'yes' === (string) ( $i['meeting'] ?? 'no' );

			$work_zone = max( 6.0, $workplaces * 5.0 );

			$extra = 0.0;
			if ( $bookshelves ) {
				$extra += 2.0;
			}
			if ( $meeting ) {
				$extra += 4.0;
			}

			$area = $work_zone + $extra;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: workplaces count, 2: work zone area in m² */
				__( '%1$d workplace(s) → work zone ≈ %2$s m² (≈ 5 m² each, office minimum 6 m²).', 'mvweb-build-calc' ),
				$workplaces,
				mvweb_bc_format_number( $work_zone, 1 )
			);

			$hints[] = __( 'This is an ergonomic planning guide based on common design practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
