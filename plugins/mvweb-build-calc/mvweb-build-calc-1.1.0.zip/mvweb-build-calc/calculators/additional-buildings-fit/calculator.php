<?php
/**
 * Calculator: do additional buildings fit the free plot area.
 *
 * Geometry plus setbacks. Each building needs its footprint plus a clearance
 * setback on every side (SP 53.13330.2019: outbuildings ≥ 1 m from a
 * boundary; the setback here is a per-building clearance, default 1 m). The
 * calculator checks whether the required area fits the free plot area.
 *
 * Model:
 *   needed = (w + 2s) × (l + 2s) × count
 *   remaining = free − needed
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'additional-buildings-fit',
	array(
		'title'       => __( 'Do additional buildings fit', 'mvweb-build-calc' ),
		'hub'         => 'lot',
		'description' => __( 'Checks whether additional buildings (garage, bathhouse, shed, gazebo) fit the free plot area, counting a clearance setback around each one. Returns the area left after placing them.', 'mvweb-build-calc' ),
		'formula'     => 'needed = (w + 2s)(l + 2s) × count;  remaining = free − needed',
		'legend'      => array(
			'free'      => __( 'free plot area available, m²', 'mvweb-build-calc' ),
			'w'         => __( 'building width, m', 'mvweb-build-calc' ),
			'l'         => __( 'building length, m', 'mvweb-build-calc' ),
			's'         => __( 'clearance setback around each building (≥ 1 m by SP 53.13330.2019)', 'mvweb-build-calc' ),
			'count'     => __( 'number of identical buildings', 'mvweb-build-calc' ),
			'remaining' => __( 'free area left after placing the buildings, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Area left', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'free_area'  => array(
				'type'     => 'number',
				'label'    => __( 'Free plot area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'default'  => 300,
				'min'      => 1,
				'max'      => 100000,
				'step'     => 1,
				'required' => true,
			),
			'building_w' => array(
				'type'     => 'number',
				'label'    => __( 'Building width', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 4,
				'min'      => 0.5,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'building_l' => array(
				'type'     => 'number',
				'label'    => __( 'Building length', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 6,
				'min'      => 0.5,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'count'      => array(
				'type'     => 'number',
				'label'    => __( 'Number of buildings', 'mvweb-build-calc' ),
				'default'  => 1,
				'min'      => 1,
				'max'      => 50,
				'step'     => 1,
				'required' => true,
			),
			'setback'    => array(
				'type'     => 'number',
				'label'    => __( 'Clearance around each', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 1,
				'min'      => 0,
				'max'      => 20,
				'step'     => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$free    = max( 0.0, (float) ( $i['free_area'] ?? 0 ) );
			$w       = max( 0.0, (float) ( $i['building_w'] ?? 0 ) );
			$l       = max( 0.0, (float) ( $i['building_l'] ?? 0 ) );
			$count   = max( 1, (int) ( $i['count'] ?? 1 ) );
			$setback = max( 0.0, (float) ( $i['setback'] ?? 1 ) );

			$per_building = ( $w + 2 * $setback ) * ( $l + 2 * $setback );
			$needed       = $per_building * $count;
			$remaining    = $free - $needed;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: number of buildings, 2: needed area in m² */
				__( '%1$d building(s) need %2$s m² including the clearance.', 'mvweb-build-calc' ),
				$count,
				mvweb_bc_format_number( $needed, 1 )
			);

			if ( $remaining >= 0 ) {
				$hints[] = __( 'They fit the free area.', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'They do not fit — reduce the size, the count or the clearance.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Outbuildings keep at least 1 m from the plot boundary (SP 53.13330.2019); this is a rough area check, not a layout plan.', 'mvweb-build-calc' );

			return array(
				'value' => $remaining,
				'hints' => $hints,
			);
		},
	)
);
