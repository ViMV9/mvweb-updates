<?php
/**
 * Calculator: roof slope angle.
 *
 * Slope angle of a pitched roof from the ridge height above the wall plate and
 * the horizontal run (half-span for a gable roof). Returns the angle and rates
 * it against the minimum slope for common roofing materials.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'roof-slope-angle',
	array(
		'title'       => __( 'Roof slope angle', 'mvweb-build-calc' ),
		'hub'         => 'roof',
		'description' => __( 'Calculates the slope angle of a pitched roof from the ridge rise above the wall plate and the horizontal run (the half-span for a gable roof), and rates it against the minimum slope for common roofing materials.', 'mvweb-build-calc' ),
		'formula'     => 'angle = atan(rise / run)',
		'legend'      => array(
			'angle' => __( 'roof slope, degrees', 'mvweb-build-calc' ),
			'rise'  => __( 'ridge rise above the wall plate, m', 'mvweb-build-calc' ),
			'run'   => __( 'horizontal run (half-span), m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Roof slope angle', 'mvweb-build-calc' ),
			'unit'     => __( '°', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'rise' => array(
				'type'     => 'number',
				'label'    => __( 'Ridge rise above the wall plate', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.1,
				'max'      => 20,
				'step'     => 0.1,
				'required' => true,
			),
			'run'  => array(
				'type'     => 'number',
				'label'    => __( 'Horizontal run (half-span)', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.5,
				'max'      => 30,
				'step'     => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$rise = max( 0.0, (float) ( $i['rise'] ?? 0 ) );
			$run  = max( 0.01, (float) ( $i['run'] ?? 0 ) );

			$angle = rad2deg( atan( $rise / $run ) );

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: slope as a percentage */
				__( 'Slope is also %s%% (rise over run).', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $rise / $run * 100, 0 )
			);

			if ( $angle < 12 ) {
				$hints[] = __( 'Below 12° most pitched-roof materials are not recommended; use a membrane or seam metal roof.', 'mvweb-build-calc' );
			} elseif ( $angle < 14 ) {
				$hints[] = __( 'Suitable for profiled sheeting (from 12°); metal tile needs at least 14°.', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'Suitable for metal tile (from 14°), soft tile (from 12°) and profiled sheeting.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Geometric calculation. Minimum slopes are the manufacturers\' common limits.', 'mvweb-build-calc' );

			return array(
				'value' => round( $angle, 1 ),
				'hints' => $hints,
			);
		},
	)
);
