<?php
/**
 * Calculator: recommended number of bathrooms by occupants and floors.
 *
 * Ergonomic planning guide, not a code requirement. Building codes do not
 * prescribe a bathroom count for single-family houses; the rule below follows
 * common residential design practice.
 *
 * Model:
 *   by_people = ceil(occupants / 4)            (one bathroom per ~4 people)
 *   bathrooms = max(by_people, floors) + guest (at least one per floor)
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'bathrooms-count',
	array(
		'title'       => __( 'Recommended number of bathrooms', 'mvweb-build-calc' ),
		'hub'         => 'rooms',
		'description' => __( 'Estimates the recommended number of bathrooms from the number of occupants and floors, with an optional guest toilet. This is an ergonomic planning guide based on common design practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'WC = max(⌈occupants / 4⌉, floors) + guest',
		'legend'      => array(
			'WC'        => __( 'recommended number of bathrooms', 'mvweb-build-calc' ),
			'occupants' => __( 'number of permanent occupants', 'mvweb-build-calc' ),
			'floors'    => __( 'number of floors (at least one bathroom per floor)', 'mvweb-build-calc' ),
			'guest'     => __( 'optional guest toilet on the ground floor (+1)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Bathrooms', 'mvweb-build-calc' ),
			'unit'     => __( 'pcs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'occupants' => array(
				'type'     => 'number',
				'label'    => __( 'Occupants', 'mvweb-build-calc' ),
				'default'  => 4,
				'min'      => 1,
				'max'      => 30,
				'step'     => 1,
				'required' => true,
			),
			'floors'    => array(
				'type'     => 'number',
				'label'    => __( 'Floors', 'mvweb-build-calc' ),
				'default'  => 2,
				'min'      => 1,
				'max'      => 5,
				'step'     => 1,
				'required' => true,
			),
			'guest_wc'  => array(
				'type'    => 'radio',
				'label'   => __( 'Guest toilet', 'mvweb-build-calc' ),
				'default' => 'yes',
				'options' => array(
					'no'  => __( 'No', 'mvweb-build-calc' ),
					'yes' => __( 'Yes', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$occupants = max( 1, (int) ( $i['occupants'] ?? 4 ) );
			$floors    = max( 1, (int) ( $i['floors'] ?? 1 ) );
			$guest     = 'yes' === (string) ( $i['guest_wc'] ?? 'no' );

			$by_people = (int) ceil( $occupants / 4 );

			// At least one bathroom per floor.
			$full = max( $by_people, $floors );

			$bathrooms = $full + ( $guest ? 1 : 0 );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: full bathrooms, 2: guest part */
				__( '%1$d full bathroom(s)%2$s — one per ~4 people, at least one per floor.', 'mvweb-build-calc' ),
				$full,
				$guest ? __( ' + 1 guest toilet', 'mvweb-build-calc' ) : ''
			);

			if ( $floors >= 2 ) {
				$hints[] = __( 'Place at least one bathroom on each living floor so the upper floor does not depend on the ground one.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'This is an ergonomic planning guide, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => (float) $bathrooms,
				'hints' => $hints,
			);
		},
	)
);
