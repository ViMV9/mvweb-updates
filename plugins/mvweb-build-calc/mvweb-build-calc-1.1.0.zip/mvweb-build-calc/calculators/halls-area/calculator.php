<?php
/**
 * Calculator: hallways and circulation area.
 *
 * Estimates the area taken by hallways, the entrance hall and landings as a
 * share of the total floor area, adjusted by the layout compactness. Planning
 * guide based on common practice.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'halls-area',
	array(
		'title'       => __( 'Hallways and circulation area', 'mvweb-build-calc' ),
		'hub'         => 'layout',
		'description' => __( 'Estimates the area taken by hallways, the entrance hall and landings as a share of the total floor area, adjusted by how compact the layout is. Planning guide based on common practice.', 'mvweb-build-calc' ),
		'formula'     => 'halls = total × share(layout)',
		'legend'      => array(
			'halls' => __( 'circulation area, m²', 'mvweb-build-calc' ),
			'total' => __( 'total floor area, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Circulation area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'total'  => array(
				'type'     => 'number',
				'label'    => __( 'Total floor area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 20,
				'max'      => 2000,
				'step'     => 0.5,
				'required' => true,
			),
			'layout' => array(
				'type'       => 'select',
				'label'      => __( 'Layout compactness', 'mvweb-build-calc' ),
				'default'    => 'average',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'compact' => __( 'Compact (open plan, few corridors) — about 8%', 'mvweb-build-calc' ),
					'average' => __( 'Average — about 12%', 'mvweb-build-calc' ),
					'complex' => __( 'Complex (many rooms, long corridors) — about 16%', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$total  = max( 1.0, (float) ( $i['total'] ?? 0 ) );
			$layout = (string) ( $i['layout'] ?? 'average' );

			$share = match ( $layout ) {
				'compact' => 0.08,
				'complex' => 0.16,
				default   => 0.12,
			};

			$halls = $total * $share;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: share percent, 2: total area m² */
				__( 'About %1$s%% of %2$s m² goes to hallways and landings.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $share * 100, 0 ),
				mvweb_bc_format_number( $total, 1 )
			);

			$hints[] = __( 'An open plan keeps circulation low; many separate rooms and long corridors raise it.', 'mvweb-build-calc' );

			$hints[] = __( 'Planning estimate based on common practice — the exact share depends on the final layout.', 'mvweb-build-calc' );

			return array(
				'value' => round( $halls, 1 ),
				'hints' => $hints,
			);
		},
	)
);
