<?php
/**
 * Calculator: underfloor heating loop length and count.
 *
 * Preliminary estimate. From the heated floor area and the pipe spacing, the
 * pipe run is area / spacing plus the lead to the manifold; the number of
 * loops is set by a maximum loop length for the chosen pipe diameter.
 *
 * Model:
 *   run   = area / spacing + 2 × lead
 *   loops = ceil(run / max_loop(diameter))
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'underfloor-heating-loops',
	array(
		'title'       => __( 'Underfloor heating loops', 'mvweb-build-calc' ),
		'hub'         => 'engineering',
		'description' => __( 'Estimates the total pipe length and the number of loops for a water underfloor heating system from the heated floor area, the pipe spacing and the pipe diameter (which sets the maximum loop length). Preliminary estimate, not a hydraulic design.', 'mvweb-build-calc' ),
		'formula'     => 'run = area / spacing + lead; loops = ceil(run / max_loop)',
		'legend'      => array(
			'run'      => __( 'total pipe length, m', 'mvweb-build-calc' ),
			'spacing'  => __( 'pipe spacing, m', 'mvweb-build-calc' ),
			'max_loop' => __( 'maximum length of one loop by diameter, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Total pipe length', 'mvweb-build-calc' ),
			'unit'     => __( 'm', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'area'     => array(
				'type'     => 'number',
				'label'    => __( 'Heated floor area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 200,
				'step'     => 0.5,
				'required' => true,
			),
			'spacing'  => array(
				'type'       => 'select',
				'label'      => __( 'Pipe spacing', 'mvweb-build-calc' ),
				'default'    => '15',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'10' => __( '10 cm (high output / edge zones)', 'mvweb-build-calc' ),
					'15' => __( '15 cm (standard)', 'mvweb-build-calc' ),
					'20' => __( '20 cm (low output / well-insulated)', 'mvweb-build-calc' ),
				),
			),
			'diameter' => array(
				'type'       => 'select',
				'label'      => __( 'Pipe diameter', 'mvweb-build-calc' ),
				'default'    => '16',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'16' => __( '⌀16 mm (max loop ~90 m)', 'mvweb-build-calc' ),
					'20' => __( '⌀20 mm (max loop ~120 m)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area     = max( 1.0, (float) ( $i['area'] ?? 0 ) );
			$spacing  = (float) ( $i['spacing'] ?? 15 ) / 100; // metres.
			$diameter = (string) ( $i['diameter'] ?? '16' );

			$max_loop = ( '20' === $diameter ) ? 120.0 : 90.0;
			$lead     = 4.0; // supply + return lead to the manifold, m.

			$pipe_in_floor = $spacing > 0 ? $area / $spacing : 0.0;
			$run           = $pipe_in_floor + $lead;

			$loops = $max_loop > 0 ? (int) ceil( $run / $max_loop ) : 1;
			$loops = max( 1, $loops );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: loops count, 2: max loop length m */
				__( '%1$d loop(s); keep each loop under about %2$s m to limit the pressure drop.', 'mvweb-build-calc' ),
				$loops,
				mvweb_bc_format_number( $max_loop, 0 )
			);

			$hints[] = sprintf(
				/* translators: %s: pipe per m² */
				__( 'About %s m of pipe per m² at this spacing, plus the lead to the manifold.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $spacing > 0 ? 1 / $spacing : 0, 1 )
			);

			$hints[] = __( 'Keep the loops of one manifold close in length so they balance. A spacing of 10 cm near outer walls boosts the edge output.', 'mvweb-build-calc' );

			$hints[] = __( 'Preliminary estimate, not a hydraulic design.', 'mvweb-build-calc' );

			return array(
				'value' => $run,
				'hints' => $hints,
			);
		},
	)
);
