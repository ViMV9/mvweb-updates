<?php
/**
 * Calculator: attic vs full second floor suitability.
 *
 * Scores how well an attic (mansard) fits compared with a full second floor
 * (0–100), from budget priority, how much usable upper area is needed and the
 * desire for full-height rooms. Recommendation, not a code requirement.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'attic-or-full-second-floor',
	array(
		'title'       => __( 'Attic or full second floor', 'mvweb-build-calc' ),
		'hub'         => 'layout',
		'description' => __( 'Scores how well an attic (mansard) fits compared with a full second floor from budget priority, how much usable upper area you need and the wish for full-height rooms, and names the recommended option. This is a design recommendation based on common practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'score = fit(budget, usable area need, full height wish)',
		'legend'      => array(
			'score' => __( 'suitability of an attic, 0–100', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Attic suitability', 'mvweb-build-calc' ),
			'unit'     => __( '/ 100', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'priority'   => array(
				'type'       => 'select',
				'label'      => __( 'Main priority', 'mvweb-build-calc' ),
				'default'    => 'budget',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'budget'  => __( 'Lower construction cost', 'mvweb-build-calc' ),
					'area'    => __( 'Maximum usable upper area', 'mvweb-build-calc' ),
					'balance' => __( 'Balanced', 'mvweb-build-calc' ),
				),
			),
			'full_rooms' => array(
				'type'       => 'radio',
				'label'      => __( 'Want full-height rooms upstairs', 'mvweb-build-calc' ),
				'default'    => 'no',
				'full_width' => true,
				'options'    => array(
					'no'  => __( 'No — sloped ceilings are fine', 'mvweb-build-calc' ),
					'yes' => __( 'Yes — full-height walls everywhere', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$priority = (string) ( $i['priority'] ?? 'budget' );
			$full     = (string) ( $i['full_rooms'] ?? 'no' );

			$score = 50;

			$score += match ( $priority ) {
				'budget' => 25,   // attic is cheaper (uses the roof volume).
				'area'   => -25,  // full floor gives more usable area.
				default  => 0,
			};

			if ( 'yes' === $full ) {
				$score -= 35; // full-height rooms favour a full second floor.
			} else {
				$score += 15;
			}

			$score = max( 0, min( 100, $score ) );

			$hints = array();

			if ( $score >= 60 ) {
				$hints[] = __( 'An attic fits well: it reuses the roof volume and costs less, with cosy sloped ceilings.', 'mvweb-build-calc' );
			} elseif ( $score <= 40 ) {
				$hints[] = __( 'A full second floor fits better: more usable area and full-height rooms throughout.', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'Both options are reasonable — weigh cost against usable area and ceiling comfort.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'An attic loses floor area to the roof slope; a knee wall of 1.1–1.5 m recovers much of it.', 'mvweb-build-calc' );

			$hints[] = __( 'Design recommendation based on common practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => (float) $score,
				'hints' => $hints,
			);
		},
	)
);
