<?php
/**
 * Calculator: maximum house dimensions allowed by plot setbacks.
 *
 * Code-based. The house must keep minimum setbacks from the plot boundaries:
 *   - SP 30-102-99 (low-rise residential, IZHS): house ≥ 3 m from a boundary.
 *   - SP 53.13330.2019 (garden / SNT plots): dwelling ≥ 3 m from a boundary.
 * The street-facing setback is often larger (red line), commonly 5 m, so it is
 * a separate input with a 5 m default.
 *
 * Model:
 *   max_width  = lot_width  − 2 × setback_side
 *   max_length = lot_length − setback_front − setback_back
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'house-max-dimensions',
	array(
		'title'       => __( 'Maximum house dimensions for the plot', 'mvweb-build-calc' ),
		'hub'         => 'lot',
		'description' => __( 'Calculates the maximum house footprint that fits the plot once the required boundary setbacks are subtracted. Setbacks follow SP 30-102-99 (IZHS) and SP 53.13330.2019 (garden plots): a house must stand at least 3 m from a boundary; the street-facing setback is usually larger.', 'mvweb-build-calc' ),
		'formula'     => 'Wmax = Wlot − 2 × s_side;  Lmax = Llot − s_front − s_back',
		'legend'      => array(
			'Wmax'    => __( 'maximum house width, m', 'mvweb-build-calc' ),
			'Lmax'    => __( 'maximum house length, m', 'mvweb-build-calc' ),
			's_side'  => __( 'side setback (≥ 3 m by SP 30-102-99 / SP 53.13330)', 'mvweb-build-calc' ),
			's_front' => __( 'street-facing setback (red line, often 5 m)', 'mvweb-build-calc' ),
			's_back'  => __( 'rear setback (≥ 3 m)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Maximum footprint', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'lot_width'     => array(
				'type'     => 'number',
				'label'    => __( 'Plot width', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 20,
				'min'      => 1,
				'max'      => 500,
				'step'     => 0.1,
				'required' => true,
			),
			'lot_length'    => array(
				'type'     => 'number',
				'label'    => __( 'Plot length', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 30,
				'min'      => 1,
				'max'      => 500,
				'step'     => 0.1,
				'required' => true,
			),
			'setback_side'  => array(
				'type'     => 'number',
				'label'    => __( 'Side setback', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 3,
				'min'      => 0,
				'max'      => 50,
				'step'     => 0.1,
				'required' => true,
			),
			'setback_front' => array(
				'type'     => 'number',
				'label'    => __( 'Street-facing setback', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 5,
				'min'      => 0,
				'max'      => 50,
				'step'     => 0.1,
				'required' => true,
			),
			'setback_back'  => array(
				'type'     => 'number',
				'label'    => __( 'Rear setback', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 3,
				'min'      => 0,
				'max'      => 50,
				'step'     => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$lot_w   = max( 0.0, (float) ( $i['lot_width'] ?? 0 ) );
			$lot_l   = max( 0.0, (float) ( $i['lot_length'] ?? 0 ) );
			$s_side  = max( 0.0, (float) ( $i['setback_side'] ?? 3 ) );
			$s_front = max( 0.0, (float) ( $i['setback_front'] ?? 5 ) );
			$s_back  = max( 0.0, (float) ( $i['setback_back'] ?? 3 ) );

			$max_w = max( 0.0, $lot_w - 2 * $s_side );
			$max_l = max( 0.0, $lot_l - $s_front - $s_back );
			$area  = $max_w * $max_l;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: max width, 2: max length, both in m */
				__( 'Maximum house size: %1$s × %2$s m.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $max_w, 1 ),
				mvweb_bc_format_number( $max_l, 1 )
			);

			if ( $s_side < 3.0 ) {
				$hints[] = __( 'Side setback below 3 m is under the SP 30-102-99 / SP 53.13330 minimum for a house — check the local rules.', 'mvweb-build-calc' );
			}

			if ( 0.0 === $max_w || 0.0 === $max_l ) {
				$hints[] = __( 'The setbacks leave no buildable area — reduce them or check the plot size.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Setbacks are measured to the projecting parts of the house. The street-facing distance is set by the red line in the local development plan.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
