<?php
/**
 * Calculator: windowsill mounting height.
 *
 * Ergonomic guide. Returns the recommended sill height above the finished
 * floor by room type, and the resulting window head height for a given window
 * height (to check it against the ceiling).
 *
 * Model:
 *   head = sill + window_height
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'windowsill-height',
	array(
		'title'       => __( 'Windowsill height', 'mvweb-build-calc' ),
		'hub'         => 'openings',
		'description' => __( 'Recommends the windowsill height above the finished floor by room type and checks the resulting window head height against a window of the chosen height. Ergonomic guide based on common practice.', 'mvweb-build-calc' ),
		'formula'     => 'head = sill + window_height',
		'legend'      => array(
			'sill'   => __( 'recommended sill height above the floor, cm', 'mvweb-build-calc' ),
			'head'   => __( 'top of the window above the floor, cm', 'mvweb-build-calc' ),
			'window' => __( 'window height, cm', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended sill height', 'mvweb-build-calc' ),
			'unit'     => __( 'cm', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'room'          => array(
				'type'       => 'select',
				'label'      => __( 'Room type', 'mvweb-build-calc' ),
				'default'    => 'living',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'living'  => __( 'Living room / bedroom (~80 cm)', 'mvweb-build-calc' ),
					'kitchen' => __( 'Kitchen — above the worktop (~90 cm)', 'mvweb-build-calc' ),
					'bath'    => __( 'Bathroom (~120 cm, privacy)', 'mvweb-build-calc' ),
					'panoram' => __( 'Panoramic / floor window (~10 cm)', 'mvweb-build-calc' ),
				),
			),
			'window_height' => array(
				'type'     => 'number',
				'label'    => __( 'Window height', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'default'  => 140,
				'min'      => 30,
				'max'      => 300,
				'step'     => 5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$room   = (string) ( $i['room'] ?? 'living' );
			$window = max( 1.0, (float) ( $i['window_height'] ?? 140 ) );

			$sill = match ( $room ) {
				'kitchen' => 90.0,
				'bath'    => 120.0,
				'panoram' => 10.0,
				default   => 80.0, // living / bedroom.
			};

			$head = $sill + $window;

			$hints = array();

			$hints[] = sprintf(
				/* translators: %d: window head height above the floor, cm */
				__( 'The top of the window sits about %d cm above the floor.', 'mvweb-build-calc' ),
				(int) round( $head )
			);

			$hints[] = __( 'Leave at least 25–30 cm from the window head to the ceiling for the lintel and the curtain rail.', 'mvweb-build-calc' );

			if ( 'kitchen' === $room ) {
				$hints[] = __( 'A kitchen sill is set above the worktop (≈ 85–90 cm); a higher sill clears a tall backsplash or appliances.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Ergonomic guide based on common practice, not a binding requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $sill,
				'hints' => $hints,
			);
		},
	)
);
