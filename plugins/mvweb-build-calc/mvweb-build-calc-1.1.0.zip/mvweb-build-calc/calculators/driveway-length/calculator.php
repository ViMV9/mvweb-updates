<?php
/**
 * Calculator: driveway paving area.
 *
 * Geometry. The paved area of the driveway from the gate to the garage or
 * house, with hints on the recommended width (one car vs. passing) and the
 * turning radius.
 *
 * Model:
 *   area = distance × width
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'driveway-length',
	array(
		'title'       => __( 'Driveway paving area', 'mvweb-build-calc' ),
		'hub'         => 'lot',
		'description' => __( 'Calculates the paved area of the driveway from the gate to the garage or house, and gives the recommended width for one car or for passing.', 'mvweb-build-calc' ),
		'formula'     => 'A = distance × width',
		'legend'      => array(
			'A'        => __( 'paved area, m²', 'mvweb-build-calc' ),
			'distance' => __( 'driveway length from the gate to the garage / parking, m', 'mvweb-build-calc' ),
			'width'    => __( 'driveway width, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Paving area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'distance' => array(
				'type'     => 'number',
				'label'    => __( 'Driveway length', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 12,
				'min'      => 1,
				'max'      => 500,
				'step'     => 0.1,
				'required' => true,
			),
			'width'    => array(
				'type'     => 'number',
				'label'    => __( 'Driveway width', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 3,
				'min'      => 1,
				'max'      => 20,
				'step'     => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$distance = max( 0.0, (float) ( $i['distance'] ?? 0 ) );
			$width    = max( 0.0, (float) ( $i['width'] ?? 0 ) );

			$area = $distance * $width;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: length, 2: width, both in m */
				__( '%1$s m long × %2$s m wide.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $distance, 1 ),
				mvweb_bc_format_number( $width, 1 )
			);

			if ( $width < 3.0 ) {
				$hints[] = __( 'A single-car driveway is usually at least 3 m wide.', 'mvweb-build-calc' );
			} elseif ( $width < 5.0 ) {
				$hints[] = __( 'Recommended width: 3 m for one car, 5–5.5 m to let two cars pass.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Allow a turning radius of about 6–7 m where the driveway meets the parking or garage.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
