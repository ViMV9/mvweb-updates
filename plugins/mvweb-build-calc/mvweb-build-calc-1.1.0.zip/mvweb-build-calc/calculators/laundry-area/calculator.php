<?php
/**
 * Calculator: laundry room area.
 *
 * Ergonomic planning guide, not a code requirement. The area is the sum of
 * functional zones for the chosen set of appliances plus a clear passage, with
 * an optional storage allowance.
 *
 * Model:
 *   area = equipment_zone(set) + storage
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'laundry-area',
	array(
		'title'       => __( 'Laundry room area', 'mvweb-build-calc' ),
		'hub'         => 'rooms',
		'description' => __( 'Estimates the recommended laundry room area from the set of appliances and an optional storage zone. This is an ergonomic planning guide based on common design practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'A = equipment_zone + storage',
		'legend'      => array(
			'A'              => __( 'recommended area, m²', 'mvweb-build-calc' ),
			'equipment_zone' => __( 'zone for the chosen appliance set, including a clear passage', 'mvweb-build-calc' ),
			'storage'        => __( 'optional storage / linen cabinet (+1.5 m²)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'equipment' => array(
				'type'       => 'select',
				'label'      => __( 'Appliances', 'mvweb-build-calc' ),
				'default'    => 'washer_dryer',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'washer'            => __( 'Washing machine only', 'mvweb-build-calc' ),
					'washer_dryer'      => __( 'Washer + dryer', 'mvweb-build-calc' ),
					'washer_dryer_sink' => __( 'Washer + dryer + sink', 'mvweb-build-calc' ),
					'full'              => __( 'Washer + dryer + sink + ironing zone', 'mvweb-build-calc' ),
				),
			),
			'storage'   => array(
				'type'    => 'radio',
				'label'   => __( 'Storage cabinet', 'mvweb-build-calc' ),
				'default' => 'yes',
				'options' => array(
					'no'  => __( 'No', 'mvweb-build-calc' ),
					'yes' => __( 'Yes', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$set     = (string) ( $i['equipment'] ?? 'washer_dryer' );
			$storage = 'yes' === (string) ( $i['storage'] ?? 'no' );

			$equipment_zone = match ( $set ) {
				'washer'            => 2.0,
				'washer_dryer_sink' => 4.5,
				'full'              => 6.0,
				default             => 3.5, // washer + dryer.
			};

			$area = $equipment_zone + ( $storage ? 1.5 : 0.0 );

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: equipment zone area, 2: storage part */
				__( 'Equipment zone ≈ %1$s m²%2$s, including a clear passage.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $equipment_zone, 1 ),
				$storage ? __( ' + 1.5 m² storage', 'mvweb-build-calc' ) : ''
			);

			$hints[] = __( 'This is an ergonomic planning guide based on common design practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
