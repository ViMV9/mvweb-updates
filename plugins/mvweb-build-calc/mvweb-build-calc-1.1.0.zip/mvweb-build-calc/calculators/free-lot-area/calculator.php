<?php
/**
 * Calculator: free plot area left for the garden.
 *
 * Geometry. Subtracts the footprints of the house, outbuildings and the
 * driveway / paths from the plot area to get the free area available for the
 * garden, lawn and recreation.
 *
 * Model:
 *   free = lot − house − outbuildings − driveway
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'free-lot-area',
	array(
		'title'       => __( 'Free plot area', 'mvweb-build-calc' ),
		'hub'         => 'lot',
		'description' => __( 'Calculates the free plot area left for the garden, lawn and recreation after subtracting the house, outbuildings and the driveway and paths.', 'mvweb-build-calc' ),
		'formula'     => 'Free = lot − house − outbuildings − driveway',
		'legend'      => array(
			'Free'         => __( 'free area for garden and recreation, m²', 'mvweb-build-calc' ),
			'lot'          => __( 'plot area, m²', 'mvweb-build-calc' ),
			'house'        => __( 'house footprint, m²', 'mvweb-build-calc' ),
			'outbuildings' => __( 'footprint of outbuildings (garage, bathhouse, shed), m²', 'mvweb-build-calc' ),
			'driveway'     => __( 'driveway and paths area, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Free area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'lot_area'          => array(
				'type'     => 'number',
				'label'    => __( 'Plot area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'default'  => 600,
				'min'      => 1,
				'max'      => 100000,
				'step'     => 1,
				'required' => true,
			),
			'house_area'        => array(
				'type'     => 'number',
				'label'    => __( 'House footprint', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'default'  => 120,
				'min'      => 0,
				'max'      => 100000,
				'step'     => 1,
				'required' => true,
			),
			'outbuildings_area' => array(
				'type'    => 'number',
				'label'   => __( 'Outbuildings footprint', 'mvweb-build-calc' ),
				'unit'    => __( 'm²', 'mvweb-build-calc' ),
				'default' => 40,
				'min'     => 0,
				'max'     => 100000,
				'step'    => 1,
			),
			'driveway_area'     => array(
				'type'    => 'number',
				'label'   => __( 'Driveway and paths', 'mvweb-build-calc' ),
				'unit'    => __( 'm²', 'mvweb-build-calc' ),
				'default' => 60,
				'min'     => 0,
				'max'     => 100000,
				'step'    => 1,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$lot     = max( 0.0, (float) ( $i['lot_area'] ?? 0 ) );
			$house   = max( 0.0, (float) ( $i['house_area'] ?? 0 ) );
			$outb    = max( 0.0, (float) ( $i['outbuildings_area'] ?? 0 ) );
			$drive   = max( 0.0, (float) ( $i['driveway_area'] ?? 0 ) );

			$occupied = $house + $outb + $drive;
			$free     = max( 0.0, $lot - $occupied );
			$share    = $lot > 0 ? $free / $lot * 100 : 0.0;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: occupied area in m², 2: free share in percent */
				__( 'Occupied %1$s m². Free area is %2$s%% of the plot.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $occupied, 1 ),
				mvweb_bc_format_number( $share, 0 )
			);

			if ( $occupied > $lot ) {
				$hints[] = __( 'Buildings and paths exceed the plot area — check the inputs.', 'mvweb-build-calc' );
			}

			return array(
				'value' => $free,
				'hints' => $hints,
			);
		},
	)
);
