<?php
/**
 * Calculator: panoramic glazing area and wall share.
 *
 * Geometric calculation. From the wall width and height and the glazed
 * portion, returns the panoramic glazing area and what share of the wall it
 * covers, with a thermal note for large glazed areas.
 *
 * Model:
 *   glazing = wall_w × glazing_h
 *   share   = glazing / (wall_w × wall_h)
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'panoramic-glazing',
	array(
		'title'       => __( 'Panoramic glazing', 'mvweb-build-calc' ),
		'hub'         => 'openings',
		'description' => __( 'Calculates the area of panoramic (floor-to-ceiling) glazing across a wall and what share of the wall it covers. Geometric calculation with a thermal note for large glazed areas.', 'mvweb-build-calc' ),
		'formula'     => 'glazing = wall_w × glazing_h; share = glazing / (wall_w × wall_h)',
		'legend'      => array(
			'wall_w'    => __( 'wall width, m', 'mvweb-build-calc' ),
			'wall_h'    => __( 'wall (floor-to-ceiling) height, m', 'mvweb-build-calc' ),
			'glazing_h' => __( 'glazed height, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Glazing area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'wall_w'    => array(
				'type'     => 'number',
				'label'    => __( 'Wall width', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.5,
				'max'      => 30,
				'step'     => 0.1,
				'required' => true,
			),
			'wall_h'    => array(
				'type'     => 'number',
				'label'    => __( 'Wall height (floor to ceiling)', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 2.7,
				'min'      => 2,
				'max'      => 6,
				'step'     => 0.1,
				'required' => true,
			),
			'glazing_h' => array(
				'type'     => 'number',
				'label'    => __( 'Glazed height', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 2.4,
				'min'      => 0.5,
				'max'      => 6,
				'step'     => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$wall_w    = max( 0.01, (float) ( $i['wall_w'] ?? 0 ) );
			$wall_h    = max( 0.01, (float) ( $i['wall_h'] ?? 0 ) );
			$glazing_h = max( 0.01, (float) ( $i['glazing_h'] ?? 0 ) );

			$glazing_h = min( $glazing_h, $wall_h );

			$glazing   = $wall_w * $glazing_h;
			$wall_area = $wall_w * $wall_h;
			$share     = $wall_area > 0 ? ( $glazing / $wall_area ) * 100 : 0.0;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: glazing area m², 2: share percent */
				__( '%1$s m² of glazing — about %2$s%% of the wall.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $glazing, 2 ),
				mvweb_bc_format_number( $share, 0 )
			);

			if ( $share >= 50 ) {
				$hints[] = __( 'Large glazed areas lose much more heat than a wall — use double or triple low-emissivity glazing and a warm-edge spacer, and plan summer shading.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Floor-to-ceiling glazing often needs tempered or laminated safety glass; check the structural support of the opening.', 'mvweb-build-calc' );

			return array(
				'value' => $glazing,
				'hints' => $hints,
			);
		},
	)
);
