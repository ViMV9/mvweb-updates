<?php
/**
 * Calculator: tensile reinforcement for a singly-reinforced RC beam.
 *
 * Estimate, not a design calculation. Computes the bending moment of a simply
 * supported beam under a uniform load and the required tensile reinforcement
 * area As with a simplified lever arm (ζ ≈ 0.9), then suggests a bar count.
 * Returns a moment-diagram payload.
 *
 * Sources (verified against official texts):
 *   - Rs: A400 350 MPa, A500 435 MPa — SP 63.13330.2018 tab. 6.14.
 *   - Rb (informational): B20 11.5 MPa, B25 14.5 MPa — SP 63 tab. 6.8.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'rc-beam',
	array(
		'title'       => __( 'Reinforced concrete beam', 'mvweb-build-calc' ),
		'hub'         => 'structures',
		'description' => __( 'Estimates the required tensile reinforcement area for a singly-reinforced rectangular RC beam under a uniform load and suggests a bar count. This is a preliminary estimate based on SP 63.13330; a full RC design (compression zone, reinforcement ratio, shear, cracking) must be done by a qualified engineer.', 'mvweb-build-calc' ),
		'formula'     => 'As = M / (Rs × ζ × h0), M = q × L² / 8, h0 = h − a',
		'legend'      => array(
			'As' => __( 'required tensile reinforcement area, cm²', 'mvweb-build-calc' ),
			'M'  => __( 'bending moment, kN·m', 'mvweb-build-calc' ),
			'Rs' => __( 'design tensile resistance of reinforcement, MPa', 'mvweb-build-calc' ),
			'h0' => __( 'effective depth h − a, cm', 'mvweb-build-calc' ),
			'ζ'  => __( 'lever arm coefficient (≈ 0.9, simplified)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Required reinforcement area', 'mvweb-build-calc' ),
			'unit'     => __( 'cm²', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'rebar_class'  => array(
				'type'       => 'select',
				'label'      => __( 'Reinforcement class', 'mvweb-build-calc' ),
				'default'    => 'a400',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'a400' => __( 'A400 (Rs = 350 MPa)', 'mvweb-build-calc' ),
					'a500' => __( 'A500 (Rs = 435 MPa)', 'mvweb-build-calc' ),
				),
			),
			'bar_diameter' => array(
				'type'     => 'select',
				'label'    => __( 'Bar diameter for the count', 'mvweb-build-calc' ),
				'default'  => '12',
				'required' => true,
				'options'  => array(
					'10' => __( '⌀10', 'mvweb-build-calc' ),
					'12' => __( '⌀12', 'mvweb-build-calc' ),
					'14' => __( '⌀14', 'mvweb-build-calc' ),
					'16' => __( '⌀16', 'mvweb-build-calc' ),
					'20' => __( '⌀20', 'mvweb-build-calc' ),
					'25' => __( '⌀25', 'mvweb-build-calc' ),
				),
			),
			'load'         => array(
				'type'     => 'number',
				'label'    => __( 'Uniform load q', 'mvweb-build-calc' ),
				'unit'     => __( 'kN/m', 'mvweb-build-calc' ),
				'min'      => 0.1,
				'max'      => 1000,
				'step'     => 0.1,
				'required' => true,
			),
			'span'         => array(
				'type'     => 'number',
				'label'    => __( 'Span L', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.5,
				'max'      => 24,
				'step'     => 0.1,
				'required' => true,
			),
			'width'        => array(
				'type'     => 'number',
				'label'    => __( 'Section width b', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 10,
				'max'      => 200,
				'step'     => 1,
				'required' => true,
			),
			'height'       => array(
				'type'     => 'number',
				'label'    => __( 'Section height h', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 10,
				'max'      => 200,
				'step'     => 1,
				'required' => true,
			),
			'cover'        => array(
				'type'     => 'number',
				'label'    => __( 'Reinforcement axis distance a', 'mvweb-build-calc' ),
				'unit'     => __( 'cm', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 10,
				'step'     => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$class    = (string) ( $i['rebar_class'] ?? 'a400' );
			$diameter = (string) ( $i['bar_diameter'] ?? '12' );
			$q        = max( 0.0, (float) ( $i['load'] ?? 0 ) );
			$span     = max( 0.01, (float) ( $i['span'] ?? 0 ) );
			$b        = max( 1.0, (float) ( $i['width'] ?? 0 ) );
			$h        = max( 1.0, (float) ( $i['height'] ?? 0 ) );
			$a        = max( 0.0, (float) ( $i['cover'] ?? 0 ) );

			$rs = ( 'a500' === $class ) ? 435.0 : 350.0;

			// Single-bar cross-section areas, cm².
			$bar_areas = array(
				'10' => 0.785,
				'12' => 1.131,
				'14' => 1.539,
				'16' => 2.011,
				'20' => 3.142,
				'25' => 4.909,
			);
			$bar_area = $bar_areas[ $diameter ] ?? 1.131;

			// Bending moment, kN·m.
			$moment = $q * $span * $span / 8;

			// Effective depth, mm. Guard against a ≥ h (physically invalid input).
			$h0_invalid = ( $h - $a ) < 1.0;
			$h0_cm      = max( 1.0, $h - $a );
			$h0_mm      = $h0_cm * 10;

			$lever = 0.9;

			// As, mm² → cm². M·10^6 N·mm / (Rs N/mm² · ζ · h0 mm).
			$as_mm = ( $moment * 1e6 ) / ( $rs * $lever * $h0_mm );
			$as_cm = $as_mm / 100;

			$bars = $bar_area > 0 ? (int) ceil( $as_cm / $bar_area ) : 0;
			$bars = max( 2, $bars );

			$hints = array();

			if ( $h0_invalid ) {
				$hints[] = __( 'The axis distance a is greater than or equal to the section height h — the effective depth is invalid. Reduce a or increase h; the result below is not meaningful.', 'mvweb-build-calc' );
			}

			$hints[] = sprintf(
				/* translators: 1: bending moment kN·m, 2: effective depth cm, 3: Rs MPa */
				__( 'Moment M = %1$s kN·m, effective depth h0 = %2$s cm, Rs = %3$s MPa.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $moment, 1 ),
				mvweb_bc_format_number( $h0_cm, 1 ),
				mvweb_bc_format_number( $rs, 0 )
			);

			$hints[] = sprintf(
				/* translators: 1: bar count, 2: bar diameter mm, 3: provided area cm² */
				__( 'Suggested reinforcement: %1$d bars ⌀%2$s (%3$s cm²).', 'mvweb-build-calc' ),
				$bars,
				$diameter,
				mvweb_bc_format_number( $bars * $bar_area, 2 )
			);

			$hints[] = __( 'Simplified single-reinforcement estimate with a fixed lever arm (ζ ≈ 0.9). It does not check the compression zone height, minimum/maximum reinforcement ratio, shear, cracking or anchorage.', 'mvweb-build-calc' );

			$hints[] = __( 'Preliminary estimate only. It does not replace a structural design by a qualified engineer.', 'mvweb-build-calc' );

			// Moment-diagram ordinates, normalised to [0..1] — parabolic, UDL.
			$curve  = array();
			$points = 24;
			for ( $k = 0; $k <= $points; $k++ ) {
				$x       = $k / $points;
				$curve[] = round( 4 * $x * ( 1 - $x ), 4 );
			}

			return array(
				'value'   => round( $as_cm, 2 ),
				'hints'   => $hints,
				'diagram' => array(
					'support' => 'simple',
					'load'    => 'udl',
					'plot'    => 'moment',
					'curve'   => $curve,
					'peak'    => sprintf(
						/* translators: %s: bending moment kN·m */
						__( 'Bending moment diagram, M_max = %s kN·m', 'mvweb-build-calc' ),
						mvweb_bc_format_number( $moment, 1 )
					),
				),
			);
		},
	)
);
