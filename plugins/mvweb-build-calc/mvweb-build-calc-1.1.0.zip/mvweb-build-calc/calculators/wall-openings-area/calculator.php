<?php
/**
 * Calculator: total openings area in a wall.
 *
 * Geometric calculation. Sums the area of the windows and doors in a wall and,
 * if the wall size is given, reports what share of the wall the openings take —
 * the figure subtracted from gross wall area in masonry and finishing take-offs.
 *
 * Model:
 *   openings = windows × win_area + doors × door_area
 *   share    = openings / (wall_w × wall_h)
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'wall-openings-area',
	array(
		'title'       => __( 'Wall openings area', 'mvweb-build-calc' ),
		'hub'         => 'openings',
		'description' => __( 'Sums the area of the windows and doors in a wall and, with the wall size, reports the openings as a share of the wall — the area subtracted from the gross wall in masonry and finishing take-offs. Geometric calculation.', 'mvweb-build-calc' ),
		'formula'     => 'openings = windows × win_area + doors × door_area',
		'legend'      => array(
			'windows'   => __( 'number of windows', 'mvweb-build-calc' ),
			'win_area'  => __( 'one window area, m²', 'mvweb-build-calc' ),
			'doors'     => __( 'number of doors', 'mvweb-build-calc' ),
			'door_area' => __( 'one door area, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Total openings area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'windows'   => array(
				'type'     => 'number',
				'label'    => __( 'Number of windows', 'mvweb-build-calc' ),
				'default'  => 2,
				'min'      => 0,
				'max'      => 100,
				'step'     => 1,
				'required' => true,
			),
			'win_area'  => array(
				'type'     => 'number',
				'label'    => __( 'One window area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'default'  => 1.8,
				'min'      => 0.1,
				'max'      => 30,
				'step'     => 0.1,
				'required' => true,
			),
			'doors'     => array(
				'type'     => 'number',
				'label'    => __( 'Number of doors', 'mvweb-build-calc' ),
				'default'  => 1,
				'min'      => 0,
				'max'      => 50,
				'step'     => 1,
				'required' => true,
			),
			'door_area' => array(
				'type'     => 'number',
				'label'    => __( 'One door area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'default'  => 1.89,
				'min'      => 0.1,
				'max'      => 30,
				'step'     => 0.1,
				'required' => true,
			),
			'wall_area' => array(
				'type'    => 'number',
				'label'   => __( 'Gross wall area (optional, for the share)', 'mvweb-build-calc' ),
				'unit'    => __( 'm²', 'mvweb-build-calc' ),
				'default' => 0,
				'min'     => 0,
				'max'     => 1000,
				'step'    => 0.5,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$windows   = max( 0, (int) ( $i['windows'] ?? 0 ) );
			$win_area  = max( 0.0, (float) ( $i['win_area'] ?? 0 ) );
			$doors     = max( 0, (int) ( $i['doors'] ?? 0 ) );
			$door_area = max( 0.0, (float) ( $i['door_area'] ?? 0 ) );
			$wall      = max( 0.0, (float) ( $i['wall_area'] ?? 0 ) );

			$openings = $windows * $win_area + $doors * $door_area;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: windows total m², 2: doors total m² */
				__( 'Windows %1$s m² + doors %2$s m².', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $windows * $win_area, 2 ),
				mvweb_bc_format_number( $doors * $door_area, 2 )
			);

			if ( $wall > 0 ) {
				$share = ( $openings / $wall ) * 100;
				$net   = max( 0.0, $wall - $openings );
				$hints[] = sprintf(
					/* translators: 1: share percent, 2: net wall area m² */
					__( 'Openings are %1$s%% of the wall; net wall after openings %2$s m².', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $share, 0 ),
					mvweb_bc_format_number( $net, 2 )
				);
			}

			$hints[] = __( 'A standard internal door opening is about 0.9 × 2.1 m (1.89 m²). Use this total to subtract openings from the gross wall area.', 'mvweb-build-calc' );

			return array(
				'value' => $openings,
				'hints' => $hints,
			);
		},
	)
);
