<?php
/**
 * Calculator: roof membranes area.
 *
 * Membrane area for a pitched roof: the roof area times an overlap factor, for
 * one or both layers (vapour barrier under the insulation and a waterproofing /
 * windproofing membrane above it). Geometric calculation.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'roof-membranes',
	array(
		'title'       => __( 'Roof membranes area', 'mvweb-build-calc' ),
		'hub'         => 'roof',
		'description' => __( 'Calculates the membrane area for a pitched roof — the roof area times an overlap factor — for one or both layers: the vapour barrier under the insulation and the waterproofing/windproofing membrane above it. Overlaps are at least 10–15 cm.', 'mvweb-build-calc' ),
		'formula'     => 'area = roof area × overlap factor × layers',
		'legend'      => array(
			'area' => __( 'membrane area, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Membrane area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'area'   => array(
				'type'     => 'number',
				'label'    => __( 'Roof area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 5000,
				'step'     => 0.5,
				'required' => true,
			),
			'layers' => array(
				'type'       => 'select',
				'label'      => __( 'Which layers', 'mvweb-build-calc' ),
				'default'    => 'both',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'water'  => __( 'Waterproofing / windproofing only', 'mvweb-build-calc' ),
					'vapour' => __( 'Vapour barrier only', 'mvweb-build-calc' ),
					'both'   => __( 'Both layers', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area   = max( 0.0, (float) ( $i['area'] ?? 0 ) );
			$layers = (string) ( $i['layers'] ?? 'both' );

			$count = ( 'both' === $layers ) ? 2 : 1;

			// Overlap factor: ~12% extra for 10–15 cm laps and edges.
			$overlap = 1.12;
			$membrane = $area * $overlap * $count;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: layers count, 2: overlap percent */
				__( '%1$d layer(s), including about %2$s%% for overlaps and edges.', 'mvweb-build-calc' ),
				$count,
				mvweb_bc_format_number( ( $overlap - 1 ) * 100, 0 )
			);

			$hints[] = __( 'Overlaps are at least 10–15 cm; at low slopes increase them and tape the seams.', 'mvweb-build-calc' );

			$hints[] = __( 'Geometric estimate — divide by the roll area to get the number of rolls.', 'mvweb-build-calc' );

			return array(
				'value' => round( $membrane, 1 ),
				'hints' => $hints,
			);
		},
	)
);
