<?php
/**
 * Calculator: boiler room (heat generator room) area and window.
 *
 * Code-based. SP 402.1325800.2018 §5.5: a room for a gas heat generator with
 * an open combustion chamber must have a volume of at least 15 m³ at a clear
 * height of at least 2.5 m. Natural lighting is required at 0.03 m² of glazing
 * per 1 m³ of room volume (SP 62.13330 / SNiP 42-01-2002 practice).
 *
 * Gas boilers with a sealed (turbo) combustion chamber up to 60 kW may be
 * placed in a kitchen meeting general requirements — no dedicated 15 m³ room
 * is mandated. Electric and (with reservations) solid-fuel boilers are not
 * covered by the gas norm; the result then reflects ergonomic practice only.
 *
 * Output is the recommended floor area at the given ceiling height
 * (area = required_volume / height), plus the required window area in hints.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'boiler-room-area',
	array(
		'title'       => __( 'Boiler room area', 'mvweb-build-calc' ),
		'hub'         => 'rooms',
		'description' => __( 'Calculates the recommended boiler room (heat generator room) area and the required window. For a gas boiler with an open combustion chamber, SP 402.1325800.2018 §5.5 requires a volume of at least 15 m³ at a height of at least 2.5 m, with natural lighting of 0.03 m² of glazing per 1 m³.', 'mvweb-build-calc' ),
		'formula'     => 'A = V / H;   window = 0.03 × V',
		'legend'      => array(
			'A'      => __( 'recommended floor area, m²', 'mvweb-build-calc' ),
			'V'      => __( 'required room volume — 15 m³ for an open-chamber gas boiler (SP 402.1325800.2018)', 'mvweb-build-calc' ),
			'H'      => __( 'clear ceiling height (at least 2.5 m for a gas boiler)', 'mvweb-build-calc' ),
			'window' => __( 'required glazing area — 0.03 m² per 1 m³ of volume', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'boiler_type' => array(
				'type'     => 'select',
				'label'    => __( 'Boiler type', 'mvweb-build-calc' ),
				'default'  => 'gas_open',
				'required' => true,
				'options'  => array(
					'gas_open'   => __( 'Gas, open combustion chamber', 'mvweb-build-calc' ),
					'gas_sealed' => __( 'Gas, sealed (turbo) chamber', 'mvweb-build-calc' ),
					'solid'      => __( 'Solid fuel', 'mvweb-build-calc' ),
					'electric'   => __( 'Electric', 'mvweb-build-calc' ),
				),
			),
			'height'      => array(
				'type'     => 'number',
				'label'    => __( 'Ceiling height, m', 'mvweb-build-calc' ),
				'default'  => 2.5,
				'min'      => 2.0,
				'max'      => 4.0,
				'step'     => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$type   = (string) ( $i['boiler_type'] ?? 'gas_open' );
			$height = max( 2.0, (float) ( $i['height'] ?? 2.5 ) );

			// Required volume and minimum height by boiler type.
			// gas_open follows SP 402.1325800.2018 §5.5 (15 m³, 2.5 m).
			$required_volume = match ( $type ) {
				'gas_open' => 15.0,
				'solid'    => 8.0,  // ergonomic practice for a solid-fuel room.
				default    => 6.0,  // gas sealed / electric — ergonomic minimum.
			};
			$min_height = 'gas_open' === $type ? 2.5 : 2.2;

			$eff_height = max( $height, $min_height );
			$area       = $required_volume / $eff_height;
			$window     = 0.03 * $required_volume;

			$hints = array();

			if ( $height < $min_height ) {
				$hints[] = sprintf(
					/* translators: %s: minimum height in m */
					__( 'Ceiling height must be at least %s m — the calculation uses this minimum.', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $min_height, 1 )
				);
			}

			if ( 'gas_open' === $type ) {
				$hints[] = sprintf(
					/* translators: %s: window area in m² */
					__( 'SP 402.1325800.2018 §5.5: volume ≥ 15 m³, height ≥ 2.5 m. Required window ≈ %s m² (0.03 m² per 1 m³).', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $window, 2 )
				);
			} elseif ( 'gas_sealed' === $type ) {
				$hints[] = __( 'A sealed-chamber gas boiler up to 60 kW may be placed in a kitchen meeting general requirements — a dedicated 15 m³ room is not mandatory. The area shown is an ergonomic minimum.', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'Electric and solid-fuel boilers are not covered by the gas room norm. The area shown is an ergonomic minimum, not a code requirement.', 'mvweb-build-calc' );
			}

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
