<?php
/**
 * Calculator: recommended ceiling height by room type.
 *
 * Returns a recommended ceiling height for the chosen space, starting from the
 * SP 55.13330.2016 minimums (living rooms and kitchens ≥ 2.5 m, hallways and
 * attic rooms ≥ 2.3 m) and adding a comfort allowance for larger rooms.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'ceiling-height',
	array(
		'title'       => __( 'Ceiling height by room type', 'mvweb-build-calc' ),
		'hub'         => 'layout',
		'description' => __( 'Recommends a ceiling height for the chosen space, starting from the SP 55.13330.2016 minimums (living rooms and kitchens 2.5 m, hallways and attic rooms 2.3 m) and adding a comfort allowance for larger rooms.', 'mvweb-build-calc' ),
		'formula'     => 'height = code minimum + comfort allowance by area',
		'legend'      => array(
			'height' => __( 'recommended ceiling height, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended ceiling height', 'mvweb-build-calc' ),
			'unit'     => __( 'm', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'room' => array(
				'type'       => 'select',
				'label'      => __( 'Room type', 'mvweb-build-calc' ),
				'default'    => 'living',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'living'  => __( 'Living room / kitchen (min 2.5 m)', 'mvweb-build-calc' ),
					'hallway' => __( 'Hallway / corridor (min 2.1 m)', 'mvweb-build-calc' ),
					'attic'   => __( 'Attic room (min 2.3 m)', 'mvweb-build-calc' ),
				),
			),
			'area' => array(
				'type'     => 'number',
				'label'    => __( 'Room area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 200,
				'step'     => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$room = (string) ( $i['room'] ?? 'living' );
			$area = max( 1.0, (float) ( $i['area'] ?? 0 ) );

			$min = match ( $room ) {
				'hallway' => 2.1,
				'attic'   => 2.3,
				default   => 2.5,
			};

			// Comfort allowance: larger living rooms feel better a bit taller.
			$allowance = 0.0;
			if ( 'living' === $room ) {
				if ( $area > 30 ) {
					$allowance = 0.5;
				} elseif ( $area > 18 ) {
					$allowance = 0.2;
				}
			}

			$height = $min + $allowance;

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: code minimum m */
				__( 'Code minimum for this space is %s m (SP 55.13330.2016).', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $min, 1 )
			);

			if ( $allowance > 0 ) {
				$hints[] = sprintf(
					/* translators: %s: allowance m */
					__( 'A comfort allowance of +%s m is added for a room of this size.', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $allowance, 1 )
				);
			}

			$hints[] = __( 'For an attic the minimum applies over at least half of the floor area; sloped parts may be lower.', 'mvweb-build-calc' );

			$hints[] = __( 'Recommendation: code minimums from SP 55.13330.2016 plus a comfort allowance. Not a binding requirement above the minimum.', 'mvweb-build-calc' );

			return array(
				'value' => round( $height, 2 ),
				'hints' => $hints,
			);
		},
	)
);
