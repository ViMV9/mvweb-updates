<?php
/**
 * Calculator: door opening size.
 *
 * Geometric calculation. From the door leaf size, returns the rough wall
 * opening to leave for the frame — leaf plus frame thickness and the mounting
 * gap on each side and the head.
 *
 * Model:
 *   opening_w = leaf_w + 2 × (frame + gap)
 *   opening_h = leaf_h + (frame + gap) + threshold_gap
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'door-opening-size',
	array(
		'title'       => __( 'Door opening size', 'mvweb-build-calc' ),
		'hub'         => 'openings',
		'description' => __( 'Calculates the rough wall opening to leave for a door — the leaf plus the frame thickness and the mounting gap on the sides and the head. Returns the opening width and height. Geometric calculation based on common practice and GOST 6629 leaf sizes.', 'mvweb-build-calc' ),
		'formula'     => 'opening_w = leaf_w + 2 × (frame + gap); opening_h = leaf_h + frame + gap + floor_gap',
		'legend'      => array(
			'leaf_w' => __( 'door leaf width, mm', 'mvweb-build-calc' ),
			'leaf_h' => __( 'door leaf height, mm', 'mvweb-build-calc' ),
			'frame'  => __( 'frame profile thickness, mm', 'mvweb-build-calc' ),
			'gap'    => __( 'mounting gap, mm', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Rough opening width', 'mvweb-build-calc' ),
			'unit'     => __( 'mm', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'leaf'  => array(
				'type'       => 'select',
				'label'      => __( 'Door leaf (standard)', 'mvweb-build-calc' ),
				'default'    => '800',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'600' => __( '600 × 2000 mm (bathroom)', 'mvweb-build-calc' ),
					'700' => __( '700 × 2000 mm (room)', 'mvweb-build-calc' ),
					'800' => __( '800 × 2000 mm (room / standard)', 'mvweb-build-calc' ),
					'900' => __( '900 × 2000 mm (wide / entrance)', 'mvweb-build-calc' ),
				),
			),
			'frame' => array(
				'type'    => 'select',
				'label'   => __( 'Frame profile thickness (each side)', 'mvweb-build-calc' ),
				'default' => '30',
				'options' => array(
					'25' => __( '25 mm (thin)', 'mvweb-build-calc' ),
					'30' => __( '30 mm (standard)', 'mvweb-build-calc' ),
					'40' => __( '40 mm (with casing)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$leaf_w = (float) ( $i['leaf'] ?? 800 );
			$frame  = (float) ( $i['frame'] ?? 30 );

			$leaf_h    = 2000.0; // standard leaf height.
			$gap       = 15.0;   // mounting gap each side / head.
			$floor_gap = 15.0;   // clearance under the leaf to the finished floor.

			$opening_w = $leaf_w + 2 * ( $frame + $gap );
			$opening_h = $leaf_h + ( $frame + $gap ) + $floor_gap;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: opening width mm, 2: opening height mm */
				__( 'Leave a rough opening of about %1$d × %2$d mm.', 'mvweb-build-calc' ),
				(int) round( $opening_w ),
				(int) round( $opening_h )
			);

			$hints[] = __( 'Width includes the frame on both sides plus a mounting gap; height includes the head frame and a clearance under the leaf to the finished floor.', 'mvweb-build-calc' );

			$hints[] = __( 'Geometric estimate per common practice and GOST 6629 leaf sizes. Confirm against the chosen door set.', 'mvweb-build-calc' );

			return array(
				'value' => $opening_w,
				'hints' => $hints,
			);
		},
	)
);
