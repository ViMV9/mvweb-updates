<?php
/**
 * Calculator: recommended wall thickness by material.
 *
 * Recommends a wall thickness for the chosen material and role (load-bearing
 * external, external infill, or internal partition). Guide based on common
 * practice; the exact external thickness should be confirmed by a thermal
 * calculation per SP 50.13330 for the region.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'wall-thickness',
	array(
		'title'       => __( 'Wall thickness by material', 'mvweb-build-calc' ),
		'hub'         => 'walls',
		'description' => __( 'Recommends a wall thickness for the chosen material and role — load-bearing external, external infill, or internal partition. Guide based on common practice; the exact external thickness should be confirmed by a thermal calculation per SP 50.13330 for your region.', 'mvweb-build-calc' ),
		'formula'     => 'thickness = typical value(material, role)',
		'legend'      => array(
			'thickness' => __( 'recommended wall thickness, cm', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended thickness', 'mvweb-build-calc' ),
			'unit'     => __( 'cm', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'material' => array(
				'type'       => 'select',
				'label'      => __( 'Material', 'mvweb-build-calc' ),
				'default'    => 'aerated',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'brick'   => __( 'Brick', 'mvweb-build-calc' ),
					'aerated' => __( 'Aerated concrete', 'mvweb-build-calc' ),
					'ceramic' => __( 'Porous ceramic', 'mvweb-build-calc' ),
					'timber'  => __( 'Timber (profiled/glued)', 'mvweb-build-calc' ),
				),
			),
			'role'     => array(
				'type'       => 'select',
				'label'      => __( 'Wall role', 'mvweb-build-calc' ),
				'default'    => 'bearing_ext',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'bearing_ext' => __( 'Load-bearing external', 'mvweb-build-calc' ),
					'infill_ext'  => __( 'External infill (with insulation)', 'mvweb-build-calc' ),
					'internal'    => __( 'Internal partition', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$material = (string) ( $i['material'] ?? 'aerated' );
			$role     = (string) ( $i['role'] ?? 'bearing_ext' );

			// Typical thicknesses, cm.
			$table = array(
				'brick'   => array(
					'bearing_ext' => 38,
					'infill_ext'  => 25,
					'internal'    => 12,
				),
				'aerated' => array(
					'bearing_ext' => 40,
					'infill_ext'  => 30,
					'internal'    => 10,
				),
				'ceramic' => array(
					'bearing_ext' => 44,
					'infill_ext'  => 38,
					'internal'    => 12,
				),
				'timber'  => array(
					'bearing_ext' => 20,
					'infill_ext'  => 20,
					'internal'    => 10,
				),
			);

			$thickness = $table[ $material ][ $role ] ?? 30;

			$hints = array();

			if ( 'internal' === $role ) {
				$hints[] = __( 'Internal partitions are sized for sound insulation and stability, not heat loss.', 'mvweb-build-calc' );
			} elseif ( 'infill_ext' === $role ) {
				$hints[] = __( 'An external infill wall is normally combined with a separate insulation layer.', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'A single-layer load-bearing external wall must satisfy both strength and heat loss.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Recommendation based on common practice. Confirm the external thickness with a thermal calculation per SP 50.13330 for your region.', 'mvweb-build-calc' );

			return array(
				'value' => (float) $thickness,
				'hints' => $hints,
			);
		},
	)
);
