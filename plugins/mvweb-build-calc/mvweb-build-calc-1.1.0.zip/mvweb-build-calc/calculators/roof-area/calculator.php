<?php
/**
 * Calculator: roof area.
 *
 * Sloped surface area of a gable or single-slope roof from the building plan
 * size, the slope angle and the eaves overhang. The plan area is divided by the
 * cosine of the slope to get the true sloped area. Geometric calculation.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'roof-area',
	array(
		'title'       => __( 'Roof area', 'mvweb-build-calc' ),
		'hub'         => 'roof',
		'description' => __( 'Calculates the sloped surface area of a gable or single-slope roof from the building plan size, the slope angle and the eaves overhang. The plan area is divided by the cosine of the slope to get the true sloped area.', 'mvweb-build-calc' ),
		'formula'     => 'area = plan area (with overhang) / cos(angle)',
		'legend'      => array(
			'area'  => __( 'sloped roof area, m²', 'mvweb-build-calc' ),
			'angle' => __( 'slope angle, degrees', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Roof area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'type'     => array(
				'type'       => 'radio',
				'label'      => __( 'Roof type', 'mvweb-build-calc' ),
				'default'    => 'gable',
				'full_width' => true,
				'options'    => array(
					'gable'  => __( 'Gable (two slopes)', 'mvweb-build-calc' ),
					'single' => __( 'Single slope', 'mvweb-build-calc' ),
				),
			),
			'length'   => array(
				'type'     => 'number',
				'label'    => __( 'Building length', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'width'    => array(
				'type'     => 'number',
				'label'    => __( 'Building width (span)', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 50,
				'step'     => 0.1,
				'required' => true,
			),
			'angle'    => array(
				'type'     => 'number',
				'label'    => __( 'Slope angle', 'mvweb-build-calc' ),
				'unit'     => __( '°', 'mvweb-build-calc' ),
				'min'      => 5,
				'max'      => 70,
				'step'     => 1,
				'required' => true,
			),
			'overhang' => array(
				'type'     => 'number',
				'label'    => __( 'Eaves overhang (each side)', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 1.5,
				'step'     => 0.05,
				'default'  => 0.5,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$type     = (string) ( $i['type'] ?? 'gable' );
			$length   = max( 0.0, (float) ( $i['length'] ?? 0 ) );
			$width    = max( 0.0, (float) ( $i['width'] ?? 0 ) );
			$angle    = max( 0.0, min( 89.0, (float) ( $i['angle'] ?? 0 ) ) );
			$overhang = max( 0.0, (float) ( $i['overhang'] ?? 0 ) );

			// Plan dimensions including overhang on all sides.
			$plan_l = $length + 2 * $overhang;
			$plan_w = $width + 2 * $overhang;

			$cos = cos( deg2rad( $angle ) );
			$cos = $cos > 0.01 ? $cos : 0.01;

			if ( 'single' === $type ) {
				// One slope spans the whole width.
				$area = $plan_l * $plan_w / $cos;
			} else {
				// Two slopes, each over half the width.
				$slope_w = ( $plan_w / 2 ) / $cos;
				$area    = 2 * $plan_l * $slope_w;
			}

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: plan area m², 2: angle degrees */
				__( 'Plan area with overhang %1$s m²; sloped area is larger by 1/cos(%2$s°).', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $plan_l * $plan_w, 1 ),
				mvweb_bc_format_number( $angle, 0 )
			);

			$hints[] = __( 'Hips, valleys and dormers change the area — this is for a plain gable or single-slope roof.', 'mvweb-build-calc' );

			return array(
				'value' => round( $area, 1 ),
				'hints' => $hints,
			);
		},
	)
);
