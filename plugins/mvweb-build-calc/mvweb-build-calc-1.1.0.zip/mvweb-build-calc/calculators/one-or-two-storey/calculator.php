<?php
/**
 * Calculator: one-storey vs two-storey suitability.
 *
 * Scores how well a two-storey house fits the situation (0–100) from the needed
 * floor area, the plot size and accessibility needs, and names the recommended
 * option. Recommendation, not a code requirement.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'one-or-two-storey',
	array(
		'title'       => __( 'One or two storeys', 'mvweb-build-calc' ),
		'hub'         => 'layout',
		'description' => __( 'Scores how well a two-storey house fits your situation from the needed floor area, the plot size and accessibility needs, and names the recommended option. This is a design recommendation based on common practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'score = fit(area need, plot size, accessibility)',
		'legend'      => array(
			'score' => __( 'suitability of a two-storey house, 0–100', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Two-storey suitability', 'mvweb-build-calc' ),
			'unit'     => __( '/ 100', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'need'          => array(
				'type'     => 'number',
				'label'    => __( 'Needed floor area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 40,
				'max'      => 1000,
				'step'     => 1,
				'required' => true,
			),
			'plot'          => array(
				'type'     => 'number',
				'label'    => __( 'Plot area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 200,
				'max'      => 50000,
				'step'     => 10,
				'required' => true,
			),
			'accessibility' => array(
				'type'       => 'radio',
				'label'      => __( 'Single-level living important (no stairs)', 'mvweb-build-calc' ),
				'default'    => 'no',
				'full_width' => true,
				'options'    => array(
					'no'  => __( 'No', 'mvweb-build-calc' ),
					'yes' => __( 'Yes — elderly or limited mobility', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$need = max( 1.0, (float) ( $i['need'] ?? 0 ) );
			$plot = max( 1.0, (float) ( $i['plot'] ?? 0 ) );
			$acc  = (string) ( $i['accessibility'] ?? 'no' );

			$score = 50;

			// A large house on a small plot favours two storeys (smaller footprint).
			$footprint_one = $need;
			$ratio         = $footprint_one / $plot;
			if ( $ratio > 0.25 ) {
				$score += 30;
			} elseif ( $ratio > 0.15 ) {
				$score += 15;
			} else {
				$score -= 10;
			}

			// A big house is usually more practical over two floors.
			if ( $need > 150 ) {
				$score += 15;
			} elseif ( $need < 90 ) {
				$score -= 15;
			}

			// Single-level need strongly favours one storey.
			if ( 'yes' === $acc ) {
				$score -= 40;
			}

			$score = max( 0, min( 100, $score ) );

			$hints = array();

			if ( $score >= 60 ) {
				$hints[] = __( 'A two-storey house fits well: smaller footprint, more area on a compact plot.', 'mvweb-build-calc' );
			} elseif ( $score <= 40 ) {
				$hints[] = __( 'A one-storey house fits better: simpler living, no stairs, easier maintenance.', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'Both options are reasonable — decide by budget, comfort and the plot shape.', 'mvweb-build-calc' );
			}

			if ( 'yes' === $acc ) {
				$hints[] = __( 'Single-level living was requested, which strongly favours one storey or a ground-floor master suite.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'Design recommendation based on common practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => (float) $score,
				'hints' => $hints,
			);
		},
	)
);
