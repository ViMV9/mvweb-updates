<?php
/**
 * Calculator: total glazing area.
 *
 * Geometric calculation. Sums the glass area of identical windows (width ×
 * height × count) and reports the glazing area, with a note on the rough
 * frame share that reduces the actual light-transmitting glass.
 *
 * Model:
 *   area = width × height × count
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'glazing-area',
	array(
		'title'       => __( 'Glazing area', 'mvweb-build-calc' ),
		'hub'         => 'openings',
		'description' => __( 'Calculates the total glazing (window) area from the size of one window and the number of identical windows. Use it for daylight, heat-loss and curtain take-offs. Geometric calculation.', 'mvweb-build-calc' ),
		'formula'     => 'A = width × height × count',
		'legend'      => array(
			'A'      => __( 'total window area, m²', 'mvweb-build-calc' ),
			'width'  => __( 'one window width, m', 'mvweb-build-calc' ),
			'height' => __( 'one window height, m', 'mvweb-build-calc' ),
			'count'  => __( 'number of identical windows', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Total window area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'width'  => array(
				'type'     => 'number',
				'label'    => __( 'Window width', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.3,
				'max'      => 6,
				'step'     => 0.1,
				'required' => true,
			),
			'height' => array(
				'type'     => 'number',
				'label'    => __( 'Window height', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.3,
				'max'      => 4,
				'step'     => 0.1,
				'required' => true,
			),
			'count'  => array(
				'type'     => 'number',
				'label'    => __( 'Number of windows', 'mvweb-build-calc' ),
				'default'  => 1,
				'min'      => 1,
				'max'      => 100,
				'step'     => 1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$width  = max( 0.01, (float) ( $i['width'] ?? 0 ) );
			$height = max( 0.01, (float) ( $i['height'] ?? 0 ) );
			$count  = max( 1, (int) ( $i['count'] ?? 1 ) );

			$one  = $width * $height;
			$area = $one * $count;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: one window area m², 2: window count */
				__( 'One window %1$s m² × %2$d.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $one, 2 ),
				$count
			);

			$hints[] = __( 'The frame and sashes take roughly 20–30% of the opening, so the clear light-transmitting glass is smaller than this figure.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
