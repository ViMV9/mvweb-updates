<?php
/**
 * Calculator: number of electrical points.
 *
 * Ergonomic guide. Estimates the number of sockets and switches for the home
 * from the number of rooms by type and the wet-room count, using common
 * per-room point counts.
 *
 * Model:
 *   sockets  = Σ rooms × sockets_per_room(type)
 *   switches = Σ rooms × switches_per_room(type)
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'electrical-points',
	array(
		'title'       => __( 'Electrical points', 'mvweb-build-calc' ),
		'hub'         => 'engineering',
		'description' => __( 'Estimates the number of sockets and switches for the home from the room counts by type, using common per-room figures. The result value is the total number of points (sockets + switches); the split is in the hints. Ergonomic guide based on common practice.', 'mvweb-build-calc' ),
		'formula'     => 'points = Σ rooms × (sockets + switches) per room',
		'legend'      => array(
			'points'  => __( 'total sockets and switches', 'mvweb-build-calc' ),
			'sockets' => __( 'sockets per room by type', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Total electrical points', 'mvweb-build-calc' ),
			'unit'     => __( 'pcs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'living'  => array(
				'type'     => 'number',
				'label'    => __( 'Living rooms / bedrooms', 'mvweb-build-calc' ),
				'default'  => 3,
				'min'      => 0,
				'max'      => 20,
				'step'     => 1,
				'required' => true,
			),
			'kitchen' => array(
				'type'     => 'number',
				'label'    => __( 'Kitchens', 'mvweb-build-calc' ),
				'default'  => 1,
				'min'      => 0,
				'max'      => 5,
				'step'     => 1,
				'required' => true,
			),
			'bath'    => array(
				'type'     => 'number',
				'label'    => __( 'Bathrooms / WC', 'mvweb-build-calc' ),
				'default'  => 2,
				'min'      => 0,
				'max'      => 10,
				'step'     => 1,
				'required' => true,
			),
			'hall'    => array(
				'type'     => 'number',
				'label'    => __( 'Hallways / utility', 'mvweb-build-calc' ),
				'default'  => 2,
				'min'      => 0,
				'max'      => 10,
				'step'     => 1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$living  = max( 0, (int) ( $i['living'] ?? 0 ) );
			$kitchen = max( 0, (int) ( $i['kitchen'] ?? 0 ) );
			$bath    = max( 0, (int) ( $i['bath'] ?? 0 ) );
			$hall    = max( 0, (int) ( $i['hall'] ?? 0 ) );

			// Per-room: [sockets, switches].
			$sockets = $living * 6 + $kitchen * 8 + $bath * 2 + $hall * 2;
			$switches = $living * 2 + $kitchen * 2 + $bath * 1 + $hall * 2;

			$total = $sockets + $switches;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: sockets count, 2: switches count */
				__( 'About %1$d sockets and %2$d switches.', 'mvweb-build-calc' ),
				$sockets,
				$switches
			);

			$hints[] = __( 'A kitchen carries the most sockets (appliances, worktop); a bathroom socket must be a protected one near the basin, not in the wet zone.', 'mvweb-build-calc' );

			$hints[] = __( 'Ergonomic guide based on common practice; the final layout depends on the furniture plan.', 'mvweb-build-calc' );

			return array(
				'value' => (float) $total,
				'hints' => $hints,
			);
		},
	)
);
