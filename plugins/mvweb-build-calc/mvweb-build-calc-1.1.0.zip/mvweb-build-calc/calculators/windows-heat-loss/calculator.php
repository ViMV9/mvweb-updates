<?php
/**
 * Calculator: heat loss through windows.
 *
 * Preliminary estimate. The transmission loss through glazing is the window
 * area times the temperature difference divided by the window's resistance
 * (Q = A × ΔT / R). R depends on the glazing type.
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'windows-heat-loss',
	array(
		'title'       => __( 'Windows heat loss', 'mvweb-build-calc' ),
		'hub'         => 'heat',
		'description' => __( 'Estimates the heat loss through windows from the glazing area, the temperature difference and the window’s heat-transfer resistance (by glazing type). Windows lose far more heat per m² than a wall. Preliminary estimate per SP 50.13330, not a thermal design.', 'mvweb-build-calc' ),
		'formula'     => 'Q = A × ΔT / R_window',
		'legend'      => array(
			'Q'        => __( 'heat loss, W', 'mvweb-build-calc' ),
			'A'        => __( 'window area, m²', 'mvweb-build-calc' ),
			'ΔT'       => __( 'indoor minus outdoor temperature, °C', 'mvweb-build-calc' ),
			'R_window' => __( 'window heat-transfer resistance, m²·°C/W', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Heat loss', 'mvweb-build-calc' ),
			'unit'     => __( 'W', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'area'    => array(
				'type'     => 'number',
				'label'    => __( 'Window area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 0.1,
				'max'      => 200,
				'step'     => 0.1,
				'required' => true,
			),
			'glazing' => array(
				'type'       => 'select',
				'label'      => __( 'Glazing type', 'mvweb-build-calc' ),
				'default'    => 'double_lowe',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'single'      => __( 'Single glass (R ≈ 0.18)', 'mvweb-build-calc' ),
					'double'      => __( 'Double glazing (R ≈ 0.40)', 'mvweb-build-calc' ),
					'double_lowe' => __( 'Double, low-E + argon (R ≈ 0.55)', 'mvweb-build-calc' ),
					'triple'      => __( 'Triple, low-E (R ≈ 0.75)', 'mvweb-build-calc' ),
				),
			),
			'delta_t' => array(
				'type'     => 'number',
				'label'    => __( 'Indoor − outdoor temperature', 'mvweb-build-calc' ),
				'unit'     => __( '°C', 'mvweb-build-calc' ),
				'default'  => 48,
				'min'      => 10,
				'max'      => 75,
				'step'     => 1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area    = max( 0.01, (float) ( $i['area'] ?? 0 ) );
			$glazing = (string) ( $i['glazing'] ?? 'double_lowe' );
			$delta_t = max( 1.0, (float) ( $i['delta_t'] ?? 48 ) );

			$r = match ( $glazing ) {
				'single'      => 0.18,
				'double'      => 0.40,
				'triple'      => 0.75,
				default       => 0.55, // double_lowe.
			};

			$q = $area * $delta_t / $r;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: window resistance, 2: loss per m² W */
				__( 'Window resistance R = %1$s m²·°C/W; loss about %2$s W per m².', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $r, 2 ),
				mvweb_bc_format_number( $delta_t / $r, 0 )
			);

			$hints[] = __( 'A window loses several times more heat per m² than an insulated wall — glazing type and area drive the comfort and the bills.', 'mvweb-build-calc' );

			$hints[] = __( 'Preliminary estimate per SP 50.13330. The frame, installation and air leakage add to the real loss.', 'mvweb-build-calc' );

			return array(
				'value' => $q,
				'hints' => $hints,
			);
		},
	)
);
