<?php
/**
 * Calculator: bathhouse (banya) size.
 *
 * Ergonomic planning guide, not a code requirement. Sizes a bathhouse from the
 * number of people it should serve at once, summing the steam room, washroom
 * and a rest / changing room by per-person and base allowances.
 *
 * Model:
 *   area = steam(people) + wash(people) + rest(people, with_rest)
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'bathhouse-size',
	array(
		'title'       => __( 'Bathhouse size', 'mvweb-build-calc' ),
		'hub'         => 'outbuildings',
		'description' => __( 'Estimates the recommended total area of a bathhouse (banya) from the number of people using it at once, summing the steam room, the washroom and an optional rest / changing room. This is an ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'A = steam + wash + rest',
		'legend'      => array(
			'A'     => __( 'recommended total area, m²', 'mvweb-build-calc' ),
			'steam' => __( 'steam room area (~1.5 m² per person, min 4)', 'mvweb-build-calc' ),
			'wash'  => __( 'washroom area (~1.2 m² per person, min 3)', 'mvweb-build-calc' ),
			'rest'  => __( 'rest / changing room area, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended total area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'people'    => array(
				'type'     => 'number',
				'label'    => __( 'People at once', 'mvweb-build-calc' ),
				'default'  => 3,
				'min'      => 1,
				'max'      => 12,
				'step'     => 1,
				'required' => true,
			),
			'with_rest' => array(
				'type'       => 'radio',
				'label'      => __( 'Include a rest / changing room', 'mvweb-build-calc' ),
				'default'    => 'yes',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'yes' => __( 'Yes — with a rest room', 'mvweb-build-calc' ),
					'no'  => __( 'No — steam + wash only', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$people    = max( 1, (int) ( $i['people'] ?? 3 ) );
			$with_rest = ( 'no' !== (string) ( $i['with_rest'] ?? 'yes' ) );

			$steam = max( 4.0, $people * 1.5 );
			$wash  = max( 3.0, $people * 1.2 );
			$rest  = $with_rest ? max( 6.0, $people * 1.8 ) : 0.0;

			$area = $steam + $wash + $rest;

			$hints = array();

			if ( $with_rest ) {
				$hints[] = sprintf(
					/* translators: 1: steam m², 2: wash m², 3: rest m² */
					__( 'Steam room %1$s m² + washroom %2$s m² + rest room %3$s m².', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $steam, 1 ),
					mvweb_bc_format_number( $wash, 1 ),
					mvweb_bc_format_number( $rest, 1 )
				);
			} else {
				$hints[] = sprintf(
					/* translators: 1: steam m², 2: wash m² */
					__( 'Steam room %1$s m² + washroom %2$s m².', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $steam, 1 ),
					mvweb_bc_format_number( $wash, 1 )
				);
			}

			$hints[] = __( 'A rest room is usually the largest of the three and doubles as a changing area.', 'mvweb-build-calc' );

			$hints[] = __( 'Ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
