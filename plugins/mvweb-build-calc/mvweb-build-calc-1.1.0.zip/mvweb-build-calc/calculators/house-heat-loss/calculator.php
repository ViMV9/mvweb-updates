<?php
/**
 * Calculator: house heat loss.
 *
 * Preliminary estimate. The transmission loss through the envelope is the
 * heated area scaled by a per-m² figure that depends on the insulation level
 * and the design temperature difference; a ventilation loss is added. The
 * result is the peak heat load for sizing the boiler.
 *
 * Model:
 *   Q_env  = area × spec_loss(level) × (ΔT / 40)
 *   Q_vent = 0.335 × air × volume × ΔT
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'house-heat-loss',
	array(
		'title'       => __( 'House heat loss', 'mvweb-build-calc' ),
		'hub'         => 'heat',
		'description' => __( 'Estimates the peak heat loss of a house — transmission through the envelope plus ventilation — from the heated area, the insulation level and the design temperature difference. The result is the heat load for sizing the heating. Preliminary estimate based on SP 50.13330 / SP 60.13330, not a heat-loss design.', 'mvweb-build-calc' ),
		'formula'     => 'Q = area × spec_loss × (ΔT/40) + 0.335 × air × volume × ΔT',
		'legend'      => array(
			'Q'         => __( 'heat loss, kW', 'mvweb-build-calc' ),
			'spec_loss' => __( 'specific envelope loss by insulation level, W/m²', 'mvweb-build-calc' ),
			'ΔT'        => __( 'indoor minus design outdoor temperature, °C', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Heat loss', 'mvweb-build-calc' ),
			'unit'     => __( 'kW', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'area'    => array(
				'type'     => 'number',
				'label'    => __( 'Heated area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 10,
				'max'      => 1500,
				'step'     => 1,
				'required' => true,
			),
			'height'  => array(
				'type'     => 'number',
				'label'    => __( 'Ceiling height', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 2.7,
				'min'      => 2.4,
				'max'      => 5,
				'step'     => 0.1,
				'required' => true,
			),
			'level'   => array(
				'type'       => 'select',
				'label'      => __( 'Insulation level', 'mvweb-build-calc' ),
				'default'    => 'normal',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'poor'   => __( 'Poor / old (≈ 100 W/m²)', 'mvweb-build-calc' ),
					'normal' => __( 'Code-compliant (≈ 70 W/m²)', 'mvweb-build-calc' ),
					'high'   => __( 'High / energy-efficient (≈ 50 W/m²)', 'mvweb-build-calc' ),
				),
			),
			'delta_t' => array(
				'type'     => 'number',
				'label'    => __( 'Indoor − design outdoor temperature', 'mvweb-build-calc' ),
				'unit'     => __( '°C', 'mvweb-build-calc' ),
				'default'  => 48,
				'min'      => 20,
				'max'      => 75,
				'step'     => 1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area    = max( 1.0, (float) ( $i['area'] ?? 0 ) );
			$height  = max( 2.0, (float) ( $i['height'] ?? 2.7 ) );
			$level   = (string) ( $i['level'] ?? 'normal' );
			$delta_t = max( 1.0, (float) ( $i['delta_t'] ?? 48 ) );

			$spec = match ( $level ) {
				'poor' => 100.0,
				'high' => 50.0,
				default => 70.0, // normal.
			};

			// Envelope loss scaled to the actual ΔT (spec figures assume ΔT ≈ 40).
			$q_env = $area * $spec * ( $delta_t / 40 );

			// Ventilation loss: 0.335 Wh/(m³·°C) (ρ·c of air) × 1 air change × volume × ΔT.
			$volume = $area * $height;
			$q_vent = 0.335 * 1.0 * $volume * $delta_t;

			$q_w = $q_env + $q_vent;
			$q_kw = $q_w / 1000;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: envelope loss kW, 2: ventilation loss kW */
				__( 'Envelope %1$s kW + ventilation %2$s kW.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $q_env / 1000, 1 ),
				mvweb_bc_format_number( $q_vent / 1000, 1 )
			);

			$hints[] = sprintf(
				/* translators: %s: specific loss W per m² */
				__( 'About %s W per m² of heated area at this temperature difference.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $q_w / $area, 0 )
			);

			$hints[] = __( 'Use this as the heating load; a heat-recovery ventilation unit cuts the ventilation share by 60–70%.', 'mvweb-build-calc' );

			$hints[] = __( 'Preliminary estimate based on SP 50.13330 / SP 60.13330. A full heat-loss calculation goes room by room; it does not replace a design.', 'mvweb-build-calc' );

			return array(
				'value' => $q_kw,
				'hints' => $hints,
			);
		},
	)
);
