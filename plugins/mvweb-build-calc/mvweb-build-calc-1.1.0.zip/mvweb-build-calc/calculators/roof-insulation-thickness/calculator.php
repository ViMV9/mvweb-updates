<?php
/**
 * Calculator: roof / attic insulation thickness.
 *
 * Preliminary estimate. The required resistance for a roof / attic floor is
 * higher than for walls (R = 0.0005·ГСОП + 2.2, SP 50.13330 Table 3). Most of
 * a pitched roof's resistance is the insulation between the rafters, so the
 * thickness is δ ≈ R_req × λ_ins.
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'roof-insulation-thickness',
	array(
		'title'       => __( 'Roof insulation thickness', 'mvweb-build-calc' ),
		'hub'         => 'heat',
		'description' => __( 'Estimates the insulation thickness a roof or attic floor needs to reach the required heat-transfer resistance for the region (R = a·ГСОП + b, SP 50.13330.2012 Table 3 for roofs). A pitched-roof structure adds little, so the insulation carries almost all of it. Preliminary estimate, not a thermal design.', 'mvweb-build-calc' ),
		'formula'     => 'δ = R_req × λ_ins, R_req = 0.0005 × ГСОП + 2.2',
		'legend'      => array(
			'δ'     => __( 'insulation thickness, mm', 'mvweb-build-calc' ),
			'R_req' => __( 'required roof resistance, m²·°C/W', 'mvweb-build-calc' ),
			'λ_ins' => __( 'insulation thermal conductivity, W/(m·°C)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Insulation thickness', 'mvweb-build-calc' ),
			'unit'     => __( 'mm', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'zone'       => array(
				'type'       => 'select',
				'label'      => __( 'Climate (degree-days, ГСОП)', 'mvweb-build-calc' ),
				'default'    => '6000',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'4000' => __( 'Mild (~4000): Krasnodar, Rostov', 'mvweb-build-calc' ),
					'5000' => __( 'Moderate (~5000): Minsk, Kaliningrad', 'mvweb-build-calc' ),
					'6000' => __( 'Central (~6000): Moscow, Saint Petersburg', 'mvweb-build-calc' ),
					'7000' => __( 'Cold (~7000): Yekaterinburg, Novosibirsk', 'mvweb-build-calc' ),
					'9000' => __( 'Severe (~9000): Surgut, Yakutsk', 'mvweb-build-calc' ),
				),
			),
			'insulation' => array(
				'type'       => 'select',
				'label'      => __( 'Insulation', 'mvweb-build-calc' ),
				'default'    => 'mineral_wool',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'mineral_wool' => __( 'Mineral wool (λ 0.040)', 'mvweb-build-calc' ),
					'eps'          => __( 'EPS foam (λ 0.039)', 'mvweb-build-calc' ),
					'xps'          => __( 'Extruded polystyrene (λ 0.032)', 'mvweb-build-calc' ),
					'pir'          => __( 'PIR board (λ 0.025)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$gsop = (float) ( $i['zone'] ?? 6000 );
			$ins  = (string) ( $i['insulation'] ?? 'mineral_wool' );

			$lambda_ins = match ( $ins ) {
				'eps' => 0.039,
				'xps' => 0.032,
				'pir' => 0.025,
				default => 0.040, // mineral_wool.
			};

			$r_req = 0.0005 * $gsop + 2.2;

			// Roof structure + surfaces give ~0.3; the rest is insulation.
			$delta_r  = max( 0.0, $r_req - 0.3 );
			$thick_mm = $delta_r * $lambda_ins * 1000;
			$rounded  = ceil( $thick_mm / 10 ) * 10;

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: required roof resistance */
				__( 'Required roof resistance %s m²·°C/W — higher than for a wall.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $r_req, 2 )
			);

			$hints[] = sprintf(
				/* translators: %s: standard layer suggestion mm */
				__( 'Often laid in two crossed layers; aim for about %s mm total.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( ceil( $thick_mm / 50 ) * 50, 0 )
			);

			$hints[] = __( 'Insulation between the rafters must not block the ventilation gap under the roofing; leave 40–50 mm.', 'mvweb-build-calc' );

			$hints[] = __( 'Preliminary estimate per SP 50.13330. It does not replace a thermal design by an engineer.', 'mvweb-build-calc' );

			return array(
				'value' => $rounded,
				'hints' => $hints,
			);
		},
	)
);
