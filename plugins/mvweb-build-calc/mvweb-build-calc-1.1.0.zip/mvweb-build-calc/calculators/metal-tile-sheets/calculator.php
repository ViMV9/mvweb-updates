<?php
/**
 * Calculator: metal tile sheets.
 *
 * Number of metal roof tile sheets for the roof area: roof area divided by the
 * useful (overlapped) area of one sheet, plus a cutting/overlap reserve.
 * Geometric calculation.
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'metal-tile-sheets',
	array(
		'title'       => __( 'Metal tile sheets', 'mvweb-build-calc' ),
		'hub'         => 'roof',
		'description' => __( 'Calculates the number of metal roof tile sheets for the roof area: the roof area divided by the useful (overlapped) area of one sheet, plus a cutting and overlap reserve. Geometric calculation.', 'mvweb-build-calc' ),
		'formula'     => 'sheets = roof area / useful sheet area × (1 + reserve%)',
		'legend'      => array(
			'area' => __( 'roof area, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Sheets needed', 'mvweb-build-calc' ),
			'unit'     => __( 'pcs', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'area'    => array(
				'type'     => 'number',
				'label'    => __( 'Roof area', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 5000,
				'step'     => 0.5,
				'required' => true,
			),
			'useful'  => array(
				'type'     => 'number',
				'label'    => __( 'Useful area of one sheet', 'mvweb-build-calc' ),
				'unit'     => __( 'm²', 'mvweb-build-calc' ),
				'min'      => 0.5,
				'max'      => 10,
				'step'     => 0.05,
				'required' => true,
			),
			'reserve' => array(
				'type'     => 'number',
				'label'    => __( 'Cutting / overlap reserve', 'mvweb-build-calc' ),
				'unit'     => __( '%', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 25,
				'step'     => 1,
				'default'  => 10,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$area    = max( 0.0, (float) ( $i['area'] ?? 0 ) );
			$useful  = max( 0.1, (float) ( $i['useful'] ?? 0 ) );
			$reserve = max( 0.0, (float) ( $i['reserve'] ?? 0 ) );

			$sheets = (int) ceil( $area / $useful * ( 1 + $reserve / 100 ) );

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: reserve percent */
				__( 'Includes a %s%% reserve for cuts and overlaps; complex roofs need more.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $reserve, 0 )
			);

			$hints[] = __( 'Useful area is the covered area after side and end overlaps — take it from the product sheet.', 'mvweb-build-calc' );

			$hints[] = __( 'Geometric estimate — order full sheets cut to the slope length where possible.', 'mvweb-build-calc' );

			return array(
				'value' => $sheets,
				'hints' => $hints,
			);
		},
	)
);
