<?php
/**
 * Calculator: recommended total house area by family composition.
 *
 * This is an ergonomic planning estimate, not a code requirement. SP
 * 55.13330.2016 (single-family houses) and SP 54.13330.2022 set only minimum
 * room areas, not a whole-house figure; the per-person allowances below follow
 * common residential design practice for detached houses.
 *
 * Model:
 *   total = occupants × per_person(comfort) + common_zone(comfort) + options
 *
 * per_person covers a person's private space (bedroom share, storage). The
 * common zone covers shared rooms that do not scale linearly with occupants
 * (kitchen-living, hallways, bathrooms, boiler room, circulation).
 *
 * @package MVweb_BC
 * @since   1.0.9
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'house-area-by-family',
	array(
		'title'       => __( 'Recommended house area by family', 'mvweb-build-calc' ),
		'hub'         => 'rooms',
		'description' => __( 'Estimates the recommended total floor area of a detached house from the number of occupants and the desired comfort level. This is an ergonomic planning guide based on common design practice — not a building code requirement. SP 55.13330.2016 and SP 54.13330.2022 regulate only minimum room areas.', 'mvweb-build-calc' ),
		'formula'     => 'S = N × s + common + options',
		'legend'      => array(
			'S'       => __( 'recommended total area, m²', 'mvweb-build-calc' ),
			'N'       => __( 'number of occupants', 'mvweb-build-calc' ),
			's'       => __( 'private area per person by comfort level (min 20, standard 28, spacious 36 m²)', 'mvweb-build-calc' ),
			'common'  => __( 'shared zone — kitchen-living, hallways, bathrooms, boiler room (min 28, standard 38, spacious 50 m²)', 'mvweb-build-calc' ),
			'options' => __( 'optional extra rooms — guest room (+14 m²), home office (+10 m²)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 0,
		),
		'fields'      => array(
			'adults'     => array(
				'type'     => 'number',
				'label'    => __( 'Adults', 'mvweb-build-calc' ),
				'default'  => 2,
				'min'      => 1,
				'max'      => 20,
				'step'     => 1,
				'required' => true,
			),
			'children'   => array(
				'type'    => 'number',
				'label'   => __( 'Children', 'mvweb-build-calc' ),
				'default' => 0,
				'min'     => 0,
				'max'     => 20,
				'step'    => 1,
			),
			'comfort'    => array(
				'type'       => 'radio',
				'label'      => __( 'Comfort level', 'mvweb-build-calc' ),
				'default'    => 'standard',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'minimal'  => __( 'Minimal — compact, functional', 'mvweb-build-calc' ),
					'standard' => __( 'Standard — comfortable', 'mvweb-build-calc' ),
					'spacious' => __( 'Spacious — generous', 'mvweb-build-calc' ),
				),
			),
			'guest_room' => array(
				'type'    => 'radio',
				'label'   => __( 'Guest room', 'mvweb-build-calc' ),
				'default' => 'no',
				'options' => array(
					'no'  => __( 'No', 'mvweb-build-calc' ),
					'yes' => __( 'Yes', 'mvweb-build-calc' ),
				),
			),
			'office'     => array(
				'type'    => 'radio',
				'label'   => __( 'Home office', 'mvweb-build-calc' ),
				'default' => 'no',
				'options' => array(
					'no'  => __( 'No', 'mvweb-build-calc' ),
					'yes' => __( 'Yes', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$adults   = max( 1, (int) ( $i['adults'] ?? 2 ) );
			$children = max( 0, (int) ( $i['children'] ?? 0 ) );
			$comfort  = (string) ( $i['comfort'] ?? 'standard' );
			$guest    = 'yes' === (string) ( $i['guest_room'] ?? 'no' );
			$office   = 'yes' === (string) ( $i['office'] ?? 'no' );

			$occupants = $adults + $children;

			// Private area per person by comfort level, m².
			$per_person = match ( $comfort ) {
				'minimal'  => 20.0,
				'spacious' => 36.0,
				default    => 28.0, // standard.
			};

			// Shared zone that does not scale linearly with occupants, m².
			$common = match ( $comfort ) {
				'minimal'  => 28.0,
				'spacious' => 50.0,
				default    => 38.0, // standard.
			};

			$options = 0.0;
			if ( $guest ) {
				$options += 14.0;
			}
			if ( $office ) {
				$options += 10.0;
			}

			$total = $occupants * $per_person + $common + $options;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: occupants count, 2: per-person area in m² */
				__( '%1$d occupants × %2$s m² private area + shared zone.', 'mvweb-build-calc' ),
				$occupants,
				mvweb_bc_format_number( $per_person, 0 )
			);

			// Show the three comfort levels side by side for comparison.
			$minimal  = $occupants * 20.0 + 28.0 + $options;
			$standard = $occupants * 28.0 + 38.0 + $options;
			$spacious = $occupants * 36.0 + 50.0 + $options;

			$hints[] = sprintf(
				/* translators: 1: minimal area, 2: standard area, 3: spacious area, all in m² */
				__( 'For reference: minimal ≈ %1$s m², standard ≈ %2$s m², spacious ≈ %3$s m².', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $minimal, 0 ),
				mvweb_bc_format_number( $standard, 0 ),
				mvweb_bc_format_number( $spacious, 0 )
			);

			$hints[] = __( 'This is an ergonomic planning guide based on common design practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $total,
				'hints' => $hints,
			);
		},
	)
);
