<?php
/**
 * Calculator: steam room size.
 *
 * Ergonomic planning guide, not a code requirement. Sizes the steam room of a
 * bathhouse from the number of bathers and whether they lie down or sit, plus
 * the floor space taken by the stove with its safety clearance.
 *
 * Model:
 *   area = bathers × per_person(posture) + stove_zone
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'steam-room-size',
	array(
		'title'       => __( 'Steam room size', 'mvweb-build-calc' ),
		'hub'         => 'outbuildings',
		'description' => __( 'Estimates the recommended steam room area from the number of bathers and whether they sit or lie on the benches, plus the floor zone taken by the stove and its safety clearance. This is an ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' ),
		'formula'     => 'A = bathers × per_person + stove_zone',
		'legend'      => array(
			'A'          => __( 'recommended area, m²', 'mvweb-build-calc' ),
			'per_person' => __( 'space per bather — sitting 1.0, lying 2.0 m²', 'mvweb-build-calc' ),
			'stove_zone' => __( 'floor zone for the stove with clearance, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Recommended area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'bathers' => array(
				'type'     => 'number',
				'label'    => __( 'Bathers at once', 'mvweb-build-calc' ),
				'default'  => 3,
				'min'      => 1,
				'max'      => 10,
				'step'     => 1,
				'required' => true,
			),
			'posture' => array(
				'type'       => 'radio',
				'label'      => __( 'Bench use', 'mvweb-build-calc' ),
				'default'    => 'sitting',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'sitting' => __( 'Sitting (1.0 m² each)', 'mvweb-build-calc' ),
					'lying'   => __( 'Lying down (2.0 m² each)', 'mvweb-build-calc' ),
				),
			),
			'stove'   => array(
				'type'    => 'select',
				'label'   => __( 'Stove type', 'mvweb-build-calc' ),
				'default' => 'metal',
				'options' => array(
					'metal' => __( 'Compact metal stove (~1.0 m²)', 'mvweb-build-calc' ),
					'brick' => __( 'Brick stove (~2.0 m²)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$bathers = max( 1, (int) ( $i['bathers'] ?? 3 ) );
			$posture = (string) ( $i['posture'] ?? 'sitting' );
			$stove   = (string) ( $i['stove'] ?? 'metal' );

			$per_person = ( 'lying' === $posture ) ? 2.0 : 1.0;
			$stove_zone = ( 'brick' === $stove ) ? 2.0 : 1.0;

			$area = $bathers * $per_person + $stove_zone;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: bathers count, 2: per-person m², 3: stove zone m² */
				__( '%1$d bathers × %2$s m² + stove zone %3$s m².', 'mvweb-build-calc' ),
				$bathers,
				mvweb_bc_format_number( $per_person, 1 ),
				mvweb_bc_format_number( $stove_zone, 1 )
			);

			$hints[] = __( 'Keep at least 0.5 m of non-combustible clearance between the stove and any wood surfaces; a metal stove needs heat shielding.', 'mvweb-build-calc' );

			$hints[] = __( 'A steam room ceiling is usually 2.1–2.3 m — lower than living rooms to hold the heat.', 'mvweb-build-calc' );

			$hints[] = __( 'Ergonomic planning guide based on common practice, not a building code requirement.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
