<?php
/**
 * Calculator: window/door reveal (slope) area.
 *
 * Geometric calculation. The reveals are the two jambs plus the head of the
 * opening (the sill is usually a separate windowsill board), each of the
 * opening dimension times the wall reveal depth, summed over the openings.
 *
 * Model:
 *   one = (2 × height + width) × depth
 *   area = one × count
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'window-slopes-area',
	array(
		'title'       => __( 'Reveals (slopes) area', 'mvweb-build-calc' ),
		'hub'         => 'openings',
		'description' => __( 'Calculates the area of the reveals (slopes) around window or door openings — the two jambs plus the head — times the wall reveal depth, summed over the openings. The sill is usually finished separately with a windowsill board. Geometric calculation.', 'mvweb-build-calc' ),
		'formula'     => 'area = (2 × height + width) × depth × count',
		'legend'      => array(
			'width'  => __( 'opening width, m', 'mvweb-build-calc' ),
			'height' => __( 'opening height, m', 'mvweb-build-calc' ),
			'depth'  => __( 'reveal depth (wall thickness minus the frame), m', 'mvweb-build-calc' ),
			'count'  => __( 'number of identical openings', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Reveals area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'width'        => array(
				'type'     => 'number',
				'label'    => __( 'Opening width', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.3,
				'max'      => 6,
				'step'     => 0.1,
				'required' => true,
			),
			'height'       => array(
				'type'     => 'number',
				'label'    => __( 'Opening height', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.3,
				'max'      => 4,
				'step'     => 0.1,
				'required' => true,
			),
			'depth'        => array(
				'type'     => 'number',
				'label'    => __( 'Reveal depth', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 0.2,
				'min'      => 0.02,
				'max'      => 0.6,
				'step'     => 0.01,
				'required' => true,
			),
			'count'        => array(
				'type'     => 'number',
				'label'    => __( 'Number of openings', 'mvweb-build-calc' ),
				'default'  => 1,
				'min'      => 1,
				'max'      => 100,
				'step'     => 1,
				'required' => true,
			),
			'include_sill' => array(
				'type'    => 'radio',
				'label'   => __( 'Include the bottom reveal', 'mvweb-build-calc' ),
				'default' => 'no',
				'options' => array(
					'no'  => __( 'No — windowsill board (default)', 'mvweb-build-calc' ),
					'yes' => __( 'Yes — plastered all round (e.g. a door)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$width   = max( 0.01, (float) ( $i['width'] ?? 0 ) );
			$height  = max( 0.01, (float) ( $i['height'] ?? 0 ) );
			$depth   = max( 0.001, (float) ( $i['depth'] ?? 0.2 ) );
			$count   = max( 1, (int) ( $i['count'] ?? 1 ) );
			$bottom  = ( 'yes' === (string) ( $i['include_sill'] ?? 'no' ) );

			// Perimeter of reveals: two jambs + head, plus optionally the bottom.
			$run = 2 * $height + $width + ( $bottom ? $width : 0 );
			$one = $run * $depth;
			$area = $one * $count;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: one opening reveal area m², 2: count */
				__( 'One opening %1$s m² of reveals × %2$d.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $one, 2 ),
				$count
			);

			$hints[] = __( 'Reveal depth is the wall thickness minus the part taken by the frame. Add a small reserve for trimming.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
