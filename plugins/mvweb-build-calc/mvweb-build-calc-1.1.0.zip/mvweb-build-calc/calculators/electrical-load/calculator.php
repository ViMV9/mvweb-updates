<?php
/**
 * Calculator: house electrical load.
 *
 * Preliminary estimate. Sums the installed power of the appliance groups, then
 * applies a demand (diversity) factor — not everything runs at once — to get
 * the design load, and converts it to a line current for sizing the supply.
 *
 * Model:
 *   design = installed × demand_factor
 *   current = design × 1000 / (voltage × pf)
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'electrical-load',
	array(
		'title'       => __( 'Electrical load', 'mvweb-build-calc' ),
		'hub'         => 'engineering',
		'description' => __( 'Estimates the design electrical load of a house from the installed power and a demand (diversity) factor — not everything runs at once — and converts it to a line current for sizing the supply and the main breaker. Preliminary estimate based on common diversity factors (SP 256.1325800), not an electrical design.', 'mvweb-build-calc' ),
		'formula'     => 'design = installed × demand; current = design × 1000 / (U × pf)',
		'legend'      => array(
			'installed' => __( 'total installed power, kW', 'mvweb-build-calc' ),
			'demand'    => __( 'demand (diversity) factor', 'mvweb-build-calc' ),
			'current'   => __( 'design line current, A', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Design load', 'mvweb-build-calc' ),
			'unit'     => __( 'kW', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'installed'     => array(
				'type'     => 'number',
				'label'    => __( 'Total installed power', 'mvweb-build-calc' ),
				'unit'     => __( 'kW', 'mvweb-build-calc' ),
				'default'  => 15,
				'min'      => 1,
				'max'      => 200,
				'step'     => 0.5,
				'required' => true,
			),
			'supply'        => array(
				'type'       => 'radio',
				'label'      => __( 'Supply type', 'mvweb-build-calc' ),
				'default'    => 'single',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'single' => __( 'Single-phase (220 V)', 'mvweb-build-calc' ),
					'three'  => __( 'Three-phase (380 V)', 'mvweb-build-calc' ),
				),
			),
			'electric_heat' => array(
				'type'       => 'radio',
				'label'      => __( 'Main load profile', 'mvweb-build-calc' ),
				'default'    => 'no',
				'required'   => true,
				'full_width' => true,
				'options'    => array(
					'no'  => __( 'Mostly lighting and sockets (factor 0.6)', 'mvweb-build-calc' ),
					'yes' => __( 'Electric heating / boiler (factor 0.8)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$installed = max( 0.1, (float) ( $i['installed'] ?? 0 ) );
			$supply    = (string) ( $i['supply'] ?? 'single' );
			$heat      = ( 'yes' === (string) ( $i['electric_heat'] ?? 'no' ) );

			$demand = $heat ? 0.8 : 0.6;
			$design = $installed * $demand;

			$pf = 0.95;
			if ( 'three' === $supply ) {
				// Three-phase line current: P / (√3 × U_line × pf), U_line = 380 V.
				$current = ( $design * 1000 ) / ( 1.732 * 380 * $pf );
			} else {
				$current = ( $design * 1000 ) / ( 220 * $pf );
			}

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: design load kW, 2: demand factor */
				__( 'Design load %1$s kW (demand factor %2$s).', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $design, 1 ),
				mvweb_bc_format_number( $demand, 2 )
			);

			$hints[] = sprintf(
				/* translators: %s: line current A */
				__( 'Line current about %s A — size the main breaker to the next standard rating above it.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $current, 0 )
			);

			$hints[] = __( 'A three-phase supply spreads the load across phases and lowers the per-line current. The utility connection limit may cap the available power.', 'mvweb-build-calc' );

			$hints[] = __( 'Preliminary estimate based on common diversity factors (SP 256.1325800). It does not replace an electrical design.', 'mvweb-build-calc' );

			return array(
				'value' => $design,
				'hints' => $hints,
			);
		},
	)
);
