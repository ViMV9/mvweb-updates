<?php
/**
 * Calculator: garage door area.
 *
 * Geometric calculation. Returns the area of the garage door leaf from the
 * opening width and height, with recommended minimum sizes for one or two
 * cars.
 *
 * Model:
 *   area = width × height
 *
 * @package MVweb_BC
 * @since   1.0.10
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'garage-door-area',
	array(
		'title'       => __( 'Garage door area', 'mvweb-build-calc' ),
		'hub'         => 'openings',
		'description' => __( 'Calculates the area of a garage door from the opening width and height, and recommends minimum sizes for one or two cars. Use it to size the door and the lintel above it. Geometric calculation.', 'mvweb-build-calc' ),
		'formula'     => 'A = width × height',
		'legend'      => array(
			'A'      => __( 'door area, m²', 'mvweb-build-calc' ),
			'width'  => __( 'opening width, m', 'mvweb-build-calc' ),
			'height' => __( 'opening height, m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Door area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'width'  => array(
				'type'     => 'number',
				'label'    => __( 'Opening width', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 2.5,
				'min'      => 2,
				'max'      => 8,
				'step'     => 0.1,
				'required' => true,
			),
			'height' => array(
				'type'     => 'number',
				'label'    => __( 'Opening height', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'default'  => 2.2,
				'min'      => 1.8,
				'max'      => 4,
				'step'     => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$width  = max( 0.1, (float) ( $i['width'] ?? 0 ) );
			$height = max( 0.1, (float) ( $i['height'] ?? 0 ) );

			$area = $width * $height;

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: width m, 2: height m */
				__( 'Door %1$s × %2$s m.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $width, 1 ),
				mvweb_bc_format_number( $height, 1 )
			);

			if ( $width < 2.5 ) {
				$hints[] = __( 'For one car aim for at least 2.5 m wide; a tight 2.3 m leaves little room for mirrors and door margins.', 'mvweb-build-calc' );
			}

			$hints[] = __( 'For one car a 2.5 × 2.2 m door is comfortable; for two cars in one opening use about 4.5–5 m wide. Sectional doors need extra headroom above the opening.', 'mvweb-build-calc' );

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
