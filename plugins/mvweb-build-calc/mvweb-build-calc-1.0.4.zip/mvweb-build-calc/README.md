# MVweb Build Calc

Construction calculator library for WordPress. Calculators are rendered via the `[mvweb_calc id="..."]` shortcode.

## Requirements

- WordPress 6.4+
- PHP 8.0+

## Installation

1. Upload the `mvweb-build-calc` folder to `/wp-content/plugins/`.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Configure under **MVweb Hub → MVweb Build Calc**.
4. Insert `[mvweb_calc id="..."]` on any page where you want a calculator to appear.

## Adding a New Calculator

Each calculator lives in its own folder under `calculators/{slug}/` with a single `calculator.php`
file that registers the calculator via `mvweb_bc_register()`. See the bundled
`calculators/foundation-concrete-volume/` for a reference implementation.

## License

GPL v2 or later. See [LICENSE](https://www.gnu.org/licenses/gpl-2.0.html).

## Author

[MVweb](https://mvweb.ru)
