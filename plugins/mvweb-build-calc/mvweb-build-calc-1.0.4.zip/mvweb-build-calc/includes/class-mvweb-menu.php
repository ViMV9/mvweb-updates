<?php
/**
 * MVweb Plugins Menu Registration
 *
 * Handles the registration of the main MVweb Plugins menu
 * that all MVweb plugins use as their parent menu.
 *
 * This file should be included in each MVweb plugin's includes/ folder.
 * The version check ensures only the newest version is loaded.
 *
 * @package MVweb\Shared
 * @since   1.0.0
 * @version 2.2.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Version of this file - increment when making changes.
if ( ! defined( 'MVWEB_MENU_VERSION' ) ) {
	define( 'MVWEB_MENU_VERSION', '2.2.0' );
}

// Skip if a newer version is already loaded.
if ( class_exists( 'MVweb_Menu' ) ) {
	return;
}

/**
 * Class MVweb_Menu
 *
 * Handles the main MVweb Plugins menu registration.
 *
 * @since 1.0.0
 */
class MVweb_Menu {

	/**
	 * Menu slug for new format plugins.
	 *
	 * Using a unique slug to avoid conflicts with old plugins.
	 *
	 * @var string
	 */
	const MENU_SLUG = 'mvweb-hub';

	/**
	 * Menu capability.
	 *
	 * @var string
	 */
	const CAPABILITY = 'manage_options';

	/**
	 * Menu position.
	 *
	 * Placed at the bottom of the menu after all standard WordPress items.
	 * String type prevents PHP from casting to int (avoids collisions).
	 *
	 * @var string
	 */
	const POSITION = '99.5';

	/**
	 * Instance of this class.
	 *
	 * @var MVweb_Menu
	 */
	private static $instance = null;

	/**
	 * Textdomain of the first plugin that loaded this class.
	 *
	 * @var string
	 */
	private $textdomain = 'mvweb';

	/**
	 * Flag to track if menu was registered by this class.
	 *
	 * @var bool
	 */
	private static $menu_registered = false;

	/**
	 * Cache of registered plugins collected via filter.
	 *
	 * @since 2.0.0
	 * @var array|null
	 */
	private $registered_plugins = null;

	/**
	 * Get singleton instance.
	 *
	 * @since 1.0.0
	 * @return MVweb_Menu
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		$this->textdomain = $this->detect_textdomain();

		add_action( 'admin_menu', array( $this, 'register_menu' ), 9 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_styles' ) );
	}

	/**
	 * Prevent cloning of the singleton instance.
	 *
	 * @since 2.2.0
	 * @return void
	 */
	private function __clone() {}

	/**
	 * Prevent unserialization of the singleton instance.
	 *
	 * @since 2.2.0
	 * @return void
	 */
	public function __wakeup() {
		throw new \Exception( 'Cannot unserialize singleton MVweb_Menu.' );
	}

	/**
	 * Detect textdomain from loaded MVweb plugins.
	 *
	 * @since 1.0.0
	 * @return string Textdomain.
	 */
	private function detect_textdomain() {
		if ( defined( 'MVWEB_PT_VERSION' ) ) {
			return 'mvweb-price-table';
		}
		if ( defined( 'MVWEB_PU_VERSION' ) ) {
			return 'mvweb-pop-up';
		}
		if ( defined( 'MVWEB_DE_VERSION' ) ) {
			return 'mvweb-data-export';
		}
		if ( defined( 'MVWEB_CP_VERSION' ) ) {
			return 'mvweb-child-pages';
		}
		if ( defined( 'MVWEB_PI_VERSION' ) ) {
			return 'mvweb-price-importer';
		}
		if ( defined( 'MVWEB_BC_VERSION' ) ) {
			return 'mvweb-build-calc';
		}

		return 'mvweb';
	}

	/**
	 * Get plugins registered via 'mvweb_registered_plugins' filter.
	 *
	 * Each plugin registers itself with add_filter in its entry point.
	 * Results are cached after the first call.
	 *
	 * @since 2.0.0
	 * @return array Associative array keyed by plugin slug.
	 */
	private function get_registered_plugins() {
		if ( null === $this->registered_plugins ) {
			$plugins = apply_filters( 'mvweb_registered_plugins', array() );

			$indexed = array();
			foreach ( $plugins as $key => $plugin ) {
				if ( is_string( $key ) && ! empty( $plugin['name'] ) ) {
					$indexed[ $key ] = $plugin;
				}
			}

			$this->registered_plugins = $indexed;
		}

		return $this->registered_plugins;
	}

	/**
	 * Register the main MVweb Plugins menu.
	 *
	 * Uses unique slug 'mvweb-hub' to avoid conflicts with old plugins
	 * that may use 'mvweb-plugins' slug.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register_menu() {
		if ( self::$menu_registered ) {
			return;
		}

		if ( ! empty( $GLOBALS['admin_page_hooks'][ self::MENU_SLUG ] ) ) {
			self::$menu_registered = true;
			return;
		}

		add_menu_page(
			__( 'MVweb Hub', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			__( 'MVweb Hub', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			self::CAPABILITY,
			self::MENU_SLUG,
			array( $this, 'render_about_page' ),
			$this->get_menu_icon(),
			self::POSITION
		);

		add_submenu_page(
			self::MENU_SLUG,
			__( 'MVweb Plugins', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			__( 'All Plugins', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			self::CAPABILITY,
			self::MENU_SLUG,
			array( $this, 'render_about_page' )
		);

		self::$menu_registered = true;
	}

	/**
	 * Get menu icon.
	 *
	 * @since 1.0.0
	 * @return string Base64 encoded SVG icon or dashicon.
	 */
	private function get_menu_icon() {
		return 'dashicons-admin-generic';
	}

	/**
	 * Render the About MVweb page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function render_about_page() {
		$installed_plugins  = $this->get_mvweb_plugins();
		$registered_plugins = $this->get_registered_plugins();
		$td                 = $this->textdomain;

		$installed_slugs = array();
		foreach ( array_keys( $installed_plugins ) as $pfile ) {
			$installed_slugs[] = dirname( $pfile );
		}
		$not_installed = array_diff_key( $registered_plugins, array_flip( $installed_slugs ) );
		?>
		<?php $logo_url = $this->find_logo_url(); ?>
		<div class="wrap mvweb-hub">

			<div class="mvweb-hero">
				<?php if ( $logo_url ) : ?>
					<img class="mvweb-hero__logo-img" src="<?php echo esc_url( $logo_url ); ?>" alt="MVweb" width="64" height="64" />
				<?php else : ?>
					<div class="mvweb-hero__logo">MV</div>
				<?php endif; ?>
				<div>
					<h1 class="mvweb-hero__title"><?php esc_html_e( 'MVweb Plugins', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></h1>
					<p class="mvweb-hero__desc">
						<?php esc_html_e( 'MVweb is a web development studio specializing in WordPress plugins and themes. We create high-quality, secure, and well-documented solutions for WordPress.', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
					</p>
				</div>
				<div>
					<a href="https://mvweb.ru" target="_blank" rel="noopener noreferrer" class="mvweb-btn mvweb-btn--primary">
						<?php esc_html_e( 'Visit our website', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?> &rarr;
					</a>
				</div>
			</div>

			<?php if ( ! empty( $installed_plugins ) ) : ?>
				<div class="mvweb-section-title">
					<h2><?php esc_html_e( 'Installed plugins', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></h2>
					<span class="mvweb-section-title__count"><?php echo esc_html( count( $installed_plugins ) ); ?></span>
				</div>

				<div class="mvweb-plugins-grid">
					<?php foreach ( $installed_plugins as $plugin_file => $plugin ) : ?>
						<?php
						$is_active    = is_plugin_active( $plugin_file );
						$plugin_slug  = dirname( $plugin_file );
						$plugin_info  = isset( $registered_plugins[ $plugin_slug ] ) ? $registered_plugins[ $plugin_slug ] : array();
						$settings_url = ! empty( $plugin_info['settings_url'] )
							? admin_url( $plugin_info['settings_url'] )
							: null;
						$icon         = $this->get_plugin_icon_label( $plugin_slug, $plugin['Name'] );
						?>
						<div class="mvweb-card <?php echo $is_active ? '' : 'mvweb-card--inactive'; ?>">
							<div class="mvweb-plugin-card__head">
								<div class="mvweb-plugin-card__id">
									<div class="mvweb-plugin-card__icon"><?php echo esc_html( $icon ); ?></div>
									<div>
										<h3 class="mvweb-plugin-card__title"><?php echo esc_html( $plugin['Name'] ); ?></h3>
										<p class="mvweb-plugin-card__version">v<?php echo esc_html( $plugin['Version'] ); ?></p>
									</div>
								</div>
								<span class="mvweb-badge <?php echo $is_active ? 'mvweb-badge--success' : 'mvweb-badge--neutral'; ?>">
									<?php echo $is_active ? esc_html__( 'active', $td ) : esc_html__( 'inactive', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
								</span>
							</div>
							<p class="mvweb-plugin-card__desc"><?php echo esc_html( $plugin['Description'] ); ?></p>
							<div class="mvweb-plugin-card__actions">
								<?php if ( $is_active && $settings_url ) : ?>
									<a href="<?php echo esc_url( $settings_url ); ?>" class="mvweb-btn mvweb-btn--primary mvweb-btn--sm">
										<?php esc_html_e( 'Settings', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								<?php elseif ( ! $is_active ) : ?>
									<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'plugins.php?action=activate&plugin=' . urlencode( $plugin_file ) ), 'activate-plugin_' . $plugin_file ) ); ?>" class="mvweb-btn mvweb-btn--primary mvweb-btn--sm">
										<?php esc_html_e( 'Activate', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								<?php endif; ?>
								<?php if ( ! empty( $plugin['PluginURI'] ) ) : ?>
									<a href="<?php echo esc_url( $plugin['PluginURI'] ); ?>" target="_blank" rel="noopener noreferrer" class="mvweb-btn mvweb-btn--sm">
										<?php esc_html_e( 'Docs', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								<?php endif; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php else : ?>
				<div class="mvweb-empty">
					<p><?php esc_html_e( 'No MVweb plugins installed yet.', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></p>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $not_installed ) ) : ?>
				<div class="mvweb-section-title">
					<h2><?php esc_html_e( 'Available plugins', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></h2>
					<span class="mvweb-section-title__count"><?php echo esc_html( count( $not_installed ) ); ?></span>
				</div>
				<div class="mvweb-plugins-grid">
					<?php foreach ( $not_installed as $slug => $plugin_info ) : ?>
						<?php $icon = $this->get_plugin_icon_label( $slug, $plugin_info['name'] ); ?>
						<div class="mvweb-card mvweb-card--available">
							<div class="mvweb-plugin-card__head">
								<div class="mvweb-plugin-card__id">
									<div class="mvweb-plugin-card__icon"><?php echo esc_html( $icon ); ?></div>
									<div>
										<h3 class="mvweb-plugin-card__title"><?php echo esc_html( $plugin_info['name'] ); ?></h3>
									</div>
								</div>
								<span class="mvweb-badge mvweb-badge--warning">
									<?php esc_html_e( 'not installed', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
								</span>
							</div>
							<p class="mvweb-plugin-card__desc"><?php echo esc_html( $plugin_info['description'] ); ?></p>
							<?php if ( ! empty( $plugin_info['url'] ) ) : ?>
								<div class="mvweb-plugin-card__actions">
									<a href="<?php echo esc_url( $plugin_info['url'] ); ?>" target="_blank" rel="noopener noreferrer" class="mvweb-btn mvweb-btn--sm">
										<?php esc_html_e( 'Learn More', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Build a short 2-letter icon label from plugin slug (mvweb-build-calc → BC).
	 *
	 * @since 2.2.0
	 * @param string $slug Plugin directory slug.
	 * @param string $name Plugin display name (fallback).
	 * @return string Two-letter uppercase label.
	 */
	private function get_plugin_icon_label( $slug, $name = '' ) {
		$slug = preg_replace( '/^mvweb-/', '', (string) $slug );
		$parts = preg_split( '/[-_\s]+/', $slug );
		if ( ! empty( $parts ) ) {
			if ( count( $parts ) === 1 && strlen( $parts[0] ) >= 2 ) {
				return strtoupper( substr( $parts[0], 0, 2 ) );
			}
			if ( count( $parts ) >= 2 ) {
				return strtoupper( substr( $parts[0], 0, 1 ) . substr( $parts[1], 0, 1 ) );
			}
		}
		return strtoupper( substr( preg_replace( '/[^A-Za-z]/', '', $name ), 0, 2 ) );
	}

	/**
	 * Get list of installed MVweb plugins.
	 *
	 * Only returns plugins registered via 'mvweb_registered_plugins' filter.
	 *
	 * @since 1.0.0
	 * @return array List of MVweb plugins.
	 */
	private function get_mvweb_plugins() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$all_plugins   = get_plugins();
		$mvweb_plugins = array();
		$allowed_slugs = array_keys( $this->get_registered_plugins() );

		foreach ( $all_plugins as $plugin_file => $plugin_data ) {
			$plugin_slug = dirname( $plugin_file );

			if ( in_array( $plugin_slug, $allowed_slugs, true ) ) {
				$mvweb_plugins[ $plugin_file ] = $plugin_data;
			}
		}

		/**
		 * Translate plugin headers (Name, Description) for each plugin.
		 *
		 * WordPress get_plugins() caches data WITHOUT translations ($translate = false).
		 * We must explicitly call _get_plugin_data_markup_translate() to get
		 * translated headers, just like get_plugin_data() does with $translate = true.
		 */
		if ( function_exists( '_get_plugin_data_markup_translate' ) ) {
			foreach ( $mvweb_plugins as $plugin_file => $plugin_data ) {
				$mvweb_plugins[ $plugin_file ] = _get_plugin_data_markup_translate(
					WP_PLUGIN_DIR . '/' . $plugin_file,
					$plugin_data,
					false,
					true
				);
			}
		}

		return $mvweb_plugins;
	}

	/**
	 * Enqueue admin styles for MVweb Hub page.
	 *
	 * Loads admin.css from the first installed and active MVweb plugin.
	 * All MVweb plugins ship identical admin.css (UI Kit) — first match is enough.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_styles( $hook ) {
		if ( 'toplevel_page_' . self::MENU_SLUG !== $hook ) {
			return;
		}

		$source = $this->find_admin_css_source();
		if ( null === $source ) {
			return;
		}

		wp_enqueue_style(
			'mvweb-hub-ui-kit',
			$source['url'],
			array(),
			$source['ver']
		);

		wp_add_inline_style(
			'mvweb-hub-ui-kit',
			'.mvweb-hero__logo-img{width:64px;height:64px;border-radius:var(--radius-2xl);display:block;flex-shrink:0;}'
		);
	}

	/**
	 * Locate mv-logo-violet.png from any installed MVweb plugin.
	 *
	 * Falls back to the textual "MV" placeholder if no plugin bundles it.
	 *
	 * @since 2.2.0
	 * @return string|null Logo URL or null if not found.
	 */
	private function find_logo_url() {
		foreach ( array_keys( $this->get_registered_plugins() ) as $slug ) {
			$path = WP_PLUGIN_DIR . '/' . $slug . '/images/mv-logo-violet.png';
			if ( file_exists( $path ) ) {
				return plugins_url( $slug . '/images/mv-logo-violet.png' );
			}
		}
		return null;
	}

	/**
	 * Locate admin.css from any installed MVweb plugin.
	 *
	 * @since 2.2.0
	 * @return array|null { url, ver } or null if not found.
	 */
	private function find_admin_css_source() {
		$candidates = array( 'admin/css/admin.min.css', 'admin/css/admin.css' );

		foreach ( array_keys( $this->get_registered_plugins() ) as $slug ) {
			foreach ( $candidates as $rel ) {
				$path = WP_PLUGIN_DIR . '/' . $slug . '/' . $rel;
				if ( file_exists( $path ) ) {
					$mtime = @filemtime( $path );
					return array(
						'url' => plugins_url( $slug . '/' . $rel ),
						'ver' => $mtime ? (string) $mtime : MVWEB_MENU_VERSION,
					);
				}
			}
		}

		return null;
	}

	/**
	 * Get menu slug.
	 *
	 * @since 1.0.0
	 * @return string Menu slug.
	 */
	public static function get_menu_slug() {
		return self::MENU_SLUG;
	}
}

// Initialize the menu immediately.
// For production, use mu-plugin mvweb-menu-init.php for guaranteed early initialization.
MVweb_Menu::get_instance();
