<?php
/**
 * Helper functions for MVweb Build Calc.
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default appearance settings shared between admin and frontend.
 *
 * The admin class is not loaded on the frontend, so the shortcode cannot
 * reference its constants. Both sides read defaults from here to keep them
 * in sync.
 *
 * @since 1.0.0
 * @return array<string, mixed>
 */
function mvweb_bc_get_appearance_defaults(): array {
	return array(
		'theme'          => 'default',
		'border_radius'  => 8,
		'border_color'   => '',
		'border_width'   => 1,
		'form_border'    => false,
		'button_variant' => 'outline',
		'button_color'   => '',
	);
}

/**
 * Format a number for display using plugin settings.
 *
 * Uses `number_format()` with thousands and decimal separators from settings.
 * Default thousands separator is the no-break space (U+00A0) — recommended
 * for Russian locale to avoid line breaks between digit groups.
 *
 * The decimals setting acts as the MAXIMUM precision: the value is formatted
 * with that many places, then trailing zeros (and a dangling separator) are
 * stripped. A whole number drops its decimal part entirely (15.00 → "15"), a
 * short decimal keeps only its meaningful digits (2.50 → "2.5"), and small
 * values keep the precision they need (0.00001 stays "0.00001"). This avoids
 * padding zeros everywhere — both the main result and converter hints.
 *
 * @since 1.0.0
 * @param float    $value    Number to format.
 * @param int|null $decimals Maximum decimal places. Falls back to setting.
 * @return string
 */
function mvweb_bc_format_number( float $value, ?int $decimals = null ): string {
	$settings = get_option( 'mvweb_bc_settings', array() );

	$decimals      = $decimals ?? (int) ( $settings['decimals'] ?? 2 );
	$decimal_sep   = (string) ( $settings['decimal_sep'] ?? '.' );
	$thousands_sep = (string) ( $settings['thousands_sep'] ?? "\xC2\xA0" );

	$formatted = number_format( $value, max( 0, $decimals ), $decimal_sep, $thousands_sep );

	// Strip trailing zeros (and a dangling separator) so neither whole numbers
	// nor short decimals carry padding zeros. Only acts when a decimal part
	// exists, and small values keep every significant digit.
	if ( '' !== $decimal_sep && str_contains( $formatted, $decimal_sep ) ) {
		$formatted = rtrim( $formatted, '0' );
		$formatted = rtrim( $formatted, $decimal_sep );
	}

	return $formatted;
}

/**
 * Highlight a formula string for IDE-style display.
 *
 * Wraps numbers, operators and variable identifiers in spans with token
 * classes so the formula renders with syntax highlighting. Output is
 * already HTML-escaped — safe to echo directly.
 *
 * @since 1.0.0
 * @param string $formula Formula source (e.g. "V = L × W × H × (1 + reserve% / 100)").
 * @return string HTML with token spans.
 */
function mvweb_bc_highlight_formula( string $formula ): string {
	$pattern = '/(?P<id>[A-Za-zА-Яа-я_][A-Za-zА-Яа-я0-9_]*%?)|(?P<num>\d+(?:\.\d+)?)|(?P<op>[×х*+\-\/=()])/u';

	return (string) preg_replace_callback(
		$pattern,
		static function ( array $m ): string {
			if ( ! empty( $m['id'] ) ) {
				return '<span class="tok-var">' . esc_html( $m['id'] ) . '</span>';
			}
			if ( ! empty( $m['num'] ) ) {
				return '<span class="tok-num">' . esc_html( $m['num'] ) . '</span>';
			}
			if ( ! empty( $m['op'] ) ) {
				return '<span class="tok-op">' . esc_html( $m['op'] ) . '</span>';
			}
			return esc_html( $m[0] );
		},
		esc_html( $formula )
	);
}

/**
 * Flatten select/radio options to a value => label map regardless of grouping.
 *
 * Supports two option formats:
 * - Flat: ['value' => 'Label', ...]
 * - Grouped: ['Group Label' => ['value' => 'Label', ...], ...]
 *
 * Format is detected by checking whether the first value is an array.
 * Used by validators and summary builders that need uniform access to options.
 *
 * @since 1.0.0
 * @param array<int|string, mixed> $options Raw options config.
 * @return array<string, string> Flat map of value => label.
 */
function mvweb_bc_flatten_options( array $options ): array {
	if ( array() === $options ) {
		return array();
	}

	$first = reset( $options );

	if ( ! is_array( $first ) ) {
		$flat = array();
		foreach ( $options as $value => $label ) {
			$flat[ (string) $value ] = (string) $label;
		}
		return $flat;
	}

	$flat = array();
	foreach ( $options as $group_children ) {
		if ( ! is_array( $group_children ) ) {
			continue;
		}
		foreach ( $group_children as $value => $label ) {
			$flat[ (string) $value ] = (string) $label;
		}
	}
	return $flat;
}

/**
 * Sanitize a single input value according to its field config.
 *
 * @since 1.0.0
 * @param mixed $value        Raw value from $_POST.
 * @param array $field_config Field configuration (type, options, etc.).
 * @return int|float|string Sanitized value.
 */
function mvweb_bc_sanitize_input( mixed $value, array $field_config ): int|float|string {
	$type = (string) ( $field_config['type'] ?? 'number' );

	return match ( $type ) {
		'number'          => (float) $value,
		'select', 'radio' => sanitize_key( (string) $value ),
		default           => sanitize_text_field( (string) $value ),
	};
}

/**
 * Human-readable label for a hub slug.
 *
 * Calculators carry a machine `hub` slug ('foundation', 'converters', …). This
 * maps it to a localized title for the admin list. Unknown slugs fall back to a
 * humanized version of the slug itself.
 *
 * @since 1.0.4
 * @param string $hub Hub slug.
 * @return string Localized hub label.
 */
function mvweb_bc_hub_label( string $hub ): string {
	$labels = array(
		'foundation' => __( 'Foundation and earthworks', 'mvweb-build-calc' ),
		'converters' => __( 'Unit converters', 'mvweb-build-calc' ),
		'rooms'      => __( 'Rooms and areas', 'mvweb-build-calc' ),
		'lot'        => __( 'Plot and house placement', 'mvweb-build-calc' ),
		'structures' => __( 'Structural calculations', 'mvweb-build-calc' ),
		'layout'     => __( 'Layout and storeys', 'mvweb-build-calc' ),
		'walls'      => __( 'Walls and materials', 'mvweb-build-calc' ),
		'roof'       => __( 'Roof', 'mvweb-build-calc' ),
	);

	if ( isset( $labels[ $hub ] ) ) {
		return $labels[ $hub ];
	}

	if ( '' === $hub ) {
		return __( 'Other', 'mvweb-build-calc' );
	}

	return ucfirst( str_replace( '-', ' ', $hub ) );
}
