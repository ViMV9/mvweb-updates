<?php
/**
 * Plugin Name:       MVweb Build Calc
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-build-calc
 * Description:       Construction calculator library for WordPress. Calculators are rendered via the [mvweb_calc id="..."] shortcode.
 * Version:           1.1.1
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-build-calc
 * Domain Path:       /languages
 *
 * @package MVweb_BC
 *
 * @since 1.0.0 Initial release.
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'MVWEB_BC_VERSION' ) ) {
	return;
}

define( 'MVWEB_BC_VERSION', '1.1.1' );
define( 'MVWEB_BC_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_BC_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_BC_BASENAME', plugin_basename( __FILE__ ) );

$shared_path = dirname( dirname( MVWEB_BC_PATH ) ) . '/shared/';

if ( file_exists( MVWEB_BC_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_BC_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

if ( file_exists( MVWEB_BC_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_BC_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-build-calc' );
}

add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-build-calc'] = array(
		'name'         => __( 'MVweb Build Calc', 'mvweb-build-calc' ),
		'description'  => __( 'Construction calculator library.', 'mvweb-build-calc' ),
		'url'          => 'https://mvweb.ru/plugins/mvweb-build-calc',
		'settings_url' => 'admin.php?page=mvweb-build-calc',
		'textdomain'   => 'mvweb-build-calc',
	);
	return $plugins;
} );

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_bc_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-build-calc',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_bc_load_textdomain' );

require_once MVWEB_BC_PATH . 'includes/helpers.php';
require_once MVWEB_BC_PATH . 'includes/themes.php';
require_once MVWEB_BC_PATH . 'includes/class-mvweb-bc-registry.php';
require_once MVWEB_BC_PATH . 'includes/class-mvweb-bc-shortcode.php';
require_once MVWEB_BC_PATH . 'includes/class-mvweb-bc-ajax.php';

if ( is_admin() ) {
	require_once MVWEB_BC_PATH . 'includes/class-mvweb-bc-admin.php';
}

/**
 * Plugin activation hook.
 *
 * Reserved for future setup tasks. Currently a no-op — the plugin has no
 * custom tables, no CPT, no scheduled events.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_bc_activate() {
}
register_activation_hook( __FILE__, 'mvweb_bc_activate' );

/**
 * Plugin deactivation hook.
 *
 * Reserved for future teardown. Settings option is kept; full cleanup
 * happens in uninstall.php.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_bc_deactivate() {
}
register_deactivation_hook( __FILE__, 'mvweb_bc_deactivate' );
