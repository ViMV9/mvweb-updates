/**
 * Admin JavaScript for MVweb Build Calc.
 *
 * Handles sidebar tab navigation, WP color picker init, click-to-copy
 * shortcode input and formula dialog open/close.
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

(function ($) {
	'use strict';

	$(function () {
		initSidebarTabs();
		initColorPickers();
		initCopyInputs();
		initFormulaDialogs();
		initThemeDescription();
	});

	/**
	 * Sidebar tab navigation — Yoast-style layout (.mvweb-nav__link).
	 */
	function initSidebarTabs() {
		var $links = $('.mvweb-nav .mvweb-nav__link');
		var $panels = $('.mvweb-tab-content');

		if (!$links.length || !$panels.length) {
			return;
		}

		$links.on('click', function (event) {
			event.preventDefault();

			var $link = $(this);
			var target = $link.data('tab') || ($link.attr('href') || '').replace('#', '');

			if (!target) {
				return;
			}

			$links.removeClass('mvweb-nav__link--active');
			$panels.removeClass('active');

			$link.addClass('mvweb-nav__link--active');
			$('#' + target).addClass('active');

			if (window.history && typeof window.history.replaceState === 'function') {
				window.history.replaceState(null, '', '#' + target);
			}
		});

		var hash = (window.location.hash || '').replace('#', '');
		if (hash) {
			var $target = $links.filter('[data-tab="' + hash + '"]');
			if ($target.length) {
				$target.trigger('click');
			}
		}
	}

	/**
	 * WP color pickers on settings tab.
	 */
	function initColorPickers() {
		if (typeof $.fn.wpColorPicker !== 'function') {
			return;
		}

		$('.mvweb-bc-color-picker').wpColorPicker();
	}

	/**
	 * Click-to-copy shortcode input on Calculators tab.
	 */
	function initCopyInputs() {
		var $inputs = $('.mvweb-bc-copy-input');
		if (!$inputs.length) {
			return;
		}

		var i18n = (window.mvwebBCAdmin && window.mvwebBCAdmin.i18n) || {};
		var copiedLabel = i18n.copied || 'Copied!';
		var errorLabel = i18n.copyError || 'Copy failed.';

		$inputs.on('click focus', function () {
			var $input = $(this);
			var $popover = $input.siblings('.mvweb-bc-copy-popover');
			var value = $input.val();

			$input.trigger('select');

			var done = function (text, isError) {
				if (!$popover.length) {
					return;
				}

				$popover.find('.mvweb-bc-copy-popover__text').text(text);
				$popover.toggleClass('mvweb-bc-copy-popover--error', !!isError);
				$popover.prop('hidden', false);

				clearTimeout($popover.data('mvweb-bc-timer'));
				var timer = setTimeout(function () {
					$popover.prop('hidden', true);
				}, 1500);
				$popover.data('mvweb-bc-timer', timer);
			};

			if (navigator.clipboard && navigator.clipboard.writeText) {
				navigator.clipboard.writeText(String(value)).then(
					function () { done(copiedLabel, false); },
					function () { fallbackCopy(value, done, copiedLabel, errorLabel); }
				);
				return;
			}

			fallbackCopy(value, done, copiedLabel, errorLabel);
		});
	}

	function fallbackCopy(value, done, copiedLabel, errorLabel) {
		try {
			var ok = document.execCommand && document.execCommand('copy');
			done(ok ? copiedLabel : errorLabel, !ok);
		} catch (err) {
			done(errorLabel, true);
		}
	}

	/**
	 * Live theme description — when a theme is picked in the Appearance settings,
	 * swap the inline description hint to match. Data comes from the JSON map
	 * printed by PHP next to the select.
	 */
	function initThemeDescription() {
		var $select = $('#mvweb_bc_settings-theme');
		var $desc = $('[data-theme-desc]');
		var $data = $('.mvweb-bc-admin-theme__data');

		if (!$select.length || !$desc.length || !$data.length) {
			return;
		}

		var map = {};
		try {
			map = JSON.parse($data.text() || '{}');
		} catch (err) {
			return;
		}

		$select.on('change', function () {
			var slug = $(this).val();
			if (map.hasOwnProperty(slug)) {
				$desc.text(map[slug]);
			}
		});
	}

	/**
	 * Formula dialog — open/close handlers for the [data-mvweb-bc-open-dialog] buttons.
	 */
	function initFormulaDialogs() {
		$(document).on('click', '[data-mvweb-bc-open-dialog]', function (event) {
			event.preventDefault();
			var dialogId = $(this).data('mvweb-bc-open-dialog');
			if (!dialogId) {
				return;
			}
			var dialog = document.getElementById(dialogId);
			if (dialog && typeof dialog.showModal === 'function') {
				dialog.showModal();
			} else if (dialog) {
				dialog.setAttribute('open', '');
			}
		});

		$(document).on('click', '[data-mvweb-bc-close-dialog]', function (event) {
			event.preventDefault();
			var dialog = $(this).closest('dialog')[0];
			if (dialog && typeof dialog.close === 'function') {
				dialog.close();
			} else if (dialog) {
				dialog.removeAttribute('open');
			}
		});

		$(document).on('click', 'dialog.mvweb-bc-formula-dialog', function (event) {
			if (event.target === this) {
				if (typeof this.close === 'function') {
					this.close();
				} else {
					this.removeAttribute('open');
				}
			}
		});
	}
})(jQuery);
