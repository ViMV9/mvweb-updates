<?php
/**
 * Calculator: trench excavation volume with sloped walls.
 *
 * Formula (trapezoidal cross-section):
 *   width_top = width_bottom + 2 × m × depth
 *   V = length × depth × (width_bottom + width_top) / 2
 *
 * Where `m` is the slope coefficient that depends on soil type **and**
 * depth bracket per SNiP 12-04-2002, table 1 (§5.2.6).
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'trench-volume',
	array(
		'title'       => __( 'Trench excavation volume', 'mvweb-build-calc' ),
		'hub'         => 'foundation',
		'description' => __( 'Calculates the in-place volume of soil to excavate from a trench. Wall slope depends on soil type and depth bracket (≤1.5 m / ≤3 m / ≤5 m) per SNiP 12-04-2002, table 1.', 'mvweb-build-calc' ),
		'formula'     => 'Wt = Wb + 2 × m × H;   V = L × H × (Wb + Wt) / 2',
		'legend'      => array(
			'V'  => __( 'in-place soil volume, m³', 'mvweb-build-calc' ),
			'L'  => __( 'total trench length, m', 'mvweb-build-calc' ),
			'Wb' => __( 'trench bottom width, m', 'mvweb-build-calc' ),
			'Wt' => __( 'trench top width with slopes, m', 'mvweb-build-calc' ),
			'H'  => __( 'trench depth, m', 'mvweb-build-calc' ),
			'm'  => __( 'wall slope coefficient (depends on soil and depth)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Soil volume to excavate', 'mvweb-build-calc' ),
			'unit'     => __( 'm³', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'length'    => array(
				'type'     => 'number',
				'label'    => __( 'Total trench length', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 500,
				'step'     => 0.1,
				'required' => true,
			),
			'width'     => array(
				'type'     => 'number',
				'label'    => __( 'Bottom width', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.3,
				'max'      => 3,
				'step'     => 0.05,
				'default'  => 0.6,
				'required' => true,
			),
			'depth'     => array(
				'type'     => 'number',
				'label'    => __( 'Depth', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.3,
				'max'      => 5,
				'step'     => 0.1,
				'default'  => 1.5,
				'required' => true,
			),
			'soil_type' => array(
				'type'     => 'select',
				'label'    => __( 'Soil type', 'mvweb-build-calc' ),
				'default'  => 'loam',
				'required' => true,
				'options'  => array(
					'sand'       => __( 'Sand', 'mvweb-build-calc' ),
					'sandy_loam' => __( 'Sandy loam', 'mvweb-build-calc' ),
					'loam'       => __( 'Loam', 'mvweb-build-calc' ),
					'clay'       => __( 'Clay', 'mvweb-build-calc' ),
					'fill'       => __( 'Fill (made ground)', 'mvweb-build-calc' ),
					'rocky'      => __( 'Rocky / hard ground', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$length       = (float) ( $i['length'] ?? 0 );
			$width_bottom = (float) ( $i['width'] ?? 0 );
			$depth        = (float) ( $i['depth'] ?? 0 );
			$soil         = (string) ( $i['soil_type'] ?? 'loam' );

			// Slope coefficient m by soil type and depth bracket per SNiP 12-04-2002, table 1 (§5.2.6).
			// Inner array order is [m for depth <= 1.5 m, <= 3 m, <= 5 m].
			$slope_table = array(
				'sand'       => array( 0.50, 1.00, 1.00 ),
				'sandy_loam' => array( 0.25, 0.67, 0.85 ),
				'loam'       => array( 0.00, 0.50, 0.75 ),
				'clay'       => array( 0.00, 0.25, 0.50 ),
				'fill'       => array( 0.67, 1.00, 1.25 ),
				'rocky'      => array( 0.00, 0.00, 0.00 ),
			);

			$brackets = $slope_table[ $soil ] ?? $slope_table['loam'];
			if ( $depth <= 1.5 ) {
				$slope = $brackets[0];
			} elseif ( $depth <= 3.0 ) {
				$slope = $brackets[1];
			} else {
				$slope = $brackets[2];
			}

			$width_top = $width_bottom + 2 * $slope * $depth;
			$volume    = $length * $depth * ( $width_bottom + $width_top ) / 2;

			$hints = array();

			if ( $slope > 0 ) {
				$hints[] = sprintf(
					/* translators: 1: slope coefficient m, 2: top width in metres */
					__( 'Slope coefficient m = %1$s (SNiP 12-04-2002). Top width: %2$s m.', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $slope, 2 ),
					mvweb_bc_format_number( $width_top, 2 )
				);
			}

			if ( $width_bottom < 0.6 ) {
				$hints[] = __( 'Minimum clear width inside a trench for workers is 0.6 m (SNiP 12-04-2002, §5.1.5).', 'mvweb-build-calc' );
			}

			if ( $depth > 5.0 ) {
				$hints[] = __( 'Trenches deeper than 5 m are outside the table 1 range — use shoring or design with an engineer.', 'mvweb-build-calc' );
			}

			if ( 'sand' === $soil && $depth > 1.5 ) {
				$hints[] = __( 'Sandy soil deeper than 1.5 m always requires shoring of the walls (SNiP 12-04-2002).', 'mvweb-build-calc' );
			}

			if ( $depth > 1.5 && 0.0 === $slope ) {
				$hints[] = __( 'Vertical walls deeper than 1.5 m always require shoring regardless of soil type.', 'mvweb-build-calc' );
			}

			return array(
				'value' => $volume,
				'hints' => $hints,
			);
		},
	)
);
