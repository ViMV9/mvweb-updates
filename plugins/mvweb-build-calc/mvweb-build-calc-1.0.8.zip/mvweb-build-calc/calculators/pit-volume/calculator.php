<?php
/**
 * Calculator: excavation pit volume with sloped walls.
 *
 * Formula (Simpson's prismoidal rule, exact for a truncated rectangular pit):
 *   length_bot = length_top - 2 × m × depth
 *   width_bot  = width_top  - 2 × m × depth
 *   length_mid = (length_top + length_bot) / 2
 *   width_mid  = (width_top  + width_bot)  / 2
 *   V_in_situ  = depth / 6 × (A_top + 4 × A_mid + A_bot)
 *   V_loose    = V_in_situ × (1 + loosening_pct / 100)
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'pit-volume',
	array(
		'title'       => __( 'Excavation pit volume', 'mvweb-build-calc' ),
		'hub'         => 'foundation',
		'description' => __( 'Calculates the in-place soil volume of a rectangular excavation pit with sloped walls, plus the loose volume to remove from the site.', 'mvweb-build-calc' ),
		'formula'     => 'V = H / 6 × (At + 4 × Am + Ab)',
		'legend'      => array(
			'V'  => __( 'in-place soil volume, m³', 'mvweb-build-calc' ),
			'H'  => __( 'pit depth, m', 'mvweb-build-calc' ),
			'At' => __( 'area at the top of the pit, m²', 'mvweb-build-calc' ),
			'Ab' => __( 'area at the bottom of the pit, m²', 'mvweb-build-calc' ),
			'Am' => __( 'area at half-depth, m²', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Soil volume to excavate', 'mvweb-build-calc' ),
			'unit'     => __( 'm³', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'length'        => array(
				'type'     => 'number',
				'label'    => __( 'Length at the top', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'width'         => array(
				'type'     => 'number',
				'label'    => __( 'Width at the top', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'depth'         => array(
				'type'     => 'number',
				'label'    => __( 'Depth', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.3,
				'max'      => 5,
				'step'     => 0.1,
				'required' => true,
			),
			'soil_type'     => array(
				'type'     => 'select',
				'label'    => __( 'Soil type', 'mvweb-build-calc' ),
				'default'  => 'loam',
				'required' => true,
				'options'  => array(
					'sand'       => __( 'Sand', 'mvweb-build-calc' ),
					'sandy_loam' => __( 'Sandy loam', 'mvweb-build-calc' ),
					'loam'       => __( 'Loam', 'mvweb-build-calc' ),
					'clay'       => __( 'Clay', 'mvweb-build-calc' ),
					'fill'       => __( 'Fill (made ground)', 'mvweb-build-calc' ),
					'rocky'      => __( 'Rocky / hard ground', 'mvweb-build-calc' ),
				),
			),
			'loosening_pct' => array(
				'type'    => 'number',
				'label'   => __( 'Loosening factor', 'mvweb-build-calc' ),
				'unit'    => __( '%', 'mvweb-build-calc' ),
				'min'     => 0,
				'max'     => 40,
				'step'    => 1,
				'default' => 20,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$l_top         = (float) ( $i['length'] ?? 0 );
			$w_top         = (float) ( $i['width'] ?? 0 );
			$depth         = (float) ( $i['depth'] ?? 0 );
			$soil          = (string) ( $i['soil_type'] ?? 'loam' );
			$loosening_pct = (float) ( $i['loosening_pct'] ?? 20 );

			// Slope coefficient m by soil and depth bracket per SNiP 12-04-2002, table 1 (§5.2.6).
			// Inner array order: [m for depth <= 1.5 m, <= 3 m, <= 5 m].
			$slope_table = array(
				'sand'       => array( 0.50, 1.00, 1.00 ),
				'sandy_loam' => array( 0.25, 0.67, 0.85 ),
				'loam'       => array( 0.00, 0.50, 0.75 ),
				'clay'       => array( 0.00, 0.25, 0.50 ),
				'fill'       => array( 0.67, 1.00, 1.25 ),
				'rocky'      => array( 0.00, 0.00, 0.00 ),
			);

			$brackets = $slope_table[ $soil ] ?? $slope_table['loam'];
			if ( $depth <= 1.5 ) {
				$slope = $brackets[0];
			} elseif ( $depth <= 3.0 ) {
				$slope = $brackets[1];
			} else {
				$slope = $brackets[2];
			}

			$l_bot = max( 0.0, $l_top - 2 * $slope * $depth );
			$w_bot = max( 0.0, $w_top - 2 * $slope * $depth );

			$a_top = $l_top * $w_top;
			$a_bot = $l_bot * $w_bot;
			$l_mid = ( $l_top + $l_bot ) / 2;
			$w_mid = ( $w_top + $w_bot ) / 2;
			$a_mid = $l_mid * $w_mid;

			$v_in_situ = $depth / 6 * ( $a_top + 4 * $a_mid + $a_bot );
			$v_loose   = $v_in_situ * ( 1 + $loosening_pct / 100 );

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: loose volume in m³ */
				__( 'Loose volume to remove from site: %s m³.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $v_loose, 2 )
			);

			if ( $slope > 0 ) {
				$hints[] = sprintf(
					/* translators: 1: bottom length, 2: bottom width */
					__( 'Bottom dimensions with slopes: %1$s × %2$s m.', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $l_bot, 2 ),
					mvweb_bc_format_number( $w_bot, 2 )
				);
			}

			if ( $l_bot <= 0 || $w_bot <= 0 ) {
				$hints[] = __( 'Pit slopes converge before the bottom: check the depth or pick a smaller slope coefficient.', 'mvweb-build-calc' );
			}

			if ( $depth > 5.0 ) {
				$hints[] = __( 'Pits deeper than 5 m are outside the table 1 range — use shoring or design with an engineer.', 'mvweb-build-calc' );
			}

			if ( 'sand' === $soil && $depth > 1.5 ) {
				$hints[] = __( 'Sandy soil deeper than 1.5 m always requires shoring of the walls (SNiP 12-04-2002).', 'mvweb-build-calc' );
			}

			if ( $depth > 1.5 && 0.0 === $slope ) {
				$hints[] = __( 'Vertical walls deeper than 1.5 m always require shoring regardless of soil type.', 'mvweb-build-calc' );
			}

			return array(
				'value' => $v_in_situ,
				'hints' => $hints,
			);
		},
	)
);
