<?php
/**
 * Calculator: lot elevation difference + earthwork volume + foundation hint.
 *
 * Given the lot dimensions and slope, returns the elevation difference as the
 * main result, with cut/fill volumes for levelling and a foundation
 * recommendation based on slope class.
 *
 * Formula:
 *   slope_ratio depends on chosen slope_unit:
 *     percent  : s = slope_value / 100
 *     degrees  : s = tan(slope_value × π / 180)
 *     mm_per_m : s = slope_value / 1000
 *   elevation  = length × s
 *   V_cut = V_fill = width × length × elevation / 4
 *
 * The /4 factor corresponds to **balanced levelling to the mid-elevation**:
 * cut from the upper half of the lot exactly fills the lower half. This is
 * the most economical scheme (no soil import or removal). For full
 * levelling to the lowest point the volume would be width × length ×
 * elevation / 2 — double the value above; that variant is intentionally
 * not exposed because it is rarely economical and requires bringing in or
 * removing soil.
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'lot-elevation-difference',
	array(
		'title'       => __( 'Lot elevation difference and levelling volume', 'mvweb-build-calc' ),
		'hub'         => 'foundation',
		'description' => __( 'Calculates the elevation difference across the lot and the cut / fill volumes for **balanced levelling to the mid-elevation** (the most economical scheme — what you cut equals what you fill). Also suggests a foundation type for the slope class.', 'mvweb-build-calc' ),
		'formula'     => 'e = L × s;   Vc = Vf = W × L × e / 4',
		'legend'      => array(
			'e'  => __( 'elevation difference across the lot, m', 'mvweb-build-calc' ),
			'L'  => __( 'lot length along the slope, m', 'mvweb-build-calc' ),
			'W'  => __( 'lot width, m', 'mvweb-build-calc' ),
			's'  => __( 'slope ratio (rise / run)', 'mvweb-build-calc' ),
			'Vc' => __( 'volume to cut from the upper half, m³', 'mvweb-build-calc' ),
			'Vf' => __( 'volume to fill on the lower half, m³', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Elevation difference', 'mvweb-build-calc' ),
			'unit'     => __( 'm', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'length'      => array(
				'type'     => 'number',
				'label'    => __( 'Lot length along the slope', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 5,
				'max'      => 200,
				'step'     => 0.5,
				'required' => true,
			),
			'width'       => array(
				'type'     => 'number',
				'label'    => __( 'Lot width', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 5,
				'max'      => 200,
				'step'     => 0.5,
				'required' => true,
			),
			'slope_value' => array(
				'type'     => 'number',
				'label'    => __( 'Slope value', 'mvweb-build-calc' ),
				'unit'     => '',
				'min'      => 0.1,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'slope_unit'  => array(
				'type'     => 'select',
				'label'    => __( 'Slope units', 'mvweb-build-calc' ),
				'default'  => 'percent',
				'required' => true,
				'options'  => array(
					'percent'  => __( 'Percent (%)', 'mvweb-build-calc' ),
					'degrees'  => __( 'Degrees (°)', 'mvweb-build-calc' ),
					'mm_per_m' => __( 'Millimetres per metre (mm/m)', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$length      = (float) ( $i['length'] ?? 0 );
			$width       = (float) ( $i['width'] ?? 0 );
			$slope_value = (float) ( $i['slope_value'] ?? 0 );
			$slope_unit  = (string) ( $i['slope_unit'] ?? 'percent' );

			$ratio = match ( $slope_unit ) {
				'degrees'  => tan( $slope_value * M_PI / 180 ),
				'mm_per_m' => $slope_value / 1000,
				default    => $slope_value / 100, // percent.
			};

			$elevation = $length * $ratio;
			$v_cut     = $width * $length * $elevation / 4;
			$v_fill    = $v_cut;
			$pct       = $ratio * 100;

			$hints = array(
				__( 'Earthwork volume below assumes balanced levelling to the mid-elevation: what you cut equals what you fill, no soil import or removal.', 'mvweb-build-calc' ),
				sprintf(
					/* translators: %s: cut volume in m³ */
					__( 'Cut from the upper half: %s m³.', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $v_cut, 2 )
				),
				sprintf(
					/* translators: %s: fill volume in m³ */
					__( 'Fill on the lower half: %s m³.', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $v_fill, 2 )
				),
			);

			if ( $pct < 3 ) {
				$hints[] = __( 'Flat lot: any foundation type works, no additional measures required.', 'mvweb-build-calc' );
			} elseif ( $pct < 8 ) {
				$hints[] = __( 'Gentle slope: planning and drainage usually suffice. Any common foundation type is suitable.', 'mvweb-build-calc' );
			} elseif ( $pct < 20 ) {
				$hints[] = __( 'Moderate slope: consider a basement on the downhill side or a stepped foundation. Full levelling is possible but expensive.', 'mvweb-build-calc' );
			} else {
				$hints[] = __( 'Steep slope: pile or pile-grillage foundation is preferred. Avoid full levelling — design the house to follow the terrain.', 'mvweb-build-calc' );
			}

			if ( $elevation > 1.5 ) {
				$hints[] = __( 'Elevation greater than 1.5 m: it is usually cheaper to build a downhill basement than to level the lot.', 'mvweb-build-calc' );
			}

			return array(
				'value' => $elevation,
				'hints' => $hints,
			);
		},
	)
);
