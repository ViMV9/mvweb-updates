<?php
/**
 * Calculator: Pressure converter (Pa / bar / atm).
 *
 * Pick a source unit, enter a value, get the equivalent in every unit.
 * Base unit (the returned value) is "Pa".
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'convert-pressure',
	array(
		'title'       => __( 'Pressure converter (Pa / bar / atm)', 'mvweb-build-calc' ),
		'hub'         => 'converters',
		'description' => __( 'Converts a pressure between pascals, kilopascals, bars, atmospheres and millimetres of mercury.', 'mvweb-build-calc' ),
		'formula'     => 'X_base = X × k',
		'legend'      => array(
			'X_base' => __( 'value in the base unit', 'mvweb-build-calc' ),
			'X'      => __( 'entered value', 'mvweb-build-calc' ),
			'k'      => __( 'factor of the source unit to the base unit', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Pressure', 'mvweb-build-calc' ),
			'unit'     => __( 'Pa', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'from'  => array(
				'type'     => 'select',
				'label'    => __( 'Convert from', 'mvweb-build-calc' ),
				'options'  => array(
					'pa' => __( 'Pascals (Pa)', 'mvweb-build-calc' ),
					'kpa' => __( 'Kilopascals (kPa)', 'mvweb-build-calc' ),
					'bar' => __( 'Bars (bar)', 'mvweb-build-calc' ),
					'atm' => __( 'Atmospheres (atm)', 'mvweb-build-calc' ),
					'mmhg' => __( 'Millimetres of mercury (mmHg)', 'mvweb-build-calc' ),
				),
				'default'  => 'bar',
				'required' => true,
			),
			'value' => array(
				'type'     => 'number',
				'label'    => __( 'Value', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 100000000,
				'step'     => 'any',
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$factors = array(
				'pa' => 1.0,
				'kpa' => 1000.0,
				'bar' => 100000.0,
				'atm' => 101325.0,
				'mmhg' => 133.322,
			);
			$labels = array(
				'pa' => __( 'Pa', 'mvweb-build-calc' ),
				'kpa' => __( 'kPa', 'mvweb-build-calc' ),
				'bar' => __( 'bar', 'mvweb-build-calc' ),
				'atm' => __( 'atm', 'mvweb-build-calc' ),
				'mmhg' => __( 'mmHg', 'mvweb-build-calc' ),
			);

			$from = (string) ( $i['from'] ?? 'bar' );
			$val  = (float) ( $i['value'] ?? 0 );
			$base = $val * ( $factors[ $from ] ?? 1.0 );

			$hints = array();
			foreach ( $factors as $unit => $factor ) {
				$hints[] = sprintf( '%s %s', mvweb_bc_format_number( $base / $factor, 6 ), $labels[ $unit ] );
			}

			return array(
				'value' => $base,
				'hints' => $hints,
			);
		},
	)
);
