<?php
/**
 * Reference calculator: foundation concrete volume.
 *
 * Formula: V = L × W × H × (1 + reserve_pct / 100)
 * Result rounded to 2 decimal places (m³).
 *
 * Source: SNiP 52-01-2003 "Concrete and reinforced concrete structures",
 * standard reserve range 5-10% for casting losses.
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'foundation-concrete-volume',
	array(
		'title'       => __( 'Concrete volume for foundation', 'mvweb-build-calc' ),
		'hub'         => 'foundation',
		'description' => __( 'Calculates concrete mix volume including a reserve for casting losses.', 'mvweb-build-calc' ),
		'formula'     => 'V = L × W × H × (1 + reserve% / 100)',
		'legend'      => array(
			'V'        => __( 'concrete volume', 'mvweb-build-calc' ),
			'L'        => __( 'length, m', 'mvweb-build-calc' ),
			'W'        => __( 'width, m', 'mvweb-build-calc' ),
			'H'        => __( 'height (depth), m', 'mvweb-build-calc' ),
			'reserve%' => __( 'reserve for casting losses, %', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Concrete volume', 'mvweb-build-calc' ),
			'unit'     => __( 'm³', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'foundation_type' => array(
				'type'     => 'radio',
				'label'    => __( 'Foundation type', 'mvweb-build-calc' ),
				'default'  => 'strip',
				'required' => true,
				'options'  => array(
					'strip'  => __( 'Strip', 'mvweb-build-calc' ),
					'slab'   => __( 'Slab', 'mvweb-build-calc' ),
					'column' => __( 'Column', 'mvweb-build-calc' ),
				),
			),
			'length'          => array(
				'type'     => 'number',
				'label'    => __( 'Length', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.1,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'width'           => array(
				'type'     => 'number',
				'label'    => __( 'Width', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.1,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'height'          => array(
				'type'     => 'number',
				'label'    => __( 'Height / depth', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.1,
				'max'      => 10,
				'step'     => 0.1,
				'required' => true,
			),
			'reserve_pct'     => array(
				'type'    => 'number',
				'label'   => __( 'Reserve for losses', 'mvweb-build-calc' ),
				'unit'    => __( '%', 'mvweb-build-calc' ),
				'min'     => 0,
				'max'     => 30,
				'step'    => 1,
				'default' => 5,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$length  = (float) ( $i['length'] ?? 0 );
			$width   = (float) ( $i['width'] ?? 0 );
			$height  = (float) ( $i['height'] ?? 0 );
			$reserve = (float) ( $i['reserve_pct'] ?? 0 );
			$type    = (string) ( $i['foundation_type'] ?? 'strip' );

			$volume = $length * $width * $height * ( 1 + $reserve / 100 );

			$hints = array();

			if ( $reserve < 5 ) {
				$hints[] = __( 'A 5–10% reserve is recommended to account for casting losses.', 'mvweb-build-calc' );
			}

			if ( 'slab' === $type && ( $height < 0.3 || $height > 0.6 ) ) {
				$hints[] = __( 'A typical slab foundation depth is 0.3–0.6 m.', 'mvweb-build-calc' );
			}

			if ( 'column' === $type && $height > 3 * min( $length, $width ) ) {
				$hints[] = __( 'For column foundations, the height should usually not exceed three times the smaller cross-section.', 'mvweb-build-calc' );
			}

			return array(
				'value' => $volume,
				'hints' => $hints,
			);
		},
	)
);
