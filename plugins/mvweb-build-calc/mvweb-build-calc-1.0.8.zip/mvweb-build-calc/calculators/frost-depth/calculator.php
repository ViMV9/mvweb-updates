<?php
/**
 * Calculator: design frost penetration depth (foundation depth guide).
 *
 * Formulas from SP 22.13330.2016:
 *   eq. 5.3:  d_f  = k_h × d_fn
 *   eq. 5.4:  d_fn = d_0 × √Mt
 *
 * Soil influence comes through d_0 (eq. 5.4), not a separate multiplier in
 * eq. 5.3. To avoid recomputing √Mt at runtime we store the precomputed
 * d_fn for the reference soil (loam, d_0 = 0.23) per city and scale it
 * for other soils by d_0(soil) / 0.23.
 *
 * d_fn values for loam are based on climatic data from SP 131.13330.2020
 * (table 5.1 — mean monthly temperatures, summed |Mt| for negative months)
 * and cross-checked against published reference tables.
 *
 * k_h is a simplified 3-bucket version of SP 22 table 5.2 (full table is
 * a 4×5 matrix of foundation type × indoor temperature). For precise
 * design refer to the original norm.
 *
 * Cities are grouped by federal district. North-West and Central are
 * listed first (Saint Petersburg and Moscow on top of their groups);
 * remaining districts follow alphabetically.
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'frost-depth',
	array(
		'title'       => __( 'Frost penetration depth', 'mvweb-build-calc' ),
		'hub'         => 'foundation',
		'description' => __( 'Calculates the design frost penetration depth — the minimum depth at which the foundation footing should be placed. Based on SP 22.13330.2016 formulas 5.3 and 5.4; d_fn for loam is taken from published reference tables computed from SP 131.13330.2020 climatic data.', 'mvweb-build-calc' ),
		'formula'     => 'df = kh × dfn;   dfn = dfn_c × (d₀ / 0.23)',
		'legend'      => array(
			'df'    => __( 'design frost depth, m', 'mvweb-build-calc' ),
			'dfn'   => __( 'normative frost depth for the chosen soil, m', 'mvweb-build-calc' ),
			'dfn_c' => __( 'normative frost depth for loam (reference), m', 'mvweb-build-calc' ),
			'd₀'    => __( 'soil coefficient (loam=0.23, fine sand=0.28, coarse sand=0.30, gravel=0.34)', 'mvweb-build-calc' ),
			'kh'    => __( 'simplified heating coefficient (unheated=1.1, cold floor=0.7, warm floor=0.5)', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Design frost depth', 'mvweb-build-calc' ),
			'unit'     => __( 'm', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'city'      => array(
				'type'     => 'select',
				'label'    => __( 'City', 'mvweb-build-calc' ),
				'default'  => 'spb',
				'required' => true,
				'options'  => array(
					__( 'North-Western Federal District', 'mvweb-build-calc' ) => array(
						'spb'          => __( 'Saint Petersburg', 'mvweb-build-calc' ),
						'arkhangelsk'  => __( 'Arkhangelsk', 'mvweb-build-calc' ),
						'kaliningrad'  => __( 'Kaliningrad', 'mvweb-build-calc' ),
						'murmansk'     => __( 'Murmansk', 'mvweb-build-calc' ),
						'petrozavodsk' => __( 'Petrozavodsk', 'mvweb-build-calc' ),
						'vologda'      => __( 'Vologda', 'mvweb-build-calc' ),
					),
					__( 'Central Federal District', 'mvweb-build-calc' ) => array(
						'moscow'    => __( 'Moscow', 'mvweb-build-calc' ),
						'belgorod'  => __( 'Belgorod', 'mvweb-build-calc' ),
						'kursk'     => __( 'Kursk', 'mvweb-build-calc' ),
						'oryol'     => __( 'Oryol', 'mvweb-build-calc' ),
						'ryazan'    => __( 'Ryazan', 'mvweb-build-calc' ),
						'smolensk'  => __( 'Smolensk', 'mvweb-build-calc' ),
						'tver'      => __( 'Tver', 'mvweb-build-calc' ),
						'tula'      => __( 'Tula', 'mvweb-build-calc' ),
						'voronezh'  => __( 'Voronezh', 'mvweb-build-calc' ),
						'yaroslavl' => __( 'Yaroslavl', 'mvweb-build-calc' ),
					),
					__( 'Far Eastern Federal District', 'mvweb-build-calc' ) => array(
						'vladivostok' => __( 'Vladivostok', 'mvweb-build-calc' ),
						'yakutsk'     => __( 'Yakutsk', 'mvweb-build-calc' ),
					),
					__( 'Volga Federal District', 'mvweb-build-calc' ) => array(
						'kazan'   => __( 'Kazan', 'mvweb-build-calc' ),
						'nizhny'  => __( 'Nizhny Novgorod', 'mvweb-build-calc' ),
						'perm'    => __( 'Perm', 'mvweb-build-calc' ),
						'samara'  => __( 'Samara', 'mvweb-build-calc' ),
						'saratov' => __( 'Saratov', 'mvweb-build-calc' ),
						'ufa'     => __( 'Ufa', 'mvweb-build-calc' ),
					),
					__( 'Siberian Federal District', 'mvweb-build-calc' ) => array(
						'irkutsk'     => __( 'Irkutsk', 'mvweb-build-calc' ),
						'krasnoyarsk' => __( 'Krasnoyarsk', 'mvweb-build-calc' ),
						'novosibirsk' => __( 'Novosibirsk', 'mvweb-build-calc' ),
						'omsk'        => __( 'Omsk', 'mvweb-build-calc' ),
					),
					__( 'Ural Federal District', 'mvweb-build-calc' ) => array(
						'ekb'         => __( 'Yekaterinburg', 'mvweb-build-calc' ),
						'tyumen'      => __( 'Tyumen', 'mvweb-build-calc' ),
						'chelyabinsk' => __( 'Chelyabinsk', 'mvweb-build-calc' ),
					),
					__( 'Southern Federal District', 'mvweb-build-calc' ) => array(
						'krasnodar' => __( 'Krasnodar', 'mvweb-build-calc' ),
						'rostov'    => __( 'Rostov-on-Don', 'mvweb-build-calc' ),
					),
					__( 'Belarus', 'mvweb-build-calc' ) => array(
						'minsk' => __( 'Minsk', 'mvweb-build-calc' ),
					),
				),
			),
			'soil_type' => array(
				'type'     => 'select',
				'label'    => __( 'Soil type', 'mvweb-build-calc' ),
				'default'  => 'clay',
				'required' => true,
				'options'  => array(
					'clay'        => __( 'Clay or loam', 'mvweb-build-calc' ),
					'sand_fine'   => __( 'Fine or silty sand', 'mvweb-build-calc' ),
					'sand_coarse' => __( 'Coarse or medium sand', 'mvweb-build-calc' ),
					'gravel'      => __( 'Gravel or coarse-grained soil', 'mvweb-build-calc' ),
				),
			),
			'heated'    => array(
				'type'     => 'radio',
				'label'    => __( 'Building heating mode', 'mvweb-build-calc' ),
				'default'  => 'unheated',
				'required' => true,
				'options'  => array(
					'unheated'          => __( 'Unheated', 'mvweb-build-calc' ),
					'heated_cold_floor' => __( 'Heated, cold ground floor', 'mvweb-build-calc' ),
					'heated_warm_floor' => __( 'Heated, warm floor or basement', 'mvweb-build-calc' ),
				),
			),
		),
		'calculate'   => static function ( array $i ): array {
			$city   = (string) ( $i['city'] ?? 'moscow' );
			$soil   = (string) ( $i['soil_type'] ?? 'clay' );
			$heated = (string) ( $i['heated'] ?? 'unheated' );

			// Reference d_fn values for **loam / clay** (d_0 = 0.23), in metres.
			// Computed from SP 22.13330.2016 formula 5.4 (d_fn = d_0 × √Mt) using
			// climatic data from SP 131.13330.2020, table 5.1, and cross-checked
			// against published reference tables.
			$d_fn_clay_map = array(
				'spb'          => 1.20,
				'arkhangelsk'  => 1.60,
				'kaliningrad'  => 0.80,
				'murmansk'     => 1.80,
				'petrozavodsk' => 1.60,
				'vologda'      => 1.50,
				'moscow'       => 1.40,
				'belgorod'     => 1.00,
				'kursk'        => 1.20,
				'oryol'        => 1.30,
				'ryazan'       => 1.50,
				'smolensk'     => 1.30,
				'tver'         => 1.40,
				'tula'         => 1.40,
				'voronezh'     => 1.40,
				'yaroslavl'    => 1.50,
				'vladivostok'  => 1.50,
				'yakutsk'      => 2.50,
				'kazan'        => 1.70,
				'nizhny'       => 1.50,
				'perm'         => 1.80,
				'samara'       => 1.60,
				'saratov'      => 1.50,
				'ufa'          => 1.80,
				'irkutsk'      => 2.20,
				'krasnoyarsk'  => 2.00,
				'novosibirsk'  => 2.20,
				'omsk'         => 2.00,
				'ekb'          => 1.78,
				'tyumen'       => 2.00,
				'chelyabinsk'  => 1.90,
				'krasnodar'    => 0.80,
				'rostov'       => 0.90,
				'minsk'        => 1.00,
			);

			$d_fn_clay = $d_fn_clay_map[ $city ] ?? 1.40;

			// Soil-specific d_0 coefficient (SP 22.13330.2016, formula 5.4).
			// d_fn for non-clay soils is d_fn_clay scaled by d_0(soil) / d_0(clay).
			$d_0 = match ( $soil ) {
				'sand_fine'   => 0.28,
				'sand_coarse' => 0.30,
				'gravel'      => 0.34,
				default       => 0.23, // clay or loam — reference soil.
			};

			$d_fn = $d_fn_clay * ( $d_0 / 0.23 );

			// k_h — simplified to three buckets from SP 22.13330.2016, table 5.2.
			// The full table is a 4×5 matrix (foundation type × indoor temperature);
			// the values below correspond to typical residential cases.
			$k_h = match ( $heated ) {
				'heated_cold_floor' => 0.7,
				'heated_warm_floor' => 0.5,
				default             => 1.1, // unheated.
			};

			// SP 22.13330.2016, formula 5.3.
			$d_f = $k_h * $d_fn;

			$d_f_rounded = ceil( $d_f * 10 ) / 10;

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: rounded design frost depth in metres */
				__( 'Foundation footing must be placed not higher than %s m below the ground.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $d_f_rounded, 1 )
			);

			if ( 'clay' !== $soil ) {
				$hints[] = __( 'Sands and coarse-grained soils are considered non-frost-susceptible — embedment may be reduced (SP 22.13330.2016, §6.8.10).', 'mvweb-build-calc' );
			}

			if ( 'heated_warm_floor' === $heated || 'heated_cold_floor' === $heated ) {
				$hints[] = __( 'k_h is a simplification of SP 22.13330.2016 table 5.2. The full table depends on indoor temperature — for precise design refer to the original norm.', 'mvweb-build-calc' );
			}

			return array(
				'value' => $d_f,
				'hints' => $hints,
			);
		},
	)
);
