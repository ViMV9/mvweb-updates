<?php
/**
 * Calculator: Density converter (kg/m³ / g/cm³ / t/m³).
 *
 * Pick a source unit, enter a value, get the equivalent in every unit.
 * Base unit (the returned value) is "kg/m³".
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'convert-density',
	array(
		'title'       => __( 'Density converter (kg/m³ / g/cm³ / t/m³)', 'mvweb-build-calc' ),
		'hub'         => 'converters',
		'description' => __( 'Converts a density between kilograms per cubic metre, grams per cubic centimetre and tonnes per cubic metre.', 'mvweb-build-calc' ),
		'formula'     => 'X_base = X × k',
		'legend'      => array(
			'X_base' => __( 'value in the base unit', 'mvweb-build-calc' ),
			'X'      => __( 'entered value', 'mvweb-build-calc' ),
			'k'      => __( 'factor of the source unit to the base unit', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Density', 'mvweb-build-calc' ),
			'unit'     => __( 'kg/m³', 'mvweb-build-calc' ),
			'decimals' => 3,
		),
		'fields'      => array(
			'from'  => array(
				'type'     => 'select',
				'label'    => __( 'Convert from', 'mvweb-build-calc' ),
				'options'  => array(
					'kgm3' => __( 'Kilograms per cubic metre (kg/m³)', 'mvweb-build-calc' ),
					'gcm3' => __( 'Grams per cubic centimetre (g/cm³)', 'mvweb-build-calc' ),
					'tm3' => __( 'Tonnes per cubic metre (t/m³)', 'mvweb-build-calc' ),
				),
				'default'  => 'kgm3',
				'required' => true,
			),
			'value' => array(
				'type'     => 'number',
				'label'    => __( 'Value', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 100000,
				'step'     => 'any',
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$factors = array(
				'kgm3' => 1.0,
				'gcm3' => 1000.0,
				'tm3' => 1000.0,
			);
			$labels = array(
				'kgm3' => __( 'kg/m³', 'mvweb-build-calc' ),
				'gcm3' => __( 'g/cm³', 'mvweb-build-calc' ),
				'tm3' => __( 't/m³', 'mvweb-build-calc' ),
			);

			$from = (string) ( $i['from'] ?? 'kgm3' );
			$val  = (float) ( $i['value'] ?? 0 );
			$base = $val * ( $factors[ $from ] ?? 1.0 );

			$hints = array();
			foreach ( $factors as $unit => $factor ) {
				$hints[] = sprintf( '%s %s', mvweb_bc_format_number( $base / $factor, 3 ), $labels[ $unit ] );
			}

			return array(
				'value' => $base,
				'hints' => $hints,
			);
		},
	)
);
