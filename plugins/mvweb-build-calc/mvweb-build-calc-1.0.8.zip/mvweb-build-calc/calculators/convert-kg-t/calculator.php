<?php
/**
 * Calculator: Mass converter (kg / t).
 *
 * Pick a source unit, enter a value, get the equivalent in every unit.
 * Base unit (the returned value) is "kg".
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'convert-kg-t',
	array(
		'title'       => __( 'Mass converter (kg / t)', 'mvweb-build-calc' ),
		'hub'         => 'converters',
		'description' => __( 'Converts a mass between kilograms and tonnes.', 'mvweb-build-calc' ),
		'formula'     => 'X_base = X × k',
		'legend'      => array(
			'X_base' => __( 'value in the base unit', 'mvweb-build-calc' ),
			'X'      => __( 'entered value', 'mvweb-build-calc' ),
			'k'      => __( 'factor of the source unit to the base unit', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Mass', 'mvweb-build-calc' ),
			'unit'     => __( 'kg', 'mvweb-build-calc' ),
			'decimals' => 3,
		),
		'fields'      => array(
			'from'  => array(
				'type'     => 'select',
				'label'    => __( 'Convert from', 'mvweb-build-calc' ),
				'options'  => array(
					'kg' => __( 'Kilograms (kg)', 'mvweb-build-calc' ),
					't' => __( 'Tonnes (t)', 'mvweb-build-calc' ),
				),
				'default'  => 'kg',
				'required' => true,
			),
			'value' => array(
				'type'     => 'number',
				'label'    => __( 'Value', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 10000000,
				'step'     => 'any',
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$factors = array(
				'kg' => 1.0,
				't' => 1000.0,
			);
			$labels = array(
				'kg' => __( 'kg', 'mvweb-build-calc' ),
				't' => __( 't', 'mvweb-build-calc' ),
			);

			$from = (string) ( $i['from'] ?? 'kg' );
			$val  = (float) ( $i['value'] ?? 0 );
			$base = $val * ( $factors[ $from ] ?? 1.0 );

			$hints = array();
			foreach ( $factors as $unit => $factor ) {
				$hints[] = sprintf( '%s %s', mvweb_bc_format_number( $base / $factor, 3 ), $labels[ $unit ] );
			}

			return array(
				'value' => $base,
				'hints' => $hints,
			);
		},
	)
);
