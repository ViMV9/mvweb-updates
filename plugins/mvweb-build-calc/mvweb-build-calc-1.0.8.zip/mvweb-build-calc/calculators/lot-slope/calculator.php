<?php
/**
 * Calculator: lot slope — units converter.
 *
 * Pure unit conversion between rise/run and percent / degrees / mm-per-m.
 * No foundation recommendations here — those belong to lot-elevation-difference.
 *
 * Formula:
 *   slope_ratio = elevation_diff / distance
 *   slope_pct   = slope_ratio × 100
 *   slope_deg   = atan(slope_ratio) × 180 / π
 *   slope_mm_m  = slope_ratio × 1000
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'lot-slope',
	array(
		'title'       => __( 'Lot slope (units converter)', 'mvweb-build-calc' ),
		'hub'         => 'foundation',
		'description' => __( 'Converts a rise-over-run measurement into percent, degrees and millimetres per metre.', 'mvweb-build-calc' ),
		'formula'     => 's = Δh / L',
		'legend'      => array(
			's'  => __( 'slope ratio (rise / run)', 'mvweb-build-calc' ),
			'Δh' => __( 'rise (vertical), m', 'mvweb-build-calc' ),
			'L'  => __( 'run (horizontal), m', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Slope', 'mvweb-build-calc' ),
			'unit'     => __( '%', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'elevation_diff' => array(
				'type'     => 'number',
				'label'    => __( 'Elevation difference', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.05,
				'max'      => 20,
				'step'     => 0.05,
				'required' => true,
			),
			'distance'       => array(
				'type'     => 'number',
				'label'    => __( 'Horizontal distance', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 500,
				'step'     => 0.1,
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$rise = (float) ( $i['elevation_diff'] ?? 0 );
			$run  = (float) ( $i['distance'] ?? 0 );

			$ratio = $run > 0 ? $rise / $run : 0.0;

			$pct      = $ratio * 100;
			$degrees  = atan( $ratio ) * 180 / M_PI;
			$mm_per_m = $ratio * 1000;

			$hints = array(
				sprintf(
					/* translators: %s: slope in degrees */
					__( 'Angle: %s°', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $degrees, 2 )
				),
				sprintf(
					/* translators: %s: slope in mm per metre */
					__( 'Rise per metre: %s mm/m', 'mvweb-build-calc' ),
					mvweb_bc_format_number( $mm_per_m, 0 )
				),
			);

			return array(
				'value' => $pct,
				'hints' => $hints,
			);
		},
	)
);
