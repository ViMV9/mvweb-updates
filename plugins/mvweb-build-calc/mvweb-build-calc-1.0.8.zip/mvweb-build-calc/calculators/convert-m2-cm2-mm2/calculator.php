<?php
/**
 * Calculator: Area converter (mm² / cm² / m²).
 *
 * Pick a source unit, enter a value, get the equivalent in every unit.
 * Base unit (the returned value) is "m²".
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'convert-m2-cm2-mm2',
	array(
		'title'       => __( 'Area converter (mm² / cm² / m²)', 'mvweb-build-calc' ),
		'hub'         => 'converters',
		'description' => __( 'Converts an area between square millimetres, square centimetres and square metres.', 'mvweb-build-calc' ),
		'formula'     => 'X_base = X × k',
		'legend'      => array(
			'X_base' => __( 'value in the base unit', 'mvweb-build-calc' ),
			'X'      => __( 'entered value', 'mvweb-build-calc' ),
			'k'      => __( 'factor of the source unit to the base unit', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 6,
		),
		'fields'      => array(
			'from'  => array(
				'type'     => 'select',
				'label'    => __( 'Convert from', 'mvweb-build-calc' ),
				'options'  => array(
					'mm2' => __( 'Square millimetres (mm²)', 'mvweb-build-calc' ),
					'cm2' => __( 'Square centimetres (cm²)', 'mvweb-build-calc' ),
					'm2' => __( 'Square metres (m²)', 'mvweb-build-calc' ),
				),
				'default'  => 'm2',
				'required' => true,
			),
			'value' => array(
				'type'     => 'number',
				'label'    => __( 'Value', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 1000000,
				'step'     => 'any',
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$factors = array(
				'mm2' => 0.000001,
				'cm2' => 0.0001,
				'm2' => 1.0,
			);
			$labels = array(
				'mm2' => __( 'mm²', 'mvweb-build-calc' ),
				'cm2' => __( 'cm²', 'mvweb-build-calc' ),
				'm2' => __( 'm²', 'mvweb-build-calc' ),
			);

			$from = (string) ( $i['from'] ?? 'm2' );
			$val  = (float) ( $i['value'] ?? 0 );
			$base = $val * ( $factors[ $from ] ?? 1.0 );

			$hints = array();
			foreach ( $factors as $unit => $factor ) {
				$hints[] = sprintf( '%s %s', mvweb_bc_format_number( $base / $factor, 6 ), $labels[ $unit ] );
			}

			return array(
				'value' => $base,
				'hints' => $hints,
			);
		},
	)
);
