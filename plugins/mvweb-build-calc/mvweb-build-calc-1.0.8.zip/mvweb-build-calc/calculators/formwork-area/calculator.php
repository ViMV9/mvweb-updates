<?php
/**
 * Calculator: formwork area for strip or slab foundation.
 *
 * Formula:
 *   strip: S = 2 × perimeter × height × (1 + reserve% / 100)
 *   slab:  S = perimeter × height × (1 + reserve% / 100)
 *
 * Result is plywood-sheet equivalent (1.22 × 2.44 m, area 2.9768 m²)
 * reported in hints.
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'formwork-area',
	array(
		'title'       => __( 'Formwork area', 'mvweb-build-calc' ),
		'hub'         => 'foundation',
		'description' => __( 'Calculates the area of formwork needed for a strip or slab foundation, plus an equivalent count of standard plywood sheets.', 'mvweb-build-calc' ),
		'formula'     => 'S = k × P × H × (1 + r% / 100)',
		'legend'      => array(
			'S'  => __( 'formwork area, m²', 'mvweb-build-calc' ),
			'k'  => __( 'wall multiplier (2 for strip, 1 for slab)', 'mvweb-build-calc' ),
			'P'  => __( 'foundation perimeter, m', 'mvweb-build-calc' ),
			'H'  => __( 'formwork height, m', 'mvweb-build-calc' ),
			'r%' => __( 'reserve for offcuts, %', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Formwork area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'foundation_type' => array(
				'type'     => 'radio',
				'label'    => __( 'Foundation type', 'mvweb-build-calc' ),
				'default'  => 'strip',
				'required' => true,
				'options'  => array(
					'strip' => __( 'Strip', 'mvweb-build-calc' ),
					'slab'  => __( 'Slab', 'mvweb-build-calc' ),
				),
			),
			'perimeter'       => array(
				'type'     => 'number',
				'label'    => __( 'Perimeter', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 4,
				'max'      => 500,
				'step'     => 0.1,
				'required' => true,
			),
			'height'          => array(
				'type'     => 'number',
				'label'    => __( 'Formwork height', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.2,
				'max'      => 3,
				'step'     => 0.05,
				'default'  => 0.6,
				'required' => true,
			),
			'reserve_pct'     => array(
				'type'    => 'number',
				'label'   => __( 'Reserve for offcuts', 'mvweb-build-calc' ),
				'unit'    => __( '%', 'mvweb-build-calc' ),
				'min'     => 0,
				'max'     => 20,
				'step'    => 1,
				'default' => 10,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$type        = (string) ( $i['foundation_type'] ?? 'strip' );
			$perimeter   = (float) ( $i['perimeter'] ?? 0 );
			$height      = (float) ( $i['height'] ?? 0 );
			$reserve_pct = (float) ( $i['reserve_pct'] ?? 0 );

			$k       = 'slab' === $type ? 1.0 : 2.0;
			$area    = $k * $perimeter * $height * ( 1 + $reserve_pct / 100 );
			$plywood = (int) ceil( $area / 2.9768 );

			$hints = array();

			$hints[] = sprintf(
				/* translators: %d: number of plywood sheets */
				_n( '%d sheet of 1.22 × 2.44 m plywood.', '%d sheets of 1.22 × 2.44 m plywood.', $plywood, 'mvweb-build-calc' ),
				$plywood
			);

			if ( $height > 1.5 ) {
				$hints[] = __( 'For formwork higher than 1.5 m, reinforce with transverse ties to resist the concrete pressure.', 'mvweb-build-calc' );
			}

			if ( 'strip' === $type && $height < 0.3 ) {
				$hints[] = __( 'Strip foundation depth below 0.3 m is unusual — check the input.', 'mvweb-build-calc' );
			}

			return array(
				'value' => $area,
				'hints' => $hints,
			);
		},
	)
);
