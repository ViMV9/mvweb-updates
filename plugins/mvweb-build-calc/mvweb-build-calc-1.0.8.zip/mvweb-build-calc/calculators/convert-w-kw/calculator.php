<?php
/**
 * Calculator: Power converter (W / kW).
 *
 * Pick a source unit, enter a value, get the equivalent in every unit.
 * Base unit (the returned value) is "W".
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'convert-w-kw',
	array(
		'title'       => __( 'Power converter (W / kW)', 'mvweb-build-calc' ),
		'hub'         => 'converters',
		'description' => __( 'Converts a power between watts and kilowatts.', 'mvweb-build-calc' ),
		'formula'     => 'X_base = X × k',
		'legend'      => array(
			'X_base' => __( 'value in the base unit', 'mvweb-build-calc' ),
			'X'      => __( 'entered value', 'mvweb-build-calc' ),
			'k'      => __( 'factor of the source unit to the base unit', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Power', 'mvweb-build-calc' ),
			'unit'     => __( 'W', 'mvweb-build-calc' ),
			'decimals' => 3,
		),
		'fields'      => array(
			'from'  => array(
				'type'     => 'select',
				'label'    => __( 'Convert from', 'mvweb-build-calc' ),
				'options'  => array(
					'w' => __( 'Watts (W)', 'mvweb-build-calc' ),
					'kw' => __( 'Kilowatts (kW)', 'mvweb-build-calc' ),
				),
				'default'  => 'kw',
				'required' => true,
			),
			'value' => array(
				'type'     => 'number',
				'label'    => __( 'Value', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 100000000,
				'step'     => 'any',
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$factors = array(
				'w' => 1.0,
				'kw' => 1000.0,
			);
			$labels = array(
				'w' => __( 'W', 'mvweb-build-calc' ),
				'kw' => __( 'kW', 'mvweb-build-calc' ),
			);

			$from = (string) ( $i['from'] ?? 'kw' );
			$val  = (float) ( $i['value'] ?? 0 );
			$base = $val * ( $factors[ $from ] ?? 1.0 );

			$hints = array();
			foreach ( $factors as $unit => $factor ) {
				$hints[] = sprintf( '%s %s', mvweb_bc_format_number( $base / $factor, 3 ), $labels[ $unit ] );
			}

			return array(
				'value' => $base,
				'hints' => $hints,
			);
		},
	)
);
