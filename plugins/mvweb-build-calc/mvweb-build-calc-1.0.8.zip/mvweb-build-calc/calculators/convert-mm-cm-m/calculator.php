<?php
/**
 * Calculator: length converter — mm / cm / m.
 *
 * Pick a source unit, enter a value, get the equivalent in every length unit.
 * Base unit (the returned value) is the metre.
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'convert-mm-cm-m',
	array(
		'title'       => __( 'Length converter (mm / cm / m)', 'mvweb-build-calc' ),
		'hub'         => 'converters',
		'description' => __( 'Converts a length between millimetres, centimetres and metres.', 'mvweb-build-calc' ),
		'formula'     => 'L_base = L × k',
		'legend'      => array(
			'L_base' => __( 'value in metres', 'mvweb-build-calc' ),
			'L'      => __( 'entered value', 'mvweb-build-calc' ),
			'k'      => __( 'factor of the source unit to metres', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Length', 'mvweb-build-calc' ),
			'unit'     => __( 'm', 'mvweb-build-calc' ),
			'decimals' => 4,
		),
		'fields'      => array(
			'from'  => array(
				'type'     => 'select',
				'label'    => __( 'Convert from', 'mvweb-build-calc' ),
				'options'  => array(
					'mm' => __( 'Millimetres (mm)', 'mvweb-build-calc' ),
					'cm' => __( 'Centimetres (cm)', 'mvweb-build-calc' ),
					'm'  => __( 'Metres (m)', 'mvweb-build-calc' ),
				),
				'default'  => 'm',
				'required' => true,
			),
			'value' => array(
				'type'     => 'number',
				'label'    => __( 'Value', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 1000000,
				'step'     => 'any',
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$factors = array(
				'mm' => 0.001,
				'cm' => 0.01,
				'm'  => 1.0,
			);
			$labels = array(
				'mm' => __( 'mm', 'mvweb-build-calc' ),
				'cm' => __( 'cm', 'mvweb-build-calc' ),
				'm'  => __( 'm', 'mvweb-build-calc' ),
			);

			$from = (string) ( $i['from'] ?? 'm' );
			$val  = (float) ( $i['value'] ?? 0 );
			$base = $val * ( $factors[ $from ] ?? 1.0 );

			$hints = array();
			foreach ( $factors as $unit => $factor ) {
				$hints[] = sprintf( '%s %s', mvweb_bc_format_number( $base / $factor, 4 ), $labels[ $unit ] );
			}

			return array(
				'value' => $base,
				'hints' => $hints,
			);
		},
	)
);
