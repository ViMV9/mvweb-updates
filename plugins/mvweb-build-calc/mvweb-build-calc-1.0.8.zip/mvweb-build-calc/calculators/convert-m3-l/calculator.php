<?php
/**
 * Calculator: Volume converter (m³ / l).
 *
 * Pick a source unit, enter a value, get the equivalent in every unit.
 * Base unit (the returned value) is "l".
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'convert-m3-l',
	array(
		'title'       => __( 'Volume converter (m³ / l)', 'mvweb-build-calc' ),
		'hub'         => 'converters',
		'description' => __( 'Converts a volume between cubic metres and litres.', 'mvweb-build-calc' ),
		'formula'     => 'X_base = X × k',
		'legend'      => array(
			'X_base' => __( 'value in the base unit', 'mvweb-build-calc' ),
			'X'      => __( 'entered value', 'mvweb-build-calc' ),
			'k'      => __( 'factor of the source unit to the base unit', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Volume', 'mvweb-build-calc' ),
			'unit'     => __( 'l', 'mvweb-build-calc' ),
			'decimals' => 3,
		),
		'fields'      => array(
			'from'  => array(
				'type'     => 'select',
				'label'    => __( 'Convert from', 'mvweb-build-calc' ),
				'options'  => array(
					'm3' => __( 'Cubic metres (m³)', 'mvweb-build-calc' ),
					'l' => __( 'Litres (l)', 'mvweb-build-calc' ),
				),
				'default'  => 'm3',
				'required' => true,
			),
			'value' => array(
				'type'     => 'number',
				'label'    => __( 'Value', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 1000000,
				'step'     => 'any',
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$factors = array(
				'm3' => 1000.0,
				'l' => 1.0,
			);
			$labels = array(
				'm3' => __( 'm³', 'mvweb-build-calc' ),
				'l' => __( 'l', 'mvweb-build-calc' ),
			);

			$from = (string) ( $i['from'] ?? 'm3' );
			$val  = (float) ( $i['value'] ?? 0 );
			$base = $val * ( $factors[ $from ] ?? 1.0 );

			$hints = array();
			foreach ( $factors as $unit => $factor ) {
				$hints[] = sprintf( '%s %s', mvweb_bc_format_number( $base / $factor, 3 ), $labels[ $unit ] );
			}

			return array(
				'value' => $base,
				'hints' => $hints,
			);
		},
	)
);
