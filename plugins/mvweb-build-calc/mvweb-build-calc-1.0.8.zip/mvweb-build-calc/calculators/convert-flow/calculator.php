<?php
/**
 * Calculator: Flow converter (l/min / m³/h / l/s).
 *
 * Pick a source unit, enter a value, get the equivalent in every unit.
 * Base unit (the returned value) is "m³/h".
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'convert-flow',
	array(
		'title'       => __( 'Flow converter (l/min / m³/h / l/s)', 'mvweb-build-calc' ),
		'hub'         => 'converters',
		'description' => __( 'Converts a volumetric flow rate between litres per minute, litres per second and cubic metres per hour.', 'mvweb-build-calc' ),
		'formula'     => 'X_base = X × k',
		'legend'      => array(
			'X_base' => __( 'value in the base unit', 'mvweb-build-calc' ),
			'X'      => __( 'entered value', 'mvweb-build-calc' ),
			'k'      => __( 'factor of the source unit to the base unit', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Flow', 'mvweb-build-calc' ),
			'unit'     => __( 'm³/h', 'mvweb-build-calc' ),
			'decimals' => 3,
		),
		'fields'      => array(
			'from'  => array(
				'type'     => 'select',
				'label'    => __( 'Convert from', 'mvweb-build-calc' ),
				'options'  => array(
					'lmin' => __( 'Litres per minute (l/min)', 'mvweb-build-calc' ),
					'ls' => __( 'Litres per second (l/s)', 'mvweb-build-calc' ),
					'm3h' => __( 'Cubic metres per hour (m³/h)', 'mvweb-build-calc' ),
				),
				'default'  => 'm3h',
				'required' => true,
			),
			'value' => array(
				'type'     => 'number',
				'label'    => __( 'Value', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 100000,
				'step'     => 'any',
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$factors = array(
				'lmin' => 0.06,
				'ls' => 3.6,
				'm3h' => 1.0,
			);
			$labels = array(
				'lmin' => __( 'l/min', 'mvweb-build-calc' ),
				'ls' => __( 'l/s', 'mvweb-build-calc' ),
				'm3h' => __( 'm³/h', 'mvweb-build-calc' ),
			);

			$from = (string) ( $i['from'] ?? 'm3h' );
			$val  = (float) ( $i['value'] ?? 0 );
			$base = $val * ( $factors[ $from ] ?? 1.0 );

			$hints = array();
			foreach ( $factors as $unit => $factor ) {
				$hints[] = sprintf( '%s %s', mvweb_bc_format_number( $base / $factor, 3 ), $labels[ $unit ] );
			}

			return array(
				'value' => $base,
				'hints' => $hints,
			);
		},
	)
);
