<?php
/**
 * Calculator: temperature converter — °C / °F / K.
 *
 * Unlike the other converters in this hub, temperature is an affine
 * transformation (offset + scale), not a single multiplier, so it has its
 * own calculate(). The returned value is in degrees Celsius; the other two
 * scales are listed in the hints.
 *
 * Formula:
 *   °C = (°F − 32) × 5/9 = K − 273.15
 *   °F = °C × 9/5 + 32
 *   K  = °C + 273.15
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'convert-c-f',
	array(
		'title'       => __( 'Temperature converter (°C / °F / K)', 'mvweb-build-calc' ),
		'hub'         => 'converters',
		'description' => __( 'Converts a temperature between Celsius, Fahrenheit and Kelvin.', 'mvweb-build-calc' ),
		'formula'     => '°C = (°F − 32) × 5/9 = K − 273.15',
		'legend'      => array(
			'°C' => __( 'degrees Celsius', 'mvweb-build-calc' ),
			'°F' => __( 'degrees Fahrenheit', 'mvweb-build-calc' ),
			'K'  => __( 'kelvin', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Temperature', 'mvweb-build-calc' ),
			'unit'     => __( '°C', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'from'  => array(
				'type'     => 'select',
				'label'    => __( 'Convert from', 'mvweb-build-calc' ),
				'options'  => array(
					'c' => __( 'Celsius (°C)', 'mvweb-build-calc' ),
					'f' => __( 'Fahrenheit (°F)', 'mvweb-build-calc' ),
					'k' => __( 'Kelvin (K)', 'mvweb-build-calc' ),
				),
				'default'  => 'c',
				'required' => true,
			),
			'value' => array(
				'type'     => 'number',
				'label'    => __( 'Value', 'mvweb-build-calc' ),
				'min'      => -273.15,
				'max'      => 1000000,
				'step'     => 'any',
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$from = (string) ( $i['from'] ?? 'c' );
			$val  = (float) ( $i['value'] ?? 0 );

			switch ( $from ) {
				case 'f':
					$celsius = ( $val - 32 ) * 5 / 9;
					break;
				case 'k':
					$celsius = $val - 273.15;
					break;
				default:
					$celsius = $val;
					break;
			}

			$fahrenheit = $celsius * 9 / 5 + 32;
			$kelvin     = $celsius + 273.15;

			$hints = array(
				sprintf( '%s %s', mvweb_bc_format_number( $celsius, 2 ), __( '°C', 'mvweb-build-calc' ) ),
				sprintf( '%s %s', mvweb_bc_format_number( $fahrenheit, 2 ), __( '°F', 'mvweb-build-calc' ) ),
				sprintf( '%s %s', mvweb_bc_format_number( $kelvin, 2 ), __( 'K', 'mvweb-build-calc' ) ),
			);

			return array(
				'value' => $celsius,
				'hints' => $hints,
			);
		},
	)
);
