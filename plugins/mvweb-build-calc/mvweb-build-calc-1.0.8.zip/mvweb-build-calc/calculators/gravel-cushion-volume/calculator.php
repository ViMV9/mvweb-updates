<?php
/**
 * Calculator: gravel cushion volume under a foundation.
 *
 * Same shape as sand-cushion-volume but with gravel-specific defaults:
 * thicker cushion, lower compaction (gravel packs less than sand) and
 * higher bulk density.
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'gravel-cushion-volume',
	array(
		'title'       => __( 'Gravel cushion volume', 'mvweb-build-calc' ),
		'hub'         => 'foundation',
		'description' => __( 'Calculates the compacted volume of gravel or crushed stone under a foundation, plus the loose volume to order from the supplier.', 'mvweb-build-calc' ),
		'formula'     => 'V = L × W × t;   V_loose = V × k',
		'legend'      => array(
			'V'       => __( 'compacted (in-place) volume, m³', 'mvweb-build-calc' ),
			'L'       => __( 'cushion length, m', 'mvweb-build-calc' ),
			'W'       => __( 'cushion width, m', 'mvweb-build-calc' ),
			't'       => __( 'cushion thickness, m', 'mvweb-build-calc' ),
			'k'       => __( 'loose-to-compacted ratio (typically 1.25 for gravel)', 'mvweb-build-calc' ),
			'V_loose' => __( 'volume to order from supplier, m³', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Compacted gravel volume', 'mvweb-build-calc' ),
			'unit'     => __( 'm³', 'mvweb-build-calc' ),
			'decimals' => 2,
		),
		'fields'      => array(
			'length'            => array(
				'type'     => 'number',
				'label'    => __( 'Length', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 1,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'width'             => array(
				'type'     => 'number',
				'label'    => __( 'Width', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.3,
				'max'      => 100,
				'step'     => 0.1,
				'required' => true,
			),
			'thickness'         => array(
				'type'     => 'number',
				'label'    => __( 'Cushion thickness', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.05,
				'max'      => 0.5,
				'step'     => 0.05,
				'default'  => 0.20,
				'required' => true,
			),
			'compaction_factor' => array(
				'type'    => 'number',
				'label'   => __( 'Compaction factor', 'mvweb-build-calc' ),
				'tip'     => __( 'Ratio between loose and compacted gravel volume. Loose gravel from a supplier packs down after compaction, so order more than the final compacted volume.', 'mvweb-build-calc' ),
				'unit'    => '',
				'min'     => 1.0,
				'max'     => 1.4,
				'step'    => 0.05,
				'default' => 1.25,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$length    = (float) ( $i['length'] ?? 0 );
			$width     = (float) ( $i['width'] ?? 0 );
			$thickness = (float) ( $i['thickness'] ?? 0 );
			$cf        = (float) ( $i['compaction_factor'] ?? 1.25 );

			$v_compacted = $length * $width * $thickness;
			$v_loose     = $v_compacted * $cf;
			$tonnes      = $v_loose * 1.4; // Bulk density of crushed stone fr. 20–40 mm ~1.35–1.45 t/m³.

			$hints = array();

			$hints[] = sprintf(
				/* translators: 1: loose volume in m³, 2: approximate weight in tonnes */
				__( 'Order from supplier (loose): %1$s m³, approximately %2$s t.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $v_loose, 2 ),
				mvweb_bc_format_number( $tonnes, 1 )
			);

			if ( $thickness < 0.15 ) {
				$hints[] = __( 'Minimum gravel cushion thickness is typically 150 mm.', 'mvweb-build-calc' );
			}

			if ( $thickness > 0.3 ) {
				$hints[] = __( 'Cushions thicker than 300 mm should be placed and compacted in layers of 150–200 mm.', 'mvweb-build-calc' );
			}

			return array(
				'value' => $v_compacted,
				'hints' => $hints,
			);
		},
	)
);
