<?php
/**
 * Calculator: rebar quantity for strip foundation.
 *
 * Formula:
 *   L_long      = perimeter × longitudinal_count
 *   L_stirrups  = ceil(perimeter / stirrup_step) × stirrup_perimeter
 *   L_total     = (L_long + L_stirrups) × (1 + reserve% / 100)
 *   mass        = L_total × weight_per_m(rebar_diameter)
 *
 * Source: GOST 5781-82 (per-meter weight of hot-rolled steel rebar),
 * SP 63.13330.2018 "Concrete and reinforced concrete structures".
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'foundation-rebar',
	array(
		'title'       => __( 'Rebar for strip foundation', 'mvweb-build-calc' ),
		'hub'         => 'foundation',
		'description' => __( 'Calculates total length and mass of rebar for a strip foundation, including longitudinal bars and stirrups.', 'mvweb-build-calc' ),
		'formula'     => 'L = (P × n + ceil(P / s) × Ps) × (1 + r% / 100)',
		'legend'      => array(
			'L'  => __( 'total rebar length, m', 'mvweb-build-calc' ),
			'P'  => __( 'foundation perimeter, m', 'mvweb-build-calc' ),
			'n'  => __( 'number of longitudinal bars', 'mvweb-build-calc' ),
			's'  => __( 'stirrup spacing, m', 'mvweb-build-calc' ),
			'Ps' => __( 'single stirrup perimeter, m', 'mvweb-build-calc' ),
			'r%' => __( 'reserve for laps and offcuts, %', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Total rebar length', 'mvweb-build-calc' ),
			'unit'     => __( 'm', 'mvweb-build-calc' ),
			'decimals' => 1,
		),
		'fields'      => array(
			'perimeter'          => array(
				'type'     => 'number',
				'label'    => __( 'Foundation perimeter', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 4,
				'max'      => 500,
				'step'     => 0.1,
				'required' => true,
			),
			'rebar_diameter'     => array(
				'type'     => 'select',
				'label'    => __( 'Longitudinal rebar diameter', 'mvweb-build-calc' ),
				'unit'     => __( 'mm', 'mvweb-build-calc' ),
				'default'  => '12',
				'required' => true,
				'options'  => array(
					'8'  => '⌀8',
					'10' => '⌀10',
					'12' => '⌀12',
					'14' => '⌀14',
					'16' => '⌀16',
					'18' => '⌀18',
					'20' => '⌀20',
				),
			),
			'longitudinal_count' => array(
				'type'     => 'number',
				'label'    => __( 'Number of longitudinal bars', 'mvweb-build-calc' ),
				'unit'     => __( 'pcs', 'mvweb-build-calc' ),
				'min'      => 2,
				'max'      => 12,
				'step'     => 1,
				'default'  => 4,
				'required' => true,
			),
			'stirrup_step'       => array(
				'type'     => 'number',
				'label'    => __( 'Stirrup spacing', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.1,
				'max'      => 1.0,
				'step'     => 0.05,
				'default'  => 0.3,
				'required' => true,
			),
			'stirrup_perimeter'  => array(
				'type'     => 'number',
				'label'    => __( 'Single stirrup perimeter', 'mvweb-build-calc' ),
				'unit'     => __( 'm', 'mvweb-build-calc' ),
				'min'      => 0.5,
				'max'      => 5,
				'step'     => 0.1,
				'default'  => 1.4,
				'required' => true,
			),
			'reserve_pct'        => array(
				'type'    => 'number',
				'label'   => __( 'Reserve for laps and offcuts', 'mvweb-build-calc' ),
				'unit'    => __( '%', 'mvweb-build-calc' ),
				'min'     => 0,
				'max'     => 30,
				'step'    => 1,
				'default' => 10,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$perimeter   = (float) ( $i['perimeter'] ?? 0 );
			$diameter    = (int) ( $i['rebar_diameter'] ?? 12 );
			$n_long      = (int) ( $i['longitudinal_count'] ?? 0 );
			$step        = (float) ( $i['stirrup_step'] ?? 0.3 );
			$p_stirrup   = (float) ( $i['stirrup_perimeter'] ?? 0 );
			$reserve_pct = (float) ( $i['reserve_pct'] ?? 0 );

			// Per-meter weight of hot-rolled rebar, kg/m (GOST 5781-82, table 1).
			$weight_per_m = array(
				8  => 0.395,
				10 => 0.617,
				12 => 0.888,
				14 => 1.21,
				16 => 1.58,
				18 => 2.00,
				20 => 2.47,
			);

			$l_long     = $perimeter * $n_long;
			$n_stirrups = $step > 0 ? (int) ceil( $perimeter / $step ) : 0;
			$l_stirrup  = $n_stirrups * $p_stirrup;
			$l_total    = ( $l_long + $l_stirrup ) * ( 1 + $reserve_pct / 100 );
			$mass       = $l_total * ( $weight_per_m[ $diameter ] ?? 0.888 );
			$bars_117   = (int) ceil( $l_total / 11.7 );

			$hints = array();

			$hints[] = sprintf(
				/* translators: %s: mass in kilograms */
				__( 'Approximate mass: %s kg.', 'mvweb-build-calc' ),
				mvweb_bc_format_number( $mass, 1 )
			);

			$hints[] = sprintf(
				/* translators: %d: number of 11.7 m bars */
				_n( '%d bar of 11.7 m length.', '%d bars of 11.7 m length.', $bars_117, 'mvweb-build-calc' ),
				$bars_117
			);

			if ( $diameter < 10 ) {
				$hints[] = __( 'Minimum longitudinal rebar diameter for strip foundations is 10 mm (SP 63.13330.2018, §10.3.6).', 'mvweb-build-calc' );
			}

			if ( $step > 0.5 ) {
				$hints[] = __( 'Stirrup spacing greater than 500 mm is not recommended for working reinforcement.', 'mvweb-build-calc' );
			}

			if ( $n_long < 4 ) {
				$hints[] = __( 'At least 4 longitudinal bars (2 top + 2 bottom) are recommended for strip foundations.', 'mvweb-build-calc' );
			}

			return array(
				'value' => $l_total,
				'hints' => $hints,
			);
		},
	)
);
