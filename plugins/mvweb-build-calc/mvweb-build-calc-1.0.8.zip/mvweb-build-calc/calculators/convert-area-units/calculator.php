<?php
/**
 * Calculator: Land area converter (sotka / hectare / m² / acre).
 *
 * Pick a source unit, enter a value, get the equivalent in every unit.
 * Base unit (the returned value) is "m²".
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'convert-area-units',
	array(
		'title'       => __( 'Land area converter (sotka / hectare / m² / acre)', 'mvweb-build-calc' ),
		'hub'         => 'converters',
		'description' => __( 'Converts a land area between square metres, sotkas, hectares and acres.', 'mvweb-build-calc' ),
		'formula'     => 'X_base = X × k',
		'legend'      => array(
			'X_base' => __( 'value in the base unit', 'mvweb-build-calc' ),
			'X'      => __( 'entered value', 'mvweb-build-calc' ),
			'k'      => __( 'factor of the source unit to the base unit', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Land area', 'mvweb-build-calc' ),
			'unit'     => __( 'm²', 'mvweb-build-calc' ),
			'decimals' => 4,
		),
		'fields'      => array(
			'from'  => array(
				'type'     => 'select',
				'label'    => __( 'Convert from', 'mvweb-build-calc' ),
				'options'  => array(
					'm2' => __( 'Square metres (m²)', 'mvweb-build-calc' ),
					'sotka' => __( 'Sotkas (100 m²)', 'mvweb-build-calc' ),
					'ha' => __( 'Hectares (ha)', 'mvweb-build-calc' ),
					'acre' => __( 'Acres', 'mvweb-build-calc' ),
				),
				'default'  => 'sotka',
				'required' => true,
			),
			'value' => array(
				'type'     => 'number',
				'label'    => __( 'Value', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 100000000,
				'step'     => 'any',
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$factors = array(
				'm2' => 1.0,
				'sotka' => 100.0,
				'ha' => 10000.0,
				'acre' => 4046.8564224,
			);
			$labels = array(
				'm2' => __( 'm²', 'mvweb-build-calc' ),
				'sotka' => __( 'sotka', 'mvweb-build-calc' ),
				'ha' => __( 'ha', 'mvweb-build-calc' ),
				'acre' => __( 'acre', 'mvweb-build-calc' ),
			);

			$from = (string) ( $i['from'] ?? 'sotka' );
			$val  = (float) ( $i['value'] ?? 0 );
			$base = $val * ( $factors[ $from ] ?? 1.0 );

			$hints = array();
			foreach ( $factors as $unit => $factor ) {
				$hints[] = sprintf( '%s %s', mvweb_bc_format_number( $base / $factor, 4 ), $labels[ $unit ] );
			}

			return array(
				'value' => $base,
				'hints' => $hints,
			);
		},
	)
);
