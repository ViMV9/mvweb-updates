<?php
/**
 * Calculator: Inches to millimetres converter.
 *
 * Pick a source unit, enter a value, get the equivalent in every unit.
 * Base unit (the returned value) is "mm".
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'convert-inches-mm',
	array(
		'title'       => __( 'Inches to millimetres converter', 'mvweb-build-calc' ),
		'hub'         => 'converters',
		'description' => __( 'Converts a length between inches and millimetres.', 'mvweb-build-calc' ),
		'formula'     => 'X_base = X × k',
		'legend'      => array(
			'X_base' => __( 'value in the base unit', 'mvweb-build-calc' ),
			'X'      => __( 'entered value', 'mvweb-build-calc' ),
			'k'      => __( 'factor of the source unit to the base unit', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Length', 'mvweb-build-calc' ),
			'unit'     => __( 'mm', 'mvweb-build-calc' ),
			'decimals' => 3,
		),
		'fields'      => array(
			'from'  => array(
				'type'     => 'select',
				'label'    => __( 'Convert from', 'mvweb-build-calc' ),
				'options'  => array(
					'in' => __( 'Inches (in)', 'mvweb-build-calc' ),
					'mm' => __( 'Millimetres (mm)', 'mvweb-build-calc' ),
				),
				'default'  => 'in',
				'required' => true,
			),
			'value' => array(
				'type'     => 'number',
				'label'    => __( 'Value', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 1000000,
				'step'     => 'any',
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$factors = array(
				'in' => 25.4,
				'mm' => 1.0,
			);
			$labels = array(
				'in' => __( 'in', 'mvweb-build-calc' ),
				'mm' => __( 'mm', 'mvweb-build-calc' ),
			);

			$from = (string) ( $i['from'] ?? 'in' );
			$val  = (float) ( $i['value'] ?? 0 );
			$base = $val * ( $factors[ $from ] ?? 1.0 );

			$hints = array();
			foreach ( $factors as $unit => $factor ) {
				$hints[] = sprintf( '%s %s', mvweb_bc_format_number( $base / $factor, 3 ), $labels[ $unit ] );
			}

			return array(
				'value' => $base,
				'hints' => $hints,
			);
		},
	)
);
