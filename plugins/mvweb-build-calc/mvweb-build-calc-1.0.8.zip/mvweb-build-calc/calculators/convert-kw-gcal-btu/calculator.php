<?php
/**
 * Calculator: Heat power converter (kW / Gcal/h / BTU/h).
 *
 * Pick a source unit, enter a value, get the equivalent in every unit.
 * Base unit (the returned value) is "kW".
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

mvweb_bc_register(
	'convert-kw-gcal-btu',
	array(
		'title'       => __( 'Heat power converter (kW / Gcal/h / BTU/h)', 'mvweb-build-calc' ),
		'hub'         => 'converters',
		'description' => __( 'Converts a thermal power between kilowatts, gigacalories per hour, kilocalories per hour and BTU per hour.', 'mvweb-build-calc' ),
		'formula'     => 'X_base = X × k',
		'legend'      => array(
			'X_base' => __( 'value in the base unit', 'mvweb-build-calc' ),
			'X'      => __( 'entered value', 'mvweb-build-calc' ),
			'k'      => __( 'factor of the source unit to the base unit', 'mvweb-build-calc' ),
		),
		'result'      => array(
			'label'    => __( 'Heat power', 'mvweb-build-calc' ),
			'unit'     => __( 'kW', 'mvweb-build-calc' ),
			'decimals' => 4,
		),
		'fields'      => array(
			'from'  => array(
				'type'     => 'select',
				'label'    => __( 'Convert from', 'mvweb-build-calc' ),
				'options'  => array(
					'kw' => __( 'Kilowatts (kW)', 'mvweb-build-calc' ),
					'gcalh' => __( 'Gigacalories per hour (Gcal/h)', 'mvweb-build-calc' ),
					'kcalh' => __( 'Kilocalories per hour (kcal/h)', 'mvweb-build-calc' ),
					'btuh' => __( 'BTU per hour (BTU/h)', 'mvweb-build-calc' ),
				),
				'default'  => 'kw',
				'required' => true,
			),
			'value' => array(
				'type'     => 'number',
				'label'    => __( 'Value', 'mvweb-build-calc' ),
				'min'      => 0,
				'max'      => 1000000,
				'step'     => 'any',
				'required' => true,
			),
		),
		'calculate'   => static function ( array $i ): array {
			$factors = array(
				'kw' => 1.0,
				'gcalh' => 1163.0,
				'kcalh' => 0.001163,
				'btuh' => 0.00029307107,
			);
			$labels = array(
				'kw' => __( 'kW', 'mvweb-build-calc' ),
				'gcalh' => __( 'Gcal/h', 'mvweb-build-calc' ),
				'kcalh' => __( 'kcal/h', 'mvweb-build-calc' ),
				'btuh' => __( 'BTU/h', 'mvweb-build-calc' ),
			);

			$from = (string) ( $i['from'] ?? 'kw' );
			$val  = (float) ( $i['value'] ?? 0 );
			$base = $val * ( $factors[ $from ] ?? 1.0 );

			$hints = array();
			foreach ( $factors as $unit => $factor ) {
				$hints[] = sprintf( '%s %s', mvweb_bc_format_number( $base / $factor, 8 ), $labels[ $unit ] );
			}

			return array(
				'value' => $base,
				'hints' => $hints,
			);
		},
	)
);
