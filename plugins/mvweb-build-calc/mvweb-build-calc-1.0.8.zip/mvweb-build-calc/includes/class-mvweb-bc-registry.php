<?php
/**
 * Calculator registry for MVweb Build Calc.
 *
 * Holds all registered calculators and discovers them by scanning the
 * `calculators/` folder at `plugins_loaded` priority 20.
 *
 * Each calculator is registered via `mvweb_bc_register( $slug, $config )`.
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_BC_Registry.
 *
 * @since 1.0.0
 */
class MVweb_BC_Registry {

	/**
	 * Registered calculators keyed by slug.
	 *
	 * @var array<string, array<string, mixed>>
	 */
	private static array $calculators = array();

	/**
	 * Cached sorted list returned by all().
	 *
	 * @var array<string, array<string, mixed>>|null
	 */
	private static ?array $cache = null;

	/**
	 * Register a calculator.
	 *
	 * Called from each `calculators/{slug}/calculator.php` file.
	 *
	 * @since 1.0.0
	 * @param string               $slug   Calculator slug (must match folder name).
	 * @param array<string, mixed> $config Calculator configuration.
	 * @return void
	 */
	public static function register( string $slug, array $config ): void {
		$slug = sanitize_key( $slug );

		if ( '' === $slug ) {
			_doing_it_wrong( __METHOD__, 'Calculator slug is required.', '1.0.0' );
			return;
		}

		if ( array_key_exists( $slug, self::$calculators ) ) {
			_doing_it_wrong(
				__METHOD__,
				sprintf( 'Calculator "%s" is already registered.', esc_html( $slug ) ),
				'1.0.0'
			);
			return;
		}

		if ( ! self::is_valid_config( $config ) ) {
			_doing_it_wrong(
				__METHOD__,
				sprintf( 'Calculator "%s" has an invalid configuration.', esc_html( $slug ) ),
				'1.0.0'
			);
			return;
		}

		$config['slug']     = $slug;
		self::$calculators[ $slug ] = $config;
		self::$cache        = null;
	}

	/**
	 * Get a single calculator by slug.
	 *
	 * @since 1.0.0
	 * @param string $slug Calculator slug.
	 * @return array<string, mixed>|null
	 */
	public static function get( string $slug ): ?array {
		return self::$calculators[ $slug ] ?? null;
	}

	/**
	 * Get all calculators sorted by hub then title.
	 *
	 * @since 1.0.0
	 * @return array<string, array<string, mixed>>
	 */
	public static function all(): array {
		if ( null !== self::$cache ) {
			return self::$cache;
		}

		$sorted = self::$calculators;

		uasort(
			$sorted,
			static function ( array $a, array $b ): int {
				$hub_a   = (string) ( $a['hub'] ?? '' );
				$hub_b   = (string) ( $b['hub'] ?? '' );
				$title_a = (string) ( $a['title'] ?? '' );
				$title_b = (string) ( $b['title'] ?? '' );

				return ( $hub_a <=> $hub_b ) ?: ( $title_a <=> $title_b );
			}
		);

		self::$cache = $sorted;
		return $sorted;
	}

	/**
	 * Auto-discover calculators inside `calculators/` and require them.
	 *
	 * Hooked to `plugins_loaded` at priority 20. Each discovered file
	 * must call `mvweb_bc_register()`. Discovery is restricted to files
	 * physically located under `MVWEB_BC_PATH . 'calculators/'` to prevent
	 * symlink-based path traversal.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function discover(): void {
		$base = realpath( MVWEB_BC_PATH . 'calculators' );

		if ( false === $base ) {
			return;
		}

		$pattern = $base . '/*/calculator.php';
		$files   = glob( $pattern, GLOB_NOSORT );

		if ( false === $files || array() === $files ) {
			return;
		}

		foreach ( $files as $file ) {
			$real = realpath( $file );

			if ( false === $real || ! str_starts_with( $real, $base . DIRECTORY_SEPARATOR ) ) {
				continue;
			}

			require_once $real;
		}
	}

	/**
	 * Validate the minimum required keys of a calculator configuration.
	 *
	 * Required: title (string), fields (non-empty array), calculate (Closure),
	 * result (array with 'unit').
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $config Configuration to validate.
	 * @return bool
	 */
	private static function is_valid_config( array $config ): bool {
		if ( ! isset( $config['title'] ) || ! is_string( $config['title'] ) || '' === $config['title'] ) {
			return false;
		}

		if ( ! isset( $config['fields'] ) || ! is_array( $config['fields'] ) || array() === $config['fields'] ) {
			return false;
		}

		if ( ! isset( $config['calculate'] ) || ! ( $config['calculate'] instanceof Closure ) ) {
			return false;
		}

		if ( ! isset( $config['result'] ) || ! is_array( $config['result'] ) ) {
			return false;
		}

		if ( ! isset( $config['result']['unit'] ) || '' === $config['result']['unit'] ) {
			return false;
		}

		return true;
	}
}

/**
 * Public registration function.
 *
 * Each calculator file calls this once from `calculators/{slug}/calculator.php`.
 *
 * @since 1.0.0
 * @param string               $slug   Calculator slug (matches folder name).
 * @param array<string, mixed> $config Calculator configuration.
 * @return void
 */
function mvweb_bc_register( string $slug, array $config ): void {
	MVweb_BC_Registry::register( $slug, $config );
}

add_action( 'plugins_loaded', array( 'MVweb_BC_Registry', 'discover' ), 20 );
