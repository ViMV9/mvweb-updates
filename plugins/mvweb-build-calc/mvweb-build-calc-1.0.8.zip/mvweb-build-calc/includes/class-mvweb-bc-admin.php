<?php
/**
 * Admin page for MVweb Build Calc.
 *
 * Registers a submenu under the MVweb Hub, the Settings API options
 * and enqueues admin styles/scripts only on the plugin page.
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_BC_Admin.
 *
 * @since 1.0.0
 */
class MVweb_BC_Admin {

	/**
	 * Admin page slug.
	 */
	public const PAGE_SLUG = 'mvweb-build-calc';

	/**
	 * Settings option name.
	 */
	public const OPTION_NAME = 'mvweb_bc_settings';

	/**
	 * Settings group (used by settings_fields()).
	 */
	public const SETTINGS_GROUP = 'mvweb_bc_settings_group';

	/**
	 * Allowed button variants. Keys map to BEM modifiers on .mvweb-bc__submit.
	 */
	private const BUTTON_VARIANTS = array( 'solid', 'outline', 'ghost' );

	/**
	 * Register WordPress hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Register the submenu under the MVweb Hub.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_menu(): void {
		$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

		add_submenu_page(
			$parent_slug,
			__( 'Build Calc', 'mvweb-build-calc' ),
			__( 'Build Calc', 'mvweb-build-calc' ),
			'manage_options',
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Register the plugin settings.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_settings(): void {
		register_setting(
			self::SETTINGS_GROUP,
			self::OPTION_NAME,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
				'default'           => self::get_defaults(),
			)
		);
	}

	/**
	 * Default settings.
	 *
	 * @since 1.0.0
	 * @return array<string, mixed>
	 */
	public static function get_defaults(): array {
		return array_merge(
			array(
				'decimals'      => 2,
				'decimal_sep'   => '.',
				'thousands_sep' => "\xC2\xA0",
			),
			mvweb_bc_get_appearance_defaults()
		);
	}

	/**
	 * Get current settings merged with defaults.
	 *
	 * @since 1.0.0
	 * @return array<string, mixed>
	 */
	public static function get_settings(): array {
		$saved = (array) get_option( self::OPTION_NAME, array() );
		return array_merge( self::get_defaults(), $saved );
	}

	/**
	 * Sanitize the settings array before saving.
	 *
	 * @since 1.0.0
	 * @param mixed $input Raw input from Settings API (may be array, null or false).
	 * @return array<string, mixed>
	 */
	public static function sanitize_settings( mixed $input ): array {
		$input = is_array( $input ) ? $input : array();

		$out                  = array();
		$out['decimals']      = isset( $input['decimals'] )
			? max( 0, min( 6, (int) $input['decimals'] ) )
			: 2;
		$out['decimal_sep']   = isset( $input['decimal_sep'] )
			? substr( (string) sanitize_text_field( (string) $input['decimal_sep'] ), 0, 3 )
			: '.';
		$out['thousands_sep'] = isset( $input['thousands_sep'] )
			? substr( (string) sanitize_text_field( (string) $input['thousands_sep'] ), 0, 3 )
			: "\xC2\xA0";

		$out['border_radius'] = isset( $input['border_radius'] )
			? max( 0, min( 32, (int) $input['border_radius'] ) )
			: 8;

		$out['border_color']  = self::sanitize_hex( $input['border_color'] ?? '' );

		$out['border_width']  = isset( $input['border_width'] )
			? max( 0, min( 6, (int) $input['border_width'] ) )
			: 1;

		$out['form_border']   = ! empty( $input['form_border'] );

		$variant              = isset( $input['button_variant'] ) ? (string) $input['button_variant'] : 'outline';
		$out['button_variant'] = in_array( $variant, self::BUTTON_VARIANTS, true ) ? $variant : 'outline';

		$out['button_color']  = self::sanitize_hex( $input['button_color'] ?? '' );

		$theme         = isset( $input['theme'] ) ? sanitize_key( (string) $input['theme'] ) : MVWEB_BC_DEFAULT_THEME;
		$out['theme']  = mvweb_bc_validate_theme( $theme );

		return $out;
	}

	/**
	 * Sanitize a HEX color value. Returns '' for empty/invalid input so the
	 * frontend falls back to `currentColor` (theme-driven).
	 *
	 * @since 1.0.0
	 * @param mixed $value Raw value.
	 * @return string Empty string or a normalized `#rrggbb` / `#rgb` color.
	 */
	private static function sanitize_hex( mixed $value ): string {
		$value = is_scalar( $value ) ? trim( (string) $value ) : '';

		if ( '' === $value ) {
			return '';
		}

		$color = sanitize_hex_color( $value );
		return is_string( $color ) ? $color : '';
	}

	/**
	 * Render: numeric input (decimals, border_radius, border_width).
	 *
	 * @since 1.0.0
	 * @param string $key Option key.
	 * @param int    $min Min value.
	 * @param int    $max Max value.
	 * @return void
	 */
	public static function render_field_number( string $key, int $min, int $max ): void {
		$settings = self::get_settings();
		$id       = self::OPTION_NAME . '-' . $key;
		printf(
			'<input type="number" id="%1$s" name="%2$s[%3$s]" value="%4$s" min="%5$d" max="%6$d" step="1" class="mvweb-input mvweb-bc-admin-input--short" />',
			esc_attr( $id ),
			esc_attr( self::OPTION_NAME ),
			esc_attr( $key ),
			esc_attr( (string) $settings[ $key ] ),
			(int) $min,
			(int) $max
		);
	}

	/**
	 * Render: short text input (decimal_sep, thousands_sep).
	 *
	 * @since 1.0.0
	 * @param string $key Option key.
	 * @return void
	 */
	public static function render_field_short_text( string $key ): void {
		$settings = self::get_settings();
		$id       = self::OPTION_NAME . '-' . $key;
		printf(
			'<input type="text" id="%1$s" name="%2$s[%3$s]" value="%4$s" maxlength="3" class="mvweb-input mvweb-bc-admin-input--short" />',
			esc_attr( $id ),
			esc_attr( self::OPTION_NAME ),
			esc_attr( $key ),
			esc_attr( (string) $settings[ $key ] )
		);
	}

	/**
	 * Render: color picker (border_color, button_color).
	 *
	 * @since 1.0.0
	 * @param string $key Option key.
	 * @return void
	 */
	public static function render_field_color( string $key ): void {
		$settings = self::get_settings();
		$id       = self::OPTION_NAME . '-' . $key;
		printf(
			'<input type="text" id="%1$s" name="%2$s[%3$s]" value="%4$s" class="mvweb-bc-color-picker" data-default-color="" />',
			esc_attr( $id ),
			esc_attr( self::OPTION_NAME ),
			esc_attr( $key ),
			esc_attr( (string) $settings[ $key ] )
		);
	}

	/**
	 * Render: form border toggle.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_field_form_border(): void {
		$settings = self::get_settings();
		$id       = self::OPTION_NAME . '-form_border';
		?>
		<div class="mvweb-toggle-row">
			<label class="mvweb-toggle">
				<input
					type="checkbox"
					id="<?php echo esc_attr( $id ); ?>"
					name="<?php echo esc_attr( self::OPTION_NAME ); ?>[form_border]"
					value="1"
					<?php checked( ! empty( $settings['form_border'] ) ); ?>
				/>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<span><?php esc_html_e( 'Wrap the whole form in a border with internal padding.', 'mvweb-build-calc' ); ?></span>
		</div>
		<?php
	}

	/**
	 * Render: button variant field (3 radios).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_field_button_variant(): void {
		$settings = self::get_settings();
		$current  = (string) $settings['button_variant'];
		$variants = array(
			'solid'   => array(
				'label' => __( 'Solid', 'mvweb-build-calc' ),
				'desc'  => __( 'Filled button with the chosen color.', 'mvweb-build-calc' ),
			),
			'outline' => array(
				'label' => __( 'Outline', 'mvweb-build-calc' ),
				'desc'  => __( 'Transparent button with a colored border and text.', 'mvweb-build-calc' ),
			),
			'ghost'   => array(
				'label' => __( 'Ghost', 'mvweb-build-calc' ),
				'desc'  => __( 'No border, only colored text with a subtle hover.', 'mvweb-build-calc' ),
			),
		);
		?>
		<fieldset>
			<?php foreach ( $variants as $key => $variant ) : ?>
				<?php $id = self::OPTION_NAME . '-button_variant-' . $key; ?>
				<label for="<?php echo esc_attr( $id ); ?>" class="mvweb-bc-admin-radio">
					<input
						type="radio"
						id="<?php echo esc_attr( $id ); ?>"
						name="<?php echo esc_attr( self::OPTION_NAME ); ?>[button_variant]"
						value="<?php echo esc_attr( $key ); ?>"
						<?php checked( $current, $key ); ?>
					/>
					<span>
						<strong><?php echo esc_html( $variant['label'] ); ?></strong>
						<span class="mvweb-form-row__desc mvweb-bc-admin-radio__desc"><?php echo esc_html( $variant['desc'] ); ?></span>
					</span>
				</label>
			<?php endforeach; ?>
		</fieldset>
		<?php
	}

	/**
	 * Render: theme select.
	 *
	 * Lists all available frontend themes from `mvweb_bc_get_themes()`.
	 * Selecting a theme applies its CSS preset; the appearance settings
	 * below (radius, colors, border) continue to fine-tune the result.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public static function render_field_theme(): void {
		$settings = self::get_settings();
		$current  = isset( $settings['theme'] ) ? (string) $settings['theme'] : MVWEB_BC_DEFAULT_THEME;
		$themes   = mvweb_bc_get_themes();
		$id       = self::OPTION_NAME . '-theme';
		?>
		<select
			id="<?php echo esc_attr( $id ); ?>"
			name="<?php echo esc_attr( self::OPTION_NAME ); ?>[theme]"
			class="mvweb-select mvweb-bc-admin-input--theme"
		>
			<?php foreach ( $themes as $slug => $theme ) : ?>
				<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $current, $slug ); ?>>
					<?php echo esc_html( (string) $theme['label'] ); ?>
				</option>
			<?php endforeach; ?>
		</select>
		<p class="mvweb-form-row__desc mvweb-bc-admin-theme__desc" data-theme-desc>
			<?php echo esc_html( (string) ( $themes[ $current ]['description'] ?? '' ) ); ?>
		</p>
		<script type="application/json" class="mvweb-bc-admin-theme__data">
			<?php
			$descriptions = array();
			foreach ( $themes as $slug => $theme ) {
				$descriptions[ $slug ] = (string) $theme['description'];
			}
			echo wp_json_encode( $descriptions );
			?>
		</script>
		<?php
	}

	/**
	 * Render the settings page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have permission to access this page.', 'mvweb-build-calc' ) );
		}

		require MVWEB_BC_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Enqueue admin assets only on the plugin page.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( string $hook ): void {
		if ( ! str_ends_with( $hook, '_page_' . self::PAGE_SLUG ) ) {
			return;
		}

		$asset_ver = static function ( string $relative_path ): string {
			$absolute = MVWEB_BC_PATH . $relative_path;
			$mtime    = @filemtime( $absolute );
			return $mtime ? (string) $mtime : MVWEB_BC_VERSION;
		};

		wp_enqueue_style(
			'mvweb-bc-admin',
			MVWEB_BC_URL . 'admin/css/admin.min.css',
			array(),
			$asset_ver( 'admin/css/admin.min.css' )
		);

		wp_enqueue_style(
			'mvweb-bc-plugin',
			MVWEB_BC_URL . 'admin/css/plugin.min.css',
			array( 'mvweb-bc-admin', 'wp-color-picker' ),
			$asset_ver( 'admin/css/plugin.min.css' )
		);

		wp_enqueue_script(
			'mvweb-bc-admin',
			MVWEB_BC_URL . 'admin/js/admin.min.js',
			array( 'wp-color-picker' ),
			$asset_ver( 'admin/js/admin.min.js' ),
			true
		);

		wp_localize_script(
			'mvweb-bc-admin',
			'mvwebBCAdmin',
			array(
				'i18n' => array(
					'copied'    => __( 'Copied!', 'mvweb-build-calc' ),
					'copyError' => __( 'Copy failed.', 'mvweb-build-calc' ),
				),
			)
		);
	}
}

MVweb_BC_Admin::init();
