<?php
/**
 * Frontend theme presets for MVweb Build Calc.
 *
 * Each preset = a CSS modifier class on the form (`mvweb-bc--theme-{slug}`)
 * defined in `public/css/build-calc-themes.css`. Themes never touch the
 * admin-controlled appearance properties (radius, border, button color) —
 * those stay user-controlled via the Appearance settings on the admin page.
 *
 * @package MVweb_BC
 * @since   1.1.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default theme slug. The `default` theme uses only `build-calc.css` and adds
 * no modifier class on the form — exact behavior as before themes existed.
 */
const MVWEB_BC_DEFAULT_THEME = 'default';

/**
 * Get the list of available theme presets.
 *
 * @since 1.1.0
 * @return array<string, array{label: string, description: string}>
 */
function mvweb_bc_get_themes(): array {
	return array(
		'default'   => array(
			'label'       => __( 'Default', 'mvweb-build-calc' ),
			'description' => __( 'Minimal styles, inherits typography and colors from the active theme.', 'mvweb-build-calc' ),
		),
		'shadcn'    => array(
			'label'       => __( 'shadcn', 'mvweb-build-calc' ),
			'description' => __( 'Tight typography, segmented radio control on a soft surface.', 'mvweb-build-calc' ),
		),
		'pico'      => array(
			'label'       => __( 'Pico', 'mvweb-build-calc' ),
			'description' => __( 'Minimalist look with native radios and taller, mobile-friendly inputs.', 'mvweb-build-calc' ),
		),
		'openprops' => array(
			'label'       => __( 'Open Props', 'mvweb-build-calc' ),
			'description' => __( 'Soft shadows and a subtle gradient on the submit button.', 'mvweb-build-calc' ),
		),
		'shoelace'  => array(
			'label'       => __( 'Shoelace', 'mvweb-build-calc' ),
			'description' => __( 'Joined radio group, soft surface inputs that lift on hover.', 'mvweb-build-calc' ),
		),
		'material'  => array(
			'label'       => __( 'Material 3', 'mvweb-build-calc' ),
			'description' => __( 'Roboto typography, taller inputs and a pill-shaped submit button.', 'mvweb-build-calc' ),
		),
		'bulma'     => array(
			'label'       => __( 'Bulma', 'mvweb-build-calc' ),
			'description' => __( 'Classic look with inset input shadows and bold labels.', 'mvweb-build-calc' ),
		),
		'halfmoon'  => array(
			'label'       => __( 'Halfmoon', 'mvweb-build-calc' ),
			'description' => __( 'Dashboard-style with IBM Plex Sans and joined radios.', 'mvweb-build-calc' ),
		),
		'tabler'    => array(
			'label'       => __( 'Tabler', 'mvweb-build-calc' ),
			'description' => __( 'Inter typography, button-group radios and soft input shadows.', 'mvweb-build-calc' ),
		),
		'daisyui'   => array(
			'label'       => __( 'DaisyUI', 'mvweb-build-calc' ),
			'description' => __( 'Pill-shaped radios, outline focus state and uppercase submit.', 'mvweb-build-calc' ),
		),
		'modern'    => array(
			'label'       => __( 'Modern', 'mvweb-build-calc' ),
			'description' => __( 'Default look with subtle input shadows and a hover glow on the submit button.', 'mvweb-build-calc' ),
		),
	);
}

/**
 * Validate a theme slug. Returns the slug if it's a registered theme, otherwise
 * returns the default theme slug.
 *
 * @since 1.1.0
 * @param string $slug Slug to validate.
 * @return string
 */
function mvweb_bc_validate_theme( string $slug ): string {
	$themes = mvweb_bc_get_themes();
	return array_key_exists( $slug, $themes ) ? $slug : MVWEB_BC_DEFAULT_THEME;
}
