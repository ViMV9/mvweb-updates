<?php
/**
 * Uninstall MVweb Build Calc
 *
 * Fired when the plugin is uninstalled.
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$options = array(
	'mvweb_bc_settings',
);

foreach ( $options as $option ) {
	delete_option( $option );
}

if ( is_multisite() ) {
	$sites = get_sites( array( 'number' => 0 ) );
	foreach ( $sites as $site ) {
		switch_to_blog( $site->blog_id );

		foreach ( $options as $option ) {
			delete_option( $option );
		}

		restore_current_blog();
	}
}
