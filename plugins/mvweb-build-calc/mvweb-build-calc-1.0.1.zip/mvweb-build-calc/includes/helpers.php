<?php
/**
 * Helper functions for MVweb Build Calc.
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default appearance settings shared between admin and frontend.
 *
 * The admin class is not loaded on the frontend, so the shortcode cannot
 * reference its constants. Both sides read defaults from here to keep them
 * in sync.
 *
 * @since 1.0.0
 * @return array<string, mixed>
 */
function mvweb_bc_get_appearance_defaults(): array {
	return array(
		'theme'          => 'default',
		'border_radius'  => 8,
		'border_color'   => '',
		'border_width'   => 1,
		'form_border'    => false,
		'button_variant' => 'outline',
		'button_color'   => '',
	);
}

/**
 * Format a number for display using plugin settings.
 *
 * Uses `number_format()` with thousands and decimal separators from settings.
 * Default thousands separator is the no-break space (U+00A0) — recommended
 * for Russian locale to avoid line breaks between digit groups.
 *
 * @since 1.0.0
 * @param float    $value    Number to format.
 * @param int|null $decimals Number of decimal places. Falls back to setting.
 * @return string
 */
function mvweb_bc_format_number( float $value, ?int $decimals = null ): string {
	$settings = get_option( 'mvweb_bc_settings', array() );

	$decimals      = $decimals ?? (int) ( $settings['decimals'] ?? 2 );
	$decimal_sep   = (string) ( $settings['decimal_sep'] ?? '.' );
	$thousands_sep = (string) ( $settings['thousands_sep'] ?? "\xC2\xA0" ); // U+00A0.

	return number_format( $value, max( 0, $decimals ), $decimal_sep, $thousands_sep );
}

/**
 * Highlight a formula string for IDE-style display.
 *
 * Wraps numbers, operators and variable identifiers in spans with token
 * classes so the formula renders with syntax highlighting. Output is
 * already HTML-escaped — safe to echo directly.
 *
 * @since 1.0.0
 * @param string $formula Formula source (e.g. "V = L × W × H × (1 + reserve% / 100)").
 * @return string HTML with token spans.
 */
function mvweb_bc_highlight_formula( string $formula ): string {
	// Tokenize raw input first, then escape + wrap each token. Avoids
	// nested replacements that would corrupt previously inserted HTML.
	$pattern = '/(?P<id>[A-Za-zА-Яа-я_][A-Za-zА-Яа-я0-9_]*%?)|(?P<num>\d+(?:\.\d+)?)|(?P<op>[×х*+\-\/=()])/u';

	return (string) preg_replace_callback(
		$pattern,
		static function ( array $m ): string {
			if ( ! empty( $m['id'] ) ) {
				return '<span class="mvweb-bc-tok-v">' . esc_html( $m['id'] ) . '</span>';
			}
			if ( ! empty( $m['num'] ) ) {
				return '<span class="mvweb-bc-tok-n">' . esc_html( $m['num'] ) . '</span>';
			}
			if ( ! empty( $m['op'] ) ) {
				return '<span class="mvweb-bc-tok-o">' . esc_html( $m['op'] ) . '</span>';
			}
			return esc_html( $m[0] );
		},
		esc_html( $formula )
	);
}

/**
 * Flatten select/radio options to a value => label map regardless of grouping.
 *
 * Supports two option formats:
 * - Flat: ['value' => 'Label', ...]
 * - Grouped: ['Group Label' => ['value' => 'Label', ...], ...]
 *
 * Format is detected by checking whether the first value is an array.
 * Used by validators and summary builders that need uniform access to options.
 *
 * @since 1.0.0
 * @param array<int|string, mixed> $options Raw options config.
 * @return array<string, string> Flat map of value => label.
 */
function mvweb_bc_flatten_options( array $options ): array {
	if ( array() === $options ) {
		return array();
	}

	$first = reset( $options );

	if ( ! is_array( $first ) ) {
		$flat = array();
		foreach ( $options as $value => $label ) {
			$flat[ (string) $value ] = (string) $label;
		}
		return $flat;
	}

	$flat = array();
	foreach ( $options as $group_children ) {
		if ( ! is_array( $group_children ) ) {
			continue;
		}
		foreach ( $group_children as $value => $label ) {
			$flat[ (string) $value ] = (string) $label;
		}
	}
	return $flat;
}

/**
 * Sanitize a single input value according to its field config.
 *
 * @since 1.0.0
 * @param mixed $value        Raw value from $_POST.
 * @param array $field_config Field configuration (type, options, etc.).
 * @return int|float|string Sanitized value.
 */
function mvweb_bc_sanitize_input( mixed $value, array $field_config ): int|float|string {
	$type = (string) ( $field_config['type'] ?? 'number' );

	return match ( $type ) {
		'number'          => (float) $value,
		'select', 'radio' => sanitize_key( (string) $value ),
		default           => sanitize_text_field( (string) $value ),
	};
}
