<?php
/**
 * Shortcode [mvweb_calc id="..."] for MVweb Build Calc.
 *
 * Renders a calculator form on the frontend. The actual calculation is
 * performed server-side via admin-ajax (see class-mvweb-bc-ajax.php).
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_BC_Shortcode.
 *
 * @since 1.0.0
 */
class MVweb_BC_Shortcode {

	/**
	 * Shortcode tag.
	 */
	public const TAG = 'mvweb_calc';

	/**
	 * Register WordPress hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'init', array( __CLASS__, 'register' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
	}

	/**
	 * Register the shortcode.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register(): void {
		add_shortcode( self::TAG, array( __CLASS__, 'render' ) );
	}

	/**
	 * Register (but don't enqueue) the public assets.
	 *
	 * Actual enqueue happens lazily inside render() so the assets only
	 * load on pages that actually contain the shortcode.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_assets(): void {
		// Cache-bust via filemtime so updated CSS/JS reach browsers without
		// bumping MVWEB_BC_VERSION between releases.
		$asset_ver = static function ( string $relative_path ): string {
			$absolute = MVWEB_BC_PATH . $relative_path;
			$mtime    = @filemtime( $absolute );
			return $mtime ? (string) $mtime : MVWEB_BC_VERSION;
		};

		wp_register_style(
			'mvweb-bc',
			MVWEB_BC_URL . 'public/css/build-calc.min.css',
			array(),
			$asset_ver( 'public/css/build-calc.min.css' )
		);

		wp_register_style(
			'mvweb-bc-themes',
			MVWEB_BC_URL . 'public/css/build-calc-themes.min.css',
			array( 'mvweb-bc' ),
			$asset_ver( 'public/css/build-calc-themes.min.css' )
		);

		wp_register_script(
			'mvweb-bc',
			MVWEB_BC_URL . 'public/js/build-calc.min.js',
			array(),
			$asset_ver( 'public/js/build-calc.min.js' ),
			array(
				'strategy'  => 'defer',
				'in_footer' => true,
			)
		);

		wp_localize_script(
			'mvweb-bc',
			'mvwebBC',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'mvweb_bc_calculate' ),
				'i18n'    => array(
					'calculate' => __( 'Calculate', 'mvweb-build-calc' ),
					'required'  => __( 'This field is required.', 'mvweb-build-calc' ),
					'min'       => __( 'Value is too small.', 'mvweb-build-calc' ),
					'max'       => __( 'Value is too large.', 'mvweb-build-calc' ),
					'invalid'   => __( 'Invalid value.', 'mvweb-build-calc' ),
					'error'     => __( 'Calculation failed. Please try again.', 'mvweb-build-calc' ),
				),
			)
		);
	}

	/**
	 * Render the shortcode.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed>|string $atts Shortcode attributes (WordPress passes array or empty string).
	 * @return string
	 */
	public static function render( mixed $atts ): string {
		$atts = shortcode_atts(
			array(
				'id' => '',
			),
			is_array( $atts ) ? $atts : array(),
			self::TAG
		);

		$slug = sanitize_key( (string) $atts['id'] );

		if ( '' === $slug ) {
			return current_user_can( 'edit_posts' )
				? '<!-- mvweb_calc: missing id attribute -->'
				: '';
		}

		$calc = MVweb_BC_Registry::get( $slug );

		if ( null === $calc ) {
			return current_user_can( 'edit_posts' )
				? sprintf( '<!-- mvweb_calc: unknown id "%s" -->', esc_html( $slug ) )
				: '';
		}

		wp_enqueue_style( 'mvweb-bc' );
		wp_enqueue_script( 'mvweb-bc' );

		$theme = mvweb_bc_validate_theme( (string) self::get_appearance_settings()['theme'] );
		if ( MVWEB_BC_DEFAULT_THEME !== $theme ) {
			wp_enqueue_style( 'mvweb-bc-themes' );
		}

		ob_start();
		self::render_form( $calc );
		return (string) ob_get_clean();
	}

	/**
	 * Render the calculator form.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $calc Calculator configuration.
	 * @return void
	 */
	private static function render_form( array $calc ): void {
		$slug         = (string) $calc['slug'];
		$fields       = (array) $calc['fields'];
		$settings     = self::get_appearance_settings();
		$variant      = (string) $settings['button_variant'];
		$btn_class    = 'mvweb-bc__submit mvweb-bc__submit--' . $variant;
		$inline_style = self::build_inline_style( $settings );
		$theme        = mvweb_bc_validate_theme( (string) $settings['theme'] );
		$form_class   = 'mvweb-bc';
		if ( MVWEB_BC_DEFAULT_THEME !== $theme ) {
			$form_class .= ' mvweb-bc--theme-' . $theme;
		}
		?>
		<form
			class="<?php echo esc_attr( $form_class ); ?>"
			data-calc-id="<?php echo esc_attr( $slug ); ?>"
			<?php if ( '' !== $inline_style ) : ?>style="<?php echo esc_attr( $inline_style ); ?>"<?php endif; ?>
		>
			<fieldset class="mvweb-bc__fieldset">
				<?php foreach ( $fields as $key => $field ) : ?>
					<?php self::render_field( (string) $key, (array) $field, $slug ); ?>
				<?php endforeach; ?>
			</fieldset>

			<button type="submit" class="<?php echo esc_attr( $btn_class ); ?>">
				<?php esc_html_e( 'Calculate', 'mvweb-build-calc' ); ?>
			</button>

			<div class="mvweb-bc__result" role="status" aria-live="polite" hidden></div>
		</form>
		<?php
	}

	/**
	 * Read appearance settings on the frontend without loading the admin class.
	 *
	 * The admin class (MVweb_BC_Admin) is only required in wp-admin, so the
	 * frontend cannot rely on its constants or methods. We read the same option
	 * and re-apply the same defaults locally.
	 *
	 * @since 1.0.0
	 * @return array<string, mixed>
	 */
	private static function get_appearance_settings(): array {
		$saved    = (array) get_option( 'mvweb_bc_settings', array() );
		$settings = array_merge( mvweb_bc_get_appearance_defaults(), $saved );

		if ( ! in_array( $settings['button_variant'], array( 'solid', 'outline', 'ghost' ), true ) ) {
			$settings['button_variant'] = 'outline';
		}

		return $settings;
	}

	/**
	 * Build the inline `style="..."` value carrying CSS custom properties
	 * derived from the saved appearance settings. Returns an empty string
	 * when every value matches the CSS defaults — so the frontend stays
	 * theme-driven without unnecessary inline attributes.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $settings Appearance settings.
	 * @return string Concatenated `--var:value;` declarations or empty string.
	 */
	private static function build_inline_style( array $settings ): string {
		$vars = array();

		$radius = (int) ( $settings['border_radius'] ?? 8 );
		if ( 8 !== $radius ) {
			$vars[] = '--mvbc-radius:' . $radius . 'px';
		}

		$border_color = (string) ( $settings['border_color'] ?? '' );
		if ( '' !== $border_color ) {
			$vars[] = '--mvbc-border-color:' . $border_color;
		}

		$border_width = (int) ( $settings['border_width'] ?? 1 );
		if ( 1 !== $border_width ) {
			$vars[] = '--mvbc-border-width:' . $border_width . 'px';
		}

		if ( ! empty( $settings['form_border'] ) ) {
			$vars[] = '--mvbc-form-border:var(--mvbc-border-width) solid var(--mvbc-border-color)';
			$vars[] = '--mvbc-form-padding:clamp(16px,4vw,28px)';
		}

		$btn_color = (string) ( $settings['button_color'] ?? '' );
		if ( '' !== $btn_color ) {
			$vars[] = '--mvbc-btn-color:' . $btn_color;
		}

		return implode( ';', $vars );
	}

	/**
	 * Render a single field.
	 *
	 * @since 1.0.0
	 * @param string               $key       Field key.
	 * @param array<string, mixed> $field     Field config.
	 * @param string               $calc_slug Calculator slug (used for unique field IDs).
	 * @return void
	 */
	private static function render_field( string $key, array $field, string $calc_slug ): void {
		$type     = (string) ( $field['type'] ?? 'number' );
		$label    = (string) ( $field['label'] ?? $key );
		$unit     = (string) ( $field['unit'] ?? '' );
		$required = ! empty( $field['required'] );
		$default  = $field['default'] ?? '';
		$field_id = 'mvweb-bc-' . $calc_slug . '-' . $key;
		?>
		<div class="mvweb-bc__field" data-field="<?php echo esc_attr( $key ); ?>">
			<label class="mvweb-bc__label" for="<?php echo esc_attr( $field_id ); ?>">
				<?php echo esc_html( $label ); ?>
				<?php if ( '' !== $unit ) : ?>
					<span class="mvweb-bc__unit">(<?php echo esc_html( $unit ); ?>)</span>
				<?php endif; ?>
				<?php if ( ! empty( $field['tip'] ) ) : ?>
					<button
						type="button"
						class="mvweb-bc__tip"
						aria-label="<?php esc_attr_e( 'Show details', 'mvweb-build-calc' ); ?>"
						data-mvbc-tip="<?php echo esc_attr( (string) $field['tip'] ); ?>"
					>?</button>
				<?php endif; ?>
			</label>

			<?php if ( 'number' === $type ) : ?>
				<input
					type="number"
					id="<?php echo esc_attr( $field_id ); ?>"
					name="<?php echo esc_attr( $key ); ?>"
					class="mvweb-bc__input"
					<?php if ( isset( $field['min'] ) ) : ?>min="<?php echo esc_attr( (string) $field['min'] ); ?>"<?php endif; ?>
					<?php if ( isset( $field['max'] ) ) : ?>max="<?php echo esc_attr( (string) $field['max'] ); ?>"<?php endif; ?>
					<?php if ( isset( $field['step'] ) ) : ?>step="<?php echo esc_attr( (string) $field['step'] ); ?>"<?php endif; ?>
					<?php if ( '' !== (string) $default ) : ?>value="<?php echo esc_attr( (string) $default ); ?>"<?php endif; ?>
					<?php echo $required ? 'required' : ''; ?>
					inputmode="decimal"
				/>
			<?php elseif ( 'select' === $type ) : ?>
				<?php
				$options    = (array) ( $field['options'] ?? array() );
				$first_val  = array() !== $options ? reset( $options ) : null;
				$is_grouped = is_array( $first_val );
				?>
				<select
					id="<?php echo esc_attr( $field_id ); ?>"
					name="<?php echo esc_attr( $key ); ?>"
					class="mvweb-bc__input"
					<?php echo $required ? 'required' : ''; ?>
				>
					<?php if ( $is_grouped ) : ?>
						<?php
						foreach ( $options as $group_label => $group_children ) :
							if ( ! is_array( $group_children ) ) {
								continue;
							}
							?>
							<optgroup label="<?php echo esc_attr( (string) $group_label ); ?>">
								<?php foreach ( $group_children as $value => $option_label ) : ?>
									<option
										value="<?php echo esc_attr( (string) $value ); ?>"
										<?php selected( (string) $value, (string) $default ); ?>
									>
										<?php echo esc_html( (string) $option_label ); ?>
									</option>
								<?php endforeach; ?>
							</optgroup>
						<?php endforeach; ?>
					<?php else : ?>
						<?php foreach ( $options as $value => $option_label ) : ?>
							<option
								value="<?php echo esc_attr( (string) $value ); ?>"
								<?php selected( (string) $value, (string) $default ); ?>
							>
								<?php echo esc_html( (string) $option_label ); ?>
							</option>
						<?php endforeach; ?>
					<?php endif; ?>
				</select>
			<?php elseif ( 'radio' === $type ) : ?>
				<div class="mvweb-bc__radios" role="radiogroup">
					<?php foreach ( mvweb_bc_flatten_options( (array) ( $field['options'] ?? array() ) ) as $value => $option_label ) : ?>
						<?php $option_id = $field_id . '-' . sanitize_key( (string) $value ); ?>
						<label class="mvweb-bc__radio-label" for="<?php echo esc_attr( $option_id ); ?>">
							<input
								type="radio"
								id="<?php echo esc_attr( $option_id ); ?>"
								name="<?php echo esc_attr( $key ); ?>"
								value="<?php echo esc_attr( (string) $value ); ?>"
								<?php checked( (string) $value, (string) $default ); ?>
								<?php echo $required ? 'required' : ''; ?>
							/>
							<span><?php echo esc_html( (string) $option_label ); ?></span>
						</label>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $field['hint'] ) ) : ?>
				<p class="mvweb-bc__hint"><?php echo esc_html( (string) $field['hint'] ); ?></p>
			<?php endif; ?>

			<p class="mvweb-bc__field-error" hidden></p>
		</div>
		<?php
	}
}

MVweb_BC_Shortcode::init();
