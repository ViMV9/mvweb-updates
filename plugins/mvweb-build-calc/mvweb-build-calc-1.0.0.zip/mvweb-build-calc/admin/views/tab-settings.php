<?php
/**
 * Settings tab — plugin-wide formatting and appearance options.
 *
 * Uses MVweb Admin UI Kit (slate palette, Yoast-style layout).
 *
 * @package MVweb_BC
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<form method="post" action="options.php">
	<?php settings_fields( MVweb_BC_Admin::SETTINGS_GROUP ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'General Settings', 'mvweb-build-calc' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Configure number formatting for calculator results.', 'mvweb-build-calc' ); ?></p>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_BC_Admin::OPTION_NAME . '-decimals' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Decimal places', 'mvweb-build-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_BC_Admin::render_field_number( 'decimals', 0, 6 ); ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Number of digits shown after the decimal separator (0–6).', 'mvweb-build-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_BC_Admin::OPTION_NAME . '-decimal_sep' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Decimal separator', 'mvweb-build-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_BC_Admin::render_field_short_text( 'decimal_sep' ); ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Character used between integer and fractional parts.', 'mvweb-build-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_BC_Admin::OPTION_NAME . '-thousands_sep' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Thousands separator', 'mvweb-build-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_BC_Admin::render_field_short_text( 'thousands_sep' ); ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Character grouping thousands. Default is a no-break space (U+00A0).', 'mvweb-build-calc' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Appearance', 'mvweb-build-calc' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Fine-tune borders, corners and the submit button. Leave colors empty to inherit from the active theme.', 'mvweb-build-calc' ); ?></p>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_BC_Admin::OPTION_NAME . '-border_radius' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Corner rounding', 'mvweb-build-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_BC_Admin::render_field_number( 'border_radius', 0, 32 ); ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Radius in pixels. Set to 0 for square corners.', 'mvweb-build-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_BC_Admin::OPTION_NAME . '-border_color' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Border color', 'mvweb-build-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_BC_Admin::render_field_color( 'border_color' ); ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Leave empty to inherit the current text color of the theme.', 'mvweb-build-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_BC_Admin::OPTION_NAME . '-border_width' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Border thickness', 'mvweb-build-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_BC_Admin::render_field_number( 'border_width', 0, 6 ); ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Pixels. Set to 0 to hide all borders on inputs and result box.', 'mvweb-build-calc' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_BC_Admin::OPTION_NAME . '-form_border' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Form border', 'mvweb-build-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_BC_Admin::render_field_form_border(); ?>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label">
				<?php esc_html_e( 'Button style', 'mvweb-build-calc' ); ?>
			</span>
			<div class="mvweb-form-row__field">
				<?php MVweb_BC_Admin::render_field_button_variant(); ?>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="<?php echo esc_attr( MVweb_BC_Admin::OPTION_NAME . '-button_color' ); ?>" class="mvweb-form-row__label">
				<?php esc_html_e( 'Button color', 'mvweb-build-calc' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<?php MVweb_BC_Admin::render_field_color( 'button_color' ); ?>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Leave empty to inherit the current text color of the theme.', 'mvweb-build-calc' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Save Changes', 'mvweb-build-calc' ); ?>
		</button>
	</div>
</form>
