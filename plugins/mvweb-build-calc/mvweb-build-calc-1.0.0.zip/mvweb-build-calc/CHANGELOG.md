# Changelog

All notable changes to MVweb Build Calc will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-05-19

### Added
- Initial plugin scaffold with MVweb Hub registration.
- Calculator registry with auto-discovery from `calculators/` folder.
- `[mvweb_calc id="..."]` shortcode for rendering calculator forms.
- Server-side calculation via admin-ajax with nonce protection and per-field validation.
- Admin UI with list of registered calculators, plugin settings and help tab.
- Reference calculator: `foundation-concrete-volume`.
- Appearance settings: corner radius, border color/width, optional form wrapper border, button variant (Solid / Outline / Ghost) and button color. Empty color fields inherit from the active theme via `currentColor`.

### Changed
- Frontend widget rewritten around CSS custom properties (`--mvbc-*`). The fixed `native` / `slate` / `outline` / `stone` presets were removed in favor of a single theme-driven base plus admin-controlled overrides.
