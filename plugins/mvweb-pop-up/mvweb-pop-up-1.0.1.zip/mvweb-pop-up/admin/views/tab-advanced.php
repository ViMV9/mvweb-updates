<?php
/**
 * Advanced settings tab.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<h2><?php esc_html_e( 'Behavior', 'mvweb-pop-up' ); ?></h2>

<table class="form-table">
	<tr>
		<th scope="row"><?php esc_html_e( 'Close on overlay click', 'mvweb-pop-up' ); ?></th>
		<td>
			<label for="mvweb-pu-close-overlay">
				<input
					type="checkbox"
					id="mvweb-pu-close-overlay"
					name="mvweb_pu_options[close_on_overlay]"
					value="1"
					<?php checked( $options['close_on_overlay'] ); ?>
				/>
				<?php esc_html_e( 'Close popup when clicking outside the modal', 'mvweb-pop-up' ); ?>
			</label>
		</td>
	</tr>
	<tr>
		<th scope="row"><?php esc_html_e( 'Close on Escape', 'mvweb-pop-up' ); ?></th>
		<td>
			<label for="mvweb-pu-close-escape">
				<input
					type="checkbox"
					id="mvweb-pu-close-escape"
					name="mvweb_pu_options[close_on_escape]"
					value="1"
					<?php checked( $options['close_on_escape'] ); ?>
				/>
				<?php esc_html_e( 'Close popup when pressing the Escape key', 'mvweb-pop-up' ); ?>
			</label>
		</td>
	</tr>
</table>

<h2><?php esc_html_e( 'Data', 'mvweb-pop-up' ); ?></h2>

<table class="form-table">
	<tr>
		<th scope="row"><?php esc_html_e( 'Keep data on uninstall', 'mvweb-pop-up' ); ?></th>
		<td>
			<label for="mvweb-pu-keep-data">
				<input
					type="checkbox"
					id="mvweb-pu-keep-data"
					name="mvweb_pu_options[keep_data]"
					value="1"
					<?php checked( $options['keep_data'] ); ?>
				/>
				<?php esc_html_e( 'Keep plugin settings when the plugin is deleted', 'mvweb-pop-up' ); ?>
			</label>
		</td>
	</tr>
</table>

<h2><?php esc_html_e( 'Shortcode Usage', 'mvweb-pop-up' ); ?></h2>

<div class="mvweb-pu-docs">
	<table class="mvweb-pu-docs-table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'Shortcode', 'mvweb-pop-up' ); ?></th>
				<th><?php esc_html_e( 'Description', 'mvweb-pop-up' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td><code>[mvweb_popup]</code></td>
				<td><?php esc_html_e( 'Button with default text from settings', 'mvweb-pop-up' ); ?></td>
			</tr>
			<tr>
				<td><code>[mvweb_popup]Click me[/mvweb_popup]</code></td>
				<td><?php esc_html_e( 'Button with custom text', 'mvweb-pop-up' ); ?></td>
			</tr>
			<tr>
				<td><code>[mvweb_pop-up]</code></td>
				<td><?php esc_html_e( 'Backward-compatible alias', 'mvweb-pop-up' ); ?></td>
			</tr>
		</tbody>
	</table>

	<p class="description">
		<?php esc_html_e( 'All buttons on the page open the same popup. The popup content is configured in the Content tab.', 'mvweb-pop-up' ); ?>
	</p>
</div>
