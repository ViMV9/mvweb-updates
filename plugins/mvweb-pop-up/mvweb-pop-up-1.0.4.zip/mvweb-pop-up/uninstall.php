<?php
/**
 * Uninstall MVweb Pop-Up
 *
 * Fired when the plugin is uninstalled.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Clean up plugin data.
 *
 * @return void
 */
function mvweb_pu_uninstall_cleanup() {
	// Check if user wants to keep data.
	$options = get_option( 'mvweb_pu_options', array() );
	if ( ! empty( $options['keep_data'] ) ) {
		return;
	}

	// Delete plugin options.
	delete_option( 'mvweb_pu_options' );
}

// Run cleanup on single site.
mvweb_pu_uninstall_cleanup();

// For multisite, clean up each site.
if ( is_multisite() ) {
	$sites = get_sites();
	foreach ( $sites as $site ) {
		switch_to_blog( $site->blog_id );
		mvweb_pu_uninstall_cleanup();
		restore_current_blog();
	}
}
