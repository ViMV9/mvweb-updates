<?php
/**
 * Plugin Name:       MVweb Pop-Up
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-pop-up
 * Description:       Simple and accessible popup plugin with shortcode trigger.
 * Version:           1.0.4
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-pop-up
 * Domain Path:       /languages
 *
 * @package MVweb_Pop_Up
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_PU_VERSION' ) ) {
	return;
}

/**
 * Plugin version.
 */
define( 'MVWEB_PU_VERSION', '1.0.4' );

/**
 * Plugin directory path.
 */
define( 'MVWEB_PU_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Plugin directory URL.
 */
define( 'MVWEB_PU_URL', plugin_dir_url( __FILE__ ) );

/**
 * Plugin basename.
 */
define( 'MVWEB_PU_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Load shared MVweb files.
 *
 * Menu and updater classes are bundled with each plugin for independent updates.
 * Shared path is used for development environment only.
 */
$shared_path = dirname( dirname( MVWEB_PU_PATH ) ) . '/shared/';

// Load MVweb Menu — prefer bundled version, fallback to shared for dev.
if ( file_exists( MVWEB_PU_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_PU_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// Ensure menu singleton is initialized (guards against OPcache stale bytecode).
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Register this plugin with MVweb Menu hub page.
add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-pop-up'] = array(
		'name'         => 'MVweb Pop-Up',
		'description'  => 'Simple and accessible popup plugin with shortcode trigger.',
		'url'          => 'https://mvweb.ru/plugins/mvweb-pop-up',
		'settings_url' => 'admin.php?page=mvweb-pop-up',
		'textdomain'   => 'mvweb-pop-up',
	);
	return $plugins;
} );

/**
 * Initialize plugin updater.
 *
 * Uses JSON metadata from public update server (mvweb-updates repo).
 * Prefers bundled updater class, falls back to shared for development.
 */
if ( file_exists( MVWEB_PU_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_PU_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-pop-up' );
}

// Load helpers.
require_once MVWEB_PU_PATH . 'includes/helpers.php';

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pu_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-pop-up',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_pu_load_textdomain' );

/**
 * Translate plugin metadata in plugins list.
 *
 * WordPress doesn't automatically translate plugin Name and Description
 * from the plugin header when using local translation files.
 *
 * @since 1.0.0
 * @param array $plugins Array of plugin data.
 * @return array Modified plugins array.
 */
function mvweb_pu_translate_plugin_meta( $plugins ) {
	$plugin_file = plugin_basename( __FILE__ );

	if ( isset( $plugins[ $plugin_file ] ) ) {
		if ( ! is_textdomain_loaded( 'mvweb-pop-up' ) ) {
			load_plugin_textdomain(
				'mvweb-pop-up',
				false,
				dirname( $plugin_file ) . '/languages/'
			);
		}

		$plugins[ $plugin_file ]['Name']        = __( 'MVweb Pop-Up', 'mvweb-pop-up' );
		$plugins[ $plugin_file ]['Title']       = __( 'MVweb Pop-Up', 'mvweb-pop-up' );
		$plugins[ $plugin_file ]['Description'] = __( 'Simple and accessible popup plugin with shortcode trigger.', 'mvweb-pop-up' );
	}

	return $plugins;
}
add_filter( 'all_plugins', 'mvweb_pu_translate_plugin_meta' );

/**
 * Register plugin submenu.
 *
 * Uses MVweb_Menu::MENU_SLUG as parent to attach to the MVweb hub menu.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pu_register_menu() {
	$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

	add_submenu_page(
		$parent_slug,
		__( 'Pop-Up', 'mvweb-pop-up' ),
		__( 'Pop-Up', 'mvweb-pop-up' ),
		'manage_options',
		'mvweb-pop-up',
		'mvweb_pu_settings_page'
	);
}
add_action( 'admin_menu', 'mvweb_pu_register_menu' );

/**
 * Plugin settings page callback.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pu_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	include MVWEB_PU_PATH . 'admin/views/settings-page.php';
}

/**
 * Plugin activation hook.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pu_activate() {
	if ( false === get_option( 'mvweb_pu_options' ) ) {
		add_option( 'mvweb_pu_options', mvweb_pu_get_defaults() );
	}
}
register_activation_hook( __FILE__, 'mvweb_pu_activate' );

// Initialize components.
if ( is_admin() ) {
	require_once MVWEB_PU_PATH . 'includes/class-mvweb-pop-up-admin.php';
	new MVweb_PU_Admin();
} else {
	require_once MVWEB_PU_PATH . 'includes/class-mvweb-pop-up-shortcode.php';
	require_once MVWEB_PU_PATH . 'includes/class-mvweb-pop-up-public.php';
	new MVweb_PU_Shortcode();
	new MVweb_PU_Public();
}
