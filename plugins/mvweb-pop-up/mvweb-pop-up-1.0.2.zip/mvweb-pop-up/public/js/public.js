/**
 * MVweb Pop-Up — Public JavaScript
 *
 * Vanilla JS popup controller with a11y support:
 * focus trap, keyboard navigation, scroll lock,
 * prefers-reduced-motion, ARIA attributes.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

( function() {
	'use strict';

	var popup       = null;
	var modal       = null;
	var lastTrigger = null;
	var config      = window.mvwebPuConfig || {};
	var duration    = parseInt( config.animationDuration, 10 ) || 300;

	/**
	 * Get all focusable elements inside the modal.
	 *
	 * @return {Element[]} Array of visible focusable elements.
	 */
	function getFocusableElements() {
		var selector =
			'a[href], button:not([disabled]), textarea:not([disabled]), ' +
			'input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';
		var elements = Array.prototype.slice.call( modal.querySelectorAll( selector ) );

		return elements.filter( function( el ) {
			return el.offsetWidth > 0 && el.offsetHeight > 0;
		} );
	}

	/**
	 * Open the popup.
	 *
	 * @param {Element} triggerElement The button that triggered the popup.
	 */
	function openPopup( triggerElement ) {
		lastTrigger = triggerElement;

		popup.hidden = false;
		popup.setAttribute( 'aria-hidden', 'false' );
		popup.classList.add( 'mvweb-popup--open' );

		// Scroll lock with scrollbar width compensation.
		var scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
		document.body.style.paddingRight = scrollbarWidth + 'px';
		document.body.classList.add( 'mvweb-popup-scroll-lock' );

		// Focus on close button (predictable, always available).
		var closeBtn = popup.querySelector( '.mvweb-popup__close' );
		if ( closeBtn ) {
			closeBtn.focus();
		}
	}

	/**
	 * Finalize popup close: hide, restore scroll, return focus.
	 */
	function finalizeClose() {
		popup.classList.remove( 'mvweb-popup--closing' );
		popup.hidden = true;
		popup.setAttribute( 'aria-hidden', 'true' );

		// Remove scroll lock.
		document.body.style.paddingRight = '';
		document.body.classList.remove( 'mvweb-popup-scroll-lock' );

		// Return focus to the trigger button.
		if ( lastTrigger ) {
			lastTrigger.focus();
		}
	}

	/**
	 * Close the popup with animation.
	 */
	function closePopup() {
		popup.classList.remove( 'mvweb-popup--open' );
		popup.classList.add( 'mvweb-popup--closing' );

		// prefers-reduced-motion — close instantly.
		var reducedMotion = window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

		if ( reducedMotion ) {
			finalizeClose();
			return;
		}

		// Fallback timeout in case transitionend doesn't fire.
		var done    = false;
		var timeout = setTimeout( function() {
			if ( ! done ) {
				finalizeClose();
			}
		}, duration + 100 );

		modal.addEventListener( 'transitionend', function handler( e ) {
			// Listen only for opacity/transform on the modal element.
			if ( e.target !== modal ) {
				return;
			}
			if ( e.propertyName !== 'opacity' && e.propertyName !== 'transform' ) {
				return;
			}
			done = true;
			clearTimeout( timeout );
			modal.removeEventListener( 'transitionend', handler );
			finalizeClose();
		} );
	}

	/**
	 * Handle Tab key for focus trapping inside the modal.
	 *
	 * @param {KeyboardEvent} e Keyboard event.
	 */
	function trapFocus( e ) {
		if ( e.key !== 'Tab' ) {
			return;
		}

		var focusable = getFocusableElements();

		// No focusable elements — keep focus on container (tabindex="-1").
		if ( focusable.length === 0 ) {
			e.preventDefault();
			return;
		}

		var first = focusable[0];
		var last  = focusable[ focusable.length - 1 ];

		if ( e.shiftKey && document.activeElement === first ) {
			e.preventDefault();
			last.focus();
		} else if ( ! e.shiftKey && document.activeElement === last ) {
			e.preventDefault();
			first.focus();
		}
	}

	/**
	 * Handle keydown events on the popup.
	 *
	 * @param {KeyboardEvent} e Keyboard event.
	 */
	function handleKeydown( e ) {
		if ( e.key === 'Escape' && config.closeOnEscape ) {
			closePopup();
			return;
		}

		trapFocus( e );
	}

	/**
	 * Initialize popup when DOM is ready.
	 */
	function init() {
		popup = document.querySelector( '.mvweb-popup' );
		if ( ! popup ) {
			return;
		}

		modal = popup.querySelector( '.mvweb-popup__modal' );
		if ( ! modal ) {
			return;
		}

		// Set animation duration CSS variable from config.
		popup.style.setProperty( '--mvweb-popup-animation-duration', duration + 'ms' );

		// Trigger buttons — open popup.
		document.addEventListener( 'click', function( e ) {
			var trigger = e.target.closest( '[data-mvweb-popup-trigger]' );
			if ( trigger ) {
				openPopup( trigger );
			}
		} );

		// Close buttons and overlay.
		popup.addEventListener( 'click', function( e ) {
			var closeTarget = e.target.closest( '[data-mvweb-popup-close]' );
			if ( ! closeTarget ) {
				return;
			}

			// Overlay click — check config.
			if ( closeTarget.classList.contains( 'mvweb-popup__overlay' ) && ! config.closeOnOverlay ) {
				return;
			}

			closePopup();
		} );

		// Keyboard events.
		popup.addEventListener( 'keydown', handleKeydown );
	}

	// Initialize on DOMContentLoaded.
	if ( document.readyState === 'loading' ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
} )();
