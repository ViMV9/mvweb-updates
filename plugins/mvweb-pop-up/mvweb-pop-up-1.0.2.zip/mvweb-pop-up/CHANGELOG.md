# Changelog

All notable changes to MVweb Pop-Up will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.2] - 2026-02-07

### Fixed

- Menu not appearing on some servers due to OPcache serving stale bytecode without get_instance() call

## [1.0.1] - 2026-02-07

### Fixed

- Menu position collision with WooCommerce: changed from float to string `'99.5'` to prevent PHP float-to-int array key casting

## [1.0.0] - 2026-02-07

### Added

- Initial release
- Shortcode `[mvweb_popup]` for trigger button with customizable text
- Backward-compatible shortcode alias `[mvweb_pop-up]`
- Admin settings page with 4 tabs: General, Content, Styles, Advanced
- HTML popup content with strict wp_kses allowlist
- 4 animation types: Fade, Slide Up, Slide Down, Zoom
- Configurable animation duration (100–2000 ms)
- Custom CSS for button and popup with security sanitization
- Close on overlay click (configurable)
- Close on Escape key (configurable)
- Conditional asset loading — CSS/JS only on pages with shortcode
- Full accessibility: ARIA attributes, focus trap, keyboard navigation
- `prefers-reduced-motion` support — animations disabled for users with this preference
- Scroll lock with scrollbar width compensation (no layout shift)
- Focus return to trigger button on close
- Keep data on uninstall option
- Multisite support for uninstall cleanup
- English and Russian translations
- Automatic updates via MVweb update server
