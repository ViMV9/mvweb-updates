<?php
/**
 * MVweb Plugin Updater
 *
 * Wrapper for YahnisElsts/plugin-update-checker library.
 * Uses JSON metadata from a public update server (mvweb-updates repo).
 *
 * @package MVweb\Shared
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_Updater
 *
 * Handles plugin updates via JSON metadata endpoint.
 *
 * @since 1.0.0
 */
class MVweb_Updater {

	/**
	 * Base URL for the public update server.
	 *
	 * @var string
	 */
	const UPDATE_SERVER_URL = 'https://raw.githubusercontent.com/ViMV9/mvweb-updates/main';

	/**
	 * Plugin file path.
	 *
	 * @var string
	 */
	private $plugin_file;

	/**
	 * Plugin slug.
	 *
	 * @var string
	 */
	private $plugin_slug;

	/**
	 * Update checker instance.
	 *
	 * @var object|null
	 */
	private $update_checker = null;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 * @param string $plugin_file Full path to the main plugin file.
	 * @param string $plugin_slug Plugin slug (e.g. 'mvweb-price-table').
	 */
	public function __construct( $plugin_file, $plugin_slug ) {
		$this->plugin_file = $plugin_file;
		$this->plugin_slug = $plugin_slug;

		$this->init();
	}

	/**
	 * Initialize the updater.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function init() {
		if ( ! $this->load_update_checker() ) {
			return;
		}

		$this->setup_update_checker();
	}

	/**
	 * Load Plugin Update Checker library.
	 *
	 * Checks bundled location first (for production), then shared (for dev).
	 *
	 * @since 1.0.0
	 * @return bool True if loaded, false otherwise.
	 */
	private function load_update_checker() {
		// 1. Bundled with plugin (production).
		$bundled_path = dirname( $this->plugin_file ) . '/includes/plugin-update-checker/plugin-update-checker.php';

		if ( file_exists( $bundled_path ) ) {
			require_once $bundled_path;
			return true;
		}

		// 2. Shared location (development).
		$shared_path = dirname( dirname( dirname( $this->plugin_file ) ) ) . '/shared/plugin-update-checker/plugin-update-checker.php';

		if ( file_exists( $shared_path ) ) {
			require_once $shared_path;
			return true;
		}

		return false;
	}

	/**
	 * Setup the update checker with JSON metadata URL.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function setup_update_checker() {
		if ( ! class_exists( 'YahnisElsts\PluginUpdateChecker\v5\PucFactory' ) ) {
			return;
		}

		$metadata_url = self::UPDATE_SERVER_URL . '/plugins/' . $this->plugin_slug . '/info.json';

		$this->update_checker = \YahnisElsts\PluginUpdateChecker\v5\PucFactory::buildUpdateChecker(
			$metadata_url,
			$this->plugin_file,
			$this->plugin_slug
		);
	}

	/**
	 * Get update checker instance.
	 *
	 * @since 1.0.0
	 * @return object|null Update checker instance or null.
	 */
	public function get_update_checker() {
		return $this->update_checker;
	}

	/**
	 * Check for updates manually.
	 *
	 * @since 1.0.0
	 * @return object|null Update info or null.
	 */
	public function check_for_updates() {
		if ( null === $this->update_checker ) {
			return null;
		}

		return $this->update_checker->checkForUpdates();
	}

	/**
	 * Factory method to create updater instance.
	 *
	 * @since 1.0.0
	 * @param string $plugin_file Full path to the main plugin file.
	 * @param string $plugin_slug Plugin slug (e.g. 'mvweb-price-table').
	 * @return MVweb_Updater
	 */
	public static function create( $plugin_file, $plugin_slug ) {
		return new self( $plugin_file, $plugin_slug );
	}
}
