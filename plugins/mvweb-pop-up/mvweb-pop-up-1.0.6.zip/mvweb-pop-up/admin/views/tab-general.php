<?php
/**
 * General settings tab.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<h2 class="mvweb-section-title"><?php esc_html_e( 'Button', 'mvweb-pop-up' ); ?></h2>

<table class="form-table">
	<tr>
		<th scope="row">
			<label for="mvweb-pu-button-text"><?php esc_html_e( 'Default button text', 'mvweb-pop-up' ); ?></label>
		</th>
		<td>
			<input
				type="text"
				id="mvweb-pu-button-text"
				name="mvweb_pu_options[default_button_text]"
				value="<?php echo esc_attr( $options['default_button_text'] ); ?>"
				class="regular-text"
			/>
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Text shown on the trigger button. Can be overridden per shortcode: [mvweb_popup]Custom text[/mvweb_popup]', 'mvweb-pop-up' ); ?>
			</div>
		</td>
	</tr>
</table>

<h2 class="mvweb-section-title"><?php esc_html_e( 'Animation', 'mvweb-pop-up' ); ?></h2>

<table class="form-table">
	<tr>
		<th scope="row">
			<label for="mvweb-pu-animation"><?php esc_html_e( 'Animation type', 'mvweb-pop-up' ); ?></label>
		</th>
		<td>
			<select id="mvweb-pu-animation" name="mvweb_pu_options[animation]" class="mvweb-select">
				<option value="fade" <?php selected( $options['animation'], 'fade' ); ?>>
					<?php esc_html_e( 'Fade', 'mvweb-pop-up' ); ?>
				</option>
				<option value="slide-up" <?php selected( $options['animation'], 'slide-up' ); ?>>
					<?php esc_html_e( 'Slide Up', 'mvweb-pop-up' ); ?>
				</option>
				<option value="slide-down" <?php selected( $options['animation'], 'slide-down' ); ?>>
					<?php esc_html_e( 'Slide Down', 'mvweb-pop-up' ); ?>
				</option>
				<option value="zoom" <?php selected( $options['animation'], 'zoom' ); ?>>
					<?php esc_html_e( 'Zoom', 'mvweb-pop-up' ); ?>
				</option>
			</select>
		</td>
	</tr>
	<tr>
		<th scope="row">
			<label for="mvweb-pu-duration"><?php esc_html_e( 'Animation duration', 'mvweb-pop-up' ); ?></label>
		</th>
		<td>
			<input
				type="number"
				id="mvweb-pu-duration"
				name="mvweb_pu_options[animation_duration]"
				value="<?php echo esc_attr( $options['animation_duration'] ); ?>"
				min="100"
				max="2000"
				step="50"
				class="small-text"
			/> <?php esc_html_e( 'ms', 'mvweb-pop-up' ); ?>
			<div class="mvweb-help-text">
				<?php esc_html_e( '100 — 2000 ms. Users with prefers-reduced-motion will see no animation.', 'mvweb-pop-up' ); ?>
			</div>
		</td>
	</tr>
</table>
