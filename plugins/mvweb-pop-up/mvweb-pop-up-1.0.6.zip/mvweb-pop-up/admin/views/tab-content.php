<?php
/**
 * Content settings tab.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<h2 class="mvweb-section-title"><?php esc_html_e( 'Popup Content', 'mvweb-pop-up' ); ?></h2>

<table class="form-table">
	<tr>
		<th scope="row">
			<label for="mvweb-pu-popup-html"><?php esc_html_e( 'HTML content', 'mvweb-pop-up' ); ?></label>
		</th>
		<td>
			<textarea
				id="mvweb-pu-popup-html"
				name="mvweb_pu_options[popup_html]"
				rows="12"
				class="large-text code mvweb-textarea mvweb-pu-code"
			><?php echo esc_textarea( $options['popup_html'] ); ?></textarea>
			<div class="mvweb-help-text">
				<?php
				printf(
					/* translators: %s: list of allowed HTML tags */
					esc_html__( 'Allowed HTML tags: %s', 'mvweb-pop-up' ),
					'<code>' . esc_html( 'h1, h2, h3, h4, p, a, strong, em, br, ul, ol, li, img, div, span' ) . '</code>'
				);
				?>
			</div>
			<div class="mvweb-help-text">
				<?php esc_html_e( 'Attributes: class, id, href, target, rel, src, alt, width, height.', 'mvweb-pop-up' ); ?>
			</div>
		</td>
	</tr>
</table>
