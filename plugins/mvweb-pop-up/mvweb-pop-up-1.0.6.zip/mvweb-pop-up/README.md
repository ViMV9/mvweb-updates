# MVweb Pop-Up

Simple and accessible popup plugin with shortcode trigger for WordPress.

## Description

MVweb Pop-Up lets you add a customizable popup to any page using a simple shortcode. All buttons on the page open the same popup with content configured in the admin panel.

### Features

- **Shortcode Trigger**: `[mvweb_popup]` renders a button that opens the popup
- **Custom Button Text**: `[mvweb_popup]Click me[/mvweb_popup]`
- **4 Animations**: Fade, Slide Up, Slide Down, Zoom
- **Full Accessibility**: ARIA attributes, focus trap, keyboard navigation, screen reader support
- **prefers-reduced-motion**: Animations automatically disabled for users with this OS preference
- **Conditional Loading**: CSS/JS only loaded on pages that use the shortcode
- **Custom CSS**: Style the button and popup with your own CSS
- **Scroll Lock**: No layout shift when popup opens (scrollbar compensation)
- **Multilingual**: English and Russian translations included

## Requirements

- WordPress 6.4 or higher
- PHP 8.0 or higher

## Installation

1. Upload the `mvweb-pop-up` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **MVweb Plugins → Pop-Up** to configure

## Usage

### Basic

```
[mvweb_popup]
```

Renders a button with default text from settings. Clicking the button opens the popup.

### Custom Button Text

```
[mvweb_popup]Learn More[/mvweb_popup]
```

### Backward-Compatible Alias

```
[mvweb_pop-up]
```

### Multiple Buttons

Place multiple shortcodes on the same page — all buttons open the same popup:

```
[mvweb_popup]Button 1[/mvweb_popup]
[mvweb_popup]Button 2[/mvweb_popup]
```

## Settings

Configure the plugin at **MVweb Plugins → Pop-Up**:

| Tab | Options |
|-----|---------|
| General | Default button text, animation type, animation duration |
| Content | HTML content of the popup |
| Styles | Custom CSS for button and popup |
| Advanced | Close on overlay/Escape, keep data on uninstall |

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for a detailed list of changes.
