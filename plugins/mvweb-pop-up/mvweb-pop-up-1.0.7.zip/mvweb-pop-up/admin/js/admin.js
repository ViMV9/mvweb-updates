/**
 * Admin JavaScript for MVweb Pop-Up
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

(function() {
	'use strict';

	/**
	 * Allowed tab IDs (whitelist).
	 */
	var ALLOWED_TABS = ['general', 'content', 'styles', 'advanced', 'help'];

	/**
	 * Tabs that are not part of the settings form (no Save button).
	 */
	var NON_FORM_TABS = ['help'];

	/**
	 * Switch to a tab by its ID.
	 *
	 * @param {string} tabId Target tab ID.
	 * @param {NodeList} links Navigation links.
	 * @param {NodeList} panels Tab content panels.
	 */
	function activateTab(tabId, links, panels) {
		if (ALLOWED_TABS.indexOf(tabId) === -1) {
			return;
		}

		links.forEach(function(link) {
			link.classList.toggle('mvweb-nav__link--active', link.getAttribute('data-tab') === tabId);
		});

		panels.forEach(function(panel) {
			panel.classList.toggle('active', panel.id === tabId);
		});

		// Hide the Save button on tabs that are not part of the settings form.
		var submit = document.querySelector('.mvweb-settings .mvweb-submit');
		if (submit) {
			submit.style.display = NON_FORM_TABS.indexOf(tabId) === -1 ? '' : 'none';
		}
	}

	/**
	 * Initialize tab navigation.
	 */
	function initTabs() {
		var links = document.querySelectorAll('.mvweb-nav .mvweb-nav__link');
		var panels = document.querySelectorAll('.mvweb-tab-content');

		if (!links.length) {
			return;
		}

		links.forEach(function(link) {
			link.addEventListener('click', function(e) {
				e.preventDefault();

				var tabId = this.getAttribute('data-tab');

				if (ALLOWED_TABS.indexOf(tabId) === -1) {
					return;
				}

				activateTab(tabId, links, panels);

				// Update URL hash.
				if (window.history && window.history.pushState) {
					window.history.pushState(null, '', '#' + tabId);
				}
			});
		});

		// Activate tab from URL hash on load, otherwise sync the Save button
		// with the server-rendered active tab.
		var hash = window.location.hash.substring(1);
		if (hash && ALLOWED_TABS.indexOf(hash) !== -1) {
			activateTab(hash, links, panels);
		} else {
			var active = document.querySelector('.mvweb-nav__link--active');
			if (active) {
				activateTab(active.getAttribute('data-tab'), links, panels);
			}
		}
	}

	// Initialize on DOM ready.
	document.addEventListener('DOMContentLoaded', initTabs);
})();
