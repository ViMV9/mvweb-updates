<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-pop-up' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Get a popup running in three steps.', 'mvweb-pop-up' ); ?></p>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Add the popup content', 'mvweb-pop-up' ); ?></strong>
			<p><?php esc_html_e( 'Open the Content tab and enter the HTML shown inside the popup.', 'mvweb-pop-up' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Place the trigger button', 'mvweb-pop-up' ); ?></strong>
			<p>
				<?php
				printf(
					/* translators: %s: shortcode example */
					esc_html__( 'Insert the shortcode %s into any post, page or widget.', 'mvweb-pop-up' ),
					'<code>[mvweb_popup]</code>'
				);
				?>
			</p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Adjust the look', 'mvweb-pop-up' ); ?></strong>
			<p><?php esc_html_e( 'Pick an animation in the General tab and add Custom CSS in the Styles tab if needed.', 'mvweb-pop-up' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Features', 'mvweb-pop-up' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'What this plugin can do.', 'mvweb-pop-up' ); ?></p>

	<ul class="mvweb-bullets">
		<li><span class="mvweb-bullet-dot mvweb-bullet-dot--good"></span><?php esc_html_e( 'Accessible modal popup with focus trap and keyboard support.', 'mvweb-pop-up' ); ?></li>
		<li><span class="mvweb-bullet-dot mvweb-bullet-dot--good"></span><?php esc_html_e( 'Trigger button via shortcode, with per-button custom text.', 'mvweb-pop-up' ); ?></li>
		<li><span class="mvweb-bullet-dot mvweb-bullet-dot--good"></span><?php esc_html_e( 'Four animations with configurable duration and reduced-motion support.', 'mvweb-pop-up' ); ?></li>
		<li><span class="mvweb-bullet-dot mvweb-bullet-dot--good"></span><?php esc_html_e( 'Custom HTML content with a strict security allowlist.', 'mvweb-pop-up' ); ?></li>
		<li><span class="mvweb-bullet-dot mvweb-bullet-dot--good"></span><?php esc_html_e( 'Custom CSS, close on overlay click or Escape, assets loaded only where used.', 'mvweb-pop-up' ); ?></li>
	</ul>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-pop-up' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Answers to common questions.', 'mvweb-pop-up' ); ?></p>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How do I change the button text?', 'mvweb-pop-up' ); ?></summary>
		<div class="mvweb-faq__body">
			<p>
				<?php
				printf(
					/* translators: %s: shortcode example with custom text */
					esc_html__( 'Set a default in the General tab, or override it per button: %s.', 'mvweb-pop-up' ),
					'<code>[mvweb_popup]Custom text[/mvweb_popup]</code>'
				);
				?>
			</p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can I have several buttons on one page?', 'mvweb-pop-up' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Yes. All buttons on a page open the same popup, whose content is set in the Content tab.', 'mvweb-pop-up' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Why is my Custom CSS link or @import ignored?', 'mvweb-pop-up' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'External URLs and @import rules are stripped for security. Only data: URLs are allowed.', 'mvweb-pop-up' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-pop-up' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Where to get help and which version you run.', 'mvweb-pop-up' ); ?></p>
	<p>
		<?php
		printf(
			/* translators: %s: MVweb plugin URL */
			esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-pop-up' ),
			'<a href="https://mvweb.ru/plugins/mvweb-pop-up" target="_blank" rel="noopener noreferrer">mvweb.ru</a>'
		);
		?>
	</p>
	<p class="mvweb-block__sub">
		<?php
		printf(
			/* translators: %s: plugin version */
			esc_html__( 'MVweb Pop-Up v%s', 'mvweb-pop-up' ),
			esc_html( MVWEB_PU_VERSION )
		);
		?>
	</p>
</div>
