<?php
/**
 * Styles settings tab.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Custom CSS', 'mvweb-pop-up' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Styles applied to the popup and its trigger button.', 'mvweb-pop-up' ); ?></p>

	<div class="mvweb-alert mvweb-alert--info">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
		<div class="mvweb-alert__body">
			<p><?php esc_html_e( 'External URLs and @import rules are removed for security. Only data: URLs are allowed.', 'mvweb-pop-up' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb-pu-popup-css" class="mvweb-form-row__label">
			<?php esc_html_e( 'Custom CSS', 'mvweb-pop-up' ); ?>
		</label>
		<div class="mvweb-form-row__field">
			<textarea
				id="mvweb-pu-popup-css"
				name="mvweb_pu_options[popup_css]"
				rows="12"
				class="mvweb-textarea mvweb-pu-code"
			><?php echo esc_textarea( $options['popup_css'] ); ?></textarea>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'CSS output as-is. Write full rules with selectors.', 'mvweb-pop-up' ); ?>
			</p>
		</div>
	</div>
</div>
