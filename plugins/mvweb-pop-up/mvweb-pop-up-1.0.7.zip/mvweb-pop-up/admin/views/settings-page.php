<?php
/**
 * Admin settings page template.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$options = wp_parse_args( get_option( 'mvweb_pu_options', array() ), mvweb_pu_get_defaults() );

$current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.

$tabs = array(
	'general'  => array(
		'label' => __( 'General', 'mvweb-pop-up' ),
		'icon'  => 'grid',
	),
	'content'  => array(
		'label' => __( 'Content', 'mvweb-pop-up' ),
		'icon'  => 'doc',
	),
	'styles'   => array(
		'label' => __( 'Styles', 'mvweb-pop-up' ),
		'icon'  => 'brush',
	),
	'advanced' => array(
		'label' => __( 'Advanced', 'mvweb-pop-up' ),
		'icon'  => 'gear',
	),
	'help'     => array(
		'label' => __( 'Help', 'mvweb-pop-up' ),
		'icon'  => 'help',
	),
);

$icons = array(
	'grid'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
	'doc'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="8" y1="13" x2="16" y2="13"/><line x1="8" y1="17" x2="16" y2="17"/></svg>',
	'brush' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M18.37 2.63 14 7l-1.59-1.59a2 2 0 0 0-2.82 0L8 7l9 9 1.59-1.59a2 2 0 0 0 0-2.82L17 10l4.37-4.37a2.12 2.12 0 1 0-3-3Z"/><path d="M9 8c-2 3-4 3.5-7 4l8 10c2-1 6-5 6-7"/><path d="M14.5 17.5 4.5 15"/></svg>',
	'gear'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
	'help'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">PU</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Pop-Up', 'mvweb-pop-up' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_PU_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $tabs as $tab_id => $tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $tab_id ); ?>"
						class="mvweb-nav__link <?php echo esc_attr( $current_tab === $tab_id ? 'mvweb-nav__link--active' : '' ); ?>"
						data-tab="<?php echo esc_attr( $tab_id ); ?>">
						<?php echo $icons[ $tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $tab['label'] ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php settings_errors(); ?>

		<form method="post" action="options.php">
			<?php settings_fields( 'mvweb_pu_settings' ); ?>

			<div id="general" class="mvweb-tab-content <?php echo esc_attr( 'general' === $current_tab ? 'active' : '' ); ?>">
				<?php require MVWEB_PU_PATH . 'admin/views/tab-general.php'; ?>
			</div>

			<div id="content" class="mvweb-tab-content <?php echo esc_attr( 'content' === $current_tab ? 'active' : '' ); ?>">
				<?php require MVWEB_PU_PATH . 'admin/views/tab-content.php'; ?>
			</div>

			<div id="styles" class="mvweb-tab-content <?php echo esc_attr( 'styles' === $current_tab ? 'active' : '' ); ?>">
				<?php require MVWEB_PU_PATH . 'admin/views/tab-styles.php'; ?>
			</div>

			<div id="advanced" class="mvweb-tab-content <?php echo esc_attr( 'advanced' === $current_tab ? 'active' : '' ); ?>">
				<?php require MVWEB_PU_PATH . 'admin/views/tab-advanced.php'; ?>
			</div>

			<div class="mvweb-submit">
				<button type="submit" name="submit" class="mvweb-btn mvweb-btn--primary">
					<?php esc_html_e( 'Save Changes', 'mvweb-pop-up' ); ?>
				</button>
			</div>
		</form>

		<div id="help" class="mvweb-tab-content <?php echo esc_attr( 'help' === $current_tab ? 'active' : '' ); ?>">
			<?php require MVWEB_PU_PATH . 'admin/views/tab-help.php'; ?>
		</div>

	</main>
</div>
