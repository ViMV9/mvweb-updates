<?php
/**
 * Content settings tab.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Popup Content', 'mvweb-pop-up' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'The HTML shown inside the popup window.', 'mvweb-pop-up' ); ?></p>

	<div class="mvweb-form-row">
		<label for="mvweb-pu-popup-html" class="mvweb-form-row__label">
			<?php esc_html_e( 'HTML content', 'mvweb-pop-up' ); ?>
		</label>
		<div class="mvweb-form-row__field">
			<textarea
				id="mvweb-pu-popup-html"
				name="mvweb_pu_options[popup_html]"
				rows="12"
				class="mvweb-textarea mvweb-pu-code"
			><?php echo esc_textarea( $options['popup_html'] ); ?></textarea>
			<p class="mvweb-form-row__desc">
				<?php
				printf(
					/* translators: %s: list of allowed HTML tags */
					esc_html__( 'Allowed HTML tags: %s', 'mvweb-pop-up' ),
					'<code>' . esc_html( 'h1, h2, h3, h4, p, a, strong, em, br, ul, ol, li, img, div, span' ) . '</code>'
				);
				?>
			</p>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Attributes: class, id, href, target, rel, src, alt, width, height.', 'mvweb-pop-up' ); ?>
			</p>
		</div>
	</div>
</div>
