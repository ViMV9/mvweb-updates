<?php
/**
 * Advanced settings tab.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Behavior', 'mvweb-pop-up' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'How visitors can close the popup.', 'mvweb-pop-up' ); ?></p>

	<div class="mvweb-form-row">
		<label for="mvweb-pu-close-overlay" class="mvweb-form-row__label"><?php esc_html_e( 'Close on overlay click', 'mvweb-pop-up' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input
						type="checkbox"
						id="mvweb-pu-close-overlay"
						name="mvweb_pu_options[close_on_overlay]"
						value="1"
						<?php checked( $options['close_on_overlay'] ); ?>
					/>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Close popup when clicking outside the modal', 'mvweb-pop-up' ); ?></span>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb-pu-close-escape" class="mvweb-form-row__label"><?php esc_html_e( 'Close on Escape', 'mvweb-pop-up' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input
						type="checkbox"
						id="mvweb-pu-close-escape"
						name="mvweb_pu_options[close_on_escape]"
						value="1"
						<?php checked( $options['close_on_escape'] ); ?>
					/>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Close popup when pressing the Escape key', 'mvweb-pop-up' ); ?></span>
			</div>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Data', 'mvweb-pop-up' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'What happens to plugin settings when it is deleted.', 'mvweb-pop-up' ); ?></p>

	<div class="mvweb-form-row">
		<label for="mvweb-pu-keep-data" class="mvweb-form-row__label"><?php esc_html_e( 'Keep data on uninstall', 'mvweb-pop-up' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input
						type="checkbox"
						id="mvweb-pu-keep-data"
						name="mvweb_pu_options[keep_data]"
						value="1"
						<?php checked( $options['keep_data'] ); ?>
					/>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Keep plugin settings when the plugin is deleted', 'mvweb-pop-up' ); ?></span>
			</div>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Shortcode Usage', 'mvweb-pop-up' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Shortcodes you can place anywhere to open the popup.', 'mvweb-pop-up' ); ?></p>

	<div class="mvweb-table-wrap">
		<table class="mvweb-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Shortcode', 'mvweb-pop-up' ); ?></th>
					<th><?php esc_html_e( 'Description', 'mvweb-pop-up' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><code>[mvweb_popup]</code></td>
					<td><?php esc_html_e( 'Button with default text from settings', 'mvweb-pop-up' ); ?></td>
				</tr>
				<tr>
					<td><code>[mvweb_popup]Click me[/mvweb_popup]</code></td>
					<td><?php esc_html_e( 'Button with custom text', 'mvweb-pop-up' ); ?></td>
				</tr>
				<tr>
					<td><code>[mvweb_pop-up]</code></td>
					<td><?php esc_html_e( 'Backward-compatible alias', 'mvweb-pop-up' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>

	<p class="mvweb-form-row__desc">
		<?php esc_html_e( 'All buttons on the page open the same popup. The popup content is configured in the Content tab.', 'mvweb-pop-up' ); ?>
	</p>
</div>
