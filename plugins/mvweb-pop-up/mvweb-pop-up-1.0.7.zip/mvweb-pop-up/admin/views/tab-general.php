<?php
/**
 * General settings tab.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Button', 'mvweb-pop-up' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Text shown on the trigger button that opens the popup.', 'mvweb-pop-up' ); ?></p>

	<div class="mvweb-form-row">
		<label for="mvweb-pu-button-text" class="mvweb-form-row__label">
			<?php esc_html_e( 'Default button text', 'mvweb-pop-up' ); ?>
		</label>
		<div class="mvweb-form-row__field">
			<input
				type="text"
				id="mvweb-pu-button-text"
				name="mvweb_pu_options[default_button_text]"
				value="<?php echo esc_attr( $options['default_button_text'] ); ?>"
				class="mvweb-input"
			/>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Text shown on the trigger button. Can be overridden per shortcode: [mvweb_popup]Custom text[/mvweb_popup]', 'mvweb-pop-up' ); ?>
			</p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Animation', 'mvweb-pop-up' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'How the popup appears and disappears on screen.', 'mvweb-pop-up' ); ?></p>

	<div class="mvweb-form-row">
		<label for="mvweb-pu-animation" class="mvweb-form-row__label">
			<?php esc_html_e( 'Animation type', 'mvweb-pop-up' ); ?>
		</label>
		<div class="mvweb-form-row__field">
			<select id="mvweb-pu-animation" name="mvweb_pu_options[animation]" class="mvweb-select">
				<option value="fade" <?php selected( $options['animation'], 'fade' ); ?>>
					<?php esc_html_e( 'Fade', 'mvweb-pop-up' ); ?>
				</option>
				<option value="slide-up" <?php selected( $options['animation'], 'slide-up' ); ?>>
					<?php esc_html_e( 'Slide Up', 'mvweb-pop-up' ); ?>
				</option>
				<option value="slide-down" <?php selected( $options['animation'], 'slide-down' ); ?>>
					<?php esc_html_e( 'Slide Down', 'mvweb-pop-up' ); ?>
				</option>
				<option value="zoom" <?php selected( $options['animation'], 'zoom' ); ?>>
					<?php esc_html_e( 'Zoom', 'mvweb-pop-up' ); ?>
				</option>
			</select>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb-pu-duration" class="mvweb-form-row__label">
			<?php esc_html_e( 'Animation duration', 'mvweb-pop-up' ); ?>
		</label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-pu-input-row">
				<input
					type="number"
					id="mvweb-pu-duration"
					name="mvweb_pu_options[animation_duration]"
					value="<?php echo esc_attr( $options['animation_duration'] ); ?>"
					min="100"
					max="2000"
					step="50"
					class="mvweb-input mvweb-pu-input-num"
				/>
				<span class="mvweb-pu-input-suffix"><?php esc_html_e( 'ms', 'mvweb-pop-up' ); ?></span>
			</div>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( '100 — 2000 ms. Users with prefers-reduced-motion will see no animation.', 'mvweb-pop-up' ); ?>
			</p>
		</div>
	</div>
</div>
