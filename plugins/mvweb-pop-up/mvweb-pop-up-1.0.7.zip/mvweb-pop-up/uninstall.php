<?php
/**
 * Uninstall MVweb Pop-Up
 *
 * Fired when the plugin is uninstalled.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Clean up plugin data.
 *
 * @return void
 */
function mvweb_pu_uninstall_cleanup() {
	// Check if user wants to keep data.
	$options = get_option( 'mvweb_pu_options', array() );
	if ( ! empty( $options['keep_data'] ) ) {
		return;
	}

	// Delete plugin options.
	delete_option( 'mvweb_pu_options' );
}

if ( is_multisite() ) {
	// Clean up every site in the network.
	foreach ( get_sites( array( 'fields' => 'ids' ) ) as $site_id ) {
		switch_to_blog( $site_id );
		mvweb_pu_uninstall_cleanup();
		restore_current_blog();
	}
} else {
	mvweb_pu_uninstall_cleanup();
}
