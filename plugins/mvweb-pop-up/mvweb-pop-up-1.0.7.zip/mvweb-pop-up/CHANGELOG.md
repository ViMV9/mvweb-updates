# Changelog

All notable changes to MVweb Pop-Up will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.7] - 2026-06-05

### Changed
- Migrated admin UI to MVweb Admin UI Kit v2 (slate palette, Yoast-style sidebar layout)
- Settings page rebuilt with sidebar navigation (`.mvweb-sidebar` + `.mvweb-nav`) and main content column (`.mvweb-main`)
- Tabs rewritten with UI Kit components: `.mvweb-block`, `.mvweb-form-row`, `.mvweb-input`, `.mvweb-select`, `.mvweb-textarea`, `.mvweb-toggle`, `.mvweb-alert`, `.mvweb-table`
- Save button replaced with `.mvweb-btn--primary`
- Bundled MVweb_Menu updated to 2.5.0 (newest-wins loader, plugin catalog with one-click install, alphabetical hub submenu, dedicated hub textdomain)
- Refreshed bundled UI Kit `admin.css` (block spacing, FAQ card styling)
- Tab navigation reworked to drive `.mvweb-nav__link` instead of legacy `.nav-tab`
- Added `declare(strict_types=1)` to helpers

### Added
- Help tab with quick start, FAQ and support sections
- Bundled `images/mv-logo-violet.png` for the MVweb Hub hero logo

### Security
- Restrict allowed link and image protocols in popup HTML (`wp_kses`) to block `javascript:` and other unsafe schemes
- Harden Custom CSS sanitizer against `@import` bypass via comments and missing whitespace
- Strip legacy CSS `expression()` from Custom CSS
- Strip slashes from submitted settings before sanitizing (`wp_unslash`)

### Fixed
- Escape animation attribute on popup output
- Associate toggle labels with their inputs via `for` on the Advanced tab
- Escape navigation and tab class output on the settings page
- Wrap Help tab step content in a block so it aligns with the grid-based `.mvweb-steps` layout
- Render the Styles info alert with icon and `.mvweb-alert__body` per UI Kit
- Keep the "ms" suffix on the same line as the duration input
- Add spacing between content/style textareas and their descriptions
- Vertically centre form-row labels next to toggle switches
- Merge saved options with defaults (`wp_parse_args`) so upgrades from older versions never hit missing keys
- Print user Custom CSS in the document head by attaching it at enqueue time
- Show the native "Settings saved" notice on the settings page
- Run uninstall cleanup once per site on multisite (no duplicate pass on the main site)

### Translations
- Regenerated POT and updated Russian (ru_RU) translation for the new UI strings (Help tab, Save Changes)

## [1.0.6] - 2026-02-10

### Changed
- Admin CSS migrated to MVweb UI Kit "Classic Clean" shared framework
- Split admin styles into `admin.css` (shared UI Kit) and `plugin.css` (plugin-specific)
- HTML templates updated to use UI Kit classes: `.mvweb-section-title`, `.mvweb-select`, `.mvweb-checkbox`, `.mvweb-notice`, `.mvweb-table`, `.mvweb-help-text`, `.mvweb-textarea`
- Page title updated to "MVweb Pop-Up"

### Fixed
- Tab switching broken due to JS selector mismatch (`.mvweb-pu-tab-content` → `.mvweb-tab-content`)
- UI Kit: checkbox vertical alignment, input font-size, notice spacing

## [1.0.5] - 2026-02-09

### Fixed
- Bundled MVweb_Menu: added `MVWEB_DE_VERSION` to `detect_textdomain()`
- Admin menu renamed from "MVweb" to "MVweb Hub"
- Added "MVweb Hub" string to ru_RU translations

## [1.0.4] - 2026-02-07

### Fixed

- Fatal error when multiple MVweb plugins active: added class_exists() guard to MVweb_Updater

## [1.0.3] - 2026-02-07

### Changed

- Consolidated Button CSS and Popup CSS into a single Custom CSS field
- Custom CSS is now output as-is without wrapping in selectors — write full CSS rules with selectors directly

### Removed

- Button CSS field (use Custom CSS field with `.mvweb-popup-trigger` selector instead)

## [1.0.2] - 2026-02-07

### Fixed

- Menu not appearing on some servers due to OPcache serving stale bytecode without get_instance() call

## [1.0.1] - 2026-02-07

### Fixed

- Menu position collision with WooCommerce: changed from float to string `'99.5'` to prevent PHP float-to-int array key casting

## [1.0.0] - 2026-02-07

### Added

- Initial release
- Shortcode `[mvweb_popup]` for trigger button with customizable text
- Backward-compatible shortcode alias `[mvweb_pop-up]`
- Admin settings page with 4 tabs: General, Content, Styles, Advanced
- HTML popup content with strict wp_kses allowlist
- 4 animation types: Fade, Slide Up, Slide Down, Zoom
- Configurable animation duration (100–2000 ms)
- Custom CSS for button and popup with security sanitization
- Close on overlay click (configurable)
- Close on Escape key (configurable)
- Conditional asset loading — CSS/JS only on pages with shortcode
- Full accessibility: ARIA attributes, focus trap, keyboard navigation
- `prefers-reduced-motion` support — animations disabled for users with this preference
- Scroll lock with scrollbar width compensation (no layout shift)
- Focus return to trigger button on close
- Keep data on uninstall option
- Multisite support for uninstall cleanup
- English and Russian translations
- Automatic updates via MVweb update server
