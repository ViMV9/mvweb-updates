<?php
/**
 * Helper functions for MVweb Pop-Up plugin.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get default plugin options.
 *
 * @since 1.0.0
 * @return array Default options.
 */
function mvweb_pu_get_defaults() {
	return array(
		'default_button_text' => 'Open',
		'popup_html'          => '<h2>Welcome!</h2><p>This is your popup content. Edit it in the plugin settings.</p>',
		'animation'           => 'fade',
		'animation_duration'  => 300,
		'button_css'          => '',
		'popup_css'           => '',
		'close_on_overlay'    => true,
		'close_on_escape'     => true,
		'keep_data'           => false,
	);
}

/**
 * Sanitize user CSS.
 *
 * Removes HTML tags, @import, external url(), null bytes.
 *
 * @since 1.0.0
 * @param string $css Raw CSS string.
 * @return string Sanitized CSS.
 */
function mvweb_pu_sanitize_css( $css ) {
	if ( ! is_string( $css ) ) {
		return '';
	}
	$css = str_replace( "\0", '', $css );
	$css = wp_strip_all_tags( $css );
	$css = preg_replace( '/@import\s+[^;]*;?/i', '', $css );
	$css = preg_replace( '/url\s*\(\s*["\']?(?!data:)[^)]*\)/i', 'url()', $css );
	return $css;
}

/**
 * Get allowed HTML tags for popup content.
 *
 * @since 1.0.0
 * @return array Allowed HTML tags for wp_kses.
 */
function mvweb_pu_get_allowed_html() {
	return array(
		'h1'     => array( 'class' => true, 'id' => true ),
		'h2'     => array( 'class' => true, 'id' => true ),
		'h3'     => array( 'class' => true, 'id' => true ),
		'h4'     => array( 'class' => true, 'id' => true ),
		'p'      => array( 'class' => true ),
		'a'      => array( 'href' => true, 'class' => true, 'target' => true, 'rel' => true ),
		'strong' => array(),
		'em'     => array(),
		'br'     => array(),
		'ul'     => array( 'class' => true ),
		'ol'     => array( 'class' => true ),
		'li'     => array(),
		'img'    => array( 'src' => true, 'alt' => true, 'class' => true, 'width' => true, 'height' => true ),
		'div'    => array( 'class' => true, 'id' => true ),
		'span'   => array( 'class' => true ),
	);
}

/**
 * Enqueue public-facing assets.
 *
 * Called from shortcode class on first render.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pu_enqueue_public_assets() {
	$suffix  = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
	$options = get_option( 'mvweb_pu_options', mvweb_pu_get_defaults() );

	wp_enqueue_style(
		'mvweb-pu-public',
		MVWEB_PU_URL . 'public/css/public' . $suffix . '.css',
		array(),
		MVWEB_PU_VERSION
	);

	wp_enqueue_script(
		'mvweb-pu-public',
		MVWEB_PU_URL . 'public/js/public' . $suffix . '.js',
		array(),
		MVWEB_PU_VERSION,
		true
	);

	wp_localize_script(
		'mvweb-pu-public',
		'mvwebPuConfig',
		array(
			'animationDuration' => absint( $options['animation_duration'] ),
			'closeOnOverlay'    => (bool) $options['close_on_overlay'],
			'closeOnEscape'     => (bool) $options['close_on_escape'],
		)
	);
}
