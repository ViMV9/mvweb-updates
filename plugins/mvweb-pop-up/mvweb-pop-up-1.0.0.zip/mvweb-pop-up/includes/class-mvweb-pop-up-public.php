<?php
/**
 * Public-facing functionality for MVweb Pop-Up plugin.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PU_Public
 *
 * Handles popup rendering in wp_footer and inline styles.
 *
 * @since 1.0.0
 */
class MVweb_PU_Public {

	/**
	 * Whether the popup should be rendered.
	 *
	 * Set to true by MVweb_PU_Shortcode when first shortcode is rendered.
	 *
	 * @var bool
	 */
	private static $should_render = false;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'wp_footer', array( $this, 'render_popup' ) );
	}

	/**
	 * Enable popup rendering.
	 *
	 * Called from MVweb_PU_Shortcode on first shortcode render.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function enable_render() {
		self::$should_render = true;
	}

	/**
	 * Render popup HTML in wp_footer.
	 *
	 * Only renders if shortcode was used on the current page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function render_popup() {
		if ( ! self::$should_render ) {
			return;
		}

		$options      = get_option( 'mvweb_pu_options', mvweb_pu_get_defaults() );
		$allowed_html = mvweb_pu_get_allowed_html();
		$popup_html   = wp_kses( $options['popup_html'], $allowed_html );
		$animation    = esc_attr( $options['animation'] );

		// Inject custom CSS via wp_add_inline_style (already sanitized on save).
		$inline_css = '';
		if ( ! empty( $options['button_css'] ) ) {
			$inline_css .= '.mvweb-popup-trigger { ' . $options['button_css'] . ' }' . "\n";
		}
		if ( ! empty( $options['popup_css'] ) ) {
			$inline_css .= '.mvweb-popup__modal { ' . $options['popup_css'] . ' }' . "\n";
		}
		if ( $inline_css ) {
			wp_add_inline_style( 'mvweb-pu-public', $inline_css );
		}

		?>
		<div class="mvweb-popup mvweb-popup--<?php echo $animation; ?>"
		     role="dialog"
		     aria-modal="true"
		     aria-labelledby="mvweb-popup-label"
		     aria-hidden="true"
		     tabindex="-1"
		     hidden>
			<div class="mvweb-popup__overlay" data-mvweb-popup-close></div>
			<div class="mvweb-popup__modal">
				<button class="mvweb-popup__close" type="button" data-mvweb-popup-close
				        aria-label="<?php echo esc_attr( __( 'Close dialog', 'mvweb-pop-up' ) ); ?>">
					<span aria-hidden="true">&times;</span>
				</button>
				<div class="mvweb-popup__content" id="mvweb-popup-label">
					<?php echo $popup_html; // Already sanitized via wp_kses above. ?>
				</div>
			</div>
		</div>
		<?php
	}
}
