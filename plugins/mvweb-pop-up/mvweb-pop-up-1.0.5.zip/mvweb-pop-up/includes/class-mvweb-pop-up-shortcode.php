<?php
/**
 * Shortcode functionality for MVweb Pop-Up plugin.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PU_Shortcode
 *
 * Registers and renders the [mvweb_popup] shortcode.
 *
 * @since 1.0.0
 */
class MVweb_PU_Shortcode {

	/**
	 * Whether assets have been enqueued for this page load.
	 *
	 * @var bool
	 */
	private static $rendered = false;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_shortcode( 'mvweb_popup', array( $this, 'render' ) );
		add_shortcode( 'mvweb_pop-up', array( $this, 'render' ) );
	}

	/**
	 * Render the shortcode.
	 *
	 * Outputs a trigger button. On first render, enqueues assets
	 * and signals MVweb_PU_Public to render the popup in wp_footer.
	 *
	 * @since 1.0.0
	 * @param array  $atts    Shortcode attributes.
	 * @param string $content Shortcode content (custom button text).
	 * @return string Button HTML.
	 */
	public function render( $atts, $content = '' ) {
		// First shortcode on page — enqueue assets and enable popup render.
		if ( ! self::$rendered ) {
			mvweb_pu_enqueue_public_assets();
			MVweb_PU_Public::enable_render();
			self::$rendered = true;
		}

		$options     = get_option( 'mvweb_pu_options', mvweb_pu_get_defaults() );
		$button_text = ! empty( $content ) ? $content : $options['default_button_text'];
		$button_id   = wp_unique_id( 'mvweb-popup-trigger-' );

		return sprintf(
			'<button type="button" class="mvweb-popup-trigger" id="%s" data-mvweb-popup-trigger aria-haspopup="dialog">%s</button>',
			esc_attr( $button_id ),
			esc_html( $button_text )
		);
	}
}
