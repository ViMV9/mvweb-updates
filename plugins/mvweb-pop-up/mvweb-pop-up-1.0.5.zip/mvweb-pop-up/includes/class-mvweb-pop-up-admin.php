<?php
/**
 * Admin functionality for MVweb Pop-Up plugin.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PU_Admin
 *
 * Handles admin menu, settings registration, and admin assets.
 *
 * @since 1.0.0
 */
class MVweb_PU_Admin {

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_action( 'admin_init', array( $this, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	/**
	 * Register plugin settings.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register_settings() {
		register_setting(
			'mvweb_pu_settings',
			'mvweb_pu_options',
			array(
				'sanitize_callback' => array( $this, 'sanitize_options' ),
				'default'           => mvweb_pu_get_defaults(),
			)
		);
	}

	/**
	 * Sanitize plugin options.
	 *
	 * @since 1.0.0
	 * @param array $input Raw input values.
	 * @return array Sanitized values.
	 */
	public function sanitize_options( $input ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return get_option( 'mvweb_pu_options', mvweb_pu_get_defaults() );
		}

		$out = array();

		// Button text.
		$out['default_button_text'] = sanitize_text_field( $input['default_button_text'] ?? '' );

		// HTML — wp_kses with strict allowlist.
		$out['popup_html'] = wp_kses( $input['popup_html'] ?? '', mvweb_pu_get_allowed_html() );

		// Animation — whitelist.
		$allowed_animations = array( 'fade', 'slide-up', 'slide-down', 'zoom' );
		$out['animation']   = in_array( $input['animation'] ?? '', $allowed_animations, true )
			? $input['animation'] : 'fade';

		// Duration — range 100–2000.
		$out['animation_duration'] = max( 100, min( 2000, absint( $input['animation_duration'] ?? 300 ) ) );

		// CSS — strip tags, @import, external url().
		$out['popup_css'] = mvweb_pu_sanitize_css( $input['popup_css'] ?? '' );

		// Checkboxes.
		$out['close_on_overlay'] = ! empty( $input['close_on_overlay'] );
		$out['close_on_escape']  = ! empty( $input['close_on_escape'] );
		$out['keep_data']        = ! empty( $input['keep_data'] );

		return $out;
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		if ( false === strpos( $hook, 'mvweb-pop-up' ) ) {
			return;
		}

		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

		wp_enqueue_style(
			'mvweb-pu-admin',
			MVWEB_PU_URL . 'admin/css/admin' . $suffix . '.css',
			array(),
			MVWEB_PU_VERSION
		);

		wp_enqueue_script(
			'mvweb-pu-admin',
			MVWEB_PU_URL . 'admin/js/admin' . $suffix . '.js',
			array(),
			MVWEB_PU_VERSION,
			true
		);
	}
}
