<?php
/**
 * Admin settings page template.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$options = get_option( 'mvweb_pu_options', mvweb_pu_get_defaults() );
?>

<div class="wrap mvweb-pu-admin">
	<h1><?php esc_html_e( 'Pop-Up', 'mvweb-pop-up' ); ?></h1>

	<?php settings_errors( 'mvweb_pu_options' ); ?>

	<nav class="nav-tab-wrapper mvweb-pu-tabs">
		<a href="#general" class="nav-tab nav-tab-active" data-tab="general">
			<?php esc_html_e( 'General', 'mvweb-pop-up' ); ?>
		</a>
		<a href="#content" class="nav-tab" data-tab="content">
			<?php esc_html_e( 'Content', 'mvweb-pop-up' ); ?>
		</a>
		<a href="#styles" class="nav-tab" data-tab="styles">
			<?php esc_html_e( 'Styles', 'mvweb-pop-up' ); ?>
		</a>
		<a href="#advanced" class="nav-tab" data-tab="advanced">
			<?php esc_html_e( 'Advanced', 'mvweb-pop-up' ); ?>
		</a>
	</nav>

	<form method="post" action="options.php">
		<?php settings_fields( 'mvweb_pu_settings' ); ?>

		<!-- General Tab -->
		<div id="general" class="mvweb-pu-tab-content active">
			<?php include MVWEB_PU_PATH . 'admin/views/tab-general.php'; ?>
		</div>

		<!-- Content Tab -->
		<div id="content" class="mvweb-pu-tab-content">
			<?php include MVWEB_PU_PATH . 'admin/views/tab-content.php'; ?>
		</div>

		<!-- Styles Tab -->
		<div id="styles" class="mvweb-pu-tab-content">
			<?php include MVWEB_PU_PATH . 'admin/views/tab-styles.php'; ?>
		</div>

		<!-- Advanced Tab -->
		<div id="advanced" class="mvweb-pu-tab-content">
			<?php include MVWEB_PU_PATH . 'admin/views/tab-advanced.php'; ?>
		</div>

		<p class="submit mvweb-pu-submit">
			<?php submit_button( __( 'Save Settings', 'mvweb-pop-up' ), 'primary', 'submit', false ); ?>
		</p>
	</form>
</div>
