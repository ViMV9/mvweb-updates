<?php
/**
 * Styles settings tab.
 *
 * @package MVweb_Pop_Up
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<h2><?php esc_html_e( 'Custom CSS', 'mvweb-pop-up' ); ?></h2>

<div class="mvweb-pu-notice mvweb-pu-notice--info">
	<p><?php esc_html_e( 'External URLs and @import rules are removed for security. Only data: URLs are allowed.', 'mvweb-pop-up' ); ?></p>
</div>

<table class="form-table">
	<tr>
		<th scope="row">
			<label for="mvweb-pu-popup-css"><?php esc_html_e( 'Custom CSS', 'mvweb-pop-up' ); ?></label>
		</th>
		<td>
			<textarea
				id="mvweb-pu-popup-css"
				name="mvweb_pu_options[popup_css]"
				rows="12"
				class="large-text code"
			><?php echo esc_textarea( $options['popup_css'] ); ?></textarea>
			<p class="description">
				<?php esc_html_e( 'CSS output as-is. Write full rules with selectors.', 'mvweb-pop-up' ); ?>
			</p>
		</td>
	</tr>
</table>
