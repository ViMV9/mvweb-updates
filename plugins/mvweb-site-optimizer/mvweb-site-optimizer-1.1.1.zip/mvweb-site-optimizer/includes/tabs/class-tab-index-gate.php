<?php
/**
 * Index Gate tab — порог индексации для товаров и категорий WooCommerce.
 *
 * Недозаполненная сущность удерживается в noindex, follow и вне sitemap, пока
 * не пройдёт включённые проверки. Состояние считается на сохранении и фоновым
 * обходом, хранится в мете; robots, sitemap, IndexNow и сводка спрашивают
 * только should_hold() и сохранённое состояние.
 *
 * @package mvweb_so
 * @since   1.1.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Tab_Index_Gate {

	const ALLOWED_KEYS = array(
		'index_gate_enabled',
		'index_gate_live',
		'index_gate_product_words',
		'index_gate_product_image',
		'index_gate_product_gallery',
		'index_gate_product_attributes',
		'index_gate_cat_products',
		'index_gate_cat_words',
	);

	const DEFAULTS = array(
		'index_gate_product_words'      => 20,
		'index_gate_product_image'      => 'on',
		'index_gate_product_gallery'    => 0,
		'index_gate_product_attributes' => 0,
		'index_gate_cat_products'       => 2,
		'index_gate_cat_words'          => 0,
	);

	const NUMBER_KEYS = array(
		'index_gate_product_words',
		'index_gate_product_gallery',
		'index_gate_product_attributes',
		'index_gate_cat_products',
		'index_gate_cat_words',
	);

	const NUMBER_MAX = 10000;

	const TYPE_PRODUCT  = 'product';
	const TYPE_CATEGORY = 'product_cat';

	const META_STATE     = '_mvweb_so_ig_state';
	const META_FAILED    = '_mvweb_so_ig_failed';
	const META_CHECKED   = '_mvweb_so_ig_checked';
	const META_PASSED_AT = '_mvweb_so_ig_passed_at';

	const STATE_HELD     = 'held';
	const STATE_PASSED   = 'passed';
	const STATE_EXCEPTED = 'excepted';

	const OPTION_REBUILD = 'mvweb_so_ig_rebuild';
	const CRON_REBUILD   = 'mvweb_so_ig_rebuild_batch';
	const BATCH_SIZE     = 100;
	const BATCH_SECONDS  = 15;

	private array $dirty = array(
		self::TYPE_PRODUCT  => array(),
		self::TYPE_CATEGORY => array(),
	);

	private array $held_cache = array();

	private array $released_urls = array();

	public function __construct() {
		if ( is_admin() ) {
			add_filter( 'mvweb_so_sanitize_index-gate', array( $this, 'sanitize' ), 10, 2 );
			add_action( 'wp_ajax_mvweb_so_ig_rebuild', array( $this, 'ajax_rebuild' ) );
		}

		add_action( 'update_option_' . MVWEB_SO_OPTION, array( $this, 'on_settings_updated' ), 10, 2 );
		add_action( self::CRON_REBUILD, array( $this, 'run_rebuild' ) );

		if ( ! mvweb_so_check_option( 'index_gate_enabled' ) ) {
			return;
		}

		add_action( 'woocommerce_new_product', array( $this, 'mark_product' ) );
		add_action( 'woocommerce_update_product', array( $this, 'mark_product' ) );
		add_action( 'transition_post_status', array( $this, 'on_transition_post_status' ), 10, 3 );
		add_action( 'set_object_terms', array( $this, 'on_set_object_terms' ), 10, 6 );
		add_action( 'woocommerce_product_set_visibility', array( $this, 'mark_product_categories' ) );
		add_action( 'woocommerce_product_set_stock_status', array( $this, 'mark_product_categories' ) );
		add_action( 'before_delete_post', array( $this, 'mark_product_categories' ) );
		add_action( 'created_' . self::TYPE_CATEGORY, array( $this, 'mark_category' ) );
		add_action( 'edited_' . self::TYPE_CATEGORY, array( $this, 'mark_category' ) );
		add_action( 'pre_delete_term', array( $this, 'on_pre_delete_term' ), 10, 2 );
		add_action( 'shutdown', array( $this, 'flush_dirty' ) );

		if ( mvweb_so_check_option( 'index_gate_live' ) ) {
			add_action( 'plugins_loaded', array( $this, 'register_live_consumers' ), 20 );
		}
	}

	public static function setting( string $key ) {
		return mvweb_so_get_option( $key, self::DEFAULTS[ $key ] ?? '' );
	}

	public static function is_woocommerce_active(): bool {
		return function_exists( 'wc_get_product' ) && function_exists( 'wc_get_products' );
	}

	public function should_hold( int $id, string $type ): bool {
		return mvweb_so_check_option( 'index_gate_enabled' )
			&& mvweb_so_check_option( 'index_gate_live' )
			&& self::STATE_HELD === $this->read_meta( $id, $type, self::META_STATE );
	}

	public function mark_product( $product_id ): void {
		$product_id = (int) $product_id;

		if ( $product_id <= 0 ) {
			return;
		}

		$this->dirty[ self::TYPE_PRODUCT ][ $product_id ] = true;
		$this->mark_product_categories( $product_id );
	}

	public function mark_product_categories( $post_id ): void {
		$post_id = (int) $post_id;

		if ( $post_id <= 0 || self::TYPE_PRODUCT !== get_post_type( $post_id ) ) {
			return;
		}

		$term_ids = wp_get_post_terms( $post_id, self::TYPE_CATEGORY, array( 'fields' => 'ids' ) );

		if ( is_wp_error( $term_ids ) ) {
			return;
		}

		foreach ( $term_ids as $term_id ) {
			$this->mark_category( $term_id );
		}
	}

	public function mark_category( $term_id ): void {
		$term_id = (int) $term_id;

		if ( $term_id <= 0 ) {
			return;
		}

		$this->dirty[ self::TYPE_CATEGORY ][ $term_id ] = true;

		foreach ( get_ancestors( $term_id, self::TYPE_CATEGORY, 'taxonomy' ) as $parent_id ) {
			$this->dirty[ self::TYPE_CATEGORY ][ (int) $parent_id ] = true;
		}
	}

	public function on_pre_delete_term( $term_id, $taxonomy ): void {
		if ( self::TYPE_CATEGORY !== $taxonomy ) {
			return;
		}

		foreach ( get_ancestors( (int) $term_id, self::TYPE_CATEGORY, 'taxonomy' ) as $parent_id ) {
			$this->dirty[ self::TYPE_CATEGORY ][ (int) $parent_id ] = true;
		}
	}

	public function on_transition_post_status( $new_status, $old_status, $post ): void {
		if ( $new_status === $old_status || ! $post instanceof WP_Post || self::TYPE_PRODUCT !== $post->post_type ) {
			return;
		}

		$this->mark_product( $post->ID );
	}

	public function on_set_object_terms( $object_id, $terms, $tt_ids, $taxonomy, $append, $old_tt_ids ): void {
		if ( self::TYPE_CATEGORY !== $taxonomy ) {
			return;
		}

		$tt_ids = array_unique( array_merge( (array) $tt_ids, (array) $old_tt_ids ) );

		foreach ( $tt_ids as $tt_id ) {
			$term = get_term_by( 'term_taxonomy_id', (int) $tt_id, self::TYPE_CATEGORY );

			if ( $term instanceof WP_Term ) {
				$this->mark_category( $term->term_id );
			}
		}
	}

	public function flush_dirty(): void {
		$dirty       = $this->dirty;
		$this->dirty = array(
			self::TYPE_PRODUCT  => array(),
			self::TYPE_CATEGORY => array(),
		);

		foreach ( array_keys( $dirty[ self::TYPE_PRODUCT ] ) as $product_id ) {
			$this->evaluate( (int) $product_id, self::TYPE_PRODUCT );
		}

		foreach ( array_keys( $dirty[ self::TYPE_CATEGORY ] ) as $term_id ) {
			$this->evaluate( (int) $term_id, self::TYPE_CATEGORY );
		}

		$this->flush_released_urls();
	}

	public function evaluate( int $id, string $type ): ?string {
		if ( ! self::is_woocommerce_active() ) {
			return null;
		}

		if ( self::TYPE_PRODUCT === $type ) {
			$product = wc_get_product( $id );

			if ( ! $product instanceof WC_Product || $product->is_type( 'variation' ) || 'publish' !== $product->get_status() ) {
				return null;
			}

			$failed = $this->failed_product_criteria( $product );
		} else {
			$term = get_term( $id, self::TYPE_CATEGORY );

			if ( ! $term instanceof WP_Term ) {
				return null;
			}

			$failed = $this->failed_category_criteria( $term );
		}

		$state = self::STATE_PASSED;

		if ( ! empty( $failed ) ) {
			$state = $this->has_forced_index( $id, $type ) ? self::STATE_EXCEPTED : self::STATE_HELD;
		}

		$previous = (string) $this->read_meta( $id, $type, self::META_STATE );

		$this->write_meta( $id, $type, self::META_STATE, $state );
		$this->write_meta( $id, $type, self::META_FAILED, $failed );
		$this->write_meta( $id, $type, self::META_CHECKED, time() );

		if ( self::STATE_PASSED !== $state ) {
			$this->delete_meta( $id, $type, self::META_PASSED_AT );
		} elseif ( self::STATE_HELD === $previous ) {
			$this->write_meta( $id, $type, self::META_PASSED_AT, time() );
			$this->collect_released_url( $id, $type );
		}

		unset( $this->held_cache[ $type ] );

		return $state;
	}

	private function failed_product_criteria( WC_Product $product ): array {
		$failed = array();

		$words = (int) self::setting( 'index_gate_product_words' );
		if ( $words > 0 && self::count_words( $product->get_description() ) < $words ) {
			$failed[] = 'product_words';
		}

		if ( 'on' === self::setting( 'index_gate_product_image' ) && ! $product->get_image_id() ) {
			$failed[] = 'product_image';
		}

		$gallery = (int) self::setting( 'index_gate_product_gallery' );
		if ( $gallery > 0 && count( $product->get_gallery_image_ids() ) < $gallery ) {
			$failed[] = 'product_gallery';
		}

		$attributes = (int) self::setting( 'index_gate_product_attributes' );
		if ( $attributes > 0 && $this->count_filled_attributes( $product ) < $attributes ) {
			$failed[] = 'product_attributes';
		}

		return $failed;
	}

	private function failed_category_criteria( WP_Term $term ): array {
		$failed = array();

		$products = (int) self::setting( 'index_gate_cat_products' );
		if ( $products > 0 && $this->count_category_products( $term->term_id ) < $products ) {
			$failed[] = 'cat_products';
		}

		$words = (int) self::setting( 'index_gate_cat_words' );
		if ( $words > 0 && self::count_words( $term->description ) < $words ) {
			$failed[] = 'cat_words';
		}

		return $failed;
	}

	private static function count_words( $text ): int {
		return (int) preg_match_all( '/[\p{L}\p{N}]+/u', wp_strip_all_tags( (string) $text ) );
	}

	private function count_filled_attributes( WC_Product $product ): int {
		$count = 0;

		foreach ( $product->get_attributes() as $attribute ) {
			if ( $attribute instanceof WC_Product_Attribute && ! empty( $attribute->get_options() ) ) {
				++$count;
			}
		}

		return $count;
	}

	private function count_category_products( int $term_id ): int {
		$args = array(
			'status'              => 'publish',
			'visibility'          => 'catalog',
			'product_category_id' => array( $term_id ),
			'limit'               => 1,
			'paginate'            => true,
			'return'              => 'ids',
		);

		if ( 'yes' === get_option( 'woocommerce_hide_out_of_stock_items' ) ) {
			$args['stock_status'] = 'instock';
		}

		$result = wc_get_products( $args );

		return is_object( $result ) && isset( $result->total ) ? (int) $result->total : 0;
	}

	private function has_forced_index( int $id, string $type ): bool {
		if ( self::TYPE_CATEGORY === $type ) {
			return defined( 'WPSEO_VERSION' )
				&& class_exists( 'WPSEO_Taxonomy_Meta' )
				&& 'index' === WPSEO_Taxonomy_Meta::get_term_meta( $id, $type, 'noindex' );
		}

		if ( defined( 'WPSEO_VERSION' ) && '2' === (string) get_post_meta( $id, '_yoast_wpseo_meta-robots-noindex', true ) ) {
			return true;
		}

		if ( defined( 'AIOSEO_VERSION' ) && function_exists( 'aioseo' ) ) {
			try {
				$meta = aioseo()->meta->metaData->getMetaData( get_post( $id ) );

				if ( ! empty( $meta ) && empty( $meta->robots_default ) && empty( $meta->robots_noindex ) ) {
					return true;
				}
			} catch ( Throwable $e ) {
				return false;
			}
		}

		return false;
	}

	private function indexnow(): ?MVweb_SO_Tab_IndexNow {
		if ( ! mvweb_so_check_option( 'index_gate_live' ) || ! mvweb_so_check_option( 'indexnow_enabled' ) ) {
			return null;
		}

		$indexnow = $GLOBALS['mvweb_so_tab_indexnow'] ?? null;

		return $indexnow instanceof MVweb_SO_Tab_IndexNow ? $indexnow : null;
	}

	private function collect_released_url( int $id, string $type ): void {
		$indexnow = $this->indexnow();

		if ( null === $indexnow ) {
			return;
		}

		if ( self::TYPE_PRODUCT === $type ) {
			if ( ! in_array( self::TYPE_PRODUCT, $indexnow->get_selected_post_types(), true ) ) {
				return;
			}

			$url = get_permalink( $id );
		} else {
			$url = get_term_link( $id, self::TYPE_CATEGORY );
		}

		if ( is_string( $url ) && '' !== $url ) {
			$this->released_urls[] = $url;
		}
	}

	private function flush_released_urls(): void {
		$urls                = $this->released_urls;
		$this->released_urls = array();
		$indexnow            = $this->indexnow();

		if ( ! empty( $urls ) && null !== $indexnow ) {
			$indexnow->enqueue_urls( $urls );
		}
	}

	public function register_live_consumers(): void {
		mvweb_so_register_noindex( array( $this, 'is_current_page_held' ) );

		add_filter( 'wp_sitemaps_posts_query_args', array( $this, 'core_sitemap_posts_args' ), 10, 2 );
		add_filter( 'wp_sitemaps_taxonomies_query_args', array( $this, 'core_sitemap_terms_args' ), 10, 2 );
		add_filter( 'wpseo_exclude_from_sitemap_by_post_ids', array( $this, 'exclude_held_products' ) );
		add_filter( 'wpseo_exclude_from_sitemap_by_term_ids', array( $this, 'exclude_held_categories' ) );
		add_filter( 'aioseo_sitemap_exclude_posts', array( $this, 'exclude_held_products' ) );
		add_filter( 'aioseo_sitemap_term', array( $this, 'aioseo_sitemap_term' ), PHP_INT_MAX, 3 );
		add_filter( 'aioseo_sitemap_terms', array( $this, 'aioseo_sitemap_terms' ), PHP_INT_MAX );
		add_filter( 'rank_math/sitemap/entry', array( $this, 'rank_math_sitemap_entry' ), 10, 3 );
		add_filter( 'mvweb_so_indexnow_dispatch_urls', array( $this, 'filter_indexnow_urls' ) );
	}

	public function is_current_page_held(): bool {
		if ( function_exists( 'is_product' ) && is_product() ) {
			return $this->should_hold( get_queried_object_id(), self::TYPE_PRODUCT );
		}

		if ( function_exists( 'is_product_category' ) && is_product_category() ) {
			return $this->should_hold( get_queried_object_id(), self::TYPE_CATEGORY );
		}

		return false;
	}

	public function core_sitemap_posts_args( $args, $post_type ) {
		if ( self::TYPE_PRODUCT !== $post_type || ! is_array( $args ) ) {
			return $args;
		}

		$args['meta_query']   = isset( $args['meta_query'] ) && is_array( $args['meta_query'] ) ? $args['meta_query'] : array(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		$args['meta_query'][] = self::not_held_clause();

		return $args;
	}

	public function core_sitemap_terms_args( $args, $taxonomy ) {
		if ( self::TYPE_CATEGORY !== $taxonomy || ! is_array( $args ) ) {
			return $args;
		}

		$args['meta_query']   = isset( $args['meta_query'] ) && is_array( $args['meta_query'] ) ? $args['meta_query'] : array(); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
		$args['meta_query'][] = self::not_held_clause();

		return $args;
	}

	public function exclude_held_products( $ids ) {
		return array_merge( (array) $ids, $this->held_ids( self::TYPE_PRODUCT ) );
	}

	public function exclude_held_categories( $ids ) {
		return array_merge( (array) $ids, $this->held_ids( self::TYPE_CATEGORY ) );
	}

	public function aioseo_sitemap_term( $entry, $term_id, $taxonomy ) {
		if ( self::TYPE_CATEGORY === $taxonomy && in_array( (int) $term_id, $this->held_ids( self::TYPE_CATEGORY ), true ) ) {
			return false;
		}

		return $entry;
	}

	public function aioseo_sitemap_terms( $entries ) {
		return is_array( $entries ) ? array_values( array_filter( $entries ) ) : $entries;
	}

	public function rank_math_sitemap_entry( $url, $type, $item ) {
		if ( 'post' === $type && is_object( $item ) && isset( $item->ID, $item->post_type )
			&& self::TYPE_PRODUCT === $item->post_type && $this->should_hold( (int) $item->ID, self::TYPE_PRODUCT ) ) {
			return array();
		}

		if ( 'term' === $type && $item instanceof WP_Term && self::TYPE_CATEGORY === $item->taxonomy
			&& $this->should_hold( $item->term_id, self::TYPE_CATEGORY ) ) {
			return array();
		}

		return $url;
	}

	public function filter_indexnow_urls( $urls ) {
		$kept = array();

		foreach ( (array) $urls as $url ) {
			$post_id = url_to_postid( (string) $url );

			if ( $post_id > 0 && self::TYPE_PRODUCT === get_post_type( $post_id ) && $this->should_hold( $post_id, self::TYPE_PRODUCT ) ) {
				continue;
			}

			$kept[] = $url;
		}

		return $kept;
	}

	private static function not_held_clause(): array {
		return array(
			'relation' => 'OR',
			array(
				'key'     => self::META_STATE,
				'compare' => 'NOT EXISTS',
			),
			array(
				'key'     => self::META_STATE,
				'value'   => self::STATE_HELD,
				'compare' => '!=',
			),
		);
	}

	private function held_ids( string $type ): array {
		if ( ! isset( $this->held_cache[ $type ] ) ) {
			$this->held_cache[ $type ] = $this->ids_in_state( $type, array( self::STATE_HELD ) );
		}

		return $this->held_cache[ $type ];
	}

	private function ids_in_state( string $type, array $states, int $limit = -1 ): array {
		$meta_query = array(
			array(
				'key'     => self::META_STATE,
				'value'   => $states,
				'compare' => 'IN',
			),
		);

		if ( self::TYPE_PRODUCT === $type ) {
			$ids = get_posts(
				array(
					'post_type'        => self::TYPE_PRODUCT,
					'post_status'      => 'publish',
					'fields'           => 'ids',
					'posts_per_page'   => $limit,
					'orderby'          => 'title',
					'order'            => 'ASC',
					'no_found_rows'    => true,
					'suppress_filters' => true,
					'meta_query'       => $meta_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				)
			);
		} else {
			$ids = get_terms(
				array(
					'taxonomy'   => self::TYPE_CATEGORY,
					'hide_empty' => false,
					'fields'     => 'ids',
					'number'     => $limit > 0 ? $limit : 0,
					'orderby'    => 'name',
					'meta_query' => $meta_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				)
			);
		}

		return is_array( $ids ) ? array_map( 'intval', $ids ) : array();
	}

	public function sanitize( $accum, $raw ): array {
		$raw = is_array( $raw ) ? $raw : array();
		$out = array();

		foreach ( array( 'index_gate_enabled', 'index_gate_live', 'index_gate_product_image' ) as $key ) {
			$out[ $key ] = isset( $raw[ $key ] ) && 'on' === $raw[ $key ] ? 'on' : '';
		}

		foreach ( self::NUMBER_KEYS as $key ) {
			$value       = isset( $raw[ $key ] ) ? (int) $raw[ $key ] : (int) self::DEFAULTS[ $key ];
			$out[ $key ] = max( 0, min( self::NUMBER_MAX, $value ) );
		}

		return $out;
	}

	public function on_settings_updated( $old_value, $new_value ): void {
		$old_value = is_array( $old_value ) ? $old_value : array();
		$new_value = is_array( $new_value ) ? $new_value : array();

		if ( 'on' !== ( $new_value['index_gate_enabled'] ?? '' ) ) {
			wp_clear_scheduled_hook( self::CRON_REBUILD );
			delete_option( self::OPTION_REBUILD );
			return;
		}

		$changed = 'on' !== ( $old_value['index_gate_enabled'] ?? '' );

		foreach ( array_keys( self::DEFAULTS ) as $key ) {
			if ( ( $old_value[ $key ] ?? null ) !== ( $new_value[ $key ] ?? null ) ) {
				$changed = true;
				break;
			}
		}

		if ( $changed ) {
			$this->start_rebuild();
		}
	}

	public function start_rebuild(): void {
		update_option(
			self::OPTION_REBUILD,
			array(
				'phase'   => self::TYPE_PRODUCT,
				'cursor'  => 0,
				'done'    => 0,
				'started' => time(),
			),
			false
		);

		wp_clear_scheduled_hook( self::CRON_REBUILD );
		wp_schedule_single_event( time(), self::CRON_REBUILD );
	}

	public function run_rebuild(): void {
		$job = get_option( self::OPTION_REBUILD );

		if ( ! is_array( $job ) || ! mvweb_so_check_option( 'index_gate_enabled' ) || ! self::is_woocommerce_active() ) {
			delete_option( self::OPTION_REBUILD );
			return;
		}

		$deadline = time() + self::BATCH_SECONDS;

		while ( time() < $deadline ) {
			$phase = self::TYPE_CATEGORY === ( $job['phase'] ?? '' ) ? self::TYPE_CATEGORY : self::TYPE_PRODUCT;
			$ids   = $this->next_batch( $phase, (int) ( $job['cursor'] ?? 0 ) );

			if ( empty( $ids ) ) {
				if ( self::TYPE_PRODUCT === $phase ) {
					$job['phase']  = self::TYPE_CATEGORY;
					$job['cursor'] = 0;
					update_option( self::OPTION_REBUILD, $job, false );
					continue;
				}

				delete_option( self::OPTION_REBUILD );
				return;
			}

			foreach ( $ids as $id ) {
				$this->evaluate( $id, $phase );
				$job['cursor'] = $id;
				$job['done']   = (int) ( $job['done'] ?? 0 ) + 1;
			}

			$this->flush_released_urls();
			update_option( self::OPTION_REBUILD, $job, false );

			if ( function_exists( 'wp_cache_flush_runtime' ) ) {
				wp_cache_flush_runtime();
			}
		}

		wp_schedule_single_event( time(), self::CRON_REBUILD );
	}

	private function next_batch( string $phase, int $cursor ): array {
		global $wpdb;

		if ( self::TYPE_PRODUCT === $phase ) {
			$ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} WHERE post_type = %s AND post_status = 'publish' AND ID > %d ORDER BY ID ASC LIMIT %d",
					self::TYPE_PRODUCT,
					$cursor,
					self::BATCH_SIZE
				)
			);
		} else {
			$ids = $wpdb->get_col( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
				$wpdb->prepare(
					"SELECT term_id FROM {$wpdb->term_taxonomy} WHERE taxonomy = %s AND term_id > %d ORDER BY term_id ASC LIMIT %d",
					self::TYPE_CATEGORY,
					$cursor,
					self::BATCH_SIZE
				)
			);
		}

		return array_map( 'intval', (array) $ids );
	}

	public function ajax_rebuild(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Недостаточно прав.', 'mvweb-site-optimizer' ) ), 403 );
		}

		check_ajax_referer( 'mvweb_so_ajax', 'nonce' );

		if ( ! self::is_woocommerce_active() ) {
			wp_send_json_error( array( 'message' => __( 'Модуль работает с каталогом WooCommerce, а WooCommerce не активен.', 'mvweb-site-optimizer' ) ) );
		}

		if ( ! mvweb_so_check_option( 'index_gate_enabled' ) ) {
			wp_send_json_error( array( 'message' => __( 'Сначала включите порог индексации и сохраните настройки.', 'mvweb-site-optimizer' ) ) );
		}

		$this->start_rebuild();

		wp_send_json_success( array( 'message' => __( 'Пересчёт запущен и идёт в фоне. Обновите страницу через минуту, чтобы увидеть результат.', 'mvweb-site-optimizer' ) ) );
	}

	public function get_rebuild_status(): ?array {
		$job = get_option( self::OPTION_REBUILD );

		return is_array( $job ) ? $job : null;
	}

	public function get_summary(): array {
		$summary = array();

		foreach ( array( self::TYPE_PRODUCT, self::TYPE_CATEGORY ) as $type ) {
			if ( self::TYPE_PRODUCT === $type ) {
				$counts = wp_count_posts( self::TYPE_PRODUCT );
				$total  = isset( $counts->publish ) ? (int) $counts->publish : 0;
			} else {
				$total = (int) wp_count_terms(
					array(
						'taxonomy'   => self::TYPE_CATEGORY,
						'hide_empty' => false,
					)
				);
			}

			$held     = $this->count_in_state( $type, self::STATE_HELD );
			$excepted = $this->count_in_state( $type, self::STATE_EXCEPTED );

			$summary[ $type ] = array(
				'total'    => $total,
				'held'     => $held,
				'excepted' => $excepted,
				'share'    => $total > 0 ? (int) round( $held * 100 / $total ) : 0,
			);
		}

		return $summary;
	}

	private function count_in_state( string $type, string $state ): int {
		$meta_query = array(
			array(
				'key'   => self::META_STATE,
				'value' => $state,
			),
		);

		if ( self::TYPE_PRODUCT === $type ) {
			$query = new WP_Query(
				array(
					'post_type'              => self::TYPE_PRODUCT,
					'post_status'            => 'publish',
					'fields'                 => 'ids',
					'posts_per_page'         => 1,
					'update_post_meta_cache' => false,
					'update_post_term_cache' => false,
					'meta_query'             => $meta_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				)
			);

			return (int) $query->found_posts;
		}

		$count = wp_count_terms(
			array(
				'taxonomy'   => self::TYPE_CATEGORY,
				'hide_empty' => false,
				'meta_query' => $meta_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			)
		);

		return is_wp_error( $count ) ? 0 : (int) $count;
	}

	private function prime_caches( string $type, array $ids ): void {
		if ( empty( $ids ) ) {
			return;
		}

		if ( self::TYPE_PRODUCT === $type ) {
			_prime_post_caches( $ids, false, true );
			return;
		}

		_prime_term_caches( $ids, true );
	}

	public function get_held_items( int $limit ): array {
		$items = array();

		foreach ( array( self::TYPE_CATEGORY, self::TYPE_PRODUCT ) as $type ) {
			$ids = $this->ids_in_state( $type, array( self::STATE_HELD, self::STATE_EXCEPTED ), $limit );
			$this->prime_caches( $type, $ids );

			foreach ( $ids as $id ) {
				$items[] = $this->describe_item( $id, $type );
			}
		}

		return array_values( array_filter( $items ) );
	}

	public function get_recently_passed( int $limit ): array {
		$items = array();

		$product_ids = get_posts(
			array(
				'post_type'        => self::TYPE_PRODUCT,
				'post_status'      => 'publish',
				'fields'           => 'ids',
				'posts_per_page'   => $limit,
				'no_found_rows'    => true,
				'suppress_filters' => true,
				'meta_key'         => self::META_PASSED_AT, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'orderby'          => 'meta_value_num',
				'order'            => 'DESC',
			)
		);

		$product_ids = array_map( 'intval', (array) $product_ids );
		$this->prime_caches( self::TYPE_PRODUCT, $product_ids );

		foreach ( $product_ids as $id ) {
			$items[] = $this->describe_item( $id, self::TYPE_PRODUCT );
		}

		$term_ids = get_terms(
			array(
				'taxonomy'   => self::TYPE_CATEGORY,
				'hide_empty' => false,
				'fields'     => 'ids',
				'number'     => $limit,
				'meta_key'   => self::META_PASSED_AT, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'orderby'    => 'meta_value_num',
				'order'      => 'DESC',
			)
		);

		$term_ids = is_array( $term_ids ) ? array_map( 'intval', $term_ids ) : array();
		$this->prime_caches( self::TYPE_CATEGORY, $term_ids );

		foreach ( $term_ids as $id ) {
			$items[] = $this->describe_item( $id, self::TYPE_CATEGORY );
		}

		$items = array_filter( $items );

		usort(
			$items,
			static function ( array $a, array $b ): int {
				return $b['passed_at'] <=> $a['passed_at'];
			}
		);

		return array_slice( $items, 0, $limit );
	}

	private function describe_item( int $id, string $type ): ?array {
		if ( self::TYPE_PRODUCT === $type ) {
			$post = get_post( $id );

			if ( ! $post instanceof WP_Post ) {
				return null;
			}

			$name     = get_the_title( $post );
			$edit_url = get_edit_post_link( $post, 'raw' );
			$view_url = get_permalink( $post );
		} else {
			$term = get_term( $id, self::TYPE_CATEGORY );

			if ( ! $term instanceof WP_Term ) {
				return null;
			}

			$name     = $term->name;
			$edit_url = get_edit_term_link( $term, self::TYPE_CATEGORY );
			$view_url = get_term_link( $term );
		}

		$failed = $this->read_meta( $id, $type, self::META_FAILED );

		return array(
			'id'        => $id,
			'type'      => $type,
			'name'      => (string) $name,
			'edit_url'  => is_string( $edit_url ) ? $edit_url : '',
			'view_url'  => is_string( $view_url ) ? $view_url : '',
			'state'     => (string) $this->read_meta( $id, $type, self::META_STATE ),
			'failed'    => self::failed_labels( is_array( $failed ) ? $failed : array() ),
			'passed_at' => (int) $this->read_meta( $id, $type, self::META_PASSED_AT ),
		);
	}

	public static function failed_labels( array $codes ): array {
		$labels = array();

		foreach ( $codes as $code ) {
			switch ( $code ) {
				case 'product_words':
				case 'cat_words':
					$min = (int) self::setting( 'product_words' === $code ? 'index_gate_product_words' : 'index_gate_cat_words' );
					/* translators: %d: minimum number of words */
					$labels[] = sprintf( _n( 'описание короче %d слова', 'описание короче %d слов', $min, 'mvweb-site-optimizer' ), $min );
					break;
				case 'product_image':
					$labels[] = __( 'нет главного изображения', 'mvweb-site-optimizer' );
					break;
				case 'product_gallery':
					$min = (int) self::setting( 'index_gate_product_gallery' );
					/* translators: %d: minimum number of gallery images */
					$labels[] = sprintf( __( 'в галерее меньше %d фото', 'mvweb-site-optimizer' ), $min );
					break;
				case 'product_attributes':
					$min = (int) self::setting( 'index_gate_product_attributes' );
					/* translators: %d: minimum number of filled attributes */
					$labels[] = sprintf( _n( 'заполнено меньше %d характеристики', 'заполнено меньше %d характеристик', $min, 'mvweb-site-optimizer' ), $min );
					break;
				case 'cat_products':
					$min = (int) self::setting( 'index_gate_cat_products' );
					/* translators: %d: minimum number of products in category */
					$labels[] = sprintf( __( 'товаров меньше %d', 'mvweb-site-optimizer' ), $min );
					break;
			}
		}

		return $labels;
	}

	private function read_meta( int $id, string $type, string $key ) {
		return self::TYPE_PRODUCT === $type ? get_post_meta( $id, $key, true ) : get_term_meta( $id, $key, true );
	}

	private function write_meta( int $id, string $type, string $key, $value ): void {
		if ( self::TYPE_PRODUCT === $type ) {
			update_post_meta( $id, $key, $value );
		} else {
			update_term_meta( $id, $key, $value );
		}
	}

	private function delete_meta( int $id, string $type, string $key ): void {
		if ( self::TYPE_PRODUCT === $type ) {
			delete_post_meta( $id, $key );
		} else {
			delete_term_meta( $id, $key );
		}
	}
}
