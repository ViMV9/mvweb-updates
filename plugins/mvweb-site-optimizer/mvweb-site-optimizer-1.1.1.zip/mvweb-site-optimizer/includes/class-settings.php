<?php
/**
 * Settings handler for MVweb Site Optimizer.
 *
 * Single POST handler shared across all tabs. Each phase adds its
 * sanitize block via `mvweb_so_sanitize_{tab}` filter, so we don't
 * have to edit a central switch on every new tab.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Settings {

	public function maybe_handle_save(): void {
		if ( ! isset( $_POST['mvweb_so_save'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		check_admin_referer( 'mvweb_so_settings', 'mvweb_so_nonce' );

		$tab = isset( $_POST['mvweb_so_tab'] ) ? sanitize_key( wp_unslash( (string) $_POST['mvweb_so_tab'] ) ) : 'general';

		$raw = isset( $_POST['mvweb_so'] ) && is_array( $_POST['mvweb_so'] )
			? wp_unslash( $_POST['mvweb_so'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			: array();

		/**
		 * Все табы оборачиваются одной <form>, поэтому POST приходит со всеми
		 * полями сразу. Прогоняем sanitize-фильтры всех зарегистрированных
		 * вкладок: каждый возвращает только свои известные ключи.
		 *
		 * Фильтр-вызов с дефолтным значением array() — если sanitize-обработчик
		 * не зарегистрирован (general/redirect/help), apply_filters вернёт
		 * пустой массив, а не несанитизированный $raw. $raw передаётся вторым
		 * аргументом — реальные обработчики уже работают через него.
		 *
		 * @param array  $sanitized Заведомо безопасный аккумулятор (по дефолту пустой).
		 * @param array  $raw       Raw $_POST['mvweb_so'] для обработки внутри обработчика.
		 * @param string $tab_slug  Slug текущей итерации.
		 * @return array Sanitized key=>value пары, мердж в общие настройки.
		 */
		$sanitized = array();
		foreach ( array_keys( MVweb_SO_Admin::tabs() ) as $tab_slug ) {
			$tab_clean = apply_filters( 'mvweb_so_sanitize_' . $tab_slug, array(), $raw, $tab_slug );
			if ( is_array( $tab_clean ) ) {
				$sanitized = array_merge( $sanitized, $tab_clean );
			}
		}
		$sanitized = apply_filters( 'mvweb_so_sanitize', $sanitized, $tab );

		if ( ! is_array( $sanitized ) ) {
			$sanitized = array();
		}

		// Доп. защита: даже если sanitize-обработчик пропустил неизвестный
		// ключ, финальный whitelist отсечёт всё, что не зарегистрировано
		// в ALLOWED_KEYS вкладок.
		$allowed = self::collect_allowed_keys();
		if ( ! empty( $allowed ) ) {
			$sanitized = array_intersect_key( $sanitized, $allowed );
		}

		$settings = mvweb_so_get_settings();

		foreach ( $sanitized as $key => $value ) {
			if ( null === $value ) {
				unset( $settings[ $key ] );
			} else {
				$settings[ $key ] = $value;
			}
		}

		update_option( MVWEB_SO_OPTION, $settings, false );

		set_transient( $this->saved_flag_key(), '1', MINUTE_IN_SECONDS );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page' => 'mvweb-site-optimizer',
					'tab'  => $tab,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	public function maybe_render_saved_notice(): void {
		if ( ! get_transient( $this->saved_flag_key() ) ) {
			return;
		}
		delete_transient( $this->saved_flag_key() );

		wp_admin_notice(
			esc_html__( 'Настройки сохранены.', 'mvweb-site-optimizer' ),
			array(
				'type'               => 'success',
				'dismissible'        => true,
				'additional_classes' => array( 'mvweb-alert', 'mvweb-alert--success' ),
			)
		);
	}

	private function saved_flag_key(): string {
		return 'mvweb_so_saved_' . get_current_user_id();
	}

	/**
	 * Собирает белый список разрешённых ключей опций со всех вкладок.
	 *
	 * Используется как доп. фильтр в maybe_handle_save: даже если sanitize
	 * обработчик пропустит неизвестный ключ — финальный intersect отсечёт.
	 *
	 * @return array Массив вида ['key' => true, ...] для array_intersect_key.
	 */
	private static function collect_allowed_keys(): array {
		$classes = array(
			'MVweb_SO_Tab_Code',
			'MVweb_SO_Tab_Seo',
			'MVweb_SO_Tab_Duplicate',
			'MVweb_SO_Tab_Security',
			'MVweb_SO_Tab_Modules',
			'MVweb_SO_Tab_Additionally',
			'MVweb_SO_Tab_IndexNow',
			'MVweb_SO_Tab_Index_Gate',
			'MVweb_SO_Tab_Maintenance',
		);
		$keys = array();
		foreach ( $classes as $class ) {
			if ( class_exists( $class ) && defined( $class . '::ALLOWED_KEYS' ) ) {
				foreach ( $class::ALLOWED_KEYS as $key ) {
					$keys[ $key ] = true;
				}
			}
		}
		return $keys;
	}
}
