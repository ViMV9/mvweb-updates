<?php
/**
 * Admin orchestrator for MVweb Site Optimizer.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Admin {

	public function settings_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		require MVWEB_SO_PATH . 'admin/views/settings-page.php';
	}

	public static function current_tab(): string {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( (string) $_GET['tab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$allowed = self::tabs();
		return isset( $allowed[ $tab ] ) ? $tab : 'general';
	}

	public static function tabs(): array {
		return array(
			'general'      => __( 'Главная', 'mvweb-site-optimizer' ),
			'code'         => __( 'Код', 'mvweb-site-optimizer' ),
			'seo'          => __( 'SEO', 'mvweb-site-optimizer' ),
			'duplicate'    => __( 'Дубли', 'mvweb-site-optimizer' ),
			'security'     => __( 'Безопасность', 'mvweb-site-optimizer' ),
			'modules'      => __( 'Модули', 'mvweb-site-optimizer' ),
			'additionally' => __( 'Дополнительно', 'mvweb-site-optimizer' ),
			'redirect'     => __( 'Редиректы', 'mvweb-site-optimizer' ),
			'indexnow'     => __( 'IndexNow', 'mvweb-site-optimizer' ),
			'index-gate'   => __( 'Порог индексации', 'mvweb-site-optimizer' ),
			'maintenance'  => __( 'Обслуживание', 'mvweb-site-optimizer' ),
			'help'         => __( 'Справка', 'mvweb-site-optimizer' ),
		);
	}

	public static function tab_url( string $tab ): string {
		return add_query_arg(
			array(
				'page' => 'mvweb-site-optimizer',
				'tab'  => $tab,
			),
			admin_url( 'admin.php' )
		);
	}
}
