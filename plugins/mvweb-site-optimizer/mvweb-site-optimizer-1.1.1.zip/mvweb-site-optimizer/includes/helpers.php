<?php
/**
 * Helper functions for MVweb Site Optimizer.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function mvweb_so_get_settings(): array {
	$settings = get_option( MVWEB_SO_OPTION, array() );
	return is_array( $settings ) ? $settings : array();
}

function mvweb_so_get_option( string $key, $default = '' ) {
	$settings = mvweb_so_get_settings();
	return array_key_exists( $key, $settings ) ? $settings[ $key ] : $default;
}

function mvweb_so_check_option( string $key ): bool {
	return 'on' === mvweb_so_get_option( $key, '' );
}

function mvweb_so_update_option( string $key, $value ): bool {
	$settings         = mvweb_so_get_settings();
	$settings[ $key ] = $value;
	return update_option( MVWEB_SO_OPTION, $settings, false );
}

/**
 * Дописывает noindex, follow в тег robots того плагина, который его выводит.
 *
 * Вызывать не раньше plugins_loaded: SEO-плагины определяются по константам.
 *
 * @param callable $condition Возвращает true, когда текущую страницу надо закрыть.
 */
function mvweb_so_register_noindex( callable $condition ): void {
	$seo_plugin = false;

	if ( defined( 'WPSEO_VERSION' ) ) {
		add_filter(
			'wpseo_robots',
			static function ( $robots ) use ( $condition ) {
				return is_string( $robots ) && $condition() ? 'noindex, follow' : $robots;
			}
		);
		$seo_plugin = true;
	}

	if ( defined( 'AIOSEO_VERSION' ) ) {
		add_filter(
			'aioseo_robots_meta',
			static function ( $attributes ) use ( $condition ) {
				if ( is_array( $attributes ) && $condition() ) {
					$attributes['noindex']  = 'noindex';
					$attributes['nofollow'] = '';
				}
				return $attributes;
			}
		);
		$seo_plugin = true;
	}

	if ( defined( 'RANK_MATH_VERSION' ) ) {
		add_filter(
			'rank_math/frontend/robots',
			static function ( $robots ) use ( $condition ) {
				if ( is_array( $robots ) && $condition() ) {
					$robots['index']  = 'noindex';
					$robots['follow'] = 'follow';
				}
				return $robots;
			}
		);
		$seo_plugin = true;
	}

	if ( ! $seo_plugin ) {
		add_filter(
			'wp_robots',
			static function ( $robots ) use ( $condition ) {
				if ( is_array( $robots ) && $condition() ) {
					unset( $robots['nofollow'] );
					$robots['noindex'] = true;
					$robots['follow']  = true;
				}
				return $robots;
			}
		);
	}
}

function mvweb_so_count_active_features(): int {
	$count = 0;
	foreach ( mvweb_so_get_settings() as $value ) {
		if ( 'on' === $value ) {
			++$count;
		}
	}
	return $count;
}
