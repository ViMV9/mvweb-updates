<?php
/**
 * Index Gate tab — настройки порога индексации и сводка удержанных сущностей.
 *
 * @package mvweb_so
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_so_ig = isset( $GLOBALS['mvweb_so_tab_index_gate'] ) && $GLOBALS['mvweb_so_tab_index_gate'] instanceof MVweb_SO_Tab_Index_Gate
	? $GLOBALS['mvweb_so_tab_index_gate']
	: null;

if ( ! $mvweb_so_ig instanceof MVweb_SO_Tab_Index_Gate ) {
	return;
}

$mvweb_so_ig_wc      = MVweb_SO_Tab_Index_Gate::is_woocommerce_active();
$mvweb_so_ig_enabled = mvweb_so_check_option( 'index_gate_enabled' );
$mvweb_so_ig_live    = mvweb_so_check_option( 'index_gate_live' );
$mvweb_so_ig_ready   = $mvweb_so_ig_wc && $mvweb_so_ig_enabled;
$mvweb_so_ig_rebuild = $mvweb_so_ig_ready ? $mvweb_so_ig->get_rebuild_status() : null;
$mvweb_so_ig_summary = $mvweb_so_ig_ready ? $mvweb_so_ig->get_summary() : array();
$mvweb_so_ig_held    = $mvweb_so_ig_ready ? $mvweb_so_ig->get_held_items( 100 ) : array();
$mvweb_so_ig_passed  = $mvweb_so_ig_ready ? $mvweb_so_ig->get_recently_passed( 10 ) : array();
$mvweb_so_ig_types   = array(
	MVweb_SO_Tab_Index_Gate::TYPE_PRODUCT  => __( 'Товар', 'mvweb-site-optimizer' ),
	MVweb_SO_Tab_Index_Gate::TYPE_CATEGORY => __( 'Категория', 'mvweb-site-optimizer' ),
);

$mvweb_so_ig_number = static function ( string $key, string $label, string $desc ) {
	$id = 'mvweb-so-' . str_replace( '_', '-', $key );
	?>
	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="<?php echo esc_attr( $id ); ?>"><?php echo esc_html( $label ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number"
					id="<?php echo esc_attr( $id ); ?>"
					name="mvweb_so[<?php echo esc_attr( $key ); ?>]"
					class="mvweb-input"
					min="0"
					max="<?php echo esc_attr( (string) MVweb_SO_Tab_Index_Gate::NUMBER_MAX ); ?>"
					step="1"
					value="<?php echo esc_attr( (string) (int) MVweb_SO_Tab_Index_Gate::setting( $key ) ); ?>">
			<p class="mvweb-form-row__desc"><?php echo esc_html( $desc ); ?></p>
		</div>
	</div>
	<?php
};
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Порог индексации', 'mvweb-site-optimizer' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Держит недозаполненные товары и категории вне индекса, пока они не наберут минимум контента. Страница остаётся доступной посетителям, закрыт только вход в поиск: noindex, follow и исключение из sitemap. Когда товар или категорию дозаполнили, удержание снимается само при сохранении.', 'mvweb-site-optimizer' ); ?></p>

	<?php if ( ! $mvweb_so_ig_wc ) : ?>
		<div class="mvweb-alert mvweb-alert--warning">
			<div class="mvweb-alert__body">
				<p><?php esc_html_e( 'Модуль работает с каталогом WooCommerce, а WooCommerce на сайте не активен. Настройки можно сохранить, но проверять пока нечего.', 'mvweb-site-optimizer' ); ?></p>
			</div>
		</div>
	<?php endif; ?>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-so-index-gate-enabled"><?php esc_html_e( 'Включить порог индексации', 'mvweb-site-optimizer' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox"
						id="mvweb-so-index-gate-enabled"
						name="mvweb_so[index_gate_enabled]"
						value="on"
						<?php checked( $mvweb_so_ig_enabled ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Модуль начинает считать заполненность товаров и категорий. Пока боевой режим выключен, на сайте ничего не меняется — результат виден только в сводке ниже.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-so-index-gate-live"><?php esc_html_e( 'Боевой режим', 'mvweb-site-optimizer' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox"
						id="mvweb-so-index-gate-live"
						name="mvweb_so[index_gate_live]"
						value="on"
						<?php checked( $mvweb_so_ig_live ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Удержанные страницы получают noindex, follow, убираются из sitemap и не отправляются в IndexNow. Включайте только после того, как просмотрели список удержанных в режиме предпросмотра: слишком строгий порог выбьет из индекса рабочие страницы.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Требования к товару', 'mvweb-site-optimizer' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Товар проходит порог, когда выполнены все включённые проверки. Значение 0 выключает проверку.', 'mvweb-site-optimizer' ); ?></p>

	<?php
	$mvweb_so_ig_number(
		'index_gate_product_words',
		__( 'Слов в описании, не меньше', 'mvweb-site-optimizer' ),
		__( 'Считается полное описание товара, без HTML-разметки.', 'mvweb-site-optimizer' )
	);
	?>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-so-index-gate-product-image"><?php esc_html_e( 'Есть главное изображение', 'mvweb-site-optimizer' ); ?></label>
		<div class="mvweb-form-row__field">
			<label class="mvweb-toggle">
				<input type="checkbox"
						id="mvweb-so-index-gate-product-image"
						name="mvweb_so[index_gate_product_image]"
						value="on"
						<?php checked( 'on' === MVweb_SO_Tab_Index_Gate::setting( 'index_gate_product_image' ) ); ?>>
				<span class="mvweb-toggle__slider"></span>
			</label>
		</div>
	</div>

	<?php
	$mvweb_so_ig_number(
		'index_gate_product_gallery',
		__( 'Фото в галерее, не меньше', 'mvweb-site-optimizer' ),
		__( 'Главное изображение в это число не входит.', 'mvweb-site-optimizer' )
	);
	$mvweb_so_ig_number(
		'index_gate_product_attributes',
		__( 'Заполненных характеристик, не меньше', 'mvweb-site-optimizer' ),
		__( 'Считаются атрибуты товара, у которых задано хотя бы одно значение.', 'mvweb-site-optimizer' )
	);
	?>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Требования к категории товаров', 'mvweb-site-optimizer' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Закрывает пустые и почти пустые архивы. Значение 0 выключает проверку.', 'mvweb-site-optimizer' ); ?></p>

	<?php
	$mvweb_so_ig_number(
		'index_gate_cat_products',
		__( 'Товаров в категории, не меньше', 'mvweb-site-optimizer' ),
		__( 'Считаются опубликованные товары, видимые в каталоге, включая товары подкатегорий. Если в WooCommerce скрыты товары не в наличии — они тоже не считаются.', 'mvweb-site-optimizer' )
	);
	$mvweb_so_ig_number(
		'index_gate_cat_words',
		__( 'Слов в описании категории, не меньше', 'mvweb-site-optimizer' ),
		__( 'Описание категории из карточки термина, без HTML-разметки.', 'mvweb-site-optimizer' )
	);
	?>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Сводка', 'mvweb-site-optimizer' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Какая часть каталога сейчас не проходит порог. Список удержанных — это и рабочий список задач на дозаполнение.', 'mvweb-site-optimizer' ); ?></p>

	<?php if ( ! $mvweb_so_ig_ready ) : ?>
		<div class="mvweb-empty">
			<h3 class="mvweb-empty__title"><?php esc_html_e( 'Модуль выключен', 'mvweb-site-optimizer' ); ?></h3>
			<p class="mvweb-empty__text"><?php esc_html_e( 'Включите порог индексации и сохраните настройки — модуль пересчитает каталог в фоне, и здесь появится сводка.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	<?php else : ?>

		<?php if ( ! $mvweb_so_ig_live ) : ?>
			<div class="mvweb-alert mvweb-alert--info">
				<div class="mvweb-alert__body">
					<p class="mvweb-alert__title"><?php esc_html_e( 'Режим предпросмотра', 'mvweb-site-optimizer' ); ?></p>
					<p><?php esc_html_e( 'Модуль только считает: robots, sitemap и отправка в IndexNow не меняются. Проверьте список ниже и включите боевой режим, когда порог откалиброван.', 'mvweb-site-optimizer' ); ?></p>
				</div>
			</div>
		<?php endif; ?>

		<div class="mvweb-metrics">
			<?php foreach ( $mvweb_so_ig_summary as $mvweb_so_ig_type => $mvweb_so_ig_row ) : ?>
				<div class="mvweb-metric">
					<div class="mvweb-metric__label">
						<?php
						echo esc_html(
							MVweb_SO_Tab_Index_Gate::TYPE_PRODUCT === $mvweb_so_ig_type
								? __( 'Товаров удержано', 'mvweb-site-optimizer' )
								: __( 'Категорий удержано', 'mvweb-site-optimizer' )
						);
						?>
					</div>
					<div class="mvweb-metric__value">
						<?php
						/* translators: 1: held count, 2: total count, 3: share in percent */
						echo esc_html( sprintf( __( '%1$d из %2$d · %3$d%%', 'mvweb-site-optimizer' ), $mvweb_so_ig_row['held'], $mvweb_so_ig_row['total'], $mvweb_so_ig_row['share'] ) );
						?>
					</div>
				</div>
			<?php endforeach; ?>
			<div class="mvweb-metric">
				<div class="mvweb-metric__label"><?php esc_html_e( 'Исключения', 'mvweb-site-optimizer' ); ?></div>
				<div class="mvweb-metric__value">
					<?php echo esc_html( (string) array_sum( array_column( $mvweb_so_ig_summary, 'excepted' ) ) ); ?>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label">&nbsp;</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-so-actions">
					<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm" data-mvweb-so-ig-rebuild>
						<?php esc_html_e( 'Пересчитать всё', 'mvweb-site-optimizer' ); ?>
					</button>
				</div>
				<p class="mvweb-form-row__desc">
					<?php if ( is_array( $mvweb_so_ig_rebuild ) ) : ?>
						<?php
						/* translators: %d: processed entities */
						echo esc_html( sprintf( __( 'Идёт пересчёт в фоне: обработано %d. Цифры в сводке обновляются по мере обхода.', 'mvweb-site-optimizer' ), (int) ( $mvweb_so_ig_rebuild['done'] ?? 0 ) ) );
						?>
					<?php else : ?>
						<?php esc_html_e( 'Каталог пересчитывается сам при изменении настроек порога, а отдельные товары и категории — при сохранении. Кнопка нужна после массового импорта мимо WooCommerce.', 'mvweb-site-optimizer' ); ?>
					<?php endif; ?>
				</p>
				<div class="mvweb-so-feedback" data-mvweb-so-ig-feedback aria-live="polite"></div>
			</div>
		</div>

		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Удержано', 'mvweb-site-optimizer' ); ?></th>
						<th><?php esc_html_e( 'Тип', 'mvweb-site-optimizer' ); ?></th>
						<th><?php esc_html_e( 'Не пройдено', 'mvweb-site-optimizer' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php if ( empty( $mvweb_so_ig_held ) ) : ?>
						<tr>
							<td colspan="3">
								<div class="mvweb-empty">
									<h3 class="mvweb-empty__title"><?php esc_html_e( 'Удержанных нет', 'mvweb-site-optimizer' ); ?></h3>
									<p class="mvweb-empty__text"><?php esc_html_e( 'Все проверенные товары и категории проходят порог. Если пересчёт ещё идёт, загляните позже.', 'mvweb-site-optimizer' ); ?></p>
								</div>
							</td>
						</tr>
					<?php else : ?>
						<?php foreach ( $mvweb_so_ig_held as $mvweb_so_ig_item ) : ?>
							<tr>
								<td>
									<?php if ( '' !== $mvweb_so_ig_item['edit_url'] ) : ?>
										<a href="<?php echo esc_url( $mvweb_so_ig_item['edit_url'] ); ?>"><?php echo esc_html( $mvweb_so_ig_item['name'] ); ?></a>
									<?php else : ?>
										<?php echo esc_html( $mvweb_so_ig_item['name'] ); ?>
									<?php endif; ?>
									<?php if ( MVweb_SO_Tab_Index_Gate::STATE_EXCEPTED === $mvweb_so_ig_item['state'] ) : ?>
										<span class="mvweb-badge mvweb-badge--info mvweb-badge--small"><?php esc_html_e( 'ручной index в SEO-плагине', 'mvweb-site-optimizer' ); ?></span>
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( $mvweb_so_ig_types[ $mvweb_so_ig_item['type'] ] ?? '' ); ?></td>
								<td><?php echo esc_html( implode( '; ', $mvweb_so_ig_item['failed'] ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>

		<?php $mvweb_so_ig_shown = array_count_values( array_column( $mvweb_so_ig_held, 'type' ) ); ?>
		<?php foreach ( $mvweb_so_ig_summary as $mvweb_so_ig_type => $mvweb_so_ig_row ) : ?>
			<?php
			$mvweb_so_ig_all   = (int) $mvweb_so_ig_row['held'] + (int) $mvweb_so_ig_row['excepted'];
			$mvweb_so_ig_count = (int) ( $mvweb_so_ig_shown[ $mvweb_so_ig_type ] ?? 0 );

			if ( $mvweb_so_ig_all <= $mvweb_so_ig_count ) {
				continue;
			}
			?>
			<p class="mvweb-block__sub">
				<?php
				echo esc_html(
					sprintf(
						MVweb_SO_Tab_Index_Gate::TYPE_PRODUCT === $mvweb_so_ig_type
							/* translators: 1: shown rows, 2: all held products */
							? _n( 'Показаны первые %1$d из %2$d удержанного товара.', 'Показаны первые %1$d из %2$d удержанных товаров.', $mvweb_so_ig_all, 'mvweb-site-optimizer' )
							/* translators: 1: shown rows, 2: all held categories */
							: _n( 'Показаны первые %1$d из %2$d удержанной категории.', 'Показаны первые %1$d из %2$d удержанных категорий.', $mvweb_so_ig_all, 'mvweb-site-optimizer' ),
						$mvweb_so_ig_count,
						$mvweb_so_ig_all
					)
				);
				?>
			</p>
		<?php endforeach; ?>
	<?php endif; ?>
</div>

<?php if ( $mvweb_so_ig_ready && ! empty( $mvweb_so_ig_passed ) ) : ?>
	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Недавно прошли порог', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Проверьте через несколько дней, что эти страницы появились в индексе Яндекса и Google.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Страница', 'mvweb-site-optimizer' ); ?></th>
						<th><?php esc_html_e( 'Тип', 'mvweb-site-optimizer' ); ?></th>
						<th><?php esc_html_e( 'Прошла порог', 'mvweb-site-optimizer' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $mvweb_so_ig_passed as $mvweb_so_ig_item ) : ?>
						<tr>
							<td>
								<?php if ( '' !== $mvweb_so_ig_item['view_url'] ) : ?>
									<a href="<?php echo esc_url( $mvweb_so_ig_item['view_url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $mvweb_so_ig_item['name'] ); ?></a>
								<?php else : ?>
									<?php echo esc_html( $mvweb_so_ig_item['name'] ); ?>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( $mvweb_so_ig_types[ $mvweb_so_ig_item['type'] ] ?? '' ); ?></td>
							<td class="cell-mono"><?php echo esc_html( $mvweb_so_ig_item['passed_at'] > 0 ? wp_date( 'Y-m-d H:i', $mvweb_so_ig_item['passed_at'] ) : '—' ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	</div>
<?php endif; ?>
