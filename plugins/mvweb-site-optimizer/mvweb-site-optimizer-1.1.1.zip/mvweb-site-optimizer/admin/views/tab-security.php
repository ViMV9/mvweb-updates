<?php
/**
 * Security tab — REST API, hide-login, login attempts, session expiration.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$hide_login_slug      = (string) mvweb_so_get_option( 'hide_wp_login_new_slug', '' );
$la_allowed_retries   = (int) mvweb_so_get_option( 'login_attempts_allowed_retries', MVweb_SO_Tab_Security::DEFAULT_ALLOWED_RETRIES );
$la_allowed_lockouts  = (int) mvweb_so_get_option( 'login_attempts_allowed_lockouts', MVweb_SO_Tab_Security::DEFAULT_ALLOWED_LOCKOUTS );
$la_lockout_duration  = (int) mvweb_so_get_option( 'login_attempts_lockout_duration', MVweb_SO_Tab_Security::DEFAULT_LOCKOUT_DURATION );
$la_long_duration     = (int) mvweb_so_get_option( 'login_attempts_long_duration', MVweb_SO_Tab_Security::DEFAULT_LONG_DURATION );
$la_whitelist         = (string) mvweb_so_get_option( 'login_attempts_whitelist', '' );
$la_blacklist         = (string) mvweb_so_get_option( 'login_attempts_blacklist', '' );
$la_behind_proxy      = mvweb_so_check_option( 'login_attempts_behind_proxy' );
$la_trusted_header    = (string) mvweb_so_get_option( 'login_attempts_trusted_header', 'HTTP_X_FORWARDED_FOR' );
$session_expiration   = (int) mvweb_so_get_option( 'session_expiration', 0 );

$session_presets = array(
	0        => __( 'По умолчанию WordPress (14 дней)', 'mvweb-site-optimizer' ),
	1209600  => __( '14 дней', 'mvweb-site-optimizer' ),
	2592000  => __( '30 дней', 'mvweb-site-optimizer' ),
	7776000  => __( '3 месяца', 'mvweb-site-optimizer' ),
	15552000 => __( '6 месяцев', 'mvweb-site-optimizer' ),
	31536000 => __( '1 год', 'mvweb-site-optimizer' ),
);
$la_state           = MVweb_SO_Tab_Security::get_state();
$la_total           = (int) $la_state['total'];
$la_lockout_rows    = MVweb_SO_Tab_Security::get_active_lockouts();
$la_active_lockouts = count( $la_lockout_rows );

$current_login_url = $hide_login_slug ? home_url( '/' . $hide_login_slug . '/' ) : home_url( '/wp-login.php' );
?>

<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'REST API', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'С версии WordPress 4.4 движок создаёт технические страницы /wp-json/, через которые можно получить список пользователей, авторов записей и другую служебную информацию. Поисковики иногда индексируют эти URL. Закройте анонимный доступ — авторизованные пользователи и нужные плагины (Yoast, Contact Form 7, WooCommerce, Elementor и др.) продолжат работать через whitelist.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-json-rest-api">
				<?php esc_html_e( 'Запретить REST API неавторизованным', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-json-rest-api"
							name="mvweb_so[disable_json_rest_api]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_json_rest_api' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Все запросы к /wp-json/* от неавторизованных пользователей возвращают 401, кроме маршрутов из whitelist. Также убирает rest-link/oEmbed discovery из <head>. Если используется кастомная интеграция — добавьте префикс маршрута через фильтр mvweb_so_rest_api_white_list.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Скрытие wp-login.php', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Переименуйте страницу входа на произвольный URL и закройте прямой доступ к wp-login.php / wp-admin/. Защита от ботов, перебирающих стандартные адреса.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-alert mvweb-alert--warning">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
			<div class="mvweb-alert__body">
				<p class="mvweb-alert__title"><?php esc_html_e( 'Внимание!', 'mvweb-site-optimizer' ); ?></p>
				<p><?php esc_html_e( 'Запишите новый URL входа в надёжное место. Если потеряете доступ к админке — деактивируйте плагин через FTP/SSH (переименуйте папку wp-content/plugins/mvweb-site-optimizer).', 'mvweb-site-optimizer' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-hide-wp-login">
				<?php esc_html_e( 'Включить скрытие входа', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-hide-wp-login"
							name="mvweb_so[hide_wp_login]"
							value="on"
							<?php checked( mvweb_so_check_option( 'hide_wp_login' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Прямой доступ к /wp-login.php, /wp-register.php и /wp-admin/ (для неавторизованных) возвращает 403. Вход доступен только по новому URL.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-hide-wp-login-slug">
				<?php esc_html_e( 'Новый URL входа', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
						id="mvweb-so-hide-wp-login-slug"
						name="mvweb_so[hide_wp_login_new_slug]"
						class="mvweb-input"
						value="<?php echo esc_attr( $hide_login_slug ); ?>"
						placeholder="my-secret-login"
						autocomplete="off">
				<p class="mvweb-form-row__desc">
					<?php
					echo wp_kses(
						sprintf(
							/* translators: %s: full login URL */
							esc_html__( 'Только латиница, цифры, дефис. Текущий URL входа: %s', 'mvweb-site-optimizer' ),
							'<code>' . esc_html( $current_login_url ) . '</code>'
						),
						array( 'code' => array() )
					);
					?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Ограничение попыток входа', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Блокирует IP после нескольких неудачных попыток. После серии блокировок включается продолжительный бан. Журнал блокировок хранится в отдельной опции.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-metrics">
			<div class="mvweb-metric">
				<div class="mvweb-metric__label"><?php esc_html_e( 'Всего блокировок', 'mvweb-site-optimizer' ); ?></div>
				<div class="mvweb-metric__value"><?php echo esc_html( (string) $la_total ); ?></div>
			</div>
			<div class="mvweb-metric">
				<div class="mvweb-metric__label"><?php esc_html_e( 'Активных сейчас', 'mvweb-site-optimizer' ); ?></div>
				<div class="mvweb-metric__value" data-mvweb-so-la-active><?php echo esc_html( (string) $la_active_lockouts ); ?></div>
			</div>
		</div>

		<div class="mvweb-so-feedback" data-mvweb-so-la-feedback aria-live="polite"></div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label"><?php esc_html_e( 'Активные блокировки', 'mvweb-site-optimizer' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-so-actions">
					<button type="button"
							class="mvweb-btn mvweb-btn--danger mvweb-btn--sm"
							data-mvweb-so-la-release-all
							<?php disabled( 0 === $la_active_lockouts ); ?>>
						<?php esc_html_e( 'Снять все блокировки', 'mvweb-site-optimizer' ); ?>
					</button>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Снятие открывает вход с адреса сразу и обнуляет его счётчик попыток. Логин показывает, что вводили с этого адреса в последний раз, — по нему находится строка нужного человека. Блокировка привязана к IP, а не к учётной записи.', 'mvweb-site-optimizer' ); ?>
					<?php if ( $la_behind_proxy ) : ?>
						<br>
						<?php esc_html_e( 'Сайт работает за прокси: одна попытка входа создаёт две записи — с адреса посетителя и с адреса прокси. Снимайте обе строки с одинаковым логином.', 'mvweb-site-optimizer' ); ?>
					<?php endif; ?>
				</p>
			</div>
		</div>

		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'IP', 'mvweb-site-optimizer' ); ?></th>
						<th><?php esc_html_e( 'Логин', 'mvweb-site-optimizer' ); ?></th>
						<th><?php esc_html_e( 'Осталось', 'mvweb-site-optimizer' ); ?></th>
						<th><?php esc_html_e( 'Попыток', 'mvweb-site-optimizer' ); ?></th>
						<th><?php esc_html_e( 'Действие', 'mvweb-site-optimizer' ); ?></th>
					</tr>
				</thead>
				<tbody data-mvweb-so-la-rows>
					<tr data-mvweb-so-la-empty <?php echo $la_active_lockouts > 0 ? 'hidden' : ''; ?>>
						<td colspan="5">
							<div class="mvweb-empty">
								<div class="mvweb-empty__icon">
									<svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
										<rect x="3" y="11" width="18" height="11" rx="2"/>
										<path d="M7 11V7a5 5 0 0 1 9.9-1"/>
									</svg>
								</div>
								<h3 class="mvweb-empty__title"><?php esc_html_e( 'Активных блокировок нет', 'mvweb-site-optimizer' ); ?></h3>
								<p class="mvweb-empty__text"><?php esc_html_e( 'Вход открыт со всех адресов. Записи появятся здесь, когда сработает ограничение попыток.', 'mvweb-site-optimizer' ); ?></p>
							</div>
						</td>
					</tr>
					<?php foreach ( $la_lockout_rows as $la_row ) : ?>
						<tr data-mvweb-so-la-row="<?php echo esc_attr( $la_row['ip'] ); ?>">
							<td class="cell-mono"><?php echo esc_html( $la_row['ip'] ); ?></td>
							<td><?php echo '' !== $la_row['login'] ? esc_html( $la_row['login'] ) : '—'; ?></td>
							<td><?php echo esc_html( human_time_diff( time(), $la_row['until'] ) ); ?></td>
							<td><?php echo $la_row['retries'] > 0 ? esc_html( (string) $la_row['retries'] ) : '—'; ?></td>
							<td class="cell-actions">
								<button type="button"
										class="mvweb-btn mvweb-btn--danger mvweb-btn--sm"
										data-mvweb-so-la-release="<?php echo esc_attr( $la_row['ip'] ); ?>">
									<?php esc_html_e( 'Снять', 'mvweb-site-optimizer' ); ?>
								</button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-login-attempts">
				<?php esc_html_e( 'Включить ограничение попыток', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-login-attempts"
							name="mvweb_so[login_attempts]"
							value="on"
							<?php checked( mvweb_so_check_option( 'login_attempts' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Подключает ограничение на неудачные входы через форму и XML-RPC. По умолчанию IP клиента берётся из REMOTE_ADDR, заголовкам запроса не доверяем (защита от подмены IP). Если сайт стоит за прокси или CDN, включите ниже «Сайт за reverse-proxy».', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-la-retries">
				<?php esc_html_e( 'Разрешённых попыток', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
						id="mvweb-so-la-retries"
						name="mvweb_so[login_attempts_allowed_retries]"
						class="mvweb-input"
						min="1"
						max="999"
						step="1"
						value="<?php echo esc_attr( (string) $la_allowed_retries ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'После скольких неудачных попыток IP блокируется. Рекомендуем 3–10.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-la-lockouts">
				<?php esc_html_e( 'Блокировок до длительного бана', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
						id="mvweb-so-la-lockouts"
						name="mvweb_so[login_attempts_allowed_lockouts]"
						class="mvweb-input"
						min="1"
						max="999"
						step="1"
						value="<?php echo esc_attr( (string) $la_allowed_lockouts ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Сколько коротких блокировок прежде, чем сработает длительный бан. По умолчанию 4.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-la-lockout-duration">
				<?php esc_html_e( 'Короткая блокировка (мин)', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
						id="mvweb-so-la-lockout-duration"
						name="mvweb_so[login_attempts_lockout_duration]"
						class="mvweb-input"
						min="1"
						max="1440"
						step="1"
						value="<?php echo esc_attr( (string) $la_lockout_duration ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Длительность короткой блокировки в минутах. По умолчанию 20.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-la-long-duration">
				<?php esc_html_e( 'Длительная блокировка (ч)', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
						id="mvweb-so-la-long-duration"
						name="mvweb_so[login_attempts_long_duration]"
						class="mvweb-input"
						min="1"
						max="720"
						step="1"
						value="<?php echo esc_attr( (string) $la_long_duration ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Длительность бана при превышении лимита коротких блокировок (в часах). По умолчанию 24.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-la-whitelist">
				<?php esc_html_e( 'Белый список IP', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-so-la-whitelist"
							name="mvweb_so[login_attempts_whitelist]"
							class="mvweb-textarea"
							rows="4"
							placeholder="192.168.1.10&#10;203.0.113.5"><?php echo esc_textarea( $la_whitelist ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Один IP в строке. IP из списка не блокируются, даже если превысили лимит попыток.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-la-blacklist">
				<?php esc_html_e( 'Чёрный список IP', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-so-la-blacklist"
							name="mvweb_so[login_attempts_blacklist]"
							class="mvweb-textarea"
							rows="4"
							placeholder="198.51.100.42"><?php echo esc_textarea( $la_blacklist ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'IP из списка не могут войти вне зависимости от количества попыток.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-la-behind-proxy">
				<?php esc_html_e( 'Сайт за reverse-proxy / CDN', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-la-behind-proxy"
							name="mvweb_so[login_attempts_behind_proxy]"
							value="on"
							<?php checked( $la_behind_proxy ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Включайте только если сайт стоит за Cloudflare, nginx-прокси, балансировщиком или хостинг-фронтом, который скрывает реальный IP клиента за единым REMOTE_ADDR. Без этой опции 5 неудачных попыток одного атакующего залочат сам прокси — и никто не сможет войти.', 'mvweb-site-optimizer' ); ?>
				</p>
				<p class="mvweb-form-row__desc">
					<strong><?php esc_html_e( 'Внимание:', 'mvweb-site-optimizer' ); ?></strong>
					<?php esc_html_e( 'Без проверенного reverse-proxy эта опция позволит атакующему подменить свой IP через заголовок и обойти rate-limit. Убедитесь, что выбранный заголовок действительно ставится вашим прокси и не доходит «как есть» извне.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-la-trusted-header">
				<?php esc_html_e( 'Заголовок с реальным IP', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb-so-la-trusted-header"
						name="mvweb_so[login_attempts_trusted_header]"
						class="mvweb-select">
					<option value="HTTP_X_FORWARDED_FOR" <?php selected( $la_trusted_header, 'HTTP_X_FORWARDED_FOR' ); ?>>X-Forwarded-For</option>
					<option value="HTTP_CF_CONNECTING_IP" <?php selected( $la_trusted_header, 'HTTP_CF_CONNECTING_IP' ); ?>>CF-Connecting-IP (Cloudflare)</option>
					<option value="HTTP_X_REAL_IP" <?php selected( $la_trusted_header, 'HTTP_X_REAL_IP' ); ?>>X-Real-IP (nginx)</option>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Какой заголовок выставляет ваш прокси с реальным IP клиента. X-Forwarded-For (по умолчанию) — стандарт; CF-Connecting-IP — Cloudflare; X-Real-IP — типично для nginx.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Запрет обновлений', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Блокирует автоматические и ручные обновления ядра WordPress, плагинов и тем. Скрывает уведомления о доступных апдейтах. Полезно для production-сайтов, где обновления выполняет администратор по расписанию или через CI/CD.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-alert mvweb-alert--warning">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
			<div class="mvweb-alert__body">
				<p class="mvweb-alert__title"><?php esc_html_e( 'Безопасность', 'mvweb-site-optimizer' ); ?></p>
				<p><?php esc_html_e( 'Запрещая обновления, вы берёте на себя ответственность за установку security-патчей вручную. Регулярно проверяйте release notes WordPress и плагинов.', 'mvweb-site-optimizer' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-core-updates">
				<?php esc_html_e( 'Запретить обновления ядра WordPress', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-core-updates"
							name="mvweb_so[disable_core_updates]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_core_updates' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Отключает auto-update major/minor/dev-релизов ядра. Скрывает уведомления и баннер «Доступна версия X.X». Не запускает wp_version_check.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-plugin-updates">
				<?php esc_html_e( 'Запретить обновления плагинов', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-plugin-updates"
							name="mvweb_so[disable_plugin_updates]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_plugin_updates' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Отключает авто-апдейты плагинов и скрывает счётчик «X обновлений» рядом с пунктом «Плагины» в админке. Кнопки «Обновить» на странице плагинов перестают появляться.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-theme-updates">
				<?php esc_html_e( 'Запретить обновления тем', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-theme-updates"
							name="mvweb_so[disable_theme_updates]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_theme_updates' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Отключает авто-апдейты тем и скрывает уведомления о доступных обновлениях на странице «Внешний вид → Темы».', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Длительность сессии админа', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Управляет тем, как долго WordPress не вылогинивает пользователя из админки. По умолчанию — 14 дней (только при отмеченной галочке «Запомнить меня» на форме входа). Без галочки сессия всегда живёт 2 дня — это нужно для корректной работы смены пароля.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-session-expiration">
				<?php esc_html_e( 'Срок жизни сессии', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<select id="mvweb-so-session-expiration"
						name="mvweb_so[session_expiration]"
						class="mvweb-select">
					<?php foreach ( $session_presets as $value => $label ) : ?>
						<option value="<?php echo esc_attr( (string) $value ); ?>" <?php selected( $session_expiration, $value ); ?>>
							<?php echo esc_html( $label ); ?>
						</option>
					<?php endforeach; ?>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Увеличение срока удобно для «своих» сайтов и одного администратора. Не рекомендуется ставить больше 30 дней на сайтах с несколькими редакторами или общими компьютерами — компрометация cookie действует дольше. Смена пароля старые сессии не разлогинивает (это отдельная операция).', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>
