<?php
/**
 * MVweb Plugins Menu Registration
 *
 * Handles the registration of the main MVweb Plugins menu
 * that all MVweb plugins use as their parent menu.
 *
 * This file should be included in each MVweb plugin's includes/ folder.
 * The version check ensures only the newest version is loaded.
 *
 * @package MVweb\Shared
 * @since   1.0.0
 * @version 2.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Version of this file - increment when making changes.
if ( ! defined( 'MVWEB_MENU_VERSION' ) ) {
	define( 'MVWEB_MENU_VERSION', '2.0.0' );
}

// Skip if a newer version is already loaded.
if ( class_exists( 'MVweb_Menu' ) ) {
	return;
}

/**
 * Class MVweb_Menu
 *
 * Handles the main MVweb Plugins menu registration.
 *
 * @since 1.0.0
 */
class MVweb_Menu {

	/**
	 * Menu slug for new format plugins.
	 *
	 * Using a unique slug to avoid conflicts with old plugins.
	 *
	 * @var string
	 */
	const MENU_SLUG = 'mvweb-hub';

	/**
	 * Hub textdomain — owns the hub's own strings, independent of any plugin.
	 *
	 * @var string
	 */
	const TEXTDOMAIN = 'mvweb-hub';

	/**
	 * Menu capability.
	 *
	 * @var string
	 */
	const CAPABILITY = 'manage_options';

	/**
	 * Menu position.
	 *
	 * Placed at the bottom of the menu after all standard WordPress items.
	 * String type prevents PHP from casting to int (avoids collisions).
	 *
	 * @var string
	 */
	const POSITION = '99.5';

	/**
	 * Instance of this class.
	 *
	 * @var MVweb_Menu
	 */
	private static $instance = null;

	/**
	 * Textdomain of the first plugin that loaded this class.
	 *
	 * @var string
	 */
	private $textdomain = 'mvweb';

	/**
	 * Flag to track if menu was registered by this class.
	 *
	 * @var bool
	 */
	private static $menu_registered = false;

	/**
	 * Cache of registered plugins collected via filter.
	 *
	 * @since 2.0.0
	 * @var array|null
	 */
	private $registered_plugins = null;

	/**
	 * Get singleton instance.
	 *
	 * @since 1.0.0
	 * @return MVweb_Menu
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		// The hub owns its own textdomain so its strings never depend on which
		// plugin happened to load first. Previously the textdomain was guessed
		// from the first known MVweb plugin constant, and the hub strings only
		// showed up translated if that particular plugin shipped them in its
		// .po — so on a site where (say) price-table won the guess but only
		// price-importer carried the full hub catalogue, half the hub was left
		// in English. A dedicated 'mvweb-hub' domain with its own bundled .mo
		// fixes that for any combination of installed plugins.
		$this->textdomain = self::TEXTDOMAIN;
		$this->load_hub_textdomain();

		// Register menu at priority 9 (standard recommended practice).
		add_action( 'admin_menu', array( $this, 'register_menu' ), 9 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_styles' ) );
	}

	/**
	 * Load the hub's own translation catalogue.
	 *
	 * The .mo lives next to this class (languages/mvweb-hub-{locale}.mo) and is
	 * bundled into every plugin, so the hub is translated regardless of which
	 * plugin is active. Loaded once — repeated calls from multiple plugins'
	 * copies are a cheap no-op once the domain is in memory.
	 *
	 * @since 2.1.0
	 * @return void
	 */
	private function load_hub_textdomain() {
		if ( is_textdomain_loaded( self::TEXTDOMAIN ) ) {
			return;
		}

		$locale = function_exists( 'determine_locale' ) ? determine_locale() : get_locale();
		$mofile = trailingslashit( dirname( __FILE__ ) ) . 'languages/' . self::TEXTDOMAIN . '-' . $locale . '.mo';

		if ( file_exists( $mofile ) ) {
			load_textdomain( self::TEXTDOMAIN, $mofile );
		}
	}

	/**
	 * Get plugins registered via 'mvweb_registered_plugins' filter.
	 *
	 * Each plugin registers itself with add_filter in its entry point.
	 * Results are cached after the first call.
	 *
	 * @since 2.0.0
	 * @return array Associative array keyed by plugin slug.
	 */
	private function get_registered_plugins() {
		if ( null === $this->registered_plugins ) {
			$plugins = apply_filters( 'mvweb_registered_plugins', array() );

			// Ensure indexed by slug.
			$indexed = array();
			foreach ( $plugins as $key => $plugin ) {
				if ( is_string( $key ) && ! empty( $plugin['name'] ) ) {
					$indexed[ $key ] = $plugin;
				}
			}

			$this->registered_plugins = $indexed;
		}

		return $this->registered_plugins;
	}

	/**
	 * Register the main MVweb Plugins menu.
	 *
	 * Uses unique slug 'mvweb-hub' to avoid conflicts with old plugins
	 * that may use 'mvweb-plugins' slug.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register_menu() {
		// Only register once.
		if ( self::$menu_registered ) {
			return;
		}

		// Check if menu already registered by another instance.
		if ( ! empty( $GLOBALS['admin_page_hooks'][ self::MENU_SLUG ] ) ) {
			self::$menu_registered = true;
			return;
		}

		// Register top-level menu.
		add_menu_page(
			__( 'MVweb Hub', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			__( 'MVweb Hub', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			self::CAPABILITY,
			self::MENU_SLUG,
			array( $this, 'render_about_page' ),
			$this->get_menu_icon(),
			self::POSITION
		);

		// Add main submenu (replaces default submenu).
		add_submenu_page(
			self::MENU_SLUG,
			__( 'MVweb Plugins', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			__( 'All Plugins', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			self::CAPABILITY,
			self::MENU_SLUG,
			array( $this, 'render_about_page' )
		);

		self::$menu_registered = true;
	}

	/**
	 * Get menu icon.
	 *
	 * @since 1.0.0
	 * @return string Base64 encoded SVG icon or dashicon.
	 */
	private function get_menu_icon() {
		return 'dashicons-admin-generic';
	}

	/**
	 * Get URL to MVweb logo (mv-logo-violet.png).
	 *
	 * Looks for images/mv-logo-violet.png alongside this file. Falls back
	 * to an empty string — caller is expected to render a text fallback.
	 *
	 * @since 1.0.0
	 * @return string Logo URL or '' if not found.
	 */
	private function get_logo_url() {
		$dir = trailingslashit( dirname( __FILE__ ) );
		// Same-folder image (shared/images/) — primary location.
		if ( file_exists( $dir . 'images/mv-logo-violet.png' ) ) {
			return plugins_url( 'images/mv-logo-violet.png', __FILE__ );
		}
		// Fallback: bundled inside plugin /includes/ (one level up).
		if ( file_exists( dirname( $dir ) . '/images/mv-logo-violet.png' ) ) {
			return plugins_url( '../images/mv-logo-violet.png', __FILE__ );
		}
		return '';
	}

	/**
	 * Render the About MVweb page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function render_about_page() {
		$installed_plugins  = $this->get_mvweb_plugins();
		$registered_plugins = $this->get_registered_plugins();
		$td                 = $this->textdomain;

		// Calc stats for hero strip.
		$total_installed = count( $installed_plugins );
		$total_active    = 0;
		foreach ( array_keys( $installed_plugins ) as $pfile ) {
			if ( is_plugin_active( $pfile ) ) {
				$total_active++;
			}
		}
		$installed_slugs = array();
		foreach ( array_keys( $installed_plugins ) as $pfile ) {
			$installed_slugs[] = dirname( $pfile );
		}
		$not_installed     = array_diff_key( $registered_plugins, array_flip( $installed_slugs ) );
		$total_available   = count( $not_installed );
		?>
		<div class="wrap mvweb-about-page mvweb-theme-ide">

			<div class="wp-frame__crumbs">
				<span class="accent"><?php esc_html_e( 'MVweb Hub', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></span>
				<span><?php esc_html_e( 'All Plugins', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></span>
			</div>

			<!-- Hub Hero -->
			<?php $logo_url = $this->get_logo_url(); ?>
			<div class="hub-hero">
				<div class="hub-hero__logo<?php echo '' === $logo_url ? ' hub-hero__logo--text' : ''; ?>">
					<?php if ( '' !== $logo_url ) : ?>
						<img src="<?php echo esc_url( $logo_url ); ?>" alt="MVweb" width="80" height="80">
					<?php else : ?>
						MV
					<?php endif; ?>
				</div>
				<div class="hub-hero__body">
					<h1 class="hub-hero__title"><?php esc_html_e( 'MVweb Plugins', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></h1>
					<p class="hub-hero__desc">
						<?php esc_html_e( 'MVweb is a web development studio specializing in WordPress plugins and themes. We create high-quality, secure, and well-documented solutions for WordPress.', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
					</p>
					<p style="margin-top:14px;">
						<a href="https://mvweb.ru" target="_blank" rel="noopener noreferrer" class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm">
							<?php esc_html_e( 'Visit mvweb.ru', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?> &rarr;
						</a>
					</p>
				</div>
				<div class="hub-hero__stats">
					<div class="hub-stat">
						<span class="hub-stat__value hub-stat__value--brand"><?php echo esc_html( (string) $total_installed ); ?></span>
						<span class="hub-stat__label"><?php esc_html_e( 'installed', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></span>
					</div>
					<div class="hub-stat">
						<span class="hub-stat__value"><?php echo esc_html( (string) $total_active ); ?></span>
						<span class="hub-stat__label"><?php esc_html_e( 'active', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></span>
					</div>
					<div class="hub-stat">
						<span class="hub-stat__value"><?php echo esc_html( (string) $total_available ); ?></span>
						<span class="hub-stat__label"><?php esc_html_e( 'available', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></span>
					</div>
				</div>
			</div>

			<!-- Installed plugins -->
			<div class="hub-section-title">
				<span>▸ <?php esc_html_e( 'installed plugins', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></span>
				<span class="hub-section-title__count"><?php echo esc_html( (string) $total_installed ); ?></span>
			</div>

			<?php if ( ! empty( $installed_plugins ) ) : ?>
				<div class="mvweb-plugins-grid">
					<?php foreach ( $installed_plugins as $plugin_file => $plugin ) : ?>
						<?php
						$is_active    = is_plugin_active( $plugin_file );
						$plugin_slug  = dirname( $plugin_file );
						$plugin_info  = isset( $registered_plugins[ $plugin_slug ] ) ? $registered_plugins[ $plugin_slug ] : array();
						$settings_url = ! empty( $plugin_info['settings_url'] )
							? admin_url( $plugin_info['settings_url'] )
							: null;
						// Build 2-letter acronym from plugin name (e.g. "MVweb Build Calc" → "BC").
						$name_parts = explode( ' ', $plugin['Name'] );
						$acronym    = '';
						foreach ( $name_parts as $part ) {
							if ( strcasecmp( $part, 'MVweb' ) === 0 ) {
								continue;
							}
							$acronym .= mb_substr( $part, 0, 1 );
							if ( mb_strlen( $acronym ) >= 2 ) {
								break;
							}
						}
						if ( '' === $acronym ) {
							$acronym = 'MV';
						}
						$acronym = mb_strtoupper( $acronym );
						?>
						<div class="mvweb-plugin-card <?php echo $is_active ? 'mvweb-plugin-card--active' : 'mvweb-plugin-card--inactive'; ?>">
							<div class="mvweb-plugin-card__header">
								<div class="mvweb-plugin-card__heading">
									<div class="mvweb-plugin-card__icon"><?php echo esc_html( $acronym ); ?></div>
									<div>
										<h3 class="mvweb-plugin-card__title"><?php echo esc_html( $plugin['Name'] ); ?></h3>
										<p class="mvweb-plugin-card__version">v<?php echo esc_html( $plugin['Version'] ); ?></p>
									</div>
								</div>
								<span class="mvweb-plugin-card__status <?php echo $is_active ? 'mvweb-plugin-card__status--active' : 'mvweb-plugin-card__status--inactive'; ?>">
									<?php echo $is_active ? esc_html__( 'active', $td ) : esc_html__( 'inactive', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
								</span>
							</div>
							<p class="mvweb-plugin-card__description">
								<?php echo esc_html( $plugin['Description'] ); ?>
							</p>
							<div class="mvweb-plugin-card__actions">
								<?php if ( $is_active && $settings_url ) : ?>
									<a href="<?php echo esc_url( $settings_url ); ?>" class="mvweb-btn mvweb-btn--primary mvweb-btn--sm">
										<?php esc_html_e( 'Settings', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								<?php elseif ( ! $is_active ) : ?>
									<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'plugins.php?action=activate&plugin=' . urlencode( $plugin_file ) ), 'activate-plugin_' . $plugin_file ) ); ?>" class="mvweb-btn mvweb-btn--primary mvweb-btn--sm">
										<?php esc_html_e( 'Activate', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								<?php endif; ?>
								<?php if ( ! empty( $plugin['PluginURI'] ) ) : ?>
									<a href="<?php echo esc_url( $plugin['PluginURI'] ); ?>" target="_blank" rel="noopener noreferrer" class="mvweb-btn mvweb-btn--sm">
										<?php esc_html_e( 'Docs', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								<?php endif; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php else : ?>
				<div class="mvweb-empty">
					<div class="mvweb-empty__icon">∅</div>
					<h3 class="mvweb-empty__title"><?php esc_html_e( 'No MVweb plugins installed yet', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></h3>
					<p class="mvweb-empty__text"><?php esc_html_e( 'Visit mvweb.ru to explore available plugins.', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></p>
				</div>
			<?php endif; ?>

			<?php if ( ! empty( $not_installed ) ) : ?>
				<div class="hub-section-title">
					<span>▸ <?php esc_html_e( 'available plugins', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></span>
					<span class="hub-section-title__count"><?php echo esc_html( (string) $total_available ); ?></span>
				</div>
				<div class="mvweb-plugins-grid">
					<?php foreach ( $not_installed as $slug => $plugin_info ) : ?>
						<?php
						$name_parts = explode( ' ', $plugin_info['name'] );
						$acronym    = '';
						foreach ( $name_parts as $part ) {
							if ( strcasecmp( $part, 'MVweb' ) === 0 ) {
								continue;
							}
							$acronym .= mb_substr( $part, 0, 1 );
							if ( mb_strlen( $acronym ) >= 2 ) {
								break;
							}
						}
						if ( '' === $acronym ) {
							$acronym = '+';
						}
						$acronym = mb_strtoupper( $acronym );
						?>
						<div class="mvweb-plugin-card mvweb-plugin-card--available">
							<div class="mvweb-plugin-card__header">
								<div class="mvweb-plugin-card__heading">
									<div class="mvweb-plugin-card__icon"><?php echo esc_html( $acronym ); ?></div>
									<div>
										<h3 class="mvweb-plugin-card__title"><?php echo esc_html( $plugin_info['name'] ); ?></h3>
										<p class="mvweb-plugin-card__version"><?php esc_html_e( 'available', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></p>
									</div>
								</div>
								<span class="mvweb-plugin-card__status mvweb-plugin-card__status--available">
									<?php esc_html_e( 'install', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
								</span>
							</div>
							<p class="mvweb-plugin-card__description">
								<?php echo esc_html( $plugin_info['description'] ); ?>
							</p>
							<?php if ( ! empty( $plugin_info['url'] ) ) : ?>
								<div class="mvweb-plugin-card__actions">
									<a href="<?php echo esc_url( $plugin_info['url'] ); ?>" target="_blank" rel="noopener noreferrer" class="mvweb-btn mvweb-btn--sm">
										<?php esc_html_e( 'Learn more →', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Get list of installed MVweb plugins.
	 *
	 * Only returns plugins registered via 'mvweb_registered_plugins' filter.
	 *
	 * @since 1.0.0
	 * @return array List of MVweb plugins.
	 */
	private function get_mvweb_plugins() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$all_plugins   = get_plugins();
		$mvweb_plugins = array();
		$allowed_slugs = array_keys( $this->get_registered_plugins() );

		foreach ( $all_plugins as $plugin_file => $plugin_data ) {
			$plugin_slug = dirname( $plugin_file );

			if ( in_array( $plugin_slug, $allowed_slugs, true ) ) {
				$mvweb_plugins[ $plugin_file ] = $plugin_data;
			}
		}

		/**
		 * Translate plugin headers (Name, Description) for each plugin.
		 *
		 * WordPress get_plugins() caches data WITHOUT translations ($translate = false).
		 * We must explicitly call _get_plugin_data_markup_translate() to get
		 * translated headers, just like get_plugin_data() does with $translate = true.
		 */
		if ( function_exists( '_get_plugin_data_markup_translate' ) ) {
			foreach ( $mvweb_plugins as $plugin_file => $plugin_data ) {
				$mvweb_plugins[ $plugin_file ] = _get_plugin_data_markup_translate(
					WP_PLUGIN_DIR . '/' . $plugin_file,
					$plugin_data,
					false,
					true
				);
			}
		}

		return $mvweb_plugins;
	}

	/**
	 * Enqueue admin styles for MVweb pages.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_styles( $hook ) {
		// Only load on MVweb main page.
		if ( 'toplevel_page_' . self::MENU_SLUG !== $hook ) {
			return;
		}

		wp_add_inline_style( 'common', $this->get_inline_styles() );
	}

	/**
	 * Get inline CSS styles.
	 *
	 * @since 1.0.0
	 * @return string CSS styles.
	 */
	private function get_inline_styles() {
		// MVweb UI Kit · IDE Light theme (GitHub Light).
		// Палитра: GitHub Light + полупрозрачный бренд-фиолет #793ea4.
		// Reference: products/wordpress/_boilerplate/plugin-template/docs/ui-kit-reference.html
		return '
			.mvweb-theme-ide {
				--brand: #793ea4;
				--brand-dark: #5e2d80;
				--brand-04: rgba(121, 62, 164, 0.04);
				--brand-08: rgba(121, 62, 164, 0.08);
				--brand-12: rgba(121, 62, 164, 0.12);
				--brand-16: rgba(121, 62, 164, 0.16);
				--brand-24: rgba(121, 62, 164, 0.24);
				--brand-40: rgba(121, 62, 164, 0.40);
				--brand-60: rgba(121, 62, 164, 0.60);
				--gh-bg: #ffffff;
				--gh-bg-subtle: #f6f8fa;
				--gh-bg-muted: #eaeef2;
				--gh-border: #d1d9e0;
				--gh-border-soft: #f0f3f6;
				--gh-text: #1f2328;
				--gh-text-muted: #59636e;
				--gh-text-faint: #afb8c1;
				--gh-success: #1a7f37;
				--gh-success-bg: #dafbe1;
				--ide-font-mono: "JetBrains Mono", ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
				--ide-font-sans: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
				font-family: var(--ide-font-sans);
				color: var(--gh-text);
				max-width: 1180px;
			}

			.mvweb-theme-ide .wp-frame__crumbs {
				display: flex;
				align-items: center;
				gap: 6px;
				font-family: var(--ide-font-mono);
				font-size: 12px;
				color: var(--gh-text-muted);
				margin: 8px 0 18px;
			}
			.mvweb-theme-ide .wp-frame__crumbs span:not(:last-child)::after {
				content: "/";
				margin-left: 6px;
				color: var(--gh-text-faint);
			}
			.mvweb-theme-ide .wp-frame__crumbs .accent { color: var(--brand); }

			/* ─── Hub Hero ─── */
			.mvweb-theme-ide .hub-hero {
				background: var(--gh-bg);
				border: 1px solid var(--gh-border);
				border-radius: 12px;
				padding: 28px 32px;
				margin-bottom: 28px;
				display: grid;
				grid-template-columns: auto 1fr auto;
				gap: 28px;
				align-items: center;
				position: relative;
				overflow: hidden;
			}
			.mvweb-theme-ide .hub-hero::before {
				content: "";
				position: absolute;
				inset: 0;
				background:
					radial-gradient(circle at 0% 0%, var(--brand-08), transparent 50%),
					radial-gradient(circle at 100% 100%, var(--brand-04), transparent 50%);
				pointer-events: none;
			}
			.mvweb-theme-ide .hub-hero__logo {
				position: relative;
				width: 80px;
				height: 80px;
				display: flex;
				align-items: center;
				justify-content: center;
				flex-shrink: 0;
			}
			.mvweb-theme-ide .hub-hero__logo img {
				width: 100%;
				height: 100%;
				object-fit: contain;
				display: block;
			}
			/* Текстовый fallback, если PNG не найден */
			.mvweb-theme-ide .hub-hero__logo--text {
				background: var(--brand);
				border-radius: 16px;
				color: #fff;
				font-family: var(--ide-font-mono);
				font-size: 22px;
				font-weight: 700;
				box-shadow: 0 8px 24px -8px var(--brand-60);
			}
			.mvweb-theme-ide .hub-hero__body { position: relative; }
			.mvweb-theme-ide .hub-hero__title {
				margin: 0 0 6px;
				font-size: 22px;
				font-weight: 600;
				color: var(--gh-text);
				letter-spacing: -0.01em;
			}
			.mvweb-theme-ide .hub-hero__desc {
				margin: 0;
				color: var(--gh-text-muted);
				font-size: 14px;
				max-width: 620px;
				line-height: 1.55;
			}
			.mvweb-theme-ide .hub-hero__stats {
				position: relative;
				display: flex;
				gap: 18px;
				padding-left: 24px;
				border-left: 1px solid var(--gh-border);
			}
			.mvweb-theme-ide .hub-stat { text-align: center; }
			.mvweb-theme-ide .hub-stat__value {
				font-family: var(--ide-font-mono);
				font-size: 22px;
				font-weight: 600;
				color: var(--gh-text);
				line-height: 1;
				display: block;
			}
			.mvweb-theme-ide .hub-stat__value--brand { color: var(--brand); }
			.mvweb-theme-ide .hub-stat__label {
				display: block;
				margin-top: 4px;
				font-family: var(--ide-font-mono);
				font-size: 10px;
				color: var(--gh-text-muted);
				text-transform: uppercase;
				letter-spacing: 0.8px;
			}

			/* ─── Section title ─── */
			.mvweb-theme-ide .hub-section-title {
				display: flex;
				align-items: baseline;
				justify-content: space-between;
				margin: 32px 0 16px;
				font-family: var(--ide-font-mono);
				font-size: 11px;
				font-weight: 600;
				color: var(--gh-text-muted);
				letter-spacing: 1.2px;
				text-transform: uppercase;
			}
			.mvweb-theme-ide .hub-section-title__count {
				font-size: 11px;
				color: var(--gh-text-faint);
			}

			/* ─── Plugins grid ─── */
			.mvweb-theme-ide .mvweb-plugins-grid {
				display: grid;
				grid-template-columns: repeat(3, 1fr);
				gap: 16px;
				margin-bottom: 28px;
			}
			.mvweb-theme-ide .mvweb-plugin-card {
				background: var(--gh-bg);
				border: 1px solid var(--gh-border);
				border-radius: 10px;
				padding: 18px 20px 16px;
				display: flex;
				flex-direction: column;
				gap: 10px;
				transition: border-color 0.15s, box-shadow 0.15s, transform 0.15s;
				position: relative;
			}
			.mvweb-theme-ide .mvweb-plugin-card:hover {
				border-color: var(--brand-40);
				box-shadow: 0 6px 20px -10px var(--brand-24);
				transform: translateY(-1px);
			}
			.mvweb-theme-ide .mvweb-plugin-card--inactive { background: var(--gh-bg-subtle); }
			.mvweb-theme-ide .mvweb-plugin-card--available {
				background:
					repeating-linear-gradient(
						135deg,
						var(--gh-bg-subtle) 0,
						var(--gh-bg-subtle) 8px,
						var(--gh-bg) 8px,
						var(--gh-bg) 16px
					);
				border-style: dashed;
				border-color: var(--gh-border);
			}
			.mvweb-theme-ide .mvweb-plugin-card__header {
				display: flex;
				align-items: flex-start;
				justify-content: space-between;
				gap: 10px;
			}
			.mvweb-theme-ide .mvweb-plugin-card__heading {
				display: flex;
				gap: 10px;
				align-items: flex-start;
				flex: 1;
			}
			.mvweb-theme-ide .mvweb-plugin-card__icon {
				display: inline-flex;
				align-items: center;
				justify-content: center;
				width: 32px;
				height: 32px;
				flex-shrink: 0;
				background: var(--brand-08);
				border-radius: 8px;
				color: var(--brand);
				font-family: var(--ide-font-mono);
				font-size: 13px;
				font-weight: 600;
			}
			.mvweb-theme-ide .mvweb-plugin-card--inactive .mvweb-plugin-card__icon {
				background: var(--gh-bg-muted);
				color: var(--gh-text-muted);
			}
			.mvweb-theme-ide .mvweb-plugin-card__title {
				margin: 0;
				font-size: 14.5px;
				font-weight: 600;
				color: var(--gh-text);
				line-height: 1.3;
			}
			.mvweb-theme-ide .mvweb-plugin-card__version {
				margin: 2px 0 0;
				font-family: var(--ide-font-mono);
				font-size: 11px;
				color: var(--gh-text-muted);
			}
			.mvweb-theme-ide .mvweb-plugin-card__status {
				display: inline-flex;
				align-items: center;
				gap: 4px;
				padding: 2px 8px;
				font-family: var(--ide-font-mono);
				font-size: 10px;
				font-weight: 500;
				border-radius: 999px;
				text-transform: uppercase;
				letter-spacing: 0.5px;
				flex-shrink: 0;
			}
			.mvweb-theme-ide .mvweb-plugin-card__status::before {
				content: "";
				width: 6px;
				height: 6px;
				border-radius: 50%;
				background: currentColor;
			}
			.mvweb-theme-ide .mvweb-plugin-card__status--active {
				background: var(--gh-success-bg);
				color: var(--gh-success);
			}
			.mvweb-theme-ide .mvweb-plugin-card__status--inactive {
				background: var(--gh-bg-muted);
				color: var(--gh-text-muted);
			}
			.mvweb-theme-ide .mvweb-plugin-card__status--available {
				background: var(--brand-08);
				color: var(--brand);
			}
			.mvweb-theme-ide .mvweb-plugin-card__description {
				margin: 0;
				font-size: 13px;
				color: var(--gh-text-muted);
				line-height: 1.5;
				flex: 1;
			}
			.mvweb-theme-ide .mvweb-plugin-card__actions {
				display: flex;
				gap: 6px;
				margin-top: 8px;
				padding-top: 12px;
				border-top: 1px solid var(--gh-border-soft);
			}

			/* ─── Buttons (IDE-style) ─── */
			.mvweb-theme-ide .mvweb-btn {
				display: inline-flex;
				align-items: center;
				gap: 6px;
				padding: 6px 12px;
				font-family: var(--ide-font-mono);
				font-size: 12px;
				font-weight: 500;
				color: var(--gh-text);
				background: var(--gh-bg);
				border: 1px solid var(--gh-border);
				border-radius: 6px;
				cursor: pointer;
				text-decoration: none;
				transition: background 0.12s, border-color 0.12s, color 0.12s;
				line-height: 1.4;
			}
			.mvweb-theme-ide .mvweb-btn:hover {
				background: var(--gh-bg-subtle);
				border-color: var(--gh-text-faint);
				color: var(--gh-text);
			}
			.mvweb-theme-ide .mvweb-btn--primary {
				background: var(--brand);
				border-color: var(--brand-dark);
				color: #fff;
			}
			.mvweb-theme-ide .mvweb-btn--primary:hover {
				background: var(--brand-dark);
				border-color: #4a2466;
				color: #fff;
			}
			.mvweb-theme-ide .mvweb-btn--secondary {
				background: var(--brand-08);
				border-color: var(--brand-24);
				color: var(--brand);
			}
			.mvweb-theme-ide .mvweb-btn--secondary:hover {
				background: var(--brand-12);
				border-color: var(--brand-40);
				color: var(--brand-dark);
			}
			.mvweb-theme-ide .mvweb-btn--sm {
				padding: 4px 10px;
				font-size: 11.5px;
			}

			/* ─── Empty state ─── */
			.mvweb-theme-ide .mvweb-empty {
				padding: 40px 24px;
				text-align: center;
				background: var(--gh-bg-subtle);
				border: 1px dashed var(--gh-border);
				border-radius: 8px;
				margin-bottom: 24px;
			}
			.mvweb-theme-ide .mvweb-empty__icon {
				display: inline-flex;
				align-items: center;
				justify-content: center;
				width: 48px;
				height: 48px;
				margin: 0 auto 12px;
				background: var(--brand-08);
				color: var(--brand);
				border-radius: 12px;
				font-size: 22px;
			}
			.mvweb-theme-ide .mvweb-empty__title {
				margin: 0 0 4px;
				font-size: 15px;
				font-weight: 600;
				color: var(--gh-text);
			}
			.mvweb-theme-ide .mvweb-empty__text {
				margin: 0;
				font-size: 13px;
				color: var(--gh-text-muted);
			}

			/* ─── Responsive ─── */
			@media (max-width: 1024px) {
				.mvweb-theme-ide .mvweb-plugins-grid {
					grid-template-columns: repeat(2, 1fr);
				}
			}
			@media (max-width: 782px) {
				.mvweb-theme-ide .hub-hero {
					grid-template-columns: 1fr;
					gap: 20px;
					padding: 22px;
					text-align: center;
				}
				.mvweb-theme-ide .hub-hero__stats {
					padding-left: 0;
					border-left: 0;
					border-top: 1px solid var(--gh-border);
					padding-top: 16px;
					justify-content: center;
				}
				.mvweb-theme-ide .mvweb-plugins-grid {
					grid-template-columns: 1fr;
				}
			}
		';
	}

	/**
	 * Get menu slug.
	 *
	 * @since 1.0.0
	 * @return string Menu slug.
	 */
	public static function get_menu_slug() {
		return self::MENU_SLUG;
	}
}

// Initialize the menu immediately.
// For production, use mu-plugin mvweb-menu-init.php for guaranteed early initialization.
MVweb_Menu::get_instance();
