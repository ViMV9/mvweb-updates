<?php
/**
 * Транслитератор русских заголовков и имён файлов.
 *
 * Хук `sanitize_title` срабатывает при создании слага записи / категории /
 * метки. Хук `sanitize_file_name` — при загрузке файла в Медиа.
 * Включается опцией `transliteration` в настройках Modules.
 *
 * @package mvweb_so
 * @since   1.1.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Transliterator {

	private static $map = array(
		'А' => 'A', 'Б' => 'B', 'В' => 'V', 'Г' => 'G', 'Д' => 'D',
		'Е' => 'E', 'Ё' => 'E', 'Ж' => 'Zh', 'З' => 'Z', 'И' => 'I',
		'Й' => 'Y', 'К' => 'K', 'Л' => 'L', 'М' => 'M', 'Н' => 'N',
		'О' => 'O', 'П' => 'P', 'Р' => 'R', 'С' => 'S', 'Т' => 'T',
		'У' => 'U', 'Ф' => 'F', 'Х' => 'Kh', 'Ц' => 'Ts', 'Ч' => 'Ch',
		'Ш' => 'Sh', 'Щ' => 'Shch', 'Ъ' => '', 'Ы' => 'Y', 'Ь' => '',
		'Э' => 'E', 'Ю' => 'Yu', 'Я' => 'Ya',
		'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'д' => 'd',
		'е' => 'e', 'ё' => 'e', 'ж' => 'zh', 'з' => 'z', 'и' => 'i',
		'й' => 'y', 'к' => 'k', 'л' => 'l', 'м' => 'm', 'н' => 'n',
		'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't',
		'у' => 'u', 'ф' => 'f', 'х' => 'kh', 'ц' => 'ts', 'ч' => 'ch',
		'ш' => 'sh', 'щ' => 'shch', 'ъ' => '', 'ы' => 'y', 'ь' => '',
		'э' => 'e', 'ю' => 'yu', 'я' => 'ya',
		// Беларуская дадатковая.
		'І' => 'I', 'і' => 'i', 'Ў' => 'U', 'ў' => 'u',
		// Украінская дадатковая.
		'Є' => 'Ye', 'є' => 'ye', 'Ї' => 'Yi', 'ї' => 'yi', 'Ґ' => 'G', 'ґ' => 'g',
	);

	public static function init(): void {
		if ( ! mvweb_so_check_option( 'transliteration' ) ) {
			return;
		}
		add_filter( 'sanitize_title', array( __CLASS__, 'filter_title' ), 9, 3 );
		add_filter( 'sanitize_file_name', array( __CLASS__, 'filter_file_name' ) );
	}

	public static function filter_title( $title, $raw_title, $context ) {
		if ( 'save' !== $context ) {
			return $title;
		}
		return self::process( (string) $title );
	}

	public static function filter_file_name( $name ) {
		$name = (string) $name;
		$ext  = '';
		$dot  = strrpos( $name, '.' );
		if ( false !== $dot ) {
			$ext  = substr( $name, $dot );
			$name = substr( $name, 0, $dot );
		}
		$name = self::process( $name );
		return $name . $ext;
	}

	public static function process( string $text ): string {
		if ( '' === $text ) {
			return '';
		}
		$text = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );
		$text = strtr( $text, self::$map );
		$text = strtolower( $text );

		$text = preg_replace( '~[^a-z0-9_.-]+~', '-', $text );
		$text = preg_replace( '~([.\-_])\1+~', '$1', (string) $text );
		$text = trim( (string) $text, '-._' );

		return (string) $text;
	}
}
