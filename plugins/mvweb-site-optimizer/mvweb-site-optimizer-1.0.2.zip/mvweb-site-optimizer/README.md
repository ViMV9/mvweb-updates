# MVweb Site Optimizer

Модульный оптимизатор WordPress: чистка `<head>`, безопасность, SEO-фиксы, performance.

**Статус:** Production-ready v1.0.0 — 10 функциональных вкладок (General, Code, SEO, Duplicate, Security, Modules, Additionally, Redirect, IndexNow, Maintenance) + Help.

## Requirements

- WordPress 6.4+
- PHP 8.0+

## Installation

1. Upload the `mvweb-site-optimizer` folder to `/wp-content/plugins/`.
2. Activate the plugin through the **Plugins** menu in WordPress.
3. Configure under **MVweb Hub → Site Optimizer**.

## Архитектура

| Каталог | Что внутри |
|---|---|
| `mvweb-site-optimizer.php` | Bootstrap: header, константы, shared loader, регистрация в Hub, enqueue, активация |
| `includes/class-admin.php` | Оркестратор админки: реестр вкладок, рендер shell |
| `includes/class-settings.php` | Единая Post/Redirect/Get-точка сохранения. Каждая вкладка регистрирует свою sanitize через фильтр `mvweb_so_sanitize_{tab}` |
| `includes/helpers.php` | Геттеры/сеттеры опций (`mvweb_so_get_option`, `mvweb_so_check_option`, ...) |
| `includes/class-mvweb-menu.php` | Shared MVweb Hub (не редактировать) |
| `includes/class-mvweb-updater.php` | Shared PUC wrapper (не редактировать) |
| `admin/views/settings-page.php` | Shell — sidebar + main + tabs |
| `admin/views/tab-*.php` | Partial-ы вкладок (UI Kit разметка) |
| `admin/css/admin.css` | MVweb Admin UI Kit v2 (не редактировать) |
| `admin/css/plugin.css` | Плагин-специфичные стили (`.mvweb-so-*`) |
| `docs/research/` | Внутренние материалы исследования аналогов (не входит в дистрибутив) |

## План разработки

Полная карта фаз — в файле плана `/.claude/plans/temporal-spinning-quasar.md`. Кратко:

| Фаза | Вкладка | Что внутри |
|---|---|---|
| 0 ✅ | — | Скелет, готово |
| 1 | General | Статус-карточка, Export/Import настроек |
| 2 | Code | Cleanup `<head>`: emoji, jQuery migrate, минификация HTML |
| 3 | SEO | robots.txt, sitemap, Yoast SEO, alt-attr |
| 4 | Duplicate | pagination, archive redirects, attachment pages |
| 5 | Security | REST API, hide-login, login-attempts, HTTPS |
| 6 | Modules | comments, Gutenberg, аватары, фиды |
| 7 | Additionally | headers, ревизии, code-snippets, версии файлов |
| 8 | Redirect | менеджер 301-редиректов (regex) |
| 9 | IndexNow | Yandex/Bing submit |
| 10 | Maintenance | режим обслуживания HTTP 503 |
| Final | Help | финальный Quick Start + FAQ |

## License

GPL v2 or later. See [LICENSE](https://www.gnu.org/licenses/gpl-2.0.html).

## Author

[MVweb](https://mvweb.ru)
