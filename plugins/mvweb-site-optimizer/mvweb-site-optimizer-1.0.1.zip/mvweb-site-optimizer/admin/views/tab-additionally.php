<?php
/**
 * Additionally tab — комплекс мелких настроек чистки <head>/<body> и поведения админки.
 *
 * Phase 7. Кастомные сниппеты, логин/cookie-баннер, ревизии, заголовки кеширования,
 * passive listeners, виджеты, чистка <head>, admin bar.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<form method="post" action="">
	<?php wp_nonce_field( 'mvweb_so_settings', 'mvweb_so_nonce' ); ?>
	<input type="hidden" name="mvweb_so_tab" value="additionally">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Кастомные сниппеты', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Произвольный HTML / JS перед закрытием </head> и </body>. Сохраняется как есть, поэтому редактировать может только администратор.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-insert-code-in-head">
				<?php esc_html_e( 'Код в <head>', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-so-insert-code-in-head"
						name="mvweb_so[insert_code_in_head]"
						class="mvweb-textarea"
						rows="6"
						spellcheck="false"><?php echo esc_textarea( (string) mvweb_so_get_option( 'insert_code_in_head', '' ) ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Например, метатеги верификации Яндекс.Вебмастер, счётчики аналитики, link rel preload.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-insert-code-in-body">
				<?php esc_html_e( 'Код перед </body>', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-so-insert-code-in-body"
						name="mvweb_so[insert_code_in_body]"
						class="mvweb-textarea"
						rows="6"
						spellcheck="false"><?php echo esc_textarea( (string) mvweb_so_get_option( 'insert_code_in_body', '' ) ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Например, отложенные скрипты, чат-виджеты, пиксели ретаргетинга.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Логин и cookie-баннер', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Нейтральное сообщение об ошибке входа и баннер согласия с использованием cookie (152-ФЗ, GDPR).', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-change-login-errors">
				<?php esc_html_e( 'Скрыть подробности ошибок входа', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-change-login-errors"
							name="mvweb_so[change_login_errors]"
							value="on"
							<?php checked( mvweb_so_check_option( 'change_login_errors' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Стандартные сообщения «Неверный логин» / «Неверный пароль» подменяются единым нейтральным сообщением. Закрывает канал user enumeration через форму входа.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-change-login-errors-text">
				<?php esc_html_e( 'Текст сообщения', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
						id="mvweb-so-change-login-errors-text"
						name="mvweb_so[change_login_errors_text]"
						class="mvweb-input"
						value="<?php echo esc_attr( (string) mvweb_so_get_option( 'change_login_errors_text', '' ) ); ?>"
						placeholder="<?php esc_attr_e( 'Неверные данные для входа.', 'mvweb-site-optimizer' ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Если оставить пустым — используется значение по умолчанию.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-message-cookie">
				<?php esc_html_e( 'Cookie-баннер', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-message-cookie"
							name="mvweb_so[message_cookie]"
							value="on"
							<?php checked( mvweb_so_check_option( 'message_cookie' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Показывает в нижней части сайта плашку согласия с использованием cookie. Согласие сохраняется в localStorage и cookie на год.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-message-cookie-text">
				<?php esc_html_e( 'Текст баннера', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
						id="mvweb-so-message-cookie-text"
						name="mvweb_so[message_cookie_text]"
						class="mvweb-input"
						value="<?php echo esc_attr( (string) mvweb_so_get_option( 'message_cookie_text', '' ) ); ?>"
						placeholder="<?php esc_attr_e( 'Мы используем cookie для корректной работы сайта…', 'mvweb-site-optimizer' ); ?>">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-message-cookie-button">
				<?php esc_html_e( 'Текст кнопки', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
						id="mvweb-so-message-cookie-button"
						name="mvweb_so[message_cookie_button]"
						class="mvweb-input"
						value="<?php echo esc_attr( (string) mvweb_so_get_option( 'message_cookie_button', '' ) ); ?>"
						placeholder="<?php esc_attr_e( 'Принять', 'mvweb-site-optimizer' ); ?>">
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Ревизии записей', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Отключение или ограничение количества ревизий — снижает размер таблицы wp_posts и ускоряет резервные копии.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-revisions-disable">
				<?php esc_html_e( 'Отключить ревизии', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-revisions-disable"
							name="mvweb_so[revisions_disable]"
							value="on"
							<?php checked( mvweb_so_check_option( 'revisions_disable' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'wp_revisions_to_keep → 0. WordPress перестаёт сохранять ревизии при обновлении записей.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-revision-limit">
				<?php esc_html_e( 'Лимит ревизий', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
						id="mvweb-so-revision-limit"
						name="mvweb_so[revision_limit]"
						class="mvweb-input"
						min="0"
						max="999"
						step="1"
						value="<?php echo esc_attr( (string) (int) mvweb_so_get_option( 'revision_limit', 0 ) ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Сколько ревизий хранить на запись. 0 — без ограничения (либо используется тоггл выше). Применяется, только если ревизии не отключены полностью.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Заголовки кеширования', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Last-Modified и 304 Not Modified для одиночных записей. Применяется только к неавторизованным пользователям.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-set-last-modified-headers">
				<?php esc_html_e( 'Отправлять Last-Modified', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-set-last-modified-headers"
							name="mvweb_so[set_last_modified_headers]"
							value="on"
							<?php checked( mvweb_so_check_option( 'set_last_modified_headers' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'На одиночных записях добавляется заголовок Last-Modified со временем последнего обновления post_modified_gmt. Помогает обновлению поисковыми ботами.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-if-modified-since-headers">
				<?php esc_html_e( 'Обрабатывать If-Modified-Since', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-if-modified-since-headers"
							name="mvweb_so[if_modified_since_headers]"
							value="on"
							<?php checked( mvweb_so_check_option( 'if_modified_since_headers' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Если клиент прислал заголовок If-Modified-Since и запись с тех пор не менялась — отдаём 304 Not Modified без тела ответа. Экономит трафик и снижает нагрузку.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Performance', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Мелочи, влияющие на Lighthouse и Core Web Vitals.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-passive-listeners">
				<?php esc_html_e( 'Passive event listeners', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-passive-listeners"
							name="mvweb_so[passive_listeners]"
							value="on"
							<?php checked( mvweb_so_check_option( 'passive_listeners' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Добавляет patch для addEventListener — touch/wheel-события по умолчанию становятся passive. Убирает предупреждение Lighthouse «Does not use passive listeners».', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-versions-styles">
				<?php esc_html_e( 'Убрать ?ver= у CSS', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-versions-styles"
							name="mvweb_so[remove_versions_styles]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_versions_styles' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Удаляет ?ver=… из ссылок на CSS — некоторые CDN не кешируют URL с query-string.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-versions-scripts">
				<?php esc_html_e( 'Убрать ?ver= у JS', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-versions-scripts"
							name="mvweb_so[remove_versions_scripts]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_versions_scripts' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Аналогично, для JS-файлов. После обновления плагина/темы рекомендуется сбросить кеш CDN.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Чистка <head>', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Удаление редко используемых ссылок и заголовков из head.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-meta-generator">
				<?php esc_html_e( 'meta name="generator"', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-meta-generator"
							name="mvweb_so[remove_meta_generator]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_meta_generator' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Скрывает версию WordPress в исходном коде страницы. Дополнительный слой security through obscurity.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-dns-prefetch">
				<?php esc_html_e( 'link rel="dns-prefetch"', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-dns-prefetch"
							name="mvweb_so[remove_dns_prefetch]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_dns_prefetch' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Удаляет dns-prefetch для s.w.org и других сервисов WordPress, если они не используются.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-rsd-link">
				<?php esc_html_e( 'link rel="EditURI" (RSD)', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-rsd-link"
							name="mvweb_so[remove_rsd_link]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_rsd_link' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Удаляет RSD-link — нужен только для устаревших XML-RPC клиентов вроде Windows Live Writer.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-wlw-link">
				<?php esc_html_e( 'link rel="wlwmanifest"', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-wlw-link"
							name="mvweb_so[remove_wlw_link]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_wlw_link' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Манифест Windows Live Writer. На сегодня не используется почти никем.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-adjacent-posts-link">
				<?php esc_html_e( 'link rel="prev/next"', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-adjacent-posts-link"
							name="mvweb_so[remove_adjacent_posts_link]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_adjacent_posts_link' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Удаляет ссылки на соседние записи (adjacent_posts_rel_link). Google больше не использует эти теги как сигнал.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-shortlink-link">
				<?php esc_html_e( 'link rel="shortlink"', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-shortlink-link"
							name="mvweb_so[remove_shortlink_link]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_shortlink_link' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Снимает короткие ссылки /?p=N — у нас уже есть нормальные permalink.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-x-pingback">
				<?php esc_html_e( 'Заголовок X-Pingback', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-x-pingback"
							name="mvweb_so[remove_x_pingback]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_x_pingback' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Убирает HTTP-заголовок X-Pingback. Если pingback всё равно отключены в настройках обсуждения — он становится бесполезным.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Виджеты и форма комментариев', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Отключение редко используемых стандартных виджетов и URL-поля в комментариях.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-unneeded-widget-page">
				<?php esc_html_e( 'Виджет «Страницы»', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-unneeded-widget-page"
							name="mvweb_so[remove_unneeded_widget_page]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_unneeded_widget_page' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-unneeded-widget-calendar">
				<?php esc_html_e( 'Виджет «Календарь»', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-unneeded-widget-calendar"
							name="mvweb_so[remove_unneeded_widget_calendar]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_unneeded_widget_calendar' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-unneeded-widget-tag-cloud">
				<?php esc_html_e( 'Виджет «Облако меток»', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-unneeded-widget-tag-cloud"
							name="mvweb_so[remove_unneeded_widget_tag_cloud]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_unneeded_widget_tag_cloud' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-unneeded-widget-archives">
				<?php esc_html_e( 'Виджет «Архивы»', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-unneeded-widget-archives"
							name="mvweb_so[remove_unneeded_widget_archives]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_unneeded_widget_archives' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-unneeded-widget-meta">
				<?php esc_html_e( 'Виджет «Мета»', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-unneeded-widget-meta"
							name="mvweb_so[remove_unneeded_widget_meta]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_unneeded_widget_meta' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-unneeded-widget-rss">
				<?php esc_html_e( 'Виджет «RSS»', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-unneeded-widget-rss"
							name="mvweb_so[remove_unneeded_widget_rss]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_unneeded_widget_rss' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-url-from-comment-form">
				<?php esc_html_e( 'Убрать поле URL из формы комментария', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-url-from-comment-form"
							name="mvweb_so[remove_url_from_comment_form]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_url_from_comment_form' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Убирает популярный канал спама в комментариях — поле «Сайт».', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Admin bar и почтовые уведомления', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Чистка верхней панели и отключение email-уведомлений об обновлениях.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-unnecessary-link-admin-bar">
				<?php esc_html_e( 'Убрать лишние пункты из admin bar', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-unnecessary-link-admin-bar"
							name="mvweb_so[remove_unnecessary_link_admin_bar]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_unnecessary_link_admin_bar' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Скрывает WP-логотип, «О WordPress», ссылки на форумы, документацию, обратную связь.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-email-notification">
				<?php esc_html_e( 'Отключить email-уведомления об обновлениях', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-email-notification"
							name="mvweb_so[disable_email_notification]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_email_notification' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Снимает фильтры auto_core_update_send_email / auto_plugin_update_send_email / auto_theme_update_send_email и debug-письма про автообновления.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" name="mvweb_so_save" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Сохранить изменения', 'mvweb-site-optimizer' ); ?>
		</button>
	</div>
</form>
