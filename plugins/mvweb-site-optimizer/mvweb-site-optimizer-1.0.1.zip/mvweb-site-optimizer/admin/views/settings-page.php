<?php
/**
 * Admin settings page shell.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$current_tab = MVweb_SO_Admin::current_tab();
$tabs        = MVweb_SO_Admin::tabs();

$icons = array(
	'general'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
	'code'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>',
	'seo'       => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/><polyline points="8 11 11 14 14 8"/></svg>',
	'duplicate' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>',
	'security'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/></svg>',
	'modules'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>',
	'additionally' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/></svg>',
	'redirect'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 10 20 15 15 20"/><path d="M4 4v7a4 4 0 0 0 4 4h12"/></svg>',
	'indexnow'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>',
	'maintenance'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>',
	'help'         => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">SO</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Site Optimizer', 'mvweb-site-optimizer' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_SO_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $tabs as $tab_id => $tab_label ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $tab_id ); ?>"
						class="mvweb-nav__link <?php echo $current_tab === $tab_id ? 'mvweb-nav__link--active' : ''; ?>"
						data-tab="<?php echo esc_attr( $tab_id ); ?>">
						<?php echo isset( $icons[ $tab_id ] ) ? $icons[ $tab_id ] : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $tab_label ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php ( new MVweb_SO_Settings() )->maybe_render_saved_notice(); ?>

		<div id="general" class="mvweb-tab-content <?php echo 'general' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SO_PATH . 'admin/views/tab-general.php'; ?>
		</div>

		<div id="code" class="mvweb-tab-content <?php echo 'code' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SO_PATH . 'admin/views/tab-code.php'; ?>
		</div>

		<div id="seo" class="mvweb-tab-content <?php echo 'seo' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SO_PATH . 'admin/views/tab-seo.php'; ?>
		</div>

		<div id="duplicate" class="mvweb-tab-content <?php echo 'duplicate' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SO_PATH . 'admin/views/tab-duplicate.php'; ?>
		</div>

		<div id="security" class="mvweb-tab-content <?php echo 'security' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SO_PATH . 'admin/views/tab-security.php'; ?>
		</div>

		<div id="modules" class="mvweb-tab-content <?php echo 'modules' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SO_PATH . 'admin/views/tab-modules.php'; ?>
		</div>

		<div id="additionally" class="mvweb-tab-content <?php echo 'additionally' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SO_PATH . 'admin/views/tab-additionally.php'; ?>
		</div>

		<div id="redirect" class="mvweb-tab-content <?php echo 'redirect' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SO_PATH . 'admin/views/tab-redirect.php'; ?>
		</div>

		<div id="indexnow" class="mvweb-tab-content <?php echo 'indexnow' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SO_PATH . 'admin/views/tab-indexnow.php'; ?>
		</div>

		<div id="maintenance" class="mvweb-tab-content <?php echo 'maintenance' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SO_PATH . 'admin/views/tab-maintenance.php'; ?>
		</div>

		<div id="help" class="mvweb-tab-content <?php echo 'help' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SO_PATH . 'admin/views/tab-help.php'; ?>
		</div>

	</main>
</div>
