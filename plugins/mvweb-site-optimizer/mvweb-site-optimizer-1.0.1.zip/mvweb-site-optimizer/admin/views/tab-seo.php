<?php
/**
 * SEO tab — индексация, robots.txt, sitemap, интеграция с Yoast SEO.
 *
 * Phase 3. Имена опций выбраны для совместимости с аналогичными плагинами.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'is_plugin_active' ) ) {
	require_once ABSPATH . 'wp-admin/includes/plugin.php';
}

$yoast_active = defined( 'WPSEO_VERSION' )
	|| is_plugin_active( 'wordpress-seo/wp-seo.php' )
	|| is_plugin_active( 'wordpress-seo-premium/wp-seo-premium.php' );

$robots_txt_value = (string) mvweb_so_get_option( 'robots_txt_text', '' );
?>

<form method="post" action="">
	<?php wp_nonce_field( 'mvweb_so_settings', 'mvweb_so_nonce' ); ?>
	<input type="hidden" name="mvweb_so_tab" value="seo">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Базовые SEO-настройки', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Индексация пагинации, авто-alt для картинок, кастомный robots.txt.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-noindex-pagination">
				<?php esc_html_e( 'Noindex на пагинации', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-noindex-pagination"
							name="mvweb_so[noindex_pagination]"
							value="on"
							<?php checked( mvweb_so_check_option( 'noindex_pagination' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Добавляет meta robots="noindex,follow" на страницах пагинации (2 и далее). При активном Yoast или All in One SEO встраивается через их фильтры, иначе печатается прямо в head.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-content-image-auto-alt">
				<?php esc_html_e( 'Авто-alt для картинок', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-content-image-auto-alt"
							name="mvweb_so[content_image_auto_alt]"
							value="on"
							<?php checked( mvweb_so_check_option( 'content_image_auto_alt' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Подставляет заголовок поста в пустые alt у тегов <img> внутри контента (на single страницах).', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'robots.txt', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Кастомный robots.txt вместо встроенного WordPress. Используется только если на сайте нет физического robots.txt в корне.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-right-robots-txt">
				<?php esc_html_e( 'Включить свой robots.txt', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-right-robots-txt"
							name="mvweb_so[right_robots_txt]"
							value="on"
							<?php checked( mvweb_so_check_option( 'right_robots_txt' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Если поле ниже пустое — отдаётся дефолтный шаблон MVweb с блокировкой wp-admin, wp-includes, plugins, кешa, xmlrpc и автоопределением sitemap.xml.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-robots-txt-text">
				<?php esc_html_e( 'Содержимое robots.txt', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-so-robots-txt-text"
							class="mvweb-textarea mvweb-so-robots"
							name="mvweb_so[robots_txt_text]"
							rows="10"
							placeholder="<?php esc_attr_e( 'Оставьте пустым, чтобы использовать дефолтный шаблон.', 'mvweb-site-optimizer' ); ?>"><?php echo esc_textarea( $robots_txt_value ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Полное содержимое robots.txt одним блоком. Поддерживаются стандартные директивы User-agent, Allow, Disallow, Sitemap, Host, Crawl-delay. Действует только при включённом переключателе выше.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'XML Sitemap', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Управление встроенным WordPress sitemap (wp-sitemap.xml).', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-wp-sitemaps-xml-disable">
				<?php esc_html_e( 'Отключить встроенный sitemap', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-wp-sitemaps-xml-disable"
							name="mvweb_so[wp_sitemaps_xml_disable]"
							value="on"
							<?php checked( mvweb_so_check_option( 'wp_sitemaps_xml_disable' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Полностью отключает wp-sitemap.xml. Включайте, если используете sitemap от другого SEO-плагина.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-wp-sitemaps-xml-disable-users">
				<?php esc_html_e( 'Убрать авторов из sitemap', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-wp-sitemaps-xml-disable-users"
							name="mvweb_so[wp_sitemaps_xml_disable_users]"
							value="on"
							<?php checked( mvweb_so_check_option( 'wp_sitemaps_xml_disable_users' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Исключает раздел users-провайдера из встроенного sitemap. Игнорируется, если sitemap полностью отключён выше.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Интеграция с Yoast SEO', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php if ( $yoast_active ) : ?>
				<?php esc_html_e( 'Yoast SEO обнаружен — настройки применяются.', 'mvweb-site-optimizer' ); ?>
			<?php else : ?>
				<?php esc_html_e( 'Настройки для Yoast SEO. Плагин не активирован.', 'mvweb-site-optimizer' ); ?>
			<?php endif; ?>
		</p>

		<?php if ( $yoast_active ) : ?>

			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label" for="mvweb-so-remove-last-item-breadcrumb-yoast">
					<?php esc_html_e( 'Удалить последний пункт в breadcrumbs', 'mvweb-site-optimizer' ); ?>
				</label>
				<div class="mvweb-form-row__field">
					<label class="mvweb-toggle">
						<input type="checkbox"
								id="mvweb-so-remove-last-item-breadcrumb-yoast"
								name="mvweb_so[remove_last_item_breadcrumb_yoast]"
								value="on"
								<?php checked( mvweb_so_check_option( 'remove_last_item_breadcrumb_yoast' ) ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<p class="mvweb-form-row__desc">
						<?php esc_html_e( 'Скрывает breadcrumb_last (заголовок текущей страницы) в хлебных крошках Yoast.', 'mvweb-site-optimizer' ); ?>
					</p>
				</div>
			</div>

			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label" for="mvweb-so-replace-last-item-breadcrumb-yoast-on-title">
					<?php esc_html_e( 'Заменить последний пункт breadcrumbs на SEO-title', 'mvweb-site-optimizer' ); ?>
				</label>
				<div class="mvweb-form-row__field">
					<label class="mvweb-toggle">
						<input type="checkbox"
								id="mvweb-so-replace-last-item-breadcrumb-yoast-on-title"
								name="mvweb_so[replace_last_item_breadcrumb_yoast_on_title]"
								value="on"
								<?php checked( mvweb_so_check_option( 'replace_last_item_breadcrumb_yoast_on_title' ) ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<p class="mvweb-form-row__desc">
						<?php esc_html_e( 'Подменяет название текущей страницы в breadcrumbs на её SEO Title из Yoast.', 'mvweb-site-optimizer' ); ?>
					</p>
				</div>
			</div>

			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label" for="mvweb-so-yoast-remove-image-from-xml-sitemap">
					<?php esc_html_e( 'Убрать картинки из Yoast sitemap', 'mvweb-site-optimizer' ); ?>
				</label>
				<div class="mvweb-form-row__field">
					<label class="mvweb-toggle">
						<input type="checkbox"
								id="mvweb-so-yoast-remove-image-from-xml-sitemap"
								name="mvweb_so[yoast_remove_image_from_xml_sitemap]"
								value="on"
								<?php checked( mvweb_so_check_option( 'yoast_remove_image_from_xml_sitemap' ) ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<p class="mvweb-form-row__desc">
						<?php esc_html_e( 'Исключает теги image:image из XML-sitemap Yoast.', 'mvweb-site-optimizer' ); ?>
					</p>
				</div>
			</div>

			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label" for="mvweb-so-yoast-remove-head-comment">
					<?php esc_html_e( 'Убрать комментарии Yoast в head', 'mvweb-site-optimizer' ); ?>
				</label>
				<div class="mvweb-form-row__field">
					<label class="mvweb-toggle">
						<input type="checkbox"
								id="mvweb-so-yoast-remove-head-comment"
								name="mvweb_so[yoast_remove_head_comment]"
								value="on"
								<?php checked( mvweb_so_check_option( 'yoast_remove_head_comment' ) ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<p class="mvweb-form-row__desc">
						<?php esc_html_e( 'Прячет debug-маркеры This site is optimized with the Yoast SEO plugin до и после блока Yoast в head.', 'mvweb-site-optimizer' ); ?>
					</p>
				</div>
			</div>

			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label" for="mvweb-so-yoast-canonical-pagination">
					<?php esc_html_e( 'Canonical для пагинации (Yoast)', 'mvweb-site-optimizer' ); ?>
				</label>
				<div class="mvweb-form-row__field">
					<label class="mvweb-toggle">
						<input type="checkbox"
								id="mvweb-so-yoast-canonical-pagination"
								name="mvweb_so[yoast_canonical_pagination]"
								value="on"
								<?php checked( mvweb_so_check_option( 'yoast_canonical_pagination' ) ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<p class="mvweb-form-row__desc">
						<?php esc_html_e( 'На страницах пагинации (категории, теги, taxonomy, авторы, главная, WC shop) подставляет canonical на первую страницу.', 'mvweb-site-optimizer' ); ?>
					</p>
				</div>
			</div>

			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label" for="mvweb-so-yoast-application-ld-json">
					<?php esc_html_e( 'Убрать JSON-LD Yoast', 'mvweb-site-optimizer' ); ?>
				</label>
				<div class="mvweb-form-row__field">
					<label class="mvweb-toggle">
						<input type="checkbox"
								id="mvweb-so-yoast-application-ld-json"
								name="mvweb_so[yoast_application_ld_json]"
								value="on"
								<?php checked( mvweb_so_check_option( 'yoast_application_ld_json' ) ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<p class="mvweb-form-row__desc">
						<?php esc_html_e( 'Полностью очищает блок Schema.org JSON-LD, который добавляет Yoast. Используйте, если разметку отдаёт другой плагин или тема.', 'mvweb-site-optimizer' ); ?>
					</p>
				</div>
			</div>

		<?php endif; ?>
	</div>

	<div class="mvweb-submit">
		<button type="submit" name="mvweb_so_save" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Сохранить изменения', 'mvweb-site-optimizer' ); ?>
		</button>
	</div>
</form>
