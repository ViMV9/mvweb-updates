<?php
/**
 * Code tab — cleanup of WordPress head and front-end ballast.
 *
 * Phase 2. Четыре переключателя: emoji, jQuery Migrate, recent comments style,
 * HTML minify.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<form method="post" action="">
	<?php wp_nonce_field( 'mvweb_so_settings', 'mvweb_so_nonce' ); ?>
	<input type="hidden" name="mvweb_so_tab" value="code">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Чистка фронтенда', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Уберите ненужные ассеты WordPress, чтобы ускорить загрузку и упростить разметку.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-emoji">
				<?php esc_html_e( 'Отключить эмодзи', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-emoji"
							name="mvweb_so[disable_emoji]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_emoji' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Убирает скрипт detect emoji, inline-стили, DNS prefetch на s.w.org, фильтры в RSS и письмах, плагин wpemoji из TinyMCE.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-jquery-migrate">
				<?php esc_html_e( 'Удалить jQuery Migrate', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-jquery-migrate"
							name="mvweb_so[remove_jquery_migrate]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_jquery_migrate' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Оставляет только jquery-core, без подключения jquery-migrate. Включайте, если тема и плагины не используют устаревшие API jQuery.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-recent-comments-style">
				<?php esc_html_e( 'Убрать стиль виджета «Свежие комментарии»', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-recent-comments-style"
							name="mvweb_so[remove_recent_comments_style]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_recent_comments_style' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Удаляет инлайн-стиль .recentcomments, который WordPress вставляет в head даже если виджет не используется.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-html-minify">
				<?php esc_html_e( 'Минифицировать HTML', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-html-minify"
							name="mvweb_so[html_minify]"
							value="on"
							<?php checked( mvweb_so_check_option( 'html_minify' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Удаляет HTML-комментарии и лишние пробелы между тегами. Содержимое pre, textarea, script и style не затрагивается. Условные комментарии IE сохраняются.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" name="mvweb_so_save" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Сохранить изменения', 'mvweb-site-optimizer' ); ?>
		</button>
	</div>
</form>
