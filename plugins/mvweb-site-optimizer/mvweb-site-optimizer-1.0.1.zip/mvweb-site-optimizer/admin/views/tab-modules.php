<?php
/**
 * Modules tab — отключение тяжёлых компонентов ядра WordPress.
 *
 * Phase 6. Комментарии (+ 5 подопций), Gutenberg, классические виджеты,
 * Gravatar, RSS-фиды, admin bar.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<form method="post" action="">
	<?php wp_nonce_field( 'mvweb_so_settings', 'mvweb_so_nonce' ); ?>
	<input type="hidden" name="mvweb_so_tab" value="modules">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Комментарии', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Полное или частичное отключение комментариев и связанной инфраструктуры (UI, XML-RPC, REST API, поле email, IP/User-Agent).', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-comments">
				<?php esc_html_e( 'Отключить комментарии', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-comments"
							name="mvweb_so[disable_comments]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_comments' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Снимает поддержку comments / trackbacks у всех зарегистрированных post-типов. Подопции ниже добавляют слои защиты (UI, XML-RPC, REST API, email-поле в форме, сохранение IP).', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-comments-interface">
				<?php esc_html_e( 'Скрыть интерфейс комментариев', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-comments-interface"
							name="mvweb_so[disable_comments_interface]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_comments_interface' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Убирает пункт «Комментарии» из меню админки, виджет recent comments, виджет в admin bar, REST-эндпоинты /wp/v2/comments, ленту комментариев, dashboard-блок.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-comments-xml-rpc">
				<?php esc_html_e( 'Запретить wp.newComment в XML-RPC', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-comments-xml-rpc"
							name="mvweb_so[disable_comments_xml_rpc]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_comments_xml_rpc' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Удаляет метод wp.newComment из списка XML-RPC. Закрывает популярный канал спама.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-comments-rest-api">
				<?php esc_html_e( 'Запретить создание комментариев через REST API', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-comments-rest-api"
							name="mvweb_so[disable_comments_rest_api]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_comments_rest_api' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'POST /wp-json/wp/v2/comments возвращает 403 «Комментарии отключены».', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-comments-email-field">
				<?php esc_html_e( 'Убрать поле Email из формы', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-comments-email-field"
							name="mvweb_so[disable_comments_email_field]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_comments_email_field' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Удаляет поле Email из стандартной формы добавления комментария. Полезно, если в Настройки → Обсуждение разрешены анонимные комментарии.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-comments-save-ip">
				<?php esc_html_e( 'Не сохранять IP и User-Agent', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-comments-save-ip"
							name="mvweb_so[disable_comments_save_ip]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_comments_save_ip' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'И IP-адрес, и User-Agent комментаторов сохраняются пустыми (опция исторически называется save_ip, но затрагивает оба поля). Соответствие требованиям GDPR/152-ФЗ при необходимости.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Gutenberg', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Откат на классический редактор и классические виджеты. Полезно для сайтов с большой кодовой базой Classic Editor / ACF / page builder.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-gutenberg">
				<?php esc_html_e( 'Отключить блочный редактор', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-gutenberg"
							name="mvweb_so[disable_gutenberg]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_gutenberg' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'use_block_editor_for_post_type и gutenberg_can_edit_post_type → false. Удаляет wp-block-library и global-styles на фронте. Открывает Classic Editor для всех типов.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-gutenberg-widgets">
				<?php esc_html_e( 'Классические виджеты', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-gutenberg-widgets"
							name="mvweb_so[disable_gutenberg_widgets]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_gutenberg_widgets' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'use_widgets_block_editor → false. Внешний вид → Виджеты открывается в классическом интерфейсе drag-and-drop.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Gravatar', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Полное отключение запросов к gravatar.com — все аватары заменяются на локальную картинку-плейсхолдер.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-gravatar">
				<?php esc_html_e( 'Отключить Gravatar', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-gravatar"
							name="mvweb_so[disable_gravatar]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_gravatar' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'pre_get_avatar_data → подмена URL на /images/default-avatar.png. Сайт перестаёт отправлять MD5-хэш email в gravatar.com. Один из ключевых пунктов GDPR-чек-листа.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'RSS-фиды', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Отключение RSS, Atom, RDF и фидов комментариев. Полезно для сайтов, которые не используют ленту.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-feed">
				<?php esc_html_e( 'Отключить фиды', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-feed"
							name="mvweb_so[disable_feed]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_feed' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Все обращения к /feed/, /rss/, /atom/, /comments/feed/ редиректятся 301 на главную. Из <head> удаляются ссылки на feed_links и feed_links_extra.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Admin bar', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Управление WordPress-тулбаром на фронте сайта.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-admin-bar">
				<?php esc_html_e( 'Скрыть admin bar для не-администраторов', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-admin-bar"
							name="mvweb_so[disable_admin_bar]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_admin_bar' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'show_admin_bar → false для всех ролей кроме administrator. Администраторы продолжают видеть тулбар.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" name="mvweb_so_save" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Сохранить изменения', 'mvweb-site-optimizer' ); ?>
		</button>
	</div>
</form>
