<?php
/**
 * Help tab — Quick Start + FAQ + Support.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Быстрый старт', 'mvweb-site-optimizer' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Семь шагов, чтобы настроить плагин под ваш сайт.', 'mvweb-site-optimizer' ); ?></p>

	<ol class="mvweb-steps">
		<li>
			<div>
				<strong><?php esc_html_e( 'Плагин активен — но ничего не делает', 'mvweb-site-optimizer' ); ?></strong>
				<p><?php esc_html_e( 'По умолчанию все оптимизации выключены. Это сознательно: плагин ничего не меняет на сайте, пока вы сами не включите конкретную опцию. Так безопаснее.', 'mvweb-site-optimizer' ); ?></p>
			</div>
		</li>
		<li>
			<div>
				<strong><?php esc_html_e( 'Начните с вкладки Code', 'mvweb-site-optimizer' ); ?></strong>
				<p><?php esc_html_e( 'Базовая чистка фронтенда: эмодзи, jQuery Migrate, инлайн-стили виджета комментариев, минификация HTML. Эти опции безопасны для 99 % сайтов и сразу дают эффект.', 'mvweb-site-optimizer' ); ?></p>
			</div>
		</li>
		<li>
			<div>
				<strong><?php esc_html_e( 'Затем — SEO и Additionally', 'mvweb-site-optimizer' ); ?></strong>
				<p><?php esc_html_e( 'Кастомный robots.txt, отключение версий у CSS/JS, удаление meta generator, RSD, WLW, shortlink. Все опции опциональны и сочетаются с Yoast SEO.', 'mvweb-site-optimizer' ); ?></p>
			</div>
		</li>
		<li>
			<div>
				<strong><?php esc_html_e( 'Включайте Security осознанно', 'mvweb-site-optimizer' ); ?></strong>
				<p><?php esc_html_e( 'Скрытие wp-login.php, лимит попыток входа, REST API lockdown — мощные опции, но могут сломать сторонние интеграции (мобильные приложения, headless-фронт). Перед сменой URL логина — запишите новый URL себе!', 'mvweb-site-optimizer' ); ?></p>
			</div>
		</li>
		<li>
			<div>
				<strong><?php esc_html_e( 'Modules и Duplicate — для контентных сайтов', 'mvweb-site-optimizer' ); ?></strong>
				<p><?php esc_html_e( 'Если у вас блог или контент-сайт без активных комментариев и без Gutenberg-блоков на фронте — отключите их полностью. Если используете WooCommerce — оставьте всё включённым.', 'mvweb-site-optimizer' ); ?></p>
			</div>
		</li>
		<li>
			<div>
				<strong><?php esc_html_e( 'IndexNow для русскоязычных сайтов', 'mvweb-site-optimizer' ); ?></strong>
				<p><?php esc_html_e( 'Включите отправку в Яндекс и Bing — после публикации поста изменения попадают в индекс за минуты, а не за дни. Эндпоинт Google пока не поддерживает IndexNow, для него работает Sitemap.', 'mvweb-site-optimizer' ); ?></p>
			</div>
		</li>
		<li>
			<div>
				<strong><?php esc_html_e( 'Тестируйте на фронте после каждого изменения', 'mvweb-site-optimizer' ); ?></strong>
				<p><?php esc_html_e( 'После сохранения настроек откройте сайт в режиме инкогнито (или с другого устройства). Если что-то сломалось — отключите последнюю включённую опцию. На вкладке General есть Экспорт настроек — делайте резервную копию перед массовыми изменениями.', 'mvweb-site-optimizer' ); ?></p>
			</div>
		</li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Что в каких вкладках', 'mvweb-site-optimizer' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Краткая шпаргалка по разделам плагина.', 'mvweb-site-optimizer' ); ?></p>

	<div class="mvweb-table-wrap">
		<table class="mvweb-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Вкладка', 'mvweb-site-optimizer' ); ?></th>
					<th><?php esc_html_e( 'Что внутри', 'mvweb-site-optimizer' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><strong><?php esc_html_e( 'General', 'mvweb-site-optimizer' ); ?></strong></td>
					<td><?php esc_html_e( 'Обзор статуса, счётчик активных опций, экспорт/импорт/сброс настроек.', 'mvweb-site-optimizer' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Code', 'mvweb-site-optimizer' ); ?></strong></td>
					<td><?php esc_html_e( 'Чистка фронтенда: эмодзи, jQuery Migrate, recent comments style, минификация HTML.', 'mvweb-site-optimizer' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'SEO', 'mvweb-site-optimizer' ); ?></strong></td>
					<td><?php esc_html_e( 'noindex для пагинации, кастомный robots.txt, авто-alt, отключение wp-sitemap, 6 опций интеграции с Yoast SEO.', 'mvweb-site-optimizer' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Duplicate', 'mvweb-site-optimizer' ); ?></strong></td>
					<td><?php esc_html_e( 'Защита от дублей: несуществующая пагинация, attachment-страницы, архивы автора/даты/тега, защита от ?author=N.', 'mvweb-site-optimizer' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Security', 'mvweb-site-optimizer' ); ?></strong></td>
					<td><?php esc_html_e( 'REST API lockdown, скрытие wp-login.php, лимит попыток входа с журналом IP, принудительный HTTPS.', 'mvweb-site-optimizer' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Modules', 'mvweb-site-optimizer' ); ?></strong></td>
					<td><?php esc_html_e( 'Отключение компонентов ядра: комментарии, Gutenberg, классические виджеты, Gravatar, RSS, admin bar.', 'mvweb-site-optimizer' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Additionally', 'mvweb-site-optimizer' ); ?></strong></td>
					<td><?php esc_html_e( 'Кастомные сниппеты в head/body, cookie-баннер, нейтральные ошибки логина, ревизии, заголовки Last-Modified, чистка <head>.', 'mvweb-site-optimizer' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Redirect', 'mvweb-site-optimizer' ); ?></strong></td>
					<td><?php esc_html_e( 'Менеджер 301/302-редиректов с режимами exact и regex, поддержка backreferences ($0, $1, $2).', 'mvweb-site-optimizer' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'IndexNow', 'mvweb-site-optimizer' ); ?></strong></td>
					<td><?php esc_html_e( 'Автоматическая отправка изменений в Яндекс и Bing при публикации/обновлении/удалении записей.', 'mvweb-site-optimizer' ); ?></td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Maintenance', 'mvweb-site-optimizer' ); ?></strong></td>
					<td><?php esc_html_e( 'Режим обслуживания: HTTP 503 + кастомная страница-заглушка + whitelist IP для тестирования.', 'mvweb-site-optimizer' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-site-optimizer' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Частые вопросы по работе плагина.', 'mvweb-site-optimizer' ); ?></p>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Чем отличается от других плагинов оптимизации?', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Плагин полностью свой: открытый код, без лицензионных ключей, без отправки данных во внешние облака. Имена опций унифицированы с распространёнными в экосистеме — это упрощает миграцию через Экспорт/Импорт настроек.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Где находятся настройки?', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'В меню MVweb Hub в админке WordPress. Прямой адрес: admin.php?page=mvweb-site-optimizer. Все 10 функциональных вкладок переключаются без перезагрузки страницы.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Безопасно ли включать все опции сразу?', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Нет. Включайте по одной и проверяйте, что сайт работает корректно. Перед массовыми изменениями экспортируйте текущие настройки на вкладке General — потом можно одной кнопкой вернуться к рабочей конфигурации.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Я включил «скрытие wp-login.php» и теперь не могу войти. Что делать?', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Зайдите по FTP/SSH, откройте wp-config.php и временно добавьте: define( \'MVWEB_SO_DISABLE\', true ); — плагин не запустится, стандартный wp-login.php снова заработает. После входа уберите эту строку и поправьте URL входа в админке.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'REST API lockdown сломал моё мобильное приложение / Elementor / другой плагин', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Маршруты Yoast, WooCommerce, Elementor, Contact Form 7, Google Site Kit уже в whitelist по умолчанию. Если ваше приложение использует свой namespace — добавьте его через фильтр mvweb_so_rest_api_white_list в functions.php темы.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Yoast всё равно показывает meta robots дубликатом', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Это известное поведение Yoast 22+: он не вызывает старый фильтр wpseo_robots, поэтому наш noindex_pagination добавляет тег в дополнение. Решение: используйте опцию noindex_pagination только если Yoast не покрывает пагинацию сам.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Кастомный robots.txt не отдаётся — отдаётся стандартный WP', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'WordPress отдаёт виртуальный robots.txt только если в корне сайта нет физического файла. Если у вас есть /robots.txt в корне (созданный руками или Yoast-ом для multisite) — удалите его, чтобы наш фильтр сработал.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Как добавить свой URL в IndexNow вручную?', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'На вкладке IndexNow нажмите «Отправить тестовый URL» — отправится главная страница в выбранные эндпоинты. Журнал ниже покажет статус ответа. Для регулярной отправки достаточно публиковать/обновлять записи — плагин делает это автоматически.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'IndexNow вернул статус 4xx или 5xx', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( '200/202 = успех (Bing/Yandex принимают сразу). 400 обычно значит, что ключевой файл не доступен по https — проверьте, что /{key}.txt отдаёт ключ. 403/422 = домен ещё не верифицирован у Яндекс.Вебмастер — добавьте сайт в кабинет до включения IndexNow.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Я выключил Maintenance, но сайт всё равно отдаёт 503', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Если на сервере включён persistent object cache (Redis, Memcached), опция плагина может закэшироваться. Выполните в админке WP-CLI команду: wp cache flush — либо подождите TTL опций (обычно 1-5 минут). Сама опция в БД уже сброшена.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Можно ли использовать regex в редиректах?', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Да. На вкладке Redirect выберите режим «regex», в поле «Откуда» введите PCRE-шаблон без ограничителей (например, ^/old-blog/(.+)$), в поле «Куда» используйте $1, $2 для подстановки захваченных групп. Невалидный regex отклоняется на стадии сохранения.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Совместимо с WP Super Cache / W3 Total Cache / LiteSpeed Cache?', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Да. Наш HTML-минификатор работает на template_redirect и отдаёт сжатый HTML до того, как кэширующий плагин его подхватит. Не отключайте сжатие в самом cache-плагине — пусть он отдаёт уже минифицированную копию.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Совместимо с WooCommerce?', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Да. Маршруты WooCommerce, wc-admin и wc-analytics в whitelist REST API по умолчанию. На вкладке Duplicate WooCommerce-страницы (корзина, чекаут, аккаунт, магазин) исключены из редиректов пагинации. На вкладке Modules не отключайте Gutenberg, если используете блоки в описаниях товаров.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Поддерживает мультисайт?', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Активация работает per-site (для каждого сайта сети отдельно). При удалении плагина uninstall.php корректно проходит по всем сайтам через switch_to_blog. Network-активация не тестировалась — рекомендуется активировать на каждом сайте отдельно.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Как добавить кастомные правила в whitelist REST API?', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'В functions.php темы или mu-плагине: add_filter( \'mvweb_so_rest_api_white_list\', function( $list ) { $list[] = \'my-plugin\'; return $list; } ); — где my-plugin это namespace вашего эндпоинта (REST URL: /wp-json/my-plugin/v1/...).', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Влияет ли плагин на админ-панель?', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Нет — почти все оптимизации работают только на фронте. Исключения: disable_admin_bar (скрывает верхний бар у не-админов), disable_comments_interface (убирает меню Комментарии), disable_gutenberg (возвращает классический редактор). Они влияют на админку осознанно.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Как перенести настройки на другой сайт?', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'На вкладке General нажмите «Экспортировать» — скачается JSON с полным набором опций, включая правила редиректов и ключ IndexNow. На новом сайте нажмите «Импортировать» и выберите этот файл. Подпись плагина проверяется автоматически.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Как удалить плагин с очисткой настроек?', 'mvweb-site-optimizer' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Деактивация плагина не удаляет настройки. Полная очистка происходит только при удалении плагина из админки (Plugins → Delete) — uninstall.php автоматически уберёт все опции, журналы, transient\'ы и cron-задачи.', 'mvweb-site-optimizer' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Поддержка', 'mvweb-site-optimizer' ); ?></div>
	</div>
	<p>
		<?php
		echo wp_kses(
			sprintf(
				/* translators: %s: MVweb plugin URL */
				esc_html__( 'Документация и поддержка: %s', 'mvweb-site-optimizer' ),
				'<a href="' . esc_url( 'https://mvweb.ru/plugins/mvweb-site-optimizer' ) . '" target="_blank" rel="noopener noreferrer">mvweb.ru/plugins/mvweb-site-optimizer</a>'
			),
			array(
				'a' => array(
					'href'   => true,
					'target' => true,
					'rel'    => true,
				),
			)
		);
		?>
	</p>
	<p>
		<?php
		echo wp_kses(
			sprintf(
				/* translators: %s: plugin version */
				esc_html__( 'Версия плагина: %s', 'mvweb-site-optimizer' ),
				'<strong>' . esc_html( MVWEB_SO_VERSION ) . '</strong>'
			),
			array( 'strong' => array() )
		);
		?>
	</p>
</div>
