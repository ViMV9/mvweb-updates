/**
 * Admin JavaScript for MVweb Site Optimizer.
 *
 * Tab navigation without page reload (URL hash-based), FAQ accordion,
 * Export/Import/Reset handlers for the General tab, Redirect manager.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

(function ($) {
	'use strict';

	function i18n(key, fallback) {
		var dict = (window.mvweb_so_ajax && window.mvweb_so_ajax.i18n) || {};
		return Object.prototype.hasOwnProperty.call(dict, key) ? dict[key] : (fallback || key);
	}

	function escapeHtml(text) {
		return $('<div/>').text(text == null ? '' : String(text)).html();
	}

	function initTabs() {
		var $links = $('.mvweb-nav .mvweb-nav__link');
		var $contents = $('.mvweb-tab-content');

		if (!$links.length || !$contents.length) {
			return;
		}

		function applyTab(tabId) {
			$links.removeClass('mvweb-nav__link--active');
			$links.filter('[data-tab="' + tabId + '"]').addClass('mvweb-nav__link--active');

			$contents.removeClass('active');
			$('#' + tabId).addClass('active');
		}

		$links.on('click', function (e) {
			e.preventDefault();

			var $this = $(this);
			var tabId = $this.data('tab') || ($this.attr('href') || '').replace('#', '');
			if (!tabId) {
				return;
			}

			applyTab(tabId);

			if (history.pushState) {
				history.pushState(null, null, '#' + tabId);
			}
		});

		var hash = window.location.hash.substring(1);
		if (hash && $('#' + hash).length) {
			applyTab(hash);
		}
	}

	function initFaqAccordion() {
		$('.mvweb-block').each(function () {
			var $details = $(this).find('details.mvweb-faq');
			if ($details.length < 2) {
				return;
			}

			$details.on('toggle', function () {
				var self = this;
				if (self.open) {
					$details.each(function () {
						if (this !== self) {
							this.open = false;
						}
					});
				}
			});
		});
	}

	function ajax(action, data) {
		var payload = $.extend({
			action: action,
			nonce: (window.mvweb_so_ajax && window.mvweb_so_ajax.nonce) || ''
		}, data || {});

		return $.post(
			(window.mvweb_so_ajax && window.mvweb_so_ajax.ajax_url) || window.ajaxurl,
			payload
		);
	}

	function showFeedback(selector, message, type) {
		var $box = $(selector);
		if (!$box.length) {
			return;
		}
		var cls = 'mvweb-alert mvweb-alert--' + (type || 'info');
		$box.html('<div class="' + cls + '"><div class="mvweb-alert__body">' + escapeHtml(message) + '</div></div>');
	}

	function updateCounters(features, total) {
		if (typeof features === 'number') {
			$('[data-mvweb-so-active]').text(features);
		}
		if (typeof total === 'number') {
			$('[data-mvweb-so-total]').text(total);
		}
	}

	function downloadFile(filename, content) {
		var blob = new Blob([content], { type: 'application/json;charset=utf-8' });
		var url  = URL.createObjectURL(blob);
		var a    = document.createElement('a');
		a.href = url;
		a.download = filename;
		document.body.appendChild(a);
		a.click();
		document.body.removeChild(a);
		setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
	}

	function initGeneralExport() {
		$(document).on('click', '[data-mvweb-so-export]', function (e) {
			e.preventDefault();
			var $btn = $(this);
			$btn.prop('disabled', true);

			ajax('mvweb_so_export_settings')
				.done(function (response) {
					if (!response || !response.success) {
						var msg = (response && response.data && response.data.message) || i18n('export_failed_action');
						showFeedback('[data-mvweb-so-feedback]', msg, 'error');
						return;
					}
					var decoded;
					try {
						decoded = decodeURIComponent(escape(atob(response.data.data)));
					} catch (err) {
						showFeedback('[data-mvweb-so-feedback]', i18n('export_failed'), 'error');
						return;
					}
					downloadFile(response.data.filename, decoded);
					showFeedback('[data-mvweb-so-feedback]', i18n('export_done'), 'success');
				})
				.fail(function () {
					showFeedback('[data-mvweb-so-feedback]', i18n('error_connection'), 'error');
				})
				.always(function () {
					$btn.prop('disabled', false);
				});
		});
	}

	function initGeneralImport() {
		var $fileInput  = $('[data-mvweb-so-import-file]');
		var $importBtn  = $('[data-mvweb-so-import]');
		var fileContent = '';

		$fileInput.on('change', function () {
			var file = this.files && this.files[0];
			$importBtn.prop('disabled', true);
			fileContent = '';

			if (!file) {
				return;
			}

			var reader = new FileReader();
			reader.onload = function (e) {
				fileContent = e.target.result;
				$importBtn.prop('disabled', false);
			};
			reader.onerror = function () {
				showFeedback('[data-mvweb-so-feedback]', i18n('file_read_failed'), 'error');
			};
			reader.readAsText(file);
		});

		$importBtn.on('click', function (e) {
			e.preventDefault();
			if (!fileContent) {
				showFeedback('[data-mvweb-so-feedback]', i18n('import_pick_file'), 'warning');
				return;
			}

			$importBtn.prop('disabled', true);

			ajax('mvweb_so_import_settings', { payload: fileContent })
				.done(function (response) {
					if (!response || !response.success) {
						var msg = (response && response.data && response.data.message) || i18n('import_failed_action');
						showFeedback('[data-mvweb-so-feedback]', msg, 'error');
						return;
					}
					showFeedback('[data-mvweb-so-feedback]', response.data.message || i18n('imported'), 'success');
					updateCounters(response.data.features, response.data.features);
					$fileInput.val('');
					fileContent = '';
				})
				.fail(function () {
					showFeedback('[data-mvweb-so-feedback]', i18n('error_connection'), 'error');
				})
				.always(function () {
					$importBtn.prop('disabled', !fileContent);
				});
		});
	}

	function initGeneralReset() {
		$(document).on('click', '[data-mvweb-so-reset]', function (e) {
			e.preventDefault();
			if (!window.confirm(i18n('confirm_reset'))) {
				return;
			}
			var $btn = $(this);
			$btn.prop('disabled', true);

			ajax('mvweb_so_reset_settings')
				.done(function (response) {
					if (!response || !response.success) {
						var msg = (response && response.data && response.data.message) || i18n('reset_failed_action');
						showFeedback('[data-mvweb-so-feedback]', msg, 'error');
						return;
					}
					showFeedback('[data-mvweb-so-feedback]', response.data.message || i18n('reset_done'), 'success');
					updateCounters(0, 0);
				})
				.fail(function () {
					showFeedback('[data-mvweb-so-feedback]', i18n('error_connection'), 'error');
				})
				.always(function () {
					$btn.prop('disabled', false);
				});
		});
	}

	function buildRedirectRow(rule) {
		var modeLabel     = rule.mode === 'regex' ? i18n('mode_regex') : i18n('mode_exact');
		var externalLabel = parseInt(rule.allow_external, 10) === 1 ? i18n('external_yes') : i18n('external_no');
		var externalCls   = parseInt(rule.allow_external, 10) === 1 ? 'mvweb-badge mvweb-badge--warning' : 'mvweb-badge';

		return '<tr data-mvweb-so-redirect-row' +
			' data-id="' + escapeHtml(rule.id) + '"' +
			' data-from="' + escapeHtml(rule.from) + '"' +
			' data-to="' + escapeHtml(rule.to) + '"' +
			' data-type="' + escapeHtml(rule.type) + '"' +
			' data-mode="' + escapeHtml(rule.mode) + '"' +
			' data-allow-external="' + escapeHtml(rule.allow_external) + '">' +
			'<td><code>' + escapeHtml(rule.from) + '</code></td>' +
			'<td><code>' + escapeHtml(rule.to) + '</code></td>' +
			'<td><span class="mvweb-badge mvweb-badge--success">' + escapeHtml(rule.type) + '</span></td>' +
			'<td><span class="mvweb-badge">' + escapeHtml(modeLabel) + '</span></td>' +
			'<td><span class="' + externalCls + '">' + escapeHtml(externalLabel) + '</span></td>' +
			'<td><label class="mvweb-toggle"><input type="checkbox" data-mvweb-so-redirect-toggle value="1" ' +
			(parseInt(rule.enabled, 10) === 1 ? 'checked' : '') + '><span class="mvweb-toggle__slider"></span></label></td>' +
			'<td><div class="mvweb-so-actions">' +
			'<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm" data-mvweb-so-redirect-edit>' + escapeHtml(i18n('edit')) + '</button>' +
			'<button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm" data-mvweb-so-redirect-delete>' + escapeHtml(i18n('delete')) + '</button>' +
			'</div></td>' +
			'</tr>';
	}

	function updateRedirectCount() {
		var count = $('[data-mvweb-so-redirect-tbody] [data-mvweb-so-redirect-row]').length;
		$('[data-mvweb-so-redirect-count]').text(count);

		var $tbody = $('[data-mvweb-so-redirect-tbody]');
		var $empty = $tbody.find('[data-mvweb-so-redirect-empty]');

		if (count === 0 && !$empty.length) {
			$tbody.append('<tr data-mvweb-so-redirect-empty><td colspan="7"><div class="mvweb-empty">' + escapeHtml(i18n('no_rules')) + '</div></td></tr>');
		} else if (count > 0 && $empty.length) {
			$empty.remove();
		}
	}

	function initRedirect() {
		var $form = $('[data-mvweb-so-redirect-form]');
		if (!$form.length) {
			return;
		}

		var $tbody    = $('[data-mvweb-so-redirect-tbody]');
		var $resetBtn = $('[data-mvweb-so-redirect-reset]');
		var $addBtn   = $('[data-mvweb-so-redirect-add]');
		var editingId = 0;

		function resetForm() {
			$form[0].reset();
			editingId = 0;
			$addBtn.text(i18n('add_rule'));
			$resetBtn.attr('hidden', true);
		}

		$addBtn.text(i18n('add_rule'));

		$resetBtn.on('click', function (e) {
			e.preventDefault();
			resetForm();
		});

		$form.on('submit', function (e) {
			e.preventDefault();

			var data = {
				from:           $form.find('[name="from"]').val(),
				to:             $form.find('[name="to"]').val(),
				type:           $form.find('[name="type"]').val(),
				mode:           $form.find('[name="mode"]').val(),
				allow_external: $form.find('[name="allow_external"]').is(':checked') ? '1' : ''
			};

			if (editingId > 0) {
				data.id = editingId;
			}

			$addBtn.prop('disabled', true);

			var action = editingId > 0 ? 'mvweb_so_redirect_update' : 'mvweb_so_redirect_add';

			ajax(action, data)
				.done(function (response) {
					if (!response || !response.success) {
						var msg = (response && response.data && response.data.message) || i18n('error_save');
						showFeedback('[data-mvweb-so-redirect-feedback]', msg, 'error');
						return;
					}

					var rule = response.data.rule;
					rule.enabled = (typeof rule.enabled === 'undefined') ? 1 : rule.enabled;

					if (editingId > 0) {
						var $row = $tbody.find('[data-mvweb-so-redirect-row][data-id="' + editingId + '"]');
						$row.replaceWith(buildRedirectRow(rule));
					} else {
						$tbody.append(buildRedirectRow(rule));
					}

					resetForm();
					updateRedirectCount();
					showFeedback('[data-mvweb-so-redirect-feedback]', response.data.message || i18n('saved'), 'success');
				})
				.fail(function () {
					showFeedback('[data-mvweb-so-redirect-feedback]', i18n('error_connection'), 'error');
				})
				.always(function () {
					$addBtn.prop('disabled', false);
				});
		});

		$tbody.on('click', '[data-mvweb-so-redirect-edit]', function (e) {
			e.preventDefault();
			var $row = $(this).closest('[data-mvweb-so-redirect-row]');

			editingId = parseInt($row.data('id'), 10) || 0;
			$form.find('[name="from"]').val($row.data('from'));
			$form.find('[name="to"]').val($row.data('to'));
			$form.find('[name="type"]').val(String($row.data('type')));
			$form.find('[name="mode"]').val($row.data('mode'));
			$form.find('[name="allow_external"]').prop('checked', parseInt($row.data('allow-external'), 10) === 1);

			$addBtn.text(i18n('save_changes'));
			$resetBtn.removeAttr('hidden');

			$('html, body').animate({ scrollTop: $form.offset().top - 40 }, 200);
		});

		$tbody.on('click', '[data-mvweb-so-redirect-delete]', function (e) {
			e.preventDefault();
			if (!window.confirm(i18n('confirm_delete_rule'))) {
				return;
			}

			var $row = $(this).closest('[data-mvweb-so-redirect-row]');
			var id   = parseInt($row.data('id'), 10) || 0;
			if (!id) {
				return;
			}

			ajax('mvweb_so_redirect_delete', { id: id })
				.done(function (response) {
					if (!response || !response.success) {
						var msg = (response && response.data && response.data.message) || i18n('error_delete');
						showFeedback('[data-mvweb-so-redirect-feedback]', msg, 'error');
						return;
					}
					$row.remove();
					updateRedirectCount();
					showFeedback('[data-mvweb-so-redirect-feedback]', response.data.message || i18n('deleted'), 'success');
				})
				.fail(function () {
					showFeedback('[data-mvweb-so-redirect-feedback]', i18n('error_connection'), 'error');
				});
		});

		$tbody.on('change', '[data-mvweb-so-redirect-toggle]', function () {
			var $row = $(this).closest('[data-mvweb-so-redirect-row]');
			var id   = parseInt($row.data('id'), 10) || 0;
			if (!id) {
				return;
			}

			var $cb = $(this);
			$cb.prop('disabled', true);

			ajax('mvweb_so_redirect_toggle', { id: id })
				.done(function (response) {
					if (!response || !response.success) {
						$cb.prop('checked', !$cb.prop('checked'));
						var msg = (response && response.data && response.data.message) || i18n('error_toggle');
						showFeedback('[data-mvweb-so-redirect-feedback]', msg, 'error');
						return;
					}
					$cb.prop('checked', response.data.enabled === 1);
				})
				.fail(function () {
					$cb.prop('checked', !$cb.prop('checked'));
					showFeedback('[data-mvweb-so-redirect-feedback]', i18n('error_connection'), 'error');
				})
				.always(function () {
					$cb.prop('disabled', false);
				});
		});
	}

	function initIndexNow() {
		var $key = $('[data-mvweb-so-indexnow-key]');
		if (!$key.length) {
			return;
		}

		$(document).on('click', '[data-mvweb-so-indexnow-regenerate]', function (e) {
			e.preventDefault();
			if (!window.confirm(i18n('confirm_regenerate'))) {
				return;
			}

			var $btn = $(this);
			$btn.prop('disabled', true);

			ajax('mvweb_so_indexnow_regenerate_key')
				.done(function (response) {
					if (!response || !response.success) {
						var msg = (response && response.data && response.data.message) || i18n('error_save');
						showFeedback('[data-mvweb-so-indexnow-feedback]', msg, 'error');
						return;
					}
					$key.val(response.data.key);
					var $link = $('[data-mvweb-so-indexnow-key-url]');
					if ($link.length) {
						$link.attr('href', response.data.key_url);
						$link.find('code').text(response.data.key_url);
					}
					showFeedback('[data-mvweb-so-indexnow-feedback]', response.data.message || i18n('key_regenerated'), 'success');
				})
				.fail(function () {
					showFeedback('[data-mvweb-so-indexnow-feedback]', i18n('error_connection'), 'error');
				})
				.always(function () {
					$btn.prop('disabled', false);
				});
		});

		$(document).on('click', '[data-mvweb-so-indexnow-test]', function (e) {
			e.preventDefault();
			var $btn = $(this);
			$btn.prop('disabled', true);

			ajax('mvweb_so_indexnow_send_test')
				.done(function (response) {
					if (!response || !response.success) {
						var msg = (response && response.data && response.data.message) || i18n('error_save');
						showFeedback('[data-mvweb-so-indexnow-feedback]', msg, 'error');
						return;
					}
					showFeedback('[data-mvweb-so-indexnow-feedback]', response.data.message || i18n('test_sent'), 'success');
				})
				.fail(function () {
					showFeedback('[data-mvweb-so-indexnow-feedback]', i18n('error_connection'), 'error');
				})
				.always(function () {
					$btn.prop('disabled', false);
				});
		});

		$(document).on('click', '[data-mvweb-so-indexnow-clear-log]', function (e) {
			e.preventDefault();
			if (!window.confirm(i18n('confirm_clear_log'))) {
				return;
			}

			var $btn = $(this);
			$btn.prop('disabled', true);

			ajax('mvweb_so_indexnow_clear_log')
				.done(function (response) {
					if (!response || !response.success) {
						var msg = (response && response.data && response.data.message) || i18n('error_save');
						showFeedback('[data-mvweb-so-indexnow-feedback]', msg, 'error');
						return;
					}
					showFeedback('[data-mvweb-so-indexnow-feedback]', response.data.message || i18n('log_cleared'), 'success');
					$('[data-mvweb-so-indexnow-count]').text('0');
				})
				.fail(function () {
					showFeedback('[data-mvweb-so-indexnow-feedback]', i18n('error_connection'), 'error');
				})
				.always(function () {
					$btn.prop('disabled', false);
				});
		});
	}

	$(function () {
		initTabs();
		initFaqAccordion();
		initGeneralExport();
		initGeneralImport();
		initGeneralReset();
		initRedirect();
		initIndexNow();
	});
})(jQuery);
