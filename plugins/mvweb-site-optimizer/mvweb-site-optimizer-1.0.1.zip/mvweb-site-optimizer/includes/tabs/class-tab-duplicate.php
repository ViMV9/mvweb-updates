<?php
/**
 * Duplicate tab — защита от дублирующего контента.
 *
 * Phase 4. Шесть переключателей: пагинация одиночных записей, attachment-страницы,
 * архивы автора/даты/тега и author-параметр в URL. Имена опций выбраны для
 * совместимости при миграции настроек с аналогичных плагинов оптимизации.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Tab_Duplicate {

	const ALLOWED_KEYS = array(
		'remove_single_pagination_duplicate',
		'attachment_pages_redirect',
		'redirect_archives_author',
		'redirect_archives_date',
		'redirect_archives_tag',
		'protect_author_get',
	);

	public function __construct() {
		if ( is_admin() ) {
			add_filter( 'mvweb_so_sanitize_duplicate', array( $this, 'sanitize' ), 10, 1 );
		}

		if ( mvweb_so_check_option( 'remove_single_pagination_duplicate' ) ) {
			add_action( 'template_redirect', array( $this, 'remove_single_pagination_duplicate' ) );
		}

		if ( mvweb_so_check_option( 'attachment_pages_redirect' ) ) {
			add_action( 'wp', array( $this, 'attachment_pages_redirect' ) );
		}

		if ( mvweb_so_check_option( 'redirect_archives_author' ) ) {
			add_action( 'wp', array( $this, 'redirect_archives_author' ) );
		}

		if ( mvweb_so_check_option( 'redirect_archives_date' ) ) {
			add_action( 'wp', array( $this, 'redirect_archives_date' ) );
		}

		if ( mvweb_so_check_option( 'redirect_archives_tag' ) ) {
			add_action( 'wp', array( $this, 'redirect_archives_tag' ) );
		}

		if ( mvweb_so_check_option( 'protect_author_get' ) ) {
			add_action( 'wp', array( $this, 'protect_author_get' ) );
		}
	}

	public function remove_single_pagination_duplicate(): void {
		if ( ! is_singular() ) {
			return;
		}

		if ( $this->is_woocommerce_excluded_page() ) {
			return;
		}

		global $post, $page;

		if ( ! ( $post instanceof WP_Post ) ) {
			return;
		}

		$content = (string) $post->post_content;

		if ( false === strpos( $content, '<!--nextpage-->' ) ) {
			if ( (int) $page > 1 ) {
				wp_safe_redirect( get_permalink( $post ), 301 );
				exit;
			}
			return;
		}

		$pages_count = substr_count( $content, '<!--nextpage-->' ) + 1;

		if ( (int) $page > $pages_count ) {
			wp_safe_redirect( get_permalink( $post ), 301 );
			exit;
		}
	}

	public function attachment_pages_redirect(): void {
		if ( ! is_attachment() ) {
			return;
		}

		global $post;

		if ( ! ( $post instanceof WP_Post ) ) {
			return;
		}

		$target = ( $post->post_parent > 0 )
			? get_permalink( $post->post_parent )
			: home_url( '/' );

		if ( ! is_string( $target ) || '' === $target ) {
			$target = home_url( '/' );
		}

		wp_safe_redirect( $target, 301 );
		exit;
	}

	public function redirect_archives_author(): void {
		if ( is_author() ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}

	public function redirect_archives_date(): void {
		if ( is_date() ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}

	public function redirect_archives_tag(): void {
		if ( is_tag() ) {
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}

	public function protect_author_get(): void {
		if ( is_admin() ) {
			return;
		}

		if ( isset( $_GET['author'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			wp_safe_redirect( home_url( '/' ), 301 );
			exit;
		}
	}

	private function is_woocommerce_excluded_page(): bool {
		if ( ! function_exists( 'is_woocommerce' ) ) {
			return false;
		}

		if ( function_exists( 'is_cart' ) && is_cart() ) {
			return true;
		}

		if ( function_exists( 'is_checkout' ) && is_checkout() ) {
			return true;
		}

		if ( function_exists( 'is_account_page' ) && is_account_page() ) {
			return true;
		}

		if ( function_exists( 'is_shop' ) && is_shop() ) {
			return true;
		}

		return false;
	}

	public function sanitize( $raw ): array {
		$raw = is_array( $raw ) ? $raw : array();
		$out = array();

		foreach ( self::ALLOWED_KEYS as $key ) {
			$out[ $key ] = isset( $raw[ $key ] ) && 'on' === $raw[ $key ] ? 'on' : '';
		}

		return $out;
	}
}
