<?php
/**
 * Security tab — REST API lockdown, hide-login, login rate-limit, force HTTPS.
 *
 * Phase 5. Самая «толстая» вкладка плагина: блокирует анонимный доступ к REST API
 * (с whitelist), переименовывает wp-login.php, ограничивает попытки входа
 * (с IP-журналом в отдельной опции) и принудительно редиректит HTTP → HTTPS.
 *
 * Имена опций выбраны для совместимости при миграции настроек с аналогичных
 * плагинов оптимизации.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Tab_Security {

	const ALLOWED_KEYS = array(
		'disable_json_rest_api',
		'hide_wp_login',
		'hide_wp_login_new_slug',
		'login_attempts',
		'login_attempts_allowed_retries',
		'login_attempts_allowed_lockouts',
		'login_attempts_lockout_duration',
		'login_attempts_long_duration',
		'login_attempts_whitelist',
		'login_attempts_blacklist',
		'redirect_from_http_to_https',
		'session_expiration',
	);

	const DEFAULT_ALLOWED_RETRIES   = 5;
	const DEFAULT_ALLOWED_LOCKOUTS  = 4;
	const DEFAULT_LOCKOUT_DURATION  = 20;
	const DEFAULT_LONG_DURATION     = 24;
	const VALID_DURATION            = 86400;

	const SESSION_PRESETS = array(
		1209600,
		2592000,
		7776000,
		15552000,
		31536000,
	);

	const OPTION_LOCKOUTS = 'mvweb_so_login_attempts_lockouts';
	const OPTION_RETRIES  = 'mvweb_so_login_attempts_retries';
	const OPTION_TOTAL    = 'mvweb_so_login_attempts_total';

	private $is_wp_login = false;

	public function __construct() {
		if ( is_admin() ) {
			add_filter( 'mvweb_so_sanitize_security', array( $this, 'sanitize' ), 10, 1 );
		}

		if ( mvweb_so_check_option( 'disable_json_rest_api' ) ) {
			$this->init_rest_api_lockdown();
		}

		if ( mvweb_so_check_option( 'hide_wp_login' ) ) {
			$slug = (string) mvweb_so_get_option( 'hide_wp_login_new_slug', '' );
			if ( '' !== $slug ) {
				$this->init_hide_login();
			}
		}

		if ( mvweb_so_check_option( 'login_attempts' ) ) {
			$this->init_login_attempts();
		}

		if ( mvweb_so_check_option( 'redirect_from_http_to_https' ) ) {
			add_action( 'init', array( $this, 'redirect_from_http_to_https' ) );
		}

		$session = (int) mvweb_so_get_option( 'session_expiration', 0 );
		if ( in_array( $session, self::SESSION_PRESETS, true ) ) {
			add_filter( 'auth_cookie_expiration', array( $this, 'filter_auth_cookie_expiration' ), 10, 3 );
		}
	}

	private function init_rest_api_lockdown(): void {
		remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
		remove_action( 'xmlrpc_rsd_apis', 'rest_output_rsd' );
		remove_action( 'template_redirect', 'rest_output_link_header', 11 );
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
		remove_action( 'wp_head', 'wp_oembed_add_host_js' );

		add_filter( 'rest_authentication_errors', array( $this, 'rest_authentication_errors' ) );
	}

	public function rest_authentication_errors( $access ) {
		if ( is_user_logged_in() ) {
			return $access;
		}

		$rest_route = $this->get_rest_route();
		if ( '' === $rest_route ) {
			return $access;
		}

		$white_list = apply_filters(
			'mvweb_so_rest_api_white_list',
			array(
				'oembed',
				'yoast',
				'contact-form-7',
				'google-site-kit',
				'wc',
				'wc-admin',
				'wc-analytics',
				'wc-telemetry',
				'wccom-site',
				'aioseo',
				'elementor',
				'wp-site-health',
				'wp-block-editor',
			)
		);

		foreach ( $white_list as $item ) {
			$pattern = '#^/' . preg_quote( (string) $item, '#' ) . '(/|$)#i';
			if ( preg_match( $pattern, $rest_route ) ) {
				return $access;
			}
		}

		return new WP_Error(
			'mvweb_so_rest_cannot_access',
			esc_html__( 'Доступ к REST API запрещён.', 'mvweb-site-optimizer' ),
			array( 'status' => rest_authorization_required_code() )
		);
	}

	private function get_rest_route(): string {
		if ( ! isset( $GLOBALS['wp']->query_vars['rest_route'] ) ) {
			return '';
		}
		$rest_route = (string) $GLOBALS['wp']->query_vars['rest_route'];
		if ( '' === $rest_route || '/' === $rest_route ) {
			return $rest_route;
		}
		return untrailingslashit( $rest_route );
	}

	private function init_hide_login(): void {
		add_action( 'plugins_loaded', array( $this, 'hide_login_plugins_loaded' ), 1 );
		add_action( 'wp_loaded', array( $this, 'hide_login_wp_loaded' ) );

		remove_action( 'template_redirect', 'wp_redirect_admin_locations', 1000 );

		add_filter( 'site_url', array( $this, 'hide_login_site_url' ), 10, 4 );
		add_filter( 'network_site_url', array( $this, 'hide_login_network_site_url' ), 10, 3 );
		add_filter( 'wp_redirect', array( $this, 'hide_login_wp_redirect' ), 10, 2 );
		add_filter( 'site_option_welcome_email', array( $this, 'hide_login_welcome_email' ) );
	}

	public function hide_login_plugins_loaded(): void {
		global $pagenow;

		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( (string) $_SERVER['REQUEST_URI'] ) : '';
		$request     = wp_parse_url( $request_uri );

		$login_slugs = array( 'wp-login', 'wp-register' );
		if ( ! is_multisite() ) {
			$login_slugs[] = 'wp-signup';
			$login_slugs[] = 'wp-activate';
		}

		$denied = false;
		foreach ( $login_slugs as $login_slug ) {
			if ( false !== strpos( $request_uri, $login_slug . '.php' ) ) {
				$denied = true;
			}
			if ( isset( $request['path'] ) && untrailingslashit( $request['path'] ) === site_url( $login_slug, 'relative' ) ) {
				$denied = true;
			}
		}

		if ( isset( $request['path'] ) && preg_match( '/wp-admin\/customize\.php/ui', untrailingslashit( $request['path'] ) ) && ! is_user_logged_in() ) {
			$this->hide_login_die();
		}

		$new_slug = $this->new_login_slug();

		if ( ! is_admin() && $denied ) {
			$this->is_wp_login = true;
			$pagenow           = 'index.php';
		} elseif (
			( isset( $request['path'] ) && untrailingslashit( $request['path'] ) === home_url( $new_slug, 'relative' ) )
			|| ( ! get_option( 'permalink_structure' ) && isset( $_GET[ $new_slug ] ) ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		) {
			$pagenow = 'wp-login.php';
		}
	}

	public function hide_login_wp_loaded(): void {
		global $pagenow;

		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( (string) $_SERVER['REQUEST_URI'] ) : '';
		$request     = wp_parse_url( $request_uri );

		if ( is_admin() && ! is_user_logged_in() && ! defined( 'DOING_AJAX' ) ) {
			wp_safe_redirect( home_url( '/' ) );
			exit;
		}

		if ( 'wp-login.php' === $pagenow && isset( $request['path'] ) && $request['path'] !== $this->trailing_slash( $request['path'] ) && get_option( 'permalink_structure' ) ) {
			$query = isset( $_SERVER['QUERY_STRING'] ) ? '?' . wp_unslash( (string) $_SERVER['QUERY_STRING'] ) : '';
			wp_safe_redirect( $this->trailing_slash( $this->new_login_url() ) . $query );
			exit;
		}

		if ( $this->is_wp_login ) {
			$this->hide_login_die();
		}

		if ( 'wp-login.php' === $pagenow ) {
			global $error, $interim_login, $action, $user_login;

			if ( is_user_logged_in() && ! isset( $_REQUEST['action'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				wp_safe_redirect( admin_url() );
				exit;
			}

			if ( ! defined( 'DONOTCACHEPAGE' ) ) {
				define( 'DONOTCACHEPAGE', true );
			}

			require_once ABSPATH . 'wp-login.php';
			exit;
		}
	}

	private function hide_login_die(): void {
		wp_die(
			esc_html__( 'Извините, эта страница недоступна.', 'mvweb-site-optimizer' ),
			'',
			array( 'response' => 403 )
		);
	}

	public function hide_login_site_url( $url, $path, $scheme, $blog_id ) {
		return $this->filter_login_url( (string) $url, $scheme );
	}

	public function hide_login_network_site_url( $url, $path, $scheme ) {
		return $this->filter_login_url( (string) $url, $scheme );
	}

	public function hide_login_wp_redirect( $location, $status ) {
		return $this->filter_login_url( (string) $location );
	}

	public function hide_login_welcome_email( $value ) {
		return str_replace( 'wp-login.php', trailingslashit( $this->new_login_slug() ), (string) $value );
	}

	private function filter_login_url( string $url, $scheme = null ): string {
		if ( false === strpos( $url, 'wp-login.php' ) ) {
			return $url;
		}
		if ( is_ssl() ) {
			$scheme = 'https';
		}
		$parts = explode( '?', $url );
		if ( isset( $parts[1] ) ) {
			parse_str( $parts[1], $args );
			return add_query_arg( $args, $this->new_login_url( $scheme ) );
		}
		return $this->new_login_url( $scheme );
	}

	private function new_login_slug(): string {
		return (string) mvweb_so_get_option( 'hide_wp_login_new_slug', '' );
	}

	private function new_login_url( $scheme = null ): string {
		if ( get_option( 'permalink_structure' ) ) {
			return $this->trailing_slash( home_url( '/', $scheme ) . $this->new_login_slug() );
		}
		return home_url( '/', $scheme ) . '?' . $this->new_login_slug();
	}

	private function trailing_slash( string $string ): string {
		if ( '/' === substr( (string) get_option( 'permalink_structure' ), -1, 1 ) ) {
			return trailingslashit( $string );
		}
		return untrailingslashit( $string );
	}

	private function init_login_attempts(): void {
		add_action( 'wp_login_failed', array( $this, 'login_attempts_failed' ) );
		add_filter( 'wp_authenticate_user', array( $this, 'login_attempts_authenticate_user' ), 99999, 2 );
		add_action( 'authenticate', array( $this, 'login_attempts_authenticate_filter' ), 5, 3 );
		add_filter( 'shake_error_codes', array( $this, 'login_attempts_shake_codes' ) );
		add_action( 'login_errors', array( $this, 'login_attempts_login_errors' ), 20 );
		add_filter( 'xmlrpc_login_error', array( $this, 'login_attempts_xmlrpc_login_error' ) );

		if ( defined( 'XMLRPC_REQUEST' ) && XMLRPC_REQUEST ) {
			add_action( 'init', array( $this, 'login_attempts_xmlrpc_lock' ) );
		}
	}

	public function login_attempts_failed( $username ): void {
		unset( $username );

		$ips      = $this->get_ips();
		$lockouts = get_option( self::OPTION_LOCKOUTS, array() );
		if ( ! is_array( $lockouts ) ) {
			$lockouts = array();
		}

		foreach ( $ips as $ip ) {
			if ( isset( $lockouts[ $ip ] ) && time() < $lockouts[ $ip ] ) {
				return;
			}
		}

		$retries = get_option( self::OPTION_RETRIES, array() );
		if ( ! is_array( $retries ) ) {
			$retries = array();
		}

		foreach ( $ips as $ip ) {
			if ( isset( $retries[ $ip ] ) && time() < $retries[ $ip ]['valid'] ) {
				++$retries[ $ip ]['count'];
			} else {
				$retries[ $ip ]['count'] = 1;
			}
			$retries[ $ip ]['valid'] = time() + self::VALID_DURATION;
		}

		$allowed_retries = $this->get_allowed_retries();
		foreach ( $ips as $ip ) {
			if ( 0 !== $retries[ $ip ]['count'] % $allowed_retries ) {
				$this->login_attempts_clean( null, $retries );
				return;
			}
		}

		$allowed_lockouts = $this->get_allowed_lockouts();
		$retries_long     = $allowed_retries * $allowed_lockouts;
		$lockout_duration = $this->get_lockout_duration();
		$long_duration    = $this->get_long_duration();

		if ( $this->is_whitelist( $ips ) ) {
			foreach ( $ips as $ip ) {
				if ( $retries[ $ip ]['count'] >= $retries_long ) {
					unset( $retries[ $ip ] );
				}
			}
		} else {
			foreach ( $ips as $ip ) {
				if ( $retries[ $ip ]['count'] >= $retries_long ) {
					$lockouts[ $ip ] = time() + $long_duration;
					unset( $retries[ $ip ] );
				} else {
					$lockouts[ $ip ] = time() + $lockout_duration;
				}
			}
		}

		$this->login_attempts_clean( $lockouts, $retries );

		$total = (int) get_option( self::OPTION_TOTAL, 0 );
		update_option( self::OPTION_TOTAL, $total + 1, false );
	}

	public function login_attempts_authenticate_user( $user, $password ) {
		unset( $password );

		if ( is_wp_error( $user ) ) {
			return $user;
		}

		if ( $this->login_attempts_can_user_login() ) {
			return $user;
		}

		$error = new WP_Error();
		if ( $this->is_blacklist() ) {
			$error->add( 'ip_in_blacklist', __( '<strong>Ошибка</strong>: доступ запрещён.', 'mvweb-site-optimizer' ) );
		} else {
			$error->add( 'too_many_retries', $this->login_attempts_error_message() );
		}
		return $error;
	}

	public function login_attempts_authenticate_filter( $user, $username, $password ) {
		if ( ! empty( $username ) && ! empty( $password ) ) {
			if ( ! $this->is_whitelist() && $this->is_blacklist() ) {
				remove_filter( 'wp_login_failed', array( $this, 'login_attempts_failed' ) );
				remove_filter( 'wp_authenticate_user', array( $this, 'login_attempts_authenticate_user' ), 99999 );
				remove_filter( 'login_errors', array( $this, 'login_attempts_login_errors' ), 20 );

				remove_filter( 'authenticate', 'wp_authenticate_username_password', 20 );
				remove_filter( 'authenticate', 'wp_authenticate_email_password', 20 );

				$user = new WP_Error();
				$user->add( 'ip_in_blacklist', __( '<strong>Ошибка</strong>: доступ запрещён.', 'mvweb-site-optimizer' ) );
			} elseif ( $this->is_whitelist() ) {
				remove_filter( 'wp_login_failed', array( $this, 'login_attempts_failed' ) );
				remove_filter( 'wp_authenticate_user', array( $this, 'login_attempts_authenticate_user' ), 99999 );
				remove_filter( 'login_errors', array( $this, 'login_attempts_login_errors' ), 20 );
			}
		}
		return $user;
	}

	public function login_attempts_login_errors( $content ) {
		if ( ! $this->login_attempts_is_show_message() ) {
			return $content;
		}

		if ( ! $this->login_attempts_can_user_login() ) {
			return $this->login_attempts_error_message();
		}

		if ( $this->is_whitelist() ) {
			return $content;
		}

		$remaining = $this->login_attempts_retries_remaining();
		if ( '' !== $remaining ) {
			$content .= '<br>' . sprintf(
				/* translators: %d: remaining attempts */
				__( 'Осталось попыток: <strong>%d</strong>', 'mvweb-site-optimizer' ),
				(int) $remaining
			) . '<br>';
		}

		return $content;
	}

	public function login_attempts_xmlrpc_login_error( $error ) {
		if ( ! class_exists( 'IXR_Error' ) ) {
			return $error;
		}
		if ( ! $this->login_attempts_can_user_login() ) {
			return new IXR_Error( 403, $this->login_attempts_error_message() );
		}
		$remaining = $this->login_attempts_retries_remaining();
		return new IXR_Error(
			403,
			sprintf(
				/* translators: %d: remaining attempts */
				__( 'Осталось попыток: %d', 'mvweb-site-optimizer' ),
				(int) $remaining
			)
		);
	}

	public function login_attempts_xmlrpc_lock() {
		if ( is_user_logged_in() || $this->is_whitelist() ) {
			return;
		}
		if ( $this->is_blacklist() || ! $this->login_attempts_can_user_login() ) {
			status_header( 403, 'Forbidden' );
			exit;
		}
	}

	public function login_attempts_shake_codes( $error_codes ) {
		if ( ! is_array( $error_codes ) ) {
			$error_codes = array();
		}
		$error_codes[] = 'too_many_retries';
		$error_codes[] = 'ip_in_blacklist';
		return $error_codes;
	}

	private function login_attempts_can_user_login(): bool {
		if ( $this->is_whitelist() ) {
			return true;
		}
		$lockouts = get_option( self::OPTION_LOCKOUTS, array() );
		if ( ! is_array( $lockouts ) ) {
			return true;
		}
		foreach ( $this->get_ips() as $ip ) {
			if ( isset( $lockouts[ $ip ] ) && time() < $lockouts[ $ip ] ) {
				return false;
			}
		}
		return true;
	}

	private function login_attempts_retries_remaining() {
		$retries = get_option( self::OPTION_RETRIES, array() );
		if ( ! is_array( $retries ) ) {
			return '';
		}
		$allowed_retries = $this->get_allowed_retries();
		$remainings      = array( 0 );

		foreach ( $this->get_ips() as $ip ) {
			if ( ! isset( $retries[ $ip ] ) || time() > $retries[ $ip ]['valid'] ) {
				return '';
			}
			if ( 0 === $retries[ $ip ]['count'] % $allowed_retries ) {
				return '';
			}
			$remainings[] = max( $allowed_retries - ( $retries[ $ip ]['count'] % $allowed_retries ), 0 );
		}
		return max( $remainings );
	}

	private function login_attempts_is_show_message(): bool {
		if ( isset( $_GET['key'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return false;
		}
		$action = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( (string) $_REQUEST['action'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return ! in_array( $action, array( 'lostpassword', 'retrievepassword', 'resetpass', 'rp', 'register' ), true );
	}

	private function login_attempts_error_message(): string {
		$ips      = $this->get_ips();
		$lockouts = get_option( self::OPTION_LOCKOUTS, array() );

		$msg = __( '<strong>Ошибка</strong>: слишком много неудачных попыток входа.', 'mvweb-site-optimizer' ) . ' ';

		$active_ip = null;
		foreach ( $ips as $ip ) {
			if ( is_array( $lockouts ) && isset( $lockouts[ $ip ] ) && time() < $lockouts[ $ip ] ) {
				$active_ip = $ip;
				break;
			}
		}

		if ( null === $active_ip ) {
			return $msg . __( 'Попробуйте позже.', 'mvweb-site-optimizer' );
		}

		$minutes = (int) ceil( ( $lockouts[ $active_ip ] - time() ) / 60 );
		if ( $minutes > 60 ) {
			$hours = (int) ceil( $minutes / 60 );
			return $msg . sprintf(
				/* translators: %d: hours */
				__( 'Попробуйте через %d ч.', 'mvweb-site-optimizer' ),
				$hours
			);
		}
		return $msg . sprintf(
			/* translators: %d: minutes */
			__( 'Попробуйте через %d мин.', 'mvweb-site-optimizer' ),
			$minutes
		);
	}

	private function login_attempts_clean( $lockouts = null, $retries = null ): void {
		$lockouts = null !== $lockouts ? $lockouts : get_option( self::OPTION_LOCKOUTS, array() );
		$retries  = null !== $retries ? $retries : get_option( self::OPTION_RETRIES, array() );

		if ( is_array( $lockouts ) ) {
			foreach ( $lockouts as $ip => $lockout ) {
				if ( $lockout < time() ) {
					unset( $lockouts[ $ip ] );
				}
			}
			update_option( self::OPTION_LOCKOUTS, $lockouts, false );
		}

		if ( ! is_array( $retries ) ) {
			return;
		}
		foreach ( $retries as $ip => $retry ) {
			if ( $retry['valid'] < time() ) {
				unset( $retries[ $ip ] );
			}
		}
		update_option( self::OPTION_RETRIES, $retries, false );
	}

	private function get_ips(): array {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';

		if ( '' !== $ip && filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return array( 'REMOTE_ADDR' => $ip );
		}

		return array();
	}

	private function is_whitelist( $ips = null ): bool {
		return $this->ip_in_list( 'login_attempts_whitelist', $ips );
	}

	private function is_blacklist( $ips = null ): bool {
		return $this->ip_in_list( 'login_attempts_blacklist', $ips );
	}

	private function ip_in_list( string $option_key, $ips = null ): bool {
		if ( null === $ips ) {
			$ips = $this->get_ips();
		}
		if ( ! is_array( $ips ) ) {
			$ips = array( $ips );
		}

		$raw = (string) mvweb_so_get_option( $option_key, '' );
		if ( '' === $raw ) {
			return false;
		}

		$list = array();
		foreach ( explode( "\n", $raw ) as $line ) {
			$line = trim( $line );
			if ( '' !== $line && filter_var( $line, FILTER_VALIDATE_IP ) ) {
				$list[] = $line;
			}
		}
		if ( empty( $list ) ) {
			return false;
		}

		foreach ( $ips as $ip ) {
			if ( in_array( $ip, $list, true ) ) {
				return true;
			}
		}
		return false;
	}

	private function get_allowed_retries(): int {
		$value = (int) mvweb_so_get_option( 'login_attempts_allowed_retries', self::DEFAULT_ALLOWED_RETRIES );
		return max( 1, $value );
	}

	private function get_allowed_lockouts(): int {
		$value = (int) mvweb_so_get_option( 'login_attempts_allowed_lockouts', self::DEFAULT_ALLOWED_LOCKOUTS );
		return max( 1, $value );
	}

	private function get_lockout_duration(): int {
		$minutes = (int) mvweb_so_get_option( 'login_attempts_lockout_duration', self::DEFAULT_LOCKOUT_DURATION );
		return max( 1, $minutes ) * 60;
	}

	private function get_long_duration(): int {
		$hours = (int) mvweb_so_get_option( 'login_attempts_long_duration', self::DEFAULT_LONG_DURATION );
		return max( 1, $hours ) * HOUR_IN_SECONDS;
	}

	public function redirect_from_http_to_https(): void {
		if ( 'cli' === php_sapi_name() || ( defined( 'WP_CLI' ) && WP_CLI ) ) {
			return;
		}
		if ( is_ssl() ) {
			return;
		}

		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( (string) $_SERVER['REQUEST_URI'] ) : '/';
		$target      = set_url_scheme( home_url( $request_uri ), 'https' );

		wp_safe_redirect( $target, 301 );
		exit;
	}

	public function sanitize( $raw ): array {
		$raw = is_array( $raw ) ? $raw : array();
		$out = array();

		$bool_keys = array(
			'disable_json_rest_api',
			'hide_wp_login',
			'login_attempts',
			'redirect_from_http_to_https',
		);
		foreach ( $bool_keys as $key ) {
			$out[ $key ] = isset( $raw[ $key ] ) && 'on' === $raw[ $key ] ? 'on' : '';
		}

		$slug = isset( $raw['hide_wp_login_new_slug'] ) ? sanitize_title( (string) $raw['hide_wp_login_new_slug'] ) : '';
		$slug = preg_replace( '/[^a-z0-9-]/', '', strtolower( $slug ) );
		$out['hide_wp_login_new_slug'] = (string) $slug;

		$out['login_attempts_allowed_retries']  = $this->sanitize_int( $raw, 'login_attempts_allowed_retries', self::DEFAULT_ALLOWED_RETRIES, 1, 999 );
		$out['login_attempts_allowed_lockouts'] = $this->sanitize_int( $raw, 'login_attempts_allowed_lockouts', self::DEFAULT_ALLOWED_LOCKOUTS, 1, 999 );
		$out['login_attempts_lockout_duration'] = $this->sanitize_int( $raw, 'login_attempts_lockout_duration', self::DEFAULT_LOCKOUT_DURATION, 1, 1440 );
		$out['login_attempts_long_duration']    = $this->sanitize_int( $raw, 'login_attempts_long_duration', self::DEFAULT_LONG_DURATION, 1, 720 );

		$out['login_attempts_whitelist'] = $this->sanitize_ip_list( $raw, 'login_attempts_whitelist' );
		$out['login_attempts_blacklist'] = $this->sanitize_ip_list( $raw, 'login_attempts_blacklist' );

		$session                  = isset( $raw['session_expiration'] ) ? (int) $raw['session_expiration'] : 0;
		$out['session_expiration'] = in_array( $session, self::SESSION_PRESETS, true ) ? $session : 0;

		return $out;
	}

	/**
	 * Filters auth cookie lifetime when "Remember me" is checked.
	 *
	 * Без галочки WP оставляет дефолт (2 дня) — это сохраняет heuristic
	 * в wp_update_user(), которая различает режимы по разнице expiry.
	 *
	 * @param int  $expiration WP default expiration in seconds.
	 * @param int  $user_id    User ID (unused).
	 * @param bool $remember   Whether "Remember me" was checked.
	 */
	public function filter_auth_cookie_expiration( $expiration, $user_id, $remember ) {
		if ( ! $remember ) {
			return $expiration;
		}
		$custom = (int) mvweb_so_get_option( 'session_expiration', 0 );
		return in_array( $custom, self::SESSION_PRESETS, true ) ? $custom : (int) $expiration;
	}

	private function sanitize_int( array $raw, string $key, int $default_value, int $min, int $max ): int {
		$value = isset( $raw[ $key ] ) ? (int) $raw[ $key ] : $default_value;
		if ( $value < $min ) {
			$value = $default_value;
		}
		if ( $value > $max ) {
			$value = $max;
		}
		return $value;
	}

	private function sanitize_ip_list( array $raw, string $key ): string {
		if ( ! isset( $raw[ $key ] ) ) {
			return '';
		}
		$lines = preg_split( '/\r\n|\r|\n/', (string) $raw[ $key ] );
		$out   = array();
		foreach ( (array) $lines as $line ) {
			$line = trim( $line );
			if ( '' !== $line && filter_var( $line, FILTER_VALIDATE_IP ) ) {
				$out[] = $line;
			}
		}
		return implode( "\n", array_unique( $out ) );
	}
}
