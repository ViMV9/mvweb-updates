<?php
/**
 * Modules tab — отключение тяжёлых компонентов ядра WordPress.
 *
 * Phase 6. Комментарии (с подопциями), Gutenberg, классические виджеты,
 * Gravatar, RSS-фиды, admin bar. Имена опций выбраны для совместимости при
 * миграции настроек с аналогичных плагинов оптимизации.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Tab_Modules {

	const ALLOWED_KEYS = array(
		'disable_comments',
		'disable_comments_interface',
		'disable_comments_xml_rpc',
		'disable_comments_rest_api',
		'disable_comments_email_field',
		'disable_comments_save_ip',
		'disable_gutenberg',
		'disable_gutenberg_widgets',
		'disable_gravatar',
		'disable_feed',
		'disable_admin_bar',
	);

	const COMMENTS_SUB_KEYS = array(
		'disable_comments_interface',
		'disable_comments_xml_rpc',
		'disable_comments_rest_api',
		'disable_comments_email_field',
		'disable_comments_save_ip',
	);

	public function __construct() {
		if ( is_admin() ) {
			add_filter( 'mvweb_so_sanitize_modules', array( $this, 'sanitize' ), 10, 1 );
		}

		if ( mvweb_so_check_option( 'disable_comments' ) ) {
			$this->init_disable_comments();
		}

		if ( mvweb_so_check_option( 'disable_gutenberg' ) ) {
			$this->init_disable_gutenberg();
		}

		if ( mvweb_so_check_option( 'disable_gutenberg_widgets' ) ) {
			add_filter( 'use_widgets_block_editor', '__return_false' );
		}

		if ( mvweb_so_check_option( 'disable_gravatar' ) ) {
			add_filter( 'pre_get_avatar_data', array( $this, 'replace_gravatar' ), 10, 2 );
			add_filter( 'avatar_defaults', array( $this, 'register_default_avatar' ) );
		}

		if ( mvweb_so_check_option( 'disable_feed' ) ) {
			$this->init_disable_feed();
		}

		if ( mvweb_so_check_option( 'disable_admin_bar' ) ) {
			add_action( 'init', array( $this, 'disable_admin_bar' ) );
		}
	}

	private function init_disable_comments(): void {
		add_action( 'wp_loaded', array( $this, 'comments_remove_post_type_support' ) );

		if ( mvweb_so_check_option( 'disable_comments_interface' ) ) {
			add_filter( 'rest_endpoints', array( $this, 'comments_remove_rest_endpoints' ) );
			add_action( 'widgets_init', array( $this, 'comments_unregister_widget' ) );
			add_action( 'template_redirect', array( $this, 'comments_block_feed' ), 9 );

			add_action( 'admin_bar_menu', array( $this, 'comments_remove_admin_bar' ), 50 );

			if ( is_admin() ) {
				add_action( 'admin_menu', array( $this, 'comments_remove_admin_menu' ), 9999 );
				add_action(
					'wp_dashboard_setup',
					static function () {
						remove_meta_box( 'dashboard_recent_comments', 'dashboard', 'normal' );
					}
				);
				add_filter( 'pre_option_default_pingback_flag', '__return_zero' );
			} else {
				add_filter( 'feed_links_show_comments_feed', '__return_false' );
			}
		}

		if ( mvweb_so_check_option( 'disable_comments_xml_rpc' ) ) {
			add_filter(
				'xmlrpc_methods',
				static function ( $methods ) {
					if ( is_array( $methods ) ) {
						unset( $methods['wp.newComment'] );
					}
					return $methods;
				}
			);
		}

		if ( mvweb_so_check_option( 'disable_comments_rest_api' ) ) {
			add_filter( 'rest_pre_insert_comment', array( $this, 'comments_block_rest_insert' ), 10, 2 );
		}

		if ( mvweb_so_check_option( 'disable_comments_email_field' ) ) {
			add_filter( 'comment_form_default_fields', array( $this, 'comments_remove_email_field' ) );
		}

		if ( mvweb_so_check_option( 'disable_comments_save_ip' ) ) {
			add_filter( 'pre_comment_user_ip', '__return_empty_string' );
			add_filter( 'pre_comment_user_agent', '__return_empty_string' );
		}
	}

	public function comments_remove_post_type_support(): void {
		foreach ( get_post_types() as $post_type ) {
			if ( post_type_supports( $post_type, 'comments' ) ) {
				remove_post_type_support( $post_type, 'comments' );
				remove_post_type_support( $post_type, 'trackbacks' );
			}
		}

		add_filter( 'comments_array', '__return_empty_array', 20 );
		add_filter( 'comments_open', '__return_false', 20 );
		add_filter( 'pings_open', '__return_false', 20 );
		add_filter( 'get_comments_number', '__return_zero', 20 );
	}

	public function comments_remove_rest_endpoints( $endpoints ) {
		if ( is_array( $endpoints ) ) {
			unset( $endpoints['/wp/v2/comments'] );
			unset( $endpoints['/wp/v2/comments/(?P<id>[\d]+)'] );
		}
		return $endpoints;
	}

	public function comments_unregister_widget(): void {
		unregister_widget( 'WP_Widget_Recent_Comments' );
		add_filter( 'show_recent_comments_widget_style', '__return_false' );
	}

	public function comments_block_feed(): void {
		if ( is_comment_feed() ) {
			wp_die(
				esc_html__( 'Комментарии отключены.', 'mvweb-site-optimizer' ),
				'',
				array( 'response' => 403 )
			);
		}
	}

	public function comments_remove_admin_bar(): void {
		remove_action( 'admin_bar_menu', 'wp_admin_bar_comments_menu', 60 );
	}

	public function comments_remove_admin_menu(): void {
		global $pagenow;

		if ( 'comment.php' === $pagenow || 'edit-comments.php' === $pagenow || 'options-discussion.php' === $pagenow ) {
			wp_die(
				esc_html__( 'Комментарии отключены.', 'mvweb-site-optimizer' ),
				'',
				array( 'response' => 403 )
			);
		}

		remove_menu_page( 'edit-comments.php' );
		remove_submenu_page( 'options-general.php', 'options-discussion.php' );
	}

	public function comments_block_rest_insert( $prepared_comment, $request ) {
		return new WP_Error(
			'mvweb_so_comments_disabled',
			__( 'Комментарии отключены.', 'mvweb-site-optimizer' ),
			array( 'status' => 403 )
		);
	}

	public function comments_remove_email_field( $fields ) {
		if ( is_array( $fields ) ) {
			unset( $fields['email'] );
		}
		return $fields;
	}

	private function init_disable_gutenberg(): void {
		add_filter( 'use_block_editor_for_post_type', '__return_false', 100 );
		add_filter( 'gutenberg_can_edit_post_type', '__return_false', 100 );

		add_action( 'wp_enqueue_scripts', array( $this, 'gutenberg_dequeue_block_library' ), 100 );
		add_action( 'admin_enqueue_scripts', array( $this, 'gutenberg_dequeue_block_library' ), 100 );

		add_action(
			'admin_init',
			static function () {
				if ( class_exists( 'WP_Privacy_Policy_Content' ) ) {
					remove_action( 'admin_notices', array( 'WP_Privacy_Policy_Content', 'notice' ) );
					add_action( 'edit_form_after_title', array( 'WP_Privacy_Policy_Content', 'notice' ) );
				}
			}
		);
	}

	public function gutenberg_dequeue_block_library(): void {
		wp_dequeue_style( 'wp-block-library' );
		wp_dequeue_style( 'wp-block-library-theme' );
		wp_dequeue_style( 'global-styles' );
		wp_dequeue_style( 'classic-theme-styles' );

		remove_action( 'wp_enqueue_scripts', 'wp_enqueue_global_styles' );
		remove_action( 'wp_footer', 'wp_enqueue_global_styles', 1 );
	}

	public function replace_gravatar( $args, $id_or_email ) {
		if ( ! is_array( $args ) ) {
			return $args;
		}

		$args['url']          = $this->get_default_avatar_url();
		$args['found_avatar'] = true;

		return $args;
	}

	public function register_default_avatar( $avatar_defaults ) {
		if ( is_array( $avatar_defaults ) ) {
			$avatar_defaults[ $this->get_default_avatar_url() ] = __( 'MVweb Site Optimizer (локальный)', 'mvweb-site-optimizer' );
		}
		return $avatar_defaults;
	}

	private function get_default_avatar_url(): string {
		return MVWEB_SO_URL . 'images/default-avatar.png';
	}

	private function init_disable_feed(): void {
		remove_action( 'wp_head', 'feed_links', 2 );
		remove_action( 'wp_head', 'feed_links_extra', 3 );

		add_action( 'do_feed', array( $this, 'disable_feed_die' ), 1 );
		add_action( 'do_feed_rdf', array( $this, 'disable_feed_die' ), 1 );
		add_action( 'do_feed_rss', array( $this, 'disable_feed_die' ), 1 );
		add_action( 'do_feed_rss2', array( $this, 'disable_feed_die' ), 1 );
		add_action( 'do_feed_atom', array( $this, 'disable_feed_die' ), 1 );
		add_action( 'do_feed_rss2_comments', array( $this, 'disable_feed_die' ), 1 );
		add_action( 'do_feed_atom_comments', array( $this, 'disable_feed_die' ), 1 );
	}

	public function disable_feed_die(): void {
		$home = home_url( '/' );

		wp_safe_redirect( $home, 301 );
		exit;
	}

	public function disable_admin_bar(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			add_filter( 'show_admin_bar', '__return_false' );
		}
	}

	public function sanitize( $raw ): array {
		$raw = is_array( $raw ) ? $raw : array();
		$out = array();

		foreach ( self::ALLOWED_KEYS as $key ) {
			$out[ $key ] = isset( $raw[ $key ] ) && 'on' === $raw[ $key ] ? 'on' : '';
		}

		if ( 'on' !== $out['disable_comments'] ) {
			foreach ( self::COMMENTS_SUB_KEYS as $sub_key ) {
				$out[ $sub_key ] = '';
			}
		}

		return $out;
	}
}
