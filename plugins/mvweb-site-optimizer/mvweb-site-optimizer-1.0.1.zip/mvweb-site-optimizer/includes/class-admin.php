<?php
/**
 * Admin orchestrator for MVweb Site Optimizer.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Admin {

	public function settings_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		require MVWEB_SO_PATH . 'admin/views/settings-page.php';
	}

	public static function current_tab(): string {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( (string) $_GET['tab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$allowed = self::tabs();
		return isset( $allowed[ $tab ] ) ? $tab : 'general';
	}

	public static function tabs(): array {
		return array(
			'general'      => __( 'General', 'mvweb-site-optimizer' ),
			'code'         => __( 'Code', 'mvweb-site-optimizer' ),
			'seo'          => __( 'SEO', 'mvweb-site-optimizer' ),
			'duplicate'    => __( 'Duplicate', 'mvweb-site-optimizer' ),
			'security'     => __( 'Security', 'mvweb-site-optimizer' ),
			'modules'      => __( 'Modules', 'mvweb-site-optimizer' ),
			'additionally' => __( 'Additionally', 'mvweb-site-optimizer' ),
			'redirect'     => __( 'Redirect', 'mvweb-site-optimizer' ),
			'indexnow'     => __( 'IndexNow', 'mvweb-site-optimizer' ),
			'maintenance'  => __( 'Maintenance', 'mvweb-site-optimizer' ),
			'help'         => __( 'Help', 'mvweb-site-optimizer' ),
		);
	}

	public static function tab_url( string $tab ): string {
		return add_query_arg(
			array(
				'page' => 'mvweb-site-optimizer',
				'tab'  => $tab,
			),
			admin_url( 'admin.php' )
		);
	}
}
