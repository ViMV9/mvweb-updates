<?php
/**
 * Settings handler for MVweb Site Optimizer.
 *
 * Single POST handler shared across all tabs. Each phase adds its
 * sanitize block via `mvweb_so_sanitize_{tab}` filter, so we don't
 * have to edit a central switch on every new tab.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Settings {

	public function maybe_handle_save(): void {
		if ( ! isset( $_POST['mvweb_so_save'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		check_admin_referer( 'mvweb_so_settings', 'mvweb_so_nonce' );

		$tab = isset( $_POST['mvweb_so_tab'] ) ? sanitize_key( wp_unslash( (string) $_POST['mvweb_so_tab'] ) ) : 'general';

		$raw = isset( $_POST['mvweb_so'] ) && is_array( $_POST['mvweb_so'] )
			? wp_unslash( $_POST['mvweb_so'] ) // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			: array();

		/**
		 * Filter raw POSTed values for a tab before saving.
		 *
		 * Each tab module hooks here to sanitize its own fields:
		 *   add_filter( 'mvweb_so_sanitize_code', [ $this, 'sanitize' ] );
		 *
		 * @param array  $raw Raw $_POST['mvweb_so'] array.
		 * @param string $tab Current tab slug.
		 * @return array Sanitized key=>value pairs to merge into settings.
		 */
		$sanitized = apply_filters( 'mvweb_so_sanitize_' . $tab, $raw, $tab );
		$sanitized = apply_filters( 'mvweb_so_sanitize', $sanitized, $tab );

		if ( ! is_array( $sanitized ) ) {
			$sanitized = array();
		}

		$settings = mvweb_so_get_settings();

		// Merge: a tab may submit either explicit replacement or partial updates.
		foreach ( $sanitized as $key => $value ) {
			if ( null === $value ) {
				unset( $settings[ $key ] );
			} else {
				$settings[ $key ] = $value;
			}
		}

		update_option( MVWEB_SO_OPTION, $settings, false );

		set_transient( $this->saved_flag_key(), '1', MINUTE_IN_SECONDS );

		wp_safe_redirect(
			add_query_arg(
				array(
					'page' => 'mvweb-site-optimizer',
					'tab'  => $tab,
				),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	public function maybe_render_saved_notice(): void {
		if ( get_transient( $this->saved_flag_key() ) ) {
			delete_transient( $this->saved_flag_key() );
			echo '<div class="mvweb-alert mvweb-alert--success"><div class="mvweb-alert__body">' .
				esc_html__( 'Настройки сохранены.', 'mvweb-site-optimizer' ) .
				'</div></div>';
		}
	}

	private function saved_flag_key(): string {
		return 'mvweb_so_saved_' . get_current_user_id();
	}
}
