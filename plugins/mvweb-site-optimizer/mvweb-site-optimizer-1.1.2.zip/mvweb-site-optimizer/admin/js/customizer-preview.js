/**
 * MVweb Site Optimizer — Customizer preview updates only on the "Refresh" button.
 *
 * @package mvweb_so
 */

( function ( api, $, l10n ) {
	'use strict';

	if ( ! api || ! api.Setting || ! l10n ) {
		return;
	}

	var pending = new api.Value( false );

	api.Setting.prototype.preview = function () {
		pending.set( true );
	};

	api.bind( 'ready', function () {
		var button = $( '<button type="button" class="button button-compact mvweb-so-cz-refresh"></button>' )
			.text( l10n.refresh )
			.attr( 'title', l10n.title );

		button.on( 'click', function () {
			pending.set( false );
			api.previewer.refresh();
		} );

		pending.bind( function ( isPending ) {
			button.toggleClass( 'is-pending', isPending );
			button.attr( 'title', isPending ? l10n.pendingTitle : l10n.title );
		} );

		$( '#customize-save-button-wrapper' ).after( button );
	} );
}( window.wp && window.wp.customize, window.jQuery, window.mvwebSoCustomizerPreview ) );
