<?php
/**
 * Additionally tab — комплекс мелких настроек чистки <head>/<body> и поведения админки.
 *
 * Phase 7. Кастомные сниппеты, чистка head, ревизии, заголовки кеширования,
 * cookie-баннер, passive listeners, виджеты. Имена опций выбраны для
 * совместимости при миграции настроек с аналогичных плагинов оптимизации.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Tab_Additionally {

	const BOOLEAN_KEYS = array(
		'change_login_errors',
		'message_cookie',
		'disable_admin_bar',
		'remove_unnecessary_link_admin_bar',
		'remove_unneeded_widget_page',
		'remove_unneeded_widget_calendar',
		'remove_unneeded_widget_tag_cloud',
		'remove_unneeded_widget_archives',
		'remove_unneeded_widget_meta',
		'remove_unneeded_widget_rss',
		'disable_email_notification',
		'revisions_disable',
		'set_last_modified_headers',
		'if_modified_since_headers',
		'passive_listeners',
		'remove_meta_generator',
		'remove_dns_prefetch',
		'remove_rsd_link',
		'remove_adjacent_posts_link',
		'remove_shortlink_link',
		'remove_x_pingback',
		'remove_url_from_comment_form',
		'customizer_manual_preview',
	);

	const TEXT_KEYS = array(
		'insert_code_in_head',
		'insert_code_in_body',
		'message_cookie_text',
		'message_cookie_button',
		'change_login_errors_text',
	);

	const INT_KEYS = array(
		'revision_limit',
	);

	// Объединённый список для MVweb_SO_Settings::collect_allowed_keys() — все ключи,
	// которые этот таб умеет сохранять. Whitelist intersect_key в save-обработчике опирается на ALLOWED_KEYS.
	const ALLOWED_KEYS = array(
		'change_login_errors',
		'change_login_errors_text',
		'message_cookie',
		'message_cookie_text',
		'message_cookie_button',
		'disable_admin_bar',
		'remove_unnecessary_link_admin_bar',
		'remove_unneeded_widget_page',
		'remove_unneeded_widget_calendar',
		'remove_unneeded_widget_tag_cloud',
		'remove_unneeded_widget_archives',
		'remove_unneeded_widget_meta',
		'remove_unneeded_widget_rss',
		'disable_email_notification',
		'revisions_disable',
		'revision_limit',
		'set_last_modified_headers',
		'if_modified_since_headers',
		'passive_listeners',
		'remove_meta_generator',
		'remove_dns_prefetch',
		'remove_rsd_link',
		'remove_adjacent_posts_link',
		'remove_shortlink_link',
		'remove_x_pingback',
		'remove_url_from_comment_form',
		'customizer_manual_preview',
		'insert_code_in_head',
		'insert_code_in_body',
	);

	public function __construct() {
		if ( is_admin() ) {
			add_filter( 'mvweb_so_sanitize_additionally', array( $this, 'sanitize' ), 10, 2 );
		}

		if ( '' !== (string) mvweb_so_get_option( 'insert_code_in_head', '' ) ) {
			add_action( 'wp_head', array( $this, 'output_code_in_head' ), 999 );
		}

		if ( '' !== (string) mvweb_so_get_option( 'insert_code_in_body', '' ) ) {
			add_action( 'wp_footer', array( $this, 'output_code_in_body' ), 999 );
		}

		if ( mvweb_so_check_option( 'change_login_errors' ) ) {
			add_filter( 'login_errors', array( $this, 'filter_login_errors' ) );
		}

		if ( mvweb_so_check_option( 'message_cookie' ) ) {
			add_action( 'wp_footer', array( $this, 'output_cookie_notice' ), 999 );
		}

		if ( mvweb_so_check_option( 'disable_admin_bar' ) ) {
			add_action( 'init', array( $this, 'disable_admin_bar' ) );
		}

		if ( mvweb_so_check_option( 'remove_unnecessary_link_admin_bar' ) ) {
			add_action( 'admin_bar_menu', array( $this, 'cleanup_admin_bar' ), 999 );
		}

		if ( mvweb_so_check_option( 'remove_unneeded_widget_page' )
			|| mvweb_so_check_option( 'remove_unneeded_widget_calendar' )
			|| mvweb_so_check_option( 'remove_unneeded_widget_tag_cloud' )
			|| mvweb_so_check_option( 'remove_unneeded_widget_archives' )
			|| mvweb_so_check_option( 'remove_unneeded_widget_meta' )
			|| mvweb_so_check_option( 'remove_unneeded_widget_rss' ) ) {
			add_action( 'widgets_init', array( $this, 'unregister_default_widgets' ), 99 );
		}

		if ( mvweb_so_check_option( 'disable_email_notification' ) ) {
			$this->init_disable_email_notifications();
		}

		if ( mvweb_so_check_option( 'revisions_disable' ) ) {
			add_filter( 'wp_revisions_to_keep', array( $this, 'force_zero_revisions' ), 10, 2 );
		} elseif ( (int) mvweb_so_get_option( 'revision_limit', 0 ) > 0 ) {
			add_filter( 'wp_revisions_to_keep', array( $this, 'limit_revisions' ), 10, 2 );
		}

		if ( mvweb_so_check_option( 'set_last_modified_headers' ) ) {
			add_action( 'template_redirect', array( $this, 'send_last_modified_headers' ), 99 );
		}

		if ( mvweb_so_check_option( 'if_modified_since_headers' ) ) {
			add_action( 'template_redirect', array( $this, 'check_if_modified_since' ), 100 );
		}

		if ( mvweb_so_check_option( 'passive_listeners' ) ) {
			add_action( 'wp_print_footer_scripts', array( $this, 'output_passive_listeners' ), 1 );
		}

		if ( mvweb_so_check_option( 'remove_meta_generator' ) ) {
			remove_action( 'wp_head', 'wp_generator' );
			add_filter( 'the_generator', '__return_empty_string' );
		}

		if ( mvweb_so_check_option( 'remove_dns_prefetch' ) ) {
			add_filter( 'wp_resource_hints', array( $this, 'strip_dns_prefetch' ), 10, 2 );
		}

		if ( mvweb_so_check_option( 'remove_rsd_link' ) ) {
			remove_action( 'wp_head', 'rsd_link' );
		}

		if ( mvweb_so_check_option( 'remove_adjacent_posts_link' ) ) {
			remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10 );
		}

		if ( mvweb_so_check_option( 'remove_shortlink_link' ) ) {
			remove_action( 'wp_head', 'wp_shortlink_wp_head', 10 );
			remove_action( 'template_redirect', 'wp_shortlink_header', 11 );
		}

		if ( mvweb_so_check_option( 'remove_x_pingback' ) ) {
			add_filter( 'wp_headers', array( $this, 'strip_x_pingback_header' ) );
			add_filter( 'xmlrpc_enabled', '__return_false' );
			add_filter( 'pings_open', '__return_false', PHP_INT_MAX );
			add_filter( 'xmlrpc_methods', array( $this, 'disable_xmlrpc_methods' ) );
			add_filter( 'bloginfo_url', array( $this, 'strip_pingback_url' ), 10, 2 );
		}

		if ( mvweb_so_check_option( 'remove_url_from_comment_form' ) ) {
			add_filter( 'comment_form_default_fields', array( $this, 'remove_url_field' ) );
		}

		if ( mvweb_so_check_option( 'customizer_manual_preview' ) ) {
			add_action( 'customize_controls_enqueue_scripts', array( $this, 'enqueue_customizer_manual_preview' ) );
		}
	}

	public function enqueue_customizer_manual_preview(): void {
		$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
		$path   = 'admin/js/customizer-preview' . $suffix . '.js';
		$mtime  = @filemtime( MVWEB_SO_PATH . $path );

		wp_enqueue_script(
			'mvweb-so-customizer-preview',
			MVWEB_SO_URL . $path,
			array( 'customize-controls' ),
			$mtime ? (string) $mtime : MVWEB_SO_VERSION,
			true
		);

		wp_localize_script(
			'mvweb-so-customizer-preview',
			'mvwebSoCustomizerPreview',
			array(
				'refresh'      => __( 'Обновить', 'mvweb-site-optimizer' ),
				'title'        => __( 'Обновить превью', 'mvweb-site-optimizer' ),
				'pendingTitle' => __( 'Есть изменения, которых нет в превью. Нажмите, чтобы обновить.', 'mvweb-site-optimizer' ),
			)
		);

		wp_add_inline_style(
			'customize-controls',
			'#customize-header-actions .mvweb-so-cz-refresh{float:right;margin:7px 6px 0 0}#customize-header-actions .mvweb-so-cz-refresh.is-pending{border-color:#2271b1;color:#2271b1;box-shadow:inset 0 0 0 1px #2271b1}'
		);
	}

	public function output_code_in_head(): void {
		echo "\n" . (string) mvweb_so_get_option( 'insert_code_in_head', '' ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- intentional raw output stored by manage_options user.
	}

	public function output_code_in_body(): void {
		echo "\n" . (string) mvweb_so_get_option( 'insert_code_in_body', '' ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- intentional raw output stored by manage_options user.
	}

	public function filter_login_errors( $errors ) {
		$custom = trim( (string) mvweb_so_get_option( 'change_login_errors_text', '' ) );

		if ( '' === $custom ) {
			$custom = __( 'Неверные данные для входа.', 'mvweb-site-optimizer' );
		}

		return esc_html( $custom );
	}

	public function output_cookie_notice(): void {
		$text   = trim( (string) mvweb_so_get_option( 'message_cookie_text', '' ) );
		$button = trim( (string) mvweb_so_get_option( 'message_cookie_button', '' ) );

		if ( '' === $text ) {
			$text = __( 'Мы используем cookie для корректной работы сайта и аналитики посещаемости. Продолжая пользоваться сайтом, вы соглашаетесь с этим.', 'mvweb-site-optimizer' );
		}

		if ( '' === $button ) {
			$button = __( 'Принять', 'mvweb-site-optimizer' );
		}
		?>
		<style id="mvweb-so-cookie-notice-style">
			#mvweb-so-cookie-notice{position:fixed;left:0;right:0;bottom:0;z-index:99999;background:#14161b;color:#fff;padding:14px 20px;display:flex;gap:16px;align-items:center;justify-content:space-between;flex-wrap:wrap;font:14px/1.45 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;box-shadow:0 -2px 18px rgba(0,0,0,.18)}
			#mvweb-so-cookie-notice p{margin:0;flex:1 1 320px}
			#mvweb-so-cookie-notice button{background:#793ea4;color:#fff;border:0;border-radius:6px;padding:9px 18px;font-size:14px;cursor:pointer;flex:0 0 auto}
			#mvweb-so-cookie-notice button:hover{background:#5d2c81}
		</style>
		<div id="mvweb-so-cookie-notice" role="dialog" aria-live="polite" hidden>
			<p><?php echo esc_html( $text ); ?></p>
			<button type="button" id="mvweb-so-cookie-accept"><?php echo esc_html( $button ); ?></button>
		</div>
		<script id="mvweb-so-cookie-notice-script">
			(function(){
				var KEY='mvweb_so_cookie_ok';
				var el=document.getElementById('mvweb-so-cookie-notice');
				var btn=document.getElementById('mvweb-so-cookie-accept');
				if(!el||!btn){return;}
				try{
					if(localStorage.getItem(KEY)==='1'){el.parentNode.removeChild(el);return;}
				}catch(e){}
				el.hidden=false;
				btn.addEventListener('click',function(){
					try{localStorage.setItem(KEY,'1');}catch(e){}
					var d=new Date();d.setTime(d.getTime()+365*24*60*60*1000);
					document.cookie=KEY+'=1; expires='+d.toUTCString()+'; path=/; SameSite=Lax';
					el.parentNode.removeChild(el);
				});
			})();
		</script>
		<?php
	}

	public function disable_admin_bar(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			add_filter( 'show_admin_bar', '__return_false' );
		}
	}

	public function cleanup_admin_bar( $wp_admin_bar ): void {
		if ( ! is_object( $wp_admin_bar ) || ! method_exists( $wp_admin_bar, 'remove_node' ) ) {
			return;
		}

		$wp_admin_bar->remove_node( 'wp-logo' );
		$wp_admin_bar->remove_node( 'about' );
		$wp_admin_bar->remove_node( 'wporg' );
		$wp_admin_bar->remove_node( 'documentation' );
		$wp_admin_bar->remove_node( 'support-forums' );
		$wp_admin_bar->remove_node( 'feedback' );
		$wp_admin_bar->remove_node( 'view-site' );
	}

	public function unregister_default_widgets(): void {
		if ( mvweb_so_check_option( 'remove_unneeded_widget_page' ) ) {
			unregister_widget( 'WP_Widget_Pages' );
		}
		if ( mvweb_so_check_option( 'remove_unneeded_widget_calendar' ) ) {
			unregister_widget( 'WP_Widget_Calendar' );
		}
		if ( mvweb_so_check_option( 'remove_unneeded_widget_tag_cloud' ) ) {
			unregister_widget( 'WP_Widget_Tag_Cloud' );
		}
		if ( mvweb_so_check_option( 'remove_unneeded_widget_archives' ) ) {
			unregister_widget( 'WP_Widget_Archives' );
		}
		if ( mvweb_so_check_option( 'remove_unneeded_widget_meta' ) ) {
			unregister_widget( 'WP_Widget_Meta' );
		}
		if ( mvweb_so_check_option( 'remove_unneeded_widget_rss' ) ) {
			unregister_widget( 'WP_Widget_RSS' );
		}
	}

	private function init_disable_email_notifications(): void {
		add_filter( 'auto_core_update_send_email', '__return_false' );
		add_filter( 'auto_plugin_update_send_email', '__return_false' );
		add_filter( 'auto_theme_update_send_email', '__return_false' );
		add_filter( 'send_core_update_notification_email', '__return_false' );
		add_filter( 'automatic_updates_send_debug_email', '__return_false' );
	}

	public function force_zero_revisions( $num, $post = null ) {
		return 0;
	}

	public function limit_revisions( $num, $post = null ) {
		$limit = (int) mvweb_so_get_option( 'revision_limit', 0 );

		if ( $limit <= 0 ) {
			return $num;
		}

		return $limit;
	}

	public function send_last_modified_headers(): void {
		$timestamp = $this->resolve_last_modified_timestamp();

		if ( ! $timestamp ) {
			return;
		}

		header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s', $timestamp ) . ' GMT' );
	}

	public function check_if_modified_since(): void {
		if ( empty( $_SERVER['HTTP_IF_MODIFIED_SINCE'] ) ) {
			return;
		}

		$post_timestamp = $this->resolve_last_modified_timestamp();

		if ( ! $post_timestamp ) {
			return;
		}

		$client_header = sanitize_text_field( wp_unslash( (string) $_SERVER['HTTP_IF_MODIFIED_SINCE'] ) );
		$client_time   = strtotime( $client_header );

		if ( ! $client_time ) {
			return;
		}

		if ( $client_time > time() ) {
			return;
		}

		if ( $post_timestamp <= $client_time ) {
			status_header( 304 );
			header( 'Last-Modified: ' . gmdate( 'D, d M Y H:i:s', $post_timestamp ) . ' GMT' );
			header( 'Cache-Control: private, must-revalidate' );
			exit;
		}
	}

	private function resolve_last_modified_timestamp() {
		if ( is_admin() || is_user_logged_in() ) {
			return 0;
		}

		if ( is_404() || is_search() || is_feed() || is_preview() ) {
			return 0;
		}

		if ( function_exists( 'is_cart' ) && ( is_cart() || is_checkout() ) ) {
			return 0;
		}

		if ( function_exists( 'is_account_page' ) && is_account_page() ) {
			return 0;
		}

		if ( is_singular() ) {
			$timestamp = $this->singular_timestamp();
		} elseif ( is_post_type_archive() || is_category() || is_tag() || is_tax() || is_author() || is_date() || is_home() || is_front_page() ) {
			$timestamp = $this->archive_timestamp();
		} else {
			return 0;
		}

		return $timestamp ? $timestamp : 0;
	}

	private function singular_timestamp(): int {
		$post = get_queried_object();

		if ( ! $post instanceof WP_Post ) {
			return 0;
		}

		$timestamp = $this->parse_gmt_datetime( (string) $post->post_modified_gmt );

		if ( ! $timestamp ) {
			return 0;
		}

		if ( (int) $post->comment_count > 0 ) {
			$comments = get_comments(
				array(
					'post_id' => $post->ID,
					'number'  => 1,
					'status'  => 'approve',
					'orderby' => 'comment_date_gmt',
					'order'   => 'DESC',
				)
			);

			if ( ! empty( $comments[0]->comment_date_gmt ) ) {
				$comment_ts = $this->parse_gmt_datetime( (string) $comments[0]->comment_date_gmt );
				if ( $comment_ts > $timestamp ) {
					$timestamp = $comment_ts;
				}
			}
		}

		return $timestamp;
	}

	private function archive_timestamp(): int {
		global $wp_query;

		if ( $wp_query instanceof WP_Query && ! empty( $wp_query->posts ) ) {
			$max = 0;
			foreach ( $wp_query->posts as $item ) {
				if ( ! isset( $item->post_modified_gmt ) ) {
					continue;
				}
				$ts = $this->parse_gmt_datetime( (string) $item->post_modified_gmt );
				if ( $ts > $max ) {
					$max = $ts;
				}
			}
			if ( $max > 0 ) {
				return $max;
			}
		}

		$post_type = 'post';
		if ( is_post_type_archive() ) {
			$queried = get_query_var( 'post_type' );
			if ( is_array( $queried ) ) {
				$queried = reset( $queried );
			}
			if ( $queried ) {
				$post_type = (string) $queried;
			}
		}

		$last = get_lastpostmodified( 'GMT', $post_type );

		return $last ? $this->parse_gmt_datetime( (string) $last ) : 0;
	}

	private function parse_gmt_datetime( string $datetime ): int {
		if ( '' === $datetime || '0000-00-00 00:00:00' === $datetime ) {
			return 0;
		}

		$ts = strtotime( $datetime . ' GMT' );

		return $ts ? (int) $ts : 0;
	}

	public function output_passive_listeners(): void {
		echo "<script id=\"mvweb-so-passive-listeners\">\n(function(){var EVT={passive:true};var P=EventTarget.prototype;var add=P.addEventListener;P.addEventListener=function(type,fn,opts){if(type==='touchstart'||type==='touchmove'||type==='wheel'||type==='mousewheel'){if(typeof opts!=='object'||opts===null){opts={};}if(opts.passive===undefined){opts.passive=true;}}return add.call(this,type,fn,opts);};})();\n</script>\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded JS literal.
	}


	public function strip_dns_prefetch( $urls, $relation_type ) {
		if ( 'dns-prefetch' === $relation_type ) {
			return array();
		}

		return $urls;
	}

	public function strip_x_pingback_header( $headers ) {
		if ( is_array( $headers ) && isset( $headers['X-Pingback'] ) ) {
			unset( $headers['X-Pingback'] );
		}
		return $headers;
	}

	public function disable_xmlrpc_methods( $methods ) {
		return is_array( $methods ) ? array() : $methods;
	}

	public function strip_pingback_url( $output, $show ) {
		if ( 'pingback_url' === $show ) {
			return '';
		}
		return $output;
	}

	public function remove_url_field( $fields ) {
		if ( is_array( $fields ) ) {
			unset( $fields['url'] );
		}
		return $fields;
	}

	public function sanitize( $accum, $raw ): array {
		$raw = is_array( $raw ) ? $raw : array();
		$out = array();

		foreach ( self::BOOLEAN_KEYS as $key ) {
			$out[ $key ] = isset( $raw[ $key ] ) && 'on' === $raw[ $key ] ? 'on' : '';
		}

		foreach ( self::TEXT_KEYS as $key ) {
			if ( ! isset( $raw[ $key ] ) ) {
				$out[ $key ] = '';
				continue;
			}

			$value = (string) $raw[ $key ];

			if ( 'insert_code_in_head' === $key || 'insert_code_in_body' === $key ) {
				$out[ $key ] = $this->sanitize_code_snippet( $value );
			} else {
				$out[ $key ] = sanitize_text_field( $value );
			}
		}

		foreach ( self::INT_KEYS as $key ) {
			$value         = isset( $raw[ $key ] ) ? (int) $raw[ $key ] : 0;
			$out[ $key ]   = max( 0, min( 999, $value ) );
		}

		return $out;
	}

	private function sanitize_code_snippet( string $value ): string {
		// Capability `manage_options` уже проверена в MVweb_SO_Settings::maybe_handle_save()
		// до вызова sanitize-фильтров. Однако на multisite даже site-admin без
		// `unfiltered_html` не должен мочь сохранить произвольный HTML/JS — это
		// обходило бы стандартный multisite-фильтр. Если пользователь не имеет
		// `unfiltered_html`, прогоняем через wp_kses_post() (ядровый фильтр,
		// тот же, что WP применяет к контенту постов).
		$value = (string) wp_check_invalid_utf8( $value );
		$value = preg_replace( '/\r\n?/', "\n", $value );
		$value = trim( (string) $value );

		if ( ! current_user_can( 'unfiltered_html' ) ) {
			$value = wp_kses_post( $value );
		}

		return $value;
	}
}
