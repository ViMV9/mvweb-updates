<?php
/**
 * Uninstall MVweb Site Optimizer.
 *
 * Fired when the plugin is removed (not deactivated). Removes all
 * plugin options from wp_options on both single-site and multisite.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$options = array(
	'mvweb_so_settings',
	'mvweb_so_redirects',
	'mvweb_so_indexnow_key',
	'mvweb_so_indexnow_log',
	'mvweb_so_indexnow_queue',
	'mvweb_so_login_attempts_state',
	'mvweb_so_login_attempts_lockouts',
	'mvweb_so_login_attempts_retries',
	'mvweb_so_login_attempts_total',
);

$cleanup = static function () use ( $options ) {
	foreach ( $options as $option ) {
		delete_option( $option );
	}
	delete_transient( 'mvweb_so_indexnow_debounce' );
	delete_transient( 'mvweb_so_sitemap_url' );
	wp_clear_scheduled_hook( 'mvweb_so_indexnow_dispatch' );
	wp_clear_scheduled_hook( 'mvweb_so_login_attempts_cleanup' );
};

$cleanup();

if ( is_multisite() ) {
	$sites = get_sites( array( 'fields' => 'ids' ) );
	foreach ( $sites as $blog_id ) {
		switch_to_blog( (int) $blog_id );
		try {
			$cleanup();
		} finally {
			restore_current_blog();
		}
	}
}

wp_cache_flush();
