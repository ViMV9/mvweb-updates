<?php
/**
 * Maintenance tab — режим обслуживания сайта (HTTP 503 + страница-заглушка).
 *
 * Phase 10. Главный toggle, заголовок, текст, Retry-After и whitelist IP.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$maintenance_enabled     = mvweb_so_check_option( 'maintenance_enabled' );
$maintenance_title       = (string) mvweb_so_get_option( 'maintenance_title', '' );
$maintenance_text        = (string) mvweb_so_get_option( 'maintenance_text', '' );
$maintenance_retry_after = (int) mvweb_so_get_option( 'maintenance_retry_after', 3600 );
$maintenance_whitelist   = (string) mvweb_so_get_option( 'maintenance_whitelist', '' );

if ( $maintenance_retry_after < 1 ) {
	$maintenance_retry_after = 3600;
}
?>

<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Режим обслуживания', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Временно закрывает сайт для посетителей с ответом HTTP 503 Service Unavailable. Администраторы (manage_options) и IP из белого списка продолжают видеть сайт как обычно.', 'mvweb-site-optimizer' ); ?></p>

		<?php if ( $maintenance_enabled ) : ?>
			<div class="mvweb-alert mvweb-alert--warning">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="20" height="20" aria-hidden="true"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
				<div class="mvweb-alert__body">
					<p class="mvweb-alert__title"><?php esc_html_e( 'Режим обслуживания включён', 'mvweb-site-optimizer' ); ?></p>
					<p><?php esc_html_e( 'Анонимные посетители получают страницу-заглушку и HTTP 503. Не забудьте выключить переключатель после окончания работ.', 'mvweb-site-optimizer' ); ?></p>
				</div>
			</div>
		<?php else : ?>
			<div class="mvweb-alert mvweb-alert--info">
				<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="20" height="20" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
				<div class="mvweb-alert__body">
					<p><?php esc_html_e( 'Режим выключен. Сайт работает в штатном режиме.', 'mvweb-site-optimizer' ); ?></p>
				</div>
			</div>
		<?php endif; ?>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-maintenance-enabled">
				<?php esc_html_e( 'Включить режим обслуживания', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-maintenance-enabled"
							name="mvweb_so[maintenance_enabled]"
							value="on"
							<?php checked( $maintenance_enabled ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Отдаёт страницу-заглушку с кодом 503 всем посетителям, кроме админов и IP из белого списка. Поисковики увидят 503 и Retry-After — это правильный сигнал, при котором страницы не выпадают из индекса.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Страница-заглушка', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Заголовок и текст, которые увидят посетители. Если оставить поля пустыми — используются стандартные значения.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-maintenance-title">
				<?php esc_html_e( 'Заголовок страницы', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
						id="mvweb-so-maintenance-title"
						name="mvweb_so[maintenance_title]"
						class="mvweb-input"
						value="<?php echo esc_attr( $maintenance_title ); ?>"
						placeholder="<?php esc_attr_e( 'Сайт на техническом обслуживании', 'mvweb-site-optimizer' ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Большой заголовок над текстом. Также подставляется в <title> страницы.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-maintenance-text">
				<?php esc_html_e( 'Текст сообщения', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-so-maintenance-text"
							name="mvweb_so[maintenance_text]"
							class="mvweb-textarea"
							rows="4"
							placeholder="<?php esc_attr_e( 'Мы скоро вернёмся. Ведутся плановые работы, пожалуйста, загляните позже.', 'mvweb-site-optimizer' ); ?>"><?php echo esc_textarea( $maintenance_text ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Простой текст. HTML вырезается, переносы строк сохраняются.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-maintenance-retry-after">
				<?php esc_html_e( 'Retry-After (сек.)', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
						id="mvweb-so-maintenance-retry-after"
						name="mvweb_so[maintenance_retry_after]"
						class="mvweb-input"
						min="1"
						max="86400"
						step="60"
						value="<?php echo esc_attr( (string) $maintenance_retry_after ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Заголовок Retry-After подсказывает поисковикам и браузерам, через сколько секунд имеет смысл вернуться. По умолчанию — 3600 (1 час). Максимум — 86400 (24 часа).', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Белый список IP', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Посетители с этих IP-адресов видят сайт как обычно, минуя заглушку. Удобно для проверки работы перед открытием.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-maintenance-whitelist">
				<?php esc_html_e( 'Доверенные IP', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-so-maintenance-whitelist"
							name="mvweb_so[maintenance_whitelist]"
							class="mvweb-textarea"
							rows="4"
							placeholder="192.168.1.10&#10;203.0.113.5"><?php echo esc_textarea( $maintenance_whitelist ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Один IP в строке. Поддерживаются IPv4 и IPv6, точное совпадение. CIDR-нотация (например 192.168.1.0/24) и диапазоны не поддерживаются. Не-валидные строки игнорируются при сохранении.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>
