<?php
/**
 * Duplicate tab — защита от дублирующего контента.
 *
 * Phase 4. Шесть переключателей: пагинация одиночных записей, attachment-страницы,
 * архивы автора/даты/тега и author-параметр в URL.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Защита от дублей', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Одна и та же запись доступна сразу по нескольким адресам — по дате, по автору, по метке, через страницу-вложение. Для поисковика это дубликаты, они снижают позиции и расходуют краулинговый бюджет. Закройте лишние варианты — пусть в индексе останутся только нужные страницы.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-single-pagination-duplicate">
				<?php esc_html_e( 'Редирект несуществующей пагинации записей', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-single-pagination-duplicate"
							name="mvweb_so[remove_single_pagination_duplicate]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_single_pagination_duplicate' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'На одиночных записях: если запрошена страница (/post/page/N/) которой нет — 301 на каноническую запись. Учитывает маркеры <!--nextpage-->. WooCommerce-страницы (корзина, оформление, аккаунт, магазин) исключены.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-attachment-pages-redirect">
				<?php esc_html_e( 'Редирект страниц-вложений', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-attachment-pages-redirect"
							name="mvweb_so[attachment_pages_redirect]"
							value="on"
							<?php checked( mvweb_so_check_option( 'attachment_pages_redirect' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Страницы вида /?attachment_id=… или /post/image-name/ редиректят 301 на родительскую запись (или на главную, если родителя нет).', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-redirect-archives-author">
				<?php esc_html_e( 'Редирект архивов автора', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-redirect-archives-author"
							name="mvweb_so[redirect_archives_author]"
							value="on"
							<?php checked( mvweb_so_check_option( 'redirect_archives_author' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Страницы /author/username/ возвращают 301 на главную. Полезно, если на сайте один автор или авторские архивы не используются.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-redirect-archives-date">
				<?php esc_html_e( 'Редирект архивов по датам', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-redirect-archives-date"
							name="mvweb_so[redirect_archives_date]"
							value="on"
							<?php checked( mvweb_so_check_option( 'redirect_archives_date' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Архивы /2025/, /2025/01/ и т.п. возвращают 301 на главную. Уменьшает индексирование пустых или малоинформативных страниц.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-redirect-archives-tag">
				<?php esc_html_e( 'Редирект архивов меток', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-redirect-archives-tag"
							name="mvweb_so[redirect_archives_tag]"
							value="on"
							<?php checked( mvweb_so_check_option( 'redirect_archives_tag' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Архивы /tag/… возвращают 301 на главную. Включайте, если метки на сайте не используются как навигационные страницы.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-protect-author-get">
				<?php esc_html_e( 'Защита от перебора авторов через ?author=N', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-protect-author-get"
							name="mvweb_so[protect_author_get]"
							value="on"
							<?php checked( mvweb_so_check_option( 'protect_author_get' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Запросы /?author=1, /?author=2 и т.д. возвращают 301 на главную. Защищает от перечисления логинов пользователей через стандартный механизм WordPress.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>
