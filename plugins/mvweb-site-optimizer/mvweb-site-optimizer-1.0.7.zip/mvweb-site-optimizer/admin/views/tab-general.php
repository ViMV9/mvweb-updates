<?php
/**
 * General tab — статус плагина, навигация по разделам, Export/Import настроек.
 *
 * Phase 1: реальная вкладка. Метаконтролы плагина, без оптимизаций.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$active_features = mvweb_so_count_active_features();
$total_options   = count( mvweb_so_get_settings() );
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Статус плагина', 'mvweb-site-optimizer' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Сводная карточка: версия, активные функции, ссылки на ресурсы.', 'mvweb-site-optimizer' ); ?></p>

	<div class="mvweb-metrics">
		<div class="mvweb-metric">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Версия', 'mvweb-site-optimizer' ); ?></div>
			<div class="mvweb-metric__value">v<?php echo esc_html( MVWEB_SO_VERSION ); ?></div>
		</div>

		<div class="mvweb-metric">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Активных функций', 'mvweb-site-optimizer' ); ?></div>
			<div class="mvweb-metric__value" data-mvweb-so-active><?php echo (int) $active_features; ?></div>
		</div>

		<div class="mvweb-metric">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Сохранённых опций', 'mvweb-site-optimizer' ); ?></div>
			<div class="mvweb-metric__value" data-mvweb-so-total><?php echo (int) $total_options; ?></div>
		</div>
	</div>

	<p class="mvweb-block__sub">
		<a href="https://mvweb.ru/plugins/mvweb-site-optimizer" target="_blank" rel="noopener noreferrer">
			<?php esc_html_e( 'Документация плагина →', 'mvweb-site-optimizer' ); ?>
		</a>
	</p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Перенос настроек', 'mvweb-site-optimizer' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Сохраните настройки в файл для переноса на другой сайт или восстановления.', 'mvweb-site-optimizer' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label"><?php esc_html_e( 'Экспорт', 'mvweb-site-optimizer' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-so-actions">
				<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm" data-mvweb-so-export>
					<?php esc_html_e( 'Скачать настройки', 'mvweb-site-optimizer' ); ?>
				</button>
			</div>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Скачайте JSON-файл со всеми настройками плагина, правилами редиректов и журналом IndexNow.', 'mvweb-site-optimizer' ); ?>
			</p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label" for="mvweb-so-import-file"><?php esc_html_e( 'Импорт', 'mvweb-site-optimizer' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-so-actions">
				<input type="file"
						id="mvweb-so-import-file"
						accept="application/json,.json"
						class="mvweb-so-file"
						data-mvweb-so-import-file>
				<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm" data-mvweb-so-import disabled>
					<?php esc_html_e( 'Импортировать', 'mvweb-site-optimizer' ); ?>
				</button>
			</div>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Выберите ранее экспортированный JSON-файл. Текущие настройки будут заменены.', 'mvweb-site-optimizer' ); ?>
			</p>
			<div class="mvweb-so-feedback" data-mvweb-so-feedback aria-live="polite"></div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label"><?php esc_html_e( 'Сброс', 'mvweb-site-optimizer' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-so-actions">
				<button type="button" class="mvweb-btn mvweb-btn--danger" data-mvweb-so-reset>
					<?php esc_html_e( 'Сбросить настройки', 'mvweb-site-optimizer' ); ?>
				</button>
			</div>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Удалить все сохранённые настройки и вернуться к значениям по умолчанию. Действие необратимо.', 'mvweb-site-optimizer' ); ?>
			</p>
		</div>
	</div>
</div>
