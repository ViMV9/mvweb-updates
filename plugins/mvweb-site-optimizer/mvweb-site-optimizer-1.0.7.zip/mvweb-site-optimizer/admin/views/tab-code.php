<?php
/**
 * Code tab — cleanup of WordPress head and front-end ballast.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Чистка фронтенда', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Отключение лишних скриптов и стилей, которые WordPress подгружает по умолчанию, но используются редко. Снижает количество запросов на странице и упрощает исходный код.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-emoji">
				<?php esc_html_e( 'Отключить Emoji', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-emoji"
							name="mvweb_so[disable_emoji]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_emoji' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'WordPress 4.2+ подключает JS-библиотеку для отображения эмодзи в старых браузерах. Она замедляет страницу и делает запрос ко внешнему ресурсу s.w.org. Опция убирает detect-скрипт, inline-стили, DNS-prefetch, фильтры в RSS и письмах. Современные браузеры рисуют эмодзи нативно.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-jquery-migrate">
				<?php esc_html_e( 'Удалить jquery-migrate.min.js', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-jquery-migrate"
							name="mvweb_so[remove_jquery_migrate]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_jquery_migrate' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'jquery-migrate нужен старым плагинам, написанным под jQuery до 1.9. В большинстве современных тем и плагинов он не используется — но добавляет лишний HTTP-запрос. Внимание: после включения проверьте, что сайт по-прежнему работает корректно (особенно слайдеры, формы, ajax-кнопки).', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-recent-comments-style">
				<?php esc_html_e( 'Удалить стили .recentcomments', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-recent-comments-style"
							name="mvweb_so[remove_recent_comments_style]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_recent_comments_style' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'WordPress вставляет в <head> инлайн-стиль для виджета «Свежие комментарии» — даже если этот виджет не используется. Стиль помечен !important, поэтому переопределить из темы напрямую нельзя. Опция убирает блок целиком.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-html-minify">
				<?php esc_html_e( 'Минифицировать HTML', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-html-minify"
							name="mvweb_so[html_minify]"
							value="on"
							<?php checked( mvweb_so_check_option( 'html_minify' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Удаляет переносы строк, табы и лишние пробелы из HTML, выдаваемого посетителю. Уменьшает вес страницы на 10-25 %, улучшает оценку Google PageSpeed. Содержимое pre, textarea, script и style не затрагивается; условные комментарии IE и HTML-комментарии сохраняются (могут содержать код аналитики или рекламных сетей). После включения сбросьте кеш, если он включён.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Чистка <head>', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'В исходный код каждой страницы WordPress добавляет служебные ссылки и метатеги, нужные только разработчикам и устаревшим клиентам. Уберите всё, чем не пользуетесь — это упростит код и уменьшит вес страницы.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-meta-generator">
				<?php esc_html_e( 'Удалить meta generator', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-meta-generator"
							name="mvweb_so[remove_meta_generator]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_meta_generator' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Метатег <meta name="generator" content="WordPress X.X"> сообщает злоумышленникам, какая версия движка установлена — это первый шаг к подбору известных уязвимостей. Полезной функции у тега нет, его можно безопасно убрать.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-dns-prefetch">
				<?php esc_html_e( 'Удалить dns-prefetch', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-dns-prefetch"
							name="mvweb_so[remove_dns_prefetch]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_dns_prefetch' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Браузер заранее резолвит DNS для серверов WordPress (s.w.org и др.) — это полезно, если вы используете эмодзи и Gravatar. Если вы их отключили — prefetch становится лишним.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-rsd-link">
				<?php esc_html_e( 'Удалить ссылку RSD', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-rsd-link"
							name="mvweb_so[remove_rsd_link]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_rsd_link' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Really Simple Discovery — протокол для устаревших блог-клиентов вроде Windows Live Writer. Сегодня ими почти никто не пользуется.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-adjacent-posts-link">
				<?php esc_html_e( 'Удалить ссылки prev/next', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-adjacent-posts-link"
							name="mvweb_so[remove_adjacent_posts_link]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_adjacent_posts_link' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Ссылки на соседнюю запись (adjacent_posts_rel_link). Google перестал учитывать их как сигнал ещё в 2019 году, в навигации сайта они тоже не участвуют.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-shortlink-link">
				<?php esc_html_e( 'Удалить shortlink', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-shortlink-link"
							name="mvweb_so[remove_shortlink_link]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_shortlink_link' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Короткие ссылки вида /?p=42 нужны там, где нет ЧПУ. Если permalink настроены — shortlink дублирует адрес записи и не используется.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-x-pingback">
				<?php esc_html_e( 'Отключить xmlrpc.php', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-x-pingback"
							name="mvweb_so[remove_x_pingback]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_x_pingback' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'XML-RPC — старый протокол удалённого доступа к WordPress. Через него часто проходят DDoS и брутфорс-атаки, а pingback используется для спама. Опция отключает endpoint целиком, убирает HTTP-заголовок X-Pingback и метатеги в исходниках.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Версии файлов в исходниках', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'WordPress, тема и плагины подключают стили и скрипты с указанием версии в виде ?ver=4.7.5. Это позволяет злоумышленникам узнать, какие версии установлены, и подобрать известные уязвимости. Заодно ?ver= мешает кешированию ресурсов в браузере и CDN.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-versions-styles">
				<?php esc_html_e( 'Скрыть версию у стилей', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-versions-styles"
							name="mvweb_so[remove_versions_styles]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_versions_styles' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Удаляет ?ver= из адресов CSS-файлов.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-versions-scripts">
				<?php esc_html_e( 'Скрыть версию у скриптов', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-versions-scripts"
							name="mvweb_so[remove_versions_scripts]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_versions_scripts' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Удаляет ?ver= из адресов JS-файлов. После обновления плагина или темы рекомендуется сбросить кеш браузера и CDN.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Принудительный HTTPS', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Если сайт открывают по HTTP — 301 редирект на HTTPS-версию того же URL. Не работает в CLI и WP_CLI окружениях.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-redirect-https">
				<?php esc_html_e( 'Редирект HTTP → HTTPS', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-redirect-https"
							name="mvweb_so[redirect_from_http_to_https]"
							value="on"
							<?php checked( mvweb_so_check_option( 'redirect_from_http_to_https' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Включайте только если SSL-сертификат уже установлен и сайт открывается по HTTPS. Иначе получите бесконечный редирект.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Кастомные сниппеты', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Добавляйте произвольный HTML или JavaScript в исходный код страниц без правки темы. Редактировать может только администратор — содержимое сохраняется как есть, без экранирования.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-insert-code-in-head">
				<?php esc_html_e( 'Код в <head>', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-so-insert-code-in-head"
						name="mvweb_so[insert_code_in_head]"
						class="mvweb-textarea"
						rows="6"
						spellcheck="false"><?php echo esc_textarea( (string) mvweb_so_get_option( 'insert_code_in_head', '' ) ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Сюда обычно добавляют коды подтверждения вебмастера (Яндекс.Вебмастер, Google Search Console), счётчики аналитики и JS-код, который должен выполниться первым.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-insert-code-in-body">
				<?php esc_html_e( 'Код перед </body>', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-so-insert-code-in-body"
						name="mvweb_so[insert_code_in_body]"
						class="mvweb-textarea"
						rows="6"
						spellcheck="false"><?php echo esc_textarea( (string) mvweb_so_get_option( 'insert_code_in_body', '' ) ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Сюда обычно добавляют отложенные скрипты, чат-виджеты, пиксели ретаргетинга и прочие сторонние JS-инструменты.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>
