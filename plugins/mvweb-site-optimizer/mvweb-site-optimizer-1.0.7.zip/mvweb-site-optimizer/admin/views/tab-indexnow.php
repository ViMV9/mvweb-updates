<?php
/**
 * IndexNow tab — управление ключом, выбор post-типов и эндпоинтов, журнал отправок.
 *
 * Phase 9. Форма настроек + карточка ключа + журнал последних 50 отправок.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_so_indexnow = isset( $GLOBALS['mvweb_so_tab_indexnow'] ) && $GLOBALS['mvweb_so_tab_indexnow'] instanceof MVweb_SO_Tab_IndexNow
	? $GLOBALS['mvweb_so_tab_indexnow']
	: null;

if ( ! $mvweb_so_indexnow instanceof MVweb_SO_Tab_IndexNow ) {
	return;
}

$mvweb_so_indexnow_key     = $mvweb_so_indexnow->get_key();
$mvweb_so_indexnow_key_url = home_url( '/' . $mvweb_so_indexnow_key . '.txt' );
$mvweb_so_indexnow_enabled = mvweb_so_check_option( 'indexnow_enabled' );
$mvweb_so_indexnow_pts     = $mvweb_so_indexnow->get_available_post_types();
$mvweb_so_indexnow_pt_sel  = $mvweb_so_indexnow->get_selected_post_types();
$mvweb_so_indexnow_ep_sel  = $mvweb_so_indexnow->get_selected_endpoints();
$mvweb_so_indexnow_log     = array_reverse( $mvweb_so_indexnow->get_log() );
$mvweb_so_indexnow_log     = array_slice( $mvweb_so_indexnow_log, 0, 50 );
?>

<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'IndexNow', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Автоматическая отправка изменений в Яндекс и Bing через протокол IndexNow. После публикации или обновления записи поисковикам сразу приходит уведомление о новом URL.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-alert mvweb-alert--info">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
			<div class="mvweb-alert__body">
				<p class="mvweb-alert__title"><?php esc_html_e( 'Как это работает', 'mvweb-site-optimizer' ); ?></p>
				<p>
					<?php esc_html_e( 'Плагин выдаёт ключевой файл по адресу /{key}.txt в корне сайта (виртуально, без записи на диск). При публикации или обновлении записи URL добавляется в очередь, отправка идёт пакетом раз в 60 секунд через WP-Cron — это не замедляет сохранение поста.', 'mvweb-site-optimizer' ); ?>
				</p>
				<p>
					<?php esc_html_e( 'Спецификация: indexnow.org/documentation. После любой отправки можно посмотреть журнал ниже — каждая строка показывает URL, эндпоинт и HTTP-код ответа.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-indexnow-enabled"><?php esc_html_e( 'Включить IndexNow', 'mvweb-site-optimizer' ); ?></label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-indexnow-enabled"
							name="mvweb_so[indexnow_enabled]"
							value="on"
							<?php checked( $mvweb_so_indexnow_enabled ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Когда включено — изменения публичных записей выбранных типов автоматически уходят в выбранные поисковики.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Ключ IndexNow', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Уникальный токен подтверждения владения сайтом. Поисковик проверяет его по адресу /{key}.txt при первой отправке.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-indexnow-key"><?php esc_html_e( 'Текущий ключ', 'mvweb-site-optimizer' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text"
						id="mvweb-so-indexnow-key"
						class="mvweb-input"
						value="<?php echo esc_attr( $mvweb_so_indexnow_key ); ?>"
						data-mvweb-so-indexnow-key
						readonly>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Ключевой файл:', 'mvweb-site-optimizer' ); ?>
					<a href="<?php echo esc_url( $mvweb_so_indexnow_key_url ); ?>" target="_blank" rel="noopener noreferrer" data-mvweb-so-indexnow-key-url>
						<code><?php echo esc_html( $mvweb_so_indexnow_key_url ); ?></code>
					</a>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label">&nbsp;</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-so-actions">
					<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm" data-mvweb-so-indexnow-regenerate>
						<?php esc_html_e( 'Сгенерировать новый ключ', 'mvweb-site-optimizer' ); ?>
					</button>
					<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm" data-mvweb-so-indexnow-test>
						<?php esc_html_e( 'Тестовая отправка главной', 'mvweb-site-optimizer' ); ?>
					</button>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Новый ключ начинает работать сразу. Старый ключевой файл перестанет отдаваться — если у поисковика остался кэш, он переключится при следующей отправке.', 'mvweb-site-optimizer' ); ?>
				</p>
				<div class="mvweb-so-feedback" data-mvweb-so-indexnow-feedback aria-live="polite"></div>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Что отправлять', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Выберите типы записей, изменения которых должны уходить в IndexNow.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label"><?php esc_html_e( 'Типы записей', 'mvweb-site-optimizer' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-so-toggle-list">
					<?php foreach ( $mvweb_so_indexnow_pts as $mvweb_so_pt_slug => $mvweb_so_pt_label ) : ?>
						<div class="mvweb-toggle-row">
							<label class="mvweb-toggle">
								<input type="checkbox"
										name="mvweb_so[indexnow_post_types][]"
										value="<?php echo esc_attr( $mvweb_so_pt_slug ); ?>"
										<?php checked( in_array( $mvweb_so_pt_slug, $mvweb_so_indexnow_pt_sel, true ) ); ?>>
								<span class="mvweb-toggle__slider"></span>
							</label>
							<span class="mvweb-so-toggle-text">
								<?php echo esc_html( $mvweb_so_pt_label ); ?>
								<code><?php echo esc_html( $mvweb_so_pt_slug ); ?></code>
							</span>
						</div>
					<?php endforeach; ?>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'По умолчанию — post и page. Если оставить всё пустым, отправка для всех типов будет выключена.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label"><?php esc_html_e( 'Куда отправлять', 'mvweb-site-optimizer' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-so-toggle-list">
					<div class="mvweb-toggle-row">
						<label class="mvweb-toggle">
							<input type="checkbox"
									name="mvweb_so[indexnow_endpoints][]"
									value="yandex"
									<?php checked( in_array( 'yandex', $mvweb_so_indexnow_ep_sel, true ) ); ?>>
							<span class="mvweb-toggle__slider"></span>
						</label>
						<span class="mvweb-so-toggle-text">
							<?php esc_html_e( 'Яндекс', 'mvweb-site-optimizer' ); ?>
							<code>yandex.com/indexnow</code>
						</span>
					</div>
					<div class="mvweb-toggle-row">
						<label class="mvweb-toggle">
							<input type="checkbox"
									name="mvweb_so[indexnow_endpoints][]"
									value="bing"
									<?php checked( in_array( 'bing', $mvweb_so_indexnow_ep_sel, true ) ); ?>>
							<span class="mvweb-toggle__slider"></span>
						</label>
						<span class="mvweb-so-toggle-text">
							<?php esc_html_e( 'Bing', 'mvweb-site-optimizer' ); ?>
							<code>bing.com/indexnow</code>
						</span>
					</div>
				</div>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Bing и Яндекс шарят пул IndexNow — отправка одного URL фактически уходит и в Google-партнёров. Рекомендуем оставить оба эндпоинта включёнными.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>
<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title">
			<?php esc_html_e( 'Журнал отправок', 'mvweb-site-optimizer' ); ?>
			<span class="mvweb-tabs__count" data-mvweb-so-indexnow-count><?php echo (int) count( $mvweb_so_indexnow_log ); ?></span>
		</div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Последние 50 отправок (всего в журнале хранится до 200 записей). Старые ротируются автоматически.', 'mvweb-site-optimizer' ); ?></p>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label">&nbsp;</label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-so-actions">
				<button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm" data-mvweb-so-indexnow-clear-log>
					<?php esc_html_e( 'Очистить журнал', 'mvweb-site-optimizer' ); ?>
				</button>
			</div>
		</div>
	</div>

	<div class="mvweb-table-wrap">
		<table class="mvweb-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'URL', 'mvweb-site-optimizer' ); ?></th>
					<th><?php esc_html_e( 'Эндпоинт', 'mvweb-site-optimizer' ); ?></th>
					<th><?php esc_html_e( 'Статус', 'mvweb-site-optimizer' ); ?></th>
					<th><?php esc_html_e( 'Ответ', 'mvweb-site-optimizer' ); ?></th>
					<th><?php esc_html_e( 'Отправлено', 'mvweb-site-optimizer' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php if ( empty( $mvweb_so_indexnow_log ) ) : ?>
					<tr>
						<td colspan="5">
							<div class="mvweb-empty">
								<div class="mvweb-empty__icon">
									<svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
										<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
										<polyline points="14 2 14 8 20 8"/>
										<line x1="9" y1="15" x2="15" y2="15"/>
									</svg>
								</div>
								<h3 class="mvweb-empty__title"><?php esc_html_e( 'Журнал пуст', 'mvweb-site-optimizer' ); ?></h3>
								<p class="mvweb-empty__text"><?php esc_html_e( 'Опубликуйте или обновите запись — спустя минуту здесь появятся строки отправок.', 'mvweb-site-optimizer' ); ?></p>
							</div>
						</td>
					</tr>
				<?php else : ?>
					<?php foreach ( $mvweb_so_indexnow_log as $mvweb_so_entry ) : ?>
						<?php
						$mvweb_so_status   = isset( $mvweb_so_entry['status'] ) ? (int) $mvweb_so_entry['status'] : 0;
						$mvweb_so_badge    = 'mvweb-badge';
						if ( $mvweb_so_status >= 200 && $mvweb_so_status < 300 ) {
							$mvweb_so_badge = 'mvweb-badge mvweb-badge--success';
						} elseif ( $mvweb_so_status >= 400 || 0 === $mvweb_so_status ) {
							$mvweb_so_badge = 'mvweb-badge mvweb-badge--warning';
						}
						$mvweb_so_sent_at = isset( $mvweb_so_entry['sent_at'] ) ? (int) $mvweb_so_entry['sent_at'] : 0;
						$mvweb_so_sent_h  = $mvweb_so_sent_at > 0
							? wp_date( 'Y-m-d H:i:s', $mvweb_so_sent_at )
							: '—';
						$mvweb_so_ep      = isset( $mvweb_so_entry['endpoint'] ) ? (string) $mvweb_so_entry['endpoint'] : '';
						$mvweb_so_url     = isset( $mvweb_so_entry['url'] ) ? (string) $mvweb_so_entry['url'] : '';
						$mvweb_so_msg     = isset( $mvweb_so_entry['message'] ) ? (string) $mvweb_so_entry['message'] : '';
						?>
						<tr>
							<td><code><?php echo esc_html( $mvweb_so_url ); ?></code></td>
							<td><?php echo esc_html( $mvweb_so_ep ); ?></td>
							<td><span class="<?php echo esc_attr( $mvweb_so_badge ); ?>"><?php echo esc_html( (string) $mvweb_so_status ); ?></span></td>
							<td><?php echo esc_html( $mvweb_so_msg ); ?></td>
							<td><?php echo esc_html( $mvweb_so_sent_h ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
