<?php
/**
 * Redirect tab — менеджер 301/302 редиректов.
 *
 * Phase 8. Форма добавления правила + таблица существующих правил
 * с inline-редактированием и переключателем enabled/disabled.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_so_redirect_rules = get_option( MVweb_SO_Tab_Redirect::OPTION_KEY, array() );
$mvweb_so_redirect_rules = is_array( $mvweb_so_redirect_rules ) ? array_values( $mvweb_so_redirect_rules ) : array();
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Менеджер редиректов', 'mvweb-site-optimizer' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Правила 301/302 — переадресация старых URL на актуальные. Поддерживаются точные совпадения и регулярные выражения.', 'mvweb-site-optimizer' ); ?></p>

	<div class="mvweb-alert mvweb-alert--info">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="20" height="20"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
		<div class="mvweb-alert__body">
			<p class="mvweb-alert__title"><?php esc_html_e( 'Как работают правила', 'mvweb-site-optimizer' ); ?></p>
			<p>
				<?php esc_html_e( 'В режиме «Точный путь» поле «Откуда» — путь от корня сайта (например, /старая-страница/). В режиме «Регулярное выражение» — PCRE-шаблон без ограничителей (например, ^/blog/(\d+)/?$). В поле «Куда» можно использовать обратные ссылки $1, $2 — будут подставлены захваченные группы.', 'mvweb-site-optimizer' ); ?>
			</p>
			<p>
				<?php esc_html_e( 'Правила обрабатываются сверху вниз — побеждает первое совпавшее. Внутренние редиректы — через wp_safe_redirect, на внешние домены — через wp_redirect.', 'mvweb-site-optimizer' ); ?>
			</p>
		</div>
	</div>

	<div class="mvweb-so-redirect-form" data-mvweb-so-redirect-form>
		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-redirect-from"><?php esc_html_e( 'Откуда', 'mvweb-site-optimizer' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text"
						id="mvweb-so-redirect-from"
						class="mvweb-input"
						name="from"
						placeholder="/old-page/"
						autocomplete="off">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Путь от корня сайта или PCRE-шаблон в режиме regex.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-redirect-to"><?php esc_html_e( 'Куда', 'mvweb-site-optimizer' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text"
						id="mvweb-so-redirect-to"
						class="mvweb-input"
						name="to"
						placeholder="/new-page/"
						autocomplete="off">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Путь на этом же сайте, либо полный URL https://… для внешнего редиректа. В regex-режиме поддерживаются $1, $2, … для подстановки захваченных групп.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-redirect-type"><?php esc_html_e( 'Код ответа', 'mvweb-site-optimizer' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb-so-redirect-type" class="mvweb-select" name="type">
					<option value="301">301 — <?php esc_html_e( 'постоянный', 'mvweb-site-optimizer' ); ?></option>
					<option value="302">302 — <?php esc_html_e( 'временный', 'mvweb-site-optimizer' ); ?></option>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( '301 для постоянных переездов (передаёт SEO-вес), 302 для временных.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-redirect-mode"><?php esc_html_e( 'Режим', 'mvweb-site-optimizer' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb-so-redirect-mode" class="mvweb-select" name="mode">
					<option value="exact"><?php esc_html_e( 'Точный путь', 'mvweb-site-optimizer' ); ?></option>
					<option value="regex"><?php esc_html_e( 'Регулярное выражение', 'mvweb-site-optimizer' ); ?></option>
				</select>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Точный — совпадение по строке. Regex — PCRE-шаблон, можно использовать группы захвата.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-redirect-allow-external"><?php esc_html_e( 'Внешний URL', 'mvweb-site-optimizer' ); ?></label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-redirect-allow-external"
							name="allow_external"
							value="1">
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Разрешить редирект на другой домен (через wp_redirect). По умолчанию выключено — для безопасности все редиректы идут через wp_safe_redirect, который блокирует чужие хосты. Включайте, только если действительно нужно увести пользователя на сторонний сайт.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label">&nbsp;</label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-so-actions">
					<button type="button" class="mvweb-btn mvweb-btn--primary mvweb-btn--sm" data-mvweb-so-redirect-add>
						<?php esc_html_e( 'Добавить правило', 'mvweb-site-optimizer' ); ?>
					</button>
					<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm" data-mvweb-so-redirect-reset hidden>
						<?php esc_html_e( 'Отмена', 'mvweb-site-optimizer' ); ?>
					</button>
				</div>
				<div class="mvweb-so-feedback" data-mvweb-so-redirect-feedback aria-live="polite"></div>
			</div>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title">
			<?php esc_html_e( 'Существующие правила', 'mvweb-site-optimizer' ); ?>
			<span class="mvweb-tabs__count" data-mvweb-so-redirect-count><?php echo (int) count( $mvweb_so_redirect_rules ); ?></span>
		</div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Список текущих правил с возможностью включить/выключить, отредактировать или удалить каждое.', 'mvweb-site-optimizer' ); ?></p>

	<div class="mvweb-table-wrap">
		<table class="mvweb-table mvweb-so-redirect-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Откуда', 'mvweb-site-optimizer' ); ?></th>
					<th><?php esc_html_e( 'Куда', 'mvweb-site-optimizer' ); ?></th>
					<th><?php esc_html_e( 'Код', 'mvweb-site-optimizer' ); ?></th>
					<th><?php esc_html_e( 'Режим', 'mvweb-site-optimizer' ); ?></th>
					<th><?php esc_html_e( 'Внешний', 'mvweb-site-optimizer' ); ?></th>
					<th><?php esc_html_e( 'Активно', 'mvweb-site-optimizer' ); ?></th>
					<th><?php esc_html_e( 'Действия', 'mvweb-site-optimizer' ); ?></th>
				</tr>
			</thead>
			<tbody data-mvweb-so-redirect-tbody>
				<?php if ( empty( $mvweb_so_redirect_rules ) ) : ?>
					<tr data-mvweb-so-redirect-empty>
						<td colspan="7">
							<div class="mvweb-empty">
								<?php esc_html_e( 'Пока нет ни одного правила. Добавьте первое через форму выше.', 'mvweb-site-optimizer' ); ?>
							</div>
						</td>
					</tr>
				<?php else : ?>
					<?php foreach ( $mvweb_so_redirect_rules as $mvweb_so_rule ) : ?>
						<?php
						$mvweb_so_rid      = isset( $mvweb_so_rule['id'] ) ? (int) $mvweb_so_rule['id'] : 0;
						$mvweb_so_from     = isset( $mvweb_so_rule['from'] ) ? (string) $mvweb_so_rule['from'] : '';
						$mvweb_so_to       = isset( $mvweb_so_rule['to'] ) ? (string) $mvweb_so_rule['to'] : '';
						$mvweb_so_type     = isset( $mvweb_so_rule['type'] ) ? (int) $mvweb_so_rule['type'] : 301;
						$mvweb_so_mode     = isset( $mvweb_so_rule['mode'] ) ? (string) $mvweb_so_rule['mode'] : 'exact';
						$mvweb_so_state    = isset( $mvweb_so_rule['enabled'] ) ? (int) $mvweb_so_rule['enabled'] : 1;
						$mvweb_so_external = ! empty( $mvweb_so_rule['allow_external'] ) ? 1 : 0;
						$mvweb_so_label    = ( 'regex' === $mvweb_so_mode )
							? esc_html__( 'regex', 'mvweb-site-optimizer' )
							: esc_html__( 'точный', 'mvweb-site-optimizer' );
						?>
						<tr data-mvweb-so-redirect-row data-id="<?php echo esc_attr( (string) $mvweb_so_rid ); ?>"
							data-from="<?php echo esc_attr( $mvweb_so_from ); ?>"
							data-to="<?php echo esc_attr( $mvweb_so_to ); ?>"
							data-type="<?php echo esc_attr( (string) $mvweb_so_type ); ?>"
							data-mode="<?php echo esc_attr( $mvweb_so_mode ); ?>"
							data-allow-external="<?php echo esc_attr( (string) $mvweb_so_external ); ?>">
							<td><code><?php echo esc_html( $mvweb_so_from ); ?></code></td>
							<td><code><?php echo esc_html( $mvweb_so_to ); ?></code></td>
							<td><span class="mvweb-badge mvweb-badge--success"><?php echo esc_html( (string) $mvweb_so_type ); ?></span></td>
							<td><span class="mvweb-badge"><?php echo esc_html( $mvweb_so_label ); ?></span></td>
							<td>
								<?php if ( $mvweb_so_external ) : ?>
									<span class="mvweb-badge mvweb-badge--warning"><?php esc_html_e( 'да', 'mvweb-site-optimizer' ); ?></span>
								<?php else : ?>
									<span class="mvweb-badge"><?php esc_html_e( 'нет', 'mvweb-site-optimizer' ); ?></span>
								<?php endif; ?>
							</td>
							<td>
								<label class="mvweb-toggle">
									<input type="checkbox"
											data-mvweb-so-redirect-toggle
											value="1"
											<?php checked( 1, $mvweb_so_state ); ?>>
									<span class="mvweb-toggle__slider"></span>
								</label>
							</td>
							<td>
								<div class="mvweb-so-actions">
									<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-btn--sm" data-mvweb-so-redirect-edit>
										<?php esc_html_e( 'Изменить', 'mvweb-site-optimizer' ); ?>
									</button>
									<button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm" data-mvweb-so-redirect-delete>
										<?php esc_html_e( 'Удалить', 'mvweb-site-optimizer' ); ?>
									</button>
								</div>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
			</tbody>
		</table>
	</div>
</div>
