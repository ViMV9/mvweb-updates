<?php
/**
 * Additionally tab — комплекс мелких настроек чистки <head>/<body> и поведения админки.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Логин и cookie-баннер', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Стандартные сообщения об ошибке входа («неверный логин» и «неверный пароль» — раздельно) подсказывают злоумышленникам, существует ли такой пользователь — это упрощает брутфорс. Здесь же — баннер согласия на cookie для соответствия 152-ФЗ и GDPR.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-change-login-errors">
				<?php esc_html_e( 'Скрыть подробности ошибок входа', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-change-login-errors"
							name="mvweb_so[change_login_errors]"
							value="on"
							<?php checked( mvweb_so_check_option( 'change_login_errors' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Стандартные сообщения «Неверный логин» / «Неверный пароль» подменяются единым нейтральным сообщением. Закрывает канал user enumeration через форму входа.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-change-login-errors-text">
				<?php esc_html_e( 'Текст сообщения', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
						id="mvweb-so-change-login-errors-text"
						name="mvweb_so[change_login_errors_text]"
						class="mvweb-input"
						value="<?php echo esc_attr( (string) mvweb_so_get_option( 'change_login_errors_text', '' ) ); ?>"
						placeholder="<?php esc_attr_e( 'Неверные данные для входа.', 'mvweb-site-optimizer' ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Если оставить пустым — используется значение по умолчанию.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-message-cookie">
				<?php esc_html_e( 'Cookie-баннер', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-message-cookie"
							name="mvweb_so[message_cookie]"
							value="on"
							<?php checked( mvweb_so_check_option( 'message_cookie' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Показывает в нижней части сайта плашку согласия с использованием cookie. Согласие сохраняется в localStorage и cookie на год.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-message-cookie-text">
				<?php esc_html_e( 'Текст баннера', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
						id="mvweb-so-message-cookie-text"
						name="mvweb_so[message_cookie_text]"
						class="mvweb-input"
						value="<?php echo esc_attr( (string) mvweb_so_get_option( 'message_cookie_text', '' ) ); ?>"
						placeholder="<?php esc_attr_e( 'Мы используем cookie для корректной работы сайта…', 'mvweb-site-optimizer' ); ?>">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-message-cookie-button">
				<?php esc_html_e( 'Текст кнопки', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
						id="mvweb-so-message-cookie-button"
						name="mvweb_so[message_cookie_button]"
						class="mvweb-input"
						value="<?php echo esc_attr( (string) mvweb_so_get_option( 'message_cookie_button', '' ) ); ?>"
						placeholder="<?php esc_attr_e( 'Принять', 'mvweb-site-optimizer' ); ?>">
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Ревизии записей', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'При каждом сохранении записи или страницы WordPress создаёт её копию-ревизию, которую можно восстановить позже. Со временем ревизий накапливается десятки на запись — они забивают базу, занимают место и замедляют резервное копирование. Обычно достаточно хранить 3-5 последних версий.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-revisions-disable">
				<?php esc_html_e( 'Полностью отключить ревизии', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-revisions-disable"
							name="mvweb_so[revisions_disable]"
							value="on"
							<?php checked( mvweb_so_check_option( 'revisions_disable' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'WordPress перестаёт сохранять копии при обновлении записей. Старые ревизии в базе остаются — их можно удалить отдельно через инструменты очистки БД.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-revision-limit">
				<?php esc_html_e( 'Ограничить количество ревизий', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
						id="mvweb-so-revision-limit"
						name="mvweb_so[revision_limit]"
						class="mvweb-input"
						min="0"
						max="999"
						step="1"
						value="<?php echo esc_attr( (string) (int) mvweb_so_get_option( 'revision_limit', 0 ) ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Сколько последних ревизий хранить на одну запись. 0 — без ограничения. Игнорируется, если ревизии полностью отключены тогглом выше.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Заголовки кеширования', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'WordPress по умолчанию не сообщает поисковому боту, когда страница была изменена последний раз, и не умеет корректно отвечать 304 Not Modified. Это важно для SEO: при наличии заголовков бот ускоряет индексацию, тратит меньше краулингового бюджета и видит больше страниц за один обход.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-set-last-modified-headers">
				<?php esc_html_e( 'Автоматически устанавливать Last-Modified', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-set-last-modified-headers"
							name="mvweb_so[set_last_modified_headers]"
							value="on"
							<?php checked( mvweb_so_check_option( 'set_last_modified_headers' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Заголовок Last-Modified добавляется к одиночным записям (с учётом даты последнего одобренного комментария) и к архивам (рубрики, метки, кастомные таксономии, архивы CPT, дата, автор, главная блога) — берётся самая свежая запись в выдаче. Не применяется на 404, поиске, фидах, страницах корзины/оформления/личного кабинета WooCommerce и для авторизованных пользователей.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-if-modified-since-headers">
				<?php esc_html_e( 'Отвечать 304 на If-Modified-Since', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-if-modified-since-headers"
							name="mvweb_so[if_modified_since_headers]"
							value="on"
							<?php checked( mvweb_so_check_option( 'if_modified_since_headers' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Парная опция к Last-Modified. Если клиент пришёл с If-Modified-Since и страница (запись или весь архив) с того момента не менялась — сервер отвечает 304 Not Modified без тела с заголовком Cache-Control: private, must-revalidate. Заголовки с датой в будущем игнорируются — защита от подделанных запросов.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'PageSpeed', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Точечные правки для Google PageSpeed.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-passive-listeners">
				<?php esc_html_e( 'PageSpeed passive listeners', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-passive-listeners"
							name="mvweb_so[passive_listeners]"
							value="on"
							<?php checked( mvweb_so_check_option( 'passive_listeners' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Включите, если Google PageSpeed выдаёт предупреждение «Does not use passive listeners to improve scrolling performance». Помечает обработчики touch/wheel-событий как passive, чтобы прокрутка не блокировалась.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Виджеты и форма комментариев', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Виджеты «Страницы», «Календарь», «Облако меток» и подобные сегодня используются редко — их легко заменить виджетом «Меню», а часть из них создаёт дубли страниц в индексе. Также здесь можно убрать поле «Сайт» из формы комментариев — это снижает спам, который оставляют ради обратной ссылки.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-unneeded-widget-page">
				<?php esc_html_e( 'Виджет «Страницы»', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-unneeded-widget-page"
							name="mvweb_so[remove_unneeded_widget_page]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_unneeded_widget_page' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-unneeded-widget-calendar">
				<?php esc_html_e( 'Виджет «Календарь»', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-unneeded-widget-calendar"
							name="mvweb_so[remove_unneeded_widget_calendar]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_unneeded_widget_calendar' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-unneeded-widget-tag-cloud">
				<?php esc_html_e( 'Виджет «Облако меток»', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-unneeded-widget-tag-cloud"
							name="mvweb_so[remove_unneeded_widget_tag_cloud]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_unneeded_widget_tag_cloud' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-unneeded-widget-archives">
				<?php esc_html_e( 'Виджет «Архивы»', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-unneeded-widget-archives"
							name="mvweb_so[remove_unneeded_widget_archives]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_unneeded_widget_archives' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-unneeded-widget-meta">
				<?php esc_html_e( 'Виджет «Мета»', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-unneeded-widget-meta"
							name="mvweb_so[remove_unneeded_widget_meta]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_unneeded_widget_meta' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-unneeded-widget-rss">
				<?php esc_html_e( 'Виджет «RSS»', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-unneeded-widget-rss"
							name="mvweb_so[remove_unneeded_widget_rss]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_unneeded_widget_rss' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-url-from-comment-form">
				<?php esc_html_e( 'Убрать поле URL из формы комментария', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-url-from-comment-form"
							name="mvweb_so[remove_url_from_comment_form]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_url_from_comment_form' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Убирает популярный канал спама в комментариях — поле «Сайт».', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Admin bar и почтовые уведомления', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Чистка верхней панели и отключение email-уведомлений об обновлениях.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-admin-bar">
				<?php esc_html_e( 'Отключить admin bar', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-admin-bar"
							name="mvweb_so[disable_admin_bar]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_admin_bar' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Скрывает верхнюю чёрную полосу WordPress на фронте для всех ролей, кроме администратора.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-remove-unnecessary-link-admin-bar">
				<?php esc_html_e( 'Удалить ссылки на wordpress.org из admin bar', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-remove-unnecessary-link-admin-bar"
							name="mvweb_so[remove_unnecessary_link_admin_bar]"
							value="on"
							<?php checked( mvweb_so_check_option( 'remove_unnecessary_link_admin_bar' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Первый пункт верхней панели — логотип WordPress со ссылками на wordpress.org, документацию и форумы. Скрывает их.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-email-notification">
				<?php esc_html_e( 'Отключить email-уведомления об обновлениях', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-email-notification"
							name="mvweb_so[disable_email_notification]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_email_notification' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Снимает фильтры auto_core_update_send_email / auto_plugin_update_send_email / auto_theme_update_send_email и debug-письма про автообновления.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>
