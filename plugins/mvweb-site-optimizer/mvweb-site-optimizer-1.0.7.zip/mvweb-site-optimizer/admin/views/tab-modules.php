<?php
/**
 * Modules tab — отключение тяжёлых компонентов ядра WordPress.
 *
 * Phase 6. Комментарии (+ 5 подопций), Gutenberg, классические виджеты,
 * Gravatar, RSS-фиды, admin bar.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Комментарии', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Полное или частичное отключение комментариев и связанной инфраструктуры (UI, XML-RPC, REST API, поле email, IP/User-Agent).', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-comments">
				<?php esc_html_e( 'Отключить комментарии', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-comments"
							name="mvweb_so[disable_comments]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_comments' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Снимает поддержку comments / trackbacks у всех зарегистрированных post-типов. Подопции ниже добавляют слои защиты (UI, XML-RPC, REST API, email-поле в форме, сохранение IP).', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-comments-interface">
				<?php esc_html_e( 'Скрыть интерфейс комментариев', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-comments-interface"
							name="mvweb_so[disable_comments_interface]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_comments_interface' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Убирает пункт «Комментарии» из меню админки, виджет recent comments, виджет в admin bar, REST-эндпоинты /wp/v2/comments, ленту комментариев, dashboard-блок.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-comments-xml-rpc">
				<?php esc_html_e( 'Запретить wp.newComment в XML-RPC', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-comments-xml-rpc"
							name="mvweb_so[disable_comments_xml_rpc]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_comments_xml_rpc' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Удаляет метод wp.newComment из списка XML-RPC. Закрывает популярный канал спама.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-comments-rest-api">
				<?php esc_html_e( 'Запретить создание комментариев через REST API', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-comments-rest-api"
							name="mvweb_so[disable_comments_rest_api]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_comments_rest_api' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'POST /wp-json/wp/v2/comments возвращает 403 «Комментарии отключены».', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-comments-email-field">
				<?php esc_html_e( 'Убрать поле Email из формы', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-comments-email-field"
							name="mvweb_so[disable_comments_email_field]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_comments_email_field' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Удаляет поле Email из стандартной формы добавления комментария. Полезно, если в Настройки → Обсуждение разрешены анонимные комментарии.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-comments-save-ip">
				<?php esc_html_e( 'Не сохранять IP и User-Agent', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-comments-save-ip"
							name="mvweb_so[disable_comments_save_ip]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_comments_save_ip' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'И IP-адрес, и User-Agent комментаторов сохраняются пустыми (опция исторически называется save_ip, но затрагивает оба поля). Соответствие требованиям GDPR/152-ФЗ при необходимости.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Gutenberg', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'С версии WordPress 5.0 редактор записей и виджетов работает на блочной системе Gutenberg. Если у вас активно используется Classic Editor, ACF, page builder или нестандартные метабоксы — Gutenberg может конфликтовать. Здесь возврат к классическим интерфейсам.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-gutenberg">
				<?php esc_html_e( 'Отключить Gutenberg', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-gutenberg"
							name="mvweb_so[disable_gutenberg]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_gutenberg' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Переключает редактирование всех типов записей на Classic Editor. На фронте больше не подключаются стили wp-block-library и global-styles — это экономит 25–40 КБ на каждой странице.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-gutenberg-widgets">
				<?php esc_html_e( 'Отключить виджеты Gutenberg', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-gutenberg-widgets"
							name="mvweb_so[disable_gutenberg_widgets]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_gutenberg_widgets' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'В WordPress 5.8 экран виджетов переехал на блочный редактор — неудобно для многих и не всем нужно. Опция возвращает классический drag-and-drop. Аналог плагина Classic Widgets.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Транслитерация', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Преобразует кириллицу в латиницу для адресов записей, рубрик, меток и для имён загружаемых файлов. Например, запись «Привет, мир!» получит адрес /privet-mir/, а файл «картинка.jpg» сохранится как kartinka.jpg.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-transliteration">
				<?php esc_html_e( 'Включить транслитерацию URL и файлов', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-transliteration"
							name="mvweb_so[transliteration]"
							value="on"
							<?php checked( mvweb_so_check_option( 'transliteration' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Срабатывает при создании новой записи или загрузке файла. На уже опубликованные записи и старые файлы не действует — там адрес и имя останутся прежними.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Gravatar', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Аватары авторов комментариев загружаются с внешнего сервера gravatar.com — это дополнительный запрос на каждой странице с комментариями. Если комментариев нет или они не важны — отключите загрузку, аватары заменятся на локальный плейсхолдер.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-gravatar">
				<?php esc_html_e( 'Отключить Gravatar', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-gravatar"
							name="mvweb_so[disable_gravatar]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_gravatar' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'pre_get_avatar_data → подмена URL на /images/default-avatar.png. Сайт перестаёт отправлять MD5-хэш email в gravatar.com. Один из ключевых пунктов GDPR-чек-листа.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'RSS-фиды', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'RSS, Atom и RDF — каналы синдикации, по которым внешние сервисы могут забирать тексты записей. Для статейных сайтов, корпоративных сайтов и сайтов-визиток это часто канал воровства контента. Если ленту никто из читателей не использует — отключите.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-feed">
				<?php esc_html_e( 'Отключить RSS-ленты', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-feed"
							name="mvweb_so[disable_feed]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_feed' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Все запросы к /feed/, /rss/, /atom/, /comments/feed/ возвращают 301-редирект на главную. Ссылки feed_links и feed_links_extra удаляются из исходников страницы.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

