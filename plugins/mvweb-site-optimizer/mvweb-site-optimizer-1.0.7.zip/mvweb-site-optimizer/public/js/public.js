/**
 * Public (frontend) JavaScript for MVweb Site Optimizer.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		// Frontend initialization.
	});
})();
