<?php
/**
 * General tab — status card, planned modules overview, Export/Import.
 *
 * Phase 1. No optimization features here — only meta-controls
 * (settings export/import, version info, links to other tabs).
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Tab_General {

	const EXTRA_OPTIONS = array(
		'mvweb_so_redirects',
		'mvweb_so_indexnow_key',
		'mvweb_so_indexnow_log',
		'mvweb_so_login_attempts_state',
	);

	public function __construct() {
		if ( is_admin() ) {
			add_action( 'wp_ajax_mvweb_so_export_settings', array( $this, 'ajax_export' ) );
			add_action( 'wp_ajax_mvweb_so_import_settings', array( $this, 'ajax_import' ) );
			add_action( 'wp_ajax_mvweb_so_reset_settings', array( $this, 'ajax_reset' ) );
		}
	}

	public function ajax_export(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Недостаточно прав.', 'mvweb-site-optimizer' ) ),
				403
			);
		}

		check_ajax_referer( 'mvweb_so_ajax', 'nonce' );

		$payload = $this->build_export_payload();
		$json    = wp_json_encode( $payload, JSON_UNESCAPED_UNICODE );

		if ( false === $json ) {
			wp_send_json_error(
				array( 'message' => __( 'Не удалось сериализовать настройки.', 'mvweb-site-optimizer' ) ),
				500
			);
		}

		wp_send_json_success(
			array(
				'data'     => base64_encode( $json ),
				'filename' => sprintf(
					'mvweb-site-optimizer-%s-%s.json',
					gmdate( 'Y-m-d-His' ),
					wp_generate_password( 6, false, false )
				),
				'features' => mvweb_so_count_active_features(),
			)
		);
	}

	public function ajax_import(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Недостаточно прав.', 'mvweb-site-optimizer' ) ),
				403
			);
		}

		check_ajax_referer( 'mvweb_so_ajax', 'nonce' );

		$raw = isset( $_POST['payload'] ) ? wp_unslash( $_POST['payload'] ) : '';
		$raw = is_string( $raw ) ? trim( $raw ) : '';

		if ( '' === $raw ) {
			wp_send_json_error(
				array( 'message' => __( 'Пустая строка импорта.', 'mvweb-site-optimizer' ) )
			);
		}

		$json = base64_decode( $raw, true );
		if ( false === $json ) {
			$json = $raw;
		}

		$data = json_decode( (string) $json, true );

		if ( ! is_array( $data ) || ! isset( $data['plugin'] ) || 'mvweb-site-optimizer' !== $data['plugin'] ) {
			wp_send_json_error(
				array( 'message' => __( 'Неверный формат файла. Ожидался экспорт MVweb Site Optimizer.', 'mvweb-site-optimizer' ) )
			);
		}

		// Совместимость по MAJOR-версии: 1.x.y экспорт можно загрузить в 1.x.y,
		// но не в 2.x.y — структура опций может несовместимо измениться.
		if ( isset( $data['version'] ) && is_string( $data['version'] ) && defined( 'MVWEB_SO_VERSION' ) ) {
			$source_major  = (int) strtok( (string) $data['version'], '.' );
			$current_major = (int) strtok( (string) MVWEB_SO_VERSION, '.' );
			if ( $source_major !== $current_major ) {
				wp_send_json_error(
					array(
						'message' => sprintf(
							/* translators: 1: source version, 2: current version */
							__( 'Экспорт сделан в версии %1$s, установлена несовместимая версия %2$s. Импорт отменён.', 'mvweb-site-optimizer' ),
							$data['version'],
							MVWEB_SO_VERSION
						),
					)
				);
			}
		}

		$sanitized = $this->sanitize_import_payload( $data );

		update_option( MVWEB_SO_OPTION, $sanitized['settings'], false );

		foreach ( self::EXTRA_OPTIONS as $extra_key ) {
			if ( array_key_exists( $extra_key, $sanitized['extras'] ) ) {
				update_option( $extra_key, $sanitized['extras'][ $extra_key ], false );
			}
		}

		wp_send_json_success(
			array(
				'message'  => __( 'Настройки импортированы.', 'mvweb-site-optimizer' ),
				'features' => mvweb_so_count_active_features(),
			)
		);
	}

	public function ajax_reset(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Недостаточно прав.', 'mvweb-site-optimizer' ) ),
				403
			);
		}

		check_ajax_referer( 'mvweb_so_ajax', 'nonce' );

		update_option( MVWEB_SO_OPTION, array(), false );

		foreach ( self::EXTRA_OPTIONS as $extra_key ) {
			delete_option( $extra_key );
		}

		// Чистим зарегистрированные cron-события и debounce-transients —
		// иначе они срабатывают вхолостую после полного сброса.
		wp_clear_scheduled_hook( 'mvweb_so_indexnow_dispatch' );
		wp_clear_scheduled_hook( 'mvweb_so_login_attempts_cleanup' );
		delete_transient( 'mvweb_so_indexnow_debounce' );
		delete_transient( 'mvweb_so_sitemap_url' );

		wp_send_json_success(
			array(
				'message'  => __( 'Все настройки сброшены к значениям по умолчанию.', 'mvweb-site-optimizer' ),
				'features' => 0,
			)
		);
	}

	private function build_export_payload(): array {
		$extras = array();
		foreach ( self::EXTRA_OPTIONS as $extra_key ) {
			$value = get_option( $extra_key, null );
			if ( null !== $value ) {
				$extras[ $extra_key ] = $value;
			}
		}

		return array(
			'plugin'    => 'mvweb-site-optimizer',
			'version'   => MVWEB_SO_VERSION,
			'exported'  => gmdate( 'c' ),
			'site_url'  => home_url(),
			'settings'  => mvweb_so_get_settings(),
			'extras'    => $extras,
		);
	}

	private function sanitize_import_payload( array $data ): array {
		$settings = array();

		// Whitelist ключей — только те, что зарегистрированы в ALLOWED_KEYS табов.
		// Защита от mass-assignment произвольных опций через подделанный JSON.
		$allowed_keys = $this->collect_known_setting_keys();

		if ( isset( $data['settings'] ) && is_array( $data['settings'] ) ) {
			foreach ( $data['settings'] as $key => $value ) {
				$clean_key = sanitize_key( (string) $key );
				if ( '' === $clean_key || ! isset( $allowed_keys[ $clean_key ] ) ) {
					continue;
				}

				if ( is_array( $value ) ) {
					$settings[ $clean_key ] = $this->deep_sanitize( $value );
				} elseif ( is_scalar( $value ) ) {
					// sanitize_textarea_field сохраняет переносы строк — важно для
					// многострочных опций (robots_txt_text, login_attempts_*list, ...).
					$settings[ $clean_key ] = sanitize_textarea_field( (string) $value );
				}
			}
		}

		$extras = array();
		if ( isset( $data['extras'] ) && is_array( $data['extras'] ) ) {
			foreach ( self::EXTRA_OPTIONS as $extra_key ) {
				if ( array_key_exists( $extra_key, $data['extras'] ) ) {
					$extras[ $extra_key ] = $this->deep_sanitize( $data['extras'][ $extra_key ] );
				}
			}
		}

		return array(
			'settings' => $settings,
			'extras'   => $extras,
		);
	}

	/**
	 * Recursively sanitize arbitrary nested structures (arrays of scalars).
	 *
	 * Used for extras (redirects, indexnow log) where structure is decided
	 * by individual tab modules later. We don't strip keys at this layer —
	 * each module re-sanitizes its option on read/save anyway.
	 *
	 * @param mixed $value
	 * @return mixed
	 */
	private function deep_sanitize( $value ) {
		if ( is_array( $value ) ) {
			$out = array();
			foreach ( $value as $k => $v ) {
				$clean_k         = is_string( $k ) ? sanitize_key( $k ) : $k;
				$out[ $clean_k ] = $this->deep_sanitize( $v );
			}
			return $out;
		}

		if ( is_bool( $value ) || is_int( $value ) || is_float( $value ) ) {
			return $value;
		}

		if ( is_string( $value ) ) {
			// Multi-line строки сохраняются (robots.txt и т.п.) — но HTML-теги
			// убираем как и в обычном sanitize_text_field.
			return sanitize_textarea_field( $value );
		}

		return '';
	}

	/**
	 * Собирает белый список ключей опций со всех табов.
	 * Используется при импорте — отсекаем неизвестные ключи.
	 */
	private function collect_known_setting_keys(): array {
		$classes = array(
			'MVweb_SO_Tab_Code',
			'MVweb_SO_Tab_Seo',
			'MVweb_SO_Tab_Duplicate',
			'MVweb_SO_Tab_Security',
			'MVweb_SO_Tab_Modules',
			'MVweb_SO_Tab_Additionally',
			'MVweb_SO_Tab_IndexNow',
			'MVweb_SO_Tab_Maintenance',
		);
		$keys = array();
		foreach ( $classes as $class ) {
			if ( class_exists( $class ) && defined( $class . '::ALLOWED_KEYS' ) ) {
				foreach ( $class::ALLOWED_KEYS as $key ) {
					$keys[ $key ] = true;
				}
			}
		}
		return $keys;
	}
}
