<?php
/**
 * IndexNow tab — автоматическая отправка изменений в Яндекс и Bing.
 *
 * Phase 9. Реализация протокола IndexNow:
 * - ключ хранится в опции `mvweb_so_indexnow_key` (autoload=yes — нужен в `init` каждый запрос);
 * - ключевой файл отдаётся виртуально через хук `init` (без записи в корень сайта);
 * - на `transition_post_status` / `wp_trash_post` URL ставится в очередь и отправляется
 *   асинхронно через `wp_schedule_single_event` (дебаунс 60 секунд через transient);
 * - журнал отправок — отдельная опция `mvweb_so_indexnow_log` (autoload=no, ротация 200 записей).
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Tab_IndexNow {

	const OPTION_KEY           = 'mvweb_so_indexnow_key';
	const OPTION_LOG           = 'mvweb_so_indexnow_log';
	const OPTION_QUEUE         = 'mvweb_so_indexnow_queue';
	const CRON_HOOK            = 'mvweb_so_indexnow_dispatch';
	const DEBOUNCE_TRANSIENT   = 'mvweb_so_indexnow_debounce';
	const DEBOUNCE_SECONDS     = 60;
	const LOG_MAX              = 200;
	const KEY_LENGTH           = 32;
	const REQUEST_TIMEOUT      = 8;
	const ENDPOINTS            = array(
		'yandex' => 'https://yandex.com/indexnow',
		'bing'   => 'https://www.bing.com/indexnow',
	);
	const DEFAULT_POST_TYPES   = array( 'post', 'page' );

	const ALLOWED_KEYS = array(
		'indexnow_enabled',
		'indexnow_post_types',
		'indexnow_endpoints',
	);

	public function __construct() {
		add_filter( 'mvweb_so_sanitize_indexnow', array( $this, 'sanitize' ), 10, 2 );

		add_action( 'update_option_' . MVWEB_SO_OPTION, array( $this, 'on_settings_updated' ), 10, 2 );

		if ( mvweb_so_check_option( 'indexnow_enabled' ) ) {
			add_action( 'init', array( $this, 'maybe_serve_key_file' ), 1 );
			add_action( 'transition_post_status', array( $this, 'on_transition_post_status' ), 10, 3 );
			add_action( 'wp_trash_post', array( $this, 'on_trash_post' ), 10, 1 );
			add_action( self::CRON_HOOK, array( $this, 'dispatch_queue' ) );
		}

		if ( is_admin() ) {
			add_action( 'wp_ajax_mvweb_so_indexnow_regenerate_key', array( $this, 'ajax_regenerate_key' ) );
			add_action( 'wp_ajax_mvweb_so_indexnow_clear_log', array( $this, 'ajax_clear_log' ) );
			add_action( 'wp_ajax_mvweb_so_indexnow_send_test', array( $this, 'ajax_send_test' ) );
		}
	}

	public function sanitize( array $accum, array $raw ): array {
		$out = array(
			'indexnow_enabled' => isset( $raw['indexnow_enabled'] ) && 'on' === $raw['indexnow_enabled'] ? 'on' : '',
		);

		$allowed_post_types = array_keys( $this->get_available_post_types() );
		$selected_pt        = isset( $raw['indexnow_post_types'] ) && is_array( $raw['indexnow_post_types'] )
			? array_map( 'sanitize_key', wp_unslash( $raw['indexnow_post_types'] ) )
			: array();

		$out['indexnow_post_types'] = array_values( array_intersect( $allowed_post_types, $selected_pt ) );
		if ( empty( $out['indexnow_post_types'] ) ) {
			$out['indexnow_post_types'] = array();
		}

		$allowed_endpoints = array_keys( self::ENDPOINTS );
		$selected_ep       = isset( $raw['indexnow_endpoints'] ) && is_array( $raw['indexnow_endpoints'] )
			? array_map( 'sanitize_key', wp_unslash( $raw['indexnow_endpoints'] ) )
			: array();

		$out['indexnow_endpoints'] = array_values( array_intersect( $allowed_endpoints, $selected_ep ) );
		if ( empty( $out['indexnow_endpoints'] ) ) {
			$out['indexnow_endpoints'] = array( 'yandex', 'bing' );
		}

		return $out;
	}

	public function get_key(): string {
		$key = (string) get_option( self::OPTION_KEY, '' );
		if ( '' === $key || ! $this->is_valid_key( $key ) ) {
			$key = $this->generate_key();
			update_option( self::OPTION_KEY, $key, true );
		}
		return $key;
	}

	public function get_available_post_types(): array {
		$types     = get_post_types( array( 'public' => true ), 'objects' );
		$available = array();
		foreach ( $types as $slug => $obj ) {
			if ( 'attachment' === $slug ) {
				continue;
			}
			$available[ $slug ] = $obj->labels->singular_name ?? $slug;
		}
		return $available;
	}

	public function get_selected_post_types(): array {
		$selected = mvweb_so_get_option( 'indexnow_post_types', null );
		if ( ! is_array( $selected ) || empty( $selected ) ) {
			return self::DEFAULT_POST_TYPES;
		}
		return $selected;
	}

	public function get_selected_endpoints(): array {
		$selected = mvweb_so_get_option( 'indexnow_endpoints', null );
		if ( ! is_array( $selected ) || empty( $selected ) ) {
			return array_keys( self::ENDPOINTS );
		}
		return $selected;
	}

	public function maybe_serve_key_file(): void {
		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( '' === $request_uri ) {
			return;
		}

		$path = wp_parse_url( $request_uri, PHP_URL_PATH );
		if ( ! is_string( $path ) || '' === $path ) {
			return;
		}

		$basename = basename( $path );
		if ( '' === $basename || ! preg_match( '/^[a-f0-9]{8,128}\.txt$/i', $basename ) ) {
			return;
		}

		$key = (string) get_option( self::OPTION_KEY, '' );
		if ( '' === $key || strtolower( $basename ) !== strtolower( $key . '.txt' ) ) {
			return;
		}

		nocache_headers();
		header( 'Content-Type: text/plain; charset=UTF-8' );
		echo $key; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- key is hex-only, validated above.
		exit;
	}

	public function on_transition_post_status( string $new_status, string $old_status, $post ): void {
		if ( 'publish' !== $new_status ) {
			return;
		}

		if ( ! $post instanceof WP_Post ) {
			return;
		}

		if ( wp_is_post_revision( $post ) || wp_is_post_autosave( $post ) ) {
			return;
		}

		$selected_types = $this->get_selected_post_types();
		if ( ! in_array( $post->post_type, $selected_types, true ) ) {
			return;
		}

		$url = get_permalink( $post );
		if ( ! is_string( $url ) || '' === $url ) {
			return;
		}

		$this->enqueue_url( $url );
	}

	public function on_trash_post( int $post_id ): void {
		$post = get_post( $post_id );
		if ( ! $post instanceof WP_Post ) {
			return;
		}

		$selected_types = $this->get_selected_post_types();
		if ( ! in_array( $post->post_type, $selected_types, true ) ) {
			return;
		}

		$url = get_permalink( $post );
		if ( ! is_string( $url ) || '' === $url ) {
			return;
		}

		$this->enqueue_url( $url );
	}

	public function enqueue_url( string $url ): void {
		$queue = get_option( self::OPTION_QUEUE, array() );
		if ( ! is_array( $queue ) ) {
			$queue = array();
		}

		if ( ! in_array( $url, $queue, true ) ) {
			$queue[] = $url;
			update_option( self::OPTION_QUEUE, $queue, false );
		}

		if ( get_transient( self::DEBOUNCE_TRANSIENT ) ) {
			return;
		}

		set_transient( self::DEBOUNCE_TRANSIENT, '1', self::DEBOUNCE_SECONDS );

		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_single_event( time() + self::DEBOUNCE_SECONDS, self::CRON_HOOK );
		}
	}

	public function dispatch_queue(): void {
		$queue = get_option( self::OPTION_QUEUE, array() );
		if ( ! is_array( $queue ) || empty( $queue ) ) {
			return;
		}

		update_option( self::OPTION_QUEUE, array(), false );

		$urls = array_values( array_unique( array_filter( $queue, 'is_string' ) ) );
		if ( empty( $urls ) ) {
			return;
		}

		$this->send_urls( $urls );
	}

	public function send_urls( array $urls ): array {
		$key       = $this->get_key();
		$host      = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$endpoints = $this->get_selected_endpoints();
		$results   = array();

		if ( empty( $endpoints ) || empty( $urls ) || '' === $host ) {
			return $results;
		}

		$payload = wp_json_encode(
			array(
				'host'        => $host,
				'key'         => $key,
				'keyLocation' => home_url( '/' . $key . '.txt' ),
				'urlList'     => $urls,
			)
		);

		if ( false === $payload ) {
			return $results;
		}

		foreach ( $endpoints as $slug ) {
			if ( ! isset( self::ENDPOINTS[ $slug ] ) ) {
				continue;
			}

			$response = wp_remote_post(
				self::ENDPOINTS[ $slug ],
				array(
					'timeout'     => self::REQUEST_TIMEOUT,
					'redirection' => 0,
					'headers'     => array(
						'Content-Type' => 'application/json; charset=utf-8',
						'Accept'       => 'application/json',
					),
					'body'        => $payload,
				)
			);

			$status  = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
			$message = is_wp_error( $response ) ? $response->get_error_message() : wp_remote_retrieve_response_message( $response );

			foreach ( $urls as $url ) {
				$this->log_entry(
					array(
						'url'      => $url,
						'endpoint' => $slug,
						'status'   => $status,
						'message'  => (string) $message,
						'sent_at'  => time(),
					)
				);
			}

			$results[ $slug ] = array(
				'status'  => $status,
				'message' => (string) $message,
			);
		}

		return $results;
	}

	public function ajax_regenerate_key(): void {
		$this->check_ajax();

		$key = $this->generate_key();
		update_option( self::OPTION_KEY, $key, true );

		wp_send_json_success(
			array(
				'message'      => __( 'Ключ обновлён.', 'mvweb-site-optimizer' ),
				'key'          => $key,
				'key_url'      => home_url( '/' . $key . '.txt' ),
				'key_location' => home_url( '/' . $key . '.txt' ),
			)
		);
	}

	public function ajax_clear_log(): void {
		$this->check_ajax();

		update_option( self::OPTION_LOG, array(), false );

		wp_send_json_success(
			array(
				'message' => __( 'Журнал очищен.', 'mvweb-site-optimizer' ),
			)
		);
	}

	public function ajax_send_test(): void {
		$this->check_ajax();

		$home    = home_url( '/' );
		$results = $this->send_urls( array( $home ) );

		if ( empty( $results ) ) {
			wp_send_json_error( array( 'message' => __( 'Не выбран ни один эндпоинт IndexNow или нет URL для отправки.', 'mvweb-site-optimizer' ) ) );
		}

		wp_send_json_success(
			array(
				'message' => __( 'Тестовая отправка выполнена. Проверьте журнал.', 'mvweb-site-optimizer' ),
				'results' => $results,
			)
		);
	}

	public function get_log(): array {
		$log = get_option( self::OPTION_LOG, array() );
		return is_array( $log ) ? $log : array();
	}

	private function log_entry( array $entry ): void {
		$log   = $this->get_log();
		$log[] = $entry;

		if ( count( $log ) > self::LOG_MAX ) {
			$log = array_slice( $log, -self::LOG_MAX );
		}

		update_option( self::OPTION_LOG, $log, false );
	}

	private function check_ajax(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Недостаточно прав.', 'mvweb-site-optimizer' ) ),
				403
			);
		}

		check_ajax_referer( 'mvweb_so_ajax', 'nonce' );
	}

	private function generate_key(): string {
		try {
			return bin2hex( random_bytes( (int) ( self::KEY_LENGTH / 2 ) ) );
		} catch ( Exception $e ) {
			// Fallback: посимвольная выборка из hex-алфавита через wp_rand.
			// wp_rand на современных системах использует random_int → /dev/urandom.
			$hex = '0123456789abcdef';
			$key = '';
			for ( $i = 0; $i < self::KEY_LENGTH; $i++ ) {
				$key .= $hex[ wp_rand( 0, 15 ) ];
			}
			return $key;
		}
	}

	private function is_valid_key( string $key ): bool {
		return (bool) preg_match( '/^[a-f0-9]{8,128}$/i', $key );
	}

	/**
	 * Когда пользователь отключает IndexNow через UI — снимаем зарегистрированный
	 * cron, очищаем debounce-transient и обнуляем очередь, чтобы остатки не
	 * сработали после off.
	 */
	public function on_settings_updated( $old_value, $new_value ): void {
		$was_enabled = is_array( $old_value ) && isset( $old_value['indexnow_enabled'] ) && 'on' === $old_value['indexnow_enabled'];
		$is_enabled  = is_array( $new_value ) && isset( $new_value['indexnow_enabled'] ) && 'on' === $new_value['indexnow_enabled'];

		if ( $was_enabled && ! $is_enabled ) {
			wp_clear_scheduled_hook( self::CRON_HOOK );
			delete_transient( 'mvweb_so_indexnow_debounce' );
		}
	}
}
