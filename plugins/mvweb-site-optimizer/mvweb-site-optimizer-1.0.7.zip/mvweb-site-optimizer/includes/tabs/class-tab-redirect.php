<?php
/**
 * Redirect tab — менеджер 301/302 редиректов.
 *
 * Phase 8. Таблица правил from → to с поддержкой exact и regex режимов.
 * Хранилище — отдельная опция `mvweb_so_redirects` с autoload=no
 * (большие сущности не в основной `mvweb_so_settings`).
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Tab_Redirect {

	const OPTION_KEY    = 'mvweb_so_redirects';
	const ALLOWED_TYPES = array( 301, 302 );
	const ALLOWED_MODES = array( 'exact', 'regex' );
	// Тестовая строка, провоцирующая catastrophic backtracking у уязвимых regex.
	// Длинная последовательность 'a' без терминатора → паттерны вида (a+)+$, (a|a)+$
	// уйдут в exponential backtracking и упрутся в PREG_BACKTRACK_LIMIT_ERROR за ~50 ms.
	const REGEX_PROBE = 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaab';

	public function __construct() {
		if ( is_admin() ) {
			add_action( 'wp_ajax_mvweb_so_redirect_add', array( $this, 'ajax_add' ) );
			add_action( 'wp_ajax_mvweb_so_redirect_update', array( $this, 'ajax_update' ) );
			add_action( 'wp_ajax_mvweb_so_redirect_delete', array( $this, 'ajax_delete' ) );
			add_action( 'wp_ajax_mvweb_so_redirect_toggle', array( $this, 'ajax_toggle' ) );
		}

		add_action( 'template_redirect', array( $this, 'maybe_redirect' ), 1 );
	}

	public function maybe_redirect(): void {
		$rules = $this->get_rules();
		if ( empty( $rules ) ) {
			return;
		}

		$request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$request_uri = $this->normalize_path( $request_uri );

		if ( '' === $request_uri ) {
			return;
		}

		foreach ( $rules as $rule ) {
			if ( empty( $rule['enabled'] ) ) {
				continue;
			}

			$from           = isset( $rule['from'] ) ? (string) $rule['from'] : '';
			$to             = isset( $rule['to'] ) ? (string) $rule['to'] : '';
			$mode           = isset( $rule['mode'] ) && in_array( $rule['mode'], self::ALLOWED_MODES, true ) ? $rule['mode'] : 'exact';
			$type           = isset( $rule['type'] ) && in_array( (int) $rule['type'], self::ALLOWED_TYPES, true ) ? (int) $rule['type'] : 301;
			$allow_external = ! empty( $rule['allow_external'] );

			if ( '' === $from || '' === $to ) {
				continue;
			}

			$target = null;

			if ( 'exact' === $mode ) {
				$from_path = $this->normalize_path( $from );
				if ( '' !== $from_path && $from_path === $request_uri ) {
					$target = $to;
				}
			} else {
				$pattern = $this->build_regex_pattern( $from );
				if ( null === $pattern ) {
					continue;
				}

				$matches = array();
				// Глушим E_WARNING если runtime-движок PCRE упрётся в backtrack_limit (защита уже на save).
				$matched = @preg_match( $pattern, $request_uri, $matches ); // phpcs:ignore WordPress.PHP.NoSilencedErrors

				if ( false === $matched || PREG_NO_ERROR !== preg_last_error() ) {
					continue;
				}

				if ( 1 === $matched ) {
					$expanded = $this->expand_backreferences( $to, $matches );
					$target   = $this->sanitize_to( $expanded, $allow_external );
				}
			}

			if ( null === $target || '' === $target ) {
				continue;
			}

			if ( $allow_external && $this->is_external( $target ) ) {
				wp_redirect( $target, $type ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- explicit opt-in via allow_external flag.
				exit;
			}

			$target_url = $this->absolutize( $target );

			wp_safe_redirect( $target_url, $type );
			exit;
		}
	}

	public function ajax_add(): void {
		$this->check_ajax();

		$rule = $this->extract_rule_from_post();
		if ( is_wp_error( $rule ) ) {
			wp_send_json_error( array( 'message' => $rule->get_error_message() ) );
		}

		$added_rule = null;

		$result = $this->mutate_rules_cas(
			function ( $rules ) use ( $rule, &$added_rule ) {
				if ( $this->has_duplicate_from( $rules, $rule['from'], $rule['mode'] ) ) {
					return new WP_Error( 'mvweb_so_duplicate', __( 'Правило с таким адресом уже существует.', 'mvweb-site-optimizer' ) );
				}
				$rule['id']      = $this->next_id( $rules );
				$rule['enabled'] = 1;
				$rules[]         = $rule;
				$added_rule      = $rule;
				return $rules;
			}
		);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				'message' => __( 'Правило добавлено.', 'mvweb-site-optimizer' ),
				'rule'    => $added_rule,
				'count'   => count( $result ),
			)
		);
	}

	public function ajax_update(): void {
		$this->check_ajax();

		$id = isset( $_POST['id'] ) ? (int) wp_unslash( $_POST['id'] ) : 0;
		if ( $id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Не указан идентификатор правила.', 'mvweb-site-optimizer' ) ) );
		}

		$rule = $this->extract_rule_from_post();
		if ( is_wp_error( $rule ) ) {
			wp_send_json_error( array( 'message' => $rule->get_error_message() ) );
		}

		$updated_rule = null;

		$result = $this->mutate_rules_cas(
			function ( $rules ) use ( $id, $rule, &$updated_rule ) {
				if ( $this->has_duplicate_from( $rules, $rule['from'], $rule['mode'], $id ) ) {
					return new WP_Error( 'mvweb_so_duplicate', __( 'Правило с таким адресом уже существует.', 'mvweb-site-optimizer' ) );
				}
				$found = false;
				foreach ( $rules as $index => $existing ) {
					if ( (int) $existing['id'] === $id ) {
						$rule['id']      = $id;
						$rule['enabled'] = isset( $existing['enabled'] ) ? (int) $existing['enabled'] : 1;
						$rules[ $index ] = $rule;
						$updated_rule    = $rule;
						$found           = true;
						break;
					}
				}
				if ( ! $found ) {
					return new WP_Error( 'mvweb_so_not_found', __( 'Правило не найдено.', 'mvweb-site-optimizer' ) );
				}
				return $rules;
			}
		);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				'message' => __( 'Правило обновлено.', 'mvweb-site-optimizer' ),
				'rule'    => $updated_rule,
			)
		);
	}

	public function ajax_delete(): void {
		$this->check_ajax();

		$id = isset( $_POST['id'] ) ? (int) wp_unslash( $_POST['id'] ) : 0;
		if ( $id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Не указан идентификатор правила.', 'mvweb-site-optimizer' ) ) );
		}

		$result = $this->mutate_rules_cas(
			function ( $rules ) use ( $id ) {
				$new_rules = array();
				foreach ( $rules as $existing ) {
					if ( (int) $existing['id'] !== $id ) {
						$new_rules[] = $existing;
					}
				}
				if ( count( $new_rules ) === count( $rules ) ) {
					return new WP_Error( 'mvweb_so_not_found', __( 'Правило не найдено.', 'mvweb-site-optimizer' ) );
				}
				return $new_rules;
			}
		);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success(
			array(
				'message' => __( 'Правило удалено.', 'mvweb-site-optimizer' ),
				'count'   => count( $result ),
			)
		);
	}

	public function ajax_toggle(): void {
		$this->check_ajax();

		$id = isset( $_POST['id'] ) ? (int) wp_unslash( $_POST['id'] ) : 0;
		if ( $id <= 0 ) {
			wp_send_json_error( array( 'message' => __( 'Не указан идентификатор правила.', 'mvweb-site-optimizer' ) ) );
		}

		$new_state = 0;

		$result = $this->mutate_rules_cas(
			function ( $rules ) use ( $id, &$new_state ) {
				$found = false;
				foreach ( $rules as $index => $existing ) {
					if ( (int) $existing['id'] === $id ) {
						$current                    = isset( $existing['enabled'] ) ? (int) $existing['enabled'] : 1;
						$rules[ $index ]['enabled'] = $current ? 0 : 1;
						$new_state                  = $rules[ $index ]['enabled'];
						$found                      = true;
						break;
					}
				}
				if ( ! $found ) {
					return new WP_Error( 'mvweb_so_not_found', __( 'Правило не найдено.', 'mvweb-site-optimizer' ) );
				}
				return $rules;
			}
		);

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
		}

		wp_send_json_success( array( 'enabled' => (int) $new_state ) );
	}

	public function get_rules(): array {
		// get_option уже использует WP-Core кэш в пределах запроса (memo_get_option / wp_cache).
		// Дополнительный кэш-слой опасен: он переживёт мутацию через wp-cli или внешний код,
		// который не пройдёт через save_rules(), и фронт продолжит отдавать старые правила.
		$rules = get_option( self::OPTION_KEY, array() );
		return is_array( $rules ) ? array_values( $rules ) : array();
	}

	private function check_ajax(): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Недостаточно прав.', 'mvweb-site-optimizer' ) ),
				403
			);
		}

		check_ajax_referer( 'mvweb_so_ajax', 'nonce' );
	}

	private function extract_rule_from_post() {
		$from           = isset( $_POST['from'] ) ? trim( (string) wp_unslash( $_POST['from'] ) ) : '';
		$to             = isset( $_POST['to'] ) ? trim( (string) wp_unslash( $_POST['to'] ) ) : '';
		$type           = isset( $_POST['type'] ) ? (int) wp_unslash( $_POST['type'] ) : 301;
		$mode           = isset( $_POST['mode'] ) ? sanitize_key( (string) wp_unslash( $_POST['mode'] ) ) : 'exact';
		$allow_external = isset( $_POST['allow_external'] ) ? (int) rest_sanitize_boolean( wp_unslash( $_POST['allow_external'] ) ) : 0;

		if ( '' === $from ) {
			return new WP_Error( 'mvweb_so_empty_from', __( 'Укажите адрес «Откуда».', 'mvweb-site-optimizer' ) );
		}

		if ( '' === $to ) {
			return new WP_Error( 'mvweb_so_empty_to', __( 'Укажите адрес «Куда».', 'mvweb-site-optimizer' ) );
		}

		if ( ! in_array( $type, self::ALLOWED_TYPES, true ) ) {
			$type = 301;
		}

		if ( ! in_array( $mode, self::ALLOWED_MODES, true ) ) {
			$mode = 'exact';
		}

		if ( 'regex' === $mode ) {
			$pattern = $this->build_regex_pattern( $from );
			if ( null === $pattern ) {
				return new WP_Error( 'mvweb_so_invalid_regex', __( 'Некорректное регулярное выражение в поле «Откуда».', 'mvweb-site-optimizer' ) );
			}
		}

		$sanitized_to = $this->sanitize_to( $to, (bool) $allow_external );
		if ( '' === $sanitized_to ) {
			return new WP_Error( 'mvweb_so_invalid_to', __( 'Адрес «Куда» содержит запрещённую схему или формат.', 'mvweb-site-optimizer' ) );
		}

		return array(
			'from'           => $this->sanitize_from( $from, $mode ),
			'to'             => $sanitized_to,
			'type'           => $type,
			'mode'           => $mode,
			'allow_external' => $allow_external,
		);
	}

	private function sanitize_from( string $from, string $mode ): string {
		if ( 'regex' === $mode ) {
			return wp_strip_all_tags( $from );
		}

		$path = wp_parse_url( $from, PHP_URL_PATH );
		if ( is_string( $path ) && '' !== $path ) {
			return $this->normalize_path( $path );
		}

		return $this->normalize_path( $from );
	}

	private function sanitize_to( string $to, bool $allow_external ): string {
		$to = wp_strip_all_tags( $to );

		if ( '' === $to ) {
			return '';
		}

		if ( str_starts_with( $to, '//' ) ) {
			return '';
		}

		$scheme = wp_parse_url( $to, PHP_URL_SCHEME );
		if ( is_string( $scheme ) && '' !== $scheme && ! in_array( strtolower( $scheme ), array( 'http', 'https' ), true ) ) {
			return '';
		}

		if ( $this->is_external( $to ) ) {
			if ( ! $allow_external ) {
				return '';
			}
			return esc_url_raw( $to );
		}

		return $this->normalize_path( $to );
	}

	private function normalize_path( string $path ): string {
		$path = wp_strip_all_tags( $path );

		if ( '' === $path ) {
			return '';
		}

		$question = strpos( $path, '?' );
		$query    = '';
		if ( false !== $question ) {
			$query = substr( $path, $question );
			$path  = substr( $path, 0, $question );
		}

		if ( '' === $path ) {
			$path = '/';
		}

		if ( '/' !== $path[0] ) {
			$path = '/' . $path;
		}

		return $path . $query;
	}

	private function is_external( string $target ): bool {
		if ( '' === $target ) {
			return false;
		}

		if ( ! str_starts_with( $target, 'http://' ) && ! str_starts_with( $target, 'https://' ) ) {
			return false;
		}

		$host = wp_parse_url( $target, PHP_URL_HOST );
		$home = wp_parse_url( home_url(), PHP_URL_HOST );

		return $host && $home && strtolower( $host ) !== strtolower( $home );
	}

	private function absolutize( string $target ): string {
		if ( str_starts_with( $target, 'http://' ) || str_starts_with( $target, 'https://' ) ) {
			return $target;
		}

		return home_url( $target );
	}

	private function build_regex_pattern( string $from ): ?string {
		if ( '' === $from ) {
			return null;
		}

		if ( str_contains( $from, '#' ) ) {
			return null;
		}

		$pattern = '#' . $from . '#';

		// Глушим E_WARNING от preg_match при невалидной компиляции — нам важен только результат.
		// false → синтаксис кривой; PREG_BACKTRACK_LIMIT_ERROR → паттерн уязвим к ReDoS на REGEX_PROBE.
		// PREG_NO_ERROR → ОК (как match=0, так и match=1 — оба валидны для проверки компиляции/линейности).
		$check = @preg_match( $pattern, self::REGEX_PROBE ); // phpcs:ignore WordPress.PHP.NoSilencedErrors -- intentional: ReDoS / compile error check below.
		if ( false === $check || PREG_NO_ERROR !== preg_last_error() ) {
			return null;
		}

		return $pattern;
	}

	private function expand_backreferences( string $target, array $matches ): string {
		if ( empty( $matches ) ) {
			return $target;
		}

		$count = count( $matches );

		for ( $i = $count - 1; $i >= 0; $i-- ) {
			$target = str_replace( '$' . $i, (string) $matches[ $i ], $target );
		}

		return $target;
	}

	private function next_id( array $rules ): int {
		$max = 0;
		foreach ( $rules as $rule ) {
			$id = isset( $rule['id'] ) ? (int) $rule['id'] : 0;
			if ( $id > $max ) {
				$max = $id;
			}
		}
		return $max + 1;
	}

	private function has_duplicate_from( array $rules, string $from, string $mode, int $exclude_id = 0 ): bool {
		foreach ( $rules as $rule ) {
			$existing_id = isset( $rule['id'] ) ? (int) $rule['id'] : 0;
			if ( $exclude_id > 0 && $existing_id === $exclude_id ) {
				continue;
			}
			$existing_from = isset( $rule['from'] ) ? (string) $rule['from'] : '';
			$existing_mode = isset( $rule['mode'] ) ? (string) $rule['mode'] : 'exact';
			if ( $existing_from === $from && $existing_mode === $mode ) {
				return true;
			}
		}
		return false;
	}

	private function save_rules( array $rules ): void {
		// Cache invalidation is handled by the update_option_{key} hook registered in __construct().
		update_option( self::OPTION_KEY, array_values( $rules ), false );
	}

	/**
	 * Атомарный read-modify-write для правил redirect через MySQL CAS.
	 *
	 * Параллельные AJAX-запросы админа (add/update/delete/toggle) иначе
	 * могут потерять чужие изменения через классический update_option-цикл.
	 *
	 * @param callable $mutator (array $rules) => array|WP_Error|null. null = no-op.
	 * @return array|WP_Error Финальный массив правил или WP_Error из мутатора.
	 */
	private function mutate_rules_cas( callable $mutator ) {
		global $wpdb;

		for ( $attempt = 0; $attempt < 5; $attempt++ ) {
			wp_cache_delete( self::OPTION_KEY, 'options' );

			$row = $wpdb->get_row(
				$wpdb->prepare(
					"SELECT option_id, option_value FROM {$wpdb->options} WHERE option_name = %s LIMIT 1",
					self::OPTION_KEY
				)
			);

			if ( $row ) {
				$raw_value = (string) $row->option_value;
				$current   = maybe_unserialize( $raw_value );
				$rules     = is_array( $current ) ? array_values( $current ) : array();
			} else {
				$raw_value = null;
				$rules     = array();
			}

			$result = call_user_func( $mutator, $rules );

			if ( null === $result ) {
				return $rules;
			}

			if ( is_wp_error( $result ) ) {
				return $result;
			}

			if ( ! is_array( $result ) ) {
				return new WP_Error( 'mvweb_so_redirect_cas', __( 'Не удалось сохранить правила.', 'mvweb-site-optimizer' ) );
			}

			$new_rules = array_values( $result );

			if ( null === $raw_value ) {
				$inserted = $wpdb->query(
					$wpdb->prepare(
						"INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, %s)",
						self::OPTION_KEY,
						maybe_serialize( $new_rules ),
						'no'
					)
				);
				wp_cache_delete( self::OPTION_KEY, 'options' );
				if ( $inserted ) {
					return $new_rules;
				}
				usleep( 1000 * ( $attempt + 1 ) );
				continue;
			}

			$updated = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$wpdb->options} SET option_value = %s WHERE option_id = %d AND option_value = %s",
					maybe_serialize( $new_rules ),
					(int) $row->option_id,
					$raw_value
				)
			);
			wp_cache_delete( self::OPTION_KEY, 'options' );

			if ( $updated ) {
				return $new_rules;
			}

			usleep( 1000 * ( $attempt + 1 ) );
		}

		return new WP_Error( 'mvweb_so_redirect_cas_failed', __( 'Не удалось сохранить правила — слишком много параллельных запросов. Попробуйте снова.', 'mvweb-site-optimizer' ) );
	}
}
