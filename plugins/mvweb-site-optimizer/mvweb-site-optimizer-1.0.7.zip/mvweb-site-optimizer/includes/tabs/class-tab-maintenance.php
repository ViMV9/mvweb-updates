<?php
/**
 * Maintenance tab — режим обслуживания сайта.
 *
 * Phase 10. Главный toggle `maintenance_enabled` отправляет HTTP 503
 * + кастомную страницу-заглушку всем неавторизованным посетителям.
 * Whitelist IP позволяет админу тестировать сайт без редиректа.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Tab_Maintenance {

	const ALLOWED_KEYS = array(
		'maintenance_enabled',
		'maintenance_title',
		'maintenance_text',
		'maintenance_retry_after',
		'maintenance_whitelist',
	);

	const DEFAULT_RETRY_AFTER = 3600;
	const MAX_RETRY_AFTER     = 86400;

	public function __construct() {
		if ( is_admin() ) {
			add_filter( 'mvweb_so_sanitize_maintenance', array( $this, 'sanitize' ), 10, 2 );
		}

		if ( mvweb_so_check_option( 'maintenance_enabled' ) ) {
			add_action( 'template_redirect', array( $this, 'maybe_render_maintenance' ), 1 );
			add_filter( 'rest_authentication_errors', array( $this, 'maybe_block_rest' ), 99 );
		}
	}

	public function maybe_render_maintenance(): void {
		if ( is_admin() ) {
			return;
		}

		if ( defined( 'DOING_CRON' ) && DOING_CRON ) {
			return;
		}

		if ( defined( 'WP_CLI' ) && WP_CLI ) {
			return;
		}

		if ( current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( $this->is_whitelisted_ip() ) {
			return;
		}

		$this->render_maintenance_page();
	}

	public function maybe_block_rest( $access ) {
		if ( ! empty( $access ) ) {
			return $access;
		}

		if ( current_user_can( 'manage_options' ) ) {
			return $access;
		}

		if ( $this->is_whitelisted_ip() ) {
			return $access;
		}

		return new WP_Error(
			'mvweb_so_maintenance_mode',
			__( 'Сайт временно недоступен — ведутся технические работы.', 'mvweb-site-optimizer' ),
			array( 'status' => 503 )
		);
	}

	private function is_whitelisted_ip(): bool {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? (string) $_SERVER['REMOTE_ADDR'] : '';
		if ( '' === $ip || ! filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return false;
		}

		$raw = (string) mvweb_so_get_option( 'maintenance_whitelist', '' );
		if ( '' === $raw ) {
			return false;
		}

		foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
			$line = trim( (string) $line );
			if ( '' !== $line && $line === $ip ) {
				return true;
			}
		}

		return false;
	}

	private function render_maintenance_page(): void {
		$title       = (string) mvweb_so_get_option( 'maintenance_title', '' );
		$text        = (string) mvweb_so_get_option( 'maintenance_text', '' );
		$retry_after = (int) mvweb_so_get_option( 'maintenance_retry_after', self::DEFAULT_RETRY_AFTER );

		if ( '' === $title ) {
			$title = __( 'Сайт на техническом обслуживании', 'mvweb-site-optimizer' );
		}

		if ( '' === $text ) {
			$text = __( 'Мы скоро вернёмся. Ведутся плановые работы, пожалуйста, загляните позже.', 'mvweb-site-optimizer' );
		}

		if ( $retry_after < 1 ) {
			$retry_after = self::DEFAULT_RETRY_AFTER;
		}
		if ( $retry_after > self::MAX_RETRY_AFTER ) {
			$retry_after = self::MAX_RETRY_AFTER;
		}

		nocache_headers();
		status_header( 503 );
		header( 'Retry-After: ' . (int) $retry_after );
		header( 'Content-Type: text/html; charset=' . get_bloginfo( 'charset' ) );

		$site_name = get_bloginfo( 'name' );

		?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="robots" content="noindex,nofollow">
	<title><?php echo esc_html( $title ); ?> — <?php echo esc_html( $site_name ); ?></title>
	<style>
		* { box-sizing: border-box; }
		html, body { margin: 0; padding: 0; height: 100%; }
		body {
			font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
			background: #f5f6f8;
			color: #14161b;
			display: flex;
			align-items: center;
			justify-content: center;
			padding: 24px;
		}
		.mvweb-maintenance {
			max-width: 560px;
			width: 100%;
			background: #fff;
			border-radius: 12px;
			box-shadow: 0 12px 32px rgba(20, 22, 27, 0.08);
			padding: 48px 40px;
			text-align: center;
		}
		.mvweb-maintenance__icon {
			width: 56px;
			height: 56px;
			margin: 0 auto 24px;
			color: #793ea4;
		}
		.mvweb-maintenance__title {
			margin: 0 0 16px;
			font-size: 28px;
			font-weight: 600;
			line-height: 1.25;
		}
		.mvweb-maintenance__text {
			margin: 0;
			font-size: 16px;
			line-height: 1.6;
			color: #4a4f5a;
			white-space: pre-wrap;
		}
		.mvweb-maintenance__brand {
			margin-top: 32px;
			font-size: 13px;
			color: #8a8f9a;
		}
	</style>
</head>
<body>
	<main class="mvweb-maintenance">
		<svg class="mvweb-maintenance__icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
			<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>
		</svg>
		<h1 class="mvweb-maintenance__title"><?php echo esc_html( $title ); ?></h1>
		<p class="mvweb-maintenance__text"><?php echo esc_html( $text ); ?></p>
		<div class="mvweb-maintenance__brand"><?php echo esc_html( $site_name ); ?></div>
	</main>
</body>
</html>
		<?php
		exit;
	}

	public function sanitize( $accum, $raw ): array {
		$raw = is_array( $raw ) ? $raw : array();
		$out = array();

		$out['maintenance_enabled'] = isset( $raw['maintenance_enabled'] ) && 'on' === $raw['maintenance_enabled'] ? 'on' : '';

		$out['maintenance_title'] = isset( $raw['maintenance_title'] )
			? sanitize_text_field( (string) $raw['maintenance_title'] )
			: '';

		$out['maintenance_text'] = isset( $raw['maintenance_text'] )
			? sanitize_textarea_field( (string) $raw['maintenance_text'] )
			: '';

		$retry_after = isset( $raw['maintenance_retry_after'] ) ? (int) $raw['maintenance_retry_after'] : self::DEFAULT_RETRY_AFTER;
		if ( $retry_after < 1 ) {
			$retry_after = self::DEFAULT_RETRY_AFTER;
		}
		if ( $retry_after > self::MAX_RETRY_AFTER ) {
			$retry_after = self::MAX_RETRY_AFTER;
		}
		$out['maintenance_retry_after'] = $retry_after;

		$out['maintenance_whitelist'] = $this->sanitize_ip_list( $raw, 'maintenance_whitelist' );

		return $out;
	}

	private function sanitize_ip_list( array $raw, string $key ): string {
		if ( ! isset( $raw[ $key ] ) ) {
			return '';
		}
		$lines = preg_split( '/\r\n|\r|\n/', (string) $raw[ $key ] );
		$out   = array();
		foreach ( (array) $lines as $line ) {
			$line = trim( (string) $line );
			if ( '' !== $line && filter_var( $line, FILTER_VALIDATE_IP ) ) {
				$out[] = $line;
			}
		}
		return implode( "\n", array_unique( $out ) );
	}
}
