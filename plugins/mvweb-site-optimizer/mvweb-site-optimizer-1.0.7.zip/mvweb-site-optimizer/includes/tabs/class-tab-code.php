<?php
/**
 * Code tab — cleanup features (emoji, jQuery Migrate, recent comments style, HTML minify).
 *
 * Phase 2. Каждая фича регистрирует хуки только если опция активирована
 * в `mvweb_so_settings`. Имена опций выбраны для совместимости при миграции
 * настроек с аналогичных плагинов оптимизации.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Tab_Code {

	const ALLOWED_KEYS = array(
		'disable_emoji',
		'remove_jquery_migrate',
		'remove_recent_comments_style',
		'html_minify',
	);

	public function __construct() {
		if ( is_admin() ) {
			add_filter( 'mvweb_so_sanitize_code', array( $this, 'sanitize' ), 10, 2 );
		}

		if ( mvweb_so_check_option( 'disable_emoji' ) ) {
			$this->disable_emoji();
		}

		if ( mvweb_so_check_option( 'remove_jquery_migrate' ) ) {
			add_filter( 'wp_default_scripts', array( $this, 'remove_jquery_migrate' ) );
		}

		if ( mvweb_so_check_option( 'remove_recent_comments_style' ) ) {
			add_action( 'widgets_init', array( $this, 'remove_recent_comments_style' ) );
		}

		if ( mvweb_so_check_option( 'html_minify' ) && ! is_admin() ) {
			add_action( 'template_redirect', array( $this, 'start_html_minify' ), 1 );
		}
	}

	private function disable_emoji(): void {
		remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'wp_print_styles', 'print_emoji_styles' );
		remove_action( 'admin_print_styles', 'print_emoji_styles' );
		remove_filter( 'the_content_feed', 'wp_staticize_emoji' );
		remove_filter( 'comment_text_rss', 'wp_staticize_emoji' );
		remove_filter( 'wp_mail', 'wp_staticize_emoji_for_email' );

		add_filter( 'tiny_mce_plugins', array( $this, 'disable_emoji_tinymce' ) );
		add_filter( 'wp_resource_hints', array( $this, 'disable_emoji_dns_prefetch' ), 10, 2 );
	}

	public function disable_emoji_tinymce( $plugins ) {
		if ( is_array( $plugins ) ) {
			return array_diff( $plugins, array( 'wpemoji' ) );
		}
		return array();
	}

	public function disable_emoji_dns_prefetch( $urls, $relation_type ) {
		if ( 'dns-prefetch' !== $relation_type || ! is_array( $urls ) ) {
			return $urls;
		}

		$emoji_svg_url = apply_filters( 'emoji_svg_url', 'https://s.w.org/images/core/emoji/' );

		foreach ( $urls as $key => $url ) {
			if ( false !== strpos( (string) $url, (string) $emoji_svg_url ) ) {
				unset( $urls[ $key ] );
			}
		}

		return $urls;
	}

	public function remove_jquery_migrate( $scripts ) {
		if ( ! is_object( $scripts ) || ! isset( $scripts->registered['jquery'] ) ) {
			return $scripts;
		}

		$jquery = $scripts->registered['jquery'];

		if ( ! empty( $jquery->deps ) ) {
			$jquery->deps = array_diff( $jquery->deps, array( 'jquery-migrate' ) );
		}

		return $scripts;
	}

	public function remove_recent_comments_style(): void {
		global $wp_widget_factory;

		if ( isset( $wp_widget_factory->widgets['WP_Widget_Recent_Comments'] ) ) {
			remove_action( 'wp_head', array( $wp_widget_factory->widgets['WP_Widget_Recent_Comments'], 'recent_comments_style' ) );
		}
	}

	public function start_html_minify(): void {
		if ( is_feed() || is_admin() ) {
			return;
		}

		if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) {
			return;
		}

		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return;
		}

		ob_start( array( $this, 'minify_html' ) );
	}

	public function minify_html( $buffer ) {
		if ( ! is_string( $buffer ) || '' === trim( $buffer ) ) {
			return $buffer;
		}

		$head_raw = substr( ltrim( $buffer ), 0, 200 );

		if ( '' !== $head_raw && '<' !== $head_raw[0] ) {
			return $buffer;
		}

		// Не минифицируем XML/RSS/SVG/Atom — наша HTML-минификация (схлопывание
		// whitespace и удаление комментариев) ломает XML-prolog, namespace и пробелы
		// внутри значимых тегов.
		$head_lower = strtolower( ltrim( $head_raw ) );

		if (
			0 === strpos( $head_lower, '<?xml' )
			|| 0 === strpos( $head_lower, '<svg' )
			|| false !== strpos( $head_lower, '<rss' )
			|| false !== strpos( $head_lower, '<feed' )
			|| false !== strpos( $head_lower, '<urlset' )
			|| false !== strpos( $head_lower, '<sitemapindex' )
		) {
			return $buffer;
		}

		// Доп. защита через Content-Type, если он уже отправлен.
		if ( function_exists( 'headers_list' ) ) {
			foreach ( headers_list() as $hdr ) {
				$h = strtolower( $hdr );
				if ( 0 !== strpos( $h, 'content-type:' ) ) {
					continue;
				}
				if (
					false !== strpos( $h, 'xml' )
					|| false !== strpos( $h, 'svg' )
					|| false !== strpos( $h, 'json' )
					|| false !== strpos( $h, 'plain' )
					|| false !== strpos( $h, 'javascript' )
				) {
					return $buffer;
				}
				break;
			}
		}

		$placeholders = array();
		$replace      = function ( $pattern ) use ( &$buffer, &$placeholders ) {
			$buffer = preg_replace_callback(
				$pattern,
				static function ( $match ) use ( &$placeholders ) {
					$token                  = '<!--MVWEB_SO_PH_' . count( $placeholders ) . '-->';
					$placeholders[ $token ] = $match[0];
					return $token;
				},
				$buffer
			);
		};

		$replace( '#<pre\b[^>]*>.*?</pre>#is' );
		$replace( '#<textarea\b[^>]*>.*?</textarea>#is' );
		$replace( '#<script\b[^>]*>.*?</script>#is' );
		$replace( '#<style\b[^>]*>.*?</style>#is' );

		$buffer = preg_replace( '/<!--(?!\[if|<!)(?!\s*MVWEB_SO_PH_).*?-->/s', '', $buffer );
		// Сворачиваем whitespace только МЕЖДУ тегами — внутри значимого текста
		// и в значениях атрибутов оставляем как есть (иначе ломаются meta description
		// с переносами строк, JSON-LD внутри отдельных тегов, alt/title-атрибуты и т.д.).
		$buffer = preg_replace( '/>[ \t\r\n]+</', '><', $buffer );

		if ( ! empty( $placeholders ) ) {
			$buffer = strtr( $buffer, $placeholders );
		}

		return $buffer;
	}

	public function sanitize( $accum, $raw ): array {
		$raw = is_array( $raw ) ? $raw : array();
		$out = array();

		foreach ( self::ALLOWED_KEYS as $key ) {
			$out[ $key ] = isset( $raw[ $key ] ) && 'on' === $raw[ $key ] ? 'on' : '';
		}

		return $out;
	}
}
