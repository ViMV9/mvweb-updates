<?php
/**
 * SEO tab — индексация, robots.txt, sitemap, интеграция с Yoast SEO.
 *
 * Phase 3. Имена опций выбраны для совместимости при миграции настроек с
 * аналогичных плагинов оптимизации.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class MVweb_SO_Tab_Seo {

	const ALLOWED_KEYS = array(
		'noindex_pagination',
		'right_robots_txt',
		'robots_txt_text',
		'content_image_auto_alt',
		'wp_sitemaps_xml_disable',
		'wp_sitemaps_xml_disable_users',
		'remove_last_item_breadcrumb_yoast',
		'replace_last_item_breadcrumb_yoast_on_title',
		'yoast_remove_image_from_xml_sitemap',
		'yoast_remove_head_comment',
		'yoast_canonical_pagination',
		'yoast_application_ld_json',
	);

	public function __construct() {
		if ( is_admin() ) {
			add_filter( 'mvweb_so_sanitize_seo', array( $this, 'sanitize' ), 10, 2 );
			add_action( 'wp_ajax_mvweb_so_get_default_robots_txt', array( $this, 'ajax_get_default_robots_txt' ) );
		}

		if ( mvweb_so_check_option( 'noindex_pagination' ) ) {
			$this->register_noindex_pagination();
		}

		if ( mvweb_so_check_option( 'right_robots_txt' ) ) {
			add_filter( 'robots_txt', array( $this, 'render_robots_txt' ), 9999999, 2 );
		}

		if ( mvweb_so_check_option( 'content_image_auto_alt' ) ) {
			add_filter( 'the_content', array( $this, 'content_image_auto_alt' ) );
			add_filter( 'wp_get_attachment_image_attributes', array( $this, 'image_attributes_auto_alt' ), 10, 2 );
		}

		if ( mvweb_so_check_option( 'wp_sitemaps_xml_disable' ) ) {
			add_filter( 'wp_sitemaps_enabled', '__return_false' );
		}

		if ( mvweb_so_check_option( 'wp_sitemaps_xml_disable_users' )
			&& ! mvweb_so_check_option( 'wp_sitemaps_xml_disable' ) ) {
			add_filter( 'wp_sitemaps_add_provider', array( $this, 'disable_sitemap_users_provider' ), 10, 2 );
		}

		add_action( 'plugins_loaded', array( $this, 'register_seo_plugin_integrations' ), 20 );
	}

	public function register_seo_plugin_integrations(): void {
		if ( defined( 'WPSEO_VERSION' ) ) {
			if ( mvweb_so_check_option( 'remove_last_item_breadcrumb_yoast' ) ) {
				add_filter( 'wpseo_breadcrumb_single_link', array( $this, 'remove_last_item_breadcrumb_yoast' ) );
			}

			if ( mvweb_so_check_option( 'replace_last_item_breadcrumb_yoast_on_title' ) ) {
				add_filter( 'wpseo_breadcrumb_single_link', array( $this, 'replace_last_item_breadcrumb_yoast_on_title' ) );
			}

			if ( mvweb_so_check_option( 'yoast_remove_image_from_xml_sitemap' ) ) {
				add_filter( 'wpseo_xml_sitemap_img', '__return_false' );
				add_filter( 'wpseo_sitemap_url', array( $this, 'yoast_remove_image_from_xml_clean' ), 10, 2 );
			}

			if ( mvweb_so_check_option( 'yoast_remove_head_comment' ) ) {
				add_filter( 'wpseo_debug_markers', '__return_false' );
			}

			if ( mvweb_so_check_option( 'yoast_canonical_pagination' ) ) {
				add_filter( 'wpseo_canonical', array( $this, 'canonical_pagination' ), 20 );
			}

			if ( mvweb_so_check_option( 'yoast_application_ld_json' ) ) {
				add_filter( 'wpseo_json_ld_output', '__return_empty_array' );
			}
		}
	}

	private function register_noindex_pagination(): void {
		if ( defined( 'AIOSEO_VERSION' ) ) {
			add_filter( 'aioseo_robots_meta', array( $this, 'noindex_pagination_meta' ) );
			return;
		}

		if ( defined( 'WPSEO_VERSION' ) ) {
			add_filter( 'wpseo_robots', array( $this, 'noindex_pagination_meta' ) );
			return;
		}

		add_action( 'wp_head', array( $this, 'print_noindex_pagination_tag' ), 1 );
	}

	public function print_noindex_pagination_tag(): void {
		if ( is_paged() ) {
			echo '<meta name="robots" content="noindex,follow">' . PHP_EOL;
		}
	}

	public function noindex_pagination_meta( $value ) {
		if ( is_paged() ) {
			return 'noindex,follow';
		}
		return $value;
	}

	public function render_robots_txt( $output, $public ) {
		if ( '0' === (string) $public ) {
			return $output;
		}

		$custom = (string) mvweb_so_get_option( 'robots_txt_text', '' );

		if ( '' !== trim( $custom ) ) {
			return $custom . PHP_EOL;
		}

		return self::default_robots_txt();
	}

	public function ajax_get_default_robots_txt(): void {
		check_ajax_referer( 'mvweb_so_ajax', 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Недостаточно прав.', 'mvweb-site-optimizer' ) ),
				403
			);
		}

		wp_send_json_success(
			array(
				'template' => self::default_robots_txt(),
			)
		);
	}

	public static function default_robots_txt(): string {
		$site_url = get_home_url();

		$lines = array(
			'User-agent: *',
			'Disallow: /wp-admin',
			'Disallow: /wp-includes',
			'Disallow: /wp-content/plugins',
			'Disallow: /wp-content/cache',
			'Disallow: /wp-json/',
			'Disallow: /xmlrpc.php',
			'Disallow: /readme.html',
			'Disallow: /*?',
			'Disallow: /?s=',
			'Disallow: /?customize_changeset_uuid=',
			'Allow: /wp-includes/*.css',
			'Allow: /wp-includes/*.js',
			'Allow: /wp-content/plugins/*.css',
			'Allow: /wp-content/plugins/*.js',
			'Allow: /*.css',
			'Allow: /*.js',
			'',
		);

		$sitemap = self::detect_sitemap_url( $site_url );
		if ( '' !== $sitemap ) {
			$lines[] = 'Sitemap: ' . $sitemap;
		}

		return implode( PHP_EOL, $lines ) . PHP_EOL;
	}

	private static function detect_sitemap_url( string $site_url ): string {
		$cache_key = 'mvweb_so_sitemap_url';
		$cached    = get_transient( $cache_key );

		if ( false !== $cached ) {
			return (string) $cached;
		}

		// Native-first: если WP Core sitemaps активны и не отключены — используем /wp-sitemap.xml без HTTP-запроса.
		// SEO-плагины (Yoast, RankMath, AIOSEO) перезаписывают endpoint, поэтому для них падаем в HTTP-проверку /sitemap.xml.
		if ( function_exists( 'wp_sitemaps_get_server' )
			&& ! defined( 'WPSEO_VERSION' )
			&& ! defined( 'RANK_MATH_VERSION' )
			&& ! defined( 'AIOSEO_VERSION' )
			&& apply_filters( 'wp_sitemaps_enabled', true ) ) {
			$result = $site_url . '/wp-sitemap.xml';
			set_transient( $cache_key, $result, DAY_IN_SECONDS );
			return $result;
		}

		$response = wp_remote_head(
			$site_url . '/sitemap.xml',
			array(
				'timeout'     => 3,
				'redirection' => 0,
			)
		);

		$result = '';

		if ( ! is_wp_error( $response ) ) {
			$code = (int) wp_remote_retrieve_response_code( $response );

			if ( 200 === $code ) {
				$result = $site_url . '/sitemap.xml';
			} elseif ( $code >= 300 && $code < 400 ) {
				$location = wp_remote_retrieve_header( $response, 'location' );
				if ( is_array( $location ) ) {
					$location = end( $location );
				}
				if ( $location ) {
					$result = (string) $location;
				}
			}
		}

		set_transient( $cache_key, $result, DAY_IN_SECONDS );

		return $result;
	}

	public function content_image_auto_alt( $content ) {
		global $post;

		if ( ! is_singular() || ! isset( $post->post_title ) ) {
			return $content;
		}

		if ( ! is_string( $content ) || false === stripos( $content, '<img' ) ) {
			return $content;
		}

		$replacement = esc_attr( $post->post_title );

		// Заменяем alt="" только на <img>-тегах, не трогая <area>, <input> и т.п.
		return preg_replace_callback(
			'#<img\b([^>]*?)>#i',
			static function ( $match ) use ( $replacement ) {
				$attrs = $match[1];
				$attrs = preg_replace( '/\salt\s*=\s*""/', ' alt="' . $replacement . '"', $attrs, 1, $count_double );
				if ( ! $count_double ) {
					$attrs = preg_replace( "/\salt\s*=\s*''/", " alt='" . $replacement . "'", $attrs, 1 );
				}
				return '<img' . $attrs . '>';
			},
			$content
		);
	}

	public function image_attributes_auto_alt( $attr, $attachment ) {
		if ( ! is_array( $attr ) ) {
			return $attr;
		}

		if ( ! empty( $attr['alt'] ) ) {
			return $attr;
		}

		$alt = '';

		if ( $attachment instanceof WP_Post ) {
			$alt = (string) get_post_meta( $attachment->ID, '_wp_attachment_image_alt', true );

			if ( '' === $alt ) {
				$parent = get_post( $attachment->post_parent );
				if ( $parent instanceof WP_Post && '' !== (string) $parent->post_title ) {
					$alt = (string) $parent->post_title;
				}
			}
		}

		if ( '' === $alt && is_singular() ) {
			$current = get_queried_object();
			if ( $current instanceof WP_Post ) {
				$alt = (string) $current->post_title;
			}
		}

		if ( '' !== $alt ) {
			$attr['alt'] = $alt;
		}

		return $attr;
	}

	public function disable_sitemap_users_provider( $provider, $name ) {
		return 'users' === $name ? false : $provider;
	}

	public function remove_last_item_breadcrumb_yoast( $link_output ) {
		if ( false !== strpos( (string) $link_output, 'breadcrumb_last' ) ) {
			return '';
		}
		return $link_output;
	}

	public function replace_last_item_breadcrumb_yoast_on_title( $link_output ) {
		$yoast_title = get_post_meta( get_the_ID(), '_yoast_wpseo_title', true );

		if ( ! empty( $yoast_title ) && false !== strpos( (string) $link_output, 'breadcrumb_last' ) ) {
			return $yoast_title;
		}

		return $link_output;
	}

	public function yoast_remove_image_from_xml_clean( $output, $url ) {
		return preg_replace( '/<image:image[^>]*?>.*?<\/image:image>/si', '', (string) $output );
	}

	public function canonical_pagination( $canonical ) {
		if ( ! is_paged() ) {
			return $canonical;
		}

		if ( is_category() ) {
			$cat = get_category( get_query_var( 'cat' ) );
			if ( $cat && isset( $cat->cat_ID ) ) {
				return get_category_link( $cat->cat_ID );
			}
		}

		if ( is_tag() || is_tax() ) {
			$queried = get_queried_object();
			if ( $queried && ! is_wp_error( $queried ) && isset( $queried->term_id ) ) {
				$taxonomy = isset( $queried->taxonomy ) ? $queried->taxonomy : get_query_var( 'taxonomy' );
				return get_term_link( $queried->term_id, $taxonomy );
			}
		}

		if ( is_author() ) {
			return get_author_posts_url( (int) get_query_var( 'author' ), (string) get_query_var( 'author_name' ) );
		}

		if ( is_front_page() ) {
			return home_url( '/' );
		}

		if ( is_home() ) {
			$blog_page_id = (int) get_option( 'page_for_posts' );
			if ( $blog_page_id > 0 ) {
				$blog_url = get_permalink( $blog_page_id );
				if ( $blog_url ) {
					return $blog_url;
				}
			}
			return home_url( '/' );
		}

		if ( $this->is_wc_shop() ) {
			return get_permalink( wc_get_page_id( 'shop' ) );
		}

		if ( is_post_type_archive() ) {
			$post_type = get_query_var( 'post_type' );
			if ( is_array( $post_type ) ) {
				$post_type = reset( $post_type );
			}
			if ( ! $post_type ) {
				$post_type = get_post_type();
			}
			if ( $post_type ) {
				$archive_link = get_post_type_archive_link( (string) $post_type );
				if ( $archive_link ) {
					return $archive_link;
				}
			}
		}

		if ( is_date() ) {
			if ( is_day() ) {
				return get_day_link( (int) get_query_var( 'year' ), (int) get_query_var( 'monthnum' ), (int) get_query_var( 'day' ) );
			}
			if ( is_month() ) {
				return get_month_link( (int) get_query_var( 'year' ), (int) get_query_var( 'monthnum' ) );
			}
			if ( is_year() ) {
				return get_year_link( (int) get_query_var( 'year' ) );
			}
		}

		if ( is_search() ) {
			return get_search_link();
		}

		return $canonical;
	}

	private function is_wc_shop(): bool {
		return function_exists( 'is_shop' )
			&& function_exists( 'wc_get_page_id' )
			&& is_shop();
	}

	public function sanitize( $accum, $raw ): array {
		$raw = is_array( $raw ) ? $raw : array();
		$out = array();

		foreach ( self::ALLOWED_KEYS as $key ) {
			if ( 'robots_txt_text' === $key ) {
				$value         = isset( $raw[ $key ] ) ? (string) $raw[ $key ] : '';
				$out[ $key ] = sanitize_textarea_field( $value );
				continue;
			}

			$out[ $key ] = isset( $raw[ $key ] ) && 'on' === $raw[ $key ] ? 'on' : '';
		}

		return $out;
	}
}
