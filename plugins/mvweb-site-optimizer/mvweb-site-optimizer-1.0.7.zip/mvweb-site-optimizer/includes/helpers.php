<?php
/**
 * Helper functions for MVweb Site Optimizer.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function mvweb_so_get_settings(): array {
	$settings = get_option( MVWEB_SO_OPTION, array() );
	return is_array( $settings ) ? $settings : array();
}

function mvweb_so_get_option( string $key, $default = '' ) {
	$settings = mvweb_so_get_settings();
	return array_key_exists( $key, $settings ) ? $settings[ $key ] : $default;
}

function mvweb_so_check_option( string $key ): bool {
	return 'on' === mvweb_so_get_option( $key, '' );
}

function mvweb_so_update_option( string $key, $value ): bool {
	$settings         = mvweb_so_get_settings();
	$settings[ $key ] = $value;
	return update_option( MVWEB_SO_OPTION, $settings, false );
}

function mvweb_so_count_active_features(): int {
	$count = 0;
	foreach ( mvweb_so_get_settings() as $value ) {
		if ( 'on' === $value ) {
			++$count;
		}
	}
	return $count;
}
