<?php
/**
 * Security tab — REST API, hide-login, login attempts, force HTTPS.
 *
 * Phase 5. Самая объёмная вкладка плагина — 4 модуля безопасности.
 *
 * @package mvweb_so
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$hide_login_slug      = (string) mvweb_so_get_option( 'hide_wp_login_new_slug', '' );
$la_allowed_retries   = (int) mvweb_so_get_option( 'login_attempts_allowed_retries', MVweb_SO_Tab_Security::DEFAULT_ALLOWED_RETRIES );
$la_allowed_lockouts  = (int) mvweb_so_get_option( 'login_attempts_allowed_lockouts', MVweb_SO_Tab_Security::DEFAULT_ALLOWED_LOCKOUTS );
$la_lockout_duration  = (int) mvweb_so_get_option( 'login_attempts_lockout_duration', MVweb_SO_Tab_Security::DEFAULT_LOCKOUT_DURATION );
$la_long_duration     = (int) mvweb_so_get_option( 'login_attempts_long_duration', MVweb_SO_Tab_Security::DEFAULT_LONG_DURATION );
$la_whitelist         = (string) mvweb_so_get_option( 'login_attempts_whitelist', '' );
$la_blacklist         = (string) mvweb_so_get_option( 'login_attempts_blacklist', '' );
$la_total             = (int) get_option( MVweb_SO_Tab_Security::OPTION_TOTAL, 0 );
$la_lockouts          = get_option( MVweb_SO_Tab_Security::OPTION_LOCKOUTS, array() );
$la_active_lockouts   = 0;
if ( is_array( $la_lockouts ) ) {
	foreach ( $la_lockouts as $until ) {
		if ( time() < (int) $until ) {
			++$la_active_lockouts;
		}
	}
}

$current_login_url = $hide_login_slug ? home_url( '/' . $hide_login_slug . '/' ) : home_url( '/wp-login.php' );
?>

<form method="post" action="">
	<?php wp_nonce_field( 'mvweb_so_settings', 'mvweb_so_nonce' ); ?>
	<input type="hidden" name="mvweb_so_tab" value="security">

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'REST API', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Закройте анонимный доступ к WordPress REST API. Авторизованные пользователи и whitelist маршрутов (Yoast, Contact Form 7, WooCommerce, Elementor и т.п.) продолжают работать.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-disable-json-rest-api">
				<?php esc_html_e( 'Запретить REST API неавторизованным', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-disable-json-rest-api"
							name="mvweb_so[disable_json_rest_api]"
							value="on"
							<?php checked( mvweb_so_check_option( 'disable_json_rest_api' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Все запросы к /wp-json/* от неавторизованных пользователей возвращают 401, кроме маршрутов из whitelist. Также убирает rest-link/oEmbed discovery из <head>. Если используется кастомная интеграция — добавьте префикс маршрута через фильтр mvweb_so_rest_api_white_list.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Скрытие wp-login.php', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Переименуйте страницу входа на произвольный URL и закройте прямой доступ к wp-login.php / wp-admin/. Защита от ботов, перебирающих стандартные адреса.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-alert mvweb-alert--warning">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
			<div class="mvweb-alert__body">
				<p class="mvweb-alert__title"><?php esc_html_e( 'Внимание!', 'mvweb-site-optimizer' ); ?></p>
				<p><?php esc_html_e( 'Запишите новый URL входа в надёжное место. Если потеряете доступ к админке — деактивируйте плагин через FTP/SSH (переименуйте папку wp-content/plugins/mvweb-site-optimizer).', 'mvweb-site-optimizer' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-hide-wp-login">
				<?php esc_html_e( 'Включить скрытие входа', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-hide-wp-login"
							name="mvweb_so[hide_wp_login]"
							value="on"
							<?php checked( mvweb_so_check_option( 'hide_wp_login' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Прямой доступ к /wp-login.php, /wp-register.php и /wp-admin/ (для неавторизованных) возвращает 403. Вход доступен только по новому URL.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-hide-wp-login-slug">
				<?php esc_html_e( 'Новый URL входа', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="text"
						id="mvweb-so-hide-wp-login-slug"
						name="mvweb_so[hide_wp_login_new_slug]"
						class="mvweb-input"
						value="<?php echo esc_attr( $hide_login_slug ); ?>"
						placeholder="my-secret-login"
						autocomplete="off">
				<p class="mvweb-form-row__desc">
					<?php
					echo wp_kses(
						sprintf(
							/* translators: %s: full login URL */
							esc_html__( 'Только латиница, цифры, дефис. Текущий URL входа: %s', 'mvweb-site-optimizer' ),
							'<code>' . esc_html( $current_login_url ) . '</code>'
						),
						array( 'code' => array() )
					);
					?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Ограничение попыток входа', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Блокирует IP после нескольких неудачных попыток. После серии блокировок включается продолжительный бан. Журнал блокировок хранится в отдельной опции.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-metrics">
			<div class="mvweb-metric">
				<div class="mvweb-metric__label"><?php esc_html_e( 'Всего блокировок', 'mvweb-site-optimizer' ); ?></div>
				<div class="mvweb-metric__value"><?php echo esc_html( (string) $la_total ); ?></div>
			</div>
			<div class="mvweb-metric">
				<div class="mvweb-metric__label"><?php esc_html_e( 'Активных сейчас', 'mvweb-site-optimizer' ); ?></div>
				<div class="mvweb-metric__value"><?php echo esc_html( (string) $la_active_lockouts ); ?></div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-login-attempts">
				<?php esc_html_e( 'Включить ограничение попыток', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-login-attempts"
							name="mvweb_so[login_attempts]"
							value="on"
							<?php checked( mvweb_so_check_option( 'login_attempts' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Подключает rate-limit на wp_login_failed и XML-RPC. IP клиента берётся только из REMOTE_ADDR — клиентским заголовкам не доверяем (защита от IP-spoofing).', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-la-retries">
				<?php esc_html_e( 'Разрешённых попыток', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
						id="mvweb-so-la-retries"
						name="mvweb_so[login_attempts_allowed_retries]"
						class="mvweb-input"
						min="1"
						max="999"
						step="1"
						value="<?php echo esc_attr( (string) $la_allowed_retries ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'После скольких неудачных попыток IP блокируется. Рекомендуем 3–10.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-la-lockouts">
				<?php esc_html_e( 'Блокировок до длительного бана', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
						id="mvweb-so-la-lockouts"
						name="mvweb_so[login_attempts_allowed_lockouts]"
						class="mvweb-input"
						min="1"
						max="999"
						step="1"
						value="<?php echo esc_attr( (string) $la_allowed_lockouts ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Сколько коротких блокировок прежде, чем сработает длительный бан. По умолчанию 4.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-la-lockout-duration">
				<?php esc_html_e( 'Короткая блокировка (мин)', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
						id="mvweb-so-la-lockout-duration"
						name="mvweb_so[login_attempts_lockout_duration]"
						class="mvweb-input"
						min="1"
						max="1440"
						step="1"
						value="<?php echo esc_attr( (string) $la_lockout_duration ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Длительность короткой блокировки в минутах. По умолчанию 20.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-la-long-duration">
				<?php esc_html_e( 'Длительная блокировка (ч)', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<input type="number"
						id="mvweb-so-la-long-duration"
						name="mvweb_so[login_attempts_long_duration]"
						class="mvweb-input"
						min="1"
						max="720"
						step="1"
						value="<?php echo esc_attr( (string) $la_long_duration ); ?>">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Длительность бана при превышении лимита коротких блокировок (в часах). По умолчанию 24.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-la-whitelist">
				<?php esc_html_e( 'Белый список IP', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-so-la-whitelist"
							name="mvweb_so[login_attempts_whitelist]"
							class="mvweb-textarea"
							rows="4"
							placeholder="192.168.1.10&#10;203.0.113.5"><?php echo esc_textarea( $la_whitelist ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Один IP в строке. IP из списка не блокируются, даже если превысили лимит попыток.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-la-blacklist">
				<?php esc_html_e( 'Чёрный список IP', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-so-la-blacklist"
							name="mvweb_so[login_attempts_blacklist]"
							class="mvweb-textarea"
							rows="4"
							placeholder="198.51.100.42"><?php echo esc_textarea( $la_blacklist ); ?></textarea>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'IP из списка не могут войти вне зависимости от количества попыток.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Принудительный HTTPS', 'mvweb-site-optimizer' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Если сайт открывают по HTTP — 301 редирект на HTTPS-версию того же URL. Не работает в CLI и WP_CLI окружениях.', 'mvweb-site-optimizer' ); ?></p>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-so-redirect-https">
				<?php esc_html_e( 'Редирект HTTP → HTTPS', 'mvweb-site-optimizer' ); ?>
			</label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-toggle">
					<input type="checkbox"
							id="mvweb-so-redirect-https"
							name="mvweb_so[redirect_from_http_to_https]"
							value="on"
							<?php checked( mvweb_so_check_option( 'redirect_from_http_to_https' ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Включайте только если SSL-сертификат уже установлен и сайт открывается по HTTPS. Иначе получите бесконечный редирект.', 'mvweb-site-optimizer' ); ?>
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" name="mvweb_so_save" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Сохранить изменения', 'mvweb-site-optimizer' ); ?>
		</button>
	</div>
</form>
