<?php
/**
 * Plugin Name:       MVweb Site Optimizer
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-site-optimizer
 * Description:       Модульный оптимизатор WordPress: чистка <head>, безопасность, SEO-фиксы, performance.
 * Version:           1.0.6
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-site-optimizer
 * Domain Path:       /languages
 *
 * @package mvweb_so
 *
 * @since 1.0.0 Initial release.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'MVWEB_SO_DISABLE' ) && MVWEB_SO_DISABLE ) {
	return;
}

if ( defined( 'MVWEB_SO_VERSION' ) ) {
	return;
}

define( 'MVWEB_SO_VERSION', '1.0.6' );
define( 'MVWEB_SO_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_SO_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_SO_BASENAME', plugin_basename( __FILE__ ) );
define( 'MVWEB_SO_OPTION', 'mvweb_so_settings' );

$shared_path = dirname( dirname( MVWEB_SO_PATH ) ) . '/shared/';

if ( file_exists( MVWEB_SO_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_SO_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

if ( file_exists( MVWEB_SO_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_SO_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-site-optimizer' );
}

require_once MVWEB_SO_PATH . 'includes/helpers.php';
require_once MVWEB_SO_PATH . 'includes/class-admin.php';
require_once MVWEB_SO_PATH . 'includes/class-settings.php';

require_once MVWEB_SO_PATH . 'includes/tabs/class-tab-general.php';
new MVweb_SO_Tab_General();

require_once MVWEB_SO_PATH . 'includes/tabs/class-tab-code.php';
new MVweb_SO_Tab_Code();

require_once MVWEB_SO_PATH . 'includes/tabs/class-tab-seo.php';
new MVweb_SO_Tab_Seo();

require_once MVWEB_SO_PATH . 'includes/tabs/class-tab-duplicate.php';
new MVweb_SO_Tab_Duplicate();

require_once MVWEB_SO_PATH . 'includes/tabs/class-tab-security.php';
new MVweb_SO_Tab_Security();

require_once MVWEB_SO_PATH . 'includes/tabs/class-tab-modules.php';
new MVweb_SO_Tab_Modules();

require_once MVWEB_SO_PATH . 'includes/class-transliterator.php';
MVweb_SO_Transliterator::init();

require_once MVWEB_SO_PATH . 'includes/tabs/class-tab-additionally.php';
new MVweb_SO_Tab_Additionally();

require_once MVWEB_SO_PATH . 'includes/tabs/class-tab-redirect.php';
new MVweb_SO_Tab_Redirect();

require_once MVWEB_SO_PATH . 'includes/tabs/class-tab-indexnow.php';
$GLOBALS['mvweb_so_tab_indexnow'] = new MVweb_SO_Tab_IndexNow();

require_once MVWEB_SO_PATH . 'includes/tabs/class-tab-maintenance.php';
new MVweb_SO_Tab_Maintenance();

add_filter(
	'mvweb_registered_plugins',
	function ( $plugins ) {
		$plugins['mvweb-site-optimizer'] = array(
			'name'         => 'MVweb Site Optimizer',
			'description'  => __( 'Модульный оптимизатор WordPress: чистка <head>, безопасность, SEO-фиксы, performance.', 'mvweb-site-optimizer' ),
			'url'          => 'https://mvweb.ru/plugins/mvweb-site-optimizer',
			'settings_url' => 'admin.php?page=mvweb-site-optimizer',
			'textdomain'   => 'mvweb-site-optimizer',
		);
		return $plugins;
	}
);

function mvweb_so_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-site-optimizer',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_so_load_textdomain' );

function mvweb_so_register_menu() {
	$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

	add_submenu_page(
		$parent_slug,
		__( 'MVweb Site Optimizer', 'mvweb-site-optimizer' ),
		__( 'Site Optimizer', 'mvweb-site-optimizer' ),
		'manage_options',
		'mvweb-site-optimizer',
		'mvweb_so_settings_page'
	);
}
add_action( 'admin_menu', 'mvweb_so_register_menu' );

function mvweb_so_settings_page() {
	$admin = new MVweb_SO_Admin();
	$admin->settings_page();
}

function mvweb_so_admin_init() {
	if ( ! is_admin() ) {
		return;
	}
	$settings = new MVweb_SO_Settings();
	$settings->maybe_handle_save();
}
add_action( 'admin_init', 'mvweb_so_admin_init' );

function mvweb_so_admin_enqueue( $hook ) {
	if ( false === strpos( (string) $hook, 'mvweb-site-optimizer' ) ) {
		return;
	}

	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

	$asset_ver = static function ( string $relative_path ) {
		$absolute = MVWEB_SO_PATH . $relative_path;
		$mtime    = @filemtime( $absolute );
		return $mtime ? (string) $mtime : MVWEB_SO_VERSION;
	};

	wp_enqueue_style(
		'mvweb-so-admin',
		MVWEB_SO_URL . 'admin/css/admin' . $suffix . '.css',
		array(),
		$asset_ver( 'admin/css/admin' . $suffix . '.css' )
	);

	wp_enqueue_style(
		'mvweb-so-plugin',
		MVWEB_SO_URL . 'admin/css/plugin' . $suffix . '.css',
		array( 'mvweb-so-admin' ),
		$asset_ver( 'admin/css/plugin' . $suffix . '.css' )
	);

	wp_enqueue_script(
		'mvweb-so-admin',
		MVWEB_SO_URL . 'admin/js/admin' . $suffix . '.js',
		array( 'jquery' ),
		$asset_ver( 'admin/js/admin' . $suffix . '.js' ),
		true
	);

	wp_localize_script(
		'mvweb-so-admin',
		'mvweb_so_ajax',
		array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'mvweb_so_ajax' ),
			'i18n'     => array(
				'edit'                  => __( 'Изменить', 'mvweb-site-optimizer' ),
				'delete'                => __( 'Удалить', 'mvweb-site-optimizer' ),
				'add_rule'              => __( 'Добавить правило', 'mvweb-site-optimizer' ),
				'save_changes'          => __( 'Сохранить изменения', 'mvweb-site-optimizer' ),
				'confirm_delete_rule'   => __( 'Удалить это правило?', 'mvweb-site-optimizer' ),
				'confirm_reset'         => __( 'Сбросить все настройки плагина? Действие необратимо.', 'mvweb-site-optimizer' ),
				'no_rules'              => __( 'Пока нет ни одного правила. Добавьте первое через форму выше.', 'mvweb-site-optimizer' ),
				'mode_regex'            => __( 'regex', 'mvweb-site-optimizer' ),
				'mode_exact'            => __( 'точный', 'mvweb-site-optimizer' ),
				'external_yes'          => __( 'да', 'mvweb-site-optimizer' ),
				'external_no'           => __( 'нет', 'mvweb-site-optimizer' ),
				'error_save'            => __( 'Ошибка сохранения.', 'mvweb-site-optimizer' ),
				'error_delete'          => __( 'Ошибка удаления.', 'mvweb-site-optimizer' ),
				'error_toggle'          => __( 'Ошибка переключения.', 'mvweb-site-optimizer' ),
				'error_connection'      => __( 'Ошибка соединения с сервером.', 'mvweb-site-optimizer' ),
				'saved'                 => __( 'Сохранено.', 'mvweb-site-optimizer' ),
				'deleted'               => __( 'Удалено.', 'mvweb-site-optimizer' ),
				'export_failed'         => __( 'Не удалось декодировать ответ сервера.', 'mvweb-site-optimizer' ),
				'export_done'           => __( 'Файл с настройками сформирован.', 'mvweb-site-optimizer' ),
				'import_pick_file'      => __( 'Сначала выберите файл с экспортом.', 'mvweb-site-optimizer' ),
				'file_read_failed'      => __( 'Не удалось прочитать файл.', 'mvweb-site-optimizer' ),
				'imported'              => __( 'Импортировано.', 'mvweb-site-optimizer' ),
				'reset_done'            => __( 'Сброшено.', 'mvweb-site-optimizer' ),
				'export_failed_action'  => __( 'Не удалось экспортировать настройки.', 'mvweb-site-optimizer' ),
				'import_failed_action'  => __( 'Не удалось импортировать настройки.', 'mvweb-site-optimizer' ),
				'reset_failed_action'   => __( 'Не удалось сбросить настройки.', 'mvweb-site-optimizer' ),
				'confirm_regenerate'    => __( 'Сгенерировать новый ключ IndexNow? Старый ключевой файл перестанет работать.', 'mvweb-site-optimizer' ),
				'confirm_clear_log'     => __( 'Очистить журнал отправок IndexNow?', 'mvweb-site-optimizer' ),
				'key_regenerated'       => __( 'Ключ обновлён.', 'mvweb-site-optimizer' ),
				'log_cleared'           => __( 'Журнал очищен.', 'mvweb-site-optimizer' ),
				'test_sent'             => __( 'Тестовая отправка выполнена. Обновите страницу для просмотра журнала.', 'mvweb-site-optimizer' ),
			),
		)
	);
}
add_action( 'admin_enqueue_scripts', 'mvweb_so_admin_enqueue' );

function mvweb_so_activate() {
	if ( false === get_option( MVWEB_SO_OPTION, false ) ) {
		add_option( MVWEB_SO_OPTION, array(), '', 'no' );
	}
}
register_activation_hook( __FILE__, 'mvweb_so_activate' );

function mvweb_so_deactivate() {
	wp_clear_scheduled_hook( 'mvweb_so_indexnow_dispatch' );
	wp_clear_scheduled_hook( 'mvweb_so_login_attempts_cleanup' );
	delete_transient( 'mvweb_so_indexnow_debounce' );
	delete_transient( 'mvweb_so_sitemap_url' );
}
register_deactivation_hook( __FILE__, 'mvweb_so_deactivate' );
