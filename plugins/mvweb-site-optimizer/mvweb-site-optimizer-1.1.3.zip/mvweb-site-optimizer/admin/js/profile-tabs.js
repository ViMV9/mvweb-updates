/**
 * MVweb Site Optimizer — user profile form split into tabs.
 *
 * @package mvweb_so
 */

( function ( settings ) {
	'use strict';

	if ( ! settings || ! settings.tabs ) {
		return;
	}

	var FALLBACK = 'other';

	var RULES = [
		{ tab: 'name', selector: '#user_login, #first_name, #nickname, #display_name' },
		{ tab: 'contacts', selector: '#email' },
		{ tab: 'about', selector: '#description' },
		{ tab: 'address', selector: '#billing_address_1, #shipping_address_1, #billing_first_name, #shipping_first_name' },
		{ tab: 'security', selector: '#pass1, #application-passwords-section' },
		{ tab: 'interface', selector: '#rich_editing, #syntax_highlighting, #admin_bar_front, #locale, input[name="admin_color"]' }
	];

	function has( node, selector ) {
		if ( ! node.matches ) {
			return false;
		}

		return node.matches( selector ) || !! node.querySelector( selector );
	}

	function isHeading( node ) {
		if ( 'H2' === node.tagName ) {
			return true;
		}

		return !! ( node.firstElementChild && 'H2' === node.firstElementChild.tagName );
	}

	function splitSocial( form ) {
		var email = document.getElementById( 'email' );
		var emailRow = email ? email.closest( 'tr' ) : null;
		var table = emailRow ? emailRow.closest( 'table' ) : null;
		var rows;
		var heading;
		var target;
		var body;
		var i;

		if ( ! table || table.parentNode !== form ) {
			return;
		}

		rows = Array.prototype.filter.call( table.rows, function ( row ) {
			return row !== emailRow && row.closest( 'table' ) === table;
		} );

		if ( ! rows.length ) {
			return;
		}

		heading = document.createElement( 'h2' );
		heading.textContent = settings.socialHeading;
		heading.setAttribute( 'data-mvweb-so-tab', 'social' );

		target = document.createElement( 'table' );
		target.className = 'form-table';
		target.setAttribute( 'role', 'presentation' );
		body = document.createElement( 'tbody' );
		target.appendChild( body );

		for ( i = 0; i < rows.length; i++ ) {
			body.appendChild( rows[ i ] );
		}

		form.insertBefore( heading, table.nextSibling );
		form.insertBefore( target, heading.nextSibling );
	}

	function collectSections( form, submit ) {
		var sections = [];
		var current = null;
		var node = form.firstElementChild;
		var next;

		while ( node && node !== submit ) {
			next = node.nextElementSibling;

			if ( isHeading( node ) ) {
				current = {
					heading: 'H2' === node.tagName ? node : node.firstElementChild,
					nodes: [ node ]
				};
				sections.push( current );
			} else if ( current ) {
				current.nodes.push( node );
			}

			node = next;
		}

		return sections;
	}

	function sectionTab( section ) {
		var marked;
		var node;
		var i;
		var j;

		for ( i = 0; i < section.nodes.length; i++ ) {
			node = section.nodes[ i ];
			marked = node.matches && node.matches( '[data-mvweb-so-tab]' ) ? node : node.querySelector && node.querySelector( '[data-mvweb-so-tab]' );

			if ( marked ) {
				return marked.getAttribute( 'data-mvweb-so-tab' );
			}
		}

		for ( j = 0; j < RULES.length; j++ ) {
			for ( i = 0; i < section.nodes.length; i++ ) {
				if ( has( section.nodes[ i ], RULES[ j ].selector ) ) {
					return RULES[ j ].tab;
				}
			}
		}

		return FALLBACK;
	}

	function groupSections( sections ) {
		var groups = [];
		var byTab = {};
		var group;
		var i;

		for ( i = 0; i < settings.tabs.length; i++ ) {
			byTab[ settings.tabs[ i ].id ] = {
				id: settings.tabs[ i ].id,
				label: settings.tabs[ i ].label,
				sections: []
			};
			groups.push( byTab[ settings.tabs[ i ].id ] );
		}

		for ( i = 0; i < sections.length; i++ ) {
			group = byTab[ sectionTab( sections[ i ] ) ] || byTab[ FALLBACK ];

			if ( group ) {
				group.sections.push( sections[ i ] );
			}
		}

		return groups.filter( function ( item ) {
			return item.sections.length > 0;
		} );
	}

	function buildPanels( form, submit, groups ) {
		var panel;
		var i;
		var j;
		var k;

		for ( i = 0; i < groups.length; i++ ) {
			panel = document.createElement( 'div' );
			panel.className = 'mvweb-so-profile-panel';
			panel.id = 'mvweb-so-profile-panel-' + groups[ i ].id;
			panel.setAttribute( 'role', 'tabpanel' );
			panel.setAttribute( 'aria-labelledby', 'mvweb-so-profile-tab-' + groups[ i ].id );
			panel.setAttribute( 'tabindex', '0' );
			panel.hidden = true;

			for ( j = 0; j < groups[ i ].sections.length; j++ ) {
				for ( k = 0; k < groups[ i ].sections[ j ].nodes.length; k++ ) {
					panel.appendChild( groups[ i ].sections[ j ].nodes[ k ] );
				}
			}

			if ( 1 === groups[ i ].sections.length && groups[ i ].sections[ 0 ].heading ) {
				groups[ i ].sections[ 0 ].heading.classList.add( 'screen-reader-text' );
			}

			groups[ i ].element = panel;
			form.insertBefore( panel, submit );
		}
	}

	function buildNav( form, panels ) {
		var nav = document.createElement( 'h2' );
		var button;
		var i;

		nav.className = 'nav-tab-wrapper mvweb-so-profile-tabs';
		nav.setAttribute( 'role', 'tablist' );

		for ( i = 0; i < panels.length; i++ ) {
			button = document.createElement( 'button' );
			button.type = 'button';
			button.className = 'nav-tab';
			button.id = 'mvweb-so-profile-tab-' + panels[ i ].id;
			button.textContent = panels[ i ].label;
			button.setAttribute( 'role', 'tab' );
			button.setAttribute( 'aria-controls', panels[ i ].element.id );
			button.setAttribute( 'aria-selected', 'false' );
			button.setAttribute( 'tabindex', '-1' );
			button.setAttribute( 'data-mvweb-so-panel', panels[ i ].id );

			nav.appendChild( button );
			panels[ i ].button = button;
		}

		form.insertBefore( nav, panels[ 0 ].element );

		return nav;
	}

	function storageKey() {
		return 'mvweb-so-profile-tab:' + ( settings.user || '0' );
	}

	function storedTab() {
		try {
			return window.sessionStorage.getItem( storageKey() );
		} catch ( error ) {
			return null;
		}
	}

	function rememberTab( id ) {
		try {
			window.sessionStorage.setItem( storageKey(), id );
		} catch ( error ) {
			return;
		}
	}

	function activate( panels, id, focus ) {
		var exists = panels.some( function ( panel ) {
			return panel.id === id;
		} );
		var current;
		var i;

		if ( ! exists ) {
			id = panels[ 0 ].id;
		}

		for ( i = 0; i < panels.length; i++ ) {
			current = panels[ i ].id === id;

			panels[ i ].element.hidden = ! current;
			panels[ i ].button.classList.toggle( 'nav-tab-active', current );
			panels[ i ].button.setAttribute( 'aria-selected', current ? 'true' : 'false' );
			panels[ i ].button.setAttribute( 'tabindex', current ? '0' : '-1' );

			if ( current && focus ) {
				panels[ i ].button.focus();
			}
		}

		rememberTab( id );
	}

	function bindKeys( nav, panels ) {
		nav.addEventListener( 'keydown', function ( event ) {
			var index = -1;
			var i;

			for ( i = 0; i < panels.length; i++ ) {
				if ( panels[ i ].button === event.target ) {
					index = i;
				}
			}

			if ( index < 0 ) {
				return;
			}

			if ( 'ArrowRight' === event.key || 'ArrowDown' === event.key ) {
				index = ( index + 1 ) % panels.length;
			} else if ( 'ArrowLeft' === event.key || 'ArrowUp' === event.key ) {
				index = ( index - 1 + panels.length ) % panels.length;
			} else if ( 'Home' === event.key ) {
				index = 0;
			} else if ( 'End' === event.key ) {
				index = panels.length - 1;
			} else {
				return;
			}

			event.preventDefault();
			activate( panels, panels[ index ].id, true );
		} );
	}

	function init() {
		var form = document.getElementById( 'your-profile' );
		var submit = form ? form.querySelector( ':scope > p.submit' ) : null;
		var panels;
		var nav;

		if ( ! form || ! submit || form.querySelector( '[role="tablist"]' ) ) {
			return;
		}

		splitSocial( form );
		panels = groupSections( collectSections( form, submit ) );

		if ( panels.length < 2 ) {
			return;
		}

		buildPanels( form, submit, panels );
		nav = buildNav( form, panels );

		nav.addEventListener( 'click', function ( event ) {
			var button = event.target.closest ? event.target.closest( '[data-mvweb-so-panel]' ) : null;

			if ( button ) {
				activate( panels, button.getAttribute( 'data-mvweb-so-panel' ), false );
			}
		} );

		bindKeys( nav, panels );
		activate( panels, storedTab() || panels[ 0 ].id, false );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}
}( window.mvwebSoProfileTabs ) );
