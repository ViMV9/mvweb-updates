<?php
/**
 * Вкладка «Справка»: как включить Memcached и что делать при ошибках.
 *
 * @package mvweb_mc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-memcached' ); ?></div>
	</div>
	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Enable Memcached on your hosting', 'mvweb-memcached' ); ?></strong>
			<p><?php esc_html_e( 'Look for the PHP settings or additional services section in the control panel. The address and port are listed there as well: usually 127.0.0.1 and 11211.', 'mvweb-memcached' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Check the PHP extension', 'mvweb-memcached' ); ?></strong>
			<p><?php esc_html_e( 'The server service and the PHP extension are enabled separately. Both are required: the plugin works with either memcached or the older memcache.', 'mvweb-memcached' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Click "Check" on the Cache tab', 'mvweb-memcached' ); ?></strong>
			<p><?php esc_html_e( 'If the settings are unknown, click "Detect automatically" and the plugin will try the usual addresses and sockets.', 'mvweb-memcached' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Enable the cache', 'mvweb-memcached' ); ?></strong>
			<p><?php esc_html_e( 'The "Enable cache" button appears once all three checks pass. The plugin then places object-cache.php into wp-content.', 'mvweb-memcached' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Check the site', 'mvweb-memcached' ); ?></strong>
			<p><?php esc_html_e( 'Home page, catalog, cart and checkout, account login, form submission. If anything goes wrong, click "Disable cache" and the site returns to its previous state.', 'mvweb-memcached' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'What the plugin does', 'mvweb-memcached' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Memcached keeps database query results in the server memory. With the cache enabled, pages are built from memory instead of being recalculated on every visit.', 'mvweb-memcached' ); ?>
	</p>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'The connection uses the standard WordPress mechanism — the object-cache.php file in wp-content. The file is self-contained and does not break the site if Memcached stops answering: the site keeps working without the cache, only slower.', 'mvweb-memcached' ); ?>
	</p>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Cart, session and coupon data never reach the persistent cache: the plugin excludes them automatically once WooCommerce is detected.', 'mvweb-memcached' ); ?>
	</p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Settings in wp-config.php', 'mvweb-memcached' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Constants override the settings from the admin screen, which helps when the parameters must not travel with the database.', 'mvweb-memcached' ); ?></p>
	<pre class="mvweb-code-block">define( 'MVWEB_MC_HOST', '127.0.0.1' );
define( 'MVWEB_MC_PORT', 11211 );
define( 'MVWEB_MC_PREFIX', 'site1' );
define( 'MVWEB_MC_SASL_USER', '' );
define( 'MVWEB_MC_SASL_PASS', '' );
define( 'MVWEB_MC_DISABLE', true );</pre>
	<p class="mvweb-block__sub"><?php esc_html_e( 'MVWEB_MC_DISABLE switches the cache off without deleting the file, in case the admin area is unreachable.', 'mvweb-memcached' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'WP-CLI commands', 'mvweb-memcached' ); ?></div>
	</div>
	<pre class="mvweb-code-block">wp mvweb-mc status
wp mvweb-mc test
wp mvweb-mc enable
wp mvweb-mc disable
wp mvweb-mc flush</pre>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Frequently asked questions', 'mvweb-memcached' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'It says no PHP extension is installed — what now?', 'mvweb-memcached' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'The service may be running while PHP cannot talk to it. Enable the memcached or the memcache extension in the hosting control panel (usually next to the PHP version selector) or ask your hosting support to do it. Either one is enough.', 'mvweb-memcached' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'What is the difference between memcached and memcache?', 'mvweb-memcached' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'These are two different PHP extensions for the same server. The plugin uses whichever is available, preferring the newer memcached. The older memcache works too, with two limitations: it cannot authenticate with a login and password, and counters are updated by read-and-write instead of a single atomic command.', 'mvweb-memcached' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The connection is not established', 'mvweb-memcached' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'Usually the port is wrong or the service is not running. Check the address and port in the hosting control panel, then click "Check". If your host provides a Unix socket, put its path into the address field and leave the port unused.', 'mvweb-memcached' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'wp-content already has object-cache.php from another plugin', 'mvweb-memcached' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'The plugin never touches a third-party file, as that could break a working cache. Deactivate the other caching plugin, delete its object-cache.php and come back here.', 'mvweb-memcached' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'My site is on shared hosting — can neighbours read my data?', 'mvweb-memcached' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'Site keys carry a unique prefix generated on activation from the database name and a random salt, so neighbouring sites cannot overwrite your keys. Full isolation on a shared Memcached server is impossible for any plugin — that is a limitation of the service itself.', 'mvweb-memcached' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The site started showing stale data', 'mvweb-memcached' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'Click "Flush cache" on the Cache tab or in the admin bar. Only the keys of this site are dropped; neighbouring sites on the same server are untouched.', 'mvweb-memcached' ); ?>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'What happens if I delete the plugin?', 'mvweb-memcached' ); ?></summary>
		<div class="mvweb-faq__body">
			<?php esc_html_e( 'On deactivation the plugin removes its own object-cache.php; on full deletion it also flushes the cache and deletes the settings. The site returns to normal operation without an object cache.', 'mvweb-memcached' ); ?>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-memcached' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php
		printf(
			/* translators: %s: ссылка на сайт студии. */
			esc_html__( 'Questions about the plugin — MVweb studio: %s', 'mvweb-memcached' ),
			'<a href="https://mvweb.ru" target="_blank" rel="noopener">mvweb.ru</a>'
		);
		?>
	</p>
	<p class="mvweb-block__sub">
		<?php
		printf(
			/* translators: %s: версия плагина. */
			esc_html__( 'Plugin version: %s', 'mvweb-memcached' ),
			esc_html( MVWEB_MC_VERSION )
		);
		?>
	</p>
</div>
