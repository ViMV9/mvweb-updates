<?php
/**
 * Страница плагина: состояние, подключение, дополнительные параметры.
 *
 * @package mvweb_mc
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_mc_current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'cache'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- переключение вкладок без записи.

$mvweb_mc_settings  = MVweb_MC_Settings::all();
$mvweb_mc_dropin    = MVweb_MC_Dropin::status();
$mvweb_mc_diagnosis = MVweb_MC_Connection::diagnose();
$mvweb_mc_groups    = MVweb_MC_Settings::non_persistent_groups();

$mvweb_mc_tabs = array(
	'cache' => array(
		'label' => __( 'Cache', 'mvweb-memcached' ),
		'icon'  => 'grid',
	),
	'help'  => array(
		'label' => __( 'Help', 'mvweb-memcached' ),
		'icon'  => 'help',
	),
);

$mvweb_mc_icons = array(
	'grid' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
	'help' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);

/**
 * Строка уровня проверки.
 *
 * @param string $label   Название уровня.
 * @param array  $state   Результат проверки.
 * @return void
 */
$mvweb_mc_render_level = static function ( $label, $state ) {
	printf(
		'<li class="mvweb-mc-level"><span class="mvweb-bullet-dot %1$s"></span><span class="mvweb-mc-level__label">%2$s</span><span class="mvweb-mc-level__text">%3$s</span></li>',
		esc_attr( $state['ok'] ? 'mvweb-bullet-dot--good' : 'mvweb-bullet-dot--bad' ),
		esc_html( $label ),
		esc_html( (string) $state['message'] )
	);
};
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">MC</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Memcached', 'mvweb-memcached' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_MC_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $mvweb_mc_tabs as $mvweb_mc_tab_id => $mvweb_mc_tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $mvweb_mc_tab_id ); ?>"
						class="mvweb-nav__link <?php echo $mvweb_mc_current_tab === $mvweb_mc_tab_id ? 'mvweb-nav__link--active' : ''; ?>"
						data-tab="<?php echo esc_attr( $mvweb_mc_tab_id ); ?>">
						<?php echo $mvweb_mc_icons[ $mvweb_mc_tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- статичная SVG-разметка. ?>
						<?php echo esc_html( $mvweb_mc_tab['label'] ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php settings_errors( 'mvweb_mc' ); ?>

		<div id="cache" class="mvweb-tab-content <?php echo 'cache' === $mvweb_mc_current_tab ? 'active' : ''; ?>">

			<div class="mvweb-block">
				<div class="mvweb-block__head">
					<div class="mvweb-block__title"><?php esc_html_e( 'Status', 'mvweb-memcached' ); ?></div>
					<?php if ( $mvweb_mc_dropin['ours'] ) : ?>
						<span class="mvweb-badge mvweb-badge--success"><?php esc_html_e( 'Cache enabled', 'mvweb-memcached' ); ?></span>
					<?php else : ?>
						<span class="mvweb-badge mvweb-badge--plain"><?php esc_html_e( 'Cache disabled', 'mvweb-memcached' ); ?></span>
					<?php endif; ?>
				</div>

				<ul class="mvweb-mc-levels" id="mvweb-mc-levels">
					<?php
					$mvweb_mc_render_level( __( 'PHP extension', 'mvweb-memcached' ), $mvweb_mc_diagnosis['extension'] );
					$mvweb_mc_render_level( __( 'Connection', 'mvweb-memcached' ), $mvweb_mc_diagnosis['connection'] );
					$mvweb_mc_render_level( __( 'Read and write', 'mvweb-memcached' ), $mvweb_mc_diagnosis['readwrite'] );
					?>
				</ul>

				<?php if ( is_array( $mvweb_mc_diagnosis['shared'] ) && $mvweb_mc_diagnosis['shared']['shared'] ) : ?>
					<div class="mvweb-alert mvweb-alert--info">
						<div class="mvweb-alert__body">
							<?php
							printf(
								/* translators: 1: число ключей на сервере, 2: префикс ключей сайта. */
								esc_html__( 'The server is shared: it holds %1$d keys, including data from other sites. Keys of this site are isolated by the prefix %2$s.', 'mvweb-memcached' ),
								(int) $mvweb_mc_diagnosis['shared']['items'],
								'<code>' . esc_html( (string) $mvweb_mc_diagnosis['shared']['prefix'] ) . '</code>'
							);
							?>
						</div>
					</div>
				<?php endif; ?>

				<?php if ( $mvweb_mc_dropin['exists'] && ! $mvweb_mc_dropin['ours'] ) : ?>
					<div class="mvweb-alert mvweb-alert--warning">
						<div class="mvweb-alert__title"><?php esc_html_e( 'Object cache is taken', 'mvweb-memcached' ); ?></div>
						<div class="mvweb-alert__body">
							<?php
							printf(
								/* translators: %s: имя плагина-владельца drop-in. */
								esc_html__( 'The wp-content/object-cache.php file belongs to "%s". The plugin leaves it untouched: remove the file manually if you want to switch to Memcached.', 'mvweb-memcached' ),
								esc_html( (string) $mvweb_mc_dropin['foreign'] )
							);
							?>
						</div>
					</div>
				<?php endif; ?>

				<?php if ( $mvweb_mc_dropin['outdated'] ) : ?>
					<div class="mvweb-alert mvweb-alert--warning">
						<div class="mvweb-alert__body">
							<?php
							printf(
								/* translators: 1: установленная версия, 2: версия в плагине. */
								esc_html__( 'The object-cache.php file is version %1$s while the plugin ships %2$s. Click "Update cache file".', 'mvweb-memcached' ),
								esc_html( (string) $mvweb_mc_dropin['installed_version'] ),
								esc_html( (string) $mvweb_mc_dropin['template_version'] )
							);
							?>
						</div>
					</div>
				<?php endif; ?>

				<div class="mvweb-mc-actions">
					<button type="button" class="mvweb-btn mvweb-btn--secondary" id="mvweb-mc-check">
						<?php esc_html_e( 'Check', 'mvweb-memcached' ); ?>
					</button>

					<?php if ( current_user_can( MVweb_MC_Admin::CAP_DROPIN ) && ! $mvweb_mc_dropin['multisite'] ) : ?>
						<?php if ( $mvweb_mc_dropin['ours'] ) : ?>
							<button type="button" class="mvweb-btn mvweb-btn--secondary" data-mvweb-mc-toggle="1">
								<?php esc_html_e( 'Update cache file', 'mvweb-memcached' ); ?>
							</button>
							<button type="button" class="mvweb-btn mvweb-btn--danger" data-mvweb-mc-toggle="0">
								<?php esc_html_e( 'Disable cache', 'mvweb-memcached' ); ?>
							</button>
						<?php elseif ( ! $mvweb_mc_dropin['exists'] ) : ?>
							<button type="button" class="mvweb-btn mvweb-btn--primary" data-mvweb-mc-toggle="1">
								<?php esc_html_e( 'Enable cache', 'mvweb-memcached' ); ?>
							</button>
						<?php endif; ?>
					<?php endif; ?>

					<?php if ( $mvweb_mc_dropin['ours'] ) : ?>
						<button type="button" class="mvweb-btn mvweb-btn--ghost" id="mvweb-mc-flush">
							<?php esc_html_e( 'Flush cache', 'mvweb-memcached' ); ?>
						</button>
					<?php endif; ?>
				</div>

				<div class="mvweb-mc-result" id="mvweb-mc-result" role="status" aria-live="polite"></div>
			</div>

			<form method="post" action="">
				<?php wp_nonce_field( 'mvweb_mc_settings', 'mvweb_mc_nonce' ); ?>

				<div class="mvweb-block">
					<div class="mvweb-block__head">
						<div class="mvweb-block__title"><?php esc_html_e( 'Connection', 'mvweb-memcached' ); ?></div>
					</div>
					<p class="mvweb-block__sub"><?php esc_html_e( 'The Memcached address and port come from your host. Usually it is 127.0.0.1 and port 11211.', 'mvweb-memcached' ); ?></p>

					<div class="mvweb-form-row">
						<label for="mvweb_mc_host" class="mvweb-form-row__label"><?php esc_html_e( 'Server address', 'mvweb-memcached' ); ?></label>
						<div class="mvweb-form-row__field">
							<input type="text"
								id="mvweb_mc_host"
								name="host"
								class="mvweb-input"
								value="<?php echo esc_attr( (string) $mvweb_mc_settings['host'] ); ?>"
								<?php disabled( MVweb_MC_Settings::is_locked( 'host' ) ); ?>>
							<p class="mvweb-form-row__desc">
								<?php
								echo MVweb_MC_Settings::is_locked( 'host' )
									? esc_html__( 'Set by the MVWEB_MC_HOST constant in wp-config.php.', 'mvweb-memcached' )
									: esc_html__( 'An IP address, a host name or a path to a Unix socket.', 'mvweb-memcached' );
								?>
							</p>
						</div>
					</div>

					<div class="mvweb-form-row">
						<label for="mvweb_mc_port" class="mvweb-form-row__label"><?php esc_html_e( 'Port', 'mvweb-memcached' ); ?></label>
						<div class="mvweb-form-row__field">
							<input type="number"
								id="mvweb_mc_port"
								name="port"
								class="mvweb-input"
								min="0"
								max="65535"
								value="<?php echo esc_attr( (string) $mvweb_mc_settings['port'] ); ?>"
								<?php disabled( MVweb_MC_Settings::is_locked( 'port' ) ); ?>>
							<p class="mvweb-form-row__desc">
								<?php
								echo MVweb_MC_Settings::is_locked( 'port' )
									? esc_html__( 'Set by the MVWEB_MC_PORT constant in wp-config.php.', 'mvweb-memcached' )
									: esc_html__( 'The port is not used for a Unix socket.', 'mvweb-memcached' );
								?>
							</p>
						</div>
					</div>

					<div class="mvweb-form-row">
						<span class="mvweb-form-row__label"><?php esc_html_e( 'Do not know the settings?', 'mvweb-memcached' ); ?></span>
						<div class="mvweb-form-row__field">
							<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-mc-detect" id="mvweb-mc-autodetect">
								<?php esc_html_e( 'Detect automatically', 'mvweb-memcached' ); ?>
							</button>
							<p class="mvweb-form-row__desc"><?php esc_html_e( 'The plugin tries the usual addresses and sockets and fills in the first one that answers.', 'mvweb-memcached' ); ?></p>
						</div>
					</div>
				</div>

				<details class="mvweb-faq mvweb-mc-advanced">
					<summary><?php esc_html_e( 'Advanced', 'mvweb-memcached' ); ?></summary>
					<div class="mvweb-faq__body">
						<div class="mvweb-form-row">
							<label for="mvweb_mc_sasl_user" class="mvweb-form-row__label"><?php esc_html_e( 'SASL user', 'mvweb-memcached' ); ?></label>
							<div class="mvweb-form-row__field">
								<input type="text"
									id="mvweb_mc_sasl_user"
									name="sasl_user"
									class="mvweb-input"
									autocomplete="off"
									value="<?php echo esc_attr( (string) $mvweb_mc_settings['sasl_user'] ); ?>"
									<?php disabled( MVweb_MC_Settings::is_locked( 'sasl_user' ) ); ?>>
								<p class="mvweb-form-row__desc"><?php esc_html_e( 'Needed only for servers with authentication. On ordinary hosting the field stays empty.', 'mvweb-memcached' ); ?></p>
								<?php if ( 'memcache' === MVweb_MC_Connection::extension_name() ) : ?>
									<p class="mvweb-form-row__desc"><?php esc_html_e( 'The old memcache extension does not support authentication — these fields will be ignored.', 'mvweb-memcached' ); ?></p>
								<?php endif; ?>
							</div>
						</div>
						<div class="mvweb-form-row">
							<label for="mvweb_mc_sasl_pass" class="mvweb-form-row__label"><?php esc_html_e( 'SASL password', 'mvweb-memcached' ); ?></label>
							<div class="mvweb-form-row__field">
								<input type="password"
									id="mvweb_mc_sasl_pass"
									name="sasl_pass"
									class="mvweb-input"
									autocomplete="new-password"
									value=""
									placeholder="<?php echo '' === $mvweb_mc_settings['sasl_pass'] ? '' : esc_attr__( 'password saved', 'mvweb-memcached' ); ?>"
									<?php disabled( MVweb_MC_Settings::is_locked( 'sasl_pass' ) ); ?>>
								<p class="mvweb-form-row__desc"><?php esc_html_e( 'An empty field keeps the saved password unchanged.', 'mvweb-memcached' ); ?></p>
							</div>
						</div>
						<div class="mvweb-form-row">
							<label for="mvweb_mc_prefix" class="mvweb-form-row__label"><?php esc_html_e( 'Key prefix', 'mvweb-memcached' ); ?></label>
							<div class="mvweb-form-row__field">
								<input type="text"
									id="mvweb_mc_prefix"
									name="prefix"
									class="mvweb-input"
									value="<?php echo esc_attr( (string) $mvweb_mc_settings['prefix'] ); ?>"
									<?php disabled( MVweb_MC_Settings::is_locked( 'prefix' ) ); ?>>
								<p class="mvweb-form-row__desc"><?php esc_html_e( 'Separates data of different sites on a shared server. Change it only when migrating a site.', 'mvweb-memcached' ); ?></p>
							</div>
						</div>
						<div class="mvweb-form-row">
							<label for="mvweb_mc_extra_groups" class="mvweb-form-row__label"><?php esc_html_e( 'Extra groups outside the cache', 'mvweb-memcached' ); ?></label>
							<div class="mvweb-form-row__field">
								<input type="text"
									id="mvweb_mc_extra_groups"
									name="extra_groups"
									class="mvweb-input"
									value="<?php echo esc_attr( (string) $mvweb_mc_settings['extra_groups'] ); ?>">
								<p class="mvweb-form-row__desc"><?php esc_html_e( 'Comma-separated. These groups are always read from the database and never stored in Memcached.', 'mvweb-memcached' ); ?></p>
								<p class="mvweb-form-row__desc">
									<?php esc_html_e( 'Currently outside the persistent cache:', 'mvweb-memcached' ); ?>
									<code><?php echo esc_html( implode( ', ', $mvweb_mc_groups ) ); ?></code>
								</p>
								<?php if ( MVweb_MC_Settings::has_woocommerce() ) : ?>
									<p class="mvweb-form-row__desc"><?php esc_html_e( 'WooCommerce detected: sessions, cart, coupons and order objects are excluded from the persistent cache automatically.', 'mvweb-memcached' ); ?></p>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</details>

				<div class="mvweb-submit">
					<button type="submit" name="mvweb_mc_save" class="mvweb-btn mvweb-btn--primary">
						<?php esc_html_e( 'Save', 'mvweb-memcached' ); ?>
					</button>
				</div>
			</form>
		</div>

		<div id="help" class="mvweb-tab-content <?php echo 'help' === $mvweb_mc_current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_MC_PATH . 'admin/views/tab-help.php'; ?>
		</div>

	</main>
</div>
