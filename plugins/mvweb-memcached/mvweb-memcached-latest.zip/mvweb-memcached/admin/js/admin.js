/**
 * Admin JavaScript for MVweb Memcached.
 *
 * @package mvweb_mc
 * @since   1.0.0
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		initTabs();
		initActions();
	});

	/**
	 * Initialize tab navigation on the settings page.
	 */
	function initTabs() {
		var links = document.querySelectorAll('.mvweb-nav__link');
		var panels = document.querySelectorAll('.mvweb-tab-content');

		if (!links.length || !panels.length) {
			return;
		}

		links.forEach(function (link) {
			link.addEventListener('click', function (event) {
				event.preventDefault();

				var target = link.getAttribute('data-tab') || link.getAttribute('href').replace('#', '');
				var panel = document.getElementById(target);

				if (!panel) {
					return;
				}

				links.forEach(function (l) { l.classList.remove('mvweb-nav__link--active'); });
				panels.forEach(function (p) { p.classList.remove('active'); });

				link.classList.add('mvweb-nav__link--active');
				panel.classList.add('active');
			});
		});
	}

	/**
	 * Wire up the check, autodetect, toggle and flush buttons.
	 */
	function initActions() {
		var check = document.getElementById('mvweb-mc-check');
		var autodetect = document.getElementById('mvweb-mc-autodetect');
		var flush = document.getElementById('mvweb-mc-flush');
		var toggles = document.querySelectorAll('[data-mvweb-mc-toggle]');

		if (check) {
			check.addEventListener('click', function () {
				runDiagnose(check);
			});
		}

		if (autodetect) {
			autodetect.addEventListener('click', function () {
				runAutodetect(autodetect);
			});
		}

		if (flush) {
			flush.addEventListener('click', function () {
				if (!window.confirm(mvwebMc.i18n.confirmFlush)) {
					return;
				}

				request('mvweb_mc_flush', {}, flush).then(function (data) {
					report(data.message, true);
				}, function (error) {
					report(error.message, false);
				});
			});
		}

		toggles.forEach(function (button) {
			button.addEventListener('click', function () {
				var enable = button.getAttribute('data-mvweb-mc-toggle');

				if ('0' === enable && !window.confirm(mvwebMc.i18n.confirmOff)) {
					return;
				}

				request('mvweb_mc_toggle', { enable: enable }, button).then(function () {
					window.location.reload();
				}, function (error) {
					report(error.message, false);
				});
			});
		});
	}

	/**
	 * Run the three-level diagnosis against the values currently in the form.
	 *
	 * @param {HTMLElement} button Trigger button.
	 */
	function runDiagnose(button) {
		var host = document.getElementById('mvweb_mc_host');
		var port = document.getElementById('mvweb_mc_port');
		var payload = {};

		if (host) {
			payload.host = host.value;
		}

		if (port) {
			payload.port = port.value;
		}

		request('mvweb_mc_diagnose', payload, button).then(function (data) {
			renderLevels(data.diagnosis);
			report('', true);
		}, function (error) {
			report(error.message, false);
		});
	}

	/**
	 * Ask the server to look for a working Memcached endpoint.
	 *
	 * @param {HTMLElement} button Trigger button.
	 */
	function runAutodetect(button) {
		request('mvweb_mc_autodetect', {}, button).then(function (data) {
			var host = document.getElementById('mvweb_mc_host');
			var port = document.getElementById('mvweb_mc_port');

			if (host && !host.disabled) {
				host.value = data.host;
			}

			if (port && !port.disabled) {
				port.value = data.port;
			}

			report(data.message, true);
		}, function (error) {
			report(error.message, false);
		});
	}

	/**
	 * Repaint the three status levels.
	 *
	 * @param {Object} diagnosis Server response.
	 */
	function renderLevels(diagnosis) {
		var list = document.getElementById('mvweb-mc-levels');

		if (!list) {
			return;
		}

		var items = list.querySelectorAll('.mvweb-mc-level');
		var order = ['extension', 'connection', 'readwrite'];

		order.forEach(function (key, index) {
			var item = items[index];

			if (!item || !diagnosis[key]) {
				return;
			}

			var dot = item.querySelector('.mvweb-bullet-dot');
			var text = item.querySelector('.mvweb-mc-level__text');

			if (dot) {
				dot.classList.remove('mvweb-bullet-dot--good', 'mvweb-bullet-dot--bad');
				dot.classList.add(diagnosis[key].ok ? 'mvweb-bullet-dot--good' : 'mvweb-bullet-dot--bad');
			}

			if (text) {
				text.textContent = diagnosis[key].message;
			}
		});
	}

	/**
	 * Show the result of the last action.
	 *
	 * @param {string}  message Text to show.
	 * @param {boolean} success Whether the action succeeded.
	 */
	function report(message, success) {
		var box = document.getElementById('mvweb-mc-result');

		if (!box) {
			return;
		}

		box.replaceChildren();

		if (!message) {
			return;
		}

		var alert = document.createElement('div');
		alert.className = 'mvweb-alert ' + (success ? 'mvweb-alert--success' : 'mvweb-alert--error');

		var body = document.createElement('div');
		body.className = 'mvweb-alert__body';
		body.textContent = message;

		alert.appendChild(body);
		box.appendChild(alert);
	}

	/**
	 * Send an AJAX request with the plugin nonce.
	 *
	 * @param {string}      action  AJAX action name.
	 * @param {Object}      payload Extra fields.
	 * @param {HTMLElement} button  Button to disable while running.
	 * @return {Promise} Resolves with the response data.
	 */
	function request(action, payload, button) {
		var body = new URLSearchParams();

		body.append('action', action);
		body.append('nonce', mvwebMc.nonce);

		Object.keys(payload).forEach(function (key) {
			body.append(key, payload[key]);
		});

		var label = button ? button.textContent : '';

		if (button) {
			button.disabled = true;
			button.textContent = mvwebMc.i18n.working;
		}

		return fetch(mvwebMc.ajaxUrl, {
			method: 'POST',
			credentials: 'same-origin',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
			body: body.toString()
		}).then(function (response) {
			return response.json();
		}).then(function (json) {
			if (!json || !json.success) {
				throw new Error(json && json.data && json.data.message ? json.data.message : mvwebMc.i18n.failed);
			}

			return json.data;
		}).catch(function (error) {
			throw error instanceof Error ? error : new Error(mvwebMc.i18n.failed);
		}).finally(function () {
			if (button) {
				button.disabled = false;
				button.textContent = label;
			}
		});
	}
})();
