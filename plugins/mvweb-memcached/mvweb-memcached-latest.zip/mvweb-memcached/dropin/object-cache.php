<?php
/**
 * Object Cache Drop-in — MVweb Memcached.
 *
 * Файл самодостаточен: он не подключает код плагина и продолжает работать,
 * даже если плагин удалён из wp-content/plugins. Параметры подключения
 * впечатываются в блок MVWEB CONFIG при установке; константы wp-config.php
 * их перекрывают.
 *
 * Drop-in Name: MVweb Memcached
 * Drop-in Version: 1.0.0
 *
 * @package mvweb_mc
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Структура файла продиктована WordPress: имя object-cache.php, глобальный
// $wp_object_cache и обязательный набор функций рядом с классом.
// phpcs:disable WordPress.Files.FileName.InvalidClassFileName
// phpcs:disable Universal.Files.SeparateFunctionsFromOO.Mixed
// phpcs:disable WordPress.WP.GlobalVariablesOverride.Prohibited
// phpcs:disable Universal.NamingConventions.NoReservedKeywordParameterNames
// phpcs:disable Generic.CodeAnalysis.UnusedFunctionParameter
// phpcs:disable Generic.Files.OneObjectStructurePerFile


define( 'MVWEB_MC_DROPIN_VERSION', '1.0.0' );

// ═══ MVWEB CONFIG START ═══
$GLOBALS['mvweb_mc_config'] = array(
	'host'           => '127.0.0.1',
	'port'           => 11211,
	'sasl_user'      => '',
	'sasl_pass'      => '',
	'prefix'         => 'mvweb',
	'timeout'        => 1000,
	'op_timeout'     => 500,
	'non_persistent' => array( 'counts', 'plugins', 'themes', 'comment' ),
);
// ═══ MVWEB CONFIG END ═══

/**
 * Драйвер поверх расширения Memcached (libmemcached).
 *
 * @since 1.0.0
 */
class MVweb_MC_Driver_Memcached {

	/**
	 * Соединение с сервером.
	 *
	 * @var Memcached|null
	 */
	private $mc = null;

	/**
	 * Имя расширения для интерфейса и диагностики.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public function name() {
		return 'memcached';
	}

	/**
	 * Доступно ли расширение в этой сборке PHP.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public static function available() {
		return class_exists( 'Memcached' );
	}

	/**
	 * Подключиться к серверу.
	 *
	 * @since 1.0.0
	 *
	 * @param array $config Параметры подключения.
	 * @return bool
	 */
	public function connect( array $config ) {
		$host = (string) $config['host'];
		$port = (int) $config['port'];

		$mc = new Memcached( 'mvweb-mc-' . substr( md5( $host . ':' . $port . ':' . $config['prefix'] ), 0, 8 ) );
		$mc->setOption( Memcached::OPT_BINARY_PROTOCOL, true );
		$mc->setOption( Memcached::OPT_CONNECT_TIMEOUT, (int) $config['timeout'] );
		$mc->setOption( Memcached::OPT_SEND_TIMEOUT, (int) $config['op_timeout'] * 1000 );
		$mc->setOption( Memcached::OPT_RECV_TIMEOUT, (int) $config['op_timeout'] * 1000 );
		$mc->setOption( Memcached::OPT_POLL_TIMEOUT, (int) $config['op_timeout'] );

		if ( '' !== $config['sasl_user'] && method_exists( $mc, 'setSaslAuthData' ) ) {
			$mc->setSaslAuthData( $config['sasl_user'], $config['sasl_pass'] );
		}

		$has_server = method_exists( $mc, 'getServerList' ) && $mc->getServerList();

		if ( ! $has_server ) {
			if ( 0 === strpos( $host, '/' ) ) {
				$mc->addServer( $host, 0 );
			} else {
				$mc->addServer( $host, $port );
			}
		}

		$mc->get( $config['prefix'] . ':probe' );
		$code = $mc->getResultCode();

		if ( Memcached::RES_SUCCESS !== $code && Memcached::RES_NOTFOUND !== $code ) {
			return false;
		}

		$this->mc = $mc;

		return true;
	}

	/**
	 * Прочитать значение.
	 *
	 * @since 1.0.0
	 *
	 * @param string $key    Полный ключ.
	 * @param string $status Итог чтения: hit, miss или error.
	 * @return mixed
	 */
	public function get( $key, &$status ) {
		$value = $this->mc->get( $key );
		$code  = $this->mc->getResultCode();

		if ( Memcached::RES_SUCCESS === $code ) {
			$status = 'hit';

			return $value;
		}

		$status = Memcached::RES_NOTFOUND === $code ? 'miss' : 'error';

		return false;
	}

	/**
	 * Записать значение.
	 *
	 * @since 1.0.0
	 *
	 * @param string $key    Полный ключ.
	 * @param mixed  $value  Значение.
	 * @param int    $expire Срок жизни.
	 * @return bool
	 */
	public function set( $key, $value, $expire ) {
		return $this->mc->set( $key, $value, $expire );
	}

	/**
	 * Записать значение, если ключа ещё нет.
	 *
	 * @since 1.0.0
	 *
	 * @param string $key    Полный ключ.
	 * @param mixed  $value  Значение.
	 * @param int    $expire Срок жизни.
	 * @return bool
	 */
	public function add( $key, $value, $expire ) {
		return $this->mc->add( $key, $value, $expire );
	}

	/**
	 * Удалить значение.
	 *
	 * @since 1.0.0
	 *
	 * @param string $key Полный ключ.
	 * @return bool
	 */
	public function delete( $key ) {
		return $this->mc->delete( $key );
	}

	/**
	 * Увеличить счётчик на сервере.
	 *
	 * @since 1.0.0
	 *
	 * @param string $key    Полный ключ.
	 * @param int    $offset Шаг.
	 * @return int|false
	 */
	public function incr( $key, $offset ) {
		return $this->mc->increment( $key, $offset );
	}

	/**
	 * Уменьшить счётчик на сервере.
	 *
	 * @since 1.0.0
	 *
	 * @param string $key    Полный ключ.
	 * @param int    $offset Шаг.
	 * @return int|false
	 */
	public function decr( $key, $offset ) {
		return $this->mc->decrement( $key, $offset );
	}

	/**
	 * Код последней операции — для сообщений в лог.
	 *
	 * @since 1.0.0
	 *
	 * @return int
	 */
	public function last_code() {
		return (int) $this->mc->getResultCode();
	}

	/**
	 * Не влезло ли значение в лимит сервера.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public function too_big() {
		return Memcached::RES_E2BIG === $this->mc->getResultCode();
	}
}

/**
 * Драйвер поверх старого расширения Memcache.
 *
 * Оно встречается на массовых хостингах (например, Beget), где нового
 * расширения нет. У него нет кодов результата, поэтому «ключа нет» и
 * «сервер не ответил» различаются по состоянию соединения.
 *
 * @since 1.0.0
 */
class MVweb_MC_Driver_Memcache {

	/**
	 * Ключ конверта, в котором хранится значение.
	 *
	 * Расширение возвращает false и при промахе, и при закешированном false.
	 * Конверт снимает эту неоднозначность.
	 */
	const ENVELOPE = 'v';

	/**
	 * Соединение с сервером.
	 *
	 * @var Memcache|null
	 */
	private $mc = null;

	/**
	 * Адрес сервера для проверки состояния соединения.
	 *
	 * @var string
	 */
	private $host = '';

	/**
	 * Порт сервера.
	 *
	 * @var int
	 */
	private $port = 11211;

	/**
	 * Имя расширения для интерфейса и диагностики.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public function name() {
		return 'memcache';
	}

	/**
	 * Доступно ли расширение в этой сборке PHP.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public static function available() {
		return class_exists( 'Memcache' );
	}

	/**
	 * Подключиться к серверу.
	 *
	 * @since 1.0.0
	 *
	 * @param array $config Параметры подключения.
	 * @return bool
	 */
	public function connect( array $config ) {
		$host = (string) $config['host'];
		$port = (int) $config['port'];

		if ( 0 === strpos( $host, '/' ) ) {
			$host = 'unix://' . $host;
			$port = 0;
		}

		$mc      = new Memcache();
		$timeout = max( 1, (int) round( $config['timeout'] / 1000 ) );

		if ( ! @$mc->pconnect( $host, $port, $timeout ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- недоступный сервер не должен ронять загрузку сайта варнингом.
			return false;
		}

		// Ограничиваем и время отдельной операции: иначе зависший сервер держал бы
		// страницу до общего таймаута PHP.
		if ( method_exists( $mc, 'setServerParams' ) ) {
			@$mc->setServerParams( $host, $port, $timeout, -1, true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- параметры применяем по возможности.
		}

		$this->mc   = $mc;
		$this->host = $host;
		$this->port = $port;

		return true;
	}

	/**
	 * Отвечает ли сервер прямо сейчас.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	private function server_alive() {
		if ( ! method_exists( $this->mc, 'getServerStatus' ) ) {
			return true;
		}

		return (bool) @$this->mc->getServerStatus( $this->host, $this->port ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- проверка состояния не должна шуметь в лог.
	}

	/**
	 * Прочитать значение.
	 *
	 * @since 1.0.0
	 *
	 * @param string $key    Полный ключ.
	 * @param string $status Итог чтения: hit, miss или error.
	 * @return mixed
	 */
	public function get( $key, &$status ) {
		$envelope = @$this->mc->get( $key ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- обрыв связи обрабатываем сами.

		if ( is_array( $envelope ) && array_key_exists( self::ENVELOPE, $envelope ) ) {
			$status = 'hit';

			return $envelope[ self::ENVELOPE ];
		}

		$status = $this->server_alive() ? 'miss' : 'error';

		return false;
	}

	/**
	 * Записать значение.
	 *
	 * @since 1.0.0
	 *
	 * @param string $key    Полный ключ.
	 * @param mixed  $value  Значение.
	 * @param int    $expire Срок жизни.
	 * @return bool
	 */
	public function set( $key, $value, $expire ) {
		return (bool) @$this->mc->set( $key, array( self::ENVELOPE => $value ), 0, $expire ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- ошибку возвращаем значением.
	}

	/**
	 * Записать значение, если ключа ещё нет.
	 *
	 * @since 1.0.0
	 *
	 * @param string $key    Полный ключ.
	 * @param mixed  $value  Значение.
	 * @param int    $expire Срок жизни.
	 * @return bool
	 */
	public function add( $key, $value, $expire ) {
		return (bool) @$this->mc->add( $key, array( self::ENVELOPE => $value ), 0, $expire ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- ошибку возвращаем значением.
	}

	/**
	 * Удалить значение.
	 *
	 * @since 1.0.0
	 *
	 * @param string $key Полный ключ.
	 * @return bool
	 */
	public function delete( $key ) {
		return (bool) @$this->mc->delete( $key ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- ошибку возвращаем значением.
	}

	/**
	 * Атомарного счётчика нет: значения лежат в конверте, а серверный
	 * increment работает только с сырыми числами. Кеш сам пересчитает
	 * значение чтением и записью.
	 *
	 * @since 1.0.0
	 *
	 * @param string $key    Полный ключ.
	 * @param int    $offset Шаг.
	 * @return false
	 */
	public function incr( $key, $offset ) {
		return false;
	}

	/**
	 * Атомарного счётчика нет — причина та же, что у incr().
	 *
	 * @since 1.0.0
	 *
	 * @param string $key    Полный ключ.
	 * @param int    $offset Шаг.
	 * @return false
	 */
	public function decr( $key, $offset ) {
		return false;
	}

	/**
	 * Кода результата у расширения нет.
	 *
	 * @since 1.0.0
	 *
	 * @return int
	 */
	public function last_code() {
		return 0;
	}

	/**
	 * Отличить «слишком большое значение» расширение не умеет.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public function too_big() {
		return false;
	}
}

/**
 * Постоянный кеш объектов поверх Memcached.
 *
 * @since 1.0.0
 */
class WP_Object_Cache {

	/**
	 * Потолок времени жизни для записей, которые WordPress кладёт без срока.
	 *
	 * Пока Memcached недоступен, изменения в базе не инвалидируют кеш: записи,
	 * сделанные до сбоя, пережили бы восстановление и отдавались бы вечно.
	 * Сутки ограничивают окно расхождения.
	 */
	const MAX_TTL = 86400;

	/**
	 * Порог, после которого Memcached считает срок абсолютной датой.
	 *
	 * Всё, что больше 30 суток, протокол трактует как unix-timestamp, поэтому
	 * такой срок нужно переводить в абсолютное время, иначе запись протухает
	 * мгновенно (WordPress и WooCommerce кладут транзиенты на год).
	 */
	const TIMESTAMP_THRESHOLD = 2592000;

	/**
	 * Кеш в памяти текущего запроса.
	 *
	 * @var array
	 */
	protected $cache = array();

	/**
	 * Драйвер расширения или null, если подключиться не удалось.
	 *
	 * @var MVweb_MC_Driver_Memcached|MVweb_MC_Driver_Memcache|null
	 */
	protected $driver = null;

	/**
	 * Имя используемого расширения.
	 *
	 * @var string
	 */
	public $extension = '';

	/**
	 * Группы, которые никогда не уходят на сервер.
	 *
	 * @var array
	 */
	protected $non_persistent = array();

	/**
	 * Глобальные группы (учитываются для совместимости API).
	 *
	 * @var array
	 */
	protected $global_groups = array();

	/**
	 * Префикс ключей сайта.
	 *
	 * @var string
	 */
	protected $prefix = 'mvweb';

	/**
	 * Поколение кеша — инкремент работает как flush своего префикса.
	 *
	 * @var int|null
	 */
	protected $generation = null;

	/**
	 * Текст последней ошибки.
	 *
	 * @var string
	 */
	public $last_error = '';

	/**
	 * Признак рабочего соединения.
	 *
	 * @var bool
	 */
	public $connected = false;

	/**
	 * Конструктор: подключается к серверу, при любой проблеме уходит в режим
	 * кеша запроса, не прерывая загрузку сайта.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$config = isset( $GLOBALS['mvweb_mc_config'] ) && is_array( $GLOBALS['mvweb_mc_config'] )
			? $GLOBALS['mvweb_mc_config']
			: array();

		$this->non_persistent = isset( $config['non_persistent'] ) ? (array) $config['non_persistent'] : array();
		$this->prefix         = $this->resolve( $config, 'prefix', 'MVWEB_MC_PREFIX', 'mvweb' );

		if ( defined( 'MVWEB_MC_DISABLE' ) && MVWEB_MC_DISABLE ) {
			$this->last_error = 'Отключено константой MVWEB_MC_DISABLE.';
			return;
		}

		$settings = array(
			'host'       => $this->resolve( $config, 'host', 'MVWEB_MC_HOST', '127.0.0.1' ),
			'port'       => (int) $this->resolve( $config, 'port', 'MVWEB_MC_PORT', 11211 ),
			'sasl_user'  => (string) $this->resolve( $config, 'sasl_user', 'MVWEB_MC_SASL_USER', '' ),
			'sasl_pass'  => (string) $this->resolve( $config, 'sasl_pass', 'MVWEB_MC_SASL_PASS', '' ),
			'prefix'     => $this->prefix,
			'timeout'    => isset( $config['timeout'] ) ? (int) $config['timeout'] : 1000,
			'op_timeout' => isset( $config['op_timeout'] ) ? (int) $config['op_timeout'] : 500,
		);

		// Новое расширение предпочтительнее: у него есть коды результата и SASL.
		// Старое memcache стоит на массовых хостингах, где нового нет.
		foreach ( array( 'MVweb_MC_Driver_Memcached', 'MVweb_MC_Driver_Memcache' ) as $class ) {
			if ( ! $class::available() ) {
				continue;
			}

			try {
				$driver = new $class();

				if ( $driver->connect( $settings ) ) {
					$this->driver    = $driver;
					$this->extension = $driver->name();
					$this->connected = true;

					return;
				}

				$this->last_error = 'Сервер не отвечает через расширение ' . $driver->name() . '.';
			} catch ( Throwable $e ) {
				$this->last_error = $e->getMessage();
				$this->log( 'Ошибка подключения (' . $class . '): ' . $e->getMessage() );
			}
		}

		if ( '' === $this->last_error ) {
			$this->last_error = 'Ни расширение Memcached, ни Memcache не установлены в PHP.';
		}

		$this->log( $this->last_error );
	}

	/**
	 * Значение параметра: константа wp-config перекрывает впечатанный конфиг.
	 *
	 * @since 1.0.0
	 *
	 * @param array  $config   Впечатанный конфиг.
	 * @param string $key      Ключ конфига.
	 * @param string $constant Имя константы.
	 * @param mixed  $default  Значение по умолчанию.
	 * @return mixed
	 */
	protected function resolve( $config, $key, $constant, $default ) {
		if ( defined( $constant ) ) {
			return constant( $constant );
		}

		return isset( $config[ $key ] ) ? $config[ $key ] : $default;
	}

	/**
	 * Запись в error_log только при включённой отладке.
	 *
	 * @since 1.0.0
	 *
	 * @param string $message Сообщение.
	 * @return void
	 */
	protected function log( $message ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( '[MVweb Memcached] ' . $message ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- диагностика только при WP_DEBUG.
		}
	}

	/**
	 * Текущее поколение кеша. Инкремент поколения = сброс своего префикса.
	 *
	 * @since 1.0.0
	 *
	 * @return int
	 */
	protected function generation() {
		if ( null !== $this->generation ) {
			return $this->generation;
		}

		$this->generation = 1;

		if ( $this->connected ) {
			try {
				$status = 'error';
				$value  = $this->driver->get( $this->prefix . ':generation', $status );

				if ( 'hit' === $status ) {
					$this->generation = (int) $value;
				} elseif ( 'miss' === $status ) {
					$this->driver->set( $this->prefix . ':generation', 1, 0 );
				} else {
					// Сервер не ответил. Перезапись счётчика единицей откатила бы
					// прошлые сбросы, поэтому оставляем кеш выключенным до конца запроса.
					$this->log( 'Поколение кеша не прочитано, кеш отключён на этот запрос.' );
					$this->connected = false;
				}
			} catch ( Throwable $e ) {
				$this->log( 'Поколение кеша недоступно: ' . $e->getMessage() );
			}
		}

		return $this->generation;
	}

	/**
	 * Полный ключ на сервере.
	 *
	 * @since 1.0.0
	 *
	 * @param string|int $key   Ключ.
	 * @param string     $group Группа.
	 * @return string
	 */
	protected function build_key( $key, $group ) {
		return $this->prefix . ':' . $this->generation() . ':' . $group . ':' . $key;
	}

	/**
	 * Ключ кеша запроса.
	 *
	 * @since 1.0.0
	 *
	 * @param string|int $key   Ключ.
	 * @param string     $group Группа.
	 * @return string
	 */
	protected function runtime_key( $key, $group ) {
		return $group . ':' . $key;
	}

	/**
	 * Уходит ли группа на сервер.
	 *
	 * @since 1.0.0
	 *
	 * @param string $group Группа.
	 * @return bool
	 */
	protected function is_persistent( $group ) {
		return $this->connected && ! in_array( $group, $this->non_persistent, true );
	}

	/**
	 * Срок жизни записи с учётом потолка.
	 *
	 * @since 1.0.0
	 *
	 * @param int $expire Запрошенный срок в секундах.
	 * @return int
	 */
	protected function ttl( $expire ) {
		$expire = (int) $expire;

		if ( $expire <= 0 ) {
			return self::MAX_TTL;
		}

		return $expire > self::TIMESTAMP_THRESHOLD ? time() + $expire : $expire;
	}

	/**
	 * Пригоден ли ключ: ядро принимает только непустую строку или число.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $key Ключ.
	 * @return bool
	 */
	protected function is_valid_key( $key ) {
		if ( is_int( $key ) ) {
			return true;
		}

		return is_string( $key ) && '' !== trim( $key );
	}

	/**
	 * Нормализация имени группы.
	 *
	 * @since 1.0.0
	 *
	 * @param string $group Группа.
	 * @return string
	 */
	protected function group( $group ) {
		return empty( $group ) ? 'default' : $group;
	}

	/**
	 * Добавить значение, если ключа ещё нет.
	 *
	 * @since 1.0.0
	 *
	 * @param string|int $key    Ключ.
	 * @param mixed      $data   Значение.
	 * @param string     $group  Группа.
	 * @param int        $expire Время жизни.
	 * @return bool
	 */
	public function add( $key, $data, $group = 'default', $expire = 0 ) {
		if ( ! $this->is_valid_key( $key ) ) {
			return false;
		}

		if ( function_exists( 'wp_suspend_cache_addition' ) && wp_suspend_cache_addition() ) {
			return false;
		}

		$group = $this->group( $group );

		if ( isset( $this->cache[ $this->runtime_key( $key, $group ) ] ) ) {
			return false;
		}

		if ( $this->is_persistent( $group ) ) {
			try {
				$added = $this->driver->add( $this->build_key( $key, $group ), $data, $this->ttl( $expire ) );

				if ( ! $added ) {
					// Ключ уже есть или сервер не принял запись. В обоих случаях
					// добавления не произошло: типовой паттерн «успешный add =
					// захваченная блокировка» не должен получать ложное «да».
					return false;
				}
			} catch ( Throwable $e ) {
				$this->log( 'add(): ' . $e->getMessage() );

				return false;
			}
		}

		$this->cache[ $this->runtime_key( $key, $group ) ] = is_object( $data ) ? clone $data : $data;

		return true;
	}

	/**
	 * Добавить набор значений.
	 *
	 * @since 1.0.0
	 *
	 * @param array  $data   Пары ключ → значение.
	 * @param string $group  Группа.
	 * @param int    $expire Время жизни.
	 * @return array
	 */
	public function add_multiple( array $data, $group = 'default', $expire = 0 ) {
		$values = array();

		foreach ( $data as $key => $value ) {
			$values[ $key ] = $this->add( $key, $value, $group, $expire );
		}

		return $values;
	}

	/**
	 * Записать значение.
	 *
	 * @since 1.0.0
	 *
	 * @param string|int $key    Ключ.
	 * @param mixed      $data   Значение.
	 * @param string     $group  Группа.
	 * @param int        $expire Время жизни.
	 * @return bool
	 */
	public function set( $key, $data, $group = 'default', $expire = 0 ) {
		if ( ! $this->is_valid_key( $key ) ) {
			return false;
		}

		$group = $this->group( $group );

		if ( $this->is_persistent( $group ) ) {
			try {
				$stored = $this->driver->set( $this->build_key( $key, $group ), $data, $this->ttl( $expire ) );

				if ( ! $stored && $this->driver->too_big() ) {
					$this->log( 'Объект больше лимита Memcached, оставлен в памяти запроса: ' . $group . ':' . $key );
				}
			} catch ( Throwable $e ) {
				$this->log( 'set(): ' . $e->getMessage() );
			}
		}

		$this->cache[ $this->runtime_key( $key, $group ) ] = is_object( $data ) ? clone $data : $data;

		return true;
	}

	/**
	 * Записать набор значений.
	 *
	 * @since 1.0.0
	 *
	 * @param array  $data   Пары ключ → значение.
	 * @param string $group  Группа.
	 * @param int    $expire Время жизни.
	 * @return array
	 */
	public function set_multiple( array $data, $group = 'default', $expire = 0 ) {
		$values = array();

		foreach ( $data as $key => $value ) {
			$values[ $key ] = $this->set( $key, $value, $group, $expire );
		}

		return $values;
	}

	/**
	 * Перезаписать значение, если ключ уже есть.
	 *
	 * @since 1.0.0
	 *
	 * @param string|int $key    Ключ.
	 * @param mixed      $data   Значение.
	 * @param string     $group  Группа.
	 * @param int        $expire Время жизни.
	 * @return bool
	 */
	public function replace( $key, $data, $group = 'default', $expire = 0 ) {
		$group = $this->group( $group );
		$found = false;

		$this->get( $key, $group, false, $found );

		if ( ! $found ) {
			return false;
		}

		return $this->set( $key, $data, $group, $expire );
	}

	/**
	 * Получить значение.
	 *
	 * @since 1.0.0
	 *
	 * @param string|int $key   Ключ.
	 * @param string     $group Группа.
	 * @param bool       $force Читать в обход кеша запроса.
	 * @param bool       $found Признак попадания.
	 * @return mixed
	 */
	public function get( $key, $group = 'default', $force = false, &$found = null ) {
		if ( ! $this->is_valid_key( $key ) ) {
			$found = false;

			return false;
		}

		$group       = $this->group( $group );
		$runtime_key = $this->runtime_key( $key, $group );

		if ( ! $force && isset( $this->cache[ $runtime_key ] ) ) {
			$found = true;
			$value = $this->cache[ $runtime_key ];

			return is_object( $value ) ? clone $value : $value;
		}

		if ( ! $this->is_persistent( $group ) ) {
			$found = array_key_exists( $runtime_key, $this->cache );

			return $found ? $this->cache[ $runtime_key ] : false;
		}

		try {
			$status = 'error';
			$value  = $this->driver->get( $this->build_key( $key, $group ), $status );

			if ( 'hit' !== $status ) {
				$found = false;

				return false;
			}
		} catch ( Throwable $e ) {
			$this->log( 'get(): ' . $e->getMessage() );
			$found = false;

			return false;
		}

		$this->cache[ $runtime_key ] = $value;
		$found                       = true;

		return is_object( $value ) ? clone $value : $value;
	}

	/**
	 * Получить набор значений.
	 *
	 * @since 1.0.0
	 *
	 * @param array  $keys  Ключи.
	 * @param string $group Группа.
	 * @param bool   $force Читать в обход кеша запроса.
	 * @return array
	 */
	public function get_multiple( $keys, $group = 'default', $force = false ) {
		$values = array();

		foreach ( (array) $keys as $key ) {
			$values[ $key ] = $this->get( $key, $group, $force );
		}

		return $values;
	}

	/**
	 * Удалить значение.
	 *
	 * @since 1.0.0
	 *
	 * @param string|int $key   Ключ.
	 * @param string     $group Группа.
	 * @return bool
	 */
	public function delete( $key, $group = 'default' ) {
		if ( ! $this->is_valid_key( $key ) ) {
			return false;
		}

		$group       = $this->group( $group );
		$runtime_key = $this->runtime_key( $key, $group );
		$existed     = array_key_exists( $runtime_key, $this->cache );

		unset( $this->cache[ $runtime_key ] );

		if ( ! $this->is_persistent( $group ) ) {
			return $existed;
		}

		try {
			$deleted = $this->driver->delete( $this->build_key( $key, $group ) );
		} catch ( Throwable $e ) {
			$this->log( 'delete(): ' . $e->getMessage() );

			return false;
		}

		return $deleted || $existed;
	}

	/**
	 * Удалить набор значений.
	 *
	 * @since 1.0.0
	 *
	 * @param array  $keys  Ключи.
	 * @param string $group Группа.
	 * @return array
	 */
	public function delete_multiple( array $keys, $group = 'default' ) {
		$values = array();

		foreach ( $keys as $key ) {
			$values[ $key ] = $this->delete( $key, $group );
		}

		return $values;
	}

	/**
	 * Увеличить числовое значение.
	 *
	 * @since 1.0.0
	 *
	 * @param string|int $key    Ключ.
	 * @param int        $offset Шаг.
	 * @param string     $group  Группа.
	 * @return int|false
	 */
	public function incr( $key, $offset = 1, $group = 'default' ) {
		$group  = $this->group( $group );
		$offset = (int) $offset;

		if ( $this->is_persistent( $group ) ) {
			try {
				$value = $this->driver->incr( $this->build_key( $key, $group ), $offset );

				if ( false !== $value ) {
					$this->cache[ $this->runtime_key( $key, $group ) ] = $value;

					return $value;
				}
			} catch ( Throwable $e ) {
				$this->log( 'incr(): ' . $e->getMessage() );
			}
		}

		$current = $this->get( $key, $group );

		if ( ! is_numeric( $current ) ) {
			return false;
		}

		$value = max( 0, (int) $current + $offset );
		$this->set( $key, $value, $group );

		return $value;
	}

	/**
	 * Уменьшить числовое значение.
	 *
	 * @since 1.0.0
	 *
	 * @param string|int $key    Ключ.
	 * @param int        $offset Шаг.
	 * @param string     $group  Группа.
	 * @return int|false
	 */
	public function decr( $key, $offset = 1, $group = 'default' ) {
		$group  = $this->group( $group );
		$offset = (int) $offset;

		if ( $this->is_persistent( $group ) ) {
			try {
				$value = $this->driver->decr( $this->build_key( $key, $group ), $offset );

				if ( false !== $value ) {
					$this->cache[ $this->runtime_key( $key, $group ) ] = $value;

					return $value;
				}
			} catch ( Throwable $e ) {
				$this->log( 'decr(): ' . $e->getMessage() );
			}
		}

		$current = $this->get( $key, $group );

		if ( ! is_numeric( $current ) ) {
			return false;
		}

		$value = max( 0, (int) $current - $offset );
		$this->set( $key, $value, $group );

		return $value;
	}

	/**
	 * Сбросить кеш своего префикса. Чужие сайты на том же сервере не задеты.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public function flush() {
		$this->cache = array();

		if ( ! $this->connected ) {
			return true;
		}

		try {
			$generation = $this->generation();
			$next       = $this->driver->incr( $this->prefix . ':generation', 1 );

			if ( false === $next ) {
				$next = $generation + 1;

				if ( ! $this->driver->set( $this->prefix . ':generation', $next, 0 ) ) {
					$this->log( 'flush(): счётчик поколения не записан.' );

					return false;
				}
			}

			$this->generation = (int) $next;
		} catch ( Throwable $e ) {
			$this->log( 'flush(): ' . $e->getMessage() );

			return false;
		}

		return true;
	}

	/**
	 * Очистить только кеш текущего запроса.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public function flush_runtime() {
		$this->cache = array();

		return true;
	}

	/**
	 * Сбросить группу. Отдельного механизма нет — сбрасываем свой префикс целиком.
	 *
	 * @since 1.0.0
	 *
	 * @param string $group Группа.
	 * @return bool
	 */
	public function flush_group( $group ) {
		$group = $this->group( $group );

		// Непостоянные группы на сервер не попадают, поэтому сбрасывать весь
		// префикс из-за них не нужно. Так WooCommerce, вызывающий
		// wp_cache_flush_group( 'coupons' ), не сносит кеш всего сайта.
		if ( ! $this->is_persistent( $group ) ) {
			$prefix = $group . ':';

			foreach ( array_keys( $this->cache ) as $runtime_key ) {
				if ( 0 === strpos( $runtime_key, $prefix ) ) {
					unset( $this->cache[ $runtime_key ] );
				}
			}

			return true;
		}

		return $this->flush();
	}

	/**
	 * Поддерживаемые возможности кеша.
	 *
	 * @since 1.0.0
	 *
	 * @param string $feature Возможность.
	 * @return bool
	 */
	public function supports( $feature ) {
		switch ( $feature ) {
			case 'get_multiple':
			case 'set_multiple':
			case 'add_multiple':
			case 'delete_multiple':
			case 'flush_runtime':
				return true;
			case 'flush_group':
				return false;
			default:
				return false;
		}
	}

	/**
	 * Зарегистрировать глобальные группы.
	 *
	 * @since 1.0.0
	 *
	 * @param string|array $groups Группы.
	 * @return void
	 */
	public function add_global_groups( $groups ) {
		$this->global_groups = array_unique( array_merge( $this->global_groups, (array) $groups ) );
	}

	/**
	 * Зарегистрировать группы, которые не уходят на сервер.
	 *
	 * @since 1.0.0
	 *
	 * @param string|array $groups Группы.
	 * @return void
	 */
	public function add_non_persistent_groups( $groups ) {
		$this->non_persistent = array_unique( array_merge( $this->non_persistent, (array) $groups ) );
	}

	/**
	 * Переключение сайта. Мультисайт плагином не поддерживается.
	 *
	 * @since 1.0.0
	 *
	 * @param int $blog_id ID сайта.
	 * @return void
	 */
	public function switch_to_blog( $blog_id ) {
		$this->cache = array();
	}

	/**
	 * Совместимость со старым wp_cache_reset(): очищает кеш запроса.
	 *
	 * @since      1.0.0
	 * @deprecated Ядро объявило функцию устаревшей в 3.5.0, но объявляет её в
	 *             wp-includes/cache.php, который этот файл замещает.
	 *
	 * @return void
	 */
	public function reset() {
		$this->cache = array();
	}

	/**
	 * Закрыть соединение.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public function close() {
		return true;
	}

	/**
	 * Диагностические данные для страницы плагина и WP-CLI.
	 *
	 * @since 1.0.0
	 *
	 * @return array
	 */
	public function mvweb_status() {
		return array(
			'connected'      => $this->connected,
			'extension'      => $this->extension,
			'error'          => $this->last_error,
			'prefix'         => $this->prefix,
			'generation'     => $this->generation(),
			'non_persistent' => $this->non_persistent,
			'dropin_version' => MVWEB_MC_DROPIN_VERSION,
		);
	}
}

/**
 * Инициализация кеша.
 *
 * @since 1.0.0
 *
 * @return void
 */
function wp_cache_init() {
	$GLOBALS['wp_object_cache'] = new WP_Object_Cache();
}

/**
 * Добавить значение, если ключа ещё нет.
 *
 * @since 1.0.0
 *
 * @param string|int $key    Ключ.
 * @param mixed      $data   Значение.
 * @param string     $group  Группа.
 * @param int        $expire Время жизни.
 * @return bool
 */
function wp_cache_add( $key, $data, $group = '', $expire = 0 ) {
	return $GLOBALS['wp_object_cache']->add( $key, $data, $group, (int) $expire );
}

/**
 * Добавить набор значений.
 *
 * @since 1.0.0
 *
 * @param array  $data   Пары ключ → значение.
 * @param string $group  Группа.
 * @param int    $expire Время жизни.
 * @return array
 */
function wp_cache_add_multiple( array $data, $group = '', $expire = 0 ) {
	return $GLOBALS['wp_object_cache']->add_multiple( $data, $group, (int) $expire );
}

/**
 * Записать значение.
 *
 * @since 1.0.0
 *
 * @param string|int $key    Ключ.
 * @param mixed      $data   Значение.
 * @param string     $group  Группа.
 * @param int        $expire Время жизни.
 * @return bool
 */
function wp_cache_set( $key, $data, $group = '', $expire = 0 ) {
	return $GLOBALS['wp_object_cache']->set( $key, $data, $group, (int) $expire );
}

/**
 * Записать набор значений.
 *
 * @since 1.0.0
 *
 * @param array  $data   Пары ключ → значение.
 * @param string $group  Группа.
 * @param int    $expire Время жизни.
 * @return array
 */
function wp_cache_set_multiple( array $data, $group = '', $expire = 0 ) {
	return $GLOBALS['wp_object_cache']->set_multiple( $data, $group, (int) $expire );
}

/**
 * Перезаписать значение, если ключ уже есть.
 *
 * @since 1.0.0
 *
 * @param string|int $key    Ключ.
 * @param mixed      $data   Значение.
 * @param string     $group  Группа.
 * @param int        $expire Время жизни.
 * @return bool
 */
function wp_cache_replace( $key, $data, $group = '', $expire = 0 ) {
	return $GLOBALS['wp_object_cache']->replace( $key, $data, $group, (int) $expire );
}

/**
 * Получить значение.
 *
 * @since 1.0.0
 *
 * @param string|int $key   Ключ.
 * @param string     $group Группа.
 * @param bool       $force Читать в обход кеша запроса.
 * @param bool       $found Признак попадания.
 * @return mixed
 */
function wp_cache_get( $key, $group = '', $force = false, &$found = null ) {
	return $GLOBALS['wp_object_cache']->get( $key, $group, $force, $found );
}

/**
 * Получить набор значений.
 *
 * @since 1.0.0
 *
 * @param array  $keys  Ключи.
 * @param string $group Группа.
 * @param bool   $force Читать в обход кеша запроса.
 * @return array
 */
function wp_cache_get_multiple( $keys, $group = '', $force = false ) {
	return $GLOBALS['wp_object_cache']->get_multiple( $keys, $group, $force );
}

/**
 * Удалить значение.
 *
 * @since 1.0.0
 *
 * @param string|int $key   Ключ.
 * @param string     $group Группа.
 * @return bool
 */
function wp_cache_delete( $key, $group = '' ) {
	return $GLOBALS['wp_object_cache']->delete( $key, $group );
}

/**
 * Удалить набор значений.
 *
 * @since 1.0.0
 *
 * @param array  $keys  Ключи.
 * @param string $group Группа.
 * @return array
 */
function wp_cache_delete_multiple( array $keys, $group = '' ) {
	return $GLOBALS['wp_object_cache']->delete_multiple( $keys, $group );
}

/**
 * Увеличить числовое значение.
 *
 * @since 1.0.0
 *
 * @param string|int $key    Ключ.
 * @param int        $offset Шаг.
 * @param string     $group  Группа.
 * @return int|false
 */
function wp_cache_incr( $key, $offset = 1, $group = '' ) {
	return $GLOBALS['wp_object_cache']->incr( $key, $offset, $group );
}

/**
 * Уменьшить числовое значение.
 *
 * @since 1.0.0
 *
 * @param string|int $key    Ключ.
 * @param int        $offset Шаг.
 * @param string     $group  Группа.
 * @return int|false
 */
function wp_cache_decr( $key, $offset = 1, $group = '' ) {
	return $GLOBALS['wp_object_cache']->decr( $key, $offset, $group );
}

/**
 * Сбросить кеш своего префикса.
 *
 * @since 1.0.0
 *
 * @return bool
 */
function wp_cache_flush() {
	return $GLOBALS['wp_object_cache']->flush();
}

/**
 * Очистить кеш текущего запроса.
 *
 * @since 1.0.0
 *
 * @return bool
 */
function wp_cache_flush_runtime() {
	return $GLOBALS['wp_object_cache']->flush_runtime();
}

/**
 * Сбросить группу.
 *
 * @since 1.0.0
 *
 * @param string $group Группа.
 * @return bool
 */
function wp_cache_flush_group( $group ) {
	return $GLOBALS['wp_object_cache']->flush_group( $group );
}

/**
 * Поддерживаемые возможности кеша.
 *
 * @since 1.0.0
 *
 * @param string $feature Возможность.
 * @return bool
 */
function wp_cache_supports( $feature ) {
	return $GLOBALS['wp_object_cache']->supports( $feature );
}

/**
 * Совместимость со старым кодом: очищает кеш запроса.
 *
 * @since      1.0.0
 * @deprecated 3.5.0 Ядро рекомендует wp_cache_switch_to_blog().
 *
 * @return void
 */
function wp_cache_reset() {
	$GLOBALS['wp_object_cache']->reset();
}

/**
 * Закрыть соединение.
 *
 * @since 1.0.0
 *
 * @return bool
 */
function wp_cache_close() {
	return $GLOBALS['wp_object_cache']->close();
}

/**
 * Зарегистрировать глобальные группы.
 *
 * @since 1.0.0
 *
 * @param string|array $groups Группы.
 * @return void
 */
function wp_cache_add_global_groups( $groups ) {
	$GLOBALS['wp_object_cache']->add_global_groups( $groups );
}

/**
 * Зарегистрировать группы, которые не уходят на сервер.
 *
 * @since 1.0.0
 *
 * @param string|array $groups Группы.
 * @return void
 */
function wp_cache_add_non_persistent_groups( $groups ) {
	$GLOBALS['wp_object_cache']->add_non_persistent_groups( $groups );
}

/**
 * Переключение сайта.
 *
 * @since 1.0.0
 *
 * @param int $blog_id ID сайта.
 * @return void
 */
function wp_cache_switch_to_blog( $blog_id ) {
	$GLOBALS['wp_object_cache']->switch_to_blog( $blog_id );
}
