<?php
/**
 * Проверка доступности Memcached, тест работы и автопоиск параметров.
 *
 * @package mvweb_mc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Диагностика соединения с Memcached.
 *
 * @since 1.0.0
 */
class MVweb_MC_Connection {

	/**
	 * Типовые пути Unix-сокетов, которые встречаются на хостингах.
	 *
	 * Проверяются только те, файл которых реально существует.
	 *
	 * @var string[]
	 */
	const SOCKET_CANDIDATES = array(
		'/var/run/memcached/memcached.sock',
		'/var/run/memcached.sock',
		'/tmp/memcached.sock',
		'/var/lib/memcached/memcached.sock',
	);

	/**
	 * Установлено ли PHP-расширение Memcached.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public static function has_extension(): bool {
		return '' !== self::extension_name();
	}

	/**
	 * Какое расширение будет использовано: новое memcached или старое memcache.
	 *
	 * @since 1.0.0
	 *
	 * @return string Пустая строка, если нет ни одного.
	 */
	public static function extension_name(): string {
		if ( class_exists( 'Memcached' ) ) {
			return 'memcached';
		}

		if ( class_exists( 'Memcache' ) ) {
			return 'memcache';
		}

		return '';
	}

	/**
	 * Версия расширения Memcached.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function extension_version(): string {
		$name = self::extension_name();

		if ( '' === $name ) {
			return '';
		}

		$version = phpversion( $name );

		return is_string( $version ) ? $version : '';
	}

	/**
	 * Три уровня проверки: расширение → соединение → запись и чтение.
	 *
	 * @since 1.0.0
	 *
	 * @param string|null $host Адрес; null — из настроек.
	 * @param int|null    $port Порт; null — из настроек.
	 * @return array<string, mixed>
	 */
	public static function diagnose( ?string $host = null, ?int $port = null ): array {
		$result = array(
			'extension'  => array(
				'ok'      => false,
				'message' => '',
			),
			'connection' => array(
				'ok'      => false,
				'message' => '',
			),
			'readwrite'  => array(
				'ok'      => false,
				'message' => '',
			),
			'shared'     => null,
		);

		if ( ! self::has_extension() ) {
			$result['extension']['message']  = __( 'Neither the memcached nor the memcache PHP extension is installed. Enable one in your hosting control panel or ask your hosting support.', 'mvweb-memcached' );
			$result['connection']['message'] = __( 'Not checked: the extension is missing.', 'mvweb-memcached' );
			$result['readwrite']['message']  = __( 'Not checked: the extension is missing.', 'mvweb-memcached' );

			return $result;
		}

		$version = self::extension_version();

		$result['extension']['ok']      = true;
		$result['extension']['message'] = '' === $version
			? sprintf(
				/* translators: %s: имя PHP-расширения. */
				__( 'The %s extension is installed.', 'mvweb-memcached' ),
				self::extension_name()
			)
			: sprintf(
				/* translators: 1: имя PHP-расширения, 2: его версия. */
				__( 'The %1$s extension is installed, version %2$s.', 'mvweb-memcached' ),
				self::extension_name(),
				$version
			);

		$host = null === $host ? (string) MVweb_MC_Settings::get( 'host' ) : $host;
		$port = null === $port ? (int) MVweb_MC_Settings::get( 'port' ) : $port;

		$mc = self::connect( $host, $port );

		if ( null === $mc ) {
			$result['connection']['message'] = sprintf(
				/* translators: %s: адрес сервера. */
				__( 'Could not connect to %s. Check the address and port in your hosting control panel or ask your hosting support.', 'mvweb-memcached' ),
				self::format_target( $host, $port )
			);
			$result['readwrite']['message'] = __( 'Not checked: no connection.', 'mvweb-memcached' );

			return $result;
		}

		$result['connection']['ok']      = true;
		$result['connection']['message'] = sprintf(
			/* translators: %s: адрес сервера. */
			__( 'Connected to %s.', 'mvweb-memcached' ),
			self::format_target( $host, $port )
		);

		$readwrite                      = self::test_read_write( $mc );
		$result['readwrite']['ok']      = $readwrite['ok'];
		$result['readwrite']['message'] = $readwrite['message'];
		$result['shared']               = self::detect_shared( $mc );

		return $result;
	}

	/**
	 * Полный цикл set → get → delete со сверкой значения.
	 *
	 * @since 1.0.0
	 *
	 * @param Memcached|Memcache $mc Соединение.
	 * @return array{ok: bool, message: string}
	 */
	private static function test_read_write( object $mc ): array {
		$prefix = (string) MVweb_MC_Settings::get( 'prefix' );
		$key    = $prefix . ':selftest:' . wp_generate_password( 8, false );
		$value  = 'mvweb-' . wp_generate_password( 12, false );

		$is_memcached = $mc instanceof Memcached;

		try {
			$stored = $is_memcached ? $mc->set( $key, $value, 60 ) : $mc->set( $key, $value, 0, 60 );

			if ( ! $stored ) {
				return array(
					'ok'      => false,
					'message' => $is_memcached
						? sprintf(
							/* translators: %d: код ошибки расширения. */
							__( 'The server refused to store the test value (code %d). Check whether the allocated memory is sufficient.', 'mvweb-memcached' ),
							$mc->getResultCode()
						)
						: __( 'The server refused to store the test value. Check whether the allocated memory is sufficient.', 'mvweb-memcached' ),
				);
			}

			$read = $mc->get( $key );

			if ( $read !== $value ) {
				return array(
					'ok'      => false,
					'message' => __( 'The stored value was read back incorrectly. The server is unstable, so the cache must not be enabled.', 'mvweb-memcached' ),
				);
			}

			$mc->delete( $key );

			if ( false !== $mc->get( $key ) ) {
				return array(
					'ok'      => false,
					'message' => __( 'Values are not deleted from the server. The cache would serve stale data, so it must not be enabled.', 'mvweb-memcached' ),
				);
			}
		} catch ( Throwable $e ) {
			return array(
				'ok'      => false,
				'message' => sprintf(
					/* translators: %s: текст ошибки. */
					__( 'Write check failed: %s', 'mvweb-memcached' ),
					$e->getMessage()
				),
			);
		}

		return array(
			'ok'      => true,
			'message' => __( 'Write, read and delete work correctly.', 'mvweb-memcached' ),
		);
	}

	/**
	 * Признак общего сервера: на нём лежат данные не только нашего сайта.
	 *
	 * @since 1.0.0
	 *
	 * @param Memcached|Memcache $mc Соединение.
	 * @return array<string, mixed>|null
	 */
	private static function detect_shared( object $mc ): ?array {
		try {
			$stats = $mc instanceof Memcached ? $mc->getStats() : $mc->getExtendedStats();
		} catch ( Throwable $e ) {
			return null;
		}

		if ( ! is_array( $stats ) || empty( $stats ) ) {
			return null;
		}

		$items = 0;

		foreach ( $stats as $server ) {
			if ( is_array( $server ) && isset( $server['curr_items'] ) ) {
				$items += (int) $server['curr_items'];
			}
		}

		return array(
			'items'  => $items,
			'shared' => $items > 0,
			'prefix' => (string) MVweb_MC_Settings::get( 'prefix' ),
		);
	}

	/**
	 * Подключение к серверу с жёсткими таймаутами.
	 *
	 * Используется то же расширение, что возьмёт drop-in: новое memcached,
	 * а при его отсутствии старое memcache.
	 *
	 * @since 1.0.0
	 *
	 * @param string $host Адрес или путь к сокету.
	 * @param int    $port Порт.
	 * @return object|null Memcached, Memcache или null.
	 */
	public static function connect( string $host, int $port ) {
		try {
			if ( class_exists( 'Memcached' ) ) {
				return self::connect_memcached( $host, $port );
			}

			if ( class_exists( 'Memcache' ) ) {
				return self::connect_memcache( $host, $port );
			}
		} catch ( Throwable $e ) {
			return null;
		}

		return null;
	}

	/**
	 * Подключение через новое расширение.
	 *
	 * @since 1.0.0
	 *
	 * @param string $host Адрес или путь к сокету.
	 * @param int    $port Порт.
	 * @return Memcached|null
	 */
	private static function connect_memcached( string $host, int $port ): ?Memcached {
		$mc = new Memcached();
		$mc->setOption( Memcached::OPT_BINARY_PROTOCOL, true );
		$mc->setOption( Memcached::OPT_CONNECT_TIMEOUT, 1000 );
		$mc->setOption( Memcached::OPT_SEND_TIMEOUT, 500000 );
		$mc->setOption( Memcached::OPT_RECV_TIMEOUT, 500000 );
		$mc->setOption( Memcached::OPT_POLL_TIMEOUT, 500 );

		$user = (string) MVweb_MC_Settings::get( 'sasl_user' );
		$pass = (string) MVweb_MC_Settings::get( 'sasl_pass' );

		if ( '' !== $user && method_exists( $mc, 'setSaslAuthData' ) ) {
			$mc->setSaslAuthData( $user, $pass );
		}

		if ( str_starts_with( $host, '/' ) ) {
			$mc->addServer( $host, 0 );
		} else {
			$mc->addServer( $host, $port );
		}

		$mc->get( 'mvweb_mc_probe' );
		$code = $mc->getResultCode();

		if ( Memcached::RES_SUCCESS !== $code && Memcached::RES_NOTFOUND !== $code ) {
			return null;
		}

		return $mc;
	}

	/**
	 * Подключение через старое расширение.
	 *
	 * @since 1.0.0
	 *
	 * @param string $host Адрес или путь к сокету.
	 * @param int    $port Порт.
	 * @return Memcache|null
	 */
	private static function connect_memcache( string $host, int $port ): ?Memcache {
		if ( str_starts_with( $host, '/' ) ) {
			$host = 'unix://' . $host;
			$port = 0;
		}

		$mc = new Memcache();

		if ( ! @$mc->connect( $host, $port, 1 ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- недоступный сервер сообщаем результатом, а не варнингом.
			return null;
		}

		return $mc;
	}

	/**
	 * Начать новое поколение ключей.
	 *
	 * Пока кеш выключен, WordPress пишет только в базу, а прежние ключи остаются
	 * на сервере. Без смены поколения включение кеша вернуло бы сайт к снимку
	 * данных на момент выключения — вплоть до пропажи активированных плагинов.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public static function start_new_generation(): bool {
		$mc = self::connect(
			(string) MVweb_MC_Settings::get( 'host' ),
			(int) MVweb_MC_Settings::get( 'port' )
		);

		if ( null === $mc ) {
			return false;
		}

		$key = MVweb_MC_Settings::get( 'prefix' ) . ':generation';

		// Метка времени монотонно растёт, поэтому новое поколение заведомо
		// не совпадёт ни с одним из прежних.
		$generation = time();

		if ( $mc instanceof Memcached ) {
			return (bool) $mc->set( $key, $generation, 0 );
		}

		return (bool) @$mc->set( $key, $generation, 0, 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- результат возвращаем значением.
	}

	/**
	 * Автопоиск: перебор типовых адресов до первого ответившего.
	 *
	 * @since 1.0.0
	 *
	 * @return array{found: bool, host: string, port: int, tried: array<int, string>}
	 */
	public static function autodetect(): array {
		$tried      = array();
		$candidates = array(
			array( '127.0.0.1', 11211 ),
			array( 'localhost', 11211 ),
		);

		foreach ( self::SOCKET_CANDIDATES as $socket ) {
			if ( file_exists( $socket ) ) {
				$candidates[] = array( $socket, 0 );
			}
		}

		foreach ( $candidates as $candidate ) {
			list( $host, $port ) = $candidate;
			$tried[]             = self::format_target( $host, (int) $port );

			if ( null !== self::connect( $host, (int) $port ) ) {
				return array(
					'found' => true,
					'host'  => $host,
					'port'  => (int) $port,
					'tried' => $tried,
				);
			}
		}

		return array(
			'found' => false,
			'host'  => '',
			'port'  => 0,
			'tried' => $tried,
		);
	}

	/**
	 * Человекочитаемый адрес сервера.
	 *
	 * @since 1.0.0
	 *
	 * @param string $host Адрес.
	 * @param int    $port Порт.
	 * @return string
	 */
	public static function format_target( string $host, int $port ): string {
		return str_starts_with( $host, '/' ) ? $host : $host . ':' . $port;
	}
}
