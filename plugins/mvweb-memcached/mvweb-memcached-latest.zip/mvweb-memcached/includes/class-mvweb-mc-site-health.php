<?php
/**
 * Интеграция со «Здоровьем сайта» WordPress.
 *
 * @package mvweb_mc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Тест и сведения о состоянии кеша объектов.
 *
 * @since 1.0.0
 */
class MVweb_MC_Site_Health {

	/**
	 * Подключить хуки.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function init(): void {
		add_filter( 'site_status_tests', array( __CLASS__, 'register_test' ) );
		add_filter( 'debug_information', array( __CLASS__, 'register_debug_info' ) );
	}

	/**
	 * Зарегистрировать прямой тест.
	 *
	 * @since 1.0.0
	 *
	 * @param array<string, mixed> $tests Тесты «Здоровья сайта».
	 * @return array<string, mixed>
	 */
	public static function register_test( array $tests ): array {
		$tests['direct']['mvweb_mc_memcached'] = array(
			'label' => __( 'Memcached object cache', 'mvweb-memcached' ),
			'test'  => array( __CLASS__, 'run_test' ),
		);

		return $tests;
	}

	/**
	 * Результат теста для экрана «Здоровье сайта».
	 *
	 * @since 1.0.0
	 *
	 * @return array<string, mixed>
	 */
	public static function run_test(): array {
		$result = array(
			'label'       => __( 'Memcached is connected and working', 'mvweb-memcached' ),
			'status'      => 'good',
			'badge'       => array(
				'label' => __( 'Performance', 'mvweb-memcached' ),
				'color' => 'blue',
			),
			'description' => '',
			'actions'     => sprintf(
				'<p><a href="%s">%s</a></p>',
				esc_url( admin_url( 'admin.php?page=mvweb-memcached' ) ),
				esc_html__( 'Open MVweb Memcached settings', 'mvweb-memcached' )
			),
			'test'        => 'mvweb_mc_memcached',
		);

		$dropin = MVweb_MC_Dropin::status();

		if ( $dropin['exists'] && ! $dropin['ours'] ) {
			$result['status']      = 'recommended';
			$result['label']       = __( 'Object cache is taken by another plugin', 'mvweb-memcached' );
			$result['description'] = '<p>' . sprintf(
				/* translators: %s: имя плагина-владельца drop-in. */
				esc_html__( 'The object-cache.php file belongs to "%s". MVweb Memcached leaves it untouched.', 'mvweb-memcached' ),
				esc_html( (string) $dropin['foreign'] )
			) . '</p>';

			return $result;
		}

		if ( ! $dropin['ours'] ) {
			$result['status']      = 'recommended';
			$result['label']       = __( 'Persistent object cache is not enabled', 'mvweb-memcached' );
			$result['description'] = '<p>' . esc_html__( 'The site runs without a persistent object cache: database query results are not reused between page requests.', 'mvweb-memcached' ) . '</p>';

			return $result;
		}

		$diagnosis = MVweb_MC_Connection::diagnose();

		if ( ! $diagnosis['readwrite']['ok'] ) {
			$result['status']      = 'critical';
			$result['label']       = __( 'Object cache is enabled, but Memcached is unavailable', 'mvweb-memcached' );
			$result['description'] = '<p>' . esc_html( (string) ( $diagnosis['connection']['ok'] ? $diagnosis['readwrite']['message'] : $diagnosis['connection']['message'] ) ) . '</p>'
				. '<p>' . esc_html__( 'The site keeps working without the cache, only slower.', 'mvweb-memcached' ) . '</p>';

			return $result;
		}

		$result['description'] = '<p>' . esc_html(
			sprintf(
				/* translators: %s: адрес сервера. */
				__( 'The persistent object cache runs through %s.', 'mvweb-memcached' ),
				MVweb_MC_Connection::format_target( (string) MVweb_MC_Settings::get( 'host' ), (int) MVweb_MC_Settings::get( 'port' ) )
			)
		) . '</p>';

		if ( $dropin['outdated'] ) {
			$result['status']       = 'recommended';
			$result['label']        = __( 'The object cache file is outdated', 'mvweb-memcached' );
			$result['description'] .= '<p>' . esc_html__( 'The plugin was updated while object-cache.php stayed the same. Update it on the plugin page.', 'mvweb-memcached' ) . '</p>';
		}

		return $result;
	}

	/**
	 * Строки в разделе «Сведения».
	 *
	 * @since 1.0.0
	 *
	 * @param array<string, mixed> $info Сведения о сайте.
	 * @return array<string, mixed>
	 */
	public static function register_debug_info( array $info ): array {
		$dropin    = MVweb_MC_Dropin::status();
		$diagnosis = MVweb_MC_Connection::diagnose();

		$info['mvweb-memcached'] = array(
			'label'  => __( 'MVweb Memcached', 'mvweb-memcached' ),
			'fields' => array(
				'extension' => array(
					'label' => __( 'PHP extension', 'mvweb-memcached' ),
					'value' => $diagnosis['extension']['ok']
						? MVweb_MC_Connection::extension_name() . ' ' . MVweb_MC_Connection::extension_version()
						: __( 'not installed', 'mvweb-memcached' ),
				),
				'server'    => array(
					'label'   => __( 'Server', 'mvweb-memcached' ),
					'value'   => MVweb_MC_Connection::format_target( (string) MVweb_MC_Settings::get( 'host' ), (int) MVweb_MC_Settings::get( 'port' ) ),
					'private' => true,
				),
				'dropin'    => array(
					'label' => __( 'object-cache.php file', 'mvweb-memcached' ),
					'value' => self::dropin_label( $dropin ),
				),
				'groups'    => array(
					'label' => __( 'Groups outside the persistent cache', 'mvweb-memcached' ),
					'value' => implode( ', ', MVweb_MC_Settings::non_persistent_groups() ),
				),
			),
		);

		return $info;
	}

	/**
	 * Текстовое описание состояния drop-in.
	 *
	 * @since 1.0.0
	 *
	 * @param array<string, mixed> $dropin Сводка состояния.
	 * @return string
	 */
	private static function dropin_label( array $dropin ): string {
		if ( ! $dropin['exists'] ) {
			return __( 'not present', 'mvweb-memcached' );
		}

		if ( ! $dropin['ours'] ) {
			return sprintf(
				/* translators: %s: имя плагина-владельца drop-in. */
				__( 'belongs to "%s"', 'mvweb-memcached' ),
				(string) $dropin['foreign']
			);
		}

		return sprintf(
			/* translators: 1: установленная версия, 2: версия в плагине. */
			__( 'MVweb, version %1$s (plugin ships %2$s)', 'mvweb-memcached' ),
			(string) $dropin['installed_version'],
			(string) $dropin['template_version']
		);
	}
}
