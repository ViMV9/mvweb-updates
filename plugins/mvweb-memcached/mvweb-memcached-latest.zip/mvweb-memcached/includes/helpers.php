<?php
/**
 * Helper functions for MVweb Memcached.
 *
 * @package mvweb_mc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
