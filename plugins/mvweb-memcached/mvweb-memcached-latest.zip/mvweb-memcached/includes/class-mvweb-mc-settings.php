<?php
/**
 * Настройки плагина: значения, константы wp-config, санитайз.
 *
 * @package mvweb_mc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Хранилище настроек подключения к Memcached.
 *
 * @since 1.0.0
 */
class MVweb_MC_Settings {

	const OPTION = 'mvweb_mc_settings';

	/**
	 * Отметка о том, что Memcached был недоступен при живом drop-in.
	 *
	 * Пока сервер не отвечает, правки в базе не вычищают старые ключи, поэтому
	 * после восстановления связи кеш нужно сбросить вручную.
	 */
	const OUTAGE_OPTION = 'mvweb_mc_outage';

	/**
	 * Настройки в памяти текущего запроса.
	 *
	 * @var array<string, mixed>|null
	 */
	private static ?array $memo = null;

	/**
	 * Соответствие ключей настроек константам wp-config.php.
	 *
	 * @var array<string, string>
	 */
	const CONSTANTS = array(
		'host'      => 'MVWEB_MC_HOST',
		'port'      => 'MVWEB_MC_PORT',
		'sasl_user' => 'MVWEB_MC_SASL_USER',
		'sasl_pass' => 'MVWEB_MC_SASL_PASS',
		'prefix'    => 'MVWEB_MC_PREFIX',
	);

	/**
	 * Группы, которые никогда не уходят на сервер.
	 *
	 * @var string[]
	 */
	const BASE_NON_PERSISTENT = array( 'counts', 'plugins', 'themes', 'comment' );

	/**
	 * Группы WooCommerce, подключаемые при обнаружении магазина.
	 *
	 * Обоснование каждой группы — в SPEC.md.
	 *
	 * @var string[]
	 */
	const WC_NON_PERSISTENT = array( 'wc_session_id', 'wc_rate_limit', 'coupons', 'product_objects', 'order_objects' );

	/**
	 * Значения по умолчанию.
	 *
	 * @since 1.0.0
	 *
	 * @return array<string, mixed>
	 */
	public static function defaults(): array {
		return array(
			'host'         => '127.0.0.1',
			'port'         => 11211,
			'sasl_user'    => '',
			'sasl_pass'    => '',
			'prefix'       => '',
			'extra_groups' => '',
		);
	}

	/**
	 * Все настройки с учётом констант wp-config.php.
	 *
	 * @since 1.0.0
	 *
	 * @return array<string, mixed>
	 */
	public static function all(): array {
		if ( null !== self::$memo ) {
			return self::$memo;
		}

		self::refresh();

		$stored = get_option( self::OPTION, array() );
		$values = wp_parse_args( is_array( $stored ) ? $stored : array(), self::defaults() );

		if ( '' === $values['prefix'] ) {
			$values['prefix'] = self::generate_prefix();
		}

		foreach ( self::CONSTANTS as $key => $constant ) {
			if ( defined( $constant ) ) {
				$values[ $key ] = constant( $constant );
			}
		}

		self::$memo = $values;

		return $values;
	}

	/**
	 * Сбросить кеш опции настроек.
	 *
	 * Настройки лежат в объектном кеше, который сами же и настраивают. Если
	 * связь с сервером терялась, кеш мог остаться со старым значением, и тогда
	 * drop-in получил бы устаревшие адрес и порт. Перед записью файла и после
	 * сохранения формы значение перечитывается из базы.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function refresh(): void {
		self::$memo = null;

		wp_cache_delete( self::OPTION, 'options' );
	}

	/**
	 * Одно значение настройки.
	 *
	 * @since 1.0.0
	 *
	 * @param string $key Ключ настройки.
	 * @return mixed
	 */
	public static function get( string $key ) {
		$values = self::all();

		return $values[ $key ] ?? null;
	}

	/**
	 * Задано ли значение константой в wp-config.php.
	 *
	 * @since 1.0.0
	 *
	 * @param string $key Ключ настройки.
	 * @return bool
	 */
	public static function is_locked( string $key ): bool {
		return isset( self::CONSTANTS[ $key ] ) && defined( self::CONSTANTS[ $key ] );
	}

	/**
	 * Сохранить настройки после санитайза.
	 *
	 * @since 1.0.0
	 *
	 * @param array<string, mixed> $input Сырые значения формы.
	 * @return array{0: bool, 1: string} Успех и текст ошибки.
	 */
	public static function save( array $input ): array {
		$current = get_option( self::OPTION, array() );
		$current = is_array( $current ) ? wp_parse_args( $current, self::defaults() ) : self::defaults();

		$host = isset( $input['host'] ) ? sanitize_text_field( wp_unslash( (string) $input['host'] ) ) : '';
		$port = isset( $input['port'] ) ? absint( $input['port'] ) : 0;

		if ( '' === $host ) {
			return array( false, __( 'Enter the Memcached server address.', 'mvweb-memcached' ) );
		}

		if ( ! self::is_valid_host( $host ) ) {
			return array( false, __( 'The address must be an IP address, a host name or a path to a Unix socket.', 'mvweb-memcached' ) );
		}

		$is_socket = str_starts_with( $host, '/' );

		if ( ! $is_socket && ( $port < 1 || $port > 65535 ) ) {
			return array( false, __( 'The port must be a number between 1 and 65535.', 'mvweb-memcached' ) );
		}

		$prefix = isset( $input['prefix'] ) ? sanitize_key( (string) $input['prefix'] ) : '';

		$values = array(
			'host'         => $host,
			'port'         => $is_socket ? 0 : $port,
			'sasl_user'    => isset( $input['sasl_user'] ) ? sanitize_text_field( wp_unslash( (string) $input['sasl_user'] ) ) : '',
			'sasl_pass'    => self::resolve_password( $input, $current ),
			'prefix'       => '' === $prefix ? $current['prefix'] : $prefix,
			'extra_groups' => self::sanitize_groups( $input['extra_groups'] ?? '' ),
		);

		if ( '' === $values['prefix'] ) {
			$values['prefix'] = self::generate_prefix();
		}

		update_option( self::OPTION, $values, false );
		self::refresh();

		return array( true, '' );
	}

	/**
	 * Пароль SASL: пустое поле означает «оставить прежний».
	 *
	 * @since 1.0.0
	 *
	 * @param array<string, mixed> $input   Значения формы.
	 * @param array<string, mixed> $current Текущие значения.
	 * @return string
	 */
	private static function resolve_password( array $input, array $current ): string {
		$password = isset( $input['sasl_pass'] ) ? (string) wp_unslash( $input['sasl_pass'] ) : '';

		return '' === $password ? (string) $current['sasl_pass'] : $password;
	}

	/**
	 * Проверка адреса: IP, имя хоста или путь к Unix-сокету.
	 *
	 * @since 1.0.0
	 *
	 * @param string $host Адрес.
	 * @return bool
	 */
	public static function is_valid_host( string $host ): bool {
		if ( str_starts_with( $host, '/' ) ) {
			return (bool) preg_match( '~^/[A-Za-z0-9._/-]+$~', $host );
		}

		if ( filter_var( $host, FILTER_VALIDATE_IP ) ) {
			return true;
		}

		return (bool) preg_match( '~^[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?$~', $host );
	}

	/**
	 * Разбор пользовательского списка групп.
	 *
	 * @since 1.0.0
	 *
	 * @param mixed $raw Строка с группами через запятую или перевод строки.
	 * @return string
	 */
	public static function sanitize_groups( $raw ): string {
		$parts  = preg_split( '~[\s,]+~', (string) wp_unslash( (string) $raw ) );
		$parts  = is_array( $parts ) ? $parts : array();
		$groups = array();

		foreach ( $parts as $part ) {
			$group = sanitize_key( $part );

			if ( '' !== $group ) {
				$groups[] = $group;
			}
		}

		return implode( ', ', array_unique( $groups ) );
	}

	/**
	 * Итоговый список non-persistent групп: база + WooCommerce + свои.
	 *
	 * @since 1.0.0
	 *
	 * @return string[]
	 */
	public static function non_persistent_groups(): array {
		$groups = self::BASE_NON_PERSISTENT;

		if ( self::has_woocommerce() ) {
			$groups = array_merge( $groups, self::WC_NON_PERSISTENT );
		}

		$extra = (string) self::get( 'extra_groups' );

		if ( '' !== $extra ) {
			$groups = array_merge( $groups, array_map( 'trim', explode( ',', $extra ) ) );
		}

		return array_values( array_unique( array_filter( $groups ) ) );
	}

	/**
	 * Наличие WooCommerce на сайте.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public static function has_woocommerce(): bool {
		return class_exists( 'WooCommerce' ) || defined( 'WC_VERSION' );
	}

	/**
	 * Запомнить, что кеш работал без связи с сервером.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function mark_outage(): void {
		if ( ! get_option( self::OUTAGE_OPTION ) ) {
			update_option( self::OUTAGE_OPTION, time(), false );
		}
	}

	/**
	 * Был ли простой, после которого кеш ещё не сбрасывали.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public static function had_outage(): bool {
		return (bool) get_option( self::OUTAGE_OPTION );
	}

	/**
	 * Снять отметку о простое.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function clear_outage(): void {
		delete_option( self::OUTAGE_OPTION );
	}

	/**
	 * Префикс ключей сайта: изоляция от соседей на shared-хостинге.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function generate_prefix(): string {
		global $table_prefix;

		$stored = get_option( self::OPTION, array() );
		$stored = is_array( $stored ) ? $stored : array();

		if ( ! empty( $stored['prefix'] ) ) {
			return (string) $stored['prefix'];
		}

		$seed   = ( defined( 'DB_NAME' ) ? DB_NAME : 'wp' ) . '|' . (string) $table_prefix . '|' . wp_generate_password( 16, false );
		$prefix = 'mvmc' . substr( md5( $seed ), 0, 12 );

		$stored['prefix'] = $prefix;
		update_option( self::OPTION, wp_parse_args( $stored, self::defaults() ), false );

		return $prefix;
	}
}
