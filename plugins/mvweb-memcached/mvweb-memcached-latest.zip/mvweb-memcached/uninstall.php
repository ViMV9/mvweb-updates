<?php
/**
 * Uninstall MVweb Memcached
 *
 * Порядок важен: сначала сбрасываем кеш своего префикса, пока drop-in ещё
 * на месте, затем убираем файл и только потом удаляем настройки.
 *
 * @package mvweb_mc
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$mvweb_mc_dropin  = WP_CONTENT_DIR . '/object-cache.php';
$mvweb_mc_is_ours = false;

if ( file_exists( $mvweb_mc_dropin ) ) {
	$mvweb_mc_head    = (string) file_get_contents( $mvweb_mc_dropin, false, null, 0, 2048 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- чтение шапки drop-in при удалении плагина.
	$mvweb_mc_is_ours = false !== strpos( $mvweb_mc_head, 'Drop-in Name: MVweb Memcached' );
}

// Сброс ключей нашего префикса, пока кеш ещё активен.
if ( $mvweb_mc_is_ours ) {
	wp_cache_flush();
}

// Удаление своего drop-in. Чужой файл не трогаем.
if ( $mvweb_mc_is_ours ) {
	if ( ! function_exists( 'WP_Filesystem' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}

	global $wp_filesystem;

	if ( WP_Filesystem() && $wp_filesystem instanceof WP_Filesystem_Base ) {
		$wp_filesystem->delete( $mvweb_mc_dropin );
	}
}

delete_option( 'mvweb_mc_settings' );
delete_option( 'mvweb_mc_outage' );
