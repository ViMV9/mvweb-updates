<?php
/**
 * Plugin Name:       MVweb Memcached
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-memcached
 * Description:       Connects WordPress to Memcached: availability check, connection test and persistent object cache.
 * Version:           1.0.1
 * Requires at least: 7.0
 * Tested up to:      7.1
 * Requires PHP:      8.2
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-memcached
 * Domain Path:       /languages
 *
 * @package mvweb_mc
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_MC_VERSION' ) ) {
	return;
}

define( 'MVWEB_MC_VERSION', '1.0.1' );
define( 'MVWEB_MC_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_MC_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_MC_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_MC_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_MC_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_MC_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_MC_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_MC_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-memcached' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter(
	'mvweb_registered_plugins',
	function ( $plugins ) {
		$plugins['mvweb-memcached'] = array(
			'name'         => 'MVweb Memcached',
			// Строка намеренно без __(): хаб собирает список на этапе загрузки плагинов,
			// а перевод до init вызывает предупреждение WordPress 6.7.
			'description'  => 'Connects WordPress to Memcached: availability check, connection test and persistent object cache.',
			'url'          => 'https://mvweb.ru/plugins/mvweb-memcached',
			'settings_url' => 'admin.php?page=mvweb-memcached',
			'textdomain'   => 'mvweb-memcached',
		);
		return $plugins;
	}
);

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_mc_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-memcached',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_mc_load_textdomain' );

// Load plugin classes.
require_once MVWEB_MC_PATH . 'includes/class-mvweb-mc-settings.php';
require_once MVWEB_MC_PATH . 'includes/class-mvweb-mc-connection.php';
require_once MVWEB_MC_PATH . 'includes/class-mvweb-mc-dropin.php';
require_once MVWEB_MC_PATH . 'includes/class-mvweb-mc-site-health.php';

MVweb_MC_Site_Health::init();

if ( is_admin() ) {
	require_once MVWEB_MC_PATH . 'admin/class-mvweb-mc-admin.php';
	MVweb_MC_Admin::init();
}

if ( defined( 'WP_CLI' ) && WP_CLI ) {
	require_once MVWEB_MC_PATH . 'includes/class-mvweb-mc-cli.php';
	WP_CLI::add_command( 'mvweb-mc', 'MVweb_MC_CLI' );
}

/**
 * Подготовить настройки при активации плагина.
 *
 * Drop-in не ставится автоматически: его включает пользователь кнопкой
 * после успешной проверки соединения.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_mc_activate() {
	MVweb_MC_Settings::generate_prefix();
}
register_activation_hook( __FILE__, 'mvweb_mc_activate' );

/**
 * Убрать свой drop-in при деактивации.
 *
 * Без плагина файл object-cache.php остался бы работать вслепую, поэтому
 * удаляем его — но только если он наш.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_mc_deactivate() {
	if ( MVweb_MC_Dropin::is_ours() ) {
		MVweb_MC_Dropin::remove();
	}
}
register_deactivation_hook( __FILE__, 'mvweb_mc_deactivate' );
