<?php
/**
 * Страница настроек, AJAX-обработчики и уведомления.
 *
 * @package mvweb_mc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Административный интерфейс плагина.
 *
 * @since 1.0.0
 */
class MVweb_MC_Admin {

	const PAGE         = 'mvweb-memcached';
	const NONCE        = 'mvweb_mc_action';
	const CAP_SETTINGS = 'manage_options';
	const CAP_DROPIN   = 'install_plugins';

	/**
	 * Хук страницы плагина.
	 *
	 * @var string
	 */
	private static string $hook_suffix = '';

	/**
	 * Подключить хуки.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function init(): void {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_init', array( __CLASS__, 'process_settings' ) );
		add_action( 'admin_init', array( __CLASS__, 'track_outage' ) );
		add_action( 'admin_notices', array( __CLASS__, 'render_notices' ) );
		add_action( 'admin_bar_menu', array( __CLASS__, 'register_admin_bar' ), 100 );

		add_action( 'wp_ajax_mvweb_mc_diagnose', array( __CLASS__, 'ajax_diagnose' ) );
		add_action( 'wp_ajax_mvweb_mc_autodetect', array( __CLASS__, 'ajax_autodetect' ) );
		add_action( 'wp_ajax_mvweb_mc_toggle', array( __CLASS__, 'ajax_toggle' ) );
		add_action( 'wp_ajax_mvweb_mc_flush', array( __CLASS__, 'ajax_flush' ) );
	}

	/**
	 * Пункт в меню MVweb Hub.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function register_menu(): void {
		if ( ! class_exists( 'MVweb_Menu' ) ) {
			return;
		}

		self::$hook_suffix = (string) add_submenu_page(
			MVweb_Menu::get_menu_slug(),
			__( 'Memcached', 'mvweb-memcached' ),
			__( 'Memcached', 'mvweb-memcached' ),
			self::CAP_SETTINGS,
			self::PAGE,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Стили и скрипты только на странице плагина.
	 *
	 * @since 1.0.0
	 *
	 * @param string $hook Текущая страница админки.
	 * @return void
	 */
	public static function enqueue_assets( $hook ): void {
		if ( self::$hook_suffix !== $hook ) {
			return;
		}

		$admin_css  = MVWEB_MC_PATH . 'admin/css/admin.min.css';
		$plugin_css = MVWEB_MC_PATH . 'admin/css/plugin.min.css';
		$admin_js   = MVWEB_MC_PATH . 'admin/js/admin.min.js';

		wp_enqueue_style(
			'mvweb-mc-admin',
			MVWEB_MC_URL . 'admin/css/admin.min.css',
			array(),
			file_exists( $admin_css ) ? (string) filemtime( $admin_css ) : MVWEB_MC_VERSION
		);

		wp_enqueue_style(
			'mvweb-mc-plugin',
			MVWEB_MC_URL . 'admin/css/plugin.min.css',
			array( 'mvweb-mc-admin' ),
			file_exists( $plugin_css ) ? (string) filemtime( $plugin_css ) : MVWEB_MC_VERSION
		);

		wp_enqueue_script(
			'mvweb-mc-admin',
			MVWEB_MC_URL . 'admin/js/admin.min.js',
			array( 'jquery' ),
			file_exists( $admin_js ) ? (string) filemtime( $admin_js ) : MVWEB_MC_VERSION,
			true
		);

		wp_localize_script(
			'mvweb-mc-admin',
			'mvwebMc',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( self::NONCE ),
				'i18n'    => array(
					'working'      => __( 'Checking…', 'mvweb-memcached' ),
					'failed'       => __( 'The request failed. Please try again.', 'mvweb-memcached' ),
					'confirmOff'   => __( 'Disable the object cache? The object-cache.php file will be deleted.', 'mvweb-memcached' ),
					'confirmFlush' => __( 'Flush the whole cache of this site?', 'mvweb-memcached' ),
				),
			)
		);
	}

	/**
	 * Сохранение формы настроек.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function process_settings(): void {
		if ( empty( $_POST['mvweb_mc_save'] ) ) {
			return;
		}

		if ( ! current_user_can( self::CAP_SETTINGS ) ) {
			wp_die( esc_html__( 'You do not have permission to change these settings.', 'mvweb-memcached' ) );
		}

		check_admin_referer( 'mvweb_mc_settings', 'mvweb_mc_nonce' );

		list( $saved, $error ) = MVweb_MC_Settings::save( wp_unslash( $_POST ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- санитайз внутри MVweb_MC_Settings::save().

		if ( ! $saved ) {
			add_settings_error( 'mvweb_mc', 'mvweb_mc_invalid', $error, 'error' );

			return;
		}

		if ( MVweb_MC_Dropin::is_ours() && current_user_can( self::CAP_DROPIN ) ) {
			MVweb_MC_Dropin::install();
		}

		add_settings_error(
			'mvweb_mc',
			'mvweb_mc_saved',
			__( 'Settings saved.', 'mvweb-memcached' ),
			'success'
		);
	}

	/**
	 * Заметить простой Memcached при включённом кеше.
	 *
	 * Пока сервер не отвечает, правки в базе не вычищают старые ключи: после
	 * восстановления связи кеш продолжил бы отдавать данные, снятые до сбоя.
	 * Отметка живёт в базе, поэтому переживает и сам простой, и перезагрузку.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function track_outage(): void {
		if ( ! MVweb_MC_Dropin::is_ours() ) {
			MVweb_MC_Settings::clear_outage();

			return;
		}

		$cache = $GLOBALS['wp_object_cache'] ?? null;

		if ( ! is_object( $cache ) || ! method_exists( $cache, 'mvweb_status' ) ) {
			return;
		}

		$status = $cache->mvweb_status();

		if ( empty( $status['connected'] ) ) {
			MVweb_MC_Settings::mark_outage();
		}
	}

	/**
	 * Уведомления о чужом и устаревшем drop-in.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function render_notices(): void {
		if ( ! current_user_can( self::CAP_SETTINGS ) ) {
			return;
		}

		$dropin = MVweb_MC_Dropin::status();

		if ( $dropin['multisite'] ) {
			printf(
				'<div class="notice notice-warning"><p>%s</p></div>',
				esc_html__( 'MVweb Memcached does not support multisite: the object cache will not be enabled.', 'mvweb-memcached' )
			);

			return;
		}

		if ( $dropin['exists'] && ! $dropin['ours'] ) {
			printf(
				'<div class="notice notice-warning"><p>%s</p></div>',
				sprintf(
					/* translators: %s: имя плагина-владельца drop-in. */
					esc_html__( 'wp-content already contains object-cache.php from "%s". MVweb Memcached leaves it untouched — remove the file manually if you want to switch.', 'mvweb-memcached' ),
					esc_html( (string) $dropin['foreign'] )
				)
			);
		}

		if ( MVweb_MC_Settings::had_outage() && MVweb_MC_Dropin::is_ours() ) {
			$cache  = $GLOBALS['wp_object_cache'] ?? null;
			$online = is_object( $cache ) && method_exists( $cache, 'mvweb_status' ) && ! empty( $cache->mvweb_status()['connected'] );

			if ( $online ) {
				printf(
					'<div class="notice notice-warning"><p>%s <a href="%s">%s</a></p></div>',
					esc_html__( 'Memcached was unavailable, so some cached data may be stale.', 'mvweb-memcached' ),
					esc_url(
						wp_nonce_url(
							add_query_arg( 'mvweb_mc_flush', '1', admin_url( 'admin.php?page=' . self::PAGE ) ),
							self::NONCE
						)
					),
					esc_html__( 'Flush cache', 'mvweb-memcached' )
				);
			}
		}

		if ( $dropin['outdated'] ) {
			printf(
				'<div class="notice notice-warning"><p>%s <a href="%s">%s</a></p></div>',
				esc_html__( 'The object-cache.php file no longer matches the current plugin settings.', 'mvweb-memcached' ),
				esc_url( admin_url( 'admin.php?page=' . self::PAGE ) ),
				esc_html__( 'Update it', 'mvweb-memcached' )
			);
		}
	}

	/**
	 * Пункт «Сбросить кеш» в верхней панели.
	 *
	 * @since 1.0.0
	 *
	 * @param WP_Admin_Bar $admin_bar Верхняя панель.
	 * @return void
	 */
	public static function register_admin_bar( $admin_bar ): void {
		if ( ! current_user_can( self::CAP_SETTINGS ) || ! MVweb_MC_Dropin::is_ours() ) {
			return;
		}

		$admin_bar->add_node(
			array(
				'id'    => 'mvweb-mc-flush',
				'title' => __( 'Flush object cache', 'mvweb-memcached' ),
				'href'  => wp_nonce_url(
					add_query_arg( 'mvweb_mc_flush', '1', admin_url( 'admin.php?page=' . self::PAGE ) ),
					self::NONCE
				),
			)
		);
	}

	/**
	 * Диагностика соединения.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function ajax_diagnose(): void {
		self::guard( self::CAP_SETTINGS );

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- nonce проверен в guard().
		$host = isset( $_POST['host'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['host'] ) ) : null;
		$port = isset( $_POST['port'] ) ? absint( $_POST['port'] ) : null;
		// phpcs:enable WordPress.Security.NonceVerification.Missing

		if ( null !== $host && ! MVweb_MC_Settings::is_valid_host( $host ) ) {
			wp_send_json_error( array( 'message' => __( 'The address must be an IP address, a host name or a path to a Unix socket.', 'mvweb-memcached' ) ) );
		}

		if ( null !== $port && ( $port < 1 || $port > 65535 ) ) {
			wp_send_json_error( array( 'message' => __( 'The port must be a number between 1 and 65535.', 'mvweb-memcached' ) ) );
		}

		wp_send_json_success(
			array(
				'diagnosis' => MVweb_MC_Connection::diagnose( $host, $port ),
				'dropin'    => MVweb_MC_Dropin::status(),
			)
		);
	}

	/**
	 * Автопоиск параметров подключения.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function ajax_autodetect(): void {
		self::guard( self::CAP_SETTINGS );

		$result = MVweb_MC_Connection::autodetect();

		if ( ! $result['found'] ) {
			wp_send_json_error(
				array(
					'message' => sprintf(
						/* translators: %s: список проверенных адресов. */
						__( 'Memcached was not found. Addresses tried: %s. Check the settings in your hosting control panel or ask support.', 'mvweb-memcached' ),
						implode( ', ', $result['tried'] )
					),
				)
			);
		}

		wp_send_json_success(
			array(
				'host'    => $result['host'],
				'port'    => $result['port'],
				'message' => sprintf(
					/* translators: %s: найденный адрес. */
					__( 'Memcached found at %s. Save the settings to apply it.', 'mvweb-memcached' ),
					MVweb_MC_Connection::format_target( $result['host'], $result['port'] )
				),
			)
		);
	}

	/**
	 * Включение и отключение drop-in.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function ajax_toggle(): void {
		self::guard( self::CAP_DROPIN );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- nonce проверен в guard().
		$enable = '1' === sanitize_text_field( wp_unslash( $_POST['enable'] ?? '' ) );

		if ( $enable ) {
			$diagnosis = MVweb_MC_Connection::diagnose();

			if ( ! $diagnosis['readwrite']['ok'] ) {
				$message = $diagnosis['connection']['ok'] ? $diagnosis['readwrite']['message'] : $diagnosis['connection']['message'];

				wp_send_json_error( array( 'message' => $message ) );
			}

			list( $ok, $message ) = MVweb_MC_Dropin::install();
		} else {
			list( $ok, $message ) = MVweb_MC_Dropin::remove();
		}

		if ( ! $ok ) {
			wp_send_json_error( array( 'message' => $message ) );
		}

		wp_send_json_success(
			array(
				'message' => $message,
				'dropin'  => MVweb_MC_Dropin::status(),
			)
		);
	}

	/**
	 * Сброс кеша своего префикса.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function ajax_flush(): void {
		self::guard( self::CAP_SETTINGS );

		if ( ! wp_cache_flush() ) {
			wp_send_json_error( array( 'message' => __( 'The cache could not be flushed.', 'mvweb-memcached' ) ) );
		}

		MVweb_MC_Settings::clear_outage();

		wp_send_json_success( array( 'message' => __( 'Cache flushed.', 'mvweb-memcached' ) ) );
	}

	/**
	 * Проверка nonce и прав для AJAX.
	 *
	 * @since 1.0.0
	 *
	 * @param string $capability Требуемое право.
	 * @return void
	 */
	private static function guard( string $capability ): void {
		check_ajax_referer( self::NONCE, 'nonce' );

		if ( ! current_user_can( $capability ) ) {
			wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'mvweb-memcached' ) ), 403 );
		}
	}

	/**
	 * Отрисовка страницы плагина.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public static function render_page(): void {
		if ( ! current_user_can( self::CAP_SETTINGS ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'mvweb-memcached' ) );
		}

		self::maybe_flush_from_admin_bar();

		require MVWEB_MC_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Сброс кеша по ссылке из верхней панели.
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	private static function maybe_flush_from_admin_bar(): void {
		if ( empty( $_GET['mvweb_mc_flush'] ) ) {
			return;
		}

		check_admin_referer( self::NONCE );

		$flushed = wp_cache_flush();

		if ( $flushed ) {
			MVweb_MC_Settings::clear_outage();
		}

		add_settings_error(
			'mvweb_mc',
			'mvweb_mc_flushed',
			$flushed ? __( 'Cache flushed.', 'mvweb-memcached' ) : __( 'The cache could not be flushed.', 'mvweb-memcached' ),
			$flushed ? 'success' : 'error'
		);
	}
}
