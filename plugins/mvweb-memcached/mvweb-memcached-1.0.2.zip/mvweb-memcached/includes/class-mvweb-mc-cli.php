<?php
/**
 * Команды WP-CLI: диагностика и управление кешем без доступа к админке.
 *
 * @package mvweb_mc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Управление кешем объектов Memcached из консоли.
 *
 * @since 1.0.0
 */
class MVweb_MC_CLI {

	/**
	 * Состояние кеша объектов.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-mc status
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function status(): void {
		$dropin    = MVweb_MC_Dropin::status();
		$diagnosis = MVweb_MC_Connection::diagnose();

		$rows = array(
			array(
				'field' => 'PHP extension',
				'value' => $diagnosis['extension']['ok']
					? MVweb_MC_Connection::extension_name() . ' ' . MVweb_MC_Connection::extension_version()
					: 'not installed',
			),
			array(
				'field' => 'Server',
				'value' => MVweb_MC_Connection::format_target( (string) MVweb_MC_Settings::get( 'host' ), (int) MVweb_MC_Settings::get( 'port' ) ),
			),
			array(
				'field' => 'Connection',
				'value' => $diagnosis['connection']['ok'] ? 'connected' : 'none',
			),
			array(
				'field' => 'Read and write',
				'value' => $diagnosis['readwrite']['ok'] ? 'working' : 'not working',
			),
			array(
				'field' => 'object-cache.php',
				'value' => $this->dropin_state( $dropin ),
			),
			array(
				'field' => 'Key prefix',
				'value' => (string) MVweb_MC_Settings::get( 'prefix' ),
			),
			array(
				'field' => 'Groups outside cache',
				'value' => implode( ', ', MVweb_MC_Settings::non_persistent_groups() ),
			),
		);

		WP_CLI\Utils\format_items( 'table', $rows, array( 'field', 'value' ) );
	}

	/**
	 * Проверка записи, чтения и удаления на сервере.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-mc test
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function test(): void {
		$diagnosis = MVweb_MC_Connection::diagnose();

		foreach ( array( 'extension', 'connection', 'readwrite' ) as $step ) {
			$message = (string) $diagnosis[ $step ]['message'];

			if ( $diagnosis[ $step ]['ok'] ) {
				WP_CLI::log( '✔ ' . $message );
			} else {
				WP_CLI::error( $message );
			}
		}

		if ( is_array( $diagnosis['shared'] ) && $diagnosis['shared']['shared'] ) {
			WP_CLI::warning(
				sprintf(
					'The server holds data of other sites (%d keys). Our keys are isolated by the prefix %s.',
					(int) $diagnosis['shared']['items'],
					(string) $diagnosis['shared']['prefix']
				)
			);
		}

		WP_CLI::success( 'Memcached works correctly.' );
	}

	/**
	 * Включить постоянный кеш объектов.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-mc enable
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function enable(): void {
		$diagnosis = MVweb_MC_Connection::diagnose();

		if ( ! $diagnosis['readwrite']['ok'] ) {
			WP_CLI::error( 'Memcached is unavailable, cache not enabled: ' . (string) ( $diagnosis['connection']['ok'] ? $diagnosis['readwrite']['message'] : $diagnosis['connection']['message'] ) );
		}

		list( $ok, $message ) = MVweb_MC_Dropin::install();

		if ( ! $ok ) {
			WP_CLI::error( $message );
		}

		// Отметка простоя означает, что данные в кеше могли остаться устаревшими:
		// файл записан, но сервер не принял новое поколение ключей.
		if ( MVweb_MC_Settings::had_outage() ) {
			WP_CLI::warning( $message );

			return;
		}

		WP_CLI::success( $message );
	}

	/**
	 * Отключить постоянный кеш объектов.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-mc disable
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function disable(): void {
		list( $ok, $message ) = MVweb_MC_Dropin::remove();

		if ( ! $ok ) {
			WP_CLI::error( $message );
		}

		WP_CLI::success( $message );
	}

	/**
	 * Сбросить кеш своего префикса.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-mc flush
	 *
	 * @since 1.0.0
	 *
	 * @return void
	 */
	public function flush(): void {
		if ( ! wp_cache_flush() ) {
			WP_CLI::error( 'The cache could not be flushed.' );
		}

		MVweb_MC_Settings::clear_outage();

		WP_CLI::success( 'Cache flushed.' );
	}

	/**
	 * Состояние drop-in одной строкой.
	 *
	 * @since 1.0.0
	 *
	 * @param array<string, mixed> $dropin Сводка состояния.
	 * @return string
	 */
	private function dropin_state( array $dropin ): string {
		if ( ! $dropin['exists'] ) {
			return 'not present';
		}

		if ( ! $dropin['ours'] ) {
			return 'third-party (' . (string) $dropin['foreign'] . ')';
		}

		if ( ! $dropin['outdated'] ) {
			return 'ours, version ' . (string) $dropin['installed_version'];
		}

		if ( $dropin['version_outdated'] ) {
			return 'ours, outdated (' . (string) $dropin['installed_version'] . ' → ' . (string) $dropin['template_version'] . ')';
		}

		return 'ours, version ' . (string) $dropin['installed_version'] . ' (non-persistent groups changed, needs update)';
	}
}
