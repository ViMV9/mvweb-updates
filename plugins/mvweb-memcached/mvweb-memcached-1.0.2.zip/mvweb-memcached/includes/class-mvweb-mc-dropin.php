<?php
/**
 * Управление файлом wp-content/object-cache.php.
 *
 * @package mvweb_mc
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Установка, обновление и удаление drop-in кеша объектов.
 *
 * @since 1.0.0
 */
class MVweb_MC_Dropin {

	const SIGNATURE   = 'Drop-in Name: MVweb Memcached';
	const CONFIG_HEAD = '// ═══ MVWEB CONFIG START ═══';
	const CONFIG_TAIL = '// ═══ MVWEB CONFIG END ═══';

	/**
	 * Известные чужие drop-in — по строкам внутри файла.
	 *
	 * @var array<string, string>
	 */
	const FOREIGN = array(
		'W3 Total Cache'         => 'W3 Total Cache',
		'Redis Object Cache'     => 'Redis Object Cache',
		'LiteSpeed Cache'        => 'LiteSpeed',
		'WP Super Cache'         => 'WP Super Cache',
		'Memcached Object Cache' => 'Memcached Object Cache',
		'Docket Cache'           => 'Docket Cache',
		'Object Cache Pro'       => 'Object Cache Pro',
	);

	/**
	 * Путь к установленному drop-in.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function path(): string {
		return WP_CONTENT_DIR . '/object-cache.php';
	}

	/**
	 * Путь к шаблону drop-in внутри плагина.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function template_path(): string {
		return MVWEB_MC_PATH . 'dropin/object-cache.php';
	}

	/**
	 * Есть ли какой-либо drop-in кеша объектов.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public static function exists(): bool {
		return file_exists( self::path() );
	}

	/**
	 * Наш ли установленный drop-in.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public static function is_ours(): bool {
		if ( ! self::exists() ) {
			return false;
		}

		$head = self::read_head();

		return false !== strpos( $head, self::SIGNATURE );
	}

	/**
	 * Имя чужого плагина, которому принадлежит drop-in.
	 *
	 * @since 1.0.0
	 *
	 * @return string Пустая строка, если drop-in наш или отсутствует.
	 */
	public static function foreign_owner(): string {
		if ( ! self::exists() || self::is_ours() ) {
			return '';
		}

		$head = self::read_head();

		foreach ( self::FOREIGN as $name => $needle ) {
			if ( false !== stripos( $head, $needle ) ) {
				return $name;
			}
		}

		return __( 'an unknown plugin', 'mvweb-memcached' );
	}

	/**
	 * Версия установленного нашего drop-in.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function installed_version(): string {
		if ( ! self::is_ours() ) {
			return '';
		}

		if ( preg_match( '~Drop-in Version:\s*([0-9.]+)~', self::read_head(), $matches ) ) {
			return $matches[1];
		}

		return '';
	}

	/**
	 * Версия drop-in в текущей сборке плагина.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	public static function template_version(): string {
		$template = self::template_path();

		if ( ! file_exists( $template ) ) {
			return '';
		}

		$head = (string) file_get_contents( $template ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- чтение файла плагина.

		if ( preg_match( '~Drop-in Version:\s*([0-9.]+)~', substr( $head, 0, 2048 ), $matches ) ) {
			return $matches[1];
		}

		return '';
	}

	/**
	 * Устарел ли установленный drop-in: новая версия шаблона или разъехавшийся конфиг.
	 *
	 * @since 1.0.0
	 *
	 * @return bool
	 */
	public static function is_outdated(): bool {
		return self::version_outdated() || self::groups_drifted();
	}

	/**
	 * Отстал ли установленный файл по версии от шаблона плагина.
	 *
	 * @since 1.0.2
	 *
	 * @return bool
	 */
	private static function version_outdated(): bool {
		if ( ! self::is_ours() ) {
			return false;
		}

		$installed = self::installed_version();
		$template  = self::template_version();

		if ( '' === $installed || '' === $template ) {
			return false;
		}

		return version_compare( $installed, $template, '<' );
	}

	/**
	 * Разошёлся ли список non-persistent групп в файле с текущим.
	 *
	 * Группы впечатываются в drop-in один раз при установке. Если WooCommerce
	 * активировали позже, её группы остались бы постоянными, и вызов
	 * wp_cache_flush_group( 'coupons' ) сбрасывал бы кеш всего сайта.
	 *
	 * @since 1.0.2
	 *
	 * @return bool
	 */
	private static function groups_drifted(): bool {
		if ( ! self::is_ours() ) {
			return false;
		}

		$config = $GLOBALS['mvweb_mc_config'] ?? null;

		if ( ! is_array( $config ) || ! isset( $config['non_persistent'] ) || ! is_array( $config['non_persistent'] ) ) {
			return false;
		}

		$installed = $config['non_persistent'];
		$current   = MVweb_MC_Settings::non_persistent_groups();

		sort( $installed );
		sort( $current );

		return $installed !== $current;
	}

	/**
	 * Сменился ли сервер или префикс относительно впечатанных в файл.
	 *
	 * Ключи прежнего адреса никуда не делись: пока сайт писал на другой сервер,
	 * правки в базе их не вычищали, и возврат к нему поднял бы устаревшие данные.
	 * Значения, запертые константой wp-config, сравнивать не с чем — они и были,
	 * и остаются одинаковыми, что бы ни лежало в файле.
	 *
	 * @since 1.0.2
	 *
	 * @return bool
	 */
	private static function target_changed(): bool {
		$config = $GLOBALS['mvweb_mc_config'] ?? null;

		if ( ! is_array( $config ) ) {
			return false;
		}

		foreach ( array( 'host', 'port', 'prefix' ) as $key ) {
			if ( MVweb_MC_Settings::is_locked( $key ) ) {
				continue;
			}

			if ( ! isset( $config[ $key ] ) ) {
				continue;
			}

			if ( (string) MVweb_MC_Settings::get( $key ) !== (string) $config[ $key ] ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Установить или обновить drop-in с текущими настройками.
	 *
	 * @since 1.0.0
	 *
	 * @return array{0: bool, 1: string}
	 */
	public static function install(): array {
		if ( is_multisite() ) {
			return array( false, __( 'The plugin does not support multisite. The object cache was not installed.', 'mvweb-memcached' ) );
		}

		$was_ours = self::is_ours();

		if ( self::exists() && ! $was_ours ) {
			return array(
				false,
				sprintf(
					/* translators: %s: имя плагина-владельца файла. */
					__( 'wp-content already contains object-cache.php from "%s". Remove it manually, otherwise the cache may break.', 'mvweb-memcached' ),
					self::foreign_owner()
				),
			);
		}

		$template = self::template_path();

		if ( ! file_exists( $template ) ) {
			return array( false, __( 'The drop-in template is missing from the plugin. Reinstall the plugin.', 'mvweb-memcached' ) );
		}

		$filesystem = self::filesystem();

		if ( null === $filesystem ) {
			return array( false, __( 'No filesystem access. Set the access credentials in wp-config.php or ask your hosting support.', 'mvweb-memcached' ) );
		}

		if ( ! $filesystem->is_writable( WP_CONTENT_DIR ) ) {
			return array( false, __( 'The wp-content directory is not writable. Allow writing or ask your hosting support.', 'mvweb-memcached' ) );
		}

		$contents = $filesystem->get_contents( $template );

		if ( ! is_string( $contents ) || '' === $contents ) {
			return array( false, __( 'Could not read the drop-in template.', 'mvweb-memcached' ) );
		}

		$config   = self::build_config();
		$contents = self::inject_config( $contents, $config );
		$temp     = WP_CONTENT_DIR . '/object-cache.php.mvweb-tmp';

		if ( ! $filesystem->put_contents( $temp, $contents, FS_CHMOD_FILE ) ) {
			return array( false, __( 'Could not write the cache file to wp-content.', 'mvweb-memcached' ) );
		}

		if ( ! $filesystem->move( $temp, self::path(), true ) ) {
			$filesystem->delete( $temp );

			return array( false, __( 'Could not replace object-cache.php. Check the file permissions.', 'mvweb-memcached' ) );
		}

		// Файл на диске переписан, а $GLOBALS хранит конфигурацию, прочитанную при
		// старте запроса. Без синхронизации groups_drifted() до конца запроса
		// сравнивал бы свежие настройки с прежним файлом и объявлял его устаревшим
		// сразу после успешного обновления.
		$stale_target               = self::target_changed();
		$GLOBALS['mvweb_mc_config'] = $config;

		// Пока кеш писался мимо этого сервера — был выключен или смотрел на другой
		// адрес — правки в базе не вычищали прежние ключи, и они снова стали бы
		// видимыми. Такой переход начинает новое поколение. Если же файл был наш и
		// адрес не менялся, данные актуальны: смена поколения только выбросила бы
		// рабочий кеш и оставила прошлые ключи мусором до истечения их срока.
		if ( ( ! $was_ours || $stale_target ) && ! MVweb_MC_Connection::start_new_generation() ) {
			MVweb_MC_Settings::mark_outage();

			return array(
				true,
				__( 'Object cache enabled, but the server did not accept a new key generation: the site may show data cached before the cache was switched off. Flush the cache once the server responds.', 'mvweb-memcached' ),
			);
		}

		return array( true, __( 'Object cache enabled.', 'mvweb-memcached' ) );
	}

	/**
	 * Удалить наш drop-in. Чужой файл не трогаем.
	 *
	 * @since 1.0.0
	 *
	 * @return array{0: bool, 1: string}
	 */
	public static function remove(): array {
		if ( ! self::exists() ) {
			return array( true, __( 'Object cache is already disabled.', 'mvweb-memcached' ) );
		}

		if ( ! self::is_ours() ) {
			return array( false, __( 'wp-content contains a third-party object-cache.php, which the plugin leaves untouched.', 'mvweb-memcached' ) );
		}

		$filesystem = self::filesystem();

		if ( null === $filesystem ) {
			return array( false, __( 'No filesystem access to remove the cache file.', 'mvweb-memcached' ) );
		}

		if ( ! $filesystem->delete( self::path() ) ) {
			return array( false, __( 'Could not delete object-cache.php. Check the file permissions.', 'mvweb-memcached' ) );
		}

		return array( true, __( 'Object cache disabled.', 'mvweb-memcached' ) );
	}

	/**
	 * Конфигурация для впечатывания в drop-in.
	 *
	 * @since 1.0.2
	 *
	 * @return array<string, mixed>
	 */
	private static function build_config(): array {
		MVweb_MC_Settings::refresh();

		return array(
			'host'           => (string) MVweb_MC_Settings::get( 'host' ),
			'port'           => (int) MVweb_MC_Settings::get( 'port' ),
			'sasl_user'      => (string) MVweb_MC_Settings::get( 'sasl_user' ),
			'sasl_pass'      => (string) MVweb_MC_Settings::get( 'sasl_pass' ),
			'prefix'         => (string) MVweb_MC_Settings::get( 'prefix' ),
			'timeout'        => 1000,
			'op_timeout'     => 500,
			'non_persistent' => MVweb_MC_Settings::non_persistent_groups(),
		);
	}

	/**
	 * Подставить настройки в блок конфигурации шаблона.
	 *
	 * @since 1.0.0
	 * @since 1.0.2 Конфигурация приходит аргументом.
	 *
	 * @param string               $contents Содержимое шаблона.
	 * @param array<string, mixed> $config   Значения для впечатывания.
	 * @return string
	 */
	private static function inject_config( string $contents, array $config ): string {
		$block = self::CONFIG_HEAD . "\n"
			. '$GLOBALS[\'mvweb_mc_config\'] = ' . var_export( $config, true ) . ";\n" // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_var_export -- генерация конфигурационного литерала drop-in.
			. self::CONFIG_TAIL;

		$pattern = '~' . preg_quote( self::CONFIG_HEAD, '~' ) . '.*?' . preg_quote( self::CONFIG_TAIL, '~' ) . '~s';

		return (string) preg_replace_callback(
			$pattern,
			static function () use ( $block ) {
				return $block;
			},
			$contents,
			1
		);
	}

	/**
	 * Первые килобайты установленного файла — для проверки сигнатуры.
	 *
	 * @since 1.0.0
	 *
	 * @return string
	 */
	private static function read_head(): string {
		$handle = @fopen( self::path(), 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.PHP.NoSilencedErrors.Discouraged -- быстрое чтение шапки без загрузки файла целиком.

		if ( false === $handle ) {
			return '';
		}

		$head = (string) fread( $handle, 2048 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread
		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		return $head;
	}

	/**
	 * Инициализированный WP_Filesystem или null.
	 *
	 * @since 1.0.0
	 *
	 * @return WP_Filesystem_Base|null
	 */
	private static function filesystem(): ?WP_Filesystem_Base {
		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		if ( ! WP_Filesystem() ) {
			return null;
		}

		return $wp_filesystem instanceof WP_Filesystem_Base ? $wp_filesystem : null;
	}

	/**
	 * Сводка состояния для интерфейса, Site Health и WP-CLI.
	 *
	 * @since 1.0.0
	 *
	 * @return array<string, mixed>
	 */
	public static function status(): array {
		return array(
			'exists'            => self::exists(),
			'ours'              => self::is_ours(),
			'foreign'           => self::foreign_owner(),
			'installed_version' => self::installed_version(),
			'template_version'  => self::template_version(),
			'outdated'          => self::is_outdated(),
			'version_outdated'  => self::version_outdated(),
			'multisite'         => is_multisite(),
		);
	}
}
