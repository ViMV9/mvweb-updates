<?php
/**
 * Uninstall MVweb Gallery Wall
 *
 * Fired when the plugin is uninstalled.
 * Removes all gallery posts and plugin settings.
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// Batch-delete all posts of type `mvweb_gallery` (100 at a time).
$batch_size = 100;

do {
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	$post_ids = $wpdb->get_col(
		$wpdb->prepare(
			"SELECT ID FROM {$wpdb->posts} WHERE post_type = %s LIMIT %d",
			'mvweb_gallery',
			$batch_size
		)
	);

	if ( empty( $post_ids ) ) {
		break;
	}

	foreach ( $post_ids as $post_id ) {
		wp_delete_post( (int) $post_id, true );
	}
} while ( count( $post_ids ) === $batch_size );

// Delete plugin option.
delete_option( 'mvweb_gw_settings' );

// For multisite, delete options from all sites.
if ( is_multisite() ) {
	$sites = get_sites();
	foreach ( $sites as $site ) {
		switch_to_blog( $site->blog_id );

		// Batch-delete gallery posts on each site.
		do {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$post_ids = $wpdb->get_col(
				$wpdb->prepare(
					"SELECT ID FROM {$wpdb->posts} WHERE post_type = %s LIMIT %d",
					'mvweb_gallery',
					$batch_size
				)
			);

			if ( empty( $post_ids ) ) {
				break;
			}

			foreach ( $post_ids as $post_id ) {
				wp_delete_post( (int) $post_id, true );
			}
		} while ( count( $post_ids ) === $batch_size );

		delete_option( 'mvweb_gw_settings' );
		restore_current_blog();
	}
}

// Clear any cached data.
wp_cache_flush();
