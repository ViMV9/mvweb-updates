# MVweb Gallery Wall

Customizable photo gallery with grid, masonry, justified, ticker layouts and built-in lightbox.

## Description

MVweb Gallery Wall is a WordPress plugin for creating beautiful photo galleries (photo walls) with multiple display modes, animations, tag filtering, and a built-in lightbox. Supports output via shortcode and widget.

## Requirements

- WordPress 6.4 or higher
- PHP 8.0 or higher

## Installation

1. Upload the `mvweb-gallery-wall` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **MVweb Hub > Gallery Wall** to create your first gallery

## Usage

1. Create a gallery collection in the admin panel
2. Add photos from the Media Library
3. Configure layout, animations, and settings
4. Copy the shortcode and paste it into any page or post

### Shortcode

```
[mvweb_gallery id="5"]
[mvweb_gallery id="5" layout="grid" columns="3" gap="20"]
[mvweb_gallery id="12" layout="ticker" speed="25"]
```

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for the full changelog.

## License

This plugin is licensed under the GPL v2 or later.

## Credits

Developed by [MVweb](https://mvweb.ru)
