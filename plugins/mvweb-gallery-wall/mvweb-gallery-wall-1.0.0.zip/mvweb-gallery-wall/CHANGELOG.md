# Changelog

All notable changes to MVweb Gallery Wall will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-06-04

### Added
- Initial release
- Custom Post Type for gallery collections
- 4 layout modes: Grid, Masonry, Justified, Ticker
- Ticker: photo aspect ratio presets (16:9, 4:3, 3:2, 1:1, 3:4, 9:16) with a custom option
- Ticker: photo fit control (cover / contain / fill) so photos can be shown whole instead of cropped
- Ticker: optional center zoom — each photo smoothly scales up (110/115/120%) as it crosses the strip center, with reserved spacing so enlarged photos never overlap neighbours
- Built-in lightbox with keyboard navigation and swipe
- Entrance animations and hover effects
- Tag-based photo filtering
- Appearance settings for the plugin controls: a single shared style for filter chips and the "Load More" button — background, text and border colors for normal and active states, plus border radius and width (hover styles derived from the active colors automatically)
- Material color scheme presets (8 schemes: Teal, Indigo, Blue, Green, Amber, Deep Orange, Pink, Blue Grey) shown as color swatches — one click fills the controls style fields, ready to fine-tune before saving. Default style is Material Teal — no rounding, soft pastel palette
- Lazy loading toggle (on by default): photos load as they scroll into view, while the first row always loads immediately for a fast first paint
- "Load More" pagination: all photos are rendered up front and revealed in batches via CSS (no extra requests), so the lightbox can always browse the full gallery — not just the first page. Filtering by a tag reveals every matching photo regardless of the per-page limit
- Classic Widget support
- Live preview in admin editor
- Shortcode with full parameter support
- Localization: English + Russian (ru_RU)
- Admin menu integration with MVweb Hub
- GitHub updater support

### Security
- Nonce verification for all forms
- Capability checks for admin pages
- Input sanitization and output escaping
- XSS protection via textContent in lightbox

### Fixed
- Cyrillic and other non-ASCII characters in photo titles, captions and tags were corrupted on save (escaped `\uXXXX` lost its backslash via `update_post_meta` unslashing). Photo meta is now stored with `JSON_UNESCAPED_UNICODE`.
- Grid layout: when the photo proportions did not match the tile (e.g. wide photos in square tiles) and Object Fit was "contain" / "scale-down", the photo was letterboxed inside the tile, leaving empty space — the caption overlay then floated in that void below the visible photo and rows looked unevenly spaced. Grid images now always use `object-fit: cover` so they fill the tile; the overlay sits on the photo's bottom edge and vertical gaps match horizontal ones. Grid tiles also keep a fixed aspect ratio (falling back to 4/3 for "Auto") so rows stay even.
- Masonry layout: the caption overlay spilling below the photo, and the vertical gap between rows not matching the horizontal gap between columns. Each tile's height is now pinned to its computed image height, so the overlay anchors to the photo's bottom edge and the gaps are identical in both directions.
- Lightbox opened a tiny thumbnail instead of the full-size image for photos whose `srcset` was not sorted by width (WordPress does not guarantee ordering). The lightbox now selects the candidate with the largest width descriptor, so every photo opens at full resolution.
