<?php
/**
 * Plugin settings: defaults, get, save, sanitization.
 *
 * All settings stored in a single wp_option: mvweb_gw_settings (autoload=no).
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

class MVweb_GW_Settings {

	/**
	 * Option name in wp_options table.
	 */
	const OPTION_NAME = 'mvweb_gw_settings';

	/**
	 * Nonce action.
	 */
	const NONCE_ACTION = 'mvweb_gw_settings_save';

	/**
	 * Nonce field name.
	 */
	const NONCE_NAME = 'mvweb_gw_settings_nonce';

	/**
	 * Get plugin settings merged with defaults.
	 *
	 * @since 1.0.0
	 * @return array Full settings array with all keys guaranteed.
	 */
	public static function get(): array {
		$saved    = get_option( self::OPTION_NAME, array() );
		$defaults = mvweb_gw_get_defaults();

		return wp_parse_args( is_array( $saved ) ? $saved : array(), $defaults );
	}

	/**
	 * Save settings from POST data.
	 *
	 * Verifies nonce and capabilities, sanitizes input, saves to wp_options.
	 *
	 * @since 1.0.0
	 * @return bool True if saved, false otherwise.
	 */
	public static function handle_save(): bool {
		if ( ! isset( $_POST['mvweb_gw_save_settings'] ) ) {
			return false;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions.', 'mvweb-gallery-wall' ) );
		}

		if ( ! isset( $_POST[ self::NONCE_NAME ] ) ||
			 ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE_NAME ] ) ), self::NONCE_ACTION ) ) {
			wp_die( esc_html__( 'Security check failed.', 'mvweb-gallery-wall' ) );
		}

		$settings = self::sanitize_from_post( $_POST );
		$saved    = update_option( self::OPTION_NAME, $settings, 'no' );

		if ( $saved ) {
			add_settings_error(
				'mvweb_gw_messages',
				'mvweb_gw_saved',
				__( 'Settings saved.', 'mvweb-gallery-wall' ),
				'updated'
			);
		}

		return $saved;
	}

	/**
	 * Sanitize settings from POST data.
	 *
	 * @since 1.0.0
	 * @param array $post Raw POST data.
	 * @return array Sanitized settings array.
	 */
	private static function sanitize_from_post( array $post ): array {
		$defaults = mvweb_gw_get_defaults();

		// Layout.
		$valid_layouts = array( 'grid', 'masonry', 'justified', 'ticker' );
		$layout        = isset( $post['default_layout'] ) ? sanitize_text_field( $post['default_layout'] ) : $defaults['default_layout'];

		// Columns (clamped).
		$columns_desktop = isset( $post['default_columns_desktop'] ) ? absint( $post['default_columns_desktop'] ) : $defaults['default_columns_desktop'];
		$columns_tablet  = isset( $post['default_columns_tablet'] ) ? absint( $post['default_columns_tablet'] ) : $defaults['default_columns_tablet'];
		$columns_mobile  = isset( $post['default_columns_mobile'] ) ? absint( $post['default_columns_mobile'] ) : $defaults['default_columns_mobile'];

		// Aspect ratio.
		$valid_ratios = array( '1:1', '4:3', '16:9', '3:2', 'auto' );
		$aspect_ratio = isset( $post['default_aspect_ratio'] ) ? sanitize_text_field( $post['default_aspect_ratio'] ) : $defaults['default_aspect_ratio'];

		// Object fit.
		$valid_fits = array( 'cover', 'contain', 'fill', 'none', 'scale-down' );
		$object_fit = isset( $post['default_object_fit'] ) ? sanitize_text_field( $post['default_object_fit'] ) : $defaults['default_object_fit'];

		// Animation.
		$valid_animations = array( 'fade', 'slide-up', 'slide-left', 'scale', 'flip', 'none' );
		$animation        = isset( $post['default_animation'] ) ? sanitize_text_field( $post['default_animation'] ) : $defaults['default_animation'];

		// Hover.
		$valid_hovers = array( 'zoom', 'grayscale', 'brightness', 'overlay', 'none' );
		$hover        = isset( $post['default_hover'] ) ? sanitize_text_field( $post['default_hover'] ) : $defaults['default_hover'];

		// Ticker direction.
		$valid_directions = array( 'left', 'right', 'up', 'down' );
		$ticker_direction = isset( $post['default_ticker_direction'] ) ? sanitize_text_field( $post['default_ticker_direction'] ) : $defaults['default_ticker_direction'];

		// Overlay mode.
		$valid_overlays = array( 'hover', 'always', 'none' );
		$overlay_mode   = isset( $post['default_overlay_mode'] ) ? sanitize_text_field( $post['default_overlay_mode'] ) : $defaults['default_overlay_mode'];

		// Link target.
		$valid_targets = array( '_blank', '_self' );
		$link_target   = isset( $post['default_link_target'] ) ? sanitize_text_field( $post['default_link_target'] ) : $defaults['default_link_target'];

		// Appearance colors (hex), with fallback to defaults when empty/invalid.
		$color = static function ( $key ) use ( $post, $defaults ) {
			$raw = isset( $post[ $key ] ) ? sanitize_hex_color( $post[ $key ] ) : '';
			return $raw ? $raw : $defaults[ $key ];
		};

		return array(
			'default_layout'           => in_array( $layout, $valid_layouts, true ) ? $layout : $defaults['default_layout'],
			'default_columns_desktop'  => min( max( $columns_desktop, 1 ), 8 ),
			'default_columns_tablet'   => min( max( $columns_tablet, 1 ), 6 ),
			'default_columns_mobile'   => min( max( $columns_mobile, 1 ), 4 ),
			'default_gap'              => isset( $post['default_gap'] ) ? absint( $post['default_gap'] ) : $defaults['default_gap'],
			'default_radius'           => isset( $post['default_radius'] ) ? absint( $post['default_radius'] ) : $defaults['default_radius'],
			'default_aspect_ratio'     => in_array( $aspect_ratio, $valid_ratios, true ) ? $aspect_ratio : $defaults['default_aspect_ratio'],
			'default_object_fit'       => in_array( $object_fit, $valid_fits, true ) ? $object_fit : $defaults['default_object_fit'],
			'default_max_width'        => isset( $post['default_max_width'] ) ? sanitize_text_field( $post['default_max_width'] ) : $defaults['default_max_width'],
			'default_animation'        => in_array( $animation, $valid_animations, true ) ? $animation : $defaults['default_animation'],
			'default_hover'            => in_array( $hover, $valid_hovers, true ) ? $hover : $defaults['default_hover'],
			'default_lightbox'         => ! empty( $post['default_lightbox'] ),
			'default_lazyload'         => ! empty( $post['default_lazyload'] ),
			'default_row_height'       => isset( $post['default_row_height'] ) ? min( max( absint( $post['default_row_height'] ), 120 ), 400 ) : $defaults['default_row_height'],
			'default_ticker_speed'     => isset( $post['default_ticker_speed'] ) ? max( absint( $post['default_ticker_speed'] ), 1 ) : $defaults['default_ticker_speed'],
			'default_ticker_direction' => in_array( $ticker_direction, $valid_directions, true ) ? $ticker_direction : $defaults['default_ticker_direction'],
			'default_ticker_pause'     => ! empty( $post['default_ticker_pause'] ),
			'default_ticker_width'     => isset( $post['default_ticker_width'] ) ? max( absint( $post['default_ticker_width'] ), 50 ) : $defaults['default_ticker_width'],
			'default_ticker_ratio'     => isset( $post['default_ticker_ratio'] ) ? sanitize_text_field( $post['default_ticker_ratio'] ) : $defaults['default_ticker_ratio'],
			'default_per_page'         => isset( $post['default_per_page'] ) ? absint( $post['default_per_page'] ) : $defaults['default_per_page'],
			'default_load_more_text'   => isset( $post['default_load_more_text'] ) ? sanitize_text_field( $post['default_load_more_text'] ) : $defaults['default_load_more_text'],
			'default_link_target'      => in_array( $link_target, $valid_targets, true ) ? $link_target : $defaults['default_link_target'],
			'default_overlay_mode'     => in_array( $overlay_mode, $valid_overlays, true ) ? $overlay_mode : $defaults['default_overlay_mode'],
			'default_show_title'       => ! empty( $post['default_show_title'] ),

			// UI controls appearance (shared by filter chips and the Load More button).
			'ui_bg'                    => $color( 'ui_bg' ),
			'ui_text'                  => $color( 'ui_text' ),
			'ui_border'                => $color( 'ui_border' ),
			'ui_active_bg'             => $color( 'ui_active_bg' ),
			'ui_active_text'           => $color( 'ui_active_text' ),
			'ui_active_border'         => $color( 'ui_active_border' ),
			'ui_radius'                => isset( $post['ui_radius'] ) ? min( max( absint( $post['ui_radius'] ), 0 ), 100 ) : $defaults['ui_radius'],
			'ui_border_width'          => isset( $post['ui_border_width'] ) ? min( max( absint( $post['ui_border_width'] ), 0 ), 10 ) : $defaults['ui_border_width'],
		);
	}
}
