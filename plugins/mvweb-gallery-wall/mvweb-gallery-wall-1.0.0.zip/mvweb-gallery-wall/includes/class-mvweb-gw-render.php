<?php
/**
 * Frontend rendering for MVweb Gallery Wall.
 *
 * Renders gallery collections on the frontend using CSS Grid.
 * Other layouts (masonry, justified, ticker) will be added in Phase 5.
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Render a gallery collection.
 *
 * Loads collection data, merges settings with shortcode attributes,
 * and outputs HTML with CSS Grid layout.
 *
 * @since 1.0.0
 * @param array $atts Shortcode/widget attributes (merged with collection meta and global defaults).
 * @return string Gallery HTML or empty string on failure.
 */
function mvweb_gw_render( array $atts = array() ): string {

	// ID is required.
	$gallery_id = isset( $atts['id'] ) ? absint( $atts['id'] ) : 0;
	if ( 0 === $gallery_id ) {
		return '';
	}

	// Load post.
	$post = get_post( $gallery_id );
	if ( ! $post || 'mvweb_gallery' !== $post->post_type || 'publish' !== $post->post_status ) {
		return '';
	}

	// Load collection meta.
	$meta = mvweb_gw_get_collection_meta( $gallery_id );

	// Global defaults.
	$defaults = MVweb_GW_Settings::get();

	// Merge: shortcode atts → collection meta → global defaults.
	$settings = mvweb_gw_merge_settings( $atts, $meta, $defaults );

	// Load photos.
	$photos_json = get_post_meta( $gallery_id, '_mvweb_gw_photos', true );
	$photos      = json_decode( $photos_json, true );
	if ( ! is_array( $photos ) || empty( $photos ) ) {
		return '';
	}

	// Order.
	if ( 'random' === $settings['order'] ) {
		shuffle( $photos );
	} else {
		usort( $photos, function ( $a, $b ) {
			return ( $a['order'] ?? 0 ) - ( $b['order'] ?? 0 );
		} );
	}

	// Hard limit from shortcode actually trims the set (photos beyond it are not output).
	$limit = isset( $atts['limit'] ) ? absint( $atts['limit'] ) : 0;
	if ( $limit > 0 ) {
		$photos = array_slice( $photos, 0, $limit );
	}

	// Per-page limit (0 = show all). All photos are rendered into the DOM so the
	// lightbox can browse the full gallery; photos beyond per_page are hidden via
	// CSS and revealed by the "Load More" button — no AJAX, no extra requests.
	$per_page    = absint( $settings['per_page'] );
	$total       = count( $photos );
	$show_photos = $photos;
	$visible     = ( $per_page > 0 && $per_page < $total ) ? $per_page : $total;
	$has_more    = $visible < $total;

	// Enqueue assets.
	mvweb_gw_enqueue_frontend_assets();

	// Enqueue lightbox markup if enabled.
	if ( $settings['lightbox'] ) {
		MVweb_GW_Lightbox::enqueue();
	}

	// Build output.
	$layout = $settings['layout'];

	// Ticker has completely different markup.
	if ( 'ticker' === $layout ) {
		return mvweb_gw_render_ticker( $gallery_id, $settings, $show_photos, $post );
	}

	$html = mvweb_gw_render_container_open( $gallery_id, $settings, $total );

	// Title.
	if ( $settings['show_title'] ) {
		$html .= '<h3 class="mvweb-gw__title">' . esc_html( $post->post_title ) . '</h3>';
	}

	// Filter bar (tags) — not for ticker.
	$html .= mvweb_gw_render_filter_bar( $photos );

	// Grid/masonry/justified items.
	$grid_attrs = 'role="list"';

	// Justified: add data-row-height.
	if ( 'justified' === $layout ) {
		$grid_attrs .= sprintf( ' data-row-height="%d"', absint( $settings['row_height'] ) );
	}

	$html .= '<div class="mvweb-gw__grid" ' . $grid_attrs . '>';

	$columns   = absint( $settings['columns_desktop'] );
	$first_row = max( $columns, 1 );

	foreach ( $show_photos as $index => $photo ) {
		$beyond = ( $index >= $visible );
		$html  .= mvweb_gw_render_item( $photo, $index, $settings, $first_row, $beyond );
	}

	$html .= '</div>';

	// Load more button.
	if ( $has_more ) {
		$html .= mvweb_gw_render_load_more( $settings );
	}

	$html .= '</div>';

	return $html;
}

/**
 * Get collection meta values.
 *
 * @since 1.0.0
 * @param int $post_id Collection post ID.
 * @return array Associative array of meta values.
 */
function mvweb_gw_get_collection_meta( int $post_id ): array {
	$keys = MVweb_GW_Editor::get_meta_keys();
	$meta = array();

	foreach ( $keys as $key ) {
		// Strip prefix for cleaner access.
		$clean_key          = str_replace( '_mvweb_gw_', '', $key );
		$meta[ $clean_key ] = get_post_meta( $post_id, $key, true );
	}

	return $meta;
}

/**
 * Merge shortcode atts → collection meta → global defaults.
 *
 * Priority: shortcode > collection meta > global defaults.
 *
 * @since 1.0.0
 * @param array $atts     Shortcode attributes.
 * @param array $meta     Collection meta values.
 * @param array $defaults Global default settings.
 * @return array Merged settings.
 */
function mvweb_gw_merge_settings( array $atts, array $meta, array $defaults ): array {

	// Map of setting key → [meta_key, default_key].
	$map = array(
		'layout'           => array( 'layout', 'default_layout' ),
		'columns_desktop'  => array( 'columns_desktop', 'default_columns_desktop' ),
		'columns_tablet'   => array( 'columns_tablet', 'default_columns_tablet' ),
		'columns_mobile'   => array( 'columns_mobile', 'default_columns_mobile' ),
		'gap'              => array( 'gap', 'default_gap' ),
		'radius'           => array( 'radius', 'default_radius' ),
		'aspect_ratio'     => array( 'aspect_ratio', 'default_aspect_ratio' ),
		'aspect_custom'    => array( 'aspect_custom', '' ),
		'object_fit'       => array( 'object_fit', 'default_object_fit' ),
		'max_width'        => array( 'max_width', 'default_max_width' ),
		'row_height'       => array( 'row_height', 'default_row_height' ),
		'animation'        => array( 'animation', 'default_animation' ),
		'hover'            => array( 'hover', 'default_hover' ),
		'lightbox'         => array( 'lightbox', 'default_lightbox' ),
		'lazyload'         => array( 'lazyload', 'default_lazyload' ),
		'show_title'       => array( 'show_title', 'default_show_title' ),
		'overlay_mode'     => array( 'overlay_mode', 'default_overlay_mode' ),
		'link_target'      => array( 'link_target', 'default_link_target' ),
		'order'            => array( 'order', 'manual' ),
		'per_page'         => array( 'per_page', 'default_per_page' ),
		'load_more_text'   => array( 'load_more_text', 'default_load_more_text' ),
		'css_class'        => array( 'css_class', '' ),
		'ticker_speed'     => array( 'ticker_speed', 'default_ticker_speed' ),
		'ticker_direction' => array( 'ticker_direction', 'default_ticker_direction' ),
		'ticker_pause'     => array( 'ticker_pause', 'default_ticker_pause' ),
		'ticker_width'     => array( 'ticker_width', 'default_ticker_width' ),
		'ticker_ratio'     => array( 'ticker_ratio', 'default_ticker_ratio' ),
		'ticker_fit'       => array( 'ticker_fit', 'default_ticker_fit' ),
		'ticker_center_scale' => array( 'ticker_center_scale', 'default_ticker_center_scale' ),
	);

	// Shortcode attribute aliases (short → canonical).
	$aliases = array(
		'columns' => 'columns_desktop',
		'speed'   => 'ticker_speed',
		'class'   => 'css_class',
	);

	// Normalize shortcode aliases.
	foreach ( $aliases as $alias => $canonical ) {
		if ( isset( $atts[ $alias ] ) && ! isset( $atts[ $canonical ] ) ) {
			$atts[ $canonical ] = $atts[ $alias ];
		}
	}

	$settings = array();

	foreach ( $map as $key => $sources ) {
		list( $meta_key, $default_key ) = $sources;

		// 1. Shortcode attribute (explicit override).
		if ( isset( $atts[ $key ] ) && '' !== $atts[ $key ] ) {
			$settings[ $key ] = $atts[ $key ];
			continue;
		}

		// 2. Collection meta.
		if ( ! empty( $meta_key ) && isset( $meta[ $meta_key ] ) && '' !== $meta[ $meta_key ] ) {
			$settings[ $key ] = $meta[ $meta_key ];
			continue;
		}

		// 3. Global default.
		if ( ! empty( $default_key ) && isset( $defaults[ $default_key ] ) ) {
			$settings[ $key ] = $defaults[ $default_key ];
			continue;
		}

		$settings[ $key ] = '';
	}

	// Cast types.
	$settings['columns_desktop'] = absint( $settings['columns_desktop'] );
	$settings['columns_tablet']  = absint( $settings['columns_tablet'] );
	$settings['columns_mobile']  = absint( $settings['columns_mobile'] );
	$settings['gap']             = absint( $settings['gap'] );
	$settings['radius']          = absint( $settings['radius'] );
	$settings['row_height']      = absint( $settings['row_height'] );
	$settings['per_page']        = absint( $settings['per_page'] );
	$settings['ticker_speed']    = absint( $settings['ticker_speed'] );
	$settings['ticker_width']    = absint( $settings['ticker_width'] );
	$settings['ticker_center_scale'] = absint( $settings['ticker_center_scale'] );

	$valid_ticker_fits        = array( 'cover', 'contain', 'fill' );
	$settings['ticker_fit']   = in_array( $settings['ticker_fit'], $valid_ticker_fits, true ) ? $settings['ticker_fit'] : 'cover';
	$settings['lightbox']        = rest_sanitize_boolean( $settings['lightbox'] );
	$settings['lazyload']        = rest_sanitize_boolean( $settings['lazyload'] );
	$settings['show_title']      = rest_sanitize_boolean( $settings['show_title'] );
	$settings['ticker_pause']    = rest_sanitize_boolean( $settings['ticker_pause'] );

	return $settings;
}

/**
 * Render opening container div with CSS variables.
 *
 * @since 1.0.0
 * @param int   $gallery_id Gallery post ID.
 * @param array $settings   Merged settings.
 * @param int   $total      Total photos count.
 * @return string Opening HTML.
 */
function mvweb_gw_render_container_open( int $gallery_id, array $settings, int $total ): string {

	$layout = esc_attr( $settings['layout'] );

	// CSS classes.
	$classes = array( 'mvweb-gw', 'mvweb-gw--' . $layout );

	if ( 'none' !== $settings['animation'] && 'ticker' !== $layout ) {
		$classes[] = 'mvweb-gw--anim-' . esc_attr( $settings['animation'] );
	}

	if ( 'none' !== $settings['hover'] && 'ticker' !== $layout ) {
		$classes[] = 'mvweb-gw--hover-' . esc_attr( $settings['hover'] );
	}

	if ( 'none' !== $settings['overlay_mode'] && 'ticker' !== $layout ) {
		$classes[] = 'mvweb-gw--overlay-' . esc_attr( $settings['overlay_mode'] );
	}

	// Ticker direction class.
	if ( 'ticker' === $layout && ! empty( $settings['ticker_direction'] ) ) {
		$classes[] = 'mvweb-gw--dir-' . esc_attr( $settings['ticker_direction'] );
	}

	if ( ! empty( $settings['css_class'] ) ) {
		$extra = array_map( 'sanitize_html_class', explode( ' ', $settings['css_class'] ) );
		$classes = array_merge( $classes, array_filter( $extra ) );
	}

	// CSS variables.
	$css_vars = array(
		'--mvweb-gw-columns'        => $settings['columns_desktop'],
		'--mvweb-gw-columns-tablet' => $settings['columns_tablet'],
		'--mvweb-gw-columns-mobile' => $settings['columns_mobile'],
		'--mvweb-gw-gap'            => $settings['gap'] . 'px',
		'--mvweb-gw-radius'         => $settings['radius'] . 'px',
		'--mvweb-gw-max-width'      => esc_attr( $settings['max_width'] ),
	);

	// Aspect ratio.
	$aspect = $settings['aspect_ratio'];
	if ( 'custom' === $aspect && ! empty( $settings['aspect_custom'] ) ) {
		$css_vars['--mvweb-gw-aspect-ratio'] = esc_attr( $settings['aspect_custom'] );
	} elseif ( 'auto' !== $aspect && 'custom' !== $aspect ) {
		$css_vars['--mvweb-gw-aspect-ratio'] = str_replace( ':', '/', $aspect );
	}

	// Object fit.
	$css_vars['--mvweb-gw-object-fit'] = esc_attr( $settings['object_fit'] );

	// Ticker-specific CSS variables.
	if ( 'ticker' === $layout ) {
		if ( $settings['ticker_width'] > 0 ) {
			$css_vars['--mvweb-gw-ticker-width'] = $settings['ticker_width'] . 'px';
		}
		if ( ! empty( $settings['ticker_ratio'] ) ) {
			$css_vars['--mvweb-gw-ticker-ratio'] = esc_attr( $settings['ticker_ratio'] );
		}
		if ( $settings['ticker_speed'] > 0 ) {
			$css_vars['--mvweb-gw-ticker-speed'] = $settings['ticker_speed'] . 's';
		}
		$css_vars['--mvweb-gw-ticker-fit'] = esc_attr( $settings['ticker_fit'] );
	}

	// Justified: add row_height CSS variable.
	if ( 'justified' === $layout && $settings['row_height'] > 0 ) {
		$css_vars['--mvweb-gw-row-height'] = $settings['row_height'] . 'px';
	}

	$style_parts = array();
	foreach ( $css_vars as $prop => $val ) {
		$style_parts[] = $prop . ': ' . $val;
	}

	// Data attributes.
	$data_attrs = sprintf(
		'data-gallery-id="%d" data-per-page="%d"',
		$gallery_id,
		$settings['per_page']
	);

	// Ticker data attributes.
	if ( 'ticker' === $layout ) {
		$data_attrs .= sprintf(
			' data-speed="%d" data-pause-hover="%s" data-center-scale="%d"',
			$settings['ticker_speed'],
			$settings['ticker_pause'] ? 'true' : 'false',
			$settings['ticker_center_scale']
		);
	}

	// Justified: row height data attribute.
	if ( 'justified' === $layout ) {
		$data_attrs .= sprintf( ' data-row-height="%d"', absint( $settings['row_height'] ) );
	}

	return sprintf(
		'<div class="%s" %s style="%s">',
		esc_attr( implode( ' ', $classes ) ),
		$data_attrs,
		esc_attr( implode( '; ', $style_parts ) )
	);
}

/**
 * Render filter bar with tag buttons.
 *
 * Collects unique tags from all photos and renders filter buttons.
 *
 * @since 1.0.0
 * @param array $photos All photos in the collection (not just visible).
 * @return string Filter bar HTML or empty string if no tags.
 */
function mvweb_gw_render_filter_bar( array $photos ): string {

	$tags = array();
	foreach ( $photos as $photo ) {
		if ( ! empty( $photo['tags'] ) && is_array( $photo['tags'] ) ) {
			foreach ( $photo['tags'] as $tag ) {
				$tag = trim( $tag );
				if ( '' !== $tag && ! in_array( $tag, $tags, true ) ) {
					$tags[] = $tag;
				}
			}
		}
	}

	if ( empty( $tags ) ) {
		return '';
	}

	sort( $tags );

	$html  = '<div class="mvweb-gw__filters" role="toolbar" aria-label="' . esc_attr__( 'Filter photos', 'mvweb-gallery-wall' ) . '">';
	$html .= '<button class="mvweb-gw__filter mvweb-gw__filter--active" data-tag="all" aria-pressed="true">';
	$html .= esc_html__( 'All', 'mvweb-gallery-wall' ) . '</button>';

	foreach ( $tags as $tag ) {
		$html .= sprintf(
			'<button class="mvweb-gw__filter" data-tag="%s" aria-pressed="false">%s</button>',
			esc_attr( $tag ),
			esc_html( $tag )
		);
	}

	$html .= '</div>';

	return $html;
}

/**
 * Render a single gallery item.
 *
 * @since 1.0.0
 * @param array $photo     Photo data from JSON.
 * @param int   $index     Photo index (0-based).
 * @param array $settings  Merged gallery settings.
 * @param int   $first_row Number of items in the first row (for eager loading).
 * @param bool  $beyond    Whether this item is beyond the per-page limit (hidden until "Load More").
 * @return string Item HTML.
 */
function mvweb_gw_render_item( array $photo, int $index, array $settings, int $first_row, bool $beyond = false ): string {

	$attachment_id = absint( $photo['attachment_id'] ?? 0 );
	if ( 0 === $attachment_id ) {
		return '';
	}

	// Verify attachment exists.
	$img_src = wp_get_attachment_image_url( $attachment_id, 'large' );
	if ( ! $img_src ) {
		return '';
	}

	// Tags data attribute.
	$tags_attr = '';
	if ( ! empty( $photo['tags'] ) && is_array( $photo['tags'] ) ) {
		$tags_attr = sprintf( ' data-tags="%s"', esc_attr( wp_json_encode( $photo['tags'], JSON_UNESCAPED_UNICODE ) ) );
	}

	// Image attributes.
	$width   = absint( $photo['width'] ?? 0 );
	$height  = absint( $photo['height'] ?? 0 );
	$alt     = wp_get_attachment_image_url( $attachment_id, 'full' ) ? get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) : '';
	$title   = isset( $photo['title'] ) ? $photo['title'] : '';
	$caption = isset( $photo['caption'] ) ? $photo['caption'] : '';
	$link    = isset( $photo['link'] ) ? $photo['link'] : '';

	// Use alt from attachment if available.
	$alt_text = $alt ? $alt : $title;

	// Loading attribute. When lazy loading is enabled, the first row stays eager
	// for a fast LCP and the rest is lazy. When disabled, everything is eager.
	if ( empty( $settings['lazyload'] ) ) {
		$loading = 'eager';
	} else {
		$loading = ( $index < $first_row ) ? 'eager' : 'lazy';
	}

	// Srcset and sizes.
	$srcset = wp_get_attachment_image_srcset( $attachment_id, 'large' );
	$sizes  = wp_get_attachment_image_sizes( $attachment_id, 'large' );

	// Build image tag.
	$img_html = sprintf(
		'<img src="%s"%s%s alt="%s" loading="%s"%s%s>',
		esc_url( $img_src ),
		$srcset ? ' srcset="' . esc_attr( $srcset ) . '"' : '',
		$sizes ? ' sizes="' . esc_attr( $sizes ) . '"' : '',
		esc_attr( $alt_text ),
		esc_attr( $loading ),
		$width ? ' width="' . $width . '"' : '',
		$height ? ' height="' . $height . '"' : ''
	);

	// Overlay.
	$overlay_html = '';
	if ( 'none' !== $settings['overlay_mode'] && ( '' !== $title || '' !== $caption ) ) {
		$overlay_html = '<div class="mvweb-gw__overlay">';
		if ( '' !== $title ) {
			$overlay_html .= '<span class="mvweb-gw__overlay-title">' . esc_html( $title ) . '</span>';
		}
		if ( '' !== $caption ) {
			$overlay_html .= '<span class="mvweb-gw__overlay-caption">' . esc_html( $caption ) . '</span>';
		}
		$overlay_html .= '</div>';
	}

	// Inner content: link or lightbox trigger.
	$inner = '';
	if ( '' !== $link ) {
		$target = esc_attr( $settings['link_target'] );
		$rel    = '_blank' === $settings['link_target'] ? ' rel="noopener noreferrer"' : '';
		$inner  = sprintf(
			'<a href="%s" target="%s"%s>%s%s</a>',
			esc_url( $link ),
			$target,
			$rel,
			$img_html,
			$overlay_html
		);
	} elseif ( $settings['lightbox'] ) {
		$inner = sprintf(
			'<button class="mvweb-gw__lightbox-trigger" data-index="%d">%s%s</button>',
			$index,
			$img_html,
			$overlay_html
		);
	} else {
		$inner = $img_html . $overlay_html;
	}

	// Data attributes for masonry/justified JS layout.
	$dim_attrs = '';
	if ( $width > 0 && $height > 0 ) {
		$dim_attrs = sprintf( ' data-width="%d" data-height="%d"', $width, $height );
	}

	$item_class = 'mvweb-gw__item';
	if ( $beyond ) {
		$item_class .= ' mvweb-gw__item--beyond';
	}

	return sprintf(
		'<div class="%s" role="listitem"%s%s>%s</div>',
		esc_attr( $item_class ),
		$tags_attr,
		$dim_attrs,
		$inner
	);
}

/**
 * Render load more button.
 *
 * @since 1.0.0
 * @param array $settings Merged settings.
 * @return string Load more HTML.
 */
function mvweb_gw_render_load_more( array $settings ): string {
	$text = $settings['load_more_text'];
	if ( empty( $text ) || 'Show More' === $text ) {
		$text = __( 'Show More', 'mvweb-gallery-wall' );
	}

	$step = absint( $settings['per_page'] );

	return sprintf(
		'<div class="mvweb-gw__load-more"><button class="mvweb-btn mvweb-gw__load-more-btn" data-step="%d">%s</button></div>',
		$step,
		esc_html( $text )
	);
}

/**
 * Render gallery items only (for AJAX load more).
 *
 * @since 1.0.0
 * @param array $photos   Array of photo data.
 * @param array $settings Merged settings.
 * @param int   $offset   Starting index for items (for data-index).
 * @return string HTML of gallery items.
 */
function mvweb_gw_render_items_only( array $photos, array $settings, int $offset = 0 ): string {
	$html = '';
	foreach ( $photos as $index => $photo ) {
		$html .= mvweb_gw_render_item( $photo, $offset + $index, $settings, 0 );
	}
	return $html;
}

/**
 * Render ticker layout.
 *
 * Ticker uses completely different markup: a track with slides
 * instead of a grid with items (see TZ section 14.2).
 *
 * @since 1.0.0
 * @param int      $gallery_id Gallery post ID.
 * @param array    $settings   Merged settings.
 * @param array    $photos     Photos to display.
 * @param \WP_Post $post       Gallery post object.
 * @return string Ticker HTML.
 */
function mvweb_gw_render_ticker( int $gallery_id, array $settings, array $photos, \WP_Post $post ): string {

	$total = count( $photos );
	$html  = mvweb_gw_render_container_open( $gallery_id, $settings, $total );

	// Title.
	if ( $settings['show_title'] ) {
		$html .= '<h3 class="mvweb-gw__title">' . esc_html( $post->post_title ) . '</h3>';
	}

	// Viewport wraps the animated track so clipping happens around it,
	// keeping the title (and center-zoom overflow) outside the clip region.
	$html .= '<div class="mvweb-gw__viewport">';
	$html .= '<div class="mvweb-gw__track">';

	foreach ( $photos as $index => $photo ) {
		$html .= mvweb_gw_render_slide( $photo, $index, $settings );
	}

	$html .= '</div>'; // .mvweb-gw__track
	$html .= '</div>'; // .mvweb-gw__viewport
	$html .= '</div>'; // .mvweb-gw

	return $html;
}

/**
 * Render a single ticker slide.
 *
 * @since 1.0.0
 * @param array $photo    Photo data from JSON.
 * @param int   $index    Photo index (0-based).
 * @param array $settings Merged gallery settings.
 * @return string Slide HTML.
 */
function mvweb_gw_render_slide( array $photo, int $index, array $settings ): string {

	$attachment_id = absint( $photo['attachment_id'] ?? 0 );
	if ( 0 === $attachment_id ) {
		return '';
	}

	$img_src = wp_get_attachment_image_url( $attachment_id, 'large' );
	if ( ! $img_src ) {
		return '';
	}

	$alt   = get_post_meta( $attachment_id, '_wp_attachment_image_alt', true );
	$title = isset( $photo['title'] ) ? $photo['title'] : '';
	if ( empty( $alt ) ) {
		$alt = $title;
	}

	// Eager for first few slides, lazy for the rest. All eager when lazy loading is off.
	if ( empty( $settings['lazyload'] ) ) {
		$loading = 'eager';
	} else {
		$loading = ( $index < 5 ) ? 'eager' : 'lazy';
	}

	$img_html = sprintf(
		'<img src="%s" alt="%s" loading="%s">',
		esc_url( $img_src ),
		esc_attr( $alt ),
		esc_attr( $loading )
	);

	// Ticker slides can have links.
	$link = isset( $photo['link'] ) ? $photo['link'] : '';
	if ( '' !== $link ) {
		$target = esc_attr( $settings['link_target'] );
		$rel    = '_blank' === $settings['link_target'] ? ' rel="noopener noreferrer"' : '';
		$inner  = sprintf(
			'<a href="%s" target="%s"%s>%s</a>',
			esc_url( $link ),
			$target,
			$rel,
			$img_html
		);
	} else {
		$inner = $img_html;
	}

	return '<div class="mvweb-gw__slide">' . $inner . '</div>';
}

/**
 * Enqueue frontend CSS and JS.
 *
 * Called from within the shortcode/widget render function.
 * Uses wp_enqueue to avoid duplicate loading.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_gw_enqueue_frontend_assets(): void {

	$css_path = MVWEB_GW_PATH . 'public/css/gallery-wall.min.css';
	$js_path  = MVWEB_GW_PATH . 'public/js/gallery-wall.min.js';

	wp_enqueue_style(
		'mvweb-gallery-wall',
		MVWEB_GW_URL . 'public/css/gallery-wall.min.css',
		array(),
		file_exists( $css_path ) ? filemtime( $css_path ) : MVWEB_GW_VERSION
	);

	wp_add_inline_style( 'mvweb-gallery-wall', mvweb_gw_appearance_inline_css() );

	wp_enqueue_script(
		'mvweb-gallery-wall',
		MVWEB_GW_URL . 'public/js/gallery-wall.min.js',
		array(),
		file_exists( $js_path ) ? filemtime( $js_path ) : MVWEB_GW_VERSION,
		true
	);

	wp_localize_script( 'mvweb-gallery-wall', 'mvwebGw', array(
		'ajaxUrl' => admin_url( 'admin-ajax.php' ),
		'nonce'   => wp_create_nonce( 'mvweb_gw_load_more' ),
	) );
}

/**
 * Build the global appearance CSS variables for the plugin's UI controls.
 *
 * A single shared style applies to both the filter chips and the Load More button.
 * These are studio-wide settings (not per-collection), so they are emitted once as a
 * single :root rule rather than inline on every shortcode wrapper.
 *
 * @since 1.0.0
 * @return string CSS rule for :root.
 */
function mvweb_gw_appearance_inline_css(): string {
	$s = MVweb_GW_Settings::get();

	$vars = array(
		'--mvweb-gw-ui-bg'            => $s['ui_bg'],
		'--mvweb-gw-ui-text'          => $s['ui_text'],
		'--mvweb-gw-ui-border'        => $s['ui_border'],
		'--mvweb-gw-ui-active-bg'     => $s['ui_active_bg'],
		'--mvweb-gw-ui-active-text'   => $s['ui_active_text'],
		'--mvweb-gw-ui-active-border' => $s['ui_active_border'],
		'--mvweb-gw-ui-radius'        => absint( $s['ui_radius'] ) . 'px',
		'--mvweb-gw-ui-border-width'  => absint( $s['ui_border_width'] ) . 'px',
	);

	$parts = array();
	foreach ( $vars as $name => $value ) {
		$parts[] = $name . ': ' . esc_attr( $value );
	}

	return ':root{' . implode( ';', $parts ) . '}';
}
