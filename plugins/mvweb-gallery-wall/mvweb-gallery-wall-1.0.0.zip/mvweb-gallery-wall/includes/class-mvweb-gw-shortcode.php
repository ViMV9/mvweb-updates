<?php
/**
 * Shortcode registration for MVweb Gallery Wall.
 *
 * Registers [mvweb_gallery] shortcode with attribute sanitization.
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Class MVweb_GW_Shortcode
 *
 * Handles shortcode registration and attribute processing.
 *
 * @since 1.0.0
 */
class MVweb_GW_Shortcode {

	/**
	 * Initialize shortcode.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_shortcode( 'mvweb_gallery', array( __CLASS__, 'render' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ) );
	}

	/**
	 * Register (but don't enqueue) frontend assets.
	 *
	 * Assets are enqueued conditionally when the shortcode is actually rendered.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_assets() {
		$css_path = MVWEB_GW_PATH . 'public/css/gallery-wall.min.css';
		$js_path  = MVWEB_GW_PATH . 'public/js/gallery-wall.min.js';

		wp_register_style(
			'mvweb-gallery-wall',
			MVWEB_GW_URL . 'public/css/gallery-wall.min.css',
			array(),
			file_exists( $css_path ) ? filemtime( $css_path ) : MVWEB_GW_VERSION
		);

		wp_register_script(
			'mvweb-gallery-wall',
			MVWEB_GW_URL . 'public/js/gallery-wall.min.js',
			array(),
			file_exists( $js_path ) ? filemtime( $js_path ) : MVWEB_GW_VERSION,
			true
		);
	}

	/**
	 * Render the [mvweb_gallery] shortcode.
	 *
	 * Sanitizes all attributes via whitelist, then delegates to mvweb_gw_render().
	 *
	 * @since 1.0.0
	 * @param array|string $atts Shortcode attributes.
	 * @return string Gallery HTML.
	 */
	public static function render( $atts ): string {
		$atts = shortcode_atts(
			array(
				'id'         => 0,
				'layout'     => '',
				'columns'    => '',
				'limit'      => 0,
				'animation'  => '',
				'hover'      => '',
				'gap'        => '',
				'radius'     => '',
				'speed'      => '',
				'class'      => '',
				'show_title' => '',
				'lightbox'   => '',
				'per_page'   => '',
				'order'      => '',
			),
			$atts,
			'mvweb_gallery'
		);

		// Sanitize attributes.
		$sanitized = self::sanitize_atts( $atts );

		// Render gallery.
		return mvweb_gw_render( $sanitized );
	}

	/**
	 * Sanitize shortcode attributes via whitelist.
	 *
	 * @since 1.0.0
	 * @param array $atts Raw shortcode attributes.
	 * @return array Sanitized attributes.
	 */
	private static function sanitize_atts( array $atts ): array {
		$sanitized = array();

		// ID — required.
		$sanitized['id'] = absint( $atts['id'] );

		// Layout — whitelist.
		$valid_layouts = array( 'grid', 'masonry', 'justified', 'ticker' );
		if ( '' !== $atts['layout'] ) {
			$sanitized['layout'] = in_array( $atts['layout'], $valid_layouts, true ) ? $atts['layout'] : '';
		}

		// Columns (desktop) — integer 1-8.
		if ( '' !== $atts['columns'] ) {
			$sanitized['columns'] = min( max( absint( $atts['columns'] ), 1 ), 8 );
		}

		// Limit.
		if ( '' !== $atts['limit'] && 0 !== absint( $atts['limit'] ) ) {
			$sanitized['limit'] = absint( $atts['limit'] );
		}

		// Animation — whitelist.
		$valid_animations = array( 'fade', 'slide-up', 'slide-left', 'scale', 'flip', 'none' );
		if ( '' !== $atts['animation'] ) {
			$sanitized['animation'] = in_array( $atts['animation'], $valid_animations, true ) ? $atts['animation'] : '';
		}

		// Hover — whitelist.
		$valid_hovers = array( 'zoom', 'grayscale', 'brightness', 'overlay', 'none' );
		if ( '' !== $atts['hover'] ) {
			$sanitized['hover'] = in_array( $atts['hover'], $valid_hovers, true ) ? $atts['hover'] : '';
		}

		// Gap.
		if ( '' !== $atts['gap'] ) {
			$sanitized['gap'] = absint( $atts['gap'] );
		}

		// Radius.
		if ( '' !== $atts['radius'] ) {
			$sanitized['radius'] = absint( $atts['radius'] );
		}

		// Speed (ticker) — alias handled in merge.
		if ( '' !== $atts['speed'] ) {
			$sanitized['speed'] = absint( $atts['speed'] );
		}

		// CSS class — sanitize each class.
		if ( '' !== $atts['class'] ) {
			$classes = array_map( 'sanitize_html_class', explode( ' ', $atts['class'] ) );
			$sanitized['class'] = implode( ' ', array_filter( $classes ) );
		}

		// Show title — boolean.
		if ( '' !== $atts['show_title'] ) {
			$sanitized['show_title'] = rest_sanitize_boolean( $atts['show_title'] );
		}

		// Lightbox — boolean.
		if ( '' !== $atts['lightbox'] ) {
			$sanitized['lightbox'] = rest_sanitize_boolean( $atts['lightbox'] );
		}

		// Per page.
		if ( '' !== $atts['per_page'] ) {
			$sanitized['per_page'] = min( absint( $atts['per_page'] ), 100 );
		}

		// Order — whitelist.
		$valid_orders = array( 'manual', 'random' );
		if ( '' !== $atts['order'] ) {
			$sanitized['order'] = in_array( $atts['order'], $valid_orders, true ) ? $atts['order'] : '';
		}

		return $sanitized;
	}
}
