<?php
/**
 * Classic Widget for MVweb Gallery Wall.
 *
 * Displays a gallery collection in widget areas (sidebars, footers, etc.).
 * Internally delegates rendering to the same function used by the shortcode.
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Class MVweb_GW_Widget
 *
 * Classic Widget that renders a gallery collection.
 *
 * @since 1.0.0
 */
class MVweb_GW_Widget extends WP_Widget {

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		parent::__construct(
			'mvweb_gw_widget',
			__( 'MVweb Gallery Wall', 'mvweb-gallery-wall' ),
			array(
				'description' => __( 'Display a photo gallery collection.', 'mvweb-gallery-wall' ),
			)
		);
	}

	/**
	 * Output the widget content on the frontend.
	 *
	 * @since 1.0.0
	 * @param array $args     Widget display arguments (before_widget, after_widget, etc.).
	 * @param array $instance Widget settings.
	 * @return void
	 */
	public function widget( $args, $instance ) {

		$collection_id = ! empty( $instance['collection'] ) ? absint( $instance['collection'] ) : 0;
		if ( 0 === $collection_id ) {
			return;
		}

		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		$title = ! empty( $instance['title'] ) ? $instance['title'] : '';
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		if ( ! empty( $title ) ) {
			echo $args['before_title'] . esc_html( $title ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		// Build render attributes from widget settings.
		$atts = array(
			'id' => $collection_id,
		);

		if ( ! empty( $instance['layout'] ) ) {
			$atts['layout'] = $instance['layout'];
		}

		if ( ! empty( $instance['columns'] ) ) {
			$atts['columns'] = absint( $instance['columns'] );
		}

		if ( ! empty( $instance['limit'] ) ) {
			$atts['limit'] = absint( $instance['limit'] );
		}

		if ( ! empty( $instance['animation'] ) ) {
			$atts['animation'] = $instance['animation'];
		}

		// Render using the same function as the shortcode.
		echo mvweb_gw_render( $atts ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Render function handles escaping.

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Output the widget settings form in the admin.
	 *
	 * @since 1.0.0
	 * @param array $instance Current widget settings.
	 * @return void
	 */
	public function form( $instance ) {

		$title      = isset( $instance['title'] ) ? $instance['title'] : '';
		$collection = isset( $instance['collection'] ) ? absint( $instance['collection'] ) : 0;
		$layout     = isset( $instance['layout'] ) ? $instance['layout'] : '';
		$columns    = isset( $instance['columns'] ) ? absint( $instance['columns'] ) : 2;
		$limit      = isset( $instance['limit'] ) ? absint( $instance['limit'] ) : 0;
		$animation  = isset( $instance['animation'] ) ? $instance['animation'] : '';

		// Get published collections.
		$collections = get_posts( array(
			'post_type'      => 'mvweb_gallery',
			'post_status'    => 'publish',
			'posts_per_page' => 100,
			'orderby'        => 'title',
			'order'          => 'ASC',
		) );

		$layouts = array(
			''          => __( 'Default (from collection)', 'mvweb-gallery-wall' ),
			'grid'      => __( 'Grid', 'mvweb-gallery-wall' ),
			'masonry'   => __( 'Masonry', 'mvweb-gallery-wall' ),
			'justified' => __( 'Justified', 'mvweb-gallery-wall' ),
			'ticker'    => __( 'Ticker', 'mvweb-gallery-wall' ),
		);

		$animations = array(
			''           => __( 'Default (from collection)', 'mvweb-gallery-wall' ),
			'fade'       => __( 'Fade', 'mvweb-gallery-wall' ),
			'slide-up'   => __( 'Slide Up', 'mvweb-gallery-wall' ),
			'slide-left' => __( 'Slide Left', 'mvweb-gallery-wall' ),
			'scale'      => __( 'Scale', 'mvweb-gallery-wall' ),
			'flip'       => __( 'Flip', 'mvweb-gallery-wall' ),
			'none'       => __( 'None', 'mvweb-gallery-wall' ),
		);
		?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>">
				<?php esc_html_e( 'Title:', 'mvweb-gallery-wall' ); ?>
			</label>
			<input class="widefat" type="text"
				   id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
				   name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>"
				   value="<?php echo esc_attr( $title ); ?>">
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'collection' ) ); ?>">
				<?php esc_html_e( 'Collection:', 'mvweb-gallery-wall' ); ?>
			</label>
			<select class="widefat"
					id="<?php echo esc_attr( $this->get_field_id( 'collection' ) ); ?>"
					name="<?php echo esc_attr( $this->get_field_name( 'collection' ) ); ?>">
				<option value=""><?php esc_html_e( '&mdash; Select &mdash;', 'mvweb-gallery-wall' ); ?></option>
				<?php foreach ( $collections as $c ) : ?>
					<option value="<?php echo esc_attr( $c->ID ); ?>" <?php selected( $collection, $c->ID ); ?>>
						<?php echo esc_html( $c->post_title ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>">
				<?php esc_html_e( 'Layout:', 'mvweb-gallery-wall' ); ?>
			</label>
			<select class="widefat"
					id="<?php echo esc_attr( $this->get_field_id( 'layout' ) ); ?>"
					name="<?php echo esc_attr( $this->get_field_name( 'layout' ) ); ?>">
				<?php foreach ( $layouts as $value => $label ) : ?>
					<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $layout, $value ); ?>>
						<?php echo esc_html( $label ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'columns' ) ); ?>">
				<?php esc_html_e( 'Columns:', 'mvweb-gallery-wall' ); ?>
			</label>
			<input class="tiny-text" type="number"
				   id="<?php echo esc_attr( $this->get_field_id( 'columns' ) ); ?>"
				   name="<?php echo esc_attr( $this->get_field_name( 'columns' ) ); ?>"
				   value="<?php echo esc_attr( $columns ); ?>"
				   min="1" max="4" step="1">
			<span class="description"><?php esc_html_e( '1-4 (for sidebars usually 1-2)', 'mvweb-gallery-wall' ); ?></span>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>">
				<?php esc_html_e( 'Limit:', 'mvweb-gallery-wall' ); ?>
			</label>
			<input class="tiny-text" type="number"
				   id="<?php echo esc_attr( $this->get_field_id( 'limit' ) ); ?>"
				   name="<?php echo esc_attr( $this->get_field_name( 'limit' ) ); ?>"
				   value="<?php echo esc_attr( $limit ); ?>"
				   min="0" step="1">
			<span class="description"><?php esc_html_e( '0 = show all', 'mvweb-gallery-wall' ); ?></span>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'animation' ) ); ?>">
				<?php esc_html_e( 'Animation:', 'mvweb-gallery-wall' ); ?>
			</label>
			<select class="widefat"
					id="<?php echo esc_attr( $this->get_field_id( 'animation' ) ); ?>"
					name="<?php echo esc_attr( $this->get_field_name( 'animation' ) ); ?>">
				<?php foreach ( $animations as $value => $label ) : ?>
					<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $animation, $value ); ?>>
						<?php echo esc_html( $label ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</p>

		<?php
	}

	/**
	 * Sanitize and save widget settings.
	 *
	 * @since 1.0.0
	 * @param array $new_instance New settings.
	 * @param array $old_instance Previous settings.
	 * @return array Sanitized settings.
	 */
	public function update( $new_instance, $old_instance ) {

		$allowed_layouts    = array( '', 'grid', 'masonry', 'justified', 'ticker' );
		$allowed_animations = array( '', 'fade', 'slide-up', 'slide-left', 'scale', 'flip', 'none' );

		$instance               = array();
		$instance['title']      = sanitize_text_field( $new_instance['title'] ?? '' );
		$instance['collection'] = absint( $new_instance['collection'] ?? 0 );

		$layout              = sanitize_text_field( $new_instance['layout'] ?? '' );
		$instance['layout']  = in_array( $layout, $allowed_layouts, true ) ? $layout : '';

		$instance['columns'] = min( 4, max( 1, absint( $new_instance['columns'] ?? 2 ) ) );
		$instance['limit']   = absint( $new_instance['limit'] ?? 0 );

		$animation              = sanitize_text_field( $new_instance['animation'] ?? '' );
		$instance['animation']  = in_array( $animation, $allowed_animations, true ) ? $animation : '';

		return $instance;
	}
}
