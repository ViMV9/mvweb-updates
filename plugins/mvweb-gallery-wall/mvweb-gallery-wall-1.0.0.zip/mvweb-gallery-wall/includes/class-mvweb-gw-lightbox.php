<?php
/**
 * Lightbox markup for MVweb Gallery Wall.
 *
 * Renders the lightbox dialog HTML in wp_footer.
 * A single lightbox instance is shared by all galleries on the page.
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Class MVweb_GW_Lightbox
 *
 * Outputs lightbox HTML markup via wp_footer.
 *
 * @since 1.0.0
 */
class MVweb_GW_Lightbox {

	/**
	 * Whether the lightbox has been enqueued for output.
	 *
	 * @since 1.0.0
	 * @var bool
	 */
	private static bool $enqueued = false;

	/**
	 * Enqueue lightbox output.
	 *
	 * Safe to call multiple times — will only add wp_footer action once.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function enqueue(): void {
		if ( self::$enqueued ) {
			return;
		}

		self::$enqueued = true;
		add_action( 'wp_footer', array( __CLASS__, 'render' ), 99 );
	}

	/**
	 * Render lightbox HTML.
	 *
	 * Output before </body> via wp_footer hook.
	 * Markup follows TZ section 14.3 with full a11y attributes.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render(): void {
		?>
		<div class="mvweb-gw-lightbox" role="dialog" aria-modal="true" aria-label="<?php esc_attr_e( 'Image gallery', 'mvweb-gallery-wall' ); ?>" hidden>
			<div class="mvweb-gw-lightbox__backdrop"></div>
			<button class="mvweb-gw-lightbox__close" aria-label="<?php esc_attr_e( 'Close', 'mvweb-gallery-wall' ); ?>">&times;</button>
			<button class="mvweb-gw-lightbox__prev" aria-label="<?php esc_attr_e( 'Previous', 'mvweb-gallery-wall' ); ?>">&#8249;</button>
			<button class="mvweb-gw-lightbox__next" aria-label="<?php esc_attr_e( 'Next', 'mvweb-gallery-wall' ); ?>">&#8250;</button>

			<div class="mvweb-gw-lightbox__content">
				<img class="mvweb-gw-lightbox__img" src="" alt="">
			</div>

			<div class="mvweb-gw-lightbox__info">
				<span class="mvweb-gw-lightbox__counter" aria-live="polite"></span>
				<span class="mvweb-gw-lightbox__title"></span>
				<span class="mvweb-gw-lightbox__caption"></span>
			</div>
		</div>
		<?php
	}
}
