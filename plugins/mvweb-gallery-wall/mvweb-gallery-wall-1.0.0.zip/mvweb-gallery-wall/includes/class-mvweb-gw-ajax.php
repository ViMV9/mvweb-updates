<?php
/**
 * AJAX handlers for MVweb Gallery Wall.
 *
 * Handles the "Load More" AJAX endpoint for paginated photo loading.
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Class MVweb_GW_Ajax
 *
 * Registers and handles wp_ajax / wp_ajax_nopriv actions.
 *
 * @since 1.0.0
 */
class MVweb_GW_Ajax {

	/**
	 * Initialize AJAX hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init(): void {
		add_action( 'wp_ajax_mvweb_gw_load_more', array( __CLASS__, 'load_more' ) );
		add_action( 'wp_ajax_nopriv_mvweb_gw_load_more', array( __CLASS__, 'load_more' ) );
	}

	/**
	 * Handle load more AJAX request.
	 *
	 * Validates nonce, gallery ID, page, and per_page parameters.
	 * Returns rendered HTML for the next batch of photos.
	 *
	 * @since 1.0.0
	 * @return void Sends JSON response and dies.
	 */
	public static function load_more(): void {

		// Verify nonce.
		if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'mvweb_gw_load_more' ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid nonce.', 'mvweb-gallery-wall' ) ), 403 );
		}

		// Validate gallery_id.
		$gallery_id = isset( $_POST['gallery_id'] ) ? absint( $_POST['gallery_id'] ) : 0;
		if ( 0 === $gallery_id ) {
			wp_send_json_error( array( 'message' => __( 'Missing gallery ID.', 'mvweb-gallery-wall' ) ), 400 );
		}

		// Verify post type and status.
		$post = get_post( $gallery_id );
		if ( ! $post || 'mvweb_gallery' !== $post->post_type || 'publish' !== $post->post_status ) {
			wp_send_json_error( array( 'message' => __( 'Invalid gallery.', 'mvweb-gallery-wall' ) ), 404 );
		}

		// Validate page.
		$page = isset( $_POST['page'] ) ? absint( $_POST['page'] ) : 1;
		if ( $page < 1 ) {
			$page = 1;
		}

		// Validate per_page (server limit: 100).
		$per_page = isset( $_POST['per_page'] ) ? min( absint( $_POST['per_page'] ), 100 ) : 12;
		if ( $per_page < 1 ) {
			$per_page = 12;
		}

		// Load photos.
		$photos_json = get_post_meta( $gallery_id, '_mvweb_gw_photos', true );
		$photos      = json_decode( $photos_json, true );
		if ( ! is_array( $photos ) || empty( $photos ) ) {
			wp_send_json_error( array( 'message' => __( 'No photos.', 'mvweb-gallery-wall' ) ), 404 );
		}

		// Load collection meta and merge with global defaults.
		$meta     = mvweb_gw_get_collection_meta( $gallery_id );
		$defaults = MVweb_GW_Settings::get();
		$settings = mvweb_gw_merge_settings( array(), $meta, $defaults );

		// Sort photos.
		if ( 'random' === $settings['order'] ) {
			shuffle( $photos );
		} else {
			usort( $photos, function ( $a, $b ) {
				return ( $a['order'] ?? 0 ) - ( $b['order'] ?? 0 );
			} );
		}

		// Calculate offset and slice.
		$offset      = ( $page - 1 ) * $per_page;
		$total       = count( $photos );
		$page_photos = array_slice( $photos, $offset, $per_page );

		if ( empty( $page_photos ) ) {
			wp_send_json_success( array(
				'html'     => '',
				'has_more' => false,
				'page'     => $page,
			) );
		}

		// Render items only (no container).
		$html = mvweb_gw_render_items_only( $page_photos, $settings, $offset );

		// Determine if there are more pages.
		$has_more = ( $offset + count( $page_photos ) ) < $total;

		wp_send_json_success( array(
			'html'     => $html,
			'has_more' => $has_more,
			'page'     => $page,
		) );
	}
}
