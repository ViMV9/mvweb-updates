<?php
/**
 * Admin pages for MVweb Gallery Wall.
 *
 * Handles menu registration, asset enqueueing, settings processing, and page rendering.
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Class MVweb_GW_Admin
 *
 * Manages admin pages for the Gallery Wall plugin.
 *
 * @since 1.0.0
 */
class MVweb_GW_Admin {

	/**
	 * Admin page hook suffix.
	 *
	 * @var string
	 */
	private static $hook_suffix = '';

	/**
	 * Initialize admin hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_init', array( __CLASS__, 'process_settings' ) );
	}

	/**
	 * Register submenu page under MVweb Hub.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_menu() {
		self::$hook_suffix = add_submenu_page(
			MVweb_Menu::get_menu_slug(),
			__( 'Gallery Wall', 'mvweb-gallery-wall' ),
			__( 'Gallery Wall', 'mvweb-gallery-wall' ),
			'manage_options',
			'mvweb-gallery-wall',
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Enqueue admin CSS and JS on plugin pages only.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		if ( self::$hook_suffix !== $hook ) {
			return;
		}

		// Styles.
		$admin_css  = MVWEB_GW_PATH . 'admin/css/admin.min.css';
		$plugin_css = MVWEB_GW_PATH . 'admin/css/plugin.min.css';
		$admin_js   = MVWEB_GW_PATH . 'admin/js/admin.min.js';

		wp_enqueue_style(
			'mvweb-gw-admin',
			MVWEB_GW_URL . 'admin/css/admin.min.css',
			array(),
			file_exists( $admin_css ) ? filemtime( $admin_css ) : MVWEB_GW_VERSION
		);

		wp_enqueue_style(
			'mvweb-gw-plugin',
			MVWEB_GW_URL . 'admin/css/plugin.min.css',
			array( 'mvweb-gw-admin' ),
			file_exists( $plugin_css ) ? filemtime( $plugin_css ) : MVWEB_GW_VERSION
		);

		// WP Media Library + jQuery UI Sortable (for editor).
		wp_enqueue_media();
		wp_enqueue_script( 'jquery-ui-sortable' );

		// Admin JS.
		wp_enqueue_script(
			'mvweb-gw-admin',
			MVWEB_GW_URL . 'admin/js/admin.min.js',
			array( 'jquery', 'jquery-ui-sortable' ),
			file_exists( $admin_js ) ? filemtime( $admin_js ) : MVWEB_GW_VERSION,
			true
		);

		// Build localized data array.
		$localize_data = array(
			'mediaTitle'    => __( 'Select Photos', 'mvweb-gallery-wall' ),
			'mediaButton'   => __( 'Add to Gallery', 'mvweb-gallery-wall' ),
			'confirmDelete' => __( 'Are you sure you want to delete this collection? This cannot be undone.', 'mvweb-gallery-wall' ),
			'phTitle'       => __( 'Title', 'mvweb-gallery-wall' ),
			'phCaption'     => __( 'Caption', 'mvweb-gallery-wall' ),
			'phLink'        => __( 'Link URL', 'mvweb-gallery-wall' ),
			'phTags'        => __( 'Tags (comma separated)', 'mvweb-gallery-wall' ),
			'removePhoto'   => __( 'Remove', 'mvweb-gallery-wall' ),
			'noPhotos'      => __( 'No photos added. Click "Add Photos" to select images from the Media Library.', 'mvweb-gallery-wall' ),
			'photosLabel'   => __( 'photos', 'mvweb-gallery-wall' ),
			'previewPhotos' => array(),
		);

		// Pass photo thumbnail data for live preview on editor page.
		$collection_id = isset( $_GET['collection_id'] ) ? absint( $_GET['collection_id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $collection_id > 0 ) {
			$photos_json = get_post_meta( $collection_id, '_mvweb_gw_photos', true );
			$photos      = json_decode( $photos_json, true );
			if ( is_array( $photos ) ) {
				$preview_photos = array();
				foreach ( $photos as $photo ) {
					$aid = absint( $photo['attachment_id'] ?? 0 );
					if ( 0 === $aid ) {
						continue;
					}
					$thumb_url  = wp_get_attachment_image_url( $aid, 'medium' );
					$thumb_url  = $thumb_url ? $thumb_url : '';
					$preview_photos[] = array(
						'attachment_id' => $aid,
						'url'           => $thumb_url,
						'width'         => absint( $photo['width'] ?? 0 ),
						'height'        => absint( $photo['height'] ?? 0 ),
					);
				}
				$localize_data['previewPhotos'] = $preview_photos;
			}
		}

		// Also enqueue frontend CSS for preview rendering.
		if ( ( isset( $_GET['tab'] ) && 'editor' === $_GET['tab'] ) || isset( $_GET['collection_id'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			wp_enqueue_style(
				'mvweb-gallery-wall',
				MVWEB_GW_URL . 'public/css/gallery-wall.min.css',
				array(),
				MVWEB_GW_VERSION
			);
		}

		// Localize script with i18n strings and config.
		wp_localize_script( 'mvweb-gw-admin', 'mvwebGwAdmin', $localize_data );
	}

	/**
	 * Process settings form submission.
	 *
	 * Runs on admin_init so redirect can happen before headers.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function process_settings() {
		if ( ! isset( $_POST['mvweb_gw_save_settings'] ) ) {
			return;
		}

		MVweb_GW_Settings::handle_save();

		// Redirect back to settings tab to avoid resubmission.
		wp_safe_redirect( admin_url( 'admin.php?page=mvweb-gallery-wall&tab=settings&saved=1' ) );
		exit;
	}

	/**
	 * Render the main admin page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_page() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'mvweb-gallery-wall' ) );
		}

		// Show the "Settings saved" notice only on the Settings tab. The editor
		// renders its own "Collection saved" notice, so we must not add a second
		// generic one here when returning from a collection save.
		$gw_current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'collections'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switch.
		if ( isset( $_GET['saved'] ) && '1' === $_GET['saved'] && 'settings' === $gw_current_tab ) {
			add_settings_error(
				'mvweb_gw_messages',
				'mvweb_gw_saved',
				__( 'Settings saved.', 'mvweb-gallery-wall' ),
				'updated'
			);
		}

		include MVWEB_GW_PATH . 'admin/views/page-main.php';
	}
}
