/**
 * Admin JavaScript for MVweb Gallery Wall
 *
 * Handles: tab navigation, conditional fields, WP Media Library integration,
 * drag & drop photo sorting, shortcode copy, delete confirmation, photos JSON sync.
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

(function($) {
	'use strict';

	/* ══════════════════════════════════════════
	   Tab Navigation
	   ══════════════════════════════════════════ */

	function initTabs() {
		var $links = $('.mvweb-nav .mvweb-nav__link');
		var $contents = $('.mvweb-tab-content');

		if (!$links.length || !$contents.length) {
			return;
		}

		function applyTab(tabId) {
			$links.removeClass('mvweb-nav__link--active');
			$links.filter('[data-tab="' + tabId + '"]').addClass('mvweb-nav__link--active');

			$contents.removeClass('active');
			$('#' + tabId).addClass('active');
		}

		$links.on('click', function(e) {
			e.preventDefault();

			var $this = $(this);
			var tabId = $this.data('tab') || ($this.attr('href') || '').replace('#', '');
			if (!tabId) {
				return;
			}

			applyTab(tabId);

			if (history.pushState) {
				history.pushState(null, null, '#' + tabId);
			}
		});

		// Activate tab from URL hash.
		var hash = window.location.hash.substring(1);
		if (hash && $('#' + hash).length) {
			applyTab(hash);
		}
	}

	/* ══════════════════════════════════════════
	   FAQ Accordion (single-open)
	   ══════════════════════════════════════════ */

	function initFaqAccordion() {
		$('.mvweb-block').each(function() {
			var $details = $(this).find('details.mvweb-faq');
			if ($details.length < 2) {
				return;
			}

			$details.on('toggle', function() {
				var self = this;
				if (self.open) {
					$details.each(function() {
						if (this !== self) {
							this.open = false;
						}
					});
				}
			});
		});
	}

	/* ══════════════════════════════════════════
	   Conditional Fields (layout-based visibility)
	   ══════════════════════════════════════════ */

	function initConditionalFields() {
		var $layoutSelect = $('[data-gw-layout-select]');
		if (!$layoutSelect.length) {
			return;
		}

		function updateVisibility() {
			var currentLayout = $layoutSelect.val();

			$('[data-gw-show-if]').each(function() {
				var $el = $(this);
				var allowedLayouts = $el.data('gw-show-if').split(',');

				allowedLayouts = $.map(allowedLayouts, function(v) {
					return $.trim(v);
				});

				if (allowedLayouts.indexOf(currentLayout) !== -1) {
					$el.show();
				} else {
					$el.hide();
				}
			});
		}

		$layoutSelect.on('change', updateVisibility);
		updateVisibility();
	}

	/* ══════════════════════════════════════════
	   Toggle Switch
	   ══════════════════════════════════════════ */

	function initToggles() {
		$(document).on('click', '.mvweb-toggle', function() {
			$(this).toggleClass('active');
		});
	}

	/* ══════════════════════════════════════════
	   Aspect Ratio Custom Field Toggle
	   ══════════════════════════════════════════ */

	function initAspectRatioToggle() {
		var $select = $('#mvweb_gw_aspect_ratio');
		var $custom = $('.mvweb-gw-aspect-custom-field');

		if (!$select.length) {
			return;
		}

		function toggle() {
			if ($select.val() === 'custom') {
				$custom.show();
			} else {
				$custom.hide();
			}
		}

		$select.on('change', toggle);
		toggle();
	}

	/* ══════════════════════════════════════════
	   Ticker Aspect Ratio Preset / Custom Toggle
	   ══════════════════════════════════════════ */

	function initTickerRatioToggle() {
		var $preset = $('#mvweb_gw_ticker_ratio_preset');
		var $custom = $('#mvweb_gw_ticker_ratio');

		if (!$preset.length) {
			return;
		}

		$preset.on('change', function () {
			if ($preset.val() === 'custom') {
				$custom.show().focus();
			} else {
				$custom.hide().val($preset.val());
			}
		});
	}

	/* ══════════════════════════════════════════
	   Controls Appearance Presets
	   ══════════════════════════════════════════ */

	function initAppearancePresets() {
		// Each Material scheme: light neutral normal state, pastel active state.
		// [bg, text, border, active_bg, active_text, active_border]
		var schemes = {
			'teal':        ['#fafafa', '#004d40', '#e0f2f1', '#b2dfdb', '#004d40', '#80cbc4'],
			'indigo':      ['#fafafa', '#1a237e', '#e8eaf6', '#c5cae9', '#1a237e', '#9fa8da'],
			'blue':        ['#fafafa', '#0d47a1', '#e3f2fd', '#bbdefb', '#0d47a1', '#90caf9'],
			'green':       ['#fafafa', '#1b5e20', '#e8f5e9', '#c8e6c9', '#1b5e20', '#a5d6a7'],
			'amber':       ['#fafafa', '#ff6f00', '#fff8e1', '#ffecb3', '#ff6f00', '#ffe082'],
			'deep-orange': ['#fafafa', '#bf360c', '#fbe9e7', '#ffccbc', '#bf360c', '#ffab91'],
			'pink':        ['#fafafa', '#880e4f', '#fce4ec', '#f8bbd0', '#880e4f', '#f48fb1'],
			'blue-grey':   ['#fafafa', '#263238', '#eceff1', '#cfd8dc', '#263238', '#b0bec5']
		};

		$('[data-gw-preset]').on('click', function () {
			var s = schemes[$(this).data('gw-preset')];
			if (!s) {
				return;
			}
			$('[name="ui_bg"]').val(s[0]);
			$('[name="ui_text"]').val(s[1]);
			$('[name="ui_border"]').val(s[2]);
			$('[name="ui_active_bg"]').val(s[3]);
			$('[name="ui_active_text"]').val(s[4]);
			$('[name="ui_active_border"]').val(s[5]);
			$('[name="ui_radius"]').val(0);
			$('[name="ui_border_width"]').val(1);

			$('[data-gw-preset]').removeClass('is-active');
			$(this).addClass('is-active');
		});
	}

	/* ══════════════════════════════════════════
	   Clipboard Copy (Shortcode)
	   ══════════════════════════════════════════ */

	/**
	 * Decode HTML entities safely using DOMParser.
	 *
	 * @param {string} str Encoded HTML string.
	 * @return {string} Decoded plain text.
	 */
	function decodeEntities(str) {
		var doc = new DOMParser().parseFromString(str, 'text/html');
		return doc.documentElement.textContent;
	}

	function initCopyButtons() {
		$(document).on('click', '.mvweb-gw-copy-btn', function(e) {
			e.preventDefault();
			var $btn = $(this);
			var text = decodeEntities($btn.data('copy'));

			if (navigator.clipboard && navigator.clipboard.writeText) {
				navigator.clipboard.writeText(text).then(function() {
					showCopyFeedback($btn);
				});
			} else {
				// Fallback for older browsers.
				var temp = document.createElement('textarea');
				temp.value = text;
				temp.style.position = 'fixed';
				temp.style.opacity = '0';
				document.body.appendChild(temp);
				temp.select();
				document.execCommand('copy');
				document.body.removeChild(temp);
				showCopyFeedback($btn);
			}
		});
	}

	function showCopyFeedback($btn) {
		var $icon = $btn.find('.dashicons');
		if ($icon.length) {
			$icon.removeClass('dashicons-clipboard').addClass('dashicons-yes');
			setTimeout(function() {
				$icon.removeClass('dashicons-yes').addClass('dashicons-clipboard');
			}, 1500);
		}
	}

	/* ══════════════════════════════════════════
	   Delete Confirmation
	   ══════════════════════════════════════════ */

	function initDeleteConfirmation() {
		$(document).on('submit', '.mvweb-gw-delete-form', function(e) {
			if (!confirm(mvwebGwAdmin.confirmDelete)) {
				e.preventDefault();
			}
		});
	}

	/* ══════════════════════════════════════════
	   WP Media Library Integration
	   ══════════════════════════════════════════ */

	var mediaFrame;

	function initMediaUploader() {
		var $addBtn = $('#mvweb-gw-add-photos');
		if (!$addBtn.length) {
			return;
		}

		$addBtn.on('click', function(e) {
			e.preventDefault();

			if (mediaFrame) {
				mediaFrame.open();
				return;
			}

			mediaFrame = wp.media({
				title: mvwebGwAdmin.mediaTitle,
				button: { text: mvwebGwAdmin.mediaButton },
				multiple: true,
				library: { type: 'image' }
			});

			mediaFrame.on('select', function() {
				var attachments = mediaFrame.state().get('selection').toJSON();

				$.each(attachments, function(i, attachment) {
					addPhotoItem(attachment);
					registerPreviewPhoto(attachment);
				});

				syncPhotosJson();
				updatePhotoCount();
				schedulePreviewUpdate();
			});

			mediaFrame.open();
		});
	}

	/* ══════════════════════════════════════════
	   Photo Items Management
	   ══════════════════════════════════════════ */

	function addPhotoItem(attachment) {
		var $list = $('#mvweb-gw-photo-list');

		// Remove empty message if present.
		$list.find('.mvweb-gw-photo-list__empty').remove();

		var thumbUrl = '';
		if (attachment.sizes && attachment.sizes.thumbnail) {
			thumbUrl = attachment.sizes.thumbnail.url;
		} else if (attachment.sizes && attachment.sizes.medium) {
			thumbUrl = attachment.sizes.medium.url;
		} else {
			thumbUrl = attachment.url;
		}

		var width  = attachment.width || 0;
		var height = attachment.height || 0;
		var title  = attachment.title || '';

		// Build photo item DOM safely using jQuery.
		var $item = $('<div>', { 'class': 'mvweb-gw-photo-item', 'data-index': $list.children('.mvweb-gw-photo-item').length });

		// Handle.
		$item.append(
			$('<div>', { 'class': 'mvweb-gw-photo-item__handle' }).append(
				$('<span>', { 'class': 'dashicons dashicons-move' })
			)
		);

		// Thumbnail.
		$item.append(
			$('<div>', { 'class': 'mvweb-gw-photo-item__thumb' }).append(
				$('<img>', { src: thumbUrl, alt: '', width: 80, height: 80 })
			)
		);

		// Fields container.
		var $fields = $('<div>', { 'class': 'mvweb-gw-photo-item__fields' });

		// Hidden fields.
		$fields.append($('<input>', { type: 'hidden', 'class': 'mvweb-gw-photo-field', 'data-field': 'attachment_id', value: attachment.id }));
		$fields.append($('<input>', { type: 'hidden', 'class': 'mvweb-gw-photo-field', 'data-field': 'width', value: width }));
		$fields.append($('<input>', { type: 'hidden', 'class': 'mvweb-gw-photo-field', 'data-field': 'height', value: height }));

		// Row 1: title + caption.
		var $row1 = $('<div>', { 'class': 'mvweb-gw-photo-item__field-row' });
		$row1.append($('<input>', { type: 'text', 'class': 'mvweb-gw-photo-field', 'data-field': 'title', value: title, placeholder: mvwebGwAdmin.phTitle }));
		$row1.append($('<input>', { type: 'text', 'class': 'mvweb-gw-photo-field', 'data-field': 'caption', value: '', placeholder: mvwebGwAdmin.phCaption }));
		$fields.append($row1);

		// Row 2: link + tags.
		var $row2 = $('<div>', { 'class': 'mvweb-gw-photo-item__field-row' });
		$row2.append($('<input>', { type: 'url', 'class': 'mvweb-gw-photo-field', 'data-field': 'link', value: '', placeholder: mvwebGwAdmin.phLink }));
		$row2.append($('<input>', { type: 'text', 'class': 'mvweb-gw-photo-field', 'data-field': 'tags', value: '', placeholder: mvwebGwAdmin.phTags }));
		$fields.append($row2);

		$item.append($fields);

		// Actions.
		var $actions = $('<div>', { 'class': 'mvweb-gw-photo-item__actions' });
		var $removeBtn = $('<button>', {
			type: 'button',
			'class': 'mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-gw-remove-photo',
			title: mvwebGwAdmin.removePhoto
		});
		$removeBtn.append($('<span>', { 'class': 'dashicons dashicons-trash' }));
		$actions.append($removeBtn);
		$item.append($actions);

		$list.append($item);
	}

	function initRemovePhoto() {
		$(document).on('click', '.mvweb-gw-remove-photo', function() {
			var $item = $(this).closest('.mvweb-gw-photo-item');
			$item.fadeOut(200, function() {
				$item.remove();
				syncPhotosJson();
				updatePhotoCount();
				schedulePreviewUpdate();

				// Show empty message if no photos.
				if ($('#mvweb-gw-photo-list .mvweb-gw-photo-item').length === 0) {
					var $emptyMsg = $('<div>', { 'class': 'mvweb-gw-photo-list__empty' });
					$emptyMsg.append($('<p>').text(mvwebGwAdmin.noPhotos));
					$('#mvweb-gw-photo-list').append($emptyMsg);
				}
			});
		});
	}

	function updatePhotoCount() {
		var count = $('#mvweb-gw-photo-list .mvweb-gw-photo-item').length;
		$('.mvweb-gw-photo-count').text(count + ' ' + mvwebGwAdmin.photosLabel);
	}

	/* ══════════════════════════════════════════
	   Drag & Drop Sorting (jQuery UI Sortable)
	   ══════════════════════════════════════════ */

	function initSortable() {
		var $list = $('#mvweb-gw-photo-list');
		if (!$list.length) {
			return;
		}

		$list.sortable({
			handle: '.mvweb-gw-photo-item__handle',
			items: '.mvweb-gw-photo-item',
			placeholder: 'mvweb-gw-photo-item--placeholder',
			tolerance: 'pointer',
			cursor: 'grabbing',
			update: function() {
				syncPhotosJson();
				schedulePreviewUpdate();
			}
		});
	}

	/* ══════════════════════════════════════════
	   Photos JSON Sync
	   ══════════════════════════════════════════ */

	function syncPhotosJson() {
		var photos = [];
		var $items = $('#mvweb-gw-photo-list .mvweb-gw-photo-item');

		$items.each(function(index) {
			var $item = $(this);
			var tagsRaw = $item.find('[data-field="tags"]').val() || '';
			var tags = tagsRaw.split(',').map(function(t) {
				return $.trim(t);
			}).filter(function(t) {
				return t.length > 0;
			});

			photos.push({
				attachment_id: parseInt($item.find('[data-field="attachment_id"]').val(), 10) || 0,
				width: parseInt($item.find('[data-field="width"]').val(), 10) || 0,
				height: parseInt($item.find('[data-field="height"]').val(), 10) || 0,
				link: $item.find('[data-field="link"]').val() || '',
				title: $item.find('[data-field="title"]').val() || '',
				caption: $item.find('[data-field="caption"]').val() || '',
				tags: tags,
				order: index
			});
		});

		$('#mvweb-gw-photos-json').val(JSON.stringify(photos));
	}

	/* ══════════════════════════════════════════
	   Sync Photos JSON on field change
	   ══════════════════════════════════════════ */

	function initFieldSync() {
		$(document).on('change input', '.mvweb-gw-photo-field', function() {
			syncPhotosJson();
		});
	}

	/* ══════════════════════════════════════════
	   Form Submit — sync photos before submission
	   ══════════════════════════════════════════ */

	function initFormSubmit() {
		$('#mvweb-gw-editor-form').on('submit', function() {
			syncPhotosJson();
		});
	}

	/* ══════════════════════════════════════════
	   Live Preview
	   ══════════════════════════════════════════ */

	var previewTimer = null;

	/**
	 * Map of attachment IDs to preview URLs.
	 * Populated from server data and updated when new photos are added.
	 *
	 * @type {Object.<number, {url: string, width: number, height: number}>}
	 */
	var previewPhotoMap = {};

	/**
	 * Initialize preview photo map from server-rendered data.
	 */
	function initPreviewMap() {
		if (mvwebGwAdmin.previewPhotos && mvwebGwAdmin.previewPhotos.length) {
			$.each(mvwebGwAdmin.previewPhotos, function(i, photo) {
				previewPhotoMap[photo.attachment_id] = {
					url: photo.url,
					width: photo.width,
					height: photo.height
				};
			});
		}
	}

	/**
	 * Read current editor settings from the form fields.
	 *
	 * @return {Object} Current settings for preview rendering.
	 */
	function getPreviewSettings() {
		return {
			layout:          $('[data-gw-layout-select]').val() || 'grid',
			columns:         parseInt($('#mvweb_gw_columns_desktop').val(), 10) || 4,
			gap:             parseInt($('#mvweb_gw_gap').val(), 10) || 8,
			radius:          parseInt($('#mvweb_gw_radius').val(), 10) || 0,
			aspectRatio:     $('#mvweb_gw_aspect_ratio').val() || 'auto',
			aspectCustom:    $('#mvweb_gw_aspect_custom').val() || '',
			objectFit:       $('#mvweb_gw_object_fit').val() || 'cover',
			rowHeight:       parseInt($('#mvweb_gw_row_height').val(), 10) || 240,
			tickerSpeed:     parseInt($('#mvweb_gw_ticker_speed').val(), 10) || 30,
			tickerDirection: $('#mvweb_gw_ticker_direction').val() || 'left',
			tickerWidth:     parseInt($('#mvweb_gw_ticker_width').val(), 10) || 200,
			tickerRatio:     $('#mvweb_gw_ticker_ratio').val() || '16/9'
		};
	}

	/**
	 * Collect current photo data from the editor DOM.
	 *
	 * @return {Array} Array of photo objects with url, width, height.
	 */
	function getPreviewPhotos() {
		var photos = [];
		$('#mvweb-gw-photo-list .mvweb-gw-photo-item').each(function() {
			var $item = $(this);
			var aid   = parseInt($item.find('[data-field="attachment_id"]').val(), 10) || 0;
			var w     = parseInt($item.find('[data-field="width"]').val(), 10) || 0;
			var h     = parseInt($item.find('[data-field="height"]').val(), 10) || 0;

			// Get URL from previewPhotoMap or from the thumbnail in the editor.
			var url = '';
			if (previewPhotoMap[aid]) {
				url = previewPhotoMap[aid].url;
			} else {
				var $img = $item.find('.mvweb-gw-photo-item__thumb img');
				if ($img.length) {
					url = $img.attr('src');
				}
			}

			if (url && aid > 0) {
				photos.push({
					url: url,
					width: w || 800,
					height: h || 600
				});
			}
		});
		return photos;
	}

	/**
	 * Schedule a preview update with debounce.
	 */
	function schedulePreviewUpdate() {
		if (previewTimer) {
			clearTimeout(previewTimer);
		}
		previewTimer = setTimeout(renderPreview, 500);
	}

	/**
	 * Render the live preview based on current settings and photos.
	 */
	function renderPreview() {
		var $container = $('#mvweb-gw-preview');
		if (!$container.length) {
			return;
		}

		var photos   = getPreviewPhotos();
		var settings = getPreviewSettings();

		// Show empty state if no photos.
		if (!photos.length) {
			$container.html(
				'<div class="mvweb-gw-preview__empty"><p>' +
				(mvwebGwAdmin.noPhotos || 'No photos.') +
				'</p></div>'
			);
			return;
		}

		var html = '';

		if (settings.layout === 'ticker') {
			html = renderTickerPreview(photos, settings);
		} else {
			html = renderGridPreview(photos, settings);
		}

		$container.html(html);

		// After DOM insertion, apply JS layouts for masonry/justified.
		if (settings.layout === 'masonry') {
			applyMasonryPreview($container, photos, settings);
		} else if (settings.layout === 'justified') {
			applyJustifiedPreview($container, photos, settings);
		}
	}

	/**
	 * Render grid/masonry/justified preview HTML.
	 *
	 * @param {Array}  photos   Photo data array.
	 * @param {Object} settings Current settings.
	 * @return {string} HTML string.
	 */
	function renderGridPreview(photos, settings) {
		var cssVars = buildCssVars(settings);
		var classes = 'mvweb-gw mvweb-gw--' + settings.layout + ' mvweb-gw-preview__gallery';

		var html = '<div class="' + classes + '" style="' + cssVars + '">';
		html += '<div class="mvweb-gw__grid" role="list">';

		$.each(photos, function(i, photo) {
			var dimAttrs = '';
			if (photo.width && photo.height) {
				dimAttrs = ' data-width="' + photo.width + '" data-height="' + photo.height + '"';
			}
			html += '<div class="mvweb-gw__item" role="listitem"' + dimAttrs + '>';
			html += '<img src="' + escHtml(photo.url) + '" alt="" loading="lazy"';
			if (photo.width) { html += ' width="' + photo.width + '"'; }
			if (photo.height) { html += ' height="' + photo.height + '"'; }
			html += '>';
			html += '</div>';
		});

		html += '</div></div>';
		return html;
	}

	/**
	 * Render ticker preview HTML.
	 *
	 * @param {Array}  photos   Photo data array.
	 * @param {Object} settings Current settings.
	 * @return {string} HTML string.
	 */
	function renderTickerPreview(photos, settings) {
		var dir       = settings.tickerDirection;
		var classes   = 'mvweb-gw mvweb-gw--ticker mvweb-gw--dir-' + dir + ' mvweb-gw--pausable mvweb-gw-preview__gallery';
		var isVert    = (dir === 'up' || dir === 'down');
		var tickerW   = settings.tickerWidth || 200;
		var tickerR   = settings.tickerRatio || '16/9';

		var style = '--mvweb-gw-ticker-speed: ' + settings.tickerSpeed + 's';
		style += '; --mvweb-gw-ticker-width: ' + tickerW + 'px';
		style += '; --mvweb-gw-ticker-ratio: ' + tickerR;
		if (isVert) {
			style += '; height: 300px';
		}

		var html = '<div class="' + classes + '" style="' + style + '">';
		html += '<div class="mvweb-gw__track">';

		// Render slides twice for seamless loop.
		for (var dup = 0; dup < 2; dup++) {
			$.each(photos, function(i, photo) {
				var ariaHidden = dup > 0 ? ' aria-hidden="true"' : '';
				html += '<div class="mvweb-gw__slide"' + ariaHidden + '>';
				html += '<img src="' + escHtml(photo.url) + '" alt="" loading="lazy">';
				html += '</div>';
			});
		}

		html += '</div></div>';
		return html;
	}

	/**
	 * Build CSS variables string from settings.
	 *
	 * @param {Object} settings Current settings.
	 * @return {string} CSS variables inline style.
	 */
	function buildCssVars(settings) {
		var vars = [];
		vars.push('--mvweb-gw-columns: ' + settings.columns);
		vars.push('--mvweb-gw-gap: ' + settings.gap + 'px');
		vars.push('--mvweb-gw-radius: ' + settings.radius + 'px');
		vars.push('--mvweb-gw-max-width: 100%');
		vars.push('--mvweb-gw-object-fit: ' + settings.objectFit);

		// Aspect ratio.
		var aspect = settings.aspectRatio;
		if (aspect === 'custom' && settings.aspectCustom) {
			vars.push('--mvweb-gw-aspect-ratio: ' + settings.aspectCustom);
		} else if (aspect !== 'auto' && aspect !== 'custom') {
			vars.push('--mvweb-gw-aspect-ratio: ' + aspect.replace(':', '/'));
		}

		return vars.join('; ');
	}

	/**
	 * Apply masonry positioning to preview items via JS.
	 *
	 * @param {jQuery}  $container Preview container.
	 * @param {Array}   photos     Photo data.
	 * @param {Object}  settings   Current settings.
	 */
	function applyMasonryPreview($container, photos, settings) {
		var $grid  = $container.find('.mvweb-gw__grid');
		var $items = $grid.find('.mvweb-gw__item');

		if (!$items.length) {
			return;
		}

		var cols       = Math.max(1, settings.columns);
		var gap        = settings.gap;
		var gridWidth  = $grid.width();
		var colWidth   = (gridWidth - (cols - 1) * gap) / cols;
		var colHeights = [];

		for (var c = 0; c < cols; c++) {
			colHeights.push(0);
		}

		$grid.css('position', 'relative');

		$items.each(function(i) {
			var $item  = $(this);
			var w = photos[i] ? photos[i].width : 800;
			var h = photos[i] ? photos[i].height : 600;
			var ratio  = (w && h) ? (h / w) : 0.75;
			var itemH  = colWidth * ratio;

			// Find shortest column.
			var minH   = Math.min.apply(null, colHeights);
			var minCol = colHeights.indexOf(minH);

			$item.css({
				position: 'absolute',
				left: minCol * (colWidth + gap) + 'px',
				top: colHeights[minCol] + 'px',
				width: colWidth + 'px'
			});

			$item.find('img').css({
				width: '100%',
				height: 'auto',
				display: 'block'
			});

			colHeights[minCol] += itemH + gap;
		});

		// Set container height.
		var maxH = Math.max.apply(null, colHeights);
		$grid.css('height', maxH + 'px');

		// Add masonry class to disable default grid.
		$grid.addClass('mvweb-gw--js-masonry');
	}

	/**
	 * Apply justified layout to preview items via JS.
	 *
	 * @param {jQuery}  $container Preview container.
	 * @param {Array}   photos     Photo data.
	 * @param {Object}  settings   Current settings.
	 */
	function applyJustifiedPreview($container, photos, settings) {
		var $grid  = $container.find('.mvweb-gw__grid');
		var $items = $grid.find('.mvweb-gw__item');

		if (!$items.length) {
			return;
		}

		var targetH   = settings.rowHeight || 240;
		var gap       = settings.gap;
		var gridWidth = $grid.width();

		$grid.css({
			display: 'flex',
			flexWrap: 'wrap',
			gap: gap + 'px'
		});

		// Calculate rows.
		var rows       = [];
		var currentRow = [];
		var currentW   = 0;

		$items.each(function(i) {
			var w = photos[i] ? photos[i].width : 800;
			var h = photos[i] ? photos[i].height : 600;
			var ratio    = (w && h) ? (w / h) : 1.333;
			var itemW    = targetH * ratio;
			var gapTotal = currentRow.length * gap;

			currentRow.push({ $el: $(this), ratio: ratio, w: itemW });
			currentW += itemW;

			if (currentW + gapTotal >= gridWidth && currentRow.length > 0) {
				rows.push(currentRow);
				currentRow = [];
				currentW   = 0;
			}
		});

		// Last row.
		if (currentRow.length) {
			rows.push(currentRow);
		}

		$.each(rows, function(rowIdx, row) {
			var isLast  = (rowIdx === rows.length - 1);
			var gapSum  = (row.length - 1) * gap;
			var totalR  = 0;
			$.each(row, function(j, item) {
				totalR += item.ratio;
			});

			var rowH;
			if (isLast && rows.length > 1) {
				rowH = targetH;
			} else {
				rowH = (gridWidth - gapSum) / totalR;
			}

			$.each(row, function(j, item) {
				var flexBasis = rowH * item.ratio;
				item.$el.css({
					flexBasis: flexBasis + 'px',
					flexGrow: isLast ? 0 : 1,
					flexShrink: 1,
					height: rowH + 'px',
					overflow: 'hidden'
				});
				item.$el.find('img').css({
					width: '100%',
					height: '100%',
					objectFit: 'cover',
					display: 'block'
				});
			});
		});
	}

	/**
	 * Escape string for safe HTML insertion.
	 *
	 * @param {string} str Raw string.
	 * @return {string} Escaped string.
	 */
	function escHtml(str) {
		if (!str) { return ''; }
		var div = document.createElement('div');
		div.appendChild(document.createTextNode(str));
		return div.innerHTML;
	}

	/**
	 * Initialize live preview: bind change events and render initial state.
	 */
	function initLivePreview() {
		var $preview = $('#mvweb-gw-preview');
		if (!$preview.length) {
			return;
		}

		initPreviewMap();

		// Settings fields that trigger preview update.
		var settingsFields = [
			'[data-gw-layout-select]',
			'#mvweb_gw_columns_desktop',
			'#mvweb_gw_gap',
			'#mvweb_gw_radius',
			'#mvweb_gw_aspect_ratio',
			'#mvweb_gw_aspect_custom',
			'#mvweb_gw_object_fit',
			'#mvweb_gw_row_height',
			'#mvweb_gw_ticker_speed',
			'#mvweb_gw_ticker_direction',
			'#mvweb_gw_ticker_width',
			'#mvweb_gw_ticker_ratio'
		].join(', ');

		$(document).on('change input', settingsFields, schedulePreviewUpdate);

		// Initial render.
		renderPreview();
	}

	/**
	 * Store thumbnail URL from newly added photos in the preview map.
	 *
	 * @param {Object} attachment WP Media attachment object.
	 */
	function registerPreviewPhoto(attachment) {
		var url = '';
		if (attachment.sizes && attachment.sizes.medium) {
			url = attachment.sizes.medium.url;
		} else if (attachment.sizes && attachment.sizes.thumbnail) {
			url = attachment.sizes.thumbnail.url;
		} else {
			url = attachment.url;
		}
		previewPhotoMap[attachment.id] = {
			url: url,
			width: attachment.width || 0,
			height: attachment.height || 0
		};
	}

	/* ══════════════════════════════════════════
	   Document Ready
	   ══════════════════════════════════════════ */

	$(function() {
		// Core.
		initTabs();
		initFaqAccordion();
		initConditionalFields();
		initToggles();

		// Editor-specific.
		initAspectRatioToggle();
		initTickerRatioToggle();
		initAppearancePresets();
		initCopyButtons();
		initDeleteConfirmation();
		initMediaUploader();
		initRemovePhoto();
		initFieldSync();
		initSortable();
		initFormSubmit();

		// Live preview.
		initLivePreview();
	});

})(jQuery);
