<?php
/**
 * Settings tab template — global defaults for new collections.
 *
 * Uses MVweb Admin UI Kit (.mvweb-block / .mvweb-form-row).
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$settings = MVweb_GW_Settings::get();
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Layout', 'mvweb-gallery-wall' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'These settings are used as defaults when creating new collections. Each collection can override them individually.', 'mvweb-gallery-wall' ); ?></p>

	<div class="mvweb-form-row">
		<label for="mvweb_gw_default_layout" class="mvweb-form-row__label"><?php esc_html_e( 'Default Layout', 'mvweb-gallery-wall' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_gw_default_layout" name="default_layout" class="mvweb-select" data-gw-layout-select>
				<option value="grid" <?php selected( $settings['default_layout'], 'grid' ); ?>><?php esc_html_e( 'Grid', 'mvweb-gallery-wall' ); ?></option>
				<option value="masonry" <?php selected( $settings['default_layout'], 'masonry' ); ?>><?php esc_html_e( 'Masonry', 'mvweb-gallery-wall' ); ?></option>
				<option value="justified" <?php selected( $settings['default_layout'], 'justified' ); ?>><?php esc_html_e( 'Justified', 'mvweb-gallery-wall' ); ?></option>
				<option value="ticker" <?php selected( $settings['default_layout'], 'ticker' ); ?>><?php esc_html_e( 'Ticker', 'mvweb-gallery-wall' ); ?></option>
			</select>
		</div>
	</div>
</div>

<div data-gw-show-if="grid,masonry,justified">
	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Grid Settings', 'mvweb-gallery-wall' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_columns_desktop" class="mvweb-form-row__label"><?php esc_html_e( 'Columns (Desktop)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_columns_desktop" name="default_columns_desktop"
					   value="<?php echo esc_attr( $settings['default_columns_desktop'] ); ?>"
					   min="1" max="8" step="1" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_columns_tablet" class="mvweb-form-row__label"><?php esc_html_e( 'Columns (Tablet)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_columns_tablet" name="default_columns_tablet"
					   value="<?php echo esc_attr( $settings['default_columns_tablet'] ); ?>"
					   min="1" max="6" step="1" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_columns_mobile" class="mvweb-form-row__label"><?php esc_html_e( 'Columns (Mobile)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_columns_mobile" name="default_columns_mobile"
					   value="<?php echo esc_attr( $settings['default_columns_mobile'] ); ?>"
					   min="1" max="4" step="1" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_gap" class="mvweb-form-row__label"><?php esc_html_e( 'Gap (px)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_gap" name="default_gap"
					   value="<?php echo esc_attr( $settings['default_gap'] ); ?>"
					   min="0" max="100" step="1" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_radius" class="mvweb-form-row__label"><?php esc_html_e( 'Border Radius (px)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_radius" name="default_radius"
					   value="<?php echo esc_attr( $settings['default_radius'] ); ?>"
					   min="0" max="100" step="1" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_aspect_ratio" class="mvweb-form-row__label"><?php esc_html_e( 'Aspect Ratio', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_gw_aspect_ratio" name="default_aspect_ratio" class="mvweb-select">
					<option value="1:1" <?php selected( $settings['default_aspect_ratio'], '1:1' ); ?>>1:1</option>
					<option value="4:3" <?php selected( $settings['default_aspect_ratio'], '4:3' ); ?>>4:3</option>
					<option value="16:9" <?php selected( $settings['default_aspect_ratio'], '16:9' ); ?>>16:9</option>
					<option value="3:2" <?php selected( $settings['default_aspect_ratio'], '3:2' ); ?>>3:2</option>
					<option value="auto" <?php selected( $settings['default_aspect_ratio'], 'auto' ); ?>><?php esc_html_e( 'Auto', 'mvweb-gallery-wall' ); ?></option>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_object_fit" class="mvweb-form-row__label"><?php esc_html_e( 'Object Fit', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_gw_object_fit" name="default_object_fit" class="mvweb-select">
					<option value="cover" <?php selected( $settings['default_object_fit'], 'cover' ); ?>><?php esc_html_e( 'Cover', 'mvweb-gallery-wall' ); ?></option>
					<option value="contain" <?php selected( $settings['default_object_fit'], 'contain' ); ?>><?php esc_html_e( 'Contain', 'mvweb-gallery-wall' ); ?></option>
					<option value="fill" <?php selected( $settings['default_object_fit'], 'fill' ); ?>><?php esc_html_e( 'Fill', 'mvweb-gallery-wall' ); ?></option>
					<option value="none" <?php selected( $settings['default_object_fit'], 'none' ); ?>><?php esc_html_e( 'None', 'mvweb-gallery-wall' ); ?></option>
					<option value="scale-down" <?php selected( $settings['default_object_fit'], 'scale-down' ); ?>><?php esc_html_e( 'Scale Down', 'mvweb-gallery-wall' ); ?></option>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_max_width" class="mvweb-form-row__label"><?php esc_html_e( 'Max Width', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb_gw_max_width" name="default_max_width"
					   value="<?php echo esc_attr( $settings['default_max_width'] ); ?>"
					   class="mvweb-input" placeholder="100%, 1200px">
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'e.g. 100%, 1200px, 80rem', 'mvweb-gallery-wall' ); ?></p>
			</div>
		</div>

		<div data-gw-show-if="justified">
			<div class="mvweb-form-row">
				<label for="mvweb_gw_row_height" class="mvweb-form-row__label"><?php esc_html_e( 'Row Height (px)', 'mvweb-gallery-wall' ); ?></label>
				<div class="mvweb-form-row__field">
					<input type="number" id="mvweb_gw_row_height" name="default_row_height"
						   value="<?php echo esc_attr( $settings['default_row_height'] ); ?>"
						   min="120" max="400" step="10" class="mvweb-input">
					<p class="mvweb-form-row__desc"><?php esc_html_e( 'Target row height for justified layout (120-400).', 'mvweb-gallery-wall' ); ?></p>
				</div>
			</div>
		</div>
	</div>
</div>

<div data-gw-show-if="ticker">
	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Ticker Settings', 'mvweb-gallery-wall' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_ticker_speed" class="mvweb-form-row__label"><?php esc_html_e( 'Speed (seconds)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_ticker_speed" name="default_ticker_speed"
					   value="<?php echo esc_attr( $settings['default_ticker_speed'] ); ?>"
					   min="1" max="120" step="1" class="mvweb-input">
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Duration of one full scroll cycle.', 'mvweb-gallery-wall' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_ticker_direction" class="mvweb-form-row__label"><?php esc_html_e( 'Direction', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_gw_ticker_direction" name="default_ticker_direction" class="mvweb-select">
					<option value="left" <?php selected( $settings['default_ticker_direction'], 'left' ); ?>><?php esc_html_e( 'Left', 'mvweb-gallery-wall' ); ?></option>
					<option value="right" <?php selected( $settings['default_ticker_direction'], 'right' ); ?>><?php esc_html_e( 'Right', 'mvweb-gallery-wall' ); ?></option>
					<option value="up" <?php selected( $settings['default_ticker_direction'], 'up' ); ?>><?php esc_html_e( 'Up', 'mvweb-gallery-wall' ); ?></option>
					<option value="down" <?php selected( $settings['default_ticker_direction'], 'down' ); ?>><?php esc_html_e( 'Down', 'mvweb-gallery-wall' ); ?></option>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Pause on Hover', 'mvweb-gallery-wall' ); ?></span>
			<div class="mvweb-form-row__field">
				<label class="mvweb-check">
					<input type="checkbox" name="default_ticker_pause" value="1"
						   <?php checked( $settings['default_ticker_pause'] ); ?>>
					<?php esc_html_e( 'Pause scrolling when the user hovers over the gallery', 'mvweb-gallery-wall' ); ?>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_ticker_width" class="mvweb-form-row__label"><?php esc_html_e( 'Photo Width (px)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_ticker_width" name="default_ticker_width"
					   value="<?php echo esc_attr( $settings['default_ticker_width'] ); ?>"
					   min="50" max="800" step="10" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_ticker_ratio" class="mvweb-form-row__label"><?php esc_html_e( 'Photo Aspect Ratio', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb_gw_ticker_ratio" name="default_ticker_ratio"
					   value="<?php echo esc_attr( $settings['default_ticker_ratio'] ); ?>"
					   class="mvweb-input" placeholder="16/9">
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'CSS aspect-ratio value, e.g. 16/9, 4/3, 1/1.', 'mvweb-gallery-wall' ); ?></p>
			</div>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Animation & Effects', 'mvweb-gallery-wall' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_gw_animation" class="mvweb-form-row__label"><?php esc_html_e( 'Entrance Animation', 'mvweb-gallery-wall' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_gw_animation" name="default_animation" class="mvweb-select">
				<option value="fade" <?php selected( $settings['default_animation'], 'fade' ); ?>><?php esc_html_e( 'Fade', 'mvweb-gallery-wall' ); ?></option>
				<option value="slide-up" <?php selected( $settings['default_animation'], 'slide-up' ); ?>><?php esc_html_e( 'Slide Up', 'mvweb-gallery-wall' ); ?></option>
				<option value="slide-left" <?php selected( $settings['default_animation'], 'slide-left' ); ?>><?php esc_html_e( 'Slide Left', 'mvweb-gallery-wall' ); ?></option>
				<option value="scale" <?php selected( $settings['default_animation'], 'scale' ); ?>><?php esc_html_e( 'Scale', 'mvweb-gallery-wall' ); ?></option>
				<option value="flip" <?php selected( $settings['default_animation'], 'flip' ); ?>><?php esc_html_e( 'Flip', 'mvweb-gallery-wall' ); ?></option>
				<option value="none" <?php selected( $settings['default_animation'], 'none' ); ?>><?php esc_html_e( 'None', 'mvweb-gallery-wall' ); ?></option>
			</select>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_gw_hover" class="mvweb-form-row__label"><?php esc_html_e( 'Hover Effect', 'mvweb-gallery-wall' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_gw_hover" name="default_hover" class="mvweb-select">
				<option value="zoom" <?php selected( $settings['default_hover'], 'zoom' ); ?>><?php esc_html_e( 'Zoom', 'mvweb-gallery-wall' ); ?></option>
				<option value="grayscale" <?php selected( $settings['default_hover'], 'grayscale' ); ?>><?php esc_html_e( 'Grayscale', 'mvweb-gallery-wall' ); ?></option>
				<option value="brightness" <?php selected( $settings['default_hover'], 'brightness' ); ?>><?php esc_html_e( 'Brightness', 'mvweb-gallery-wall' ); ?></option>
				<option value="overlay" <?php selected( $settings['default_hover'], 'overlay' ); ?>><?php esc_html_e( 'Overlay', 'mvweb-gallery-wall' ); ?></option>
				<option value="none" <?php selected( $settings['default_hover'], 'none' ); ?>><?php esc_html_e( 'None', 'mvweb-gallery-wall' ); ?></option>
			</select>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Lightbox', 'mvweb-gallery-wall' ); ?></span>
		<div class="mvweb-form-row__field">
			<label class="mvweb-check">
				<input type="checkbox" name="default_lightbox" value="1"
					   <?php checked( $settings['default_lightbox'] ); ?>>
				<?php esc_html_e( 'Enable built-in lightbox for photos without a custom link', 'mvweb-gallery-wall' ); ?>
			</label>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Lazy Loading', 'mvweb-gallery-wall' ); ?></span>
		<div class="mvweb-form-row__field">
			<label class="mvweb-check">
				<input type="checkbox" name="default_lazyload" value="1"
					   <?php checked( $settings['default_lazyload'] ); ?>>
				<?php esc_html_e( 'Load photos lazily as they scroll into view', 'mvweb-gallery-wall' ); ?>
			</label>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'The first row always loads immediately for a fast first paint.', 'mvweb-gallery-wall' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_gw_overlay_mode" class="mvweb-form-row__label"><?php esc_html_e( 'Overlay', 'mvweb-gallery-wall' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_gw_overlay_mode" name="default_overlay_mode" class="mvweb-select">
				<option value="hover" <?php selected( $settings['default_overlay_mode'], 'hover' ); ?>><?php esc_html_e( 'Show on Hover', 'mvweb-gallery-wall' ); ?></option>
				<option value="always" <?php selected( $settings['default_overlay_mode'], 'always' ); ?>><?php esc_html_e( 'Always Visible', 'mvweb-gallery-wall' ); ?></option>
				<option value="none" <?php selected( $settings['default_overlay_mode'], 'none' ); ?>><?php esc_html_e( 'Hidden', 'mvweb-gallery-wall' ); ?></option>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Title and caption overlay on photos.', 'mvweb-gallery-wall' ); ?></p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Controls Appearance', 'mvweb-gallery-wall' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'A single style shared by the tag filter chips and the "Load More" button. Hover styles are derived from the active colors automatically.', 'mvweb-gallery-wall' ); ?></p>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Material Presets', 'mvweb-gallery-wall' ); ?></span>
		<div class="mvweb-form-row__field">
			<?php
			$gw_material_presets = array(
				'teal'        => __( 'Teal', 'mvweb-gallery-wall' ),
				'indigo'      => __( 'Indigo', 'mvweb-gallery-wall' ),
				'blue'        => __( 'Blue', 'mvweb-gallery-wall' ),
				'green'       => __( 'Green', 'mvweb-gallery-wall' ),
				'amber'       => __( 'Amber', 'mvweb-gallery-wall' ),
				'deep-orange' => __( 'Deep Orange', 'mvweb-gallery-wall' ),
				'pink'        => __( 'Pink', 'mvweb-gallery-wall' ),
				'blue-grey'   => __( 'Blue Grey', 'mvweb-gallery-wall' ),
			);
			$gw_preset_swatches = array(
				'teal'        => '#4db6ac',
				'indigo'      => '#7986cb',
				'blue'        => '#64b5f6',
				'green'       => '#81c784',
				'amber'       => '#ffd54f',
				'deep-orange' => '#ff8a65',
				'pink'        => '#f06292',
				'blue-grey'   => '#90a4ae',
			);
			?>
			<div class="mvweb-gw-presets">
				<?php foreach ( $gw_material_presets as $gw_key => $gw_label ) : ?>
					<button type="button" class="mvweb-gw-preset" data-gw-preset="<?php echo esc_attr( $gw_key ); ?>"
							style="--mvweb-gw-preset-color: <?php echo esc_attr( $gw_preset_swatches[ $gw_key ] ); ?>;"
							title="<?php echo esc_attr( $gw_label ); ?>" aria-label="<?php echo esc_attr( $gw_label ); ?>"></button>
				<?php endforeach; ?>
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Pick a color scheme to fill the fields below, then fine-tune and save.', 'mvweb-gallery-wall' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Normal', 'mvweb-gallery-wall' ); ?></span>
		<div class="mvweb-form-row__field">
			<div class="mvweb-gw-colors">
				<label class="mvweb-gw-color"><input type="color" name="ui_bg" value="<?php echo esc_attr( $settings['ui_bg'] ); ?>"><span><?php esc_html_e( 'Background', 'mvweb-gallery-wall' ); ?></span></label>
				<label class="mvweb-gw-color"><input type="color" name="ui_text" value="<?php echo esc_attr( $settings['ui_text'] ); ?>"><span><?php esc_html_e( 'Text', 'mvweb-gallery-wall' ); ?></span></label>
				<label class="mvweb-gw-color"><input type="color" name="ui_border" value="<?php echo esc_attr( $settings['ui_border'] ); ?>"><span><?php esc_html_e( 'Border', 'mvweb-gallery-wall' ); ?></span></label>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Active / Hover', 'mvweb-gallery-wall' ); ?></span>
		<div class="mvweb-form-row__field">
			<div class="mvweb-gw-colors">
				<label class="mvweb-gw-color"><input type="color" name="ui_active_bg" value="<?php echo esc_attr( $settings['ui_active_bg'] ); ?>"><span><?php esc_html_e( 'Background', 'mvweb-gallery-wall' ); ?></span></label>
				<label class="mvweb-gw-color"><input type="color" name="ui_active_text" value="<?php echo esc_attr( $settings['ui_active_text'] ); ?>"><span><?php esc_html_e( 'Text', 'mvweb-gallery-wall' ); ?></span></label>
				<label class="mvweb-gw-color"><input type="color" name="ui_active_border" value="<?php echo esc_attr( $settings['ui_active_border'] ); ?>"><span><?php esc_html_e( 'Border', 'mvweb-gallery-wall' ); ?></span></label>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_gw_ui_radius" class="mvweb-form-row__label"><?php esc_html_e( 'Border Radius (px)', 'mvweb-gallery-wall' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_gw_ui_radius" name="ui_radius"
				   value="<?php echo esc_attr( $settings['ui_radius'] ); ?>"
				   min="0" max="100" step="1" class="mvweb-input">
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_gw_ui_border_width" class="mvweb-form-row__label"><?php esc_html_e( 'Border Width (px)', 'mvweb-gallery-wall' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_gw_ui_border_width" name="ui_border_width"
				   value="<?php echo esc_attr( $settings['ui_border_width'] ); ?>"
				   min="0" max="10" step="1" class="mvweb-input">
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Additional', 'mvweb-gallery-wall' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<span class="mvweb-form-row__label"><?php esc_html_e( 'Show Collection Title', 'mvweb-gallery-wall' ); ?></span>
		<div class="mvweb-form-row__field">
			<label class="mvweb-check">
				<input type="checkbox" name="default_show_title" value="1"
					   <?php checked( $settings['default_show_title'] ); ?>>
				<?php esc_html_e( 'Display the collection title above the gallery', 'mvweb-gallery-wall' ); ?>
			</label>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_gw_per_page" class="mvweb-form-row__label"><?php esc_html_e( 'Photos per Page', 'mvweb-gallery-wall' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="number" id="mvweb_gw_per_page" name="default_per_page"
				   value="<?php echo esc_attr( $settings['default_per_page'] ); ?>"
				   min="0" max="100" step="1" class="mvweb-input">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Number of photos before "Load More" button. 0 = show all.', 'mvweb-gallery-wall' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_gw_load_more_text" class="mvweb-form-row__label"><?php esc_html_e( 'Load More Text', 'mvweb-gallery-wall' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_gw_load_more_text" name="default_load_more_text"
				   value="<?php echo esc_attr( $settings['default_load_more_text'] ); ?>"
				   class="mvweb-input" placeholder="<?php esc_attr_e( 'Show More', 'mvweb-gallery-wall' ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Leave empty to use the default localized label.', 'mvweb-gallery-wall' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_gw_link_target" class="mvweb-form-row__label"><?php esc_html_e( 'Link Target', 'mvweb-gallery-wall' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_gw_link_target" name="default_link_target" class="mvweb-select">
				<option value="_blank" <?php selected( $settings['default_link_target'], '_blank' ); ?>><?php esc_html_e( 'New Window (_blank)', 'mvweb-gallery-wall' ); ?></option>
				<option value="_self" <?php selected( $settings['default_link_target'], '_self' ); ?>><?php esc_html_e( 'Same Window (_self)', 'mvweb-gallery-wall' ); ?></option>
			</select>
		</div>
	</div>
</div>
