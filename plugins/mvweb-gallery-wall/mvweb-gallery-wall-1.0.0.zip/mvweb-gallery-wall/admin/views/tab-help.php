<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick Start', 'mvweb-gallery-wall' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Step 1', 'mvweb-gallery-wall' ); ?></strong>
			<p><?php esc_html_e( 'Go to the Collections tab and click "Add New" to create your first gallery.', 'mvweb-gallery-wall' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Step 2', 'mvweb-gallery-wall' ); ?></strong>
			<p><?php esc_html_e( 'Add photos from the Media Library, configure layout and settings.', 'mvweb-gallery-wall' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Step 3', 'mvweb-gallery-wall' ); ?></strong>
			<p><?php esc_html_e( 'Copy the shortcode and paste it into any page or post.', 'mvweb-gallery-wall' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Layouts', 'mvweb-gallery-wall' ); ?></div>
	</div>
	<ul>
		<li><strong>Grid</strong> &mdash; <?php esc_html_e( 'Uniform grid with equal-sized cells. Configurable columns and aspect ratio.', 'mvweb-gallery-wall' ); ?></li>
		<li><strong>Masonry</strong> &mdash; <?php esc_html_e( 'Equal-width columns with varying heights. Photos displayed in original proportions.', 'mvweb-gallery-wall' ); ?></li>
		<li><strong>Justified</strong> &mdash; <?php esc_html_e( 'Rows of equal height filling the full width. Each row adjusts to fit photos.', 'mvweb-gallery-wall' ); ?></li>
		<li><strong>Ticker</strong> &mdash; <?php esc_html_e( 'Infinite scrolling marquee in 4 directions with pause on hover.', 'mvweb-gallery-wall' ); ?></li>
	</ul>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Inserting a gallery', 'mvweb-gallery-wall' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'To display a collection, only its ID is required. The gallery will use all the settings saved in the collection itself.', 'mvweb-gallery-wall' ); ?></p>

	<p>
		<code>[mvweb_gallery id="5"]</code>
	</p>
	<p class="mvweb-form-row__desc">
		<?php esc_html_e( 'Replace 5 with your collection ID (shown on the Collections tab). This is the usual way to insert a gallery.', 'mvweb-gallery-wall' ); ?>
	</p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Optional parameters', 'mvweb-gallery-wall' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'These parameters are optional. Add them only when you want to override the collection settings for a specific place on the site. Any parameter you omit keeps its collection value.', 'mvweb-gallery-wall' ); ?></p>

	<div class="mvweb-table-wrap">
		<table class="mvweb-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Parameter', 'mvweb-gallery-wall' ); ?></th>
					<th><?php esc_html_e( 'Default', 'mvweb-gallery-wall' ); ?></th>
					<th><?php esc_html_e( 'Description', 'mvweb-gallery-wall' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><code>id</code></td>
					<td>&mdash;</td>
					<td><?php esc_html_e( 'Required. The ID of the collection to display. Found on the Collections tab.', 'mvweb-gallery-wall' ); ?></td>
				</tr>
				<tr>
					<td><code>layout</code></td>
					<td><?php esc_html_e( 'from collection', 'mvweb-gallery-wall' ); ?></td>
					<td><?php esc_html_e( 'How photos are arranged. Overrides the collection setting. Values: grid, masonry, justified, ticker.', 'mvweb-gallery-wall' ); ?></td>
				</tr>
				<tr>
					<td><code>columns</code></td>
					<td><?php esc_html_e( 'from collection', 'mvweb-gallery-wall' ); ?></td>
					<td><?php esc_html_e( 'Number of columns on desktop. Overrides the collection setting.', 'mvweb-gallery-wall' ); ?></td>
				</tr>
				<tr>
					<td><code>limit</code></td>
					<td>0</td>
					<td><?php esc_html_e( 'Maximum number of photos to show. 0 means show all photos in the collection.', 'mvweb-gallery-wall' ); ?></td>
				</tr>
				<tr>
					<td><code>animation</code></td>
					<td><?php esc_html_e( 'from collection', 'mvweb-gallery-wall' ); ?></td>
					<td><?php esc_html_e( 'Entrance animation of photos as they appear. Values: fade, slide-up, slide-left, scale, flip, none.', 'mvweb-gallery-wall' ); ?></td>
				</tr>
				<tr>
					<td><code>hover</code></td>
					<td><?php esc_html_e( 'from collection', 'mvweb-gallery-wall' ); ?></td>
					<td><?php esc_html_e( 'Visual effect when hovering over a photo. Values: zoom, grayscale, brightness, overlay, none.', 'mvweb-gallery-wall' ); ?></td>
				</tr>
				<tr>
					<td><code>gap</code></td>
					<td><?php esc_html_e( 'from collection', 'mvweb-gallery-wall' ); ?></td>
					<td><?php esc_html_e( 'Spacing between photos in pixels. Overrides the collection setting.', 'mvweb-gallery-wall' ); ?></td>
				</tr>
				<tr>
					<td><code>class</code></td>
					<td>&mdash;</td>
					<td><?php esc_html_e( 'Extra CSS class added to the gallery wrapper for custom styling.', 'mvweb-gallery-wall' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>
	<p>
		<?php esc_html_e( 'Example with overrides:', 'mvweb-gallery-wall' ); ?>
		<code>[mvweb_gallery id="5" layout="grid" columns="3" gap="20"]</code>
	</p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Widget', 'mvweb-gallery-wall' ); ?></div>
	</div>
	<p><?php esc_html_e( 'Go to Appearance > Widgets and add the "MVweb Gallery Wall" widget to any sidebar. Select a collection, layout, and number of columns.', 'mvweb-gallery-wall' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Frequently Asked Questions', 'mvweb-gallery-wall' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How do I create a new gallery?', 'mvweb-gallery-wall' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Go to MVweb Hub > Gallery Wall > Collections tab and click "Add New". Add photos from the Media Library, configure your settings, and save.', 'mvweb-gallery-wall' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can I use multiple galleries on one page?', 'mvweb-gallery-wall' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Yes, you can place multiple shortcodes on the same page. Each gallery works independently, including lightbox navigation.', 'mvweb-gallery-wall' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How does the lightbox work?', 'mvweb-gallery-wall' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Photos without a custom link will open in the built-in lightbox. Navigate with arrow keys, swipe on mobile, or use the prev/next buttons. Press Esc or click outside to close.', 'mvweb-gallery-wall' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'What is the Ticker layout?', 'mvweb-gallery-wall' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Ticker creates an infinite scrolling marquee of photos. You can set the direction (left, right, up, down), speed, and enable pause on hover.', 'mvweb-gallery-wall' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-gallery-wall' ); ?></div>
	</div>
	<p>
		<?php
		$url  = 'https://mvweb.ru/plugins/mvweb-gallery-wall';
		$link = '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">mvweb.ru</a>';
		printf(
			/* translators: %s: MVweb plugin URL as link */
			esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-gallery-wall' ),
			wp_kses( $link, array( 'a' => array( 'href' => true, 'target' => true, 'rel' => true ) ) )
		);
		?>
	</p>
	<p>
		<strong><?php esc_html_e( 'Version:', 'mvweb-gallery-wall' ); ?></strong> <?php echo esc_html( MVWEB_GW_VERSION ); ?>
	</p>
</div>
