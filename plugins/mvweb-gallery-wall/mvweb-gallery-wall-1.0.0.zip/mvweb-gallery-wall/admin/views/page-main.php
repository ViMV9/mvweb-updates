<?php
/**
 * Admin main page template.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 *
 * Tabs: Collections, Settings, Help. The Editor is a sub-view of Collections
 * (hidden from the nav) reached via ?tab=editor&collection_id=N.
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'collections'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.
$is_editor   = ( 'editor' === $current_tab );

// Editor renders inside the Collections nav slot.
$active_nav_tab = $is_editor ? 'collections' : $current_tab;

$tabs = array(
	'collections' => array(
		'label' => __( 'Collections', 'mvweb-gallery-wall' ),
		'icon'  => 'grid',
	),
	'settings'    => array(
		'label' => __( 'Settings', 'mvweb-gallery-wall' ),
		'icon'  => 'gear',
	),
	'help'        => array(
		'label' => __( 'Help', 'mvweb-gallery-wall' ),
		'icon'  => 'help',
	),
);

$icons = array(
	'grid' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
	'gear' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
	'help' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">GW</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'Gallery Wall', 'mvweb-gallery-wall' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_GW_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $tabs as $tab_id => $tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $tab_id ); ?>"
						class="mvweb-nav__link <?php echo esc_attr( $active_nav_tab === $tab_id ? 'mvweb-nav__link--active' : '' ); ?>"
						data-tab="<?php echo esc_attr( $tab_id ); ?>">
						<?php echo $icons[ $tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $tab['label'] ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php
		$gw_notices = get_settings_errors( 'mvweb_gw_messages' );
		foreach ( $gw_notices as $gw_notice ) :
			$gw_is_error = ( 'error' === $gw_notice['type'] );
			$gw_variant  = $gw_is_error ? 'error' : 'success';
			?>
			<div class="mvweb-alert mvweb-alert--<?php echo esc_attr( $gw_variant ); ?>">
				<?php if ( $gw_is_error ) : ?>
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
				<?php else : ?>
					<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
				<?php endif; ?>
				<div class="mvweb-alert__body"><?php echo esc_html( $gw_notice['message'] ); ?></div>
			</div>
		<?php endforeach; ?>

		<div id="collections" class="mvweb-tab-content <?php echo ( 'collections' === $active_nav_tab && ! $is_editor ) ? 'active' : ''; ?>">
			<?php require MVWEB_GW_PATH . 'admin/views/tab-collections.php'; ?>
		</div>

		<div id="editor" class="mvweb-tab-content <?php echo $is_editor ? 'active' : ''; ?>">
			<?php require MVWEB_GW_PATH . 'admin/views/tab-editor.php'; ?>
		</div>

		<div id="settings" class="mvweb-tab-content <?php echo 'settings' === $current_tab ? 'active' : ''; ?>">
			<form method="post" action="">
				<?php wp_nonce_field( MVweb_GW_Settings::NONCE_ACTION, MVweb_GW_Settings::NONCE_NAME ); ?>
				<?php require MVWEB_GW_PATH . 'admin/views/tab-settings.php'; ?>
				<div class="mvweb-submit">
					<button type="submit" name="mvweb_gw_save_settings" class="mvweb-btn mvweb-btn--primary">
						<?php esc_html_e( 'Save Settings', 'mvweb-gallery-wall' ); ?>
					</button>
					<span class="mvweb-submit__hint"><kbd>⌘ S</kbd></span>
				</div>
			</form>
		</div>

		<div id="help" class="mvweb-tab-content <?php echo 'help' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_GW_PATH . 'admin/views/tab-help.php'; ?>
		</div>

	</main>
</div>
