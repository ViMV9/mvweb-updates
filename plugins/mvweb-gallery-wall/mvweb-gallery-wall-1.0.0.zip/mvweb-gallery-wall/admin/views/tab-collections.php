<?php
/**
 * Collections tab — list of gallery collections.
 *
 * Displays a table of all gallery collections with actions: edit, clone, delete.
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Show notices.
$gw_success_svg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>';
if ( isset( $_GET['cloned'] ) && '1' === $_GET['cloned'] ) {
	echo '<div class="mvweb-alert mvweb-alert--success">' . $gw_success_svg . '<div class="mvweb-alert__body">' . esc_html__( 'Collection cloned successfully.', 'mvweb-gallery-wall' ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG + escaped text.
}
if ( isset( $_GET['deleted'] ) && '1' === $_GET['deleted'] ) {
	echo '<div class="mvweb-alert mvweb-alert--success">' . $gw_success_svg . '<div class="mvweb-alert__body">' . esc_html__( 'Collection deleted.', 'mvweb-gallery-wall' ) . '</div></div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG + escaped text.
}

// Get all collections.
$collections = get_posts( array(
	'post_type'      => 'mvweb_gallery',
	'post_status'    => array( 'publish', 'draft' ),
	'posts_per_page' => -1,
	'orderby'        => 'date',
	'order'          => 'DESC',
) );

$editor_url = admin_url( 'admin.php?page=mvweb-gallery-wall&tab=editor' );
?>

<div class="mvweb-section-title">
	<h2>
		<?php esc_html_e( 'Collections', 'mvweb-gallery-wall' ); ?>
		<?php if ( ! empty( $collections ) ) : ?>
			<span class="mvweb-section-title__count"><?php echo esc_html( count( $collections ) ); ?></span>
		<?php endif; ?>
	</h2>
	<a href="<?php echo esc_url( $editor_url ); ?>" class="mvweb-btn mvweb-btn--primary">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
		<?php esc_html_e( 'Add New', 'mvweb-gallery-wall' ); ?>
	</a>
</div>

<?php if ( empty( $collections ) ) : ?>
	<div class="mvweb-empty">
		<div class="mvweb-empty__icon">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg>
		</div>
		<h3 class="mvweb-empty__title"><?php esc_html_e( 'No collections yet', 'mvweb-gallery-wall' ); ?></h3>
		<p class="mvweb-empty__text"><?php esc_html_e( 'Create your first gallery collection to get started.', 'mvweb-gallery-wall' ); ?></p>
		<a href="<?php echo esc_url( $editor_url ); ?>" class="mvweb-btn mvweb-btn--primary">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
			<?php esc_html_e( 'Create Collection', 'mvweb-gallery-wall' ); ?>
		</a>
	</div>
<?php else : ?>
	<div class="mvweb-table-wrap">
		<table class="mvweb-table mvweb-gw-collections-table">
			<thead>
				<tr>
					<th class="mvweb-gw-col-preview"><?php esc_html_e( 'Preview', 'mvweb-gallery-wall' ); ?></th>
					<th class="mvweb-gw-col-title"><?php esc_html_e( 'Title', 'mvweb-gallery-wall' ); ?></th>
					<th class="mvweb-gw-col-shortcode"><?php esc_html_e( 'Shortcode', 'mvweb-gallery-wall' ); ?></th>
					<th class="mvweb-gw-col-layout"><?php esc_html_e( 'Layout', 'mvweb-gallery-wall' ); ?></th>
					<th class="mvweb-gw-col-photos"><?php esc_html_e( 'Photos', 'mvweb-gallery-wall' ); ?></th>
					<th class="mvweb-gw-col-date"><?php esc_html_e( 'Date', 'mvweb-gallery-wall' ); ?></th>
					<th class="mvweb-gw-col-actions"><?php esc_html_e( 'Actions', 'mvweb-gallery-wall' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $collections as $collection ) :
					$coll_id  = $collection->ID;
					$photos   = json_decode( get_post_meta( $coll_id, '_mvweb_gw_photos', true ), true );
					$photos   = is_array( $photos ) ? $photos : array();
					$layout   = get_post_meta( $coll_id, '_mvweb_gw_layout', true );
					$layout   = $layout ? $layout : 'grid';
					$edit_url = admin_url( 'admin.php?page=mvweb-gallery-wall&tab=editor&collection_id=' . $coll_id );

					// Layout labels.
					$layout_labels = array(
						'grid'      => __( 'Grid', 'mvweb-gallery-wall' ),
						'masonry'   => __( 'Masonry', 'mvweb-gallery-wall' ),
						'justified' => __( 'Justified', 'mvweb-gallery-wall' ),
						'ticker'    => __( 'Ticker', 'mvweb-gallery-wall' ),
					);
					$layout_label = isset( $layout_labels[ $layout ] ) ? $layout_labels[ $layout ] : ucfirst( $layout );

					// Layout icons.
					$layout_icons = array(
						'grid'      => 'dashicons-grid-view',
						'masonry'   => 'dashicons-columns',
						'justified' => 'dashicons-align-wide',
						'ticker'    => 'dashicons-controls-repeat',
					);
					$layout_icon = isset( $layout_icons[ $layout ] ) ? $layout_icons[ $layout ] : 'dashicons-format-gallery';
				?>
				<tr>
					<td class="mvweb-gw-col-preview">
						<div class="mvweb-gw-preview-thumbs">
							<?php
							$first_thumb = ! empty( $photos ) ? wp_get_attachment_image_url( $photos[0]['attachment_id'], 'thumbnail' ) : '';
							if ( $first_thumb ) :
							?>
								<img src="<?php echo esc_url( $first_thumb ); ?>"
									 alt=""
									 class="mvweb-gw-preview-thumb"
									 width="40" height="40">
							<?php endif; ?>

							<?php
							$remaining = count( $photos ) - 1;
							if ( $remaining > 0 ) :
							?>
								<span class="mvweb-gw-preview-more">+<?php echo esc_html( $remaining ); ?></span>
							<?php endif; ?>
						</div>
					</td>
					<td class="mvweb-gw-col-title">
						<a href="<?php echo esc_url( $edit_url ); ?>" class="mvweb-gw-collection-title">
							<?php echo esc_html( $collection->post_title ); ?>
						</a>
						<?php if ( 'draft' === $collection->post_status ) : ?>
							<span class="mvweb-badge mvweb-badge--warning"><?php esc_html_e( 'Draft', 'mvweb-gallery-wall' ); ?></span>
						<?php endif; ?>
					</td>
					<td class="mvweb-gw-col-shortcode">
						<code class="mvweb-gw-shortcode-code">[mvweb_gallery id="<?php echo esc_attr( $coll_id ); ?>"]</code>
						<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-gw-copy-btn"
								data-copy="[mvweb_gallery id=&quot;<?php echo esc_attr( $coll_id ); ?>&quot;]"
								title="<?php esc_attr_e( 'Copy shortcode', 'mvweb-gallery-wall' ); ?>">
							<span class="dashicons dashicons-clipboard"></span>
						</button>
					</td>
					<td class="mvweb-gw-col-layout">
						<span class="dashicons <?php echo esc_attr( $layout_icon ); ?>"></span>
						<?php echo esc_html( $layout_label ); ?>
					</td>
					<td class="mvweb-gw-col-photos">
						<?php echo esc_html( count( $photos ) ); ?>
					</td>
					<td class="mvweb-gw-col-date">
						<?php echo esc_html( get_the_date( '', $collection ) ); ?>
					</td>
					<td class="mvweb-gw-col-actions">
						<a href="<?php echo esc_url( $edit_url ); ?>" class="mvweb-btn mvweb-btn--ghost mvweb-btn--icon" title="<?php esc_attr_e( 'Edit', 'mvweb-gallery-wall' ); ?>">
							<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
							<span class="screen-reader-text"><?php esc_html_e( 'Edit', 'mvweb-gallery-wall' ); ?></span>
						</a>

						<form method="post" class="mvweb-gw-inline-form">
							<?php wp_nonce_field( 'mvweb_gw_clone_' . $coll_id, 'mvweb_gw_clone_nonce' ); ?>
							<input type="hidden" name="collection_id" value="<?php echo esc_attr( $coll_id ); ?>">
							<button type="submit" name="mvweb_gw_clone_collection" value="1" class="mvweb-btn mvweb-btn--ghost mvweb-btn--icon" title="<?php esc_attr_e( 'Clone', 'mvweb-gallery-wall' ); ?>">
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>
								<span class="screen-reader-text"><?php esc_html_e( 'Clone', 'mvweb-gallery-wall' ); ?></span>
							</button>
						</form>

						<form method="post" class="mvweb-gw-inline-form mvweb-gw-delete-form">
							<?php wp_nonce_field( 'mvweb_gw_delete_' . $coll_id, 'mvweb_gw_delete_nonce' ); ?>
							<input type="hidden" name="collection_id" value="<?php echo esc_attr( $coll_id ); ?>">
							<button type="submit" name="mvweb_gw_delete_collection" value="1" class="mvweb-btn mvweb-btn--ghost mvweb-btn--icon mvweb-btn--danger" title="<?php esc_attr_e( 'Delete', 'mvweb-gallery-wall' ); ?>">
								<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
								<span class="screen-reader-text"><?php esc_html_e( 'Delete', 'mvweb-gallery-wall' ); ?></span>
							</button>
						</form>
					</td>
				</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
<?php endif; ?>
