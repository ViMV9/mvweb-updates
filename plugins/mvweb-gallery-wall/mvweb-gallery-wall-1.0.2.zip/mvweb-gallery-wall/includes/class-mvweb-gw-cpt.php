<?php
/**
 * Custom Post Type registration for MVweb Gallery Wall.
 *
 * Registers CPT `mvweb_gallery`, post meta fields, and provides defaults.
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Register the `mvweb_gallery` Custom Post Type.
 *
 * Non-public CPT — managed entirely through the custom admin page.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_gw_register_cpt() {

	$args = array(
		'label'               => __( 'Gallery Collections', 'mvweb-gallery-wall' ),
		'public'              => false,
		'show_ui'             => false,
		'show_in_rest'        => false,
		'has_archive'         => false,
		'exclude_from_search' => true,
		'publicly_queryable'  => false,
		'supports'            => array( 'title' ),
		'capability_type'     => 'post',
		'map_meta_cap'        => true,
	);

	register_post_type( 'mvweb_gallery', $args );

	// Register meta fields.
	mvweb_gw_register_meta();
}

/**
 * Register post meta fields for `mvweb_gallery`.
 *
 * Each meta field has a sanitize_callback and type defined.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_gw_register_meta() {

	$text_meta = array(
		'_mvweb_gw_layout'           => 'grid',
		'_mvweb_gw_aspect_ratio'     => '1:1',
		'_mvweb_gw_aspect_custom'    => '',
		'_mvweb_gw_object_fit'       => 'cover',
		'_mvweb_gw_max_width'        => '100%',
		'_mvweb_gw_animation'        => 'fade',
		'_mvweb_gw_hover'            => 'zoom',
		'_mvweb_gw_overlay_mode'     => 'hover',
		'_mvweb_gw_link_target'      => '_blank',
		'_mvweb_gw_order'            => 'manual',
		'_mvweb_gw_load_more_text'   => 'Show More',
		'_mvweb_gw_css_class'        => '',
		'_mvweb_gw_ticker_direction' => 'left',
		'_mvweb_gw_ticker_ratio'     => '16/9',
		'_mvweb_gw_ticker_fit'       => 'cover',
	);

	foreach ( $text_meta as $key => $default ) {
		register_post_meta(
			'mvweb_gallery',
			$key,
			array(
				'type'              => 'string',
				'single'            => true,
				'default'           => $default,
				'sanitize_callback' => 'sanitize_text_field',
			)
		);
	}

	$int_meta = array(
		'_mvweb_gw_columns_desktop' => 4,
		'_mvweb_gw_columns_tablet'  => 3,
		'_mvweb_gw_columns_mobile'  => 2,
		'_mvweb_gw_gap'             => 16,
		'_mvweb_gw_radius'          => 8,
		'_mvweb_gw_row_height'      => 240,
		'_mvweb_gw_per_page'        => 12,
		'_mvweb_gw_ticker_speed'    => 35,
		'_mvweb_gw_ticker_width'    => 200,
		'_mvweb_gw_ticker_center_scale' => 0,
		'_mvweb_gw_ticker_gap'      => 16,
	);

	foreach ( $int_meta as $key => $default ) {
		register_post_meta(
			'mvweb_gallery',
			$key,
			array(
				'type'              => 'integer',
				'single'            => true,
				'default'           => $default,
				'sanitize_callback' => 'absint',
			)
		);
	}

	$bool_meta = array(
		'_mvweb_gw_lightbox'      => true,
		'_mvweb_gw_show_title'    => false,
		'_mvweb_gw_ticker_pause'  => true,
	);

	foreach ( $bool_meta as $key => $default ) {
		register_post_meta(
			'mvweb_gallery',
			$key,
			array(
				'type'              => 'boolean',
				'single'            => true,
				'default'           => $default,
				'sanitize_callback' => 'rest_sanitize_boolean',
			)
		);
	}

	// Photos JSON — stored as a serialized string.
	register_post_meta(
		'mvweb_gallery',
		'_mvweb_gw_photos',
		array(
			'type'              => 'string',
			'single'            => true,
			'default'           => '[]',
			'sanitize_callback' => 'mvweb_gw_sanitize_photos_json',
		)
	);
}

/**
 * Sanitize photos JSON array.
 *
 * Validates and sanitizes each photo entry in the JSON array.
 *
 * @since 1.0.0
 * @param string $value Raw JSON string.
 * @return string Sanitized JSON string.
 */
function mvweb_gw_sanitize_photos_json( $value ) {

	$photos = json_decode( $value, true );

	if ( ! is_array( $photos ) ) {
		return '[]';
	}

	$sanitized = array();

	foreach ( $photos as $index => $photo ) {
		if ( ! is_array( $photo ) ) {
			continue;
		}

		$attachment_id = isset( $photo['attachment_id'] ) ? absint( $photo['attachment_id'] ) : 0;

		// Skip invalid attachments.
		if ( 0 === $attachment_id ) {
			continue;
		}

		// Sanitize tags.
		$tags = array();
		if ( ! empty( $photo['tags'] ) && is_array( $photo['tags'] ) ) {
			$tags = array_map( 'sanitize_text_field', $photo['tags'] );
			$tags = array_filter( $tags );
			$tags = array_values( $tags );
		}

		$sanitized[] = array(
			'attachment_id' => $attachment_id,
			'width'         => isset( $photo['width'] ) ? absint( $photo['width'] ) : 0,
			'height'        => isset( $photo['height'] ) ? absint( $photo['height'] ) : 0,
			'link'          => isset( $photo['link'] ) ? esc_url_raw( $photo['link'], array( 'http', 'https' ) ) : '',
			'title'         => isset( $photo['title'] ) ? sanitize_text_field( $photo['title'] ) : '',
			'caption'       => isset( $photo['caption'] ) ? sanitize_text_field( $photo['caption'] ) : '',
			'tags'          => $tags,
			'order'         => $index,
		);
	}

	return wp_json_encode( $sanitized, JSON_UNESCAPED_UNICODE );
}

/**
 * Get default settings for the plugin.
 *
 * These values are used as global defaults for new collections
 * and stored in the `mvweb_gw_settings` option.
 *
 * @since 1.0.0
 * @return array Default settings array.
 */
function mvweb_gw_get_defaults() {
	return array(
		// Layout defaults.
		'default_layout'            => 'grid',
		'default_columns_desktop'   => 4,
		'default_columns_tablet'    => 3,
		'default_columns_mobile'    => 2,
		'default_gap'               => 16,
		'default_radius'            => 8,
		'default_aspect_ratio'      => '1:1',
		'default_object_fit'        => 'cover',
		'default_max_width'         => '100%',

		// Animation & hover.
		'default_animation'         => 'fade',
		'default_hover'             => 'zoom',

		// Lightbox.
		'default_lightbox'          => true,

		// Lazy loading (first row stays eager for LCP when enabled).
		'default_lazyload'          => true,

		// Justified.
		'default_row_height'        => 240,

		// Ticker.
		'default_ticker_speed'      => 35,
		'default_ticker_direction'  => 'left',
		'default_ticker_pause'      => true,
		'default_ticker_width'      => 200,
		'default_ticker_ratio'      => '16/9',
		'default_ticker_fit'        => 'cover',
		'default_ticker_center_scale' => 0,
		'default_ticker_gap'        => 16,

		// UI controls appearance (shared by filter chips and the Load More button).
		// Default style: Material — no rounding, soft pastel palette.
		'ui_bg'                     => '#f5f5f5',
		'ui_text'                   => '#37474f',
		'ui_border'                 => '#cfd8dc',
		'ui_active_bg'              => '#b2dfdb',
		'ui_active_text'            => '#004d40',
		'ui_active_border'          => '#80cbc4',
		'ui_radius'                 => 0,
		'ui_border_width'           => 1,

		// Load more.
		'default_per_page'          => 12,
		'default_load_more_text'    => '',

		// Links.
		'default_link_target'       => '_blank',

		// Overlay.
		'default_overlay_mode'      => 'hover',
		'default_show_title'        => false,
	);
}
