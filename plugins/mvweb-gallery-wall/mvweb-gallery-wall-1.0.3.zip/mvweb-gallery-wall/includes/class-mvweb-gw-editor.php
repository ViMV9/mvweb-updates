<?php
/**
 * Collection editor: save, clone, delete operations.
 *
 * Handles all POST operations for gallery collections.
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Class MVweb_GW_Editor
 *
 * Manages CRUD operations for gallery collections.
 *
 * @since 1.0.0
 */
class MVweb_GW_Editor {

	/**
	 * Initialize hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'handle_save' ) );
		add_action( 'admin_init', array( __CLASS__, 'handle_clone' ) );
		add_action( 'admin_init', array( __CLASS__, 'handle_delete' ) );
	}

	/**
	 * Handle collection save (create / update).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function handle_save() {
		if ( ! isset( $_POST['mvweb_gw_save_collection'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions.', 'mvweb-gallery-wall' ) );
		}

		if ( ! isset( $_POST['mvweb_gw_editor_nonce'] ) ||
			 ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mvweb_gw_editor_nonce'] ) ), 'mvweb_gw_editor_save' ) ) {
			wp_die( esc_html__( 'Security check failed.', 'mvweb-gallery-wall' ) );
		}

		$collection_id = isset( $_POST['collection_id'] ) ? absint( $_POST['collection_id'] ) : 0;
		$title         = isset( $_POST['collection_title'] ) ? sanitize_text_field( wp_unslash( $_POST['collection_title'] ) ) : '';
		$status        = ! empty( $_POST['collection_status'] ) ? 'publish' : 'draft';

		// Create or update post.
		$post_data = array(
			'post_title'  => $title ? $title : __( 'Untitled Collection', 'mvweb-gallery-wall' ),
			'post_status' => $status,
			'post_type'   => 'mvweb_gallery',
		);

		if ( $collection_id > 0 ) {
			// Verify existing post is our CPT.
			$existing = get_post( $collection_id );
			if ( ! $existing || 'mvweb_gallery' !== $existing->post_type ) {
				wp_die( esc_html__( 'Invalid collection.', 'mvweb-gallery-wall' ) );
			}
			$post_data['ID'] = $collection_id;
			$result = wp_update_post( $post_data, true );
		} else {
			$result = wp_insert_post( $post_data, true );
		}

		if ( is_wp_error( $result ) ) {
			wp_die( esc_html( $result->get_error_message() ) );
		}

		$post_id = absint( $result );

		// Save all meta fields.
		self::save_meta( $post_id, $_POST );

		// Redirect back to editor.
		wp_safe_redirect( admin_url( 'admin.php?page=mvweb-gallery-wall&tab=editor&collection_id=' . $post_id . '&saved=1' ) );
		exit;
	}

	/**
	 * Handle collection clone.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function handle_clone() {
		if ( ! isset( $_POST['mvweb_gw_clone_collection'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions.', 'mvweb-gallery-wall' ) );
		}

		$gallery_id = isset( $_POST['collection_id'] ) ? absint( $_POST['collection_id'] ) : 0;

		if ( ! isset( $_POST['mvweb_gw_clone_nonce'] ) ||
			 ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mvweb_gw_clone_nonce'] ) ), 'mvweb_gw_clone_' . $gallery_id ) ) {
			wp_die( esc_html__( 'Security check failed.', 'mvweb-gallery-wall' ) );
		}

		$original = get_post( $gallery_id );
		if ( ! $original || 'mvweb_gallery' !== $original->post_type ) {
			wp_die( esc_html__( 'Invalid collection.', 'mvweb-gallery-wall' ) );
		}

		// Create clone as draft.
		$new_id = wp_insert_post( array(
			'post_title'  => sprintf(
				/* translators: %s: Original collection title */
				__( '%s (Copy)', 'mvweb-gallery-wall' ),
				$original->post_title
			),
			'post_status' => 'draft',
			'post_type'   => 'mvweb_gallery',
		), true );

		if ( is_wp_error( $new_id ) ) {
			wp_die( esc_html( $new_id->get_error_message() ) );
		}

		// Copy all meta fields.
		$meta_keys = self::get_meta_keys();
		foreach ( $meta_keys as $key ) {
			$value = get_post_meta( $gallery_id, $key, true );
			if ( '' !== $value ) {
				update_post_meta( $new_id, $key, $value );
			}
		}

		wp_safe_redirect( admin_url( 'admin.php?page=mvweb-gallery-wall&tab=collections&cloned=1' ) );
		exit;
	}

	/**
	 * Handle collection delete.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function handle_delete() {
		if ( ! isset( $_POST['mvweb_gw_delete_collection'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'You do not have sufficient permissions.', 'mvweb-gallery-wall' ) );
		}

		$gallery_id = isset( $_POST['collection_id'] ) ? absint( $_POST['collection_id'] ) : 0;

		if ( ! isset( $_POST['mvweb_gw_delete_nonce'] ) ||
			 ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['mvweb_gw_delete_nonce'] ) ), 'mvweb_gw_delete_' . $gallery_id ) ) {
			wp_die( esc_html__( 'Security check failed.', 'mvweb-gallery-wall' ) );
		}

		$post = get_post( $gallery_id );
		if ( ! $post || 'mvweb_gallery' !== $post->post_type ) {
			wp_die( esc_html__( 'Invalid collection.', 'mvweb-gallery-wall' ) );
		}

		wp_delete_post( $gallery_id, true );

		wp_safe_redirect( admin_url( 'admin.php?page=mvweb-gallery-wall&tab=collections&deleted=1' ) );
		exit;
	}

	/**
	 * Save meta fields for a collection.
	 *
	 * @since 1.0.0
	 * @param int   $post_id Post ID.
	 * @param array $post    Raw POST data.
	 * @return void
	 */
	private static function save_meta( int $post_id, array $post ): void {
		$defaults = mvweb_gw_get_defaults();

		// Layout — whitelist.
		$valid_layouts = array( 'grid', 'masonry', 'justified', 'ticker' );
		$layout        = isset( $post['_mvweb_gw_layout'] ) ? sanitize_text_field( $post['_mvweb_gw_layout'] ) : $defaults['default_layout'];
		update_post_meta( $post_id, '_mvweb_gw_layout', in_array( $layout, $valid_layouts, true ) ? $layout : 'grid' );

		// Columns (clamped).
		$col_d = isset( $post['_mvweb_gw_columns_desktop'] ) ? min( max( absint( $post['_mvweb_gw_columns_desktop'] ), 1 ), 8 ) : $defaults['default_columns_desktop'];
		$col_t = isset( $post['_mvweb_gw_columns_tablet'] ) ? min( max( absint( $post['_mvweb_gw_columns_tablet'] ), 1 ), 6 ) : $defaults['default_columns_tablet'];
		$col_m = isset( $post['_mvweb_gw_columns_mobile'] ) ? min( max( absint( $post['_mvweb_gw_columns_mobile'] ), 1 ), 4 ) : $defaults['default_columns_mobile'];
		update_post_meta( $post_id, '_mvweb_gw_columns_desktop', $col_d );
		update_post_meta( $post_id, '_mvweb_gw_columns_tablet', $col_t );
		update_post_meta( $post_id, '_mvweb_gw_columns_mobile', $col_m );

		// Gap, Radius.
		update_post_meta( $post_id, '_mvweb_gw_gap', isset( $post['_mvweb_gw_gap'] ) ? min( absint( $post['_mvweb_gw_gap'] ), 60 ) : $defaults['default_gap'] );
		update_post_meta( $post_id, '_mvweb_gw_radius', isset( $post['_mvweb_gw_radius'] ) ? min( absint( $post['_mvweb_gw_radius'] ), 50 ) : $defaults['default_radius'] );

		// Aspect ratio.
		$valid_ratios = array( '1:1', '4:3', '16:9', '3:2', 'auto', 'custom' );
		$ratio        = isset( $post['_mvweb_gw_aspect_ratio'] ) ? sanitize_text_field( $post['_mvweb_gw_aspect_ratio'] ) : 'auto';
		update_post_meta( $post_id, '_mvweb_gw_aspect_ratio', in_array( $ratio, $valid_ratios, true ) ? $ratio : 'auto' );
		update_post_meta( $post_id, '_mvweb_gw_aspect_custom', isset( $post['_mvweb_gw_aspect_custom'] ) ? sanitize_text_field( $post['_mvweb_gw_aspect_custom'] ) : '' );

		// Object fit.
		$valid_fits = array( 'cover', 'contain', 'fill', 'none', 'scale-down' );
		$fit        = isset( $post['_mvweb_gw_object_fit'] ) ? sanitize_text_field( $post['_mvweb_gw_object_fit'] ) : 'cover';
		update_post_meta( $post_id, '_mvweb_gw_object_fit', in_array( $fit, $valid_fits, true ) ? $fit : 'cover' );

		// Max width.
		update_post_meta( $post_id, '_mvweb_gw_max_width', isset( $post['_mvweb_gw_max_width'] ) ? sanitize_text_field( $post['_mvweb_gw_max_width'] ) : '100%' );

		// Row height (justified).
		update_post_meta( $post_id, '_mvweb_gw_row_height', isset( $post['_mvweb_gw_row_height'] ) ? min( max( absint( $post['_mvweb_gw_row_height'] ), 120 ), 400 ) : 240 );

		// Animation.
		$valid_anims = array( 'fade', 'slide-up', 'slide-left', 'scale', 'flip', 'none' );
		$anim        = isset( $post['_mvweb_gw_animation'] ) ? sanitize_text_field( $post['_mvweb_gw_animation'] ) : 'fade';
		update_post_meta( $post_id, '_mvweb_gw_animation', in_array( $anim, $valid_anims, true ) ? $anim : 'fade' );

		// Hover.
		$valid_hovers = array( 'zoom', 'grayscale', 'brightness', 'overlay', 'none' );
		$hover        = isset( $post['_mvweb_gw_hover'] ) ? sanitize_text_field( $post['_mvweb_gw_hover'] ) : 'zoom';
		update_post_meta( $post_id, '_mvweb_gw_hover', in_array( $hover, $valid_hovers, true ) ? $hover : 'zoom' );

		// Booleans — stored as '1'/'0' strings so an unchecked box keeps an explicit
		// '0' and does not fall back to the global default during the merge.
		update_post_meta( $post_id, '_mvweb_gw_lightbox', empty( $post['_mvweb_gw_lightbox'] ) ? '0' : '1' );
		update_post_meta( $post_id, '_mvweb_gw_show_title', empty( $post['_mvweb_gw_show_title'] ) ? '0' : '1' );

		// Overlay mode.
		$valid_overlays = array( 'hover', 'always', 'none' );
		$overlay        = isset( $post['_mvweb_gw_overlay_mode'] ) ? sanitize_text_field( $post['_mvweb_gw_overlay_mode'] ) : 'hover';
		update_post_meta( $post_id, '_mvweb_gw_overlay_mode', in_array( $overlay, $valid_overlays, true ) ? $overlay : 'hover' );

		// Link target.
		$valid_targets = array( '_self', '_blank' );
		$target        = isset( $post['_mvweb_gw_link_target'] ) ? sanitize_text_field( $post['_mvweb_gw_link_target'] ) : '_blank';
		update_post_meta( $post_id, '_mvweb_gw_link_target', in_array( $target, $valid_targets, true ) ? $target : '_blank' );

		// Order.
		$valid_orders = array( 'manual', 'random' );
		$order        = isset( $post['_mvweb_gw_order'] ) ? sanitize_text_field( $post['_mvweb_gw_order'] ) : 'manual';
		update_post_meta( $post_id, '_mvweb_gw_order', in_array( $order, $valid_orders, true ) ? $order : 'manual' );

		// Per page, load more text.
		update_post_meta( $post_id, '_mvweb_gw_per_page', isset( $post['_mvweb_gw_per_page'] ) ? absint( $post['_mvweb_gw_per_page'] ) : 12 );
		update_post_meta( $post_id, '_mvweb_gw_load_more_text', isset( $post['_mvweb_gw_load_more_text'] ) ? sanitize_text_field( wp_unslash( $post['_mvweb_gw_load_more_text'] ) ) : 'Show More' );

		// CSS class.
		$css_class = isset( $post['_mvweb_gw_css_class'] ) ? sanitize_text_field( $post['_mvweb_gw_css_class'] ) : '';
		update_post_meta( $post_id, '_mvweb_gw_css_class', $css_class );

		// Ticker settings.
		update_post_meta( $post_id, '_mvweb_gw_ticker_speed', isset( $post['_mvweb_gw_ticker_speed'] ) ? max( absint( $post['_mvweb_gw_ticker_speed'] ), 10 ) : 35 );

		$valid_dirs = array( 'left', 'right', 'up', 'down' );
		$dir        = isset( $post['_mvweb_gw_ticker_direction'] ) ? sanitize_text_field( $post['_mvweb_gw_ticker_direction'] ) : 'left';
		update_post_meta( $post_id, '_mvweb_gw_ticker_direction', in_array( $dir, $valid_dirs, true ) ? $dir : 'left' );

		update_post_meta( $post_id, '_mvweb_gw_ticker_pause', empty( $post['_mvweb_gw_ticker_pause'] ) ? '0' : '1' );
		update_post_meta( $post_id, '_mvweb_gw_ticker_width', isset( $post['_mvweb_gw_ticker_width'] ) ? max( absint( $post['_mvweb_gw_ticker_width'] ), 50 ) : 200 );
		update_post_meta( $post_id, '_mvweb_gw_ticker_ratio', isset( $post['_mvweb_gw_ticker_ratio'] ) ? sanitize_text_field( $post['_mvweb_gw_ticker_ratio'] ) : '16/9' );
		update_post_meta( $post_id, '_mvweb_gw_ticker_gap', isset( $post['_mvweb_gw_ticker_gap'] ) ? min( max( absint( $post['_mvweb_gw_ticker_gap'] ), 0 ), 100 ) : 16 );

		$valid_ticker_fits = array( 'cover', 'contain', 'fill' );
		$ticker_fit        = isset( $post['_mvweb_gw_ticker_fit'] ) ? sanitize_text_field( $post['_mvweb_gw_ticker_fit'] ) : 'cover';
		update_post_meta( $post_id, '_mvweb_gw_ticker_fit', in_array( $ticker_fit, $valid_ticker_fits, true ) ? $ticker_fit : 'cover' );

		$valid_center_scales = array( 0, 110, 115, 120 );
		$center_scale        = isset( $post['_mvweb_gw_ticker_center_scale'] ) ? absint( $post['_mvweb_gw_ticker_center_scale'] ) : 0;
		update_post_meta( $post_id, '_mvweb_gw_ticker_center_scale', in_array( $center_scale, $valid_center_scales, true ) ? $center_scale : 0 );

		// Photos JSON.
		$photos_json = isset( $post['_mvweb_gw_photos'] ) ? wp_unslash( $post['_mvweb_gw_photos'] ) : '[]';
		$sanitized   = mvweb_gw_sanitize_photos_json( $photos_json );
		update_post_meta( $post_id, '_mvweb_gw_photos', $sanitized );
	}

	/**
	 * Get all meta keys for a collection.
	 *
	 * @since 1.0.0
	 * @return array List of meta keys.
	 */
	public static function get_meta_keys(): array {
		return array(
			'_mvweb_gw_photos',
			'_mvweb_gw_layout',
			'_mvweb_gw_columns_desktop',
			'_mvweb_gw_columns_tablet',
			'_mvweb_gw_columns_mobile',
			'_mvweb_gw_gap',
			'_mvweb_gw_radius',
			'_mvweb_gw_aspect_ratio',
			'_mvweb_gw_aspect_custom',
			'_mvweb_gw_object_fit',
			'_mvweb_gw_max_width',
			'_mvweb_gw_row_height',
			'_mvweb_gw_animation',
			'_mvweb_gw_hover',
			'_mvweb_gw_lightbox',
			'_mvweb_gw_show_title',
			'_mvweb_gw_overlay_mode',
			'_mvweb_gw_link_target',
			'_mvweb_gw_order',
			'_mvweb_gw_per_page',
			'_mvweb_gw_load_more_text',
			'_mvweb_gw_css_class',
			'_mvweb_gw_ticker_speed',
			'_mvweb_gw_ticker_direction',
			'_mvweb_gw_ticker_pause',
			'_mvweb_gw_ticker_width',
			'_mvweb_gw_ticker_ratio',
			'_mvweb_gw_ticker_fit',
			'_mvweb_gw_ticker_center_scale',
			'_mvweb_gw_ticker_gap',
		);
	}

	/**
	 * Get collection data for editor.
	 *
	 * Returns post data with all meta fields merged.
	 *
	 * @since 1.0.0
	 * @param int $post_id Collection post ID.
	 * @return array|null Collection data or null if not found.
	 */
	public static function get_collection( int $post_id ): ?array {
		$post = get_post( $post_id );

		if ( ! $post || 'mvweb_gallery' !== $post->post_type ) {
			return null;
		}

		$data = array(
			'ID'          => $post->ID,
			'post_title'  => $post->post_title,
			'post_status' => $post->post_status,
		);

		$meta_keys = self::get_meta_keys();
		foreach ( $meta_keys as $key ) {
			$data[ $key ] = get_post_meta( $post_id, $key, true );
		}

		return $data;
	}
}
