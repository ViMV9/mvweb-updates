/**
 * Frontend JavaScript for MVweb Gallery Wall
 *
 * Phase 4: Basic initialization, entrance animations (IntersectionObserver),
 * filter bar, and foundation for future phases.
 *
 * Native JavaScript (no jQuery on frontend).
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

( function () {
	'use strict';

	/**
	 * Initialize all galleries on the page.
	 */
	function init() {
		var galleries = document.querySelectorAll( '.mvweb-gw' );
		galleries.forEach( function ( gallery ) {
			initLayout( gallery );
			initAnimations( gallery );
			initFilterBar( gallery );
			initLoadMore( gallery );
		} );

		initLightbox();
	}

	/**
	 * Initialize layout-specific logic.
	 *
	 * @param {HTMLElement} gallery Gallery container.
	 */
	function initLayout( gallery ) {
		if ( gallery.classList.contains( 'mvweb-gw--masonry' ) ) {
			initMasonry( gallery );
		} else if ( gallery.classList.contains( 'mvweb-gw--justified' ) ) {
			initJustified( gallery );
		} else if ( gallery.classList.contains( 'mvweb-gw--ticker' ) ) {
			initTicker( gallery );
		}
	}

	/* =====================================================================
	   Entrance Animations — IntersectionObserver
	   ===================================================================== */

	/**
	 * Set up IntersectionObserver for entrance animations.
	 *
	 * @param {HTMLElement} gallery Gallery container.
	 */
	function initAnimations( gallery ) {
		// Check if animations are enabled.
		var hasAnimation = gallery.className.indexOf( 'mvweb-gw--anim-' ) !== -1;
		if ( ! hasAnimation ) {
			return;
		}

		// Respect prefers-reduced-motion.
		if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			showAllItems( gallery );
			return;
		}

		if ( ! ( 'IntersectionObserver' in window ) ) {
			showAllItems( gallery );
			return;
		}

		var observer = new IntersectionObserver(
			function ( entries ) {
				entries.forEach( function ( entry ) {
					if ( entry.isIntersecting ) {
						var item = entry.target;
						var index = parseInt( item.getAttribute( 'data-anim-index' ) || '0', 10 );
						var delay = index * 80; // Stagger: 80ms between items.

						setTimeout( function () {
							item.classList.add( 'mvweb-gw__item--visible' );
						}, delay );

						observer.unobserve( item );
					}
				} );
			},
			{ threshold: 0.1 }
		);

		var items = gallery.querySelectorAll( '.mvweb-gw__item' );
		items.forEach( function ( item, i ) {
			item.setAttribute( 'data-anim-index', i );
			observer.observe( item );
		} );
	}

	/**
	 * Show all items immediately (fallback).
	 *
	 * @param {HTMLElement} gallery Gallery container.
	 */
	function showAllItems( gallery ) {
		var items = gallery.querySelectorAll( '.mvweb-gw__item' );
		items.forEach( function ( item ) {
			item.classList.add( 'mvweb-gw__item--visible' );
		} );
	}

	/* =====================================================================
	   Filter Bar
	   ===================================================================== */

	/**
	 * Initialize filter bar functionality.
	 *
	 * @param {HTMLElement} gallery Gallery container.
	 */
	function initFilterBar( gallery ) {
		var filterBar = gallery.querySelector( '.mvweb-gw__filters' );
		if ( ! filterBar ) {
			return;
		}

		var buttons = filterBar.querySelectorAll( '.mvweb-gw__filter' );
		var allItems = gallery.querySelectorAll( '.mvweb-gw__item' );
		var loadMore = gallery.querySelector( '.mvweb-gw__load-more' );

		// Remember which items were initially hidden behind "Load More" so the
		// unfiltered ("All") view can restore the per-page limit.
		var beyondItems = Array.prototype.slice.call(
			gallery.querySelectorAll( '.mvweb-gw__item--beyond' )
		);

		buttons.forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				var tag = btn.getAttribute( 'data-tag' );

				// Update active state.
				buttons.forEach( function ( b ) {
					b.classList.remove( 'mvweb-gw__filter--active' );
					b.setAttribute( 'aria-pressed', 'false' );
				} );
				btn.classList.add( 'mvweb-gw__filter--active' );
				btn.setAttribute( 'aria-pressed', 'true' );

				if ( 'all' === tag ) {
					// Restore the per-page limit and the "Load More" button.
					allItems.forEach( function ( item ) {
						item.classList.remove( 'mvweb-gw__item--hidden' );
					} );
					beyondItems.forEach( function ( item ) {
						item.classList.add( 'mvweb-gw__item--beyond' );
					} );
					if ( loadMore && beyondItems.length ) {
						loadMore.style.display = '';
					}
				} else {
					// Filtering by a tag reveals ALL matching photos (ignoring the
					// per-page limit) and hides the "Load More" button.
					allItems.forEach( function ( item ) {
						item.classList.remove( 'mvweb-gw__item--beyond' );

						var tagsAttr = item.getAttribute( 'data-tags' );
						var match = false;
						if ( tagsAttr ) {
							try {
								var itemTags = JSON.parse( tagsAttr );
								match = Array.isArray( itemTags ) && itemTags.indexOf( tag ) !== -1;
							} catch ( e ) {
								match = false;
							}
						}

						if ( match ) {
							item.classList.remove( 'mvweb-gw__item--hidden' );
						} else {
							item.classList.add( 'mvweb-gw__item--hidden' );
						}
					} );
					if ( loadMore ) {
						loadMore.style.display = 'none';
					}
				}

				if ( gallery._masonryLayout ) {
					gallery._masonryLayout();
				}
				if ( gallery._justifiedLayout ) {
					gallery._justifiedLayout();
				}
			} );
		} );
	}

	/* =====================================================================
	   Masonry Layout
	   ===================================================================== */

	/**
	 * Initialize masonry layout with absolute positioning.
	 *
	 * @param {HTMLElement} gallery Gallery container.
	 */
	function initMasonry( gallery ) {
		var grid = gallery.querySelector( '.mvweb-gw__grid' );
		if ( ! grid ) {
			return;
		}

		// Mark as JS-masonry to switch from CSS columns.
		gallery.classList.add( 'mvweb-gw--js-masonry' );

		function layoutMasonry() {
			var items = grid.querySelectorAll( '.mvweb-gw__item:not(.mvweb-gw__item--hidden):not(.mvweb-gw__item--beyond)' );
			if ( ! items.length ) {
				grid.style.height = '0px';
				return;
			}

			var containerWidth = grid.offsetWidth;
			var style = getComputedStyle( gallery );
			var gap = parseInt( style.getPropertyValue( '--mvweb-gw-gap' ), 10 ) || 0;

			// Determine columns based on viewport.
			var columns;
			var viewportWidth = window.innerWidth;
			if ( viewportWidth <= 782 ) {
				columns = parseInt( style.getPropertyValue( '--mvweb-gw-columns-mobile' ), 10 ) || 2;
			} else if ( viewportWidth <= 1024 ) {
				columns = parseInt( style.getPropertyValue( '--mvweb-gw-columns-tablet' ), 10 ) || 3;
			} else {
				columns = parseInt( style.getPropertyValue( '--mvweb-gw-columns' ), 10 ) || 4;
			}

			var colWidth = ( containerWidth - gap * ( columns - 1 ) ) / columns;
			var colHeights = new Array( columns ).fill( 0 );

			items.forEach( function ( item ) {
				// Find shortest column.
				var minHeight = Math.min.apply( null, colHeights );
				var colIndex = colHeights.indexOf( minHeight );

				// Get natural aspect ratio from data attributes or img.
				var img = item.querySelector( 'img' );
				var naturalWidth = parseInt( item.getAttribute( 'data-width' ) || ( img && img.getAttribute( 'width' ) ) || '0', 10 );
				var naturalHeight = parseInt( item.getAttribute( 'data-height' ) || ( img && img.getAttribute( 'height' ) ) || '0', 10 );

				var itemHeight;
				if ( naturalWidth > 0 && naturalHeight > 0 ) {
					itemHeight = ( naturalHeight / naturalWidth ) * colWidth;
				} else {
					// Fallback: measure actual rendered height.
					item.style.position = 'absolute';
					item.style.width = colWidth + 'px';
					item.style.left = '-9999px';
					item.style.top = '0';
					itemHeight = item.offsetHeight;
				}

				var left = colIndex * ( colWidth + gap );
				var top = colHeights[ colIndex ];

				item.style.position = 'absolute';
				item.style.width = colWidth + 'px';
				// Pin the tile height to the computed image height so the overlay
				// sits exactly at the photo's bottom edge (no spill below, even
				// before a lazy image has loaded) and the vertical gap matches the
				// horizontal one exactly.
				item.style.height = Math.round( itemHeight ) + 'px';
				item.style.left = left + 'px';
				item.style.top = Math.round( top ) + 'px';

				colHeights[ colIndex ] += Math.round( itemHeight ) + gap;
			} );

			// Set container height.
			var maxHeight = Math.max.apply( null, colHeights );
			grid.style.height = ( maxHeight - gap ) + 'px';
		}

		// Initial layout after images load.
		var images = grid.querySelectorAll( 'img' );
		var loaded = 0;
		var totalImages = images.length;

		if ( 0 === totalImages ) {
			layoutMasonry();
		} else {
			images.forEach( function ( img ) {
				if ( img.complete ) {
					loaded++;
					if ( loaded === totalImages ) {
						layoutMasonry();
					}
				} else {
					img.addEventListener( 'load', function () {
						loaded++;
						if ( loaded === totalImages ) {
							layoutMasonry();
						}
					} );
					img.addEventListener( 'error', function () {
						loaded++;
						if ( loaded === totalImages ) {
							layoutMasonry();
						}
					} );
				}
			} );
		}

		// Recalc on resize (debounced).
		var resizeTimer;
		window.addEventListener( 'resize', function () {
			clearTimeout( resizeTimer );
			resizeTimer = setTimeout( layoutMasonry, 150 );
		} );

		// Expose for external recalculation (load more, filter).
		gallery._masonryLayout = layoutMasonry;
	}

	/* =====================================================================
	   Justified Layout
	   ===================================================================== */

	/**
	 * Initialize justified layout with row-based calculation.
	 *
	 * @param {HTMLElement} gallery Gallery container.
	 */
	function initJustified( gallery ) {
		var grid = gallery.querySelector( '.mvweb-gw__grid' );
		if ( ! grid ) {
			return;
		}

		function layoutJustified() {
			var items = Array.prototype.slice.call(
				grid.querySelectorAll( '.mvweb-gw__item:not(.mvweb-gw__item--hidden):not(.mvweb-gw__item--beyond)' )
			);
			if ( ! items.length ) {
				return;
			}

			var containerWidth = grid.offsetWidth;
			if ( containerWidth <= 0 ) {
				return;
			}
			var style = getComputedStyle( gallery );
			var gap = parseInt( style.getPropertyValue( '--mvweb-gw-gap' ), 10 ) || 0;

			// Target row height from data attribute or CSS variable.
			var rowHeight = parseInt( gallery.getAttribute( 'data-row-height' ), 10 ) || 240;

			// Collect aspect ratios.
			var ratios = items.map( function ( item ) {
				var img = item.querySelector( 'img' );
				var w = parseInt( item.getAttribute( 'data-width' ) || ( img && img.getAttribute( 'width' ) ) || '0', 10 );
				var h = parseInt( item.getAttribute( 'data-height' ) || ( img && img.getAttribute( 'height' ) ) || '0', 10 );
				return ( w > 0 && h > 0 ) ? w / h : 1;
			} );

			// Build rows.
			var currentRow = [];
			var currentRowWidth = 0;
			var lastFullRowHeight = rowHeight;

			for ( var i = 0; i < items.length; i++ ) {
				var ratio = ratios[ i ];
				var itemWidth = ratio * rowHeight;

				currentRow.push( { item: items[ i ], ratio: ratio } );
				currentRowWidth += itemWidth;

				// Add gaps between items in the row.
				var totalGaps = ( currentRow.length - 1 ) * gap;
				var availableWidth = containerWidth - totalGaps;

				// Check if row is full.
				if ( currentRowWidth >= availableWidth ) {
					// Calculate actual height to fit row perfectly.
					var rowRatioSum = 0;
					currentRow.forEach( function ( entry ) {
						rowRatioSum += entry.ratio;
					} );
					var actualHeight = ( containerWidth - totalGaps ) / rowRatioSum;
					lastFullRowHeight = actualHeight;

					currentRow.forEach( function ( entry ) {
						var w = entry.ratio * actualHeight;
						entry.item.style.flexBasis = w + 'px';
						entry.item.style.height = actualHeight + 'px';
					} );

					currentRow = [];
					currentRowWidth = 0;
				}
			}

			// Last (incomplete) row: left-aligned, matched to the previous rows'
			// height so a leftover photo never looks bigger than the rest.
			if ( currentRow.length > 0 ) {
				var lastHeight = Math.min( rowHeight, lastFullRowHeight );
				currentRow.forEach( function ( entry ) {
					var w = entry.ratio * lastHeight;
					entry.item.style.flexBasis = w + 'px';
					entry.item.style.height = lastHeight + 'px';
				} );
			}
		}

		// Lay out immediately using the data-width/height attributes (no need to
		// wait for images), so photos never flash at full size. Re-run once each
		// image is loaded as a safety net for items without dimension data.
		layoutJustified();

		var images = grid.querySelectorAll( 'img' );
		images.forEach( function ( img ) {
			if ( ! img.complete ) {
				img.addEventListener( 'load', layoutJustified );
				img.addEventListener( 'error', layoutJustified );
			}
		} );

		// Recalc on resize.
		var resizeTimer;
		window.addEventListener( 'resize', function () {
			clearTimeout( resizeTimer );
			resizeTimer = setTimeout( layoutJustified, 150 );
		} );

		// Expose for external recalculation.
		gallery._justifiedLayout = layoutJustified;
	}

	/* =====================================================================
	   Ticker Layout
	   ===================================================================== */

	/**
	 * Initialize ticker (infinite scroll) layout.
	 *
	 * @param {HTMLElement} gallery Gallery container.
	 */
	function initTicker( gallery ) {
		var track = gallery.querySelector( '.mvweb-gw__track' );
		if ( ! track ) {
			return;
		}

		var isVertical = gallery.classList.contains( 'mvweb-gw--dir-up' ) ||
		                 gallery.classList.contains( 'mvweb-gw--dir-down' );

		// Speed is a constant linear speed in pixels per second, independent of how
		// many photos the strip holds. The animation duration is derived from the
		// measured loop distance once the slides are laid out (see duplicateSlides),
		// so adding or removing photos no longer changes the on-screen speed.
		var speed = parseInt( gallery.getAttribute( 'data-speed' ), 10 ) || 35;

		// Pause on hover.
		var pauseHover = 'true' === gallery.getAttribute( 'data-pause-hover' );
		if ( pauseHover ) {
			gallery.classList.add( 'mvweb-gw--pausable' );
		}

		/**
		 * Duplicate slides until they fill at least 2x visible area.
		 */
		function duplicateSlides() {
			var slides = track.querySelectorAll( '.mvweb-gw__slide:not([aria-hidden])' );
			if ( ! slides.length ) {
				return;
			}

			// Remove old duplicates.
			var oldDupes = track.querySelectorAll( '.mvweb-gw__slide[aria-hidden="true"]' );
			oldDupes.forEach( function ( dupe ) {
				track.removeChild( dupe );
			} );

			// Estimate one set's size to decide how many copies are needed. The exact
			// seamless shift is measured from real positions further down — this is
			// only a rough size used for the copy count.
			var estSize = 0;
			slides.forEach( function ( slide ) {
				estSize += isVertical ? slide.offsetHeight : slide.offsetWidth;
			} );
			var style = getComputedStyle( gallery );
			var gap = parseFloat( style.getPropertyValue( '--mvweb-gw-gap' ) ) || 0;
			estSize += slides.length * gap;

			var containerSize = isVertical ? gallery.offsetHeight : gallery.offsetWidth;

			// Duplicate enough times that the original set plus the copies always
			// overflow the viewport (need at least one full copy behind the original
			// so the seam is never on screen).
			var duplications = Math.ceil( ( containerSize + estSize ) / estSize );
			if ( duplications < 1 ) {
				duplications = 1;
			}

			for ( var d = 0; d < duplications; d++ ) {
				slides.forEach( function ( slide ) {
					var clone = slide.cloneNode( true );
					clone.setAttribute( 'aria-hidden', 'true' );
					// Clones must not be picked up by the lightbox or duplicate any ids.
					clone.querySelectorAll( '[id]' ).forEach( function ( el ) {
						el.removeAttribute( 'id' );
					} );
					track.appendChild( clone );
				} );
			}

			// Measure the seamless shift as the real distance from the first original
			// slide to its twin (the first clone). offsetLeft/Top are layout positions
			// unaffected by the transform animation, so this is exact regardless of
			// slide width, gap or box-sizing — no double-counting of gaps.
			var allSlides = track.querySelectorAll( '.mvweb-gw__slide' );
			var firstClone = allSlides[ slides.length ];
			if ( firstClone ) {
				var shift = isVertical
					? firstClone.offsetTop - slides[ 0 ].offsetTop
					: firstClone.offsetLeft - slides[ 0 ].offsetLeft;
				track.style.setProperty( '--mvweb-gw-ticker-shift', shift + 'px' );

				// Derive the animation duration from the loop distance so the visible
				// speed stays constant (pixels per second) regardless of how many
				// photos there are: duration = distance / speed.
				var pxPerSec = speed > 0 ? speed : 35;
				var duration = shift / pxPerSec;
				if ( duration > 0 ) {
					gallery.style.setProperty( '--mvweb-gw-ticker-speed', duration.toFixed( 2 ) + 's' );
				}
			}
		}

		// Wait for images to load before duplicating.
		var images = track.querySelectorAll( 'img' );
		var loaded = 0;
		var totalImages = images.length;

		// Center zoom: smoothly enlarge each photo as it crosses the strip center.
		var centerScale = parseInt( gallery.getAttribute( 'data-center-scale' ), 10 ) || 0;
		var reduceMotion = window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches;

		function initCenterScale() {
			if ( centerScale <= 100 || reduceMotion ) {
				return;
			}

			gallery.classList.add( 'mvweb-gw--center-scale' );
			var maxScale = centerScale / 100;
			var rafId = null;

			// Reserve side spacing so a photo at peak scale never overlaps its
			// neighbours. Extra room per side = photoSize * (maxScale - 1) / 2.
			function setExtraSpacing() {
				var sampleImg = track.querySelector( '.mvweb-gw__slide img' );
				if ( ! sampleImg ) {
					return;
				}
				var imgSize = isVertical ? sampleImg.offsetHeight : sampleImg.offsetWidth;
				var extra = Math.ceil( ( imgSize * ( maxScale - 1 ) ) / 2 );
				gallery.style.setProperty( '--mvweb-gw-center-extra', extra + 'px' );
			}
			setExtraSpacing();

			function update() {
				var galleryRect = gallery.getBoundingClientRect();
				var center = isVertical
					? galleryRect.top + galleryRect.height / 2
					: galleryRect.left + galleryRect.width / 2;
				// Falloff distance: half the container size — at the edge scale returns to 1.
				var reach = ( isVertical ? galleryRect.height : galleryRect.width ) / 2;

				var slides = track.querySelectorAll( '.mvweb-gw__slide' );
				slides.forEach( function ( slide ) {
					var rect = slide.getBoundingClientRect();
					var slideCenter = isVertical
						? rect.top + rect.height / 2
						: rect.left + rect.width / 2;
					var dist = Math.abs( slideCenter - center );
					var t = reach > 0 ? Math.max( 0, 1 - dist / reach ) : 0;
					var scale = 1 + ( maxScale - 1 ) * t;
					var img = slide.querySelector( 'img' );
					if ( img ) {
						img.style.transform = 'scale(' + scale.toFixed( 3 ) + ')';
						// Larger photos stack above smaller neighbours.
						img.style.zIndex = String( Math.round( t * 100 ) );
					}
				} );

				rafId = window.requestAnimationFrame( update );
			}

			rafId = window.requestAnimationFrame( update );

			// Pause the rAF loop when the gallery is off-screen.
			if ( 'IntersectionObserver' in window ) {
				var io = new IntersectionObserver( function ( entries ) {
					entries.forEach( function ( entry ) {
						if ( entry.isIntersecting ) {
							if ( null === rafId ) {
								rafId = window.requestAnimationFrame( update );
							}
						} else if ( null !== rafId ) {
							window.cancelAnimationFrame( rafId );
							rafId = null;
						}
					} );
				} );
				io.observe( gallery );
			}
		}

		function onAllImagesReady() {
			duplicateSlides();
			initCenterScale();
		}

		if ( 0 === totalImages ) {
			onAllImagesReady();
		} else {
			images.forEach( function ( img ) {
				if ( img.complete ) {
					loaded++;
					if ( loaded === totalImages ) {
						onAllImagesReady();
					}
				} else {
					img.addEventListener( 'load', function () {
						loaded++;
						if ( loaded === totalImages ) {
							onAllImagesReady();
						}
					} );
					img.addEventListener( 'error', function () {
						loaded++;
						if ( loaded === totalImages ) {
							onAllImagesReady();
						}
					} );
				}
			} );
		}
	}

	/* =====================================================================
	   Lightbox
	   ===================================================================== */

	/**
	 * Initialize lightbox functionality.
	 *
	 * Supports multiple isolated galleries, keyboard navigation,
	 * touch swipe, preloading, and full a11y (focus trap, inert, aria-live).
	 */
	function initLightbox() {
		var lightbox = document.querySelector( '.mvweb-gw-lightbox' );
		if ( ! lightbox ) {
			return;
		}

		var imgEl      = lightbox.querySelector( '.mvweb-gw-lightbox__img' );
		var counterEl  = lightbox.querySelector( '.mvweb-gw-lightbox__counter' );
		var titleEl    = lightbox.querySelector( '.mvweb-gw-lightbox__title' );
		var captionEl  = lightbox.querySelector( '.mvweb-gw-lightbox__caption' );
		var closeBtn   = lightbox.querySelector( '.mvweb-gw-lightbox__close' );
		var prevBtn    = lightbox.querySelector( '.mvweb-gw-lightbox__prev' );
		var nextBtn    = lightbox.querySelector( '.mvweb-gw-lightbox__next' );

		var currentItems   = [];
		var currentIndex   = 0;
		var triggerElement = null;
		var isOpen         = false;

		var touchStartX = 0;
		var touchStartY = 0;
		var touchEndX   = 0;
		var touchEndY   = 0;

		/**
		 * Collect lightbox items from a gallery container.
		 */
		function collectItems( gallery ) {
			var triggers = gallery.querySelectorAll( '.mvweb-gw__lightbox-trigger' );
			var items = [];
			triggers.forEach( function ( trigger ) {
				// Skip ticker clones so the lightbox lists each photo only once.
				if ( trigger.closest( '[aria-hidden="true"]' ) ) {
					return;
				}
				var img = trigger.querySelector( 'img' );
				if ( ! img ) {
					return;
				}
				var item = trigger.closest( '.mvweb-gw__item' );
				// Pick the largest candidate from srcset. WordPress does not
				// guarantee the entries are sorted, so we compare the width
				// descriptors instead of blindly taking the last one (which can
				// be a tiny thumbnail and would open a blurry image).
				var fullSrc = img.currentSrc || img.src;
				if ( img.srcset ) {
					var bestWidth = -1;
					img.srcset.split( ',' ).forEach( function ( part ) {
						var bits = part.trim().split( /\s+/ );
						var url = bits[ 0 ];
						var w = bits[ 1 ] ? parseInt( bits[ 1 ], 10 ) : 0;
						if ( url && w > bestWidth ) {
							bestWidth = w;
							fullSrc = url;
						}
					} );
				}

				items.push( {
					trigger: trigger,
					src:     fullSrc,
					alt:     img.getAttribute( 'alt' ) || '',
					title:   item ? ( item.querySelector( '.mvweb-gw__overlay-title' ) || {} ).textContent || '' : '',
					caption: item ? ( item.querySelector( '.mvweb-gw__overlay-caption' ) || {} ).textContent || '' : ''
				} );
			} );
			return items;
		}

		/**
		 * Open lightbox at a given index.
		 */
		function open( items, index, trigger ) {
			currentItems   = items;
			currentIndex   = index;
			triggerElement = trigger;
			isOpen         = true;

			showImage( index );
			lightbox.removeAttribute( 'hidden' );
			lightbox.classList.add( 'mvweb-gw-lightbox--open' );

			document.querySelectorAll( 'body > *:not(.mvweb-gw-lightbox)' ).forEach( function ( el ) {
				el.setAttribute( 'inert', '' );
			} );

			closeBtn.focus();
			document.addEventListener( 'keydown', onKeyDown );
		}

		/**
		 * Close lightbox.
		 */
		function close() {
			if ( ! isOpen ) {
				return;
			}
			isOpen = false;
			lightbox.classList.remove( 'mvweb-gw-lightbox--open' );
			lightbox.setAttribute( 'hidden', '' );

			document.querySelectorAll( '[inert]' ).forEach( function ( el ) {
				el.removeAttribute( 'inert' );
			} );

			document.removeEventListener( 'keydown', onKeyDown );

			if ( triggerElement ) {
				triggerElement.focus();
			}

			imgEl.src = '';
			imgEl.alt = '';
		}

		/**
		 * Show image at index.
		 */
		function showImage( index ) {
			if ( index < 0 || index >= currentItems.length ) {
				return;
			}
			currentIndex = index;
			var item = currentItems[ index ];

			imgEl.src = item.src;
			imgEl.alt = item.alt;

			// Counter — textContent for XSS safety (TZ 17.4).
			counterEl.textContent = ( index + 1 ) + ' / ' + currentItems.length;

			// Title and caption — textContent only.
			titleEl.textContent   = item.title;
			captionEl.textContent = item.caption;

			prevBtn.style.display = ( index > 0 ) ? '' : 'none';
			nextBtn.style.display = ( index < currentItems.length - 1 ) ? '' : 'none';

			preload( index - 1 );
			preload( index + 1 );
		}

		function preload( index ) {
			if ( index >= 0 && index < currentItems.length ) {
				var img = new Image();
				img.src = currentItems[ index ].src;
			}
		}

		function goNext() {
			if ( currentIndex < currentItems.length - 1 ) {
				showImage( currentIndex + 1 );
			}
		}

		function goPrev() {
			if ( currentIndex > 0 ) {
				showImage( currentIndex - 1 );
			}
		}

		function onKeyDown( e ) {
			switch ( e.key ) {
				case 'Escape':
					close();
					break;
				case 'ArrowRight':
					goNext();
					break;
				case 'ArrowLeft':
					goPrev();
					break;
				case 'Tab':
					trapFocus( e );
					break;
			}
		}

		/**
		 * Focus trap — cycle between close, prev, next.
		 */
		function trapFocus( e ) {
			var focusable = [];
			if ( closeBtn ) { focusable.push( closeBtn ); }
			if ( prevBtn && prevBtn.style.display !== 'none' ) { focusable.push( prevBtn ); }
			if ( nextBtn && nextBtn.style.display !== 'none' ) { focusable.push( nextBtn ); }

			if ( 0 === focusable.length ) {
				return;
			}

			var currentFocus = document.activeElement;
			var focusIndex   = focusable.indexOf( currentFocus );
			e.preventDefault();

			if ( e.shiftKey ) {
				var prevIndex = ( focusIndex <= 0 ) ? focusable.length - 1 : focusIndex - 1;
				focusable[ prevIndex ].focus();
			} else {
				var nextIndex = ( focusIndex >= focusable.length - 1 ) ? 0 : focusIndex + 1;
				focusable[ nextIndex ].focus();
			}
		}

		// Click: open from trigger buttons (delegated).
		document.addEventListener( 'click', function ( e ) {
			var trigger = e.target.closest( '.mvweb-gw__lightbox-trigger' );
			if ( ! trigger ) {
				return;
			}
			e.preventDefault();

			var gallery = trigger.closest( '.mvweb-gw' );
			if ( ! gallery ) {
				return;
			}

			var items = collectItems( gallery );
			if ( 0 === items.length ) {
				return;
			}

			var clickedIndex = -1;
			for ( var i = 0; i < items.length; i++ ) {
				if ( items[ i ].trigger === trigger ) {
					clickedIndex = i;
					break;
				}
			}

			// Ticker duplicates slides for the seamless loop; a click can land on a
			// clone (excluded from `items`). Map it back to the original by its
			// position among all triggers, modulo the real photo count.
			if ( -1 === clickedIndex ) {
				var allTriggers = gallery.querySelectorAll( '.mvweb-gw__lightbox-trigger' );
				var pos = Array.prototype.indexOf.call( allTriggers, trigger );
				clickedIndex = ( pos >= 0 && items.length ) ? ( pos % items.length ) : 0;
			}

			open( items, clickedIndex, trigger );
		} );

		closeBtn.addEventListener( 'click', close );

		lightbox.addEventListener( 'click', function ( e ) {
			if ( e.target === lightbox || e.target.classList.contains( 'mvweb-gw-lightbox__backdrop' ) ) {
				close();
			}
		} );

		prevBtn.addEventListener( 'click', function ( e ) {
			e.stopPropagation();
			goPrev();
		} );
		nextBtn.addEventListener( 'click', function ( e ) {
			e.stopPropagation();
			goNext();
		} );

		// Touch swipe.
		lightbox.addEventListener( 'touchstart', function ( e ) {
			touchStartX = e.changedTouches[ 0 ].screenX;
			touchStartY = e.changedTouches[ 0 ].screenY;
		}, { passive: true } );

		lightbox.addEventListener( 'touchend', function ( e ) {
			touchEndX = e.changedTouches[ 0 ].screenX;
			touchEndY = e.changedTouches[ 0 ].screenY;
			var diffX = touchEndX - touchStartX;
			var diffY = touchEndY - touchStartY;

			if ( Math.abs( diffX ) > 50 && Math.abs( diffX ) > Math.abs( diffY ) ) {
				if ( diffX < 0 ) {
					goNext();
				} else {
					goPrev();
				}
			}
		}, { passive: true } );
	}

	/* =====================================================================
	   Load More (reveal hidden items — no AJAX)
	   ===================================================================== */

	/**
	 * Initialize "Load More" for a gallery.
	 *
	 * All photos are already in the DOM; items beyond the per-page limit carry
	 * the `--beyond` class and are hidden via CSS. Each click reveals the next
	 * batch. This keeps the full gallery available to the lightbox at all times,
	 * while lazy-loaded images keep hidden photos cheap until they are shown.
	 *
	 * @param {HTMLElement} gallery Gallery container.
	 */
	function initLoadMore( gallery ) {
		var loadMoreBtn = gallery.querySelector( '.mvweb-gw__load-more-btn' );
		if ( ! loadMoreBtn ) {
			return;
		}

		var grid = gallery.querySelector( '.mvweb-gw__grid' );
		var step = parseInt( loadMoreBtn.getAttribute( 'data-step' ), 10 ) || 0;

		loadMoreBtn.addEventListener( 'click', function () {
			var hidden = grid ? grid.querySelectorAll( '.mvweb-gw__item--beyond' ) : [];
			if ( ! hidden.length ) {
				return;
			}

			var count   = step > 0 ? Math.min( step, hidden.length ) : hidden.length;
			var revealed = [];
			for ( var i = 0; i < count; i++ ) {
				hidden[ i ].classList.remove( 'mvweb-gw__item--beyond' );
				revealed.push( hidden[ i ] );
			}

			applyAnimationsToNewItems( gallery, revealed );

			if ( gallery._masonryLayout ) {
				gallery._masonryLayout();
			}
			if ( gallery._justifiedLayout ) {
				gallery._justifiedLayout();
			}

			// Hide the button once nothing is left to reveal.
			if ( ! grid.querySelector( '.mvweb-gw__item--beyond' ) ) {
				loadMoreBtn.closest( '.mvweb-gw__load-more' ).style.display = 'none';
			}
		} );
	}

	/**
	 * Apply entrance animations to newly loaded items.
	 *
	 * @param {HTMLElement}  gallery  Gallery container.
	 * @param {NodeList}     newItems Newly added items.
	 */
	function applyAnimationsToNewItems( gallery, newItems ) {
		var hasAnimation = gallery.className.indexOf( 'mvweb-gw--anim-' ) !== -1;
		if ( ! hasAnimation ) {
			return;
		}

		if ( window.matchMedia && window.matchMedia( '(prefers-reduced-motion: reduce)' ).matches ) {
			newItems.forEach( function ( item ) {
				item.classList.add( 'mvweb-gw__item--visible' );
			} );
			return;
		}

		if ( ! ( 'IntersectionObserver' in window ) ) {
			newItems.forEach( function ( item ) {
				item.classList.add( 'mvweb-gw__item--visible' );
			} );
			return;
		}

		var observer = new IntersectionObserver(
			function ( entries ) {
				entries.forEach( function ( entry ) {
					if ( entry.isIntersecting ) {
						var item = entry.target;
						var idx = parseInt( item.getAttribute( 'data-anim-index' ) || '0', 10 );
						setTimeout( function () {
							item.classList.add( 'mvweb-gw__item--visible' );
						}, idx * 80 );
						observer.unobserve( item );
					}
				} );
			},
			{ threshold: 0.1 }
		);

		newItems.forEach( function ( item, i ) {
			item.setAttribute( 'data-anim-index', i );
			observer.observe( item );
		} );
	}

	/* =====================================================================
	   DOM Ready
	   ===================================================================== */

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', init );
	} else {
		init();
	}

} )();
