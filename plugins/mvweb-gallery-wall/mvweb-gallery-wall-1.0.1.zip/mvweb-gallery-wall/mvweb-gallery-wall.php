<?php
/**
 * Plugin Name:       MVweb Gallery Wall
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-gallery-wall
 * Description:       Customizable photo gallery with grid, masonry, justified, ticker layouts and built-in lightbox.
 * Version:           1.0.1
 * Requires at least: 6.4
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-gallery-wall
 * Domain Path:       /languages
 *
 * @package MVweb_Gallery_Wall
 *
 * @since 1.0.0 Initial release.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// Prevent double loading.
if ( defined( 'MVWEB_GW_VERSION' ) ) { return; }

define( 'MVWEB_GW_VERSION',  '1.0.1' );
define( 'MVWEB_GW_PATH',     plugin_dir_path( __FILE__ ) );
define( 'MVWEB_GW_URL',      plugin_dir_url( __FILE__ ) );
define( 'MVWEB_GW_BASENAME', plugin_basename( __FILE__ ) );

// Shared classes path (monorepo dev fallback).
$shared_path = dirname( dirname( MVWEB_GW_PATH ) ) . '/shared/';

// Load MVweb Menu — prefer bundled version, fallback to shared for dev.
if ( file_exists( MVWEB_GW_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_GW_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Always call get_instance() here — do NOT rely on call at end of class file.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_GW_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_GW_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}
if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-gallery-wall' );
}

// Self-registration via filter (no need to edit shared file).
add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-gallery-wall'] = array(
		'name'         => 'MVweb Gallery Wall',
		'description'  => __( 'Customizable photo gallery with grid, masonry, ticker and lightbox.', 'mvweb-gallery-wall' ),
		'url'          => 'https://mvweb.ru/plugins/mvweb-gallery-wall',
		'settings_url' => 'admin.php?page=mvweb-gallery-wall',
		'textdomain'   => 'mvweb-gallery-wall',
	);
	return $plugins;
} );

// Load core classes.
require_once MVWEB_GW_PATH . 'includes/class-mvweb-gw-cpt.php';
require_once MVWEB_GW_PATH . 'includes/class-mvweb-gw-settings.php';
require_once MVWEB_GW_PATH . 'includes/class-mvweb-gw-editor.php';
require_once MVWEB_GW_PATH . 'includes/class-mvweb-gw-admin.php';
require_once MVWEB_GW_PATH . 'includes/class-mvweb-gw-render.php';
require_once MVWEB_GW_PATH . 'includes/class-mvweb-gw-shortcode.php';
require_once MVWEB_GW_PATH . 'includes/class-mvweb-gw-lightbox.php';
require_once MVWEB_GW_PATH . 'includes/class-mvweb-gw-ajax.php';
require_once MVWEB_GW_PATH . 'includes/class-mvweb-gw-widget.php';

// Activation / deactivation hooks.
register_activation_hook( __FILE__, 'mvweb_gw_activate' );
register_deactivation_hook( __FILE__, 'mvweb_gw_deactivate' );

/**
 * Plugin activation.
 *
 * Register CPT, flush rewrite rules, set default settings.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_gw_activate() {
	// Register CPT first so rewrite rules include it.
	mvweb_gw_register_cpt();
	flush_rewrite_rules();

	// Set default settings (will not overwrite existing). Not autoloaded — admin/render only.
	add_option( 'mvweb_gw_settings', mvweb_gw_get_defaults(), '', 'no' );
}

/**
 * Plugin deactivation.
 *
 * Flush rewrite rules to remove CPT rewrites.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_gw_deactivate() {
	flush_rewrite_rules();
}

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_gw_load_textdomain() {
	load_plugin_textdomain( 'mvweb-gallery-wall', false, dirname( MVWEB_GW_BASENAME ) . '/languages' );
}
add_action( 'plugins_loaded', 'mvweb_gw_load_textdomain' );

// Initialize CPT registration on init.
add_action( 'init', 'mvweb_gw_register_cpt' );

// Initialize admin.
if ( is_admin() ) {
	MVweb_GW_Admin::init();
	MVweb_GW_Editor::init();
}

// Initialize frontend shortcode.
MVweb_GW_Shortcode::init();

// Initialize AJAX handlers.
MVweb_GW_Ajax::init();

// Register widget.
add_action( 'widgets_init', function () {
	register_widget( 'MVweb_GW_Widget' );
} );
