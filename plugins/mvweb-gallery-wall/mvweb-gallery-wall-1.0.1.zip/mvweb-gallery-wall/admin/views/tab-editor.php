<?php
/**
 * Collection editor tab template.
 *
 * Renders the full editor form for creating/editing a gallery collection.
 * Uses MVweb Admin UI Kit (.mvweb-block / .mvweb-form-row / .mvweb-alert).
 *
 * @package MVweb_Gallery_Wall
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$collection_id = isset( $_GET['collection_id'] ) ? absint( $_GET['collection_id'] ) : 0;
$is_new        = ( 0 === $collection_id );
$defaults      = mvweb_gw_get_defaults();

// Load collection data or defaults.
if ( ! $is_new ) {
	$collection = MVweb_GW_Editor::get_collection( $collection_id );
	if ( ! $collection ) {
		?>
		<div class="mvweb-alert mvweb-alert--error">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
			<div class="mvweb-alert__body"><?php esc_html_e( 'Collection not found.', 'mvweb-gallery-wall' ); ?></div>
		</div>
		<?php
		return;
	}
} else {
	$collection = array(
		'ID'                         => 0,
		'post_title'                 => '',
		'post_status'                => 'draft',
		'_mvweb_gw_layout'           => $defaults['default_layout'],
		'_mvweb_gw_columns_desktop'  => $defaults['default_columns_desktop'],
		'_mvweb_gw_columns_tablet'   => $defaults['default_columns_tablet'],
		'_mvweb_gw_columns_mobile'   => $defaults['default_columns_mobile'],
		'_mvweb_gw_gap'              => $defaults['default_gap'],
		'_mvweb_gw_radius'           => $defaults['default_radius'],
		'_mvweb_gw_aspect_ratio'     => $defaults['default_aspect_ratio'],
		'_mvweb_gw_aspect_custom'    => '',
		'_mvweb_gw_object_fit'       => $defaults['default_object_fit'],
		'_mvweb_gw_max_width'        => $defaults['default_max_width'],
		'_mvweb_gw_row_height'       => $defaults['default_row_height'],
		'_mvweb_gw_animation'        => $defaults['default_animation'],
		'_mvweb_gw_hover'            => $defaults['default_hover'],
		'_mvweb_gw_lightbox'         => $defaults['default_lightbox'],
		'_mvweb_gw_show_title'       => $defaults['default_show_title'],
		'_mvweb_gw_overlay_mode'     => $defaults['default_overlay_mode'],
		'_mvweb_gw_link_target'      => $defaults['default_link_target'],
		'_mvweb_gw_order'            => 'manual',
		'_mvweb_gw_per_page'         => $defaults['default_per_page'],
		'_mvweb_gw_load_more_text'   => $defaults['default_load_more_text'],
		'_mvweb_gw_css_class'        => '',
		'_mvweb_gw_ticker_speed'     => $defaults['default_ticker_speed'],
		'_mvweb_gw_ticker_direction' => $defaults['default_ticker_direction'],
		'_mvweb_gw_ticker_pause'     => $defaults['default_ticker_pause'],
		'_mvweb_gw_ticker_width'     => $defaults['default_ticker_width'],
		'_mvweb_gw_ticker_gap'       => $defaults['default_ticker_gap'],
		'_mvweb_gw_ticker_ratio'     => $defaults['default_ticker_ratio'],
		'_mvweb_gw_ticker_fit'       => $defaults['default_ticker_fit'],
		'_mvweb_gw_ticker_center_scale' => $defaults['default_ticker_center_scale'],
		'_mvweb_gw_photos'           => '[]',
	);
}

// Parse photos.
$photos_raw = is_string( $collection['_mvweb_gw_photos'] ) ? $collection['_mvweb_gw_photos'] : '[]';
$photos     = json_decode( $photos_raw, true );
$photos     = is_array( $photos ) ? $photos : array();

// Show saved notice — only when the editor tab is the active one, otherwise the
// editor markup (always present in the DOM) would also fire on the Settings tab.
$gw_active_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'collections'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switch.
if ( isset( $_GET['saved'] ) && '1' === $_GET['saved'] && 'editor' === $gw_active_tab ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only notice after redirect.
	?>
	<div class="mvweb-alert mvweb-alert--success">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
		<div class="mvweb-alert__body"><?php esc_html_e( 'Collection saved.', 'mvweb-gallery-wall' ); ?></div>
	</div>
	<?php
}

$back_url = admin_url( 'admin.php?page=mvweb-gallery-wall&tab=collections' );
?>

<div class="mvweb-gw-editor-header">
	<a href="<?php echo esc_url( $back_url ); ?>" class="mvweb-btn mvweb-btn--ghost">
		&larr; <?php esc_html_e( 'Back to Collections', 'mvweb-gallery-wall' ); ?>
	</a>
	<h2 class="mvweb-gw-editor-title">
		<?php echo $is_new ? esc_html__( 'New Collection', 'mvweb-gallery-wall' ) : esc_html__( 'Edit Collection', 'mvweb-gallery-wall' ); ?>
	</h2>
</div>

<form method="post" action="" id="mvweb-gw-editor-form" class="mvweb-gw-editor">
	<?php wp_nonce_field( 'mvweb_gw_editor_save', 'mvweb_gw_editor_nonce' ); ?>
	<input type="hidden" name="collection_id" value="<?php echo esc_attr( $collection_id ); ?>">

	<!-- Section A: Basic -->
	<div class="mvweb-block mvweb-gw-editor__section">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Basic', 'mvweb-gallery-wall' ); ?></div>
		</div>

		<div class="mvweb-gw-editor__basic-row">
			<div class="mvweb-form-group mvweb-gw-editor__name-group">
				<label class="mvweb-form-row__label" for="collection_title">
					<?php esc_html_e( 'Collection Name', 'mvweb-gallery-wall' ); ?>
				</label>
				<input type="text" id="collection_title" name="collection_title"
					   class="mvweb-input"
					   value="<?php echo esc_attr( $collection['post_title'] ); ?>"
					   placeholder="<?php esc_attr_e( 'My Gallery', 'mvweb-gallery-wall' ); ?>">
			</div>

			<div class="mvweb-form-group mvweb-gw-editor__layout-group">
				<label class="mvweb-form-row__label" for="mvweb_gw_layout">
					<?php esc_html_e( 'Layout', 'mvweb-gallery-wall' ); ?>
				</label>
				<select id="mvweb_gw_layout" name="_mvweb_gw_layout" class="mvweb-select" data-gw-layout-select>
					<option value="grid" <?php selected( $collection['_mvweb_gw_layout'], 'grid' ); ?>><?php esc_html_e( 'Grid', 'mvweb-gallery-wall' ); ?></option>
					<option value="masonry" <?php selected( $collection['_mvweb_gw_layout'], 'masonry' ); ?>><?php esc_html_e( 'Masonry', 'mvweb-gallery-wall' ); ?></option>
					<option value="justified" <?php selected( $collection['_mvweb_gw_layout'], 'justified' ); ?>><?php esc_html_e( 'Justified', 'mvweb-gallery-wall' ); ?></option>
					<option value="ticker" <?php selected( $collection['_mvweb_gw_layout'], 'ticker' ); ?>><?php esc_html_e( 'Ticker', 'mvweb-gallery-wall' ); ?></option>
				</select>
			</div>

			<div class="mvweb-form-group mvweb-gw-editor__status-group">
				<span class="mvweb-form-row__label"><?php esc_html_e( 'Status', 'mvweb-gallery-wall' ); ?></span>
				<label class="mvweb-check">
					<input type="checkbox" name="collection_status" value="1" <?php checked( $collection['post_status'], 'publish' ); ?>>
					<?php esc_html_e( 'Published', 'mvweb-gallery-wall' ); ?>
				</label>
			</div>
		</div>

		<?php if ( ! $is_new ) : ?>
		<div class="mvweb-gw-editor__shortcode-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Shortcode', 'mvweb-gallery-wall' ); ?></span>
			<div class="mvweb-gw-editor__shortcode-wrap">
				<code class="mvweb-gw-shortcode-code">[mvweb_gallery id="<?php echo esc_attr( $collection_id ); ?>"]</code>
				<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-gw-copy-btn"
						data-copy="[mvweb_gallery id=&quot;<?php echo esc_attr( $collection_id ); ?>&quot;]">
					<span class="dashicons dashicons-clipboard"></span>
					<?php esc_html_e( 'Copy', 'mvweb-gallery-wall' ); ?>
				</button>
			</div>
		</div>
		<?php endif; ?>
	</div>

	<!-- Section B: Photos -->
	<div class="mvweb-block mvweb-gw-editor__section">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Photos', 'mvweb-gallery-wall' ); ?></div>
		</div>

		<div class="mvweb-gw-editor__photos-toolbar">
			<button type="button" id="mvweb-gw-add-photos" class="mvweb-btn mvweb-btn--secondary">
				<span class="dashicons dashicons-format-gallery"></span>
				<?php esc_html_e( 'Add Photos', 'mvweb-gallery-wall' ); ?>
			</button>
			<span class="mvweb-gw-photo-count">
				<?php
				printf(
					/* translators: %d: Number of photos */
					esc_html__( '%d photos', 'mvweb-gallery-wall' ),
					count( $photos )
				);
				?>
			</span>
		</div>

		<div id="mvweb-gw-photo-list" class="mvweb-gw-photo-list">
			<?php if ( empty( $photos ) ) : ?>
			<div class="mvweb-gw-photo-list__empty">
				<p><?php esc_html_e( 'No photos added. Click "Add Photos" to select images from the Media Library.', 'mvweb-gallery-wall' ); ?></p>
			</div>
			<?php endif; ?>
			<?php foreach ( $photos as $index => $photo ) :
				$thumb_url = wp_get_attachment_image_url( $photo['attachment_id'], 'thumbnail' );
				if ( ! $thumb_url ) {
					continue;
				}
				$tags_str = ! empty( $photo['tags'] ) ? implode( ', ', $photo['tags'] ) : '';
			?>
			<div class="mvweb-gw-photo-item" data-index="<?php echo esc_attr( $index ); ?>">
				<div class="mvweb-gw-photo-item__handle">
					<span class="dashicons dashicons-move"></span>
				</div>
				<div class="mvweb-gw-photo-item__thumb">
					<img src="<?php echo esc_url( $thumb_url ); ?>" alt="" width="80" height="80">
				</div>
				<div class="mvweb-gw-photo-item__fields">
					<input type="hidden" class="mvweb-gw-photo-field" data-field="attachment_id" value="<?php echo esc_attr( $photo['attachment_id'] ); ?>">
					<input type="hidden" class="mvweb-gw-photo-field" data-field="width" value="<?php echo esc_attr( $photo['width'] ); ?>">
					<input type="hidden" class="mvweb-gw-photo-field" data-field="height" value="<?php echo esc_attr( $photo['height'] ); ?>">
					<div class="mvweb-gw-photo-item__field-row">
						<input type="text" class="mvweb-gw-photo-field" data-field="title"
							   value="<?php echo esc_attr( $photo['title'] ); ?>"
							   placeholder="<?php esc_attr_e( 'Title', 'mvweb-gallery-wall' ); ?>">
						<input type="text" class="mvweb-gw-photo-field" data-field="caption"
							   value="<?php echo esc_attr( $photo['caption'] ); ?>"
							   placeholder="<?php esc_attr_e( 'Caption', 'mvweb-gallery-wall' ); ?>">
					</div>
					<div class="mvweb-gw-photo-item__field-row">
						<input type="url" class="mvweb-gw-photo-field" data-field="link"
							   value="<?php echo esc_url( $photo['link'] ); ?>"
							   placeholder="<?php esc_attr_e( 'Link URL', 'mvweb-gallery-wall' ); ?>">
						<input type="text" class="mvweb-gw-photo-field" data-field="tags"
							   value="<?php echo esc_attr( $tags_str ); ?>"
							   placeholder="<?php esc_attr_e( 'Tags (comma separated)', 'mvweb-gallery-wall' ); ?>">
					</div>
				</div>
				<div class="mvweb-gw-photo-item__actions">
					<button type="button" class="mvweb-btn mvweb-btn--danger mvweb-btn--sm mvweb-gw-remove-photo"
							title="<?php esc_attr_e( 'Remove', 'mvweb-gallery-wall' ); ?>">
						<span class="dashicons dashicons-trash"></span>
					</button>
				</div>
			</div>
			<?php endforeach; ?>
		</div>

		<input type="hidden" id="mvweb-gw-photos-json" name="_mvweb_gw_photos" value="<?php echo esc_attr( $photos_raw ); ?>">
	</div>

	<!-- Live Preview -->
	<div class="mvweb-block mvweb-gw-editor__section">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Preview', 'mvweb-gallery-wall' ); ?></div>
		</div>
		<div id="mvweb-gw-preview" class="mvweb-gw-preview">
			<div class="mvweb-gw-preview__empty">
				<p><?php esc_html_e( 'Add photos and adjust settings to see a live preview.', 'mvweb-gallery-wall' ); ?></p>
			</div>
		</div>
	</div>

	<!-- Section C: Grid Settings (Grid/Masonry/Justified) -->
	<div class="mvweb-block mvweb-gw-editor__section" data-gw-show-if="grid,masonry,justified">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Grid Settings', 'mvweb-gallery-wall' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_columns_desktop" class="mvweb-form-row__label"><?php esc_html_e( 'Columns (Desktop)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_columns_desktop" name="_mvweb_gw_columns_desktop"
					   value="<?php echo esc_attr( $collection['_mvweb_gw_columns_desktop'] ); ?>"
					   min="1" max="8" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_columns_tablet" class="mvweb-form-row__label"><?php esc_html_e( 'Columns (Tablet)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_columns_tablet" name="_mvweb_gw_columns_tablet"
					   value="<?php echo esc_attr( $collection['_mvweb_gw_columns_tablet'] ); ?>"
					   min="1" max="6" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_columns_mobile" class="mvweb-form-row__label"><?php esc_html_e( 'Columns (Mobile)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_columns_mobile" name="_mvweb_gw_columns_mobile"
					   value="<?php echo esc_attr( $collection['_mvweb_gw_columns_mobile'] ); ?>"
					   min="1" max="4" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_gap" class="mvweb-form-row__label"><?php esc_html_e( 'Gap (px)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_gap" name="_mvweb_gw_gap"
					   value="<?php echo esc_attr( $collection['_mvweb_gw_gap'] ); ?>"
					   min="0" max="60" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_radius" class="mvweb-form-row__label"><?php esc_html_e( 'Border Radius (px)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_radius" name="_mvweb_gw_radius"
					   value="<?php echo esc_attr( $collection['_mvweb_gw_radius'] ); ?>"
					   min="0" max="50" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_aspect_ratio" class="mvweb-form-row__label"><?php esc_html_e( 'Aspect Ratio', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_gw_aspect_ratio" name="_mvweb_gw_aspect_ratio" class="mvweb-select">
					<option value="1:1" <?php selected( $collection['_mvweb_gw_aspect_ratio'], '1:1' ); ?>>1:1</option>
					<option value="4:3" <?php selected( $collection['_mvweb_gw_aspect_ratio'], '4:3' ); ?>>4:3</option>
					<option value="16:9" <?php selected( $collection['_mvweb_gw_aspect_ratio'], '16:9' ); ?>>16:9</option>
					<option value="3:2" <?php selected( $collection['_mvweb_gw_aspect_ratio'], '3:2' ); ?>>3:2</option>
					<option value="auto" <?php selected( $collection['_mvweb_gw_aspect_ratio'], 'auto' ); ?>><?php esc_html_e( 'Auto (original)', 'mvweb-gallery-wall' ); ?></option>
					<option value="custom" <?php selected( $collection['_mvweb_gw_aspect_ratio'], 'custom' ); ?>><?php esc_html_e( 'Custom', 'mvweb-gallery-wall' ); ?></option>
				</select>
				<input type="text" id="mvweb_gw_aspect_custom" name="_mvweb_gw_aspect_custom"
					   value="<?php echo esc_attr( $collection['_mvweb_gw_aspect_custom'] ); ?>"
					   placeholder="<?php esc_attr_e( 'e.g. 5/4', 'mvweb-gallery-wall' ); ?>"
					   class="mvweb-input mvweb-gw-aspect-custom-field"
					   style="<?php echo esc_attr( 'custom' !== $collection['_mvweb_gw_aspect_ratio'] ? 'display:none;' : '' ); ?>">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_object_fit" class="mvweb-form-row__label"><?php esc_html_e( 'Object Fit', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_gw_object_fit" name="_mvweb_gw_object_fit" class="mvweb-select">
					<option value="cover" <?php selected( $collection['_mvweb_gw_object_fit'], 'cover' ); ?>><?php esc_html_e( 'Cover', 'mvweb-gallery-wall' ); ?></option>
					<option value="contain" <?php selected( $collection['_mvweb_gw_object_fit'], 'contain' ); ?>><?php esc_html_e( 'Contain', 'mvweb-gallery-wall' ); ?></option>
					<option value="fill" <?php selected( $collection['_mvweb_gw_object_fit'], 'fill' ); ?>><?php esc_html_e( 'Fill', 'mvweb-gallery-wall' ); ?></option>
					<option value="none" <?php selected( $collection['_mvweb_gw_object_fit'], 'none' ); ?>><?php esc_html_e( 'None', 'mvweb-gallery-wall' ); ?></option>
					<option value="scale-down" <?php selected( $collection['_mvweb_gw_object_fit'], 'scale-down' ); ?>><?php esc_html_e( 'Scale Down', 'mvweb-gallery-wall' ); ?></option>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_max_width" class="mvweb-form-row__label"><?php esc_html_e( 'Max Width', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb_gw_max_width" name="_mvweb_gw_max_width"
					   value="<?php echo esc_attr( $collection['_mvweb_gw_max_width'] ); ?>"
					   placeholder="100%" class="mvweb-input">
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'e.g. 100%, 1200px, 1400px', 'mvweb-gallery-wall' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row" data-gw-show-if="justified">
			<label for="mvweb_gw_row_height" class="mvweb-form-row__label"><?php esc_html_e( 'Row Height (px)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_row_height" name="_mvweb_gw_row_height"
					   value="<?php echo esc_attr( $collection['_mvweb_gw_row_height'] ); ?>"
					   min="120" max="400" class="mvweb-input">
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Target row height for justified layout (120-400).', 'mvweb-gallery-wall' ); ?></p>
			</div>
		</div>
	</div>

	<!-- Section D: Ticker Settings -->
	<div class="mvweb-block mvweb-gw-editor__section" data-gw-show-if="ticker">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Ticker Settings', 'mvweb-gallery-wall' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_ticker_speed" class="mvweb-form-row__label"><?php esc_html_e( 'Speed (seconds)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_ticker_speed" name="_mvweb_gw_ticker_speed"
					   value="<?php echo esc_attr( $collection['_mvweb_gw_ticker_speed'] ); ?>"
					   min="10" max="120" class="mvweb-input">
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Time for one full cycle (10-120 seconds).', 'mvweb-gallery-wall' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_ticker_direction" class="mvweb-form-row__label"><?php esc_html_e( 'Direction', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_gw_ticker_direction" name="_mvweb_gw_ticker_direction" class="mvweb-select">
					<option value="left" <?php selected( $collection['_mvweb_gw_ticker_direction'], 'left' ); ?>><?php esc_html_e( 'Left', 'mvweb-gallery-wall' ); ?></option>
					<option value="right" <?php selected( $collection['_mvweb_gw_ticker_direction'], 'right' ); ?>><?php esc_html_e( 'Right', 'mvweb-gallery-wall' ); ?></option>
					<option value="up" <?php selected( $collection['_mvweb_gw_ticker_direction'], 'up' ); ?>><?php esc_html_e( 'Up', 'mvweb-gallery-wall' ); ?></option>
					<option value="down" <?php selected( $collection['_mvweb_gw_ticker_direction'], 'down' ); ?>><?php esc_html_e( 'Down', 'mvweb-gallery-wall' ); ?></option>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Pause on Hover', 'mvweb-gallery-wall' ); ?></span>
			<div class="mvweb-form-row__field">
				<label class="mvweb-check">
					<input type="checkbox" name="_mvweb_gw_ticker_pause" value="1" <?php checked( $collection['_mvweb_gw_ticker_pause'] ); ?>>
					<?php esc_html_e( 'Pause when hovering over the ticker', 'mvweb-gallery-wall' ); ?>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_ticker_width" class="mvweb-form-row__label"><?php esc_html_e( 'Photo Width (px)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_ticker_width" name="_mvweb_gw_ticker_width"
					   value="<?php echo esc_attr( $collection['_mvweb_gw_ticker_width'] ); ?>"
					   min="50" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_ticker_gap" class="mvweb-form-row__label"><?php esc_html_e( 'Photo Spacing (px)', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_ticker_gap" name="_mvweb_gw_ticker_gap"
					   value="<?php echo esc_attr( $collection['_mvweb_gw_ticker_gap'] ); ?>"
					   min="0" max="100" step="1" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_ticker_ratio_preset" class="mvweb-form-row__label"><?php esc_html_e( 'Photo Aspect Ratio', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<?php
				$gw_ticker_ratio        = $collection['_mvweb_gw_ticker_ratio'];
				$gw_ticker_ratio_presets = array( '16/9', '4/3', '3/2', '1/1', '3/4', '9/16' );
				$gw_ticker_ratio_is_custom = ( '' !== $gw_ticker_ratio && ! in_array( $gw_ticker_ratio, $gw_ticker_ratio_presets, true ) );
				?>
				<select id="mvweb_gw_ticker_ratio_preset" class="mvweb-select mvweb-gw-ticker-ratio-preset">
					<?php foreach ( $gw_ticker_ratio_presets as $gw_ratio_opt ) : ?>
						<option value="<?php echo esc_attr( $gw_ratio_opt ); ?>" <?php selected( $gw_ticker_ratio, $gw_ratio_opt ); ?>><?php echo esc_html( str_replace( '/', ':', $gw_ratio_opt ) ); ?></option>
					<?php endforeach; ?>
					<option value="custom" <?php selected( $gw_ticker_ratio_is_custom, true ); ?>><?php esc_html_e( 'Custom', 'mvweb-gallery-wall' ); ?></option>
				</select>
				<input type="text" id="mvweb_gw_ticker_ratio" name="_mvweb_gw_ticker_ratio"
					   value="<?php echo esc_attr( $gw_ticker_ratio ); ?>"
					   placeholder="16/9" class="mvweb-input mvweb-gw-ticker-ratio-custom"
					   style="<?php echo esc_attr( $gw_ticker_ratio_is_custom ? '' : 'display:none;' ); ?>">
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Proportions of each photo in the strip. Choose a preset or set your own (e.g. 5/4).', 'mvweb-gallery-wall' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_ticker_fit" class="mvweb-form-row__label"><?php esc_html_e( 'Photo Fit', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_gw_ticker_fit" name="_mvweb_gw_ticker_fit" class="mvweb-select">
					<option value="cover" <?php selected( $collection['_mvweb_gw_ticker_fit'], 'cover' ); ?>><?php esc_html_e( 'Crop to fill (Cover)', 'mvweb-gallery-wall' ); ?></option>
					<option value="contain" <?php selected( $collection['_mvweb_gw_ticker_fit'], 'contain' ); ?>><?php esc_html_e( 'Show whole photo (Contain)', 'mvweb-gallery-wall' ); ?></option>
					<option value="fill" <?php selected( $collection['_mvweb_gw_ticker_fit'], 'fill' ); ?>><?php esc_html_e( 'Stretch (Fill)', 'mvweb-gallery-wall' ); ?></option>
				</select>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'How each photo fits its slot. "Crop" fills the slot and may trim edges; "Show whole photo" never crops but may leave gaps.', 'mvweb-gallery-wall' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_ticker_center_scale" class="mvweb-form-row__label"><?php esc_html_e( 'Center Zoom', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_gw_ticker_center_scale" name="_mvweb_gw_ticker_center_scale" class="mvweb-select">
					<?php
					$gw_center_scale = $collection['_mvweb_gw_ticker_center_scale'];
					$gw_scale_opts   = array(
						'0'   => __( 'Off', 'mvweb-gallery-wall' ),
						'110' => __( 'Subtle (110%)', 'mvweb-gallery-wall' ),
						'115' => __( 'Medium (115%)', 'mvweb-gallery-wall' ),
						'120' => __( 'Strong (120%)', 'mvweb-gallery-wall' ),
					);
					foreach ( $gw_scale_opts as $gw_scale_val => $gw_scale_label ) :
						?>
						<option value="<?php echo esc_attr( $gw_scale_val ); ?>" <?php selected( (string) $gw_center_scale, $gw_scale_val ); ?>><?php echo esc_html( $gw_scale_label ); ?></option>
					<?php endforeach; ?>
				</select>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Smoothly enlarge each photo as it passes the center of the strip for an eye-catching effect.', 'mvweb-gallery-wall' ); ?></p>
			</div>
		</div>
	</div>

	<!-- Section E: Animation & Effects (not used by the ticker layout) -->
	<div class="mvweb-block mvweb-gw-editor__section" data-gw-show-if="grid,masonry,justified">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Animation & Effects', 'mvweb-gallery-wall' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_animation" class="mvweb-form-row__label"><?php esc_html_e( 'Entrance Animation', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_gw_animation" name="_mvweb_gw_animation" class="mvweb-select">
					<option value="fade" <?php selected( $collection['_mvweb_gw_animation'], 'fade' ); ?>><?php esc_html_e( 'Fade', 'mvweb-gallery-wall' ); ?></option>
					<option value="slide-up" <?php selected( $collection['_mvweb_gw_animation'], 'slide-up' ); ?>><?php esc_html_e( 'Slide Up', 'mvweb-gallery-wall' ); ?></option>
					<option value="slide-left" <?php selected( $collection['_mvweb_gw_animation'], 'slide-left' ); ?>><?php esc_html_e( 'Slide Left', 'mvweb-gallery-wall' ); ?></option>
					<option value="scale" <?php selected( $collection['_mvweb_gw_animation'], 'scale' ); ?>><?php esc_html_e( 'Scale', 'mvweb-gallery-wall' ); ?></option>
					<option value="flip" <?php selected( $collection['_mvweb_gw_animation'], 'flip' ); ?>><?php esc_html_e( 'Flip', 'mvweb-gallery-wall' ); ?></option>
					<option value="none" <?php selected( $collection['_mvweb_gw_animation'], 'none' ); ?>><?php esc_html_e( 'None', 'mvweb-gallery-wall' ); ?></option>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_hover" class="mvweb-form-row__label"><?php esc_html_e( 'Hover Effect', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_gw_hover" name="_mvweb_gw_hover" class="mvweb-select">
					<option value="zoom" <?php selected( $collection['_mvweb_gw_hover'], 'zoom' ); ?>><?php esc_html_e( 'Zoom', 'mvweb-gallery-wall' ); ?></option>
					<option value="grayscale" <?php selected( $collection['_mvweb_gw_hover'], 'grayscale' ); ?>><?php esc_html_e( 'Grayscale', 'mvweb-gallery-wall' ); ?></option>
					<option value="brightness" <?php selected( $collection['_mvweb_gw_hover'], 'brightness' ); ?>><?php esc_html_e( 'Brightness', 'mvweb-gallery-wall' ); ?></option>
					<option value="overlay" <?php selected( $collection['_mvweb_gw_hover'], 'overlay' ); ?>><?php esc_html_e( 'Overlay', 'mvweb-gallery-wall' ); ?></option>
					<option value="none" <?php selected( $collection['_mvweb_gw_hover'], 'none' ); ?>><?php esc_html_e( 'None', 'mvweb-gallery-wall' ); ?></option>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Lightbox', 'mvweb-gallery-wall' ); ?></span>
			<div class="mvweb-form-row__field">
				<label class="mvweb-check">
					<input type="checkbox" name="_mvweb_gw_lightbox" value="1" <?php checked( $collection['_mvweb_gw_lightbox'] ); ?>>
					<?php esc_html_e( 'Enable lightbox for photos without links', 'mvweb-gallery-wall' ); ?>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_overlay_mode" class="mvweb-form-row__label"><?php esc_html_e( 'Overlay', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_gw_overlay_mode" name="_mvweb_gw_overlay_mode" class="mvweb-select">
					<option value="hover" <?php selected( $collection['_mvweb_gw_overlay_mode'], 'hover' ); ?>><?php esc_html_e( 'Show on hover', 'mvweb-gallery-wall' ); ?></option>
					<option value="always" <?php selected( $collection['_mvweb_gw_overlay_mode'], 'always' ); ?>><?php esc_html_e( 'Always visible', 'mvweb-gallery-wall' ); ?></option>
					<option value="none" <?php selected( $collection['_mvweb_gw_overlay_mode'], 'none' ); ?>><?php esc_html_e( 'Hidden', 'mvweb-gallery-wall' ); ?></option>
				</select>
			</div>
		</div>
	</div>

	<!-- Section F: Additional -->
	<div class="mvweb-block mvweb-gw-editor__section">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Additional', 'mvweb-gallery-wall' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_order" class="mvweb-form-row__label"><?php esc_html_e( 'Photo Order', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_gw_order" name="_mvweb_gw_order" class="mvweb-select">
					<option value="manual" <?php selected( $collection['_mvweb_gw_order'], 'manual' ); ?>><?php esc_html_e( 'Manual (drag & drop)', 'mvweb-gallery-wall' ); ?></option>
					<option value="random" <?php selected( $collection['_mvweb_gw_order'], 'random' ); ?>><?php esc_html_e( 'Random', 'mvweb-gallery-wall' ); ?></option>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Show Title', 'mvweb-gallery-wall' ); ?></span>
			<div class="mvweb-form-row__field">
				<label class="mvweb-check">
					<input type="checkbox" name="_mvweb_gw_show_title" value="1" <?php checked( $collection['_mvweb_gw_show_title'] ); ?>>
					<?php esc_html_e( 'Show collection title above the gallery', 'mvweb-gallery-wall' ); ?>
				</label>
			</div>
		</div>

		<div class="mvweb-form-row" data-gw-show-if="grid,masonry,justified">
			<label for="mvweb_gw_per_page" class="mvweb-form-row__label"><?php esc_html_e( 'Photos per Page', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" id="mvweb_gw_per_page" name="_mvweb_gw_per_page"
					   value="<?php echo esc_attr( $collection['_mvweb_gw_per_page'] ); ?>"
					   min="0" class="mvweb-input">
				<p class="mvweb-form-row__desc"><?php esc_html_e( '0 = show all photos. Otherwise, shows "Load More" button.', 'mvweb-gallery-wall' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row" data-gw-show-if="grid,masonry,justified">
			<label for="mvweb_gw_load_more_text" class="mvweb-form-row__label"><?php esc_html_e( 'Load More Text', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb_gw_load_more_text" name="_mvweb_gw_load_more_text"
					   value="<?php echo esc_attr( $collection['_mvweb_gw_load_more_text'] ); ?>"
					   placeholder="<?php esc_attr_e( 'Show More', 'mvweb-gallery-wall' ); ?>" class="mvweb-input">
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_link_target" class="mvweb-form-row__label"><?php esc_html_e( 'Link Target', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb_gw_link_target" name="_mvweb_gw_link_target" class="mvweb-select">
					<option value="_blank" <?php selected( $collection['_mvweb_gw_link_target'], '_blank' ); ?>><?php esc_html_e( 'New window (_blank)', 'mvweb-gallery-wall' ); ?></option>
					<option value="_self" <?php selected( $collection['_mvweb_gw_link_target'], '_self' ); ?>><?php esc_html_e( 'Same window (_self)', 'mvweb-gallery-wall' ); ?></option>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb_gw_css_class" class="mvweb-form-row__label"><?php esc_html_e( 'CSS Class', 'mvweb-gallery-wall' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb_gw_css_class" name="_mvweb_gw_css_class"
					   value="<?php echo esc_attr( $collection['_mvweb_gw_css_class'] ); ?>"
					   placeholder="<?php esc_attr_e( 'Optional additional CSS class', 'mvweb-gallery-wall' ); ?>"
					   class="mvweb-input">
			</div>
		</div>
	</div>

	<div class="mvweb-submit mvweb-gw-editor__submit">
		<button type="submit" name="mvweb_gw_save_collection" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Save Collection', 'mvweb-gallery-wall' ); ?>
		</button>
		<a href="<?php echo esc_url( $back_url ); ?>" class="mvweb-btn">
			<?php esc_html_e( 'Cancel', 'mvweb-gallery-wall' ); ?>
		</a>
	</div>
</form>
