<?php
/**
 * Push block on the profile screen.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

use MVweb\BrowserPush\Admin\Profile;
use MVweb\BrowserPush\Subscriptions\Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<h2 id="mvweb-bp"><?php esc_html_e( 'Notifications about new WooCommerce orders', 'mvweb-browser-push' ); ?></h2>
<p><?php esc_html_e( 'Get a notification in this browser about every new order in the store. Turn it on separately in each browser you use.', 'mvweb-browser-push' ); ?></p>

<table class="form-table mvweb-bp-block" role="presentation">
	<tr>
		<th scope="row"><?php esc_html_e( 'This browser', 'mvweb-browser-push' ); ?></th>
		<td>
			<p class="mvweb-bp-state" aria-live="polite"></p>
			<p>
				<button type="button" class="button button-primary mvweb-bp-enable" hidden><?php esc_html_e( 'Enable in this browser', 'mvweb-browser-push' ); ?></button>
				<button type="button" class="button mvweb-bp-test" hidden><?php esc_html_e( 'Send test', 'mvweb-browser-push' ); ?></button>
				<button type="button" class="button mvweb-bp-disable" hidden><?php esc_html_e( 'Disable in this browser', 'mvweb-browser-push' ); ?></button>
			</p>
		</td>
	</tr>
</table>

<?php if ( $subs ) : ?>
	<div class="mvweb-bp-devices">
		<h3><?php esc_html_e( 'My devices', 'mvweb-browser-push' ); ?></h3>
		<table class="widefat striped">
			<thead>
				<tr>
					<td class="manage-column column-cb check-column">
						<label class="screen-reader-text" for="mvweb-bp-remove-all"><?php esc_html_e( 'Remove', 'mvweb-browser-push' ); ?></label>
						<input type="checkbox" id="mvweb-bp-remove-all">
					</td>
					<th scope="col"><?php esc_html_e( 'Browser', 'mvweb-browser-push' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Added', 'mvweb-browser-push' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Last delivery', 'mvweb-browser-push' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Status', 'mvweb-browser-push' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $subs as $mvweb_bp_hash => $mvweb_bp_sub ) : ?>
					<tr>
						<th scope="row" class="check-column">
							<label class="screen-reader-text" for="mvweb-bp-remove-<?php echo esc_attr( $mvweb_bp_hash ); ?>"><?php esc_html_e( 'Remove this device on save', 'mvweb-browser-push' ); ?></label>
							<input type="checkbox" id="mvweb-bp-remove-<?php echo esc_attr( $mvweb_bp_hash ); ?>" name="mvweb_bp_remove[]" value="<?php echo esc_attr( $mvweb_bp_hash ); ?>">
						</th>
						<td><?php echo esc_html( Repository::browser_label( $mvweb_bp_sub['endpoint'] ) ); ?></td>
						<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $mvweb_bp_sub['created'] ) ); ?></td>
						<td><?php echo ! empty( $mvweb_bp_sub['last_ok'] ) ? esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $mvweb_bp_sub['last_ok'] ) ) : '—'; ?></td>
						<td><?php echo esc_html( Profile::status_label( (string) $mvweb_bp_sub['last_error'] ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<p class="description"><?php esc_html_e( 'Tick devices to remove and press Update Profile.', 'mvweb-browser-push' ); ?></p>
	</div>
<?php endif; ?>
