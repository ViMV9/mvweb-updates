<?php
/**
 * Push block on the user profile screen.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Admin;

use Automattic\WooCommerce\Utilities\OrderUtil;
use MVweb\BrowserPush\Push\Vapid;
use MVweb\BrowserPush\Settings;
use MVweb\BrowserPush\Subscriptions\Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Profile {

	public function register() {
		add_action( 'show_user_profile', array( $this, 'render' ) );
		add_action( 'personal_options_update', array( $this, 'save' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
		add_action( 'admin_notices', array( $this, 'orders_notice' ) );
	}

	public function render( $user ) {
		if ( ! Settings::user_can_receive( $user->ID ) ) {
			return;
		}

		$subs = Repository::for_user( $user->ID );

		require MVWEB_BP_PATH . 'admin/views/profile-block.php';
	}

	public function save( $user_id ) {
		if ( empty( $_POST['mvweb_bp_remove'] ) || ! is_array( $_POST['mvweb_bp_remove'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing -- core verifies the profile nonce before this hook.
			return;
		}

		$owned = Repository::for_user( (int) $user_id );

		foreach ( wp_unslash( $_POST['mvweb_bp_remove'] ) as $hash ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- compared against the user's own hashes below.
			if ( is_string( $hash ) && isset( $owned[ $hash ] ) ) {
				Repository::delete( (int) $user_id, $hash );
			}
		}
	}

	public function enqueue( $hook_suffix ) {
		if ( 'profile.php' !== $hook_suffix || ! Settings::user_can_receive( get_current_user_id() ) ) {
			return;
		}

		$relative = 'admin/js/subscribe.min.js';

		wp_enqueue_style(
			'mvweb-bp-profile',
			MVWEB_BP_URL . 'admin/css/profile.min.css',
			array(),
			self::asset_version( 'admin/css/profile.min.css' )
		);

		wp_enqueue_script(
			'mvweb-bp-subscribe',
			MVWEB_BP_URL . $relative,
			array(),
			self::asset_version( $relative ),
			true
		);

		wp_localize_script(
			'mvweb-bp-subscribe',
			'mvwebBp',
			array(
				'restUrl'  => rest_url( 'mvweb-bp/v1/subscriptions' ),
				'nonce'    => wp_create_nonce( 'wp_rest' ),
				'vapidKey' => Vapid::public_key(),
				'swUrl'    => wp_make_link_relative( MVWEB_BP_URL . 'public/js/sw.js' ),
				'swScope'  => wp_make_link_relative( MVWEB_BP_URL . 'public/js/' ),
				'i18n'     => array(
					'unsupported' => __( 'Push notifications are not supported in this browser.', 'mvweb-browser-push' ),
					'blocked'     => __( 'Notifications are blocked in the browser settings for this site.', 'mvweb-browser-push' ),
					'enabled'     => __( 'Enabled in this browser.', 'mvweb-browser-push' ),
					'disabled'    => __( 'Not enabled in this browser.', 'mvweb-browser-push' ),
					'working'     => __( 'Working…', 'mvweb-browser-push' ),
					'error'       => __( 'Something went wrong. Please try again.', 'mvweb-browser-push' ),
					'testOk'      => __( 'Test sent. It should appear in a few seconds.', 'mvweb-browser-push' ),
					'testGone'    => __( 'The browser no longer accepts push for this site. Enable it again.', 'mvweb-browser-push' ),
					'testFailed'  => __( 'The push service refused the test message.', 'mvweb-browser-push' ),
					'testWait'    => __( 'Please wait half a minute before the next test.', 'mvweb-browser-push' ),
					'useDisable'  => __( 'This is the current browser. Use “Disable in this browser” instead.', 'mvweb-browser-push' ),
					'braveOff'    => __( 'Brave blocks push messages by default. Open brave://settings/privacy, turn on “Use Google Services for Push Messaging”, restart Brave and press “Enable in this browser” again.', 'mvweb-browser-push' ),
					'pushDown'    => __( 'The browser could not reach its push service. Check the internet connection and that push messaging is allowed in the browser settings, then try again.', 'mvweb-browser-push' ),
				),
			)
		);
	}

	public function orders_notice() {
		if ( ! class_exists( OrderUtil::class ) || ! OrderUtil::is_order_list_table_screen() ) {
			return;
		}

		$user_id = get_current_user_id();

		if ( ! Settings::user_can_receive( $user_id ) || array() !== Repository::for_user( $user_id ) ) {
			return;
		}

		printf(
			'<div class="notice notice-info"><p>%s <a href="%s">%s</a></p></div>',
			esc_html__( 'Get notifications in your browser about new orders in the store.', 'mvweb-browser-push' ),
			esc_url( admin_url( 'profile.php#mvweb-bp' ) ),
			esc_html__( 'Enable in your profile', 'mvweb-browser-push' )
		);
	}

	private static function asset_version( string $relative ): string {
		$path  = MVWEB_BP_PATH . $relative;
		$mtime = file_exists( $path ) ? filemtime( $path ) : 0;

		return $mtime ? (string) $mtime : MVWEB_BP_VERSION;
	}

	public static function status_label( string $code ): string {
		$labels = self::status_labels();

		return $labels[ $code ] ?? __( 'Delivery failed', 'mvweb-browser-push' );
	}

	public static function status_labels(): array {
		return array(
			''        => __( 'OK', 'mvweb-browser-push' ),
			'network' => __( 'Push service unreachable', 'mvweb-browser-push' ),
			'local'   => __( 'Message could not be prepared', 'mvweb-browser-push' ),
			'400'     => __( 'Request rejected (400)', 'mvweb-browser-push' ),
			'403'     => __( 'Sender not accepted (403)', 'mvweb-browser-push' ),
			'413'     => __( 'Message too large (413)', 'mvweb-browser-push' ),
			'429'     => __( 'Too many requests (429)', 'mvweb-browser-push' ),
		);
	}
}
