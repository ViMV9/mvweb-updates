<?php
/**
 * Push subscriptions stored as user meta, one row per browser.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Subscriptions;

use MVweb\BrowserPush\Settings;
use WP_User;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Repository {

	public const PREFIX = '_mvweb_bp_sub_';

	public const LIMIT = 10;

	public static function register(): void {
		add_action( 'after_password_reset', array( self::class, 'on_password_reset' ) );
		add_action( 'profile_update', array( self::class, 'on_profile_update' ), 10, 2 );
	}

	public static function on_password_reset( WP_User $user ): void {
		self::delete_all_for_user( $user->ID );
	}

	public static function on_profile_update( int $user_id, WP_User $old_user_data ): void {
		$current = get_userdata( $user_id );

		if ( $current && $old_user_data->user_pass !== $current->user_pass ) {
			self::delete_all_for_user( $user_id );
		}
	}

	public static function hash( string $endpoint ): string {
		return hash( 'sha256', $endpoint );
	}

	public static function save( int $user_id, string $endpoint, string $p256dh, string $auth ): string {
		$hash = self::hash( $endpoint );

		foreach ( self::owners( $hash ) as $owner ) {
			if ( $owner !== $user_id ) {
				delete_user_meta( $owner, self::PREFIX . $hash );
			}
		}

		$subs = self::for_user( $user_id );

		if ( ! isset( $subs[ $hash ] ) && count( $subs ) >= self::LIMIT ) {
			uasort(
				$subs,
				static function ( $a, $b ) {
					return (int) $a['created'] <=> (int) $b['created'];
				}
			);

			delete_user_meta( $user_id, self::PREFIX . array_key_first( $subs ) );
		}

		$existing = $subs[ $hash ] ?? array();

		update_user_meta(
			$user_id,
			self::PREFIX . $hash,
			array(
				'endpoint'   => $endpoint,
				'p256dh'     => $p256dh,
				'auth'       => $auth,
				'created'    => $existing['created'] ?? time(),
				'last_ok'    => $existing['last_ok'] ?? 0,
				'last_error' => $existing['last_error'] ?? '',
			)
		);

		return $hash;
	}

	public static function for_user( int $user_id ): array {
		$subs = array();

		foreach ( get_user_meta( $user_id ) as $key => $values ) {
			if ( 0 !== strpos( $key, self::PREFIX ) ) {
				continue;
			}

			$value = maybe_unserialize( $values[0] ?? '' );

			if ( is_array( $value ) && ! empty( $value['endpoint'] ) ) {
				$subs[ substr( $key, strlen( self::PREFIX ) ) ] = $value;
			}
		}

		return $subs;
	}

	public static function find( string $hash ): ?array {
		foreach ( self::owners( $hash ) as $owner ) {
			$sub = get_user_meta( $owner, self::PREFIX . $hash, true );

			if ( is_array( $sub ) ) {
				return array(
					'user_id' => $owner,
					'sub'     => $sub,
				);
			}
		}

		return null;
	}

	public static function delete( int $user_id, string $hash ): bool {
		return delete_user_meta( $user_id, self::PREFIX . $hash );
	}

	public static function delete_all_for_user( int $user_id ): void {
		foreach ( array_keys( self::for_user( $user_id ) ) as $hash ) {
			self::delete( $user_id, $hash );
		}
	}

	public static function recipients(): array {
		$recipients = array();

		if ( array() === Settings::roles() ) {
			return $recipients;
		}

		$user_ids = get_users(
			array(
				'role__in' => Settings::roles(),
				'fields'   => 'ID',
			)
		);

		foreach ( $user_ids as $user_id ) {
			$user_id = (int) $user_id;

			if ( ! Settings::user_can_receive( $user_id ) ) {
				continue;
			}

			foreach ( self::for_user( $user_id ) as $hash => $sub ) {
				$recipients[ $hash ] = array(
					'user_id' => $user_id,
					'sub'     => $sub,
				);
			}
		}

		return $recipients;
	}

	public static function mark( string $hash, int $user_id, string $field, $value ): void {
		$sub = get_user_meta( $user_id, self::PREFIX . $hash, true );

		if ( ! is_array( $sub ) ) {
			return;
		}

		$sub[ $field ] = $value;

		update_user_meta( $user_id, self::PREFIX . $hash, $sub );
	}

	public static function browser_label( string $endpoint ): string {
		$host = (string) wp_parse_url( $endpoint, PHP_URL_HOST );

		if ( 'fcm.googleapis.com' === $host ) {
			return __( 'Chrome, Yandex Browser, Opera, Edge (Chromium)', 'mvweb-browser-push' );
		}

		if ( str_ends_with( $host, '.mozilla.com' ) || str_ends_with( $host, '.mozaws.net' ) ) {
			return __( 'Firefox', 'mvweb-browser-push' );
		}

		if ( str_ends_with( $host, '.push.apple.com' ) ) {
			return __( 'Safari', 'mvweb-browser-push' );
		}

		if ( str_ends_with( $host, '.notify.windows.com' ) ) {
			return __( 'Edge', 'mvweb-browser-push' );
		}

		return __( 'Other browser', 'mvweb-browser-push' );
	}

	private static function owners( string $hash ): array {
		return array_map(
			'intval',
			get_users(
				array(
					'meta_key' => self::PREFIX . $hash, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- exact key, a handful of rows.
					'fields'   => 'ID',
				)
			)
		);
	}
}
