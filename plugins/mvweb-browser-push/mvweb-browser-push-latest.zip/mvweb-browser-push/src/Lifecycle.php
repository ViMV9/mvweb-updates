<?php
/**
 * Activation and deactivation handlers.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush;

use MVweb\BrowserPush\Push\Vapid;
use MVweb\BrowserPush\Queue\Dispatcher;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Lifecycle {

	public static function activate() {
		self::guard_environment();

		add_option( Settings::OPTION, Settings::defaults(), '', true );

		Vapid::ensure_keys();
	}

	public static function deactivate() {
		Dispatcher::cancel_all();
	}

	private static function guard_environment() {
		global $wp_version;

		load_plugin_textdomain( 'mvweb-browser-push', false, dirname( MVWEB_BP_BASENAME ) . '/languages/' );

		$problem = '';

		if ( version_compare( PHP_VERSION, MVWEB_BP_MIN_PHP, '<' ) ) {
			$problem = sprintf(
				/* translators: 1: required PHP version, 2: current PHP version. */
				__( 'MVweb Browser Push needs PHP %1$s or newer. This server runs PHP %2$s.', 'mvweb-browser-push' ),
				MVWEB_BP_MIN_PHP,
				PHP_VERSION
			);
		} elseif ( version_compare( $wp_version, MVWEB_BP_MIN_WP, '<' ) ) {
			$problem = sprintf(
				/* translators: 1: required WordPress version, 2: current WordPress version. */
				__( 'MVweb Browser Push needs WordPress %1$s or newer. This site runs WordPress %2$s.', 'mvweb-browser-push' ),
				MVWEB_BP_MIN_WP,
				$wp_version
			);
		} elseif ( ! extension_loaded( 'openssl' ) || ! in_array( 'prime256v1', openssl_get_curve_names(), true ) ) {
			$problem = __( 'MVweb Browser Push needs the PHP openssl extension with the prime256v1 curve.', 'mvweb-browser-push' );
		} elseif ( ! in_array( 'aes-128-gcm', openssl_get_cipher_methods(), true ) ) {
			$problem = __( 'MVweb Browser Push needs the PHP openssl extension with the aes-128-gcm cipher.', 'mvweb-browser-push' );
		}

		if ( '' === $problem ) {
			return;
		}

		deactivate_plugins( MVWEB_BP_BASENAME );

		wp_die(
			esc_html( $problem ),
			esc_html__( 'Plugin activation failed', 'mvweb-browser-push' ),
			array( 'back_link' => true )
		);
	}
}
