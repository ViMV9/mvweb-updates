<?php
/**
 * Builds the text of a push notification.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Orders;

use WC_Order;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Message {

	private const MAX_BYTES = 3000;

	public static function build( WC_Order $order ): array {
		$count = (int) $order->get_item_count();

		$amount = html_entity_decode(
			wp_strip_all_tags( wc_price( $order->get_total(), array( 'currency' => $order->get_currency() ) ) ),
			ENT_QUOTES,
			'UTF-8'
		);

		$message = array(
			'title' => sprintf(
				/* translators: %s: order number. */
				__( 'New order #%s', 'mvweb-browser-push' ),
				$order->get_order_number()
			),
			'body'  => $amount . ' · ' . sprintf(
				/* translators: %d: number of items in the order. */
				_n( '%d item', '%d items', $count, 'mvweb-browser-push' ),
				$count
			),
			'url'   => $order->get_edit_order_url(),
			'tag'   => 'order-' . $order->get_id(),
			'icon'  => (string) get_site_icon_url( 192 ),
		);

		return self::fit( (array) apply_filters( 'mvweb_bp_message', $message, $order ) );
	}

	public static function test(): array {
		return array(
			'title' => __( 'Test notification', 'mvweb-browser-push' ),
			'body'  => __( 'Push notifications work in this browser.', 'mvweb-browser-push' ),
			'url'   => admin_url( 'profile.php' ),
			'tag'   => 'mvweb-bp-test',
			'icon'  => (string) get_site_icon_url( 192 ),
		);
	}

	private static function fit( array $message ): array {
		$body = (string) ( $message['body'] ?? '' );
		$size = strlen( (string) wp_json_encode( $message ) );

		while ( $size > self::MAX_BYTES && '' !== $body ) {
			$body            = mb_substr( $body, 0, max( 0, mb_strlen( $body ) - 30 ) );
			$message['body'] = $body;
			$size            = strlen( (string) wp_json_encode( $message ) );
		}

		return $message;
	}
}
