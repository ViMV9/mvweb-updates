<?php
/**
 * Order triggers.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Orders;

use MVweb\BrowserPush\Push\Vapid;
use MVweb\BrowserPush\Queue\Dispatcher;
use WC_Order;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Trigger {

	public const META_SENT = '_mvweb_bp_sent';

	public function register() {
		add_action( 'woocommerce_checkout_order_processed', array( $this, 'on_checkout' ), 10, 3 );
		add_action( 'woocommerce_store_api_checkout_order_processed', array( $this, 'on_store_api' ), 10, 1 );
	}

	public function on_checkout( $order_id, $posted_data, $order ) {
		unset( $posted_data );

		if ( ! $order instanceof WC_Order ) {
			$order = wc_get_order( $order_id );
		}

		$this->maybe_dispatch( $order );
	}

	public function on_store_api( $order ) {
		$this->maybe_dispatch( $order );
	}

	private function maybe_dispatch( $order ) {
		if ( ! $order instanceof WC_Order || ! Vapid::has_keys() ) {
			return;
		}

		if ( '' !== (string) $order->get_meta( self::META_SENT ) ) {
			return;
		}

		$order->update_meta_data( self::META_SENT, (string) time() );
		$order->save();

		Dispatcher::dispatch( $order->get_id() );
	}
}
