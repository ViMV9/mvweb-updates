<?php
/**
 * Settings sanitiser.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Admin;

use MVweb\BrowserPush\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Sanitizer {

	public static function sanitize( $input ): array {
		$input   = is_array( $input ) ? $input : array();
		$allowed = array_keys( Settings::allowed_roles() );
		$roles   = isset( $input['roles'] ) && is_array( $input['roles'] ) ? array_map( 'sanitize_key', $input['roles'] ) : array();

		return array(
			'roles'       => array_values( array_intersect( $roles, $allowed ) ),
			'delete_data' => ! empty( $input['delete_data'] ),
		);
	}
}
