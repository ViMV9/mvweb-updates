<?php
/**
 * Settings API registration.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Admin;

use MVweb\BrowserPush\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Fields {

	public static function register() {
		register_setting(
			Page::GROUP,
			Settings::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( Sanitizer::class, 'sanitize' ),
				'default'           => Settings::defaults(),
				'show_in_rest'      => false,
			)
		);
	}
}
