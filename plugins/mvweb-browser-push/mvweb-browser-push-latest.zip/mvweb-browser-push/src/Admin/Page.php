<?php
/**
 * Settings screen.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Admin;

use MVweb_Menu;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Page {

	public const CAPABILITY = 'manage_options';

	public const GROUP = 'mvweb_bp_settings_group';

	private static $hook_suffix = '';

	public function register() {
		add_action( 'admin_menu', array( $this, 'register_menu' ), 11 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'admin_init', array( Fields::class, 'register' ) );
	}

	public function register_menu() {
		$parent = class_exists( 'MVweb_Menu' ) && method_exists( 'MVweb_Menu', 'get_menu_slug' )
			? MVweb_Menu::get_menu_slug()
			: 'mvweb-hub';

		self::$hook_suffix = add_submenu_page(
			$parent,
			__( 'MVweb Browser Push', 'mvweb-browser-push' ),
			__( 'Browser Push', 'mvweb-browser-push' ),
			self::CAPABILITY,
			MVWEB_BP_SLUG,
			array( $this, 'render' )
		);
	}

	public function enqueue_assets( $hook ) {
		if ( '' === self::$hook_suffix || $hook !== self::$hook_suffix ) {
			return;
		}

		wp_enqueue_style(
			'mvweb-bp-admin',
			MVWEB_BP_URL . 'admin/css/admin.min.css',
			array(),
			self::asset_version( 'admin/css/admin.min.css' )
		);
		wp_enqueue_style(
			'mvweb-bp-plugin',
			MVWEB_BP_URL . 'admin/css/plugin.min.css',
			array( 'mvweb-bp-admin' ),
			self::asset_version( 'admin/css/plugin.min.css' )
		);
		wp_enqueue_script(
			'mvweb-bp-admin',
			MVWEB_BP_URL . 'admin/js/admin.min.js',
			array(),
			self::asset_version( 'admin/js/admin.min.js' ),
			true
		);
	}

	public function render() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}

		require MVWEB_BP_PATH . 'admin/views/settings-page.php';
	}

	public static function tab_url( $tab ) {
		return admin_url( 'admin.php?page=' . MVWEB_BP_SLUG . '&tab=' . rawurlencode( $tab ) );
	}

	public static function referer_field( $tab ) {
		printf(
			'<input type="hidden" name="_wp_http_referer" value="%s">',
			esc_attr( self::tab_url( $tab ) )
		);
	}

	private static function asset_version( $relative ) {
		$path  = MVWEB_BP_PATH . $relative;
		$mtime = file_exists( $path ) ? filemtime( $path ) : 0;

		return $mtime ? (string) $mtime : MVWEB_BP_VERSION;
	}
}
