<?php
/**
 * Plugin orchestrator.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush;

use MVweb\BrowserPush\Admin\Page;
use MVweb\BrowserPush\Admin\Profile;
use MVweb\BrowserPush\Orders\Trigger;
use MVweb\BrowserPush\Queue\Worker;
use MVweb\BrowserPush\Rest\Subscriptions;
use MVweb\BrowserPush\Subscriptions\Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Plugin {

	private static $instance = null;

	private $booted = false;

	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {}

	public function boot() {
		if ( $this->booted ) {
			return;
		}
		$this->booted = true;

		Repository::register();
		( new Subscriptions() )->register();
		( new Profile() )->register();

		if ( self::queue_available() ) {
			( new Worker() )->register();
			( new Trigger() )->register();
		}

		if ( is_admin() ) {
			( new Page() )->register();
			add_action( 'admin_notices', array( $this, 'render_environment_notice' ) );
		}
	}

	public static function queue_available(): bool {
		return function_exists( 'as_enqueue_async_action' )
			&& defined( 'WC_VERSION' )
			&& version_compare( WC_VERSION, MVWEB_BP_MIN_WC, '>=' );
	}

	public function render_environment_notice() {
		if ( ! current_user_can( 'manage_options' ) || self::queue_available() ) {
			return;
		}

		printf(
			'<div class="notice notice-warning"><p>%s</p></div>',
			esc_html(
				sprintf(
				/* translators: %s: minimum WooCommerce version. */
					__( 'MVweb Browser Push: WooCommerce %s or newer must be active, so order notifications are paused.', 'mvweb-browser-push' ),
					MVWEB_BP_MIN_WC
				)
			)
		);
	}

	private function __clone() {}

	public function __wakeup() {
		throw new \LogicException( 'Cannot unserialize a singleton.' );
	}
}
