<?php
/**
 * Plugin settings.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Settings {

	public const OPTION = 'mvweb_bp_settings';

	public const CAPABILITY = 'edit_shop_orders';

	public static function defaults(): array {
		return array(
			'roles'       => array( 'administrator', 'shop_manager' ),
			'delete_data' => false,
		);
	}

	public static function get(): array {
		$stored = get_option( self::OPTION, array() );

		return array_merge( self::defaults(), is_array( $stored ) ? $stored : array() );
	}

	public static function roles(): array {
		return array_values( array_filter( (array) self::get()['roles'], 'is_string' ) );
	}

	public static function delete_data(): bool {
		return ! empty( self::get()['delete_data'] );
	}

	public static function allowed_roles(): array {
		$allowed = array();

		foreach ( wp_roles()->roles as $slug => $role ) {
			if ( ! empty( $role['capabilities'][ self::CAPABILITY ] ) ) {
				$allowed[ $slug ] = translate_user_role( $role['name'] );
			}
		}

		return $allowed;
	}

	public static function user_can_receive( int $user_id ): bool {
		$user = get_userdata( $user_id );

		if ( ! $user ) {
			return false;
		}

		return array() !== array_intersect( $user->roles, self::roles() ) && user_can( $user, self::CAPABILITY );
	}
}
