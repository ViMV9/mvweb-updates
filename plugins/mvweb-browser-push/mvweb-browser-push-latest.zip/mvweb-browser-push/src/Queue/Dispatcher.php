<?php
/**
 * Queues push deliveries.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Queue;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Dispatcher {

	public const HOOK = 'mvweb_bp_send';

	public const GROUP = 'mvweb-bp';

	public static function dispatch( int $order_id ): void {
		self::schedule(
			array(
				'order_id' => $order_id,
				'attempt'  => 1,
			),
			0
		);
	}

	public static function schedule( array $job, int $delay ): bool {
		if ( ! function_exists( 'as_enqueue_async_action' ) ) {
			return false;
		}

		$action_id = $delay <= 0
			? as_enqueue_async_action( self::HOOK, array( $job ), self::GROUP )
			: as_schedule_single_action( time() + $delay, self::HOOK, array( $job ), self::GROUP );

		if ( $action_id ) {
			return true;
		}

		wc_get_logger()->error(
			sprintf( 'Job for order %d was refused by Action Scheduler.', (int) ( $job['order_id'] ?? 0 ) ),
			array( 'source' => 'mvweb-browser-push' )
		);

		return false;
	}

	public static function cancel_all(): void {
		if ( function_exists( 'as_unschedule_all_actions' ) ) {
			as_unschedule_all_actions( '', array(), self::GROUP );
		}
	}
}
