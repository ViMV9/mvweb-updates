<?php
/**
 * Executes queued push deliveries.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Queue;

use MVweb\BrowserPush\Orders\Message;
use MVweb\BrowserPush\Push\Sender;
use MVweb\BrowserPush\Rest\Subscriptions;
use MVweb\BrowserPush\Subscriptions\Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Worker {

	private const RETRY_DELAYS = array( 60, 300, 900 );

	private const SOURCE = 'mvweb-browser-push';

	public function register() {
		add_action( Dispatcher::HOOK, array( $this, 'run' ), 10, 1 );
	}

	public function run( $job ) {
		if ( ! is_array( $job ) ) {
			return;
		}

		$order_id = isset( $job['order_id'] ) ? absint( $job['order_id'] ) : 0;
		$attempt  = isset( $job['attempt'] ) ? max( 1, absint( $job['attempt'] ) ) : 1;
		$order    = $order_id ? wc_get_order( $order_id ) : false;

		if ( ! $order ) {
			return;
		}

		$message    = Message::build( $order );
		$recipients = Repository::recipients();

		if ( ! empty( $job['subs'] ) && is_array( $job['subs'] ) ) {
			$recipients = array_intersect_key( $recipients, array_flip( $job['subs'] ) );
		}

		$failed      = array();
		$retry_after = 0;
		$logger      = wc_get_logger();

		foreach ( $recipients as $hash => $recipient ) {
			$result = Sender::send( $recipient['sub'], $message );
			$user   = (int) $recipient['user_id'];

			switch ( $result['status'] ) {
				case 'ok':
					Repository::mark( $hash, $user, 'last_ok', time() );
					Repository::mark( $hash, $user, 'last_error', '' );
					break;

				case 'gone':
					Repository::delete( $user, $hash );
					break;

				case 'retry':
					$failed[]    = $hash;
					$retry_after = max( $retry_after, (int) $result['retry_after'] );
					Repository::mark( $hash, $user, 'last_error', Subscriptions::error_code( $result ) );
					break;

				default:
					Repository::mark( $hash, $user, 'last_error', Subscriptions::error_code( $result ) );
					$logger->error(
						sprintf( 'Push refused: user %d, sub %s, order %d, HTTP %d.', $user, substr( $hash, 0, 8 ), $order_id, $result['code'] ),
						array( 'source' => self::SOURCE )
					);
			}
		}

		if ( empty( $failed ) ) {
			return;
		}

		if ( $attempt > count( self::RETRY_DELAYS ) ) {
			foreach ( $failed as $hash ) {
				$logger->error(
					sprintf( 'Push gave up: sub %s, order %d, attempt %d.', substr( $hash, 0, 8 ), $order_id, $attempt ),
					array( 'source' => self::SOURCE )
				);
			}

			return;
		}

		Dispatcher::schedule(
			array(
				'order_id' => $order_id,
				'attempt'  => $attempt + 1,
				'subs'     => $failed,
			),
			min( 3600, max( self::RETRY_DELAYS[ $attempt - 1 ], $retry_after ) )
		);
	}
}
