<?php
/**
 * Message encryption for Web Push (RFC 8291, aes128gcm).
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Push;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Encryption {

	public static function encrypt( string $plaintext, string $ua_public, string $auth, ?array $as_key = null, ?string $salt = null ): string {
		$as_key = $as_key ?? Ec::generate();
		$salt   = $salt ?? random_bytes( 16 );

		if ( empty( $as_key ) || 65 !== strlen( $ua_public ) || 16 !== strlen( $auth ) ) {
			return '';
		}

		$ecdh = openssl_pkey_derive( Ec::public_pem( $ua_public ), Ec::private_pem( $as_key['d'], $as_key['public'] ) );

		if ( false === $ecdh ) {
			return '';
		}

		$key_info = "WebPush: info\0" . $ua_public . $as_key['public'];
		$ikm      = hash_hkdf( 'sha256', $ecdh, 32, $key_info, $auth );
		$cek      = hash_hkdf( 'sha256', $ikm, 16, "Content-Encoding: aes128gcm\0", $salt );
		$nonce    = hash_hkdf( 'sha256', $ikm, 12, "Content-Encoding: nonce\0", $salt );

		$cipher = openssl_encrypt( $plaintext . "\x02", 'aes-128-gcm', $cek, OPENSSL_RAW_DATA, $nonce, $tag, '', 16 );

		if ( false === $cipher ) {
			return '';
		}

		return $salt . pack( 'N', 4096 ) . chr( 65 ) . $as_key['public'] . $cipher . $tag;
	}
}
