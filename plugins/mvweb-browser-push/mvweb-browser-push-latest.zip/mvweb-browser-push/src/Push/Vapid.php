<?php
/**
 * VAPID keys and the Authorization header (RFC 8292).
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Push;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Vapid {

	public const OPTION = 'mvweb_bp_vapid';

	public static function ensure_keys(): void {
		if ( self::has_keys() ) {
			return;
		}

		$pair = Ec::generate();

		if ( empty( $pair ) ) {
			return;
		}

		add_option(
			self::OPTION,
			array(
				'd'       => Base64Url::encode( $pair['d'] ),
				'public'  => Base64Url::encode( $pair['public'] ),
				'created' => time(),
			),
			'',
			false
		);
	}

	public static function has_keys(): bool {
		return '' !== self::public_key();
	}

	public static function public_key(): string {
		$keys = get_option( self::OPTION );

		return is_array( $keys ) && ! empty( $keys['public'] ) ? (string) $keys['public'] : '';
	}

	public static function headers( string $endpoint ): array {
		$keys = get_option( self::OPTION );

		if ( ! is_array( $keys ) || empty( $keys['d'] ) || empty( $keys['public'] ) ) {
			return array();
		}

		$d      = Base64Url::decode( (string) $keys['d'] );
		$public = Base64Url::decode( (string) $keys['public'] );
		$parts  = wp_parse_url( $endpoint );

		if ( null === $d || null === $public || empty( $parts['scheme'] ) || empty( $parts['host'] ) ) {
			return array();
		}

		$jwt_header = array(
			'typ' => 'JWT',
			'alg' => 'ES256',
		);

		$header = Base64Url::encode( wp_json_encode( $jwt_header ) );
		$claims = Base64Url::encode(
			wp_json_encode(
				array(
					'aud' => $parts['scheme'] . '://' . $parts['host'],
					'exp' => time() + 3600,
					'sub' => home_url(),
				)
			)
		);

		$signed = openssl_sign( $header . '.' . $claims, $der, Ec::private_pem( $d, $public ), OPENSSL_ALGO_SHA256 );

		if ( ! $signed ) {
			return array();
		}

		$jwt = $header . '.' . $claims . '.' . Base64Url::encode( Ec::der_to_raw( $der ) );

		return array( 'Authorization' => 'vapid t=' . $jwt . ', k=' . (string) $keys['public'] );
	}
}
