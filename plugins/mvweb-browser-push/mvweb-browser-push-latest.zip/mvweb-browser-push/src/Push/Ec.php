<?php
/**
 * P-256 keys and ECDSA signatures through openssl.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Push;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Ec {

	public const SPKI_HEADER = '3059301306072a8648ce3d020106082a8648ce3d03010703420004';

	private const SEC1_PREFIX = '30770201010420';

	private const SEC1_CURVE = 'a00a06082a8648ce3d030107a144034200';

	public static function generate(): array {
		$key = openssl_pkey_new(
			array(
				'curve_name'       => 'prime256v1',
				'private_key_type' => OPENSSL_KEYTYPE_EC,
			)
		);

		if ( false === $key ) {
			return array();
		}

		$details = openssl_pkey_get_details( $key );

		if ( ! is_array( $details ) || empty( $details['ec'] ) ) {
			return array();
		}

		$ec = $details['ec'];

		return array(
			'd'      => str_pad( $ec['d'], 32, "\0", STR_PAD_LEFT ),
			'public' => "\x04" . str_pad( $ec['x'], 32, "\0", STR_PAD_LEFT ) . str_pad( $ec['y'], 32, "\0", STR_PAD_LEFT ),
		);
	}

	public static function public_pem( string $public65 ): string {
		return self::pem( 'PUBLIC KEY', hex2bin( self::SPKI_HEADER ) . substr( $public65, 1 ) );
	}

	public static function private_pem( string $d, string $public65 ): string {
		return self::pem(
			'EC PRIVATE KEY',
			hex2bin( self::SEC1_PREFIX ) . $d . hex2bin( self::SEC1_CURVE ) . $public65
		);
	}

	public static function der_to_raw( string $der ): string {
		if ( strlen( $der ) < 8 || "\x30" !== $der[0] ) {
			return '';
		}

		$offset = 2;

		if ( ord( $der[1] ) & 0x80 ) {
			$offset = 2 + ( ord( $der[1] ) & 0x7f );
		}

		$parts = array();

		for ( $i = 0; $i < 2; $i++ ) {
			if ( ! isset( $der[ $offset + 1 ] ) || "\x02" !== $der[ $offset ] ) {
				return '';
			}

			$length  = ord( $der[ $offset + 1 ] );
			$value   = substr( $der, $offset + 2, $length );
			$offset += 2 + $length;

			$parts[] = str_pad( ltrim( $value, "\0" ), 32, "\0", STR_PAD_LEFT );
		}

		return $parts[0] . $parts[1];
	}

	private static function pem( string $label, string $der ): string {
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- PEM wrapping of a DER key.
		$body = chunk_split( base64_encode( $der ), 64, "\n" );

		return "-----BEGIN {$label}-----\n" . $body . "-----END {$label}-----\n";
	}
}
