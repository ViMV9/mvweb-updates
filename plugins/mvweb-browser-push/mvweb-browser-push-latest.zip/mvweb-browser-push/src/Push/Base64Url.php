<?php
/**
 * Base64url encoding without padding.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Push;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Base64Url {

	public static function encode( string $bin ): string {
		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- binary-to-text encoding required by RFC 7515.
		return rtrim( strtr( base64_encode( $bin ), '+/', '-_' ), '=' );
	}

	public static function decode( string $str ): ?string {
		if ( '' === $str || ! preg_match( '/^[A-Za-z0-9_-]+$/', $str ) ) {
			return null;
		}

		// phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- strict decoding of a validated base64url string.
		$bin = base64_decode( strtr( $str, '-_', '+/' ) . str_repeat( '=', ( 4 - strlen( $str ) % 4 ) % 4 ), true );

		return false === $bin ? null : $bin;
	}
}
