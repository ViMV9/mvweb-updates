<?php
/**
 * Sends one encrypted push message to one subscription.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Push;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Sender {

	public static function send( array $sub, array $message ): array {
		$body = Encryption::encrypt(
			(string) wp_json_encode( $message ),
			(string) Base64Url::decode( (string) ( $sub['p256dh'] ?? '' ) ),
			(string) Base64Url::decode( (string) ( $sub['auth'] ?? '' ) )
		);

		$auth_headers = Vapid::headers( (string) ( $sub['endpoint'] ?? '' ) );

		if ( '' === $body || empty( $auth_headers ) ) {
			return array(
				'status'      => 'error',
				'code'        => 0,
				'retry_after' => 0,
			);
		}

		$response = wp_safe_remote_post(
			$sub['endpoint'],
			array(
				'timeout'     => 5,
				'redirection' => 0,
				'headers'     => array_merge(
					$auth_headers,
					array(
						'Content-Type'     => 'application/octet-stream',
						'Content-Encoding' => 'aes128gcm',
						'TTL'              => '86400',
						'Urgency'          => 'high',
					)
				),
				'body'        => $body,
			)
		);

		return self::classify( $response );
	}

	public static function classify( $response ): array {
		if ( is_wp_error( $response ) ) {
			return array(
				'status'      => 'retry',
				'code'        => 0,
				'retry_after' => 0,
			);
		}

		$code        = (int) wp_remote_retrieve_response_code( $response );
		$retry_after = 0;
		$status      = 'error';

		if ( in_array( $code, array( 200, 201, 202 ), true ) ) {
			$status = 'ok';
		} elseif ( in_array( $code, array( 404, 410 ), true ) ) {
			$status = 'gone';
		} elseif ( 429 === $code || ( $code >= 500 && $code <= 599 ) ) {
			$status = 'retry';
			$header = wp_remote_retrieve_header( $response, 'retry-after' );

			if ( is_string( $header ) && ctype_digit( $header ) ) {
				$retry_after = (int) $header;
			}
		}

		return array(
			'status'      => $status,
			'code'        => $code,
			'retry_after' => $retry_after,
		);
	}
}
