( function () {
	'use strict';

	document.addEventListener( 'DOMContentLoaded', function () {
		initTabs();
		initSelectOnFocus();
	} );

	function initSelectOnFocus() {
		document.querySelectorAll( '.mvweb-bp-selectable' ).forEach( function ( field ) {
			field.addEventListener( 'focus', function () {
				field.select();
			} );
		} );
	}

	function initTabs() {
		var links = document.querySelectorAll( '.mvweb-nav__link[data-tab]' );
		var panels = document.querySelectorAll( '.mvweb-tab-content' );

		if ( ! links.length || ! panels.length ) {
			return;
		}

		links.forEach( function ( link ) {
			link.addEventListener( 'click', function ( event ) {
				event.preventDefault();

				var target = link.getAttribute( 'data-tab' );
				var panel = document.getElementById( target );

				if ( ! panel ) {
					return;
				}

				links.forEach( function ( item ) {
					item.classList.remove( 'mvweb-nav__link--active' );
					item.removeAttribute( 'aria-current' );
				} );
				panels.forEach( function ( item ) {
					item.classList.remove( 'active' );
				} );

				link.classList.add( 'mvweb-nav__link--active' );
				link.setAttribute( 'aria-current', 'page' );
				panel.classList.add( 'active' );

				if ( window.history && window.history.replaceState ) {
					var url = new URL( window.location.href );
					url.searchParams.set( 'tab', target );
					window.history.replaceState( {}, '', url.toString() );
				}
			} );
		} );
	}
}() );
