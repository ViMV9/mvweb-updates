<?php
/**
 * Push block on the profile screen.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

use MVweb\BrowserPush\Admin\Profile;
use MVweb\BrowserPush\Subscriptions\Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<h2 id="mvweb-bp"><?php esc_html_e( 'Push notifications about new orders', 'mvweb-browser-push' ); ?></h2>

<table class="form-table mvweb-bp-block" role="presentation">
	<tr>
		<th scope="row"><?php esc_html_e( 'This browser', 'mvweb-browser-push' ); ?></th>
		<td>
			<p class="mvweb-bp-state" aria-live="polite"></p>
			<p>
				<button type="button" class="button button-primary mvweb-bp-enable" hidden><?php esc_html_e( 'Enable in this browser', 'mvweb-browser-push' ); ?></button>
				<button type="button" class="button mvweb-bp-test" hidden><?php esc_html_e( 'Send test', 'mvweb-browser-push' ); ?></button>
				<button type="button" class="button mvweb-bp-disable" hidden><?php esc_html_e( 'Disable in this browser', 'mvweb-browser-push' ); ?></button>
			</p>
		</td>
	</tr>
	<?php if ( $subs ) : ?>
		<tr>
			<th scope="row"><?php esc_html_e( 'My devices', 'mvweb-browser-push' ); ?></th>
			<td>
				<table class="widefat striped mvweb-bp-devices">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Browser', 'mvweb-browser-push' ); ?></th>
							<th><?php esc_html_e( 'Added', 'mvweb-browser-push' ); ?></th>
							<th><?php esc_html_e( 'Last delivery', 'mvweb-browser-push' ); ?></th>
							<th><?php esc_html_e( 'Status', 'mvweb-browser-push' ); ?></th>
							<th><?php esc_html_e( 'Remove', 'mvweb-browser-push' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $subs as $mvweb_bp_hash => $mvweb_bp_sub ) : ?>
							<tr>
								<td><?php echo esc_html( Repository::browser_label( $mvweb_bp_sub['endpoint'] ) ); ?></td>
								<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $mvweb_bp_sub['created'] ) ); ?></td>
								<td><?php echo ! empty( $mvweb_bp_sub['last_ok'] ) ? esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $mvweb_bp_sub['last_ok'] ) ) : '—'; ?></td>
								<td><?php echo esc_html( Profile::status_label( (string) $mvweb_bp_sub['last_error'] ) ); ?></td>
								<td><input type="checkbox" name="mvweb_bp_remove[]" value="<?php echo esc_attr( $mvweb_bp_hash ); ?>" aria-label="<?php esc_attr_e( 'Remove this device on save', 'mvweb-browser-push' ); ?>"></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
				<p class="description"><?php esc_html_e( 'Tick devices to remove and press Update Profile.', 'mvweb-browser-push' ); ?></p>
			</td>
		</tr>
	<?php endif; ?>
</table>
