<?php
/**
 * Admin settings page template.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_bp_current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'settings'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.

$mvweb_bp_tabs = array(
	'settings'    => array(
		'label' => __( 'Settings', 'mvweb-browser-push' ),
		'icon'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
	),
	'diagnostics' => array(
		'label' => __( 'Diagnostics', 'mvweb-browser-push' ),
		'icon'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>',
	),
	'help'        => array(
		'label' => __( 'Help', 'mvweb-browser-push' ),
		'icon'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
	),
);

if ( ! isset( $mvweb_bp_tabs[ $mvweb_bp_current_tab ] ) ) {
	$mvweb_bp_current_tab = 'settings';
}
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">BP</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Browser Push', 'mvweb-browser-push' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_BP_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $mvweb_bp_tabs as $mvweb_bp_tab_id => $mvweb_bp_tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $mvweb_bp_tab_id ); ?>"
						class="mvweb-nav__link <?php echo $mvweb_bp_current_tab === $mvweb_bp_tab_id ? 'mvweb-nav__link--active' : ''; ?>"
						<?php echo $mvweb_bp_current_tab === $mvweb_bp_tab_id ? 'aria-current="page"' : ''; ?>
						data-tab="<?php echo esc_attr( $mvweb_bp_tab_id ); ?>">
						<?php echo $mvweb_bp_tab['icon']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $mvweb_bp_tab['label'] ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php settings_errors( 'general' ); ?>

		<?php foreach ( array_keys( $mvweb_bp_tabs ) as $mvweb_bp_tab_id ) : ?>
			<div id="<?php echo esc_attr( $mvweb_bp_tab_id ); ?>" class="mvweb-tab-content <?php echo $mvweb_bp_current_tab === $mvweb_bp_tab_id ? 'active' : ''; ?>">
				<?php require MVWEB_BP_PATH . 'admin/views/tab-' . $mvweb_bp_tab_id . '.php'; ?>
			</div>
		<?php endforeach; ?>

	</main>
</div>
