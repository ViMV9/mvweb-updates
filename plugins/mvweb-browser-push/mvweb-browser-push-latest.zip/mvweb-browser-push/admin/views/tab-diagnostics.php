<?php
/**
 * Diagnostics tab: environment checks and links to the log and the queue.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

use MVweb\BrowserPush\Plugin;
use MVweb\BrowserPush\Push\Vapid;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_bp_host   = (string) wp_parse_url( home_url(), PHP_URL_HOST );
$mvweb_bp_checks = array(
	array(
		__( 'Secure connection (HTTPS)', 'mvweb-browser-push' ),
		is_ssl() || 'localhost' === $mvweb_bp_host,
		__( 'Browsers allow push only on https pages. localhost is the one exception.', 'mvweb-browser-push' ),
	),
	array(
		__( 'PHP openssl: curve prime256v1', 'mvweb-browser-push' ),
		extension_loaded( 'openssl' ) && in_array( 'prime256v1', openssl_get_curve_names(), true ),
		__( 'Ask the hosting to enable the openssl extension.', 'mvweb-browser-push' ),
	),
	array(
		__( 'PHP openssl: cipher aes-128-gcm', 'mvweb-browser-push' ),
		extension_loaded( 'openssl' ) && in_array( 'aes-128-gcm', openssl_get_cipher_methods(), true ),
		__( 'Ask the hosting to enable the openssl extension.', 'mvweb-browser-push' ),
	),
	array(
		__( 'WooCommerce 11.0+ with Action Scheduler', 'mvweb-browser-push' ),
		Plugin::queue_available(),
		__( 'Activate or update WooCommerce.', 'mvweb-browser-push' ),
	),
	array(
		__( 'Site push keys created', 'mvweb-browser-push' ),
		Vapid::has_keys(),
		__( 'Deactivate the plugin and activate it again to create them.', 'mvweb-browser-push' ),
	),
);
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Environment', 'mvweb-browser-push' ); ?></div>
	</div>

	<div class="mvweb-table-wrap">
		<table class="mvweb-table">
			<tbody>
				<?php foreach ( $mvweb_bp_checks as $mvweb_bp_check ) : ?>
					<tr>
						<td><?php echo esc_html( $mvweb_bp_check[0] ); ?></td>
						<td>
							<?php if ( $mvweb_bp_check[1] ) : ?>
								<span class="mvweb-badge mvweb-badge--success"><?php esc_html_e( 'OK', 'mvweb-browser-push' ); ?></span>
							<?php else : ?>
								<span class="mvweb-badge mvweb-badge--error"><?php esc_html_e( 'Problem', 'mvweb-browser-push' ); ?></span>
								<?php echo esc_html( $mvweb_bp_check[2] ); ?>
							<?php endif; ?>
						</td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Public push key', 'mvweb-browser-push' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'The key browsers use to recognise this site. It is public and safe to share. The private half never leaves the database.', 'mvweb-browser-push' ); ?></p>
	<input type="text" class="mvweb-input mvweb-bp-selectable" readonly aria-label="<?php esc_attr_e( 'Public push key', 'mvweb-browser-push' ); ?>" value="<?php echo esc_attr( Vapid::public_key() ); ?>">
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Log and queue', 'mvweb-browser-push' ); ?></div>
	</div>
	<p>
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-status&tab=logs&source=mvweb-browser-push' ) ); ?>"><?php esc_html_e( 'Open the delivery log', 'mvweb-browser-push' ); ?></a>
		·
		<a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-status&tab=action-scheduler&s=mvweb_bp_send' ) ); ?>"><?php esc_html_e( 'Open the queue', 'mvweb-browser-push' ); ?></a>
	</p>
</div>
