<?php
/**
 * Help tab: how staff turn push on and what to check when it goes quiet.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-browser-push' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Choose the roles', 'mvweb-browser-push' ); ?></strong>
			<p><?php esc_html_e( 'On the Settings tab tick the roles whose people should get notifications. Administrators and shop managers are ticked by default.', 'mvweb-browser-push' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Each person turns push on for themselves', 'mvweb-browser-push' ); ?></strong>
			<p><?php esc_html_e( 'Open Users → Profile, find “Push notifications about new orders” and press “Enable in this browser”. Allow notifications when the browser asks.', 'mvweb-browser-push' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Check it', 'mvweb-browser-push' ); ?></strong>
			<p><?php esc_html_e( 'Press “Send test” in the same block. A notification should appear within seconds. Repeat on every browser and computer you want to use.', 'mvweb-browser-push' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'How it works', 'mvweb-browser-push' ); ?></div>
	</div>
	<p><?php esc_html_e( 'When a customer places an order at checkout, classic or block, a job is queued and delivered in the background. The customer never waits for the push service. Orders created by hand in the admin or brought in by an import stay quiet.', 'mvweb-browser-push' ); ?></p>
	<p><?php esc_html_e( 'The notification shows the order number, the total and the number of items. Customer names and addresses are never put into it. Clicking it opens the order in the admin.', 'mvweb-browser-push' ); ?></p>
	<p><?php esc_html_e( 'Delivery goes through the push service of each browser: Google for Chrome, Yandex Browser and Opera, Mozilla for Firefox, Apple for Safari, Microsoft for Edge. No third-party plugin service is involved.', 'mvweb-browser-push' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-browser-push' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The test arrives, but a real order does not.', 'mvweb-browser-push' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Check the queue on the Diagnostics tab: orders are delivered by Action Scheduler about a minute after checkout. If jobs stay pending for long, the site’s background tasks do not run — set a server cron job for wp-cron.php once a minute.', 'mvweb-browser-push' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Nothing arrives at all.', 'mvweb-browser-push' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'On a computer the browser must be running, though it may sit in the background. Notifications must also be allowed for the browser in the system settings of macOS or Windows.', 'mvweb-browser-push' ); ?></p>
			<p><?php esc_html_e( 'Chrome, Yandex Browser and Opera receive push through Google servers. Some networks restrict access to them, and then no site can deliver push there. The “Last delivery” column in your profile shows whether the push service accepted the message.', 'mvweb-browser-push' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can the text be changed?', 'mvweb-browser-push' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'A developer can change it with the mvweb_bp_message filter. The plugin has no text editor on purpose: the text is short and carries no personal data.', 'mvweb-browser-push' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Does it work on iPhone and iPad?', 'mvweb-browser-push' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Not in this version. Safari on a Mac works.', 'mvweb-browser-push' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-browser-push' ); ?></div>
	</div>
	<p>
		<?php
		printf(
			/* translators: 1: plugin URL, 2: plugin version. */
			esc_html__( 'Documentation and support: %1$s. Version %2$s.', 'mvweb-browser-push' ),
			'<a href="https://mvweb.ru/plugins/mvweb-browser-push" target="_blank" rel="noopener">mvweb.ru</a>',
			esc_html( MVWEB_BP_VERSION )
		);
		?>
	</p>
</div>
