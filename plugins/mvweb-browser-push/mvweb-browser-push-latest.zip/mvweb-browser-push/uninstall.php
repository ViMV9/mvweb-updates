<?php
/**
 * Uninstall MVweb Browser Push.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$mvweb_bp_settings = get_option( 'mvweb_bp_settings', array() );

if ( ! is_array( $mvweb_bp_settings ) || empty( $mvweb_bp_settings['delete_data'] ) ) {
	return;
}

global $wpdb;

delete_option( 'mvweb_bp_settings' );
delete_option( 'mvweb_bp_vapid' );

$mvweb_bp_like = $wpdb->esc_like( 'mvweb_bp_' ) . '%';

$mvweb_bp_sql = $wpdb->prepare(
	"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
	'_transient_' . $mvweb_bp_like,
	'_transient_timeout_' . $mvweb_bp_like
);

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- prepared above.
$wpdb->query( $mvweb_bp_sql );

$mvweb_bp_sql = $wpdb->prepare(
	"DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s",
	$wpdb->esc_like( '_mvweb_bp_sub_' ) . '%'
);

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- prepared above.
$wpdb->query( $mvweb_bp_sql );

$mvweb_bp_meta_tables = array(
	$wpdb->postmeta,
	$wpdb->prefix . 'wc_orders_meta',
);

foreach ( $mvweb_bp_meta_tables as $mvweb_bp_table ) {
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery
	$mvweb_bp_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $mvweb_bp_table ) ) );

	if ( $mvweb_bp_exists !== $mvweb_bp_table ) {
		continue;
	}

	do {
		$mvweb_bp_sql = $wpdb->prepare(
			'DELETE FROM %i WHERE meta_key = %s LIMIT 1000',
			$mvweb_bp_table,
			'_mvweb_bp_sent'
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared -- prepared above.
		$mvweb_bp_deleted = $wpdb->query( $mvweb_bp_sql );
	} while ( $mvweb_bp_deleted > 0 );
}

wp_cache_flush();
