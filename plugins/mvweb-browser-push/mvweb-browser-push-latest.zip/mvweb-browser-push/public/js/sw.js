self.addEventListener( 'push', ( event ) => {
	const data = event.data ? event.data.json() : {};
	event.waitUntil( self.registration.showNotification( data.title || 'MVweb Browser Push', {
		body: data.body || '',
		tag: data.tag,
		icon: sameOrigin( data.icon ) ? data.icon : undefined,
		data: { url: data.url },
	} ) );
} );

self.addEventListener( 'notificationclick', ( event ) => {
	event.notification.close();
	const url = adminUrl( event.notification.data && event.notification.data.url );
	event.waitUntil( clients.matchAll( { type: 'window', includeUncontrolled: true } ).then( ( list ) => {
		const tab = list.find( ( c ) => c.url === url );
		return tab ? tab.focus() : clients.openWindow( url );
	} ) );
} );

function sameOrigin( u ) {
	try {
		return new URL( u, self.location.origin ).origin === self.location.origin;
	} catch {
		return false;
	}
}

function adminUrl( u ) {
	if ( u && sameOrigin( u ) && new URL( u, self.location.origin ).pathname.includes( '/wp-admin/' ) ) {
		return u;
	}
	return self.location.origin + '/wp-admin/';
}
