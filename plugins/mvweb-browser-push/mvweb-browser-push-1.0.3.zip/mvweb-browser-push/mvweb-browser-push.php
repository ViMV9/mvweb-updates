<?php
/**
 * Plugin Name:       MVweb Browser Push
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-browser-push
 * Description:       Browser push notifications about new WooCommerce orders for shop staff.
 * Version:           1.0.3
 * Requires at least: 7.0
 * Tested up to:      7.1.2
 * Requires PHP:      8.2
 * Requires Plugins:  woocommerce
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-browser-push
 * Domain Path:       /languages
 * Update URI:        https://mvweb.ru/plugins/mvweb-browser-push
 *
 * @package MVweb\BrowserPush
 *
 * @since 1.0.0 Initial release.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'MVWEB_BP_VERSION' ) ) {
	return;
}

define( 'MVWEB_BP_VERSION', '1.0.3' );
define( 'MVWEB_BP_FILE', __FILE__ );
define( 'MVWEB_BP_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_BP_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_BP_BASENAME', plugin_basename( __FILE__ ) );
define( 'MVWEB_BP_SLUG', 'mvweb-browser-push' );

define( 'MVWEB_BP_MIN_WP', '7.0' );
define( 'MVWEB_BP_MIN_PHP', '8.2' );
define( 'MVWEB_BP_MIN_WC', '11.0' );

$mvweb_bp_shared_path = dirname( dirname( MVWEB_BP_PATH ) ) . '/shared/';

if ( file_exists( MVWEB_BP_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_BP_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $mvweb_bp_shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $mvweb_bp_shared_path . 'class-mvweb-menu.php';
}

if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

if ( file_exists( MVWEB_BP_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_BP_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $mvweb_bp_shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $mvweb_bp_shared_path . 'class-mvweb-updater.php';
}

$mvweb_bp_updater = null;

if ( class_exists( 'MVweb_Updater' ) ) {
	$mvweb_bp_updater = MVweb_Updater::create( MVWEB_BP_FILE, MVWEB_BP_SLUG );
}

if ( file_exists( MVWEB_BP_PATH . 'includes/class-mvweb-license.php' ) ) {
	require_once MVWEB_BP_PATH . 'includes/class-mvweb-license.php';
} elseif ( file_exists( $mvweb_bp_shared_path . 'class-mvweb-license.php' ) ) {
	require_once $mvweb_bp_shared_path . 'class-mvweb-license.php';
}

if ( class_exists( 'MVweb_License' ) ) {
	MVweb_License::init( MVWEB_BP_SLUG, $mvweb_bp_updater, 'plugin', MVWEB_BP_SLUG );
}

unset( $mvweb_bp_updater );

unset( $mvweb_bp_shared_path );

require_once MVWEB_BP_PATH . 'src/Autoloader.php';

\MVweb\BrowserPush\Autoloader::register();

register_activation_hook( MVWEB_BP_FILE, array( \MVweb\BrowserPush\Lifecycle::class, 'activate' ) );
register_deactivation_hook( MVWEB_BP_FILE, array( \MVweb\BrowserPush\Lifecycle::class, 'deactivate' ) );

add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility(
				'custom_order_tables',
				MVWEB_BP_FILE,
				true
			);
		}
	}
);

add_filter(
	'mvweb_registered_plugins',
	static function ( $plugins ) {
		$plugins[ MVWEB_BP_SLUG ] = array(
			'name'         => 'MVweb Browser Push',
			'description'  => __( 'Browser push notifications about new WooCommerce orders for shop staff.', 'mvweb-browser-push' ),
			'url'          => 'https://mvweb.ru/plugins/mvweb-browser-push',
			'settings_url' => 'admin.php?page=' . MVWEB_BP_SLUG,
			'textdomain'   => 'mvweb-browser-push',
		);
		return $plugins;
	}
);

add_action(
	'plugins_loaded',
	static function () {
		load_plugin_textdomain(
			'mvweb-browser-push',
			false,
			dirname( plugin_basename( MVWEB_BP_FILE ) ) . '/languages/'
		);
	}
);

add_action(
	'init',
	static function () {
		\MVweb\BrowserPush\Plugin::instance()->boot();
	}
);
