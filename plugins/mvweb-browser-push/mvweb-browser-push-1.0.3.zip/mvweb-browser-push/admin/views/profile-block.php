<?php
/**
 * Push block on the profile screen.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

use MVweb\BrowserPush\Admin\Profile;
use MVweb\BrowserPush\Subscriptions\Repository;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<h2 id="mvweb-bp"><?php esc_html_e( 'Notifications about new WooCommerce orders', 'mvweb-browser-push' ); ?></h2>
<p><?php esc_html_e( 'Get a notification in this browser about every new order in the store. Turn it on separately in each browser you use.', 'mvweb-browser-push' ); ?></p>

<table class="form-table mvweb-bp-block" role="presentation">
	<tr>
		<th scope="row"><?php esc_html_e( 'This browser', 'mvweb-browser-push' ); ?></th>
		<td>
			<p class="mvweb-bp-state" aria-live="polite"></p>
			<p>
				<button type="button" class="button button-primary mvweb-bp-enable" hidden><?php esc_html_e( 'Enable in this browser', 'mvweb-browser-push' ); ?></button>
				<button type="button" class="button mvweb-bp-test" hidden><?php esc_html_e( 'Send test', 'mvweb-browser-push' ); ?></button>
				<button type="button" class="button mvweb-bp-disable" hidden><?php esc_html_e( 'Disable in this browser', 'mvweb-browser-push' ); ?></button>
			</p>
		</td>
	</tr>
</table>

<?php if ( $subs ) : ?>
	<div class="mvweb-bp-devices">
		<h3><?php esc_html_e( 'My devices', 'mvweb-browser-push' ); ?></h3>
		<table class="widefat striped">
			<thead>
				<tr>
					<th scope="col"><?php esc_html_e( 'Browser', 'mvweb-browser-push' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Added', 'mvweb-browser-push' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Last delivery', 'mvweb-browser-push' ); ?></th>
					<th scope="col"><?php esc_html_e( 'Status', 'mvweb-browser-push' ); ?></th>
					<td class="manage-column"><span class="screen-reader-text"><?php esc_html_e( 'Remove', 'mvweb-browser-push' ); ?></span></td>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $subs as $mvweb_bp_hash => $mvweb_bp_sub ) : ?>
					<tr>
						<td><?php echo esc_html( Repository::browser_label( $mvweb_bp_sub['endpoint'] ) ); ?></td>
						<td><?php echo esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $mvweb_bp_sub['created'] ) ); ?></td>
						<td><?php echo ! empty( $mvweb_bp_sub['last_ok'] ) ? esc_html( wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $mvweb_bp_sub['last_ok'] ) ) : '—'; ?></td>
						<td><?php echo esc_html( Profile::status_label( (string) $mvweb_bp_sub['last_error'] ) ); ?></td>
						<td><button type="button" class="button button-small mvweb-bp-device-remove" data-hash="<?php echo esc_attr( $mvweb_bp_hash ); ?>" aria-label="<?php echo esc_attr( sprintf( /* translators: 1: browser name, 2: date the device was added. */ __( 'Remove: %1$s, added %2$s', 'mvweb-browser-push' ), Repository::browser_label( $mvweb_bp_sub['endpoint'] ), wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), (int) $mvweb_bp_sub['created'] ) ) ); ?>"><?php esc_html_e( 'Remove', 'mvweb-browser-push' ); ?></button></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
		<p class="description"><?php esc_html_e( 'Remove a device to stop notifications on it. This browser is switched off with “Disable in this browser”.', 'mvweb-browser-push' ); ?></p>
	</div>
<?php endif; ?>
