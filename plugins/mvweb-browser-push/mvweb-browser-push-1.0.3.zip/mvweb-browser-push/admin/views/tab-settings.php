<?php
/**
 * Settings tab: who receives the notifications and what happens on uninstall.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

use MVweb\BrowserPush\Admin\Page;
use MVweb\BrowserPush\Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_bp_selected = Settings::roles();
?>

<form method="post" action="options.php">
	<?php settings_fields( Page::GROUP ); ?>
	<?php Page::referer_field( 'settings' ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Notifications about new orders', 'mvweb-browser-push' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'A staff member sees a notification in the browser about every new WooCommerce order, even when the admin tab is closed: the order number, the total and the number of items. Clicking it opens the order.', 'mvweb-browser-push' ); ?></p>
		<p class="mvweb-form-row__desc"><?php esc_html_e( 'It is sent as soon as the customer places the order, before payment, so open the order to see whether it is paid. Orders created by hand in the admin or imported stay quiet.', 'mvweb-browser-push' ); ?></p>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Who gets the notifications', 'mvweb-browser-push' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Every person with a ticked role turns notifications on for themselves in their own profile (Users → Profile). Only roles that can manage orders are listed.', 'mvweb-browser-push' ); ?></p>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Roles', 'mvweb-browser-push' ); ?></span>
			<div class="mvweb-form-row__field">
				<?php foreach ( Settings::allowed_roles() as $mvweb_bp_slug => $mvweb_bp_name ) : ?>
					<label class="mvweb-check">
						<input type="checkbox"
							name="<?php echo esc_attr( Settings::OPTION ); ?>[roles][]"
							value="<?php echo esc_attr( $mvweb_bp_slug ); ?>"
							<?php checked( in_array( $mvweb_bp_slug, $mvweb_bp_selected, true ) ); ?>>
						<?php echo esc_html( $mvweb_bp_name ); ?>
					</label>
				<?php endforeach; ?>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Uninstall', 'mvweb-browser-push' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-bp-delete-data" class="mvweb-form-row__label"><?php esc_html_e( 'Plugin data', 'mvweb-browser-push' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox"
							id="mvweb-bp-delete-data"
							name="<?php echo esc_attr( Settings::OPTION ); ?>[delete_data]"
							value="1"
							<?php checked( Settings::delete_data() ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Delete all plugin data when the plugin is deleted', 'mvweb-browser-push' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Removes settings, the site push keys and every saved browser. Without it a reinstall keeps working subscriptions.', 'mvweb-browser-push' ); ?></p>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" class="mvweb-btn mvweb-btn--primary"><?php esc_html_e( 'Save Changes', 'mvweb-browser-push' ); ?></button>
	</div>
</form>
