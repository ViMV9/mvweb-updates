( function () {
	'use strict';

	const cfg = window.mvwebBp;
	if ( ! cfg ) {
		return;
	}

	const state = document.querySelector( '.mvweb-bp-state' );
	const btnEnable = document.querySelector( '.mvweb-bp-enable' );
	const btnTest = document.querySelector( '.mvweb-bp-test' );
	const btnDisable = document.querySelector( '.mvweb-bp-disable' );

	if ( ! state || ! btnEnable || ! btnTest || ! btnDisable ) {
		return;
	}

	const b64uToBytes = ( s ) => Uint8Array.from( atob( s.replace( /-/g, '+' ).replace( /_/g, '/' ) + '='.repeat( ( 4 - s.length % 4 ) % 4 ) ), ( c ) => c.charCodeAt( 0 ) );

	const bytesToB64u = ( bytes ) => btoa( String.fromCharCode( ...bytes ) ).replace( /\+/g, '-' ).replace( /\//g, '_' ).replace( /=+$/, '' );

	const headers = { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.nonce };

	const api = ( method, path, body ) => fetch( cfg.restUrl + path, { method, headers, credentials: 'same-origin', body: JSON.stringify( body ) } );

	let registration = null;

	const show = ( text, enabled ) => {
		state.textContent = text;
		btnEnable.hidden = enabled !== false;
		btnTest.hidden = enabled !== true;
		btnDisable.hidden = enabled !== true;
	};

	const hideAll = ( text ) => show( text, null );

	const isSupported = () => 'serviceWorker' in navigator && 'PushManager' in window && 'Notification' in window;

	const lockCurrentDevice = async ( endpoint ) => {
		if ( ! window.crypto || ! window.crypto.subtle ) {
			return;
		}
		const digest = await window.crypto.subtle.digest( 'SHA-256', new TextEncoder().encode( endpoint ) );
		const hash = Array.from( new Uint8Array( digest ), ( b ) => b.toString( 16 ).padStart( 2, '0' ) ).join( '' );
		document.querySelectorAll( '.mvweb-bp-device-remove' ).forEach( ( button ) => {
			if ( button.dataset.hash === hash ) {
				button.disabled = true;
				button.title = cfg.i18n.useDisable;
			}
		} );
	};

	const refresh = async () => {
		try {
			if ( Notification.permission === 'denied' ) {
				hideAll( cfg.i18n.blocked );
				return;
			}
			let sub = await registration.pushManager.getSubscription();
			const key = sub && sub.options && sub.options.applicationServerKey;
			if ( sub && key && cfg.vapidKey && bytesToB64u( new Uint8Array( key ) ) !== cfg.vapidKey ) {
				await sub.unsubscribe();
				sub = null;
			}
			if ( ! sub ) {
				show( cfg.i18n.disabled, false );
				return;
			}
			const res = await api( 'POST', '', sub.toJSON() );
			if ( ! res.ok ) {
				show( cfg.i18n.error, false );
				return;
			}
			show( cfg.i18n.enabled, true );
			lockCurrentDevice( sub.endpoint );
		} catch ( e ) {
			show( cfg.i18n.error, false );
		}
	};

	btnEnable.addEventListener( 'click', () => {
		const pending = registration.pushManager.subscribe( { userVisibleOnly: true, applicationServerKey: b64uToBytes( cfg.vapidKey ) } );
		hideAll( cfg.i18n.working );
		pending
			.then( refresh )
			.catch( ( e ) => refresh().then( () => {
				if ( Notification.permission === 'denied' ) {
					return;
				}
				if ( e && e.name === 'AbortError' ) {
					state.textContent = navigator.brave ? cfg.i18n.braveOff : cfg.i18n.pushDown;
					return;
				}
				state.textContent = cfg.i18n.error;
			} ) );
	} );

	btnDisable.addEventListener( 'click', async () => {
		hideAll( cfg.i18n.working );
		try {
			const sub = await registration.pushManager.getSubscription();
			if ( sub ) {
				const endpoint = sub.endpoint;
				await sub.unsubscribe();
				await api( 'DELETE', '', { endpoint } );
			}
			await refresh();
		} catch ( e ) {
			await refresh();
			state.textContent = cfg.i18n.error;
		}
	} );

	btnTest.addEventListener( 'click', async () => {
		btnTest.disabled = true;
		try {
			const sub = await registration.pushManager.getSubscription();
			if ( ! sub ) {
				await refresh();
				return;
			}
			const res = await api( 'POST', '/test', { endpoint: sub.endpoint } );
			if ( res.status === 429 ) {
				state.textContent = cfg.i18n.testWait;
			} else if ( ! res.ok ) {
				state.textContent = cfg.i18n.error;
			} else {
				const data = await res.json();
				if ( data.status === 'ok' ) {
					state.textContent = cfg.i18n.testOk;
				} else if ( data.status === 'gone' ) {
					state.textContent = cfg.i18n.testGone;
					await sub.unsubscribe();
					show( cfg.i18n.disabled, false );
				} else {
					state.textContent = data.code ? cfg.i18n.testFailed : cfg.i18n.error;
				}
			}
		} catch ( e ) {
			state.textContent = cfg.i18n.error;
		} finally {
			btnTest.disabled = false;
		}
	} );

	document.querySelectorAll( '.mvweb-bp-device-remove' ).forEach( ( button ) => {
		button.addEventListener( 'click', async () => {
			button.disabled = true;
			try {
				const res = await api( 'DELETE', '/' + button.dataset.hash );
				if ( ! res.ok && res.status !== 404 ) {
					throw new Error( String( res.status ) );
				}
				const row = button.closest( 'tr' );
				const list = row.closest( 'tbody' );
				row.remove();
				if ( ! list.children.length ) {
					list.closest( '.mvweb-bp-devices' ).remove();
				}
			} catch ( e ) {
				button.disabled = false;
				state.textContent = cfg.i18n.error;
			}
		} );
	} );

	if ( ! isSupported() ) {
		hideAll( cfg.i18n.unsupported );
		return;
	}

	navigator.serviceWorker.register( cfg.swUrl, { scope: cfg.swScope } )
		.then( ( reg ) => {
			registration = reg;
			return refresh();
		} )
		.catch( () => hideAll( cfg.i18n.error ) );
}() );
