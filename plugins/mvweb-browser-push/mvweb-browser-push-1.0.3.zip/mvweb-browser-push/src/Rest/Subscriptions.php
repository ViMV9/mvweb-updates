<?php
/**
 * REST endpoints for managing the current user's push subscriptions.
 *
 * @package MVweb\BrowserPush
 * @since   1.0.0
 */

namespace MVweb\BrowserPush\Rest;

use MVweb\BrowserPush\Orders\Message;
use MVweb\BrowserPush\Push\Base64Url;
use MVweb\BrowserPush\Push\Ec;
use MVweb\BrowserPush\Push\Sender;
use MVweb\BrowserPush\Settings;
use MVweb\BrowserPush\Subscriptions\Repository;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Subscriptions {

	public const NAMESPACE = 'mvweb-bp/v1';

	private const TEST_INTERVAL = 30;

	public function register() {
		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	public function register_routes() {
		$endpoint = array(
			'type'              => 'string',
			'required'          => true,
			'validate_callback' => array( $this, 'validate_endpoint' ),
		);

		register_rest_route(
			self::NAMESPACE,
			'/subscriptions',
			array(
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'create' ),
					'permission_callback' => array( $this, 'permission' ),
					'args'                => array(
						'endpoint' => $endpoint,
						'keys'     => array(
							'type'              => 'object',
							'required'          => true,
							'validate_callback' => array( $this, 'validate_keys' ),
						),
					),
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'delete' ),
					'permission_callback' => array( $this, 'permission' ),
					'args'                => array( 'endpoint' => $endpoint ),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/subscriptions/(?P<hash>[a-f0-9]{64})',
			array(
				'methods'             => WP_REST_Server::DELETABLE,
				'callback'            => array( $this, 'delete_by_hash' ),
				'permission_callback' => array( $this, 'permission' ),
			)
		);

		register_rest_route(
			self::NAMESPACE,
			'/subscriptions/test',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'test' ),
				'permission_callback' => array( $this, 'permission' ),
				'args'                => array( 'endpoint' => $endpoint ),
			)
		);
	}

	public function permission() {
		return is_user_logged_in() && Settings::user_can_receive( get_current_user_id() );
	}

	public function validate_endpoint( $value ) {
		return is_string( $value )
			&& strlen( $value ) <= 1000
			&& 0 === strpos( $value, 'https://' )
			&& false !== wp_http_validate_url( $value );
	}

	public function validate_keys( $value ) {
		if ( ! is_array( $value ) ) {
			return false;
		}

		if ( ! isset( $value['p256dh'], $value['auth'] ) || ! is_string( $value['p256dh'] ) || ! is_string( $value['auth'] ) ) {
			return false;
		}

		$p256dh = Base64Url::decode( $value['p256dh'] );
		$auth   = Base64Url::decode( $value['auth'] );

		if ( null === $p256dh || null === $auth || 65 !== strlen( $p256dh ) || "\x04" !== $p256dh[0] || 16 !== strlen( $auth ) ) {
			return false;
		}

		$probe = Ec::generate();

		return ! empty( $probe ) && false !== openssl_pkey_derive( Ec::public_pem( $p256dh ), Ec::private_pem( $probe['d'], $probe['public'] ) );
	}

	public static function error_code( array $result ): string {
		if ( $result['code'] ) {
			return (string) $result['code'];
		}

		return 'retry' === $result['status'] ? 'network' : 'local';
	}

	public function create( WP_REST_Request $request ) {
		$keys = $request->get_param( 'keys' );
		$hash = Repository::save(
			get_current_user_id(),
			(string) $request->get_param( 'endpoint' ),
			(string) $keys['p256dh'],
			(string) $keys['auth']
		);

		return new WP_REST_Response(
			array(
				'hash'    => $hash,
				'browser' => Repository::browser_label( (string) $request->get_param( 'endpoint' ) ),
			),
			201
		);
	}

	public function delete( WP_REST_Request $request ) {
		$hash = Repository::hash( (string) $request->get_param( 'endpoint' ) );

		if ( ! isset( Repository::for_user( get_current_user_id() )[ $hash ] ) ) {
			return new WP_Error( 'mvweb_bp_not_found', __( 'Subscription not found.', 'mvweb-browser-push' ), array( 'status' => 404 ) );
		}

		Repository::delete( get_current_user_id(), $hash );

		return new WP_REST_Response( array( 'deleted' => true ), 200 );
	}

	public function delete_by_hash( WP_REST_Request $request ) {
		$hash = (string) $request->get_param( 'hash' );

		if ( ! isset( Repository::for_user( get_current_user_id() )[ $hash ] ) ) {
			return new WP_Error( 'mvweb_bp_not_found', __( 'Subscription not found.', 'mvweb-browser-push' ), array( 'status' => 404 ) );
		}

		Repository::delete( get_current_user_id(), $hash );

		return new WP_REST_Response( array( 'deleted' => true ), 200 );
	}

	public function test( WP_REST_Request $request ) {
		$user_id = get_current_user_id();
		$hash    = Repository::hash( (string) $request->get_param( 'endpoint' ) );
		$sub     = Repository::for_user( $user_id )[ $hash ] ?? null;

		if ( null === $sub ) {
			return new WP_Error( 'mvweb_bp_not_found', __( 'Subscription not found.', 'mvweb-browser-push' ), array( 'status' => 404 ) );
		}

		$throttle = 'mvweb_bp_test_' . $user_id;

		if ( false !== get_transient( $throttle ) ) {
			return new WP_Error( 'mvweb_bp_too_many', __( 'Please wait half a minute before the next test.', 'mvweb-browser-push' ), array( 'status' => 429 ) );
		}

		set_transient( $throttle, 1, self::TEST_INTERVAL );

		$result = Sender::send( $sub, Message::test() );

		if ( 'gone' === $result['status'] ) {
			Repository::delete( $user_id, $hash );
		} elseif ( 'ok' === $result['status'] ) {
			Repository::mark( $hash, $user_id, 'last_ok', time() );
			Repository::mark( $hash, $user_id, 'last_error', '' );
		} else {
			Repository::mark( $hash, $user_id, 'last_error', self::error_code( $result ) );
		}

		return new WP_REST_Response(
			array(
				'status' => $result['status'],
				'code'   => $result['code'],
			),
			200
		);
	}
}
