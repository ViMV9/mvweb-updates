<?php
/**
 * Helper functions for MVweb Stock Labels.
 *
 * @package mvweb_sl
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Default plugin settings.
 *
 * @since 1.0.0
 * @return array
 */
function mvweb_sl_get_defaults(): array {
	return array(
		/* translators: %s: group wording such as Low or Plenty. Keep the placeholder in place. */
		'template' => __( 'In stock: %s', 'mvweb-stock-labels' ),
		'bold'     => true,
		'groups'   => array(
			'none' => array(
				'label' => __( 'Out of stock', 'mvweb-stock-labels' ),
				'color' => '#6b7280',
			),
			'low'  => array(
				'from'  => 1,
				'to'    => 2,
				'label' => __( 'Low', 'mvweb-stock-labels' ),
				'color' => '#dc2626',
			),
			'mid'  => array(
				'from'  => 3,
				'to'    => 5,
				'label' => __( 'Enough', 'mvweb-stock-labels' ),
				'color' => '#d97706',
			),
			'high' => array(
				'from'  => 6,
				'label' => __( 'Plenty', 'mvweb-stock-labels' ),
				'color' => '#16a34a',
			),
		),
	);
}

/**
 * Stored settings merged over the defaults.
 *
 * @since 1.0.0
 * @return array
 */
function mvweb_sl_get_settings(): array {
	$defaults = mvweb_sl_get_defaults();
	$saved    = get_option( MVWEB_SL_OPTION, array() );

	if ( ! is_array( $saved ) ) {
		return $defaults;
	}

	$settings           = array_merge( $defaults, $saved );
	$settings['groups'] = $defaults['groups'];

	foreach ( $defaults['groups'] as $key => $group ) {
		if ( isset( $saved['groups'][ $key ] ) && is_array( $saved['groups'][ $key ] ) ) {
			$settings['groups'][ $key ] = array_merge( $group, $saved['groups'][ $key ] );
		}
	}

	return $settings;
}

/**
 * Whether WooCommerce itself prints the exact quantity for this product.
 *
 * Mirrors wc_format_stock_for_display(): the store setting
 * "Stock display format" decides whether a number is shown at all.
 * The plugin only replaces a number that WooCommerce already prints.
 *
 * @since 1.0.0
 * @param WC_Product $product Product being rendered.
 * @return bool
 */
function mvweb_sl_woo_prints_quantity( WC_Product $product ): bool {
	$quantity = $product->get_stock_quantity();

	if ( null === $quantity ) {
		return false;
	}

	$format = mvweb_sl_get_woo_stock_format();

	if ( 'low_amount' === $format ) {
		return $quantity <= wc_get_low_stock_amount( $product );
	}

	return '' === $format;
}

/**
 * Pick the label group for a product.
 *
 * Branch order mirrors WC_Product::get_availability_text() so the plugin
 * never invents output where WooCommerce stays silent.
 *
 * @since 1.0.0
 * @param WC_Product $product Product being rendered.
 * @return string Group key, or an empty string when the output must stay untouched.
 */
function mvweb_sl_pick_group( WC_Product $product ): string {
	if ( ! $product->is_in_stock() ) {
		return 'none';
	}

	if ( $product->is_on_backorder( 1 ) ) {
		return '';
	}

	if ( ! $product->managing_stock() ) {
		return '';
	}

	if ( ! mvweb_sl_woo_prints_quantity( $product ) ) {
		return '';
	}

	$quantity = (int) $product->get_stock_quantity();
	$groups   = mvweb_sl_get_settings()['groups'];

	if ( $quantity >= (int) $groups['high']['from'] ) {
		return 'high';
	}

	foreach ( array( 'low', 'mid' ) as $key ) {
		if ( $quantity >= (int) $groups[ $key ]['from'] && $quantity <= (int) $groups[ $key ]['to'] ) {
			return $key;
		}
	}

	return '';
}

/**
 * Current value of the WooCommerce "Stock display format" setting.
 *
 * @since 1.0.0
 * @return string One of '', 'low_amount', 'no_amount'.
 */
function mvweb_sl_get_woo_stock_format(): string {
	return (string) get_option( 'woocommerce_stock_format' );
}

/**
 * Build the label for a product.
 *
 * The single place where a group turns into ready text, shared by the
 * availability filter and by the public helper below. The group wording and
 * the output template are kept apart: only the wording carries the colour.
 *
 * @since 1.0.1
 * @param WC_Product $product Product being rendered.
 * @return array{group: string, value: string, template: string, text: string} Empty group means "leave the output alone".
 */
function mvweb_sl_build_label( WC_Product $product ): array {
	$group = mvweb_sl_pick_group( $product );

	if ( '' === $group ) {
		return array(
			'group'    => '',
			'value'    => '',
			'template' => '',
			'text'     => '',
		);
	}

	$settings = mvweb_sl_get_settings();
	$defaults = mvweb_sl_get_defaults();

	$raw_label    = $settings['groups'][ $group ]['label'] ?? '';
	$raw_template = $settings['template'] ?? '';

	$label    = is_scalar( $raw_label ) ? sanitize_text_field( (string) $raw_label ) : '';
	$template = is_scalar( $raw_template ) ? sanitize_text_field( (string) $raw_template ) : '';

	if ( '' === $label ) {
		$label = (string) $defaults['groups'][ $group ]['label'];
	}

	// The "out of stock" wording replaces the whole line, the template is not applied to it.
	if ( 'none' === $group ) {
		$template = '%s';
	}

	return array(
		'group'    => $group,
		'value'    => $label,
		'template' => $template,
		'text'     => mvweb_sl_format_label( $template, $label ),
	);
}

/**
 * Label text with the group wording wrapped for styling.
 *
 * Only the wording gets the plugin classes, so the surrounding template text
 * ("In stock:") keeps the colour and the weight given to it by the theme.
 *
 * @since 1.0.2
 * @param array $label Result of mvweb_sl_build_label().
 * @return string Empty string when there is nothing to print.
 */
function mvweb_sl_label_text_html( array $label ): string {
	if ( empty( $label['group'] ) ) {
		return '';
	}

	$value = '<span class="mvweb-sl__value">' . esc_html( (string) $label['value'] ) . '</span>';

	$template = isset( $label['template'] ) ? (string) $label['template'] : '';

	if ( false === strpos( $template, '%s' ) ) {
		return $value;
	}

	try {
		return sprintf( esc_html( $template ), $value );
	} catch ( Throwable $e ) {
		return $value;
	}
}

/**
 * Ready-to-print label markup for themes and templates.
 *
 * For themes that render the stock line with their own code instead of
 * wc_get_stock_html() — the plugin filter cannot reach those.
 *
 * @since 1.0.1
 * @param WC_Product $product    Product being rendered.
 * @param string     $extra_class Optional theme class to keep alongside the plugin ones.
 * @return string Empty string when the output must stay untouched.
 */
function mvweb_sl_label_html( WC_Product $product, string $extra_class = '' ): string {
	$label = mvweb_sl_build_label( $product );

	if ( '' === $label['group'] ) {
		return '';
	}

	$classes = trim( $extra_class . ' mvweb-sl mvweb-sl--' . $label['group'] );

	return '<span class="' . esc_attr( $classes ) . '">' . mvweb_sl_label_text_html( $label ) . '</span>';
}

/**
 * Whether the output template survives sprintf().
 *
 * A lone % or an extra specifier makes sprintf() throw, so the template is
 * checked before it is stored and again before it reaches a product page.
 *
 * @since 1.0.0
 * @param string $template Output template.
 * @return bool
 */
function mvweb_sl_template_is_safe( string $template ): bool {
	if ( false === strpos( $template, '%s' ) ) {
		return true;
	}

	try {
		sprintf( $template, '' );
	} catch ( Throwable $e ) {
		return false;
	}

	return true;
}

/**
 * Put the label into the output template.
 *
 * Falls back to the bare label when the template has no placeholder or
 * cannot be formatted — a broken template must never take the page down.
 *
 * @since 1.0.0
 * @param string $template Output template.
 * @param string $label    Group label.
 * @return string
 */
function mvweb_sl_format_label( string $template, string $label ): string {
	if ( false === strpos( $template, '%s' ) ) {
		return $label;
	}

	try {
		return sprintf( $template, $label );
	} catch ( Throwable $e ) {
		return $label;
	}
}
