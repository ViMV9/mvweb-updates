<?php
/**
 * Plugin Name:       MVweb Stock Labels
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-stock-labels
 * Description:       Replaces the exact WooCommerce stock quantity on the front end with configurable labels such as Low, Enough and Plenty.
 * Version:           1.0.2
 * Requires at least: 7.0
 * Tested up to:      7.1
 * Requires PHP:      8.2
 * Requires Plugins:  woocommerce
 * WC requires at least: 11.0
 * WC tested up to:      11.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-stock-labels
 * Domain Path:       /languages
 *
 * @package mvweb_sl
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_SL_VERSION' ) ) {
	return;
}

define( 'MVWEB_SL_VERSION', '1.0.2' );
define( 'MVWEB_SL_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_SL_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_SL_BASENAME', plugin_basename( __FILE__ ) );
define( 'MVWEB_SL_OPTION', 'mvweb_sl_settings' );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_SL_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_SL_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_SL_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_SL_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_SL_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-stock-labels' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter(
	'mvweb_registered_plugins',
	function ( $plugins ) {
		$plugins['mvweb-stock-labels'] = array(
			'name'         => 'MVweb Stock Labels',
			'description'  => __( 'Replaces the exact WooCommerce stock quantity on the front end with configurable labels such as Low, Enough and Plenty.', 'mvweb-stock-labels' ),
			'url'          => 'https://mvweb.ru/plugins/mvweb-stock-labels',
			'settings_url' => 'admin.php?page=mvweb-stock-labels',
			'textdomain'   => 'mvweb-stock-labels',
		);
		return $plugins;
	}
);

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_sl_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-stock-labels',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_sl_load_textdomain' );

require_once MVWEB_SL_PATH . 'includes/helpers.php';

/**
 * Declare compatibility with WooCommerce features.
 *
 * Without this WooCommerce lists the plugin as incompatible: an undeclared
 * plugin counts as uncertain, not as compatible. The plugin touches neither
 * orders nor the checkout, so both features are safe to declare.
 *
 * @since 1.0.1
 * @return void
 */
function mvweb_sl_declare_wc_compatibility() {
	if ( ! class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		return;
	}

	\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
	\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
}
add_action( 'before_woocommerce_init', 'mvweb_sl_declare_wc_compatibility' );

/**
 * Bootstrap the plugin once WooCommerce is known to be present.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_sl_bootstrap() {
	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'mvweb_sl_woocommerce_missing_notice' );
		return;
	}

	require_once MVWEB_SL_PATH . 'public/class-mvweb-sl-frontend.php';

	MVweb_SL_Frontend::init();

	if ( ! is_admin() ) {
		return;
	}

	require_once MVWEB_SL_PATH . 'admin/class-mvweb-sl-admin.php';

	MVweb_SL_Admin::init();
}
add_action( 'plugins_loaded', 'mvweb_sl_bootstrap' );

/**
 * Admin notice shown when WooCommerce is missing or inactive.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_sl_woocommerce_missing_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	printf(
		'<div class="notice notice-error"><p>%s</p></div>',
		esc_html__( 'MVweb Stock Labels requires WooCommerce to be installed and active.', 'mvweb-stock-labels' )
	);
}
