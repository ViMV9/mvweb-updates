<?php
/**
 * Front-end controller: availability replacement and label styles.
 *
 * @package mvweb_sl
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Front-end controller.
 *
 * @since 1.0.0
 */
class MVweb_SL_Frontend {

	const HANDLE = 'mvweb-sl';

	/**
	 * Register front-end hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_filter( 'woocommerce_get_availability', array( __CLASS__, 'filter_availability' ), 10, 2 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_styles' ) );
	}

	/**
	 * Replace the exact quantity with the group label.
	 *
	 * Covers simple products and variations alike: WooCommerce builds the
	 * variation availability_html through the same wc_get_stock_html().
	 *
	 * @since 1.0.0
	 * @param array      $availability Availability text and class.
	 * @param WC_Product $product      Product being rendered.
	 * @return array
	 */
	public static function filter_availability( $availability, $product ) {
		if ( ! is_array( $availability ) || ! $product instanceof WC_Product ) {
			return $availability;
		}

		$label = mvweb_sl_build_label( $product );

		if ( '' === $label['group'] ) {
			return $availability;
		}

		$availability['availability'] = mvweb_sl_label_text_html( $label );

		$classes               = isset( $availability['class'] ) ? (string) $availability['class'] : '';
		$availability['class'] = trim( $classes . ' mvweb-sl mvweb-sl--' . $label['group'] );

		return $availability;
	}

	/**
	 * Enqueue label styles.
	 *
	 * Not scoped to WooCommerce page conditionals on purpose: a theme can
	 * print the availability line in a category archive, in search results
	 * or through a [products] shortcode on any page, and the label would
	 * then be left without its colour.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function enqueue_styles() {
		wp_enqueue_style(
			self::HANDLE,
			MVWEB_SL_URL . 'public/css/public.min.css',
			array(),
			MVWEB_SL_VERSION
		);

		wp_add_inline_style( self::HANDLE, self::build_inline_css() );
	}

	/**
	 * Build the colour variables and the optional weight rule.
	 *
	 * Colours are re-validated here as well: the option could have been
	 * written straight into the database, bypassing the settings form.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	protected static function build_inline_css() {
		$settings = mvweb_sl_get_settings();
		$defaults = mvweb_sl_get_defaults();
		$vars     = '';

		foreach ( $defaults['groups'] as $key => $group ) {
			$raw_color = $settings['groups'][ $key ]['color'] ?? '';
			$color     = is_scalar( $raw_color ) ? sanitize_hex_color( (string) $raw_color ) : null;

			if ( null === $color || '' === $color ) {
				$color = $group['color'];
			}

			$vars .= '--mvweb-sl-' . $key . ':' . $color . ';';
		}

		$css = ':root{' . $vars . '}';

		if ( ! empty( $settings['bold'] ) ) {
			$css .= '.mvweb-sl .mvweb-sl__value{font-weight:600;}';
		}

		return $css;
	}
}
