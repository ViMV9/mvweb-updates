/**
 * Admin JavaScript for MVweb Stock Labels.
 *
 * @package mvweb_sl
 * @since   1.0.0
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		initTabs();
	});

	/**
	 * Initialize tab navigation on the settings page.
	 */
	function initTabs() {
		var links = document.querySelectorAll('.mvweb-nav__link');
		var panels = document.querySelectorAll('.mvweb-tab-content');

		if (!links.length || !panels.length) {
			return;
		}

		links.forEach(function (link) {
			link.addEventListener('click', function (event) {
				event.preventDefault();

				var target = link.getAttribute('data-tab') || link.getAttribute('href').replace('#', '');
				var panel = document.getElementById(target);

				if (!panel) {
					return;
				}

				links.forEach(function (l) { l.classList.remove('mvweb-nav__link--active'); });
				panels.forEach(function (p) { p.classList.remove('active'); });

				link.classList.add('mvweb-nav__link--active');
				panel.classList.add('active');
			});
		});
	}
})();
