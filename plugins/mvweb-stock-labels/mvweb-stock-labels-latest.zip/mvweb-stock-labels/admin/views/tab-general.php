<?php
/**
 * General settings tab.
 *
 * @package mvweb_sl
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_sl_settings = mvweb_sl_get_settings();
$mvweb_sl_format   = mvweb_sl_get_woo_stock_format();
$mvweb_sl_wc_url   = admin_url( 'admin.php?page=wc-settings&tab=products&section=inventory' );

$mvweb_sl_rows = array(
	'none' => array(
		'title' => __( 'Out of stock', 'mvweb-stock-labels' ),
		'desc'  => __( 'Shown when the product is out of stock. WooCommerce prints this line regardless of the stock display format.', 'mvweb-stock-labels' ),
		'range' => 'none',
	),
	'low'  => array(
		'title' => __( 'Low stock', 'mvweb-stock-labels' ),
		'desc'  => __( 'The smallest quantity range.', 'mvweb-stock-labels' ),
		'range' => 'both',
	),
	'mid'  => array(
		'title' => __( 'Medium stock', 'mvweb-stock-labels' ),
		'desc'  => __( 'The middle quantity range.', 'mvweb-stock-labels' ),
		'range' => 'both',
	),
	'high' => array(
		'title' => __( 'High stock', 'mvweb-stock-labels' ),
		'desc'  => __( 'Everything from this quantity and above.', 'mvweb-stock-labels' ),
		'range' => 'from',
	),
);
?>

<?php if ( 'no_amount' === $mvweb_sl_format ) : ?>
	<div class="mvweb-alert mvweb-alert--warning">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
		<div class="mvweb-alert__body">
			<p class="mvweb-alert__title"><?php esc_html_e( 'The plugin is idle right now', 'mvweb-stock-labels' ); ?></p>
			<p>
				<?php esc_html_e( 'WooCommerce is set to never show the quantity remaining in stock, so there is no number to replace.', 'mvweb-stock-labels' ); ?>
				<a href="<?php echo esc_url( $mvweb_sl_wc_url ); ?>"><?php esc_html_e( 'Change the stock display format', 'mvweb-stock-labels' ); ?></a>
			</p>
		</div>
	</div>
<?php elseif ( 'low_amount' === $mvweb_sl_format ) : ?>
	<div class="mvweb-alert mvweb-alert--warning">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
		<div class="mvweb-alert__body">
			<p class="mvweb-alert__title"><?php esc_html_e( 'Only part of the groups will ever appear', 'mvweb-stock-labels' ); ?></p>
			<p>
				<?php
				printf(
					/* translators: %s: low stock threshold set in WooCommerce. */
					esc_html__( 'WooCommerce prints the quantity only when the stock drops to %s or below, so the upper groups stay unused.', 'mvweb-stock-labels' ),
					esc_html( (string) get_option( 'woocommerce_notify_low_stock_amount', 2 ) )
				);
				?>
				<a href="<?php echo esc_url( $mvweb_sl_wc_url ); ?>"><?php esc_html_e( 'Change the stock display format', 'mvweb-stock-labels' ); ?></a>
			</p>
		</div>
	</div>
<?php else : ?>
	<div class="mvweb-alert mvweb-alert--info">
		<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>
		<div class="mvweb-alert__body">
			<p class="mvweb-alert__title"><?php esc_html_e( 'WooCommerce shows the quantity, the plugin replaces it', 'mvweb-stock-labels' ); ?></p>
			<p><?php esc_html_e( 'Products with stock management enabled get a label instead of the exact number. Everything else stays as WooCommerce renders it.', 'mvweb-stock-labels' ); ?></p>
		</div>
	</div>
<?php endif; ?>

<form method="post" action="options.php">
	<?php settings_fields( MVweb_SL_Admin::OPTION_GROUP ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Groups', 'mvweb-stock-labels' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Quantity ranges, their wording and colour. Ranges must not overlap.', 'mvweb-stock-labels' ); ?></p>

		<?php foreach ( $mvweb_sl_rows as $mvweb_sl_key => $mvweb_sl_row ) : ?>
			<?php $mvweb_sl_group = $mvweb_sl_settings['groups'][ $mvweb_sl_key ]; ?>
			<div class="mvweb-form-row">
				<label for="mvweb-sl-label-<?php echo esc_attr( $mvweb_sl_key ); ?>" class="mvweb-form-row__label">
					<?php echo esc_html( $mvweb_sl_row['title'] ); ?>
				</label>
				<div class="mvweb-form-row__field">
					<div class="mvweb-sl-group">
						<?php if ( 'none' !== $mvweb_sl_row['range'] ) : ?>
							<span class="mvweb-sl-group__range">
								<label class="mvweb-sl-group__cap" for="mvweb-sl-from-<?php echo esc_attr( $mvweb_sl_key ); ?>"><?php esc_html_e( 'from', 'mvweb-stock-labels' ); ?></label>
								<input type="number" min="0" step="1" class="mvweb-input mvweb-sl-group__num"
									id="mvweb-sl-from-<?php echo esc_attr( $mvweb_sl_key ); ?>"
									name="<?php echo esc_attr( MVWEB_SL_OPTION ); ?>[groups][<?php echo esc_attr( $mvweb_sl_key ); ?>][from]"
									value="<?php echo esc_attr( (string) $mvweb_sl_group['from'] ); ?>">
							</span>

							<?php if ( 'both' === $mvweb_sl_row['range'] ) : ?>
								<span class="mvweb-sl-group__range">
									<label class="mvweb-sl-group__cap" for="mvweb-sl-to-<?php echo esc_attr( $mvweb_sl_key ); ?>"><?php esc_html_e( 'to', 'mvweb-stock-labels' ); ?></label>
									<input type="number" min="0" step="1" class="mvweb-input mvweb-sl-group__num"
										id="mvweb-sl-to-<?php echo esc_attr( $mvweb_sl_key ); ?>"
										name="<?php echo esc_attr( MVWEB_SL_OPTION ); ?>[groups][<?php echo esc_attr( $mvweb_sl_key ); ?>][to]"
										value="<?php echo esc_attr( (string) $mvweb_sl_group['to'] ); ?>">
								</span>
							<?php else : ?>
								<span class="mvweb-sl-group__cap"><?php esc_html_e( 'and above', 'mvweb-stock-labels' ); ?></span>
							<?php endif; ?>
						<?php endif; ?>

						<input type="text" class="mvweb-input mvweb-sl-group__label"
							id="mvweb-sl-label-<?php echo esc_attr( $mvweb_sl_key ); ?>"
							name="<?php echo esc_attr( MVWEB_SL_OPTION ); ?>[groups][<?php echo esc_attr( $mvweb_sl_key ); ?>][label]"
							value="<?php echo esc_attr( $mvweb_sl_group['label'] ); ?>">

						<input type="color" class="mvweb-sl-group__color"
							aria-label="<?php echo esc_attr( $mvweb_sl_row['title'] ); ?>"
							name="<?php echo esc_attr( MVWEB_SL_OPTION ); ?>[groups][<?php echo esc_attr( $mvweb_sl_key ); ?>][color]"
							value="<?php echo esc_attr( $mvweb_sl_group['color'] ); ?>">
					</div>
					<p class="mvweb-form-row__desc"><?php echo esc_html( $mvweb_sl_row['desc'] ); ?></p>
				</div>
			</div>
		<?php endforeach; ?>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Output', 'mvweb-stock-labels' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'How the label reads on the product page.', 'mvweb-stock-labels' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb-sl-template" class="mvweb-form-row__label"><?php esc_html_e( 'Template', 'mvweb-stock-labels' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text" id="mvweb-sl-template" class="mvweb-input"
					name="<?php echo esc_attr( MVWEB_SL_OPTION ); ?>[template]"
					value="<?php echo esc_attr( $mvweb_sl_settings['template'] ); ?>">
				<p class="mvweb-form-row__desc">
					<code>%s</code> &mdash; <?php esc_html_e( 'the place where the group wording goes. Leave the field with the placeholder alone to print the bare label.', 'mvweb-stock-labels' ); ?>
				</p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-sl-bold" class="mvweb-form-row__label"><?php esc_html_e( 'Bold', 'mvweb-stock-labels' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox" id="mvweb-sl-bold" value="1"
							name="<?php echo esc_attr( MVWEB_SL_OPTION ); ?>[bold]"
							<?php checked( ! empty( $mvweb_sl_settings['bold'] ) ); ?>>
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'print the label in a heavier weight', 'mvweb-stock-labels' ); ?></span>
				</div>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<?php submit_button( __( 'Save changes', 'mvweb-stock-labels' ), 'mvweb-btn mvweb-btn--primary', 'submit', false ); ?>
	</div>
</form>
