<?php
/**
 * Help tab template.
 *
 * Uses MVweb Admin UI Kit.
 *
 * @package mvweb_sl
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick start', 'mvweb-stock-labels' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Let WooCommerce show the quantity', 'mvweb-stock-labels' ); ?></strong>
			<p><?php esc_html_e( 'In WooCommerce → Settings → Products → Inventory set the stock display format to "Always show quantity remaining in stock". The plugin only replaces a number that WooCommerce already prints.', 'mvweb-stock-labels' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Set the ranges', 'mvweb-stock-labels' ); ?></strong>
			<p><?php esc_html_e( 'On the General tab describe what counts as low, medium and high stock. Ranges must not overlap.', 'mvweb-stock-labels' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Pick the wording and the colours', 'mvweb-stock-labels' ); ?></strong>
			<p><?php esc_html_e( 'Each group has its own text and colour. The template controls the sentence around the wording.', 'mvweb-stock-labels' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'How it works', 'mvweb-stock-labels' ); ?></div>
	</div>
	<p><?php esc_html_e( 'The plugin hooks into the availability line WooCommerce renders on the product page and swaps the exact quantity for a label. Ordering is untouched: a customer still cannot buy more than the shop actually has, and the real quantity stays visible in the admin area and in reports.', 'mvweb-stock-labels' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'FAQ', 'mvweb-stock-labels' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Why do the upper groups never appear?', 'mvweb-stock-labels' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'The stock display format in WooCommerce is set to show the quantity only when it is low. Above that threshold WooCommerce prints a plain "In stock" with no number, and the plugin leaves it alone.', 'mvweb-stock-labels' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Nothing changes on a product. Why?', 'mvweb-stock-labels' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Check that stock management is enabled for that product and a quantity is set. Products sold on backorder and products without stock management keep the standard WooCommerce wording, because there is no number to hide.', 'mvweb-stock-labels' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can a customer still find the exact number?', 'mvweb-stock-labels' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Yes, in the page source. The quantity field keeps its max attribute so the native order limit keeps working, and the WooCommerce Store API keeps returning stock data for integrations. The goal is a calmer product page, not secrecy.', 'mvweb-stock-labels' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'My theme shows the old number in the catalogue.', 'mvweb-stock-labels' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'If the theme prints the availability line with the standard WooCommerce function, the plugin replaces it in the catalogue too — it is not limited to the product page. Two cases stay out of reach: block-based storefronts (All Products, Product Collection), which render stock in JavaScript from the Store API, and themes that print the quantity with their own code instead of the standard function.', 'mvweb-stock-labels' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-stock-labels' ); ?></div>
	</div>
	<p>
		<?php
		printf(
			/* translators: %s: MVweb plugin URL */
			esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-stock-labels' ),
			'<a href="https://mvweb.ru/plugins/mvweb-stock-labels" target="_blank">mvweb.ru</a>'
		);
		?>
	</p>
</div>
