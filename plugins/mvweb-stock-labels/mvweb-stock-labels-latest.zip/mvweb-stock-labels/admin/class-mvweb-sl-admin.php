<?php
/**
 * Admin controller: settings page and asset enqueue.
 *
 * @package mvweb_sl
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin controller.
 *
 * @since 1.0.0
 */
class MVweb_SL_Admin {

	const CAPABILITY = 'manage_options';

	const PAGE_SLUG = 'mvweb-stock-labels';

	const OPTION_GROUP = 'mvweb_sl';

	/**
	 * Hook suffix returned by `add_submenu_page`, used to scope asset enqueue.
	 *
	 * @var string|false
	 */
	protected static $hook_suffix = false;

	/**
	 * Register admin hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 20 );
		add_action( 'admin_init', array( __CLASS__, 'register_settings' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Register the plugin option through the Settings API.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_settings() {
		register_setting(
			self::OPTION_GROUP,
			MVWEB_SL_OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize_settings' ),
				'default'           => mvweb_sl_get_defaults(),
			)
		);
	}

	/**
	 * Sanitize submitted settings.
	 *
	 * Invalid ranges are rejected as a whole: the stored value stays untouched
	 * and the admin sees what exactly is wrong.
	 *
	 * @since 1.0.0
	 * @param mixed $input Raw value from the settings form.
	 * @return array
	 */
	public static function sanitize_settings( $input ) {
		$defaults = mvweb_sl_get_defaults();
		$current  = mvweb_sl_get_settings();

		if ( ! is_array( $input ) ) {
			return $current;
		}

		$raw_template = $input['template'] ?? $defaults['template'];

		if ( ! is_scalar( $raw_template ) ) {
			$raw_template = $defaults['template'];
		}

		$template = sanitize_text_field( (string) $raw_template );

		if ( '' === $template ) {
			$template = '%s';
		}

		if ( ! mvweb_sl_template_is_safe( $template ) ) {
			add_settings_error(
				MVWEB_SL_OPTION,
				'mvweb_sl_template',
				__( 'The template cannot be formatted. Use the placeholder once for the group wording, and double every other percent sign.', 'mvweb-stock-labels' )
			);
			return $current;
		}

		$output = array(
			'template' => $template,
			'bold'     => ! empty( $input['bold'] ),
			'groups'   => array(),
		);

		foreach ( $defaults['groups'] as $key => $group ) {
			$raw = ( isset( $input['groups'][ $key ] ) && is_array( $input['groups'][ $key ] ) )
				? $input['groups'][ $key ]
				: array();

			$raw_label = $raw['label'] ?? '';
			$raw_color = $raw['color'] ?? '';

			$label = is_scalar( $raw_label ) ? sanitize_text_field( (string) $raw_label ) : '';
			$color = is_scalar( $raw_color ) ? (string) sanitize_hex_color( (string) $raw_color ) : '';

			$output['groups'][ $key ] = array(
				'label' => '' !== $label ? $label : $group['label'],
				'color' => '' !== $color ? $color : $group['color'],
			);

			if ( isset( $group['from'] ) ) {
				$output['groups'][ $key ]['from'] = absint( $raw['from'] ?? $group['from'] );
			}

			if ( isset( $group['to'] ) ) {
				$output['groups'][ $key ]['to'] = absint( $raw['to'] ?? $group['to'] );
			}
		}

		$error = self::validate_ranges( $output['groups'] );

		if ( '' !== $error ) {
			add_settings_error( MVWEB_SL_OPTION, 'mvweb_sl_ranges', $error );
			return $current;
		}

		return $output;
	}

	/**
	 * Check group boundaries for reversed and overlapping ranges.
	 *
	 * @since 1.0.0
	 * @param array $groups Sanitized groups.
	 * @return string Error message, or an empty string when the ranges are valid.
	 */
	protected static function validate_ranges( array $groups ) {
		if ( $groups['low']['from'] < 1 ) {
			return __( 'The lower bound of the first group must be 1 or higher.', 'mvweb-stock-labels' );
		}

		if ( $groups['low']['to'] < $groups['low']['from'] ) {
			return __( 'In the first group the upper bound is below the lower bound.', 'mvweb-stock-labels' );
		}

		if ( $groups['mid']['to'] < $groups['mid']['from'] ) {
			return __( 'In the second group the upper bound is below the lower bound.', 'mvweb-stock-labels' );
		}

		if ( $groups['mid']['from'] <= $groups['low']['to'] ) {
			return __( 'The first and the second group overlap.', 'mvweb-stock-labels' );
		}

		if ( $groups['high']['from'] <= $groups['mid']['to'] ) {
			return __( 'The second and the third group overlap.', 'mvweb-stock-labels' );
		}

		return '';
	}

	/**
	 * Add the plugin page under the MVweb Hub menu.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_menu() {
		$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

		self::$hook_suffix = add_submenu_page(
			$parent_slug,
			__( 'Stock Labels', 'mvweb-stock-labels' ),
			__( 'Stock Labels', 'mvweb-stock-labels' ),
			self::CAPABILITY,
			self::PAGE_SLUG,
			array( __CLASS__, 'render_settings_page' )
		);
	}

	/**
	 * Render the settings page wrapper.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_settings_page() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}

		require MVWEB_SL_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Enqueue admin assets on the plugin page only.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		if ( ! self::$hook_suffix || $hook !== self::$hook_suffix ) {
			return;
		}

		wp_enqueue_style(
			'mvweb-sl-admin-ui',
			MVWEB_SL_URL . 'admin/css/admin.min.css',
			array(),
			MVWEB_SL_VERSION
		);

		wp_enqueue_style(
			'mvweb-sl-admin-plugin',
			MVWEB_SL_URL . 'admin/css/plugin.min.css',
			array( 'mvweb-sl-admin-ui' ),
			MVWEB_SL_VERSION
		);

		wp_enqueue_script(
			'mvweb-sl-admin',
			MVWEB_SL_URL . 'admin/js/admin.min.js',
			array(),
			MVWEB_SL_VERSION,
			true
		);
	}
}
