<?php
/**
 * Helper functions for MVweb Price Table.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Generate a slug from string preserving Cyrillic characters.
 *
 * Unlike sanitize_title() which URL-encodes non-ASCII characters,
 * this function keeps Cyrillic letters as-is for proper key matching.
 *
 * @since 2.0.0
 * @param string $text Input text.
 * @return string Slug with preserved Cyrillic.
 */
function mvweb_pt_slug( $text ) {
	// Convert to lowercase (UTF-8 aware).
	$slug = mb_strtolower( $text, 'UTF-8' );

	// Replace spaces and multiple dashes with single dash.
	$slug = preg_replace( '/[\s_]+/u', '-', $slug );

	// Remove characters that are not letters (Latin or Cyrillic), numbers, or dashes.
	// \p{L} matches any Unicode letter, \p{N} matches any Unicode number.
	$slug = preg_replace( '/[^\p{L}\p{N}\-]/u', '', $slug );

	// Replace multiple dashes with single dash.
	$slug = preg_replace( '/-+/', '-', $slug );

	// Trim dashes from ends.
	$slug = trim( $slug, '-' );

	return $slug;
}

/**
 * Get plugin option.
 *
 * @since 1.0.0
 * @param string $key     Option key.
 * @param mixed  $default Default value.
 * @return mixed Option value.
 */
function mvweb_pt_get_option( $key, $default = '' ) {
	$settings = get_option( 'mvweb_pt_settings', array() );
	return isset( $settings[ $key ] ) ? $settings[ $key ] : $default;
}

/**
 * Update plugin option.
 *
 * @since 1.0.0
 * @param string $key   Option key.
 * @param mixed  $value Option value.
 * @return bool True on success.
 */
function mvweb_pt_update_option( $key, $value ) {
	$settings         = get_option( 'mvweb_pt_settings', array() );
	$settings[ $key ] = $value;
	return update_option( 'mvweb_pt_settings', $settings, false );
}

/**
 * Get all forms.
 *
 * @since 1.0.0
 * @return array Array of forms.
 */
function mvweb_pt_get_forms() {
	return get_option( 'mvweb_pt_forms', array() );
}

/**
 * Get a single form by ID.
 *
 * @since 1.0.0
 * @param int $form_id Form ID.
 * @return array|false Form data or false if not found.
 */
function mvweb_pt_get_form( $form_id ) {
	$forms   = mvweb_pt_get_forms();
	$form_id = absint( $form_id );

	return isset( $forms[ $form_id ] ) ? $forms[ $form_id ] : false;
}

/**
 * Save a form.
 *
 * @since 1.0.0
 * @since 2.0.0 Added field_mapping support.
 * @param array    $form_data Form data.
 * @param int|null $form_id   Form ID (null for new form).
 * @return int|WP_Error Form ID on success, WP_Error on failure.
 */
function mvweb_pt_save_form( $form_data, $form_id = null ) {
	// Validate required fields.
	if ( empty( $form_data['name'] ) ) {
		return new WP_Error(
			'missing_name',
			__( 'Form name is required.', 'mvweb-price-table' )
		);
	}

	if ( empty( $form_data['spreadsheet_url'] ) ) {
		return new WP_Error(
			'missing_url',
			__( 'Google Sheets URL is required.', 'mvweb-price-table' )
		);
	}

	// Validate spreadsheet URL.
	$sheets         = new MVweb_PT_Google_Sheets();
	$spreadsheet_id = $sheets->extract_spreadsheet_id( $form_data['spreadsheet_url'] );

	if ( ! $spreadsheet_id ) {
		return new WP_Error(
			'invalid_url',
			__( 'Invalid Google Sheets URL.', 'mvweb-price-table' )
		);
	}

	$forms = mvweb_pt_get_forms();

	// Generate new ID if not provided.
	if ( null === $form_id ) {
		$form_id = empty( $forms ) ? 1 : max( array_keys( $forms ) ) + 1;
	}

	$form_id = absint( $form_id );

	// Build form data with defaults.
	$form = array(
		'id'              => $form_id,
		'name'            => sanitize_text_field( $form_data['name'] ),
		'spreadsheet_url' => esc_url_raw( $form_data['spreadsheet_url'] ),
		'spreadsheet_id'  => $spreadsheet_id,
		'sheet_id'        => isset( $form_data['sheet_id'] ) && '' !== $form_data['sheet_id'] ? absint( $form_data['sheet_id'] ) : null,
		'sheet_name'      => isset( $form_data['sheet_name'] ) ? sanitize_text_field( $form_data['sheet_name'] ) : '',
		'status'          => isset( $form_data['status'] ) ? sanitize_key( $form_data['status'] ) : 'active',
		'preset'          => isset( $form_data['preset'] ) ? sanitize_key( $form_data['preset'] ) : 'light',
		'created_at'      => isset( $forms[ $form_id ]['created_at'] ) ? $forms[ $form_id ]['created_at'] : current_time( 'mysql' ),
		'updated_at'      => current_time( 'mysql' ),
		'settings'        => mvweb_pt_sanitize_form_settings(
			isset( $form_data['settings'] ) ? $form_data['settings'] : array()
		),
	);

	// v2.0: Handle field_mapping.
	if ( isset( $form_data['field_mapping'] ) ) {
		$form['field_mapping'] = mvweb_pt_sanitize_field_mapping( $form_data['field_mapping'] );
	} elseif ( isset( $forms[ $form_id ]['field_mapping'] ) ) {
		// Preserve existing field_mapping if not provided.
		$form['field_mapping'] = $forms[ $form_id ]['field_mapping'];
	} else {
		// Default to legacy mode for backward compatibility.
		$form['field_mapping'] = mvweb_pt_get_default_field_mapping();
	}

	$forms[ $form_id ] = $form;

	update_option( 'mvweb_pt_forms', $forms, false );

	// Clear resolved values cache when form is updated.
	if ( class_exists( 'MVweb_PT_Value_Resolver' ) ) {
		MVweb_PT_Value_Resolver::clear_cache( $form_id );
	}

	return $form_id;
}

/**
 * Delete a form.
 *
 * @since 1.0.0
 * @param int $form_id Form ID.
 * @return bool True on success, false on failure.
 */
function mvweb_pt_delete_form( $form_id ) {
	$forms   = mvweb_pt_get_forms();
	$form_id = absint( $form_id );

	if ( ! isset( $forms[ $form_id ] ) ) {
		return false;
	}

	unset( $forms[ $form_id ] );

	return update_option( 'mvweb_pt_forms', $forms, false );
}

/**
 * Sanitize form settings.
 *
 * @since 1.0.0
 * @param array $settings Form settings.
 * @return array Sanitized settings.
 */
function mvweb_pt_sanitize_form_settings( $settings ) {
	$defaults = array(
		'title'              => '',
		'description'        => '',
		'button_text'        => __( 'Show Prices', 'mvweb-price-table' ),
		'brand_label'        => __( 'Brand', 'mvweb-price-table' ),
		'type_label'         => __( 'Type', 'mvweb-price-table' ),
		'model_label'        => __( 'Model', 'mvweb-price-table' ),
		'brand_placeholder'  => __( 'Select brand', 'mvweb-price-table' ),
		'type_placeholder'   => __( 'Select type', 'mvweb-price-table' ),
		'model_placeholder'  => __( 'Select model', 'mvweb-price-table' ),
		'show_search'        => true,
		'show_groups'        => true,
		'auto_submit'        => false,
		'default_brand'      => '',
		'default_type'       => '',
		'default_model'      => '',
		'service_column'     => __( 'Service', 'mvweb-price-table' ),
		'time_column'        => __( 'Time', 'mvweb-price-table' ),
		'price_column'       => __( 'Price', 'mvweb-price-table' ),
		'no_results_text'    => __( 'No prices found for this model.', 'mvweb-price-table' ),
		'loading_text'       => __( 'Loading...', 'mvweb-price-table' ),
		'error_text'         => __( 'An error occurred. Please try again.', 'mvweb-price-table' ),
	);

	$sanitized = array();

	foreach ( $defaults as $key => $default ) {
		if ( isset( $settings[ $key ] ) ) {
			if ( is_bool( $default ) ) {
				$sanitized[ $key ] = (bool) $settings[ $key ];
			} else {
				$sanitized[ $key ] = sanitize_text_field( $settings[ $key ] );
			}
		} else {
			$sanitized[ $key ] = $default;
		}
	}

	return $sanitized;
}

/**
 * Get form default settings.
 *
 * @since 1.0.0
 * @return array Default settings.
 */
function mvweb_pt_get_default_form_settings() {
	return mvweb_pt_sanitize_form_settings( array() );
}

/**
 * Generate shortcode string for a form.
 *
 * @since 1.0.0
 * @param int   $form_id Form ID.
 * @param array $atts    Additional attributes.
 * @return string Shortcode string.
 */
function mvweb_pt_get_shortcode( $form_id, $atts = array() ) {
	$shortcode = '[mvweb_price_table id="' . absint( $form_id ) . '"';

	foreach ( $atts as $key => $value ) {
		$shortcode .= ' ' . esc_attr( $key ) . '="' . esc_attr( $value ) . '"';
	}

	$shortcode .= ']';

	return $shortcode;
}

/**
 * Render price table.
 *
 * Use this function to display a price table form in your theme templates.
 *
 * @since 1.0.0
 *
 * @param int   $form_id Form ID (required). Get form ID from the plugin admin.
 * @param array $args {
 *     Optional. Arguments to customize the calculator output.
 *
 *     @type bool   $show_title   Whether to show the form title. Default true.
 *     @type string $class        Additional CSS class(es) for the wrapper. Default ''.
 *     @type string $preset       Design preset (light, dark, minimal, brand). Default uses form setting.
 *     @type bool   $echo         Whether to echo or return the output. Default true.
 *     @type string $title        Custom title text. Default uses form setting.
 *     @type string $description  Custom description text. Default uses form setting.
 *     @type string $button_text  Custom button text. Default uses form setting.
 * }
 * @return string HTML output if echo is false, empty string otherwise.
 *
 * @example
 * // Basic usage - display form ID 1.
 * mvweb_price_calculator( 1 );
 *
 * @example
 * // With custom preset and without title.
 * mvweb_price_calculator( 1, array(
 *     'preset'     => 'dark',
 *     'show_title' => false,
 * ) );
 *
 * @example
 * // Return HTML instead of echoing.
 * $html = mvweb_price_calculator( 1, array( 'echo' => false ) );
 */
function mvweb_price_calculator( $form_id, $args = array() ) {
	$form = mvweb_pt_get_form( $form_id );

	if ( ! $form || 'active' !== $form['status'] ) {
		return '';
	}

	$defaults = array(
		'show_title' => true,
		'show_all'   => false,
		'class'      => '',
		'preset'     => $form['preset'],
		'echo'       => true,
	);

	$args = wp_parse_args( $args, $defaults );

	// Get global appearance settings.
	$global_settings = get_option( 'mvweb_pt_settings', array() );

	// Map global appearance settings to form settings keys.
	$global_appearance = array(
		'title'           => $global_settings['default_title'] ?? '',
		'description'     => $global_settings['default_description'] ?? '',
		'button_text'     => $global_settings['default_button_text'] ?? __( 'Show Prices', 'mvweb-price-table' ),
		'button_style'    => $global_settings['button_style'] ?? 'filled',
		'footer_text'     => $global_settings['footer_text'] ?? '',
		'service_column'  => $global_settings['service_column_label'] ?? __( 'Service', 'mvweb-price-table' ),
		'time_column'     => $global_settings['time_column_label'] ?? __( 'Time', 'mvweb-price-table' ),
		'price_column'    => $global_settings['price_column_label'] ?? __( 'Price', 'mvweb-price-table' ),
		'on_request_text' => $global_settings['on_request_text'] ?? __( 'On request', 'mvweb-price-table' ),
		'custom_css'      => $global_settings['custom_css'] ?? '',
	);

	// Start with default settings.
	$settings = mvweb_pt_get_default_form_settings();

	// Keys that are managed globally via Appearance tab.
	// Form settings for these keys should NOT override global settings
	// (they only contain defaults from form creation time).
	$global_only_keys = array(
		'button_text',
		'service_column',
		'time_column',
		'price_column',
		'on_request_text',
		'custom_css',
	);

	// Override with global appearance settings (only non-empty values).
	foreach ( $global_appearance as $key => $value ) {
		if ( '' !== $value ) {
			$settings[ $key ] = $value;
		}
	}

	// Override with form-specific settings (only non-empty values).
	// Skip global-only keys to prevent form defaults from overriding Appearance settings.
	foreach ( $form['settings'] as $key => $value ) {
		if ( '' !== $value && ! is_null( $value ) && ! in_array( $key, $global_only_keys, true ) ) {
			$settings[ $key ] = $value;
		}
	}

	// Override with shortcode args (highest priority).
	foreach ( $args as $key => $value ) {
		if ( '' !== $value && ! is_null( $value ) && 'echo' !== $key ) {
			$settings[ $key ] = $value;
		}
	}

	// Enqueue assets with specific preset.
	mvweb_pt_enqueue_public_assets( $args['preset'] );

	// Start output buffering.
	ob_start();

	// Include template.
	include MVWEB_PT_PATH . 'public/views/calculator-form.php';

	$output = ob_get_clean();

	if ( $args['echo'] ) {
		echo $output; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	return $output;
}

/**
 * Enqueue public assets.
 *
 * @since 1.0.0
 * @param string $preset Optional preset to load. Defaults to 'light'.
 * @return void
 */
function mvweb_pt_enqueue_public_assets( $preset = 'light' ) {
	static $enqueued        = false;
	static $loaded_presets  = array();

	$settings    = get_option( 'mvweb_pt_settings', array() );
	$use_choices = isset( $settings['use_choices'] ) ? (bool) $settings['use_choices'] : true;

	// Use minified assets in production.
	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

	// Base assets (only enqueue once).
	if ( ! $enqueued ) {
		// Choices.js (if enabled).
		if ( $use_choices ) {
			wp_enqueue_style(
				'choices-js',
				MVWEB_PT_URL . 'assets/vendor/choices.min.css',
				array(),
				'11.0.2'
			);

			wp_enqueue_script(
				'choices-js',
				MVWEB_PT_URL . 'assets/vendor/choices.min.js',
				array(),
				'11.0.2',
				true
			);
		}

		// Base styles.
		wp_enqueue_style(
			'mvweb-pc-public',
			MVWEB_PT_URL . 'public/css/public' . $suffix . '.css',
			$use_choices ? array( 'choices-js' ) : array(),
			MVWEB_PT_VERSION
		);

		// Calculator script.
		wp_enqueue_script(
			'mvweb-pc-calculator',
			MVWEB_PT_URL . 'public/js/calculator' . $suffix . '.js',
			$use_choices ? array( 'choices-js' ) : array(),
			MVWEB_PT_VERSION,
			true
		);

		// Localize script.
		$currency_code = isset( $settings['currency'] ) ? $settings['currency'] : 'RUB';
		wp_localize_script(
			'mvweb-pc-calculator',
			'mvwebPcConfig',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( 'mvweb_pt_public' ),
				'currency'   => mvweb_pt_get_currency_symbol( $currency_code ),
				'useChoices' => $use_choices,
				'i18n'       => array(
					'loading'           => __( 'Loading...', 'mvweb-price-table' ),
					'error'             => __( 'An error occurred. Please try again.', 'mvweb-price-table' ),
					'noResults'         => __( 'No prices found.', 'mvweb-price-table' ),
					'searchPlaceholder' => __( 'Search...', 'mvweb-price-table' ),
					'noChoicesText'     => __( 'No options available', 'mvweb-price-table' ),
					'itemSelectText'    => '',
					'onRequest'         => isset( $settings['on_request_text'] ) ? $settings['on_request_text'] : __( 'On request', 'mvweb-price-table' ),
				),
			)
		);

		$enqueued = true;
	}

	// Validate preset.
	$valid_presets = array_keys( mvweb_pt_get_presets() );
	if ( ! in_array( $preset, $valid_presets, true ) ) {
		$preset = 'light';
	}

	// Load preset CSS (only once per preset).
	if ( ! in_array( $preset, $loaded_presets, true ) ) {
		$preset_file = MVWEB_PT_PATH . 'public/css/presets/' . $preset . $suffix . '.css';

		// Fallback to non-minified if minified doesn't exist.
		if ( ! file_exists( $preset_file ) ) {
			$preset_file = MVWEB_PT_PATH . 'public/css/presets/' . $preset . '.css';
			$suffix      = '';
		}

		if ( file_exists( $preset_file ) ) {
			wp_enqueue_style(
				'mvweb-pc-preset-' . $preset,
				MVWEB_PT_URL . 'public/css/presets/' . $preset . $suffix . '.css',
				array( 'mvweb-pc-public' ),
				MVWEB_PT_VERSION
			);
		}

		$loaded_presets[] = $preset;
	}

	// Output custom CSS from settings.
	static $custom_css_added = false;
	if ( ! $custom_css_added && ! empty( $settings['custom_css'] ) ) {
		wp_add_inline_style( 'mvweb-pc-public', $settings['custom_css'] );
		$custom_css_added = true;
	}
}

/**
 * Log plugin message.
 *
 * @since 1.0.0
 * @param mixed  $message Message to log.
 * @param string $level   Log level (info, warning, error).
 * @return void
 */
function mvweb_pt_log( $message, $level = 'info' ) {
	if ( function_exists( 'mvweb_log' ) ) {
		mvweb_log( $message, 'MVweb Price Table', $level );
	}
}

/**
 * Format price for display.
 *
 * @since 1.0.0
 * @param mixed $price Price value.
 * @return string Formatted price.
 */
function mvweb_pt_format_price( $price ) {
	$settings      = get_option( 'mvweb_pt_settings', array() );
	$currency_code = isset( $settings['currency'] ) ? $settings['currency'] : 'RUB';
	$symbol        = mvweb_pt_get_currency_symbol( $currency_code );

	// If price is not numeric (e.g., "По запросу", range), return as-is.
	if ( ! is_numeric( $price ) ) {
		return esc_html( $price );
	}

	// Format number.
	$formatted = number_format( (float) $price, 0, ',', ' ' );

	return $formatted . ' ' . $symbol;
}

/**
 * Check if form exists and is active.
 *
 * @since 1.0.0
 * @param int $form_id Form ID.
 * @return bool True if form is active.
 */
function mvweb_pt_is_form_active( $form_id ) {
	$form = mvweb_pt_get_form( $form_id );

	return $form && 'active' === $form['status'];
}

/**
 * Get available presets.
 *
 * Presets are grouped by theme type (dark/light) for better UX in admin.
 *
 * @since 1.0.0
 * @since 1.2.0 Added 15 new modern design presets.
 * @return array Array of presets with slug => label.
 */
function mvweb_pt_get_presets() {
	return array(
		// Dark themes.
		'aurora'        => __( 'Aurora Borealis', 'mvweb-price-table' ),
		'carbon'        => __( 'Carbon Fiber', 'mvweb-price-table' ),
		'lavender'      => __( 'Lavender Haze', 'mvweb-price-table' ),

		// Light themes - neutral.
		'light'         => __( 'Light (Default)', 'mvweb-price-table' ),
		'classic-blue'  => __( 'Classic Blue', 'mvweb-price-table' ),
		'editorial'     => __( 'Editorial', 'mvweb-price-table' ),
		'soft-cloud'    => __( 'Soft Cloud', 'mvweb-price-table' ),
		'elegant-serif' => __( 'Elegant Serif', 'mvweb-price-table' ),
		'swiss'         => __( 'Swiss Minimal', 'mvweb-price-table' ),
		'paper-craft'   => __( 'Paper Craft', 'mvweb-price-table' ),
		'mvweb-brand'   => __( 'MVweb Brand', 'mvweb-price-table' ),

		// Light themes - colorful.
		'forest-green'  => __( 'Forest Green', 'mvweb-price-table' ),
		'ocean-blue'    => __( 'Ocean Blue', 'mvweb-price-table' ),
		'sky-cyan'      => __( 'Sky Cyan', 'mvweb-price-table' ),
		'teal-mint'     => __( 'Teal Mint', 'mvweb-price-table' ),
		'emerald'       => __( 'Emerald Gradient', 'mvweb-price-table' ),
	);
}

/**
 * Get available currencies.
 *
 * @since 1.1.0
 * @return array Array of currencies with codes, symbols and names.
 */
function mvweb_pt_get_currencies() {
	return array(
		'RUB' => array(
			'symbol' => '₽',
			'name'   => __( 'Russian Ruble', 'mvweb-price-table' ),
		),
		'USD' => array(
			'symbol' => '$',
			'name'   => __( 'US Dollar', 'mvweb-price-table' ),
		),
		'EUR' => array(
			'symbol' => '€',
			'name'   => __( 'Euro', 'mvweb-price-table' ),
		),
		'GBP' => array(
			'symbol' => '£',
			'name'   => __( 'British Pound', 'mvweb-price-table' ),
		),
		'UAH' => array(
			'symbol' => '₴',
			'name'   => __( 'Ukrainian Hryvnia', 'mvweb-price-table' ),
		),
		'KZT' => array(
			'symbol' => '₸',
			'name'   => __( 'Kazakhstani Tenge', 'mvweb-price-table' ),
		),
		'BYN' => array(
			'symbol' => 'Br',
			'name'   => __( 'Belarusian Ruble', 'mvweb-price-table' ),
		),
		'CNY' => array(
			'symbol' => '¥',
			'name'   => __( 'Chinese Yuan', 'mvweb-price-table' ),
		),
		'JPY' => array(
			'symbol' => '¥',
			'name'   => __( 'Japanese Yen', 'mvweb-price-table' ),
		),
		'TRY' => array(
			'symbol' => '₺',
			'name'   => __( 'Turkish Lira', 'mvweb-price-table' ),
		),
		'INR' => array(
			'symbol' => '₹',
			'name'   => __( 'Indian Rupee', 'mvweb-price-table' ),
		),
		'BRL' => array(
			'symbol' => 'R$',
			'name'   => __( 'Brazilian Real', 'mvweb-price-table' ),
		),
		'PLN' => array(
			'symbol' => 'zł',
			'name'   => __( 'Polish Zloty', 'mvweb-price-table' ),
		),
		'CHF' => array(
			'symbol' => 'CHF',
			'name'   => __( 'Swiss Franc', 'mvweb-price-table' ),
		),
		'AED' => array(
			'symbol' => 'د.إ',
			'name'   => __( 'UAE Dirham', 'mvweb-price-table' ),
		),
	);
}

/**
 * Get currency symbol by code.
 *
 * @since 1.1.0
 * @param string $code Currency code.
 * @return string Currency symbol.
 */
function mvweb_pt_get_currency_symbol( $code ) {
	// Handle custom currency.
	$code_upper = strtoupper( $code );
	if ( 'CUSTOM' === $code_upper ) {
		$settings = get_option( 'mvweb_pt_settings', array() );
		$custom   = isset( $settings['custom_currency'] ) ? $settings['custom_currency'] : '';
		return ! empty( $custom ) ? $custom : $code;
	}

	$currencies = mvweb_pt_get_currencies();
	// Normalize to uppercase for lookup (handles legacy lowercase values).
	return isset( $currencies[ $code_upper ]['symbol'] ) ? $currencies[ $code_upper ]['symbol'] : $code;
}

/*
|--------------------------------------------------------------------------
| Field Mapping v2.0 - Roles, Formats, Modes
|--------------------------------------------------------------------------
|
| Constants and whitelist validation functions for the dynamic field
| mapping system introduced in v2.0.
|
| @since 2.0.0
*/

/**
 * Get valid column roles for field mapping.
 *
 * Roles define what each column represents in the spreadsheet.
 * - hierarchy_* : Levels for cascading selection (brand > type > model)
 * - service_*   : Service-related data columns
 * - meta_*      : Additional metadata columns
 * - ignore      : Column to be skipped during parsing
 *
 * @since 2.0.0
 * @return array<string,string> Role slug => Label pairs.
 */
function mvweb_pt_get_valid_roles() {
	return array(
		// Hierarchy roles (for cascading selects).
		'hierarchy_1'    => __( 'Level 1', 'mvweb-price-table' ),
		'hierarchy_2'    => __( 'Level 2', 'mvweb-price-table' ),
		'hierarchy_3'    => __( 'Level 3', 'mvweb-price-table' ),
		'hierarchy_4'    => __( 'Level 4', 'mvweb-price-table' ),
		'hierarchy_5'    => __( 'Level 5', 'mvweb-price-table' ),

		// Service data roles.
		'service_name'   => __( 'Service Name', 'mvweb-price-table' ),
		'service_price'  => __( 'Price', 'mvweb-price-table' ),
		'service_time'   => __( 'Time/Duration', 'mvweb-price-table' ),
		'service_group'  => __( 'Service Group', 'mvweb-price-table' ),

		// Meta roles for additional data.
		'meta_note'      => __( 'Note/Description', 'mvweb-price-table' ),
		'meta_warranty'  => __( 'Warranty', 'mvweb-price-table' ),
		'meta_sku'       => __( 'SKU/Article', 'mvweb-price-table' ),
		'meta_custom_1'  => __( 'Custom Field 1', 'mvweb-price-table' ),
		'meta_custom_2'  => __( 'Custom Field 2', 'mvweb-price-table' ),

		// Special roles.
		'ignore'         => __( 'Ignore Column', 'mvweb-price-table' ),
	);
}

/**
 * Get hierarchy roles only.
 *
 * @since 2.0.0
 * @return array<string,string> Hierarchy role slug => Label pairs.
 */
function mvweb_pt_get_hierarchy_roles() {
	$roles = mvweb_pt_get_valid_roles();
	return array_filter(
		$roles,
		function ( $key ) {
			return strpos( $key, 'hierarchy_' ) === 0;
		},
		ARRAY_FILTER_USE_KEY
	);
}

/**
 * Get service roles only.
 *
 * @since 2.0.0
 * @return array<string,string> Service role slug => Label pairs.
 */
function mvweb_pt_get_service_roles() {
	$roles = mvweb_pt_get_valid_roles();
	return array_filter(
		$roles,
		function ( $key ) {
			return strpos( $key, 'service_' ) === 0;
		},
		ARRAY_FILTER_USE_KEY
	);
}

/**
 * Get valid display formats for columns.
 *
 * Formats define how values should be rendered.
 *
 * @since 2.0.0
 * @return array<string,string> Format slug => Label pairs.
 */
function mvweb_pt_get_valid_formats() {
	return array(
		'text'     => __( 'Plain Text', 'mvweb-price-table' ),
		'currency' => __( 'Currency (Price)', 'mvweb-price-table' ),
		'duration' => __( 'Duration (Time)', 'mvweb-price-table' ),
		'number'   => __( 'Number', 'mvweb-price-table' ),
		'html'     => __( 'HTML (sanitized)', 'mvweb-price-table' ),
	);
}

/**
 * Get valid parsing modes.
 *
 * Modes determine how the spreadsheet data is parsed.
 * - legacy : Fixed column positions (0-5) for backward compatibility
 * - mapped : Dynamic positions based on field_mapping configuration
 *
 * @since 2.0.0
 * @return array<string,string> Mode slug => Label pairs.
 */
function mvweb_pt_get_valid_modes() {
	return array(
		'legacy' => __( 'Legacy (Fixed Columns)', 'mvweb-price-table' ),
		'mapped' => __( 'Mapped (Dynamic Columns)', 'mvweb-price-table' ),
	);
}

/**
 * Validate a role value against whitelist.
 *
 * @since 2.0.0
 * @param string $role Role to validate.
 * @return bool True if valid.
 */
function mvweb_pt_is_valid_role( $role ) {
	$valid_roles = array_keys( mvweb_pt_get_valid_roles() );
	return in_array( $role, $valid_roles, true );
}

/**
 * Validate a format value against whitelist.
 *
 * @since 2.0.0
 * @param string $format Format to validate.
 * @return bool True if valid.
 */
function mvweb_pt_is_valid_format( $format ) {
	$valid_formats = array_keys( mvweb_pt_get_valid_formats() );
	return in_array( $format, $valid_formats, true );
}

/**
 * Validate a mode value against whitelist.
 *
 * @since 2.0.0
 * @param string $mode Mode to validate.
 * @return bool True if valid.
 */
function mvweb_pt_is_valid_mode( $mode ) {
	$valid_modes = array_keys( mvweb_pt_get_valid_modes() );
	return in_array( $mode, $valid_modes, true );
}

/**
 * Sanitize a hierarchy value (brand, type, model).
 *
 * SEC-001: Blocks wildcard characters in user input to prevent
 * template injection attacks.
 *
 * @since 2.0.0
 * @param string $value Value to sanitize.
 * @return string Sanitized value with wildcards removed.
 */
function mvweb_pt_sanitize_hierarchy_value( $value ) {
	$value = sanitize_text_field( $value );

	// Block wildcard characters that could match templates.
	$value = str_replace( array( '*', '%' ), '', $value );

	// Limit length to prevent DoS.
	if ( strlen( $value ) > 100 ) {
		$value = substr( $value, 0, 100 );
	}

	return $value;
}

/**
 * Get default field mapping structure.
 *
 * This is the canonical structure for field_mapping v2.0.
 * Used for new forms and as reference for validation.
 *
 * @since 2.0.0
 * @return array Default field mapping structure.
 */
function mvweb_pt_get_default_field_mapping() {
	return array(
		'schema_version' => '2.0',
		'mode'           => 'legacy', // legacy | mapped
		'columns'        => array(
			// Default legacy mapping (same as v1.x behavior).
			array(
				'index'  => 0,
				'role'   => 'hierarchy_1',
				'label'  => __( 'Brand', 'mvweb-price-table' ),
				'format' => 'text',
			),
			array(
				'index'  => 1,
				'role'   => 'hierarchy_2',
				'label'  => __( 'Type', 'mvweb-price-table' ),
				'format' => 'text',
			),
			array(
				'index'  => 2,
				'role'   => 'hierarchy_3',
				'label'  => __( 'Model', 'mvweb-price-table' ),
				'format' => 'text',
			),
			array(
				'index'  => 3,
				'role'   => 'service_name',
				'label'  => __( 'Service', 'mvweb-price-table' ),
				'format' => 'text',
			),
			array(
				'index'  => 4,
				'role'   => 'service_time',
				'label'  => __( 'Time', 'mvweb-price-table' ),
				'format' => 'duration',
			),
			array(
				'index'  => 5,
				'role'   => 'service_price',
				'label'  => __( 'Price', 'mvweb-price-table' ),
				'format' => 'currency',
			),
		),
		'inheritance'    => array(
			'enabled'        => false,
			'wildcard'       => '*',
			'show_source'    => false, // Debug: show value origin.
		),
	);
}

/**
 * Get legacy field mapping for v1.x forms.
 *
 * Creates a field mapping structure that matches v1.x behavior
 * with fixed column positions (0-5).
 *
 * @since 2.0.0
 * @return array Legacy field mapping structure.
 */
function mvweb_pt_get_legacy_field_mapping() {
	return array(
		'schema_version' => '2.0',
		'mode'           => 'legacy',
		'columns'        => array(
			array(
				'index'  => 0,
				'role'   => 'hierarchy_1',
				'label'  => __( 'Brand', 'mvweb-price-table' ),
				'format' => 'text',
			),
			array(
				'index'  => 1,
				'role'   => 'hierarchy_2',
				'label'  => __( 'Type', 'mvweb-price-table' ),
				'format' => 'text',
			),
			array(
				'index'  => 2,
				'role'   => 'hierarchy_3',
				'label'  => __( 'Model', 'mvweb-price-table' ),
				'format' => 'text',
			),
			array(
				'index'  => 3,
				'role'   => 'service_name',
				'label'  => __( 'Service', 'mvweb-price-table' ),
				'format' => 'text',
			),
			array(
				'index'  => 4,
				'role'   => 'service_time',
				'label'  => __( 'Time', 'mvweb-price-table' ),
				'format' => 'duration',
			),
			array(
				'index'  => 5,
				'role'   => 'service_price',
				'label'  => __( 'Price', 'mvweb-price-table' ),
				'format' => 'currency',
			),
		),
		'inheritance'    => array(
			'enabled'     => false,
			'wildcard'    => '*',
			'show_source' => false,
		),
	);
}

/**
 * Sanitize field mapping structure.
 *
 * Validates and sanitizes the entire field_mapping array.
 * Uses whitelist validation for roles, formats, and modes.
 *
 * @since 2.0.0
 * @param array $mapping Raw field mapping data.
 * @return array Sanitized field mapping.
 */
function mvweb_pt_sanitize_field_mapping( $mapping ) {
	// DEBUG: Log incoming mapping mode.
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		error_log( 'MVWEB DEBUG: field_mapping mode = ' . ( isset( $mapping['mode'] ) ? $mapping['mode'] : 'NOT SET' ) );
	}

	$default = mvweb_pt_get_default_field_mapping();

	// Start with defaults.
	$sanitized = array(
		'schema_version' => '2.0',
		'mode'           => 'legacy',
		'columns'        => array(),
		'inheritance'    => array(
			'enabled'     => false,
			'wildcard'    => '*',
			'show_source' => false,
		),
	);

	// Validate mode.
	if ( isset( $mapping['mode'] ) && mvweb_pt_is_valid_mode( $mapping['mode'] ) ) {
		$sanitized['mode'] = $mapping['mode'];
	}

	// Sanitize columns.
	if ( isset( $mapping['columns'] ) && is_array( $mapping['columns'] ) ) {
		foreach ( $mapping['columns'] as $column ) {
			if ( ! is_array( $column ) ) {
				continue;
			}

			$sanitized_column = array(
				'index'             => isset( $column['index'] ) ? absint( $column['index'] ) : 0,
				'role'              => 'ignore',
				'label'             => '',
				'format'            => 'text',
				'full_width_mobile' => false,
			);

			// Validate role (whitelist).
			if ( isset( $column['role'] ) && mvweb_pt_is_valid_role( $column['role'] ) ) {
				$sanitized_column['role'] = $column['role'];
			}

			// Sanitize label (max 100 chars).
			if ( isset( $column['label'] ) ) {
				$sanitized_column['label'] = sanitize_text_field(
					substr( $column['label'], 0, 100 )
				);
			}

			// Validate format (whitelist).
			if ( isset( $column['format'] ) && mvweb_pt_is_valid_format( $column['format'] ) ) {
				$sanitized_column['format'] = $column['format'];
			}

			// Sanitize full_width_mobile (boolean).
			if ( isset( $column['full_width_mobile'] ) ) {
				$sanitized_column['full_width_mobile'] = (bool) $column['full_width_mobile'];
			}

			$sanitized['columns'][] = $sanitized_column;
		}
	}

	// Use default columns if none provided.
	if ( empty( $sanitized['columns'] ) ) {
		$sanitized['columns'] = $default['columns'];
	}

	// Sanitize inheritance settings.
	if ( isset( $mapping['inheritance'] ) && is_array( $mapping['inheritance'] ) ) {
		$sanitized['inheritance']['enabled'] = ! empty( $mapping['inheritance']['enabled'] );

		// Wildcard: only allow specific safe characters.
		if ( isset( $mapping['inheritance']['wildcard'] ) ) {
			$wildcard = $mapping['inheritance']['wildcard'];
			// Only allow * or ** as wildcards.
			$sanitized['inheritance']['wildcard'] = in_array( $wildcard, array( '*', '**' ), true )
				? $wildcard
				: '*';
		}

		$sanitized['inheritance']['show_source'] = ! empty( $mapping['inheritance']['show_source'] );
	}

	return $sanitized;
}

/*
|--------------------------------------------------------------------------
| Migration Functions v2.0
|--------------------------------------------------------------------------
|
| SEC-006: Migration functions with mandatory backup and rollback support.
|
| @since 2.0.0
*/

/**
 * Migrate all forms to v2.0 format.
 *
 * SEC-006: Creates backup before migration. Each form gets legacy field_mapping
 * structure to maintain backward compatibility.
 *
 * @since 2.0.0
 * @return array{
 *     success: bool,
 *     migrated: int,
 *     backup_key: string,
 *     errors: array<string>
 * } Migration result.
 */
function mvweb_pt_migrate_to_v2() {
	$forms  = mvweb_pt_get_forms();
	$result = array(
		'success'    => true,
		'migrated'   => 0,
		'backup_key' => '',
		'errors'     => array(),
	);

	// Nothing to migrate.
	if ( empty( $forms ) ) {
		$result['backup_key'] = 'no_forms';
		return $result;
	}

	// SEC-006: Create backup before migration.
	$backup_key = 'mvweb_pt_forms_backup_' . gmdate( 'Y-m-d_H-i-s' );
	$backup_ok  = add_option( $backup_key, $forms, '', false );

	if ( ! $backup_ok ) {
		$result['success']  = false;
		$result['errors'][] = __( 'Failed to create backup. Migration aborted.', 'mvweb-price-table' );
		return $result;
	}

	$result['backup_key'] = $backup_key;

	// Get legacy field mapping template.
	$legacy_mapping = mvweb_pt_get_legacy_field_mapping();

	// Migrate each form.
	$migrated_count = 0;
	foreach ( $forms as $form_id => $form ) {
		// Skip if already has field_mapping with schema_version 2.0.
		if (
			isset( $form['field_mapping']['schema_version'] ) &&
			'2.0' === $form['field_mapping']['schema_version']
		) {
			continue;
		}

		// Add legacy field_mapping to form.
		$forms[ $form_id ]['field_mapping'] = $legacy_mapping;
		++$migrated_count;
	}

	// Save migrated forms.
	if ( $migrated_count > 0 ) {
		$saved = update_option( 'mvweb_pt_forms', $forms, false );

		if ( ! $saved ) {
			$result['success']  = false;
			$result['errors'][] = __( 'Failed to save migrated forms.', 'mvweb-price-table' );
			return $result;
		}
	}

	$result['migrated'] = $migrated_count;

	// Store migration info for admin notice.
	set_transient(
		'mvweb_pt_migration_notice',
		array(
			'migrated'   => $migrated_count,
			'backup_key' => $backup_key,
			'time'       => current_time( 'mysql' ),
		),
		HOUR_IN_SECONDS
	);

	return $result;
}

/**
 * Rollback a single form to pre-migration state.
 *
 * SEC-006: Restores form from backup option.
 *
 * @since 2.0.0
 * @param int    $form_id    Form ID to rollback.
 * @param string $backup_key Backup option key (default: auto-detect latest).
 * @return bool|WP_Error True on success, WP_Error on failure.
 */
function mvweb_pt_rollback_form( $form_id, $backup_key = '' ) {
	$form_id = absint( $form_id );

	// Find backup key if not provided.
	if ( empty( $backup_key ) ) {
		$backup_key = mvweb_pt_get_latest_backup_key();

		if ( ! $backup_key ) {
			return new WP_Error(
				'no_backup',
				__( 'No backup found for rollback.', 'mvweb-price-table' )
			);
		}
	}

	// Get backup data.
	$backup_forms = get_option( $backup_key, array() );

	if ( empty( $backup_forms ) ) {
		return new WP_Error(
			'backup_empty',
			__( 'Backup is empty or corrupted.', 'mvweb-price-table' )
		);
	}

	// Check if form exists in backup.
	if ( ! isset( $backup_forms[ $form_id ] ) ) {
		return new WP_Error(
			'form_not_in_backup',
			sprintf(
				/* translators: %d: form ID */
				__( 'Form ID %d not found in backup.', 'mvweb-price-table' ),
				$form_id
			)
		);
	}

	// Get current forms and replace the target form.
	$forms              = mvweb_pt_get_forms();
	$forms[ $form_id ]  = $backup_forms[ $form_id ];

	// Save.
	$saved = update_option( 'mvweb_pt_forms', $forms, false );

	if ( ! $saved ) {
		return new WP_Error(
			'save_failed',
			__( 'Failed to save rollback.', 'mvweb-price-table' )
		);
	}

	// Clear caches for this form.
	if ( class_exists( 'MVweb_PT_Value_Resolver' ) ) {
		MVweb_PT_Value_Resolver::clear_cache( $form_id );
	}

	return true;
}

/**
 * Rollback all forms to pre-migration state.
 *
 * SEC-006: Restores entire forms array from backup.
 *
 * @since 2.0.0
 * @param string $backup_key Backup option key (default: auto-detect latest).
 * @return bool|WP_Error True on success, WP_Error on failure.
 */
function mvweb_pt_rollback_all_forms( $backup_key = '' ) {
	// Find backup key if not provided.
	if ( empty( $backup_key ) ) {
		$backup_key = mvweb_pt_get_latest_backup_key();

		if ( ! $backup_key ) {
			return new WP_Error(
				'no_backup',
				__( 'No backup found for rollback.', 'mvweb-price-table' )
			);
		}
	}

	// Get backup data.
	$backup_forms = get_option( $backup_key, array() );

	if ( empty( $backup_forms ) && 'no_forms' !== $backup_key ) {
		return new WP_Error(
			'backup_empty',
			__( 'Backup is empty or corrupted.', 'mvweb-price-table' )
		);
	}

	// Restore entire forms array.
	$saved = update_option( 'mvweb_pt_forms', $backup_forms, false );

	if ( ! $saved && ! empty( $backup_forms ) ) {
		return new WP_Error(
			'save_failed',
			__( 'Failed to save rollback.', 'mvweb-price-table' )
		);
	}

	// Clear all caches.
	if ( class_exists( 'MVweb_PT_Value_Resolver' ) ) {
		foreach ( array_keys( $backup_forms ) as $form_id ) {
			MVweb_PT_Value_Resolver::clear_cache( $form_id );
		}
	}

	// Downgrade version.
	update_option( 'mvweb_pt_version', '1.0.0' );

	return true;
}

/**
 * Get the latest backup option key.
 *
 * @since 2.0.0
 * @return string|false Backup key or false if not found.
 */
function mvweb_pt_get_latest_backup_key() {
	global $wpdb;

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	$backup_key = $wpdb->get_var(
		"SELECT option_name FROM {$wpdb->options}
		WHERE option_name LIKE 'mvweb_pt_forms_backup_%'
		ORDER BY option_name DESC
		LIMIT 1"
	);

	return $backup_key ? $backup_key : false;
}

/**
 * Get all available backups.
 *
 * @since 2.0.0
 * @return array<string,array{key: string, date: string, forms_count: int}> Backup info.
 */
function mvweb_pt_get_backups() {
	global $wpdb;

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	$backup_keys = $wpdb->get_col(
		"SELECT option_name FROM {$wpdb->options}
		WHERE option_name LIKE 'mvweb_pt_forms_backup_%'
		ORDER BY option_name DESC
		LIMIT 10"
	);

	$backups = array();

	foreach ( $backup_keys as $key ) {
		// Extract date from key: mvweb_pt_forms_backup_2024-01-15_10-30-45.
		$date_part = str_replace( 'mvweb_pt_forms_backup_', '', $key );
		$date_part = str_replace( '_', ' ', $date_part );
		$date_part = str_replace( '-', ':', substr( $date_part, 11 ) );
		$date_str  = substr( $date_part, 0, 10 ) . ' ' . $date_part;

		// Get forms count.
		$backup_data  = get_option( $key, array() );
		$forms_count  = is_array( $backup_data ) ? count( $backup_data ) : 0;

		$backups[] = array(
			'key'         => $key,
			'date'        => $date_str,
			'forms_count' => $forms_count,
		);
	}

	return $backups;
}

/**
 * Delete old backups keeping only the latest N.
 *
 * @since 2.0.0
 * @param int $keep Number of backups to keep (default 5).
 * @return int Number of deleted backups.
 */
function mvweb_pt_cleanup_old_backups( $keep = 5 ) {
	global $wpdb;

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	$backup_keys = $wpdb->get_col(
		"SELECT option_name FROM {$wpdb->options}
		WHERE option_name LIKE 'mvweb_pt_forms_backup_%'
		ORDER BY option_name DESC"
	);

	$deleted = 0;

	// Keep first $keep backups, delete the rest.
	if ( count( $backup_keys ) > $keep ) {
		$to_delete = array_slice( $backup_keys, $keep );

		foreach ( $to_delete as $key ) {
			if ( delete_option( $key ) ) {
				++$deleted;
			}
		}
	}

	return $deleted;
}

/*
|--------------------------------------------------------------------------
| Model Normalization Functions v2.1
|--------------------------------------------------------------------------
|
| Functions for normalizing and comparing model names.
| Used by Price Resolver for priority-based price matching.
|
| @since 2.1.0
*/

/**
 * Normalize model name for comparison.
 *
 * Handles case-insensitivity, Unicode normalization, and similar
 * looking characters (Russian/English lookalikes).
 *
 * @since 2.1.0
 * @param string $name Model name.
 * @return string Normalized name.
 */
function mvweb_pt_normalize_model_name( $name ) {
	if ( class_exists( 'MVweb_PT_Price_Resolver' ) ) {
		return MVweb_PT_Price_Resolver::normalize_model( $name );
	}

	// Fallback implementation.
	$normalized = trim( $name );
	$normalized = mb_strtolower( $normalized, 'UTF-8' );
	$normalized = preg_replace( '/\s+/u', ' ', $normalized );

	return $normalized;
}

/**
 * Check if two models match (case-insensitive, normalized).
 *
 * @since 2.1.0
 * @param string $model_a First model name.
 * @param string $model_b Second model name.
 * @return bool True if models match.
 */
function mvweb_pt_models_match( $model_a, $model_b ) {
	if ( class_exists( 'MVweb_PT_Price_Resolver' ) ) {
		return MVweb_PT_Price_Resolver::models_match( $model_a, $model_b );
	}

	return mvweb_pt_normalize_model_name( $model_a ) === mvweb_pt_normalize_model_name( $model_b );
}

/**
 * Check if a pattern matches a model name.
 *
 * Pattern is a prefix match:
 * - "iPhone 17" matches "iPhone 17", "iPhone 17 Pro", "iPhone 17 Pro Max"
 *
 * @since 2.1.0
 * @param string $pattern    Pattern text (prefix to match).
 * @param string $model_name Model name.
 * @return bool True if model starts with pattern.
 */
function mvweb_pt_pattern_matches( $pattern, $model_name ) {
	if ( class_exists( 'MVweb_PT_Price_Resolver' ) ) {
		return MVweb_PT_Price_Resolver::pattern_matches( $pattern, $model_name );
	}

	// Fallback implementation: prefix match.
	$pattern_norm = mvweb_pt_normalize_model_name( $pattern );
	$model_norm   = mvweb_pt_normalize_model_name( $model_name );

	return strpos( $model_norm, $pattern_norm ) === 0;
}

/**
 * Calculate pattern specificity (higher = more specific).
 *
 * @since 2.1.0
 * @param string $pattern Pattern string (without braces).
 * @return int Specificity score.
 */
function mvweb_pt_pattern_specificity( $pattern ) {
	if ( class_exists( 'MVweb_PT_Price_Resolver' ) ) {
		return MVweb_PT_Price_Resolver::pattern_specificity( $pattern );
	}

	// Fallback implementation.
	$pattern_norm = mvweb_pt_normalize_model_name( $pattern );
	$chars        = preg_replace( '/[^\p{L}\p{N}]/u', '', $pattern_norm );

	return mb_strlen( $chars, 'UTF-8' );
}

/**
 * Check if field mapping migration is needed.
 *
 * @since 1.0.0
 * @return bool True if migration is needed.
 */
function mvweb_pt_needs_migration() {
	$current_version = get_option( 'mvweb_pt_version', '1.0.0' );

	// Already migrated.
	if ( version_compare( $current_version, '1.0.0', '>=' ) ) {
		return false;
	}

	// Check if any forms exist without field_mapping.
	$forms = mvweb_pt_get_forms();

	if ( empty( $forms ) ) {
		return false;
	}

	foreach ( $forms as $form ) {
		if ( ! isset( $form['field_mapping']['schema_version'] ) ) {
			return true;
		}
	}

	return false;
}
