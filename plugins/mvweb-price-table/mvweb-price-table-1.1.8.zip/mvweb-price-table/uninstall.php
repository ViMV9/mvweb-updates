<?php
/**
 * Uninstall MVweb Price Table
 *
 * Fired when the plugin is uninstalled.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Clean up plugin data.
 *
 * @return void
 */
function mvweb_pt_uninstall_cleanup() {
	global $wpdb;

	// Check if user wants to keep data.
	$settings = get_option( 'mvweb_pt_settings', array() );
	if ( ! empty( $settings['keep_data_on_uninstall'] ) ) {
		return;
	}

	// Drop statistics table.
	$table_name = $wpdb->prefix . 'mvweb_pt_stats';
	$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $table_name ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange

	// Delete plugin options.
	$options = array(
		'mvweb_pt_settings',
		'mvweb_pt_forms',
		'mvweb_pt_version',
		'mvweb_pt_cache_errors',
	);

	foreach ( $options as $option ) {
		delete_option( $option );
	}

	// Delete all transients with our prefix.
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
			$wpdb->esc_like( '_transient_mvweb_pt_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_mvweb_pt_' ) . '%'
		)
	);

	// Delete fallback options and their metadata.
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
			$wpdb->esc_like( 'mvweb_pt_fallback_' ) . '%'
		)
	);

	// Clear scheduled events.
	wp_clear_scheduled_hook( 'mvweb_pt_cache_refresh' );
	wp_clear_scheduled_hook( 'mvweb_pt_stats_cleanup' );
	wp_clear_scheduled_hook( 'mvweb_pt_flush_stats' );

	// Delete stats buffer transient.
	delete_transient( 'mvweb_pt_stats_buffer' );
}

// Run cleanup on single site.
mvweb_pt_uninstall_cleanup();

// For multisite, clean up each site.
if ( is_multisite() ) {
	$sites = get_sites();
	foreach ( $sites as $site ) {
		switch_to_blog( $site->blog_id );
		mvweb_pt_uninstall_cleanup();
		restore_current_blog();
	}
}

// Clear any cached data.
wp_cache_flush();
