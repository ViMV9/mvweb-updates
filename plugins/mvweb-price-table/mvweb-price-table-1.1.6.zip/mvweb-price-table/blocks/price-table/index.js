/**
 * MVweb Price Table Gutenberg Block.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

( function ( wp ) {
	const { registerBlockType } = wp.blocks;
	const { useBlockProps, InspectorControls } = wp.blockEditor;
	const {
		PanelBody,
		SelectControl,
		ToggleControl,
		TextControl,
		Placeholder,
		Spinner,
	} = wp.components;
	const { useEffect, useState } = wp.element;
	const { __ } = wp.i18n;

	// Get forms data from localized script.
	const formsData = window.mvwebPtBlockData || { forms: [], presets: [] };

	registerBlockType( 'mvweb/price-table', {
		edit: function ( props ) {
			const { attributes, setAttributes } = props;
			const {
				formId,
				preset,
				showTitle,
				customTitle,
				customDescription,
				customButtonText,
			} = attributes;

			const blockProps = useBlockProps();
			const [ isLoading, setIsLoading ] = useState( false );

			// Build form options.
			const formOptions = [
				{ label: __( '— Select a form —', 'mvweb-price-table' ), value: 0 },
			];
			formsData.forms.forEach( function ( form ) {
				formOptions.push( {
					label: form.name + ( form.status !== 'active' ? ' (' + __( 'Inactive', 'mvweb-price-table' ) + ')' : '' ),
					value: form.id,
				} );
			} );

			// Build preset options.
			const presetOptions = [
				{ label: __( '— Use form default —', 'mvweb-price-table' ), value: '' },
			];
			Object.keys( formsData.presets ).forEach( function ( key ) {
				presetOptions.push( {
					label: formsData.presets[ key ],
					value: key,
				} );
			} );

			// Get selected form data.
			const selectedForm = formsData.forms.find( function ( form ) {
				return form.id === formId;
			} );

			return wp.element.createElement(
				wp.element.Fragment,
				null,
				wp.element.createElement(
					InspectorControls,
					null,
					wp.element.createElement(
						PanelBody,
						{
							title: __( 'Form Settings', 'mvweb-price-table' ),
							initialOpen: true,
						},
						wp.element.createElement( SelectControl, {
							label: __( 'Select Form', 'mvweb-price-table' ),
							value: formId,
							options: formOptions,
							onChange: function ( value ) {
								setAttributes( { formId: parseInt( value, 10 ) } );
							},
							help: formId
								? __( 'Shortcode:', 'mvweb-price-table' ) +
								  ' [mvweb_price_table id="' +
								  formId +
								  '"]'
								: '',
						} ),
						wp.element.createElement( SelectControl, {
							label: __( 'Design Preset', 'mvweb-price-table' ),
							value: preset,
							options: presetOptions,
							onChange: function ( value ) {
								setAttributes( { preset: value } );
							},
						} ),
						wp.element.createElement( ToggleControl, {
							label: __( 'Show Title', 'mvweb-price-table' ),
							checked: showTitle,
							onChange: function ( value ) {
								setAttributes( { showTitle: value } );
							},
						} )
					),
					wp.element.createElement(
						PanelBody,
						{
							title: __( 'Custom Text', 'mvweb-price-table' ),
							initialOpen: false,
						},
						wp.element.createElement( TextControl, {
							label: __( 'Custom Title', 'mvweb-price-table' ),
							value: customTitle,
							onChange: function ( value ) {
								setAttributes( { customTitle: value } );
							},
							help: __(
								'Leave empty to use form default.',
								'mvweb-price-table'
							),
						} ),
						wp.element.createElement( TextControl, {
							label: __( 'Custom Description', 'mvweb-price-table' ),
							value: customDescription,
							onChange: function ( value ) {
								setAttributes( { customDescription: value } );
							},
						} ),
						wp.element.createElement( TextControl, {
							label: __( 'Custom Button Text', 'mvweb-price-table' ),
							value: customButtonText,
							onChange: function ( value ) {
								setAttributes( { customButtonText: value } );
							},
						} )
					)
				),
				wp.element.createElement(
					'div',
					blockProps,
					! formId
						? wp.element.createElement(
								Placeholder,
								{
									icon: 'calculator',
									label: __( 'Price Table', 'mvweb-price-table' ),
									instructions: __(
										'Select a calculator form to display.',
										'mvweb-price-table'
									),
								},
								wp.element.createElement( SelectControl, {
									value: formId,
									options: formOptions,
									onChange: function ( value ) {
										setAttributes( { formId: parseInt( value, 10 ) } );
									},
								} )
						  )
						: wp.element.createElement(
								'div',
								{ className: 'mvweb-pc-block-preview' },
								wp.element.createElement(
									'div',
									{ className: 'mvweb-pc-block-preview__header' },
									wp.element.createElement( 'span', {
										className: 'dashicons dashicons-calculator',
									} ),
									wp.element.createElement(
										'strong',
										null,
										__( 'Price Table', 'mvweb-price-table' )
									)
								),
								wp.element.createElement(
									'div',
									{ className: 'mvweb-pc-block-preview__content' },
									wp.element.createElement(
										'p',
										null,
										wp.element.createElement( 'strong', null, __( 'Form:', 'mvweb-price-table' ) + ' ' ),
										selectedForm ? selectedForm.name : __( 'Unknown', 'mvweb-price-table' )
									),
									preset &&
										wp.element.createElement(
											'p',
											null,
											wp.element.createElement( 'strong', null, __( 'Preset:', 'mvweb-price-table' ) + ' ' ),
											formsData.presets[ preset ] || preset
										),
									customTitle &&
										wp.element.createElement(
											'p',
											null,
											wp.element.createElement( 'strong', null, __( 'Title:', 'mvweb-price-table' ) + ' ' ),
											customTitle
										)
								),
								wp.element.createElement(
									'p',
									{ className: 'mvweb-pc-block-preview__note' },
									__(
										'The calculator will be rendered on the frontend.',
										'mvweb-price-table'
									)
								)
						  )
				)
			);
		},
	} );
} )( window.wp );
