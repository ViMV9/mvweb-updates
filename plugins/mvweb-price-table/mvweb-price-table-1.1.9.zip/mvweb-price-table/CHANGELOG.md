# Changelog

All notable changes to MVweb Price Calculator will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.1.9] - 2026-02-07

### Fixed

- Vendor assets (Choices.js, Chart.js) missing from release ZIP: `vendor/` in .gitignore was excluding `assets/vendor/` at all depths

## [1.1.8] - 2026-02-07

### Added

- Natural alphabetical/numerical sorting (natcasesort) for all select dropdowns
- "All" mode now loads next hierarchy level for user interaction when only level-1 is preset

### Fixed

- Choices.js dropdown appearing behind results table (z-index stacking context)
- CI/CD build excluding `assets/vendor/` directory (Choices.js, Chart.js) from ZIP archives

## [1.1.7] - 2026-02-07

### Fixed

- Fatal error when multiple MVweb plugins active: added class_exists() guard to MVweb_Updater

## [1.1.6] - 2026-02-07

### Fixed

- Menu not appearing on some servers due to OPcache serving stale bytecode without get_instance() call

## [1.1.5] - 2026-02-07

### Fixed

- Menu position collision with WooCommerce: changed from float to string `'99.5'` to prevent PHP float-to-int array key casting

## [1.1.4] - 2026-02-07

### Changed

- MVweb Menu refactored to v2.0.0: dynamic plugin registration via `mvweb_registered_plugins` filter
- Plugin descriptions on hub page now properly translated via `all_plugins` filter

### Added

- Russian translations for MVweb Menu shared strings (hub page UI)
- Self-registration with MVweb Menu hub page via `add_filter`

## [1.1.3] - 2026-02-05

### Added

- Automatic update system via public JSON metadata server (plugin-update-checker v5.6)
- Bundled update checker library for standalone distribution

## [1.1.2] - 2026-02-05

### Added

- Universal `level-N` shortcode attributes for automatic level filtering (e.g., `level-1="Apple"` instead of specific column names)

## [1.1.1] - 2026-02-05

### Fixed

- Service columns in the results table now sorted by index to match the order in Google Sheets. Previously, columns with custom field mapping could appear in wrong order.

## [1.0.0] - 2026-02-05

### Added

- Initial release
- Google Sheets integration for dynamic pricing
- Cascading selects with dynamic hierarchy support (up to 5 levels)
- Multiple calculator forms support
- Admin panel with tabs: Forms, Settings, Statistics, Help
- CRUD operations for forms via AJAX
- **Field Mapping system** for flexible column configuration:
  - Auto-detect columns from spreadsheet headers
  - Quick presets: Repair Services, Product Catalog, General Services
  - Support for hierarchy, price, and display columns
  - Priority-based price resolution with `{pattern}` syntax
  - Wildcard model matching
- **15 design presets** with modern styling:
  - Dark themes: Aurora Borealis, Carbon Fiber, Lavender Haze
  - Light themes (neutral): Light (Default), Classic Blue, Editorial, Soft Cloud, Elegant Serif, Swiss Minimal, Paper Craft, MVweb Brand
  - Light themes (colorful): Forest Green, Ocean Blue, Sky Cyan, Teal Mint, Emerald Gradient
- Glassmorphism, gradients, and animated effects in select presets
- Support for Google Fonts in custom presets
- CSS custom properties for easy customization
- Gutenberg block with live preview
- WordPress Widget support
- PHP function `mvweb_price_calculator()` for theme developers
- Smart caching with WordPress Transients API
- Fallback cache for offline support
- Background cache refresh via WP-Cron
- Usage statistics with Chart.js graphs
- CSV export for statistics
- Auto-cleanup of statistics older than 90 days
- Choices.js integration for searchable selects
- Model grouping syntax (comma, brackets, wildcard)
- Mobile-first responsive design
- Touch targets minimum 44px
- Horizontal table scroll on mobile
- Skeleton loader animations
- Smooth scroll to results
- Respect `prefers-reduced-motion`
- Full localization support (EN + RU)
- Nonce protection for all AJAX requests
- Capability checks for admin actions
- Input sanitization and output escaping
- Prepared statements for database queries
- Direct file access protection
- Uninstall hook with data cleanup option
- GitHub Updater integration
