<?php
/**
 * Shortcode class for MVweb Price Table.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PT_Shortcode
 *
 * Handles the [mvweb_price_calculator] shortcode.
 *
 * @since 1.0.0
 */
class MVweb_PT_Shortcode {

	/**
	 * Primary shortcode tag.
	 *
	 * @var string
	 */
	const TAG = 'mvweb_price_table';

	/**
	 * Legacy shortcode tag (for backward compatibility).
	 *
	 * @var string
	 */
	const TAG_LEGACY = 'mvweb_price_calculator';

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		add_shortcode( self::TAG, array( $this, 'render' ) );
		add_shortcode( self::TAG_LEGACY, array( $this, 'render' ) );
	}

	/**
	 * Render shortcode.
	 *
	 * @since 1.0.0
	 * @param array  $atts    Shortcode attributes.
	 * @param string $content Shortcode content.
	 * @return string HTML output.
	 */
	public function render( $atts, $content = '' ) {
		// WordPress does NOT automatically convert hyphens to underscores.
		// We need to normalize attribute keys manually.
		if ( is_array( $atts ) ) {
			$normalized = array();
			foreach ( $atts as $key => $value ) {
				// Detect bare "all" attribute (WordPress passes as numeric key 0 => 'all').
				if ( is_int( $key ) && 'all' === $value ) {
					$normalized['all'] = 'true';
					continue;
				}
				// Convert level-1 to level_1, etc.
				$normalized_key              = str_replace( '-', '_', $key );
				$normalized[ $normalized_key ] = $value;
			}
			$atts = $normalized;
		}

		$atts = shortcode_atts(
			array(
				'id'          => 0,
				'level_1'     => '',
				'level_2'     => '',
				'level_3'     => '',
				'level_4'     => '',
				'level_5'     => '',
				'title'       => '',
				'description' => '',
				'button_text' => '',
				'preset'      => '',
				'class'       => '',
				'show_title'  => 'true',
				'all'         => 'false',
			),
			$atts,
			self::TAG
		);

		// Validate form ID.
		$form_id = absint( $atts['id'] );

		if ( ! $form_id ) {
			return $this->render_error( __( 'Form ID is required.', 'mvweb-price-table' ) );
		}

		// Get form.
		$form = mvweb_pt_get_form( $form_id );

		if ( ! $form ) {
			return $this->render_error( __( 'Form not found.', 'mvweb-price-table' ) );
		}

		if ( 'active' !== $form['status'] ) {
			// Don't show anything for inactive forms on frontend.
			if ( ! current_user_can( 'manage_options' ) ) {
				return '';
			}
			return $this->render_error( __( 'This form is inactive.', 'mvweb-price-table' ) );
		}

		// Build args from shortcode attributes.
		$args = array(
			'show_title' => 'true' === $atts['show_title'] || '1' === $atts['show_title'],
			'class'      => sanitize_html_class( $atts['class'] ),
			'echo'       => false,
		);

		// Override form settings with shortcode attributes.
		if ( ! empty( $atts['preset'] ) ) {
			$args['preset'] = sanitize_key( $atts['preset'] );
		}

		if ( ! empty( $atts['title'] ) ) {
			$args['title'] = sanitize_text_field( $atts['title'] );
		}

		if ( ! empty( $atts['description'] ) ) {
			$args['description'] = sanitize_text_field( $atts['description'] );
		}

		if ( ! empty( $atts['button_text'] ) ) {
			$args['button_text'] = sanitize_text_field( $atts['button_text'] );
		}

		// Pre-selected values for hierarchy levels (level-1 to level-5).
		// WordPress converts level-1 to level_1 in shortcode attributes.
		for ( $level = 1; $level <= 5; $level++ ) {
			$attr_key = 'level_' . $level;
			if ( ! empty( $atts[ $attr_key ] ) ) {
				$args[ 'default_level_' . $level ] = $atts[ $attr_key ];
			}
		}

		// "all" mode: show all prices for the specified hierarchy branch.
		if ( 'true' === $atts['all'] || '1' === $atts['all'] ) {
			$args['show_all'] = true;
		}

		// Render calculator.
		return mvweb_price_calculator( $form_id, $args );
	}

	/**
	 * Render error message (only for admins).
	 *
	 * @since 1.0.0
	 * @param string $message Error message.
	 * @return string HTML output.
	 */
	private function render_error( $message ) {
		// Only show errors to admins.
		if ( ! current_user_can( 'manage_options' ) ) {
			return '';
		}

		return sprintf(
			'<div class="mvweb-pc-error" style="background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 12px 20px; border-radius: 4px; margin: 10px 0;">
				<strong>%s</strong> %s
			</div>',
			esc_html__( 'MVweb Price Table:', 'mvweb-price-table' ),
			esc_html( $message )
		);
	}

	/**
	 * Get shortcode usage examples.
	 *
	 * @since 1.0.0
	 * @return array Array of examples.
	 */
	public static function get_examples() {
		return array(
			array(
				'code'        => '[mvweb_price_table id="1"]',
				'description' => __( 'Basic usage with form ID.', 'mvweb-price-table' ),
			),
			array(
				'code'        => '[mvweb_price_table id="1" preset="dark"]',
				'description' => __( 'With dark theme preset.', 'mvweb-price-table' ),
			),
			array(
				'code'        => '[mvweb_price_table id="1" level-1="Apple" level-2="iPhone"]',
				'description' => __( 'With pre-selected hierarchy levels.', 'mvweb-price-table' ),
			),
			array(
				'code'        => '[mvweb_price_table id="1" title="Service Prices" button_text="Get Price"]',
				'description' => __( 'With custom title and button text.', 'mvweb-price-table' ),
			),
			array(
				'code'        => '[mvweb_price_table id="1" show_title="false" class="my-custom-class"]',
				'description' => __( 'Without title and with custom CSS class.', 'mvweb-price-table' ),
			),
			array(
				'code'        => '[mvweb_price_table id="1" level-1="Apple" all]',
				'description' => __( 'Show all prices for a specific brand.', 'mvweb-price-table' ),
			),
			array(
				'code'        => '[mvweb_price_table id="1" level-1="Apple" level-2="iPhone" all]',
				'description' => __( 'Show all prices for a specific category.', 'mvweb-price-table' ),
			),
		);
	}
}

// Initialize shortcode.
new MVweb_PT_Shortcode();
