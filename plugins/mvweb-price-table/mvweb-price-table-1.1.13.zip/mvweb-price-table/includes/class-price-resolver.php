<?php
/**
 * Price Resolver for MVweb Price Table.
 *
 * Handles price resolution with priority system:
 * 1. Exact match (highest priority)
 * 2. Wildcard pattern match
 * 3. General list match (lowest priority)
 *
 * @package MVweb_Price_Table
 * @since   2.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PT_Price_Resolver
 *
 * Resolves service prices using priority-based source matching.
 *
 * @since 2.1.0
 */
class MVweb_PT_Price_Resolver {

	/**
	 * Source types priority constants (lower = higher priority).
	 */
	const PRIORITY_EXACT    = 1;
	const PRIORITY_WILDCARD = 2;
	const PRIORITY_GENERAL  = 3;

	/**
	 * Debug mode (show source info).
	 *
	 * @var bool
	 */
	private $debug_mode = false;

	/**
	 * Price column index in raw_cells.
	 *
	 * @var int
	 */
	private $price_column_index = 6;

	/**
	 * Constructor.
	 *
	 * @since 2.1.0
	 * @param bool $debug_mode         Enable debug info in results.
	 * @param int  $price_column_index Index of price column in raw_cells (default 6).
	 */
	public function __construct( $debug_mode = false, $price_column_index = 6 ) {
		$this->debug_mode         = $debug_mode && current_user_can( 'manage_options' );
		$this->price_column_index = $price_column_index;
	}

	/**
	 * Categorize model sources by type (exact, wildcard, general).
	 *
	 * @since 2.1.0
	 * @param array  $models     Models array from parsed data.
	 * @param string $model_name Model display name to match.
	 * @return array {
	 *     @type array $exact    Exact match sources.
	 *     @type array $wildcard Wildcard pattern sources (sorted by specificity DESC).
	 *     @type array $general  General list sources.
	 * }
	 */
	public function categorize_sources( $models, $model_name ) {
		$exact    = array();
		$wildcard = array();
		$general  = array();

		$model_norm       = self::normalize_model( $model_name );
		$model_key_target = sanitize_title( $model_name );

		foreach ( $models as $model_key => $model_data ) {
			$stored_name = $model_data['name'] ?? '';
			$is_pattern  = ! empty( $model_data['pattern'] );

			// Case 1: Wildcard pattern - check if it matches our model.
			if ( $is_pattern ) {
				$pattern_text = $model_data['pattern_text'] ?? $stored_name . '*';

				// Check if pattern matches our model.
				if ( self::pattern_matches( $pattern_text, $model_name ) ) {
					$wildcard[] = array(
						'key'         => $model_key,
						'data'        => $model_data,
						'pattern'     => $pattern_text,
						'specificity' => self::pattern_specificity( $pattern_text ),
						'priority'    => self::PRIORITY_WILDCARD,
					);
				}
				continue;
			}

			// Case 2: Non-pattern model - check if key matches requested model.
			if ( $model_key !== $model_key_target ) {
				continue;
			}

			// Determine source type by comparing normalized names (per spec 6.4).
			// If stored name exactly matches requested model name = exact match.
			// Otherwise (model was part of comma-separated list) = general match.
			$stored_norm    = self::normalize_model( $stored_name );
			$is_exact_match = ( $stored_norm === $model_norm );

			if ( $is_exact_match ) {
				$exact[] = array(
					'key'      => $model_key,
					'data'     => $model_data,
					'priority' => self::PRIORITY_EXACT,
				);
			} else {
				$general[] = array(
					'key'      => $model_key,
					'data'     => $model_data,
					'priority' => self::PRIORITY_GENERAL,
				);
			}
		}

		// Sort wildcard sources by specificity (DESC - more specific first).
		usort(
			$wildcard,
			function ( $a, $b ) {
				return $b['specificity'] - $a['specificity'];
			}
		);

		return array(
			'exact'    => $exact,
			'wildcard' => $wildcard,
			'general'  => $general,
		);
	}

	/**
	 * Resolve services with prices using priority system.
	 *
	 * Algorithm:
	 * 1. Collect all services from all sources.
	 * 2. For each service, use price from highest priority source that has it.
	 * 3. Add unique services from wildcard sources.
	 *
	 * @since 2.1.0
	 * @param array  $sources    Categorized sources from categorize_sources().
	 * @param string $model_name Model name for debug info.
	 * @return array Merged services with resolved prices.
	 */
	public function resolve_services( $sources, $model_name ) {
		// Service index: service_name => {data, priority, source, order}.
		$service_index = array();
		$order_counter = 0;

		// Step 1: Build base service list (defines order).
		// Priority for ORDER: Exact > General > Wildcard.
		// First from Exact sources.
		foreach ( $sources['exact'] as $source ) {
			$services = $source['data']['services'] ?? array();
			foreach ( $services as $service ) {
				$service_key = $this->get_service_key( $service );

				if ( ! isset( $service_index[ $service_key ] ) ) {
					$service_index[ $service_key ] = array(
						'data'     => $service,
						'priority' => self::PRIORITY_EXACT,
						'source'   => 'exact:' . $source['key'],
						'order'    => $order_counter++,
					);
				}
			}
		}

		// Then from General sources.
		foreach ( $sources['general'] as $source ) {
			$services = $source['data']['services'] ?? array();
			foreach ( $services as $service ) {
				$service_key = $this->get_service_key( $service );

				if ( ! isset( $service_index[ $service_key ] ) ) {
					$service_index[ $service_key ] = array(
						'data'     => $service,
						'priority' => self::PRIORITY_GENERAL,
						'source'   => 'general:' . $source['key'],
						'order'    => $order_counter++,
					);
				}
			}
		}

		// Step 2: Apply Wildcard prices (fills gaps where no price exists).
		// Sorted by specificity DESC, process in reverse (less specific first).
		$wildcards_reversed = array_reverse( $sources['wildcard'] );

		foreach ( $wildcards_reversed as $source ) {
			$services = $source['data']['services'] ?? array();
			foreach ( $services as $service ) {
				$service_key = $this->get_service_key( $service );

				if ( isset( $service_index[ $service_key ] ) ) {
					// Service exists - update price only if current has no valid price.
					$current_has_price = $this->has_valid_price( $service_index[ $service_key ]['data'] );

					if ( ! $current_has_price && $this->has_valid_price( $service ) ) {
						$service_index[ $service_key ]['data']['raw_cells'] = $service['raw_cells'] ?? array();
						$service_index[ $service_key ]['priority']          = self::PRIORITY_WILDCARD;
						$service_index[ $service_key ]['source']            = 'wildcard:' . $source['pattern'];
					}
				} else {
					// Add new service from wildcard (at the end).
					$service_index[ $service_key ] = array(
						'data'     => $service,
						'priority' => self::PRIORITY_WILDCARD,
						'source'   => 'wildcard:' . $source['pattern'],
						'order'    => $order_counter++,
					);
				}
			}
		}

		// Step 3: Apply Exact prices (highest priority - overwrites wildcard).
		foreach ( $sources['exact'] as $source ) {
			$services = $source['data']['services'] ?? array();
			foreach ( $services as $service ) {
				$service_key = $this->get_service_key( $service );

				if ( isset( $service_index[ $service_key ] ) && $this->has_valid_price( $service ) ) {
					$service_index[ $service_key ]['data']['raw_cells'] = $service['raw_cells'] ?? array();
					$service_index[ $service_key ]['priority']          = self::PRIORITY_EXACT;
					$service_index[ $service_key ]['source']            = 'exact:' . $source['key'];
				}
			}
		}

		// Step 4: Apply General prices (lowest priority).
		foreach ( $sources['general'] as $source ) {
			$services = $source['data']['services'] ?? array();
			foreach ( $services as $service ) {
				$service_key = $this->get_service_key( $service );

				if ( isset( $service_index[ $service_key ] ) ) {
					$current_has_price = $this->has_valid_price( $service_index[ $service_key ]['data'] );

					if ( ! $current_has_price && $this->has_valid_price( $service ) ) {
						$service_index[ $service_key ]['data']['raw_cells'] = $service['raw_cells'] ?? array();
						$service_index[ $service_key ]['priority']          = self::PRIORITY_GENERAL;
						$service_index[ $service_key ]['source']            = 'general:' . $source['key'];
					}
				}
			}
		}

		// Sort by original order.
		uasort(
			$service_index,
			function ( $a, $b ) {
				return $a['order'] - $b['order'];
			}
		);

		// Build result array.
		$result = array();
		foreach ( $service_index as $key => $entry ) {
			$service = $entry['data'];

			// Add debug info if enabled.
			if ( $this->debug_mode ) {
				$service['_debug'] = array(
					'priority' => $entry['priority'],
					'source'   => $entry['source'],
					'order'    => $entry['order'],
				);
			}

			$result[] = $service;
		}

		return $result;
	}

	/**
	 * Get unique key for a service.
	 *
	 * @since 2.1.0
	 * @param array $service Service data.
	 * @return string Service key.
	 */
	private function get_service_key( $service ) {
		$name = $service['name'] ?? '';
		return self::normalize_model( $name );
	}

	/**
	 * Check if service has a valid (non-empty) price.
	 *
	 * Checks raw_cells for price column. The price_column_index can be set
	 * via constructor, defaults to 6 (standard layout).
	 *
	 * @since 2.1.0
	 * @param array $service Service data.
	 * @return bool True if price is valid.
	 */
	private function has_valid_price( $service ) {
		// Check raw_cells at price column index.
		$raw_cells = $service['raw_cells'] ?? array();
		$price     = $raw_cells[ $this->price_column_index ] ?? '';

		// Empty string is not valid.
		if ( '' === $price || null === $price ) {
			return false;
		}

		// "0" or 0 is valid (free service).
		if ( '0' === $price || 0 === $price || 0.0 === $price ) {
			return true;
		}

		// Non-empty string is valid (e.g., "По запросу", "1000-2000").
		return ! empty( $price );
	}

	/**
	 * Normalize model name for comparison.
	 *
	 * @since 2.1.0
	 * @param string $name Model name.
	 * @return string Normalized name.
	 */
	public static function normalize_model( $name ) {
		// 1. Trim whitespace.
		$normalized = trim( $name );

		// 2. Convert to lowercase (UTF-8 aware).
		$normalized = mb_strtolower( $normalized, 'UTF-8' );

		// 3. Normalize Unicode (NFC) if available.
		if ( function_exists( 'normalizer_normalize' ) ) {
			$normalized = normalizer_normalize( $normalized, Normalizer::FORM_C );
		}

		// 4. Replace multiple spaces with single space.
		$normalized = preg_replace( '/\s+/u', ' ', $normalized );

		// 5. Normalize similar characters (Russian/English lookalikes).
		// Using explicit UTF-8 codes to avoid encoding issues.
		$replacements = array(
			// Russian to English lookalikes (Cyrillic letters that look like Latin).
			"\xD0\xB0" => 'a', // а (Cyrillic)
			"\xD0\xB5" => 'e', // е (Cyrillic)
			"\xD0\xBE" => 'o', // о (Cyrillic)
			"\xD1\x80" => 'p', // р (Cyrillic)
			"\xD1\x81" => 'c', // с (Cyrillic)
			"\xD1\x83" => 'y', // у (Cyrillic)
			"\xD1\x85" => 'x', // х (Cyrillic)
			// Special dashes.
			"\xE2\x80\x93" => '-', // en-dash
			"\xE2\x80\x94" => '-', // em-dash
			"\xE2\x88\x92" => '-', // minus sign
			// Special quotes.
			"\xE2\x80\x98" => "'", // left single quote
			"\xE2\x80\x99" => "'", // right single quote
			"\xE2\x80\x9C" => '"', // left double quote
			"\xE2\x80\x9D" => '"', // right double quote
		);
		$normalized = strtr( $normalized, $replacements );

		// 6. Remove special characters except alphanumeric, spaces, dashes.
		$normalized = preg_replace( '/[^\p{L}\p{N}\s\-]/u', '', $normalized );

		return $normalized;
	}

	/**
	 * Check if pattern matches model name.
	 *
	 * Pattern is a prefix match:
	 * - "iPhone 17" matches "iPhone 17", "iPhone 17 Pro", "iPhone 17 Pro Max"
	 *
	 * @since 2.1.0
	 * @param string $pattern    Pattern text (prefix to match).
	 * @param string $model_name Model name.
	 * @return bool True if model starts with pattern.
	 */
	public static function pattern_matches( $pattern, $model_name ) {
		// Normalize both for comparison.
		$pattern_norm = self::normalize_model( $pattern );
		$model_norm   = self::normalize_model( $model_name );

		// Prefix match: model must start with pattern.
		return strpos( $model_norm, $pattern_norm ) === 0;
	}

	/**
	 * Calculate pattern specificity (higher = more specific).
	 *
	 * "{iPhone 17 Pro}" (12 chars) > "{iPhone 17}" (9 chars) > "{iPhone}" (6 chars)
	 *
	 * @since 2.1.0
	 * @param string $pattern Pattern string (without braces).
	 * @return int Specificity score.
	 */
	public static function pattern_specificity( $pattern ) {
		$pattern_norm = self::normalize_model( $pattern );

		// Count meaningful characters (letters and digits).
		$chars = preg_replace( '/[^\p{L}\p{N}]/u', '', $pattern_norm );

		return mb_strlen( $chars, 'UTF-8' );
	}

	/**
	 * Check if models_match (case-insensitive, normalized).
	 *
	 * @since 2.1.0
	 * @param string $model_a First model name.
	 * @param string $model_b Second model name.
	 * @return bool True if models match.
	 */
	public static function models_match( $model_a, $model_b ) {
		$norm_a = self::normalize_model( $model_a );
		$norm_b = self::normalize_model( $model_b );

		return $norm_a === $norm_b;
	}
}
