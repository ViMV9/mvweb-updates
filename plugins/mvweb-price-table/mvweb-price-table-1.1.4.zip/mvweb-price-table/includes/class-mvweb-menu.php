<?php
/**
 * MVweb Plugins Menu Registration
 *
 * Handles the registration of the main MVweb Plugins menu
 * that all MVweb plugins use as their parent menu.
 *
 * This file should be included in each MVweb plugin's includes/ folder.
 * The version check ensures only the newest version is loaded.
 *
 * @package MVweb\Shared
 * @since   1.0.0
 * @version 2.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Version of this file - increment when making changes.
if ( ! defined( 'MVWEB_MENU_VERSION' ) ) {
	define( 'MVWEB_MENU_VERSION', '2.0.0' );
}

// Skip if a newer version is already loaded.
if ( class_exists( 'MVweb_Menu' ) ) {
	return;
}

/**
 * Class MVweb_Menu
 *
 * Handles the main MVweb Plugins menu registration.
 *
 * @since 1.0.0
 */
class MVweb_Menu {

	/**
	 * Menu slug for new format plugins.
	 *
	 * Using a unique slug to avoid conflicts with old plugins.
	 *
	 * @var string
	 */
	const MENU_SLUG = 'mvweb-hub';

	/**
	 * Menu capability.
	 *
	 * @var string
	 */
	const CAPABILITY = 'manage_options';

	/**
	 * Menu position.
	 *
	 * Using a unique float position to avoid conflicts.
	 *
	 * @var float
	 */
	const POSITION = 58.5;

	/**
	 * Instance of this class.
	 *
	 * @var MVweb_Menu
	 */
	private static $instance = null;

	/**
	 * Textdomain of the first plugin that loaded this class.
	 *
	 * @var string
	 */
	private $textdomain = 'mvweb';

	/**
	 * Flag to track if menu was registered by this class.
	 *
	 * @var bool
	 */
	private static $menu_registered = false;

	/**
	 * Cache of registered plugins collected via filter.
	 *
	 * @since 2.0.0
	 * @var array|null
	 */
	private $registered_plugins = null;

	/**
	 * Get singleton instance.
	 *
	 * @since 1.0.0
	 * @return MVweb_Menu
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	private function __construct() {
		// Determine textdomain from the first loaded MVweb plugin.
		$this->textdomain = $this->detect_textdomain();

		// Register menu at priority 9 (standard recommended practice).
		add_action( 'admin_menu', array( $this, 'register_menu' ), 9 );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_styles' ) );
	}

	/**
	 * Detect textdomain from loaded MVweb plugins.
	 *
	 * @since 1.0.0
	 * @return string Textdomain.
	 */
	private function detect_textdomain() {
		// Check for known MVweb plugin constants.
		if ( defined( 'MVWEB_PT_VERSION' ) ) {
			return 'mvweb-price-table';
		}
		if ( defined( 'MVWEB_PU_VERSION' ) ) {
			return 'mvweb-pop-up';
		}

		return 'mvweb';
	}

	/**
	 * Get plugins registered via 'mvweb_registered_plugins' filter.
	 *
	 * Each plugin registers itself with add_filter in its entry point.
	 * Results are cached after the first call.
	 *
	 * @since 2.0.0
	 * @return array Associative array keyed by plugin slug.
	 */
	private function get_registered_plugins() {
		if ( null === $this->registered_plugins ) {
			$plugins = apply_filters( 'mvweb_registered_plugins', array() );

			// Ensure indexed by slug.
			$indexed = array();
			foreach ( $plugins as $key => $plugin ) {
				if ( is_string( $key ) && ! empty( $plugin['name'] ) ) {
					$indexed[ $key ] = $plugin;
				}
			}

			$this->registered_plugins = $indexed;
		}

		return $this->registered_plugins;
	}

	/**
	 * Register the main MVweb Plugins menu.
	 *
	 * Uses unique slug 'mvweb-hub' to avoid conflicts with old plugins
	 * that may use 'mvweb-plugins' slug.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function register_menu() {
		// Only register once.
		if ( self::$menu_registered ) {
			return;
		}

		// Check if menu already registered by another instance.
		if ( ! empty( $GLOBALS['admin_page_hooks'][ self::MENU_SLUG ] ) ) {
			self::$menu_registered = true;
			return;
		}

		// Register top-level menu.
		add_menu_page(
			__( 'MVweb Plugins', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			__( 'MVweb', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			self::CAPABILITY,
			self::MENU_SLUG,
			array( $this, 'render_about_page' ),
			$this->get_menu_icon(),
			self::POSITION
		);

		// Add main submenu (replaces default submenu).
		add_submenu_page(
			self::MENU_SLUG,
			__( 'MVweb Plugins', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			__( 'All Plugins', $this->textdomain ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
			self::CAPABILITY,
			self::MENU_SLUG,
			array( $this, 'render_about_page' )
		);

		self::$menu_registered = true;
	}

	/**
	 * Get menu icon.
	 *
	 * @since 1.0.0
	 * @return string Base64 encoded SVG icon or dashicon.
	 */
	private function get_menu_icon() {
		return 'dashicons-admin-generic';
	}

	/**
	 * Render the About MVweb page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function render_about_page() {
		$installed_plugins  = $this->get_mvweb_plugins();
		$registered_plugins = $this->get_registered_plugins();
		$td                 = $this->textdomain;
		?>
		<div class="wrap mvweb-about-page">
			<h1><?php esc_html_e( 'MVweb Plugins', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></h1>

			<div class="mvweb-about-header">
				<div class="mvweb-about-logo">
					<span class="mvweb-logo-text">MVweb</span>
				</div>
				<div class="mvweb-about-description">
					<p>
						<?php esc_html_e( 'MVweb is a web development studio specializing in WordPress plugins and themes. We create high-quality, secure, and well-documented solutions for WordPress.', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
					</p>
					<p>
						<a href="https://mvweb.ru" target="_blank" rel="noopener noreferrer" class="button button-primary">
							<?php esc_html_e( 'Visit our website', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?> &rarr;
						</a>
					</p>
				</div>
			</div>

			<h2><?php esc_html_e( 'Installed Plugins', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></h2>

			<?php if ( ! empty( $installed_plugins ) ) : ?>
				<div class="mvweb-plugins-grid">
					<?php foreach ( $installed_plugins as $plugin_file => $plugin ) : ?>
						<?php
						$is_active    = is_plugin_active( $plugin_file );
						$plugin_slug  = dirname( $plugin_file );
						$plugin_info  = isset( $registered_plugins[ $plugin_slug ] ) ? $registered_plugins[ $plugin_slug ] : array();
						$settings_url = ! empty( $plugin_info['settings_url'] )
							? admin_url( $plugin_info['settings_url'] )
							: null;
						?>
						<div class="mvweb-plugin-card <?php echo $is_active ? 'mvweb-plugin-card--active' : 'mvweb-plugin-card--inactive'; ?>">
							<div class="mvweb-plugin-card__header">
								<h3 class="mvweb-plugin-card__title"><?php echo esc_html( $plugin['Name'] ); ?></h3>
								<span class="mvweb-plugin-card__status <?php echo $is_active ? 'mvweb-plugin-card__status--active' : 'mvweb-plugin-card__status--inactive'; ?>">
									<?php echo $is_active ? esc_html__( 'Active', $td ) : esc_html__( 'Inactive', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
								</span>
							</div>
							<p class="mvweb-plugin-card__version">
								<?php
								printf(
									/* translators: %s: plugin version */
									esc_html__( 'Version %s', $td ), // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain
									esc_html( $plugin['Version'] )
								);
								?>
							</p>
							<p class="mvweb-plugin-card__description">
								<?php echo esc_html( $plugin['Description'] ); ?>
							</p>
							<div class="mvweb-plugin-card__actions">
								<?php if ( $is_active && $settings_url ) : ?>
									<a href="<?php echo esc_url( $settings_url ); ?>" class="button button-primary">
										<?php esc_html_e( 'Settings', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								<?php elseif ( ! $is_active ) : ?>
									<a href="<?php echo esc_url( wp_nonce_url( admin_url( 'plugins.php?action=activate&plugin=' . urlencode( $plugin_file ) ), 'activate-plugin_' . $plugin_file ) ); ?>" class="button button-primary">
										<?php esc_html_e( 'Activate', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								<?php endif; ?>
								<?php if ( ! empty( $plugin['PluginURI'] ) ) : ?>
									<a href="<?php echo esc_url( $plugin['PluginURI'] ); ?>" target="_blank" rel="noopener noreferrer" class="button">
										<?php esc_html_e( 'Learn More', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								<?php endif; ?>
							</div>
						</div>
					<?php endforeach; ?>
				</div>
			<?php else : ?>
				<p class="mvweb-no-plugins"><?php esc_html_e( 'No MVweb plugins installed yet.', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></p>
			<?php endif; ?>

			<?php
			// Show available plugins from catalog that are not installed.
			$installed_slugs = array();
			foreach ( array_keys( $installed_plugins ) as $pfile ) {
				$installed_slugs[] = dirname( $pfile );
			}
			$not_installed = array_diff_key( $registered_plugins, array_flip( $installed_slugs ) );

			if ( ! empty( $not_installed ) ) :
				?>
				<h2><?php esc_html_e( 'Available Plugins', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?></h2>
				<div class="mvweb-plugins-grid">
					<?php foreach ( $not_installed as $slug => $plugin_info ) : ?>
						<div class="mvweb-plugin-card mvweb-plugin-card--available">
							<div class="mvweb-plugin-card__header">
								<h3 class="mvweb-plugin-card__title"><?php echo esc_html( $plugin_info['name'] ); ?></h3>
								<span class="mvweb-plugin-card__status mvweb-plugin-card__status--available">
									<?php esc_html_e( 'Not Installed', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
								</span>
							</div>
							<p class="mvweb-plugin-card__description">
								<?php echo esc_html( $plugin_info['description'] ); ?>
							</p>
							<?php if ( ! empty( $plugin_info['url'] ) ) : ?>
								<div class="mvweb-plugin-card__actions">
									<a href="<?php echo esc_url( $plugin_info['url'] ); ?>" target="_blank" rel="noopener noreferrer" class="button">
										<?php esc_html_e( 'Learn More', $td ); // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralDomain ?>
									</a>
								</div>
							<?php endif; ?>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Get list of installed MVweb plugins.
	 *
	 * Only returns plugins registered via 'mvweb_registered_plugins' filter.
	 *
	 * @since 1.0.0
	 * @return array List of MVweb plugins.
	 */
	private function get_mvweb_plugins() {
		if ( ! function_exists( 'get_plugins' ) ) {
			require_once ABSPATH . 'wp-admin/includes/plugin.php';
		}

		$all_plugins   = get_plugins();
		$mvweb_plugins = array();
		$allowed_slugs = array_keys( $this->get_registered_plugins() );

		foreach ( $all_plugins as $plugin_file => $plugin_data ) {
			$plugin_slug = dirname( $plugin_file );

			if ( in_array( $plugin_slug, $allowed_slugs, true ) ) {
				$mvweb_plugins[ $plugin_file ] = $plugin_data;
			}
		}

		/**
		 * Apply the same 'all_plugins' filter that WordPress uses.
		 * This allows each plugin to translate its Name and Description
		 * via the filter registered in its entry point.
		 */
		$mvweb_plugins = apply_filters( 'all_plugins', $mvweb_plugins );

		return $mvweb_plugins;
	}

	/**
	 * Enqueue admin styles for MVweb pages.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public function enqueue_styles( $hook ) {
		// Only load on MVweb main page.
		if ( 'toplevel_page_' . self::MENU_SLUG !== $hook ) {
			return;
		}

		wp_add_inline_style( 'common', $this->get_inline_styles() );
	}

	/**
	 * Get inline CSS styles.
	 *
	 * @since 1.0.0
	 * @return string CSS styles.
	 */
	private function get_inline_styles() {
		return '
			:root {
				--mvweb-primary: #793ea4;
				--mvweb-primary-dark: #5e2d80;
				--mvweb-success: #46b450;
				--mvweb-warning: #ffb900;
				--mvweb-muted: #72777c;
			}

			.mvweb-about-page {
				max-width: 1200px;
			}

			.mvweb-about-header {
				display: flex;
				gap: 30px;
				align-items: flex-start;
				margin-bottom: 40px;
				padding: 30px;
				background: #fff;
				border: 1px solid #ccd0d4;
				border-radius: 4px;
			}

			.mvweb-about-logo {
				flex-shrink: 0;
			}

			.mvweb-logo-text {
				font-size: 48px;
				font-weight: bold;
				color: var(--mvweb-primary);
			}

			.mvweb-about-description {
				flex-grow: 1;
			}

			.mvweb-about-description p {
				font-size: 14px;
				line-height: 1.6;
				margin: 0 0 15px;
			}

			.mvweb-about-page .button-primary {
				background: var(--mvweb-primary);
				border-color: var(--mvweb-primary-dark);
			}

			.mvweb-about-page .button-primary:hover,
			.mvweb-about-page .button-primary:focus {
				background: var(--mvweb-primary-dark);
				border-color: var(--mvweb-primary-dark);
			}

			.mvweb-about-page h2 {
				margin: 30px 0 20px;
				padding-bottom: 10px;
				border-bottom: 1px solid #ccd0d4;
			}

			.mvweb-plugins-grid {
				display: grid;
				grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
				gap: 20px;
			}

			.mvweb-plugin-card {
				background: #fff;
				border: 1px solid #ccd0d4;
				border-radius: 4px;
				padding: 20px;
				display: flex;
				flex-direction: column;
			}

			.mvweb-plugin-card--active {
				border-left: 4px solid var(--mvweb-success);
			}

			.mvweb-plugin-card--inactive {
				border-left: 4px solid var(--mvweb-muted);
			}

			.mvweb-plugin-card--available {
				border-left: 4px solid var(--mvweb-warning);
				opacity: 0.85;
			}

			.mvweb-plugin-card__header {
				display: flex;
				justify-content: space-between;
				align-items: flex-start;
				gap: 10px;
				margin-bottom: 5px;
			}

			.mvweb-plugin-card__title {
				margin: 0;
				color: var(--mvweb-primary);
				font-size: 16px;
			}

			.mvweb-plugin-card__status {
				flex-shrink: 0;
				padding: 2px 8px;
				border-radius: 3px;
				font-size: 11px;
				font-weight: 500;
				text-transform: uppercase;
			}

			.mvweb-plugin-card__status--active {
				background: #d4edda;
				color: #155724;
			}

			.mvweb-plugin-card__status--inactive {
				background: #e2e3e5;
				color: #383d41;
			}

			.mvweb-plugin-card__status--available {
				background: #fff3cd;
				color: #856404;
			}

			.mvweb-plugin-card__version {
				color: var(--mvweb-muted);
				font-size: 12px;
				margin: 0 0 10px;
			}

			.mvweb-plugin-card__description {
				flex-grow: 1;
				margin: 0 0 15px;
				font-size: 13px;
				line-height: 1.5;
				color: #50575e;
			}

			.mvweb-plugin-card__actions {
				display: flex;
				gap: 10px;
				flex-wrap: wrap;
			}

			.mvweb-plugin-card__actions .button {
				flex-shrink: 0;
			}

			.mvweb-no-plugins {
				background: #f8f9fa;
				padding: 30px;
				text-align: center;
				color: var(--mvweb-muted);
				border-radius: 4px;
			}

			@media (max-width: 782px) {
				.mvweb-about-header {
					flex-direction: column;
					text-align: center;
				}

				.mvweb-plugins-grid {
					grid-template-columns: 1fr;
				}
			}
		';
	}

	/**
	 * Get menu slug.
	 *
	 * @since 1.0.0
	 * @return string Menu slug.
	 */
	public static function get_menu_slug() {
		return self::MENU_SLUG;
	}
}

// Initialize the menu immediately.
// For production, use mu-plugin mvweb-menu-init.php for guaranteed early initialization.
MVweb_Menu::get_instance();
