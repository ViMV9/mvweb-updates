# MVweb Price Calculator

Price calculator plugin with Google Sheets integration for repair services, e-commerce, and any business that needs dynamic pricing display.

## Description

MVweb Price Calculator allows you to create interactive price calculators that pull data directly from Google Sheets spreadsheets. Perfect for:

- Repair service centers (smartphones, computers, appliances)
- Auto service shops
- Medical and dental clinics
- Any business with cascading price selection

### Features

- **Google Sheets Integration**: Manage prices in familiar spreadsheet interface
- **Cascading Selects**: Brand → Type → Model → Services with prices
- **Multiple Forms**: Create unlimited calculator forms
- **Design Presets**: Light, Dark, Minimal, and MVweb Brand themes
- **Gutenberg Block**: Native block editor support
- **Widget Support**: Display in sidebars
- **Smart Caching**: Reduce Google API calls with configurable cache
- **Fallback Mode**: Show cached data when Google Sheets is unavailable
- **Usage Statistics**: Track popular brands and models
- **Fully Responsive**: Mobile-first design with touch-friendly interface
- **Searchable Selects**: Choices.js integration for better UX
- **Model Grouping**: Group similar models with same prices
- **Multilingual**: English and Russian translations included

## Requirements

- WordPress 6.4 or higher
- PHP 8.0 or higher

## Installation

1. Upload the `mvweb-price-calculator` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to **MVweb Plugins → Price Calculator** to configure

## Quick Start

### 1. Create a Google Sheets Spreadsheet

Create a new spreadsheet with the following columns:

| Column | Name    | Description                        | Example                    |
|--------|---------|------------------------------------|----------------------------|
| A      | Brand   | Device brand/manufacturer          | Apple, Samsung, Xiaomi     |
| B      | Type    | Device type or category            | iPhone, iPad, MacBook      |
| C      | Model   | Device model                       | iPhone 14 Pro, iPhone 14   |
| D      | Service | Service or repair name             | Screen Replacement         |
| E      | Price   | Price value                        | 15000 or "On request"      |

### 2. Make it Public

1. Click **File → Share → Share with others**
2. Change access to **Anyone with the link can view**
3. Copy the spreadsheet URL

### 3. Create a Form

1. Go to **MVweb Plugins → Price Calculator → Forms**
2. Click **Add New Form**
3. Enter a name and paste the Google Sheets URL
4. Click **Test Connection** to verify
5. Save the form

### 4. Display the Calculator

Use the shortcode on any page or post:

```
[mvweb_price_calculator id="1"]
```

## Shortcode Attributes

| Attribute    | Description                              | Example                        |
|--------------|------------------------------------------|--------------------------------|
| `id`         | Form ID (required)                       | `id="1"`                       |
| `preset`     | Design preset: light, dark, minimal, brand | `preset="dark"`              |
| `brand`      | Pre-select a brand                       | `brand="apple"`                |
| `type`       | Pre-select a type                        | `type="iphone"`                |
| `model`      | Pre-select a model                       | `model="iphone-14-pro"`        |
| `title`      | Custom form title                        | `title="Repair Prices"`        |
| `show_title` | Show or hide title                       | `show_title="false"`           |
| `class`      | Additional CSS class                     | `class="my-custom-class"`      |

### Examples

```
// Basic usage
[mvweb_price_calculator id="1"]

// Dark theme with pre-selected brand
[mvweb_price_calculator id="1" preset="dark" brand="apple"]

// Without title and custom CSS class
[mvweb_price_calculator id="1" show_title="false" class="compact-calculator"]
```

## PHP Function

For theme developers:

```php
<?php
// Basic usage
mvweb_price_calculator( 1 );

// With options
mvweb_price_calculator( 1, array(
    'show_title' => false,
    'preset'     => 'dark',
    'class'      => 'my-custom-class',
    'echo'       => true, // false to return HTML
) );
?>
```

## Model Grouping

Group multiple models with the same price using these formats:

| Format           | Example                        | Result                              |
|------------------|--------------------------------|-------------------------------------|
| Comma-separated  | `iPhone 14, iPhone 14 Plus`    | Two separate models                 |
| Brackets group   | `iPhone 14 [Pro/Pro Max]`      | Group shown as single option        |
| Wildcard         | `iPhone 14*`                   | Matches all models starting with... |

## Gutenberg Block

1. Open the page/post in the block editor
2. Click **+** to add a new block
3. Search for **Price Calculator** or find it in the MVweb category
4. Select the form and customize options in the sidebar

## Widget

1. Go to **Appearance → Widgets**
2. Add the **Price Calculator** widget to a sidebar
3. Select a form and customize options

## Hooks & Filters

The plugin provides hooks for customization:

```php
// Modify form settings before rendering
add_filter( 'mvweb_pc_form_settings', function( $settings, $form_id ) {
    // Customize settings
    return $settings;
}, 10, 2 );
```

## CSS Customization

The calculator uses BEM methodology with CSS custom properties:

```css
/* Override primary color */
.mvweb-pc {
    --mvweb-pc-primary: #your-color;
    --mvweb-pc-primary-hover: #your-hover-color;
}

/* Custom styling for a specific form */
.mvweb-pc[data-form-id="1"] {
    --mvweb-pc-border-radius: 0;
}
```

## Frequently Asked Questions

### Why is my spreadsheet not loading?

Make sure your spreadsheet is publicly accessible:
1. Go to **File → Share → Share with others**
2. Change to **Anyone with the link can view**
3. The spreadsheet must be viewable without sign-in

### How often is the data refreshed?

Data is cached according to your settings (default: 1 hour). You can:
- Clear the cache manually in **Settings** tab
- Change the cache duration
- Refresh automatically happens in background via WP-Cron

### Can I have multiple calculators on one page?

Yes, add multiple shortcodes with different form IDs. Each calculator works independently.

### What happens if Google Sheets is unavailable?

If fallback cache is enabled (default), the plugin shows the last successfully loaded data with a small notice.

### Is user data collected?

If statistics is enabled, anonymous usage data is collected (popular brands/models). IP addresses are hashed for privacy and never stored in plain text. Statistics can be disabled in Settings.

## Support

- Documentation: [mvweb.ru/plugins/mvweb-price-calculator](https://mvweb.ru/plugins/mvweb-price-calculator)
- Support: [mvweb.ru/support](https://mvweb.ru/support)

## License

This plugin is licensed under the GPL v2 or later.

## Changelog

See [CHANGELOG.md](CHANGELOG.md) for version history.
