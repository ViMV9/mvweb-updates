/**
 * Admin JavaScript for MVweb Price Table
 *
 * @package MVweb_Price_Calculator
 * @since   1.0.0
 */

(function($) {
	'use strict';

	var MVwebPcAdmin = {
		/**
		 * Current field mapping configuration.
		 */
		fieldMapping: null,

		/**
		 * Initialize admin functionality.
		 */
		init: function() {
			this.initTabs();
			this.initFormModal();
			this.initFormActions();
			this.initSettings();
			this.initAppearance();
			this.initCopyShortcode();
			this.initStatistics();
			this.initFieldMapping();
		},

		/**
		 * Tab navigation.
		 */
		initTabs: function() {
			var $tabs = $('.mvweb-pc-tabs .nav-tab');
			var $contents = $('.mvweb-pc-tab-content');

			$tabs.on('click', function(e) {
				e.preventDefault();

				var $this = $(this);
				var tabId = $this.data('tab');

				// Update active tab.
				$tabs.removeClass('nav-tab-active');
				$this.addClass('nav-tab-active');

				// Show corresponding content.
				$contents.removeClass('active');
				$('#' + tabId).addClass('active');

				// Update URL hash.
				if (history.pushState) {
					history.pushState(null, null, '#' + tabId);
				}
			});

			// Activate tab from URL hash.
			var hash = window.location.hash.substring(1);
			if (hash && $('#' + hash).length) {
				$tabs.filter('[data-tab="' + hash + '"]').trigger('click');
			}
		},

		/**
		 * Form modal functionality.
		 */
		initFormModal: function() {
			var dialog = document.getElementById('mvweb-pc-form-modal');
			var $form = $('#mvweb-pc-form-edit');
			var self = this;

			// Open modal for new form.
			$('.mvweb-pc-add-form').on('click', function() {
				self.openFormModal();
			});

			// Close on backdrop click (::backdrop).
			if (dialog) {
				dialog.addEventListener('click', function(e) {
					if (e.target === dialog) {
						dialog.close();
					}
				});
			}

			// Form submit.
			$form.on('submit', function(e) {
				e.preventDefault();
				self.saveForm();
			});

			// Test connection.
			$('.mvweb-pc-test-connection').on('click', function() {
				self.testConnection();
			});
		},

		/**
		 * Open form modal.
		 */
		openFormModal: function(formId) {
			var dialog = document.getElementById('mvweb-pc-form-modal');
			var $title = $(dialog).find('.mvweb-pc-modal-title');
			var self = this;

			// Reset form.
			$('#mvweb-pc-form-edit')[0].reset();
			$('#mvweb-pc-form-id').val('');
			$('#mvweb-pc-field-mapping').val('');
			$('.mvweb-pc-connection-status').text('').removeClass('loading success error');

			// Reset mapping UI.
			$('#mvweb-pc-mapping-rows').html('<tr class="mvweb-pc-mapping-placeholder"><td colspan="6">' + (mvweb_pt_ajax.i18n.no_columns || 'Click "Auto-Detect Columns" or add columns manually.') + '</td></tr>');
			$('.mvweb-pc-preview-section').hide();
			$('#mvweb-pc-inheritance-enabled').prop('checked', false);
			$('.mvweb-pc-inheritance-options').hide();
			self.fieldMapping = null;

			// Reset sheet selector.
			$('.mvweb-pc-sheet-row').hide();
			$('#mvweb-pc-form-sheet').html('<option value="">' + (mvweb_pt_ajax.i18n.first_sheet || 'First sheet (default)') + '</option>');
			$('#mvweb-pc-form-sheet-name').val('');

			if (formId && window.mvwebPcForms && window.mvwebPcForms[formId]) {
				// Edit mode.
				var form = window.mvwebPcForms[formId];
				$title.text(mvweb_pt_ajax.i18n.edit_form || 'Edit Form');
				$('#mvweb-pc-form-id').val(formId);
				$('#mvweb-pc-form-name').val(form.name);
				$('#mvweb-pc-form-url').val(form.spreadsheet_url);
				$('#mvweb-pc-form-preset').val(form.preset);
				$('#mvweb-pc-form-status').val(form.status);

				// Load sheet selection - always fetch if URL exists.
				if (form.spreadsheet_url) {
					// If sheet_id exists, pre-select it.
					var selectedGid = null;
					if (form.sheet_id !== null && form.sheet_id !== undefined && form.sheet_id !== '') {
						selectedGid = form.sheet_id;
						var sheetName = form.sheet_name || 'Sheet';
						$('#mvweb-pc-form-sheet').html(
							'<option value="">' + (mvweb_pt_ajax.i18n.first_sheet || 'First sheet (default)') + '</option>' +
							'<option value="' + form.sheet_id + '" selected>' + sheetName + '</option>'
						);
						$('#mvweb-pc-form-sheet-name').val(sheetName);
					}
					// Fetch sheets list and show selector.
					self.fetchSheets(form.spreadsheet_url, selectedGid);
				}

				// Load field mapping if exists.
				if (form.field_mapping) {
					self.fieldMapping = form.field_mapping;
					self.renderMappingTable(form.field_mapping, []);
					self.updateFieldMappingInput();
				}
			} else {
				// Add mode.
				$title.text(mvweb_pt_ajax.i18n.add_form || 'Add New Form');
			}

			dialog.showModal();
		},

		/**
		 * Close form modal.
		 */
		closeFormModal: function() {
			var dialog = document.getElementById('mvweb-pc-form-modal');
			if (dialog && dialog.open) {
				dialog.close();
			}
		},

		/**
		 * Save form.
		 */
		saveForm: function() {
			var self = this;
			var $form = $('#mvweb-pc-form-edit');
			var $submitBtn = $form.find('button[type="submit"]');

			// Update field mapping from UI before saving.
			self.updateMappingFromUI();

			var data = {
				action: 'mvweb_pt_save_form',
				nonce: mvweb_pt_ajax.nonce,
				form_id: $('#mvweb-pc-form-id').val(),
				name: $('#mvweb-pc-form-name').val(),
				spreadsheet_url: $('#mvweb-pc-form-url').val(),
				sheet_id: $('#mvweb-pc-form-sheet').val(),
				sheet_name: $('#mvweb-pc-form-sheet option:selected').text(),
				preset: $('#mvweb-pc-form-preset').val(),
				status: $('#mvweb-pc-form-status').val(),
				field_mapping: $('#mvweb-pc-field-mapping').val()
			};

			$submitBtn.prop('disabled', true);

			$.post(mvweb_pt_ajax.ajax_url, data, function(response) {
				if (response.success) {
					// Reload page to show updated forms list.
					window.location.reload();
				} else {
					alert(response.data.message || mvweb_pt_ajax.i18n.error);
				}
			}).fail(function() {
				alert(mvweb_pt_ajax.i18n.error);
			}).always(function() {
				$submitBtn.prop('disabled', false);
			});
		},

		/**
		 * Test Google Sheets connection.
		 */
		testConnection: function() {
			var $button = $('.mvweb-pc-test-connection');
			var $status = $('.mvweb-pc-connection-status');
			var url = $('#mvweb-pc-form-url').val();

			if (!url) {
				$status.text(mvweb_pt_ajax.i18n.url_required || mvweb_pt_ajax.i18n.error).removeClass('loading success').addClass('error');
				return;
			}

			$button.prop('disabled', true);
			$status.text(mvweb_pt_ajax.i18n.testing).removeClass('success error').addClass('loading');

			$.post(mvweb_pt_ajax.ajax_url, {
				action: 'mvweb_pt_test_connection',
				nonce: mvweb_pt_ajax.nonce,
				spreadsheet_url: url
			}, function(response) {
				if (response.success) {
					$status.text(response.data.message).removeClass('loading error').addClass('success');
				} else {
					$status.text(response.data.message || mvweb_pt_ajax.i18n.error).removeClass('loading success').addClass('error');
				}
			}).fail(function() {
				$status.text(mvweb_pt_ajax.i18n.error).removeClass('loading success').addClass('error');
			}).always(function() {
				$button.prop('disabled', false);
			});
		},

		/**
		 * Fetch sheets list from spreadsheet.
		 *
		 * @param {string} url - Spreadsheet URL.
		 * @param {string|null} selectedGid - Pre-select this gid if provided.
		 */
		fetchSheets: function(url, selectedGid) {
			var $select = $('#mvweb-pc-form-sheet');
			var $row = $('.mvweb-pc-sheet-row');
			var $status = $('.mvweb-pc-sheets-status');
			var $button = $('.mvweb-pc-refresh-sheets');

			if (!url) {
				$row.hide();
				return;
			}

			$button.prop('disabled', true);
			$status.text(mvweb_pt_ajax.i18n.loading || 'Loading...').removeClass('success error').addClass('loading');

			$.post(mvweb_pt_ajax.ajax_url, {
				action: 'mvweb_pt_fetch_sheets',
				nonce: mvweb_pt_ajax.nonce,
				spreadsheet_url: url
			}, function(response) {
				if (response.success && response.data.sheets) {
					var sheets = response.data.sheets;
					var options = '<option value="">' + (mvweb_pt_ajax.i18n.first_sheet || 'First sheet (default)') + '</option>';

					sheets.forEach(function(sheet) {
						var selected = (selectedGid !== null && selectedGid !== undefined && parseInt(selectedGid) === sheet.gid) ? ' selected' : '';
						options += '<option value="' + sheet.gid + '"' + selected + '>' + sheet.name + '</option>';
					});

					$select.html(options);
					$row.show();
					$status.text('').removeClass('loading error success');

					// Update hidden sheet name.
					$('#mvweb-pc-form-sheet-name').val($select.find('option:selected').text());
				} else {
					$status.text(response.data.message || mvweb_pt_ajax.i18n.error).removeClass('loading success').addClass('error');
					// Still show row with default option.
					$row.show();
				}
			}).fail(function() {
				$status.text(mvweb_pt_ajax.i18n.error).removeClass('loading success').addClass('error');
				$row.show();
			}).always(function() {
				$button.prop('disabled', false);
			});
		},

		/**
		 * Form actions (edit, delete).
		 */
		initFormActions: function() {
			var self = this;

			// Edit form.
			$(document).on('click', '.mvweb-pc-edit-form', function() {
				var formId = $(this).data('form-id');
				self.openFormModal(formId);
			});

			// Refresh sheets list.
			$(document).on('click', '.mvweb-pc-refresh-sheets', function() {
				var url = $('#mvweb-pc-form-url').val();
				self.fetchSheets(url, null);
			});

			// Update sheet name hidden field when selection changes.
			$(document).on('change', '#mvweb-pc-form-sheet', function() {
				$('#mvweb-pc-form-sheet-name').val($(this).find('option:selected').text());
			});

			// Fetch sheets when URL changes (on blur).
			var urlFetchTimeout;
			$(document).on('blur', '#mvweb-pc-form-url', function() {
				var url = $(this).val();
				clearTimeout(urlFetchTimeout);
				urlFetchTimeout = setTimeout(function() {
					if (url) {
						self.fetchSheets(url, null);
					}
				}, 300);
			});

			// Delete form.
			$(document).on('click', '.mvweb-pc-delete-form', function() {
				var $button = $(this);
				var formId = $button.data('form-id');

				if (!confirm(mvweb_pt_ajax.i18n.confirm_delete)) {
					return;
				}

				$button.prop('disabled', true);

				$.post(mvweb_pt_ajax.ajax_url, {
					action: 'mvweb_pt_delete_form',
					nonce: mvweb_pt_ajax.nonce,
					form_id: formId
				}, function(response) {
					if (response.success) {
						$button.closest('tr').fadeOut(300, function() {
							$(this).remove();

							// Show empty message if no forms left.
							if ($('.mvweb-pc-forms-table tbody tr').length === 0) {
								$('.mvweb-pc-forms-table').replaceWith(
									'<div class="mvweb-pc-no-forms"><p>' + (mvweb_pt_ajax.i18n.no_forms || 'No forms created yet. Click "Add New Form" to create your first calculator form.') + '</p></div>'
								);
							}
						});
					} else {
						alert(response.data.message || mvweb_pt_ajax.i18n.error);
						$button.prop('disabled', false);
					}
				}).fail(function() {
					alert(mvweb_pt_ajax.i18n.error);
					$button.prop('disabled', false);
				});
			});
		},

		/**
		 * Settings form (includes both Settings and Appearance tabs).
		 */
		initSettings: function() {
			var $form = $('#mvweb-pc-settings-form');
			var $status = $('.mvweb-pc-settings-status');

			if (!$form.length) {
				return;
			}

			// Toggle custom currency input visibility.
			$('#currency').on('change', function() {
				var $customWrapper = $('#custom-currency-wrapper');
				if ($(this).val() === 'CUSTOM') {
					$customWrapper.slideDown(200);
					$('#custom_currency').trigger('focus');
				} else {
					$customWrapper.slideUp(200);
				}
			});

			// Save settings (both tabs).
			$form.on('submit', function(e) {
				e.preventDefault();

				var $submitBtn = $form.find('button[type="submit"]');
				$submitBtn.prop('disabled', true);
				$status.text(mvweb_pt_ajax.i18n.saving || 'Saving...').removeClass('success error');

				// Collect data from both Settings and Appearance tabs.
				var data = {
					action: 'mvweb_pt_save_settings',
					nonce: mvweb_pt_ajax.nonce,
					// Settings tab.
					cache_ttl: $('#cache_ttl').val(),
					fallback_enabled: $('input[name="fallback_enabled"]').is(':checked') ? '1' : '0',
					stats_enabled: $('input[name="stats_enabled"]').is(':checked') ? '1' : '0',
					default_preset: $('#default_preset').val(),
					currency: $('#currency').val(),
					custom_currency: $('#custom_currency').val(),
					keep_data_on_uninstall: $('input[name="keep_data_on_uninstall"]').is(':checked') ? '1' : '0',
					// Appearance tab.
					default_title: $('#default_title').val(),
					default_description: $('#default_description').val(),
					footer_text: $('#footer_text').val(),
					default_button_text: $('#default_button_text').val(),
					service_column_label: $('#service_column_label').val(),
					time_column_label: $('#time_column_label').val(),
					price_column_label: $('#price_column_label').val(),
					on_request_text: $('#on_request_text').val(),
					custom_css: $('#custom_css').val()
				};

				$.post(mvweb_pt_ajax.ajax_url, data, function(response) {
					if (response.success) {
						$status.text(response.data.message || mvweb_pt_ajax.i18n.success).addClass('success');
					} else {
						$status.text(response.data.message || mvweb_pt_ajax.i18n.error).addClass('error');
					}
				}).fail(function() {
					$status.text(mvweb_pt_ajax.i18n.error).addClass('error');
				}).always(function() {
					$submitBtn.prop('disabled', false);
					setTimeout(function() {
						$status.text('');
					}, 3000);
				});
			});

			// Clear cache.
			$('.mvweb-pc-clear-cache').on('click', function() {
				var $button = $(this);
				var $cacheStatus = $('.mvweb-pc-cache-status');

				$button.prop('disabled', true);
				$cacheStatus.text(mvweb_pt_ajax.i18n.clearing).removeClass('success error');

				$.post(mvweb_pt_ajax.ajax_url, {
					action: 'mvweb_pt_clear_cache',
					nonce: mvweb_pt_ajax.nonce
				}, function(response) {
					if (response.success) {
						$cacheStatus.text(response.data.message || mvweb_pt_ajax.i18n.success).addClass('success');
					} else {
						$cacheStatus.text(response.data.message || mvweb_pt_ajax.i18n.error).addClass('error');
					}
				}).fail(function() {
					$cacheStatus.text(mvweb_pt_ajax.i18n.error).addClass('error');
				}).always(function() {
					$button.prop('disabled', false);
					setTimeout(function() {
						$cacheStatus.text('');
					}, 3000);
				});
			});
		},

		/**
		 * Appearance settings form.
		 *
		 * @deprecated 2.2.0 Now handled by initSettings().
		 */
		initAppearance: function() {
			// Appearance is now part of the unified settings form.
			// This method is kept for backwards compatibility.
		},

		/**
		 * Copy shortcode to clipboard.
		 */
		initCopyShortcode: function() {
			$(document).on('click', '.mvweb-pc-copy-shortcode', function() {
				var $button = $(this);
				var $code = $button.siblings('.mvweb-pc-shortcode');
				var shortcode = $code.text();

				if (navigator.clipboard) {
					navigator.clipboard.writeText(shortcode).then(function() {
						$button.find('.dashicons').removeClass('dashicons-clipboard').addClass('dashicons-yes');
						setTimeout(function() {
							$button.find('.dashicons').removeClass('dashicons-yes').addClass('dashicons-clipboard');
						}, 1500);
					});
				} else {
					// Fallback for older browsers.
					var $temp = $('<textarea>');
					$('body').append($temp);
					$temp.val(shortcode).select();
					document.execCommand('copy');
					$temp.remove();

					$button.find('.dashicons').removeClass('dashicons-clipboard').addClass('dashicons-yes');
					setTimeout(function() {
						$button.find('.dashicons').removeClass('dashicons-yes').addClass('dashicons-clipboard');
					}, 1500);
				}
			});
		},

		/**
		 * Statistics functionality.
		 */
		initStatistics: function() {
			var self = this;

			// Period and form filter changes.
			$(document).on('change', '.mvweb-pc-stats-filter', function() {
				var period = $('#mvweb-pc-stats-period').val();
				var formId = $('#mvweb-pc-stats-form').val();
				var url = window.location.pathname + window.location.search.split('&period=')[0].split('&form_id=')[0];

				url += '&period=' + period;
				if (formId) {
					url += '&form_id=' + formId;
				}
				url += '#statistics';

				window.location.href = url;
			});

			// Export CSV.
			$(document).on('click', '.mvweb-pc-export-stats', function() {
				var $button = $(this);
				var period = $('#mvweb-pc-stats-period').val() || $button.data('period') || 'month';
				var formId = $('#mvweb-pc-stats-form').val() || $button.data('form') || '';

				$button.prop('disabled', true);

				$.post(mvweb_pt_ajax.ajax_url, {
					action: 'mvweb_pt_export_stats',
					nonce: mvweb_pt_ajax.nonce,
					period: period,
					form_id: formId
				}, function(response) {
					if (response.success) {
						self.downloadCSV(response.data.csv, response.data.filename);
					} else {
						alert(response.data.message || mvweb_pt_ajax.i18n.error);
					}
				}).fail(function() {
					alert(mvweb_pt_ajax.i18n.error);
				}).always(function() {
					$button.prop('disabled', false);
				});
			});

			// Clear statistics.
			$(document).on('click', '.mvweb-pc-clear-stats', function() {
				var $button = $(this);

				if (!confirm(mvweb_pt_ajax.i18n.confirm_clear_stats || 'Are you sure you want to clear all statistics?')) {
					return;
				}

				$button.prop('disabled', true);

				$.post(mvweb_pt_ajax.ajax_url, {
					action: 'mvweb_pt_clear_stats',
					nonce: mvweb_pt_ajax.nonce,
					period: 'all'
				}, function(response) {
					if (response.success) {
						alert(response.data.message);
						window.location.reload();
					} else {
						alert(response.data.message || mvweb_pt_ajax.i18n.error);
					}
				}).fail(function() {
					alert(mvweb_pt_ajax.i18n.error);
				}).always(function() {
					$button.prop('disabled', false);
				});
			});

			// Link to settings tab from statistics notice.
			$(document).on('click', '.nav-tab-link', function(e) {
				e.preventDefault();
				var tabId = $(this).data('tab');
				$('.mvweb-pc-tabs .nav-tab[data-tab="' + tabId + '"]').trigger('click');
			});
		},

		/**
		 * Download CSV file.
		 */
		downloadCSV: function(csv, filename) {
			var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
			var link = document.createElement('a');

			if (navigator.msSaveBlob) {
				// IE 10+
				navigator.msSaveBlob(blob, filename);
			} else {
				var url = URL.createObjectURL(blob);
				link.setAttribute('href', url);
				link.setAttribute('download', filename);
				link.style.visibility = 'hidden';
				document.body.appendChild(link);
				link.click();
				document.body.removeChild(link);
			}
		},

		/**
		 * Field Mapping functionality (v2.0).
		 */
		initFieldMapping: function() {
			var self = this;

			// Auto-detect button.
			$(document).on('click', '.mvweb-pc-auto-detect', function() {
				self.autoDetectMapping();
			});

			// Add column button.
			$(document).on('click', '.mvweb-pc-add-column', function() {
				self.addMappingColumn();
			});

			// Remove column button.
			$(document).on('click', '.mvweb-pc-remove-column', function() {
				$(this).closest('tr').remove();
				self.updateMappingFromUI();
			});

			// Preset buttons.
			$(document).on('click', '.mvweb-pc-preset-btn', function() {
				var presetId = $(this).data('preset');
				self.applyMappingPreset(presetId);
			});

			// Inheritance toggle.
			$(document).on('change', '#mvweb-pc-inheritance-enabled', function() {
				var $options = $('.mvweb-pc-inheritance-options');
				if ($(this).is(':checked')) {
					$options.slideDown(200);
				} else {
					$options.slideUp(200);
				}
				self.updateMappingFromUI();
			});

			// Update mapping when any field changes (select, text input, checkbox).
			$(document).on('change', '.mvweb-pc-mapping-table select, .mvweb-pc-mapping-table input', function() {
				self.updateMappingFromUI();
			});

			// Explicit handler for mobile checkbox (ensure it triggers update).
			$(document).on('click', '.mvweb-pc-mobile-checkbox', function() {
				self.updateMappingFromUI();
			});

			$(document).on('change', '#mvweb-pc-wildcard-char, #mvweb-pc-show-source', function() {
				self.updateMappingFromUI();
			});
		},

		/**
		 * Auto-detect field mapping from spreadsheet headers.
		 */
		autoDetectMapping: function() {
			var self = this;
			var $button = $('.mvweb-pc-auto-detect');
			var url = $('#mvweb-pc-form-url').val();

			if (!url) {
				alert(mvweb_pt_ajax.i18n.url_required || 'Please enter Google Sheets URL first.');
				return;
			}

			$button.prop('disabled', true).text(mvweb_pt_ajax.i18n.detecting || 'Detecting...');

			var sheetId = $('#mvweb-pc-form-sheet').val();

			$.post(mvweb_pt_ajax.ajax_url, {
				action: 'mvweb_pt_auto_detect_mapping',
				nonce: mvweb_pt_ajax.nonce,
				spreadsheet_url: url,
				sheet_id: sheetId
			}, function(response) {
				if (response.success) {
					self.fieldMapping = response.data.mapping;
					self.renderMappingTable(response.data.mapping, response.data.headers);
					self.fetchPreview(url, sheetId);
				} else {
					alert(response.data.message || mvweb_pt_ajax.i18n.error);
				}
			}).fail(function() {
				alert(mvweb_pt_ajax.i18n.error);
			}).always(function() {
				$button.prop('disabled', false).html('<span class="dashicons dashicons-search" style="vertical-align: middle;"></span> ' + (mvweb_pt_ajax.i18n.auto_detect || 'Auto-Detect Columns'));
			});
		},

		/**
		 * Fetch preview data from spreadsheet.
		 *
		 * @param {string} url - Spreadsheet URL.
		 * @param {string|null} sheetId - Optional sheet gid.
		 */
		fetchPreview: function(url, sheetId) {
			var self = this;

			$.post(mvweb_pt_ajax.ajax_url, {
				action: 'mvweb_pt_fetch_preview',
				nonce: mvweb_pt_ajax.nonce,
				spreadsheet_url: url,
				sheet_id: sheetId || '',
				limit: 20
			}, function(response) {
				if (response.success) {
					self.renderPreviewTable(response.data.headers, response.data.rows);
					$('.mvweb-pc-preview-section').slideDown(200);
				}
			});
		},

		/**
		 * Render mapping table from configuration.
		 */
		renderMappingTable: function(mapping, headers) {
			var self = this;
			var $tbody = $('#mvweb-pc-mapping-rows');
			$tbody.empty();

			if (!mapping || !mapping.columns || mapping.columns.length === 0) {
				$tbody.html('<tr class="mvweb-pc-mapping-placeholder"><td colspan="6">' + (mvweb_pt_ajax.i18n.no_columns || 'Click "Auto-Detect Columns" or add columns manually.') + '</td></tr>');
				return;
			}

			mapping.columns.forEach(function(column, index) {
				var header = headers && headers[column.index] ? headers[column.index] : '';
				var confidence = column.confidence || 0;
				var confidenceClass = confidence >= 70 ? 'high' : (confidence >= 40 ? 'medium' : 'low');
				var fullWidthMobile = column.full_width_mobile || false;

				var $row = self.createMappingRow(column.index, header, column.role, column.label, column.format, confidenceClass, fullWidthMobile);
				$tbody.append($row);
			});

			// Update inheritance settings.
			if (mapping.inheritance) {
				$('#mvweb-pc-inheritance-enabled').prop('checked', mapping.inheritance.enabled);
				$('#mvweb-pc-wildcard-char').val(mapping.inheritance.wildcard || '*');
				$('#mvweb-pc-show-source').prop('checked', mapping.inheritance.show_source);

				if (mapping.inheritance.enabled) {
					$('.mvweb-pc-inheritance-options').show();
				}
			}

			self.updateFieldMappingInput();
		},

		/**
		 * Create a mapping table row.
		 */
		createMappingRow: function(index, header, role, label, format, confidenceClass, fullWidthMobile) {
			var roles = window.mvwebPcRoles || {};
			var formats = window.mvwebPcFormats || {};

			var roleOptions = '';
			for (var roleKey in roles) {
				var selected = roleKey === role ? ' selected' : '';
				roleOptions += '<option value="' + roleKey + '"' + selected + '>' + roles[roleKey] + '</option>';
			}

			var formatOptions = '';
			for (var formatKey in formats) {
				var selected = formatKey === format ? ' selected' : '';
				formatOptions += '<option value="' + formatKey + '"' + selected + '>' + formats[formatKey] + '</option>';
			}

			var confidenceIndicator = confidenceClass ? '<span class="mvweb-pc-confidence mvweb-pc-confidence--' + confidenceClass + '" title="Auto-detection confidence"></span>' : '';
			var mobileChecked = fullWidthMobile ? ' checked' : '';

			var html = '<tr data-index="' + index + '">' +
				'<td class="column-index"><span class="mvweb-pc-col-index">' + (index + 1) + '</span></td>' +
				'<td class="column-header">' + confidenceIndicator + '<span class="header-detected">' + this.escapeHtml(header || '-') + '</span></td>' +
				'<td class="column-role"><select class="mvweb-pc-role-select">' + roleOptions + '</select></td>' +
				'<td class="column-label"><input type="text" class="mvweb-pc-label-input" value="' + this.escapeHtml(label || '') + '" placeholder="' + this.escapeHtml(header || 'Label') + '"></td>' +
				'<td class="column-format"><div class="column-format-inner"><select class="mvweb-pc-format-select">' + formatOptions + '</select><span class="mvweb-pc-remove-column dashicons dashicons-trash"></span></div></td>' +
				'<td class="column-mobile"><input type="checkbox" class="mvweb-pc-mobile-checkbox"' + mobileChecked + ' title="Full width on mobile"></td>' +
				'</tr>';

			return $(html);
		},

		/**
		 * Add a new mapping column.
		 */
		addMappingColumn: function() {
			var $tbody = $('#mvweb-pc-mapping-rows');
			var $placeholder = $tbody.find('.mvweb-pc-mapping-placeholder');

			if ($placeholder.length) {
				$placeholder.remove();
			}

			// Find next available index.
			var maxIndex = -1;
			$tbody.find('tr[data-index]').each(function() {
				var idx = parseInt($(this).data('index'), 10);
				if (idx > maxIndex) {
					maxIndex = idx;
				}
			});

			var newIndex = maxIndex + 1;
			var $row = this.createMappingRow(newIndex, '', 'ignore', '', 'text', '', false);
			$tbody.append($row);

			this.updateMappingFromUI();
		},

		/**
		 * Apply a mapping preset.
		 */
		applyMappingPreset: function(presetId) {
			var presets = window.mvwebPcPresets || {};
			if (!presets[presetId]) {
				return;
			}

			this.fieldMapping = presets[presetId].mapping;
			this.renderMappingTable(this.fieldMapping, []);
		},

		/**
		 * Update mapping configuration from UI.
		 */
		updateMappingFromUI: function() {
			var self = this;
			var columns = [];

			$('#mvweb-pc-mapping-rows tr[data-index]').each(function() {
				var $row = $(this);
				columns.push({
					index: parseInt($row.data('index'), 10),
					role: $row.find('.mvweb-pc-role-select').val(),
					label: $row.find('.mvweb-pc-label-input').val(),
					format: $row.find('.mvweb-pc-format-select').val(),
					full_width_mobile: $row.find('.mvweb-pc-mobile-checkbox').is(':checked')
				});
			});

			self.fieldMapping = {
				schema_version: '2.0',
				mode: columns.length > 0 ? 'mapped' : 'legacy',
				columns: columns,
				inheritance: {
					enabled: $('#mvweb-pc-inheritance-enabled').is(':checked'),
					wildcard: $('#mvweb-pc-wildcard-char').val() || '*',
					show_source: $('#mvweb-pc-show-source').is(':checked')
				}
			};

			self.updateFieldMappingInput();
		},

		/**
		 * Update hidden field_mapping input.
		 */
		updateFieldMappingInput: function() {
			$('#mvweb-pc-field-mapping').val(JSON.stringify(this.fieldMapping));
		},

		/**
		 * Render preview table.
		 */
		renderPreviewTable: function(headers, rows) {
			var $thead = $('#mvweb-pc-preview-headers');
			var $tbody = $('#mvweb-pc-preview-rows');

			$thead.empty();
			$tbody.empty();

			// Headers.
			var headerHtml = '<tr>';
			headers.forEach(function(header, index) {
				headerHtml += '<th>' + (index + 1) + '. ' + MVwebPcAdmin.escapeHtml(header || '-') + '</th>';
			});
			headerHtml += '</tr>';
			$thead.html(headerHtml);

			// Rows.
			rows.forEach(function(row) {
				var rowHtml = '<tr>';
				row.forEach(function(cell) {
					rowHtml += '<td title="' + MVwebPcAdmin.escapeHtml(cell || '') + '">' + MVwebPcAdmin.escapeHtml(cell || '-') + '</td>';
				});
				rowHtml += '</tr>';
				$tbody.append(rowHtml);
			});
		},

		/**
		 * Escape HTML special characters.
		 */
		escapeHtml: function(text) {
			if (!text) return '';
			var div = document.createElement('div');
			div.textContent = text;
			return div.innerHTML;
		}
	};

	// Initialize on document ready.
	$(document).ready(function() {
		MVwebPcAdmin.init();
	});

})(jQuery);
