<?php
/**
 * Appearance tab template.
 *
 * @package MVweb_Price_Table
 * @since   1.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<h2 class="mvweb-section-title"><?php esc_html_e( 'Form Title & Description', 'mvweb-price-table' ); ?></h2>
	<p class="description">
		<?php esc_html_e( 'These settings can be overridden per form in the Forms tab.', 'mvweb-price-table' ); ?>
	</p>
	<table class="form-table">
		<tr>
			<th scope="row">
				<label for="default_title"><?php esc_html_e( 'Default Title', 'mvweb-price-table' ); ?></label>
			</th>
			<td>
				<input type="text" id="default_title" name="default_title" class="regular-text"
					   value="<?php echo esc_attr( $settings['default_title'] ?? '' ); ?>">
				<p class="description">
					<?php esc_html_e( 'Default title displayed above the form. Leave empty to hide.', 'mvweb-price-table' ); ?>
				</p>
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="default_description"><?php esc_html_e( 'Default Description', 'mvweb-price-table' ); ?></label>
			</th>
			<td>
				<textarea id="default_description" name="default_description" class="large-text" rows="3"><?php echo esc_textarea( $settings['default_description'] ?? '' ); ?></textarea>
				<p class="description">
					<?php esc_html_e( 'Description text displayed below the title.', 'mvweb-price-table' ); ?>
				</p>
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="footer_text"><?php esc_html_e( 'Footer Text', 'mvweb-price-table' ); ?></label>
			</th>
			<td>
				<textarea id="footer_text" name="footer_text" class="large-text" rows="2"><?php echo esc_textarea( $settings['footer_text'] ?? '' ); ?></textarea>
				<p class="description">
					<?php esc_html_e( 'Text displayed below the price table. Supports basic HTML.', 'mvweb-price-table' ); ?>
				</p>
			</td>
		</tr>
	</table>

	<h2 class="mvweb-section-title"><?php esc_html_e( 'Button Customization', 'mvweb-price-table' ); ?></h2>
	<table class="form-table">
		<tr>
			<th scope="row">
				<label for="default_button_text"><?php esc_html_e( 'Button Text', 'mvweb-price-table' ); ?></label>
			</th>
			<td>
				<input type="text" id="default_button_text" name="default_button_text" class="regular-text"
					   value="<?php echo esc_attr( $settings['default_button_text'] ?? __( 'Show Prices', 'mvweb-price-table' ) ); ?>">
			</td>
		</tr>
	</table>

	<h2 class="mvweb-section-title"><?php esc_html_e( 'Custom CSS', 'mvweb-price-table' ); ?></h2>
	<table class="form-table">
		<tr>
			<th scope="row">
				<label for="custom_css"><?php esc_html_e( 'Additional CSS', 'mvweb-price-table' ); ?></label>
			</th>
			<td>
				<textarea id="custom_css" name="custom_css" class="large-text code mvweb-textarea" rows="10" placeholder="/* <?php esc_attr_e( 'Add your custom CSS here', 'mvweb-price-table' ); ?> */
.mvweb-pc {
    /* <?php esc_attr_e( 'Your styles', 'mvweb-price-table' ); ?> */
}"><?php echo esc_textarea( $settings['custom_css'] ?? '' ); ?></textarea>
				<p class="description">
					<?php esc_html_e( 'Custom CSS will be added to the frontend. Use .mvweb-pc selector for specificity.', 'mvweb-price-table' ); ?>
				</p>
			</td>
		</tr>
	</table>
