<?php
/**
 * Help tab template.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 * @since   2.0.0 Updated with Field Mapping, inheritance, and new presets.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-help">
	<!-- Quick Start -->
	<section class="mvweb-help__section">
		<h2 class="mvweb-section-title"><?php esc_html_e( 'Quick Start', 'mvweb-price-table' ); ?></h2>
		<ol class="mvweb-help__steps">
			<li>
				<strong><?php esc_html_e( 'Create a Google Sheets spreadsheet', 'mvweb-price-table' ); ?></strong>
				<p><?php esc_html_e( 'Create a new spreadsheet with your price data. Column headers are auto-detected.', 'mvweb-price-table' ); ?></p>
			</li>
			<li>
				<strong><?php esc_html_e( 'Make it public', 'mvweb-price-table' ); ?></strong>
				<p><?php esc_html_e( 'Go to File → Share → Share with others → Anyone with the link can view.', 'mvweb-price-table' ); ?></p>
			</li>
			<li>
				<strong><?php esc_html_e( 'Create a form', 'mvweb-price-table' ); ?></strong>
				<p><?php esc_html_e( 'Go to Forms tab, click "Add New Form", paste the spreadsheet URL, and select the sheet/tab if your spreadsheet has multiple sheets.', 'mvweb-price-table' ); ?></p>
			</li>
			<li>
				<strong><?php esc_html_e( 'Configure Field Mapping', 'mvweb-price-table' ); ?></strong>
				<p><?php esc_html_e( 'Click "Auto-detect" to automatically assign column roles, or configure manually if needed.', 'mvweb-price-table' ); ?></p>
			</li>
			<li>
				<strong><?php esc_html_e( 'Add to your page', 'mvweb-price-table' ); ?></strong>
				<p><?php esc_html_e( 'Copy the shortcode and paste it into any page or post.', 'mvweb-price-table' ); ?></p>
			</li>
		</ol>
	</section>

	<!-- Sheet Selection (v2.0) -->
	<section class="mvweb-help__section">
		<h2 class="mvweb-section-title"><?php esc_html_e( 'Sheet Selection', 'mvweb-price-table' ); ?></h2>
		<p><?php esc_html_e( 'If your spreadsheet has multiple sheets (tabs), you can select which one to use:', 'mvweb-price-table' ); ?></p>
		<ol>
			<li><?php esc_html_e( 'Paste the spreadsheet URL and click "Test Connection"', 'mvweb-price-table' ); ?></li>
			<li><?php esc_html_e( 'The plugin will detect all available sheets', 'mvweb-price-table' ); ?></li>
			<li><?php esc_html_e( 'Select the desired sheet from the dropdown', 'mvweb-price-table' ); ?></li>
			<li><?php esc_html_e( 'The data will be loaded from the selected sheet', 'mvweb-price-table' ); ?></li>
		</ol>
		<div class="mvweb-notice mvweb-notice--info">
			<p><?php esc_html_e( 'If you change the sheet, click "Auto-detect" to update the field mapping for the new columns.', 'mvweb-price-table' ); ?></p>
		</div>
	</section>

	<!-- Google Sheets Format -->
	<section class="mvweb-help__section">
		<h2 class="mvweb-section-title"><?php esc_html_e( 'Google Sheets Format', 'mvweb-price-table' ); ?></h2>
		<p><?php esc_html_e( 'Your spreadsheet should have column headers in the first row. The plugin supports flexible column order via Field Mapping.', 'mvweb-price-table' ); ?></p>

		<h3><?php esc_html_e( 'Recommended Columns', 'mvweb-price-table' ); ?></h3>
		<table class="mvweb-table mvweb-table--striped">
			<thead>
				<tr>
					<th style="width: 120px;"><?php esc_html_e( 'Column Type', 'mvweb-price-table' ); ?></th>
					<th><?php esc_html_e( 'Description', 'mvweb-price-table' ); ?></th>
					<th style="width: 180px;"><?php esc_html_e( 'Example Headers', 'mvweb-price-table' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><strong><?php esc_html_e( 'Hierarchy', 'mvweb-price-table' ); ?></strong></td>
					<td><?php esc_html_e( 'Cascading selection levels (1-5 levels supported)', 'mvweb-price-table' ); ?></td>
					<td>Brand, Type, Model</td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Service', 'mvweb-price-table' ); ?></strong></td>
					<td><?php esc_html_e( 'Service or product name (required)', 'mvweb-price-table' ); ?></td>
					<td>Service, Услуга, Repair</td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Price', 'mvweb-price-table' ); ?></strong></td>
					<td><?php esc_html_e( 'Price value - number or text (required)', 'mvweb-price-table' ); ?></td>
					<td>Price, Цена, Cost</td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Time', 'mvweb-price-table' ); ?></strong></td>
					<td><?php esc_html_e( 'Service duration (optional)', 'mvweb-price-table' ); ?></td>
					<td>Time, Время, Duration</td>
				</tr>
				<tr>
					<td><strong><?php esc_html_e( 'Additional', 'mvweb-price-table' ); ?></strong></td>
					<td><?php esc_html_e( 'Note, warranty, SKU, etc. (optional)', 'mvweb-price-table' ); ?></td>
					<td>Note, Warranty, SKU</td>
				</tr>
			</tbody>
		</table>

		<h3><?php esc_html_e( 'Example Spreadsheet', 'mvweb-price-table' ); ?></h3>
		<table class="mvweb-table mvweb-table--striped">
			<thead>
				<tr>
					<th>Brand</th>
					<th>Type</th>
					<th>Model</th>
					<th>Service</th>
					<th>Time</th>
					<th>Price</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td>Apple</td>
					<td>iPhone</td>
					<td>iPhone 14 Pro</td>
					<td>Screen Replacement</td>
					<td>60 min</td>
					<td>15000</td>
				</tr>
				<tr>
					<td>Apple</td>
					<td>iPhone</td>
					<td>iPhone 14 Pro</td>
					<td>Battery Replacement</td>
					<td>30 min</td>
					<td>8000</td>
				</tr>
				<tr>
					<td>Samsung</td>
					<td>Galaxy</td>
					<td>Galaxy S23</td>
					<td>Screen Replacement</td>
					<td>90 min</td>
					<td>12000</td>
				</tr>
			</tbody>
		</table>

		<div class="mvweb-notice mvweb-notice--info">
			<p><strong><?php esc_html_e( 'Cyrillic Support:', 'mvweb-price-table' ); ?></strong> <?php esc_html_e( 'Full support for Cyrillic characters in brand, type, model names (e.g., "Все модели", "Смартфон").', 'mvweb-price-table' ); ?></p>
		</div>

		<h3><?php esc_html_e( 'Model Grouping', 'mvweb-price-table' ); ?></h3>
		<p><?php esc_html_e( 'You can group multiple models with the same price using these formats:', 'mvweb-price-table' ); ?></p>

		<table class="mvweb-table mvweb-table--striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Format', 'mvweb-price-table' ); ?></th>
					<th><?php esc_html_e( 'Example', 'mvweb-price-table' ); ?></th>
					<th><?php esc_html_e( 'Result', 'mvweb-price-table' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><?php esc_html_e( 'Comma-separated', 'mvweb-price-table' ); ?></td>
					<td><code>iPhone 14, iPhone 14 Plus</code></td>
					<td><?php esc_html_e( 'Two separate models', 'mvweb-price-table' ); ?></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Brackets group', 'mvweb-price-table' ); ?></td>
					<td><code>iPhone 14 [Pro/Pro Max]</code></td>
					<td><?php esc_html_e( 'Group "iPhone 14 Pro/Pro Max" shown as one option', 'mvweb-price-table' ); ?></td>
				</tr>
				<tr>
					<td><?php esc_html_e( 'Wildcard', 'mvweb-price-table' ); ?></td>
					<td><code>{iPhone 14}</code></td>
					<td><?php esc_html_e( 'Matches all models starting with "iPhone 14"', 'mvweb-price-table' ); ?></td>
				</tr>
			</tbody>
		</table>
	</section>

	<!-- Field Mapping (v2.0) -->
	<section class="mvweb-help__section">
		<h2 class="mvweb-section-title"><?php esc_html_e( 'Field Mapping', 'mvweb-price-table' ); ?></h2>
		<p><?php esc_html_e( 'Field Mapping allows flexible column configuration. The plugin can auto-detect roles from column headers or you can set them manually.', 'mvweb-price-table' ); ?></p>

		<h3><?php esc_html_e( 'Auto-Detection', 'mvweb-price-table' ); ?></h3>
		<ol>
			<li><?php esc_html_e( 'After connecting to a spreadsheet, click "Auto-detect"', 'mvweb-price-table' ); ?></li>
			<li><?php esc_html_e( 'The plugin analyzes column headers and assigns roles automatically', 'mvweb-price-table' ); ?></li>
			<li><?php esc_html_e( 'Review and adjust if needed, then save the form', 'mvweb-price-table' ); ?></li>
		</ol>

		<p><?php esc_html_e( 'Auto-detection recognizes keywords in Russian and English:', 'mvweb-price-table' ); ?></p>
		<ul>
			<li><strong>Brand:</strong> brand, бренд, марка, manufacturer</li>
			<li><strong>Type:</strong> type, тип, категория, category, series</li>
			<li><strong>Model:</strong> model, модель, product, товар</li>
			<li><strong>Service:</strong> service, услуга, repair, ремонт</li>
			<li><strong>Price:</strong> price, цена, стоимость, cost</li>
			<li><strong>Time:</strong> time, время, duration, срок</li>
		</ul>

		<h3><?php esc_html_e( 'Available Roles', 'mvweb-price-table' ); ?></h3>
		<table class="mvweb-table mvweb-table--striped">
			<thead>
				<tr>
					<th style="width: 150px;"><?php esc_html_e( 'Role', 'mvweb-price-table' ); ?></th>
					<th><?php esc_html_e( 'Description', 'mvweb-price-table' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><code>hierarchy_1-5</code></td>
					<td><?php esc_html_e( 'Hierarchy levels (Brand, Type, Model, etc.) - up to 5 levels supported', 'mvweb-price-table' ); ?></td>
				</tr>
				<tr>
					<td><code>service_name</code></td>
					<td><?php esc_html_e( 'Service/product name (required)', 'mvweb-price-table' ); ?></td>
				</tr>
				<tr>
					<td><code>service_price</code></td>
					<td><?php esc_html_e( 'Price value (required)', 'mvweb-price-table' ); ?></td>
				</tr>
				<tr>
					<td><code>service_time</code></td>
					<td><?php esc_html_e( 'Duration/time', 'mvweb-price-table' ); ?></td>
				</tr>
				<tr>
					<td><code>service_group</code></td>
					<td><?php esc_html_e( 'Service group for categorization in results table', 'mvweb-price-table' ); ?></td>
				</tr>
				<tr>
					<td><code>meta_note</code></td>
					<td><?php esc_html_e( 'Note/description displayed in results', 'mvweb-price-table' ); ?></td>
				</tr>
				<tr>
					<td><code>meta_warranty</code></td>
					<td><?php esc_html_e( 'Warranty information', 'mvweb-price-table' ); ?></td>
				</tr>
				<tr>
					<td><code>meta_sku</code></td>
					<td><?php esc_html_e( 'SKU/article number', 'mvweb-price-table' ); ?></td>
				</tr>
				<tr>
					<td><code>ignore</code></td>
					<td><?php esc_html_e( 'Skip this column (not used in the calculator)', 'mvweb-price-table' ); ?></td>
				</tr>
			</tbody>
		</table>
	</section>

	<!-- Value Inheritance (v2.0) -->
	<section class="mvweb-help__section">
		<h2 class="mvweb-section-title"><?php esc_html_e( 'Value Inheritance (Advanced)', 'mvweb-price-table' ); ?></h2>
		<p><?php esc_html_e( 'Use {pattern} syntax to define default values that are inherited by more specific entries:', 'mvweb-price-table' ); ?></p>

		<table class="mvweb-table mvweb-table--striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Brand', 'mvweb-price-table' ); ?></th>
					<th><?php esc_html_e( 'Type', 'mvweb-price-table' ); ?></th>
					<th><?php esc_html_e( 'Model', 'mvweb-price-table' ); ?></th>
					<th><?php esc_html_e( 'Service', 'mvweb-price-table' ); ?></th>
					<th><?php esc_html_e( 'Time', 'mvweb-price-table' ); ?></th>
					<th><?php esc_html_e( 'Price', 'mvweb-price-table' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><code>*</code></td>
					<td><code>*</code></td>
					<td><code>*</code></td>
					<td><?php esc_html_e( 'Screen Repair', 'mvweb-price-table' ); ?></td>
					<td><?php esc_html_e( '60 min', 'mvweb-price-table' ); ?></td>
					<td>5000</td>
				</tr>
				<tr>
					<td>Apple</td>
					<td><code>*</code></td>
					<td><code>*</code></td>
					<td><?php esc_html_e( 'Screen Repair', 'mvweb-price-table' ); ?></td>
					<td><?php esc_html_e( '90 min', 'mvweb-price-table' ); ?></td>
					<td>7000</td>
				</tr>
				<tr>
					<td>Apple</td>
					<td>iPhone</td>
					<td><code>*</code></td>
					<td><?php esc_html_e( 'Screen Repair', 'mvweb-price-table' ); ?></td>
					<td><?php esc_html_e( '60 min', 'mvweb-price-table' ); ?></td>
					<td>8000</td>
				</tr>
				<tr>
					<td>Apple</td>
					<td>iPhone</td>
					<td>15 Pro</td>
					<td><?php esc_html_e( 'Screen Repair', 'mvweb-price-table' ); ?></td>
					<td><?php esc_html_e( '45 min', 'mvweb-price-table' ); ?></td>
					<td>12000</td>
				</tr>
			</tbody>
		</table>

		<p><strong><?php esc_html_e( 'How it works:', 'mvweb-price-table' ); ?></strong></p>
		<ol>
			<li><?php esc_html_e( 'Row 1: Default for all brands/types/models', 'mvweb-price-table' ); ?></li>
			<li><?php esc_html_e( 'Row 2: Override for all Apple devices', 'mvweb-price-table' ); ?></li>
			<li><?php esc_html_e( 'Row 3: Override for all iPhones', 'mvweb-price-table' ); ?></li>
			<li><?php esc_html_e( 'Row 4: Specific price for iPhone 15 Pro', 'mvweb-price-table' ); ?></li>
		</ol>
		<p><?php esc_html_e( 'Query for "Apple > iPhone > 15 Pro" returns: Screen Repair | 45 min | 12000', 'mvweb-price-table' ); ?></p>

		<div class="mvweb-notice mvweb-notice--info">
			<p><?php esc_html_e( 'To enable inheritance, check "Enable value inheritance" in the Form settings under Field Mapping section.', 'mvweb-price-table' ); ?></p>
		</div>
	</section>

	<!-- Shortcode -->
	<section class="mvweb-help__section">
		<h2 class="mvweb-section-title"><?php esc_html_e( 'Shortcode Usage', 'mvweb-price-table' ); ?></h2>

		<h3><?php esc_html_e( 'Basic Usage', 'mvweb-price-table' ); ?></h3>
		<pre class="mvweb-help__code">[mvweb_price_table id="1"]</pre>

		<h3><?php esc_html_e( 'Available Attributes', 'mvweb-price-table' ); ?></h3>
		<table class="mvweb-table mvweb-table--striped">
			<thead>
				<tr>
					<th style="width: 120px;"><?php esc_html_e( 'Attribute', 'mvweb-price-table' ); ?></th>
					<th><?php esc_html_e( 'Description', 'mvweb-price-table' ); ?></th>
					<th style="width: 200px;"><?php esc_html_e( 'Example', 'mvweb-price-table' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><code>id</code></td>
					<td><?php esc_html_e( 'Form ID (required)', 'mvweb-price-table' ); ?></td>
					<td><code>id="1"</code></td>
				</tr>
				<tr>
					<td><code>preset</code></td>
					<td><?php esc_html_e( 'Design preset (16 available - see below)', 'mvweb-price-table' ); ?></td>
					<td><code>preset="aurora"</code></td>
				</tr>
				<tr>
					<td><code>level-1</code></td>
					<td><?php esc_html_e( 'Pre-select hierarchy level 1', 'mvweb-price-table' ); ?></td>
					<td><code>level-1="Apple"</code></td>
				</tr>
				<tr>
					<td><code>level-2</code></td>
					<td><?php esc_html_e( 'Pre-select hierarchy level 2', 'mvweb-price-table' ); ?></td>
					<td><code>level-2="iPhone"</code></td>
				</tr>
				<tr>
					<td><code>level-3</code></td>
					<td><?php esc_html_e( 'Pre-select hierarchy level 3', 'mvweb-price-table' ); ?></td>
					<td><code>level-3="iphone-14-pro"</code></td>
				</tr>
				<tr>
					<td><code>level-4, level-5</code></td>
					<td><?php esc_html_e( 'Pre-select hierarchy levels 4-5 (if configured)', 'mvweb-price-table' ); ?></td>
					<td><code>level-4="128gb"</code></td>
				</tr>
				<tr>
					<td><code>title</code></td>
					<td><?php esc_html_e( 'Custom form title', 'mvweb-price-table' ); ?></td>
					<td><code>title="Repair Prices"</code></td>
				</tr>
				<tr>
					<td><code>show_title</code></td>
					<td><?php esc_html_e( 'Show or hide title', 'mvweb-price-table' ); ?></td>
					<td><code>show_title="false"</code></td>
				</tr>
				<tr>
					<td><code>class</code></td>
					<td><?php esc_html_e( 'Additional CSS class', 'mvweb-price-table' ); ?></td>
					<td><code>class="my-custom-class"</code></td>
				</tr>
			</tbody>
		</table>

		<h3><?php esc_html_e( 'Design Presets', 'mvweb-price-table' ); ?></h3>
		<p><?php esc_html_e( '16 built-in design presets available:', 'mvweb-price-table' ); ?></p>
		<table class="mvweb-table mvweb-table--striped">
			<thead>
				<tr>
					<th style="width: 140px;"><?php esc_html_e( 'Preset', 'mvweb-price-table' ); ?></th>
					<th><?php esc_html_e( 'Description', 'mvweb-price-table' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr><td><code>light</code></td><td><?php esc_html_e( 'Light (default) - Clean light theme', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>aurora</code></td><td><?php esc_html_e( 'Aurora Borealis - Dark with gradient accents', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>carbon</code></td><td><?php esc_html_e( 'Carbon Fiber - Dark industrial style', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>lavender</code></td><td><?php esc_html_e( 'Lavender Haze - Soft purple dark theme', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>emerald</code></td><td><?php esc_html_e( 'Emerald Gradient - Green gradient theme', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>classic-blue</code></td><td><?php esc_html_e( 'Classic Blue - Traditional blue theme', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>editorial</code></td><td><?php esc_html_e( 'Editorial - Magazine-style typography', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>soft-cloud</code></td><td><?php esc_html_e( 'Soft Cloud - Light and airy', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>elegant-serif</code></td><td><?php esc_html_e( 'Elegant Serif - Refined typography', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>swiss</code></td><td><?php esc_html_e( 'Swiss Minimal - Clean minimalist design', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>paper-craft</code></td><td><?php esc_html_e( 'Paper Craft - Textured paper look', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>mvweb-brand</code></td><td><?php esc_html_e( 'MVweb Brand - Purple brand colors', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>forest-green</code></td><td><?php esc_html_e( 'Forest Green - Natural green tones', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>ocean-blue</code></td><td><?php esc_html_e( 'Ocean Blue - Deep blue marine theme', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>sky-cyan</code></td><td><?php esc_html_e( 'Sky Cyan - Bright cyan accents', 'mvweb-price-table' ); ?></td></tr>
				<tr><td><code>teal-mint</code></td><td><?php esc_html_e( 'Teal Mint - Fresh teal and mint colors', 'mvweb-price-table' ); ?></td></tr>
			</tbody>
		</table>

		<h3><?php esc_html_e( 'Examples', 'mvweb-price-table' ); ?></h3>
		<pre class="mvweb-help__code"><?php
		// Examples.
		echo esc_html( '// Basic usage' ) . "\n";
		echo esc_html( '[mvweb_price_table id="1"]' ) . "\n\n";
		echo esc_html( '// Aurora theme with pre-selected level 1' ) . "\n";
		echo esc_html( '[mvweb_price_table id="1" preset="aurora" level-1="Apple"]' ) . "\n\n";
		echo esc_html( '// Custom title, hidden default title' ) . "\n";
		echo esc_html( '[mvweb_price_table id="1" title="iPhone Repair Prices" show_title="true"]' ) . "\n\n";
		echo esc_html( '// Pre-selected hierarchy levels for specific page' ) . "\n";
		echo esc_html( '[mvweb_price_table id="1" level-1="Apple" level-2="iPhone"]' );
		?></pre>
	</section>

	<!-- Gutenberg Block -->
	<section class="mvweb-help__section">
		<h2 class="mvweb-section-title"><?php esc_html_e( 'Gutenberg Block', 'mvweb-price-table' ); ?></h2>
		<p><?php esc_html_e( 'You can also use the Price Table block in the WordPress block editor:', 'mvweb-price-table' ); ?></p>
		<ol>
			<li><?php esc_html_e( 'Open the page/post in the block editor', 'mvweb-price-table' ); ?></li>
			<li><?php esc_html_e( 'Click the "+" button to add a block', 'mvweb-price-table' ); ?></li>
			<li><?php esc_html_e( 'Search for "Price Table" or find it in the MVweb category', 'mvweb-price-table' ); ?></li>
			<li><?php esc_html_e( 'Select the form and customize options in the sidebar', 'mvweb-price-table' ); ?></li>
		</ol>
	</section>

	<!-- PHP Function -->
	<section class="mvweb-help__section">
		<h2 class="mvweb-section-title"><?php esc_html_e( 'PHP Function (for Theme Developers)', 'mvweb-price-table' ); ?></h2>
		<p><?php esc_html_e( 'You can display the calculator directly in your theme templates:', 'mvweb-price-table' ); ?></p>

		<pre class="mvweb-help__code"><?php
		echo esc_html( '<?php' ) . "\n";
		echo esc_html( '// Display calculator with default settings' ) . "\n";
		echo esc_html( 'mvweb_price_table( 1 );' ) . "\n\n";
		echo esc_html( '// With custom options' ) . "\n";
		echo esc_html( 'mvweb_price_table( 1, array(' ) . "\n";
		echo esc_html( "    'show_title' => false," ) . "\n";
		echo esc_html( "    'preset'     => 'aurora'," ) . "\n";
		echo esc_html( "    'class'      => 'my-custom-class'," ) . "\n";
		echo esc_html( "    'echo'       => true, // false to return HTML" ) . "\n";
		echo esc_html( ') );' ) . "\n";
		echo esc_html( '?>' );
		?></pre>

		<h3><?php esc_html_e( 'Available Options', 'mvweb-price-table' ); ?></h3>
		<table class="mvweb-table mvweb-table--striped">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Option', 'mvweb-price-table' ); ?></th>
					<th><?php esc_html_e( 'Type', 'mvweb-price-table' ); ?></th>
					<th><?php esc_html_e( 'Default', 'mvweb-price-table' ); ?></th>
					<th><?php esc_html_e( 'Description', 'mvweb-price-table' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><code>show_title</code></td>
					<td>bool</td>
					<td>true</td>
					<td><?php esc_html_e( 'Show the form title', 'mvweb-price-table' ); ?></td>
				</tr>
				<tr>
					<td><code>preset</code></td>
					<td>string</td>
					<td>light</td>
					<td><?php esc_html_e( 'Design preset (see list above)', 'mvweb-price-table' ); ?></td>
				</tr>
				<tr>
					<td><code>class</code></td>
					<td>string</td>
					<td>''</td>
					<td><?php esc_html_e( 'Additional CSS class', 'mvweb-price-table' ); ?></td>
				</tr>
				<tr>
					<td><code>echo</code></td>
					<td>bool</td>
					<td>true</td>
					<td><?php esc_html_e( 'Echo output or return HTML', 'mvweb-price-table' ); ?></td>
				</tr>
			</tbody>
		</table>
	</section>

	<!-- FAQ -->
	<section class="mvweb-help__section">
		<h2 class="mvweb-section-title"><?php esc_html_e( 'Frequently Asked Questions', 'mvweb-price-table' ); ?></h2>

		<div class="mvweb-help__faq">
			<details class="mvweb-details">
				<summary><?php esc_html_e( 'Why is my spreadsheet not loading?', 'mvweb-price-table' ); ?></summary>
				<div class="mvweb-details__body">
					<p><?php esc_html_e( 'Make sure your spreadsheet is publicly accessible. Go to File → Share → Share with others → Change to "Anyone with the link". The spreadsheet must be viewable without sign-in.', 'mvweb-price-table' ); ?></p>
				</div>
			</details>

			<details class="mvweb-details">
				<summary><?php esc_html_e( 'My spreadsheet has multiple sheets. How do I select one?', 'mvweb-price-table' ); ?></summary>
				<div class="mvweb-details__body">
					<p><?php esc_html_e( 'After pasting the URL and clicking "Test Connection", the plugin detects all sheets. Select the desired sheet from the dropdown that appears. If you change the sheet, click "Auto-detect" to update the field mapping.', 'mvweb-price-table' ); ?></p>
				</div>
			</details>

			<details class="mvweb-details">
				<summary><?php esc_html_e( 'Columns are not detected correctly. What should I do?', 'mvweb-price-table' ); ?></summary>
				<div class="mvweb-details__body">
					<p><?php esc_html_e( 'Click "Auto-detect" to re-analyze column headers. If auto-detection fails, manually set the role for each column using the dropdown menus in the Field Mapping section.', 'mvweb-price-table' ); ?></p>
				</div>
			</details>

			<details class="mvweb-details">
				<summary><?php esc_html_e( 'How often is the data refreshed?', 'mvweb-price-table' ); ?></summary>
				<div class="mvweb-details__body">
					<p><?php esc_html_e( 'Data is cached according to your cache settings (default: 1 hour). You can clear the cache manually in Settings tab or change the cache duration.', 'mvweb-price-table' ); ?></p>
				</div>
			</details>

			<details class="mvweb-details">
				<summary><?php esc_html_e( 'Can I use Cyrillic (Russian) text in my spreadsheet?', 'mvweb-price-table' ); ?></summary>
				<div class="mvweb-details__body">
					<p><?php esc_html_e( 'Yes! Full Unicode/Cyrillic support is included. You can use Russian brand names, model names like "Все модели", etc. The plugin correctly handles all non-ASCII characters.', 'mvweb-price-table' ); ?></p>
				</div>
			</details>

			<details class="mvweb-details">
				<summary><?php esc_html_e( 'Can I have multiple calculators on one page?', 'mvweb-price-table' ); ?></summary>
				<div class="mvweb-details__body">
					<p><?php esc_html_e( 'Yes, you can add multiple shortcodes with different form IDs on the same page. Each calculator will work independently.', 'mvweb-price-table' ); ?></p>
				</div>
			</details>

			<details class="mvweb-details">
				<summary><?php esc_html_e( 'What happens if Google Sheets is unavailable?', 'mvweb-price-table' ); ?></summary>
				<div class="mvweb-details__body">
					<p><?php esc_html_e( 'If fallback cache is enabled (default), the plugin will show the last successfully loaded data. A small notice will indicate that cached data is being displayed.', 'mvweb-price-table' ); ?></p>
				</div>
			</details>

			<details class="mvweb-details">
				<summary><?php esc_html_e( 'How can I customize the design?', 'mvweb-price-table' ); ?></summary>
				<div class="mvweb-details__body">
					<p><?php esc_html_e( 'Choose from 16 built-in presets or add custom CSS in the Appearance tab. The calculator uses BEM methodology with CSS custom properties for easy customization.', 'mvweb-price-table' ); ?></p>
				</div>
			</details>

			<details class="mvweb-details">
				<summary><?php esc_html_e( 'Is user data collected?', 'mvweb-price-table' ); ?></summary>
				<div class="mvweb-details__body">
					<p><?php esc_html_e( 'If statistics is enabled, we collect anonymous usage data (which brands/models are popular). IP addresses are hashed for privacy and never stored in plain text. You can disable statistics in Settings.', 'mvweb-price-table' ); ?></p>
				</div>
			</details>
		</div>
	</section>

	<!-- Support -->
	<section class="mvweb-help__section">
		<h2 class="mvweb-section-title"><?php esc_html_e( 'Support', 'mvweb-price-table' ); ?></h2>
		<p>
			<?php
			printf(
				/* translators: %s: MVweb URL */
				esc_html__( 'Need help? Visit %s for documentation and support.', 'mvweb-price-table' ),
				'<a href="https://mvweb.ru/plugins/mvweb-price-table" target="_blank">mvweb.ru</a>'
			);
			?>
		</p>
		<p>
			<strong><?php esc_html_e( 'Version:', 'mvweb-price-table' ); ?></strong> <?php echo esc_html( MVWEB_PT_VERSION ); ?>
		</p>
	</section>
</div>
