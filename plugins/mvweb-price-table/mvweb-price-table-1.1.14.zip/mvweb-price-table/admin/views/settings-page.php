<?php
/**
 * Admin settings page template.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get forms.
$forms    = mvweb_pt_get_forms();
$settings = get_option( 'mvweb_pt_settings', array() );
$presets  = mvweb_pt_get_presets();
?>

<div class="wrap mvweb-settings mvweb-settings--wide mvweb-pc-admin">
	<h1><?php esc_html_e( 'MVweb Price Table', 'mvweb-price-table' ); ?></h1>

	<nav class="nav-tab-wrapper mvweb-pc-tabs">
		<a href="#forms" class="nav-tab nav-tab-active" data-tab="forms">
			<?php esc_html_e( 'Forms', 'mvweb-price-table' ); ?>
		</a>
		<a href="#settings" class="nav-tab" data-tab="settings">
			<?php esc_html_e( 'Settings', 'mvweb-price-table' ); ?>
		</a>
		<a href="#appearance" class="nav-tab" data-tab="appearance">
			<?php esc_html_e( 'Appearance', 'mvweb-price-table' ); ?>
		</a>
		<a href="#statistics" class="nav-tab" data-tab="statistics">
			<?php esc_html_e( 'Statistics', 'mvweb-price-table' ); ?>
		</a>
		<a href="#help" class="nav-tab" data-tab="help">
			<?php esc_html_e( 'Help', 'mvweb-price-table' ); ?>
		</a>
	</nav>

	<!-- Forms Tab -->
	<div id="forms" class="mvweb-pc-tab-content active">
		<?php include MVWEB_PT_PATH . 'admin/views/tab-forms.php'; ?>
	</div>

	<!-- Settings and Appearance Tabs share the same form -->
	<form id="mvweb-pc-settings-form" method="post">
		<?php wp_nonce_field( 'mvweb_pt_save_settings', 'mvweb_pt_settings_nonce' ); ?>

		<!-- Settings Tab -->
		<div id="settings" class="mvweb-pc-tab-content">
			<?php include MVWEB_PT_PATH . 'admin/views/tab-settings.php'; ?>
		</div>

		<!-- Appearance Tab -->
		<div id="appearance" class="mvweb-pc-tab-content">
			<?php include MVWEB_PT_PATH . 'admin/views/tab-appearance.php'; ?>
		</div>

		<p class="submit mvweb-pc-settings-submit">
			<button type="submit" class="mvweb-btn mvweb-btn--primary">
				<?php esc_html_e( 'Save Settings', 'mvweb-price-table' ); ?>
			</button>
			<span class="mvweb-pc-settings-status"></span>
		</p>
	</form>

	<!-- Statistics Tab -->
	<div id="statistics" class="mvweb-pc-tab-content">
		<?php include MVWEB_PT_PATH . 'admin/views/tab-statistics.php'; ?>
	</div>

	<!-- Help Tab -->
	<div id="help" class="mvweb-pc-tab-content">
		<?php include MVWEB_PT_PATH . 'admin/views/tab-help.php'; ?>
	</div>
</div>
