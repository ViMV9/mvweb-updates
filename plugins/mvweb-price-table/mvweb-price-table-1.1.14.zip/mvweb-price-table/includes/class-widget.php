<?php
/**
 * Widget class for MVweb Price Table.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PT_Widget
 *
 * WordPress Widget for displaying price table forms.
 *
 * @since 1.0.0
 */
class MVweb_PT_Widget extends WP_Widget {

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		parent::__construct(
			'mvweb_pt_widget',
			__( 'Price Table', 'mvweb-price-table' ),
			array(
				'description'                 => __( 'Display a price table form.', 'mvweb-price-table' ),
				'customize_selective_refresh' => true,
				'show_instance_in_rest'       => true,
			)
		);
	}

	/**
	 * Output widget content on frontend.
	 *
	 * @since 1.0.0
	 * @param array $args     Widget arguments.
	 * @param array $instance Widget instance settings.
	 * @return void
	 */
	public function widget( $args, $instance ) {
		// Get form ID.
		$form_id = isset( $instance['form_id'] ) ? absint( $instance['form_id'] ) : 0;

		if ( ! $form_id ) {
			return;
		}

		// Check if form is active.
		if ( ! mvweb_pt_is_form_active( $form_id ) ) {
			return;
		}

		// Output widget wrapper.
		echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		// Widget title.
		$title = isset( $instance['title'] ) ? $instance['title'] : '';
		if ( ! empty( $title ) ) {
			echo $args['before_title'] . esc_html( apply_filters( 'widget_title', $title ) ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		// Build calculator args.
		$calc_args = array(
			'show_title' => false, // Title is handled by widget.
			'echo'       => true,
		);

		// Custom preset.
		if ( ! empty( $instance['preset'] ) ) {
			$calc_args['preset'] = sanitize_key( $instance['preset'] );
		}

		// Custom button text.
		if ( ! empty( $instance['button_text'] ) ) {
			$calc_args['button_text'] = sanitize_text_field( $instance['button_text'] );
		}

		// Render calculator.
		mvweb_price_calculator( $form_id, $calc_args );

		echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	/**
	 * Output widget settings form in admin.
	 *
	 * @since 1.0.0
	 * @param array $instance Current settings.
	 * @return void
	 */
	public function form( $instance ) {
		// Defaults.
		$title       = isset( $instance['title'] ) ? $instance['title'] : '';
		$form_id     = isset( $instance['form_id'] ) ? absint( $instance['form_id'] ) : 0;
		$preset      = isset( $instance['preset'] ) ? $instance['preset'] : '';
		$button_text = isset( $instance['button_text'] ) ? $instance['button_text'] : '';

		// Get available forms.
		$forms = mvweb_pt_get_forms();

		// Get available presets.
		$presets = mvweb_pt_get_presets();
		?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>">
				<?php esc_html_e( 'Title:', 'mvweb-price-table' ); ?>
			</label>
			<input
				type="text"
				class="widefat"
				id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>"
				value="<?php echo esc_attr( $title ); ?>"
			>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'form_id' ) ); ?>">
				<?php esc_html_e( 'Select Form:', 'mvweb-price-table' ); ?>
			</label>
			<select
				class="widefat"
				id="<?php echo esc_attr( $this->get_field_id( 'form_id' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'form_id' ) ); ?>"
			>
				<option value=""><?php esc_html_e( '— Select a form —', 'mvweb-price-table' ); ?></option>
				<?php foreach ( $forms as $form ) : ?>
					<option
						value="<?php echo esc_attr( $form['id'] ); ?>"
						<?php selected( $form_id, $form['id'] ); ?>
					>
						<?php
						echo esc_html( $form['name'] );
						if ( 'active' !== $form['status'] ) {
							echo ' (' . esc_html__( 'Inactive', 'mvweb-price-table' ) . ')';
						}
						?>
					</option>
				<?php endforeach; ?>
			</select>
		</p>

		<?php if ( empty( $forms ) ) : ?>
			<p class="description" style="color: #d63638;">
				<?php
				printf(
					/* translators: %s: admin URL */
					esc_html__( 'No forms found. %s to create one.', 'mvweb-price-table' ),
					'<a href="' . esc_url( admin_url( 'admin.php?page=mvweb-price-table#forms' ) ) . '">' . esc_html__( 'Click here', 'mvweb-price-table' ) . '</a>'
				);
				?>
			</p>
		<?php endif; ?>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'preset' ) ); ?>">
				<?php esc_html_e( 'Design Preset:', 'mvweb-price-table' ); ?>
			</label>
			<select
				class="widefat"
				id="<?php echo esc_attr( $this->get_field_id( 'preset' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'preset' ) ); ?>"
			>
				<option value=""><?php esc_html_e( '— Use form default —', 'mvweb-price-table' ); ?></option>
				<?php foreach ( $presets as $key => $label ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $preset, $key ); ?>>
						<?php echo esc_html( $label ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'button_text' ) ); ?>">
				<?php esc_html_e( 'Button Text:', 'mvweb-price-table' ); ?>
			</label>
			<input
				type="text"
				class="widefat"
				id="<?php echo esc_attr( $this->get_field_id( 'button_text' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'button_text' ) ); ?>"
				value="<?php echo esc_attr( $button_text ); ?>"
				placeholder="<?php esc_attr_e( 'Leave empty for default', 'mvweb-price-table' ); ?>"
			>
		</p>

		<?php
	}

	/**
	 * Save widget settings.
	 *
	 * @since 1.0.0
	 * @param array $new_instance New settings.
	 * @param array $old_instance Old settings.
	 * @return array Sanitized settings.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = array();

		$instance['title']       = sanitize_text_field( $new_instance['title'] );
		$instance['form_id']     = absint( $new_instance['form_id'] );
		$instance['preset']      = sanitize_key( $new_instance['preset'] );
		$instance['button_text'] = sanitize_text_field( $new_instance['button_text'] );

		return $instance;
	}
}

/**
 * Register widget.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pt_register_widget() {
	register_widget( 'MVweb_PT_Widget' );
}
add_action( 'widgets_init', 'mvweb_pt_register_widget' );
