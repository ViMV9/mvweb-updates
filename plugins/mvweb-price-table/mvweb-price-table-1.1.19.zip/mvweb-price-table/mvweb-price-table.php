<?php
/**
 * Plugin Name:       MVweb Price Table
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-price-table
 * Description:       Price table with Google Sheets integration for repair services.
 * Version:           1.1.19
 * Requires at least: 6.4
 * Tested up to:      7.1.4
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-price-table
 * Domain Path:       /languages
 *
 * @package MVweb_Price_Table
 *
 * @since 1.0.0 Initial release.
 * @since 1.1.8 Natural sort for selects, "all" mode hierarchy fix, Choices.js z-index fix.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'MVWEB_PT_VERSION' ) ) {
	return;
}

/**
 * Plugin version.
 */
define( 'MVWEB_PT_VERSION', '1.1.19' );

/**
 * Plugin directory path.
 */
define( 'MVWEB_PT_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Plugin directory URL.
 */
define( 'MVWEB_PT_URL', plugin_dir_url( __FILE__ ) );

/**
 * Plugin basename.
 */
define( 'MVWEB_PT_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Load shared MVweb files.
 *
 * Menu class is bundled with each plugin for independent updates.
 * Shared path is used for development environment only.
 */
$shared_path = dirname( dirname( MVWEB_PT_PATH ) ) . '/shared/';

if ( file_exists( MVWEB_PT_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_PT_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-price-table'] = array(
		'name'         => 'MVweb Price Table',
		'description'  => 'Price table with Google Sheets integration for repair services.',
		'url'          => 'https://mvweb.ru/plugins/mvweb-price-table',
		'settings_url' => 'admin.php?page=mvweb-price-table',
		'textdomain'   => 'mvweb-price-table',
	);
	return $plugins;
} );

if ( file_exists( $shared_path . 'helpers.php' ) ) {
	require_once $shared_path . 'helpers.php';
}

/**
 * Initialize plugin updater.
 *
 * Uses JSON metadata from public update server (mvweb-updates repo).
 * Prefers bundled updater class, falls back to shared for development.
 */
if ( file_exists( MVWEB_PT_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_PT_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

$mvweb_pt_updater = null;

if ( class_exists( 'MVweb_Updater' ) ) {
	$mvweb_pt_updater = MVweb_Updater::create( __FILE__, 'mvweb-price-table' );
}

// Load MVweb License.
if ( file_exists( MVWEB_PT_PATH . 'includes/class-mvweb-license.php' ) ) {
	require_once MVWEB_PT_PATH . 'includes/class-mvweb-license.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-license.php' ) ) {
	require_once $shared_path . 'class-mvweb-license.php';
}

if ( class_exists( 'MVweb_License' ) ) {
	MVweb_License::init( 'mvweb-price-table', $mvweb_pt_updater, 'plugin', 'mvweb-price-table' );
}

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pt_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-price-table',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_pt_load_textdomain' );

/**
 * Translate plugin metadata in plugins list.
 *
 * WordPress doesn't automatically translate plugin Name and Description
 * from the plugin header when using local translation files.
 * This filter provides translated strings for the plugins list.
 *
 * @since 1.0.0
 * @param array $plugins Array of plugin data.
 * @return array Modified plugins array.
 */
function mvweb_pt_translate_plugin_meta( $plugins ) {
	$plugin_file = plugin_basename( __FILE__ );

	if ( isset( $plugins[ $plugin_file ] ) ) {
		if ( ! is_textdomain_loaded( 'mvweb-price-table' ) ) {
			load_plugin_textdomain(
				'mvweb-price-table',
				false,
				dirname( $plugin_file ) . '/languages/'
			);
		}

		$plugins[ $plugin_file ]['Name']        = __( 'MVweb Price Table', 'mvweb-price-table' );
		$plugins[ $plugin_file ]['Title']       = __( 'MVweb Price Table', 'mvweb-price-table' );
		$plugins[ $plugin_file ]['Description'] = __( 'Price table with Google Sheets integration for repair services.', 'mvweb-price-table' );
	}

	return $plugins;
}
add_filter( 'all_plugins', 'mvweb_pt_translate_plugin_meta' );

/**
 * Register plugin submenu.
 *
 * Uses MVweb_Menu::MENU_SLUG as parent to attach to the MVweb hub menu.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pt_register_menu() {
	$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

	add_submenu_page(
		$parent_slug,
		__( 'Price Table', 'mvweb-price-table' ),
		__( 'Price Table', 'mvweb-price-table' ),
		'manage_options',
		'mvweb-price-table',
		'mvweb_pt_settings_page'
	);
}
add_action( 'admin_menu', 'mvweb_pt_register_menu' );

/**
 * Plugin settings page callback.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pt_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	include MVWEB_PT_PATH . 'admin/views/settings-page.php';
}

/**
 * Enqueue admin styles and scripts.
 *
 * @since 1.0.0
 * @param string $hook Current admin page hook.
 * @return void
 */
function mvweb_pt_admin_enqueue( $hook ) {
	if ( false === strpos( $hook, 'mvweb-price-table' ) ) {
		return;
	}

	$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

	$script_deps = array( 'jquery' );

	wp_enqueue_style( 'wp-color-picker' );
	$script_deps[] = 'wp-color-picker';

	wp_enqueue_style(
		'mvweb-pt-admin',
		MVWEB_PT_URL . 'admin/css/admin' . $suffix . '.css',
		array(),
		MVWEB_PT_VERSION
	);

	wp_enqueue_style(
		'mvweb-pt-plugin',
		MVWEB_PT_URL . 'admin/css/plugin' . $suffix . '.css',
		array( 'mvweb-pt-admin' ),
		MVWEB_PT_VERSION
	);

	wp_enqueue_script(
		'mvweb-pt-admin',
		MVWEB_PT_URL . 'admin/js/admin' . $suffix . '.js',
		$script_deps,
		MVWEB_PT_VERSION,
		true
	);

	wp_localize_script(
		'mvweb-pt-admin',
		'mvweb_pt_ajax',
		array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'mvweb_pt_ajax' ),
			'i18n'     => array(
				'confirm_delete'      => __( 'Are you sure you want to delete this form?', 'mvweb-price-table' ),
				'confirm_clear_stats' => __( 'Are you sure you want to clear all statistics? This action cannot be undone.', 'mvweb-price-table' ),
				'testing'             => __( 'Testing connection...', 'mvweb-price-table' ),
				'success'             => __( 'Success!', 'mvweb-price-table' ),
				'error'               => __( 'Error', 'mvweb-price-table' ),
				'add_form'            => __( 'Add New Form', 'mvweb-price-table' ),
				'edit_form'           => __( 'Edit Form', 'mvweb-price-table' ),
				'saving'              => __( 'Saving...', 'mvweb-price-table' ),
				'clearing'            => __( 'Clearing...', 'mvweb-price-table' ),
				'exporting'           => __( 'Exporting...', 'mvweb-price-table' ),
				'url_required'        => __( 'Please enter a Google Sheets URL.', 'mvweb-price-table' ),
				'no_forms'            => __( 'No forms created yet. Click "Add New Form" to create your first calculator form.', 'mvweb-price-table' ),
				'no_forms_title'      => __( 'No forms yet', 'mvweb-price-table' ),
				'detecting'           => __( 'Detecting...', 'mvweb-price-table' ),
				'auto_detect'         => __( 'Auto-Detect Columns', 'mvweb-price-table' ),
				'no_columns'          => __( 'Click "Auto-Detect Columns" or add columns manually.', 'mvweb-price-table' ),
				'loading'             => __( 'Loading...', 'mvweb-price-table' ),
				'first_sheet'         => __( 'First sheet (default)', 'mvweb-price-table' ),
				'sheet'               => __( 'Sheet', 'mvweb-price-table' ),
				'column_n'            => __( 'Column %d', 'mvweb-price-table' ),
				'field_role'          => __( 'Role', 'mvweb-price-table' ),
				'field_label'         => __( 'Display Label', 'mvweb-price-table' ),
				'field_format'        => __( 'Format', 'mvweb-price-table' ),
				'field_mobile'        => __( 'Full width on mobile devices', 'mvweb-price-table' ),
				'remove_column'       => __( 'Remove column', 'mvweb-price-table' ),
				'confidence_high'     => __( 'Auto-detection confidence: high', 'mvweb-price-table' ),
				'confidence_medium'   => __( 'Auto-detection confidence: medium', 'mvweb-price-table' ),
				'confidence_low'      => __( 'Auto-detection confidence: low', 'mvweb-price-table' ),
			),
		)
	);

	$forms = mvweb_pt_get_forms();
	wp_localize_script(
		'mvweb-pt-admin',
		'mvwebPcForms',
		$forms ? $forms : array()
	);
	wp_localize_script(
		'mvweb-pt-admin',
		'mvwebPcRoles',
		mvweb_pt_get_valid_roles()
	);
	wp_localize_script(
		'mvweb-pt-admin',
		'mvwebPcFormats',
		mvweb_pt_get_valid_formats()
	);
	wp_localize_script(
		'mvweb-pt-admin',
		'mvwebPcPresets',
		MVweb_PT_Field_Mapper::get_presets()
	);
}
add_action( 'admin_enqueue_scripts', 'mvweb_pt_admin_enqueue' );

/**
 * Plugin activation hook.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pt_activate() {
	if ( false === get_option( 'mvweb_pt_settings' ) ) {
		$default_settings = array(
			'cache_ttl'        => 3600,
			'fallback_enabled' => true,
			'stats_enabled'    => true,
			'default_preset'   => 'light',
			'currency'         => 'RUB',
		);
		add_option( 'mvweb_pt_settings', $default_settings );
	}

	if ( false === get_option( 'mvweb_pt_forms' ) ) {
		add_option( 'mvweb_pt_forms', array(), '', false );
	}

	require_once MVWEB_PT_PATH . 'includes/class-statistics.php';
	MVweb_PT_Statistics::create_table();
	update_option( 'mvweb_pt_stats_table', 1 );

	update_option( 'mvweb_pt_version', MVWEB_PT_VERSION );

	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'mvweb_pt_activate' );

/**
 * Plugin deactivation hook.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pt_deactivate() {
	wp_clear_scheduled_hook( 'mvweb_pt_cache_refresh' );
	wp_clear_scheduled_hook( 'mvweb_pt_stats_cleanup' );

	flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'mvweb_pt_deactivate' );

require_once MVWEB_PT_PATH . 'includes/helpers.php';
require_once MVWEB_PT_PATH . 'includes/class-cache.php';
require_once MVWEB_PT_PATH . 'includes/class-logger.php';
require_once MVWEB_PT_PATH . 'includes/class-field-mapper.php';
require_once MVWEB_PT_PATH . 'includes/class-value-resolver.php';
require_once MVWEB_PT_PATH . 'includes/class-price-resolver.php';
require_once MVWEB_PT_PATH . 'includes/class-google-sheets.php';
require_once MVWEB_PT_PATH . 'includes/class-statistics.php';
require_once MVWEB_PT_PATH . 'includes/class-ajax.php';
require_once MVWEB_PT_PATH . 'includes/class-shortcode.php';
require_once MVWEB_PT_PATH . 'includes/class-widget.php';

/**
 * Register Gutenberg block.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pt_register_block() {
	register_block_type( MVWEB_PT_PATH . 'blocks/price-table' );
}
add_action( 'init', 'mvweb_pt_register_block' );

/**
 * Enqueue block editor assets.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pt_block_editor_assets() {
	$forms       = mvweb_pt_get_forms();
	$forms_array = array();

	foreach ( $forms as $form ) {
		$forms_array[] = array(
			'id'     => $form['id'],
			'name'   => $form['name'],
			'status' => $form['status'],
		);
	}

	wp_set_script_translations( 'mvweb-price-table-editor-script', 'mvweb-price-table', MVWEB_PT_PATH . 'languages' );

	wp_localize_script(
		'mvweb-price-table-editor-script',
		'mvwebPtBlockData',
		array(
			'forms'   => $forms_array,
			'presets' => mvweb_pt_get_presets(),
		)
	);
}
add_action( 'enqueue_block_editor_assets', 'mvweb_pt_block_editor_assets' );

/**
 * Schedule cron events on plugin load.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pt_schedule_cron() {
	if ( ! wp_next_scheduled( 'mvweb_pt_cache_refresh' ) ) {
		wp_schedule_event( time(), 'hourly', 'mvweb_pt_cache_refresh' );
	}

	if ( ! wp_next_scheduled( 'mvweb_pt_stats_cleanup' ) ) {
		wp_schedule_event( time(), 'daily', 'mvweb_pt_stats_cleanup' );
	}
}
add_action( 'init', 'mvweb_pt_schedule_cron' );

/**
 * Handle cache refresh cron job.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pt_cron_cache_refresh() {
	$forms = mvweb_pt_get_forms();
	$cache = new MVweb_PT_Cache();

	foreach ( $forms as $form ) {
		if ( 'active' === $form['status'] && ! empty( $form['spreadsheet_id'] ) ) {
			$cache->refresh_form_cache( $form['id'] );
		}
	}
}
add_action( 'mvweb_pt_cache_refresh', 'mvweb_pt_cron_cache_refresh' );

/**
 * Handle statistics cleanup cron job.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pt_cron_stats_cleanup() {
	$statistics = new MVweb_PT_Statistics();
	$statistics->clear_stats( 'old' );
	MVweb_PT_Logger::cleanup();
}
add_action( 'mvweb_pt_stats_cleanup', 'mvweb_pt_cron_stats_cleanup' );

/**
 * Display admin notice after field mapping migration.
 *
 * Shows success message with backup key for rollback reference.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pt_migration_admin_notice() {
	$screen = get_current_screen();
	if ( ! $screen || ( 'dashboard' !== $screen->id && false === strpos( $screen->id, 'mvweb-price-table' ) ) ) {
		return;
	}

	$notice = get_transient( 'mvweb_pt_migration_notice' );

	if ( ! $notice ) {
		return;
	}

	if ( isset( $_GET['mvweb_pt_dismiss_migration'] ) && '1' === $_GET['mvweb_pt_dismiss_migration'] ) {
		if ( isset( $_GET['_wpnonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ), 'mvweb_pt_dismiss_migration' ) ) {
			delete_transient( 'mvweb_pt_migration_notice' );
		}
		return;
	}

	printf(
		'<div class="notice notice-success is-dismissible"><p>%s</p><p><small>%s <code>%s</code></small></p></div>',
		sprintf(
			/* translators: %d: number of migrated forms */
			esc_html__( 'MVweb Price Table: Successfully migrated %d form(s) to v1.0.0 format.', 'mvweb-price-table' ),
			intval( $notice['migrated'] )
		),
		esc_html__( 'Backup key for rollback:', 'mvweb-price-table' ),
		esc_html( $notice['backup_key'] )
	);
}
add_action( 'admin_notices', 'mvweb_pt_migration_admin_notice' );

/**
 * Run field mapping migration on plugin load if needed.
 *
 * Checks plugin version and migrates forms if upgrading from older format.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_pt_maybe_migrate() {
	if ( ! is_admin() ) {
		return;
	}

	if ( ! mvweb_pt_needs_migration() ) {
		$current_version = get_option( 'mvweb_pt_version', '0.0.0' );
		if ( version_compare( $current_version, '1.0.0', '<' ) ) {
			update_option( 'mvweb_pt_version', '1.0.0' );
		}
		return;
	}

	$result = mvweb_pt_migrate_to_v2();

	if ( $result['success'] ) {
		update_option( 'mvweb_pt_version', '1.0.0' );

		mvweb_pt_cleanup_old_backups( 5 );
	}
}
add_action( 'admin_init', 'mvweb_pt_maybe_migrate', 5 );

/**
 * Create the statistics table on sites where activation did not run it (network activation).
 *
 * @since 1.1.17
 * @return void
 */
function mvweb_pt_maybe_create_stats_table() {
	if ( get_option( 'mvweb_pt_stats_table' ) ) {
		return;
	}

	MVweb_PT_Statistics::create_table();
	update_option( 'mvweb_pt_stats_table', 1 );
}
add_action( 'admin_init', 'mvweb_pt_maybe_create_stats_table' );

/**
 * Remove cache and fallback copies stored under the pre-1.1.17 key format.
 *
 * @since 1.1.17
 * @return void
 */
function mvweb_pt_cleanup_legacy_cache_keys() {
	if ( get_option( 'mvweb_pt_cache_v2' ) ) {
		return;
	}

	$cache = new MVweb_PT_Cache();
	foreach ( mvweb_pt_get_forms() as $form ) {
		if ( ! empty( $form['spreadsheet_id'] ) ) {
			$cache->delete_fallback( 'sheets_' . $form['spreadsheet_id'] );
		}
	}

	update_option( 'mvweb_pt_cache_v2', 1 );
}
add_action( 'admin_init', 'mvweb_pt_cleanup_legacy_cache_keys' );

/**
 * Migrate currency_symbol to currency code.
 *
 * @since 1.1.0
 * @return void
 */
function mvweb_pt_migrate_currency_settings() {
	$settings = get_option( 'mvweb_pt_settings', array() );

	if ( isset( $settings['currency'] ) && ! isset( $settings['currency_symbol'] ) ) {
		return;
	}

	if ( isset( $settings['currency_symbol'] ) && ! isset( $settings['currency'] ) ) {
		$symbol = $settings['currency_symbol'];

		$currencies = mvweb_pt_get_currencies();
		$found_code = 'RUB';

		foreach ( $currencies as $code => $data ) {
			if ( $data['symbol'] === $symbol ) {
				$found_code = $code;
				break;
			}
		}

		$settings['currency'] = $found_code;
		unset( $settings['currency_symbol'] );

		update_option( 'mvweb_pt_settings', $settings, false );
	}
}
add_action( 'admin_init', 'mvweb_pt_migrate_currency_settings' );
