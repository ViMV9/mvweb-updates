/**
 * Admin JavaScript for MVweb Price Table
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

(function($) {
	'use strict';

	var MVwebPcAdmin = {
		fieldMapping: null,
		mappingMode: 'mapped',
		sheetsUrl: null,
		sheetsRequestId: 0,

		getAjaxError: function(xhr) {
			var data = xhr && xhr.responseJSON && xhr.responseJSON.data;
			return (data && data.message) || mvweb_pt_ajax.i18n.error;
		},

		firstSheetOption: function() {
			return $('<option>').val('').text(mvweb_pt_ajax.i18n.first_sheet || 'First sheet (default)');
		},

		resetSheetSelect: function() {
			$('#mvweb-pc-form-sheet').empty().append(this.firstSheetOption());
			$('#mvweb-pc-form-sheet-name').val('');
		},

		placeholderRow: function() {
			return $('<tr class="mvweb-pc-mapping-placeholder">').append(
				$('<td colspan="7">').text(mvweb_pt_ajax.i18n.no_columns || 'Click "Auto-Detect Columns" or add columns manually.')
			);
		},

				setStatus: function($el, message, type) {
			clearTimeout($el.data('statusTimer'));
			$el.removeClass('loading success error').text(message || '');

			if (type) {
				$el.addClass(type);
			}

			if (type === 'success') {
				$el.data('statusTimer', setTimeout(function() {
					$el.text('').removeClass('success');
				}, 3000));
			}
		},

		openStatisticsPage: function(params) {
			var url = new URL(window.location.href);

			url.searchParams.set('tab', 'statistics');
			Object.keys(params || {}).forEach(function(key) {
				if (params[key]) {
					url.searchParams.set(key, params[key]);
				} else {
					url.searchParams.delete(key);
				}
			});
			url.hash = '';

			window.location.href = url.toString();
		},

		init: function() {
			this.initTabs();
			this.initFormModal();
			this.initFormActions();
			this.initSettings();
			this.initCopyShortcode();
			this.initStatistics();
			this.initFieldMapping();
		},

		initTabs: function() {
			var $tabs = $('.mvweb-nav__link');
			var $contents = $('.mvweb-tab-content');
			var self = this;

			$tabs.on('click', function(e) {
				e.preventDefault();

				var $this = $(this);
				var tabId = $this.data('tab');

				if (tabId === 'statistics' && !$('#statistics [data-pc-stats-loaded]').length) {
					self.openStatisticsPage();
					return;
				}

				$tabs.removeClass('mvweb-nav__link--active');
				$this.addClass('mvweb-nav__link--active');

				$contents.removeClass('active');
				$('#' + tabId).addClass('active');

				self.toggleSubmit(tabId);

				if (history.pushState) {
					history.pushState(null, null, '#' + tabId);
				}
			});

			var hash = window.location.hash.substring(1);
			if (hash && $('#' + hash).length) {
				$tabs.filter('[data-tab="' + hash + '"]').trigger('click');
			} else {
				this.toggleSubmit($tabs.filter('.mvweb-nav__link--active').data('tab') || 'forms');
			}
		},

		toggleSubmit: function(tabId) {
			var $submit = $('#mvweb-pc-settings-form .mvweb-submit');
			if (tabId === 'settings' || tabId === 'appearance') {
				$submit.show();
			} else {
				$submit.hide();
			}
		},

		initFormModal: function() {
			var dialog = document.getElementById('mvweb-pc-form-modal');
			var $form = $('#mvweb-pc-form-edit');
			var self = this;

			$('.mvweb-pc-add-form').on('click', function() {
				self.openFormModal();
			});

			if (dialog) {
				var pressedOnBackdrop = false;

				dialog.addEventListener('mousedown', function(e) {
					pressedOnBackdrop = e.target === dialog;
				});

				dialog.addEventListener('click', function(e) {
					var rect = dialog.getBoundingClientRect();
					var outside = e.clientX < rect.left || e.clientX > rect.right || e.clientY < rect.top || e.clientY > rect.bottom;

					if (pressedOnBackdrop && e.target === dialog && outside) {
						dialog.close();
					}

					pressedOnBackdrop = false;
				});
			}

			$(document).on('click', '.mvweb-pc-modal-close, .mvweb-pc-modal-cancel', function() {
				self.closeFormModal();
			});

			$form.on('submit', function(e) {
				e.preventDefault();
				self.saveForm();
			});

			$('.mvweb-pc-test-connection').on('click', function() {
				self.testConnection();
			});
		},

		openFormModal: function(formId) {
			var dialog = document.getElementById('mvweb-pc-form-modal');
			var $title = $(dialog).find('.mvweb-pc-modal-title');
			var self = this;

			$('#mvweb-pc-form-edit')[0].reset();
			$('#mvweb-pc-form-id').val('');
			$('#mvweb-pc-field-mapping').val('');
			$('.mvweb-pc-connection-status').text('').removeClass('loading success error');

			$('#mvweb-pc-mapping-rows').empty().append(self.placeholderRow());
			$('.mvweb-pc-preview-section').prop('hidden', true);
			self.fieldMapping = null;
			self.mappingMode = 'mapped';

			self.sheetsRequestId++;
			self.sheetsUrl = null;
			$('.mvweb-pc-sheet-row').prop('hidden', true);
			$('.mvweb-pc-sheets-status').text('').removeClass('loading success error');
			$('.mvweb-pc-refresh-sheets').prop('disabled', false);
			self.resetSheetSelect();

			if (formId && window.mvwebPcForms && window.mvwebPcForms[formId]) {
				var form = window.mvwebPcForms[formId];
				$title.text(mvweb_pt_ajax.i18n.edit_form || 'Edit Form');
				$('#mvweb-pc-form-id').val(formId);
				$('#mvweb-pc-form-name').val(form.name);
				$('#mvweb-pc-form-url').val(form.spreadsheet_url);
				$('#mvweb-pc-form-preset').val(form.preset);
				$('#mvweb-pc-form-status').val(form.status);

				if (form.spreadsheet_url) {
					var selectedGid = null;
					if (form.sheet_id !== null && form.sheet_id !== undefined && form.sheet_id !== '') {
						selectedGid = form.sheet_id;
						var sheetName = form.sheet_name || mvweb_pt_ajax.i18n.sheet || 'Sheet';
						$('#mvweb-pc-form-sheet').append($('<option>').val(form.sheet_id).text(sheetName).prop('selected', true));
						$('#mvweb-pc-form-sheet-name').val(sheetName);
					}
					self.sheetsUrl = form.spreadsheet_url;
					self.fetchSheets(form.spreadsheet_url, selectedGid);
				}

				if (form.field_mapping) {
					self.mappingMode = form.field_mapping.mode || 'mapped';
					self.fieldMapping = form.field_mapping;
					self.renderMappingTable(form.field_mapping, []);
					self.updateFieldMappingInput();
				}
			} else {
				$title.text(mvweb_pt_ajax.i18n.add_form || 'Add New Form');
			}

			dialog.showModal();
		},

		closeFormModal: function() {
			var dialog = document.getElementById('mvweb-pc-form-modal');
			if (dialog && dialog.open) {
				dialog.close();
			}
		},

		saveForm: function() {
			var self = this;
			var $form = $('#mvweb-pc-form-edit');
			var $submitBtn = $form.find('button[type="submit"]');

			self.updateMappingFromUI();

			var data = {
				action: 'mvweb_pt_save_form',
				nonce: mvweb_pt_ajax.nonce,
				form_id: $('#mvweb-pc-form-id').val(),
				name: $('#mvweb-pc-form-name').val(),
				spreadsheet_url: $('#mvweb-pc-form-url').val(),
				sheet_id: $('#mvweb-pc-form-sheet').val(),
				sheet_name: $('#mvweb-pc-form-sheet option:selected').text(),
				preset: $('#mvweb-pc-form-preset').val(),
				status: $('#mvweb-pc-form-status').val(),
				field_mapping: $('#mvweb-pc-field-mapping').val()
			};

			$submitBtn.prop('disabled', true);

			$.post(mvweb_pt_ajax.ajax_url, data, function(response) {
				if (response.success) {
					window.location.reload();
				} else {
					alert(response.data.message || mvweb_pt_ajax.i18n.error);
				}
			}).fail(function(xhr) {
				alert(MVwebPcAdmin.getAjaxError(xhr));
			}).always(function() {
				$submitBtn.prop('disabled', false);
			});
		},

		testConnection: function() {
			var self = this;
			var $button = $('.mvweb-pc-test-connection');
			var $status = $('.mvweb-pc-connection-status');
			var url = $('#mvweb-pc-form-url').val();

			if (!url) {
				$status.text(mvweb_pt_ajax.i18n.url_required || mvweb_pt_ajax.i18n.error).removeClass('loading success').addClass('error');
				return;
			}

			self.updateMappingFromUI();

			$button.prop('disabled', true);
			$status.text(mvweb_pt_ajax.i18n.testing).removeClass('success error').addClass('loading');

			$.post(mvweb_pt_ajax.ajax_url, {
				action: 'mvweb_pt_test_connection',
				nonce: mvweb_pt_ajax.nonce,
				spreadsheet_url: url,
				sheet_id: $('#mvweb-pc-form-sheet').val(),
				field_mapping: $('#mvweb-pc-field-mapping').val()
			}, function(response) {
				if (response.success) {
					$status.text(response.data.message).removeClass('loading error').addClass('success');
				} else {
					$status.text(response.data.message || mvweb_pt_ajax.i18n.error).removeClass('loading success').addClass('error');
				}
			}).fail(function(xhr) {
				$status.text(MVwebPcAdmin.getAjaxError(xhr)).removeClass('loading success').addClass('error');
			}).always(function() {
				$button.prop('disabled', false);
			});
		},

		currentSheetFor: function(url) {
			return url && url === this.sheetsUrl ? $('#mvweb-pc-form-sheet').val() : null;
		},

		fetchSheets: function(url, selectedGid) {
			var $select = $('#mvweb-pc-form-sheet');
			var $row = $('.mvweb-pc-sheet-row');
			var $status = $('.mvweb-pc-sheets-status');
			var $button = $('.mvweb-pc-refresh-sheets');
			var self = this;
			var requestId = ++self.sheetsRequestId;

			if (!url) {
				self.sheetsUrl = null;
				self.resetSheetSelect();
				$status.text('').removeClass('loading success error');
				$button.prop('disabled', false);
				$row.prop('hidden', true);
				return;
			}

			$button.prop('disabled', true);
			$status.text(mvweb_pt_ajax.i18n.loading || 'Loading...').removeClass('success error').addClass('loading');

			$.post(mvweb_pt_ajax.ajax_url, {
				action: 'mvweb_pt_fetch_sheets',
				nonce: mvweb_pt_ajax.nonce,
				spreadsheet_url: url
			}, function(response) {
				if (requestId !== self.sheetsRequestId) {
					return;
				}

				if (response.success && response.data.sheets) {
					var hasSelected = selectedGid !== null && selectedGid !== undefined && selectedGid !== '';

					$select.empty().append(self.firstSheetOption());

					response.data.sheets.forEach(function(sheet) {
						var $option = $('<option>').val(sheet.gid).text(sheet.name);
						if (hasSelected && String(selectedGid) === String(sheet.gid)) {
							$option.prop('selected', true);
						}
						$select.append($option);
					});

					self.sheetsUrl = url;
					$row.prop('hidden', false);
					$status.text('').removeClass('loading error success');

					$('#mvweb-pc-form-sheet-name').val($select.find('option:selected').text());
				} else {
					$status.text((response.data && response.data.message) || mvweb_pt_ajax.i18n.error).removeClass('loading success').addClass('error');
					$row.prop('hidden', false);
				}
			}).fail(function(xhr) {
				if (requestId !== self.sheetsRequestId) {
					return;
				}
				$status.text(MVwebPcAdmin.getAjaxError(xhr)).removeClass('loading success').addClass('error');
				$row.prop('hidden', false);
			}).always(function() {
				if (requestId === self.sheetsRequestId) {
					$button.prop('disabled', false);
				}
			});
		},

		initFormActions: function() {
			var self = this;

			$(document).on('click', '.mvweb-pc-edit-form', function() {
				var formId = $(this).data('form-id');
				self.openFormModal(formId);
			});

			$(document).on('click', '.mvweb-pc-refresh-sheets', function() {
				var url = $('#mvweb-pc-form-url').val();
				self.fetchSheets(url, self.currentSheetFor(url));
			});

			$(document).on('change', '#mvweb-pc-form-sheet', function() {
				$('#mvweb-pc-form-sheet-name').val($(this).find('option:selected').text());
			});

			var urlFetchTimeout;
			$(document).on('blur', '#mvweb-pc-form-url', function() {
				var url = $(this).val();
				clearTimeout(urlFetchTimeout);
				urlFetchTimeout = setTimeout(function() {
					if (url !== self.sheetsUrl) {
						self.resetSheetSelect();
					}
					self.fetchSheets(url, self.currentSheetFor(url));
				}, 300);
			});

			$(document).on('click', '.mvweb-pc-delete-form', function() {
				var $button = $(this);
				var formId = $button.data('form-id');

				if (!confirm(mvweb_pt_ajax.i18n.confirm_delete)) {
					return;
				}

				$button.prop('disabled', true);

				$.post(mvweb_pt_ajax.ajax_url, {
					action: 'mvweb_pt_delete_form',
					nonce: mvweb_pt_ajax.nonce,
					form_id: formId
				}, function(response) {
					if (response.success) {
						$button.closest('tr').fadeOut(300, function() {
							$(this).remove();

							if ($('.mvweb-pc-forms-table tbody tr').length === 0) {
								$('.mvweb-pc-forms-table').closest('.mvweb-table-wrap').replaceWith(
									$('<div class="mvweb-empty">').append(
										$('<div class="mvweb-empty__title">').text(mvweb_pt_ajax.i18n.no_forms_title || 'No forms yet'),
										$('<p class="mvweb-empty__text">').text(mvweb_pt_ajax.i18n.no_forms || 'No forms created yet. Click "Add New Form" to create your first calculator form.')
									)
								);
							}
						});
					} else {
						alert(response.data.message || mvweb_pt_ajax.i18n.error);
						$button.prop('disabled', false);
					}
				}).fail(function(xhr) {
					alert(MVwebPcAdmin.getAjaxError(xhr));
					$button.prop('disabled', false);
				});
			});
		},

		initSettings: function() {
			var self = this;
			var $form = $('#mvweb-pc-settings-form');
			var $status = $('.mvweb-pc-settings-status');

			if (!$form.length) {
				return;
			}

			$('#currency').on('change', function() {
				var $customWrapper = $('#custom-currency-wrapper');
				if ($(this).val() === 'CUSTOM') {
					$customWrapper.slideDown(200);
					$('#custom_currency').trigger('focus');
				} else {
					$customWrapper.slideUp(200);
				}
			});

			var settingsDirty = false;

			$form.on('input', '.mvweb-pc-color-input', function() {
				$(this).siblings('.mvweb-color-picker__value').text(this.value);
			});

			$form.on('click', '.mvweb-pc-color-reset', function() {
				var $input = $(this).siblings('.mvweb-pc-color-input');

				$input.val($input.data('default')).trigger('input');
			});

			$form.on('input change', function() {
				settingsDirty = true;
			});

			$(window).on('beforeunload', function(e) {
				if (settingsDirty) {
					e.preventDefault();
					e.returnValue = '';
				}
			});

			$form.on('submit', function(e) {
				e.preventDefault();

				var $submitBtn = $form.find('button[type="submit"]');
				$submitBtn.prop('disabled', true);
				self.setStatus($status, mvweb_pt_ajax.i18n.saving || 'Saving...', 'loading');

				var data = {
					action: 'mvweb_pt_save_settings',
					nonce: mvweb_pt_ajax.nonce,
					cache_ttl: $('#cache_ttl').val(),
					fallback_enabled: $('input[name="fallback_enabled"]').is(':checked') ? '1' : '0',
					stats_enabled: $('input[name="stats_enabled"]').is(':checked') ? '1' : '0',
					default_preset: $('#default_preset').val(),
					currency: $('#currency').val(),
					custom_currency: $('#custom_currency').val(),
					keep_data_on_uninstall: $('input[name="keep_data_on_uninstall"]').is(':checked') ? '1' : '0',
					default_title: $('#default_title').val(),
					default_description: $('#default_description').val(),
					footer_text: $('#footer_text').val(),
					default_button_text: $('#default_button_text').val(),
					service_column_label: $('#service_column_label').val(),
					time_column_label: $('#time_column_label').val(),
					price_column_label: $('#price_column_label').val(),
					on_request_text: $('#on_request_text').val(),
					custom_css: $('#custom_css').val(),
					light_button_color: $('#light_button_color').val(),
					light_th_color: $('#light_th_color').val(),
					light_price_color: $('#light_price_color').val()
				};

				$.post(mvweb_pt_ajax.ajax_url, data, function(response) {
					if (response.success) {
						settingsDirty = false;
						self.setStatus($status, response.data.message || mvweb_pt_ajax.i18n.success, 'success');
						$('#mvweb-pc-form-preset option').each(function() {
							this.defaultSelected = this.value === data.default_preset;
						});
					} else {
						self.setStatus($status, (response.data && response.data.message) || mvweb_pt_ajax.i18n.error, 'error');
					}
				}).fail(function(xhr) {
					self.setStatus($status, MVwebPcAdmin.getAjaxError(xhr), 'error');
				}).always(function() {
					$submitBtn.prop('disabled', false);
				});
			});

			$('.mvweb-pc-clear-cache').on('click', function() {
				var $button = $(this);
				var $cacheStatus = $('.mvweb-pc-cache-status');

				$button.prop('disabled', true);
				self.setStatus($cacheStatus, mvweb_pt_ajax.i18n.clearing, 'loading');

				$.post(mvweb_pt_ajax.ajax_url, {
					action: 'mvweb_pt_clear_cache',
					nonce: mvweb_pt_ajax.nonce
				}, function(response) {
					if (response.success) {
						self.setStatus($cacheStatus, response.data.message || mvweb_pt_ajax.i18n.success, 'success');
					} else {
						self.setStatus($cacheStatus, (response.data && response.data.message) || mvweb_pt_ajax.i18n.error, 'error');
					}
				}).fail(function(xhr) {
					self.setStatus($cacheStatus, MVwebPcAdmin.getAjaxError(xhr), 'error');
				}).always(function() {
					$button.prop('disabled', false);
				});
			});
		},

		initCopyShortcode: function() {
			var markCopied = function($button) {
				$button.addClass('is-copied');
				setTimeout(function() {
					$button.removeClass('is-copied');
				}, 1500);
			};

			$(document).on('click', '.mvweb-pc-copy-shortcode', function() {
				var $button = $(this);
				var shortcode = $button.siblings('.mvweb-pc-shortcode').text();

				if (navigator.clipboard) {
					navigator.clipboard.writeText(shortcode).then(function() {
						markCopied($button);
					});
				} else {
					var $temp = $('<textarea>');
					$('body').append($temp);
					$temp.val(shortcode).select();
					document.execCommand('copy');
					$temp.remove();
					markCopied($button);
				}
			});
		},

		initStatistics: function() {
			var self = this;

			$(document).on('change', '.mvweb-pc-stats-filter', function() {
				self.openStatisticsPage({
					period: $('#mvweb-pc-stats-period').val(),
					form_id: $('#mvweb-pc-stats-form').val()
				});
			});

			$(document).on('click', '.mvweb-pc-export-stats', function() {
				var $button = $(this);
				var period = $('#mvweb-pc-stats-period').val() || $button.data('period') || 'month';
				var formId = $('#mvweb-pc-stats-form').val() || $button.data('form') || '';

				$button.prop('disabled', true);

				$.post(mvweb_pt_ajax.ajax_url, {
					action: 'mvweb_pt_export_stats',
					nonce: mvweb_pt_ajax.nonce,
					period: period,
					form_id: formId
				}, function(response) {
					if (response.success) {
						self.downloadCSV(response.data.csv, response.data.filename);
					} else {
						alert(response.data.message || mvweb_pt_ajax.i18n.error);
					}
				}).fail(function(xhr) {
					alert(MVwebPcAdmin.getAjaxError(xhr));
				}).always(function() {
					$button.prop('disabled', false);
				});
			});

			$(document).on('click', '.mvweb-pc-clear-stats', function() {
				var $button = $(this);

				if (!confirm(mvweb_pt_ajax.i18n.confirm_clear_stats || 'Are you sure you want to clear all statistics?')) {
					return;
				}

				$button.prop('disabled', true);

				$.post(mvweb_pt_ajax.ajax_url, {
					action: 'mvweb_pt_clear_stats',
					nonce: mvweb_pt_ajax.nonce,
					period: 'all'
				}, function(response) {
					if (response.success) {
						alert(response.data.message);
						window.location.reload();
					} else {
						alert(response.data.message || mvweb_pt_ajax.i18n.error);
					}
				}).fail(function(xhr) {
					alert(MVwebPcAdmin.getAjaxError(xhr));
				}).always(function() {
					$button.prop('disabled', false);
				});
			});

			$(document).on('click', '.nav-tab-link', function(e) {
				e.preventDefault();
				var tabId = $(this).data('tab');
				$('.mvweb-nav__link[data-tab="' + tabId + '"]').trigger('click');
			});
		},

		downloadCSV: function(csv, filename) {
			var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
			var link = document.createElement('a');

			if (navigator.msSaveBlob) {
				navigator.msSaveBlob(blob, filename);
			} else {
				var url = URL.createObjectURL(blob);
				link.setAttribute('href', url);
				link.setAttribute('download', filename);
				link.style.visibility = 'hidden';
				document.body.appendChild(link);
				link.click();
				document.body.removeChild(link);
			}
		},

		initFieldMapping: function() {
			var self = this;

			$(document).on('click', '.mvweb-pc-auto-detect', function() {
				self.autoDetectMapping();
			});

			$(document).on('click', '.mvweb-pc-add-column', function() {
				self.addMappingColumn();
			});

			$(document).on('click', '.mvweb-pc-remove-column', function() {
				$(this).closest('tr').remove();
				self.mappingMode = 'mapped';
				self.updateMappingFromUI();
			});

			$(document).on('click', '.mvweb-pc-preset-btn', function() {
				var presetId = $(this).data('preset');
				self.applyMappingPreset(presetId);
			});

			$(document).on('change', '.mvweb-pc-mapping-table select, .mvweb-pc-mapping-table input', function() {
				self.mappingMode = 'mapped';
				self.updateMappingFromUI();
			});

			$(document).on('click', '.mvweb-pc-mobile-checkbox', function() {
				self.mappingMode = 'mapped';
				self.updateMappingFromUI();
			});

			
		},

		autoDetectMapping: function() {
			var self = this;
			var $button = $('.mvweb-pc-auto-detect');
			var url = $('#mvweb-pc-form-url').val();

			if (!url) {
				alert(mvweb_pt_ajax.i18n.url_required || 'Please enter Google Sheets URL first.');
				return;
			}

			$button.prop('disabled', true).text(mvweb_pt_ajax.i18n.detecting || 'Detecting...');

			var sheetId = $('#mvweb-pc-form-sheet').val();

			$.post(mvweb_pt_ajax.ajax_url, {
				action: 'mvweb_pt_auto_detect_mapping',
				nonce: mvweb_pt_ajax.nonce,
				spreadsheet_url: url,
				sheet_id: sheetId
			}, function(response) {
				if (response.success) {
					self.mappingMode = 'mapped';
					self.fieldMapping = response.data.mapping;
					self.renderMappingTable(response.data.mapping, response.data.headers);
					self.fetchPreview(url, sheetId);
				} else {
					alert(response.data.message || mvweb_pt_ajax.i18n.error);
				}
			}).fail(function(xhr) {
				alert(MVwebPcAdmin.getAjaxError(xhr));
			}).always(function() {
				$button.prop('disabled', false).empty().append(
					$('<span class="dashicons dashicons-search"></span>'),
					document.createTextNode(' ' + (mvweb_pt_ajax.i18n.auto_detect || 'Auto-Detect Columns'))
				);
			});
		},

		fetchPreview: function(url, sheetId) {
			var self = this;
			var $status = $('.mvweb-pc-connection-status');
			var showError = function(message) {
				$('.mvweb-pc-preview-section').prop('hidden', true);
				$status.text(message).removeClass('loading success').addClass('error');
			};

			$status.text('').removeClass('loading success error');

			$.post(mvweb_pt_ajax.ajax_url, {
				action: 'mvweb_pt_fetch_preview',
				nonce: mvweb_pt_ajax.nonce,
				spreadsheet_url: url,
				sheet_id: sheetId || '',
				limit: 20
			}, function(response) {
				if (response.success) {
					self.renderPreviewTable(response.data.headers, response.data.rows);
					$('.mvweb-pc-preview-section').prop('hidden', false);
				} else {
					showError((response.data && response.data.message) || mvweb_pt_ajax.i18n.error);
				}
			}).fail(function(xhr) {
				showError(MVwebPcAdmin.getAjaxError(xhr));
			});
		},

		renderMappingTable: function(mapping, headers) {
			var self = this;
			var $tbody = $('#mvweb-pc-mapping-rows');
			$tbody.empty();

			if (!mapping || !mapping.columns || mapping.columns.length === 0) {
				$tbody.append(self.placeholderRow());
				return;
			}

			mapping.columns.forEach(function(column, index) {
				var header = headers && headers[column.index] ? headers[column.index] : '';
				var confidence = column.confidence;
				var confidenceClass = typeof confidence !== 'number' ? '' : (confidence >= 70 ? 'high' : (confidence >= 40 ? 'medium' : 'low'));
				var fullWidthMobile = column.full_width_mobile || false;

				var $row = self.createMappingRow(column.index, header, column.role, column.label, column.format, confidenceClass, fullWidthMobile);
				$tbody.append($row);
			});

			

			self.updateFieldMappingInput();
		},

		createMappingRow: function(index, header, role, label, format, confidenceClass, fullWidthMobile) {
			var roles = window.mvwebPcRoles || {};
			var formats = window.mvwebPcFormats || {};
			var i18n = mvweb_pt_ajax.i18n;
			var self = this;

			var roleOptions = '';
			for (var roleKey in roles) {
				var selected = roleKey === role ? ' selected' : '';
				roleOptions += '<option value="' + this.escapeHtml(roleKey) + '"' + selected + '>' + this.escapeHtml(roles[roleKey]) + '</option>';
			}

			var formatOptions = '';
			for (var formatKey in formats) {
				var fmtSelected = formatKey === format ? ' selected' : '';
				formatOptions += '<option value="' + this.escapeHtml(formatKey) + '"' + fmtSelected + '>' + this.escapeHtml(formats[formatKey]) + '</option>';
			}

			index = parseInt(index, 10) || 0;

			var columnName = header || (i18n.column_n || 'Column %d').replace('%d', index + 1);
			var fieldName = function(key, fallback) {
				return self.escapeHtml(columnName + ': ' + (i18n[key] || fallback));
			};

			var confidenceLabels = {
				high: i18n.confidence_high || 'Auto-detection confidence: high',
				medium: i18n.confidence_medium || 'Auto-detection confidence: medium',
				low: i18n.confidence_low || 'Auto-detection confidence: low'
			};
			var confidenceIndicator = confidenceClass ? '<span class="mvweb-pc-confidence mvweb-pc-confidence--' + confidenceClass + '" title="' + this.escapeHtml(confidenceLabels[confidenceClass]) + '"><span class="screen-reader-text">' + this.escapeHtml(confidenceLabels[confidenceClass]) + '</span></span>' : '';
			var mobileChecked = fullWidthMobile ? ' checked' : '';
			var removeText = this.escapeHtml(i18n.remove_column || 'Remove column');
			var mobileText = this.escapeHtml(i18n.field_mobile || 'Full width on mobile devices');

			var html = '<tr data-index="' + index + '">' +
				'<td class="column-index"><span class="mvweb-pc-col-index">' + (index + 1) + '</span></td>' +
				'<td class="column-header"><span class="header-detected">' + confidenceIndicator + '<span>' + this.escapeHtml(header || '-') + '</span></span></td>' +
				'<td class="column-role"><select class="mvweb-select mvweb-pc-role-select" aria-label="' + fieldName('field_role', 'Role') + '">' + roleOptions + '</select></td>' +
				'<td class="column-label"><input type="text" class="mvweb-input mvweb-pc-label-input" aria-label="' + fieldName('field_label', 'Display Label') + '" value="' + this.escapeHtml(label || '') + '" placeholder="' + this.escapeHtml(header || i18n.field_label || 'Display Label') + '"></td>' +
				'<td class="column-format"><select class="mvweb-select mvweb-pc-format-select" aria-label="' + fieldName('field_format', 'Format') + '">' + formatOptions + '</select></td>' +
				'<td class="column-mobile"><input type="checkbox" class="mvweb-pc-mobile-checkbox" aria-label="' + this.escapeHtml(columnName + ': ') + mobileText + '" title="' + mobileText + '"' + mobileChecked + '></td>' +
				'<td class="column-remove"><button type="button" class="mvweb-pc-remove-column" title="' + removeText + '"><svg class="mvweb-pc-icon" aria-hidden="true" focusable="false" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2m3 0v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M10 11v6M14 11v6"/></svg><span class="screen-reader-text">' + removeText + '</span></button></td>' +
				'</tr>';

			return $(html);
		},

		addMappingColumn: function() {
			var $tbody = $('#mvweb-pc-mapping-rows');
			var $placeholder = $tbody.find('.mvweb-pc-mapping-placeholder');

			if ($placeholder.length) {
				$placeholder.remove();
			}

			var maxIndex = -1;
			$tbody.find('tr[data-index]').each(function() {
				var idx = parseInt($(this).data('index'), 10);
				if (idx > maxIndex) {
					maxIndex = idx;
				}
			});

			var newIndex = maxIndex + 1;
			var $row = this.createMappingRow(newIndex, '', 'ignore', '', 'text', '', false);
			$tbody.append($row);

			this.updateMappingFromUI();
		},

		applyMappingPreset: function(presetId) {
			var presets = window.mvwebPcPresets || {};
			if (!presets[presetId]) {
				return;
			}

			this.fieldMapping = presets[presetId].mapping;
			this.mappingMode = (this.fieldMapping && this.fieldMapping.mode) || 'mapped';
			this.renderMappingTable(this.fieldMapping, []);
		},

		updateMappingFromUI: function() {
			var self = this;
			var columns = [];

			$('#mvweb-pc-mapping-rows tr[data-index]').each(function() {
				var $row = $(this);
				columns.push({
					index: parseInt($row.data('index'), 10),
					role: $row.find('.mvweb-pc-role-select').val(),
					label: $row.find('.mvweb-pc-label-input').val(),
					format: $row.find('.mvweb-pc-format-select').val(),
					full_width_mobile: $row.find('.mvweb-pc-mobile-checkbox').is(':checked')
				});
			});

			self.fieldMapping = {
				schema_version: '2.0',
				mode: columns.length > 0 ? self.mappingMode : 'legacy',
				columns: columns
			};

			self.updateFieldMappingInput();
		},

		updateFieldMappingInput: function() {
			$('#mvweb-pc-field-mapping').val(JSON.stringify(this.fieldMapping));
		},

		renderPreviewTable: function(headers, rows) {
			var $thead = $('#mvweb-pc-preview-headers');
			var $tbody = $('#mvweb-pc-preview-rows');

			$thead.empty();
			$tbody.empty();

			var headerHtml = '<tr>';
			headers.forEach(function(header, index) {
				headerHtml += '<th>' + (index + 1) + '. ' + MVwebPcAdmin.escapeHtml(header || '-') + '</th>';
			});
			headerHtml += '</tr>';
			$thead.html(headerHtml);

			rows.forEach(function(row) {
				var rowHtml = '<tr>';
				row.forEach(function(cell) {
					rowHtml += '<td title="' + MVwebPcAdmin.escapeHtml(cell || '') + '">' + MVwebPcAdmin.escapeHtml(cell || '-') + '</td>';
				});
				rowHtml += '</tr>';
				$tbody.append(rowHtml);
			});
		},

		escapeHtml: function(text) {
			if (!text) return '';
			return String(text)
				.replace(/&/g, '&amp;')
				.replace(/</g, '&lt;')
				.replace(/>/g, '&gt;')
				.replace(/"/g, '&quot;')
				.replace(/'/g, '&#39;');
		}
	};

	$(document).ready(function() {
		MVwebPcAdmin.init();
	});

})(jQuery);
