<?php
/**
 * Server-side rendering for the Price Table block.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 *
 * @var array    $attributes Block attributes.
 * @var string   $content    Block content.
 * @var WP_Block $block      Block instance.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get form ID from attributes.
$form_id = isset( $attributes['formId'] ) ? absint( $attributes['formId'] ) : 0;

if ( ! $form_id ) {
	return;
}

// Build args from block attributes.
$args = array(
	'show_title' => isset( $attributes['showTitle'] ) ? (bool) $attributes['showTitle'] : true,
	'echo'       => false,
);

// Custom preset.
if ( ! empty( $attributes['preset'] ) ) {
	$args['preset'] = sanitize_key( $attributes['preset'] );
}

// Custom title.
if ( ! empty( $attributes['customTitle'] ) ) {
	$args['title'] = sanitize_text_field( $attributes['customTitle'] );
}

// Custom description.
if ( ! empty( $attributes['customDescription'] ) ) {
	$args['description'] = sanitize_text_field( $attributes['customDescription'] );
}

// Custom button text.
if ( ! empty( $attributes['customButtonText'] ) ) {
	$args['button_text'] = sanitize_text_field( $attributes['customButtonText'] );
}

// Add custom class from block.
if ( ! empty( $attributes['className'] ) ) {
	$args['class'] = sanitize_html_class( $attributes['className'] );
}

// Render the calculator.
$output = mvweb_price_calculator( $form_id, $args );

if ( empty( $output ) ) {
	return;
}

// Get wrapper attributes with alignment support.
$wrapper_attributes = get_block_wrapper_attributes();

printf(
	'<div %s>%s</div>',
	$wrapper_attributes,
	$output // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Output is escaped in mvweb_price_calculator().
);
