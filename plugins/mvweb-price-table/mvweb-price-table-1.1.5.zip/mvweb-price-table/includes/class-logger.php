<?php
/**
 * Logger class for MVweb Price Table.
 *
 * @package MVweb_Price_Table
 * @since   1.1.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PT_Logger
 *
 * Handles error logging with automatic 7-day retention.
 *
 * @since 1.1.0
 */
class MVweb_PT_Logger {

	/**
	 * Option name for storing logs.
	 *
	 * @var string
	 */
	const OPTION_NAME = 'mvweb_pt_logs';

	/**
	 * Maximum log retention in days.
	 *
	 * @var int
	 */
	const RETENTION_DAYS = 7;

	/**
	 * Maximum number of log entries.
	 *
	 * @var int
	 */
	const MAX_ENTRIES = 500;

	/**
	 * Log levels.
	 *
	 * @var array
	 */
	const LEVELS = array(
		'error'   => 0,
		'warning' => 1,
		'info'    => 2,
	);

	/**
	 * Log an error message.
	 *
	 * @since 1.1.0
	 * @param string $message  Log message.
	 * @param string $context  Context (e.g., 'ajax', 'sheets', 'cache').
	 * @param array  $data     Additional data.
	 * @return void
	 */
	public static function error( $message, $context = 'general', $data = array() ) {
		self::log( 'error', $message, $context, $data );
	}

	/**
	 * Log a warning message.
	 *
	 * @since 1.1.0
	 * @param string $message  Log message.
	 * @param string $context  Context.
	 * @param array  $data     Additional data.
	 * @return void
	 */
	public static function warning( $message, $context = 'general', $data = array() ) {
		self::log( 'warning', $message, $context, $data );
	}

	/**
	 * Log an info message.
	 *
	 * @since 1.1.0
	 * @param string $message  Log message.
	 * @param string $context  Context.
	 * @param array  $data     Additional data.
	 * @return void
	 */
	public static function info( $message, $context = 'general', $data = array() ) {
		self::log( 'info', $message, $context, $data );
	}

	/**
	 * Log a message.
	 *
	 * @since 1.1.0
	 * @param string $level    Log level.
	 * @param string $message  Log message.
	 * @param string $context  Context.
	 * @param array  $data     Additional data.
	 * @return void
	 */
	private static function log( $level, $message, $context, $data ) {
		$logs = get_option( self::OPTION_NAME, array() );

		$entry = array(
			'time'    => current_time( 'mysql' ),
			'ts'      => time(),
			'level'   => $level,
			'context' => $context,
			'message' => $message,
		);

		if ( ! empty( $data ) ) {
			$entry['data'] = $data;
		}

		// Add request info for errors.
		if ( 'error' === $level ) {
			$entry['request'] = array(
				'url'    => isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '',
				'method' => isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : '',
				'ip'     => self::get_client_ip(),
			);
		}

		array_unshift( $logs, $entry );

		// Limit entries.
		if ( count( $logs ) > self::MAX_ENTRIES ) {
			$logs = array_slice( $logs, 0, self::MAX_ENTRIES );
		}

		update_option( self::OPTION_NAME, $logs, false );
	}

	/**
	 * Get client IP address.
	 *
	 * @since 1.1.0
	 * @return string
	 */
	private static function get_client_ip() {
		$ip = '';

		if ( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['HTTP_CLIENT_IP'] ) );
		} elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ips = explode( ',', sanitize_text_field( wp_unslash( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) );
			$ip  = trim( $ips[0] );
		} elseif ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
			$ip = sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) );
		}

		return $ip;
	}

	/**
	 * Get logs.
	 *
	 * @since 1.1.0
	 * @param string $level   Filter by level (optional).
	 * @param string $context Filter by context (optional).
	 * @param int    $limit   Number of entries to return.
	 * @return array
	 */
	public static function get_logs( $level = '', $context = '', $limit = 100 ) {
		$logs = get_option( self::OPTION_NAME, array() );

		// Filter by level.
		if ( ! empty( $level ) ) {
			$logs = array_filter(
				$logs,
				function ( $entry ) use ( $level ) {
					return $entry['level'] === $level;
				}
			);
		}

		// Filter by context.
		if ( ! empty( $context ) ) {
			$logs = array_filter(
				$logs,
				function ( $entry ) use ( $context ) {
					return $entry['context'] === $context;
				}
			);
		}

		return array_slice( array_values( $logs ), 0, $limit );
	}

	/**
	 * Clear all logs.
	 *
	 * @since 1.1.0
	 * @return bool
	 */
	public static function clear_logs() {
		return delete_option( self::OPTION_NAME );
	}

	/**
	 * Cleanup old logs (older than retention period).
	 *
	 * @since 1.1.0
	 * @return int Number of entries removed.
	 */
	public static function cleanup() {
		$logs     = get_option( self::OPTION_NAME, array() );
		$cutoff   = time() - ( self::RETENTION_DAYS * DAY_IN_SECONDS );
		$original = count( $logs );

		$logs = array_filter(
			$logs,
			function ( $entry ) use ( $cutoff ) {
				return isset( $entry['ts'] ) && $entry['ts'] > $cutoff;
			}
		);

		$removed = $original - count( $logs );

		if ( $removed > 0 ) {
			update_option( self::OPTION_NAME, array_values( $logs ), false );
		}

		return $removed;
	}

	/**
	 * Get log statistics.
	 *
	 * @since 1.1.0
	 * @return array
	 */
	public static function get_stats() {
		$logs = get_option( self::OPTION_NAME, array() );

		$stats = array(
			'total'    => count( $logs ),
			'by_level' => array(
				'error'   => 0,
				'warning' => 0,
				'info'    => 0,
			),
			'oldest'   => '',
			'newest'   => '',
		);

		foreach ( $logs as $entry ) {
			if ( isset( $entry['level'] ) && isset( $stats['by_level'][ $entry['level'] ] ) ) {
				++$stats['by_level'][ $entry['level'] ];
			}
		}

		if ( ! empty( $logs ) ) {
			$stats['newest'] = $logs[0]['time'] ?? '';
			$stats['oldest'] = end( $logs )['time'] ?? '';
		}

		return $stats;
	}
}
