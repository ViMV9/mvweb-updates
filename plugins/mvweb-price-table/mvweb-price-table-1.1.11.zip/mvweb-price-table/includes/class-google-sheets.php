<?php
/**
 * Google Sheets API integration.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PT_Google_Sheets
 *
 * Handles fetching and parsing data from public Google Sheets.
 *
 * @since 1.0.0
 */
class MVweb_PT_Google_Sheets {

	/**
	 * Google Sheets public JSON API base URL.
	 *
	 * @var string
	 */
	const API_BASE_URL = 'https://docs.google.com/spreadsheets/d/%s/gviz/tq?tqx=out:json&headers=1';

	/**
	 * Cache instance.
	 *
	 * @var MVweb_PT_Cache
	 */
	private $cache;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->cache = new MVweb_PT_Cache();
	}

	/**
	 * Extract spreadsheet ID from URL.
	 *
	 * @since 1.0.0
	 * @param string $url Google Sheets URL.
	 * @return string|false Spreadsheet ID or false if invalid.
	 */
	public function extract_spreadsheet_id( $url ) {
		// Pattern: /spreadsheets/d/{spreadsheet_id}/
		if ( preg_match( '/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/', $url, $matches ) ) {
			return $matches[1];
		}

		// Check if it's already an ID (no slashes).
		if ( preg_match( '/^[a-zA-Z0-9-_]+$/', $url ) ) {
			return $url;
		}

		return false;
	}

	/**
	 * Flag to indicate data is from fallback.
	 *
	 * @var bool
	 */
	private $is_using_fallback = false;

	/**
	 * Fallback error message.
	 *
	 * @var string
	 */
	private $fallback_error = '';

	/**
	 * Check if last fetch used fallback data.
	 *
	 * @since 1.0.0
	 * @return bool True if fallback was used.
	 */
	public function is_using_fallback() {
		return $this->is_using_fallback;
	}

	/**
	 * Get last fallback error message.
	 *
	 * @since 1.0.0
	 * @return string Error message.
	 */
	public function get_fallback_error() {
		return $this->fallback_error;
	}

	/**
	 * Fetch data from Google Sheets.
	 *
	 * @since 1.0.0
	 * @param string $spreadsheet_id Spreadsheet ID.
	 * @param bool   $use_cache      Whether to use cache.
	 * @return array|WP_Error Parsed data or error.
	 */
	public function fetch_data( $spreadsheet_id, $use_cache = true ) {
		$cache_key = 'sheets_' . $spreadsheet_id;

		// Reset fallback flag.
		$this->is_using_fallback = false;
		$this->fallback_error    = '';

		// Try to get from cache first.
		if ( $use_cache ) {
			$cached = $this->cache->get( $cache_key );
			if ( false !== $cached ) {
				return $cached;
			}
		}

		// Build API URL.
		$url = sprintf( self::API_BASE_URL, $spreadsheet_id );

		// Make request.
		$response = wp_remote_get(
			$url,
			array(
				'timeout'    => 15,
				'user-agent' => 'MVweb Price Table/' . MVWEB_PT_VERSION,
			)
		);

		// Check for errors.
		if ( is_wp_error( $response ) ) {
			$error_message = $response->get_error_message();
			$this->cache->log_error( $spreadsheet_id, 'Network error: ' . $error_message );

			// Try to return fallback data.
			$fallback = $this->cache->get_fallback( $cache_key );
			if ( false !== $fallback ) {
				$this->is_using_fallback = true;
				$this->fallback_error    = $error_message;
				return $fallback;
			}
			return $response;
		}

		// Check response code.
		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			$error_message = sprintf(
				/* translators: %d: HTTP status code */
				__( 'HTTP error: %d', 'mvweb-price-table' ),
				$code
			);
			$this->cache->log_error( $spreadsheet_id, $error_message );

			$fallback = $this->cache->get_fallback( $cache_key );
			if ( false !== $fallback ) {
				$this->is_using_fallback = true;
				$this->fallback_error    = $error_message;
				return $fallback;
			}
			return new WP_Error(
				'http_error',
				sprintf(
					/* translators: %d: HTTP status code */
					__( 'Google Sheets returned HTTP error: %d', 'mvweb-price-table' ),
					$code
				)
			);
		}

		// Get body.
		$body = wp_remote_retrieve_body( $response );

		// Parse response.
		$parsed = $this->parse_response( $body );
		if ( is_wp_error( $parsed ) ) {
			$error_message = $parsed->get_error_message();
			$this->cache->log_error( $spreadsheet_id, 'Parse error: ' . $error_message );

			$fallback = $this->cache->get_fallback( $cache_key );
			if ( false !== $fallback ) {
				$this->is_using_fallback = true;
				$this->fallback_error    = $error_message;
				return $fallback;
			}
			return $parsed;
		}

		// Save to cache.
		$settings = get_option( 'mvweb_pt_settings', array() );
		$ttl      = isset( $settings['cache_ttl'] ) ? absint( $settings['cache_ttl'] ) : 3600;
		$this->cache->set( $cache_key, $parsed, $ttl );

		// Save as fallback.
		$this->cache->set_fallback( $cache_key, $parsed );

		return $parsed;
	}

	/**
	 * Parse Google Sheets JSON response.
	 *
	 * @since 1.0.0
	 * @param string $body Response body.
	 * @return array|WP_Error Parsed data or error.
	 */
	public function parse_response( $body ) {
		// Remove JSONP wrapper: google.visualization.Query.setResponse({...});
		$json = preg_replace( '/^[^(]+\(|\);?$/', '', $body );

		// Decode JSON.
		$data = json_decode( $json, true );
		if ( null === $data || ! isset( $data['table'] ) ) {
			return new WP_Error(
				'parse_error',
				__( 'Failed to parse Google Sheets response.', 'mvweb-price-table' )
			);
		}

		// Extract table data.
		$table = $data['table'];
		$cols  = isset( $table['cols'] ) ? $table['cols'] : array();
		$rows  = isset( $table['rows'] ) ? $table['rows'] : array();

		// Build structured data.
		// Expected columns: Brand, Type, Model, Service, Time, Price.
		$result = array(
			'brands' => array(),
			'data'   => array(),
		);

		foreach ( $rows as $row ) {
			if ( empty( $row['c'] ) ) {
				continue;
			}

			$cells = $row['c'];

			// Get cell values.
			$brand   = $this->get_cell_value( $cells, 0 );
			$type    = $this->get_cell_value( $cells, 1 );
			$model   = $this->get_cell_value( $cells, 2 );
			$service = $this->get_cell_value( $cells, 3 );
			$time    = $this->get_cell_value( $cells, 4 );
			$price   = $this->get_cell_value( $cells, 5 );

			// Skip empty rows.
			if ( empty( $brand ) || empty( $type ) || empty( $model ) ) {
				continue;
			}

			// Normalize brand.
			$brand_key = sanitize_title( $brand );

			// Add brand.
			if ( ! isset( $result['brands'][ $brand_key ] ) ) {
				$result['brands'][ $brand_key ] = $brand;
			}

			// Initialize brand data.
			if ( ! isset( $result['data'][ $brand_key ] ) ) {
				$result['data'][ $brand_key ] = array(
					'types' => array(),
				);
			}

			// Normalize type.
			$type_key = sanitize_title( $type );

			// Add type.
			if ( ! isset( $result['data'][ $brand_key ]['types'][ $type_key ] ) ) {
				$result['data'][ $brand_key ]['types'][ $type_key ] = array(
					'name'   => $type,
					'models' => array(),
				);
			}

			// Parse models (can be comma-separated, bracketed groups, or wildcards).
			$parsed_models = $this->parse_models( $model );

			foreach ( $parsed_models as $parsed_model ) {
				// Use different key for patterns to avoid collision with exact models.
				$is_pattern = ! empty( $parsed_model['pattern'] );
				$model_key  = $is_pattern
					? 'pattern-' . sanitize_title( $parsed_model['name'] )
					: sanitize_title( $parsed_model['name'] );

				if ( ! isset( $result['data'][ $brand_key ]['types'][ $type_key ]['models'][ $model_key ] ) ) {
					$model_data = array(
						'name'        => $parsed_model['name'],
						'group'       => $parsed_model['group'],
						'pattern'     => $is_pattern,
						'source_type' => $parsed_model['source_type'] ?? 'exact',
						'services'    => array(),
					);

					// Store original pattern text for wildcard matching.
					if ( ! empty( $parsed_model['pattern_text'] ) ) {
						$model_data['pattern_text'] = $parsed_model['pattern_text'];
					}

					$result['data'][ $brand_key ]['types'][ $type_key ]['models'][ $model_key ] = $model_data;
				}

				// Add service if not empty.
				if ( ! empty( $service ) ) {
					// Store all cell values for dynamic field mapping.
					$raw_cells = array();
					foreach ( $cells as $idx => $cell ) {
						$raw_cells[ $idx ] = $this->get_cell_value( $cells, $idx );
					}

					$result['data'][ $brand_key ]['types'][ $type_key ]['models'][ $model_key ]['services'][] = array(
						'name'      => $service,
						'time'      => $time,
						'price'     => $this->parse_price( $price ),
						'raw_cells' => $raw_cells,
					);
				}
			}
		}

		return $result;
	}

	/**
	 * Get cell value from row.
	 *
	 * @since 1.0.0
	 * @param array $cells Cell array.
	 * @param int   $index Cell index.
	 * @return string Cell value.
	 */
	private function get_cell_value( $cells, $index ) {
		if ( ! isset( $cells[ $index ] ) || null === $cells[ $index ] ) {
			return '';
		}

		$cell = $cells[ $index ];

		// Check for 'v' (value) key.
		if ( isset( $cell['v'] ) ) {
			return trim( (string) $cell['v'] );
		}

		// Check for 'f' (formatted value) key.
		if ( isset( $cell['f'] ) ) {
			return trim( (string) $cell['f'] );
		}

		return '';
	}

	/**
	 * Parse models string with grouping support.
	 *
	 * Supports:
	 * - Comma-separated: "iPhone 12, iPhone 12 Pro, iPhone 12 Pro Max"
	 * - Bracketed groups: "[iPhone 12 Series] iPhone 12, iPhone 12 Pro"
	 * - Wildcard pattern: "{iPhone 12}" (matches iPhone 12, 12 Pro, 12 Pro Max)
	 *
	 * @since 1.0.0
	 * @since 2.1.0 Added source_type for priority-based price resolution.
	 * @param string $model_string Model string.
	 * @return array Array of parsed models with name, group, and source_type.
	 */
	public function parse_models( $model_string ) {
		$models = array();
		$group  = '';

		// Check for bracketed group.
		if ( preg_match( '/^\[([^\]]+)\]\s*(.*)$/', $model_string, $matches ) ) {
			$group        = trim( $matches[1] );
			$model_string = $matches[2];
		}

		// Split by comma.
		$parts = array_map( 'trim', explode( ',', $model_string ) );

		// Track if this is a multi-model list (for source_type determination).
		$is_list = count( $parts ) > 1;

		foreach ( $parts as $part ) {
			if ( empty( $part ) ) {
				continue;
			}

			// Check for wildcard pattern: {pattern text}.
			if ( preg_match( '/^\{(.+)\}$/', $part, $pattern_match ) ) {
				// Extract pattern text from braces.
				$pattern_text = trim( $pattern_match[1] );
				$models[]     = array(
					'name'         => $pattern_text, // Display name without braces.
					'group'        => $group,
					'pattern'      => true,
					'pattern_text' => $pattern_text, // Pattern for matching.
					'source_type'  => 'wildcard',
				);
			} else {
				$models[] = array(
					'name'        => $part,
					'group'       => $group,
					'pattern'     => false,
					'source_type' => $is_list ? 'general' : 'exact',
				);
			}
		}

		// If no models parsed, return original string.
		if ( empty( $models ) ) {
			$models[] = array(
				'name'        => $model_string,
				'group'       => '',
				'pattern'     => false,
				'source_type' => 'exact',
			);
		}

		return $models;
	}

	/**
	 * Parse price value.
	 *
	 * @since 1.0.0
	 * @param string $price_string Price string.
	 * @return float|string Numeric price or original string for ranges/special values.
	 */
	private function parse_price( $price_string ) {
		// Remove currency symbols and spaces.
		$clean = preg_replace( '/[^\d.,\-]/', '', $price_string );

		// Check if it's a range (contains dash).
		if ( strpos( $clean, '-' ) !== false && preg_match( '/^\d/', $clean ) ) {
			// Return as string for ranges like "1000-2000".
			return $price_string;
		}

		// Replace comma with dot for decimals.
		$clean = str_replace( ',', '.', $clean );

		// Try to convert to float.
		if ( is_numeric( $clean ) ) {
			return floatval( $clean );
		}

		// Return original for non-numeric values (e.g., "По запросу").
		return $price_string;
	}

	/**
	 * Get brands from cached data.
	 *
	 * @since 1.0.0
	 * @param string $spreadsheet_id Spreadsheet ID.
	 * @return array Brands array.
	 */
	public function get_brands( $spreadsheet_id ) {
		$data = $this->fetch_data( $spreadsheet_id );

		if ( is_wp_error( $data ) ) {
			return array();
		}

		return isset( $data['brands'] ) ? $data['brands'] : array();
	}

	/**
	 * Get types for a brand.
	 *
	 * @since 1.0.0
	 * @param string $spreadsheet_id Spreadsheet ID.
	 * @param string $brand          Brand key.
	 * @return array Types array.
	 */
	public function get_types( $spreadsheet_id, $brand ) {
		$data = $this->fetch_data( $spreadsheet_id );

		if ( is_wp_error( $data ) || ! isset( $data['data'][ $brand ]['types'] ) ) {
			return array();
		}

		$types = array();
		foreach ( $data['data'][ $brand ]['types'] as $type_key => $type_data ) {
			$types[ $type_key ] = $type_data['name'];
		}

		return $types;
	}

	/**
	 * Get models for a brand and type.
	 *
	 * @since 1.0.0
	 * @param string $spreadsheet_id Spreadsheet ID.
	 * @param string $brand          Brand key.
	 * @param string $type           Type key.
	 * @return array Models array with grouping.
	 */
	public function get_models( $spreadsheet_id, $brand, $type ) {
		$data = $this->fetch_data( $spreadsheet_id );

		if ( is_wp_error( $data ) || ! isset( $data['data'][ $brand ]['types'][ $type ]['models'] ) ) {
			return array();
		}

		$models  = array();
		$grouped = array();

		foreach ( $data['data'][ $brand ]['types'][ $type ]['models'] as $model_key => $model_data ) {
			$group = $model_data['group'];

			if ( ! empty( $group ) ) {
				if ( ! isset( $grouped[ $group ] ) ) {
					$grouped[ $group ] = array();
				}
				$grouped[ $group ][ $model_key ] = $model_data['name'];
			} else {
				$models[ $model_key ] = $model_data['name'];
			}
		}

		return array(
			'models'  => $models,
			'grouped' => $grouped,
		);
	}

	/**
	 * Get prices for a model with priority-based resolution.
	 *
	 * Supports wildcard pattern matching with priority system:
	 * 1. Exact match (highest priority)
	 * 2. Wildcard pattern match (sorted by specificity)
	 * 3. General list match (lowest priority)
	 *
	 * @since 1.0.0
	 * @since 2.1.0 Added priority-based price resolution via Price Resolver.
	 * @param string $spreadsheet_id Spreadsheet ID.
	 * @param string $brand          Brand key.
	 * @param string $type           Type key.
	 * @param string $model          Model key.
	 * @param bool   $use_resolver   Use new Price Resolver (default true).
	 * @return array Services with prices.
	 */
	public function get_prices( $spreadsheet_id, $brand, $type, $model, $use_resolver = true ) {
		$data = $this->fetch_data( $spreadsheet_id );

		if ( is_wp_error( $data ) || ! isset( $data['data'][ $brand ]['types'][ $type ] ) ) {
			return array();
		}

		$type_data = $data['data'][ $brand ]['types'][ $type ];

		// Get model display name for pattern matching.
		$model_name = $this->get_model_name_by_key( $type_data['models'], $model );

		if ( empty( $model_name ) ) {
			return array();
		}

		// v2.1.0: Use Price Resolver for priority-based resolution.
		if ( $use_resolver && class_exists( 'MVweb_PT_Price_Resolver' ) ) {
			$debug_mode = current_user_can( 'manage_options' ) && ! empty( $_REQUEST['debug'] );
			$resolver   = new MVweb_PT_Price_Resolver( $debug_mode );

			// Categorize sources by type.
			$sources = $resolver->categorize_sources( $type_data['models'], $model_name );

			// Resolve services with priority.
			return $resolver->resolve_services( $sources, $model_name );
		}

		// Legacy behavior (fallback).
		return $this->get_prices_legacy( $type_data, $model, $model_name );
	}

	/**
	 * Legacy price resolution (v1.x behavior).
	 *
	 * @since 2.1.0
	 * @param array  $type_data  Type data with models.
	 * @param string $model      Model key.
	 * @param string $model_name Model display name.
	 * @return array Services with prices.
	 */
	private function get_prices_legacy( $type_data, $model, $model_name ) {
		// 1. Try exact match first.
		if ( isset( $type_data['models'][ $model ] ) ) {
			$exact_services = $type_data['models'][ $model ]['services'];

			// Check if exact match has valid services with prices.
			if ( $this->has_valid_prices( $exact_services ) ) {
				return $exact_services;
			}

			// Exact match exists but has no prices - fall through to wildcard matching.
		}

		// 2. Try pattern matching (wildcard models).
		// Search for pattern models that match the requested model.
		foreach ( $type_data['models'] as $pattern_key => $pattern_data ) {
			// Skip if not a pattern (no 'pattern' flag).
			if ( empty( $pattern_data['pattern'] ) ) {
				continue;
			}

			// Use pattern_text if available, otherwise use name.
			$pattern = isset( $pattern_data['pattern_text'] ) ? $pattern_data['pattern_text'] : $pattern_data['name'];

			// Check if pattern matches the model name.
			if ( $this->match_model_pattern( $pattern, $model_name ) ) {
				return $pattern_data['services'];
			}
		}

		// 3. Return exact match services even without prices (for display purposes).
		if ( isset( $type_data['models'][ $model ]['services'] ) ) {
			return $type_data['models'][ $model ]['services'];
		}

		return array();
	}

	/**
	 * Check if services array has valid prices.
	 *
	 * @since 2.0.0
	 * @param array $services Services array.
	 * @return bool True if at least one service has a non-zero price.
	 */
	private function has_valid_prices( $services ) {
		if ( empty( $services ) ) {
			return false;
		}

		foreach ( $services as $service ) {
			if ( isset( $service['price'] ) && ! empty( $service['price'] ) && 0 !== $service['price'] ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Get model display name by key.
	 *
	 * @since 2.0.0
	 * @param array  $models    Models array.
	 * @param string $model_key Model key to find.
	 * @return string Model name or empty string.
	 */
	private function get_model_name_by_key( $models, $model_key ) {
		if ( isset( $models[ $model_key ]['name'] ) ) {
			return $models[ $model_key ]['name'];
		}

		// If model doesn't exist, try to reconstruct name from key.
		// sanitize_title converts "iPhone 17 Pro Max" to "iphone-17-pro-max".
		// We need to find a model that would produce this key.
		foreach ( $models as $key => $data ) {
			if ( sanitize_title( $data['name'] ) === $model_key ) {
				return $data['name'];
			}
		}

		return '';
	}

	/**
	 * Check if a pattern matches a model name (prefix match).
	 *
	 * Pattern is a prefix:
	 * - "iPhone 17" matches "iPhone 17", "iPhone 17 Pro", "iPhone 17 Pro Max"
	 *
	 * @since 2.0.0
	 * @since 2.1.0 Changed from wildcard (*) to prefix matching.
	 * @param string $pattern    Pattern (prefix to match).
	 * @param string $model_name Model name to match against.
	 * @return bool True if model starts with pattern.
	 */
	private function match_model_pattern( $pattern, $model_name ) {
		// Normalize both for comparison.
		$pattern_lower = mb_strtolower( trim( $pattern ) );
		$model_lower   = mb_strtolower( trim( $model_name ) );

		// Exact match.
		if ( $pattern_lower === $model_lower ) {
			return true;
		}

		// Prefix match: model must start with pattern.
		return strpos( $model_lower, $pattern_lower ) === 0;
	}

	/**
	 * Test connection to Google Sheets.
	 *
	 * @since 1.0.0
	 * @param string $spreadsheet_id Spreadsheet ID.
	 * @return array|WP_Error Test result or error.
	 */
	public function test_connection( $spreadsheet_id ) {
		$data = $this->fetch_data( $spreadsheet_id, false );

		if ( is_wp_error( $data ) ) {
			return $data;
		}

		$brand_count  = count( $data['brands'] );
		$type_count   = 0;
		$model_count  = 0;
		$record_count = 0;

		foreach ( $data['data'] as $brand_data ) {
			$type_count += count( $brand_data['types'] );
			foreach ( $brand_data['types'] as $type_data ) {
				$model_count += count( $type_data['models'] );
				foreach ( $type_data['models'] as $model_data ) {
					$record_count += count( $model_data['services'] );
				}
			}
		}

		return array(
			'success' => true,
			'stats'   => array(
				'brands'   => $brand_count,
				'types'    => $type_count,
				'models'   => $model_count,
				'services' => $record_count,
			),
		);
	}

	/**
	 * Fetch list of sheets (tabs) from a Google Spreadsheet.
	 *
	 * Uses the htmlview endpoint which contains sheet names in JavaScript.
	 *
	 * @since 2.2.0
	 * @param string $spreadsheet_id Spreadsheet ID.
	 * @return array|WP_Error Array of sheets with 'gid' and 'name', or error.
	 */
	public function fetch_sheets_list( $spreadsheet_id ) {
		$sheets = array();

		// Use htmlview endpoint - it contains sheet names in JavaScript array.
		$html_url  = sprintf( 'https://docs.google.com/spreadsheets/d/%s/htmlview', $spreadsheet_id );
		$html_resp = wp_remote_get(
			$html_url,
			array(
				'timeout'    => 15,
				'user-agent' => 'MVweb Price Table/' . MVWEB_PT_VERSION,
			)
		);

		if ( is_wp_error( $html_resp ) ) {
			return $html_resp;
		}

		$code = wp_remote_retrieve_response_code( $html_resp );
		if ( 200 !== $code ) {
			return new WP_Error(
				'http_error',
				sprintf(
					/* translators: %d: HTTP status code */
					__( 'Google Sheets returned HTTP error: %d', 'mvweb-price-table' ),
					$code
				)
			);
		}

		$body = wp_remote_retrieve_body( $html_resp );

		// Look for items.push({name: "Sheet Name", ... gid: "123"});
		// Pattern: items.push({name: "Цены на услуги", ... gid: "0",...});
		if ( preg_match_all( '/items\.push\(\{name:\s*"([^"]+)"[^}]*gid:\s*"(\d+)"/', $body, $matches, PREG_SET_ORDER ) ) {
			foreach ( $matches as $match ) {
				$sheets[] = array(
					'gid'  => intval( $match[2] ),
					'name' => $this->decode_unicode_string( $match[1] ),
				);
			}
		}

		if ( empty( $sheets ) ) {
			// Return default sheet if nothing found.
			return array(
				array(
					'gid'  => 0,
					'name' => 'Sheet1',
				),
			);
		}

		return $sheets;
	}

	/**
	 * Decode unicode escape sequences in a string.
	 *
	 * @since 2.2.0
	 * @param string $str String with possible unicode escapes.
	 * @return string Decoded string.
	 */
	private function decode_unicode_string( $str ) {
		// Decode \uXXXX sequences.
		$decoded = preg_replace_callback(
			'/\\\\u([0-9a-fA-F]{4})/',
			function ( $match ) {
				return mb_convert_encoding( pack( 'H*', $match[1] ), 'UTF-8', 'UTF-16BE' );
			},
			$str
		);

		// Also handle \\x sequences.
		$decoded = preg_replace_callback(
			'/\\\\x([0-9a-fA-F]{2})/',
			function ( $match ) {
				return chr( hexdec( $match[1] ) );
			},
			$decoded
		);

		return $decoded;
	}

	/**
	 * Fetch headers (first row) from Google Sheets.
	 *
	 * @since 2.0.0
	 * @param string $spreadsheet_id Spreadsheet ID.
	 * @return array|WP_Error Array of header strings or error.
	 */
	public function fetch_headers( $spreadsheet_id ) {
		// Build API URL with headers=1 (first row as headers).
		$url = sprintf( self::API_BASE_URL, $spreadsheet_id );

		// Make request.
		$response = wp_remote_get(
			$url,
			array(
				'timeout'    => 15,
				'user-agent' => 'MVweb Price Table/' . MVWEB_PT_VERSION,
			)
		);

		// Check for errors.
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		// Check response code.
		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			return new WP_Error(
				'http_error',
				sprintf(
					/* translators: %d: HTTP status code */
					__( 'Google Sheets returned HTTP error: %d', 'mvweb-price-table' ),
					$code
				)
			);
		}

		// Get body.
		$body = wp_remote_retrieve_body( $response );

		// Remove JSONP wrapper.
		$json = preg_replace( '/^[^(]+\(|\);?$/', '', $body );

		// Decode JSON.
		$data = json_decode( $json, true );
		if ( null === $data || ! isset( $data['table'] ) ) {
			return new WP_Error(
				'parse_error',
				__( 'Failed to parse Google Sheets response.', 'mvweb-price-table' )
			);
		}

		// With headers=1, the header labels are in 'cols' array with 'label' key.
		$cols = isset( $data['table']['cols'] ) ? $data['table']['cols'] : array();
		if ( empty( $cols ) ) {
			return new WP_Error(
				'no_headers',
				__( 'No headers found in spreadsheet.', 'mvweb-price-table' )
			);
		}

		// Extract header labels from cols.
		$headers = array();
		foreach ( $cols as $col ) {
			if ( isset( $col['label'] ) && '' !== $col['label'] ) {
				$headers[] = trim( (string) $col['label'] );
			} else {
				$headers[] = '';
			}
		}

		return $headers;
	}

	/**
	 * Fetch raw rows from Google Sheets (including headers as first row).
	 *
	 * @since 2.0.0
	 * @param string $spreadsheet_id Spreadsheet ID.
	 * @param int    $limit          Maximum rows to fetch.
	 * @return array|WP_Error Array of rows or error.
	 */
	public function fetch_raw_rows( $spreadsheet_id, $limit = 21 ) {
		// Build API URL without headers=1 to get raw data.
		$url = sprintf( self::API_BASE_URL, $spreadsheet_id );
		$url = str_replace( 'headers=1', 'headers=0', $url );

		// Add LIMIT clause.
		$url = add_query_arg( 'tq', 'SELECT * LIMIT ' . $limit, $url );

		// Make request.
		$response = wp_remote_get(
			$url,
			array(
				'timeout'    => 15,
				'user-agent' => 'MVweb Price Table/' . MVWEB_PT_VERSION,
			)
		);

		// Check for errors.
		if ( is_wp_error( $response ) ) {
			return $response;
		}

		// Check response code.
		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== $code ) {
			return new WP_Error(
				'http_error',
				sprintf(
					/* translators: %d: HTTP status code */
					__( 'Google Sheets returned HTTP error: %d', 'mvweb-price-table' ),
					$code
				)
			);
		}

		// Get body.
		$body = wp_remote_retrieve_body( $response );

		// Remove JSONP wrapper.
		$json = preg_replace( '/^[^(]+\(|\);?$/', '', $body );

		// Decode JSON.
		$data = json_decode( $json, true );
		if ( null === $data || ! isset( $data['table'] ) ) {
			return new WP_Error(
				'parse_error',
				__( 'Failed to parse Google Sheets response.', 'mvweb-price-table' )
			);
		}

		$rows   = isset( $data['table']['rows'] ) ? $data['table']['rows'] : array();
		$result = array();

		foreach ( $rows as $row ) {
			$cells    = isset( $row['c'] ) ? $row['c'] : array();
			$row_data = array();

			foreach ( $cells as $cell ) {
				if ( null === $cell ) {
					$row_data[] = '';
				} elseif ( isset( $cell['f'] ) ) {
					// Formatted value (preferred for display).
					$row_data[] = (string) $cell['f'];
				} elseif ( isset( $cell['v'] ) ) {
					$row_data[] = (string) $cell['v'];
				} else {
					$row_data[] = '';
				}
			}

			$result[] = $row_data;
		}

		return $result;
	}
}
