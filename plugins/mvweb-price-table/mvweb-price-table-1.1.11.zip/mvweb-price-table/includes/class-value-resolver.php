<?php
/**
 * Value Resolver for MVweb Price Table.
 *
 * Handles value inheritance with wildcard templates.
 * Merges service data from general to specific (cascade inheritance).
 *
 * @package MVweb_Price_Table
 * @since   2.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Value Resolver class.
 *
 * Implements inheritance system where wildcard templates (*) allow
 * defining default values that are overridden by more specific ones.
 *
 * Example inheritance chain:
 * - * | * | * | Screen Repair | 60 min | 5000  (default for all)
 * - Apple | * | * | Screen Repair | 90 min | 7000  (Apple default)
 * - Apple | iPhone | * | Screen Repair | 60 min | 8000  (iPhone default)
 * - Apple | iPhone | 15 Pro | Screen Repair | 45 min | 12000  (specific)
 *
 * Query for "Apple | iPhone | 15 Pro" returns:
 * Screen Repair | 45 min | 12000 (most specific wins)
 *
 * @since 2.0.0
 */
class MVweb_PT_Value_Resolver {

	/**
	 * Wildcard character.
	 *
	 * @since 2.0.0
	 * @var string
	 */
	private $wildcard;

	/**
	 * Memory cache for resolved values.
	 *
	 * @since 2.0.0
	 * @var array
	 */
	private $memory_cache = array();

	/**
	 * Transient cache key prefix.
	 *
	 * @since 2.0.0
	 * @var string
	 */
	private const CACHE_PREFIX = 'mvweb_pt_resolved_';

	/**
	 * Cache expiration in seconds (1 hour).
	 *
	 * @since 2.0.0
	 * @var int
	 */
	private const CACHE_EXPIRATION = 3600;

	/**
	 * Show source debug info.
	 *
	 * @since 2.0.0
	 * @var bool
	 */
	private $show_source;

	/**
	 * Constructor.
	 *
	 * @since 2.0.0
	 * @param string $wildcard    Wildcard character (default '*').
	 * @param bool   $show_source Whether to include source info in results.
	 */
	public function __construct( $wildcard = '*', $show_source = false ) {
		$this->wildcard    = $wildcard;
		$this->show_source = $show_source && current_user_can( 'manage_options' );
	}

	/**
	 * Parse templates from spreadsheet data.
	 *
	 * Extracts rows containing wildcards and builds template index.
	 *
	 * @since 2.0.0
	 * @param array $data        Parsed spreadsheet data with services.
	 * @param int   $depth       Hierarchy depth (number of levels).
	 * @return array {
	 *     @type array $templates      Template rows indexed by pattern.
	 *     @type array $template_index Index for fast lookup.
	 *     @type array $specific       Non-template (specific) rows.
	 * }
	 */
	public function parse_templates( $data, $depth = 3 ) {
		$templates      = array();
		$template_index = array();
		$specific       = array();

		foreach ( $data as $row ) {
			$hierarchy = $this->extract_hierarchy( $row, $depth );
			$has_wildcard = $this->has_wildcard( $hierarchy );

			if ( $has_wildcard ) {
				// Build template key.
				$key = $this->build_template_key( $hierarchy );

				if ( ! isset( $templates[ $key ] ) ) {
					$templates[ $key ] = array(
						'hierarchy' => $hierarchy,
						'services'  => array(),
					);
				}

				// Add service to template.
				$templates[ $key ]['services'][] = $this->extract_service( $row );

				// Build index for fast lookup.
				$this->add_to_index( $template_index, $hierarchy, $key );
			} else {
				$specific[] = $row;
			}
		}

		return array(
			'templates'      => $templates,
			'template_index' => $template_index,
			'specific'       => $specific,
		);
	}

	/**
	 * Resolve services for a specific hierarchy path.
	 *
	 * Merges templates from most general to most specific.
	 *
	 * @since 2.0.0
	 * @param array  $hierarchy    Hierarchy values [brand, type, model, ...].
	 * @param array  $templates    Parsed templates.
	 * @param array  $specific     Specific rows for this path.
	 * @param string $cache_key    Optional cache key for transient caching.
	 * @return array Resolved services with inheritance applied.
	 */
	public function resolve_services( $hierarchy, $templates, $specific, $cache_key = '' ) {
		// Check memory cache.
		$memory_key = implode( '|', $hierarchy );
		if ( isset( $this->memory_cache[ $memory_key ] ) ) {
			return $this->memory_cache[ $memory_key ];
		}

		// Check transient cache.
		if ( ! empty( $cache_key ) ) {
			$cached = get_transient( self::CACHE_PREFIX . $cache_key );
			if ( false !== $cached ) {
				$this->memory_cache[ $memory_key ] = $cached;
				return $cached;
			}
		}

		// Build list of matching templates (most general first).
		$matching_templates = $this->find_matching_templates( $hierarchy, $templates );

		// Merge services.
		$resolved = $this->merge_services( $matching_templates, $specific );

		// Store in caches.
		$this->memory_cache[ $memory_key ] = $resolved;

		if ( ! empty( $cache_key ) ) {
			set_transient( self::CACHE_PREFIX . $cache_key, $resolved, self::CACHE_EXPIRATION );
		}

		return $resolved;
	}

	/**
	 * Find matching templates for a hierarchy path.
	 *
	 * Returns templates in order from most general to most specific.
	 *
	 * @since 2.0.0
	 * @param array $hierarchy Hierarchy values.
	 * @param array $templates All parsed templates.
	 * @return array Matching templates ordered by specificity.
	 */
	private function find_matching_templates( $hierarchy, $templates ) {
		$matches = array();
		$depth   = count( $hierarchy );

		// Generate all possible patterns (most general to most specific).
		$patterns = $this->generate_patterns( $hierarchy );

		foreach ( $patterns as $pattern ) {
			$key = $this->build_template_key( $pattern );
			if ( isset( $templates[ $key ] ) ) {
				$matches[] = array(
					'key'        => $key,
					'pattern'    => $pattern,
					'specificity' => $this->calculate_specificity( $pattern ),
					'services'   => $templates[ $key ]['services'],
				);
			}
		}

		// Sort by specificity (ascending - most general first).
		usort(
			$matches,
			function ( $a, $b ) {
				return $a['specificity'] - $b['specificity'];
			}
		);

		return $matches;
	}

	/**
	 * Generate all possible wildcard patterns for a hierarchy.
	 *
	 * For [A, B, C] generates:
	 * [*, *, *], [A, *, *], [*, B, *], [*, *, C],
	 * [A, B, *], [A, *, C], [*, B, C], [A, B, C]
	 *
	 * @since 2.0.0
	 * @param array $hierarchy Hierarchy values.
	 * @return array All possible patterns.
	 */
	private function generate_patterns( $hierarchy ) {
		$patterns = array();
		$depth    = count( $hierarchy );
		$total    = pow( 2, $depth ); // 2^depth combinations.

		for ( $i = 0; $i < $total; $i++ ) {
			$pattern = array();
			for ( $j = 0; $j < $depth; $j++ ) {
				// If bit j is set, use actual value; otherwise use wildcard.
				if ( $i & ( 1 << $j ) ) {
					$pattern[] = $hierarchy[ $j ];
				} else {
					$pattern[] = $this->wildcard;
				}
			}
			$patterns[] = $pattern;
		}

		return $patterns;
	}

	/**
	 * Calculate specificity score for a pattern.
	 *
	 * Higher score = more specific.
	 * Each non-wildcard value adds 2^position to the score.
	 *
	 * @since 2.0.0
	 * @param array $pattern Pattern array.
	 * @return int Specificity score.
	 */
	private function calculate_specificity( $pattern ) {
		$score = 0;
		foreach ( $pattern as $i => $value ) {
			if ( $value !== $this->wildcard ) {
				$score += pow( 2, $i );
			}
		}
		return $score;
	}

	/**
	 * Merge services from templates and specific rows.
	 *
	 * Later (more specific) values override earlier (general) values.
	 *
	 * @since 2.0.0
	 * @param array $matching_templates Ordered templates.
	 * @param array $specific           Specific rows.
	 * @return array Merged services.
	 */
	private function merge_services( $matching_templates, $specific ) {
		$merged = array();

		// First, apply templates (most general first).
		foreach ( $matching_templates as $template ) {
			foreach ( $template['services'] as $service ) {
				$service_key = $this->get_service_key( $service );

				if ( ! isset( $merged[ $service_key ] ) ) {
					$merged[ $service_key ] = $service;
					if ( $this->show_source ) {
						$merged[ $service_key ]['_source'] = $template['key'];
					}
				} else {
					// Merge: more specific values override.
					$merged[ $service_key ] = $this->merge_service_data(
						$merged[ $service_key ],
						$service,
						$template['key']
					);
				}
			}
		}

		// Then apply specific rows (highest priority).
		foreach ( $specific as $row ) {
			$service     = $this->extract_service( $row );
			$service_key = $this->get_service_key( $service );

			if ( ! isset( $merged[ $service_key ] ) ) {
				$merged[ $service_key ] = $service;
				if ( $this->show_source ) {
					$merged[ $service_key ]['_source'] = 'specific';
				}
			} else {
				$merged[ $service_key ] = $this->merge_service_data(
					$merged[ $service_key ],
					$service,
					'specific'
				);
			}
		}

		return array_values( $merged );
	}

	/**
	 * Get unique key for a service (for merging).
	 *
	 * @since 2.0.0
	 * @param array $service Service data.
	 * @return string Service key.
	 */
	private function get_service_key( $service ) {
		// Use service name and group as unique identifier.
		$name  = $service['name'] ?? '';
		$group = $service['group'] ?? '';

		// SEC-004: Escape pipe character to prevent injection.
		$name  = str_replace( '|', '\\|', $name );
		$group = str_replace( '|', '\\|', $group );

		return $group . '|' . $name;
	}

	/**
	 * Merge two service data arrays.
	 *
	 * Non-empty values from $new override values in $existing.
	 *
	 * @since 2.0.0
	 * @param array  $existing Existing service data.
	 * @param array  $new      New service data.
	 * @param string $source   Source identifier for debug.
	 * @return array Merged service data.
	 */
	private function merge_service_data( $existing, $new, $source ) {
		$merged = $existing;

		foreach ( $new as $key => $value ) {
			// Skip internal keys.
			if ( strpos( $key, '_' ) === 0 ) {
				continue;
			}

			// Non-empty values override.
			if ( ! empty( $value ) || '0' === $value || 0 === $value ) {
				$merged[ $key ] = $value;

				if ( $this->show_source ) {
					$merged[ '_source' ]        = $source;
					$merged[ '_merged_fields' ] = $merged['_merged_fields'] ?? array();
					$merged[ '_merged_fields' ][ $key ] = $source;
				}
			}
		}

		return $merged;
	}

	/**
	 * Extract hierarchy values from a row.
	 *
	 * @since 2.0.0
	 * @param array $row   Row data.
	 * @param int   $depth Number of hierarchy levels.
	 * @return array Hierarchy values.
	 */
	private function extract_hierarchy( $row, $depth ) {
		$hierarchy = array();

		for ( $i = 1; $i <= $depth; $i++ ) {
			$key = "hierarchy_{$i}";
			$hierarchy[] = $row[ $key ] ?? '';
		}

		return $hierarchy;
	}

	/**
	 * Extract service data from a row.
	 *
	 * @since 2.0.0
	 * @param array $row Row data.
	 * @return array Service data.
	 */
	private function extract_service( $row ) {
		return array(
			'name'     => $row['service_name'] ?? $row['service'] ?? '',
			'price'    => $row['service_price'] ?? $row['price'] ?? '',
			'time'     => $row['service_time'] ?? $row['time'] ?? '',
			'group'    => $row['service_group'] ?? $row['group'] ?? '',
			'note'     => $row['meta_note'] ?? $row['note'] ?? '',
			'warranty' => $row['meta_warranty'] ?? '',
			'sku'      => $row['meta_sku'] ?? '',
		);
	}

	/**
	 * Check if hierarchy contains wildcards.
	 *
	 * @since 2.0.0
	 * @param array $hierarchy Hierarchy values.
	 * @return bool True if contains wildcard.
	 */
	private function has_wildcard( $hierarchy ) {
		return in_array( $this->wildcard, $hierarchy, true );
	}

	/**
	 * Build template key from hierarchy.
	 *
	 * SEC-004: Escapes pipe character to prevent injection.
	 *
	 * @since 2.0.0
	 * @param array $hierarchy Hierarchy values.
	 * @return string Template key.
	 */
	private function build_template_key( $hierarchy ) {
		// Escape pipe characters in values.
		$escaped = array_map(
			function ( $value ) {
				return str_replace( '|', '\\|', $value );
			},
			$hierarchy
		);

		return implode( '|', $escaped );
	}

	/**
	 * Add template to lookup index.
	 *
	 * @since 2.0.0
	 * @param array  $index     Index array (passed by reference).
	 * @param array  $hierarchy Hierarchy pattern.
	 * @param string $key       Template key.
	 * @return void
	 */
	private function add_to_index( &$index, $hierarchy, $key ) {
		// Index by first non-wildcard value for quick lookup.
		foreach ( $hierarchy as $value ) {
			if ( $value !== $this->wildcard ) {
				if ( ! isset( $index[ $value ] ) ) {
					$index[ $value ] = array();
				}
				$index[ $value ][] = $key;
				return;
			}
		}

		// All wildcards - index under special key.
		if ( ! isset( $index['*'] ) ) {
			$index['*'] = array();
		}
		$index['*'][] = $key;
	}

	/**
	 * Clear all caches for a form.
	 *
	 * @since 2.0.0
	 * @param int $form_id Form ID.
	 * @return void
	 */
	public static function clear_cache( $form_id ) {
		global $wpdb;

		// Clear transients matching our prefix + form_id.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . self::CACHE_PREFIX . $form_id . '_' ) . '%'
			)
		);

		// Clear timeout transients.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_timeout_' . self::CACHE_PREFIX . $form_id . '_' ) . '%'
			)
		);
	}

	/**
	 * Generate cache key for a hierarchy query.
	 *
	 * @since 2.0.0
	 * @param int   $form_id   Form ID.
	 * @param array $hierarchy Hierarchy values.
	 * @return string Cache key.
	 */
	public static function generate_cache_key( $form_id, $hierarchy ) {
		$path = implode( '_', array_map( 'sanitize_key', $hierarchy ) );
		return absint( $form_id ) . '_' . md5( $path );
	}

	/**
	 * Get inheritance chain for debugging.
	 *
	 * @since 2.0.0
	 * @param array $hierarchy        Hierarchy values.
	 * @param array $templates        Parsed templates.
	 * @param array $resolved_service Resolved service data.
	 * @return array Debug info about inheritance chain.
	 */
	public function get_inheritance_chain( $hierarchy, $templates, $resolved_service ) {
		if ( ! $this->show_source ) {
			return array();
		}

		$chain = array();
		$matching = $this->find_matching_templates( $hierarchy, $templates );

		foreach ( $matching as $template ) {
			$chain[] = array(
				'pattern'     => implode( ' → ', $template['pattern'] ),
				'specificity' => $template['specificity'],
				'key'         => $template['key'],
			);
		}

		$chain[] = array(
			'pattern'     => implode( ' → ', $hierarchy ),
			'specificity' => pow( 2, count( $hierarchy ) ) - 1,
			'key'         => 'specific',
		);

		return array(
			'query'     => $hierarchy,
			'chain'     => $chain,
			'final'     => $resolved_service['_source'] ?? 'unknown',
			'merged'    => $resolved_service['_merged_fields'] ?? array(),
		);
	}
}
