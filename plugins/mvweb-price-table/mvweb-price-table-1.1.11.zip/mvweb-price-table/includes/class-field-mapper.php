<?php
/**
 * Field Mapper for MVweb Price Table.
 *
 * Handles dynamic column mapping and auto-detection from spreadsheet headers.
 *
 * @package MVweb_Price_Table
 * @since   2.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Field Mapper class.
 *
 * Provides methods for working with dynamic field mappings,
 * including auto-detection from headers and validation.
 *
 * @since 2.0.0
 */
class MVweb_PT_Field_Mapper {

	/**
	 * Mapping configuration.
	 *
	 * @since 2.0.0
	 * @var array
	 */
	private $mapping;

	/**
	 * Header keywords for auto-detection (Russian and English).
	 *
	 * @since 2.0.0
	 * @var array<string,array<string>>
	 */
	private $keywords = array(
		'hierarchy_1'   => array(
			'brand', 'бренд', 'марка', 'производитель',
			'manufacturer', 'make', 'vendor',
		),
		'hierarchy_2'   => array(
			'type', 'тип', 'категория', 'category',
			'вид', 'kind', 'series', 'серия',
		),
		'hierarchy_3'   => array(
			'model', 'модель', 'название', 'name',
			'product', 'продукт', 'товар', 'item',
		),
		'hierarchy_4'   => array(
			'variant', 'вариант', 'модификация',
			'modification', 'version', 'версия',
			'level 4', 'уровень 4',
		),
		'hierarchy_5'   => array(
			'subvariant', 'подвариант', 'submodel', 'подмодель',
			'level 5', 'уровень 5',
		),
		'service_name'  => array(
			'service', 'услуга', 'работа', 'work',
			'repair', 'ремонт', 'operation', 'операция',
			'название услуги', 'service name',
		),
		'service_price' => array(
			'price', 'цена', 'стоимость', 'cost',
			'прайс', 'сумма', 'amount', 'rate',
		),
		'service_time'  => array(
			'time', 'время', 'срок', 'duration',
			'длительность', 'period', 'период',
			'часы', 'hours', 'минуты', 'minutes',
		),
		'service_group' => array(
			'group', 'группа', 'section', 'раздел',
			'category', 'категория услуг',
		),
		'meta_note'     => array(
			'note', 'примечание', 'comment', 'комментарий',
			'description', 'описание', 'info', 'инфо',
		),
		'meta_warranty' => array(
			'warranty', 'гарантия', 'guarantee',
		),
		'meta_sku'      => array(
			'sku', 'артикул', 'article', 'код',
			'code', 'id', 'номер', 'number',
		),
	);

	/**
	 * Constructor.
	 *
	 * @since 2.0.0
	 * @param array|null $mapping Optional mapping configuration.
	 */
	public function __construct( $mapping = null ) {
		if ( null === $mapping ) {
			$this->mapping = mvweb_pt_get_default_field_mapping();
		} else {
			$this->mapping = mvweb_pt_sanitize_field_mapping( $mapping );
		}
	}

	/**
	 * Get the current mapping configuration.
	 *
	 * @since 2.0.0
	 * @return array Mapping configuration.
	 */
	public function get_mapping() {
		return $this->mapping;
	}

	/**
	 * Get column index by role.
	 *
	 * @since 2.0.0
	 * @param string $role Role to find.
	 * @return int|false Column index or false if not found.
	 */
	public function get_column_index( $role ) {
		foreach ( $this->mapping['columns'] as $column ) {
			if ( $column['role'] === $role ) {
				return $column['index'];
			}
		}
		return false;
	}

	/**
	 * Get all column indices by role prefix.
	 *
	 * @since 2.0.0
	 * @param string $prefix Role prefix (e.g., 'hierarchy_', 'service_').
	 * @return array Array of indices sorted by role number.
	 */
	public function get_columns_by_prefix( $prefix ) {
		$columns = array();

		foreach ( $this->mapping['columns'] as $column ) {
			if ( strpos( $column['role'], $prefix ) === 0 ) {
				$columns[ $column['role'] ] = $column['index'];
			}
		}

		// Sort by role name to maintain order (hierarchy_1, hierarchy_2, etc.).
		ksort( $columns );

		return $columns;
	}

	/**
	 * Get hierarchy depth.
	 *
	 * @since 2.0.0
	 * @return int Number of hierarchy levels (1-5).
	 */
	public function get_hierarchy_depth() {
		$hierarchy_columns = $this->get_columns_by_prefix( 'hierarchy_' );
		return count( $hierarchy_columns );
	}

	/**
	 * Get hierarchy column indices in order.
	 *
	 * @since 2.0.0
	 * @return array Ordered array of column indices for hierarchy levels.
	 */
	public function get_hierarchy_indices() {
		return array_values( $this->get_columns_by_prefix( 'hierarchy_' ) );
	}

	/**
	 * Get service column configuration.
	 *
	 * Returns columns that contain service data (name, price, time, etc.).
	 *
	 * @since 2.0.0
	 * @return array Array with role => column_config pairs.
	 */
	public function get_service_columns() {
		$service_columns = array();

		foreach ( $this->mapping['columns'] as $column ) {
			if ( strpos( $column['role'], 'service_' ) === 0 ) {
				$service_columns[ $column['role'] ] = $column;
			}
		}

		return $service_columns;
	}

	/**
	 * Get meta column configuration.
	 *
	 * Returns columns that contain metadata.
	 *
	 * @since 2.0.0
	 * @return array Array with role => column_config pairs.
	 */
	public function get_meta_columns() {
		$meta_columns = array();

		foreach ( $this->mapping['columns'] as $column ) {
			if ( strpos( $column['role'], 'meta_' ) === 0 ) {
				$meta_columns[ $column['role'] ] = $column;
			}
		}

		return $meta_columns;
	}

	/**
	 * Validate mapping configuration.
	 *
	 * @since 2.0.0
	 * @return true|WP_Error True on success, WP_Error on failure.
	 */
	public function validate() {
		$errors = array();

		// Check for required hierarchy levels.
		$depth = $this->get_hierarchy_depth();
		if ( $depth < 1 ) {
			$errors[] = __( 'At least one hierarchy level is required.', 'mvweb-price-table' );
		}

		// Check for service_name (required).
		if ( false === $this->get_column_index( 'service_name' ) ) {
			$errors[] = __( 'Service Name column is required.', 'mvweb-price-table' );
		}

		// Check for service_price (required).
		if ( false === $this->get_column_index( 'service_price' ) ) {
			$errors[] = __( 'Price column is required.', 'mvweb-price-table' );
		}

		// Check for duplicate indices.
		$indices = array();
		foreach ( $this->mapping['columns'] as $column ) {
			if ( 'ignore' === $column['role'] ) {
				continue;
			}
			if ( in_array( $column['index'], $indices, true ) ) {
				$errors[] = sprintf(
					/* translators: %d: column index */
					__( 'Duplicate column index: %d', 'mvweb-price-table' ),
					$column['index']
				);
			}
			$indices[] = $column['index'];
		}

		// Check hierarchy is sequential (no gaps).
		$hierarchy = $this->get_columns_by_prefix( 'hierarchy_' );
		$expected  = 1;
		foreach ( array_keys( $hierarchy ) as $role ) {
			$level = (int) str_replace( 'hierarchy_', '', $role );
			if ( $level !== $expected ) {
				$errors[] = sprintf(
					/* translators: %d: hierarchy level */
					__( 'Missing hierarchy level: %d', 'mvweb-price-table' ),
					$expected
				);
			}
			++$expected;
		}

		if ( ! empty( $errors ) ) {
			return new WP_Error( 'invalid_mapping', implode( ' ', $errors ) );
		}

		return true;
	}

	/**
	 * Auto-detect mapping from spreadsheet headers.
	 *
	 * Analyzes header row and suggests role assignments based on keywords.
	 *
	 * @since 2.0.0
	 * @param array $headers Array of header strings from first row.
	 * @return array Suggested mapping configuration.
	 */
	public function auto_detect_mapping( $headers ) {
		$columns    = array();
		$used_roles = array();

		// Find the last non-empty header index to avoid trailing empty columns.
		$last_non_empty = -1;
		foreach ( $headers as $index => $header ) {
			if ( ! empty( trim( $header ) ) ) {
				$last_non_empty = $index;
			}
		}

		foreach ( $headers as $index => $header ) {
			$header_trimmed = trim( $header );

			// Skip completely empty headers after the last non-empty one.
			if ( empty( $header_trimmed ) && $index > $last_non_empty ) {
				continue;
			}

			// Skip empty headers in the middle - don't add to columns at all.
			if ( empty( $header_trimmed ) ) {
				continue;
			}

			$header_lower  = mb_strtolower( $header_trimmed );
			$detected_role = 'ignore';
			$best_score    = 0;

			// Find best matching role.
			foreach ( $this->keywords as $role => $keywords ) {
				// Skip if role already used.
				if ( in_array( $role, $used_roles, true ) ) {
					continue;
				}

				foreach ( $keywords as $keyword ) {
					// Exact match.
					if ( $header_lower === $keyword ) {
						$score = 100;
					// Contains keyword.
					} elseif ( mb_strpos( $header_lower, $keyword ) !== false ) {
						$score = 70 + ( strlen( $keyword ) / strlen( $header_lower ) * 30 );
					// Keyword contains header.
					} elseif ( mb_strpos( $keyword, $header_lower ) !== false ) {
						$score = 50;
					} else {
						$score = 0;
					}

					if ( $score > $best_score ) {
						$best_score    = $score;
						$detected_role = $role;
					}
				}
			}

			// Only assign role if score is high enough.
			if ( $best_score < 40 ) {
				$detected_role = 'ignore';
			} else {
				$used_roles[] = $detected_role;
			}

			// Determine format based on role.
			$format = $this->get_default_format_for_role( $detected_role );

			$columns[] = array(
				'index'           => $index,
				'role'            => $detected_role,
				'label'           => sanitize_text_field( substr( $header_trimmed, 0, 100 ) ),
				'format'          => $format,
				'auto_detected'   => true,
				'confidence'      => $best_score,
				'original_header' => $header,
			);
		}

		return array(
			'schema_version' => '2.0',
			'mode'           => 'mapped',
			'columns'        => $columns,
			'inheritance'    => array(
				'enabled'     => false,
				'wildcard'    => '*',
				'show_source' => false,
			),
		);
	}

	/**
	 * Get default format for a role.
	 *
	 * @since 2.0.0
	 * @param string $role Role name.
	 * @return string Format name.
	 */
	private function get_default_format_for_role( $role ) {
		$role_formats = array(
			'service_price' => 'currency',
			'service_time'  => 'duration',
			'meta_note'     => 'html',
		);

		return isset( $role_formats[ $role ] ) ? $role_formats[ $role ] : 'text';
	}

	/**
	 * Check if inheritance is enabled.
	 *
	 * @since 2.0.0
	 * @return bool True if inheritance is enabled.
	 */
	public function is_inheritance_enabled() {
		return ! empty( $this->mapping['inheritance']['enabled'] );
	}

	/**
	 * Get wildcard character for inheritance.
	 *
	 * @since 2.0.0
	 * @return string Wildcard character.
	 */
	public function get_wildcard() {
		return $this->mapping['inheritance']['wildcard'] ?? '*';
	}

	/**
	 * Check if showing value source is enabled (debug mode).
	 *
	 * @since 2.0.0
	 * @return bool True if enabled (and user is admin).
	 */
	public function should_show_source() {
		if ( empty( $this->mapping['inheritance']['show_source'] ) ) {
			return false;
		}

		return current_user_can( 'manage_options' );
	}

	/**
	 * Check if using legacy mode.
	 *
	 * @since 2.0.0
	 * @return bool True if legacy mode.
	 */
	public function is_legacy_mode() {
		return 'legacy' === ( $this->mapping['mode'] ?? 'legacy' );
	}

	/**
	 * Convert mapping to legacy indices for backward compatibility.
	 *
	 * Returns array compatible with old Google Sheets parser.
	 *
	 * @since 2.0.0
	 * @return array Legacy indices [brand_idx, type_idx, model_idx, service_idx, time_idx, price_idx].
	 */
	public function to_legacy_indices() {
		return array(
			'brand'   => $this->get_column_index( 'hierarchy_1' ) ?? 0,
			'type'    => $this->get_column_index( 'hierarchy_2' ) ?? 1,
			'model'   => $this->get_column_index( 'hierarchy_3' ) ?? 2,
			'service' => $this->get_column_index( 'service_name' ) ?? 3,
			'time'    => $this->get_column_index( 'service_time' ) ?? 4,
			'price'   => $this->get_column_index( 'service_price' ) ?? 5,
		);
	}

	/**
	 * Get preset mapping configurations.
	 *
	 * Provides predefined mappings for common use cases.
	 *
	 * @since 2.0.0
	 * @return array<string,array> Preset name => mapping configuration.
	 */
	public static function get_presets() {
		return array(
			'repair'   => array(
				'name'        => __( 'Repair Services', 'mvweb-price-table' ),
				'description' => __( 'Brand → Type → Model → Service → Time → Price', 'mvweb-price-table' ),
				'mapping'     => mvweb_pt_get_default_field_mapping(),
			),
			'products' => array(
				'name'        => __( 'Product Catalog', 'mvweb-price-table' ),
				'description' => __( 'Category → Subcategory → Product → Price', 'mvweb-price-table' ),
				'mapping'     => array(
					'schema_version' => '2.0',
					'mode'           => 'mapped',
					'columns'        => array(
						array(
							'index'  => 0,
							'role'   => 'hierarchy_1',
							'label'  => __( 'Category', 'mvweb-price-table' ),
							'format' => 'text',
						),
						array(
							'index'  => 1,
							'role'   => 'hierarchy_2',
							'label'  => __( 'Subcategory', 'mvweb-price-table' ),
							'format' => 'text',
						),
						array(
							'index'  => 2,
							'role'   => 'service_name',
							'label'  => __( 'Product', 'mvweb-price-table' ),
							'format' => 'text',
						),
						array(
							'index'  => 3,
							'role'   => 'service_price',
							'label'  => __( 'Price', 'mvweb-price-table' ),
							'format' => 'currency',
						),
					),
					'inheritance'    => array(
						'enabled'     => false,
						'wildcard'    => '*',
						'show_source' => false,
					),
				),
			),
			'services' => array(
				'name'        => __( 'General Services', 'mvweb-price-table' ),
				'description' => __( 'Category → Service → Time → Price', 'mvweb-price-table' ),
				'mapping'     => array(
					'schema_version' => '2.0',
					'mode'           => 'mapped',
					'columns'        => array(
						array(
							'index'  => 0,
							'role'   => 'hierarchy_1',
							'label'  => __( 'Category', 'mvweb-price-table' ),
							'format' => 'text',
						),
						array(
							'index'  => 1,
							'role'   => 'service_name',
							'label'  => __( 'Service', 'mvweb-price-table' ),
							'format' => 'text',
						),
						array(
							'index'  => 2,
							'role'   => 'service_time',
							'label'  => __( 'Duration', 'mvweb-price-table' ),
							'format' => 'duration',
						),
						array(
							'index'  => 3,
							'role'   => 'service_price',
							'label'  => __( 'Price', 'mvweb-price-table' ),
							'format' => 'currency',
						),
					),
					'inheritance'    => array(
						'enabled'     => false,
						'wildcard'    => '*',
						'show_source' => false,
					),
				),
			),
		);
	}
}
