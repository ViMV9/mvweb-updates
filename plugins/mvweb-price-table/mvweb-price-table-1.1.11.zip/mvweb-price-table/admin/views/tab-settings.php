<?php
/**
 * Settings tab template.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<h2><?php esc_html_e( 'Cache Settings', 'mvweb-price-table' ); ?></h2>
	<table class="form-table">
		<tr>
			<th scope="row">
				<label for="cache_ttl"><?php esc_html_e( 'Cache Duration', 'mvweb-price-table' ); ?></label>
			</th>
			<td>
				<select id="cache_ttl" name="cache_ttl">
					<option value="1800" <?php selected( $settings['cache_ttl'] ?? 3600, 1800 ); ?>><?php esc_html_e( '30 minutes', 'mvweb-price-table' ); ?></option>
					<option value="3600" <?php selected( $settings['cache_ttl'] ?? 3600, 3600 ); ?>><?php esc_html_e( '1 hour', 'mvweb-price-table' ); ?></option>
					<option value="7200" <?php selected( $settings['cache_ttl'] ?? 3600, 7200 ); ?>><?php esc_html_e( '2 hours', 'mvweb-price-table' ); ?></option>
					<option value="21600" <?php selected( $settings['cache_ttl'] ?? 3600, 21600 ); ?>><?php esc_html_e( '6 hours', 'mvweb-price-table' ); ?></option>
					<option value="86400" <?php selected( $settings['cache_ttl'] ?? 3600, 86400 ); ?>><?php esc_html_e( '24 hours', 'mvweb-price-table' ); ?></option>
				</select>
				<p class="description"><?php esc_html_e( 'How long to cache Google Sheets data.', 'mvweb-price-table' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Fallback Cache', 'mvweb-price-table' ); ?></th>
			<td>
				<label>
					<input type="checkbox" name="fallback_enabled" value="1" <?php checked( $settings['fallback_enabled'] ?? true ); ?>>
					<?php esc_html_e( 'Enable fallback cache (use last successful data if Google Sheets is unavailable)', 'mvweb-price-table' ); ?>
				</label>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Clear Cache', 'mvweb-price-table' ); ?></th>
			<td>
				<button type="button" class="button mvweb-pc-clear-cache">
					<?php esc_html_e( 'Clear All Cache', 'mvweb-price-table' ); ?>
				</button>
				<span class="mvweb-pc-cache-status"></span>
			</td>
		</tr>
	</table>

	<h2><?php esc_html_e( 'Display Settings', 'mvweb-price-table' ); ?></h2>
	<table class="form-table">
		<tr>
			<th scope="row">
				<label for="default_preset"><?php esc_html_e( 'Default Preset', 'mvweb-price-table' ); ?></label>
			</th>
			<td>
				<select id="default_preset" name="default_preset">
					<?php foreach ( $presets as $preset_key => $preset_name ) : ?>
						<option value="<?php echo esc_attr( $preset_key ); ?>" <?php selected( $settings['default_preset'] ?? 'light', $preset_key ); ?>>
							<?php echo esc_html( $preset_name ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</td>
		</tr>
		<tr>
			<th scope="row">
				<label for="currency"><?php esc_html_e( 'Currency', 'mvweb-price-table' ); ?></label>
			</th>
			<td>
				<?php
				$currencies        = mvweb_pt_get_currencies();
				$current_currency  = $settings['currency'] ?? 'RUB';
				$custom_currency   = $settings['custom_currency'] ?? '';
				$is_custom         = 'CUSTOM' === $current_currency;
				?>
				<select id="currency" name="currency" class="regular-text">
					<?php foreach ( $currencies as $code => $currency ) : ?>
						<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $current_currency, $code ); ?>>
							<?php echo esc_html( $currency['symbol'] . ' — ' . $currency['name'] . ' (' . $code . ')' ); ?>
						</option>
					<?php endforeach; ?>
					<option value="CUSTOM" <?php selected( $current_currency, 'CUSTOM' ); ?>>
						<?php esc_html_e( '— Custom —', 'mvweb-price-table' ); ?>
					</option>
				</select>
				<div id="custom-currency-wrapper" class="mvweb-pc-custom-currency" style="margin-top: 10px; <?php echo $is_custom ? '' : 'display: none;'; ?>">
					<input
						type="text"
						id="custom_currency"
						name="custom_currency"
						value="<?php echo esc_attr( $custom_currency ); ?>"
						placeholder="<?php esc_attr_e( 'e.g., points, credits, ¤', 'mvweb-price-table' ); ?>"
						class="regular-text"
						maxlength="20"
					>
					<p class="description">
						<?php esc_html_e( 'Enter custom currency symbol or name (max 20 characters).', 'mvweb-price-table' ); ?>
					</p>
				</div>
				<p class="description">
					<?php esc_html_e( 'Select the currency to display prices.', 'mvweb-price-table' ); ?>
				</p>
			</td>
		</tr>
	</table>

	<h2><?php esc_html_e( 'Additional Settings', 'mvweb-price-table' ); ?></h2>
	<table class="form-table">
		<tr>
			<th scope="row"><?php esc_html_e( 'Statistics', 'mvweb-price-table' ); ?></th>
			<td>
				<label>
					<input type="checkbox" name="stats_enabled" value="1" <?php checked( $settings['stats_enabled'] ?? true ); ?>>
					<?php esc_html_e( 'Enable usage statistics collection', 'mvweb-price-table' ); ?>
				</label>
				<p class="description"><?php esc_html_e( 'Track usage statistics like popular brands and models. IP addresses are hashed for privacy.', 'mvweb-price-table' ); ?></p>
			</td>
		</tr>
		<tr>
			<th scope="row"><?php esc_html_e( 'Uninstall', 'mvweb-price-table' ); ?></th>
			<td>
				<label>
					<input type="checkbox" name="keep_data_on_uninstall" value="1" <?php checked( $settings['keep_data_on_uninstall'] ?? false ); ?>>
					<?php esc_html_e( 'Keep data on plugin uninstall', 'mvweb-price-table' ); ?>
				</label>
				<p class="description"><?php esc_html_e( 'If enabled, plugin data (forms, settings, statistics) will not be deleted when the plugin is uninstalled.', 'mvweb-price-table' ); ?></p>
			</td>
		</tr>
	</table>
