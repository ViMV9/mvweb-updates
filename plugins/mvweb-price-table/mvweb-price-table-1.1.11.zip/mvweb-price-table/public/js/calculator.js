/**
 * MVweb Price Table - Frontend JavaScript
 *
 * @package MVweb_Price_Calculator
 * @since   1.0.0
 * @since   2.0.0 Added dynamic hierarchy support.
 */

(function() {
	'use strict';

	/**
	 * Price Table module.
	 */
	const MVwebPriceCalculator = {
		/**
		 * Configuration from WordPress.
		 */
		config: window.mvwebPcConfig || {
			ajaxUrl: '/wp-admin/admin-ajax.php',
			nonce: '',
			currency: '₽',
			useChoices: true,
			i18n: {
				loading: 'Loading...',
				error: 'An error occurred. Please try again.',
				noResults: 'No prices found.',
				searchPlaceholder: 'Search...',
				noChoicesText: 'No options available',
				itemSelectText: '',
				onRequest: 'On request'
			}
		},

		/**
		 * Choices.js instances storage.
		 */
		choicesInstances: new Map(),

		/**
		 * Initialize all calculator instances on the page.
		 */
		init: function() {
			const calculators = document.querySelectorAll('.mvweb-pc');

			calculators.forEach(function(calculator) {
				MVwebPriceCalculator.initInstance(calculator);
			});
		},

		/**
		 * Initialize a single calculator instance.
		 *
		 * @param {HTMLElement} container Calculator container element.
		 */
		initInstance: function(container) {
			const formId = container.dataset.formId;
			const autoSubmit = container.dataset.autoSubmit === 'true';
			const useChoices = MVwebPriceCalculator.config.useChoices && typeof Choices !== 'undefined';

			// v2.0: Get hierarchy configuration from data attributes.
			const hierarchyDepth = parseInt(container.dataset.hierarchyDepth, 10) || 3;
			const mappingMode = container.dataset.mappingMode || 'legacy';
			const isLegacyMode = mappingMode === 'legacy';

			// v2.3: "show all" mode — load all prices for the specified branch.
			const showAll = container.dataset.showAll === 'true';
			let showAllActive = showAll; // Tracks if "all" mode is currently active (reset on user interaction).

			// Elements.
			const form = container.querySelector('.mvweb-pc__form');
			const submitButton = container.querySelector('.mvweb-pc__button--submit');
			const resultsContainer = container.querySelector('.mvweb-pc__results');
			const loadingIndicator = container.querySelector('.mvweb-pc__loading');
			const errorContainer = container.querySelector('.mvweb-pc__error');

			// v2.0: Dynamic hierarchy selects.
			const hierarchySelects = {};
			for (let i = 1; i <= hierarchyDepth; i++) {
				const select = container.querySelector('.mvweb-pc__select--level-' + i);
				if (select) {
					hierarchySelects[i] = select;
				}
			}

			// Legacy compatibility: map old selectors to new structure.
			const brandSelect = hierarchySelects[1] || container.querySelector('.mvweb-pc__select--brand');
			const typeSelect = hierarchySelects[2] || container.querySelector('.mvweb-pc__select--type');
			const modelSelect = hierarchySelects[3] || container.querySelector('.mvweb-pc__select--model');

			// v2.0: Dynamic state.
			const state = {
				formId: formId,
				hierarchyDepth: hierarchyDepth,
				mappingMode: mappingMode,
				levels: {}, // Dynamic levels: { 1: 'Apple', 2: 'iPhone', 3: 'iPhone 15' }
				isLoading: false,
				// Legacy compatibility.
				brand: '',
				type: '',
				model: ''
			};

			// Initialize levels state.
			for (let i = 1; i <= hierarchyDepth; i++) {
				state.levels[i] = '';
			}

			// v2.0: Dynamic Choices.js instances.
			const choices = {};
			for (let i = 1; i <= hierarchyDepth; i++) {
				choices[i] = null;
			}
			// Legacy compatibility.
			choices.brand = null;
			choices.type = null;
			choices.model = null;

			/**
			 * Initialize Choices.js on a select element.
			 *
			 * @param {HTMLSelectElement} select     Select element.
			 * @param {string}            type       Type identifier (brand, type, model).
			 * @param {boolean}           searchable Whether search is enabled.
			 * @return {Choices|null} Choices instance or null.
			 */
			function initChoices(select, type, searchable) {
				if (!useChoices) {
					return null;
				}

				const instanceKey = container.id + '-' + type;

				// Destroy existing instance if any.
				if (MVwebPriceCalculator.choicesInstances.has(instanceKey)) {
					MVwebPriceCalculator.choicesInstances.get(instanceKey).destroy();
					MVwebPriceCalculator.choicesInstances.delete(instanceKey);
				}

				// Get placeholder from data attribute.
				const placeholderText = select.dataset.placeholder || '';

				try {
					const instance = new Choices(select, {
						searchEnabled: searchable,
						searchPlaceholderValue: MVwebPriceCalculator.config.i18n.searchPlaceholder,
						noResultsText: MVwebPriceCalculator.config.i18n.noChoicesText,
						noChoicesText: MVwebPriceCalculator.config.i18n.noChoicesText,
						itemSelectText: MVwebPriceCalculator.config.i18n.itemSelectText,
						shouldSort: false,
						allowHTML: false,
						searchResultLimit: 50,
						position: 'bottom',
						resetScrollPosition: true,
						placeholder: true,
						placeholderValue: placeholderText,
						classNames: {
							containerOuter: ['choices', 'mvweb-pc-choices'],
							containerInner: ['choices__inner'],
							input: ['choices__input'],
							inputCloned: ['choices__input--cloned'],
							list: ['choices__list'],
							listItems: ['choices__list--multiple'],
							listSingle: ['choices__list--single'],
							listDropdown: ['choices__list--dropdown'],
							item: ['choices__item'],
							itemSelectable: ['choices__item--selectable'],
							itemDisabled: ['choices__item--disabled'],
							itemChoice: ['choices__item--choice'],
							group: ['choices__group'],
							groupHeading: ['choices__heading'],
							placeholder: ['choices__placeholder'],
							button: ['choices__button'],
							activeState: ['is-active'],
							focusState: ['is-focused'],
							openState: ['is-open'],
							disabledState: ['is-disabled'],
							highlightedState: ['is-highlighted'],
							selectedState: ['is-selected'],
							flippedState: ['is-flipped'],
							loadingState: ['is-loading'],
							noResults: ['has-no-results'],
							noChoices: ['has-no-choices']
						}
					});

					MVwebPriceCalculator.choicesInstances.set(instanceKey, instance);

					// Fix: temporarily override ancestor styles that clip/hide the dropdown.
					// Themes may use overflow:hidden or low z-index on wrapper elements,
					// causing the Choices.js dropdown to be clipped or hidden behind siblings.
					var savedAncestorStyles = [];
					instance.passedElement.element.addEventListener('showDropdown', function() {
						savedAncestorStyles = [];
						var el = container.parentElement;
						while (el && el !== document.documentElement) {
							var style = window.getComputedStyle(el);
							var needsFix = false;
							var saved = { element: el, overflow: '', zIndex: '' };

							if (style.overflow === 'hidden' || style.overflowY === 'hidden') {
								saved.overflow = el.style.overflow;
								el.style.overflow = 'visible';
								needsFix = true;
							}
							if (style.position !== 'static' && (style.zIndex === 'auto' || (parseInt(style.zIndex, 10) || 0) < 100)) {
								saved.zIndex = el.style.zIndex;
								el.style.zIndex = '9999';
								needsFix = true;
							}
							if (needsFix) {
								savedAncestorStyles.push(saved);
							}
							el = el.parentElement;
						}
					});
					instance.passedElement.element.addEventListener('hideDropdown', function() {
						for (var i = 0; i < savedAncestorStyles.length; i++) {
							var s = savedAncestorStyles[i];
							if (s.overflow !== undefined && s.overflow !== '') {
								s.element.style.overflow = s.overflow;
							} else if (s.overflow === '') {
								s.element.style.overflow = '';
							}
							if (s.zIndex !== undefined) {
								s.element.style.zIndex = s.zIndex;
							}
						}
						savedAncestorStyles = [];
					});

					return instance;
				} catch (error) {
					console.warn('MVweb PC: Could not initialize Choices.js', error);
					return null;
				}
			}

			/**
			 * Show loading state.
			 */
			function showLoading() {
				state.isLoading = true;
				loadingIndicator.style.display = 'flex';
				resultsContainer.style.display = 'none';
				errorContainer.style.display = 'none';
			}

			/**
			 * Hide loading state.
			 */
			function hideLoading() {
				state.isLoading = false;
				loadingIndicator.style.display = 'none';
			}

			/**
			 * Show error message.
			 *
			 * @param {string} message Error message.
			 */
			function showError(message) {
				hideLoading();
				const errorText = errorContainer.querySelector('.mvweb-pc__error-text');
				errorText.textContent = message || MVwebPriceCalculator.config.i18n.error;
				errorContainer.style.display = 'flex';
				resultsContainer.style.display = 'none';
			}

			/**
			 * Make AJAX request.
			 *
			 * @param {string} action   AJAX action name.
			 * @param {Object} data     Request data.
			 * @returns {Promise}       Promise resolving to response data.
			 */
			function ajaxRequest(action, data) {
				const formData = new FormData();
				formData.append('action', action);
				formData.append('nonce', MVwebPriceCalculator.config.nonce);
				formData.append('form_id', state.formId);

				for (const key in data) {
					if (Object.prototype.hasOwnProperty.call(data, key)) {
						formData.append(key, data[key]);
					}
				}

				return fetch(MVwebPriceCalculator.config.ajaxUrl, {
					method: 'POST',
					credentials: 'same-origin',
					body: formData
				})
				.then(function(response) {
					if (!response.ok) {
						throw new Error('HTTP ' + response.status);
					}
					return response.json();
				})
				.then(function(response) {
					if (!response.success) {
						const errorMessage = (response.data && response.data.message)
							? response.data.message
							: MVwebPriceCalculator.config.i18n.error;
						throw new Error(errorMessage);
					}
					return response.data;
				});
			}

			/**
			 * Clear all children from an element.
			 *
			 * @param {HTMLElement} element Element to clear.
			 */
			function clearElement(element) {
				while (element.firstChild) {
					element.removeChild(element.firstChild);
				}
			}

			/**
			 * Update Choices.js with new options.
			 *
			 * @param {Choices}           choicesInstance Choices instance.
			 * @param {HTMLSelectElement} select          Select element.
			 * @param {Object}            options         Regular options.
			 * @param {Object}            grouped         Grouped options.
			 * @param {string}            placeholder     Placeholder text.
			 */
			function updateChoices(choicesInstance, select, options, grouped, placeholder) {
				if (!choicesInstance) {
					populateSelect(select, options, grouped, placeholder);
					return;
				}

				// Build choices array (no placeholder - it's handled by Choices.js config).
				const choicesArray = [];

				// Add regular options.
				if (options && typeof options === 'object') {
					for (const key in options) {
						if (Object.prototype.hasOwnProperty.call(options, key)) {
							choicesArray.push({
								value: key,
								label: options[key]
							});
						}
					}
				}

				// Add grouped options.
				if (grouped && typeof grouped === 'object') {
					for (const groupName in grouped) {
						if (Object.prototype.hasOwnProperty.call(grouped, groupName)) {
							const groupChoices = [];
							const groupOptions = grouped[groupName];

							for (const key in groupOptions) {
								if (Object.prototype.hasOwnProperty.call(groupOptions, key)) {
									groupChoices.push({
										value: key,
										label: groupOptions[key]
									});
								}
							}

							if (groupChoices.length > 0) {
								choicesArray.push({
									label: groupName,
									id: groupName.toLowerCase().replace(/\s+/g, '-'),
									disabled: false,
									choices: groupChoices
								});
							}
						}
					}
				}

				// Clear and set new choices.
				choicesInstance.clearStore();
				choicesInstance.setChoices(choicesArray, 'value', 'label', true);
			}

			/**
			 * Populate select element with options (fallback without Choices.js).
			 *
			 * @param {HTMLSelectElement} select      Select element.
			 * @param {Object}            options     Options object (key => label).
			 * @param {Object}            grouped     Grouped options (group => options).
			 * @param {string}            placeholder Placeholder text.
			 */
			function populateSelect(select, options, grouped, placeholder) {
				// Clear existing options.
				clearElement(select);

				// Add placeholder.
				const placeholderOption = document.createElement('option');
				placeholderOption.value = '';
				placeholderOption.textContent = placeholder;
				select.appendChild(placeholderOption);

				// Add regular options.
				if (options && typeof options === 'object') {
					for (const key in options) {
						if (Object.prototype.hasOwnProperty.call(options, key)) {
							const option = document.createElement('option');
							option.value = key;
							option.textContent = options[key];
							select.appendChild(option);
						}
					}
				}

				// Add grouped options.
				if (grouped && typeof grouped === 'object') {
					for (const groupName in grouped) {
						if (Object.prototype.hasOwnProperty.call(grouped, groupName)) {
							const optgroup = document.createElement('optgroup');
							optgroup.label = groupName;

							const groupOptions = grouped[groupName];
							for (const key in groupOptions) {
								if (Object.prototype.hasOwnProperty.call(groupOptions, key)) {
									const option = document.createElement('option');
									option.value = key;
									option.textContent = groupOptions[key];
									optgroup.appendChild(option);
								}
							}

							select.appendChild(optgroup);
						}
					}
				}
			}

			/**
			 * Reset select and disable it.
			 *
			 * @param {Choices|null}      choicesInstance Choices instance.
			 * @param {HTMLSelectElement} select          Select element.
			 * @param {string}            placeholder     Placeholder text.
			 */
			function resetSelect(choicesInstance, select, placeholder) {
				if (choicesInstance) {
					// Clear all choices - placeholder is shown automatically via Choices.js config.
					choicesInstance.clearStore();
					choicesInstance.disable();
				} else {
					clearElement(select);
					const option = document.createElement('option');
					option.value = '';
					option.textContent = placeholder;
					option.disabled = true;
					option.selected = true;
					option.hidden = true;
					select.appendChild(option);
					select.disabled = true;
					select.value = '';
				}
			}

			/**
			 * Enable a Choices instance.
			 *
			 * @param {Choices|null}      choicesInstance Choices instance.
			 * @param {HTMLSelectElement} select          Select element.
			 */
			function enableSelect(choicesInstance, select) {
				if (choicesInstance) {
					choicesInstance.enable();
				} else {
					select.disabled = false;
				}
			}

			/**
			 * Set value on Choices instance.
			 *
			 * @param {Choices|null}      choicesInstance Choices instance.
			 * @param {HTMLSelectElement} select          Select element.
			 * @param {string}            value           Value to set.
			 */
			function setSelectValue(choicesInstance, select, value) {
				if (choicesInstance) {
					choicesInstance.setChoiceByValue(value);
				} else {
					select.value = value;
				}
			}

			/**
			 * Get placeholder text from select.
			 *
			 * @param {HTMLSelectElement} select Select element.
			 * @return {string} Placeholder text.
			 */
			function getPlaceholder(select) {
				// First try data-placeholder attribute, then fall back to first option.
				const dataPlaceholder = select.dataset.placeholder;
				if (dataPlaceholder) {
					return dataPlaceholder;
				}
				const firstOption = select.querySelector('option');
				return firstOption ? firstOption.textContent : '';
			}

			/**
			 * v2.0: Load a hierarchy level.
			 *
			 * Universal function that replaces loadBrands/loadTypes/loadModels.
			 * Uses the new get_hierarchy_level endpoint for mapped mode,
			 * falls back to legacy endpoints for legacy mode.
			 *
			 * @param {number} level Level number to load (1-based).
			 */
			function loadHierarchyLevel(level) {
				const select = hierarchySelects[level];
				if (!select) {
					return;
				}

				const placeholder = getPlaceholder(select);

				// For level 1, just load it directly.
				// For other levels, check if parent levels are selected.
				if (level > 1) {
					let hasAllParents = true;
					for (let i = 1; i < level; i++) {
						if (!state.levels[i]) {
							hasAllParents = false;
							break;
						}
					}

					if (!hasAllParents) {
						// Reset this level and all subsequent levels.
						for (let i = level; i <= hierarchyDepth; i++) {
							const levelSelect = hierarchySelects[i];
							if (levelSelect) {
								resetSelect(choices[i], levelSelect, getPlaceholder(levelSelect));
							}
						}
						return;
					}
				}

				showLoading();

				// Build parent values for the request.
				const parentValues = {};
				for (let i = 1; i < level; i++) {
					parentValues['level_' + i] = state.levels[i];
				}

				// Use universal endpoint.
				ajaxRequest('mvweb_pt_get_hierarchy_level', {
					level: level,
					...parentValues
				})
					.then(function(data) {
						hideLoading();

						const items = data.items || {};
						const grouped = data.grouped || null;

						updateChoices(choices[level], select, items, grouped, placeholder);
						enableSelect(choices[level], select);

						// Reset subsequent levels.
						for (let i = level + 1; i <= hierarchyDepth; i++) {
							const levelSelect = hierarchySelects[i];
							if (levelSelect) {
								resetSelect(choices[i], levelSelect, getPlaceholder(levelSelect));
							}
						}

						// Check for default value.
						// Note: data-default-level-1 becomes dataset['defaultLevel-1'] (hyphen before number is preserved).
						const defaultValue = container.dataset['defaultLevel-' + level];

						// Case-insensitive match: find the actual key in items.
						let matchedKey = null;
						if (defaultValue) {
							const defaultValueLower = defaultValue.toLowerCase();
							for (const key in items) {
								if (Object.prototype.hasOwnProperty.call(items, key) && key.toLowerCase() === defaultValueLower) {
									matchedKey = key;
									break;
								}
							}
						}
						if (matchedKey) {
							setSelectValue(choices[level], select, matchedKey);
							state.levels[level] = matchedKey;

							// Sync legacy state.
							syncLegacyState();

							// v2.3: In "all" mode, check if next level has a default.
							// If not — load all prices for the current branch,
							// but still load next level so user can refine selection.
							if (showAllActive && level < hierarchyDepth) {
								const nextDefault = container.dataset['defaultLevel-' + (level + 1)];
								if (!nextDefault) {
									// No deeper default specified — load all prices at this depth.
									loadAllPrices();
									// Continue to load next level for user interaction.
									loadHierarchyLevel(level + 1);
									return;
								}
							}

							// Load next level if not the last.
							if (level < hierarchyDepth) {
								loadHierarchyLevel(level + 1);
							} else {
								// Last level selected, update button and maybe auto-submit.
								updateSubmitButton();
								if (showAllActive) {
									loadAllPrices();
								} else if (autoSubmit) {
									loadPricesV2();
								} else {
									// Auto-load prices when last level is preset.
									loadPricesV2();
								}
							}
						} else if (showAllActive) {
							// v2.3: Default value not found in items but "all" mode is active.
							// This shouldn't normally happen, but handle gracefully.
							loadAllPrices();
						}
					})
					.catch(function(error) {
						showError(error.message);
					});
			}

			/**
			 * v2.0: Sync legacy state variables with dynamic levels.
			 *
			 * Keeps brand/type/model in sync with levels[1]/levels[2]/levels[3].
			 */
			function syncLegacyState() {
				state.brand = state.levels[1] || '';
				state.type = state.levels[2] || '';
				state.model = state.levels[3] || '';
			}

			/**
			 * v2.0: Load prices using dynamic hierarchy.
			 */
			function loadPricesV2() {
				// Check if all levels are selected.
				for (let i = 1; i <= hierarchyDepth; i++) {
					if (!state.levels[i]) {
						return;
					}
				}

				showLoading();

				// Build level values for the request.
				const levelValues = {};
				for (let i = 1; i <= hierarchyDepth; i++) {
					levelValues['level_' + i] = state.levels[i];
				}

				// Legacy compatibility.
				levelValues.brand = state.levels[1] || '';
				levelValues.type = state.levels[2] || '';
				levelValues.model = state.levels[3] || '';

				ajaxRequest('mvweb_pt_get_prices', levelValues)
					.then(function(data) {
						hideLoading();
						displayResults(data.services);
					})
					.catch(function(error) {
						showError(error.message);
					});
			}

			/**
			 * v2.3: Load all prices for the specified hierarchy branch.
			 *
			 * Used when the "all" shortcode attribute is set.
			 * Calls the mvweb_pt_get_all_prices endpoint and renders
			 * results with additional hierarchy columns.
			 */
			function loadAllPrices() {
				// Collect specified level values.
				const levelValues = {};
				for (let i = 1; i <= hierarchyDepth; i++) {
					if (state.levels[i]) {
						levelValues['level_' + i] = state.levels[i];
					} else {
						break;
					}
				}

				if (Object.keys(levelValues).length === 0) {
					return;
				}

				showLoading();

				ajaxRequest('mvweb_pt_get_all_prices', levelValues)
					.then(function(data) {
						hideLoading();
						displayAllResults(data.services, data.hierarchy_columns);
					})
					.catch(function(error) {
						showError(error.message);
					});
			}

			/**
			 * v2.3: Display results with hierarchy columns.
			 *
			 * Similar to displayResults() but prepends hierarchy columns
			 * (e.g. Type, Model) before the service columns.
			 *
			 * @param {Array} services         Array of service objects with hierarchy info.
			 * @param {Array} hierarchyColumns  Array of {level, label} for extra columns.
			 */
			function displayAllResults(services, hierarchyColumns) {
				const tbody = resultsContainer.querySelector('.mvweb-pc__table-body');
				const noResults = resultsContainer.querySelector('.mvweb-pc__no-results');
				const tableWrapper = resultsContainer.querySelector('.mvweb-pc__table-wrapper');
				const titleElement = resultsContainer.querySelector('.mvweb-pc__results-title');
				const thead = resultsContainer.querySelector('.mvweb-pc__table-head tr');

				// Clear existing rows.
				clearElement(tbody);

				// Remove any previously added hierarchy headers.
				if (thead) {
					const existingHierarchyThs = thead.querySelectorAll('.mvweb-pc__table-th--hierarchy');
					existingHierarchyThs.forEach(function(th) {
						th.remove();
					});
				}

				// Build service column configuration from existing table headers.
				const serviceColumns = [];
				if (thead) {
					const headers = thead.querySelectorAll('.mvweb-pc__table-th:not(.mvweb-pc__table-th--hierarchy)');
					headers.forEach(function(th) {
						serviceColumns.push({
							role: th.dataset.role || 'unknown',
							format: th.dataset.format || 'text',
							label: th.textContent.trim(),
							fullWidthMobile: th.dataset.fullWidthMobile === 'true'
						});
					});
				}

				if (!services || services.length === 0) {
					noResults.style.display = 'block';
					tableWrapper.style.display = 'none';
					resultsContainer.style.display = 'block';
					return;
				}

				noResults.style.display = 'none';
				tableWrapper.style.display = 'block';

				// Add hierarchy column headers before service columns.
				if (thead && hierarchyColumns && hierarchyColumns.length > 0) {
					const firstTh = thead.querySelector('.mvweb-pc__table-th');
					hierarchyColumns.forEach(function(col) {
						const th = document.createElement('th');
						th.className = 'mvweb-pc__table-th mvweb-pc__table-th--hierarchy';
						th.dataset.level = col.level;
						th.textContent = col.label;
						thead.insertBefore(th, firstTh);
					});
				}

				// Update results title.
				if (titleElement) {
					// Build title from selected levels.
					const titleParts = [];
					for (let i = 1; i <= hierarchyDepth; i++) {
						if (state.levels[i]) {
							const select = hierarchySelects[i];
							if (select) {
								const selectedOption = select.options[select.selectedIndex];
								if (selectedOption && selectedOption.value) {
									titleParts.push(selectedOption.textContent);
								}
							}
						}
					}
					titleElement.textContent = titleParts.join(' — ');
				}

				// Check if reduced motion is preferred.
				const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

				// Add rows.
				services.forEach(function(service) {
					const row = document.createElement('tr');
					row.className = 'mvweb-pc__table-row';

					if (!prefersReducedMotion) {
						row.classList.add('mvweb-pc__table-row--animate');
					}

					// Add hierarchy cells first.
					if (hierarchyColumns) {
						hierarchyColumns.forEach(function(col) {
							const cell = document.createElement('td');
							cell.className = 'mvweb-pc__table-td mvweb-pc__table-td--hierarchy';
							cell.setAttribute('data-label', col.label + ':');
							const hierValue = service.hierarchy ? service.hierarchy['level_' + col.level] : '';
							cell.textContent = hierValue || '—';
							row.appendChild(cell);
						});
					}

					// Add service cells.
					serviceColumns.forEach(function(col) {
						const cell = document.createElement('td');
						const roleClass = col.role.replace('service_', '');
						cell.className = 'mvweb-pc__table-td mvweb-pc__table-td--' + roleClass;
						cell.setAttribute('data-label', col.label + ':');

						if (col.fullWidthMobile) {
							cell.classList.add('mvweb-pc__table-td--full-mobile');
						}

						let value = getCellValue(service, col.role, col.format);

						if (col.role === 'service_price') {
							if (!value || value === '' || value === '0' || value === '0 ₽') {
								value = MVwebPriceCalculator.config.i18n.onRequest;
								cell.classList.add('mvweb-pc__table-td--on-request');
							}
						} else if (!value) {
							value = '—';
						}

						cell.textContent = value;
						row.appendChild(cell);
					});

					tbody.appendChild(row);
				});

				// Check table scroll.
				checkTableScroll(tableWrapper);

				// Show results.
				resultsContainer.style.display = 'block';
				errorContainer.style.display = 'none';

				// Smooth scroll to results.
				scrollToResults();
			}

			/**
			 * v2.0: Handle hierarchy select change.
			 *
			 * @param {number} level Level that changed.
			 */
			function onHierarchyLevelChange(level) {
				const select = hierarchySelects[level];
				if (!select) {
					return;
				}

				state.levels[level] = select.value;

				// Clear subsequent levels.
				for (let i = level + 1; i <= hierarchyDepth; i++) {
					state.levels[i] = '';
				}

				// Sync legacy state.
				syncLegacyState();

				// v2.3: Deactivate "all" mode on user interaction and clean up hierarchy headers.
				if (showAllActive) {
					showAllActive = false;
					const thead = resultsContainer.querySelector('.mvweb-pc__table-head tr');
					if (thead) {
						const hierarchyThs = thead.querySelectorAll('.mvweb-pc__table-th--hierarchy');
						hierarchyThs.forEach(function(th) {
							th.remove();
						});
					}
				}

				// Hide results.
				resultsContainer.style.display = 'none';

				// Load next level or update submit button.
				if (level < hierarchyDepth && select.value) {
					loadHierarchyLevel(level + 1);
				}

				updateSubmitButton();

				// Auto-submit if last level and autoSubmit is enabled.
				if (level === hierarchyDepth && autoSubmit && select.value) {
					loadPricesV2();
				}
			}

			/**
			 * v2.0: Check if all hierarchy levels are selected.
			 *
			 * @return {boolean} True if all levels selected.
			 */
			function isHierarchyComplete() {
				for (let i = 1; i <= hierarchyDepth; i++) {
					if (!state.levels[i]) {
						return false;
					}
				}
				return true;
			}

			/**
			 * Load brands.
			 */
			function loadBrands() {
				showLoading();

				ajaxRequest('mvweb_pt_get_brands', {})
					.then(function(data) {
						hideLoading();

						const placeholder = getPlaceholder(brandSelect);

						if (choices.brand) {
							updateChoices(choices.brand, brandSelect, data.brands, null, placeholder);
							choices.brand.enable();
						} else {
							populateSelect(brandSelect, data.brands, null, placeholder);
							brandSelect.disabled = false;
						}

						// Load default brand if set (using universal level-1 attribute).
						const defaultBrand = container.dataset.defaultLevel1;
						if (defaultBrand && data.brands[defaultBrand]) {
							setSelectValue(choices.brand, brandSelect, defaultBrand);
							state.brand = defaultBrand;
							loadTypes();
						}
					})
					.catch(function(error) {
						showError(error.message);
					});
			}

			/**
			 * Load types for selected brand.
			 */
			function loadTypes() {
				const typePlaceholder = getPlaceholder(typeSelect);
				const modelPlaceholder = getPlaceholder(modelSelect);

				if (!state.brand) {
					resetSelect(choices.type, typeSelect, typePlaceholder);
					resetSelect(choices.model, modelSelect, modelPlaceholder);
					return;
				}

				showLoading();

				ajaxRequest('mvweb_pt_get_types', { brand: state.brand })
					.then(function(data) {
						hideLoading();

						updateChoices(choices.type, typeSelect, data.types, null, typePlaceholder);
						enableSelect(choices.type, typeSelect);

						// Reset model.
						resetSelect(choices.model, modelSelect, modelPlaceholder);

						// Load default type if set (using universal level-2 attribute).
						const defaultType = container.dataset.defaultLevel2;
						if (defaultType && data.types[defaultType]) {
							setSelectValue(choices.type, typeSelect, defaultType);
							state.type = defaultType;
							loadModels();
						}
					})
					.catch(function(error) {
						showError(error.message);
					});
			}

			/**
			 * Load models for selected type.
			 */
			function loadModels() {
				const modelPlaceholder = getPlaceholder(modelSelect);

				if (!state.brand || !state.type) {
					resetSelect(choices.model, modelSelect, modelPlaceholder);
					return;
				}

				showLoading();

				ajaxRequest('mvweb_pt_get_models', { brand: state.brand, type: state.type })
					.then(function(data) {
						hideLoading();

						updateChoices(choices.model, modelSelect, data.models, data.grouped, modelPlaceholder);
						enableSelect(choices.model, modelSelect);

						// Load default model if set (using universal level-3 attribute).
						const defaultModel = container.dataset.defaultLevel3;
						if (defaultModel) {
							// Check if model exists in regular models or grouped (case-insensitive).
							let matchedModel = null;
							const defaultModelLower = defaultModel.toLowerCase();

							// Check regular models.
							for (const key in data.models) {
								if (Object.prototype.hasOwnProperty.call(data.models, key)) {
									if (key.toLowerCase() === defaultModelLower) {
										matchedModel = key;
										break;
									}
								}
							}

							// Check grouped models if not found.
							if (!matchedModel && data.grouped) {
								for (const groupName in data.grouped) {
									if (Object.prototype.hasOwnProperty.call(data.grouped, groupName)) {
										const groupOptions = data.grouped[groupName];
										for (const key in groupOptions) {
											if (Object.prototype.hasOwnProperty.call(groupOptions, key)) {
												if (key.toLowerCase() === defaultModelLower) {
													matchedModel = key;
													break;
												}
											}
										}
										if (matchedModel) {
											break;
										}
									}
								}
							}

							if (matchedModel) {
								setSelectValue(choices.model, modelSelect, matchedModel);
								state.model = matchedModel;
								updateSubmitButton();

								// Auto-load prices when model is preset (regardless of autoSubmit setting).
								loadPrices();
							}
						}
					})
					.catch(function(error) {
						showError(error.message);
					});
			}

			/**
			 * Load prices for selected model.
			 */
			function loadPrices() {
				if (!state.brand || !state.type || !state.model) {
					return;
				}

				showLoading();

				ajaxRequest('mvweb_pt_get_prices', {
					brand: state.brand,
					type: state.type,
					model: state.model
				})
					.then(function(data) {
						hideLoading();
						displayResults(data.services);
					})
					.catch(function(error) {
						showError(error.message);
					});
			}

			/**
			 * Display price results with animations.
			 *
			 * v2.0: Supports dynamic columns based on service_columns from server response.
			 *
			 * @param {Array}  services Array of service objects.
			 * @param {Array}  columns  Optional column configuration from server.
			 */
			function displayResults(services, columns) {
				const tbody = resultsContainer.querySelector('.mvweb-pc__table-body');
				const noResults = resultsContainer.querySelector('.mvweb-pc__no-results');
				const tableWrapper = resultsContainer.querySelector('.mvweb-pc__table-wrapper');
				const titleElement = resultsContainer.querySelector('.mvweb-pc__results-title');
				const thead = resultsContainer.querySelector('.mvweb-pc__table-head tr');

				// Clear existing rows.
				clearElement(tbody);

				// Get column configuration from table headers.
				const tableColumns = [];
				if (thead) {
					const headers = thead.querySelectorAll('.mvweb-pc__table-th');
					headers.forEach(function(th) {
						tableColumns.push({
							role: th.dataset.role || 'unknown',
							format: th.dataset.format || 'text',
							label: th.textContent.trim(),
							fullWidthMobile: th.dataset.fullWidthMobile === 'true'
						});
					});
				}

				if (!services || services.length === 0) {
					noResults.style.display = 'block';
					tableWrapper.style.display = 'none';
				} else {
					noResults.style.display = 'none';
					tableWrapper.style.display = 'block';

					// v2.0: Get selected label from the last hierarchy level.
					let selectedLabel = '';
					const lastLevelSelect = hierarchySelects[hierarchyDepth];
					if (lastLevelSelect) {
						const selectedOption = lastLevelSelect.options[lastLevelSelect.selectedIndex];
						selectedLabel = selectedOption ? selectedOption.textContent : '';
					} else if (modelSelect) {
						// Legacy fallback.
						const selectedOption = modelSelect.options[modelSelect.selectedIndex];
						selectedLabel = selectedOption ? selectedOption.textContent : '';
					}

					if (titleElement && selectedLabel) {
						titleElement.textContent = selectedLabel;
					}

					// Check if reduced motion is preferred.
					const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

					// Add rows with staggered animation.
					services.forEach(function(service, index) {
						const row = document.createElement('tr');
						row.className = 'mvweb-pc__table-row';

						// Add animation class unless reduced motion is preferred.
						if (!prefersReducedMotion) {
							row.classList.add('mvweb-pc__table-row--animate');
						}

						// v2.0: Build cells based on table column configuration.
						tableColumns.forEach(function(col) {
							const cell = document.createElement('td');
							const roleClass = col.role.replace('service_', '');
							cell.className = 'mvweb-pc__table-td mvweb-pc__table-td--' + roleClass;

							// Add data-label for mobile responsive table.
							cell.setAttribute('data-label', col.label + ':');

							// Add full-width-mobile modifier if configured.
							if (col.fullWidthMobile) {
								cell.classList.add('mvweb-pc__table-td--full-mobile');
							}

							// Get value based on role.
							let value = getCellValue(service, col.role, col.format);

							// Handle special formatting.
							if (col.role === 'service_price') {
								if (!value || value === '' || value === '0' || value === '0 ₽') {
									value = MVwebPriceCalculator.config.i18n.onRequest;
									cell.classList.add('mvweb-pc__table-td--on-request');
								}
							} else if (!value) {
								value = '—';
							}

							cell.textContent = value;
							row.appendChild(cell);
						});

						tbody.appendChild(row);
					});

					// Check if table is scrollable on mobile.
					checkTableScroll(tableWrapper);
				}

				// Show results container.
				resultsContainer.style.display = 'block';
				errorContainer.style.display = 'none';

				// Smooth scroll to results.
				scrollToResults();
			}

			/**
			 * v2.0: Get cell value from service object based on role.
			 *
			 * @param {Object} service Service object from response.
			 * @param {string} role    Column role (e.g., 'service_name', 'service_price').
			 * @param {string} format  Display format.
			 * @return {string} Formatted value.
			 */
			function getCellValue(service, role, format) {
				// Map roles to service object keys.
				const roleMap = {
					'service_name': 'name',
					'service_price': 'price_display',
					'service_time': 'time',
					'service_group': 'group',
					'meta_note': 'note',
					'meta_warranty': 'warranty',
					'meta_sku': 'sku',
					'meta_custom_1': 'custom_1',
					'meta_custom_2': 'custom_2'
				};

				const key = roleMap[role] || role.replace('service_', '').replace('meta_', '');
				let value = service[key] || '';

				// Apply format-specific processing.
				if (format === 'currency' && value && !isNaN(parseFloat(value))) {
					// Currency formatting is done server-side, just return as-is.
					return service.price_display || value;
				}

				return value;
			}

			/**
			 * Check if table is scrollable and add indicator.
			 *
			 * @param {HTMLElement} tableWrapper Table wrapper element.
			 */
			function checkTableScroll(tableWrapper) {
				const table = tableWrapper.querySelector('.mvweb-pc__table');
				if (table && tableWrapper.scrollWidth > tableWrapper.clientWidth) {
					tableWrapper.classList.add('mvweb-pc__table-wrapper--scrollable');
				} else {
					tableWrapper.classList.remove('mvweb-pc__table-wrapper--scrollable');
				}
			}

			/**
			 * Smooth scroll to results.
			 */
			function scrollToResults() {
				// Check if reduced motion is preferred.
				const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

				if (prefersReducedMotion) {
					resultsContainer.scrollIntoView({ block: 'nearest' });
				} else {
					resultsContainer.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
				}
			}

			/**
			 * Update submit button state.
			 *
			 * v2.0: Uses isHierarchyComplete() for dynamic hierarchy support.
			 */
			function updateSubmitButton() {
				if (submitButton) {
					// v2.0: Check if all hierarchy levels are selected.
					const allLevelsSelected = isHierarchyComplete();
					submitButton.disabled = !allLevelsSelected || state.isLoading;

					// Toggle loading class.
					if (state.isLoading) {
						submitButton.classList.add('mvweb-pc__button--loading');
					} else {
						submitButton.classList.remove('mvweb-pc__button--loading');
					}
				}
			}

			// v2.0: Initialize Choices.js on dynamic hierarchy selects.
			if (useChoices) {
				for (let level = 1; level <= hierarchyDepth; level++) {
					const select = hierarchySelects[level];
					if (select) {
						choices[level] = initChoices(select, 'level-' + level, true);

						// Disable all levels except the first.
						if (level > 1 && choices[level]) {
							choices[level].disable();
						}
					}
				}

				// Legacy compatibility: map choices to old names.
				choices.brand = choices[1];
				choices.type = choices[2];
				choices.model = choices[3];
			}

			// v2.0: Event listeners for dynamic hierarchy.
			for (let level = 1; level <= hierarchyDepth; level++) {
				const select = hierarchySelects[level];
				if (select) {
					// Use closure to capture level value.
					(function(currentLevel) {
						select.addEventListener('change', function() {
							onHierarchyLevelChange(currentLevel);
						});
					})(level);
				}
			}

			// Form submit.
			if (form) {
				form.addEventListener('submit', function(e) {
					e.preventDefault();

					if (isHierarchyComplete() && !state.isLoading) {
						loadPricesV2();
					}
				});
			}

			// Handle window resize for scroll indicator.
			let resizeTimeout;
			window.addEventListener('resize', function() {
				clearTimeout(resizeTimeout);
				resizeTimeout = setTimeout(function() {
					const tableWrapper = resultsContainer.querySelector('.mvweb-pc__table-wrapper');
					if (tableWrapper && resultsContainer.style.display !== 'none') {
						checkTableScroll(tableWrapper);
					}
				}, 250);
			});

			// v2.0: Initial load - start with first level.
			loadHierarchyLevel(1);
		},

		/**
		 * Destroy all Choices.js instances for a calculator.
		 *
		 * v2.0: Supports dynamic hierarchy levels up to 5.
		 *
		 * @param {string} containerId Container ID.
		 */
		destroyChoices: function(containerId) {
			// v2.0: Destroy dynamic level instances.
			for (let level = 1; level <= 5; level++) {
				const key = containerId + '-level-' + level;
				if (MVwebPriceCalculator.choicesInstances.has(key)) {
					MVwebPriceCalculator.choicesInstances.get(key).destroy();
					MVwebPriceCalculator.choicesInstances.delete(key);
				}
			}

			// Legacy: also destroy old-style instances if any.
			const types = ['brand', 'type', 'model'];
			types.forEach(function(type) {
				const key = containerId + '-' + type;
				if (MVwebPriceCalculator.choicesInstances.has(key)) {
					MVwebPriceCalculator.choicesInstances.get(key).destroy();
					MVwebPriceCalculator.choicesInstances.delete(key);
				}
			});
		},

		/**
		 * Reinitialize a calculator instance.
		 *
		 * @param {string|HTMLElement} containerOrId Container element or ID.
		 */
		reinit: function(containerOrId) {
			let container;

			if (typeof containerOrId === 'string') {
				container = document.getElementById(containerOrId);
			} else {
				container = containerOrId;
			}

			if (!container) {
				return;
			}

			// Destroy existing Choices instances.
			MVwebPriceCalculator.destroyChoices(container.id);

			// Reinitialize.
			MVwebPriceCalculator.initInstance(container);
		}
	};

	// Initialize on DOM ready.
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', MVwebPriceCalculator.init);
	} else {
		MVwebPriceCalculator.init();
	}

	// Expose to global scope for external use.
	window.MVwebPriceCalculator = MVwebPriceCalculator;

})();
