<?php
/**
 * Appearance tab template.
 *
 * @package MVweb_Price_Table
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Form Title & Description', 'mvweb-price-table' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'These settings apply to all calculators. A shortcode can override the title with its title attribute.', 'mvweb-price-table' ); ?>
	</p>

	<div class="mvweb-form-row">
		<label for="default_title" class="mvweb-form-row__label"><?php esc_html_e( 'Default Title', 'mvweb-price-table' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="default_title" name="default_title" class="mvweb-input"
					value="<?php echo esc_attr( $settings['default_title'] ?? '' ); ?>">
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Default title displayed above the form. Leave empty to hide.', 'mvweb-price-table' ); ?>
			</p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="default_description" class="mvweb-form-row__label"><?php esc_html_e( 'Default Description', 'mvweb-price-table' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="default_description" name="default_description" class="mvweb-textarea" rows="3"><?php echo esc_textarea( $settings['default_description'] ?? '' ); ?></textarea>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Description text displayed below the title.', 'mvweb-price-table' ); ?>
			</p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="footer_text" class="mvweb-form-row__label"><?php esc_html_e( 'Footer Text', 'mvweb-price-table' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="footer_text" name="footer_text" class="mvweb-textarea" rows="2"><?php echo esc_textarea( $settings['footer_text'] ?? '' ); ?></textarea>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Text displayed below the price table. Supports basic HTML.', 'mvweb-price-table' ); ?>
			</p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Button Customization', 'mvweb-price-table' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="default_button_text" class="mvweb-form-row__label"><?php esc_html_e( 'Button Text', 'mvweb-price-table' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="default_button_text" name="default_button_text" class="mvweb-input"
					value="<?php echo esc_attr( $settings['default_button_text'] ?? __( 'Show Prices', 'mvweb-price-table' ) ); ?>">
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Light Design Colors', 'mvweb-price-table' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Accent colors of the Light design. They apply to all calculators that use this design.', 'mvweb-price-table' ); ?>
	</p>

	<?php
	$light_color_fields = array(
		'light_button_color' => __( 'Button Color', 'mvweb-price-table' ),
		'light_th_color'     => __( 'Table Header Color', 'mvweb-price-table' ),
		'light_price_color'  => __( 'Highlighted Price Color', 'mvweb-price-table' ),
	);

	foreach ( mvweb_pt_get_light_color_defaults() as $color_key => $color_default ) :
		$color_value = is_string( $settings[ $color_key ] ?? null ) ? sanitize_hex_color( trim( $settings[ $color_key ] ) ) : '';
		$color_value = $color_value ? $color_value : $color_default;
		?>
	<div class="mvweb-form-row">
		<label for="<?php echo esc_attr( $color_key ); ?>" class="mvweb-form-row__label"><?php echo esc_html( $light_color_fields[ $color_key ] ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-color-picker">
				<input type="color" id="<?php echo esc_attr( $color_key ); ?>" name="<?php echo esc_attr( $color_key ); ?>" class="mvweb-pc-color-input"
						value="<?php echo esc_attr( $color_value ); ?>" data-default="<?php echo esc_attr( $color_default ); ?>">
				<span class="mvweb-color-picker__value"><?php echo esc_html( $color_value ); ?></span>
				<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-pc-color-reset"><?php esc_html_e( 'Reset', 'mvweb-price-table' ); ?></button>
			</div>
		</div>
	</div>
	<?php endforeach; ?>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Custom CSS', 'mvweb-price-table' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="custom_css" class="mvweb-form-row__label"><?php esc_html_e( 'Additional CSS', 'mvweb-price-table' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="custom_css" name="custom_css" class="mvweb-textarea code" rows="10" placeholder="/* <?php esc_attr_e( 'Add your custom CSS here', 'mvweb-price-table' ); ?> */
.mvweb-pc {
    /* <?php esc_attr_e( 'Your styles', 'mvweb-price-table' ); ?> */
}"><?php echo esc_textarea( $settings['custom_css'] ?? '' ); ?></textarea>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Custom CSS will be added to the frontend. Use .mvweb-pc selector for specificity.', 'mvweb-price-table' ); ?>
			</p>
		</div>
	</div>
</div>
