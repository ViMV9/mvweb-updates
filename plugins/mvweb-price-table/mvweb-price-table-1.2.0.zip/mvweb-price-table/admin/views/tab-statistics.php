<?php
/**
 * Statistics tab template.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 * @since   2.2.0 Simplified to show only hierarchy level statistics.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( 'statistics' !== $current_tab ) {
	?>
	<p class="mvweb-pc-no-data" role="status"><?php esc_html_e( 'Loading...', 'mvweb-price-table' ); ?></p>
	<?php
	return;
}

$statistics = new MVweb_PT_Statistics();

$stats_enabled = mvweb_pt_get_option( 'stats_enabled', true );

$period = isset( $_GET['period'] ) ? sanitize_key( $_GET['period'] ) : 'month'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

$form_filter = isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : null; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

$stats = $statistics->get_stats( $period, $form_filter );

$total_records = $statistics->get_total_records();
$table_size    = $statistics->get_table_size();

$periods = array(
	'today' => __( 'Today', 'mvweb-price-table' ),
	'week'  => __( 'Last 7 days', 'mvweb-price-table' ),
	'month' => __( 'Last 30 days', 'mvweb-price-table' ),
	'year'  => __( 'Last year', 'mvweb-price-table' ),
	'all'   => __( 'All time', 'mvweb-price-table' ),
);

$forms         = mvweb_pt_get_forms();
$level_columns = array(
	1 => 'brand',
	2 => 'type',
	3 => 'model',
);
$level_roles   = mvweb_pt_get_valid_roles();
$level_labels  = array();

foreach ( $level_columns as $position => $column ) {
	$level_labels[ $position ] = $level_roles[ 'hierarchy_' . $position ];
}

if ( $form_filter && isset( $forms[ $form_filter ] ) ) {
	$field_mapping = ! empty( $forms[ $form_filter ]['field_mapping'] ) ? $forms[ $form_filter ]['field_mapping'] : mvweb_pt_get_default_field_mapping();
	$form_levels   = mvweb_pt_get_effective_hierarchy( $field_mapping );

	if ( ! empty( $form_levels ) ) {
		$level_labels = array();

		foreach ( $form_levels as $position => $level ) {
			if ( isset( $level_columns[ $position ] ) ) {
				$level_labels[ $position ] = '' !== $level['label'] ? $level['label'] : $level_roles[ 'hierarchy_' . $level['original_level'] ];
			}
		}
	}
}
?>

<?php if ( ! $stats_enabled ) : ?>
	<div class="mvweb-alert mvweb-alert--warning">
		<div class="mvweb-alert__body">
			<?php esc_html_e( 'Statistics collection is currently disabled.', 'mvweb-price-table' ); ?>
			<a href="#settings" class="nav-tab-link" data-tab="settings"><?php esc_html_e( 'Enable in Settings', 'mvweb-price-table' ); ?></a>
		</div>
	</div>
<?php endif; ?>

<div class="mvweb-pc-stats-header" data-pc-stats-loaded>
	<div class="mvweb-pc-stats-filters">
		<label for="mvweb-pc-stats-period"><?php esc_html_e( 'Period:', 'mvweb-price-table' ); ?></label>
		<select id="mvweb-pc-stats-period" class="mvweb-select mvweb-pc-stats-filter">
			<?php foreach ( $periods as $key => $label ) : ?>
				<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $period, $key ); ?>>
					<?php echo esc_html( $label ); ?>
				</option>
			<?php endforeach; ?>
		</select>

		<?php if ( ! empty( $forms ) ) : ?>
			<label for="mvweb-pc-stats-form"><?php esc_html_e( 'Form:', 'mvweb-price-table' ); ?></label>
			<select id="mvweb-pc-stats-form" class="mvweb-select mvweb-pc-stats-filter">
				<option value=""><?php esc_html_e( 'All forms', 'mvweb-price-table' ); ?></option>
				<?php foreach ( $forms as $form ) : ?>
					<option value="<?php echo esc_attr( $form['id'] ); ?>" <?php selected( $form_filter, $form['id'] ); ?>>
						<?php echo esc_html( $form['name'] ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		<?php endif; ?>
	</div>

	<div class="mvweb-pc-stats-actions">
		<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-pc-export-stats" data-period="<?php echo esc_attr( $period ); ?>" data-form="<?php echo esc_attr( $form_filter ); ?>">
			<span class="dashicons dashicons-download"></span>
			<?php esc_html_e( 'Export CSV', 'mvweb-price-table' ); ?>
		</button>
		<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-btn--danger mvweb-pc-clear-stats">
			<span class="dashicons dashicons-trash"></span>
			<?php esc_html_e( 'Clear Statistics', 'mvweb-price-table' ); ?>
		</button>
	</div>
</div>

<div class="mvweb-pc-stats-cards">
	<div class="mvweb-pc-stats-card">
		<div class="mvweb-pc-stats-card__icon">
			<span class="dashicons dashicons-visibility"></span>
		</div>
		<div class="mvweb-pc-stats-card__content">
			<div class="mvweb-pc-stats-card__value"><?php echo esc_html( number_format_i18n( $stats['total_requests'] ) ); ?></div>
			<div class="mvweb-pc-stats-card__label"><?php esc_html_e( 'Total Requests', 'mvweb-price-table' ); ?></div>
		</div>
	</div>

	<div class="mvweb-pc-stats-card">
		<div class="mvweb-pc-stats-card__icon">
			<span class="dashicons dashicons-groups"></span>
		</div>
		<div class="mvweb-pc-stats-card__content">
			<div class="mvweb-pc-stats-card__value"><?php echo esc_html( number_format_i18n( $stats['unique_visitors'] ) ); ?></div>
			<div class="mvweb-pc-stats-card__label"><?php esc_html_e( 'Unique Visitors', 'mvweb-price-table' ); ?></div>
		</div>
	</div>

	<div class="mvweb-pc-stats-card">
		<div class="mvweb-pc-stats-card__icon">
			<span class="dashicons dashicons-money-alt"></span>
		</div>
		<div class="mvweb-pc-stats-card__content">
			<div class="mvweb-pc-stats-card__value"><?php echo esc_html( number_format_i18n( $stats['price_lookups'] ) ); ?></div>
			<div class="mvweb-pc-stats-card__label"><?php esc_html_e( 'Price Lookups', 'mvweb-price-table' ); ?></div>
		</div>
	</div>

	<div class="mvweb-pc-stats-card">
		<div class="mvweb-pc-stats-card__icon">
			<span class="dashicons dashicons-database"></span>
		</div>
		<div class="mvweb-pc-stats-card__content">
			<div class="mvweb-pc-stats-card__value"><?php echo esc_html( number_format_i18n( $total_records ) ); ?></div>
			<div class="mvweb-pc-stats-card__label">
				<?php esc_html_e( 'Total Records', 'mvweb-price-table' ); ?>
				<small>(<?php echo esc_html( $table_size ); ?>)</small>
			</div>
		</div>
	</div>
</div>

<div class="mvweb-pc-stats-grid">
	<?php foreach ( $level_labels as $position => $level_label ) : ?>
		<?php $level_stats = $statistics->get_level_stats( $level_columns[ $position ], $period, $form_filter, 10 ); ?>
		<div class="mvweb-pc-stats-section">
			<h3><?php echo esc_html( $level_label ); ?></h3>
			<?php if ( ! empty( $level_stats ) ) : ?>
				<table class="mvweb-table">
					<thead>
						<tr>
							<th><?php echo esc_html( $level_label ); ?></th>
							<th class="column-count"><?php esc_html_e( 'Requests', 'mvweb-price-table' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $level_stats as $item ) : ?>
							<tr>
								<td><?php echo esc_html( $item['value'] ); ?></td>
								<td class="column-count"><?php echo esc_html( number_format_i18n( $item['count'] ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p class="mvweb-pc-no-data"><?php esc_html_e( 'No data available.', 'mvweb-price-table' ); ?></p>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>
</div>

<div class="mvweb-pc-stats-footer">
	<p>
		<span class="dashicons dashicons-info" aria-hidden="true"></span>
		<?php esc_html_e( 'Statistics older than 90 days are automatically deleted to keep the database clean.', 'mvweb-price-table' ); ?>
	</p>
	<p>
		<span class="dashicons dashicons-info" aria-hidden="true"></span>
		<?php esc_html_e( 'Statistics record only the first three hierarchy levels of each form.', 'mvweb-price-table' ); ?>
	</p>
</div>
