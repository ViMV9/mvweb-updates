<?php
/**
 * Script dependencies and version for the Price Table block editor script.
 *
 * @package MVweb_Price_Table
 * @since   1.1.18
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

return array(
	'dependencies' => array( 'wp-blocks', 'wp-block-editor', 'wp-components', 'wp-element', 'wp-i18n' ),
	'version'      => MVWEB_PT_VERSION,
);
