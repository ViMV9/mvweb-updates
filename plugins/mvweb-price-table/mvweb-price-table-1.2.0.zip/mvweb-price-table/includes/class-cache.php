<?php
/**
 * Cache class for MVweb Price Table.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PT_Cache
 *
 * Stores parsed sheet data in files under wp-content/cache, with the last good copy as fallback.
 *
 * @since 1.0.0
 */
class MVweb_PT_Cache {

	/**
	 * Cache prefix.
	 *
	 * @var string
	 */
	const PREFIX = 'mvweb_pt_';

	/**
	 * Fallback prefix.
	 *
	 * @var string
	 */
	const FALLBACK_PREFIX = 'mvweb_pt_fallback_';

	/**
	 * Default TTL in seconds (1 hour).
	 *
	 * @var int
	 */
	const DEFAULT_TTL = 3600;

	/**
	 * Get the cache directory, creating it on first use.
	 *
	 * Cached sheet data stays out of wp_options and so out of database backups.
	 *
	 * @since 1.2.0
	 * @return string|false Directory path with trailing slash, false if it cannot be created.
	 */
	private function dir() {
		static $dir = null;

		if ( null !== $dir ) {
			return $dir;
		}

		$uploads    = wp_upload_dir( null, false );
		$candidates = array( trailingslashit( WP_CONTENT_DIR ) . 'cache/mvweb-price-table/' );

		if ( empty( $uploads['error'] ) ) {
			$candidates[] = trailingslashit( $uploads['basedir'] ) . 'mvweb-price-table-cache/';
		}

		$path = false;

		foreach ( $candidates as $candidate ) {
			if ( ! is_dir( $candidate ) ) {
				wp_mkdir_p( $candidate );
			}

			if ( is_dir( $candidate ) && wp_is_writable( $candidate ) ) {
				$path = $candidate;
				break;
			}
		}

		if ( ! $path ) {
			$dir = false;
			return $dir;
		}

		if ( ! file_exists( $path . 'index.php' ) ) {
			file_put_contents( $path . 'index.php', "<?php\n// Silence is golden.\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		if ( ! file_exists( $path . '.htaccess' ) ) {
			file_put_contents( $path . '.htaccess', "<IfModule mod_authz_core.c>\nRequire all denied\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
		}

		$dir = $path;
		return $dir;
	}

	/**
	 * Get the file path for a cache key.
	 *
	 * @since 1.2.0
	 * @param string $key Cache key.
	 * @return string|false File path or false when there is no cache directory.
	 */
	private function file_for( $key ) {
		$dir = $this->dir();

		return $dir ? $dir . md5( $key . wp_salt() ) . '.dat' : false;
	}

	/**
	 * Read a cache entry from its file.
	 *
	 * @since 1.2.0
	 * @param string $key Cache key.
	 * @return array|false Entry (gen, expires, time, data) or false.
	 */
	private function read_entry( $key ) {
		$file = $this->file_for( $key );

		if ( ! $file || ! is_readable( $file ) ) {
			return false;
		}

		$raw = file_get_contents( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

		if ( false === $raw ) {
			return false;
		}

		$entry = unserialize( $raw, array( 'allowed_classes' => false ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_unserialize

		if ( ! is_array( $entry ) || ! array_key_exists( 'data', $entry ) ) {
			return false;
		}

		return $entry;
	}

	/**
	 * Get cached data.
	 *
	 * @since 1.0.0
	 * @since 1.2.0 Stored in a file instead of a transient.
	 * @param string $key Cache key.
	 * @return mixed|false Cached data or false if not found or expired.
	 */
	public function get( $key ) {
		$entry = $this->read_entry( $key );

		if ( false === $entry || (int) get_option( 'mvweb_pt_cache_gen', 0 ) !== (int) $entry['gen'] || time() > (int) $entry['expires'] ) {
			return false;
		}

		return $entry['data'];
	}

	/**
	 * Store data in the cache and keep it as the last good copy.
	 *
	 * One file serves both purposes: it stops being fresh when its TTL ends or
	 * the cache is cleared, but stays readable as the fallback copy.
	 *
	 * @since 1.0.0
	 * @since 1.2.0 Stored in a file; the fallback copy is the same file.
	 * @param string $key  Cache key.
	 * @param mixed  $data Data to cache.
	 * @param int    $ttl  Time to live in seconds.
	 * @return bool True on success, false on failure.
	 */
	public function set( $key, $data, $ttl = self::DEFAULT_TTL ) {
		$file = $this->file_for( $key );

		if ( ! $file ) {
			return false;
		}

		$payload = serialize( // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.serialize_serialize
			array(
				'gen'     => (int) get_option( 'mvweb_pt_cache_gen', 0 ),
				'expires' => time() + (int) $ttl,
				'time'    => time(),
				'data'    => $data,
			)
		);

		$tmp = $file . '.' . wp_generate_password( 8, false ) . '.tmp';

		if ( false === file_put_contents( $tmp, $payload ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
			wp_delete_file( $tmp );
			return false;
		}

		if ( ! rename( $tmp, $file ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.rename_rename
			wp_delete_file( $tmp );
			return false;
		}

		return true;
	}

	/**
	 * Delete a cache entry together with its fallback copy.
	 *
	 * @since 1.0.0
	 * @param string $key Cache key.
	 * @return bool True when a file was deleted.
	 */
	public function delete( $key ) {
		$file = $this->file_for( $key );

		if ( ! $file || ! file_exists( $file ) ) {
			return false;
		}

		wp_delete_file( $file );

		return ! file_exists( $file );
	}

	/**
	 * Get the last good copy, even if it is stale.
	 *
	 * @since 1.0.0
	 * @since 1.2.0 Read from the cache file.
	 * @param string $key Cache key.
	 * @return mixed|false Fallback data or false if not found or disabled.
	 */
	public function get_fallback( $key ) {
		$settings = get_option( 'mvweb_pt_settings', array() );

		if ( empty( $settings['fallback_enabled'] ) ) {
			return false;
		}

		$entry = $this->read_entry( $key );

		return false === $entry ? false : $entry['data'];
	}

	/**
	 * Delete the fallback copy.
	 *
	 * @since 1.0.0
	 * @param string $key Cache key.
	 * @return bool True when a file was deleted.
	 */
	public function delete_fallback( $key ) {
		return $this->delete( $key );
	}

	/**
	 * Mark all cached data stale. Last good copies stay available as fallback.
	 *
	 * Also removes transients left by earlier versions.
	 *
	 * @since 1.0.0
	 * @return int Number of removed transients.
	 */
	public function flush_all() {
		global $wpdb;

		$count = 0;

		update_option( 'mvweb_pt_cache_gen', (int) get_option( 'mvweb_pt_cache_gen', 0 ) + 1 );

		$transients = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . self::PREFIX ) . '%'
			)
		);

		foreach ( $transients as $transient ) {
			$key = str_replace( '_transient_', '', $transient );
			if ( delete_transient( $key ) ) {
				++$count;
			}
		}

		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_timeout_' . self::PREFIX ) . '%'
			)
		);

		return $count + $this->count_files();
	}

	/**
	 * Count cache files.
	 *
	 * @since 1.2.0
	 * @return int Number of cache files.
	 */
	private function count_files() {
		$dir = $this->dir();

		return $dir ? count( (array) glob( $dir . '*.dat' ) ) : 0;
	}

	/**
	 * Remove cache copies that earlier versions kept in wp_options.
	 *
	 * @since 1.2.0
	 * @return void
	 */
	public function purge_database_copies() {
		global $wpdb;

		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( self::FALLBACK_PREFIX ) . '%'
			)
		);

		$names = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . self::PREFIX ) . '%'
			)
		);

		foreach ( $names as $name ) {
			$key = substr( $name, strlen( '_transient_' ) );

			if ( preg_match( '/^' . self::PREFIX . '[0-9a-f]{32}$/', $key ) ) {
				delete_transient( $key );
			}
		}
	}

	/**
	 * Log cache error.
	 *
	 * @since 1.0.0
	 * @param string $key     Cache key (usually spreadsheet ID).
	 * @param string $message Error message.
	 * @return void
	 */
	public function log_error( $key, $message ) {
		$errors   = get_option( 'mvweb_pt_cache_errors', array() );
		$errors[] = array(
			'key'       => $key,
			'message'   => $message,
			'timestamp' => current_time( 'mysql' ),
		);

		if ( count( $errors ) > 50 ) {
			$errors = array_slice( $errors, -50 );
		}

		update_option( 'mvweb_pt_cache_errors', $errors, false );

		mvweb_pt_log( 'Cache error for key ' . $key . ': ' . $message, 'error' );
	}

	/**
	 * Get cache errors.
	 *
	 * @since 1.0.0
	 * @param int $limit Number of errors to return.
	 * @return array Array of errors.
	 */
	public function get_errors( $limit = 10 ) {
		$errors = get_option( 'mvweb_pt_cache_errors', array() );
		return array_slice( array_reverse( $errors ), 0, $limit );
	}

	/**
	 * Clear cache errors.
	 *
	 * @since 1.0.0
	 * @return bool True on success.
	 */
	public function clear_errors() {
		return delete_option( 'mvweb_pt_cache_errors' );
	}

	/**
	 * Refresh cache for a specific form.
	 *
	 * @since 1.0.0
	 * @param int $form_id Form ID.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	public function refresh_form_cache( $form_id ) {
		$form = mvweb_pt_get_form( $form_id );

		if ( ! $form || empty( $form['spreadsheet_url'] ) ) {
			return new WP_Error(
				'invalid_form',
				__( 'Form not found or has no spreadsheet URL.', 'mvweb-price-table' )
			);
		}

		$sheets         = new MVweb_PT_Google_Sheets();
		$spreadsheet_id = $sheets->extract_spreadsheet_id( $form['spreadsheet_url'] );

		if ( ! $spreadsheet_id ) {
			return new WP_Error(
				'invalid_url',
				__( 'Invalid Google Sheets URL.', 'mvweb-price-table' )
			);
		}

		$form['spreadsheet_id'] = $spreadsheet_id;

		$result = $sheets->fetch_form( $form, false );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return true;
	}
}
