<?php
/**
 * Statistics tab template.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 * @since   2.2.0 Simplified to show only hierarchy level statistics.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get statistics instance.
$statistics = new MVweb_PT_Statistics();

// Check if stats are enabled.
$stats_enabled = mvweb_pt_get_option( 'stats_enabled', true );

// Get current period.
$period = isset( $_GET['period'] ) ? sanitize_key( $_GET['period'] ) : 'month'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

// Get form filter.
$form_filter = isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : null; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

// Get stats.
$stats = $statistics->get_stats( $period, $form_filter );

// Get database info.
$total_records = $statistics->get_total_records();
$table_size    = $statistics->get_table_size();

// Period labels.
$periods = array(
	'today' => __( 'Today', 'mvweb-price-table' ),
	'week'  => __( 'Last 7 days', 'mvweb-price-table' ),
	'month' => __( 'Last 30 days', 'mvweb-price-table' ),
	'year'  => __( 'Last year', 'mvweb-price-table' ),
	'all'   => __( 'All time', 'mvweb-price-table' ),
);

// Get hierarchy levels configuration.
$hierarchy_levels = array();
$forms            = mvweb_pt_get_forms();

// If specific form is selected, get its field_mapping.
if ( $form_filter && isset( $forms[ $form_filter ] ) ) {
	$form          = $forms[ $form_filter ];
	$field_mapping = isset( $form['field_mapping'] ) ? $form['field_mapping'] : mvweb_pt_get_default_field_mapping();
} else {
	// Use default field mapping if no form selected or multiple forms.
	$field_mapping = mvweb_pt_get_default_field_mapping();
}

// Build hierarchy levels from field_mapping.
if ( isset( $field_mapping['columns'] ) && is_array( $field_mapping['columns'] ) ) {
	foreach ( $field_mapping['columns'] as $column ) {
		if ( strpos( $column['role'], 'hierarchy_' ) === 0 ) {
			$level_num                      = (int) str_replace( 'hierarchy_', '', $column['role'] );
			$hierarchy_levels[ $level_num ] = array(
				'label' => $column['label'],
				'role'  => $column['role'],
			);
		}
	}
	ksort( $hierarchy_levels );
}

// Map hierarchy levels to database columns.
$level_columns = array(
	1 => 'brand',
	2 => 'type',
	3 => 'model',
);
?>

<?php if ( ! $stats_enabled ) : ?>
	<div class="notice notice-warning inline">
		<p>
			<?php esc_html_e( 'Statistics collection is currently disabled.', 'mvweb-price-table' ); ?>
			<a href="#settings" class="nav-tab-link" data-tab="settings"><?php esc_html_e( 'Enable in Settings', 'mvweb-price-table' ); ?></a>
		</p>
	</div>
<?php endif; ?>

<div class="mvweb-pc-stats-header">
	<div class="mvweb-pc-stats-filters">
		<label for="mvweb-pc-stats-period"><?php esc_html_e( 'Period:', 'mvweb-price-table' ); ?></label>
		<select id="mvweb-pc-stats-period" class="mvweb-pc-stats-filter">
			<?php foreach ( $periods as $key => $label ) : ?>
				<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $period, $key ); ?>>
					<?php echo esc_html( $label ); ?>
				</option>
			<?php endforeach; ?>
		</select>

		<?php if ( ! empty( $forms ) ) : ?>
			<label for="mvweb-pc-stats-form"><?php esc_html_e( 'Form:', 'mvweb-price-table' ); ?></label>
			<select id="mvweb-pc-stats-form" class="mvweb-pc-stats-filter">
				<option value=""><?php esc_html_e( 'All forms', 'mvweb-price-table' ); ?></option>
				<?php foreach ( $forms as $form ) : ?>
					<option value="<?php echo esc_attr( $form['id'] ); ?>" <?php selected( $form_filter, $form['id'] ); ?>>
						<?php echo esc_html( $form['name'] ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		<?php endif; ?>
	</div>

	<div class="mvweb-pc-stats-actions">
		<button type="button" class="button mvweb-pc-export-stats" data-period="<?php echo esc_attr( $period ); ?>" data-form="<?php echo esc_attr( $form_filter ); ?>">
			<span class="dashicons dashicons-download"></span>
			<?php esc_html_e( 'Export CSV', 'mvweb-price-table' ); ?>
		</button>
		<button type="button" class="button mvweb-pc-clear-stats">
			<span class="dashicons dashicons-trash"></span>
			<?php esc_html_e( 'Clear Statistics', 'mvweb-price-table' ); ?>
		</button>
	</div>
</div>

<!-- Summary Cards -->
<div class="mvweb-pc-stats-cards">
	<div class="mvweb-pc-stats-card">
		<div class="mvweb-pc-stats-card__icon">
			<span class="dashicons dashicons-visibility"></span>
		</div>
		<div class="mvweb-pc-stats-card__content">
			<div class="mvweb-pc-stats-card__value"><?php echo esc_html( number_format_i18n( $stats['total_requests'] ) ); ?></div>
			<div class="mvweb-pc-stats-card__label"><?php esc_html_e( 'Total Requests', 'mvweb-price-table' ); ?></div>
		</div>
	</div>

	<div class="mvweb-pc-stats-card">
		<div class="mvweb-pc-stats-card__icon">
			<span class="dashicons dashicons-groups"></span>
		</div>
		<div class="mvweb-pc-stats-card__content">
			<div class="mvweb-pc-stats-card__value"><?php echo esc_html( number_format_i18n( $stats['unique_visitors'] ) ); ?></div>
			<div class="mvweb-pc-stats-card__label"><?php esc_html_e( 'Unique Visitors', 'mvweb-price-table' ); ?></div>
		</div>
	</div>

	<div class="mvweb-pc-stats-card">
		<div class="mvweb-pc-stats-card__icon">
			<span class="dashicons dashicons-money-alt"></span>
		</div>
		<div class="mvweb-pc-stats-card__content">
			<div class="mvweb-pc-stats-card__value"><?php echo esc_html( number_format_i18n( $stats['price_lookups'] ) ); ?></div>
			<div class="mvweb-pc-stats-card__label"><?php esc_html_e( 'Price Lookups', 'mvweb-price-table' ); ?></div>
		</div>
	</div>

	<div class="mvweb-pc-stats-card">
		<div class="mvweb-pc-stats-card__icon">
			<span class="dashicons dashicons-database"></span>
		</div>
		<div class="mvweb-pc-stats-card__content">
			<div class="mvweb-pc-stats-card__value"><?php echo esc_html( number_format_i18n( $total_records ) ); ?></div>
			<div class="mvweb-pc-stats-card__label">
				<?php esc_html_e( 'Total Records', 'mvweb-price-table' ); ?>
				<small>(<?php echo esc_html( $table_size ); ?>)</small>
			</div>
		</div>
	</div>
</div>

<!-- Hierarchy Level Statistics -->
<div class="mvweb-pc-stats-grid">
	<?php foreach ( $hierarchy_levels as $level => $config ) : ?>
		<?php
		// Get column name for this level.
		$column = isset( $level_columns[ $level ] ) ? $level_columns[ $level ] : null;
		if ( ! $column ) {
			continue;
		}

		// Get statistics for this level.
		$level_stats = $statistics->get_level_stats( $column, $period, $form_filter, 10 );
		?>
		<div class="mvweb-pc-stats-section">
			<h3><?php echo esc_html( $config['label'] ); ?></h3>
			<?php if ( ! empty( $level_stats ) ) : ?>
				<table class="wp-list-table widefat fixed striped">
					<thead>
						<tr>
							<th><?php echo esc_html( $config['label'] ); ?></th>
							<th class="column-count"><?php esc_html_e( 'Requests', 'mvweb-price-table' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $level_stats as $item ) : ?>
							<tr>
								<td><?php echo esc_html( $item['value'] ); ?></td>
								<td class="column-count"><?php echo esc_html( number_format_i18n( $item['count'] ) ); ?></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php else : ?>
				<p class="mvweb-pc-no-data"><?php esc_html_e( 'No data available.', 'mvweb-price-table' ); ?></p>
			<?php endif; ?>
		</div>
	<?php endforeach; ?>
</div>

<!-- Auto-cleanup notice -->
<div class="mvweb-pc-stats-footer">
	<p class="description">
		<span class="dashicons dashicons-info"></span>
		<?php esc_html_e( 'Statistics older than 90 days are automatically deleted to keep the database clean.', 'mvweb-price-table' ); ?>
	</p>
</div>
