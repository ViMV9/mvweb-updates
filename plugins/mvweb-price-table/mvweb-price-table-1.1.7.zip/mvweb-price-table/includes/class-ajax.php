<?php
/**
 * AJAX handlers for MVweb Price Table.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PT_Ajax
 *
 * Handles all AJAX requests for the plugin.
 *
 * @since 1.0.0
 */
class MVweb_PT_Ajax {

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->register_public_handlers();
		$this->register_admin_handlers();
	}

	/**
	 * Register public AJAX handlers.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function register_public_handlers() {
		// Public endpoints (available to non-logged-in users).
		$public_actions = array(
			'mvweb_pt_get_brands',
			'mvweb_pt_get_types',
			'mvweb_pt_get_models',
			'mvweb_pt_get_prices',
			'mvweb_pt_get_hierarchy_level',
		);

		foreach ( $public_actions as $action ) {
			add_action( 'wp_ajax_' . $action, array( $this, str_replace( 'mvweb_pt_', '', $action ) ) );
			add_action( 'wp_ajax_nopriv_' . $action, array( $this, str_replace( 'mvweb_pt_', '', $action ) ) );
		}
	}

	/**
	 * Register admin AJAX handlers.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function register_admin_handlers() {
		// Admin-only endpoints.
		$admin_actions = array(
			'mvweb_pt_save_form',
			'mvweb_pt_delete_form',
			'mvweb_pt_test_connection',
			'mvweb_pt_clear_cache',
			'mvweb_pt_save_settings',
			'mvweb_pt_save_appearance',
			'mvweb_pt_get_stats',
			'mvweb_pt_export_stats',
			'mvweb_pt_clear_stats',
			'mvweb_pt_export_logs',
			'mvweb_pt_auto_detect_mapping',
			'mvweb_pt_fetch_preview',
			'mvweb_pt_fetch_sheets',
		);

		foreach ( $admin_actions as $action ) {
			add_action( 'wp_ajax_' . $action, array( $this, str_replace( 'mvweb_pt_', 'admin_', $action ) ) );
		}
	}

	/**
	 * Verify public nonce.
	 *
	 * @since 1.0.0
	 * @return bool True if valid.
	 */
	private function verify_public_nonce() {
		$nonce = isset( $_REQUEST['nonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'mvweb_pt_public' ) ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_nonce',
					'message' => __( 'Security check failed. Please refresh the page and try again.', 'mvweb-price-table' ),
				),
				403
			);
		}

		return true;
	}

	/**
	 * Verify admin nonce and capability.
	 *
	 * @since 1.0.0
	 * @return bool True if valid.
	 */
	private function verify_admin_request() {
		$nonce = isset( $_REQUEST['nonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'mvweb_pt_ajax' ) ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_nonce',
					'message' => __( 'Security check failed.', 'mvweb-price-table' ),
				),
				403
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'code'    => 'insufficient_permissions',
					'message' => __( 'You do not have permission to perform this action.', 'mvweb-price-table' ),
				),
				403
			);
		}

		return true;
	}

	/**
	 * Get form and Google Sheets instance.
	 *
	 * @since 1.0.0
	 * @return array|void Array with form and sheets, or sends error.
	 */
	private function get_form_and_sheets() {
		$form_id = isset( $_REQUEST['form_id'] ) ? absint( $_REQUEST['form_id'] ) : 0;

		if ( ! $form_id ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_form_id',
					'message' => __( 'Form ID is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$form = mvweb_pt_get_form( $form_id );

		if ( ! $form ) {
			wp_send_json_error(
				array(
					'code'    => 'form_not_found',
					'message' => __( 'Form not found.', 'mvweb-price-table' ),
				),
				404
			);
		}

		if ( 'active' !== $form['status'] ) {
			wp_send_json_error(
				array(
					'code'    => 'form_inactive',
					'message' => __( 'This form is inactive.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$sheets = new MVweb_PT_Google_Sheets();

		return array(
			'form'   => $form,
			'sheets' => $sheets,
		);
	}

	/**
	 * Get brands handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function get_brands() {
		$this->verify_public_nonce();

		$form_id = isset( $_REQUEST['form_id'] ) ? absint( $_REQUEST['form_id'] ) : 0;
		$data    = $this->get_form_and_sheets();

		// Fetch data to check for errors.
		$sheets_data = $data['sheets']->fetch_data( $data['form']['spreadsheet_id'] );

		if ( is_wp_error( $sheets_data ) ) {
			MVweb_PT_Logger::error(
				$sheets_data->get_error_message(),
				'ajax',
				array(
					'action'  => 'get_brands',
					'form_id' => $form_id,
					'code'    => $sheets_data->get_error_code(),
				)
			);

			wp_send_json_error(
				array(
					'code'    => $sheets_data->get_error_code(),
					'message' => $sheets_data->get_error_message(),
				),
				500
			);
		}

		$brands = isset( $sheets_data['brands'] ) ? $sheets_data['brands'] : array();

		// Log statistics.
		$this->log_stats( $form_id, 'get_brands' );

		wp_send_json_success(
			array(
				'brands' => $brands,
			)
		);
	}

	/**
	 * Get types handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function get_types() {
		$this->verify_public_nonce();

		$form_id = isset( $_REQUEST['form_id'] ) ? absint( $_REQUEST['form_id'] ) : 0;
		$brand   = isset( $_REQUEST['brand'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['brand'] ) ) : '';

		if ( empty( $brand ) ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_brand',
					'message' => __( 'Brand is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$data        = $this->get_form_and_sheets();
		$sheets_data = $data['sheets']->fetch_data( $data['form']['spreadsheet_id'] );

		if ( is_wp_error( $sheets_data ) ) {
			MVweb_PT_Logger::error(
				$sheets_data->get_error_message(),
				'ajax',
				array(
					'action'  => 'get_types',
					'form_id' => $form_id,
					'brand'   => $brand,
					'code'    => $sheets_data->get_error_code(),
				)
			);

			wp_send_json_error(
				array(
					'code'    => $sheets_data->get_error_code(),
					'message' => $sheets_data->get_error_message(),
				),
				500
			);
		}

		$types = array();
		if ( isset( $sheets_data['data'][ $brand ]['types'] ) ) {
			foreach ( $sheets_data['data'][ $brand ]['types'] as $type_key => $type_data ) {
				$types[ $type_key ] = $type_data['name'];
			}
		}

		// Log statistics.
		$this->log_stats( $form_id, 'get_types', array( 'brand' => $brand ) );

		wp_send_json_success(
			array(
				'types' => $types,
			)
		);
	}

	/**
	 * Get models handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function get_models() {
		$this->verify_public_nonce();

		$form_id = isset( $_REQUEST['form_id'] ) ? absint( $_REQUEST['form_id'] ) : 0;
		$brand   = isset( $_REQUEST['brand'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['brand'] ) ) : '';
		$type    = isset( $_REQUEST['type'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['type'] ) ) : '';

		if ( empty( $brand ) || empty( $type ) ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_params',
					'message' => __( 'Brand and type are required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$data        = $this->get_form_and_sheets();
		$sheets_data = $data['sheets']->fetch_data( $data['form']['spreadsheet_id'] );

		if ( is_wp_error( $sheets_data ) ) {
			MVweb_PT_Logger::error(
				$sheets_data->get_error_message(),
				'ajax',
				array(
					'action'  => 'get_models',
					'form_id' => $form_id,
					'brand'   => $brand,
					'type'    => $type,
					'code'    => $sheets_data->get_error_code(),
				)
			);

			wp_send_json_error(
				array(
					'code'    => $sheets_data->get_error_code(),
					'message' => $sheets_data->get_error_message(),
				),
				500
			);
		}

		$models  = array();
		$grouped = array();

		if ( isset( $sheets_data['data'][ $brand ]['types'][ $type ]['models'] ) ) {
			foreach ( $sheets_data['data'][ $brand ]['types'][ $type ]['models'] as $model_key => $model_data ) {
				$group = $model_data['group'];

				if ( ! empty( $group ) ) {
					if ( ! isset( $grouped[ $group ] ) ) {
						$grouped[ $group ] = array();
					}
					$grouped[ $group ][ $model_key ] = $model_data['name'];
				} else {
					$models[ $model_key ] = $model_data['name'];
				}
			}
		}

		// Log statistics.
		$this->log_stats( $form_id, 'get_models', array( 'brand' => $brand, 'type' => $type ) );

		wp_send_json_success(
			array(
				'models'  => $models,
				'grouped' => $grouped,
			)
		);
	}

	/**
	 * Get prices handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function get_prices() {
		$this->verify_public_nonce();

		$form_id = isset( $_REQUEST['form_id'] ) ? absint( $_REQUEST['form_id'] ) : 0;
		$brand   = isset( $_REQUEST['brand'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['brand'] ) ) : '';
		$type    = isset( $_REQUEST['type'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['type'] ) ) : '';
		$model   = isset( $_REQUEST['model'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['model'] ) ) : '';

		if ( empty( $brand ) || empty( $type ) || empty( $model ) ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_params',
					'message' => __( 'Brand, type, and model are required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$data        = $this->get_form_and_sheets();
		$sheets_data = $data['sheets']->fetch_data( $data['form']['spreadsheet_id'] );

		if ( is_wp_error( $sheets_data ) ) {
			MVweb_PT_Logger::error(
				$sheets_data->get_error_message(),
				'ajax',
				array(
					'action'  => 'get_prices',
					'form_id' => $form_id,
					'brand'   => $brand,
					'type'    => $type,
					'model'   => $model,
					'code'    => $sheets_data->get_error_code(),
				)
			);

			wp_send_json_error(
				array(
					'code'    => $sheets_data->get_error_code(),
					'message' => $sheets_data->get_error_message(),
				),
				500
			);
		}

		// Use get_prices() method which supports priority-based price resolution (v2.1.0).
		// Priority: exact match > wildcard pattern > general list.
		$prices = $data['sheets']->get_prices( $data['form']['spreadsheet_id'], $brand, $type, $model );

		// Log statistics.
		$this->log_stats( $form_id, 'get_prices', array( 'brand' => $brand, 'type' => $type, 'model' => $model ) );

		// Get field mapping for dynamic column handling.
		$field_mapping = isset( $data['form']['field_mapping'] ) ? $data['form']['field_mapping'] : null;

		// Format prices for display based on field_mapping.
		$formatted = array();
		foreach ( $prices as $service ) {
			$item = array(
				// Legacy fields for backwards compatibility.
				'name'          => $service['name'],
				'time'          => isset( $service['time'] ) ? $service['time'] : '',
				'price'         => $service['price'],
				'price_display' => mvweb_pt_format_price( $service['price'] ),
			);

			// v2.0: Map all columns from raw_cells based on field_mapping.
			if ( $field_mapping && isset( $field_mapping['columns'] ) && isset( $service['raw_cells'] ) ) {
				foreach ( $field_mapping['columns'] as $column ) {
					$role  = $column['role'];
					$index = $column['index'];

					// Skip hierarchy columns (brand, type, model).
					if ( strpos( $role, 'hierarchy_' ) === 0 ) {
						continue;
					}

					// Get raw value from cells.
					$raw_value = isset( $service['raw_cells'][ $index ] ) ? $service['raw_cells'][ $index ] : '';

					// Map role to field key.
					$key = str_replace( array( 'service_', 'meta_' ), '', $role );

					// Special handling for price.
					if ( 'service_price' === $role ) {
						$item['price']         = $this->parse_price_value( $raw_value );
						$item['price_display'] = mvweb_pt_format_price( $item['price'] );
					} elseif ( 'service_name' === $role ) {
						$item['name'] = $raw_value;
					} elseif ( 'service_time' === $role ) {
						$item['time'] = $raw_value;
					} else {
						// Store other fields by key (note, warranty, custom, etc.).
						$item[ $key ] = $raw_value;
					}
				}
			}

			$formatted[] = $item;
		}

		wp_send_json_success(
			array(
				'services' => $formatted,
			)
		);
	}

	/**
	 * Parse price value from string.
	 *
	 * @since 2.0.0
	 * @param string $price_string Price string.
	 * @return float|string Parsed price.
	 */
	private function parse_price_value( $price_string ) {
		if ( empty( $price_string ) ) {
			return 0;
		}

		// Remove currency symbols and spaces.
		$clean = preg_replace( '/[^\d.,\-]/', '', $price_string );

		// Check if it's a range.
		if ( strpos( $clean, '-' ) !== false && preg_match( '/^\d/', $clean ) ) {
			return $price_string;
		}

		// Replace comma with dot.
		$clean = str_replace( ',', '.', $clean );

		if ( is_numeric( $clean ) ) {
			return floatval( $clean );
		}

		return $price_string;
	}

	/**
	 * Get hierarchy level handler (v2.0 universal endpoint).
	 *
	 * Returns items at a specific hierarchy level based on parent selections.
	 * Level 1 = brands, Level 2 = types, Level 3 = models, etc.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function get_hierarchy_level() {
		$this->verify_public_nonce();

		$form_id = isset( $_REQUEST['form_id'] ) ? absint( $_REQUEST['form_id'] ) : 0;
		$level   = isset( $_REQUEST['level'] ) ? absint( $_REQUEST['level'] ) : 1;

		$data = $this->get_form_and_sheets();

		$sheets_data = $data['sheets']->fetch_data( $data['form']['spreadsheet_id'] );

		if ( is_wp_error( $sheets_data ) ) {
			MVweb_PT_Logger::error(
				$sheets_data->get_error_message(),
				'ajax',
				array(
					'action'  => 'get_hierarchy_level',
					'form_id' => $form_id,
					'level'   => $level,
					'code'    => $sheets_data->get_error_code(),
				)
			);

			wp_send_json_error(
				array(
					'code'    => $sheets_data->get_error_code(),
					'message' => $sheets_data->get_error_message(),
				),
				500
			);
		}

		$items = array();

		// Level 1: Brands.
		if ( 1 === $level ) {
			$items = isset( $sheets_data['brands'] ) ? $sheets_data['brands'] : array();
		}
		// Level 2: Types (requires brand).
		elseif ( 2 === $level ) {
			$brand = isset( $_REQUEST['level_1'] ) ? sanitize_title( wp_unslash( $_REQUEST['level_1'] ) ) : '';
			if ( ! empty( $brand ) && isset( $sheets_data['data'][ $brand ]['types'] ) ) {
				foreach ( $sheets_data['data'][ $brand ]['types'] as $type_key => $type_data ) {
					$items[ $type_key ] = $type_data['name'];
				}
			}
		}
		// Level 3: Models (requires brand and type).
		elseif ( 3 === $level ) {
			$brand = isset( $_REQUEST['level_1'] ) ? sanitize_title( wp_unslash( $_REQUEST['level_1'] ) ) : '';
			$type  = isset( $_REQUEST['level_2'] ) ? sanitize_title( wp_unslash( $_REQUEST['level_2'] ) ) : '';
			if ( ! empty( $brand ) && ! empty( $type ) && isset( $sheets_data['data'][ $brand ]['types'][ $type ]['models'] ) ) {
				foreach ( $sheets_data['data'][ $brand ]['types'][ $type ]['models'] as $model_key => $model_data ) {
					$items[ $model_key ] = $model_data['name'];
				}
			}
		}

		// Log statistics.
		$this->log_stats( $form_id, 'get_hierarchy_level', array( 'level' => $level ) );

		wp_send_json_success(
			array(
				'items' => $items,
				'level' => $level,
			)
		);
	}

	/**
	 * Log statistics for a request.
	 *
	 * @since 1.0.0
	 * @param int    $form_id Form ID.
	 * @param string $action  Action type.
	 * @param array  $data    Additional data.
	 * @return void
	 */
	private function log_stats( $form_id, $action, $data = array() ) {
		$statistics = new MVweb_PT_Statistics();
		$statistics->log_request( $form_id, $action, $data );
	}

	/**
	 * Admin: Save form handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_save_form() {
		$this->verify_admin_request();

		$form_id = isset( $_POST['form_id'] ) ? absint( $_POST['form_id'] ) : null;
		if ( 0 === $form_id ) {
			$form_id = null;
		}

		$form_data = array(
			'name'            => isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '',
			'spreadsheet_url' => isset( $_POST['spreadsheet_url'] ) ? esc_url_raw( wp_unslash( $_POST['spreadsheet_url'] ) ) : '',
			'status'          => isset( $_POST['status'] ) ? sanitize_key( $_POST['status'] ) : 'active',
			'preset'          => isset( $_POST['preset'] ) ? sanitize_key( $_POST['preset'] ) : 'light',
			'settings'        => isset( $_POST['settings'] ) ? mvweb_sanitize_array( wp_unslash( $_POST['settings'] ) ) : array(),
			'sheet_id'        => isset( $_POST['sheet_id'] ) && '' !== $_POST['sheet_id'] ? absint( $_POST['sheet_id'] ) : null,
			'sheet_name'      => isset( $_POST['sheet_name'] ) ? sanitize_text_field( wp_unslash( $_POST['sheet_name'] ) ) : '',
		);

		// v2.0: Handle field_mapping JSON.
		if ( isset( $_POST['field_mapping'] ) && '' !== $_POST['field_mapping'] ) {
			$mapping_json = wp_unslash( $_POST['field_mapping'] );
			$mapping      = json_decode( $mapping_json, true );
			if ( is_array( $mapping ) ) {
				$form_data['field_mapping'] = $mapping;
			}
		}

		$result = mvweb_pt_save_form( $form_data, $form_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'code'    => $result->get_error_code(),
					'message' => $result->get_error_message(),
				),
				400
			);
		}

		$form = mvweb_pt_get_form( $result );

		wp_send_json_success(
			array(
				'form_id'   => $result,
				'form'      => $form,
				'shortcode' => mvweb_pt_get_shortcode( $result ),
				'message'   => __( 'Form saved successfully.', 'mvweb-price-table' ),
			)
		);
	}

	/**
	 * Admin: Delete form handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_delete_form() {
		$this->verify_admin_request();

		$form_id = isset( $_POST['form_id'] ) ? absint( $_POST['form_id'] ) : 0;

		if ( ! $form_id ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_form_id',
					'message' => __( 'Form ID is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$result = mvweb_pt_delete_form( $form_id );

		if ( ! $result ) {
			wp_send_json_error(
				array(
					'code'    => 'delete_failed',
					'message' => __( 'Failed to delete form.', 'mvweb-price-table' ),
				),
				500
			);
		}

		wp_send_json_success(
			array(
				'message' => __( 'Form deleted successfully.', 'mvweb-price-table' ),
			)
		);
	}

	/**
	 * Admin: Test connection handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_test_connection() {
		$this->verify_admin_request();

		$spreadsheet_url = isset( $_POST['spreadsheet_url'] ) ? esc_url_raw( wp_unslash( $_POST['spreadsheet_url'] ) ) : '';

		if ( empty( $spreadsheet_url ) ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_url',
					'message' => __( 'Google Sheets URL is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$sheets         = new MVweb_PT_Google_Sheets();
		$spreadsheet_id = $sheets->extract_spreadsheet_id( $spreadsheet_url );

		if ( ! $spreadsheet_id ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_url',
					'message' => __( 'Invalid Google Sheets URL.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$result = $sheets->test_connection( $spreadsheet_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'code'    => $result->get_error_code(),
					'message' => $result->get_error_message(),
				),
				400
			);
		}

		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: %1$d: brands count, %2$d: types count, %3$d: models count, %4$d: services count */
					__( 'Connection successful! Found %1$d brands, %2$d types, %3$d models, %4$d services.', 'mvweb-price-table' ),
					$result['stats']['brands'],
					$result['stats']['types'],
					$result['stats']['models'],
					$result['stats']['services']
				),
				'stats'   => $result['stats'],
			)
		);
	}

	/**
	 * Admin: Clear cache handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_clear_cache() {
		$this->verify_admin_request();

		$cache   = new MVweb_PT_Cache();
		$deleted = $cache->flush_all();

		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: %d: number of deleted cache entries */
					__( 'Cache cleared. %d entries deleted.', 'mvweb-price-table' ),
					$deleted
				),
			)
		);
	}

	/**
	 * Admin: Save settings handler.
	 *
	 * Saves both Settings and Appearance tabs in a single request.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_save_settings() {
		$this->verify_admin_request();

		$settings = get_option( 'mvweb_pt_settings', array() );

		// Settings tab fields.
		$settings['cache_ttl']              = isset( $_POST['cache_ttl'] ) ? absint( $_POST['cache_ttl'] ) : 3600;
		$settings['fallback_enabled']       = isset( $_POST['fallback_enabled'] ) && '1' === $_POST['fallback_enabled'];
		$settings['stats_enabled']          = isset( $_POST['stats_enabled'] ) && '1' === $_POST['stats_enabled'];
		$settings['default_preset']         = isset( $_POST['default_preset'] ) ? sanitize_key( $_POST['default_preset'] ) : 'light';
		$settings['currency']               = isset( $_POST['currency'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_POST['currency'] ) ) ) : 'RUB';
		$settings['custom_currency']        = isset( $_POST['custom_currency'] ) ? sanitize_text_field( wp_unslash( $_POST['custom_currency'] ) ) : '';
		$settings['keep_data_on_uninstall'] = isset( $_POST['keep_data_on_uninstall'] ) && '1' === $_POST['keep_data_on_uninstall'];

		// Appearance tab fields.
		$appearance_keys = array(
			'default_title',
			'default_description',
			'footer_text',
			'default_button_text',
			'button_style',
			'service_column_label',
			'time_column_label',
			'price_column_label',
			'on_request_text',
			'custom_css',
		);

		foreach ( $appearance_keys as $key ) {
			if ( isset( $_POST[ $key ] ) ) {
				if ( 'custom_css' === $key ) {
					// Sanitize CSS but allow most CSS properties.
					$settings[ $key ] = wp_strip_all_tags( wp_unslash( $_POST[ $key ] ) );
				} elseif ( in_array( $key, array( 'default_description', 'footer_text' ), true ) ) {
					// Allow basic HTML for descriptions.
					$settings[ $key ] = wp_kses_post( wp_unslash( $_POST[ $key ] ) );
				} else {
					$settings[ $key ] = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
				}
			}
		}

		update_option( 'mvweb_pt_settings', $settings );

		wp_send_json_success(
			array(
				'message' => __( 'Settings saved successfully.', 'mvweb-price-table' ),
			)
		);
	}

	/**
	 * Admin: Save appearance settings handler.
	 *
	 * @since 1.1.0
	 * @deprecated 2.2.0 Use admin_save_settings() instead.
	 * @return void
	 */
	public function admin_save_appearance() {
		// Redirect to unified settings handler.
		$this->admin_save_settings();
	}

	/**
	 * Admin: Get statistics handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_get_stats() {
		$this->verify_admin_request();

		$period  = isset( $_POST['period'] ) ? sanitize_key( $_POST['period'] ) : 'month';
		$form_id = isset( $_POST['form_id'] ) && '' !== $_POST['form_id'] ? absint( $_POST['form_id'] ) : null;

		$statistics = new MVweb_PT_Statistics();
		$stats      = $statistics->get_stats( $period, $form_id );

		wp_send_json_success( $stats );
	}

	/**
	 * Admin: Export statistics handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_export_stats() {
		$this->verify_admin_request();

		$period  = isset( $_POST['period'] ) ? sanitize_key( $_POST['period'] ) : 'month';
		$form_id = isset( $_POST['form_id'] ) && '' !== $_POST['form_id'] ? absint( $_POST['form_id'] ) : null;

		$statistics = new MVweb_PT_Statistics();
		$csv        = $statistics->export_csv( $period, $form_id );

		wp_send_json_success(
			array(
				'csv'      => $csv,
				'filename' => 'price-table-stats-' . gmdate( 'Y-m-d' ) . '.csv',
			)
		);
	}

	/**
	 * Admin: Clear statistics handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_clear_stats() {
		$this->verify_admin_request();

		$period  = isset( $_POST['period'] ) ? sanitize_key( $_POST['period'] ) : 'all';
		$form_id = isset( $_POST['form_id'] ) && '' !== $_POST['form_id'] ? absint( $_POST['form_id'] ) : null;

		$statistics = new MVweb_PT_Statistics();
		$deleted    = $statistics->clear_stats( $period, $form_id );

		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: %d: number of deleted entries */
					__( 'Statistics cleared. %d entries deleted.', 'mvweb-price-table' ),
					$deleted
				),
				'deleted' => $deleted,
			)
		);
	}

	/**
	 * Admin: Export logs handler.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function admin_export_logs() {
		$this->verify_admin_request();

		$json     = MVweb_PT_Logger::export_json();
		$filename = 'mvweb-price-table-logs-' . gmdate( 'Y-m-d-His' ) . '.json';

		header( 'Content-Type: application/json' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Length: ' . strlen( $json ) );

		echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON export
		exit;
	}

	/**
	 * Admin: Fetch sheets list from spreadsheet.
	 *
	 * @since 2.2.0
	 * @return void
	 */
	public function admin_fetch_sheets() {
		$this->verify_admin_request();

		$spreadsheet_url = isset( $_POST['spreadsheet_url'] ) ? esc_url_raw( wp_unslash( $_POST['spreadsheet_url'] ) ) : '';

		if ( empty( $spreadsheet_url ) ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_url',
					'message' => __( 'Google Sheets URL is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$sheets         = new MVweb_PT_Google_Sheets();
		$spreadsheet_id = $sheets->extract_spreadsheet_id( $spreadsheet_url );

		if ( ! $spreadsheet_id ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_url',
					'message' => __( 'Invalid Google Sheets URL.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$sheets_list = $sheets->fetch_sheets_list( $spreadsheet_id );

		if ( is_wp_error( $sheets_list ) ) {
			wp_send_json_error(
				array(
					'code'    => $sheets_list->get_error_code(),
					'message' => $sheets_list->get_error_message(),
				),
				400
			);
		}

		wp_send_json_success(
			array(
				'sheets'  => $sheets_list,
				'message' => sprintf(
					/* translators: %d: number of sheets found */
					__( 'Found %d sheets.', 'mvweb-price-table' ),
					count( $sheets_list )
				),
			)
		);
	}

	/**
	 * Admin: Auto-detect column mapping from spreadsheet headers.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function admin_auto_detect_mapping() {
		$this->verify_admin_request();

		$spreadsheet_url = isset( $_POST['spreadsheet_url'] ) ? esc_url_raw( wp_unslash( $_POST['spreadsheet_url'] ) ) : '';

		if ( empty( $spreadsheet_url ) ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_url',
					'message' => __( 'Google Sheets URL is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$sheets         = new MVweb_PT_Google_Sheets();
		$spreadsheet_id = $sheets->extract_spreadsheet_id( $spreadsheet_url );

		if ( ! $spreadsheet_id ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_url',
					'message' => __( 'Invalid Google Sheets URL.', 'mvweb-price-table' ),
				),
				400
			);
		}

		// Fetch raw data to get headers.
		$headers = $sheets->fetch_headers( $spreadsheet_id );

		if ( is_wp_error( $headers ) ) {
			wp_send_json_error(
				array(
					'code'    => $headers->get_error_code(),
					'message' => $headers->get_error_message(),
				),
				400
			);
		}

		// Use field mapper to auto-detect mapping.
		$mapper          = new MVweb_PT_Field_Mapper();
		$detected_mapping = $mapper->auto_detect_mapping( $headers );

		wp_send_json_success(
			array(
				'mapping' => $detected_mapping,
				'headers' => $headers,
				'message' => __( 'Columns detected successfully.', 'mvweb-price-table' ),
			)
		);
	}

	/**
	 * Fetch preview data from spreadsheet.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function admin_fetch_preview() {
		$this->verify_admin_request();

		$spreadsheet_url = isset( $_POST['spreadsheet_url'] ) ? esc_url_raw( wp_unslash( $_POST['spreadsheet_url'] ) ) : '';
		$limit           = isset( $_POST['limit'] ) ? absint( $_POST['limit'] ) : 20;

		if ( empty( $spreadsheet_url ) ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_url',
					'message' => __( 'Google Sheets URL is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$sheets         = new MVweb_PT_Google_Sheets();
		$spreadsheet_id = $sheets->extract_spreadsheet_id( $spreadsheet_url );

		if ( ! $spreadsheet_id ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_url',
					'message' => __( 'Invalid Google Sheets URL.', 'mvweb-price-table' ),
				),
				400
			);
		}

		// Fetch raw rows from spreadsheet.
		$raw_data = $sheets->fetch_raw_rows( $spreadsheet_id, $limit + 1 );

		if ( is_wp_error( $raw_data ) ) {
			wp_send_json_error(
				array(
					'code'    => $raw_data->get_error_code(),
					'message' => $raw_data->get_error_message(),
				),
				400
			);
		}

		// First row is headers, rest is data.
		$headers = ! empty( $raw_data ) ? array_shift( $raw_data ) : array();
		$rows    = array_slice( $raw_data, 0, $limit );

		wp_send_json_success(
			array(
				'headers' => $headers,
				'rows'    => $rows,
			)
		);
	}
}

// Initialize AJAX handlers.
new MVweb_PT_Ajax();
