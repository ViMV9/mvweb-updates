<?php
/**
 * Statistics class for MVweb Price Table.
 *
 * Handles collection and retrieval of usage statistics.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PT_Statistics
 *
 * Manages statistics collection and reporting.
 *
 * @since 1.0.0
 */
class MVweb_PT_Statistics {

	/**
	 * Table name.
	 *
	 * @since 1.0.0
	 * @var string
	 */
	private $table_name;

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		global $wpdb;
		$this->table_name = $wpdb->prefix . 'mvweb_pt_stats';
	}

	/**
	 * Create statistics table.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function create_table() {
		global $wpdb;

		$table_name      = $wpdb->prefix . 'mvweb_pt_stats';
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table_name} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			form_id int(11) NOT NULL,
			brand varchar(100) DEFAULT NULL,
			type varchar(100) DEFAULT NULL,
			model varchar(255) DEFAULT NULL,
			action varchar(50) NOT NULL DEFAULT 'view',
			ip_hash varchar(64) DEFAULT NULL,
			user_agent varchar(255) DEFAULT NULL,
			referer varchar(500) DEFAULT NULL,
			created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY form_id (form_id),
			KEY brand (brand),
			KEY created_at (created_at),
			KEY action (action)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/**
	 * Drop statistics table.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function drop_table() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'mvweb_pt_stats';
		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $table_name ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
	}

	/**
	 * Check if statistics is enabled.
	 *
	 * @since 1.0.0
	 * @return bool True if enabled.
	 */
	public function is_enabled() {
		return (bool) mvweb_pt_get_option( 'stats_enabled', true );
	}

	/**
	 * Log a request directly to database.
	 *
	 * @since 1.0.0
	 * @param int    $form_id Form ID.
	 * @param string $action  Action type (view, get_brands, get_types, get_models, get_prices).
	 * @param array  $data    Additional data (brand, type, model).
	 * @return bool True on success.
	 */
	public function log_request( $form_id, $action = 'view', $data = array() ) {
		global $wpdb;

		if ( ! $this->is_enabled() ) {
			return false;
		}

		// Don't log admin requests.
		if ( is_admin() && ! wp_doing_ajax() ) {
			return false;
		}

		// Hash IP for privacy.
		$ip      = $this->get_client_ip();
		$ip_hash = $ip ? hash( 'sha256', $ip . wp_salt() ) : null;

		$row = array(
			'form_id'    => absint( $form_id ),
			'action'     => sanitize_key( $action ),
			'brand'      => isset( $data['brand'] ) ? sanitize_text_field( $data['brand'] ) : null,
			'type'       => isset( $data['type'] ) ? sanitize_text_field( $data['type'] ) : null,
			'model'      => isset( $data['model'] ) ? sanitize_text_field( $data['model'] ) : null,
			'ip_hash'    => $ip_hash,
			'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( mb_substr( $_SERVER['HTTP_USER_AGENT'], 0, 255 ) ) ) : null,
			'referer'    => isset( $_SERVER['HTTP_REFERER'] ) ? esc_url_raw( wp_unslash( mb_substr( $_SERVER['HTTP_REFERER'], 0, 500 ) ) ) : null,
			'created_at' => current_time( 'mysql' ),
		);

		$result = $wpdb->insert( $this->table_name, $row ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery

		// Cleanup old records with 1% probability (to avoid running on every request).
		// phpcs:ignore WordPress.WP.AlternativeFunctions.rand_mt_rand
		if ( 1 === mt_rand( 1, 100 ) ) {
			$this->clear_stats( 'old' );
		}

		return false !== $result;
	}

	/**
	 * Get client IP address.
	 *
	 * @since 1.0.0
	 * @return string|null IP address or null.
	 */
	private function get_client_ip() {
		$ip_keys = array(
			'HTTP_CF_CONNECTING_IP', // Cloudflare.
			'HTTP_X_FORWARDED_FOR',
			'HTTP_X_REAL_IP',
			'REMOTE_ADDR',
		);

		foreach ( $ip_keys as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$ip = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
				// Handle comma-separated IPs (X-Forwarded-For).
				if ( strpos( $ip, ',' ) !== false ) {
					$ips = explode( ',', $ip );
					$ip  = trim( $ips[0] );
				}
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
					return $ip;
				}
			}
		}

		return null;
	}

	/**
	 * Get statistics for a period.
	 *
	 * @since 1.0.0
	 * @param string   $period  Period (today, week, month, year, all).
	 * @param int|null $form_id Optional form ID to filter.
	 * @return array Statistics data.
	 */
	public function get_stats( $period = 'month', $form_id = null ) {
		global $wpdb;

		$where     = array( '1=1' );
		$where_sql = '';

		// Period filter.
		$date_from = $this->get_period_start( $period );
		if ( $date_from ) {
			$where[] = $wpdb->prepare( 'created_at >= %s', $date_from );
		}

		// Form filter.
		if ( $form_id ) {
			$where[] = $wpdb->prepare( 'form_id = %d', $form_id );
		}

		$where_sql = implode( ' AND ', $where );

		$stats = array(
			'total_requests'   => 0,
			'unique_visitors'  => 0,
			'price_lookups'    => 0,
			'top_brands'       => array(),
			'top_models'       => array(),
			'requests_by_day'  => array(),
			'requests_by_form' => array(),
		);

		// Total requests.
		$stats['total_requests'] = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i WHERE {$where_sql}", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$this->table_name
			)
		);

		// Unique visitors (by IP hash).
		$stats['unique_visitors'] = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT ip_hash) FROM %i WHERE {$where_sql} AND ip_hash IS NOT NULL", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$this->table_name
			)
		);

		// Price lookups (get_prices action).
		$price_where           = $where;
		$price_where[]         = "action = 'get_prices'";
		$price_where_sql       = implode( ' AND ', $price_where );
		$stats['price_lookups'] = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT COUNT(*) FROM %i WHERE {$price_where_sql}", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$this->table_name
			)
		);

		// Top brands.
		$stats['top_brands'] = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT brand, COUNT(*) as count FROM %i WHERE {$where_sql} AND brand IS NOT NULL AND brand != '' GROUP BY brand ORDER BY count DESC LIMIT 10", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$this->table_name
			),
			ARRAY_A
		);

		// Top models.
		$stats['top_models'] = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT model, brand, COUNT(*) as count FROM %i WHERE {$where_sql} AND model IS NOT NULL AND model != '' GROUP BY model, brand ORDER BY count DESC LIMIT 10", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$this->table_name
			),
			ARRAY_A
		);

		// Requests by day (last 30 days).
		$stats['requests_by_day'] = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT DATE(created_at) as date, COUNT(*) as count FROM %i WHERE {$where_sql} AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) GROUP BY DATE(created_at) ORDER BY date ASC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$this->table_name
			),
			ARRAY_A
		);

		// Requests by form.
		$stats['requests_by_form'] = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT form_id, COUNT(*) as count FROM %i WHERE {$where_sql} GROUP BY form_id ORDER BY count DESC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$this->table_name
			),
			ARRAY_A
		);

		return $stats;
	}

	/**
	 * Get period start date.
	 *
	 * @since 1.0.0
	 * @param string $period Period name.
	 * @return string|null Date string or null for all.
	 */
	private function get_period_start( $period ) {
		switch ( $period ) {
			case 'today':
				return gmdate( 'Y-m-d 00:00:00' );
			case 'week':
				return gmdate( 'Y-m-d 00:00:00', strtotime( '-7 days' ) );
			case 'month':
				return gmdate( 'Y-m-d 00:00:00', strtotime( '-30 days' ) );
			case 'year':
				return gmdate( 'Y-m-d 00:00:00', strtotime( '-365 days' ) );
			case 'all':
			default:
				return null;
		}
	}

	/**
	 * Clear statistics.
	 *
	 * @since 1.0.0
	 * @param string   $period  Period to clear (all, old).
	 * @param int|null $form_id Optional form ID.
	 * @return int Number of deleted rows.
	 */
	public function clear_stats( $period = 'all', $form_id = null ) {
		global $wpdb;

		$where = array( '1=1' );

		if ( 'old' === $period ) {
			// Delete records older than 90 days.
			$where[] = $wpdb->prepare( 'created_at < %s', gmdate( 'Y-m-d 00:00:00', strtotime( '-90 days' ) ) );
		}

		if ( $form_id ) {
			$where[] = $wpdb->prepare( 'form_id = %d', $form_id );
		}

		$where_sql = implode( ' AND ', $where );

		$deleted = $wpdb->query( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"DELETE FROM %i WHERE {$where_sql}", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$this->table_name
			)
		);

		return (int) $deleted;
	}

	/**
	 * Export statistics to CSV.
	 *
	 * @since 1.0.0
	 * @param string   $period  Period to export.
	 * @param int|null $form_id Optional form ID.
	 * @return string CSV content.
	 */
	public function export_csv( $period = 'month', $form_id = null ) {
		global $wpdb;

		$where = array( '1=1' );

		$date_from = $this->get_period_start( $period );
		if ( $date_from ) {
			$where[] = $wpdb->prepare( 'created_at >= %s', $date_from );
		}

		if ( $form_id ) {
			$where[] = $wpdb->prepare( 'form_id = %d', $form_id );
		}

		$where_sql = implode( ' AND ', $where );

		$results = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT form_id, brand, type, model, action, created_at FROM %i WHERE {$where_sql} ORDER BY created_at DESC LIMIT 10000", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$this->table_name
			),
			ARRAY_A
		);

		$csv = array();

		// Header row.
		$csv[] = array(
			__( 'Form ID', 'mvweb-price-table' ),
			__( 'Brand', 'mvweb-price-table' ),
			__( 'Type', 'mvweb-price-table' ),
			__( 'Model', 'mvweb-price-table' ),
			__( 'Action', 'mvweb-price-table' ),
			__( 'Date', 'mvweb-price-table' ),
		);

		// Data rows.
		foreach ( $results as $row ) {
			$csv[] = array(
				$row['form_id'],
				$row['brand'],
				$row['type'],
				$row['model'],
				$row['action'],
				$row['created_at'],
			);
		}

		// Build CSV string.
		$output = fopen( 'php://temp', 'r+' );
		foreach ( $csv as $row ) {
			fputcsv( $output, $row );
		}
		rewind( $output );
		$csv_string = stream_get_contents( $output );
		fclose( $output );

		return $csv_string;
	}

	/**
	 * Get statistics summary for dashboard widget.
	 *
	 * @since 1.0.0
	 * @return array Summary data.
	 */
	public function get_summary() {
		return array(
			'today' => $this->get_stats( 'today' ),
			'week'  => $this->get_stats( 'week' ),
			'month' => $this->get_stats( 'month' ),
		);
	}

	/**
	 * Get Chart.js compatible data for requests graph.
	 *
	 * @since 1.0.0
	 * @param string   $period  Period (week, month).
	 * @param int|null $form_id Optional form ID.
	 * @return array Chart.js data structure.
	 */
	public function get_chart_data( $period = 'month', $form_id = null ) {
		global $wpdb;

		$days = 'week' === $period ? 7 : 30;

		$where = array( '1=1' );
		$where[] = $wpdb->prepare( 'created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)', $days );

		if ( $form_id ) {
			$where[] = $wpdb->prepare( 'form_id = %d', $form_id );
		}

		$where_sql = implode( ' AND ', $where );

		// Get daily counts.
		$results = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT DATE(created_at) as date, COUNT(*) as total, COUNT(DISTINCT ip_hash) as unique_visitors
				FROM %i
				WHERE {$where_sql}
				GROUP BY DATE(created_at)
				ORDER BY date ASC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$this->table_name
			),
			ARRAY_A
		);

		// Build complete date range.
		$labels       = array();
		$total_data   = array();
		$unique_data  = array();
		$results_map  = array();

		// Map results by date.
		foreach ( $results as $row ) {
			$results_map[ $row['date'] ] = $row;
		}

		// Fill all days.
		for ( $i = $days - 1; $i >= 0; $i-- ) {
			$date     = gmdate( 'Y-m-d', strtotime( "-{$i} days" ) );
			$labels[] = gmdate( 'M j', strtotime( $date ) );

			if ( isset( $results_map[ $date ] ) ) {
				$total_data[]  = (int) $results_map[ $date ]['total'];
				$unique_data[] = (int) $results_map[ $date ]['unique_visitors'];
			} else {
				$total_data[]  = 0;
				$unique_data[] = 0;
			}
		}

		return array(
			'labels'   => $labels,
			'datasets' => array(
				array(
					'label'           => __( 'Total Requests', 'mvweb-price-table' ),
					'data'            => $total_data,
					'borderColor'     => '#793ea4',
					'backgroundColor' => 'rgba(121, 62, 164, 0.1)',
					'fill'            => true,
					'tension'         => 0.4,
				),
				array(
					'label'           => __( 'Unique Visitors', 'mvweb-price-table' ),
					'data'            => $unique_data,
					'borderColor'     => '#2271b1',
					'backgroundColor' => 'rgba(34, 113, 177, 0.1)',
					'fill'            => true,
					'tension'         => 0.4,
				),
			),
		);
	}

	/**
	 * Get hierarchy level statistics.
	 *
	 * Returns top values for a specific hierarchy level (brand, type, or model column).
	 *
	 * @since 2.2.0
	 * @param string   $column  Column name (brand, type, model).
	 * @param string   $period  Period (today, week, month, year, all).
	 * @param int|null $form_id Optional form ID to filter.
	 * @param int      $limit   Number of results (default 10).
	 * @return array Top values with counts.
	 */
	public function get_level_stats( $column, $period = 'month', $form_id = null, $limit = 10 ) {
		global $wpdb;

		// Validate column name.
		$valid_columns = array( 'brand', 'type', 'model' );
		if ( ! in_array( $column, $valid_columns, true ) ) {
			return array();
		}

		$where = array( '1=1' );

		// Period filter.
		$date_from = $this->get_period_start( $period );
		if ( $date_from ) {
			$where[] = $wpdb->prepare( 'created_at >= %s', $date_from );
		}

		// Form filter.
		if ( $form_id ) {
			$where[] = $wpdb->prepare( 'form_id = %d', $form_id );
		}

		// Filter out empty values.
		$where[] = $wpdb->prepare( '%i IS NOT NULL', $column );
		$where[] = $wpdb->prepare( '%i != %s', $column, '' );

		$where_sql = implode( ' AND ', $where );

		return $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT %i as value, COUNT(*) as count FROM %i WHERE {$where_sql} GROUP BY %i ORDER BY count DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$column,
				$this->table_name,
				$column,
				$limit
			),
			ARRAY_A
		);
	}

	/**
	 * Get referrer statistics.
	 *
	 * @since 1.0.0
	 * @param string   $period  Period.
	 * @param int|null $form_id Optional form ID.
	 * @return array Top referrers.
	 */
	public function get_referrer_stats( $period = 'month', $form_id = null ) {
		global $wpdb;

		$where = array( '1=1', "referer IS NOT NULL", "referer != ''" );

		$date_from = $this->get_period_start( $period );
		if ( $date_from ) {
			$where[] = $wpdb->prepare( 'created_at >= %s', $date_from );
		}

		if ( $form_id ) {
			$where[] = $wpdb->prepare( 'form_id = %d', $form_id );
		}

		$where_sql = implode( ' AND ', $where );

		return $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT
					SUBSTRING_INDEX(SUBSTRING_INDEX(referer, '/', 3), '//', -1) as source,
					COUNT(*) as count
				FROM %i
				WHERE {$where_sql}
				GROUP BY source
				ORDER BY count DESC
				LIMIT 10", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$this->table_name
			),
			ARRAY_A
		);
	}

	/**
	 * Get action breakdown statistics.
	 *
	 * @since 1.0.0
	 * @param string   $period  Period.
	 * @param int|null $form_id Optional form ID.
	 * @return array Action counts.
	 */
	public function get_action_stats( $period = 'month', $form_id = null ) {
		global $wpdb;

		$where = array( '1=1' );

		$date_from = $this->get_period_start( $period );
		if ( $date_from ) {
			$where[] = $wpdb->prepare( 'created_at >= %s', $date_from );
		}

		if ( $form_id ) {
			$where[] = $wpdb->prepare( 'form_id = %d', $form_id );
		}

		$where_sql = implode( ' AND ', $where );

		$results = $wpdb->get_results( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT action, COUNT(*) as count FROM %i WHERE {$where_sql} GROUP BY action ORDER BY count DESC", // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$this->table_name
			),
			ARRAY_A
		);

		// Map to readable labels.
		$labels = array(
			'get_brands' => __( 'Loaded Brands', 'mvweb-price-table' ),
			'get_types'  => __( 'Selected Brand', 'mvweb-price-table' ),
			'get_models' => __( 'Selected Type', 'mvweb-price-table' ),
			'get_prices' => __( 'Viewed Prices', 'mvweb-price-table' ),
		);

		foreach ( $results as &$row ) {
			$row['label'] = isset( $labels[ $row['action'] ] ) ? $labels[ $row['action'] ] : $row['action'];
		}

		return $results;
	}

	/**
	 * Get total record count.
	 *
	 * @since 1.0.0
	 * @return int Total records.
	 */
	public function get_total_records() {
		global $wpdb;

		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				'SELECT COUNT(*) FROM %i',
				$this->table_name
			)
		);
	}

	/**
	 * Get database table size.
	 *
	 * @since 1.0.0
	 * @return string Human-readable size.
	 */
	public function get_table_size() {
		global $wpdb;

		$size = $wpdb->get_var( // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
			$wpdb->prepare(
				"SELECT (DATA_LENGTH + INDEX_LENGTH) FROM information_schema.TABLES
				WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s",
				DB_NAME,
				$this->table_name
			)
		);

		return size_format( (int) $size, 2 );
	}
}
