<?php
/**
 * Cache class for MVweb Price Table.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PT_Cache
 *
 * Handles caching with WordPress Transients API and fallback storage.
 *
 * @since 1.0.0
 */
class MVweb_PT_Cache {

	/**
	 * Cache prefix.
	 *
	 * @var string
	 */
	const PREFIX = 'mvweb_pt_';

	/**
	 * Fallback prefix.
	 *
	 * @var string
	 */
	const FALLBACK_PREFIX = 'mvweb_pt_fallback_';

	/**
	 * Default TTL in seconds (1 hour).
	 *
	 * @var int
	 */
	const DEFAULT_TTL = 3600;

	/**
	 * Get cached data.
	 *
	 * @since 1.0.0
	 * @param string $key Cache key.
	 * @return mixed|false Cached data or false if not found.
	 */
	public function get( $key ) {
		$cache_key = $this->build_key( $key );
		$data      = get_transient( $cache_key );

		if ( false === $data ) {
			return false;
		}

		return $data;
	}

	/**
	 * Set cached data.
	 *
	 * @since 1.0.0
	 * @param string $key  Cache key.
	 * @param mixed  $data Data to cache.
	 * @param int    $ttl  Time to live in seconds.
	 * @return bool True on success, false on failure.
	 */
	public function set( $key, $data, $ttl = self::DEFAULT_TTL ) {
		$cache_key = $this->build_key( $key );
		return set_transient( $cache_key, $data, $ttl );
	}

	/**
	 * Delete cached data.
	 *
	 * @since 1.0.0
	 * @param string $key Cache key.
	 * @return bool True on success, false on failure.
	 */
	public function delete( $key ) {
		$cache_key = $this->build_key( $key );
		return delete_transient( $cache_key );
	}

	/**
	 * Get fallback data (last successful fetch).
	 *
	 * @since 1.0.0
	 * @param string $key Cache key.
	 * @return mixed|false Fallback data or false if not found.
	 */
	public function get_fallback( $key ) {
		$settings = get_option( 'mvweb_pt_settings', array() );

		// Check if fallback is enabled.
		if ( empty( $settings['fallback_enabled'] ) ) {
			return false;
		}

		$fallback_key = $this->build_fallback_key( $key );
		return get_option( $fallback_key, false );
	}

	/**
	 * Delete fallback data.
	 *
	 * @since 1.0.0
	 * @param string $key Cache key.
	 * @return bool True on success, false on failure.
	 */
	public function delete_fallback( $key ) {
		$fallback_key = $this->build_fallback_key( $key );
		return delete_option( $fallback_key );
	}

	/**
	 * Flush all plugin cache.
	 *
	 * @since 1.0.0
	 * @return int Number of deleted transients.
	 */
	public function flush_all() {
		global $wpdb;

		$count = 0;

		// Delete transients.
		$transients = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . self::PREFIX ) . '%'
			)
		);

		foreach ( $transients as $transient ) {
			$key = str_replace( '_transient_', '', $transient );
			if ( delete_transient( $key ) ) {
				++$count;
			}
		}

		// Delete timeout transients.
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_timeout_' . self::PREFIX ) . '%'
			)
		);

		return $count;
	}

	/**
	 * Flush all fallback data.
	 *
	 * @since 1.0.0
	 * @return int Number of deleted options.
	 */
	public function flush_fallbacks() {
		global $wpdb;

		$count = 0;

		$options = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT option_name FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( self::FALLBACK_PREFIX ) . '%'
			)
		);

		foreach ( $options as $option ) {
			if ( delete_option( $option ) ) {
				++$count;
			}
		}

		return $count;
	}

	/**
	 * Get cache statistics.
	 *
	 * @since 1.0.0
	 * @return array Cache statistics.
	 */
	public function get_stats() {
		global $wpdb;

		// Count transients.
		$transient_count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . self::PREFIX ) . '%'
			)
		);

		// Count fallbacks.
		$fallback_count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$wpdb->options} WHERE option_name LIKE %s",
				$wpdb->esc_like( self::FALLBACK_PREFIX ) . '%'
			)
		);

		// Get total size (approximate).
		$size = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT SUM(LENGTH(option_value)) FROM {$wpdb->options}
				WHERE option_name LIKE %s OR option_name LIKE %s",
				$wpdb->esc_like( '_transient_' . self::PREFIX ) . '%',
				$wpdb->esc_like( self::FALLBACK_PREFIX ) . '%'
			)
		);

		return array(
			'transients' => (int) $transient_count,
			'fallbacks'  => (int) $fallback_count,
			'size'       => (int) $size,
			'size_human' => size_format( (int) $size, 2 ),
		);
	}

	/**
	 * Build cache key with prefix.
	 *
	 * @since 1.0.0
	 * @param string $key Original key.
	 * @return string Prefixed key.
	 */
	private function build_key( $key ) {
		return self::PREFIX . md5( $key );
	}

	/**
	 * Build fallback key with prefix.
	 *
	 * @since 1.0.0
	 * @param string $key Original key.
	 * @return string Prefixed fallback key.
	 */
	private function build_fallback_key( $key ) {
		return self::FALLBACK_PREFIX . md5( $key );
	}

	/**
	 * Check if cache is expired.
	 *
	 * @since 1.0.0
	 * @param string $key Cache key.
	 * @return bool True if expired or not exists.
	 */
	public function is_expired( $key ) {
		return false === $this->get( $key );
	}

	/**
	 * Check if data is from fallback.
	 *
	 * @since 1.0.0
	 * @param string $key Cache key.
	 * @return bool True if cache is expired and fallback will be used.
	 */
	public function is_using_fallback( $key ) {
		$cache_key = $this->build_key( $key );
		$cached    = get_transient( $cache_key );

		if ( false !== $cached ) {
			return false;
		}

		$fallback = $this->get_fallback( $key );
		return false !== $fallback;
	}

	/**
	 * Get fallback info.
	 *
	 * @since 1.0.0
	 * @param string $key Cache key.
	 * @return array|false Fallback info array or false.
	 */
	public function get_fallback_info( $key ) {
		$meta_key = $this->build_fallback_key( $key ) . '_meta';
		return get_option( $meta_key, false );
	}

	/**
	 * Set fallback data with metadata.
	 *
	 * @since 1.0.0
	 * @param string $key  Cache key.
	 * @param mixed  $data Data to store as fallback.
	 * @return bool True on success, false on failure.
	 */
	public function set_fallback( $key, $data ) {
		$fallback_key = $this->build_fallback_key( $key );
		$result       = update_option( $fallback_key, $data, false );

		// Store metadata about the fallback.
		$meta_key = $fallback_key . '_meta';
		update_option(
			$meta_key,
			array(
				'updated_at' => current_time( 'mysql' ),
				'timestamp'  => time(),
			),
			false
		);

		return $result;
	}

	/**
	 * Log cache error.
	 *
	 * @since 1.0.0
	 * @param string $key     Cache key (usually spreadsheet ID).
	 * @param string $message Error message.
	 * @return void
	 */
	public function log_error( $key, $message ) {
		$errors   = get_option( 'mvweb_pt_cache_errors', array() );
		$errors[] = array(
			'key'       => $key,
			'message'   => $message,
			'timestamp' => current_time( 'mysql' ),
		);

		// Keep only last 50 errors.
		if ( count( $errors ) > 50 ) {
			$errors = array_slice( $errors, -50 );
		}

		update_option( 'mvweb_pt_cache_errors', $errors, false );

		// Also log via plugin logger.
		mvweb_pt_log( 'Cache error for key ' . $key . ': ' . $message, 'error' );
	}

	/**
	 * Get cache errors.
	 *
	 * @since 1.0.0
	 * @param int $limit Number of errors to return.
	 * @return array Array of errors.
	 */
	public function get_errors( $limit = 10 ) {
		$errors = get_option( 'mvweb_pt_cache_errors', array() );
		return array_slice( array_reverse( $errors ), 0, $limit );
	}

	/**
	 * Clear cache errors.
	 *
	 * @since 1.0.0
	 * @return bool True on success.
	 */
	public function clear_errors() {
		return delete_option( 'mvweb_pt_cache_errors' );
	}

	/**
	 * Refresh cache for a specific form.
	 *
	 * @since 1.0.0
	 * @param int $form_id Form ID.
	 * @return bool|WP_Error True on success, WP_Error on failure.
	 */
	public function refresh_form_cache( $form_id ) {
		$form = mvweb_pt_get_form( $form_id );

		if ( ! $form || empty( $form['spreadsheet_url'] ) ) {
			return new WP_Error(
				'invalid_form',
				__( 'Form not found or has no spreadsheet URL.', 'mvweb-price-table' )
			);
		}

		$sheets         = new MVweb_PT_Google_Sheets();
		$spreadsheet_id = $sheets->extract_spreadsheet_id( $form['spreadsheet_url'] );

		if ( ! $spreadsheet_id ) {
			return new WP_Error(
				'invalid_url',
				__( 'Invalid Google Sheets URL.', 'mvweb-price-table' )
			);
		}

		// Clear existing cache.
		$cache_key = 'sheets_' . $spreadsheet_id;
		$this->delete( $cache_key );

		// Fetch fresh data.
		$result = $sheets->fetch_data( $spreadsheet_id, false );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		return true;
	}
}
