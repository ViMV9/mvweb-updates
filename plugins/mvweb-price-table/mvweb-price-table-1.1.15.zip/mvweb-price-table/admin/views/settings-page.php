<?php
/**
 * Admin settings page template.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$forms    = mvweb_pt_get_forms();
$settings = get_option( 'mvweb_pt_settings', array() );
$presets  = mvweb_pt_get_presets();

$current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'forms'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.

$tabs = array(
	'forms'      => array(
		'label' => __( 'Forms', 'mvweb-price-table' ),
		'count' => count( $forms ),
		'icon'  => 'grid',
	),
	'settings'   => array(
		'label' => __( 'Settings', 'mvweb-price-table' ),
		'count' => null,
		'icon'  => 'gear',
	),
	'appearance' => array(
		'label' => __( 'Appearance', 'mvweb-price-table' ),
		'count' => null,
		'icon'  => 'brush',
	),
	'statistics' => array(
		'label' => __( 'Statistics', 'mvweb-price-table' ),
		'count' => null,
		'icon'  => 'chart',
	),
	'help'       => array(
		'label' => __( 'Help', 'mvweb-price-table' ),
		'count' => null,
		'icon'  => 'help',
	),
);

$icons = array(
	'grid'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
	'gear'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
	'brush' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M9.06 11.9l8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08"/><path d="M7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04a3.01 3.01 0 0 0-3-3.02z"/></svg>',
	'chart' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
	'help'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">PT</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Price Table', 'mvweb-price-table' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_PT_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $tabs as $tab_id => $tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $tab_id ); ?>"
						class="mvweb-nav__link <?php echo $current_tab === $tab_id ? 'mvweb-nav__link--active' : ''; ?>"
						data-tab="<?php echo esc_attr( $tab_id ); ?>">
						<?php echo $icons[ $tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $tab['label'] ); ?>
						<?php if ( null !== $tab['count'] ) : ?>
							<span class="mvweb-nav__badge"><?php echo esc_html( (string) $tab['count'] ); ?></span>
						<?php endif; ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php settings_errors( 'mvweb_pt_messages' ); ?>

		<div id="forms" class="mvweb-tab-content <?php echo 'forms' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_PT_PATH . 'admin/views/tab-forms.php'; ?>
		</div>

		<form id="mvweb-pc-settings-form" method="post">
			<?php wp_nonce_field( 'mvweb_pt_save_settings', 'mvweb_pt_settings_nonce' ); ?>

			<div id="settings" class="mvweb-tab-content <?php echo 'settings' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_PT_PATH . 'admin/views/tab-settings.php'; ?>
			</div>

			<div id="appearance" class="mvweb-tab-content <?php echo 'appearance' === $current_tab ? 'active' : ''; ?>">
				<?php require MVWEB_PT_PATH . 'admin/views/tab-appearance.php'; ?>
			</div>

			<div class="mvweb-submit">
				<button type="submit" class="mvweb-btn mvweb-btn--primary">
					<?php esc_html_e( 'Save Settings', 'mvweb-price-table' ); ?>
				</button>
				<span class="mvweb-pc-settings-status mvweb-submit__hint"></span>
			</div>
		</form>

		<div id="statistics" class="mvweb-tab-content <?php echo 'statistics' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_PT_PATH . 'admin/views/tab-statistics.php'; ?>
		</div>

		<div id="help" class="mvweb-tab-content <?php echo 'help' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_PT_PATH . 'admin/views/tab-help.php'; ?>
		</div>

	</main>
</div>
