<?php
/**
 * Appearance tab template.
 *
 * @package MVweb_Price_Table
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Form Title & Description', 'mvweb-price-table' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'These settings can be overridden per form in the Forms tab.', 'mvweb-price-table' ); ?>
	</p>

	<div class="mvweb-form-row">
		<label for="default_title" class="mvweb-form-row__label"><?php esc_html_e( 'Default Title', 'mvweb-price-table' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="default_title" name="default_title" class="mvweb-input"
					value="<?php echo esc_attr( $settings['default_title'] ?? '' ); ?>">
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Default title displayed above the form. Leave empty to hide.', 'mvweb-price-table' ); ?>
			</p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="default_description" class="mvweb-form-row__label"><?php esc_html_e( 'Default Description', 'mvweb-price-table' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="default_description" name="default_description" class="mvweb-textarea" rows="3"><?php echo esc_textarea( $settings['default_description'] ?? '' ); ?></textarea>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Description text displayed below the title.', 'mvweb-price-table' ); ?>
			</p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="footer_text" class="mvweb-form-row__label"><?php esc_html_e( 'Footer Text', 'mvweb-price-table' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="footer_text" name="footer_text" class="mvweb-textarea" rows="2"><?php echo esc_textarea( $settings['footer_text'] ?? '' ); ?></textarea>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Text displayed below the price table. Supports basic HTML.', 'mvweb-price-table' ); ?>
			</p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Button Customization', 'mvweb-price-table' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="default_button_text" class="mvweb-form-row__label"><?php esc_html_e( 'Button Text', 'mvweb-price-table' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="default_button_text" name="default_button_text" class="mvweb-input"
					value="<?php echo esc_attr( $settings['default_button_text'] ?? __( 'Show Prices', 'mvweb-price-table' ) ); ?>">
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Custom CSS', 'mvweb-price-table' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="custom_css" class="mvweb-form-row__label"><?php esc_html_e( 'Additional CSS', 'mvweb-price-table' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="custom_css" name="custom_css" class="mvweb-textarea code" rows="10" placeholder="/* <?php esc_attr_e( 'Add your custom CSS here', 'mvweb-price-table' ); ?> */
.mvweb-pc {
    /* <?php esc_attr_e( 'Your styles', 'mvweb-price-table' ); ?> */
}"><?php echo esc_textarea( $settings['custom_css'] ?? '' ); ?></textarea>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Custom CSS will be added to the frontend. Use .mvweb-pc selector for specificity.', 'mvweb-price-table' ); ?>
			</p>
		</div>
	</div>
</div>
