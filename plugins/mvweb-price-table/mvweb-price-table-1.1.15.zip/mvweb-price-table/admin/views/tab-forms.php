<?php
/**
 * Forms tab template.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Calculator Forms', 'mvweb-price-table' ); ?></div>
		<button type="button" class="mvweb-btn mvweb-btn--primary mvweb-pc-add-form">
			<?php esc_html_e( 'Add New Form', 'mvweb-price-table' ); ?>
		</button>
	</div>

	<?php if ( empty( $forms ) ) : ?>
		<div class="mvweb-empty">
			<div class="mvweb-empty__title"><?php esc_html_e( 'No forms yet', 'mvweb-price-table' ); ?></div>
			<p class="mvweb-empty__text"><?php esc_html_e( 'No forms created yet. Click "Add New Form" to create your first calculator form.', 'mvweb-price-table' ); ?></p>
		</div>
	<?php else : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table mvweb-pc-forms-table">
				<thead>
					<tr>
						<th class="column-id"><?php esc_html_e( 'ID', 'mvweb-price-table' ); ?></th>
						<th class="column-name"><?php esc_html_e( 'Name', 'mvweb-price-table' ); ?></th>
						<th class="column-shortcode"><?php esc_html_e( 'Shortcode', 'mvweb-price-table' ); ?></th>
						<th class="column-status"><?php esc_html_e( 'Status', 'mvweb-price-table' ); ?></th>
						<th class="column-actions cell-actions"><?php esc_html_e( 'Actions', 'mvweb-price-table' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $forms as $form ) : ?>
						<tr data-form-id="<?php echo esc_attr( $form['id'] ); ?>">
							<td class="column-id"><?php echo esc_html( $form['id'] ); ?></td>
							<td class="column-name">
								<strong><?php echo esc_html( $form['name'] ); ?></strong>
							</td>
							<td class="column-shortcode">
								<code class="mvweb-pc-shortcode"><?php echo esc_html( mvweb_pt_get_shortcode( $form['id'] ) ); ?></code>
								<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-pc-copy-shortcode" title="<?php esc_attr_e( 'Copy shortcode', 'mvweb-price-table' ); ?>">
									<span class="dashicons dashicons-clipboard"></span>
								</button>
							</td>
							<td class="column-status">
								<?php if ( 'active' === $form['status'] ) : ?>
									<span class="mvweb-badge mvweb-badge--success"><?php esc_html_e( 'Active', 'mvweb-price-table' ); ?></span>
								<?php else : ?>
									<span class="mvweb-badge mvweb-badge--plain"><?php esc_html_e( 'Inactive', 'mvweb-price-table' ); ?></span>
								<?php endif; ?>
							</td>
							<td class="column-actions cell-actions">
								<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-pc-edit-form" data-form-id="<?php echo esc_attr( $form['id'] ); ?>">
									<?php esc_html_e( 'Edit', 'mvweb-price-table' ); ?>
								</button>
								<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-btn--danger mvweb-pc-delete-form" data-form-id="<?php echo esc_attr( $form['id'] ); ?>">
									<?php esc_html_e( 'Delete', 'mvweb-price-table' ); ?>
								</button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</div>

<dialog id="mvweb-pc-form-modal" class="mvweb-dialog mvweb-pc-dialog--wide">
	<div class="mvweb-dialog__head">
		<h3 class="mvweb-pc-modal-title"><?php esc_html_e( 'Add New Form', 'mvweb-price-table' ); ?></h3>
		<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--icon mvweb-pc-modal-close" onclick="this.closest('dialog').close()">&times;</button>
	</div>
		<form id="mvweb-pc-form-edit" method="post">
			<?php wp_nonce_field( 'mvweb_pt_save_form', 'mvweb_pt_form_nonce' ); ?>
			<input type="hidden" name="form_id" id="mvweb-pc-form-id" value="">
			<input type="hidden" name="field_mapping" id="mvweb-pc-field-mapping" value="">

			<div class="mvweb-dialog__body">
				<div class="mvweb-pc-form-section">
					<h3><?php esc_html_e( 'Basic Settings', 'mvweb-price-table' ); ?></h3>

					<div class="mvweb-form-row">
						<label for="mvweb-pc-form-name" class="mvweb-form-row__label"><?php esc_html_e( 'Form Name', 'mvweb-price-table' ); ?> <span class="required">*</span></label>
						<div class="mvweb-form-row__field">
							<input type="text" id="mvweb-pc-form-name" name="name" class="mvweb-input" required>
						</div>
					</div>

					<div class="mvweb-form-row">
						<label for="mvweb-pc-form-url" class="mvweb-form-row__label"><?php esc_html_e( 'Google Sheets URL', 'mvweb-price-table' ); ?> <span class="required">*</span></label>
						<div class="mvweb-form-row__field">
							<input type="url" id="mvweb-pc-form-url" name="spreadsheet_url" class="mvweb-input" required>
							<p class="mvweb-form-row__desc"><?php esc_html_e( 'Paste the full URL of your public Google Sheets spreadsheet.', 'mvweb-price-table' ); ?></p>
							<div class="mvweb-pc-connection-buttons">
								<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-pc-test-connection">
									<?php esc_html_e( 'Test Connection', 'mvweb-price-table' ); ?>
								</button>
								<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-pc-auto-detect">
									<span class="dashicons dashicons-search"></span>
									<?php esc_html_e( 'Auto-Detect Columns', 'mvweb-price-table' ); ?>
								</button>
							</div>
							<span class="mvweb-pc-connection-status"></span>
						</div>
					</div>

					<div class="mvweb-form-row mvweb-pc-sheet-row" style="display: none;">
						<label for="mvweb-pc-form-sheet" class="mvweb-form-row__label"><?php esc_html_e( 'Sheet (Tab)', 'mvweb-price-table' ); ?></label>
						<div class="mvweb-form-row__field">
							<div class="mvweb-pc-sheet-controls">
								<select id="mvweb-pc-form-sheet" name="sheet_id" class="mvweb-select">
									<option value=""><?php esc_html_e( 'First sheet (default)', 'mvweb-price-table' ); ?></option>
								</select>
								<input type="hidden" id="mvweb-pc-form-sheet-name" name="sheet_name" value="">
								<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-btn--icon mvweb-pc-refresh-sheets" title="<?php esc_attr_e( 'Refresh sheets list', 'mvweb-price-table' ); ?>">
									<span class="dashicons dashicons-update"></span>
								</button>
								<span class="mvweb-pc-sheets-status"></span>
							</div>
							<p class="mvweb-form-row__desc"><?php esc_html_e( 'Select which sheet (tab) to use from the spreadsheet.', 'mvweb-price-table' ); ?></p>
						</div>
					</div>

					<div class="mvweb-form-row">
						<label for="mvweb-pc-form-preset" class="mvweb-form-row__label"><?php esc_html_e( 'Design Preset', 'mvweb-price-table' ); ?></label>
						<div class="mvweb-form-row__field">
							<select id="mvweb-pc-form-preset" name="preset" class="mvweb-select">
								<?php foreach ( $presets as $preset_key => $preset_name ) : ?>
									<option value="<?php echo esc_attr( $preset_key ); ?>">
										<?php echo esc_html( $preset_name ); ?>
									</option>
								<?php endforeach; ?>
							</select>
						</div>
					</div>

					<div class="mvweb-form-row">
						<label for="mvweb-pc-form-status" class="mvweb-form-row__label"><?php esc_html_e( 'Status', 'mvweb-price-table' ); ?></label>
						<div class="mvweb-form-row__field">
							<select id="mvweb-pc-form-status" name="status" class="mvweb-select">
								<option value="active"><?php esc_html_e( 'Active', 'mvweb-price-table' ); ?></option>
								<option value="inactive"><?php esc_html_e( 'Inactive', 'mvweb-price-table' ); ?></option>
							</select>
						</div>
					</div>
				</div>

				<div class="mvweb-pc-form-section mvweb-pc-mapping-section">
					<h3><?php esc_html_e( 'Field Mapping', 'mvweb-price-table' ); ?></h3>
					<p class="mvweb-block__sub"><?php esc_html_e( 'Configure which columns in your spreadsheet correspond to which data fields. Use "Auto-Detect" to automatically detect columns from headers.', 'mvweb-price-table' ); ?></p>

					<div class="mvweb-pc-mapping-presets">
						<label><?php esc_html_e( 'Quick Presets:', 'mvweb-price-table' ); ?></label>
						<?php foreach ( MVweb_PT_Field_Mapper::get_presets() as $preset_id => $preset_data ) : ?>
							<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-pc-preset-btn" data-preset="<?php echo esc_attr( $preset_id ); ?>" title="<?php echo esc_attr( $preset_data['description'] ); ?>">
								<?php echo esc_html( $preset_data['name'] ); ?>
							</button>
						<?php endforeach; ?>
					</div>

					<div class="mvweb-pc-mapping-table-wrapper">
						<table class="mvweb-pc-mapping-table mvweb-table">
							<thead>
								<tr>
									<th class="column-index"><?php esc_html_e( 'Column', 'mvweb-price-table' ); ?></th>
									<th class="column-header"><?php esc_html_e( 'Header', 'mvweb-price-table' ); ?></th>
									<th class="column-role"><?php esc_html_e( 'Role', 'mvweb-price-table' ); ?></th>
									<th class="column-label"><?php esc_html_e( 'Display Label', 'mvweb-price-table' ); ?></th>
									<th class="column-format"><?php esc_html_e( 'Format', 'mvweb-price-table' ); ?></th>
									<th class="column-mobile" title="<?php esc_attr_e( 'Full width on mobile devices', 'mvweb-price-table' ); ?>">
										<?php esc_html_e( 'Mobile', 'mvweb-price-table' ); ?><br>
										<small><?php esc_html_e( 'width 100%', 'mvweb-price-table' ); ?></small>
									</th>
								</tr>
							</thead>
							<tbody id="mvweb-pc-mapping-rows">
								<tr class="mvweb-pc-mapping-placeholder">
									<td colspan="6"><?php esc_html_e( 'Click "Auto-Detect Columns" or add columns manually.', 'mvweb-price-table' ); ?></td>
								</tr>
							</tbody>
						</table>
						<button type="button" class="mvweb-btn mvweb-btn--sm mvweb-pc-add-column">
							<span class="dashicons dashicons-plus-alt2"></span>
							<?php esc_html_e( 'Add Column', 'mvweb-price-table' ); ?>
						</button>
					</div>

					<div class="mvweb-pc-inheritance-settings">
						<h4><?php esc_html_e( 'Value Inheritance', 'mvweb-price-table' ); ?></h4>
						<label class="mvweb-check">
							<input type="checkbox" id="mvweb-pc-inheritance-enabled" name="inheritance_enabled">
							<?php esc_html_e( 'Enable value inheritance with pattern templates', 'mvweb-price-table' ); ?>
						</label>
						<p class="mvweb-form-row__desc"><?php esc_html_e( 'Allows using {pattern} syntax in hierarchy columns to define default values that apply to multiple items.', 'mvweb-price-table' ); ?></p>

						<div class="mvweb-pc-inheritance-options" style="display: none;">
							<label class="mvweb-check">
								<input type="checkbox" id="mvweb-pc-show-source">
								<?php esc_html_e( 'Show value source (admin only, for debugging)', 'mvweb-price-table' ); ?>
							</label>
						</div>
					</div>

					<div class="mvweb-pc-preview-section" style="display: none;">
						<h4><?php esc_html_e( 'Data Preview', 'mvweb-price-table' ); ?></h4>
						<div class="mvweb-pc-preview-table-wrapper">
							<table class="mvweb-pc-preview-table mvweb-table">
								<thead id="mvweb-pc-preview-headers"></thead>
								<tbody id="mvweb-pc-preview-rows"></tbody>
							</table>
						</div>
						<p class="mvweb-form-row__desc"><?php esc_html_e( 'Showing first 20 rows from your spreadsheet.', 'mvweb-price-table' ); ?></p>
					</div>
				</div>
			</div>

			<div class="mvweb-dialog__foot">
				<button type="button" class="mvweb-btn mvweb-pc-modal-cancel" onclick="this.closest('dialog').close()"><?php esc_html_e( 'Cancel', 'mvweb-price-table' ); ?></button>
				<button type="submit" class="mvweb-btn mvweb-btn--primary"><?php esc_html_e( 'Save Form', 'mvweb-price-table' ); ?></button>
			</div>
		</form>
</dialog>
