/**
 * Admin JavaScript for MVweb Price Table
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

(function($) {
	'use strict';

	var MVwebPcAdmin = {
		fieldMapping: null,

		init: function() {
			this.initTabs();
			this.initFormModal();
			this.initFormActions();
			this.initSettings();
			this.initCopyShortcode();
			this.initStatistics();
			this.initFieldMapping();
		},

		initTabs: function() {
			var $tabs = $('.mvweb-nav__link');
			var $contents = $('.mvweb-tab-content');
			var self = this;

			$tabs.on('click', function(e) {
				e.preventDefault();

				var $this = $(this);
				var tabId = $this.data('tab');

				$tabs.removeClass('mvweb-nav__link--active');
				$this.addClass('mvweb-nav__link--active');

				$contents.removeClass('active');
				$('#' + tabId).addClass('active');

				self.toggleSubmit(tabId);

				if (history.pushState) {
					history.pushState(null, null, '#' + tabId);
				}
			});

			var hash = window.location.hash.substring(1);
			if (hash && $('#' + hash).length) {
				$tabs.filter('[data-tab="' + hash + '"]').trigger('click');
			} else {
				this.toggleSubmit($tabs.filter('.mvweb-nav__link--active').data('tab') || 'forms');
			}
		},

		toggleSubmit: function(tabId) {
			var $submit = $('#mvweb-pc-settings-form .mvweb-submit');
			if (tabId === 'settings' || tabId === 'appearance') {
				$submit.show();
			} else {
				$submit.hide();
			}
		},

		initFormModal: function() {
			var dialog = document.getElementById('mvweb-pc-form-modal');
			var $form = $('#mvweb-pc-form-edit');
			var self = this;

			$('.mvweb-pc-add-form').on('click', function() {
				self.openFormModal();
			});

			if (dialog) {
				dialog.addEventListener('click', function(e) {
					if (e.target === dialog) {
						dialog.close();
					}
				});
			}

			$form.on('submit', function(e) {
				e.preventDefault();
				self.saveForm();
			});

			$('.mvweb-pc-test-connection').on('click', function() {
				self.testConnection();
			});
		},

		openFormModal: function(formId) {
			var dialog = document.getElementById('mvweb-pc-form-modal');
			var $title = $(dialog).find('.mvweb-pc-modal-title');
			var self = this;

			$('#mvweb-pc-form-edit')[0].reset();
			$('#mvweb-pc-form-id').val('');
			$('#mvweb-pc-field-mapping').val('');
			$('.mvweb-pc-connection-status').text('').removeClass('loading success error');

			$('#mvweb-pc-mapping-rows').html('<tr class="mvweb-pc-mapping-placeholder"><td colspan="6">' + (mvweb_pt_ajax.i18n.no_columns || 'Click "Auto-Detect Columns" or add columns manually.') + '</td></tr>');
			$('.mvweb-pc-preview-section').hide();
			$('#mvweb-pc-inheritance-enabled').prop('checked', false);
			$('.mvweb-pc-inheritance-options').hide();
			self.fieldMapping = null;

			$('.mvweb-pc-sheet-row').hide();
			$('#mvweb-pc-form-sheet').html('<option value="">' + (mvweb_pt_ajax.i18n.first_sheet || 'First sheet (default)') + '</option>');
			$('#mvweb-pc-form-sheet-name').val('');

			if (formId && window.mvwebPcForms && window.mvwebPcForms[formId]) {
				var form = window.mvwebPcForms[formId];
				$title.text(mvweb_pt_ajax.i18n.edit_form || 'Edit Form');
				$('#mvweb-pc-form-id').val(formId);
				$('#mvweb-pc-form-name').val(form.name);
				$('#mvweb-pc-form-url').val(form.spreadsheet_url);
				$('#mvweb-pc-form-preset').val(form.preset);
				$('#mvweb-pc-form-status').val(form.status);

				if (form.spreadsheet_url) {
					var selectedGid = null;
					if (form.sheet_id !== null && form.sheet_id !== undefined && form.sheet_id !== '') {
						selectedGid = form.sheet_id;
						var sheetName = form.sheet_name || 'Sheet';
						$('#mvweb-pc-form-sheet').html(
							'<option value="">' + (mvweb_pt_ajax.i18n.first_sheet || 'First sheet (default)') + '</option>' +
							'<option value="' + form.sheet_id + '" selected>' + sheetName + '</option>'
						);
						$('#mvweb-pc-form-sheet-name').val(sheetName);
					}
					self.fetchSheets(form.spreadsheet_url, selectedGid);
				}

				if (form.field_mapping) {
					self.fieldMapping = form.field_mapping;
					self.renderMappingTable(form.field_mapping, []);
					self.updateFieldMappingInput();
				}
			} else {
				$title.text(mvweb_pt_ajax.i18n.add_form || 'Add New Form');
			}

			dialog.showModal();
		},

		closeFormModal: function() {
			var dialog = document.getElementById('mvweb-pc-form-modal');
			if (dialog && dialog.open) {
				dialog.close();
			}
		},

		saveForm: function() {
			var self = this;
			var $form = $('#mvweb-pc-form-edit');
			var $submitBtn = $form.find('button[type="submit"]');

			self.updateMappingFromUI();

			var data = {
				action: 'mvweb_pt_save_form',
				nonce: mvweb_pt_ajax.nonce,
				form_id: $('#mvweb-pc-form-id').val(),
				name: $('#mvweb-pc-form-name').val(),
				spreadsheet_url: $('#mvweb-pc-form-url').val(),
				sheet_id: $('#mvweb-pc-form-sheet').val(),
				sheet_name: $('#mvweb-pc-form-sheet option:selected').text(),
				preset: $('#mvweb-pc-form-preset').val(),
				status: $('#mvweb-pc-form-status').val(),
				field_mapping: $('#mvweb-pc-field-mapping').val()
			};

			$submitBtn.prop('disabled', true);

			$.post(mvweb_pt_ajax.ajax_url, data, function(response) {
				if (response.success) {
					window.location.reload();
				} else {
					alert(response.data.message || mvweb_pt_ajax.i18n.error);
				}
			}).fail(function() {
				alert(mvweb_pt_ajax.i18n.error);
			}).always(function() {
				$submitBtn.prop('disabled', false);
			});
		},

		testConnection: function() {
			var $button = $('.mvweb-pc-test-connection');
			var $status = $('.mvweb-pc-connection-status');
			var url = $('#mvweb-pc-form-url').val();

			if (!url) {
				$status.text(mvweb_pt_ajax.i18n.url_required || mvweb_pt_ajax.i18n.error).removeClass('loading success').addClass('error');
				return;
			}

			$button.prop('disabled', true);
			$status.text(mvweb_pt_ajax.i18n.testing).removeClass('success error').addClass('loading');

			$.post(mvweb_pt_ajax.ajax_url, {
				action: 'mvweb_pt_test_connection',
				nonce: mvweb_pt_ajax.nonce,
				spreadsheet_url: url
			}, function(response) {
				if (response.success) {
					$status.text(response.data.message).removeClass('loading error').addClass('success');
				} else {
					$status.text(response.data.message || mvweb_pt_ajax.i18n.error).removeClass('loading success').addClass('error');
				}
			}).fail(function() {
				$status.text(mvweb_pt_ajax.i18n.error).removeClass('loading success').addClass('error');
			}).always(function() {
				$button.prop('disabled', false);
			});
		},

		fetchSheets: function(url, selectedGid) {
			var $select = $('#mvweb-pc-form-sheet');
			var $row = $('.mvweb-pc-sheet-row');
			var $status = $('.mvweb-pc-sheets-status');
			var $button = $('.mvweb-pc-refresh-sheets');

			if (!url) {
				$row.hide();
				return;
			}

			$button.prop('disabled', true);
			$status.text(mvweb_pt_ajax.i18n.loading || 'Loading...').removeClass('success error').addClass('loading');

			$.post(mvweb_pt_ajax.ajax_url, {
				action: 'mvweb_pt_fetch_sheets',
				nonce: mvweb_pt_ajax.nonce,
				spreadsheet_url: url
			}, function(response) {
				if (response.success && response.data.sheets) {
					var sheets = response.data.sheets;
					var options = '<option value="">' + (mvweb_pt_ajax.i18n.first_sheet || 'First sheet (default)') + '</option>';

					sheets.forEach(function(sheet) {
						var selected = (selectedGid !== null && selectedGid !== undefined && parseInt(selectedGid) === sheet.gid) ? ' selected' : '';
						options += '<option value="' + sheet.gid + '"' + selected + '>' + sheet.name + '</option>';
					});

					$select.html(options);
					$row.show();
					$status.text('').removeClass('loading error success');

					$('#mvweb-pc-form-sheet-name').val($select.find('option:selected').text());
				} else {
					$status.text(response.data.message || mvweb_pt_ajax.i18n.error).removeClass('loading success').addClass('error');
					$row.show();
				}
			}).fail(function() {
				$status.text(mvweb_pt_ajax.i18n.error).removeClass('loading success').addClass('error');
				$row.show();
			}).always(function() {
				$button.prop('disabled', false);
			});
		},

		initFormActions: function() {
			var self = this;

			$(document).on('click', '.mvweb-pc-edit-form', function() {
				var formId = $(this).data('form-id');
				self.openFormModal(formId);
			});

			$(document).on('click', '.mvweb-pc-refresh-sheets', function() {
				var url = $('#mvweb-pc-form-url').val();
				self.fetchSheets(url, null);
			});

			$(document).on('change', '#mvweb-pc-form-sheet', function() {
				$('#mvweb-pc-form-sheet-name').val($(this).find('option:selected').text());
			});

			var urlFetchTimeout;
			$(document).on('blur', '#mvweb-pc-form-url', function() {
				var url = $(this).val();
				clearTimeout(urlFetchTimeout);
				urlFetchTimeout = setTimeout(function() {
					if (url) {
						self.fetchSheets(url, null);
					}
				}, 300);
			});

			$(document).on('click', '.mvweb-pc-delete-form', function() {
				var $button = $(this);
				var formId = $button.data('form-id');

				if (!confirm(mvweb_pt_ajax.i18n.confirm_delete)) {
					return;
				}

				$button.prop('disabled', true);

				$.post(mvweb_pt_ajax.ajax_url, {
					action: 'mvweb_pt_delete_form',
					nonce: mvweb_pt_ajax.nonce,
					form_id: formId
				}, function(response) {
					if (response.success) {
						$button.closest('tr').fadeOut(300, function() {
							$(this).remove();

							if ($('.mvweb-pc-forms-table tbody tr').length === 0) {
								$('.mvweb-pc-forms-table').closest('.mvweb-table-wrap').replaceWith(
									'<div class="mvweb-empty"><div class="mvweb-empty__title">' + (mvweb_pt_ajax.i18n.no_forms_title || 'No forms yet') + '</div><p class="mvweb-empty__text">' + (mvweb_pt_ajax.i18n.no_forms || 'No forms created yet. Click "Add New Form" to create your first calculator form.') + '</p></div>'
								);
							}
						});
					} else {
						alert(response.data.message || mvweb_pt_ajax.i18n.error);
						$button.prop('disabled', false);
					}
				}).fail(function() {
					alert(mvweb_pt_ajax.i18n.error);
					$button.prop('disabled', false);
				});
			});
		},

		initSettings: function() {
			var $form = $('#mvweb-pc-settings-form');
			var $status = $('.mvweb-pc-settings-status');

			if (!$form.length) {
				return;
			}

			$('#currency').on('change', function() {
				var $customWrapper = $('#custom-currency-wrapper');
				if ($(this).val() === 'CUSTOM') {
					$customWrapper.slideDown(200);
					$('#custom_currency').trigger('focus');
				} else {
					$customWrapper.slideUp(200);
				}
			});

			$form.on('submit', function(e) {
				e.preventDefault();

				var $submitBtn = $form.find('button[type="submit"]');
				$submitBtn.prop('disabled', true);
				$status.text(mvweb_pt_ajax.i18n.saving || 'Saving...').removeClass('success error');

				var data = {
					action: 'mvweb_pt_save_settings',
					nonce: mvweb_pt_ajax.nonce,
					cache_ttl: $('#cache_ttl').val(),
					fallback_enabled: $('input[name="fallback_enabled"]').is(':checked') ? '1' : '0',
					stats_enabled: $('input[name="stats_enabled"]').is(':checked') ? '1' : '0',
					default_preset: $('#default_preset').val(),
					currency: $('#currency').val(),
					custom_currency: $('#custom_currency').val(),
					keep_data_on_uninstall: $('input[name="keep_data_on_uninstall"]').is(':checked') ? '1' : '0',
					default_title: $('#default_title').val(),
					default_description: $('#default_description').val(),
					footer_text: $('#footer_text').val(),
					default_button_text: $('#default_button_text').val(),
					service_column_label: $('#service_column_label').val(),
					time_column_label: $('#time_column_label').val(),
					price_column_label: $('#price_column_label').val(),
					on_request_text: $('#on_request_text').val(),
					custom_css: $('#custom_css').val()
				};

				$.post(mvweb_pt_ajax.ajax_url, data, function(response) {
					if (response.success) {
						$status.text(response.data.message || mvweb_pt_ajax.i18n.success).addClass('success');
					} else {
						$status.text(response.data.message || mvweb_pt_ajax.i18n.error).addClass('error');
					}
				}).fail(function() {
					$status.text(mvweb_pt_ajax.i18n.error).addClass('error');
				}).always(function() {
					$submitBtn.prop('disabled', false);
					setTimeout(function() {
						$status.text('');
					}, 3000);
				});
			});

			$('.mvweb-pc-clear-cache').on('click', function() {
				var $button = $(this);
				var $cacheStatus = $('.mvweb-pc-cache-status');

				$button.prop('disabled', true);
				$cacheStatus.text(mvweb_pt_ajax.i18n.clearing).removeClass('success error');

				$.post(mvweb_pt_ajax.ajax_url, {
					action: 'mvweb_pt_clear_cache',
					nonce: mvweb_pt_ajax.nonce
				}, function(response) {
					if (response.success) {
						$cacheStatus.text(response.data.message || mvweb_pt_ajax.i18n.success).addClass('success');
					} else {
						$cacheStatus.text(response.data.message || mvweb_pt_ajax.i18n.error).addClass('error');
					}
				}).fail(function() {
					$cacheStatus.text(mvweb_pt_ajax.i18n.error).addClass('error');
				}).always(function() {
					$button.prop('disabled', false);
					setTimeout(function() {
						$cacheStatus.text('');
					}, 3000);
				});
			});
		},

		initCopyShortcode: function() {
			$(document).on('click', '.mvweb-pc-copy-shortcode', function() {
				var $button = $(this);
				var $code = $button.siblings('.mvweb-pc-shortcode');
				var shortcode = $code.text();

				if (navigator.clipboard) {
					navigator.clipboard.writeText(shortcode).then(function() {
						$button.find('.dashicons').removeClass('dashicons-clipboard').addClass('dashicons-yes');
						setTimeout(function() {
							$button.find('.dashicons').removeClass('dashicons-yes').addClass('dashicons-clipboard');
						}, 1500);
					});
				} else {
					var $temp = $('<textarea>');
					$('body').append($temp);
					$temp.val(shortcode).select();
					document.execCommand('copy');
					$temp.remove();

					$button.find('.dashicons').removeClass('dashicons-clipboard').addClass('dashicons-yes');
					setTimeout(function() {
						$button.find('.dashicons').removeClass('dashicons-yes').addClass('dashicons-clipboard');
					}, 1500);
				}
			});
		},

		initStatistics: function() {
			var self = this;

			$(document).on('change', '.mvweb-pc-stats-filter', function() {
				var period = $('#mvweb-pc-stats-period').val();
				var formId = $('#mvweb-pc-stats-form').val();
				var url = window.location.pathname + window.location.search.split('&period=')[0].split('&form_id=')[0];

				url += '&period=' + period;
				if (formId) {
					url += '&form_id=' + formId;
				}
				url += '#statistics';

				window.location.href = url;
			});

			$(document).on('click', '.mvweb-pc-export-stats', function() {
				var $button = $(this);
				var period = $('#mvweb-pc-stats-period').val() || $button.data('period') || 'month';
				var formId = $('#mvweb-pc-stats-form').val() || $button.data('form') || '';

				$button.prop('disabled', true);

				$.post(mvweb_pt_ajax.ajax_url, {
					action: 'mvweb_pt_export_stats',
					nonce: mvweb_pt_ajax.nonce,
					period: period,
					form_id: formId
				}, function(response) {
					if (response.success) {
						self.downloadCSV(response.data.csv, response.data.filename);
					} else {
						alert(response.data.message || mvweb_pt_ajax.i18n.error);
					}
				}).fail(function() {
					alert(mvweb_pt_ajax.i18n.error);
				}).always(function() {
					$button.prop('disabled', false);
				});
			});

			$(document).on('click', '.mvweb-pc-clear-stats', function() {
				var $button = $(this);

				if (!confirm(mvweb_pt_ajax.i18n.confirm_clear_stats || 'Are you sure you want to clear all statistics?')) {
					return;
				}

				$button.prop('disabled', true);

				$.post(mvweb_pt_ajax.ajax_url, {
					action: 'mvweb_pt_clear_stats',
					nonce: mvweb_pt_ajax.nonce,
					period: 'all'
				}, function(response) {
					if (response.success) {
						alert(response.data.message);
						window.location.reload();
					} else {
						alert(response.data.message || mvweb_pt_ajax.i18n.error);
					}
				}).fail(function() {
					alert(mvweb_pt_ajax.i18n.error);
				}).always(function() {
					$button.prop('disabled', false);
				});
			});

			$(document).on('click', '.nav-tab-link', function(e) {
				e.preventDefault();
				var tabId = $(this).data('tab');
				$('.mvweb-nav__link[data-tab="' + tabId + '"]').trigger('click');
			});
		},

		downloadCSV: function(csv, filename) {
			var blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
			var link = document.createElement('a');

			if (navigator.msSaveBlob) {
				navigator.msSaveBlob(blob, filename);
			} else {
				var url = URL.createObjectURL(blob);
				link.setAttribute('href', url);
				link.setAttribute('download', filename);
				link.style.visibility = 'hidden';
				document.body.appendChild(link);
				link.click();
				document.body.removeChild(link);
			}
		},

		initFieldMapping: function() {
			var self = this;

			$(document).on('click', '.mvweb-pc-auto-detect', function() {
				self.autoDetectMapping();
			});

			$(document).on('click', '.mvweb-pc-add-column', function() {
				self.addMappingColumn();
			});

			$(document).on('click', '.mvweb-pc-remove-column', function() {
				$(this).closest('tr').remove();
				self.updateMappingFromUI();
			});

			$(document).on('click', '.mvweb-pc-preset-btn', function() {
				var presetId = $(this).data('preset');
				self.applyMappingPreset(presetId);
			});

			$(document).on('change', '#mvweb-pc-inheritance-enabled', function() {
				var $options = $('.mvweb-pc-inheritance-options');
				if ($(this).is(':checked')) {
					$options.slideDown(200);
				} else {
					$options.slideUp(200);
				}
				self.updateMappingFromUI();
			});

			$(document).on('change', '.mvweb-pc-mapping-table select, .mvweb-pc-mapping-table input', function() {
				self.updateMappingFromUI();
			});

			$(document).on('click', '.mvweb-pc-mobile-checkbox', function() {
				self.updateMappingFromUI();
			});

			$(document).on('change', '#mvweb-pc-show-source', function() {
				self.updateMappingFromUI();
			});
		},

		autoDetectMapping: function() {
			var self = this;
			var $button = $('.mvweb-pc-auto-detect');
			var url = $('#mvweb-pc-form-url').val();

			if (!url) {
				alert(mvweb_pt_ajax.i18n.url_required || 'Please enter Google Sheets URL first.');
				return;
			}

			$button.prop('disabled', true).text(mvweb_pt_ajax.i18n.detecting || 'Detecting...');

			var sheetId = $('#mvweb-pc-form-sheet').val();

			$.post(mvweb_pt_ajax.ajax_url, {
				action: 'mvweb_pt_auto_detect_mapping',
				nonce: mvweb_pt_ajax.nonce,
				spreadsheet_url: url,
				sheet_id: sheetId
			}, function(response) {
				if (response.success) {
					self.fieldMapping = response.data.mapping;
					self.renderMappingTable(response.data.mapping, response.data.headers);
					self.fetchPreview(url, sheetId);
				} else {
					alert(response.data.message || mvweb_pt_ajax.i18n.error);
				}
			}).fail(function() {
				alert(mvweb_pt_ajax.i18n.error);
			}).always(function() {
				$button.prop('disabled', false).html('<span class="dashicons dashicons-search"></span> ' + (mvweb_pt_ajax.i18n.auto_detect || 'Auto-Detect Columns'));
			});
		},

		fetchPreview: function(url, sheetId) {
			var self = this;

			$.post(mvweb_pt_ajax.ajax_url, {
				action: 'mvweb_pt_fetch_preview',
				nonce: mvweb_pt_ajax.nonce,
				spreadsheet_url: url,
				sheet_id: sheetId || '',
				limit: 20
			}, function(response) {
				if (response.success) {
					self.renderPreviewTable(response.data.headers, response.data.rows);
					$('.mvweb-pc-preview-section').slideDown(200);
				}
			});
		},

		renderMappingTable: function(mapping, headers) {
			var self = this;
			var $tbody = $('#mvweb-pc-mapping-rows');
			$tbody.empty();

			if (!mapping || !mapping.columns || mapping.columns.length === 0) {
				$tbody.html('<tr class="mvweb-pc-mapping-placeholder"><td colspan="6">' + (mvweb_pt_ajax.i18n.no_columns || 'Click "Auto-Detect Columns" or add columns manually.') + '</td></tr>');
				return;
			}

			mapping.columns.forEach(function(column, index) {
				var header = headers && headers[column.index] ? headers[column.index] : '';
				var confidence = column.confidence || 0;
				var confidenceClass = confidence >= 70 ? 'high' : (confidence >= 40 ? 'medium' : 'low');
				var fullWidthMobile = column.full_width_mobile || false;

				var $row = self.createMappingRow(column.index, header, column.role, column.label, column.format, confidenceClass, fullWidthMobile);
				$tbody.append($row);
			});

			if (mapping.inheritance) {
				$('#mvweb-pc-inheritance-enabled').prop('checked', mapping.inheritance.enabled);
				$('#mvweb-pc-show-source').prop('checked', mapping.inheritance.show_source);

				if (mapping.inheritance.enabled) {
					$('.mvweb-pc-inheritance-options').show();
				}
			}

			self.updateFieldMappingInput();
		},

		createMappingRow: function(index, header, role, label, format, confidenceClass, fullWidthMobile) {
			var roles = window.mvwebPcRoles || {};
			var formats = window.mvwebPcFormats || {};

			var roleOptions = '';
			for (var roleKey in roles) {
				var selected = roleKey === role ? ' selected' : '';
				roleOptions += '<option value="' + roleKey + '"' + selected + '>' + roles[roleKey] + '</option>';
			}

			var formatOptions = '';
			for (var formatKey in formats) {
				var fmtSelected = formatKey === format ? ' selected' : '';
				formatOptions += '<option value="' + formatKey + '"' + fmtSelected + '>' + formats[formatKey] + '</option>';
			}

			var confidenceIndicator = confidenceClass ? '<span class="mvweb-pc-confidence mvweb-pc-confidence--' + confidenceClass + '" title="Auto-detection confidence"></span>' : '';
			var mobileChecked = fullWidthMobile ? ' checked' : '';

			var html = '<tr data-index="' + index + '">' +
				'<td class="column-index"><span class="mvweb-pc-col-index">' + (index + 1) + '</span></td>' +
				'<td class="column-header">' + confidenceIndicator + '<span class="header-detected">' + this.escapeHtml(header || '-') + '</span></td>' +
				'<td class="column-role"><select class="mvweb-select mvweb-pc-role-select">' + roleOptions + '</select></td>' +
				'<td class="column-label"><input type="text" class="mvweb-input mvweb-pc-label-input" value="' + this.escapeHtml(label || '') + '" placeholder="' + this.escapeHtml(header || 'Label') + '"></td>' +
				'<td class="column-format"><div class="column-format-inner"><select class="mvweb-select mvweb-pc-format-select">' + formatOptions + '</select><span class="mvweb-pc-remove-column dashicons dashicons-trash"></span></div></td>' +
				'<td class="column-mobile"><input type="checkbox" class="mvweb-pc-mobile-checkbox"' + mobileChecked + ' title="Full width on mobile"></td>' +
				'</tr>';

			return $(html);
		},

		addMappingColumn: function() {
			var $tbody = $('#mvweb-pc-mapping-rows');
			var $placeholder = $tbody.find('.mvweb-pc-mapping-placeholder');

			if ($placeholder.length) {
				$placeholder.remove();
			}

			var maxIndex = -1;
			$tbody.find('tr[data-index]').each(function() {
				var idx = parseInt($(this).data('index'), 10);
				if (idx > maxIndex) {
					maxIndex = idx;
				}
			});

			var newIndex = maxIndex + 1;
			var $row = this.createMappingRow(newIndex, '', 'ignore', '', 'text', '', false);
			$tbody.append($row);

			this.updateMappingFromUI();
		},

		applyMappingPreset: function(presetId) {
			var presets = window.mvwebPcPresets || {};
			if (!presets[presetId]) {
				return;
			}

			this.fieldMapping = presets[presetId].mapping;
			this.renderMappingTable(this.fieldMapping, []);
		},

		updateMappingFromUI: function() {
			var self = this;
			var columns = [];

			$('#mvweb-pc-mapping-rows tr[data-index]').each(function() {
				var $row = $(this);
				columns.push({
					index: parseInt($row.data('index'), 10),
					role: $row.find('.mvweb-pc-role-select').val(),
					label: $row.find('.mvweb-pc-label-input').val(),
					format: $row.find('.mvweb-pc-format-select').val(),
					full_width_mobile: $row.find('.mvweb-pc-mobile-checkbox').is(':checked')
				});
			});

			self.fieldMapping = {
				schema_version: '2.0',
				mode: columns.length > 0 ? 'mapped' : 'legacy',
				columns: columns,
				inheritance: {
					enabled: $('#mvweb-pc-inheritance-enabled').is(':checked'),
					wildcard: '*',
					show_source: $('#mvweb-pc-show-source').is(':checked')
				}
			};

			self.updateFieldMappingInput();
		},

		updateFieldMappingInput: function() {
			$('#mvweb-pc-field-mapping').val(JSON.stringify(this.fieldMapping));
		},

		renderPreviewTable: function(headers, rows) {
			var $thead = $('#mvweb-pc-preview-headers');
			var $tbody = $('#mvweb-pc-preview-rows');

			$thead.empty();
			$tbody.empty();

			var headerHtml = '<tr>';
			headers.forEach(function(header, index) {
				headerHtml += '<th>' + (index + 1) + '. ' + MVwebPcAdmin.escapeHtml(header || '-') + '</th>';
			});
			headerHtml += '</tr>';
			$thead.html(headerHtml);

			rows.forEach(function(row) {
				var rowHtml = '<tr>';
				row.forEach(function(cell) {
					rowHtml += '<td title="' + MVwebPcAdmin.escapeHtml(cell || '') + '">' + MVwebPcAdmin.escapeHtml(cell || '-') + '</td>';
				});
				rowHtml += '</tr>';
				$tbody.append(rowHtml);
			});
		},

		escapeHtml: function(text) {
			if (!text) return '';
			var div = document.createElement('div');
			div.textContent = text;
			return div.innerHTML;
		}
	};

	$(document).ready(function() {
		MVwebPcAdmin.init();
	});

})(jQuery);
