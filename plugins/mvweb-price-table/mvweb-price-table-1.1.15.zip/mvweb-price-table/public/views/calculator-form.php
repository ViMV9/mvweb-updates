<?php
/**
 * Calculator form template.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 * @since   2.0.0 Added dynamic hierarchy support via field_mapping.
 *
 * Variables available:
 * - $form     (array)  Form data.
 * - $settings (array)  Merged settings.
 * - $args     (array)  Shortcode/function arguments.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Get field mapping configuration.
$field_mapping = isset( $form['field_mapping'] ) ? $form['field_mapping'] : mvweb_pt_get_default_field_mapping();
$mapping_mode  = isset( $field_mapping['mode'] ) ? $field_mapping['mode'] : 'legacy';

// Build effective hierarchy from field_mapping.
$effective_hierarchy = mvweb_pt_get_effective_hierarchy( $field_mapping );

// Fallback to legacy if no hierarchy found.
if ( empty( $effective_hierarchy ) ) {
	$effective_hierarchy = array(
		1 => array( 'original_level' => 1, 'index' => 0, 'label' => $settings['brand_label'], 'role' => 'hierarchy_1' ),
		2 => array( 'original_level' => 2, 'index' => 1, 'label' => $settings['type_label'], 'role' => 'hierarchy_2' ),
		3 => array( 'original_level' => 3, 'index' => 2, 'label' => $settings['model_label'], 'role' => 'hierarchy_3' ),
	);
}

// Use effective hierarchy as the levels for rendering.
// Keys are effective positions (1, 2, 3...), values have original_level.
$hierarchy_levels = $effective_hierarchy;
$hierarchy_depth  = count( $hierarchy_levels );

// Build effective levels string for JS (comma-separated original level numbers).
$effective_levels_str = implode(
	',',
	array_map(
		function ( $info ) {
			return absint( $info['original_level'] );
		},
		$effective_hierarchy
	)
);

// Build service columns from field_mapping for table headers.
// Include service_* and meta_* roles (except service_group which is for grouping).
$service_columns = array();
if ( isset( $field_mapping['columns'] ) && is_array( $field_mapping['columns'] ) ) {
	foreach ( $field_mapping['columns'] as $column ) {
		$role = $column['role'];
		// Include service columns (except group) and meta columns.
		$is_service = strpos( $role, 'service_' ) === 0 && 'service_group' !== $role;
		$is_meta    = strpos( $role, 'meta_' ) === 0;

		if ( $is_service || $is_meta ) {
			$service_columns[] = array(
				'index'             => $column['index'],
				'role'              => $role,
				'label'             => $column['label'],
				'format'            => $column['format'] ?? 'text',
				'full_width_mobile' => ! empty( $column['full_width_mobile'] ),
			);
		}
	}

	// Sort by column index to match the order in Google Sheets.
	usort(
		$service_columns,
		function ( $a, $b ) {
			return $a['index'] - $b['index'];
		}
	);
}

// Fallback to legacy columns.
if ( empty( $service_columns ) ) {
	$service_columns = array(
		array( 'role' => 'service_name', 'label' => $settings['service_column'], 'format' => 'text' ),
		array( 'role' => 'service_time', 'label' => $settings['time_column'], 'format' => 'duration' ),
		array( 'role' => 'service_price', 'label' => $settings['price_column'], 'format' => 'currency' ),
	);
}

// Build classes.
$wrapper_classes = array(
	'mvweb-pc',
	'mvweb-pc--preset-' . esc_attr( $args['preset'] ),
	'mvweb-pc--depth-' . $hierarchy_depth,
);

if ( ! empty( $args['class'] ) ) {
	$wrapper_classes[] = esc_attr( $args['class'] );
}

// Unique ID for this instance.
$instance_id = 'mvweb-pc-' . $form['id'] . '-' . wp_rand( 1000, 9999 );

// Build default values array for each hierarchy level.
// Use original_level numbers for shortcode/settings lookup (e.g., default_level_1, default_level_3).
$default_values = array();
foreach ( $hierarchy_levels as $eff_pos => $config ) {
	$orig_level = $config['original_level'];
	// Check shortcode argument first (e.g., $args['default_level_1']).
	if ( ! empty( $args[ 'default_level_' . $orig_level ] ) ) {
		$default_values[ $orig_level ] = $args[ 'default_level_' . $orig_level ];
	} elseif ( ! empty( $settings[ 'default_level_' . $orig_level ] ) ) {
		$default_values[ $orig_level ] = $settings[ 'default_level_' . $orig_level ];
	} else {
		$default_values[ $orig_level ] = '';
	}
}

// Placeholders for each level - keyed by original_level number.
$placeholders = array();
foreach ( $hierarchy_levels as $eff_pos => $config ) {
	$orig_level = $config['original_level'];
	// translators: %s is the field label (e.g. "Brand", "Type", "Model").
	$placeholders[ $orig_level ] = sprintf( __( 'Select %s', 'mvweb-price-table' ), $config['label'] );
}

// "show all" mode from shortcode [... all].
$show_all = ! empty( $args['show_all'] );

// Data attributes for JS.
$data_attrs = array(
	'form-id'          => $form['id'],
	'spreadsheet'      => $form['spreadsheet_id'],
	'auto-submit'      => $settings['auto_submit'] ? 'true' : 'false',
	'hierarchy-depth'  => $hierarchy_depth,
	'mapping-mode'     => $mapping_mode,
	'effective-levels' => $effective_levels_str,
);

if ( $show_all ) {
	$data_attrs['show-all'] = 'true';
}

// Add default values for all hierarchy levels.
foreach ( $default_values as $level => $value ) {
	$data_attrs[ 'default-level-' . $level ] = $value;
}

$data_string = '';
foreach ( $data_attrs as $key => $value ) {
	$data_string .= ' data-' . esc_attr( $key ) . '="' . esc_attr( $value ) . '"';
}
?>

<div id="<?php echo esc_attr( $instance_id ); ?>"
	 class="<?php echo esc_attr( implode( ' ', $wrapper_classes ) ); ?>"
	 <?php echo $data_string; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>

	<?php if ( $args['show_title'] && ! empty( $settings['title'] ) ) : ?>
		<div class="mvweb-pc__title"><?php echo esc_html( $settings['title'] ); ?></div>
	<?php endif; ?>

	<?php if ( ! empty( $settings['description'] ) ) : ?>
		<div class="mvweb-pc__description"><?php echo esc_html( $settings['description'] ); ?></div>
	<?php endif; ?>

	<form class="mvweb-pc__form" method="post" action="">
		<div class="mvweb-pc__form-row">
			<div class="mvweb-pc__selects" style="--mvweb-pc-hierarchy-depth: <?php echo (int) $hierarchy_depth; ?>;">
				<?php
				$level_index = 0;
				foreach ( $hierarchy_levels as $eff_pos => $config ) :
					$orig_level = $config['original_level'];
					// Map original level numbers to legacy names for CSS compatibility.
					$legacy_names = array( 1 => 'brand', 2 => 'type', 3 => 'model' );
					$level_name   = isset( $legacy_names[ $orig_level ] ) ? $legacy_names[ $orig_level ] : 'level-' . $orig_level;
					$is_first     = ( $level_index === 0 );
					?>
					<!-- Level <?php echo (int) $orig_level; ?> Select (effective position <?php echo (int) $eff_pos; ?>) -->
					<div class="mvweb-pc__field mvweb-pc__field--<?php echo esc_attr( $level_name ); ?> mvweb-pc__field--level-<?php echo (int) $orig_level; ?>">
						<label class="mvweb-pc__label" for="<?php echo esc_attr( $instance_id ); ?>-level-<?php echo (int) $orig_level; ?>">
							<?php echo esc_html( $config['label'] ); ?>
						</label>
						<select class="mvweb-pc__select mvweb-pc__select--<?php echo esc_attr( $level_name ); ?> mvweb-pc__select--level-<?php echo (int) $orig_level; ?>"
								id="<?php echo esc_attr( $instance_id ); ?>-level-<?php echo (int) $orig_level; ?>"
								name="level_<?php echo (int) $orig_level; ?>"
								data-level="<?php echo (int) $orig_level; ?>"
								data-eff-pos="<?php echo (int) $eff_pos; ?>"
								data-role="<?php echo esc_attr( $config['role'] ); ?>"
								data-placeholder="<?php echo esc_attr( $placeholders[ $orig_level ] ); ?>"
								<?php echo $is_first ? '' : 'disabled'; ?>
								required>
							<option value="" disabled selected hidden><?php echo esc_html( $placeholders[ $orig_level ] ); ?></option>
						</select>
					</div>
					<?php
					++$level_index;
				endforeach;
				?>
			</div>

			<?php if ( ! $settings['auto_submit'] ) : ?>
				<div class="mvweb-pc__actions">
					<button type="submit" class="mvweb-pc__button mvweb-pc__button--submit mvweb-pc__button--<?php echo esc_attr( $settings['button_style'] ?? 'filled' ); ?>" disabled>
						<span class="mvweb-pc__button-text"><?php echo esc_html( $settings['button_text'] ); ?></span>
						<span class="mvweb-pc__button-loader" style="display: none;">
							<svg class="mvweb-pc__spinner" viewBox="0 0 24 24" width="18" height="18">
								<circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="3" stroke-dasharray="32" stroke-linecap="round"/>
							</svg>
						</span>
					</button>
				</div>
			<?php endif; ?>
		</div>
	</form>

	<!-- Results -->
	<div class="mvweb-pc__results" style="display: none;" data-columns-count="<?php echo count( $service_columns ); ?>">
		<div class="mvweb-pc__results-header">
			<div class="mvweb-pc__results-title"></div>
		</div>

		<div class="mvweb-pc__table-wrapper">
			<table class="mvweb-pc__table" style="--mvweb-pc-service-columns: <?php echo count( $service_columns ); ?>;">
				<thead class="mvweb-pc__table-head">
					<tr>
						<?php foreach ( $service_columns as $column ) : ?>
							<?php
							// Map role to CSS class for styling.
							$role_class         = str_replace( 'service_', '', $column['role'] );
							$full_width_mobile  = ! empty( $column['full_width_mobile'] ) ? 'true' : 'false';
							?>
							<th class="mvweb-pc__table-th mvweb-pc__table-th--<?php echo esc_attr( $role_class ); ?>"
								data-role="<?php echo esc_attr( $column['role'] ); ?>"
								data-format="<?php echo esc_attr( $column['format'] ); ?>"
								data-full-width-mobile="<?php echo esc_attr( $full_width_mobile ); ?>">
								<?php echo esc_html( $column['label'] ); ?>
							</th>
						<?php endforeach; ?>
					</tr>
				</thead>
				<tbody class="mvweb-pc__table-body">
					<!-- Rows will be inserted by JS -->
				</tbody>
			</table>
		</div>

		<div class="mvweb-pc__no-results" style="display: none;">
			<?php echo esc_html( $settings['no_results_text'] ); ?>
		</div>

		<?php if ( ! empty( $settings['footer_text'] ) ) : ?>
			<div class="mvweb-pc__footer">
				<?php echo wp_kses_post( $settings['footer_text'] ); ?>
			</div>
		<?php endif; ?>
	</div>

	<!-- Loading Indicator -->
	<div class="mvweb-pc__loading" style="display: none;">
		<div class="mvweb-pc__loading-spinner">
			<svg viewBox="0 0 50 50" width="40" height="40">
				<circle cx="25" cy="25" r="20" fill="none" stroke="currentColor" stroke-width="4" stroke-dasharray="63" stroke-linecap="round">
					<animateTransform attributeName="transform" type="rotate" dur="1s" from="0 25 25" to="360 25 25" repeatCount="indefinite"/>
				</circle>
			</svg>
		</div>
		<span class="mvweb-pc__loading-text"><?php echo esc_html( $settings['loading_text'] ); ?></span>
	</div>

	<!-- Error Message -->
	<div class="mvweb-pc__error" style="display: none;">
		<span class="mvweb-pc__error-icon">!</span>
		<span class="mvweb-pc__error-text"><?php echo esc_html( $settings['error_text'] ); ?></span>
	</div>
</div>
