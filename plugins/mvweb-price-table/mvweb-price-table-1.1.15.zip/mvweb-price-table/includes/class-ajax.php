<?php
/**
 * AJAX handlers for MVweb Price Table.
 *
 * @package MVweb_Price_Table
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class MVweb_PT_Ajax
 *
 * Handles all AJAX requests for the plugin.
 *
 * @since 1.0.0
 */
class MVweb_PT_Ajax {

	/**
	 * Constructor.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		$this->register_public_handlers();
		$this->register_admin_handlers();
	}

	/**
	 * Register public AJAX handlers.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function register_public_handlers() {
		$public_actions = array(
			'mvweb_pt_get_brands',
			'mvweb_pt_get_types',
			'mvweb_pt_get_models',
			'mvweb_pt_get_prices',
			'mvweb_pt_get_all_prices',
			'mvweb_pt_get_hierarchy_level',
		);

		foreach ( $public_actions as $action ) {
			add_action( 'wp_ajax_' . $action, array( $this, str_replace( 'mvweb_pt_', '', $action ) ) );
			add_action( 'wp_ajax_nopriv_' . $action, array( $this, str_replace( 'mvweb_pt_', '', $action ) ) );
		}
	}

	/**
	 * Register admin AJAX handlers.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function register_admin_handlers() {
		$admin_actions = array(
			'mvweb_pt_save_form',
			'mvweb_pt_delete_form',
			'mvweb_pt_test_connection',
			'mvweb_pt_clear_cache',
			'mvweb_pt_save_settings',
			'mvweb_pt_save_appearance',
			'mvweb_pt_get_stats',
			'mvweb_pt_export_stats',
			'mvweb_pt_clear_stats',
			'mvweb_pt_export_logs',
			'mvweb_pt_auto_detect_mapping',
			'mvweb_pt_fetch_preview',
			'mvweb_pt_fetch_sheets',
		);

		foreach ( $admin_actions as $action ) {
			add_action( 'wp_ajax_' . $action, array( $this, str_replace( 'mvweb_pt_', 'admin_', $action ) ) );
		}
	}

	/**
	 * Verify public nonce.
	 *
	 * @since 1.0.0
	 * @return bool True if valid.
	 */
	private function verify_public_nonce() {
		$nonce = isset( $_REQUEST['nonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'mvweb_pt_public' ) ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_nonce',
					'message' => __( 'Security check failed. Please refresh the page and try again.', 'mvweb-price-table' ),
				),
				403
			);
		}

		return true;
	}

	/**
	 * Verify admin nonce and capability.
	 *
	 * @since 1.0.0
	 * @return bool True if valid.
	 */
	private function verify_admin_request() {
		$nonce = isset( $_REQUEST['nonce'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['nonce'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'mvweb_pt_ajax' ) ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_nonce',
					'message' => __( 'Security check failed.', 'mvweb-price-table' ),
				),
				403
			);
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error(
				array(
					'code'    => 'insufficient_permissions',
					'message' => __( 'You do not have permission to perform this action.', 'mvweb-price-table' ),
				),
				403
			);
		}

		return true;
	}

	/**
	 * Get form and Google Sheets instance.
	 *
	 * @since 1.0.0
	 * @return array|void Array with form and sheets, or sends error.
	 */
	private function get_form_and_sheets() {
		$form_id = isset( $_REQUEST['form_id'] ) ? absint( $_REQUEST['form_id'] ) : 0;

		if ( ! $form_id ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_form_id',
					'message' => __( 'Form ID is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$form = mvweb_pt_get_form( $form_id );

		if ( ! $form ) {
			wp_send_json_error(
				array(
					'code'    => 'form_not_found',
					'message' => __( 'Form not found.', 'mvweb-price-table' ),
				),
				404
			);
		}

		if ( 'active' !== $form['status'] ) {
			wp_send_json_error(
				array(
					'code'    => 'form_inactive',
					'message' => __( 'This form is inactive.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$sheets = new MVweb_PT_Google_Sheets();

		return array(
			'form'   => $form,
			'sheets' => $sheets,
		);
	}

	/**
	 * Get brands handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function get_brands() {
		$this->verify_public_nonce();

		$form_id = isset( $_REQUEST['form_id'] ) ? absint( $_REQUEST['form_id'] ) : 0;
		$data    = $this->get_form_and_sheets();

		$sheets_data = $data['sheets']->fetch_data( $data['form']['spreadsheet_id'] );

		if ( is_wp_error( $sheets_data ) ) {
			MVweb_PT_Logger::error(
				$sheets_data->get_error_message(),
				'ajax',
				array(
					'action'  => 'get_brands',
					'form_id' => $form_id,
					'code'    => $sheets_data->get_error_code(),
				)
			);

			wp_send_json_error(
				array(
					'code'    => $sheets_data->get_error_code(),
					'message' => $sheets_data->get_error_message(),
				),
				500
			);
		}

		$brands = isset( $sheets_data['brands'] ) ? $sheets_data['brands'] : array();

		natcasesort( $brands );

		$this->log_stats( $form_id, 'get_brands' );

		wp_send_json_success(
			array(
				'brands' => $brands,
			)
		);
	}

	/**
	 * Get types handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function get_types() {
		$this->verify_public_nonce();

		$form_id = isset( $_REQUEST['form_id'] ) ? absint( $_REQUEST['form_id'] ) : 0;
		$brand   = isset( $_REQUEST['brand'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['brand'] ) ) : '';

		if ( empty( $brand ) ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_brand',
					'message' => __( 'Brand is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$data        = $this->get_form_and_sheets();
		$sheets_data = $data['sheets']->fetch_data( $data['form']['spreadsheet_id'] );

		if ( is_wp_error( $sheets_data ) ) {
			MVweb_PT_Logger::error(
				$sheets_data->get_error_message(),
				'ajax',
				array(
					'action'  => 'get_types',
					'form_id' => $form_id,
					'brand'   => $brand,
					'code'    => $sheets_data->get_error_code(),
				)
			);

			wp_send_json_error(
				array(
					'code'    => $sheets_data->get_error_code(),
					'message' => $sheets_data->get_error_message(),
				),
				500
			);
		}

		$types = array();
		if ( isset( $sheets_data['data'][ $brand ]['types'] ) ) {
			foreach ( $sheets_data['data'][ $brand ]['types'] as $type_key => $type_data ) {
				$types[ $type_key ] = $type_data['name'];
			}
		}

		natcasesort( $types );

		$this->log_stats( $form_id, 'get_types', array( 'brand' => $brand ) );

		wp_send_json_success(
			array(
				'types' => $types,
			)
		);
	}

	/**
	 * Get models handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function get_models() {
		$this->verify_public_nonce();

		$form_id = isset( $_REQUEST['form_id'] ) ? absint( $_REQUEST['form_id'] ) : 0;
		$brand   = isset( $_REQUEST['brand'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['brand'] ) ) : '';
		$type    = isset( $_REQUEST['type'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['type'] ) ) : '';

		if ( empty( $brand ) || empty( $type ) ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_params',
					'message' => __( 'Brand and type are required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$data        = $this->get_form_and_sheets();
		$sheets_data = $data['sheets']->fetch_data( $data['form']['spreadsheet_id'] );

		if ( is_wp_error( $sheets_data ) ) {
			MVweb_PT_Logger::error(
				$sheets_data->get_error_message(),
				'ajax',
				array(
					'action'  => 'get_models',
					'form_id' => $form_id,
					'brand'   => $brand,
					'type'    => $type,
					'code'    => $sheets_data->get_error_code(),
				)
			);

			wp_send_json_error(
				array(
					'code'    => $sheets_data->get_error_code(),
					'message' => $sheets_data->get_error_message(),
				),
				500
			);
		}

		$models  = array();
		$grouped = array();

		if ( isset( $sheets_data['data'][ $brand ]['types'][ $type ]['models'] ) ) {
			foreach ( $sheets_data['data'][ $brand ]['types'][ $type ]['models'] as $model_key => $model_data ) {
				$group = $model_data['group'];

				if ( ! empty( $group ) ) {
					if ( ! isset( $grouped[ $group ] ) ) {
						$grouped[ $group ] = array();
					}
					$grouped[ $group ][ $model_key ] = $model_data['name'];
				} else {
					$models[ $model_key ] = $model_data['name'];
				}
			}
		}

		natcasesort( $models );

		ksort( $grouped, SORT_NATURAL | SORT_FLAG_CASE );
		foreach ( $grouped as &$group_items ) {
			natcasesort( $group_items );
		}
		unset( $group_items );

		$this->log_stats( $form_id, 'get_models', array( 'brand' => $brand, 'type' => $type ) );

		wp_send_json_success(
			array(
				'models'  => $models,
				'grouped' => $grouped,
			)
		);
	}

	/**
	 * Get prices handler.
	 *
	 * @since 1.0.0
	 * @since 2.4.0 Added mapped tree mode support.
	 * @return void
	 */
	public function get_prices() {
		$this->verify_public_nonce();

		$form_id = isset( $_REQUEST['form_id'] ) ? absint( $_REQUEST['form_id'] ) : 0;

		$data        = $this->get_form_and_sheets();
		$sheets_data = $this->fetch_form_data( $data['form'], $data['sheets'] );

		if ( is_wp_error( $sheets_data ) ) {
			MVweb_PT_Logger::error(
				$sheets_data->get_error_message(),
				'ajax',
				array(
					'action'  => 'get_prices',
					'form_id' => $form_id,
					'code'    => $sheets_data->get_error_code(),
				)
			);

			wp_send_json_error(
				array(
					'code'    => $sheets_data->get_error_code(),
					'message' => $sheets_data->get_error_message(),
				),
				500
			);
		}

		$prices    = array();
		$stats_ctx = array();

		if ( $this->is_tree_data( $sheets_data ) ) {
			$effective_levels = $sheets_data['effective_levels'];

			$parent_values = array();
			foreach ( $effective_levels as $eff_pos => $level_info ) {
				$orig      = $level_info['original_level'];
				$param_key = 'level_' . $orig;
				if ( isset( $_REQUEST[ $param_key ] ) && is_string( $_REQUEST[ $param_key ] ) && '' !== $_REQUEST[ $param_key ] ) {
					$parent_values[ $orig ] = mvweb_pt_slug( wp_unslash( $_REQUEST[ $param_key ] ) );
				}
			}

			if ( count( $parent_values ) < count( $effective_levels ) ) {
				wp_send_json_error(
					array(
						'code'    => 'missing_params',
						'message' => __( 'All hierarchy levels are required.', 'mvweb-price-table' ),
					),
					400
				);
			}

			$prices = $this->traverse_tree_for_services(
				$sheets_data['tree'],
				$effective_levels,
				$parent_values
			);

			$stats_ctx = $this->map_levels_to_stats( $parent_values, $effective_levels );
		} else {
			$brand = isset( $_REQUEST['brand'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['brand'] ) ) : '';
			$type  = isset( $_REQUEST['type'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['type'] ) ) : '';
			$model = isset( $_REQUEST['model'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['model'] ) ) : '';

			if ( empty( $brand ) || empty( $type ) || empty( $model ) ) {
				wp_send_json_error(
					array(
						'code'    => 'missing_params',
						'message' => __( 'Brand, type, and model are required.', 'mvweb-price-table' ),
					),
					400
				);
			}

			$prices    = $data['sheets']->get_prices( $data['form']['spreadsheet_id'], $brand, $type, $model );
			$stats_ctx = array(
				'brand' => $brand,
				'type'  => $type,
				'model' => $model,
			);
		}

		$this->log_stats( $form_id, 'get_prices', $stats_ctx );

		$field_mapping = isset( $data['form']['field_mapping'] ) ? $data['form']['field_mapping'] : null;

		$formatted = array();
		foreach ( $prices as $service ) {
			$item = array(
				'name'          => $service['name'],
				'time'          => isset( $service['time'] ) ? $service['time'] : '',
				'price'         => $service['price'],
				'price_display' => mvweb_pt_format_price( $service['price'] ),
			);

			if ( $field_mapping && isset( $field_mapping['columns'] ) && isset( $service['raw_cells'] ) ) {
				foreach ( $field_mapping['columns'] as $column ) {
					$role  = $column['role'];
					$index = $column['index'];

					if ( strpos( $role, 'hierarchy_' ) === 0 ) {
						continue;
					}

					$raw_value = isset( $service['raw_cells'][ $index ] ) ? $service['raw_cells'][ $index ] : '';

					$key = str_replace( array( 'service_', 'meta_' ), '', $role );

					if ( 'service_price' === $role ) {
						$item['price']         = $this->parse_price_value( $raw_value );
						$item['price_display'] = mvweb_pt_format_price( $item['price'] );
					} elseif ( 'service_name' === $role ) {
						$item['name'] = $raw_value;
					} elseif ( 'service_time' === $role ) {
						$item['time'] = $raw_value;
					} else {
						$item[ $key ] = $raw_value;
					}
				}
			}

			$formatted[] = $item;
		}

		wp_send_json_success(
			array(
				'services' => $formatted,
			)
		);
	}

	/**
	 * Get all prices for a hierarchy branch.
	 *
	 * Returns all services under the specified hierarchy levels,
	 * with additional hierarchy columns for identification.
	 *
	 * @since 2.3.0
	 * @since 2.4.0 Added mapped tree mode support with effective levels.
	 * @return void
	 */
	public function get_all_prices() {
		$this->verify_public_nonce();

		$form_id = isset( $_REQUEST['form_id'] ) ? absint( $_REQUEST['form_id'] ) : 0;

		$data        = $this->get_form_and_sheets();
		$sheets_data = $this->fetch_form_data( $data['form'], $data['sheets'] );

		if ( is_wp_error( $sheets_data ) ) {
			MVweb_PT_Logger::error(
				$sheets_data->get_error_message(),
				'ajax',
				array(
					'action'  => 'get_all_prices',
					'form_id' => $form_id,
					'code'    => $sheets_data->get_error_code(),
				)
			);

			wp_send_json_error(
				array(
					'code'    => $sheets_data->get_error_code(),
					'message' => $sheets_data->get_error_message(),
				),
				500
			);
		}

		$field_mapping = isset( $data['form']['field_mapping'] ) ? $data['form']['field_mapping'] : null;
		$all_services  = array();

		if ( $this->is_tree_data( $sheets_data ) ) {
			$effective_levels = $sheets_data['effective_levels'];
			$eff_depth        = count( $effective_levels );

			$specified_levels = array();
			foreach ( $effective_levels as $eff_pos => $level_info ) {
				$orig      = $level_info['original_level'];
				$param_key = 'level_' . $orig;
				if ( isset( $_REQUEST[ $param_key ] ) && is_string( $_REQUEST[ $param_key ] ) && '' !== $_REQUEST[ $param_key ] ) {
					$specified_levels[ $eff_pos ] = mvweb_pt_slug( wp_unslash( $_REQUEST[ $param_key ] ) );
				} else {
					break;
				}
			}

			if ( empty( $specified_levels ) ) {
				wp_send_json_error(
					array(
						'code'    => 'missing_params',
						'message' => __( 'At least one hierarchy level is required.', 'mvweb-price-table' ),
					),
					400
				);
			}

			$specified_eff_depth = max( array_keys( $specified_levels ) );

			$extra_columns = array();
			for ( $i = $specified_eff_depth + 1; $i <= $eff_depth; $i++ ) {
				$extra_columns[] = array(
					'level' => $effective_levels[ $i ]['original_level'],
					'label' => $effective_levels[ $i ]['label'],
				);
			}

			$node = $sheets_data['tree'];
			for ( $i = 1; $i <= $specified_eff_depth; $i++ ) {
				$key = $specified_levels[ $i ];
				if ( ! isset( $node[ $key ] ) ) {
					wp_send_json_success(
						array(
							'services'          => array(),
							'hierarchy_columns' => $extra_columns,
						)
					);
					return;
				}
				if ( $i < $specified_eff_depth ) {
					$node = $node[ $key ]['children'];
				} else {
					$this->collect_tree_services(
						$all_services,
						$node[ $key ],
						$specified_eff_depth,
						$eff_depth,
						$effective_levels,
						array(),
						$field_mapping
					);
				}
			}

			$stats_ctx = $this->map_levels_to_stats( $specified_levels, $effective_levels );
			$this->log_stats( $form_id, 'get_all_prices', $stats_ctx );

			wp_send_json_success(
				array(
					'services'          => $all_services,
					'hierarchy_columns' => $extra_columns,
				)
			);
			return;
		}

		$levels = array();
		for ( $i = 1; $i <= 5; $i++ ) {
			$key = 'level_' . $i;
			if ( isset( $_REQUEST[ $key ] ) && '' !== $_REQUEST[ $key ] ) {
				$levels[ $i ] = sanitize_title( wp_unslash( $_REQUEST[ $key ] ) );
			} else {
				break;
			}
		}

		if ( empty( $levels ) ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_params',
					'message' => __( 'At least one hierarchy level is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$hierarchy_depth  = 3;
		$hierarchy_labels = array();
		if ( $field_mapping && isset( $field_mapping['columns'] ) ) {
			foreach ( $field_mapping['columns'] as $column ) {
				if ( strpos( $column['role'], 'hierarchy_' ) === 0 ) {
					$level_num                      = (int) str_replace( 'hierarchy_', '', $column['role'] );
					$hierarchy_labels[ $level_num ] = $column['label'];
					$hierarchy_depth                = max( $hierarchy_depth, $level_num );
				}
			}
		}

		if ( empty( $hierarchy_labels ) ) {
			$hierarchy_labels = array(
				1 => __( 'Brand', 'mvweb-price-table' ),
				2 => __( 'Type', 'mvweb-price-table' ),
				3 => __( 'Model', 'mvweb-price-table' ),
			);
		}

		$specified_depth = max( array_keys( $levels ) );

		$extra_columns = array();
		for ( $i = $specified_depth + 1; $i <= $hierarchy_depth; $i++ ) {
			if ( isset( $hierarchy_labels[ $i ] ) ) {
				$extra_columns[] = array(
					'level' => $i,
					'label' => $hierarchy_labels[ $i ],
				);
			}
		}

		$brand_key = isset( $levels[1] ) ? $levels[1] : null;

		if ( ! $brand_key || ! isset( $sheets_data['data'][ $brand_key ] ) ) {
			wp_send_json_success(
				array(
					'services'          => array(),
					'hierarchy_columns' => $extra_columns,
				)
			);
			return;
		}

		$brand_data = $sheets_data['data'][ $brand_key ];

		if ( 1 === $specified_depth ) {
			if ( isset( $brand_data['types'] ) ) {
				foreach ( $brand_data['types'] as $type_key => $type_data ) {
					$type_name = $type_data['name'];
					if ( isset( $type_data['models'] ) ) {
						foreach ( $type_data['models'] as $model_key => $model_data ) {
							if ( ! empty( $model_data['pattern'] ) ) {
								continue;
							}
							$hierarchy = array();
							if ( $hierarchy_depth >= 2 ) {
								$hierarchy['level_2'] = $type_name;
							}
							if ( $hierarchy_depth >= 3 ) {
								$hierarchy['level_3'] = $model_data['name'];
							}
							$this->collect_services( $all_services, $model_data['services'], $hierarchy, $field_mapping );
						}
					}
				}
			}
		} elseif ( 2 === $specified_depth ) {
			$type_key = isset( $levels[2] ) ? $levels[2] : null;
			if ( $type_key && isset( $brand_data['types'][ $type_key ]['models'] ) ) {
				foreach ( $brand_data['types'][ $type_key ]['models'] as $model_key => $model_data ) {
					if ( ! empty( $model_data['pattern'] ) ) {
						continue;
					}
					$hierarchy = array();
					if ( $hierarchy_depth >= 3 ) {
						$hierarchy['level_3'] = $model_data['name'];
					}
					$this->collect_services( $all_services, $model_data['services'], $hierarchy, $field_mapping );
				}
			}
		} elseif ( $specified_depth >= 3 ) {
			$type_key  = isset( $levels[2] ) ? $levels[2] : null;
			$model_key = isset( $levels[3] ) ? $levels[3] : null;
			if ( $type_key && $model_key && isset( $brand_data['types'][ $type_key ]['models'][ $model_key ] ) ) {
				$model_data = $brand_data['types'][ $type_key ]['models'][ $model_key ];
				$this->collect_services( $all_services, $model_data['services'], array(), $field_mapping );
			}
		}

		$legacy_stats = array();
		if ( isset( $levels[1] ) ) {
			$legacy_stats['brand'] = $levels[1];
		}
		if ( isset( $levels[2] ) ) {
			$legacy_stats['type'] = $levels[2];
		}
		if ( isset( $levels[3] ) ) {
			$legacy_stats['model'] = $levels[3];
		}
		$this->log_stats( $form_id, 'get_all_prices', $legacy_stats );

		wp_send_json_success(
			array(
				'services'          => $all_services,
				'hierarchy_columns' => $extra_columns,
			)
		);
	}

	/**
	 * Recursively collect services from a mapped tree node.
	 *
	 * @since 2.4.0
	 * @param array      &$result          Accumulated result array.
	 * @param array      $node             Current tree node (with name, children, services).
	 * @param int        $current_eff_pos  Current effective position in the tree.
	 * @param int        $total_depth      Total effective hierarchy depth.
	 * @param array      $effective_levels Effective hierarchy configuration.
	 * @param array      $hierarchy_ctx    Hierarchy context for extra columns.
	 * @param array|null $field_mapping    Field mapping configuration.
	 * @return void
	 */
	private function collect_tree_services( &$result, $node, $current_eff_pos, $total_depth, $effective_levels, $hierarchy_ctx, $field_mapping, $depth = 0 ) {
		if ( $depth > 10 ) {
			return;
		}

		if ( $current_eff_pos >= $total_depth ) {
			$this->collect_services( $result, $node['services'], $hierarchy_ctx, $field_mapping );
			return;
		}

		if ( ! empty( $node['children'] ) ) {
			foreach ( $node['children'] as $child_key => $child_node ) {
				$next_pos     = $current_eff_pos + 1;
				$orig_level   = $effective_levels[ $next_pos ]['original_level'];
				$child_ctx    = $hierarchy_ctx;
				$child_ctx[ 'level_' . $orig_level ] = $child_node['name'];

				$this->collect_tree_services(
					$result,
					$child_node,
					$next_pos,
					$total_depth,
					$effective_levels,
					$child_ctx,
					$field_mapping,
					$depth + 1
				);
			}
		}
	}

	/**
	 * Collect and format services from a model, adding hierarchy info.
	 *
	 * @since 2.3.0
	 * @param array      &$result       Accumulated result array.
	 * @param array      $services      Services from model data.
	 * @param array      $hierarchy     Hierarchy context (e.g., ['level_2' => 'iPhone', 'level_3' => 'iPhone 15']).
	 * @param array|null $field_mapping Field mapping configuration.
	 * @return void
	 */
	private function collect_services( &$result, $services, $hierarchy, $field_mapping ) {
		foreach ( $services as $service ) {
			$item = array(
				'hierarchy'     => $hierarchy,
				'name'          => $service['name'],
				'time'          => isset( $service['time'] ) ? $service['time'] : '',
				'price'         => $service['price'],
				'price_display' => mvweb_pt_format_price( $service['price'] ),
			);

			if ( $field_mapping && isset( $field_mapping['columns'] ) && isset( $service['raw_cells'] ) ) {
				foreach ( $field_mapping['columns'] as $column ) {
					$role  = $column['role'];
					$index = $column['index'];

					if ( strpos( $role, 'hierarchy_' ) === 0 ) {
						continue;
					}

					$raw_value = isset( $service['raw_cells'][ $index ] ) ? $service['raw_cells'][ $index ] : '';
					$key       = str_replace( array( 'service_', 'meta_' ), '', $role );

					if ( 'service_price' === $role ) {
						$item['price']         = $this->parse_price_value( $raw_value );
						$item['price_display'] = mvweb_pt_format_price( $item['price'] );
					} elseif ( 'service_name' === $role ) {
						$item['name'] = $raw_value;
					} elseif ( 'service_time' === $role ) {
						$item['time'] = $raw_value;
					} else {
						$item[ $key ] = $raw_value;
					}
				}
			}

			$result[] = $item;
		}
	}

	/**
	 * Parse price value from string.
	 *
	 * @since 2.0.0
	 * @param string $price_string Price string.
	 * @return float|string Parsed price.
	 */
	private function parse_price_value( $price_string ) {
		if ( empty( $price_string ) ) {
			return 0;
		}

		$clean = preg_replace( '/[^\d.,\-]/', '', $price_string );

		if ( strpos( $clean, '-' ) !== false && preg_match( '/^\d/', $clean ) ) {
			return $price_string;
		}

		$clean = str_replace( ',', '.', $clean );

		if ( is_numeric( $clean ) ) {
			return floatval( $clean );
		}

		return $price_string;
	}

	/**
	 * Fetch sheets data for a form, using mapped parser when appropriate.
	 *
	 * @since 2.4.0
	 * @param array              $form   Form data.
	 * @param MVweb_PT_Google_Sheets $sheets Sheets instance.
	 * @return array|WP_Error Parsed data or error.
	 */
	private function fetch_form_data( $form, $sheets ) {
		$field_mapping = isset( $form['field_mapping'] ) ? $form['field_mapping'] : null;
		$is_mapped     = $field_mapping && isset( $field_mapping['mode'] ) && 'mapped' === $field_mapping['mode'];

		return $sheets->fetch_data(
			$form['spreadsheet_id'],
			true,
			$is_mapped ? $field_mapping : null
		);
	}

	/**
	 * Check if parsed sheets data uses the mapped tree structure.
	 *
	 * @since 2.4.0
	 * @param array $sheets_data Parsed sheets data.
	 * @return bool True if mapped mode (tree structure present).
	 */
	private function is_tree_data( $sheets_data ) {
		return isset( $sheets_data['tree'] );
	}

	/**
	 * Map effective hierarchy level values to brand/type/model for statistics.
	 *
	 * Maps effective positions 1→brand, 2→type, 3→model regardless of
	 * original level numbers. E.g., for effective [1, 3] the values of
	 * original level 1 map to 'brand', original level 3 to 'type'.
	 *
	 * @since 2.5.0
	 * @param array $values          Level values keyed by original level number or effective position.
	 * @param array $effective_levels Effective hierarchy configuration (1-based).
	 * @return array Stats context with brand/type/model keys.
	 */
	private function map_levels_to_stats( array $values, array $effective_levels ): array {
		$stats_keys = array( 1 => 'brand', 2 => 'type', 3 => 'model' );
		$result     = array();
		$eff_pos    = 0;

		foreach ( $effective_levels as $level_info ) {
			++$eff_pos;
			if ( $eff_pos > 3 ) {
				break;
			}

			$orig_level = is_array( $level_info ) ? $level_info['original_level'] : $level_info;
			$stats_key  = $stats_keys[ $eff_pos ];

			if ( isset( $values[ $orig_level ] ) ) {
				$result[ $stats_key ] = sanitize_text_field( $values[ $orig_level ] );
			} elseif ( isset( $values[ $eff_pos ] ) ) {
				$result[ $stats_key ] = sanitize_text_field( $values[ $eff_pos ] );
			}
		}

		return $result;
	}

	/**
	 * Traverse the mapped tree to get items at a specific effective position.
	 *
	 * @since 2.4.0
	 * @param array $tree              The tree structure from parse_mapped().
	 * @param int   $target_eff_pos    Target effective position (1-based).
	 * @param array $effective_levels  Effective hierarchy array.
	 * @param array $parent_values     Sanitized parent values keyed by original level number.
	 * @return array Items at the target level (key => name).
	 */
	private function traverse_tree_for_level( array $tree, int $target_eff_pos, array $effective_levels, array $parent_values ): array {
		$node = $tree;

		for ( $i = 1; $i < $target_eff_pos; $i++ ) {
			$orig_level = $effective_levels[ $i ]['original_level'];
			$parent_key = isset( $parent_values[ $orig_level ] ) ? $parent_values[ $orig_level ] : '';

			if ( empty( $parent_key ) || ! isset( $node[ $parent_key ] ) ) {
				return array();
			}
			$node = $node[ $parent_key ]['children'];
		}

		$items = array();
		foreach ( $node as $key => $data ) {
			$items[ $key ] = $data['name'];
		}

		return $items;
	}

	/**
	 * Traverse the mapped tree to get services at the last effective level.
	 *
	 * @since 2.4.0
	 * @param array $tree              Tree structure.
	 * @param array $effective_levels  Effective hierarchy.
	 * @param array $parent_values     Sanitized parent values keyed by original level number.
	 * @return array Services array.
	 */
	private function traverse_tree_for_services( array $tree, array $effective_levels, array $parent_values ): array {
		$node  = $tree;
		$depth = count( $effective_levels );

		for ( $i = 1; $i <= $depth; $i++ ) {
			$orig_level = $effective_levels[ $i ]['original_level'];
			$key        = isset( $parent_values[ $orig_level ] ) ? $parent_values[ $orig_level ] : '';

			if ( empty( $key ) || ! isset( $node[ $key ] ) ) {
				return array();
			}

			if ( $i === $depth ) {
				return $node[ $key ]['services'];
			}

			$node = $node[ $key ]['children'];
		}

		return array();
	}

	/**
	 * Get hierarchy level handler (v2.0 universal endpoint).
	 *
	 * Returns items at a specific hierarchy level based on parent selections.
	 * Supports both legacy (brand/type/model) and mapped (tree) data structures.
	 *
	 * @since 2.0.0
	 * @since 2.4.0 Added mapped tree traversal support.
	 * @return void
	 */
	public function get_hierarchy_level() {
		$this->verify_public_nonce();

		$form_id = isset( $_REQUEST['form_id'] ) ? absint( $_REQUEST['form_id'] ) : 0;
		$level   = isset( $_REQUEST['level'] ) ? absint( $_REQUEST['level'] ) : 1;

		$data        = $this->get_form_and_sheets();
		$sheets_data = $this->fetch_form_data( $data['form'], $data['sheets'] );

		if ( is_wp_error( $sheets_data ) ) {
			MVweb_PT_Logger::error(
				$sheets_data->get_error_message(),
				'ajax',
				array(
					'action'  => 'get_hierarchy_level',
					'form_id' => $form_id,
					'level'   => $level,
					'code'    => $sheets_data->get_error_code(),
				)
			);

			wp_send_json_error(
				array(
					'code'    => $sheets_data->get_error_code(),
					'message' => $sheets_data->get_error_message(),
				),
				500
			);
		}

		$items = array();

		if ( $this->is_tree_data( $sheets_data ) ) {
			$effective_levels = $sheets_data['effective_levels'];

			if ( $level < 1 || $level > count( $effective_levels ) ) {
				wp_send_json_success( array( 'items' => array(), 'level' => $level ) );
				return;
			}

			$parent_values = array();
			foreach ( $effective_levels as $eff_pos => $level_info ) {
				if ( $eff_pos >= $level ) {
					break;
				}
				$orig      = $level_info['original_level'];
				$param_key = 'level_' . $orig;
				if ( isset( $_REQUEST[ $param_key ] ) && is_string( $_REQUEST[ $param_key ] ) && '' !== $_REQUEST[ $param_key ] ) {
					$parent_values[ $orig ] = mvweb_pt_slug( wp_unslash( $_REQUEST[ $param_key ] ) );
				}
			}

			$items = $this->traverse_tree_for_level(
				$sheets_data['tree'],
				$level,
				$effective_levels,
				$parent_values
			);
		} else {
			if ( 1 === $level ) {
				$items = isset( $sheets_data['brands'] ) ? $sheets_data['brands'] : array();
			} elseif ( 2 === $level ) {
				$brand = isset( $_REQUEST['level_1'] ) ? sanitize_title( wp_unslash( $_REQUEST['level_1'] ) ) : '';
				if ( ! empty( $brand ) && isset( $sheets_data['data'][ $brand ]['types'] ) ) {
					foreach ( $sheets_data['data'][ $brand ]['types'] as $type_key => $type_data ) {
						$items[ $type_key ] = $type_data['name'];
					}
				}
			} elseif ( 3 === $level ) {
				$brand = isset( $_REQUEST['level_1'] ) ? sanitize_title( wp_unslash( $_REQUEST['level_1'] ) ) : '';
				$type  = isset( $_REQUEST['level_2'] ) ? sanitize_title( wp_unslash( $_REQUEST['level_2'] ) ) : '';
				if ( ! empty( $brand ) && ! empty( $type ) && isset( $sheets_data['data'][ $brand ]['types'][ $type ]['models'] ) ) {
					foreach ( $sheets_data['data'][ $brand ]['types'][ $type ]['models'] as $model_key => $model_data ) {
						$items[ $model_key ] = $model_data['name'];
					}
				}
			}
		}

		natcasesort( $items );

		$stats_ctx = array();
		if ( $this->is_tree_data( $sheets_data ) ) {
			$stats_ctx = $this->map_levels_to_stats( $parent_values, $effective_levels );
		} else {
			if ( $level >= 2 ) {
				$stats_ctx['brand'] = isset( $_REQUEST['level_1'] ) ? sanitize_title( wp_unslash( $_REQUEST['level_1'] ) ) : '';
			}
			if ( $level >= 3 ) {
				$stats_ctx['type'] = isset( $_REQUEST['level_2'] ) ? sanitize_title( wp_unslash( $_REQUEST['level_2'] ) ) : '';
			}
		}
		$this->log_stats( $form_id, 'get_hierarchy_level', $stats_ctx );

		wp_send_json_success(
			array(
				'items' => $items,
				'level' => $level,
			)
		);
	}

	/**
	 * Log statistics for a request.
	 *
	 * @since 1.0.0
	 * @param int    $form_id Form ID.
	 * @param string $action  Action type.
	 * @param array  $data    Additional data.
	 * @return void
	 */
	private function log_stats( $form_id, $action, $data = array() ) {
		$statistics = new MVweb_PT_Statistics();
		$statistics->log_request( $form_id, $action, $data );
	}

	/**
	 * Admin: Save form handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_save_form() {
		$this->verify_admin_request();

		$form_id = isset( $_POST['form_id'] ) ? absint( $_POST['form_id'] ) : null;
		if ( 0 === $form_id ) {
			$form_id = null;
		}

		$form_data = array(
			'name'            => isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '',
			'spreadsheet_url' => isset( $_POST['spreadsheet_url'] ) ? esc_url_raw( wp_unslash( $_POST['spreadsheet_url'] ) ) : '',
			'status'          => isset( $_POST['status'] ) ? sanitize_key( $_POST['status'] ) : 'active',
			'preset'          => isset( $_POST['preset'] ) ? sanitize_key( $_POST['preset'] ) : 'light',
			'settings'        => isset( $_POST['settings'] ) ? mvweb_sanitize_array( wp_unslash( $_POST['settings'] ) ) : array(),
			'sheet_id'        => isset( $_POST['sheet_id'] ) && '' !== $_POST['sheet_id'] ? absint( $_POST['sheet_id'] ) : null,
			'sheet_name'      => isset( $_POST['sheet_name'] ) ? sanitize_text_field( wp_unslash( $_POST['sheet_name'] ) ) : '',
		);

		if ( isset( $_POST['field_mapping'] ) && '' !== $_POST['field_mapping'] ) {
			$mapping_json = wp_unslash( $_POST['field_mapping'] );
			$mapping      = json_decode( $mapping_json, true );
			if ( JSON_ERROR_NONE === json_last_error() && is_array( $mapping ) ) {
				$form_data['field_mapping'] = $mapping;
			}
		}

		$result = mvweb_pt_save_form( $form_data, $form_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'code'    => $result->get_error_code(),
					'message' => $result->get_error_message(),
				),
				400
			);
		}

		$form = mvweb_pt_get_form( $result );

		wp_send_json_success(
			array(
				'form_id'   => $result,
				'form'      => $form,
				'shortcode' => mvweb_pt_get_shortcode( $result ),
				'message'   => __( 'Form saved successfully.', 'mvweb-price-table' ),
			)
		);
	}

	/**
	 * Admin: Delete form handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_delete_form() {
		$this->verify_admin_request();

		$form_id = isset( $_POST['form_id'] ) ? absint( $_POST['form_id'] ) : 0;

		if ( ! $form_id ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_form_id',
					'message' => __( 'Form ID is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$result = mvweb_pt_delete_form( $form_id );

		if ( ! $result ) {
			wp_send_json_error(
				array(
					'code'    => 'delete_failed',
					'message' => __( 'Failed to delete form.', 'mvweb-price-table' ),
				),
				500
			);
		}

		wp_send_json_success(
			array(
				'message' => __( 'Form deleted successfully.', 'mvweb-price-table' ),
			)
		);
	}

	/**
	 * Admin: Test connection handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_test_connection() {
		$this->verify_admin_request();

		$spreadsheet_url = isset( $_POST['spreadsheet_url'] ) ? esc_url_raw( wp_unslash( $_POST['spreadsheet_url'] ) ) : '';

		if ( empty( $spreadsheet_url ) ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_url',
					'message' => __( 'Google Sheets URL is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$sheets         = new MVweb_PT_Google_Sheets();
		$spreadsheet_id = $sheets->extract_spreadsheet_id( $spreadsheet_url );

		if ( ! $spreadsheet_id ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_url',
					'message' => __( 'Invalid Google Sheets URL.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$result = $sheets->test_connection( $spreadsheet_id );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'code'    => $result->get_error_code(),
					'message' => $result->get_error_message(),
				),
				400
			);
		}

		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: %1$d: brands count, %2$d: types count, %3$d: models count, %4$d: services count */
					__( 'Connection successful! Found %1$d brands, %2$d types, %3$d models, %4$d services.', 'mvweb-price-table' ),
					$result['stats']['brands'],
					$result['stats']['types'],
					$result['stats']['models'],
					$result['stats']['services']
				),
				'stats'   => $result['stats'],
			)
		);
	}

	/**
	 * Admin: Clear cache handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_clear_cache() {
		$this->verify_admin_request();

		$cache   = new MVweb_PT_Cache();
		$deleted = $cache->flush_all();

		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: %d: number of deleted cache entries */
					__( 'Cache cleared. %d entries deleted.', 'mvweb-price-table' ),
					$deleted
				),
			)
		);
	}

	/**
	 * Admin: Save settings handler.
	 *
	 * Saves both Settings and Appearance tabs in a single request.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_save_settings() {
		$this->verify_admin_request();

		$settings = get_option( 'mvweb_pt_settings', array() );

		$settings['cache_ttl']              = isset( $_POST['cache_ttl'] ) ? absint( $_POST['cache_ttl'] ) : 3600;
		$settings['fallback_enabled']       = isset( $_POST['fallback_enabled'] ) && '1' === $_POST['fallback_enabled'];
		$settings['stats_enabled']          = isset( $_POST['stats_enabled'] ) && '1' === $_POST['stats_enabled'];
		$settings['default_preset']         = isset( $_POST['default_preset'] ) ? sanitize_key( $_POST['default_preset'] ) : 'light';
		$settings['currency']               = isset( $_POST['currency'] ) ? strtoupper( sanitize_text_field( wp_unslash( $_POST['currency'] ) ) ) : 'RUB';
		$settings['custom_currency']        = isset( $_POST['custom_currency'] ) ? sanitize_text_field( wp_unslash( $_POST['custom_currency'] ) ) : '';
		$settings['keep_data_on_uninstall'] = isset( $_POST['keep_data_on_uninstall'] ) && '1' === $_POST['keep_data_on_uninstall'];

		$appearance_keys = array(
			'default_title',
			'default_description',
			'footer_text',
			'default_button_text',
			'button_style',
			'service_column_label',
			'time_column_label',
			'price_column_label',
			'on_request_text',
			'custom_css',
		);

		foreach ( $appearance_keys as $key ) {
			if ( isset( $_POST[ $key ] ) ) {
				if ( 'custom_css' === $key ) {
					$settings[ $key ] = wp_strip_all_tags( wp_unslash( $_POST[ $key ] ) );
				} elseif ( in_array( $key, array( 'default_description', 'footer_text' ), true ) ) {
					$settings[ $key ] = wp_kses_post( wp_unslash( $_POST[ $key ] ) );
				} else {
					$settings[ $key ] = sanitize_text_field( wp_unslash( $_POST[ $key ] ) );
				}
			}
		}

		update_option( 'mvweb_pt_settings', $settings );

		wp_send_json_success(
			array(
				'message' => __( 'Settings saved successfully.', 'mvweb-price-table' ),
			)
		);
	}

	/**
	 * Admin: Save appearance settings handler.
	 *
	 * @since 1.1.0
	 * @deprecated 2.2.0 Use admin_save_settings() instead.
	 * @return void
	 */
	public function admin_save_appearance() {
		$this->admin_save_settings();
	}

	/**
	 * Admin: Get statistics handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_get_stats() {
		$this->verify_admin_request();

		$period  = isset( $_POST['period'] ) ? sanitize_key( $_POST['period'] ) : 'month';
		$form_id = isset( $_POST['form_id'] ) && '' !== $_POST['form_id'] ? absint( $_POST['form_id'] ) : null;

		$statistics = new MVweb_PT_Statistics();
		$stats      = $statistics->get_stats( $period, $form_id );

		wp_send_json_success( $stats );
	}

	/**
	 * Admin: Export statistics handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_export_stats() {
		$this->verify_admin_request();

		$period  = isset( $_POST['period'] ) ? sanitize_key( $_POST['period'] ) : 'month';
		$form_id = isset( $_POST['form_id'] ) && '' !== $_POST['form_id'] ? absint( $_POST['form_id'] ) : null;

		$statistics = new MVweb_PT_Statistics();
		$csv        = $statistics->export_csv( $period, $form_id );

		wp_send_json_success(
			array(
				'csv'      => $csv,
				'filename' => 'price-table-stats-' . gmdate( 'Y-m-d' ) . '.csv',
			)
		);
	}

	/**
	 * Admin: Clear statistics handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function admin_clear_stats() {
		$this->verify_admin_request();

		$period  = isset( $_POST['period'] ) ? sanitize_key( $_POST['period'] ) : 'all';
		$form_id = isset( $_POST['form_id'] ) && '' !== $_POST['form_id'] ? absint( $_POST['form_id'] ) : null;

		$statistics = new MVweb_PT_Statistics();
		$deleted    = $statistics->clear_stats( $period, $form_id );

		wp_send_json_success(
			array(
				'message' => sprintf(
					/* translators: %d: number of deleted entries */
					__( 'Statistics cleared. %d entries deleted.', 'mvweb-price-table' ),
					$deleted
				),
				'deleted' => $deleted,
			)
		);
	}

	/**
	 * Admin: Export logs handler.
	 *
	 * @since 1.1.0
	 * @return void
	 */
	public function admin_export_logs() {
		$this->verify_admin_request();

		$json     = MVweb_PT_Logger::export_json();
		$filename = 'mvweb-price-table-logs-' . gmdate( 'Y-m-d-His' ) . '.json';

		header( 'Content-Type: application/json' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Length: ' . strlen( $json ) );

		echo $json; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- JSON export
		exit;
	}

	/**
	 * Admin: Fetch sheets list from spreadsheet.
	 *
	 * @since 2.2.0
	 * @return void
	 */
	public function admin_fetch_sheets() {
		$this->verify_admin_request();

		$spreadsheet_url = isset( $_POST['spreadsheet_url'] ) ? esc_url_raw( wp_unslash( $_POST['spreadsheet_url'] ) ) : '';

		if ( empty( $spreadsheet_url ) ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_url',
					'message' => __( 'Google Sheets URL is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$sheets         = new MVweb_PT_Google_Sheets();
		$spreadsheet_id = $sheets->extract_spreadsheet_id( $spreadsheet_url );

		if ( ! $spreadsheet_id ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_url',
					'message' => __( 'Invalid Google Sheets URL.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$sheets_list = $sheets->fetch_sheets_list( $spreadsheet_id );

		if ( is_wp_error( $sheets_list ) ) {
			wp_send_json_error(
				array(
					'code'    => $sheets_list->get_error_code(),
					'message' => $sheets_list->get_error_message(),
				),
				400
			);
		}

		wp_send_json_success(
			array(
				'sheets'  => $sheets_list,
				'message' => sprintf(
					/* translators: %d: number of sheets found */
					__( 'Found %d sheets.', 'mvweb-price-table' ),
					count( $sheets_list )
				),
			)
		);
	}

	/**
	 * Admin: Auto-detect column mapping from spreadsheet headers.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function admin_auto_detect_mapping() {
		$this->verify_admin_request();

		$spreadsheet_url = isset( $_POST['spreadsheet_url'] ) ? esc_url_raw( wp_unslash( $_POST['spreadsheet_url'] ) ) : '';

		if ( empty( $spreadsheet_url ) ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_url',
					'message' => __( 'Google Sheets URL is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$sheets         = new MVweb_PT_Google_Sheets();
		$spreadsheet_id = $sheets->extract_spreadsheet_id( $spreadsheet_url );

		if ( ! $spreadsheet_id ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_url',
					'message' => __( 'Invalid Google Sheets URL.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$headers = $sheets->fetch_headers( $spreadsheet_id );

		if ( is_wp_error( $headers ) ) {
			wp_send_json_error(
				array(
					'code'    => $headers->get_error_code(),
					'message' => $headers->get_error_message(),
				),
				400
			);
		}

		$mapper          = new MVweb_PT_Field_Mapper();
		$detected_mapping = $mapper->auto_detect_mapping( $headers );

		wp_send_json_success(
			array(
				'mapping' => $detected_mapping,
				'headers' => $headers,
				'message' => __( 'Columns detected successfully.', 'mvweb-price-table' ),
			)
		);
	}

	/**
	 * Fetch preview data from spreadsheet.
	 *
	 * @since 2.0.0
	 * @return void
	 */
	public function admin_fetch_preview() {
		$this->verify_admin_request();

		$spreadsheet_url = isset( $_POST['spreadsheet_url'] ) ? esc_url_raw( wp_unslash( $_POST['spreadsheet_url'] ) ) : '';
		$limit           = isset( $_POST['limit'] ) ? absint( $_POST['limit'] ) : 20;

		if ( empty( $spreadsheet_url ) ) {
			wp_send_json_error(
				array(
					'code'    => 'missing_url',
					'message' => __( 'Google Sheets URL is required.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$sheets         = new MVweb_PT_Google_Sheets();
		$spreadsheet_id = $sheets->extract_spreadsheet_id( $spreadsheet_url );

		if ( ! $spreadsheet_id ) {
			wp_send_json_error(
				array(
					'code'    => 'invalid_url',
					'message' => __( 'Invalid Google Sheets URL.', 'mvweb-price-table' ),
				),
				400
			);
		}

		$raw_data = $sheets->fetch_raw_rows( $spreadsheet_id, $limit + 1 );

		if ( is_wp_error( $raw_data ) ) {
			wp_send_json_error(
				array(
					'code'    => $raw_data->get_error_code(),
					'message' => $raw_data->get_error_message(),
				),
				400
			);
		}

		$headers = ! empty( $raw_data ) ? array_shift( $raw_data ) : array();
		$rows    = array_slice( $raw_data, 0, $limit );

		wp_send_json_success(
			array(
				'headers' => $headers,
				'rows'    => $rows,
			)
		);
	}
}

new MVweb_PT_Ajax();
