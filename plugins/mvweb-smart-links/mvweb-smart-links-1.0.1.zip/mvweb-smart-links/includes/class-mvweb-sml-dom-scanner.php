<?php
/**
 * DOM scanner: shared content rewriting engine.
 *
 * Walks the text nodes of an HTML fragment and inserts contextual links
 * for the supplied list of candidates while respecting per-page limits,
 * inter-link gaps and excluded ancestors.
 *
 * Used by both the frontend Linker (public/class-mvweb-sml-linker.php) and
 * the admin "Generate suggestions" sweep (admin/class-mvweb-sml-bulk.php in
 * a later phase). Living under includes/ keeps it loadable from either side.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_DOM_Scanner
 *
 * @since 1.0.0
 */
class MVweb_SML_DOM_Scanner {

	/**
	 * Default tag names whose descendants are never linkified.
	 *
	 * @var array<int, string>
	 */
	const DEFAULT_EXCLUDED_ELEMENTS = array(
		'h1',
		'h2',
		'h3',
		'h4',
		'h5',
		'h6',
		'pre',
		'code',
		'blockquote',
		'a',
		'script',
		'style',
	);

	/**
	 * Scan a content string and insert links for matching keywords.
	 *
	 * Always returns the modified HTML alongside the list of inserted pairs
	 * — callers in "collect only" mode (admin sweep) can simply discard the
	 * `html` key. Keeping a single signature avoids divergent code paths.
	 *
	 * `$candidates` items shape:
	 *   array(
	 *       'target_id' => int,         // Required.
	 *       'keyword'   => string,      // Required, used for the regex match.
	 *       'permalink' => string,      // Required, becomes the href.
	 *       'priority'  => int,         // Lower = inserted first. Default PHP_INT_MAX.
	 *       'anchor'    => string|null, // Optional override for the visible text.
	 *       'title'     => string|null, // Optional title attribute.
	 *   )
	 *
	 * `$opts` recognised keys:
	 *   - links_gap_words          int   Minimum word distance between two inserted links.
	 *   - links_max_per_page       int   Hard cap on inserted links for this scan.
	 *   - links_max_per_paragraph  int   Cap on inserted links per block ancestor (0 = off).
	 *   - excluded_elements        array Tag names whose subtree is skipped.
	 *   - link_class           string CSS class added to each <a>.
	 *   - link_target          string `target` attribute value.
	 *   - extra_attributes     array  Extra attributes appended to every <a>.
	 *
	 * @since 1.0.0
	 * @param string               $content    Source HTML.
	 * @param int                  $source_id  Source post ID (used for filters/meta only).
	 * @param array<int, array>    $candidates Candidate links — see shape above.
	 * @param array<string, mixed> $opts       Scanner options.
	 * @return array{html:string, inserted:array<int, array<string, mixed>>, word_total:int}
	 */
	public static function scan( $content, $source_id, array $candidates, array $opts = array() ) {
		$content = (string) $content;

		if ( '' === $content || empty( $candidates ) ) {
			return array(
				'html'       => $content,
				'inserted'   => array(),
				'word_total' => 0,
			);
		}

		// MANDATORY normalisation: enforce priority ordering even if the caller
		// forgot. Bulk::generate_suggestions calls scan() directly, so the
		// contract cannot rely on the linker pre-sorting the array.
		usort(
			$candidates,
			static function ( $a, $b ) {
				$pa = isset( $a['priority'] ) ? (int) $a['priority'] : PHP_INT_MAX;
				$pb = isset( $b['priority'] ) ? (int) $b['priority'] : PHP_INT_MAX;
				return $pa <=> $pb;
			}
		);

		// Pre-compile a morphological match pattern per candidate once, before
		// the per-text-node loop, so the stemmer runs O(candidates) instead of
		// O(candidates × text nodes). The keyword and any registered synonyms
		// are folded into a single alternation so one link can fire on any of
		// them — morphology applies to each variant independently. Patterns are
		// kept in a side array keyed by candidate index so the public candidate
		// contract (exposed to the mvweb_sml_links filter) is not polluted.
		$patterns = array();
		foreach ( $candidates as $i => $cand ) {
			$kw             = isset( $cand['keyword'] ) ? (string) $cand['keyword'] : '';
			$synonyms       = isset( $cand['synonyms'] ) && is_array( $cand['synonyms'] ) ? $cand['synonyms'] : array();
			$variants       = array_merge( array( $kw ), $synonyms );
			$patterns[ $i ] = self::build_keyword_pattern( $variants );
		}

		$gap_words   = isset( $opts['links_gap_words'] ) ? max( 0, (int) $opts['links_gap_words'] ) : 50;
		$max_links   = isset( $opts['links_max_per_page'] ) ? max( 0, (int) $opts['links_max_per_page'] ) : 0;
		// Per-paragraph cap: 0 = unlimited. Counts inserted links per nearest
		// block ancestor so one paragraph is never over-linked (SEO safeguard).
		$max_per_para = isset( $opts['links_max_per_paragraph'] ) ? max( 0, (int) $opts['links_max_per_paragraph'] ) : 0;
		$link_class  = isset( $opts['link_class'] ) ? sanitize_html_class( (string) $opts['link_class'] ) : 'mvweb-sml-link';
		$link_target = isset( $opts['link_target'] ) ? (string) $opts['link_target'] : '_self';
		// scan() is a public entry point; do not trust the caller to have
		// whitelisted the target — an unknown value would land verbatim in the
		// target attribute.
		if ( ! in_array( $link_target, array( '_self', '_blank', '_parent', '_top' ), true ) ) {
			$link_target = '_self';
		}
		// Base rel tokens from the caller (e.g. 'nofollow'); each token is a
		// single sanitize_html_class value so nothing arbitrary reaches the attr.
		$link_rel_tokens = array();
		if ( isset( $opts['link_rel'] ) && '' !== (string) $opts['link_rel'] ) {
			foreach ( preg_split( '/\s+/', (string) $opts['link_rel'] ) as $rel_token ) {
				$rel_token = sanitize_html_class( $rel_token );
				if ( '' !== $rel_token ) {
					$link_rel_tokens[] = $rel_token;
				}
			}
		}
		$extra_attrs  = isset( $opts['extra_attributes'] ) && is_array( $opts['extra_attributes'] ) ? $opts['extra_attributes'] : array();
		$track_target = ! empty( $opts['track_target'] );
		$excluded     = isset( $opts['excluded_elements'] ) && is_array( $opts['excluded_elements'] )
			? $opts['excluded_elements']
			: self::DEFAULT_EXCLUDED_ELEMENTS;

		/**
		 * Filter the list of HTML tag names whose descendants are skipped.
		 *
		 * @since 1.0.0
		 * @param array $excluded  Tag names.
		 * @param int   $source_id Source post ID.
		 */
		$excluded = apply_filters( 'mvweb_sml_excluded_elements', $excluded, $source_id );
		// Keep only valid HTML tag names. The values are interpolated into an
		// XPath expression below, so a filter returning anything other than a
		// bare element name (e.g. "a[@href]") must be rejected to prevent XPath
		// injection.
		$excluded = array_values(
			array_filter(
				array_map( 'strtolower', array_map( 'strval', $excluded ) ),
				static function ( $tag ) {
					return (bool) preg_match( '/^[a-z][a-z0-9-]*$/', $tag );
				}
			)
		);
		if ( empty( $excluded ) ) {
			$excluded = self::DEFAULT_EXCLUDED_ELEMENTS;
		}

		// Load the document. We wrap the input in a known root so that
		// libxml < 2.9.13 reliably round-trips multi-root content (the typical
		// shape produced by the_content output).
		libxml_use_internal_errors( true );
		$dom                     = new DOMDocument( '1.0', 'UTF-8' );
		$dom->preserveWhiteSpace = true; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOMDocument property name fixed by PHP core.
		$dom->formatOutput       = false; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOMDocument property name fixed by PHP core.

		$wrapped = '<div class="mvweb-sml-wrap">' . $content . '</div>';
		$loaded  = $dom->loadHTML(
			'<?xml encoding="utf-8" ?>' . $wrapped,
			LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
		);
		libxml_clear_errors();

		if ( ! $loaded ) {
			return array(
				'html'       => $content,
				'inserted'   => array(),
				'word_total' => 0,
			);
		}

		$xpath = new DOMXPath( $dom );

		$exclusion_parts = array();
		foreach ( $excluded as $tag ) {
			$exclusion_parts[] = "not(ancestor::{$tag})";
		}
		$exclusion_xpath = implode( ' and ', $exclusion_parts );
		$nodes           = $xpath->query( "//text()[{$exclusion_xpath}]" );

		// CRITICAL: materialise the live NodeList. Mutating the DOM inside the
		// loop invalidates the iterator and silently drops half of the matches
		// on long posts.
		$text_nodes = array();
		if ( $nodes ) {
			foreach ( $nodes as $node ) {
				$text_nodes[] = $node;
			}
		}

		$inserted         = array();
		$inserted_count   = 0;
		$used_targets     = array();
		$used_keywords    = array();
		$last_word_offset = null;
		$running_word_pos = 0;
		$para_counts      = array();

		foreach ( $text_nodes as $text_node ) {
			if ( $max_links > 0 && $inserted_count >= $max_links ) {
				break;
			}

			$node_text = $text_node->nodeValue; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM property fixed by PHP core.
			if ( '' === (string) $node_text ) {
				continue;
			}

			$node_word_count = self::count_words( $node_text );

			// Per-paragraph cap: if this node's block already holds the maximum
			// number of inserted links, skip the whole node — leaving every
			// candidate free to land in a different paragraph later.
			$block_key = 0;
			if ( $max_per_para > 0 ) {
				$block     = self::paragraph_ancestor( $text_node );
				$block_key = $block ? spl_object_id( $block ) : 0;
				if ( $block_key && isset( $para_counts[ $block_key ] ) && $para_counts[ $block_key ] >= $max_per_para ) {
					$running_word_pos += $node_word_count;
					continue;
				}
			}

			// Try every candidate against this text node. The candidates list is
			// already sorted by priority, so manual targets get a fair shot first.
			$best_match = null;
			foreach ( $candidates as $ci => $cand ) {
				if ( $max_links > 0 && $inserted_count >= $max_links ) {
					break;
				}

				$keyword = isset( $cand['keyword'] ) ? (string) $cand['keyword'] : '';
				if ( '' === $keyword ) {
					continue;
				}

				// "only first occurrence per keyword" — same keyword text wins
				// at most once across the whole post.
				$kw_key = mb_strtolower( $keyword, 'UTF-8' );
				if ( isset( $used_keywords[ $kw_key ] ) ) {
					continue;
				}

				$target_id = isset( $cand['target_id'] ) ? (int) $cand['target_id'] : 0;
				if ( $target_id <= 0 || isset( $used_targets[ $target_id ] ) ) {
					continue;
				}

				$pattern = isset( $patterns[ $ci ] ) ? (string) $patterns[ $ci ] : '';
				if ( '' === $pattern ) {
					continue;
				}
				if ( ! preg_match( $pattern, $node_text, $m, PREG_OFFSET_CAPTURE ) ) {
					continue;
				}

				$byte_offset      = (int) $m[0][1];
				$matched_text     = (string) $m[0][0];
				$prefix_substring = substr( $node_text, 0, $byte_offset );
				// PHP's DOMText::splitText() measures the offset in Unicode
				// codepoints, not UTF-16 code units: libxml stores text as UTF-8
				// and has no notion of surrogate pairs, so the argument matches
				// mb_strlen() one-for-one for every character, astral plane
				// included. The W3C DOM spec says UTF-16, but the PHP/libxml
				// implementation does not follow it — verified empirically.
				$char_offset     = mb_strlen( $prefix_substring, 'UTF-8' );
				$words_before    = self::count_words( $prefix_substring );
				$global_word_pos = $running_word_pos + $words_before;

				if ( null !== $last_word_offset
					&& ( $global_word_pos - $last_word_offset ) < $gap_words ) {
					continue;
				}

				$best_match = array(
					'cand'        => $cand,
					'char_offset' => $char_offset,
					'byte_offset' => $byte_offset,
					'node_text'   => $node_text,
					'matched'     => $matched_text,
					'word_pos'    => $global_word_pos,
				);
				break; // First successful candidate wins for this text node.
			}

			if ( null === $best_match ) {
				$running_word_pos += $node_word_count;
				continue;
			}

			$cand        = $best_match['cand'];
			$char_offset = $best_match['char_offset'];
			$matched     = $best_match['matched'];
			$keyword     = (string) $cand['keyword'];
			$target_id   = (int) $cand['target_id'];
			$permalink   = isset( $cand['permalink'] ) ? (string) $cand['permalink'] : '';
			$anchor_val  = ( isset( $cand['anchor'] ) && '' !== (string) $cand['anchor'] ) ? (string) $cand['anchor'] : '';
			$title       = isset( $cand['title'] ) ? (string) $cand['title'] : '';

			// Split the text node into [before][wrap][after]. Offsets and lengths
			// are measured in Unicode codepoints for the same reason documented
			// above where $char_offset is computed.
			//
			// By default the link wraps exactly the matched keyword and shows the
			// anchor override (or the matched text) as its visible label.
			$wrap_offset = $char_offset;
			$wrap_len    = mb_strlen( $matched, 'UTF-8' );
			$display     = '' !== $anchor_val ? $anchor_val : $matched;

			// Sentence-level anchor: when the editor picked a multi-word anchor
			// straight from the surrounding prose, wrap that real phrase instead
			// of just the keyword — otherwise the extra words would be duplicated,
			// since they already sit in the sentence. Gated hard: the anchor must
			// literally occur in THIS text node AND overlap the keyword match, so
			// an unrelated occurrence is never linked. Anything else falls back to
			// the plain display-override above — zero change for single-word or
			// keyword-equal anchors.
			if ( '' !== $anchor_val
				&& mb_strtolower( $anchor_val, 'UTF-8' ) !== mb_strtolower( $matched, 'UTF-8' ) ) {
				$node_full   = (string) $best_match['node_text'];
				$anchor_len  = mb_strlen( $anchor_val, 'UTF-8' );
				$match_start = $char_offset;
				$match_end   = $char_offset + mb_strlen( $matched, 'UTF-8' );
				// Find the anchor occurrence that overlaps THIS match, not merely
				// the first one in the node — an earlier literal occurrence (e.g. a
				// compound word) would otherwise fail the overlap test and leave the
				// trailing words duplicated in the sentence.
				$anchor_pos = mb_stripos( $node_full, $anchor_val, 0, 'UTF-8' );
				while ( false !== $anchor_pos ) {
					if ( $anchor_pos < $match_end && ( $anchor_pos + $anchor_len ) > $match_start ) {
						$wrap_offset = $anchor_pos;
						$wrap_len    = $anchor_len;
						// Real prose slice, so the visible casing matches the page.
						$display = mb_substr( $node_full, $anchor_pos, $anchor_len, 'UTF-8' );
						break;
					}
					if ( $anchor_pos >= $match_end ) {
						break;
					}
					$anchor_pos = mb_stripos( $node_full, $anchor_val, $anchor_pos + 1, 'UTF-8' );
				}
			}

			$middle_node = $text_node->splitText( $wrap_offset );
			if ( ! ( $middle_node instanceof DOMText ) ) {
				$running_word_pos += $node_word_count;
				continue;
			}

			$after_node = $middle_node->splitText( $wrap_len );

			// esc_url strips dangerous schemes (javascript:, data:) so a filter
			// hook feeding a crafted permalink cannot inject a click handler.
			$safe_href = esc_url( $permalink );
			if ( '' === $safe_href ) {
				$running_word_pos += $node_word_count;
				continue;
			}

			$link = $dom->createElement( 'a' );
			$link->setAttribute( 'href', $safe_href );
			if ( '' !== $link_class ) {
				$link->setAttribute( 'class', $link_class );
			}
			$rel_tokens = $link_rel_tokens;
			if ( '' !== $link_target ) {
				$link->setAttribute( 'target', $link_target );
				if ( '_blank' === $link_target ) {
					$rel_tokens[] = 'noopener';
					$rel_tokens[] = 'noreferrer';
				}
			}
			if ( ! empty( $rel_tokens ) ) {
				$link->setAttribute( 'rel', implode( ' ', array_unique( $rel_tokens ) ) );
			}
			if ( '' !== $title ) {
				$link->setAttribute( 'title', $title );
			}
			if ( $track_target ) {
				$link->setAttribute( 'data-sml-t', (string) $target_id );
			}
			foreach ( $extra_attrs as $attr_name => $attr_value ) {
				$attr_name = (string) $attr_name;
				// Defence-in-depth: only allow conservative attribute names and
				// reject any `on*` event handler so a compromised filter hook
				// cannot inject JavaScript through the link element.
				if ( ! preg_match( '/^[a-zA-Z][\w-]*$/', $attr_name ) ) {
					continue;
				}
				if ( 0 === stripos( $attr_name, 'on' ) ) {
					continue;
				}
				$link->setAttribute( $attr_name, (string) $attr_value );
			}
			// IMPORTANT: append the visible text as a separate text node so that
			// nothing in the keyword can be interpreted as HTML.
			$link->appendChild( $dom->createTextNode( $display ) );

			$middle_node->parentNode->replaceChild( $link, $middle_node ); // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM property fixed by PHP core.

			// Capture a short surrounding snippet (≈40 chars each side, within the
			// same text node) so the review UI can show where the link lands.
			$ctx_byte   = (int) $best_match['byte_offset'];
			$ctx_source = (string) $best_match['node_text'];
			$ctx_before = (string) substr( $ctx_source, 0, $ctx_byte );
			$ctx_after  = (string) substr( $ctx_source, $ctx_byte + strlen( $matched ) );

			$inserted[] = array(
				'target_id' => $target_id,
				'keyword'   => $keyword,
				'anchor'    => $display,
				// Word index of the match in the source prose — lets the sweep
				// give links that land early in the content a small ranking bonus
				// (Reasonable Surfer). Purely informational; scanning is unaffected.
				'word_pos'  => (int) $best_match['word_pos'],
				'context'   => array(
					'b' => ltrim( mb_substr( $ctx_before, -40, null, 'UTF-8' ) ),
					'm' => $matched,
					'a' => rtrim( mb_substr( $ctx_after, 0, 40, 'UTF-8' ) ),
				),
			);
			++$inserted_count;
			if ( $block_key ) {
				$para_counts[ $block_key ] = ( isset( $para_counts[ $block_key ] ) ? $para_counts[ $block_key ] : 0 ) + 1;
			}
			$used_targets[ $target_id ]                          = true;
			$used_keywords[ mb_strtolower( $keyword, 'UTF-8' ) ] = true;
			$last_word_offset                                    = $best_match['word_pos'];

			// Word counter must reflect the original text node we just consumed,
			// then advance through the trailing portion (after_node).
			$running_word_pos += $node_word_count;
			unset( $after_node );
		}

		$html = self::serialize_wrapper( $dom, $xpath, $content );

		return array(
			'html'       => $html,
			'inserted'   => $inserted,
			// Total prose words walked — the denominator for a match's relative
			// position (word_pos / word_total) when scoring suggestions.
			'word_total' => (int) $running_word_pos,
		);
	}

	/**
	 * Count Unicode words in a string.
	 *
	 * Used both for the per-page word budget and the inter-link gap calculation.
	 *
	 * @since 1.0.0
	 * @param string $text Text fragment.
	 * @return int
	 */
	public static function count_words( $text ) {
		$text = (string) $text;
		if ( '' === $text ) {
			return 0;
		}
		if ( preg_match_all( '/[\p{L}\p{N}]+/u', $text, $m ) ) {
			return count( $m[0] );
		}
		return 0;
	}

	/**
	 * Tag names treated as a "paragraph" unit for the per-paragraph link cap.
	 *
	 * @var array<int, string>
	 */
	const PARAGRAPH_ELEMENTS = array(
		'p',
		'li',
		'dd',
		'dt',
		'td',
		'th',
		'blockquote',
		'figcaption',
		'caption',
		'div',
		'section',
		'article',
		'aside',
	);

	/**
	 * Find the nearest block-level ancestor that counts as one paragraph.
	 *
	 * Walks up from a text node to the first PARAGRAPH_ELEMENTS ancestor. Since
	 * `div` is in that set and scan() always wraps the content in a `<div>`,
	 * text with no block markup of its own resolves to that wrapper — so it
	 * still shares a single counter. The parent fallback only matters if a
	 * caller ever runs this against an unwrapped fragment.
	 *
	 * @since 1.0.0
	 * @param DOMNode $node Text node.
	 * @return DOMNode|null Block ancestor, or null if none.
	 */
	private static function paragraph_ancestor( DOMNode $node ) {
		$cur = $node->parentNode; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM property fixed by PHP core.
		while ( $cur instanceof DOMElement ) {
			if ( in_array( strtolower( $cur->tagName ), self::PARAGRAPH_ELEMENTS, true ) ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM property fixed by PHP core.
				return $cur;
			}
			$cur = $cur->parentNode; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM property fixed by PHP core.
		}
		return $node->parentNode instanceof DOMNode ? $node->parentNode : null; // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM property fixed by PHP core.
	}

	/**
	 * Build the full match regex for a keyword and its synonyms.
	 *
	 * Each variant (the keyword plus any synonyms) becomes a morphological body
	 * from MVweb_SML_Stemmer; all variants are folded into one alternation and
	 * wrapped in word-boundary lookarounds with case-insensitive Unicode flags,
	 * so a single link can fire on whichever variant the prose actually uses.
	 * Falls back to a literal match if the stemmer is unavailable, so the
	 * scanner keeps working even if the class fails to load.
	 *
	 * @since 1.0.0
	 * @param string|string[] $keywords Raw keyword, or a list of keyword + synonyms.
	 * @return string Complete regex including delimiters and flags, or '' if empty.
	 */
	public static function build_keyword_pattern( $keywords ) {
		$variants = is_array( $keywords ) ? $keywords : array( $keywords );

		$bodies = array();
		$seen   = array();
		foreach ( $variants as $variant ) {
			$variant = trim( (string) $variant );
			if ( '' === $variant ) {
				continue;
			}
			$key = mb_strtolower( $variant, 'UTF-8' );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;

			if ( class_exists( 'MVweb_SML_Stemmer' ) ) {
				$body = MVweb_SML_Stemmer::build_morph_pattern( $variant );
			} else {
				$body = preg_quote( $variant, '/' );
			}
			if ( '' === $body ) {
				$body = preg_quote( $variant, '/' );
			}
			$bodies[] = $body;
		}

		if ( empty( $bodies ) ) {
			return '';
		}

		// Longest-first so a short variant («диван») does not match and stop
		// before a longer overlapping one («диван кровать») gets its chance.
		usort(
			$bodies,
			static function ( $a, $b ) {
				return strlen( $b ) <=> strlen( $a );
			}
		);

		$alternation = count( $bodies ) > 1 ? '(?:' . implode( '|', $bodies ) . ')' : $bodies[0];

		return '/(?<![\p{L}\p{N}])' . $alternation . '(?![\p{L}\p{N}])/iu';
	}

	/**
	 * Serialize the modified document, stripping the wrapper we injected.
	 *
	 * @since 1.0.0
	 * @param DOMDocument $dom      Document instance.
	 * @param DOMXPath    $xpath    Pre-built XPath helper.
	 * @param string      $fallback Original content to return on failure.
	 * @return string
	 */
	private static function serialize_wrapper( DOMDocument $dom, DOMXPath $xpath, $fallback ) {
		$wrap = $xpath->query( '//div[@class="mvweb-sml-wrap"]' );
		if ( ! $wrap || 0 === $wrap->length ) {
			$html = (string) $dom->saveHTML();
			$html = preg_replace( '/^<\?xml[^>]+\?>\s*/', '', $html );
			return null === $html ? $fallback : $html;
		}

		$wrap_node = $wrap->item( 0 );
		$html      = '';
		foreach ( $wrap_node->childNodes as $child ) { // phpcs:ignore WordPress.NamingConventions.ValidVariableName.UsedPropertyNotSnakeCase -- DOM property fixed by PHP core.
			$piece = $dom->saveHTML( $child );
			if ( false !== $piece ) {
				$html .= $piece;
			}
		}

		return '' === $html ? $fallback : $html;
	}
}
