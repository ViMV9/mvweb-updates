<?php
/**
 * Helper functions for MVweb Smart Links
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Maximum number of rows accepted in a single CSV import.
 *
 * Guards against OOM on huge files — rows beyond this limit are ignored.
 *
 * @since 1.0.0
 */
if ( ! defined( 'MVWEB_SML_CSV_MAX_ROWS' ) ) {
	define( 'MVWEB_SML_CSV_MAX_ROWS', 10000 );
}

/**
 * Escape a single CSV cell against Formula Injection.
 *
 * Prepends a leading apostrophe if the value starts with a character that
 * spreadsheet software may interpret as a formula (`=`, `+`, `-`, `@`) or with
 * a leading control character (tab, carriage return, vertical tab, form feed)
 * which some importers strip — exposing a formula trigger underneath.
 *
 * @since 1.0.0
 * @param mixed $value Raw cell value.
 * @return string Escaped value safe for fputcsv.
 */
function mvweb_sml_csv_escape( $value ) {
	$value = (string) $value;
	if ( '' === $value ) {
		return $value;
	}
	$first = $value[0];
	if ( in_array( $first, array( '=', '+', '-', '@', "\t", "\r", "\x0B", "\x0C" ), true ) ) {
		$value = "'" . $value;
	}
	return $value;
}

/**
 * Get fully-qualified custom table name for this plugin.
 *
 * @since 1.0.0
 * @param string $name Logical table name (e.g. 'keywords', 'links').
 * @return string Full table name including WP table prefix.
 */
function mvweb_sml_table( $name ) {
	global $wpdb;
	return $wpdb->prefix . 'mvweb_sml_' . $name;
}

/**
 * Get plugin option with default value.
 *
 * @since 1.0.0
 * @param string $key     Option key.
 * @param mixed  $default_value Default value.
 * @return mixed Option value.
 */
function mvweb_sml_get_option( $key, $default_value = '' ) {
	return get_option( 'mvweb_sml_' . $key, $default_value );
}

/**
 * Update plugin option.
 *
 * @since 1.0.0
 * @param string $key   Option key.
 * @param mixed  $value Option value.
 * @return bool True if updated, false otherwise.
 */
function mvweb_sml_update_option( $key, $value ) {
	return update_option( 'mvweb_sml_' . $key, $value );
}

/**
 * Delete plugin option.
 *
 * @since 1.0.0
 * @param string $key Option key.
 * @return bool True if deleted, false otherwise.
 */
function mvweb_sml_delete_option( $key ) {
	return delete_option( 'mvweb_sml_' . $key );
}

/**
 * Check if feature is enabled.
 *
 * @since 1.0.0
 * @param string $feature Feature name.
 * @return bool True if enabled, false otherwise.
 */
function mvweb_sml_is_enabled( $feature ) {
	return (bool) mvweb_sml_get_option( $feature . '_enable', false );
}

/**
 * Write a debug log entry when WP_DEBUG is enabled.
 *
 * @since 1.0.0
 * @param string $msg   Message to log.
 * @param string $level Severity level (info|warning|error).
 * @return void
 */
function mvweb_sml_log( $msg, $level = 'info' ) {
	if ( ! defined( 'WP_DEBUG' ) || ! WP_DEBUG ) {
		return;
	}

	if ( ! is_scalar( $msg ) ) {
		$msg = wp_json_encode( $msg );
	}

	// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Gated behind WP_DEBUG.
	error_log( sprintf( '[mvweb-sml][%s] %s', $level, $msg ) );
}

/**
 * Read a single key from the unified plugin settings array.
 *
 * Thin wrapper around MVweb_SML_Settings::get() so that helper code does not
 * need to know about the class name.
 *
 * @since 1.0.0
 * @param string|null $key           Key inside the settings array. Null returns the full array.
 * @param mixed       $default_value Value returned if the key is missing.
 * @return mixed
 */
function mvweb_sml_get_setting( $key = null, $default_value = null ) {
	if ( ! class_exists( 'MVweb_SML_Settings' ) ) {
		return $default_value;
	}

	$value = MVweb_SML_Settings::get( $key );

	if ( null === $value && null !== $default_value ) {
		return $default_value;
	}

	return $value;
}

/**
 * Get the list of post types the plugin should operate on.
 *
 * Reads the `post_types` setting and validates each value via post_type_exists().
 * Filterable via `mvweb_sml_post_types`.
 *
 * @since 1.0.0
 * @return array<int, string>
 */
function mvweb_sml_supported_post_types() {
	$configured = mvweb_sml_get_setting( 'post_types', array( 'post', 'page' ) );

	if ( ! is_array( $configured ) ) {
		$configured = array( 'post', 'page' );
	}

	$valid = array();
	foreach ( $configured as $pt ) {
		$pt = sanitize_key( $pt );
		if ( '' !== $pt && post_type_exists( $pt ) ) {
			$valid[] = $pt;
		}
	}

	/**
	 * Filter the list of post types Smart Links operates on.
	 *
	 * @since 1.0.0
	 * @param array $valid Validated post type slugs.
	 */
	return apply_filters( 'mvweb_sml_post_types', array_values( array_unique( $valid ) ) );
}

/**
 * Locate a template file for the related posts block.
 *
 * Lookup order:
 *   1. Active theme (and child theme) via `locate_template( "mvweb-smart-links/{$name}" )`.
 *   2. Plugin's bundled templates directory (`templates/{$name}`).
 *
 * @since 1.0.0
 * @param string $name Template filename (for example `related-list.php`).
 * @return string Absolute path to the resolved template, or empty string if nothing matched.
 */
function mvweb_sml_locate_template( $name ) {
	$name = ltrim( (string) $name, '/' );
	if ( '' === $name ) {
		return '';
	}

	$theme = locate_template( array( 'mvweb-smart-links/' . $name ) );
	if ( '' !== $theme && file_exists( $theme ) ) {
		return $theme;
	}

	$plugin = MVWEB_SML_PATH . 'templates/' . $name;
	if ( file_exists( $plugin ) ) {
		return $plugin;
	}

	return '';
}

/**
 * Whether a post is excluded as a link source on the front end.
 *
 * Single source of truth for the per-post opt-out and the three global
 * blacklists (post IDs, URL glob patterns, taxonomy terms). Shared by the
 * contextual linker and the "Read also" related block so both honour the
 * exact same exclusions — a post the editor removed from automatic linking
 * gets neither contextual links nor a related block.
 *
 * @since 1.0.0
 * @param int    $post_id   Source post ID.
 * @param string $post_type Post type (optional; resolved if omitted).
 * @return bool True when the post must be skipped.
 */
function mvweb_sml_is_source_excluded( $post_id, $post_type = '' ) {
	$post_id = (int) $post_id;
	if ( $post_id <= 0 ) {
		return true;
	}

	// Per-post opt-out via metabox.
	if ( '1' === (string) get_post_meta( $post_id, '_mvweb_sml_disabled', true ) ) {
		return true;
	}

	// Global blacklist by ID.
	$disabled_ids = (array) mvweb_sml_get_setting( 'disabled_post_ids', array() );
	if ( in_array( $post_id, array_map( 'intval', $disabled_ids ), true ) ) {
		return true;
	}

	// Global blacklist by URL pattern (fnmatch glob).
	$disabled_patterns = (array) mvweb_sml_get_setting( 'disabled_url_patterns', array() );
	if ( ! empty( $disabled_patterns ) && function_exists( 'fnmatch' ) ) {
		$permalink = (string) get_permalink( $post_id );
		foreach ( $disabled_patterns as $pattern ) {
			$pattern = (string) $pattern;
			if ( '' !== $pattern && fnmatch( $pattern, $permalink ) ) {
				return true;
			}
		}
	}

	// Global blacklist by taxonomy term.
	$disabled_terms = array_map( 'intval', (array) mvweb_sml_get_setting( 'disabled_terms', array() ) );
	if ( ! empty( $disabled_terms ) ) {
		if ( '' === $post_type ) {
			$post_type = (string) get_post_type( $post_id );
		}
		$taxonomies = get_object_taxonomies( $post_type );
		if ( ! empty( $taxonomies ) ) {
			$post_terms = wp_get_object_terms( $post_id, $taxonomies, array( 'fields' => 'ids' ) );
			if ( ! is_wp_error( $post_terms ) && array_intersect( $disabled_terms, array_map( 'intval', $post_terms ) ) ) {
				return true;
			}
		}
	}

	return false;
}
