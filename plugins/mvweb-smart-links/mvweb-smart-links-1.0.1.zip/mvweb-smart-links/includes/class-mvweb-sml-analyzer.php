<?php
/**
 * Content analyzer: extract text, tokenize, score prominent words.
 *
 * Pure functions, no DB access. The Indexer is responsible for persistence.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Analyzer
 *
 * Frequency-based prominent word extractor. The first version intentionally
 * skips tf/idf — frequency is good enough for the metabox "Suggest keywords"
 * helper and for the Related block. tf/idf can be added later without
 * breaking the public interface (see plan §Phase 5).
 *
 * @since 1.0.0
 */
class MVweb_SML_Analyzer {

	/**
	 * Cached stop-word lookup table (key => true).
	 *
	 * @var array<string, bool>|null
	 */
	private static $stopwords = null;

	/**
	 * Minimum token length, in characters (multibyte-aware).
	 */
	const MIN_TOKEN_LENGTH = 3;

	/**
	 * Load and cache the stop-word lookup table.
	 *
	 * @since 1.0.0
	 * @return array<string, bool>
	 */
	private static function get_stopwords() {
		if ( null !== self::$stopwords ) {
			return self::$stopwords;
		}

		$file = MVWEB_SML_PATH . 'includes/data/stopwords.php';
		$list = file_exists( $file ) ? include $file : array();

		if ( ! is_array( $list ) ) {
			$list = array();
		}

		// Flip to enable O(1) isset() lookups.
		self::$stopwords = array_fill_keys( array_map( 'strval', $list ), true );

		return self::$stopwords;
	}

	/**
	 * Extract plain text from a post's content (no shortcodes, no HTML).
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return string Plain text. Empty string if the post has no content.
	 */
	public static function extract_text( $post_id ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return '';
		}

		$content = get_post_field( 'post_content', $post_id );
		if ( ! is_string( $content ) || '' === $content ) {
			return '';
		}

		$content = strip_shortcodes( $content );
		$content = wp_strip_all_tags( $content );
		// Decode entities (&laquo;, &mdash;, …) so they don't survive as junk
		// tokens like "laquo" after the non-letter split in tokenize().
		$content = html_entity_decode( $content, ENT_QUOTES, 'UTF-8' );

		return $content;
	}

	/**
	 * Tokenize plain text into normalized lowercase tokens.
	 *
	 * Uses Unicode-aware splitting (`\p{L}\p{N}` with `/u`) so cyrillic and
	 * other non-ASCII alphabets are handled the same as ASCII. Filters
	 * stop-words, short tokens and pure-numeric tokens.
	 *
	 * @since 1.0.0
	 * @param string $text Plain text input.
	 * @return array<int, string> Sequence of tokens (with duplicates).
	 */
	public static function tokenize( $text ) {
		if ( ! is_string( $text ) || '' === $text ) {
			return array();
		}

		$text = mb_strtolower( $text, 'UTF-8' );

		$matches = array();
		preg_match_all( '/[\p{L}\p{N}]+/u', $text, $matches );

		if ( empty( $matches[0] ) ) {
			return array();
		}

		$stopwords = self::get_stopwords();
		$tokens    = array();

		foreach ( $matches[0] as $token ) {
			if ( mb_strlen( $token, 'UTF-8' ) < self::MIN_TOKEN_LENGTH ) {
				continue;
			}
			if ( ctype_digit( $token ) ) {
				continue;
			}
			if ( isset( $stopwords[ $token ] ) ) {
				continue;
			}
			$tokens[] = $token;
		}

		return $tokens;
	}

	/**
	 * Score prominent words by raw frequency.
	 *
	 * Returns an associative array of `word => count`, sorted by count
	 * descending, trimmed to `$top` entries.
	 *
	 * @since 1.0.0
	 * @param array<int, string> $tokens Tokenized words.
	 * @param int                $top    Maximum entries to return.
	 * @return array<string, int>
	 */
	public static function prominent_words( array $tokens, $top = 30 ) {
		if ( empty( $tokens ) ) {
			return array();
		}

		$counts = array_count_values( $tokens );
		arsort( $counts, SORT_NUMERIC );

		$top = max( 1, (int) $top );
		if ( count( $counts ) > $top ) {
			$counts = array_slice( $counts, 0, $top, true );
		}

		return $counts;
	}

	/**
	 * Convenience helper used by the editor metabox (phase 6).
	 *
	 * Combines extract → tokenize → prominent_words and returns an indexed
	 * list of words (no counts) ready for an autocomplete suggestion.
	 *
	 * @since 1.0.0
	 * @param int                 $post_id Post ID.
	 * @param int                 $limit   Maximum suggestions to return.
	 * @param array<string, bool> $exclude Words to drop (e.g. corpus-generic
	 *                                     filler), as a word => true lookup.
	 * @return array<int, string>
	 */
	public static function suggest_keywords( $post_id, $limit = 10, array $exclude = array() ) {
		$text   = self::extract_text( $post_id );
		$tokens = self::tokenize( $text );
		$limit  = max( 1, (int) $limit );

		// Over-fetch, then drop corpus-generic words so suggestions favour
		// distinctive topical terms over high-frequency filler.
		$words = self::prominent_words( $tokens, $limit * 4 );

		if ( ! empty( $exclude ) ) {
			$words = array_diff_key( $words, $exclude );
		}

		return array_slice( array_keys( $words ), 0, $limit );
	}
}
