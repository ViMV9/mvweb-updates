<?php
/**
 * CSV import / export for the plugin keywords table.
 *
 * Format (both directions):
 *
 *     post_id,keyword,synonyms
 *
 * Where `synonyms` is a single cell with entries separated by a semicolon.
 *
 * Every exported cell is passed through `mvweb_sml_csv_escape()` to defuse
 * spreadsheet formula injection; every imported row is validated per-field
 * against the same rules the metabox uses.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_CSV
 *
 * @since 1.0.0
 */
class MVweb_SML_CSV {

	/**
	 * Import keywords from a CSV file on disk.
	 *
	 * Each row is independently validated — a bad row is skipped (counted in
	 * `errors`) and does not abort the rest of the import.
	 *
	 * Rows beyond `MVWEB_SML_CSV_MAX_ROWS` are silently dropped so an
	 * arbitrarily large file cannot OOM the process.
	 *
	 * @since 1.0.0
	 * @param string $file_path Absolute path to an already-validated upload.
	 * @return array{imported:int, errors:int, skipped:int}
	 */
	public static function import( $file_path ) {
		$result = array(
			'imported' => 0,
			'errors'   => 0,
			'skipped'  => 0,
		);

		if ( ! is_string( $file_path ) || '' === $file_path || ! file_exists( $file_path ) ) {
			return $result;
		}
		if ( ! class_exists( 'MVweb_SML_Keyword_Manager' ) ) {
			return $result;
		}

		// Streaming CSV reader — `WP_Filesystem` has no row-wise API, so
		// the classic fopen/fgetcsv pair is the only reasonable choice.
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.WP.AlternativeFunctions.file_system_read_fopen
		$handle = fopen( $file_path, 'r' );
		if ( false === $handle ) {
			return $result;
		}

		// Strip UTF-8 BOM if present so the header row is detected correctly
		// on a round-trip (our own export() writes a BOM for Excel Cyrillic).
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fread
		$bom = fread( $handle, 3 );
		if ( "\xEF\xBB\xBF" !== $bom ) {
			rewind( $handle );
		}

		$data_rows = 0;
		$max_rows  = defined( 'MVWEB_SML_CSV_MAX_ROWS' ) ? (int) MVWEB_SML_CSV_MAX_ROWS : 10000;
		$first     = true;

		// phpcs:ignore Generic.CodeAnalysis.AssignmentInCondition.FoundInWhileCondition
		while ( ( $row = fgetcsv( $handle ) ) !== false ) {
			// Skip obvious header row (`post_id,keyword,...`) — counter
			// only advances for data rows, so the max_rows limit is
			// exact (no off-by-one caused by the header).
			if ( $first ) {
				$first = false;
				if ( isset( $row[0] ) && 'post_id' === strtolower( trim( (string) $row[0] ) ) ) {
					continue;
				}
			}

			++$data_rows;

			// Defensive stop — avoid OOM on absurdly large uploads.
			if ( $data_rows > $max_rows ) {
				break;
			}

			// Need at least post_id + keyword.
			if ( ! is_array( $row ) || ! isset( $row[0], $row[1] ) ) {
				++$result['errors'];
				continue;
			}

			$post_id = absint( $row[0] );
			if ( $post_id <= 0 || ! get_post( $post_id ) ) {
				++$result['skipped'];
				continue;
			}

			// Per-post capability check — matches the metabox/cluster
			// IDOR protection pattern used elsewhere in the plugin.
			if ( ! current_user_can( 'edit_post', $post_id ) ) {
				++$result['skipped'];
				continue;
			}

			$keyword = sanitize_text_field( (string) $row[1] );
			if ( '' === $keyword || mb_strlen( $keyword, 'UTF-8' ) > 255 ) {
				++$result['skipped'];
				continue;
			}

			$synonyms_raw = (string) ( $row[2] ?? '' );
			$synonyms     = array_values(
				array_filter(
					array_map( 'sanitize_text_field', explode( ';', $synonyms_raw ) ),
					static function ( $item ) {
						return '' !== $item;
					}
				)
			);

			$id = MVweb_SML_Keyword_Manager::add( $post_id, $keyword, $synonyms, 'manual' );
			if ( $id ) {
				++$result['imported'];
			} else {
				++$result['errors'];
			}
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		fclose( $handle );

		return $result;
	}

	/**
	 * Stream every keyword row in the plugin table as a CSV download.
	 *
	 * Exits after the stream is flushed — callers should not expect
	 * control to return.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function export() {
		global $wpdb;

		$table = mvweb_sml_table( 'keywords' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT post_id, keyword, synonyms FROM %i ORDER BY post_id ASC, id ASC',
				$table
			),
			ARRAY_A
		);

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="mvweb-sml-keywords-' . gmdate( 'Y-m-d' ) . '.csv"' );

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.WP.AlternativeFunctions.file_system_read_fopen
		$out = fopen( 'php://output', 'w' );
		if ( false === $out ) {
			exit;
		}

		// UTF-8 BOM for Excel Cyrillic rendering.
		echo "\xEF\xBB\xBF"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		$headers = array(
			mvweb_sml_csv_escape( 'post_id' ),
			mvweb_sml_csv_escape( 'keyword' ),
			mvweb_sml_csv_escape( 'synonyms' ),
		);
		fputcsv( $out, $headers );

		foreach ( (array) $rows as $row ) {
			$synonyms = self::decode_synonyms_to_string( $row['synonyms'] ?? '' );

			$line = array(
				mvweb_sml_csv_escape( (int) $row['post_id'] ),
				mvweb_sml_csv_escape( (string) $row['keyword'] ),
				mvweb_sml_csv_escape( $synonyms ),
			);
			fputcsv( $out, $line );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		fclose( $out );
		exit;
	}

	/**
	 * Flatten the JSON-encoded synonyms column into a `;`-joined string.
	 *
	 * @since 1.0.0
	 * @param string $raw Raw column value.
	 * @return string
	 */
	private static function decode_synonyms_to_string( $raw ) {
		if ( ! is_string( $raw ) || '' === $raw ) {
			return '';
		}

		$decoded = json_decode( $raw, true );
		if ( ! is_array( $decoded ) ) {
			return '';
		}

		$out = array();
		foreach ( $decoded as $item ) {
			if ( is_scalar( $item ) ) {
				$out[] = (string) $item;
			}
		}

		return implode( ';', $out );
	}
}
