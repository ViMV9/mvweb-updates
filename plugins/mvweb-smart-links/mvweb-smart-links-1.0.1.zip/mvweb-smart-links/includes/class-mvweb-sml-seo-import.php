<?php
/**
 * SEO plugin importer: Yoast / Rank Math / AIOSEO focus keywords → `_keywords`.
 *
 * Detection is based purely on the presence of the corresponding postmeta
 * row — no plugin classes are introspected, so a deactivated SEO plugin
 * whose data still lives in the database remains importable.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_SEO_Import
 *
 * @since 1.0.0
 */
class MVweb_SML_SEO_Import {

	/**
	 * Map of source slug → postmeta key used to detect / query records.
	 *
	 * @var array<string, string>
	 */
	const META_KEYS = array(
		'yoast'    => '_yoast_wpseo_focuskw',
		'rankmath' => 'rank_math_focus_keyword',
		'aioseo'   => '_aioseo_keyphrases',
	);

	/**
	 * Detect how many posts in the database carry focus-keyword data for
	 * each supported SEO plugin.
	 *
	 * Uses a single `EXISTS`-style `COUNT` query per source. Rows with an
	 * empty string are excluded.
	 *
	 * @since 1.0.0
	 * @return array<string, int> Map of source slug → post count.
	 */
	public static function detect() {
		global $wpdb;

		$out = array();
		foreach ( self::META_KEYS as $source => $meta_key ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$count          = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(DISTINCT post_id) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value <> ''",
					$meta_key
				)
			);
			$out[ $source ] = (int) $count;
		}

		return $out;
	}

	/**
	 * Import focus keywords from the given source into the plugin's
	 * `_keywords` table.
	 *
	 * @since 1.0.0
	 * @param string $source One of `yoast`, `rankmath`, `aioseo`.
	 * @return array{imported:int, skipped:int, total:int}
	 */
	public static function import( $source ) {
		$result = array(
			'imported' => 0,
			'skipped'  => 0,
			'total'    => 0,
		);

		if ( ! isset( self::META_KEYS[ $source ] ) ) {
			return $result;
		}
		if ( ! class_exists( 'MVweb_SML_Keyword_Manager' ) ) {
			return $result;
		}

		$meta_key   = self::META_KEYS[ $source ];
		$post_types = mvweb_sml_supported_post_types();
		if ( empty( $post_types ) ) {
			return $result;
		}

		$paged = 1;
		do {
			$query = new WP_Query(
				array(
					'post_type'              => $post_types,
					'post_status'            => array( 'publish', 'draft', 'pending', 'future', 'private' ),
					'posts_per_page'         => 100,
					'paged'                  => $paged,
					'fields'                 => 'ids',
					'no_found_rows'          => true,
					'update_post_term_cache' => false,
					'update_post_meta_cache' => false,
					'ignore_sticky_posts'    => true,
					// phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					'meta_query'             => array(
						array(
							'key'     => $meta_key,
							'compare' => 'EXISTS',
						),
						array(
							'key'     => $meta_key,
							'value'   => '',
							'compare' => '!=',
						),
					),
				)
			);

			if ( empty( $query->posts ) ) {
				break;
			}

			foreach ( $query->posts as $post_id ) {
				++$result['total'];
				$raw = get_post_meta( (int) $post_id, $meta_key, true );
				$kw  = self::extract_keyword( $source, $raw );
				if ( '' === $kw ) {
					++$result['skipped'];
					continue;
				}

				$id = MVweb_SML_Keyword_Manager::add( (int) $post_id, $kw, array(), $source );
				if ( $id ) {
					++$result['imported'];
				} else {
					++$result['skipped'];
				}
			}

			// Short page = last page. Exit without a second round-trip.
			if ( count( $query->posts ) < 100 ) {
				break;
			}
			++$paged;
		} while ( true );

		wp_reset_postdata();

		return $result;
	}

	/**
	 * Normalise raw postmeta into a keyword string.
	 *
	 * Yoast and Rank Math store a plain string; AIOSEO stores JSON with a
	 * `focus.keyphrase` shape (plus optional additional keyphrases we ignore
	 * here — users can move those over manually).
	 *
	 * @since 1.0.0
	 * @param string $source Source slug.
	 * @param mixed  $raw    Raw postmeta value.
	 * @return string Clean keyword, or empty string when nothing usable.
	 */
	private static function extract_keyword( $source, $raw ) {
		if ( 'aioseo' === $source ) {
			if ( ! is_string( $raw ) || '' === $raw ) {
				return '';
			}
			$decoded = json_decode( $raw, true );
			if ( ! is_array( $decoded ) ) {
				return '';
			}
			if ( isset( $decoded['focus']['keyphrase'] ) && is_string( $decoded['focus']['keyphrase'] ) ) {
				return sanitize_text_field( $decoded['focus']['keyphrase'] );
			}
			return '';
		}

		if ( ! is_scalar( $raw ) ) {
			return '';
		}

		return sanitize_text_field( (string) $raw );
	}
}
