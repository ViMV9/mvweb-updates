<?php
/**
 * Import search-query data (Google Search Console / Yandex Webmaster) as keywords.
 *
 * The plugin never calls the external APIs itself — that would require per-site
 * OAuth secrets and break the "no SaaS / no external calls" positioning. Instead
 * the editor pastes (or the CLI feeds) the queries a page already ranks for, and
 * this class filters them by the "growth point" heuristic — search position in a
 * window (default 4–20) and a minimum impressions threshold — then stores the
 * survivors as keywords against the target post. Those become anchor candidates
 * for interlinking, strengthening pages that rank but under-perform on CTR.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Query_Import
 *
 * @since 1.0.0
 */
class MVweb_SML_Query_Import {

	/**
	 * Hard cap on rows processed from a single paste / CSV import.
	 */
	const MAX_ROWS = 5000;

	/**
	 * Sources this importer may tag keywords with.
	 *
	 * @var array
	 */
	const ALLOWED_SOURCES = array( 'gsc', 'yandex' );

	/**
	 * Parse a pasted block of query rows into structured rows.
	 *
	 * Accepts one query per line. Extra columns (position, impressions) may be
	 * separated by tab, semicolon or comma — tab first, because copying straight
	 * from a GSC / Webmaster table yields tab-separated cells. Column order is
	 * `query, position, impressions`. A leading header row (non-numeric position
	 * cell) is skipped. Missing metrics stay null so the caller can decide
	 * whether to filter on them.
	 *
	 * @since 1.0.0
	 * @param string $raw Raw pasted text.
	 * @return array<int, array{query:string, position:?float, impressions:?int}>
	 */
	public static function parse_rows( $raw ) {
		$raw   = (string) $raw;
		$lines = preg_split( '/\r\n|\r|\n/', $raw );
		$rows  = array();
		$first = true;

		foreach ( (array) $lines as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}

			if ( false !== strpos( $line, "\t" ) ) {
				$delim = "\t";
			} elseif ( false !== strpos( $line, ';' ) ) {
				$delim = ';';
			} elseif ( false !== strpos( $line, ',' ) ) {
				$delim = ',';
			} else {
				$delim = "\t";
			}

			$cols  = array_map( 'trim', explode( $delim, $line ) );
			$query = isset( $cols[0] ) ? $cols[0] : '';

			$position    = null;
			$impressions = null;

			if ( isset( $cols[1] ) && '' !== $cols[1] ) {
				// RU exports use a decimal comma; normalise unless comma is the
				// column delimiter (then the value cannot carry a decimal comma).
				$pos_raw = ( ',' !== $delim ) ? str_replace( ',', '.', $cols[1] ) : $cols[1];
				if ( is_numeric( $pos_raw ) ) {
					$position = (float) $pos_raw;
				}
			}

			if ( isset( $cols[2] ) && '' !== $cols[2] ) {
				// Strip thousands separators (spaces / non-breaking spaces).
				$imp_raw = str_replace( array( ' ', "\xC2\xA0" ), '', $cols[2] );
				if ( is_numeric( $imp_raw ) ) {
					$impressions = (int) $imp_raw;
				}
			}

			// Skip a header row: the first line whose second column exists but is
			// not numeric is a label row ("Query;Position;Impressions").
			if ( $first ) {
				$first = false;
				if ( isset( $cols[1] ) && '' !== $cols[1] && null === $position ) {
					continue;
				}
			}

			if ( '' === $query ) {
				continue;
			}

			$rows[] = array(
				'query'       => $query,
				'position'    => $position,
				'impressions' => $impressions,
			);

			if ( count( $rows ) >= self::MAX_ROWS ) {
				break;
			}
		}

		return $rows;
	}

	/**
	 * Filter parsed rows and store the survivors as keywords on a post.
	 *
	 * A row is skipped when a known metric fails the growth-point window: its
	 * position is outside [min_position, max_position], or its impressions are
	 * below min_impressions. Rows missing a metric are not filtered on it.
	 *
	 * @since 1.0.0
	 * @param int    $post_id Target post the queries belong to.
	 * @param array  $rows    Parsed rows from parse_rows().
	 * @param string $source  'gsc' or 'yandex'.
	 * @param array  $opts    min_position, max_position, min_impressions.
	 * @return array{imported:int, skipped_filter:int, skipped_dup:int, total:int}
	 */
	public static function import_for_post( $post_id, array $rows, $source, array $opts = array() ) {
		$post_id = (int) $post_id;
		$source  = in_array( $source, self::ALLOWED_SOURCES, true ) ? $source : 'gsc';

		$min_pos  = isset( $opts['min_position'] ) ? (float) $opts['min_position'] : 0.0;
		$max_pos  = isset( $opts['max_position'] ) ? (float) $opts['max_position'] : 100.0;
		$min_impr = isset( $opts['min_impressions'] ) ? max( 0, (int) $opts['min_impressions'] ) : 0;

		$stats = array(
			'imported'       => 0,
			'skipped_filter' => 0,
			'skipped_dup'    => 0,
			'total'          => count( $rows ),
		);

		if ( $post_id <= 0 || ! class_exists( 'MVweb_SML_Keyword_Manager' ) ) {
			return $stats;
		}

		// Snapshot existing keywords once so duplicate counting is a set lookup,
		// not a query per row.
		$existing = array();
		foreach ( MVweb_SML_Keyword_Manager::get_for_post( $post_id ) as $kw ) {
			$existing[ mb_strtolower( $kw['keyword'], 'UTF-8' ) ] = true;
		}

		foreach ( $rows as $row ) {
			$query = isset( $row['query'] ) ? trim( (string) $row['query'] ) : '';
			if ( '' === $query ) {
				continue;
			}

			$position    = isset( $row['position'] ) ? $row['position'] : null;
			$impressions = isset( $row['impressions'] ) ? $row['impressions'] : null;

			if ( null !== $position && ( $position < $min_pos || $position > $max_pos ) ) {
				++$stats['skipped_filter'];
				continue;
			}
			if ( null !== $impressions && $impressions < $min_impr ) {
				++$stats['skipped_filter'];
				continue;
			}

			$key = mb_strtolower( $query, 'UTF-8' );
			if ( isset( $existing[ $key ] ) ) {
				++$stats['skipped_dup'];
				continue;
			}

			$id = MVweb_SML_Keyword_Manager::add( $post_id, $query, array(), $source );
			if ( $id ) {
				++$stats['imported'];
				$existing[ $key ] = true;
			}
		}

		return $stats;
	}

	/**
	 * Import from a CSV file (CLI / automation path).
	 *
	 * The CSV must have a header row. Recognised columns (case-insensitive):
	 * `post_id` OR `url`/`page` (to resolve the target post), `query`, and
	 * optionally `position` and `impressions`. Rows are grouped by target post
	 * and imported through import_for_post(), so the same growth-point filter
	 * applies.
	 *
	 * @since 1.0.0
	 * @param string $path   Absolute path to the CSV file.
	 * @param string $source 'gsc' or 'yandex'.
	 * @param array  $opts   min_position, max_position, min_impressions.
	 * @return array{imported:int, skipped_filter:int, skipped_dup:int, total:int, posts:int, unresolved:int}|WP_Error
	 */
	public static function import_from_csv( $path, $source, array $opts = array() ) {
		if ( ! is_readable( $path ) ) {
			return new WP_Error( 'mvweb_sml_csv_unreadable', __( 'CSV file is not readable.', 'mvweb-smart-links' ) );
		}

		$handle = fopen( $path, 'r' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
		if ( false === $handle ) {
			return new WP_Error( 'mvweb_sml_csv_open', __( 'Could not open CSV file.', 'mvweb-smart-links' ) );
		}

		$header = fgetcsv( $handle );
		if ( ! is_array( $header ) ) {
			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			return new WP_Error( 'mvweb_sml_csv_empty', __( 'CSV file is empty.', 'mvweb-smart-links' ) );
		}

		$map = array();
		foreach ( $header as $i => $name ) {
			$map[ strtolower( trim( (string) $name ) ) ] = $i;
		}
		$col_query = isset( $map['query'] ) ? $map['query'] : null;
		if ( null === $col_query ) {
			fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
			return new WP_Error( 'mvweb_sml_csv_no_query', __( 'CSV must have a "query" column.', 'mvweb-smart-links' ) );
		}

		$col_post = isset( $map['post_id'] ) ? $map['post_id'] : null;
		$col_url  = isset( $map['url'] ) ? $map['url'] : ( isset( $map['page'] ) ? $map['page'] : null );
		$col_pos  = isset( $map['position'] ) ? $map['position'] : null;
		$col_impr = isset( $map['impressions'] ) ? $map['impressions'] : null;

		// Bucket rows by resolved post id.
		$by_post    = array();
		$unresolved = 0;
		$count      = 0;

		while ( true ) {
			$data = fgetcsv( $handle );
			if ( false === $data ) {
				break;
			}
			if ( ++$count > self::MAX_ROWS ) {
				break;
			}

			$query = isset( $data[ $col_query ] ) ? trim( (string) $data[ $col_query ] ) : '';
			if ( '' === $query ) {
				continue;
			}

			$post_id = 0;
			if ( null !== $col_post && isset( $data[ $col_post ] ) && is_numeric( $data[ $col_post ] ) ) {
				$post_id = (int) $data[ $col_post ];
			} elseif ( null !== $col_url && isset( $data[ $col_url ] ) && '' !== trim( (string) $data[ $col_url ] ) ) {
				$post_id = (int) url_to_postid( trim( (string) $data[ $col_url ] ) );
			}

			if ( $post_id <= 0 ) {
				++$unresolved;
				continue;
			}

			$position = null;
			if ( null !== $col_pos && isset( $data[ $col_pos ] ) && '' !== $data[ $col_pos ] ) {
				$pos_raw = str_replace( ',', '.', (string) $data[ $col_pos ] );
				if ( is_numeric( $pos_raw ) ) {
					$position = (float) $pos_raw;
				}
			}

			$impressions = null;
			if ( null !== $col_impr && isset( $data[ $col_impr ] ) && '' !== $data[ $col_impr ] ) {
				$imp_raw = str_replace( array( ' ', "\xC2\xA0" ), '', (string) $data[ $col_impr ] );
				if ( is_numeric( $imp_raw ) ) {
					$impressions = (int) $imp_raw;
				}
			}

			$by_post[ $post_id ][] = array(
				'query'       => $query,
				'position'    => $position,
				'impressions' => $impressions,
			);
		}

		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

		$totals = array(
			'imported'       => 0,
			'skipped_filter' => 0,
			'skipped_dup'    => 0,
			'total'          => 0,
			'posts'          => 0,
			'unresolved'     => $unresolved,
		);

		foreach ( $by_post as $post_id => $rows ) {
			$stats                     = self::import_for_post( $post_id, $rows, $source, $opts );
			$totals['imported']       += $stats['imported'];
			$totals['skipped_filter'] += $stats['skipped_filter'];
			$totals['skipped_dup']    += $stats['skipped_dup'];
			$totals['total']          += $stats['total'];
			++$totals['posts'];
		}

		return $totals;
	}
}
