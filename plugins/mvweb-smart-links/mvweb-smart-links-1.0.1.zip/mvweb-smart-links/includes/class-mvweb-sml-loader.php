<?php
/**
 * Plugin loader: explicit require_once list and hook registration.
 *
 * No autoloader — a flat, ordered include list is easier to debug, easier
 * for new contributors to read and avoids surprises around case-sensitive
 * file systems.
 *
 * IMPORTANT: every new class file under includes/, admin/ or public/ MUST
 * be appended to the list inside `init()` (and, if it carries hooks, also
 * to the hook-registration block). Without an entry here the class does
 * not exist at runtime.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loader. Wires up files and hooks for all controllers / singletons.
 *
 * @since 1.0.0
 */
class MVweb_SML_Loader {

	/**
	 * Whether init() has already run.
	 *
	 * @var bool
	 */
	private static $booted = false;

	/**
	 * Boot the plugin: include class files and register hooks.
	 *
	 * Called from the entry point on `plugins_loaded` (priority 5) so other
	 * components can hook in at the standard `init` priority.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		self::require_files();
		self::register_hooks();
	}

	/**
	 * Explicit, ordered list of every class file the plugin owns.
	 *
	 * Order matters when one class instantiates another at file scope.
	 * Files that do not yet exist (because the plan phase that creates
	 * them has not been executed) are skipped via file_exists() so the
	 * plugin keeps loading; once the file lands, the next request picks
	 * it up automatically.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function require_files() {
		$base = MVWEB_SML_PATH;

		$files = array(
			// Core infrastructure.
			'includes/class-mvweb-sml-settings.php',
			'includes/class-mvweb-sml-cache.php',
			'includes/class-mvweb-sml-i18n.php',
			'includes/class-mvweb-sml-notices.php',
			// includes/data/stopwords.php is loaded lazily by Analyzer::get_stopwords().
			'includes/class-mvweb-sml-analyzer.php',
			'includes/class-mvweb-sml-stemmer.php',
			'includes/class-mvweb-sml-dom-scanner.php',
			'includes/class-mvweb-sml-indexer.php',
			'includes/class-mvweb-sml-keyword-manager.php',
			'includes/class-mvweb-sml-cluster-manager.php',
			'includes/class-mvweb-sml-reports.php',
			'includes/class-mvweb-sml-clicks.php',
			'includes/class-mvweb-sml-dashboard-widget.php',
			'includes/class-mvweb-sml-seo-import.php',
			'includes/class-mvweb-sml-query-import.php',
			'includes/class-mvweb-sml-csv.php',
			'includes/class-mvweb-sml-rest-api.php',
			'includes/class-mvweb-sml-cli.php',

			// Admin layer.
			'admin/class-mvweb-sml-metabox.php',
			'admin/class-mvweb-sml-bulk.php',
			'admin/class-mvweb-sml-admin.php',

			// Frontend layer.
			'public/class-mvweb-sml-linker.php',
			'public/class-mvweb-sml-related.php',
			'public/class-mvweb-sml-public.php',
		);

		foreach ( $files as $rel ) {
			$path = $base . $rel;
			if ( file_exists( $path ) ) {
				require_once $path;
			}
		}
	}

	/**
	 * Register hooks for controllers and singleton classes.
	 *
	 * Each branch is wrapped in `class_exists` so partially-implemented
	 * builds keep loading. Once the corresponding phase ships its class,
	 * the hook starts firing automatically.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function register_hooks() {
		// Frontend controller.
		if ( class_exists( 'MVweb_SML_Public' ) && method_exists( 'MVweb_SML_Public', 'init' ) ) {
			add_action( 'init', array( 'MVweb_SML_Public', 'init' ) );
		}

		// Click-tracking beacon endpoint. Registered unconditionally (self-gated
		// on the track_clicks setting) so the wp_ajax handlers exist during the
		// admin-ajax.php request that front-end visitors' beacons hit.
		if ( class_exists( 'MVweb_SML_Clicks' ) && method_exists( 'MVweb_SML_Clicks', 'init' ) ) {
			MVweb_SML_Clicks::init();
		}

		// Notices need to be wired before any subsystem fires
		// `mvweb_sml_index_complete` (cron may run on the front-end too).
		if ( class_exists( 'MVweb_SML_Notices' ) && method_exists( 'MVweb_SML_Notices', 'init' ) ) {
			MVweb_SML_Notices::init();
		}

		if ( is_admin() ) {
			// Migrate the database schema on update (idempotent dbDelta) before
			// any admin screen queries the custom tables.
			if ( class_exists( 'MVweb_SML_Activator' ) && method_exists( 'MVweb_SML_Activator', 'maybe_upgrade' ) ) {
				add_action( 'admin_init', array( 'MVweb_SML_Activator', 'maybe_upgrade' ) );
			}

			// Admin::init() registers an `admin_menu` action, which runs
			// BEFORE `admin_init`. Calling it directly here (we are already
			// on plugins_loaded) keeps the menu registration in time.
			if ( class_exists( 'MVweb_SML_Admin' ) && method_exists( 'MVweb_SML_Admin', 'init' ) ) {
				MVweb_SML_Admin::init();
			}

			if ( class_exists( 'MVweb_SML_Metabox' ) && method_exists( 'MVweb_SML_Metabox', 'init' ) ) {
				MVweb_SML_Metabox::init();
			}

			if ( class_exists( 'MVweb_SML_Bulk' ) && method_exists( 'MVweb_SML_Bulk', 'init' ) ) {
				MVweb_SML_Bulk::init();
			}

			if ( class_exists( 'MVweb_SML_Notices' ) && method_exists( 'MVweb_SML_Notices', 'render_all' ) ) {
				add_action( 'admin_notices', array( 'MVweb_SML_Notices', 'render_all' ) );
			}

			if ( class_exists( 'MVweb_SML_Dashboard_Widget' ) && method_exists( 'MVweb_SML_Dashboard_Widget', 'register' ) ) {
				add_action( 'wp_dashboard_setup', array( 'MVweb_SML_Dashboard_Widget', 'register' ) );
			}
		}

		if ( defined( 'WP_CLI' ) && WP_CLI && class_exists( 'MVweb_SML_CLI' ) ) {
			WP_CLI::add_command( 'mvweb-sml', 'MVweb_SML_CLI' );
		}

		if ( class_exists( 'MVweb_SML_REST_API' ) && method_exists( 'MVweb_SML_REST_API', 'register_routes' ) ) {
			add_action( 'rest_api_init', array( 'MVweb_SML_REST_API', 'register_routes' ) );
		}

		if ( class_exists( 'MVweb_SML_Indexer' ) && method_exists( 'MVweb_SML_Indexer', 'get_instance' ) ) {
			add_action(
				'mvweb_sml_cron_indexer',
				array( MVweb_SML_Indexer::get_instance(), 'cron_handler' )
			);
		}
	}
}
