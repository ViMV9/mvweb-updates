<?php
/**
 * Reports for MVweb Smart Links (TZ §8 / §9).
 *
 * Five report types:
 *  - orphans()                  posts no other post links to.
 *  - link_stats()               incoming/outgoing per post (auto + manual).
 *  - broken_links()             targets pointing at trashed/deleted posts
 *                               in BOTH the `_links` table and the
 *                               `_mvweb_sml_manual_targets` postmeta.
 *  - keyword_cannibalization()  keywords assigned to more than one post.
 *  - crawl_depth()              BFS distance from front_page through `_links`.
 *
 * Pure data layer — does not render HTML and does not enqueue assets. The
 * tab views and the dashboard widget consume these arrays directly.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Reports.
 *
 * @since 1.0.0
 */
class MVweb_SML_Reports {

	/**
	 * Cache key for the broken-links scan (refreshed on demand).
	 */
	const BROKEN_CACHE_KEY = 'mvweb_sml_broken_cache';

	/**
	 * Cache key for the crawl-depth BFS.
	 */
	const CRAWL_CACHE_KEY = 'mvweb_sml_crawl_depth_cache';

	/**
	 * TTL for both caches (1 hour, per plan).
	 */
	const CACHE_TTL = HOUR_IN_SECONDS;

	// ─────────────────────────────────────────────────────────────────────
	// 1. Orphan pages
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Find published posts that no other post links to.
	 *
	 * Only looks at the `_links` table (auto-discovery + admin-approved
	 * pairs). Orphans by manual postmeta links are intentionally not
	 * counted as "incoming" — manual targets only express outgoing
	 * intentions, never incoming back-links.
	 *
	 * @since 1.0.0
	 * @param int $limit Maximum rows to return.
	 * @return array<int, WP_Post>
	 */
	public static function orphans( $limit = 200 ) {
		global $wpdb;

		$post_types = mvweb_sml_supported_post_types();
		if ( empty( $post_types ) ) {
			return array();
		}

		$links = mvweb_sml_table( 'links' );
		$limit = max( 1, (int) $limit );

		$placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT p.ID
				 FROM {$wpdb->posts} p
				 LEFT JOIN `{$links}` l
				   ON l.target_id = p.ID
				   AND l.status IN ('approved','auto')
				 WHERE p.post_status = 'publish'
				   AND p.post_type IN ({$placeholders})
				   AND l.id IS NULL
				 ORDER BY p.post_date DESC
				 LIMIT %d",
				array_merge( $post_types, array( $limit ) )
			)
		);
		// phpcs:enable

		$ids = array_filter( array_map( 'intval', (array) $ids ) );
		if ( empty( $ids ) ) {
			return array();
		}

		$posts = get_posts(
			array(
				'post__in'            => $ids,
				'post_type'           => $post_types,
				'post_status'         => 'publish',
				'numberposts'         => count( $ids ),
				'orderby'             => 'post__in',
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			)
		);

		return is_array( $posts ) ? $posts : array();
	}

	/**
	 * Count published posts that no other post links to.
	 *
	 * Same filter as {@see orphans()} but returns a single integer via
	 * `SELECT COUNT(*)` — cheap for dashboards and REST summaries that
	 * do not need the WP_Post objects themselves.
	 *
	 * @since 1.0.0
	 * @return int
	 */
	public static function orphans_count() {
		global $wpdb;

		$post_types = mvweb_sml_supported_post_types();
		if ( empty( $post_types ) ) {
			return 0;
		}

		$links        = mvweb_sml_table( 'links' );
		$placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );

		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$count = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*)
				 FROM {$wpdb->posts} p
				 LEFT JOIN `{$links}` l
				   ON l.target_id = p.ID
				   AND l.status IN ('approved','auto')
				 WHERE p.post_status = 'publish'
				   AND p.post_type IN ({$placeholders})
				   AND l.id IS NULL",
				$post_types
			)
		);
		// phpcs:enable

		return $count;
	}

	// ─────────────────────────────────────────────────────────────────────
	// 2. Link stats (incoming / outgoing per post)
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Compute incoming/outgoing link counts.
	 *
	 * Combines two sources:
	 *   1. The `_links` table (status `approved` or `auto`).
	 *   2. Manual targets stored in postmeta `_mvweb_sml_manual_targets`.
	 *
	 * Manual targets are validated against `get_post_status()` — broken
	 * (deleted or trashed) ids are skipped here and surfaced via
	 * broken_links() instead.
	 *
	 * @since 1.0.0
	 * @param int|null $post_id Single post id, or null for an aggregate map.
	 * @return array
	 */
	public static function link_stats( $post_id = null ) {
		global $wpdb;

		$links_table = mvweb_sml_table( 'links' );

		// Pull aggregated counts from `_links` once.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$out_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT source_id AS post_id, COUNT(*) AS c
				 FROM %i
				 WHERE status IN ('approved','auto')
				 GROUP BY source_id",
				$links_table
			),
			ARRAY_A
		);

		$in_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT target_id AS post_id, COUNT(*) AS c
				 FROM %i
				 WHERE status IN ('approved','auto')
				 GROUP BY target_id",
				$links_table
			),
			ARRAY_A
		);
		// phpcs:enable

		$outgoing = array();
		$incoming = array();

		foreach ( (array) $out_rows as $r ) {
			$outgoing[ (int) $r['post_id'] ] = (int) $r['c'];
		}
		foreach ( (array) $in_rows as $r ) {
			$incoming[ (int) $r['post_id'] ] = (int) $r['c'];
		}

		// Manual targets (postmeta) — outgoing for source, incoming for targets.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$manual_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s",
				'_mvweb_sml_manual_targets'
			),
			ARRAY_A
		);

		// Collect unique target ids up front so we can prime the post cache
		// with a single get_posts() — without this each get_post_status() in
		// the inner loop hits wp_posts separately.
		$manual_map = array();
		foreach ( (array) $manual_rows as $row ) {
			$source = (int) $row['post_id'];
			$value  = maybe_unserialize( $row['meta_value'] );
			if ( ! is_array( $value ) ) {
				continue;
			}
			$manual_map[ $source ] = $value;
		}

		$all_manual_targets = array();
		foreach ( $manual_map as $targets ) {
			foreach ( $targets as $target ) {
				$target = (int) $target;
				if ( $target > 0 ) {
					$all_manual_targets[ $target ] = true;
				}
			}
		}
		if ( ! empty( $all_manual_targets ) ) {
			$ids = array_keys( $all_manual_targets );
			get_posts(
				array(
					'post__in'            => $ids,
					'post_type'           => 'any',
					'post_status'         => 'any',
					'numberposts'         => count( $ids ),
					'fields'              => 'ids',
					'no_found_rows'       => true,
					'ignore_sticky_posts' => true,
				)
			);
		}

		foreach ( $manual_map as $source => $targets ) {
			foreach ( $targets as $target ) {
				$target = (int) $target;
				if ( $target <= 0 || $target === $source ) {
					continue;
				}
				$status = get_post_status( $target );
				if ( false === $status || 'trash' === $status ) {
					continue;
				}

				$outgoing[ $source ] = isset( $outgoing[ $source ] ) ? $outgoing[ $source ] + 1 : 1;
				$incoming[ $target ] = isset( $incoming[ $target ] ) ? $incoming[ $target ] + 1 : 1;
			}
		}

		if ( null !== $post_id ) {
			$pid = (int) $post_id;
			return array(
				'post_id'  => $pid,
				'incoming' => isset( $incoming[ $pid ] ) ? (int) $incoming[ $pid ] : 0,
				'outgoing' => isset( $outgoing[ $pid ] ) ? (int) $outgoing[ $pid ] : 0,
			);
		}

		// Aggregate map — return per-post counts and global averages.
		$post_ids = array_unique( array_merge( array_keys( $incoming ), array_keys( $outgoing ) ) );
		$rows     = array();
		foreach ( $post_ids as $pid ) {
			$rows[] = array(
				'post_id'  => (int) $pid,
				'incoming' => isset( $incoming[ $pid ] ) ? (int) $incoming[ $pid ] : 0,
				'outgoing' => isset( $outgoing[ $pid ] ) ? (int) $outgoing[ $pid ] : 0,
			);
		}

		$count        = max( 1, count( $rows ) );
		$avg_incoming = array_sum( wp_list_pluck( $rows, 'incoming' ) ) / $count;
		$avg_outgoing = array_sum( wp_list_pluck( $rows, 'outgoing' ) ) / $count;

		return array(
			'rows'         => $rows,
			'avg_incoming' => round( $avg_incoming, 2 ),
			'avg_outgoing' => round( $avg_outgoing, 2 ),
			'total_posts'  => count( $rows ),
		);
	}

	// ─────────────────────────────────────────────────────────────────────
	// 3. Broken links scanner
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Scan every link target — both from the `_links` table and from
	 * `_mvweb_sml_manual_targets` postmeta — and return the ones whose
	 * post is missing or trashed.
	 *
	 * Heavy. Cached for one hour in BROKEN_CACHE_KEY transient. Pass
	 * `$force = true` to invalidate the cache.
	 *
	 * @since 1.0.0
	 * @param bool $force Force a fresh scan.
	 * @return array<int, array{target_id:int, source_id:int, origin:string}>
	 */
	public static function broken_links( $force = false ) {
		global $wpdb;

		if ( ! $force ) {
			$cached = get_transient( self::BROKEN_CACHE_KEY );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$out         = array();
		$links_table = mvweb_sml_table( 'links' );

		// 1. Active links from the table (`pending`/`rejected` are not broken —
		// they simply were never activated, so they are excluded from the scan).
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results(
			"SELECT id, source_id, target_id FROM `{$links_table}` WHERE status IN ('approved','auto')",
			ARRAY_A
		);
		// phpcs:enable

		// Prime the post cache once so `get_post_status()` in the loop below
		// resolves from the in-memory WP cache instead of hitting wp_posts
		// for every row.
		$auto_targets = array_unique( array_map( 'intval', wp_list_pluck( (array) $rows, 'target_id' ) ) );
		if ( ! empty( $auto_targets ) ) {
			get_posts(
				array(
					'post__in'            => $auto_targets,
					'post_type'           => 'any',
					'post_status'         => 'any',
					'numberposts'         => count( $auto_targets ),
					'fields'              => 'ids',
					'no_found_rows'       => true,
					'ignore_sticky_posts' => true,
				)
			);
		}

		foreach ( (array) $rows as $row ) {
			$target = (int) $row['target_id'];
			$status = get_post_status( $target );
			if ( false === $status || 'publish' !== $status ) {
				$out[] = array(
					'target_id' => $target,
					'source_id' => (int) $row['source_id'],
					'origin'    => 'auto',
				);
			}
		}

		// 2. Manual targets in postmeta.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$manual_rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, meta_value FROM {$wpdb->postmeta} WHERE meta_key = %s",
				'_mvweb_sml_manual_targets'
			),
			ARRAY_A
		);

		foreach ( (array) $manual_rows as $row ) {
			$source = (int) $row['post_id'];
			$value  = maybe_unserialize( $row['meta_value'] );
			if ( ! is_array( $value ) ) {
				continue;
			}
			foreach ( $value as $target ) {
				$target = (int) $target;
				if ( $target <= 0 ) {
					continue;
				}
				$status = get_post_status( $target );
				if ( false === $status || 'trash' === $status ) {
					$out[] = array(
						'target_id' => $target,
						'source_id' => $source,
						'origin'    => 'manual',
					);
				}
			}
		}

		set_transient( self::BROKEN_CACHE_KEY, $out, self::CACHE_TTL );
		return $out;
	}

	// ─────────────────────────────────────────────────────────────────────
	// 4. Keyword cannibalization
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Delegate to Keyword_Manager::find_conflicts().
	 *
	 * @since 1.0.0
	 * @return array<int, array{keyword:string, post_ids:array<int,int>}>
	 */
	public static function keyword_cannibalization() {
		if ( ! class_exists( 'MVweb_SML_Keyword_Manager' ) ) {
			return array();
		}
		return MVweb_SML_Keyword_Manager::find_conflicts();
	}

	// ─────────────────────────────────────────────────────────────────────
	// 4b. Anchor profile (over-optimisation)
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Anchor-text distribution per target across live links.
	 *
	 * Search engines penalise exact-match anchor over-optimisation: many
	 * incoming links using the identical anchor text look manipulative. This
	 * groups the live (approved + auto) links by target and anchor and returns
	 * every anchor that repeats at least `$min_count` times, so the editor can
	 * diversify anchors (rotate synonyms) before it becomes a ranking risk.
	 *
	 * Only non-empty stored anchors are counted — a blank anchor renders as the
	 * matched keyword, which varies per source and is not an over-optimisation
	 * signal.
	 *
	 * @since 1.0.0
	 * @param int $min_count Minimum repetitions to report (floored at 2).
	 * @param int $limit     Maximum rows returned.
	 * @return array<int, array{target_id:int, anchor:string, count:int}>
	 */
	public static function anchor_profile( $min_count = 2, $limit = 200 ) {
		global $wpdb;

		$min_count = max( 2, (int) $min_count );
		$limit     = max( 1, (int) $limit );
		$table     = mvweb_sml_table( 'links' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT target_id, anchor, COUNT(*) AS cnt
				 FROM `{$table}`
				 WHERE status IN ('approved','auto') AND anchor <> ''
				 GROUP BY target_id, anchor
				 HAVING cnt >= %d
				 ORDER BY cnt DESC, target_id ASC
				 LIMIT %d",
				$min_count,
				$limit
			),
			ARRAY_A
		);
		// phpcs:enable

		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[] = array(
				'target_id' => (int) $row['target_id'],
				'anchor'    => (string) $row['anchor'],
				'count'     => (int) $row['cnt'],
			);
		}

		return $out;
	}

	/**
	 * How many live links already use a given anchor for a target.
	 *
	 * Used by the review table to warn before approving yet another identical
	 * exact-match anchor to the same destination.
	 *
	 * @since 1.0.0
	 * @param int    $target_id Target post ID.
	 * @param string $anchor    Anchor text to count.
	 * @return int
	 */
	public static function anchor_reuse_count( $target_id, $anchor ) {
		global $wpdb;

		$target_id = (int) $target_id;
		$anchor    = trim( (string) $anchor );
		if ( $target_id <= 0 || '' === $anchor ) {
			return 0;
		}

		$table = mvweb_sml_table( 'links' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$count = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM `{$table}`
				 WHERE target_id = %d AND anchor = %s AND status IN ('approved','auto')",
				$target_id,
				$anchor
			)
		);
		// phpcs:enable

		return (int) $count;
	}

	// ─────────────────────────────────────────────────────────────────────
	// 5. Crawl depth (BFS from front page)
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * BFS from the configured front page through the `_links` graph.
	 *
	 * Returns an associative map post_id => depth, plus a `reason` string
	 * when the graph cannot be built (no links yet, no front page).
	 *
	 * Cached for one hour. Pass `$force = true` to invalidate.
	 *
	 * @since 1.0.0
	 * @param bool $force Force a fresh BFS.
	 * @return array{depths:array<int,int>, max_depth:int, average:float, reason:string}
	 */
	public static function crawl_depth( $force = false ) {
		global $wpdb;

		if ( ! $force ) {
			$cached = get_transient( self::CRAWL_CACHE_KEY );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$result = array(
			'depths'    => array(),
			'max_depth' => 0,
			'average'   => 0.0,
			'reason'    => '',
		);

		$links_table = mvweb_sml_table( 'links' );

		// Bail if the links graph is empty.
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$links_table}` WHERE status IN ('approved','auto')" );
		// phpcs:enable
		if ( 0 === $total ) {
			$result['reason'] = 'no_links';
			set_transient( self::CRAWL_CACHE_KEY, $result, self::CACHE_TTL );
			return $result;
		}

		// Resolve the seed post id (front page).
		$seed = self::resolve_front_page_id();
		if ( $seed <= 0 ) {
			$result['reason'] = 'no_front_page';
			set_transient( self::CRAWL_CACHE_KEY, $result, self::CACHE_TTL );
			return $result;
		}

		// Pull every edge once into memory: source_id → [target_id, ...].
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery
		$edges = $wpdb->get_results(
			"SELECT DISTINCT source_id, target_id FROM `{$links_table}` WHERE status IN ('approved','auto')",
			ARRAY_A
		);
		// phpcs:enable

		$adj = array();
		foreach ( (array) $edges as $edge ) {
			$src = (int) $edge['source_id'];
			$tgt = (int) $edge['target_id'];
			if ( $src <= 0 || $tgt <= 0 ) {
				continue;
			}
			if ( ! isset( $adj[ $src ] ) ) {
				$adj[ $src ] = array();
			}
			$adj[ $src ][] = $tgt;
		}

		// Standard BFS.
		$depths        = array( $seed => 0 );
		$queue         = array( $seed );
		$queue_pointer = 0;
		$queue_size    = 1;

		while ( $queue_pointer < $queue_size ) {
			$current = $queue[ $queue_pointer ];
			++$queue_pointer;

			$current_depth = $depths[ $current ];

			if ( empty( $adj[ $current ] ) ) {
				continue;
			}

			foreach ( $adj[ $current ] as $next ) {
				if ( isset( $depths[ $next ] ) ) {
					continue;
				}
				$depths[ $next ] = $current_depth + 1;
				$queue[]         = $next;
				++$queue_size;
			}
		}

		$max = empty( $depths ) ? 0 : max( $depths );
		$avg = empty( $depths ) ? 0 : array_sum( $depths ) / count( $depths );

		$result['depths']    = $depths;
		$result['max_depth'] = (int) $max;
		$result['average']   = round( (float) $avg, 2 );

		set_transient( self::CRAWL_CACHE_KEY, $result, self::CACHE_TTL );
		return $result;
	}

	/**
	 * Resolve the post id used as BFS seed.
	 *
	 * Order:
	 *  1. `page_on_front` if `show_on_front=page`.
	 *  2. `page_for_posts`.
	 *  3. The newest published post in the supported types.
	 *
	 * @since 1.0.0
	 * @return int Post id, or 0 when nothing matched.
	 */
	private static function resolve_front_page_id() {
		if ( 'page' === get_option( 'show_on_front' ) ) {
			$front = (int) get_option( 'page_on_front' );
			if ( $front > 0 ) {
				return $front;
			}
		}

		$blog = (int) get_option( 'page_for_posts' );
		if ( $blog > 0 ) {
			return $blog;
		}

		$post_types = mvweb_sml_supported_post_types();
		if ( empty( $post_types ) ) {
			return 0;
		}

		$latest = get_posts(
			array(
				'post_type'           => $post_types,
				'post_status'         => 'publish',
				'numberposts'         => 1,
				'fields'              => 'ids',
				'orderby'             => 'date',
				'order'               => 'DESC',
				'no_found_rows'       => true,
				'ignore_sticky_posts' => true,
			)
		);

		return ! empty( $latest ) ? (int) $latest[0] : 0;
	}

	// ─────────────────────────────────────────────────────────────────────
	// Helpers for the dashboard tab and the WP dashboard widget
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Total number of supported posts (`post_status=publish`).
	 *
	 * @since 1.0.0
	 * @return int
	 */
	public static function total_supported_posts() {
		$post_types = mvweb_sml_supported_post_types();
		if ( empty( $post_types ) ) {
			return 0;
		}

		$total = 0;
		foreach ( $post_types as $type ) {
			$counts = wp_count_posts( $type );
			if ( is_object( $counts ) && isset( $counts->publish ) ) {
				$total += (int) $counts->publish;
			}
		}
		return $total;
	}

	/**
	 * Total number of auto/approved links currently stored in `_links`.
	 *
	 * @since 1.0.0
	 * @return int
	 */
	public static function total_auto_links() {
		global $wpdb;
		$table = mvweb_sml_table( 'links' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}` WHERE status IN ('approved','auto')" );
	}

	/**
	 * Index status: total/dirty/last_indexed for the dashboard card.
	 *
	 * @since 1.0.0
	 * @return array{total:int, dirty:int, last_indexed:string}
	 */
	public static function index_status() {
		global $wpdb;

		$indexer   = MVweb_SML_Indexer::get_instance();
		$index_tbl = mvweb_sml_table( 'index' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$last_raw = $wpdb->get_var( "SELECT MAX(indexed_at) FROM `{$index_tbl}`" );

		return array(
			'total'        => $indexer->total_count(),
			'dirty'        => $indexer->dirty_count(),
			'last_indexed' => $last_raw ? (string) $last_raw : '',
		);
	}

	/**
	 * Refresh notices that depend on report state.
	 *
	 * Called from tab-reports.php after running the heavy reports so that
	 * the global "orphans found" / "conflicts found" notices stay in sync
	 * with the latest scan.
	 *
	 * @since 1.0.0
	 * @param int $orphan_count Number of orphan pages.
	 * @param int $conflict_count Number of cannibalising keywords.
	 * @return void
	 */
	public static function refresh_notices( $orphan_count, $conflict_count ) {
		if ( ! class_exists( 'MVweb_SML_Notices' ) ) {
			return;
		}

		if ( $orphan_count > 0 ) {
			MVweb_SML_Notices::add(
				'orphans_found',
				sprintf(
					/* translators: %d: number of orphan pages. */
					_n( 'Found %d orphan page.', 'Found %d orphan pages.', $orphan_count, 'mvweb-smart-links' ),
					$orphan_count
				),
				'warning'
			);
		} else {
			MVweb_SML_Notices::remove( 'orphans_found' );
		}

		if ( $conflict_count > 0 ) {
			MVweb_SML_Notices::add(
				'conflicts_found',
				sprintf(
					/* translators: %d: number of cannibalising keywords. */
					_n( '%d keyword is assigned to multiple posts.', '%d keywords are assigned to multiple posts.', $conflict_count, 'mvweb-smart-links' ),
					$conflict_count
				),
				'warning'
			);
		} else {
			MVweb_SML_Notices::remove( 'conflicts_found' );
		}
	}
}
