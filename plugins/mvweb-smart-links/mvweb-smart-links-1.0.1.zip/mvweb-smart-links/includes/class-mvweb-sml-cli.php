<?php
/**
 * WP-CLI commands for MVweb Smart Links.
 *
 * Registered under the `wp mvweb-sml` namespace. Five sub-commands:
 *
 *   wp mvweb-sml reindex [--force]
 *   wp mvweb-sml stats
 *   wp mvweb-sml orphans [--format=<table|csv|json>]
 *   wp mvweb-sml keywords list [--post=<id>]
 *   wp mvweb-sml keywords import --source=<yoast|rankmath|aioseo>
 *
 * The file is only loaded when `WP_CLI` is defined (see loader), so it is
 * safe to reference `WP_CLI`, `WP_CLI_Command` and helper functions here
 * without extra guards at runtime.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Only declare the command class in CLI context. The loader also guards the
// include, but this keeps static analysers from flagging the parent class.
if ( ! ( defined( 'WP_CLI' ) && WP_CLI ) ) {
	return;
}

/**
 * Manage MVweb Smart Links from the command line.
 *
 * @since 1.0.0
 */
class MVweb_SML_CLI extends WP_CLI_Command {

	/**
	 * Re-index the content graph.
	 *
	 * ## OPTIONS
	 *
	 * [--force]
	 * : Mark every supported post as dirty before processing and drain the
	 * queue in-place. Without `--force` only a single background batch is
	 * processed.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-sml reindex
	 *     wp mvweb-sml reindex --force
	 *
	 * @param array $args       Positional args (unused).
	 * @param array $assoc_args Associative args.
	 * @return void
	 */
	public function reindex( $args, $assoc_args ) {
		unset( $args );

		if ( ! class_exists( 'MVweb_SML_Indexer' ) ) {
			WP_CLI::error( 'Indexer is not available.' );
		}

		$indexer = MVweb_SML_Indexer::get_instance();
		$force   = ! empty( $assoc_args['force'] );

		if ( $force ) {
			$queued = $indexer->mark_all_dirty();
			WP_CLI::log( sprintf( 'Queued %d posts for reindex.', (int) $queued ) );

			$total_processed = 0;
			do {
				$result           = $indexer->process_batch();
				$processed        = isset( $result['processed'] ) ? (int) $result['processed'] : 0;
				$remaining        = isset( $result['remaining'] ) ? (int) $result['remaining'] : 0;
				$total_processed += $processed;
				WP_CLI::log( sprintf( 'Batch processed: %d (remaining: %d)', $processed, $remaining ) );
				if ( 0 === $processed ) {
					break;
				}
			} while ( $remaining > 0 );

			do_action( 'mvweb_sml_index_complete' );

			WP_CLI::success( sprintf( 'Reindex complete. Processed %d posts.', $total_processed ) );
			return;
		}

		$result    = $indexer->process_batch();
		$processed = isset( $result['processed'] ) ? (int) $result['processed'] : 0;
		$remaining = isset( $result['remaining'] ) ? (int) $result['remaining'] : 0;

		WP_CLI::success(
			sprintf( 'Batch processed: %d (remaining: %d)', $processed, $remaining )
		);
	}

	/**
	 * Print aggregate Smart Links statistics.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-sml stats
	 *
	 * @return void
	 */
	public function stats() {
		if ( ! class_exists( 'MVweb_SML_Reports' ) ) {
			WP_CLI::error( 'Reports component is not available.' );
		}

		$index_status = MVweb_SML_Reports::index_status();
		$link_stats   = MVweb_SML_Reports::link_stats();
		$conflicts    = MVweb_SML_Reports::keyword_cannibalization();

		$rows = array(
			array(
				'metric' => 'total_posts',
				'value'  => (string) MVweb_SML_Reports::total_supported_posts(),
			),
			array(
				'metric' => 'total_links',
				'value'  => (string) MVweb_SML_Reports::total_auto_links(),
			),
			array(
				'metric' => 'avg_incoming',
				'value'  => isset( $link_stats['avg_incoming'] ) ? (string) $link_stats['avg_incoming'] : '0',
			),
			array(
				'metric' => 'avg_outgoing',
				'value'  => isset( $link_stats['avg_outgoing'] ) ? (string) $link_stats['avg_outgoing'] : '0',
			),
			array(
				'metric' => 'index_total',
				'value'  => isset( $index_status['total'] ) ? (string) $index_status['total'] : '0',
			),
			array(
				'metric' => 'index_dirty',
				'value'  => isset( $index_status['dirty'] ) ? (string) $index_status['dirty'] : '0',
			),
			array(
				'metric' => 'last_indexed',
				'value'  => isset( $index_status['last_indexed'] ) && '' !== $index_status['last_indexed']
					? (string) $index_status['last_indexed']
					: 'never',
			),
			array(
				'metric' => 'keyword_conflicts',
				'value'  => (string) count( (array) $conflicts ),
			),
		);

		\WP_CLI\Utils\format_items( 'table', $rows, array( 'metric', 'value' ) );
	}

	/**
	 * List orphan posts (posts with no incoming links).
	 *
	 * ## OPTIONS
	 *
	 * [--format=<format>]
	 * : Output format.
	 * ---
	 * default: table
	 * options:
	 *   - table
	 *   - csv
	 *   - json
	 * ---
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-sml orphans
	 *     wp mvweb-sml orphans --format=json
	 *
	 * @param array $args       Positional args (unused).
	 * @param array $assoc_args Associative args.
	 * @return void
	 */
	public function orphans( $args, $assoc_args ) {
		unset( $args );

		if ( ! class_exists( 'MVweb_SML_Reports' ) ) {
			WP_CLI::error( 'Reports component is not available.' );
		}

		$format = isset( $assoc_args['format'] ) ? (string) $assoc_args['format'] : 'table';
		$posts  = MVweb_SML_Reports::orphans( 1000 );

		$rows = array();
		foreach ( (array) $posts as $post ) {
			if ( ! $post instanceof WP_Post ) {
				continue;
			}
			$rows[] = array(
				'id'        => (int) $post->ID,
				'title'     => (string) get_the_title( $post ),
				'post_type' => (string) $post->post_type,
				'date'      => (string) $post->post_date,
			);
		}

		if ( empty( $rows ) ) {
			WP_CLI::success( 'No orphans found.' );
			return;
		}

		\WP_CLI\Utils\format_items( $format, $rows, array( 'id', 'title', 'post_type', 'date' ) );
	}

	/**
	 * Manage keywords (list / import / import-queries).
	 *
	 * ## OPTIONS
	 *
	 * <action>
	 * : `list`, `import` (SEO plugin focus keywords) or `import-queries`
	 *   (search-query CSV).
	 *
	 * [--post=<id>]
	 * : (list) Restrict output to a single post ID.
	 *
	 * [--source=<source>]
	 * : (import) SEO plugin source: yoast|rankmath|aioseo.
	 *   (import-queries) Provenance tag: gsc|yandex (default gsc).
	 *
	 * [--file=<path>]
	 * : (import-queries) Path to a CSV with a header row and columns
	 *   `query` plus `post_id` or `url`/`page`, optionally `position` and
	 *   `impressions`.
	 *
	 * [--min-position=<n>]
	 * : (import-queries) Lowest search position to keep. Default 0.
	 *
	 * [--max-position=<n>]
	 * : (import-queries) Highest search position to keep. Default 100.
	 *
	 * [--min-impressions=<n>]
	 * : (import-queries) Minimum impressions to keep. Default 0.
	 *
	 * ## EXAMPLES
	 *
	 *     wp mvweb-sml keywords list
	 *     wp mvweb-sml keywords list --post=42
	 *     wp mvweb-sml keywords import --source=yoast
	 *     wp mvweb-sml keywords import-queries --file=queries.csv --source=yandex --min-position=4 --max-position=20 --min-impressions=10
	 *
	 * @param array $args       Positional args. First element is the action.
	 * @param array $assoc_args Associative args.
	 * @return void
	 */
	public function keywords( $args, $assoc_args ) {
		$action = isset( $args[0] ) ? (string) $args[0] : '';

		if ( 'list' === $action ) {
			$this->keywords_list( $assoc_args );
			return;
		}

		if ( 'import' === $action ) {
			$this->keywords_import( $assoc_args );
			return;
		}

		if ( 'import-queries' === $action ) {
			$this->keywords_import_queries( $assoc_args );
			return;
		}

		WP_CLI::error( 'Unknown keywords action. Use `list`, `import` or `import-queries`.' );
	}

	/**
	 * Handler for `wp mvweb-sml keywords import-queries --file=...`.
	 *
	 * Bulk-imports search queries from a CSV (header row required, columns:
	 * `query` plus `post_id` or `url`/`page`, optionally `position` and
	 * `impressions`) as keywords, applying the growth-point filter.
	 *
	 * @since 1.0.0
	 * @param array $assoc_args Associative args.
	 * @return void
	 */
	private function keywords_import_queries( $assoc_args ) {
		if ( ! class_exists( 'MVweb_SML_Query_Import' ) ) {
			WP_CLI::error( 'Query import component is not available.' );
		}

		$file = isset( $assoc_args['file'] ) ? (string) $assoc_args['file'] : '';
		if ( '' === $file ) {
			WP_CLI::error( 'Missing --file=<path to CSV>.' );
		}

		$source = isset( $assoc_args['source'] ) ? (string) $assoc_args['source'] : 'gsc';
		$opts   = array(
			'min_position'    => isset( $assoc_args['min-position'] ) ? (float) $assoc_args['min-position'] : 0.0,
			'max_position'    => isset( $assoc_args['max-position'] ) ? (float) $assoc_args['max-position'] : 100.0,
			'min_impressions' => isset( $assoc_args['min-impressions'] ) ? (int) $assoc_args['min-impressions'] : 0,
		);

		$result = MVweb_SML_Query_Import::import_from_csv( $file, $source, $opts );
		if ( is_wp_error( $result ) ) {
			WP_CLI::error( $result->get_error_message() );
		}

		if ( (int) $result['imported'] > 0 && class_exists( 'MVweb_SML_Cache' ) ) {
			MVweb_SML_Cache::flush_all();
		}

		WP_CLI::success(
			sprintf(
				'Imported %d keywords across %d posts (filtered %d, duplicates %d, unresolved rows %d).',
				(int) $result['imported'],
				(int) $result['posts'],
				(int) $result['skipped_filter'],
				(int) $result['skipped_dup'],
				(int) $result['unresolved']
			)
		);
	}

	/**
	 * Handler for `wp mvweb-sml keywords list`.
	 *
	 * @since 1.0.0
	 * @param array $assoc_args Associative args.
	 * @return void
	 */
	private function keywords_list( $assoc_args ) {
		global $wpdb;

		if ( ! class_exists( 'MVweb_SML_Keyword_Manager' ) ) {
			WP_CLI::error( 'Keyword manager is not available.' );
		}

		$rows = array();

		if ( isset( $assoc_args['post'] ) ) {
			$post_id = (int) $assoc_args['post'];
			$data    = MVweb_SML_Keyword_Manager::get_for_post( $post_id );
			foreach ( (array) $data as $row ) {
				$rows[] = array(
					'id'       => (int) $row['id'],
					'post_id'  => (int) $row['post_id'],
					'keyword'  => (string) $row['keyword'],
					'synonyms' => implode( '|', (array) $row['synonyms'] ),
					'source'   => (string) $row['source'],
				);
			}
		} else {
			$table = mvweb_sml_table( 'keywords' );
			// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$records = $wpdb->get_results(
				"SELECT id, post_id, keyword, synonyms, source FROM `{$table}` ORDER BY post_id ASC, id ASC",
				ARRAY_A
			);
			// phpcs:enable
			foreach ( (array) $records as $row ) {
				$synonyms = json_decode( (string) $row['synonyms'], true );
				if ( ! is_array( $synonyms ) ) {
					$synonyms = array();
				}
				$rows[] = array(
					'id'       => (int) $row['id'],
					'post_id'  => (int) $row['post_id'],
					'keyword'  => (string) $row['keyword'],
					'synonyms' => implode( '|', $synonyms ),
					'source'   => (string) $row['source'],
				);
			}
		}

		if ( empty( $rows ) ) {
			WP_CLI::success( 'No keywords found.' );
			return;
		}

		\WP_CLI\Utils\format_items(
			'table',
			$rows,
			array( 'id', 'post_id', 'keyword', 'synonyms', 'source' )
		);
	}

	/**
	 * Handler for `wp mvweb-sml keywords import --source=...`.
	 *
	 * @since 1.0.0
	 * @param array $assoc_args Associative args.
	 * @return void
	 */
	private function keywords_import( $assoc_args ) {
		if ( ! class_exists( 'MVweb_SML_SEO_Import' ) ) {
			WP_CLI::error( 'SEO import component is not available.' );
		}

		$source = isset( $assoc_args['source'] ) ? (string) $assoc_args['source'] : '';
		if ( '' === $source ) {
			WP_CLI::error( 'Missing --source=<yoast|rankmath|aioseo>.' );
		}

		$result = MVweb_SML_SEO_Import::import( $source );

		if ( ( isset( $result['imported'] ) ? (int) $result['imported'] : 0 ) > 0 && class_exists( 'MVweb_SML_Cache' ) ) {
			MVweb_SML_Cache::flush_all();
		}

		WP_CLI::success(
			sprintf(
				'Imported %d keywords (skipped %d, total scanned %d).',
				isset( $result['imported'] ) ? (int) $result['imported'] : 0,
				isset( $result['skipped'] ) ? (int) $result['skipped'] : 0,
				isset( $result['total'] ) ? (int) $result['total'] : 0
			)
		);
	}
}
