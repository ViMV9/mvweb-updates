<?php
/**
 * REST API controller for MVweb Smart Links.
 *
 * Exposes read-only endpoints under the `mvweb-sml/v1` namespace. Designed
 * for external dashboards, editorial tooling and CI automation that need to
 * consume the plugin's data without scraping HTML from the admin views.
 *
 * Endpoints (all require the `edit_others_posts` capability by default, see
 * {@see mvweb_sml_rest_permission} filter for customization):
 *
 *  - GET /links/{post_id}     → {@see MVweb_SML_Reports::link_stats()}
 *  - GET /orphans             → {@see MVweb_SML_Reports::orphans()}
 *  - GET /stats               → aggregate metrics (links, posts, index)
 *  - GET /keywords/{post_id}  → {@see MVweb_SML_Keyword_Manager::get_for_post()}
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_REST_API.
 *
 * @since 1.0.0
 */
class MVweb_SML_REST_API {

	/**
	 * REST namespace used for every route in this class.
	 */
	const NAMESPACE_V1 = 'mvweb-sml/v1';

	/**
	 * Register all routes on `rest_api_init`.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_routes() {
		$post_id_args = array(
			'post_id' => array(
				'description'       => __( 'Post ID.', 'mvweb-smart-links' ),
				'type'              => 'integer',
				'required'          => true,
				'minimum'           => 1,
				'sanitize_callback' => 'absint',
				'validate_callback' => 'rest_validate_request_arg',
			),
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/links/(?P<post_id>\d+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_links' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
				'args'                => $post_id_args,
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/orphans',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_orphans' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
				'args'                => array(
					'limit' => array(
						'description'       => __( 'Maximum number of orphan posts to return.', 'mvweb-smart-links' ),
						'type'              => 'integer',
						'required'          => false,
						'default'           => 200,
						'minimum'           => 1,
						'maximum'           => 1000,
						'sanitize_callback' => 'absint',
						'validate_callback' => 'rest_validate_request_arg',
					),
				),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/stats',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_stats' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
			)
		);

		register_rest_route(
			self::NAMESPACE_V1,
			'/keywords/(?P<post_id>\d+)',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( __CLASS__, 'handle_keywords' ),
				'permission_callback' => array( __CLASS__, 'check_permission' ),
				'args'                => $post_id_args,
			)
		);
	}

	/**
	 * Shared permission callback for every endpoint.
	 *
	 * Defaults to `current_user_can( 'edit_others_posts' )` — editors and
	 * above. Wrapped in the {@see mvweb_sml_rest_permission} filter so sites
	 * with custom capability mapping can opt in or lock down further.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request Current REST request.
	 * @return bool
	 */
	public static function check_permission( $request ) {
		$allowed = current_user_can( 'edit_others_posts' );

		/**
		 * Filter whether the current user may access the Smart Links REST API.
		 *
		 * WARNING: This filter changes REST API authentication. Returning
		 * `true` bypasses the capability check entirely. Use only with
		 * explicit auth checks in a custom callback — otherwise you will
		 * expose internal link graph data to anonymous visitors.
		 *
		 * @since 1.0.0
		 * @param bool            $allowed Whether the request is allowed.
		 * @param WP_REST_Request $request Current REST request.
		 */
		return (bool) apply_filters( 'mvweb_sml_rest_permission', $allowed, $request );
	}

	/**
	 * GET /links/{post_id}.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function handle_links( $request ) {
		$post_id = (int) $request['post_id'];

		if ( ! get_post( $post_id ) ) {
			return new WP_Error(
				'mvweb_sml_post_not_found',
				__( 'Post not found.', 'mvweb-smart-links' ),
				array( 'status' => 404 )
			);
		}

		$stats = MVweb_SML_Reports::link_stats( $post_id );

		return rest_ensure_response( $stats );
	}

	/**
	 * GET /orphans.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response
	 */
	public static function handle_orphans( $request ) {
		$limit = (int) $request->get_param( 'limit' );

		$posts = MVweb_SML_Reports::orphans( $limit );

		$items = array();
		foreach ( (array) $posts as $post ) {
			if ( ! $post instanceof WP_Post ) {
				continue;
			}
			$items[] = array(
				'id'        => (int) $post->ID,
				'title'     => (string) get_the_title( $post ),
				'permalink' => (string) get_permalink( $post ),
				'post_type' => (string) $post->post_type,
				'date'      => (string) $post->post_date,
			);
		}

		return rest_ensure_response(
			array(
				'total' => count( $items ),
				'items' => $items,
			)
		);
	}

	/**
	 * GET /stats.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response
	 */
	public static function handle_stats( $request ) {
		unset( $request );

		// /stats aggregates several report queries (index status, link stats,
		// cannibalisation, orphan count). External dashboards may poll it, so a
		// short read-through cache keeps repeated hits cheap; a 5-minute TTL
		// bounds staleness, and any settings change flushes the whole group.
		if ( class_exists( 'MVweb_SML_Cache' ) ) {
			$cached = MVweb_SML_Cache::get( 'rest_stats' );
			if ( is_array( $cached ) ) {
				return rest_ensure_response( $cached );
			}
		}

		$index_status = MVweb_SML_Reports::index_status();
		$link_stats   = MVweb_SML_Reports::link_stats();
		$conflicts    = MVweb_SML_Reports::keyword_cannibalization();

		$payload = array(
			'total_posts'   => MVweb_SML_Reports::total_supported_posts(),
			'total_links'   => MVweb_SML_Reports::total_auto_links(),
			'avg_incoming'  => isset( $link_stats['avg_incoming'] ) ? (float) $link_stats['avg_incoming'] : 0.0,
			'avg_outgoing'  => isset( $link_stats['avg_outgoing'] ) ? (float) $link_stats['avg_outgoing'] : 0.0,
			'index'         => array(
				'total'        => isset( $index_status['total'] ) ? (int) $index_status['total'] : 0,
				'dirty'        => isset( $index_status['dirty'] ) ? (int) $index_status['dirty'] : 0,
				'last_indexed' => isset( $index_status['last_indexed'] ) ? (string) $index_status['last_indexed'] : '',
			),
			'conflicts'     => count( (array) $conflicts ),
			'orphans_count' => MVweb_SML_Reports::orphans_count(),
		);

		if ( class_exists( 'MVweb_SML_Cache' ) ) {
			MVweb_SML_Cache::set( 'rest_stats', $payload, 5 * MINUTE_IN_SECONDS );
		}

		return rest_ensure_response( $payload );
	}

	/**
	 * GET /keywords/{post_id}.
	 *
	 * @since 1.0.0
	 * @param WP_REST_Request $request Current request.
	 * @return WP_REST_Response|WP_Error
	 */
	public static function handle_keywords( $request ) {
		$post_id = (int) $request['post_id'];

		if ( ! get_post( $post_id ) ) {
			return new WP_Error(
				'mvweb_sml_post_not_found',
				__( 'Post not found.', 'mvweb-smart-links' ),
				array( 'status' => 404 )
			);
		}

		$rows = MVweb_SML_Keyword_Manager::get_for_post( $post_id );

		return rest_ensure_response(
			array(
				'post_id'  => $post_id,
				'total'    => count( (array) $rows ),
				'keywords' => $rows,
			)
		);
	}
}
