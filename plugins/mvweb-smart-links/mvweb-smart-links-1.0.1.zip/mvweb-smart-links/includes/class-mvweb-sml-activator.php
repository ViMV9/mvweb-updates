<?php
/**
 * Plugin activator: database schema and lifecycle bootstrap.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Activator
 *
 * Handles plugin activation: creates custom tables via dbDelta,
 * seeds default settings, schedules background indexer cron.
 *
 * @since 1.0.0
 */
class MVweb_SML_Activator {

	/**
	 * Database schema version.
	 *
	 * Increment when the table structure changes. `maybe_upgrade()` re-runs
	 * dbDelta whenever the stored version differs, so schema changes ship to
	 * existing installs on the next admin request without a manual re-activation.
	 *
	 * @var string
	 */
	const DB_VERSION = '1.2';

	/**
	 * Option key holding the installed schema version.
	 *
	 * @var string
	 */
	const DB_VERSION_OPTION = 'mvweb_sml_db_version';

	/**
	 * Run activation tasks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function activate() {
		self::create_tables();
		self::seed_default_settings();

		if ( ! wp_next_scheduled( 'mvweb_sml_cron_indexer' ) ) {
			wp_schedule_event( time(), 'mvweb_sml_5min', 'mvweb_sml_cron_indexer' );
		}

		set_transient( 'mvweb_sml_activation_redirect', 1, 30 );

		update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
	}

	/**
	 * Re-run dbDelta when the stored schema version is behind the code.
	 *
	 * Hooked on admin_init so plugin updates that change the schema migrate
	 * existing installs without a manual deactivate/activate cycle. dbDelta is
	 * idempotent, so an up-to-date install does nothing but a single option read.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function maybe_upgrade() {
		$installed = get_option( self::DB_VERSION_OPTION );

		if ( self::DB_VERSION === $installed ) {
			return;
		}

		self::create_tables();
		update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
	}

	/**
	 * Create the 5 custom tables via dbDelta.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function create_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset_collate = $wpdb->get_charset_collate();
		$prefix          = $wpdb->prefix . 'mvweb_sml_';

		$schemas = array();

		// 1. Keywords table.
		$schemas[] = "CREATE TABLE {$prefix}keywords (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			post_id BIGINT UNSIGNED NOT NULL,
			keyword VARCHAR(255) NOT NULL,
			synonyms TEXT NULL,
			source VARCHAR(20) NOT NULL DEFAULT 'manual',
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY post_id (post_id),
			KEY keyword (keyword(191))
		) $charset_collate;";

		// 2. Links table.
		$schemas[] = "CREATE TABLE {$prefix}links (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			source_id BIGINT UNSIGNED NOT NULL,
			target_id BIGINT UNSIGNED NOT NULL,
			keyword VARCHAR(255) NOT NULL,
			anchor VARCHAR(255) NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			score FLOAT NOT NULL DEFAULT 0,
			context VARCHAR(255) NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY source_id (source_id),
			KEY target_id (target_id),
			KEY status (status),
			UNIQUE KEY uq_pair_kw (source_id, target_id, keyword(100))
		) $charset_collate;";

		// 3. Index table (per-post content index).
		$schemas[] = "CREATE TABLE {$prefix}index (
			post_id BIGINT UNSIGNED NOT NULL,
			prominent LONGTEXT NULL,
			word_count INT UNSIGNED NOT NULL DEFAULT 0,
			dirty TINYINT(1) NOT NULL DEFAULT 1,
			indexed_at DATETIME NULL,
			PRIMARY KEY  (post_id),
			KEY dirty (dirty)
		) $charset_collate;";

		// 4. Clusters table.
		$schemas[] = "CREATE TABLE {$prefix}clusters (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			pillar_id BIGINT UNSIGNED NOT NULL,
			name VARCHAR(255) NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY pillar_id (pillar_id)
		) $charset_collate;";

		// 6. Click counters per (source, target) link pair.
		$schemas[] = "CREATE TABLE {$prefix}clicks (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			source_id BIGINT UNSIGNED NOT NULL,
			target_id BIGINT UNSIGNED NOT NULL,
			clicks BIGINT UNSIGNED NOT NULL DEFAULT 0,
			last_click DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY uq_pair (source_id, target_id),
			KEY target_id (target_id)
		) $charset_collate;";

		// 5. Cluster ↔ post relations.
		$schemas[] = "CREATE TABLE {$prefix}cluster_posts (
			cluster_id BIGINT UNSIGNED NOT NULL,
			post_id BIGINT UNSIGNED NOT NULL,
			role VARCHAR(20) NOT NULL DEFAULT 'spoke',
			PRIMARY KEY  (cluster_id, post_id),
			KEY post_id (post_id)
		) $charset_collate;";

		foreach ( $schemas as $sql ) {
			dbDelta( $sql );
		}
	}

	/**
	 * Seed default settings option (only if not present).
	 *
	 * Mirrors the schema documented in the plan (§ Settings option).
	 * Uses add_option (not update_option) to preserve existing values
	 * across re-activation.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function seed_default_settings() {
		$defaults = array(
			'enabled'                  => false,
			'contextual_enabled'       => true,
			'related_enabled'          => true,
			'post_types'               => array( 'post', 'page' ),
			'cross_cpt_matrix'         => array(),
			'links_max_per_page'       => 'auto',
			'links_max_per_paragraph'  => 0,
			'links_gap_words'          => 50,
			'anchor_rotation'          => true,
			'anchor_max_repeat'        => 3,
			'pillar_score_bonus'       => 3,
			'score_idf'                => true,
			'score_position'           => true,
			'link_target'              => '_self',
			'link_css_class'           => 'mvweb-sml-link',
			'related_position'         => 'after_content',
			'related_after_paragraph'  => 3,
			'related_template'         => 'list',
			'related_title'            => 'Read also',
			'related_count'            => 5,
			'related_target'           => '_self',
			'delete_data_on_uninstall' => false,
			'disabled_post_ids'        => array(),
			'disabled_url_patterns'    => array(),
		);

		add_option( 'mvweb_sml_settings', $defaults );
	}
}
