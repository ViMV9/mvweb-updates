<?php
/**
 * WordPress dashboard widget for MVweb Smart Links.
 *
 * Compact summary panel attached to wp-admin/index.php for editors and above.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Dashboard_Widget.
 *
 * @since 1.0.0
 */
class MVweb_SML_Dashboard_Widget {

	/**
	 * Widget id used by `wp_add_dashboard_widget`.
	 */
	const WIDGET_ID = 'mvweb_sml_widget';

	/**
	 * Hooked from MVweb_SML_Loader on `wp_dashboard_setup`.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register() {
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			return;
		}

		wp_add_dashboard_widget(
			self::WIDGET_ID,
			__( 'MVweb Smart Links', 'mvweb-smart-links' ),
			array( __CLASS__, 'render' )
		);
	}

	/**
	 * Render the widget contents.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render() {
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			return;
		}

		if ( ! class_exists( 'MVweb_SML_Reports' ) ) {
			esc_html_e( 'Smart Links reports are not available yet.', 'mvweb-smart-links' );
			return;
		}

		$total_posts = MVweb_SML_Reports::total_supported_posts();
		$total_links = MVweb_SML_Reports::total_auto_links();
		$orphans     = count( MVweb_SML_Reports::orphans( 1000 ) );
		$index       = MVweb_SML_Reports::index_status();
		$page_url    = admin_url( 'admin.php?page=' . MVweb_SML_Admin::PAGE_SLUG );

		// Inline styles: plugin.css is not enqueued on the WP dashboard
		// (index.php). Use native `button-secondary` for the action link —
		// that's the stock WP admin class guaranteed to be available here.
		$item_style  = 'display:flex;flex-direction:column;padding:10px 12px;background:#f6f7f7;border-radius:4px;';
		$list_style  = 'display:grid;grid-template-columns:repeat(2,1fr);gap:10px;margin:0 0 10px;padding:0;list-style:none;';
		$value_style = 'font-size:18px;color:#14161b;';
		$label_style = 'font-size:12px;color:#646970;';
		?>
		<ul style="<?php echo esc_attr( $list_style ); ?>">
			<li style="<?php echo esc_attr( $item_style ); ?>">
				<strong style="<?php echo esc_attr( $value_style ); ?>"><?php echo esc_html( number_format_i18n( $total_posts ) ); ?></strong>
				<span style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'supported posts', 'mvweb-smart-links' ); ?></span>
			</li>
			<li style="<?php echo esc_attr( $item_style ); ?>">
				<strong style="<?php echo esc_attr( $value_style ); ?>"><?php echo esc_html( number_format_i18n( $total_links ) ); ?></strong>
				<span style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'internal links', 'mvweb-smart-links' ); ?></span>
			</li>
			<li style="<?php echo esc_attr( $item_style ); ?>">
				<strong style="<?php echo esc_attr( $value_style ); ?>"><?php echo esc_html( number_format_i18n( $orphans ) ); ?></strong>
				<span style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'orphan pages', 'mvweb-smart-links' ); ?></span>
			</li>
			<li style="<?php echo esc_attr( $item_style ); ?>">
				<strong style="<?php echo esc_attr( $value_style ); ?>"><?php echo esc_html( number_format_i18n( $index['dirty'] ) ); ?></strong>
				<span style="<?php echo esc_attr( $label_style ); ?>"><?php esc_html_e( 'pending in index', 'mvweb-smart-links' ); ?></span>
			</li>
		</ul>
		<p>
			<a class="button button-secondary" href="<?php echo esc_url( $page_url ); ?>">
				<?php esc_html_e( 'Open Smart Links', 'mvweb-smart-links' ); ?>
			</a>
		</p>
		<?php
	}
}
