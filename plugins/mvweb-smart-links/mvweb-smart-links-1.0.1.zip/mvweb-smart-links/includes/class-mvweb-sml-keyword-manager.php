<?php
/**
 * Keyword manager: CRUD operations on the `_keywords` table.
 *
 * Pure data-access layer. Editor metabox (admin/class-mvweb-sml-metabox.php)
 * and the AJAX endpoints in MVweb_SML_Admin call into this class — they do not
 * touch $wpdb directly.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Keyword_Manager
 *
 * @since 1.0.0
 */
class MVweb_SML_Keyword_Manager {

	/**
	 * Whitelist of allowed `source` column values.
	 *
	 * @var array
	 */
	const ALLOWED_SOURCES = array( 'manual', 'yoast', 'rankmath', 'aioseo', 'auto', 'gsc', 'yandex' );

	/**
	 * Maximum keyword length (mirrors VARCHAR(255) column).
	 */
	const MAX_KEYWORD_LENGTH = 255;

	/**
	 * Insert a new keyword for a post.
	 *
	 * Duplicate detection: matching (post_id, keyword) returns the existing id
	 * instead of creating a second row.
	 *
	 * @since 1.0.0
	 * @param int    $post_id  Post ID.
	 * @param string $keyword  Keyword text.
	 * @param array  $synonyms Optional list of synonym strings.
	 * @param string $source   One of self::ALLOWED_SOURCES.
	 * @return int|false Inserted (or existing) row id, or false on failure.
	 */
	public static function add( $post_id, $keyword, $synonyms = array(), $source = 'manual' ) {
		global $wpdb;

		$post_id = (int) $post_id;
		$keyword = is_string( $keyword ) ? trim( wp_strip_all_tags( $keyword ) ) : '';

		if ( $post_id <= 0 || '' === $keyword ) {
			return false;
		}

		if ( mb_strlen( $keyword, 'UTF-8' ) > self::MAX_KEYWORD_LENGTH ) {
			$keyword = mb_substr( $keyword, 0, self::MAX_KEYWORD_LENGTH, 'UTF-8' );
		}

		$source = in_array( $source, self::ALLOWED_SOURCES, true ) ? $source : 'manual';
		$table  = mvweb_sml_table( 'keywords' );

		// De-dup: case-insensitive match by post_id + keyword.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$existing = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT id FROM `{$table}` WHERE post_id = %d AND keyword = %s LIMIT 1",
				$post_id,
				$keyword
			)
		);
		// phpcs:enable
		if ( $existing ) {
			return (int) $existing;
		}

		$now     = current_time( 'mysql' );
		$encoded = wp_json_encode( self::sanitize_synonyms( $synonyms ) );
		if ( false === $encoded ) {
			$encoded = '[]';
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$ok = $wpdb->insert(
			$table,
			array(
				'post_id'    => $post_id,
				'keyword'    => $keyword,
				'synonyms'   => $encoded,
				'source'     => $source,
				'created_at' => $now,
				'updated_at' => $now,
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( ! $ok ) {
			return false;
		}

		return (int) $wpdb->insert_id;
	}

	/**
	 * Update an existing keyword row.
	 *
	 * The `$post_id` argument is required to prevent IDOR — the WHERE clause
	 * scopes the update to (id, post_id), so an editor of post A cannot
	 * modify a keyword belonging to post B by guessing its row id.
	 *
	 * @since 1.0.0
	 * @param int   $id      Row id.
	 * @param int   $post_id Owning post id (must match the row).
	 * @param array $data    Mutable fields: keyword, synonyms, source.
	 * @return bool True if at least one row was updated.
	 */
	public static function update( $id, $post_id, array $data ) {
		global $wpdb;

		$id      = (int) $id;
		$post_id = (int) $post_id;
		if ( $id <= 0 || $post_id <= 0 ) {
			return false;
		}

		$update = array();
		$format = array();

		if ( isset( $data['keyword'] ) ) {
			$kw = trim( wp_strip_all_tags( (string) $data['keyword'] ) );
			if ( '' === $kw ) {
				return false;
			}
			if ( mb_strlen( $kw, 'UTF-8' ) > self::MAX_KEYWORD_LENGTH ) {
				$kw = mb_substr( $kw, 0, self::MAX_KEYWORD_LENGTH, 'UTF-8' );
			}
			$update['keyword'] = $kw;
			$format[]          = '%s';
		}

		if ( array_key_exists( 'synonyms', $data ) ) {
			$encoded = wp_json_encode( self::sanitize_synonyms( $data['synonyms'] ) );
			if ( false === $encoded ) {
				$encoded = '[]';
			}
			$update['synonyms'] = $encoded;
			$format[]           = '%s';
		}

		if ( isset( $data['source'] ) && in_array( $data['source'], self::ALLOWED_SOURCES, true ) ) {
			$update['source'] = $data['source'];
			$format[]         = '%s';
		}

		if ( empty( $update ) ) {
			return false;
		}

		$update['updated_at'] = current_time( 'mysql' );
		$format[]             = '%s';

		$table = mvweb_sml_table( 'keywords' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$result = $wpdb->update(
			$table,
			$update,
			array(
				'id'      => $id,
				'post_id' => $post_id,
			),
			$format,
			array( '%d', '%d' )
		);

		return false !== $result && $result > 0;
	}

	/**
	 * Delete a keyword row.
	 *
	 * The `$post_id` argument is required to prevent IDOR — see update().
	 *
	 * @since 1.0.0
	 * @param int $id      Row id.
	 * @param int $post_id Owning post id (must match the row).
	 * @return bool True on success.
	 */
	public static function delete( $id, $post_id ) {
		global $wpdb;

		$id      = (int) $id;
		$post_id = (int) $post_id;
		if ( $id <= 0 || $post_id <= 0 ) {
			return false;
		}

		$table = mvweb_sml_table( 'keywords' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$deleted = $wpdb->delete(
			$table,
			array(
				'id'      => $id,
				'post_id' => $post_id,
			),
			array( '%d', '%d' )
		);

		return $deleted > 0;
	}

	/**
	 * Fetch all keywords assigned to a post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return array<int, array{id:int,post_id:int,keyword:string,synonyms:array,source:string}>
	 */
	public static function get_for_post( $post_id ) {
		global $wpdb;

		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return array();
		}

		$table = mvweb_sml_table( 'keywords' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, post_id, keyword, synonyms, source FROM `{$table}` WHERE post_id = %d ORDER BY id ASC",
				$post_id
			),
			ARRAY_A
		);
		// phpcs:enable

		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[] = array(
				'id'       => (int) $row['id'],
				'post_id'  => (int) $row['post_id'],
				'keyword'  => (string) $row['keyword'],
				'synonyms' => self::decode_synonyms( $row['synonyms'] ),
				'source'   => (string) $row['source'],
			);
		}

		/**
		 * Filter the list of keywords returned for a post.
		 *
		 * Consumed by the Linker (anchor resolution for manual targets),
		 * the admin metabox and the REST API. Each row is an associative
		 * array with `id`, `post_id`, `keyword`, `synonyms` and `source`
		 * keys. Return an empty array to hide keywords for the post.
		 *
		 * @since 1.0.0
		 *
		 * @example
		 *     add_filter( 'mvweb_sml_keywords', function ( $rows, $post_id ) {
		 *         return array_filter( $rows, fn( $r ) => 'manual' === $r['source'] );
		 *     }, 10, 2 );
		 *
		 * @param array<int, array<string, mixed>> $out     Keyword rows.
		 * @param int                              $post_id Post ID.
		 */
		return (array) apply_filters( 'mvweb_sml_keywords', $out, $post_id );
	}

	/**
	 * Fetch keywords for many posts in a single query.
	 *
	 * Batch companion to get_for_post(): the frontend Linker needs the keyword
	 * rows of every candidate target, and calling get_for_post() in a loop is a
	 * classic N+1. Returns a map keyed by post_id; posts with no keywords are
	 * simply absent. The per-post `mvweb_sml_keywords` filter is applied so the
	 * result is identical to calling get_for_post() individually.
	 *
	 * @since 1.0.0
	 * @param array<int, int> $post_ids Post IDs.
	 * @return array<int, array<int, array{id:int,post_id:int,keyword:string,synonyms:array,source:string}>>
	 */
	public static function get_for_posts( array $post_ids ) {
		global $wpdb;

		$ids = array_values( array_unique( array_filter( array_map( 'intval', $post_ids ) ) ) );
		if ( empty( $ids ) ) {
			return array();
		}

		$table        = mvweb_sml_table( 'keywords' );
		$placeholders = implode( ', ', array_fill( 0, count( $ids ), '%d' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, post_id, keyword, synonyms, source FROM `{$table}` WHERE post_id IN ({$placeholders}) ORDER BY post_id ASC, id ASC",
				$ids
			),
			ARRAY_A
		);
		// phpcs:enable

		$grouped = array();
		foreach ( (array) $rows as $row ) {
			$pid               = (int) $row['post_id'];
			$grouped[ $pid ][] = array(
				'id'       => (int) $row['id'],
				'post_id'  => $pid,
				'keyword'  => (string) $row['keyword'],
				'synonyms' => self::decode_synonyms( $row['synonyms'] ),
				'source'   => (string) $row['source'],
			);
		}

		$out = array();
		foreach ( $ids as $pid ) {
			$post_rows   = isset( $grouped[ $pid ] ) ? $grouped[ $pid ] : array();
			$out[ $pid ] = (array) apply_filters( 'mvweb_sml_keywords', $post_rows, $pid );
		}

		return $out;
	}

	/**
	 * Find keywords assigned to more than one post (cannibalisation seed).
	 *
	 * @since 1.0.0
	 * @return array<int, array{keyword:string, post_ids:array<int,int>}>
	 */
	public static function find_conflicts() {
		global $wpdb;

		$table = mvweb_sml_table( 'keywords' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				'SELECT keyword, GROUP_CONCAT(DISTINCT post_id) AS post_ids
				 FROM %i
				 GROUP BY keyword
				 HAVING COUNT(DISTINCT post_id) > 1',
				$table
			),
			ARRAY_A
		);
		// phpcs:enable

		$out = array();
		foreach ( (array) $rows as $row ) {
			$ids = array_filter( array_map( 'intval', explode( ',', (string) $row['post_ids'] ) ) );
			if ( count( $ids ) < 2 ) {
				continue;
			}
			$out[] = array(
				'keyword'  => (string) $row['keyword'],
				'post_ids' => array_values( array_unique( $ids ) ),
			);
		}

		return $out;
	}

	/**
	 * Find conflicts for a single keyword (used after add() to surface a
	 * warning to the editor).
	 *
	 * @since 1.0.0
	 * @param string $keyword         Keyword text.
	 * @param int    $exclude_post_id Post ID to exclude from the result set.
	 * @return array<int, int> List of other post IDs that share this keyword.
	 */
	public static function conflicts_for_keyword( $keyword, $exclude_post_id = 0 ) {
		global $wpdb;

		$keyword = is_string( $keyword ) ? trim( wp_strip_all_tags( $keyword ) ) : '';
		if ( '' === $keyword ) {
			return array();
		}

		$table = mvweb_sml_table( 'keywords' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT post_id FROM `{$table}` WHERE keyword = %s AND post_id <> %d",
				$keyword,
				(int) $exclude_post_id
			)
		);
		// phpcs:enable

		return array_values( array_filter( array_map( 'intval', (array) $ids ) ) );
	}

	/**
	 * Suggest keywords for a post via the Analyzer.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @param int $limit   Maximum suggestions to return.
	 * @return array<int, string>
	 */
	public static function suggest( $post_id, $limit = 10 ) {
		if ( ! class_exists( 'MVweb_SML_Analyzer' ) ) {
			return array();
		}
		$exclude = class_exists( 'MVweb_SML_Indexer' )
			? MVweb_SML_Indexer::corpus_common_words()
			: array();
		return MVweb_SML_Analyzer::suggest_keywords( (int) $post_id, (int) $limit, $exclude );
	}

	// ─────────────────────────────────────────────────────────────────────
	// Internals
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Coerce arbitrary input into a clean list of synonym strings.
	 *
	 * Accepts arrays or comma-separated strings; trims whitespace; drops
	 * empties; enforces UTF-8 length limit.
	 *
	 * @since 1.0.0
	 * @param mixed $value Raw input.
	 * @return array<int, string>
	 */
	private static function sanitize_synonyms( $value ) {
		if ( is_string( $value ) ) {
			$value = preg_split( '/\s*,\s*/', $value );
		}
		if ( ! is_array( $value ) ) {
			return array();
		}

		$out = array();
		foreach ( $value as $item ) {
			if ( ! is_scalar( $item ) ) {
				continue;
			}
			$item = trim( wp_strip_all_tags( (string) $item ) );
			if ( '' === $item ) {
				continue;
			}
			if ( mb_strlen( $item, 'UTF-8' ) > self::MAX_KEYWORD_LENGTH ) {
				$item = mb_substr( $item, 0, self::MAX_KEYWORD_LENGTH, 'UTF-8' );
			}
			$out[] = $item;
		}

		return array_values( array_unique( $out ) );
	}

	/**
	 * Decode the JSON synonyms column into a PHP array.
	 *
	 * @since 1.0.0
	 * @param string|null $value Raw column value.
	 * @return array<int, string>
	 */
	private static function decode_synonyms( $value ) {
		if ( ! is_string( $value ) || '' === $value ) {
			return array();
		}
		$decoded = json_decode( $value, true );
		if ( ! is_array( $decoded ) ) {
			return array();
		}
		$out = array();
		foreach ( $decoded as $item ) {
			if ( is_scalar( $item ) ) {
				$out[] = (string) $item;
			}
		}
		return $out;
	}
}
