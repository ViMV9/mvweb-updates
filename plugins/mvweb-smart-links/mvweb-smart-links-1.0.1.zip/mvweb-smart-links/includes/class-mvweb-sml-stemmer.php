<?php
/**
 * Lightweight Russian stemmer + morphological pattern builder.
 *
 * The frontend linker matches a keyword against running prose. Russian words
 * inflect heavily (case, number, gender), so a literal match misses most real
 * occurrences. This class strips inflectional endings from a word so a keyword
 * stem can match every case form, and builds a regex that does the same against
 * a text node while still returning a single contiguous match for splitText().
 *
 * Deliberately MODERATE: only inflectional endings (case/number/verb/participle)
 * are removed — derivational suffixes (ость, ив, ев) are kept on purpose so a
 * keyword like «ремонт» does not also catch «ремонтный». This keeps false
 * positives low. Based on the Snowball Russian algorithm, RV region only.
 *
 * No external dependencies, no dictionaries — pure suffix rules, PHP 7.4+.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Stemmer
 *
 * @since 1.0.0
 */
class MVweb_SML_Stemmer {

	/**
	 * Minimum stem length (UTF-8 chars). Shorter stems would match far too much,
	 * so the original word is used verbatim instead.
	 */
	const MIN_STEM_LEN = 3;

	/**
	 * Inflectional tail allowed after a stem in the match pattern.
	 *
	 * A real Russian case ending starts with a vowel or a soft/hard sign and is
	 * at most 3 letters (ому/ыми/ями…). Requiring the first tail letter to be a
	 * vowel/sign is what separates an ENDING from a derivational SUFFIX: «ремонт»
	 * + «а»→«ремонта» (ending) is allowed, but «ремонт» + «ный» (suffix starts
	 * with consonant «н») is rejected — keeping the stemming moderate. The empty
	 * tail is allowed so the bare nominative still matches.
	 */
	const TAIL = '(?:[аеёиоуыэюяьъ][а-яё]{0,2})?';

	/**
	 * Short function words allowed to sit between two phrase words, e.g.
	 * «ремонт iPhone» still matches «ремонт этого iPhone». One word max — the
	 * bridge is optional and non-repeating to avoid linking across half a
	 * sentence. Kept small and curated rather than pulled from the full
	 * stopword list (which contains long words that would over-match).
	 *
	 * @var string[]
	 */
	const BRIDGE_WORDS = array(
		'в',
		'во',
		'на',
		'по',
		'за',
		'из',
		'до',
		'от',
		'над',
		'под',
		'при',
		'про',
		'для',
		'без',
		'и',
		'или',
		'же',
		'ли',
		'не',
		'то',
		'это',
		'этот',
		'этого',
		'этой',
		'этому',
		'этим',
		'этих',
		'эту',
		'нового',
		'новый',
		'новых',
		'своего',
		'своих',
		'вашего',
		'вашем',
	);

	/**
	 * Vowels used to locate the RV region (everything after the first vowel).
	 */
	const VOWELS = array( 'а', 'е', 'ё', 'и', 'о', 'у', 'ы', 'э', 'ю', 'я' );

	/**
	 * Inflectional endings, longest first so the greedy strip removes the
	 * fullest ending. Grouped by category for readability; order within the
	 * merged list is enforced by usort on length.
	 *
	 * Intentionally EXCLUDES derivational suffixes (ость/ность/ив/ев/тель…)
	 * to stay moderate.
	 *
	 * @var string[]|null
	 */
	private static $endings = null;

	/**
	 * Reduce a single lowercase UTF-8 word to its inflectional stem.
	 *
	 * Latin/numeric words are returned unchanged — Russian morphology does not
	 * apply, and brands (iPhone, PDF) should match literally.
	 *
	 * @since 1.0.0
	 * @param string $word Lowercase word.
	 * @return string Stem (never shorter than the original's first MIN_STEM_LEN
	 *                chars unless the word itself is shorter).
	 */
	public static function stem( $word ) {
		$word = (string) $word;
		if ( '' === $word ) {
			return '';
		}

		// Only stem Cyrillic words; leave everything else (latin, digits) as is.
		if ( ! preg_match( '/^[а-яё]+$/u', $word ) ) {
			return $word;
		}

		$rv_start = self::rv_offset( $word );
		if ( $rv_start < 0 ) {
			return $word;
		}

		$head = mb_substr( $word, 0, $rv_start, 'UTF-8' );
		$rv   = mb_substr( $word, $rv_start, null, 'UTF-8' );

		foreach ( self::get_endings() as $ending ) {
			$elen = mb_strlen( $ending, 'UTF-8' );
			if ( mb_strlen( $rv, 'UTF-8' ) < $elen ) {
				continue;
			}
			if ( mb_substr( $rv, -$elen, null, 'UTF-8' ) === $ending ) {
				$rv = mb_substr( $rv, 0, -$elen, 'UTF-8' );
				break;
			}
		}

		// Drop a trailing soft/hard sign left after the ending strip.
		$stem = $head . $rv;
		$stem = preg_replace( '/[ьъ]$/u', '', $stem );

		// Guard against over-short stems matching half the dictionary.
		if ( mb_strlen( $stem, 'UTF-8' ) < self::MIN_STEM_LEN ) {
			return $word;
		}

		return $stem;
	}

	/**
	 * Build the regex body that matches a keyword morphologically inside prose.
	 *
	 * Each Cyrillic content word becomes `stem[\p{L}]*` (stem + any ending).
	 * Latin words match literally. Between adjacent content words an optional
	 * single function word (BRIDGE_WORDS) is allowed. The whole pattern matches
	 * one contiguous span from the first to the last word — required because the
	 * caller feeds $m[0][1]/$m[0][0] straight into splitText().
	 *
	 * The returned string has NO delimiters and NO lookaround — the caller wraps
	 * it with its own word-boundary lookarounds and `/iu` flags.
	 *
	 * @since 1.0.0
	 * @param string $keyword Raw keyword (possibly multi-word).
	 * @return string Regex body, or a literal preg_quote fallback if empty.
	 */
	public static function build_morph_pattern( $keyword ) {
		$keyword = trim( (string) $keyword );
		if ( '' === $keyword ) {
			return '';
		}

		// Split on whitespace; keep word tokens only. With the /u flag preg_split
		// returns false on invalid UTF-8 (corrupt DB data) — fall back to a
		// literal match so the keyword is never silently dropped.
		$words = preg_split( '/\s+/u', mb_strtolower( $keyword, 'UTF-8' ) );
		if ( false === $words ) {
			return preg_quote( $keyword, '/' );
		}
		$words = array_values(
			array_filter(
				$words,
				static function ( $w ) {
					return '' !== $w;
				}
			)
		);

		if ( empty( $words ) ) {
			return preg_quote( $keyword, '/' );
		}

		$word_patterns = array();
		foreach ( $words as $w ) {
			$word_patterns[] = self::word_pattern( $w );
		}

		// Join content words with an optional one-word bridge. Single-word
		// keywords get no bridge at all.
		return implode( self::bridge_pattern(), $word_patterns );
	}

	/**
	 * Build the sub-pattern for one word.
	 *
	 * Cyrillic → stem + open ending; latin/other → literal (case-insensitive
	 * handled by the caller's /i flag).
	 *
	 * @since 1.0.0
	 * @param string $word Lowercase word.
	 * @return string
	 */
	private static function word_pattern( $word ) {
		if ( preg_match( '/^[а-яё]+$/u', $word ) ) {
			$stem = self::stem( $word );

			// Fleeting-vowel fix: words like «чехол»/«замок»/«палец» drop the
			// last stem vowel in oblique cases («чехла», «замка», «пальца»).
			// Stemming the nominative keeps that vowel, so make the final о/е/ё
			// of the stem optional in the pattern. Cheap, no dictionary, and
			// only fires when the stem actually ends in such a vowel preceded by
			// a consonant — so it does not loosen ordinary stems.
			// Fleeting vowel sits between the last two consonants of the stem:
			// «чехол»→«чехл(а)», «замок»→«замк(а)», «палец»→«пальц(а)». If the
			// stem ends «consonant + о/е + consonant», make that vowel optional
			// so both the nominative (with vowel) and oblique forms (without)
			// match. Cheap, dictionary-free, and narrow enough not to loosen
			// ordinary stems.
			$len = mb_strlen( $stem, 'UTF-8' );
			if ( $len >= self::MIN_STEM_LEN + 1 ) {
				$c1 = mb_substr( $stem, -1, null, 'UTF-8' ); // last char.
				$c2 = mb_substr( $stem, -2, 1, 'UTF-8' );    // vowel?
				$c3 = mb_substr( $stem, -3, 1, 'UTF-8' );    // consonant?
				if ( ! in_array( $c1, self::VOWELS, true )
					&& in_array( $c2, array( 'о', 'е', 'ё' ), true )
					&& ! in_array( $c3, self::VOWELS, true ) ) {
					$base = preg_quote( mb_substr( $stem, 0, -2, 'UTF-8' ), '/' );
					return $base . preg_quote( $c2, '/' ) . '?' . preg_quote( $c1, '/' ) . self::TAIL;
				}
			}

			// Stem + a bounded inflectional tail. The tail is capped at 3 letters
			// so a stem like «ремонт» matches its case forms («ремонта»,
			// «ремонтом») but NOT derivations that add a suffix + ending
			// («ремонтный» = н+ый, 3 letters but starting with a consonant the
			// tail rule rejects). See TAIL for the exact shape.
			return preg_quote( $stem, '/' ) . self::TAIL;
		}

		// Latin / digits / mixed — match literally.
		return preg_quote( $word, '/' );
	}

	/**
	 * The optional one-word bridge inserted between adjacent phrase words.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	private static function bridge_pattern() {
		static $cache = null;
		if ( null !== $cache ) {
			return $cache;
		}

		$alts = implode(
			'|',
			array_map(
				static function ( $w ) {
					return preg_quote( $w, '/' );
				},
				self::BRIDGE_WORDS
			)
		);

		// \s+ between words, optionally a single function word + its trailing \s+.
		$cache = '\s+(?:(?:' . $alts . ')\s+)?';
		return $cache;
	}

	/**
	 * Locate the RV region start (char index after the first vowel).
	 *
	 * @since 1.0.0
	 * @param string $word Lowercase Cyrillic word.
	 * @return int Char offset of RV, or -1 if no vowel found.
	 */
	private static function rv_offset( $word ) {
		$chars = mb_str_split( $word, 1, 'UTF-8' );
		foreach ( $chars as $i => $ch ) {
			if ( in_array( $ch, self::VOWELS, true ) ) {
				return $i + 1;
			}
		}
		return -1;
	}

	/**
	 * Inflectional endings list, sorted longest-first.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	private static function get_endings() {
		if ( null !== self::$endings ) {
			return self::$endings;
		}

		// MODERATE inflectional endings. Each ending begins at a vowel (or a
		// soft/hard sign) so the strip never bites into a root consonant — this
		// is the rule that keeps «телефоны»→«телефон», not «телефо». Endings
		// that would require removing a consonant (e.g. nominative «ол» in
		// «чехол» with a fleeting vowel) are NOT listed; such words simply keep
		// a slightly longer stem and still match their own inflected forms via
		// the trailing `[\p{L}]*` in the pattern.
		$list = array(
			// Participle / gerund (all start with и/ы/у/ю/а/я/в+vowel).
			'ившись',
			'ывшись',
			'ивший',
			'ывший',
			'ующий',
			'ивши',
			'ывши',
			'ущий',
			'ющий',
			'ящий',
			'ивш',
			'ывш',
			// Verb (vowel-initial only).
			'ейте',
			'уйте',
			'ете',
			'ите',
			'ишь',
			'ешь',
			'ать',
			'ять',
			'ить',
			'еть',
			'ыть',
			'ует',
			'уют',
			'ает',
			'ают',
			'ило',
			'ыло',
			'ала',
			'яла',
			'ена',
			'ено',
			'ем',
			'ет',
			'ют',
			'им',
			'ит',
			'ал',
			'ял',
			'ел',
			'ил',
			'ыл',
			// Noun / adjective, case & number (vowel- or sign-initial).
			'иями',
			'ями',
			'ами',
			'иях',
			'ого',
			'его',
			'ому',
			'ему',
			'ыми',
			'ими',
			'ая',
			'яя',
			'ою',
			'ею',
			'ую',
			'юю',
			'ых',
			'их',
			'ое',
			'ее',
			'ый',
			'ий',
			'ой',
			'ом',
			'ым',
			'ах',
			'ях',
			'ов',
			'ев',
			'ью',
			'ия',
			'ие',
			'ии',
			'ье',
			'ьё',
			'а',
			'е',
			'и',
			'о',
			'у',
			'ы',
			'ю',
			'я',
			'й',
			'ь',
			'ъ',
		);

		// Dedupe and sort longest-first so the greedy strip removes the full
		// ending rather than a short suffix of it.
		$list = array_values( array_unique( $list ) );
		usort(
			$list,
			static function ( $a, $b ) {
				return mb_strlen( $b, 'UTF-8' ) <=> mb_strlen( $a, 'UTF-8' );
			}
		);

		self::$endings = $list;
		return self::$endings;
	}
}
