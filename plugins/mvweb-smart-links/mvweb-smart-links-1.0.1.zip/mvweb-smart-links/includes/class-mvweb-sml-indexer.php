<?php
/**
 * Background indexer with dirty tracking and cron batches.
 *
 * Workflow:
 *  - On `save_post` (for supported post types) the row in `_index` is marked
 *    `dirty = 1`.
 *  - The cron handler (`mvweb_sml_cron_indexer`, every 5 min) takes a small
 *    batch (50 rows), runs them through the Analyzer and updates the index
 *    row with the resulting prominent-words JSON and `dirty = 0`.
 *  - The admin "Run reindex" button drives the same pipeline through three
 *    AJAX endpoints (start / step / progress) — see MVweb_SML_Admin.
 *
 * Concurrency: a lock prevents two parallel cron runs from racing on the
 * same batch. The lock is atomic (`wp_cache_add` on object cache, falling
 * back to `add_option` which uses a UNIQUE constraint in the DB).
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Indexer
 *
 * @since 1.0.0
 */
class MVweb_SML_Indexer {

	/**
	 * Singleton instance.
	 *
	 * @var MVweb_SML_Indexer|null
	 */
	private static $instance = null;

	/**
	 * Default batch size for cron and AJAX step.
	 */
	const BATCH_SIZE = 50;

	/**
	 * Lock key shared across object cache and add_option fallback.
	 */
	const LOCK_KEY = 'mvweb_sml_indexer_lock';

	/**
	 * Object cache group.
	 */
	const CACHE_GROUP = 'mvweb_sml';

	/**
	 * Stale-lock threshold for the add_option fallback (10 minutes).
	 */
	const LOCK_STALE_SECONDS = 600;

	/**
	 * Transient holding the set of corpus-generic prominent words.
	 */
	const COMMON_WORDS_CACHE = 'mvweb_sml_common_words';

	/**
	 * Transient holding the corpus document-frequency map { word => posts, total }.
	 */
	const DOC_FREQ_CACHE = 'mvweb_sml_doc_freq';

	/**
	 * Get the shared instance.
	 *
	 * @since 1.0.0
	 * @return MVweb_SML_Indexer
	 */
	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
			self::$instance->register_hooks();
		}

		return self::$instance;
	}

	/**
	 * Wire up hooks. Called once from get_instance().
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function register_hooks() {
		add_action( 'save_post', array( $this, 'on_save_post' ), 10, 2 );
		add_action( 'deleted_post', array( $this, 'on_deleted_post' ) );
		add_action( 'mvweb_sml_index_complete', array( __CLASS__, 'flush_common_words_cache' ) );
	}

	/**
	 * Set of prominent words that are too generic to make good interlinking
	 * anchors — i.e. words that are "prominent" in a large share of posts
	 * (e.g. "настройки", "требуется"). Used to filter keyword suggestions.
	 *
	 * Computed from the `_index` document frequencies and cached for a day;
	 * the cache is dropped whenever indexing completes.
	 *
	 * @since 1.0.0
	 * @return array<string, bool> word => true lookup.
	 */
	public static function corpus_common_words() {
		$cached = get_transient( self::COMMON_WORDS_CACHE );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		$freq  = self::document_frequencies();
		$total = (int) $freq['total'];
		$df    = $freq['df'];

		$common = array();

		// A word prominent in more than 35% of posts is corpus filler, not a
		// distinctive topic — exclude it from suggestions. (Skipped on a tiny
		// corpus: document_frequencies() returns an empty map under 20 posts.)
		if ( $total >= 20 && ! empty( $df ) ) {
			$threshold = (int) ceil( $total * 0.35 );
			foreach ( $df as $word => $count ) {
				if ( $count >= $threshold ) {
					$common[ $word ] = true;
				}
			}
		}

		set_transient( self::COMMON_WORDS_CACHE, $common, DAY_IN_SECONDS );
		return $common;
	}

	/**
	 * Corpus document frequencies over the clean `_index` prominent maps.
	 *
	 * Returns how many indexed posts each prominent word appears in, plus the
	 * corpus size, cached for a day and dropped on reindex. Reused by both the
	 * corpus-common-words filter and the IDF component of suggestion scoring —
	 * one scan, two consumers. On a corpus under 20 posts IDF is meaningless, so
	 * an empty map is returned (callers treat every word as equally rare).
	 *
	 * @since 1.0.0
	 * @return array{df: array<string, int>, total: int}
	 */
	public static function document_frequencies() {
		$cached = get_transient( self::DOC_FREQ_CACHE );
		if ( is_array( $cached ) && isset( $cached['df'], $cached['total'] ) && is_array( $cached['df'] ) ) {
			return $cached;
		}

		global $wpdb;
		$table = mvweb_sml_table( 'index' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$rows = $wpdb->get_col( $wpdb->prepare( "SELECT prominent FROM %i WHERE dirty = 0 AND prominent IS NOT NULL AND prominent <> ''", $table ) );
		// phpcs:enable

		$total = is_array( $rows ) ? count( $rows ) : 0;
		$df    = array();

		// IDF is meaningless on a tiny corpus — return an empty map under 20 posts.
		if ( $total >= 20 ) {
			foreach ( $rows as $json ) {
				$map = json_decode( (string) $json, true );
				if ( ! is_array( $map ) ) {
					continue;
				}
				foreach ( array_keys( $map ) as $word ) {
					$word = (string) $word;
					if ( '' === $word ) {
						continue;
					}
					$df[ $word ] = isset( $df[ $word ] ) ? $df[ $word ] + 1 : 1;
				}
			}
		}

		$result = array(
			'df'    => $df,
			'total' => $total,
		);

		set_transient( self::DOC_FREQ_CACHE, $result, DAY_IN_SECONDS );
		return $result;
	}

	/**
	 * Drop the corpus-common-words and document-frequency caches (both shift
	 * after a reindex).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function flush_common_words_cache() {
		delete_transient( self::COMMON_WORDS_CACHE );
		delete_transient( self::DOC_FREQ_CACHE );
	}

	// ─────────────────────────────────────────────────────────────────────
	// Dirty tracking
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * `save_post` hook callback.
	 *
	 * @since 1.0.0
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @return void
	 */
	public function on_save_post( $post_id, $post ) {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( ! ( $post instanceof WP_Post ) ) {
			return;
		}

		if ( ! in_array( $post->post_type, mvweb_sml_supported_post_types(), true ) ) {
			return;
		}

		$this->mark_dirty( (int) $post_id );
	}

	/**
	 * Remove deleted posts from the index table.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public function on_deleted_post( $post_id ) {
		global $wpdb;

		$table = mvweb_sml_table( 'index' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->delete( $table, array( 'post_id' => (int) $post_id ), array( '%d' ) );
	}

	/**
	 * Mark a single post as dirty (insert if missing).
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public function mark_dirty( $post_id ) {
		global $wpdb;

		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return;
		}

		$table = mvweb_sml_table( 'index' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query(
			$wpdb->prepare(
				"INSERT INTO `{$table}` (post_id, prominent, word_count, dirty, indexed_at)
				 VALUES (%d, NULL, 0, 1, NULL)
				 ON DUPLICATE KEY UPDATE dirty = 1",
				$post_id
			)
		);
		// phpcs:enable
	}

	/**
	 * Mark a single post as clean and persist its analysis result.
	 *
	 * @since 1.0.0
	 * @param int                $post_id    Post ID.
	 * @param array<string, int> $prominent  Prominent words map.
	 * @param int                $word_count Total word count.
	 * @return void
	 */
	public function mark_clean( $post_id, array $prominent, $word_count ) {
		global $wpdb;

		$table = mvweb_sml_table( 'index' );

		// Guard against false from wp_json_encode (broken UTF-8 in keys);
		// store an empty JSON object so subsequent json_decode() returns array().
		$encoded = wp_json_encode( $prominent );
		if ( false === $encoded ) {
			$encoded = '{}';
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->update(
			$table,
			array(
				'prominent'  => $encoded,
				'word_count' => max( 0, (int) $word_count ),
				'dirty'      => 0,
				'indexed_at' => current_time( 'mysql' ),
			),
			array( 'post_id' => (int) $post_id ),
			array( '%s', '%d', '%d', '%s' ),
			array( '%d' )
		);
	}

	/**
	 * Mark every supported post as dirty (full reindex starter).
	 *
	 * Uses `INSERT ... ON DUPLICATE KEY UPDATE` so that posts which never
	 * had an index row get one and existing rows get flipped back to dirty.
	 *
	 * @since 1.0.0
	 * @param array<int, string>|null $post_types Optional override; defaults
	 *                                            to supported post types.
	 * @return int Number of posts queued.
	 */
	public function mark_all_dirty( $post_types = null ) {
		global $wpdb;

		if ( null === $post_types || ! is_array( $post_types ) || empty( $post_types ) ) {
			$post_types = mvweb_sml_supported_post_types();
		}

		if ( empty( $post_types ) ) {
			return 0;
		}

		$table        = mvweb_sml_table( 'index' );
		$placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );

		// Pull all candidate post IDs first (cheap — IDs only).
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ({$placeholders})",
				$post_types
			)
		);
		// phpcs:enable

		$ids = array_map( 'intval', (array) $ids );
		if ( empty( $ids ) ) {
			return 0;
		}

		// Bulk upsert in chunks to keep the prepared statement reasonable.
		$chunks = array_chunk( $ids, 200 );
		foreach ( $chunks as $chunk ) {
			$values = array();
			foreach ( $chunk as $id ) {
				$values[] = $wpdb->prepare( '(%d, NULL, 0, 1, NULL)', $id );
			}
			$sql = "INSERT INTO `{$table}` (post_id, prominent, word_count, dirty, indexed_at)
				VALUES " . implode( ',', $values ) . '
				ON DUPLICATE KEY UPDATE dirty = 1';
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared
			$wpdb->query( $sql );
		}

		return count( $ids );
	}

	// ─────────────────────────────────────────────────────────────────────
	// Stats
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Total number of dirty rows still pending.
	 *
	 * @since 1.0.0
	 * @return int
	 */
	public function dirty_count() {
		global $wpdb;
		$table = mvweb_sml_table( 'index' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}` WHERE dirty = 1" );
	}

	/**
	 * Total number of indexed rows (dirty + clean).
	 *
	 * @since 1.0.0
	 * @return int
	 */
	public function total_count() {
		global $wpdb;
		$table = mvweb_sml_table( 'index' );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" );
	}

	// ─────────────────────────────────────────────────────────────────────
	// Batch processing
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Process a single batch of dirty rows.
	 *
	 * @since 1.0.0
	 * @param int $size Maximum rows per batch.
	 * @return array{processed:int, remaining:int}
	 */
	public function process_batch( $size = self::BATCH_SIZE ) {
		global $wpdb;

		$size  = max( 1, (int) $size );
		$table = mvweb_sml_table( 'index' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT post_id FROM `{$table}` WHERE dirty = 1 LIMIT %d",
				$size
			)
		);
		// phpcs:enable

		$processed = 0;
		foreach ( (array) $ids as $post_id ) {
			$post_id = (int) $post_id;
			$text    = MVweb_SML_Analyzer::extract_text( $post_id );
			$tokens  = MVweb_SML_Analyzer::tokenize( $text );

			$prominent = MVweb_SML_Analyzer::prominent_words( $tokens );

			// Count real words from the raw text, not the filtered token list.
			// Stop-words and short tokens are dropped by tokenize(), so counting
			// tokens would undercount by 20-40% and skew the auto max_links math
			// in the Linker (which derives a per-post cap from word_count).
			$word_count = MVweb_SML_DOM_Scanner::count_words( $text );

			$this->mark_clean( $post_id, $prominent, $word_count );

			if ( class_exists( 'MVweb_SML_Cache' ) ) {
				MVweb_SML_Cache::flush_post( $post_id );
			}

			++$processed;
		}

		return array(
			'processed' => $processed,
			'remaining' => $this->dirty_count(),
		);
	}

	// ─────────────────────────────────────────────────────────────────────
	// Cron handler with atomic lock
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Process one batch under the atomic lock and fire the completion hook.
	 *
	 * Shared by the cron callback and the admin AJAX "reindex" step so both
	 * paths hold the same lock — a manual reindex and a cron tick can no longer
	 * SELECT and process the same dirty rows twice. If the lock is already held
	 * the method returns a no-op result with `locked => true`; the AJAX JS loop
	 * keeps retrying while `remaining > 0`, so it simply waits out the sub-second
	 * window until the other run releases the lock.
	 *
	 * @since 1.0.0
	 * @param int $size Maximum rows per batch.
	 * @return array{processed:int, remaining:int, locked?:bool}
	 */
	public function run_batch_locked( $size = self::BATCH_SIZE ) {
		if ( ! $this->acquire_lock() ) {
			return array(
				'processed' => 0,
				'remaining' => $this->dirty_count(),
				'locked'    => true,
			);
		}

		try {
			$result = $this->process_batch( $size );

			// Fire ONLY when this run actually indexed something and emptied the
			// queue — otherwise every idle wp-cron tick (queue already empty,
			// processed = 0) would re-fire the hook, and the notice listener
			// would wipe each user's dismissal and re-raise the notice forever.
			if ( $result['processed'] > 0 && 0 === (int) $result['remaining'] ) {
				/**
				 * Fires after the indexer has drained the dirty queue.
				 *
				 * @since 1.0.0
				 */
				do_action( 'mvweb_sml_index_complete' );
			}

			return $result;
		} finally {
			$this->release_lock();
		}
	}

	/**
	 * Cron callback. Processes one batch under an atomic lock.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function cron_handler() {
		$this->run_batch_locked( self::BATCH_SIZE );
	}

	/**
	 * Try to acquire the indexer lock atomically.
	 *
	 * @since 1.0.0
	 * @return bool True if the lock is now held by this process.
	 */
	private function acquire_lock() {
		if ( wp_using_ext_object_cache() ) {
			// Object cache (memcached/redis) — atomic add with native TTL.
			return (bool) wp_cache_add( self::LOCK_KEY, time(), self::CACHE_GROUP, 5 * MINUTE_IN_SECONDS );
		}

		// add_option uses a UNIQUE constraint at the DB level → atomic.
		$acquired = add_option( self::LOCK_KEY, time(), '', 'no' );
		if ( $acquired ) {
			return true;
		}

		// Fallback path needs an explicit stale-lock check (no native TTL on DB).
		$existing = (int) get_option( self::LOCK_KEY, 0 );
		if ( $existing > 0 && ( time() - $existing ) > self::LOCK_STALE_SECONDS ) {
			delete_option( self::LOCK_KEY );
			return add_option( self::LOCK_KEY, time(), '', 'no' );
		}

		return false;
	}

	/**
	 * Release the indexer lock.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private function release_lock() {
		if ( wp_using_ext_object_cache() ) {
			wp_cache_delete( self::LOCK_KEY, self::CACHE_GROUP );
			return;
		}

		delete_option( self::LOCK_KEY );
	}
}
