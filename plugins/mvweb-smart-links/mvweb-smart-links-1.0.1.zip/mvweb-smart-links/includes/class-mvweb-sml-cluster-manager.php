<?php
/**
 * Cluster manager: CRUD for Pillar-Cluster groups.
 *
 * Backed by two tables:
 *  - `_clusters`       — one row per cluster (pillar_id, name).
 *  - `_cluster_posts`  — link table (cluster_id, post_id, role).
 *
 * Pure data-access layer. The Clusters tab and metabox call into this class
 * via the AJAX endpoints in MVweb_SML_Admin — they do not touch $wpdb directly.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Cluster_Manager
 *
 * @since 1.0.0
 */
class MVweb_SML_Cluster_Manager {

	/**
	 * Maximum cluster name length (mirrors VARCHAR(255) column).
	 */
	const MAX_NAME_LENGTH = 255;

	/**
	 * Allowed values for the role column.
	 */
	const ROLE_PILLAR = 'pillar';
	const ROLE_SPOKE  = 'spoke';

	/**
	 * Allowed interlinking presets for apply_preset().
	 *
	 * - hub_spoke:    pillar links to every spoke AND every spoke links back to
	 *                 the pillar (a bidirectional content hub).
	 * - reverse_silo: every spoke links up to the pillar only — link equity is
	 *                 concentrated on the pillar, which is not diluted by
	 *                 outbound links back down to the spokes.
	 */
	const PRESET_HUB_SPOKE    = 'hub_spoke';
	const PRESET_REVERSE_SILO = 'reverse_silo';

	// ─────────────────────────────────────────────────────────────────────
	// CRUD
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Create a new cluster around the given pillar post.
	 *
	 * Inserts one row into `_clusters` and one pillar row into `_cluster_posts`.
	 *
	 * @since 1.0.0
	 * @param int    $pillar_id Post ID that will play the pillar role.
	 * @param string $name      Cluster display name.
	 * @return int|WP_Error New cluster id, or WP_Error on validation failure.
	 */
	public static function create_cluster( $pillar_id, $name ) {
		global $wpdb;

		$pillar_id = (int) $pillar_id;
		if ( $pillar_id <= 0 || ! get_post( $pillar_id ) ) {
			return new WP_Error(
				'mvweb_sml_invalid_pillar',
				__( 'Invalid pillar post.', 'mvweb-smart-links' )
			);
		}

		$name = is_string( $name ) ? trim( wp_strip_all_tags( $name ) ) : '';
		if ( '' === $name ) {
			$name = (string) get_the_title( $pillar_id );
		}
		if ( '' === $name ) {
			return new WP_Error(
				'mvweb_sml_invalid_name',
				__( 'Cluster name is required.', 'mvweb-smart-links' )
			);
		}
		if ( mb_strlen( $name, 'UTF-8' ) > self::MAX_NAME_LENGTH ) {
			$name = mb_substr( $name, 0, self::MAX_NAME_LENGTH, 'UTF-8' );
		}

		$clusters_table = mvweb_sml_table( 'clusters' );
		$pivot_table    = mvweb_sml_table( 'cluster_posts' );
		$now            = current_time( 'mysql' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$ok = $wpdb->insert(
			$clusters_table,
			array(
				'pillar_id'  => $pillar_id,
				'name'       => $name,
				'created_at' => $now,
			),
			array( '%d', '%s', '%s' )
		);
		if ( ! $ok ) {
			return new WP_Error(
				'mvweb_sml_db_error',
				__( 'Failed to create cluster.', 'mvweb-smart-links' )
			);
		}

		$cluster_id = (int) $wpdb->insert_id;

		// Pillar row in the pivot table.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->insert(
			$pivot_table,
			array(
				'cluster_id' => $cluster_id,
				'post_id'    => $pillar_id,
				'role'       => self::ROLE_PILLAR,
			),
			array( '%d', '%d', '%s' )
		);

		return $cluster_id;
	}

	/**
	 * Add a spoke post to an existing cluster.
	 *
	 * Uses INSERT IGNORE-style behaviour: if the row already exists nothing
	 * happens and the method still reports success.
	 *
	 * @since 1.0.0
	 * @param int $cluster_id Cluster id.
	 * @param int $post_id    Post id of the spoke.
	 * @return bool True if the spoke was added (or already present).
	 */
	public static function add_spoke( $cluster_id, $post_id ) {
		global $wpdb;

		$cluster_id = (int) $cluster_id;
		$post_id    = (int) $post_id;
		if ( $cluster_id <= 0 || $post_id <= 0 ) {
			return false;
		}

		$cluster = self::get_cluster( $cluster_id );
		if ( ! $cluster ) {
			return false;
		}

		// Pillar cannot also be a spoke.
		if ( (int) $cluster['pillar_id'] === $post_id ) {
			return false;
		}

		if ( ! get_post( $post_id ) ) {
			return false;
		}

		$pivot_table = mvweb_sml_table( 'cluster_posts' );

		// Already a member?
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$existing = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT role FROM `{$pivot_table}` WHERE cluster_id = %d AND post_id = %d LIMIT 1",
				$cluster_id,
				$post_id
			)
		);
		// phpcs:enable
		if ( $existing ) {
			return true;
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$ok = $wpdb->insert(
			$pivot_table,
			array(
				'cluster_id' => $cluster_id,
				'post_id'    => $post_id,
				'role'       => self::ROLE_SPOKE,
			),
			array( '%d', '%d', '%s' )
		);

		return false !== $ok;
	}

	/**
	 * Remove a spoke from a cluster.
	 *
	 * Cannot remove the pillar — use delete_cluster() for that.
	 *
	 * Idempotent: returns true even if the spoke row is already absent, so
	 * double-clicks or race conditions do not surface as HTTP 500 on the
	 * Clusters AJAX endpoint.
	 *
	 * @since 1.0.0
	 * @param int $cluster_id Cluster id.
	 * @param int $post_id    Post id of the spoke.
	 * @return bool True when the row is gone (deleted now or was missing already).
	 */
	public static function remove_spoke( $cluster_id, $post_id ) {
		global $wpdb;

		$cluster_id = (int) $cluster_id;
		$post_id    = (int) $post_id;
		if ( $cluster_id <= 0 || $post_id <= 0 ) {
			return false;
		}

		$pivot_table = mvweb_sml_table( 'cluster_posts' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$deleted = $wpdb->delete(
			$pivot_table,
			array(
				'cluster_id' => $cluster_id,
				'post_id'    => $post_id,
				'role'       => self::ROLE_SPOKE,
			),
			array( '%d', '%d', '%s' )
		);

		// Treat "already gone" as success (idempotent behaviour).
		return false !== $deleted;
	}

	/**
	 * Delete an entire cluster (pillar + every spoke link row).
	 *
	 * Connections in the `_links` table are intentionally NOT touched —
	 * deleting a cluster does not unlink the underlying contextual links.
	 *
	 * @since 1.0.0
	 * @param int $cluster_id Cluster id.
	 * @return bool True if the cluster row was removed.
	 */
	public static function delete_cluster( $cluster_id ) {
		global $wpdb;

		$cluster_id = (int) $cluster_id;
		if ( $cluster_id <= 0 ) {
			return false;
		}

		$clusters_table = mvweb_sml_table( 'clusters' );
		$pivot_table    = mvweb_sml_table( 'cluster_posts' );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$wpdb->delete( $pivot_table, array( 'cluster_id' => $cluster_id ), array( '%d' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$deleted = $wpdb->delete( $clusters_table, array( 'id' => $cluster_id ), array( '%d' ) );

		return $deleted > 0;
	}

	// ─────────────────────────────────────────────────────────────────────
	// Read helpers
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Fetch a single cluster row.
	 *
	 * @since 1.0.0
	 * @param int $cluster_id Cluster id.
	 * @return array{id:int, pillar_id:int, name:string, created_at:string}|null
	 */
	public static function get_cluster( $cluster_id ) {
		global $wpdb;

		$cluster_id = (int) $cluster_id;
		if ( $cluster_id <= 0 ) {
			return null;
		}

		$table = mvweb_sml_table( 'clusters' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, pillar_id, name, created_at FROM `{$table}` WHERE id = %d LIMIT 1",
				$cluster_id
			),
			ARRAY_A
		);
		// phpcs:enable

		if ( ! $row ) {
			return null;
		}

		return array(
			'id'         => (int) $row['id'],
			'pillar_id'  => (int) $row['pillar_id'],
			'name'       => (string) $row['name'],
			'created_at' => (string) $row['created_at'],
		);
	}

	/**
	 * Return every cluster with its spoke list and basic health metrics.
	 *
	 * Pull strategy:
	 *  1. SELECT all clusters.
	 *  2. SELECT all pivot rows in one shot, group in PHP.
	 *  3. Compute health stats per cluster (spoke count, spokes that link
	 *     back to the pillar in `_links`, orphan spokes).
	 *
	 * @since 1.0.0
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_all() {
		global $wpdb;

		$clusters_table = mvweb_sml_table( 'clusters' );
		$pivot_table    = mvweb_sml_table( 'cluster_posts' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		$clusters = $wpdb->get_results(
			"SELECT id, pillar_id, name, created_at FROM `{$clusters_table}` ORDER BY name ASC",
			ARRAY_A
		);
		// phpcs:enable

		if ( empty( $clusters ) ) {
			return array();
		}

		// Map cluster_id => spoke ids.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		$pivot_rows = $wpdb->get_results(
			"SELECT cluster_id, post_id, role FROM `{$pivot_table}`",
			ARRAY_A
		);
		// phpcs:enable

		$by_cluster = array();
		foreach ( (array) $pivot_rows as $row ) {
			$cid = (int) $row['cluster_id'];
			$by_cluster[ $cid ][ (int) $row['post_id'] ] = (string) $row['role'];
		}

		$out = array();
		foreach ( $clusters as $cluster ) {
			$cid       = (int) $cluster['id'];
			$pillar_id = (int) $cluster['pillar_id'];
			$members   = isset( $by_cluster[ $cid ] ) ? $by_cluster[ $cid ] : array();

			$spokes    = array();
			$spoke_ids = array();
			foreach ( $members as $pid => $role ) {
				if ( self::ROLE_SPOKE !== $role ) {
					continue;
				}
				$spoke_ids[] = (int) $pid;
				$spokes[]    = array(
					'id'       => (int) $pid,
					'title'    => (string) get_the_title( (int) $pid ),
					'edit_url' => get_edit_post_link( (int) $pid ),
					'view_url' => get_permalink( (int) $pid ),
				);
			}

			$out[] = array(
				'id'           => $cid,
				'name'         => (string) $cluster['name'],
				'pillar_id'    => $pillar_id,
				'pillar_title' => (string) get_the_title( $pillar_id ),
				'pillar_edit'  => get_edit_post_link( $pillar_id ),
				'pillar_view'  => get_permalink( $pillar_id ),
				'created_at'   => (string) $cluster['created_at'],
				'spokes'       => $spokes,
				// Pillar id and spoke ids are already in memory — reuse them
				// to avoid the 3 extra queries that get_health() would issue.
				'health'       => self::compute_health_from( $pillar_id, $spoke_ids ),
			);
		}

		return $out;
	}

	/**
	 * List clusters that contain the given post (in any role).
	 *
	 * @since 1.0.0
	 * @param int $post_id Post id.
	 * @return array<int, array{cluster_id:int, name:string, role:string}>
	 */
	public static function get_for_post( $post_id ) {
		global $wpdb;

		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return array();
		}

		$clusters_table = mvweb_sml_table( 'clusters' );
		$pivot_table    = mvweb_sml_table( 'cluster_posts' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT c.id AS cluster_id, c.name, p.role
				 FROM `{$pivot_table}` AS p
				 INNER JOIN `{$clusters_table}` AS c ON c.id = p.cluster_id
				 WHERE p.post_id = %d
				 ORDER BY c.name ASC",
				$post_id
			),
			ARRAY_A
		);
		// phpcs:enable

		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[] = array(
				'cluster_id' => (int) $row['cluster_id'],
				'name'       => (string) $row['name'],
				'role'       => (string) $row['role'],
			);
		}
		return $out;
	}

	/**
	 * Compute health metrics for a cluster.
	 *
	 * Returns:
	 *  - spoke_count                 : number of spoke rows.
	 *  - spokes_linking_to_pillar    : spokes that have an outgoing row in
	 *                                  `_links` whose target is the pillar.
	 *  - orphan_spokes               : spokes that do NOT link to the pillar.
	 *
	 * The query joins the pivot table with `_links` once per cluster — fine
	 * for typical sites (≤ a few hundred clusters).
	 *
	 * @since 1.0.0
	 * @param int $cluster_id Cluster id.
	 * @return array{spoke_count:int, spokes_linking_to_pillar:int, orphan_spokes:int}
	 */
	public static function get_health( $cluster_id ) {
		global $wpdb;

		$cluster_id = (int) $cluster_id;
		$base       = array(
			'spoke_count'              => 0,
			'spokes_linking_to_pillar' => 0,
			'orphan_spokes'            => 0,
		);
		if ( $cluster_id <= 0 ) {
			return $base;
		}

		$cluster = self::get_cluster( $cluster_id );
		if ( ! $cluster ) {
			return $base;
		}

		$pivot_table = mvweb_sml_table( 'cluster_posts' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$spoke_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT post_id FROM `{$pivot_table}` WHERE cluster_id = %d AND role = %s",
				$cluster_id,
				self::ROLE_SPOKE
			)
		);
		// phpcs:enable

		$spoke_ids = array_filter( array_map( 'intval', (array) $spoke_ids ) );

		return self::compute_health_from( (int) $cluster['pillar_id'], $spoke_ids );
	}

	/**
	 * Compute health metrics from pre-fetched ids.
	 *
	 * Factored out so `get_all()` can reuse pillar id and spoke ids that are
	 * already in memory, avoiding the 3 extra queries per cluster that
	 * `get_health()` would otherwise issue (cluster row + spoke ids + COUNT).
	 *
	 * @since 1.0.0
	 * @param int   $pillar_id Pillar post id.
	 * @param int[] $spoke_ids Spoke post ids.
	 * @return array{spoke_count:int, spokes_linking_to_pillar:int, orphan_spokes:int}
	 */
	private static function compute_health_from( $pillar_id, array $spoke_ids ) {
		global $wpdb;

		$base = array(
			'spoke_count'              => 0,
			'spokes_linking_to_pillar' => 0,
			'orphan_spokes'            => 0,
		);

		$pillar_id = (int) $pillar_id;
		if ( $pillar_id <= 0 ) {
			return $base;
		}

		$spoke_ids   = array_values( array_filter( array_map( 'intval', $spoke_ids ) ) );
		$spoke_count = count( $spoke_ids );
		if ( 0 === $spoke_count ) {
			return $base;
		}

		$links_table  = mvweb_sml_table( 'links' );
		$placeholders = implode( ',', array_fill( 0, $spoke_count, '%d' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$linking = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT source_id)
				 FROM `{$links_table}`
				 WHERE target_id = %d
				   AND status IN ('approved','auto')
				   AND source_id IN ({$placeholders})",
				array_merge( array( $pillar_id ), $spoke_ids )
			)
		);
		// phpcs:enable

		return array(
			'spoke_count'              => $spoke_count,
			'spokes_linking_to_pillar' => $linking,
			'orphan_spokes'            => max( 0, $spoke_count - $linking ),
		);
	}

	/**
	 * Suggest spoke candidates for a cluster.
	 *
	 * Strategy: take the pillar's prominent words from the `_index` table,
	 * find other supported posts whose prominent map overlaps best, return
	 * the top N. Posts already in the cluster (in any role) are excluded.
	 *
	 * Pure-PHP scoring keeps the SQL trivial — fine for the typical
	 * "few thousand posts" target. For very large sites the scoring could be
	 * pushed into MySQL JSON functions later.
	 *
	 * @since 1.0.0
	 * @param int $cluster_id Cluster id.
	 * @param int $limit      Maximum number of suggestions.
	 * @return array<int, array{id:int, title:string, score:int}>
	 */
	public static function suggest_spokes( $cluster_id, $limit = 10 ) {
		global $wpdb;

		$cluster_id = (int) $cluster_id;
		$limit      = max( 1, (int) $limit );
		if ( $cluster_id <= 0 ) {
			return array();
		}

		$cluster = self::get_cluster( $cluster_id );
		if ( ! $cluster ) {
			return array();
		}

		$index_table = mvweb_sml_table( 'index' );
		$pivot_table = mvweb_sml_table( 'cluster_posts' );

		// Pillar prominent map.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$pillar_json = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT prominent FROM `{$index_table}` WHERE post_id = %d LIMIT 1",
				(int) $cluster['pillar_id']
			)
		);
		// phpcs:enable

		$pillar_words = self::decode_prominent( $pillar_json );
		if ( empty( $pillar_words ) ) {
			return array();
		}

		// Already-in-cluster posts (any role) — exclude.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$existing_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT post_id FROM `{$pivot_table}` WHERE cluster_id = %d",
				$cluster_id
			)
		);
		// phpcs:enable
		$existing_ids   = array_filter( array_map( 'intval', (array) $existing_ids ) );
		$existing_ids[] = (int) $cluster['pillar_id'];
		$existing_ids   = array_values( array_unique( $existing_ids ) );

		// Pull every clean indexed row except the excluded ones. We cap the
		// scan at a generous batch — sites with tens of thousands of posts
		// would need a smarter strategy, but for the v1.0 target this is fine.
		$exclude_placeholders = implode( ',', array_fill( 0, count( $existing_ids ), '%d' ) );

		$post_types = mvweb_sml_supported_post_types();
		if ( empty( $post_types ) ) {
			return array();
		}
		$pt_placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );

		$sql = "SELECT i.post_id, i.prominent
				FROM `{$index_table}` AS i
				INNER JOIN {$wpdb->posts} AS p ON p.ID = i.post_id
				WHERE i.dirty = 0
				  AND p.post_status = 'publish'
				  AND p.post_type IN ({$pt_placeholders})
				  AND i.post_id NOT IN ({$exclude_placeholders})
				LIMIT 2000";

		$args = array_merge( $post_types, $existing_ids );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A );
		// phpcs:enable

		if ( empty( $rows ) ) {
			return array();
		}

		// Score: number of overlapping prominent words.
		$scored = array();
		foreach ( $rows as $row ) {
			$candidate = self::decode_prominent( $row['prominent'] );
			if ( empty( $candidate ) ) {
				continue;
			}
			$overlap = count( array_intersect_key( $pillar_words, $candidate ) );
			if ( $overlap < 1 ) {
				continue;
			}
			$scored[] = array(
				'id'    => (int) $row['post_id'],
				'score' => (int) $overlap,
			);
		}

		usort(
			$scored,
			static function ( $a, $b ) {
				return $b['score'] <=> $a['score'];
			}
		);

		$scored = array_slice( $scored, 0, $limit );

		$out = array();
		foreach ( $scored as $item ) {
			$out[] = array(
				'id'    => (int) $item['id'],
				'title' => (string) get_the_title( (int) $item['id'] ),
				'score' => (int) $item['score'],
			);
		}

		return $out;
	}

	/**
	 * Apply an interlinking preset to a whole cluster in one call.
	 *
	 * Creates approved `_links` rows for the directed pairs the chosen topology
	 * implies, using each target's primary keyword as the anchor keyword. As
	 * everywhere in the plugin, a row is only an intent: the linker renders it
	 * on the front end wherever that keyword actually occurs in the source's
	 * prose (nothing is written into post_content). Existing pairs are left
	 * untouched — a human "rejected" or an edited anchor is never clobbered.
	 *
	 * @since 1.0.0
	 * @param int    $cluster_id Cluster id.
	 * @param string $preset     One of PRESET_HUB_SPOKE / PRESET_REVERSE_SILO.
	 * @return array{created:int, existing:int, skipped_no_keyword:int}|WP_Error
	 */
	public static function apply_preset( $cluster_id, $preset ) {
		global $wpdb;

		$cluster = self::get_cluster( (int) $cluster_id );
		if ( ! $cluster ) {
			return new WP_Error(
				'mvweb_sml_invalid_cluster',
				__( 'Cluster not found.', 'mvweb-smart-links' )
			);
		}
		if ( ! in_array( $preset, array( self::PRESET_HUB_SPOKE, self::PRESET_REVERSE_SILO ), true ) ) {
			return new WP_Error(
				'mvweb_sml_invalid_preset',
				__( 'Unknown cluster preset.', 'mvweb-smart-links' )
			);
		}

		$cluster_id = (int) $cluster['id'];
		$pillar_id  = (int) $cluster['pillar_id'];
		$pivot      = mvweb_sml_table( 'cluster_posts' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$spoke_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT post_id FROM `{$pivot}` WHERE cluster_id = %d AND role = %s",
				$cluster_id,
				self::ROLE_SPOKE
			)
		);
		// phpcs:enable
		$spoke_ids = array_values( array_filter( array_map( 'intval', (array) $spoke_ids ) ) );

		// Directed (source => target) pairs for the topology.
		$pairs = array();
		foreach ( $spoke_ids as $sid ) {
			$pairs[] = array( $sid, $pillar_id ); // Spoke → pillar (both presets).
			if ( self::PRESET_HUB_SPOKE === $preset ) {
				$pairs[] = array( $pillar_id, $sid ); // Pillar → spoke (hub only).
			}
		}

		$stats = array(
			'created'            => 0,
			'existing'           => 0,
			'skipped_no_keyword' => 0,
		);
		if ( empty( $pairs ) ) {
			return $stats;
		}

		$links = mvweb_sml_table( 'links' );
		$now   = current_time( 'mysql' );

		foreach ( $pairs as $pair ) {
			$source_id = (int) $pair[0];
			$target_id = (int) $pair[1];
			if ( $source_id <= 0 || $target_id <= 0 || $source_id === $target_id ) {
				continue;
			}
			if ( 'publish' !== get_post_status( $source_id ) || 'publish' !== get_post_status( $target_id ) ) {
				continue;
			}

			// Anchor keyword = the target's primary keyword; without one there is
			// nothing for the linker to match in the source prose.
			$target_kws = MVweb_SML_Keyword_Manager::get_for_post( $target_id );
			$keyword    = ! empty( $target_kws ) ? (string) $target_kws[0]['keyword'] : '';
			if ( '' === $keyword ) {
				++$stats['skipped_no_keyword'];
				continue;
			}

			// Dedup on the pair, not the (pair, keyword) triple: if this cluster
			// pair is already linked under any keyword, leave it — a human anchor
			// or a sweep-created row stays intact and we never add a second row
			// for the same direction.
			// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$exists = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT id FROM `{$links}` WHERE source_id = %d AND target_id = %d LIMIT 1",
					$source_id,
					$target_id
				)
			);
			// phpcs:enable
			if ( $exists ) {
				++$stats['existing'];
				continue;
			}

			$score  = 0.0;
			$scores = self::overlap_scores( $source_id, array( $target_id ) );
			if ( isset( $scores[ $target_id ] ) ) {
				$score = (float) $scores[ $target_id ];
			}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$ok = $wpdb->insert(
				$links,
				array(
					'source_id'  => $source_id,
					'target_id'  => $target_id,
					'keyword'    => $keyword,
					'anchor'     => '',
					'status'     => 'approved',
					'score'      => $score,
					'context'    => '',
					'created_at' => $now,
				),
				array( '%d', '%d', '%s', '%s', '%s', '%f', '%s', '%s' )
			);
			if ( false !== $ok ) {
				++$stats['created'];
			}
		}

		return $stats;
	}

	/**
	 * Topical-overlap score between one source post and a set of targets.
	 *
	 * Reuses the cached `_index` prominent-word maps: the score is the number
	 * of prominent words the source and a target share. Lets suggestion pairs
	 * be ranked by relevance instead of insertion order.
	 *
	 * @since 1.0.0
	 * @param int            $source_id  Source post id.
	 * @param array<int,int> $target_ids Target post ids.
	 * @return array<int,int> Map of target_id => overlapping prominent words.
	 */
	public static function overlap_scores( $source_id, array $target_ids ) {
		$source_id  = (int) $source_id;
		$target_ids = array_values( array_unique( array_filter( array_map( 'intval', $target_ids ) ) ) );
		if ( $source_id <= 0 || empty( $target_ids ) ) {
			return array();
		}

		global $wpdb;
		$index_table = mvweb_sml_table( 'index' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		$source_raw = $wpdb->get_var(
			$wpdb->prepare( 'SELECT prominent FROM %i WHERE post_id = %d LIMIT 1', $index_table, $source_id )
		);
		// phpcs:enable

		$source_words = self::decode_prominent( $source_raw );
		if ( empty( $source_words ) ) {
			return array();
		}

		$placeholders = implode( ',', array_fill( 0, count( $target_ids ), '%d' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, prominent FROM %i WHERE post_id IN ({$placeholders})",
				array_merge( array( $index_table ), $target_ids )
			),
			ARRAY_A
		);
		// phpcs:enable

		$scores = array();
		foreach ( (array) $rows as $row ) {
			$words = self::decode_prominent( $row['prominent'] );
			if ( empty( $words ) ) {
				continue;
			}
			$scores[ (int) $row['post_id'] ] = count( array_intersect_key( $source_words, $words ) );
		}

		return $scores;
	}

	/**
	 * Like overlap_scores(), but returns the actual list of shared prominent
	 * words per target instead of just the count.
	 *
	 * The sweep derives the integer base score (word count) AND the IDF ranking
	 * refinement from this single query — rarer shared words make a pair more
	 * distinctive. Returned per target as a plain, de-duplicated word list.
	 *
	 * @since 1.0.0
	 * @param int            $source_id  Source post id.
	 * @param array<int,int> $target_ids Target post ids.
	 * @return array<int, string[]> Map of target_id => shared prominent words.
	 */
	public static function overlap_scored_words( $source_id, array $target_ids ) {
		$source_id  = (int) $source_id;
		$target_ids = array_values( array_unique( array_filter( array_map( 'intval', $target_ids ) ) ) );
		if ( $source_id <= 0 || empty( $target_ids ) ) {
			return array();
		}

		global $wpdb;
		$index_table = mvweb_sml_table( 'index' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		$source_raw = $wpdb->get_var(
			$wpdb->prepare( 'SELECT prominent FROM %i WHERE post_id = %d LIMIT 1', $index_table, $source_id )
		);
		// phpcs:enable

		$source_words = self::decode_prominent( $source_raw );
		if ( empty( $source_words ) ) {
			return array();
		}

		$placeholders = implode( ',', array_fill( 0, count( $target_ids ), '%d' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, prominent FROM %i WHERE post_id IN ({$placeholders})",
				array_merge( array( $index_table ), $target_ids )
			),
			ARRAY_A
		);
		// phpcs:enable

		$out = array();
		foreach ( (array) $rows as $row ) {
			$words = self::decode_prominent( $row['prominent'] );
			if ( empty( $words ) ) {
				continue;
			}
			$shared = array_keys( array_intersect_key( $source_words, $words ) );
			if ( ! empty( $shared ) ) {
				$out[ (int) $row['post_id'] ] = array_map( 'strval', $shared );
			}
		}

		return $out;
	}

	/**
	 * Every post id that plays the pillar role in at least one cluster.
	 *
	 * Cached for the request so a suggestion sweep can look pillars up once and
	 * give cornerstone pages a ranking bonus without a query per candidate.
	 *
	 * @since 1.0.0
	 * @return array<int, int> Pillar post ids.
	 */
	public static function pillar_ids() {
		static $cache = null;
		if ( null !== $cache ) {
			return $cache;
		}

		global $wpdb;
		$table = mvweb_sml_table( 'clusters' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery
		$ids = $wpdb->get_col( "SELECT DISTINCT pillar_id FROM `{$table}`" );
		// phpcs:enable

		$cache = array_values( array_unique( array_filter( array_map( 'intval', (array) $ids ) ) ) );
		return $cache;
	}

	/**
	 * Ensure a draft cluster exists for a freshly-flagged pillar post.
	 *
	 * Used by the metabox when the editor ticks "Pillar page": if the post
	 * has no cluster yet, create one named after the post title.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post id.
	 * @return int|null New cluster id, existing id, or null on failure.
	 */
	public static function ensure_draft_for_pillar( $post_id ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return null;
		}

		// Already a pillar of a cluster? Reuse it.
		foreach ( self::get_for_post( $post_id ) as $entry ) {
			if ( self::ROLE_PILLAR === $entry['role'] ) {
				return (int) $entry['cluster_id'];
			}
		}

		$result = self::create_cluster( $post_id, (string) get_the_title( $post_id ) );
		if ( is_wp_error( $result ) ) {
			return null;
		}
		return (int) $result;
	}

	// ─────────────────────────────────────────────────────────────────────
	// Internals
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Decode the JSON prominent column into a `word => count` map.
	 *
	 * @since 1.0.0
	 * @param string|null $value Raw column value.
	 * @return array<string, int>
	 */
	private static function decode_prominent( $value ) {
		if ( ! is_string( $value ) || '' === $value ) {
			return array();
		}
		$decoded = json_decode( $value, true );
		if ( ! is_array( $decoded ) ) {
			return array();
		}
		$out = array();
		foreach ( $decoded as $word => $count ) {
			if ( ! is_string( $word ) || '' === $word ) {
				continue;
			}
			$out[ $word ] = (int) $count;
		}
		return $out;
	}
}
