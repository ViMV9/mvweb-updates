<?php
/**
 * Read-through cache abstraction for MVweb Smart Links.
 *
 * Uses the persistent object cache when one is available
 * (memcached / redis / etc.) and falls back to transients otherwise.
 * No third-party libraries.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Cache facade. All keys are scoped under the `mvweb_sml` group / prefix.
 *
 * @since 1.0.0
 */
class MVweb_SML_Cache {

	/**
	 * Object cache group and transient key prefix.
	 */
	const GROUP = 'mvweb_sml';

	/**
	 * Transient key prefix used when no persistent object cache is available.
	 */
	const TRANSIENT_PREFIX = 'mvweb_sml_';

	/**
	 * Store a value in the cache.
	 *
	 * @since 1.0.0
	 * @param string $key   Cache key (without prefix).
	 * @param mixed  $value Value to store.
	 * @param int    $ttl   Time-to-live in seconds.
	 * @return bool True on success, false on failure.
	 */
	public static function set( $key, $value, $ttl = HOUR_IN_SECONDS ) {
		$key = self::normalize_key( $key );

		if ( wp_using_ext_object_cache() ) {
			return wp_cache_set( $key, $value, self::GROUP, (int) $ttl );
		}

		return set_transient( self::TRANSIENT_PREFIX . $key, $value, (int) $ttl );
	}

	/**
	 * Retrieve a value from the cache.
	 *
	 * @since 1.0.0
	 * @param string $key Cache key (without prefix).
	 * @return mixed Cached value or false on miss.
	 */
	public static function get( $key ) {
		$key = self::normalize_key( $key );

		if ( wp_using_ext_object_cache() ) {
			return wp_cache_get( $key, self::GROUP );
		}

		return get_transient( self::TRANSIENT_PREFIX . $key );
	}

	/**
	 * Remove a single key from the cache.
	 *
	 * @since 1.0.0
	 * @param string $key Cache key (without prefix).
	 * @return bool
	 */
	public static function delete( $key ) {
		$key = self::normalize_key( $key );

		if ( wp_using_ext_object_cache() ) {
			return wp_cache_delete( $key, self::GROUP );
		}

		return delete_transient( self::TRANSIENT_PREFIX . $key );
	}

	/**
	 * Drop all cached entries that belong to a specific post.
	 *
	 * Per-post caches use deterministic key suffixes so we just delete the
	 * known shapes (linker output, related posts list).
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function flush_post( $post_id ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return;
		}

		// The linker and related caches use language-suffixed keys
		// (see MVweb_SML_Linker::cache_key / MVweb_SML_Related::cache_key).
		// MVweb_SML_Public::flush_post_cache() enumerates every active
		// language and removes each variant explicitly — we only clean
		// up the simple, language-less entries here.
		self::delete( 'index_' . $post_id );

		/**
		 * Allow other components to flush per-post cache entries.
		 *
		 * @since 1.0.0
		 * @param int $post_id Post ID being flushed.
		 */
		do_action( 'mvweb_sml_flush_post_cache', $post_id );
	}

	/**
	 * Drop every cached entry the plugin owns.
	 *
	 * For object cache backends we use wp_cache_flush_group() when available
	 * (WP 6.1+) and otherwise bump an internal version key. For the
	 * transient fallback we sweep wp_options directly.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function flush_all() {
		if ( wp_using_ext_object_cache() ) {
			if ( function_exists( 'wp_cache_flush_group' ) ) {
				wp_cache_flush_group( self::GROUP );
			}
			return;
		}

		global $wpdb;

		$like = $wpdb->esc_like( '_transient_' . self::TRANSIENT_PREFIX ) . '%';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Cache flush itself; nothing to cache.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like ) );

		$timeout_like = $wpdb->esc_like( '_transient_timeout_' . self::TRANSIENT_PREFIX ) . '%';
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Cache flush itself.
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $timeout_like ) );
	}

	/**
	 * Normalize a cache key: lower-case, alnum + underscore.
	 *
	 * @since 1.0.0
	 * @param string $key Raw key.
	 * @return string
	 */
	private static function normalize_key( $key ) {
		$key = strtolower( (string) $key );
		$key = preg_replace( '/[^a-z0-9_]+/', '_', $key );
		return trim( (string) $key, '_' );
	}
}
