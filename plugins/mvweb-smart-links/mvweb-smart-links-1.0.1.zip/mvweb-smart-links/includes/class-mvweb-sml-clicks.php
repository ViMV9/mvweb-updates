<?php
/**
 * Internal-link click tracking.
 *
 * Records aggregate click counts per (source, target) contextual link so the
 * editor can see which internal links actually get used — the missing feedback
 * loop for interlinking. Only integer counts are stored: no IP, user agent or
 * any personal data, so the feature stays GDPR / 152-FZ clean.
 *
 * A tiny front-end beacon (public/js/track.js) posts source + target ids to the
 * `mvweb_sml_track_click` AJAX action on click; this class validates the pair
 * and increments the counter in the `clicks` table.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Clicks
 *
 * @since 1.0.0
 */
class MVweb_SML_Clicks {

	/**
	 * AJAX action name for the tracking beacon.
	 */
	const ACTION = 'mvweb_sml_track_click';

	/**
	 * Whether click tracking is switched on in settings.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function is_enabled() {
		return (bool) mvweb_sml_get_setting( 'track_clicks' );
	}

	/**
	 * Register the AJAX handlers (logged-in and anonymous visitors).
	 *
	 * Called from the loader. The beacon runs for every visitor, so both the
	 * priv and nopriv variants are registered — but only when the feature is on.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		if ( ! self::is_enabled() ) {
			return;
		}

		add_action( 'wp_ajax_' . self::ACTION, array( __CLASS__, 'ajax_track' ) );
		add_action( 'wp_ajax_nopriv_' . self::ACTION, array( __CLASS__, 'ajax_track' ) );
	}

	/**
	 * AJAX beacon endpoint.
	 *
	 * No nonce: the beacon fires from full-page-cached HTML where a nonce would
	 * be stale, which is the standard trade-off for anonymous analytics. Abuse
	 * is bounded because record() only accepts pairs of real published posts,
	 * and the payload carries no personal data.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_track() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$source_id = isset( $_POST['source'] ) ? absint( wp_unslash( $_POST['source'] ) ) : 0;
		$target_id = isset( $_POST['target'] ) ? absint( wp_unslash( $_POST['target'] ) ) : 0;
		// phpcs:enable

		self::record( $source_id, $target_id );

		// The beacon ignores the body; keep the response minimal.
		wp_send_json_success();
	}

	/**
	 * Increment the click counter for a (source, target) link pair.
	 *
	 * @since 1.0.0
	 * @param int $source_id Post the link was clicked from.
	 * @param int $target_id Post the link points to.
	 * @return bool True if a row was written.
	 */
	public static function record( $source_id, $target_id ) {
		global $wpdb;

		$source_id = (int) $source_id;
		$target_id = (int) $target_id;

		if ( $source_id <= 0 || $target_id <= 0 || $source_id === $target_id ) {
			return false;
		}

		// Only count clicks between real, published posts — this bounds junk the
		// public endpoint could otherwise insert. get_post_status() is served
		// from the post cache, so this is two cache hits, not two queries.
		if ( 'publish' !== get_post_status( $source_id ) || 'publish' !== get_post_status( $target_id ) ) {
			return false;
		}

		// The endpoint is nonce-less (it must fire from fully cached HTML), so
		// count a click only when the pair is an actually-rendered internal link
		// — otherwise a scripted request could inflate counts or bloat the table
		// with arbitrary post pairs.
		if ( ! self::is_rendered_link( $source_id, $target_id ) ) {
			return false;
		}

		$table = mvweb_sml_table( 'clicks' );
		$now   = current_time( 'mysql' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$ok = $wpdb->query(
			$wpdb->prepare(
				"INSERT INTO `{$table}` (source_id, target_id, clicks, last_click)
				 VALUES (%d, %d, 1, %s)
				 ON DUPLICATE KEY UPDATE clicks = clicks + 1, last_click = %s",
				$source_id,
				$target_id,
				$now,
				$now
			)
		);
		// phpcs:enable

		return false !== $ok;
	}

	/**
	 * Whether the (source, target) pair is an internal link the linker renders.
	 *
	 * Mirrors the two link sources in MVweb_SML_Linker::collect_candidates():
	 * a manual target stored on the source post, or an approved/auto row in the
	 * links table. Manual targets are read from the (cached) post meta; only the
	 * table branch costs a query, and only when the pair is not a manual target.
	 *
	 * @since 1.0.0
	 * @param int $source_id Source post.
	 * @param int $target_id Target post.
	 * @return bool
	 */
	private static function is_rendered_link( $source_id, $target_id ) {
		global $wpdb;

		$manual = get_post_meta( $source_id, '_mvweb_sml_manual_targets', true );
		if ( is_array( $manual ) && in_array( $target_id, array_map( 'intval', $manual ), true ) ) {
			return true;
		}

		$table = mvweb_sml_table( 'links' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$found = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT 1 FROM `{$table}`
				 WHERE source_id = %d AND target_id = %d AND status IN ('approved','auto')
				 LIMIT 1",
				$source_id,
				$target_id
			)
		);
		// phpcs:enable

		return null !== $found;
	}

	/**
	 * Most-clicked internal links.
	 *
	 * @since 1.0.0
	 * @param int $limit Maximum rows.
	 * @return array<int, array{source_id:int, target_id:int, clicks:int, last_click:string}>
	 */
	public static function top_clicked( $limit = 50 ) {
		global $wpdb;

		$limit = max( 1, (int) $limit );
		$table = mvweb_sml_table( 'clicks' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT source_id, target_id, clicks, last_click
				 FROM `{$table}`
				 WHERE clicks > 0
				 ORDER BY clicks DESC, last_click DESC
				 LIMIT %d",
				$limit
			),
			ARRAY_A
		);
		// phpcs:enable

		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[] = array(
				'source_id'  => (int) $row['source_id'],
				'target_id'  => (int) $row['target_id'],
				'clicks'     => (int) $row['clicks'],
				'last_click' => (string) $row['last_click'],
			);
		}

		return $out;
	}
}
