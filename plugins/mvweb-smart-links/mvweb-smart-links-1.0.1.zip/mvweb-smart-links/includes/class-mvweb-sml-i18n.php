<?php
/**
 * Multilingual adapter for MVweb Smart Links.
 *
 * Provides a thin abstraction over WPML and Polylang so the rest of the
 * plugin can ask "are these two posts in the same language?" without caring
 * which (if any) translation plugin is active.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WPML / Polylang adapter.
 *
 * @since 1.0.0
 */
class MVweb_SML_I18n {

	/**
	 * Sentinel value used when no translation plugin is active.
	 */
	const NO_LANGUAGE = 'none';

	/**
	 * Get the current request language code.
	 *
	 * @since 1.0.0
	 * @return string Two-letter language code or `self::NO_LANGUAGE`.
	 */
	public static function current_language() {
		if ( function_exists( 'pll_current_language' ) ) {
			$lang = pll_current_language();
			if ( ! empty( $lang ) ) {
				return (string) $lang;
			}
		}

		if ( has_filter( 'wpml_current_language' ) ) {
			$lang = apply_filters( 'wpml_current_language', null );
			if ( ! empty( $lang ) ) {
				return (string) $lang;
			}
		}

		return self::NO_LANGUAGE;
	}

	/**
	 * Get the language code attached to a specific post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return string Language code or `self::NO_LANGUAGE`.
	 */
	public static function get_post_language( $post_id ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return self::NO_LANGUAGE;
		}

		if ( function_exists( 'pll_get_post_language' ) ) {
			$lang = pll_get_post_language( $post_id );
			if ( ! empty( $lang ) ) {
				return (string) $lang;
			}
		}

		if ( has_filter( 'wpml_post_language_details' ) ) {
			$details = apply_filters( 'wpml_post_language_details', null, $post_id );
			if ( is_array( $details ) && ! empty( $details['language_code'] ) ) {
				return (string) $details['language_code'];
			}
		}

		return self::NO_LANGUAGE;
	}

	/**
	 * Check whether two posts are in the same language.
	 *
	 * Returns true when both posts have no detected language (single-language
	 * site) or when the detected language codes match.
	 *
	 * @since 1.0.0
	 * @param int $source_id Source post ID.
	 * @param int $target_id Target post ID.
	 * @return bool
	 */
	public static function same_language( $source_id, $target_id ) {
		$source_lang = self::get_post_language( $source_id );
		$target_lang = self::get_post_language( $target_id );

		return $source_lang === $target_lang;
	}

	/**
	 * List all active language codes on the site.
	 *
	 * Used by cache invalidation to flush every language-suffixed variant of
	 * a cached value (otherwise the non-current languages keep stale entries
	 * until TTL expiry).
	 *
	 * @since 1.0.0
	 * @return array<int, string> Language codes. Contains a single
	 *                            self::NO_LANGUAGE entry on single-language sites.
	 */
	public static function active_languages() {
		if ( function_exists( 'pll_languages_list' ) ) {
			$langs = pll_languages_list();
			if ( is_array( $langs ) && ! empty( $langs ) ) {
				return array_values( array_unique( array_map( 'strval', $langs ) ) );
			}
		}

		if ( has_filter( 'wpml_active_languages' ) ) {
			$langs = apply_filters( 'wpml_active_languages', null, array( 'skip_missing' => 0 ) );
			if ( is_array( $langs ) && ! empty( $langs ) ) {
				$codes = array();
				foreach ( $langs as $entry ) {
					if ( is_array( $entry ) && ! empty( $entry['language_code'] ) ) {
						$codes[] = (string) $entry['language_code'];
					} elseif ( is_string( $entry ) && '' !== $entry ) {
						$codes[] = $entry;
					}
				}
				if ( ! empty( $codes ) ) {
					return array_values( array_unique( $codes ) );
				}
			}
		}

		return array( self::NO_LANGUAGE );
	}

	/**
	 * Reduce a list of post IDs to those that share the language of a reference post.
	 *
	 * @since 1.0.0
	 * @param array $ids          List of post IDs.
	 * @param int   $reference_id Reference post ID.
	 * @return array<int, int> Filtered list of post IDs.
	 */
	public static function filter_post_ids_by_language( array $ids, $reference_id ) {
		$reference_lang = self::get_post_language( $reference_id );

		if ( self::NO_LANGUAGE === $reference_lang ) {
			// No translation plugin → nothing to filter.
			return array_map( 'intval', $ids );
		}

		$out = array();
		foreach ( $ids as $id ) {
			$id = (int) $id;
			if ( $id <= 0 ) {
				continue;
			}
			if ( self::get_post_language( $id ) === $reference_lang ) {
				$out[] = $id;
			}
		}

		return $out;
	}
}
