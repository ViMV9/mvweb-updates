<?php
/**
 * Plugin settings: defaults, get, save and per-field sanitization.
 *
 * All plugin settings live in a single wp_option named `mvweb_sml_settings`
 * (autoloaded). This class is the single source of truth for the schema.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings store and sanitizer.
 *
 * @since 1.0.0
 */
class MVweb_SML_Settings {

	/**
	 * Option name in wp_options table.
	 */
	const OPTION_NAME = 'mvweb_sml_settings';

	/**
	 * Settings group used by Settings API (`register_setting`).
	 */
	const OPTION_GROUP = 'mvweb_sml_settings_group';

	/**
	 * Allowed values for the `link_target` and `related_target` fields.
	 *
	 * @var array
	 */
	const ALLOWED_TARGETS = array( '_self', '_blank' );

	/**
	 * Allowed values for the `related_position` field.
	 *
	 * @var array
	 */
	const ALLOWED_RELATED_POSITIONS = array( 'after_content', 'after_paragraph' );

	/**
	 * Allowed values for the `related_template` field.
	 *
	 * @var array
	 */
	const ALLOWED_RELATED_TEMPLATES = array( 'list', 'cards', 'inline' );

	/**
	 * Allowed values for the `mode` field — the three interlinking modes.
	 *
	 * - manual: editor curates links by hand (metabox); no auto-approval.
	 * - semi:   plugin suggests pairs, a human approves them (default).
	 * - auto:   plugin auto-approves high-confidence suggestions (status='auto')
	 *           subject to the relevance and inbound-cap safeguards.
	 *
	 * @var array
	 */
	const ALLOWED_MODES = array( 'manual', 'semi', 'auto' );

	/**
	 * Get the schema of default values for every plugin setting.
	 *
	 * @since 1.0.0
	 * @return array Defaults schema.
	 */
	public static function defaults() {
		return array(
			'enabled'                  => false,
			'mode'                     => 'semi',
			'auto_min_score'           => 3,
			'auto_max_inbound'         => 5,
			'anchor_rotation'          => true,
			'anchor_max_repeat'        => 3,
			'pillar_score_bonus'       => 3,
			'score_idf'                => true,
			'score_position'           => true,
			'contextual_enabled'       => true,
			'related_enabled'          => true,
			'track_clicks'             => true,
			'post_types'               => array( 'post', 'page' ),
			'cross_cpt_matrix'         => array(),
			'links_max_per_page'       => 'auto',
			'links_max_per_paragraph'  => 0,
			'links_gap_words'          => 50,
			'link_target'              => '_self',
			'link_nofollow'            => false,
			'link_css_class'           => 'mvweb-sml-link',
			'related_position'         => 'after_content',
			'related_after_paragraph'  => 3,
			'related_template'         => 'list',
			'related_title'            => 'Read also',
			'related_count'            => 5,
			'related_target'           => '_self',
			'delete_data_on_uninstall' => false,
			'disabled_post_ids'        => array(),
			'disabled_url_patterns'    => array(),
			'disabled_terms'           => array(),
		);
	}

	/**
	 * Get all settings (or a single key) merged with defaults.
	 *
	 * @since 1.0.0
	 * @param string|null $key Optional single key to fetch.
	 * @return mixed Full settings array, or value of a single key.
	 */
	public static function get( $key = null ) {
		$saved    = get_option( self::OPTION_NAME, array() );
		$defaults = self::defaults();
		$merged   = array_merge( $defaults, is_array( $saved ) ? $saved : array() );

		if ( null === $key ) {
			return $merged;
		}

		return isset( $merged[ $key ] ) ? $merged[ $key ] : null;
	}

	/**
	 * Update a single setting key.
	 *
	 * @since 1.0.0
	 * @param string $key   Setting key.
	 * @param mixed  $value Value to store.
	 * @return bool True on success.
	 */
	public static function update( $key, $value ) {
		$settings         = self::get();
		$settings[ $key ] = $value;
		return self::save( $settings );
	}

	/**
	 * Save the full settings array.
	 *
	 * @since 1.0.0
	 * @param array $settings Settings array.
	 * @return bool True on success.
	 */
	public static function save( array $settings ) {
		return update_option( self::OPTION_NAME, $settings, 'yes' );
	}

	/**
	 * Sanitize callback for `register_setting`.
	 *
	 * Applies per-field rules. Unknown keys are dropped — only schema keys
	 * survive.
	 *
	 * @since 1.0.0
	 * @param mixed $input Raw input from $_POST['mvweb_sml_settings'].
	 * @return array Sanitized settings array merged with defaults.
	 */
	public static function sanitize( $input ) {
		// Defence-in-depth: nonce is verified by the Settings API before this
		// runs, but the option_page_capability_* filter only narrows the cap
		// check inside options.php — we still want an explicit guard here.
		if ( ! current_user_can( MVweb_SML_Admin::CAPABILITY ) ) {
			add_settings_error(
				'mvweb_sml_messages',
				'mvweb_sml_forbidden',
				__( 'You do not have permission to change these settings.', 'mvweb-smart-links' ),
				'error'
			);
			return self::get();
		}

		$defaults = self::defaults();
		$current  = self::get();
		$input    = is_array( $input ) ? $input : array();
		$out      = $current;

		// Booleans — checkboxes are not sent when off, so coerce explicitly.
		$bool_keys = array(
			'enabled',
			'contextual_enabled',
			'related_enabled',
			'track_clicks',
			'link_nofollow',
			'anchor_rotation',
			'score_idf',
			'score_position',
			'delete_data_on_uninstall',
		);
		foreach ( $bool_keys as $bk ) {
			$out[ $bk ] = ! empty( $input[ $bk ] );
		}

		// Post types — only registered post types pass through.
		if ( isset( $input['post_types'] ) ) {
			$pt                = array_map( 'sanitize_key', (array) $input['post_types'] );
			$pt                = array_filter( $pt, 'post_type_exists' );
			$out['post_types'] = array_values( array_unique( $pt ) );
		} else {
			$out['post_types'] = array();
		}

		// Cross-CPT matrix: matrix[source_cpt][target_cpt] = bool.
		if ( isset( $input['cross_cpt_matrix'] ) && is_array( $input['cross_cpt_matrix'] ) ) {
			$matrix = array();
			foreach ( $input['cross_cpt_matrix'] as $source => $targets ) {
				$source_key = sanitize_key( $source );
				if ( '' === $source_key || ! is_array( $targets ) ) {
					continue;
				}
				foreach ( $targets as $target => $val ) {
					$target_key = sanitize_key( $target );
					if ( '' === $target_key ) {
						continue;
					}
					$matrix[ $source_key ][ $target_key ] = ! empty( $val );
				}
			}
			$out['cross_cpt_matrix'] = $matrix;
		} else {
			$out['cross_cpt_matrix'] = array();
		}

		// links_max_per_page: 'auto' or non-negative integer.
		if ( isset( $input['links_max_per_page'] ) ) {
			$raw = is_string( $input['links_max_per_page'] ) ? trim( $input['links_max_per_page'] ) : $input['links_max_per_page'];
			if ( 'auto' === $raw || '' === $raw ) {
				$out['links_max_per_page'] = 'auto';
			} else {
				$out['links_max_per_page'] = absint( $raw );
			}
		}

		// Interlinking mode — whitelisted enum.
		if ( isset( $input['mode'] ) && in_array( $input['mode'], self::ALLOWED_MODES, true ) ) {
			$out['mode'] = $input['mode'];
		}

		// Integers.
		$int_keys = array( 'links_gap_words', 'links_max_per_paragraph', 'related_after_paragraph', 'related_count', 'auto_min_score', 'auto_max_inbound', 'anchor_max_repeat', 'pillar_score_bonus' );
		foreach ( $int_keys as $ik ) {
			if ( isset( $input[ $ik ] ) ) {
				$out[ $ik ] = absint( $input[ $ik ] );
			}
		}

		// Whitelisted enums.
		if ( isset( $input['link_target'] ) && in_array( $input['link_target'], self::ALLOWED_TARGETS, true ) ) {
			$out['link_target'] = $input['link_target'];
		}
		if ( isset( $input['related_target'] ) && in_array( $input['related_target'], self::ALLOWED_TARGETS, true ) ) {
			$out['related_target'] = $input['related_target'];
		}
		if ( isset( $input['related_position'] ) && in_array( $input['related_position'], self::ALLOWED_RELATED_POSITIONS, true ) ) {
			$out['related_position'] = $input['related_position'];
		}
		if ( isset( $input['related_template'] ) && in_array( $input['related_template'], self::ALLOWED_RELATED_TEMPLATES, true ) ) {
			$out['related_template'] = $input['related_template'];
		}

		// CSS class — strict, single class only.
		if ( isset( $input['link_css_class'] ) ) {
			$class                 = sanitize_html_class( (string) $input['link_css_class'] );
			$out['link_css_class'] = '' !== $class ? $class : $defaults['link_css_class'];
		}

		// Related title — plain text.
		if ( isset( $input['related_title'] ) ) {
			$out['related_title'] = sanitize_text_field( (string) $input['related_title'] );
		}

		// Disabled post IDs — accept array or comma-separated string.
		if ( isset( $input['disabled_post_ids'] ) ) {
			$ids = $input['disabled_post_ids'];
			if ( is_string( $ids ) ) {
				$ids = preg_split( '/[\s,]+/', $ids );
			}
			$ids                      = array_filter( array_map( 'absint', (array) $ids ) );
			$out['disabled_post_ids'] = array_values( array_unique( $ids ) );
		} else {
			$out['disabled_post_ids'] = array();
		}

		// Disabled URL patterns — accept array or newline-separated textarea.
		if ( isset( $input['disabled_url_patterns'] ) ) {
			$patterns = $input['disabled_url_patterns'];
			if ( is_string( $patterns ) ) {
				$patterns = preg_split( '/\r\n|\r|\n/', $patterns );
			}
			$patterns                     = array_map( 'sanitize_text_field', (array) $patterns );
			$patterns                     = array_filter(
				$patterns,
				static function ( $p ) {
					return '' !== trim( $p );
				}
			);
			$out['disabled_url_patterns'] = array_values( $patterns );
		} else {
			$out['disabled_url_patterns'] = array();
		}

		// Disabled taxonomy terms — array of term IDs; keep only ones that still
		// resolve to a real term so a deleted term never lingers in the option.
		if ( isset( $input['disabled_terms'] ) ) {
			$term_ids              = array_filter( array_map( 'absint', (array) $input['disabled_terms'] ) );
			$term_ids              = array_filter(
				$term_ids,
				static function ( $tid ) {
					return get_term( $tid ) instanceof WP_Term;
				}
			);
			$out['disabled_terms'] = array_values( array_unique( $term_ids ) );
		} else {
			$out['disabled_terms'] = array();
		}

		// NOTE: do not add a "Settings saved." notice here. The Settings API
		// calls this sanitize callback twice per submit (old/new comparison in
		// update_option), so adding it here renders the message twice. The
		// Settings API already queues a single localized "Settings saved."
		// notice on settings-updated, which settings_errors() renders once.

		return $out;
	}

	/**
	 * Register the option with the Settings API.
	 *
	 * Called from `MVweb_SML_Admin::init()` on `admin_init`.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register() {
		register_setting(
			self::OPTION_GROUP,
			self::OPTION_NAME,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => self::defaults(),
			)
		);
	}
}
