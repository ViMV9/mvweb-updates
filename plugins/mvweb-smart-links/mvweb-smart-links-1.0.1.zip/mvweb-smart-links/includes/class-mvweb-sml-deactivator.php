<?php
/**
 * Plugin deactivator: clean up scheduled events.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Deactivator
 *
 * Handles plugin deactivation. Does NOT delete data — that is the
 * responsibility of uninstall.php (gated by the user opt-in setting).
 *
 * @since 1.0.0
 */
class MVweb_SML_Deactivator {

	/**
	 * Run deactivation tasks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function deactivate() {
		wp_clear_scheduled_hook( 'mvweb_sml_cron_indexer' );
	}
}
