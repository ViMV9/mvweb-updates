<?php
/**
 * Dismissible admin notices for MVweb Smart Links (TZ §20).
 *
 * Notices live in the option `mvweb_sml_notices` (associative array keyed by
 * a logical slug). When the current user dismisses a notice, the dismiss flag
 * is recorded per-user in usermeta — so different editors can clear the same
 * notice independently.
 *
 * Triggers (added in phase 11):
 *  - `mvweb_sml_index_complete` → "indexing finished" notice.
 *  - Reports::orphans()         → "N orphan pages found" notice.
 *  - Reports::keyword_cannibalization() → "N keyword conflicts" notice.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Notices.
 *
 * @since 1.0.0
 */
class MVweb_SML_Notices {

	/**
	 * Option storing the active notices array.
	 */
	const OPTION_KEY = 'mvweb_sml_notices';

	/**
	 * Per-user dismissal usermeta key prefix.
	 */
	const USERMETA_PREFIX = 'mvweb_sml_dismissed_';

	/**
	 * Whitelisted notice types (mapped to WP `notice-{type}`).
	 *
	 * @var array<int, string>
	 */
	const ALLOWED_TYPES = array( 'info', 'success', 'warning', 'error' );

	/**
	 * Wire global hooks. Called from MVweb_SML_Loader::init().
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'mvweb_sml_index_complete', array( __CLASS__, 'on_index_complete' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_dismiss_script' ) );
	}

	/**
	 * Enqueue the tiny dismiss handler on every admin page that may render
	 * one of our notices. Plugin's main admin.js already handles the same
	 * click on the settings page, but `admin_notices` fires everywhere, so
	 * we need a globally available handler.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function enqueue_dismiss_script() {
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			return;
		}

		$notices = self::all();
		if ( empty( $notices ) ) {
			return;
		}

		// If the plugin's main admin.js is already enqueued (we're on the
		// plugin settings page or the post editor), it carries the handler
		// itself — skip the inline duplicate.
		if ( wp_script_is( 'mvweb-sml-admin', 'enqueued' ) ) {
			return;
		}

		wp_register_script( 'mvweb-sml-notices', '', array( 'jquery' ), MVWEB_SML_VERSION, true );
		wp_enqueue_script( 'mvweb-sml-notices' );

		$data = array(
			'ajax_url' => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'mvweb_sml_admin' ),
		);
		wp_add_inline_script(
			'mvweb-sml-notices',
			'window.mvweb_sml_ajax = window.mvweb_sml_ajax || ' . wp_json_encode( $data ) . ';' .
			'jQuery(function($){' .
			'$(document).on("click",".mvweb-sml-notice .notice-dismiss",function(){' .
			'var $n=$(this).closest(".mvweb-sml-notice");' .
			'var key=$n.data("mvweb-sml-key");' .
			'if(!key){return;}' .
			'$.post(window.mvweb_sml_ajax.ajax_url,{action:"mvweb_sml_dismiss_notice",nonce:window.mvweb_sml_ajax.nonce,key:key});' .
			'});' .
			'});'
		);
	}

	/**
	 * Add or update a notice. Stored centrally so every editor sees it on
	 * the next page load until they personally dismiss it.
	 *
	 * @since 1.0.0
	 * @param string $key     Logical slug (sanitize_key applied).
	 * @param string $message Human-readable message (already translated).
	 * @param string $type    One of self::ALLOWED_TYPES.
	 * @return void
	 */
	public static function add( $key, $message, $type = 'info' ) {
		$key = sanitize_key( $key );
		if ( '' === $key ) {
			return;
		}

		if ( ! in_array( $type, self::ALLOWED_TYPES, true ) ) {
			$type = 'info';
		}

		$notices         = self::all();
		$notices[ $key ] = array(
			'message'    => (string) $message,
			'type'       => $type,
			'created_at' => time(),
		);

		update_option( self::OPTION_KEY, $notices, false );
	}

	/**
	 * Remove a notice from the global store.
	 *
	 * @since 1.0.0
	 * @param string $key Notice slug.
	 * @return void
	 */
	public static function remove( $key ) {
		$key = sanitize_key( $key );
		if ( '' === $key ) {
			return;
		}

		$notices = self::all();
		if ( isset( $notices[ $key ] ) ) {
			unset( $notices[ $key ] );
			update_option( self::OPTION_KEY, $notices, false );
		}
	}

	/**
	 * Mark a notice as dismissed for a single user.
	 *
	 * The notice itself stays in the option so that other editors still see
	 * it; only the per-user usermeta flag is set.
	 *
	 * @since 1.0.0
	 * @param string $key     Notice slug.
	 * @param int    $user_id User ID.
	 * @return void
	 */
	public static function dismiss( $key, $user_id ) {
		$key     = sanitize_key( $key );
		$user_id = (int) $user_id;
		if ( '' === $key || $user_id <= 0 ) {
			return;
		}

		update_user_meta( $user_id, self::USERMETA_PREFIX . $key, 1 );
	}

	/**
	 * Whether a user has dismissed a notice.
	 *
	 * @since 1.0.0
	 * @param string $key     Notice slug.
	 * @param int    $user_id User ID.
	 * @return bool
	 */
	public static function is_dismissed( $key, $user_id ) {
		$key     = sanitize_key( $key );
		$user_id = (int) $user_id;
		if ( '' === $key || $user_id <= 0 ) {
			return false;
		}

		return (bool) get_user_meta( $user_id, self::USERMETA_PREFIX . $key, true );
	}

	/**
	 * Return every active notice (raw store).
	 *
	 * @since 1.0.0
	 * @return array<string, array<string, mixed>>
	 */
	public static function all() {
		$notices = get_option( self::OPTION_KEY, array() );
		return is_array( $notices ) ? $notices : array();
	}

	/**
	 * Render every active, non-dismissed notice for the current user.
	 *
	 * Hooked on `admin_notices` from the loader. Restricted to users with
	 * `edit_others_posts` (the plugin-wide capability).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_all() {
		if ( ! current_user_can( 'edit_others_posts' ) ) {
			return;
		}

		$user_id = get_current_user_id();
		if ( $user_id <= 0 ) {
			return;
		}

		$notices = self::all();
		if ( empty( $notices ) ) {
			return;
		}

		foreach ( $notices as $key => $data ) {
			if ( self::is_dismissed( $key, $user_id ) ) {
				continue;
			}

			$message = isset( $data['message'] ) ? (string) $data['message'] : '';
			$type    = isset( $data['type'] ) && in_array( $data['type'], self::ALLOWED_TYPES, true )
				? $data['type']
				: 'info';

			if ( '' === $message ) {
				continue;
			}

			printf(
				'<div class="notice notice-%1$s is-dismissible mvweb-sml-notice" data-mvweb-sml-key="%2$s"><p><strong>%3$s</strong> %4$s</p></div>',
				esc_attr( $type ),
				esc_attr( $key ),
				esc_html__( 'MVweb Smart Links:', 'mvweb-smart-links' ),
				esc_html( $message )
			);
		}
	}

	/**
	 * Handler for `mvweb_sml_index_complete` (from the indexer).
	 *
	 * Records a notice and clears any per-user dismissal so that the new
	 * "indexing finished" message is visible to everyone.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function on_index_complete() {
		self::reset_dismissals( 'index_complete' );
		self::add(
			'index_complete',
			__( 'indexing finished — go to Reports for the latest stats.', 'mvweb-smart-links' ),
			'success'
		);
	}

	/**
	 * Delete every per-user dismissal flag for the given notice.
	 *
	 * Used when re-publishing a notice that was previously dismissed (the
	 * underlying state changed and we want users to see it again).
	 *
	 * @since 1.0.0
	 * @param string $key Notice slug.
	 * @return void
	 */
	public static function reset_dismissals( $key ) {
		$key = sanitize_key( $key );
		if ( '' === $key ) {
			return;
		}

		delete_metadata( 'user', 0, self::USERMETA_PREFIX . $key, '', true );
	}
}
