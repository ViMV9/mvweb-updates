<?php
/**
 * Related posts template — simple list.
 *
 * Override this template by copying it to your active theme at:
 * `wp-content/themes/<theme>/mvweb-smart-links/related-list.php`.
 *
 * Arguments provided via `load_template( $file, false, $args )`:
 *
 *   @var array $args {
 *       @type WP_Post[] $posts    List of related posts.
 *       @type string    $block_title    Block title (already sanitized in controller).
 *       @type string    $target   '_self' or '_blank'.
 *       @type string    $template Current template slug.
 *       @type int       $post_id  Source post ID.
 *   }
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $args['posts'] ) || ! is_array( $args['posts'] ) ) {
	return;
}

$block_title = isset( $args['title'] ) ? (string) $args['title'] : '';
$target      = isset( $args['target'] ) ? (string) $args['target'] : '_self';
?>
<aside class="mvweb-sml-related mvweb-sml-related--list" aria-label="<?php echo esc_attr( $block_title ); ?>">
	<?php if ( '' !== $block_title ) : ?>
		<h2 class="mvweb-sml-related__title"><?php echo esc_html( $block_title ); ?></h2>
	<?php endif; ?>
	<ul class="mvweb-sml-related__items">
		<?php foreach ( $args['posts'] as $related_post ) : ?>
			<li class="mvweb-sml-related__item">
				<a
					class="mvweb-sml-related__link"
					href="<?php echo esc_url( get_permalink( $related_post ) ); ?>"
					target="<?php echo esc_attr( $target ); ?>"
					<?php
					if ( '_blank' === $target ) :
						?>
						rel="noopener noreferrer"<?php endif; ?>
				>
					<?php echo esc_html( get_the_title( $related_post ) ); ?>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</aside>
