<?php
/**
 * Related posts template — inline chips (compact, flows with text).
 *
 * Override this template by copying it to your active theme at:
 * `wp-content/themes/<theme>/mvweb-smart-links/related-inline.php`.
 *
 * Arguments provided via `load_template( $file, false, $args )`:
 *
 *   @var array $args {
 *       @type WP_Post[] $posts    List of related posts.
 *       @type string    $block_title    Block title (already sanitized in controller).
 *       @type string    $target   '_self' or '_blank'.
 *       @type string    $template Current template slug.
 *       @type int       $post_id  Source post ID.
 *   }
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( empty( $args['posts'] ) || ! is_array( $args['posts'] ) ) {
	return;
}

$block_title = isset( $args['title'] ) ? (string) $args['title'] : '';
$target      = isset( $args['target'] ) ? (string) $args['target'] : '_self';
$total       = count( $args['posts'] );
$index       = 0;
?>
<aside class="mvweb-sml-related mvweb-sml-related--inline" aria-label="<?php echo esc_attr( $block_title ); ?>">
	<span class="mvweb-sml-related__inline-body">
		<?php if ( '' !== $block_title ) : ?>
			<strong class="mvweb-sml-related__title-inline"><?php echo esc_html( $block_title ); ?>:</strong>
		<?php endif; ?>
		<?php foreach ( $args['posts'] as $related_post ) : ?>
			<?php ++$index; ?>
			<a
				class="mvweb-sml-related__chip"
				href="<?php echo esc_url( get_permalink( $related_post ) ); ?>"
				target="<?php echo esc_attr( $target ); ?>"
				<?php
				if ( '_blank' === $target ) :
					?>
					rel="noopener noreferrer"<?php endif; ?>
			>
				<?php echo esc_html( get_the_title( $related_post ) ); ?>
			</a>
			<?php if ( $index < $total ) : ?>
				<span class="mvweb-sml-related__sep" aria-hidden="true">·</span>
			<?php endif; ?>
		<?php endforeach; ?>
	</span>
</aside>
