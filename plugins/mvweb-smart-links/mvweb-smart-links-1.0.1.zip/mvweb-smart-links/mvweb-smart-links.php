<?php
/**
 * Plugin Name:       MVweb Smart Links
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-smart-links
 * Description:       Semi-automatic internal interlinking for content sites: contextual links, related posts, pillar clusters and reports.
 * Version:           1.0.1
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-smart-links
 * Domain Path:       /languages
 *
 * @package mvweb_sml
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_SML_VERSION' ) ) {
	return;
}

/**
 * Plugin version.
 */
define( 'MVWEB_SML_VERSION', '1.0.1' );

/**
 * Plugin directory path.
 */
define( 'MVWEB_SML_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Plugin directory URL.
 */
define( 'MVWEB_SML_URL', plugin_dir_url( __FILE__ ) );

/**
 * Plugin basename.
 */
define( 'MVWEB_SML_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_SML_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_SML_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_SML_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
// Do NOT rely on get_instance() at end of class file — OPcache may skip it.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_SML_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_SML_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-smart-links' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter(
	'mvweb_registered_plugins',
	function ( $plugins ) {
		$plugins['mvweb-smart-links'] = array(
			'name'         => __( 'MVweb Smart Links', 'mvweb-smart-links' ),
			'description'  => __( 'Semi-automatic internal interlinking for content sites: contextual links, related posts, pillar clusters and reports.', 'mvweb-smart-links' ),
			'url'          => 'https://mvweb.ru/plugins/mvweb-smart-links',
			'settings_url' => 'admin.php?page=mvweb-smart-links',
			'textdomain'   => 'mvweb-smart-links',
		);
		return $plugins;
	}
);

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_sml_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-smart-links',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_sml_load_textdomain', 4 );

// Admin controller (settings page, asset enqueue, AJAX router) lives in
// admin/class-mvweb-sml-admin.php. It is required and initialized below.
//
// Frontend assets and the_content filter are wired in MVweb_SML_Public,
// which is booted by MVweb_SML_Loader on `init`.

// Bootstrap files needed before plugins_loaded (helpers + activation).
require_once MVWEB_SML_PATH . 'includes/helpers.php';
require_once MVWEB_SML_PATH . 'includes/class-mvweb-sml-activator.php';
require_once MVWEB_SML_PATH . 'includes/class-mvweb-sml-deactivator.php';
require_once MVWEB_SML_PATH . 'includes/class-mvweb-sml-loader.php';

register_activation_hook( __FILE__, array( 'MVweb_SML_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'MVweb_SML_Deactivator', 'deactivate' ) );

/**
 * Boot the plugin loader on plugins_loaded.
 *
 * Priority 5 ensures classes are available before other components hook
 * into the standard `init` priority.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_sml_boot_loader() {
	if ( class_exists( 'MVweb_SML_Loader' ) ) {
		MVweb_SML_Loader::init();
	}
}
add_action( 'plugins_loaded', 'mvweb_sml_boot_loader', 5 );

/**
 * Register the custom 5-minute cron interval used by the indexer.
 *
 * Registered here (not in the loader) so it is available at activation time
 * when wp_schedule_event() is called.
 *
 * @since 1.0.0
 * @param array $schedules Existing cron schedules.
 * @return array Filtered schedules.
 */
function mvweb_sml_cron_schedules( $schedules ) {
	if ( ! isset( $schedules['mvweb_sml_5min'] ) ) {
		$schedules['mvweb_sml_5min'] = array(
			'interval' => 300,
			'display'  => __( 'Every 5 minutes (MVweb Smart Links)', 'mvweb-smart-links' ),
		);
	}
	return $schedules;
}
// phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval -- Background indexer requires sub-15-minute granularity to keep dirty queue current.
add_filter( 'cron_schedules', 'mvweb_sml_cron_schedules' );

/**
 * Redirect to the plugin settings page after activation.
 *
 * Guards against AJAX/REST/CLI/cron contexts and bulk-activate to avoid
 * hijacking unrelated requests (especially important on multisite).
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_sml_activation_redirect() {
	if ( ! is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
		return;
	}

	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	// Skip during bulk plugin activation.
	if ( isset( $_GET['activate-multi'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}

	if ( ! get_transient( 'mvweb_sml_activation_redirect' ) ) {
		return;
	}

	delete_transient( 'mvweb_sml_activation_redirect' );

	wp_safe_redirect( admin_url( 'admin.php?page=mvweb-smart-links&welcome=1' ) );
	exit;
}
add_action( 'admin_init', 'mvweb_sml_activation_redirect' );

/**
 * Display one-shot welcome admin notice on the plugin page after activation.
 *
 * Triggered by the `welcome=1` query argument set by the activation redirect.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_sml_welcome_notice() {
	if ( ! isset( $_GET['page'], $_GET['welcome'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}

	if ( 'mvweb-smart-links' !== $_GET['page'] || '1' !== $_GET['welcome'] ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		return;
	}

	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}

	printf(
		'<div class="notice notice-info"><p>%s</p></div>',
		esc_html__(
			'Configure MVweb Smart Links: enable plugin, run reindex, then add keywords.',
			'mvweb-smart-links'
		)
	);
}
add_action( 'admin_notices', 'mvweb_sml_welcome_notice' );
