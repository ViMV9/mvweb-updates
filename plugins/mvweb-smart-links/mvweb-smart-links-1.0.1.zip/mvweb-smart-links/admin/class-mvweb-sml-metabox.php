<?php
/**
 * Editor metabox: Keywords / Cluster & Manual links / Preview tabs.
 *
 * The metabox itself only persists post-meta on `save_post`. Keywords are
 * managed via AJAX (see MVweb_SML_Admin) and stored in the `_keywords` table
 * through MVweb_SML_Keyword_Manager.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Metabox
 *
 * @since 1.0.0
 */
class MVweb_SML_Metabox {

	/**
	 * Metabox HTML id.
	 */
	const METABOX_ID = 'mvweb_sml_metabox';

	/**
	 * Nonce action and field name.
	 */
	const NONCE_ACTION = 'mvweb_sml_metabox';
	const NONCE_FIELD  = 'mvweb_sml_metabox_nonce';

	/**
	 * Singleton bootstrap.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'add_meta_boxes', array( __CLASS__, 'register' ) );
		add_action( 'save_post', array( __CLASS__, 'save' ), 10, 2 );
	}

	/**
	 * Register the metabox on every supported post type.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register() {
		$post_types = mvweb_sml_supported_post_types();
		foreach ( $post_types as $post_type ) {
			add_meta_box(
				self::METABOX_ID,
				__( 'MVweb Smart Links', 'mvweb-smart-links' ),
				array( __CLASS__, 'render' ),
				$post_type,
				'normal',
				'default'
			);
		}
	}

	/**
	 * Render the metabox shell.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Post being edited.
	 * @return void
	 */
	public static function render( $post ) {
		wp_nonce_field( self::NONCE_ACTION, self::NONCE_FIELD );

		$keywords            = class_exists( 'MVweb_SML_Keyword_Manager' )
			? MVweb_SML_Keyword_Manager::get_for_post( (int) $post->ID )
			: array();
		$is_pillar           = '1' === (string) get_post_meta( $post->ID, '_mvweb_sml_pillar', true );
		$is_disabled         = '1' === (string) get_post_meta( $post->ID, '_mvweb_sml_disabled', true );
		$manual_targets      = (array) get_post_meta( $post->ID, '_mvweb_sml_manual_targets', true );
		$manual_targets      = array_values( array_filter( array_map( 'absint', $manual_targets ) ) );
		$outgoing_links      = self::get_links( (int) $post->ID, 'source_id' );
		$incoming_links      = self::get_links( (int) $post->ID, 'target_id' );
		$manual_targets_data = self::resolve_post_summaries( $manual_targets );

		// Flag whether each manual target's keyword actually occurs in this
		// post's prose, so the editor sees which manual links will really fire.
		$mvweb_sml_source_plain = wp_strip_all_tags( strip_shortcodes( (string) $post->post_content ) );
		foreach ( $manual_targets_data as &$mvweb_sml_mt ) {
			$mvweb_sml_mt['matches'] = self::manual_target_matches( $mvweb_sml_source_plain, (int) $mvweb_sml_mt['id'] );
		}
		unset( $mvweb_sml_mt );

		include MVWEB_SML_PATH . 'admin/views/metabox.php';
	}

	/**
	 * Whether a manual target's keyword occurs in the source post's prose.
	 *
	 * Mirrors the linker: a manual link fires where the target's first keyword
	 * (or, failing that, its title) matches — morphology-aware via the shared
	 * scanner pattern. Lets the metabox show a "will insert / no match" hint.
	 *
	 * @since 1.0.0
	 * @param string $source_plain Plain-text source content.
	 * @param int    $target_id    Manual target post id.
	 * @return bool
	 */
	private static function manual_target_matches( $source_plain, $target_id ) {
		if ( '' === (string) $source_plain || ! class_exists( 'MVweb_SML_DOM_Scanner' ) ) {
			return false;
		}

		$keyword = '';
		if ( class_exists( 'MVweb_SML_Keyword_Manager' ) ) {
			$kws = MVweb_SML_Keyword_Manager::get_for_post( $target_id );
			if ( ! empty( $kws ) ) {
				$keyword = (string) $kws[0]['keyword'];
			}
		}
		if ( '' === $keyword ) {
			$keyword = (string) get_the_title( $target_id );
		}
		if ( '' === $keyword ) {
			return false;
		}

		$pattern = MVweb_SML_DOM_Scanner::build_keyword_pattern( $keyword );
		return '' !== $pattern && (bool) preg_match( $pattern, $source_plain );
	}

	/**
	 * Persist post-meta on save.
	 *
	 * Keywords are NOT saved here — they are managed via AJAX endpoints, so
	 * concurrent editor edits cannot wipe them.
	 *
	 * @since 1.0.0
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @return void
	 */
	public static function save( $post_id, $post ) {
		if ( wp_is_post_autosave( $post_id ) || wp_is_post_revision( $post_id ) ) {
			return;
		}

		if ( ! isset( $_POST[ self::NONCE_FIELD ] ) ) {
			return;
		}

		$nonce = sanitize_text_field( wp_unslash( $_POST[ self::NONCE_FIELD ] ) );
		if ( ! wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		if ( ! ( $post instanceof WP_Post ) ) {
			return;
		}

		if ( ! in_array( $post->post_type, mvweb_sml_supported_post_types(), true ) ) {
			return;
		}

		$pillar   = isset( $_POST['mvweb_sml_pillar'] ) ? '1' : '0';
		$disabled = isset( $_POST['mvweb_sml_disabled'] ) ? '1' : '0';

		update_post_meta( $post_id, '_mvweb_sml_pillar', $pillar );
		update_post_meta( $post_id, '_mvweb_sml_disabled', $disabled );

		// Auto-create a draft cluster the first time a post is flagged as a
		// pillar. Subsequent saves no-op because ensure_draft_for_pillar()
		// returns the existing cluster id.
		if ( '1' === $pillar && class_exists( 'MVweb_SML_Cluster_Manager' ) ) {
			MVweb_SML_Cluster_Manager::ensure_draft_for_pillar( (int) $post_id );
		}

		// Nonce verified above; values are coerced to integers via absint(), so
		// the WordPress.Security.ValidatedSanitizedInput sniff is satisfied by
		// the explicit cast even though the array goes through wp_unslash() raw.
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$raw_targets = isset( $_POST['mvweb_sml_manual_targets'] ) ? (array) wp_unslash( $_POST['mvweb_sml_manual_targets'] ) : array();
		$targets     = array_values( array_unique( array_filter( array_map( 'absint', $raw_targets ) ) ) );

		// Drop self-links.
		$targets = array_values(
			array_filter(
				$targets,
				static function ( $tid ) use ( $post_id ) {
					return $tid !== (int) $post_id;
				}
			)
		);

		if ( ! empty( $targets ) ) {
			update_post_meta( $post_id, '_mvweb_sml_manual_targets', $targets );
		} else {
			delete_post_meta( $post_id, '_mvweb_sml_manual_targets' );
		}
	}

	/**
	 * Fetch link rows from the `_links` table for the Preview tab.
	 *
	 * @since 1.0.0
	 * @param int    $post_id Post ID.
	 * @param string $column  'source_id' or 'target_id'.
	 * @return array<int, array<string, mixed>>
	 */
	public static function get_links( $post_id, $column ) {
		global $wpdb;

		$column = 'target_id' === $column ? 'target_id' : 'source_id';
		$other  = 'target_id' === $column ? 'source_id' : 'target_id';
		$table  = mvweb_sml_table( 'links' );

		// $column is a hard-coded whitelist (source_id|target_id), $table is
		// owned by us — both are safe to interpolate.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, source_id, target_id, keyword, anchor, status, score
				 FROM `{$table}`
				 WHERE {$column} = %d
				 ORDER BY status ASC, score DESC
				 LIMIT 50",
				(int) $post_id
			),
			ARRAY_A
		);
		// phpcs:enable

		$out = array();
		foreach ( (array) $rows as $row ) {
			$other_id = (int) $row[ $other ];
			$out[]    = array(
				'id'        => (int) $row['id'],
				'source_id' => (int) $row['source_id'],
				'target_id' => (int) $row['target_id'],
				'other_id'  => $other_id,
				'keyword'   => (string) $row['keyword'],
				'anchor'    => (string) $row['anchor'],
				'status'    => (string) $row['status'],
				'score'     => (float) $row['score'],
				'title'     => get_the_title( $other_id ),
				'edit_url'  => get_edit_post_link( $other_id ),
			);
		}

		return $out;
	}

	/**
	 * Resolve a list of post IDs into title/edit-url tuples for the view.
	 *
	 * @since 1.0.0
	 * @param array<int, int> $ids Post IDs.
	 * @return array<int, array{id:int, title:string, edit_url:string|null}>
	 */
	public static function resolve_post_summaries( array $ids ) {
		$out = array();
		foreach ( $ids as $id ) {
			$id = (int) $id;
			if ( $id <= 0 ) {
				continue;
			}
			$out[] = array(
				'id'       => $id,
				'title'    => (string) get_the_title( $id ),
				'edit_url' => get_edit_post_link( $id ),
			);
		}
		return $out;
	}
}
