<?php
/**
 * Import / Export tab — SEO keyword import and CSV import/export.
 *
 * These operations are independent of the Settings API form, so they live on
 * their own tab with their own AJAX / admin-post forms.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'SEO plugin import', 'mvweb-smart-links' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Pull focus keywords from Yoast SEO, Rank Math or All in One SEO into the plugin keyword table. Their saved data is read directly, so the source plugin does not need to be active.', 'mvweb-smart-links' ); ?>
	</p>

	<div class="mvweb-sml-seo__detect-row">
		<button type="button" class="mvweb-btn mvweb-sml-seo__detect" id="mvweb-sml-seo-detect">
			<?php esc_html_e( 'Detect available sources', 'mvweb-smart-links' ); ?>
		</button>
	</div>

	<div class="mvweb-sml-seo__counts" id="mvweb-sml-seo-counts" aria-live="polite"></div>

	<div class="mvweb-sml-seo__actions" hidden>
		<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-sml-seo__import" data-source="yoast" disabled>
			<?php esc_html_e( 'Import Yoast', 'mvweb-smart-links' ); ?>
		</button>
		<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-sml-seo__import" data-source="rankmath" disabled>
			<?php esc_html_e( 'Import Rank Math', 'mvweb-smart-links' ); ?>
		</button>
		<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-sml-seo__import" data-source="aioseo" disabled>
			<?php esc_html_e( 'Import AIOSEO', 'mvweb-smart-links' ); ?>
		</button>
	</div>

	<p class="mvweb-sml-seo__status" aria-live="polite"></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'CSV import', 'mvweb-smart-links' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Upload a CSV with columns: post_id, keyword, synonyms (synonyms separated by semicolons). Max file size 5 MB.', 'mvweb-smart-links' ); ?>
	</p>

	<form class="mvweb-sml-csv__form" id="mvweb-sml-csv-import-form" enctype="multipart/form-data">
		<label class="mvweb-file">
			<input type="file" name="file" id="mvweb-sml-csv-file" accept=".csv,text/csv,text/plain" />
			<span class="mvweb-file__name"><?php esc_html_e( 'No file selected', 'mvweb-smart-links' ); ?></span>
		</label>
		<div class="mvweb-sml-csv__actions">
			<button type="button" class="mvweb-btn mvweb-btn--primary mvweb-sml-csv__import" id="mvweb-sml-csv-import">
				<?php esc_html_e( 'Import CSV', 'mvweb-smart-links' ); ?>
			</button>
		</div>
		<p class="mvweb-sml-csv__status" aria-live="polite"></p>
	</form>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'CSV export', 'mvweb-smart-links' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Download every keyword row as a CSV file, ready to open in Excel (Cyrillic text included correctly).', 'mvweb-smart-links' ); ?>
	</p>

	<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<input type="hidden" name="action" value="mvweb_sml_csv_export" />
		<?php wp_nonce_field( 'mvweb_sml_csv_export', '_wpnonce_csv_export' ); ?>
		<div class="mvweb-submit">
			<button type="submit" class="mvweb-btn">
				<?php esc_html_e( 'Export CSV', 'mvweb-smart-links' ); ?>
			</button>
		</div>
	</form>
</div>
