<?php
/**
 * Metabox view: Keywords / Cluster & Manual links / Preview tabs.
 *
 * Variables provided by MVweb_SML_Metabox::render():
 *
 * @var WP_Post $post
 * @var array   $keywords            List of keyword rows for this post.
 * @var bool    $is_pillar
 * @var bool    $is_disabled
 * @var array   $manual_targets      Plain list of post IDs.
 * @var array   $manual_targets_data Resolved [id, title, edit_url] tuples.
 * @var array   $outgoing_links      Rows from `_links` (source_id = $post->ID).
 * @var array   $incoming_links      Rows from `_links` (target_id = $post->ID).
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_sml_status_badge = array(
	'approved' => 'mvweb-badge--success',
	'auto'     => 'mvweb-badge--info',
	'pending'  => 'mvweb-badge--warning',
	'rejected' => 'mvweb-badge--error',
);
$mvweb_sml_status_label = array(
	'approved' => __( 'Approved', 'mvweb-smart-links' ),
	'auto'     => __( 'Auto', 'mvweb-smart-links' ),
	'pending'  => __( 'Pending', 'mvweb-smart-links' ),
	'rejected' => __( 'Rejected', 'mvweb-smart-links' ),
);
?>
<div class="mvweb-sml-metabox mvweb-ui" data-post-id="<?php echo esc_attr( (int) $post->ID ); ?>">
	<ul class="mvweb-sml-metabox__tabs">
		<li>
			<button type="button" class="mvweb-sml-metabox__tab is-active" data-tab="keywords">
				<?php esc_html_e( 'Keywords', 'mvweb-smart-links' ); ?>
			</button>
		</li>
		<li>
			<button type="button" class="mvweb-sml-metabox__tab" data-tab="cluster">
				<?php esc_html_e( 'Cluster &amp; Manual links', 'mvweb-smart-links' ); ?>
			</button>
		</li>
		<li>
			<button type="button" class="mvweb-sml-metabox__tab" data-tab="preview">
				<?php esc_html_e( 'Preview', 'mvweb-smart-links' ); ?>
			</button>
		</li>
	</ul>

	<?php /* ───────────────── Tab: Keywords ───────────────── */ ?>
	<div class="mvweb-sml-metabox__panel is-active" data-panel="keywords">
		<div class="mvweb-table-wrap">
			<table class="mvweb-table mvweb-sml-metabox__keywords">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Keyword', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Synonyms', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Source', 'mvweb-smart-links' ); ?></th>
						<th class="mvweb-sml-metabox__col-actions">&nbsp;</th>
					</tr>
				</thead>
				<tbody class="mvweb-sml-metabox__kw-list">
					<?php if ( empty( $keywords ) ) : ?>
						<tr class="mvweb-sml-metabox__empty">
							<td colspan="4">
								<?php esc_html_e( 'No keywords yet — add one below.', 'mvweb-smart-links' ); ?>
							</td>
						</tr>
					<?php else : ?>
						<?php foreach ( $keywords as $kw ) : ?>
							<tr class="mvweb-sml-metabox__kw-row" data-id="<?php echo esc_attr( $kw['id'] ); ?>">
								<td class="mvweb-sml-metabox__kw-cell" data-field="keyword">
									<span class="mvweb-sml-metabox__kw-text"><?php echo esc_html( $kw['keyword'] ); ?></span>
								</td>
								<td class="mvweb-sml-metabox__kw-cell" data-field="synonyms">
									<span class="mvweb-sml-metabox__kw-text"><?php echo esc_html( implode( ', ', $kw['synonyms'] ) ); ?></span>
								</td>
								<td><?php echo esc_html( $kw['source'] ); ?></td>
								<td class="mvweb-sml-metabox__col-actions">
									<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-sml-metabox__kw-edit">
										<?php esc_html_e( 'Edit', 'mvweb-smart-links' ); ?>
									</button>
									<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-sml-metabox__kw-delete">
										<?php esc_html_e( 'Delete', 'mvweb-smart-links' ); ?>
									</button>
								</td>
							</tr>
						<?php endforeach; ?>
					<?php endif; ?>
				</tbody>
			</table>
		</div>

		<div class="mvweb-sml-metabox__add">
			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label">
					<?php esc_html_e( 'Keyword', 'mvweb-smart-links' ); ?>
				</label>
				<div class="mvweb-form-row__field">
					<input type="text" class="mvweb-input mvweb-sml-metabox__add-keyword" />
				</div>
			</div>
			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label">
					<?php esc_html_e( 'Synonyms (comma-separated)', 'mvweb-smart-links' ); ?>
				</label>
				<div class="mvweb-form-row__field">
					<input type="text" class="mvweb-input mvweb-sml-metabox__add-synonyms" />
				</div>
			</div>
			<div>
				<button type="button" class="mvweb-btn mvweb-btn--primary mvweb-sml-metabox__add-btn">
					<?php esc_html_e( 'Add keyword', 'mvweb-smart-links' ); ?>
				</button>
				<button type="button" class="mvweb-btn mvweb-sml-metabox__suggest-btn">
					<?php esc_html_e( 'Suggest keywords', 'mvweb-smart-links' ); ?>
				</button>
			</div>
			<div class="mvweb-sml-metabox__suggestions" hidden>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Click a suggestion to add it.', 'mvweb-smart-links' ); ?></p>
				<ul class="mvweb-sml-metabox__suggestion-list"></ul>
			</div>
			<div class="mvweb-sml-metabox__notice" hidden></div>
		</div>

		<div class="mvweb-sml-metabox__queries">
			<div class="mvweb-form-row__label"><?php esc_html_e( 'Import from search queries', 'mvweb-smart-links' ); ?></div>
			<p class="mvweb-form-row__desc">
				<?php esc_html_e( 'Paste the queries this page ranks for (one per line: query, position, impressions — tab, semicolon or comma). Only queries within the position window and above the impressions threshold are added — the "almost there" queries an internal-link boost helps most.', 'mvweb-smart-links' ); ?>
			</p>
			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label"><?php esc_html_e( 'Source', 'mvweb-smart-links' ); ?></label>
				<div class="mvweb-form-row__field">
					<select class="mvweb-select mvweb-sml-metabox__q-source">
						<option value="yandex"><?php esc_html_e( 'Yandex Webmaster', 'mvweb-smart-links' ); ?></option>
						<option value="gsc"><?php esc_html_e( 'Google Search Console', 'mvweb-smart-links' ); ?></option>
					</select>
				</div>
			</div>
			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label"><?php esc_html_e( 'Position window', 'mvweb-smart-links' ); ?></label>
				<div class="mvweb-form-row__field mvweb-sml-metabox__q-range">
					<input type="number" class="mvweb-input mvweb-sml-metabox__q-minpos" value="4" min="1" max="100" step="1" />
					<span>–</span>
					<input type="number" class="mvweb-input mvweb-sml-metabox__q-maxpos" value="20" min="1" max="100" step="1" />
				</div>
			</div>
			<div class="mvweb-form-row">
				<label class="mvweb-form-row__label"><?php esc_html_e( 'Min impressions', 'mvweb-smart-links' ); ?></label>
				<div class="mvweb-form-row__field">
					<input type="number" class="mvweb-input mvweb-sml-metabox__q-minimpr" value="10" min="0" step="1" />
				</div>
			</div>
			<div class="mvweb-form-row">
				<div class="mvweb-form-row__field">
					<textarea class="mvweb-textarea mvweb-sml-metabox__q-text" rows="5" placeholder="<?php esc_attr_e( 'как настроить wi-fi на iphone	8.4	320', 'mvweb-smart-links' ); ?>"></textarea>
				</div>
			</div>
			<div>
				<button type="button" class="mvweb-btn mvweb-btn--primary mvweb-sml-metabox__q-import-btn">
					<?php esc_html_e( 'Import queries', 'mvweb-smart-links' ); ?>
				</button>
			</div>
			<div class="mvweb-sml-metabox__q-notice" hidden></div>
		</div>
	</div>

	<?php /* ───────────────── Tab: Cluster & Manual links ───────────────── */ ?>
	<div class="mvweb-sml-metabox__panel" data-panel="cluster">
		<h4 class="mvweb-block__title mvweb-sml-metabox__section-title"><?php esc_html_e( 'Post options', 'mvweb-smart-links' ); ?></h4>
		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label" aria-hidden="true"></span>
			<div class="mvweb-form-row__field">
				<label class="mvweb-check">
					<input type="checkbox" name="mvweb_sml_pillar" value="1" <?php checked( $is_pillar ); ?> />
					<?php esc_html_e( 'Pillar page (cluster hub)', 'mvweb-smart-links' ); ?>
				</label>
			</div>
		</div>
		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label" aria-hidden="true"></span>
			<div class="mvweb-form-row__field">
				<label class="mvweb-check">
					<input type="checkbox" name="mvweb_sml_disabled" value="1" <?php checked( $is_disabled ); ?> />
					<?php esc_html_e( 'Disable interlinking on this post', 'mvweb-smart-links' ); ?>
				</label>
			</div>
		</div>

		<h4 class="mvweb-block__title mvweb-sml-metabox__section-title"><?php esc_html_e( 'Manual links', 'mvweb-smart-links' ); ?></h4>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'Search for posts you want to link to from this article. Manual links are inserted before automatic ones.', 'mvweb-smart-links' ); ?>
		</p>
		<div>
			<input type="text" class="mvweb-input mvweb-sml-metabox__search" placeholder="<?php esc_attr_e( 'Search posts…', 'mvweb-smart-links' ); ?>" />
		</div>
		<ul class="mvweb-sml-metabox__search-results" hidden></ul>

		<ul class="mvweb-sml-metabox__manual-list">
			<?php foreach ( $manual_targets_data as $target ) : ?>
				<li class="mvweb-sml-metabox__manual-item" data-id="<?php echo esc_attr( $target['id'] ); ?>">
					<input type="hidden" name="mvweb_sml_manual_targets[]" value="<?php echo esc_attr( $target['id'] ); ?>" />
					<span class="mvweb-sml-metabox__manual-title">
						<?php if ( $target['edit_url'] ) : ?>
							<a href="<?php echo esc_url( $target['edit_url'] ); ?>" target="_blank" rel="noopener">
								<?php echo esc_html( $target['title'] ); ?>
							</a>
						<?php else : ?>
							<?php echo esc_html( $target['title'] ); ?>
						<?php endif; ?>
					</span>
					<?php if ( ! empty( $target['matches'] ) ) : ?>
						<span class="mvweb-badge mvweb-badge--success mvweb-sml-metabox__manual-flag" title="<?php esc_attr_e( 'This target\'s keyword occurs in the post, so the link will be inserted.', 'mvweb-smart-links' ); ?>"><?php esc_html_e( 'Will insert', 'mvweb-smart-links' ); ?></span>
					<?php else : ?>
						<span class="mvweb-badge mvweb-badge--warning mvweb-sml-metabox__manual-flag" title="<?php esc_attr_e( 'No matching phrase found in the post yet — add the keyword to the text or register it on the target.', 'mvweb-smart-links' ); ?>"><?php esc_html_e( 'No match', 'mvweb-smart-links' ); ?></span>
					<?php endif; ?>
					<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-sml-metabox__manual-remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-smart-links' ); ?>">
						&times;
					</button>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>

	<?php /* ───────────────── Tab: Preview ───────────────── */ ?>
	<div class="mvweb-sml-metabox__panel" data-panel="preview">
		<h4 class="mvweb-block__title mvweb-sml-metabox__section-title"><?php esc_html_e( 'Outgoing links', 'mvweb-smart-links' ); ?></h4>
		<?php if ( empty( $outgoing_links ) ) : ?>
			<p class="mvweb-block__sub">
				<?php esc_html_e( 'No outgoing links yet. Run "Generate suggestions" or save the post after configuring keywords.', 'mvweb-smart-links' ); ?>
			</p>
		<?php else : ?>
			<div class="mvweb-table-wrap">
				<table class="mvweb-table mvweb-sml-metabox__preview">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Target', 'mvweb-smart-links' ); ?></th>
							<th><?php esc_html_e( 'Anchor', 'mvweb-smart-links' ); ?></th>
							<th><?php esc_html_e( 'Status', 'mvweb-smart-links' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $outgoing_links as $row ) : ?>
							<tr>
								<td>
									<?php if ( $row['edit_url'] ) : ?>
										<a href="<?php echo esc_url( $row['edit_url'] ); ?>" target="_blank" rel="noopener">
											<?php echo esc_html( $row['title'] ); ?>
										</a>
									<?php else : ?>
										<?php echo esc_html( $row['title'] ); ?>
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( $row['anchor'] ); ?></td>
								<td>
									<?php
									$mvweb_sml_badge = isset( $mvweb_sml_status_badge[ $row['status'] ] )
										? $mvweb_sml_status_badge[ $row['status'] ]
										: 'mvweb-badge--plain';
									?>
									<span class="mvweb-badge <?php echo esc_attr( $mvweb_sml_badge ); ?>"><?php echo esc_html( isset( $mvweb_sml_status_label[ $row['status'] ] ) ? $mvweb_sml_status_label[ $row['status'] ] : $row['status'] ); ?></span>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>

		<h4 class="mvweb-block__title mvweb-sml-metabox__section-title"><?php esc_html_e( 'Incoming links', 'mvweb-smart-links' ); ?></h4>
		<?php if ( empty( $incoming_links ) ) : ?>
			<p class="mvweb-block__sub">
				<?php esc_html_e( 'No incoming links yet.', 'mvweb-smart-links' ); ?>
			</p>
		<?php else : ?>
			<div class="mvweb-table-wrap">
				<table class="mvweb-table mvweb-sml-metabox__preview">
					<thead>
						<tr>
							<th><?php esc_html_e( 'Source', 'mvweb-smart-links' ); ?></th>
							<th><?php esc_html_e( 'Anchor', 'mvweb-smart-links' ); ?></th>
							<th><?php esc_html_e( 'Status', 'mvweb-smart-links' ); ?></th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $incoming_links as $row ) : ?>
							<tr>
								<td>
									<?php if ( $row['edit_url'] ) : ?>
										<a href="<?php echo esc_url( $row['edit_url'] ); ?>" target="_blank" rel="noopener">
											<?php echo esc_html( $row['title'] ); ?>
										</a>
									<?php else : ?>
										<?php echo esc_html( $row['title'] ); ?>
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( $row['anchor'] ); ?></td>
								<td>
									<?php
									$mvweb_sml_badge = isset( $mvweb_sml_status_badge[ $row['status'] ] )
										? $mvweb_sml_status_badge[ $row['status'] ]
										: 'mvweb-badge--plain';
									?>
									<span class="mvweb-badge <?php echo esc_attr( $mvweb_sml_badge ); ?>"><?php echo esc_html( isset( $mvweb_sml_status_label[ $row['status'] ] ) ? $mvweb_sml_status_label[ $row['status'] ] : $row['status'] ); ?></span>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>
	</div>
</div>
