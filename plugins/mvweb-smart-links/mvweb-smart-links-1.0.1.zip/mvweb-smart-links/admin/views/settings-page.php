<?php
/**
 * Admin settings page wrapper with tabs.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Read current tab from URL hash fallback (read-only navigation, no nonce).
// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$current_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';

$mvweb_sml_tabs = array(
	'dashboard' => array(
		'label' => __( 'Dashboard', 'mvweb-smart-links' ),
		'icon'  => 'grid',
	),
	'keywords'  => array(
		'label' => __( 'Keywords', 'mvweb-smart-links' ),
		'icon'  => 'tag',
	),
	'clusters'  => array(
		'label' => __( 'Clusters', 'mvweb-smart-links' ),
		'icon'  => 'share',
	),
	'reports'   => array(
		'label' => __( 'Reports', 'mvweb-smart-links' ),
		'icon'  => 'chart',
	),
	'settings'  => array(
		'label' => __( 'Settings', 'mvweb-smart-links' ),
		'icon'  => 'gear',
	),
	'import'    => array(
		'label' => __( 'Import / Export', 'mvweb-smart-links' ),
		'icon'  => 'transfer',
	),
	'help'      => array(
		'label' => __( 'Help', 'mvweb-smart-links' ),
		'icon'  => 'help',
	),
);

if ( ! array_key_exists( $current_tab, $mvweb_sml_tabs ) ) {
	$current_tab = 'dashboard';
}

$mvweb_sml_icons = array(
	'grid'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
	'tag'      => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41 13.42 20.6a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/></svg>',
	'share'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>',
	'chart'    => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>',
	'gear'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>',
	'help'     => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
	'transfer' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg>',
);

$mvweb_sml_settings = MVweb_SML_Settings::get();
?>

<div class="wrap mvweb-settings mvweb-sml">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">SML</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Smart Links', 'mvweb-smart-links' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_SML_VERSION ); ?></div>
			</div>
		</div>

		<?php
		// Active interlinking mode, surfaced on every screen so the operator always
		// knows whether the plugin is acting on its own (auto) or waiting for review.
		$mvweb_sml_mode     = isset( $mvweb_sml_settings['mode'] ) ? (string) $mvweb_sml_settings['mode'] : 'semi';
		$mvweb_sml_mode_map = array(
			'manual' => array( __( 'Manual', 'mvweb-smart-links' ), __( 'You curate links by hand in the editor.', 'mvweb-smart-links' ) ),
			'semi'   => array( __( 'Semi-automatic', 'mvweb-smart-links' ), __( 'The plugin suggests; you approve.', 'mvweb-smart-links' ) ),
			'auto'   => array( __( 'Automatic', 'mvweb-smart-links' ), __( 'The plugin approves high-confidence links without review.', 'mvweb-smart-links' ) ),
		);
		$mvweb_sml_mode_cur = isset( $mvweb_sml_mode_map[ $mvweb_sml_mode ] ) ? $mvweb_sml_mode_map[ $mvweb_sml_mode ] : $mvweb_sml_mode_map['semi'];
		?>
		<div class="mvweb-sml-mode-badge" title="<?php echo esc_attr( $mvweb_sml_mode_cur[1] ); ?>">
			<span class="mvweb-sml-mode-badge__label"><?php esc_html_e( 'Mode', 'mvweb-smart-links' ); ?></span>
			<span class="mvweb-sml-mode-badge__pill mvweb-sml-mode-badge__pill--<?php echo esc_attr( $mvweb_sml_mode ); ?>"><?php echo esc_html( $mvweb_sml_mode_cur[0] ); ?></span>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $mvweb_sml_tabs as $mvweb_sml_tab_id => $mvweb_sml_tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $mvweb_sml_tab_id ); ?>"
						class="mvweb-nav__link <?php echo $current_tab === $mvweb_sml_tab_id ? 'mvweb-nav__link--active' : ''; ?>"
						data-tab="<?php echo esc_attr( $mvweb_sml_tab_id ); ?>">
						<?php echo $mvweb_sml_icons[ $mvweb_sml_tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $mvweb_sml_tab['label'] ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php settings_errors( 'mvweb_sml_messages' ); ?>

		<div id="dashboard" class="mvweb-tab-content <?php echo 'dashboard' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SML_PATH . 'admin/views/tab-dashboard.php'; ?>
		</div>

		<div id="keywords" class="mvweb-tab-content <?php echo 'keywords' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SML_PATH . 'admin/views/tab-keywords.php'; ?>
		</div>

		<div id="clusters" class="mvweb-tab-content <?php echo 'clusters' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SML_PATH . 'admin/views/tab-clusters.php'; ?>
		</div>

		<div id="reports" class="mvweb-tab-content <?php echo 'reports' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SML_PATH . 'admin/views/tab-reports.php'; ?>
		</div>

		<div id="settings" class="mvweb-tab-content <?php echo 'settings' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SML_PATH . 'admin/views/tab-settings.php'; ?>
		</div>

		<div id="import" class="mvweb-tab-content <?php echo 'import' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SML_PATH . 'admin/views/tab-import.php'; ?>
		</div>

		<div id="help" class="mvweb-tab-content <?php echo 'help' === $current_tab ? 'active' : ''; ?>">
			<?php require MVWEB_SML_PATH . 'admin/views/tab-help.php'; ?>
		</div>

	</main>
</div>
