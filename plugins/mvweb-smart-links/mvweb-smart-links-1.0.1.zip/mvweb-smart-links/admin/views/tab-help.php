<?php
/**
 * Help tab template for MVweb Smart Links.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Quick Start', 'mvweb-smart-links' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Enable the plugin', 'mvweb-smart-links' ); ?></strong>
			<p><?php esc_html_e( 'Open the Settings tab and turn on the main toggle.', 'mvweb-smart-links' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Run the initial reindex', 'mvweb-smart-links' ); ?></strong>
			<p><?php esc_html_e( 'Use the Maintenance section to build the content index. This is required before any links can be inserted.', 'mvweb-smart-links' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Add keywords', 'mvweb-smart-links' ); ?></strong>
			<p><?php esc_html_e( 'Open any post and use the Smart Links metabox to add target keywords — or import focus keywords / search queries on the Import tab.', 'mvweb-smart-links' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Generate suggestions', 'mvweb-smart-links' ); ?></strong>
			<p><?php esc_html_e( 'On the Keywords tab press “Generate suggestions”. The plugin scans your content and proposes source → target links ranked by topical relevance.', 'mvweb-smart-links' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Review and approve', 'mvweb-smart-links' ); ?></strong>
			<p><?php esc_html_e( 'Approve, reject or edit the anchor of each suggestion — or filter and apply an action to all matching rows at once. Approved links render on the front end wherever the keyword occurs.', 'mvweb-smart-links' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Monitor and refine', 'mvweb-smart-links' ); ?></strong>
			<p><?php esc_html_e( 'Use the Reports tab to watch orphans, broken links, anchor over-optimisation and click activity, then keep adding keywords to grow coverage.', 'mvweb-smart-links' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Features', 'mvweb-smart-links' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'What the plugin can do.', 'mvweb-smart-links' ); ?></p>
	<ul>
		<li><?php esc_html_e( 'Contextual links inserted into post content based on per-post keywords.', 'mvweb-smart-links' ); ?></li>
		<li><?php esc_html_e( '"Read also" related-posts block with three layout templates.', 'mvweb-smart-links' ); ?></li>
		<li><?php esc_html_e( 'Pillar / cluster topical groups with health metrics.', 'mvweb-smart-links' ); ?></li>
		<li><?php esc_html_e( 'Reports: orphans, broken links, keyword cannibalization, crawl depth.', 'mvweb-smart-links' ); ?></li>
		<li><?php esc_html_e( 'Background indexing via WP Cron — no impact on front-end response time.', 'mvweb-smart-links' ); ?></li>
		<li><?php esc_html_e( 'WPML / Polylang aware: links are kept within the same language.', 'mvweb-smart-links' ); ?></li>
	</ul>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Glossary', 'mvweb-smart-links' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Key terms in plain language.', 'mvweb-smart-links' ); ?></p>
	<div class="mvweb-table-wrap">
		<table class="mvweb-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'Term', 'mvweb-smart-links' ); ?></th>
					<th><?php esc_html_e( 'Meaning', 'mvweb-smart-links' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<tr><td><?php esc_html_e( 'Pillar page', 'mvweb-smart-links' ); ?></td><td><?php esc_html_e( 'The main page a topic cluster is built around; its spokes link back to it.', 'mvweb-smart-links' ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Spoke', 'mvweb-smart-links' ); ?></td><td><?php esc_html_e( 'A supporting article that links back to its pillar page.', 'mvweb-smart-links' ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Anchor', 'mvweb-smart-links' ); ?></td><td><?php esc_html_e( 'The visible clickable text of a link.', 'mvweb-smart-links' ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Orphan page', 'mvweb-smart-links' ); ?></td><td><?php esc_html_e( 'A page nothing links to yet — hard for visitors and search engines to find.', 'mvweb-smart-links' ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Crawl depth', 'mvweb-smart-links' ); ?></td><td><?php esc_html_e( 'How many clicks it takes to reach a page from the homepage.', 'mvweb-smart-links' ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Keyword cannibalization', 'mvweb-smart-links' ); ?></td><td><?php esc_html_e( 'Several pages competing for the same search query, so none ranks well.', 'mvweb-smart-links' ); ?></td></tr>
				<tr><td><?php esc_html_e( 'Score', 'mvweb-smart-links' ); ?></td><td><?php esc_html_e( 'How strongly two pages share the same topic — higher means a stronger match.', 'mvweb-smart-links' ); ?></td></tr>
			</tbody>
		</table>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Cron setup', 'mvweb-smart-links' ); ?></div>
	</div>
	<p><?php esc_html_e( 'Smart Links rebuilds its content index in the background every five minutes using WP Cron.', 'mvweb-smart-links' ); ?></p>
	<p>
		<?php
		echo wp_kses(
			sprintf(
				/* translators: %s: wp-config.php constant wrapped in <code> */
				__( 'For best results on busy sites, disable WP Cron in %s and trigger it from a real system cron job at least once per minute.', 'mvweb-smart-links' ),
				'<code>wp-config.php</code>'
			),
			array( 'code' => array() )
		);
		?>
	</p>
	<div class="mvweb-codeblock">define( 'DISABLE_WP_CRON', true );</div>
	<div class="mvweb-codeblock">* * * * * curl -s https://example.com/wp-cron.php?doing_wp_cron &gt; /dev/null</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Frequently Asked Questions', 'mvweb-smart-links' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Why are links not appearing on my posts?', 'mvweb-smart-links' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Make sure (1) the main toggle is enabled, (2) the post type is in the supported list, (3) the initial reindex has finished (check “Index status” on the Dashboard), and (4) the post has at least one keyword that matches another post.', 'mvweb-smart-links' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'How do I exclude a single post from receiving links?', 'mvweb-smart-links' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Either add its ID to the global blacklist on the Settings tab, or check "Disable on this post" inside the Smart Links metabox.', 'mvweb-smart-links' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Can I import keywords from Yoast or Rank Math?', 'mvweb-smart-links' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Yes — the Import / Export section will detect installed SEO plugins and import their focus keyphrases.', 'mvweb-smart-links' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Is removing the plugin destructive?', 'mvweb-smart-links' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'No — by default the plugin keeps its tables on uninstall. To wipe everything, enable "Delete data on uninstall" in Maintenance before deleting the plugin.', 'mvweb-smart-links' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-smart-links' ); ?></div>
	</div>
	<p>
		<?php
		echo wp_kses(
			sprintf(
				/* translators: %s: link to the MVweb Smart Links plugin page */
				__( 'Need help? Visit %s for documentation and support.', 'mvweb-smart-links' ),
				'<a href="https://mvweb.ru/plugins/mvweb-smart-links" target="_blank" rel="noopener">mvweb.ru</a>'
			),
			array(
				'a' => array(
					'href'   => array(),
					'target' => array(),
					'rel'    => array(),
				),
			)
		);
		?>
	</p>
	<p>
		<strong><?php esc_html_e( 'Version:', 'mvweb-smart-links' ); ?></strong>
		<code><?php echo esc_html( MVWEB_SML_VERSION ); ?></code>
	</p>
</div>
