<?php
/**
 * Dashboard tab — top-level metrics and quick actions (TZ §9).
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'MVweb_SML_Reports' ) ) {
	echo '<div class="mvweb-block"><p>' . esc_html__( 'Reports module is not loaded.', 'mvweb-smart-links' ) . '</p></div>';
	return;
}

$mvweb_sml_total_posts = MVweb_SML_Reports::total_supported_posts();
$mvweb_sml_total_links = MVweb_SML_Reports::total_auto_links();
$mvweb_sml_index       = MVweb_SML_Reports::index_status();
// Single query up to 1000 rows → top 10 for the table, count() for the metric.
$mvweb_sml_orphan_all  = MVweb_SML_Reports::orphans( 1000 );
$mvweb_sml_orphan_list = array_slice( $mvweb_sml_orphan_all, 0, 10 );
$mvweb_sml_orphan_cnt  = count( $mvweb_sml_orphan_all );
$mvweb_sml_broken      = MVweb_SML_Reports::broken_links();
$mvweb_sml_broken_cnt  = count( $mvweb_sml_broken );
$mvweb_sml_stats       = MVweb_SML_Reports::link_stats();
$mvweb_sml_crawl       = MVweb_SML_Reports::crawl_depth();
?>
<div class="mvweb-block mvweb-sml-dashboard__next">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Next step', 'mvweb-smart-links' ); ?></div>
	</div>
	<?php if ( 0 === (int) $mvweb_sml_index['total'] ) : ?>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Nothing is indexed yet. Enable the plugin on the Settings tab and run the initial reindex — it builds the content index every link relies on.', 'mvweb-smart-links' ); ?></p>
		<a href="#settings" class="mvweb-btn mvweb-btn--primary mvweb-sml-goto-tab" data-tab="settings"><?php esc_html_e( 'Open Settings', 'mvweb-smart-links' ); ?></a>
	<?php elseif ( 0 === (int) $mvweb_sml_total_links ) : ?>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Your content is indexed. Add target keywords (in the post editor or via import), then generate suggestions and approve the ones you want.', 'mvweb-smart-links' ); ?></p>
		<a href="#keywords" class="mvweb-btn mvweb-btn--primary mvweb-sml-goto-tab" data-tab="keywords"><?php esc_html_e( 'Generate suggestions', 'mvweb-smart-links' ); ?></a>
	<?php else : ?>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Links are live. Review pending suggestions, diversify anchors, or add more keywords to grow internal linking.', 'mvweb-smart-links' ); ?></p>
		<a href="#keywords" class="mvweb-btn mvweb-btn--primary mvweb-sml-goto-tab" data-tab="keywords"><?php esc_html_e( 'Review suggestions', 'mvweb-smart-links' ); ?></a>
	<?php endif; ?>
</div>

<div class="mvweb-block mvweb-sml-dashboard">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Smart Links overview', 'mvweb-smart-links' ); ?></div>
	</div>

	<div class="mvweb-metrics">
		<div class="mvweb-metric" title="<?php esc_attr_e( 'Content types this plugin is allowed to link, set on the Settings tab.', 'mvweb-smart-links' ); ?>">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Supported posts', 'mvweb-smart-links' ); ?></div>
			<div class="mvweb-metric__value"><?php echo esc_html( number_format_i18n( $mvweb_sml_total_posts ) ); ?></div>
		</div>
		<div class="mvweb-metric">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Auto links', 'mvweb-smart-links' ); ?></div>
			<div class="mvweb-metric__value"><?php echo esc_html( number_format_i18n( $mvweb_sml_total_links ) ); ?></div>
		</div>
		<div class="mvweb-metric" title="<?php esc_attr_e( 'Pages nothing links to yet — hard for visitors and search engines to find.', 'mvweb-smart-links' ); ?>">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Orphan pages', 'mvweb-smart-links' ); ?></div>
			<div class="mvweb-metric__value"><?php echo esc_html( number_format_i18n( $mvweb_sml_orphan_cnt ) ); ?></div>
		</div>
		<div class="mvweb-metric">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Broken links', 'mvweb-smart-links' ); ?></div>
			<div class="mvweb-metric__value"><?php echo esc_html( number_format_i18n( $mvweb_sml_broken_cnt ) ); ?></div>
		</div>
		<div class="mvweb-metric" title="<?php esc_attr_e( 'Average number of internal links pointing to a page.', 'mvweb-smart-links' ); ?>">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Avg incoming', 'mvweb-smart-links' ); ?></div>
			<div class="mvweb-metric__value">
				<?php
				echo esc_html(
					number_format_i18n( isset( $mvweb_sml_stats['avg_incoming'] ) ? (float) $mvweb_sml_stats['avg_incoming'] : 0, 2 )
				);
				?>
			</div>
		</div>
		<div class="mvweb-metric" title="<?php esc_attr_e( 'Average number of internal links a page points to.', 'mvweb-smart-links' ); ?>">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Avg outgoing', 'mvweb-smart-links' ); ?></div>
			<div class="mvweb-metric__value">
				<?php
				echo esc_html(
					number_format_i18n( isset( $mvweb_sml_stats['avg_outgoing'] ) ? (float) $mvweb_sml_stats['avg_outgoing'] : 0, 2 )
				);
				?>
			</div>
		</div>
		<div class="mvweb-metric" title="<?php esc_attr_e( 'Average number of clicks from the homepage to reach a page.', 'mvweb-smart-links' ); ?>">
			<div class="mvweb-metric__label"><?php esc_html_e( 'Avg crawl depth', 'mvweb-smart-links' ); ?></div>
			<div class="mvweb-metric__value">
				<?php
				if ( '' !== $mvweb_sml_crawl['reason'] ) {
					echo esc_html( '—' );
				} else {
					echo esc_html( number_format_i18n( $mvweb_sml_crawl['average'], 2 ) );
				}
				?>
			</div>
		</div>
	</div>
</div>

<?php
$mvweb_sml_idx_total   = (int) $mvweb_sml_index['total'];
$mvweb_sml_idx_dirty   = (int) $mvweb_sml_index['dirty'];
$mvweb_sml_idx_done    = max( 0, $mvweb_sml_idx_total - $mvweb_sml_idx_dirty );
$mvweb_sml_idx_percent = $mvweb_sml_idx_total > 0
	? (int) round( $mvweb_sml_idx_done / $mvweb_sml_idx_total * 100 )
	: 0;

if ( 0 === $mvweb_sml_idx_total ) {
	$mvweb_sml_idx_state = 'bad';
} elseif ( $mvweb_sml_idx_dirty > 0 ) {
	$mvweb_sml_idx_state = 'ok';
} else {
	$mvweb_sml_idx_state = 'good';
}

if ( '' === $mvweb_sml_index['last_indexed'] ) {
	$mvweb_sml_idx_last = __( 'never', 'mvweb-smart-links' );
} else {
	$mvweb_sml_idx_last = mysql2date(
		get_option( 'date_format' ) . ' ' . get_option( 'time_format' ),
		$mvweb_sml_index['last_indexed']
	);
}
?>
<div class="mvweb-block mvweb-sml-dashboard__index">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Index status', 'mvweb-smart-links' ); ?></div>
	</div>

	<div class="mvweb-sml-dashboard__index-progress">
		<div class="mvweb-sml-dashboard__index-caption">
			<span>
				<?php
				printf(
					/* translators: 1: number of indexed posts, 2: total supported posts. */
					esc_html__( 'Indexed %1$s of %2$s', 'mvweb-smart-links' ),
					'<strong>' . esc_html( number_format_i18n( $mvweb_sml_idx_done ) ) . '</strong>',
					esc_html( number_format_i18n( $mvweb_sml_idx_total ) )
				);
				?>
			</span>
			<span class="mvweb-sml-dashboard__index-percent"><?php echo esc_html( $mvweb_sml_idx_percent . '%' ); ?></span>
		</div>
		<div class="mvweb-progress mvweb-progress--<?php echo esc_attr( $mvweb_sml_idx_state ); ?>">
			<span class="mvweb-progress__bar" style="width:<?php echo esc_attr( $mvweb_sml_idx_percent ); ?>%"></span>
		</div>
	</div>

	<div class="mvweb-sml-dashboard__index-stats">
		<div class="mvweb-stat">
			<span class="mvweb-stat__value"><?php echo esc_html( number_format_i18n( $mvweb_sml_idx_total ) ); ?></span>
			<span class="mvweb-stat__label"><?php esc_html_e( 'in index', 'mvweb-smart-links' ); ?></span>
		</div>
		<div class="mvweb-stat">
			<span class="mvweb-stat__value <?php echo $mvweb_sml_idx_dirty > 0 ? 'mvweb-stat__value--brand' : ''; ?>"><?php echo esc_html( number_format_i18n( $mvweb_sml_idx_dirty ) ); ?></span>
			<span class="mvweb-stat__label"><?php esc_html_e( 'in queue', 'mvweb-smart-links' ); ?></span>
		</div>
		<div class="mvweb-stat mvweb-sml-dashboard__index-stat--date">
			<span class="mvweb-stat__value"><?php echo esc_html( $mvweb_sml_idx_last ); ?></span>
			<span class="mvweb-stat__label"><?php esc_html_e( 'last indexed', 'mvweb-smart-links' ); ?></span>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Top orphan pages', 'mvweb-smart-links' ); ?></div>
	</div>
	<?php if ( empty( $mvweb_sml_orphan_list ) ) : ?>
		<p><?php esc_html_e( 'No orphans — every supported post has at least one incoming link.', 'mvweb-smart-links' ); ?></p>
	<?php else : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table mvweb-sml-dashboard__orphans">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Title', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Type', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'mvweb-smart-links' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $mvweb_sml_orphan_list as $mvweb_sml_orphan ) : ?>
						<?php
						$mvweb_sml_edit_url = (string) get_edit_post_link( $mvweb_sml_orphan->ID );
						?>
						<tr>
							<td><?php echo esc_html( get_the_title( $mvweb_sml_orphan ) ); ?></td>
							<td><?php echo esc_html( $mvweb_sml_orphan->post_type ); ?></td>
							<td class="cell-actions">
								<a href="<?php echo esc_url( $mvweb_sml_edit_url . '#mvweb_sml_metabox' ); ?>"
									class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm"
									title="<?php esc_attr_e( 'Register a keyword on this page so other posts link to it.', 'mvweb-smart-links' ); ?>">
									<?php esc_html_e( 'Add inbound link', 'mvweb-smart-links' ); ?>
								</a>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</div>
