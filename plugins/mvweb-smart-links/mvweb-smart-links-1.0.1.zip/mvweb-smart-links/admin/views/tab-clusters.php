<?php
/**
 * Clusters tab — Pillar-Cluster CRUD UI (phase 10).
 *
 * Renders an empty shell that the JS controller (`initClusters` in admin.js)
 * fills via AJAX endpoints in MVweb_SML_Admin. Server-side templating is kept
 * minimal so all interactions stay reactive.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="mvweb-sml-clusters">
	<div class="mvweb-block">
		<div class="mvweb-block__head mvweb-sml-clusters__header">
			<div class="mvweb-block__title"><?php esc_html_e( 'Create a new cluster', 'mvweb-smart-links' ); ?></div>
		</div>
		<p class="mvweb-block__sub">
			<?php esc_html_e( 'A cluster is a simple structure: one main page (the pillar) plus supporting articles (spokes) that all link back to it. Group a pillar with its spokes below — spokes that link back to the pillar are shown as healthy.', 'mvweb-smart-links' ); ?>
		</p>

		<div class="mvweb-sml-clusters__create-fields">
			<label class="mvweb-sml-clusters__field mvweb-sml-clusters__field--pillar">
				<span><?php esc_html_e( 'Pillar page', 'mvweb-smart-links' ); ?></span>
				<input
					type="text"
					class="mvweb-input mvweb-sml-clusters__pillar-search"
					placeholder="<?php esc_attr_e( 'Search for a post…', 'mvweb-smart-links' ); ?>"
					autocomplete="off"
				/>
				<input type="hidden" class="mvweb-sml-clusters__pillar-id" value="" />
				<ul class="mvweb-sml-clusters__autocomplete" hidden></ul>
			</label>

			<label class="mvweb-sml-clusters__field mvweb-sml-clusters__field--name">
				<span><?php esc_html_e( 'Cluster name', 'mvweb-smart-links' ); ?></span>
				<input
					type="text"
					class="mvweb-input mvweb-sml-clusters__name"
					placeholder="<?php esc_attr_e( 'Optional — defaults to the pillar title', 'mvweb-smart-links' ); ?>"
				/>
			</label>

			<button type="button" class="mvweb-btn mvweb-btn--primary mvweb-sml-clusters__create-btn">
				<?php esc_html_e( 'Create', 'mvweb-smart-links' ); ?>
			</button>
		</div>
		<p class="mvweb-sml-clusters__create-status" hidden></p>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Clusters', 'mvweb-smart-links' ); ?></div>
		</div>
		<div class="mvweb-sml-clusters__list" aria-live="polite">
			<p class="mvweb-sml-clusters__loading"><?php esc_html_e( 'Loading clusters…', 'mvweb-smart-links' ); ?></p>
		</div>
	</div>
</div>
