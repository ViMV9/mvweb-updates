<?php
/**
 * Keywords tab — bulk suggestion management (phase 9).
 *
 * Exposes a paginated + filterable view of every `_links` row with inline
 * anchor editing, bulk approve/reject and a "Generate suggestions" sweep.
 *
 * NOTE: this file is included from admin/views/settings-page.php while it is
 * already wrapped in `<form action="options.php">`, so the bulk UI is built
 * without nested forms — all interactions go through AJAX.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$mvweb_sml_bulk_cpts = array();
foreach ( mvweb_sml_supported_post_types() as $mvweb_sml_bulk_pt ) {
	$mvweb_sml_bulk_pt_obj = get_post_type_object( $mvweb_sml_bulk_pt );
	if ( $mvweb_sml_bulk_pt_obj ) {
		$mvweb_sml_bulk_cpts[ $mvweb_sml_bulk_pt ] = $mvweb_sml_bulk_pt_obj->labels->singular_name;
	}
}

$mvweb_sml_bulk_categories = get_terms(
	array(
		'taxonomy'   => 'category',
		'hide_empty' => false,
	)
);
if ( is_wp_error( $mvweb_sml_bulk_categories ) ) {
	$mvweb_sml_bulk_categories = array();
}

global $wpdb;
$mvweb_sml_bulk_clusters_table = mvweb_sml_table( 'clusters' );
// phpcs:disable WordPress.DB.DirectDatabaseQuery
$mvweb_sml_bulk_clusters = $wpdb->get_results(
	$wpdb->prepare( 'SELECT id, name FROM %i ORDER BY name ASC', $mvweb_sml_bulk_clusters_table ),
	ARRAY_A
);
// phpcs:enable
if ( ! is_array( $mvweb_sml_bulk_clusters ) ) {
	$mvweb_sml_bulk_clusters = array();
}

// The "Generate suggestions" sweep is a semi-automatic / automatic affordance.
// In manual mode the editor adds links by hand in the post metabox, so the
// button is hidden (TZ §5) and replaced with a pointer to that workflow.
$mvweb_sml_mode = (string) mvweb_sml_get_setting( 'mode', 'semi' );
?>
<div class="mvweb-block mvweb-sml-bulk">
	<div class="mvweb-block__head mvweb-sml-bulk__header">
		<div class="mvweb-block__title"><?php esc_html_e( 'Suggested links', 'mvweb-smart-links' ); ?></div>
		<?php if ( 'manual' !== $mvweb_sml_mode ) : ?>
			<button type="button" class="mvweb-btn mvweb-btn--primary mvweb-sml-bulk__generate">
				<?php esc_html_e( 'Generate suggestions', 'mvweb-smart-links' ); ?>
			</button>
		<?php endif; ?>
	</div>

	<?php if ( 'manual' !== $mvweb_sml_mode ) : ?>
		<div class="mvweb-sml-bulk__progress" hidden>
			<div class="mvweb-progress">
				<div class="mvweb-progress__bar mvweb-sml-bulk__bar" style="width:0%"></div>
			</div>
			<p class="mvweb-sml-bulk__progress-status"></p>
		</div>
	<?php else : ?>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Manual mode: add internal links by hand in the post editor (the Smart Links box). Switch to Semi-automatic on the Settings tab to generate suggestions here.', 'mvweb-smart-links' ); ?></p>
	<?php endif; ?>

	<div class="mvweb-sml-bulk__filters">
		<label class="mvweb-sml-bulk__filter">
			<span class="screen-reader-text"><?php esc_html_e( 'Post type', 'mvweb-smart-links' ); ?></span>
			<select class="mvweb-select mvweb-sml-bulk__filter-cpt">
				<option value=""><?php esc_html_e( 'All post types', 'mvweb-smart-links' ); ?></option>
				<?php foreach ( $mvweb_sml_bulk_cpts as $pt_slug => $pt_label ) : ?>
					<option value="<?php echo esc_attr( $pt_slug ); ?>"><?php echo esc_html( $pt_label ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>

		<label class="mvweb-sml-bulk__filter">
			<span class="screen-reader-text"><?php esc_html_e( 'Category', 'mvweb-smart-links' ); ?></span>
			<select class="mvweb-select mvweb-sml-bulk__filter-category">
				<option value="0"><?php esc_html_e( 'All categories', 'mvweb-smart-links' ); ?></option>
				<?php foreach ( $mvweb_sml_bulk_categories as $mvweb_sml_bulk_cat ) : ?>
					<option value="<?php echo esc_attr( (int) $mvweb_sml_bulk_cat->term_taxonomy_id ); ?>">
						<?php echo esc_html( $mvweb_sml_bulk_cat->name ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</label>

		<label class="mvweb-sml-bulk__filter">
			<span class="screen-reader-text"><?php esc_html_e( 'Cluster', 'mvweb-smart-links' ); ?></span>
			<select class="mvweb-select mvweb-sml-bulk__filter-cluster">
				<option value="0"><?php esc_html_e( 'All clusters', 'mvweb-smart-links' ); ?></option>
				<?php foreach ( $mvweb_sml_bulk_clusters as $mvweb_sml_bulk_cl ) : ?>
					<option value="<?php echo esc_attr( (int) $mvweb_sml_bulk_cl['id'] ); ?>">
						<?php echo esc_html( (string) $mvweb_sml_bulk_cl['name'] ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</label>

		<label class="mvweb-sml-bulk__filter">
			<span class="screen-reader-text"><?php esc_html_e( 'Status', 'mvweb-smart-links' ); ?></span>
			<select class="mvweb-select mvweb-sml-bulk__filter-status">
				<option value=""><?php esc_html_e( 'All statuses', 'mvweb-smart-links' ); ?></option>
				<option value="pending"><?php esc_html_e( 'Pending', 'mvweb-smart-links' ); ?></option>
				<option value="approved"><?php esc_html_e( 'Approved', 'mvweb-smart-links' ); ?></option>
				<option value="rejected"><?php esc_html_e( 'Rejected', 'mvweb-smart-links' ); ?></option>
				<option value="auto"><?php esc_html_e( 'Auto-approved', 'mvweb-smart-links' ); ?></option>
			</select>
		</label>

		<label class="mvweb-sml-bulk__filter mvweb-sml-bulk__filter--search">
			<span class="screen-reader-text"><?php esc_html_e( 'Search keyword', 'mvweb-smart-links' ); ?></span>
			<input type="search" class="mvweb-input mvweb-sml-bulk__filter-search" placeholder="<?php esc_attr_e( 'Search keyword…', 'mvweb-smart-links' ); ?>" />
		</label>

		<label class="mvweb-check mvweb-sml-bulk__filter mvweb-sml-bulk__filter--checkbox">
			<input type="checkbox" class="mvweb-sml-bulk__filter-orphan" />
			<span><?php esc_html_e( 'Orphans only', 'mvweb-smart-links' ); ?></span>
		</label>

		<label class="mvweb-check mvweb-sml-bulk__filter mvweb-sml-bulk__filter--checkbox">
			<input type="checkbox" class="mvweb-sml-bulk__filter-has-keywords" />
			<span><?php esc_html_e( 'Has keywords', 'mvweb-smart-links' ); ?></span>
		</label>
	</div>

	<div class="mvweb-sml-bulk__toolbar">
		<label class="mvweb-sml-bulk__action-label">
			<span class="screen-reader-text"><?php esc_html_e( 'Bulk action', 'mvweb-smart-links' ); ?></span>
			<select class="mvweb-select mvweb-sml-bulk__action">
				<option value=""><?php esc_html_e( 'Bulk action', 'mvweb-smart-links' ); ?></option>
				<option value="approve"><?php esc_html_e( 'Approve', 'mvweb-smart-links' ); ?></option>
				<option value="reject"><?php esc_html_e( 'Reject', 'mvweb-smart-links' ); ?></option>
				<option value="pending"><?php esc_html_e( 'Reset to pending', 'mvweb-smart-links' ); ?></option>
				<option value="delete"><?php esc_html_e( 'Delete', 'mvweb-smart-links' ); ?></option>
			</select>
		</label>
		<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-sml-bulk__apply">
			<?php esc_html_e( 'Apply', 'mvweb-smart-links' ); ?>
		</button>
		<span class="mvweb-sml-bulk__status-msg"></span>
	</div>

	<div class="mvweb-sml-bulk__selectall-note" hidden>
		<span class="mvweb-sml-bulk__selectall-text"></span>
		<button type="button" class="mvweb-sml-bulk__selectall-toggle"></button>
	</div>

	<div class="mvweb-table-wrap mvweb-sml-bulk__table-wrap">
		<table class="mvweb-table mvweb-sml-bulk__table">
			<thead>
				<tr>
					<th scope="col" class="mvweb-sml-bulk__col-check">
						<label class="mvweb-sml-bulk__select-all-label">
							<input type="checkbox" class="mvweb-sml-bulk__select-all" />
							<span><?php esc_html_e( 'All', 'mvweb-smart-links' ); ?></span>
						</label>
					</th>
					<th scope="col" class="mvweb-sml-bulk__col-source"><?php esc_html_e( 'Source', 'mvweb-smart-links' ); ?></th>
					<th scope="col" class="mvweb-sml-bulk__col-arrow">→</th>
					<th scope="col" class="mvweb-sml-bulk__col-target"><?php esc_html_e( 'Target', 'mvweb-smart-links' ); ?></th>
					<th scope="col" class="mvweb-sml-bulk__col-anchor"><?php esc_html_e( 'Anchor', 'mvweb-smart-links' ); ?></th>
					<th scope="col" class="mvweb-sml-bulk__col-score mvweb-sml-bulk__sortable" data-orderby="score">
						<button type="button" class="mvweb-sml-bulk__sort"><?php esc_html_e( 'Score', 'mvweb-smart-links' ); ?><span class="mvweb-sml-bulk__sort-ind" aria-hidden="true"></span></button>
					</th>
					<th scope="col" class="mvweb-sml-bulk__col-status mvweb-sml-bulk__sortable" data-orderby="status">
						<button type="button" class="mvweb-sml-bulk__sort"><?php esc_html_e( 'Status', 'mvweb-smart-links' ); ?><span class="mvweb-sml-bulk__sort-ind" aria-hidden="true"></span></button>
					</th>
					<th scope="col" class="mvweb-sml-bulk__col-actions"><?php esc_html_e( 'Actions', 'mvweb-smart-links' ); ?></th>
				</tr>
			</thead>
			<tbody class="mvweb-sml-bulk__tbody">
				<tr class="mvweb-sml-bulk__empty">
					<td colspan="8"><?php esc_html_e( 'Loading…', 'mvweb-smart-links' ); ?></td>
				</tr>
			</tbody>
		</table>
	</div>

	<div class="mvweb-sml-bulk__pagination">
		<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-sml-bulk__prev" disabled>&laquo; <?php esc_html_e( 'Prev', 'mvweb-smart-links' ); ?></button>
		<span class="mvweb-sml-bulk__page-info"></span>
		<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-sml-bulk__next" disabled><?php esc_html_e( 'Next', 'mvweb-smart-links' ); ?> &raquo;</button>
		<label class="mvweb-sml-bulk__perpage-label">
			<span class="screen-reader-text"><?php esc_html_e( 'Rows per page', 'mvweb-smart-links' ); ?></span>
			<select class="mvweb-select mvweb-sml-bulk__perpage">
				<option value="25">25</option>
				<option value="50">50</option>
				<option value="100">100</option>
			</select>
		</label>
	</div>
</div>
