<?php
/**
 * Settings tab — full form for `mvweb_sml_settings` option.
 *
 * Expects `$mvweb_sml_settings` (full settings array) to be in scope; provided
 * by `settings-page.php`.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! isset( $mvweb_sml_settings ) || ! is_array( $mvweb_sml_settings ) ) {
	$mvweb_sml_settings = MVweb_SML_Settings::get();
}

$opt        = MVweb_SML_Settings::OPTION_NAME;
$post_types = get_post_types( array( 'public' => true ), 'objects' );
unset( $post_types['attachment'] );

$selected_post_types = (array) $mvweb_sml_settings['post_types'];
$disabled_post_ids   = implode( ', ', (array) $mvweb_sml_settings['disabled_post_ids'] );
$disabled_patterns   = implode( "\n", (array) $mvweb_sml_settings['disabled_url_patterns'] );
$disabled_terms      = array_map( 'intval', (array) $mvweb_sml_settings['disabled_terms'] );

// Taxonomies attached to the supported post types, so the term blacklist only
// offers terms that can actually appear on a linkable post.
$term_taxonomies = array();
foreach ( $selected_post_types as $pt_name ) {
	foreach ( get_object_taxonomies( $pt_name, 'objects' ) as $tax_obj ) {
		if ( ! empty( $tax_obj->public ) && ! isset( $term_taxonomies[ $tax_obj->name ] ) ) {
			$term_taxonomies[ $tax_obj->name ] = $tax_obj;
		}
	}
}
?>

<form method="post" action="options.php">
	<?php settings_fields( MVweb_SML_Settings::OPTION_GROUP ); ?>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Interlinking mode', 'mvweb-smart-links' ); ?></div>
			<div class="mvweb-block__sub"><?php esc_html_e( 'Choose how much of the linking the plugin does on its own.', 'mvweb-smart-links' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-sml-mode"><?php esc_html_e( 'Mode', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb-sml-mode" class="mvweb-select" name="<?php echo esc_attr( $opt ); ?>[mode]">
					<option value="manual" <?php selected( $mvweb_sml_settings['mode'], 'manual' ); ?>><?php esc_html_e( 'Manual — you curate links by hand', 'mvweb-smart-links' ); ?></option>
					<option value="semi" <?php selected( $mvweb_sml_settings['mode'], 'semi' ); ?>><?php esc_html_e( 'Semi-automatic — plugin suggests, you approve', 'mvweb-smart-links' ); ?></option>
					<option value="auto" <?php selected( $mvweb_sml_settings['mode'], 'auto' ); ?>><?php esc_html_e( 'Automatic — plugin approves high-confidence links', 'mvweb-smart-links' ); ?></option>
				</select>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Automatic mode promotes suggestions that pass the relevance and inbound-cap safeguards below, without manual review.', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-sml-auto-min-score"><?php esc_html_e( 'Auto: minimum relevance', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" min="0" id="mvweb-sml-auto-min-score" class="mvweb-input" name="<?php echo esc_attr( $opt ); ?>[auto_min_score]" value="<?php echo esc_attr( (int) $mvweb_sml_settings['auto_min_score'] ); ?>" />
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Minimum relevance score a suggestion needs before automatic mode approves it without review. Check the Score column on the Keywords tab to see the values your content produces.', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-sml-auto-max-inbound"><?php esc_html_e( 'Auto: max inbound per target', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" min="0" id="mvweb-sml-auto-max-inbound" class="mvweb-input" name="<?php echo esc_attr( $opt ); ?>[auto_max_inbound]" value="<?php echo esc_attr( (int) $mvweb_sml_settings['auto_max_inbound'] ); ?>" />
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Stop auto-approving links to a page once it already has this many incoming internal links (anchor-spam guard).', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Auto-mode preview', 'mvweb-smart-links' ); ?></span>
			<div class="mvweb-form-row__field">
				<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-sml-auto-preview"><?php esc_html_e( 'Preview auto-approvals', 'mvweb-smart-links' ); ?></button>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Dry run — nothing is changed. Shows how many pending suggestions clear the confidence threshold above and would be approved without review if automatic mode were on.', 'mvweb-smart-links' ); ?></p>
				<div class="mvweb-sml-auto-preview__result" hidden></div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label" for="mvweb-sml-pillar-bonus"><?php esc_html_e( 'Pillar bonus', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number" min="0" id="mvweb-sml-pillar-bonus" class="mvweb-input" name="<?php echo esc_attr( $opt ); ?>[pillar_score_bonus]" value="<?php echo esc_attr( (int) $mvweb_sml_settings['pillar_score_bonus'] ); ?>" />
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Extra relevance score added to suggestions that point at a cluster pillar (its main hub page), so pillar pages rank higher and gather more internal links. 0 = off.', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label"><?php esc_html_e( 'Ranking refinement', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[score_idf]" value="1" <?php checked( ! empty( $mvweb_sml_settings['score_idf'] ) ); ?> />
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Rarity: among suggestions with the same overlap, favour the ones sharing distinctive topic words over those sharing common ones.', 'mvweb-smart-links' ); ?></span>
				</div>
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[score_position]" value="1" <?php checked( ! empty( $mvweb_sml_settings['score_position'] ) ); ?> />
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Position: give a small bonus to links that land earlier in the content.', 'mvweb-smart-links' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Both are tie-breakers applied when suggestions are generated — they refine the order without changing the automatic-mode threshold or the pillar bonus.', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Main toggles', 'mvweb-smart-links' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label"><?php esc_html_e( 'Plugin enabled', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[enabled]" value="1" <?php checked( $mvweb_sml_settings['enabled'] ); ?> />
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Master switch. Turn this off to instantly stop all automatic and contextual linking across the site.', 'mvweb-smart-links' ); ?></span>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label"><?php esc_html_e( 'Contextual links', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[contextual_enabled]" value="1" <?php checked( $mvweb_sml_settings['contextual_enabled'] ); ?> />
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Automatically turn matching keywords in your post text into links — the plugin\'s main linking mechanism.', 'mvweb-smart-links' ); ?></span>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label"><?php esc_html_e( 'Related posts block', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[related_enabled]" value="1" <?php checked( $mvweb_sml_settings['related_enabled'] ); ?> />
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Append a "Read also" block after content.', 'mvweb-smart-links' ); ?></span>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label"><?php esc_html_e( 'Click tracking', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[track_clicks]" value="1" <?php checked( ! empty( $mvweb_sml_settings['track_clicks'] ) ); ?> />
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Count clicks on contextual links (aggregate only, no personal data). Results appear in Reports → Link clicks.', 'mvweb-smart-links' ); ?></span>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<span class="mvweb-form-row__label"><?php esc_html_e( 'Supported post types', 'mvweb-smart-links' ); ?></span>
			<div class="mvweb-form-row__field">
				<?php foreach ( $post_types as $pt_obj ) : ?>
					<label class="mvweb-check">
						<input type="checkbox"
							name="<?php echo esc_attr( $opt ); ?>[post_types][]"
							value="<?php echo esc_attr( $pt_obj->name ); ?>"
							<?php checked( in_array( $pt_obj->name, $selected_post_types, true ) ); ?> />
						<?php echo esc_html( $pt_obj->labels->singular_name . ' (' . $pt_obj->name . ')' ); ?>
					</label>
				<?php endforeach; ?>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Only these content types can give or receive automatic and contextual links. Unchecked types are ignored.', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Contextual links', 'mvweb-smart-links' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-sml-links-max" class="mvweb-form-row__label"><?php esc_html_e( 'Max links per page', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text"
					id="mvweb-sml-links-max"
					class="mvweb-input"
					name="<?php echo esc_attr( $opt ); ?>[links_max_per_page]"
					value="<?php echo esc_attr( $mvweb_sml_settings['links_max_per_page'] ); ?>" />
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Use "auto" to calculate from word count, or set a fixed number.', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-sml-links-max-para" class="mvweb-form-row__label"><?php esc_html_e( 'Max links per paragraph', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number"
					id="mvweb-sml-links-max-para"
					class="mvweb-input"
					min="0"
					name="<?php echo esc_attr( $opt ); ?>[links_max_per_paragraph]"
					value="<?php echo esc_attr( (int) $mvweb_sml_settings['links_max_per_paragraph'] ); ?>" />
				<p class="mvweb-form-row__desc"><?php esc_html_e( '0 = no limit. Caps how many links land in one paragraph — protects against over-linking a single block.', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-sml-links-gap" class="mvweb-form-row__label"><?php esc_html_e( 'Min words between links', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number"
					id="mvweb-sml-links-gap"
					class="mvweb-input"
					min="0"
					name="<?php echo esc_attr( $opt ); ?>[links_gap_words]"
					value="<?php echo esc_attr( (int) $mvweb_sml_settings['links_gap_words'] ); ?>" />
					<p class="mvweb-form-row__desc"><?php esc_html_e( 'The plugin skips at least this many words after one inserted link before adding another — keeps links from clustering together.', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-sml-link-target" class="mvweb-form-row__label"><?php esc_html_e( 'Link target', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb-sml-link-target" class="mvweb-select" name="<?php echo esc_attr( $opt ); ?>[link_target]">
					<option value="_self" <?php selected( $mvweb_sml_settings['link_target'], '_self' ); ?>><?php esc_html_e( 'Same window', 'mvweb-smart-links' ); ?></option>
					<option value="_blank" <?php selected( $mvweb_sml_settings['link_target'], '_blank' ); ?>><?php esc_html_e( 'New tab', 'mvweb-smart-links' ); ?></option>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-sml-link-class" class="mvweb-form-row__label"><?php esc_html_e( 'CSS class', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text"
					id="mvweb-sml-link-class"
					class="mvweb-input"
					name="<?php echo esc_attr( $opt ); ?>[link_css_class]"
					value="<?php echo esc_attr( $mvweb_sml_settings['link_css_class'] ); ?>" />
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Single CSS class added to every inserted link.', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label"><?php esc_html_e( 'Nofollow', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[link_nofollow]" value="1" <?php checked( ! empty( $mvweb_sml_settings['link_nofollow'] ) ); ?> />
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Add rel="nofollow" to inserted links — this tells search engines not to pass ranking weight through them. Leave off unless you specifically want that.', 'mvweb-smart-links' ); ?></span>
				</div>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label"><?php esc_html_e( 'Anchor rotation', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<div class="mvweb-toggle-row">
					<label class="mvweb-toggle">
						<input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[anchor_rotation]" value="1" <?php checked( ! empty( $mvweb_sml_settings['anchor_rotation'] ) ); ?> />
						<span class="mvweb-toggle__slider"></span>
					</label>
					<span><?php esc_html_e( 'Diversify anchors: when an exact phrase already points to a target too often, link a registered synonym instead (if it appears in the text).', 'mvweb-smart-links' ); ?></span>
				</div>
				<p class="mvweb-form-row__desc">
					<label for="mvweb-sml-anchor-max-repeat"><?php esc_html_e( 'Rotate after the same anchor points to a target this many times:', 'mvweb-smart-links' ); ?></label>
					<input type="number" min="1" id="mvweb-sml-anchor-max-repeat" class="mvweb-input" name="<?php echo esc_attr( $opt ); ?>[anchor_max_repeat]" value="<?php echo esc_attr( (int) $mvweb_sml_settings['anchor_max_repeat'] ); ?>" />
				</p>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Global blacklist', 'mvweb-smart-links' ); ?></div>
		</div>
		<p class="mvweb-block__sub"><?php esc_html_e( 'Posts and URLs from these lists never receive automatic links.', 'mvweb-smart-links' ); ?></p>

		<div class="mvweb-form-row">
			<label for="mvweb-sml-disabled-ids" class="mvweb-form-row__label"><?php esc_html_e( 'Disabled post IDs', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-sml-disabled-ids"
					class="mvweb-textarea"
					rows="3"
					name="<?php echo esc_attr( $opt ); ?>[disabled_post_ids]"><?php echo esc_textarea( $disabled_post_ids ); ?></textarea>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Comma-separated post IDs — the number shown in the address bar while editing a post (post.php?post=123).', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-sml-disabled-urls" class="mvweb-form-row__label"><?php esc_html_e( 'Disabled URL patterns', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<textarea id="mvweb-sml-disabled-urls"
					class="mvweb-textarea"
					rows="5"
					name="<?php echo esc_attr( $opt ); ?>[disabled_url_patterns]"><?php echo esc_textarea( $disabled_patterns ); ?></textarea>
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'One pattern per line. Wildcards (*) are allowed.', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>

		<?php if ( ! empty( $term_taxonomies ) ) : ?>
			<div class="mvweb-form-row">
				<label for="mvweb-sml-disabled-terms" class="mvweb-form-row__label"><?php esc_html_e( 'Excluded categories / terms', 'mvweb-smart-links' ); ?></label>
				<div class="mvweb-form-row__field">
					<select id="mvweb-sml-disabled-terms"
						class="mvweb-select"
						multiple
						size="8"
						name="<?php echo esc_attr( $opt ); ?>[disabled_terms][]">
						<?php
						foreach ( $term_taxonomies as $tax_obj ) :
							$terms = get_terms(
								array(
									'taxonomy'   => $tax_obj->name,
									'hide_empty' => false,
								)
							);
							if ( is_wp_error( $terms ) || empty( $terms ) ) {
								continue;
							}
							?>
							<optgroup label="<?php echo esc_attr( $tax_obj->labels->singular_name ); ?>">
								<?php foreach ( $terms as $mvweb_sml_term ) : ?>
									<option value="<?php echo esc_attr( (int) $mvweb_sml_term->term_id ); ?>" <?php selected( in_array( (int) $mvweb_sml_term->term_id, $disabled_terms, true ) ); ?>>
										<?php echo esc_html( $mvweb_sml_term->name ); ?>
									</option>
								<?php endforeach; ?>
							</optgroup>
						<?php endforeach; ?>
					</select>
					<p class="mvweb-form-row__desc"><?php esc_html_e( 'Posts filed under any selected term never receive automatic links. Hold Ctrl/Cmd to select several.', 'mvweb-smart-links' ); ?></p>
				</div>
			</div>
		<?php endif; ?>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Related posts', 'mvweb-smart-links' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-sml-related-position" class="mvweb-form-row__label"><?php esc_html_e( 'Position', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb-sml-related-position" class="mvweb-select" name="<?php echo esc_attr( $opt ); ?>[related_position]">
					<option value="after_content" <?php selected( $mvweb_sml_settings['related_position'], 'after_content' ); ?>><?php esc_html_e( 'After content', 'mvweb-smart-links' ); ?></option>
					<option value="after_paragraph" <?php selected( $mvweb_sml_settings['related_position'], 'after_paragraph' ); ?>><?php esc_html_e( 'After Nth paragraph', 'mvweb-smart-links' ); ?></option>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-sml-related-after-paragraph" class="mvweb-form-row__label"><?php esc_html_e( 'Paragraph number', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number"
					id="mvweb-sml-related-after-paragraph"
					class="mvweb-input"
					min="1"
					name="<?php echo esc_attr( $opt ); ?>[related_after_paragraph]"
					value="<?php echo esc_attr( (int) $mvweb_sml_settings['related_after_paragraph'] ); ?>" />
				<p class="mvweb-form-row__desc"><?php esc_html_e( 'Used only when position is "After Nth paragraph".', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-sml-related-template" class="mvweb-form-row__label"><?php esc_html_e( 'Template', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb-sml-related-template" class="mvweb-select" name="<?php echo esc_attr( $opt ); ?>[related_template]">
					<option value="list" <?php selected( $mvweb_sml_settings['related_template'], 'list' ); ?>><?php esc_html_e( 'List', 'mvweb-smart-links' ); ?></option>
					<option value="cards" <?php selected( $mvweb_sml_settings['related_template'], 'cards' ); ?>><?php esc_html_e( 'Cards', 'mvweb-smart-links' ); ?></option>
					<option value="inline" <?php selected( $mvweb_sml_settings['related_template'], 'inline' ); ?>><?php esc_html_e( 'Inline', 'mvweb-smart-links' ); ?></option>
				</select>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-sml-related-title" class="mvweb-form-row__label"><?php esc_html_e( 'Block title', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="text"
					id="mvweb-sml-related-title"
					class="mvweb-input"
					name="<?php echo esc_attr( $opt ); ?>[related_title]"
					value="<?php echo esc_attr( $mvweb_sml_settings['related_title'] ); ?>" />
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-sml-related-count" class="mvweb-form-row__label"><?php esc_html_e( 'Number of items', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<input type="number"
					id="mvweb-sml-related-count"
					class="mvweb-input"
					min="1"
					name="<?php echo esc_attr( $opt ); ?>[related_count]"
					value="<?php echo esc_attr( (int) $mvweb_sml_settings['related_count'] ); ?>" />
			</div>
		</div>

		<div class="mvweb-form-row">
			<label for="mvweb-sml-related-target" class="mvweb-form-row__label"><?php esc_html_e( 'Link target', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<select id="mvweb-sml-related-target" class="mvweb-select" name="<?php echo esc_attr( $opt ); ?>[related_target]">
					<option value="_self" <?php selected( $mvweb_sml_settings['related_target'], '_self' ); ?>><?php esc_html_e( 'Same window', 'mvweb-smart-links' ); ?></option>
					<option value="_blank" <?php selected( $mvweb_sml_settings['related_target'], '_blank' ); ?>><?php esc_html_e( 'New tab', 'mvweb-smart-links' ); ?></option>
				</select>
			</div>
		</div>
	</div>

	<div class="mvweb-block">
		<div class="mvweb-block__head">
			<div class="mvweb-block__title"><?php esc_html_e( 'Maintenance', 'mvweb-smart-links' ); ?></div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label"><?php esc_html_e( 'Content index', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<p class="mvweb-form-row__desc">
					<?php esc_html_e( 'Rebuild the content index used by the linker and the related-posts block. Runs in the background in small steps — safe to leave this tab open until it finishes.', 'mvweb-smart-links' ); ?>
				</p>
				<div>
					<button type="button"
						class="mvweb-btn mvweb-btn--primary mvweb-sml-reindex__btn"
						id="mvweb-sml-reindex">
						<?php esc_html_e( 'Run reindex', 'mvweb-smart-links' ); ?>
					</button>
				</div>
				<div class="mvweb-progress mvweb-sml-reindex__progress" style="display:none;">
					<div class="mvweb-progress__bar mvweb-sml-reindex__bar" style="width:0%"></div>
				</div>
				<p class="mvweb-sml-reindex__status" aria-live="polite"></p>
			</div>
		</div>

		<div class="mvweb-form-row">
			<label class="mvweb-form-row__label"><?php esc_html_e( 'Delete data on uninstall', 'mvweb-smart-links' ); ?></label>
			<div class="mvweb-form-row__field">
				<label class="mvweb-check">
					<input type="checkbox" name="<?php echo esc_attr( $opt ); ?>[delete_data_on_uninstall]" value="1" <?php checked( $mvweb_sml_settings['delete_data_on_uninstall'] ); ?> />
					<?php esc_html_e( 'Drop all plugin tables and options when the plugin is removed.', 'mvweb-smart-links' ); ?>
				</label>
			</div>
		</div>
	</div>

	<div class="mvweb-submit">
		<button type="submit" name="submit" class="mvweb-btn mvweb-btn--primary">
			<?php esc_html_e( 'Save Changes', 'mvweb-smart-links' ); ?>
		</button>
	</div>
</form>
