<?php
/**
 * Reports tab — five reports + CSV export buttons (TZ §8).
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! class_exists( 'MVweb_SML_Reports' ) ) {
	echo '<div class="mvweb-block"><p>' . esc_html__( 'Reports module is not loaded.', 'mvweb-smart-links' ) . '</p></div>';
	return;
}

// Detect "Run broken scan" GET trigger so the heavy scanner only runs on
// demand. Plain GET + nonce is fine because the action is read-only and
// the result is cached for an hour.
// phpcs:ignore WordPress.Security.NonceVerification.Recommended
$mvweb_sml_force_broken = isset( $_GET['mvweb_sml_run_broken'] ) && check_admin_referer( 'mvweb_sml_run_broken', 'mvweb_sml_broken_nonce' );

$mvweb_sml_orphans      = MVweb_SML_Reports::orphans( 200 );
$mvweb_sml_orphan_count = count( $mvweb_sml_orphans );

$mvweb_sml_stats        = MVweb_SML_Reports::link_stats();
$mvweb_sml_conflicts    = MVweb_SML_Reports::keyword_cannibalization();
$mvweb_sml_conflict_cnt = count( $mvweb_sml_conflicts );

$mvweb_sml_broken_links = $mvweb_sml_force_broken
	? MVweb_SML_Reports::broken_links( true )
	: MVweb_SML_Reports::broken_links( false );

$mvweb_sml_crawl = MVweb_SML_Reports::crawl_depth();

$mvweb_sml_anchors = MVweb_SML_Reports::anchor_profile();

$mvweb_sml_track_clicks = (bool) mvweb_sml_get_setting( 'track_clicks' );
$mvweb_sml_clicks       = ( $mvweb_sml_track_clicks && class_exists( 'MVweb_SML_Clicks' ) )
	? MVweb_SML_Clicks::top_clicked( 50 )
	: array();

// Sync notices to current state of the reports.
MVweb_SML_Reports::refresh_notices( $mvweb_sml_orphan_count, $mvweb_sml_conflict_cnt );

$mvweb_sml_admin_post = admin_url( 'admin-post.php' );
$mvweb_sml_run_broken = wp_nonce_url(
	add_query_arg(
		array(
			'page'                 => MVweb_SML_Admin::PAGE_SLUG,
			'tab'                  => 'reports',
			'mvweb_sml_run_broken' => '1',
		),
		admin_url( 'admin.php' )
	),
	'mvweb_sml_run_broken',
	'mvweb_sml_broken_nonce'
);
?>

<div class="mvweb-block mvweb-sml-reports">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Orphan pages', 'mvweb-smart-links' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Published posts no other post links to. Add internal links from related content to fix this.', 'mvweb-smart-links' ); ?>
	</p>

	<div class="mvweb-sml-reports__actions">
		<a class="mvweb-btn mvweb-btn--secondary"
			href="<?php echo esc_url( wp_nonce_url( $mvweb_sml_admin_post . '?action=mvweb_sml_export_orphans', 'mvweb_sml_export_orphans', '_wpnonce_export_orphans' ) ); ?>">
			<?php esc_html_e( 'Export CSV', 'mvweb-smart-links' ); ?>
		</a>
	</div>

	<?php if ( empty( $mvweb_sml_orphans ) ) : ?>
		<p><?php esc_html_e( 'No orphans found.', 'mvweb-smart-links' ); ?></p>
	<?php else : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Title', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Type', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Date', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Actions', 'mvweb-smart-links' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $mvweb_sml_orphans as $mvweb_sml_orphan ) : ?>
						<tr>
							<td><?php echo esc_html( get_the_title( $mvweb_sml_orphan ) ); ?></td>
							<td><?php echo esc_html( $mvweb_sml_orphan->post_type ); ?></td>
							<td><?php echo esc_html( get_the_date( '', $mvweb_sml_orphan ) ); ?></td>
							<td class="cell-actions">
								<a href="<?php echo esc_url( get_edit_post_link( $mvweb_sml_orphan->ID, 'raw' ) . '#mvweb_sml_metabox' ); ?>"
									class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm"
									title="<?php esc_attr_e( 'Register a keyword on this page so other posts link to it.', 'mvweb-smart-links' ); ?>">
									<?php esc_html_e( 'Add inbound link', 'mvweb-smart-links' ); ?>
								</a>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</div>

<div class="mvweb-block mvweb-sml-reports">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Link stats', 'mvweb-smart-links' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php
		printf(
			/* translators: 1: average incoming links, 2: average outgoing, 3: posts counted. */
			esc_html__( 'Avg incoming: %1$s · Avg outgoing: %2$s · Posts with links: %3$s', 'mvweb-smart-links' ),
			esc_html( number_format_i18n( (float) $mvweb_sml_stats['avg_incoming'], 2 ) ),
			esc_html( number_format_i18n( (float) $mvweb_sml_stats['avg_outgoing'], 2 ) ),
			esc_html( number_format_i18n( (int) $mvweb_sml_stats['total_posts'] ) )
		);
		?>
	</p>

	<div class="mvweb-sml-reports__actions">
		<a class="mvweb-btn mvweb-btn--secondary"
			href="<?php echo esc_url( wp_nonce_url( $mvweb_sml_admin_post . '?action=mvweb_sml_export_stats', 'mvweb_sml_export_stats', '_wpnonce_export_stats' ) ); ?>">
			<?php esc_html_e( 'Export CSV', 'mvweb-smart-links' ); ?>
		</a>
	</div>

	<?php if ( empty( $mvweb_sml_stats['rows'] ) ) : ?>
		<p><?php esc_html_e( 'No link data yet — run reindex and Generate suggestions first.', 'mvweb-smart-links' ); ?></p>
	<?php else : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Post', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Incoming', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Outgoing', 'mvweb-smart-links' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php
					$mvweb_sml_stats_top = array_slice( $mvweb_sml_stats['rows'], 0, 50 );
					foreach ( $mvweb_sml_stats_top as $mvweb_sml_row ) :
						$mvweb_sml_title = get_the_title( $mvweb_sml_row['post_id'] );
						if ( '' === $mvweb_sml_title ) {
							$mvweb_sml_title = '#' . $mvweb_sml_row['post_id'];
						}
						?>
						<tr>
							<td>
								<a href="<?php echo esc_url( get_edit_post_link( $mvweb_sml_row['post_id'] ) ); ?>">
									<?php echo esc_html( $mvweb_sml_title ); ?>
								</a>
							</td>
							<td><?php echo esc_html( number_format_i18n( $mvweb_sml_row['incoming'] ) ); ?></td>
							<td><?php echo esc_html( number_format_i18n( $mvweb_sml_row['outgoing'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</div>

<div class="mvweb-block mvweb-sml-reports">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Link clicks', 'mvweb-smart-links' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Which contextual internal links visitors actually click. Only aggregate counts are stored — no personal data.', 'mvweb-smart-links' ); ?>
	</p>

	<?php if ( ! $mvweb_sml_track_clicks ) : ?>
		<p><?php esc_html_e( 'Click tracking is turned off. Enable it on the Settings tab to start collecting clicks.', 'mvweb-smart-links' ); ?></p>
	<?php elseif ( empty( $mvweb_sml_clicks ) ) : ?>
		<p><?php esc_html_e( 'No clicks recorded yet.', 'mvweb-smart-links' ); ?></p>
	<?php else : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'From', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'To', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Clicks', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Last click', 'mvweb-smart-links' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $mvweb_sml_clicks as $mvweb_sml_click ) : ?>
						<?php
						$mvweb_sml_click_from = get_the_title( $mvweb_sml_click['source_id'] );
						$mvweb_sml_click_to   = get_the_title( $mvweb_sml_click['target_id'] );
						if ( '' === $mvweb_sml_click_from ) {
							$mvweb_sml_click_from = '#' . $mvweb_sml_click['source_id'];
						}
						if ( '' === $mvweb_sml_click_to ) {
							$mvweb_sml_click_to = '#' . $mvweb_sml_click['target_id'];
						}
						?>
						<tr>
							<td>
								<a href="<?php echo esc_url( (string) get_edit_post_link( $mvweb_sml_click['source_id'] ) ); ?>">
									<?php echo esc_html( $mvweb_sml_click_from ); ?>
								</a>
							</td>
							<td>
								<a href="<?php echo esc_url( (string) get_edit_post_link( $mvweb_sml_click['target_id'] ) ); ?>">
									<?php echo esc_html( $mvweb_sml_click_to ); ?>
								</a>
							</td>
							<td><?php echo esc_html( number_format_i18n( $mvweb_sml_click['clicks'] ) ); ?></td>
							<td><?php echo esc_html( $mvweb_sml_click['last_click'] ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</div>

<div class="mvweb-block mvweb-sml-reports">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Broken links', 'mvweb-smart-links' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Internal links pointing at posts that were deleted or trashed. The scan is heavy and cached for one hour — re-run it after bulk edits.', 'mvweb-smart-links' ); ?>
	</p>

	<div class="mvweb-sml-reports__actions">
		<a class="mvweb-btn" href="<?php echo esc_url( $mvweb_sml_run_broken ); ?>">
			<?php esc_html_e( 'Run scanner', 'mvweb-smart-links' ); ?>
		</a>
		<a class="mvweb-btn mvweb-btn--secondary"
			href="<?php echo esc_url( wp_nonce_url( $mvweb_sml_admin_post . '?action=mvweb_sml_export_broken', 'mvweb_sml_export_broken', '_wpnonce_export_broken' ) ); ?>">
			<?php esc_html_e( 'Export CSV', 'mvweb-smart-links' ); ?>
		</a>
	</div>

	<?php if ( empty( $mvweb_sml_broken_links ) ) : ?>
		<p><?php esc_html_e( 'No broken links detected.', 'mvweb-smart-links' ); ?></p>
	<?php else : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Source', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Target ID', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Created by', 'mvweb-smart-links' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $mvweb_sml_broken_links as $mvweb_sml_b ) : ?>
						<tr>
							<td>
								<a href="<?php echo esc_url( get_edit_post_link( $mvweb_sml_b['source_id'] ) ); ?>">
									<?php echo esc_html( get_the_title( $mvweb_sml_b['source_id'] ) ); ?> (#<?php echo (int) $mvweb_sml_b['source_id']; ?>)
								</a>
							</td>
							<td>#<?php echo (int) $mvweb_sml_b['target_id']; ?></td>
							<td><?php echo esc_html( 'auto' === $mvweb_sml_b['origin'] ? __( 'Automatic', 'mvweb-smart-links' ) : ( 'manual' === $mvweb_sml_b['origin'] ? __( 'Manual', 'mvweb-smart-links' ) : $mvweb_sml_b['origin'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</div>

<div class="mvweb-block mvweb-sml-reports">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Keyword cannibalization', 'mvweb-smart-links' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'Keywords assigned to multiple posts compete for the same search intent — pick a winner per keyword.', 'mvweb-smart-links' ); ?>
	</p>

	<?php if ( empty( $mvweb_sml_conflicts ) ) : ?>
		<p><?php esc_html_e( 'No conflicts detected.', 'mvweb-smart-links' ); ?></p>
	<?php else : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Keyword', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Posts', 'mvweb-smart-links' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $mvweb_sml_conflicts as $mvweb_sml_conflict ) : ?>
						<tr>
							<td><?php echo esc_html( $mvweb_sml_conflict['keyword'] ); ?></td>
							<td>
								<?php
								$mvweb_sml_links_html = array();
								foreach ( $mvweb_sml_conflict['post_ids'] as $mvweb_sml_pid ) {
									$mvweb_sml_links_html[] = sprintf(
										'<a href="%1$s">%2$s</a>',
										esc_url( get_edit_post_link( $mvweb_sml_pid ) ),
										esc_html( get_the_title( $mvweb_sml_pid ) )
									);
								}
								echo wp_kses(
									implode( ', ', $mvweb_sml_links_html ),
									array(
										'a' => array( 'href' => array() ),
									)
								);
								?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</div>

<div class="mvweb-block mvweb-sml-reports">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Anchor over-optimization', 'mvweb-smart-links' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'The same exact anchor text repeated across many links to one target looks manipulative to search engines. Diversify these anchors — rotate synonyms or vary the wording.', 'mvweb-smart-links' ); ?>
	</p>

	<?php if ( empty( $mvweb_sml_anchors ) ) : ?>
		<p><?php esc_html_e( 'No over-used anchors — anchor text is well diversified.', 'mvweb-smart-links' ); ?></p>
	<?php else : ?>
		<div class="mvweb-table-wrap">
			<table class="mvweb-table">
				<thead>
					<tr>
						<th><?php esc_html_e( 'Target', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Anchor', 'mvweb-smart-links' ); ?></th>
						<th><?php esc_html_e( 'Times used', 'mvweb-smart-links' ); ?></th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $mvweb_sml_anchors as $mvweb_sml_anchor_row ) : ?>
						<?php
						$mvweb_sml_anchor_title = get_the_title( $mvweb_sml_anchor_row['target_id'] );
						if ( '' === $mvweb_sml_anchor_title ) {
							$mvweb_sml_anchor_title = '#' . $mvweb_sml_anchor_row['target_id'];
						}
						$mvweb_sml_anchor_badge = $mvweb_sml_anchor_row['count'] >= 4 ? 'mvweb-badge--error' : 'mvweb-badge--warning';
						?>
						<tr>
							<td>
								<a href="<?php echo esc_url( get_edit_post_link( $mvweb_sml_anchor_row['target_id'] ) ); ?>">
									<?php echo esc_html( $mvweb_sml_anchor_title ); ?>
								</a>
							</td>
							<td><?php echo esc_html( $mvweb_sml_anchor_row['anchor'] ); ?></td>
							<td>
								<span class="mvweb-badge <?php echo esc_attr( $mvweb_sml_anchor_badge ); ?>">
									<?php echo esc_html( number_format_i18n( $mvweb_sml_anchor_row['count'] ) ); ?>
								</span>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php endif; ?>
</div>

<div class="mvweb-block mvweb-sml-reports">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Crawl depth', 'mvweb-smart-links' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'How many clicks it takes to reach a page, starting from the homepage and following internal links.', 'mvweb-smart-links' ); ?>
	</p>

	<?php if ( 'no_links' === $mvweb_sml_crawl['reason'] ) : ?>
		<div class="mvweb-alert mvweb-alert--warning">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
			<div class="mvweb-alert__body">
				<p><?php esc_html_e( 'Run reindex and Generate suggestions before viewing crawl depth.', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>
	<?php elseif ( 'no_front_page' === $mvweb_sml_crawl['reason'] ) : ?>
		<div class="mvweb-alert mvweb-alert--warning">
			<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
			<div class="mvweb-alert__body">
				<p><?php esc_html_e( 'Could not determine your homepage to measure link depth from. Check Settings → Reading in wp-admin.', 'mvweb-smart-links' ); ?></p>
			</div>
		</div>
	<?php else : ?>
		<ul class="mvweb-sml-reports__crawl">
			<li>
				<strong><?php esc_html_e( 'Pages reached:', 'mvweb-smart-links' ); ?></strong>
				<?php echo esc_html( number_format_i18n( count( $mvweb_sml_crawl['depths'] ) ) ); ?>
			</li>
			<li>
				<strong><?php esc_html_e( 'Maximum depth:', 'mvweb-smart-links' ); ?></strong>
				<?php echo esc_html( number_format_i18n( $mvweb_sml_crawl['max_depth'] ) ); ?>
			</li>
			<li>
				<strong><?php esc_html_e( 'Average depth:', 'mvweb-smart-links' ); ?></strong>
				<?php echo esc_html( number_format_i18n( $mvweb_sml_crawl['average'], 2 ) ); ?>
			</li>
		</ul>
	<?php endif; ?>
</div>
