<?php
/**
 * Bulk suggestions controller — Keywords tab table backend.
 *
 * Provides a paginated, filterable view over the `_links` table with
 * inline anchor editing, mass approve/reject and the "Generate suggestions"
 * sweep that re-uses the shared MVweb_SML_DOM_Scanner.
 *
 * Every endpoint is locked behind:
 *   - check_ajax_referer( 'mvweb_sml_admin', 'nonce' )
 *   - current_user_can( 'edit_others_posts' )
 *   - a per-row edit_post check before any mutation, plus DoS caps: 500 ids per
 *     explicit-id bulk mutation, 2000 rows per "apply to all matching" run
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Bulk
 *
 * @since 1.0.0
 */
class MVweb_SML_Bulk {

	/**
	 * Capability required for every bulk endpoint.
	 *
	 * Mirrors MVweb_SML_Admin::CAPABILITY (TZ §16 — editor and above).
	 */
	const CAPABILITY = 'edit_others_posts';

	/**
	 * Hard upper bound on bulk mutation payload size.
	 *
	 * Anti-DoS — protects approve/reject from million-id payloads.
	 */
	const MAX_BULK_IDS = 500;

	/**
	 * Hard upper bound on how many rows one "apply to all matching" request
	 * mutates. Keeps a filter that matches thousands of rows from blowing the
	 * request timeout — the UI reports when a run was capped so the operator
	 * can repeat it (a status filter drops the just-changed rows out of range).
	 */
	const MAX_BULK_FILTER = 2000;

	/**
	 * Default page size for the bulk listing.
	 */
	const DEFAULT_PER_PAGE = 25;

	/**
	 * How many source posts the "Generate suggestions" sweep walks per AJAX
	 * step. Kept small so each request finishes well under PHP timeouts.
	 */
	const SUGGEST_BATCH_SIZE = 5;

	/**
	 * Allowed status values for filters and bulk mutations.
	 *
	 * @var array<int, string>
	 */
	const ALLOWED_STATUSES = array( 'pending', 'approved', 'rejected', 'auto' );

	/**
	 * Register every AJAX endpoint exposed by this controller.
	 *
	 * Called from MVweb_SML_Loader::register_hooks() — see loader for the
	 * exact wiring.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'wp_ajax_mvweb_sml_bulk_list', array( __CLASS__, 'ajax_list' ) );
		add_action( 'wp_ajax_mvweb_sml_bulk_update_anchor', array( __CLASS__, 'ajax_update_anchor' ) );
		add_action( 'wp_ajax_mvweb_sml_bulk_apply', array( __CLASS__, 'ajax_bulk_apply' ) );
		add_action( 'wp_ajax_mvweb_sml_bulk_filter', array( __CLASS__, 'ajax_bulk_filter' ) );
		add_action( 'wp_ajax_mvweb_sml_generate_suggestions', array( __CLASS__, 'ajax_generate_suggestions' ) );
		add_action( 'wp_ajax_mvweb_sml_auto_preview', array( __CLASS__, 'ajax_auto_preview' ) );
	}

	/**
	 * AJAX: dry-run preview of what automatic mode would auto-approve.
	 *
	 * Read-only. Counts the pending suggestions whose score clears the current
	 * auto_min_score threshold (the pairs auto mode promotes to `status='auto'`
	 * without review) and returns a scored sample. Nothing is mutated, so the
	 * operator can gauge the impact of the thresholds before switching modes.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_auto_preview() {
		self::check_access();

		global $wpdb;
		$table = mvweb_sml_table( 'links' );
		$min   = (int) mvweb_sml_get_setting( 'auto_min_score', 3 );
		$cap   = (int) mvweb_sml_get_setting( 'auto_max_inbound', 5 );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $wpdb->get_var(
			$wpdb->prepare( "SELECT COUNT(*) FROM `{$table}` WHERE status = 'pending' AND score >= %d", $min )
		);
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT source_id, target_id, keyword, anchor, score FROM `{$table}`
				 WHERE status = 'pending' AND score >= %d
				 ORDER BY score DESC, id DESC
				 LIMIT 20",
				$min
			),
			ARRAY_A
		);
		// phpcs:enable

		$items = array();
		foreach ( (array) $rows as $row ) {
			$anchor  = '' !== (string) $row['anchor'] ? (string) $row['anchor'] : (string) $row['keyword'];
			$items[] = array(
				'source' => html_entity_decode( (string) get_the_title( (int) $row['source_id'] ), ENT_QUOTES, 'UTF-8' ),
				'target' => html_entity_decode( (string) get_the_title( (int) $row['target_id'] ), ENT_QUOTES, 'UTF-8' ),
				'anchor' => $anchor,
				'score'  => round( (float) $row['score'], 2 ),
			);
		}

		wp_send_json_success(
			array(
				'total' => $total,
				'shown' => count( $items ),
				'min'   => $min,
				'cap'   => $cap,
				'mode'  => (string) mvweb_sml_get_setting( 'mode', 'semi' ),
				'items' => $items,
			)
		);
	}

	// ─────────────────────────────────────────────────────────────────────
	// Access guard
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Shared guard: nonce + capability check, terminates request on failure.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function check_access() {
		check_ajax_referer( 'mvweb_sml_admin', 'nonce' );

		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to manage suggestions.', 'mvweb-smart-links' ) ),
				403
			);
		}
	}

	/**
	 * Read, sanitize and clamp an `ids` POST array.
	 *
	 * @since 1.0.0
	 * @return array<int, int>
	 */
	private static function read_ids() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified in check_access().
		// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Each element is coerced via absint() below.
		$raw = isset( $_POST['ids'] ) ? (array) wp_unslash( $_POST['ids'] ) : array();
		// phpcs:enable
		$ids = array_values(
			array_unique(
				array_filter(
					array_map( 'absint', $raw )
				)
			)
		);

		if ( count( $ids ) > self::MAX_BULK_IDS ) {
			$ids = array_slice( $ids, 0, self::MAX_BULK_IDS );
		}

		return $ids;
	}

	// ─────────────────────────────────────────────────────────────────────
	// Listing
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Build the WHERE clause (and its params) shared by the listing and the
	 * "apply to all matching" bulk action, straight from the request filters.
	 *
	 * Reads the same POST fields the review table sends (cpt, category,
	 * cluster, status, search, orphan_only, has_keywords). The alias `l` refers
	 * to the `_links` table; callers must join it as `\`links\` l`.
	 *
	 * @since 1.0.0
	 * @return array{0:string,1:array<int,mixed>} [ $where_sql, $params ]
	 */
	private static function build_list_filter() {
		global $wpdb;

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$cpt          = isset( $_POST['cpt'] ) ? sanitize_key( wp_unslash( $_POST['cpt'] ) ) : '';
		$category     = isset( $_POST['category'] ) ? absint( wp_unslash( $_POST['category'] ) ) : 0;
		$cluster      = isset( $_POST['cluster'] ) ? absint( wp_unslash( $_POST['cluster'] ) ) : 0;
		$status       = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';
		$search       = isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
		$orphan_only  = ! empty( $_POST['orphan_only'] );
		$has_keywords = ! empty( $_POST['has_keywords'] );
		// phpcs:enable

		$links_table    = mvweb_sml_table( 'links' );
		$keywords_table = mvweb_sml_table( 'keywords' );
		$cluster_table  = mvweb_sml_table( 'cluster_posts' );

		$where  = array( '1=1' );
		$params = array();

		if ( '' !== $status && in_array( $status, self::ALLOWED_STATUSES, true ) ) {
			$where[]  = 'l.status = %s';
			$params[] = $status;
		}

		// CPT filter — restricts to source posts of the given post_type.
		if ( '' !== $cpt && post_type_exists( $cpt ) ) {
			$where[]  = "l.source_id IN ( SELECT ID FROM {$wpdb->posts} WHERE post_type = %s )";
			$params[] = $cpt;
		}

		// Category filter — sources that belong to the given term_id (only
		// applies to taxonomies whose objects include the source post type).
		if ( $category > 0 ) {
			$where[]  = "l.source_id IN ( SELECT object_id FROM {$wpdb->term_relationships} WHERE term_taxonomy_id = %d )";
			$params[] = $category;
		}

		// Cluster filter — source post belongs to the cluster (any role).
		if ( $cluster > 0 ) {
			$where[]  = "l.source_id IN ( SELECT post_id FROM `{$cluster_table}` WHERE cluster_id = %d )";
			$params[] = $cluster;
		}

		// Orphan-only — sources that have NO inbound links pointing at them
		// (i.e. nobody links to this source as a target).
		if ( $orphan_only ) {
			$where[] = "NOT EXISTS ( SELECT 1 FROM `{$links_table}` l2 WHERE l2.target_id = l.source_id )";
		}

		// Has-keywords filter — restrict to sources that own at least one
		// keyword in the keywords table.
		if ( $has_keywords ) {
			$where[] = "EXISTS ( SELECT 1 FROM `{$keywords_table}` k WHERE k.post_id = l.source_id )";
		}

		// Search applies to keyword text.
		if ( '' !== $search ) {
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$where[]  = 'l.keyword LIKE %s';
			$params[] = $like;
		}

		return array( implode( ' AND ', $where ), $params );
	}

	/**
	 * AJAX: paginated + filtered list of `_links` rows.
	 *
	 * Response shape:
	 *   {
	 *       items: [ { id, source_id, source_title, source_edit_url,
	 *                  target_id, target_title, target_edit_url,
	 *                  keyword, anchor, status, score } ],
	 *       total: int, page: int, pages: int, per_page: int
	 *   }
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_list() {
		self::check_access();

		global $wpdb;

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$page     = isset( $_POST['page'] ) ? absint( wp_unslash( $_POST['page'] ) ) : 1;
		$per_page = isset( $_POST['per_page'] ) ? absint( wp_unslash( $_POST['per_page'] ) ) : self::DEFAULT_PER_PAGE;
		$orderby  = isset( $_POST['orderby'] ) ? sanitize_key( wp_unslash( $_POST['orderby'] ) ) : 'id';
		$order    = isset( $_POST['order'] ) && 'asc' === strtolower( (string) wp_unslash( $_POST['order'] ) ) ? 'ASC' : 'DESC';
		// phpcs:enable

		$page     = max( 1, $page );
		$per_page = max( 5, min( 100, $per_page ) );

		// Whitelist the sort column — the value is interpolated into the query.
		$orderby_map = array(
			'id'     => 'l.id',
			'score'  => 'l.score',
			'status' => 'l.status',
		);
		$orderby_sql = isset( $orderby_map[ $orderby ] ) ? $orderby_map[ $orderby ] : 'l.id';
		if ( ! isset( $orderby_map[ $orderby ] ) ) {
			$orderby = 'id';
		}

		$links_table = mvweb_sml_table( 'links' );

		list( $where_sql, $params ) = self::build_list_filter();

		// Total count for pagination.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		$count_sql = "SELECT COUNT(*) FROM `{$links_table}` l WHERE {$where_sql}";
		$total     = (int) ( empty( $params )
			? $wpdb->get_var( $count_sql )
			: $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) )
		);
		// phpcs:enable

		$pages  = $total > 0 ? (int) ceil( $total / $per_page ) : 0;
		$offset = ( $page - 1 ) * $per_page;

		// Fetch the rows for the current page.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		// Secondary sort by id keeps paging stable when the primary key ties.
		$select_sql = "SELECT l.id, l.source_id, l.target_id, l.keyword, l.anchor, l.status, l.score, l.context
			FROM `{$links_table}` l
			WHERE {$where_sql}
			ORDER BY {$orderby_sql} {$order}, l.id DESC
			LIMIT %d OFFSET %d";

		$select_params   = $params;
		$select_params[] = $per_page;
		$select_params[] = $offset;

		$rows = $wpdb->get_results( $wpdb->prepare( $select_sql, $select_params ), ARRAY_A );
		// phpcs:enable

		// Anchor over-optimisation hint: in ONE query, count how many live
		// (approved/auto) links already use each (target, anchor) pair on this
		// page, so the review table can warn before yet another identical
		// exact-match anchor is approved to the same destination.
		$reuse_map    = array();
		$page_targets = array_values( array_unique( array_map( 'intval', wp_list_pluck( (array) $rows, 'target_id' ) ) ) );
		if ( ! empty( $page_targets ) ) {
			$reuse_ph = implode( ',', array_fill( 0, count( $page_targets ), '%d' ) );
			// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
			$reuse_rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT target_id, anchor, COUNT(*) AS cnt
					 FROM `{$links_table}`
					 WHERE status IN ('approved','auto') AND anchor <> '' AND target_id IN ({$reuse_ph})
					 GROUP BY target_id, anchor",
					$page_targets
				),
				ARRAY_A
			);
			// phpcs:enable
			foreach ( (array) $reuse_rows as $reuse_row ) {
				$reuse_map[ (int) $reuse_row['target_id'] ][ (string) $reuse_row['anchor'] ] = (int) $reuse_row['cnt'];
			}
		}

		$items = array();
		foreach ( (array) $rows as $row ) {
			$source_id = (int) $row['source_id'];
			$target_id = (int) $row['target_id'];

			$context = array();
			if ( ! empty( $row['context'] ) ) {
				$decoded = json_decode( (string) $row['context'], true );
				if ( is_array( $decoded ) ) {
					$context = array(
						'b' => isset( $decoded['b'] ) ? (string) $decoded['b'] : '',
						'm' => isset( $decoded['m'] ) ? (string) $decoded['m'] : '',
						'a' => isset( $decoded['a'] ) ? (string) $decoded['a'] : '',
					);
				}
			}

			$items[] = array(
				'id'              => (int) $row['id'],
				'source_id'       => $source_id,
				// get_the_title() encodes entities, including NUMERIC ones
				// (— → &#8212;) that wp_specialchars_decode() leaves untouched.
				// html_entity_decode handles both named and numeric, giving a
				// plain Unicode string; the client renders it with jQuery .text()
				// which does the single, correct escaping.
				'source_title'    => html_entity_decode( (string) get_the_title( $source_id ), ENT_QUOTES, 'UTF-8' ),
				'source_edit_url' => (string) get_edit_post_link( $source_id, 'raw' ),
				'target_id'       => $target_id,
				'target_title'    => html_entity_decode( (string) get_the_title( $target_id ), ENT_QUOTES, 'UTF-8' ),
				'target_edit_url' => (string) get_edit_post_link( $target_id, 'raw' ),
				'keyword'         => (string) $row['keyword'],
				'anchor'          => (string) $row['anchor'],
				'status'          => (string) $row['status'],
				'score'           => (float) $row['score'],
				'context'         => $context,
				'anchor_reuse'    => isset( $reuse_map[ $target_id ][ (string) $row['anchor'] ] )
					? (int) $reuse_map[ $target_id ][ (string) $row['anchor'] ]
					: 0,
			);
		}

		wp_send_json_success(
			array(
				'items'    => $items,
				'total'    => $total,
				'page'     => $page,
				'pages'    => $pages,
				'per_page' => $per_page,
				'orderby'  => $orderby,
				'order'    => $order,
			)
		);
	}

	// ─────────────────────────────────────────────────────────────────────
	// Inline anchor edit
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * AJAX: update the `anchor` column of a single `_links` row.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_update_anchor() {
		self::check_access();

		global $wpdb;

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$id     = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;
		$anchor = isset( $_POST['anchor'] ) ? sanitize_text_field( wp_unslash( $_POST['anchor'] ) ) : '';
		// phpcs:enable

		if ( $id <= 0 ) {
			wp_send_json_error(
				array( 'message' => __( 'Invalid link ID.', 'mvweb-smart-links' ) ),
				400
			);
		}

		// Anchor column is VARCHAR(255).
		if ( mb_strlen( $anchor, 'UTF-8' ) > 255 ) {
			$anchor = mb_substr( $anchor, 0, 255, 'UTF-8' );
		}

		$table = mvweb_sml_table( 'links' );

		// Per-row authorisation: the global capability check in check_access()
		// is not enough in a multi-author site — confirm the user may edit the
		// specific source post this link belongs to before mutating its anchor.
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$source_id = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT source_id FROM %i WHERE id = %d', $table, $id ) );
		if ( $source_id <= 0 || ! current_user_can( 'edit_post', $source_id ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to edit this link.', 'mvweb-smart-links' ) ),
				403
			);
		}

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery
		$updated = $wpdb->update(
			$table,
			array( 'anchor' => $anchor ),
			array( 'id' => $id ),
			array( '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			wp_send_json_error(
				array( 'message' => __( 'Failed to update anchor.', 'mvweb-smart-links' ) ),
				500
			);
		}

		// The anchor drives both the visible text and (for a sentence-level
		// phrase) the wrapped span, so the cached front-end output for the
		// source post is now stale.
		if ( class_exists( 'MVweb_SML_Cache' ) ) {
			MVweb_SML_Cache::flush_post( $source_id );
		}

		wp_send_json_success(
			array(
				'id'     => $id,
				'anchor' => $anchor,
			)
		);
	}

	// ─────────────────────────────────────────────────────────────────────
	// Bulk approve / reject
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * AJAX: apply a bulk action to an explicit id list from the review table.
	 *
	 * Reads the action from the request (approve / reject / reset-to-pending /
	 * delete) so both the row icons and the toolbar dropdown share one endpoint.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_bulk_apply() {
		self::check_access();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$action = self::normalize_bulk_action( isset( $_POST['bulk_action'] ) ? sanitize_key( wp_unslash( $_POST['bulk_action'] ) ) : '' );
		if ( '' === $action ) {
			wp_send_json_error( array( 'message' => __( 'Pick a bulk action.', 'mvweb-smart-links' ) ), 400 );
		}

		$ids = self::read_ids();
		if ( empty( $ids ) ) {
			wp_send_json_error( array( 'message' => __( 'No items selected.', 'mvweb-smart-links' ) ), 400 );
		}

		$result = self::apply_action_to_ids( $action, $ids );
		if ( false === $result ) {
			wp_send_json_error( array( 'message' => __( 'Failed to update items.', 'mvweb-smart-links' ) ), 500 );
		}

		wp_send_json_success( array( 'updated' => (int) $result ) );
	}

	/**
	 * AJAX: apply a bulk action to EVERY row matching the current filters, not
	 * just the visible page — the "select all N matching" affordance.
	 *
	 * Capped at MAX_BULK_FILTER rows per request; the response reports the total
	 * match count and whether the run was capped so the UI can prompt a repeat.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_bulk_filter() {
		self::check_access();

		global $wpdb;

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$action = self::normalize_bulk_action( isset( $_POST['bulk_action'] ) ? sanitize_key( wp_unslash( $_POST['bulk_action'] ) ) : '' );
		if ( '' === $action ) {
			wp_send_json_error( array( 'message' => __( 'Pick a bulk action.', 'mvweb-smart-links' ) ), 400 );
		}

		$links_table = mvweb_sml_table( 'links' );
		list( $where_sql, $params ) = self::build_list_filter();

		// Total matches (before the cap) so the UI can say "run again for the rest".
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		$count_sql = "SELECT COUNT(*) FROM `{$links_table}` l WHERE {$where_sql}";
		$matched   = (int) ( empty( $params )
			? $wpdb->get_var( $count_sql )
			: $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) )
		);

		// Pull one capped page of matching ids.
		$select_sql    = "SELECT l.id FROM `{$links_table}` l WHERE {$where_sql} ORDER BY l.id DESC LIMIT %d";
		$select_params = array_merge( $params, array( self::MAX_BULK_FILTER ) );
		$ids           = array_map( 'intval', (array) $wpdb->get_col( $wpdb->prepare( $select_sql, $select_params ) ) );
		// phpcs:enable

		if ( empty( $ids ) ) {
			wp_send_json_success(
				array(
					'updated' => 0,
					'matched' => $matched,
					'capped'  => false,
				)
			);
		}

		$result = self::apply_action_to_ids( $action, $ids );
		if ( false === $result ) {
			wp_send_json_error( array( 'message' => __( 'Failed to update items.', 'mvweb-smart-links' ) ), 500 );
		}

		wp_send_json_success(
			array(
				'updated' => (int) $result,
				'matched' => $matched,
				'capped'  => $matched > self::MAX_BULK_FILTER,
			)
		);
	}

	/**
	 * Normalise a raw bulk-action string to a canonical operation.
	 *
	 * @since 1.0.0
	 * @param string $raw Raw request value.
	 * @return string One of 'approved'|'rejected'|'pending'|'delete', or '' if invalid.
	 */
	private static function normalize_bulk_action( $raw ) {
		$map = array(
			'approve' => 'approved',
			'reject'  => 'rejected',
			'pending' => 'pending',
			'delete'  => 'delete',
		);
		return isset( $map[ $raw ] ) ? $map[ $raw ] : '';
	}

	/**
	 * Apply a status change (or deletion) to a set of `_links` ids.
	 *
	 * Shared by every bulk path (explicit ids and filter-wide). Enforces the
	 * same per-row `edit_post` authorisation as ajax_update_anchor — the global
	 * capability in check_access() is not enough on multi-author sites — and
	 * flushes the linker cache for every affected source post.
	 *
	 * @since 1.0.0
	 * @param string          $action 'approved'|'rejected'|'pending'|'delete'.
	 * @param array<int, int> $ids    `_links.id` values.
	 * @return int|false Rows affected, or false on a DB error.
	 */
	private static function apply_action_to_ids( $action, array $ids ) {
		$is_delete = ( 'delete' === $action );
		// Only the statuses a bulk action can set (not 'auto', which is
		// producer-only) plus the delete pseudo-action are accepted.
		if ( ! $is_delete && ! in_array( $action, array( 'approved', 'rejected', 'pending' ), true ) ) {
			return false;
		}

		$ids = array_values( array_unique( array_filter( array_map( 'intval', $ids ) ) ) );
		if ( empty( $ids ) ) {
			return 0;
		}

		global $wpdb;
		$table = mvweb_sml_table( 'links' );

		// Per-row authorisation + capture source ids for the cache flush (needed
		// before a delete removes the rows).
		$id_placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT id, source_id FROM %i WHERE id IN ({$id_placeholders})", array_merge( array( $table ), $ids ) ),
			ARRAY_A
		);
		// phpcs:enable

		// A real DB error here returns null and would otherwise be silently read
		// as "no rows / nobody authorised"; surface it as a failure instead.
		if ( null === $rows && '' !== (string) $wpdb->last_error ) {
			return false;
		}

		$allowed_ids = array();
		$source_ids  = array();
		foreach ( (array) $rows as $row ) {
			$sid = (int) $row['source_id'];
			if ( current_user_can( 'edit_post', $sid ) ) {
				$allowed_ids[]       = (int) $row['id'];
				$source_ids[ $sid ]  = true;
			}
		}
		if ( empty( $allowed_ids ) ) {
			return 0;
		}

		$placeholders = implode( ',', array_fill( 0, count( $allowed_ids ), '%d' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared
		if ( $is_delete ) {
			$affected = $wpdb->query(
				$wpdb->prepare( "DELETE FROM %i WHERE id IN ({$placeholders})", array_merge( array( $table ), $allowed_ids ) )
			);
		} else {
			$affected = $wpdb->query(
				$wpdb->prepare( "UPDATE %i SET status = %s WHERE id IN ({$placeholders})", array_merge( array( $table, $action ), $allowed_ids ) )
			);
		}
		// phpcs:enable

		if ( false === $affected ) {
			return false;
		}

		// Invalidate per-source caches so the frontend reflects the change.
		if ( class_exists( 'MVweb_SML_Cache' ) ) {
			foreach ( array_keys( $source_ids ) as $sid ) {
				MVweb_SML_Cache::flush_post( (int) $sid );
			}
		}

		return (int) $affected;
	}

	// ─────────────────────────────────────────────────────────────────────
	// Generate suggestions (Dry Run sweep)
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * AJAX: run one batch of the suggestion sweep.
	 *
	 * Driver state is kept in two transients:
	 *   - mvweb_sml_suggest_queue: array of remaining source post IDs.
	 *   - mvweb_sml_suggest_total: total queue size at the start (for UI %).
	 *
	 * Each step pops at most SUGGEST_BATCH_SIZE source posts, runs them
	 * through the shared DOM scanner in collect-only mode and INSERT IGNOREs
	 * the resulting pairs into `_links` with status='pending'.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_generate_suggestions() {
		self::check_access();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$reset = ! empty( $_POST['reset'] );

		if ( $reset ) {
			$queue = self::collect_source_queue();
			set_transient( 'mvweb_sml_suggest_queue', $queue, HOUR_IN_SECONDS );
			set_transient( 'mvweb_sml_suggest_total', count( $queue ), HOUR_IN_SECONDS );

			wp_send_json_success(
				array(
					'total'     => count( $queue ),
					'remaining' => count( $queue ),
					'inserted'  => 0,
				)
			);
		}

		$queue = get_transient( 'mvweb_sml_suggest_queue' );
		$total = (int) get_transient( 'mvweb_sml_suggest_total' );

		if ( ! is_array( $queue ) || empty( $queue ) ) {
			delete_transient( 'mvweb_sml_suggest_queue' );
			delete_transient( 'mvweb_sml_suggest_total' );

			wp_send_json_success(
				array(
					'total'     => $total,
					'remaining' => 0,
					'inserted'  => 0,
					'done'      => true,
				)
			);
		}

		$batch     = array_splice( $queue, 0, self::SUGGEST_BATCH_SIZE );
		$inserted  = 0;
		$processed = 0;

		foreach ( $batch as $source_id ) {
			$inserted += self::sweep_source( (int) $source_id );
			++$processed;
		}

		// Persist remaining queue.
		if ( empty( $queue ) ) {
			delete_transient( 'mvweb_sml_suggest_queue' );
			delete_transient( 'mvweb_sml_suggest_total' );
		} else {
			set_transient( 'mvweb_sml_suggest_queue', array_values( $queue ), HOUR_IN_SECONDS );
		}

		wp_send_json_success(
			array(
				'total'     => $total,
				'remaining' => count( $queue ),
				'processed' => $processed,
				'inserted'  => $inserted,
				'done'      => empty( $queue ),
			)
		);
	}

	/**
	 * Build the queue of source post IDs the sweep should walk.
	 *
	 * Restricted to supported post types and `publish` status.
	 *
	 * @since 1.0.0
	 * @return array<int, int>
	 */
	private static function collect_source_queue() {
		global $wpdb;

		$post_types = mvweb_sml_supported_post_types();
		if ( empty( $post_types ) ) {
			return array();
		}

		$placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT ID FROM {$wpdb->posts} WHERE post_status = 'publish' AND post_type IN ({$placeholders}) ORDER BY ID ASC",
				$post_types
			)
		);
		// phpcs:enable

		return array_values( array_map( 'intval', (array) $ids ) );
	}

	/**
	 * Run a single source post through the DOM scanner in collect-only mode
	 * and persist every detected pair as a pending `_links` row.
	 *
	 * @since 1.0.0
	 * @param int $source_id Source post ID.
	 * @return int Number of new rows inserted (existing pairs are ignored).
	 */
	private static function sweep_source( $source_id ) {
		if ( $source_id <= 0 ) {
			return 0;
		}

		$post = get_post( $source_id );
		if ( ! $post || 'publish' !== $post->post_status ) {
			return 0;
		}

		// Honour the per-post opt-out and the global blacklist so the sweep
		// never produces suggestions for sources that the linker would skip
		// on the frontend (TZ §3.4).
		if ( '1' === (string) get_post_meta( $source_id, '_mvweb_sml_disabled', true ) ) {
			return 0;
		}

		$disabled_ids = (array) mvweb_sml_get_setting( 'disabled_post_ids', array() );
		if ( in_array( $source_id, array_map( 'intval', $disabled_ids ), true ) ) {
			return 0;
		}

		$disabled_terms = array_map( 'intval', (array) mvweb_sml_get_setting( 'disabled_terms', array() ) );
		if ( ! empty( $disabled_terms ) ) {
			$taxonomies = get_object_taxonomies( $post->post_type );
			if ( ! empty( $taxonomies ) ) {
				$post_terms = wp_get_object_terms( $source_id, $taxonomies, array( 'fields' => 'ids' ) );
				if ( ! is_wp_error( $post_terms ) && array_intersect( $disabled_terms, array_map( 'intval', $post_terms ) ) ) {
					return 0;
				}
			}
		}

		$content = (string) $post->post_content;
		if ( '' === $content ) {
			return 0;
		}

		$candidates = self::collect_sweep_candidates( $source_id );
		if ( empty( $candidates ) ) {
			return 0;
		}

		// Use generous defaults for the sweep — we are only collecting pairs,
		// the per-page cap on the frontend is enforced separately at render
		// time. We still respect gap-words to avoid suggesting links that
		// would later be silently dropped by the linker.
		$opts = array(
			'links_gap_words'    => (int) mvweb_sml_get_setting( 'links_gap_words', 50 ),
			'links_max_per_page' => 0, // No cap during collection.
			'link_class'         => 'mvweb-sml-link',
			'link_target'        => '_self',
		);

		$result   = MVweb_SML_DOM_Scanner::scan( $content, $source_id, $candidates, $opts );
		$inserted = isset( $result['inserted'] ) && is_array( $result['inserted'] ) ? $result['inserted'] : array();

		if ( empty( $inserted ) ) {
			return 0;
		}

		// Map keyword → target_id for the persistence step. Candidates have
		// the canonical mapping; the scanner only echoes back the matched
		// pair so we look up the target_id from the candidate list.
		$by_keyword = array();
		foreach ( $candidates as $cand ) {
			$kw_key                = mb_strtolower( (string) $cand['keyword'], 'UTF-8' );
			$by_keyword[ $kw_key ] = $cand;
		}

		global $wpdb;
		$table = mvweb_sml_table( 'links' );
		$now   = current_time( 'mysql' );
		$rows  = 0;

		// Pre-compute a topical-overlap score for every target in this sweep so
		// the review table and frontend linker can rank suggestions by relevance
		// instead of insertion order. Reuses the cached `_index` prominent maps.
		$score_targets = array();
		foreach ( $inserted as $hit ) {
			$key = mb_strtolower( isset( $hit['keyword'] ) ? (string) $hit['keyword'] : '', 'UTF-8' );
			if ( isset( $by_keyword[ $key ] ) ) {
				$score_targets[] = (int) $by_keyword[ $key ]['target_id'];
			}
		}
		// Shared prominent words per target — the integer base score is their
		// count; the words themselves feed the IDF ranking refinement below.
		$shared_map = ( ! empty( $score_targets ) && class_exists( 'MVweb_SML_Cluster_Manager' ) )
			? MVweb_SML_Cluster_Manager::overlap_scored_words( $source_id, $score_targets )
			: array();

		$scores = array();
		foreach ( $shared_map as $tid => $words ) {
			$scores[ (int) $tid ] = count( $words );
		}

		// Ranking refinement (§4.1): rarer shared words (IDF) and links that land
		// early in the prose (Reasonable Surfer) nudge a pair up. Kept as a bounded
		// fraction < 1 added on top of the integer base+bonus, so the auto-mode
		// threshold and cornerstone bonus keep their exact integer semantics.
		$use_idf      = (bool) mvweb_sml_get_setting( 'score_idf', true );
		$use_position = (bool) mvweb_sml_get_setting( 'score_position', true );
		$doc_freq     = array();
		$corpus_total = 0;
		if ( $use_idf && class_exists( 'MVweb_SML_Indexer' ) ) {
			$freq         = MVweb_SML_Indexer::document_frequencies();
			$doc_freq     = isset( $freq['df'] ) && is_array( $freq['df'] ) ? $freq['df'] : array();
			$corpus_total = isset( $freq['total'] ) ? (int) $freq['total'] : 0;
		}
		$word_total = isset( $result['word_total'] ) ? (int) $result['word_total'] : 0;

		// Word index of each match, keyed by lower-cased keyword, for the
		// positional component (the scanner reports one hit per target).
		$word_pos_map = array();
		foreach ( $inserted as $hit ) {
			if ( isset( $hit['keyword'], $hit['word_pos'] ) ) {
				$word_pos_map[ mb_strtolower( (string) $hit['keyword'], 'UTF-8' ) ] = (int) $hit['word_pos'];
			}
		}

		// Cornerstone bonus: lift pillar pages up the ranked list so suggestions
		// funnel link equity toward them (hub-and-spoke). Bonus is additive on
		// the topical-overlap score; 0 disables it.
		$pillar_bonus = (int) mvweb_sml_get_setting( 'pillar_score_bonus', 3 );
		if ( $pillar_bonus > 0 && ! empty( $score_targets ) && class_exists( 'MVweb_SML_Cluster_Manager' ) ) {
			$pillar_set = array_flip( MVweb_SML_Cluster_Manager::pillar_ids() );
			if ( ! empty( $pillar_set ) ) {
				foreach ( array_unique( $score_targets ) as $score_tid ) {
					if ( isset( $pillar_set[ $score_tid ] ) ) {
						$scores[ $score_tid ] = ( isset( $scores[ $score_tid ] ) ? (float) $scores[ $score_tid ] : 0.0 ) + $pillar_bonus;
					}
				}
			}
		}

		// Interlinking mode + auto-mode safeguards (read once per sweep).
		$mode             = (string) mvweb_sml_get_setting( 'mode', 'semi' );
		$auto_min_score   = (int) mvweb_sml_get_setting( 'auto_min_score', 3 );
		$auto_max_inbound = (int) mvweb_sml_get_setting( 'auto_max_inbound', 5 );

		// Anchor rotation: diversify exact-match anchors that already point to a
		// target too many times by swapping in a registered synonym that actually
		// occurs in the source prose. Read the plain text and the synonym pool
		// once; both are only needed when rotation is on.
		$rotation_on = (bool) mvweb_sml_get_setting( 'anchor_rotation', true );
		$max_repeat  = max( 1, (int) mvweb_sml_get_setting( 'anchor_max_repeat', 3 ) );
		$plain_text  = '';
		$syn_map     = array();
		if ( $rotation_on ) {
			$plain_text = wp_strip_all_tags( strip_shortcodes( $content ) );
			$syn_map    = self::synonyms_for_targets( $score_targets );
		}

		foreach ( $inserted as $hit ) {
			$keyword = isset( $hit['keyword'] ) ? (string) $hit['keyword'] : '';
			$anchor  = isset( $hit['anchor'] ) ? (string) $hit['anchor'] : $keyword;
			$key     = mb_strtolower( $keyword, 'UTF-8' );

			if ( ! isset( $by_keyword[ $key ] ) ) {
				continue;
			}

			$target_id = (int) $by_keyword[ $key ]['target_id'];
			if ( $target_id <= 0 || $target_id === $source_id ) {
				continue;
			}

			// Swap the anchor for a less-used synonym when the default is already
			// over-represented on this target. Only a genuinely new row is affected
			// — the ON DUPLICATE KEY UPDATE below never touches `anchor`, so an
			// approved link or a human-edited anchor is left untouched.
			if ( $rotation_on ) {
				$syn_key = $target_id . '|' . $key;
				if ( ! empty( $syn_map[ $syn_key ] ) ) {
					$anchor = self::rotate_anchor( $plain_text, $syn_map[ $syn_key ], $target_id, $anchor, $max_repeat );
				}
			}

			$score = isset( $scores[ $target_id ] ) ? (float) $scores[ $target_id ] : 0.0;

			// Add the bounded IDF + positional refinement (< 1) so pairs with the
			// same integer base rank by topical distinctiveness and link position.
			// Only when the pair actually shares prominent words — position alone
			// must never lift an otherwise-irrelevant target.
			if ( ( $use_idf || $use_position ) && ! empty( $shared_map[ $target_id ] ) ) {
				$score += self::refine_score(
					$shared_map[ $target_id ],
					isset( $word_pos_map[ $key ] ) ? $word_pos_map[ $key ] : null,
					$word_total,
					$use_idf ? $doc_freq : array(),
					$use_idf ? $corpus_total : 0,
					$use_position
				);
			}

			// Auto mode promotes high-confidence pairs straight to status='auto'
			// (rendered without manual review), guarded by a relevance threshold
			// and a per-target inbound cap so one page is never over-linked. The
			// cap counts rows committed earlier in this same sweep too, because
			// each INSERT commits before the next COUNT runs.
			$status = 'pending';
			if ( 'auto' === $mode && $score >= $auto_min_score ) {
				// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$inbound = (int) $wpdb->get_var(
					$wpdb->prepare( "SELECT COUNT(*) FROM %i WHERE target_id = %d AND status IN ('approved','auto')", $table, $target_id )
				);
				// phpcs:enable
				if ( $inbound < $auto_max_inbound ) {
					$status = 'auto';
				}
			}

			// JSON_UNESCAPED_UNICODE keeps Cyrillic snippets compact (one char per
			// codepoint instead of a 6-char \uXXXX escape) so they fit the 255-char
			// column instead of being dropped by the guard below.
			$context_json = ( isset( $hit['context'] ) && is_array( $hit['context'] ) )
				? (string) wp_json_encode( $hit['context'], JSON_UNESCAPED_UNICODE )
				: '';
			if ( mb_strlen( $context_json, 'UTF-8' ) > 255 ) {
				$context_json = '';
			}

			// ON DUPLICATE KEY UPDATE refreshes the relevance score and snippet on
			// repeated sweeps via the UNIQUE KEY uq_pair_kw — without clobbering the
			// human decision (status) or an edited anchor. Values are passed as
			// parameters (not VALUES()) so the statement stays portable across
			// MySQL 8.4 and MariaDB.
			// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$ok = $wpdb->query(
				$wpdb->prepare(
					"INSERT INTO `{$table}`
						(source_id, target_id, keyword, anchor, status, score, context, created_at)
					 VALUES (%d, %d, %s, %s, %s, %f, %s, %s)
					 ON DUPLICATE KEY UPDATE score = %f, context = COALESCE(NULLIF(%s, ''), context)",
					$source_id,
					$target_id,
					$keyword,
					$anchor,
					$status,
					$score,
					$context_json,
					$now,
					$score,
					$context_json
				)
			);
			// phpcs:enable

			// $wpdb->query returns false on a real DB error, which is otherwise
			// indistinguishable from a legitimate "0 rows changed" no-op — do
			// not let a failed INSERT vanish silently.
			if ( false === $ok ) {
				mvweb_sml_log(
					sprintf(
						'sweep INSERT failed (source %d → target %d): %s',
						$source_id,
						$target_id,
						$wpdb->last_error
					),
					'error'
				);
				continue;
			}

			// Count only genuinely new rows ($wpdb->query returns 1 on INSERT,
			// 2 on UPDATE, 0 on no-op) so the progress total is not inflated by
			// score refreshes on re-runs.
			if ( 1 === (int) $ok ) {
				++$rows;
			}
		}

		if ( $rows > 0 && class_exists( 'MVweb_SML_Cache' ) ) {
			MVweb_SML_Cache::flush_post( $source_id );
		}

		return $rows;
	}

	/**
	 * Bounded ranking refinement for one candidate pair, in the range [0, 0.9).
	 *
	 * Two signals, each normalised to [0, 1]:
	 *   - IDF: average rarity of the shared prominent words (a word in few posts
	 *     is more distinctive than corpus filler). Neutral (0) when the corpus is
	 *     too small for meaningful document frequencies.
	 *   - Position: how early the link lands in the prose (1 = very top, 0 = end).
	 *
	 * Weighted 0.5 / 0.4 so the total stays below 1 — the caller adds it on top of
	 * the integer base+bonus score, and keeping it fractional means the auto-mode
	 * threshold and cornerstone bonus keep operating on the whole-number part.
	 *
	 * @since 1.0.0
	 * @param string[]           $shared_words Prominent words shared by source and target.
	 * @param int|null           $word_pos     Word index of the match (null = unknown).
	 * @param int                $word_total   Total prose words in the source.
	 * @param array<string, int> $doc_freq     Corpus document frequencies (empty = IDF off).
	 * @param int                $corpus_total Number of posts in the corpus.
	 * @param bool               $use_position Whether to include the positional term.
	 * @return float
	 */
	private static function refine_score( array $shared_words, $word_pos, $word_total, array $doc_freq, $corpus_total, $use_position ) {
		$refinement = 0.0;

		// IDF term — only meaningful with a corpus of at least a couple of posts.
		if ( ! empty( $doc_freq ) && $corpus_total > 1 && ! empty( $shared_words ) ) {
			$log_total = log( (float) $corpus_total );
			if ( $log_total > 0 ) {
				$sum = 0.0;
				foreach ( $shared_words as $word ) {
					$df       = isset( $doc_freq[ $word ] ) ? max( 1, (int) $doc_freq[ $word ] ) : 1;
					$idf_norm = log( (float) $corpus_total / $df ) / $log_total; // [0, 1].
					$sum     += max( 0.0, min( 1.0, $idf_norm ) );
				}
				$refinement += 0.5 * ( $sum / count( $shared_words ) );
			}
		}

		// Positional term — earlier in the prose weighs slightly more.
		if ( $use_position && null !== $word_pos && $word_total > 0 ) {
			$ratio      = max( 0.0, min( 1.0, (float) $word_pos / (float) $word_total ) );
			$refinement += 0.4 * ( 1.0 - $ratio );
		}

		return $refinement;
	}

	/**
	 * Build a (target_id|keyword) → synonyms lookup for a set of target posts.
	 *
	 * Rotation needs the synonym pool of each keyword, which the sweep candidate
	 * list deliberately omits (feeding synonyms to the scanner there would change
	 * which pairs the sweep discovers). One batch query keeps it off the per-row
	 * path. Keyword is lower-cased in the map key to match the persist loop.
	 *
	 * @since 1.0.0
	 * @param array<int, int> $target_ids Target post IDs seen in this sweep.
	 * @return array<string, string[]> Map of "targetId|keyword" => synonym list.
	 */
	private static function synonyms_for_targets( array $target_ids ) {
		global $wpdb;

		$ids = array_values( array_unique( array_filter( array_map( 'intval', $target_ids ) ) ) );
		if ( empty( $ids ) ) {
			return array();
		}

		$table        = mvweb_sml_table( 'keywords' );
		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, keyword, synonyms FROM `{$table}` WHERE post_id IN ({$placeholders})",
				$ids
			),
			ARRAY_A
		);
		// phpcs:enable

		$map = array();
		foreach ( (array) $rows as $row ) {
			$syn = json_decode( (string) $row['synonyms'], true );
			if ( ! is_array( $syn ) ) {
				$syn = array();
			}
			$syn = array_values( array_filter( array_map( 'strval', $syn ) ) );
			if ( empty( $syn ) ) {
				continue;
			}
			$map_key         = (int) $row['post_id'] . '|' . mb_strtolower( (string) $row['keyword'], 'UTF-8' );
			$map[ $map_key ] = $syn;
		}

		return $map;
	}

	/**
	 * Pick the anchor text for a new pair, rotating to a synonym when the default
	 * exact-match anchor is already over-used on this target.
	 *
	 * Returns the default anchor unchanged unless it already points to the target
	 * at least `$max_repeat` times AND a registered synonym both occurs in the
	 * source prose and is used fewer times toward that target. The least-used
	 * qualifying synonym wins, so anchors spread out instead of piling onto one
	 * exact phrase (search engines penalise exact-match over-optimisation).
	 *
	 * @since 1.0.0
	 * @param string   $plain_text     Plain-text source prose.
	 * @param string[] $synonyms       Synonym pool for the keyword.
	 * @param int      $target_id      Target post ID.
	 * @param string   $default_anchor Anchor the scanner produced (the matched phrase).
	 * @param int      $max_repeat     Repeat threshold that triggers rotation.
	 * @return string Chosen anchor.
	 */
	private static function rotate_anchor( $plain_text, array $synonyms, $target_id, $default_anchor, $max_repeat ) {
		$default_anchor = (string) $default_anchor;

		$base_use = self::anchor_usage( $target_id, $default_anchor );
		if ( $base_use < $max_repeat ) {
			return $default_anchor;
		}

		$default_lc = mb_strtolower( trim( $default_anchor ), 'UTF-8' );
		$best       = null;
		$best_use   = $base_use;

		foreach ( $synonyms as $syn ) {
			$syn = trim( (string) $syn );
			if ( '' === $syn || mb_strtolower( $syn, 'UTF-8' ) === $default_lc ) {
				continue;
			}
			if ( ! self::variant_in_prose( $plain_text, $syn ) ) {
				continue;
			}
			$use = self::anchor_usage( $target_id, $syn );
			if ( $use < $best_use ) {
				$best_use = $use;
				$best     = $syn;
			}
		}

		return null !== $best ? $best : $default_anchor;
	}

	/**
	 * Count how many links already carry a given anchor toward a target.
	 *
	 * Counts every non-rejected status (pending / approved / auto) so rotation
	 * also spreads anchors across a single Generate run: each INSERT commits
	 * before the next count, exactly like the auto-mode inbound cap.
	 *
	 * @since 1.0.0
	 * @param int    $target_id Target post ID.
	 * @param string $anchor    Anchor text.
	 * @return int
	 */
	private static function anchor_usage( $target_id, $anchor ) {
		global $wpdb;

		$target_id = (int) $target_id;
		$anchor    = trim( (string) $anchor );
		if ( $target_id <= 0 || '' === $anchor ) {
			return 0;
		}

		$table = mvweb_sml_table( 'links' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM `{$table}` WHERE target_id = %d AND anchor = %s AND status <> 'rejected'",
				$target_id,
				$anchor
			)
		);
		// phpcs:enable
	}

	/**
	 * Whether a keyword variant (morphology-aware) occurs in plain source prose.
	 *
	 * Reuses the same morphological pattern the scanner matches with, so a
	 * synonym is only chosen as an anchor when the render will actually find it.
	 *
	 * @since 1.0.0
	 * @param string $plain_text Plain-text source prose.
	 * @param string $variant    Keyword/synonym to test.
	 * @return bool
	 */
	private static function variant_in_prose( $plain_text, $variant ) {
		if ( '' === (string) $plain_text || ! class_exists( 'MVweb_SML_DOM_Scanner' ) ) {
			return false;
		}
		$pattern = MVweb_SML_DOM_Scanner::build_keyword_pattern( $variant );
		return '' !== $pattern && (bool) preg_match( $pattern, $plain_text );
	}

	/**
	 * Build the candidate list passed to the DOM scanner during the sweep.
	 *
	 * Pulls every keyword from `_keywords` whose post_id != source_id and
	 * builds one descriptor per (target, keyword) pair. Cross-CPT matrix and
	 * per-post opt-out are honoured so the suggestions never include
	 * forbidden pairs.
	 *
	 * @since 1.0.0
	 * @param int $source_id Source post ID.
	 * @return array<int, array<string, mixed>>
	 */
	private static function collect_sweep_candidates( $source_id ) {
		global $wpdb;

		$source_post = get_post( $source_id );
		if ( ! $source_post ) {
			return array();
		}
		$source_cpt   = $source_post->post_type;
		$cross_matrix = (array) mvweb_sml_get_setting( 'cross_cpt_matrix', array() );

		$keywords_table = mvweb_sml_table( 'keywords' );

		// Pull every (post_id, keyword) pair, excluding the source itself.
		// phpcs:disable WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT post_id, keyword FROM `{$keywords_table}` WHERE post_id <> %d ORDER BY id ASC",
				$source_id
			),
			ARRAY_A
		);
		// phpcs:enable

		$candidates = array();
		$seen       = array();

		foreach ( (array) $rows as $row ) {
			$target_id = (int) $row['post_id'];
			$keyword   = (string) $row['keyword'];

			if ( $target_id <= 0 || '' === $keyword ) {
				continue;
			}

			$kw_key = mb_strtolower( $keyword, 'UTF-8' );
			if ( isset( $seen[ $kw_key ] ) ) {
				// Scanner only links the first occurrence per keyword anyway.
				continue;
			}

			$target_post = get_post( $target_id );
			if ( ! $target_post || 'publish' !== $target_post->post_status ) {
				continue;
			}

			// Per-post opt-out on the target.
			if ( '1' === (string) get_post_meta( $target_id, '_mvweb_sml_disabled', true ) ) {
				continue;
			}

			// Cross-CPT matrix filter.
			if ( ! empty( $cross_matrix ) ) {
				$target_cpt = $target_post->post_type;
				if ( empty( $cross_matrix[ $source_cpt ][ $target_cpt ] ) ) {
					continue;
				}
			}

			$permalink = (string) get_permalink( $target_id );
			if ( '' === $permalink ) {
				continue;
			}

			$candidates[] = array(
				'target_id' => $target_id,
				'keyword'   => $keyword,
				'permalink' => $permalink,
				'priority'  => 20,
				'anchor'    => null,
				'title'     => $target_post->post_title,
			);

			$seen[ $kw_key ] = true;
		}

		return $candidates;
	}
}
