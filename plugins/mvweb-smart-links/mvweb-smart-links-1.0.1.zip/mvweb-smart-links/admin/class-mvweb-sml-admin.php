<?php
/**
 * Admin controller: settings page, asset enqueue, AJAX router.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin controller.
 *
 * Singleton-style: register hooks via `MVweb_SML_Admin::init()`.
 *
 * @since 1.0.0
 */
class MVweb_SML_Admin {

	/**
	 * Capability required for every admin action of this plugin.
	 *
	 * Editor role and above (TZ §16).
	 */
	const CAPABILITY = 'edit_others_posts';

	/**
	 * Plugin admin page slug.
	 */
	const PAGE_SLUG = 'mvweb-smart-links';

	/**
	 * Hook suffix returned by `add_submenu_page`, used to scope asset enqueue.
	 *
	 * @var string|false
	 */
	protected static $hook_suffix = false;

	/**
	 * Register all admin hooks.
	 *
	 * Called from the plugin entry point on `admin_init` (or directly,
	 * since this method itself only registers further hooks — safe at any
	 * priority before `admin_menu`).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 20 );
		add_action( 'admin_init', array( 'MVweb_SML_Settings', 'register' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );

		// Allow editors (not just administrators) to save the plugin option
		// group through wp-admin/options.php. Without this filter, options.php
		// requires the default `manage_options` capability and editors get a
		// "not allowed to manage options" error after submitting the form.
		add_filter(
			'option_page_capability_' . MVweb_SML_Settings::OPTION_GROUP,
			array( __CLASS__, 'option_page_capability' )
		);

		// Reindex AJAX endpoints (phase 5).
		add_action( 'wp_ajax_mvweb_sml_reindex_start', array( __CLASS__, 'ajax_reindex_start' ) );
		add_action( 'wp_ajax_mvweb_sml_reindex_step', array( __CLASS__, 'ajax_reindex_step' ) );
		add_action( 'wp_ajax_mvweb_sml_reindex_progress', array( __CLASS__, 'ajax_reindex_progress' ) );

		// Metabox AJAX endpoints (phase 6).
		add_action( 'wp_ajax_mvweb_sml_add_keyword', array( __CLASS__, 'ajax_add_keyword' ) );
		add_action( 'wp_ajax_mvweb_sml_update_keyword', array( __CLASS__, 'ajax_update_keyword' ) );
		add_action( 'wp_ajax_mvweb_sml_delete_keyword', array( __CLASS__, 'ajax_delete_keyword' ) );
		add_action( 'wp_ajax_mvweb_sml_suggest_keywords', array( __CLASS__, 'ajax_suggest_keywords' ) );
		add_action( 'wp_ajax_mvweb_sml_import_queries', array( __CLASS__, 'ajax_import_queries' ) );
		add_action( 'wp_ajax_mvweb_sml_search_posts', array( __CLASS__, 'ajax_search_posts' ) );

		// Cluster AJAX endpoints (phase 10).
		add_action( 'wp_ajax_mvweb_sml_cluster_list', array( __CLASS__, 'ajax_cluster_list' ) );
		add_action( 'wp_ajax_mvweb_sml_cluster_create', array( __CLASS__, 'ajax_cluster_create' ) );
		add_action( 'wp_ajax_mvweb_sml_cluster_delete', array( __CLASS__, 'ajax_cluster_delete' ) );
		add_action( 'wp_ajax_mvweb_sml_cluster_add_spoke', array( __CLASS__, 'ajax_cluster_add_spoke' ) );
		add_action( 'wp_ajax_mvweb_sml_cluster_remove_spoke', array( __CLASS__, 'ajax_cluster_remove_spoke' ) );
		add_action( 'wp_ajax_mvweb_sml_cluster_suggest_spokes', array( __CLASS__, 'ajax_cluster_suggest_spokes' ) );
		add_action( 'wp_ajax_mvweb_sml_cluster_apply_preset', array( __CLASS__, 'ajax_cluster_apply_preset' ) );

		// Reports CSV export endpoints (phase 11).
		add_action( 'admin_post_mvweb_sml_export_orphans', array( __CLASS__, 'export_orphans' ) );
		add_action( 'admin_post_mvweb_sml_export_stats', array( __CLASS__, 'export_stats' ) );
		add_action( 'admin_post_mvweb_sml_export_broken', array( __CLASS__, 'export_broken' ) );

		// SEO / CSV import-export endpoints (phase 12).
		add_action( 'wp_ajax_mvweb_sml_seo_detect', array( __CLASS__, 'ajax_seo_detect' ) );
		add_action( 'wp_ajax_mvweb_sml_seo_import', array( __CLASS__, 'ajax_seo_import' ) );
		add_action( 'wp_ajax_mvweb_sml_csv_import', array( __CLASS__, 'ajax_csv_import' ) );
		add_action( 'admin_post_mvweb_sml_csv_export', array( __CLASS__, 'csv_export' ) );

		// Notices dismiss (phase 11).
		add_action( 'wp_ajax_mvweb_sml_dismiss_notice', array( __CLASS__, 'ajax_dismiss_notice' ) );

		// Posts list column (phase 11).
		add_action( 'admin_init', array( __CLASS__, 'register_posts_columns' ) );
	}

	/**
	 * Hook the "Links" column on every supported post type.
	 *
	 * Runs on `admin_init` so that custom post types registered after
	 * `plugins_loaded` are available.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_posts_columns() {
		$post_types = mvweb_sml_supported_post_types();
		foreach ( $post_types as $type ) {
			add_filter( "manage_{$type}_posts_columns", array( __CLASS__, 'add_links_column' ) );
			add_action(
				"manage_{$type}_posts_custom_column",
				array( __CLASS__, 'render_links_column' ),
				10,
				2
			);
		}
	}

	/**
	 * Append the "Links" column to the post-list table.
	 *
	 * @since 1.0.0
	 * @param array $columns Existing columns map.
	 * @return array
	 */
	public static function add_links_column( $columns ) {
		if ( ! is_array( $columns ) ) {
			return array( 'mvweb_sml' => __( 'Links', 'mvweb-smart-links' ) );
		}
		$columns['mvweb_sml'] = __( 'Links', 'mvweb-smart-links' );
		return $columns;
	}

	/**
	 * Render the "Links" column cell. Cached per request to avoid issuing
	 * a separate query for every row.
	 *
	 * @since 1.0.0
	 * @param string $column  Column slug.
	 * @param int    $post_id Post ID.
	 * @return void
	 */
	public static function render_links_column( $column, $post_id ) {
		if ( 'mvweb_sml' !== $column ) {
			return;
		}

		static $cache = null;

		if ( null === $cache ) {
			$cache = self::collect_post_link_counts();
		}

		$out = isset( $cache['outgoing'][ (int) $post_id ] ) ? (int) $cache['outgoing'][ (int) $post_id ] : 0;
		$in  = isset( $cache['incoming'][ (int) $post_id ] ) ? (int) $cache['incoming'][ (int) $post_id ] : 0;

		$state = 'ok';
		if ( 0 === $in ) {
			$state = 'error';
		} elseif ( $in < 2 ) {
			$state = 'warning';
		}

		printf(
			'<span class="mvweb-sml-col-links mvweb-sml-col-links--%1$s">%2$s &rarr; / %3$s &larr;</span>',
			esc_attr( $state ),
			esc_html( (string) $out ),
			esc_html( (string) $in )
		);
	}

	/**
	 * Build incoming/outgoing maps once per request via Reports::link_stats().
	 *
	 * @since 1.0.0
	 * @return array{incoming:array<int,int>, outgoing:array<int,int>}
	 */
	private static function collect_post_link_counts() {
		$incoming = array();
		$outgoing = array();

		if ( ! class_exists( 'MVweb_SML_Reports' ) ) {
			return array(
				'incoming' => $incoming,
				'outgoing' => $outgoing,
			);
		}

		$stats = MVweb_SML_Reports::link_stats();
		if ( ! empty( $stats['rows'] ) ) {
			foreach ( $stats['rows'] as $row ) {
				$incoming[ (int) $row['post_id'] ] = (int) $row['incoming'];
				$outgoing[ (int) $row['post_id'] ] = (int) $row['outgoing'];
			}
		}

		return array(
			'incoming' => $incoming,
			'outgoing' => $outgoing,
		);
	}

	/**
	 * Shared guard for the CSV export endpoints.
	 *
	 * @since 1.0.0
	 * @param string $nonce_action Nonce action slug.
	 * @param string $nonce_field  Form field carrying the nonce.
	 * @return void
	 */
	private static function check_export_access( $nonce_action, $nonce_field ) {
		check_admin_referer( $nonce_action, $nonce_field );

		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die(
				esc_html__( 'You do not have permission to export this report.', 'mvweb-smart-links' ),
				'',
				array( 'response' => 403 )
			);
		}
	}

	/**
	 * Stream a CSV report to the browser.
	 *
	 * @since 1.0.0
	 * @param string                        $filename Suggested file name.
	 * @param array<int, string>            $headers  Header row (raw, not yet escaped).
	 * @param array<int, array<int, mixed>> $rows     Data rows.
	 * @return void
	 */
	private static function send_csv( $filename, array $headers, array $rows ) {
		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );

		// Streaming to php://output is the only sensible way to push CSV
		// to the browser — WP_Filesystem cannot drive a download response.
		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.WP.AlternativeFunctions.file_system_read_fopen
		$out = fopen( 'php://output', 'w' );
		if ( false === $out ) {
			wp_die( 'CSV stream open failed', '', array( 'response' => 500 ) );
		}

		// UTF-8 BOM so Excel renders Cyrillic correctly.
		echo "\xEF\xBB\xBF"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped

		$escaped_headers = array_map( 'mvweb_sml_csv_escape', $headers );
		fputcsv( $out, $escaped_headers );

		foreach ( $rows as $row ) {
			$escaped = array_map( 'mvweb_sml_csv_escape', $row );
			fputcsv( $out, $escaped );
		}

		// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
		fclose( $out );
		exit;
	}

	/**
	 * CSV export: orphan pages.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function export_orphans() {
		self::check_export_access( 'mvweb_sml_export_orphans', '_wpnonce_export_orphans' );

		$orphans = MVweb_SML_Reports::orphans( 5000 );
		$rows    = array();
		foreach ( $orphans as $post ) {
			$rows[] = array(
				$post->ID,
				get_the_title( $post ),
				$post->post_type,
				$post->post_date,
				get_permalink( $post ),
			);
		}

		self::send_csv(
			'mvweb-sml-orphans-' . gmdate( 'Y-m-d' ) . '.csv',
			array(
				__( 'ID', 'mvweb-smart-links' ),
				__( 'Title', 'mvweb-smart-links' ),
				__( 'Type', 'mvweb-smart-links' ),
				__( 'Date', 'mvweb-smart-links' ),
				__( 'URL', 'mvweb-smart-links' ),
			),
			$rows
		);
	}

	/**
	 * CSV export: per-post link stats.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function export_stats() {
		self::check_export_access( 'mvweb_sml_export_stats', '_wpnonce_export_stats' );

		$stats = MVweb_SML_Reports::link_stats();
		$rows  = array();
		foreach ( $stats['rows'] as $row ) {
			$rows[] = array(
				(int) $row['post_id'],
				get_the_title( $row['post_id'] ),
				(int) $row['incoming'],
				(int) $row['outgoing'],
			);
		}

		self::send_csv(
			'mvweb-sml-link-stats-' . gmdate( 'Y-m-d' ) . '.csv',
			array(
				__( 'Post ID', 'mvweb-smart-links' ),
				__( 'Title', 'mvweb-smart-links' ),
				__( 'Incoming', 'mvweb-smart-links' ),
				__( 'Outgoing', 'mvweb-smart-links' ),
			),
			$rows
		);
	}

	/**
	 * CSV export: broken links.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function export_broken() {
		self::check_export_access( 'mvweb_sml_export_broken', '_wpnonce_export_broken' );

		$broken = MVweb_SML_Reports::broken_links();
		$rows   = array();
		foreach ( $broken as $row ) {
			$rows[] = array(
				(int) $row['source_id'],
				get_the_title( $row['source_id'] ),
				(int) $row['target_id'],
				$row['origin'],
			);
		}

		self::send_csv(
			'mvweb-sml-broken-' . gmdate( 'Y-m-d' ) . '.csv',
			array(
				__( 'Source ID', 'mvweb-smart-links' ),
				__( 'Source title', 'mvweb-smart-links' ),
				__( 'Target ID', 'mvweb-smart-links' ),
				__( 'Created by', 'mvweb-smart-links' ),
			),
			$rows
		);
	}

	/**
	 * AJAX: dismiss a notice for the current user.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_dismiss_notice() {
		check_ajax_referer( 'mvweb_sml_admin', 'nonce' );

		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to dismiss notices.', 'mvweb-smart-links' ) ),
				403
			);
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$key = isset( $_POST['key'] ) ? sanitize_key( wp_unslash( $_POST['key'] ) ) : '';
		if ( '' === $key ) {
			wp_send_json_error(
				array( 'message' => __( 'Missing notice key.', 'mvweb-smart-links' ) ),
				400
			);
		}

		MVweb_SML_Notices::dismiss( $key, get_current_user_id() );
		wp_send_json_success();
	}

	/**
	 * Shared guard for every reindex AJAX endpoint.
	 *
	 * Verifies nonce and capability, terminates the request on failure.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function check_ajax_access() {
		check_ajax_referer( 'mvweb_sml_admin', 'nonce' );

		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to run reindex.', 'mvweb-smart-links' ) ),
				403
			);
		}
	}

	/**
	 * AJAX: queue every supported post for reindex.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_reindex_start() {
		self::check_ajax_access();

		$indexer = MVweb_SML_Indexer::get_instance();
		$total   = $indexer->mark_all_dirty();

		wp_send_json_success(
			array(
				'total'     => $total,
				'remaining' => $indexer->dirty_count(),
			)
		);
	}

	/**
	 * AJAX: process one batch.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_reindex_step() {
		self::check_ajax_access();

		// Runs under the same atomic lock as the cron indexer, so a manual
		// reindex and a background cron tick can never process the same dirty
		// rows twice. The completion hook (notice + corpus-words flush) fires
		// inside run_batch_locked() when the queue drains.
		$indexer = MVweb_SML_Indexer::get_instance();
		$result  = $indexer->run_batch_locked( MVweb_SML_Indexer::BATCH_SIZE );

		wp_send_json_success( $result );
	}

	/**
	 * AJAX: report current progress.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_reindex_progress() {
		self::check_ajax_access();

		$indexer = MVweb_SML_Indexer::get_instance();
		wp_send_json_success(
			array(
				'total'      => $indexer->total_count(),
				'dirty_left' => $indexer->dirty_count(),
			)
		);
	}

	/**
	 * Capability used by Settings API for our option group.
	 *
	 * @since 1.0.0
	 * @return string Capability slug.
	 */
	public static function option_page_capability() {
		return self::CAPABILITY;
	}

	/**
	 * Register the plugin submenu under MVweb Hub.
	 *
	 * Boilerplate already registers a page using a global function in the
	 * entry point. To avoid double registration, this method does nothing
	 * unless that function has been removed. Detection: we hook on
	 * `admin_menu` priority 20 (after the boilerplate priority 10) and
	 * check whether the page has already been registered.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_menu() {
		global $admin_page_hooks;

		// If the boilerplate function already registered the page, capture
		// its hook suffix and reuse it for asset scoping.
		if ( isset( $admin_page_hooks[ self::PAGE_SLUG ] ) ) {
			self::$hook_suffix = $admin_page_hooks[ self::PAGE_SLUG ];
			return;
		}

		$parent_slug = class_exists( 'MVweb_Menu' ) ? MVweb_Menu::get_menu_slug() : 'mvweb-hub';

		self::$hook_suffix = add_submenu_page(
			$parent_slug,
			__( 'Smart Links', 'mvweb-smart-links' ),
			__( 'Smart Links', 'mvweb-smart-links' ),
			self::CAPABILITY,
			self::PAGE_SLUG,
			array( __CLASS__, 'render_settings_page' )
		);
	}

	/**
	 * Render the plugin settings page wrapper.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_settings_page() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}

		include MVWEB_SML_PATH . 'admin/views/settings-page.php';
	}

	/**
	 * Enqueue admin assets only on the plugin page.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		$is_plugin_page = ( false !== strpos( (string) $hook, self::PAGE_SLUG ) );
		$is_post_edit   = self::is_post_edit_screen( $hook );

		if ( ! $is_plugin_page && ! $is_post_edit ) {
			return;
		}

		wp_enqueue_style(
			'mvweb-sml-admin-ui',
			MVWEB_SML_URL . 'admin/css/admin.min.css',
			array(),
			MVWEB_SML_VERSION
		);

		wp_enqueue_style(
			'mvweb-sml-admin-plugin',
			MVWEB_SML_URL . 'admin/css/plugin.min.css',
			array( 'mvweb-sml-admin-ui' ),
			MVWEB_SML_VERSION
		);

		wp_enqueue_script(
			'mvweb-sml-admin',
			MVWEB_SML_URL . 'admin/js/admin.min.js',
			array( 'jquery' ),
			MVWEB_SML_VERSION,
			true
		);

		wp_localize_script(
			'mvweb-sml-admin',
			'mvweb_sml_ajax',
			array(
				'ajax_url' => admin_url( 'admin-ajax.php' ),
				'nonce'    => wp_create_nonce( 'mvweb_sml_admin' ),
				'i18n'     => array(
					'confirm_delete'         => __( 'Are you sure you want to delete this item?', 'mvweb-smart-links' ),
					'saving'                 => __( 'Saving…', 'mvweb-smart-links' ),
					'saved'                  => __( 'Saved.', 'mvweb-smart-links' ),
					'error'                  => __( 'Something went wrong.', 'mvweb-smart-links' ),
					'reindex_running'        => __( 'Reindexing…', 'mvweb-smart-links' ),
					'reindex_complete'       => __( 'Reindex complete.', 'mvweb-smart-links' ),
					'reindex_empty'          => __( 'Nothing to reindex — no supported posts found.', 'mvweb-smart-links' ),
					'keyword_required'       => __( 'Keyword is required.', 'mvweb-smart-links' ),
					'no_suggestions'         => __( 'No suggestions found.', 'mvweb-smart-links' ),
					'q_empty'                => __( 'Paste at least one query.', 'mvweb-smart-links' ),
					/* translators: 1: imported count, 2: filtered-out count, 3: duplicate count. */
					'q_done'                 => __( 'Imported %1$d, skipped %2$d (outside filter), %3$d already present.', 'mvweb-smart-links' ),
					'conflict_prefix'        => __( 'Conflict: this keyword is also assigned to:', 'mvweb-smart-links' ),
					'no_results'             => __( 'No results.', 'mvweb-smart-links' ),
					'edit'                   => __( 'Edit', 'mvweb-smart-links' ),
					'save'                   => __( 'Save', 'mvweb-smart-links' ),
					'cancel'                 => __( 'Cancel', 'mvweb-smart-links' ),
					'delete'                 => __( 'Delete', 'mvweb-smart-links' ),
					'confirm_approve'        => __( 'Approve selected suggestions?', 'mvweb-smart-links' ),
					'confirm_reject'         => __( 'Reject selected suggestions?', 'mvweb-smart-links' ),
					'confirm_pending'        => __( 'Reset selected suggestions to pending?', 'mvweb-smart-links' ),
					'confirm_bulk_delete'    => __( 'Delete selected suggestions? This cannot be undone.', 'mvweb-smart-links' ),
					/* translators: %d: number of matching rows. */
					'confirm_all'            => __( 'Apply this action to all %d matching rows?', 'mvweb-smart-links' ),
					/* translators: %d: number of matching rows. */
					'confirm_all_delete'     => __( 'Delete all %d matching rows? This cannot be undone.', 'mvweb-smart-links' ),
					'confirm_generate'       => __( 'Generate suggestions for every supported post? This may take a while.', 'mvweb-smart-links' ),
					'no_selection'           => __( 'No items selected.', 'mvweb-smart-links' ),
					'no_action'              => __( 'Pick a bulk action.', 'mvweb-smart-links' ),
					'bulk_reset'             => __( 'Reset to pending', 'mvweb-smart-links' ),
					'bulk_delete'            => __( 'Delete', 'mvweb-smart-links' ),
					/* translators: %d: number of updated suggestion rows. */
					'bulk_done'              => __( 'Updated %d items.', 'mvweb-smart-links' ),
					'bulk_capped'            => __( 'Some matches remain — run it again to continue.', 'mvweb-smart-links' ),
					/* translators: %d: number of rows selected on the current page. */
					'selectall_page'         => __( 'All %d rows on this page are selected.', 'mvweb-smart-links' ),
					/* translators: %d: total number of rows matching the filters. */
					'selectall_pick'         => __( 'Select all %d matching rows', 'mvweb-smart-links' ),
					/* translators: %d: total number of rows matching the filters. */
					'selectall_all'          => __( 'All %d matching rows are selected.', 'mvweb-smart-links' ),
					'selectall_clear'        => __( 'Clear selection', 'mvweb-smart-links' ),
					'bulk_loading'           => __( 'Loading…', 'mvweb-smart-links' ),
					'bulk_empty'             => __( 'No suggestions match the current filters.', 'mvweb-smart-links' ),
					/* translators: 1: current page number, 2: total pages, 3: total item count. */
					'bulk_page'              => __( 'Page %1$d of %2$d (%3$d items)', 'mvweb-smart-links' ),
					/* translators: 1: processed posts, 2: total posts, 3: newly inserted pairs. */
					'generating'             => __( 'Generating suggestions… %1$d / %2$d posts processed (%3$d new pairs).', 'mvweb-smart-links' ),
					/* translators: 1: total posts processed, 2: total new pairs inserted. */
					'generate_done'          => __( 'Generation complete: %1$d posts processed, %2$d new pairs added.', 'mvweb-smart-links' ),
					'auto_preview_loading'   => __( 'Checking…', 'mvweb-smart-links' ),
					/* translators: 1: number of pending suggestions, 2: minimum relevance score. */
					'auto_preview_summary'   => __( '%1$d pending suggestions clear the threshold (score ≥ %2$d) and would be auto-approved without review.', 'mvweb-smart-links' ),
					/* translators: %d: number of additional suggestions not shown. */
					'auto_preview_more'      => __( '…and %d more.', 'mvweb-smart-links' ),
					'auto_preview_none'      => __( 'No pending suggestions meet the threshold yet.', 'mvweb-smart-links' ),
					'status_pending'         => __( 'Pending', 'mvweb-smart-links' ),
					'status_approved'        => __( 'Approved', 'mvweb-smart-links' ),
					'status_rejected'        => __( 'Rejected', 'mvweb-smart-links' ),
					'status_auto'            => __( 'Auto', 'mvweb-smart-links' ),
					'relevance_hint'         => __( 'Relevance score (shared topical words)', 'mvweb-smart-links' ),
					'anchor_pick_hint'       => __( 'Click a word to set the link anchor from the sentence.', 'mvweb-smart-links' ),
					/* translators: %d: how many links already use this anchor for the target. */
					'anchor_reuse_hint'      => __( 'This anchor already links to this target %d times — consider diversifying to avoid over-optimization', 'mvweb-smart-links' ),
					/* translators: %d: number of spokes. */
					'cluster_spokes'         => __( '%d spokes', 'mvweb-smart-links' ),
					/* translators: 1: spokes linking to the pillar, 2: total spokes. */
					'cluster_health'         => __( '%1$d / %2$d link to pillar', 'mvweb-smart-links' ),
					'cluster_no_clusters'    => __( 'No clusters yet. Create one above to get started.', 'mvweb-smart-links' ),
					'cluster_pillar'         => __( 'Pillar', 'mvweb-smart-links' ),
					'cluster_spokes_label'   => __( 'Spokes', 'mvweb-smart-links' ),
					'cluster_add_spoke'      => __( 'Add spoke', 'mvweb-smart-links' ),
					'cluster_suggest'        => __( 'Suggest spokes', 'mvweb-smart-links' ),
					'cluster_delete'         => __( 'Delete cluster', 'mvweb-smart-links' ),
					'cluster_remove_spoke'   => __( 'Remove', 'mvweb-smart-links' ),
					'cluster_confirm_del'    => __( 'Delete this cluster? Underlying contextual links remain untouched.', 'mvweb-smart-links' ),
					'cluster_preset_hub'     => __( 'Hub & spoke', 'mvweb-smart-links' ),
					'cluster_preset_silo'    => __( 'Reverse silo', 'mvweb-smart-links' ),
					'cluster_preset_confirm' => __( 'Create approved internal links for this cluster? Links render on the front end wherever the target keyword appears in the source text.', 'mvweb-smart-links' ),
					/* translators: 1: created links, 2: already-existing pairs, 3: pairs skipped for a missing keyword. */
					'cluster_preset_done'    => __( 'Created %1$d links (%2$d already existed, %3$d skipped — target has no keyword).', 'mvweb-smart-links' ),
					'cluster_pillar_req'     => __( 'Pick a pillar post first.', 'mvweb-smart-links' ),
					'cluster_no_spokes'      => __( 'No spokes yet.', 'mvweb-smart-links' ),
					'cluster_no_suggest'     => __( 'No spoke suggestions found.', 'mvweb-smart-links' ),
					'cluster_loading'        => __( 'Loading…', 'mvweb-smart-links' ),
					/* translators: %d: overlap score. */
					'cluster_score'          => __( 'score %d', 'mvweb-smart-links' ),
					'cluster_add'            => __( 'Add', 'mvweb-smart-links' ),
					'cluster_search_post'    => __( 'Search post…', 'mvweb-smart-links' ),
					/* translators: 1: yoast count, 2: rankmath count, 3: aioseo count. */
					'seo_detected'           => __( 'Detected — Yoast: %1$d, Rank Math: %2$d, AIOSEO: %3$d.', 'mvweb-smart-links' ),
					'seo_none'               => __( 'No focus keywords found for this source.', 'mvweb-smart-links' ),
					/* translators: 1: imported, 2: skipped, 3: total. */
					'seo_import_done'        => __( 'Import complete: %1$d imported, %2$d skipped (of %3$d).', 'mvweb-smart-links' ),
					'seo_importing'          => __( 'Importing…', 'mvweb-smart-links' ),
					'csv_pick_file'          => __( 'Pick a CSV file first.', 'mvweb-smart-links' ),
					'csv_importing'          => __( 'Importing CSV…', 'mvweb-smart-links' ),
					/* translators: 1: imported, 2: skipped, 3: errors. */
					'csv_import_done'        => __( 'CSV import complete: %1$d imported, %2$d skipped, %3$d errors.', 'mvweb-smart-links' ),
					'detecting'              => __( 'Detecting…', 'mvweb-smart-links' ),
				),
			)
		);
	}

	/**
	 * Detect whether the current admin screen is the post editor for a
	 * supported post type.
	 *
	 * @since 1.0.0
	 * @param string $hook Current hook suffix from admin_enqueue_scripts.
	 * @return bool
	 */
	private static function is_post_edit_screen( $hook ) {
		if ( 'post.php' !== $hook && 'post-new.php' !== $hook && 'edit.php' !== $hook ) {
			return false;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || empty( $screen->post_type ) ) {
			return false;
		}

		return in_array( $screen->post_type, mvweb_sml_supported_post_types(), true );
	}

	// ─────────────────────────────────────────────────────────────────────
	// Metabox AJAX endpoints (phase 6)
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Read and validate the post_id sent in the AJAX request.
	 *
	 * Per-post capability is checked via `edit_post`. Aborts the request
	 * (`wp_send_json_error`) on failure.
	 *
	 * @since 1.0.0
	 * @return int Validated post ID.
	 */
	private static function require_editable_post_id() {
		check_ajax_referer( 'mvweb_sml_admin', 'nonce' );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$post_id = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;
		if ( $post_id <= 0 ) {
			wp_send_json_error(
				array( 'message' => __( 'Invalid post ID.', 'mvweb-smart-links' ) ),
				400
			);
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to edit this post.', 'mvweb-smart-links' ) ),
				403
			);
		}

		return $post_id;
	}

	/**
	 * AJAX: add a keyword to a post.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_add_keyword() {
		$post_id = self::require_editable_post_id();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$keyword  = isset( $_POST['keyword'] ) ? sanitize_text_field( wp_unslash( $_POST['keyword'] ) ) : '';
		$synonyms = isset( $_POST['synonyms'] ) ? sanitize_text_field( wp_unslash( $_POST['synonyms'] ) ) : '';
		// phpcs:enable

		if ( '' === $keyword ) {
			wp_send_json_error(
				array( 'message' => __( 'Keyword is required.', 'mvweb-smart-links' ) ),
				400
			);
		}

		$id = MVweb_SML_Keyword_Manager::add( $post_id, $keyword, $synonyms, 'manual' );
		if ( ! $id ) {
			wp_send_json_error(
				array( 'message' => __( 'Failed to save keyword.', 'mvweb-smart-links' ) ),
				500
			);
		}

		$rows      = MVweb_SML_Keyword_Manager::get_for_post( $post_id );
		$conflicts = MVweb_SML_Keyword_Manager::conflicts_for_keyword( $keyword, $post_id );

		$conflict_data = array();
		foreach ( $conflicts as $cid ) {
			$conflict_data[] = array(
				'id'    => (int) $cid,
				'title' => (string) get_the_title( (int) $cid ),
			);
		}

		// A keyword change alters how other posts anchor-link to this target,
		// so the read-through linker/related caches are now stale.
		MVweb_SML_Cache::flush_all();

		wp_send_json_success(
			array(
				'id'        => (int) $id,
				'keywords'  => $rows,
				'conflicts' => $conflict_data,
			)
		);
	}

	/**
	 * AJAX: update an existing keyword.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_update_keyword() {
		$post_id = self::require_editable_post_id();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$id       = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;
		$keyword  = isset( $_POST['keyword'] ) ? sanitize_text_field( wp_unslash( $_POST['keyword'] ) ) : '';
		$synonyms = isset( $_POST['synonyms'] ) ? sanitize_text_field( wp_unslash( $_POST['synonyms'] ) ) : '';
		// phpcs:enable

		if ( $id <= 0 ) {
			wp_send_json_error(
				array( 'message' => __( 'Invalid keyword ID.', 'mvweb-smart-links' ) ),
				400
			);
		}

		if ( '' === $keyword ) {
			wp_send_json_error(
				array( 'message' => __( 'Keyword is required.', 'mvweb-smart-links' ) ),
				400
			);
		}

		$ok = MVweb_SML_Keyword_Manager::update(
			$id,
			$post_id,
			array(
				'keyword'  => $keyword,
				'synonyms' => $synonyms,
			)
		);

		if ( ! $ok ) {
			wp_send_json_error(
				array( 'message' => __( 'Failed to update keyword.', 'mvweb-smart-links' ) ),
				500
			);
		}

		MVweb_SML_Cache::flush_all();

		wp_send_json_success(
			array(
				'keywords' => MVweb_SML_Keyword_Manager::get_for_post( $post_id ),
			)
		);
	}

	/**
	 * AJAX: delete a keyword.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_delete_keyword() {
		$post_id = self::require_editable_post_id();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$id = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;
		if ( $id <= 0 ) {
			wp_send_json_error(
				array( 'message' => __( 'Invalid keyword ID.', 'mvweb-smart-links' ) ),
				400
			);
		}

		$ok = MVweb_SML_Keyword_Manager::delete( $id, $post_id );
		if ( ! $ok ) {
			wp_send_json_error(
				array( 'message' => __( 'Failed to delete keyword.', 'mvweb-smart-links' ) ),
				500
			);
		}

		MVweb_SML_Cache::flush_all();

		wp_send_json_success(
			array(
				'keywords' => MVweb_SML_Keyword_Manager::get_for_post( $post_id ),
			)
		);
	}

	/**
	 * AJAX: return suggested keywords for a post.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_suggest_keywords() {
		$post_id = self::require_editable_post_id();

		$suggestions = MVweb_SML_Keyword_Manager::suggest( $post_id, 10 );
		wp_send_json_success( array( 'suggestions' => array_values( $suggestions ) ) );
	}

	/**
	 * AJAX: import pasted search queries as keywords for a post.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_import_queries() {
		$post_id = self::require_editable_post_id();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$source          = isset( $_POST['source'] ) ? sanitize_key( wp_unslash( $_POST['source'] ) ) : 'gsc';
		$min_position    = isset( $_POST['min_position'] ) ? (float) $_POST['min_position'] : 0.0;
		$max_position    = isset( $_POST['max_position'] ) ? (float) $_POST['max_position'] : 100.0;
		$min_impressions = isset( $_POST['min_impressions'] ) ? absint( wp_unslash( $_POST['min_impressions'] ) ) : 0;
		// Raw query block — kept as multi-line text, sanitized per-field by the parser.
		$raw = isset( $_POST['queries'] ) ? sanitize_textarea_field( wp_unslash( $_POST['queries'] ) ) : '';
		// phpcs:enable

		if ( '' === trim( $raw ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Paste at least one query.', 'mvweb-smart-links' ) ),
				400
			);
		}

		if ( ! class_exists( 'MVweb_SML_Query_Import' ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Query import component is not available.', 'mvweb-smart-links' ) ),
				500
			);
		}

		$rows  = MVweb_SML_Query_Import::parse_rows( $raw );
		$stats = MVweb_SML_Query_Import::import_for_post(
			$post_id,
			$rows,
			$source,
			array(
				'min_position'    => $min_position,
				'max_position'    => $max_position,
				'min_impressions' => $min_impressions,
			)
		);

		// New keywords change how other posts anchor-link to this target.
		if ( $stats['imported'] > 0 ) {
			MVweb_SML_Cache::flush_all();
		}

		wp_send_json_success(
			array(
				'stats'    => $stats,
				'keywords' => MVweb_SML_Keyword_Manager::get_for_post( $post_id ),
			)
		);
	}

	/**
	 * AJAX: search supported posts for the manual-link autocomplete.
	 *
	 * Returns titles for posts whose title or content matches the term.
	 * Cap: edit_others_posts (autocomplete returns posts the editor does not
	 * necessarily own).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_search_posts() {
		check_ajax_referer( 'mvweb_sml_admin', 'nonce' );

		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to search posts.', 'mvweb-smart-links' ) ),
				403
			);
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$term    = isset( $_POST['term'] ) ? sanitize_text_field( wp_unslash( $_POST['term'] ) ) : '';
		$exclude = isset( $_POST['exclude'] ) ? absint( wp_unslash( $_POST['exclude'] ) ) : 0;
		// phpcs:enable

		if ( mb_strlen( $term, 'UTF-8' ) < 2 ) {
			wp_send_json_success( array( 'results' => array() ) );
		}

		$post_types = mvweb_sml_supported_post_types();
		if ( empty( $post_types ) ) {
			wp_send_json_success( array( 'results' => array() ) );
		}

		$query = new WP_Query(
			array(
				's'                   => $term,
				'post_type'           => $post_types,
				'post_status'         => 'publish',
				'posts_per_page'      => 20,
				'post__not_in'        => $exclude > 0 ? array( $exclude ) : array(),
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
				'orderby'             => 'relevance',
			)
		);

		$results = array();
		foreach ( $query->posts as $p ) {
			$results[] = array(
				'id'    => (int) $p->ID,
				'title' => (string) get_the_title( $p ),
				'type'  => (string) $p->post_type,
			);
		}

		wp_send_json_success( array( 'results' => $results ) );
	}

	// ─────────────────────────────────────────────────────────────────────
	// SEO import + CSV import/export endpoints (phase 12)
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Shared guard for every phase-12 import/export endpoint.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function check_import_access() {
		check_ajax_referer( 'mvweb_sml_admin', 'nonce' );

		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to run imports.', 'mvweb-smart-links' ) ),
				403
			);
		}
	}

	/**
	 * AJAX: detect how many posts have focus-keyword data for each SEO plugin.
	 *
	 * Response: `{ yoast: 12, rankmath: 5, aioseo: 0 }`.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_seo_detect() {
		self::check_import_access();

		wp_send_json_success(
			array(
				'counts' => MVweb_SML_SEO_Import::detect(),
			)
		);
	}

	/**
	 * AJAX: import focus keywords from Yoast / Rank Math / AIOSEO.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_seo_import() {
		self::check_import_access();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$source = isset( $_POST['source'] ) ? sanitize_key( wp_unslash( $_POST['source'] ) ) : '';
		if ( ! in_array( $source, array( 'yoast', 'rankmath', 'aioseo' ), true ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Unknown SEO source.', 'mvweb-smart-links' ) ),
				400
			);
		}

		// Raise execution limits on best-effort basis — large imports may
		// otherwise stall on shared hosting defaults.
		if ( function_exists( 'wp_raise_memory_limit' ) ) {
			wp_raise_memory_limit( 'admin' );
		}
		// phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged,WordPress.PHP.IniSet.Risky -- best-effort extension of execution time for large imports.
		@set_time_limit( 0 );

		$result = MVweb_SML_SEO_Import::import( $source );

		// Imported focus keywords change anchor resolution for their target
		// posts; flush once after the whole batch, not per row.
		MVweb_SML_Cache::flush_all();

		wp_send_json_success( $result );
	}

	/**
	 * AJAX: import keywords from an uploaded CSV file.
	 *
	 * Request is `multipart/form-data` with a single `file` field.
	 *
	 * Order of checks is critical:
	 *   1. Size check BEFORE wp_handle_upload — otherwise a gigabyte upload
	 *      hits disk I/O before being rejected.
	 *   2. Real MIME check via wp_check_filetype_and_ext.
	 *   3. Only then — wp_handle_upload to move the tmp file into uploads.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_csv_import() {
		self::check_import_access();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		if ( empty( $_FILES['file'] ) || ! is_array( $_FILES['file'] ) ) {
			wp_send_json_error(
				array( 'message' => __( 'No file uploaded.', 'mvweb-smart-links' ) ),
				400
			);
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized, WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$file = $_FILES['file'];

		$error = isset( $file['error'] ) ? (int) $file['error'] : UPLOAD_ERR_NO_FILE;
		if ( UPLOAD_ERR_OK !== $error ) {
			wp_send_json_error(
				array( 'message' => __( 'Upload failed.', 'mvweb-smart-links' ) ),
				400
			);
		}

		// 1. Size check BEFORE disk write.
		$size = isset( $file['size'] ) ? (int) $file['size'] : 0;
		if ( $size <= 0 || $size > 5 * MB_IN_BYTES ) {
			wp_send_json_error(
				array( 'message' => __( 'File too large (max 5 MB).', 'mvweb-smart-links' ) ),
				400
			);
		}

		// 2. Whitelist extensions + real MIME check.
		$allowed_mimes = array(
			'csv' => 'text/csv',
			'txt' => 'text/plain',
		);

		$tmp_name = isset( $file['tmp_name'] ) ? (string) $file['tmp_name'] : '';
		$name     = isset( $file['name'] ) ? sanitize_file_name( (string) $file['name'] ) : '';

		$checked = wp_check_filetype_and_ext( $tmp_name, $name, $allowed_mimes );
		if ( empty( $checked['ext'] ) || empty( $checked['type'] ) ) {
			wp_send_json_error(
				array( 'message' => __( 'Invalid file type. CSV only.', 'mvweb-smart-links' ) ),
				400
			);
		}

		// 3. wp_handle_upload — now safe to persist the file to disk.
		if ( ! function_exists( 'wp_handle_upload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		$overrides = array(
			'test_form' => false,
			'mimes'     => $allowed_mimes,
		);

		$upload = wp_handle_upload( $file, $overrides );
		if ( isset( $upload['error'] ) ) {
			wp_send_json_error(
				array( 'message' => (string) $upload['error'] ),
				400
			);
		}

		$result = MVweb_SML_CSV::import( $upload['file'] );

		// Always remove the temporary upload — even on partial success.
		if ( ! empty( $upload['file'] ) && file_exists( $upload['file'] ) ) {
			wp_delete_file( $upload['file'] );
		}

		// Imported keywords change anchor resolution for their target posts;
		// flush once after the whole batch, not per row.
		MVweb_SML_Cache::flush_all();

		wp_send_json_success( $result );
	}

	/**
	 * Admin-post: export every keyword row as a CSV download.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function csv_export() {
		check_admin_referer( 'mvweb_sml_csv_export', '_wpnonce_csv_export' );

		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_die(
				esc_html__( 'You do not have permission to export this report.', 'mvweb-smart-links' ),
				'',
				array( 'response' => 403 )
			);
		}

		MVweb_SML_CSV::export();
	}

	// ─────────────────────────────────────────────────────────────────────
	// Cluster AJAX endpoints (phase 10)
	// ─────────────────────────────────────────────────────────────────────

	/**
	 * Shared guard for every cluster AJAX endpoint.
	 *
	 * Verifies nonce and the global plugin capability. Aborts on failure.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function check_cluster_access() {
		check_ajax_referer( 'mvweb_sml_admin', 'nonce' );

		if ( ! current_user_can( self::CAPABILITY ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to manage clusters.', 'mvweb-smart-links' ) ),
				403
			);
		}
	}

	/**
	 * Guard an existing cluster against IDOR: verify the cluster exists and
	 * that the current user can edit the pillar post it is attached to.
	 *
	 * Complements {@see check_cluster_access()}, which only validates the
	 * nonce and the global capability. Always call AFTER that guard.
	 *
	 * @since 1.0.0
	 * @param int $cluster_id Cluster ID from the request.
	 * @return array Cluster row (never returns when guard fails — sends JSON error).
	 */
	private static function require_editable_cluster( $cluster_id ) {
		$cluster_id = (int) $cluster_id;
		if ( $cluster_id <= 0 ) {
			wp_send_json_error(
				array( 'message' => __( 'Invalid cluster ID.', 'mvweb-smart-links' ) ),
				400
			);
		}

		$cluster = MVweb_SML_Cluster_Manager::get_cluster( $cluster_id );
		if ( ! $cluster ) {
			wp_send_json_error(
				array( 'message' => __( 'Cluster not found.', 'mvweb-smart-links' ) ),
				404
			);
		}

		if ( ! current_user_can( 'edit_post', (int) $cluster['pillar_id'] ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to edit this cluster.', 'mvweb-smart-links' ) ),
				403
			);
		}

		return $cluster;
	}

	/**
	 * AJAX: list every cluster with its spokes and health metrics.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_cluster_list() {
		self::check_cluster_access();

		wp_send_json_success(
			array(
				'clusters' => MVweb_SML_Cluster_Manager::get_all(),
			)
		);
	}

	/**
	 * AJAX: create a new cluster around the supplied pillar post.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_cluster_create() {
		self::check_cluster_access();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$pillar_id = isset( $_POST['pillar_id'] ) ? absint( wp_unslash( $_POST['pillar_id'] ) ) : 0;
		$name      = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
		// phpcs:enable

		if ( $pillar_id <= 0 ) {
			wp_send_json_error(
				array( 'message' => __( 'Pick a pillar post first.', 'mvweb-smart-links' ) ),
				400
			);
		}

		if ( ! current_user_can( 'edit_post', $pillar_id ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to edit this post.', 'mvweb-smart-links' ) ),
				403
			);
		}

		$result = MVweb_SML_Cluster_Manager::create_cluster( $pillar_id, $name );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array( 'message' => $result->get_error_message() ),
				400
			);
		}

		// Cluster membership feeds the "related" block, whose per-post output
		// is cached read-through — invalidate it after any structural change.
		MVweb_SML_Cache::flush_all();

		wp_send_json_success(
			array(
				'cluster_id' => (int) $result,
				'clusters'   => MVweb_SML_Cluster_Manager::get_all(),
			)
		);
	}

	/**
	 * AJAX: delete a cluster (links in `_links` are kept).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_cluster_delete() {
		self::check_cluster_access();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$cluster_id = isset( $_POST['cluster_id'] ) ? absint( wp_unslash( $_POST['cluster_id'] ) ) : 0;
		self::require_editable_cluster( $cluster_id );

		$ok = MVweb_SML_Cluster_Manager::delete_cluster( $cluster_id );
		if ( ! $ok ) {
			wp_send_json_error(
				array( 'message' => __( 'Failed to delete cluster.', 'mvweb-smart-links' ) ),
				500
			);
		}

		MVweb_SML_Cache::flush_all();

		wp_send_json_success(
			array(
				'clusters' => MVweb_SML_Cluster_Manager::get_all(),
			)
		);
	}

	/**
	 * AJAX: add a spoke to a cluster.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_cluster_add_spoke() {
		self::check_cluster_access();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$cluster_id = isset( $_POST['cluster_id'] ) ? absint( wp_unslash( $_POST['cluster_id'] ) ) : 0;
		$post_id    = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;
		// phpcs:enable

		self::require_editable_cluster( $cluster_id );

		if ( $post_id <= 0 ) {
			wp_send_json_error(
				array( 'message' => __( 'Invalid post ID.', 'mvweb-smart-links' ) ),
				400
			);
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to add this post as a spoke.', 'mvweb-smart-links' ) ),
				403
			);
		}

		$ok = MVweb_SML_Cluster_Manager::add_spoke( $cluster_id, $post_id );
		if ( ! $ok ) {
			wp_send_json_error(
				array( 'message' => __( 'Failed to add spoke.', 'mvweb-smart-links' ) ),
				500
			);
		}

		MVweb_SML_Cache::flush_all();

		wp_send_json_success(
			array(
				'clusters' => MVweb_SML_Cluster_Manager::get_all(),
			)
		);
	}

	/**
	 * AJAX: remove a spoke from a cluster.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_cluster_remove_spoke() {
		self::check_cluster_access();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$cluster_id = isset( $_POST['cluster_id'] ) ? absint( wp_unslash( $_POST['cluster_id'] ) ) : 0;
		$post_id    = isset( $_POST['post_id'] ) ? absint( wp_unslash( $_POST['post_id'] ) ) : 0;
		// phpcs:enable

		self::require_editable_cluster( $cluster_id );

		if ( $post_id <= 0 ) {
			wp_send_json_error(
				array( 'message' => __( 'Invalid post ID.', 'mvweb-smart-links' ) ),
				400
			);
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			wp_send_json_error(
				array( 'message' => __( 'You are not allowed to remove this spoke.', 'mvweb-smart-links' ) ),
				403
			);
		}

		$ok = MVweb_SML_Cluster_Manager::remove_spoke( $cluster_id, $post_id );
		if ( ! $ok ) {
			wp_send_json_error(
				array( 'message' => __( 'Failed to remove spoke.', 'mvweb-smart-links' ) ),
				500
			);
		}

		MVweb_SML_Cache::flush_all();

		wp_send_json_success(
			array(
				'clusters' => MVweb_SML_Cluster_Manager::get_all(),
			)
		);
	}

	/**
	 * AJAX: suggest spoke candidates for a cluster.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_cluster_suggest_spokes() {
		self::check_cluster_access();

		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$cluster_id = isset( $_POST['cluster_id'] ) ? absint( wp_unslash( $_POST['cluster_id'] ) ) : 0;
		self::require_editable_cluster( $cluster_id );

		$suggestions = MVweb_SML_Cluster_Manager::suggest_spokes( $cluster_id, 10 );
		wp_send_json_success( array( 'suggestions' => $suggestions ) );
	}

	/**
	 * AJAX: apply an interlinking preset (hub-and-spoke / reverse silo) to a
	 * whole cluster.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function ajax_cluster_apply_preset() {
		self::check_cluster_access();

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		$cluster_id = isset( $_POST['cluster_id'] ) ? absint( wp_unslash( $_POST['cluster_id'] ) ) : 0;
		$preset     = isset( $_POST['preset'] ) ? sanitize_key( wp_unslash( $_POST['preset'] ) ) : '';
		// phpcs:enable

		self::require_editable_cluster( $cluster_id );

		$result = MVweb_SML_Cluster_Manager::apply_preset( $cluster_id, $preset );
		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array( 'message' => $result->get_error_message() ),
				400
			);
		}

		// New approved pairs change front-end rendering — flush the read-through
		// cache so the links appear without waiting for the TTL.
		if ( $result['created'] > 0 && class_exists( 'MVweb_SML_Cache' ) ) {
			MVweb_SML_Cache::flush_all();
		}

		wp_send_json_success(
			array(
				'stats'    => $result,
				'clusters' => MVweb_SML_Cluster_Manager::get_all(),
			)
		);
	}
}
