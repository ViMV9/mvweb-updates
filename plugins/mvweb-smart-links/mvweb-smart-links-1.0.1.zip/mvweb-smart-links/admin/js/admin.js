/**
 * Admin JavaScript for MVweb Smart Links
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

(function($) {
	'use strict';

	/**
	 * Tab navigation without page reload.
	 */
	function initTabs() {
		var $tabs = $('.mvweb-nav .mvweb-nav__link');
		var $contents = $('.mvweb-tab-content');

		$tabs.on('click', function(e) {
			e.preventDefault();

			var $this = $(this);
			var tabId = $this.data('tab');

			// Update active tab.
			$tabs.removeClass('mvweb-nav__link--active');
			$this.addClass('mvweb-nav__link--active');

			// Show corresponding content.
			$contents.removeClass('active');
			$('#' + tabId).addClass('active');

			// Update URL hash without scrolling.
			if (history.pushState) {
				history.pushState(null, null, '#' + tabId);
			}
		});

		// In-content links (e.g. the Dashboard "Next step" CTA) that jump to
		// another tab reuse the same switch as the sidebar nav.
		$(document).on('click', '.mvweb-sml-goto-tab', function(e) {
			e.preventDefault();
			var target = $(this).data('tab');
			$tabs.filter('[data-tab="' + target + '"]').trigger('click');
		});

		// Activate tab from URL hash.
		var hash = window.location.hash.substring(1);
		if (hash && $('#' + hash).length) {
			$tabs.filter('[data-tab="' + hash + '"]').trigger('click');
		}
	}

	/**
	 * Reindex Maintenance widget — drives the AJAX pipeline
	 * (start → step loop → done) and updates the progress bar.
	 */
	function initReindex() {
		var $btn = $('#mvweb-sml-reindex');
		if (!$btn.length) {
			return;
		}

		var $progress = $('.mvweb-sml-reindex__progress');
		var $bar = $('.mvweb-sml-reindex__bar');
		var $status = $('.mvweb-sml-reindex__status');

		var i18n = (window.mvweb_sml_ajax && mvweb_sml_ajax.i18n) || {};

		function setStatus(text) {
			$status.text(text || '');
		}

		function setProgress(percent) {
			$bar.css('width', Math.max(0, Math.min(100, percent)) + '%');
		}

		function fail(message) {
			$btn.prop('disabled', false);
			setStatus(message || i18n.error || 'Error');
		}

		function step(total) {
			$.post(mvweb_sml_ajax.ajax_url, {
				action: 'mvweb_sml_reindex_step',
				nonce: mvweb_sml_ajax.nonce
			}).done(function(response) {
				if (!response || !response.success) {
					fail(response && response.data && response.data.message);
					return;
				}

				var remaining = parseInt(response.data.remaining, 10) || 0;
				var done = Math.max(0, total - remaining);
				var percent = total > 0 ? Math.round((done / total) * 100) : 100;
				setProgress(percent);
				setStatus(i18n.reindex_running + ' ' + done + ' / ' + total);

				if (remaining > 0) {
					step(total);
				} else {
					setProgress(100);
					setStatus(i18n.reindex_complete || 'Done');
					$btn.prop('disabled', false);
				}
			}).fail(function() {
				fail();
			});
		}

		$btn.on('click', function(e) {
			e.preventDefault();

			$btn.prop('disabled', true);
			$progress.show();
			setProgress(0);
			setStatus(i18n.reindex_running || 'Reindexing…');

			$.post(mvweb_sml_ajax.ajax_url, {
				action: 'mvweb_sml_reindex_start',
				nonce: mvweb_sml_ajax.nonce
			}).done(function(response) {
				if (!response || !response.success) {
					fail(response && response.data && response.data.message);
					return;
				}

				var total = parseInt(response.data.total, 10) || 0;
				if (total <= 0) {
					setProgress(100);
					setStatus(i18n.reindex_empty || i18n.reindex_complete || 'Done');
					$btn.prop('disabled', false);
					return;
				}

				step(total);
			}).fail(function() {
				fail();
			});
		});
	}

	/**
	 * Editor metabox: mini-tabs, keyword CRUD, suggestions,
	 * manual-link autocomplete.
	 */
	function initMetabox() {
		var $metabox = $('.mvweb-sml-metabox');
		if (!$metabox.length) {
			return;
		}

		var ajax = window.mvweb_sml_ajax || {};
		var i18n = ajax.i18n || {};
		var postId = parseInt($metabox.data('post-id'), 10) || 0;

		// ── Mini-tabs ─────────────────────────────────────────────
		$metabox.on('click', '.mvweb-sml-metabox__tab', function(e) {
			e.preventDefault();
			var $btn = $(this);
			var target = $btn.data('tab');
			$metabox.find('.mvweb-sml-metabox__tab').removeClass('is-active');
			$btn.addClass('is-active');
			$metabox.find('.mvweb-sml-metabox__panel').removeClass('is-active');
			$metabox.find('.mvweb-sml-metabox__panel[data-panel="' + target + '"]').addClass('is-active');
		});

		// ── Notice helper ─────────────────────────────────────────
		function showNotice($container, message, type) {
			$container
				.removeClass('is-error is-warning is-success')
				.addClass('is-' + (type || 'success'))
				.text(message)
				.show();
		}

		function hideNotice($container) {
			$container.hide().empty();
		}

		// ── Render keyword rows from server response ──────────────
		function renderKeywordRows(rows) {
			var $tbody = $metabox.find('.mvweb-sml-metabox__kw-list');
			$tbody.empty();
			if (!rows || !rows.length) {
				$tbody.append(
					'<tr class="mvweb-sml-metabox__empty"><td colspan="4">' +
					escapeHtml(i18n.no_results || 'No keywords yet.') +
					'</td></tr>'
				);
				return;
			}
			$.each(rows, function(_, row) {
				var synonyms = (row.synonyms || []).join(', ');
				var $tr = $('<tr class="mvweb-sml-metabox__kw-row" />').attr('data-id', row.id);
				$tr.append('<td class="mvweb-sml-metabox__kw-cell" data-field="keyword"><span class="mvweb-sml-metabox__kw-text"></span></td>');
				$tr.append('<td class="mvweb-sml-metabox__kw-cell" data-field="synonyms"><span class="mvweb-sml-metabox__kw-text"></span></td>');
				$tr.append('<td></td>');
				$tr.append(
					'<td class="mvweb-sml-metabox__col-actions">' +
					'<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-sml-metabox__kw-edit"></button> ' +
					'<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-sml-metabox__kw-delete"></button>' +
					'</td>'
				);
				$tr.find('[data-field="keyword"] .mvweb-sml-metabox__kw-text').text(row.keyword);
				$tr.find('[data-field="synonyms"] .mvweb-sml-metabox__kw-text').text(synonyms);
				$tr.find('td').eq(2).text(row.source);
				$tr.find('.mvweb-sml-metabox__kw-edit').text(i18n.edit || 'Edit');
				$tr.find('.mvweb-sml-metabox__kw-delete').text(i18n.delete || 'Delete');
				$tbody.append($tr);
			});
		}

		function escapeHtml(str) {
			return $('<div/>').text(str == null ? '' : String(str)).html();
		}

		// ── Add keyword ──────────────────────────────────────────
		$metabox.on('click', '.mvweb-sml-metabox__add-btn', function(e) {
			e.preventDefault();
			var $kw = $metabox.find('.mvweb-sml-metabox__add-keyword');
			var $syn = $metabox.find('.mvweb-sml-metabox__add-synonyms');
			var $notice = $metabox.find('.mvweb-sml-metabox__notice');
			var keyword = $.trim($kw.val() || '');
			var synonyms = $.trim($syn.val() || '');

			if (!keyword) {
				showNotice($notice, i18n.keyword_required || 'Keyword is required.', 'error');
				return;
			}

			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_add_keyword',
				nonce: ajax.nonce,
				post_id: postId,
				keyword: keyword,
				synonyms: synonyms
			}).done(function(response) {
				if (!response || !response.success) {
					showNotice($notice, (response && response.data && response.data.message) || i18n.error, 'error');
					return;
				}
				$kw.val('');
				$syn.val('');
				renderKeywordRows(response.data.keywords);

				if (response.data.conflicts && response.data.conflicts.length) {
					var titles = $.map(response.data.conflicts, function(c) { return c.title || ('#' + c.id); });
					showNotice($notice, (i18n.conflict_prefix || 'Conflict:') + ' ' + titles.join(', '), 'warning');
				} else {
					showNotice($notice, i18n.saved || 'Saved.', 'success');
					setTimeout(function() { hideNotice($notice); }, 2000);
				}
			}).fail(function() {
				showNotice($notice, i18n.error || 'Error', 'error');
			});
		});

		// ── Delete keyword ───────────────────────────────────────
		$metabox.on('click', '.mvweb-sml-metabox__kw-delete', function(e) {
			e.preventDefault();
			var $row = $(this).closest('.mvweb-sml-metabox__kw-row');
			var id = parseInt($row.data('id'), 10) || 0;
			if (!id) { return; }
			if (i18n.confirm_delete && !window.confirm(i18n.confirm_delete)) {
				return;
			}
			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_delete_keyword',
				nonce: ajax.nonce,
				post_id: postId,
				id: id
			}).done(function(response) {
				if (response && response.success) {
					renderKeywordRows(response.data.keywords);
				}
			});
		});

		// ── Inline-edit keyword ──────────────────────────────────
		$metabox.on('click', '.mvweb-sml-metabox__kw-edit', function(e) {
			e.preventDefault();
			var $row = $(this).closest('.mvweb-sml-metabox__kw-row');
			var id = parseInt($row.data('id'), 10) || 0;
			if (!id) { return; }

			var $kwCell = $row.find('[data-field="keyword"]');
			var $synCell = $row.find('[data-field="synonyms"]');
			var currentKw = $kwCell.find('.mvweb-sml-metabox__kw-text').text();
			var currentSyn = $synCell.find('.mvweb-sml-metabox__kw-text').text();

			$row.data('original-keyword', currentKw);
			$row.data('original-synonyms', currentSyn);

			$kwCell.html('<input type="text" class="mvweb-input mvweb-sml-metabox__edit-keyword" />');
			$synCell.html('<input type="text" class="mvweb-input mvweb-sml-metabox__edit-synonyms" />');
			$kwCell.find('input').val(currentKw).trigger('focus');
			$synCell.find('input').val(currentSyn);

			var $actions = $row.find('.mvweb-sml-metabox__col-actions');
			$actions.html(
				'<button type="button" class="mvweb-btn mvweb-btn--primary mvweb-btn--sm mvweb-sml-metabox__kw-save"></button> ' +
				'<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-sml-metabox__kw-cancel"></button>'
			);
			$actions.find('.mvweb-sml-metabox__kw-save').text(i18n.save || 'Save');
			$actions.find('.mvweb-sml-metabox__kw-cancel').text(i18n.cancel || 'Cancel');
		});

		$metabox.on('click', '.mvweb-sml-metabox__kw-cancel', function(e) {
			e.preventDefault();
			var $row = $(this).closest('.mvweb-sml-metabox__kw-row');
			var origKw = $row.data('original-keyword') || '';
			var origSyn = $row.data('original-synonyms') || '';

			var $kwCell = $row.find('[data-field="keyword"]');
			var $synCell = $row.find('[data-field="synonyms"]');
			$kwCell.html('<span class="mvweb-sml-metabox__kw-text"></span>');
			$synCell.html('<span class="mvweb-sml-metabox__kw-text"></span>');
			$kwCell.find('span').text(origKw);
			$synCell.find('span').text(origSyn);

			var $actions = $row.find('.mvweb-sml-metabox__col-actions');
			$actions.html(
				'<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-sml-metabox__kw-edit"></button> ' +
				'<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-sml-metabox__kw-delete"></button>'
			);
			$actions.find('.mvweb-sml-metabox__kw-edit').text(i18n.edit || 'Edit');
			$actions.find('.mvweb-sml-metabox__kw-delete').text(i18n.delete || 'Delete');
		});

		$metabox.on('click', '.mvweb-sml-metabox__kw-save', function(e) {
			e.preventDefault();
			var $row = $(this).closest('.mvweb-sml-metabox__kw-row');
			var id = parseInt($row.data('id'), 10) || 0;
			if (!id) { return; }
			var keyword = $row.find('.mvweb-sml-metabox__edit-keyword').val();
			var synonyms = $row.find('.mvweb-sml-metabox__edit-synonyms').val();

			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_update_keyword',
				nonce: ajax.nonce,
				post_id: postId,
				id: id,
				keyword: keyword,
				synonyms: synonyms
			}).done(function(response) {
				if (response && response.success) {
					renderKeywordRows(response.data.keywords);
				}
			});
		});

		// ── Suggest keywords ────────────────────────────────────
		$metabox.on('click', '.mvweb-sml-metabox__suggest-btn', function(e) {
			e.preventDefault();
			var $box = $metabox.find('.mvweb-sml-metabox__suggestions');
			var $list = $box.find('.mvweb-sml-metabox__suggestion-list');
			$list.empty();
			$box.show();

			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_suggest_keywords',
				nonce: ajax.nonce,
				post_id: postId
			}).done(function(response) {
				if (!response || !response.success) {
					$list.append('<li>' + escapeHtml(i18n.error) + '</li>');
					return;
				}
				var suggestions = response.data.suggestions || [];
				if (!suggestions.length) {
					$list.append('<li>' + escapeHtml(i18n.no_suggestions || 'No suggestions found.') + '</li>');
					return;
				}
				$.each(suggestions, function(_, word) {
					var $li = $('<li><button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-sml-metabox__suggestion"></button></li>');
					$li.find('button').text(word);
					$list.append($li);
				});
			});
		});

		$metabox.on('click', '.mvweb-sml-metabox__suggestion', function(e) {
			e.preventDefault();
			var word = $(this).text();
			$metabox.find('.mvweb-sml-metabox__add-keyword').val(word);
			$metabox.find('.mvweb-sml-metabox__add-btn').trigger('click');
		});

		$metabox.on('click', '.mvweb-sml-metabox__q-import-btn', function(e) {
			e.preventDefault();
			var $btn = $(this);
			var $notice = $metabox.find('.mvweb-sml-metabox__q-notice');
			var raw = $.trim($metabox.find('.mvweb-sml-metabox__q-text').val() || '');
			if (!raw) {
				showNotice($notice, i18n.q_empty || 'Paste at least one query.', 'error');
				return;
			}
			$btn.prop('disabled', true);
			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_import_queries',
				nonce: ajax.nonce,
				post_id: postId,
				source: $metabox.find('.mvweb-sml-metabox__q-source').val(),
				min_position: $metabox.find('.mvweb-sml-metabox__q-minpos').val(),
				max_position: $metabox.find('.mvweb-sml-metabox__q-maxpos').val(),
				min_impressions: $metabox.find('.mvweb-sml-metabox__q-minimpr').val(),
				queries: raw
			}).done(function(response) {
				if (!response || !response.success) {
					showNotice($notice, (response && response.data && response.data.message) || i18n.error, 'error');
					return;
				}
				var s = response.data.stats || {};
				renderKeywordRows(response.data.keywords);
				$metabox.find('.mvweb-sml-metabox__q-text').val('');
				var tpl = i18n.q_done || 'Imported %1$d, skipped %2$d (filtered), %3$d duplicates.';
				var msg = tpl.replace('%1$d', s.imported || 0).replace('%2$d', s.skipped_filter || 0).replace('%3$d', s.skipped_dup || 0);
				showNotice($notice, msg, (s.imported > 0) ? 'success' : 'warning');
			}).fail(function() {
				showNotice($notice, i18n.error || 'Error', 'error');
			}).always(function() {
				$btn.prop('disabled', false);
			});
		});

		// ── Manual link autocomplete (debounced) ───────────────
		var searchTimer = null;
		$metabox.on('input', '.mvweb-sml-metabox__search', function() {
			var $input = $(this);
			var $results = $metabox.find('.mvweb-sml-metabox__search-results');
			var term = $.trim($input.val() || '');

			if (searchTimer) { clearTimeout(searchTimer); }

			if (term.length < 2) {
				$results.hide().empty();
				return;
			}

			searchTimer = setTimeout(function() {
				$.post(ajax.ajax_url, {
					action: 'mvweb_sml_search_posts',
					nonce: ajax.nonce,
					term: term,
					exclude: postId
				}).done(function(response) {
					$results.empty();
					if (!response || !response.success) {
						return;
					}
					var rows = response.data.results || [];
					if (!rows.length) {
						$results.append('<li class="mvweb-sml-metabox__search-empty">' + escapeHtml(i18n.no_results || 'No results.') + '</li>').show();
						return;
					}
					$.each(rows, function(_, row) {
						var $li = $('<li class="mvweb-sml-metabox__search-result" />').attr('data-id', row.id);
						$li.text(row.title + ' (' + row.type + ')');
						$results.append($li);
					});
					$results.show();
				});
			}, 300);
		});

		$metabox.on('click', '.mvweb-sml-metabox__search-result', function() {
			var id = parseInt($(this).data('id'), 10) || 0;
			if (!id) { return; }
			var title = $(this).text();
			var $list = $metabox.find('.mvweb-sml-metabox__manual-list');

			// De-dup.
			if ($list.find('.mvweb-sml-metabox__manual-item[data-id="' + id + '"]').length) {
				return;
			}

			var $item = $(
				'<li class="mvweb-sml-metabox__manual-item">' +
				'<input type="hidden" name="mvweb_sml_manual_targets[]" />' +
				'<span class="mvweb-sml-metabox__manual-title"></span> ' +
				'<span class="mvweb-badge mvweb-badge--plain mvweb-sml-metabox__manual-flag"></span> ' +
				'<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-sml-metabox__manual-remove">&times;</button>' +
				'</li>'
			);
			$item.attr('data-id', id);
			$item.find('input').val(id);
			$item.find('.mvweb-sml-metabox__manual-title').text(title);
			$item.find('.mvweb-sml-metabox__manual-flag').text(i18n.manual_unsaved || 'Save to check');
			$list.append($item);

			$metabox.find('.mvweb-sml-metabox__search').val('');
			$metabox.find('.mvweb-sml-metabox__search-results').hide().empty();
		});

		$metabox.on('click', '.mvweb-sml-metabox__manual-remove', function(e) {
			e.preventDefault();
			$(this).closest('.mvweb-sml-metabox__manual-item').remove();
		});
	}

	/**
	 * Bulk suggestions table on the Keywords tab (phase 9).
	 *
	 * Handles AJAX paginated listing, filters, inline anchor editing, bulk
	 * approve/reject and the "Generate suggestions" sweep driver.
	 */
	function initBulk() {
		var $root = $('.mvweb-sml-bulk');
		if (!$root.length) {
			return;
		}

		var ajax = window.mvweb_sml_ajax || {};
		var i18n = ajax.i18n || {};

		var state = {
			page: 1,
			perPage: 25,
			pages: 0,
			total: 0,
			items: [],
			selectAllMatching: false,
			orderby: 'id',
			order: 'DESC'
		};

		var ICON_CHECK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="20 6 9 17 4 12"/></svg>';
		var ICON_X = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>';

		var $tbody = $root.find('.mvweb-sml-bulk__tbody');
		var $pageInfo = $root.find('.mvweb-sml-bulk__page-info');
		var $prev = $root.find('.mvweb-sml-bulk__prev');
		var $next = $root.find('.mvweb-sml-bulk__next');
		var $statusMsg = $root.find('.mvweb-sml-bulk__status-msg');
		var $selectAll = $root.find('.mvweb-sml-bulk__select-all');
		var $selectAllNote = $root.find('.mvweb-sml-bulk__selectall-note');
		var $selectAllText = $root.find('.mvweb-sml-bulk__selectall-text');
		var $selectAllToggle = $root.find('.mvweb-sml-bulk__selectall-toggle');
		var $progress = $root.find('.mvweb-sml-bulk__progress');
		var $bar = $root.find('.mvweb-sml-bulk__bar');
		var $progressStatus = $root.find('.mvweb-sml-bulk__progress-status');

		function escapeHtml(str) {
			return $('<div/>').text(str == null ? '' : String(str)).html();
		}

		function readFilters() {
			return {
				cpt: $root.find('.mvweb-sml-bulk__filter-cpt').val() || '',
				category: parseInt($root.find('.mvweb-sml-bulk__filter-category').val(), 10) || 0,
				cluster: parseInt($root.find('.mvweb-sml-bulk__filter-cluster').val(), 10) || 0,
				status: $root.find('.mvweb-sml-bulk__filter-status').val() || '',
				search: $.trim($root.find('.mvweb-sml-bulk__filter-search').val() || ''),
				orphan_only: $root.find('.mvweb-sml-bulk__filter-orphan').is(':checked') ? 1 : 0,
				has_keywords: $root.find('.mvweb-sml-bulk__filter-has-keywords').is(':checked') ? 1 : 0
			};
		}

		function sprintf(tpl, args) {
			var out = String(tpl);
			args = args || [];
			out = out.replace(/%(\d+)\$[sd]/g, function(_, idx) {
				var i = parseInt(idx, 10) - 1;
				return args[i] != null ? String(args[i]) : '';
			});
			var i = 0;
			out = out.replace(/%[sd]/g, function() {
				var v = args[i++];
				return v != null ? String(v) : '';
			});
			return out;
		}

		function formatStatus(status) {
			if ('approved' === status) { return i18n.status_approved || 'Approved'; }
			if ('rejected' === status) { return i18n.status_rejected || 'Rejected'; }
			if ('auto' === status) { return i18n.status_auto || 'Auto'; }
			return i18n.status_pending || 'Pending';
		}

		// Map link status to a UI Kit badge modifier so the bulk table reuses
		// .mvweb-badge--success / --warning / --error / --purple instead of
		// shipping plugin-level color overrides.
		function statusBadgeModifier(status) {
			if ('approved' === status) { return 'mvweb-badge--success'; }
			if ('rejected' === status) { return 'mvweb-badge--error'; }
			if ('auto' === status) { return 'mvweb-badge--purple'; }
			return 'mvweb-badge--warning';
		}

		function resetSelectAllMatching() {
			state.selectAllMatching = false;
			$selectAllNote.attr('hidden', true);
		}

		// Show/refresh the "select all N matching" banner. Only meaningful when
		// the whole page is checked and more rows match than fit on one page.
		function refreshSelectAllNote() {
			var pageChecked = $selectAll.is(':checked');
			if (!pageChecked || state.total <= state.items.length) {
				resetSelectAllMatching();
				return;
			}
			$selectAllNote.removeAttr('hidden');
			if (state.selectAllMatching) {
				$selectAllText.text(sprintf(i18n.selectall_all || 'All %d matching rows are selected.', [state.total]));
				$selectAllToggle.text(i18n.selectall_clear || 'Clear selection');
			} else {
				$selectAllText.text(sprintf(i18n.selectall_page || 'All %d rows on this page are selected.', [state.items.length]));
				$selectAllToggle.text(sprintf(i18n.selectall_pick || 'Select all %d matching rows', [state.total]));
			}
		}

		function renderRows() {
			$tbody.empty();
			$selectAll.prop('checked', false);
			resetSelectAllMatching();

			if (!state.items.length) {
				$tbody.append(
					'<tr class="mvweb-sml-bulk__empty"><td colspan="8">' +
					escapeHtml(i18n.bulk_empty || 'No suggestions match the current filters.') +
					'</td></tr>'
				);
				return;
			}

			$.each(state.items, function(_, item) {
				var $tr = $('<tr class="mvweb-sml-bulk__row" />').attr('data-id', item.id);

				var $check = $('<td class="mvweb-sml-bulk__col-check"><input type="checkbox" class="mvweb-sml-bulk__row-check" /></td>');

				var $source = $('<td class="mvweb-sml-bulk__col-source" />');
				if (item.source_edit_url) {
					$source.append($('<a />').attr('href', item.source_edit_url).attr('target', '_blank').text(item.source_title || ('#' + item.source_id)));
				} else {
					$source.text(item.source_title || ('#' + item.source_id));
				}

				var $arrow = $('<td class="mvweb-sml-bulk__col-arrow">→</td>');

				var $target = $('<td class="mvweb-sml-bulk__col-target" />');
				if (item.target_edit_url) {
					$target.append($('<a />').attr('href', item.target_edit_url).attr('target', '_blank').text(item.target_title || ('#' + item.target_id)));
				} else {
					$target.text(item.target_title || ('#' + item.target_id));
				}
				if (item.context && (item.context.b || item.context.m || item.context.a)) {
					var ctxB = item.context.b || '';
					var ctxM = item.context.m || '';
					var ctxA = item.context.a || '';
					var full = ctxB + ctxM + ctxA;
					var toks = [];
					var ci = 0, cn = full.length;
					while (ci < cn) {
						while (ci < cn && /\s/.test(full.charAt(ci))) { ci++; }
						if (ci >= cn) { break; }
						var wStart = ci;
						while (ci < cn && !/\s/.test(full.charAt(ci))) { ci++; }
						toks.push({ text: full.substring(wStart, ci), start: wStart, end: ci });
					}
					var mStart = ctxB.length, mEnd = mStart + ctxM.length;
					var matchIdx = [];
					for (var ti = 0; ti < toks.length; ti++) { if (toks[ti].start < mEnd && toks[ti].end > mStart) { matchIdx.push(ti); } }
					var $snippet = $('<div class="mvweb-sml-bulk__context" />').attr('title', i18n.anchor_pick_hint || 'Click a word to set the link anchor from the sentence');
					$snippet.append(document.createTextNode('…'));
					for (var wi = 0; wi < toks.length; wi++) {
						var $w = $('<span class="mvweb-sml-bulk__ctx-word" />').attr('data-i', wi).text(toks[wi].text);
						if (matchIdx.indexOf(wi) >= 0) { $w.addClass('is-match'); }
						$snippet.append($w);
						if (wi < toks.length - 1) { $snippet.append(document.createTextNode(' ')); }
					}
					$snippet.append(document.createTextNode('…'));
					if (matchIdx.length) { $snippet.data('sml', { full: full, toks: toks, matchIdx: matchIdx }); }
					$target.append($snippet);
				}

				var $anchor = $('<td class="mvweb-sml-bulk__col-anchor" />');
				$anchor.append(
					$('<span class="mvweb-sml-bulk__anchor-badge mvweb-sml-bulk__anchor-text" />').text(item.anchor || item.keyword || '')
				);
				if (item.anchor_reuse && item.anchor_reuse >= 2) {
					var reuseHint = (i18n.anchor_reuse_hint || 'This anchor already links to this target %d times — consider diversifying to avoid over-optimization').replace('%d', item.anchor_reuse);
					$anchor.append(
						$('<span class="mvweb-sml-bulk__anchor-warn" />')
							.attr('title', reuseHint)
							.text(' ⚠ ' + item.anchor_reuse + '×')
					);
				}

				var $score = $('<td class="mvweb-sml-bulk__col-score" />');
				if (item.score) {
					$score.append(
						$('<span class="mvweb-sml-bulk__score" />')
							.attr('title', i18n.relevance_hint || 'Relevance score (shared topical words)')
							.text(Math.round(item.score))
					);
				} else {
					$score.append($('<span class="mvweb-sml-bulk__score-empty" />').text('—'));
				}

				var $status = $('<td class="mvweb-sml-bulk__col-status" />');
				$status.append(
					$('<span />')
						.addClass('mvweb-badge ' + statusBadgeModifier(item.status))
						.text(formatStatus(item.status))
				);

				var $actions = $('<td class="mvweb-sml-bulk__col-actions" />');
				$actions.append(
					$('<button type="button" class="mvweb-sml-bulk__icon-btn mvweb-sml-bulk__approve mvweb-sml-bulk__approve--icon" />')
						.attr('title', i18n.status_approved || 'Approve')
						.attr('aria-label', i18n.status_approved || 'Approve')
						.html(ICON_CHECK)
				);
				$actions.append(' ');
				$actions.append(
					$('<button type="button" class="mvweb-sml-bulk__icon-btn mvweb-sml-bulk__reject mvweb-sml-bulk__reject--icon" />')
						.attr('title', i18n.status_rejected || 'Reject')
						.attr('aria-label', i18n.status_rejected || 'Reject')
						.html(ICON_X)
				);

				$tr.append($check).append($source).append($arrow).append($target).append($anchor).append($score).append($status).append($actions);
				$tbody.append($tr);
			});
		}

		function renderPagination() {
			var label = sprintf(i18n.bulk_page || 'Page %1$d of %2$d (%3$d items)', [state.page, Math.max(1, state.pages), state.total]);
			$pageInfo.text(label);
			$prev.prop('disabled', state.page <= 1);
			$next.prop('disabled', state.page >= state.pages);
		}

		function setStatusMsg(text, isError) {
			$statusMsg.text(text || '').toggleClass('is-error', !!isError);
		}

		// Message to surface once the next load() finishes (so a bulk result
		// survives the table reload instead of being wiped by it).
		var pendingMsg = '';

		// Reflect the active sort column + direction on the header buttons.
		function renderSort() {
			$root.find('.mvweb-sml-bulk__sortable').each(function() {
				var $th = $(this);
				var active = $th.data('orderby') === state.orderby;
				$th.toggleClass('is-sorted', active);
				$th.find('.mvweb-sml-bulk__sort-ind').text(active ? ('ASC' === state.order ? ' ▲' : ' ▼') : '');
			});
		}

		function load() {
			setStatusMsg(i18n.bulk_loading || 'Loading…');
			var filters = readFilters();
			filters.action = 'mvweb_sml_bulk_list';
			filters.nonce = ajax.nonce;
			filters.page = state.page;
			filters.per_page = state.perPage;
			filters.orderby = state.orderby;
			filters.order = state.order;

			$.post(ajax.ajax_url, filters).done(function(response) {
				if (!response || !response.success) {
					setStatusMsg((response && response.data && response.data.message) || i18n.error, true);
					return;
				}
				state.items = response.data.items || [];
				state.total = parseInt(response.data.total, 10) || 0;
				state.pages = parseInt(response.data.pages, 10) || 0;
				state.page = parseInt(response.data.page, 10) || 1;
				state.perPage = parseInt(response.data.per_page, 10) || state.perPage;
				state.orderby = response.data.orderby || state.orderby;
				state.order = response.data.order || state.order;
				renderRows();
				renderPagination();
				renderSort();
				$root.find('.mvweb-sml-bulk__perpage').val(String(state.perPage));
				setStatusMsg(pendingMsg || '');
				pendingMsg = '';
			}).fail(function() {
				setStatusMsg(i18n.error || 'Error', true);
			});
		}

		// ── Sort by clickable column headers ────────────────────────
		$root.on('click', '.mvweb-sml-bulk__sortable', function() {
			var col = $(this).data('orderby');
			if (!col) { return; }
			if (state.orderby === col) {
				state.order = 'ASC' === state.order ? 'DESC' : 'ASC';
			} else {
				state.orderby = col;
				state.order = 'DESC';
			}
			state.page = 1;
			load();
		});

		// ── Rows-per-page selector ──────────────────────────────────
		$root.on('change', '.mvweb-sml-bulk__perpage', function() {
			var v = parseInt($(this).val(), 10);
			if (v > 0) {
				state.perPage = v;
				state.page = 1;
				load();
			}
		});

		// ── Filters with debounce on the search input ───────────────
		var filterTimer = null;
		function scheduleReload() {
			if (filterTimer) { clearTimeout(filterTimer); }
			filterTimer = setTimeout(function() {
				state.page = 1;
				load();
			}, 250);
		}

		$root.on('change',
			'.mvweb-sml-bulk__filter-cpt, .mvweb-sml-bulk__filter-category, .mvweb-sml-bulk__filter-cluster, .mvweb-sml-bulk__filter-status, .mvweb-sml-bulk__filter-orphan, .mvweb-sml-bulk__filter-has-keywords',
			function() {
				state.page = 1;
				load();
			}
		);

		$root.on('input', '.mvweb-sml-bulk__filter-search', scheduleReload);

		// ── Pagination ──────────────────────────────────────────────
		$prev.on('click', function() {
			if (state.page > 1) {
				state.page -= 1;
				load();
			}
		});
		$next.on('click', function() {
			if (state.page < state.pages) {
				state.page += 1;
				load();
			}
		});

		// ── Select all on current page ──────────────────────────────
		$selectAll.on('change', function() {
			var checked = $(this).is(':checked');
			$root.find('.mvweb-sml-bulk__row-check').prop('checked', checked);
			state.selectAllMatching = false;
			refreshSelectAllNote();
		});

		// Un/checking an individual row invalidates the "all matching" scope.
		$root.on('change', '.mvweb-sml-bulk__row-check', function() {
			if (!$(this).is(':checked')) {
				$selectAll.prop('checked', false);
			}
			state.selectAllMatching = false;
			refreshSelectAllNote();
		});

		// Toggle between "this page" and "all N matching" scope.
		$selectAllToggle.on('click', function() {
			state.selectAllMatching = !state.selectAllMatching;
			refreshSelectAllNote();
		});

		function collectSelectedIds() {
			var ids = [];
			$root.find('.mvweb-sml-bulk__row-check:checked').each(function() {
				var id = parseInt($(this).closest('.mvweb-sml-bulk__row').data('id'), 10);
				if (id) { ids.push(id); }
			});
			return ids;
		}

		// ── Inline anchor edit ──────────────────────────────────────
		$root.on('click', '.mvweb-sml-bulk__anchor-text', function() {
			var $span = $(this);
			if ($span.closest('td').find('input.mvweb-sml-bulk__anchor-input').length) {
				return;
			}
			var current = $span.text();
			var $input = $('<input type="text" class="mvweb-sml-bulk__anchor-input" />').val(current);
			$span.hide().after($input);
			$input.trigger('focus').trigger('select');
		});

		$root.on('blur', '.mvweb-sml-bulk__anchor-input', function() {
			var $input = $(this);
			var $span = $input.siblings('.mvweb-sml-bulk__anchor-text');
			var $row = $input.closest('.mvweb-sml-bulk__row');
			var id = parseInt($row.data('id'), 10) || 0;
			var value = $input.val();

			if (!id) {
				$input.remove();
				$span.show();
				return;
			}

			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_bulk_update_anchor',
				nonce: ajax.nonce,
				id: id,
				anchor: value
			}).done(function(response) {
				if (response && response.success) {
					$span.text(response.data.anchor || value);
					setStatusMsg(i18n.saved || 'Saved.');
				} else {
					setStatusMsg((response && response.data && response.data.message) || i18n.error, true);
				}
			}).fail(function() {
				setStatusMsg(i18n.error || 'Error', true);
			}).always(function() {
				$input.remove();
				$span.show();
			});
		});

		$root.on('keydown', '.mvweb-sml-bulk__anchor-input', function(e) {
			if (e.which === 13) {
				e.preventDefault();
				$(this).trigger('blur');
			} else if (e.which === 27) {
				e.preventDefault();
				var $input = $(this);
				$input.siblings('.mvweb-sml-bulk__anchor-text').show();
				$input.remove();
			}
		});

		$root.on('click', '.mvweb-sml-bulk__ctx-word', function() {
			var $w = $(this);
			var $snippet = $w.closest('.mvweb-sml-bulk__context');
			var meta = $snippet.data('sml');
			if (!meta || !meta.matchIdx.length) { return; }

			var i = parseInt($w.attr('data-i'), 10);
			var lo = Math.min(i, meta.matchIdx[0]);
			var hi = Math.max(i, meta.matchIdx[meta.matchIdx.length - 1]);
			var phrase = meta.full.substring(meta.toks[lo].start, meta.toks[hi].end);
			// Trim sentence punctuation off the edges so the anchor stays clean;
			// the result is still a real substring, so the scanner still finds it.
			phrase = phrase.replace(/^[\s.,;:!?»«"'()]+/, '').replace(/[\s.,;:!?»«"'()]+$/, '');

			$snippet.find('.mvweb-sml-bulk__ctx-word').each(function() {
				var j = parseInt($(this).attr('data-i'), 10);
				$(this).toggleClass('is-selected', j >= lo && j <= hi);
			});

			// Fill (opening if needed) the existing inline anchor input so the
			// normal Enter/blur save path persists the picked phrase.
			var $row = $w.closest('.mvweb-sml-bulk__row');
			var $input = $row.find('input.mvweb-sml-bulk__anchor-input');
			if (!$input.length) {
				$row.find('.mvweb-sml-bulk__anchor-text').trigger('click');
				$input = $row.find('input.mvweb-sml-bulk__anchor-input');
			}
			$input.val(phrase).trigger('focus');
		});

		// ── Bulk actions (approve / reject / reset / delete) ────────
		function confirmIds(action) {
			if ('approve' === action) { return i18n.confirm_approve || 'Approve selected?'; }
			if ('reject' === action) { return i18n.confirm_reject || 'Reject selected?'; }
			if ('pending' === action) { return i18n.confirm_pending || 'Reset selected to pending?'; }
			if ('delete' === action) { return i18n.confirm_bulk_delete || 'Delete selected suggestions? This cannot be undone.'; }
			return '';
		}

		function afterMutate(response) {
			var d = response.data || {};
			var msg = sprintf(i18n.bulk_done || 'Updated %d items.', [d.updated || 0]);
			if (d.capped) { msg += ' ' + (i18n.bulk_capped || 'Some matches remain — run it again to continue.'); }
			pendingMsg = msg;
			load();
		}

		function postMutate(data) {
			data.nonce = ajax.nonce;
			$.post(ajax.ajax_url, data).done(function(response) {
				if (!response || !response.success) {
					setStatusMsg((response && response.data && response.data.message) || i18n.error, true);
					return;
				}
				afterMutate(response);
			}).fail(function() {
				setStatusMsg(i18n.error || 'Error', true);
			});
		}

		function applyIds(action, ids) {
			if (!ids.length) {
				setStatusMsg(i18n.no_selection || 'No items selected.', true);
				return;
			}
			var c = confirmIds(action);
			if (c && !window.confirm(c)) { return; }
			postMutate({ action: 'mvweb_sml_bulk_apply', bulk_action: action, ids: ids });
		}

		function applyFilter(action) {
			var c = 'delete' === action
				? sprintf(i18n.confirm_all_delete || 'Delete all %d matching rows? This cannot be undone.', [state.total])
				: sprintf(i18n.confirm_all || 'Apply this action to all %d matching rows?', [state.total]);
			if (c && !window.confirm(c)) { return; }
			var data = readFilters();
			data.action = 'mvweb_sml_bulk_filter';
			data.bulk_action = action;
			postMutate(data);
		}

		$root.on('click', '.mvweb-sml-bulk__approve', function() {
			var id = parseInt($(this).closest('.mvweb-sml-bulk__row').data('id'), 10) || 0;
			if (id) { applyIds('approve', [id]); }
		});
		$root.on('click', '.mvweb-sml-bulk__reject', function() {
			var id = parseInt($(this).closest('.mvweb-sml-bulk__row').data('id'), 10) || 0;
			if (id) { applyIds('reject', [id]); }
		});

		// ── Apply bulk action to selected rows OR all matching ──────
		$root.on('click', '.mvweb-sml-bulk__apply', function() {
			var action = $root.find('.mvweb-sml-bulk__action').val();
			if (!action) {
				setStatusMsg(i18n.no_action || 'Pick a bulk action.', true);
				return;
			}
			if (state.selectAllMatching) {
				applyFilter(action);
			} else {
				applyIds(action, collectSelectedIds());
			}
		});

		// ── Generate suggestions sweep ──────────────────────────────
		function setBar(pct) {
			$bar.css('width', Math.max(0, Math.min(100, pct)) + '%');
		}

		function suggestStep(total, totalInserted) {
			totalInserted = totalInserted || 0;
			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_generate_suggestions',
				nonce: ajax.nonce
			}).done(function(response) {
				if (!response || !response.success) {
					$progressStatus.text((response && response.data && response.data.message) || i18n.error);
					return;
				}
				var data = response.data || {};
				var remaining = parseInt(data.remaining, 10) || 0;
				var done = Math.max(0, total - remaining);
				var pct = total > 0 ? Math.round((done / total) * 100) : 100;
				totalInserted += parseInt(data.inserted, 10) || 0;
				setBar(pct);
				$progressStatus.text(sprintf(i18n.generating || 'Generating… %1$d / %2$d (+%3$d)', [done, total, totalInserted]));

				if (data.done || remaining <= 0) {
					setBar(100);
					$progressStatus.text(sprintf(i18n.generate_done || 'Done: %1$d posts, %2$d new pairs.', [total, totalInserted]));
					$root.find('.mvweb-sml-bulk__generate').prop('disabled', false);
					load();
					return;
				}

				suggestStep(total, totalInserted);
			}).fail(function() {
				$progressStatus.text(i18n.error || 'Error');
				$root.find('.mvweb-sml-bulk__generate').prop('disabled', false);
			});
		}

		$root.on('click', '.mvweb-sml-bulk__generate', function() {
			if (i18n.confirm_generate && !window.confirm(i18n.confirm_generate)) {
				return;
			}
			$(this).prop('disabled', true);
			$progress.prop('hidden', false).show();
			setBar(0);
			$progressStatus.text(i18n.bulk_loading || 'Loading…');

			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_generate_suggestions',
				nonce: ajax.nonce,
				reset: 1
			}).done(function(response) {
				if (!response || !response.success) {
					$progressStatus.text((response && response.data && response.data.message) || i18n.error);
					$root.find('.mvweb-sml-bulk__generate').prop('disabled', false);
					return;
				}
				var total = parseInt(response.data.total, 10) || 0;
				if (total <= 0) {
					setBar(100);
					$progressStatus.text(sprintf(i18n.generate_done || 'Done.', [0, 0]));
					$root.find('.mvweb-sml-bulk__generate').prop('disabled', false);
					return;
				}
				suggestStep(total);
			}).fail(function() {
				$progressStatus.text(i18n.error || 'Error');
				$root.find('.mvweb-sml-bulk__generate').prop('disabled', false);
			});
		});

		// Initial load.
		load();
	}

	/**
	 * Clusters tab (phase 10): list, create, add/remove spokes, suggestions.
	 *
	 * The whole tab is built from a single AJAX state — every mutating
	 * endpoint returns the fresh `clusters` array so the client can re-render
	 * without keeping a parallel state.
	 */
	function initClusters() {
		var $root = $('.mvweb-sml-clusters');
		if (!$root.length) {
			return;
		}

		var ajax = window.mvweb_sml_ajax || {};
		var i18n = ajax.i18n || {};
		var $list = $root.find('.mvweb-sml-clusters__list');
		var $createStatus = $root.find('.mvweb-sml-clusters__create-status');

		function escapeHtml(str) {
			return $('<div/>').text(str == null ? '' : String(str)).html();
		}

		function format(template, args) {
			var i = 0;
			return String(template || '').replace(/%(\d+\$)?[ds]/g, function(_, pos) {
				if (pos) {
					var idx = parseInt(pos, 10) - 1;
					return args[idx] != null ? args[idx] : '';
				}
				var v = args[i];
				i++;
				return v != null ? v : '';
			});
		}

		function showStatus($el, message, type) {
			$el.text(message)
				.removeClass('mvweb-alert--success mvweb-alert--error mvweb-alert--warning mvweb-alert--info')
				.addClass('mvweb-alert mvweb-alert--' + (type || 'info'))
				.prop('hidden', false);
		}

		function hideStatus($el) {
			$el.text('').prop('hidden', true);
		}

		function renderClusters(clusters) {
			$list.empty();

			if (!clusters || !clusters.length) {
				$list.append(
					$('<p/>', {
						'class': 'mvweb-sml-clusters__empty',
						text: i18n.cluster_no_clusters || 'No clusters yet.'
					})
				);
				return;
			}

			$.each(clusters, function(_, c) {
				var $card = $('<div/>', {
					'class': 'mvweb-card mvweb-sml-cluster',
					'data-cluster-id': c.id
				});

				var $header = $('<div/>', { 'class': 'mvweb-sml-cluster__header' });
				$header.append(
					$('<h3/>', {
						'class': 'mvweb-sml-cluster__title',
						text: c.name
					})
				);

				var pillarLine = $('<div/>', { 'class': 'mvweb-sml-cluster__pillar' });
				pillarLine.append(
					$('<span/>', {
						'class': 'mvweb-badge mvweb-badge--purple',
						text: i18n.cluster_pillar || 'Pillar'
					})
				);
				if (c.pillar_view) {
					pillarLine.append(
						$('<a/>', {
							href: c.pillar_view,
							text: c.pillar_title,
							target: '_blank',
							rel: 'noopener'
						})
					);
				} else {
					pillarLine.append($('<span/>', { text: c.pillar_title }));
				}
				$header.append(pillarLine);

				var health = c.health || {};
				var healthText = format(
					i18n.cluster_health || '%1$d / %2$d link to pillar',
					[health.spokes_linking_to_pillar || 0, health.spoke_count || 0]
				);
				var orphan = (health.orphan_spokes || 0) > 0;
				$header.append(
					$('<span/>', {
						'class': 'mvweb-badge ' + (orphan ? 'mvweb-badge--warning' : 'mvweb-badge--success'),
						text: healthText
					})
				);

				$card.append($header);

				// Spokes list.
				var $spokes = $('<ul/>', { 'class': 'mvweb-sml-cluster__spokes' });
				if (c.spokes && c.spokes.length) {
					$.each(c.spokes, function(_, s) {
						var $li = $('<li/>', { 'class': 'mvweb-sml-cluster__spoke' });
						if (s.view_url) {
							$li.append($('<a/>', { href: s.view_url, text: s.title, target: '_blank', rel: 'noopener' }));
						} else {
							$li.append($('<span/>', { text: s.title }));
						}
						$li.append(
							$('<button/>', {
								type: 'button',
								'class': 'mvweb-btn mvweb-btn--ghost mvweb-btn--sm mvweb-sml-cluster__spoke-remove',
								'data-post-id': s.id,
								text: i18n.cluster_remove_spoke || 'Remove'
							})
						);
						$spokes.append($li);
					});
				} else {
					$spokes.append(
						$('<li/>', {
							'class': 'mvweb-sml-cluster__spoke mvweb-sml-cluster__spoke--empty',
							text: i18n.cluster_no_spokes || 'No spokes yet.'
						})
					);
				}
				$card.append($spokes);

				// Add spoke autocomplete.
				var $addBox = $('<div/>', { 'class': 'mvweb-sml-cluster__add' });
				$addBox.append(
					$('<input/>', {
						type: 'text',
						'class': 'mvweb-input mvweb-sml-cluster__spoke-search',
						placeholder: i18n.cluster_search_post || 'Search post…',
						autocomplete: 'off'
					})
				);
				$addBox.append(
					$('<ul/>', { 'class': 'mvweb-sml-cluster__autocomplete', hidden: true })
				);
				$card.append($addBox);

				// Actions row.
				var $actions = $('<div/>', { 'class': 'mvweb-sml-cluster__actions' });
				$actions.append(
					$('<button/>', {
						type: 'button',
						'class': 'mvweb-btn mvweb-btn--secondary mvweb-sml-cluster__suggest',
						text: i18n.cluster_suggest || 'Suggest spokes'
					})
				);
				$actions.append(
					$('<button/>', {
						type: 'button',
						'class': 'mvweb-btn mvweb-btn--ghost mvweb-sml-cluster__preset',
						'data-preset': 'hub_spoke',
						text: i18n.cluster_preset_hub || 'Hub & spoke'
					})
				);
				$actions.append(
					$('<button/>', {
						type: 'button',
						'class': 'mvweb-btn mvweb-btn--ghost mvweb-sml-cluster__preset',
						'data-preset': 'reverse_silo',
						text: i18n.cluster_preset_silo || 'Reverse silo'
					})
				);
				$actions.append(
					$('<button/>', {
						type: 'button',
						'class': 'mvweb-btn mvweb-btn--danger mvweb-sml-cluster__delete',
						text: i18n.cluster_delete || 'Delete cluster'
					})
				);
				$card.append($actions);

				// Suggestions container.
				$card.append($('<div/>', { 'class': 'mvweb-sml-cluster__suggestions', hidden: true }));

				$list.append($card);
			});
		}

		function loadClusters() {
			$list.html('<p class="mvweb-sml-clusters__loading">' + escapeHtml(i18n.cluster_loading || 'Loading…') + '</p>');
			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_cluster_list',
				nonce: ajax.nonce
			}).done(function(response) {
				if (response && response.success) {
					renderClusters(response.data.clusters || []);
				} else {
					$list.html('<p class="mvweb-sml-clusters__empty">' + escapeHtml(i18n.error || 'Error') + '</p>');
				}
			}).fail(function() {
				$list.html('<p class="mvweb-sml-clusters__empty">' + escapeHtml(i18n.error || 'Error') + '</p>');
			});
		}

		// Pillar autocomplete (for create form).
		var $pillarSearch = $root.find('.mvweb-sml-clusters__pillar-search');
		var $pillarId = $root.find('.mvweb-sml-clusters__pillar-id');
		var $pillarAuto = $root.find('.mvweb-sml-clusters__autocomplete');
		var pillarTimer = null;

		$pillarSearch.on('input', function() {
			var term = $.trim($(this).val());
			$pillarId.val('');
			if (pillarTimer) {
				clearTimeout(pillarTimer);
			}
			if (term.length < 2) {
				$pillarAuto.empty().prop('hidden', true);
				return;
			}
			pillarTimer = setTimeout(function() {
				$.post(ajax.ajax_url, {
					action: 'mvweb_sml_search_posts',
					nonce: ajax.nonce,
					term: term
				}).done(function(response) {
					if (!response || !response.success) {
						$pillarAuto.empty().prop('hidden', true);
						return;
					}
					$pillarAuto.empty();
					$.each(response.data.results || [], function(_, item) {
						$('<li/>', {
							'class': 'mvweb-sml-clusters__autocomplete-item',
							'data-id': item.id,
							text: item.title
						}).appendTo($pillarAuto);
					});
					$pillarAuto.prop('hidden', !$pillarAuto.children().length);
				});
			}, 250);
		});

		$root.on('click', '.mvweb-sml-clusters__autocomplete-item', function() {
			var $li = $(this);
			$pillarId.val($li.data('id'));
			$pillarSearch.val($li.text());
			$pillarAuto.empty().prop('hidden', true);
		});

		$(document).on('click', function(e) {
			if (!$(e.target).closest('.mvweb-sml-clusters__field--pillar').length) {
				$pillarAuto.empty().prop('hidden', true);
			}
		});

		// Create cluster.
		$root.on('click', '.mvweb-sml-clusters__create-btn', function() {
			var pillarId = parseInt($pillarId.val(), 10) || 0;
			var name = $.trim($root.find('.mvweb-sml-clusters__name').val());
			if (pillarId <= 0) {
				showStatus($createStatus, i18n.cluster_pillar_req || 'Pick a pillar post first.', 'error');
				return;
			}
			hideStatus($createStatus);
			var $btn = $(this).prop('disabled', true);
			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_cluster_create',
				nonce: ajax.nonce,
				pillar_id: pillarId,
				name: name
			}).done(function(response) {
				if (response && response.success) {
					$pillarSearch.val('');
					$pillarId.val('');
					$root.find('.mvweb-sml-clusters__name').val('');
					renderClusters(response.data.clusters || []);
				} else {
					var msg = (response && response.data && response.data.message) || i18n.error || 'Error';
					showStatus($createStatus, msg, 'error');
				}
			}).fail(function() {
				showStatus($createStatus, i18n.error || 'Error', 'error');
			}).always(function() {
				$btn.prop('disabled', false);
			});
		});

		// Delete cluster.
		$list.on('click', '.mvweb-sml-cluster__delete', function() {
			var $card = $(this).closest('.mvweb-sml-cluster');
			var clusterId = parseInt($card.data('cluster-id'), 10) || 0;
			if (clusterId <= 0) {
				return;
			}
			if (!window.confirm(i18n.cluster_confirm_del || 'Delete this cluster?')) {
				return;
			}
			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_cluster_delete',
				nonce: ajax.nonce,
				cluster_id: clusterId
			}).done(function(response) {
				if (response && response.success) {
					renderClusters(response.data.clusters || []);
				}
			});
		});

		// Apply interlinking preset (hub-and-spoke / reverse silo).
		$list.on('click', '.mvweb-sml-cluster__preset', function() {
			var $btn = $(this);
			var $card = $btn.closest('.mvweb-sml-cluster');
			var clusterId = parseInt($card.data('cluster-id'), 10) || 0;
			var preset = $btn.data('preset');
			if (clusterId <= 0 || !preset) {
				return;
			}
			if (!window.confirm(i18n.cluster_preset_confirm || 'Create approved internal links for this cluster?')) {
				return;
			}
			$card.find('.mvweb-sml-cluster__preset').prop('disabled', true);
			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_cluster_apply_preset',
				nonce: ajax.nonce,
				cluster_id: clusterId,
				preset: preset
			}).done(function(response) {
				if (response && response.success) {
					var s = response.data.stats || {};
					var tpl = i18n.cluster_preset_done || 'Created %1$d links (%2$d already existed, %3$d skipped — target has no keyword).';
					window.alert(
						tpl.replace('%1$d', s.created || 0)
							.replace('%2$d', s.existing || 0)
							.replace('%3$d', s.skipped_no_keyword || 0)
					);
					renderClusters(response.data.clusters || []);
				} else {
					var msg = (response && response.data && response.data.message) || i18n.error || 'Error';
					window.alert(msg);
				}
			}).fail(function() {
				window.alert(i18n.error || 'Error');
			}).always(function() {
				$card.find('.mvweb-sml-cluster__preset').prop('disabled', false);
			});
		});

		// Remove spoke.
		$list.on('click', '.mvweb-sml-cluster__spoke-remove', function() {
			var $card = $(this).closest('.mvweb-sml-cluster');
			var clusterId = parseInt($card.data('cluster-id'), 10) || 0;
			var postId = parseInt($(this).data('post-id'), 10) || 0;
			if (clusterId <= 0 || postId <= 0) {
				return;
			}
			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_cluster_remove_spoke',
				nonce: ajax.nonce,
				cluster_id: clusterId,
				post_id: postId
			}).done(function(response) {
				if (response && response.success) {
					renderClusters(response.data.clusters || []);
				}
			});
		});

		// Add-spoke autocomplete (delegated, per-card).
		var spokeTimers = {};
		$list.on('input', '.mvweb-sml-cluster__spoke-search', function() {
			var $input = $(this);
			var $card = $input.closest('.mvweb-sml-cluster');
			var clusterId = parseInt($card.data('cluster-id'), 10) || 0;
			var $auto = $card.find('.mvweb-sml-cluster__autocomplete');
			var term = $.trim($input.val());

			if (spokeTimers[clusterId]) {
				clearTimeout(spokeTimers[clusterId]);
			}
			if (term.length < 2) {
				$auto.empty().prop('hidden', true);
				return;
			}

			spokeTimers[clusterId] = setTimeout(function() {
				$.post(ajax.ajax_url, {
					action: 'mvweb_sml_search_posts',
					nonce: ajax.nonce,
					term: term
				}).done(function(response) {
					if (!response || !response.success) {
						$auto.empty().prop('hidden', true);
						return;
					}
					$auto.empty();
					$.each(response.data.results || [], function(_, item) {
						$('<li/>', {
							'class': 'mvweb-sml-cluster__autocomplete-item',
							'data-id': item.id,
							text: item.title
						}).appendTo($auto);
					});
					$auto.prop('hidden', !$auto.children().length);
				});
			}, 250);
		});

		$list.on('click', '.mvweb-sml-cluster__autocomplete-item', function() {
			var $li = $(this);
			var $card = $li.closest('.mvweb-sml-cluster');
			var clusterId = parseInt($card.data('cluster-id'), 10) || 0;
			var postId = parseInt($li.data('id'), 10) || 0;
			if (clusterId <= 0 || postId <= 0) {
				return;
			}
			$card.find('.mvweb-sml-cluster__autocomplete').empty().prop('hidden', true);
			$card.find('.mvweb-sml-cluster__spoke-search').val('');
			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_cluster_add_spoke',
				nonce: ajax.nonce,
				cluster_id: clusterId,
				post_id: postId
			}).done(function(response) {
				if (response && response.success) {
					renderClusters(response.data.clusters || []);
				}
			});
		});

		// Suggest spokes.
		$list.on('click', '.mvweb-sml-cluster__suggest', function() {
			var $btn = $(this);
			var $card = $btn.closest('.mvweb-sml-cluster');
			var clusterId = parseInt($card.data('cluster-id'), 10) || 0;
			var $box = $card.find('.mvweb-sml-cluster__suggestions');
			if (clusterId <= 0) {
				return;
			}
			$btn.prop('disabled', true);
			$box.prop('hidden', false).html('<p>' + escapeHtml(i18n.cluster_loading || 'Loading…') + '</p>');
			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_cluster_suggest_spokes',
				nonce: ajax.nonce,
				cluster_id: clusterId
			}).done(function(response) {
				$box.empty();
				if (!response || !response.success) {
					$box.append($('<p/>', { text: i18n.error || 'Error' }));
					return;
				}
				var suggestions = (response.data && response.data.suggestions) || [];
				if (!suggestions.length) {
					$box.append($('<p/>', { text: i18n.cluster_no_suggest || 'No suggestions.' }));
					return;
				}
				var $ul = $('<ul/>', { 'class': 'mvweb-sml-cluster__suggest-list' });
				$.each(suggestions, function(_, s) {
					var $li = $('<li/>', { 'class': 'mvweb-sml-cluster__suggest-item' });
					$li.append($('<span/>', { 'class': 'mvweb-sml-cluster__suggest-title', text: s.title }));
					$li.append(
						$('<span/>', {
							'class': 'mvweb-sml-cluster__suggest-score',
							text: format(i18n.cluster_score || 'score %d', [s.score])
						})
					);
					$li.append(
						$('<button/>', {
							type: 'button',
							'class': 'mvweb-btn mvweb-btn--secondary mvweb-sml-cluster__suggest-add',
							'data-post-id': s.id,
							text: i18n.cluster_add || 'Add'
						})
					);
					$ul.append($li);
				});
				$box.append($ul);
			}).always(function() {
				$btn.prop('disabled', false);
			});
		});

		$list.on('click', '.mvweb-sml-cluster__suggest-add', function() {
			var $btn = $(this);
			var $card = $btn.closest('.mvweb-sml-cluster');
			var clusterId = parseInt($card.data('cluster-id'), 10) || 0;
			var postId = parseInt($btn.data('post-id'), 10) || 0;
			if (clusterId <= 0 || postId <= 0) {
				return;
			}
			$btn.prop('disabled', true);
			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_cluster_add_spoke',
				nonce: ajax.nonce,
				cluster_id: clusterId,
				post_id: postId
			}).done(function(response) {
				if (response && response.success) {
					renderClusters(response.data.clusters || []);
				} else {
					$btn.prop('disabled', false);
				}
			}).fail(function() {
				$btn.prop('disabled', false);
			});
		});

		loadClusters();
	}

	/**
	 * Phase 11 — dismissible notices.
	 *
	 * Persists the click on a `.mvweb-sml-notice` close button via AJAX so
	 * the notice does not return on the next page load for this user.
	 */
	function initNoticeDismiss() {
		var ajax = window.mvweb_sml_ajax || {};
		if (!ajax.ajax_url) {
			return;
		}

		$(document).on('click', '.mvweb-sml-notice .notice-dismiss', function() {
			var $notice = $(this).closest('.mvweb-sml-notice');
			var key = $notice.data('mvweb-sml-key');
			if (!key) {
				return;
			}
			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_dismiss_notice',
				nonce: ajax.nonce,
				key: key
			});
		});
	}

	/**
	 * Phase 12 — SEO import + CSV import/export on the Settings tab.
	 */
	function initImportExport() {
		var ajax = window.mvweb_sml_ajax || {};
		var i18n = ajax.i18n || {};

		if (!ajax.ajax_url) {
			return;
		}

		// ── SEO detect ──────────────────────────────────────────
		var $detectBtn = $('#mvweb-sml-seo-detect');
		var $counts = $('#mvweb-sml-seo-counts');
		var $actions = $('.mvweb-sml-seo__actions');
		var $seoStatus = $('.mvweb-sml-seo__status');

		function seoSetStatus(text) {
			$seoStatus.text(text || '');
		}

		if ($detectBtn.length) {
			$detectBtn.on('click', function(e) {
				e.preventDefault();
				$detectBtn.prop('disabled', true);
				seoSetStatus(i18n.detecting || 'Detecting…');

				$.post(ajax.ajax_url, {
					action: 'mvweb_sml_seo_detect',
					nonce: ajax.nonce
				}).done(function(response) {
					$detectBtn.prop('disabled', false);
					if (!response || !response.success) {
						seoSetStatus((response && response.data && response.data.message) || i18n.error || 'Error');
						return;
					}
					var counts = response.data.counts || {};
					var yoast = parseInt(counts.yoast, 10) || 0;
					var rank = parseInt(counts.rankmath, 10) || 0;
					var aio = parseInt(counts.aioseo, 10) || 0;
					var tpl = i18n.seo_detected || 'Yoast: %1$d, Rank Math: %2$d, AIOSEO: %3$d';
					var msg = tpl.replace('%1$d', yoast).replace('%2$d', rank).replace('%3$d', aio);
					$counts.text(msg);
					$actions.show();
					$actions.find('[data-source="yoast"]').prop('disabled', yoast <= 0);
					$actions.find('[data-source="rankmath"]').prop('disabled', rank <= 0);
					$actions.find('[data-source="aioseo"]').prop('disabled', aio <= 0);
					seoSetStatus('');
				}).fail(function() {
					$detectBtn.prop('disabled', false);
					seoSetStatus(i18n.error || 'Error');
				});
			});
		}

		// ── SEO import (per source) ─────────────────────────────
		$actions.on('click', '.mvweb-sml-seo__import', function(e) {
			e.preventDefault();
			var $btn = $(this);
			var source = $btn.data('source');
			if (!source) {
				return;
			}

			$actions.find('.mvweb-sml-seo__import').prop('disabled', true);
			seoSetStatus(i18n.seo_importing || 'Importing…');

			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_seo_import',
				nonce: ajax.nonce,
				source: source
			}).done(function(response) {
				if (!response || !response.success) {
					seoSetStatus((response && response.data && response.data.message) || i18n.error || 'Error');
					$actions.find('.mvweb-sml-seo__import').prop('disabled', false);
					return;
				}
				var data = response.data || {};
				var imported = parseInt(data.imported, 10) || 0;
				var skipped = parseInt(data.skipped, 10) || 0;
				var total = parseInt(data.total, 10) || 0;
				if (total <= 0) {
					seoSetStatus(i18n.seo_none || 'No focus keywords found.');
				} else {
					var tpl = i18n.seo_import_done || 'Done: %1$d imported, %2$d skipped (of %3$d).';
					seoSetStatus(tpl.replace('%1$d', imported).replace('%2$d', skipped).replace('%3$d', total));
				}
				$actions.find('.mvweb-sml-seo__import').prop('disabled', false);
			}).fail(function() {
				seoSetStatus(i18n.error || 'Error');
				$actions.find('.mvweb-sml-seo__import').prop('disabled', false);
			});
		});

		// ── CSV import ──────────────────────────────────────────
		var $csvBtn = $('#mvweb-sml-csv-import');
		var $csvFile = $('#mvweb-sml-csv-file');
		var $csvStatus = $('.mvweb-sml-csv__status');

		function csvSetStatus(text) {
			$csvStatus.text(text || '');
		}

		$csvFile.on('change', function() {
			var fileInput = this;
			var $name = $(this).closest('.mvweb-file').find('.mvweb-file__name');
			if ($name.length && fileInput.files && fileInput.files.length) {
				$name.text(fileInput.files[0].name);
			}
		});

		if ($csvBtn.length) {
			$csvBtn.on('click', function(e) {
				e.preventDefault();

				var fileInput = $csvFile.get(0);
				if (!fileInput || !fileInput.files || fileInput.files.length === 0) {
					csvSetStatus(i18n.csv_pick_file || 'Pick a CSV file first.');
					return;
				}

				var fd = new FormData();
				fd.append('action', 'mvweb_sml_csv_import');
				fd.append('nonce', ajax.nonce);
				fd.append('file', fileInput.files[0]);

				$csvBtn.prop('disabled', true);
				csvSetStatus(i18n.csv_importing || 'Importing CSV…');

				$.ajax({
					url: ajax.ajax_url,
					type: 'POST',
					data: fd,
					processData: false,
					contentType: false
				}).done(function(response) {
					$csvBtn.prop('disabled', false);
					if (!response || !response.success) {
						csvSetStatus((response && response.data && response.data.message) || i18n.error || 'Error');
						return;
					}
					var data = response.data || {};
					var imported = parseInt(data.imported, 10) || 0;
					var skipped = parseInt(data.skipped, 10) || 0;
					var errors = parseInt(data.errors, 10) || 0;
					var tpl = i18n.csv_import_done || 'CSV import complete: %1$d imported, %2$d skipped, %3$d errors.';
					csvSetStatus(tpl.replace('%1$d', imported).replace('%2$d', skipped).replace('%3$d', errors));
				}).fail(function() {
					$csvBtn.prop('disabled', false);
					csvSetStatus(i18n.error || 'Error');
				});
			});
		}
	}

	/**
	 * Settings tab — dry-run preview of what automatic mode would auto-approve.
	 * Read-only: calls the mvweb_sml_auto_preview endpoint and renders the count
	 * plus a scored sample. Nothing is mutated.
	 */
	function initAutoPreview() {
		var ajax = window.mvweb_sml_ajax || {};
		var i18n = ajax.i18n || {};
		function esc(str) {
			return $('<div>').text(str == null ? '' : String(str)).html();
		}

		$(document).on('click', '.mvweb-sml-auto-preview', function() {
			var $btn = $(this);
			var $out = $btn.closest('.mvweb-form-row__field').find('.mvweb-sml-auto-preview__result');
			$btn.prop('disabled', true);
			$out.prop('hidden', false).html('<p>' + esc(i18n.auto_preview_loading || 'Checking…') + '</p>');

			$.post(ajax.ajax_url, {
				action: 'mvweb_sml_auto_preview',
				nonce: ajax.nonce
			}).done(function(resp) {
				if (!resp || !resp.success) {
					$out.html('<p>' + esc(i18n.error || 'Error') + '</p>');
					return;
				}
				var d = resp.data || {};
				var total = parseInt(d.total, 10) || 0;
				var shown = parseInt(d.shown, 10) || 0;
				var min = parseInt(d.min, 10) || 0;
				var summary = (i18n.auto_preview_summary || '%1$d pending suggestions clear the threshold (score ≥ %2$d) and would be auto-approved without review.')
					.replace('%1$d', total).replace('%2$d', min);
				var html = '<p class="mvweb-sml-auto-preview__summary">' + esc(summary) + '</p>';

				if (d.items && d.items.length) {
					html += '<ul class="mvweb-sml-auto-preview__list">';
					d.items.forEach(function(it) {
						html += '<li>' +
							'<span class="mvweb-sml-auto-preview__pair">' + esc(it.source) + ' → ' + esc(it.target) + '</span> ' +
							'<span class="mvweb-sml-auto-preview__anchor">' + esc(it.anchor) + '</span> ' +
							'<span class="mvweb-sml-auto-preview__score">' + esc(it.score) + '</span>' +
							'</li>';
					});
					html += '</ul>';
					if (total > shown) {
						html += '<p class="mvweb-sml-auto-preview__more">' +
							esc((i18n.auto_preview_more || '…and %1$d more.').replace('%1$d', total - shown)) +
							'</p>';
					}
				} else {
					html += '<p>' + esc(i18n.auto_preview_none || 'No pending suggestions meet the threshold yet.') + '</p>';
				}
				$out.html(html);
			}).fail(function() {
				$out.html('<p>' + esc(i18n.error || 'Error') + '</p>');
			}).always(function() {
				$btn.prop('disabled', false);
			});
		});
	}

	/**
	 * Document ready.
	 */
	$(function() {
		initTabs();
		initReindex();
		initMetabox();
		initBulk();
		initClusters();
		initNoticeDismiss();
		initImportExport();
		initAutoPreview();
	});

})(jQuery);
