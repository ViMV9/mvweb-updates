<?php
/**
 * Uninstall MVweb Smart Links
 *
 * Fired when the plugin is uninstalled. Removes all custom tables, options,
 * postmeta and transients — but only if the user has explicitly opted in
 * via the `delete_data_on_uninstall` setting.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if not uninstalling from WordPress.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

/**
 * Custom table logical names (without prefix).
 *
 * @var string[]
 */
$mvweb_sml_tables = array(
	'keywords',
	'links',
	'index',
	'clusters',
	'cluster_posts',
	'clicks',
);

/**
 * All plugin options created by activator/settings.
 *
 * @var string[]
 */
$mvweb_sml_options = array(
	'mvweb_sml_settings',
	'mvweb_sml_db_version',
	'mvweb_sml_notices',
	'mvweb_sml_indexer_lock',
);

/**
 * Perform full data wipe for the current site.
 *
 * @param string[] $tables  Logical table names.
 * @param string[] $options Option names to delete.
 * @return void
 */
function mvweb_sml_uninstall_site( $tables, $options ) {
	global $wpdb;

	$settings = get_option( 'mvweb_sml_settings' );

	// Respect opt-in: do nothing unless the admin explicitly enabled deletion.
	if ( ! is_array( $settings ) || empty( $settings['delete_data_on_uninstall'] ) ) {
		return;
	}

	// Drop custom tables.
	foreach ( $tables as $name ) {
		$table = $wpdb->prefix . 'mvweb_sml_' . $name;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.DirectDatabaseQuery.SchemaChange
		$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $table ) );
	}

	// Delete plugin options.
	foreach ( $options as $option ) {
		delete_option( $option );
	}

	// Delete plugin postmeta.
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE %s",
			$wpdb->esc_like( '_mvweb_sml_' ) . '%'
		)
	);

	// Delete per-user notice-dismissal flags (usermeta `mvweb_sml_dismissed_*`).
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s",
			$wpdb->esc_like( 'mvweb_sml_dismissed_' ) . '%'
		)
	);

	// Delete plugin transients (and their timeout twins).
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
	$wpdb->query(
		$wpdb->prepare(
			"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
			$wpdb->esc_like( '_transient_mvweb_sml_' ) . '%',
			$wpdb->esc_like( '_transient_timeout_mvweb_sml_' ) . '%'
		)
	);
}

if ( is_multisite() ) {
	$sites = get_sites( array( 'number' => 0 ) );
	foreach ( $sites as $site ) {
		switch_to_blog( (int) $site->blog_id );
		mvweb_sml_uninstall_site( $mvweb_sml_tables, $mvweb_sml_options );
		restore_current_blog();
	}
} else {
	mvweb_sml_uninstall_site( $mvweb_sml_tables, $mvweb_sml_options );
}
