/**
 * Public JavaScript for MVweb Smart Links
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

(function($) {
	'use strict';

	/**
	 * Document ready.
	 */
	$(function() {
		// Add your public JavaScript here.
	});

})(jQuery);
