/**
 * MVweb Smart Links — internal link click beacon.
 *
 * Fires a fire-and-forget beacon when a contextual link (class + data-sml-t)
 * is clicked, so the plugin can count which internal links get used. No
 * personal data is sent — only the source and target post ids.
 */
(function () {
	'use strict';

	var cfg = window.mvwebSmlTrack;
	if (!cfg || !cfg.ajaxUrl || !cfg.source) {
		return;
	}

	var linkClass = cfg.linkClass || 'mvweb-sml-link';

	function send(target) {
		var data = new FormData();
		data.append('action', cfg.action);
		data.append('source', cfg.source);
		data.append('target', target);

		if (navigator.sendBeacon) {
			navigator.sendBeacon(cfg.ajaxUrl, data);
		} else {
			fetch(cfg.ajaxUrl, {
				method: 'POST',
				body: data,
				keepalive: true,
				credentials: 'same-origin'
			});
		}
	}

	document.addEventListener('click', function (e) {
		if (!e.target || !e.target.closest) {
			return;
		}
		var link = e.target.closest('a.' + linkClass + '[data-sml-t]');
		if (!link) {
			return;
		}
		var target = parseInt(link.getAttribute('data-sml-t'), 10);
		if (target > 0) {
			send(target);
		}
	}, true);
})();
