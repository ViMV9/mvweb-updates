<?php
/**
 * Frontend "Read also" block: candidate selection, injection, shortcode.
 *
 * Selection pipeline:
 *   1. Target IDs from the `_links` table (status approved|auto, source = current post).
 *   2. Cluster members (if current post belongs to a cluster) — pillar + sibling spokes.
 *   3. Taxonomy fallback (shared category/tag) when steps 1-2 return fewer than `count` items.
 *
 * Results are filtered by language (WPML / Polylang via MVweb_SML_I18n) and by the
 * global post blacklist, sorted by score, then truncated to the requested count.
 *
 * The block can be injected automatically into `the_content` or rendered anywhere via
 * the `[mvweb_related]` shortcode. Template files live in `templates/` and can be
 * overridden by the active theme under `mvweb-smart-links/`.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Related
 *
 * @since 1.0.0
 */
class MVweb_SML_Related {

	/**
	 * Whether init() has already run.
	 *
	 * @var bool
	 */
	private static $booted = false;

	/**
	 * Allowed template slugs.
	 */
	const TEMPLATES = array( 'list', 'cards', 'inline' );

	/**
	 * Allowed link targets.
	 */
	const TARGETS = array( '_self', '_blank' );

	/**
	 * Register frontend hooks and the shortcode.
	 *
	 * Called by MVweb_SML_Public::init() after the master kill switch check.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		// Priority 1000 runs after the linker (priority 999) so the related
		// block is appended to the already-linked content.
		add_filter( 'the_content', array( __CLASS__, 'inject' ), 1000 );

		add_shortcode( 'mvweb_related', array( __CLASS__, 'shortcode' ) );
	}

	/**
	 * Inject the related block into `the_content` based on `related_position`.
	 *
	 * @since 1.0.0
	 * @param string $content Post content.
	 * @return string
	 */
	public static function inject( $content ) {
		if ( ! is_string( $content ) || '' === $content ) {
			return $content;
		}

		if ( ! mvweb_sml_get_setting( 'enabled' ) ) {
			return $content;
		}

		if ( ! mvweb_sml_get_setting( 'related_enabled' ) ) {
			return $content;
		}

		if ( is_feed() ) {
			return $content;
		}

		if ( ! is_singular() || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		$post_id = (int) get_the_ID();
		if ( $post_id <= 0 ) {
			return $content;
		}

		$post_type = get_post_type( $post_id );
		if ( ! in_array( $post_type, mvweb_sml_supported_post_types(), true ) ) {
			return $content;
		}

		// Per-post opt-out and the global blacklists (IDs / URL globs / terms) —
		// same exclusions as the contextual linker, so an excluded post gets no
		// related block either.
		if ( mvweb_sml_is_source_excluded( $post_id, $post_type ) ) {
			return $content;
		}

		$html = self::render( $post_id );
		if ( '' === $html ) {
			return $content;
		}

		$position = (string) mvweb_sml_get_setting( 'related_position', 'after_content' );

		if ( 'after_paragraph' === $position ) {
			$after = (int) mvweb_sml_get_setting( 'related_after_paragraph', 3 );
			if ( $after < 1 ) {
				$after = 1;
			}
			return self::insert_after_paragraph( $content, $html, $after );
		}

		return $content . $html;
	}

	/**
	 * Shortcode handler for `[mvweb_related]`.
	 *
	 * Accepted attributes:
	 *   count     — int, overrides `related_count` setting.
	 *   template  — 'list' | 'cards' | 'inline', overrides `related_template`.
	 *   title     — string, overrides `related_title`.
	 *   post_id   — int, explicit source post (useful when the shortcode runs
	 *               outside The Loop, e.g. in a widget or sidebar).
	 *   post_type — comma-separated list of CPTs the candidates must belong to.
	 *   category  — term slug (or comma-separated slugs) restricting candidates to
	 *               any of the current post's public taxonomies.
	 *
	 * @since 1.0.0
	 * @param array $atts Shortcode attributes.
	 * @return string Rendered HTML or empty string.
	 */
	public static function shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'count'     => '',
				'template'  => '',
				'title'     => '',
				'post_id'   => '',
				'post_type' => '',
				'category'  => '',
			),
			is_array( $atts ) ? $atts : array(),
			'mvweb_related'
		);

		$post_id = '' !== $atts['post_id']
			? absint( $atts['post_id'] )
			: (int) get_the_ID();

		if ( $post_id <= 0 ) {
			return '';
		}

		$args = array();

		if ( '' !== $atts['count'] ) {
			$args['count'] = max( 1, (int) $atts['count'] );
		}

		$template = sanitize_key( (string) $atts['template'] );
		if ( in_array( $template, self::TEMPLATES, true ) ) {
			$args['template'] = $template;
		}

		if ( '' !== $atts['title'] ) {
			$args['title'] = sanitize_text_field( (string) $atts['title'] );
		}

		if ( '' !== $atts['post_type'] ) {
			$cpts = array_filter( array_map( 'sanitize_key', explode( ',', (string) $atts['post_type'] ) ) );
			if ( ! empty( $cpts ) ) {
				$args['post_types'] = array_values( $cpts );
			}
		}

		if ( '' !== $atts['category'] ) {
			$slugs = array_filter( array_map( 'sanitize_title', explode( ',', (string) $atts['category'] ) ) );
			if ( ! empty( $slugs ) ) {
				$args['category'] = array_values( $slugs );
			}
		}

		return self::render( $post_id, $args );
	}

	/**
	 * Render the related block for a given post.
	 *
	 * Results are cached per (post_id, language) pair for the default
	 * (unparameterised) render. Parameterised calls (shortcode with attrs)
	 * bypass the cache.
	 *
	 * @since 1.0.0
	 * @param int   $post_id Current post ID.
	 * @param array $args    Optional overrides (count, template, title, post_types, category).
	 * @return string HTML output (empty string if no candidates).
	 */
	public static function render( $post_id, $args = array() ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return '';
		}

		$count    = isset( $args['count'] ) ? (int) $args['count'] : (int) mvweb_sml_get_setting( 'related_count', 5 );
		$template = isset( $args['template'] ) ? (string) $args['template'] : (string) mvweb_sml_get_setting( 'related_template', 'list' );
		$title    = isset( $args['title'] )
			? (string) $args['title']
			: (string) mvweb_sml_get_setting( 'related_title', __( 'Read also', 'mvweb-smart-links' ) );
		$target   = (string) mvweb_sml_get_setting( 'related_target', '_self' );

		if ( $count < 1 ) {
			return '';
		}

		$cacheable = empty( $args );
		$cache_key = $cacheable ? self::cache_key( $post_id ) : '';

		if ( $cacheable ) {
			$cached = MVweb_SML_Cache::get( $cache_key );
			if ( false !== $cached && null !== $cached ) {
				return (string) $cached;
			}
		}

		$posts = self::get_related( $post_id, $count, $args );

		/**
		 * Filter the related posts list before rendering.
		 *
		 * @since 1.0.0
		 * @param WP_Post[] $posts   Candidate posts.
		 * @param int       $post_id Current post ID.
		 */
		$posts = apply_filters( 'mvweb_sml_related_posts', $posts, $post_id );

		if ( empty( $posts ) ) {
			if ( $cacheable ) {
				MVweb_SML_Cache::set( $cache_key, '', WEEK_IN_SECONDS );
			}
			return '';
		}

		$template_name = in_array( $template, self::TEMPLATES, true ) ? $template : 'list';
		$template_file = mvweb_sml_locate_template( 'related-' . $template_name . '.php' );
		if ( '' === $template_file ) {
			return '';
		}

		$template_args = array(
			'posts'    => $posts,
			'title'    => $title,
			'target'   => in_array( $target, self::TARGETS, true ) ? $target : '_self',
			'template' => $template_name,
			'post_id'  => $post_id,
		);

		ob_start();
		load_template( $template_file, false, $template_args );
		$html = (string) ob_get_clean();

		if ( $cacheable ) {
			MVweb_SML_Cache::set( $cache_key, $html, MONTH_IN_SECONDS );
		}

		return $html;
	}

	/**
	 * Build the cache key for a (post, current language) pair.
	 *
	 * Centralised so MVweb_SML_Public::flush_post_cache() can reuse the exact
	 * same shape when invalidating every language variant at once.
	 *
	 * @since 1.0.0
	 * @param int         $post_id Source post ID.
	 * @param string|null $lang    Optional language code override. Defaults to the
	 *                             current frontend language.
	 * @return string
	 */
	public static function cache_key( $post_id, $lang = null ) {
		if ( null === $lang ) {
			$lang = class_exists( 'MVweb_SML_I18n' ) ? MVweb_SML_I18n::current_language() : 'none';
		}
		$lang = sanitize_key( (string) $lang );
		if ( '' === $lang ) {
			$lang = 'none';
		}
		return 'related_' . (int) $post_id . '_' . $lang;
	}

	/**
	 * Collect related post objects for a given source post.
	 *
	 * Resolution order — first fill from `_links`, then extend from the
	 * current cluster, then fall back to shared taxonomy terms. Each stage
	 * deduplicates against the accumulator and stops when $count is reached.
	 *
	 * @since 1.0.0
	 * @param int   $post_id Current post ID.
	 * @param int   $count   Maximum number of posts to return.
	 * @param array $args    Optional filters: post_types (array), category (array of term slugs).
	 * @return WP_Post[] Ordered list of candidate posts.
	 */
	public static function get_related( $post_id, $count, $args = array() ) {
		global $wpdb;

		$post_id = (int) $post_id;
		$count   = max( 1, (int) $count );
		if ( $post_id <= 0 ) {
			return array();
		}

		$disabled_ids        = array_map( 'intval', (array) mvweb_sml_get_setting( 'disabled_post_ids', array() ) );
		$exclude             = array_fill_keys( $disabled_ids, true );
		$exclude[ $post_id ] = true;

		$collected = array(); // target_id => score.

		// Stage 1: _links table (approved + auto).
		$links_table = mvweb_sml_table( 'links' );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT target_id, MAX(score) AS score FROM `{$links_table}` WHERE source_id = %d AND status IN ('approved','auto') GROUP BY target_id ORDER BY score DESC",
				$post_id
			),
			ARRAY_A
		);
		// phpcs:enable

		foreach ( (array) $rows as $row ) {
			$tid = (int) $row['target_id'];
			if ( $tid <= 0 || isset( $exclude[ $tid ] ) || isset( $collected[ $tid ] ) ) {
				continue;
			}
			// Explicit (approved/auto) links always outrank the heuristic cluster
			// and taxonomy fallbacks below; the overlap score only orders the
			// explicit links among themselves (it may legitimately be 0).
			$collected[ $tid ] = 1000.0 + (float) $row['score'];
		}

		// Stage 2: cluster siblings (pillar + sibling spokes).
		if ( count( $collected ) < $count ) {
			$cluster_ids = self::get_cluster_sibling_ids( $post_id );
			foreach ( $cluster_ids as $tid ) {
				$tid = (int) $tid;
				if ( $tid <= 0 || isset( $exclude[ $tid ] ) || isset( $collected[ $tid ] ) ) {
					continue;
				}
				// Cluster siblings always rank slightly below explicit links
				// but above pure taxonomy fallbacks.
				$collected[ $tid ] = 0.5;
				if ( count( $collected ) >= $count * 2 ) {
					break;
				}
			}
		}

		// Stage 3: taxonomy fallback (only if still short).
		if ( count( $collected ) < $count ) {
			$fallback_ids = self::get_taxonomy_fallback_ids( $post_id, $count * 2 );
			foreach ( $fallback_ids as $tid ) {
				$tid = (int) $tid;
				if ( $tid <= 0 || isset( $exclude[ $tid ] ) || isset( $collected[ $tid ] ) ) {
					continue;
				}
				$collected[ $tid ] = 0.1;
				if ( count( $collected ) >= $count * 2 ) {
					break;
				}
			}
		}

		if ( empty( $collected ) ) {
			return array();
		}

		// Language filter.
		if ( class_exists( 'MVweb_SML_I18n' ) ) {
			$ids     = array_keys( $collected );
			$allowed = MVweb_SML_I18n::filter_post_ids_by_language( $ids, $post_id );
			$allow   = array_flip( array_map( 'intval', $allowed ) );
			foreach ( array_keys( $collected ) as $tid ) {
				if ( ! isset( $allow[ (int) $tid ] ) ) {
					unset( $collected[ $tid ] );
				}
			}
		}

		if ( empty( $collected ) ) {
			return array();
		}

		// Resolve WP_Post objects, honouring published status and shortcode filters.
		$allowed_cpts = ! empty( $args['post_types'] ) && is_array( $args['post_types'] )
			? array_values( array_filter( array_map( 'sanitize_key', $args['post_types'] ) ) )
			: array();

		$category_slugs = ! empty( $args['category'] ) && is_array( $args['category'] )
			? array_values( array_filter( array_map( 'sanitize_title', $args['category'] ) ) )
			: array();

		arsort( $collected );

		$posts = array();
		foreach ( $collected as $tid => $score ) {
			if ( count( $posts ) >= $count ) {
				break;
			}
			$post = get_post( (int) $tid );
			if ( ! $post || 'publish' !== $post->post_status ) {
				continue;
			}
			if ( ! empty( $allowed_cpts ) && ! in_array( $post->post_type, $allowed_cpts, true ) ) {
				continue;
			}
			if ( ! empty( $category_slugs ) && ! self::post_matches_category( $post, $category_slugs ) ) {
				continue;
			}
			$posts[] = $post;
		}

		return $posts;
	}

	/**
	 * Insert the related block after the N-th closing `</p>` tag.
	 *
	 * Note: the count includes every `</p>` in the content, including those
	 * nested inside `<blockquote>` and similar containers. For posts that mix
	 * quotations with the `after_paragraph` injection mode, prefer
	 * `related_position = after_content` to avoid landing the block mid-quote.
	 *
	 * Falls back to appending at the end when the content has fewer paragraphs
	 * than requested.
	 *
	 * @since 1.0.0
	 * @param string $content     Original HTML.
	 * @param string $injection   Block HTML to insert.
	 * @param int    $after_index 1-based paragraph index.
	 * @return string
	 */
	private static function insert_after_paragraph( $content, $injection, $after_index ) {
		$parts = preg_split( '~(</p>)~i', $content, -1, PREG_SPLIT_DELIM_CAPTURE );
		if ( false === $parts || count( $parts ) < 2 ) {
			return $content . $injection;
		}

		// $parts is [text, '</p>', text, '</p>', ...]. Paragraph N ends at index (2*N - 1).
		$target = ( $after_index * 2 ) - 1;
		if ( ! isset( $parts[ $target ] ) ) {
			return $content . $injection;
		}

		$before = implode( '', array_slice( $parts, 0, $target + 1 ) );
		$after  = implode( '', array_slice( $parts, $target + 1 ) );

		return $before . $injection . $after;
	}

	/**
	 * Return cluster sibling post IDs for a given post (pillar + spokes).
	 *
	 * Works even when the cluster feature (phase 10) is not yet wired in —
	 * simply returns an empty array if the tables do not exist.
	 *
	 * @since 1.0.0
	 * @param int $post_id Current post ID.
	 * @return int[]
	 */
	private static function get_cluster_sibling_ids( $post_id ) {
		global $wpdb;

		$cp_table = mvweb_sml_table( 'cluster_posts' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$cluster_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT cluster_id FROM `{$cp_table}` WHERE post_id = %d",
				$post_id
			)
		);
		// phpcs:enable

		if ( empty( $cluster_ids ) ) {
			return array();
		}

		$placeholders = implode( ',', array_fill( 0, count( $cluster_ids ), '%d' ) );
		$params       = array_map( 'intval', $cluster_ids );
		$params[]     = (int) $post_id;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sibling_ids = $wpdb->get_col(
			$wpdb->prepare(
				// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
				"SELECT DISTINCT post_id FROM `{$cp_table}` WHERE cluster_id IN ({$placeholders}) AND post_id <> %d",
				$params
			)
		);
		// phpcs:enable

		return array_map( 'intval', (array) $sibling_ids );
	}

	/**
	 * Return post IDs that share taxonomy terms with the current post.
	 *
	 * Walks every public taxonomy attached to the post's type and collects up
	 * to `$limit` distinct object IDs from their terms.
	 *
	 * @since 1.0.0
	 * @param int $post_id Current post ID.
	 * @param int $limit   Maximum number of IDs to return.
	 * @return int[]
	 */
	private static function get_taxonomy_fallback_ids( $post_id, $limit ) {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return array();
		}

		$taxonomies = get_object_taxonomies( $post->post_type, 'names' );
		if ( empty( $taxonomies ) ) {
			return array();
		}

		$collected = array();
		foreach ( $taxonomies as $taxonomy ) {
			$terms = wp_get_post_terms( $post_id, $taxonomy, array( 'fields' => 'ids' ) );
			if ( is_wp_error( $terms ) || empty( $terms ) ) {
				continue;
			}
			foreach ( $terms as $term_id ) {
				$ids = get_objects_in_term( (int) $term_id, $taxonomy );
				if ( is_wp_error( $ids ) || empty( $ids ) ) {
					continue;
				}
				foreach ( $ids as $id ) {
					$id = (int) $id;
					if ( $id === (int) $post_id ) {
						continue;
					}
					$collected[ $id ] = true;
					if ( count( $collected ) >= $limit ) {
						break 3;
					}
				}
			}
		}

		return array_keys( $collected );
	}

	/**
	 * Check whether a post belongs to any of the given `category` term slugs.
	 *
	 * Only the built-in `category` taxonomy is consulted — the shortcode
	 * `category` attribute is documented accordingly.
	 *
	 * @since 1.0.0
	 * @param WP_Post  $post  Post object.
	 * @param string[] $slugs Category term slugs.
	 * @return bool
	 */
	private static function post_matches_category( $post, $slugs ) {
		$terms = wp_get_post_terms( $post->ID, 'category', array( 'fields' => 'slugs' ) );
		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return false;
		}
		foreach ( $slugs as $slug ) {
			if ( in_array( $slug, $terms, true ) ) {
				return true;
			}
		}
		return false;
	}
}
