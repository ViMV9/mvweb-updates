<?php
/**
 * Frontend controller: registers the_content filter and conditional asset enqueue.
 *
 * Kept intentionally small — the heavy lifting lives in MVweb_SML_Linker and
 * MVweb_SML_DOM_Scanner. This class only wires hooks and handles cache
 * invalidation that is logically tied to the frontend output.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Public
 *
 * @since 1.0.0
 */
class MVweb_SML_Public {

	/**
	 * Whether init() has already run.
	 *
	 * @var bool
	 */
	private static $booted = false;

	/**
	 * Register frontend hooks.
	 *
	 * Called by MVweb_SML_Loader on `init`.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		// Frontend output is gated by the master kill switch.
		if ( ! mvweb_sml_get_setting( 'enabled' ) ) {
			// Cache invalidation hooks still need to fire so toggling the
			// setting back on does not show stale content.
			self::register_invalidation_hooks();
			return;
		}

		add_filter( 'the_content', array( 'MVweb_SML_Linker', 'apply' ), 999 );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );

		if ( class_exists( 'MVweb_SML_Related' ) ) {
			MVweb_SML_Related::init();
		}

		self::register_invalidation_hooks();
	}

	/**
	 * Register cache invalidation hooks.
	 *
	 * Bumped on save_post / deleted_post (per-post flush) and on settings
	 * updates (full flush).
	 *
	 * @since 1.0.0
	 * @return void
	 */
	private static function register_invalidation_hooks() {
		add_action( 'save_post', array( __CLASS__, 'flush_post_cache' ), 20, 1 );
		add_action( 'deleted_post', array( __CLASS__, 'flush_post_cache' ), 20, 1 );
		add_action( 'update_option_mvweb_sml_settings', array( __CLASS__, 'flush_all_cache' ), 20, 0 );

		// When a *target* post changes (edited title/permalink, or published /
		// unpublished / deleted), every source that links to it holds stale
		// cached HTML — the linker resolves the target's title and permalink at
		// render time. Flush those sources too, not just the changed post itself.
		add_action( 'save_post', array( __CLASS__, 'flush_incoming_sources' ), 20, 1 );
		add_action( 'deleted_post', array( __CLASS__, 'flush_incoming_sources' ), 20, 1 );
		add_action( 'transition_post_status', array( __CLASS__, 'on_transition_post_status' ), 20, 3 );

		// Admin link changes (bulk approve/reject, keyword edits) call
		// MVweb_SML_Cache::flush_post(), which fires this action. Clearing the
		// language-suffixed linker/related variants here keeps the frontend in
		// sync without waiting for the next save_post.
		add_action( 'mvweb_sml_flush_post_cache', array( __CLASS__, 'flush_post_language_variants' ), 20, 1 );
	}

	/**
	 * Conditionally enqueue the public stylesheet on supported singular pages.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function enqueue_assets() {
		if ( ! is_singular( mvweb_sml_supported_post_types() ) ) {
			return;
		}

		$rel_css     = 'public/css/public.min.css';
		$abs_css     = MVWEB_SML_PATH . $rel_css;
		$plain_css   = MVWEB_SML_PATH . 'public/css/public.css';
		$css_handle  = 'mvweb-sml-public';
		$css_url     = MVWEB_SML_URL . $rel_css;
		$css_version = MVWEB_SML_VERSION;

		if ( ! file_exists( $abs_css ) && file_exists( $plain_css ) ) {
			$css_url = MVWEB_SML_URL . 'public/css/public.css';
		}

		wp_enqueue_style( $css_handle, $css_url, array(), $css_version );

		// Click-tracking beacon — only when enabled and we have a source post.
		if ( class_exists( 'MVweb_SML_Clicks' ) && MVweb_SML_Clicks::is_enabled() ) {
			$source_id = (int) get_queried_object_id();
			if ( $source_id > 0 ) {
				$rel_js = 'public/js/track.min.js';
				$abs_js = MVWEB_SML_PATH . $rel_js;
				$js_url = MVWEB_SML_URL . $rel_js;
				if ( ! file_exists( $abs_js ) && file_exists( MVWEB_SML_PATH . 'public/js/track.js' ) ) {
					$js_url = MVWEB_SML_URL . 'public/js/track.js';
				}

				wp_enqueue_script( 'mvweb-sml-track', $js_url, array(), $css_version, true );
				wp_localize_script(
					'mvweb-sml-track',
					'mvwebSmlTrack',
					array(
						'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
						'action'    => MVweb_SML_Clicks::ACTION,
						'source'    => $source_id,
						'linkClass' => sanitize_html_class( (string) mvweb_sml_get_setting( 'link_css_class', 'mvweb-sml-link' ) ),
					)
				);
			}
		}
	}

	/**
	 * Drop the cached linker/related output for a post.
	 *
	 * Save hooks run in whatever UI language the editor happens to use, so
	 * we cannot simply flush `linker_<post>_<current_lang>` — the other
	 * languages would keep stale entries until TTL expiry. Instead we ask
	 * the i18n adapter for every active language code on the site and flush
	 * each variant explicitly.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function flush_post_cache( $post_id ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return;
		}

		// Cache::flush_post handles the un-suffixed shape and emits the
		// `mvweb_sml_flush_post_cache` action, which in turn triggers
		// flush_post_language_variants() below — so the language-suffixed
		// linker/related entries are cleared through a single path shared with
		// admin-side link changes.
		MVweb_SML_Cache::flush_post( $post_id );
	}

	/**
	 * Drop the language-suffixed linker/related cache variants for a post.
	 *
	 * Save hooks run in whatever UI language the editor happens to use, so we
	 * cannot simply flush `linker_<post>_<current_lang>` — the other languages
	 * would keep stale entries until TTL expiry. We ask the i18n adapter for
	 * every active language code and flush each variant explicitly.
	 *
	 * Hooked on `mvweb_sml_flush_post_cache` so both frontend saves and admin
	 * link edits (bulk approve/reject) converge here.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function flush_post_language_variants( $post_id ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return;
		}

		$languages = class_exists( 'MVweb_SML_I18n' )
			? MVweb_SML_I18n::active_languages()
			: array( 'none' );

		foreach ( $languages as $lang ) {
			if ( class_exists( 'MVweb_SML_Linker' ) ) {
				MVweb_SML_Cache::delete( MVweb_SML_Linker::cache_key( $post_id, $lang ) );
			}
			if ( class_exists( 'MVweb_SML_Related' ) ) {
				MVweb_SML_Cache::delete( MVweb_SML_Related::cache_key( $post_id, $lang ) );
			}
		}
	}

	/**
	 * `transition_post_status` callback — flush sources linking to this target
	 * whenever its published state actually changes (publish ↔ draft/pending/
	 * trash). A publish makes its inbound links appear; an un-publish makes them
	 * vanish, since the linker only links `publish` targets.
	 *
	 * @since 1.0.0
	 * @param string  $new_status New post status.
	 * @param string  $old_status Previous post status.
	 * @param WP_Post $post       Post object.
	 * @return void
	 */
	public static function on_transition_post_status( $new_status, $old_status, $post ) {
		if ( $new_status === $old_status ) {
			return;
		}
		if ( $post instanceof WP_Post ) {
			self::flush_incoming_sources( (int) $post->ID );
		}
	}

	/**
	 * Drop the cached output of every source post that links to a given target.
	 *
	 * The linker resolves each target's title and permalink at render time, so a
	 * change to the target leaves stale HTML cached against the *sources*. We
	 * flush those (the changed post's own cache is handled separately by
	 * flush_post_cache). Bounded by MVweb_SML_Bulk::MAX_BULK_FILTER — a target
	 * with more inbound links than that falls back to a single full flush.
	 *
	 * @since 1.0.0
	 * @param int $target_id Target post ID.
	 * @return void
	 */
	public static function flush_incoming_sources( $target_id ) {
		$target_id = (int) $target_id;
		if ( $target_id <= 0 ) {
			return;
		}

		// On the save_post path this fires for autosaves and revisions too — a
		// revision is never a real link target, so skip the query entirely
		// (mirrors the indexer's own save_post guard).
		if ( wp_is_post_revision( $target_id ) || wp_is_post_autosave( $target_id ) ) {
			return;
		}

		global $wpdb;
		$table = mvweb_sml_table( 'links' );
		$cap   = class_exists( 'MVweb_SML_Bulk' ) ? MVweb_SML_Bulk::MAX_BULK_FILTER : 2000;

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$source_ids = $wpdb->get_col(
			$wpdb->prepare(
				"SELECT DISTINCT source_id FROM `{$table}` WHERE target_id = %d AND status IN ('approved','auto') LIMIT %d",
				$target_id,
				$cap + 1
			)
		);
		// phpcs:enable

		$source_ids = array_values( array_filter( array_map( 'intval', (array) $source_ids ) ) );
		if ( empty( $source_ids ) ) {
			return;
		}

		// Pathological fan-in: flush everything once instead of thousands of
		// per-post deletes.
		if ( count( $source_ids ) > $cap ) {
			self::flush_all_cache();
			return;
		}

		foreach ( $source_ids as $sid ) {
			self::flush_post_cache( $sid );
		}
	}

	/**
	 * Flush every cache entry the plugin owns.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function flush_all_cache() {
		MVweb_SML_Cache::flush_all();
	}
}
