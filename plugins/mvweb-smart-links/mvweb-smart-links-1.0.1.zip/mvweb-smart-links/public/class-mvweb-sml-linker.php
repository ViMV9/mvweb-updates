<?php
/**
 * Frontend linker: thin wrapper around the DOM scanner.
 *
 * Hooks into `the_content`, gathers candidates from the `_links` table and
 * post meta, applies the global blacklist and read-through cache, then asks
 * MVweb_SML_DOM_Scanner to do the actual rewriting.
 *
 * @package mvweb_sml
 * @since   1.0.0
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_SML_Linker
 *
 * @since 1.0.0
 */
class MVweb_SML_Linker {

	/**
	 * Manual postmeta link priority (highest = inserted first).
	 */
	const PRIORITY_MANUAL = 0;

	/**
	 * Approved-link priority.
	 */
	const PRIORITY_APPROVED = 10;

	/**
	 * Auto-link priority.
	 */
	const PRIORITY_AUTO = 20;

	/**
	 * Build the cache key for a (post, language) pair.
	 *
	 * Centralised so MVweb_SML_Public::flush_post_cache() can reuse the exact
	 * same shape when invalidating every language variant at once.
	 *
	 * @since 1.0.0
	 * @param int    $post_id Source post ID.
	 * @param string $lang    Language code (or self::NO_LANGUAGE sentinel).
	 * @return string
	 */
	public static function cache_key( $post_id, $lang ) {
		$lang = preg_replace( '/[^a-z0-9]+/i', '', (string) $lang );
		return 'linker_' . (int) $post_id . '_' . $lang;
	}

	/**
	 * Filter callback registered against `the_content`.
	 *
	 * @since 1.0.0
	 * @param string $content Post content.
	 * @return string
	 */
	public static function apply( $content ) {
		if ( ! is_string( $content ) || '' === $content ) {
			return $content;
		}

		if ( ! mvweb_sml_get_setting( 'enabled' ) ) {
			return $content;
		}

		if ( ! mvweb_sml_get_setting( 'contextual_enabled' ) ) {
			return $content;
		}

		if ( is_feed() ) {
			return $content;
		}

		if ( ! is_singular() || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		$post_id = (int) get_the_ID();
		if ( $post_id <= 0 ) {
			return $content;
		}

		$post_type = get_post_type( $post_id );
		if ( ! in_array( $post_type, mvweb_sml_supported_post_types(), true ) ) {
			return $content;
		}

		// Per-post opt-out and the global blacklists (IDs / URL globs / terms).
		if ( mvweb_sml_is_source_excluded( $post_id, $post_type ) ) {
			return $content;
		}

		// Read-through cache. Key includes the current language so Polylang
		// translations don't collide on the same post_id.
		$lang      = class_exists( 'MVweb_SML_I18n' ) ? MVweb_SML_I18n::current_language() : 'none';
		$cache_key = self::cache_key( $post_id, $lang );

		$cached = MVweb_SML_Cache::get( $cache_key );
		if ( false !== $cached && null !== $cached ) {
			return $cached;
		}

		/**
		 * Fires before contextual links are inserted into a post.
		 *
		 * @since 1.0.0
		 * @param int $post_id Post ID being processed.
		 */
		do_action( 'mvweb_sml_before_links', $post_id );

		$candidates = self::collect_candidates( $post_id, $content );

		if ( empty( $candidates ) ) {
			MVweb_SML_Cache::set( $cache_key, $content, MONTH_IN_SECONDS );
			/** This action is documented above. */
			do_action( 'mvweb_sml_after_links', $post_id );
			return $content;
		}

		$opts = self::build_scanner_options( $post_id );

		$result = MVweb_SML_DOM_Scanner::scan( $content, $post_id, $candidates, $opts );
		$html   = isset( $result['html'] ) ? (string) $result['html'] : $content;

		MVweb_SML_Cache::set( $cache_key, $html, MONTH_IN_SECONDS );

		/** This action is documented above. */
		do_action( 'mvweb_sml_after_links', $post_id );

		return $html;
	}

	/**
	 * Build the candidate list for a given source post.
	 *
	 * Order:
	 *   1. Manual targets (postmeta `_mvweb_sml_manual_targets`) — priority 0.
	 *   2. Approved entries from `_links`                       — priority 10.
	 *   3. Auto entries from `_links`                           — priority 20.
	 *
	 * Then filtered by:
	 *   - language (WPML/Polylang adapter)
	 *   - cross-CPT matrix
	 *   - already-existing <a href> targets in the source HTML
	 *
	 * @since 1.0.0
	 * @param int    $source_id Source post ID.
	 * @param string $content   Original HTML, used to detect existing links.
	 * @return array<int, array<string, mixed>>
	 */
	private static function collect_candidates( $source_id, $content ) {
		global $wpdb;

		$candidates    = array();
		$seen_target   = array();
		$source_post   = get_post( $source_id );
		$source_cpt    = $source_post ? $source_post->post_type : '';
		$cross_matrix  = (array) mvweb_sml_get_setting( 'cross_cpt_matrix', array() );
		$existing_urls = self::extract_existing_link_urls( $content );

		// 1. Manual targets from postmeta (highest priority).
		$manual_targets = get_post_meta( $source_id, '_mvweb_sml_manual_targets', true );
		if ( ! is_array( $manual_targets ) ) {
			$manual_targets = array();
		}

		// 2 + 3. Approved / auto rows from the links table.
		$links_table = mvweb_sml_table( 'links' );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT target_id, keyword, anchor, status FROM `{$links_table}` WHERE source_id = %d AND status IN ('approved','auto') ORDER BY status ASC, score DESC",
				$source_id
			),
			ARRAY_A
		);
		// phpcs:enable

		// Prime the post-object cache and pull every target's keyword rows in a
		// single batch up front. Without this, build_candidate() would N+1 on
		// get_post()/get_permalink() and Keyword_Manager::get_for_post() once
		// per candidate — 20-40 extra queries on a cold (cache-miss) render.
		$prime_ids = array();
		foreach ( $manual_targets as $tid ) {
			$tid = (int) $tid;
			if ( $tid > 0 ) {
				$prime_ids[ $tid ] = true;
			}
		}
		foreach ( (array) $rows as $row ) {
			$tid = (int) $row['target_id'];
			if ( $tid > 0 ) {
				$prime_ids[ $tid ] = true;
			}
		}

		$kw_map = array();
		if ( ! empty( $prime_ids ) ) {
			$prime_ids = array_keys( $prime_ids );
			_prime_post_caches( $prime_ids );
			if ( class_exists( 'MVweb_SML_Keyword_Manager' ) ) {
				$kw_map = MVweb_SML_Keyword_Manager::get_for_posts( $prime_ids );
			}
		}

		foreach ( $manual_targets as $target_id ) {
			$target_id = (int) $target_id;
			if ( $target_id <= 0 || $target_id === (int) $source_id ) {
				continue;
			}
			if ( isset( $seen_target[ $target_id ] ) ) {
				continue;
			}
			$target_kws = isset( $kw_map[ $target_id ] ) ? $kw_map[ $target_id ] : array();
			$cand       = self::build_candidate( $source_id, $target_id, '', self::PRIORITY_MANUAL, '', $target_kws );
			if ( null === $cand ) {
				continue;
			}
			$candidates[]              = $cand;
			$seen_target[ $target_id ] = true;
		}

		foreach ( (array) $rows as $row ) {
			$target_id = (int) $row['target_id'];
			$keyword   = (string) $row['keyword'];
			$anchor    = isset( $row['anchor'] ) ? (string) $row['anchor'] : '';
			$status    = (string) $row['status'];

			if ( $target_id <= 0 || $target_id === (int) $source_id ) {
				continue;
			}
			if ( isset( $seen_target[ $target_id ] ) ) {
				continue;
			}
			if ( '' === $keyword ) {
				continue;
			}

			$priority = ( 'approved' === $status ) ? self::PRIORITY_APPROVED : self::PRIORITY_AUTO;

			$target_kws = isset( $kw_map[ $target_id ] ) ? $kw_map[ $target_id ] : array();
			$cand       = self::build_candidate( $source_id, $target_id, $keyword, $priority, $anchor, $target_kws );
			if ( null === $cand ) {
				continue;
			}
			$candidates[]              = $cand;
			$seen_target[ $target_id ] = true;
		}

		// Language filter.
		if ( class_exists( 'MVweb_SML_I18n' ) && ! empty( $candidates ) ) {
			$ids        = wp_list_pluck( $candidates, 'target_id' );
			$allowed    = MVweb_SML_I18n::filter_post_ids_by_language( $ids, $source_id );
			$allow_set  = array_flip( array_map( 'intval', $allowed ) );
			$candidates = array_values(
				array_filter(
					$candidates,
					static function ( $c ) use ( $allow_set ) {
						return isset( $allow_set[ (int) $c['target_id'] ] );
					}
				)
			);
		}

		// Cross-CPT matrix filter (ТЗ §3.2). Empty matrix = backward-compat (allow everything).
		if ( ! empty( $cross_matrix ) && ! empty( $candidates ) ) {
			$candidates = array_values(
				array_filter(
					$candidates,
					static function ( $c ) use ( $cross_matrix, $source_cpt ) {
						$target_cpt = get_post_type( (int) $c['target_id'] );
						if ( ! $target_cpt ) {
							return false;
						}
						return ! empty( $cross_matrix[ $source_cpt ][ $target_cpt ] );
					}
				)
			);
		}

		// Drop candidates whose permalink already appears in the original content.
		if ( ! empty( $existing_urls ) && ! empty( $candidates ) ) {
			$candidates = array_values(
				array_filter(
					$candidates,
					static function ( $c ) use ( $existing_urls ) {
						$href = isset( $c['permalink'] ) ? self::normalize_url( (string) $c['permalink'] ) : '';
						return '' !== $href && ! isset( $existing_urls[ $href ] );
					}
				)
			);
		}

		/**
		 * Filter the final list of outgoing link candidates for a post.
		 *
		 * Fires after language, cross-CPT and duplicate-URL filters. Each
		 * candidate is an associative array with `target_id`, `keyword`,
		 * `permalink`, `priority`, `anchor` and `title` keys. Return an
		 * empty array to suppress contextual links for the post.
		 *
		 * @since 1.0.0
		 *
		 * @example
		 *     add_filter( 'mvweb_sml_links', function ( $candidates, $source_id ) {
		 *         return array_slice( $candidates, 0, 5 );
		 *     }, 10, 2 );
		 *
		 * @param array<int, array<string, mixed>> $candidates Ordered candidate list.
		 * @param int                              $source_id  Source post ID.
		 */
		$candidates = (array) apply_filters( 'mvweb_sml_links', $candidates, (int) $source_id );

		return $candidates;
	}

	/**
	 * Build a single candidate descriptor (or null if the target is invalid).
	 *
	 * @since 1.0.0
	 * @param int        $source_id Source post ID.
	 * @param int        $target_id Target post ID.
	 * @param string     $keyword   Keyword text. Empty string allowed for manual targets — we
	 *                              fall back to keywords stored against the target post.
	 * @param int        $priority  Insertion priority (lower = first).
	 * @param string     $anchor    Optional anchor override.
	 * @param array|null $target_kws Pre-fetched keyword rows for the target (batch
	 *                               path); null falls back to a per-post query.
	 * @return array{target_id:int,keyword:string,synonyms:string[],permalink:string,priority:int,anchor:?string,title:string}|null
	 */
	private static function build_candidate( $source_id, $target_id, $keyword, $priority, $anchor = '', $target_kws = null ) {
		$target_post = get_post( $target_id );
		if ( ! $target_post || 'publish' !== $target_post->post_status ) {
			return null;
		}

		$permalink = (string) get_permalink( $target_id );
		if ( '' === $permalink ) {
			return null;
		}

		// Keyword rows stored against the target post — used both to fill an
		// empty keyword (manual targets) and to gather synonyms for whichever
		// keyword we end up matching on. Callers on the frontend pass these in
		// pre-fetched (batch); null means resolve them here.
		if ( ! is_array( $target_kws ) ) {
			$target_kws = class_exists( 'MVweb_SML_Keyword_Manager' )
				? MVweb_SML_Keyword_Manager::get_for_post( $target_id )
				: array();
		}

		// For manual targets without an explicit keyword, pull the first
		// keyword stored against the target post; if none exist, fall back to
		// the post title so the link can still be inserted somewhere it
		// matches in prose.
		if ( '' === $keyword ) {
			if ( ! empty( $target_kws ) ) {
				$keyword = (string) $target_kws[0]['keyword'];
			}
			if ( '' === $keyword ) {
				$keyword = (string) get_the_title( $target_id );
			}
		}

		if ( '' === $keyword ) {
			return null;
		}

		return array(
			'target_id' => (int) $target_id,
			'keyword'   => $keyword,
			'synonyms'  => self::synonyms_for_keyword( $target_kws, $keyword ),
			'permalink' => $permalink,
			'priority'  => (int) $priority,
			'anchor'    => '' !== $anchor ? $anchor : null,
			'title'     => $target_post->post_title,
		);
	}

	/**
	 * Collect the synonyms registered against a keyword on the target post.
	 *
	 * Synonyms widen the match: a link keyed on «джойстик» should also fire on
	 * «геймпад»/«контроллер» if the author registered them. Morphology applies
	 * to each synonym independently in the DOM scanner, so they inflect too.
	 * The match is case-insensitive on the keyword text.
	 *
	 * @since 1.0.0
	 * @param array<int, array<string, mixed>> $target_kws Keyword rows for the target.
	 * @param string                           $keyword    The keyword being linked on.
	 * @return string[] Synonym strings (may be empty).
	 */
	private static function synonyms_for_keyword( array $target_kws, $keyword ) {
		$needle = mb_strtolower( trim( (string) $keyword ), 'UTF-8' );
		if ( '' === $needle ) {
			return array();
		}

		foreach ( $target_kws as $row ) {
			$row_kw = mb_strtolower( trim( (string) ( isset( $row['keyword'] ) ? $row['keyword'] : '' ) ), 'UTF-8' );
			if ( $row_kw === $needle && ! empty( $row['synonyms'] ) && is_array( $row['synonyms'] ) ) {
				return array_values( array_filter( array_map( 'strval', $row['synonyms'] ) ) );
			}
		}

		return array();
	}

	/**
	 * Build the options array passed to MVweb_SML_DOM_Scanner::scan().
	 *
	 * Resolves the per-page link cap (auto vs explicit number) and applies
	 * the `mvweb_sml_link_attributes` filter so themes can append rel/data
	 * attributes to every inserted link.
	 *
	 * @since 1.0.0
	 * @param int $post_id Source post ID.
	 * @return array<string, mixed>
	 */
	private static function build_scanner_options( $post_id ) {
		$gap_words   = (int) mvweb_sml_get_setting( 'links_gap_words', 50 );
		$max_per_par = (int) mvweb_sml_get_setting( 'links_max_per_paragraph', 0 );
		$max_setting = mvweb_sml_get_setting( 'links_max_per_page', 'auto' );
		$link_class  = (string) mvweb_sml_get_setting( 'link_css_class', 'mvweb-sml-link' );
		$link_target = (string) mvweb_sml_get_setting( 'link_target', '_self' );
		$link_rel    = mvweb_sml_get_setting( 'link_nofollow', false ) ? 'nofollow' : '';

		if ( 'auto' === $max_setting ) {
			$word_count = (int) self::get_post_word_count( $post_id );
			$max_links  = (int) max( 2, min( 10, (int) floor( $word_count / 500 ) ) );
		} else {
			$max_links = max( 0, (int) $max_setting );
		}

		$base_attributes = array();

		/**
		 * Filter the attributes appended to every link inserted by the linker.
		 *
		 * @since 1.0.0
		 * @param array $attributes Map of HTML attribute name => value.
		 * @param int   $post_id    Source post ID.
		 * @param int   $target_id  Target post ID. 0 in this base call — themes
		 *                          that need per-target tweaks should hook into
		 *                          their own filter via the candidate list.
		 */
		$attributes = apply_filters( 'mvweb_sml_link_attributes', $base_attributes, $post_id, 0 );
		if ( ! is_array( $attributes ) ) {
			$attributes = array();
		}

		return array(
			'links_gap_words'         => $gap_words,
			'links_max_per_paragraph' => $max_per_par,
			'links_max_per_page'      => $max_links,
			'link_class'              => $link_class,
			'link_target'             => $link_target,
			'link_rel'                => $link_rel,
			'extra_attributes'        => $attributes,
			// Emit a data-sml-t="<target id>" attribute so the click-tracking
			// beacon can attribute a click without resolving the href back to a
			// post. Only when the feature is enabled, to keep cached HTML lean.
			'track_target'            => class_exists( 'MVweb_SML_Clicks' ) && MVweb_SML_Clicks::is_enabled(),
		);
	}

	/**
	 * Read the cached word count for a post (Indexer fills this).
	 *
	 * Falls back to a live strip+count when the post has not been indexed yet.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return int
	 */
	private static function get_post_word_count( $post_id ) {
		global $wpdb;

		$table = mvweb_sml_table( 'index' );
		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wc = $wpdb->get_var(
			$wpdb->prepare(
				"SELECT word_count FROM `{$table}` WHERE post_id = %d LIMIT 1",
				$post_id
			)
		);
		// phpcs:enable

		if ( null !== $wc ) {
			return (int) $wc;
		}

		$content = (string) get_post_field( 'post_content', $post_id );
		$plain   = wp_strip_all_tags( strip_shortcodes( $content ) );
		return MVweb_SML_DOM_Scanner::count_words( $plain );
	}

	/**
	 * Extract a flat lookup of URLs that already appear as <a href> in HTML.
	 *
	 * @since 1.0.0
	 * @param string $content HTML content.
	 * @return array<string, true>
	 */
	private static function extract_existing_link_urls( $content ) {
		$out = array();
		if ( '' === $content ) {
			return $out;
		}
		if ( preg_match_all( '/<a\b[^>]*\bhref\s*=\s*([\'"])(.*?)\1/i', $content, $m ) ) {
			foreach ( $m[2] as $href ) {
				$href = self::normalize_url( (string) $href );
				if ( '' !== $href ) {
					$out[ $href ] = true;
				}
			}
		}
		return $out;
	}

	/**
	 * Normalize a URL for trailing-slash-insensitive comparison.
	 *
	 * WordPress permalinks may or may not carry a trailing slash depending on
	 * the site permalink structure, while hand-written links in the content can
	 * use either form. Stripping the trailing slash before comparison prevents
	 * the same target being linked twice.
	 *
	 * @since 1.0.0
	 * @param string $url Raw URL.
	 * @return string Normalized URL (trimmed, no trailing slash).
	 */
	private static function normalize_url( $url ) {
		$url = trim( (string) $url );
		if ( '' === $url ) {
			return '';
		}
		return untrailingslashit( $url );
	}
}
