<?php
/**
 * Schema output for MVweb Local Business.
 *
 * Anti-duplicate strategy (SPEC §4):
 *   1. Yoast active   → augment its Organization node (same @id) via
 *                       `wpseo_schema_organization`.
 *   2. Rank Math active → augment/inject through `rank_math/json_ld`.
 *   3. Neither         → print a standalone node in wp_head.
 *
 * The node describes the company rather than the page, so it is emitted on
 * every page except the 404 screen — one @id, no duplicates.
 *
 * The plugin never emits a self-serving aggregateRating/review (Google policy);
 * the reviews aggregator is exposed only as a sameAs profile link.
 *
 * @package mvweb_lb
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Schema controller.
 *
 * @since 1.0.0
 */
final class MVweb_LB_Schema {

	/**
	 * Node keys where an existing SEO-plugin value wins over ours.
	 *
	 * Only `url` — the SEO plugin resolves the home URL its own way (Yoast uses
	 * the home indexable permalink) and the value is ours anyway. Everything the
	 * admin typed into this plugin wins: a field in the form must be the field
	 * in the markup, otherwise the setting silently does nothing (Yoast falls
	 * back to the site title when its own organization name is empty).
	 *
	 * @var array<int, string>
	 */
	const KEEP_EXISTING = array( 'url' );

	/**
	 * Whether our data was merged into an SEO plugin's graph this request.
	 *
	 * Set by the Yoast/Rank Math filters (which run early on wp_head). The
	 * wp_head fallback checks it late (priority 99) and only prints a standalone
	 * node when no integration happened — so an active SEO plugin that does not
	 * emit an Organization node on this page still gets our markup.
	 *
	 * @var bool
	 */
	private static $integrated = false;

	/**
	 * Wire hooks.
	 *
	 * The Yoast/Rank Math filters only fire when those plugins are active, so
	 * registering them unconditionally is harmless.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_filter( 'wpseo_schema_organization', array( __CLASS__, 'filter_yoast' ), 20 );
		add_filter( 'rank_math/json_ld', array( __CLASS__, 'filter_rankmath' ), 20, 2 );
		add_action( 'wp_head', array( __CLASS__, 'maybe_print_fallback' ), 99 );
	}

	/**
	 * Build the Organization + LocalBusiness node (without @context).
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $s Settings.
	 * @return array<string, mixed>
	 */
	public static function build_node( array $s ) {
		$node = array(
			'@type' => mvweb_lb_build_type( $s ),
			'@id'   => home_url( '/' ) . '#organization',
			'name'  => (string) $s['name'],
			'url'   => home_url( '/' ),
		);

		if ( '' !== (string) $s['alt_name'] ) {
			$node['alternateName'] = (string) $s['alt_name'];
		}
		if ( '' !== (string) $s['description'] ) {
			$node['description'] = (string) $s['description'];
		}

		$address = mvweb_lb_build_address( $s );
		if ( count( $address ) > 1 ) {
			$node['address'] = $address;
		}

		if ( '' !== (string) $s['lat'] && '' !== (string) $s['lng'] ) {
			$node['geo'] = array(
				'@type'     => 'GeoCoordinates',
				'latitude'  => (string) $s['lat'],
				'longitude' => (string) $s['lng'],
			);
		}

		if ( '' !== (string) $s['phone'] ) {
			$node['telephone'] = (string) $s['phone'];
		}
		if ( '' !== (string) $s['email'] ) {
			$node['email'] = (string) $s['email'];
		}

		$points = mvweb_lb_build_contact_points( $s );
		if ( ! empty( $points ) ) {
			$node['contactPoint'] = $points;
		}

		$hours = mvweb_lb_build_hours( $s );
		if ( ! empty( $hours ) ) {
			$node['openingHoursSpecification'] = $hours;
		}

		if ( '' !== (string) $s['price_range'] ) {
			$node['priceRange'] = (string) $s['price_range'];
		}

		if ( ! empty( $s['payments'] ) && is_array( $s['payments'] ) ) {
			$node['paymentAccepted'] = implode( ', ', array_map( 'strval', $s['payments'] ) );
		}

		if ( '' !== (string) $s['logo'] ) {
			$node['logo'] = (string) $s['logo'];
		}

		$images = array();
		if ( '' !== (string) $s['facade'] ) {
			$images[] = (string) $s['facade'];
		}
		if ( ! empty( $s['gallery'] ) && is_array( $s['gallery'] ) ) {
			foreach ( $s['gallery'] as $image ) {
				$images[] = (string) $image;
			}
		}
		if ( ! empty( $images ) ) {
			$node['image'] = array_values( array_unique( $images ) );
		}

		$sameas = mvweb_lb_build_sameas( $s );
		if ( ! empty( $sameas ) ) {
			$node['sameAs'] = $sameas;
		}

		if ( preg_match( '/^\d{4}$/', (string) $s['founded'] ) ) {
			$node['foundingDate'] = (string) $s['founded'];
		}
		if ( '' !== (string) $s['slogan'] ) {
			$node['slogan'] = (string) $s['slogan'];
		}
		// The service area only means something when the company travels to clients.
		if ( ! empty( $s['serves_onsite'] ) && ! empty( $s['area_served'] ) && is_array( $s['area_served'] ) ) {
			$node['areaServed'] = array_values( $s['area_served'] );
		}

		if ( '' !== (string) $s['video'] ) {
			$node['subjectOf'] = array(
				'@type' => 'VideoObject',
				'name'  => (string) $s['name'],
				'url'   => (string) $s['video'],
			);
		}

		return $node;
	}

	/**
	 * Merge our LocalBusiness node into an existing Organization graph piece.
	 *
	 * Preserves the target's @id and its url, always upgrades @type, unions
	 * sameAs and image, and overwrites everything else with our values (see
	 * KEEP_EXISTING).
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $target Existing node.
	 * @param array<string, mixed> $node   Our node.
	 * @return array<string, mixed>
	 */
	private static function merge_into( array $target, array $node ) {
		// Keep the target's @id if it has one.
		if ( empty( $target['@id'] ) && isset( $node['@id'] ) ) {
			$target['@id'] = $node['@id'];
		}
		unset( $node['@id'] );

		// Always upgrade the type.
		if ( isset( $node['@type'] ) ) {
			$target['@type'] = $node['@type'];
			unset( $node['@type'] );
		}

		// Union sameAs.
		if ( isset( $node['sameAs'] ) ) {
			$existing         = isset( $target['sameAs'] ) ? (array) $target['sameAs'] : array();
			$target['sameAs'] = array_values( array_unique( array_merge( $existing, $node['sameAs'] ) ) );
			unset( $node['sameAs'] );
		}

		// Union image with what the SEO plugin had. Yoast's image is a reference
		// to its logo ImageObject, so it must go once our own logo replaces that
		// object — otherwise the reference points at a node no longer in the graph.
		if ( isset( $node['image'] ) || isset( $node['logo'] ) ) {
			$existing = isset( $node['logo'] ) ? array() : self::as_list( isset( $target['image'] ) ? $target['image'] : array() );
			$ours     = isset( $node['image'] ) ? self::as_list( $node['image'] ) : array();
			$images   = self::unique_nodes( array_merge( $existing, $ours ) );

			if ( empty( $images ) ) {
				unset( $target['image'] );
			} else {
				$target['image'] = $images;
			}
			unset( $node['image'] );
		}

		foreach ( $node as $key => $value ) {
			if ( in_array( $key, self::KEEP_EXISTING, true ) && ! empty( $target[ $key ] ) ) {
				continue;
			}
			$target[ $key ] = $value;
		}

		return $target;
	}

	/**
	 * Normalize a JSON-LD value into a list of nodes.
	 *
	 * An associative array is a single node (e.g. `{"@id": "…#logo"}`), not a
	 * list — wrapping it keeps the merged value a proper JSON array.
	 *
	 * @since 1.0.5
	 * @param mixed $value Raw value.
	 * @return array<int, mixed>
	 */
	private static function as_list( $value ) {
		if ( null === $value || '' === $value || array() === $value ) {
			return array();
		}
		if ( ! is_array( $value ) ) {
			return array( $value );
		}
		if ( array_keys( $value ) !== range( 0, count( $value ) - 1 ) ) {
			return array( $value );
		}
		return $value;
	}

	/**
	 * Deduplicate a list that may hold both strings and nodes.
	 *
	 * @since 1.0.5
	 * @param array<int, mixed> $items Items.
	 * @return array<int, mixed>
	 */
	private static function unique_nodes( array $items ) {
		$out  = array();
		$seen = array();

		foreach ( $items as $item ) {
			$key = is_scalar( $item ) ? (string) $item : (string) wp_json_encode( $item );
			if ( isset( $seen[ $key ] ) ) {
				continue;
			}
			$seen[ $key ] = true;
			$out[]        = $item;
		}

		return $out;
	}

	/**
	 * Whether the markup may be emitted on the current request.
	 *
	 * The node describes the company, not the page, so it rides along on every
	 * page (that is what Yoast does with its own Organization node). Only the
	 * 404 screen is excluded — it represents no page of the site.
	 *
	 * @since 1.0.5
	 * @return bool
	 */
	private static function is_allowed_context() {
		return ! is_404();
	}

	/**
	 * Augment the Yoast Organization node.
	 *
	 * @since 1.0.0
	 * @param mixed $data Organization graph piece from Yoast.
	 * @return mixed
	 */
	public static function filter_yoast( $data ) {
		if ( ! is_array( $data ) || ! self::is_allowed_context() ) {
			return $data;
		}
		$s = mvweb_lb_get_settings();
		if ( ! mvweb_lb_is_ready( $s ) ) {
			return $data;
		}
		self::$integrated = true;
		return self::merge_into( $data, self::build_node( $s ) );
	}

	/**
	 * Augment the Rank Math organization node, or inject a LocalBusiness node.
	 *
	 * Rank Math keys its graph pieces by role, not by type: the organization
	 * lives in `$data['publisher']` with `@id = home_url('/#organization')`
	 * (RankMath\Schema\Publisher, verified on 1.0.276) — the same @id we build.
	 * So we look the node up by @id instead of by key name, which also covers
	 * a graph whose keys change between Rank Math versions. Our filter runs at
	 * 20, after Rank Math fills the graph on the default priority.
	 *
	 * When nothing carries our @id — the site represents a person, so the
	 * publisher is a Person node with `#person` — we add our own node instead.
	 *
	 * @since 1.0.0
	 * @param mixed $data   Associative array of schema pieces.
	 * @param mixed $jsonld Rank Math JsonLD instance (unused).
	 * @return mixed
	 */
	public static function filter_rankmath( $data, $jsonld ) {
		unset( $jsonld );
		if ( ! is_array( $data ) || ! self::is_allowed_context() ) {
			return $data;
		}
		$s = mvweb_lb_get_settings();
		if ( ! mvweb_lb_is_ready( $s ) ) {
			return $data;
		}

		$node = self::build_node( $s );
		$key  = self::find_by_id( $data, $node['@id'] );

		if ( null === $key ) {
			// Rank Math prints array_values( $data ) inside one graph with a shared
			// @context: the key never reaches the markup, so ours only has to be
			// unique enough not to overwrite a piece Rank Math put there.
			$data['mvweb_lb'] = $node;
		} else {
			$data[ $key ] = self::merge_into( $data[ $key ], $node );
		}
		self::$integrated = true;

		return $data;
	}

	/**
	 * Find the graph piece carrying a given @id.
	 *
	 * @since 1.0.5
	 * @param array<string, mixed> $data Graph pieces.
	 * @param string               $id   Node @id.
	 * @return string|int|null Key of the matching piece, null when there is none.
	 */
	private static function find_by_id( array $data, $id ) {
		foreach ( $data as $key => $piece ) {
			if ( is_array( $piece ) && isset( $piece['@id'] ) && $piece['@id'] === $id ) {
				return $key;
			}
		}

		return null;
	}

	/**
	 * Print a standalone JSON-LD node when no SEO plugin integrated our data.
	 *
	 * Runs late (priority 99) so the Yoast/Rank Math filters — which fire early
	 * on wp_head — have already set the integration flag when they emit an
	 * Organization node. If they didn't (SEO plugin active but no Organization
	 * on this page), we still output a standalone node.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function maybe_print_fallback() {
		if ( self::$integrated || ! self::is_allowed_context() ) {
			return;
		}
		$s = mvweb_lb_get_settings();
		if ( ! mvweb_lb_is_ready( $s ) ) {
			return;
		}

		$node = array( '@context' => 'https://schema.org' ) + self::build_node( $s );
		$json = wp_json_encode( $node, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if ( false === $json ) {
			return;
		}
		$json = str_replace( '</script>', '<\/script>', $json );

		// JSON is pre-encoded and </script>-guarded; not HTML-context output.
		echo '<script type="application/ld+json">' . $json . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
