<?php
/**
 * Hours tab — weekly opening hours with breaks and special days.
 *
 * @package mvweb_lb
 * @since   1.0.0
 * @var array<string, mixed> $mvweb_lb Current settings (from settings-page.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$s     = $mvweb_lb;
$hours = ! empty( $s['hours'] ) && is_array( $s['hours'] ) ? $s['hours'] : array();

$day_labels = array(
	'monday'    => __( 'Monday', 'mvweb-local-business' ),
	'tuesday'   => __( 'Tuesday', 'mvweb-local-business' ),
	'wednesday' => __( 'Wednesday', 'mvweb-local-business' ),
	'thursday'  => __( 'Thursday', 'mvweb-local-business' ),
	'friday'    => __( 'Friday', 'mvweb-local-business' ),
	'saturday'  => __( 'Saturday', 'mvweb-local-business' ),
	'sunday'    => __( 'Sunday', 'mvweb-local-business' ),
);

$special_days = ! empty( $s['special_days'] ) && is_array( $s['special_days'] ) ? $s['special_days'] : array();
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Opening hours', 'mvweb-local-business' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'When you actually receive customers and answer calls — this affects the «Open / Closed» label in search and on maps.', 'mvweb-local-business' ); ?></p>

	<div class="mvweb-lb-presets">
		<span class="mvweb-lb-presets__label"><?php esc_html_e( 'Quick fill:', 'mvweb-local-business' ); ?></span>
		<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-preset" data-preset="weekdays"><?php esc_html_e( 'Mon–Fri 9–18', 'mvweb-local-business' ); ?></button>
		<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-preset" data-preset="sixdays"><?php esc_html_e( 'Mon–Sat 10–20', 'mvweb-local-business' ); ?></button>
		<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-preset" data-preset="daily"><?php esc_html_e( 'Daily 9–21', 'mvweb-local-business' ); ?></button>
		<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-preset" data-preset="allday"><?php esc_html_e( '24/7', 'mvweb-local-business' ); ?></button>
	</div>

	<div class="mvweb-lb-hours">
		<?php foreach ( $day_labels as $day => $label ) : ?>
			<?php
			$row       = isset( $hours[ $day ] ) && is_array( $hours[ $day ] ) ? $hours[ $day ] : array();
			$closed    = ! empty( $row['closed'] );
			$allday    = ! empty( $row['allday'] );
			$intervals = ! empty( $row['intervals'] ) && is_array( $row['intervals'] ) ? $row['intervals'] : array( array( 'open' => '', 'close' => '' ) );
			?>
			<div class="mvweb-lb-hours__day" data-day="<?php echo esc_attr( $day ); ?>">
				<div class="mvweb-lb-hours__name"><?php echo esc_html( $label ); ?></div>

				<label class="mvweb-lb-hours__flag">
					<input type="checkbox" name="mvweb_lb_settings[hours][<?php echo esc_attr( $day ); ?>][closed]" value="1" class="mvweb-lb-hours__closed" <?php checked( $closed ); ?>>
					<?php esc_html_e( 'Day off', 'mvweb-local-business' ); ?>
				</label>

				<label class="mvweb-lb-hours__flag">
					<input type="checkbox" name="mvweb_lb_settings[hours][<?php echo esc_attr( $day ); ?>][allday]" value="1" class="mvweb-lb-hours__allday" <?php checked( $allday ); ?>>
					<?php esc_html_e( '24/7', 'mvweb-local-business' ); ?>
				</label>

				<div class="mvweb-lb-hours__intervals">
					<?php foreach ( array_values( $intervals ) as $i => $interval ) : ?>
						<span class="mvweb-lb-hours__interval">
							<input type="time" name="mvweb_lb_settings[hours][<?php echo esc_attr( $day ); ?>][intervals][<?php echo esc_attr( (string) $i ); ?>][open]" class="mvweb-input mvweb-input--time" value="<?php echo esc_attr( isset( $interval['open'] ) ? $interval['open'] : '' ); ?>">
							<span class="mvweb-lb-hours__dash">—</span>
							<input type="time" name="mvweb_lb_settings[hours][<?php echo esc_attr( $day ); ?>][intervals][<?php echo esc_attr( (string) $i ); ?>][close]" class="mvweb-input mvweb-input--time" value="<?php echo esc_attr( isset( $interval['close'] ) ? $interval['close'] : '' ); ?>">
							<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-hours__remove" aria-label="<?php esc_attr_e( 'Remove interval', 'mvweb-local-business' ); ?>">&times;</button>
						</span>
					<?php endforeach; ?>
				</div>

				<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-hours__add-break"><?php esc_html_e( '+ break', 'mvweb-local-business' ); ?></button>
			</div>
		<?php endforeach; ?>
	</div>

	<p class="mvweb-form-row__desc">
		<?php esc_html_e( 'Work by appointment or arrangement? Turn on «24/7» and mention it in your company description — search engines understand only exact hours, not the phrase «by arrangement».', 'mvweb-local-business' ); ?>
	</p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Special days', 'mvweb-local-business' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Holidays and one-off non-working days. Optional, but saves customers from calling on a closed day.', 'mvweb-local-business' ); ?></p>

	<div class="mvweb-lb-repeater" data-repeater="special_days">
		<div class="mvweb-lb-repeater__list">
			<?php foreach ( array_values( $special_days ) as $sd_i => $item ) : ?>
				<div class="mvweb-lb-repeater__row">
					<input type="date" name="mvweb_lb_settings[special_days][<?php echo esc_attr( (string) $sd_i ); ?>][date]" class="mvweb-input mvweb-input--narrow" value="<?php echo esc_attr( isset( $item['date'] ) ? $item['date'] : '' ); ?>">
					<input type="text" name="mvweb_lb_settings[special_days][<?php echo esc_attr( (string) $sd_i ); ?>][note]" class="mvweb-input" value="<?php echo esc_attr( isset( $item['note'] ) ? $item['note'] : '' ); ?>" placeholder="<?php esc_attr_e( 'Closed — New Year', 'mvweb-local-business' ); ?>">
					<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-repeater__remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-local-business' ); ?>">&times;</button>
				</div>
			<?php endforeach; ?>
		</div>
		<template class="mvweb-lb-repeater__template">
			<div class="mvweb-lb-repeater__row">
				<input type="date" name="mvweb_lb_settings[special_days][__i__][date]" class="mvweb-input mvweb-input--narrow" value="">
				<input type="text" name="mvweb_lb_settings[special_days][__i__][note]" class="mvweb-input" value="" placeholder="<?php esc_attr_e( 'Closed — New Year', 'mvweb-local-business' ); ?>">
				<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-repeater__remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-local-business' ); ?>">&times;</button>
			</div>
		</template>
		<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-lb-repeater__add"><?php esc_html_e( '+ add day', 'mvweb-local-business' ); ?></button>
	</div>
</div>
