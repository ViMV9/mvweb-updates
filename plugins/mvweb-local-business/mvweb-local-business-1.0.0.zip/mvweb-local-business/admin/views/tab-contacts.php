<?php
/**
 * Company tab — identity, address, contacts, messengers, geo.
 *
 * @package mvweb_lb
 * @since   1.0.0
 * @var array<string, mixed> $mvweb_lb Current settings (from settings-page.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$s = $mvweb_lb;

$countries = array(
	'RU' => __( 'Russia', 'mvweb-local-business' ),
	'BY' => __( 'Belarus', 'mvweb-local-business' ),
	'KZ' => __( 'Kazakhstan', 'mvweb-local-business' ),
	'UA' => __( 'Ukraine', 'mvweb-local-business' ),
);

$phones_extra = ! empty( $s['phones_extra'] ) && is_array( $s['phones_extra'] ) ? $s['phones_extra'] : array();
$area_served  = ! empty( $s['area_served'] ) && is_array( $s['area_served'] ) ? $s['area_served'] : array();
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'About the company', 'mvweb-local-business' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_business_type" class="mvweb-form-row__label"><?php esc_html_e( 'Business type', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_lb_business_type" name="mvweb_lb_settings[business_type]" class="mvweb-select">
				<?php foreach ( MVweb_LB_Settings::business_types() as $type => $label ) : ?>
					<option value="<?php echo esc_attr( $type ); ?>" <?php selected( $s['business_type'], $type ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Pick the option that best describes your company. If you can\'t find your field, choose «Other» — search engines will still recognize you as a local business.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_name" class="mvweb-form-row__label"><?php esc_html_e( 'Organization name', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_lb_name" name="mvweb_lb_settings[name]" class="mvweb-input" value="<?php echo esc_attr( $s['name'] ); ?>" placeholder="<?php esc_attr_e( 'Warm House LLC', 'mvweb-local-business' ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'As you write it on your sign and in documents. Required field.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_alt_name" class="mvweb-form-row__label"><?php esc_html_e( 'Short name', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_lb_alt_name" name="mvweb_lb_settings[alt_name]" class="mvweb-input" value="<?php echo esc_attr( $s['alt_name'] ); ?>" placeholder="<?php esc_attr_e( 'Warm House', 'mvweb-local-business' ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'If people more often search for you by a shortened name, add it too. Optional.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_description" class="mvweb-form-row__label"><?php esc_html_e( 'Short description', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<textarea id="mvweb_lb_description" name="mvweb_lb_settings[description]" class="mvweb-textarea" rows="3" placeholder="<?php esc_attr_e( 'Stove and fireplace repair in Saint Petersburg with on-site visits.', 'mvweb-local-business' ); ?>"><?php echo esc_textarea( $s['description'] ); ?></textarea>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'What you do and for whom — simple and short. This appears in the search snippet.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_logo" class="mvweb-form-row__label"><?php esc_html_e( 'Logo', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-lb-media" data-target="mvweb_lb_logo">
				<input type="url" id="mvweb_lb_logo" name="mvweb_lb_settings[logo]" class="mvweb-input" value="<?php echo esc_attr( $s['logo'] ); ?>" placeholder="https://example.ru/logo.png">
				<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-lb-media__pick"><?php esc_html_e( 'Choose from media library', 'mvweb-local-business' ); ?></button>
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Square image, at least 112×112 px, on a white background.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_founded" class="mvweb-form-row__label"><?php esc_html_e( 'Founding year', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" inputmode="numeric" id="mvweb_lb_founded" name="mvweb_lb_settings[founded]" class="mvweb-input mvweb-input--narrow" value="<?php echo esc_attr( $s['founded'] ); ?>" placeholder="2014">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Four digits. Optional.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_slogan" class="mvweb-form-row__label"><?php esc_html_e( 'Slogan', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_lb_slogan" name="mvweb_lb_settings[slogan]" class="mvweb-input" value="<?php echo esc_attr( $s['slogan'] ); ?>" placeholder="<?php esc_attr_e( 'We come and fix it the same day', 'mvweb-local-business' ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'One phrase about what makes you better than competitors. Optional.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Address', 'mvweb-local-business' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'The company\'s physical address. Fill it in as completely as possible — the address is required for search.', 'mvweb-local-business' ); ?></p>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_country" class="mvweb-form-row__label"><?php esc_html_e( 'Country', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_lb_country" name="mvweb_lb_settings[country]" class="mvweb-select mvweb-select--narrow">
				<?php foreach ( $countries as $code => $label ) : ?>
					<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $s['country'], $code ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_city" class="mvweb-form-row__label"><?php esc_html_e( 'City', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_lb_city" name="mvweb_lb_settings[city]" class="mvweb-input" value="<?php echo esc_attr( $s['city'] ); ?>" placeholder="<?php esc_attr_e( 'Saint Petersburg', 'mvweb-local-business' ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'In full, without abbreviations («Saint Petersburg», not «SPb»).', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_region" class="mvweb-form-row__label"><?php esc_html_e( 'Region / province', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_lb_region" name="mvweb_lb_settings[region]" class="mvweb-input" value="<?php echo esc_attr( $s['region'] ); ?>" placeholder="<?php esc_attr_e( 'Leningrad Oblast', 'mvweb-local-business' ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'May be left empty for major cities.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_street" class="mvweb-form-row__label"><?php esc_html_e( 'Street, building', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_lb_street" name="mvweb_lb_settings[street]" class="mvweb-input" value="<?php echo esc_attr( $s['street'] ); ?>" placeholder="<?php esc_attr_e( '12 Sadovaya St.', 'mvweb-local-business' ); ?>">
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_office" class="mvweb-form-row__label"><?php esc_html_e( 'Office / floor', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_lb_office" name="mvweb_lb_settings[office]" class="mvweb-input" value="<?php echo esc_attr( $s['office'] ); ?>" placeholder="<?php esc_attr_e( '3rd floor, office 305', 'mvweb-local-business' ); ?>">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Helps customers, but not required for search engines.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_postal" class="mvweb-form-row__label"><?php esc_html_e( 'Postal code', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_lb_postal" name="mvweb_lb_settings[postal]" class="mvweb-input mvweb-input--narrow" value="<?php echo esc_attr( $s['postal'] ); ?>" placeholder="190000">
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Contacts', 'mvweb-local-business' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_phone" class="mvweb-form-row__label"><?php esc_html_e( 'Phone', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="tel" id="mvweb_lb_phone" name="mvweb_lb_settings[phone]" class="mvweb-input" value="<?php echo esc_attr( $s['phone'] ); ?>" placeholder="+7 (812) 123-45-67">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Main number in international format — with country and area code. For example: +7 (812) 123-45-67.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label"><?php esc_html_e( 'Additional phone numbers', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-lb-repeater" data-repeater="phones_extra">
				<div class="mvweb-lb-repeater__list">
					<?php foreach ( $phones_extra as $phone ) : ?>
						<div class="mvweb-lb-repeater__row">
							<input type="tel" name="mvweb_lb_settings[phones_extra][]" class="mvweb-input" value="<?php echo esc_attr( $phone ); ?>">
							<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-repeater__remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-local-business' ); ?>">&times;</button>
						</div>
					<?php endforeach; ?>
				</div>
				<template class="mvweb-lb-repeater__template">
					<div class="mvweb-lb-repeater__row">
						<input type="tel" name="mvweb_lb_settings[phones_extra][]" class="mvweb-input" value="">
						<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-repeater__remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-local-business' ); ?>">&times;</button>
					</div>
				</template>
				<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-lb-repeater__add"><?php esc_html_e( '+ add phone', 'mvweb-local-business' ); ?></button>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_email" class="mvweb-form-row__label"><?php esc_html_e( 'E-mail', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="email" id="mvweb_lb_email" name="mvweb_lb_settings[email]" class="mvweb-input" value="<?php echo esc_attr( $s['email'] ); ?>" placeholder="info@example.ru">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Just the email address, without «mailto:». Make sure the mailbox is active.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_whatsapp" class="mvweb-form-row__label"><?php esc_html_e( 'WhatsApp', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_lb_whatsapp" name="mvweb_lb_settings[whatsapp]" class="mvweb-input" value="<?php echo esc_attr( $s['whatsapp'] ); ?>" placeholder="+7 (911) 000-00-00">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Number with country code. You can paste a wa.me link — we\'ll keep only the number. If it matches your phone, the field can be left empty.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_telegram" class="mvweb-form-row__label"><?php esc_html_e( 'Telegram', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_lb_telegram" name="mvweb_lb_settings[telegram]" class="mvweb-input" value="<?php echo esc_attr( $s['telegram'] ); ?>" placeholder="teplydom">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Username (@teplydom) or a t.me/teplydom link — we\'ll format it correctly.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_viber" class="mvweb-form-row__label"><?php esc_html_e( 'Viber', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_lb_viber" name="mvweb_lb_settings[viber]" class="mvweb-input" value="<?php echo esc_attr( $s['viber'] ); ?>" placeholder="+7 (911) 000-00-00">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Viber number with country code. Optional.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_max" class="mvweb-form-row__label"><?php esc_html_e( 'MAX', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="text" id="mvweb_lb_max" name="mvweb_lb_settings[max]" class="mvweb-input" value="<?php echo esc_attr( $s['max'] ); ?>" placeholder="teplydom">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'MAX messenger (VK): username or a profile link — we\'ll format it correctly. Optional.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Coordinates and service area', 'mvweb-local-business' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label"><?php esc_html_e( 'Map coordinates', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-lb-coords">
				<input type="text" inputmode="decimal" name="mvweb_lb_settings[lat]" class="mvweb-input mvweb-input--narrow" value="<?php echo esc_attr( $s['lat'] ); ?>" placeholder="<?php esc_attr_e( 'Latitude: 59.93428', 'mvweb-local-business' ); ?>">
				<input type="text" inputmode="decimal" name="mvweb_lb_settings[lng]" class="mvweb-input mvweb-input--narrow" value="<?php echo esc_attr( $s['lng'] ); ?>" placeholder="<?php esc_attr_e( 'Longitude: 30.33509', 'mvweb-local-business' ); ?>">
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Open your location on an online map (Google Maps, Yandex Maps, or 2GIS), right-click the building and copy the coordinates — latitude first, then longitude. Make sure the marker is on your building. At least 5 decimal places is recommended.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_serves_onsite" class="mvweb-form-row__label"><?php esc_html_e( 'On-site visits', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" id="mvweb_lb_serves_onsite" name="mvweb_lb_settings[serves_onsite]" value="1" <?php checked( ! empty( $s['serves_onsite'] ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'A specialist or team travels to the customer\'s site', 'mvweb-local-business' ); ?></span>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label"><?php esc_html_e( 'Service area', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-lb-repeater" data-repeater="area_served">
				<div class="mvweb-lb-repeater__list">
					<?php foreach ( $area_served as $area ) : ?>
						<div class="mvweb-lb-repeater__row">
							<input type="text" name="mvweb_lb_settings[area_served][]" class="mvweb-input" value="<?php echo esc_attr( $area ); ?>">
							<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-repeater__remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-local-business' ); ?>">&times;</button>
						</div>
					<?php endforeach; ?>
				</div>
				<template class="mvweb-lb-repeater__template">
					<div class="mvweb-lb-repeater__row">
						<input type="text" name="mvweb_lb_settings[area_served][]" class="mvweb-input" value="">
						<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-repeater__remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-local-business' ); ?>">&times;</button>
					</div>
				</template>
				<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-lb-repeater__add"><?php esc_html_e( '+ add city / district', 'mvweb-local-business' ); ?></button>
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Cities and districts you travel to. Fill in if on-site visits are enabled.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>
</div>
