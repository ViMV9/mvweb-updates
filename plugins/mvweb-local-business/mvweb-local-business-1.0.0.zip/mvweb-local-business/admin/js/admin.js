/**
 * Admin JavaScript for MVweb Local Business.
 *
 * @package mvweb_lb
 * @since   1.0.0
 */

(function () {
	'use strict';

	var cfg = window.mvwebLb || {};
	var i18n = cfg.i18n || {};

	document.addEventListener('DOMContentLoaded', function () {
		initTabs();
		initRepeaters();
		initHours();
		initMediaPickers();
		initScanner();
	});

	/**
	 * Sidebar tab navigation.
	 */
	function initTabs() {
		var links = document.querySelectorAll('.mvweb-nav__link');
		var panels = document.querySelectorAll('.mvweb-tab-content');

		if (!links.length || !panels.length) {
			return;
		}

		links.forEach(function (link) {
			link.addEventListener('click', function (event) {
				event.preventDefault();
				var target = link.getAttribute('data-tab');

				links.forEach(function (l) { l.classList.remove('mvweb-nav__link--active'); });
				panels.forEach(function (p) { p.classList.remove('active'); });

				link.classList.add('mvweb-nav__link--active');
				var panel = document.getElementById(target);
				if (panel) {
					panel.classList.add('active');
				}
			});
		});
	}

	/**
	 * Generic add/remove repeaters (phones, areas, social, gallery, special days).
	 */
	function initRepeaters() {
		document.querySelectorAll('.mvweb-lb-repeater').forEach(function (repeater) {
			var list = repeater.querySelector('.mvweb-lb-repeater__list');
			var template = repeater.querySelector('.mvweb-lb-repeater__template');
			var addBtn = repeater.querySelector('.mvweb-lb-repeater__add');

			if (!list || !template || !addBtn) {
				return;
			}

			// Monotonic index for templates that group fields with __i__ tokens.
			var counter = list.querySelectorAll('.mvweb-lb-repeater__row').length;

			addBtn.addEventListener('click', function () {
				var fragment = template.content.cloneNode(true);
				fragment.querySelectorAll('[name]').forEach(function (el) {
					el.setAttribute('name', el.getAttribute('name').split('__i__').join(String(counter)));
				});
				list.appendChild(fragment);
				counter++;
			});
		});

		// Delegated removal for every repeater row.
		document.addEventListener('click', function (event) {
			var btn = event.target.closest('.mvweb-lb-repeater__remove');
			if (!btn) {
				return;
			}
			var row = btn.closest('.mvweb-lb-repeater__row');
			if (row) {
				row.parentNode.removeChild(row);
			}
		});
	}

	/**
	 * Opening hours: presets, add/remove break interval.
	 */
	function initHours() {
		var wrap = document.querySelector('.mvweb-lb-hours');
		if (!wrap) {
			return;
		}

		var presets = {
			weekdays: { days: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday'], open: '09:00', close: '18:00' },
			sixdays: { days: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'], open: '10:00', close: '20:00' },
			daily: { days: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'], open: '09:00', close: '21:00' },
			allday: { days: ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'], allday: true }
		};

		document.querySelectorAll('.mvweb-lb-preset').forEach(function (btn) {
			btn.addEventListener('click', function () {
				applyPreset(wrap, presets[btn.getAttribute('data-preset')]);
			});
		});

		// Add break — clone the first interval of that day.
		wrap.addEventListener('click', function (event) {
			var addBtn = event.target.closest('.mvweb-lb-hours__add-break');
			if (addBtn) {
				addInterval(addBtn.closest('.mvweb-lb-hours__day'));
				return;
			}
			var rmBtn = event.target.closest('.mvweb-lb-hours__remove');
			if (rmBtn) {
				var interval = rmBtn.closest('.mvweb-lb-hours__interval');
				var box = interval && interval.parentNode;
				if (interval && box.querySelectorAll('.mvweb-lb-hours__interval').length > 1) {
					box.removeChild(interval);
					reindexIntervals(box);
				} else if (interval) {
					interval.querySelectorAll('input[type="time"]').forEach(function (el) { el.value = ''; });
				}
			}
		});
	}

	/**
	 * Renumber a day's interval inputs to a contiguous 0..n-1 sequence,
	 * so add-after-remove never reuses an index (which would collide on submit).
	 *
	 * @param {HTMLElement} box The .mvweb-lb-hours__intervals container.
	 */
	function reindexIntervals(box) {
		box.querySelectorAll('.mvweb-lb-hours__interval').forEach(function (item, idx) {
			item.querySelectorAll('input[type="time"]').forEach(function (el) {
				el.setAttribute('name', el.getAttribute('name').replace(/\[intervals\]\[\d+\]/, '[intervals][' + idx + ']'));
			});
		});
	}

	/**
	 * Apply a preset to the whole week.
	 *
	 * @param {HTMLElement} wrap   Hours wrapper.
	 * @param {Object}      preset Preset config.
	 */
	function applyPreset(wrap, preset) {
		if (!preset) {
			return;
		}
		wrap.querySelectorAll('.mvweb-lb-hours__day').forEach(function (dayEl) {
			var day = dayEl.getAttribute('data-day');
			var active = preset.days.indexOf(day) !== -1;
			var closed = dayEl.querySelector('.mvweb-lb-hours__closed');
			var allday = dayEl.querySelector('.mvweb-lb-hours__allday');

			// Collapse to a single interval.
			var box = dayEl.querySelector('.mvweb-lb-hours__intervals');
			var intervals = box.querySelectorAll('.mvweb-lb-hours__interval');
			for (var k = 1; k < intervals.length; k++) {
				box.removeChild(intervals[k]);
			}
			var first = box.querySelector('.mvweb-lb-hours__interval');
			var times = first ? first.querySelectorAll('input[type="time"]') : [];

			if (closed) { closed.checked = !active; }
			if (allday) { allday.checked = active && !!preset.allday; }
			if (times.length === 2) {
				times[0].value = active && !preset.allday ? preset.open : '';
				times[1].value = active && !preset.allday ? preset.close : '';
			}
		});
	}

	/**
	 * Append a fresh interval to a day, re-indexing the interval name.
	 *
	 * @param {HTMLElement} dayEl Day row.
	 */
	function addInterval(dayEl) {
		if (!dayEl) {
			return;
		}
		var box = dayEl.querySelector('.mvweb-lb-hours__intervals');
		var first = box.querySelector('.mvweb-lb-hours__interval');
		if (!first) {
			return;
		}
		var clone = first.cloneNode(true);
		clone.querySelectorAll('input[type="time"]').forEach(function (el) { el.value = ''; });
		box.appendChild(clone);
		reindexIntervals(box);
	}

	/**
	 * WordPress media picker for logo / facade / gallery image fields.
	 */
	function initMediaPickers() {
		if (!window.wp || !window.wp.media) {
			return;
		}
		document.addEventListener('click', function (event) {
			var btn = event.target.closest('.mvweb-lb-media__pick');
			if (!btn) {
				return;
			}
			event.preventDefault();

			var container = btn.closest('.mvweb-lb-media');
			var input = container ? container.querySelector('input') : null;
			if (!input) {
				return;
			}

			var frame = window.wp.media({
				title: i18n.chooseImage || '',
				multiple: false,
				library: { type: 'image' }
			});
			frame.on('select', function () {
				var attachment = frame.state().get('selection').first().toJSON();
				input.value = attachment.url || '';
			});
			frame.open();
		});
	}

	/**
	 * Homepage schema scanner.
	 */
	function initScanner() {
		var btn = document.getElementById('mvweb-lb-scan');
		var box = document.getElementById('mvweb-lb-scan-result');
		if (!btn || !box || !cfg.ajaxUrl) {
			return;
		}

		btn.addEventListener('click', function () {
			btn.disabled = true;
			showResult(box, 'info', i18n.scanning || '');

			var body = new URLSearchParams();
			body.append('action', cfg.scanAction || 'mvweb_lb_scan');
			body.append('nonce', cfg.scanNonce || '');

			fetch(cfg.ajaxUrl, {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
				body: body.toString()
			})
				.then(function (r) { return r.json(); })
				.then(function (res) {
					if (!res || !res.success) {
						var msg = (res && res.data && res.data.message) || i18n.scanError || '';
						showResult(box, 'warning', msg);
						return;
					}
					renderScan(box, res.data || {});
				})
				.catch(function () {
					showResult(box, 'warning', i18n.scanError || '');
				})
				.then(function () {
					btn.disabled = false;
				});
		});
	}

	/**
	 * Render the scan verdict into the result box.
	 *
	 * @param {HTMLElement} box  Result container.
	 * @param {Object}      data Scan response.
	 */
	function renderScan(box, data) {
		var scenario = data.scenario || 'none';
		var label = data.source_label || '';

		if (scenario === 'none') {
			showResult(box, 'success', i18n.none || '');
			return;
		}

		var template = scenario === 'seo_graph' ? (i18n.seoGraph || '') : (i18n.standalone || '');
		var kind = scenario === 'seo_graph' ? 'info' : 'warning';
		var body = showResult(box, kind, template.replace('%s', label));

		var fields = data.fields || {};
		var parts = [];
		if (fields.name) { parts.push(fields.name); }
		if (fields.telephone) { parts.push(fields.telephone); }
		if (fields.address) { parts.push(i18n.addr || ''); }
		parts = parts.filter(Boolean);
		if (parts.length) {
			var found = document.createElement('p');
			found.className = 'mvweb-lb-scan-result__found';
			found.textContent = (i18n.found || '') + ' ' + parts.join(', ');
			body.appendChild(found);
		}
	}

	/**
	 * Render an alert into the result box. Builds a .mvweb-alert__body child so
	 * the flex alert lays the message out as one column; returns it so the
	 * caller can append extra lines.
	 *
	 * @param {HTMLElement} box  Container.
	 * @param {string}      kind info | success | warning.
	 * @param {string}      text Message.
	 * @return {HTMLElement} The alert body element.
	 */
	function showResult(box, kind, text) {
		box.hidden = false;
		box.className = 'mvweb-lb-scan-result mvweb-alert mvweb-alert--' + kind;
		box.textContent = '';

		var body = document.createElement('div');
		body.className = 'mvweb-alert__body';

		var msg = document.createElement('p');
		msg.className = 'mvweb-lb-scan-result__msg';
		msg.textContent = text;
		body.appendChild(msg);

		box.appendChild(body);
		return body;
	}
})();
