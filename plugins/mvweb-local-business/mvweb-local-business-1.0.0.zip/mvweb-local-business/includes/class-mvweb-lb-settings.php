<?php
/**
 * Settings storage and sanitization for MVweb Local Business.
 *
 * One wp_options array (`mvweb_lb_settings`) registered through the Settings API.
 * Sanitization runs against an explicit key whitelist — arbitrary $_POST keys
 * are never persisted.
 *
 * @package mvweb_lb
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Settings controller.
 *
 * @since 1.0.0
 */
final class MVweb_LB_Settings {

	/**
	 * Option name.
	 */
	const OPTION = 'mvweb_lb_settings';

	/**
	 * Settings group (Settings API).
	 */
	const GROUP = 'mvweb_lb_group';

	/**
	 * Business type select: schema.org @type => translatable human label.
	 *
	 * Keys are valid schema.org subtypes of LocalBusiness (ProfessionalService
	 * is intentionally excluded — deprecated). `LocalBusiness` is the safe
	 * fallback. A method (not a const) so labels stay translatable.
	 *
	 * @since 1.0.0
	 * @return array<string, string>
	 */
	public static function business_types() {
		return array(
			'ElectronicsStore'            => __( 'Repair shop (appliances, electronics)', 'mvweb-local-business' ),
			'Store'                       => __( 'Store', 'mvweb-local-business' ),
			'HardwareStore'               => __( 'Building materials / adhesives, sealants, chemicals', 'mvweb-local-business' ),
			'FurnitureStore'              => __( 'Furniture store', 'mvweb-local-business' ),
			'HomeAndConstructionBusiness' => __( 'Construction / finishing company, stoves and fireplaces', 'mvweb-local-business' ),
			'GeneralContractor'           => __( 'Renovation and construction crew / general contractor', 'mvweb-local-business' ),
			'Electrician'                 => __( 'Electrician / electrical work', 'mvweb-local-business' ),
			'Plumber'                     => __( 'Plumber', 'mvweb-local-business' ),
			'RoofingContractor'           => __( 'Roofing', 'mvweb-local-business' ),
			'AutoRepair'                  => __( 'Auto repair / tire service', 'mvweb-local-business' ),
			'LegalService'                => __( 'Legal services', 'mvweb-local-business' ),
			'FinancialService'            => __( 'Financial / accounting services', 'mvweb-local-business' ),
			'HealthAndBeautyBusiness'     => __( 'Beauty salon / barbershop', 'mvweb-local-business' ),
			'Dentist'                     => __( 'Dental clinic', 'mvweb-local-business' ),
			'RealEstateAgent'             => __( 'Real estate agency', 'mvweb-local-business' ),
			'FoodEstablishment'           => __( 'Cafe / restaurant', 'mvweb-local-business' ),
			'LodgingBusiness'             => __( 'Hotel / hostel', 'mvweb-local-business' ),
			'LocalBusiness'               => __( 'Other (local business)', 'mvweb-local-business' ),
		);
	}

	/**
	 * Week days: storage key => schema.org dayOfWeek.
	 *
	 * @var array<string, string>
	 */
	const DAYS = array(
		'monday'    => 'Monday',
		'tuesday'   => 'Tuesday',
		'wednesday' => 'Wednesday',
		'thursday'  => 'Thursday',
		'friday'    => 'Friday',
		'saturday'  => 'Saturday',
		'sunday'    => 'Sunday',
	);

	/**
	 * Wire hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_init', array( __CLASS__, 'register' ) );
	}

	/**
	 * Register the option with the Settings API.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register() {
		register_setting(
			self::GROUP,
			self::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => self::defaults(),
			)
		);
	}

	/**
	 * Default settings.
	 *
	 * @since 1.0.0
	 * @return array<string, mixed>
	 */
	public static function defaults() {
		$hours = array();
		foreach ( array_keys( self::DAYS ) as $day ) {
			$hours[ $day ] = array(
				'closed'    => false,
				'allday'    => false,
				'intervals' => array( array( 'open' => '', 'close' => '' ) ),
			);
		}

		return array(
			'enabled'       => false,
			'business_type' => 'LocalBusiness',
			'name'          => '',
			'alt_name'      => '',
			'description'   => '',
			'logo'          => '',
			'founded'       => '',
			'slogan'        => '',
			// Address.
			'country'       => 'RU',
			'region'        => '',
			'city'          => '',
			'street'        => '',
			'office'        => '',
			'postal'        => '',
			// Contacts.
			'phone'         => '',
			'phones_extra'  => array(),
			'email'         => '',
			'whatsapp'      => '',
			'telegram'      => '',
			'viber'         => '',
			'max'           => '',
			// Hours.
			'hours'         => $hours,
			'special_days'  => array(),
			// Geo.
			'lat'           => '',
			'lng'           => '',
			'serves_onsite' => false,
			'area_served'   => array(),
			// Social / catalogues.
			'sameas'        => array(),
			// Media.
			'facade'        => '',
			'gallery'       => array(),
			'video'         => '',
			// Extra.
			'price_range'   => '',
			'payments'      => array(),
			'languages'     => array(),
			'reviews_url'   => '',
		);
	}

	/**
	 * Sanitize the whole settings array against the key whitelist.
	 *
	 * @since 1.0.0
	 * @param mixed $input Raw input from options.php.
	 * @return array<string, mixed>
	 */
	public static function sanitize( $input ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			add_settings_error(
				self::GROUP,
				'mvweb_lb_forbidden',
				__( 'You do not have permission to change these settings.', 'mvweb-local-business' ),
				'error'
			);
			return mvweb_lb_get_settings();
		}

		$in  = is_array( $input ) ? $input : array();
		$out = self::defaults();

		$out['enabled']       = ! empty( $in['enabled'] );
		$out['serves_onsite'] = ! empty( $in['serves_onsite'] );

		// Business type — whitelist.
		if ( isset( $in['business_type'] ) && is_string( $in['business_type'] ) && isset( self::business_types()[ $in['business_type'] ] ) ) {
			$out['business_type'] = $in['business_type'];
		}

		// Plain text fields.
		foreach ( array( 'name', 'alt_name', 'region', 'city', 'street', 'office', 'postal', 'founded', 'slogan' ) as $key ) {
			if ( isset( $in[ $key ] ) ) {
				$out[ $key ] = sanitize_text_field( self::as_string( $in[ $key ] ) );
			}
		}

		// Multiline text.
		if ( isset( $in['description'] ) ) {
			$out['description'] = sanitize_textarea_field( self::as_string( $in['description'] ) );
		}

		// Phones (any input format → digits/+/-/spaces/parens).
		$out['phone']    = self::clean_phone( $in['phone'] ?? '' );
		$out['whatsapp'] = self::clean_phone( $in['whatsapp'] ?? '' );
		$out['viber']    = self::clean_phone( $in['viber'] ?? '' );

		// Messenger handles — normalize "@name" / links to a bare handle.
		$out['telegram'] = self::clean_handle( $in['telegram'] ?? '', array( 't.me', 'telegram.me' ) );
		$out['max']      = self::clean_handle( $in['max'] ?? '', array( 'max.ru' ) );
		if ( isset( $in['phones_extra'] ) && is_array( $in['phones_extra'] ) ) {
			foreach ( $in['phones_extra'] as $p ) {
				$clean = self::clean_phone( $p );
				if ( '' !== $clean ) {
					$out['phones_extra'][] = $clean;
				}
			}
		}

		// Email.
		if ( isset( $in['email'] ) ) {
			$email        = sanitize_email( self::as_string( $in['email'] ) );
			$out['email'] = is_email( $email ) ? $email : '';
		}

		// Country — ISO 3166-1 alpha-2.
		if ( isset( $in['country'] ) ) {
			$country = self::as_string( $in['country'] );
			if ( preg_match( '/^[A-Za-z]{2}$/', $country ) ) {
				$out['country'] = strtoupper( $country );
			}
		}

		// Coordinates.
		$out['lat'] = self::clean_coord( $in['lat'] ?? '', -90.0, 90.0 );
		$out['lng'] = self::clean_coord( $in['lng'] ?? '', -180.0, 180.0 );

		// URLs.
		foreach ( array( 'logo', 'facade', 'video', 'reviews_url' ) as $key ) {
			if ( isset( $in[ $key ] ) && '' !== trim( self::as_string( $in[ $key ] ) ) ) {
				$out[ $key ] = esc_url_raw( self::as_string( $in[ $key ] ) );
			}
		}

		// URL lists.
		foreach ( array( 'sameas', 'gallery' ) as $key ) {
			if ( isset( $in[ $key ] ) && is_array( $in[ $key ] ) ) {
				foreach ( $in[ $key ] as $url ) {
					$clean = esc_url_raw( self::as_string( $url ) );
					if ( '' !== $clean ) {
						$out[ $key ][] = $clean;
					}
				}
			}
		}

		// Text lists.
		foreach ( array( 'area_served', 'payments', 'languages' ) as $key ) {
			if ( isset( $in[ $key ] ) && is_array( $in[ $key ] ) ) {
				foreach ( $in[ $key ] as $val ) {
					$clean = sanitize_text_field( self::as_string( $val ) );
					if ( '' !== $clean ) {
						$out[ $key ][] = $clean;
					}
				}
			}
		}

		// Price range — under 100 chars (Google requirement).
		if ( isset( $in['price_range'] ) ) {
			$out['price_range'] = mb_substr( sanitize_text_field( self::as_string( $in['price_range'] ) ), 0, 99 );
		}

		// Hours.
		$out['hours']        = self::sanitize_hours( $in['hours'] ?? array() );
		$out['special_days'] = self::sanitize_special_days( $in['special_days'] ?? array() );

		return $out;
	}

	/**
	 * Sanitize the weekly opening hours structure.
	 *
	 * @since 1.0.0
	 * @param mixed $raw Raw hours input.
	 * @return array<string, array<string, mixed>>
	 */
	private static function sanitize_hours( $raw ) {
		$raw   = is_array( $raw ) ? $raw : array();
		$hours = array();

		foreach ( array_keys( self::DAYS ) as $day ) {
			$row       = isset( $raw[ $day ] ) && is_array( $raw[ $day ] ) ? $raw[ $day ] : array();
			$closed    = ! empty( $row['closed'] );
			$allday    = ! empty( $row['allday'] );
			$intervals = array();

			if ( ! $closed && ! $allday && isset( $row['intervals'] ) && is_array( $row['intervals'] ) ) {
				foreach ( $row['intervals'] as $interval ) {
					if ( ! is_array( $interval ) ) {
						continue;
					}
					$open  = self::clean_time( $interval['open'] ?? '' );
					$close = self::clean_time( $interval['close'] ?? '' );
					if ( '' !== $open && '' !== $close ) {
						$intervals[] = array( 'open' => $open, 'close' => $close );
					}
				}
			}

			// A day with neither allday nor a valid interval is treated as closed.
			if ( ! $allday && empty( $intervals ) ) {
				$closed = true;
			}

			if ( empty( $intervals ) ) {
				$intervals = array( array( 'open' => '', 'close' => '' ) );
			}

			$hours[ $day ] = array(
				'closed'    => $closed,
				'allday'    => $allday,
				'intervals' => $intervals,
			);
		}

		return $hours;
	}

	/**
	 * Sanitize the special days list (date + note).
	 *
	 * @since 1.0.0
	 * @param mixed $raw Raw special days input.
	 * @return array<int, array<string, string>>
	 */
	private static function sanitize_special_days( $raw ) {
		if ( ! is_array( $raw ) ) {
			return array();
		}

		$out = array();
		foreach ( $raw as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}
			$date = isset( $item['date'] ) ? trim( self::as_string( $item['date'] ) ) : '';
			if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
				continue;
			}
			$out[] = array(
				'date' => $date,
				'note' => isset( $item['note'] ) ? sanitize_text_field( self::as_string( $item['note'] ) ) : '',
			);
		}

		return $out;
	}

	/**
	 * Cast a raw value to string, treating non-scalars as empty.
	 *
	 * Guards the trust boundary against arrays arriving from crafted requests
	 * (`name="...[]"`), avoiding array-to-string warnings.
	 *
	 * @since 1.0.0
	 * @param mixed $value Raw value.
	 * @return string
	 */
	private static function as_string( $value ) {
		return is_scalar( $value ) ? (string) $value : '';
	}

	/**
	 * Sanitize a phone-like value: keep digits, +, -, spaces, parentheses.
	 *
	 * @since 1.0.0
	 * @param mixed $value Raw value.
	 * @return string
	 */
	private static function clean_phone( $value ) {
		$value = sanitize_text_field( self::as_string( $value ) );
		return trim( (string) preg_replace( '/[^0-9+\-\s()]/', '', $value ) );
	}

	/**
	 * Normalize a messenger handle: accept "@name", "name", or a profile link
	 * and return a bare handle.
	 *
	 * @since 1.0.0
	 * @param mixed              $value   Raw value.
	 * @param array<int, string> $domains Known host names to strip (e.g. t.me).
	 * @return string
	 */
	private static function clean_handle( $value, array $domains ) {
		$value = trim( self::as_string( $value ) );
		if ( '' === $value ) {
			return '';
		}
		$value = preg_replace( '#^https?://#i', '', $value );
		$value = preg_replace( '#^www\.#i', '', $value );
		foreach ( $domains as $domain ) {
			$value = preg_replace( '#^' . preg_quote( $domain, '#' ) . '/#i', '', (string) $value );
		}
		$value = ltrim( (string) $value, '@/' );
		$value = rtrim( $value, '/' );
		return sanitize_text_field( $value );
	}

	/**
	 * Validate a HH:MM time string.
	 *
	 * @since 1.0.0
	 * @param mixed $value Raw value.
	 * @return string Empty string when invalid.
	 */
	private static function clean_time( $value ) {
		$value = trim( self::as_string( $value ) );
		return preg_match( '/^([01][0-9]|2[0-3]):[0-5][0-9]$/', $value ) ? $value : '';
	}

	/**
	 * Validate a coordinate within a range.
	 *
	 * @since 1.0.0
	 * @param mixed $value Raw value.
	 * @param float $min   Lower bound.
	 * @param float $max   Upper bound.
	 * @return string Empty string when invalid.
	 */
	private static function clean_coord( $value, $min, $max ) {
		$value = str_replace( ',', '.', trim( self::as_string( $value ) ) );
		if ( '' === $value ) {
			return '';
		}
		$float = filter_var( $value, FILTER_VALIDATE_FLOAT );
		if ( false === $float || $float < $min || $float > $max ) {
			return '';
		}
		return (string) $float;
	}
}
