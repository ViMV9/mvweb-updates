<?php
/**
 * Homepage schema scanner for MVweb Local Business.
 *
 * AJAX endpoint that fetches the site front page, parses existing JSON-LD and
 * reports whether an Organization/LocalBusiness node is already present and
 * which plugin renders it — so the admin does not create a duplicate (SPEC §5).
 *
 * @package mvweb_lb
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Scanner controller.
 *
 * @since 1.0.0
 */
final class MVweb_LB_Scanner {

	/**
	 * AJAX action / nonce name.
	 */
	const ACTION = 'mvweb_lb_scan';

	/**
	 * Schema.org types treated as an existing business node (in addition to the
	 * plugin's own BUSINESS_TYPES subtypes).
	 *
	 * @var array<int, string>
	 */
	const EXTRA_TYPES = array( 'Organization', 'LocalBusiness', 'Restaurant', 'ProfessionalService', 'MedicalBusiness', 'FoodEstablishment' );

	/**
	 * Wire hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'wp_ajax_' . self::ACTION, array( __CLASS__, 'handle' ) );
	}

	/**
	 * Handle the scan request.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function handle() {
		check_ajax_referer( self::ACTION, 'nonce' );

		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => __( 'Insufficient permissions.', 'mvweb-local-business' ) ), 403 );
		}

		$url  = add_query_arg( 'mvweb_lb_nocache', time(), home_url( '/' ) );
		$resp = wp_remote_get(
			$url,
			array(
				'timeout' => 15,
				'headers' => array( 'Cache-Control' => 'no-cache' ),
			)
		);

		if ( is_wp_error( $resp ) ) {
			wp_send_json_error( array( 'message' => $resp->get_error_message() ) );
		}

		$code = (int) wp_remote_retrieve_response_code( $resp );
		$html = (string) wp_remote_retrieve_body( $resp );

		if ( $code < 200 || $code >= 300 || '' === $html ) {
			wp_send_json_error(
				array(
					/* translators: %d: HTTP status code. */
					'message' => sprintf( __( 'Could not retrieve the homepage (response code %d).', 'mvweb-local-business' ), $code ),
				)
			);
		}

		wp_send_json_success( self::analyze( $html ) );
	}

	/**
	 * Analyze fetched HTML for existing business schema.
	 *
	 * @since 1.0.0
	 * @param string $html Front-page HTML.
	 * @return array<string, mixed>
	 */
	public static function analyze( $html ) {
		$nodes   = self::extract_nodes( $html );
		$matched = array();

		foreach ( $nodes as $node ) {
			if ( is_array( $node ) && self::is_business_node( $node ) ) {
				$matched[] = $node;
			}
		}

		$source       = self::detect_source( $html );
		$source_label = self::source_label( $source );

		if ( empty( $matched ) ) {
			return array(
				'scenario'     => 'none',
				'source'       => '',
				'source_label' => '',
				'types'        => array(),
				'fields'       => array(),
			);
		}

		// Merge the discovered fields across all matched nodes.
		$types  = array();
		$fields = array(
			'name'      => '',
			'telephone' => '',
			'email'     => '',
			'address'   => false,
			'geo'       => false,
			'hours'     => false,
			'priceRange' => '',
			'sameAs'    => 0,
		);

		foreach ( $matched as $node ) {
			foreach ( self::node_types( $node ) as $type ) {
				$types[ $type ] = true;
			}
			if ( '' === $fields['name'] && ! empty( $node['name'] ) && is_string( $node['name'] ) ) {
				$fields['name'] = sanitize_text_field( $node['name'] );
			}
			if ( '' === $fields['telephone'] && ! empty( $node['telephone'] ) && is_string( $node['telephone'] ) ) {
				$fields['telephone'] = sanitize_text_field( $node['telephone'] );
			}
			if ( '' === $fields['email'] && ! empty( $node['email'] ) && is_string( $node['email'] ) ) {
				$fields['email'] = sanitize_text_field( $node['email'] );
			}
			if ( '' === $fields['priceRange'] && ! empty( $node['priceRange'] ) && is_string( $node['priceRange'] ) ) {
				$fields['priceRange'] = sanitize_text_field( $node['priceRange'] );
			}
			$fields['address'] = $fields['address'] || ! empty( $node['address'] );
			$fields['geo']     = $fields['geo'] || ! empty( $node['geo'] );
			$fields['hours']   = $fields['hours'] || ! empty( $node['openingHoursSpecification'] ) || ! empty( $node['openingHours'] );
			if ( ! empty( $node['sameAs'] ) ) {
				$fields['sameAs'] += is_array( $node['sameAs'] ) ? count( $node['sameAs'] ) : 1;
			}
		}

		// Yoast/Rank Math → we auto-integrate; anything else → duplicate risk.
		$scenario = ( 'yoast' === $source || 'rankmath' === $source ) ? 'seo_graph' : 'standalone';

		return array(
			'scenario'     => $scenario,
			'source'       => $source,
			'source_label' => $source_label,
			'types'        => array_keys( $types ),
			'fields'       => $fields,
		);
	}

	/**
	 * Extract all JSON-LD nodes from HTML (flattening @graph and lists).
	 *
	 * @since 1.0.0
	 * @param string $html HTML.
	 * @return array<int, mixed>
	 */
	private static function extract_nodes( $html ) {
		if ( '' === trim( $html ) || ! class_exists( 'DOMDocument' ) ) {
			return array();
		}

		$dom      = new DOMDocument();
		$previous = libxml_use_internal_errors( true );
		// Encoding hint keeps UTF-8 content intact.
		$dom->loadHTML( '<?xml encoding="utf-8" ?>' . $html );
		libxml_clear_errors();
		libxml_use_internal_errors( $previous );

		$nodes = array();
		foreach ( $dom->getElementsByTagName( 'script' ) as $script ) {
			if ( 'application/ld+json' !== strtolower( (string) $script->getAttribute( 'type' ) ) ) {
				continue;
			}
			$decoded = json_decode( trim( (string) $script->textContent ), true );
			if ( null === $decoded ) {
				continue;
			}
			foreach ( self::flatten( $decoded ) as $node ) {
				$nodes[] = $node;
			}
		}

		return $nodes;
	}

	/**
	 * Flatten a decoded JSON-LD structure into a flat list of nodes.
	 *
	 * @since 1.0.0
	 * @param mixed $decoded Decoded JSON.
	 * @return array<int, mixed>
	 */
	private static function flatten( $decoded ) {
		if ( ! is_array( $decoded ) ) {
			return array();
		}

		// @graph container.
		if ( isset( $decoded['@graph'] ) && is_array( $decoded['@graph'] ) ) {
			$out = array();
			foreach ( $decoded['@graph'] as $item ) {
				$out[] = $item;
			}
			return $out;
		}

		// List of nodes (numeric keys).
		if ( array_keys( $decoded ) === range( 0, count( $decoded ) - 1 ) && ! isset( $decoded['@type'] ) ) {
			return $decoded;
		}

		// Single node.
		return array( $decoded );
	}

	/**
	 * Normalize a node's @type into a list of strings.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $node Node.
	 * @return array<int, string>
	 */
	private static function node_types( $node ) {
		if ( ! isset( $node['@type'] ) ) {
			return array();
		}
		$types = is_array( $node['@type'] ) ? $node['@type'] : array( $node['@type'] );
		$types = array_filter( $types, 'is_scalar' );
		return array_values( array_filter( array_map( 'strval', $types ) ) );
	}

	/**
	 * Whether a node represents an organization/local business.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $node Node.
	 * @return bool
	 */
	private static function is_business_node( $node ) {
		$known = array_merge( self::EXTRA_TYPES, array_keys( MVweb_LB_Settings::business_types() ) );
		foreach ( self::node_types( $node ) as $type ) {
			if ( in_array( $type, $known, true ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Detect which plugin renders the schema, by HTML markers.
	 *
	 * @since 1.0.0
	 * @param string $html HTML.
	 * @return string 'yoast' | 'rankmath' | 'unknown'
	 */
	private static function detect_source( $html ) {
		if ( false !== stripos( $html, 'yoast-schema-graph' ) || false !== stripos( $html, 'Yoast SEO plugin' ) ) {
			return 'yoast';
		}
		if ( false !== stripos( $html, 'rank-math-schema' ) || false !== stripos( $html, 'Rank Math WordPress SEO' ) ) {
			return 'rankmath';
		}
		return 'unknown';
	}

	/**
	 * Human label for a detected source.
	 *
	 * @since 1.0.0
	 * @param string $source Source key.
	 * @return string
	 */
	private static function source_label( $source ) {
		if ( 'yoast' === $source ) {
			return 'Yoast SEO';
		}
		if ( 'rankmath' === $source ) {
			return 'Rank Math';
		}
		return __( 'the site theme or another plugin', 'mvweb-local-business' );
	}
}
