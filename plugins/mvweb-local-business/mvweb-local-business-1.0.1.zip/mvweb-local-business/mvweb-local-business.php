<?php
/**
 * Plugin Name:       MVweb Local Business
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-local-business
 * Description:       LocalBusiness (Schema.org) markup for Google and Yandex: NAP entry form, opening hours, duplicate-free integration into the Yoast/Rank Math graph, and a homepage scanner.
 * Version:           1.0.1
 * Requires at least: 6.4
 * Tested up to:      7.0.1
 * Requires PHP:      8.0
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-local-business
 * Domain Path:       /languages
 *
 * @package mvweb_lb
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_LB_VERSION' ) ) {
	return;
}

define( 'MVWEB_LB_VERSION', '1.0.1' );
define( 'MVWEB_LB_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_LB_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_LB_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_LB_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_LB_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_LB_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_LB_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_LB_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-local-business' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter( 'mvweb_registered_plugins', function ( $plugins ) {
	$plugins['mvweb-local-business'] = array(
		'name'         => 'MVweb Local Business',
		'description'  => __( 'LocalBusiness markup (Schema.org) for Google and Yandex: NAP input form, opening hours, merging into the Yoast/RankMath graph without duplicates, and a homepage scanner.', 'mvweb-local-business' ),
		'url'          => 'https://mvweb.ru/plugins/mvweb-local-business',
		'settings_url' => 'admin.php?page=mvweb-local-business',
		'textdomain'   => 'mvweb-local-business',
	);
	return $plugins;
} );

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_lb_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-local-business',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_lb_load_textdomain' );

// ───────────────────────────────────────────────
// Plugin classes
// ───────────────────────────────────────────────
require_once MVWEB_LB_PATH . 'includes/class-mvweb-lb-settings.php';
require_once MVWEB_LB_PATH . 'includes/helpers.php';
require_once MVWEB_LB_PATH . 'includes/class-mvweb-lb-schema.php';
require_once MVWEB_LB_PATH . 'includes/class-mvweb-lb-scanner.php';

MVweb_LB_Settings::init();
MVweb_LB_Schema::init();
MVweb_LB_Scanner::init();

if ( is_admin() ) {
	require_once MVWEB_LB_PATH . 'admin/class-mvweb-lb-admin.php';
	MVweb_LB_Admin::init();
}
