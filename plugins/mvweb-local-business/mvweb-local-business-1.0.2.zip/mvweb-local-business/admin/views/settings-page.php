<?php
/**
 * Admin settings page template.
 *
 * MVweb Admin UI Kit — sidebar layout (slate palette, Yoast-style).
 * One Settings API form wraps every tab; a single Save persists the whole
 * `mvweb_lb_settings` option.
 *
 * @package mvweb_lb
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$requested_tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only tab switching.
$allowed_tabs  = array( 'general', 'contacts', 'hours', 'media', 'help' );
$current_tab   = in_array( $requested_tab, $allowed_tabs, true ) ? $requested_tab : 'general';

$tabs = array(
	'general'  => array(
		'label' => __( 'General', 'mvweb-local-business' ),
		'icon'  => 'grid',
	),
	'contacts' => array(
		'label' => __( 'Company', 'mvweb-local-business' ),
		'icon'  => 'pin',
	),
	'hours'    => array(
		'label' => __( 'Opening hours', 'mvweb-local-business' ),
		'icon'  => 'clock',
	),
	'media'    => array(
		'label' => __( 'Media & profiles', 'mvweb-local-business' ),
		'icon'  => 'image',
	),
	'help'     => array(
		'label' => __( 'Help', 'mvweb-local-business' ),
		'icon'  => 'help',
	),
);

$icons = array(
	'grid'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
	'pin'   => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>',
	'clock' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 15 14"/></svg>',
	'image' => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>',
	'help'  => '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>',
);

$mvweb_lb = mvweb_lb_get_settings();
?>

<div class="wrap mvweb-settings">

	<aside class="mvweb-sidebar">
		<div class="mvweb-sidebar__brand">
			<div class="mvweb-sidebar__brand-logo" aria-hidden="true">LB</div>
			<div>
				<div class="mvweb-sidebar__brand-name"><?php esc_html_e( 'MVweb Local Business', 'mvweb-local-business' ); ?></div>
				<div class="mvweb-sidebar__brand-meta">v<?php echo esc_html( MVWEB_LB_VERSION ); ?></div>
			</div>
		</div>

		<ul class="mvweb-nav">
			<?php foreach ( $tabs as $tab_id => $tab ) : ?>
				<li>
					<a href="#<?php echo esc_attr( $tab_id ); ?>"
						class="<?php echo esc_attr( 'mvweb-nav__link' . ( $current_tab === $tab_id ? ' mvweb-nav__link--active' : '' ) ); ?>"
						data-tab="<?php echo esc_attr( $tab_id ); ?>">
						<?php echo $icons[ $tab['icon'] ]; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG markup. ?>
						<?php echo esc_html( $tab['label'] ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</aside>

	<main class="mvweb-main">

		<?php settings_errors( MVweb_LB_Settings::GROUP ); ?>

		<form method="post" action="options.php">
			<?php settings_fields( MVweb_LB_Settings::GROUP ); ?>

			<div id="general" class="<?php echo esc_attr( 'mvweb-tab-content' . ( 'general' === $current_tab ? ' active' : '' ) ); ?>">
				<?php require MVWEB_LB_PATH . 'admin/views/tab-general.php'; ?>
			</div>

			<div id="contacts" class="<?php echo esc_attr( 'mvweb-tab-content' . ( 'contacts' === $current_tab ? ' active' : '' ) ); ?>">
				<?php require MVWEB_LB_PATH . 'admin/views/tab-contacts.php'; ?>
			</div>

			<div id="hours" class="<?php echo esc_attr( 'mvweb-tab-content' . ( 'hours' === $current_tab ? ' active' : '' ) ); ?>">
				<?php require MVWEB_LB_PATH . 'admin/views/tab-hours.php'; ?>
			</div>

			<div id="media" class="<?php echo esc_attr( 'mvweb-tab-content' . ( 'media' === $current_tab ? ' active' : '' ) ); ?>">
				<?php require MVWEB_LB_PATH . 'admin/views/tab-media.php'; ?>
			</div>

			<div id="help" class="<?php echo esc_attr( 'mvweb-tab-content' . ( 'help' === $current_tab ? ' active' : '' ) ); ?>">
				<?php require MVWEB_LB_PATH . 'admin/views/tab-help.php'; ?>
			</div>

			<div class="mvweb-submit">
				<button type="submit" class="mvweb-btn mvweb-btn--primary">
					<?php esc_html_e( 'Save', 'mvweb-local-business' ); ?>
				</button>
				<span class="mvweb-submit__hint"><kbd>⌘ S</kbd></span>
			</div>
		</form>

	</main>
</div>
