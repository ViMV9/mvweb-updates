<?php
/**
 * Media & profiles tab — sameAs, images, price range, payments, reviews link.
 *
 * @package mvweb_lb
 * @since   1.0.0
 * @var array<string, mixed> $mvweb_lb Current settings (from settings-page.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$s        = $mvweb_lb;
$sameas   = ! empty( $s['sameas'] ) && is_array( $s['sameas'] ) ? $s['sameas'] : array();
$gallery  = ! empty( $s['gallery'] ) && is_array( $s['gallery'] ) ? $s['gallery'] : array();
$payments = ! empty( $s['payments'] ) && is_array( $s['payments'] ) ? $s['payments'] : array();
$langs    = ! empty( $s['languages'] ) && is_array( $s['languages'] ) ? $s['languages'] : array();

$payment_options  = array(
	__( 'Cash', 'mvweb-local-business' ),
	__( 'Card', 'mvweb-local-business' ),
	__( 'Transfer', 'mvweb-local-business' ),
	__( 'Installments', 'mvweb-local-business' ),
);
$language_options = array(
	__( 'Russian', 'mvweb-local-business' ),
	__( 'English', 'mvweb-local-business' ),
);
$price_options    = array(
	''    => __( 'Not specified', 'mvweb-local-business' ),
	'$'   => __( '$ — budget', 'mvweb-local-business' ),
	'$$'  => __( '$$ — moderate', 'mvweb-local-business' ),
	'$$$' => __( '$$$ — premium', 'mvweb-local-business' ),
);
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Social and directory profiles', 'mvweb-local-business' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'VKontakte, a Telegram channel, Yandex Maps, 2GIS, a Google profile. The more matching links, the more confident search engines are that it\'s the same company.', 'mvweb-local-business' ); ?></p>

	<div class="mvweb-lb-repeater" data-repeater="sameas">
		<div class="mvweb-lb-repeater__list">
			<?php foreach ( $sameas as $url ) : ?>
				<div class="mvweb-lb-repeater__row">
					<input type="url" name="mvweb_lb_settings[sameas][]" class="mvweb-input" value="<?php echo esc_attr( $url ); ?>" placeholder="https://vk.com/company">
					<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-repeater__remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-local-business' ); ?>">&times;</button>
				</div>
			<?php endforeach; ?>
		</div>
		<template class="mvweb-lb-repeater__template">
			<div class="mvweb-lb-repeater__row">
				<input type="url" name="mvweb_lb_settings[sameas][]" class="mvweb-input" value="" placeholder="https://vk.com/company">
				<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-repeater__remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-local-business' ); ?>">&times;</button>
			</div>
		</template>
		<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-lb-repeater__add"><?php esc_html_e( '+ add link', 'mvweb-local-business' ); ?></button>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Reviews', 'mvweb-local-business' ); ?></div>
	</div>

	<div class="mvweb-alert mvweb-alert--warning">
		<div class="mvweb-alert__body">
			<?php esc_html_e( 'Don\'t enter the rating and review count manually. Search engines specifically verify that reviews come from an independent source — a rating «made up» on your own site leads to penalties, not stars in the results. Provide a link to your profile on Yandex Maps or Google — the rating will be pulled in automatically and counted as trusted.', 'mvweb-local-business' ); ?>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_reviews_url" class="mvweb-form-row__label"><?php esc_html_e( 'Reviews link', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="url" id="mvweb_lb_reviews_url" name="mvweb_lb_settings[reviews_url]" class="mvweb-input" value="<?php echo esc_attr( $s['reviews_url'] ); ?>" placeholder="https://yandex.ru/maps/org/.../reviews">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'An aggregator profile where reviews actually accumulate (Yandex Maps, Google).', 'mvweb-local-business' ); ?></p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Photos and video', 'mvweb-local-business' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_facade" class="mvweb-form-row__label"><?php esc_html_e( 'Photo of the storefront / sign', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-lb-media" data-target="mvweb_lb_facade">
				<input type="url" id="mvweb_lb_facade" name="mvweb_lb_settings[facade]" class="mvweb-input" value="<?php echo esc_attr( $s['facade'] ); ?>" placeholder="https://example.ru/fasad.jpg">
				<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-lb-media__pick"><?php esc_html_e( 'Choose from media library', 'mvweb-local-business' ); ?></button>
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Helps confirm the address is real — useful for maps.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label"><?php esc_html_e( 'Gallery', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-lb-repeater" data-repeater="gallery">
				<div class="mvweb-lb-repeater__list">
					<?php foreach ( $gallery as $img ) : ?>
						<div class="mvweb-lb-repeater__row mvweb-lb-media" data-target="">
							<input type="url" name="mvweb_lb_settings[gallery][]" class="mvweb-input" value="<?php echo esc_attr( $img ); ?>" placeholder="https://example.ru/photo.jpg">
							<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-lb-media__pick"><?php esc_html_e( 'Choose', 'mvweb-local-business' ); ?></button>
							<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-repeater__remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-local-business' ); ?>">&times;</button>
						</div>
					<?php endforeach; ?>
				</div>
				<template class="mvweb-lb-repeater__template">
					<div class="mvweb-lb-repeater__row mvweb-lb-media" data-target="">
						<input type="url" name="mvweb_lb_settings[gallery][]" class="mvweb-input" value="" placeholder="https://example.ru/photo.jpg">
						<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-lb-media__pick"><?php esc_html_e( 'Choose', 'mvweb-local-business' ); ?></button>
						<button type="button" class="mvweb-btn mvweb-btn--ghost mvweb-lb-repeater__remove" aria-label="<?php esc_attr_e( 'Remove', 'mvweb-local-business' ); ?>">&times;</button>
					</div>
				</template>
				<button type="button" class="mvweb-btn mvweb-btn--secondary mvweb-lb-repeater__add"><?php esc_html_e( '+ add photo', 'mvweb-local-business' ); ?></button>
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( '3–6 photos: work, interior, team.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_video" class="mvweb-form-row__label"><?php esc_html_e( 'Video introduction', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<input type="url" id="mvweb_lb_video" name="mvweb_lb_settings[video]" class="mvweb-input" value="<?php echo esc_attr( $s['video'] ); ?>" placeholder="https://youtube.com/watch?v=...">
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'YouTube or RuTube. Optional.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Additional', 'mvweb-local-business' ); ?></div>
	</div>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_price_range" class="mvweb-form-row__label"><?php esc_html_e( 'Price range', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<select id="mvweb_lb_price_range" name="mvweb_lb_settings[price_range]" class="mvweb-select mvweb-select--narrow">
				<?php foreach ( $price_options as $value => $label ) : ?>
					<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $s['price_range'], $value ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label"><?php esc_html_e( 'Payment methods', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-lb-checks">
				<?php foreach ( $payment_options as $option ) : ?>
					<label class="mvweb-check">
						<input type="checkbox" name="mvweb_lb_settings[payments][]" value="<?php echo esc_attr( $option ); ?>" <?php checked( in_array( $option, $payments, true ) ); ?>>
						<?php echo esc_html( $option ); ?>
					</label>
				<?php endforeach; ?>
			</div>
		</div>
	</div>

	<div class="mvweb-form-row">
		<label class="mvweb-form-row__label"><?php esc_html_e( 'Languages spoken', 'mvweb-local-business' ); ?></label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-lb-checks">
				<?php foreach ( $language_options as $option ) : ?>
					<label class="mvweb-check">
						<input type="checkbox" name="mvweb_lb_settings[languages][]" value="<?php echo esc_attr( $option ); ?>" <?php checked( in_array( $option, $langs, true ) ); ?>>
						<?php echo esc_html( $option ); ?>
					</label>
				<?php endforeach; ?>
			</div>
		</div>
	</div>
</div>
