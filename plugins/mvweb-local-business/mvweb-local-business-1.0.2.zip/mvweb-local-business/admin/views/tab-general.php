<?php
/**
 * General tab — output status, homepage scan, validation help.
 *
 * @package mvweb_lb
 * @since   1.0.0
 * @var array<string, mixed> $mvweb_lb Current settings (from settings-page.php).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$s = $mvweb_lb;
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Organization markup for search', 'mvweb-local-business' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'This data becomes special markup on the page — invisible to visitors, but read by Yandex and Google. Using it, search engines show your opening hours, phone, and address right in the search results.', 'mvweb-local-business' ); ?>
	</p>

	<div class="mvweb-form-row">
		<label for="mvweb_lb_enabled" class="mvweb-form-row__label">
			<?php esc_html_e( 'Output markup', 'mvweb-local-business' ); ?>
		</label>
		<div class="mvweb-form-row__field">
			<div class="mvweb-toggle-row">
				<label class="mvweb-toggle">
					<input type="checkbox" id="mvweb_lb_enabled" name="mvweb_lb_settings[enabled]" value="1" <?php checked( ! empty( $s['enabled'] ) ); ?>>
					<span class="mvweb-toggle__slider"></span>
				</label>
				<span><?php esc_html_e( 'Enable LocalBusiness markup output on the homepage', 'mvweb-local-business' ); ?></span>
			</div>
			<p class="mvweb-form-row__desc"><?php esc_html_e( 'Company data is filled in on the «Company» tab.', 'mvweb-local-business' ); ?></p>
		</div>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Duplicate check', 'mvweb-local-business' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'We\'ll check whether the site already has company markup — so you don\'t create a duplicate. If you use a caching plugin, clear the cache manually first.', 'mvweb-local-business' ); ?>
	</p>

	<div class="mvweb-lb-scan">
		<button type="button" class="mvweb-btn mvweb-btn--secondary" id="mvweb-lb-scan">
			<?php esc_html_e( 'Check site', 'mvweb-local-business' ); ?>
		</button>
		<div id="mvweb-lb-scan-result" class="mvweb-lb-scan-result" hidden></div>
	</div>
</div>

<div class="mvweb-alert mvweb-alert--info">
	<div class="mvweb-alert__body">
		<?php esc_html_e( 'If you already have Yoast SEO or Rank Math installed with the organization filled in, we\'ll automatically extend their markup with no duplicate. Search engines treat two independent blocks on a page as an error, not a double benefit.', 'mvweb-local-business' ); ?>
	</div>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'How to check that everything worked', 'mvweb-local-business' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php esc_html_e( 'After saving and publishing, open the homepage and check the markup with two tools:', 'mvweb-local-business' ); ?>
	</p>
	<ul class="mvweb-lb-links">
		<li><a href="https://search.google.com/test/rich-results" target="_blank" rel="noopener noreferrer">Google Rich Results Test</a> — <?php esc_html_e( 'what Google sees', 'mvweb-local-business' ); ?></li>
		<li><a href="https://webmaster.yandex.ru/tools/microtest/" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'Yandex.Webmaster validator', 'mvweb-local-business' ); ?></a> — <?php esc_html_e( 'what Yandex sees', 'mvweb-local-business' ); ?></li>
	</ul>
</div>
