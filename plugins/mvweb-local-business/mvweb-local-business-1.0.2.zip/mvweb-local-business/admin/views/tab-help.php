<?php
/**
 * Help tab.
 *
 * @package mvweb_lb
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Getting started', 'mvweb-local-business' ); ?></div>
	</div>

	<ol class="mvweb-steps">
		<li><div>
			<strong><?php esc_html_e( 'Check the site for duplicates', 'mvweb-local-business' ); ?></strong>
			<p><?php esc_html_e( 'On the «General» tab, click «Check site». If Yoast or Rank Math already outputs markup, we\'ll extend it with no duplicate.', 'mvweb-local-business' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Fill in company data', 'mvweb-local-business' ); ?></strong>
			<p><?php esc_html_e( 'Business type, name, address, and phone are the required minimum. The rest enriches your card in search.', 'mvweb-local-business' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Set your opening hours', 'mvweb-local-business' ); ?></strong>
			<p><?php esc_html_e( 'Use the presets or set the hours per day. For a lunch break, add a break.', 'mvweb-local-business' ); ?></p>
		</div></li>
		<li><div>
			<strong><?php esc_html_e( 'Enable output and check the markup', 'mvweb-local-business' ); ?></strong>
			<p><?php esc_html_e( 'Turn on the toggle on the «General» tab, save, and check the homepage with the Google Rich Results Test and the Yandex.Webmaster validator.', 'mvweb-local-business' ); ?></p>
		</div></li>
	</ol>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'What the plugin does', 'mvweb-local-business' ); ?></div>
	</div>
	<p class="mvweb-block__sub"><?php esc_html_e( 'Builds LocalBusiness markup (Schema.org, JSON-LD) for Yandex and Google based on your data. The markup helps show your address, phone, and opening hours right in the search results.', 'mvweb-local-business' ); ?></p>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Frequently asked questions', 'mvweb-local-business' ); ?></div>
	</div>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'I already have Yoast / Rank Math. Will there be a duplicate?', 'mvweb-local-business' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'No. If Yoast or Rank Math is found, the plugin extends their organization node with your data and does not print its own block. Search engines treat two independent blocks as an error.', 'mvweb-local-business' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'Why can\'t I enter the rating and reviews manually?', 'mvweb-local-business' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Search engines don\'t show a «self-serving» rating that a company assigns to itself — this can lead to penalties. Instead, provide a link to your profile on Yandex Maps or Google, where the rating is pulled from as trusted.', 'mvweb-local-business' ); ?></p>
		</div>
	</details>

	<details class="mvweb-faq">
		<summary><?php esc_html_e( 'The markup doesn\'t show up in the check — why?', 'mvweb-local-business' ); ?></summary>
		<div class="mvweb-faq__body">
			<p><?php esc_html_e( 'Make sure the output toggle is on, the name and address are filled in, and the cache is cleared (if you use a caching plugin). Search engines also need a few days to recrawl.', 'mvweb-local-business' ); ?></p>
		</div>
	</details>
</div>

<div class="mvweb-block">
	<div class="mvweb-block__head">
		<div class="mvweb-block__title"><?php esc_html_e( 'Support', 'mvweb-local-business' ); ?></div>
	</div>
	<p class="mvweb-block__sub">
		<?php
		printf(
			/* translators: %s: plugin version. */
			esc_html__( 'MVweb Local Business, version %s. Website: mvweb.ru', 'mvweb-local-business' ),
			esc_html( MVWEB_LB_VERSION )
		);
		?>
	</p>
</div>
