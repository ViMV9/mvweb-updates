<?php
/**
 * Admin settings page for MVweb Local Business.
 *
 * Registers a submenu under the MVweb Hub, enqueues admin assets and renders
 * the tabbed settings page backed by the Settings API.
 *
 * @package mvweb_lb
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Admin page controller.
 *
 * @since 1.0.0
 */
final class MVweb_LB_Admin {

	/**
	 * Settings page slug.
	 */
	const PAGE_SLUG = 'mvweb-local-business';

	/**
	 * Capability required to manage the plugin.
	 */
	const CAPABILITY = 'manage_options';

	/**
	 * Hook suffix of the settings page.
	 *
	 * @var string
	 */
	private static $hook_suffix = '';

	/**
	 * Wire hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ), 11 );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
	}

	/**
	 * Register the settings submenu under the MVweb Hub.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_menu() {
		$parent = class_exists( 'MVweb_Menu' ) && method_exists( 'MVweb_Menu', 'get_menu_slug' )
			? MVweb_Menu::get_menu_slug()
			: 'mvweb-hub';

		self::$hook_suffix = add_submenu_page(
			$parent,
			__( 'MVweb Local Business', 'mvweb-local-business' ),
			__( 'Local Business', 'mvweb-local-business' ),
			self::CAPABILITY,
			self::PAGE_SLUG,
			array( __CLASS__, 'render_page' )
		);
	}

	/**
	 * Enqueue admin styles and scripts on the settings page only.
	 *
	 * @since 1.0.0
	 * @param string $hook Current admin page hook suffix.
	 * @return void
	 */
	public static function enqueue_assets( $hook ) {
		if ( '' === self::$hook_suffix || $hook !== self::$hook_suffix ) {
			return;
		}

		// WordPress media modal for logo / gallery pickers.
		wp_enqueue_media();

		wp_enqueue_style(
			'mvweb-lb-admin',
			MVWEB_LB_URL . 'admin/css/admin.min.css',
			array(),
			self::asset_ver( 'admin/css/admin.min.css' )
		);
		wp_enqueue_style(
			'mvweb-lb-plugin',
			MVWEB_LB_URL . 'admin/css/plugin.min.css',
			array( 'mvweb-lb-admin' ),
			self::asset_ver( 'admin/css/plugin.min.css' )
		);
		wp_enqueue_script(
			'mvweb-lb-admin',
			MVWEB_LB_URL . 'admin/js/admin.min.js',
			array(),
			self::asset_ver( 'admin/js/admin.min.js' ),
			true
		);

		wp_localize_script(
			'mvweb-lb-admin',
			'mvwebLb',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'scanAction' => MVweb_LB_Scanner::ACTION,
				'scanNonce'  => wp_create_nonce( MVweb_LB_Scanner::ACTION ),
				'i18n'       => array(
					'scanning'   => __( 'Checking the site…', 'mvweb-local-business' ),
					'scanError'  => __( 'Could not check the site. Please try again later.', 'mvweb-local-business' ),
					'none'       => __( 'There is no organization markup on the site yet — you can fill in the form safely, no duplicates will appear.', 'mvweb-local-business' ),
					'seoGraph'   => __( 'The site already has company markup output by %s. We will carefully merge your data with the existing markup, with no duplicate. Just overwrite any outdated values here.', 'mvweb-local-business' ),
					'standalone' => __( 'The site already has LocalBusiness markup (source: %s). If you enable output here, the page will contain two blocks — search engines will treat this as an error. Disable the markup in the source, or do not enable output here.', 'mvweb-local-business' ),
					'found'      => __( 'Found:', 'mvweb-local-business' ),
					'chooseImage' => __( 'Choose image', 'mvweb-local-business' ),
				),
			)
		);
	}

	/**
	 * Asset version = file mtime, so changes bust the cache without a version
	 * bump (same pattern as the shared MVweb_Menu).
	 *
	 * @since 1.0.0
	 * @param string $rel Path relative to the plugin root.
	 * @return string
	 */
	private static function asset_ver( $rel ) {
		$path = MVWEB_LB_PATH . $rel;
		$mtime = file_exists( $path ) ? filemtime( $path ) : 0;
		return $mtime ? (string) $mtime : MVWEB_LB_VERSION;
	}

	/**
	 * Render the settings page.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function render_page() {
		if ( ! current_user_can( self::CAPABILITY ) ) {
			return;
		}
		require MVWEB_LB_PATH . 'admin/views/settings-page.php';
	}
}
