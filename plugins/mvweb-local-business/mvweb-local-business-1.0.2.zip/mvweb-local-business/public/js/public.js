/**
 * Public (frontend) JavaScript for MVweb Local Business.
 *
 * @package mvweb_lb
 * @since   1.0.0
 */

(function () {
	'use strict';

	document.addEventListener('DOMContentLoaded', function () {
		// Frontend initialization.
	});
})();
