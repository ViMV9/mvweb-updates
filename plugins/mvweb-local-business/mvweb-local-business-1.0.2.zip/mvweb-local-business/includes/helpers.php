<?php
/**
 * Helper functions for MVweb Local Business.
 *
 * Settings accessors and schema-fragment builders (address, opening hours,
 * sameAs). The full JSON-LD node is assembled in MVweb_LB_Schema.
 *
 * @package mvweb_lb
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Get plugin settings merged with defaults.
 *
 * @since 1.0.0
 * @return array<string, mixed>
 */
function mvweb_lb_get_settings() {
	$saved = get_option( MVweb_LB_Settings::OPTION, array() );
	if ( ! is_array( $saved ) ) {
		$saved = array();
	}
	return array_merge( MVweb_LB_Settings::defaults(), $saved );
}

/**
 * Whether schema output is enabled and has the Google-required minimum
 * (name + address locality/street).
 *
 * @since 1.0.0
 * @param array<string, mixed>|null $settings Optional pre-fetched settings.
 * @return bool
 */
function mvweb_lb_is_ready( $settings = null ) {
	$s = null === $settings ? mvweb_lb_get_settings() : $settings;
	if ( empty( $s['enabled'] ) || '' === trim( (string) $s['name'] ) ) {
		return false;
	}
	// Address is required by Google — need at least a street or a city.
	return '' !== trim( (string) $s['street'] ) || '' !== trim( (string) $s['city'] );
}

/**
 * Build the PostalAddress node.
 *
 * @since 1.0.0
 * @param array<string, mixed> $s Settings.
 * @return array<string, string>
 */
function mvweb_lb_build_address( array $s ) {
	$map = array(
		'streetAddress'   => trim( (string) $s['street'] ),
		'addressLocality' => trim( (string) $s['city'] ),
		'addressRegion'   => trim( (string) $s['region'] ),
		'postalCode'      => trim( (string) $s['postal'] ),
		'addressCountry'  => trim( (string) $s['country'] ),
	);

	$address = array( '@type' => 'PostalAddress' );
	foreach ( $map as $key => $value ) {
		if ( '' !== $value ) {
			$address[ $key ] = $value;
		}
	}

	return $address;
}

/**
 * Build the openingHoursSpecification array.
 *
 * A day may produce several specification objects (e.g. one per interval when
 * there is a lunch break). All-day maps to 00:00–23:59. Closed days are omitted.
 * Special days are appended as single-date closed specs (opens = closes = 00:00
 * bounded by validFrom/validThrough) — the documented way to mark a date off.
 *
 * @since 1.0.0
 * @param array<string, mixed> $s Settings.
 * @return array<int, array<string, string>>
 */
function mvweb_lb_build_hours( array $s ) {
	$hours = isset( $s['hours'] ) && is_array( $s['hours'] ) ? $s['hours'] : array();
	$spec  = array();

	foreach ( MVweb_LB_Settings::DAYS as $day => $schema_day ) {
		$row = isset( $hours[ $day ] ) && is_array( $hours[ $day ] ) ? $hours[ $day ] : array();

		if ( ! empty( $row['closed'] ) ) {
			continue;
		}

		if ( ! empty( $row['allday'] ) ) {
			$spec[] = array(
				'@type'     => 'OpeningHoursSpecification',
				'dayOfWeek' => $schema_day,
				'opens'     => '00:00',
				'closes'    => '23:59',
			);
			continue;
		}

		$intervals = isset( $row['intervals'] ) && is_array( $row['intervals'] ) ? $row['intervals'] : array();
		foreach ( $intervals as $interval ) {
			$open  = isset( $interval['open'] ) ? (string) $interval['open'] : '';
			$close = isset( $interval['close'] ) ? (string) $interval['close'] : '';
			if ( '' === $open || '' === $close ) {
				continue;
			}
			$spec[] = array(
				'@type'     => 'OpeningHoursSpecification',
				'dayOfWeek' => $schema_day,
				'opens'     => $open,
				'closes'    => $close,
			);
		}
	}

	$special = isset( $s['special_days'] ) && is_array( $s['special_days'] ) ? $s['special_days'] : array();
	foreach ( $special as $item ) {
		$date = isset( $item['date'] ) ? (string) $item['date'] : '';
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			continue;
		}
		$spec[] = array(
			'@type'        => 'OpeningHoursSpecification',
			'opens'        => '00:00',
			'closes'       => '00:00',
			'validFrom'    => $date,
			'validThrough' => $date,
		);
	}

	return $spec;
}

/**
 * Build the sameAs list (social/catalogue profiles + reviews aggregator).
 *
 * The reviews URL is exposed only as a trusted third-party profile link — the
 * plugin never emits a self-serving aggregateRating (Google policy).
 *
 * @since 1.0.0
 * @param array<string, mixed> $s Settings.
 * @return array<int, string>
 */
function mvweb_lb_build_sameas( array $s ) {
	$urls = isset( $s['sameas'] ) && is_array( $s['sameas'] ) ? $s['sameas'] : array();

	if ( ! empty( $s['reviews_url'] ) ) {
		$urls[] = (string) $s['reviews_url'];
	}

	$urls = array_values( array_unique( array_filter( array_map( 'trim', $urls ) ) ) );

	return $urls;
}

/**
 * Combined @type for the business (Organization + LocalBusiness + subtype).
 *
 * @since 1.0.0
 * @param array<string, mixed> $s Settings.
 * @return array<int, string>
 */
function mvweb_lb_build_type( array $s ) {
	$type = isset( $s['business_type'] ) ? (string) $s['business_type'] : 'LocalBusiness';

	if ( 'LocalBusiness' === $type ) {
		return array( 'Organization', 'LocalBusiness' );
	}

	return array( 'Organization', 'LocalBusiness', $type );
}
