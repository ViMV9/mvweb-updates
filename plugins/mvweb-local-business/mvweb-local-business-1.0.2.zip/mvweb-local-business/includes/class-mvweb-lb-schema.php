<?php
/**
 * Schema output for MVweb Local Business.
 *
 * Anti-duplicate strategy (SPEC §4):
 *   1. Yoast active   → augment its Organization node (same @id) via
 *                       `wpseo_schema_organization`.
 *   2. Rank Math active → augment/inject through `rank_math/json_ld`.
 *   3. Neither         → print a standalone node in wp_head on the front page.
 *
 * The plugin never emits a self-serving aggregateRating/review (Google policy);
 * the reviews aggregator is exposed only as a sameAs profile link.
 *
 * @package mvweb_lb
 * @since   1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Schema controller.
 *
 * @since 1.0.0
 */
final class MVweb_LB_Schema {

	/**
	 * Node keys where an existing SEO-plugin value wins over ours.
	 *
	 * @var array<int, string>
	 */
	const KEEP_EXISTING = array( 'name', 'url', 'logo', 'description' );

	/**
	 * Whether our data was merged into an SEO plugin's graph this request.
	 *
	 * Set by the Yoast/Rank Math filters (which run early on wp_head). The
	 * wp_head fallback checks it late (priority 99) and only prints a standalone
	 * node when no integration happened — so an active SEO plugin that does not
	 * emit an Organization node on this page still gets our markup.
	 *
	 * @var bool
	 */
	private static $integrated = false;

	/**
	 * Wire hooks.
	 *
	 * The Yoast/Rank Math filters only fire when those plugins are active, so
	 * registering them unconditionally is harmless.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_filter( 'wpseo_schema_organization', array( __CLASS__, 'filter_yoast' ), 20 );
		add_filter( 'rank_math/json_ld', array( __CLASS__, 'filter_rankmath' ), 20, 2 );
		add_action( 'wp_head', array( __CLASS__, 'maybe_print_fallback' ), 99 );
	}

	/**
	 * Build the Organization + LocalBusiness node (without @context).
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $s Settings.
	 * @return array<string, mixed>
	 */
	public static function build_node( array $s ) {
		$node = array(
			'@type' => mvweb_lb_build_type( $s ),
			'@id'   => home_url( '/' ) . '#organization',
			'name'  => (string) $s['name'],
			'url'   => home_url( '/' ),
		);

		if ( '' !== (string) $s['alt_name'] ) {
			$node['alternateName'] = (string) $s['alt_name'];
		}
		if ( '' !== (string) $s['description'] ) {
			$node['description'] = (string) $s['description'];
		}

		$address = mvweb_lb_build_address( $s );
		if ( count( $address ) > 1 ) {
			$node['address'] = $address;
		}

		if ( '' !== (string) $s['lat'] && '' !== (string) $s['lng'] ) {
			$node['geo'] = array(
				'@type'     => 'GeoCoordinates',
				'latitude'  => (string) $s['lat'],
				'longitude' => (string) $s['lng'],
			);
		}

		if ( '' !== (string) $s['phone'] ) {
			$node['telephone'] = (string) $s['phone'];
		}
		if ( '' !== (string) $s['email'] ) {
			$node['email'] = (string) $s['email'];
		}

		$hours = mvweb_lb_build_hours( $s );
		if ( ! empty( $hours ) ) {
			$node['openingHoursSpecification'] = $hours;
		}

		if ( '' !== (string) $s['price_range'] ) {
			$node['priceRange'] = (string) $s['price_range'];
		}

		if ( '' !== (string) $s['logo'] ) {
			$node['logo'] = (string) $s['logo'];
		}

		$images = array();
		if ( '' !== (string) $s['facade'] ) {
			$images[] = (string) $s['facade'];
		}
		if ( ! empty( $s['gallery'] ) && is_array( $s['gallery'] ) ) {
			foreach ( $s['gallery'] as $image ) {
				$images[] = (string) $image;
			}
		}
		if ( ! empty( $images ) ) {
			$node['image'] = array_values( array_unique( $images ) );
		}

		$sameas = mvweb_lb_build_sameas( $s );
		if ( ! empty( $sameas ) ) {
			$node['sameAs'] = $sameas;
		}

		if ( preg_match( '/^\d{4}$/', (string) $s['founded'] ) ) {
			$node['foundingDate'] = (string) $s['founded'];
		}
		if ( '' !== (string) $s['slogan'] ) {
			$node['slogan'] = (string) $s['slogan'];
		}
		if ( ! empty( $s['area_served'] ) && is_array( $s['area_served'] ) ) {
			$node['areaServed'] = array_values( $s['area_served'] );
		}

		return $node;
	}

	/**
	 * Merge our LocalBusiness node into an existing Organization graph piece.
	 *
	 * Preserves the target's @id and its name/url/logo/description when set,
	 * always upgrades @type and injects the LocalBusiness-specific fields.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $target Existing node.
	 * @param array<string, mixed> $node   Our node.
	 * @return array<string, mixed>
	 */
	private static function merge_into( array $target, array $node ) {
		// Keep the target's @id if it has one.
		if ( empty( $target['@id'] ) && isset( $node['@id'] ) ) {
			$target['@id'] = $node['@id'];
		}
		unset( $node['@id'] );

		// Always upgrade the type.
		if ( isset( $node['@type'] ) ) {
			$target['@type'] = $node['@type'];
			unset( $node['@type'] );
		}

		// Union sameAs.
		if ( isset( $node['sameAs'] ) ) {
			$existing         = isset( $target['sameAs'] ) ? (array) $target['sameAs'] : array();
			$target['sameAs'] = array_values( array_unique( array_merge( $existing, $node['sameAs'] ) ) );
			unset( $node['sameAs'] );
		}

		foreach ( $node as $key => $value ) {
			if ( in_array( $key, self::KEEP_EXISTING, true ) && ! empty( $target[ $key ] ) ) {
				continue;
			}
			$target[ $key ] = $value;
		}

		return $target;
	}

	/**
	 * Augment the Yoast Organization node.
	 *
	 * @since 1.0.0
	 * @param mixed $data Organization graph piece from Yoast.
	 * @return mixed
	 */
	public static function filter_yoast( $data ) {
		if ( ! is_array( $data ) ) {
			return $data;
		}
		$s = mvweb_lb_get_settings();
		if ( ! mvweb_lb_is_ready( $s ) ) {
			return $data;
		}
		self::$integrated = true;
		return self::merge_into( $data, self::build_node( $s ) );
	}

	/**
	 * Augment the Rank Math Organization node, or inject a LocalBusiness node.
	 *
	 * ⚠️ Filter name/signature to be re-verified on a live Rank Math install
	 * (SPEC §4 — vendor docs were unreachable).
	 *
	 * @since 1.0.0
	 * @param mixed $data   Associative array of schema pieces keyed by type.
	 * @param mixed $jsonld Rank Math JsonLD instance (unused).
	 * @return mixed
	 */
	public static function filter_rankmath( $data, $jsonld ) {
		unset( $jsonld );
		if ( ! is_array( $data ) ) {
			return $data;
		}
		$s = mvweb_lb_get_settings();
		if ( ! mvweb_lb_is_ready( $s ) ) {
			return $data;
		}

		$node = self::build_node( $s );

		if ( isset( $data['Organization'] ) && is_array( $data['Organization'] ) ) {
			$data['Organization'] = self::merge_into( $data['Organization'], $node );
			self::$integrated     = true;
		} elseif ( isset( $data['LocalBusiness'] ) && is_array( $data['LocalBusiness'] ) ) {
			// Rank Math already renders a Local Business node — merge, don't clobber.
			$data['LocalBusiness'] = self::merge_into( $data['LocalBusiness'], $node );
			self::$integrated      = true;
		} elseif ( is_front_page() ) {
			$node                  = array( '@context' => 'https://schema.org' ) + $node;
			$data['LocalBusiness'] = $node;
			self::$integrated      = true;
		}

		return $data;
	}

	/**
	 * Print a standalone JSON-LD node when no SEO plugin integrated our data.
	 *
	 * Runs late (priority 99) so the Yoast/Rank Math filters — which fire early
	 * on wp_head — have already set the integration flag when they emit an
	 * Organization node. If they didn't (SEO plugin active but no Organization
	 * on this page), we still output a standalone node.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function maybe_print_fallback() {
		if ( self::$integrated || ! is_front_page() ) {
			return;
		}
		$s = mvweb_lb_get_settings();
		if ( ! mvweb_lb_is_ready( $s ) ) {
			return;
		}

		$node = array( '@context' => 'https://schema.org' ) + self::build_node( $s );
		$json = wp_json_encode( $node, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if ( false === $json ) {
			return;
		}
		$json = str_replace( '</script>', '<\/script>', $json );

		// JSON is pre-encoded and </script>-guarded; not HTML-context output.
		echo '<script type="application/ld+json">' . $json . '</script>' . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
