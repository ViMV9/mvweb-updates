<?php
/**
 * Plugin Name:       MVweb Related Posts
 * Plugin URI:        https://mvweb.ru/plugins/mvweb-related-posts
 * Description:       Related posts with weighted relevance scoring, ItemList schema and flexible block layout.
 * Version:           1.0.0
 * Requires at least: 7.0
 * Tested up to:      7.1
 * Requires PHP:      8.2
 * Author:            MVweb
 * Author URI:        https://mvweb.ru
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       mvweb-related-posts
 * Domain Path:       /languages
 *
 * @package mvweb_rp
 *
 * @since 1.0.0 Initial release.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Prevent double loading.
if ( defined( 'MVWEB_RP_VERSION' ) ) {
	return;
}

define( 'MVWEB_RP_VERSION', '1.0.0' );
define( 'MVWEB_RP_PATH', plugin_dir_path( __FILE__ ) );
define( 'MVWEB_RP_URL', plugin_dir_url( __FILE__ ) );
define( 'MVWEB_RP_BASENAME', plugin_basename( __FILE__ ) );

// ───────────────────────────────────────────────
// Shared classes: bundled → shared fallback (dev)
// ───────────────────────────────────────────────
$shared_path = dirname( dirname( MVWEB_RP_PATH ) ) . '/shared/';

// Load MVweb Menu.
if ( file_exists( MVWEB_RP_PATH . 'includes/class-mvweb-menu.php' ) ) {
	require_once MVWEB_RP_PATH . 'includes/class-mvweb-menu.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-menu.php' ) ) {
	require_once $shared_path . 'class-mvweb-menu.php';
}

// IMPORTANT: Ensure menu singleton is initialized.
if ( class_exists( 'MVweb_Menu' ) ) {
	MVweb_Menu::get_instance();
}

// Load MVweb Updater.
if ( file_exists( MVWEB_RP_PATH . 'includes/class-mvweb-updater.php' ) ) {
	require_once MVWEB_RP_PATH . 'includes/class-mvweb-updater.php';
} elseif ( file_exists( $shared_path . 'class-mvweb-updater.php' ) ) {
	require_once $shared_path . 'class-mvweb-updater.php';
}

if ( class_exists( 'MVweb_Updater' ) ) {
	MVweb_Updater::create( __FILE__, 'mvweb-related-posts' );
}

// ───────────────────────────────────────────────
// Plugin registration
// ───────────────────────────────────────────────

// Register this plugin with MVweb Menu hub page.
add_filter(
	'mvweb_registered_plugins',
	function ( $plugins ) {
		$plugins['mvweb-related-posts'] = array(
			'name'         => 'MVweb Related Posts',
			'description'  => __( 'Related posts with weighted relevance scoring, ItemList schema and flexible block layout.', 'mvweb-related-posts' ),
			'url'          => 'https://mvweb.ru/plugins/mvweb-related-posts',
			'settings_url' => 'admin.php?page=mvweb-related-posts',
			'textdomain'   => 'mvweb-related-posts',
		);
		return $plugins;
	}
);

/**
 * Load plugin textdomain.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_rp_load_textdomain() {
	load_plugin_textdomain(
		'mvweb-related-posts',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages/'
	);
}
add_action( 'plugins_loaded', 'mvweb_rp_load_textdomain' );

require_once MVWEB_RP_PATH . 'includes/class-mvweb-rp-settings.php';
require_once MVWEB_RP_PATH . 'includes/class-mvweb-rp-stemmer.php';
require_once MVWEB_RP_PATH . 'includes/class-mvweb-rp-cache.php';
require_once MVWEB_RP_PATH . 'includes/class-mvweb-rp-scorer.php';
require_once MVWEB_RP_PATH . 'includes/class-mvweb-rp-indexer.php';
require_once MVWEB_RP_PATH . 'includes/class-mvweb-rp-query.php';
require_once MVWEB_RP_PATH . 'includes/class-mvweb-rp-schema.php';
require_once MVWEB_RP_PATH . 'includes/class-mvweb-rp-activator.php';
require_once MVWEB_RP_PATH . 'includes/helpers.php';
require_once MVWEB_RP_PATH . 'admin/class-mvweb-rp-metabox.php';
require_once MVWEB_RP_PATH . 'admin/class-mvweb-rp-admin.php';
require_once MVWEB_RP_PATH . 'public/class-mvweb-rp-public.php';
require_once MVWEB_RP_PATH . 'public/class-mvweb-rp-widget.php';

add_filter( 'cron_schedules', array( 'MVweb_RP_Indexer', 'add_schedule' ) ); // phpcs:ignore WordPress.WP.CronInterval -- five minute batches keep the queue short.

register_activation_hook( __FILE__, array( 'MVweb_RP_Activator', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'MVweb_RP_Activator', 'deactivate' ) );

/**
 * Boot the plugin once WordPress is ready.
 *
 * @since 1.0.0
 * @return void
 */
function mvweb_rp_boot() {
	MVweb_RP_Activator::maybe_upgrade();
	MVweb_RP_Indexer::init();
	MVweb_RP_Public::init();

	if ( is_admin() ) {
		MVweb_RP_Admin::init();
		MVweb_RP_Metabox::init();
	}
}
add_action( 'init', 'mvweb_rp_boot' );
add_action( 'widgets_init', array( 'MVweb_RP_Widget', 'register' ) );
