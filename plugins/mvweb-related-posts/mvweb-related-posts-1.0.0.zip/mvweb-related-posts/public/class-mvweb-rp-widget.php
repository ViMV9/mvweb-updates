<?php
/**
 * Sidebar widget rendering the related posts block.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_RP_Widget
 *
 * @since 1.0.0
 */
class MVweb_RP_Widget extends WP_Widget {

	/**
	 * Register the widget definition.
	 *
	 * @since 1.0.0
	 */
	public function __construct() {
		parent::__construct(
			'mvweb_rp_widget',
			__( 'MVweb Related Posts', 'mvweb-related-posts' ),
			array(
				'description'           => __( 'Related posts for the current single post.', 'mvweb-related-posts' ),
				'show_instance_in_rest' => true,
			)
		);
	}

	/**
	 * Register the widget with WordPress.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register() {
		register_widget( __CLASS__ );
	}

	/**
	 * Frontend output.
	 *
	 * @since 1.0.0
	 * @param array<string, string> $sidebar_args Sidebar arguments.
	 * @param array<string, mixed>  $instance     Saved widget settings.
	 * @return void
	 */
	public function widget( $sidebar_args, $instance ) {
		if ( ! is_singular() ) {
			return;
		}

		$post_id = (int) get_the_ID();
		if ( $post_id <= 0 ) {
			return;
		}

		$html = MVweb_RP_Public::render(
			$post_id,
			array(
				'count'    => isset( $instance['count'] ) ? (int) $instance['count'] : 0,
				'template' => isset( $instance['template'] ) ? sanitize_key( (string) $instance['template'] ) : '',
				'title'    => isset( $instance['title'] ) ? (string) $instance['title'] : null,
			)
		);

		if ( '' === $html ) {
			return;
		}

		echo wp_kses_post( $sidebar_args['before_widget'] ?? '' );
		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- markup escaped in templates.
		echo wp_kses_post( $sidebar_args['after_widget'] ?? '' );
	}

	/**
	 * Widget settings form.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $instance Saved widget settings.
	 * @return void
	 */
	public function form( $instance ) {
		$title    = isset( $instance['title'] ) ? (string) $instance['title'] : '';
		$count    = isset( $instance['count'] ) ? (int) $instance['count'] : 0;
		$template = isset( $instance['template'] ) ? (string) $instance['template'] : '';
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>">
				<?php esc_html_e( 'Title', 'mvweb-related-posts' ); ?>
			</label>
			<input class="widefat"
				id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>"
				type="text"
				value="<?php echo esc_attr( $title ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>">
				<?php esc_html_e( 'Number of posts (0 — use plugin setting)', 'mvweb-related-posts' ); ?>
			</label>
			<input class="tiny-text"
				id="<?php echo esc_attr( $this->get_field_id( 'count' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'count' ) ); ?>"
				type="number" min="0" max="12" step="1"
				value="<?php echo esc_attr( (string) $count ); ?>">
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'template' ) ); ?>">
				<?php esc_html_e( 'Template', 'mvweb-related-posts' ); ?>
			</label>
			<select class="widefat"
				id="<?php echo esc_attr( $this->get_field_id( 'template' ) ); ?>"
				name="<?php echo esc_attr( $this->get_field_name( 'template' ) ); ?>">
				<option value="" <?php selected( $template, '' ); ?>><?php esc_html_e( 'Plugin setting', 'mvweb-related-posts' ); ?></option>
				<option value="cards" <?php selected( $template, 'cards' ); ?>><?php esc_html_e( 'Cards', 'mvweb-related-posts' ); ?></option>
				<option value="list" <?php selected( $template, 'list' ); ?>><?php esc_html_e( 'List', 'mvweb-related-posts' ); ?></option>
				<option value="links" <?php selected( $template, 'links' ); ?>><?php esc_html_e( 'Links', 'mvweb-related-posts' ); ?></option>
			</select>
		</p>
		<?php
	}

	/**
	 * Sanitise submitted widget settings.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $new_instance Submitted values.
	 * @param array<string, mixed> $old_instance Previous values.
	 * @return array<string, mixed>
	 */
	public function update( $new_instance, $old_instance ) {
		unset( $old_instance );

		$template = isset( $new_instance['template'] ) ? sanitize_key( (string) $new_instance['template'] ) : '';

		return array(
			'title'    => sanitize_text_field( (string) ( $new_instance['title'] ?? '' ) ),
			'count'    => max( 0, min( 12, (int) ( $new_instance['count'] ?? 0 ) ) ),
			'template' => in_array( $template, MVweb_RP_Settings::TEMPLATES, true ) ? $template : '',
		);
	}
}
