<?php
/**
 * Frontend output: automatic injection, shortcode and rendering.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_RP_Public
 *
 * @since 1.0.0
 */
class MVweb_RP_Public {

	const IMAGE_SIZE = 'mvweb_rp_thumb';

	/**
	 * Register frontend hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		self::register_image_size();
		add_shortcode( 'mvweb_related_posts', array( __CLASS__, 'shortcode' ) );

		if ( ! MVweb_RP_Settings::get( 'enabled', true ) ) {
			return;
		}

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_styles' ) );

		if ( MVweb_RP_Settings::get( 'auto_output', true ) && ! self::smart_links_owns_block() ) {
			add_filter( 'the_content', array( __CLASS__, 'inject' ), 20 );
		}
	}

	/**
	 * Register the plugin thumbnail size.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register_image_size() {
		add_image_size( self::IMAGE_SIZE, 480, 480, false );
	}

	/**
	 * Whether MVweb Smart Links already prints its own related block.
	 *
	 * @since 1.0.0
	 * @return bool
	 */
	public static function smart_links_owns_block() {
		if ( ! class_exists( 'MVweb_SML_Related' ) || ! function_exists( 'mvweb_sml_get_setting' ) ) {
			return false;
		}

		return (bool) mvweb_sml_get_setting( 'enabled' ) && (bool) mvweb_sml_get_setting( 'related_enabled' );
	}

	/**
	 * Append the block to single post content.
	 *
	 * @since 1.0.0
	 * @param string $content Post content.
	 * @return string
	 */
	public static function inject( $content ) {
		if ( ! is_string( $content ) || '' === $content ) {
			return $content;
		}

		if ( is_feed() || ! is_singular() || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		$post_id = (int) get_the_ID();
		if ( $post_id <= 0 ) {
			return $content;
		}

		if ( ! in_array( get_post_type( $post_id ), (array) MVweb_RP_Settings::get( 'post_types', array( 'post' ) ), true ) ) {
			return $content;
		}

		if ( MVweb_RP_Metabox::is_hidden( $post_id ) ) {
			return $content;
		}

		return $content . self::render( $post_id );
	}

	/**
	 * Shortcode handler.
	 *
	 * @since 1.0.0
	 * @param array<string, string>|string $atts Shortcode attributes.
	 * @return string
	 */
	public static function shortcode( $atts ) {
		$atts = shortcode_atts(
			array(
				'count'    => 0,
				'template' => '',
				'title'    => null,
				'post_id'  => 0,
				'columns'  => 0,
			),
			$atts,
			'mvweb_related_posts'
		);

		$post_id = (int) $atts['post_id'];
		if ( $post_id <= 0 ) {
			$post_id = (int) get_the_ID();
		}

		return self::render(
			$post_id,
			array(
				'count'    => (int) $atts['count'],
				'template' => sanitize_key( (string) $atts['template'] ),
				'title'    => null === $atts['title'] ? null : sanitize_text_field( (string) $atts['title'] ),
				'columns'  => (int) $atts['columns'],
			)
		);
	}

	/**
	 * Render the block markup.
	 *
	 * @since 1.0.0
	 * @param int                  $post_id Source post ID.
	 * @param array<string, mixed> $args    Overrides for count, template, title and columns.
	 * @return string
	 */
	public static function render( $post_id, array $args = array() ) {
		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return '';
		}

		$count    = ! empty( $args['count'] ) ? (int) $args['count'] : (int) MVweb_RP_Settings::get( 'count', 4 );
		$template = ! empty( $args['template'] ) ? (string) $args['template'] : (string) MVweb_RP_Settings::get( 'template', 'cards' );
		$columns  = ! empty( $args['columns'] ) ? (int) $args['columns'] : (int) MVweb_RP_Settings::get( 'columns', 3 );
		$title    = array_key_exists( 'title', $args ) && null !== $args['title']
			? (string) $args['title']
			: (string) MVweb_RP_Settings::get( 'block_title', '' );

		if ( ! in_array( $template, MVweb_RP_Settings::TEMPLATES, true ) ) {
			$template = 'cards';
		}

		$count   = max( 1, min( 12, $count ) );
		$columns = max( 1, min( 6, $columns ) );

		$cache_key = MVweb_RP_Cache::key(
			'block',
			array( $post_id, $count, $template, $columns, $title )
		);

		$cached = MVweb_RP_Cache::get( $cache_key );
		if ( is_string( $cached ) ) {
			return $cached;
		}

		$posts = MVweb_RP_Query::get_posts( $post_id, $count );
		if ( empty( $posts ) ) {
			MVweb_RP_Cache::set( $cache_key, '' );
			return '';
		}

		$html = self::render_template(
			$template,
			array(
				'posts'    => $posts,
				'title'    => $title,
				'columns'  => $columns,
				'template' => $template,
				'post_id'  => $post_id,
			)
		);

		if ( MVweb_RP_Settings::get( 'schema_enabled', true ) ) {
			$html .= MVweb_RP_Schema::item_list( $posts );
		}

		MVweb_RP_Cache::set( $cache_key, $html );

		return $html;
	}

	/**
	 * Load a template file, allowing theme overrides.
	 *
	 * @since 1.0.0
	 * @param string               $template Template slug.
	 * @param array<string, mixed> $args     Template arguments.
	 * @return string
	 */
	private static function render_template( $template, array $args ) {
		$file = locate_template( array( 'mvweb-related-posts/' . $template . '.php' ) );

		if ( ! $file ) {
			$file = MVWEB_RP_PATH . 'templates/' . $template . '.php';
		}

		if ( ! file_exists( $file ) ) {
			return '';
		}

		ob_start();
		load_template( $file, false, $args );

		return (string) ob_get_clean();
	}

	/**
	 * Enqueue the frontend stylesheet and inline settings.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function enqueue_styles() {
		if ( ! is_singular() ) {
			return;
		}

		wp_register_style( 'mvweb-rp', MVWEB_RP_URL . 'public/css/public.min.css', array(), mvweb_rp_asset_ver( 'public/css/public.min.css' ) );
		wp_enqueue_style( 'mvweb-rp' );

		$aspect = (string) MVweb_RP_Settings::get( 'aspect', '16-9' );
		$ratio  = array(
			'16-9' => '16 / 9',
			'4-3'  => '4 / 3',
			'1-1'  => '1 / 1',
		);

		$inline = ':root{--mvweb-rp-ratio:' . ( $ratio[ $aspect ] ?? '16 / 9' ) . ';}';

		$custom_css = (string) MVweb_RP_Settings::get( 'custom_css', '' );
		if ( '' !== $custom_css ) {
			$inline .= $custom_css;
		}

		wp_add_inline_style( 'mvweb-rp', $inline );
	}
}
