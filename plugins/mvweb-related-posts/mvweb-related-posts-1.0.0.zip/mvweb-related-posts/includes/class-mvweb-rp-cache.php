<?php
/**
 * Rendered block cache: object cache with a transient fallback.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_RP_Cache
 *
 * @since 1.0.0
 */
class MVweb_RP_Cache {

	const GROUP = 'mvweb_rp';

	const VERSION_OPTION = 'mvweb_rp_cache_version';

	const TTL = DAY_IN_SECONDS;

	/**
	 * Current cache generation.
	 *
	 * @since 1.0.0
	 * @return int
	 */
	public static function version() {
		return (int) get_option( self::VERSION_OPTION, 1 );
	}

	/**
	 * Invalidate everything cached so far.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function bump() {
		update_option( self::VERSION_OPTION, self::version() + 1, false );
	}

	/**
	 * Build a namespaced cache key.
	 *
	 * @since 1.0.0
	 * @param string               $prefix Key prefix.
	 * @param array<string, mixed> $parts  Values the cached result depends on.
	 * @return string
	 */
	public static function key( $prefix, array $parts ) {
		return $prefix . '_' . self::version() . '_' . md5( (string) wp_json_encode( $parts ) );
	}

	/**
	 * Read a cached value.
	 *
	 * @since 1.0.0
	 * @param string $key Cache key.
	 * @return mixed False when the key is unknown.
	 */
	public static function get( $key ) {
		if ( wp_using_ext_object_cache() ) {
			return wp_cache_get( $key, self::GROUP );
		}

		return get_transient( self::GROUP . '_' . $key );
	}

	/**
	 * Store a value.
	 *
	 * @since 1.0.0
	 * @param string $key   Cache key.
	 * @param mixed  $value Value to store.
	 * @return void
	 */
	public static function set( $key, $value ) {
		if ( wp_using_ext_object_cache() ) {
			wp_cache_set( $key, $value, self::GROUP, self::TTL );
			return;
		}

		set_transient( self::GROUP . '_' . $key, $value, self::TTL );
	}
}
