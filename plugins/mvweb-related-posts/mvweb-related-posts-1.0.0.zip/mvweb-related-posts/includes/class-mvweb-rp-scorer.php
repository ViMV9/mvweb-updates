<?php
/**
 * Relevance scoring between a source post and its candidates.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_RP_Scorer
 *
 * @since 1.0.0
 */
class MVweb_RP_Scorer {

	const CANDIDATE_LIMIT = 200;

	const FRESHNESS_WINDOW_DAYS = 730;

	/**
	 * Score every candidate related to the given post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Source post ID.
	 * @param int $limit   Maximum rows to return.
	 * @return array<int, array{score: float, factors: array<string, float>}>
	 */
	public static function score_post( $post_id, $limit = 12 ) {
		$post_id = (int) $post_id;
		$post    = get_post( $post_id );

		if ( ! $post instanceof WP_Post ) {
			return array();
		}

		$post_types = MVweb_RP_Settings::get( 'post_types', array( 'post' ) );
		if ( ! in_array( $post->post_type, $post_types, true ) ) {
			return array();
		}

		$source_tokens = MVweb_RP_Indexer::get_tokens( $post_id );
		$source_terms  = self::get_terms_map( array( $post_id ) );
		$source_terms  = $source_terms[ $post_id ] ?? array();

		$candidates = self::collect_candidates( $post_id, $source_tokens, $source_terms, $post_types );
		if ( empty( $candidates ) ) {
			return array();
		}

		$candidate_tokens = MVweb_RP_Indexer::get_tokens_bulk( array_keys( $candidates ) );
		$candidate_terms  = self::get_terms_map( array_keys( $candidates ) );

		$weights = self::weights();
		$scored  = array();

		foreach ( $candidates as $candidate_id => $candidate ) {
			$factors = self::factors(
				$source_tokens,
				$source_terms,
				$candidate_tokens[ $candidate_id ] ?? array(),
				$candidate_terms[ $candidate_id ] ?? array(),
				$candidate['post_date_gmt']
			);

			$score = 0.0;
			foreach ( $factors as $factor => $value ) {
				$score += $value * $weights[ $factor ];
			}

			if ( $score <= 0 ) {
				continue;
			}

			$scored[ $candidate_id ] = array(
				'score'   => round( $score, 4 ),
				'factors' => $factors,
			);
		}

		uasort(
			$scored,
			static function ( $a, $b ) {
				return $b['score'] <=> $a['score'];
			}
		);

		if ( $limit > 0 && count( $scored ) > $limit ) {
			$scored = array_slice( $scored, 0, $limit, true );
		}

		return $scored;
	}

	/**
	 * Current weight values keyed by factor name.
	 *
	 * @since 1.0.0
	 * @return array<string, int>
	 */
	public static function weights() {
		return array(
			'category'  => (int) MVweb_RP_Settings::get( 'weight_category', 0 ),
			'tag'       => (int) MVweb_RP_Settings::get( 'weight_tag', 0 ),
			'taxonomy'  => (int) MVweb_RP_Settings::get( 'weight_taxonomy', 0 ),
			'title'     => (int) MVweb_RP_Settings::get( 'weight_title', 0 ),
			'content'   => (int) MVweb_RP_Settings::get( 'weight_content', 0 ),
			'freshness' => (int) MVweb_RP_Settings::get( 'weight_freshness', 0 ),
		);
	}

	/**
	 * Taxonomies participating in scoring.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	public static function taxonomies() {
		$extra = MVweb_RP_Settings::get( 'taxonomies', array() );
		$extra = is_array( $extra ) ? $extra : array();

		return array_values( array_unique( array_merge( array( 'category', 'post_tag' ), $extra ) ) );
	}

	/**
	 * Individual similarity factors, each normalised to 0..1.
	 *
	 * @since 1.0.0
	 * @param array<string, array{weight: int, in_title: int}> $source_tokens    Source stems.
	 * @param array<string, int[]>                             $source_terms     Source term ids per taxonomy.
	 * @param array<string, array{weight: int, in_title: int}> $candidate_tokens Candidate stems.
	 * @param array<string, int[]>                             $candidate_terms  Candidate term ids per taxonomy.
	 * @param string                                           $candidate_date   Candidate GMT date.
	 * @return array<string, float>
	 */
	private static function factors( array $source_tokens, array $source_terms, array $candidate_tokens, array $candidate_terms, $candidate_date ) {
		$extra_taxonomies = array_diff( self::taxonomies(), array( 'category', 'post_tag' ) );

		$taxonomy_overlap = 0.0;
		foreach ( $extra_taxonomies as $taxonomy ) {
			$taxonomy_overlap = max(
				$taxonomy_overlap,
				self::term_overlap( $source_terms[ $taxonomy ] ?? array(), $candidate_terms[ $taxonomy ] ?? array() )
			);
		}

		return array(
			'category'  => self::term_overlap( $source_terms['category'] ?? array(), $candidate_terms['category'] ?? array() ),
			'tag'       => self::term_overlap( $source_terms['post_tag'] ?? array(), $candidate_terms['post_tag'] ?? array() ),
			'taxonomy'  => $taxonomy_overlap,
			'title'     => self::title_overlap( $source_tokens, $candidate_tokens ),
			'content'   => self::token_overlap( $source_tokens, $candidate_tokens ),
			'freshness' => self::freshness( $candidate_date ),
		);
	}

	/**
	 * Share of source terms also present on the candidate.
	 *
	 * @since 1.0.0
	 * @param int[] $source    Source term ids.
	 * @param int[] $candidate Candidate term ids.
	 * @return float
	 */
	private static function term_overlap( array $source, array $candidate ) {
		if ( empty( $source ) || empty( $candidate ) ) {
			return 0.0;
		}

		$shared = count( array_intersect( $source, $candidate ) );

		return $shared > 0 ? $shared / count( $source ) : 0.0;
	}

	/**
	 * Share of source title stems found in the candidate.
	 *
	 * @since 1.0.0
	 * @param array<string, array{weight: int, in_title: int}> $source    Source stems.
	 * @param array<string, array{weight: int, in_title: int}> $candidate Candidate stems.
	 * @return float
	 */
	private static function title_overlap( array $source, array $candidate ) {
		$source_title = array_keys(
			array_filter(
				$source,
				static function ( $row ) {
					return ! empty( $row['in_title'] );
				}
			)
		);

		if ( empty( $source_title ) || empty( $candidate ) ) {
			return 0.0;
		}

		$shared = count( array_intersect( $source_title, array_keys( $candidate ) ) );

		return $shared > 0 ? $shared / count( $source_title ) : 0.0;
	}

	/**
	 * Jaccard similarity between two stem sets.
	 *
	 * @since 1.0.0
	 * @param array<string, array{weight: int, in_title: int}> $source    Source stems.
	 * @param array<string, array{weight: int, in_title: int}> $candidate Candidate stems.
	 * @return float
	 */
	private static function token_overlap( array $source, array $candidate ) {
		if ( empty( $source ) || empty( $candidate ) ) {
			return 0.0;
		}

		$source_stems    = array_keys( $source );
		$candidate_stems = array_keys( $candidate );

		$shared = count( array_intersect( $source_stems, $candidate_stems ) );
		if ( 0 === $shared ) {
			return 0.0;
		}

		$union = count( array_unique( array_merge( $source_stems, $candidate_stems ) ) );

		return $union > 0 ? $shared / $union : 0.0;
	}

	/**
	 * Freshness factor decaying over the freshness window.
	 *
	 * @since 1.0.0
	 * @param string $date_gmt Post date in GMT.
	 * @return float
	 */
	private static function freshness( $date_gmt ) {
		$timestamp = strtotime( (string) $date_gmt . ' UTC' );
		if ( ! $timestamp ) {
			return 0.0;
		}

		$age_days = ( time() - $timestamp ) / DAY_IN_SECONDS;
		if ( $age_days <= 0 ) {
			return 1.0;
		}

		return max( 0.0, 1 - ( $age_days / self::FRESHNESS_WINDOW_DAYS ) );
	}

	/**
	 * Build the candidate pool from shared stems and shared terms.
	 *
	 * @since 1.0.0
	 * @param int                                              $post_id       Source post ID.
	 * @param array<string, array{weight: int, in_title: int}> $source_tokens Source stems.
	 * @param array<string, int[]>                             $source_terms  Source term ids per taxonomy.
	 * @param string[]                                         $post_types    Allowed post types.
	 * @return array<int, array{post_date_gmt: string}>
	 */
	private static function collect_candidates( $post_id, array $source_tokens, array $source_terms, array $post_types ) {
		global $wpdb;

		$ids = array();

		$stems = array_keys( $source_tokens );
		if ( ! empty( $stems ) ) {
			$tokens_table = MVweb_RP_Indexer::tokens_table();
			$placeholders = implode( ',', array_fill( 0, count( $stems ), '%s' ) );

			$sql = "SELECT post_id, SUM(weight) AS hits FROM {$tokens_table} WHERE stem IN ({$placeholders}) AND post_id != %d GROUP BY post_id ORDER BY hits DESC LIMIT %d";

			$params = array_merge( $stems, array( $post_id, self::CANDIDATE_LIMIT ) );

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- table name interpolated, values prepared.
			$rows = $wpdb->get_col( $wpdb->prepare( $sql, $params ) );
			$ids  = array_map( 'intval', (array) $rows );
		}

		$term_taxonomy_ids = self::term_taxonomy_ids( $source_terms );
		if ( ! empty( $term_taxonomy_ids ) ) {
			$placeholders = implode( ',', array_fill( 0, count( $term_taxonomy_ids ), '%d' ) );

			$sql = "SELECT DISTINCT object_id FROM {$wpdb->term_relationships} WHERE term_taxonomy_id IN ({$placeholders}) AND object_id != %d LIMIT %d";

			$params = array_merge( $term_taxonomy_ids, array( $post_id, self::CANDIDATE_LIMIT ) );

			// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- placeholders built from a counted array.
			$rows = $wpdb->get_col( $wpdb->prepare( $sql, $params ) );
			$ids  = array_merge( $ids, array_map( 'intval', (array) $rows ) );
		}

		$ids = array_values( array_unique( array_filter( $ids ) ) );
		if ( empty( $ids ) ) {
			return array();
		}

		return self::filter_candidates( $ids, $post_types );
	}

	/**
	 * Convert term ids into term_taxonomy ids.
	 *
	 * @since 1.0.0
	 * @param array<string, int[]> $terms_map Term ids per taxonomy.
	 * @return int[]
	 */
	private static function term_taxonomy_ids( array $terms_map ) {
		$ids = array();

		foreach ( $terms_map as $taxonomy => $term_ids ) {
			foreach ( $term_ids as $term_id ) {
				$term = get_term( $term_id, $taxonomy );
				if ( $term instanceof WP_Term ) {
					$ids[] = (int) $term->term_taxonomy_id;
				}
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Drop candidates that are not published, wrong type, excluded or too old.
	 *
	 * @since 1.0.0
	 * @param int[]    $ids        Candidate ids.
	 * @param string[] $post_types Allowed post types.
	 * @return array<int, array{post_date_gmt: string}>
	 */
	private static function filter_candidates( array $ids, array $post_types ) {
		global $wpdb;

		$id_placeholders   = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$type_placeholders = implode( ',', array_fill( 0, count( $post_types ), '%s' ) );

		$sql = "SELECT ID, post_date_gmt FROM {$wpdb->posts} WHERE ID IN ({$id_placeholders}) AND post_status = 'publish' AND post_password = '' AND post_type IN ({$type_placeholders})";

		$params = array_merge( $ids, $post_types );

		$max_age_months = (int) MVweb_RP_Settings::get( 'max_age_months', 0 );
		if ( $max_age_months > 0 ) {
			$sql     .= ' AND post_date_gmt >= %s';
			$params[] = gmdate( 'Y-m-d H:i:s', strtotime( '-' . $max_age_months . ' months' ) );
		}

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- placeholders built from counted arrays.
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ) );

		$excluded_posts = MVweb_RP_Settings::get( 'exclude_posts', array() );
		$excluded_terms = MVweb_RP_Settings::get( 'exclude_terms', array() );

		$row_ids = array_map(
			static function ( $row ) {
				return (int) $row->ID;
			},
			(array) $rows
		);

		if ( ! empty( $row_ids ) ) {
			update_meta_cache( 'post', $row_ids );
			update_object_term_cache( $row_ids, $post_types );
		}

		$candidates = array();
		foreach ( (array) $rows as $row ) {
			$candidate_id = (int) $row->ID;

			if ( in_array( $candidate_id, (array) $excluded_posts, true ) ) {
				continue;
			}

			if ( get_post_meta( $candidate_id, MVweb_RP_Metabox::META_NO_SUGGEST, true ) ) {
				continue;
			}

			if ( ! empty( $excluded_terms ) && self::has_excluded_term( $candidate_id, (array) $excluded_terms ) ) {
				continue;
			}

			$candidates[ $candidate_id ] = array( 'post_date_gmt' => (string) $row->post_date_gmt );
		}

		return $candidates;
	}

	/**
	 * Whether the post carries one of the excluded terms.
	 *
	 * @since 1.0.0
	 * @param int   $post_id  Post ID.
	 * @param int[] $term_ids Excluded term ids.
	 * @return bool
	 */
	private static function has_excluded_term( $post_id, array $term_ids ) {
		foreach ( self::taxonomies() as $taxonomy ) {
			$terms = wp_get_object_terms( $post_id, $taxonomy, array( 'fields' => 'ids' ) );
			if ( is_wp_error( $terms ) ) {
				continue;
			}
			if ( array_intersect( array_map( 'intval', $terms ), $term_ids ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Term ids per taxonomy for a set of posts.
	 *
	 * @since 1.0.0
	 * @param int[] $post_ids Post ids.
	 * @return array<int, array<string, int[]>>
	 */
	private static function get_terms_map( array $post_ids ) {
		$map = array();

		if ( empty( $post_ids ) ) {
			return $map;
		}

		$terms = wp_get_object_terms(
			$post_ids,
			self::taxonomies(),
			array( 'fields' => 'all_with_object_id' )
		);

		if ( is_wp_error( $terms ) ) {
			return $map;
		}

		foreach ( $terms as $term ) {
			$map[ (int) $term->object_id ][ $term->taxonomy ][] = (int) $term->term_id;
		}

		return $map;
	}
}
