<?php
/**
 * Token and relation index: queue, cron batches, storage.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_RP_Indexer
 *
 * @since 1.0.0
 */
class MVweb_RP_Indexer {

	const CRON_HOOK = 'mvweb_rp_index_batch';

	const CRON_SCHEDULE = 'mvweb_rp_five_minutes';

	const LOCK_TRANSIENT = 'mvweb_rp_index_lock';

	const META_DIRTY = '_mvweb_rp_dirty';

	const META_INDEXED = '_mvweb_rp_indexed';

	const BATCH_SIZE = 50;

	const STORE_LIMIT = 12;

	/**
	 * Register hooks.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function init() {
		add_action( self::CRON_HOOK, array( __CLASS__, 'run_batch' ) );
		add_action( 'save_post', array( __CLASS__, 'on_save_post' ), 20, 3 );
		add_action( 'deleted_post', array( __CLASS__, 'purge_post' ) );
		add_action( 'trashed_post', array( __CLASS__, 'purge_post' ) );
		add_action( 'untrashed_post', array( __CLASS__, 'mark_dirty' ) );
	}

	/**
	 * Tokens table name.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function tokens_table() {
		global $wpdb;

		return $wpdb->prefix . 'mvweb_rp_tokens';
	}

	/**
	 * Relation index table name.
	 *
	 * @since 1.0.0
	 * @return string
	 */
	public static function index_table() {
		global $wpdb;

		return $wpdb->prefix . 'mvweb_rp_index';
	}

	/**
	 * Add the five minute cron interval.
	 *
	 * @since 1.0.0
	 * @param array<string, array{interval: int, display: string}> $schedules Registered schedules.
	 * @return array<string, array{interval: int, display: string}>
	 */
	public static function add_schedule( $schedules ) {
		$schedules[ self::CRON_SCHEDULE ] = array(
			'interval' => 5 * MINUTE_IN_SECONDS,
			'display'  => __( 'Every five minutes (MVweb Related Posts)', 'mvweb-related-posts' ),
		);

		return $schedules;
	}

	/**
	 * Schedule the recurring indexer.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function schedule() {
		if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
			wp_schedule_event( time() + MINUTE_IN_SECONDS, self::CRON_SCHEDULE, self::CRON_HOOK );
		}
	}

	/**
	 * Remove the recurring indexer.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function unschedule() {
		$timestamp = wp_next_scheduled( self::CRON_HOOK );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::CRON_HOOK );
		}
	}

	/**
	 * Queue a post after it was saved.
	 *
	 * @since 1.0.0
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @param bool    $update  Whether this is an update.
	 * @return void
	 */
	public static function on_save_post( $post_id, $post, $update ) {
		unset( $update );

		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) {
			return;
		}

		if ( ! $post instanceof WP_Post ) {
			return;
		}

		if ( ! in_array( $post->post_type, (array) MVweb_RP_Settings::get( 'post_types', array( 'post' ) ), true ) ) {
			return;
		}

		if ( 'publish' !== $post->post_status ) {
			if ( get_post_meta( $post_id, self::META_INDEXED, true ) ) {
				self::purge_post( $post_id );
			}
			return;
		}

		self::mark_dirty( $post_id );
		MVweb_RP_Cache::bump();
	}

	/**
	 * Flag a post for reindexing.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function mark_dirty( $post_id ) {
		update_post_meta( (int) $post_id, self::META_DIRTY, 1 );
	}

	/**
	 * Remove a post from both tables.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function purge_post( $post_id ) {
		global $wpdb;

		$post_id = (int) $post_id;
		if ( $post_id <= 0 ) {
			return;
		}

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->delete( self::tokens_table(), array( 'post_id' => $post_id ), array( '%d' ) );
		$wpdb->delete( self::index_table(), array( 'source_id' => $post_id ), array( '%d' ) );
		$wpdb->delete( self::index_table(), array( 'related_id' => $post_id ), array( '%d' ) );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		delete_post_meta( $post_id, self::META_DIRTY );
		delete_post_meta( $post_id, self::META_INDEXED );

		MVweb_RP_Cache::bump();
	}

	/**
	 * Process one batch of queued posts.
	 *
	 * @since 1.0.0
	 * @return int Number of posts processed.
	 */
	public static function run_batch() {
		if ( get_transient( self::LOCK_TRANSIENT ) ) {
			return 0;
		}

		set_transient( self::LOCK_TRANSIENT, 1, 5 * MINUTE_IN_SECONDS );

		$processed = 0;

		foreach ( self::next_queue() as $post_id ) {
			self::reindex_post( $post_id );
			++$processed;
		}

		if ( 0 === $processed ) {
			delete_option( MVweb_RP_Activator::FULL_REINDEX_OPTION );
		} else {
			MVweb_RP_Cache::bump();
		}

		delete_transient( self::LOCK_TRANSIENT );

		return $processed;
	}

	/**
	 * Next batch of post ids waiting for indexing.
	 *
	 * @since 1.0.0
	 * @return int[]
	 */
	public static function next_queue() {
		$dirty = get_posts(
			array(
				'post_type'        => (array) MVweb_RP_Settings::get( 'post_types', array( 'post' ) ),
				'post_status'      => 'publish',
				'posts_per_page'   => self::BATCH_SIZE,
				'fields'           => 'ids',
				'orderby'          => 'modified',
				'order'            => 'DESC',
				'suppress_filters' => true,
				'no_found_rows'    => true,
				'meta_query'       => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- queue lookup runs in cron only.
					array(
						'key'     => self::META_DIRTY,
						'compare' => 'EXISTS',
					),
				),
			)
		);

		if ( ! empty( $dirty ) ) {
			return array_map( 'intval', $dirty );
		}

		if ( ! get_option( MVweb_RP_Activator::FULL_REINDEX_OPTION ) ) {
			return array();
		}

		$fresh = get_posts(
			array(
				'post_type'        => (array) MVweb_RP_Settings::get( 'post_types', array( 'post' ) ),
				'post_status'      => 'publish',
				'posts_per_page'   => self::BATCH_SIZE,
				'fields'           => 'ids',
				'suppress_filters' => true,
				'no_found_rows'    => true,
				'meta_query'       => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- full reindex runs in cron only.
					array(
						'key'     => self::META_INDEXED,
						'compare' => 'NOT EXISTS',
					),
				),
			)
		);

		return array_map( 'intval', (array) $fresh );
	}

	/**
	 * Rebuild tokens and relations for a single post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return void
	 */
	public static function reindex_post( $post_id ) {
		global $wpdb;

		$post_id = (int) $post_id;
		$post    = get_post( $post_id );

		if ( ! $post instanceof WP_Post || 'publish' !== $post->post_status ) {
			self::purge_post( $post_id );
			return;
		}

		$first_run = ! get_post_meta( $post_id, self::META_INDEXED, true );

		self::store_tokens( $post );

		$scored = MVweb_RP_Scorer::score_post( $post_id, self::STORE_LIMIT );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- index maintenance.
		$wpdb->delete( self::index_table(), array( 'source_id' => $post_id ), array( '%d' ) );

		foreach ( $scored as $related_id => $row ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- index maintenance.
			$wpdb->insert(
				self::index_table(),
				array(
					'source_id'  => $post_id,
					'related_id' => (int) $related_id,
					'score'      => (float) $row['score'],
					'factors'    => (string) wp_json_encode( $row['factors'] ),
				),
				array( '%d', '%d', '%f', '%s' )
			);
		}

		delete_post_meta( $post_id, self::META_DIRTY );
		update_post_meta( $post_id, self::META_INDEXED, time() );

		if ( $first_run ) {
			foreach ( array_keys( $scored ) as $related_id ) {
				self::mark_dirty( (int) $related_id );
			}
		}
	}

	/**
	 * Replace the stored stems of a post.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Post object.
	 * @return void
	 */
	private static function store_tokens( WP_Post $post ) {
		global $wpdb;

		$title_stems   = MVweb_RP_Stemmer::tokenize( $post->post_title, 20 );
		$content_stems = MVweb_RP_Stemmer::tokenize( $post->post_content, 60 );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- index maintenance.
		$wpdb->delete( self::tokens_table(), array( 'post_id' => $post->ID ), array( '%d' ) );

		$stems = $content_stems;
		foreach ( $title_stems as $stem => $count ) {
			$stems[ $stem ] = ( $stems[ $stem ] ?? 0 ) + $count;
		}

		foreach ( $stems as $stem => $count ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- index maintenance.
			$wpdb->insert(
				self::tokens_table(),
				array(
					'post_id'  => (int) $post->ID,
					'stem'     => (string) $stem,
					'weight'   => min( 255, (int) $count ),
					'in_title' => isset( $title_stems[ $stem ] ) ? 1 : 0,
				),
				array( '%d', '%s', '%d', '%d' )
			);
		}
	}

	/**
	 * Stored stems of one post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Post ID.
	 * @return array<string, array{weight: int, in_title: int}>
	 */
	public static function get_tokens( $post_id ) {
		$bulk = self::get_tokens_bulk( array( (int) $post_id ) );

		return $bulk[ (int) $post_id ] ?? array();
	}

	/**
	 * Stored stems of several posts.
	 *
	 * @since 1.0.0
	 * @param int[] $post_ids Post ids.
	 * @return array<int, array<string, array{weight: int, in_title: int}>>
	 */
	public static function get_tokens_bulk( array $post_ids ) {
		global $wpdb;

		$post_ids = array_values( array_unique( array_map( 'intval', $post_ids ) ) );
		if ( empty( $post_ids ) ) {
			return array();
		}

		$table        = self::tokens_table();
		$placeholders = implode( ',', array_fill( 0, count( $post_ids ), '%d' ) );

		$sql = "SELECT post_id, stem, weight, in_title FROM {$table} WHERE post_id IN ({$placeholders})";

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- placeholders built from a counted array.
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $post_ids ) );

		$map = array();
		foreach ( (array) $rows as $row ) {
			$map[ (int) $row->post_id ][ (string) $row->stem ] = array(
				'weight'   => (int) $row->weight,
				'in_title' => (int) $row->in_title,
			);
		}

		return $map;
	}

	/**
	 * Related post ids stored for a source post, best first.
	 *
	 * @since 1.0.0
	 * @param int $source_id Source post ID.
	 * @param int $limit     Maximum ids.
	 * @return int[]
	 */
	public static function get_related_ids( $source_id, $limit ) {
		global $wpdb;

		$table = self::index_table();

		$sql = "SELECT related_id FROM {$table} WHERE source_id = %d ORDER BY score DESC LIMIT %d";

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- table name interpolated, values prepared.
		$rows = $wpdb->get_col( $wpdb->prepare( $sql, (int) $source_id, (int) $limit ) );

		return array_map( 'intval', (array) $rows );
	}

	/**
	 * Stored rows with score and factors, used by the editor debug panel.
	 *
	 * @since 1.0.0
	 * @param int $source_id Source post ID.
	 * @param int $limit     Maximum rows.
	 * @return array<int, array{score: float, factors: array<string, float>}>
	 */
	public static function get_related_rows( $source_id, $limit = self::STORE_LIMIT ) {
		global $wpdb;

		$table = self::index_table();

		$sql = "SELECT related_id, score, factors FROM {$table} WHERE source_id = %d ORDER BY score DESC LIMIT %d";

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- table name interpolated, values prepared.
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, (int) $source_id, (int) $limit ) );

		$out = array();
		foreach ( (array) $rows as $row ) {
			$factors = json_decode( (string) $row->factors, true );

			$out[ (int) $row->related_id ] = array(
				'score'   => (float) $row->score,
				'factors' => is_array( $factors ) ? $factors : array(),
			);
		}

		return $out;
	}

	/**
	 * Index counters for the admin screen.
	 *
	 * @since 1.0.0
	 * @return array{indexed: int, relations: int, queued: int, next_run: int}
	 */
	public static function stats() {
		global $wpdb;

		$tokens_table = self::tokens_table();
		$index_table  = self::index_table();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$indexed   = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT post_id) FROM {$tokens_table}" );
		$relations = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$index_table}" );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		$queued = new WP_Query(
			array(
				'post_type'      => (array) MVweb_RP_Settings::get( 'post_types', array( 'post' ) ),
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query -- admin screen counter.
					array(
						'key'     => self::META_DIRTY,
						'compare' => 'EXISTS',
					),
				),
			)
		);

		return array(
			'indexed'   => $indexed,
			'relations' => $relations,
			'queued'    => (int) $queued->found_posts,
			'next_run'  => (int) wp_next_scheduled( self::CRON_HOOK ),
		);
	}

	/**
	 * Drop the whole index and queue a full rebuild.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function reset() {
		global $wpdb;

		$tokens_table = self::tokens_table();
		$index_table  = self::index_table();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$wpdb->query( "TRUNCATE TABLE {$tokens_table}" );
		$wpdb->query( "TRUNCATE TABLE {$index_table}" );
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s", self::META_INDEXED ) );
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->postmeta} WHERE meta_key = %s", self::META_DIRTY ) );
		// phpcs:enable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared

		update_option( MVweb_RP_Activator::FULL_REINDEX_OPTION, 1 );

		MVweb_RP_Cache::bump();
	}
}
