<?php
/**
 * Activation and deactivation routines.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_RP_Activator
 *
 * @since 1.0.0
 */
class MVweb_RP_Activator {

	const DB_VERSION_OPTION = 'mvweb_rp_db_version';

	const DB_VERSION = '1.0.0';

	const FULL_REINDEX_OPTION = 'mvweb_rp_full_reindex';

	/**
	 * Create tables, seed defaults and schedule the indexer.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function activate() {
		self::create_tables();

		if ( false === get_option( MVweb_RP_Settings::OPTION, false ) ) {
			$defaults                = MVweb_RP_Settings::defaults();
			$defaults['block_title'] = __( 'Read also', 'mvweb-related-posts' );

			add_option( MVweb_RP_Settings::OPTION, $defaults );
		}

		update_option( self::FULL_REINDEX_OPTION, 1 );

		MVweb_RP_Indexer::schedule();
	}

	/**
	 * Clear the scheduled indexer.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function deactivate() {
		MVweb_RP_Indexer::unschedule();
	}

	/**
	 * Create or upgrade the plugin tables.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function create_tables() {
		global $wpdb;

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();
		$tokens  = MVweb_RP_Indexer::tokens_table();
		$index   = MVweb_RP_Indexer::index_table();

		dbDelta(
			"CREATE TABLE {$tokens} (
				post_id bigint(20) unsigned NOT NULL,
				stem varchar(32) NOT NULL,
				weight smallint(5) unsigned NOT NULL DEFAULT 1,
				in_title tinyint(1) unsigned NOT NULL DEFAULT 0,
				PRIMARY KEY  (post_id, stem),
				KEY stem (stem)
			) {$charset};"
		);

		dbDelta(
			"CREATE TABLE {$index} (
				source_id bigint(20) unsigned NOT NULL,
				related_id bigint(20) unsigned NOT NULL,
				score float NOT NULL DEFAULT 0,
				factors varchar(255) NOT NULL DEFAULT '',
				PRIMARY KEY  (source_id, related_id),
				KEY source_score (source_id, score)
			) {$charset};"
		);

		update_option( self::DB_VERSION_OPTION, self::DB_VERSION );
	}

	/**
	 * Re-create tables when the stored schema version is behind.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function maybe_upgrade() {
		if ( get_option( self::DB_VERSION_OPTION ) === self::DB_VERSION ) {
			return;
		}

		self::create_tables();
	}
}
