<?php
/**
 * Selection of the posts shown in the block.
 *
 * Order: pinned posts, then stored index rows, then the category fallback.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_RP_Query
 *
 * @since 1.0.0
 */
class MVweb_RP_Query {

	/**
	 * Related post ids for a source post, respecting pins, exclusions and fallback.
	 *
	 * Returns an empty array when fewer than `min_results` posts are available.
	 *
	 * @since 1.0.0
	 * @param int $post_id Source post ID.
	 * @param int $count   Requested number of posts.
	 * @return int[]
	 */
	public static function get_ids( $post_id, $count = 0 ) {
		$post_id = (int) $post_id;
		$count   = $count > 0 ? (int) $count : (int) MVweb_RP_Settings::get( 'count', 4 );

		if ( $post_id <= 0 ) {
			return array();
		}

		$excluded   = self::excluded_ids( $post_id );
		$collected  = array();
		$pinned_ids = MVweb_RP_Metabox::get_pinned( $post_id );

		foreach ( $pinned_ids as $pinned_id ) {
			if ( in_array( $pinned_id, $excluded, true ) ) {
				continue;
			}
			if ( 'publish' !== get_post_status( $pinned_id ) ) {
				continue;
			}
			$collected[] = $pinned_id;
		}

		if ( count( $collected ) < $count ) {
			foreach ( MVweb_RP_Indexer::get_related_ids( $post_id, $count * 3 ) as $related_id ) {
				if ( in_array( $related_id, $excluded, true ) || in_array( $related_id, $collected, true ) ) {
					continue;
				}
				$collected[] = $related_id;
				if ( count( $collected ) >= $count ) {
					break;
				}
			}
		}

		if ( count( $collected ) < $count && MVweb_RP_Settings::get( 'fallback_parent', true ) ) {
			$collected = array_merge( $collected, self::fallback_ids( $post_id, $count - count( $collected ), array_merge( $excluded, $collected ) ) );
		}

		$collected = array_slice( array_values( array_unique( $collected ) ), 0, $count );

		$min_results = (int) MVweb_RP_Settings::get( 'min_results', 2 );
		if ( count( $collected ) < $min_results ) {
			return array();
		}

		/**
		 * Filter the final list of related post ids.
		 *
		 * @since 1.0.0
		 * @param int[] $collected Related post ids.
		 * @param int   $post_id   Source post ID.
		 */
		return (array) apply_filters( 'mvweb_rp_related_ids', $collected, $post_id );
	}

	/**
	 * Related posts as objects.
	 *
	 * @since 1.0.0
	 * @param int $post_id Source post ID.
	 * @param int $count   Requested number of posts.
	 * @return WP_Post[]
	 */
	public static function get_posts( $post_id, $count = 0 ) {
		$ids = self::get_ids( $post_id, $count );
		if ( empty( $ids ) ) {
			return array();
		}

		$posts = get_posts(
			array(
				'post__in'            => $ids,
				'orderby'             => 'post__in',
				'posts_per_page'      => count( $ids ),
				'post_type'           => 'any',
				'post_status'         => 'publish',
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
			)
		);

		return is_array( $posts ) ? $posts : array();
	}

	/**
	 * Ids that must never appear in the block for this post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Source post ID.
	 * @return int[]
	 */
	private static function excluded_ids( $post_id ) {
		$excluded = array( (int) $post_id );

		$global = MVweb_RP_Settings::get( 'exclude_posts', array() );
		if ( is_array( $global ) ) {
			$excluded = array_merge( $excluded, array_map( 'intval', $global ) );
		}

		$excluded = array_merge( $excluded, MVweb_RP_Metabox::get_excluded( $post_id ) );

		return array_values( array_unique( $excluded ) );
	}

	/**
	 * Recent posts from the same categories, used when the index is short.
	 *
	 * @since 1.0.0
	 * @param int   $post_id  Source post ID.
	 * @param int   $needed   How many posts are still missing.
	 * @param int[] $excluded Ids to skip.
	 * @return int[]
	 */
	private static function fallback_ids( $post_id, $needed, array $excluded ) {
		if ( $needed <= 0 ) {
			return array();
		}

		$terms = wp_get_object_terms( $post_id, 'category', array( 'fields' => 'ids' ) );
		if ( is_wp_error( $terms ) || empty( $terms ) ) {
			return array();
		}

		$ids = get_posts(
			array(
				'post_type'           => get_post_type( $post_id ),
				'post_status'         => 'publish',
				'posts_per_page'      => $needed,
				'fields'              => 'ids',
				'ignore_sticky_posts' => true,
				'no_found_rows'       => true,
				'post__not_in'        => array_map( 'intval', $excluded ),
				'has_password'        => false,
				'tax_query'           => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query -- category fallback is cached with the rendered block.
					array(
						'taxonomy' => 'category',
						'field'    => 'term_id',
						'terms'    => array_map( 'intval', $terms ),
					),
				),
			)
		);

		return array_map( 'intval', (array) $ids );
	}
}
