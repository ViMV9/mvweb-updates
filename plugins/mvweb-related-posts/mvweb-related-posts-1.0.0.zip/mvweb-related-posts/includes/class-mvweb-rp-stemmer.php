<?php
/**
 * Russian stemmer and tokenizer used for text similarity.
 *
 * Port of the moderate inflectional stemmer shipped with MVweb Smart Links,
 * reduced to the tokenisation path needed here.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_RP_Stemmer
 *
 * @since 1.0.0
 */
class MVweb_RP_Stemmer {

	const MIN_STEM_LEN = 3;

	const MIN_WORD_LEN = 4;

	const VOWELS = array( 'а', 'е', 'ё', 'и', 'о', 'у', 'ы', 'э', 'ю', 'я' );

	/**
	 * Function words dropped before stemming.
	 */
	const STOP_WORDS = array(
		'без',
		'более',
		'будет',
		'бы',
		'был',
		'была',
		'были',
		'было',
		'быть',
		'ваш',
		'весь',
		'вот',
		'все',
		'всего',
		'всех',
		'вы',
		'где',
		'для',
		'до',
		'его',
		'ее',
		'её',
		'если',
		'есть',
		'еще',
		'ещё',
		'же',
		'за',
		'здесь',
		'из',
		'или',
		'им',
		'их',
		'как',
		'кто',
		'ли',
		'между',
		'меня',
		'мы',
		'на',
		'над',
		'нас',
		'не',
		'него',
		'нее',
		'нет',
		'ни',
		'них',
		'но',
		'ну',
		'об',
		'она',
		'они',
		'оно',
		'от',
		'очень',
		'по',
		'под',
		'при',
		'про',
		'себя',
		'со',
		'так',
		'также',
		'такой',
		'там',
		'те',
		'тем',
		'то',
		'того',
		'тоже',
		'той',
		'только',
		'том',
		'тот',
		'ты',
		'уже',
		'что',
		'чтобы',
		'эта',
		'эти',
		'это',
		'этой',
		'этом',
		'этот',
		'and',
		'are',
		'for',
		'from',
		'that',
		'the',
		'this',
		'was',
		'were',
		'with',
		'you',
		'your',
	);

	/**
	 * Inflectional endings, sorted longest-first on first use.
	 *
	 * @var string[]|null
	 */
	private static $endings = null;

	/**
	 * Reduce a lowercase word to its inflectional stem.
	 *
	 * Latin and numeric tokens are returned unchanged.
	 *
	 * @since 1.0.0
	 * @param string $word Lowercase word.
	 * @return string
	 */
	public static function stem( $word ) {
		$word = (string) $word;
		if ( '' === $word ) {
			return '';
		}

		if ( ! preg_match( '/^[а-яё]+$/u', $word ) ) {
			return $word;
		}

		$rv_start = self::rv_offset( $word );
		if ( $rv_start < 0 ) {
			return $word;
		}

		$head = mb_substr( $word, 0, $rv_start, 'UTF-8' );
		$rv   = mb_substr( $word, $rv_start, null, 'UTF-8' );

		foreach ( self::get_endings() as $ending ) {
			$elen = mb_strlen( $ending, 'UTF-8' );
			if ( mb_strlen( $rv, 'UTF-8' ) < $elen ) {
				continue;
			}
			if ( mb_substr( $rv, -$elen, null, 'UTF-8' ) === $ending ) {
				$rv = mb_substr( $rv, 0, -$elen, 'UTF-8' );
				break;
			}
		}

		$stem = preg_replace( '/[ьъ]$/u', '', $head . $rv );

		if ( mb_strlen( (string) $stem, 'UTF-8' ) < self::MIN_STEM_LEN ) {
			return $word;
		}

		return (string) $stem;
	}

	/**
	 * Split text into stems with occurrence counts.
	 *
	 * @since 1.0.0
	 * @param string $text  Raw text or HTML.
	 * @param int    $limit Maximum number of distinct stems to keep.
	 * @return array<string, int> Stem => count, ordered by count descending.
	 */
	public static function tokenize( $text, $limit = 60 ) {
		$text = wp_strip_all_tags( (string) $text, true );
		$text = html_entity_decode( $text, ENT_QUOTES, 'UTF-8' );
		$text = mb_strtolower( $text, 'UTF-8' );

		$words = preg_split( '/[^\p{L}\p{N}]+/u', $text, -1, PREG_SPLIT_NO_EMPTY );
		if ( ! is_array( $words ) ) {
			return array();
		}

		$stems = array();
		foreach ( $words as $word ) {
			if ( mb_strlen( $word, 'UTF-8' ) < self::MIN_WORD_LEN ) {
				continue;
			}
			if ( in_array( $word, self::STOP_WORDS, true ) ) {
				continue;
			}
			if ( preg_match( '/^\p{N}+$/u', $word ) ) {
				continue;
			}

			$stem = self::stem( $word );
			if ( mb_strlen( $stem, 'UTF-8' ) < self::MIN_STEM_LEN ) {
				continue;
			}

			$stem = mb_substr( $stem, 0, 32, 'UTF-8' );

			$stems[ $stem ] = isset( $stems[ $stem ] ) ? $stems[ $stem ] + 1 : 1;
		}

		arsort( $stems );

		if ( $limit > 0 && count( $stems ) > $limit ) {
			$stems = array_slice( $stems, 0, $limit, true );
		}

		return $stems;
	}

	/**
	 * Character offset right after the first vowel.
	 *
	 * @since 1.0.0
	 * @param string $word Lowercase Cyrillic word.
	 * @return int Offset, or -1 when the word has no vowel.
	 */
	private static function rv_offset( $word ) {
		$chars = mb_str_split( $word, 1, 'UTF-8' );
		foreach ( $chars as $i => $char ) {
			if ( in_array( $char, self::VOWELS, true ) ) {
				return $i + 1;
			}
		}

		return -1;
	}

	/**
	 * Inflectional endings list, longest-first.
	 *
	 * @since 1.0.0
	 * @return string[]
	 */
	private static function get_endings() {
		if ( null !== self::$endings ) {
			return self::$endings;
		}

		$list = array(
			'ившись',
			'ывшись',
			'ивший',
			'ывший',
			'ующий',
			'ивши',
			'ывши',
			'ущий',
			'ющий',
			'ящий',
			'ивш',
			'ывш',
			'ейте',
			'уйте',
			'ете',
			'ите',
			'ишь',
			'ешь',
			'ать',
			'ять',
			'ить',
			'еть',
			'ыть',
			'ует',
			'уют',
			'ает',
			'ают',
			'ило',
			'ыло',
			'ала',
			'яла',
			'ена',
			'ено',
			'ем',
			'ет',
			'ют',
			'им',
			'ит',
			'ал',
			'ял',
			'ел',
			'ил',
			'ыл',
			'иями',
			'ями',
			'ами',
			'иях',
			'ого',
			'его',
			'ому',
			'ему',
			'ыми',
			'ими',
			'ая',
			'яя',
			'ою',
			'ею',
			'ую',
			'юю',
			'ых',
			'их',
			'ое',
			'ее',
			'ый',
			'ий',
			'ой',
			'ом',
			'ым',
			'ах',
			'ях',
			'ов',
			'ев',
			'ью',
			'ия',
			'ие',
			'ии',
			'ье',
			'ьё',
			'а',
			'е',
			'и',
			'о',
			'у',
			'ы',
			'ю',
			'я',
			'й',
			'ь',
			'ъ',
		);

		$list = array_values( array_unique( $list ) );
		usort(
			$list,
			static function ( $a, $b ) {
				return mb_strlen( $b, 'UTF-8' ) <=> mb_strlen( $a, 'UTF-8' );
			}
		);

		self::$endings = $list;

		return self::$endings;
	}
}
