<?php
/**
 * Public helper functions for MVweb Related Posts.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'mvweb_rp_asset_ver' ) ) {
	/**
	 * Cache-busting version for a bundled asset, based on its modification time.
	 *
	 * @since 1.0.0
	 * @param string $relative Path relative to the plugin root (e.g. 'public/css/public.min.css').
	 * @return string
	 */
	function mvweb_rp_asset_ver( string $relative ): string {
		$file = MVWEB_RP_PATH . ltrim( $relative, '/' );
		$time = is_readable( $file ) ? filemtime( $file ) : false;

		return false !== $time ? (string) $time : MVWEB_RP_VERSION;
	}
}

if ( ! function_exists( 'mvweb_rp_get_related' ) ) {
	/**
	 * Related posts for a given post.
	 *
	 * @since 1.0.0
	 * @param int $post_id Source post ID, current post when omitted.
	 * @param int $count   Number of posts, plugin setting when omitted.
	 * @return WP_Post[]
	 */
	function mvweb_rp_get_related( $post_id = 0, $count = 0 ) {
		$post_id = (int) $post_id > 0 ? (int) $post_id : (int) get_the_ID();

		return MVweb_RP_Query::get_posts( $post_id, (int) $count );
	}
}

if ( ! function_exists( 'mvweb_rp_related' ) ) {
	/**
	 * Print the related posts block.
	 *
	 * @since 1.0.0
	 * @param array<string, mixed> $args Overrides: post_id, count, template, title, columns.
	 * @return void
	 */
	function mvweb_rp_related( array $args = array() ) {
		$post_id = isset( $args['post_id'] ) ? (int) $args['post_id'] : (int) get_the_ID();

		unset( $args['post_id'] );

		echo MVweb_RP_Public::render( $post_id, $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- markup escaped in templates.
	}
}

if ( ! function_exists( 'mvweb_rp_thumbnail_html' ) ) {
	/**
	 * Thumbnail markup for a card, falling back to the first content image.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Post to render.
	 * @return string
	 */
	function mvweb_rp_thumbnail_html( WP_Post $post ) {
		$size = (string) MVweb_RP_Settings::get( 'image_size', MVweb_RP_Public::IMAGE_SIZE );

		if ( has_post_thumbnail( $post ) ) {
			return (string) get_the_post_thumbnail(
				$post,
				$size,
				array(
					'loading'  => 'lazy',
					'decoding' => 'async',
					'alt'      => get_the_title( $post ),
				)
			);
		}

		$attachment_id = mvweb_rp_first_content_image_id( $post );
		if ( $attachment_id > 0 ) {
			return (string) wp_get_attachment_image(
				$attachment_id,
				$size,
				false,
				array(
					'loading'  => 'lazy',
					'decoding' => 'async',
				)
			);
		}

		$placeholder = (string) MVweb_RP_Settings::get( 'placeholder_url', '' );
		if ( '' === $placeholder ) {
			$placeholder = MVWEB_RP_URL . 'public/images/placeholder.svg';
		}

		return sprintf(
			'<img src="%s" alt="" loading="lazy" decoding="async" />',
			esc_url( $placeholder )
		);
	}
}

if ( ! function_exists( 'mvweb_rp_first_content_image_id' ) ) {
	/**
	 * Attachment id of the first image found in the post content.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Post to scan.
	 * @return int Zero when no local image is found.
	 */
	function mvweb_rp_first_content_image_id( WP_Post $post ) {
		if ( ! preg_match( '/<img[^>]+wp-image-(\d+)/i', (string) $post->post_content, $matches ) ) {
			return 0;
		}

		$attachment_id = (int) $matches[1];

		return wp_attachment_is_image( $attachment_id ) ? $attachment_id : 0;
	}
}

if ( ! function_exists( 'mvweb_rp_card_excerpt' ) ) {
	/**
	 * Trimmed excerpt for a card.
	 *
	 * @since 1.0.0
	 * @param WP_Post $post Post to render.
	 * @return string
	 */
	function mvweb_rp_card_excerpt( WP_Post $post ) {
		$words = (int) MVweb_RP_Settings::get( 'excerpt_words', 18 );
		$text  = has_excerpt( $post ) ? $post->post_excerpt : $post->post_content;
		$text  = wp_strip_all_tags( strip_shortcodes( (string) $text ), true );

		return wp_trim_words( $text, $words, '…' );
	}
}
