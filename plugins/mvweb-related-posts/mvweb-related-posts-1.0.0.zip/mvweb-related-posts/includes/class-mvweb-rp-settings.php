<?php
/**
 * Settings storage, defaults and sanitisation.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_RP_Settings
 *
 * @since 1.0.0
 */
class MVweb_RP_Settings {

	const OPTION = 'mvweb_rp_settings';

	const TEMPLATES = array( 'cards', 'list', 'links' );

	const ASPECTS = array( '16-9', '4-3', '1-1' );

	const PRESETS = array( 'blog', 'services', 'strict', 'custom' );

	/**
	 * Weight keys used by the scorer.
	 */
	const WEIGHT_KEYS = array(
		'weight_category',
		'weight_tag',
		'weight_taxonomy',
		'weight_title',
		'weight_content',
		'weight_freshness',
	);

	/**
	 * Weight profiles offered as presets.
	 *
	 * @var array<string, array<string, int>>
	 */
	const PRESET_WEIGHTS = array(
		'blog'     => array(
			'weight_category'  => 6,
			'weight_tag'       => 7,
			'weight_taxonomy'  => 4,
			'weight_title'     => 8,
			'weight_content'   => 5,
			'weight_freshness' => 3,
		),
		'services' => array(
			'weight_category'  => 8,
			'weight_tag'       => 5,
			'weight_taxonomy'  => 7,
			'weight_title'     => 7,
			'weight_content'   => 4,
			'weight_freshness' => 1,
		),
		'strict'   => array(
			'weight_category'  => 9,
			'weight_tag'       => 8,
			'weight_taxonomy'  => 8,
			'weight_title'     => 9,
			'weight_content'   => 3,
			'weight_freshness' => 0,
		),
	);

	/**
	 * Runtime cache of the merged settings array.
	 *
	 * @var array<string, mixed>|null
	 */
	private static $cache = null;

	/**
	 * Default settings.
	 *
	 * @since 1.0.0
	 * @return array<string, mixed>
	 */
	public static function defaults() {
		return array_merge(
			self::PRESET_WEIGHTS['blog'],
			array(
				'enabled'         => true,
				'auto_output'     => true,
				'post_types'      => array( 'post' ),
				'taxonomies'      => array(),
				'count'           => 4,
				'min_results'     => 2,
				'fallback_parent' => true,
				'preset'          => 'blog',
				'max_age_months'  => 0,
				'exclude_terms'   => array(),
				'exclude_posts'   => array(),
				'template'        => 'cards',
				'columns'         => 3,
				'block_title'     => 'Read also',
				'show_thumb'      => true,
				'show_excerpt'    => true,
				'excerpt_words'   => 18,
				'image_size'      => 'mvweb_rp_thumb',
				'aspect'          => '16-9',
				'placeholder_url' => '',
				'custom_css'      => '',
				'schema_enabled'  => true,
			)
		);
	}

	/**
	 * All settings, defaults merged with stored values.
	 *
	 * @since 1.0.0
	 * @return array<string, mixed>
	 */
	public static function all() {
		if ( null !== self::$cache ) {
			return self::$cache;
		}

		$stored = get_option( self::OPTION, array() );
		if ( ! is_array( $stored ) ) {
			$stored = array();
		}

		self::$cache = array_merge( self::defaults(), $stored );

		return self::$cache;
	}

	/**
	 * Single setting value.
	 *
	 * @since 1.0.0
	 * @param string $key     Setting key.
	 * @param mixed  $fallback Value returned when the key is unknown.
	 * @return mixed
	 */
	public static function get( $key, $fallback = null ) {
		$all = self::all();

		return array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
	}

	/**
	 * Drop the runtime cache after a save.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function flush() {
		self::$cache = null;
	}

	/**
	 * Register the option with the Settings API.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public static function register() {
		register_setting(
			'mvweb_rp_settings_group',
			self::OPTION,
			array(
				'type'              => 'array',
				'sanitize_callback' => array( __CLASS__, 'sanitize' ),
				'default'           => self::defaults(),
			)
		);
	}

	/**
	 * Sanitise the whole settings array.
	 *
	 * @since 1.0.0
	 * @param mixed $input Raw input from the settings form.
	 * @return array<string, mixed>
	 */
	public static function sanitize( $input ) {
		$out = self::defaults();

		if ( ! is_array( $input ) ) {
			return $out;
		}

		foreach ( array( 'enabled', 'auto_output', 'fallback_parent', 'show_thumb', 'show_excerpt', 'schema_enabled' ) as $flag ) {
			$out[ $flag ] = ! empty( $input[ $flag ] );
		}

		$out['post_types'] = self::sanitize_slug_list( $input['post_types'] ?? array(), get_post_types( array( 'public' => true ) ) );
		if ( empty( $out['post_types'] ) ) {
			$out['post_types'] = array( 'post' );
		}

		$out['taxonomies'] = self::sanitize_slug_list( $input['taxonomies'] ?? array(), get_taxonomies( array( 'public' => true ) ) );

		$out['count']          = self::clamp_int( $input['count'] ?? 4, 1, 12 );
		$out['min_results']    = self::clamp_int( $input['min_results'] ?? 2, 1, 12 );
		$out['columns']        = self::clamp_int( $input['columns'] ?? 3, 1, 6 );
		$out['excerpt_words']  = self::clamp_int( $input['excerpt_words'] ?? 18, 5, 60 );
		$out['max_age_months'] = self::clamp_int( $input['max_age_months'] ?? 0, 0, 240 );

		if ( $out['min_results'] > $out['count'] ) {
			$out['min_results'] = $out['count'];
		}

		$preset        = isset( $input['preset'] ) ? sanitize_key( (string) $input['preset'] ) : 'blog';
		$out['preset'] = in_array( $preset, self::PRESETS, true ) ? $preset : 'blog';

		foreach ( self::WEIGHT_KEYS as $weight_key ) {
			$out[ $weight_key ] = self::clamp_int( $input[ $weight_key ] ?? 0, 0, 10 );
		}

		if ( 'custom' !== $out['preset'] ) {
			$out = array_merge( $out, self::PRESET_WEIGHTS[ $out['preset'] ] );
		}

		$out['exclude_terms'] = self::sanitize_id_list( $input['exclude_terms'] ?? array() );
		$out['exclude_posts'] = self::sanitize_id_list( $input['exclude_posts'] ?? array() );

		$template          = isset( $input['template'] ) ? sanitize_key( (string) $input['template'] ) : 'cards';
		$out['template']   = in_array( $template, self::TEMPLATES, true ) ? $template : 'cards';
		$aspect            = isset( $input['aspect'] ) ? sanitize_key( (string) $input['aspect'] ) : '16-9';
		$out['aspect']     = in_array( $aspect, self::ASPECTS, true ) ? $aspect : '16-9';
		$image_size        = isset( $input['image_size'] ) ? sanitize_key( (string) $input['image_size'] ) : 'mvweb_rp_thumb';
		$known_sizes       = array_merge( get_intermediate_image_sizes(), array( 'full' ) );
		$out['image_size'] = in_array( $image_size, $known_sizes, true ) ? $image_size : 'mvweb_rp_thumb';

		$out['block_title']     = sanitize_text_field( (string) ( $input['block_title'] ?? '' ) );
		$out['placeholder_url'] = esc_url_raw( (string) ( $input['placeholder_url'] ?? '' ) );
		$out['custom_css']      = self::sanitize_css( (string) ( $input['custom_css'] ?? '' ) );

		self::flush();

		return $out;
	}

	/**
	 * Keep only slugs present in the allowed list.
	 *
	 * @since 1.0.0
	 * @param mixed    $value   Raw list.
	 * @param string[] $allowed Allowed slugs.
	 * @return string[]
	 */
	private static function sanitize_slug_list( $value, array $allowed ) {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$clean = array();
		foreach ( $value as $slug ) {
			$slug = sanitize_key( (string) $slug );
			if ( '' !== $slug && in_array( $slug, $allowed, true ) ) {
				$clean[] = $slug;
			}
		}

		return array_values( array_unique( $clean ) );
	}

	/**
	 * Normalise a list of positive integers, accepting arrays or comma strings.
	 *
	 * @since 1.0.0
	 * @param mixed $value Raw list.
	 * @return int[]
	 */
	public static function sanitize_id_list( $value ) {
		if ( is_string( $value ) ) {
			$value = preg_split( '/[\s,]+/', $value );
		}

		if ( ! is_array( $value ) ) {
			return array();
		}

		$ids = array();
		foreach ( $value as $id ) {
			$id = (int) $id;
			if ( $id > 0 ) {
				$ids[] = $id;
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Strip tags and control characters from the custom CSS field.
	 *
	 * @since 1.0.0
	 * @param string $css Raw CSS.
	 * @return string
	 */
	private static function sanitize_css( $css ) {
		$css = wp_strip_all_tags( $css );

		return trim( str_replace( array( '<', '>' ), '', $css ) );
	}

	/**
	 * Clamp an integer into a range.
	 *
	 * @since 1.0.0
	 * @param mixed $value Raw value.
	 * @param int   $min   Lower bound.
	 * @param int   $max   Upper bound.
	 * @return int
	 */
	private static function clamp_int( $value, $min, $max ) {
		$value = (int) $value;

		return max( $min, min( $max, $value ) );
	}
}
