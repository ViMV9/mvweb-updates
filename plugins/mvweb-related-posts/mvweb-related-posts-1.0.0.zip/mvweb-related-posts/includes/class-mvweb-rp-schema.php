<?php
/**
 * ItemList JSON-LD for the rendered block.
 *
 * @package mvweb_rp
 * @since   1.0.0
 */

declare(strict_types=1);

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * MVweb_RP_Schema
 *
 * @since 1.0.0
 */
class MVweb_RP_Schema {

	/**
	 * Build the ItemList script tag for a list of posts.
	 *
	 * @since 1.0.0
	 * @param WP_Post[] $posts Related posts in display order.
	 * @return string
	 */
	public static function item_list( array $posts ) {
		if ( count( $posts ) < 2 ) {
			return '';
		}

		$items    = array();
		$position = 1;

		foreach ( $posts as $post ) {
			if ( ! $post instanceof WP_Post ) {
				continue;
			}

			$items[] = array(
				'@type'    => 'ListItem',
				'position' => $position,
				'url'      => get_permalink( $post ),
				'name'     => wp_strip_all_tags( get_the_title( $post ) ),
			);

			++$position;
		}

		if ( count( $items ) < 2 ) {
			return '';
		}

		$graph = array(
			'@context'        => 'https://schema.org',
			'@type'           => 'ItemList',
			'itemListOrder'   => 'https://schema.org/ItemListOrderDescending',
			'numberOfItems'   => count( $items ),
			'itemListElement' => $items,
		);

		/**
		 * Filter the ItemList graph before it is printed.
		 *
		 * @since 1.0.0
		 * @param array<string, mixed> $graph Schema.org graph.
		 * @param WP_Post[]            $posts Related posts.
		 */
		$graph = (array) apply_filters( 'mvweb_rp_schema_graph', $graph, $posts );

		return '<script type="application/ld+json">' . wp_json_encode( $graph, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) . '</script>';
	}
}
